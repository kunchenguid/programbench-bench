#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

static const char *langs =
    "bash, c, cpp, crystal, csharp, dart, elixir, go, groovy, haskell, java, "
    "javascript, julia, kotlin, lua, nim, perl, php, python, r, ruby, rust, "
    "swift, typescript, zig";

static void help(void) {
    puts("Universal multi-language runner and REPL\n");
    puts("Usage: executable [OPTIONS] [ARGS]...\n");
    puts("Arguments:");
    puts("  [ARGS]...  Positional arguments (language, code, or file)\n");
    puts("Options:");
    puts("  -V, --version      Print version information and exit");
    puts("  -l, --lang <LANG>  Explicitly choose the language to execute");
    puts("  -f, --file <PATH>  Execute code from the provided file path");
    puts("  -c, --code <CODE>  Execute the provided code snippet");
    puts("      --no-detect    Disable heuristic language detection");
    puts("  -h, --help         Print help");
}

static void version(void) {
    puts("run-kit 0.3.2");
    puts("Universal multi-language runner and smart REPL");
    puts("author: Esubalew Chekol <esubalewchekol6@gmail.com>");
    puts("homepage: https://esubalew.et");
    puts("repository: https://github.com/Esubaalew/run");
    puts("license: Apache-2.0");
    puts("commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)");
    puts("built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]");
    puts("rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)");
}

static void parse_error_missing(const char *opt) {
    fprintf(stderr, "error: a value is required for '%s' but none was supplied\n\n", opt);
    fprintf(stderr, "For more information, try '--help'.\n");
}

static void parse_error_unexpected(const char *arg, bool has_lang) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fprintf(stderr, "Usage: executable %s[ARGS]...\n\n", has_lang ? "--lang <LANG> " : "[OPTIONS] ");
    fprintf(stderr, "For more information, try '--help'.\n");
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (n < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)n + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0;
    fclose(f);
    return buf;
}

static char *join_pos(const char **pos, int start, int npos) {
    if (start >= npos) return NULL;
    size_t n = 0;
    for (int i = start; i < npos; i++) n += strlen(pos[i]) + 1;
    char *s = calloc(n + 1, 1);
    if (!s) return NULL;
    for (int i = start; i < npos; i++) {
        if (i > start) strcat(s, " ");
        strcat(s, pos[i]);
    }
    return s;
}

static bool eq(const char *a, const char *b) { return strcmp(a, b) == 0; }

static const char *canon_lang(const char *l) {
    if (!l) return NULL;
    if (eq(l, "py") || eq(l, "python3")) return "python";
    if (eq(l, "js") || eq(l, "node")) return "javascript";
    if (eq(l, "ts")) return "typescript";
    if (eq(l, "sh")) return "bash";
    if (eq(l, "cc") || eq(l, "c++") || eq(l, "cxx")) return "cpp";
    if (eq(l, "rs")) return "rust";
    return l;
}

static bool known_lang(const char *l) {
    static const char *known[] = {"bash","c","cpp","crystal","csharp","dart","elixir","go",
        "groovy","haskell","java","javascript","julia","kotlin","lua","nim","perl","php",
        "python","r","ruby","rust","swift","typescript","zig", NULL};
    l = canon_lang(l);
    for (int i = 0; known[i]; i++) if (eq(l, known[i])) return true;
    return false;
}

static const char *lang_from_path(const char *p) {
    const char *d = strrchr(p, '.');
    if (!d) return NULL;
    d++;
    if (eq(d, "py")) return "python";
    if (eq(d, "js") || eq(d, "mjs") || eq(d, "cjs")) return "javascript";
    if (eq(d, "ts")) return "typescript";
    if (eq(d, "rb")) return "ruby";
    if (eq(d, "sh") || eq(d, "bash")) return "bash";
    if (eq(d, "pl")) return "perl";
    if (eq(d, "c")) return "c";
    if (eq(d, "cc") || eq(d, "cpp") || eq(d, "cxx") || eq(d, "hpp")) return "cpp";
    if (eq(d, "go")) return "go";
    if (eq(d, "rs")) return "rust";
    if (eq(d, "java")) return "java";
    if (eq(d, "lua")) return "lua";
    if (eq(d, "php")) return "php";
    return NULL;
}

static int wait_status(int st) {
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return 1;
}

static int run_exec3(const char *prog, const char *a, const char *b) {
    pid_t pid = fork();
    if (pid == 0) {
        if (b) execlp(prog, prog, a, b, (char *)NULL);
        else if (a) execlp(prog, prog, a, (char *)NULL);
        else execlp(prog, prog, (char *)NULL);
        fprintf(stderr, "%s: %s\n", prog, strerror(errno));
        _exit(127);
    }
    if (pid < 0) return 1;
    int st;
    if (waitpid(pid, &st, 0) < 0) return 1;
    return wait_status(st);
}

static int write_text(const char *path, const char *s) {
    int fd = open(path, O_CREAT | O_TRUNC | O_WRONLY, 0644);
    if (fd < 0) return -1;
    size_t n = strlen(s);
    ssize_t w = write(fd, s, n);
    close(fd);
    return w == (ssize_t)n ? 0 : -1;
}

static int compile_and_run(const char *lang, const char *code, bool from_file) {
    char dir[32];
    snprintf(dir, sizeof(dir), "%s", eq(lang, "cpp") ? "/tmp/run-cppXXXXXX" : "/tmp/run-cXXXXXX");
    if (!mkdtemp(dir)) return 1;
    char src[512], out[512], cmd[1600];
    snprintf(out, sizeof(out), "%s/main", dir);
    if (eq(lang, "c")) {
        snprintf(src, sizeof(src), "%s/main.c", dir);
        char *wrapped = NULL;
        const char *body = code;
        if (!from_file && !strstr(code, "int main") && !strstr(code, "#include")) {
            size_t need = strlen(code) + 80;
            wrapped = malloc(need);
            if (!wrapped) return 1;
            snprintf(wrapped, need, "#include <stdio.h>\nint main(){\n%s\nreturn 0;\n}\n", code);
            body = wrapped;
        }
        if (write_text(src, body) != 0) return 1;
        free(wrapped);
        snprintf(cmd, sizeof(cmd), "gcc %s -o %s", src, out);
    } else {
        snprintf(src, sizeof(src), "%s/main.cpp", dir);
        if (write_text(src, code) != 0) return 1;
        snprintf(cmd, sizeof(cmd), "g++ %s -o %s", src, out);
    }
    int rc = system(cmd);
    if (rc == -1 || wait_status(rc) != 0) return rc == -1 ? 1 : wait_status(rc);
    return run_exec3(out, NULL, NULL);
}

static int unavailable(const char *lang) {
    if (eq(lang, "python")) fprintf(stderr, "python is not available in the c-mandated arm\n");
    else if (eq(lang, "go")) fprintf(stderr, "Error: Go support requires the `go` executable. Install it from https://go.dev/dl/ and ensure it is on your PATH.\n");
    else if (eq(lang, "rust")) fprintf(stderr, "Error: Rust support requires the `rustc` executable. Install it via Rustup and ensure it is on your PATH.\n");
    else if (eq(lang, "java")) fprintf(stderr, "Error: Java support requires the `javac` compiler. Install the JDK from https://adoptium.net/ or your vendor of choice and ensure it is on your PATH.\n");
    else if (eq(lang, "lua")) fprintf(stderr, "Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.\n");
    else if (eq(lang, "php")) fprintf(stderr, "Error: PHP support requires the `php` CLI executable. Install PHP and ensure it is on your PATH.\n");
    return (eq(lang, "python") || eq(lang, "javascript") || eq(lang, "ruby") || eq(lang, "typescript")) ? 127 : 1;
}

static int run_lang(const char *lang, const char *code, const char *file) {
    lang = canon_lang(lang ? lang : "python");
    if (!known_lang(lang)) {
        fprintf(stderr, "Error: Unknown language '%s'. Available languages: %s\n", lang, langs);
        return 1;
    }
    if (eq(lang, "bash")) {
        if (code) return run_exec3("/usr/bin/bash", "-c", code);
        if (file) return run_exec3("/usr/bin/bash", file, NULL);
        return run_exec3("/usr/bin/bash", NULL, NULL);
    }
    if (eq(lang, "perl")) {
        if (code) return run_exec3("perl", "-e", code);
        if (file) return run_exec3("perl", file, NULL);
        return run_exec3("perl", NULL, NULL);
    }
    if (eq(lang, "c") || eq(lang, "cpp")) {
        char *buf = NULL;
        const char *body = code;
        bool from_file = false;
        if (!body && file) {
            buf = read_file(file);
            if (!buf) {
                fprintf(stderr, "%s: %s\n", file, strerror(errno));
                return 1;
            }
            body = buf;
            from_file = true;
        }
        if (!body) body = "";
        int rc = compile_and_run(lang, body, from_file);
        free(buf);
        return rc;
    }
    return unavailable(lang);
}

int main(int argc, char **argv) {
    const char *lang = NULL, *code = NULL, *file = NULL;
    char *joined_code = NULL;
    bool no_detect = false;
    const char *pos[16];
    int npos = 0;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (eq(a, "--help") || eq(a, "-h")) { help(); return 0; }
        if (eq(a, "--version") || eq(a, "-V")) { version(); return 0; }
        if (eq(a, "--no-detect")) { no_detect = true; continue; }
        if (eq(a, "--lang") || eq(a, "-l")) {
            if (++i >= argc) { parse_error_missing(eq(a, "-l") ? "-l <LANG>" : "--lang <LANG>"); return 2; }
            lang = argv[i]; continue;
        }
        if (eq(a, "--file") || eq(a, "-f")) {
            if (++i >= argc) { parse_error_missing(eq(a, "-f") ? "-f <PATH>" : "--file <PATH>"); return 2; }
            file = argv[i]; continue;
        }
        if (eq(a, "--code") || eq(a, "-c")) {
            if (++i >= argc) { parse_error_missing(eq(a, "-c") ? "-c <CODE>" : "--code <CODE>"); return 2; }
            code = argv[i]; continue;
        }
        if (a[0] == '-') { parse_error_unexpected(a, lang != NULL); return 2; }
        if (npos < 16) pos[npos++] = a;
    }
    if (!lang && npos > 0 && known_lang(pos[0])) {
        lang = pos[0];
        if (!code && npos > 1) {
            joined_code = join_pos(pos, 1, npos);
            code = joined_code;
        }
    } else if (!file && npos > 0) {
        file = pos[0];
    }
    if (!lang && file && !no_detect) lang = lang_from_path(file);
    if (!lang) lang = "python";
    int rc = run_lang(lang, code, file);
    free(joined_code);
    return rc;
}
