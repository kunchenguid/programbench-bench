#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    const char *name;
    const char *label;
    const char *pattern;
    int flag;
    regex_t re;
} Extractor;

enum {
    F_EMAIL = 1 << 0, F_PHONE = 1 << 1, F_HASH = 1 << 2, F_IP = 1 << 3,
    F_IPV6 = 1 << 4, F_MAC = 1 << 5, F_CC = 1 << 6, F_URL = 1 << 7,
    F_FILES = 1 << 8, F_BTC = 1 << 9, F_AWS = 1 << 10, F_GOOGLE = 1 << 11,
    F_DNS = 1 << 12, F_SOCIAL = 1 << 13
};

static Extractor extractors[] = {
    {"phone_number", "phone_number", "[0-9]{3}-[0-9]{3}-[0-9]{4}", F_PHONE},
    {"email", "email", "[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}", F_EMAIL},
    {"url", "url", "(https?|ftp)://[^][[:space:]<>\")(']+", F_URL},
    {"ip_address", "ip_address", "([0-9]{1,3}\\.){3}[0-9]{1,3}", F_IP},
    {"ipv6_address", "ipv6_address", "(([0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{0,4}|::1)", F_IPV6},
    {"mac_address", "mac_address", "([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}", F_MAC},
    {"credit_card", "credit_card", "[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}", F_CC},
    {"hashes", "hashes", "(\\$2[abxy]\\$[0-9]{2}\\$[./A-Za-z0-9]{53}|[A-Fa-f0-9]{128}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{32})", F_HASH},
    {"files", "files", "[A-Za-z0-9_.+%\\-]+\\.(txt|csv|json|xml|html?|php|asp|aspx|jsp|js|css|png|jpe?g|gif|svg|pdf|docx?|xlsx?|pptx?|zip|tar|gz|tgz|rar|7z|exe|dll|so|dylib|log|bak|conf|cfg|ini|yaml|yml|db|sqlite|sql|py|rb|go|rs|c|h|cpp|java|sh)", F_FILES},
    {"bitcoin_wallet", "bitcoin_wallet", "([13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[ac-hj-np-z02-9]{20,90})", F_BTC},
    {"aws", "aws", "(A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}", F_AWS},
    {"google", "google", "[A-Fa-f0-9]{40}", F_GOOGLE},
    {"dns", "dns", "([A-Za-z0-9]([A-Za-z0-9\\-]{0,61}[A-Za-z0-9])?\\.)+[A-Za-z]{2,63}", F_DNS},
    {"social_security", "social_security", "[0-9]{3}-[0-9]{2}-[0-9]{4}", F_SOCIAL},
};

typedef struct {
    char *file;
    char *directory;
    char *drop;
    char *filter;
    char *output;
    bool clean, line, thorough, display, suppress, hide, timeit;
    bool list, help, version;
    char *add, *update, *remove;
    int flags;
    regex_t drop_re, filter_re;
    bool has_drop, has_filter;
    FILE *out;
    int exit_status;
} Opts;

static const char *plugin_path(void) {
    const char *home = getenv("HOME");
    static char buf[1024];
    snprintf(buf, sizeof(buf), "%s/.DataSurgeon/plugins.json", home ? home : "/home/agent");
    return buf;
}

static void plugin_error(void) {
    printf("Failed to open plugins.json file. PLUGIN_PATH: %s\n", plugin_path());
}

static void usage(void) {
    puts("Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.\n");
    puts("Usage: executable [OPTIONS]\n");
    puts("Options:");
    puts("  -f, --file <file>            File to extract information from [default: \"\"]");
    puts("      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: \"\"]");
    puts("      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: \"\"]");
    puts("      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: \"\"]");
    puts("      --list                   List all added plugins");
    puts("  -C, --clean                  Only displays the matched result, rather than the entire line");
    puts("      --directory <directory>  Process all files found in the specified directory [default: \"\"]");
    puts("      --ignore                 Silences error messages");
    puts("  -l, --line                   Displays the line number where the match occurred");
    puts("  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line");
    puts("  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)");
    puts("  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file");
    puts("      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop \"^.{1,10}$\" will hide all matches not under 10 characters) [default: \"\"]");
    puts("      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: \"\"]");
    puts("  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.");
    puts("  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: \"\"]");
    puts("  -t, --time                   Time how long the operation took");
    puts("  -e, --email                  Extract email addresses");
    puts("  -p, --phone                  Extracts phone numbers");
    puts("  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)");
    puts("  -i, --ip-addr                Extract IP addresses");
    puts("  -6, --ipv6-addr              Extract IPv6 addresses");
    puts("  -m, --mac-addr               Extract MAC addresses");
    puts("  -c, --credit-card            Extract credit card numbers");
    puts("  -u, --url                    Extract urls");
    puts("  -F, --files                  Extract filenames");
    puts("  -b, --bitcoin                Extract bitcoin wallets");
    puts("  -a, --aws                    Extract AWS keys");
    puts("  -g, --google                 Extract Google service account private key ids (used for google automations services)");
    puts("  -d, --dns                    Extract Domain Name System records");
    puts("  -s, --social                 Extract social security numbers");
    puts("  -h, --help                   Print help");
    puts("  -V, --version                Print version");
}

static char *slice_dup(const char *s, size_t n) {
    char *r = malloc(n + 1);
    if (!r) exit(1);
    memcpy(r, s, n);
    r[n] = 0;
    return r;
}

static void trim_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0;
}

static bool re_matches(regex_t *re, const char *s) {
    return regexec(re, s, 0, NULL, 0) == 0;
}

static void emit(Opts *o, const char *type, const char *data, const char *path, long line) {
    if (o->has_drop && re_matches(&o->drop_re, data)) return;
    FILE *fp = o->out ? o->out : stdout;
    if (o->out) {
        fprintf(fp, "%s, %s\n", type, data);
        return;
    }
    if (o->hide) {
        fprintf(fp, "%s", data);
        if (o->line) fprintf(fp, ", line: %ld", line);
        fputc('\n', fp);
        return;
    }
    if (o->display && path && o->line)
        fprintf(fp, "%s, file: %s %s, line: %ld\n", type, path, data, line);
    else if (o->display && path)
        fprintf(fp, "%s, file: %s %s\n", type, path, data);
    else if (o->line)
        fprintf(fp, "%s, %s, line: %ld\n", type, data, line);
    else
        fprintf(fp, "%s: %s\n", type, data);
}

static void process_line(Opts *o, const char *line_text, const char *path, long line_no) {
    if (o->has_filter && !re_matches(&o->filter_re, line_text)) return;
    int active = o->flags ? o->flags : (F_EMAIL | F_PHONE | F_HASH | F_IP | F_IPV6 | F_MAC | F_CC | F_URL | F_FILES | F_BTC | F_AWS | F_GOOGLE | F_DNS | F_SOCIAL);
    for (size_t i = 0; i < sizeof(extractors) / sizeof(extractors[0]); i++) {
        Extractor *ex = &extractors[i];
        if (!(active & ex->flag)) continue;
        const char *cursor = line_text;
        int eflags = 0;
        while (1) {
            regmatch_t m;
            if (regexec(&ex->re, cursor, 1, &m, eflags) != 0) break;
            if (m.rm_so < 0 || m.rm_eo <= m.rm_so) break;
            if (ex->flag == F_FILES && isalnum((unsigned char)cursor[m.rm_eo])) {
                cursor += m.rm_so + 1;
                eflags = REG_NOTBOL;
                continue;
            }
            char *match = slice_dup(cursor + m.rm_so, (size_t)(m.rm_eo - m.rm_so));
            if (ex->flag == F_FILES) {
                char *slash = strrchr(match, '/');
                if (slash) memmove(match, slash + 1, strlen(slash));
            }
            emit(o, ex->label, o->clean ? match : line_text, path, line_no);
            free(match);
            if (!o->thorough) return;
            cursor += m.rm_eo;
            if (*cursor == 0) break;
            eflags = REG_NOTBOL;
        }
    }
}

static void process_stream(Opts *o, FILE *fp, const char *path) {
    char *line = NULL;
    size_t cap = 0;
    long n = 0;
    while (getline(&line, &cap, fp) != -1) {
        n++;
        trim_newline(line);
        process_line(o, line, path, n);
    }
    free(line);
}

static void process_file(Opts *o, const char *path) {
    FILE *fp = fopen(path, "r");
    if (!fp) {
        printf("[-] File not found: %s\n", path);
        o->exit_status = 1;
        return;
    }
    process_stream(o, fp, path);
    fclose(fp);
}

static void process_dir(Opts *o, const char *path) {
    DIR *dir = opendir(path);
    if (!dir) return;
    struct dirent *de;
    while ((de = readdir(dir))) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
        char *child;
        if (asprintf(&child, "%s/%s", path, de->d_name) < 0) exit(1);
        struct stat st;
        if (stat(child, &st) == 0) {
            if (S_ISDIR(st.st_mode)) process_dir(o, child);
            else if (S_ISREG(st.st_mode)) process_file(o, child);
        }
        free(child);
    }
    closedir(dir);
}

static void compile_regexes(Opts *o) {
    for (size_t i = 0; i < sizeof(extractors) / sizeof(extractors[0]); i++) {
        if (regcomp(&extractors[i].re, extractors[i].pattern, REG_EXTENDED | REG_ICASE) != 0) exit(1);
    }
    if (o->drop && *o->drop) {
        o->has_drop = regcomp(&o->drop_re, o->drop, REG_EXTENDED | REG_NOSUB) == 0;
    }
    if (o->filter && *o->filter) {
        o->has_filter = regcomp(&o->filter_re, o->filter, REG_EXTENDED | REG_NOSUB) == 0;
    }
}

static void parse_args(int argc, char **argv, Opts *o) {
    static struct option longs[] = {
        {"file", required_argument, 0, 'f'}, {"add", required_argument, 0, 1000},
        {"update", required_argument, 0, 1001}, {"remove", required_argument, 0, 1002},
        {"list", no_argument, 0, 1003}, {"clean", no_argument, 0, 'C'},
        {"directory", required_argument, 0, 1004}, {"ignore", no_argument, 0, 1005},
        {"line", no_argument, 0, 'l'}, {"thorough", no_argument, 0, 'T'},
        {"display", no_argument, 0, 'D'}, {"suppress", no_argument, 0, 'S'},
        {"drop", required_argument, 0, 1006}, {"filter", required_argument, 0, 1007},
        {"hide", no_argument, 0, 'X'}, {"output", required_argument, 0, 'o'},
        {"time", no_argument, 0, 't'}, {"email", no_argument, 0, 'e'},
        {"phone", no_argument, 0, 'p'}, {"hash", no_argument, 0, 'H'},
        {"ip-addr", no_argument, 0, 'i'}, {"ipv6-addr", no_argument, 0, '6'},
        {"mac-addr", no_argument, 0, 'm'}, {"credit-card", no_argument, 0, 'c'},
        {"url", no_argument, 0, 'u'}, {"files", no_argument, 0, 'F'},
        {"bitcoin", no_argument, 0, 'b'}, {"aws", no_argument, 0, 'a'},
        {"google", no_argument, 0, 'g'}, {"dns", no_argument, 0, 'd'},
        {"social", no_argument, 0, 's'}, {"help", no_argument, 0, 'h'},
        {"version", no_argument, 0, 'V'}, {0, 0, 0, 0}
    };
    int c;
    while ((c = getopt_long(argc, argv, "f:ClTDSXo:tepHi6mcuFbagdshV", longs, NULL)) != -1) {
        switch (c) {
            case 'f': o->file = optarg; break;
            case 'C': o->clean = true; break;
            case 'l': o->line = true; break;
            case 'T': o->thorough = true; break;
            case 'D': o->display = true; break;
            case 'S': o->suppress = true; break;
            case 'X': o->hide = true; break;
            case 'o': o->output = optarg; break;
            case 't': o->timeit = true; break;
            case 'e': o->flags |= F_EMAIL; break;
            case 'p': o->flags |= F_PHONE; break;
            case 'H': o->flags |= F_HASH; break;
            case 'i': o->flags |= F_IP; break;
            case '6': o->flags |= F_IPV6; break;
            case 'm': o->flags |= F_MAC; break;
            case 'c': o->flags |= F_CC; break;
            case 'u': o->flags |= F_URL; break;
            case 'F': o->flags |= F_FILES; break;
            case 'b': o->flags |= F_BTC; break;
            case 'a': o->flags |= F_AWS; break;
            case 'g': o->flags |= F_GOOGLE; break;
            case 'd': o->flags |= F_DNS; break;
            case 's': o->flags |= F_SOCIAL; break;
            case 'h': o->help = true; break;
            case 'V': o->version = true; break;
            case 1000: o->add = optarg; break;
            case 1001: o->update = optarg; break;
            case 1002: o->remove = optarg; break;
            case 1003: o->list = true; break;
            case 1004: o->directory = optarg; break;
            case 1005: break;
            case 1006: o->drop = optarg; break;
            case 1007: o->filter = optarg; break;
            default:
                printf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", argv[optind - 1]);
                exit(2);
        }
    }
}

int main(int argc, char **argv) {
    Opts o;
    memset(&o, 0, sizeof(o));
    parse_args(argc, argv, &o);
    plugin_error();
    if (o.help) {
        usage();
        return 0;
    }
    if (o.version) {
        puts("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8");
        return 0;
    }
    if (o.list) {
        plugin_error();
        printf("No plugins found. Plugin File: %s\n", plugin_path());
        return 1;
    }
    if (o.add) {
        puts("[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base");
        return 1;
    }
    if (o.update || o.remove) {
        plugin_error();
        return 1;
    }

    compile_regexes(&o);
    clock_t start = clock();
    if (o.output && *o.output) {
        o.out = fopen(o.output, "w");
        if (!o.out) {
            perror(o.output);
            return 1;
        }
        fputs("content_type, data\n", o.out);
    }
    if (o.directory && *o.directory) {
        process_dir(&o, o.directory);
    } else if (o.file && *o.file) {
        process_file(&o, o.file);
    } else {
        if (!o.suppress) puts("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)");
        process_stream(&o, stdin, NULL);
    }
    if (o.out) fclose(o.out);
    if (o.timeit) {
        double sec = (double)(clock() - start) / CLOCKS_PER_SEC;
        int isec = (int)(sec + 0.5);
        printf("[*] Time elapsed: %02dh:%02dm:%02ds\n", isec / 3600, (isec / 60) % 60, isec % 60);
    }
    return o.exit_status;
}
