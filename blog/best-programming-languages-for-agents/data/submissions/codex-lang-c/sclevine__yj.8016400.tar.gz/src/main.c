#define _GNU_SOURCE
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { V_NULL, V_BOOL, V_NUM, V_STR, V_ARR, V_OBJ } Type;
typedef struct Val Val;
typedef struct { char *key; Val *val; } Pair;
struct Val {
    Type t;
    int b;
    double num;
    char *s;
    Val **items;
    int len, cap;
    Pair *pairs;
    int plen, pcap;
};

static Val *val(Type t){ Val *v=calloc(1,sizeof(Val)); v->t=t; return v; }
static char *xstrndup(const char *s,size_t n){ char *r=malloc(n+1); memcpy(r,s,n); r[n]=0; return r; }
static Val *vstr(const char*s){ Val*v=val(V_STR); v->s=strdup(s?s:""); return v; }
static Val *vnum(double d){ Val*v=val(V_NUM); v->num=d; return v; }
static Val *vbool(int b){ Val*v=val(V_BOOL); v->b=b; return v; }
static void arr_add(Val*a,Val*x){ if(a->len==a->cap){a->cap=a->cap?a->cap*2:8; a->items=realloc(a->items,a->cap*sizeof(Val*));} a->items[a->len++]=x; }
static Pair *obj_pair(Val*o,const char*k){ for(int i=0;i<o->plen;i++) if(!strcmp(o->pairs[i].key,k)) return &o->pairs[i]; return NULL; }
static void obj_set(Val*o,const char*k,Val*x){ Pair*p=obj_pair(o,k); if(p){p->val=x;return;} if(o->plen==o->pcap){o->pcap=o->pcap?o->pcap*2:8; o->pairs=realloc(o->pairs,o->pcap*sizeof(Pair));} o->pairs[o->plen].key=strdup(k); o->pairs[o->plen].val=x; o->plen++; }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char*e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static char *read_all(void){ size_t cap=8192,len=0; char*b=malloc(cap+1); int c; while((c=getchar())!=EOF){ if(len+1>=cap){cap*=2;b=realloc(b,cap+1);} b[len++]=(char)c;} b[len]=0; return b; }

typedef struct { const char *p; } Parser;
static void ws(Parser*x){ while(isspace((unsigned char)*x->p)) x->p++; }
static Val *parse_json_val(Parser*x);
static char *parse_jstr(Parser*x){
    if(*x->p!='"') return strdup("");
    x->p++; size_t cap=32,len=0; char*out=malloc(cap);
    while(*x->p && *x->p!='"'){
        unsigned char c=*x->p++;
        if(c=='\\'){
            c=*x->p++;
            if(c=='n') c='\n'; else if(c=='r') c='\r'; else if(c=='t') c='\t'; else if(c=='b') c='\b'; else if(c=='f') c='\f';
            else if(c=='u'){ int code=0; for(int i=0;i<4&&isxdigit((unsigned char)*x->p);i++){ char h=*x->p++; code=code*16+(isdigit(h)?h-'0':tolower(h)-'a'+10);} c=(code<128)?code:'?'; }
        }
        if(len+2>=cap){cap*=2;out=realloc(out,cap);}
        out[len++]=c;
    }
    if(*x->p=='"') x->p++;
    out[len]=0; return out;
}
static Val *parse_json_arr(Parser*x){ Val*a=val(V_ARR); x->p++; ws(x); if(*x->p==']'){x->p++;return a;} for(;;){ arr_add(a,parse_json_val(x)); ws(x); if(*x->p==','){x->p++;continue;} if(*x->p==']')x->p++; return a; } }
static Val *parse_json_obj(Parser*x){ Val*o=val(V_OBJ); x->p++; ws(x); if(*x->p=='}'){x->p++;return o;} for(;;){ ws(x); char*k=parse_jstr(x); ws(x); if(*x->p==':')x->p++; Val*v=parse_json_val(x); obj_set(o,k,v); free(k); ws(x); if(*x->p==','){x->p++;continue;} if(*x->p=='}')x->p++; return o; } }
static Val *parse_json_val(Parser*x){
    ws(x);
    if(*x->p=='"'){ char*s=parse_jstr(x); Val*v=vstr(s); free(s); return v; }
    if(*x->p=='{') return parse_json_obj(x);
    if(*x->p=='[') return parse_json_arr(x);
    if(!strncmp(x->p,"true",4)){x->p+=4;return vbool(1);}
    if(!strncmp(x->p,"false",5)){x->p+=5;return vbool(0);}
    if(!strncmp(x->p,"null",4)){x->p+=4;return val(V_NULL);}
    char *end; double d=strtod(x->p,&end); if(end!=x->p){x->p=end;return vnum(d);}
    return val(V_NULL);
}
static Val *parse_json(const char*s){ Parser p={s}; return parse_json_val(&p); }

static int is_numlike(const char*s){ if(!*s) return 0; char*e; strtod(s,&e); return *trim(e)==0; }
static Val *parse_scalar(char *s){
    s=trim(s); size_t n=strlen(s);
    if(!strcmp(s,"null")||!strcmp(s,"~")) return val(V_NULL);
    if(!strcmp(s,"true")) return vbool(1);
    if(!strcmp(s,"false")) return vbool(0);
    if((s[0]=='"'&&s[n-1]=='"')||(s[0]=='\''&&s[n-1]=='\'')){ char q=s[0]; (void)q; char *t=xstrndup(s+1,n-2); Val*v=vstr(t); free(t); return v; }
    if(s[0]=='['||s[0]=='{') return parse_json(s);
    if(is_numlike(s)) return vnum(strtod(s,NULL));
    return vstr(s);
}

typedef struct { char **l; int n; } Lines;
static int indentof(const char*s){ int n=0; while(*s==' '){n++;s++;} return n; }
static Val *parse_yaml_block(Lines*ls,int*idx,int ind);
static Val *parse_yaml_block(Lines*ls,int*idx,int ind){
    while(*idx<ls->n && !*trim(ls->l[*idx])) (*idx)++;
    if(*idx>=ls->n) return val(V_NULL);
    char *line=ls->l[*idx];
    if(indentof(line)>ind) ind=indentof(line);
    char *first=trim(line);
    if(first[0]!='-' && !strchr(first,':')) { (*idx)++; return parse_scalar(first); }
    int list = indentof(line)==ind && first[0]=='-' && (first[1]==' '||first[1]==0);
    if(list){
        Val*a=val(V_ARR);
        while(*idx<ls->n && indentof(ls->l[*idx])==ind && trim(ls->l[*idx])[0]=='-'){
            char *t=trim(ls->l[*idx])+1; t=trim(t); (*idx)++;
            if(!*t) arr_add(a,parse_yaml_block(ls,idx,ind+1));
            else arr_add(a,parse_scalar(t));
        }
        return a;
    }
    Val*o=val(V_OBJ);
    while(*idx<ls->n && indentof(ls->l[*idx])==ind){
        char *t=trim(ls->l[*idx]); if(!*t||*t=='#'){(*idx)++;continue;}
        char *c=strchr(t,':'); if(!c) break; *c=0; char *k=trim(t), *r=trim(c+1); (*idx)++;
        if((k[0]=='"'&&k[strlen(k)-1]=='"')||(k[0]=='\''&&k[strlen(k)-1]=='\'')){ k[strlen(k)-1]=0; k++; }
        obj_set(o,k,*r?parse_scalar(r):parse_yaml_block(ls,idx,ind+1));
    }
    return o;
}
static Val *parse_yaml(char *s){
    Lines ls={0}; char *save,*line=strtok_r(s,"\n",&save);
    while(line){ char *hash=strchr(line,'#'); if(hash && (hash==line||hash[-1]==' ')) *hash=0; ls.l=realloc(ls.l,(ls.n+1)*sizeof(char*)); ls.l[ls.n++]=line; line=strtok_r(NULL,"\n",&save); }
    int i=0; return parse_yaml_block(&ls,&i,0);
}

static Val *parse_toml(char *s){
    Val*root=val(V_OBJ), *cur=root; char *save,*line=strtok_r(s,"\n",&save);
    while(line){ char*t=trim(line); if(!*t||*t=='#'){line=strtok_r(NULL,"\n",&save);continue;}
        if(*t=='['){ char *e=strchr(t,']'); if(e){*e=0; cur=root; char *path=trim(t+1), *sv, *part=strtok_r(path,".",&sv); while(part){ Pair*p=obj_pair(cur,trim(part)); if(!p||p->val->t!=V_OBJ){ Val*no=val(V_OBJ); obj_set(cur,trim(part),no); cur=no; } else cur=p->val; part=strtok_r(NULL,".",&sv); } } }
        else { char *eq=strchr(t,'='); if(eq){*eq=0; char *key=trim(t), *sv, *part=strtok_r(key,".",&sv); Val *target=cur; char *last=part; while(part){ last=part; part=strtok_r(NULL,".",&sv); if(part){ Pair*p=obj_pair(target,trim(last)); if(!p||p->val->t!=V_OBJ){ Val*no=val(V_OBJ); obj_set(target,trim(last),no); target=no; } else target=p->val; } } obj_set(target,trim(last),parse_scalar(trim(eq+1)));} }
        line=strtok_r(NULL,"\n",&save);
    }
    return root;
}
static Val *parse_hcl(char *s){
    Val*root=val(V_OBJ); Val*stack[64]; char*names[64]; int sp=0; stack[0]=root; char *save,*line=strtok_r(s,"\n",&save);
    while(line){ char*t=trim(line); if(!*t||*t=='#'){line=strtok_r(NULL,"\n",&save);continue;} size_t n=strlen(t);
        if(n&&t[n-1]=='{'){ t[n-1]=0; Val*o=val(V_OBJ); obj_set(stack[sp],trim(t),o); stack[++sp]=o; }
        else if(!strcmp(t,"}")){ if(sp>0) sp--; }
        else { char *eq=strchr(t,'='); if(eq){*eq=0; obj_set(stack[sp],trim(t),parse_scalar(trim(eq+1)));} }
        (void)names; line=strtok_r(NULL,"\n",&save);
    }
    return root;
}

static void pr_indent(int n){ while(n--) putchar(' '); }
static void print_json_str(const char*s,int html){
    putchar('"'); for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\') printf("\\%c",c); else if(c=='\n') printf("\\n"); else if(c=='\r') printf("\\r"); else if(c=='\t') printf("\\t"); else if(html&&(c=='<'||c=='>'||c=='&')) printf("\\u%04x",c); else putchar(c);} putchar('"');
}
static void emit_json(Val*v,int pretty,int html,int ind){
    switch(v->t){
    case V_NULL: printf("null"); break; case V_BOOL: printf(v->b?"true":"false"); break; case V_NUM: { char b[64]; snprintf(b,sizeof b,"%.15g",v->num); printf("%s",b); break; } case V_STR: print_json_str(v->s,html); break;
    case V_ARR: putchar('['); for(int i=0;i<v->len;i++){ if(i) putchar(','); if(pretty){putchar('\n');pr_indent(ind+2);} emit_json(v->items[i],pretty,html,ind+2);} if(pretty&&v->len){putchar('\n');pr_indent(ind);} putchar(']'); break;
    case V_OBJ: putchar('{'); for(int i=0;i<v->plen;i++){ if(i) putchar(','); if(pretty){putchar('\n');pr_indent(ind+2);} print_json_str(v->pairs[i].key,html); putchar(':'); if(pretty) putchar(' '); emit_json(v->pairs[i].val,pretty,html,ind+2);} if(pretty&&v->plen){putchar('\n');pr_indent(ind);} putchar('}'); break;
    }
}
static int scalarish(Val*v){ return v->t!=V_ARR && v->t!=V_OBJ; }
static void emit_yaml_scalar(Val*v){ switch(v->t){case V_NULL:printf("null");break;case V_BOOL:printf(v->b?"true":"false");break;case V_NUM:printf("%.15g",v->num);break;case V_STR:printf("%s",v->s);break;default:break;} }
static void emit_yaml(Val*v,int ind){
    if(v->t==V_OBJ){ for(int i=0;i<v->plen;i++){ pr_indent(ind); printf("%s:",v->pairs[i].key); if(scalarish(v->pairs[i].val)){ putchar(' '); emit_yaml_scalar(v->pairs[i].val); putchar('\n'); } else { putchar('\n'); emit_yaml(v->pairs[i].val,ind+2); } } }
    else if(v->t==V_ARR){ for(int i=0;i<v->len;i++){ pr_indent(ind); printf("-"); if(scalarish(v->items[i])){ putchar(' '); emit_yaml_scalar(v->items[i]); putchar('\n'); } else { putchar('\n'); emit_yaml(v->items[i],ind+2); } } }
    else { emit_yaml_scalar(v); putchar('\n'); }
}
static void emit_toml_val(Val*v){ if(v->t==V_STR) print_json_str(v->s,0); else if(v->t==V_BOOL) printf(v->b?"true":"false"); else if(v->t==V_NUM) printf("%.15g",v->num); else if(v->t==V_ARR){ putchar('['); for(int i=0;i<v->len;i++){ if(i)printf(", "); emit_toml_val(v->items[i]); } putchar(']'); } else if(v->t==V_NULL) printf("\"\""); }
static void emit_toml_obj(Val*o,const char*prefix,int ind){
    for(int i=0;i<o->plen;i++) if(o->pairs[i].val->t!=V_OBJ){ pr_indent(ind); printf("%s = ",o->pairs[i].key); emit_toml_val(o->pairs[i].val); putchar('\n'); }
    for(int i=0;i<o->plen;i++) if(o->pairs[i].val->t==V_OBJ){ printf("\n[%s%s%s]\n",prefix&&*prefix?prefix:"",prefix&&*prefix?".":"",o->pairs[i].key); emit_toml_obj(o->pairs[i].val,o->pairs[i].key,ind); }
}
static void emit_hcl_val(Val*v,int ind){
    if(v->t==V_OBJ){ printf("{\n"); for(int i=0;i<v->plen;i++){ pr_indent(ind+2); print_json_str(v->pairs[i].key,0); printf(" = "); emit_hcl_val(v->pairs[i].val,ind+2); printf("\n"); } pr_indent(ind); printf("}"); }
    else if(v->t==V_ARR){ putchar('['); for(int i=0;i<v->len;i++){ if(i)printf(", "); emit_hcl_val(v->items[i],ind); } putchar(']'); }
    else emit_toml_val(v);
}
static void emit_hcl(Val*o){ if(o->t==V_OBJ){ for(int i=0;i<o->plen;i++){ print_json_str(o->pairs[i].key,0); printf(" = "); emit_hcl_val(o->pairs[i].val,0); if(i+1<o->plen) printf("\n\n"); } } else emit_hcl_val(o,0); }

static void help(const char*argv0){
printf("Usage: %s [-][ytjcrneikhv]\n\nConvert between YAML, TOML, JSON, and HCL.\nPreserves map order.\n\n-x[x]  Convert using stdin. Valid options:\n          -yj, -y = YAML to JSON (default)\n          -yy     = YAML to YAML\n          -yt     = YAML to TOML\n          -yc     = YAML to HCL\n          -tj, -t = TOML to JSON\n          -ty     = TOML to YAML\n          -tt     = TOML to TOML\n          -tc     = TOML to HCL\n          -jj     = JSON to JSON\n          -jy, -r = JSON to YAML\n          -jt     = JSON to TOML\n          -jc     = JSON to HCL\n          -cy     = HCL to YAML\n          -ct     = HCL to TOML\n          -cj, -c = HCL to JSON\n          -cc     = HCL to HCL\n-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)\n-e     Escape HTML (JSON out only)\n-i     Indent output (JSON or TOML out only)\n-k     Attempt to parse keys as objects or numeric types (YAML out only)\n-h     Show this help message\n-v     Show version\n",argv0);
}
int main(int argc,char**argv){
    char in='y',out='j'; int pretty=0,html=0,showh=0,showv=0; const char*flags=argc>1?argv[1]:"-yj";
    if(argc>1 && flags[0]=='-'){ for(int i=1;flags[i];i++){ char c=flags[i]; if(c=='h')showh=1; else if(c=='v')showv=1; else if(c=='i')pretty=1; else if(c=='e')html=1; else if(c=='r'){in='j';out='y';} else if(c=='y'||c=='t'||c=='j'||c=='c'){ if(in=='y'&&out=='j'&&i==1){in=c; out=(flags[i+1]&&strchr("ytjc",flags[i+1]))?flags[++i]:(c=='y'?'j':c=='t'?'j':c=='j'?'j':'j');} else out=c; } } }
    if(showv){ puts("v0.0.0"); return 0; } if(showh){ help(argv[0]); return 0; }
    char *buf=read_all(); if(!*buf){ free(buf); return 0; }
    Val *root = in=='j'?parse_json(buf):in=='t'?parse_toml(buf):in=='c'?parse_hcl(buf):parse_yaml(buf);
    if(out=='j') emit_json(root,pretty,html,0);
    else if(out=='y') emit_yaml(root,0);
    else if(out=='t') emit_toml_obj(root,"",pretty?2:0);
    else if(out=='c') emit_hcl(root);
    return 0;
}
