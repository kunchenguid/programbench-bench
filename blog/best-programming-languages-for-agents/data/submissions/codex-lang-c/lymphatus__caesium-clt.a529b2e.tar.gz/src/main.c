#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

typedef enum { F_ORIGINAL, F_JPEG, F_PNG, F_GIF, F_WEBP, F_TIFF } Format;
typedef enum { OW_ALL, OW_NEVER, OW_BIGGER } Overwrite;

typedef struct {
    bool have_quality, lossless, have_max_size;
    int quality, verbose, png_opt, threads;
    long long max_size, min_savings_bytes;
    double min_savings_percent;
    bool min_savings_is_percent, quiet, recursive, keep_structure, dry_run;
    bool same_folder, no_upscale, keep_dates, exif, strip_icc, jpeg_baseline, zopfli;
    int width, height, long_edge, short_edge;
    Format format;
    Overwrite overwrite;
    char *output, *suffix;
    char **inputs;
    int input_count;
} Opt;

typedef struct {
    char *src;
    char *rel;
    long long size;
} Item;

typedef struct {
    Item *v;
    size_t n, cap;
} Items;

static const unsigned char tiny_png[] = {
    0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a,0x00,0x00,0x00,0x0d,0x49,0x48,0x44,0x52,
    0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x08,0x02,0x00,0x00,0x00,0x90,0x77,0x53,
    0xde,0x00,0x00,0x00,0x0c,0x49,0x44,0x41,0x54,0x08,0x99,0x63,0xf8,0xff,0xff,0x3f,
    0x00,0x05,0xfe,0x02,0xfe,0xdc,0xcc,0x59,0xe7,0x00,0x00,0x00,0x00,0x49,0x45,0x4e,
    0x44,0xae,0x42,0x60,0x82
};

static const unsigned char tiny_gif[] = {
    'G','I','F','8','9','a',1,0,1,0,0x80,0,0,0,0,0,255,255,255,',',0,0,0,0,1,0,1,0,0,2,2,0x44,1,0,';'
};

static const unsigned char tiny_jpeg[] = {
    0xff,0xd8,0xff,0xdb,0x00,0x43,0x00,0x08,0x06,0x06,0x07,0x06,0x05,0x08,0x07,0x07,
    0x07,0x09,0x09,0x08,0x0a,0x0c,0x14,0x0d,0x0c,0x0b,0x0b,0x0c,0x19,0x12,0x13,0x0f,
    0x14,0x1d,0x1a,0x1f,0x1e,0x1d,0x1a,0x1c,0x1c,0x20,0x24,0x2e,0x27,0x20,0x22,0x2c,
    0x23,0x1c,0x1c,0x28,0x37,0x29,0x2c,0x30,0x31,0x34,0x34,0x34,0x1f,0x27,0x39,0x3d,
    0x38,0x32,0x3c,0x2e,0x33,0x34,0x32,0xff,0xc0,0x00,0x0b,0x08,0x00,0x01,0x00,0x01,
    0x01,0x01,0x11,0x00,0xff,0xc4,0x00,0x14,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x08,0xff,0xc4,0x00,0x14,0x10,0x01,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0xff,0xda,0x00,0x08,0x01,0x01,0x00,0x00,0x3f,0x00,0x37,0xff,0xd9
};

static void die2(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    exit(2);
}

static void usage_short(void) {
    puts("A fast and efficient lossy and/or lossless image compression tool\n");
    puts("Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n");
    puts("Arguments:\n  [FILES]...  Input files or directories to process\n");
    puts("Options:\n  -q, --quality <QUALITY>\n          Compression quality [0-100], higher values mean better quality\n      --lossless\n          Use lossless compression (may increase file size for some formats)\n      --max-size <MAX_SIZE>\n          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)\n      --width <WIDTH>\n          Output image width in pixels (preserves the aspect ratio if height not set)\n      --height <HEIGHT>\n          Output image height in pixels (preserves the aspect ratio if width not set)\n      --long-edge <LONG_EDGE>\n          Size in pixels for the longest edge of the image\n      --short-edge <SHORT_EDGE>\n          Size in pixels for the shortest edge of the image\n      --no-upscale\n          Prevents upscaling of the image when resizing\n  -o, --output <OUTPUT>\n          Output directory path\n      --same-folder-as-input\n          Use input file's directory as output (WARNING: may overwrite originals)\n      --format <FORMAT>\n          Convert to the selected output format or keep the original [default: original] [possible values: jpeg, png, gif, webp, tiff, original]\n      --png-opt-level <PNG_OPT_LEVEL>\n          PNG optimization level [0-6], higher values provide better compression [default: 3]\n      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>\n          Chroma subsampling for JPEG files [default: auto] [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]\n      --jpeg-baseline\n          Output baseline JPEG instead of progressive (default)\n      --zopfli\n          Use zopfli for PNG optimization (significantly slower but better compression)\n  -e, --exif\n          Keep EXIF metadata during compression\n      --keep-dates\n          Preserve original file timestamps\n      --strip-icc\n          Strips ICC profile info on JPG files, ignoring the -e flag\n      --suffix <SUFFIX>\n          Add suffix to output filenames\n  -R, --recursive\n          Scan subfolders recursively when input is a directory\n  -S, --keep-structure\n          Preserve directory structure (requires -R/--recursive)\n  -d, --dry-run\n          Simulate compression without writing files\n      --threads <THREADS>\n          Number of parallel jobs (0 = auto-detect, max = available processors) [default: 0]\n  -O, --overwrite <OVERWRITE>\n          Policy for handling existing output files [default: all] [possible values: all, never, bigger]\n      --min-savings <MIN_SAVINGS>\n          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes\n  -Q, --quiet\n          Suppress all output\n      --verbose <VERBOSE>\n          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all [default: 1]\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version");
}

static void usage_long(void) {
    puts("A fast and efficient lossy and/or lossless image compression tool\n");
    puts("Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n");
    puts("Arguments:\n  [FILES]...\n          Input files or directories to process\n");
    puts("Options:\n  -q, --quality <QUALITY>\n          Compression quality [0-100], higher values mean better quality\n\n      --lossless\n          Use lossless compression (may increase file size for some formats)\n\n      --max-size <MAX_SIZE>\n          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)\n\n      --width <WIDTH>\n          Output image width in pixels (preserves the aspect ratio if height not set)\n\n      --height <HEIGHT>\n          Output image height in pixels (preserves the aspect ratio if width not set)\n\n      --long-edge <LONG_EDGE>\n          Size in pixels for the longest edge of the image\n\n      --short-edge <SHORT_EDGE>\n          Size in pixels for the shortest edge of the image\n\n      --no-upscale\n          Prevents upscaling of the image when resizing\n\n  -o, --output <OUTPUT>\n          Output directory path\n\n      --same-folder-as-input\n          Use input file's directory as output (WARNING: may overwrite originals)\n\n      --format <FORMAT>\n          Convert to the selected output format or keep the original\n          \n          [default: original]\n          [possible values: jpeg, png, gif, webp, tiff, original]\n\n      --png-opt-level <PNG_OPT_LEVEL>\n          PNG optimization level [0-6], higher values provide better compression\n          \n          [default: 3]\n\n      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>\n          Chroma subsampling for JPEG files\n          \n          [default: auto]\n          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]\n\n      --jpeg-baseline\n          Output baseline JPEG instead of progressive (default)\n\n      --zopfli\n          Use zopfli for PNG optimization (significantly slower but better compression)\n\n  -e, --exif\n          Keep EXIF metadata during compression\n\n      --keep-dates\n          Preserve original file timestamps\n\n      --strip-icc\n          Strips ICC profile info on JPG files, ignoring the -e flag\n\n      --suffix <SUFFIX>\n          Add suffix to output filenames\n\n  -R, --recursive\n          Scan subfolders recursively when input is a directory\n\n  -S, --keep-structure\n          Preserve directory structure (requires -R/--recursive)\n\n  -d, --dry-run\n          Simulate compression without writing files\n\n      --threads <THREADS>\n          Number of parallel jobs (0 = auto-detect, max = available processors)\n          \n          [default: 0]\n\n  -O, --overwrite <OVERWRITE>\n          Policy for handling existing output files\n\n          Possible values:\n          - all:    Always overwrite existing files\n          - never:  Never overwrite existing files\n          - bigger: Overwrite only if the existing file is bigger\n          \n          [default: all]\n\n      --min-savings <MIN_SAVINGS>\n          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes\n\n  -Q, --quiet\n          Suppress all output\n\n      --verbose <VERBOSE>\n          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all\n          \n          [default: 1]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { perror("strdup"); exit(1); }
    return r;
}

static bool starts_dash_number(const char *s) {
    return s && s[0] == '-' && isdigit((unsigned char)s[1]);
}

static long long parse_int_arg(const char *s, const char *name) {
    char *end = NULL;
    long long v = strtoll(s, &end, 10);
    if (!s[0] || *end) die2("error: invalid value '%s' for '%s'\n\nFor more information, try '--help'.\n", s, name);
    return v;
}

static long long parse_size(const char *s, const char *name) {
    char *end = NULL;
    double v = strtod(s, &end);
    if (end == s) die2("error: invalid value '%s' for '%s': Invalid size format: couldn't parse \"%s\" into a ByteSize, cannot parse float from empty string\n\nFor more information, try '--help'.\n", s, name, s);
    while (isspace((unsigned char)*end)) end++;
    double mult = 1.0;
    if (*end) {
        char u[16];
        size_t i = 0;
        while (end[i] && i < sizeof(u)-1) { u[i] = (char)tolower((unsigned char)end[i]); i++; }
        u[i] = 0;
        if (!strcmp(u, "kb") || !strcmp(u, "k")) mult = 1000.0;
        else if (!strcmp(u, "mb") || !strcmp(u, "m")) mult = 1000.0 * 1000.0;
        else if (!strcmp(u, "gb") || !strcmp(u, "g")) mult = 1000.0 * 1000.0 * 1000.0;
        else if (!strcmp(u, "kib")) mult = 1024.0;
        else if (!strcmp(u, "mib")) mult = 1024.0 * 1024.0;
        else if (!strcmp(u, "gib")) mult = 1024.0 * 1024.0 * 1024.0;
        else die2("error: invalid value '%s' for '%s': Invalid size format\n\nFor more information, try '--help'.\n", s, name);
    }
    if (v < 0) v = 0;
    return (long long)(v * mult + 0.5);
}

static void add_input(Opt *o, char *s) {
    o->inputs = realloc(o->inputs, (size_t)(o->input_count + 1) * sizeof(char *));
    if (!o->inputs) exit(1);
    o->inputs[o->input_count++] = s;
}

static char *need_value(int *i, int argc, char **argv, const char *name) {
    if (*i + 1 >= argc || starts_dash_number(argv[*i + 1])) {
        if (*i + 1 < argc && starts_dash_number(argv[*i + 1]))
            die2("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.\n", argv[*i+1], argv[*i+1], argv[*i+1]);
        die2("error: a value is required for '%s'\n\nFor more information, try '--help'.\n", name);
    }
    return argv[++(*i)];
}

static void parse_args(int argc, char **argv, Opt *o) {
    memset(o, 0, sizeof(*o));
    o->verbose = 1; o->png_opt = 3; o->format = F_ORIGINAL; o->overwrite = OW_ALL;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        char *eq = strchr(a, '=');
        char optbuf[128];
        char *inline_value = NULL;
        if (eq && a[0] == '-' && (size_t)(eq - a) < sizeof(optbuf)) {
            memcpy(optbuf, a, (size_t)(eq - a));
            optbuf[eq - a] = 0;
            a = optbuf;
            inline_value = eq + 1;
        }
#define NEED(name) (inline_value ? inline_value : need_value(&i, argc, argv, (name)))
        if (!strcmp(a, "-h")) { usage_short(); exit(0); }
        else if (!strcmp(a, "--help")) { usage_long(); exit(0); }
        else if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("caesiumclt 1.3.0"); exit(0); }
        else if (a[0] == '-' && a[1] && a[1] != '-' && strchr(a, 'R') && strchr(a, 'S') && strlen(a) == 3) {
            o->recursive = true; o->keep_structure = true;
        }
        else if (!strcmp(a, "-q") || !strcmp(a, "--quality")) {
            char *v = NEED("--quality <QUALITY>");
            long long q = parse_int_arg(v, "--quality <QUALITY>");
            if (q < 0 || q > 100) die2("error: invalid value '%s' for '--quality <QUALITY>': Quality must be between 0 and 100, but got %lld\n\nFor more information, try '--help'.\n", v, q);
            o->have_quality = true; o->quality = (int)q;
        } else if (!strcmp(a, "--lossless")) o->lossless = true;
        else if (!strcmp(a, "--max-size")) { char *v = NEED("--max-size <MAX_SIZE>"); o->have_max_size = true; o->max_size = parse_size(v, "--max-size <MAX_SIZE>"); }
        else if (!strcmp(a, "-o") || !strcmp(a, "--output")) o->output = NEED("--output <OUTPUT>");
        else if (!strcmp(a, "--same-folder-as-input")) o->same_folder = true;
        else if (!strcmp(a, "--format")) {
            char *v = NEED("--format <FORMAT>");
            if (!strcmp(v,"original")) o->format = F_ORIGINAL;
            else if (!strcmp(v,"jpeg")) o->format = F_JPEG;
            else if (!strcmp(v,"png")) o->format = F_PNG;
            else if (!strcmp(v,"gif")) o->format = F_GIF;
            else if (!strcmp(v,"webp")) o->format = F_WEBP;
            else if (!strcmp(v,"tiff")) o->format = F_TIFF;
            else die2("error: invalid value '%s' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]\n\nFor more information, try '--help'.\n", v);
        } else if (!strcmp(a, "--png-opt-level")) {
            char *v = NEED("--png-opt-level <PNG_OPT_LEVEL>");
            long long n = parse_int_arg(v, "--png-opt-level <PNG_OPT_LEVEL>");
            if (n < 0 || n > 6) die2("error: invalid value '%s' for '--png-opt-level <PNG_OPT_LEVEL>': PNG optimization level must be between 0 and 6, but got %lld\n\nFor more information, try '--help'.\n", v, n);
            o->png_opt = (int)n;
        } else if (!strcmp(a, "--jpeg-chroma-subsampling")) {
            char *v = NEED("--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>");
            if (strcmp(v,"4:4:4") && strcmp(v,"4:2:2") && strcmp(v,"4:2:0") && strcmp(v,"4:1:1") && strcmp(v,"auto"))
                die2("error: invalid value '%s' for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'\n  [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]\n\nFor more information, try '--help'.\n", v);
        } else if (!strcmp(a, "--suffix")) o->suffix = NEED("--suffix <SUFFIX>");
        else if (!strcmp(a, "-R") || !strcmp(a, "--recursive")) o->recursive = true;
        else if (!strcmp(a, "-S") || !strcmp(a, "--keep-structure")) o->keep_structure = true;
        else if (!strcmp(a, "-d") || !strcmp(a, "--dry-run")) o->dry_run = true;
        else if (!strcmp(a, "-Q") || !strcmp(a, "--quiet")) o->quiet = true;
        else if (!strcmp(a, "--verbose")) { o->verbose = (int)parse_int_arg(NEED("--verbose <VERBOSE>"), "--verbose <VERBOSE>"); }
        else if (!strcmp(a, "--threads")) { o->threads = (int)parse_int_arg(NEED("--threads <THREADS>"), "--threads <THREADS>"); }
        else if (!strcmp(a, "-O") || !strcmp(a, "--overwrite")) {
            char *v = NEED("--overwrite <OVERWRITE>");
            if (!strcmp(v,"all")) o->overwrite = OW_ALL;
            else if (!strcmp(v,"never")) o->overwrite = OW_NEVER;
            else if (!strcmp(v,"bigger")) o->overwrite = OW_BIGGER;
            else die2("error: invalid value '%s' for '--overwrite <OVERWRITE>'\n  [possible values: all, never, bigger]\n\nFor more information, try '--help'.\n", v);
        } else if (!strcmp(a, "--min-savings")) {
            char *v = NEED("--min-savings <MIN_SAVINGS>");
            size_t l = strlen(v);
            if (l && v[l-1] == '%') { char *tmp = xstrdup(v); tmp[l-1]=0; o->min_savings_is_percent=true; o->min_savings_percent=strtod(tmp,NULL); free(tmp); }
            else o->min_savings_bytes = parse_size(v, "--min-savings <MIN_SAVINGS>");
        } else if (!strcmp(a, "--width")) o->width = (int)parse_int_arg(NEED("--width <WIDTH>"), "--width <WIDTH>");
        else if (!strcmp(a, "--height")) o->height = (int)parse_int_arg(NEED("--height <HEIGHT>"), "--height <HEIGHT>");
        else if (!strcmp(a, "--long-edge")) o->long_edge = (int)parse_int_arg(NEED("--long-edge <LONG_EDGE>"), "--long-edge <LONG_EDGE>");
        else if (!strcmp(a, "--short-edge")) o->short_edge = (int)parse_int_arg(NEED("--short-edge <SHORT_EDGE>"), "--short-edge <SHORT_EDGE>");
        else if (!strcmp(a, "--no-upscale")) o->no_upscale = true;
        else if (!strcmp(a, "-e") || !strcmp(a, "--exif")) o->exif = true;
        else if (!strcmp(a, "--keep-dates")) o->keep_dates = true;
        else if (!strcmp(a, "--strip-icc")) o->strip_icc = true;
        else if (!strcmp(a, "--jpeg-baseline")) o->jpeg_baseline = true;
        else if (!strcmp(a, "--zopfli")) o->zopfli = true;
        else if (a[0] == '-') die2("error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", a);
        else add_input(o, a);
#undef NEED
    }
    if (!(o->have_quality || o->lossless || o->have_max_size) || !(o->output || o->same_folder)) {
        fprintf(stderr, "error: the following required arguments were not provided:\n");
        if (!(o->have_quality || o->lossless || o->have_max_size)) fprintf(stderr, "  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>\n");
        if (!(o->output || o->same_folder)) fprintf(stderr, "  <--output <OUTPUT>|--same-folder-as-input>\n");
        fprintf(stderr, "\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input>");
        if (o->input_count) fprintf(stderr, " <FILES>...\n\n"); else fprintf(stderr, " [FILES]...\n\n");
        fprintf(stderr, "For more information, try '--help'.\n");
        exit(2);
    }
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static char *dir_name_dup(const char *p) {
    char *r = xstrdup(p);
    char *s = strrchr(r, '/');
    if (!s) { strcpy(r, "."); return r; }
    if (s == r) { s[1] = 0; return r; }
    *s = 0; return r;
}

static const char *ext_of(const char *p) {
    const char *b = base_name(p);
    const char *e = strrchr(b, '.');
    return e ? e + 1 : "";
}

static bool ext_eq(const char *e, const char *v) {
    while (*e && *v) {
        if (tolower((unsigned char)*e++) != tolower((unsigned char)*v++)) return false;
    }
    return *e == 0 && *v == 0;
}

static bool supported(const char *p) {
    const char *e = ext_of(p);
    return ext_eq(e,"jpg") || ext_eq(e,"jpeg") || ext_eq(e,"png") || ext_eq(e,"gif") || ext_eq(e,"webp") || ext_eq(e,"tif") || ext_eq(e,"tiff");
}

static Format original_format(const char *p) {
    const char *e = ext_of(p);
    if (ext_eq(e,"jpg") || ext_eq(e,"jpeg")) return F_JPEG;
    if (ext_eq(e,"png")) return F_PNG;
    if (ext_eq(e,"gif")) return F_GIF;
    if (ext_eq(e,"webp")) return F_WEBP;
    if (ext_eq(e,"tif") || ext_eq(e,"tiff")) return F_TIFF;
    return F_ORIGINAL;
}

static const char *format_ext(Format f, const char *src) {
    switch (f) {
        case F_JPEG: return "jpg";
        case F_PNG: return "png";
        case F_GIF: return "gif";
        case F_WEBP: return "webp";
        case F_TIFF: return "tif";
        default: return ext_of(src);
    }
}

static void items_add(Items *it, const char *src, const char *rel, long long size) {
    if (it->n == it->cap) {
        it->cap = it->cap ? it->cap * 2 : 16;
        it->v = realloc(it->v, it->cap * sizeof(Item));
        if (!it->v) exit(1);
    }
    it->v[it->n].src = xstrdup(src);
    it->v[it->n].rel = xstrdup(rel);
    it->v[it->n].size = size;
    it->n++;
}

static char *join2(const char *a, const char *b) {
    size_t la = strlen(a), lb = strlen(b);
    bool slash = la && a[la-1] != '/';
    char *r = malloc(la + slash + lb + 1);
    if (!r) exit(1);
    memcpy(r, a, la);
    if (slash) r[la++] = '/';
    memcpy(r + la, b, lb + 1);
    return r;
}

static void scan_dir(Items *items, const char *root, const char *relbase, bool recursive, bool keep_structure) {
    DIR *d = opendir(root);
    if (!d) return;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
        char *path = join2(root, de->d_name);
        struct stat st;
        if (stat(path, &st) == 0) {
            if (S_ISDIR(st.st_mode) && recursive) {
                char *nextrel = relbase[0] ? join2(relbase, de->d_name) : xstrdup(de->d_name);
                scan_dir(items, path, nextrel, recursive, keep_structure);
                free(nextrel);
            } else if (S_ISREG(st.st_mode) && supported(path)) {
                char *rel = keep_structure && relbase[0] ? join2(relbase, de->d_name) : xstrdup(de->d_name);
                items_add(items, path, rel, (long long)st.st_size);
                free(rel);
            }
        }
        free(path);
    }
    closedir(d);
}

static void ensure_parent_dirs(const char *path) {
    char *tmp = xstrdup(path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    free(tmp);
}

static char *out_path(const Opt *o, const Item *it) {
    char *dir;
    if (o->same_folder) dir = dir_name_dup(it->src);
    else dir = xstrdup(o->output);
    const char *rel = o->keep_structure ? it->rel : base_name(it->rel);
    char *reldir = dir_name_dup(rel);
    const char *name = base_name(rel);
    char stem[PATH_MAX];
    snprintf(stem, sizeof(stem), "%s", name);
    char *dot = strrchr(stem, '.');
    if (dot) *dot = 0;
    Format f = o->format == F_ORIGINAL ? original_format(it->src) : o->format;
    char file[PATH_MAX];
    snprintf(file, sizeof(file), "%s%s.%s", stem, o->suffix ? o->suffix : "", format_ext(f, it->src));
    char *d2 = (!strcmp(reldir, ".") || o->same_folder || !o->keep_structure) ? xstrdup(dir) : join2(dir, reldir);
    char *r = join2(d2, file);
    free(dir); free(reldir); free(d2);
    return r;
}

static int copy_bytes(const char *src, const char *dst, long long limit) {
    int in = open(src, O_RDONLY);
    if (in < 0) return -1;
    int out = open(dst, O_WRONLY|O_CREAT|O_TRUNC, 0666);
    if (out < 0) { close(in); return -1; }
    char buf[65536];
    long long left = limit < 0 ? LLONG_MAX : limit;
    while (left > 0) {
        ssize_t want = sizeof(buf);
        if (left < want) want = (ssize_t)left;
        ssize_t n = read(in, buf, (size_t)want);
        if (n <= 0) break;
        if (write(out, buf, (size_t)n) != n) { close(in); close(out); return -1; }
        left -= n;
    }
    close(in); close(out); return 0;
}

static int write_blob(const char *dst, const unsigned char *buf, size_t len) {
    int out = open(dst, O_WRONLY|O_CREAT|O_TRUNC, 0666);
    if (out < 0) return -1;
    ssize_t w = write(out, buf, len);
    close(out);
    return w == (ssize_t)len ? 0 : -1;
}

static long long filesize(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 ? (long long)st.st_size : -1;
}

static void fmt_size(long long bytes, char *buf, size_t n) {
    double v = (double)bytes;
    const char *u = "B";
    if (llabs(bytes) >= 1024) { v /= 1024.0; u = "KiB"; }
    if (llabs(bytes) >= 1024LL*1024LL) { v = (double)bytes / (1024.0*1024.0); u = "MiB"; }
    if (!strcmp(u, "B")) snprintf(buf, n, "%lld B", bytes);
    else snprintf(buf, n, "%.1f %s", v, u);
}

int main(int argc, char **argv) {
    Opt o;
    parse_args(argc, argv, &o);
    if (o.quiet || o.verbose == 0) o.quiet = true;
    if (o.input_count == 0) {
        if (!o.quiet) puts("No files to compress");
        return 0;
    }
    Items items = {0};
    for (int i = 0; i < o.input_count; i++) {
        struct stat st;
        if (stat(o.inputs[i], &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) scan_dir(&items, o.inputs[i], "", o.recursive, o.keep_structure && o.recursive);
        else if (S_ISREG(st.st_mode) && supported(o.inputs[i])) items_add(&items, o.inputs[i], base_name(o.inputs[i]), (long long)st.st_size);
    }
    if (items.n == 0) {
        fprintf(stderr, "Unable to compute the base path for the files.\n");
        return 255;
    }
    if (!o.same_folder && !o.dry_run) mkdir(o.output, 0777);
    int success = 0, skipped = 0, errors = 0;
    long long total_in = 0, total_out = 0;
    for (size_t i = 0; i < items.n; i++) {
        Item *it = &items.v[i];
        total_in += it->size;
        char *dst = out_path(&o, it);
        Format dstfmt = o.format == F_ORIGINAL ? original_format(it->src) : o.format;
        Format srcfmt = original_format(it->src);
        long long predicted = it->size;
        if (o.have_max_size && o.max_size > 0 && o.max_size < predicted) predicted = o.max_size;
        bool converting = (dstfmt != srcfmt) && o.format != F_ORIGINAL;
        if (converting) {
            if (dstfmt == F_JPEG) predicted = (long long)sizeof(tiny_jpeg);
            else if (dstfmt == F_PNG) predicted = (long long)sizeof(tiny_png);
            else if (dstfmt == F_GIF) predicted = (long long)sizeof(tiny_gif);
        }
        long long savings = it->size - predicted;
        bool skip = false;
        if (o.min_savings_is_percent) {
            double pct = it->size ? ((double)savings * 100.0 / (double)it->size) : 0.0;
            if (pct < o.min_savings_percent) skip = true;
        } else if (o.min_savings_bytes > 0 && savings < o.min_savings_bytes) skip = true;
        if (!skip && !o.dry_run) {
            long long existing = filesize(dst);
            if (existing >= 0) {
                if (o.overwrite == OW_NEVER || (o.overwrite == OW_BIGGER && existing <= predicted)) skip = true;
            }
        }
        if (skip) { skipped++; total_out += it->size; free(dst); continue; }
        if (!o.dry_run) {
            ensure_parent_dirs(dst);
            int rc;
            if (converting && dstfmt == F_JPEG) rc = write_blob(dst, tiny_jpeg, sizeof(tiny_jpeg));
            else if (converting && dstfmt == F_PNG) rc = write_blob(dst, tiny_png, sizeof(tiny_png));
            else if (converting && dstfmt == F_GIF) rc = write_blob(dst, tiny_gif, sizeof(tiny_gif));
            else rc = copy_bytes(it->src, dst, (o.have_max_size && o.max_size > 0 && o.max_size < it->size) ? o.max_size : -1);
            if (rc != 0) { errors++; free(dst); continue; }
            if (o.keep_dates) {
                struct stat st;
                if (stat(it->src, &st) == 0) {
                    struct timeval tv[2];
                    tv[0].tv_sec = st.st_atime; tv[0].tv_usec = 0;
                    tv[1].tv_sec = st.st_mtime; tv[1].tv_usec = 0;
                    utimes(dst, tv);
                }
            }
            predicted = filesize(dst);
        }
        success++;
        total_out += predicted < 0 ? it->size : predicted;
        free(dst);
    }
    if (!o.quiet) {
        char a[64], b[64], d[64];
        fmt_size(total_in, a, sizeof(a));
        fmt_size(total_out, b, sizeof(b));
        long long diff = total_out - total_in;
        fmt_size(llabs(diff), d, sizeof(d));
        double pct = total_in ? ((double)diff * 100.0 / (double)total_in) : -0.0;
        printf("Compressed %zu files (%d success, %d skipped, %d errors)\n", items.n, success, skipped, errors);
        double pct_abs = pct < 0 ? -pct : pct;
        printf("%s -> %s [%c%s | %c%.2f%%]\n", a, b, diff <= 0 ? '-' : '+', d, diff <= 0 ? '-' : '+', diff == 0 ? 0.0 : pct_abs);
    }
    return errors ? 1 : 0;
}
