#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct { char *in; char *out; } Pair;
typedef struct { Pair *v; size_t n, cap; } Pairs;
typedef struct { char **v; size_t n, cap; } Strs;
typedef struct { char *name; int index; } Name;
typedef struct { Name *v; size_t n, cap; } Names;

typedef struct {
    char *dir, *regex_pat, *sort_order, *map_path, *gen_path, *output_pat;
    bool no_ext, mkdirs, quiet, test, overwrite;
    int depth, max_depth;
} Opt;

static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(1);} return p; }
static void *xrealloc(void *p,size_t n){ void *q=realloc(p,n); if(!q){perror("realloc"); exit(1);} return q; }
static void pairs_add(Pairs *p,const char *in,const char *out){ if(p->n==p->cap){p->cap=p->cap?p->cap*2:16;p->v=xrealloc(p->v,p->cap*sizeof(Pair));} p->v[p->n].in=xstrdup(in); p->v[p->n].out=xstrdup(out); p->n++; }
static void strs_add(Strs *s,const char *v){ if(s->n==s->cap){s->cap=s->cap?s->cap*2:32;s->v=xrealloc(s->v,s->cap*sizeof(char*));} s->v[s->n++]=xstrdup(v); }
static void names_add(Names *n,const char *name,int idx){ if(n->n==n->cap){n->cap=n->cap?n->cap*2:8;n->v=xrealloc(n->v,n->cap*sizeof(Name));} n->v[n->n].name=xstrdup(name); n->v[n->n].index=idx; n->n++; }
static int names_get(Names *n,const char *name){ for(size_t i=0;i<n->n;i++) if(!strcmp(n->v[i].name,name)) return n->v[i].index; return -1; }
static bool is_regular(const char *p){ struct stat st; return lstat(p,&st)==0 && S_ISREG(st.st_mode); }
static bool exists_path(const char *p){ return access(p,F_OK)==0; }

static void die_usage(const char *fmt,...){
    va_list ap; va_start(ap,fmt); fprintf(stderr,"error: "); vfprintf(stderr,fmt,ap); va_end(ap);
    fprintf(stderr,"\nusage: run './executable --help' for more information.\n"); exit(2);
}

static void print_help(bool longh){
    printf("Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\n");
    if(longh){
        printf("Arguments:\n  [[SOURCE] OUTPUT]...\n          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n");
        printf("  -d, --dir <PATH>\n          Sets the working directory\n\n      --depth <DEPTH>\n          Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n\n");
        printf("  -E, --no-extension\n          Does not preserve the extension of input files in 'sort' and 'regex' options\n\n  -g, --generate <PATH>\n          Stores a JSON map file in '<PATH>' after renaming files\n\n");
        printf("  -h, --help\n          Print help (see a summary with '-h')\n\n  -k, --mkdir\n          Recursively creates all parent directories of '<OUTPUT>' if they are missing\n\n");
        printf("  -m, --map <PATH>\n          Sets the path of map file to be used for renaming files\n          \n          [aliases: --from-file]\n\n");
        printf("      --max-depth <DEPTH>\n          Optional value to set the maximum of subdirectory depth value in 'regex' mode\n\n  -q, --quiet\n          Does not print the map table to stdout\n\n");
        printf("  -r, --regex <PATTERN>\n          Regex pattern to match by filenames\n\n  -s, --sort <ORDER>\n          Sets the order of natural sorting (by name) to rename files using enumerator\n\n          Possible values:\n          - asc:  Sort in ascending order\n          - desc: Sort in descending order\n\n");
        printf("  -t, --test\n          Runs in test mode without renaming actual files\n          \n          [aliases: --dry-run]\n\n  -V, --version\n          Print version\n\n  -w, --overwrite\n          Overwrites output files, otherwise, a '_' is prepended to filename\n\n");
    } else {
        printf("Arguments:\n  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n");
        printf("  -d, --dir <PATH>         Sets the working directory\n      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n");
        printf("  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options\n  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files\n");
        printf("  -h, --help               Print help (see more with '--help')\n  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing\n");
        printf("  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]\n      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode\n");
        printf("  -q, --quiet              Does not print the map table to stdout\n  -r, --regex <PATTERN>    Regex pattern to match by filenames\n  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]\n");
        printf("  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]\n  -V, --version            Print version\n  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename\n\n");
    }
    printf("OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.\n");
}

static const char *base_name(const char *p){ const char *s=strrchr(p,'/'); return s?s+1:p; }
static char *dir_name_dup(const char *p){ const char *s=strrchr(p,'/'); if(!s) return xstrdup(""); size_t n=s-p; char *r=malloc(n+1); memcpy(r,p,n); r[n]=0; return r; }
static const char *extension_of(const char *p){ const char *b=base_name(p), *d=strrchr(b,'.'); return (d&&d!=b)?d:""; }
static char *join2(const char *a,const char *b){ if(!a||!*a) return xstrdup(b); size_t al=strlen(a), bl=strlen(b); char *r=malloc(al+bl+2); sprintf(r,"%s/%s",a,b); return r; }

static int natural_cmp_core(const char *a,const char *b){
    while(*a&&*b){
        if(isdigit((unsigned char)*a)&&isdigit((unsigned char)*b)){
            while(*a=='0') a++; while(*b=='0') b++;
            const char *aa=a,*bb=b; while(isdigit((unsigned char)*aa)) aa++; while(isdigit((unsigned char)*bb)) bb++;
            int la=aa-a, lb=bb-b; if(la!=lb) return la-lb;
            int c=strncmp(a,b,la); if(c) return c; a=aa; b=bb;
        } else {
            int ca=tolower((unsigned char)*a), cb=tolower((unsigned char)*b); if(ca!=cb) return ca-cb; a++; b++;
        }
    }
    return (unsigned char)*a-(unsigned char)*b;
}
static int sort_asc(const void *pa,const void *pb){ char * const *a=pa,* const *b=pb; return natural_cmp_core(*a,*b); }
static int sort_desc(const void *pa,const void *pb){ return -sort_asc(pa,pb); }

static void scan_dir(const char *root,const char *rel,int maxd,Strs *out){
    char *path = rel&&*rel ? join2(root,rel) : xstrdup(root);
    DIR *d=opendir(path); if(!d){ free(path); return; }
    struct dirent *e;
    while((e=readdir(d))){
        if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")) continue;
        char *r = rel&&*rel ? join2(rel,e->d_name) : xstrdup(e->d_name);
        char *full = join2(root,r);
        struct stat st;
        if(lstat(full,&st)==0){
            if(S_ISREG(st.st_mode)) strs_add(out,r);
            else if(S_ISDIR(st.st_mode) && maxd!=0) scan_dir(root,r,maxd>0?maxd-1:maxd,out);
        }
        free(r); free(full);
    }
    closedir(d); free(path);
}

static char *group_text(const char *s, regmatch_t *m, int idx){
    if(idx<0 || m[idx].rm_so<0) return xstrdup("");
    size_t n=m[idx].rm_eo-m[idx].rm_so; char *r=malloc(n+1); memcpy(r,s+m[idx].rm_so,n); r[n]=0; return r;
}
static char *pad_value(const char *v,int pad){
    if(pad<=0 || !*v) return xstrdup(v);
    const char *p=v; if(*p=='-') return xstrdup(v);
    for(const char *q=p; *q; q++) if(!isdigit((unsigned char)*q)) return xstrdup(v);
    int len=strlen(v); if(len>=pad) return xstrdup(v);
    char *r=malloc(pad+1); memset(r,'0',pad-len); strcpy(r+(pad-len),v); return r;
}
static bool all_digits_s(const char *s){ if(!*s) return false; for(;*s;s++) if(!isdigit((unsigned char)*s)) return false; return true; }
static char *replace_pattern(const char *pat, const char *subject, regmatch_t *m, int nmatch, int seq, Names *names){
    size_t cap=128,len=0; char *res=malloc(cap); res[0]=0; int autoi=1;
    for(size_t i=0; pat[i]; ){
        if(pat[i]=='{' ){
            size_t j=i+1; while(pat[j] && pat[j]!='}') j++;
            if(pat[j]=='}'){
                char buf[128]; size_t cn=j-i-1; if(cn>=sizeof(buf)) cn=sizeof(buf)-1; memcpy(buf,pat+i+1,cn); buf[cn]=0;
                int gi=-1,pad=0; char *colon=strchr(buf,':');
                if(colon){ *colon=0; pad=atoi(colon+1); }
                if(buf[0]) gi=all_digits_s(buf)?atoi(buf):names_get(names,buf); else gi=autoi++;
                char *g = (gi==0 && (!m || nmatch==0)) ? xstrdup(subject) : (m && gi<nmatch ? group_text(subject,m,gi) : xstrdup(""));
                if(!m && gi>0){ free(g); char tmp[32]; snprintf(tmp,sizeof(tmp),"%d",seq); g=xstrdup(tmp); }
                char *pv=pad_value(g,pad); size_t pl=strlen(pv);
                if(len+pl+1>cap){ while(len+pl+1>cap) cap*=2; res=xrealloc(res,cap); }
                memcpy(res+len,pv,pl); len+=pl; res[len]=0; free(g); free(pv); i=j+1; continue;
            }
        }
        if(len+2>cap){ cap*=2; res=xrealloc(res,cap); }
        res[len++]=pat[i++]; res[len]=0;
    }
    return res;
}
static char *with_extension(const char *out,const char *input,bool noext){
    if(noext) return xstrdup(out);
    const char *ext=extension_of(input); size_t n=strlen(out)+strlen(ext)+1; char *r=malloc(n); snprintf(r,n,"%s%s",out,ext); return r;
}

static char *convert_named_regex(const char *pat, Names *names){
    size_t cap=strlen(pat)+1,len=0; char *out=malloc(cap); int group=0; bool esc=false, in_class=false;
    for(size_t i=0; pat[i]; i++){
        char c=pat[i];
        if(esc){ if(len+2>cap){cap*=2;out=xrealloc(out,cap);} out[len++]=c; esc=false; continue; }
        if(c=='\\'){ if(len+2>cap){cap*=2;out=xrealloc(out,cap);} out[len++]=c; esc=true; continue; }
        if(c=='[') in_class=true; else if(c==']') in_class=false;
        if(!in_class && c=='('){
            if(pat[i+1]=='?' && (pat[i+2]=='<' || (pat[i+2]=='P' && pat[i+3]=='<'))){
                size_t j=i+(pat[i+2]=='<'?3:4), start=j; while(pat[j] && pat[j]!='>') j++;
                if(pat[j]=='>'){
                    char name[128]; size_t nl=j-start; if(nl>=sizeof(name)) nl=sizeof(name)-1; memcpy(name,pat+start,nl); name[nl]=0;
                    group++; names_add(names,name,group);
                    if(len+2>cap){cap*=2;out=xrealloc(out,cap);} out[len++]='('; i=j; continue;
                }
            }
            group++;
        }
        if(len+2>cap){cap*=2;out=xrealloc(out,cap);} out[len++]=c;
    }
    out[len]=0; return out;
}

static char *collision_name(const char *out,bool overwrite){
    if(overwrite || !exists_path(out)) return xstrdup(out);
    char *dir=dir_name_dup(out); const char *b=base_name(out); char *cur=NULL;
    int underscores=1;
    do {
        free(cur); size_t bl=strlen(b)+underscores+1; char *nb=malloc(bl); memset(nb,'_',underscores); strcpy(nb+underscores,b);
        cur=(*dir)?join2(dir,nb):xstrdup(nb); free(nb); underscores++;
    } while(exists_path(cur));
    free(dir); return cur;
}

static void collect_sort(Opt *o,Pairs *pairs){
    Strs s={0}; scan_dir(".", "", 0, &s); qsort(s.v,s.n,sizeof(char*), !strcmp(o->sort_order,"desc")?sort_desc:sort_asc);
    for(size_t i=0;i<s.n;i++){ char *r=replace_pattern(o->output_pat,s.v[i],NULL,0,(int)i+1,NULL); char *e=with_extension(r,s.v[i],o->no_ext); char *c=collision_name(e,o->overwrite); pairs_add(pairs,s.v[i],c); free(r); free(e); free(c); }
}
static void collect_regex(Opt *o,Pairs *pairs){
    Names names={0}; char *conv=convert_named_regex(o->regex_pat,&names);
    regex_t re; int rc=regcomp(&re,conv,REG_EXTENDED);
    if(rc){ char buf[256]; regerror(rc,&re,buf,sizeof(buf)); fprintf(stderr,"error: %s\n",buf); exit(2); }
    Strs s={0}; int md=o->max_depth>=0?o->max_depth:(o->depth>=0?o->depth:0); scan_dir(".", "", md, &s); qsort(s.v,s.n,sizeof(char*),sort_asc);
    size_t nmatch=re.re_nsub+1; regmatch_t *m=calloc(nmatch,sizeof(regmatch_t));
    for(size_t i=0;i<s.n;i++) if(regexec(&re,s.v[i],nmatch,m,0)==0){ char *r=replace_pattern(o->output_pat,s.v[i],m,(int)nmatch,(int)i+1,&names); char *e=with_extension(r,s.v[i],o->no_ext); char *c=collision_name(e,o->overwrite); pairs_add(pairs,s.v[i],c); free(r); free(e); free(c); }
    free(m); free(conv); regfree(&re);
}

static char *read_file(const char *p){ FILE *f=fopen(p,"rb"); if(!f){fprintf(stderr,"[error] unable to read '%s': %s\n",p,strerror(errno)); exit(1);} fseek(f,0,SEEK_END); long n=ftell(f); rewind(f); char *b=malloc(n+1); fread(b,1,n,f); b[n]=0; fclose(f); return b; }
static char *json_string(const char **pp){
    const char *p=*pp; while(*p&&*p!='"') p++; if(!*p) return NULL; p++;
    size_t cap=64,len=0; char *r=malloc(cap);
    while(*p&&*p!='"'){ char c=*p++; if(c=='\\'&&*p) c=*p++; if(len+2>cap){cap*=2;r=xrealloc(r,cap);} r[len++]=c; }
    r[len]=0; if(*p=='"') p++; *pp=p; return r;
}
static void collect_map(Opt *o,Pairs *pairs){
    char *buf=read_file(o->map_path); const char *p=buf;
    while(1){ char *src=json_string(&p); if(!src) break; while(*p&&*p!=':') p++; if(*p==':') p++; char *dst=json_string(&p); if(!dst){free(src);break;} char *c=collision_name(dst,o->overwrite); pairs_add(pairs,src,c); free(src); free(dst); free(c); }
    free(buf);
}

static void print_table(Pairs *p){
    size_t wi=5,wo=6; for(size_t i=0;i<p->n;i++){ size_t a=strlen(p->v[i].in), b=strlen(p->v[i].out); if(a>wi)wi=a; if(b>wo)wo=b; }
    printf("+"); for(size_t i=0;i<wi+2;i++) printf("-"); printf("+"); for(size_t i=0;i<wo+2;i++) printf("-"); printf("+\n");
    printf("| %-*s | %-*s |\n",(int)wi,"Input",(int)wo,"Output");
    printf("+"); for(size_t i=0;i<wi+2;i++) printf("-"); printf("+"); for(size_t i=0;i<wo+2;i++) printf("-"); printf("+\n");
    for(size_t i=0;i<p->n;i++) printf("| %-*s | %-*s |\n",(int)wi,p->v[i].in,(int)wo,p->v[i].out);
    printf("+"); for(size_t i=0;i<wi+2;i++) printf("-"); printf("+"); for(size_t i=0;i<wo+2;i++) printf("-"); printf("+\n");
}
static void mkdir_parent(const char *p){
    char *d=dir_name_dup(p); if(!*d){free(d);return;} for(char *q=d+1; *q; q++) if(*q=='/'){*q=0; mkdir(d,0777); *q='/';} mkdir(d,0777); free(d);
}
static void apply_pairs(Pairs *p,Opt *o){
    if(o->test) return;
    for(size_t i=0;i<p->n;i++){ if(o->mkdirs) mkdir_parent(p->v[i].out); if(rename(p->v[i].in,p->v[i].out)!=0) fprintf(stderr,"[error] unable to rename '%s': %s (os error %d)\n",p->v[i].in,strerror(errno),errno); }
}
static void write_map(const char *path,Pairs *p){
    FILE *f=fopen(path,"w"); if(!f){fprintf(stderr,"[error] unable to write '%s': %s\n",path,strerror(errno)); return;} fprintf(f,"{\n");
    for(size_t i=0;i<p->n;i++) fprintf(f,"  \"%s\": \"%s\"%s\n",p->v[i].out,p->v[i].in,(i+1<p->n)?",":"");
    fprintf(f,"}\n"); fclose(f);
}

int main(int argc,char **argv){
    Opt o={.dir=".",.depth=-1,.max_depth=-1}; char *pos[3]; int npos=0;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")){print_help(true);return 0;} else if(!strcmp(a,"-h")){print_help(false);return 0;} else if(!strcmp(a,"--version")||!strcmp(a,"-V")){printf("nomino 1.6.4\n");return 0;}
        else if(!strcmp(a,"-E")||!strcmp(a,"--no-extension")) o.no_ext=true; else if(!strcmp(a,"-k")||!strcmp(a,"--mkdir")) o.mkdirs=true; else if(!strcmp(a,"-q")||!strcmp(a,"--quiet")) o.quiet=true; else if(!strcmp(a,"-t")||!strcmp(a,"--test")||!strcmp(a,"--dry-run")) o.test=true; else if(!strcmp(a,"-w")||!strcmp(a,"--overwrite")) o.overwrite=true;
        else if((!strcmp(a,"-d")||!strcmp(a,"--dir"))&&i+1<argc) o.dir=argv[++i]; else if((!strcmp(a,"-r")||!strcmp(a,"--regex"))&&i+1<argc) o.regex_pat=argv[++i]; else if((!strcmp(a,"-s")||!strcmp(a,"--sort"))&&i+1<argc) o.sort_order=argv[++i];
        else if((!strcmp(a,"-m")||!strcmp(a,"--map")||!strcmp(a,"--from-file"))&&i+1<argc) o.map_path=argv[++i]; else if((!strcmp(a,"-g")||!strcmp(a,"--generate"))&&i+1<argc) o.gen_path=argv[++i];
        else if(!strcmp(a,"--depth")&&i+1<argc) o.depth=atoi(argv[++i]); else if(!strcmp(a,"--max-depth")&&i+1<argc) o.max_depth=atoi(argv[++i]);
        else if(a[0]=='-') die_usage("unexpected argument '%s' found",a);
        else { if(npos<3) pos[npos++]=a; }
    }
    if(o.sort_order && strcmp(o.sort_order,"asc")&&strcmp(o.sort_order,"desc")){ fprintf(stderr,"error: invalid value '%s' for '--sort <ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.\n",o.sort_order); return 2; }
    if(npos==1) o.output_pat=pos[0]; else if(npos>=2){ if(!o.regex_pat) o.regex_pat=pos[0]; o.output_pat=pos[1]; }
    if(chdir(o.dir)!=0){ fprintf(stderr,"[error] unable to open directory '%s': %s\n",o.dir,strerror(errno)); return 1; }
    Pairs pairs={0};
    if(o.map_path) collect_map(&o,&pairs);
    else if(o.sort_order){ if(!o.output_pat) die_usage("'OUTPUT' is required"); collect_sort(&o,&pairs); }
    else if(o.regex_pat){ if(!o.output_pat) die_usage("'OUTPUT' is required"); collect_regex(&o,&pairs); }
    else die_usage("one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.");
    if(!o.quiet) print_table(&pairs);
    apply_pairs(&pairs,&o);
    if(o.gen_path) write_map(o.gen_path,&pairs);
    return 0;
}
