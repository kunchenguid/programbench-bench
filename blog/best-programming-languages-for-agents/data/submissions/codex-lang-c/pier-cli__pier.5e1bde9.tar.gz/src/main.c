#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char *alias, *command, *description;
    char **tags;
    int ntags;
} Script;

typedef struct {
    Script *items;
    int len, cap;
} Config;

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) { perror("strdup"); exit(2); }
    return p;
}

static void die(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static char *unquote_value(char *v) {
    v = trim(v);
    size_t n = strlen(v);
    if (n >= 2 && ((v[0] == '\'' && v[n-1] == '\'') || (v[0] == '"' && v[n-1] == '"'))) {
        v[n-1] = 0;
        return xstrdup(v+1);
    }
    return xstrdup(v);
}

static void add_script(Config *c, Script s) {
    if (c->len == c->cap) {
        c->cap = c->cap ? c->cap * 2 : 8;
        c->items = realloc(c->items, sizeof(Script) * c->cap);
        if (!c->items) exit(2);
    }
    c->items[c->len++] = s;
}

static int find_script(Config *c, const char *alias) {
    for (int i = 0; i < c->len; i++) if (strcmp(c->items[i].alias, alias) == 0) return i;
    return -1;
}

static void free_script(Script *s) {
    free(s->alias); free(s->command); free(s->description);
    for (int i = 0; i < s->ntags; i++) free(s->tags[i]);
    free(s->tags);
}

static char *path_join3(const char *a, const char *b, const char *c) {
    size_t n = strlen(a)+strlen(b)+strlen(c)+3;
    char *p = malloc(n);
    snprintf(p, n, "%s/%s/%s", a, b, c);
    return p;
}

static bool exists_file(const char *p) { return access(p, F_OK) == 0; }

static char *default_config_path(bool require_exists) {
    const char *env = getenv("PIER_CONFIG_PATH");
    if (env && *env) return xstrdup(env);
    if (exists_file("pier.toml")) return xstrdup("pier.toml");
    const char *xdg = getenv("XDG_CONFIG_HOME");
    const char *home = getenv("HOME");
    char *candidates[5]; int n = 0;
    if (xdg && *xdg) {
        candidates[n++] = path_join3(xdg, "pier", "config.toml");
        candidates[n++] = path_join3(xdg, "pier", "config");
        size_t z = strlen(xdg)+20; candidates[n] = malloc(z); snprintf(candidates[n++], z, "%s/pier.toml", xdg);
    }
    if (home && *home) {
        size_t z = strlen(home)+20; candidates[n] = malloc(z); snprintf(candidates[n++], z, "%s/.pier.toml", home);
        z = strlen(home)+20; candidates[n] = malloc(z); snprintf(candidates[n++], z, "%s/.pier", home);
    }
    for (int i = 0; i < n; i++) {
        if (exists_file(candidates[i])) {
            char *r = candidates[i];
            for (int j = 0; j < n; j++) if (j != i) free(candidates[j]);
            return r;
        }
    }
    if (require_exists) die("No default config file found. See help for more info.");
    if (xdg && *xdg) return path_join3(xdg, "pier", "config.toml");
    if (home && *home) { size_t z = strlen(home)+20; char *p = malloc(z); snprintf(p, z, "%s/.pier.toml", home); return p; }
    return xstrdup("pier.toml");
}

static void ensure_parent_dir(const char *path) {
    char *p = xstrdup(path);
    char *slash = strrchr(p, '/');
    if (slash) {
        *slash = 0;
        char tmp[PATH_MAX] = {0};
        char *src = p;
        if (*src == '/') { strcpy(tmp, "/"); src++; }
        for (char *tok = strtok(src, "/"); tok; tok = strtok(NULL, "/")) {
            if (strlen(tmp) && tmp[strlen(tmp)-1] != '/') strcat(tmp, "/");
            strcat(tmp, tok);
            mkdir(tmp, 0777);
        }
    }
    free(p);
}

static Config load_config(const char *path) {
    Config c = {0};
    FILE *f = fopen(path, "r");
    if (!f) die("No default config file found. See help for more info.");
    char *line = NULL; size_t sz = 0; Script *cur = NULL; bool in_tags = false;
    while (getline(&line, &sz, f) != -1) {
        char *s = trim(line);
        if (!*s || *s == '#') continue;
        if (strncmp(s, "[scripts.", 9) == 0) {
            char *e = strchr(s+9, ']'); if (!e) continue; *e = 0;
            Script sc = {0}; sc.alias = xstrdup(s+9); sc.command = xstrdup(""); sc.description = xstrdup("");
            add_script(&c, sc); cur = &c.items[c.len-1]; in_tags = false; continue;
        }
        if (*s == '[') { cur = NULL; in_tags = false; continue; }
        if (!cur) continue;
        if (in_tags) {
            if (strchr(s, ']')) { in_tags = false; continue; }
            char *comma = strrchr(s, ','); if (comma) *comma = 0;
            char *val = unquote_value(s);
            if (*val) {
                cur->tags = realloc(cur->tags, sizeof(char*) * (cur->ntags+1));
                cur->tags[cur->ntags++] = val;
            } else free(val);
            continue;
        }
        char *eq = strchr(s, '='); if (!eq) continue; *eq = 0;
        char *key = trim(s), *val = trim(eq+1);
        if (strcmp(key, "command") == 0) { free(cur->command); cur->command = unquote_value(val); }
        else if (strcmp(key, "description") == 0) { free(cur->description); cur->description = unquote_value(val); }
        else if (strcmp(key, "tags") == 0) {
            if (strchr(val, '[') && !strchr(val, ']')) in_tags = true;
            else {
                char *b = strchr(val, '['), *e = strrchr(val, ']');
                if (b && e && e > b) {
                    *e = 0; b++;
                    for (char *tok = strtok(b, ","); tok; tok = strtok(NULL, ",")) {
                        char *q = unquote_value(tok);
                        if (*q) { cur->tags = realloc(cur->tags, sizeof(char*)*(cur->ntags+1)); cur->tags[cur->ntags++] = q; }
                        else free(q);
                    }
                }
            }
        }
    }
    free(line); fclose(f); return c;
}

static void write_sq(FILE *f, const char *s) {
    fputc('\'', f);
    for (; *s; s++) {
        if (*s == '\'') fputs("\\'", f);
        else fputc(*s, f);
    }
    fputc('\'', f);
}

static void save_config(const char *path, Config *c) {
    ensure_parent_dir(path);
    FILE *f = fopen(path, "w");
    if (!f) die("Failed to write config. %s (os error %d)", strerror(errno), errno);
    for (int i = 0; i < c->len; i++) {
        Script *s = &c->items[i];
        fprintf(f, "[scripts.%s]\ncommand = ", s->alias); write_sq(f, s->command); fputc('\n', f);
        if (s->description && *s->description) { fputs("description = ", f); write_sq(f, s->description); fputc('\n', f); }
        if (s->ntags) {
            fputs("tags = [\n", f);
            for (int j = 0; j < s->ntags; j++) { fputs("    ", f); write_sq(f, s->tags[j]); fputs(",\n", f); }
            fputs("]\n", f);
        }
        fputc('\n', f);
    }
    fputs("[default]\n", f);
    fclose(f);
}

static void print_main_help(void) {
    puts("pier 0.1.6\nBenjamin Scholtz, Isak Johansson\nA simple script management CLI\n");
    puts("USAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n");
    puts("FLAGS:\n    -h, --help       \n            Prints help information\n\n    -V, --version    \n            Prints version information\n\n    -v, --verbose    \n            The level of verbosity\n");
    puts("OPTIONS:\n    -c, --config-file <path>    \n            Sets a custom config file.\n");
    puts("SUBCOMMANDS:\n    add            Add a new script to config.\n    config-init    alias: init - Add a config file.\n    copy           alias: cp - Copy existing alias to the new one\n    edit           Edit a script matching alias.\n    help           Prints this message or the help of the given subcommand(s)\n    list           alias: ls - List scripts\n    move           alias: mv, rename - Move/rename existing alias to the new one\n    remove         alias: rm - Remove a script matching alias.\n    run            Run a script matching alias.\n    show           Show a script matching alias.");
}

static void print_help(const char *cmd) {
    if (!cmd) { print_main_help(); return; }
    if (!strcmp(cmd,"add")) puts("executable-add 0.1.6\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -a, --alias <alias>                The alias or name for the script.\n    -d, --description <description>    The description for the script.\n    -t, --tag <tags>...                Set which tags the script belongs to.\n\nARGS:\n    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR\n                 for you to enter the script into.");
    else if (!strcmp(cmd,"list")||!strcmp(cmd,"ls")) puts("executable-list 0.1.6\nalias: ls - List scripts\n\nDisplay options are determined by priority in this order:\n\n1. List only aliases\n\n2. Show full command\n\n3. Command display with (cli option)\n\n4. Command display with (config option)\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n    -l, --cmd_full        \n            Display the full command.\n\n    -h, --help            \n            Prints help information\n\n    -q, --list_aliases    \n            Only displays aliases of the scripts.\n\n    -V, --version         \n            Prints version information\n\n\nOPTIONS:\n    -c, --cmd_width <cmd-width>    \n            The max number of characters to display from the command.\n\n    -t, --tag <tags>...            \n            Filter based on tags.");
    else if (!strcmp(cmd,"run")) puts("executable-run 0.1.6\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script.");
    else if (!strcmp(cmd,"show")) puts("executable-show 0.1.6\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.");
    else if (!strcmp(cmd,"remove")||!strcmp(cmd,"rm")) puts("executable-remove 0.1.6\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.");
    else if (!strcmp(cmd,"copy")||!strcmp(cmd,"cp")) puts("executable-copy 0.1.6\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be copied.\n    <to-alias>      The new alias of the copy of the script.");
    else if (!strcmp(cmd,"move")||!strcmp(cmd,"mv")||!strcmp(cmd,"rename")) puts("executable-move 0.1.6\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be moved.\n    <to-alias>      The new alias of the script.");
    else if (!strcmp(cmd,"config-init")||!strcmp(cmd,"init")) puts("executable-config-init 0.1.6\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information");
    else print_main_help();
}

static char *join_args(int argc, char **argv, int start) {
    size_t n = 1;
    for (int i = start; i < argc; i++) n += strlen(argv[i]) + 1;
    char *s = calloc(1, n);
    for (int i = start; i < argc; i++) { if (i > start) strcat(s, " "); strcat(s, argv[i]); }
    return s;
}

static bool has_tag(Script *s, char **tags, int nt) {
    if (!nt) return true;
    for (int t = 0; t < nt; t++) for (int i = 0; i < s->ntags; i++) if (!strcmp(tags[t], s->tags[i])) return true;
    return false;
}

static char *tag_string(Script *s) {
    size_t n = 1; for (int i = 0; i < s->ntags; i++) n += strlen(s->tags[i]) + 1;
    char *r = calloc(1, n);
    for (int i = 0; i < s->ntags; i++) { if (i) strcat(r, ","); strcat(r, s->tags[i]); }
    return r;
}

static void border(int total) { for (int i = 0; i < total; i++) fputs("≖", stdout); putchar('\n'); }
static void row(const char *a,const char *b,const char *c,const char *d,int wa,int wb,int wc,int wd) {
    printf("⋮ %-*s ⋮ %-*s ⋮ %-*s ⋮ %-*s ⋮\n", wa,a, wb,b, wc,c, wd,d);
}

static void cmd_list(Config *cfg, int argc, char **argv) {
    bool q = false, full = false; int width = 20; char *tags[64]; int nt = 0;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i],"-q")||!strcmp(argv[i],"--list_aliases")) q = true;
        else if (!strcmp(argv[i],"-l")||!strcmp(argv[i],"--cmd_full")) full = true;
        else if ((!strcmp(argv[i],"-c")||!strcmp(argv[i],"--cmd_width")) && i+1<argc) width = atoi(argv[++i]);
        else if ((!strcmp(argv[i],"-t")||!strcmp(argv[i],"--tag")) && i+1<argc) tags[nt++] = argv[++i];
        else if (!strcmp(argv[i],"--help")||!strcmp(argv[i],"-h")) { print_help("list"); exit(0); }
    }
    if (q) { for (int i=0;i<cfg->len;i++) if (has_tag(&cfg->items[i],tags,nt)) puts(cfg->items[i].alias); return; }
    int wa=5, wb=4, wc=7, wd=11;
    char **tagstr = calloc(cfg->len, sizeof(char*));
    char **cmdstr = calloc(cfg->len, sizeof(char*));
    for (int i=0;i<cfg->len;i++) {
        Script *s=&cfg->items[i]; tagstr[i]=tag_string(s);
        cmdstr[i]=xstrdup(s->command);
        if (!full && (int)strlen(cmdstr[i]) > width) cmdstr[i][width]=0;
        if (has_tag(s,tags,nt)) {
            if ((int)strlen(s->alias)>wa) wa=strlen(s->alias);
            if ((int)strlen(tagstr[i])>wb) wb=strlen(tagstr[i]);
            if ((int)strlen(cmdstr[i])>wc) wc=strlen(cmdstr[i]);
            if ((int)strlen(s->description)>wd) wd=strlen(s->description);
        }
    }
    int total = wa+wb+wc+wd+13; border(total); row("Alias","Tags","Command","Description",wa,wb,wc,wd); border(total);
    for (int i=0;i<cfg->len;i++) if (has_tag(&cfg->items[i],tags,nt)) row(cfg->items[i].alias,tagstr[i],cmdstr[i],cfg->items[i].description,wa,wb,wc,wd);
    border(total);
    for(int i=0;i<cfg->len;i++){free(tagstr[i]);free(cmdstr[i]);} free(tagstr); free(cmdstr);
}

static void run_script(Script *s, int argc, char **argv) {
    int n = argc + 5;
    char **args = calloc(n, sizeof(char*));
    args[0] = "/bin/sh"; args[1] = "-c"; args[2] = s->command; args[3] = s->alias;
    for (int i = 0; i < argc; i++) args[4+i] = argv[i];
    execv("/bin/sh", args);
    perror("execv"); exit(127);
}

int main(int argc, char **argv) {
    int ai = 1; char *config_path = NULL;
    while (ai < argc) {
        if (!strcmp(argv[ai],"-h")||!strcmp(argv[ai],"--help")) { print_main_help(); return 0; }
        if (!strcmp(argv[ai],"-V")||!strcmp(argv[ai],"--version")) { puts("pier 0.1.6"); return 0; }
        if (!strcmp(argv[ai],"-v")||!strcmp(argv[ai],"--verbose")) { ai++; continue; }
        if ((!strcmp(argv[ai],"-c")||!strcmp(argv[ai],"--config-file")) && ai+1<argc) { config_path = argv[ai+1]; ai += 2; continue; }
        break;
    }
    if (ai >= argc) { print_main_help(); return 0; }
    char *cmd = argv[ai++];
    if (!strcmp(cmd,"help")) { print_help(ai<argc?argv[ai]:NULL); return 0; }
    if (!strcmp(cmd,"--help")||!strcmp(cmd,"-h")) { print_main_help(); return 0; }
    if (!strcmp(cmd,"--version")||!strcmp(cmd,"-V")) { puts("pier 0.1.6"); return 0; }
    if (!config_path) config_path = default_config_path(!(!strcmp(cmd,"config-init")||!strcmp(cmd,"init")));
    if (!strcmp(cmd,"config-init")||!strcmp(cmd,"init")) {
        Config c={0}; Script s={0}; s.alias=xstrdup("hello-pier"); s.command=xstrdup("echo Hello, Pier!"); s.description=xstrdup("This is an example command."); add_script(&c,s);
        save_config(config_path, &c); puts("Added hello-pier"); return 0;
    }
    Config cfg = load_config(config_path);
    if (!strcmp(cmd,"add")) {
        char *alias=NULL,*desc=xstrdup(""),*command=NULL; bool force=false; char *tags[64]; int nt=0;
        bool command_option = false;
        for (int i = ai; i < argc; i++) if (!strcmp(argv[i], "--command")) command_option = true;
        for (int i=ai;i<argc;i++) {
            if (!strcmp(argv[i],"--")) { command=join_args(argc,argv,i+1); break; }
            else if (!strcmp(argv[i],"-f")||!strcmp(argv[i],"--force")) force=true;
            else if ((!strcmp(argv[i],"-a")||!strcmp(argv[i],"--alias")) && i+1<argc) alias=argv[++i];
            else if (!strcmp(argv[i],"--command") && i+1<argc) command=xstrdup(argv[++i]);
            else if ((!strcmp(argv[i],"-d")||!strcmp(argv[i],"--description")) && i+1<argc) { free(desc); desc=xstrdup(argv[++i]); }
            else if ((!strcmp(argv[i],"-t")||!strcmp(argv[i],"--tag")) && i+1<argc) tags[nt++]=argv[++i];
            else if (!alias && command_option) alias=argv[i];
            else { command=join_args(argc,argv,i); break; }
        }
        if (!alias) die("The following required arguments were not provided:\n    --alias <alias>");
        if (!command || !*command) die("EditorError: Failed when trying to get input from editor Failed to open `vi` as a text editor or editor was terminated with errors.");
        int idx=find_script(&cfg,alias); if (idx>=0 && !force) die("AliasAlreadyExists:  %s", alias);
        Script s={0}; s.alias=xstrdup(alias); s.command=command; s.description=desc;
        for(int i=0;i<nt;i++){s.tags=realloc(s.tags,sizeof(char*)*(s.ntags+1));s.tags[s.ntags++]=xstrdup(tags[i]);}
        if (idx>=0) { free_script(&cfg.items[idx]); cfg.items[idx]=s; } else add_script(&cfg,s);
        save_config(config_path,&cfg); printf("Added %s\n", alias); return 0;
    }
    if (!strcmp(cmd,"list")||!strcmp(cmd,"ls")) { cmd_list(&cfg, argc-ai, argv+ai); return 0; }
    if (!strcmp(cmd,"show")) { if (ai>=argc) die("The following required arguments were not provided:\n    <alias>"); int idx=find_script(&cfg,argv[ai]); if(idx<0) die("AliasNotFound: No script found by alias %s",argv[ai]); puts(cfg.items[idx].command); return 0; }
    if (!strcmp(cmd,"run")) { if (ai>=argc) die("The following required arguments were not provided:\n    <alias>"); int idx=find_script(&cfg,argv[ai]); if(idx<0) die("AliasNotFound: No script found by alias %s",argv[ai]); run_script(&cfg.items[idx], argc-ai-1, argv+ai+1); return 0; }
    if (!strcmp(cmd,"remove")||!strcmp(cmd,"rm")) { if(ai>=argc) die("The following required arguments were not provided:\n    <alias>"); int idx=find_script(&cfg,argv[ai]); if(idx<0) die("AliasNotFound: No script found by alias %s",argv[ai]); char *a=xstrdup(argv[ai]); free_script(&cfg.items[idx]); memmove(&cfg.items[idx],&cfg.items[idx+1],sizeof(Script)*(cfg.len-idx-1)); cfg.len--; save_config(config_path,&cfg); printf("Removed %s\n",a); return 0; }
    if (!strcmp(cmd,"copy")||!strcmp(cmd,"cp")) { if(ai+1>=argc) die("Missing arguments"); int from=find_script(&cfg,argv[ai]); if(from<0) die("AliasNotFound: No script found by alias %s",argv[ai]); if(find_script(&cfg,argv[ai+1])>=0) die("AliasAlreadyExists:  %s",argv[ai+1]); Script *o=&cfg.items[from], s={0}; s.alias=xstrdup(argv[ai+1]); s.command=xstrdup(o->command); s.description=xstrdup(o->description); for(int j=0;j<o->ntags;j++){s.tags=realloc(s.tags,sizeof(char*)*(s.ntags+1));s.tags[s.ntags++]=xstrdup(o->tags[j]);} add_script(&cfg,s); save_config(config_path,&cfg); printf("Copy from alias %s to new alias %s\n",argv[ai],argv[ai+1]); return 0; }
    if (!strcmp(cmd,"move")||!strcmp(cmd,"mv")||!strcmp(cmd,"rename")) { bool force=false; if(ai<argc && (!strcmp(argv[ai],"-f")||!strcmp(argv[ai],"--force"))){force=true;ai++;} if(ai+1>=argc) die("Missing arguments"); int from=find_script(&cfg,argv[ai]); if(from<0) die("AliasNotFound: No script found by alias %s",argv[ai]); int to=find_script(&cfg,argv[ai+1]); if(to>=0 && !force) die("AliasAlreadyExists:  %s",argv[ai+1]); if(to>=0){free_script(&cfg.items[to]); memmove(&cfg.items[to],&cfg.items[to+1],sizeof(Script)*(cfg.len-to-1)); cfg.len--; if(from>to) from--;} free(cfg.items[from].alias); cfg.items[from].alias=xstrdup(argv[ai+1]); save_config(config_path,&cfg); printf("Move from alias %s to new alias %s\n",argv[ai],argv[ai+1]); return 0; }
    if (!strcmp(cmd,"edit")) die("EditorError: Failed when trying to get input from editor Failed to open `vi` as a text editor or editor was terminated with errors.");
    int idx=find_script(&cfg,cmd); if(idx<0) die("AliasNotFound: No script found by alias %s",cmd); run_script(&cfg.items[idx], argc-ai, argv+ai);
    return 0;
}
