#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    int ignore_case, smart_case, literal, word, invert;
    int count, files_with_matches, files_without_matches, only_matching;
    int column, vimgrep, heading, noheading, break_between;
    int show_filename, no_filename, show_numbers, no_numbers;
    int hidden, unrestricted, all_types, all_text, search_binary;
    int recurse, follow, max_depth, after, before, max_count;
    int null_sep, silent, stats, stats_only, print_all_files;
    char *file_regex;
    char **ignores;
    int ignore_count, ignore_cap;
    char **type_exts;
    int type_ext_count;
} Options;

typedef struct {
    Options opt;
    char *pattern;
    regex_t re;
    bool use_re;
    int any_match;
    long files_scanned;
    long matches;
    int paths_count;
} App;

typedef struct {
    char *text;
    int num;
    int match_count;
    int first_col;
    regmatch_t *matches;
} Line;

static void die_nomem(void){ fprintf(stderr, "ag: out of memory\n"); exit(2); }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) die_nomem(); return p; }

static void add_ignore(Options *o, const char *pat) {
    if (!pat || !*pat) return;
    if (o->ignore_count == o->ignore_cap) {
        o->ignore_cap = o->ignore_cap ? o->ignore_cap * 2 : 16;
        o->ignores = realloc(o->ignores, sizeof(char*) * o->ignore_cap);
        if (!o->ignores) die_nomem();
    }
    o->ignores[o->ignore_count++] = xstrdup(pat);
}

static int has_upper(const char *s){ for(;*s;s++) if(isupper((unsigned char)*s)) return 1; return 0; }

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static const char *display_path(const char *p) {
    while (p[0] == '.' && p[1] == '/') p += 2;
    return p;
}

static int ends_with_ext(const char *path, char **exts, int n) {
    if (n == 0) return 1;
    const char *b = base_name(path);
    const char *dot = strrchr(b, '.');
    for (int i = 0; i < n; i++) {
        if (dot && strcmp(dot + 1, exts[i]) == 0) return 1;
        if (strcmp(b, exts[i]) == 0) return 1;
    }
    return 0;
}

static char *strcasestr_local(const char *h, const char *n) {
    size_t nl = strlen(n);
    if (!nl) return (char*)h;
    for (; *h; h++) if (tolower((unsigned char)*h) == tolower((unsigned char)*n)) {
        size_t i;
        for (i = 1; i < nl; i++) if (!h[i] || tolower((unsigned char)h[i]) != tolower((unsigned char)n[i])) break;
        if (i == nl) return (char*)h;
    }
    return NULL;
}

static int word_boundary(const char *line, int start, int end) {
    int before = start > 0 && (isalnum((unsigned char)line[start-1]) || line[start-1] == '_');
    int after = line[end] && (isalnum((unsigned char)line[end]) || line[end] == '_');
    return !before && !after;
}

static int literal_matches(App *app, const char *line, regmatch_t **out) {
    const char *needle = app->pattern;
    size_t nl = strlen(needle);
    int cap = 0, cnt = 0;
    regmatch_t *ms = NULL;
    if (nl == 0) return 0;
    const char *p = line;
    while (*p) {
        char *q = app->opt.ignore_case ? strcasestr_local(p, needle) : strstr(p, needle);
        if (!q) break;
        int s = (int)(q - line), e = s + (int)nl;
        if (!app->opt.word || word_boundary(line, s, e)) {
            if (cnt == cap) { cap = cap ? cap * 2 : 4; ms = realloc(ms, sizeof(regmatch_t) * cap); if (!ms) die_nomem(); }
            ms[cnt].rm_so = s; ms[cnt].rm_eo = e; cnt++;
        }
        p = q + (nl ? nl : 1);
    }
    *out = ms;
    return cnt;
}

static int regex_matches(App *app, const char *line, regmatch_t **out) {
    int cap = 0, cnt = 0, off = 0;
    regmatch_t m;
    regmatch_t *ms = NULL;
    size_t len = strlen(line);
    while (off <= (int)len && regexec(&app->re, line + off, 1, &m, 0) == 0) {
        if (m.rm_so < 0) break;
        int s = off + (int)m.rm_so, e = off + (int)m.rm_eo;
        if (e < s) break;
        if (!app->opt.word || word_boundary(line, s, e)) {
            if (cnt == cap) { cap = cap ? cap * 2 : 4; ms = realloc(ms, sizeof(regmatch_t) * cap); if (!ms) die_nomem(); }
            ms[cnt].rm_so = s; ms[cnt].rm_eo = e; cnt++;
        }
        if (e == off) off++; else off = e;
    }
    *out = ms;
    return cnt;
}

static int line_matches(App *app, const char *line, regmatch_t **out) {
    int cnt = app->use_re ? regex_matches(app, line, out) : literal_matches(app, line, out);
    if (app->opt.invert) {
        if (cnt) { free(*out); *out = NULL; return 0; }
        *out = calloc(1, sizeof(regmatch_t)); if (!*out) die_nomem();
        (*out)[0].rm_so = 0; (*out)[0].rm_eo = (regoff_t)strlen(line);
        return 1;
    }
    return cnt;
}

static void print_sep(App *app, const char *path, int line, int col, int context, const char *text) {
    if (app->opt.stats_only) return;
    if (app->opt.show_filename && !app->opt.heading) printf("%s%c", display_path(path), context ? '-' : ':');
    if (!app->opt.no_numbers && app->opt.show_numbers) printf("%d%c", line, context ? '-' : ':');
    if (app->opt.column && col > 0 && !context) printf("%d:", col);
    fputs(text, stdout);
    size_t l = strlen(text);
    if (l == 0 || text[l-1] != '\n') putchar('\n');
}

static void print_match_line(App *app, const char *path, Line *ln) {
    if (app->opt.only_matching) {
        for (int i = 0; i < ln->match_count; i++) {
            if (app->opt.show_filename && !app->opt.heading) printf("%s:", display_path(path));
            if (!app->opt.no_numbers && app->opt.show_numbers) printf("%d:", ln->num);
            if (app->opt.column || app->opt.vimgrep) printf("%ld:", (long)ln->matches[i].rm_so + 1);
            fwrite(ln->text + ln->matches[i].rm_so, 1, ln->matches[i].rm_eo - ln->matches[i].rm_so, stdout);
            putchar('\n');
        }
    } else if (app->opt.vimgrep) {
        for (int i = 0; i < ln->match_count; i++) {
            if (app->opt.show_filename) printf("%s:", display_path(path));
            printf("%d:%ld:%s", ln->num, (long)ln->matches[i].rm_so + 1, ln->text);
            if (ln->text[strlen(ln->text)-1] != '\n') putchar('\n');
        }
    } else {
        print_sep(app, path, ln->num, ln->first_col, 0, ln->text);
    }
}

static void free_lines(Line *lines, int n) {
    for (int i = 0; i < n; i++) { free(lines[i].text); free(lines[i].matches); }
    free(lines);
}

static int is_binary_file(FILE *f) {
    unsigned char buf[4096];
    size_t n = fread(buf, 1, sizeof(buf), f);
    for (size_t i = 0; i < n; i++) if (buf[i] == 0) { rewind(f); return 1; }
    rewind(f);
    return 0;
}

static int search_stream(App *app, FILE *f, const char *path, int is_stdin) {
    char *buf = NULL; size_t cap = 0; ssize_t n;
    Line *lines = NULL; int count = 0, lcap = 0, matched_lines = 0, total_matches = 0;
    int line_no = 0;
    while ((n = getline(&buf, &cap, f)) != -1) {
        line_no++;
        regmatch_t *ms = NULL;
        int mc = line_matches(app, buf, &ms);
        if (mc > 0) { matched_lines++; total_matches += mc; }
        if (count == lcap) { lcap = lcap ? lcap * 2 : 128; lines = realloc(lines, sizeof(Line) * lcap); if (!lines) die_nomem(); }
        lines[count].text = xstrdup(buf);
        lines[count].num = line_no;
        lines[count].match_count = mc;
        lines[count].first_col = mc ? (int)ms[0].rm_so + 1 : 0;
        lines[count].matches = ms;
        count++;
        if (app->opt.max_count > 0 && total_matches >= app->opt.max_count) break;
    }
    free(buf);
    int has = total_matches > 0;
    app->files_scanned++;
    app->matches += total_matches;
    if (app->opt.files_with_matches || app->opt.files_without_matches) {
        int print = app->opt.files_with_matches ? has : !has;
        if (print && !app->opt.stats_only) printf("%s%c", display_path(path), app->opt.null_sep ? '\0' : '\n');
        if (print) app->any_match = 1;
        free_lines(lines, count);
        return has;
    }
    if (app->opt.count || app->opt.stats_only) {
        if (app->opt.count && !app->opt.stats_only && (has || app->opt.print_all_files)) {
            if (app->opt.show_filename) printf("%s:", display_path(path));
            printf("%d\n", total_matches);
        }
        if (has) app->any_match = 1;
        free_lines(lines, count);
        return has;
    }
    if (!has) { free_lines(lines, count); return 0; }
    app->any_match = 1;
    static char *last_path = NULL;
    if (!is_stdin && app->opt.break_between && last_path && strcmp(last_path, path) != 0 && !app->opt.heading) putchar('\n');
    if (app->opt.heading && !is_stdin) printf("%s\n", display_path(path));
    free(last_path); last_path = xstrdup(path);
    int *print = calloc(count, sizeof(int)); if (!print) die_nomem();
    for (int i = 0; i < count; i++) if (lines[i].match_count) {
        int a = app->opt.only_matching || app->opt.vimgrep ? 0 : app->opt.after;
        int b = app->opt.only_matching || app->opt.vimgrep ? 0 : app->opt.before;
        for (int j = i - b; j <= i + a; j++) if (j >= 0 && j < count) print[j] = 1;
    }
    for (int i = 0; i < count; i++) if (print[i]) {
        if (lines[i].match_count) print_match_line(app, path, &lines[i]);
        else print_sep(app, path, lines[i].num, 0, 1, lines[i].text);
    }
    if (app->opt.heading) putchar('\n');
    free(print); free_lines(lines, count);
    return 1;
}

static void load_ignore_file(App *app, const char *dir, const char *name) {
    if (app->opt.unrestricted || app->opt.all_types) return;
    char path[4096];
    snprintf(path, sizeof(path), "%s/%s", dir, name);
    FILE *f = fopen(path, "r");
    if (!f) return;
    char *line = NULL; size_t cap = 0;
    while (getline(&line, &cap, f) != -1) {
        char *s = line;
        while (*s && isspace((unsigned char)*s)) s++;
        char *e = s + strlen(s);
        while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
        if (*s && *s != '#') add_ignore(&app->opt, s[0] == '/' ? s + 1 : s);
    }
    free(line); fclose(f);
}

static int ignored(App *app, const char *path, const char *name, int is_dir) {
    if (!app->opt.hidden && name[0] == '.') return 1;
    if (!app->opt.unrestricted && is_dir && (!strcmp(name, ".git") || !strcmp(name, ".hg") || !strcmp(name, ".svn"))) return 1;
    if (app->opt.unrestricted || app->opt.all_types) return 0;
    for (int i = 0; i < app->opt.ignore_count; i++) {
        const char *p = app->opt.ignores[i];
        if (fnmatch(p, name, 0) == 0 || fnmatch(p, path, FNM_PATHNAME) == 0) return 1;
        char pat[1024]; snprintf(pat, sizeof(pat), "*/%s", p);
        if (fnmatch(pat, path, FNM_PATHNAME) == 0) return 1;
    }
    return 0;
}

static int path_file_regex_ok(App *app, const char *path) {
    if (!app->opt.file_regex) return 1;
    regex_t r; int rc = regcomp(&r, app->opt.file_regex, REG_EXTENDED | REG_NOSUB);
    if (rc) return 1;
    int ok = regexec(&r, path, 0, NULL, 0) == 0;
    regfree(&r);
    return ok;
}

static int search_file(App *app, const char *path) {
    if (!ends_with_ext(path, app->opt.type_exts, app->opt.type_ext_count)) return 0;
    if (!path_file_regex_ok(app, path)) return 0;
    FILE *f = fopen(path, "rb");
    if (!f) { if (!app->opt.silent) fprintf(stderr, "ERR: Error opening file %s: %s\n", path, strerror(errno)); return 0; }
    if (!app->opt.search_binary && !app->opt.unrestricted && !app->opt.all_text && is_binary_file(f)) { fclose(f); return 0; }
    int r = search_stream(app, f, path, 0);
    fclose(f);
    return r;
}

static void filename_search(App *app, const char *path) {
    regex_t r; int flags = REG_EXTENDED | REG_NOSUB | (app->opt.ignore_case ? REG_ICASE : 0);
    if (regcomp(&r, app->pattern, flags) != 0) return;
    if (regexec(&r, path, 0, NULL, 0) == 0) { puts(display_path(path)); app->any_match = 1; }
    regfree(&r);
}

static void walk(App *app, const char *path, int depth) {
    struct stat st;
    if ((app->opt.follow ? stat(path, &st) : lstat(path, &st)) != 0) { if(!app->opt.silent) perror(path); return; }
    const char *name = base_name(path);
    if (depth > 0 && ignored(app, path, name, S_ISDIR(st.st_mode))) return;
    if (S_ISDIR(st.st_mode)) {
        if (!app->opt.recurse && depth > 0) return;
        if (app->opt.max_depth >= 0 && depth > app->opt.max_depth) return;
        load_ignore_file(app, path, ".ignore");
        load_ignore_file(app, path, ".gitignore");
        DIR *d = opendir(path);
        if (!d) { if(!app->opt.silent) perror(path); return; }
        struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
            char child[4096];
            snprintf(child, sizeof(child), "%s/%s", path, de->d_name);
            walk(app, child, depth + 1);
        }
        closedir(d);
    } else if (S_ISREG(st.st_mode)) {
        if (app->opt.file_regex && app->pattern == app->opt.file_regex) filename_search(app, path);
        else search_file(app, path);
    }
}

static void print_version(void) {
    puts("ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib");
}

static void print_help(void) {
    puts("\nUsage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]\n\n  Recursively search for PATTERN in PATH.\n  Like grep or ack, but faster.\n\nExample:\n  ag -i foo /bar/\n\nOutput Options:\n     --ackmate            Print results in AckMate-parseable format\n  -A --after [LINES]      Print lines after match (Default: 2)\n  -B --before [LINES]     Print lines before match (Default: 2)\n     --[no]break          Print newlines between matches in different files\n                          (Enabled by default)\n  -c --count              Only print the number of matches in each file.\n     --[no]color          Print color codes in results (Enabled by default)\n     --column             Print column numbers in results\n     --[no]filename       Print file names (Enabled unless searching a single file)\n  -H --[no]heading        Print file names before each file's matches\n  -C --context [LINES]    Print lines before and after matches (Default: 2)\n     --[no]group          Same as --[no]break --[no]heading\n  -g --filename-pattern PATTERN\n                          Print filenames matching PATTERN\n  -l --files-with-matches Only print filenames that contain matches\n  -L --files-without-matches\n                          Only print filenames that don't contain matches\n     --[no]numbers        Print line numbers. Default is to omit line numbers\n                          when searching streams\n  -o --only-matching      Prints only the matching part of the lines\n     --passthrough        When searching a stream, print all lines even if they\n                          don't match\n     --silent             Suppress all log messages, including errors\n     --stats              Print stats (files scanned, time taken, etc.)\n     --stats-only         Print stats and nothing else.\n     --vimgrep            Print results like vim's :vimgrep /pattern/g would\n  -0 --null --print0      Separate filenames with null (for 'xargs -0')\n\nSearch Options:\n  -a --all-types          Search all files\n  -D --debug              Ridiculous debugging (probably not useful)\n     --depth NUM          Search up to NUM directories deep (Default: 25)\n  -f --follow             Follow symlinks\n  -F --fixed-strings      Alias for --literal for compatibility with grep\n  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN\n     --hidden             Search hidden files (obeys .*ignore files)\n  -i --ignore-case        Match case insensitively\n     --ignore PATTERN     Ignore files/directories matching PATTERN\n  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)\n  -Q --literal            Don't parse PATTERN as a regular expression\n  -s --case-sensitive     Match case sensitively\n  -S --smart-case         Match case insensitively unless PATTERN contains uppercase characters\n  -t --all-text           Search all text files\n  -u --unrestricted       Search all files\n  -U --skip-vcs-ignores   Ignore VCS ignore files\n  -v --invert-match\n  -w --word-regexp        Only match whole words\n  -z --search-zip         Search contents of compressed files\n\nFile Types:\nFor a list of supported file types run:\n  ag --list-file-types\n");
}

static void print_types(void) {
    puts("The following file types are supported:\n  --cc\n      .c  .h  .xs\n\n  --cpp\n      .cpp  .cc  .C  .cxx  .m  .hpp  .hh  .h  .H  .hxx  .tpp\n\n  --css\n      .css\n\n  --go\n      .go\n\n  --html\n      .htm  .html  .shtml  .xhtml\n\n  --java\n      .java  .properties\n\n  --js\n      .es6  .js  .jsx  .vue\n\n  --json\n      .json\n\n  --markdown\n      .markdown  .mdown  .mdwn  .mkdn  .mkd  .md\n\n  --md\n      .markdown  .mdown  .mdwn  .mkdn  .mkd  .md\n\n  --php\n      .php  .phpt  .php3  .php4  .php5  .phtml\n\n  --python\n      .py\n\n  --ruby\n      .rb  .rhtml  .rjs  .rxml  .erb  .rake  .gemspec\n\n  --rust\n      .rs\n\n  --shell\n      .sh  .bash  .csh  .tcsh  .ksh  .zsh  .fish\n\n  --txt\n      .txt\n\n  --xml\n      .xml  .dtd  .xsl  .xslt  .ent\n");
}

static int need_arg(int i, int argc, const char *opt){ if(i+1>=argc){ fprintf(stderr,"ERR: option %s requires an argument\n", opt); exit(2);} return i+1; }
static int optional_num(int *i, int argc, char **argv, int def) {
    if (*i + 1 < argc && argv[*i + 1][0] != '-' && isdigit((unsigned char)argv[*i + 1][0])) {
        (*i)++;
        return atoi(argv[*i]);
    }
    return def;
}

static void set_type(Options *o, const char *name) {
    static char *cc[]={"c","h","xs"}, *cpp[]={"cpp","cc","C","cxx","m","hpp","hh","h","H","hxx","tpp"};
    static char *py[]={"py"}, *js[]={"js","jsx","vue","es6"}, *md[]={"md","markdown","mdown","mdwn","mkdn","mkd"};
    static char *go[]={"go"}, *rs[]={"rs"}, *java[]={"java","properties"}, *php[]={"php","phpt","php3","php4","php5","phtml"};
    static char *html[]={"htm","html","shtml","xhtml"}, *css[]={"css"}, *sh[]={"sh","bash","zsh","fish","ksh","csh","tcsh"}, *txt[]={"txt"};
    struct { const char *n; char **e; int c; } types[] = {
        {"cc",cc,3},{"c",cc,3},{"cpp",cpp,11},{"python",py,1},{"py",py,1},{"js",js,4},{"javascript",js,4},
        {"markdown",md,6},{"md",md,6},{"go",go,1},{"rust",rs,1},{"rs",rs,1},{"java",java,2},{"php",php,6},
        {"html",html,4},{"css",css,1},{"shell",sh,7},{"sh",sh,7},{"txt",txt,1},{NULL,NULL,0}
    };
    for (int i=0; types[i].n; i++) if (!strcmp(name, types[i].n)) { o->type_exts=types[i].e; o->type_ext_count=types[i].c; return; }
}

int main(int argc, char **argv) {
    App app; memset(&app, 0, sizeof(app));
    Options *o = &app.opt;
    o->smart_case = 1; o->recurse = 1; o->max_depth = 25; o->break_between = 1; o->show_numbers = 1; o->max_count = 0;
    char **pos = calloc(argc + 1, sizeof(char*)); if(!pos) die_nomem(); int pc = 0;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a,"--help") || !strcmp(a,"-h")) { print_help(); return 0; }
        else if (!strcmp(a,"--version") || !strcmp(a,"-V")) { print_version(); return 0; }
        else if (!strcmp(a,"--list-file-types")) { print_types(); return 0; }
        else if (!strcmp(a,"-i") || !strcmp(a,"--ignore-case")) { o->ignore_case=1; o->smart_case=0; }
        else if (!strcmp(a,"-s") || !strcmp(a,"--case-sensitive")) { o->ignore_case=0; o->smart_case=0; }
        else if (!strcmp(a,"-S") || !strcmp(a,"--smart-case")) { o->smart_case=1; }
        else if (!strcmp(a,"-Q") || !strcmp(a,"--literal") || !strcmp(a,"-F") || !strcmp(a,"--fixed-strings")) o->literal=1;
        else if (!strcmp(a,"-w") || !strcmp(a,"--word-regexp")) o->word=1;
        else if (!strcmp(a,"-v") || !strcmp(a,"--invert-match")) o->invert=1;
        else if (!strcmp(a,"-c") || !strcmp(a,"--count")) o->count=1;
        else if (!strcmp(a,"-l") || !strcmp(a,"--files-with-matches")) o->files_with_matches=1;
        else if (!strcmp(a,"-L") || !strcmp(a,"--files-without-matches")) o->files_without_matches=1;
        else if (!strcmp(a,"-o") || !strcmp(a,"--only-matching")) o->only_matching=1;
        else if (!strcmp(a,"--column")) o->column=1;
        else if (!strcmp(a,"--vimgrep")) { o->vimgrep=1; o->column=1; o->heading=0; }
        else if (!strcmp(a,"--heading") || !strcmp(a,"-H")) o->heading=1;
        else if (!strcmp(a,"--noheading") || !strcmp(a,"--no-heading") || !strcmp(a,"--nogroup") || !strcmp(a,"--no-group")) o->heading=0;
        else if (!strcmp(a,"--group")) o->heading=1;
        else if (!strcmp(a,"--nobreak") || !strcmp(a,"--no-break")) o->break_between=0;
        else if (!strcmp(a,"--break")) o->break_between=1;
        else if (!strcmp(a,"--filename")) o->show_filename=1;
        else if (!strcmp(a,"--nofilename") || !strcmp(a,"--no-filename")) o->no_filename=1;
        else if (!strcmp(a,"--numbers") || !strcmp(a,"-n")) o->show_numbers=1;
        else if (!strcmp(a,"--nonumbers") || !strcmp(a,"--no-numbers")) o->no_numbers=1;
        else if (!strcmp(a,"--hidden")) o->hidden=1;
        else if (!strcmp(a,"-u") || !strcmp(a,"--unrestricted")) { o->unrestricted=1; o->hidden=1; o->search_binary=1; }
        else if (!strcmp(a,"-a") || !strcmp(a,"--all-types")) o->all_types=1;
        else if (!strcmp(a,"-t") || !strcmp(a,"--all-text")) o->all_text=1;
        else if (!strcmp(a,"--search-binary")) o->search_binary=1;
        else if (!strcmp(a,"-r") || !strcmp(a,"--recurse")) o->recurse=1;
        else if (!strcmp(a,"-n") || !strcmp(a,"--norecurse")) o->recurse=0;
        else if (!strcmp(a,"-f") || !strcmp(a,"--follow")) o->follow=1;
        else if (!strcmp(a,"--silent")) o->silent=1;
        else if (!strcmp(a,"--stats")) o->stats=1;
        else if (!strcmp(a,"--stats-only")) { o->stats=1; o->stats_only=1; }
        else if (!strcmp(a,"--print-all-files")) o->print_all_files=1;
        else if (!strcmp(a,"-0") || !strcmp(a,"--null") || !strcmp(a,"--print0")) o->null_sep=1;
        else if (!strcmp(a,"--nocolor") || !strcmp(a,"--no-color") || !strcmp(a,"--color") || !strcmp(a,"--ackmate") || !strcmp(a,"--pager") || !strcmp(a,"--nopager") || !strcmp(a,"--parallel") || !strcmp(a,"--passthrough") || !strcmp(a,"--passthru") || !strcmp(a,"--print-long-lines") || !strcmp(a,"--mmap") || !strcmp(a,"--nommap") || !strcmp(a,"--multiline") || !strcmp(a,"--nomultiline") || !strcmp(a,"--one-device") || !strcmp(a,"-z") || !strcmp(a,"--search-zip") || !strcmp(a,"-D") || !strcmp(a,"--debug") || !strcmp(a,"-U") || !strcmp(a,"--skip-vcs-ignores")) { if (!strcmp(a,"--pager")) i = need_arg(i, argc, a); }
        else if (!strcmp(a,"-A") || !strcmp(a,"--after")) { o->after=optional_num(&i,argc,argv,2); }
        else if (!strcmp(a,"-B") || !strcmp(a,"--before")) { o->before=optional_num(&i,argc,argv,2); }
        else if (!strcmp(a,"-C") || !strcmp(a,"--context")) { o->after=o->before=optional_num(&i,argc,argv,2); }
        else if (!strcmp(a,"-m") || !strcmp(a,"--max-count")) { i=need_arg(i,argc,a); o->max_count=atoi(argv[i]); }
        else if (!strcmp(a,"--depth")) { i=need_arg(i,argc,a); o->max_depth=atoi(argv[i]); }
        else if (!strcmp(a,"-G") || !strcmp(a,"--file-search-regex")) { i=need_arg(i,argc,a); o->file_regex=argv[i]; }
        else if (!strcmp(a,"-g") || !strcmp(a,"--filename-pattern")) { i=need_arg(i,argc,a); o->file_regex=argv[i]; app.pattern=o->file_regex; }
        else if (!strcmp(a,"--ignore") || !strcmp(a,"--ignore-dir")) { i=need_arg(i,argc,a); add_ignore(o, argv[i]); }
        else if (!strcmp(a,"-p") || !strcmp(a,"--path-to-ignore")) { i=need_arg(i,argc,a); FILE *f=fopen(argv[i],"r"); if(f){char *ln=NULL;size_t cp=0;while(getline(&ln,&cp,f)!=-1){ln[strcspn(ln,"\r\n")]=0;add_ignore(o,ln);}free(ln);fclose(f);} }
        else if (!strncmp(a, "--", 2)) { set_type(o, a+2); }
        else pos[pc++] = a;
    }
    if (!app.pattern) {
        if (pc == 0) { print_help(); free(pos); return 2; }
        app.pattern = pos[0];
    }
    int first_path = (app.pattern == pos[0]) ? 1 : 0;
    if (o->smart_case) o->ignore_case = !has_upper(app.pattern);
    app.use_re = !o->literal && !o->file_regex == 0;
    if (!o->literal && !(o->file_regex && app.pattern == o->file_regex)) {
        int flags = REG_EXTENDED | (o->ignore_case ? REG_ICASE : 0);
        int rc = regcomp(&app.re, app.pattern, flags);
        if (rc) { char err[256]; regerror(rc, &app.re, err, sizeof(err)); fprintf(stderr, "ERR: Error in regex: %s\n", err); free(pos); return 2; }
        app.use_re = 1;
    } else app.use_re = 0;
    app.paths_count = pc - first_path;
    o->show_filename = !o->no_filename && (o->show_filename || app.paths_count != 1 || (app.paths_count == 1 && ({struct stat st; stat(pos[first_path], &st)==0 && S_ISDIR(st.st_mode);})));
    if (app.paths_count == 0) {
        o->show_filename = 0;
        o->show_numbers = o->show_numbers && !o->no_numbers ? 0 : o->show_numbers;
        search_stream(&app, stdin, "", 1);
    } else {
        for (int i = first_path; i < pc; i++) walk(&app, pos[i], 0);
    }
    if (o->stats) fprintf(stderr, "%ld matches\n%ld files scanned\n", app.matches, app.files_scanned);
    if (app.use_re) regfree(&app.re);
    free(pos);
    return app.any_match ? 0 : 1;
}
