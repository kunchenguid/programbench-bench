#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *buf;
    size_t len;
    size_t cap;
} Str;

typedef struct {
    const char *src;
    size_t pos;
    int err;
    char msg[256];
} Parser;

static void str_init(Str *s) {
    s->cap = 64;
    s->len = 0;
    s->buf = malloc(s->cap);
    if (!s->buf) exit(2);
    s->buf[0] = 0;
}

static void str_reserve(Str *s, size_t add) {
    if (s->len + add + 1 <= s->cap) return;
    while (s->len + add + 1 > s->cap) s->cap *= 2;
    s->buf = realloc(s->buf, s->cap);
    if (!s->buf) exit(2);
}

static void str_addn(Str *s, const char *p, size_t n) {
    str_reserve(s, n);
    memcpy(s->buf + s->len, p, n);
    s->len += n;
    s->buf[s->len] = 0;
}

static void str_add(Str *s, const char *p) { str_addn(s, p, strlen(p)); }

static void str_ch(Str *s, char c) {
    str_reserve(s, 1);
    s->buf[s->len++] = c;
    s->buf[s->len] = 0;
}

static char *str_take(Str *s) { return s->buf; }

static void seterr(Parser *p, const char *msg) {
    if (!p->err) {
        p->err = 1;
        snprintf(p->msg, sizeof(p->msg), "%s", msg);
    }
}

static void skip_ws(Parser *p) {
    for (;;) {
        while (isspace((unsigned char)p->src[p->pos])) p->pos++;
        if (p->src[p->pos] == '/' && p->src[p->pos + 1] == '/') {
            p->pos += 2;
            while (p->src[p->pos] && p->src[p->pos] != '\n') p->pos++;
            continue;
        }
        break;
    }
}

static bool starts_word(Parser *p, const char *w) {
    size_t n = strlen(w);
    if (strncmp(p->src + p->pos, w, n) != 0) return false;
    char c = p->src[p->pos + n];
    return !(isalnum((unsigned char)c) || c == '_' || c == '-');
}

static bool take_word(Parser *p, const char *w) {
    skip_ws(p);
    if (!starts_word(p, w)) return false;
    p->pos += strlen(w);
    return true;
}

static bool take_char(Parser *p, char c) {
    skip_ws(p);
    if (p->src[p->pos] != c) return false;
    p->pos++;
    return true;
}

static char *parse_sequence(Parser *p, char end);
static char *parse_expr(Parser *p);

static bool is_meta(char c) {
    return c == '.' || c == '*' || c == '+' || c == '?' || c == '^' || c == '$' ||
           c == '{' || c == '}' || c == '(' || c == ')' || c == '|' ||
           c == '[' || c == ']' || c == '\\';
}

static char *parse_string(Parser *p) {
    skip_ws(p);
    if (p->src[p->pos] != '"') {
        seterr(p, "expected root");
        return strdup("");
    }
    p->pos++;
    Str out;
    str_init(&out);
    while (p->src[p->pos] && p->src[p->pos] != '"') {
        char c = p->src[p->pos++];
        if (c == '\\' && p->src[p->pos]) {
            char e = p->src[p->pos++];
            if (e == '"' ) {
                str_ch(&out, '"');
            } else if (e == '\\') {
                str_add(&out, "\\\\");
            } else {
                str_ch(&out, '\\');
                str_ch(&out, e);
            }
        } else {
            if (is_meta(c)) str_ch(&out, '\\');
            str_ch(&out, c);
        }
    }
    if (p->src[p->pos] != '"') seterr(p, "expected root");
    else p->pos++;
    return str_take(&out);
}

static const char *symbol_regex(const char *name, bool neg) {
    if (!strcmp(name, "char")) return neg ? NULL : ".";
    if (!strcmp(name, "space")) return neg ? "[^ ]" : " ";
    if (!strcmp(name, "whitespace")) return neg ? "\\S" : "\\s";
    if (!strcmp(name, "digit")) return neg ? "\\D" : "\\d";
    if (!strcmp(name, "word")) return neg ? "\\W" : "\\w";
    if (!strcmp(name, "alphabetic")) return neg ? "[^a-zA-Z]" : "[a-zA-Z]";
    if (!strcmp(name, "alphanumeric")) return neg ? "[^a-zA-Z0-9]" : "[a-zA-Z0-9]";
    if (!strcmp(name, "newline")) return neg ? "[^\\n]" : "\\n";
    if (!strcmp(name, "tab")) return neg ? "[^\\t]" : "\\t";
    if (!strcmp(name, "return")) return neg ? "[^\\r]" : "\\r";
    if (!strcmp(name, "vertical")) return neg ? "[^\\v]" : "\\v";
    if (!strcmp(name, "null")) return neg ? "[^\\0]" : "\\0";
    if (!strcmp(name, "backspace")) return neg ? "[^\\b]" : "[\\b]";
    if (!strcmp(name, "start")) return neg ? NULL : "^";
    if (!strcmp(name, "end")) return neg ? NULL : "$";
    if (!strcmp(name, "boundary")) return neg ? "\\B" : "\\b";
    return NULL;
}

static char *parse_symbol(Parser *p, bool neg) {
    skip_ws(p);
    if (p->src[p->pos] != '<') {
        seterr(p, "expected root");
        return strdup("");
    }
    p->pos++;
    size_t st = p->pos;
    while (p->src[p->pos] && p->src[p->pos] != '>') p->pos++;
    if (p->src[p->pos] != '>') {
        seterr(p, "usage of an unrecognized symbol");
        return strdup("");
    }
    char *name = strndup(p->src + st, p->pos - st);
    p->pos++;
    const char *r = symbol_regex(name, neg);
    free(name);
    if (!r) {
        seterr(p, neg ? "negative char not allowed" : "usage of an unrecognized symbol");
        return strdup("");
    }
    return strdup(r);
}

static char *parse_block(Parser *p) {
    if (!take_char(p, '{')) {
        seterr(p, "expected block");
        return strdup("");
    }
    char *inner = parse_sequence(p, '}');
    take_char(p, '}');
    return inner;
}

static char *wrap(const char *pre, char *mid, const char *post) {
    Str s;
    str_init(&s);
    str_add(&s, pre);
    str_add(&s, mid);
    str_add(&s, post);
    free(mid);
    return str_take(&s);
}

static char *parse_identifier_until_block(Parser *p) {
    skip_ws(p);
    size_t st = p->pos;
    while (p->src[p->pos] && p->src[p->pos] != '{') p->pos++;
    size_t en = p->pos;
    while (en > st && isspace((unsigned char)p->src[en - 1])) en--;
    return strndup(p->src + st, en - st);
}

static char *parse_either(Parser *p) {
    if (!take_char(p, '{')) {
        seterr(p, "expected block");
        return strdup("");
    }
    Str out;
    str_init(&out);
    str_add(&out, "(?:");
    bool first = true;
    for (;;) {
        skip_ws(p);
        if (p->src[p->pos] == '}') {
            p->pos++;
            break;
        }
        if (!first) str_ch(&out, '|');
        char *e = parse_expr(p);
        str_add(&out, e);
        free(e);
        first = false;
        take_char(p, ';');
    }
    str_ch(&out, ')');
    return str_take(&out);
}

static char *quantify(char *e, const char *q) {
    Str s;
    str_init(&s);
    size_t n = strlen(e);
    bool atom = false;
    if (n == 1) atom = true;
    else if (n == 2 && e[0] == '\\') atom = true;
    else if (n >= 2 && e[0] == '[' && e[n - 1] == ']') atom = true;
    else if (n >= 3 && e[0] == '(' && e[n - 1] == ')') atom = true;
    if (!atom) str_add(&s, "(?:");
    str_add(&s, e);
    if (!atom) str_ch(&s, ')');
    str_add(&s, q);
    free(e);
    return str_take(&s);
}

static char *parse_number_quant(Parser *p) {
    skip_ws(p);
    size_t st = p->pos;
    while (isdigit((unsigned char)p->src[p->pos])) p->pos++;
    char *a = strndup(p->src + st, p->pos - st);
    skip_ws(p);
    char *q = NULL;
    if (take_word(p, "to")) {
        skip_ws(p);
        size_t st2 = p->pos;
        while (isdigit((unsigned char)p->src[p->pos])) p->pos++;
        char *b = strndup(p->src + st2, p->pos - st2);
        if (!take_word(p, "of")) seterr(p, "expected amount");
        Str qs;
        str_init(&qs);
        str_ch(&qs, '{');
        str_add(&qs, a);
        str_ch(&qs, ',');
        str_add(&qs, b);
        str_ch(&qs, '}');
        q = str_take(&qs);
        free(b);
    } else {
        if (!take_word(p, "of")) seterr(p, "expected amount");
        Str qs;
        str_init(&qs);
        str_ch(&qs, '{');
        str_add(&qs, a);
        str_ch(&qs, '}');
        q = str_take(&qs);
    }
    free(a);
    char *e = parse_expr(p);
    char *res = quantify(e, q);
    free(q);
    return res;
}

static char *parse_expr(Parser *p) {
    skip_ws(p);
    if (p->err) return strdup("");
    if (isdigit((unsigned char)p->src[p->pos])) return parse_number_quant(p);
    if (take_word(p, "some")) {
        if (!take_word(p, "of")) seterr(p, "expected amount");
        return quantify(parse_expr(p), "+");
    }
    if (take_word(p, "any")) {
        if (!take_word(p, "of")) seterr(p, "expected amount");
        return quantify(parse_expr(p), "*");
    }
    if (take_word(p, "option")) {
        if (!take_word(p, "of")) seterr(p, "expected amount");
        return quantify(parse_expr(p), "?");
    }
    if (take_word(p, "not")) {
        if (take_word(p, "ahead")) return wrap("(?!", parse_block(p), ")");
        if (take_word(p, "behind")) return wrap("(?<!", parse_block(p), ")");
        return parse_symbol(p, true);
    }
    if (take_word(p, "match")) return wrap("(?:", parse_block(p), ")");
    if (take_word(p, "either")) return parse_either(p);
    if (take_word(p, "capture")) {
        skip_ws(p);
        if (p->src[p->pos] == '{') return wrap("(", parse_block(p), ")");
        char *name = parse_identifier_until_block(p);
        char *inner = parse_block(p);
        Str s;
        str_init(&s);
        str_add(&s, "(?<");
        str_add(&s, name);
        str_ch(&s, '>');
        str_add(&s, inner);
        str_ch(&s, ')');
        free(name);
        free(inner);
        return str_take(&s);
    }
    if (take_word(p, "ahead")) return wrap("(?=", parse_block(p), ")");
    if (take_word(p, "behind")) return wrap("(?<=", parse_block(p), ")");
    skip_ws(p);
    if (p->src[p->pos] == '"') return parse_string(p);
    if (p->src[p->pos] == '<') return parse_symbol(p, false);
    seterr(p, "expected root");
    return strdup("");
}

static char *parse_sequence(Parser *p, char end) {
    Str out;
    str_init(&out);
    for (;;) {
        skip_ws(p);
        if (!p->src[p->pos] || (end && p->src[p->pos] == end)) break;
        char *e = parse_expr(p);
        str_add(&out, e);
        free(e);
        skip_ws(p);
        take_char(p, ';');
        if (p->err) break;
    }
    return str_take(&out);
}

static char *compile_melody(const char *src, char *err, size_t errsz) {
    Parser p = {src, 0, 0, {0}};
    char *r = parse_sequence(&p, 0);
    skip_ws(&p);
    if (!p.err && p.src[p.pos]) seterr(&p, "expected root");
    if (p.err) {
        snprintf(err, errsz, "%s", p.msg);
        free(r);
        return NULL;
    }
    return r;
}

static char *read_stream(FILE *f) {
    Str s;
    str_init(&s);
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) str_addn(&s, buf, n);
    return str_take(&s);
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    char *s = read_stream(f);
    fclose(f);
    return s;
}

static char *regex_for_posix(const char *r) {
    Str s;
    str_init(&s);
    for (size_t i = 0; r[i]; i++) {
        if (r[i] == '\\' && r[i + 1]) {
            char c = r[++i];
            if (c == 'd') str_add(&s, "[0-9]");
            else if (c == 'D') str_add(&s, "[^0-9]");
            else if (c == 'w') str_add(&s, "[A-Za-z0-9_]");
            else if (c == 'W') str_add(&s, "[^A-Za-z0-9_]");
            else if (c == 's') str_add(&s, "[[:space:]]");
            else if (c == 'S') str_add(&s, "[^[:space:]]");
            else {
                str_ch(&s, '\\');
                str_ch(&s, c);
            }
        } else {
            str_ch(&s, r[i]);
        }
    }
    return str_take(&s);
}

static int test_regex(const char *regex, const char *text, const char *label, bool quote) {
    char *rx = regex_for_posix(regex);
    regex_t re;
    int ok = regcomp(&re, rx, REG_EXTENDED | REG_NEWLINE) == 0;
    int matched = ok && regexec(&re, text, 0, NULL, 0) == 0;
    if (ok) regfree(&re);
    if (quote) printf("'%s' %s\n", label, matched ? "matched" : "did not match");
    else printf("%s %s\n", label, matched ? "matched" : "did not match");
    free(rx);
    return 0;
}

static void print_help(void) {
    puts("A CLI wrapping the Melody language compiler\n");
    puts("Usage: executable [OPTIONS] [INPUT_FILE_PATH]\n");
    puts("Arguments:");
    puts("  [INPUT_FILE_PATH]  Read from a file");
    puts("                     Use '-' and or pipe input to read from stdin\n");
    puts("Options:");
    puts("  -o, --output <OUTPUT_FILE_PATH>           Write to a file");
    puts("  -n, --no-color                            Print output with no color");
    puts("  -r, --repl                                Start the Melody REPL");
    puts("      --generate-completions <completions>  Outputs completions for the selected shell");
    puts("  -t, --test <test>                         Test the compiled regex against a string");
    puts("  -f, --test-file <test-file>               Test the compiled regex against the contents of a file");
    puts("  -h, --help                                Print help");
    puts("  -V, --version                             Print version");
}

int main(int argc, char **argv) {
    const char *input_path = NULL, *out_path = NULL, *test = NULL, *test_file = NULL;
    bool repl = false, completions = false;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            print_help();
            return 0;
        } else if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) {
            puts("melody_cli 0.20.0");
            return 0;
        } else if (!strcmp(argv[i], "-n") || !strcmp(argv[i], "--no-color")) {
        } else if (!strcmp(argv[i], "-r") || !strcmp(argv[i], "--repl")) {
            repl = true;
        } else if (!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output")) {
            if (i + 1 < argc) out_path = argv[++i];
        } else if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--test")) {
            if (i + 1 < argc) test = argv[++i];
        } else if (!strcmp(argv[i], "-f") || !strcmp(argv[i], "--test-file")) {
            if (i + 1 < argc) test_file = argv[++i];
        } else if (!strcmp(argv[i], "--generate-completions")) {
            completions = true;
            if (i + 1 < argc) i++;
        } else if (argv[i][0] == '-' && argv[i][1] && strcmp(argv[i], "-")) {
            fprintf(stderr, "error: unexpected argument '%s'\n", argv[i]);
            return 2;
        } else {
            input_path = argv[i];
        }
    }
    if (completions) return 0;
    if (repl) {
        char line[4096];
        while (fgets(line, sizeof(line), stdin)) {
            char err[256];
            char *r = compile_melody(line, err, sizeof(err));
            if (r) {
                puts(r);
                free(r);
            } else {
                fprintf(stderr, "Error: %s\n", err);
            }
        }
        return 0;
    }

    char *src = NULL;
    if (input_path && strcmp(input_path, "-") != 0) {
        src = read_file(input_path);
        if (!src) {
            fprintf(stderr, "Error: unable read file at path %s\n", input_path);
            return 65;
        }
    } else {
        src = read_stream(stdin);
    }
    if (!src || src[0] == 0) {
        free(src);
        return 0;
    }
    char err[256];
    char *regex = compile_melody(src, err, sizeof(err));
    free(src);
    if (!regex) {
        fprintf(stderr, "Error: %s\n", err);
        return 65;
    }
    if (out_path) {
        FILE *f = fopen(out_path, "wb");
        if (!f) {
            fprintf(stderr, "Error: unable write file at path %s\n", out_path);
            free(regex);
            return 65;
        }
        fputs(regex, f);
        fclose(f);
    } else if (test) {
        test_regex(regex, test, test, true);
    } else if (test_file) {
        char *tf = read_file(test_file);
        if (!tf) {
            fprintf(stderr, "Error: unable read file at path %s\n", test_file);
            free(regex);
            return 65;
        }
        test_regex(regex, tf, test_file, false);
        free(tf);
    } else {
        puts(regex);
    }
    free(regex);
    return 0;
}
