#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define MAX_ITEMS 64
#define MAX_PACKET 4096

typedef struct { const char *name; int code; } Map;
static Map types[] = {
    {"A",1},{"NS",2},{"CNAME",5},{"SOA",6},{"PTR",12},{"HINFO",13},{"MX",15},{"TXT",16},
    {"AAAA",28},{"SRV",33},{"NAPTR",35},{"CAA",257},{"OPT",41},{"SSHFP",44},{"TLSA",52},
    {"ANY",255},{"IXFR",251},{"AXFR",252},{"AFSDB",18},{NULL,0}
};
static Map classes[] = {{"IN",1},{"CH",3},{"HS",4},{NULL,0}};

typedef struct {
    char *queries[MAX_ITEMS]; int nq;
    int qtypes[MAX_ITEMS]; const char *qtnames[MAX_ITEMS]; int nt;
    int qclasses[MAX_ITEMS]; const char *qcnames[MAX_ITEMS]; int nc;
    char *servers[MAX_ITEMS]; int ns;
    bool tcp, tls, https, json, short_out, seconds, timeit;
    unsigned txid; bool txid_set;
} Opts;

typedef struct {
    char name[256], type[32], cls[16], data[512];
    uint32_t ttl; int typeno, clsno;
    char jsondata[768];
} RR;

static void help(FILE *f) {
    fputs("dog \342\227\217 command-line DNS client\n\n"
"Usage:\n"
"  dog [OPTIONS] [--] <arguments>\n\n"
"Examples:\n"
"  dog example.net                          Query a domain using default settings\n"
"  dog example.net MX                       ...looking up MX records instead\n"
"  dog example.net MX @1.1.1.1              ...using a specific nameserver instead\n"
"  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP\n"
"  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments\n\n"
"Query options:\n"
"  <arguments>              Human-readable host names, nameservers, types, or classes\n"
"  -q, --query=HOST         Host name or domain name to query\n"
"  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)\n"
"  -n, --nameserver=ADDR    Address of the nameserver to send packets to\n"
"  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)\n\n"
"Sending options:\n"
"  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)\n"
"  --txid=NUMBER            Set the transaction ID to a specific value\n"
"  -Z=TWEAKS                Set uncommon protocol-level tweaks\n\n"
"Protocol options:\n"
"  -U, --udp                Use the DNS protocol over UDP\n"
"  -T, --tcp                Use the DNS protocol over TCP\n"
"  -S, --tls                Use the DNS-over-TLS protocol\n"
"  -H, --https              Use the DNS-over-HTTPS protocol\n\n"
"Output options:\n"
"  -1, --short              Short mode: display nothing but the first result\n"
"  -J, --json               Display the output as JSON\n"
"  --color, --colour=WHEN   When to colourise the output (always, automatic, never)\n"
"  --seconds                Do not format durations, display them as seconds\n"
"  --time                   Print how long the response took to arrive\n\n"
"Meta options:\n"
"  -?, --help               Print list of command-line options\n"
"  -v, --version            Print version information\n", f);
}

static void version(void) {
    puts("dog \342\227\217 command-line DNS client");
    puts("v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)");
    puts("mhttps://dns.lookup.dog/");
}

static int map_lookup(Map *m, const char *s) {
    for (int i=0; m[i].name; i++) if (!strcasecmp(m[i].name, s)) return m[i].code;
    return -1;
}
static const char *map_name(Map *m, int code) {
    static char buf[32];
    for (int i=0; m[i].name; i++) if (m[i].code == code) return m[i].name;
    snprintf(buf, sizeof buf, "TYPE%d", code); return buf;
}
static char *xstrdup(const char *s) { char *p = strdup(s); if (!p) exit(1); return p; }
static void add_query(Opts *o, const char *s) { if (o->nq < MAX_ITEMS) o->queries[o->nq++] = xstrdup(s); }
static void add_server(Opts *o, const char *s) { if (o->ns < MAX_ITEMS) o->servers[o->ns++] = xstrdup(s); }
static int add_type(Opts *o, const char *s) {
    int t = map_lookup(types, s); if (t < 0) return -1;
    if (o->nt < MAX_ITEMS) { o->qtypes[o->nt]=t; o->qtnames[o->nt++]=map_name(types,t); }
    return 0;
}
static int add_class(Opts *o, const char *s) {
    int c = map_lookup(classes, s); if (c < 0) return -1;
    if (o->nc < MAX_ITEMS) { o->qclasses[o->nc]=c; o->qcnames[o->nc++]=map_name(classes,c); }
    return 0;
}

static const char *valarg(int *i, int argc, char **argv, const char *cur, const char *optname, int shortopt) {
    char *eq = strchr(cur, '=');
    if (eq) return eq + 1;
    if (shortopt && cur[2]) return cur + 2;
    if (*i + 1 >= argc) {
        fprintf(stderr, "dog: Invalid options: Argument to option '%s' missing\n", optname);
        exit(3);
    }
    return argv[++*i];
}

static void parse(int argc, char **argv, Opts *o) {
    memset(o, 0, sizeof *o);
    bool positional = false;
    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (!positional && !strcmp(a, "--")) { positional = true; continue; }
        if (!positional && (!strcmp(a,"--help") || !strcmp(a,"-?"))) { help(stdout); exit(0); }
        if (!positional && (!strcmp(a,"--version") || !strcmp(a,"-v"))) { version(); exit(0); }
        if (!positional && a[0]=='-') {
            if (!strncmp(a,"--query",7)) add_query(o, valarg(&i,argc,argv,a,"query",0));
            else if (!strncmp(a,"--type",6)) { const char *v=valarg(&i,argc,argv,a,"type",0); if(add_type(o,v)<0){fprintf(stderr,"dog: Invalid options: Invalid query type \"%s\"\n",v); exit(3);} }
            else if (!strncmp(a,"--nameserver",12)) add_server(o, valarg(&i,argc,argv,a,"nameserver",0));
            else if (!strncmp(a,"--class",7)) { const char *v=valarg(&i,argc,argv,a,"class",0); if(add_class(o,v)<0){fprintf(stderr,"dog: Invalid options: Invalid query class \"%s\"\n",v); exit(3);} }
            else if (!strncmp(a,"--txid",6)) { o->txid=(unsigned)strtoul(valarg(&i,argc,argv,a,"txid",0),NULL,0); o->txid_set=true; }
            else if (!strncmp(a,"--edns",6) || !strcmp(a,"--color") || !strcmp(a,"--colour") || !strncmp(a,"--color=",8) || !strncmp(a,"--colour=",9)) { if(!strchr(a,'=')) (void)valarg(&i,argc,argv,a,a+2,0); }
            else if (!strcmp(a,"--udp")) o->tcp = false;
            else if (!strcmp(a,"--tcp")) o->tcp = true;
            else if (!strcmp(a,"--tls")) o->tls = true;
            else if (!strcmp(a,"--https")) o->https = true;
            else if (!strcmp(a,"--short")) o->short_out = true;
            else if (!strcmp(a,"--json")) o->json = true;
            else if (!strcmp(a,"--seconds")) o->seconds = true;
            else if (!strcmp(a,"--time")) o->timeit = true;
            else if (a[1]=='q') add_query(o, valarg(&i,argc,argv,a,"q",1));
            else if (a[1]=='t') { const char *v=valarg(&i,argc,argv,a,"t",1); if(add_type(o,v)<0){fprintf(stderr,"dog: Invalid options: Invalid query type \"%s\"\n",v); exit(3);} }
            else if (a[1]=='n') add_server(o, valarg(&i,argc,argv,a,"n",1));
            else if (a[1]=='Z') { (void)valarg(&i,argc,argv,a,"Z",1); }
            else if (!strcmp(a,"-U")) o->tcp = false;
            else if (!strcmp(a,"-T")) o->tcp = true;
            else if (!strcmp(a,"-S")) o->tls = true;
            else if (!strcmp(a,"-H")) o->https = true;
            else if (!strcmp(a,"-1")) o->short_out = true;
            else if (!strcmp(a,"-J")) o->json = true;
            else { fprintf(stderr, "dog: Invalid options: Unrecognized option: '%s'\n", a+1+(a[1]=='-')); exit(3); }
        } else {
            if (a[0]=='@') add_server(o, a+1);
            else if (map_lookup(types,a) >= 0) add_type(o, a);
            else if (map_lookup(classes,a) >= 0) add_class(o, a);
            else add_query(o, a);
        }
    }
    if (!o->nq) { help(stdout); exit(3); }
    if (!o->nt) add_type(o, "A");
    if (!o->nc) add_class(o, "IN");
}

static int read_resolv(char *buf, size_t n) {
    FILE *f = fopen("/etc/resolv.conf","r"); char line[256];
    if (!f) return -1;
    while (fgets(line,sizeof line,f)) {
        char ns[200];
        if (sscanf(line, "nameserver %199s", ns)==1) { snprintf(buf,n,"%s",ns); fclose(f); return 0; }
    }
    fclose(f); return -1;
}

static int put_name(uint8_t *p, const char *name) {
    int pos=0; const char *s=name;
    while (*s) {
        const char *dot = strchr(s,'.');
        int len = dot ? (int)(dot-s) : (int)strlen(s);
        if (len <= 0) break;
        p[pos++] = (uint8_t)len; memcpy(p+pos, s, len); pos += len;
        if (!dot) break; s = dot + 1;
    }
    p[pos++] = 0; return pos;
}

static int make_query(uint8_t *p, const char *name, int type, int cls, const Opts *o) {
    unsigned id = o->txid_set ? o->txid : (unsigned)(getpid() ^ time(NULL));
    memset(p,0,12); p[0]=id>>8; p[1]=id; p[2]=1; p[5]=1;
    int pos=12; pos += put_name(p+pos,name);
    p[pos++]=type>>8; p[pos++]=type; p[pos++]=cls>>8; p[pos++]=cls;
    return pos;
}

static int split_hostport(const char *in, char *host, size_t hn, char *port, size_t pn) {
    snprintf(port,pn,"53");
    if (in[0]=='[') {
        const char *r = strchr(in,']'); if (!r) return -1;
        snprintf(host, hn, "%.*s", (int)(r-in-1), in+1);
        if (r[1]==':') snprintf(port,pn,"%s",r+2);
    } else {
        const char *c = strrchr(in, ':');
        if (c && strchr(in, ':') == c) { snprintf(host,hn,"%.*s",(int)(c-in),in); snprintf(port,pn,"%s",c+1); }
        else snprintf(host,hn,"%s",in);
    }
    return 0;
}

static int send_dns(const char *server, bool tcp, uint8_t *q, int qlen, uint8_t *resp, int *rlen, char *err, size_t en) {
    char host[256], port[32]; split_hostport(server,host,sizeof host,port,sizeof port);
    struct addrinfo hints, *ai=NULL; memset(&hints,0,sizeof hints);
    hints.ai_socktype = tcp ? SOCK_STREAM : SOCK_DGRAM; hints.ai_family = AF_UNSPEC;
    int g = getaddrinfo(host, port, &hints, &ai);
    if (g) { snprintf(err,en,"%s",gai_strerror(g)); return -1; }
    int rc=-1;
    for (struct addrinfo *a=ai; a; a=a->ai_next) {
        int s=socket(a->ai_family,a->ai_socktype,a->ai_protocol); if(s<0) continue;
        struct timeval tv={4,0}; setsockopt(s,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof tv); setsockopt(s,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof tv);
        if (tcp) {
            if (connect(s,a->ai_addr,a->ai_addrlen)<0) { snprintf(err,en,"%s (os error %d)",strerror(errno),errno); close(s); continue; }
            uint8_t lenb[2]={(uint8_t)(qlen>>8),(uint8_t)qlen};
            if (write(s,lenb,2)!=2 || write(s,q,qlen)!=qlen) { snprintf(err,en,"%s (os error %d)",strerror(errno),errno); close(s); continue; }
            if (read(s,lenb,2)!=2) { snprintf(err,en,"%s (os error %d)",strerror(errno),errno); close(s); continue; }
            int need=lenb[0]*256+lenb[1], got=0; while(got<need){int n=read(s,resp+got,need-got); if(n<=0)break; got+=n;}
            *rlen=got; rc = got==need ? 0 : -1;
        } else {
            if (connect(s,a->ai_addr,a->ai_addrlen)<0) { snprintf(err,en,"%s (os error %d)",strerror(errno),errno); close(s); continue; }
            if (send(s,q,qlen,0)<0) { snprintf(err,en,"%s (os error %d)",strerror(errno),errno); close(s); continue; }
            int n=recv(s,resp,MAX_PACKET,0);
            if (n<0) snprintf(err,en,"%s (os error %d)",strerror(errno),errno); else { *rlen=n; rc=0; }
        }
        close(s); if (rc==0) break;
    }
    freeaddrinfo(ai); return rc;
}

static int read_name(const uint8_t *pkt, int len, int *off, char *out, size_t on) {
    int p=*off, jumped=0, jumps=0, w=0;
    while (p < len && jumps++ < 40) {
        int c=pkt[p++];
        if (c==0) break;
        if ((c&0xc0)==0xc0) { if(p>=len)return -1; int ptr=((c&0x3f)<<8)|pkt[p++]; if(!jumped)*off=p; p=ptr; jumped=1; continue; }
        if (c&0xc0 || p+c>len) return -1;
        if (w && w<(int)on-1) out[w++]='.';
        for(int i=0;i<c && w<(int)on-1;i++) out[w++]=(char)pkt[p+i];
        p+=c;
    }
    if (!jumped) *off=p;
    if (w<(int)on-1) out[w++]='.';
    out[w]=0; return 0;
}

static void json_escape(char *dst, size_t dn, const char *s) {
    size_t w=0; for (; *s && w+2<dn; s++) {
        if (*s=='"' || *s=='\\') { if(w+2<dn){dst[w++]='\\'; dst[w++]=*s;} }
        else if ((unsigned char)*s < 32) { }
        else dst[w++]=*s;
    } dst[w]=0;
}

static void parse_rdata(const uint8_t *pkt, int len, int typ, int rdstart, int rdlen, RR *rr) {
    char tmp[512], esc[700]; rr->data[0]=0; rr->jsondata[0]=0;
    if (typ==1 && rdlen==4) {
        inet_ntop(AF_INET,pkt+rdstart,tmp,sizeof tmp); snprintf(rr->data,sizeof rr->data,"%s",tmp); snprintf(rr->jsondata,sizeof rr->jsondata,"{\"address\":\"%s\"}",tmp);
    } else if (typ==28 && rdlen==16) {
        inet_ntop(AF_INET6,pkt+rdstart,tmp,sizeof tmp); snprintf(rr->data,sizeof rr->data,"%s",tmp); snprintf(rr->jsondata,sizeof rr->jsondata,"{\"address\":\"%s\"}",tmp);
    } else if ((typ==2 || typ==5 || typ==12) && rdlen>0) {
        int o=rdstart; if(read_name(pkt,len,&o,tmp,sizeof tmp)<0) snprintf(tmp,sizeof tmp,".");
        snprintf(rr->data,sizeof rr->data,"\"%s\"",tmp); json_escape(esc,sizeof esc,tmp); snprintf(rr->jsondata,sizeof rr->jsondata,"{\"domain\":\"%s\"}",esc);
    } else if (typ==15 && rdlen>2) {
        int pref=pkt[rdstart]*256+pkt[rdstart+1], o=rdstart+2; if(read_name(pkt,len,&o,tmp,sizeof tmp)<0) snprintf(tmp,sizeof tmp,".");
        snprintf(rr->data,sizeof rr->data,"%d \"%s\"",pref,tmp); json_escape(esc,sizeof esc,tmp); snprintf(rr->jsondata,sizeof rr->jsondata,"{\"preference\":%d,\"exchange\":\"%s\"}",pref,esc);
    } else if (typ==16) {
        int p=rdstart, end=rdstart+rdlen, first=1; rr->data[0]=0; strcpy(rr->jsondata,"{\"texts\":[");
        while(p<end){ int l=pkt[p++]; if(p+l>end)break; char part[260]; snprintf(part,sizeof part,"%.*s",l,(char*)pkt+p); json_escape(esc,sizeof esc,part);
            if(!first){strncat(rr->data,", ",sizeof(rr->data)-strlen(rr->data)-1); strncat(rr->jsondata,",",sizeof(rr->jsondata)-strlen(rr->jsondata)-1);} first=0;
            strncat(rr->data,"\"",sizeof(rr->data)-strlen(rr->data)-1); strncat(rr->data,esc,sizeof(rr->data)-strlen(rr->data)-1); strncat(rr->data,"\"",sizeof(rr->data)-strlen(rr->data)-1);
            strncat(rr->jsondata,"\"",sizeof(rr->jsondata)-strlen(rr->jsondata)-1); strncat(rr->jsondata,esc,sizeof(rr->jsondata)-strlen(rr->jsondata)-1); strncat(rr->jsondata,"\"",sizeof(rr->jsondata)-strlen(rr->jsondata)-1); p+=l; }
        strncat(rr->jsondata,"]}",sizeof(rr->jsondata)-strlen(rr->jsondata)-1);
    } else {
        int w=0; for(int i=0;i<rdlen && w<(int)sizeof(rr->data)-8;i++) w+=snprintf(rr->data+w,sizeof(rr->data)-w,"%s%d",i?" ":"",pkt[rdstart+i]);
        json_escape(esc,sizeof esc,rr->data); snprintf(rr->jsondata,sizeof rr->jsondata,"{\"bytes\":\"%s\"}",esc);
    }
}

static int parse_response(const uint8_t *pkt, int len, RR *answers, int *anc, char qname[256], int *qtype, int *qclass) {
    if (len < 12) return -1;
    int qd=pkt[4]*256+pkt[5], an=pkt[6]*256+pkt[7], off=12;
    if (qd>0) { read_name(pkt,len,&off,qname,256); if(off+4<=len){*qtype=pkt[off]*256+pkt[off+1]; *qclass=pkt[off+2]*256+pkt[off+3]; off+=4;} }
    for (int i=1;i<qd;i++) { char dum[256]; read_name(pkt,len,&off,dum,256); off+=4; }
    *anc=0;
    for (int i=0;i<an && *anc<MAX_ITEMS;i++) {
        RR *r=&answers[*anc]; if(read_name(pkt,len,&off,r->name,sizeof r->name)<0 || off+10>len) break;
        r->typeno=pkt[off]*256+pkt[off+1]; r->clsno=pkt[off+2]*256+pkt[off+3]; r->ttl=((uint32_t)pkt[off+4]<<24)|((uint32_t)pkt[off+5]<<16)|(pkt[off+6]<<8)|pkt[off+7];
        int rdlen=pkt[off+8]*256+pkt[off+9]; off+=10; if(off+rdlen>len) break;
        snprintf(r->type,sizeof r->type,"%s",map_name(types,r->typeno)); snprintf(r->cls,sizeof r->cls,"%s",map_name(classes,r->clsno));
        parse_rdata(pkt,len,r->typeno,off,rdlen,r); off+=rdlen; (*anc)++;
    }
    return 0;
}

static void ttlfmt(uint32_t ttl, bool seconds, char *buf, size_t n) {
    if (seconds) snprintf(buf,n,"%u",ttl);
    else if (ttl >= 3600) snprintf(buf,n,"%uh%02um%02us",ttl/3600,(ttl%3600)/60,ttl%60);
    else snprintf(buf,n,"%um%02us",ttl/60,ttl%60);
}

static long ms_since(struct timeval a, struct timeval b) {
    return (b.tv_sec-a.tv_sec)*1000L + (b.tv_usec-a.tv_usec)/1000L;
}

int main(int argc, char **argv) {
    Opts o; parse(argc, argv, &o);
    if (o.tls || o.https) {
        if (o.json) puts("{\"error\":true,\"error_phase\":\"network\",\"error_message\":\"unsupported transport\"}\n{\"responses\":[]}");
        else fputs("Error [network]: unsupported transport\n", stderr);
        return 1;
    }
    char defns[256]; if (!o.ns) { if(read_resolv(defns,sizeof defns)<0){fputs("Error [network]: failed to read resolver\n",stderr); return 4;} add_server(&o,defns); }
    struct timeval start,end; gettimeofday(&start,NULL);
    bool any=false, error=false, first_json_resp=true; char first_err[512]="";
    char jbuf[65536]; size_t jp=0;
    if (o.json) jp += snprintf(jbuf+jp, sizeof jbuf-jp, "{\"responses\":[");
    for(int qi=0; qi<o.nq; qi++) for(int ti=0; ti<o.nt; ti++) for(int ci=0; ci<o.nc; ci++) for(int si=0; si<o.ns; si++) {
        uint8_t q[MAX_PACKET], resp[MAX_PACKET]; int qlen=make_query(q,o.queries[qi],o.qtypes[ti],o.qclasses[ci],&o), rlen=0; char err[512]="";
        if(send_dns(o.servers[si],o.tcp,q,qlen,resp,&rlen,err,sizeof err)<0) {
            error=true; if(!first_err[0]) snprintf(first_err,sizeof first_err,"%s",err[0]?err:"network error"); continue;
        }
        RR ans[MAX_ITEMS]; int anc=0, qt=0, qc=0; char qn[256]="";
        parse_response(resp,rlen,ans,&anc,qn,&qt,&qc);
        if (o.json) {
            if(!first_json_resp) jp += snprintf(jbuf+jp, sizeof jbuf-jp, ",");
            first_json_resp=false;
            jp += snprintf(jbuf+jp, sizeof jbuf-jp, "{\"queries\":[{\"name\":\"%s\",\"class\":\"%s\",\"type\":\"%s\"}],\"answers\":[", qn, map_name(classes,qc), map_name(types,qt));
            for(int i=0;i<anc;i++){ if(i) jp += snprintf(jbuf+jp, sizeof jbuf-jp, ","); jp += snprintf(jbuf+jp, sizeof jbuf-jp, "{\"name\":\"%s\",\"class\":\"%s\",\"ttl\":%u,\"type\":\"%s\",\"data\":%s}",ans[i].name,ans[i].cls,ans[i].ttl,ans[i].type,ans[i].jsondata); }
            jp += snprintf(jbuf+jp, sizeof jbuf-jp, "],\"authorities\":[],\"additionals\":[]}");
        } else {
            for(int i=0;i<anc;i++) {
                any=true;
                if (o.short_out) {
                    char sdata[512]; snprintf(sdata, sizeof sdata, "%s", ans[i].data);
                    size_t l = strlen(sdata);
                    if (l >= 2 && sdata[0] == '"' && sdata[l-1] == '"') { sdata[l-1] = 0; printf("%s\n", sdata+1); }
                    else printf("%s\n", sdata);
                    return 0;
                }
                char tb[64]; ttlfmt(ans[i].ttl,o.seconds,tb,sizeof tb);
                printf("%s %s %s   %s\n", ans[i].type, ans[i].name, tb, ans[i].data);
            }
        }
        if (anc>0) any=true;
    }
    if (o.json) {
        jp += snprintf(jbuf+jp, sizeof jbuf-jp, "]}\n");
    }
    gettimeofday(&end,NULL);
    if (!o.json && error && !any) fprintf(stderr, "Error [network]: %s\n", first_err[0]?first_err:"network error");
    if (o.json && error && !any) {
        char esc[700]; json_escape(esc,sizeof esc,first_err[0]?first_err:"network error");
        printf("{\"error\":true,\"error_phase\":\"network\",\"error_message\":\"%s\"}\n", esc);
    }
    if (o.json) fputs(jbuf, stdout);
    if (!o.json && o.short_out && !any) { puts("No results"); return 2; }
    if (!o.json && o.timeit) printf("Ran in %ldms\n", ms_since(start,end));
    return error && !any ? 1 : 0;
}
