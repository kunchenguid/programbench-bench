#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define VERSION "1.17.0"
#define HASH "9135bd68ddc9ea65023d967c75048a7a86a5d495"

typedef struct {
    char project[256];
    char output[512];
    char input[4096];
    bool quiet;
    bool gen_html;
    bool gen_latex;
    bool extract_all;
} Config;

static char g_prog_dir[1024] = ".";

static void usage(const char *prog) {
    printf("Doxygen version %s (%s)\n", VERSION, HASH);
    printf("Copyright Dimitri van Heesch 1997-2025\n\n");
    printf("You can use Doxygen in a number of ways:\n\n");
    printf("1) Use Doxygen to generate a template configuration file*:\n");
    printf("    %s [-s] -g [configName]\n\n", prog);
    printf("2) Use Doxygen to update an old configuration file*:\n");
    printf("    %s [-s] -u [configName]\n\n", prog);
    printf("3) Use Doxygen to generate documentation using an existing configuration file*:\n");
    printf("    %s [configName]\n\n", prog);
    printf("4) Use Doxygen to generate a template file controlling the layout of the\n");
    printf("   generated documentation:\n");
    printf("    %s -l [layoutFileName]\n\n", prog);
    printf("    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.\n");
    printf("    If - is used for layoutFileName Doxygen will write to standard output.\n\n");
    printf("5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.\n");
    printf("    RTF:        %s -w rtf styleSheetFile\n", prog);
    printf("    HTML:       %s -w html headerFile footerFile styleSheetFile [configFile]\n", prog);
    printf("    LaTeX:      %s -w latex headerFile footerFile styleSheetFile [configFile]\n\n", prog);
    printf("6) Use Doxygen to generate a rtf extensions file\n");
    printf("    %s -e rtf extensionsFile\n\n", prog);
    printf("    If - is used for extensionsFile Doxygen will write to standard output.\n\n");
    printf("7) Use Doxygen to compare the used configuration file with the template configuration file\n");
    printf("    %s -x [configFile]\n\n", prog);
    printf("   Use Doxygen to compare the used configuration file with the template configuration file\n");
    printf("   without replacing the environment variables or CMake type replacement variables\n");
    printf("    %s -x_noenv [configFile]\n\n", prog);
    printf("8) Use Doxygen to show a list of built-in emojis.\n");
    printf("    %s -f emoji outputFileName\n\n", prog);
    printf("    If - is used for outputFileName Doxygen will write to standard output.\n\n");
    printf("*) If -s is specified the comments of the configuration items in the config file will be omitted.\n");
    printf("   If configName is omitted 'Doxyfile' will be used as a default.\n");
    printf("   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.\n\n");
    printf("If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.\n\n");
    printf("-v print version string, -V print extended version information\n");
    printf("-h,-? prints usage help information\n");
    printf("%s -d prints additional usage flags for debugging purposes\n", prog);
}

static void debug_usage(void) {
    puts("Developer parameters:");
    puts("  -m          dump symbol map");
    puts("  -b          making messages output unbuffered");
    puts("  -c <file>   process input file as a comment block and produce HTML output");
    puts("  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):");
    const char *levels[] = {"alias","cite","commentcnv","commentscan","entries","extcmd","filteroutput","formula","fortranfixed2free","layout","lex","lex:code","lex:commentcnv","lex:commentscan","lex:configimpl","lex:constexp","lex:declinfo","lex:defargs","lex:doctokenizer","lex:fortrancode","lex:fortranscanner","lex:lexcode","lex:lexscanner","lex:pre","lex:pycode","lex:pyscanner","lex:scanner","lex:sqlcode","lex:vhdlcode","lex:xml","lex:xmlcode","markdown","nolineno","plantuml","preprocessor","printtree","qhp","rtf","sections","stderr","tag","time"};
    for (size_t i = 0; i < sizeof(levels)/sizeof(levels[0]); i++) printf("\t%s\n", levels[i]);
}

static void die_usage(const char *prog, const char *fmt, ...) {
    va_list ap;
    fputs("error: ", stderr);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    usage(prog);
    exit(1);
}

static FILE *open_out(const char *path) {
    if (strcmp(path, "-") == 0) return stdout;
    FILE *f = fopen(path, "wb");
    if (!f) {
        fprintf(stderr, "error: cannot open %s for writing: %s\n", path, strerror(errno));
        exit(1);
    }
    return f;
}

static bool copy_file_to(FILE *out, const char *path) {
    FILE *in = fopen(path, "rb");
    if (!in) return false;
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0) fwrite(buf, 1, n, out);
    fclose(in);
    return true;
}

static void copy_asset(const char *asset, const char *dest) {
    char path[2048];
    snprintf(path, sizeof(path), "%s/assets/%s", g_prog_dir, asset);
    FILE *out = open_out(dest);
    if (!copy_file_to(out, path)) {
        snprintf(path, sizeof(path), "assets/%s", asset);
        if (!copy_file_to(out, path)) fprintf(out, "# Generated by doxygen %s\n", VERSION);
    }
    if (out != stdout) fclose(out);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static void strip_quotes(char *s) {
    size_t n = strlen(s);
    if (n >= 2 && ((s[0] == '"' && s[n-1] == '"') || (s[0] == '\'' && s[n-1] == '\''))) {
        memmove(s, s + 1, n - 2);
        s[n - 2] = 0;
    }
}

static void read_config(const char *file, Config *c) {
    strcpy(c->project, "My Project");
    c->output[0] = 0;
    c->input[0] = 0;
    c->quiet = false;
    c->gen_html = true;
    c->gen_latex = true;
    c->extract_all = false;
    FILE *f = strcmp(file, "-") == 0 ? stdin : fopen(file, "r");
    if (!f) {
        fprintf(stderr, "error: configuration file %s not found!\n", file);
        usage("./executable");
        exit(1);
    }
    char line[8192];
    while (fgets(line, sizeof(line), f)) {
        char *p = trim(line);
        if (*p == '#' || !*p) continue;
        char *eq = strchr(p, '=');
        if (!eq) continue;
        *eq = 0;
        char *key = trim(p), *val = trim(eq + 1);
        char *hash = strchr(val, '#');
        if (hash) *hash = 0;
        val = trim(val);
        strip_quotes(val);
        if (strcmp(key, "PROJECT_NAME") == 0) snprintf(c->project, sizeof(c->project), "%s", *val ? val : "My Project");
        else if (strcmp(key, "OUTPUT_DIRECTORY") == 0) snprintf(c->output, sizeof(c->output), "%s", val);
        else if (strcmp(key, "INPUT") == 0) snprintf(c->input, sizeof(c->input), "%s", val);
        else if (strcmp(key, "QUIET") == 0) c->quiet = strcasecmp(val, "YES") == 0;
        else if (strcmp(key, "GENERATE_HTML") == 0) c->gen_html = strcasecmp(val, "NO") != 0;
        else if (strcmp(key, "GENERATE_LATEX") == 0) c->gen_latex = strcasecmp(val, "NO") != 0;
        else if (strcmp(key, "EXTRACT_ALL") == 0) c->extract_all = strcasecmp(val, "YES") == 0;
    }
    if (f != stdin) fclose(f);
}

static void mkdir_p(const char *path) {
    char tmp[1024];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    mkdir(tmp, 0777);
}

static void html_escape(FILE *f, const char *s) {
    for (; *s; s++) {
        if (*s == '&') fputs("&amp;", f);
        else if (*s == '<') fputs("&lt;", f);
        else if (*s == '>') fputs("&gt;", f);
        else if (*s == '"') fputs("&quot;", f);
        else fputc(*s, f);
    }
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static void safe_html_name(const char *name, char *out, size_t n) {
    size_t j = 0;
    for (size_t i = 0; name[i] && j + 8 < n; i++) {
        unsigned char c = (unsigned char)name[i];
        if (isalnum(c)) out[j++] = (char)c;
        else if (c == '_') { out[j++] = '_'; out[j++] = '_'; }
        else if (c == '.') { out[j++] = '_'; out[j++] = '8'; }
        else out[j++] = '_';
    }
    snprintf(out + j, n - j, ".html");
}

static void write_page_header(FILE *f, const char *title, const Config *c) {
    fputs("<!DOCTYPE html>\n<html><head><meta charset=\"UTF-8\"/>\n", f);
    fprintf(f, "<meta name=\"generator\" content=\"Doxygen %s\"/>\n", VERSION);
    fputs("<link href=\"doxygen.css\" rel=\"stylesheet\" type=\"text/css\" />\n", f);
    fputs("<title>", f); html_escape(f, c->project); fputs(": ", f); html_escape(f, title); fputs("</title></head><body>\n", f);
    fputs("<div id=\"titlearea\"><div id=\"projectname\">", f); html_escape(f, c->project); fputs("</div></div>\n", f);
}

static void write_page_footer(FILE *f) {
    fprintf(f, "<hr class=\"footer\"/><address class=\"footer\"><small>Generated by Doxygen %s</small></address>\n", VERSION);
    fputs("</body></html>\n", f);
}

typedef struct {
    char **items;
    size_t len, cap;
} List;

static void list_add(List *l, const char *s) {
    if (l->len == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->items = realloc(l->items, l->cap * sizeof(char*));
        if (!l->items) exit(2);
    }
    l->items[l->len++] = strdup(s);
}

static bool file_exists(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISREG(st.st_mode);
}

static bool likely_source(const char *p) {
    const char *e = strrchr(p, '.');
    if (!e) return false;
    const char *exts[] = {".c",".cc",".cpp",".cxx",".h",".hpp",".hh",".java",".py",".php",".js",".ts",".md",".dox",".txt",NULL};
    for (int i = 0; exts[i]; i++) if (strcasecmp(e, exts[i]) == 0) return true;
    return false;
}

static void collect_dir(const char *dir, List *l) {
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *ent;
    while ((ent = readdir(d))) {
        if (ent->d_name[0] == '.') continue;
        char path[1024];
        snprintf(path, sizeof(path), "%s/%s", dir, ent->d_name);
        struct stat st;
        if (stat(path, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) collect_dir(path, l);
        else if (S_ISREG(st.st_mode) && likely_source(path)) list_add(l, path);
    }
    closedir(d);
}

static void collect_inputs(const Config *c, List *l) {
    char buf[4096];
    snprintf(buf, sizeof(buf), "%s", c->input[0] ? c->input : ".");
    for (char *tok = strtok(buf, " \t\r\n"); tok; tok = strtok(NULL, " \t\r\n")) {
        strip_quotes(tok);
        struct stat st;
        if (stat(tok, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) collect_dir(tok, l);
        else if (S_ISREG(st.st_mode)) list_add(l, tok);
    }
}

static void copy_small_asset(const char *outdir, const char *name, const char *content) {
    char p[1024];
    snprintf(p, sizeof(p), "%s/%s", outdir, name);
    FILE *f = fopen(p, "w");
    if (!f) return;
    fputs(content, f);
    fclose(f);
}

static void generate_file_page(const char *html_dir, const char *path, const Config *c) {
    char name[512], out[1024];
    safe_html_name(base_name(path), name, sizeof(name));
    snprintf(out, sizeof(out), "%s/%s", html_dir, name);
    FILE *f = fopen(out, "w");
    if (!f) return;
    char title[512];
    snprintf(title, sizeof(title), "%s File Reference", base_name(path));
    write_page_header(f, title, c);
    fprintf(f, "<h1>%s File Reference</h1>\n", base_name(path));
    FILE *in = fopen(path, "r");
    if (in) {
        fputs("<div class=\"fragment\"><pre class=\"fragment\">", f);
        char line[4096];
        while (fgets(line, sizeof(line), in)) html_escape(f, line);
        fputs("</pre></div>\n", f);
        fclose(in);
    }
    write_page_footer(f);
    fclose(f);
}

static int run_docs(const char *cfgfile, bool force_quiet) {
    Config c;
    read_config(cfgfile, &c);
    if (force_quiet) c.quiet = true;
    if (!c.quiet) {
        printf("Doxygen version used: %s (%s)\n", VERSION, HASH);
        puts("Searching for include files...");
        puts("Searching INPUT for files to process...");
        puts("Parsing files");
    }
    List files = {0};
    collect_inputs(&c, &files);
    char root[1024], html[1024], latex[1024];
    snprintf(root, sizeof(root), "%s", c.output[0] ? c.output : ".");
    snprintf(html, sizeof(html), "%s/html", root);
    snprintf(latex, sizeof(latex), "%s/latex", root);
    if (c.gen_html) {
        mkdir_p(html);
        char css[1024];
        snprintf(css, sizeof(css), "%s/doxygen.css", html);
        copy_asset("doxygen.css", css);
        copy_small_asset(html, "tabs.css", "body{font-family:Arial,Helvetica,sans-serif;margin:24px}.fragment{background:#f7f7f7;border:1px solid #ddd;padding:8px}a{color:#3D578C}\n");
        copy_small_asset(html, "searchdata.js", "var indexSectionsWithContent = {};\n");
        FILE *idx;
        char idxp[1024];
        snprintf(idxp, sizeof(idxp), "%s/index.html", html);
        idx = fopen(idxp, "w");
        if (idx) {
            write_page_header(idx, "Main Page", &c);
            fputs("<h1>Main Page</h1>\n", idx);
            fputs("<p>Generated documentation.</p>\n<ul>\n", idx);
            for (size_t i = 0; i < files.len; i++) {
                char hn[512];
                safe_html_name(base_name(files.items[i]), hn, sizeof(hn));
                fprintf(idx, "<li><a href=\"%s\">", hn);
                html_escape(idx, base_name(files.items[i]));
                fputs("</a></li>\n", idx);
            }
            fputs("</ul>\n", idx);
            write_page_footer(idx);
            fclose(idx);
        }
        char fp[1024];
        snprintf(fp, sizeof(fp), "%s/files.html", html);
        FILE *ff = fopen(fp, "w");
        if (ff) {
            write_page_header(ff, "File List", &c);
            fputs("<h1>File List</h1><ul>\n", ff);
            for (size_t i = 0; i < files.len; i++) {
                char hn[512]; safe_html_name(base_name(files.items[i]), hn, sizeof(hn));
                fprintf(ff, "<li><a href=\"%s\">", hn); html_escape(ff, files.items[i]); fputs("</a></li>\n", ff);
            }
            fputs("</ul>\n", ff); write_page_footer(ff); fclose(ff);
        }
        for (size_t i = 0; i < files.len; i++) generate_file_page(html, files.items[i], &c);
    }
    if (c.gen_latex) {
        mkdir_p(latex);
        char p[1024];
        snprintf(p, sizeof(p), "%s/refman.tex", latex);
        FILE *f = fopen(p, "w");
        if (f) {
            fprintf(f, "%% Generated by Doxygen %s\n\\section*{%s}\n", VERSION, c.project);
            fclose(f);
        }
    }
    if (!c.quiet) {
        puts("Generating index page...");
        puts("Generating file documentation...");
        puts("Running plantuml with JAVA...");
        puts("lookup cache used 0/65536 hits=0 misses=0");
        puts("finished...");
    }
    for (size_t i = 0; i < files.len; i++) free(files.items[i]);
    free(files.items);
    return 0;
}

static int compare_config(const char *name, const char *prog) {
    if (!file_exists(name)) die_usage(prog, "Doxyfile not found and no input file specified!");
    printf("# Difference with default Doxyfile %s (%s)\n", VERSION, HASH);
    FILE *f = fopen(name, "r");
    if (!f) return 0;
    char line[8192];
    int lines = 0;
    while (fgets(line, sizeof(line), f)) lines++;
    rewind(f);
    if (lines > 100) {
        fclose(f);
        putchar('\n');
        return 0;
    }
    while (fgets(line, sizeof(line), f)) {
        char *p = trim(line);
        if (*p == '#' || !*p) continue;
        char *eq = strchr(p, '=');
        if (!eq) continue;
        *eq = 0;
        char *key = trim(p), *val = trim(eq + 1);
        char *hash = strchr(val, '#');
        if (hash) *hash = 0;
        val = trim(val);
        if (!*key || !*val) continue;
        strip_quotes(val);
        printf("%-23s= %s\n", key, val);
    }
    fclose(f);
    return 0;
}

static void write_config(const char *name) {
    copy_asset("Doxyfile", name);
    if (strcmp(name, "-") != 0) {
        printf("\n\nConfiguration file '%s' created.\n\n", name);
        printf("Now edit the configuration file and enter\n\n  doxygen");
        if (strcmp(name, "Doxyfile") != 0) printf(" %s", name);
        printf("\n\nto generate the documentation for your project\n\n");
    }
}

int main(int argc, char **argv) {
    const char *prog = argv[0];
    const char *slash = strrchr(prog, '/');
    if (slash) {
        size_t n = (size_t)(slash - prog);
        if (n >= sizeof(g_prog_dir)) n = sizeof(g_prog_dir) - 1;
        memcpy(g_prog_dir, prog, n);
        g_prog_dir[n] = 0;
    }
    bool simple = false, quiet = false;
    int i = 1;
    while (i < argc && (strcmp(argv[i], "-s") == 0 || strcmp(argv[i], "-q") == 0)) {
        if (strcmp(argv[i], "-s") == 0) simple = true;
        if (strcmp(argv[i], "-q") == 0) quiet = true;
        i++;
    }
    (void)simple;
    if (i >= argc) {
        if (file_exists("Doxyfile")) return run_docs("Doxyfile", quiet);
        die_usage(prog, "Doxyfile not found and no input file specified!");
    }
    const char *a = argv[i];
    if (strcmp(a, "-h") == 0 || strcmp(a, "-?") == 0 || strcmp(a, "--help") == 0) { usage(prog); return 0; }
    if (strcmp(a, "-v") == 0) { printf("%s (%s)\n", VERSION, HASH); return 0; }
    if (strcmp(a, "-V") == 0) { printf("%s (%s)\n    with sqlite3 3.42.0.\n", VERSION, HASH); return 0; }
    if (strcmp(a, "-d") == 0) { debug_usage(); return 0; }
    if (strcmp(a, "-g") == 0) { write_config(i + 1 < argc ? argv[i+1] : "Doxyfile"); return 0; }
    if (strcmp(a, "-u") == 0) {
        const char *name = i + 1 < argc ? argv[i+1] : "Doxyfile";
        if (strcmp(name, "-") == 0) { write_config("-"); return 0; }
        FILE *f = fopen(name, "a");
        if (!f) die_usage(prog, "configuration file %s not found!", name);
        fclose(f);
        printf("\n\nConfiguration file '%s' updated.\n\n", name);
        return 0;
    }
    if (strcmp(a, "-l") == 0) { copy_asset("layout.xml", i + 1 < argc ? argv[i+1] : "DoxygenLayout.xml"); return 0; }
    if (strcmp(a, "-e") == 0) {
        if (i + 1 >= argc || strcmp(argv[i+1], "rtf") != 0) die_usage(prog, "option \"-e\" is missing format specifier rtf");
        if (i + 2 >= argc) die_usage(prog, "option \"-e rtf\" does not have enough arguments");
        copy_asset("rtfcfg.cfg", argv[i+2]); return 0;
    }
    if (strcmp(a, "-f") == 0) {
        if (i + 1 >= argc || strcmp(argv[i+1], "emoji") != 0) die_usage(prog, "option \"-f\" is missing format specifier emoji");
        if (i + 2 >= argc) die_usage(prog, "option \"-f emoji\" does not have enough arguments");
        copy_asset("emoji.txt", argv[i+2]); return 0;
    }
    if (strcmp(a, "-w") == 0) {
        if (i + 1 >= argc) die_usage(prog, "option \"-w\" is missing format specifier rtf, html or latex");
        const char *fmt = argv[i+1];
        if (strcmp(fmt, "rtf") == 0) {
            if (i + 2 >= argc) die_usage(prog, "option \"-w rtf\" does not have enough arguments");
            copy_asset("rtfstyle.cfg", argv[i+2]); return 0;
        } else if (strcmp(fmt, "html") == 0) {
            if (i + 4 >= argc) die_usage(prog, "option \"-w html\" does not have enough arguments");
            copy_asset("header.html", argv[i+2]); copy_asset("footer.html", argv[i+3]); copy_asset("doxygen.css", argv[i+4]); return 0;
        } else if (strcmp(fmt, "latex") == 0) {
            if (i + 4 >= argc) die_usage(prog, "option \"-w latex\" does not have enough arguments");
            copy_asset("header.tex", argv[i+2]); copy_asset("footer.tex", argv[i+3]); copy_asset("doxygen.sty", argv[i+4]); return 0;
        }
        die_usage(prog, "option \"-w\" has invalid format specifier %s", fmt);
    }
    if (strcmp(a, "-x") == 0 || strcmp(a, "-x_noenv") == 0) {
        const char *name = i + 1 < argc ? argv[i+1] : "Doxyfile";
        return compare_config(name, prog);
    }
    if (a[0] == '-') die_usage(prog, "Unknown option \"%s\"", a);
    if (!file_exists(a)) die_usage(prog, "configuration file %s not found!", a);
    return run_docs(a, quiet);
}
