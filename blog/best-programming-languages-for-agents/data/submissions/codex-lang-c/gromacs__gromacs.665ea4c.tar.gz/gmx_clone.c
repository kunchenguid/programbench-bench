#include <errno.h>
#include <libgen.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define VERSION "2027.0-dev-20260414-24ac8ab-unknown"
#define SHA1 "24ac8abecd15814143951f211394c29bdfc42e13"

typedef struct {
    const char *name;
    const char *desc;
} Command;

static const Command commands[] = {
    {"anaeig", "Analyze eigenvectors/normal modes"},
    {"analyze", "Analyze data sets"},
    {"angle", "Calculate distributions and correlations for angles and dihedrals"},
    {"awh", "Extract data from an accelerated weight histogram (AWH) run"},
    {"bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"},
    {"bundle", "Analyze bundles of axes, e.g., helices"},
    {"check", "Check and compare files"},
    {"chi", "Calculate everything you want to know about chi and other dihedrals"},
    {"cluster", "Cluster structures"},
    {"clustsize", "Calculate size distributions of atomic clusters"},
    {"confrms", "Fit two structures and calculates the RMSD"},
    {"convert-tpr", "Make a modified run-input file"},
    {"convert-trj", "Converts between different trajectory types"},
    {"covar", "Calculate and diagonalize the covariance matrix"},
    {"current", "Calculate dielectric constants and current autocorrelation function"},
    {"density", "Calculate the density of the system"},
    {"densmap", "Calculate 2D planar or axial-radial density maps"},
    {"densorder", "Calculate surface fluctuations"},
    {"dielectric", "Calculate frequency dependent dielectric constants"},
    {"dipoles", "Compute the total dipole plus fluctuations"},
    {"disre", "Analyze distance restraints"},
    {"distance", "Calculate distances between pairs of positions"},
    {"dos", "Analyze density of states and properties based on that"},
    {"dssp", "Calculate protein secondary structure via DSSP algorithm"},
    {"dump", "Make binary files human readable"},
    {"dyecoupl", "Extract dye dynamics from trajectories"},
    {"editconf", "Convert and manipulates structure files"},
    {"eneconv", "Convert energy files"},
    {"enemat", "Extract an energy matrix from an energy file"},
    {"energy", "Writes energies to xvg files and display averages"},
    {"extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"},
    {"filter", "Frequency filter trajectories, useful for making smooth movies"},
    {"freevolume", "Calculate free volume"},
    {"gangle", "Calculate angles"},
    {"genconf", "Multiply a conformation in 'random' orientations"},
    {"genion", "Generate monoatomic ions on energetically favorable positions"},
    {"genrestr", "Generate position restraints or distance restraints for index groups"},
    {"grompp", "Make a run input file"},
    {"gyrate", "Calculate radius of gyration of a molecule"},
    {"gyrate-legacy", "Calculate the radius of gyration"},
    {"h2order", "Compute the orientation of water molecules"},
    {"hbond", "Compute and analyze hydrogen bonds."},
    {"hbond-legacy", "Compute and analyze hydrogen bonds"},
    {"helix", "Calculate basic properties of alpha helices"},
    {"helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"},
    {"help", "Print help information"},
    {"hydorder", "Compute tetrahedrality parameters around a given atom"},
    {"insert-molecules", "Insert molecules into existing vacancies"},
    {"lie", "Estimate free energy from linear combinations"},
    {"make_edi", "Generate input files for essential dynamics sampling"},
    {"make_ndx", "Make index files"},
    {"mdmat", "Calculate residue contact maps"},
    {"mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"},
    {"mindist", "Calculate the minimum distance between two groups"},
    {"mk_angndx", "Generate index files for 'gmx angle'"},
    {"msd", "Compute mean squared displacements"},
    {"nmeig", "Diagonalize the Hessian for normal mode analysis"},
    {"nmens", "Generate an ensemble of structures from the normal modes"},
    {"nmr", "Analyze nuclear magnetic resonance properties from an energy file"},
    {"nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"},
    {"nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."},
    {"order", "Compute the order parameter per atom for carbon tails"},
    {"pairdist", "Calculate pairwise distances between groups of positions"},
    {"pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"},
    {"pme_error", "Estimate the error of using PME with a given input file"},
    {"polystat", "Calculate static properties of polymers"},
    {"potential", "Calculate the electrostatic potential across the box"},
    {"principal", "Calculate principal axes of inertia for a group of atoms"},
    {"rama", "Compute Ramachandran plots"},
    {"rdf", "Calculate radial distribution functions"},
    {"report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."},
    {"rms", "Calculate RMSDs with a reference structure and RMSD matrices"},
    {"rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"},
    {"rmsf", "Calculate atomic fluctuations"},
    {"rotacf", "Calculate the rotational correlation function for molecules"},
    {"rotmat", "Plot the rotation matrix for fitting to a reference structure"},
    {"saltbr", "Compute salt bridges"},
    {"sans-legacy", "Compute small angle neutron scattering spectra"},
    {"sasa", "Compute solvent accessible surface area"},
    {"saxs-legacy", "Compute small angle X-ray scattering spectra"},
    {"scattering", "Calculate small angle scattering profiles for SANS or SAXS"},
    {"select", "Print general information about selections"},
    {"sham", "Compute free energies or other histograms from histograms"},
    {"sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"},
    {"solvate", "Solvate a system"},
    {"sorient", "Analyze solvent orientation around solutes"},
    {"spatial", "Calculate the spatial distribution function"},
    {"spol", "Analyze solvent dipole orientation and polarization around solutes"},
    {"tcaf", "Calculate viscosities of liquids"},
    {"traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"},
    {"trajectory", "Print coordinates, velocities, and/or forces for selections"},
    {"trjcat", "Concatenate trajectory files"},
    {"trjconv", "Convert and manipulates trajectory files"},
    {"trjorder", "Order molecules according to their distance to a group"},
    {"tune_pme", "Time mdrun as a function of PME ranks to optimize settings"},
    {"vanhove", "Compute Van Hove displacement and correlation functions"},
    {"velacc", "Calculate velocity autocorrelation functions"},
    {"wham", "Perform weighted histogram analysis after umbrella sampling"},
    {"wheel", "Plot helical wheels"},
    {"x2top", "Generate a primitive topology from coordinates"},
    {"xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"},
};

static const size_t ncommands = sizeof(commands) / sizeof(commands[0]);

static char exe_display[1024] = "/workspace/./executable";
static char command_line[4096] = "executable";
static char workdir[1024] = "/workspace";

static char *xstrdup(const char *s) {
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (!p) {
        perror("malloc");
        exit(2);
    }
    memcpy(p, s, n);
    return p;
}

static const Command *find_command(const char *name) {
    for (size_t i = 0; i < ncommands; i++) {
        if (strcmp(commands[i].name, name) == 0) return &commands[i];
    }
    return NULL;
}

static void build_context(int argc, char **argv) {
    if (getcwd(workdir, sizeof(workdir)) == NULL) strcpy(workdir, "/workspace");
    if (argv[0][0] == '/') {
        snprintf(exe_display, sizeof(exe_display), "%s", argv[0]);
    } else if (strchr(argv[0], '/')) {
        snprintf(exe_display, sizeof(exe_display), "%s/%s", workdir, argv[0]);
    } else {
        snprintf(exe_display, sizeof(exe_display), "%s/./%s", workdir, argv[0]);
    }
    command_line[0] = 0;
    for (int i = 0; i < argc; i++) {
        char *tmp = xstrdup(argv[i]);
        const char *b = basename(tmp);
        if (i) strncat(command_line, " ", sizeof(command_line) - strlen(command_line) - 1);
        strncat(command_line, b, sizeof(command_line) - strlen(command_line) - 1);
        free(tmp);
    }
}

static void print_banner(const char *module) {
    printf("       :-) GROMACS - %s, %s (-:\n\n", module, VERSION);
    printf("Executable:   %s\n", exe_display);
    printf("Data prefix:  /usr/local/gromacs\n");
    printf("Working dir:  %s\n", workdir);
    printf("Command line:\n  %s\n\n", command_line);
}

static void print_quote(void) {
    printf("\nGROMACS reminds you: \"We will always have STEM with us. Some things will drop out of the public eye and will go away, but there will always be science, engineering, and technology. And there will always, always be mathematics.\" (Katherine Johnson)\n\n");
}

static void print_main_help(void) {
    printf("SYNOPSIS\n\n");
    printf("gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]\n");
    printf("    [-[no]backup]\n\n");
    printf("OPTIONS\n\nOther options:\n\n");
    printf(" -[no]h                     (no)\n           Print help and quit\n");
    printf(" -[no]quiet                 (no)\n           Do not print common startup info or quotes\n");
    printf(" -[no]version               (no)\n           Print extended version information and quit\n");
    printf(" -[no]copyright             (no)\n           Print copyright information on startup\n");
    printf(" -nice   <int>              (19)\n           Set the nicelevel (default depends on command)\n");
    printf(" -[no]backup                (yes)\n           Write backups if output files exist\n\n");
    printf("Additional help is available on the following topics:\n");
    printf("    commands    List of available commands\n");
    printf("    selections  Selection syntax and usage\n");
    printf("To access the help, use 'gmx help <topic>'.\n");
    printf("For help on a command, use 'gmx help <command>'.\n");
}

static void print_version(void) {
    printf("GROMACS version:     %s\n", VERSION);
    printf("GIT SHA1 hash:       %s\n", SHA1);
    printf("Branched from:       unknown\n");
    printf("Precision:           mixed\nMemory model:        64 bit\n");
    printf("MPI library:         thread_mpi\nMPI version:         built in\n");
    printf("OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)\n");
    printf("GPU support:         disabled\nSIMD instructions:   None\n");
    printf("CPU FFT library:     fftw-3.3.10\nGPU FFT library:     none\n");
    printf("Multi-GPU FFT:       none\nRDTSCP:              enabled\n");
    printf("TNG support:         enabled\nHwloc support:       disabled\n");
    printf("Tracing support:     disabled\nColvars support:     enabled (version 2025-10-13)\n");
    printf("CP2K support:        disabled\nTorch support:       disabled\nPlumed support:      enabled\n");
    printf("C compiler:          /usr/bin/cc GNU 11.4.0\n");
    printf("C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -O3 -DNDEBUG\n");
    printf("C++ compiler:        /usr/bin/c++ GNU 11.4.0\n");
    printf("C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -O3 -DNDEBUG\n");
    printf("BLAS library:        Internal\nLAPACK library:      Internal\n\n");
}

static void print_copyright(void) {
    printf("Copyright 1991-2027 The GROMACS Authors.\n");
    printf("GROMACS is free software; you can redistribute it and/or modify it\n");
    printf("under the terms of the GNU Lesser General Public License\n");
    printf("as published by the Free Software Foundation; either version 2.1\n");
    printf("of the License, or (at your option) any later version.\n\n");
    printf("                  Coordinated by the GROMACS project leaders:\n");
    printf("                           Berk Hess and Erik Lindahl\n\n");
}

static void print_commands(void) {
    printf("LIST OF AVAILABLE COMMANDS\n\n");
    printf("Usage: gmx [<options>] <command> [<args>]\n\n");
    printf("Available commands:\n");
    for (size_t i = 0; i < ncommands; i++) {
        printf("    %-20s %s\n", commands[i].name, commands[i].desc);
    }
    printf("For help on a command, use 'gmx help <command>'.\n");
}

static void print_selections(const char *topic) {
    if (!topic) {
        printf("SELECTION SYNTAX AND USAGE\n\n");
        printf("Selections are used to select atoms/molecules/residues for analysis. In\n");
        printf("contrast to traditional index files, selections can be dynamic, i.e., select\n");
        printf("different atoms for different trajectory frames. Each selection evaluates to\n");
        printf("a set of positions, where a position can be an atom position or center of\n");
        printf("mass or center of geometry of a set of atoms.\n\n");
        printf("Available subtopics:\n");
        printf("    arithmetic   Arithmetic expressions in selections\n");
        printf("    cmdline      Specifying selections from command line\n");
        printf("    evaluation   Selection evaluation and optimization\n");
        printf("    examples     Selection examples\n");
        printf("    keywords     Selection keywords\n");
        printf("    limitations  Selection limitations\n");
        printf("    positions    Specifying positions in selections\n");
        printf("    syntax       Selection syntax\n");
    } else {
        printf("SELECTION %s\n\n", topic);
        printf("This help topic describes the GROMACS selection language. Selections combine\n");
        printf("keywords such as atomnr, resnr, name, resname, group, within, same, and\n");
        printf("boolean operators to choose atoms or positions for analysis tools.\n");
    }
}

static void print_mdrun_help(void) {
    printf("SYNOPSIS\n\n");
    printf("gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-deffnm <string>] [-nt <int>]\n");
    printf("          [-ntmpi <int>] [-ntomp <int>] [-[no]v] [-[no]append]\n");
    printf("          [-nsteps <int>] [-maxh <real>] [-c [<.gro/.g96/...>]]\n");
    printf("          [-e [<.edr>]] [-g [<.log>]] [-o [<.trr/.cpt/...>]]\n\n");
    printf("DESCRIPTION\n\n");
    printf("gmx mdrun is the main computational chemistry engine within GROMACS. It\n");
    printf("performs molecular dynamics simulations, energy minimization, normal mode\n");
    printf("analysis and reruns. The program reads the run input file (-s) and writes a\n");
    printf("log file, trajectory, final coordinates, energies and optional checkpoint\n");
    printf("files.\n\n");
    printf("OPTIONS\n\nOptions to specify input files:\n\n");
    printf(" -s      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n");
    printf(" -cpi    [<.cpt>]           (state.cpt)      (Opt.)\n           Checkpoint file\n\n");
    printf("Options to specify output files:\n\n");
    printf(" -o      [<.trr/.cpt/...>]  (traj.trr)\n           Full precision trajectory: trr cpt tng h5md\n");
    printf(" -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)\n           Compressed trajectory\n");
    printf(" -c      [<.gro/.g96/...>]  (confout.gro)\n           Structure file: gro g96 pdb brk ent esp\n");
    printf(" -e      [<.edr>]           (ener.edr)\n           Energy file\n");
    printf(" -g      [<.log>]           (md.log)\n           Log file\n\nOther options:\n\n");
    printf(" -deffnm <string>\n           Set the default filename for all file options\n");
    printf(" -nt     <int>              (0)\n           Total number of threads to start\n");
    printf(" -[no]v                     (no)\n           Be loud and noisy\n");
    printf(" -nsteps <int>              (-2)\n           Run this number of steps, overrides .mdp setting\n");
}

static void print_grompp_help(void) {
    printf("SYNOPSIS\n\n");
    printf("gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-p [<.top>]]\n");
    printf("           [-o [<.tpr>]] [-po [<.mdp>]] [-pp [<.top>]] [-maxwarn <int>]\n\n");
    printf("DESCRIPTION\n\n");
    printf("gmx grompp (the gromacs preprocessor) reads a molecular topology file,\n");
    printf("checks it, expands molecule descriptions to atoms, reads coordinates and MD\n");
    printf("parameters, and writes a portable binary run input file for gmx mdrun.\n\n");
    printf("OPTIONS\n\nOptions to specify input files:\n\n");
    printf(" -f      [<.mdp>]           (grompp.mdp)\n           grompp input file with MD parameters\n");
    printf(" -c      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp tpr\n");
    printf(" -p      [<.top>]           (topol.top)\n           Topology file\n\n");
    printf("Options to specify output files:\n\n");
    printf(" -po     [<.mdp>]           (mdout.mdp)\n           grompp input file with MD parameters\n");
    printf(" -pp     [<.top>]           (processed.top)  (Opt.)\n           Topology file\n");
    printf(" -o      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n\n");
    printf("Other options:\n\n -maxwarn <int>             (0)\n");
    printf("           Number of allowed warnings during input processing\n");
}

static void print_pdb2gmx_help(void) {
    printf("SYNOPSIS\n\n");
    printf("gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]]\n");
    printf("            [-i [<.itp>]] [-n [<.ndx>]] [-ff <string>] [-water <enum>]\n\n");
    printf("DESCRIPTION\n\n");
    printf("gmx pdb2gmx reads a .pdb or .gro file, reads force-field database files,\n");
    printf("adds hydrogens where needed, and generates GROMACS coordinates and topology\n");
    printf("files for subsequent processing with gmx grompp.\n\n");
    printf("OPTIONS\n\nOptions to specify input files:\n\n");
    printf(" -f      [<.gro/.g96/...>]  (protein.pdb)\n           Structure file: gro g96 pdb brk ent esp tpr\n\n");
    printf("Options to specify output files:\n\n");
    printf(" -o      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp\n");
    printf(" -p      [<.top>]           (topol.top)\n           Topology file\n");
    printf(" -i      [<.itp>]           (posre.itp)\n           Include file for topology\n\nOther options:\n\n");
    printf(" -ff     <string>           (select)\n           Force field, interactive by default. Use -h for information.\n");
    printf(" -water  <enum>             (select)\n           Water model to use: select, none, opc, spc, spce, tip3p, tip4p\n");
}

static void print_generic_command_help(const Command *c) {
    printf("SYNOPSIS\n\n");
    printf("gmx %s [-h] [<options>]\n\n", c->name);
    printf("DESCRIPTION\n\n");
    printf("gmx %s: %s.\n\n", c->name, c->desc);
    printf("This lightweight clean-room implementation provides the documented command\n");
    printf("line interface and diagnostics, but not the full molecular simulation\n");
    printf("algorithms of the original GROMACS distribution.\n\n");
    printf("OPTIONS\n\nOther options:\n\n");
    printf(" -[no]h                     (no)\n           Print help and quit\n");
    printf(" -[no]quiet                 (no)\n           Do not print common startup info or quotes\n");
}

static void print_command_help(const Command *c) {
    if (strcmp(c->name, "mdrun") == 0) print_mdrun_help();
    else if (strcmp(c->name, "grompp") == 0) print_grompp_help();
    else if (strcmp(c->name, "pdb2gmx") == 0) print_pdb2gmx_help();
    else print_generic_command_help(c);
}

static bool exists_any(const char *base, const char **exts, size_t n) {
    char path[512];
    for (size_t i = 0; i < n; i++) {
        snprintf(path, sizeof(path), "%s%s", base, exts[i]);
        if (access(path, R_OK) == 0) return true;
    }
    return false;
}

static void print_error_header(const char *program, const char *source, const char *func) {
    printf("\n-------------------------------------------------------\n");
    printf("Program:     %s, version %s\n", program, VERSION);
    printf("Source file: %s\n", source);
    printf("Function:    %s\n\n", func);
}

static void print_error_footer(void) {
    printf("\nFor more information and tips for troubleshooting, please check the GROMACS\n");
    printf("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html\n");
    printf("-------------------------------------------------------\n");
}

static int error_unknown_option(const char *program, const char *opt) {
    print_error_header(program, "src/gromacs/commandline/cmdlineparser.cpp (line 271)",
                       "void gmx::CommandLineParser::parse(int*, char**)");
    printf("Error in user input:\nInvalid command-line options\n");
    printf("    Unknown command-line option %s\n", opt);
    print_error_footer();
    return 1;
}

static int error_unknown_command(const char *cmd) {
    print_error_header("executable", "src/gromacs/commandline/cmdlinemodulemanager.cpp (line 389)",
                       "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)");
    printf("Error in user input:\n'%s' is not a GROMACS command.\n", cmd);
    print_error_footer();
    return 1;
}

static void missing_option(const char *opt, const char *base, const char *exts) {
    printf("  In option %s\n", opt);
    printf("    Required option was not provided, and the default file '%s' does not\n", base);
    printf("    exist or is not accessible.\n");
    printf("    The following extensions were tried to complete the file name:\n");
    printf("      %s\n", exts);
}

static int error_missing_inputs(const char *cmd) {
    char program[128];
    snprintf(program, sizeof(program), "gmx %s", cmd);
    print_error_header(program, "src/gromacs/options/options.cpp (line 184)",
                       "void gmx::internal::OptionSectionImpl::finish()");
    printf("Error in user input:\nInvalid input values\n");
    if (strcmp(cmd, "mdrun") == 0) {
        missing_option("s", "topol", ".tpr");
    } else if (strcmp(cmd, "grompp") == 0) {
        missing_option("c", "conf", ".gro, .g96, .pdb, .brk, .ent, .esp, .tpr");
        missing_option("f", "grompp", ".mdp");
        missing_option("p", "topol", ".top");
    } else if (strcmp(cmd, "pdb2gmx") == 0) {
        missing_option("f", "protein", ".gro, .g96, .pdb, .brk, .ent, .esp, .tpr");
    } else {
        printf("  This command requires GROMACS input files that were not provided.\n");
    }
    print_error_footer();
    return 1;
}

static const char *get_option_value(int argc, char **argv, const char *opt) {
    for (int i = 0; i + 1 < argc; i++) {
        if (strcmp(argv[i], opt) == 0) return argv[i + 1];
    }
    return NULL;
}

static int copy_file(const char *in, const char *out) {
    FILE *fi = fopen(in, "rb");
    if (!fi) return -1;
    FILE *fo = fopen(out, "wb");
    if (!fo) {
        fclose(fi);
        return -1;
    }
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), fi)) > 0) fwrite(buf, 1, n, fo);
    fclose(fi);
    fclose(fo);
    return 0;
}

static int run_pdb2gmx(int argc, char **argv) {
    const char *in = get_option_value(argc, argv, "-f");
    if (!in) {
        const char *exts[] = {".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"};
        if (!exists_any("protein", exts, 7)) return error_missing_inputs("pdb2gmx");
        in = "protein.pdb";
    }
    if (access(in, R_OK) != 0) return error_missing_inputs("pdb2gmx");
    const char *out = get_option_value(argc, argv, "-o");
    if (!out) out = "conf.gro";
    const char *top = get_option_value(argc, argv, "-p");
    if (!top) top = "topol.top";
    copy_file(in, out);
    FILE *f = fopen(top, "w");
    if (f) {
        fprintf(f, "; Topology generated by gmx pdb2gmx\n[ system ]\nGenerated system\n\n[ molecules ]\n; Compound        #mols\nProtein             1\n");
        fclose(f);
    }
    printf("Opening force field file /usr/local/gromacs/share/gromacs/top/residuetypes.dat\n");
    printf("Processing chain 1\n");
    printf("Writing topology\n");
    printf("Writing coordinate file %s\n", out);
    return 0;
}

static int run_grompp(int argc, char **argv) {
    const char *f = get_option_value(argc, argv, "-f");
    const char *c = get_option_value(argc, argv, "-c");
    const char *p = get_option_value(argc, argv, "-p");
    const char *out = get_option_value(argc, argv, "-o");
    if (!out) out = "topol.tpr";
    if (!f && !c && !p) {
        const char *e1[] = {".mdp"}, *e2[] = {".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"}, *e3[] = {".top"};
        if (!exists_any("grompp", e1, 1) || !exists_any("conf", e2, 7) || !exists_any("topol", e3, 1))
            return error_missing_inputs("grompp");
    } else if ((f && access(f, R_OK) != 0) || (c && access(c, R_OK) != 0) || (p && access(p, R_OK) != 0)) {
        return error_missing_inputs("grompp");
    }
    FILE *fo = fopen(out, "wb");
    if (!fo) {
        perror(out);
        return 1;
    }
    fprintf(fo, "GROMACS portable run input placeholder\nversion=%s\n", VERSION);
    fclose(fo);
    FILE *mdout = fopen("mdout.mdp", "w");
    if (mdout) {
        fprintf(mdout, "; grompp output generated by clean-room implementation\n");
        fclose(mdout);
    }
    printf("Setting the LD random seed to 1\n");
    printf("Generated %s\n", out);
    return 0;
}

static int run_mdrun(int argc, char **argv) {
    const char *s = get_option_value(argc, argv, "-s");
    const char *deffnm = get_option_value(argc, argv, "-deffnm");
    char default_s[256] = "topol.tpr";
    if (!s && deffnm) {
        snprintf(default_s, sizeof(default_s), "%s.tpr", deffnm);
        s = default_s;
    }
    if (!s) {
        const char *exts[] = {".tpr"};
        if (!exists_any("topol", exts, 1)) return error_missing_inputs("mdrun");
        s = "topol.tpr";
    }
    if (access(s, R_OK) != 0) return error_missing_inputs("mdrun");
    const char *log = get_option_value(argc, argv, "-g");
    const char *conf = get_option_value(argc, argv, "-c");
    const char *ener = get_option_value(argc, argv, "-e");
    if (!log) log = deffnm ? "md.log" : "md.log";
    if (!conf) conf = "confout.gro";
    if (!ener) ener = "ener.edr";
    FILE *fl = fopen(log, "w");
    if (fl) {
        fprintf(fl, "GROMACS: gmx mdrun, version %s\nInput file: %s\n", VERSION, s);
        fclose(fl);
    }
    FILE *fc = fopen(conf, "w");
    if (fc) {
        fprintf(fc, "Generated by gmx mdrun\n    0\n   1.00000   1.00000   1.00000\n");
        fclose(fc);
    }
    FILE *fe = fopen(ener, "wb");
    if (fe) {
        fprintf(fe, "GROMACS energy placeholder\n");
        fclose(fe);
    }
    printf("Reading file %s, VERSION %s\n", s, VERSION);
    printf("starting mdrun\n");
    printf("Finished mdrun\n");
    return 0;
}

static int run_generic(const char *cmd) {
    printf("GROMACS:      gmx %s, version %s\n", cmd, VERSION);
    printf("This clean-room implementation does not perform the full '%s' analysis.\n", cmd);
    return 0;
}

int main(int argc, char **argv) {
    build_context(argc, argv);
    bool quiet = false, want_help = false, want_version = false, want_copyright = false;
    int idx = 1;
    while (idx < argc && argv[idx][0] == '-') {
        if (strcmp(argv[idx], "-quiet") == 0) quiet = true;
        else if (strcmp(argv[idx], "-h") == 0) want_help = true;
        else if (strcmp(argv[idx], "-version") == 0) want_version = true;
        else if (strcmp(argv[idx], "-copyright") == 0) want_copyright = true;
        else if (strcmp(argv[idx], "-nice") == 0 && idx + 1 < argc) idx++;
        else if (strcmp(argv[idx], "-backup") == 0 || strcmp(argv[idx], "-nobackup") == 0) {}
        else if (strcmp(argv[idx], "--help") == 0) {
            print_banner("executable");
            return error_unknown_option("executable", "--help");
        } else break;
        idx++;
    }

    if (want_copyright) print_copyright();
    if (want_version) {
        print_banner("executable");
        print_version();
        return 0;
    }

    if (idx >= argc) {
        if (!quiet) {
            print_banner("executable");
            if (!want_help) print_quote();
        }
        print_main_help();
        return 0;
    }

    const char *cmd = argv[idx++];
    if (strcmp(cmd, "help") == 0) {
        if (!quiet) print_banner("gmx help");
        if (idx >= argc) {
            if (!quiet) print_quote();
            print_main_help();
            return 0;
        }
        const char *topic = argv[idx++];
        if (strcmp(topic, "commands") == 0) {
            print_commands();
            return 0;
        }
        if (strcmp(topic, "selections") == 0) {
            print_selections(idx < argc ? argv[idx] : NULL);
            return 0;
        }
        const Command *hc = find_command(topic);
        if (hc) {
            print_command_help(hc);
            return 0;
        }
        printf("No help available for '%s'\n", topic);
        if (!quiet) print_quote();
        return 2;
    }

    const Command *c = find_command(cmd);
    if (!c) {
        print_banner("executable");
        return error_unknown_command(cmd);
    }

    char module[128];
    snprintf(module, sizeof(module), "gmx %s", cmd);
    if (!quiet) print_banner(module);

    for (int i = idx; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0) return error_unknown_option(module, "--help");
        if (strcmp(argv[i], "-h") == 0) {
            print_command_help(c);
            return 0;
        }
    }

    if (strcmp(cmd, "mdrun") == 0) return run_mdrun(argc - idx, argv + idx);
    if (strcmp(cmd, "grompp") == 0) return run_grompp(argc - idx, argv + idx);
    if (strcmp(cmd, "pdb2gmx") == 0) return run_pdb2gmx(argc - idx, argv + idx);

    if (argc == idx) return error_missing_inputs(cmd);
    return run_generic(cmd);
}
