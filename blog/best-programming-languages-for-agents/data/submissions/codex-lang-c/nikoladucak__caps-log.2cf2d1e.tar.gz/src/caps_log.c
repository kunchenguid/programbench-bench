#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <openssl/sha.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#define VERSION "commit-93cc85d16ab60ba8d646458fe0233778317b22a3"
#define DEFAULT_CONFIG "/home/agent/.caps-log/config.ini"
#define DEFAULT_LOG_DIR "/home/agent/.caps-log/day/"
#define DEFAULT_LOG_FORMAT "d%y_%m_%d.md"

typedef struct {
  char *config_path;
  char *log_dir_path;
  char *log_name_format;
  char *password;
  bool help;
  bool sunday_start;
  bool first_line_section;
  bool encrypt;
  bool decrypt;
} Options;

typedef struct {
  char **items;
  size_t count;
  size_t cap;
} StringSet;

static void die(const char *msg) {
  printf("Captain's log encountered an error: \n %s\n", msg);
  exit(1);
}

static void die_arg_missing(const char *opt) {
  char buf[256];
  snprintf(buf, sizeof(buf), "the required argument for option '%s' is missing", opt);
  die(buf);
}

static void die_unrecognized(const char *opt) {
  char buf[256];
  snprintf(buf, sizeof(buf), "unrecognised option '%s'", opt);
  die(buf);
}

static char *xstrdup(const char *s) {
  char *out = strdup(s ? s : "");
  if (!out) {
    perror("strdup");
    exit(2);
  }
  return out;
}

static char *trim(char *s) {
  while (*s && isspace((unsigned char)*s)) s++;
  char *end = s + strlen(s);
  while (end > s && isspace((unsigned char)end[-1])) *--end = '\0';
  return s;
}

static void set_string(char **slot, const char *value) {
  free(*slot);
  *slot = xstrdup(value);
}

static void print_help(void) {
  printf("Captain's Log (caps-log)! A CLI journalig tool.\n");
  printf("Version: %s\n", VERSION);
  printf("Allowed options:\n");
  printf("  -h [ --help ]         show this message\n");
  printf("  -c [ --config ] arg   override the default config file path \n");
  printf("                        (/home/agent/.caps-log/config.ini)\n");
  printf("  --log-dir-path arg    path where log files are stored\n");
  printf("  --log-name-format arg format in which log entry markdown files are saved\n");
  printf("  --sunday-start        have the calendar display sunday as first day of the \n");
  printf("                        week\n");
  printf("  --first-line-section  override the default behaviour of ignoring sections \n");
  printf("                        (lines starting with `#`) in the first line of a log \n");
  printf("                        entry file\n");
  printf("  --password arg        password for encrypted log repositories or to be used \n");
  printf("                        with --encrypt/--decrypt\n");
  printf("  --encrypt             apply encryption to all logs in log dir path (needs \n");
  printf("                        --password)\n");
  printf("  --decrypt             apply decryption to all logs in log dir path (needs \n");
  printf("                        --password)\n");
}

static void parse_args(int argc, char **argv, Options *opt) {
  opt->config_path = xstrdup(DEFAULT_CONFIG);
  opt->log_dir_path = xstrdup(DEFAULT_LOG_DIR);
  opt->log_name_format = xstrdup(DEFAULT_LOG_FORMAT);

  for (int i = 1; i < argc; i++) {
    const char *a = argv[i];
    if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
      opt->help = true;
    } else if (!strcmp(a, "-c") || !strcmp(a, "--config")) {
      if (++i >= argc) die_arg_missing(a);
      set_string(&opt->config_path, argv[i]);
    } else if (!strcmp(a, "--log-dir-path")) {
      if (++i >= argc) die_arg_missing(a);
      set_string(&opt->log_dir_path, argv[i]);
    } else if (!strcmp(a, "--log-name-format")) {
      if (++i >= argc) die_arg_missing(a);
      set_string(&opt->log_name_format, argv[i]);
    } else if (!strcmp(a, "--sunday-start")) {
      opt->sunday_start = true;
    } else if (!strcmp(a, "--first-line-section")) {
      opt->first_line_section = true;
    } else if (!strcmp(a, "--password")) {
      if (++i >= argc) die_arg_missing(a);
      set_string(&opt->password, argv[i]);
    } else if (!strcmp(a, "--encrypt")) {
      opt->encrypt = true;
    } else if (!strcmp(a, "--decrypt")) {
      opt->decrypt = true;
    } else {
      die_unrecognized(a);
    }
  }
}

static bool parse_bool(const char *v) {
  return !strcasecmp(v, "true") || !strcmp(v, "1") || !strcasecmp(v, "yes") ||
         !strcasecmp(v, "on");
}

static void read_config(Options *opt) {
  FILE *f = fopen(opt->config_path, "r");
  if (!f) {
    char buf[512];
    snprintf(buf, sizeof(buf), "Failed to open file: %s", opt->config_path);
    die(buf);
  }

  char line[4096];
  while (fgets(line, sizeof(line), f)) {
    char *hash = strchr(line, '#');
    if (hash) *hash = '\0';
    char *s = trim(line);
    if (*s == '\0' || *s == '[') continue;
    char *eq = strchr(s, '=');
    if (!eq) continue;
    *eq = '\0';
    char *key = trim(s);
    char *val = trim(eq + 1);
    if (!strcmp(key, "log-dir-path")) set_string(&opt->log_dir_path, val);
    else if (!strcmp(key, "log-filename-format") || !strcmp(key, "log-name-format")) set_string(&opt->log_name_format, val);
    else if (!strcmp(key, "sunday-start")) opt->sunday_start = parse_bool(val);
    else if (!strcmp(key, "first-line-section")) opt->first_line_section = parse_bool(val);
    else if (!strcmp(key, "password")) set_string(&opt->password, val);
  }
  fclose(f);
}

static void marker_for_password(const char *password, unsigned char out[18]) {
  unsigned char digest[SHA256_DIGEST_LENGTH];
  SHA256((const unsigned char *)password, strlen(password), digest);
  memcpy(out, digest, 18);
}

static char *join_path(const char *dir, const char *name) {
  size_t dl = strlen(dir), nl = strlen(name);
  bool slash = dl > 0 && dir[dl - 1] == '/';
  char *out = malloc(dl + nl + (slash ? 1 : 2));
  if (!out) exit(2);
  sprintf(out, "%s%s%s", dir, slash ? "" : "/", name);
  return out;
}

static char *marker_path(const Options *opt) {
  return join_path(opt->log_dir_path, ".cle");
}

static bool file_exists(const char *path) {
  struct stat st;
  return stat(path, &st) == 0;
}

static void write_marker(const Options *opt) {
  char *path = marker_path(opt);
  if (file_exists(path)) {
    free(path);
    die("Already applied");
  }
  FILE *f = fopen(path, "wb");
  if (!f) {
    free(path);
    die("Failed to apply crypto");
  }
  unsigned char marker[18];
  marker_for_password(opt->password, marker);
  fwrite(marker, 1, sizeof(marker), f);
  fclose(f);
  free(path);
}

static bool check_marker(const Options *opt) {
  char *path = marker_path(opt);
  FILE *f = fopen(path, "rb");
  if (!f) {
    free(path);
    return false;
  }
  unsigned char expected[18], actual[18];
  marker_for_password(opt->password ? opt->password : "", expected);
  size_t n = fread(actual, 1, sizeof(actual), f);
  fclose(f);
  free(path);
  return n == sizeof(actual) && memcmp(expected, actual, sizeof(actual)) == 0;
}

static void remove_marker(const Options *opt) {
  char *path = marker_path(opt);
  if (!file_exists(path)) {
    free(path);
    die("Already applied");
  }
  unlink(path);
  free(path);
}

static void set_add(StringSet *set, const char *value) {
  if (!value || !*value) return;
  for (size_t i = 0; i < set->count; i++) {
    if (!strcmp(set->items[i], value)) return;
  }
  if (set->count == set->cap) {
    set->cap = set->cap ? set->cap * 2 : 8;
    set->items = realloc(set->items, set->cap * sizeof(char *));
    if (!set->items) exit(2);
  }
  set->items[set->count++] = xstrdup(value);
}

static int cmp_strptr(const void *a, const void *b) {
  const char *const *sa = a;
  const char *const *sb = b;
  return strcmp(*sa, *sb);
}

static bool parse_date_from_name(const char *name, const char *fmt, int *yy, int *mm, int *dd) {
  const char *p = name, *f = fmt;
  *yy = *mm = *dd = -1;
  while (*f && *p) {
    if (*f == '%') {
      f++;
      int digits = 0, val = 0;
      if (*f == 'y' || *f == 'm' || *f == 'd') {
        while (digits < 2 && isdigit((unsigned char)p[digits])) {
          val = val * 10 + (p[digits] - '0');
          digits++;
        }
        if (digits != 2) return false;
        if (*f == 'y') *yy = val;
        else if (*f == 'm') *mm = val;
        else *dd = val;
        p += 2;
        f++;
      } else if (*f == 'Y') {
        for (digits = 0; digits < 4 && isdigit((unsigned char)p[digits]); digits++) val = val * 10 + (p[digits] - '0');
        if (digits != 4) return false;
        *yy = val % 100;
        p += 4;
        f++;
      } else {
        if (*p++ != *f++) return false;
      }
    } else if (*f == *p) {
      f++;
      p++;
    } else {
      return false;
    }
  }
  return *f == '\0' && *p == '\0' && *yy >= 0 && *mm >= 1 && *mm <= 12 && *dd >= 1 && *dd <= 31;
}

static char *tag_label(char *s) {
  s = trim(s);
  if (*s == '*') s++;
  s = trim(s);
  char *colon = strchr(s, ':');
  if (colon) *colon = '\0';
  return trim(s);
}

static void scan_file(const char *path, bool first_line_section, StringSet *sections, StringSet *tags) {
  FILE *f = fopen(path, "r");
  if (!f) return;
  char line[4096];
  int line_no = 0;
  bool have_section = false;
  while (fgets(line, sizeof(line), f)) {
    line_no++;
    char *s = trim(line);
    if (*s == '#' && (line_no != 1 || first_line_section)) {
      while (*s == '#') s++;
      s = trim(s);
      if (*s) {
        set_add(sections, s);
        have_section = true;
      }
    } else if (*s == '*') {
      set_add(tags, tag_label(s));
      if (!have_section) set_add(sections, "<root section>");
    }
  }
  fclose(f);
}

static int scan_logs(const Options *opt, StringSet *sections, StringSet *tags) {
  DIR *dir = opendir(opt->log_dir_path);
  if (!dir) return 0;
  int count = 0;
  struct dirent *ent;
  while ((ent = readdir(dir))) {
    if (ent->d_name[0] == '.') continue;
    int yy, mm, dd;
    if (!parse_date_from_name(ent->d_name, opt->log_name_format, &yy, &mm, &dd)) continue;
    count++;
    char *path = join_path(opt->log_dir_path, ent->d_name);
    scan_file(path, opt->first_line_section, sections, tags);
    free(path);
  }
  closedir(dir);
  qsort(sections->items, sections->count, sizeof(char *), cmp_strptr);
  qsort(tags->items, tags->count, sizeof(char *), cmp_strptr);
  return count;
}

static void print_list_box(const char *title, const StringSet *set) {
  printf("%s\n", title);
  if (set->count == 0) {
    printf("> <select none>\n");
    return;
  }
  for (size_t i = 0; i < set->count; i++) {
    printf("%c %s\n", i == 0 ? '>' : ' ', set->items[i]);
  }
}

static void print_calendar_summary(const Options *opt) {
  StringSet sections = {0}, tags = {0};
  int entries = scan_logs(opt, &sections, &tags);
  time_t now = time(NULL);
  struct tm tmv;
  localtime_r(&now, &tmv);
  printf("Today is: %02d. %02d. %04d.  | There are %d log entries for year %04d.\n",
         tmv.tm_mday, tmv.tm_mon + 1, tmv.tm_year + 1900, entries, tmv.tm_year + 1900);
  print_list_box("Sections", &sections);
  print_list_box("Tags", &tags);
  printf("%04d\n", tmv.tm_year + 1900);
  printf("log preview for %02d. %02d. %02d.\n", tmv.tm_mday, tmv.tm_mon + 1, (tmv.tm_year + 1900) % 100);
  fflush(stdout);
  for (size_t i = 0; i < sections.count; i++) free(sections.items[i]);
  for (size_t i = 0; i < tags.count; i++) free(tags.items[i]);
  free(sections.items);
  free(tags.items);
}

static char *read_password_from_tty(void) {
  printf("Enter password for log files:");
  fflush(stdout);
  char buf[512];
  if (!fgets(buf, sizeof(buf), stdin)) return xstrdup("");
  buf[strcspn(buf, "\r\n")] = '\0';
  return xstrdup(buf);
}

int main(int argc, char **argv) {
  Options opt = {0};
  parse_args(argc, argv, &opt);
  if (opt.help) {
    print_help();
    return 0;
  }
  read_config(&opt);

  if (opt.encrypt && opt.decrypt) die("Cannot encrypt and decrypt at the same time!");
  if (opt.encrypt) {
    if (!opt.password || !*opt.password) die("Password must be provided when encrypting logs!");
    printf("Applying crypto...\n");
    write_marker(&opt);
    return 0;
  }
  if (opt.decrypt) {
    if (!opt.password || !*opt.password) die("Password must be provided when decrypting logs!");
    printf("Applying crypto...\n");
    remove_marker(&opt);
    return 0;
  }

  char *mp = marker_path(&opt);
  bool encrypted = file_exists(mp);
  free(mp);
  if (encrypted) {
    if (!opt.password) opt.password = read_password_from_tty();
    if (!check_marker(&opt)) die("Invalid password provided!");
  }

  print_calendar_summary(&opt);
  if (isatty(STDIN_FILENO)) {
    char ch;
    while (read(STDIN_FILENO, &ch, 1) == 1) {
      if (ch == 'q' || ch == 3 || ch == 4) break;
    }
  }
  return 0;
}
