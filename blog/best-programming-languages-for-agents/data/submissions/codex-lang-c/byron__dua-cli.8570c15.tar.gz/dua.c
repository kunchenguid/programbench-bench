#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <dirent.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

#define GREEN "\033[32m"
#define CYAN "\033[36m"
#define RESET "\033[39m"

typedef enum { F_BINARY, F_METRIC, F_BYTES, F_GB, F_GIB, F_MB, F_MIB } Format;

typedef struct {
    int apparent, count_links, stay_fs, stats, no_sort, no_total;
    Format format;
    char **ignore;
    size_t ignore_len;
} Options;

typedef struct {
    dev_t dev;
    ino_t ino;
} Seen;

typedef struct {
    char *path;
    char *label;
    uint64_t size;
    int is_dir;
    int errors;
    size_t order;
} Row;

typedef struct {
    Seen *seen;
    size_t seen_len, seen_cap;
    uint64_t smallest, largest;
    uint64_t entries;
    int any_stat;
    Options *opt;
} Ctx;

static char *xstrdup(const char *s) {
    char *out = strdup(s ? s : "");
    if (!out) { perror("strdup"); exit(2); }
    return out;
}

static char *join_path(const char *a, const char *b) {
    size_t alen = strlen(a), blen = strlen(b);
    int slash = alen && a[alen - 1] != '/';
    char *out = malloc(alen + slash + blen + 1);
    if (!out) { perror("malloc"); exit(2); }
    memcpy(out, a, alen);
    if (slash) out[alen++] = '/';
    memcpy(out + alen, b, blen + 1);
    return out;
}

static uint64_t entry_size(const struct stat *st, int apparent) {
    if (apparent) return (uint64_t)st->st_size;
    return (uint64_t)st->st_blocks * 512ULL;
}

static int seen_contains(Ctx *ctx, const struct stat *st) {
    if (ctx->opt->count_links || st->st_nlink <= 1 || S_ISDIR(st->st_mode)) return 0;
    for (size_t i = 0; i < ctx->seen_len; i++)
        if (ctx->seen[i].dev == st->st_dev && ctx->seen[i].ino == st->st_ino) return 1;
    if (ctx->seen_len == ctx->seen_cap) {
        ctx->seen_cap = ctx->seen_cap ? ctx->seen_cap * 2 : 128;
        ctx->seen = realloc(ctx->seen, ctx->seen_cap * sizeof(Seen));
        if (!ctx->seen) { perror("realloc"); exit(2); }
    }
    ctx->seen[ctx->seen_len++] = (Seen){ st->st_dev, st->st_ino };
    return 0;
}

static int should_ignore(Ctx *ctx, const char *path) {
    for (size_t i = 0; i < ctx->opt->ignore_len; i++)
        if (strcmp(path, ctx->opt->ignore[i]) == 0) return 1;
    return 0;
}

static void stat_seen(Ctx *ctx, uint64_t v) {
    ctx->entries++;
    if (!ctx->any_stat || v < ctx->smallest) ctx->smallest = v;
    if (!ctx->any_stat || v > ctx->largest) ctx->largest = v;
    ctx->any_stat = 1;
}

static uint64_t scan_path(Ctx *ctx, const char *path, dev_t root_dev, int *is_dir, int *errors, int explicit_root) {
    struct stat st;
    if (lstat(path, &st) != 0) {
        (*errors)++;
        *is_dir = 1;
        return 0;
    }
    if (S_ISLNK(st.st_mode)) return entry_size(&st, ctx->opt->apparent);
    uint64_t own = seen_contains(ctx, &st) ? 0 : entry_size(&st, ctx->opt->apparent);
    stat_seen(ctx, own);
    *is_dir = S_ISDIR(st.st_mode);
    if (!S_ISDIR(st.st_mode)) return own;
    if (!explicit_root && should_ignore(ctx, path)) return 0;
    if (ctx->opt->stay_fs && st.st_dev != root_dev) return own;
    uint64_t total = own;
    DIR *d = opendir(path);
    if (!d) {
        (*errors)++;
        return total;
    }
    struct dirent *de;
    while ((de = readdir(d))) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;
        char *child = join_path(path, de->d_name);
        struct stat lst;
        if (lstat(child, &lst) == 0 && S_ISLNK(lst.st_mode)) {
            free(child);
            continue;
        }
        int child_dir = 0;
        total += scan_path(ctx, child, root_dev, &child_dir, errors, 0);
        free(child);
    }
    closedir(d);
    return total;
}

static void add_row(Row **rows, size_t *len, size_t *cap, Row r) {
    if (*len == *cap) {
        *cap = *cap ? *cap * 2 : 32;
        *rows = realloc(*rows, *cap * sizeof(Row));
        if (!*rows) { perror("realloc"); exit(2); }
    }
    (*rows)[(*len)++] = r;
}

static int cmp_rows(const void *a, const void *b) {
    const Row *ra = a, *rb = b;
    if (ra->size < rb->size) return -1;
    if (ra->size > rb->size) return 1;
    int c = strcmp(ra->label, rb->label);
    if (c) return c;
    return (ra->order > rb->order) - (ra->order < rb->order);
}

static void fmt_size(uint64_t bytes, Format f, char out[64]) {
    const char *units_bin[] = {"B", "KiB", "MiB", "GiB", "TiB", "PiB"};
    const char *units_met[] = {"B", "KB", "MB", "GB", "TB", "PB"};
    if (f == F_BYTES) { snprintf(out, 64, "%10llu b", (unsigned long long)bytes); return; }
    if (f == F_GB) { snprintf(out, 64, "%7.2f GB", bytes / 1000000000.0); return; }
    if (f == F_GIB) { snprintf(out, 64, "%6.2f GiB", bytes / 1073741824.0); return; }
    if (f == F_MB) { snprintf(out, 64, "%8.2f MB", bytes / 1000000.0); return; }
    if (f == F_MIB) { snprintf(out, 64, "%7.2f MiB", bytes / 1048576.0); return; }
    double v = (double)bytes, step = (f == F_METRIC) ? 1000.0 : 1024.0;
    const char **units = (f == F_METRIC) ? units_met : units_bin;
    int u = 0;
    while (v > step && u < 5) { v /= step; u++; }
    if (u == 0) snprintf(out, 64, (f == F_METRIC) ? "%7.0f  %s" : "%7.0f   %s", v, units[u]);
    else snprintf(out, 64, "%7.2f %s", v, units[u]);
}

static void output_row(const Row *r, Format f) {
    char sz[64];
    fmt_size(r->size, f, sz);
    printf(GREEN "%s" RESET " ", sz);
    if (r->is_dir) printf(CYAN "%s" RESET, r->label);
    else printf("%s", r->label);
    if (r->errors) printf("  <%d IO Error%s>", r->errors, r->errors == 1 ? "" : "s");
    putchar('\n');
}

static int collect_dir_entries(Ctx *ctx, const char *dir, Row **rows, size_t *len, size_t *cap, int labels_base) {
    DIR *d = opendir(dir);
    if (!d) return 1;
    struct stat rootst;
    dev_t rootdev = 0;
    if (lstat(dir, &rootst) == 0) rootdev = rootst.st_dev;
    struct dirent *de;
    size_t order = *len;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
        char *p = join_path(dir, de->d_name);
        struct stat lst;
        if (lstat(p, &lst) == 0 && S_ISLNK(lst.st_mode)) { free(p); continue; }
        int is_dir = 0, errors = 0;
        uint64_t s = scan_path(ctx, p, rootdev, &is_dir, &errors, 1);
        add_row(rows, len, cap, (Row){ p, xstrdup(labels_base ? de->d_name : p), s, is_dir, errors, order++ });
    }
    closedir(d);
    return 0;
}

static void usage_main(void) {
    puts("A tool to learn about disk usage, fast!\n");
    puts("Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n");
    puts("Commands:\n  interactive  Launch the terminal user interface [aliases: i]\n  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]\n  completions  Generate shell completions\n  help         Print this message or the help of the given subcommand(s)\n");
    puts("Arguments:\n  [INPUT]...\n          One or more input files or directories. If unset, we will use all entries in the current working directory\n");
    puts("Options:\n  -t, --threads <THREADS>\n          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread\n          \n          [default: 0]\n\n  -f, --format <FORMAT>\n          The format with which to print byte counts\n          \n          [default: binary]\n          [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\n  -A, --apparent-size\n          Display apparent size instead of disk usage\n\n  -l, --count-hard-links\n          Count hard-linked files each time they are seen\n\n  -x, --stay-on-filesystem\n          If set, we will not cross filesystems or traverse mount points\n\n  -i, --ignore-dirs <IGNORE_DIRS>\n          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.\n          \n          Hence, they will only be ignored if they are eventually reached as part of the traversal.\n          \n          [default: /proc /dev /sys /run]\n\n      --log-file <LOG_FILE>\n          Write a log file with debug information, including panics\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
}

static void usage_agg(const char *prog) {
    printf("Aggregate the consumed space of one or more directories or files\n\nUsage: %s aggregate [OPTIONS] [INPUT]...\n\n", prog);
    puts("Options:\n      --stats     If set, print additional statistics about the file traversal to stderr\n      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending\n      --no-total  If set, no total column will be computed for multiple inputs\n  -h, --help      Print help");
}

static int parse_format(const char *s, Format *f) {
    if (!strcmp(s, "binary")) *f = F_BINARY;
    else if (!strcmp(s, "metric")) *f = F_METRIC;
    else if (!strcmp(s, "bytes")) *f = F_BYTES;
    else if (!strcmp(s, "gb")) *f = F_GB;
    else if (!strcmp(s, "gib")) *f = F_GIB;
    else if (!strcmp(s, "mb")) *f = F_MB;
    else if (!strcmp(s, "mib")) *f = F_MIB;
    else return 0;
    return 1;
}

static void add_ignore(Options *o, const char *p) {
    o->ignore = realloc(o->ignore, (o->ignore_len + 1) * sizeof(char *));
    if (!o->ignore) { perror("realloc"); exit(2); }
    o->ignore[o->ignore_len++] = xstrdup(p);
}

static int is_command(const char *s) {
    return !strcmp(s, "aggregate") || !strcmp(s, "a") || !strcmp(s, "interactive") ||
           !strcmp(s, "i") || !strcmp(s, "completions") || !strcmp(s, "help");
}

int main(int argc, char **argv) {
    Options opt = {0};
    opt.format = F_BINARY;
    add_ignore(&opt, "/proc"); add_ignore(&opt, "/dev"); add_ignore(&opt, "/sys"); add_ignore(&opt, "/run");
    char *prog = strrchr(argv[0], '/');
    prog = prog ? prog + 1 : argv[0];
    int i = 1, end_opts = 0;
    while (i < argc && !end_opts && !is_command(argv[i])) {
        char *a = argv[i];
        if (!strcmp(a, "--")) { end_opts = 1; i++; break; }
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage_main(); return 0; }
        if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("dua 2.32.2"); return 0; }
        if (!strcmp(a, "-A") || !strcmp(a, "--apparent-size")) { opt.apparent = 1; i++; continue; }
        if (!strcmp(a, "-l") || !strcmp(a, "--count-hard-links")) { opt.count_links = 1; i++; continue; }
        if (!strcmp(a, "-x") || !strcmp(a, "--stay-on-filesystem")) { opt.stay_fs = 1; i++; continue; }
        if ((!strcmp(a, "-t") || !strcmp(a, "--threads") || !strcmp(a, "--log-file")) && i + 1 < argc) { i += 2; continue; }
        if ((!strcmp(a, "-f") || !strcmp(a, "--format")) && i + 1 < argc) {
            if (!parse_format(argv[i + 1], &opt.format)) {
                fprintf(stderr, "error: invalid value '%s' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n", argv[i + 1]);
                return 2;
            }
            i += 2; continue;
        }
        if ((!strcmp(a, "-i") || !strcmp(a, "--ignore-dirs")) && i + 1 < argc) { add_ignore(&opt, argv[i + 1]); i += 2; continue; }
        if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nFor more information, try '--help'.\n", a, a, a);
            return 2;
        }
        break;
    }
    const char *cmd = "aggregate";
    if (i < argc && is_command(argv[i])) cmd = argv[i++];
    if (!strcmp(cmd, "help")) { usage_main(); return 0; }
    if (!strcmp(cmd, "interactive") || !strcmp(cmd, "i")) {
        if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) {
            puts("Launch the terminal user interface\n\nUsage: dua interactive [OPTIONS] [INPUT]...\n\nOptions:\n  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems\n  -h, --help            Print help");
            return 0;
        }
        fprintf(stderr, "Error: Interactive mode requires a connected terminal\n");
        return 1;
    }
    if (!strcmp(cmd, "completions")) {
        if (i >= argc || !strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            puts("Generate shell completions\n\nUsage: dua completions <SHELL>\n\nArguments:\n  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]\n\nOptions:\n  -h, --help  Print help");
            return i >= argc ? 2 : 0;
        }
        printf("# completion script for dua (%s)\n", argv[i]);
        return 0;
    }
    if (!strcmp(cmd, "aggregate") || !strcmp(cmd, "a")) {
        while (i < argc) {
            if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { usage_agg(prog); return 0; }
            if (!strcmp(argv[i], "--stats")) { opt.stats = 1; i++; continue; }
            if (!strcmp(argv[i], "--no-sort")) { opt.no_sort = 1; i++; continue; }
            if (!strcmp(argv[i], "--no-total")) { opt.no_total = 1; i++; continue; }
            if (argv[i][0] == '-') {
                fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: %s aggregate [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n", argv[i], argv[i], argv[i], prog);
                return 2;
            }
            break;
        }
    }
    Ctx ctx = {0}; ctx.opt = &opt;
    Row *rows = NULL; size_t len = 0, cap = 0;
    int exit_code = 0;
    if (i >= argc) {
        if (collect_dir_entries(&ctx, ".", &rows, &len, &cap, 1)) exit_code = 1;
    } else if (argc - i == 1) {
        struct stat st;
        if (lstat(argv[i], &st) == 0 && S_ISDIR(st.st_mode)) {
            if (collect_dir_entries(&ctx, argv[i], &rows, &len, &cap, 1)) exit_code = 1;
        } else {
            int is_dir = 0, errors = 0;
            dev_t dev = (lstat(argv[i], &st) == 0) ? st.st_dev : 0;
            uint64_t s = scan_path(&ctx, argv[i], dev, &is_dir, &errors, 1);
            add_row(&rows, &len, &cap, (Row){ xstrdup(argv[i]), xstrdup(argv[i]), s, is_dir, errors, 0 });
            if (errors) exit_code = 1;
        }
    } else {
        for (int j = i; j < argc; j++) {
            struct stat st;
            int is_dir = 0, errors = 0;
            dev_t dev = (lstat(argv[j], &st) == 0) ? st.st_dev : 0;
            uint64_t s = scan_path(&ctx, argv[j], dev, &is_dir, &errors, 1);
            add_row(&rows, &len, &cap, (Row){ xstrdup(argv[j]), xstrdup(argv[j]), s, is_dir, errors, (size_t)(j - i) });
            if (errors) exit_code = 1;
        }
    }
    if (!opt.no_sort) qsort(rows, len, sizeof(Row), cmp_rows);
    uint64_t total = 0;
    for (size_t r = 0; r < len; r++) { output_row(&rows[r], opt.format); total += rows[r].size; }
    if (!opt.no_total && len > 1) {
        Row t = { .label = "total", .size = total };
        output_row(&t, opt.format);
    }
    if (opt.stats) {
        fflush(stdout);
        fprintf(stderr, "Statistics { entries_traversed: %llu, smallest_file_in_bytes: %llu, largest_file_in_bytes: %llu }\n",
                (unsigned long long)ctx.entries, (unsigned long long)(ctx.any_stat ? ctx.smallest : 0),
                (unsigned long long)(ctx.any_stat ? ctx.largest : 0));
    }
    return exit_code;
}
