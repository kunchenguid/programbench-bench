#define _DEFAULT_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct {
    char **items;
    size_t len;
    size_t cap;
} StrList;

typedef struct {
    regex_t rx;
    bool valid;
    bool use_group;
} Pattern;

typedef struct {
    Pattern *items;
    size_t len;
    size_t cap;
} PatList;

static bool only_matching = false;
static bool strict_ignore = false;
static bool found_secret = false;
static StrList ignore_patterns = {0};
static StrList ignored_secrets = {0};
static PatList patterns = {0};

static const char *help_long =
"ripsecrets searches files and directories recursively for secret API keys.\n"
"It's primarily designed to be used as a pre-commit to prevent committing\n"
"secrets into version control.\n"
"\n"
"Usage: executable [OPTIONS] [Source files]...\n"
"\n"
"Arguments:\n"
"  [Source files]...\n"
"          Source files. Can be files or directories. Defaults to '.'\n"
"\n"
"Options:\n"
"      --install-pre-commit\n"
"          Install `ripsecrets` as a pre-commit hook automatically in git directory provided\n"
"\n"
"      --strict-ignore\n"
"          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit\n"
"\n"
"      --only-matching\n"
"          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line\n"
"\n"
"      --additional-pattern <ADDITIONAL_PATTERNS>\n"
"          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret\n"
"\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n"
"\n"
"  -V, --version\n"
"          Print version\n";

static const char *help_short =
"A command-line tool to prevent committing secret keys into your source code\n"
"\n"
"Usage: executable [OPTIONS] [Source files]...\n"
"\n"
"Arguments:\n"
"  [Source files]...  Source files. Can be files or directories. Defaults to '.'\n"
"\n"
"Options:\n"
"      --install-pre-commit\n"
"          Install `ripsecrets` as a pre-commit hook automatically in git directory provided\n"
"      --strict-ignore\n"
"          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit\n"
"      --only-matching\n"
"          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line\n"
"      --additional-pattern <ADDITIONAL_PATTERNS>\n"
"          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret\n"
"  -h, --help\n"
"          Print help (see more with '--help')\n"
"  -V, --version\n"
"          Print version\n";

static void push_str(StrList *l, const char *s) {
    if (l->len == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->items = realloc(l->items, l->cap * sizeof(char *));
        if (!l->items) exit(2);
    }
    l->items[l->len++] = strdup(s);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool contains_secret_ignore(const char *s, size_t n) {
    for (size_t i = 0; i < ignored_secrets.len; i++) {
        const char *v = ignored_secrets.items[i];
        if (strlen(v) == n && strncmp(v, s, n) == 0) return true;
    }
    return false;
}

static void add_pattern_ex(const char *expr, bool use_group) {
    if (patterns.len == patterns.cap) {
        patterns.cap = patterns.cap ? patterns.cap * 2 : 32;
        patterns.items = realloc(patterns.items, patterns.cap * sizeof(Pattern));
        if (!patterns.items) exit(2);
    }
    Pattern *p = &patterns.items[patterns.len++];
    p->use_group = use_group;
    p->valid = regcomp(&p->rx, expr, REG_EXTENDED | REG_NEWLINE) == 0;
}

static void add_pattern(const char *expr) {
    add_pattern_ex(expr, false);
}

static void add_builtin_patterns(void) {
    add_pattern("AKIA[0-9A-Z]{16}");
    add_pattern("ASIA[0-9A-Z]{16}");
    add_pattern("A3T[A-Z0-9]{16}");
    add_pattern("AGPA[0-9A-Z]{16}");
    add_pattern("AIDA[0-9A-Z]{16}");
    add_pattern("AROA[0-9A-Z]{16}");
    add_pattern("aws(.{0,20})?(secret|access).{0,20}[=:][[:space:]]*['\\\"]?[A-Za-z0-9/+=]{32,}");
    add_pattern("gh[pousr]_[A-Za-z0-9_]{36}");
    add_pattern("github_pat_[A-Za-z0-9_]{20,}_[A-Za-z0-9_]{20,}");
    add_pattern("glpat-[A-Za-z0-9_-]{20,}");
    add_pattern("xox[baprs]-[A-Za-z0-9-]{10,}");
    add_pattern("sk_live_[A-Za-z0-9]{20,}");
    add_pattern("pk_live_[A-Za-z0-9]{20,}");
    add_pattern("rk_live_[A-Za-z0-9]{20,}");
    add_pattern("sk-[A-Za-z0-9]{32,}");
    add_pattern("SG\\.[A-Za-z0-9_-]{16,}\\.[A-Za-z0-9_-]{16,}");
    add_pattern("AIza[0-9A-Za-z_-]{35}");
    add_pattern("ya29\\.[0-9A-Za-z_-]{20,}");
    add_pattern("AC[0-9a-fA-F]{32}");
    add_pattern("key-[0-9a-fA-F]{32}");
    add_pattern("[0-9a-f]{32}-us[0-9]{1,2}");
    add_pattern("HEROKU_API_KEY[[:space:]]*=?[[:space:]]*[0-9a-fA-F-]{36}");
    add_pattern("-----BEGIN (RSA |DSA |EC |OPENSSH |PGP )?PRIVATE KEY-----");
    add_pattern("eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}");
    add_pattern("(password|passwd|pwd|secret|token|api[_-]?key|private[_-]?key)[[:space:]]*[:=][[:space:]]*['\\\"]?[A-Za-z0-9_./+=-]{16,}");
}

static void load_ignore_file(void) {
    FILE *f = fopen(".secretsignore", "r");
    if (!f) return;
    char *line = NULL;
    size_t cap = 0;
    bool in_secrets = false;
    while (getline(&line, &cap, f) != -1) {
        char *t = trim(line);
        if (*t == 0 || *t == '#') continue;
        if (strcmp(t, "[secrets]") == 0) {
            in_secrets = true;
            continue;
        }
        if (*t == '[') {
            in_secrets = false;
            continue;
        }
        if (in_secrets) push_str(&ignored_secrets, t);
        else push_str(&ignore_patterns, t);
    }
    free(line);
    fclose(f);
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static bool is_ignored_path(const char *path) {
    const char *p = path;
    if (strncmp(p, "./", 2) == 0) p += 2;
    for (size_t i = 0; i < ignore_patterns.len; i++) {
        const char *pat = ignore_patterns.items[i];
        size_t n = strlen(pat);
        if (n == 0) continue;
        if (pat[n - 1] == '/') {
            if (strncmp(p, pat, n) == 0) return true;
            char pref[1024];
            snprintf(pref, sizeof(pref), "*/%s", pat);
            if (fnmatch(pref, p, 0) == 0) return true;
        } else {
            if (fnmatch(pat, p, 0) == 0 || fnmatch(pat, base_name(p), 0) == 0) return true;
        }
    }
    return false;
}

static bool path_has_component(const char *path, const char *component) {
    const char *p = path;
    size_t n = strlen(component);
    while (*p) {
        while (*p == '/') p++;
        if (strncmp(p, component, n) == 0 && (p[n] == '/' || p[n] == 0)) return true;
        while (*p && *p != '/') p++;
    }
    return false;
}

static void print_match(const char *disp, long line_no, const char *line, regmatch_t m) {
    size_t len = (size_t)(m.rm_eo - m.rm_so);
    if (len == 0) return;
    if (contains_secret_ignore(line + m.rm_so, len)) return;
    found_secret = true;
    if (only_matching) {
        printf("%s:%ld:%.*s\n", disp, line_no, (int)len, line + m.rm_so);
    } else {
        printf("%s:%ld:%s\n", disp, line_no, line);
    }
}

static void scan_line(const char *disp, long line_no, char *line) {
    size_t ll = strlen(line);
    while (ll && (line[ll - 1] == '\n' || line[ll - 1] == '\r')) line[--ll] = 0;
    bool printed = false;
    for (size_t i = 0; i < patterns.len; i++) {
        if (!patterns.items[i].valid) continue;
        const char *cursor = line;
        size_t offset = 0;
        regmatch_t m[2];
        while (regexec(&patterns.items[i].rx, cursor, 2, m, 0) == 0) {
            int idx = (patterns.items[i].use_group && m[1].rm_so != -1) ? 1 : 0;
            if (m[idx].rm_so == -1) break;
            regmatch_t abs_m = {m[idx].rm_so + (regoff_t)offset, m[idx].rm_eo + (regoff_t)offset};
            if (!printed || only_matching) print_match(disp, line_no, line, abs_m);
            printed = true;
            if (!only_matching) return;
            if (m[0].rm_eo <= 0) break;
            offset += (size_t)m[0].rm_eo;
            cursor += m[0].rm_eo;
        }
    }
}

static void scan_file(const char *path, const char *disp) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "%s: %s (os error %d)\n", path, strerror(errno), errno);
        return;
    }
    char *line = NULL;
    size_t cap = 0;
    long line_no = 1;
    while (getline(&line, &cap, f) != -1) {
        if (memchr(line, '\0', strlen(line))) {
            line_no++;
            continue;
        }
        scan_line(disp, line_no++, line);
    }
    free(line);
    fclose(f);
}

typedef struct {
    char **dirs;
    size_t ndirs, cdirs;
    char **files;
    size_t nfiles, cfiles;
} Entries;

static int cmpstr(const void *a, const void *b) {
    const char *const *sa = a;
    const char *const *sb = b;
    return strcmp(*sa, *sb);
}

static void epush(char ***arr, size_t *len, size_t *cap, const char *s) {
    if (*len == *cap) {
        *cap = *cap ? *cap * 2 : 16;
        *arr = realloc(*arr, *cap * sizeof(char *));
        if (!*arr) exit(2);
    }
    (*arr)[(*len)++] = strdup(s);
}

static void scan_path(const char *path, const char *disp, bool explicit_arg) {
    if ((!explicit_arg || strict_ignore) && is_ignored_path(disp)) return;
    if (path_has_component(disp, ".git")) return;
    struct stat st;
    if (lstat(path, &st) != 0) {
        fprintf(stderr, "%s: %s (os error %d)\n", path, strerror(errno), errno);
        return;
    }
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) {
            fprintf(stderr, "%s: %s (os error %d)\n", path, strerror(errno), errno);
            return;
        }
        Entries e = {0};
        struct dirent *de;
        while ((de = readdir(d)) != NULL) {
            if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;
            if (strcmp(de->d_name, ".git") == 0) continue;
            char child[4096];
            snprintf(child, sizeof(child), "%s/%s", path, de->d_name);
            struct stat cst;
            if (lstat(child, &cst) != 0) continue;
            if (S_ISDIR(cst.st_mode)) epush(&e.dirs, &e.ndirs, &e.cdirs, de->d_name);
            else if (S_ISREG(cst.st_mode)) epush(&e.files, &e.nfiles, &e.cfiles, de->d_name);
        }
        closedir(d);
        qsort(e.dirs, e.ndirs, sizeof(char *), cmpstr);
        qsort(e.files, e.nfiles, sizeof(char *), cmpstr);
        for (size_t i = 0; i < e.ndirs; i++) {
            char child[4096], cdisp[4096];
            snprintf(child, sizeof(child), "%s/%s", path, e.dirs[i]);
            snprintf(cdisp, sizeof(cdisp), "%s/%s", disp, e.dirs[i]);
            scan_path(child, cdisp, false);
            free(e.dirs[i]);
        }
        for (size_t i = 0; i < e.nfiles; i++) {
            char child[4096], cdisp[4096];
            snprintf(child, sizeof(child), "%s/%s", path, e.files[i]);
            snprintf(cdisp, sizeof(cdisp), "%s/%s", disp, e.files[i]);
            scan_path(child, cdisp, false);
            free(e.files[i]);
        }
        free(e.dirs);
        free(e.files);
    } else if (S_ISREG(st.st_mode)) {
        scan_file(path, disp);
    }
}

static int install_pre_commit(void) {
    struct stat st;
    if (stat(".git", &st) != 0 || !S_ISDIR(st.st_mode)) {
        fprintf(stderr, "Error: .git directory not found\n");
        return 2;
    }
    mkdir(".git/hooks", 0777);
    FILE *f = fopen(".git/hooks/pre-commit", "w");
    if (!f) {
        fprintf(stderr, "Error: %s\n", strerror(errno));
        return 2;
    }
    fputs("ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n", f);
    fclose(f);
    chmod(".git/hooks/pre-commit", 0744);
    return 0;
}

static void unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fprintf(stderr, "Usage: executable [OPTIONS] [Source files]...\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
}

int main(int argc, char **argv) {
    add_builtin_patterns();
    load_ignore_file();
    bool install = false;
    bool end_opts = false;
    StrList args = {0};
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!end_opts && strcmp(a, "--") == 0) {
            end_opts = true;
        } else if (!end_opts && strcmp(a, "--help") == 0) {
            fputs(help_long, stdout);
            return 0;
        } else if (!end_opts && strcmp(a, "-h") == 0) {
            fputs(help_short, stdout);
            return 0;
        } else if (!end_opts && (strcmp(a, "--version") == 0 || strcmp(a, "-V") == 0)) {
            puts("ripsecrets 0.1.11");
            return 0;
        } else if (!end_opts && strcmp(a, "--only-matching") == 0) {
            only_matching = true;
        } else if (!end_opts && strcmp(a, "--strict-ignore") == 0) {
            strict_ignore = true;
        } else if (!end_opts && strcmp(a, "--install-pre-commit") == 0) {
            install = true;
        } else if (!end_opts && strcmp(a, "--additional-pattern") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied\n\n");
                fprintf(stderr, "For more information, try '--help'.\n");
                return 2;
            }
            add_pattern_ex(argv[++i], true);
        } else if (!end_opts && strncmp(a, "--additional-pattern=", 21) == 0) {
            add_pattern_ex(a + 21, true);
        } else if (!end_opts && a[0] == '-') {
            unexpected(a);
            return 2;
        } else {
            push_str(&args, a);
        }
    }
    if (install) return install_pre_commit();
    if (args.len == 0) {
        scan_path(".", ".", true);
    } else {
        for (size_t i = 0; i < args.len; i++) scan_path(args.items[i], args.items[i], true);
    }
    return found_secret ? 1 : 0;
}
