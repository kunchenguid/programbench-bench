#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <unistd.h>

typedef struct { char *s; size_t n, cap; } Str;
typedef struct { char **v; int n, cap; } Files;
typedef enum { BASIC, CLOZE } CardType;

typedef struct {
  CardType type;
  char *hash, *family, *deck, *path;
  int line_start, line_end;
  char *question, *answer, *text;
  int start, end;
} Card;
typedef struct { Card *v; int n, cap; } Cards;

static void die_oom(void){ fprintf(stderr,"out of memory\n"); exit(1); }
static void *xmalloc(size_t n){ void *p=malloc(n?n:1); if(!p) die_oom(); return p; }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) die_oom(); return p; }
static void str_init(Str *b){ b->s=NULL; b->n=b->cap=0; }
static void str_reserve(Str *b,size_t add){ if(b->n+add+1>b->cap){ size_t c=b->cap?b->cap*2:64; while(c<b->n+add+1)c*=2; b->s=realloc(b->s,c); if(!b->s)die_oom(); b->cap=c; } }
static void str_addn(Str *b,const char *s,size_t n){ str_reserve(b,n); memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void str_add(Str *b,const char *s){ str_addn(b,s,strlen(s)); }
static void str_ch(Str *b,char c){ str_reserve(b,1); b->s[b->n++]=c; b->s[b->n]=0; }
static char *str_take(Str *b){ if(!b->s) return xstrdup(""); char *s=b->s; b->s=NULL; b->n=b->cap=0; return s; }

static char *trim_copy(const char *s){
  while(*s && isspace((unsigned char)*s)) s++;
  size_t n=strlen(s);
  while(n && isspace((unsigned char)s[n-1])) n--;
  char *r=xmalloc(n+1); memcpy(r,s,n); r[n]=0; return r;
}
static int starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }
static int has_suffix(const char *s,const char *suf){ size_t a=strlen(s),b=strlen(suf); return a>=b && strcmp(s+a-b,suf)==0; }

/* public domain style SHA-256 implementation */
typedef struct { uint8_t data[64]; uint32_t datalen; uint64_t bitlen; uint32_t state[8]; } SHA256_CTX;
#define ROTRIGHT(a,b) (((a) >> (b)) | ((a) << (32-(b))))
#define CH(x,y,z) (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x,y,z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x) (ROTRIGHT(x,2) ^ ROTRIGHT(x,13) ^ ROTRIGHT(x,22))
#define EP1(x) (ROTRIGHT(x,6) ^ ROTRIGHT(x,11) ^ ROTRIGHT(x,25))
#define SIG0(x) (ROTRIGHT(x,7) ^ ROTRIGHT(x,18) ^ ((x) >> 3))
#define SIG1(x) (ROTRIGHT(x,17) ^ ROTRIGHT(x,19) ^ ((x) >> 10))
static const uint32_t k256[64]={
  0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
static void sha256_transform(SHA256_CTX *ctx,const uint8_t data[]){
  uint32_t a,b,c,d,e,f,g,h,i,j,t1,t2,m[64];
  for(i=0,j=0;i<16;i++,j+=4)m[i]=(data[j]<<24)|(data[j+1]<<16)|(data[j+2]<<8)|data[j+3];
  for(;i<64;i++)m[i]=SIG1(m[i-2])+m[i-7]+SIG0(m[i-15])+m[i-16];
  a=ctx->state[0];b=ctx->state[1];c=ctx->state[2];d=ctx->state[3];e=ctx->state[4];f=ctx->state[5];g=ctx->state[6];h=ctx->state[7];
  for(i=0;i<64;i++){t1=h+EP1(e)+CH(e,f,g)+k256[i]+m[i];t2=EP0(a)+MAJ(a,b,c);h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;}
  ctx->state[0]+=a;ctx->state[1]+=b;ctx->state[2]+=c;ctx->state[3]+=d;ctx->state[4]+=e;ctx->state[5]+=f;ctx->state[6]+=g;ctx->state[7]+=h;
}
static void sha256_init(SHA256_CTX *ctx){ ctx->datalen=0;ctx->bitlen=0;ctx->state[0]=0x6a09e667;ctx->state[1]=0xbb67ae85;ctx->state[2]=0x3c6ef372;ctx->state[3]=0xa54ff53a;ctx->state[4]=0x510e527f;ctx->state[5]=0x9b05688c;ctx->state[6]=0x1f83d9ab;ctx->state[7]=0x5be0cd19; }
static void sha256_update(SHA256_CTX *ctx,const uint8_t data[],size_t len){ for(size_t i=0;i<len;i++){ctx->data[ctx->datalen++]=data[i]; if(ctx->datalen==64){sha256_transform(ctx,ctx->data);ctx->bitlen+=512;ctx->datalen=0;}}}
static void sha256_final(SHA256_CTX *ctx,uint8_t hash[]){
  uint32_t i=ctx->datalen; ctx->data[i++]=0x80; if(i>56){ while(i<64)ctx->data[i++]=0; sha256_transform(ctx,ctx->data); i=0; } while(i<56)ctx->data[i++]=0;
  ctx->bitlen += ctx->datalen*8; for(int j=7;j>=0;j--) ctx->data[63-j]=(ctx->bitlen>>(j*8))&0xff; sha256_transform(ctx,ctx->data);
  for(i=0;i<4;i++) for(int j=0;j<8;j++) hash[i+4*j]=(ctx->state[j]>>(24-i*8))&0xff;
}
static char *sha_hex(const char *s){ uint8_t h[32]; SHA256_CTX c; sha256_init(&c); sha256_update(&c,(const uint8_t*)s,strlen(s)); sha256_final(&c,h); char *o=xmalloc(65); for(int i=0;i<32;i++) sprintf(o+i*2,"%02x",h[i]); o[64]=0; return o; }

static void files_add(Files *f,char *p){ if(f->n==f->cap){f->cap=f->cap?f->cap*2:16;f->v=realloc(f->v,f->cap*sizeof(char*));if(!f->v)die_oom();} f->v[f->n++]=p; }
static int cmp_strp(const void *a,const void *b){ return strcmp(*(char*const*)a,*(char*const*)b); }
static void collect_files(const char *dir,Files *out){
  DIR *d=opendir(dir); if(!d)return; struct dirent *e;
  while((e=readdir(d))){ if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")||!strcmp(e->d_name,".git"))continue; Str p; str_init(&p); str_add(&p,dir); str_ch(&p,'/'); str_add(&p,e->d_name); char *path=str_take(&p); struct stat st; if(!stat(path,&st)){ if(S_ISDIR(st.st_mode)) collect_files(path,out); else if(S_ISREG(st.st_mode)&&has_suffix(path,".md")) files_add(out,path); else free(path);} else free(path); }
  closedir(d);
}
static int count_tex_files(const char *dir){
  int count=0; DIR *d=opendir(dir); if(!d)return 0; struct dirent *e;
  while((e=readdir(d))){
    if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")||!strcmp(e->d_name,".git"))continue;
    Str p; str_init(&p); str_add(&p,dir); str_ch(&p,'/'); str_add(&p,e->d_name); char *path=str_take(&p);
    struct stat st; if(!stat(path,&st)){ if(S_ISDIR(st.st_mode)) count+=count_tex_files(path); else if(S_ISREG(st.st_mode)&&has_suffix(path,".tex")) count++; }
    free(path);
  }
  closedir(d); return count;
}
static char *read_file(const char *path){
  FILE *fp=fopen(path,"rb"); if(!fp)return NULL; Str b; str_init(&b); char tmp[4096]; size_t n;
  while((n=fread(tmp,1,sizeof tmp,fp))>0) str_addn(&b,tmp,n);
  fclose(fp);
  return str_take(&b);
}
static char *deck_name(const char *path){ const char *s=strrchr(path,'/'); s=s?s+1:path; char *d=xstrdup(s); char *dot=strrchr(d,'.'); if(dot)*dot=0; return d; }

static void cards_add(Cards *cs,Card c){ if(cs->n==cs->cap){cs->cap=cs->cap?cs->cap*2:32;cs->v=realloc(cs->v,cs->cap*sizeof(Card));if(!cs->v)die_oom();} cs->v[cs->n++]=c; }
static char *json_escape(const char *s){
  Str b; str_init(&b); for(;*s;s++){ unsigned char c=*s; if(c=='"')str_add(&b,"\\\""); else if(c=='\\')str_add(&b,"\\\\"); else if(c=='\n')str_add(&b,"\\n"); else if(c=='\r'){} else if(c=='\t')str_add(&b,"\\t"); else if(c<32){ char tmp[8]; sprintf(tmp,"\\u%04x",c); str_add(&b,tmp);} else str_ch(&b,c);} return str_take(&b);
}

static void make_hashes(Card *c){
  Str b; str_init(&b);
  if(c->type==BASIC){ str_add(&b,"basic\n"); str_add(&b,c->question); str_ch(&b,'\n'); str_add(&b,c->answer); c->family=NULL; }
  else { str_add(&b,"cloze-family\n"); str_add(&b,c->text); c->family=sha_hex(b.s?b.s:""); b.n=0; if(b.s)b.s[0]=0; str_add(&b,"cloze\n"); str_add(&b,c->text); char tmp[64]; sprintf(tmp,"\n%d\n%d",c->start,c->end); str_add(&b,tmp); }
  c->hash=sha_hex(b.s?b.s:""); free(b.s);
}

static void parse_error(const char *msg,const char *path,int line){ fprintf(stderr,"hashcards: error: Parse error: %s. Location: %s:%d\n",msg,path,line+1); exit(1); }

static void add_cloze_cards(Cards *cards,const char *path,const char *deck,int start_line,int end_line,const char *raw){
  Str text; str_init(&text); int starts_pos[256], ends_pos[256], n=0;
  for(size_t i=0; raw[i]; i++){
    if(raw[i]=='['){
      const char *close=strchr(raw+i+1,']');
      if(close && n<256){
        int st=(int)text.n; str_addn(&text,raw+i+1,(size_t)(close-(raw+i+1))); int en=(int)text.n-1;
        starts_pos[n]=st; ends_pos[n]=en; n++; i=(size_t)(close-raw);
      } else str_ch(&text,raw[i]);
    } else str_ch(&text,raw[i]);
  }
  char *t=trim_copy(text.s?text.s:""); free(text.s);
  if(n==0){ free(t); parse_error("Cloze card must contain at least one cloze deletion",path,start_line); }
  int trim_left=0; while(raw[trim_left] && isspace((unsigned char)raw[trim_left])) trim_left++;
  for(int i=0;i<n;i++){
    Card c={0}; c.type=CLOZE; c.deck=xstrdup(deck); c.path=xstrdup(path); c.line_start=start_line; c.line_end=end_line; c.text=xstrdup(t);
    c.start=starts_pos[i]-trim_left; c.end=ends_pos[i]-trim_left; if(c.start<0)c.start=0; if(c.end<c.start-1)c.end=c.start-1;
    make_hashes(&c); cards_add(cards,c);
  }
  free(t);
}

static void parse_file(const char *path,Cards *cards){
  char *content=read_file(path); if(!content)return; char *deck=deck_name(path);
  int cap=64,n=0; char **lines=xmalloc(cap*sizeof(char*));
  char *p=content; while(1){
    if(n==cap){cap*=2;lines=realloc(lines,cap*sizeof(char*));if(!lines)die_oom();}
    lines[n++]=p;
    char *nl=strchr(p,'\n');
    if(!nl) break;
    *nl=0; p=nl+1;
    if(!*p) break;
  }
  enum { IDLE, IN_Q, IN_A, IN_C } state=IDLE; Str q,a,c; str_init(&q); str_init(&a); str_init(&c); int start=0, a_line=0;
  for(int i=0;i<n;i++){
    char *line=lines[i]; int tagQ=starts(line,"Q:"), tagA=starts(line,"A:"), tagC=starts(line,"C:");
    if(tagQ || tagC || (tagA && state!=IN_Q)){
      if(state==IN_Q) parse_error("File ended while reading a question without an answer",path,start);
      if(state==IN_A){ Card cd={0}; cd.type=BASIC; cd.deck=xstrdup(deck); cd.path=xstrdup(path); cd.line_start=start; cd.line_end=i; cd.question=trim_copy(q.s?q.s:""); cd.answer=trim_copy(a.s?a.s:""); make_hashes(&cd); cards_add(cards,cd); q.n=a.n=0; if(q.s)q.s[0]=0; if(a.s)a.s[0]=0; state=IDLE; }
      if(state==IN_C){ char *raw=trim_copy(c.s?c.s:""); add_cloze_cards(cards,path,deck,start,i-1,raw); free(raw); c.n=0; if(c.s)c.s[0]=0; state=IDLE; }
    }
    if(tagQ){ state=IN_Q; start=i; str_add(&q,line+2); str_ch(&q,'\n'); }
    else if(tagA){ if(state!=IN_Q) parse_error("Found answer tag without a question",path,i); state=IN_A; a_line=i; (void)a_line; str_add(&a,line+2); str_ch(&a,'\n'); }
    else if(tagC){ state=IN_C; start=i; str_add(&c,line+2); str_ch(&c,'\n'); }
    else { if(state==IN_Q) { str_add(&q,line); str_ch(&q,'\n'); } else if(state==IN_A){ str_add(&a,line); str_ch(&a,'\n'); } else if(state==IN_C){ str_add(&c,line); str_ch(&c,'\n'); } }
  }
  if(state==IN_Q) parse_error("File ended while reading a question without an answer",path,start);
  if(state==IN_A){ Card cd={0}; cd.type=BASIC; cd.deck=xstrdup(deck); cd.path=xstrdup(path); cd.line_start=start; cd.line_end=n?n-1:start; cd.question=trim_copy(q.s?q.s:""); cd.answer=trim_copy(a.s?a.s:""); make_hashes(&cd); cards_add(cards,cd); }
  if(state==IN_C){ char *raw=trim_copy(c.s?c.s:""); add_cloze_cards(cards,path,deck,start,n?n-1:start,raw); free(raw); }
  free(q.s); free(a.s); free(c.s); free(lines); free(deck); free(content);
}

static int cmp_card(const void *A,const void *B){ const Card *a=A,*b=B; return strcmp(a->hash,b->hash); }
static void load_collection(const char *dir,Cards *cards,int *tex_count){
  struct stat st; if(stat(dir,&st)||!S_ISDIR(st.st_mode)){ fprintf(stderr,"hashcards: error: directory does not exist.\n"); exit(1); }
  char root[4096]; const char *base=dir; if(realpath(dir,root)) base=root;
  Files f={0}; collect_files(base,&f); qsort(f.v,f.n,sizeof(char*),cmp_strp);
  *tex_count=count_tex_files(base);
  for(int i=0;i<f.n;i++){ parse_file(f.v[i],cards); free(f.v[i]); }
  free(f.v);
  qsort(cards->v,cards->n,sizeof(Card),cmp_card);
}

static void print_export(Cards *cards,FILE *out){
  fprintf(out,"{\n  \"cards\": [\n");
  for(int i=0;i<cards->n;i++){
    Card *c=&cards->v[i]; char *path=json_escape(c->path),*deck=json_escape(c->deck);
    fprintf(out,"    {\n      \"hash\": \"%s\",\n      \"familyHash\": ",c->hash);
    if(c->family) fprintf(out,"\"%s\"",c->family); else fprintf(out,"null");
    fprintf(out,",\n      \"deckName\": \"%s\",\n      \"location\": {\n        \"filePath\": \"%s\",\n        \"lineStart\": %d,\n        \"lineEnd\": %d\n      },\n      \"content\": {\n",deck,path,c->line_start,c->line_end);
    if(c->type==BASIC){ char *q=json_escape(c->question),*a=json_escape(c->answer); fprintf(out,"        \"basic\": {\n          \"question\": \"%s\",\n          \"answer\": \"%s\"\n        }\n",q,a); free(q); free(a); }
    else { char *t=json_escape(c->text); fprintf(out,"        \"cloze\": {\n          \"text\": \"%s\",\n          \"start\": %d,\n          \"end\": %d\n        }\n",t,c->start,c->end); free(t); }
    fprintf(out,"      },\n      \"performance\": null\n    }%s\n", i==cards->n-1?"":",");
    free(path); free(deck);
  }
  fprintf(out,"  ],\n  \"sessions\": []\n}\n");
}

static void help_root(void){ puts("A plain text-based spaced repetition system.\n\nUsage: executable <COMMAND>\n\nCommands:\n  drill    Drill cards through a web interface\n  check    Check the integrity of a collection\n  stats    Print collection statistics\n  orphans  Commands relating to orphan cards\n  export   Export a collection\n  help     Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"); }
static void help_stats(void){ puts("Print collection statistics\n\nUsage: executable stats [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --format <FORMAT>\n          Which output format to use\n\n          Possible values:\n          - html: HTML output\n          - json: JSON output\n          \n          [default: html]\n\n  -h, --help\n          Print help (see a summary with '-h')"); }
static void help_check(void){ puts("Check the integrity of a collection\n\nUsage: executable check [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help"); }
static void help_export(void){ puts("Export a collection\n\nUsage: executable export [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout\n  -h, --help             Print help"); }
static void help_orphans(void){ puts("Commands relating to orphan cards\n\nUsage: executable orphans <COMMAND>\n\nCommands:\n  list    List the hashes of all orphan cards in the collection\n  delete  Remove all orphan cards from the database\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help"); }
static void help_orphans_list(void){ puts("List the hashes of all orphan cards in the collection\n\nUsage: executable orphans list [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help"); }
static void help_orphans_delete(void){ puts("Remove all orphan cards from the database\n\nUsage: executable orphans delete [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help"); }
static void help_drill(void){ puts("Drill cards through a web interface\n\nUsage: executable drill [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --card-limit <CARD_LIMIT>\n          Maximum number of cards to drill in a session. By default, all cards due today are drilled\n\n      --new-card-limit <NEW_CARD_LIMIT>\n          Maximum number of new cards to drill in a session\n\n      --host <HOST>\n          The host address to bind to. Default is 127.0.0.1\n          \n          [default: 127.0.0.1]\n\n      --port <PORT>\n          The port to use for the web server. Default is 8000\n          \n          [default: 8000]\n\n      --from-deck <FROM_DECK>\n          Only drill cards from this deck\n\n      --open-browser <OPEN_BROWSER>\n          Whether to open the browser automatically. Default is true\n          \n          [possible values: true, false]\n\n      --answer-controls <ANSWER_CONTROLS>\n          Which answer controls to show:\n\n          Possible values:\n          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)\n          - binary: Show only two rating buttons (Forgot/Good)\n          \n          [default: full]\n\n      --bury-siblings <BURY_SIBLINGS>\n          Whether or not to bury siblings. Default is true\n          \n          [possible values: true, false]\n\n  -h, --help\n          Print help (see a summary with '-h')"); }

static const char *dir_arg(int argc,char **argv,int start){ const char *dir="."; for(int i=start;i<argc;i++) if(argv[i][0]!='-') dir=argv[i]; else if(i+1<argc && (!strcmp(argv[i],"--format")||!strcmp(argv[i],"--output")||!strcmp(argv[i],"--port")||!strcmp(argv[i],"--host")||!strcmp(argv[i],"--card-limit")||!strcmp(argv[i],"--new-card-limit")||!strcmp(argv[i],"--from-deck")||!strcmp(argv[i],"--open-browser")||!strcmp(argv[i],"--answer-controls")||!strcmp(argv[i],"--bury-siblings"))) i++; return dir; }

int main(int argc,char **argv){
  if(argc<2){ help_root(); return 2; }
  if(!strcmp(argv[1],"-h")||!strcmp(argv[1],"--help")||!strcmp(argv[1],"help")){ if(argc>=3){ if(!strcmp(argv[2],"stats"))help_stats(); else if(!strcmp(argv[2],"check"))help_check(); else if(!strcmp(argv[2],"export"))help_export(); else if(!strcmp(argv[2],"orphans") && argc>=4 && !strcmp(argv[3],"list"))help_orphans_list(); else if(!strcmp(argv[2],"orphans") && argc>=4 && !strcmp(argv[3],"delete"))help_orphans_delete(); else if(!strcmp(argv[2],"orphans"))help_orphans(); else if(!strcmp(argv[2],"drill"))help_drill(); else help_root(); } else help_root(); return 0; }
  if(!strcmp(argv[1],"-V")||!strcmp(argv[1],"--version")){ puts("hashcards 0.3.0"); return 0; }
  if(!strcmp(argv[1],"check")){ if(argc>2 && (!strcmp(argv[2],"-h")||!strcmp(argv[2],"--help"))){help_check();return 0;} Cards c={0}; int tex=0; load_collection(dir_arg(argc,argv,2),&c,&tex); puts("ok"); return 0; }
  if(!strcmp(argv[1],"stats")){
    const char *fmt="html"; for(int i=2;i<argc;i++) if(!strcmp(argv[i],"--format")&&i+1<argc) fmt=argv[++i]; else if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){help_stats();return 0;}
    if(strcmp(fmt,"json") && strcmp(fmt,"html")) { fprintf(stderr,"error: invalid value '%s' for '--format <FORMAT>'\n  [possible values: html, json]\n\nFor more information, try '--help'.\n",fmt); return 2; }
    Cards c={0}; int tex=0; load_collection(dir_arg(argc,argv,2),&c,&tex);
    if(!strcmp(fmt,"json")) printf("{\n  \"cardsInDeckCount\": %d,\n  \"cardsInDbCount\": 0,\n  \"texMacroCount\": %d,\n  \"cardsReviewedTodayCount\": 0\n}\n",c.n,tex);
    else puts("HTML output is not implemented yet.");
    return 0;
  }
  if(!strcmp(argv[1],"export")){
    const char *outpath=NULL; for(int i=2;i<argc;i++) if(!strcmp(argv[i],"--output")&&i+1<argc) outpath=argv[++i]; else if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){help_export();return 0;}
    Cards c={0}; int tex=0; load_collection(dir_arg(argc,argv,2),&c,&tex); FILE *out=stdout; if(outpath){ out=fopen(outpath,"w"); if(!out){perror(outpath); return 1;} } print_export(&c,out); if(outpath) fclose(out); return 0;
  }
  if(!strcmp(argv[1],"orphans")){
    if(argc<3 || !strcmp(argv[2],"help") || !strcmp(argv[2],"-h") || !strcmp(argv[2],"--help")){ help_orphans(); return argc<3?2:0; }
    if((!strcmp(argv[2],"list")||!strcmp(argv[2],"delete")) && argc>3 && (!strcmp(argv[3],"-h")||!strcmp(argv[3],"--help"))){ if(!strcmp(argv[2],"list")) help_orphans_list(); else help_orphans_delete(); return 0; }
    if(!strcmp(argv[2],"list")||!strcmp(argv[2],"delete")){ Cards c={0}; int tex=0; load_collection(dir_arg(argc,argv,3),&c,&tex); if(!strcmp(argv[2],"delete")) puts("Deleted 0 orphan cards."); return 0; }
  }
  if(!strcmp(argv[1],"drill")){
    for(int i=2;i<argc;i++) if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){help_drill();return 0;}
    Cards c={0}; int tex=0; load_collection(dir_arg(argc,argv,2),&c,&tex);
    puts("Starting server at http://127.0.0.1:8000"); fflush(stdout);
    while(1) sleep(3600);
  }
  fprintf(stderr,"error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n",argv[1]); return 2;
}
