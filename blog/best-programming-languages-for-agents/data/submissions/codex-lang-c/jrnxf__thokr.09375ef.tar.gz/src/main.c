#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#define VERSION "thokr 0.4.1"
#define ABOUT "sleek typing tui with visualized results and historical logging"

typedef struct {
    unsigned words;
    unsigned secs;
    unsigned full_sentences;
    char *prompt;
    const char *language;
    bool has_secs;
    bool has_full;
} Options;

typedef struct {
    char *text;
    size_t len;
    size_t pos;
    size_t errors;
    size_t typed;
    double start_time;
    double end_time;
    bool started;
    bool done;
    bool timed_out;
} TestState;

static struct termios old_term;
static bool raw_enabled = false;
static bool alt_enabled = false;
static volatile sig_atomic_t got_signal = 0;

static const char *english_words[] = {
    "the","be","to","of","and","a","in","that","have","i","it","for","not","on","with",
    "he","as","you","do","at","this","but","his","by","from","they","we","say","her","she",
    "or","an","will","my","one","all","would","there","their","what","so","up","out","if",
    "about","who","get","which","go","me","when","make","can","like","time","no","just",
    "him","know","take","people","into","year","your","good","some","could","them","see",
    "other","than","then","now","look","only","come","its","over","think","also","back",
    "after","use","two","how","our","work","first","well","way","even","new","want",
    "because","any","these","give","day","most","us","is","are","was","were","had","been",
    "has","more","very","where","much","too","may","down","should","long","each","state",
    "world","school","still","try","last","ask","need","feel","three","life","never","place",
    "while","small","found","those","right","great","same","another","left","number","part",
    "again","against","house","point","home","course","water","room","mother","area","money",
    "story","young","fact","month","different","lot","study","book","eye","job","word",
    "though","business","issue","side","kind","head","far","black","hand","high","government",
    "night","service","game","line","end","member","law","car","city","community","name",
    "president","team","minute","idea","kid","body","information","nothing","ago","lead",
    "social","understand","whether","watch","together","follow","around","parent","face",
    "anything","create","public","already","speak","others","read","level","allow","add"
};

static const char *sentences[] = {
    "The quick brown fox jumps over the lazy dog.",
    "Typing smooth words can make a quiet terminal feel alive.",
    "Practice turns careful movement into steady rhythm.",
    "Small mistakes are easy to see when the prompt is clear.",
    "Every sentence ends with a full stop.",
    "A simple test is often enough to measure progress.",
    "The cursor waits while the clock keeps counting.",
    "Clean output matters when people use tools every day."
};

static double now_secs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
}

static void cleanup_terminal(void) {
    if (alt_enabled) {
        printf("\033[?1049l\033[?25h");
        fflush(stdout);
        alt_enabled = false;
    }
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &old_term);
        raw_enabled = false;
    }
}

static void on_signal(int sig) {
    (void)sig;
    got_signal = 1;
}

static void die_nomem(void) {
    fprintf(stderr, "error: out of memory\n");
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) die_nomem();
    return r;
}

static void usage(FILE *f, const char *prog) {
    fprintf(f, "%s\n%s\n\n", VERSION, ABOUT);
    fprintf(f, "USAGE:\n    %s [OPTIONS]\n\n", prog);
    fprintf(f, "OPTIONS:\n");
    fprintf(f, "    -f, --full-sentences <NUMBER_OF_SENTENCES>\n            number of sentences to use in test\n\n");
    fprintf(f, "    -h, --help\n            Print help information\n\n");
    fprintf(f, "    -l, --supported-language <SUPPORTED_LANGUAGE>\n            language to pull words from [default: english] [possible values: english, english1k,\n            english10k]\n\n");
    fprintf(f, "    -p, --prompt <PROMPT>\n            custom prompt to use\n\n");
    fprintf(f, "    -s, --number-of-secs <NUMBER_OF_SECS>\n            number of seconds to run test\n\n");
    fprintf(f, "    -V, --version\n            Print version information\n\n");
    fprintf(f, "    -w, --number-of-words <NUMBER_OF_WORDS>\n            number of words to use in test [default: 15]\n");
}

static void print_try_help(void) {
    fprintf(stderr, "\nFor more information try --help\n");
}

static void cli_error(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    print_try_help();
    exit(2);
}

static bool parse_uint_value(const char *s, unsigned *out, const char *flag, const char *meta) {
    if (!s || !*s) {
        cli_error("Invalid value \"\" for '%s <%s>': invalid digit found in string\n", flag, meta);
    }
    for (const char *p = s; *p; p++) {
        if (!isdigit((unsigned char)*p)) {
            cli_error("Invalid value \"%s\" for '%s <%s>': invalid digit found in string\n", s, flag, meta);
        }
    }
    errno = 0;
    unsigned long v = strtoul(s, NULL, 10);
    if (errno || v > 4294967295UL) {
        cli_error("Invalid value \"%s\" for '%s <%s>': number too large to fit in target type\n", s, flag, meta);
    }
    *out = (unsigned)v;
    return true;
}

static const char *need_value(int *i, int argc, char **argv, const char *longflag, const char *meta) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "error: The argument '%s <%s>' requires a value but none was supplied\n\n", longflag, meta);
        fprintf(stderr, "USAGE:\n    executable [OPTIONS]\n");
        print_try_help();
        exit(2);
    }
    if (argv[*i + 1][0] == '-' && argv[*i + 1][1] != '\0') {
        fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n", argv[*i + 1]);
        fprintf(stderr, "\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\n", argv[*i + 1], argv[*i + 1]);
        fprintf(stderr, "USAGE:\n    executable [OPTIONS]\n");
        print_try_help();
        exit(2);
    }
    (*i)++;
    return argv[*i];
}

static void parse_args(int argc, char **argv, Options *opt) {
    opt->words = 15;
    opt->secs = 0;
    opt->full_sentences = 0;
    opt->prompt = NULL;
    opt->language = "english";
    opt->has_secs = false;
    opt->has_full = false;

    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            usage(stdout, "executable");
            exit(0);
        } else if (!strcmp(a, "-V") || !strcmp(a, "--version")) {
            puts(VERSION);
            exit(0);
        } else if (!strcmp(a, "-w") || !strcmp(a, "--number-of-words")) {
            const char *v = need_value(&i, argc, argv, "--number-of-words", "NUMBER_OF_WORDS");
            parse_uint_value(v, &opt->words, "--number-of-words", "NUMBER_OF_WORDS");
        } else if (!strncmp(a, "--number-of-words=", 18)) {
            parse_uint_value(a + 18, &opt->words, "--number-of-words", "NUMBER_OF_WORDS");
        } else if (!strcmp(a, "-s") || !strcmp(a, "--number-of-secs")) {
            const char *v = need_value(&i, argc, argv, "--number-of-secs", "NUMBER_OF_SECS");
            parse_uint_value(v, &opt->secs, "--number-of-secs", "NUMBER_OF_SECS");
            opt->has_secs = true;
        } else if (!strncmp(a, "--number-of-secs=", 17)) {
            parse_uint_value(a + 17, &opt->secs, "--number-of-secs", "NUMBER_OF_SECS");
            opt->has_secs = true;
        } else if (!strcmp(a, "-f") || !strcmp(a, "--full-sentences")) {
            const char *v = need_value(&i, argc, argv, "--full-sentences", "NUMBER_OF_SENTENCES");
            parse_uint_value(v, &opt->full_sentences, "--full-sentences", "NUMBER_OF_SENTENCES");
            opt->has_full = true;
        } else if (!strncmp(a, "--full-sentences=", 17)) {
            parse_uint_value(a + 17, &opt->full_sentences, "--full-sentences", "NUMBER_OF_SENTENCES");
            opt->has_full = true;
        } else if (!strcmp(a, "-p") || !strcmp(a, "--prompt")) {
            const char *v = need_value(&i, argc, argv, "--prompt", "PROMPT");
            free(opt->prompt);
            opt->prompt = xstrdup(v);
        } else if (!strncmp(a, "--prompt=", 9)) {
            free(opt->prompt);
            opt->prompt = xstrdup(a + 9);
        } else if (!strcmp(a, "-l") || !strcmp(a, "--supported-language")) {
            const char *v = need_value(&i, argc, argv, "--supported-language", "SUPPORTED_LANGUAGE");
            if (strcmp(v, "english") && strcmp(v, "english1k") && strcmp(v, "english10k")) {
                fprintf(stderr, "error: \"%s\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]\n\n", v);
                fprintf(stderr, "USAGE:\n    executable --supported-language <SUPPORTED_LANGUAGE>\n");
                print_try_help();
                exit(2);
            }
            opt->language = v;
        } else if (!strncmp(a, "--supported-language=", 21)) {
            const char *v = a + 21;
            if (strcmp(v, "english") && strcmp(v, "english1k") && strcmp(v, "english10k")) {
                fprintf(stderr, "error: \"%s\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]\n\n", v);
                fprintf(stderr, "USAGE:\n    executable --supported-language <SUPPORTED_LANGUAGE>\n");
                print_try_help();
                exit(2);
            }
            opt->language = v;
        } else {
            fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n", a);
            fprintf(stderr, "\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\n", a, a);
            fprintf(stderr, "USAGE:\n    executable [OPTIONS]\n");
            print_try_help();
            exit(2);
        }
    }
}

static void append_str(char **buf, size_t *len, size_t *cap, const char *s) {
    size_t n = strlen(s);
    if (*len + n + 1 > *cap) {
        while (*len + n + 1 > *cap) *cap *= 2;
        char *nb = realloc(*buf, *cap);
        if (!nb) die_nomem();
        *buf = nb;
    }
    memcpy(*buf + *len, s, n);
    *len += n;
    (*buf)[*len] = '\0';
}

static char *make_prompt(const Options *opt) {
    if (opt->prompt) return xstrdup(opt->prompt);
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) die_nomem();
    buf[0] = '\0';

    if (opt->has_full) {
        for (unsigned i = 0; i < opt->full_sentences; i++) {
            if (i) append_str(&buf, &len, &cap, " ");
            append_str(&buf, &len, &cap, sentences[i % (sizeof(sentences) / sizeof(sentences[0]))]);
        }
        return buf;
    }

    unsigned count = opt->words;
    unsigned offset = (unsigned)(time(NULL) % (sizeof(english_words) / sizeof(english_words[0])));
    if (!strcmp(opt->language, "english1k")) offset = (offset * 7 + 3) % (sizeof(english_words) / sizeof(english_words[0]));
    if (!strcmp(opt->language, "english10k")) offset = (offset * 11 + 5) % (sizeof(english_words) / sizeof(english_words[0]));
    for (unsigned i = 0; i < count; i++) {
        if (i) append_str(&buf, &len, &cap, " ");
        append_str(&buf, &len, &cap, english_words[(offset + i) % (sizeof(english_words) / sizeof(english_words[0]))]);
    }
    return buf;
}

static void tty_size(int *rows, int *cols) {
    struct winsize ws;
    *rows = 24;
    *cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row && ws.ws_col) {
        *rows = ws.ws_row;
        *cols = ws.ws_col;
    }
}

static void move_to(int r, int c) {
    printf("\033[%d;%dH", r, c);
}

static unsigned count_words(const char *s) {
    unsigned n = 0;
    bool in = false;
    for (; *s; s++) {
        if (isspace((unsigned char)*s)) in = false;
        else if (!in) { n++; in = true; }
    }
    return n;
}

static double elapsed_for(const TestState *st) {
    if (!st->started) return 0.0;
    double end = st->done ? st->end_time : now_secs();
    double e = end - st->start_time;
    return e < 0 ? 0 : e;
}

static double calc_wpm(const TestState *st) {
    double elapsed = elapsed_for(st);
    if (elapsed < 0.005) return INFINITY;
    return ((double)st->typed / 5.0) / (elapsed / 60.0);
}

static double calc_acc(const TestState *st) {
    if (st->typed == 0) return 100.0;
    if (st->errors >= st->typed) return 0.0;
    return 100.0 * (double)(st->typed - st->errors) / (double)st->typed;
}

static void draw_wrapped_prompt(const TestState *st, int rows, int cols) {
    int width = cols - 12;
    if (width < 20) width = cols > 4 ? cols - 2 : cols;
    int start_row = rows / 2;
    int start_col = (cols - width) / 2 + 1;
    if (start_col < 1) start_col = 1;
    move_to(start_row, start_col);
    for (size_t i = 0; i < st->len; i++) {
        if (i && (int)(i % (size_t)width) == 0) {
            move_to(start_row + (int)(i / (size_t)width), start_col);
        }
        if (i < st->pos) {
            printf("\033[1m\033[38;5;2m%c\033[39m\033[22m", st->text[i]);
        } else if (i == st->pos && !st->done) {
            printf("\033[1m\033[4m\033[2m%c\033[24m\033[22m", st->text[i]);
        } else {
            printf("\033[2m%c\033[22m", st->text[i]);
        }
    }
}

static void draw_box_line(int r, int c, int width, char left, char mid, char right) {
    move_to(r, c);
    putchar(left);
    for (int i = 0; i < width - 2; i++) putchar(mid);
    putchar(right);
}

static void render(const TestState *st, const Options *opt) {
    int rows, cols;
    tty_size(&rows, &cols);
    printf("\033[2J");
    double elapsed = elapsed_for(st);
    double remaining = opt->has_secs ? (double)opt->secs - elapsed : INFINITY;
    if (remaining < 0) remaining = 0;

    if (!st->done) {
        if (opt->has_secs) {
            move_to(2, 4);
            printf("\033[1m%.0f\033[22m seconds", remaining);
        }
        draw_wrapped_prompt(st, rows, cols);
    } else {
        int boxw = cols - 18;
        if (boxw < 42) boxw = cols - 2;
        if (boxw > 78) boxw = 78;
        int left = (cols - boxw) / 2 + 1;
        if (left < 1) left = 1;
        int top = rows / 2 - 8;
        if (top < 2) top = 2;
        draw_box_line(top, left, boxw, '+', '-', '+');
        for (int r = top + 1; r < top + 12; r++) {
            move_to(r, left); putchar('|');
            move_to(r, left + boxw - 1); putchar('|');
        }
        draw_box_line(top + 12, left, boxw, '+', '-', '+');
        move_to(top + 1, left + 3);
        printf("\033[1m");
        if (isinf(calc_wpm(st))) printf("inf");
        else printf("%.0f", calc_wpm(st));
        printf("\033[22m|wpm");
        move_to(top + 4, left + 3);
        printf("\033[1m%.0f%%\033[22m|acc", calc_acc(st));
        move_to(top + 7, left + 3);
        printf("\033[1m%.2f\033[22m|seconds", elapsed);
        move_to(top + 10, left + 3);
        printf("\033[1m%.2f\033[22m|std dev", 0.0);
        move_to(top + 14, left);
        printf("\033[3m(r)etry / (n)ew / (esc)ape\033[23m");
    }
    printf("\033[?25l");
    fflush(stdout);
}

static void enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &old_term) != 0) {
        fprintf(stderr, "error: stdin must be a tty\n\nUSAGE:\n    thokr [OPTIONS]\n");
        print_try_help();
        exit(2);
    }
    struct termios raw = old_term;
    raw.c_lflag &= (tcflag_t)~(ECHO | ICANON | IEXTEN | ISIG);
    raw.c_iflag &= (tcflag_t)~(IXON | ICRNL | BRKINT | INPCK | ISTRIP);
    raw.c_oflag &= (tcflag_t)~(OPOST);
    raw.c_cflag |= CS8;
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 0;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) != 0) {
        fprintf(stderr, "error: stdin must be a tty\n\nUSAGE:\n    thokr [OPTIONS]\n");
        print_try_help();
        exit(2);
    }
    raw_enabled = true;
}

static int read_key(int timeout_ms) {
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(STDIN_FILENO, &rfds);
    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
    int r = select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv);
    if (r <= 0) return -1;
    unsigned char c;
    if (read(STDIN_FILENO, &c, 1) != 1) return -1;
    if (c == 27) {
        unsigned char seq[2];
        if (read(STDIN_FILENO, &seq[0], 1) == 1 && read(STDIN_FILENO, &seq[1], 1) == 1) {
            if (seq[0] == '[' && seq[1] == 'D') return 1000; /* left */
            if (seq[0] == '[' && seq[1] == 'C') return 1001; /* right */
        }
        return 27;
    }
    return c;
}

static void ensure_dir(const char *path) {
    char tmp[1024];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    mkdir(tmp, 0777);
}

static void write_log(const Options *opt, const TestState *st) {
    const char *home = getenv("HOME");
    if (!home || !*home) return;
    char dir[1024], file[1200];
    snprintf(dir, sizeof(dir), "%s/.config/thokr", home);
    ensure_dir(dir);
    snprintf(file, sizeof(file), "%s/log.csv", dir);
    bool exists = access(file, F_OK) == 0;
    FILE *f = fopen(file, "a");
    if (!f) return;
    if (!exists) fprintf(f, "date,num_words,num_secs,elapsed_secs,wpm,accuracy,std_dev\n");
    time_t t = time(NULL);
    char date[128];
    struct tm tmv;
    localtime_r(&t, &tmv);
    strftime(date, sizeof(date), "%a %b %d %H:%M:%S %Y", &tmv);
    fprintf(f, "%s,%u,", date, opt->prompt ? 15u : count_words(st->text));
    if (opt->has_secs) fprintf(f, "%u", opt->secs);
    fprintf(f, ",%.2f,", elapsed_for(st));
    if (isinf(calc_wpm(st))) fprintf(f, "inf");
    else fprintf(f, "%.0f", calc_wpm(st));
    fprintf(f, ",%.0f,%.2f\n", calc_acc(st), 0.0);
    fclose(f);
}

static void reset_state(TestState *st, char *prompt) {
    free(st->text);
    memset(st, 0, sizeof(*st));
    st->text = prompt;
    st->len = strlen(prompt);
}

static int run_app(const Options *opt) {
    if (!isatty(STDIN_FILENO)) {
        fprintf(stderr, "error: stdin must be a tty\n\nUSAGE:\n    thokr [OPTIONS]\n");
        print_try_help();
        return 2;
    }
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    atexit(cleanup_terminal);
    enable_raw();
    printf("\033[?1049h");
    alt_enabled = true;

    TestState st = {0};
    reset_state(&st, make_prompt(opt));
    render(&st, opt);
    bool logged = false;
    for (;;) {
        if (got_signal) break;
        if (st.started && !st.done && opt->has_secs && elapsed_for(&st) >= (double)opt->secs) {
            st.done = true;
            st.timed_out = true;
            st.end_time = now_secs();
            if (!logged) {
                write_log(opt, &st);
                logged = true;
            }
            render(&st, opt);
        }
        int k = read_key(50);
        if (k < 0) continue;
        if (k == 27 || k == 3) break;
        if (st.done) {
            if (k == 'r' || k == 'R') {
                char *same = xstrdup(st.text);
                reset_state(&st, same);
                logged = false;
                render(&st, opt);
            } else if ((k == 'n' || k == 'N') && !opt->prompt) {
                reset_state(&st, make_prompt(opt));
                logged = false;
                render(&st, opt);
            }
            continue;
        }
        if (k == 1000) {
            reset_state(&st, xstrdup(st.text));
            render(&st, opt);
            continue;
        }
        if (k == 1001 && !opt->prompt) {
            reset_state(&st, make_prompt(opt));
            render(&st, opt);
            continue;
        }
        if (k == 127 || k == 8) {
            if (st.pos > 0) st.pos--;
            render(&st, opt);
            continue;
        }
        if (k < 32 || k > 126) continue;
        if (!st.started) {
            st.started = true;
            st.start_time = now_secs();
        }
        if (st.pos < st.len) {
            if ((char)k != st.text[st.pos]) st.errors++;
            st.pos++;
            st.typed++;
        }
        if (st.pos >= st.len) {
            st.done = true;
            st.end_time = now_secs();
            if (!logged) {
                write_log(opt, &st);
                logged = true;
            }
        }
        render(&st, opt);
    }
    free(st.text);
    return 0;
}

int main(int argc, char **argv) {
    Options opt;
    parse_args(argc, argv, &opt);
    int rc = run_app(&opt);
    free(opt.prompt);
    return rc;
}
