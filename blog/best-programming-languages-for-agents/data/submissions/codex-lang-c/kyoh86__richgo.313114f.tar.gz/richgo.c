#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static void print_go_panic(int test_mode) {
    if (test_mode) {
        fputc('\n', stdout);
        fflush(stdout);
        fputc('\n', stderr);
    }
    fputs("panic: exec: \"go\": executable file not found in $PATH\n\n"
          "goroutine 1 [running]:\n"
          "main.main()\n"
          "\t/workspace/main.go:74 +0x465\n",
          stderr);
}

static int is_executable_file(const char *path) {
    return access(path, X_OK) == 0;
}

static int command_exists(const char *name) {
    const char *path = getenv("PATH");
    if (!path || !*path) {
        return 0;
    }

    const char *start = path;
    while (1) {
        const char *end = strchr(start, ':');
        size_t dir_len = end ? (size_t)(end - start) : strlen(start);
        const char *dir = dir_len ? start : ".";
        size_t actual_dir_len = dir_len ? dir_len : 1;
        size_t total = actual_dir_len + 1 + strlen(name) + 1;
        char *candidate = malloc(total);
        if (!candidate) {
            return 0;
        }
        memcpy(candidate, dir, actual_dir_len);
        candidate[actual_dir_len] = '/';
        strcpy(candidate + actual_dir_len + 1, name);
        int ok = is_executable_file(candidate);
        free(candidate);
        if (ok) {
            return 1;
        }
        if (!end) {
            break;
        }
        start = end + 1;
    }
    return 0;
}

static int run_testfilter(void) {
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), stdin)) > 0) {
        if (fwrite(buf, 1, n, stdout) != n) {
            return 1;
        }
    }
    fputc('\n', stdout);
    fflush(stdout);
    fputc('\n', stderr);
    fflush(stderr);
    return ferror(stdin) ? 1 : 0;
}

static int run_go(int argc, char **argv) {
    int test_mode = argc > 1 && strcmp(argv[1], "test") == 0;
    if (!command_exists("go")) {
        print_go_panic(test_mode);
        return 2;
    }

    char **go_argv = calloc((size_t)argc + 1, sizeof(char *));
    if (!go_argv) {
        perror("calloc");
        return 2;
    }
    go_argv[0] = "go";
    for (int i = 1; i < argc; i++) {
        go_argv[i] = argv[i];
    }
    go_argv[argc] = NULL;

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        free(go_argv);
        return 2;
    }
    if (pid == 0) {
        execvp("go", go_argv);
        print_go_panic(test_mode);
        _exit(2);
    }

    int status = 0;
    while (waitpid(pid, &status, 0) < 0) {
        if (errno != EINTR) {
            perror("waitpid");
            free(go_argv);
            return 2;
        }
    }
    free(go_argv);

    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return 2;
}

int main(int argc, char **argv) {
    if (argc > 1 && strcmp(argv[1], "testfilter") == 0) {
        return run_testfilter();
    }
    return run_go(argc, argv);
}
