#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <regex.h>
#include <sqlite3.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define VERSION "lnav 0.14.0-07efb63"

typedef struct {
    char **items;
    size_t len;
    size_t cap;
} StrList;

typedef struct {
    char *text;
    char *body;
    time_t ts;
    int has_ts;
    int visible;
} Line;

typedef struct {
    Line *items;
    size_t len;
    size_t cap;
} LineList;

typedef struct {
    int headless, no_default, quiet, recursive, rotated, stdin_log;
    int had_command, command_error;
    char *since_arg, *until_arg, *debug_file;
    time_t since_ts, until_ts;
    int has_since, has_until;
    StrList paths;
    StrList commands;
    LineList exec_lines;
} Options;

static void strlist_push(StrList *sl, const char *s) {
    if (sl->len == sl->cap) {
        sl->cap = sl->cap ? sl->cap * 2 : 8;
        sl->items = realloc(sl->items, sl->cap * sizeof(char *));
        if (!sl->items) exit(2);
    }
    sl->items[sl->len++] = strdup(s ? s : "");
}

static void linelist_push(LineList *ll, char *s) {
    if (ll->len == ll->cap) {
        ll->cap = ll->cap ? ll->cap * 2 : 64;
        ll->items = realloc(ll->items, ll->cap * sizeof(Line));
        if (!ll->items) exit(2);
    }
    Line *ln = &ll->items[ll->len++];
    ln->text = s;
    ln->body = NULL;
    ln->ts = 0;
    ln->has_ts = 0;
    ln->visible = 1;
}

static int ends_with(const char *s, const char *suffix) {
    size_t a = strlen(s), b = strlen(suffix);
    return a >= b && strcmp(s + a - b, suffix) == 0;
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static int parse_time_value(const char *s, time_t *out) {
    struct tm tm;
    char *end;
    const char *formats[] = {
        "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y-%m-%d", NULL
    };
    for (int i = 0; formats[i]; i++) {
        memset(&tm, 0, sizeof(tm));
        tm.tm_isdst = -1;
        end = strptime(s, formats[i], &tm);
        if (end && (*end == 0 || isspace((unsigned char)*end))) {
            *out = mktime(&tm);
            return 1;
        }
    }
    return 0;
}

static void parse_line(Line *ln) {
    time_t t;
    ln->body = ln->text;
    if (strlen(ln->text) >= 19) {
        char save = ln->text[19];
        ln->text[19] = 0;
        if (parse_time_value(ln->text, &t)) {
            ln->has_ts = 1;
            ln->ts = t;
            ln->body = ln->text + 19;
            while (*ln->body && isspace((unsigned char)*ln->body)) ln->body++;
            char *p = ln->body;
            while (*p && !isspace((unsigned char)*p)) p++;
            while (*p && isspace((unsigned char)*p)) p++;
            if (*p) ln->body = p;
        }
        ln->text[19] = save;
    }
}

static void apply_time_filters(Options *o, LineList *ll) {
    for (size_t i = 0; i < ll->len; i++) {
        Line *ln = &ll->items[i];
        parse_line(ln);
        if (ln->has_ts) {
            if (o->has_since && ln->ts < o->since_ts) ln->visible = 0;
            if (o->has_until && ln->ts > o->until_ts) ln->visible = 0;
        }
    }
}

static void usage(const char *argv0) {
    printf("usage: %s [options] [logfile1 logfile2 ...]\n\n", argv0);
    printf("A log file viewer for the terminal that indexes log messages to\n");
    printf("make it easier to navigate through files quickly.\n\n");
    printf("Key Bindings\n");
    printf("  ?    View/leave the online help text.\n");
    printf("  q    Quit the program.\n\n");
    printf("Options\n");
    printf("  -h         Print this message, then exit.\n");
    printf("  -H         Display the internal help text.\n\n");
    printf("  -I dir     An additional configuration directory.\n");
    printf("  -W         Print warnings related to lnav's configuration.\n");
    printf("  -u         Update formats installed from git repositories.\n");
    printf("  -d file    Write debug messages to the given file.\n");
    printf("  -V         Print version information.\n\n");
    printf("  -S,--since Only index log content since this time.\n");
    printf("  -U,--until Only index log content until this time.\n");
    printf("  -r         Recursively load files from the given directory hierarchies.\n");
    printf("  -R         Load older rotated log files as well.\n");
    printf("  -c cmd     Execute a command after the files have been loaded.\n");
    printf("  -f file    Execute the commands in the given file.\n");
    printf("  -e cmd     Execute a shell command-line.\n");
    printf("  -t         Treat data piped into standard in as a log file.\n");
    printf("  -n         Run without the curses UI. (headless mode)\n");
    printf("  -N         Do not open the default syslog file if no files are given.\n");
    printf("  -q         Do not print informational messages.\n\n");
    printf("Optional arguments\n");
    printf("  logfileN   The log files, directories, or remote paths to view.\n");
    printf("             If a directory is given, all of the files in the\n");
    printf("             directory will be loaded.\n\n");
    printf("Management-Mode Options\n");
    printf("  -i         Install the given format files and exit.  Pass 'extra'\n");
    printf("             to install the default set of third-party formats.\n");
    printf("  -m         Switch to the management command-line mode.  This mode\n");
    printf("             is used to work with lnav's configuration.\n\n");
    printf("Examples\n");
    printf(" • To load and follow the syslog file:\n");
    printf("     $ lnav                                  \n\n");
    printf(" • To load all of the files in /var/log:\n");
    printf("     $ lnav /var/log                         \n\n");
    printf(" • To watch the output of make:\n");
    printf("     $ lnav -e 'make -j4'                    \n\n");
    printf("Paths\n");
    printf(" • This binary:\n");
    printf("    🧭 /workspace/executable\n");
    printf(" • Format files are read from:\n");
    printf("    📂 /etc/lnav\n");
    printf("    📂 /usr/etc/lnav\n");
    printf(" • Configuration, session, and format files are stored in:\n");
    printf("    📂 /home/agent/.lnav\n\n");
    printf(" • Local copies of remote files, files extracted from\n");
    printf("   archives, execution output, and so on are stored in:\n");
    printf("    📂 /tmp/lnav-user-1000-work\n\n");
    printf("Documentation: https://docs.lnav.org\n");
    printf("Contact\n");
    printf("  💬 https://github.com/tstack/lnav/discussions\n");
    printf("  📫 lnav@googlegroups.com\n");
    printf("Version: %s\n", VERSION);
}

static void tty_error(void) {
    fprintf(stderr, "  error: unable to display interactive text UI\n");
    fprintf(stderr, " reason: stdout is not a TTY\n");
    fprintf(stderr, " = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n");
}

static int read_stream(FILE *fp, LineList *ll) {
    char *line = NULL;
    size_t n = 0;
    ssize_t r;
    while ((r = getline(&line, &n, fp)) >= 0) {
        while (r > 0 && (line[r - 1] == '\n' || line[r - 1] == '\r')) line[--r] = 0;
        linelist_push(ll, strdup(line));
    }
    free(line);
    return 0;
}

static int load_file(const char *path, LineList *ll) {
    if (ends_with(path, ".gz")) {
        char *cmd;
        if (asprintf(&cmd, "gzip -cd -- '%s'", path) < 0) exit(2);
        FILE *fp = popen(cmd, "r");
        free(cmd);
        if (!fp) return -1;
        read_stream(fp, ll);
        int rc = pclose(fp);
        return (rc == -1 || !WIFEXITED(rc) || WEXITSTATUS(rc) != 0) ? -1 : 0;
    }
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    read_stream(fp, ll);
    fclose(fp);
    return 0;
}

static int load_path(const char *path, Options *o, LineList *ll) {
    struct stat st;
    if (stat(path, &st) != 0) {
        fprintf(stderr, "  error: unable to open file: %s\n", path);
        fprintf(stderr, " reason: %s\n", strerror(errno));
        return -1;
    }
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) return -1;
        StrList entries = {0};
        struct dirent *de;
        while ((de = readdir(d))) {
            if (de->d_name[0] == '.') continue;
            char *full;
            if (asprintf(&full, "%s/%s", path, de->d_name) < 0) exit(2);
            struct stat est;
            if (stat(full, &est) == 0) {
                if (S_ISREG(est.st_mode) && (ends_with(de->d_name, ".log") || ends_with(de->d_name, ".log.gz"))) {
                    strlist_push(&entries, full);
                } else if (o->recursive && S_ISDIR(est.st_mode)) {
                    load_path(full, o, ll);
                }
            }
            free(full);
        }
        closedir(d);
        for (size_t i = 0; i < entries.len; i++) {
            load_file(entries.items[i], ll);
            free(entries.items[i]);
        }
        free(entries.items);
        return 0;
    }
    if (load_file(path, ll) != 0) {
        fprintf(stderr, "  error: unable to open file: %s\n", path);
        fprintf(stderr, " reason: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

static int sqlite_exec_callback(void *unused, int argc, char **argv, char **cols) {
    (void)unused;
    static int printed_header = 0;
    if (!printed_header) {
        for (int i = 0; i < argc; i++) printf("%-9s ", cols[i]);
        printf("\n");
        printed_header = 1;
    }
    for (int i = 0; i < argc; i++) printf("%9s ", argv[i] ? argv[i] : "");
    printf("\n");
    return 0;
}

static void run_sql(const char *sql_in, LineList *ll) {
    sqlite3 *db = NULL;
    sqlite3_open(":memory:", &db);
    sqlite3_exec(db, "create table all_logs(log_line integer, log_time text, log_body text, log_level text, log_path text);", NULL, NULL, NULL);
    sqlite3_stmt *stmt = NULL;
    sqlite3_prepare_v2(db, "insert into all_logs values(?,?,?,?,?)", -1, &stmt, NULL);
    for (size_t i = 0; i < ll->len; i++) {
        Line *ln = &ll->items[i];
        if (!ln->visible) continue;
        char tsbuf[32] = "";
        if (ln->has_ts) {
            strftime(tsbuf, sizeof(tsbuf), "%Y-%m-%d %H:%M:%S", localtime(&ln->ts));
        }
        const char *level = "";
        if (strstr(ln->text, "ERROR")) level = "error";
        else if (strstr(ln->text, "WARN")) level = "warning";
        else if (strstr(ln->text, "INFO")) level = "info";
        sqlite3_bind_int(stmt, 1, (int)i);
        sqlite3_bind_text(stmt, 2, tsbuf, -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 3, ln->body ? ln->body : ln->text, -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 4, level, -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(stmt, 5, "", -1, SQLITE_TRANSIENT);
        sqlite3_step(stmt);
        sqlite3_reset(stmt);
    }
    sqlite3_finalize(stmt);
    char *sql = strdup(sql_in);
    char *err = NULL;
    sqlite3_exec(db, trim(sql), sqlite_exec_callback, NULL, &err);
    if (err) {
        fprintf(stderr, "  error: %s\n", err);
        sqlite3_free(err);
    }
    free(sql);
    sqlite3_close(db);
}

static void apply_regex_filter(LineList *ll, const char *pat, int keep_matches) {
    regex_t re;
    int ok = regcomp(&re, pat, REG_EXTENDED | REG_NOSUB) == 0;
    for (size_t i = 0; i < ll->len; i++) {
        if (!ll->items[i].visible) continue;
        int m = ok ? (regexec(&re, ll->items[i].text, 0, NULL, 0) == 0) : (strstr(ll->items[i].text, pat) != NULL);
        if (keep_matches ? !m : m) ll->items[i].visible = 0;
    }
    if (ok) regfree(&re);
}

static void print_visible(LineList *ll) {
    for (size_t i = 0; i < ll->len; i++) {
        if (ll->items[i].visible) printf("%s\n", ll->items[i].text);
    }
}

static void execute_command(const char *cmd0, LineList *ll, int *printed) {
    char *copy = strdup(cmd0);
    char *cmd = trim(copy);
    if (*cmd == ':') {
        cmd++;
        if (strncmp(cmd, "echo", 4) == 0 && (cmd[4] == 0 || isspace((unsigned char)cmd[4]))) {
            char *msg = trim(cmd + 4);
            printf("%s\n", msg);
            *printed = 1;
        } else if (strncmp(cmd, "filter-in", 9) == 0) {
            apply_regex_filter(ll, trim(cmd + 9), 1);
        } else if (strncmp(cmd, "filter-out", 10) == 0) {
            apply_regex_filter(ll, trim(cmd + 10), 0);
        } else if (strncmp(cmd, "write-", 6) == 0 || strncmp(cmd, "write_", 6) == 0) {
            char *arg = strrchr(cmd, ' ');
            if (arg) {
                arg = trim(arg);
                FILE *fp = fopen(arg, "w");
                if (fp) {
                    for (size_t i = 0; i < ll->len; i++) if (ll->items[i].visible) fprintf(fp, "%s\n", ll->items[i].text);
                    fclose(fp);
                }
            }
        } else if (*cmd) {
            char word[128];
            size_t n = strcspn(cmd, " \t\r\n");
            if (n >= sizeof(word)) n = sizeof(word) - 1;
            memcpy(word, cmd, n);
            word[n] = 0;
            fprintf(stderr, "  error: unknown command: “%s”\n", word);
            *printed = 1;
        }
    } else if (*cmd == ';') {
        run_sql(cmd + 1, ll);
        *printed = 1;
    } else if (*cmd) {
        fprintf(stderr, "  error: unknown command: “%s”\n", cmd);
        *printed = 1;
    }
    free(copy);
}

static int read_command_file(const char *path, StrList *commands) {
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "  error: unable to open file: %s\n", path);
        fprintf(stderr, " reason: %s\n", strerror(errno));
        return -1;
    }
    char *line = NULL;
    size_t n = 0;
    ssize_t r;
    while ((r = getline(&line, &n, fp)) >= 0) {
        while (r > 0 && (line[r - 1] == '\n' || line[r - 1] == '\r')) line[--r] = 0;
        if (*trim(line)) strlist_push(commands, line);
    }
    free(line);
    fclose(fp);
    return 0;
}

int main(int argc, char **argv) {
    Options o;
    memset(&o, 0, sizeof(o));
    opterr = 0;
    static struct option long_opts[] = {
        {"help", no_argument, 0, 'h'}, {"version", no_argument, 0, 'V'},
        {"since", required_argument, 0, 'S'}, {"until", required_argument, 0, 'U'},
        {0, 0, 0, 0}
    };
    int c;
    while ((c = getopt_long(argc, argv, "+hHWI:ud:VS:U:rRc:f:e:tnNqimC", long_opts, NULL)) != -1) {
        switch (c) {
        case 'h': usage(argv[0]); return 0;
        case 'V': printf("%s\n", VERSION); return 0;
        case 'H': if (!isatty(STDOUT_FILENO)) { tty_error(); return 1; } usage(argv[0]); return 0;
        case 'W': break;
        case 'I': break;
        case 'u': break;
        case 'd': o.debug_file = optarg; break;
        case 'S': o.since_arg = optarg; if (!parse_time_value(optarg, &o.since_ts)) { fprintf(stderr, "  error: invalid 'since' time “%s”\n reason: Unrecognized input\n", optarg); return 1; } o.has_since = 1; break;
        case 'U': o.until_arg = optarg; if (!parse_time_value(optarg, &o.until_ts)) { fprintf(stderr, "  error: invalid 'until' time “%s”\n reason: Unrecognized input\n", optarg); return 1; } o.has_until = 1; break;
        case 'r': o.recursive = 1; break;
        case 'R': o.rotated = 1; break;
        case 'c': strlist_push(&o.commands, optarg); o.had_command = 1; break;
        case 'f': if (read_command_file(optarg, &o.commands) != 0) return 1; o.had_command = 1; break;
        case 'e': {
            char *ecmd = NULL;
            if (asprintf(&ecmd, "%s 2>&1", optarg) < 0) exit(2);
            FILE *fp = popen(ecmd, "r");
            free(ecmd);
            if (fp) {
                read_stream(fp, &o.exec_lines);
                pclose(fp);
            }
            break;
        }
        case 't': o.stdin_log = 1; break;
        case 'n': o.headless = 1; break;
        case 'N': o.no_default = 1; break;
        case 'q': o.quiet = 1; break;
        case 'i':
            fprintf(stderr, "  error: invalid command-line arguments\n reason: -i requires file\n");
            return 107;
        case 'm':
            fprintf(stderr, "  error: expecting an operation to perform\n = help: the available operations are:\n          • apps: manage lnav apps\n          • config: perform operations on the lnav configuration\n          • format: perform operations on log file formats\n          • piper: perform operations on piper storage\n          • regex101: create and edit log message regular expressions using regex101.com\n          • crash: manage crash logs\n");
            return 1;
        case 'C': return 0;
        default:
            if (optopt) fprintf(stderr, "  error: invalid command-line arguments\n reason: -%c requires argument\n", optopt);
            else fprintf(stderr, "  error: invalid command-line arguments\n reason: The following argument was not expected: %s\n", argv[optind - 1]);
            return optopt ? 107 : 109;
        }
    }
    for (int i = optind; i < argc; i++) strlist_push(&o.paths, argv[i]);
    if (o.debug_file) {
        FILE *df = fopen(o.debug_file, "w");
        if (df) { fprintf(df, "debug logging enabled\n"); fclose(df); }
    }
    if (!o.headless) {
        if (!isatty(STDOUT_FILENO)) { tty_error(); return 1; }
        return 0;
    }
    LineList lines = {0};
    if (o.stdin_log) read_stream(stdin, &lines);
    for (size_t i = 0; i < o.exec_lines.len; i++) {
        linelist_push(&lines, strdup(o.exec_lines.items[i].text));
    }
    for (size_t i = 0; i < o.paths.len; i++) {
        struct stat st;
        if (stat(o.paths.items[i], &st) == 0) {
            if (load_path(o.paths.items[i], &o, &lines) != 0) return 1;
        } else {
            linelist_push(&lines, strdup(o.paths.items[i]));
        }
    }
    if (lines.len == 0 && o.paths.len == 0 && !o.no_default) {
        fprintf(stderr, "  error: nothing to do\n reason: no files given or default files found\n = help: use the “-N” option to open lnav without loading any files\n");
        return 1;
    }
    apply_time_filters(&o, &lines);
    int printed = 0;
    for (size_t i = 0; i < o.commands.len; i++) execute_command(o.commands.items[i], &lines, &printed);
    if (!o.quiet && !printed) print_visible(&lines);
    return 0;
}
