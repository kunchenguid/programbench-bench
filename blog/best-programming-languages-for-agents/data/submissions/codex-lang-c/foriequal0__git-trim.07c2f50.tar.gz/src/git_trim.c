#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fnmatch.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char **v;
    int n;
    int cap;
} StrList;

typedef struct {
    char *ref;
    char *shortname;
    char *sha;
    char *upstream;
    char *track;
    char *symref;
    bool is_remote;
    bool is_head_sym;
    bool is_base;
    bool protected_branch;
    bool stray;
    bool tracking;
    bool merged;
    bool delete_local;
    bool delete_remote;
    int skip_code;
} Branch;

typedef struct {
    Branch *v;
    int n;
    int cap;
} BranchList;

typedef struct {
    bool update;
    bool confirm;
    bool detach;
    bool dry_run;
    long update_interval;
    char *bases_arg;
    char *protected_arg;
    char *delete_arg;
} Opts;

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "Error: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) die("out of memory");
    return r;
}

static void strip_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0;
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static char *shell_quote(const char *s) {
    size_t len = 3;
    for (const char *p = s; *p; p++) len += (*p == '\'') ? 4 : 1;
    char *r = malloc(len);
    if (!r) die("out of memory");
    char *o = r;
    *o++ = '\'';
    for (const char *p = s; *p; p++) {
        if (*p == '\'') {
            memcpy(o, "'\\''", 4);
            o += 4;
        } else {
            *o++ = *p;
        }
    }
    *o++ = '\'';
    *o = 0;
    return r;
}

static int run_cmd(const char *fmt, ...) {
    char cmd[4096];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cmd, sizeof(cmd), fmt, ap);
    va_end(ap);
    int rc = system(cmd);
    if (rc == -1) return 127;
    if (WIFEXITED(rc)) return WEXITSTATUS(rc);
    return 1;
}

static char *read_cmd(const char *fmt, ...) {
    char cmd[4096];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cmd, sizeof(cmd), fmt, ap);
    va_end(ap);
    FILE *fp = popen(cmd, "r");
    if (!fp) return NULL;
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) die("out of memory");
    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (len + 1 >= cap) {
            cap *= 2;
            buf = realloc(buf, cap);
            if (!buf) die("out of memory");
        }
        buf[len++] = (char)c;
    }
    buf[len] = 0;
    int rc = pclose(fp);
    if (rc == -1 || !WIFEXITED(rc) || WEXITSTATUS(rc) != 0) {
        free(buf);
        return NULL;
    }
    return buf;
}

static char *config_get(const char *key) {
    char *q = shell_quote(key);
    char *out = read_cmd("git config --get %s 2>/dev/null", q);
    free(q);
    if (!out) return NULL;
    strip_newline(out);
    if (!*out) {
        free(out);
        return NULL;
    }
    return out;
}

static bool parse_bool(const char *s, bool def) {
    if (!s || !*s) return def;
    if (!strcasecmp(s, "true") || !strcasecmp(s, "yes") || !strcasecmp(s, "on") || !strcmp(s, "1")) return true;
    if (!strcasecmp(s, "false") || !strcasecmp(s, "no") || !strcasecmp(s, "off") || !strcmp(s, "0")) return false;
    return def;
}

static void sl_add(StrList *l, const char *s) {
    if (!s || !*s) return;
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 8;
        l->v = realloc(l->v, sizeof(char *) * l->cap);
        if (!l->v) die("out of memory");
    }
    l->v[l->n++] = xstrdup(s);
}

static bool sl_contains(StrList *l, const char *s) {
    for (int i = 0; i < l->n; i++) if (!strcmp(l->v[i], s)) return true;
    return false;
}

static void split_csv(StrList *l, const char *s) {
    if (!s) return;
    char *copy = xstrdup(s);
    for (char *tok = strtok(copy, ","); tok; tok = strtok(NULL, ",")) {
        char *t = trim(tok);
        if (*t) sl_add(l, t);
    }
    free(copy);
}

static void bl_add(BranchList *l, Branch b) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->v = realloc(l->v, sizeof(Branch) * l->cap);
        if (!l->v) die("out of memory");
    }
    l->v[l->n++] = b;
}

static bool show_ref_exists(const char *shortname) {
    char *q = shell_quote(shortname);
    int rc = run_cmd("git rev-parse --verify -q %s >/dev/null 2>&1", q);
    free(q);
    return rc == 0;
}

static bool is_ancestor(const char *a, const char *b) {
    char *qa = shell_quote(a), *qb = shell_quote(b);
    int rc = run_cmd("git merge-base --is-ancestor %s %s >/dev/null 2>&1", qa, qb);
    free(qa);
    free(qb);
    return rc == 0;
}

static char *remote_part(const char *remote_short) {
    const char *slash = strchr(remote_short, '/');
    if (!slash) return xstrdup(remote_short);
    return strndup(remote_short, slash - remote_short);
}

static const char *branch_part(const char *remote_short) {
    const char *slash = strchr(remote_short, '/');
    return slash ? slash + 1 : remote_short;
}

static void print_help(bool long_help) {
    puts("Automatically trims your tracking branches whose upstream branches are merged or stray.");
    puts("");
    puts("Usage: executable [OPTIONS]");
    puts("");
    puts("Options:");
    puts("  -b, --bases <BASES>");
    puts("          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]");
    if (long_help) {
        puts("          ");
        puts("          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.");
        puts("");
    }
    puts("  -p, --protected <PROTECTED>");
    puts("          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]");
    puts("      --no-update");
    puts("          Do not update remotes [config: trim.update]");
    puts("      --update-interval <UPDATE_INTERVAL>");
    puts("          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]");
    puts("      --no-confirm");
    puts("          Do not ask confirm [config: trim.confirm]");
    puts("      --no-detach");
    puts("          Do not detach when HEAD is about to be deleted [config: trim.detach]");
    puts("  -d, --delete <DELETE>");
    puts("          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]");
    if (long_help) {
        puts("          ");
        puts("          `merged` implies `merged-local,merged-remote`.");
        puts("          ");
        puts("          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.");
        puts("");
    }
    puts("      --dry-run");
    puts("          Do not delete branches, show what branches will be deleted");
    puts("  -h, --help");
    printf("          Print help%s\n", long_help ? " (see a summary with '-h')" : " (see more with '--help')");
    puts("  -V, --version");
    puts("          Print version");
}

static void parse_args(int argc, char **argv, Opts *o) {
    o->update = true;
    o->confirm = true;
    o->detach = true;
    o->update_interval = 5;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h")) { print_help(false); exit(0); }
        if (!strcmp(a, "--help")) { print_help(true); exit(0); }
        if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("git-trim 0.4.4"); exit(0); }
        if (!strcmp(a, "--no-update")) o->update = false;
        else if (!strcmp(a, "--update")) o->update = true;
        else if (!strcmp(a, "--no-confirm")) o->confirm = false;
        else if (!strcmp(a, "--confirm")) o->confirm = true;
        else if (!strcmp(a, "--no-detach")) o->detach = false;
        else if (!strcmp(a, "--detach")) o->detach = true;
        else if (!strcmp(a, "--dry-run")) o->dry_run = true;
        else if (!strcmp(a, "-b") || !strcmp(a, "--bases")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '%s <BASES>'\n", a); exit(2); }
            o->bases_arg = xstrdup(argv[i]);
        } else if (!strncmp(a, "--bases=", 8)) o->bases_arg = xstrdup(a + 8);
        else if (!strcmp(a, "-p") || !strcmp(a, "--protected")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '%s <PROTECTED>'\n", a); exit(2); }
            o->protected_arg = xstrdup(argv[i]);
        } else if (!strncmp(a, "--protected=", 12)) o->protected_arg = xstrdup(a + 12);
        else if (!strcmp(a, "-d") || !strcmp(a, "--delete")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '%s <DELETE>'\n", a); exit(2); }
            o->delete_arg = xstrdup(argv[i]);
        } else if (!strncmp(a, "--delete=", 9)) o->delete_arg = xstrdup(a + 9);
        else if (!strcmp(a, "--update-interval")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '--update-interval <UPDATE_INTERVAL>'\n"); exit(2); }
            char *end = NULL;
            errno = 0;
            long v = strtol(argv[i], &end, 10);
            if (errno || *end || v < 0) {
                fprintf(stderr, "error: invalid value '%s' for '--update-interval <UPDATE_INTERVAL>': invalid digit found in string\n\nFor more information, try '--help'.\n", argv[i]);
                exit(2);
            }
            o->update_interval = v;
        } else if (!strncmp(a, "--update-interval=", 18)) {
            char *val = a + 18, *end = NULL;
            long v = strtol(val, &end, 10);
            if (*end || v < 0) {
                fprintf(stderr, "error: invalid value '%s' for '--update-interval <UPDATE_INTERVAL>': invalid digit found in string\n\nFor more information, try '--help'.\n", val);
                exit(2);
            }
            o->update_interval = v;
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", a);
            exit(2);
        }
    }
}

static void apply_config(Opts *o) {
    char *s;
    s = config_get("trim.update"); if (s) { o->update = parse_bool(s, o->update); free(s); }
    s = config_get("trim.confirm"); if (s) { o->confirm = parse_bool(s, o->confirm); free(s); }
    s = config_get("trim.detach"); if (s) { o->detach = parse_bool(s, o->detach); free(s); }
    s = config_get("trim.updateInterval"); if (s) { char *e = NULL; long v = strtol(s, &e, 10); if (!*e && v >= 0) o->update_interval = v; free(s); }
    if (!o->bases_arg) o->bases_arg = config_get("trim.bases");
    if (!o->protected_arg) o->protected_arg = config_get("trim.protected");
    if (!o->delete_arg) o->delete_arg = config_get("trim.delete");
    if (!o->delete_arg) o->delete_arg = xstrdup("merged:origin");
}

static BranchList load_branches(void) {
    BranchList list = {0};
    char *out = read_cmd("git for-each-ref refs/heads refs/remotes --format='%%(refname)|%%(refname:short)|%%(objectname)|%%(upstream:short)|%%(upstream:track)|%%(symref)' 2>/dev/null");
    if (!out) die("could not list refs");
    char *save = NULL;
    for (char *line = strtok_r(out, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *fields[6] = {"", "", "", "", "", ""};
        char *p = line;
        for (int i = 0; i < 6; i++) {
            fields[i] = p;
            char *bar = strchr(p, '|');
            if (bar) {
                *bar = 0;
                p = bar + 1;
            } else {
                p = (char *)"";
            }
        }
        Branch b = {0};
        b.ref = xstrdup(fields[0]);
        b.shortname = xstrdup(fields[1]);
        b.sha = xstrdup(fields[2]);
        b.upstream = xstrdup(fields[3]);
        b.track = xstrdup(fields[4]);
        b.symref = xstrdup(fields[5]);
        b.is_remote = !strncmp(b.ref, "refs/remotes/", 13);
        b.is_head_sym = b.is_remote && *b.symref;
        b.tracking = !b.is_remote && *b.upstream;
        bl_add(&list, b);
    }
    free(out);
    return list;
}

static void default_bases(BranchList *branches, StrList *bases) {
    for (int i = 0; i < branches->n; i++) {
        Branch *b = &branches->v[i];
        if (b->is_head_sym && *b->symref) {
            const char *prefix = "refs/remotes/";
            const char *name = !strncmp(b->symref, prefix, strlen(prefix)) ? b->symref + strlen(prefix) : b->symref;
            sl_add(bases, name);
        }
    }
}

static void expand_bases(BranchList *branches, StrList *bases) {
    int original = bases->n;
    for (int i = 0; i < original; i++) {
        for (int j = 0; j < branches->n; j++) {
            Branch *b = &branches->v[j];
            if (!b->is_remote && !strcmp(b->shortname, bases->v[i]) && *b->upstream && !sl_contains(bases, b->upstream)) {
                sl_add(bases, b->upstream);
            }
        }
    }
    if (bases->n == 0) {
        char *cur = read_cmd("git branch --show-current 2>/dev/null");
        if (cur) {
            strip_newline(cur);
            for (int j = 0; j < branches->n; j++) {
                Branch *b = &branches->v[j];
                if (!b->is_remote && !strcmp(b->shortname, cur)) {
                    if (*b->upstream) sl_add(bases, b->upstream);
                    else sl_add(bases, cur);
                    break;
                }
            }
            free(cur);
        }
    }
}

static bool protected_match(StrList *patterns, const char *name) {
    for (int i = 0; i < patterns->n; i++) {
        if (fnmatch(patterns->v[i], name, 0) == 0) return true;
        const char *bp = branch_part(name);
        if (fnmatch(patterns->v[i], bp, 0) == 0) return true;
    }
    return false;
}

typedef struct {
    bool merged_local;
    bool stray;
    bool local;
    bool diverged;
    bool merged_remote_all;
    bool remote_all;
    StrList merged_remote;
    StrList remote;
    StrList diverged_remote;
} DeleteSpec;

static void parse_delete(DeleteSpec *d, const char *arg) {
    char *copy = xstrdup(arg);
    for (char *tok = strtok(copy, ","); tok; tok = strtok(NULL, ",")) {
        char *t = trim(tok);
        if (!*t) continue;
        char *colon = strchr(t, ':');
        char *remote = NULL;
        if (colon) {
            *colon = 0;
            remote = colon + 1;
        }
        if (!strcmp(t, "merged")) {
            d->merged_local = true;
            if (remote && *remote) {
                if (!strcmp(remote, "*")) d->merged_remote_all = true; else sl_add(&d->merged_remote, remote);
            }
        } else if (!strcmp(t, "merged-local")) d->merged_local = true;
        else if (!strcmp(t, "stray")) d->stray = true;
        else if (!strcmp(t, "local")) d->local = true;
        else if (!strcmp(t, "merged-remote")) {
            if (!remote || !*remote) {
                fprintf(stderr, "error: invalid value '%s' for '--delete <DELETE>': Invalid delete range format `%s`\n\nFor more information, try '--help'.\n", arg, t);
                exit(2);
            }
            if (!strcmp(remote, "*")) d->merged_remote_all = true; else sl_add(&d->merged_remote, remote);
        } else if (!strcmp(t, "remote")) {
            if (!remote || !*remote) {
                fprintf(stderr, "error: invalid value '%s' for '--delete <DELETE>': Invalid delete range format `%s`\n\nFor more information, try '--help'.\n", arg, t);
                exit(2);
            }
            if (!strcmp(remote, "*")) d->remote_all = true; else sl_add(&d->remote, remote);
        } else if (!strcmp(t, "diverged")) {
            d->diverged = true;
            if (remote && *remote) {
                if (!strcmp(remote, "*")) d->merged_remote_all = true; else sl_add(&d->diverged_remote, remote);
            }
        } else {
            fprintf(stderr, "error: invalid value '%s' for '--delete <DELETE>': Invalid delete range format `%s`\n\nFor more information, try '--help'.\n", arg, t);
            exit(2);
        }
    }
    free(copy);
}

static bool remote_allowed(StrList *remotes, bool all, const char *remote) {
    return all || sl_contains(remotes, remote);
}

static void classify(BranchList *branches, StrList *bases, StrList *protected, DeleteSpec *del) {
    for (int i = 0; i < branches->n; i++) {
        Branch *b = &branches->v[i];
        if (b->is_head_sym) continue;
        b->protected_branch = protected_match(protected, b->shortname);
        if (sl_contains(bases, b->shortname)) b->is_base = true;
        if (!b->is_remote && b->tracking && sl_contains(bases, b->upstream)) b->is_base = true;
    }
    const char *base = bases->n ? bases->v[0] : NULL;
    if (!base) return;
    for (int i = 0; i < branches->n; i++) {
        Branch *b = &branches->v[i];
        if (b->is_head_sym || b->is_base || b->protected_branch) continue;
        if (!b->is_remote) {
            if (b->tracking) {
                b->stray = strstr(b->track, "gone") != NULL || !show_ref_exists(b->upstream);
                b->merged = is_ancestor(b->shortname, base);
                if (b->stray && del->stray) b->delete_local = true;
                else if (b->merged && del->merged_local) b->delete_local = true;
            } else {
                b->merged = is_ancestor(b->shortname, base);
                if (b->merged && del->local) b->delete_local = true;
            }
        } else {
            char *remote = remote_part(b->shortname);
            bool upstream_of_local = false;
            for (int j = 0; j < branches->n; j++) {
                Branch *l = &branches->v[j];
                if (!l->is_remote && l->tracking && !strcmp(l->upstream, b->shortname)) {
                    upstream_of_local = true;
                    break;
                }
            }
            b->merged = is_ancestor(b->shortname, base);
            if (b->merged && remote_allowed(&del->merged_remote, del->merged_remote_all, remote)) b->delete_remote = true;
            if (b->merged && !upstream_of_local && remote_allowed(&del->remote, del->remote_all, remote)) b->delete_remote = true;
            free(remote);
        }
    }
}

static void print_remain(BranchList *branches, DeleteSpec *del) {
    bool any_skip2 = false;
    puts("Branches that will remain:");
    puts("  local branches:");
    for (int i = 0; i < branches->n; i++) {
        Branch *b = &branches->v[i];
        if (b->is_remote || b->delete_local) continue;
        printf("    %s", b->shortname);
        if (b->is_base) printf(" [base]");
        else if (b->protected_branch) printf(" [protected]");
        else if (b->stray && !del->stray) printf(" [stray, but: delete range `stray` was not given]");
        else if (!b->tracking) {
            printf(" *2");
            any_skip2 = true;
        }
        puts("");
    }
    puts("  remote references:");
    for (int i = 0; i < branches->n; i++) {
        Branch *b = &branches->v[i];
        if (!b->is_remote || b->is_head_sym || b->delete_remote) continue;
        printf("    %s", b->shortname);
        if (b->is_base) printf(" [base]");
        else if (b->protected_branch) printf(" [protected]");
        puts("");
    }
    if (any_skip2) {
        puts("  Some branches are skipped. Consider following to scan them:");
        puts("    *2: Set an upstream to make it a tracking branch or add `--delete 'local'` flag.");
    }
    puts("");
}

static void maybe_detach(Opts *o, BranchList *branches) {
    if (!o->detach) return;
    char *cur = read_cmd("git branch --show-current 2>/dev/null");
    if (!cur) return;
    strip_newline(cur);
    for (int i = 0; i < branches->n; i++) {
        Branch *b = &branches->v[i];
        if (b->delete_local && !strcmp(b->shortname, cur)) {
            run_cmd("git switch --detach HEAD >/dev/null 2>&1");
            break;
        }
    }
    free(cur);
}

static void do_delete(Opts *o, BranchList *branches) {
    bool any_local = false, any_remote = false;
    for (int i = 0; i < branches->n; i++) {
        if (branches->v[i].delete_local) any_local = true;
        if (branches->v[i].delete_remote) any_remote = true;
    }
    if (any_local) {
        puts("Delete merged local branches:");
        for (int i = 0; i < branches->n; i++) if (branches->v[i].delete_local) printf("  - %s\n", branches->v[i].shortname);
    }
    if (any_remote) {
        puts("Delete merged remote refs:");
        for (int i = 0; i < branches->n; i++) if (branches->v[i].delete_remote) {
            char *remote = remote_part(branches->v[i].shortname);
            printf("  - %s, refs/heads/%s\n", remote, branch_part(branches->v[i].shortname));
            free(remote);
        }
    }
    if (!any_local && !any_remote) return;
    fflush(stdout);
    if (o->confirm && !o->dry_run) {
        fprintf(stderr, "Error: IO error: not a terminal\n\nCaused by:\n    not a terminal\n");
        exit(1);
    }
    maybe_detach(o, branches);
    for (int i = 0; i < branches->n; i++) if (branches->v[i].delete_remote) {
        char *remote = remote_part(branches->v[i].shortname);
        const char *bp = branch_part(branches->v[i].shortname);
        char *qr = shell_quote(remote), *qb = shell_quote(bp);
        if (o->dry_run) run_cmd("git push --dry-run %s --delete %s", qr, qb);
        else run_cmd("git push %s --delete %s", qr, qb);
        fflush(stdout);
        free(qr); free(qb); free(remote);
    }
    for (int i = 0; i < branches->n; i++) if (branches->v[i].delete_local) {
        char *q = shell_quote(branches->v[i].shortname);
        if (o->dry_run) {
            printf("Delete branch %s (dry run).\n", branches->v[i].shortname);
        } else {
            run_cmd("git branch -d %s", q);
        }
        free(q);
    }
}

int main(int argc, char **argv) {
    Opts opts;
    memset(&opts, 0, sizeof(opts));
    parse_args(argc, argv, &opts);

    if (run_cmd("git rev-parse --git-dir >/dev/null 2>&1") != 0) {
        fprintf(stderr, "Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n");
        return 1;
    }
    apply_config(&opts);
    if (opts.update) run_cmd("git fetch --prune --all");

    StrList bases = {0}, prot = {0};
    DeleteSpec del;
    memset(&del, 0, sizeof(del));
    BranchList branches = load_branches();
    if (opts.bases_arg) split_csv(&bases, opts.bases_arg);
    else default_bases(&branches, &bases);
    expand_bases(&branches, &bases);
    split_csv(&prot, opts.protected_arg);
    parse_delete(&del, opts.delete_arg);
    classify(&branches, &bases, &prot, &del);
    print_remain(&branches, &del);
    do_delete(&opts, &branches);
    return 0;
}
