#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { char **v; int n, cap; } StrList;
typedef struct { char *from, *to; } Edge;
typedef struct { Edge *v; int n, cap; } EdgeList;
typedef struct { char *key; StrList vals; } Rule;
typedef struct { Rule *v; int n, cap; } RuleList;

static void sl_add(StrList *l, const char *s) {
    if (!s || !*s) return;
    for (int i=0;i<l->n;i++) if (strcmp(l->v[i], s)==0) return;
    if (l->n==l->cap) { l->cap=l->cap?l->cap*2:8; l->v=realloc(l->v,l->cap*sizeof(char*)); }
    l->v[l->n++]=strdup(s);
}
static void el_add(EdgeList *l, const char *a, const char *b) {
    if (!a || !b || !*a || !*b || strcmp(a,b)==0) return;
    for (int i=0;i<l->n;i++) if (!strcmp(l->v[i].from,a)&&!strcmp(l->v[i].to,b)) return;
    if (l->n==l->cap) { l->cap=l->cap?l->cap*2:16; l->v=realloc(l->v,l->cap*sizeof(Edge)); }
    l->v[l->n].from=strdup(a); l->v[l->n].to=strdup(b); l->n++;
}
static void rule_add(RuleList *rl, const char *key, const char *val) {
    if (!key || !val) return;
    for (int i=0;i<rl->n;i++) if (!strcmp(rl->v[i].key,key)) { sl_add(&rl->v[i].vals,val); return; }
    if (rl->n==rl->cap) { rl->cap=rl->cap?rl->cap*2:8; rl->v=realloc(rl->v,rl->cap*sizeof(Rule)); }
    rl->v[rl->n].key=strdup(key); rl->v[rl->n].vals=(StrList){0}; sl_add(&rl->v[rl->n].vals,val); rl->n++;
}
static bool exists_file(const char *p){ struct stat st; return stat(p,&st)==0 && S_ISREG(st.st_mode); }
static bool exists_dir(const char *p){ struct stat st; return stat(p,&st)==0 && S_ISDIR(st.st_mode); }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1])) *--e=0; return s; }
static void strip_quotes(char *s){ size_t n=strlen(s); if(n>=2 && ((s[0]=='\''&&s[n-1]=='\'')||(s[0]=='"'&&s[n-1]=='"'))){ memmove(s,s+1,n-2); s[n-2]=0; } }
static char *norm_path(const char *in) {
    char tmp[4096]; if (!realpath(in,tmp)) {
        char cwd[4096]; getcwd(cwd,sizeof(cwd)); snprintf(tmp,sizeof(tmp),"%s/%s",cwd,in);
    }
    char cwd[4096]; getcwd(cwd,sizeof(cwd)); size_t c=strlen(cwd);
    const char *p=tmp; if (!strncmp(tmp,cwd,c) && (tmp[c]=='/' || tmp[c]==0)) p=tmp+c+(tmp[c]=='/');
    while (!strncmp(p,"./",2)) p+=2;
    return strdup(*p?p:in);
}
static char *dir_name(const char *p){ char *s=strdup(p); char *q=strrchr(s,'/'); if(q)*q=0; else strcpy(s,"."); return s; }
static char *join2(const char *a,const char *b){ char *r; if(!strcmp(a,".")||!*a) asprintf(&r,"%s",b); else asprintf(&r,"%s/%s",a,b); return r; }
static void replace_char(char *s,char a,char b){ for(;*s;s++) if(*s==a)*s=b; }
static bool has_ext(const char *p){
    const char *e=strrchr(p,'.'); if(!e) return false;
    return !strcmp(e,".py")||!strcmp(e,".js")||!strcmp(e,".jsx")||!strcmp(e,".ts")||!strcmp(e,".tsx")||!strcmp(e,".mjs")||!strcmp(e,".cjs")||!strcmp(e,".go")||!strcmp(e,".rs");
}
static void scan_files(const char *dir, StrList *out) {
    DIR *d=opendir(dir); if(!d) return; struct dirent *de;
    while((de=readdir(d))) {
        if(!strcmp(de->d_name,".")||!strcmp(de->d_name,"..")||!strcmp(de->d_name,".git")||!strcmp(de->d_name,"node_modules")||!strcmp(de->d_name,"target")) continue;
        char *p=join2(dir,de->d_name);
        if(exists_dir(p)) scan_files(p,out); else if(exists_file(p)&&has_ext(p)) { char *n=norm_path(p); sl_add(out,n); free(n); }
        free(p);
    }
    closedir(d);
}
static bool match_glob(const char *pat,const char *path) {
    if(!pat||!*pat) return false;
    char buf[4096]; snprintf(buf,sizeof(buf),"%s",pat); strip_quotes(buf);
    if(fnmatch(buf,path,0)==0) return true;
    char *gs = strstr(buf, "/**/");
    if (gs) {
        char pre[2048], post[2048];
        size_t pn = (size_t)(gs - buf) + 1;
        memcpy(pre, buf, pn); pre[pn] = 0;
        snprintf(post, sizeof(post), "%s", gs + 4);
        if (!strncmp(path, pre, pn)) {
            const char *tail = path + pn;
            if (fnmatch(post, tail, 0) == 0) return true;
            for (const char *slash = strchr(tail, '/'); slash; slash = strchr(slash + 1, '/'))
                if (fnmatch(post, slash + 1, 0) == 0) return true;
        }
    }
    gs = strstr(buf, "/**");
    if (gs && gs[3] == 0) {
        char pre[2048];
        size_t pn = (size_t)(gs - buf) + 1;
        memcpy(pre, buf, pn); pre[pn] = 0;
        if (!strncmp(path, pre, pn)) return true;
    }
    if(strstr(buf,"**")) {
        char simple[4096]; int j=0;
        for(int i=0;buf[i]&&j<(int)sizeof(simple)-1;i++){ if(buf[i]=='*'&&buf[i+1]=='*'){ simple[j++]='*'; i++; } else simple[j++]=buf[i]; }
        simple[j]=0; if(fnmatch(simple,path,0)==0) return true;
    }
    return false;
}
static void files_matching(const char *pat, StrList *out) {
    StrList all={0}; scan_files(".",&all);
    for(int i=0;i<all.n;i++) if(match_glob(pat,all.v[i])) sl_add(out,all.v[i]);
}
static char *try_candidates(const char *base) {
    const char *exts[]={"",".py",".js",".jsx",".ts",".tsx",".mjs",".cjs",".go",".rs",NULL};
    for(int i=0;exts[i];i++){ char *p; asprintf(&p,"%s%s",base,exts[i]); if(exists_file(p)){ char *n=norm_path(p); free(p); return n; } free(p); }
    const char *idx[]={"/index.js","/index.ts","/__init__.py","/mod.rs",NULL};
    for(int i=0;idx[i];i++){ char *p; asprintf(&p,"%s%s",base,idx[i]); if(exists_file(p)){ char *n=norm_path(p); free(p); return n; } free(p); }
    return NULL;
}
static char *resolve_js(const char *from,const char *spec){
    if(strncmp(spec,".",1)!=0 && spec[0]!='/') return NULL;
    char *d=dir_name(from), *base = spec[0]=='/'?strdup(spec+1):join2(d,spec); free(d);
    char *r=try_candidates(base); free(base); return r;
}
static char *resolve_py_module(const char *module){
    char b[4096]; snprintf(b,sizeof(b),"%s",module); replace_char(b,'.','/');
    return try_candidates(b);
}
static char *resolve_py_relative(const char *from, int dots, const char *mod, const char *name){
    char *d=dir_name(from);
    for(int i=1;i<dots;i++){ char *q=strrchr(d,'/'); if(q)*q=0; else strcpy(d,"."); }
    char rel[4096]=""; if(mod&&*mod){ snprintf(rel,sizeof(rel),"%s",mod); replace_char(rel,'.','/'); }
    if(name&&*name){ if(*rel) strncat(rel,"/",sizeof(rel)-strlen(rel)-1); strncat(rel,name,sizeof(rel)-strlen(rel)-1); }
    char *base=join2(d,rel); free(d); char *r=try_candidates(base); free(base); return r;
}
static void parse_quoted_specs(const char *line, StrList *specs) {
    for(const char *p=line; *p; p++) if(*p=='"' || *p=='\'') {
        char q=*p++; const char *s=p; while(*p && *p!=q) p++;
        if(*p==q){ char tmp[1024]; int n=p-s; if(n>0&&n<(int)sizeof(tmp)){ memcpy(tmp,s,n); tmp[n]=0; sl_add(specs,tmp); } }
    }
}
static void parse_file_deps(const char *file, EdgeList *edges) {
    FILE *f=fopen(file,"r"); if(!f) return; char line[4096];
    while(fgets(line,sizeof(line),f)) {
        char orig[4096]; snprintf(orig,sizeof(orig),"%s",line); char *s=trim(line);
        if(!*s || *s=='#' || !strncmp(s,"//",2)) continue;
        const char *ext=strrchr(file,'.');
        if(ext && !strcmp(ext,".py")) {
            if(!strncmp(s,"import ",7)) {
                char *p=s+7, *tok=strtok(p,", ");
                while(tok){ char *r=resolve_py_module(tok); if(r){el_add(edges,file,r); free(r);} tok=strtok(NULL,", "); }
            } else if(!strncmp(s,"from ",5)) {
                char *p=s+5, *imp=strstr(p," import "); if(imp){ *imp=0; char *mod=trim(p); char *names=trim(imp+8); int dots=0; while(mod[dots]=='.') dots++;
                    char *first=strtok(names,", "); if(first&&strcmp(first,"*")) {
                        char *r = dots?resolve_py_relative(file,dots,mod+dots,first):NULL;
                        if(!r && dots) r=resolve_py_relative(file,dots,mod+dots,NULL);
                        if(!r && !dots){ char combo[1024]; snprintf(combo,sizeof(combo),"%s.%s",mod,first); r=resolve_py_module(combo); if(!r) r=resolve_py_module(mod); }
                        if(r){el_add(edges,file,r); free(r);}
                    } else { char *r=dots?resolve_py_relative(file,dots,mod+dots,NULL):resolve_py_module(mod); if(r){el_add(edges,file,r); free(r);} }
                }
            }
        } else if(ext && (!strcmp(ext,".js")||!strcmp(ext,".jsx")||!strcmp(ext,".ts")||!strcmp(ext,".tsx")||!strcmp(ext,".mjs")||!strcmp(ext,".cjs"))) {
            StrList specs={0}; if(strstr(orig,"import")||strstr(orig,"export")||strstr(orig,"require")) parse_quoted_specs(orig,&specs);
            for(int i=0;i<specs.n;i++){ char *r=resolve_js(file,specs.v[i]); if(r){el_add(edges,file,r); free(r);} }
        } else if(ext && !strcmp(ext,".rs")) {
            if(!strncmp(s,"mod ",4)){ char name[256]; if(sscanf(s+4,"%255[^; {]",name)==1){ char *d=dir_name(file), *b=join2(d,name); free(d); char *r=try_candidates(b); free(b); if(r){el_add(edges,file,r); free(r);} } }
        } else if(ext && !strcmp(ext,".go")) {
            StrList specs={0}; parse_quoted_specs(orig,&specs);
            for(int i=0;i<specs.n;i++){ char *r=try_candidates(specs.v[i]); if(r){el_add(edges,file,r); free(r);} }
        }
    }
    fclose(f);
}
static void build_graph_from_roots(StrList *roots, EdgeList *edges) {
    StrList seen={0}, q={0}; for(int i=0;i<roots->n;i++){ char *n=norm_path(roots->v[i]); sl_add(&q,n); free(n); }
    for(int qi=0; qi<q.n; qi++) {
        if(!exists_file(q.v[qi])) continue; if(seen.n && match_glob("__never__",q.v[qi])) {}
        bool done=false; for(int j=0;j<seen.n;j++) if(!strcmp(seen.v[j],q.v[qi])) done=true; if(done) continue;
        sl_add(&seen,q.v[qi]); int before=edges->n; parse_file_deps(q.v[qi],edges);
        for(int e=before;e<edges->n;e++) sl_add(&q,edges->v[e].to);
    }
}
static void json_str(const char *s){ putchar('"'); for(;*s;s++){ if(*s=='"'||*s=='\\') printf("\\%c",*s); else if(*s=='\n') printf("\\n"); else putchar(*s);} putchar('"'); }
static void print_json_node(const char *node, EdgeList *edges, StrList *stack) {
    bool cyc=false; for(int i=0;i<stack->n;i++) if(!strcmp(stack->v[i],node)) cyc=true;
    if(cyc){ printf("null"); return; }
    StrList children={0}; for(int i=0;i<edges->n;i++) if(!strcmp(edges->v[i].from,node)) sl_add(&children,edges->v[i].to);
    if(children.n==0){ printf("null"); return; }
    sl_add(stack,node); printf("{");
    for(int i=0;i<children.n;i++){ if(i) printf(","); printf("\n"); for(int k=0;k<stack->n+3;k++) printf("  "); json_str(children.v[i]); printf(": "); print_json_node(children.v[i],edges,stack); }
    printf("\n"); for(int k=0;k<stack->n+1;k++) printf("  "); printf("}");
    stack->n--;
}
static void cmd_tree(const char *entry, bool json) {
    if(!entry){ fprintf(stderr,"Error: requires at least 1 arg(s), only received 0\n"); exit(1); }
    if(!exists_file(entry)){ fprintf(stderr,"Error: %s does not match with any existing file\n",entry); exit(1); }
    StrList roots={0}; sl_add(&roots,entry); EdgeList edges={0}; build_graph_from_roots(&roots,&edges); char *root=norm_path(entry);
    if(json){ printf("{\n  \"tree\": {\n    "); json_str(root); printf(": "); StrList st={0}; print_json_node(root,&edges,&st); printf("\n  },\n  \"circularDependencies\": [],\n  \"errors\": {}\n}\n"); }
    else { printf("%s\n",root); for(int i=0;i<edges.n;i++) printf("  %s\n",edges.v[i].to); }
    free(root);
}
static void cmd_explain(const char *a,const char *b,bool ol,bool orr) {
    if(!a||!b){ fprintf(stderr,"Error: accepts 2 arg(s), received %d\n", a?1:0); exit(1); }
    StrList left={0}, right={0}; files_matching(a,&left); files_matching(b,&right);
    if(ol||orr){ for(int i=0;i<left.n;i++) for(int j=0;j<right.n;j++) if(!strcmp(left.v[i],right.v[j])) { if(ol) right.v[j][0]=0; if(orr) left.v[i][0]=0; } }
    EdgeList edges={0}; build_graph_from_roots(&left,&edges);
    for(int i=0;i<edges.n;i++) for(int j=0;j<right.n;j++) if(*right.v[j]&&!strcmp(edges.v[i].to,right.v[j])) printf("%s -> %s\n",edges.v[i].from,edges.v[i].to);
}
static const char *sample_config =
"# Files that should be completely ignored by dep-tree. It's fine to ignore\n"
"# some big files that everyone depends on and that don't add\n"
"# value to the visualization, like auto generated code.\n"
"exclude:\n  - 'some-glob-pattern/**/*.ts'\n\n"
"# The only files that will be included by dep-tree. If a file does not\n"
"# match any of the provided patters, it is ignored.\n"
"only:\n  - 'some-glob-pattern/**/*.ts'\n\n"
"unwrapExports: false\n\n"
"check:\n  entrypoints:\n    - src/index.ts\n  allowCircularDependencies: false\n  allow:\n    'src/products/**':\n      - 'src/products/**'\n      - 'src/helpers/**'\n  deny:\n    'src/products/**':\n      - 'src/users/**'\n";
static void cmd_config(const char *path){ if(exists_file(path)){ fprintf(stderr,"Error: cannot generate config file, as one already exists in %s\n",path); exit(1);} FILE*f=fopen(path,"w"); if(!f){perror(path);exit(1);} fputs(sample_config,f); fclose(f); chmod(path,0600); }
static void parse_config(const char *path, StrList *entries, RuleList *allow, RuleList *deny, bool *allowCirc) {
    FILE *f=fopen(path,"r"); if(!f) return; char line[2048], section[32]=""; char curkey[1024]="";
    while(fgets(line,sizeof(line),f)){ char *s=trim(line); if(!*s||*s=='#') continue;
        if(!strncmp(s,"allowCircularDependencies:",26)){ *allowCirc=strstr(s,"true")!=NULL; continue; }
        if(!strcmp(s,"entrypoints:")){ strcpy(section,"entry"); continue; }
        if(!strcmp(s,"allow:")){ strcpy(section,"allow"); curkey[0]=0; continue; }
        if(!strcmp(s,"deny:")){ strcpy(section,"deny"); curkey[0]=0; continue; }
        if(!strncmp(s,"-",1)){ char *v=trim(s+1); strip_quotes(v); if(!strcmp(section,"entry")) sl_add(entries,v); else if(curkey[0]) { if(!strcmp(section,"allow")) rule_add(allow,curkey,v); else if(!strcmp(section,"deny")) rule_add(deny,curkey,v); } continue; }
        char *colon=strchr(s,':'); if(colon && (!strcmp(section,"allow")||!strcmp(section,"deny"))){ *colon=0; char *k=trim(s); strip_quotes(k); snprintf(curkey,sizeof(curkey),"%s",k); }
    }
    fclose(f);
}
static void cmd_check(const char *cfg) {
    if(!exists_file(cfg)){ fprintf(stderr,"Error: when using the `check` subcommand, a .dep-tree.yml file must be provided, you can create one sample .dep-tree.yml file executing `dep-tree config` in your terminal\n"); exit(1); }
    StrList entries={0}; RuleList allow={0}, deny={0}; bool allowCirc=false; parse_config(cfg,&entries,&allow,&deny,&allowCirc);
    EdgeList edges={0}; build_graph_from_roots(&entries,&edges); StrList bad={0};
    for(int i=0;i<edges.n;i++){
        for(int r=0;r<deny.n;r++) if(match_glob(deny.v[r].key,edges.v[i].from)) for(int v=0;v<deny.v[r].vals.n;v++) if(match_glob(deny.v[r].vals.v[v],edges.v[i].to)){ char *m; asprintf(&m,"%s -> %s",edges.v[i].from,edges.v[i].to); sl_add(&bad,m); free(m); }
        for(int r=0;r<allow.n;r++) if(match_glob(allow.v[r].key,edges.v[i].from)){ bool ok=false; for(int v=0;v<allow.v[r].vals.n;v++) if(match_glob(allow.v[r].vals.v[v],edges.v[i].to)) ok=true; if(!ok){ char *m; asprintf(&m,"%s -> %s",edges.v[i].from,edges.v[i].to); sl_add(&bad,m); free(m); } }
    }
    if(bad.n){ fprintf(stderr,"Error: Check failed, the following dependencies are not allowed:\n"); for(int i=0;i<bad.n;i++) fprintf(stderr,"- %s\n",bad.v[i]); exit(1); }
}
static void print_help(void){
    puts("\n      ____         _ __       _\n     |  _ \\   ___ |  _ \\    _| |_  _ __  ___   ___\n     | | | | / _ \\| |_) |  |_   _||  __|/ _ \\ / _ \\\n     | |_| ||  __/| .__/     | |  | |  |  __/|  __/\n     |____/  \\__| |_|        | \\__|_|   \\___| \\___|\n\nUsage:\n  dep-tree [command]\n\nExamples:\n$ dep-tree src/index.ts\n$ dep-tree entropy src/index.ts\n$ dep-tree tree package/main.py --unwrap-exports\n$ dep-tree check\n\nVisualize your dependencies graphically\n  entropy     (default) Renders a 3d force-directed graph in the browser\n  tree        Render the dependency tree starting from the provided entrypoint\n\nCheck your dependencies against your own rules\n  check       Checks that the dependency rules defined in the configuration file are not broken\n\nDisplay what are the dependencies between two portions of code\n  explain     Shows all the dependencies between two parts of the code\n\nAdditional Commands:\n  config      Generates a sample config in case that there's not already one present\n  help        Help about any command\n\nFlags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n  -h, --help                                 help for dep-tree\n  -v, --version                              version for dep-tree\n\nUse \"dep-tree [command] --help\" for more information about a command.");
}
static void sub_help(const char *c){
    if(!strcmp(c,"tree")) puts("Render the dependency tree starting from the provided entrypoint\n\nUsage:\n  dep-tree tree [flags]\n\nFlags:\n  -h, --help   help for tree\n      --json   render the dependency tree in a machine readable json format");
    else if(!strcmp(c,"explain")) puts("Shows all the dependencies between two parts of the code\n\nUsage:\n  dep-tree explain [flags]\n\nFlags:\n  -h, --help            help for explain\n  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left\n  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right");
    else if(!strcmp(c,"check")) puts("Checks that the dependency rules defined in the configuration file are not broken\n\nUsage:\n  dep-tree check [flags]\n\nFlags:\n  -h, --help   help for check");
    else if(!strcmp(c,"config")) puts("Generates a sample config in case that there's not already one present\n\nUsage:\n  dep-tree config [flags]\n\nAliases:\n  config, init\n\nFlags:\n  -h, --help   help for config");
    else if(!strcmp(c,"entropy")) puts("(default) Renders a 3d force-directed graph in the browser\n\nUsage:\n  dep-tree entropy [flags]\n\nFlags:\n      --enable-gui           Enables a GUI for changing rendering settings\n  -h, --help                 help for entropy\n      --no-browser-open      Disable the automatic browser open while rendering entropy\n      --render-path string   Sets the output path of the rendered html file");
    else print_help();
}
static void cmd_entropy(const char *entry, const char *render) {
    if(!entry){ fprintf(stderr,"Error: requires at least 1 arg(s), only received 0\n"); exit(1); }
    if(!exists_file(entry)){ fprintf(stderr,"Error: %s does not match with any existing file\n",entry); exit(1); }
    const char *out=render?render:"dep-tree.html"; FILE*f=fopen(out,"w"); if(f){ fprintf(f,"<!doctype html><title>dep-tree</title><h1>dep-tree</h1>\n"); fclose(f); }
}
int main(int argc,char **argv){
    const char *cfg=".dep-tree.yml"; char *args[256]; int an=0; bool json=false, ol=false, orr=false; const char *render=NULL;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"-c")||!strcmp(argv[i],"--config")){ if(i+1<argc) cfg=argv[++i]; }
        else if(!strcmp(argv[i],"--json")) json=true;
        else if(!strcmp(argv[i],"-l")||!strcmp(argv[i],"--overlap-left")) ol=true;
        else if(!strcmp(argv[i],"-r")||!strcmp(argv[i],"--overlap-right")) orr=true;
        else if(!strcmp(argv[i],"--render-path")){ if(i+1<argc) render=argv[++i]; }
        else if(!strcmp(argv[i],"--help")||!strcmp(argv[i],"-h")) args[an++]="--help";
        else if(!strcmp(argv[i],"--version")||!strcmp(argv[i],"-v")) { puts("dep-tree version v0.23.4"); return 0; }
        else if(!strncmp(argv[i],"--",2)) {}
        else args[an++]=argv[i];
    }
    if(an==0){ print_help(); return 0; }
    if(!strcmp(args[0],"--help")){ print_help(); return 0; }
    if(an>1 && !strcmp(args[1],"--help")){ sub_help(args[0]); return 0; }
    if(!strcmp(args[0],"help")){ if(an>1) sub_help(args[1]); else sub_help("help"); return 0; }
    if(!strcmp(args[0],"tree")) cmd_tree(an>1?args[1]:NULL,json);
    else if(!strcmp(args[0],"explain")) cmd_explain(an>1?args[1]:NULL,an>2?args[2]:NULL,ol,orr);
    else if(!strcmp(args[0],"check")) cmd_check(cfg);
    else if(!strcmp(args[0],"config")||!strcmp(args[0],"init")) cmd_config(cfg);
    else if(!strcmp(args[0],"entropy")) cmd_entropy(an>1?args[1]:NULL,render);
    else if(exists_file(args[0])) cmd_entropy(args[0],render);
    else { fprintf(stderr,"Error: %s does not match with any existing file\n",args[0]); return 1; }
    return 0;
}
