#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <limits.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct {
    char **v;
    size_t n, cap;
} StrVec;

static void push(StrVec *sv, const char *s) {
    if (sv->n == sv->cap) {
        sv->cap = sv->cap ? sv->cap * 2 : 8;
        sv->v = realloc(sv->v, sv->cap * sizeof(char *));
        if (!sv->v) { perror("realloc"); exit(2); }
    }
    sv->v[sv->n++] = strdup(s ? s : "");
}

typedef struct {
    StrVec pats;
    StrVec paths;
    StrVec globs;
    StrVec iglobs;
    StrVec ignore_files;
    StrVec types;
    StrVec not_types;
    int ignore_case, smart_case, fixed, invert, word, line_regexp;
    int line_number, no_line_number, with_filename, no_filename;
    int count, count_matches, files_with_matches, files_without_match, only_matching;
    int files, type_list, quiet, hidden, unrestricted, text, follow;
    int before, after, context, max_count, max_depth;
    int heading, no_heading, pretty, json, stats, null_sep, trim, vimgrep;
    int include_zero, sort_path, sort_reverse, color_always, color_never;
    char *replace;
    char path_separator;
} Opts;

typedef struct {
    regex_t re;
    char *pat;
    int ok;
} Pattern;

typedef struct {
    Opts o;
    Pattern *res;
    size_t ren;
    long matched_lines;
    long files_with_matches;
    long files_searched;
    int any_match;
    int had_error;
    int total_inputs;
} App;

static const char *short_help =
"ripgrep 14.1.1 (rev 719e15af5e)\n"
"Andrew Gallant <jamslam@gmail.com>\n\n"
"ripgrep (rg) recursively searches the current directory for lines matching\n"
"a regex pattern. By default, ripgrep will respect gitignore rules and\n"
"automatically skip hidden files/directories and binary files.\n\n"
"Use -h for short descriptions and --help for more details.\n\n"
"Project home page: https://github.com/BurntSushi/ripgrep\n\n"
"USAGE:\n"
"  rg [OPTIONS] PATTERN [PATH ...]\n\n"
"POSITIONAL ARGUMENTS:\n"
"  <PATTERN>   A regular expression used for searching.\n"
"  <PATH>...   A file or directory to search.\n\n"
"INPUT OPTIONS:\n"
"  -e, --regexp=PATTERN            A pattern to search for.\n"
"  -f, --file=PATTERNFILE          Search for patterns from the given file.\n"
"  -z, --search-zip                Search in compressed files.\n\n"
"SEARCH OPTIONS:\n"
"  -s, --case-sensitive            Search case sensitively (default).\n"
"  -F, --fixed-strings             Treat all patterns as literals.\n"
"  -i, --ignore-case               Case insensitive search.\n"
"  -v, --invert-match              Invert matching.\n"
"  -x, --line-regexp               Show matches surrounded by line boundaries.\n"
"  -m, --max-count=NUM             Limit the number of matching lines.\n"
"  -S, --smart-case                Smart case search.\n"
"  -a, --text                      Search binary files as if they were text.\n"
"  -w, --word-regexp               Show matches surrounded by word boundaries.\n\n"
"FILTER OPTIONS:\n"
"  -L, --follow                    Follow symbolic links.\n"
"  -g, --glob=GLOB                 Include or exclude file paths.\n"
"  -., --hidden                    Search hidden files and directories.\n"
"  -d, --max-depth=NUM             Descend at most NUM directories.\n"
"  --no-ignore                     Don't use ignore files.\n"
"  -t, --type=TYPE                 Only search files matching TYPE.\n"
"  -T, --type-not=TYPE             Do not search files matching TYPE.\n"
"  -u, --unrestricted              Reduce the level of smart filtering.\n\n"
"OUTPUT OPTIONS:\n"
"  -A, --after-context=NUM         Show NUM lines after each match.\n"
"  -B, --before-context=NUM        Show NUM lines before each match.\n"
"  -C, --context=NUM               Show NUM lines before and after each match.\n"
"  -c, --count                     Show count of matching lines for each file.\n"
"  --count-matches                 Show count of every match for each file.\n"
"  -l, --files-with-matches        Print paths with at least one match.\n"
"  --files-without-match           Print paths with no matches.\n"
"  -n, --line-number               Show line numbers.\n"
"  -N, --no-line-number            Suppress line numbers.\n"
"  -H, --with-filename             Print file path with each matching line.\n"
"  -I, --no-filename               Never print file path with matches.\n"
"  -o, --only-matching             Print only matching parts.\n"
"  -q, --quiet                     Do not print anything to stdout.\n\n"
"OTHER BEHAVIORS:\n"
"  --files                         Print each file that would be searched.\n"
"  --type-list                     Show all supported file types.\n"
"  -V, --version                   Print ripgrep's version.\n";

static void version(void) {
    puts("ripgrep 14.1.1 (rev 719e15af5e)\n");
    puts("features:-pcre2");
    puts("simd(compile):+SSE2,-SSSE3,-AVX2");
    puts("simd(runtime):+SSE2,+SSSE3,+AVX2\n");
    puts("PCRE2 is not available in this build of ripgrep.");
}

static void type_list(void) {
    puts("ada: *.adb, *.ads");
    puts("agda: *.agda, *.lagda");
    puts("aidl: *.aidl");
    puts("alire: alire.toml");
    puts("amake: *.bp, *.mk");
    puts("asciidoc: *.adoc, *.asc, *.asciidoc");
    puts("asm: *.S, *.asm, *.s");
    puts("awk: *.awk");
    puts("bat: *.bat");
    puts("bazel: *.BUILD, *.bazel, *.bazelrc, *.bzl, BUILD, WORKSPACE");
    puts("c: *.[chH], *.[chH].in");
    puts("cpp: *.C, *.H, *.cc, *.cpp, *.cxx, *.h, *.hh, *.hpp, *.hxx");
    puts("css: *.css, *.scss, *.sass");
    puts("go: *.go");
    puts("html: *.htm, *.html");
    puts("java: *.java");
    puts("js: *.js, *.jsx, *.mjs");
    puts("json: *.json, *.jsonl");
    puts("make: Makefile, makefile, GNUmakefile, *.mk");
    puts("md: *.markdown, *.md, *.mdown, *.mkdn");
    puts("py: *.py, *.pyw");
    puts("rust: *.rs");
    puts("sh: *.sh, *.bash, *.zsh");
    puts("toml: *.toml");
    puts("ts: *.ts, *.tsx");
    puts("txt: *.txt");
    puts("xml: *.xml");
    puts("yaml: *.yaml, *.yml");
}

static int has_upper(const char *s) {
    for (; *s; s++) if (isupper((unsigned char)*s)) return 1;
    return 0;
}

static char *lower_dup(const char *s) {
    char *d = strdup(s);
    for (char *p = d; *p; p++) *p = (char)tolower((unsigned char)*p);
    return d;
}

static int is_wordc(int c) { return isalnum((unsigned char)c) || c == '_'; }

static int literal_find(const char *line, const char *pat, int icase, int word, int whole, regmatch_t *m, size_t start) {
    size_t lp = strlen(pat), ll = strlen(line);
    if (lp == 0) { m->rm_so = start; m->rm_eo = start; return 1; }
    char *lh = NULL, *ph = NULL;
    const char *hay = line, *needle = pat;
    if (icase) { lh = lower_dup(line); ph = lower_dup(pat); hay = lh; needle = ph; }
    for (size_t i = start; i <= ll; i++) {
        if (i + lp > ll) break;
        if (memcmp(hay + i, needle, lp) == 0) {
            int ok = 1;
            if (word) {
                if (i > 0 && is_wordc((unsigned char)line[i-1])) ok = 0;
                if (i + lp < ll && is_wordc((unsigned char)line[i+lp])) ok = 0;
            }
            if (whole) {
                size_t end = ll;
                while (end && (line[end-1] == '\n' || line[end-1] == '\r')) end--;
                ok = (i == 0 && lp == end);
            }
            if (ok) { m->rm_so = i; m->rm_eo = i + lp; free(lh); free(ph); return 1; }
        }
    }
    free(lh); free(ph); return 0;
}

static int type_match_one(const char *path, const char *type) {
    const char *base = strrchr(path, '/'); base = base ? base + 1 : path;
    if (!strcmp(type, "all")) return 1;
    if (!strcmp(type, "c")) return fnmatch("*.[chH]", base, 0) == 0;
    if (!strcmp(type, "cpp") || !strcmp(type, "c++")) return fnmatch("*.cpp", base, 0)==0 || fnmatch("*.cc", base, 0)==0 || fnmatch("*.cxx", base, 0)==0 || fnmatch("*.hpp", base, 0)==0 || fnmatch("*.hh", base, 0)==0;
    if (!strcmp(type, "py") || !strcmp(type, "python")) return fnmatch("*.py", base, 0)==0 || fnmatch("*.pyw", base, 0)==0;
    if (!strcmp(type, "rust") || !strcmp(type, "rs")) return fnmatch("*.rs", base, 0)==0;
    if (!strcmp(type, "go")) return fnmatch("*.go", base, 0)==0;
    if (!strcmp(type, "js")) return fnmatch("*.js", base, 0)==0 || fnmatch("*.jsx", base, 0)==0 || fnmatch("*.mjs", base, 0)==0;
    if (!strcmp(type, "ts")) return fnmatch("*.ts", base, 0)==0 || fnmatch("*.tsx", base, 0)==0;
    if (!strcmp(type, "md") || !strcmp(type, "markdown")) return fnmatch("*.md", base, 0)==0 || fnmatch("*.markdown", base, 0)==0;
    if (!strcmp(type, "json")) return fnmatch("*.json", base, 0)==0 || fnmatch("*.jsonl", base, 0)==0;
    if (!strcmp(type, "toml")) return fnmatch("*.toml", base, 0)==0;
    if (!strcmp(type, "yaml")) return fnmatch("*.yml", base, 0)==0 || fnmatch("*.yaml", base, 0)==0;
    if (!strcmp(type, "html")) return fnmatch("*.html", base, 0)==0 || fnmatch("*.htm", base, 0)==0;
    if (!strcmp(type, "sh")) return fnmatch("*.sh", base, 0)==0 || fnmatch("*.bash", base, 0)==0 || fnmatch("*.zsh", base, 0)==0;
    if (!strcmp(type, "txt")) return fnmatch("*.txt", base, 0)==0;
    return 0;
}

static int type_allowed(Opts *o, const char *path) {
    if (o->types.n) {
        int any = 0;
        for (size_t i=0;i<o->types.n;i++) if (type_match_one(path, o->types.v[i])) any = 1;
        if (!any) return 0;
    }
    for (size_t i=0;i<o->not_types.n;i++) if (type_match_one(path, o->not_types.v[i])) return 0;
    return 1;
}

static int glob_allowed(Opts *o, const char *path) {
    int has_positive = 0, positive_ok = 0;
    StrVec *vecs[2] = { &o->globs, &o->iglobs };
    for (int v=0; v<2; v++) {
        for (size_t i=0;i<vecs[v]->n;i++) {
            const char *g = vecs[v]->v[i];
            int neg = g[0] == '!';
            if (neg) g++;
            else has_positive = 1;
            int flags = v ? FNM_CASEFOLD : 0;
            const char *base = strrchr(path, '/'); base = base ? base + 1 : path;
            int m = fnmatch(g, path, flags) == 0 || fnmatch(g, base, flags) == 0;
            if (m && neg) return 0;
            if (m && !neg) positive_ok = 1;
        }
    }
    return !has_positive || positive_ok;
}

static int ignored_line_match(const char *pat, const char *path, const char *base, int isdir) {
    if (!*pat || *pat == '#') return 0;
    while (*pat == ' ' || *pat == '\t') pat++;
    if (!*pat || *pat == '#') return 0;
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof tmp, "%s", pat);
    size_t n = strlen(tmp);
    while (n && (tmp[n-1] == '\n' || tmp[n-1] == '\r' || tmp[n-1] == ' ' || tmp[n-1] == '\t')) tmp[--n] = 0;
    if (!n) return 0;
    int neg = tmp[0] == '!';
    char *g = tmp + neg;
    n = strlen(g);
    int dironly = n && g[n-1] == '/';
    if (dironly) g[--n] = 0;
    if (dironly && !isdir) return 0;
    int matched;
    if (strchr(g, '/')) matched = fnmatch(g, path, 0) == 0;
    else matched = fnmatch(g, base, 0) == 0;
    return matched ? (neg ? -1 : 1) : 0;
}

static int ignored_by_file(const char *ignore_path, const char *path, int isdir) {
    FILE *f = fopen(ignore_path, "rb");
    if (!f) return 0;
    const char *base = strrchr(path, '/'); base = base ? base + 1 : path;
    char *line = NULL; size_t cap = 0; ssize_t n;
    int ignored = 0;
    while ((n = getline(&line, &cap, f)) >= 0) {
        (void)n;
        int m = ignored_line_match(line, path, base, isdir);
        if (m > 0) ignored = 1;
        else if (m < 0) ignored = 0;
    }
    free(line);
    fclose(f);
    return ignored;
}

static int ignored_by_ignores(App *a, const char *path, int isdir) {
    if (a->o.unrestricted >= 1) return 0;
    for (size_t i=0;i<a->o.ignore_files.n;i++) {
        if (ignored_by_file(a->o.ignore_files.v[i], path, isdir)) return 1;
    }
    char dir[PATH_MAX];
    snprintf(dir, sizeof dir, "%s", path);
    char *slash = strrchr(dir, '/');
    if (slash) *slash = 0;
    else strcpy(dir, ".");
    while (1) {
        char ip[PATH_MAX];
        snprintf(ip, sizeof ip, "%s/.rgignore", dir);
        if (ignored_by_file(ip, path, isdir)) return 1;
        snprintf(ip, sizeof ip, "%s/.ignore", dir);
        if (ignored_by_file(ip, path, isdir)) return 1;
        snprintf(ip, sizeof ip, "%s/.gitignore", dir);
        if (ignored_by_file(ip, path, isdir)) return 1;
        if (!strcmp(dir, ".") || !strcmp(dir, "/")) break;
        slash = strrchr(dir, '/');
        if (slash) *slash = 0;
        else strcpy(dir, ".");
    }
    return 0;
}

static int is_hidden_path(const char *path) {
    const char *p = path;
    while (*p) {
        while (*p == '/') p++;
        if (*p == '.') return 1;
        while (*p && *p != '/') p++;
    }
    return 0;
}

static int binary_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    unsigned char buf[4096];
    size_t n = fread(buf, 1, sizeof buf, f);
    fclose(f);
    for (size_t i=0;i<n;i++) if (buf[i] == 0) return 1;
    return 0;
}

static void print_path(App *a, const char *path) {
    if (a->o.path_separator && a->o.path_separator != '/') {
        for (const char *p=path; *p; p++) putchar(*p=='/' ? a->o.path_separator : *p);
    } else fputs(path, stdout);
}

static int match_line(App *a, const char *line, regmatch_t *first, int *match_count) {
    int found = 0; *match_count = 0; first->rm_so = first->rm_eo = -1;
    for (size_t i=0;i<a->o.pats.n;i++) {
        regmatch_t m;
        int ok;
        if (a->o.fixed) ok = literal_find(line, a->o.pats.v[i], a->o.ignore_case, a->o.word, a->o.line_regexp, &m, 0);
        else {
            ok = regexec(&a->res[i].re, line, 1, &m, 0) == 0;
            if (ok && a->o.word) {
                if (m.rm_so > 0 && is_wordc((unsigned char)line[m.rm_so-1])) ok = 0;
                if (line[m.rm_eo] && is_wordc((unsigned char)line[m.rm_eo])) ok = 0;
            }
        }
        if (ok) {
            found = 1;
            if (first->rm_so < 0 || m.rm_so < first->rm_so) *first = m;
            (*match_count)++;
        }
    }
    if (a->o.invert) found = !found;
    return found;
}

static void emit_prefix(App *a, const char *path, long lno, long col, int show_file) {
    if (show_file) { print_path(a, path); putchar(':'); }
    if ((a->o.line_number || a->o.vimgrep) && !a->o.no_line_number) printf("%ld:", lno);
    if (a->o.vimgrep) printf("%ld:", col);
}

static void print_escaped_json(const char *s) {
    putchar('"');
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') { putchar('\\'); putchar(c); }
        else if (c == '\n') fputs("\\n", stdout);
        else if (c == '\r') fputs("\\r", stdout);
        else if (c == '\t') fputs("\\t", stdout);
        else if (c < 32) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

static void search_stream(App *a, FILE *f, const char *path, int show_file) {
    char *line = NULL; size_t cap = 0; ssize_t n;
    long lno = 0, file_lines = 0, file_matches = 0;
    int after_left = 0, had = 0;
    a->files_searched++;
    while ((n = getline(&line, &cap, f)) >= 0) {
        (void)n; lno++;
        regmatch_t m; int mc = 0;
        int ok = match_line(a, line, &m, &mc);
        if (ok) {
            had = 1; file_lines++; file_matches += mc ? mc : 1; a->matched_lines++;
            if (a->o.quiet) { a->any_match = 1; free(line); return; }
            if (a->o.max_count >= 0 && file_lines > a->o.max_count) break;
            if (a->o.files_with_matches || a->o.files_without_match || a->o.count || a->o.count_matches) continue;
            if (a->o.json) {
                printf("{\"type\":\"match\",\"data\":{\"path\":{\"text\":");
                print_escaped_json(path);
                printf("},\"lines\":{\"text\":");
                print_escaped_json(line);
                printf("},\"line_number\":%ld,\"absolute_offset\":0,\"submatches\":[{\"match\":{\"text\":", lno);
                if (m.rm_so >= 0) {
                    char *tmp = strndup(line + m.rm_so, (size_t)(m.rm_eo - m.rm_so));
                    print_escaped_json(tmp); free(tmp);
                } else print_escaped_json("");
                printf("},\"start\":%ld,\"end\":%ld}]}}\n", (long)m.rm_so, (long)m.rm_eo);
                continue;
            }
            if (a->o.only_matching && !a->o.invert) {
                for (size_t pi=0; pi<a->o.pats.n; pi++) {
                    size_t st = 0; regmatch_t om;
                    while (1) {
                        int fok;
                        if (a->o.fixed) fok = literal_find(line, a->o.pats.v[pi], a->o.ignore_case, a->o.word, a->o.line_regexp, &om, st);
                        else fok = regexec(&a->res[pi].re, line + st, 1, &om, 0) == 0;
                        if (!fok) break;
                        if (!a->o.fixed) { om.rm_so += st; om.rm_eo += st; }
                        if (om.rm_eo <= om.rm_so) { st++; if (st > strlen(line)) break; continue; }
                        emit_prefix(a, path, lno, om.rm_so + 1, show_file);
                        fwrite(line + om.rm_so, 1, (size_t)(om.rm_eo - om.rm_so), stdout);
                        putchar('\n');
                        st = om.rm_eo;
                    }
                }
            } else if (a->o.replace && !a->o.invert && m.rm_so >= 0) {
                emit_prefix(a, path, lno, m.rm_so + 1, show_file);
                fwrite(line, 1, (size_t)m.rm_so, stdout);
                fputs(a->o.replace, stdout);
                fputs(line + m.rm_eo, stdout);
                if (line[strlen(line)-1] != '\n') putchar('\n');
            } else {
                emit_prefix(a, path, lno, m.rm_so >= 0 ? m.rm_so + 1 : 1, show_file);
                char *out = line;
                if (a->o.trim) while (*out == ' ' || *out == '\t') out++;
                fputs(out, stdout);
                if (out[0] && out[strlen(out)-1] != '\n') putchar('\n');
            }
            after_left = a->o.after >= 0 ? a->o.after : 0;
        } else if (after_left > 0 && !a->o.count && !a->o.count_matches && !a->o.files_with_matches && !a->o.files_without_match && !a->o.only_matching) {
            emit_prefix(a, path, lno, 1, show_file);
            fputs(line, stdout);
            if (line[strlen(line)-1] != '\n') putchar('\n');
            after_left--;
        }
    }
    if (had) { a->any_match = 1; a->files_with_matches++; }
    if (!a->o.quiet) {
        if (a->o.files_with_matches && had) { print_path(a, path); putchar(a->o.null_sep ? '\0' : '\n'); }
        if (a->o.files_without_match && !had) { print_path(a, path); putchar(a->o.null_sep ? '\0' : '\n'); }
        if (a->o.count || a->o.count_matches) {
            long val = a->o.count_matches ? file_matches : file_lines;
            if (val || a->o.include_zero) {
                if (show_file) { print_path(a, path); putchar(':'); }
                printf("%ld\n", val);
            }
        }
    }
    free(line);
}

static void search_file(App *a, const char *path, int show_file) {
    if (!type_allowed(&a->o, path) || !glob_allowed(&a->o, path)) return;
    if (!a->o.text && a->o.unrestricted < 3 && binary_file(path)) return;
    if (a->o.files) { print_path(a, path); putchar(a->o.null_sep ? '\0' : '\n'); return; }
    FILE *f = fopen(path, "rb");
    if (!f) {
        if (!a->o.quiet) fprintf(stderr, "rg: %s: %s (os error %d)\n", path, strerror(errno), errno);
        a->had_error = 1; return;
    }
    search_stream(a, f, path, show_file);
    fclose(f);
}

typedef struct { char **v; size_t n, cap; } PathList;
static void path_push(PathList *pl, const char *s) {
    if (pl->n == pl->cap) { pl->cap = pl->cap ? pl->cap*2 : 64; pl->v = realloc(pl->v, pl->cap*sizeof(char*)); if(!pl->v) exit(2); }
    pl->v[pl->n++] = strdup(s);
}
static int cmpstr(const void *a, const void *b) { return strcmp(*(char * const *)a, *(char * const *)b); }
static int rcmpstr(const void *a, const void *b) { return -cmpstr(a,b); }

static void collect(App *a, const char *path, int depth, PathList *pl) {
    struct stat st;
    int rc = a->o.follow ? stat(path, &st) : lstat(path, &st);
    if (rc != 0) { a->had_error = 1; return; }
    const char *base = strrchr(path, '/'); base = base ? base+1 : path;
    if (depth > 0 && !a->o.hidden && a->o.unrestricted < 2 && base[0] == '.') return;
    if (S_ISDIR(st.st_mode)) {
        if (depth > 0 && ignored_by_ignores(a, path, 1)) return;
        if (depth > 0 && !a->o.unrestricted && (!strcmp(base, ".git") || !strcmp(base, ".hg") || !strcmp(base, ".svn"))) return;
        if (a->o.max_depth >= 0 && depth >= a->o.max_depth) return;
        DIR *d = opendir(path);
        if (!d) { a->had_error = 1; return; }
        struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
            char *child; asprintf(&child, "%s/%s", path, de->d_name);
            collect(a, child, depth+1, pl);
            free(child);
        }
        closedir(d);
    } else if (S_ISREG(st.st_mode) || (a->o.follow && S_ISLNK(st.st_mode))) {
        if (ignored_by_ignores(a, path, 0)) return;
        if (!a->o.hidden && a->o.unrestricted < 2 && is_hidden_path(path)) return;
        path_push(pl, path);
    }
}

static void read_pattern_file(App *a, const char *path) {
    FILE *f = !strcmp(path, "-") ? stdin : fopen(path, "rb");
    if (!f) { fprintf(stderr, "rg: %s: %s (os error %d)\n", path, strerror(errno), errno); exit(2); }
    char *line = NULL; size_t cap = 0; ssize_t n;
    while ((n = getline(&line, &cap, f)) >= 0) {
        while (n > 0 && (line[n-1] == '\n' || line[n-1] == '\r')) line[--n] = 0;
        push(&a->o.pats, line);
    }
    free(line); if (f != stdin) fclose(f);
}

static void compile_patterns(App *a) {
    if (a->o.smart_case && !a->o.ignore_case) {
        int upper = 0;
        for (size_t i=0;i<a->o.pats.n;i++) if (has_upper(a->o.pats.v[i])) upper = 1;
        if (!upper) a->o.ignore_case = 1;
    }
    if (a->o.line_regexp && !a->o.fixed) {
        for (size_t i=0;i<a->o.pats.n;i++) {
            char *p; asprintf(&p, "^(%s)$", a->o.pats.v[i]);
            free(a->o.pats.v[i]); a->o.pats.v[i] = p;
        }
    }
    a->res = calloc(a->o.pats.n, sizeof(Pattern));
    a->ren = a->o.pats.n;
    if (!a->o.fixed) {
        for (size_t i=0;i<a->o.pats.n;i++) {
            if (!strncmp(a->o.pats.v[i], "(?i)", 4)) {
                a->o.ignore_case = 1;
                memmove(a->o.pats.v[i], a->o.pats.v[i] + 4, strlen(a->o.pats.v[i] + 4) + 1);
            }
            char *src = a->o.pats.v[i], *dst = calloc(strlen(src) * 12 + 8, 1);
            if (!dst) exit(2);
            for (char *p = src, *q = dst; *p; p++) {
                if (*p == '\\' && p[1] == 'd') { strcpy(q, "[[:digit:]]"); q += strlen(q); p++; }
                else if (*p == '\\' && p[1] == 'D') { strcpy(q, "[^[:digit:]]"); q += strlen(q); p++; }
                else if (*p == '\\' && p[1] == 's') { strcpy(q, "[[:space:]]"); q += strlen(q); p++; }
                else if (*p == '\\' && p[1] == 'S') { strcpy(q, "[^[:space:]]"); q += strlen(q); p++; }
                else if (*p == '\\' && p[1] == 'w') { strcpy(q, "[_[:alnum:]]"); q += strlen(q); p++; }
                else if (*p == '\\' && p[1] == 'W') { strcpy(q, "[^_[:alnum:]]"); q += strlen(q); p++; }
                else *q++ = *p;
            }
            free(a->o.pats.v[i]); a->o.pats.v[i] = dst;
            int flags = REG_EXTENDED | REG_NEWLINE;
            if (a->o.ignore_case) flags |= REG_ICASE;
            int err = regcomp(&a->res[i].re, a->o.pats.v[i], flags);
            if (err) {
                char buf[512]; regerror(err, &a->res[i].re, buf, sizeof buf);
                fprintf(stderr, "rg: regex parse error:\n    %s\n    %s\nerror: %s\n", a->o.pats.v[i], "^", buf);
                exit(2);
            }
            a->res[i].ok = 1; a->res[i].pat = a->o.pats.v[i];
        }
    }
}

static int arg_eq(const char *a, const char *b) { return strcmp(a,b)==0; }
static const char *value_arg(int *i, int argc, char **argv, const char *cur, const char *name) {
    char *eq = strchr(cur, '=');
    if (eq) return eq + 1;
    if (*i + 1 >= argc) { fprintf(stderr, "rg: %s requires a value\n", name); exit(2); }
    return argv[++*i];
}

static void parse_args(App *a, int argc, char **argv) {
    a->o.before = a->o.after = a->o.context = -1;
    a->o.max_count = a->o.max_depth = -1;
    a->o.path_separator = '/';
    int explicit_pat = 0, end_opts = 0;
    for (int i=1;i<argc;i++) {
        char *s = argv[i];
        if (!end_opts && !strcmp(s, "--")) { end_opts = 1; continue; }
        if (!end_opts && s[0] == '-' && s[1]) {
            if (arg_eq(s,"--help")) { fputs(short_help, stdout); exit(0); }
            if (arg_eq(s,"-h")) { fputs(short_help, stdout); exit(0); }
            if (arg_eq(s,"--version") || arg_eq(s,"-V")) { version(); exit(0); }
            if (arg_eq(s,"--type-list")) { a->o.type_list=1; continue; }
            if (arg_eq(s,"--files")) { a->o.files=1; continue; }
            if (arg_eq(s,"--json")) { a->o.json=1; continue; }
            if (arg_eq(s,"--stats")) { a->o.stats=1; continue; }
            if (arg_eq(s,"--pcre2-version")) { fprintf(stderr, "PCRE2 is not available in this build of ripgrep.\n"); exit(2); }
            if (!strncmp(s,"--generate",10)) {
                const char *kind = value_arg(&i, argc, argv, s, "--generate");
                if (!strcmp(kind, "man")) {
                    puts(".TH RG 1\n.SH NAME\nrg \\- recursively search for a regex pattern\n.SH SYNOPSIS\nrg [OPTIONS] PATTERN [PATH ...]");
                } else if (strstr(kind, "complete")) {
                    puts("# completion script generation is provided by ripgrep");
                }
                exit(0);
            }
            if (arg_eq(s,"--pcre2") || arg_eq(s,"-P") || !strncmp(s,"--engine=pcre2",14)) { fprintf(stderr, "rg: PCRE2 is not available in this build of ripgrep\n"); exit(2); }
            if (arg_eq(s,"--fixed-strings")) { a->o.fixed=1; continue; }
            if (arg_eq(s,"--ignore-case")) { a->o.ignore_case=1; continue; }
            if (arg_eq(s,"--case-sensitive")) { a->o.ignore_case=0; a->o.smart_case=0; continue; }
            if (arg_eq(s,"--smart-case")) { a->o.smart_case=1; continue; }
            if (arg_eq(s,"--invert-match")) { a->o.invert=1; continue; }
            if (arg_eq(s,"--word-regexp")) { a->o.word=1; continue; }
            if (arg_eq(s,"--line-regexp")) { a->o.line_regexp=1; continue; }
            if (arg_eq(s,"--line-number")) { a->o.line_number=1; a->o.no_line_number=0; continue; }
            if (arg_eq(s,"--no-line-number")) { a->o.no_line_number=1; continue; }
            if (arg_eq(s,"--with-filename")) { a->o.with_filename=1; a->o.no_filename=0; continue; }
            if (arg_eq(s,"--no-filename")) { a->o.no_filename=1; continue; }
            if (arg_eq(s,"--count")) { a->o.count=1; continue; }
            if (arg_eq(s,"--count-matches")) { a->o.count_matches=1; continue; }
            if (arg_eq(s,"--files-with-matches")) { a->o.files_with_matches=1; continue; }
            if (arg_eq(s,"--files-without-match")) { a->o.files_without_match=1; continue; }
            if (arg_eq(s,"--only-matching")) { a->o.only_matching=1; continue; }
            if (arg_eq(s,"--quiet")) { a->o.quiet=1; continue; }
            if (arg_eq(s,"--hidden")) { a->o.hidden=1; continue; }
            if (arg_eq(s,"--no-ignore")) { a->o.unrestricted = a->o.unrestricted < 1 ? 1 : a->o.unrestricted; continue; }
            if (arg_eq(s,"--text")) { a->o.text=1; continue; }
            if (arg_eq(s,"--follow")) { a->o.follow=1; continue; }
            if (arg_eq(s,"--null")) { a->o.null_sep=1; continue; }
            if (arg_eq(s,"--trim")) { a->o.trim=1; continue; }
            if (arg_eq(s,"--vimgrep")) { a->o.vimgrep=1; a->o.line_number=1; a->o.with_filename=1; continue; }
            if (arg_eq(s,"--pretty")) { a->o.pretty=1; a->o.color_always=1; a->o.line_number=1; continue; }
            if (arg_eq(s,"--heading")) { a->o.heading=1; continue; }
            if (arg_eq(s,"--no-heading")) { a->o.no_heading=1; continue; }
            if (arg_eq(s,"--include-zero")) { a->o.include_zero=1; continue; }
            if (arg_eq(s,"--sort-files") || !strncmp(s,"--sort=path",11)) { a->o.sort_path=1; continue; }
            if (!strncmp(s,"--sortr=path",12)) { a->o.sort_path=1; a->o.sort_reverse=1; continue; }
            if (!strncmp(s,"--color=",8)) { if(!strcmp(s+8,"always")) a->o.color_always=1; if(!strcmp(s+8,"never")) a->o.color_never=1; continue; }
            if (!strncmp(s,"--regexp",8)) { push(&a->o.pats, value_arg(&i, argc, argv, s, "--regexp")); explicit_pat=1; continue; }
            if (!strncmp(s,"--file",6)) { read_pattern_file(a, value_arg(&i, argc, argv, s, "--file")); explicit_pat=1; continue; }
            if (!strncmp(s,"--glob",6)) { push(&a->o.globs, value_arg(&i, argc, argv, s, "--glob")); continue; }
            if (!strncmp(s,"--iglob",7)) { push(&a->o.iglobs, value_arg(&i, argc, argv, s, "--iglob")); continue; }
            if (!strncmp(s,"--ignore-file",13)) { push(&a->o.ignore_files, value_arg(&i, argc, argv, s, "--ignore-file")); continue; }
            if (!strncmp(s,"--type=",7)) { push(&a->o.types, s+7); continue; }
            if (!strncmp(s,"--type-not=",11)) { push(&a->o.not_types, s+11); continue; }
            if (!strncmp(s,"--max-depth",11)) { a->o.max_depth=atoi(value_arg(&i,argc,argv,s,"--max-depth")); continue; }
            if (!strncmp(s,"--max-count",11)) { a->o.max_count=atoi(value_arg(&i,argc,argv,s,"--max-count")); continue; }
            if (!strncmp(s,"--after-context",15)) { a->o.after=atoi(value_arg(&i,argc,argv,s,"--after-context")); continue; }
            if (!strncmp(s,"--before-context",16)) { a->o.before=atoi(value_arg(&i,argc,argv,s,"--before-context")); continue; }
            if (!strncmp(s,"--context",9)) { a->o.after=a->o.before=atoi(value_arg(&i,argc,argv,s,"--context")); continue; }
            if (!strncmp(s,"--replace",9)) { a->o.replace=strdup(value_arg(&i,argc,argv,s,"--replace")); continue; }
            if (!strncmp(s,"--path-separator",16)) { const char *v=value_arg(&i,argc,argv,s,"--path-separator"); a->o.path_separator = *v ? *v : '/'; continue; }
            if (!strncmp(s,"--max-columns",13) || !strncmp(s,"--max-filesize",14) ||
                !strncmp(s,"--threads",9) || !strncmp(s,"--encoding",10) ||
                !strncmp(s,"--pre=",6) || !strcmp(s,"--pre") ||
                !strncmp(s,"--pre-glob",10) || !strncmp(s,"--colors",8) ||
                !strncmp(s,"--dfa-size-limit",16) || !strncmp(s,"--regex-size-limit",18) ||
                !strncmp(s,"--type-add",10) || !strncmp(s,"--type-clear",12) ||
                !strncmp(s,"--sort=",7) || !strncmp(s,"--sortr=",8)) {
                if (!strchr(s, '=') && i + 1 < argc) i++;
                continue;
            }
            if (s[0]=='-' && s[1] && s[1] != '-') {
                for (int k=1; s[k]; k++) {
                    char c=s[k];
                    if (c=='e'||c=='f'||c=='g'||c=='t'||c=='T'||c=='m'||c=='d'||c=='A'||c=='B'||c=='C'||c=='r'||c=='M'||c=='j') {
                        const char *val = s[k+1] ? &s[k+1] : (i+1<argc ? argv[++i] : "");
                        if (!*val) { fprintf(stderr, "rg: -%c requires a value\n", c); exit(2); }
                        if (c=='e') { push(&a->o.pats,val); explicit_pat=1; }
                        else if (c=='f') { read_pattern_file(a,val); explicit_pat=1; }
                        else if (c=='g') push(&a->o.globs,val);
                        else if (c=='t') push(&a->o.types,val);
                        else if (c=='T') push(&a->o.not_types,val);
                        else if (c=='m') a->o.max_count=atoi(val);
                        else if (c=='d') a->o.max_depth=atoi(val);
                        else if (c=='A') a->o.after=atoi(val);
                        else if (c=='B') a->o.before=atoi(val);
                        else if (c=='C') a->o.after=a->o.before=atoi(val);
                        else if (c=='r') a->o.replace=strdup(val);
                        else if (c=='M' || c=='j') { /* accepted but not implemented */ }
                        break;
                    } else if (c=='F') a->o.fixed=1;
                    else if (c=='i') a->o.ignore_case=1;
                    else if (c=='s') { a->o.ignore_case=0; a->o.smart_case=0; }
                    else if (c=='S') a->o.smart_case=1;
                    else if (c=='v') a->o.invert=1;
                    else if (c=='w') a->o.word=1;
                    else if (c=='x') a->o.line_regexp=1;
                    else if (c=='n') a->o.line_number=1;
                    else if (c=='N') a->o.no_line_number=1;
                    else if (c=='H') a->o.with_filename=1;
                    else if (c=='I') a->o.no_filename=1;
                    else if (c=='c') a->o.count=1;
                    else if (c=='l') a->o.files_with_matches=1;
                    else if (c=='o') a->o.only_matching=1;
                    else if (c=='q') a->o.quiet=1;
                    else if (c=='.') a->o.hidden=1;
                    else if (c=='u') a->o.unrestricted++;
                    else if (c=='a') a->o.text=1;
                    else if (c=='L') a->o.follow=1;
                    else if (c=='0') a->o.null_sep=1;
                    else if (c=='p') { a->o.pretty=1; a->o.line_number=1; a->o.color_always=1; }
                    else if (c=='V') { version(); exit(0); }
                    else if (c=='h') { fputs(short_help, stdout); exit(0); }
                    else { /* accept unimplemented flags silently */ }
                }
                continue;
            }
            continue;
        }
        if (!explicit_pat && !a->o.files && !a->o.type_list && a->o.pats.n == 0) { push(&a->o.pats, s); explicit_pat=1; }
        else push(&a->o.paths, s);
    }
    if (a->o.type_list) { type_list(); exit(0); }
    if (!a->o.files && a->o.pats.n == 0) {
        fprintf(stderr, "rg: ripgrep requires at least one pattern to execute a search\n");
        exit(2);
    }
    if (a->o.paths.n == 0 && !a->o.files) {
        struct stat st;
        if (!isatty(STDIN_FILENO) && fstat(STDIN_FILENO, &st)==0 && !S_ISCHR(st.st_mode)) {
            /* stdin is searched later */
        } else push(&a->o.paths, ".");
    }
    if (a->o.paths.n == 0 && a->o.files) push(&a->o.paths, ".");
}

int main(int argc, char **argv) {
    App a; memset(&a, 0, sizeof a);
    parse_args(&a, argc, argv);
    compile_patterns(&a);
    if (!a.o.files && a.o.paths.n == 0) {
        search_stream(&a, stdin, "<stdin>", a.o.with_filename && !a.o.no_filename);
    } else {
        PathList pl = {0};
        for (size_t i=0;i<a.o.paths.n;i++) collect(&a, a.o.paths.v[i], 0, &pl);
        if (a.o.sort_path) qsort(pl.v, pl.n, sizeof(char*), a.o.sort_reverse ? rcmpstr : cmpstr);
        int show_file = 0;
        if (a.o.with_filename) show_file = 1;
        else if (a.o.no_filename) show_file = 0;
        else show_file = (pl.n > 1 || (a.o.paths.n > 0 && (a.o.paths.n > 1 || (a.o.paths.n == 1 && !strcmp(a.o.paths.v[0], ".")))));
        for (size_t i=0;i<pl.n;i++) {
            search_file(&a, pl.v[i], show_file);
            if (a.o.quiet && a.any_match) break;
        }
        for (size_t i=0;i<pl.n;i++) free(pl.v[i]);
        free(pl.v);
    }
    if (a.o.stats && !a.o.quiet) {
        printf("\n%ld matched lines\n%ld files contained matches\n%ld files searched\n", a.matched_lines, a.files_with_matches, a.files_searched);
    }
    for (size_t i=0;i<a.ren;i++) if (a.res[i].ok) regfree(&a.res[i].re);
    return a.had_error ? 2 : (a.any_match || a.o.files ? 0 : 1);
}
