#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct {
    bool ignore_case, smart_case, hidden, follow, word, fixed, multiline;
    bool type_list;
    char **globs; int glob_count;
    char **types; int type_count;
    char **not_types; int not_type_count;
    const char *pattern;
    char **paths; int path_count;
} Opts;

static const char *editors[] = {
    "vim","neovim","nvim","nano","code","vscode","code-insiders","emacs",
    "emacsclient","hx","helix","subl","sublime-text","micro","intellij",
    "goland","pycharm","less","fresh",NULL
};
static const char *viewers[] = {"none","vertical","horizontal",NULL};
static const char *sorts[] = {"path","modified","created","accessed",NULL};

static void help(void) {
    puts("Interactive Grep\n");
    puts("Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n");
    puts("Arguments:");
    puts("  <PATTERN>   Regular expression used for searching");
    puts("  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory\n");
    puts("Options:");
    puts("      --editor <EDITOR>");
    puts("          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]");
    puts("      --custom-command <CUSTOM_COMMAND>");
    puts("          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]");
    puts("      --theme <THEME>");
    puts("          UI color theme [default: dark] [possible values: light, dark]");
    puts("  -i, --ignore-case");
    puts("          Searches case insensitively");
    puts("  -S, --smart-case");
    puts("          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise");
    puts("  -., --hidden");
    puts("          Search hidden files and directories. By default, hidden files and directories are skipped");
    puts("  -L, --follow");
    puts("          Follow symbolic links while traversing directories");
    puts("  -w, --word-regexp");
    puts("          Only show matches surrounded by word boundaries");
    puts("  -F, --fixed-strings");
    puts("          Exact matches with no regex. Useful when searching for a string full of delimiters");
    puts("  -U, --multiline");
    puts("          Search with pattern contains newline character ('\\n')");
    puts("  -g, --glob <GLOB>");
    puts("          Include files and directories for searching that match the given glob. Multiple globs may be provided");
    puts("      --type-list");
    puts("          Show all supported file types and their corresponding globs");
    puts("  -t, --type <TYPE_MATCHING>");
    puts("          Only search files matching TYPE. Multiple types may be provided");
    puts("  -T, --type-not <TYPE_NOT>");
    puts("          Do not search files matching TYPE-NOT. Multiple types-not may be provided");
    puts("      --context-viewer <CONTEXT_VIEWER>");
    puts("          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]");
    puts("      --sort <SORT_BY>");
    puts("          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]");
    puts("      --sortr <SORT_BY_REVERSE>");
    puts("          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]");
    puts("  -h, --help");
    puts("          Print help");
    puts("  -V, --version");
    puts("          Print version");
}

static bool in_list(const char *s, const char **xs) {
    for (int i = 0; xs[i]; i++) if (strcmp(s, xs[i]) == 0) return true;
    return false;
}

static void invalid_value(const char *flag, const char *meta, const char *val, const char *possible) {
    fprintf(stderr, "error: invalid value '%s' for '%s <%s>'\n", val, flag, meta);
    fprintf(stderr, "  [possible values: %s]\n\nFor more information, try '--help'.\n", possible);
    exit(2);
}

static void need_value(const char *flag) {
    fprintf(stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", flag);
    exit(2);
}

static int count_token(const char *s, const char *tok) {
    int n = 0; size_t len = strlen(tok);
    for (const char *p = s; (p = strstr(p, tok)); p += len) n++;
    return n;
}

static void validate_custom(const char *cmd) {
    int f = count_token(cmd, "{file_name}");
    int l = count_token(cmd, "{line_number}");
    if (f != 1 || l != 1) {
        fprintf(stderr, "Error: Incorrect editor command: '%s'\n\nCaused by:\n", cmd);
        if (f != 1) fprintf(stderr, "    Expected one occurrence of '{file_name}'.\n");
        else fprintf(stderr, "    Expected one occurrence of '{line_number}'.\n");
        exit(1);
    }
}

static void add_str(char ***arr, int *n, char *s) {
    *arr = realloc(*arr, sizeof(char*) * (*n + 1));
    if (!*arr) exit(1);
    (*arr)[(*n)++] = s;
}

static void show_types(void) {
    FILE *f = fopen("type-list.txt", "r");
    if (!f) f = fopen("./type-list.txt", "r");
    if (f) {
        char buf[4096];
        while (fgets(buf, sizeof buf, f)) fputs(buf, stdout);
        fclose(f);
    } else {
        puts("rust: *.rs\nc: *.[chH], *.[chH].in, *.cats\npython: *.py, *.pyi\nmarkdown: *.markdown, *.md, *.mdown, *.mdwn, *.mdx, *.mkd, *.mkdn");
    }
}

static bool hidden_name(const char *path) {
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    return base[0] == '.' && strcmp(base, ".") && strcmp(base, "..");
}

static const char *ext(const char *p) {
    const char *b = strrchr(p, '/'); b = b ? b + 1 : p;
    const char *d = strrchr(b, '.');
    return d ? d + 1 : "";
}

static bool type_match(const char *path, const char *type) {
    const char *e = ext(path);
    if (!strcmp(type,"c")) return !strcmp(e,"c")||!strcmp(e,"h")||!strcmp(e,"H");
    if (!strcmp(type,"cpp")) return !strcmp(e,"cpp")||!strcmp(e,"cc")||!strcmp(e,"cxx")||!strcmp(e,"hpp")||!strcmp(e,"hh")||!strcmp(e,"hxx")||!strcmp(e,"C")||!strcmp(e,"H");
    if (!strcmp(type,"rust")) return !strcmp(e,"rs");
    if (!strcmp(type,"python")||!strcmp(type,"py")) return !strcmp(e,"py")||!strcmp(e,"pyi");
    if (!strcmp(type,"markdown")||!strcmp(type,"md")) return !strcmp(e,"md")||!strcmp(e,"markdown")||!strcmp(e,"mdown")||!strcmp(e,"mdwn")||!strcmp(e,"mdx")||!strcmp(e,"mkd")||!strcmp(e,"mkdn");
    if (!strcmp(type,"txt")) return !strcmp(e,"txt");
    if (!strcmp(type,"json")) return !strcmp(e,"json");
    if (!strcmp(type,"toml")) return !strcmp(e,"toml");
    if (!strcmp(type,"yaml")) return !strcmp(e,"yaml")||!strcmp(e,"yml");
    if (!strcmp(type,"go")) return !strcmp(e,"go");
    if (!strcmp(type,"js")) return !strcmp(e,"js")||!strcmp(e,"jsx")||!strcmp(e,"mjs")||!strcmp(e,"cjs")||!strcmp(e,"vue");
    if (!strcmp(type,"ts")||!strcmp(type,"typescript")) return !strcmp(e,"ts")||!strcmp(e,"tsx")||!strcmp(e,"mts")||!strcmp(e,"cts");
    if (!strcmp(type,"html")) return !strcmp(e,"html")||!strcmp(e,"htm")||!strcmp(e,"ejs");
    if (!strcmp(type,"css")) return !strcmp(e,"css")||!strcmp(e,"scss");
    if (!strcmp(type,"sh")) return !strcmp(e,"sh")||!strcmp(e,"bash")||!strcmp(e,"zsh")||!strcmp(e,"ksh")||!strcmp(e,"csh");
    return false;
}

static bool wanted_file(const char *path, const Opts *o) {
    if (!o->hidden && hidden_name(path)) return false;
    if (o->glob_count) {
        bool ok = false;
        const char *base = strrchr(path, '/'); base = base ? base + 1 : path;
        for (int i = 0; i < o->glob_count; i++)
            if (fnmatch(o->globs[i], path, 0) == 0 || fnmatch(o->globs[i], base, 0) == 0) ok = true;
        if (!ok) return false;
    }
    if (o->type_count) {
        bool ok = false;
        for (int i = 0; i < o->type_count; i++) if (type_match(path, o->types[i])) ok = true;
        if (!ok) return false;
    }
    for (int i = 0; i < o->not_type_count; i++) if (type_match(path, o->not_types[i])) return false;
    return true;
}

static bool word_ok(const char *line, size_t pos, size_t len) {
    unsigned char before = pos ? (unsigned char)line[pos-1] : 0;
    unsigned char after = (unsigned char)line[pos+len];
    bool b = pos == 0 || !(isalnum(before) || before == '_');
    bool a = after == 0 || after == '\n' || !(isalnum(after) || after == '_');
    return b && a;
}

static char *lowerdup(const char *s) {
    char *r = strdup(s);
    if (!r) exit(1);
    for (char *p = r; *p; p++) *p = (char)tolower((unsigned char)*p);
    return r;
}

static bool all_lower_pat(const char *s) {
    for (; *s; s++) if (isalpha((unsigned char)*s) && isupper((unsigned char)*s)) return false;
    return true;
}

static int search_file(const char *path, const Opts *o, regex_t *rx, bool use_rx, bool icase) {
    FILE *f = fopen(path, "r");
    if (!f) return 0;
    char *line = NULL; size_t cap = 0; ssize_t n; int ln = 0, hits = 0;
    char *patlow = NULL;
    if (o->fixed && icase) patlow = lowerdup(o->pattern);
    while ((n = getline(&line, &cap, f)) >= 0) {
        (void)n; ln++;
        bool match = false;
        if (o->fixed) {
            char *hay = icase ? lowerdup(line) : line;
            char *p = strstr(hay, patlow ? patlow : o->pattern);
            while (p) {
                size_t pos = (size_t)(p - hay);
                if (!o->word || word_ok(line, pos, strlen(o->pattern))) { match = true; break; }
                p = strstr(p + 1, patlow ? patlow : o->pattern);
            }
            if (icase) free(hay);
        } else if (use_rx) {
            regmatch_t m;
            const char *start = line;
            size_t off = 0;
            while (regexec(rx, start, 1, &m, 0) == 0) {
                size_t pos = off + (size_t)m.rm_so, len = (size_t)(m.rm_eo - m.rm_so);
                if (!o->word || word_ok(line, pos, len)) { match = true; break; }
                if (m.rm_eo <= 0) break;
                start += m.rm_eo; off += (size_t)m.rm_eo;
            }
        }
        if (match) {
            printf("%s:%d:%s", path, ln, line);
            if (line[0] && line[strlen(line)-1] != '\n') putchar('\n');
            hits++;
        }
    }
    free(patlow); free(line); fclose(f); return hits;
}

static int walk(const char *path, const Opts *o, regex_t *rx, bool use_rx, bool icase) {
    struct stat st;
    if ((o->follow ? stat(path, &st) : lstat(path, &st)) != 0) return 0;
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path); if (!d) return 0;
        struct dirent *ent; int hits = 0;
        while ((ent = readdir(d))) {
            if (!strcmp(ent->d_name, ".") || !strcmp(ent->d_name, "..")) continue;
            if (!o->hidden && ent->d_name[0] == '.') continue;
            char child[4096];
            snprintf(child, sizeof child, "%s/%s", path, ent->d_name);
            hits += walk(child, o, rx, use_rx, icase);
        }
        closedir(d); return hits;
    }
    if (S_ISREG(st.st_mode) && wanted_file(path, o)) return search_file(path, o, rx, use_rx, icase);
    return 0;
}

static int run_search(const Opts *o) {
    bool icase = o->ignore_case || (o->smart_case && all_lower_pat(o->pattern));
    regex_t rx; bool use_rx = !o->fixed;
    if (use_rx) {
        int flags = REG_EXTENDED | REG_NOSUB | (icase ? REG_ICASE : 0);
        int r = regcomp(&rx, o->pattern, flags);
        if (r) {
            char err[256]; regerror(r, &rx, err, sizeof err);
            fprintf(stderr, "Error: %s\n", err);
            return 1;
        }
    }
    int hits = 0;
    if (o->path_count == 0) hits += walk(".", o, &rx, use_rx, icase);
    else for (int i = 0; i < o->path_count; i++) hits += walk(o->paths[i], o, &rx, use_rx, icase);
    if (use_rx) regfree(&rx);
    return hits ? 0 : 0;
}

int main(int argc, char **argv) {
    Opts o; memset(&o, 0, sizeof o);
    if (argc == 1) {
        fputs("error: the following required arguments were not provided:\n  --type-list\n  <PATTERN>\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n", stderr);
        return 2;
    }
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a,"--help") || !strcmp(a,"-h")) { help(); return 0; }
        else if (!strcmp(a,"--version") || !strcmp(a,"-V")) { puts("igrep 1.3.0"); return 0; }
        else if (!strcmp(a,"--type-list")) o.type_list = true;
        else if (!strcmp(a,"--ignore-case") || !strcmp(a,"-i")) o.ignore_case = true;
        else if (!strcmp(a,"--smart-case") || !strcmp(a,"-S")) o.smart_case = true;
        else if (!strcmp(a,"--hidden") || !strcmp(a,"-.")) o.hidden = true;
        else if (!strcmp(a,"--follow") || !strcmp(a,"-L")) o.follow = true;
        else if (!strcmp(a,"--word-regexp") || !strcmp(a,"-w")) o.word = true;
        else if (!strcmp(a,"--fixed-strings") || !strcmp(a,"-F")) o.fixed = true;
        else if (!strcmp(a,"--multiline") || !strcmp(a,"-U")) o.multiline = true;
        else if (!strcmp(a,"--glob") || !strcmp(a,"-g")) { if (++i >= argc) need_value(a); add_str(&o.globs,&o.glob_count,argv[i]); }
        else if (!strcmp(a,"--type") || !strcmp(a,"-t")) { if (++i >= argc) need_value(a); add_str(&o.types,&o.type_count,argv[i]); }
        else if (!strcmp(a,"--type-not") || !strcmp(a,"-T")) { if (++i >= argc) need_value(a); add_str(&o.not_types,&o.not_type_count,argv[i]); }
        else if (!strcmp(a,"--editor")) { if (++i >= argc) need_value(a); if (!in_list(argv[i], editors)) invalid_value("--editor","EDITOR",argv[i],"vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh"); }
        else if (!strcmp(a,"--theme")) { if (++i >= argc) need_value(a); if (strcmp(argv[i],"light") && strcmp(argv[i],"dark")) invalid_value("--theme","THEME",argv[i],"light, dark"); }
        else if (!strcmp(a,"--context-viewer")) { if (++i >= argc) need_value(a); if (!in_list(argv[i], viewers)) invalid_value("--context-viewer","CONTEXT_VIEWER",argv[i],"none, vertical, horizontal"); }
        else if (!strcmp(a,"--sort")) { if (++i >= argc) need_value(a); if (!in_list(argv[i], sorts)) invalid_value("--sort","SORT_BY",argv[i],"path, modified, created, accessed"); }
        else if (!strcmp(a,"--sortr")) { if (++i >= argc) need_value(a); if (!in_list(argv[i], sorts)) invalid_value("--sortr","SORT_BY_REVERSE",argv[i],"path, modified, created, accessed"); }
        else if (!strcmp(a,"--custom-command")) { if (++i >= argc) need_value(a); validate_custom(argv[i]); }
        else if (a[0] == '-' && strcmp(a, "-")) {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n", a, a, a);
            return 2;
        } else if (!o.pattern) o.pattern = a;
        else add_str(&o.paths, &o.path_count, a);
    }
    const char *envcmd = getenv("IGREP_CUSTOM_EDITOR");
    if (envcmd && *envcmd) validate_custom(envcmd);
    if (o.type_list) { show_types(); return 0; }
    if (!o.pattern) {
        fputs("error: the following required arguments were not provided:\n  --type-list\n  <PATTERN>\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n", stderr);
        return 2;
    }
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fputs("Error: Inappropriate ioctl for device (os error 25)\n", stderr);
        return 1;
    }
    return run_search(&o);
}
