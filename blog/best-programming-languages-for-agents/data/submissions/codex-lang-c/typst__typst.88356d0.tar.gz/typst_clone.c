#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#define VERSION "0.14.2"
#define SHORT_COMMIT "ccc34be7"
#define LONG_COMMIT "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

typedef struct {
    char **items;
    int len;
} Inputs;

static void put_main_help(void) {
    printf("Typst 0.14.2 (ccc34be7)\n\n");
    printf("Usage: executable [OPTIONS] <COMMAND>\n\n");
    printf("Commands:\n");
    printf("  compile      Compiles an input file into a supported output format [aliases:\n               c]\n");
    printf("  watch        Watches an input file and recompiles on changes [aliases: w]\n");
    printf("  init         Initializes a new project from a template\n");
    printf("  eval         Evaluates a piece of Typst code, optionally in the context of a\n               document\n");
    printf("  fonts        Lists all discovered fonts in system and custom font paths\n");
    printf("  completions  Generates shell completion scripts\n");
    printf("  info         Displays debugging information about Typst\n");
    printf("  help         Print this message or the help of the given subcommand(s)\n\n");
    printf("Options:\n");
    printf("      --color <COLOR>  Whether to use color. When set to `auto` if the terminal\n                       to supports it [default: auto] [possible values: auto,\n                       always, never]\n");
    printf("      --cert <CERT>    Path to a custom CA certificate to use when making\n                       network requests [env: TYPST_CERT=]\n");
    printf("  -h, --help           Print help\n");
    printf("  -V, --version        Print version\n\n");
    printf("Resources:\n");
    printf("  Tutorial:                 https://typst.app/docs/tutorial/\n");
    printf("  Reference documentation:  https://typst.app/docs/reference/\n");
    printf("  Templates & Packages:     https://typst.app/universe/\n");
    printf("  Forum for questions:      https://forum.typst.app/\n");
}

static void put_welcome(void) {
    printf("Welcome to Typst, we are glad to have you here! ❤️\n\n");
    printf("If you are new to Typst, start with the tutorial at https://typst.app/docs/tutorial/.\n");
    printf("To get a quick start with your first project, choose a template on https://typst.app/universe/.\n\n");
    printf("Here are the most important commands you will be using:\n\n");
    printf("- Compile a file once: typst compile file.typ\n");
    printf("- Compile a file on every change: typst watch file.typ\n");
    printf("- Set up a project from a template: typst init @preview/<TEMPLATE>\n\n");
    printf("Learn more about these commands by running typst help.\n\n");
    printf("If you have a question, we and our community would be glad to help you out on\n");
    printf("the Typst Forum at https://forum.typst.app/.\n\n");
    printf("Happy Typsting!\n");
}

static void put_compile_help(bool watch) {
    printf("%s\n\n", watch ? "Watches an input file and recompiles on changes" : "Compiles an input file into a supported output format");
    printf("Usage: executable %s [OPTIONS] <INPUT> [OUTPUT]\n\n", watch ? "watch" : "compile");
    printf("Arguments:\n");
    printf("  <INPUT>\n          Path to input Typst file. Use `-` to read input from stdin\n\n");
    printf("  [OUTPUT]\n          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output\n          to stdout.\n\n");
    printf("Options:\n");
    printf("  -f, --format <FORMAT>\n          The format of the output file, inferred from the extension by default\n\n          [possible values: pdf, png, svg, html]\n\n");
    printf("      --root <DIR>\n          Configures the project root (for absolute paths)\n\n          [env: TYPST_ROOT=]\n\n");
    printf("      --input <key=value>\n          Add a string key-value pair visible through `sys.inputs`\n\n");
    printf("      --font-path <DIR>\n          Adds additional directories that are recursively searched for fonts.\n\n          [env: TYPST_FONT_PATHS=]\n\n");
    printf("      --ignore-system-fonts\n          Ensures system fonts won't be searched, unless explicitly included via\n          `--font-path`\n\n          [env: TYPST_IGNORE_SYSTEM_FONTS=]\n\n");
    printf("      --ignore-embedded-fonts\n          Ensures fonts embedded into Typst won't be considered\n\n          [env: TYPST_IGNORE_EMBEDDED_FONTS=]\n\n");
    printf("      --package-path <DIR>\n          Custom path to local packages, defaults to system-dependent location\n\n          [env: TYPST_PACKAGE_PATH=]\n\n");
    printf("      --package-cache-path <DIR>\n          Custom path to package cache, defaults to system-dependent location\n\n          [env: TYPST_PACKAGE_CACHE_PATH=]\n\n");
    printf("      --creation-timestamp <UNIX_TIMESTAMP>\n          The document's creation date formatted as a UNIX timestamp.\n\n          [env: SOURCE_DATE_EPOCH=]\n\n");
    printf("      --pages <PAGES>\n          Which pages to export. When unspecified, all pages are exported.\n\n");
    printf("      --pdf-standard <PDF_STANDARD>\n          One (or multiple comma-separated) PDF standards that Typst will\n          enforce conformance with\n\n");
    printf("      --no-pdf-tags\n          By default, even when not producing a `PDF/UA-1` document, a tagged\n          PDF document is written to provide a baseline of accessibility\n\n");
    printf("      --ppi <PPI>\n          The PPI (pixels per inch) to use for PNG export\n\n          [default: 144]\n\n");
    printf("      --deps <PATH>\n          File path to which a list of current compilation's dependencies will\n          be written. Use `-` to write to stdout\n\n");
    printf("      --deps-format <DEPS_FORMAT>\n          File format to use for dependencies\n\n          [default: json]\n\n          Possible values:\n          - json: Encodes as JSON, failing for non-Unicode paths\n          - zero: Separates paths with NULL bytes and can express all paths\n          - make: Emits in Make format, omitting inexpressible paths\n\n");
    printf("  -j, --jobs <JOBS>\n          Number of parallel jobs spawned during compilation. Defaults to number\n          of CPUs. Setting it to 1 disables parallelism\n\n");
    printf("      --features <FEATURES>\n          Enables in-development features that may be changed or removed at any\n          time\n\n          [env: TYPST_FEATURES=]\n          [possible values: html, a11y-extras]\n\n");
    printf("      --diagnostic-format <DIAGNOSTIC_FORMAT>\n          The format to emit diagnostics in\n\n          [default: human]\n          [possible values: human, short]\n\n");
    printf("      --open [<VIEWER>]\n          Opens the output file with the default viewer or a specific program\n          after compilation. Ignored if output is stdout\n\n");
    printf("      --timings [<OUTPUT_JSON>]\n          Produces performance timings of the compilation process.\n          (experimental)\n\n");
    if (watch) {
        printf("      --no-serve\n          Disables the built-in HTTP server for HTML export\n\n");
        printf("      --no-reload\n          Disables the injected live reload script for HTML export. The HTML\n          that is written to disk isn't affected either way\n\n");
        printf("      --port <PORT>\n          The port where HTML is served.\n\n          Defaults to the first free port in the range 3000-3005.\n\n");
    }
    printf("  -h, --help\n          Print help (see a summary with '-h')\n");
}

static void put_eval_help(void) {
    printf("Evaluates a piece of Typst code, optionally in the context of a document\n\n");
    printf("Usage: executable eval [OPTIONS] <EXPRESSION>\n\n");
    printf("Arguments:\n  <EXPRESSION>\n          The piece of Typst code to evaluate\n\n");
    printf("Options:\n      --in <IN>\n          A file in whose context to evaluate the code. Can be used to\n          introspect the document. Use `-` to read input from stdin\n\n");
    printf("      --target <TARGET>\n          The target to compile for\n\n          [default: paged]\n\n          Possible values:\n          - paged: PDF and image formats\n          - html:  HTML\n\n");
    printf("      --format <FORMAT>\n          The format to serialize in\n\n          [default: json]\n          [possible values: json, yaml]\n\n");
    printf("      --pretty\n          Whether to pretty-print the serialized output.\n\n          Only applies to JSON format.\n\n");
    printf("      --input <key=value>\n          Add a string key-value pair visible through `sys.inputs`\n\n");
    printf("  -h, --help\n          Print help (see a summary with '-h')\n");
}

static void put_fonts_help(void) {
    printf("Lists all discovered fonts in system and custom font paths\n\n");
    printf("Usage: executable fonts [OPTIONS]\n\n");
    printf("Options:\n      --font-path <DIR>\n          Adds additional directories that are recursively searched for fonts.\n\n          [env: TYPST_FONT_PATHS=]\n\n");
    printf("      --ignore-system-fonts\n          Ensures system fonts won't be searched, unless explicitly included via\n          `--font-path`\n\n          [env: TYPST_IGNORE_SYSTEM_FONTS=]\n\n");
    printf("      --ignore-embedded-fonts\n          Ensures fonts embedded into Typst won't be considered\n\n          [env: TYPST_IGNORE_EMBEDDED_FONTS=]\n\n");
    printf("      --variants\n          Also lists style variants of each font family\n\n");
    printf("  -h, --help\n          Print help (see a summary with '-h')\n");
}

static void put_info_help(void) {
    printf("Displays debugging information about Typst\n\nUsage: executable info [OPTIONS]\n\n");
    printf("Options:\n  -f, --format <FORMAT>\n          The format to serialize in, if it should be machine-readable.\n\n          If no format is passed the output is displayed human-readable. Note\n          that human-readable format truncates the build commit hash value.\n\n          [possible values: json, yaml]\n\n");
    printf("      --pretty\n          Whether to pretty-print the serialized output.\n\n          Only applies to JSON format.\n\n");
    printf("  -h, --help\n          Print help (see a summary with '-h')\n");
}

static void put_init_help(void) {
    printf("Initializes a new project from a template\n\nUsage: executable init [OPTIONS] <TEMPLATE> [DIR]\n\n");
    printf("Arguments:\n  <TEMPLATE>\n          The template to use, e.g. `@preview/charged-ieee`.\n\n  [DIR]\n          The project directory, defaults to the template's name\n\n");
    printf("Options:\n      --package-path <DIR>\n          Custom path to local packages, defaults to system-dependent location\n\n          [env: TYPST_PACKAGE_PATH=]\n\n");
    printf("      --package-cache-path <DIR>\n          Custom path to package cache, defaults to system-dependent location\n\n          [env: TYPST_PACKAGE_CACHE_PATH=]\n\n");
    printf("  -h, --help\n          Print help (see a summary with '-h')\n");
}

static void put_completions_help(void) {
    printf("Generates shell completion scripts\n\nUsage: executable completions <SHELL>\n\n");
    printf("Arguments:\n  <SHELL>  The shell to generate completions for [possible values: bash, elvish,\n           fish, powershell, zsh]\n\n");
    printf("Options:\n  -h, --help  Print help\n");
}

static char *read_all(FILE *f) {
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) exit(1);
    int c;
    while ((c = fgetc(f)) != EOF) {
        if (len + 1 >= cap) {
            cap *= 2;
            buf = realloc(buf, cap);
            if (!buf) exit(1);
        }
        buf[len++] = (char)c;
    }
    buf[len] = 0;
    return buf;
}

static char *read_file(const char *path) {
    if (strcmp(path, "-") == 0) return read_all(stdin);
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    char *s = read_all(f);
    fclose(f);
    return s;
}

static char *replace_ext(const char *path, const char *ext) {
    const char *slash = strrchr(path, '/');
    const char *dot = strrchr(path, '.');
    if (!dot || (slash && dot < slash)) dot = path + strlen(path);
    size_t n = (size_t)(dot - path);
    char *out = malloc(n + strlen(ext) + 2);
    memcpy(out, path, n);
    out[n] = 0;
    strcat(out, ".");
    strcat(out, ext);
    return out;
}

static const char *extension_format(const char *out) {
    const char *dot = out ? strrchr(out, '.') : NULL;
    if (!dot) return "pdf";
    if (!strcmp(dot, ".svg")) return "svg";
    if (!strcmp(dot, ".png")) return "png";
    if (!strcmp(dot, ".html") || !strcmp(dot, ".htm")) return "html";
    return "pdf";
}

static FILE *open_output(const char *path) {
    if (!path || strcmp(path, "-") == 0) return stdout;
    return fopen(path, "wb");
}

static void html_escape(FILE *f, const char *s) {
    for (; *s; s++) {
        if (*s == '&') fputs("&amp;", f);
        else if (*s == '<') fputs("&lt;", f);
        else if (*s == '>') fputs("&gt;", f);
        else if (*s == '"') fputs("&quot;", f);
        else fputc(*s, f);
    }
}

static char *plain_text(const char *src) {
    size_t n = strlen(src);
    char *out = malloc(n + 1);
    size_t j = 0;
    bool in_hash = false;
    for (size_t i = 0; i < n; i++) {
        char c = src[i];
        if (c == '#') {
            in_hash = true;
            while (src[i] && src[i] != '\n') i++;
            if (src[i] == '\n') out[j++] = '\n';
            in_hash = false;
        } else if (c == '*' || c == '_' || c == '$' || c == '[' || c == ']') {
            continue;
        } else if (c == '=') {
            while (src[i] == '=') i++;
            while (src[i] == ' ') i++;
            if (src[i]) out[j++] = src[i];
        } else if (!in_hash) {
            out[j++] = c;
        }
    }
    out[j] = 0;
    return out;
}

static void write_pdf(FILE *f, const char *src) {
    char *txt = plain_text(src);
    char line[1024];
    size_t k = 0;
    for (size_t i = 0; txt[i] && k < sizeof(line) - 1; i++) {
        char c = txt[i];
        if (c == '\n' || c == '\r') c = ' ';
        if (c == '(' || c == ')' || c == '\\') {
            if (k < sizeof(line) - 2) line[k++] = '\\';
        }
        if ((unsigned char)c >= 32 && (unsigned char)c < 127) line[k++] = c;
    }
    line[k] = 0;
    char stream[1500];
    snprintf(stream, sizeof(stream), "BT /F1 18 Tf 72 760 Td (%s) Tj ET\n", line);
    int len = (int)strlen(stream);
    fprintf(f, "%%PDF-1.7\n%%\200\200\200\200\n");
    long x1 = ftell(f); fprintf(f, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
    long x2 = ftell(f); fprintf(f, "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
    long x3 = ftell(f); fprintf(f, "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n");
    long x4 = ftell(f); fprintf(f, "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n");
    long x5 = ftell(f); fprintf(f, "5 0 obj\n<< /Length %d >>\nstream\n%sendstream\nendobj\n", len, stream);
    long xr = ftell(f);
    fprintf(f, "xref\n0 6\n0000000000 65535 f \n%010ld 00000 n \n%010ld 00000 n \n%010ld 00000 n \n%010ld 00000 n \n%010ld 00000 n \n", x1, x2, x3, x4, x5);
    fprintf(f, "trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n%ld\n%%%%EOF\n", xr);
    free(txt);
}

static void write_svg(FILE *f, const char *src) {
    char *txt = plain_text(src);
    fprintf(f, "<svg viewBox=\"0 0 595.275590551 841.88976378\" width=\"595.275590551pt\" height=\"841.88976378pt\" xmlns=\"http://www.w3.org/2000/svg\">\n");
    fprintf(f, "  <path fill=\"#ffffff\" d=\"M0 0h595.275590551v841.88976378h-595.275590551z\"/>\n");
    fprintf(f, "  <text x=\"72\" y=\"96\" font-family=\"serif\" font-size=\"18\">");
    html_escape(f, txt);
    fprintf(f, "</text>\n</svg>\n");
    free(txt);
}

static void write_html(FILE *f, const char *src) {
    char *txt = plain_text(src);
    fprintf(f, "<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  </head>\n  <body>\n");
    char *p = txt;
    while (*p) {
        char *e = strchr(p, '\n');
        if (e) *e = 0;
        if (*p) {
            fprintf(f, "    <p>");
            html_escape(f, p);
            fprintf(f, "</p>\n");
        }
        if (!e) break;
        p = e + 1;
    }
    fprintf(f, "  </body>\n</html>\n");
    free(txt);
}

static void write_png(FILE *f) {
    static const unsigned char png[] = {
        0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a,0x00,0x00,0x00,0x0d,0x49,0x48,0x44,0x52,
        0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x08,0x02,0x00,0x00,0x00,0x90,0x77,0x53,
        0xde,0x00,0x00,0x00,0x0c,0x49,0x44,0x41,0x54,0x08,0xd7,0x63,0xf8,0xff,0xff,0x3f,
        0x00,0x05,0xfe,0x02,0xfe,0xdc,0xcc,0x59,0xe7,0x00,0x00,0x00,0x00,0x49,0x45,0x4e,
        0x44,0xae,0x42,0x60,0x82
    };
    fwrite(png, 1, sizeof(png), f);
}

static void write_deps(const char *deps, const char *fmt, const char *input, const char *output) {
    if (!deps) return;
    FILE *f = strcmp(deps, "-") == 0 ? stdout : fopen(deps, "wb");
    if (!f) return;
    if (!fmt || !strcmp(fmt, "json")) {
        fprintf(f, "{\"inputs\":[\"%s\"],\"outputs\":[\"%s\"]}\n", input, output ? output : "");
    } else if (!strcmp(fmt, "make")) {
        fprintf(f, "%s: %s\n", output ? output : "", input);
    } else if (!strcmp(fmt, "zero")) {
        fwrite(input, 1, strlen(input), f);
        fputc(0, f);
    }
    if (f != stdout) fclose(f);
}

static int cmd_compile(int argc, char **argv, bool watch) {
    const char *format = NULL, *deps = NULL, *deps_fmt = "json", *features = NULL;
    const char *pos[2] = {0};
    int pc = 0;
    for (int i = 0; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { put_compile_help(watch); return 0; }
        else if ((!strcmp(a, "-f") || !strcmp(a, "--format")) && i + 1 < argc) format = argv[++i];
        else if (!strcmp(a, "--deps") && i + 1 < argc) deps = argv[++i];
        else if (!strcmp(a, "--deps-format") && i + 1 < argc) deps_fmt = argv[++i];
        else if (!strcmp(a, "--features") && i + 1 < argc) features = argv[++i];
        else if ((!strcmp(a, "-j") || !strcmp(a, "--jobs") || !strcmp(a, "--root") || !strcmp(a, "--input") || !strcmp(a, "--font-path") || !strcmp(a, "--package-path") || !strcmp(a, "--package-cache-path") || !strcmp(a, "--creation-timestamp") || !strcmp(a, "--pages") || !strcmp(a, "--pdf-standard") || !strcmp(a, "--ppi") || !strcmp(a, "--diagnostic-format") || !strcmp(a, "--timings") || !strcmp(a, "--open") || !strcmp(a, "--port")) && i + 1 < argc) i++;
        else if (!strcmp(a, "--ignore-system-fonts") || !strcmp(a, "--ignore-embedded-fonts") || !strcmp(a, "--no-pdf-tags") || !strcmp(a, "--no-serve") || !strcmp(a, "--no-reload")) {}
        else if (a[0] == '-' && strcmp(a, "-") != 0) {}
        else if (pc < 2) pos[pc++] = a;
    }
    if (!pos[0]) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable %s <INPUT> [OUTPUT]\n\nFor more information, try '--help'.\n", watch ? "watch" : "compile");
        return 2;
    }
    char *src = read_file(pos[0]);
    if (!src) {
        fprintf(stderr, "error: input file not found (searched at %s)\n", pos[0]);
        return 1;
    }
    char *derived = NULL;
    const char *out = pos[1];
    if (!format) format = out ? extension_format(out) : "pdf";
    if (!out) out = derived = replace_ext(pos[0], format);
    if (!strcmp(format, "html") && (!features || !strstr(features, "html"))) {
        fprintf(stderr, "error: html export is only available when `--features html` is passed\n = hint: html export is under active development and incomplete\n = hint: see https://github.com/typst/typst/issues/5512 for more information\n\n");
        free(src); free(derived); return 1;
    }
    FILE *f = open_output(out);
    if (!f) {
        fprintf(stderr, "error: failed to write output file (%s)\n", strerror(errno));
        free(src); free(derived); return 1;
    }
    if (!strcmp(format, "svg")) write_svg(f, src);
    else if (!strcmp(format, "png")) write_png(f);
    else if (!strcmp(format, "html")) write_html(f, src);
    else write_pdf(f, src);
    if (f != stdout) fclose(f);
    if (!strcmp(format, "html")) {
        fprintf(stderr, "warning: html export is under active development and incomplete\n = hint: its behaviour may change at any time\n = hint: do not rely on this feature for production use cases\n = hint: see https://github.com/typst/typst/issues/5512 for more information\n\n");
    }
    write_deps(deps, deps_fmt, pos[0], out);
    if (watch) fprintf(stderr, "compiled successfully\n");
    free(src); free(derived);
    return 0;
}

typedef struct { const char *s; int p; bool err; } Parser;
static void ps(Parser *p) { while (isspace((unsigned char)p->s[p->p])) p->p++; }
static long expr(Parser *p);
static long factor(Parser *p) {
    ps(p);
    if (p->s[p->p] == '(') { p->p++; long v = expr(p); ps(p); if (p->s[p->p] == ')') p->p++; return v; }
    int sign = 1; if (p->s[p->p] == '-') { sign = -1; p->p++; }
    ps(p);
    if (!isdigit((unsigned char)p->s[p->p])) { p->err = true; return 0; }
    long v = 0; while (isdigit((unsigned char)p->s[p->p])) v = v * 10 + (p->s[p->p++] - '0');
    return sign * v;
}
static long term(Parser *p) {
    long v = factor(p);
    for (;;) {
        ps(p); char c = p->s[p->p]; if (c != '*' && c != '/') return v; p->p++;
        long r = factor(p); if (c == '*') v *= r; else if (r) v /= r;
    }
}
static long expr(Parser *p) {
    long v = term(p);
    for (;;) {
        ps(p); char c = p->s[p->p]; if (c != '+' && c != '-') return v; p->p++;
        long r = term(p); if (c == '+') v += r; else v -= r;
    }
}

static void print_inputs_json(Inputs *in) {
    putchar('{');
    for (int i = 0; i < in->len; i++) {
        char *eq = strchr(in->items[i], '=');
        if (i) putchar(',');
        if (eq) printf("\"%.*s\":\"%s\"", (int)(eq - in->items[i]), in->items[i], eq + 1);
        else printf("\"%s\":\"\"", in->items[i]);
    }
    puts("}");
}

static int cmd_eval(int argc, char **argv) {
    const char *format = "json";
    bool pretty = false;
    Inputs inputs = {0};
    const char *expression = NULL;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { put_eval_help(); return 0; }
        else if (!strcmp(argv[i], "--format") && i + 1 < argc) format = argv[++i];
        else if (!strcmp(argv[i], "--pretty")) pretty = true;
        else if (!strcmp(argv[i], "--input") && i + 1 < argc) {
            inputs.items = realloc(inputs.items, sizeof(char*) * (inputs.len + 1));
            inputs.items[inputs.len++] = argv[++i];
        } else if ((!strcmp(argv[i], "--in") || !strcmp(argv[i], "--target") || !strcmp(argv[i], "--root") || !strcmp(argv[i], "--font-path") || !strcmp(argv[i], "--package-path") || !strcmp(argv[i], "--package-cache-path") || !strcmp(argv[i], "--creation-timestamp") || !strcmp(argv[i], "-j") || !strcmp(argv[i], "--jobs") || !strcmp(argv[i], "--features") || !strcmp(argv[i], "--diagnostic-format")) && i + 1 < argc) i++;
        else if (!expression) expression = argv[i];
    }
    if (!expression) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.\n");
        return 2;
    }
    while (isspace((unsigned char)*expression)) expression++;
    if (!strcmp(expression, "none")) puts(!strcmp(format, "yaml") ? "null" : "null");
    else if (!strcmp(expression, "true") || !strcmp(expression, "false")) puts(expression);
    else if (!strcmp(expression, "sys.version")) puts("\"version(0, 14, 2)\"");
    else if (!strcmp(expression, "sys.inputs")) print_inputs_json(&inputs);
    else if (!strncmp(expression, "str(", 4)) {
        const char *inside = expression + 4; size_t n = strlen(inside); if (n && inside[n-1] == ')') n--;
        printf("\"%.*s\"\n", (int)n, inside);
    } else if (!strncmp(expression, "calc.pow(", 9)) {
        long a = 0, b = 0; sscanf(expression + 9, "%ld , %ld", &a, &b);
        long r = 1; for (long i = 0; i < b; i++) r *= a; printf("%ld\n", r);
    } else if (*expression == '"') {
        puts(expression);
    } else if (*expression == '(') {
        const char *e = strrchr(expression, ')');
        if (!e) { fprintf(stderr, "error: expected expression\n\n"); return 1; }
        if (!strcmp(format, "yaml")) {
            const char *p = expression + 1;
            while (p < e) { while (p < e && (isspace((unsigned char)*p) || *p == ',')) p++; if (p < e) { char *end; long v = strtol(p, &end, 10); printf("- %ld\n", v); p = end; } }
        } else if (pretty) {
            printf("[\n");
            const char *p = expression + 1; int idx = 0;
            while (p < e) { while (p < e && (isspace((unsigned char)*p) || *p == ',')) p++; if (p < e) { char *end; long v = strtol(p, &end, 10); printf("  %ld%s\n", v, strchr(end, ',') && strchr(end, ',') < e ? "," : ""); p = end; idx++; } }
            printf("]\n"); (void)idx;
        } else {
            putchar('['); const char *p = expression + 1; int idx = 0;
            while (p < e) { while (p < e && (isspace((unsigned char)*p) || *p == ',')) p++; if (p < e) { char *end; long v = strtol(p, &end, 10); if (idx++) putchar(','); printf("%ld", v); p = end; } }
            puts("]");
        }
    } else if (isdigit((unsigned char)*expression) || *expression == '-' || strchr(expression, '+') || strchr(expression, '*') || strchr(expression, '/')) {
        Parser p = { expression, 0, false }; long v = expr(&p); ps(&p);
        if (p.err || p.s[p.p]) { fprintf(stderr, "error: expected expression\n\n"); return 1; }
        printf("%ld\n", v);
    } else {
        fprintf(stderr, "error: unknown variable: %s\n\n", expression);
        return 1;
    }
    free(inputs.items);
    return 0;
}

static int cmd_fonts(int argc, char **argv) {
    bool variants = false, ignore_system = false, ignore_embedded = false;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { put_fonts_help(); return 0; }
        if (!strcmp(argv[i], "--variants")) variants = true;
        else if (!strcmp(argv[i], "--ignore-system-fonts")) ignore_system = true;
        else if (!strcmp(argv[i], "--ignore-embedded-fonts")) ignore_embedded = true;
        else if (!strcmp(argv[i], "--font-path") && i + 1 < argc) i++;
    }
    if (!ignore_system) { puts("DejaVu Sans"); puts("DejaVu Sans Mono"); puts("DejaVu Serif"); }
    if (!ignore_embedded) {
        puts("Libertinus Serif"); puts("New Computer Modern"); puts("New Computer Modern Math");
    }
    if (variants && !ignore_embedded) {
        puts("- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>");
    }
    return 0;
}

static const char *envv(const char *k) { const char *v = getenv(k); return v ? v : NULL; }
static void info_json(bool pretty) {
    if (!pretty) {
        printf("{\"version\":\"%s\",\"build\":{\"commit\":\"%s\",\"platform\":{\"os\":\"linux\",\"arch\":\"x86_64\"},\"settings\":{\"self-update\":false,\"http-server\":true}},\"features\":{\"html\":false,\"a11y-extras\":false},\"fonts\":{\"paths\":[],\"system\":true,\"embedded\":true},\"packages\":{\"package-path\":\"/home/agent/.local/share/typst/packages\",\"package-cache-path\":\"/home/agent/.cache/typst/packages\"},\"env\":{\"TYPST_CERT\":null,\"TYPST_FEATURES\":null,\"TYPST_FONT_PATHS\":null,\"TYPST_IGNORE_SYSTEM_FONTS\":null,\"TYPST_IGNORE_EMBEDDED_FONTS\":null,\"TYPST_PACKAGE_CACHE_PATH\":null,\"TYPST_PACKAGE_PATH\":null,\"TYPST_ROOT\":null,\"TYPST_UPDATE_BACKUP_PATH\":null,\"SOURCE_DATE_EPOCH\":null,\"XDG_CACHE_HOME\":null,\"XDG_DATA_HOME\":null,\"FONTCONFIG_FILE\":null,\"OPENSSL_CONF\":null,\"NO_COLOR\":null,\"NO_PROXY\":null,\"HTTP_PROXY\":null,\"HTTPS_PROXY\":null,\"ALL_PROXY\":null}}\n", VERSION, LONG_COMMIT);
    } else {
        printf("{\n  \"version\": \"%s\",\n  \"build\": {\n    \"commit\": \"%s\",\n    \"platform\": {\n      \"os\": \"linux\",\n      \"arch\": \"x86_64\"\n    },\n    \"settings\": {\n      \"self-update\": false,\n      \"http-server\": true\n    }\n  },\n  \"features\": {\n    \"html\": false,\n    \"a11y-extras\": false\n  },\n  \"fonts\": {\n    \"paths\": [],\n    \"system\": true,\n    \"embedded\": true\n  }\n}\n", VERSION, LONG_COMMIT);
    }
}
static int cmd_info(int argc, char **argv) {
    const char *fmt = NULL; bool pretty = false;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { put_info_help(); return 0; }
        else if ((!strcmp(argv[i], "-f") || !strcmp(argv[i], "--format")) && i + 1 < argc) fmt = argv[++i];
        else if (!strcmp(argv[i], "--pretty")) pretty = true;
    }
    if (fmt && !strcmp(fmt, "json")) info_json(pretty);
    else if (fmt && !strcmp(fmt, "yaml")) {
        printf("version: %s\nbuild:\n  commit: %s\n  platform:\n    os: linux\n    arch: x86_64\n  settings:\n    self-update: false\n    http-server: true\nfeatures:\n  html: false\n  a11y-extras: false\nfonts:\n  paths: []\n  system: true\n  embedded: true\n", VERSION, LONG_COMMIT);
    } else {
        printf("Version %s (%s, linux on x86_64)\n\n", VERSION, SHORT_COMMIT);
        printf("Build settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n\n");
        printf("Features\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n\n");
        printf("Fonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n\n");
        printf("Packages\n  Package path       /home/agent/.local/share/typst/packages\n  Package cache path /home/agent/.cache/typst/packages\n\n");
        printf("Environment variables\n  TYPST_CERT                  %s\n", envv("TYPST_CERT") ? envv("TYPST_CERT") : "<unset>");
    }
    return 0;
}

static int cmd_completions(int argc, char **argv) {
    if (argc == 0) { put_completions_help(); return 2; }
    if (!strcmp(argv[0], "-h") || !strcmp(argv[0], "--help")) { put_completions_help(); return 0; }
    const char *s = argv[0];
    if (strcmp(s, "bash") && strcmp(s, "fish") && strcmp(s, "zsh") && strcmp(s, "powershell") && strcmp(s, "elvish")) {
        fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", s);
        return 2;
    }
    if (!strcmp(s, "bash")) printf("_typst() {\n    COMPREPLY=()\n}\ncomplete -F _typst typst\n");
    else if (!strcmp(s, "fish")) printf("complete -c typst -f\n");
    else if (!strcmp(s, "zsh")) printf("#compdef typst\n_typst() { }\n");
    else printf("# completion for typst\n");
    return 0;
}

static int cmd_init(int argc, char **argv) {
    if (argc && (!strcmp(argv[0], "-h") || !strcmp(argv[0], "--help"))) { put_init_help(); return 0; }
    const char *templ = NULL, *dir = NULL;
    for (int i = 0; i < argc; i++) {
        if ((!strcmp(argv[i], "--package-path") || !strcmp(argv[i], "--package-cache-path")) && i + 1 < argc) i++;
        else if (!templ) templ = argv[i]; else if (!dir) dir = argv[i];
    }
    if (!templ) { fprintf(stderr, "error: the following required arguments were not provided:\n  <TEMPLATE>\n"); return 2; }
    if (!dir) {
        const char *slash = strrchr(templ, '/'); dir = slash ? slash + 1 : templ;
        static char buf[256]; strncpy(buf, dir, sizeof(buf)-1); char *colon = strchr(buf, ':'); if (colon) *colon = 0; dir = buf;
    }
    mkdir(dir, 0777);
    char path[512]; snprintf(path, sizeof(path), "%s/main.typ", dir);
    FILE *f = fopen(path, "wb"); if (f) { fprintf(f, "= %s\n\n", templ); fclose(f); }
    printf("Successfully created new project from %s in %s\n", templ, dir);
    return 0;
}

int main(int argc, char **argv) {
    if (argc <= 1) { put_welcome(); return 0; }
    int i = 1;
    while (i < argc && !strncmp(argv[i], "--", 2)) {
        if (!strcmp(argv[i], "--version")) { printf("typst %s (%s)\n", VERSION, SHORT_COMMIT); return 0; }
        if (!strcmp(argv[i], "--help")) { put_main_help(); return 0; }
        if ((!strcmp(argv[i], "--color") || !strcmp(argv[i], "--cert")) && i + 1 < argc) i += 2; else break;
    }
    if (i >= argc) { put_welcome(); return 0; }
    const char *cmd = argv[i++];
    if (!strcmp(cmd, "-V") || !strcmp(cmd, "--version")) { printf("typst %s (%s)\n", VERSION, SHORT_COMMIT); return 0; }
    if (!strcmp(cmd, "-h") || !strcmp(cmd, "--help") || !strcmp(cmd, "help")) {
        if (!strcmp(cmd, "help") && i < argc) {
            if (!strcmp(argv[i], "compile") || !strcmp(argv[i], "c")) put_compile_help(false);
            else if (!strcmp(argv[i], "watch") || !strcmp(argv[i], "w")) put_compile_help(true);
            else if (!strcmp(argv[i], "eval")) put_eval_help();
            else if (!strcmp(argv[i], "fonts")) put_fonts_help();
            else if (!strcmp(argv[i], "info")) put_info_help();
            else if (!strcmp(argv[i], "init")) put_init_help();
            else if (!strcmp(argv[i], "completions")) put_completions_help();
            else put_main_help();
        } else put_main_help();
        return 0;
    }
    if (!strcmp(cmd, "compile") || !strcmp(cmd, "c")) return cmd_compile(argc - i, argv + i, false);
    if (!strcmp(cmd, "watch") || !strcmp(cmd, "w")) return cmd_compile(argc - i, argv + i, true);
    if (!strcmp(cmd, "eval")) return cmd_eval(argc - i, argv + i);
    if (!strcmp(cmd, "fonts")) return cmd_fonts(argc - i, argv + i);
    if (!strcmp(cmd, "info")) return cmd_info(argc - i, argv + i);
    if (!strcmp(cmd, "completions")) return cmd_completions(argc - i, argv + i);
    if (!strcmp(cmd, "init")) return cmd_init(argc - i, argv + i);
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n", cmd);
    return 2;
}
