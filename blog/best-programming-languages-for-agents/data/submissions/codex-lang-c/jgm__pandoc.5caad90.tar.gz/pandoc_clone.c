#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char *s; size_t n, cap; } Str;
typedef struct { char **v; int n, cap; } Lines;

static void die(const char *msg){ fprintf(stderr,"%s\n",msg); exit(1); }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) die("out of memory"); return p; }
static void saddn(Str *b,const char *s,size_t n){ if(b->n+n+1>b->cap){ while(b->n+n+1>b->cap) b->cap=b->cap?b->cap*2:256; b->s=realloc(b->s,b->cap); if(!b->s) die("out of memory"); } memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void sadd(Str *b,const char *s){ saddn(b,s,strlen(s)); }
static void sc(char c,Str*b){ saddn(b,&c,1); }
static char *sfinish(Str*b){ if(!b->s) return xstrdup(""); return b->s; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; size_t n=strlen(s); while(n&&isspace((unsigned char)s[n-1])) s[--n]=0; return s; }
static bool blank(const char*s){ while(*s){ if(!isspace((unsigned char)*s)) return false; s++; } return true; }
static void push_line(Lines*l,char*s){ if(l->n==l->cap){ l->cap=l->cap?l->cap*2:64; l->v=realloc(l->v,l->cap*sizeof(char*)); if(!l->v) die("out of memory"); } l->v[l->n++]=s; }

static char *read_stream(FILE*f){
  Str b={0}; char tmp[8192]; size_t n;
  while((n=fread(tmp,1,sizeof tmp,f))>0) saddn(&b,tmp,n);
  return sfinish(&b);
}
static char *read_file(const char *path){
  FILE*f=fopen(path,"rb"); if(!f){ fprintf(stderr,"executable: %s: openBinaryFile: does not exist (No such file or directory)\n",path); exit(1); }
  char*r=read_stream(f); fclose(f); return r;
}
static Lines split_lines(const char *text){
  Lines l={0}; const char*p=text;
  while(*p){ const char*q=strchr(p,'\n'); size_t n=q?(size_t)(q-p):strlen(p); if(n&&p[n-1]=='\r') n--; char*s=malloc(n+1); memcpy(s,p,n); s[n]=0; push_line(&l,s); if(!q) break; p=q+1; }
  if(l.n==0) push_line(&l,xstrdup(""));
  return l;
}

static char *slugify(const char *s){
  Str b={0}; bool lastdash=false;
  for(;*s;s++){
    unsigned char c=*s;
    if(isalnum(c)){ sc((char)tolower(c),&b); lastdash=false; }
    else if(isspace(c)||c=='-'||c=='_'){ if(b.n&&!lastdash){ sc('-',&b); lastdash=true; } }
  }
  while(b.n&&b.s[b.n-1]=='-') b.s[--b.n]=0;
  if(!b.n) sadd(&b,"section");
  return sfinish(&b);
}
static void esc_html(Str*b,const char*s){
  for(;*s;s++){ if(*s=='&')sadd(b,"&amp;"); else if(*s=='<')sadd(b,"&lt;"); else if(*s=='>')sadd(b,"&gt;"); else if(*s=='"')sadd(b,"&quot;"); else sc(*s,b); }
}
static void esc_latex(Str*b,const char*s){
  for(;*s;s++){ switch(*s){case '\\':sadd(b,"\\textbackslash{}");break;case '&':sadd(b,"\\&");break;case '%':sadd(b,"\\%");break;case '$':sadd(b,"\\$");break;case '#':sadd(b,"\\#");break;case '_':sadd(b,"\\_");break;case '{':sadd(b,"\\{");break;case '}':sadd(b,"\\}");break;case '~':sadd(b,"\\textasciitilde{}");break;case '^':sadd(b,"\\textasciicircum{}");break;default:sc(*s,b);} }
}
static void esc_json(Str*b,const char*s){
  for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\'){ sc('\\',b); sc(c,b);} else if(c=='\n') sadd(b,"\\n"); else if(c<32){} else sc(c,b); }
}
static bool starts(const char*s,const char*p){ return strncmp(s,p,strlen(p))==0; }

static char *inline_render(const char *s,const char *fmt){
  Str b={0}; bool html=!strcmp(fmt,"html"), latex=!strcmp(fmt,"latex"), plain=!strcmp(fmt,"plain");
  for(size_t i=0;s[i];){
    if(s[i]=='`'){ size_t j=i+1; while(s[j]&&s[j]!='`') j++; char *inner=strndup(s+i+1,j-i-1); if(html){sadd(&b,"<code>");esc_html(&b,inner);sadd(&b,"</code>");} else if(latex){sadd(&b,"\\texttt{");esc_latex(&b,inner);sadd(&b,"}");} else {sadd(&b,inner);} free(inner); i=s[j]?j+1:j; continue; }
    if(s[i]=='*'&&s[i+1]=='*'){ char *e=strstr(s+i+2,"**"); if(e){ char *inner=strndup(s+i+2,e-s-i-2); char *r=inline_render(inner,fmt); if(html){sadd(&b,"<strong>");sadd(&b,r);sadd(&b,"</strong>");} else if(latex){sadd(&b,"\\textbf{");sadd(&b,r);sadd(&b,"}");} else sadd(&b,r); free(inner); free(r); i=(e-s)+2; continue; } }
    if((s[i]=='*'||s[i]=='_') && s[i+1]){ char mark=s[i]; size_t j=i+1; while(s[j]&&s[j]!=mark) j++; if(s[j]){ char *inner=strndup(s+i+1,j-i-1); char *r=inline_render(inner,fmt); if(html){sadd(&b,"<em>");sadd(&b,r);sadd(&b,"</em>");} else if(latex){sadd(&b,"\\emph{");sadd(&b,r);sadd(&b,"}");} else sadd(&b,r); free(inner); free(r); i=j+1; continue; } }
    if(s[i]=='!'&&s[i+1]=='['){ char *mid=strchr(s+i+2,']'); if(mid&&mid[1]=='('){ char *end=strchr(mid+2,')'); if(end){ char *alt=strndup(s+i+2,mid-s-i-2); char *url=strndup(mid+2,end-mid-2); if(html){sadd(&b,"<img src=\"");esc_html(&b,url);sadd(&b,"\" alt=\"");esc_html(&b,alt);sadd(&b,"\" />");} else sadd(&b,alt); free(alt); free(url); i=end-s+1; continue; }}}
    if(s[i]=='['){ char *mid=strchr(s+i+1,']'); if(mid&&mid[1]=='('){ char *end=strchr(mid+2,')'); if(end){ char *txt=strndup(s+i+1,mid-s-i-1); char *url=strndup(mid+2,end-mid-2); char *r=inline_render(txt,fmt); if(html){sadd(&b,"<a href=\"");esc_html(&b,url);sadd(&b,"\">");sadd(&b,r);sadd(&b,"</a>");} else if(latex){sadd(&b,"\\href{");esc_latex(&b,url);sadd(&b,"}{");sadd(&b,r);sadd(&b,"}");} else sadd(&b,r); free(txt); free(url); free(r); i=end-s+1; continue; }}}
    if(html) esc_html(&b,(char[]){s[i],0}); else if(latex) esc_latex(&b,(char[]){s[i],0}); else sc(s[i],&b);
    i++;
  }
  (void)plain; return sfinish(&b);
}
static char *strip_tags(const char*in){
  Str b={0}; bool intag=false; for(size_t i=0;in[i];i++){ char c=in[i]; if(c=='<'){ intag=true; if(starts(in+i,"<br")||starts(in+i,"</p")||starts(in+i,"</h")||starts(in+i,"</li")) sc('\n',&b); } else if(c=='>') intag=false; else if(!intag) sc(c,&b); }
  return sfinish(&b);
}

static int heading_level(char*s,char**txt){
  int n=0; while(s[n]=='#') n++; if(n>=1&&n<=6&&isspace((unsigned char)s[n])){ *txt=trim(s+n); return n; } return 0;
}
static int underline_heading(char*s){ s=trim(s); if(!*s) return 0; char c=*s; if(c!='='&&c!='-') return 0; for(;*s;s++) if(*s!=c&& !isspace((unsigned char)*s)) return 0; return c=='='?1:2; }
static int alt_heading(char*s,char**txt){
  char*t=trim(s);
  if(starts(t,"== ")||starts(t,"= ")){ int n=0; while(t[n]=='=') n++; *txt=trim(t+n); return n; }
  if(t[0]=='*'&&isspace((unsigned char)t[1])){ int n=0; while(t[n]=='*') n++; if(isspace((unsigned char)t[n])){ *txt=trim(t+n); return n; }}
  return 0;
}
static bool ul_marker(char*s,char**txt){ s=trim(s); if((s[0]=='-'||s[0]=='*'||s[0]=='+')&&isspace((unsigned char)s[1])){*txt=trim(s+2);return true;} return false; }
static bool ol_marker(char*s,char**txt){ s=trim(s); int i=0; while(isdigit((unsigned char)s[i]))i++; if(i&& (s[i]=='.'||s[i]==')') && isspace((unsigned char)s[i+1])){*txt=trim(s+i+2);return true;} return false; }

static void render_para(Str*out,const char*para,const char*fmt){
  char *r=inline_render(para,fmt);
  if(!strcmp(fmt,"html")){ sadd(out,"<p>"); sadd(out,r); sadd(out,"</p>\n"); }
  else if(!strcmp(fmt,"latex")){ sadd(out,r); sadd(out,"\n"); }
  else { sadd(out,r); sadd(out,"\n"); }
  free(r);
}
static char **split_cells(char *row,int *count){
  char *s=trim(row); size_t n=strlen(s); if(n&&s[0]=='|') s++; n=strlen(s); if(n&&s[n-1]=='|') s[n-1]=0;
  char **cells=NULL; int cap=0,cnt=0; char *save=NULL,*p=strtok_r(s,"|",&save);
  while(p){ if(cnt==cap){cap=cap?cap*2:8; cells=realloc(cells,cap*sizeof(char*));} cells[cnt++]=xstrdup(trim(p)); p=strtok_r(NULL,"|",&save); }
  *count=cnt; return cells;
}
static bool table_sep(const char*s){ s=trim((char*)s); if(!strchr(s,'|')) return false; for(;*s;s++) if(*s!='|'&&*s!='-'&&*s!=':'&& !isspace((unsigned char)*s)) return false; return true; }
static void render_table(Str*body,Lines*l,int *idx,const char*fmt){
  int i=*idx, hc=0; char *hrow=xstrdup(l->v[i]); char **heads=split_cells(hrow,&hc); free(hrow); i+=2;
  if(!strcmp(fmt,"html")){ sadd(body,"<table>\n<thead>\n<tr>"); for(int c=0;c<hc;c++){sadd(body,"<th>");esc_html(body,heads[c]);sadd(body,"</th>");} sadd(body,"</tr>\n</thead>\n<tbody>\n"); }
  else if(!strcmp(fmt,"latex")){ sadd(body,"\\begin{longtable}"); for(int c=0;c<hc;c++) sadd(body,"{l}"); sadd(body,"\n"); for(int c=0;c<hc;c++){ if(c)sadd(body," & "); esc_latex(body,heads[c]); } sadd(body," \\\\\n\\endhead\n"); }
  else { for(int c=0;c<hc;c++){ if(c)sadd(body," | "); sadd(body,heads[c]); } sadd(body,"\n"); }
  while(i<l->n && strchr(l->v[i],'|') && !blank(l->v[i])){
    int cc=0; char *r=xstrdup(l->v[i]); char **cells=split_cells(r,&cc); free(r);
    if(!strcmp(fmt,"html")){ sadd(body,"<tr>"); for(int c=0;c<cc;c++){sadd(body,"<td>");esc_html(body,cells[c]);sadd(body,"</td>");} sadd(body,"</tr>\n"); }
    else if(!strcmp(fmt,"latex")){ for(int c=0;c<cc;c++){ if(c)sadd(body," & "); esc_latex(body,cells[c]); } sadd(body," \\\\\n"); }
    else { for(int c=0;c<cc;c++){ if(c)sadd(body," | "); sadd(body,cells[c]); } sadd(body,"\n"); }
    for(int c=0;c<cc;c++) free(cells[c]); free(cells); i++;
  }
  if(!strcmp(fmt,"html")) sadd(body,"</tbody>\n</table>\n"); else if(!strcmp(fmt,"latex")) sadd(body,"\\end{longtable}\n");
  for(int c=0;c<hc;c++) free(heads[c]); free(heads); *idx=i;
}
static char *convert_markdown(const char*input,const char*fmt,int standalone,int toc,const char*title){
  if(!strcmp(fmt,"markdown")||!strcmp(fmt,"commonmark")||!strcmp(fmt,"gfm")) return xstrdup(input);
  if(!strcmp(fmt,"html4")||!strcmp(fmt,"html5")) fmt="html";
  Lines l=split_lines(input); Str body={0}, tocbuf={0}; int i=0;
  while(i<l.n){
    char *line=l.v[i], *txt=NULL; int hl=heading_level(line,&txt);
    if(!hl) hl=alt_heading(line,&txt);
    if(blank(line)){ i++; continue; }
    if(i+1<l.n && !blank(line) && underline_heading(l.v[i+1])){ txt=trim(line); hl=underline_heading(l.v[i+1]); }
    if(hl){
      char *id=slugify(txt); char *r=inline_render(txt,fmt);
      if(!strcmp(fmt,"html")){ char tag[32]; snprintf(tag,sizeof tag,"<h%d id=\"",hl); sadd(&body,tag); esc_html(&body,id); sadd(&body,"\">"); sadd(&body,r); snprintf(tag,sizeof tag,"</h%d>\n",hl); sadd(&body,tag);
        if(toc){ sadd(&tocbuf,"<li><a href=\"#"); esc_html(&tocbuf,id); sadd(&tocbuf,"\" id=\"toc-"); esc_html(&tocbuf,id); sadd(&tocbuf,"\">"); esc_html(&tocbuf,txt); sadd(&tocbuf,"</a></li>\n"); }}
      else if(!strcmp(fmt,"latex")){ const char*cmd[]={"","section","subsection","subsubsection","paragraph","subparagraph","subparagraph"}; sadd(&body,"\\"); sadd(&body,cmd[hl]); sadd(&body,"{"); sadd(&body,r); sadd(&body,"}\\label{"); sadd(&body,id); sadd(&body,"}\n"); }
      else if(!strcmp(fmt,"rst")){ sadd(&body,txt); sadd(&body,"\n"); for(size_t k=0;k<strlen(txt);k++) sc(hl==1?'=':'-',&body); sadd(&body,"\n"); }
      else if(!strcmp(fmt,"org")){ for(int k=0;k<hl;k++) sc('*',&body); sc(' ',&body); sadd(&body,txt); sadd(&body,"\n:PROPERTIES:\n:CUSTOM_ID: "); sadd(&body,id); sadd(&body,"\n:END:\n"); }
      else if(!strcmp(fmt,"asciidoc")||!strcmp(fmt,"asciidoctor")){ for(int k=0;k<=hl;k++) sc('=',&body); sc(' ',&body); sadd(&body,txt); sadd(&body,"\n"); }
      else if(!strcmp(fmt,"man")){ sadd(&body,hl==1?".SH ":".SS "); sadd(&body,txt); sadd(&body,"\n"); }
      else { sadd(&body,txt); sadd(&body,"\n"); }
      free(r); free(id); i += (i+1<l.n && underline_heading(l.v[i+1])) ? 2 : 1; if(strcmp(fmt,"html") && (i>=l.n || blank(l.v[i]))) sadd(&body,"\n"); continue;
    }
    if(starts(trim(line),"```")||starts(trim(line),"~~~")){
      const char *fence=line[0]=='~'?"~~~":"```"; i++; Str code={0}; while(i<l.n&&!starts(trim(l.v[i]),fence)){ sadd(&code,l.v[i]); sadd(&code,"\n"); i++; } if(i<l.n)i++;
      if(!strcmp(fmt,"html")){ sadd(&body,"<pre><code>"); esc_html(&body,code.s?code.s:""); sadd(&body,"</code></pre>\n");}
      else if(!strcmp(fmt,"latex")){ sadd(&body,"\\begin{verbatim}\n"); sadd(&body,code.s?code.s:""); sadd(&body,"\\end{verbatim}\n");}
      else sadd(&body,code.s?code.s:"");
      free(code.s); if(strcmp(fmt,"html")) sadd(&body,"\n"); continue;
    }
    char *item=NULL;
    if(ul_marker(line,&item)||ol_marker(line,&item)){
      bool ordered=ol_marker(line,&item);
      if(!strcmp(fmt,"html")) sadd(&body,ordered?"<ol>\n":"<ul>\n");
      else if(!strcmp(fmt,"latex")) sadd(&body,ordered?"\\begin{enumerate}\n\\tightlist\n":"\\begin{itemize}\n\\tightlist\n");
      while(i<l.n && (ordered?ol_marker(l.v[i],&item):ul_marker(l.v[i],&item))){
        char *r=inline_render(item,fmt);
        if(!strcmp(fmt,"html")){ sadd(&body,"<li>"); sadd(&body,r); sadd(&body,"</li>\n");}
        else if(!strcmp(fmt,"latex")){ sadd(&body,"\\item\n  "); sadd(&body,r); sadd(&body,"\n");}
        else if(!strcmp(fmt,"asciidoc")||!strcmp(fmt,"asciidoctor")){ sadd(&body,ordered?". ":"* "); sadd(&body,r); sadd(&body,"\n");}
        else { sadd(&body,ordered?"1. ":"- "); sadd(&body,r); sadd(&body,"\n");}
        free(r); i++;
      }
      if(!strcmp(fmt,"html")) sadd(&body,ordered?"</ol>\n":"</ul>\n");
      else if(!strcmp(fmt,"latex")) sadd(&body,ordered?"\\end{enumerate}\n":"\\end{itemize}\n");
      if(strcmp(fmt,"html")) sadd(&body,"\n"); continue;
    }
    if(starts(trim(line),">")){
      Str q={0}; while(i<l.n&&starts(trim(l.v[i]),">")){ char*p=trim(l.v[i])+1; p=trim(p); sadd(&q,p); sadd(&q," "); i++; }
      char *r=inline_render(q.s?q.s:"",fmt); if(!strcmp(fmt,"html")){sadd(&body,"<blockquote>\n<p>");sadd(&body,r);sadd(&body,"</p>\n</blockquote>\n");} else sadd(&body,r),sadd(&body,"\n"); free(r); free(q.s); if(strcmp(fmt,"html")) sadd(&body,"\n"); continue;
    }
    if(starts(trim(line),"---")||starts(trim(line),"***")){ if(!strcmp(fmt,"html")) sadd(&body,"<hr />\n"); else sadd(&body,"* * * * *\n"); i++; continue; }
    if(i+1<l.n && strchr(line,'|') && table_sep(l.v[i+1])){ render_table(&body,&l,&i,fmt); if(strcmp(fmt,"html")) sadd(&body,"\n"); continue; }
    Str para={0}; while(i<l.n&&!blank(l.v[i])&&!heading_level(l.v[i],&txt)&&!ul_marker(l.v[i],&txt)&&!ol_marker(l.v[i],&txt)&&!starts(trim(l.v[i]),"```")&&!starts(trim(l.v[i]),"~~~")){ if(para.n) sc(' ',&para); sadd(&para,trim(l.v[i])); i++; }
    render_para(&body,para.s?para.s:"",fmt); if(strcmp(fmt,"html")) sadd(&body,"\n"); free(para.s);
  }
  for(int k=0;k<l.n;k++) free(l.v[k]); free(l.v);
  char *b=sfinish(&body);
  if(!strcmp(fmt,"html")&&standalone){
    Str out={0}; sadd(&out,"<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=yes\" />\n  <title>"); esc_html(&out,title?title:"-"); sadd(&out,"</title>\n</head>\n<body>\n");
    if(toc&&tocbuf.n){ sadd(&out,"<nav id=\"TOC\" role=\"doc-toc\">\n<ul>\n"); sadd(&out,tocbuf.s); sadd(&out,"</ul>\n</nav>\n"); }
    sadd(&out,b); sadd(&out,"</body>\n</html>\n"); free(b); free(tocbuf.s); return sfinish(&out);
  }
  free(tocbuf.s); return b;
}

static char *convert_csv(const char*input,const char*fmt){
  Lines l=split_lines(input); Str out={0};
  if(!strcmp(fmt,"html")) sadd(&out,"<table>\n");
  for(int i=0;i<l.n;i++){ if(blank(l.v[i])) continue; char *row=xstrdup(l.v[i]); if(!strcmp(fmt,"html")) sadd(&out,i==0?"<thead>\n<tr>":"<tr>"); else if(i==1&&!strcmp(fmt,"markdown")){} char *save=NULL,*cell=strtok_r(row,",\t",&save); int c=0; while(cell){ if(!strcmp(fmt,"html")){ sadd(&out,i==0?"<th>":"<td>"); esc_html(&out,trim(cell)); sadd(&out,i==0?"</th>":"</td>"); } else { if(c++) sadd(&out," | "); sadd(&out,trim(cell)); } cell=strtok_r(NULL,",\t",&save); } if(!strcmp(fmt,"html")) sadd(&out,i==0?"</tr>\n</thead>\n<tbody>\n":"</tr>\n"); else sadd(&out,"\n"); free(row);}
  if(!strcmp(fmt,"html")) sadd(&out,"</tbody>\n</table>\n"); for(int i=0;i<l.n;i++)free(l.v[i]); free(l.v); return sfinish(&out);
}
static char *strip_yaml_meta(char *input,const char **titlep){
  if(strncmp(input,"---\n",4)&&strncmp(input,"---\r\n",5)) return input;
  char *p=strchr(input,'\n'); if(!p) return input; p++;
  char *body=NULL;
  while(*p){
    char *e=strchr(p,'\n'); size_t n=e?(size_t)(e-p):strlen(p);
    char *line=strndup(p,n); if(n&&line[n-1]=='\r') line[n-1]=0;
    char *t=trim(line);
    if(!strcmp(t,"---")||!strcmp(t,"...")){ body=e?e+1:p+n; free(line); return xstrdup(body); }
    if(starts(t,"title:") && !*titlep){ t=trim(t+6); if((*t=='"'||*t=='\'')&&t[strlen(t)-1]==*t){ t[strlen(t)-1]=0; t++; } *titlep=xstrdup(t); }
    free(line); if(!e) break; p=e+1;
  }
  return input;
}
static const char *inputs="asciidoc\nbiblatex\nbibtex\nbits\ncommonmark\ncommonmark_x\ncreole\ncsljson\ncsv\ndjot\ndocbook\ndocx\ndokuwiki\nendnotexml\nepub\nfb2\ngfm\nhaddock\nhtml\nipynb\njats\njira\njson\nlatex\nman\nmarkdown\nmarkdown_github\nmarkdown_mmd\nmarkdown_phpextra\nmarkdown_strict\nmdoc\nmediawiki\nmuse\nnative\nodt\nopml\norg\npod\npptx\nris\nrst\nrtf\nt2t\ntextile\ntikiwiki\ntsv\ntwiki\ntypst\nvimwiki\nxlsx\nxml\n";
static const char *outputs="ansi\nasciidoc\nasciidoc_legacy\nasciidoctor\nbbcode\nbbcode_fluxbb\nbbcode_hubzilla\nbbcode_phpbb\nbbcode_steam\nbbcode_xenforo\nbeamer\nbiblatex\nbibtex\nchunkedhtml\ncommonmark\ncommonmark_x\ncontext\ncsljson\ndjot\ndocbook\ndocbook4\ndocbook5\ndocx\ndokuwiki\ndzslides\nepub\nepub2\nepub3\nfb2\ngfm\nhaddock\nhtml\nhtml4\nhtml5\nicml\nipynb\njats\njats_archiving\njats_articleauthoring\njats_publishing\njira\njson\nlatex\nman\nmarkdown\nmarkdown_github\nmarkdown_mmd\nmarkdown_phpextra\nmarkdown_strict\nmarkua\nmediawiki\nms\nmuse\nnative\nodt\nopendocument\nopml\norg\npdf\nplain\npptx\nrevealjs\nrst\nrtf\ns5\nslideous\nslidy\ntei\ntexinfo\ntextile\ntypst\nvimdoc\nxml\nxwiki\nzimwiki\n";
static void help(void){ puts("executable [OPTIONS] [FILES]\n  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT\n  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT\n  -o FILE               --output=FILE\n  -s                    --standalone\n  -M KEY[:VALUE]        --metadata=KEY[:VALUE]\n  -V KEY[:VALUE]        --variable=KEY[:VALUE]\n                        --toc, --table-of-contents\n  -v                    --version\n  -h                    --help"); }
static void version(void){ puts("pandoc 3.9.0.2\nFeatures: +server +lua\nScripting engine: Lua 5.4\nUser data directory: /home/agent/.local/share/pandoc\nCopyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org\nThis is free software; see the source for copying conditions. There is no\nwarranty, not even for merchantability or fitness for a particular purpose."); }
int main(int argc,char**argv){
  const char *from="markdown", *to="html", *outfile=NULL, *title=NULL; int standalone=0,toc=0; Lines files={0};
  for(int i=1;i<argc;i++){
    char*a=argv[i];
    if(!strcmp(a,"-h")||!strcmp(a,"--help")){help();return 0;} if(!strcmp(a,"-v")||!strcmp(a,"--version")){version();return 0;}
    if(!strcmp(a,"--list-input-formats")){fputs(inputs,stdout);return 0;} if(!strcmp(a,"--list-output-formats")){fputs(outputs,stdout);return 0;}
    if(!strcmp(a,"--list-extensions")){ puts("+smart\n+footnotes\n+pipe_tables\n+table_captions\n+strikeout\n+tex_math_dollars\n+yaml_metadata_block"); return 0; }
    if(!strcmp(a,"--list-highlight-languages")){ puts("bash\nc\ncpp\nhaskell\nhtml\njson\npython\ntext\nxml\nyaml"); return 0; }
    if(!strcmp(a,"--list-highlight-styles")){ puts("pygments\ntango\nespresso\nzenburn\nkate\nmonochrome\nbreezedark\nhaddock"); return 0; }
    if((!strcmp(a,"-D")||!strcmp(a,"--print-default-template"))&&i+1<argc){ const char *f=argv[++i]; if(strstr(f,"html")) puts("$if(title)$\n<title>$title$</title>\n$endif$\n$body$"); else puts("$body$"); return 0; }
    if(!strncmp(a,"--print-default-template=",25)){ puts("$body$"); return 0; }
    if((!strcmp(a,"--print-default-data-file"))&&i+1<argc){ i++; return 0; }
    if(!strncmp(a,"--print-default-data-file=",26)) return 0;
    if(!strcmp(a,"--bash-completion")) return 0;
    if((!strcmp(a,"-f")||!strcmp(a,"-r")||!strcmp(a,"--from")||!strcmp(a,"--read"))&&i+1<argc){from=argv[++i];continue;}
    if((!strcmp(a,"-t")||!strcmp(a,"-w")||!strcmp(a,"--to")||!strcmp(a,"--write"))&&i+1<argc){to=argv[++i];continue;}
    if(!strncmp(a,"--from=",7)){from=a+7;continue;} if(!strncmp(a,"--read=",7)){from=a+7;continue;} if(!strncmp(a,"--to=",5)){to=a+5;continue;} if(!strncmp(a,"--write=",8)){to=a+8;continue;}
    if(!strcmp(a,"-o")&&i+1<argc){outfile=argv[++i];continue;} if(!strncmp(a,"--output=",9)){outfile=a+9;continue;}
    if(!strcmp(a,"-s")||starts(a,"--standalone")){standalone=1;continue;} if(!strcmp(a,"--toc")||!strcmp(a,"--table-of-contents")){toc=1;continue;}
    if((!strcmp(a,"-M")||!strcmp(a,"--metadata")||!strcmp(a,"-V")||!strcmp(a,"--variable"))&&i+1<argc){ char*v=argv[++i]; if(starts(v,"title:")||starts(v,"title=")) title=v+6; continue; }
    if(!strncmp(a,"--metadata=",11)){ char*v=a+11; if(starts(v,"title:")||starts(v,"title=")) title=v+6; continue; }
    if(!strncmp(a,"--variable=",11)){ char*v=a+11; if(starts(v,"title:")||starts(v,"title=")) title=v+6; continue; }
    if(a[0]=='-'){ if(!strcmp(a,"--self-contained")||!strcmp(a,"--embed-resources")||!strcmp(a,"--mathjax")||!strcmp(a,"--katex")||!strcmp(a,"--ascii")||!strcmp(a,"--number-sections")||!strcmp(a,"--no-highlight")||!strcmp(a,"--quiet")) continue; if(i+1<argc && (strchr("dDHBAFcTL", a[1])||starts(a,"--template")||starts(a,"--css")||starts(a,"--highlight-style"))) { if(!strchr(a,'=')) i++; continue; } fprintf(stderr,"Unknown option %s.\nTry executable --help for more information.\n",a); return 6; }
    push_line(&files,xstrdup(a));
  }
  Str in={0}; if(files.n){ for(int i=0;i<files.n;i++){ char *c=read_file(files.v[i]); sadd(&in,c); if(i+1<files.n) sadd(&in,"\n"); free(c); } } else { char*c=read_stream(stdin); sadd(&in,c); free(c); }
  char *input=sfinish(&in); char *res=NULL; char *stripped=strip_yaml_meta(input,&title); if(stripped!=input){ free(input); input=stripped; }
  char fbuf[64], tbuf[64]; snprintf(fbuf,sizeof fbuf,"%s",from); snprintf(tbuf,sizeof tbuf,"%s",to); char *p=strchr(fbuf,'+'); if(p)*p=0; p=strchr(tbuf,'+'); if(p)*p=0;
  if(!strcmp(fbuf,"html")){ char *plain=strip_tags(input); res=(!strcmp(tbuf,"html"))?xstrdup(input):convert_markdown(plain,tbuf,standalone,toc,title); free(plain); }
  else if(!strcmp(fbuf,"csv")||!strcmp(fbuf,"tsv")) res=convert_csv(input,tbuf);
  else if(!strcmp(tbuf,"json")){ Str j={0}; sadd(&j,"{\"pandoc-api-version\":[1,23,1,1],\"meta\":{},\"blocks\":[{\"t\":\"Para\",\"c\":[{\"t\":\"Str\",\"c\":\""); char *pl=convert_markdown(input,"plain",0,0,NULL); esc_json(&j,trim(pl)); sadd(&j,"\"}]}]}\n"); free(pl); res=sfinish(&j); }
  else if(!strcmp(tbuf,"native")){ char *pl=convert_markdown(input,"plain",0,0,NULL); Str n={0}; sadd(&n,"[ Para [ Str \""); esc_json(&n,trim(pl)); sadd(&n,"\" ] ]\n"); free(pl); res=sfinish(&n); }
  else if(!strcmp(tbuf,"plain")||!strcmp(tbuf,"ansi")) res=convert_markdown(input,"plain",0,0,title);
  else res=convert_markdown(input,tbuf,standalone,toc,title);
  if(outfile){ FILE*f=fopen(outfile,"wb"); if(!f){perror(outfile);return 1;} fputs(res,f); fclose(f); } else fputs(res,stdout);
  free(res); free(input); for(int i=0;i<files.n;i++) free(files.v[i]); free(files.v); return 0;
}
