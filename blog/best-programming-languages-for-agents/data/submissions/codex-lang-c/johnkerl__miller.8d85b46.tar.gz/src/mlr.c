#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char *k, *v; } Field;
typedef struct { Field *f; int n, cap; } Rec;
typedef struct { Rec *r; int n, cap; } Table;

typedef enum { F_DKVP, F_CSV, F_TSV, F_NIDX } Format;
typedef enum { O_DKVP, O_CSV, O_TSV, O_PPRINT, O_JSON, O_JSONL, O_XTAB } OFormat;

static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(1);} return p; }
static void *xrealloc(void *p,size_t n){ void *q=realloc(p,n); if(!q&&n){perror("realloc"); exit(1);} return q; }
static void rec_add(Rec *r,const char*k,const char*v){ if(r->n==r->cap){r->cap=r->cap?r->cap*2:8; r->f=xrealloc(r->f,r->cap*sizeof(Field));} r->f[r->n].k=xstrdup(k); r->f[r->n].v=xstrdup(v); r->n++; }
static int rec_idx(const Rec*r,const char*k){ for(int i=0;i<r->n;i++) if(strcmp(r->f[i].k,k)==0) return i; return -1; }
static const char *rec_get(const Rec*r,const char*k){ int i=rec_idx(r,k); return i>=0?r->f[i].v:""; }
static void rec_set(Rec*r,const char*k,const char*v){ int i=rec_idx(r,k); if(i>=0){ free(r->f[i].v); r->f[i].v=xstrdup(v);} else rec_add(r,k,v); }
static void rec_free(Rec*r){ for(int i=0;i<r->n;i++){free(r->f[i].k); free(r->f[i].v);} free(r->f); r->f=NULL; r->n=r->cap=0; }
static Rec rec_clone(const Rec*r){ Rec o={0}; for(int i=0;i<r->n;i++) rec_add(&o,r->f[i].k,r->f[i].v); return o; }
static void table_add(Table*t,Rec r){ if(t->n==t->cap){t->cap=t->cap?t->cap*2:64; t->r=xrealloc(t->r,t->cap*sizeof(Rec));} t->r[t->n++]=r; }
static void table_free(Table*t){ for(int i=0;i<t->n;i++) rec_free(&t->r[i]); free(t->r); t->r=NULL; t->n=t->cap=0; }

static char *trim(char*s){ while(isspace((unsigned char)*s))s++; char*e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static int isnumstr(const char*s){ if(!s||!*s)return 0; char*e; errno=0; strtod(s,&e); return errno==0 && e>s && *e==0; }
static double numval(const char*s){ return strtod(s,NULL); }

static char **split_csv_line(const char *line, char sep, int *outn){
  int cap=8,n=0; char **a=xrealloc(NULL,cap*sizeof(char*)); const char*p=line;
  while(*p){
    if(n==cap){cap*=2; a=xrealloc(a,cap*sizeof(char*));}
    char *buf=xrealloc(NULL,strlen(p)+1); int bi=0;
    if(*p=='"'){
      p++;
      while(*p){ if(*p=='"'&&p[1]=='"'){buf[bi++]='"'; p+=2;} else if(*p=='"'){p++; break;} else buf[bi++]=*p++; }
      while(*p && *p!=sep && *p!='\n' && *p!='\r') p++;
    } else {
      while(*p && *p!=sep && *p!='\n' && *p!='\r') buf[bi++]=*p++;
    }
    buf[bi]=0; a[n++]=buf; if(*p==sep) p++;
  }
  if(n==0 || (line[0] && line[strlen(line)-1]==sep)){ if(n==cap){cap*=2; a=xrealloc(a,cap*sizeof(char*));} a[n++]=xstrdup(""); }
  *outn=n; return a;
}
static void free_words(char**a,int n){ for(int i=0;i<n;i++) free(a[i]); free(a); }

static Rec parse_dkvp(char *line){
  Rec r={0}; int idx=1; char *save=NULL;
  for(char *tok=strtok_r(line,",",&save); tok; tok=strtok_r(NULL,",",&save),idx++){
    char *eq=strchr(tok,'=');
    if(eq){ *eq=0; rec_add(&r,trim(tok),trim(eq+1)); }
    else { char k[32]; snprintf(k,sizeof(k),"%d",idx); rec_add(&r,k,trim(tok)); }
  }
  return r;
}
static Rec parse_nidx(char *line){
  Rec r={0}; int idx=1; char *save=NULL;
  for(char *tok=strtok_r(line," \t\r\n",&save); tok; tok=strtok_r(NULL," \t\r\n",&save),idx++){ char k[32]; snprintf(k,sizeof(k),"%d",idx); rec_add(&r,k,tok); }
  return r;
}

static void read_stream(FILE*fp,Format fmt,Table*t){
  char *line=NULL; size_t sz=0; ssize_t nr; char **hdr=NULL; int hn=0; int first=1; char sep=fmt==F_TSV?'\t':',';
  while((nr=getline(&line,&sz,fp))!=-1){
    while(nr>0 && (line[nr-1]=='\n'||line[nr-1]=='\r')) line[--nr]=0;
    if(first && (fmt==F_CSV||fmt==F_TSV)){ hdr=split_csv_line(line,sep,&hn); first=0; continue; }
    first=0; if(line[0]==0) continue;
    Rec r={0};
    if(fmt==F_CSV||fmt==F_TSV){ int n=0; char **v=split_csv_line(line,sep,&n); for(int i=0;i<n;i++){ char k[32]; const char *key=i<hn?hdr[i]:(snprintf(k,sizeof(k),"%d",i+1),k); rec_add(&r,key,v[i]); } free_words(v,n); }
    else if(fmt==F_NIDX) r=parse_nidx(line); else r=parse_dkvp(line);
    table_add(t,r);
  }
  if(hdr) free_words(hdr,hn); free(line);
}

static void read_files(Table*t,Format fmt,int nfiles,char**files){
  if(nfiles==0) read_stream(stdin,fmt,t);
  for(int i=0;i<nfiles;i++){ FILE*fp=fopen(files[i],"r"); if(!fp){ fprintf(stderr,"mlr: couldn't open \"%s\": %s\n",files[i],strerror(errno)); exit(1);} read_stream(fp,fmt,t); fclose(fp); }
}

typedef struct { char **v; int n,cap; } Strs;
static int strs_has(Strs*s,const char*x){ for(int i=0;i<s->n;i++) if(strcmp(s->v[i],x)==0)return 1; return 0; }
static void strs_add(Strs*s,const char*x){ if(strs_has(s,x))return; if(s->n==s->cap){s->cap=s->cap?2*s->cap:16; s->v=xrealloc(s->v,s->cap*sizeof(char*));} s->v[s->n++]=xstrdup(x); }
static Strs schema(Table*t){ Strs s={0}; for(int i=0;i<t->n;i++) for(int j=0;j<t->r[i].n;j++) strs_add(&s,t->r[i].f[j].k); return s; }
static void strs_free(Strs*s){ for(int i=0;i<s->n;i++) free(s->v[i]); free(s->v); }

static char **parse_list(const char*s,int*n){ char *tmp=xstrdup(s); int cap=8,c=0; char**a=xrealloc(NULL,cap*sizeof(char*)); char*save=NULL; for(char*tok=strtok_r(tmp,",",&save);tok;tok=strtok_r(NULL,",",&save)){ if(c==cap){cap*=2;a=xrealloc(a,cap*sizeof(char*));} a[c++]=xstrdup(trim(tok)); } free(tmp); *n=c; return a; }
static void replace_table(Table*t,Table*n){ table_free(t); *t=*n; }

static void verb_cut(Table*t,const char*fields,int exclude){
  int nf=0; char**fs=parse_list(fields?fields:"",&nf); Table nt={0};
  for(int i=0;i<t->n;i++){ Rec r={0}; if(exclude){ for(int j=0;j<t->r[i].n;j++){ int drop=0; for(int k=0;k<nf;k++) if(strcmp(t->r[i].f[j].k,fs[k])==0) drop=1; if(!drop) rec_add(&r,t->r[i].f[j].k,t->r[i].f[j].v); } } else { for(int k=0;k<nf;k++){ int ix=rec_idx(&t->r[i],fs[k]); if(ix>=0) rec_add(&r,fs[k],t->r[i].f[ix].v); } } table_add(&nt,r); }
  free_words(fs,nf); replace_table(t,&nt);
}
static void verb_head(Table*t,int n){ if(n<0)n=10; if(t->n>n){ for(int i=n;i<t->n;i++) rec_free(&t->r[i]); t->n=n; } }
static void verb_tail(Table*t,int n){ if(n<0)n=10; if(n>=t->n)return; Table nt={0}; for(int i=t->n-n;i<t->n;i++) table_add(&nt,rec_clone(&t->r[i])); replace_table(t,&nt); }

static const char *g_sort_field; static int g_sort_num,g_sort_rev;
static int rec_cmp(const void*a,const void*b){ const Rec*ra=a,*rb=b; const char*va=rec_get(ra,g_sort_field),*vb=rec_get(rb,g_sort_field); int c; if(g_sort_num){ double da=numval(va),db=numval(vb); c=(da>db)-(da<db); } else c=strcmp(va,vb); return g_sort_rev?-c:c; }
static void verb_sort(Table*t,const char*field,int num,int rev){ if(!field)return; g_sort_field=field; g_sort_num=num; g_sort_rev=rev; qsort(t->r,t->n,sizeof(Rec),rec_cmp); }

static int eval_filter(Rec*r,const char*expr){
  char buf[1024]; snprintf(buf,sizeof(buf),"%s",expr); char *s=trim(buf); if(*s=='(')s++;
  if(*s=='$')s++; char *ops[]={"==","!=",">=","<=","=~",">","<",NULL}; char *op=NULL,*pos=NULL;
  for(int i=0;ops[i];i++){ pos=strstr(s,ops[i]); if(pos){op=ops[i];break;} }
  if(!op) return 1; *pos=0; char *field=trim(s); char *rhs=trim(pos+strlen(op)); size_t l=strlen(rhs); if((rhs[0]=='"'&&rhs[l-1]=='"')||(rhs[0]=='\''&&rhs[l-1]=='\'')){ rhs[l-1]=0; rhs++; }
  const char *v=rec_get(r,field); int cmp=strcmp(v,rhs); if(strcmp(op,"==")==0)return cmp==0; if(strcmp(op,"!=")==0)return cmp!=0; if(strcmp(op,"=~")==0)return strstr(v,rhs)!=NULL;
  double a=numval(v),b=numval(rhs); if(strcmp(op,">")==0)return a>b; if(strcmp(op,"<")==0)return a<b; if(strcmp(op,">=")==0)return a>=b; if(strcmp(op,"<=")==0)return a<=b; return 0;
}
static void verb_filter(Table*t,const char*expr){ Table nt={0}; for(int i=0;i<t->n;i++) if(eval_filter(&t->r[i],expr)) table_add(&nt,rec_clone(&t->r[i])); replace_table(t,&nt); }

static double eval_arith(Rec*r,const char*e){
  char buf[1024]; snprintf(buf,sizeof(buf),"%s",e); char *ops="+-*/"; for(char*p=buf;*p;p++){ if(strchr(ops,*p) && p!=buf){ char op=*p; *p=0; char *a=trim(buf),*b=trim(p+1); double x=(*a=='$')?numval(rec_get(r,a+1)):numval(a); double y=(*b=='$')?numval(rec_get(r,b+1)):numval(b); if(op=='+')return x+y; if(op=='-')return x-y; if(op=='*')return x*y; if(op=='/')return y==0?NAN:x/y; } }
  char *a=trim(buf); return (*a=='$')?numval(rec_get(r,a+1)):numval(a);
}
static void fmt_num(char*out,size_t n,double x){ if(isnan(x)) snprintf(out,n,"nan"); else { snprintf(out,n,"%.12g",x); } }
static void verb_put(Table*t,const char*expr){
  char buf[1024]; snprintf(buf,sizeof(buf),"%s",expr); char *eq=strchr(buf,'='); if(!eq)return; *eq=0; char *lhs=trim(buf); if(*lhs=='$')lhs++; char *rhs=trim(eq+1);
  for(int i=0;i<t->n;i++){ char v[128]; fmt_num(v,sizeof(v),eval_arith(&t->r[i],rhs)); rec_set(&t->r[i],lhs,v); }
}

static void verb_count(Table*t){ char v[64]; snprintf(v,sizeof(v),"%d",t->n); Table nt={0}; Rec r={0}; rec_add(&r,"count",v); table_add(&nt,r); replace_table(t,&nt); }
static void verb_stats1(Table*t,const char*accs,const char*fields){
  int na=0,nf=0; char**as=parse_list(accs?accs:"count",&na); char**fs=parse_list(fields?fields:"",&nf); Rec out={0};
  for(int f=0;f<nf;f++){ double minv=0,maxv=0,sum=0; int cnt=0; for(int i=0;i<t->n;i++){ const char*v=rec_get(&t->r[i],fs[f]); if(!isnumstr(v))continue; double x=numval(v); if(cnt==0||x<minv)minv=x; if(cnt==0||x>maxv)maxv=x; sum+=x; cnt++; }
    for(int a=0;a<na;a++){ char key[256],val[128]; snprintf(key,sizeof(key),"%s_%s",fs[f],as[a]); if(strcmp(as[a],"min")==0)fmt_num(val,sizeof(val),minv); else if(strcmp(as[a],"max")==0)fmt_num(val,sizeof(val),maxv); else if(strcmp(as[a],"mean")==0)fmt_num(val,sizeof(val),cnt?sum/cnt:NAN); else if(strcmp(as[a],"sum")==0)fmt_num(val,sizeof(val),sum); else if(strcmp(as[a],"count")==0)snprintf(val,sizeof(val),"%d",cnt); else fmt_num(val,sizeof(val),cnt?sum/cnt:NAN); rec_add(&out,key,val); }
  }
  Table nt={0}; table_add(&nt,out); free_words(as,na); free_words(fs,nf); replace_table(t,&nt);
}

static void csv_print_cell(const char*s,char sep){ int q=0; for(const char*p=s;*p;p++) if(*p==sep||*p=='"'||*p=='\n'||*p=='\r') q=1; if(!q){ fputs(s,stdout); return;} putchar('"'); for(const char*p=s;*p;p++){ if(*p=='"') putchar('"'); putchar(*p);} putchar('"'); }
static void output_csv(Table*t,char sep){
  Strs s=schema(t); for(int i=0;i<s.n;i++){ if(i)putchar(sep); csv_print_cell(s.v[i],sep);} putchar('\n');
  for(int r=0;r<t->n;r++){ for(int i=0;i<s.n;i++){ if(i)putchar(sep); csv_print_cell(rec_get(&t->r[r],s.v[i]),sep);} putchar('\n'); } strs_free(&s);
}
static void output_dkvp(Table*t){ for(int r=0;r<t->n;r++){ for(int i=0;i<t->r[r].n;i++){ if(i)putchar(','); printf("%s=%s",t->r[r].f[i].k,t->r[r].f[i].v);} putchar('\n'); } }
static void output_pprint(Table*t){
  Strs s=schema(t); int *w=calloc(s.n,sizeof(int)); for(int i=0;i<s.n;i++)w[i]=strlen(s.v[i]); for(int r=0;r<t->n;r++)for(int i=0;i<s.n;i++){ int l=strlen(rec_get(&t->r[r],s.v[i])); if(l>w[i])w[i]=l; }
  for(int i=0;i<s.n;i++){ if(i)putchar(' '); if(i==s.n-1) printf("%s",s.v[i]); else printf("%-*s",w[i],s.v[i]); } putchar('\n');
  for(int r=0;r<t->n;r++){ for(int i=0;i<s.n;i++){ if(i)putchar(' '); if(i==s.n-1) printf("%s",rec_get(&t->r[r],s.v[i])); else printf("%-*s",w[i],rec_get(&t->r[r],s.v[i])); } putchar('\n'); }
  free(w); strs_free(&s);
}
static void json_str(const char*s){ putchar('"'); for(const char*p=s;*p;p++){ if(*p=='"'||*p=='\\')printf("\\%c",*p); else if(*p=='\n')printf("\\n"); else putchar(*p);} putchar('"'); }
static void json_val(const char*s){ if(isnumstr(s)) fputs(s,stdout); else json_str(s); }
static void output_json(Table*t,int lines){
  if(!lines) puts("[");
  for(int r=0;r<t->n;r++){ if(!lines) puts("{"); else putchar('{');
    for(int i=0;i<t->r[r].n;i++){ if(lines){ if(i) printf(", "); } else if(i) puts(","); if(!lines) printf("  "); json_str(t->r[r].f[i].k); printf(": "); json_val(t->r[r].f[i].v); }
    if(lines) puts("}"); else { puts(""); printf("}%s\n",r==t->n-1?"":","); }
  }
  if(!lines) puts("]");
}
static void output_xtab(Table*t){ for(int r=0;r<t->n;r++){ int w=0; for(int i=0;i<t->r[r].n;i++){int l=strlen(t->r[r].f[i].k); if(l>w)w=l;} for(int i=0;i<t->r[r].n;i++)printf("%-*s %s\n",w,t->r[r].f[i].k,t->r[r].f[i].v); if(r!=t->n-1)putchar('\n'); } }

static void usage(void){
  puts("Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}\n");
  puts("If zero file names are provided, standard input is read, e.g.");
  puts("  mlr --csv sort -f shape example.csv\n");
  puts("Output of one verb may be chained as input to another using \"then\", e.g.");
  puts("  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv\n");
  puts("Please see 'mlr help topics' for more information.");
  puts("Please also see https://miller.readthedocs.io");
}
static void topics(void){ puts("Type 'mlr help {topic}' for any of the following:\nEssentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats\nFlags:\n  mlr help flags\nVerbs:\n  mlr help list-verbs\n  mlr help usage-verbs\n  mlr help verb\nFunctions:\n  mlr help list-functions\nKeywords:\n  mlr help list-keywords"); }
static void list_verbs(void){ puts("altkv\nbar\nbootstrap\ncase\ncat\ncheck\nclean-whitespace\ncount-distinct\ncount\ncut\nfilter\ngrep\ngroup-by\nhead\njoin\nlabel\nnothing\nput\nsort\nstats1\ntac\ntail\ntop\nuniq"); }

int main(int argc,char**argv){
  Format ifmt=F_DKVP; OFormat ofmt=O_DKVP; char **files=xrealloc(NULL,argc*sizeof(char*)); int nfiles=0; int i=1;
  if(argc==1){ usage(); return 0; }
  for(;i<argc;i++){
    char*a=argv[i];
    if(strcmp(a,"--help")==0||strcmp(a,"-h")==0){usage();return 0;} if(strcmp(a,"--version")==0){puts("mlr 6.16.0");return 0;}
    if(strcmp(a,"help")==0){ if(i+1<argc && strcmp(argv[i+1],"topics")==0)topics(); else if(i+1<argc && strcmp(argv[i+1],"list-verbs")==0)list_verbs(); else usage(); return 0; }
    if(strcmp(a,"-l")==0){list_verbs();return 0;}
    if(strcmp(a,"--csv")==0||strcmp(a,"-c")==0||strcmp(a,"--c2c")==0){ifmt=F_CSV;ofmt=O_CSV;continue;} if(strcmp(a,"--tsv")==0){ifmt=F_TSV;ofmt=O_TSV;continue;} if(strcmp(a,"--dkvp")==0){ifmt=F_DKVP;ofmt=O_DKVP;continue;} if(strcmp(a,"--nidx")==0){ifmt=F_NIDX;ofmt=O_DKVP;continue;}
    if(strcmp(a,"--icsv")==0){ifmt=F_CSV;continue;} if(strcmp(a,"--itsv")==0){ifmt=F_TSV;continue;} if(strcmp(a,"--idkvp")==0){ifmt=F_DKVP;continue;} if(strcmp(a,"--inidx")==0){ifmt=F_NIDX;continue;}
    if(strcmp(a,"--ocsv")==0){ofmt=O_CSV;continue;} if(strcmp(a,"--otsv")==0){ofmt=O_TSV;continue;} if(strcmp(a,"--odkvp")==0){ofmt=O_DKVP;continue;} if(strcmp(a,"--opprint")==0){ofmt=O_PPRINT;continue;} if(strcmp(a,"--ojson")==0){ofmt=O_JSON;continue;} if(strcmp(a,"--ojsonl")==0){ofmt=O_JSONL;continue;} if(strcmp(a,"--oxtab")==0){ofmt=O_XTAB;continue;}
    if(strcmp(a,"--from")==0 && i+1<argc){ files[nfiles++]=argv[++i]; continue; }
    if(a[0]=='-') continue; break;
  }
  int verb_start=i; int file_start=argc;
  for(int j=verb_start;j<argc;j++){
    if(strcmp(argv[j],"then")==0) continue;
    if(strcmp(argv[j],"cat")==0||strcmp(argv[j],"cut")==0||strcmp(argv[j],"sort")==0||strcmp(argv[j],"head")==0||strcmp(argv[j],"tail")==0||strcmp(argv[j],"filter")==0||strcmp(argv[j],"put")==0||strcmp(argv[j],"stats1")==0||strcmp(argv[j],"count")==0||strcmp(argv[j],"nothing")==0||strcmp(argv[j],"tac")==0){
      if(strcmp(argv[j],"cut")==0){ j++; while(j<argc && strcmp(argv[j],"then")!=0){ if((strcmp(argv[j],"-f")==0||strcmp(argv[j],"--fields")==0) && j+1<argc) j+=2; else if(strcmp(argv[j],"-x")==0) j++; else { file_start=j; break; } } if(file_start!=argc) break; j--; continue; }
      if(strcmp(argv[j],"sort")==0){ j++; while(j<argc && strcmp(argv[j],"then")!=0){ if((strcmp(argv[j],"-f")==0||strcmp(argv[j],"-n")==0||strcmp(argv[j],"-nr")==0) && j+1<argc) j+=2; else { file_start=j; break; } } if(file_start!=argc) break; j--; continue; }
      if(strcmp(argv[j],"head")==0||strcmp(argv[j],"tail")==0){ j++; while(j<argc && strcmp(argv[j],"then")!=0){ if(strcmp(argv[j],"-n")==0 && j+1<argc) j+=2; else { file_start=j; break; } } if(file_start!=argc) break; j--; continue; }
      if(strcmp(argv[j],"filter")==0||strcmp(argv[j],"put")==0){ j+=1; if(j+1<argc && strcmp(argv[j+1],"then")!=0){ file_start=j+1; break; } continue; }
      if(strcmp(argv[j],"stats1")==0){ j++; while(j<argc && strcmp(argv[j],"then")!=0){ if((strcmp(argv[j],"-a")==0||strcmp(argv[j],"-f")==0) && j+1<argc) j+=2; else { file_start=j; break; } } if(file_start!=argc) break; j--; continue; }
      continue;
    } else { file_start=j; break; }
  }
  for(int j=file_start;j<argc;j++) files[nfiles++]=argv[j];
  Table t={0}; read_files(&t,ifmt,nfiles,files); free(files);
  for(int j=verb_start;j<file_start;j++){
    char*v=argv[j]; if(strcmp(v,"then")==0||strcmp(v,"cat")==0) continue; if(strcmp(v,"nothing")==0){ t.n=0; continue; }
    if(strcmp(v,"cut")==0){ const char*f=NULL; int ex=0; for(j++;j<file_start&&strcmp(argv[j],"then")!=0;j++){ if(strcmp(argv[j],"-x")==0)ex=1; else if((strcmp(argv[j],"-f")==0||strcmp(argv[j],"--fields")==0)&&j+1<file_start)f=argv[++j]; } j--; verb_cut(&t,f,ex); continue; }
    if(strcmp(v,"head")==0){ int n=10; for(j++;j<file_start&&strcmp(argv[j],"then")!=0;j++) if(strcmp(argv[j],"-n")==0&&j+1<file_start)n=atoi(argv[++j]); j--; verb_head(&t,n); continue; }
    if(strcmp(v,"tail")==0){ int n=10; for(j++;j<file_start&&strcmp(argv[j],"then")!=0;j++) if(strcmp(argv[j],"-n")==0&&j+1<file_start)n=atoi(argv[++j]); j--; verb_tail(&t,n); continue; }
    if(strcmp(v,"sort")==0){ const char*f=NULL; int num=0,rev=0; for(j++;j<file_start&&strcmp(argv[j],"then")!=0;j++){ if(strcmp(argv[j],"-f")==0&&j+1<file_start)f=argv[++j]; else if(strcmp(argv[j],"-n")==0&&j+1<file_start){num=1;f=argv[++j];} else if(strcmp(argv[j],"-nr")==0&&j+1<file_start){num=1;rev=1;f=argv[++j];} } j--; verb_sort(&t,f,num,rev); continue; }
    if(strcmp(v,"filter")==0 && j+1<file_start){ verb_filter(&t,argv[++j]); continue; }
    if(strcmp(v,"put")==0 && j+1<file_start){ verb_put(&t,argv[++j]); continue; }
    if(strcmp(v,"count")==0){ verb_count(&t); continue; }
    if(strcmp(v,"stats1")==0){ const char*a=NULL,*f=NULL; for(j++;j<file_start&&strcmp(argv[j],"then")!=0;j++){ if(strcmp(argv[j],"-a")==0&&j+1<file_start)a=argv[++j]; else if(strcmp(argv[j],"-f")==0&&j+1<file_start)f=argv[++j]; } j--; verb_stats1(&t,a,f); continue; }
    if(strcmp(v,"tac")==0){ for(int a=0,b=t.n-1;a<b;a++,b--){ Rec tmp=t.r[a]; t.r[a]=t.r[b]; t.r[b]=tmp; } continue; }
  }
  if(ofmt==O_CSV)output_csv(&t,','); else if(ofmt==O_TSV)output_csv(&t,'\t'); else if(ofmt==O_PPRINT)output_pprint(&t); else if(ofmt==O_JSON)output_json(&t,0); else if(ofmt==O_JSONL)output_json(&t,1); else if(ofmt==O_XTAB)output_xtab(&t); else output_dkvp(&t);
  table_free(&t); return 0;
}
