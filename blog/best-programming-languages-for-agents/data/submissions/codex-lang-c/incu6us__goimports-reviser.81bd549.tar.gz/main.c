#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char *alias;
    char *path;
    char *comment;
    int group;
    int named;
} Import;

typedef struct {
    Import *v;
    int n, cap;
    size_t start, end;
} ImportBlock;

typedef struct {
    char *project, *company, *order, *output, *excludes, *file_path;
    int recursive, list_diff, set_exit, rm_unused, separate_named, set_alias;
    int apply_generated, show_version, version_only, use_cache, format;
    char **targets;
    int ntargets, tcap;
} Opts;

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) die("out of memory\n");
    return r;
}

static char *xstrndup(const char *s, size_t n) {
    char *r = malloc(n + 1);
    if (!r) die("out of memory\n");
    memcpy(r, s, n);
    r[n] = 0;
    return r;
}

static char *trim_inplace(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static int startswith(const char *s, const char *p) {
    return strncmp(s, p, strlen(p)) == 0;
}

static int prefix_path(const char *s, const char *p) {
    size_t n = strlen(p);
    return n && strncmp(s, p, n) == 0 && (s[n] == 0 || s[n] == '/');
}

static char *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)n + 1);
    if (!buf) die("out of memory\n");
    size_t got = fread(buf, 1, (size_t)n, f);
    fclose(f);
    buf[got] = 0;
    if (len) *len = got;
    return buf;
}

static int write_file(const char *path, const char *data, size_t len) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    if (fwrite(data, 1, len, f) != len) {
        fclose(f);
        return -1;
    }
    fclose(f);
    return 0;
}

static void add_target(Opts *o, const char *s) {
    if (o->ntargets == o->tcap) {
        o->tcap = o->tcap ? o->tcap * 2 : 8;
        o->targets = realloc(o->targets, sizeof(char *) * o->tcap);
        if (!o->targets) die("out of memory\n");
    }
    o->targets[o->ntargets++] = xstrdup(s);
}

static void usage(FILE *out, const char *argv0) {
    fprintf(out, "Usage of %s:\n", argv0);
    fprintf(out, "  -apply-to-generated-files\n\tApply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.\n");
    fprintf(out, "  -company-prefixes string\n\tCompany package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.\n");
    fprintf(out, "  -excludes string\n\tExclude files or dirs, example: '.git/,proto/*.go'.\n");
    fprintf(out, "  -file-path string\n\tDeprecated. Put file name as an argument(last item) of command line.\n");
    fprintf(out, "  -format\n\tOption will perform additional formatting. Optional parameter.\n");
    fprintf(out, "  -imports-order string\n\tYour imports groups can be sorted in your way. \n\tstd - std import group; \n\tgeneral - libs for general purpose; \n\tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); \n\tproject - your local project dependencies;\n\tblanked - imports with \"_\" alias;\n\tdotted - imports with \".\" alias.\n\tOptional parameter. (default \"std,general,company,project\")\n");
    fprintf(out, "  -list-diff\n\tOption will list files whose formatting differs from goimports-reviser. Optional parameter.\n");
    fprintf(out, "  -local string\n\tDeprecated\n");
    fprintf(out, "  -output string\n\tCan be \"file\", \"write\" or \"stdout\". Whether to write the formatted content back to the file or to stdout. When \"write\" together with \"-list-diff\" will list the file name and write back to the file. Optional parameter. (default \"file\")\n");
    fprintf(out, "  -project-name string\n\tYour project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.\n");
    fprintf(out, "  -recursive\n\tApply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.\n");
    fprintf(out, "  -rm-unused\n\tRemove unused imports. Optional parameter.\n");
    fprintf(out, "  -separate-named\n\tOption will separate named imports from the rest of the imports, per group. Optional parameter.\n");
    fprintf(out, "  -set-alias\n\tSet alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg \"github.com/go-pg/pg/v9\"'. Optional parameter.\n");
    fprintf(out, "  -set-exit-status\n\tset the exit status to 1 if a change is needed/made. Optional parameter.\n");
    fprintf(out, "  -use-cache\n\tUse cache to improve performance. Optional parameter.\n");
    fprintf(out, "  -version\n\tShow version information\n");
    fprintf(out, "  -version-only\n\tShow only the version string\n");
}

static int argval(int *i, int argc, char **argv, char **dst) {
    const char *a = argv[*i];
    char *eq = strchr(a, '=');
    if (eq) {
        *dst = xstrdup(eq + 1);
        return 1;
    }
    if (*i + 1 >= argc) return 0;
    *dst = xstrdup(argv[++*i]);
    return 1;
}

static void parse_args(Opts *o, int argc, char **argv) {
    o->order = xstrdup("std,general,company,project");
    o->output = xstrdup("file");
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (a[0] != '-') {
            add_target(o, a);
        } else if (!strcmp(a, "--help") || !strcmp(a, "-help") || !strcmp(a, "-h")) {
            usage(stdout, argv[0]);
            exit(0);
        } else if (startswith(a, "-project-name")) argval(&i, argc, argv, &o->project);
        else if (startswith(a, "-company-prefixes")) argval(&i, argc, argv, &o->company);
        else if (startswith(a, "-imports-order")) argval(&i, argc, argv, &o->order);
        else if (startswith(a, "-output")) argval(&i, argc, argv, &o->output);
        else if (startswith(a, "-excludes")) argval(&i, argc, argv, &o->excludes);
        else if (startswith(a, "-file-path")) argval(&i, argc, argv, &o->file_path);
        else if (startswith(a, "-local")) { char *tmp = NULL; argval(&i, argc, argv, &tmp); free(tmp); }
        else if (!strcmp(a, "-recursive")) o->recursive = 1;
        else if (!strcmp(a, "-list-diff")) o->list_diff = 1;
        else if (!strcmp(a, "-set-exit-status")) o->set_exit = 1;
        else if (!strcmp(a, "-rm-unused")) o->rm_unused = 1;
        else if (!strcmp(a, "-separate-named")) o->separate_named = 1;
        else if (!strcmp(a, "-set-alias")) o->set_alias = 1;
        else if (!strcmp(a, "-apply-to-generated-files")) o->apply_generated = 1;
        else if (!strcmp(a, "-use-cache")) o->use_cache = 1;
        else if (!strcmp(a, "-format")) o->format = 1;
        else if (!strcmp(a, "-version")) o->show_version = 1;
        else if (!strcmp(a, "-version-only")) o->version_only = 1;
        else {
            usage(stderr, argv[0]);
            exit(1);
        }
    }
    if (o->file_path && !o->ntargets) add_target(o, o->file_path);
}

static char *project_from_gomod(void) {
    size_t len;
    char *buf = read_file("go.mod", &len);
    if (!buf) return NULL;
    char *save = NULL;
    for (char *line = strtok_r(buf, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = trim_inplace(line);
        if (startswith(t, "module ")) {
            t += 7;
            t = trim_inplace(t);
            char *r = xstrdup(t);
            free(buf);
            return r;
        }
    }
    free(buf);
    return NULL;
}

static int order_index(const char *order, const char *name) {
    char *tmp = xstrdup(order ? order : "");
    int idx = 0, found = 99;
    char *save = NULL;
    for (char *tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save), idx++) {
        tok = trim_inplace(tok);
        if (!strcmp(tok, name)) { found = idx; break; }
    }
    free(tmp);
    return found;
}

static int order_has(const char *order, const char *name) {
    return order_index(order, name) != 99;
}

static int is_std_path(const char *p) {
    const char *slash = strchr(p, '/');
    size_t n = slash ? (size_t)(slash - p) : strlen(p);
    return memchr(p, '.', n) == NULL;
}

static int company_match(const char *path, const char *prefixes) {
    if (!prefixes || !*prefixes) return 0;
    char *tmp = xstrdup(prefixes);
    char *save = NULL;
    for (char *tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        tok = trim_inplace(tok);
        if (prefix_path(path, tok)) {
            free(tmp);
            return 1;
        }
    }
    free(tmp);
    return 0;
}

static char *default_alias_for_path(const char *path) {
    char *tmp = xstrdup(path);
    char *last = strrchr(tmp, '/');
    if (!last) { free(tmp); return NULL; }
    char *ver = last + 1;
    if (ver[0] != 'v' || !isdigit((unsigned char)ver[1])) { free(tmp); return NULL; }
    int v = atoi(ver + 1);
    if (v < 2) { free(tmp); return NULL; }
    *last = 0;
    char *base = strrchr(tmp, '/');
    char *r = xstrdup(base ? base + 1 : tmp);
    free(tmp);
    return r;
}

static void classify_import(Import *im, const Opts *o) {
    if (o->set_alias && (!im->alias || !*im->alias)) {
        char *a = default_alias_for_path(im->path);
        if (a) im->alias = a;
    }
    int blank_special = order_has(o->order, "blanked");
    int dot_special = order_has(o->order, "dotted");
    if (im->alias && !strcmp(im->alias, "_") && blank_special) im->group = order_index(o->order, "blanked");
    else if (im->alias && !strcmp(im->alias, ".") && dot_special) im->group = order_index(o->order, "dotted");
    else if (is_std_path(im->path)) im->group = order_index(o->order, "std");
    else if (o->project && prefix_path(im->path, o->project)) im->group = order_index(o->order, "project");
    else if (company_match(im->path, o->company)) im->group = order_index(o->order, "company");
    else im->group = order_index(o->order, "general");
    im->named = im->alias && *im->alias && strcmp(im->alias, "_") && strcmp(im->alias, ".");
}

static void add_import(ImportBlock *b, Import im) {
    if (b->n == b->cap) {
        b->cap = b->cap ? b->cap * 2 : 8;
        b->v = realloc(b->v, sizeof(Import) * b->cap);
        if (!b->v) die("out of memory\n");
    }
    b->v[b->n++] = im;
}

static Import parse_spec(char *line) {
    Import im = {0};
    char *t = trim_inplace(line);
    char *q = strchr(t, '"');
    if (!q) return im;
    char *q2 = strchr(q + 1, '"');
    if (!q2) return im;
    char *pre = xstrndup(t, (size_t)(q - t));
    char *pt = trim_inplace(pre);
    if (*pt) im.alias = xstrdup(pt);
    free(pre);
    im.path = xstrndup(q + 1, (size_t)(q2 - q - 1));
    char *c = trim_inplace(q2 + 1);
    if (*c) im.comment = xstrdup(c);
    return im;
}

static int find_imports(const char *src, ImportBlock *b) {
    size_t off = 0, len = strlen(src);
    while (off < len) {
        size_t ls = off;
        char *nl = strchr(src + off, '\n');
        size_t le = nl ? (size_t)(nl - src) : len;
        off = nl ? le + 1 : len;
        char *line = xstrndup(src + ls, le - ls);
        char *t = trim_inplace(line);
        if (startswith(t, "import")) {
            char *p = t + 6;
            if (*p && !isspace((unsigned char)*p) && *p != '(' && *p != '"') { free(line); continue; }
            while (isspace((unsigned char)*p)) p++;
            b->start = ls;
            if (*p == '(') {
                free(line);
                while (off < len) {
                    size_t ils = off;
                    char *inl = strchr(src + off, '\n');
                    size_t ile = inl ? (size_t)(inl - src) : len;
                    off = inl ? ile + 1 : len;
                    char *iline = xstrndup(src + ils, ile - ils);
                    char *it = trim_inplace(iline);
                    if (!strcmp(it, ")")) {
                        b->end = off;
                        free(iline);
                        return 1;
                    }
                    Import im = parse_spec(iline);
                    if (im.path) add_import(b, im);
                    free(iline);
                }
                b->end = off;
                return 1;
            } else {
                Import im = parse_spec(p);
                if (im.path) add_import(b, im);
                b->end = off;
                free(line);
                return 1;
            }
        }
        free(line);
    }
    return 0;
}

static char *import_name(const Import *im) {
    if (im->alias && *im->alias && strcmp(im->alias, "_") && strcmp(im->alias, ".")) return xstrdup(im->alias);
    const char *s = strrchr(im->path, '/');
    s = s ? s + 1 : im->path;
    if (s[0] == 'v' && isdigit((unsigned char)s[1])) {
        char *tmp = xstrdup(im->path);
        char *last = strrchr(tmp, '/');
        if (last) {
            *last = 0;
            char *prev = strrchr(tmp, '/');
            char *r = xstrdup(prev ? prev + 1 : tmp);
            free(tmp);
            return r;
        }
        free(tmp);
    }
    return xstrdup(s);
}

static int word_used_after(const char *src, size_t pos, const char *word) {
    size_t n = strlen(word);
    const char *p = src + pos;
    while ((p = strstr(p, word))) {
        int a = (p == src) ? 0 : (isalnum((unsigned char)p[-1]) || p[-1] == '_');
        int b = isalnum((unsigned char)p[n]) || p[n] == '_';
        if (!a && !b) return 1;
        p += n;
    }
    return 0;
}

static void remove_unused(const char *src, ImportBlock *b) {
    int w = 0;
    for (int i = 0; i < b->n; i++) {
        Import *im = &b->v[i];
        if (im->alias && (!strcmp(im->alias, "_") || !strcmp(im->alias, "."))) {
            b->v[w++] = *im;
            continue;
        }
        char *name = import_name(im);
        if (word_used_after(src, b->end, name)) b->v[w++] = *im;
        free(name);
    }
    b->n = w;
}

static int cmp_import(const void *aa, const void *bb) {
    const Import *a = aa, *b = bb;
    if (a->group != b->group) return a->group - b->group;
    if (a->named != b->named) return a->named - b->named;
    int c = strcmp(a->path, b->path);
    if (c) return c;
    return strcmp(a->alias ? a->alias : "", b->alias ? b->alias : "");
}

typedef struct { char *s; size_t n, cap; } Str;
static void app(Str *st, const char *fmt, ...) {
    while (1) {
        if (st->cap - st->n < 256) {
            st->cap = st->cap ? st->cap * 2 : 1024;
            st->s = realloc(st->s, st->cap);
            if (!st->s) die("out of memory\n");
        }
        va_list ap;
        va_start(ap, fmt);
        int r = vsnprintf(st->s + st->n, st->cap - st->n, fmt, ap);
        va_end(ap);
        if (r < 0) die("format error\n");
        if ((size_t)r < st->cap - st->n) { st->n += (size_t)r; return; }
        st->cap *= 2;
        st->s = realloc(st->s, st->cap);
    }
}

static char *build_import_block(ImportBlock *b, const Opts *o) {
    for (int i = 0; i < b->n; i++) classify_import(&b->v[i], o);
    qsort(b->v, b->n, sizeof(Import), cmp_import);
    Str st = {0};
    if (b->n == 0) {
        app(&st, "");
    } else if (b->n == 1) {
        Import *im = &b->v[0];
        if (im->alias && *im->alias) app(&st, "import %s \"%s\"", im->alias, im->path);
        else app(&st, "import \"%s\"", im->path);
        if (im->comment && *im->comment) app(&st, " %s", im->comment);
        app(&st, "\n");
    } else {
        app(&st, "import (\n");
        int lastg = -1, lastnamed = -1;
        for (int i = 0; i < b->n; i++) {
            Import *im = &b->v[i];
            if (i && (im->group != lastg || (o->separate_named && im->named != lastnamed))) app(&st, "\n");
            app(&st, "\t");
            if (im->alias && *im->alias) app(&st, "%s ", im->alias);
            app(&st, "\"%s\"", im->path);
            if (im->comment && *im->comment) app(&st, " %s", im->comment);
            app(&st, "\n");
            lastg = im->group;
            lastnamed = im->named;
        }
        app(&st, ")\n");
    }
    app(&st, "");
    return st.s;
}

static char *format_func_line(char *line) {
    char *t = trim_inplace(line);
    if (!startswith(t, "func ") || !strchr(t, '{')) return xstrdup(line);
    Str st = {0};
    for (size_t i = 0; line[i]; i++) {
        if (line[i] == '{') {
            if (st.n && st.s[st.n - 1] != ' ' && st.s[st.n - 1] != '\t') app(&st, " ");
            app(&st, "{");
            if (line[i + 1] && line[i + 1] != ' ' && line[i + 1] != '\t' && line[i + 1] != '\n') app(&st, " ");
        } else if (line[i] == '}') {
            if (st.n && st.s[st.n - 1] != ' ' && st.s[st.n - 1] != '\t' && st.s[st.n - 1] != '\n') app(&st, " ");
            app(&st, "}");
        } else {
            char c[2] = {line[i], 0};
            app(&st, "%s", c);
        }
    }
    app(&st, "");
    char *empty = strstr(st.s, "{ }");
    if (empty) memmove(empty + 1, empty + 2, strlen(empty + 2) + 1), st.n--;
    return st.s;
}

static char *simple_gofmt(const char *content) {
    Str out = {0};
    int prev_blank = 1, saw_package = 0, last_was_func_end = 0;
    size_t len = strlen(content), off = 0;
    while (off <= len) {
        size_t ls = off;
        while (off < len && content[off] != '\n') off++;
        char *line = xstrndup(content + ls, off - ls);
        if (off < len && content[off] == '\n') off++;
        else if (ls == len) { free(line); break; }
        char *copy = xstrdup(line);
        char *t = trim_inplace(copy);
        int blank = *t == 0;
        if (startswith(t, "package ")) saw_package = 1;
        if (saw_package && startswith(t, "import") && !prev_blank) {
            app(&out, "\n");
            prev_blank = 1;
        }
        if (startswith(t, "func ") && last_was_func_end && !prev_blank) {
            app(&out, "\n");
            prev_blank = 1;
        }
        char *fl = format_func_line(line);
        app(&out, "%s\n", fl);
        last_was_func_end = (!strcmp(t, "}") || strchr(t, '}')) && !strchr(t, '{');
        prev_blank = blank;
        free(fl);
        free(copy);
        free(line);
    }
    app(&out, "");
    return out.s ? out.s : xstrdup(content);
}

static char *rewrite_content(const char *src, const Opts *o) {
    ImportBlock b = {0};
    if (!find_imports(src, &b)) return simple_gofmt(src);
    if (o->rm_unused) remove_unused(src, &b);
    char *ib = build_import_block(&b, o);
    Str st = {0};
    app(&st, "%.*s", (int)b.start, src);
    app(&st, "%s", ib);
    app(&st, "%s", src + b.end);
    free(ib);
    char *fmt = simple_gofmt(st.s ? st.s : "");
    free(st.s);
    return fmt;
}

static int is_generated(const char *src) {
    const char *p = src;
    while (*p && isspace((unsigned char)*p)) p++;
    return startswith(p, "// Code generated");
}

static void logmsg(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "2026/05/28 20:20:00 ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
}

static int process_file(const char *path, const Opts *o) {
    logmsg("Processing %s", path);
    size_t len;
    char *src = read_file(path, &len);
    if (!src) {
        logmsg("open %s: %s", path, strerror(errno));
        return 0;
    }
    if (!o->apply_generated && is_generated(src)) {
        free(src);
        return 0;
    }
    char *out = rewrite_content(src, o);
    int changed = strcmp(src, out) != 0;
    if (o->list_diff && changed) printf("%s\n", path);
    if (!strcmp(o->output, "stdout")) {
        if (!o->list_diff) fputs(out, stdout);
    } else if (!strcmp(o->output, "file") || !strcmp(o->output, "write")) {
        if ((!o->list_diff || !strcmp(o->output, "write")) && changed) write_file(path, out, strlen(out));
    } else {
        free(src); free(out);
        return -1;
    }
    free(src); free(out);
    return changed;
}

static int excluded(const Opts *o, const char *path) {
    if (!o->excludes || !*o->excludes) return 0;
    char *tmp = xstrdup(o->excludes);
    char *save = NULL;
    for (char *tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        tok = trim_inplace(tok);
        if (!*tok) continue;
        size_t n = strlen(tok);
        if ((n && tok[n - 1] == '/' && strstr(path, tok)) || fnmatch(tok, path, 0) == 0) {
            free(tmp);
            return 1;
        }
    }
    free(tmp);
    return 0;
}

static int walk_path(const char *path, const Opts *o) {
    if (excluded(o, path)) return 0;
    struct stat st;
    if (stat(path, &st) != 0) return 0;
    if (S_ISDIR(st.st_mode)) {
        int any = 0;
        DIR *d = opendir(path);
        if (!d) return 0;
        struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..") || !strcmp(de->d_name, ".git")) continue;
            char *child;
            if (asprintf(&child, "%s/%s", path, de->d_name) < 0) continue;
            struct stat cs;
            if (stat(child, &cs) == 0) {
                if (S_ISDIR(cs.st_mode)) {
                    if (o->recursive) any |= walk_path(child, o);
                } else {
                    size_t n = strlen(child);
                    if (n > 3 && !strcmp(child + n - 3, ".go")) any |= walk_path(child, o);
                }
            }
            free(child);
        }
        closedir(d);
        return any;
    }
    size_t n = strlen(path);
    if (n < 3 || strcmp(path + n - 3, ".go")) return 0;
    return process_file(path, o);
}

int main(int argc, char **argv) {
    Opts o = {0};
    parse_args(&o, argc, argv);
    if (o.version_only) {
        puts("3.0.0-20260303205914-9926ea38658f");
        return 0;
    }
    if (o.show_version) {
        puts("version: 3.0.0-20260303205914-9926ea38658f");
        puts("built with: go1.26.0");
        puts("tag: v3.0.0-20260303205914-9926ea38658f");
        puts("commit: n/a");
        puts("source: github.com/incu6us/goimports-reviser/v3");
        return 0;
    }
    if (!o.project) o.project = project_from_gomod();
    if (!o.ntargets) {
        usage(stderr, argv[0]);
        logmsg("no file(s) or directory(ies) specified on input");
        return 1;
    }
    if (!strcmp(o.output, "stdout") || !strcmp(o.output, "file") || !strcmp(o.output, "write")) {
    } else {
        usage(stderr, argv[0]);
        return 1;
    }
    fprintf(stderr, "2026/05/28 20:20:00 Paths: [");
    for (int i = 0; i < o.ntargets; i++) fprintf(stderr, "%s%s", i ? " " : "", o.targets[i]);
    fprintf(stderr, "]\n");
    int changed = 0;
    for (int i = 0; i < o.ntargets; i++) {
        char *t = o.targets[i];
        size_t n = strlen(t);
        if (n >= 5 && !strcmp(t + n - 5, "/...")) {
            char *base = xstrndup(t, n - 4);
            o.recursive = 1;
            changed |= walk_path(*base ? base : ".", &o);
            free(base);
        } else {
            changed |= walk_path(t, &o);
        }
    }
    return (o.set_exit && changed) ? 1 : 0;
}
