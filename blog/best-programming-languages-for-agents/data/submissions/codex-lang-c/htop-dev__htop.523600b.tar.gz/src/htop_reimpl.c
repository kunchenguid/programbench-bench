#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <pwd.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define VERSION "3.5.0-dev-878e0ce"

typedef struct {
    int pid;
    int ppid;
    uid_t uid;
    char user[32];
    char state;
    long priority;
    long nicev;
    unsigned long vsize;
    long rss;
    unsigned long utime;
    unsigned long stime;
    char command[512];
    char comm[128];
} Proc;

typedef struct {
    Proc *items;
    size_t len;
    size_t cap;
} ProcList;

static const char *sort_help =
"                PID Process/thread ID\n"
"            Command Command line (insert as last column only)\n"
"              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)\n"
"               PPID Parent process ID\n"
"               PGRP Process group ID\n"
"            SESSION Process's session ID\n"
"                TTY Controlling terminal\n"
"              TPGID Process ID of the fg process group of the controlling terminal\n"
"             MINFLT Number of minor faults which have not required loading a memory page from disk\n"
"            CMINFLT Children processes' minor faults\n"
"             MAJFLT Number of major faults which have required loading a memory page from disk\n"
"            CMAJFLT Children processes' major faults\n"
"              UTIME User CPU time - time the process spent executing in user mode\n"
"              STIME System CPU time - time the kernel spent running system calls for this process\n"
"             CUTIME Children processes' user CPU time\n"
"             CSTIME Children processes' system CPU time\n"
"           PRIORITY Kernel's internal priority for the process\n"
"               NICE Nice value (the higher the value, the more it lets other processes take priority)\n"
"          STARTTIME Time the process was started\n"
"          PROCESSOR Id of the CPU the process last executed on\n"
"             M_VIRT Total program size in virtual memory\n"
"         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage\n"
"            M_SHARE Size of the process's shared pages\n"
"              M_TRS Size of the .text segment of the process (CODE)\n"
"              M_DRS Size of the .data segment plus stack usage of the process (DATA)\n"
"              M_LRS The library size of the process (calculated from memory maps)\n"
"             ST_UID User ID of the process owner\n"
"        PERCENT_CPU Percentage of the CPU time the process used in the last sampling\n"
"        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size\n"
"               USER Username of the process owner (or user ID if name cannot be determined)\n"
"               TIME Total time the process has spent in user and system time\n"
"               NLWP Number of threads in the process\n"
"               TGID Thread group ID (i.e. process ID)\n"
"   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)\n"
"            ELAPSED Time since the process was started\n"
"    SCHEDULERPOLICY Current scheduling policy of the process\n"
"              RCHAR Number of bytes the process has read\n"
"              WCHAR Number of bytes the process has written\n"
"              SYSCR Number of read(2) syscalls for the process\n"
"              SYSCW Number of write(2) syscalls for the process\n"
"             RBYTES Bytes of read(2) I/O for the process\n"
"             WBYTES Bytes of write(2) I/O for the process\n"
"             CNCLWB Bytes of cancelled write(2) I/O\n"
"       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process\n"
"      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process\n"
"            IO_RATE Total I/O rate in bytes per second\n"
"             CGROUP Which cgroup the process is in\n"
"                OOM OOM (Out-of-Memory) killer score\n"
"        IO_PRIORITY I/O priority\n"
"              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it\n"
"             M_SWAP Size of the process's swapped pages\n"
"            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects\n"
"               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)\n"
"            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)\n"
"               COMM comm string of the process from /proc/[pid]/comm\n"
"                EXE Basename of exe of the process from /proc/[pid]/exe\n"
"                CWD The current working directory of the process\n"
"       AUTOGROUP_ID The autogroup identifier of the process\n"
"     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup\n"
"            CCGROUP Which cgroup the process is in (condensed to essentials)\n"
"          CONTAINER Name of the container the process is in (guessed by heuristics)\n"
"             M_PRIV The private memory size of the process - resident set size minus shared memory\n"
"           GPU_TIME Total GPU time\n"
"        GPU_PERCENT Percentage of the GPU time the process used in the last sampling\n"
"        ISCONTAINER Whether the process is running inside a child container\n";

static void print_version(void) {
    printf("htop %s\n", VERSION);
}

static void print_help(void) {
    printf("htop %s\n", VERSION);
    printf("(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.\n");
    printf("Released under the GNU GPLv2+.\n\n");
    printf("-C --no-color                   Use a monochrome color scheme\n");
    printf("-d --delay=DELAY                Set the delay between updates, in tenths of seconds\n");
    printf("-F --filter=FILTER              Show only the commands matching the given filter\n");
    printf("   --no-function-bar             Hide the function bar\n");
    printf("-h --help                       Print this help screen\n");
    printf("-H --highlight-changes[=DELAY]  Highlight new and old processes\n");
    printf("-M --no-mouse                   Disable the mouse\n");
    printf("   --no-meters                  Hide meters\n");
    printf("-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates\n");
    printf("-p --pid=PID[,PID,PID...]       Show only the given PIDs\n");
    printf("   --readonly                   Disable all system and process changing features\n");
    printf("-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)\n");
    printf("-t --tree                       Show the tree view (can be combined with -s)\n");
    printf("-u --user[=USERNAME]            Show only processes for a given user (or $USER)\n");
    printf("-U --no-unicode                 Do not use unicode but plain ASCII\n");
    printf("-V --version                    Print version info\n\n");
    printf("Press F1 inside htop for online help.\n");
    printf("See 'man htop' for more information.\n");
}

static bool parse_long(const char *s, long *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || end == s || *end)
        return false;
    *out = v;
    return true;
}

static bool valid_column(const char *s) {
    const char *cols[] = {
        "PID","Command","STATE","PPID","PGRP","SESSION","TTY","TPGID","MINFLT",
        "CMINFLT","MAJFLT","CMAJFLT","UTIME","STIME","CUTIME","CSTIME","PRIORITY",
        "NICE","STARTTIME","PROCESSOR","M_VIRT","M_RESIDENT","M_SHARE","M_TRS",
        "M_DRS","M_LRS","ST_UID","PERCENT_CPU","PERCENT_MEM","USER","TIME","NLWP",
        "TGID","PERCENT_NORM_CPU","ELAPSED","SCHEDULERPOLICY","RCHAR","WCHAR",
        "SYSCR","SYSCW","RBYTES","WBYTES","CNCLWB","IO_READ_RATE","IO_WRITE_RATE",
        "IO_RATE","CGROUP","OOM","IO_PRIORITY","M_PSS","M_SWAP","M_PSSWP","CTXT",
        "SECATTR","COMM","EXE","CWD","AUTOGROUP_ID","AUTOGROUP_NICE","CCGROUP",
        "CONTAINER","M_PRIV","GPU_TIME","GPU_PERCENT","ISCONTAINER", NULL
    };
    for (int i = 0; cols[i]; i++)
        if (strcasecmp(s, cols[i]) == 0)
            return true;
    return false;
}

static bool pid_selected(int pid, const char *pids) {
    if (!pids || !*pids)
        return true;
    const char *p = pids;
    while (*p) {
        while (*p == ',') p++;
        char *end = NULL;
        long v = strtol(p, &end, 10);
        if (end != p && v == pid)
            return true;
        p = end;
        while (*p && *p != ',') p++;
    }
    return false;
}

static bool contains_filter(const char *cmd, const char *filter) {
    if (!filter || !*filter)
        return true;
    char lower_cmd[512];
    snprintf(lower_cmd, sizeof(lower_cmd), "%s", cmd);
    for (char *p = lower_cmd; *p; p++)
        *p = (char)tolower((unsigned char)*p);
    char buf[256];
    snprintf(buf, sizeof(buf), "%s", filter);
    for (char *term = strtok(buf, "|"); term; term = strtok(NULL, "|")) {
        for (char *p = term; *p; p++)
            *p = (char)tolower((unsigned char)*p);
        if (strstr(lower_cmd, term))
            return true;
    }
    return false;
}

static void push_proc(ProcList *list, const Proc *p) {
    if (list->len == list->cap) {
        size_t nc = list->cap ? list->cap * 2 : 64;
        Proc *np = realloc(list->items, nc * sizeof(*np));
        if (!np)
            exit(2);
        list->items = np;
        list->cap = nc;
    }
    list->items[list->len++] = *p;
}

static void read_cmdline(int pid, char *buf, size_t size, const char *fallback) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
    FILE *f = fopen(path, "rb");
    if (!f) {
        snprintf(buf, size, "%s", fallback);
        return;
    }
    size_t n = fread(buf, 1, size - 1, f);
    fclose(f);
    if (n == 0) {
        snprintf(buf, size, "%s", fallback);
        return;
    }
    for (size_t i = 0; i < n; i++)
        if (buf[i] == '\0')
            buf[i] = ' ';
    buf[n] = '\0';
}

static bool read_proc(int pid, Proc *p) {
    char path[64], line[2048];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    FILE *f = fopen(path, "r");
    if (!f)
        return false;
    if (!fgets(line, sizeof(line), f)) {
        fclose(f);
        return false;
    }
    fclose(f);
    char *lp = strchr(line, '(');
    char *rp = strrchr(line, ')');
    if (!lp || !rp)
        return false;
    memset(p, 0, sizeof(*p));
    p->pid = pid;
    size_t clen = (size_t)(rp - lp - 1);
    if (clen >= sizeof(p->comm))
        clen = sizeof(p->comm) - 1;
    memcpy(p->comm, lp + 1, clen);
    p->comm[clen] = '\0';
    char *rest = rp + 2;
    sscanf(rest, "%c %d %*d %*d %*d %*d %*u %*lu %*lu %*lu %*lu %lu %lu %*ld %*ld %ld %ld %*ld %*ld %*llu %lu %ld",
           &p->state, &p->ppid, &p->utime, &p->stime, &p->priority, &p->nicev, &p->vsize, &p->rss);
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    f = fopen(path, "r");
    p->uid = 0;
    if (f) {
        while (fgets(line, sizeof(line), f)) {
            if (strncmp(line, "Uid:", 4) == 0) {
                unsigned u = 0;
                sscanf(line + 4, "%u", &u);
                p->uid = (uid_t)u;
                break;
            }
        }
        fclose(f);
    }
    struct passwd *pw = getpwuid(p->uid);
    if (pw)
        snprintf(p->user, sizeof(p->user), "%s", pw->pw_name);
    else
        snprintf(p->user, sizeof(p->user), "%u", (unsigned)p->uid);
    read_cmdline(pid, p->command, sizeof(p->command), p->comm);
    return true;
}

static int proc_cmp(const void *a, const void *b) {
    const Proc *pa = a, *pb = b;
    return (pa->pid > pb->pid) - (pa->pid < pb->pid);
}

static ProcList collect(const char *pid_filter, uid_t only_uid, bool use_uid, const char *filter) {
    ProcList list = {0};
    DIR *d = opendir("/proc");
    if (!d)
        return list;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!isdigit((unsigned char)de->d_name[0]))
            continue;
        int pid = atoi(de->d_name);
        if (!pid_selected(pid, pid_filter))
            continue;
        Proc p;
        if (!read_proc(pid, &p))
            continue;
        if (use_uid && p.uid != only_uid)
            continue;
        if (!contains_filter(p.command, filter))
            continue;
        push_proc(&list, &p);
    }
    closedir(d);
    qsort(list.items, list.len, sizeof(Proc), proc_cmp);
    return list;
}

static void fmt_mem(unsigned long bytes, char *buf, size_t size) {
    double v = (double)bytes;
    const char *u = "B";
    if (v > 1024) { v /= 1024; u = "K"; }
    if (v > 1024) { v /= 1024; u = "M"; }
    if (v > 1024) { v /= 1024; u = "G"; }
    if (v >= 10)
        snprintf(buf, size, "%.0f%s", v, u);
    else
        snprintf(buf, size, "%.1f%s", v, u);
}

static void render(const char *pid_filter, uid_t only_uid, bool use_uid, const char *filter, bool function_bar) {
    ProcList list = collect(pid_filter, only_uid, use_uid, filter);
    struct winsize ws;
    int rows = 24, cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0) {
        rows = ws.ws_row;
        cols = ws.ws_col ? ws.ws_col : 80;
    }
    printf("\033[?1049h\033[H\033[2J\033[?25l");
    long cpus = sysconf(_SC_NPROCESSORS_ONLN);
    if (cpus < 1) cpus = 1;
    printf("  htop %s", VERSION);
    for (long i = 0; i < cpus && i < 8; i++)
        printf("\n  %2ld[          0.0%%]", i);
    printf("\n  Tasks: %zu, 0 thr, 0 kthr; 1 running", list.len);
    double loads[3] = {0, 0, 0};
    getloadavg(loads, 3);
    printf("\n  Load average: %.2f %.2f %.2f", loads[0], loads[1], loads[2]);
    printf("\n\n  [Main] [I/O]\n");
    printf("  PID USER       PRI  NI   VIRT   RES S  CPU%% MEM%%   TIME+  Command\n");
    long page = sysconf(_SC_PAGESIZE);
    long ticks = sysconf(_SC_CLK_TCK);
    int max_lines = rows - (function_bar ? 12 : 10);
    if (max_lines < 1)
        max_lines = 1;
    for (size_t i = 0; i < list.len && (int)i < max_lines; i++) {
        Proc *p = &list.items[i];
        char virt[16], res[16], timebuf[32];
        fmt_mem(p->vsize, virt, sizeof(virt));
        fmt_mem((unsigned long)(p->rss > 0 ? p->rss : 0) * (unsigned long)page, res, sizeof(res));
        unsigned long secs = (p->utime + p->stime) / (unsigned long)(ticks > 0 ? ticks : 100);
        snprintf(timebuf, sizeof(timebuf), "%lu:%05.2f", secs / 60, (double)(secs % 60));
        printf("%5d %-10.10s %3ld %3ld %6s %5s %c %5.1f %4.1f %8s  %.*s\n",
               p->pid, p->user, p->priority, p->nicev, virt, res, p->state, 0.0, 0.0,
               timebuf, cols > 62 ? cols - 62 : 20, p->command);
    }
    if (function_bar)
        printf("\033[%d;1HF1Help  F2Setup F3Search F4Filter F5Tree  F6SortBy F7Nice - F8Nice + F9Kill  F10Quit", rows);
    printf("\033[?25h\033[?1049l\n");
    free(list.items);
}

int main(int argc, char **argv) {
    static struct option longopts[] = {
        {"no-color", no_argument, 0, 'C'},
        {"no-colour", no_argument, 0, 'C'},
        {"delay", required_argument, 0, 'd'},
        {"filter", required_argument, 0, 'F'},
        {"no-function-bar", no_argument, 0, 1000},
        {"help", no_argument, 0, 'h'},
        {"highlight-changes", optional_argument, 0, 'H'},
        {"no-mouse", no_argument, 0, 'M'},
        {"no-meters", no_argument, 0, 1001},
        {"max-iterations", required_argument, 0, 'n'},
        {"pid", required_argument, 0, 'p'},
        {"readonly", no_argument, 0, 1002},
        {"sort-key", required_argument, 0, 's'},
        {"tree", no_argument, 0, 't'},
        {"user", optional_argument, 0, 'u'},
        {"no-unicode", no_argument, 0, 'U'},
        {"version", no_argument, 0, 'V'},
        {0, 0, 0, 0}
    };
    int iterations = 0;
    const char *pid_filter = NULL;
    const char *filter = NULL;
    bool function_bar = true;
    bool use_uid = false;
    uid_t only_uid = 0;
    int c;
    while ((c = getopt_long(argc, argv, "Cd:F:hH::Mn:p:s:tu::UV", longopts, NULL)) != -1) {
        long v;
        switch (c) {
        case 'C': case 'M': case 't': case 'U':
        case 1001: case 1002:
            break;
        case 1000:
            function_bar = false;
            break;
        case 'd':
            if (!parse_long(optarg, &v)) {
                fprintf(stderr, "Error: invalid delay value \"%s\".\n", optarg);
                return 1;
            }
            break;
        case 'F':
            filter = optarg;
            break;
        case 'h':
            print_help();
            return 0;
        case 'H':
            if (!optarg && optind < argc && argv[optind][0] != '-')
                optarg = argv[optind++];
            if (optarg && !parse_long(optarg, &v)) {
                fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", optarg);
                return 1;
            }
            break;
        case 'n':
            if (!parse_long(optarg, &v)) {
                fprintf(stderr, "Error: invalid maximum iteration count \"%s\".\n", optarg);
                return 1;
            }
            iterations = (int)v;
            break;
        case 'p':
            pid_filter = optarg;
            break;
        case 's':
            if (strcmp(optarg, "help") == 0) {
                fputs(sort_help, stdout);
                return 0;
            }
            if (!valid_column(optarg)) {
                fprintf(stderr, "Error: invalid column \"%s\".\n", optarg);
                return 1;
            }
            break;
        case 'u': {
            const char *name = optarg;
            if (!name && optind < argc && argv[optind][0] != '-')
                name = argv[optind++];
            if (!name) name = getenv("USER");
            if (!name || !*name) name = getenv("LOGNAME");
            struct passwd *pw = name ? getpwnam(name) : NULL;
            if (!pw && name) {
                char *end = NULL;
                errno = 0;
                unsigned long uid = strtoul(name, &end, 10);
                if (!errno && end != name && *end == '\0')
                    pw = getpwuid((uid_t)uid);
            }
            if (!pw) {
                fprintf(stderr, "Error: invalid user \"%s\".\n", name ? name : "");
                return 1;
            }
            use_uid = true;
            only_uid = pw->pw_uid;
            break;
        }
        case 'V':
            print_version();
            return 0;
        case '?':
        default:
            return 1;
        }
    }
    (void)iterations;
    render(pid_filter, only_uid, use_uid, filter, function_bar);
    return 0;
}
