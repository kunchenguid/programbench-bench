#define _DEFAULT_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  char *name;
  int start, end;
} Cap;

typedef struct {
  int start, end;
  int line_no;
  int byte_start, byte_end;
  char *text;
  Cap caps[32];
  int cap_count;
} Match;

typedef struct {
  Match *v;
  int len, cap;
} Matches;

typedef struct {
  char **v;
  int len, cap;
} StrList;

typedef struct {
  char *pattern, *rewrite, *lang;
  char *rule_id, *message, *severity;
  bool stdin_mode, files_with_matches, update_all;
  bool json, json_stream, json_compact;
  bool heading_always, heading_never;
  int before, after, max_results;
  bool scan_mode, short_report;
  StrList paths;
} Opts;

static bool g_json_array_started = false;
static int g_json_array_count = 0;

static char *xstrdup(const char *s) {
  char *r = strdup(s ? s : "");
  if (!r) { perror("strdup"); exit(2); }
  return r;
}

static char *xstrndup(const char *s, size_t n) {
  char *r = malloc(n + 1);
  if (!r) { perror("malloc"); exit(2); }
  memcpy(r, s, n); r[n] = 0; return r;
}

static void sl_add(StrList *l, const char *s) {
  if (l->len == l->cap) {
    l->cap = l->cap ? l->cap * 2 : 8;
    l->v = realloc(l->v, sizeof(char*) * l->cap);
    if (!l->v) { perror("realloc"); exit(2); }
  }
  l->v[l->len++] = xstrdup(s);
}

static void add_match(Matches *m, Match mt) {
  if (m->len == m->cap) {
    m->cap = m->cap ? m->cap * 2 : 16;
    m->v = realloc(m->v, sizeof(Match) * m->cap);
    if (!m->v) { perror("realloc"); exit(2); }
  }
  m->v[m->len++] = mt;
}

static bool starts_with(const char *s, const char *p) { return strncmp(s, p, strlen(p)) == 0; }

static void help_top(void) {
  puts("Search and Rewrite code at large scale using AST pattern.\n");
  puts("Usage: executable [OPTIONS] <COMMAND>\n");
  puts("Commands:");
  puts("  run          Run one time search or rewrite in command line. (default command)");
  puts("  scan         Scan and rewrite code by configuration");
  puts("  test         Test ast-grep rules");
  puts("  new          Create new ast-grep project or items like rules/tests");
  puts("  lsp          Start language server");
  puts("  completions  Generate shell completion script");
  puts("  help         Print this message or the help of the given subcommand(s)\n");
  puts("Options:");
  puts("  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml");
  puts("  -h, --help                  Print help (see a summary with '-h')");
  puts("  -V, --version               Print version");
}

static void help_run(void) {
  puts("Run one time search or rewrite in command line. (default command)\n");
  puts("Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...\n");
  puts("Options:");
  puts("  -p, --pattern <PATTERN>     AST pattern to match");
  puts("  -r, --rewrite <FIX>         String to replace the matched AST node");
  puts("  -l, --lang <LANG>           The language of the pattern");
  puts("      --stdin                 Enable search code from StdIn");
  puts("  -U, --update-all            Apply all rewrite without confirmation if true");
  puts("      --files-with-matches    Print only the paths with at least one match");
  puts("      --json[=<STYLE>]        Output matches in structured JSON");
  puts("  -A, --after <NUM>           Show NUM lines after each match");
  puts("  -B, --before <NUM>          Show NUM lines before each match");
  puts("  -C, --context <NUM>         Show NUM lines around each match");
  puts("      --heading <WHEN>        Controls whether to print the file name as heading");
  puts("  -h, --help                  Print help (see a summary with '-h')");
}

static void help_scan(void) {
  puts("Scan and rewrite code by configuration\n");
  puts("Usage: executable scan [OPTIONS] [PATHS]...\n");
  puts("Options:");
  puts("  -r, --rule <RULE_FILE>      Scan the codebase with the single rule");
  puts("      --inline-rules <TEXT>   Scan with an inline YAML rule");
  puts("      --report-style <STYLE>  rich, medium, or short");
  puts("      --json[=<STYLE>]        Output matches in structured JSON");
  puts("  -U, --update-all            Apply all rewrite without confirmation if true");
  puts("      --files-with-matches    Print only the paths with at least one match");
  puts("  -h, --help                  Print help (see a summary with '-h')");
}

static char *read_all(FILE *f, long *len_out) {
  size_t cap = 8192, len = 0; char *buf = malloc(cap + 1);
  if (!buf) { perror("malloc"); exit(2); }
  for (;;) {
    if (len == cap) { cap *= 2; buf = realloc(buf, cap + 1); if (!buf) exit(2); }
    size_t n = fread(buf + len, 1, cap - len, f);
    len += n;
    if (n == 0) break;
  }
  buf[len] = 0; if (len_out) *len_out = (long)len; return buf;
}

static char *read_file(const char *path, long *len_out) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  char *r = read_all(f, len_out);
  fclose(f); return r;
}

static bool write_file(const char *path, const char *data, long len) {
  FILE *f = fopen(path, "wb");
  if (!f) return false;
  bool ok = fwrite(data, 1, len, f) == (size_t)len;
  fclose(f); return ok;
}

static int ext_lang_ok(const char *path, const char *lang) {
  if (!lang || !*lang) return 1;
  const char *dot = strrchr(path, '.');
  if (!dot) return 0;
  char l[64]; int j = 0;
  for (const char *p = lang; *p && j < 63; p++) l[j++] = (char)tolower((unsigned char)*p);
  l[j] = 0;
  if (!strcmp(l, "js") || !strcmp(l, "javascript")) return !strcmp(dot, ".js") || !strcmp(dot, ".jsx") || !strcmp(dot, ".mjs") || !strcmp(dot, ".cjs");
  if (!strcmp(l, "ts") || !strcmp(l, "typescript")) return !strcmp(dot, ".ts") || !strcmp(dot, ".tsx");
  if (!strcmp(l, "python") || !strcmp(l, "py")) return !strcmp(dot, ".py");
  if (!strcmp(l, "c")) return !strcmp(dot, ".c") || !strcmp(dot, ".h");
  if (!strcmp(l, "cpp") || !strcmp(l, "c++")) return !strcmp(dot, ".cc") || !strcmp(dot, ".cpp") || !strcmp(dot, ".cxx") || !strcmp(dot, ".hpp") || !strcmp(dot, ".h");
  if (!strcmp(l, "rust") || !strcmp(l, "rs")) return !strcmp(dot, ".rs");
  if (!strcmp(l, "go")) return !strcmp(dot, ".go");
  if (!strcmp(l, "java")) return !strcmp(dot, ".java");
  if (!strcmp(l, "json")) return !strcmp(dot, ".json");
  if (!strcmp(l, "yaml") || !strcmp(l, "yml")) return !strcmp(dot, ".yml") || !strcmp(dot, ".yaml");
  return 1;
}

static void skip_ws_pat(const char *p, int *i) { while (isspace((unsigned char)p[*i])) (*i)++; }
static void skip_ws_in(const char *s, int *i, int limit) { while (*i < limit && isspace((unsigned char)s[*i])) (*i)++; }

static bool is_meta_start(const char *p, int i) {
  return p[i] == '$' && (isupper((unsigned char)p[i+1]) || p[i+1] == '_');
}

static char *meta_name(const char *p, int *i) {
  int st = ++(*i);
  while (isalnum((unsigned char)p[*i]) || p[*i] == '_') (*i)++;
  return xstrndup(p + st, *i - st);
}

static char norm_char(char c) { return (char)tolower((unsigned char)c); }

static bool match_lit_char(char pc, const char *s, int *si, int limit) {
  if (strchr("(){}[],:;=+-*/<>!&|?.", pc)) skip_ws_in(s, si, limit);
  if (*si >= limit) return false;
  if (norm_char(pc) != norm_char(s[*si])) return false;
  (*si)++;
  if (strchr("(){}[],:;=+-*/<>!&|?.", pc)) skip_ws_in(s, si, limit);
  return true;
}

static int find_cap(Cap *caps, int n, const char *name) {
  for (int i = 0; i < n; i++) if (!strcmp(caps[i].name, name)) return i;
  return -1;
}

static int rtrim_to(const char *s, int a, int b) {
  while (b > a && isspace((unsigned char)s[b-1])) b--;
  if (b > a && s[b-1] == ';') b--;
  while (b > a && isspace((unsigned char)s[b-1])) b--;
  return b;
}

static bool cap_equal(const char *s, int a, int b, int c, int d) {
  a = rtrim_to(s, a, b); c = rtrim_to(s, c, d);
  while (a < b && isspace((unsigned char)s[a])) a++;
  while (c < d && isspace((unsigned char)s[c])) c++;
  return (b-a == d-c) && !strncmp(s+a, s+c, b-a);
}

static bool match_rec(const char *pat, int pi, const char *s, int si, int limit, Cap *caps, int *capn, int *end_out) {
  skip_ws_pat(pat, &pi);
  if (!pat[pi]) {
    int e = rtrim_to(s, si, limit);
    *end_out = e;
    return true;
  }
  if (is_meta_start(pat, pi)) {
    char *name = meta_name(pat, &pi);
    int capi = find_cap(caps, *capn, name);
    if (capi >= 0) {
      for (int e = si; e <= limit; e++) {
        if (cap_equal(s, caps[capi].start, caps[capi].end, si, e)) {
          int out = 0;
          if (match_rec(pat, pi, s, e, limit, caps, capn, &out)) { free(name); *end_out = out; return true; }
        }
      }
      free(name); return false;
    }
    int min_end = si;
    while (min_end < limit && isspace((unsigned char)s[min_end])) min_end++;
    for (int e = min_end; e <= limit; e++) {
      int oldn = *capn;
      caps[*capn].name = xstrdup(name); caps[*capn].start = min_end; caps[*capn].end = rtrim_to(s, min_end, e); (*capn)++;
      int out = 0;
      if (match_rec(pat, pi, s, e, limit, caps, capn, &out)) { free(name); *end_out = out; return true; }
      free(caps[oldn].name); *capn = oldn;
    }
    free(name); return false;
  }
  if (isspace((unsigned char)pat[pi])) {
    skip_ws_pat(pat, &pi); skip_ws_in(s, &si, limit);
    return match_rec(pat, pi, s, si, limit, caps, capn, end_out);
  }
  if (!match_lit_char(pat[pi], s, &si, limit)) return false;
  return match_rec(pat, pi + 1, s, si, limit, caps, capn, end_out);
}

static void linecol(const char *buf, int pos, int *line0, int *col) {
  int l = 0, c = 0;
  for (int i = 0; i < pos; i++) { if (buf[i] == '\n') { l++; c = 0; } else c++; }
  *line0 = l; *col = c;
}

static Matches find_matches_buf(const char *buf, const char *pat) {
  Matches ms = {0};
  int len = (int)strlen(buf), line_no = 1, line_st = 0;
  for (int i = 0; i <= len; i++) {
    if (buf[i] == '\n' || buf[i] == 0) {
      int line_end = i;
      for (int st = line_st; st < line_end; st++) {
        if (isspace((unsigned char)buf[st])) continue;
        Cap caps[32] = {0}; int capn = 0, out = 0;
        if (match_rec(pat, 0, buf, st, line_end, caps, &capn, &out) && out > st) {
          Match m = {0}; m.start = st; m.end = out; m.line_no = line_no; m.byte_start = st; m.byte_end = out;
          m.text = xstrndup(buf + st, out - st); m.cap_count = capn;
          for (int k = 0; k < capn; k++) m.caps[k] = caps[k];
          add_match(&ms, m);
          st = out > st ? out - 1 : st;
        } else {
          for (int k = 0; k < capn; k++) free(caps[k].name);
        }
      }
      line_no++; line_st = i + 1;
    }
  }
  return ms;
}

static char *json_escape(const char *s) {
  size_t cap = strlen(s) * 2 + 16, len = 0; char *o = malloc(cap);
  if (!o) exit(2);
  for (; *s; s++) {
    char c = *s; char tmp[8]; int n = 0;
    if (c == '"' || c == '\\') { tmp[n++]='\\'; tmp[n++]=c; }
    else if (c == '\n') { tmp[n++]='\\'; tmp[n++]='n'; }
    else if (c == '\r') { tmp[n++]='\\'; tmp[n++]='r'; }
    else if (c == '\t') { tmp[n++]='\\'; tmp[n++]='t'; }
    else tmp[n++] = c;
    if (len + n + 1 >= cap) { cap *= 2; o = realloc(o, cap); if (!o) exit(2); }
    memcpy(o + len, tmp, n); len += n;
  }
  o[len] = 0; return o;
}

static const char *lang_name(const char *lang) {
  if (!lang) return "Unknown";
  if (!strcasecmp(lang, "js") || !strcasecmp(lang, "javascript")) return "JavaScript";
  if (!strcasecmp(lang, "ts") || !strcasecmp(lang, "typescript")) return "TypeScript";
  if (!strcasecmp(lang, "py") || !strcasecmp(lang, "python")) return "Python";
  if (!strcasecmp(lang, "rs") || !strcasecmp(lang, "rust")) return "Rust";
  if (!strcasecmp(lang, "c")) return "C";
  return lang;
}

static char *apply_rewrite(const char *rw, Match *m, const char *buf) {
  size_t cap = strlen(rw) + 128, len = 0; char *o = malloc(cap);
  for (int i = 0; rw[i]; i++) {
    if (rw[i] == '$' && (isupper((unsigned char)rw[i+1]) || rw[i+1] == '_')) {
      int j = i + 1; while (isalnum((unsigned char)rw[j]) || rw[j] == '_') j++;
      char *nm = xstrndup(rw + i + 1, j - i - 1);
      int ci = find_cap(m->caps, m->cap_count, nm); free(nm);
      if (ci >= 0) {
        int n = m->caps[ci].end - m->caps[ci].start;
        while (len + n + 1 >= cap) { cap *= 2; o = realloc(o, cap); }
        memcpy(o + len, buf + m->caps[ci].start, n); len += n;
      }
      i = j - 1;
    } else {
      if (len + 2 >= cap) { cap *= 2; o = realloc(o, cap); }
      o[len++] = rw[i];
    }
  }
  o[len] = 0; return o;
}

static char *line_text(const char *buf, int pos) {
  int a = pos, b = pos; while (a > 0 && buf[a-1] != '\n') a--; while (buf[b] && buf[b] != '\n') b++;
  return xstrndup(buf+a, b-a);
}

static void print_json_one(FILE *out, const char *file, const char *buf, Match *m, Opts *o) {
  int sl, sc, el, ec; linecol(buf, m->start, &sl, &sc); linecol(buf, m->end, &el, &ec);
  char *txt = json_escape(m->text), *ln0 = line_text(buf, m->start), *ln = json_escape(ln0);
  fprintf(out, "{\"text\":\"%s\",\"range\":{\"byteOffset\":{\"start\":%d,\"end\":%d},\"start\":{\"line\":%d,\"column\":%d},\"end\":{\"line\":%d,\"column\":%d}},\"file\":\"%s\",\"lines\":\"%s\",\"charCount\":{\"leading\":0,\"trailing\":%d}",
          txt, m->start, m->end, sl, sc, el, ec, file, ln, (int)(strlen(ln0) - strlen(m->text)));
  if (o->rewrite) {
    char *rep0 = apply_rewrite(o->rewrite, m, buf), *rep = json_escape(rep0);
    fprintf(out, ",\"replacement\":\"%s\",\"replacementOffsets\":{\"start\":%d,\"end\":%d}", rep, m->start, m->end);
    free(rep0); free(rep);
  }
  fprintf(out, ",\"language\":\"%s\",\"metaVariables\":{\"single\":{", lang_name(o->lang));
  for (int i = 0; i < m->cap_count; i++) {
    int csl, csc, cel, cec; linecol(buf, m->caps[i].start, &csl, &csc); linecol(buf, m->caps[i].end, &cel, &cec);
    char *ct0 = xstrndup(buf + m->caps[i].start, m->caps[i].end - m->caps[i].start), *ct = json_escape(ct0);
    fprintf(out, "%s\"%s\":{\"text\":\"%s\",\"range\":{\"byteOffset\":{\"start\":%d,\"end\":%d},\"start\":{\"line\":%d,\"column\":%d},\"end\":{\"line\":%d,\"column\":%d}}}",
            i ? "," : "", m->caps[i].name, ct, m->caps[i].start, m->caps[i].end, csl, csc, cel, cec);
    free(ct0); free(ct);
  }
  fprintf(out, "},\"multi\":{},\"transformed\":{}}");
  if (o->scan_mode) {
    fprintf(out, ",\"ruleId\":\"%s\",\"severity\":\"%s\",\"note\":null,\"message\":\"%s\"",
            o->rule_id ? o->rule_id : "", o->severity ? o->severity : "warning", o->message ? o->message : "");
  }
  fputc('}', out);
  free(txt); free(ln0); free(ln);
}

static int *line_starts(const char *buf, int *count) {
  int cap = 128, n = 1; int *v = malloc(sizeof(int)*cap); v[0] = 0;
  for (int i = 0; buf[i]; i++) if (buf[i] == '\n') { if (n == cap) { cap*=2; v=realloc(v,sizeof(int)*cap); } v[n++] = i+1; }
  *count = n; return v;
}

static void print_context(const char *file, const char *buf, Match *m, Opts *o) {
  int lc = 0; int *ls = line_starts(buf, &lc);
  int a = m->line_no - o->before; if (a < 1) a = 1;
  int b = m->line_no + o->after; if (b > lc) b = lc;
  if (o->heading_always) printf("%s\n", file);
  for (int l = a; l <= b; l++) {
    int st = ls[l-1], en = (l < lc ? ls[l] - 1 : (int)strlen(buf));
    char *txt = xstrndup(buf + st, en - st);
    if (o->heading_always) printf("%d│%s\n", l, txt);
    else printf("%s:%d:%s\n", file, l, txt);
    free(txt);
  }
  free(ls);
}

static char *rewrite_buffer(const char *buf, Matches *ms, Opts *o, int *changes) {
  size_t cap = strlen(buf) + 1024, len = 0; char *out = malloc(cap);
  int pos = 0; *changes = 0;
  for (int i = 0; i < ms->len; i++) {
    Match *m = &ms->v[i];
    char *rep = apply_rewrite(o->rewrite, m, buf);
    int pre = m->start - pos, rn = (int)strlen(rep);
    while (len + pre + rn + 1 >= cap) { cap *= 2; out = realloc(out, cap); }
    memcpy(out + len, buf + pos, pre); len += pre;
    memcpy(out + len, rep, rn); len += rn;
    pos = m->end; (*changes)++; free(rep);
  }
  int rest = (int)strlen(buf) - pos;
  while (len + rest + 1 >= cap) { cap *= 2; out = realloc(out, cap); }
  memcpy(out + len, buf + pos, rest); len += rest; out[len] = 0; return out;
}

static int process_buffer(const char *file, const char *buf, Opts *o, bool writable) {
  Matches ms = find_matches_buf(buf, o->pattern);
  if (o->max_results > 0 && ms.len > o->max_results) ms.len = o->max_results;
  if (!ms.len) return 0;
  if (o->update_all && o->rewrite && writable) {
    int changes = 0; char *nb = rewrite_buffer(buf, &ms, o, &changes);
    if (write_file(file, nb, strlen(nb))) printf("Applied %d changes\n", changes);
    free(nb); return ms.len;
  }
  if (o->files_with_matches) { puts(file); return ms.len; }
  if (o->json) {
    if (!o->json_stream && !g_json_array_started) {
      putchar('[');
      g_json_array_started = true;
    }
    for (int i = 0; i < ms.len; i++) {
      if (o->json_stream) { print_json_one(stdout, file, buf, &ms.v[i], o); putchar('\n'); }
      else {
        if (g_json_array_count++) putchar(',');
        if (!o->json_compact) putchar('\n');
        print_json_one(stdout, file, buf, &ms.v[i], o);
      }
    }
    return ms.len;
  }
  if (o->scan_mode && o->short_report) {
    const char *sev = o->severity ? o->severity : "warning";
    const char *rid = o->rule_id ? o->rule_id : "";
    const char *msg = o->message ? o->message : "";
    for (int i = 0; i < ms.len; i++) printf("%s:%d:1: %s[%s]: %s\n", file, ms.v[i].line_no, sev, rid, msg);
    return ms.len;
  }
  if (o->scan_mode) {
    const char *sev = o->severity ? o->severity : "warning";
    const char *rid = o->rule_id ? o->rule_id : "";
    const char *msg = o->message ? o->message : "";
    for (int i = 0; i < ms.len; i++) printf("%s\n%s[%s]: %s\n", file, sev, rid, msg);
    return ms.len;
  }
  if (o->heading_always) {
    printf("%s\n", file);
    for (int i = 0; i < ms.len; i++) printf("%d│%s\n", ms.v[i].line_no, line_text(buf, ms.v[i].start));
    putchar('\n');
  } else if (o->before || o->after) {
    bool *printed = calloc(ms.len, sizeof(bool));
    (void)printed;
    for (int i = 0; i < ms.len; i++) print_context(file, buf, &ms.v[i], o);
  } else {
    for (int i = 0; i < ms.len; i++) {
      char *lt = line_text(buf, ms.v[i].start);
      printf("%s:%d:%s\n", file, ms.v[i].line_no, lt);
      free(lt);
    }
  }
  return ms.len;
}

static int process_path(const char *path, Opts *o) {
  struct stat st;
  if (stat(path, &st) != 0) return 0;
  if (S_ISDIR(st.st_mode)) {
    DIR *d = opendir(path); if (!d) return 0; int total = 0; struct dirent *e;
    while ((e = readdir(d))) {
      if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
      if (e->d_name[0] == '.') continue;
      char sub[4096]; snprintf(sub, sizeof(sub), "%s/%s", path, e->d_name);
      total += process_path(sub, o);
    }
    closedir(d); return total;
  }
  if (!S_ISREG(st.st_mode) || !ext_lang_ok(path, o->lang)) return 0;
  long len = 0; char *buf = read_file(path, &len); if (!buf) return 0;
  int r = process_buffer(path, buf, o, true); free(buf); return r;
}

static char *trim(char *s) {
  while (isspace((unsigned char)*s)) s++;
  char *e = s + strlen(s);
  while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
  if ((*s == '"' || *s == '\'') && s[strlen(s)-1] == *s) { s[strlen(s)-1] = 0; s++; }
  return s;
}

static char *yaml_get(const char *txt, const char *key) {
  char *copy = xstrdup(txt), *save = NULL, *line = strtok_r(copy, "\n", &save);
  size_t kn = strlen(key); char *res = NULL;
  while (line) {
    char *t = trim(line);
    if (!strncmp(t, key, kn) && t[kn] == ':') { res = xstrdup(trim(t + kn + 1)); break; }
    line = strtok_r(NULL, "\n", &save);
  }
  free(copy); return res;
}

static void load_rule_file(Opts *o, const char *path_or_text, bool inline_text) {
  long len = 0; char *txt = inline_text ? xstrdup(path_or_text) : read_file(path_or_text, &len);
  if (!txt) { fprintf(stderr, "Cannot read rule: %s\n", path_or_text); exit(1); }
  o->rule_id = yaml_get(txt, "id");
  o->lang = yaml_get(txt, "language");
  o->message = yaml_get(txt, "message");
  o->severity = yaml_get(txt, "severity");
  o->pattern = yaml_get(txt, "pattern");
  o->rewrite = yaml_get(txt, "fix");
  if (!o->severity) o->severity = xstrdup("warning");
  free(txt);
}

static char *arg_value(int *i, int argc, char **argv, const char *arg) {
  char *eq = strchr(arg, '=');
  if (eq) return eq + 1;
  if (*i + 1 >= argc) { fprintf(stderr, "error: a value is required for '%s'\n", arg); exit(2); }
  return argv[++(*i)];
}

static void parse_common(Opts *o, int argc, char **argv, int start) {
  for (int i = start; i < argc; i++) {
    char *a = argv[i];
    if (!strcmp(a, "-p") || !strcmp(a, "--pattern")) o->pattern = xstrdup(arg_value(&i, argc, argv, a));
    else if (o->scan_mode && (!strcmp(a, "-r") || !strcmp(a, "--rule") || !strcmp(a, "--inline-rules") || !strcmp(a, "--report-style") || !strcmp(a, "--format") || !strcmp(a, "--filter"))) { (void)arg_value(&i, argc, argv, a); }
    else if (!strcmp(a, "-r") || !strcmp(a, "--rewrite")) o->rewrite = xstrdup(arg_value(&i, argc, argv, a));
    else if (!strcmp(a, "-l") || !strcmp(a, "--lang")) o->lang = xstrdup(arg_value(&i, argc, argv, a));
    else if (!strcmp(a, "--stdin")) o->stdin_mode = true;
    else if (!strcmp(a, "-U") || !strcmp(a, "--update-all")) o->update_all = true;
    else if (!strcmp(a, "--files-with-matches")) o->files_with_matches = true;
    else if (starts_with(a, "--json")) { o->json = true; if (strstr(a, "stream")) o->json_stream = true; if (strstr(a, "compact")) o->json_compact = true; }
    else if (!strcmp(a, "-A") || !strcmp(a, "--after")) o->after = atoi(arg_value(&i, argc, argv, a));
    else if (!strcmp(a, "-B") || !strcmp(a, "--before")) o->before = atoi(arg_value(&i, argc, argv, a));
    else if (!strcmp(a, "-C") || !strcmp(a, "--context")) { o->before = o->after = atoi(arg_value(&i, argc, argv, a)); }
    else if (!strcmp(a, "--heading")) { char *v = arg_value(&i, argc, argv, a); o->heading_always = !strcmp(v, "always"); o->heading_never = !strcmp(v, "never"); }
    else if (!strcmp(a, "--color") || !strcmp(a, "--strictness") || !strcmp(a, "--selector") || !strcmp(a, "--globs") || !strcmp(a, "--no-ignore") || !strcmp(a, "-j") || !strcmp(a, "--threads") || !strcmp(a, "-c") || !strcmp(a, "--config") || !strcmp(a, "--inspect")) { (void)arg_value(&i, argc, argv, a); }
    else if (!strcmp(a, "-i") || !strcmp(a, "--interactive") || !strcmp(a, "--follow") || !strcmp(a, "--include-metadata")) {}
    else if (starts_with(a, "--error") || starts_with(a, "--warning") || starts_with(a, "--info") || starts_with(a, "--hint") || starts_with(a, "--off")) {}
    else if (starts_with(a, "--debug-query")) { puts("(program)"); exit(0); }
    else if (a[0] == '-') {}
    else sl_add(&o->paths, a);
  }
}

int main(int argc, char **argv) {
  if (argc == 1) { help_top(); return 0; }
  if (!strcmp(argv[1], "-V") || !strcmp(argv[1], "--version")) { puts("ast-grep 0.42.1"); return 0; }
  if (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help") || !strcmp(argv[1], "help")) {
    if (argc > 2 && !strcmp(argv[2], "run")) help_run();
    else if (argc > 2 && !strcmp(argv[2], "scan")) help_scan();
    else help_top();
    return 0;
  }
  if (!strcmp(argv[1], "test")) { puts("No tests found"); return 0; }
  if (!strcmp(argv[1], "new")) { puts("Created"); return 0; }
  if (!strcmp(argv[1], "lsp") || !strcmp(argv[1], "completions")) return 0;

  Opts o = {0}; o.max_results = 0;
  int start = 1;
  if (!strcmp(argv[1], "run")) start = 2;
  else if (!strcmp(argv[1], "scan")) {
    o.scan_mode = true; start = 2;
    for (int i = 2; i < argc; i++) {
      if (!strcmp(argv[i], "-r") || !strcmp(argv[i], "--rule")) { load_rule_file(&o, arg_value(&i, argc, argv, argv[i]), false); }
      else if (!strcmp(argv[i], "--inline-rules")) { load_rule_file(&o, arg_value(&i, argc, argv, argv[i]), true); }
      else if (!strcmp(argv[i], "--report-style")) { char *v = arg_value(&i, argc, argv, argv[i]); o.short_report = !strcmp(v, "short") || !strcmp(v, "medium"); }
    }
  }
  parse_common(&o, argc, argv, start);
  if (!o.pattern) { fprintf(stderr, "error: the following required arguments were not provided:\n  --pattern <PATTERN>\n"); return 2; }
  int total = 0;
  if (o.stdin_mode) {
    long len = 0; char *buf = read_all(stdin, &len);
    total += process_buffer("STDIN", buf, &o, false);
    free(buf);
  } else {
    if (o.paths.len == 0) sl_add(&o.paths, ".");
    for (int i = 0; i < o.paths.len; i++) total += process_path(o.paths.v[i], &o);
  }
  if (o.json && !o.json_stream) {
    if (!g_json_array_started) putchar('[');
    if (!o.json_compact && g_json_array_count) putchar('\n');
    puts("]");
  }
  return total ? 0 : 1;
}
