#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    unsigned char *p;
    size_t n, cap;
} Buf;

static const unsigned char XZ_MAGIC[6] = {0xfd, '7', 'z', 'X', 'Z', 0x00};
static uint32_t crc32_tab[256];
static uint64_t crc64_tab[256];

static void init_crc(void) {
    for (unsigned i = 0; i < 256; ++i) {
        uint32_t c = i;
        for (int j = 0; j < 8; ++j)
            c = (c >> 1) ^ (0xedb88320U & (0U - (c & 1)));
        crc32_tab[i] = c;
        uint64_t d = i;
        for (int j = 0; j < 8; ++j)
            d = (d >> 1) ^ (0xc96c5795d7870f42ULL & (0ULL - (d & 1)));
        crc64_tab[i] = d;
    }
}

static uint32_t crc32_calc(const unsigned char *p, size_t n) {
    uint32_t c = 0xffffffffU;
    for (size_t i = 0; i < n; ++i)
        c = crc32_tab[(c ^ p[i]) & 0xff] ^ (c >> 8);
    return c ^ 0xffffffffU;
}

static uint64_t crc64_calc(const unsigned char *p, size_t n) {
    uint64_t c = 0xffffffffffffffffULL;
    for (size_t i = 0; i < n; ++i)
        c = crc64_tab[(c ^ p[i]) & 0xff] ^ (c >> 8);
    return c ^ 0xffffffffffffffffULL;
}

static uint32_t ror32(uint32_t x, unsigned n) { return (x >> n) | (x << (32 - n)); }

static void sha256_calc(const unsigned char *data, size_t len, unsigned char out[32]) {
    static const uint32_t k[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
    uint32_t h[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    uint64_t bitlen = (uint64_t)len * 8;
    size_t total = len + 1 + 8;
    total = (total + 63) & ~(size_t)63;
    unsigned char *msg = calloc(total, 1);
    if (!msg) abort();
    memcpy(msg, data, len);
    msg[len] = 0x80;
    for (int i = 0; i < 8; ++i) msg[total - 1 - i] = (unsigned char)(bitlen >> (8 * i));
    for (size_t off = 0; off < total; off += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; ++i) {
            const unsigned char *p = msg + off + 4 * i;
            w[i] = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
        }
        for (int i = 16; i < 64; ++i) {
            uint32_t s0 = ror32(w[i-15], 7) ^ ror32(w[i-15], 18) ^ (w[i-15] >> 3);
            uint32_t s1 = ror32(w[i-2], 17) ^ ror32(w[i-2], 19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        uint32_t a=h[0], b=h[1], c=h[2], d=h[3], e=h[4], f=h[5], g=h[6], hh=h[7];
        for (int i = 0; i < 64; ++i) {
            uint32_t S1 = ror32(e,6) ^ ror32(e,11) ^ ror32(e,25);
            uint32_t ch = (e & f) ^ (~e & g);
            uint32_t t1 = hh + S1 + ch + k[i] + w[i];
            uint32_t S0 = ror32(a,2) ^ ror32(a,13) ^ ror32(a,22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + maj;
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
    }
    free(msg);
    for (int i = 0; i < 8; ++i) {
        out[4*i] = (unsigned char)(h[i] >> 24);
        out[4*i+1] = (unsigned char)(h[i] >> 16);
        out[4*i+2] = (unsigned char)(h[i] >> 8);
        out[4*i+3] = (unsigned char)h[i];
    }
}

static void put32le(unsigned char *p, uint32_t v) {
    p[0] = (unsigned char)v; p[1] = (unsigned char)(v >> 8);
    p[2] = (unsigned char)(v >> 16); p[3] = (unsigned char)(v >> 24);
}

static uint32_t get32le(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void put64le(unsigned char *p, uint64_t v) {
    for (int i = 0; i < 8; ++i) p[i] = (unsigned char)(v >> (8 * i));
}

static void buf_reserve(Buf *b, size_t add) {
    if (add > SIZE_MAX - b->n) abort();
    size_t need = b->n + add;
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap * 2 : 4096;
    while (nc < need) nc *= 2;
    unsigned char *np = realloc(b->p, nc);
    if (!np) abort();
    b->p = np; b->cap = nc;
}

static void buf_put(Buf *b, const void *p, size_t n) {
    buf_reserve(b, n);
    memcpy(b->p + b->n, p, n);
    b->n += n;
}

static void buf_byte(Buf *b, unsigned char c) { buf_put(b, &c, 1); }

static void buf_vli(Buf *b, uint64_t v) {
    do {
        unsigned char c = (unsigned char)(v & 0x7f);
        v >>= 7;
        if (v) c |= 0x80;
        buf_byte(b, c);
    } while (v);
}

static bool read_vli(const unsigned char *p, size_t n, size_t *pos, uint64_t *out) {
    uint64_t v = 0;
    unsigned shift = 0;
    for (int i = 0; i < 9; ++i) {
        if (*pos >= n) return false;
        unsigned char c = p[(*pos)++];
        v |= (uint64_t)(c & 0x7f) << shift;
        if (!(c & 0x80)) { *out = v; return true; }
        shift += 7;
    }
    return false;
}

static bool read_all(FILE *f, Buf *b) {
    unsigned char tmp[32768];
    for (;;) {
        size_t r = fread(tmp, 1, sizeof(tmp), f);
        if (r) buf_put(b, tmp, r);
        if (r < sizeof(tmp)) return feof(f);
    }
}

static bool read_file(const char *name, Buf *b) {
    FILE *f = strcmp(name, "-") == 0 ? stdin : fopen(name, "rb");
    if (!f) return false;
    bool ok = read_all(f, b);
    if (f != stdin) fclose(f);
    return ok;
}

static void add_file_arg(char ***files, int *nf, int *cap, char *name) {
    if (*nf >= *cap) {
        int nc = *cap ? *cap * 2 : 16;
        char **np = realloc(*files, (size_t)nc * sizeof(char *));
        if (!np) abort();
        *files = np; *cap = nc;
    }
    (*files)[(*nf)++] = name;
}

static int add_files_from_list(char ***files, int *nf, int *cap, const char *listfile, int delim) {
    Buf b = {0};
    if (!read_file(listfile ? listfile : "-", &b)) return -1;
    size_t start = 0;
    for (size_t i = 0; i <= b.n; ++i) {
        if (i == b.n || b.p[i] == (unsigned char)delim) {
            if (i > start) {
                char *s = malloc(i - start + 1);
                if (!s) abort();
                memcpy(s, b.p + start, i - start);
                s[i - start] = 0;
                add_file_arg(files, nf, cap, s);
            }
            start = i + 1;
        }
    }
    free(b.p);
    return 0;
}

static int write_file_or_stdout(const char *name, const Buf *b, bool force) {
    FILE *f;
    if (!name || strcmp(name, "-") == 0) {
        f = stdout;
    } else {
        if (!force && access(name, F_OK) == 0) {
            fprintf(stderr, "xz: %s: File exists\n", name);
            return 1;
        }
        f = fopen(name, "wb");
        if (!f) {
            fprintf(stderr, "xz: %s: %s\n", name, strerror(errno));
            return 1;
        }
    }
    int rc = fwrite(b->p, 1, b->n, f) == b->n ? 0 : 1;
    if (f != stdout) fclose(f);
    return rc;
}

static unsigned dict_prop_for_preset(int preset) {
    static const unsigned props[10] = {16, 16, 18, 20, 21, 22, 23, 24, 25, 26};
    if (preset < 0 || preset > 9) preset = 6;
    return props[preset];
}

static void make_lzma2_uncompressed(const unsigned char *in, size_t n, Buf *lz) {
    size_t pos = 0;
    bool first = true;
    while (pos < n) {
        size_t chunk = n - pos;
        if (chunk > 65536) chunk = 65536;
        buf_byte(lz, first ? 0x01 : 0x02);
        first = false;
        unsigned s = (unsigned)chunk - 1;
        buf_byte(lz, (unsigned char)(s >> 8));
        buf_byte(lz, (unsigned char)s);
        buf_put(lz, in + pos, chunk);
        pos += chunk;
    }
    buf_byte(lz, 0x00);
}

static void append_check(Buf *out, int check, const unsigned char *data, size_t n) {
    unsigned char tmp[32];
    if (check == 0) return;
    if (check == 1) {
        put32le(tmp, crc32_calc(data, n));
        buf_put(out, tmp, 4);
    } else if (check == 4) {
        uint64_t c = crc64_calc(data, n);
        put64le(tmp, c);
        buf_put(out, tmp, 8);
    } else {
        sha256_calc(data, n, tmp);
        buf_put(out, tmp, 32);
    }
}

static void xz_compress(const Buf *in, Buf *out, int preset, int check) {
    unsigned char flags[2] = {0x00, (unsigned char)check};
    unsigned char tmp[8];
    buf_put(out, XZ_MAGIC, 6);
    buf_put(out, flags, 2);
    put32le(tmp, crc32_calc(flags, 2));
    buf_put(out, tmp, 4);

    Buf lz = {0};
    make_lzma2_uncompressed(in->p, in->n, &lz);

    Buf bh = {0};
    buf_byte(&bh, 0); /* filled below */
    buf_byte(&bh, 0xc0); /* one filter, compressed and uncompressed sizes present */
    buf_vli(&bh, lz.n);
    buf_vli(&bh, in->n);
    buf_byte(&bh, 0x21);
    buf_byte(&bh, 0x01);
    buf_byte(&bh, (unsigned char)dict_prop_for_preset(preset));
    while ((bh.n + 4) % 4) buf_byte(&bh, 0);
    bh.p[0] = (unsigned char)(bh.n / 4);
    put32le(tmp, crc32_calc(bh.p, bh.n));
    buf_put(&bh, tmp, 4);
    size_t header_size = bh.n;
    buf_put(out, bh.p, bh.n);
    buf_put(out, lz.p, lz.n);
    append_check(out, check, in->p, in->n);
    size_t unpadded = header_size + lz.n + (check == 0 ? 0 : check == 1 ? 4 : check == 10 ? 8 : 32);
    while (out->n % 4) buf_byte(out, 0);

    Buf idx = {0};
    buf_byte(&idx, 0x00);
    buf_vli(&idx, 1);
    buf_vli(&idx, unpadded);
    buf_vli(&idx, in->n);
    while ((idx.n + 4) % 4) buf_byte(&idx, 0);
    put32le(tmp, crc32_calc(idx.p, idx.n));
    buf_put(&idx, tmp, 4);
    size_t idx_size = idx.n;
    buf_put(out, idx.p, idx.n);

    unsigned char footer[12];
    uint32_t bwd = (uint32_t)(idx_size / 4 - 1);
    put32le(footer + 4, bwd);
    footer[8] = flags[0]; footer[9] = flags[1];
    put32le(footer, crc32_calc(footer + 4, 6));
    footer[10] = 'Y'; footer[11] = 'Z';
    buf_put(out, footer, 12);
    free(lz.p); free(bh.p); free(idx.p);
}

static bool check_stream_check(int check, const unsigned char *got, const unsigned char *data, size_t n) {
    unsigned char tmp[32];
    if (check == 0) return true;
    if (check == 1) {
        put32le(tmp, crc32_calc(data, n));
        return memcmp(tmp, got, 4) == 0;
    }
    if (check == 4) {
        put64le(tmp, crc64_calc(data, n));
        return memcmp(tmp, got, 8) == 0;
    }
    if (check == 10) {
        sha256_calc(data, n, tmp);
        return memcmp(tmp, got, 32) == 0;
    }
    return true;
}

static size_t check_size(int check) {
    if (check == 0) return 0;
    if (check == 1) return 4;
    if (check == 4) return 8;
    if (check == 10) return 32;
    if (check == 2 || check == 3) return 4;
    return 32;
}

static int decode_lzma2_uncompressed(const unsigned char *p, size_t n, Buf *out) {
    size_t pos = 0;
    for (;;) {
        if (pos >= n) return -1;
        unsigned c = p[pos++];
        if (c == 0) return pos == n ? 0 : 0;
        if (c != 1 && c != 2) return -2;
        if (pos + 2 > n) return -1;
        size_t len = ((size_t)p[pos] << 8) | p[pos + 1];
        pos += 2; len += 1;
        if (pos + len > n) return -1;
        buf_put(out, p + pos, len);
        pos += len;
    }
}

typedef struct {
    uint64_t unpacked;
    uint64_t compressed;
    int check;
    unsigned blocks;
} XzInfo;

static int xz_decompress(const Buf *in, Buf *out, XzInfo *info) {
    if (in->n < 32 || memcmp(in->p, XZ_MAGIC, 6) != 0) return -1;
    unsigned char flags[2] = {in->p[6], in->p[7]};
    if (crc32_calc(flags, 2) != get32le(in->p + 8)) return -1;
    int check = flags[1] & 0x0f;
    size_t pos = 12;
    if (pos >= in->n - 12) return -1;
    unsigned hsz = ((unsigned)in->p[pos] + 1) * 4;
    if (pos + hsz > in->n) return -1;
    if (crc32_calc(in->p + pos, hsz - 4) != get32le(in->p + pos + hsz - 4)) return -1;
    const unsigned char *h = in->p + pos;
    size_t hp = 1;
    unsigned bflags = h[hp++];
    bool has_csize = bflags & 0x40, has_usize = bflags & 0x80;
    unsigned filters = (bflags & 0x03) + 1;
    uint64_t csize = 0, usize = 0, v = 0;
    if (has_csize && !read_vli(h, hsz - 4, &hp, &csize)) return -1;
    if (has_usize && !read_vli(h, hsz - 4, &hp, &usize)) return -1;
    if (filters != 1 || !read_vli(h, hsz - 4, &hp, &v) || v != 0x21) return -2;
    if (!read_vli(h, hsz - 4, &hp, &v)) return -1;
    if (hp + v > hsz - 4) return -1;
    pos += hsz;
    size_t data_start = pos;
    if (!has_csize) {
        return -2;
    }
    if (pos + csize > in->n) return -1;
    int dr = decode_lzma2_uncompressed(in->p + pos, (size_t)csize, out);
    if (dr) return -2;
    pos += (size_t)csize;
    if (has_usize && out->n != usize) return -1;
    size_t cksz = check_size(check);
    if (pos + cksz > in->n) return -1;
    if (!check_stream_check(check, in->p + pos, out->p, out->n)) return -1;
    pos += cksz;
    while (pos % 4) {
        if (pos >= in->n || in->p[pos] != 0) return -1;
        ++pos;
    }
    if (info) {
        info->unpacked = out->n;
        info->compressed = in->n;
        info->check = check;
        info->blocks = 1;
    }
    (void)data_start;
    return 0;
}

static char *out_name_compress(const char *in, const char *suffix) {
    size_t a = strlen(in), b = strlen(suffix);
    char *s = malloc(a + b + 1);
    memcpy(s, in, a); memcpy(s + a, suffix, b + 1);
    return s;
}

static char *out_name_decompress(const char *in, const char *suffix) {
    size_t a = strlen(in), b = strlen(suffix);
    if (a > b && strcmp(in + a - b, suffix) == 0) {
        char *s = malloc(a - b + 1);
        memcpy(s, in, a - b); s[a - b] = 0;
        return s;
    }
    if (a > 3 && strcmp(in + a - 3, ".xz") == 0) {
        char *s = malloc(a - 2);
        memcpy(s, in, a - 3); s[a - 3] = 0;
        return s;
    }
    return NULL;
}

static void print_help(bool longh) {
    printf("Usage: ./executable [OPTION]... [FILE]...\n");
    printf("Compress or decompress FILEs in the .xz format.\n\n");
    printf("Mandatory arguments to long options are mandatory for short options too.\n\n");
    if (longh) printf(" Operation mode:\n\n");
    printf("  -z, --compress      force compression\n");
    printf("  -d, --decompress    force decompression\n");
    printf("  -t, --test          test compressed file integrity\n");
    printf("  -l, --list          list information about .xz files\n");
    if (longh) printf("\n Operation modifiers:\n\n");
    printf("  -k, --keep          keep (don't delete) input files\n");
    printf("  -f, --force         force overwrite of output file and (de)compress links\n");
    printf("  -c, --stdout        write to standard output and don't delete input files\n");
    if (longh) {
        printf("      --no-sync       don't synchronize the output file to the storage device\n");
        printf("                      before removing the input file\n");
        printf("  -S, --suffix=.SUF   use the suffix '.SUF' on compressed files\n");
        printf("\n Basic file format and compression options:\n\n");
        printf("  -F, --format=FORMAT file format to encode or decode; possible values are\n");
        printf("                      'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'\n");
        printf("  -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',\n");
        printf("                      'crc64' (default), or 'sha256'\n");
    }
    printf("  -0 ... -9           compression preset; default is 6; take compressor *and*\n");
    printf("                      decompressor memory usage into account before using 7-9!\n");
    printf("  -e, --extreme       try to improve compression ratio by using more CPU time;\n");
    printf("                      does not affect decompressor memory requirements\n");
    printf("  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as\n");
    printf("                      many threads as there are processor cores\n");
    printf("  -q, --quiet         suppress warnings; specify twice to suppress errors too\n");
    printf("  -v, --verbose       be verbose; specify twice for even more verbose\n");
    printf("  -h, --help          display this short help and exit\n");
    printf("  -H, --long-help     display the long help (lists also the advanced options)\n");
    printf("  -V, --version       display the version number and exit\n\n");
    printf("With no FILE, or when FILE is -, read standard input.\n\n");
    printf("Report bugs to <xz@tukaani.org> (in English or Finnish).\n");
    printf("XZ Utils home page: <https://tukaani.org/xz/>\n");
}

static const char *check_name(int c) {
    if (c == 0) return "None";
    if (c == 1) return "CRC32";
    if (c == 4) return "CRC64";
    if (c == 10) return "SHA-256";
    return "Unknown";
}

int main(int argc, char **argv) {
    init_crc();
    const char *prog = "xz";
    enum { MODE_COMPRESS, MODE_DECOMPRESS, MODE_TEST, MODE_LIST } mode = MODE_COMPRESS;
    bool keep = false, force = false, to_stdout = false, saw_mode = false;
    int preset = 6, check = 4;
    const char *suffix = ".xz";
    char **files = NULL;
    int nf = 0, files_cap = 0;

    for (int i = 1; i < argc; ++i) {
        char *a = argv[i];
        if (strcmp(a, "--") == 0) {
            while (++i < argc) add_file_arg(&files, &nf, &files_cap, argv[i]);
            break;
        } else if (a[0] == '-' && a[1]) {
            if (!strcmp(a, "--help")) { print_help(false); free(files); return 0; }
            if (!strcmp(a, "--long-help")) { print_help(true); free(files); return 0; }
            if (!strcmp(a, "--version")) { printf("xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"); free(files); return 0; }
            if (!strcmp(a, "--compress")) { mode = MODE_COMPRESS; saw_mode = true; continue; }
            if (!strcmp(a, "--decompress")) { mode = MODE_DECOMPRESS; saw_mode = true; continue; }
            if (!strcmp(a, "--test")) { mode = MODE_TEST; saw_mode = true; continue; }
            if (!strcmp(a, "--list")) { mode = MODE_LIST; saw_mode = true; continue; }
            if (!strcmp(a, "--keep")) { keep = true; continue; }
            if (!strcmp(a, "--force")) { force = true; continue; }
            if (!strcmp(a, "--stdout") || !strcmp(a, "--to-stdout")) { to_stdout = true; keep = true; continue; }
            if (!strcmp(a, "--files")) {
                if (add_files_from_list(&files, &nf, &files_cap, NULL, '\n')) {
                    fprintf(stderr, "%s: %s\n", prog, strerror(errno));
                    free(files); return 1;
                }
                continue;
            }
            if (!strncmp(a, "--files=", 8)) {
                if (add_files_from_list(&files, &nf, &files_cap, a + 8, '\n')) {
                    fprintf(stderr, "%s: %s: %s\n", prog, a + 8, strerror(errno));
                    free(files); return 1;
                }
                continue;
            }
            if (!strcmp(a, "--files0")) {
                if (add_files_from_list(&files, &nf, &files_cap, NULL, '\0')) {
                    fprintf(stderr, "%s: %s\n", prog, strerror(errno));
                    free(files); return 1;
                }
                continue;
            }
            if (!strncmp(a, "--files0=", 9)) {
                if (add_files_from_list(&files, &nf, &files_cap, a + 9, '\0')) {
                    fprintf(stderr, "%s: %s: %s\n", prog, a + 9, strerror(errno));
                    free(files); return 1;
                }
                continue;
            }
            if (!strcmp(a, "--extreme") || !strcmp(a, "--quiet") || !strcmp(a, "--verbose") ||
                !strcmp(a, "--no-sync") || !strcmp(a, "--single-stream") || !strcmp(a, "--no-sparse") ||
                !strcmp(a, "--robot") || !strcmp(a, "--no-warn") || !strcmp(a, "--ignore-check")) continue;
            if (!strncmp(a, "--suffix=", 9)) { suffix = a + 9; continue; }
            if (!strcmp(a, "--suffix") && i + 1 < argc) { suffix = argv[++i]; continue; }
            if (!strncmp(a, "--check=", 8)) {
                const char *c = a + 8;
                if (!strcmp(c, "none")) check = 0;
                else if (!strcmp(c, "crc32")) check = 1;
                else if (!strcmp(c, "crc64")) check = 4;
                else if (!strcmp(c, "sha256")) check = 10;
                continue;
            }
            if ((!strcmp(a, "-C") || !strcmp(a, "--check")) && i + 1 < argc) {
                const char *c = argv[++i];
                if (!strcmp(c, "none")) check = 0;
                else if (!strcmp(c, "crc32")) check = 1;
                else if (!strcmp(c, "sha256")) check = 10;
                else check = 4;
                continue;
            }
            if ((!strcmp(a, "-T") || !strcmp(a, "--threads") || !strcmp(a, "-F") || !strcmp(a, "--format") ||
                 !strcmp(a, "-M") || !strcmp(a, "--memlimit") || !strcmp(a, "--memlimit-compress") ||
                 !strcmp(a, "--memlimit-decompress") || !strcmp(a, "--block-size") || !strcmp(a, "--block-list") ||
                 !strcmp(a, "--flush-timeout")) && i + 1 < argc) { ++i; continue; }
            if (!strncmp(a, "--threads=", 10) || !strncmp(a, "--format=", 9) || !strncmp(a, "--memlimit", 10) ||
                !strncmp(a, "--block-size=", 13) || !strncmp(a, "--block-list=", 13) ||
                !strncmp(a, "--flush-timeout=", 16)) continue;
            if (a[0] == '-' && a[1] && a[1] != '-') {
                for (int j = 1; a[j]; ++j) {
                    char c = a[j];
                    if (c == 'z') { mode = MODE_COMPRESS; saw_mode = true; }
                    else if (c == 'd') { mode = MODE_DECOMPRESS; saw_mode = true; }
                    else if (c == 't') { mode = MODE_TEST; saw_mode = true; }
                    else if (c == 'l') { mode = MODE_LIST; saw_mode = true; }
                    else if (c == 'k') keep = true;
                    else if (c == 'f') force = true;
                    else if (c == 'c') { to_stdout = true; keep = true; }
                    else if (c >= '0' && c <= '9') preset = c - '0';
                    else if (c == 'e' || c == 'q' || c == 'v') {}
                    else if (c == 'h') { print_help(false); free(files); return 0; }
                    else if (c == 'H') { print_help(true); free(files); return 0; }
                    else if (c == 'V') { printf("xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"); free(files); return 0; }
                    else if (c == 'S') {
                        if (a[j+1]) suffix = a + j + 1;
                        else if (i + 1 < argc) suffix = argv[++i];
                        break;
                    }
                    else if (c == 'T' || c == 'F' || c == 'M') { if (a[j+1] == 0 && i + 1 < argc) ++i; break; }
                }
                continue;
            }
        } else {
            add_file_arg(&files, &nf, &files_cap, a);
        }
    }
    if (nf == 0) add_file_arg(&files, &nf, &files_cap, "-");
    int rc = 0;
    if (mode == MODE_LIST) {
        printf("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename\n");
    }
    for (int i = 0; i < nf; ++i) {
        const char *fn = files[i];
        Buf in = {0}, out = {0};
        if (!read_file(fn, &in)) {
            fprintf(stderr, "%s: %s: %s\n", prog, fn, strerror(errno));
            rc = 1; continue;
        }
        if (mode == MODE_COMPRESS) {
            xz_compress(&in, &out, preset, check);
            char *on = NULL;
            if (!to_stdout && strcmp(fn, "-") != 0) on = out_name_compress(fn, suffix);
            if (write_file_or_stdout(on ? on : "-", &out, force)) rc = 1;
            else if (!keep && strcmp(fn, "-") != 0) unlink(fn);
            free(on);
        } else {
            XzInfo xi = {0};
            int dr = xz_decompress(&in, &out, &xi);
            if (dr) {
                fprintf(stderr, "%s: %s: %s\n", prog, fn, dr == -2 ? "Unsupported compressed data" : "File format not recognized");
                rc = 1;
            } else if (mode == MODE_TEST) {
                if (!keep && false) unlink(fn);
            } else if (mode == MODE_LIST) {
                printf("%5d %7u %10" PRIu64 " B %10" PRIu64 " B %6s  %-6s %s\n",
                       1, xi.blocks, xi.compressed, xi.unpacked, "---", check_name(xi.check), fn);
            } else {
                char *on = NULL;
                if (!to_stdout && strcmp(fn, "-") != 0) {
                    on = out_name_decompress(fn, suffix);
                    if (!on) {
                        fprintf(stderr, "%s: %s: Filename has an unknown suffix, skipping\n", prog, fn);
                        rc = 1; free(in.p); free(out.p); continue;
                    }
                }
                if (write_file_or_stdout(on ? on : "-", &out, force)) rc = 1;
                else if (!keep && strcmp(fn, "-") != 0) unlink(fn);
                free(on);
            }
        }
        free(in.p); free(out.p);
    }
    free(files);
    (void)saw_mode;
    return rc;
}
