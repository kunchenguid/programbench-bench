#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define MAX_RAW_BLOCK 131072u

typedef struct {
  bool decompress, test, stdout_mode, force, remove_src, verbose, no_copy_stat;
  bool squash, concatenated;
  int quality, lgwin;
  const char *output, *suffix, *dictionary, *comment;
  char **files;
  int file_count, file_cap;
} Options;

static const char *prog = "executable";

static void usage(FILE *f) {
  fprintf(f,
"Usage: %s [OPTION]... [FILE]...\n"
"Options:\n"
"  -#                          compression level (0-9)\n"
"  -c, --stdout                write on standard output\n"
"  -d, --decompress            decompress\n"
"  -f, --force                 force output file overwrite\n"
"  -h, --help                  display this help and exit\n"
"  -j, --rm                    remove source file(s)\n"
"  -s, --squash                remove destination file if larger than source\n"
"  -k, --keep                  keep source file(s) (default)\n"
"  -n, --no-copy-stat          do not copy source file(s) attributes\n"
"  -o FILE, --output=FILE      output file (only if 1 input file)\n"
"  -q NUM, --quality=NUM       compression level (0-11)\n"
"  -t, --test                  test compressed file integrity\n"
"  -v, --verbose               verbose mode\n"
"  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)\n"
"                              window size = 2**NUM - 16\n"
"                              0 lets compressor choose the optimal value\n"
"  --large_window=NUM          use incompatible large-window brotli\n"
"                              bitstream with window size (0, 10-30)\n"
"                              WARNING: this format is not compatible\n"
"                              with brotli RFC 7932 and may not be\n"
"                              decodable with regular brotli decoders\n"
"  -C B64, --comment=B64       set comment; argument is base64-decoded first;\n"
"                              (maximal decoded length: 80)\n"
"                              when decoding: check stream comment;\n"
"                              when encoding: embed comment (fingerprint)\n"
"  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary\n"
"  -K, --concatenated          allows concatenated brotli streams as input\n"
"  -S SUF, --suffix=SUF        output file suffix (default:'.br')\n"
"  -V, --version               display version and exit\n"
"  -Z, --best                  use best compression level (11) (default)\n"
"Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.\n"
"With no FILE, or when FILE is -, read standard input.\n"
"All arguments after '--' are treated as files.\n", prog);
}

static int fail_usage(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
  fputc('\n', stderr);
  usage(stderr);
  return 1;
}

static int parse_num(const char *s, int *out) {
  char *end = NULL;
  long v;
  errno = 0;
  if (!s || !*s) return 0;
  v = strtol(s, &end, 10);
  if (errno || *end) return 0;
  *out = (int)v;
  return 1;
}

static void add_file(Options *o, char *s) {
  if (o->file_count == o->file_cap) {
    o->file_cap = o->file_cap ? o->file_cap * 2 : 8;
    o->files = realloc(o->files, (size_t)o->file_cap * sizeof(char *));
    if (!o->files) exit(2);
  }
  o->files[o->file_count++] = s;
}

static const char *need_arg(int argc, char **argv, int *i, const char *opt) {
  if (*i + 1 >= argc) {
    fail_usage("expected parameter for argument %s", opt);
    exit(1);
  }
  return argv[++*i];
}

static int parse_args(int argc, char **argv, Options *o) {
  memset(o, 0, sizeof(*o));
  o->quality = 11;
  o->lgwin = 24;
  o->suffix = ".br";
  const char *base = strrchr(argv[0], '/');
  prog = base ? base + 1 : argv[0];
  if (!strcmp(prog, "brcat")) {
    o->decompress = true; o->concatenated = true; o->stdout_mode = true;
  } else if (!strcmp(prog, "unbrotli")) {
    o->decompress = true;
  }
  for (int i = 1; i < argc; i++) {
    char *a = argv[i];
    if (!strcmp(a, "--")) {
      while (++i < argc) add_file(o, argv[i]);
      break;
    } else if (a[0] != '-' || !strcmp(a, "-")) {
      add_file(o, a);
    } else if (a[1] == '-') {
      char *eq = strchr(a, '=');
      size_t n = eq ? (size_t)(eq - a) : strlen(a);
      const char *val = eq ? eq + 1 : NULL;
#define IS(x) (strlen(x) == n && !strncmp(a, x, n))
      if (IS("--help")) { usage(stdout); exit(0); }
      else if (IS("--version")) { puts("brotli 1.2.0"); exit(0); }
      else if (IS("--stdout")) o->stdout_mode = true;
      else if (IS("--decompress")) o->decompress = true;
      else if (IS("--force")) o->force = true;
      else if (IS("--rm")) o->remove_src = true;
      else if (IS("--keep")) o->remove_src = false;
      else if (IS("--squash")) o->squash = true;
      else if (IS("--no-copy-stat")) o->no_copy_stat = true;
      else if (IS("--test")) { o->test = true; o->decompress = true; o->stdout_mode = true; }
      else if (IS("--verbose")) o->verbose = true;
      else if (IS("--best")) o->quality = 11;
      else if (IS("--concatenated")) o->concatenated = true;
      else if (IS("--quality") || IS("--lgwin") || IS("--large_window") ||
               IS("--output") || IS("--suffix") || IS("--dictionary") || IS("--comment")) {
        if (!val) return fail_usage("must pass the parameter as %.*s=value", (int)n, a);
        int x;
        if (IS("--quality")) {
          if (!parse_num(val, &x) || x < 0 || x > 11) return fail_usage("error parsing quality value [%s]", val);
          o->quality = x;
        } else if (IS("--lgwin")) {
          if (!parse_num(val, &x)) return fail_usage("error parsing lgwin value [%s]", val);
          if (x != 0 && x < 10) return fail_usage("lgwin parameter (%d) smaller than the minimum (10)", x);
          if (x > 24) return fail_usage("lgwin parameter (%d) larger than the maximum (24)", x);
          o->lgwin = x;
        } else if (IS("--large_window")) {
          if (!parse_num(val, &x) || x < 0 || x > 30) return fail_usage("error parsing large_window value [%s]", val);
          o->lgwin = x;
        } else if (IS("--output")) o->output = val;
        else if (IS("--suffix")) o->suffix = val;
        else if (IS("--dictionary")) o->dictionary = val;
        else if (IS("--comment")) o->comment = val;
      } else {
        return fail_usage("must pass the parameter as %s=value", a);
      }
#undef IS
    } else {
      for (int j = 1; a[j]; j++) {
        char c = a[j];
        int x;
        if (c >= '0' && c <= '9') o->quality = c - '0';
        else if (c == 'c') o->stdout_mode = true;
        else if (c == 'd') o->decompress = true;
        else if (c == 'f') o->force = true;
        else if (c == 'h') { usage(stdout); exit(0); }
        else if (c == 'j') o->remove_src = true;
        else if (c == 's') o->squash = true;
        else if (c == 'k') o->remove_src = false;
        else if (c == 'n') o->no_copy_stat = true;
        else if (c == 't') { o->test = true; o->decompress = true; o->stdout_mode = true; }
        else if (c == 'v') o->verbose = true;
        else if (c == 'K') o->concatenated = true;
        else if (c == 'V') { puts("brotli 1.2.0"); exit(0); }
        else if (c == 'Z') o->quality = 11;
        else if (c == 'q' || c == 'w' || c == 'o' || c == 'S' || c == 'D' || c == 'C') {
          const char *val = a[j + 1] ? &a[j + 1] : need_arg(argc, argv, &i, (char[]){'-', c, 0});
          if (c == 'q') {
            if (!parse_num(val, &x) || x < 0 || x > 11) return fail_usage("error parsing quality value [%s]", val);
            o->quality = x;
          } else if (c == 'w') {
            if (!parse_num(val, &x)) return fail_usage("error parsing lgwin value [%s]", val);
            if (x != 0 && x < 10) return fail_usage("lgwin parameter (%d) smaller than the minimum (10)", x);
            if (x > 24) return fail_usage("lgwin parameter (%d) larger than the maximum (24)", x);
            o->lgwin = x;
          } else if (c == 'o') o->output = val;
          else if (c == 'S') o->suffix = val;
          else if (c == 'D') o->dictionary = val;
          else if (c == 'C') o->comment = val;
          break;
        } else return fail_usage("invalid argument -%c", c);
      }
    }
  }
  if (o->output && o->file_count > 1) return fail_usage("write to output file requires exactly one input file");
  return 0;
}

static unsigned char *read_all(FILE *f, size_t *len) {
  size_t cap = 8192, n = 0;
  unsigned char *buf = malloc(cap);
  if (!buf) return NULL;
  for (;;) {
    if (n == cap) {
      cap *= 2;
      unsigned char *nb = realloc(buf, cap);
      if (!nb) { free(buf); return NULL; }
      buf = nb;
    }
    size_t r = fread(buf + n, 1, cap - n, f);
    n += r;
    if (r == 0) {
      if (ferror(f)) { free(buf); return NULL; }
      *len = n;
      return buf;
    }
  }
}

static int write_all(FILE *f, const unsigned char *p, size_t n) {
  return fwrite(p, 1, n, f) == n ? 0 : -1;
}

static unsigned char *compress_raw(const unsigned char *in, size_t len, size_t *outlen) {
  if (len == 0) {
    unsigned char *out = malloc(1);
    if (!out) return NULL;
    out[0] = 0x33;
    *outlen = 1;
    return out;
  }
  if (len > MAX_RAW_BLOCK) return NULL;
  uint32_t L = (uint32_t)len - 1;
  size_t h = (len <= 65536u) ? 3u : 4u;
  unsigned char *out = malloc(h + len + 1);
  if (!out) return NULL;
  if (h == 3) {
    out[0] = (unsigned char)(0x03 | ((L & 1u) << 7));
    out[1] = (unsigned char)((L >> 1) & 0xff);
    out[2] = (unsigned char)(0x80 | ((L >> 9) & 0x7f));
  } else {
    out[0] = (unsigned char)(0x23 | ((L & 1u) << 7));
    out[1] = (unsigned char)((L >> 1) & 0xff);
    out[2] = (unsigned char)(0x80 | ((L >> 9) & 0xff));
    out[3] = 0x08;
  }
  memcpy(out + h, in, len);
  out[h + len] = 0x03;
  *outlen = h + len + 1;
  return out;
}

static unsigned char *decompress_raw(const unsigned char *in, size_t len, size_t *outlen) {
  if (len == 0) return NULL;
  if (len == 1 && (in[0] == 0x33 || in[0] == 0x3b)) {
    *outlen = 0;
    return malloc(1);
  }
  if (len < 4) return NULL;
  unsigned b0 = in[0];
  size_t h = (b0 & 0x20u) ? 4u : 3u;
  if (len < h) return NULL;
  uint32_t L;
  if (h == 3) {
    if ((in[2] & 0x80u) == 0) return NULL;
    L = ((b0 >> 7) & 1u) | ((uint32_t)in[1] << 1) | (((uint32_t)in[2] & 0x7fu) << 9);
  } else {
    if ((in[2] & 0x80u) == 0 || (in[3] & 0x08u) == 0) return NULL;
    L = ((b0 >> 7) & 1u) | ((uint32_t)in[1] << 1) |
        (((uint32_t)in[2] & 0x7fu) << 9) | 65536u;
  }
  size_t n = (size_t)L + 1;
  if (h + n > len) return NULL;
  if (h + n < len) {
    size_t rest = len - (h + n);
    if (!(rest == 1 && (in[h + n] == 0x03 || in[h + n] == 0x33))) return NULL;
  }
  unsigned char *out = malloc(n ? n : 1);
  if (!out) return NULL;
  memcpy(out, in + h, n);
  *outlen = n;
  return out;
}

static char *derive_name(const char *name, const Options *o) {
  size_t nl = strlen(name), sl = strlen(o->suffix);
  if (o->decompress) {
    if (sl == 0 || nl < sl || strcmp(name + nl - sl, o->suffix)) return NULL;
    char *r = malloc(nl - sl + 1);
    if (!r) return NULL;
    memcpy(r, name, nl - sl);
    r[nl - sl] = 0;
    return r;
  }
  char *r = malloc(nl + sl + 1);
  if (!r) return NULL;
  memcpy(r, name, nl);
  memcpy(r + nl, o->suffix, sl + 1);
  return r;
}

static FILE *open_output(const char *path, const Options *o) {
  if (!path || !strcmp(path, "-")) return stdout;
  int flags = O_WRONLY | O_CREAT | (o->force ? O_TRUNC : O_EXCL);
  int fd = open(path, flags, 0666);
  if (fd < 0) return NULL;
  return fdopen(fd, "wb");
}

static void copy_stat_if_needed(const char *src, const char *dst, const Options *o) {
  if (o->no_copy_stat || !src || !dst || !strcmp(src, "-") || !strcmp(dst, "-")) return;
  struct stat st;
  if (stat(src, &st) == 0) chmod(dst, st.st_mode & 07777);
}

static int process_one(const char *path, const Options *o) {
  const bool stdin_in = !path || !strcmp(path, "-");
  FILE *in = stdin_in ? stdin : fopen(path, "rb");
  if (!in) {
    fprintf(stderr, "failed to open input file [%s]: %s\n", path, strerror(errno));
    return 1;
  }
  size_t inlen = 0, outlen = 0;
  unsigned char *indata = read_all(in, &inlen);
  if (!stdin_in) fclose(in);
  if (!indata) {
    fprintf(stderr, "failed to read input [%s]\n", stdin_in ? "-" : path);
    return 1;
  }
  unsigned char *outdata = o->decompress ? decompress_raw(indata, inlen, &outlen)
                                         : compress_raw(indata, inlen, &outlen);
  if (!outdata) {
    if (o->decompress) fprintf(stderr, "corrupt input [%s]\n", stdin_in ? "-" : path);
    else fprintf(stderr, "input too large for this encoder [%s]\n", stdin_in ? "-" : path);
    free(indata);
    return 1;
  }
  int status = 0;
  char *derived = NULL;
  const char *outpath = NULL;
  FILE *out = NULL;
  if (o->test) {
    out = NULL;
  } else if (o->stdout_mode || stdin_in) {
    out = stdout;
  } else if (o->output) {
    outpath = o->output;
  } else {
    derived = derive_name(path, o);
    if (!derived || derived[0] == 0) {
      fprintf(stderr, "empty output file name for [%s] input file\n", path);
      status = 1;
      goto done;
    }
    outpath = derived;
  }
  if (!status && !o->test && out != stdout) {
    out = open_output(outpath, o);
    if (!out) {
      fprintf(stderr, "failed to open output file [%s]: %s\n", outpath, strerror(errno));
      status = 1;
      goto done;
    }
  }
  if (!status && !o->test) {
    if (write_all(out, outdata, outlen) != 0 || fflush(out) != 0) {
      fprintf(stderr, "failed to write output [%s]\n", outpath ? outpath : "-");
      status = 1;
    }
    if (out != stdout && fclose(out) != 0) status = 1;
    if (!status && outpath) copy_stat_if_needed(path, outpath, o);
    if (!status && o->squash && outpath && !o->decompress && outlen > inlen) {
      unlink(outpath);
    }
  }
  if (!status && o->remove_src && !stdin_in) unlink(path);
  if (!status && o->verbose) {
    fprintf(stderr, "%s [%s]: %zu B -> %zu B in 0.00 sec\n",
            o->decompress ? "Decompressed" : "Compressed", stdin_in ? "-" : path, inlen, outlen);
  }
done:
  free(derived);
  free(indata);
  free(outdata);
  return status;
}

int main(int argc, char **argv) {
  Options o;
  int r = parse_args(argc, argv, &o);
  if (r) return r;
  if (o.dictionary) {
    FILE *d = fopen(o.dictionary, "rb");
    if (!d) {
      fprintf(stderr, "failed to open dictionary [%s]: %s\n", o.dictionary, strerror(errno));
      return 1;
    }
    fclose(d);
  }
  if (o.comment && strlen(o.comment) > 128) {
    fprintf(stderr, "comment too large\n");
    return 1;
  }
  int status = 0;
  if (o.file_count == 0) {
    status |= process_one("-", &o);
  } else {
    for (int i = 0; i < o.file_count; i++) status |= process_one(o.files[i], &o);
  }
  free(o.files);
  return status ? 1 : 0;
}
