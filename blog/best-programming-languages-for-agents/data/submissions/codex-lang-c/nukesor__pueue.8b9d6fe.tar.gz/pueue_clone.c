#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *ROOT_HELP =
"Interact with the Pueue daemon\n\n"
"Use the `--help` long form to get detailed help output on each subcommand!\n\n"
"Usage: executable [OPTIONS] [COMMAND]\n\n"
"Commands:\n"
"  add          Enqueue a task for execution\n"
"  remove       Remove tasks from the list. Running or paused tasks need to be killed first\n"
"  switch       Switches the queue position of two commands\n"
"  stash        Stash a task. Stashed tasks won't be automatically started\n"
"  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards\n"
"  start        Resume operation of specific tasks or groups of tasks\n"
"  restart      Restart failed or successful task(s)\n"
"  pause        Either pause running tasks or specific groups of tasks\n"
"  kill         Kill specific running tasks or whole task groups\n"
"  send         Send something to a task. Useful for sending confirmations such as 'y\\n'\n"
"  edit         Adjust editable properties of a task\n"
"  env          Use this to add or remove environment variables from tasks\n"
"  group        Use this to add or remove groups\n"
"  status       Display the current status of all tasks\n"
"  log          Display the log output of finished tasks\n"
"  follow       Follow the output of a currently running task. This command works like \"tail -f\"\n"
"  wait         Wait until tasks are finished\n"
"  clean        Remove all finished tasks from the list\n"
"  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!\n"
"  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a\n"
"               service manager\n"
"  parallel     Set the amount of allowed parallel tasks\n"
"  completions  Generates shell completion files\n"
"  help         Print this message or the help of the given subcommand(s)\n\n"
"Options:\n"
"  -v, --verbose...\n"
"          Verbose mode (-v, -vv, -vvv)\n\n"
"      --color <COLOR>\n"
"          Colorize the output; auto enables color output when connected to a tty\n"
"          \n"
"          [default: auto]\n"
"          [possible values: auto, never, always]\n\n"
"  -c, --config <CONFIG>\n"
"          If provided, Pueue only uses this config file.\n"
"          \n"
"          This path can also be set via the \"PUEUE_CONFIG_PATH\" environment variable. The\n"
"          commandline option overwrites the environment variable!\n\n"
"  -p, --profile <PROFILE>\n"
"          The name of the profile that should be loaded from your config file\n\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n\n"
"  -V, --version\n"
"          Print version\n";

static const char *ADD_HELP =
"Enqueue a task for execution.\n\n"
"There're many different options when scheduling a task. Check the individual option help texts for\n"
"more information. Furthermore, please remember that scheduled commands are executed via your system\n"
"shell. This means that the command needs proper shell escaping. The safest way to preserve shell\n"
"escaping is to surround your command with quotes, for example:\n\n"
"pueue add 'ls $HOME && echo \\\"Some string\\\"'\n\n"
"Usage: executable add [OPTIONS] <COMMAND>...\n\n"
"Arguments:\n"
"  <COMMAND>...\n"
"          The command to be added\n\n"
"Options:\n"
"  -w, --working-directory <working-directory>\n"
"          Specify current working directory\n\n"
"  -e, --escape\n"
"          Escape any special shell characters (\" \", \"&\", \"!\", etc.).\n"
"          Beware: This implicitly disables nearly all shell specific syntax (\"&&\", \"&>\").\n\n"
"  -i, --immediate\n"
"          Immediately start the task\n\n"
"      --follow\n"
"          Immediately follow a task, if it's started with --immediate\n\n"
"  -s, --stashed\n"
"          Create the task in Stashed state.\n"
"          \n"
"          Useful to avoid immediate execution if the queue is empty.\n\n"
"  -d, --delay <delay>\n"
"          Prevents the task from being enqueued until 'delay' elapses. See \"enqueue\" for accepted\n"
"          formats\n\n"
"  -g, --group <GROUP>\n"
"          Assign the task to a group.\n"
"          \n"
"          Groups kind of act as separate queues. All groups run in parallel and you can specify the\n"
"          amount of parallel tasks for each group. If no group is specified, the default group will\n"
"          be used.\n"
"          \n"
"          Create groups via the `pueue group` subcommand\n\n"
"  -a, --after <after>...\n"
"          Start the task once all specified tasks have successfully finished.\n"
"          \n"
"          As soon as one of the dependencies fails, this task will fail as well.\n\n"
"  -o, --priority <PRIORITY>\n"
"          Start this task with a higher priority.\n"
"          \n"
"          The higher the number, the faster it will be processed.\n\n"
"  -l, --label <LABEL>\n"
"          Add some information for yourself.\n"
"          \n"
"          This string will be shown in the \"status\" table. There's no additional logic connected to\n"
"          it.\n\n"
"  -p, --print-task-id\n"
"          Only return the task id instead of a text.\n"
"          \n"
"          This is useful when working with dependencies in scripts.\n\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n";

static const char *ENQUEUE_HELP =
"Enqueue stashed tasks. They'll be handled normally afterwards.\n\n"
"Enqueues all stashed task in the default group if no arguments are given.\n\n"
"Usage: executable enqueue [OPTIONS] [TASK_IDS]...\n\n"
"Arguments:\n"
"  [TASK_IDS]...\n"
"          Enqueue these specific tasks\n\n"
"Options:\n"
"  -g, --group <GROUP>\n"
"          Enqueue all stashed tasks in a group\n\n"
"  -a, --all\n"
"          Enqueue all stashed tasks across all groups\n\n"
"  -d, --delay <delay>\n"
"          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below\n\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n\n"
"DELAY FORMAT:\n\n"
"    The --delay argument must be either a number of seconds or a \"date expression\" similar to GNU\n"
"    \"date -d\" with some extensions. It does not attempt to parse all natural language, but is\n"
"    incredibly flexible. Here are some supported examples.\n\n"
"    2020-04-01T18:30:00   // RFC 3339 timestamp\n"
"    2020-4-1 18:2:30      // Optional leading zeros\n"
"    2020-4-1 5:30pm       // Informal am/pm time\n"
"    2020-4-1 5pm          // Optional minutes and seconds\n"
"    April 1 2020 18:30:00 // English months\n"
"    1 Apr 8:30pm          // Implies current year\n"
"    4/1                   // American form date\n"
"    wednesday 10:30pm     // The closest wednesday in the future at 22:30\n"
"    wednesday             // The closest wednesday in the future\n"
"    4 months              // 4 months from today at 00:00:00\n"
"    1 week                // 1 week at the current time\n"
"    1days                 // 1 day from today at the current time\n"
"    1d 03:00              // The closest 3:00 after 1 day (24 hours)\n"
"    3h                    // 3 hours from now\n"
"    3600s                 // 3600 seconds from now\n";

struct Help { const char *cmd; const char *text; };

static const struct Help HELPS[] = {
{"add", NULL},
{"remove", "Remove tasks from the list. Running or paused tasks need to be killed first\n\nUsage: executable remove <TASK_IDS>...\n\nArguments:\n  <TASK_IDS>...  The task ids to be removed\n\nOptions:\n  -h, --help  Print help\n"},
{"switch", "Switches the queue position of two commands.\n\nOnly works on queued and stashed commands.\n\nUsage: executable switch <TASK_ID_1> <TASK_ID_2>\n\nArguments:\n  <TASK_ID_1>\n          The first task id\n\n  <TASK_ID_2>\n          The second task id\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"stash", "Stash a task. Stashed tasks won't be automatically started.\n\nThe enqueue an item, use the `pueue enqueue` subcommand. Stashed entries can also be explicitely\nstarted via `pueue start $task_id`.\n\nUsage: executable stash [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Stash these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Stash all queued tasks in a group\n\n  -a, --all\n          Stash all queued tasks across all groups\n\n  -d, --delay <delay>\n          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"enqueue", NULL},
{"start", "Resume operation of specific tasks or groups of tasks.\n\nWithout any parameters this resumes the default group and all its tasks. Can also be used\nforce-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my\nhave!\n\nUsage: executable start [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be\n          force-started\n\nOptions:\n  -g, --group <GROUP>\n          Resume a specific group and all paused tasks in it.\n          \n          The group will be set to running and its paused tasks will be resumed.\n\n  -a, --all\n          Resume all groups!\n          \n          All groups will be set to running and paused tasks will be resumed.\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"restart", "Restart failed or successful task(s).\n\nBy default, identical tasks will be created and enqueued, but it's possible to restart in-place. You\ncan also edit a few properties, such as the path and the command, before restarting.\n\nUsage: executable restart [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Restart these specific tasks\n\nOptions:\n  -a, --all-failed\n          Restart all failed tasks across all groups.\n\n  -g, --failed-in-group <FAILED_IN_GROUP>\n          Like `--all-failed`, but only restart tasks failed tasks of a specific group\n\n  -k, --immediate\n          Immediately start the tasks, no matter how many open slots there are. This will ignore any\n          dependencies tasks may have\n\n  -s, --stashed\n          Set the restarted task to a \"Stashed\" state. Useful to avoid immediate execution\n\n  -i, --in-place\n          Restart the task by reusing the already existing tasks. This will overwrite any previous\n          logs of the restarted tasks.\n\n      --not-in-place\n          Restart the task by creating a new identical tasks. Only necessary if you have the\n          `restart_in_place` configuration set to true\n\n  -e, --edit\n          Edit the task before restarting\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"pause", "Either pause running tasks or specific groups of tasks.\n\nBy default, pauses the default group and all its tasks. A paused queue (group) won't start any new\ntasks.\n\nUsage: executable pause [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Pause these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Pause a specific group\n\n  -a, --all\n          Pause all groups!\n\n  -w, --wait\n          Pause the specified groups, but let already running tasks finish by themselves\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"kill", "Kill specific running tasks or whole task groups.\n\nKills all tasks of the default group when no ids or a specific group are provided.\n\nUsage: executable kill [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Kill these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Kill all running tasks in a group. This also pauses the group\n\n  -a, --all\n          Kill all running tasks across ALL groups. This also pauses all groups\n\n  -s, --signal <SIGNAL>\n          Send a UNIX signal instead of simply killing the process.\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"send", "Send something to a task. Useful for sending confirmations such as 'y\\n'\n\nUsage: executable send <TASK_ID> <INPUT>\n\nArguments:\n  <TASK_ID>  The id of the task\n  <INPUT>    The input that should be sent to the process\n\nOptions:\n  -h, --help  Print help\n"},
{"edit", "Adjust editable properties of a task.\n\nOnly stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your\n$EDITOR to edit the tasks.\n\nUsage: executable edit [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          The ids of all tasks that should be edited\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"env", "Use this to add or remove environment variables from tasks\n\nUsage: executable env <COMMAND>\n\nCommands:\n  set    Set a variable for a specific task's environment\n  unset  Remove a specific variable from a task's environment\n  help   Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help\n"},
{"group", "Use this to add or remove groups.\n\nBy default, this will simply display all known groups.\n\nUsage: executable group [OPTIONS] [COMMAND]\n\nCommands:\n  add     Add a group by name\n  remove  Remove a group by name. This will move all tasks in this group to the default group!\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -j, --json\n          Print the list of groups as json\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"status", "Display the current status of all tasks\n\nUsage: executable status [OPTIONS] [QUERY]...\n\nArguments:\n  [QUERY]...\n          Users can specify a custom query to filter for specific values, order by a column\n          or limit the amount of tasks listed.\n\nOptions:\n  -j, --json\n          Print the current state as json to stdout. This does not include the output of tasks. Use\n          `log -j` if you want everything\n\n  -g, --group <GROUP>\n          Only show tasks of a specific group\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"log", "Display the log output of finished tasks.\n\nOnly the last few lines will be shown by default. If you want to follow the output of a task, please\nuse the \\\"follow\\\" subcommand.\n\nUsage: executable log [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          View the task output of these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          View the outputs of this specific group's tasks\n\n  -a, --all\n          Show the logs of all groups' tasks\n\n  -j, --json\n          Print the resulting tasks and output as json.\n\n  -l, --lines <LINES>\n          Only print the last X lines of each task's output.\n\n  -f, --full\n          Show the whole output\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"follow", "Follow the output of a currently running task. This command works like \"tail -f\"\n\nUsage: executable follow [OPTIONS] [TASK_ID]\n\nArguments:\n  [TASK_ID]\n          The id of the task you want to watch.\n\nOptions:\n  -l, --lines <LINES>\n          Only print the last X lines of the output before following\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"wait", "Wait until tasks are finished.\n\nBy default, this will wait for all tasks in the default group to finish.\n\nNote: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,\nLocked, Queued, ...]\n\nUsage: executable wait [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          This allows you to wait for specific tasks to finish\n\nOptions:\n  -g, --group <GROUP>\n          Wait for all tasks in a specific group\n\n  -a, --all\n          Wait for all tasks across all groups and the default group\n\n  -q, --quiet\n          Don't show any log output while waiting\n\n  -s, --status <STATUS>\n          Wait for tasks to reach a specific task status\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"clean", "Remove all finished tasks from the list\n\nUsage: executable clean [OPTIONS]\n\nOptions:\n  -s, --successful-only  Only clean tasks that finished successfully\n  -g, --group <GROUP>    Only clean tasks of a specific group\n  -h, --help             Print help\n"},
{"reset", "Kill all tasks, clean up afterwards and reset EVERYTHING!\n\nUsage: executable reset [OPTIONS]\n\nOptions:\n  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset\n  -f, --force            Don't ask for any confirmation\n  -h, --help             Print help\n"},
{"shutdown", "Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager\n\nUsage: executable shutdown\n\nOptions:\n  -h, --help  Print help\n"},
{"parallel", "Set the amount of allowed parallel tasks\n\nBy default, adjusts the amount of the default group.\n\nNo tasks will be stopped, if this is lowered. This limit is only considered when tasks are\nscheduled.\n\nUsage: executable parallel [OPTIONS] [PARALLEL_TASKS]\n\nArguments:\n  [PARALLEL_TASKS]\n          The amount of allowed parallel tasks.\n          \n          Setting this to 0 means an unlimited amount of parallel tasks.\n\nOptions:\n  -g, --group <group>\n          Set the amount for a specific group\n\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{"completions", "Generates shell completion files.\n\nThis can be ignored during normal operations.\n\nUsage: executable completions <SHELL> [OUTPUT_DIRECTORY]\n\nArguments:\n  <SHELL>\n          The target shell\n          \n          [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\n  [OUTPUT_DIRECTORY]\n          The output directory to which the file should be written\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n"},
{NULL, NULL}
};

static const char *lookup(const char *cmd) {
    if (strcmp(cmd, "add") == 0) return ADD_HELP;
    if (strcmp(cmd, "enqueue") == 0) return ENQUEUE_HELP;
    for (int i = 0; HELPS[i].cmd; i++) if (strcmp(HELPS[i].cmd, cmd) == 0) return HELPS[i].text;
    return NULL;
}

static int is_cmd(const char *s) { return lookup(s) != NULL; }
static int is_help_arg(const char *s) { return strcmp(s, "--help") == 0 || strcmp(s, "-h") == 0; }

static int config_error(void) {
    fprintf(stderr, "Error: \n");
    fprintf(stderr, "   0: \033[91mCouldn't find a configuration file. Did you start the daemon yet?\033[0m\n\n");
    fprintf(stderr, "Location:\n");
    fprintf(stderr, "   \033[35mpueue/src/bin/pueue.rs\033[0m:\033[35m61\033[0m\n\n");
    fprintf(stderr, "Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\n");
    fprintf(stderr, "Run with RUST_BACKTRACE=full to include source snippets.\n");
    return 1;
}

static int clap_error(const char *msg, const char *usage) {
    fprintf(stderr, "error: %s\n\nUsage: %s\n\nFor more information, try '--help'.\n", msg, usage);
    return 2;
}

static int missing(const char *what, const char *usage) {
    fprintf(stderr, "error: the following required arguments were not provided:\n  %s\n\nUsage: %s\n\nFor more information, try '--help'.\n", what, usage);
    return 2;
}

static int write_file(const char *dir, const char *name, const char *content) {
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", dir, name);
    FILE *f = fopen(path, "w");
    if (!f) return 1;
    fputs(content, f);
    fclose(f);
    return 0;
}

static int completions(int argc, char **argv) {
    if (argc < 2) return missing("<SHELL>", "executable completions <SHELL> [OUTPUT_DIRECTORY]");
    if (is_help_arg(argv[1])) { fputs(lookup("completions"), stdout); return 0; }
    const char *shell = argv[1];
    const char *script =
"_pueue() {\n"
"    local i cur prev opts cmd\n"
"    COMPREPLY=()\n"
"    cur=\"${COMP_WORDS[COMP_CWORD]}\"\n"
"    prev=\"${COMP_WORDS[COMP_CWORD-1]}\"\n"
"    opts=\"add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions help --help --version\"\n"
"    COMPREPLY=( $(compgen -W \"${opts}\" -- \"${cur}\") )\n"
"}\n"
"complete -F _pueue -o bashdefault -o default pueue\n";
    if (strcmp(shell, "bash") && strcmp(shell, "elvish") && strcmp(shell, "fish") &&
        strcmp(shell, "power-shell") && strcmp(shell, "zsh") && strcmp(shell, "nushell"))
        return clap_error("invalid value for '<SHELL>'", "executable completions <SHELL> [OUTPUT_DIRECTORY]");
    if (argc >= 3) {
        const char *name = strcmp(shell, "zsh") == 0 ? "_pueue" : strcmp(shell, "fish") == 0 ? "pueue.fish" : "pueue";
        return write_file(argv[2], name, script);
    }
    fputs(script, stdout);
    return 0;
}

static int nested_help(int argc, char **argv) {
    if (argc >= 3 && is_help_arg(argv[2])) {
        if (!strcmp(argv[0], "env") && !strcmp(argv[1], "set")) {
            fputs("Set a variable for a specific task's environment\n\nUsage: executable env set <TASK_ID> <KEY> <VALUE>\n\nArguments:\n  <TASK_ID>  The id of the task for which the variable should be set\n  <KEY>      The name of the environment variable to set\n  <VALUE>    The value of the environment variable to set\n\nOptions:\n  -h, --help  Print help\n", stdout);
            return 0;
        }
        if (!strcmp(argv[0], "env") && !strcmp(argv[1], "unset")) {
            fputs("Remove a specific variable from a task's environment\n\nUsage: executable env unset <TASK_ID> <KEY>\n\nArguments:\n  <TASK_ID>  The id of the task for which the variable should be set\n  <KEY>      The name of the environment variable to set\n\nOptions:\n  -h, --help  Print help\n", stdout);
            return 0;
        }
        if (!strcmp(argv[0], "group") && !strcmp(argv[1], "add")) {
            fputs("Add a group by name\n\nUsage: executable group add [OPTIONS] <NAME>\n\nArguments:\n  <NAME>\n          \n\nOptions:\n  -p, --parallel <PARALLEL>\n          Set the amount of parallel tasks this group can have.\n          \n          Setting this to 0 means an unlimited amount of parallel tasks.\n\n  -h, --help\n          Print help (see a summary with '-h')\n", stdout);
            return 0;
        }
        if (!strcmp(argv[0], "group") && !strcmp(argv[1], "remove")) {
            fputs("Remove a group by name. This will move all tasks in this group to the default group!\n\nUsage: executable group remove <NAME>\n\nArguments:\n  <NAME>  \n\nOptions:\n  -h, --help  Print help\n", stdout);
            return 0;
        }
    }
    return -1;
}

int main(int argc, char **argv) {
    (void)argv;
    if (argc == 1) return config_error();
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--version") || !strcmp(argv[i], "-V")) { puts("pueue 4.0.4"); return 0; }
        if (!strcmp(argv[i], "--color")) { if (++i >= argc) return missing("<COLOR>", "executable --color <COLOR> [COMMAND]"); continue; }
        if (!strcmp(argv[i], "--config") || !strcmp(argv[i], "-c") || !strcmp(argv[i], "--profile") || !strcmp(argv[i], "-p")) { if (++i >= argc) return 2; continue; }
        if (!strncmp(argv[i], "-v", 2) && argv[i][0] == '-') continue;
        if (is_help_arg(argv[i])) { fputs(ROOT_HELP, stdout); return 0; }
        break;
    }
    int first = 1;
    while (first < argc && argv[first][0] == '-' && strcmp(argv[first], "--help") && strcmp(argv[first], "-h") && strcmp(argv[first], "--version") && strcmp(argv[first], "-V")) {
        if (!strcmp(argv[first], "--color") || !strcmp(argv[first], "--config") || !strcmp(argv[first], "-c") || !strcmp(argv[first], "--profile") || !strcmp(argv[first], "-p")) first += 2;
        else first++;
    }
    if (first >= argc) return config_error();
    const char *cmd = argv[first];
    if (!strcmp(cmd, "help")) {
        if (first + 1 < argc && is_cmd(argv[first + 1])) fputs(lookup(argv[first + 1]), stdout);
        else fputs(ROOT_HELP, stdout);
        return 0;
    }
    if (cmd[0] == '-') {
        char msg[256]; snprintf(msg, sizeof(msg), "unexpected argument '%s' found", cmd);
        return clap_error(msg, "executable [OPTIONS] [COMMAND]");
    }
    if (!is_cmd(cmd)) {
        char msg[256]; snprintf(msg, sizeof(msg), "unrecognized subcommand '%s'", cmd);
        return clap_error(msg, "executable [OPTIONS] [COMMAND]");
    }
    if (first + 1 < argc && is_help_arg(argv[first + 1])) { fputs(lookup(cmd), stdout); return 0; }
    if ((!strcmp(cmd, "env") || !strcmp(cmd, "group")) && first + 1 < argc) {
        int r = nested_help(argc - first, argv + first);
        if (r >= 0) return r;
    }
    if (!strcmp(cmd, "completions")) return completions(argc - first, argv + first);
    if (!strcmp(cmd, "remove") && first + 1 >= argc) return missing("<TASK_IDS>...", "executable remove <TASK_IDS>...");
    if (!strcmp(cmd, "switch") && first + 2 >= argc) return missing(first + 1 >= argc ? "<TASK_ID_1>\n  <TASK_ID_2>" : "<TASK_ID_2>", "executable switch <TASK_ID_1> <TASK_ID_2>");
    if (!strcmp(cmd, "send") && first + 2 >= argc) return missing(first + 1 >= argc ? "<TASK_ID>\n  <INPUT>" : "<INPUT>", "executable send <TASK_ID> <INPUT>");
    if (!strcmp(cmd, "add") && first + 1 >= argc) return missing("<COMMAND>...", "executable add <COMMAND>...");
    if (!strcmp(cmd, "shutdown") && first + 1 < argc) return clap_error("unexpected argument found", "executable shutdown");
    return config_error();
}
