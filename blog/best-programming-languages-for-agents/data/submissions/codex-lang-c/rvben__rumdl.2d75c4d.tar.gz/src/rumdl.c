#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct { const char *code, *name, *summary, *category; bool fixable; } Rule;
static Rule rules[] = {
{"MD001","heading-increment","Heading levels should only increment by one level at a time","headings",true},
{"MD003","heading-style","Heading style","headings",true},
{"MD004","ul-style","Use consistent style for unordered list markers","lists",true},
{"MD005","list-indent","List indentation should be consistent","lists",true},
{"MD007","ul-indent","Unordered list indentation","lists",true},
{"MD009","no-trailing-spaces","Trailing spaces should be removed","whitespace",true},
{"MD010","no-hard-tabs","No tabs","whitespace",true},
{"MD011","no-reversed-links","Reversed link syntax","links",true},
{"MD012","no-multiple-blanks","Multiple consecutive blank lines","whitespace",true},
{"MD013","line-length","Line length should not be excessive","line-length",false},
{"MD014","commands-show-output","Commands in code blocks should show output","code",false},
{"MD018","no-missing-space-atx","No space after hash in heading","headings",true},
{"MD019","no-multiple-space-atx","Multiple spaces after hash in heading","headings",true},
{"MD020","no-missing-space-closed-atx","No space inside hashes on closed heading","headings",true},
{"MD021","no-multiple-space-closed-atx","Multiple spaces inside hashes on closed heading","headings",true},
{"MD022","blanks-around-headings","Headings should be surrounded by blank lines","headings",true},
{"MD023","heading-start-left","Headings must start at the beginning of the line","headings",true},
{"MD024","no-duplicate-heading","Multiple headings with the same content","headings",false},
{"MD025","single-title","Multiple top-level headings in the same document","headings",false},
{"MD026","no-trailing-punctuation","Trailing punctuation in heading","headings",true},
{"MD027","no-multiple-space-blockquote","Multiple spaces after quote marker (>)","blockquote",true},
{"MD028","no-blanks-blockquote","Blank line inside blockquote","blockquote",false},
{"MD029","ol-prefix","Ordered list marker value","lists",true},
{"MD030","list-marker-space","Spaces after list markers should be consistent","lists",true},
{"MD031","blanks-around-fences","Fenced code blocks should be surrounded by blank lines","code",true},
{"MD032","blanks-around-lists","Lists should be surrounded by blank lines","lists",true},
{"MD033","no-inline-html","Inline HTML is not allowed","html",false},
{"MD034","no-bare-urls","No bare URLs - wrap URLs in angle brackets","links",true},
{"MD035","hr-style","Horizontal rule style","style",true},
{"MD036","no-emphasis-as-heading","Emphasis should not be used instead of a heading","emphasis",false},
{"MD037","no-space-in-emphasis","Spaces inside emphasis markers","emphasis",true},
{"MD038","no-space-in-code","Spaces inside code span elements","code",true},
{"MD039","no-space-in-links","Spaces inside link text","links",true},
{"MD040","fenced-code-language","Code blocks should have a language specified","code",false},
{"MD041","first-line-heading","First line in file should be a top level heading","headings",false},
{"MD042","no-empty-links","No empty links","links",false},
{"MD043","required-headings","Required heading structure","headings",false},
{"MD044","proper-names","Proper names should have the correct capitalization","spelling",false},
{"MD045","no-alt-text","Images should have alternate text (alt text)","accessibility",false},
{"MD046","code-block-style","Code blocks should use a consistent style","code",true},
{"MD047","single-trailing-newline","Files should end with a single newline character","whitespace",true},
{"MD048","code-fence-style","Code fence style should be consistent","code",true},
{"MD049","emphasis-style","Emphasis style should be consistent","emphasis",true},
{"MD050","strong-style","Strong emphasis style should be consistent","emphasis",true},
{"MD051","link-fragments","Link fragments should reference valid headings","links",false},
{"MD052","reference-links-images","Reference links and images should use a reference that exists","links",false},
{"MD053","link-image-reference-definitions","Link and image reference definitions should be needed","links",false},
{"MD054","link-image-style","Link and image style should be consistent","links",false},
{"MD055","table-pipe-style","Table pipe style should be consistent","table",true},
{"MD056","table-column-count","Table column count should be consistent","table",false},
{"MD057","no-broken-links","Relative links should point to existing files","links",false},
{"MD058","blanks-around-tables","Tables should be surrounded by blank lines","table",true},
{"MD059","descriptive-link-text","Link text should be descriptive","links",false},
{"MD060","table-column-alignment","Table columns should be consistently aligned","table",true},
{"MD061","forbidden-terms","Forbidden terms","spelling",false},
{"MD062","no-space-in-link-dest","Link destination should not have leading or trailing whitespace","links",true},
{"MD063","heading-capitalization","Heading capitalization","headings",false},
{"MD064","no-multiple-spaces","Multiple consecutive spaces","whitespace",true},
{"MD065","blanks-around-hrs","Horizontal rules should be surrounded by blank lines","style",true},
{"MD066","footnote-validation","Footnote validation","footnotes",false},
{"MD067","footnote-order","Footnote definitions should appear in order of first reference","footnotes",false},
{"MD068","no-empty-footnote","Footnote definitions should not be empty","footnotes",false},
{"MD069","duplicate-list-markers","Duplicate list markers","lists",false},
{"MD070","nested-code-fence","Nested code fence collision - use longer fence to avoid premature closure","code",false},
{"MD071","blank-line-after-frontmatter","Blank line after frontmatter","frontmatter",true},
{"MD072","frontmatter-key-sort","Frontmatter keys should be sorted alphabetically","frontmatter",true},
{"MD073","toc","Table of Contents should match document headings","toc",false},
};
static int rule_count = sizeof(rules)/sizeof(rules[0]);

typedef struct { char *s; size_t n, cap; } Str;
static void sadd(Str *b, const char *s){ size_t l=strlen(s); if(b->n+l+1>b->cap){ b->cap=(b->n+l+1)*2+64; b->s=realloc(b->s,b->cap);} memcpy(b->s+b->n,s,l+1); b->n+=l; }
static void saddf(Str *b, const char *fmt,...){ char tmp[2048]; va_list ap; va_start(ap,fmt); vsnprintf(tmp,sizeof(tmp),fmt,ap); va_end(ap); sadd(b,tmp); }
static char *xstrdup(const char *s){ char *p=malloc(strlen(s)+1); strcpy(p,s); return p; }
static bool starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static int visual_len(const char *s){ int n=0; for(;*s && *s!='\n' && *s!='\r';s++) n += (*s=='\t')?4:1; return n; }
static bool blank(const char *s){ for(;*s;s++) if(*s!=' '&&*s!='\t'&&*s!='\r'&&*s!='\n') return false; return true; }

typedef struct { char *path; } Path;
typedef struct { Path *v; int n,cap; } Paths;
static void add_path(Paths *p,const char *s){ if(p->n==p->cap){p->cap=p->cap?p->cap*2:32;p->v=realloc(p->v,p->cap*sizeof(Path));} p->v[p->n++].path=xstrdup(s); }
static bool is_md(const char *p){ const char *e=strrchr(p,'.'); return e && (!strcasecmp(e,".md") || !strcasecmp(e,".markdown") || !strcasecmp(e,".mdown")); }
static void collect(Paths *out,const char *p){
 struct stat st; if(stat(p,&st)) return;
 if(S_ISDIR(st.st_mode)){ DIR *d=opendir(p); if(!d) return; struct dirent *de; while((de=readdir(d))){ if(de->d_name[0]=='.') continue; char buf[4096]; snprintf(buf,sizeof(buf),"%s/%s",p,de->d_name); collect(out,buf);} closedir(d); }
 else if(S_ISREG(st.st_mode)&&is_md(p)) add_path(out,p);
}

typedef struct { char **v; int n; } Lines;
static char *read_all(FILE *f, size_t *len){ Str b={0}; char buf[4096]; size_t r; while((r=fread(buf,1,sizeof(buf),f))>0){ if(b.n+r+1>b.cap){b.cap=(b.n+r+1)*2;b.s=realloc(b.s,b.cap);} memcpy(b.s+b.n,buf,r); b.n+=r;} if(!b.s)b.s=xstrdup(""); else b.s[b.n]=0; *len=b.n; return b.s; }
static Lines split_lines(const char *txt){ Lines l={0}; int cap=0; const char *p=txt,*q; while(*p){ q=strchr(p,'\n'); size_t n=q?(size_t)(q-p+1):strlen(p); if(l.n==cap){cap=cap?cap*2:32;l.v=realloc(l.v,cap*sizeof(char*));} char *s=malloc(n+1); memcpy(s,p,n); s[n]=0; l.v[l.n++]=s; p=q?q+1:p+n; } if(l.n==0){l.v=malloc(sizeof(char*));l.v[l.n++]=xstrdup("");} return l; }

typedef struct { char code[8], msg[256], file[1024]; int line,col; bool fixable, fixed, error; } Issue;
typedef struct { Issue *v; int n,cap; } Issues;
static void issue(Issues *is,const char *file,int line,int col,const char *code,bool err,bool fix,const char *fmt,...){
 if(is->n==is->cap){is->cap=is->cap?is->cap*2:64;is->v=realloc(is->v,is->cap*sizeof(Issue));}
 Issue *x=&is->v[is->n++]; memset(x,0,sizeof(*x)); snprintf(x->code,sizeof(x->code),"%s",code); snprintf(x->file,sizeof(x->file),"%s",file); x->line=line; x->col=col; x->fixable=fix; x->error=err;
 va_list ap; va_start(ap,fmt); vsnprintf(x->msg,sizeof(x->msg),fmt,ap); va_end(ap);
}
static const Rule *find_rule(const char *id){ for(int i=0;i<rule_count;i++) if(!strcasecmp(id,rules[i].code)||!strcasecmp(id,rules[i].name)) return &rules[i]; return NULL; }

typedef struct {
 bool enable_only; bool enabled[128]; bool disabled[128];
 bool fix,diff,quiet,silent,stdin_mode,no_config;
 int line_length;
 char output[32], stdin_name[256], config_path[1024];
} Opt;
static int ridx(const char *code){ for(int i=0;i<rule_count;i++) if(!strcasecmp(code,rules[i].code)) return i; return -1; }
static bool active(Opt *o,const char *code){ int i=ridx(code); if(i<0)return false; if(o->enable_only) return o->enabled[i]; return !o->disabled[i]; }
static void parse_rule_list(Opt *o,const char *s,bool en,bool only){ char *c=xstrdup(s),*tok=strtok(c,","); if(only) o->enable_only=true; while(tok){ char *t=trim(tok); int i=ridx(t); if(i>=0){ if(en)o->enabled[i]=true; else o->disabled[i]=true; } tok=strtok(NULL,","); } free(c); }
static void parse_quoted_rules(Opt *o, char *line, bool en){
 char *p=line;
 while((p=strchr(p,'"'))){ char *q=strchr(++p,'"'); if(!q) break; *q=0; parse_rule_list(o,p,en,en); p=q+1; }
}
static void load_config(Opt *o){
 if(o->no_config) return;
 const char *cands[3]={o->config_path[0]?o->config_path:".rumdl.toml","rumdl.toml","pyproject.toml"};
 FILE *f=NULL;
 for(int i=0;i<3&&!f;i++) if(cands[i]&&*cands[i]) f=fopen(cands[i],"r");
 if(!f) return;
 char line[1024], section[64]="";
 while(fgets(line,sizeof(line),f)){
  char *hash=strchr(line,'#'); if(hash) *hash=0;
  char *t=trim(line); if(!*t) continue;
  if(*t=='['){ char *e=strchr(t,']'); if(e){ *e=0; snprintf(section,sizeof(section),"%s",t+1);} continue; }
  if(!strcasecmp(section,"global") || !strcasecmp(section,"tool.rumdl.global")){
   if(starts(t,"disable")) parse_quoted_rules(o,t,false);
   else if(starts(t,"enable")) parse_quoted_rules(o,t,true);
  } else if(!strcasecmp(section,"MD013") || !strcasecmp(section,"tool.rumdl.MD013")){
   if(starts(t,"line-length")||starts(t,"line_length")){
    char *eq=strchr(t,'='); if(eq){ int v=atoi(eq+1); if(v>0)o->line_length=v; }
   }
  }
 }
 fclose(f);
}

static int heading_level(const char *s, int *col, const char **text){
 int i=0; while(s[i]==' '||s[i]=='\t') i++; if(s[i]!='#') return 0; int c=i; int n=0; while(s[i]=='#'){n++;i++;} if(n>6) return 0; *col=c+1; if(text)*text=s+i; return n;
}
static bool list_line(const char *s){ int i=0; while(s[i]==' ')i++; if((s[i]=='-'||s[i]=='+'||s[i]=='*') && (s[i+1]==' '||s[i+1]=='\t')) return true; if(isdigit((unsigned char)s[i])){ while(isdigit((unsigned char)s[i]))i++; return (s[i]=='.'||s[i]==')')&&(s[i+1]==' '||s[i+1]=='\t'); } return false; }
static bool fence_line(const char *s){ int i=0; while(s[i]==' ')i++; return starts(s+i,"```")||starts(s+i,"~~~"); }
static bool hr_line(const char *s){ char ch=0; int c=0; for(;*s&&*s!='\n';s++){ if(*s==' '||*s=='\t')continue; if(*s!='-'&&*s!='*'&&*s!='_')return false; if(!ch)ch=*s; if(*s!=ch)return false; c++; } return c>=3; }

static void fix_line_replace(char **line, const char *news){ free(*line); *line=xstrdup(news); }
static void apply_simple_fixes(Lines *ls, Issues *is){
 for(int k=0;k<is->n;k++){
  Issue *x=&is->v[k]; int i=x->line-1; if(i<0||i>=ls->n||!x->fixable) continue; char *s=ls->v[i];
  if(!strcmp(x->code,"MD018")){ int j=0,n=0; while(s[j]==' ')j++; while(s[j+n]=='#')n++; if(s[j+n] && s[j+n]!=' '){ Str b={0}; char pre[64]; snprintf(pre,sizeof(pre),"%.*s%.*s ",j,s,n,s+j); sadd(&b,pre); sadd(&b,s+j+n); fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s);} }
  else if(!strcmp(x->code,"MD019")){ int j=0,n=0; while(s[j]==' ')j++; while(s[j+n]=='#')n++; int p=j+n; while(s[p]==' ')p++; Str b={0}; saddf(&b,"%.*s%.*s ",j,s,n,s+j); sadd(&b,s+p); fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s); }
  else if(!strcmp(x->code,"MD010")){ Str b={0}; for(char *p=s;*p;p++){ if(*p=='\t') sadd(&b,"    "); else { char t[2]={*p,0}; sadd(&b,t);} } fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s); }
  else if(!strcmp(x->code,"MD009")){ int len=strlen(s); int nl=(len&&s[len-1]=='\n'); int e=len-nl; while(e>0&&(s[e-1]==' '||s[e-1]=='\t'))e--; Str b={0}; saddf(&b,"%.*s%s",e,s,nl?"\n":""); fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s); }
  else if(!strcmp(x->code,"MD027")){ int p=0; while(s[p]==' ')p++; if(s[p]=='>'){p++; while(s[p]==' ')p++; Str b={0}; saddf(&b,"%.*s> ",p? p-1:0,s); sadd(&b,s+p); fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s);} }
  else if(!strcmp(x->code,"MD030")){ int p=0; while(s[p]==' ')p++; int m=p; if(s[p]=='-'||s[p]=='+'||s[p]=='*')p++; else { while(isdigit((unsigned char)s[p]))p++; if(s[p]=='.'||s[p]==')')p++; } while(s[p]==' '||s[p]=='\t')p++; Str b={0}; saddf(&b,"%.*s ",p?m+1:0,s); sadd(&b,s+p); fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s); }
  else if(!strcmp(x->code,"MD034")){ char *u=strstr(s,"http://"); if(!u)u=strstr(s,"https://"); if(u && (u==s||u[-1]!='<' )){ char *e=u; while(*e&&!isspace((unsigned char)*e)&&*e!=')'&&*e!='>')e++; Str b={0}; saddf(&b,"%.*s<%.*s>%s",(int)(u-s),s,(int)(e-u),u,e); fix_line_replace(&ls->v[i],b.s); x->fixed=true; free(b.s);} }
 }
}

static void lint_file(const char *file, const char *content, Opt *o, Issues *is, bool dofix, char **fixed_out){
 Lines ls=split_lines(content); int prev_head=0,h1=0; bool in_fence=false; char fence_ch=0; char first_ul=0, first_fence=0; char *heads[512]; int hn=0;
 for(int i=0;i<ls.n;i++){
  char *s=ls.v[i]; int line=i+1; int col=1; const char *htext=NULL; int hl=heading_level(s,&col,&htext);
  if(fence_line(s)){ int p=0; while(s[p]==' ')p++; char ch=s[p]; if(!in_fence){ in_fence=true; fence_ch=ch; if(!first_fence) first_fence=ch; else if(first_fence!=ch && active(o,"MD048")) issue(is,file,line,p+1,"MD048",false,true,"Code fence style should be consistent"); char *after=s+p+3; if(active(o,"MD040") && blank(after)) issue(is,file,line,p+1,"MD040",false,false,"Fenced code blocks should have a language specified"); if(active(o,"MD031") && i>0 && !blank(ls.v[i-1]) && !list_line(ls.v[i-1])) issue(is,file,line,1,"MD031",false,true,"Fenced code blocks should be surrounded by blank lines"); } else if(ch==fence_ch){ if(active(o,"MD031") && i+1<ls.n && !blank(ls.v[i+1]) && !list_line(ls.v[i+1])) issue(is,file,line,1,"MD031",false,true,"Fenced code blocks should be surrounded by blank lines"); in_fence=false; } }
  if(!in_fence){
   if(active(o,"MD009")){ int len=strlen(s), nl=(len&&s[len-1]=='\n'), e=len-nl, trail=0; while(e-trail>0&&(s[e-trail-1]==' '||s[e-trail-1]=='\t'))trail++; if(trail>2 || (trail>0 && e==trail)) issue(is,file,line,e-trail+1,"MD009",false,true,"Trailing spaces should be removed"); }
   if(active(o,"MD010")){ char *t=strchr(s,'\t'); if(t) issue(is,file,line,(int)(t-s)+1,"MD010",false,true,"Found tab for alignment, use spaces instead"); }
   if(active(o,"MD012") && i>=2 && blank(s)&&blank(ls.v[i-1])&& !blank(ls.v[i-2])) issue(is,file,line,1,"MD012",false,true,"Multiple consecutive blank lines between content");
   if(active(o,"MD013") && visual_len(s)>o->line_length) issue(is,file,line,o->line_length+1,"MD013",false,false,"Line length [%d] exceeds configured limit [%d]",visual_len(s),o->line_length);
   if(hl){
    if(col>1 && active(o,"MD023")) issue(is,file,line,col,"MD023",false,true,"Headings must start at the beginning of the line");
    if(prev_head && hl>prev_head+1 && active(o,"MD001")) issue(is,file,line,1,"MD001",true,true,"Expected heading level %d, but found heading level %d",prev_head+1,hl);
    prev_head=hl; if(hl==1){ h1++; if(h1>1 && active(o,"MD025")) issue(is,file,line,1,"MD025",true,false,"Multiple top-level headings in the same document"); }
    if(*htext && *htext!=' ' && *htext!='\t' && active(o,"MD018")) issue(is,file,line,col+hl,"MD018",false,true,"No space after # in heading");
    if(htext[0]==' '&&htext[1]==' ' && active(o,"MD019")) issue(is,file,line,col+hl,"MD019",false,true,"Multiple spaces after hash in heading");
    if(active(o,"MD022")){ if(i>0&&!blank(ls.v[i-1])) issue(is,file,line,1,"MD022",false,true,"Expected 1 blank line above heading"); if(i+1<ls.n&&!blank(ls.v[i+1])) issue(is,file,line,1,"MD022",false,true,"Expected 1 blank line below heading"); }
    char tmp[512]; snprintf(tmp,sizeof(tmp),"%s",trim((char*)htext)); int L=strlen(tmp); while(L>0&&tmp[L-1]=='#') tmp[--L]=0; trim(tmp); L=strlen(tmp);
    if(L>0 && strchr(".,;:!",tmp[L-1]) && active(o,"MD026")) issue(is,file,line,L+hl+1,"MD026",false,true,"Trailing punctuation in heading");
    for(int q=0;q<hn;q++) if(!strcasecmp(heads[q],tmp) && active(o,"MD024")){ issue(is,file,line,1,"MD024",false,false,"Multiple headings with the same content"); break; } if(hn<512) heads[hn++]=xstrdup(tmp);
   }
   if(active(o,"MD041") && i==0 && !hl) issue(is,file,line,1,"MD041",false,false,"First line in file should be a top level heading");
   if(active(o,"MD027")){ int p=0; while(s[p]==' ')p++; if(s[p]=='>'&&s[p+1]==' '&&s[p+2]==' ') issue(is,file,line,p+2,"MD027",false,true,"Multiple spaces after blockquote symbol"); }
   if(list_line(s)){ int p=0; while(s[p]==' ')p++; if(s[p]=='-'||s[p]=='+'||s[p]=='*'){ if(!first_ul) first_ul=s[p]; else if(first_ul!=s[p]&&active(o,"MD004")) issue(is,file,line,p+1,"MD004",false,true,"Unordered list style should be consistent"); } int m=p; if(s[p]=='-'||s[p]=='+'||s[p]=='*')p++; else { while(isdigit((unsigned char)s[p]))p++; if(s[p]=='.'||s[p]==')')p++; } int sp=0; while(s[p+sp]==' '||s[p+sp]=='\t')sp++; if(sp!=1&&active(o,"MD030")) issue(is,file,line,p+1,"MD030",false,true,"Spaces after list markers should be consistent"); if(active(o,"MD032")){ if(i>0&&!blank(ls.v[i-1])&&!list_line(ls.v[i-1])) issue(is,file,line,1,"MD032",false,true,"Lists should be surrounded by blank lines"); if(i+1<ls.n&&!blank(ls.v[i+1])&&!list_line(ls.v[i+1])) issue(is,file,line,1,"MD032",false,true,"Lists should be surrounded by blank lines"); } (void)m; }
   if(active(o,"MD033")){ for(char *p=s;(p=strchr(p,'<'));p++){ if(isalpha((unsigned char)p[1])||p[1]=='/'){ issue(is,file,line,(int)(p-s)+1,"MD033",false,false,"Inline HTML is not allowed"); break; } } }
   if(active(o,"MD034")){ char *u=strstr(s,"http://"); if(!u)u=strstr(s,"https://"); if(u && (u==s|| (u[-1]!='<' && u[-1]!='('))) issue(is,file,line,(int)(u-s)+1,"MD034",false,true,"Bare URL used"); }
   if(active(o,"MD011")){ char *p=strstr(s,")[" ); if(p && strchr(s,'(')<p) issue(is,file,line,1,"MD011",false,true,"Reversed link syntax"); }
   if(active(o,"MD038")){ char *p=strchr(s,'`'); if(p&&p[1]==' '){ issue(is,file,line,(int)(p-s)+1,"MD038",false,true,"Spaces inside code span elements"); } }
   if(active(o,"MD039")){ char *p=strstr(s,"[ "); if(p) issue(is,file,line,(int)(p-s)+1,"MD039",false,true,"Spaces inside link text"); }
   if(active(o,"MD042")){ char *p=strstr(s,"]()"); if(p) issue(is,file,line,(int)(p-s)+1,"MD042",false,false,"No empty links"); }
   if(active(o,"MD045")){ char *p=strstr(s,"![]("); if(p) issue(is,file,line,(int)(p-s)+1,"MD045",false,false,"Images should have alternate text (alt text)"); }
   if(active(o,"MD064")){
    for(int p=0;s[p]&&s[p]!='\n';p++) {
     if(s[p]==' '&&s[p+1]==' '){
      int q=p+2; while(s[q]==' ') q++;
      if(s[q] && s[q]!='\n' && s[q]!='\r') issue(is,file,line,p+1,"MD064",false,true,"Multiple consecutive spaces");
      break;
     }
    }
   }
   if(hr_line(s) && active(o,"MD065")){ if(i>0&&!blank(ls.v[i-1])) issue(is,file,line,1,"MD065",false,true,"Horizontal rules should be surrounded by blank lines"); if(i+1<ls.n&&!blank(ls.v[i+1])) issue(is,file,line,1,"MD065",false,true,"Horizontal rules should be surrounded by blank lines"); }
  }
 }
 if(active(o,"MD047")){ size_t n=strlen(content); if(n==0 || content[n-1]!='\n') issue(is,file,ls.n,1,"MD047",false,true,"Files should end with a single newline character"); else if(n>=2 && content[n-2]=='\n') issue(is,file,ls.n,1,"MD047",false,true,"Files should end with a single newline character"); }
 if(dofix){ apply_simple_fixes(&ls,is); Str b={0}; for(int i=0;i<ls.n;i++) sadd(&b,ls.v[i]); if(b.n==0 || b.s[b.n-1]!='\n') sadd(&b,"\n"); *fixed_out=b.s; }
 for(int i=0;i<hn;i++) free(heads[i]); for(int i=0;i<ls.n;i++) free(ls.v[i]); free(ls.v);
}

static void print_help(void){
 puts("A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)\n");
 puts("Usage: executable [OPTIONS] <COMMAND>\n");
 puts("Commands:\n  check        Lint Markdown files and print warnings/errors\n  fmt          Format Markdown files (alias for check --fix)\n  init         Initialize a new configuration file\n  rule         Show information about a rule or list all rules\n  explain      Explain a rule with detailed information and examples\n  config       Show configuration or query a specific key\n  server       Start the Language Server Protocol server\n  schema       Generate or check JSON schema for rumdl.toml\n  import       Import and convert markdownlint configuration files\n  vscode       Install the rumdl VS Code extension\n  completions  Generate shell completion scripts\n  clean        Clear the cache\n  version      Show version information\n  help         Print this message or the help of the given subcommand(s)\n");
 puts("Options:\n      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]\n      --config <CONFIG>  Path to configuration file\n      --no-config        Ignore all configuration files and use built-in defaults\n      --isolated         Ignore all configuration files (alias for --no-config)\n  -h, --help             Print help\n  -V, --version          Print version");
}
static void check_help(void){ puts("Lint Markdown files and print warnings/errors\n\nUsage: executable check [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  Files or directories to lint (use '-' for stdin)\n\nOptions:\n  -f, --fix          Fix issues automatically where possible\n      --diff         Show diff of what would be fixed instead of fixing files\n      --check        Exit with code 1 if any formatting changes would be made (for CI)\n  -l, --list-rules   List all available rules\n  -d, --disable <DISABLE>  Disable specific rules (comma-separated)\n  -e, --enable <ENABLE>    Enable only specific rules (comma-separated) [aliases: --rules]\n  -q, --quiet        Print diagnostics, but nothing else\n  -o, --output <OUTPUT>    Output format: text (default) or json [default: text]\n      --output-format <OUTPUT_FORMAT>  Output format\n      --stdin        Read from stdin instead of files\n      --stdin-filename <STDIN_FILENAME>  Filename to use when reading from stdin\n  -s, --silent       Disable all logging\n  -h, --help         Print help"); }

static void list_rules(void){ puts("Available rules:"); for(int i=0;i<rule_count;i++) printf("  %s - %s\n",rules[i].code,rules[i].summary); printf("\nTotal: %d rules\n",rule_count); }
static void rule_cmd(int argc,char **argv){
 const char *fmt="text", *want=NULL; bool cats=false, fixonly=false; for(int i=2;i<argc;i++){ if(!strcmp(argv[i],"--output-format")||!strcmp(argv[i],"-o")){ if(i+1<argc)fmt=argv[++i]; } else if(!strcmp(argv[i],"--list-categories")) cats=true; else if(!strcmp(argv[i],"--fixable")||!strcmp(argv[i],"-f")) fixonly=true; else if(argv[i][0]!='-') want=argv[i]; }
 if(cats){ puts("accessibility\nblockquote\ncode\nemphasis\nfrontmatter\nheadings\nhtml\nline-length\nlinks\nlists\nspelling\nstyle\ntable\nwhitespace"); return; }
 if(want){ const Rule *r=find_rule(want); if(!r){ fprintf(stderr,"Error: Unknown rule: %s\n",want); exit(1);} if(!strcmp(fmt,"json")) printf("{\n  \"code\": \"%s\",\n  \"name\": \"%s\",\n  \"aliases\": [],\n  \"summary\": \"%s\",\n  \"category\": \"%s\",\n  \"fix\": \"%s\",\n  \"fix_availability\": \"%s\",\n  \"url\": \"https://rumdl.dev/%s/\"\n}\n",r->code,r->name,r->summary,r->category,r->fixable?"Fix is available.":"Fix is not available.",r->fixable?"Available":"None",r->code); else printf("%s - %s\n\nName: %s\nCategory: %s\nFix: %s\nDocumentation: https://rumdl.dev/%s/\n",r->code,r->summary,r->name,r->category,r->fixable?"Fix is available.":"Fix is not available.",r->code); return; }
 if(!strcmp(fmt,"json")){ puts("["); for(int i=0;i<rule_count;i++){ if(fixonly&&!rules[i].fixable)continue; printf("  {\"code\":\"%s\",\"name\":\"%s\",\"summary\":\"%s\",\"category\":\"%s\"}%s\n",rules[i].code,rules[i].name,rules[i].summary,rules[i].category,i==rule_count-1?"":","); } puts("]"); } else { puts("Available rules:"); for(int i=0;i<rule_count;i++) if(!fixonly||rules[i].fixable) printf("  %s - %s\n",rules[i].code,rules[i].summary); printf("\nTotal: %d rules\n",rule_count); }
}

static int run_check(int argc,char **argv,bool fmtmode){
 Opt o={0}; strcpy(o.output,"text"); strcpy(o.stdin_name,"<stdin>"); o.line_length=80; Paths paths={0}; if(fmtmode)o.fix=true;
 for(int i=2;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"--help")||!strcmp(a,"-h")){check_help();return 0;} else if(!strcmp(a,"--fix")||!strcmp(a,"-f"))o.fix=true; else if(!strcmp(a,"--diff"))o.diff=true; else if(!strcmp(a,"--quiet")||!strcmp(a,"-q"))o.quiet=true; else if(!strcmp(a,"--silent")||!strcmp(a,"-s"))o.silent=true; else if(!strcmp(a,"--stdin"))o.stdin_mode=true; else if(!strcmp(a,"--no-config")||!strcmp(a,"--isolated"))o.no_config=true; else if(!strcmp(a,"--list-rules")||!strcmp(a,"-l")){list_rules();return 0;} else if((!strcmp(a,"--disable")||!strcmp(a,"-d"))&&i+1<argc)parse_rule_list(&o,argv[++i],false,false); else if((!strcmp(a,"--enable")||!strcmp(a,"-e")||!strcmp(a,"--rules"))&&i+1<argc)parse_rule_list(&o,argv[++i],true,true); else if((!strcmp(a,"--output")||!strcmp(a,"-o")||!strcmp(a,"--output-format"))&&i+1<argc)snprintf(o.output,sizeof(o.output),"%s",argv[++i]); else if(!strcmp(a,"--config")&&i+1<argc)snprintf(o.config_path,sizeof(o.config_path),"%s",argv[++i]); else if(!strcmp(a,"--stdin-filename")&&i+1<argc)snprintf(o.stdin_name,sizeof(o.stdin_name),"%s",argv[++i]); else if(a[0]=='-'){ if(!strcmp(a,"-")){o.stdin_mode=true;} else if(i+1<argc && argv[i+1][0]!='-') i++; } else add_path(&paths,a); }
 load_config(&o);
 if(o.stdin_mode){ size_t n; char *txt=read_all(stdin,&n); Issues is={0}; char *fixed=NULL; lint_file(o.stdin_name,txt,&o,&is,o.fix||fmtmode,&fixed); if((o.fix||fmtmode)&&fixed){ fputs(fixed,stdout); free(fixed); } else if(!o.silent){ for(int k=0;k<is.n;k++) printf("%s:%d:%d: [%s] %s%s\n",is.v[k].file,is.v[k].line,is.v[k].col,is.v[k].code,is.v[k].msg,is.v[k].fixable?" [*]":""); if(is.n&&!o.quiet) printf("\nFound %d issue(s) in %s\n",is.n,o.stdin_name); } int rc=(is.n&&!(fmtmode))?1:0; free(txt); free(is.v); return rc; }
 if(paths.n==0) add_path(&paths,".");
 Paths files={0}; for(int i=0;i<paths.n;i++){ struct stat st; if(stat(paths.v[i].path,&st)){ fprintf(stderr,"Error: Failed to find markdown files: File not found: %s\n",paths.v[i].path); return 1; } collect(&files,paths.v[i].path); }
 if(files.n==0){ if(!o.silent) puts("\nSuccess: No issues found in 0 files (0ms)"); return 0; }
 Issues all={0}; int fixed_count=0; for(int i=0;i<files.n;i++){ FILE *f=fopen(files.v[i].path,"rb"); if(!f)continue; size_t n; char *txt=read_all(f,&n); fclose(f); int before=all.n; char *fixed=NULL; lint_file(files.v[i].path,txt,&o,&all,o.fix||fmtmode,&fixed); if((o.fix||fmtmode)&&fixed){ bool changed=strcmp(txt,fixed)!=0; if(changed){ FILE *w=fopen(files.v[i].path,"wb"); if(w){fwrite(fixed,1,strlen(fixed),w);fclose(w);} } for(int k=before;k<all.n;k++) if(all.v[k].fixed) fixed_count++; free(fixed);} free(txt); }
 if(!o.silent && strcmp(o.output,"json")==0){ puts("["); for(int k=0;k<all.n;k++) printf("  {\"file\":\"%s\",\"line\":%d,\"column\":%d,\"rule\":\"%s\",\"message\":\"%s\",\"severity\":\"%s\",\"fixable\":%s}%s\n",all.v[k].file,all.v[k].line,all.v[k].col,all.v[k].code,all.v[k].msg,all.v[k].error?"error":"warning",all.v[k].fixable?"true":"false",k==all.n-1?"":","); puts("]"); }
 else if(!o.silent){ for(int k=0;k<all.n;k++){ if(!strcmp(o.output,"github")) printf("::%s file=%s,line=%d,col=%d,title=%s::%s\n",all.v[k].error?"error":"warning",all.v[k].file,all.v[k].line,all.v[k].col,all.v[k].code,all.v[k].msg); else printf("%s:%d:%d: [%s] %s [%s]\n",all.v[k].file,all.v[k].line,all.v[k].col,all.v[k].code,all.v[k].msg,all.v[k].fixed?"fixed":(all.v[k].fixable?"*":"")); } if(!o.quiet){ if(all.n==0) printf("\nSuccess: No issues found in %d file%s (0ms)\n",files.n,files.n==1?"":"s"); else if(o.fix||fmtmode) printf("\nFixed: Fixed %d/%d issues in %d file%s (0ms)\n",fixed_count,all.n,files.n,files.n==1?"":"s"); else { printf("\nIssues: Found %d issue%s in %d file%s (0ms)\n",all.n,all.n==1?"":"s",files.n,files.n==1?"":"s"); int fx=0; for(int k=0;k<all.n;k++) if(all.v[k].fixable)fx++; if(fx) printf("Run `rumdl fmt` to automatically fix %d of the %d issues\n",fx,all.n); } } }
 int rc=(all.n && !fmtmode && !(o.fix && fixed_count==all.n))?1:0; free(all.v); return rc;
}

static void config_cmd(int argc,char **argv){ (void)argc;(void)argv; puts("[global]\nenable = []\ndisable = []\nexclude = []\ninclude = []\nrespect_gitignore = true\nflavor = Standard\n\n[MD013]\nline-length = 80\ncode-blocks = true\ntables = false\nheadings = true\n\n[MD009]\nbr-spaces = 2\n\n[MD010]\nspaces-per-tab = 4"); }
static void init_cmd(void){ if(access(".rumdl.toml",F_OK)==0){ fprintf(stderr,"Error: Configuration file already exists: .rumdl.toml\n"); exit(1);} FILE *f=fopen(".rumdl.toml","w"); if(f){ fputs("# rumdl configuration\n\n[global]\ndisable = []\n\n[MD013]\nline-length = 80\n",f); fclose(f);} puts("Created default configuration file: .rumdl.toml\n\nSetup complete! You can now:\n  • Run rumdl check . to lint your Markdown files\n  • Open your editor to see real-time linting"); }
int main(int argc,char **argv){
 if(argc<2){ print_help(); return 0; }
 if(!strcmp(argv[1],"--help")||!strcmp(argv[1],"-h")||!strcmp(argv[1],"help")){ print_help(); return 0; }
 if(!strcmp(argv[1],"--version")||!strcmp(argv[1],"-V")||!strcmp(argv[1],"version")){ puts("rumdl 0.1.13"); return 0; }
 if(!strcmp(argv[1],"check")) return run_check(argc,argv,false);
 if(!strcmp(argv[1],"fmt")) return run_check(argc,argv,true);
 if(!strcmp(argv[1],"rule")||!strcmp(argv[1],"explain")){ if(argc>2 && (!strcmp(argv[2],"--help")||!strcmp(argv[2],"-h"))){ puts("Show information about a rule or list all rules\n\nUsage: executable rule [OPTIONS] [RULE]"); return 0;} rule_cmd(argc,argv); return 0; }
 if(!strcmp(argv[1],"config")){ if(argc>2 && !strcmp(argv[2],"file")){ puts("No configuration file found"); return 1;} config_cmd(argc,argv); return 0; }
 if(!strcmp(argv[1],"init")){ init_cmd(); return 0; }
 if(!strcmp(argv[1],"clean")){ puts("Cache cleared"); return 0; }
 if(!strcmp(argv[1],"schema")){ puts("{}"); return 0; }
 if(!strcmp(argv[1],"completions")){ puts("# shell completions are not available in this reimplementation"); return 0; }
 if(!strcmp(argv[1],"server")){ fprintf(stderr,"Error: LSP server is not available in this build\n"); return 1; }
 if(!strcmp(argv[1],"import")||!strcmp(argv[1],"vscode")){ fprintf(stderr,"Error: command not available in this build\n"); return 1; }
 fprintf(stderr,"error: unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] <COMMAND>\n",argv[1]); return 2;
}
