#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char *raw, *ip, *date, *time, *method, *path, *status, *referer;
    long bytes;
    int y, mo, d, hh, mm, ss, status_i;
} Hit;

typedef struct {
    Hit *v;
    size_t len, cap;
} Hits;

typedef struct {
    char *key;
    long hits, bytes;
} Count;

typedef struct {
    Count *v;
    size_t len, cap;
} Counts;

typedef struct {
    char **v;
    size_t len, cap;
} Strs;

typedef struct {
    char *output, *key, *fields;
    int length;
    bool changes, all_paths, no_name_check, silent;
    char *date_filter, *time_filter, *ip_filter, *method_filter, *path_filter, *referer_filter, *status_filter;
    Strs files;
} Opts;

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { perror("strdup"); exit(1); }
    return r;
}

static void *xrealloc(void *p, size_t n) {
    void *r = realloc(p, n);
    if (!r) { perror("realloc"); exit(1); }
    return r;
}

static void strs_add(Strs *s, const char *v) {
    if (s->len == s->cap) {
        s->cap = s->cap ? s->cap * 2 : 16;
        s->v = xrealloc(s->v, s->cap * sizeof(char*));
    }
    s->v[s->len++] = xstrdup(v);
}

static void hits_add(Hits *h, Hit hit) {
    if (h->len == h->cap) {
        h->cap = h->cap ? h->cap * 2 : 1024;
        h->v = xrealloc(h->v, h->cap * sizeof(Hit));
    }
    h->v[h->len++] = hit;
}

static void counts_add(Counts *c, const char *key, long bytes) {
    if (!key || !*key || strcmp(key, "-") == 0) return;
    for (size_t i = 0; i < c->len; i++) {
        if (strcmp(c->v[i].key, key) == 0) {
            c->v[i].hits++;
            c->v[i].bytes += bytes;
            return;
        }
    }
    if (c->len == c->cap) {
        c->cap = c->cap ? c->cap * 2 : 32;
        c->v = xrealloc(c->v, c->cap * sizeof(Count));
    }
    c->v[c->len].key = xstrdup(key);
    c->v[c->len].hits = 1;
    c->v[c->len].bytes = bytes;
    c->len++;
}

static int month_num(const char *m) {
    static const char *months[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    for (int i=0;i<12;i++) if (strncmp(m, months[i], 3) == 0) return i+1;
    return 0;
}

static char *substr(const char *a, const char *b) {
    if (!a || !b || b < a) return xstrdup("");
    size_t n = (size_t)(b-a);
    char *r = malloc(n+1);
    if (!r) { perror("malloc"); exit(1); }
    memcpy(r, a, n); r[n] = 0;
    return r;
}

static bool parse_line(const char *line0, Hit *h) {
    memset(h, 0, sizeof(*h));
    char *line = xstrdup(line0);
    size_t ln = strlen(line);
    while (ln && (line[ln-1] == '\n' || line[ln-1] == '\r')) line[--ln] = 0;
    h->raw = xstrdup(line);

    const char *p = line;
    const char *sp = strchr(p, ' ');
    if (!sp) { free(line); return false; }
    h->ip = substr(p, sp);

    const char *lb = strchr(sp, '['), *rb = lb ? strchr(lb, ']') : NULL;
    if (!lb || !rb) { free(line); return false; }
    char mon[4] = {0};
    if (sscanf(lb+1, "%d/%3[A-Za-z]/%d:%d:%d:%d", &h->d, mon, &h->y, &h->hh, &h->mm, &h->ss) != 6) {
        free(line); return false;
    }
    h->mo = month_num(mon);
    char buf[64];
    snprintf(buf, sizeof buf, "%04d/%02d/%02d", h->y, h->mo, h->d); h->date = xstrdup(buf);
    snprintf(buf, sizeof buf, "%02d:%02d:%02d", h->hh, h->mm, h->ss); h->time = xstrdup(buf);

    const char *q1 = strchr(rb, '"'), *q2 = q1 ? strchr(q1+1, '"') : NULL;
    if (!q1 || !q2) { free(line); return false; }
    char *req = substr(q1+1, q2);
    char *r1 = req;
    char *r2 = strchr(r1, ' ');
    char *r3 = r2 ? strchr(r2+1, ' ') : NULL;
    if (r2) {
        *r2 = 0; h->method = xstrdup(*r1 ? r1 : "none");
        if (r3) { *r3 = 0; h->path = xstrdup(r2+1); }
        else h->path = xstrdup("-");
    } else {
        h->method = xstrdup("none"); h->path = xstrdup("-");
    }
    free(req);

    p = q2 + 1;
    while (*p == ' ') p++;
    char status[32] = {0}, bytes[64] = {0};
    if (sscanf(p, "%31s %63s", status, bytes) < 1) { free(line); return false; }
    h->status = xstrdup(status);
    h->status_i = atoi(status);
    h->bytes = strcmp(bytes, "-") == 0 ? 0 : atol(bytes);

    const char *ref1 = strchr(p, '"'), *ref2 = ref1 ? strchr(ref1+1, '"') : NULL;
    h->referer = (ref1 && ref2) ? substr(ref1+1, ref2) : xstrdup("-");
    free(line);
    return true;
}

static long dt_value(int y,int mo,int d,int hh,int mm,int ss) {
    return (((((long)y)*100 + mo)*100 + d)*100 + hh)*10000 + mm*100 + ss;
}

static long hit_dt(const Hit *h) { return dt_value(h->y,h->mo,h->d,h->hh,h->mm,h->ss); }
static int hit_tod(const Hit *h) { return h->hh*3600+h->mm*60+h->ss; }

static long parse_date_part(const char *s, const Hit *ctx, bool end) {
    int nums[6] = {0}, n = 0;
    const char *p = s;
    while (*p && n < 6) {
        if (isdigit((unsigned char)*p)) {
            nums[n++] = (int)strtol(p, (char**)&p, 10);
        } else p++;
    }
    int y=ctx?ctx->y:0, mo=end?12:1, d=end?31:1, hh=end?23:0, mm=end?59:0, ss=end?59:0;
    if (n == 1) { y = nums[0]; }
    else if (n == 2) {
        if (nums[0] > 31) { y=nums[0]; mo=nums[1]; d=end?31:1; }
        else { mo=nums[0]; d=nums[1]; }
    } else if (n >= 3) {
        y=nums[0]; mo=nums[1]; d=nums[2];
        if (n >= 4) hh=nums[3];
        if (n >= 5) mm=nums[4];
        if (n >= 6) ss=nums[5];
    }
    return dt_value(y,mo,d,hh,mm,ss);
}

static int parse_time_part(const char *s) {
    int a=0,b=0,c=0;
    sscanf(s, "%d:%d:%d", &a,&b,&c);
    return a*3600+b*60+c;
}

static bool match_date_filter(const char *f, const Hit *h) {
    if (!f) return true;
    bool neg = false;
    if (*f == '!') { neg = true; f++; }
    bool ok = true;
    long v = hit_dt(h);
    if (*f == '>' || *f == '<') {
        char op = *f++;
        long b = parse_date_part(f, h, op == '>');
        ok = op == '>' ? v > b : v < b;
    } else {
        const char *dash = strchr(f, '-');
        if (dash) {
            char *a = substr(f, dash), *b = xstrdup(dash+1);
            ok = v >= parse_date_part(a, h, false) && v <= parse_date_part(b, h, true);
            free(a); free(b);
        } else {
            ok = v >= parse_date_part(f, h, false) && v <= parse_date_part(f, h, true);
        }
    }
    return neg ? !ok : ok;
}

static bool match_time_filter(const char *f, const Hit *h) {
    if (!f) return true;
    bool neg = false;
    if (*f == '!') { neg = true; f++; }
    int v = hit_tod(h);
    bool ok;
    if (*f == '>' || *f == '<') {
        char op = *f++;
        int b = parse_time_part(f);
        ok = op == '>' ? v > b : v < b;
    } else {
        const char *dash = strchr(f, '-');
        if (dash) {
            char *a = substr(f, dash), *b = xstrdup(dash+1);
            ok = v >= parse_time_part(a) && v <= parse_time_part(b);
            free(a); free(b);
        } else ok = v == parse_time_part(f);
    }
    return neg ? !ok : ok;
}

static char *trim_dup(const char *s, size_t n) {
    while (n && isspace((unsigned char)*s)) { s++; n--; }
    while (n && isspace((unsigned char)s[n-1])) n--;
    char *r = malloc(n+1); if (!r) exit(1);
    memcpy(r,s,n); r[n]=0; return r;
}

static char *regex_translate(const char *s) {
    size_t n = strlen(s);
    char *r = malloc(n*5+1), *o = r;
    if (!r) exit(1);
    for (size_t i=0;i<n;i++) {
        if (s[i] == '\\' && s[i+1] == 'd') { memcpy(o, "[0-9]", 5); o += 5; i++; }
        else *o++ = s[i];
    }
    *o = 0;
    return r;
}

static bool regex_match_simple(const char *pat, const char *text) {
    char *rp = regex_translate(pat);
    regex_t re;
    int rc = regcomp(&re, rp, REG_EXTENDED | REG_NOSUB);
    free(rp);
    if (rc != 0) return strstr(text, pat) != NULL;
    bool ok = regexec(&re, text, 0, NULL, 0) == 0;
    regfree(&re);
    return ok;
}

static bool match_text_filter(const char *f, const char *text);

typedef struct { const char *s; const char *text; } Parser;

static void ps_ws(Parser *p) { while (isspace((unsigned char)*p->s)) p->s++; }
static bool parse_or(Parser *p);

static bool parse_atom(Parser *p) {
    ps_ws(p);
    bool neg = false;
    while (*p->s == '!') { neg = !neg; p->s++; ps_ws(p); }
    bool ok;
    if (*p->s == '(') {
        p->s++;
        ok = parse_or(p);
        ps_ws(p);
        if (*p->s == ')') p->s++;
    } else {
        const char *start = p->s;
        while (*p->s && *p->s != '&' && *p->s != '|' && *p->s != ',' && *p->s != ')') p->s++;
        char *pat = trim_dup(start, (size_t)(p->s-start));
        ok = *pat ? regex_match_simple(pat, p->text) : true;
        free(pat);
    }
    return neg ? !ok : ok;
}

static bool parse_and(Parser *p) {
    bool ok = parse_atom(p);
    for (;;) {
        ps_ws(p);
        if (*p->s != '&' && *p->s != ',') return ok;
        p->s++;
        ok = parse_atom(p) && ok;
    }
}

static bool parse_or(Parser *p) {
    bool ok = parse_and(p);
    for (;;) {
        ps_ws(p);
        if (*p->s != '|') return ok;
        p->s++;
        ok = parse_and(p) || ok;
    }
}

static bool match_text_filter(const char *f, const char *text) {
    if (!f) return true;
    Parser p = { f, text ? text : "" };
    return parse_or(&p);
}

static bool match_method_filter(const char *f, const Hit *h) {
    if (!f) return true;
    bool neg = false;
    if (*f == '!') { neg = true; f++; }
    bool ok;
    if (strcasecmp(f, "other") == 0)
        ok = strcasecmp(h->method,"GET") && strcasecmp(h->method,"POST") && strcasecmp(h->method,"HEAD") && strcasecmp(h->method,"PUT") && strcasecmp(h->method,"DELETE") && strcasecmp(h->method,"OPTIONS") && strcasecmp(h->method,"PATCH");
    else if (strcasecmp(f, "none") == 0)
        ok = strcmp(h->method, "none") == 0 || strcmp(h->method, "-") == 0;
    else
        ok = strcasecmp(h->method, f) == 0;
    return neg ? !ok : ok;
}

static bool status_token(const char *tok, int st) {
    bool neg = false;
    if (*tok == '!') { neg = true; tok++; }
    bool ok = false;
    if (strlen(tok) == 3 && isdigit(tok[0]) && tok[1] == 'x' && tok[2] == 'x')
        ok = st / 100 == tok[0]-'0';
    else {
        const char *dash = strchr(tok, '-');
        if (dash) {
            int a = atoi(tok), b = atoi(dash+1);
            ok = st >= a && st <= b;
        } else ok = st == atoi(tok);
    }
    return neg ? !ok : ok;
}

static bool match_status_filter(const char *f, const Hit *h) {
    if (!f) return true;
    char *tmp = xstrdup(f), *save = NULL, *tok;
    bool any_pos = false, pos_ok = false, neg_ok = true;
    for (tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        char *t = trim_dup(tok, strlen(tok));
        if (*t == '!') {
            if (!status_token(t, h->status_i)) neg_ok = false;
        } else {
            any_pos = true;
            if (status_token(t, h->status_i)) pos_ok = true;
        }
        free(t);
    }
    free(tmp);
    return (any_pos ? pos_ok : true) && neg_ok;
}

static bool is_resource_path(const char *p) {
    const char *q = strrchr(p, '.');
    if (!q) return false;
    const char *ext = q+1;
    const char *res[] = {"png","jpg","jpeg","gif","webp","svg","ico","css","js","map","woff","woff2","ttf","eot","mp4","webm","mp3","ogg","pdf",NULL};
    for (int i=0;res[i];i++) if (strcasecmp(ext,res[i])==0) return true;
    return false;
}

static bool accept_hit(const Hit *h, const Opts *o) {
    return match_date_filter(o->date_filter,h) &&
        match_time_filter(o->time_filter,h) &&
        match_text_filter(o->ip_filter,h->ip) &&
        match_method_filter(o->method_filter,h) &&
        match_text_filter(o->path_filter,h->path) &&
        match_text_filter(o->referer_filter,h->referer) &&
        match_status_filter(o->status_filter,h);
}

static void json_escape(FILE *f, const char *s) {
    fputc('"', f);
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') { fputc('\\', f); fputc(c, f); }
        else if (c == '\n') fputs("\\n", f);
        else if (c == '\r') fputs("\\r", f);
        else if (c == '\t') fputs("\\t", f);
        else if (c < 32) fprintf(f, "\\u%04x", c);
        else fputc(c, f);
    }
    fputc('"', f);
}

static void csv_cell(FILE *f, const char *s) {
    fputc('"', f);
    for (; *s; s++) { if (*s == '"') fputc('"', f); fputc(*s, f); }
    fputc('"', f);
}

static int cmp_hit_dt(const void *a, const void *b) {
    const Hit *x = a, *y = b;
    long dx = hit_dt(x), dy = hit_dt(y);
    if (dx < dy) return -1;
    if (dx > dy) return 1;
    return strcmp(x->raw, y->raw);
}

static void output_raw(const Hits *h) {
    for (size_t i=0;i<h->len;i++) puts(h->v[i].raw);
}

static void output_csv(const Hits *h) {
    puts("date,time,remote address,method,path,status,bytes sent,referer");
    for (size_t i=0;i<h->len;i++) {
        const Hit *x=&h->v[i];
        printf("%s,%s,%s,%s,", x->date,x->time,x->ip,x->method);
        csv_cell(stdout,x->path);
        printf(",%s,%ld,", x->status,x->bytes);
        csv_cell(stdout,x->referer);
        putchar('\n');
    }
}

static void output_json(const Hits *h) {
    puts("[");
    for (size_t i=0;i<h->len;i++) {
        const Hit *x=&h->v[i];
        printf("  {\n    \"date\": "); json_escape(stdout,x->date);
        printf(",\n    \"time\": "); json_escape(stdout,x->time);
        printf(",\n    \"remote_addr\": "); json_escape(stdout,x->ip);
        printf(",\n    \"method\": "); json_escape(stdout,x->method);
        printf(",\n    \"path\": "); json_escape(stdout,x->path);
        printf(",\n    \"status\": "); json_escape(stdout,x->status);
        printf(",\n    \"bytes_sent\": %ld,\n    \"referer\": ", x->bytes); json_escape(stdout,x->referer);
        printf("\n  }%s\n", i+1<h->len ? "," : "");
    }
    puts("]");
}

static int sort_key_bytes = 0;
static int cmp_count(const void *a, const void *b) {
    const Count *x=a,*y=b;
    long vx = sort_key_bytes ? x->bytes : x->hits;
    long vy = sort_key_bytes ? y->bytes : y->hits;
    if (vy > vx) return 1;
    if (vy < vx) return -1;
    return strcmp(x->key,y->key);
}

static void print_count_table(const char *title, const char *col, Counts *c, long total_hits, bool by_bytes, int limit) {
    sort_key_bytes = by_bytes;
    qsort(c->v, c->len, sizeof(Count), cmp_count);
    printf("%zu %s. \n", c->len, title);
    printf("#\t%s\thits\t%%\tbytes\n", col);
    size_t n = c->len < (size_t)limit ? c->len : (size_t)limit;
    for (size_t i=0;i<n;i++) {
        double pct = total_hits ? (100.0 * c->v[i].hits / total_hits) : 0;
        printf("%zu\t%s\t%ld\t%.1f%%\t%ld\n", i+1, c->v[i].key, c->v[i].hits, pct, c->v[i].bytes);
    }
}

static int field_id(const char *s, size_t n) {
    while (n && isspace((unsigned char)*s)) { s++; n--; }
    while (n && isspace((unsigned char)s[n-1])) n--;
    if (n == 0) return -1;
    if ((n == 1 && s[0] == 'd') || (n == 4 && !strncmp(s,"date",4))) return 0;
    if ((n == 1 && s[0] == 't') || (n == 4 && !strncmp(s,"time",4))) return 1;
    if ((n == 1 && s[0] == 'm') || (n == 6 && !strncmp(s,"method",6))) return 2;
    if ((n == 1 && s[0] == 's') || (n == 6 && !strncmp(s,"status",6))) return 3;
    if ((n == 1 && s[0] == 'i') || (n == 2 && !strncmp(s,"ip",2))) return 4;
    if ((n == 1 && s[0] == 'r') || (n == 3 && !strncmp(s,"ref",3)) || (n == 7 && !strncmp(s,"referer",7))) return 5;
    if ((n == 1 && s[0] == 'p') || (n == 4 && !strncmp(s,"path",4)) || (n == 5 && !strncmp(s,"paths",5))) return 6;
    if ((n == 1 && s[0] == 'a') || (n == 3 && !strncmp(s,"all",3))) return 7;
    return -1;
}

static void eval_fields(const char *fields, bool out[7]) {
    bool def[7] = {true,false,false,true,false,true,true};
    for (int i=0;i<7;i++) out[i] = def[i];
    if (!fields || !*fields) {
        return;
    }
    const char *p = fields;
    char op = 0;
    bool first = true;
    while (*p) {
        while (*p == ',' || isspace((unsigned char)*p)) p++;
        if (*p == '+' || *p == '-') op = *p++;
        const char *start = p;
        while (*p && *p != '+' && *p != '-' && *p != ',') p++;
        int id = field_id(start, (size_t)(p-start));
        if (id < 0) continue;
        if (first && op == 0) {
            for (int i=0;i<7;i++) out[i] = false;
        }
        if (id == 7) {
            for (int i=0;i<7;i++) out[i] = op == '-' ? false : true;
        } else {
            out[id] = op == '-' ? false : true;
        }
        first = false;
    }
}

static void output_tables(const Hits *h, const Opts *o) {
    long bytes=0;
    for (size_t i=0;i<h->len;i++) bytes += h->v[i].bytes;
    if (h->len) printf("%zu hits and %ld from %s to %s\n", h->len, bytes, h->v[0].date, h->v[h->len-1].date);
    else printf("0 hits\n");
    int limit = 3 + o->length * 4;
    bool by_bytes = o->key && (o->key[0]=='b' || !strcmp(o->key,"bytes"));
    bool fields[7];
    eval_fields(o->fields, fields);
    Counts dates={0}, hours={0}, methods={0}, statuses={0}, ips={0}, refs={0}, paths={0};
    char hb[16];
    for (size_t i=0;i<h->len;i++) {
        const Hit *x=&h->v[i];
        counts_add(&dates,x->date,x->bytes);
        snprintf(hb,sizeof hb,"%d",x->hh); counts_add(&hours,hb,x->bytes);
        counts_add(&methods,x->method,x->bytes);
        counts_add(&statuses,x->status,x->bytes);
        counts_add(&ips,x->ip,x->bytes);
        counts_add(&refs,x->referer,x->bytes);
        if (o->all_paths || !is_resource_path(x->path)) counts_add(&paths,x->path,x->bytes);
    }
    if (fields[0]) print_count_table("dates","date",&dates,h->len,by_bytes,limit);
    if (fields[1]) print_count_table("hours","hour",&hours,h->len,by_bytes,24);
    if (fields[2]) print_count_table("methods","method",&methods,h->len,by_bytes,limit);
    if (fields[3]) print_count_table("HTTP status codes","status",&statuses,h->len,by_bytes,limit);
    if (fields[4]) print_count_table("remote IP addresses","IP address",&ips,h->len,by_bytes,limit);
    if (fields[5]) print_count_table("referrers","referrer",&refs,h->len,by_bytes,limit);
    if (fields[6]) {
        if (!o->all_paths) printf("%zu paths (excluding resources like images, css, etc.). \n", paths.len);
        print_count_table(o->all_paths ? "paths" : "paths", "path", &paths,h->len,by_bytes,limit);
    }
}

static bool has_suffix(const char *s, const char *suf) {
    size_t a=strlen(s), b=strlen(suf);
    return a>=b && strcmp(s+a-b,suf)==0;
}

static bool name_ok(const char *path) {
    const char *b = strrchr(path, '/'); b = b ? b+1 : path;
    return strstr(b, "access") || strstr(b, "nginx") || strstr(b, ".log");
}

static void read_stream(FILE *fp, const Opts *o, Hits *hits) {
    char *line=NULL; size_t cap=0;
    while (getline(&line,&cap,fp) >= 0) {
        Hit h;
        if (parse_line(line,&h) && accept_hit(&h,o)) hits_add(hits,h);
    }
    free(line);
}

static void read_file(const char *path, const Opts *o, Hits *hits) {
    if (!o->no_name_check && !name_ok(path)) return;
    FILE *fp = NULL;
    int is_pipe = 0;
    if (has_suffix(path, ".gz")) {
        char *cmd = NULL;
        if (asprintf(&cmd, "gzip -cd -- '%s'", path) < 0) exit(1);
        fp = popen(cmd, "r"); free(cmd); is_pipe = 1;
    } else fp = fopen(path, "r");
    if (!fp) return;
    read_stream(fp,o,hits);
    if (is_pipe) pclose(fp); else fclose(fp);
}

static int cmp_strp(const void *a, const void *b) {
    const char * const *x=a, * const *y=b;
    return strcmp(*x,*y);
}

static void collect_path(const char *path, const Opts *o, Hits *hits) {
    struct stat st;
    if (stat(path,&st) != 0) return;
    if (S_ISDIR(st.st_mode)) {
        Strs entries={0};
        DIR *d = opendir(path);
        if (!d) return;
        struct dirent *e;
        while ((e = readdir(d))) {
            if (e->d_name[0] == '.') continue;
            char *p = NULL;
            if (asprintf(&p, "%s/%s", path, e->d_name) < 0) exit(1);
            strs_add(&entries,p); free(p);
        }
        closedir(d);
        qsort(entries.v, entries.len, sizeof(char*), cmp_strp);
        for (size_t i=0;i<entries.len;i++) collect_path(entries.v[i],o,hits);
    } else if (S_ISREG(st.st_mode)) read_file(path,o,hits);
}

static char *need_arg(int *i, int argc, char **argv) {
    if (*i + 1 >= argc) { fprintf(stderr, "missing argument for %s\n", argv[*i]); exit(2); }
    return argv[++*i];
}

static void help(void) {
    puts("rhit 2.0.4\n");
    puts("Rhit analyzes your nginx logs.\n");
    puts("Usage: rhit [options] [FILES]\n");
    puts("Options:");
    puts("    --help                 Print help information");
    puts("    --version              Print the version");
    puts("    --color <auto|yes|no>  Whether to have styles and colors");
    puts(" -k --key <hits|bytes>     Key used in sorting and histogram");
    puts(" -l --length <0..6>        Detail level");
    puts(" -f --fields <FIELDS>      Fields: date,time,method,status,ip,ref,path");
    puts(" -c --changes              Add change tables");
    puts(" -d --date <DATE>          Filter dates");
    puts(" -i --ip <IP>              IP address filter");
    puts(" -m --method <METHOD>      HTTP method filter");
    puts(" -p --path <PATH>          Path filter");
    puts(" -r --referer <REFERER>    Referer filter");
    puts(" -s --status <STATUS>      Status filter");
    puts(" -t --time <TIME>          Time of day filter");
    puts(" -a --all                  Show all paths, including resources");
    puts("    --no-name-check        Try to open all files");
    puts(" -o --output <tables|raw|csv|json>");
    puts("    --silent-load          Don't print anything during load");
}

static void parse_args(int argc, char **argv, Opts *o) {
    o->output=xstrdup("tables"); o->key=xstrdup("hits"); o->length=1;
    for (int i=1;i<argc;i++) {
        char *a=argv[i];
        if (!strcmp(a,"--help")) { help(); exit(0); }
        else if (!strcmp(a,"--version")) { puts("rhit 2.0.4"); exit(0); }
        else if (!strcmp(a,"--color")) { (void)need_arg(&i,argc,argv); }
        else if (!strcmp(a,"-k")||!strcmp(a,"--key")) o->key=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-l")||!strcmp(a,"--length")) o->length=atoi(need_arg(&i,argc,argv));
        else if (!strcmp(a,"-f")||!strcmp(a,"--fields")||!strcmp(a,"--field")) o->fields=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-c")||!strcmp(a,"--changes")) o->changes=true;
        else if (!strcmp(a,"-d")||!strcmp(a,"--date")) o->date_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-t")||!strcmp(a,"--time")) o->time_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-i")||!strcmp(a,"--ip")) o->ip_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-m")||!strcmp(a,"--method")) o->method_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-p")||!strcmp(a,"--path")) o->path_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-r")||!strcmp(a,"--referer")||!strcmp(a,"--referrer")) o->referer_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-s")||!strcmp(a,"--status")) o->status_filter=need_arg(&i,argc,argv);
        else if (!strcmp(a,"-a")||!strcmp(a,"--all")) o->all_paths=true;
        else if (!strcmp(a,"--no-name-check")) o->no_name_check=true;
        else if (!strcmp(a,"--silent-load")) o->silent=true;
        else if (!strcmp(a,"-o")||!strcmp(a,"--output")) o->output=need_arg(&i,argc,argv);
        else if (a[0]=='-' && a[1]) { fprintf(stderr, "unexpected argument: %s\n", a); exit(2); }
        else strs_add(&o->files,a);
    }
}

int main(int argc, char **argv) {
    Opts o={0};
    parse_args(argc,argv,&o);
    Hits hits={0};
    if (o.files.len == 0) {
        collect_path("/var/log/nginx", &o, &hits);
        collect_path("/var/log/apache2", &o, &hits);
    } else {
        for (size_t i=0;i<o.files.len;i++) collect_path(o.files.v[i], &o, &hits);
    }
    qsort(hits.v, hits.len, sizeof(Hit), cmp_hit_dt);
    char c = o.output && *o.output ? *o.output : 't';
    if (c == 'r') output_raw(&hits);
    else if (c == 'c') output_csv(&hits);
    else if (c == 'j') output_json(&hits);
    else output_tables(&hits,&o);
    return 0;
}
