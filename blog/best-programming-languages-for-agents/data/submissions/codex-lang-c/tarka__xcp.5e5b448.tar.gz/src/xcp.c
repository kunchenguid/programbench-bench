#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <getopt.h>
#include <glob.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/sendfile.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/xattr.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef enum {
    BACKUP_NONE,
    BACKUP_NUMBERED,
    BACKUP_AUTO
} backup_mode_t;

typedef struct {
    bool recursive;
    bool dereference;
    bool no_clobber;
    bool force;
    bool gitignore;
    bool glob_patterns;
    bool no_progress;
    bool preserve_perms;
    bool preserve_times;
    bool ownership;
    bool no_target_directory;
    bool fsync_each;
    int verbose;
    char *target_directory;
    backup_mode_t backup;
} options_t;

typedef struct {
    char **items;
    size_t len;
    size_t cap;
} strvec_t;

static options_t opt = {
    .preserve_perms = true,
    .preserve_times = true,
    .backup = BACKUP_NONE
};

static void vec_push(strvec_t *v, const char *s) {
    if (v->len == v->cap) {
        size_t nc = v->cap ? v->cap * 2 : 16;
        char **ni = realloc(v->items, nc * sizeof(char *));
        if (!ni) {
            perror("realloc");
            exit(1);
        }
        v->items = ni;
        v->cap = nc;
    }
    v->items[v->len++] = strdup(s);
    if (!v->items[v->len - 1]) {
        perror("strdup");
        exit(1);
    }
}

static void die_clap(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    exit(2);
}

static void info(const char *fmt, ...) {
    if (opt.verbose <= 0)
        return;
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    fprintf(stdout, "%02d:%02d:%02d [INFO] ", tmv.tm_hour, tmv.tm_min, tmv.tm_sec);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stdout, fmt, ap);
    va_end(ap);
    fputc('\n', stdout);
}

static int fail1(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "Error: ");
    vfprintf(stderr, fmt, ap);
    fprintf(stderr, "\n");
    va_end(ap);
    return 1;
}

static const char *base_name(const char *p) {
    const char *end = p + strlen(p);
    while (end > p + 1 && end[-1] == '/')
        end--;
    const char *s = end;
    while (s > p && s[-1] != '/')
        s--;
    static char buf[PATH_MAX];
    size_t n = (size_t)(end - s);
    if (n >= sizeof(buf))
        n = sizeof(buf) - 1;
    memcpy(buf, s, n);
    buf[n] = 0;
    return buf;
}

static char *join_path(const char *a, const char *b) {
    size_t la = strlen(a), lb = strlen(b);
    bool slash = la > 0 && a[la - 1] != '/';
    char *r = malloc(la + slash + lb + 1);
    if (!r) {
        perror("malloc");
        exit(1);
    }
    memcpy(r, a, la);
    if (slash)
        r[la++] = '/';
    memcpy(r + la, b, lb + 1);
    return r;
}

static bool path_exists_l(const char *p) {
    struct stat st;
    return lstat(p, &st) == 0;
}

static bool is_dir_path(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static int ensure_parent_mode(const char *dst, mode_t mode) {
    if (mkdir(dst, mode & 07777) == 0)
        return 0;
    if (errno == EEXIST) {
        struct stat st;
        if (stat(dst, &st) == 0 && S_ISDIR(st.st_mode))
            return 0;
    }
    return -1;
}

static int numbered_backup_index(const char *dst, bool *any) {
    *any = false;
    int max = 0;
    char *dir = strdup(dst);
    char *name = strdup(base_name(dst));
    if (!dir || !name)
        exit(1);
    char *slash = strrchr(dir, '/');
    const char *dname;
    if (slash) {
        if (slash == dir)
            slash[1] = 0;
        else
            *slash = 0;
        dname = dir;
    } else {
        strcpy(dir, ".");
        dname = dir;
    }
    DIR *d = opendir(dname);
    if (!d) {
        free(dir);
        free(name);
        return 1;
    }
    size_t nl = strlen(name);
    struct dirent *de;
    while ((de = readdir(d))) {
        const char *e = de->d_name;
        if (strncmp(e, name, nl) != 0 || strncmp(e + nl, ".~", 2) != 0)
            continue;
        char *end = NULL;
        long n = strtol(e + nl + 2, &end, 10);
        if (end && strcmp(end, "~") == 0 && n > 0) {
            *any = true;
            if (n > max)
                max = (int)n;
        }
    }
    closedir(d);
    free(dir);
    free(name);
    return max + 1;
}

static int maybe_backup(const char *dst) {
    if (opt.backup == BACKUP_NONE || !path_exists_l(dst))
        return 0;
    bool any = false;
    int idx = numbered_backup_index(dst, &any);
    if (opt.backup == BACKUP_AUTO && !any)
        return 0;
    char *backup = NULL;
    if (asprintf(&backup, "%s.~%d~", dst, idx) < 0)
        return -1;
    int rc = rename(dst, backup);
    if (rc != 0)
        fprintf(stderr, "Error: Failed to create backup %s: %s\n", backup, strerror(errno));
    free(backup);
    return rc;
}

static int prepare_destination(const char *dst) {
    if (path_exists_l(dst)) {
        if (opt.no_clobber) {
            if (opt.verbose > 0)
                fprintf(stderr, "[ERROR] Received error: Destination Exists: Destination file exists and --no-clobber is set., %s\n", dst);
            return fail1("Destination Exists: Destination file exists and --no-clobber is set., %s", dst);
        }
        if (maybe_backup(dst) != 0)
            return 1;
        if (path_exists_l(dst)) {
            struct stat st;
            if (lstat(dst, &st) == 0 && S_ISDIR(st.st_mode))
                return 0;
            if (unlink(dst) != 0)
                return fail1("Failed to remove destination: %s, %s", strerror(errno), dst);
        }
    }
    return 0;
}

static void preserve_attrs(const char *src, const char *dst, const struct stat *st, bool symlink) {
    if (opt.preserve_times) {
        struct timespec ts[2];
        ts[0] = st->st_atim;
        ts[1] = st->st_mtim;
        utimensat(AT_FDCWD, dst, ts, symlink ? AT_SYMLINK_NOFOLLOW : 0);
    }
    if (opt.preserve_perms && !symlink)
        chmod(dst, st->st_mode & 07777);
    if (opt.ownership && lchown(dst, st->st_uid, st->st_gid) != 0 && opt.verbose > 0)
        fprintf(stderr, "[WARN] Failed to copy ownership for %s: %s\n", dst, strerror(errno));
#ifdef __linux__
    if (!symlink) {
        ssize_t sz = listxattr(src, NULL, 0);
        if (sz > 0) {
            char *list = malloc((size_t)sz);
            if (list && listxattr(src, list, (size_t)sz) == sz) {
                for (ssize_t i = 0; i < sz;) {
                    const char *name = list + i;
                    ssize_t vsz = getxattr(src, name, NULL, 0);
                    if (vsz >= 0) {
                        void *val = malloc((size_t)vsz);
                        if (val && getxattr(src, name, val, (size_t)vsz) == vsz)
                            setxattr(dst, name, val, (size_t)vsz, 0);
                        free(val);
                    }
                    i += (ssize_t)strlen(name) + 1;
                }
            }
            free(list);
        }
    }
#endif
}

typedef struct {
    char **patterns;
    size_t len;
} ignores_t;

static int copy_path_with_ignores(const char *src, const char *dst, const ignores_t *ig, const char *relbase);

static int copy_file_data(int in, int out) {
    char buf[1024 * 1024];
    for (;;) {
        ssize_t r = read(in, buf, sizeof(buf));
        if (r == 0)
            return 0;
        if (r < 0) {
            if (errno == EINTR)
                continue;
            return -1;
        }
        char *p = buf;
        ssize_t left = r;
        while (left > 0) {
            ssize_t w = write(out, p, (size_t)left);
            if (w < 0) {
                if (errno == EINTR)
                    continue;
                return -1;
            }
            left -= w;
            p += w;
        }
    }
}

static int copy_regular(const char *src, const char *dst, const struct stat *st) {
    int rc = prepare_destination(dst);
    if (rc)
        return rc;
    int in = open(src, O_RDONLY);
    if (in < 0)
        return fail1("Failed to open source: %s, %s", strerror(errno), src);
    mode_t create_mode = opt.preserve_perms ? (st->st_mode & 07777) : 0666;
    int out = open(dst, O_WRONLY | O_CREAT | O_TRUNC, create_mode);
    if (out < 0) {
        close(in);
        return fail1("Failed to open destination: %s, %s", strerror(errno), dst);
    }
    if (copy_file_data(in, out) != 0) {
        int e = errno;
        close(in);
        close(out);
        return fail1("Copy failed: %s, %s", strerror(e), src);
    }
    if (opt.fsync_each)
        fsync(out);
    close(in);
    close(out);
    preserve_attrs(src, dst, st, false);
    return 0;
}

static int copy_symlink(const char *src, const char *dst, const struct stat *st) {
    char buf[PATH_MAX + 1];
    ssize_t n = readlink(src, buf, PATH_MAX);
    if (n < 0)
        return fail1("Failed to read symlink: %s, %s", strerror(errno), src);
    buf[n] = 0;
    int rc = prepare_destination(dst);
    if (rc)
        return rc;
    if (symlink(buf, dst) != 0)
        return fail1("Failed to create symlink: %s, %s", strerror(errno), dst);
    preserve_attrs(src, dst, st, true);
    return 0;
}

static ignores_t load_ignores(const char *root) {
    ignores_t ig = {0};
    if (!opt.gitignore)
        return ig;
    char *path = join_path(root, ".gitignore");
    FILE *f = fopen(path, "r");
    free(path);
    if (!f)
        return ig;
    char *line = NULL;
    size_t cap = 0;
    while (getline(&line, &cap, f) > 0) {
        line[strcspn(line, "\r\n")] = 0;
        char *p = line;
        while (*p == ' ' || *p == '\t')
            p++;
        if (*p == 0 || *p == '#')
            continue;
        ig.patterns = realloc(ig.patterns, (ig.len + 1) * sizeof(char *));
        ig.patterns[ig.len++] = strdup(p);
    }
    free(line);
    fclose(f);
    return ig;
}

static bool ignored_name(const ignores_t *ig, const char *name, const char *rel) {
    for (size_t i = 0; i < ig->len; i++) {
        const char *p = ig->patterns[i];
        size_t l = strlen(p);
        if (l && p[l - 1] == '/') {
            char tmp[PATH_MAX];
            snprintf(tmp, sizeof(tmp), "%.*s", (int)(l - 1), p);
            if (strcmp(tmp, name) == 0 || strcmp(tmp, rel) == 0)
                return true;
        } else if (fnmatch(p, name, 0) == 0 || fnmatch(p, rel, FNM_PATHNAME) == 0) {
            return true;
        }
    }
    return false;
}

static int copy_dir_recursive(const char *src, const char *dst, const struct stat *st, const ignores_t *ig, const char *relbase) {
    int existed = path_exists_l(dst);
    int rc = prepare_destination(dst);
    if (rc)
        return rc;
    mode_t dmode = opt.preserve_perms ? st->st_mode : 0777;
    if (!existed && ensure_parent_mode(dst, dmode) != 0)
        return fail1("Failed to create directory: %s, %s", strerror(errno), dst);
    DIR *d = opendir(src);
    if (!d)
        return fail1("Failed to read directory: %s, %s", strerror(errno), src);
    int status = 0;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0)
            continue;
        char *s2 = join_path(src, de->d_name);
        char *d2 = join_path(dst, de->d_name);
        char *rel = relbase && *relbase ? join_path(relbase, de->d_name) : strdup(de->d_name);
        if (ig && ignored_name(ig, de->d_name, rel)) {
            free(s2);
            free(d2);
            free(rel);
            continue;
        }
        if (copy_path_with_ignores(s2, d2, ig, rel) != 0)
            status = 1;
        free(s2);
        free(d2);
        free(rel);
    }
    closedir(d);
    preserve_attrs(src, dst, st, false);
    return status;
}

static int copy_path_with_ignores(const char *src, const char *dst, const ignores_t *ig, const char *relbase) {
    struct stat st;
    int sr = opt.dereference ? stat(src, &st) : lstat(src, &st);
    if (sr != 0)
        return fail1("Invalid source: Source path does not exist., %s", src);
    info("Copying source \"%s\" to \"%s\"", src, dst);
    if (S_ISDIR(st.st_mode)) {
        if (!opt.recursive)
            return fail1("Invalid source: Source is directory and --recursive not specified.");
        return copy_dir_recursive(src, dst, &st, ig, relbase);
    }
    if (S_ISLNK(st.st_mode) && !opt.dereference)
        return copy_symlink(src, dst, &st);
    if (S_ISREG(st.st_mode))
        return copy_regular(src, dst, &st);
    if (S_ISFIFO(st.st_mode) || S_ISCHR(st.st_mode) || S_ISBLK(st.st_mode) || S_ISSOCK(st.st_mode)) {
        int rc = prepare_destination(dst);
        if (rc)
            return rc;
        if (mknod(dst, st.st_mode, st.st_rdev) != 0)
            return fail1("Failed to create special file: %s, %s", strerror(errno), dst);
        preserve_attrs(src, dst, &st, false);
        return 0;
    }
    return fail1("Invalid source: Unsupported file type., %s", src);
}

static void print_help(bool long_help) {
    printf("A (partial) clone of the Unix `cp` command with progress and pluggable drivers.\n\n");
    printf("Usage: executable [OPTIONS] [PATHS]...\n\n");
    if (long_help) {
        printf("Arguments:\n  [PATHS]...\n          Path list.\n          \n          Source and destination files, or multiple source(s) to a directory.\n\n");
        printf("Options:\n  -v, --verbose...\n          Verbosity.\n          \n          Can be specified multiple times to increase logging.\n\n");
    } else {
        printf("Arguments:\n  [PATHS]...  Path list\n\nOptions:\n  -v, --verbose...\n          Verbosity\n");
    }
    printf("  -r, --recursive\n          Copy directories recursively\n");
    printf("  -L, --dereference\n          Dereference symlinks in source\n");
    printf("  -w, --workers <WORKERS>\n          Number of parallel workers [default: 4]\n");
    printf("      --block-size <BLOCK_SIZE>\n          Block size for operations [default: 1MB]\n");
    printf("  -n, --no-clobber\n          Do not overwrite an existing file\n");
    printf("  -f, --force\n          Force (compatability only)\n");
    printf("      --gitignore\n          Use .gitignore if present\n");
    printf("  -g, --glob\n          Expand file patterns\n");
    printf("      --no-progress\n          Disable progress bar\n");
    printf("      --no-perms\n          Do not copy the file permissions\n");
    printf("      --no-timestamps\n          Do not copy the file timestamps\n");
    printf("  -o, --ownership\n          Copy ownership\n");
    printf("      --driver <DRIVER>\n          Driver to use, defaults to 'file-parallel' [default: parfile]\n");
    printf("  -T, --no-target-directory\n          Target should not be a directory\n");
    printf("      --target-directory <TARGET_DIRECTORY>\n          Copy into a subdirectory of the target\n");
    printf("      --fsync\n          Sync each file to disk after writing\n");
    printf("      --reflink <REFLINK>\n          Reflink options [default: auto]\n");
    printf("      --backup <BACKUP>\n          Backup options [default: none]\n");
    printf("  -h, --help\n          Print help (see %s with '%s')\n", long_help ? "a summary" : "more", long_help ? "-h" : "--help");
    printf("  -V, --version\n          Print version\n");
}

static void expand_globs(strvec_t *in, strvec_t *out) {
    for (size_t i = 0; i < in->len; i++) {
        glob_t g;
        memset(&g, 0, sizeof(g));
        int r = glob(in->items[i], GLOB_TILDE, NULL, &g);
        if (r == 0 && g.gl_pathc > 0) {
            for (size_t j = 0; j < g.gl_pathc; j++)
                vec_push(out, g.gl_pathv[j]);
        } else {
            vec_push(out, in->items[i]);
        }
        globfree(&g);
    }
}

int main(int argc, char **argv) {
    enum {
        OPT_BLOCK = 1000,
        OPT_GITIGNORE,
        OPT_NO_PROGRESS,
        OPT_NO_PERMS,
        OPT_NO_TIMES,
        OPT_DRIVER,
        OPT_TARGET_DIR,
        OPT_FSYNC,
        OPT_REFLINK,
        OPT_BACKUP
    };
    static struct option longopts[] = {
        {"verbose", no_argument, 0, 'v'},
        {"recursive", no_argument, 0, 'r'},
        {"dereference", no_argument, 0, 'L'},
        {"workers", required_argument, 0, 'w'},
        {"block-size", required_argument, 0, OPT_BLOCK},
        {"no-clobber", no_argument, 0, 'n'},
        {"force", no_argument, 0, 'f'},
        {"gitignore", no_argument, 0, OPT_GITIGNORE},
        {"glob", no_argument, 0, 'g'},
        {"no-progress", no_argument, 0, OPT_NO_PROGRESS},
        {"no-perms", no_argument, 0, OPT_NO_PERMS},
        {"no-timestamps", no_argument, 0, OPT_NO_TIMES},
        {"ownership", no_argument, 0, 'o'},
        {"driver", required_argument, 0, OPT_DRIVER},
        {"no-target-directory", no_argument, 0, 'T'},
        {"target-directory", required_argument, 0, OPT_TARGET_DIR},
        {"fsync", no_argument, 0, OPT_FSYNC},
        {"reflink", required_argument, 0, OPT_REFLINK},
        {"backup", required_argument, 0, OPT_BACKUP},
        {"help", no_argument, 0, 'h'},
        {"version", no_argument, 0, 'V'},
        {0, 0, 0, 0}
    };
    opterr = 0;
    int c;
    while ((c = getopt_long(argc, argv, "vrLw:nfgoThV", longopts, NULL)) != -1) {
        switch (c) {
        case 'v': opt.verbose++; break;
        case 'r': opt.recursive = true; break;
        case 'L': opt.dereference = true; break;
        case 'w': (void)optarg; break;
        case 'n': opt.no_clobber = true; break;
        case 'f': opt.force = true; break;
        case 'g': opt.glob_patterns = true; break;
        case 'o': opt.ownership = true; break;
        case 'T': opt.no_target_directory = true; break;
        case 'h': print_help(strcmp(argv[optind - 1], "--help") == 0); return 0;
        case 'V': printf("xcp 0.24.3\n"); return 0;
        case OPT_BLOCK: break;
        case OPT_GITIGNORE: opt.gitignore = true; break;
        case OPT_NO_PROGRESS: opt.no_progress = true; break;
        case OPT_NO_PERMS: opt.preserve_perms = false; break;
        case OPT_NO_TIMES: opt.preserve_times = false; break;
        case OPT_DRIVER:
            if (strcmp(optarg, "parfile") && strcmp(optarg, "parblock"))
                die_clap("error: invalid value '%s' for '--driver <DRIVER>': Unknown driver: %s\n\nFor more information, try '--help'.\n", optarg, optarg);
            break;
        case OPT_TARGET_DIR: opt.target_directory = strdup(optarg); break;
        case OPT_FSYNC: opt.fsync_each = true; break;
        case OPT_REFLINK:
            if (strcmp(optarg, "auto") && strcmp(optarg, "always") && strcmp(optarg, "never"))
                die_clap("error: invalid value '%s' for '--reflink <REFLINK>'\n\nFor more information, try '--help'.\n", optarg);
            break;
        case OPT_BACKUP:
            if (strcmp(optarg, "none") == 0 || strcmp(optarg, "off") == 0)
                opt.backup = BACKUP_NONE;
            else if (strcmp(optarg, "numbered") == 0)
                opt.backup = BACKUP_NUMBERED;
            else if (strcmp(optarg, "auto") == 0)
                opt.backup = BACKUP_AUTO;
            else
                die_clap("error: invalid value '%s' for '--backup <BACKUP>'\n\nFor more information, try '--help'.\n", optarg);
            break;
        case '?':
        default:
            if (optopt)
                die_clap("error: unexpected argument '-%c' found\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n", optopt);
            else
                die_clap("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n", argv[optind - 1]);
        }
    }

    if (opt.force && opt.no_clobber)
        return fail1("Invalid arguments: --force and --noclobber cannot be set at the same time.");

    strvec_t raw = {0}, paths = {0};
    for (int i = optind; i < argc; i++)
        vec_push(&raw, argv[i]);
    if (opt.glob_patterns)
        expand_globs(&raw, &paths);
    else
        paths = raw;

    if (opt.target_directory) {
        if (paths.len == 0)
            return fail1("Invalid arguments: Insufficient arguments");
        if (!is_dir_path(opt.target_directory))
            return fail1("Invalid destination: Target directory does not exist., %s", opt.target_directory);
        int status = 0;
        for (size_t i = 0; i < paths.len; i++) {
            char *dst = join_path(opt.target_directory, base_name(paths.items[i]));
            ignores_t ig = load_ignores(paths.items[i]);
            if (copy_path_with_ignores(paths.items[i], dst, &ig, "") != 0)
                status = 1;
            free(dst);
        }
        if (opt.verbose > 0 && status == 0)
            info("Copy complete");
        return status;
    }

    if (paths.len < 2)
        return fail1("Invalid arguments: Insufficient arguments");

    const char *dest_arg = paths.items[paths.len - 1];
    bool dest_is_dir = is_dir_path(dest_arg);
    if (paths.len > 2 && !dest_is_dir)
        return fail1("Invalid destination: Multiple sources and destination is not a directory.");

    int status = 0;
    if (paths.len == 2) {
        const char *src = paths.items[0];
        char *dst = NULL;
        if (dest_is_dir && !opt.no_target_directory)
            dst = join_path(dest_arg, base_name(src));
        else
            dst = strdup(dest_arg);
        ignores_t ig = load_ignores(src);
        status = copy_path_with_ignores(src, dst, &ig, "");
        free(dst);
    } else {
        for (size_t i = 0; i + 1 < paths.len; i++) {
            char *dst = join_path(dest_arg, base_name(paths.items[i]));
            ignores_t ig = load_ignores(paths.items[i]);
            if (copy_path_with_ignores(paths.items[i], dst, &ig, "") != 0)
                status = 1;
            free(dst);
        }
    }
    if (opt.verbose > 0 && status == 0)
        info("Copy complete");
    return status;
}
