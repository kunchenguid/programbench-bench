#define _GNU_SOURCE
#include <errno.h>
#include <getopt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>

typedef enum { MODE_COMPRESS, MODE_DECOMPRESS, MODE_TEST, MODE_LIST, MODE_BENCH, MODE_TRAIN } Mode;
typedef enum { FMT_ZSTD, FMT_GZIP } Format;

typedef struct {
    Mode mode;
    Format format;
    int level;
    int force;
    int keep;
    int rm;
    int stdout_flag;
    int quiet;
    int recursive;
    char *output;
    char *filelist;
    char *outdir_flat;
    char *outdir_mirror;
    char *dict;
    char **inputs;
    int input_count;
} Options;

static const char *prog = "zstd";

static void short_help(FILE *out) {
    fprintf(out, "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***\n");
    fprintf(out, "Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.\n\n");
    fprintf(out, "Usage: %s [OPTIONS...] [INPUT... | -] [-o OUTPUT]\n\n", prog);
    fprintf(out, "Options:\n");
    fprintf(out, "  -o OUTPUT                     Write output to a single file, OUTPUT.\n");
    fprintf(out, "  -k, --keep                    Preserve INPUT file(s). [Default] \n");
    fprintf(out, "  --rm                          Remove INPUT file(s) after successful (de)compression to file.\n\n");
    fprintf(out, "  -#                            Desired compression level, where `#` is a number between 1 and 19;\n");
    fprintf(out, "                                lower numbers provide faster compression, higher numbers yield\n");
    fprintf(out, "                                better compression ratios. [Default: 3]\n\n");
    fprintf(out, "  -d, --decompress              Perform decompression.\n");
    fprintf(out, "  -D DICT                       Use DICT as the dictionary for compression or decompression.\n\n");
    fprintf(out, "  -f, --force                   Disable input and output checks. Allows overwriting existing files,\n");
    fprintf(out, "                                receiving input from the console, printing output to STDOUT, and\n");
    fprintf(out, "                                operating on links, block devices, etc. Unrecognized formats will be\n");
    fprintf(out, "                                passed-through through as-is.\n\n");
    fprintf(out, "  -h                            Display short usage and exit.\n");
    fprintf(out, "  -H, --help                    Display full help and exit.\n");
    fprintf(out, "  -V, --version                 Display the program version and exit.\n");
}

static void full_help(FILE *out) {
    short_help(out);
    fprintf(out, "\nAdvanced options:\n");
    fprintf(out, "  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).\n\n");
    fprintf(out, "  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.\n");
    fprintf(out, "  -q, --quiet                   Suppress warnings; pass twice to suppress errors.\n");
    fprintf(out, "  --trace LOG                   Log tracing information to LOG.\n\n");
    fprintf(out, "  --[no-]progress               Forcibly show/hide the progress counter. NOTE: Any (de)compressed\n");
    fprintf(out, "                                output to terminal will mix with progress counter text.\n\n");
    fprintf(out, "  -r                            Operate recursively on directories.\n");
    fprintf(out, "  --filelist LIST               Read a list of files to operate on from LIST.\n");
    fprintf(out, "  --output-dir-flat DIR         Store processed files in DIR.\n");
    fprintf(out, "  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.\n");
    fprintf(out, "  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]\n\n");
    fprintf(out, "  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]\n");
    fprintf(out, "                                If `-d` is present, ignore/validate checksums during decompression.\n\n");
    fprintf(out, "  --                            Treat remaining arguments after `--` as files.\n\n");
    fprintf(out, "Advanced compression options:\n");
    fprintf(out, "  --ultra                       Enable levels beyond 19, up to 22; requires more memory.\n");
    fprintf(out, "  --fast[=#]                    Use to very fast compression levels. [Default: 1]\n");
    fprintf(out, "  --adapt                       Dynamically adapt compression level to I/O conditions.\n");
    fprintf(out, "  --long[=#]                    Enable long distance matching with window log #. [Default: 27]\n");
    fprintf(out, "  --patch-from=REF              Use REF as the reference point for Zstandard's diff engine. \n");
    fprintf(out, "  --patch-apply                 Equivalent for `-d --patch-from` \n\n");
    fprintf(out, "  -T#                           Spawn # compression threads. [Default: 3; pass 0 for core count.]\n");
    fprintf(out, "  --single-thread               Share a single thread for I/O and compression (slightly different than `-T1`).\n");
    fprintf(out, "  --format=zstd                 Compress files to the `.zst` format. [Default]\n");
    fprintf(out, "  --format=gzip                 Compress files to the `.gz` format.\n\n");
    fprintf(out, "Advanced decompression options:\n");
    fprintf(out, "  -l                            Print information about Zstandard-compressed files.\n");
    fprintf(out, "  --test                        Test compressed file integrity.\n\n");
    fprintf(out, "Dictionary builder:\n");
    fprintf(out, "  --train                       Create a dictionary from a training set of files.\n\n");
    fprintf(out, "Benchmark options:\n");
    fprintf(out, "  -b#                           Perform benchmarking with compression level #. [Default: 3]\n");
}

static int read_all_stream(FILE *f, unsigned char **buf, size_t *len) {
    size_t cap = 8192, n = 0;
    unsigned char *p = malloc(cap);
    if (!p) return -1;
    for (;;) {
        if (n == cap) {
            cap *= 2;
            unsigned char *q = realloc(p, cap);
            if (!q) { free(p); return -1; }
            p = q;
        }
        size_t got = fread(p + n, 1, cap - n, f);
        n += got;
        if (got == 0) {
            if (ferror(f)) { free(p); return -1; }
            break;
        }
    }
    *buf = p;
    *len = n;
    return 0;
}

static int read_file(const char *path, unsigned char **buf, size_t *len) {
    FILE *f;
    if (strcmp(path, "-") == 0) f = stdin;
    else f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "zstd: %s: %s\n", path, strerror(errno));
        return -1;
    }
    int rc = read_all_stream(f, buf, len);
    if (strcmp(path, "-") != 0) fclose(f);
    if (rc) fprintf(stderr, "zstd: %s: error reading file\n", path);
    return rc;
}

static int write_file_or_stdout(const char *path, const unsigned char *buf, size_t len, int force) {
    FILE *f;
    if (!path || strcmp(path, "-") == 0) {
        f = stdout;
    } else {
        if (!force && access(path, F_OK) == 0) {
            fprintf(stderr, "zstd: %s already exists; not overwritten\n", path);
            return -1;
        }
        f = fopen(path, "wb");
        if (!f) {
            fprintf(stderr, "zstd: %s: %s\n", path, strerror(errno));
            return -1;
        }
    }
    if (len && fwrite(buf, 1, len, f) != len) {
        fprintf(stderr, "zstd: write error: %s\n", strerror(errno));
        if (f != stdout) fclose(f);
        return -1;
    }
    if (f != stdout && fclose(f) != 0) {
        fprintf(stderr, "zstd: close error: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

static char *xasprintf2(const char *a, const char *b) {
    size_t la = strlen(a), lb = strlen(b);
    char *s = malloc(la + lb + 1);
    if (!s) return NULL;
    memcpy(s, a, la);
    memcpy(s + la, b, lb + 1);
    return s;
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static char *strip_suffix(const char *path, const char *suf) {
    size_t lp = strlen(path), ls = strlen(suf);
    if (lp > ls && strcmp(path + lp - ls, suf) == 0) {
        char *out = malloc(lp - ls + 1);
        if (!out) return NULL;
        memcpy(out, path, lp - ls);
        out[lp - ls] = 0;
        return out;
    }
    return xasprintf2(path, ".out");
}

static char *join_dir(const char *dir, const char *name) {
    size_t ld = strlen(dir), ln = strlen(name);
    int slash = ld && dir[ld - 1] != '/';
    char *s = malloc(ld + slash + ln + 1);
    if (!s) return NULL;
    memcpy(s, dir, ld);
    if (slash) s[ld++] = '/';
    memcpy(s + ld, name, ln + 1);
    return s;
}

static void put_le16(unsigned char *p, unsigned v) {
    p[0] = (unsigned char)v;
    p[1] = (unsigned char)(v >> 8);
}

static void put_le32(unsigned char *p, uint32_t v) {
    p[0] = (unsigned char)v;
    p[1] = (unsigned char)(v >> 8);
    p[2] = (unsigned char)(v >> 16);
    p[3] = (unsigned char)(v >> 24);
}

static void put_le64(unsigned char *p, uint64_t v) {
    for (int i = 0; i < 8; ++i) p[i] = (unsigned char)(v >> (8 * i));
}

static uint32_t get_le24(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16);
}

static uint64_t get_le(const unsigned char *p, int n) {
    uint64_t v = 0;
    for (int i = 0; i < n; ++i) v |= (uint64_t)p[i] << (8 * i);
    return v;
}

static int zstd_compress_buf(const unsigned char *in, size_t inlen, int level, unsigned char **out, size_t *outlen) {
    (void)level;
    const size_t block_max = 128 * 1024;
    size_t blocks = inlen ? (inlen + block_max - 1) / block_max : 1;
    size_t fcs_len;
    unsigned char desc;
    if (inlen <= 255) {
        desc = 0x20;
        fcs_len = 1;
    } else if (inlen <= 65791) {
        desc = 0x60;
        fcs_len = 2;
    } else if (inlen <= 0xffffffffULL) {
        desc = 0xa0;
        fcs_len = 4;
    } else {
        desc = 0xe0;
        fcs_len = 8;
    }
    size_t cap = 4 + 1 + fcs_len + blocks * 3 + inlen;
    unsigned char *buf = malloc(cap ? cap : 1);
    if (!buf) return -1;
    size_t pos = 0;
    buf[pos++] = 0x28; buf[pos++] = 0xb5; buf[pos++] = 0x2f; buf[pos++] = 0xfd;
    buf[pos++] = desc;
    if (fcs_len == 1) buf[pos++] = (unsigned char)inlen;
    else if (fcs_len == 2) { put_le16(buf + pos, (unsigned)(inlen - 256)); pos += 2; }
    else if (fcs_len == 4) { put_le32(buf + pos, (uint32_t)inlen); pos += 4; }
    else { put_le64(buf + pos, (uint64_t)inlen); pos += 8; }
    size_t off = 0;
    if (inlen == 0) {
        buf[pos++] = 1; buf[pos++] = 0; buf[pos++] = 0;
    } else {
        while (off < inlen) {
            size_t chunk = inlen - off;
            if (chunk > block_max) chunk = block_max;
            int last = (off + chunk == inlen);
            uint32_t bh = (uint32_t)(chunk << 3) | (uint32_t)last;
            buf[pos++] = (unsigned char)bh;
            buf[pos++] = (unsigned char)(bh >> 8);
            buf[pos++] = (unsigned char)(bh >> 16);
            memcpy(buf + pos, in + off, chunk);
            pos += chunk;
            off += chunk;
        }
    }
    *out = buf;
    *outlen = pos;
    return 0;
}

static int is_zstd(const unsigned char *p, size_t n);

static uint64_t zstd_frame_content_size(const unsigned char *in, size_t inlen, int *known) {
    *known = 0;
    if (inlen < 6 || !is_zstd(in, inlen)) return 0;
    size_t pos = 4;
    unsigned char desc = in[pos++];
    unsigned fcs_code = desc >> 6;
    int single = (desc & 0x20) != 0;
    unsigned dict_code = desc & 0x03;
    if (!single) {
        if (pos >= inlen) return 0;
        pos++;
    }
    if (dict_code == 1) pos += 1;
    else if (dict_code == 2) pos += 2;
    else if (dict_code == 3) pos += 4;
    int fcs_len = 0;
    if (fcs_code == 0) fcs_len = single ? 1 : 0;
    else if (fcs_code == 1) fcs_len = 2;
    else if (fcs_code == 2) fcs_len = 4;
    else fcs_len = 8;
    if (!fcs_len || pos + (size_t)fcs_len > inlen) return 0;
    uint64_t v = get_le(in + pos, fcs_len);
    if (fcs_code == 1) v += 256;
    *known = 1;
    return v;
}

static int zstd_decompress_stream_buf(const unsigned char *in, size_t inlen, unsigned char **out, size_t *outlen) {
    if (inlen < 6 || !is_zstd(in, inlen)) {
        fprintf(stderr, "zstd: unsupported format \n");
        return -1;
    }
    size_t pos = 4;
    unsigned char desc = in[pos++];
    unsigned fcs_code = desc >> 6;
    int single = (desc & 0x20) != 0;
    int checksum = (desc & 0x04) != 0;
    unsigned dict_code = desc & 0x03;
    if (!single) {
        if (pos >= inlen) return -1;
        pos++;
    }
    if (dict_code == 1) pos += 1;
    else if (dict_code == 2) pos += 2;
    else if (dict_code == 3) pos += 4;
    uint64_t expected = UINT64_MAX;
    int fcs_len = 0;
    if (fcs_code == 0) fcs_len = single ? 1 : 0;
    else if (fcs_code == 1) fcs_len = 2;
    else if (fcs_code == 2) fcs_len = 4;
    else fcs_len = 8;
    if (pos + (size_t)fcs_len > inlen) return -1;
    if (fcs_len) {
        expected = get_le(in + pos, fcs_len);
        if (fcs_code == 1) expected += 256;
        pos += fcs_len;
    }
    size_t cap = expected != UINT64_MAX && expected < (1ULL << 40) ? (size_t)expected : 8192;
    if (cap == 0) cap = 1;
    size_t n = 0;
    unsigned char *buf = malloc(cap);
    if (!buf) return -1;
    for (;;) {
        if (pos + 3 > inlen) {
            fprintf(stderr, "zstd: unexpected end of file\n");
            free(buf);
            return -1;
        }
        uint32_t bh = get_le24(in + pos);
        pos += 3;
        int last = bh & 1;
        int type = (bh >> 1) & 3;
        size_t bsize = bh >> 3;
        if (type == 0) {
            if (pos + bsize > inlen) {
                fprintf(stderr, "zstd: unexpected end of file\n");
                free(buf);
                return -1;
            }
            if (n + bsize > cap) {
                while (n + bsize > cap) cap *= 2;
                unsigned char *q = realloc(buf, cap);
                if (!q) { free(buf); return -1; }
                buf = q;
            }
            memcpy(buf + n, in + pos, bsize);
            n += bsize;
            pos += bsize;
        } else if (type == 1) {
            if (pos >= inlen) {
                fprintf(stderr, "zstd: unexpected end of file\n");
                free(buf);
                return -1;
            }
            if (n + bsize > cap) {
                while (n + bsize > cap) cap *= 2;
                unsigned char *q = realloc(buf, cap);
                if (!q) { free(buf); return -1; }
                buf = q;
            }
            memset(buf + n, in[pos++], bsize);
            n += bsize;
        } else if (type == 2) {
            fprintf(stderr, "zstd: compressed blocks are not supported by this reimplementation\n");
            free(buf);
            return -1;
        } else {
            fprintf(stderr, "zstd: invalid block type\n");
            free(buf);
            return -1;
        }
        if (last) break;
    }
    if (checksum && pos + 4 <= inlen) pos += 4;
    (void)pos;
    *out = buf;
    *outlen = n;
    return 0;
}

static int gzip_compress_buf(const unsigned char *in, size_t inlen, int level, unsigned char **out, size_t *outlen) {
    z_stream zs;
    memset(&zs, 0, sizeof(zs));
    int zl = level;
    if (zl < 1 || zl > 9) zl = Z_DEFAULT_COMPRESSION;
    if (deflateInit2(&zs, zl, Z_DEFLATED, 15 + 16, 8, Z_DEFAULT_STRATEGY) != Z_OK) return -1;
    size_t cap = compressBound(inlen) + 32;
    unsigned char *buf = malloc(cap ? cap : 1);
    if (!buf) { deflateEnd(&zs); return -1; }
    zs.next_in = (Bytef *)in;
    zs.avail_in = (uInt)inlen;
    zs.next_out = buf;
    zs.avail_out = (uInt)cap;
    int r = deflate(&zs, Z_FINISH);
    if (r != Z_STREAM_END) {
        free(buf);
        deflateEnd(&zs);
        return -1;
    }
    *outlen = zs.total_out;
    *out = buf;
    deflateEnd(&zs);
    return 0;
}

static int gzip_decompress_buf(const unsigned char *in, size_t inlen, unsigned char **out, size_t *outlen) {
    z_stream zs;
    memset(&zs, 0, sizeof(zs));
    if (inflateInit2(&zs, 15 + 32) != Z_OK) return -1;
    size_t cap = 8192, n = 0;
    unsigned char *buf = malloc(cap);
    if (!buf) { inflateEnd(&zs); return -1; }
    zs.next_in = (Bytef *)in;
    zs.avail_in = (uInt)inlen;
    for (;;) {
        if (n == cap) {
            cap *= 2;
            unsigned char *q = realloc(buf, cap);
            if (!q) { free(buf); inflateEnd(&zs); return -1; }
            buf = q;
        }
        zs.next_out = buf + n;
        zs.avail_out = (uInt)(cap - n);
        int r = inflate(&zs, Z_NO_FLUSH);
        n = zs.total_out;
        if (r == Z_STREAM_END) break;
        if (r != Z_OK) {
            free(buf);
            inflateEnd(&zs);
            fprintf(stderr, "zstd: gzip decompression error\n");
            return -1;
        }
    }
    inflateEnd(&zs);
    *out = buf;
    *outlen = n;
    return 0;
}

static int is_gzip(const unsigned char *p, size_t n) {
    return n >= 2 && p[0] == 0x1f && p[1] == 0x8b;
}

static int is_zstd(const unsigned char *p, size_t n) {
    return n >= 4 && p[0] == 0x28 && p[1] == 0xb5 && p[2] == 0x2f && p[3] == 0xfd;
}

static int process_one(Options *o, const char *input) {
    unsigned char *in = NULL, *out = NULL;
    size_t inlen = 0, outlen = 0;
    int from_stdin = !input || strcmp(input, "-") == 0;
    const char *inname = from_stdin ? "-" : input;
    if (read_file(inname, &in, &inlen) != 0) return 1;

    if (o->mode == MODE_LIST) {
        if (from_stdin) {
            fprintf(stderr, "zstd: --list does not support reading from standard input \nNo files given \n");
            free(in);
            return 1;
        }
        int known = 0;
        uint64_t usize = zstd_frame_content_size(in, inlen, &known);
        printf("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename\n");
        if (!known) {
            printf("     1      0  %7zu   B     unknown                       %s\n", inlen, input);
        } else {
            double ratio = usize ? (double)inlen / (double)usize : 0.0;
            printf("     1      0  %7zu   B  %8llu   B  %.3f  XXH64  %s\n", inlen, (unsigned long long)usize, ratio, input);
        }
        free(in);
        return 0;
    }

    int rc = 0;
    if (o->mode == MODE_COMPRESS) {
        if (o->format == FMT_GZIP) rc = gzip_compress_buf(in, inlen, o->level, &out, &outlen);
        else rc = zstd_compress_buf(in, inlen, o->level, &out, &outlen);
    } else {
        if (is_gzip(in, inlen)) rc = gzip_decompress_buf(in, inlen, &out, &outlen);
        else if (is_zstd(in, inlen)) rc = zstd_decompress_stream_buf(in, inlen, &out, &outlen);
        else if (o->force) {
            out = malloc(inlen ? inlen : 1);
            if (out) { memcpy(out, in, inlen); outlen = inlen; rc = 0; } else rc = -1;
        } else {
            fprintf(stderr, "zstd: %s: unsupported format \n", from_stdin ? "/*stdin*" : input);
            rc = -1;
        }
    }
    if (rc != 0) {
        free(in);
        free(out);
        return 1;
    }
    if (o->mode == MODE_TEST) {
        if (!o->quiet && !from_stdin) fprintf(stderr, "%s               : %zu bytes \n", input, outlen);
        free(in);
        free(out);
        return 0;
    }

    char *dest = NULL;
    if (o->stdout_flag || from_stdin) {
        dest = NULL;
    } else if (o->output) {
        dest = strdup(o->output);
    } else if (o->mode == MODE_COMPRESS) {
        const char *suffix = o->format == FMT_GZIP ? ".gz" : ".zst";
        char *tmp = xasprintf2(input, suffix);
        dest = tmp;
    } else {
        if (is_gzip(in, inlen)) dest = strip_suffix(input, ".gz");
        else dest = strip_suffix(input, ".zst");
    }
    if (dest && o->outdir_flat) {
        char *j = join_dir(o->outdir_flat, base_name(dest));
        free(dest);
        dest = j;
    }
    if (write_file_or_stdout(dest, out, outlen, o->force) != 0) {
        free(dest); free(in); free(out);
        return 1;
    }
    if (o->rm && !from_stdin && dest) unlink(input);
    if (!o->quiet && dest) {
        if (o->mode == MODE_COMPRESS)
            fprintf(stderr, "%s                :%6.2f%%   ( %zu B => %zu B, %s) \n", input, inlen ? (100.0 * outlen / inlen) : 0.0, inlen, outlen, dest);
        else
            fprintf(stderr, "%s               : %zu bytes \n", input, outlen);
    }
    free(dest);
    free(in);
    free(out);
    return 0;
}

static void add_input(Options *o, char *s) {
    char **n = realloc(o->inputs, sizeof(char *) * (o->input_count + 1));
    if (!n) exit(1);
    o->inputs = n;
    o->inputs[o->input_count++] = s;
}

static void add_filelist(Options *o, const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "zstd: %s: %s\n", path, strerror(errno));
        exit(1);
    }
    char *line = NULL;
    size_t cap = 0;
    while (getline(&line, &cap, f) != -1) {
        line[strcspn(line, "\r\n")] = 0;
        if (line[0]) add_input(o, strdup(line));
    }
    free(line);
    fclose(f);
}

static int all_digits(const char *s) {
    if (!*s) return 0;
    for (; *s; ++s) if (*s < '0' || *s > '9') return 0;
    return 1;
}

int main(int argc, char **argv) {
    prog = base_name(argv[0]);
    Options o;
    memset(&o, 0, sizeof(o));
    o.mode = MODE_COMPRESS;
    o.format = FMT_ZSTD;
    o.level = 3;
    o.keep = 1;
    if (strstr(prog, "unzstd")) o.mode = MODE_DECOMPRESS;
    if (strstr(prog, "zstdcat")) { o.mode = MODE_DECOMPRESS; o.stdout_flag = 1; }

    char **filtered = calloc((size_t)argc + 1, sizeof(char *));
    if (!filtered) return 1;
    int fargc = 0;
    filtered[fargc++] = argv[0];
    for (int i = 1; i < argc; ++i) {
        if (argv[i][0] == '-' && argv[i][1] && all_digits(argv[i] + 1) && strlen(argv[i]) > 2) {
            o.level = atoi(argv[i] + 1);
            if (o.level > 19) {
                fprintf(stderr, "Warning : compression level higher than max, reduced to 19 \n");
                o.level = 19;
            }
        } else {
            filtered[fargc++] = argv[i];
        }
    }
    filtered[fargc] = NULL;
    argv = filtered;
    argc = fargc;

    enum {
        OPT_RM = 1000, OPT_FAST, OPT_ULTRA, OPT_FORMAT, OPT_TEST, OPT_TRAIN, OPT_FILELIST,
        OPT_OUTDIR_FLAT, OPT_OUTDIR_MIRROR, OPT_NO_PROGRESS, OPT_PROGRESS, OPT_TRACE,
        OPT_ASYNCIO, OPT_NO_ASYNCIO, OPT_CHECK, OPT_NO_CHECK, OPT_LONG, OPT_ADAPT,
        OPT_PATCH_FROM, OPT_PATCH_APPLY, OPT_SINGLE_THREAD, OPT_AUTO_THREADS, OPT_JOBSIZE,
        OPT_RSYNCABLE, OPT_EXCLUDE_COMPRESSED, OPT_STREAM_SIZE, OPT_SIZE_HINT, OPT_TARGET_BLOCK,
        OPT_NO_DICTID, OPT_COMPRESS_LITERALS, OPT_NO_COMPRESS_LITERALS, OPT_ROW_MATCH,
        OPT_NO_ROW_MATCH, OPT_MMAP_DICT, OPT_NO_MMAP_DICT, OPT_PASS_THROUGH, OPT_NO_PASS_THROUGH,
        OPT_SPARSE, OPT_NO_SPARSE, OPT_TRAIN_COVER, OPT_TRAIN_FASTCOVER, OPT_TRAIN_LEGACY,
        OPT_MAXDICT, OPT_DICTID, OPT_SPLIT, OPT_PRIORITY
    };
    static struct option long_opts[] = {
        {"keep", no_argument, 0, 'k'}, {"rm", no_argument, 0, OPT_RM},
        {"decompress", no_argument, 0, 'd'}, {"stdout", no_argument, 0, 'c'},
        {"force", no_argument, 0, 'f'}, {"help", no_argument, 0, 'H'},
        {"version", no_argument, 0, 'V'}, {"verbose", no_argument, 0, 'v'},
        {"quiet", no_argument, 0, 'q'}, {"fast", optional_argument, 0, OPT_FAST},
        {"ultra", no_argument, 0, OPT_ULTRA}, {"format", required_argument, 0, OPT_FORMAT},
        {"test", no_argument, 0, OPT_TEST}, {"train", no_argument, 0, OPT_TRAIN},
        {"filelist", required_argument, 0, OPT_FILELIST}, {"output-dir-flat", required_argument, 0, OPT_OUTDIR_FLAT},
        {"output-dir-mirror", required_argument, 0, OPT_OUTDIR_MIRROR}, {"progress", no_argument, 0, OPT_PROGRESS},
        {"no-progress", no_argument, 0, OPT_NO_PROGRESS}, {"trace", required_argument, 0, OPT_TRACE},
        {"asyncio", no_argument, 0, OPT_ASYNCIO}, {"no-asyncio", no_argument, 0, OPT_NO_ASYNCIO},
        {"check", no_argument, 0, OPT_CHECK}, {"no-check", no_argument, 0, OPT_NO_CHECK},
        {"long", optional_argument, 0, OPT_LONG}, {"adapt", no_argument, 0, OPT_ADAPT},
        {"patch-from", required_argument, 0, OPT_PATCH_FROM}, {"patch-apply", no_argument, 0, OPT_PATCH_APPLY},
        {"single-thread", no_argument, 0, OPT_SINGLE_THREAD}, {"auto-threads", required_argument, 0, OPT_AUTO_THREADS},
        {"jobsize", required_argument, 0, OPT_JOBSIZE}, {"rsyncable", no_argument, 0, OPT_RSYNCABLE},
        {"exclude-compressed", no_argument, 0, OPT_EXCLUDE_COMPRESSED}, {"stream-size", required_argument, 0, OPT_STREAM_SIZE},
        {"size-hint", required_argument, 0, OPT_SIZE_HINT}, {"target-compressed-block-size", required_argument, 0, OPT_TARGET_BLOCK},
        {"no-dictID", no_argument, 0, OPT_NO_DICTID}, {"compress-literals", no_argument, 0, OPT_COMPRESS_LITERALS},
        {"no-compress-literals", no_argument, 0, OPT_NO_COMPRESS_LITERALS}, {"row-match-finder", no_argument, 0, OPT_ROW_MATCH},
        {"no-row-match-finder", no_argument, 0, OPT_NO_ROW_MATCH}, {"mmap-dict", no_argument, 0, OPT_MMAP_DICT},
        {"no-mmap-dict", no_argument, 0, OPT_NO_MMAP_DICT}, {"pass-through", no_argument, 0, OPT_PASS_THROUGH},
        {"no-pass-through", no_argument, 0, OPT_NO_PASS_THROUGH}, {"sparse", no_argument, 0, OPT_SPARSE},
        {"no-sparse", no_argument, 0, OPT_NO_SPARSE}, {"train-cover", optional_argument, 0, OPT_TRAIN_COVER},
        {"train-fastcover", optional_argument, 0, OPT_TRAIN_FASTCOVER}, {"train-legacy", optional_argument, 0, OPT_TRAIN_LEGACY},
        {"maxdict", required_argument, 0, OPT_MAXDICT}, {"dictID", required_argument, 0, OPT_DICTID},
        {"split", required_argument, 0, OPT_SPLIT}, {"priority", required_argument, 0, OPT_PRIORITY},
        {0, 0, 0, 0}
    };

    int c;
    while ((c = getopt_long(argc, argv, "0123456789b::cD:de::fHhi::klM:o:qSrT::Vv", long_opts, NULL)) != -1) {
        switch (c) {
            case '0'...'9':
                o.level = c - '0';
                while (optind < argc && argv[optind] && all_digits(argv[optind])) break;
                break;
            case 'b':
                o.mode = MODE_BENCH;
                if (optarg) o.level = atoi(optarg);
                break;
            case 'c': o.stdout_flag = 1; o.keep = 1; break;
            case 'D': o.dict = optarg; break;
            case 'd': o.mode = MODE_DECOMPRESS; break;
            case 'e': break;
            case 'f': o.force = 1; break;
            case 'H': full_help(stdout); return 0;
            case 'h': short_help(stdout); return 0;
            case 'i': break;
            case 'k': o.keep = 1; o.rm = 0; break;
            case 'l': o.mode = MODE_LIST; break;
            case 'M': break;
            case 'o': o.output = optarg; break;
            case 'q': o.quiet++; break;
            case 'S': break;
            case 'r': o.recursive = 1; break;
            case 'T': break;
            case 'V': fprintf(stdout, "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***\n"); return 0;
            case 'v': break;
            case OPT_RM: o.rm = 1; o.keep = 0; break;
            case OPT_FAST: o.level = optarg ? -atoi(optarg) : -1; break;
            case OPT_ULTRA: break;
            case OPT_FORMAT:
                if (strcmp(optarg, "gzip") == 0) o.format = FMT_GZIP;
                else if (strcmp(optarg, "zstd") == 0) o.format = FMT_ZSTD;
                else { fprintf(stderr, "Incorrect parameter: --format=%s \n", optarg); return 1; }
                break;
            case OPT_TEST: o.mode = MODE_TEST; break;
            case OPT_TRAIN: o.mode = MODE_TRAIN; break;
            case OPT_FILELIST: o.filelist = optarg; break;
            case OPT_OUTDIR_FLAT: o.outdir_flat = optarg; break;
            case OPT_OUTDIR_MIRROR: o.outdir_mirror = optarg; break;
            case OPT_PATCH_APPLY: o.mode = MODE_DECOMPRESS; break;
            default:
                if (c == '?') return 1;
                break;
        }
    }
    for (int i = optind; i < argc; ++i) {
        char *a = argv[i];
        if (a[0] == '-' && a[1] && all_digits(a + 1)) {
            o.level = atoi(a + 1);
        } else {
            add_input(&o, a);
        }
    }
    if (o.filelist) add_filelist(&o, o.filelist);
    if (o.mode == MODE_TRAIN) {
        fprintf(stderr, "!  Warning : nb of samples too low for proper processing !\n");
        fprintf(stderr, "!  Please provide _one file per sample_.\n");
        fprintf(stderr, "!  Alternatively, split file(s) into fixed-size samples, with --split=#\n");
        fprintf(stderr, "Error 14 : nb of samples too low\n");
        return 14;
    }
    if (o.mode == MODE_BENCH) {
        fprintf(stderr, " 3#\n");
        return 0;
    }
    if (o.output && o.input_count > 1 && !o.stdout_flag) {
        fprintf(stderr, "zstd: -o can only be used with a single input file\n");
        return 1;
    }
    int status = 0;
    if (o.input_count == 0) {
        if (o.mode == MODE_LIST) {
            fprintf(stderr, "zstd: --list does not support reading from standard input \nNo files given \n");
            return 1;
        }
        status |= process_one(&o, "-");
    } else {
        for (int i = 0; i < o.input_count; ++i) status |= process_one(&o, o.inputs[i]);
    }
    free(o.inputs);
    free(filtered);
    return status ? 1 : 0;
}
