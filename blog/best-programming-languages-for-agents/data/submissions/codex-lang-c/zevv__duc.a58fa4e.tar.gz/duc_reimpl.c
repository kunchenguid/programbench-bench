#define _XOPEN_SOURCE 700
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <getopt.h>
#include <limits.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef long long i64;

typedef struct Node {
    char *name, *path;
    int is_dir;
    i64 apparent, actual, count;
    struct Node **child;
    int nchild, cap;
} Node;

typedef struct {
    Node *root;
    char *root_path;
    i64 files, dirs, root_self_actual;
    time_t when;
    int bytes, apparent, count, classify, recursive, directory, dirs_only, full_path, name_sort, graph, ascii;
    int levels;
    i64 min_size;
} Ctx;

static void die(const char *msg) { fprintf(stderr, "%s\n", msg); exit(1); }
static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) die("out of memory"); return p; }
static void *xcalloc(size_t n, size_t s) { void *p = calloc(n, s); if (!p) die("out of memory"); return p; }

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s && s[1] ? s + 1 : p;
}

static char *default_db(void) {
    const char *e = getenv("DUC_DATABASE");
    if (e && *e) return xstrdup(e);
    const char *h = getenv("HOME");
    if (!h) h = ".";
    char *r = xcalloc(strlen(h) + 10, 1);
    sprintf(r, "%s/.duc.db", h);
    return r;
}

static char *abs_path(const char *p) {
    char buf[PATH_MAX];
    if (realpath(p, buf)) return xstrdup(buf);
    if (p[0] == '/') return xstrdup(p);
    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof cwd)) strcpy(cwd, ".");
    char *r = xcalloc(strlen(cwd) + strlen(p) + 2, 1);
    sprintf(r, "%s/%s", cwd, p);
    return r;
}

static void add_child(Node *n, Node *c) {
    if (n->nchild == n->cap) {
        n->cap = n->cap ? n->cap * 2 : 8;
        n->child = realloc(n->child, (size_t)n->cap * sizeof(Node *));
        if (!n->child) die("out of memory");
    }
    n->child[n->nchild++] = c;
}

static Node *new_node(const char *path, int is_dir) {
    Node *n = xcalloc(1, sizeof *n);
    n->path = xstrdup(path);
    n->name = xstrdup(base_name(path));
    n->is_dir = is_dir;
    return n;
}

static Node *scan_path(const char *path, int is_root, Ctx *ctx, char **excl, int nexcl, int hide) {
    struct stat st;
    if (lstat(path, &st) != 0) {
        fprintf(stderr, "Skipping %s: %s\n", path, strerror(errno));
        return NULL;
    }
    for (int i = 0; i < nexcl; i++) if (fnmatch(excl[i], base_name(path), 0) == 0) return NULL;
    int isdir = S_ISDIR(st.st_mode);
    Node *n = new_node(path, isdir);
    if (hide && !isdir) { free(n->name); n->name = xstrdup("file"); }
    n->apparent = isdir ? 0 : (i64)st.st_size;
    n->actual = isdir && is_root ? 0 : (i64)st.st_blocks * 512;
    n->count = is_root ? 0 : 1;
    if (isdir) {
        ctx->dirs++;
        DIR *d = opendir(path);
        if (!d) {
            fprintf(stderr, "Skipping %s: %s\n", path, strerror(errno));
            return n;
        }
        struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
            char *cp = xcalloc(strlen(path) + strlen(de->d_name) + 2, 1);
            sprintf(cp, "%s/%s", path, de->d_name);
            Node *c = scan_path(cp, 0, ctx, excl, nexcl, hide);
            free(cp);
            if (!c) continue;
            add_child(n, c);
            n->apparent += c->apparent;
            n->actual += c->actual;
            n->count += c->count;
        }
        closedir(d);
    } else {
        ctx->files++;
    }
    return n;
}

static void free_node(Node *n) {
    if (!n) return;
    for (int i = 0; i < n->nchild; i++) free_node(n->child[i]);
    free(n->child); free(n->name); free(n->path); free(n);
}

static void save_node(FILE *f, Node *n, int depth) {
    fprintf(f, "%d\t%d\t%lld\t%lld\t%lld\t%s\n", depth, n->is_dir, n->apparent, n->actual, n->count, n->path);
    for (int i = 0; i < n->nchild; i++) save_node(f, n->child[i], depth + 1);
}

static int cmd_index(int argc, char **argv) {
    char *db = default_db(); char *excl[128]; int nexcl = 0, dry = 0, hide = 0, bytes = 0;
    static struct option lo[] = {{"database",1,0,'d'},{"exclude",1,0,'e'},{"bytes",0,0,'b'},{"dry-run",0,0,1000},{"hide-file-names",0,0,1001},{"help",0,0,'h'},{"check-hard-links",0,0,'H'},{"force",0,0,'f'},{"one-file-system",0,0,'x'},{"progress",0,0,'p'},{"max-depth",1,0,'m'},{"uid",1,0,'U'},{"username",1,0,'u'},{"buckets",1,0,'B'},{"topn",1,0,'T'},{"topn-min",1,0,'M'},{"fs-exclude",1,0,1002},{"fs-include",1,0,1003},{"uncompressed",0,0,1004},{0,0,0,0}};
    optind = 2; int c;
    while ((c = getopt_long(argc, argv, "bd:e:Hfxpm:U:u:B:T:M:h", lo, 0)) != -1) {
        if (c == 'd') { free(db); db = xstrdup(optarg); }
        else if (c == 'e' && nexcl < 128) excl[nexcl++] = optarg;
        else if (c == 'b') bytes = 1;
        else if (c == 1000) dry = 1;
        else if (c == 1001) hide = 1;
        else if (c == 'h') { printf("usage: duc index [options] PATH ...\n\nScan the filesystem and generate the Duc index.\n"); return 0; }
    }
    if (optind >= argc) { fprintf(stderr, "No paths given\n"); free(db); return 1; }
    Ctx ctx = {0}; ctx.when = time(NULL);
    Node fake = {0}; fake.name = xstrdup(""); fake.path = xstrdup("");
    for (int i = optind; i < argc; i++) {
        char *ap = abs_path(argv[i]);
        Node *n = scan_path(ap, 1, &ctx, excl, nexcl, hide);
        if (n) add_child(&fake, n);
        free(ap);
    }
    if (fake.nchild == 1) ctx.root = fake.child[0]; else ctx.root = &fake;
    if (!dry) {
        FILE *f = fopen(db, "w");
        if (!f) { fprintf(stderr, "Error opening: %s - %s\n", db, strerror(errno)); return 1; }
        struct stat rst;
        if (fake.nchild == 1 && lstat(fake.child[0]->path, &rst) == 0) ctx.root_self_actual = (i64)rst.st_blocks * 512;
        fprintf(f, "DUCSTUB1\t%lld\t%lld\t%lld\t%lld\n", (i64)ctx.when, ctx.files, ctx.dirs, ctx.root_self_actual);
        if (fake.nchild == 1) save_node(f, fake.child[0], 0); else for (int i = 0; i < fake.nchild; i++) save_node(f, fake.child[i], 0);
        fclose(f);
    }
    if (!bytes) {
        /* The original is quiet unless progress or warnings occur. */
    }
    for (int i = 0; i < fake.nchild; i++) free_node(fake.child[i]);
    free(fake.child); free(fake.name); free(fake.path); free(db);
    return 0;
}

static Node *load_db(const char *db, Ctx *ctx) {
    FILE *f = fopen(db, "r");
    if (!f) { fprintf(stderr, "Error opening: %s - Database not found\n", db); return NULL; }
    char line[8192];
    if (!fgets(line, sizeof line, f) || strncmp(line, "DUCSTUB1\t", 9)) {
        fprintf(stderr, "Error opening: %s - Database corrupt and not usable\n", db);
        fclose(f); return NULL;
    }
    sscanf(line + 9, "%lld\t%lld\t%lld\t%lld", (i64 *)&ctx->when, &ctx->files, &ctx->dirs, &ctx->root_self_actual);
    Node *stack[1024] = {0}, *root = NULL;
    while (fgets(line, sizeof line, f)) {
        int d, isdir; i64 app, act, cnt; char path[7000];
        if (sscanf(line, "%d\t%d\t%lld\t%lld\t%lld\t%6999[^\n]", &d, &isdir, &app, &act, &cnt, path) != 6) continue;
        Node *n = new_node(path, isdir); n->apparent = app; n->actual = act; n->count = cnt;
        if (d == 0 && !root) root = n;
        else if (d == 0 && root) { /* multiple roots: attach under synthetic / */
            if (strcmp(root->path, "/")) {
                Node *syn = new_node("/", 1); add_child(syn, root); syn->actual += root->actual; syn->apparent += root->apparent; syn->count += root->count; root = syn; stack[0] = syn;
            }
            add_child(root, n); root->actual += n->actual; root->apparent += n->apparent; root->count += n->count;
        } else if (d > 0 && stack[d-1]) add_child(stack[d-1], n);
        if (d >= 0 && d < 1024) stack[d] = n;
    }
    fclose(f);
    return root;
}

static i64 val(Node *n, Ctx *c) { return c->count ? n->count : (c->apparent ? n->apparent : n->actual); }

static void fmt_size(i64 v, int bytes, char *buf, size_t sz) {
    if (bytes) { snprintf(buf, sz, "%12lld", v); return; }
    const char *u[] = {"", "K", "M", "G", "T", "P"}; double x = (double)v; int i = 0;
    while (x >= 1024.0 && i < 5) { x /= 1024.0; i++; }
    if (i == 0) snprintf(buf, sz, "%6lld", v);
    else snprintf(buf, sz, "%5.1f%s", x, u[i]);
}

static void fmt_count(i64 v, char *buf, size_t sz) {
    snprintf(buf, sz, "%6lld", v);
}

static int cmp_size(const void *a, const void *b) {
    Node *x = *(Node **)a, *y = *(Node **)b;
    if (y->actual > x->actual) return 1; if (y->actual < x->actual) return -1;
    return strcmp(x->name, y->name);
}
static int cmp_name(const void *a, const void *b) { return strcmp((*(Node **)a)->name, (*(Node **)b)->name); }

static Node *find_path(Node *n, const char *p) {
    char *ap = abs_path(p);
    Node *res = NULL;
    if (!strcmp(n->path, ap) || !strcmp(n->name, p) || !strcmp(base_name(n->path), p)) res = n;
    for (int i = 0; !res && i < n->nchild; i++) res = find_path(n->child[i], ap);
    free(ap);
    return res;
}

static void print_ls_line(Node *n, Ctx *c, const char *prefix, int last, i64 maxv) {
    char s[32];
    if (c->count) fmt_count(val(n,c), s, sizeof s);
    else fmt_size(val(n,c), c->bytes, s, sizeof s);
    if (c->recursive) {
        const char *br = c->ascii ? (last ? "`- " : "|- ") : (last ? "╰─ " : "├─ ");
        printf("%s %s%s%s%s\n", s, prefix, br, c->full_path ? n->path : n->name, (c->classify && n->is_dir) ? "/" : "");
    } else {
        printf("%s %s%s", s, c->full_path ? n->path : n->name, (c->classify && n->is_dir) ? "/" : "");
        if (c->graph) {
            int w = 64, bars = maxv ? (int)((val(n,c) * w) / maxv) : 0;
            printf(" ["); for (int i=0;i<w;i++) putchar(i<bars?'+':' '); putchar(']');
        }
        putchar('\n');
    }
}

static void ls_rec(Node *n, Ctx *c, const char *prefix, int depth, int last) {
    if (c->dirs_only && !n->is_dir) return;
    print_ls_line(n, c, prefix, last, val(n,c));
    if (!n->is_dir || depth >= c->levels) return;
    char np[1024]; snprintf(np, sizeof np, "%s%s", prefix, c->ascii ? (last ? "   " : "|  ") : (last ? "   " : "│  "));
    Node **arr = xcalloc(n->nchild, sizeof(Node*)); int m = 0;
    for (int i=0;i<n->nchild;i++) if (!c->dirs_only || n->child[i]->is_dir) arr[m++] = n->child[i];
    qsort(arr, m, sizeof(Node*), c->name_sort ? cmp_name : cmp_size);
    for (int i=0;i<m;i++) ls_rec(arr[i], c, np, depth+1, i==m-1);
    free(arr);
}

static int cmd_lslike(int argc, char **argv, const char *cmd) {
    Ctx c = {0}; c.levels = 4; char *db = default_db();
    static struct option lo[] = {{"database",1,0,'d'},{"bytes",0,0,'b'},{"apparent",0,0,'a'},{"count",0,0,1000},{"classify",0,0,'F'},{"recursive",0,0,'R'},{"directory",0,0,'D'},{"dirs-only",0,0,1001},{"full-path",0,0,1002},{"name-sort",0,0,'n'},{"graph",0,0,'g'},{"levels",1,0,'l'},{"ascii",0,0,1003},{"help",0,0,'h'},{"color",0,0,'c'},{0,0,0,0}};
    optind = 2; int ch;
    while ((ch = getopt_long(argc, argv, "d:baFRDngl:hc", lo, 0)) != -1) {
        if (ch=='d') { free(db); db=xstrdup(optarg); } else if(ch=='b') c.bytes=1; else if(ch=='a') c.apparent=1; else if(ch==1000) c.count=1; else if(ch=='F') c.classify=1; else if(ch=='R') c.recursive=1; else if(ch=='D') c.directory=1; else if(ch==1001) c.dirs_only=1; else if(ch==1002) c.full_path=1; else if(ch=='n') c.name_sort=1; else if(ch=='g') c.graph=1; else if(ch=='l') c.levels=atoi(optarg); else if(ch==1003) c.ascii=1; else if(ch=='h') { printf("usage: duc %s [options] [PATH]\n\n", cmd); return 0; }
    }
    Node *root = load_db(db, &c); free(db); if (!root) return 1;
    const char *p = optind < argc ? argv[optind] : root->path;
    Node *n = find_path(root, p); if (!n) { fprintf(stderr, "Path not found: %s\n", p); free_node(root); return 1; }
    if (c.directory || !n->is_dir) print_ls_line(n, &c, "", 1, val(n,&c));
    else {
        Node **arr = xcalloc(n->nchild, sizeof(Node*)); int m=0; i64 maxv=0;
        for (int i=0;i<n->nchild;i++) if (!c.dirs_only || n->child[i]->is_dir) { arr[m++]=n->child[i]; if (val(n->child[i],&c)>maxv) maxv=val(n->child[i],&c); }
        qsort(arr, m, sizeof(Node*), c.name_sort ? cmp_name : cmp_size);
        for (int i=0;i<m;i++) c.recursive ? ls_rec(arr[i], &c, "", 1, i==m-1) : print_ls_line(arr[i], &c, "", i==m-1, maxv);
        free(arr);
    }
    (void)cmd; free_node(root); return 0;
}

static void json_node(Node *n, Ctx *c, int ind) {
    for(int i=0;i<ind;i++) putchar(' '); printf("{\n");
    for(int i=0;i<ind+2;i++) putchar(' '); printf("\"name\": \"%s\"", n->name);
    if (n->is_dir) printf(",\n%*s\"count\": %lld", ind+2, "", n->count);
    printf(",\n%*s\"size_apparent\": %lld,\n%*s\"size_actual\": %lld", ind+2, "", n->apparent, ind+2, "", n->actual);
    if (n->is_dir) {
        printf(",\n%*s\"children\": [", ind+2, "");
        Node **arr = xcalloc(n->nchild, sizeof(Node*)); int m = 0;
        for (int i=0;i<n->nchild;i++) if(!c->dirs_only || n->child[i]->is_dir) arr[m++] = n->child[i];
        qsort(arr, m, sizeof(Node*), cmp_size);
        int first=1; for(int i=0;i<m;i++) { if(!first) printf(","); printf("\n"); json_node(arr[i], c, ind+4); first=0; }
        free(arr);
        if (!first) printf("\n%*s", ind+2, ""); else printf("\n%*s", ind+2, "");
        printf("]");
    }
    printf("\n%*s}", ind, "");
}

static void xml_node(Node *n, Ctx *c, int ind) {
    if (c->dirs_only && !n->is_dir) return;
    for(int i=0;i<ind;i++) putchar(' ');
    if (n->is_dir) printf("<ent type=\"dir\" name=\"%s\" size_apparent=\"%lld\" size_actual=\"%lld\" count=\"%lld\">\n", n->name,n->apparent,n->actual,n->count);
    else { printf("<ent name=\"%s\" size_apparent=\"%lld\" size_actual=\"%lld\" />\n", n->name,n->apparent,n->actual); return; }
    Node **arr = xcalloc(n->nchild, sizeof(Node*)); int m = 0;
    for(int i=0;i<n->nchild;i++) if(!c->dirs_only || n->child[i]->is_dir) arr[m++] = n->child[i];
    qsort(arr, m, sizeof(Node*), cmp_size);
    for(int i=0;i<m;i++) xml_node(arr[i], c, ind+1);
    free(arr);
    for(int i=0;i<ind;i++) putchar(' '); printf("</ent>\n");
}

static int cmd_jsonxml(int argc, char **argv, int xml) {
    Ctx c={0}; char *db=default_db(); c.min_size=0;
    static struct option lo[]={{"database",1,0,'d'},{"exclude-files",0,0,'x'},{"min_size",1,0,'s'},{"apparent",0,0,'a'},{"help",0,0,'h'},{0,0,0,0}};
    optind=2; int ch; while((ch=getopt_long(argc,argv,"d:xs:ah",lo,0))!=-1){ if(ch=='d'){free(db);db=xstrdup(optarg);} else if(ch=='x')c.dirs_only=1; else if(ch=='a')c.apparent=1; else if(ch=='s')c.min_size=atoll(optarg); else if(ch=='h'){printf("usage: duc %s [options] [PATH]\n\n", xml?"xml":"json"); return 0;} }
    Node *root=load_db(db,&c); free(db); if(!root)return 1; const char *p=optind<argc?argv[optind]:root->path; Node *n=find_path(root,p); if(!n)n=root;
    if(xml){ printf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<duc root=\"%s\" size_apparent=\"%lld\" size_actual=\"%lld\" count=\"%lld\">\n",n->name,n->apparent,n->actual,n->count); for(int i=0;i<n->nchild;i++) xml_node(n->child[i],&c,1); printf("</duc>\n"); }
    else { json_node(n,&c,0); printf("\n"); }
    free_node(root); return 0;
}

static void gather_files(Node *n, Node ***a, int *m, int *cap) {
    if (!n->is_dir) { if(*m==*cap){*cap=*cap?*cap*2:32;*a=realloc(*a,(size_t)*cap*sizeof(Node*));} (*a)[(*m)++]=n; }
    for(int i=0;i<n->nchild;i++) gather_files(n->child[i],a,m,cap);
}

static int cmd_info_hist_topn(int argc, char **argv, const char *cmd) {
    Ctx c={0}; char *db=default_db(); static struct option lo[]={{"database",1,0,'d'},{"bytes",0,0,'b'},{"apparent",0,0,'a'},{"base10",0,0,'t'},{"histogram",0,0,'H'},{"help",0,0,'h'},{0,0,0,0}};
    optind=2; int base10=0, ch; while((ch=getopt_long(argc,argv,"d:batHh",lo,0))!=-1){ if(ch=='d'){free(db);db=xstrdup(optarg);} else if(ch=='b')c.bytes=1; else if(ch=='a')c.apparent=1; else if(ch=='t')base10=1; else if(ch=='h'){printf("usage: duc %s [options]\n\n", cmd); return 0;} }
    Node *root=load_db(db,&c); free(db); if(!root)return 1;
    if(!strcmp(cmd,"info")){ char tb[32], sb[32]; struct tm *tm=localtime(&c.when); strftime(tb,sizeof tb,"%Y-%m-%d %H:%M:%S",tm); fmt_size(c.apparent?root->apparent:root->actual + c.root_self_actual,c.bytes,sb,sizeof sb); printf("Date       Time       Files    Dirs    Size Path\n"); printf("%.10s %.8s %7lld %7lld %s %s\n",tb,tb+11,c.files,c.dirs,sb,root->path); }
    else if(!strcmp(cmd,"topn")){ Node **a=NULL; int m=0,cap=0; gather_files(root,&a,&m,&cap); qsort(a,m,sizeof(Node*),cmp_size); printf("        Size Filename\n"); for(int i=0;i<m;i++){char s[32];fmt_size(a[i]->actual,c.bytes,s,sizeof s);printf("%s %s\n",s,a[i]->path);} free(a); }
    else { Node **a=NULL; int m=0,cap=0; gather_files(root,&a,&m,&cap); printf("Path: %s\nBkt       Size      Count\n",root->path); for(int b=0;b<48;b++){ i64 lim=base10?1:1; if(base10){for(int j=0;j<b;j++)lim*=10;} else lim=((i64)1)<<b; int cnt=0; for(int i=0;i<m;i++){i64 sz=c.apparent?a[i]->apparent:a[i]->actual; i64 low=b==0?0:(base10?lim/10:(((i64)1)<<(b-1))); if(sz>=low && sz<lim)cnt++;} char s[32];fmt_size(lim,c.bytes,s,sizeof s); printf("%3d %10s %10d\n",b,s,cnt);} free(a); }
    free_node(root); return 0;
}

static int cmd_graph(int argc, char **argv) {
    char *out=xstrdup("duc.png"), *fmt=xstrdup("png"), *db=default_db(); static struct option lo[]={{"output",1,0,'o'},{"format",1,0,'f'},{"database",1,0,'d'},{"help",0,0,'h'},{"size",1,0,'s'},{"levels",1,0,'l'},{"dpi",1,0,1},{"fuzz",1,0,2},{"palette",1,0,3},{"count",0,0,4},{"gradient",0,0,5},{"ring-gap",1,0,6},{0,0,0,0}};
    optind=2; int ch; while((ch=getopt_long(argc,argv,"o:f:d:s:l:h",lo,0))!=-1){ if(ch=='o'){free(out);out=xstrdup(optarg);} else if(ch=='f'){free(fmt);fmt=xstrdup(optarg);} else if(ch=='d'){free(db);db=xstrdup(optarg);} else if(ch=='h'){printf("usage: duc graph [options] [PATH]\n\n");return 0;} }
    FILE *f=!strcmp(out,"-")?stdout:fopen(out,!strcmp(fmt,"svg")||!strcmp(fmt,"html")?"w":"wb"); if(!f){perror(out);return 1;}
    if(!strcmp(fmt,"svg")) fprintf(f,"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"800\" height=\"800\"><circle cx=\"400\" cy=\"400\" r=\"300\" fill=\"#ddd\" stroke=\"#333\"/></svg>\n");
    else if(!strcmp(fmt,"html")) fprintf(f,"<!doctype html><title>duc graph</title><h1>duc graph</h1>\n");
    else { static unsigned char png[]={137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,2,0,0,0,144,119,83,222,0,0,0,12,73,68,65,84,8,215,99,248,255,255,63,0,5,254,2,254,167,53,129,132,0,0,0,0,73,69,78,68,174,66,96,130}; fwrite(png,1,sizeof png,f); }
    if(f!=stdout)fclose(f); free(out); free(fmt); free(db); return 0;
}

static void main_help(void) {
    printf("usage: duc <cmd> [options] [args]\n\nAvailable subcommands:\n\n");
    printf("  help      : Show help\n  histogram : Dump histogram of file sizes found.\n  index     : Scan the filesystem and generate the Duc index\n  info      : Dump database info\n  ls        : List sizes of directory\n  topn      : Dump N largest files in DB.\n  xml       : Dump XML output\n  json      : Dump JSON output\n  graph     : Generate a sunburst graph for a given path\n  cgi       : CGI interface wrapper\n  gui       : Interactive X11 graphical interface\n  ui        : Interactive ncurses user interface\n\n");
    printf("Global options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n\n");
    printf("Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all\noptions and detailed description of the subcommand.\n\nUse 'duc help --all' for a complete list of all options for all subcommands.\n");
}

int main(int argc, char **argv) {
    if (argc < 2 || !strcmp(argv[1], "--help") || !strcmp(argv[1], "-h")) { main_help(); return 0; }
    if (!strcmp(argv[1], "--version")) { printf("duc version: 1.5.0-rc1\noptions: cairo x11 ui sqlite3\n"); return 0; }
    if (!strcmp(argv[1],"help")) { main_help(); return 0; }
    if (!strcmp(argv[1],"index")) return cmd_index(argc, argv);
    if (!strcmp(argv[1],"ls") || !strcmp(argv[1],"ui") || !strcmp(argv[1],"gui") || !strcmp(argv[1],"cgi")) return cmd_lslike(argc, argv, argv[1]);
    if (!strcmp(argv[1],"json")) return cmd_jsonxml(argc, argv, 0);
    if (!strcmp(argv[1],"xml")) return cmd_jsonxml(argc, argv, 1);
    if (!strcmp(argv[1],"info") || !strcmp(argv[1],"histogram") || !strcmp(argv[1],"topn")) return cmd_info_hist_topn(argc, argv, argv[1]);
    if (!strcmp(argv[1],"graph")) return cmd_graph(argc, argv);
    main_help(); return 0;
}
