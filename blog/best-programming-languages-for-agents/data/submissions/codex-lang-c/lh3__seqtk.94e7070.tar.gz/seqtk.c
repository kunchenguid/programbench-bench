#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <zlib.h>

typedef struct { char *s; size_t l, c; } Str;
typedef struct { gzFile fp; int has; char *line; size_t cap; } Reader;
typedef struct { char *name, *comment, *seq, *qual; int is_fastq; } Rec;
typedef struct { char *name; int is_reg; long st,en; int strand; } Item;

static void die(const char *s){ fprintf(stderr,"%s\n",s); exit(1); }
static void *xcalloc(size_t n,size_t s){ void *p=calloc(n,s); if(!p) die("out of memory"); return p; }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) die("out of memory"); return p; }
static void spush(Str *b, const char *s, size_t n){ if(b->l+n+1>b->c){ b->c=(b->l+n+1)*2+64; b->s=realloc(b->s,b->c); if(!b->s) die("out of memory"); } memcpy(b->s+b->l,s,n); b->l+=n; b->s[b->l]=0; }
static void trimnl(char *s){ size_t n=strlen(s); while(n && (s[n-1]=='\n'||s[n-1]=='\r')) s[--n]=0; }

static int getline_gz(Reader *r, char **out){
    if(r->has){ r->has=0; *out=r->line; return 1; }
    if(!r->line){ r->cap=8192; r->line=malloc(r->cap); }
    r->line[0]=0; size_t len=0;
    for(;;){
        if(gzgets(r->fp, r->line+len, (int)(r->cap-len))==NULL){
            if(len){ *out=r->line; return 1; }
            return 0;
        }
        len=strlen(r->line);
        if(len && r->line[len-1]=='\n') { *out=r->line; return 1; }
        r->cap*=2; r->line=realloc(r->line,r->cap); if(!r->line) die("out of memory");
    }
}
static Reader *open_reader(const char *fn){
    Reader *r=xcalloc(1,sizeof(*r));
    r->fp = (!fn || strcmp(fn,"-")==0)? gzdopen(fileno(stdin),"rb") : gzopen(fn,"rb");
    if(!r->fp){ fprintf(stderr,"[E::%s] fail to open file '%s'\n", __func__, fn); exit(1); }
    return r;
}
static void close_reader(Reader *r){ if(!r) return; if(r->fp) gzclose(r->fp); free(r->line); free(r); }
static void free_rec(Rec *x){ free(x->name); free(x->comment); free(x->seq); free(x->qual); memset(x,0,sizeof(*x)); }

static int next_rec(Reader *r, Rec *rec){
    free_rec(rec);
    char *line;
    while(getline_gz(r,&line)){
        trimnl(line);
        if(line[0]=='>' || line[0]=='@') break;
    }
    if(!(line[0]=='>' || line[0]=='@')) return 0;
    int start=line[0]; char *h=line+1, *sp=h;
    while(*sp && !isspace((unsigned char)*sp)) sp++;
    rec->name=strndup(h, sp-h); if(!rec->name) die("out of memory");
    while(*sp && isspace((unsigned char)*sp)) sp++;
    rec->comment=xstrdup(sp);
    Str seq={0}, qual={0};
    if(start=='>'){
        while(getline_gz(r,&line)){
            trimnl(line);
            if(line[0]=='>' || line[0]=='@'){ r->has=1; break; }
            spush(&seq,line,strlen(line));
        }
        rec->seq=seq.s?seq.s:xstrdup(""); rec->is_fastq=0; return 1;
    } else {
        while(getline_gz(r,&line)){
            trimnl(line);
            if(line[0]=='+') break;
            spush(&seq,line,strlen(line));
        }
        while(qual.l < seq.l && getline_gz(r,&line)){
            trimnl(line); spush(&qual,line,strlen(line));
        }
        rec->seq=seq.s?seq.s:xstrdup(""); rec->qual=qual.s?qual.s:xstrdup(""); rec->is_fastq=1; return 1;
    }
}

static char comp_base(char c){
    switch(c){
        case 'A': return 'T'; case 'C': return 'G'; case 'G': return 'C'; case 'T': case 'U': return 'A';
        case 'a': return 't'; case 'c': return 'g'; case 'g': return 'c'; case 't': case 'u': return 'a';
        case 'M': return 'K'; case 'K': return 'M'; case 'R': return 'Y'; case 'Y': return 'R';
        case 'S': return 'S'; case 'W': return 'W'; case 'B': return 'V'; case 'V': return 'B';
        case 'D': return 'H'; case 'H': return 'D';
        case 'm': return 'k'; case 'k': return 'm'; case 'r': return 'y'; case 'y': return 'r';
        case 's': return 's'; case 'w': return 'w'; case 'b': return 'v'; case 'v': return 'b';
        case 'd': return 'h'; case 'h': return 'd'; default: return c;
    }
}
static void revcomp(char *s){ size_t n=strlen(s); for(size_t i=0;i<n/2;i++){ char a=comp_base(s[i]), b=comp_base(s[n-1-i]); s[i]=b; s[n-1-i]=a; } if(n&1) s[n/2]=comp_base(s[n/2]); }
static void reverse(char *s){ size_t n=strlen(s); for(size_t i=0;i<n/2;i++){ char t=s[i]; s[i]=s[n-1-i]; s[n-1-i]=t; } }
static void print_wrapped(const char *s, int l){
    size_t n=strlen(s);
    if(l<=0){ puts(s); return; }
    for(size_t i=0;i<n;i+=l) printf("%.*s\n", (int)((i+l<n)?l:n-i), s+i);
}
static void print_rec(Rec *r, int as_fa, int as_fq, int no_comment, int l){
    int fa = as_fa || (!as_fq && !r->is_fastq);
    printf("%c%s", fa?'>':'@', r->name);
    if(!no_comment && r->comment && *r->comment) printf(" %s", r->comment);
    putchar('\n'); print_wrapped(r->seq,l);
    if(!fa){ puts("+"); print_wrapped(r->qual?r->qual:"",l); }
}

static int load_items(const char *fn, Item **out);

static int cmd_seq(int argc, char **argv){
    int as_fa=0, as_fq=0, no_comment=0, l=0, rev=0, qual_base=33, qth=-1; char nchar=0; char *maskfn=NULL;
    int i;
    for(i=0;i<argc;i++){
        char *a=argv[i]; if(a[0]!='-') break;
        for(char *p=a+1; *p; p++){
            if(*p=='a' || *p=='A') as_fa=1;
            else if(*p=='C') no_comment=1;
            else if(*p=='r') rev=1;
            else if(*p=='F') as_fq=1;
            else if(*p=='l'){ if(p[1]) l=atoi(p+1); else if(i+1<argc) l=atoi(argv[++i]); break; }
            else if(*p=='q'){ if(p[1]) qth=atoi(p+1); else if(i+1<argc) qth=atoi(argv[++i]); break; }
            else if(*p=='Q'){ if(p[1]) qual_base=atoi(p+1); break; }
            else if(*p=='n'){ if(p[1]) nchar=p[1]; else if(i+1<argc) nchar=argv[++i][0]; break; }
            else if(*p=='M'){ if(p[1]) maskfn=p+1; else if(i+1<argc) maskfn=argv[++i]; break; }
        }
    }
    (void)maskfn;
    Item *masks=NULL; int nmasks=maskfn?load_items(maskfn,&masks):0;
    Reader *rd=open_reader(i<argc?argv[i]:"-"); Rec r={0};
    while(next_rec(rd,&r)){
        if(nmasks){
            long len=(long)strlen(r.seq);
            for(int j=0;j<nmasks;j++) if(!strcmp(masks[j].name,r.name) && masks[j].is_reg){
                long st=masks[j].st<0?0:masks[j].st, en=masks[j].en>len?len:masks[j].en;
                for(long k=st;k<en;k++) r.seq[k]=(char)tolower((unsigned char)r.seq[k]);
            }
        }
        if(qth>=0 && r.is_fastq && r.qual){
            for(size_t k=0;r.seq[k]&&r.qual[k];k++) if((int)r.qual[k]-qual_base < qth) r.seq[k]= nchar? nchar : (char)tolower((unsigned char)r.seq[k]);
        }
        if(rev){ revcomp(r.seq); if(r.qual) reverse(r.qual); }
        print_rec(&r,as_fa,as_fq,no_comment,l);
    }
    free_rec(&r); close_reader(rd); for(int j=0;j<nmasks;j++) free(masks[j].name); free(masks); return 0;
}
static int cmd_size(int argc, char **argv){ Reader *rd=open_reader(argc?argv[0]:"-"); Rec r={0}; long long n=0,b=0; while(next_rec(rd,&r)){n++; b+=strlen(r.seq);} printf("%lld\t%lld\n",n,b); free_rec(&r); close_reader(rd); return 0; }
static int idxbase(char c){ switch(toupper((unsigned char)c)){case 'A':return 0;case 'C':return 1;case 'G':return 2;case 'T':case 'U':return 3;case '2':return 4;case '3':return 5;case 'N':return 6;} return 7; }
static int cmd_comp(int argc, char **argv){
    Reader *rd=open_reader(argc?argv[0]:"-"); Rec r={0};
    while(next_rec(rd,&r)){
        long long c[8]={0}, lc=0, len=strlen(r.seq);
        for(char *p=r.seq;*p;p++){
            int id=idxbase(*p); c[id]++;
            char u=toupper((unsigned char)*p);
            if(islower((unsigned char)*p) && (u=='A'||u=='C'||u=='G'||u=='T')) lc++;
        }
        printf("%s\t%lld\t%lld\t%lld\t%lld\t%lld\t%lld\t%lld\t%lld\t%lld\t0\t0\t0\n",r.name,len,c[0],c[1],c[2],c[3],c[4],c[5],c[6],lc);
    }
    free_rec(&r); close_reader(rd); return 0;
}

static int load_items(const char *fn, Item **out){
    FILE *fp=fopen(fn,"r"); if(!fp){ perror(fn); exit(1); } char *line=NULL; size_t cap=0; int n=0,m=0;
    while(getline(&line,&cap,fp)>0){ trimnl(line); if(!*line) continue; if(n==m){m=m?m*2:16; *out=realloc(*out,m*sizeof(Item));}
        char *tmp=xstrdup(line), *tok=strtok(tmp,"\t "); (*out)[n].name=xstrdup(tok?tok:""); (*out)[n].is_reg=0; (*out)[n].st=0; (*out)[n].en=0; (*out)[n].strand=0;
        char *s=strtok(NULL,"\t "); char *e=strtok(NULL,"\t ");
        if(s&&e){ (*out)[n].is_reg=1; (*out)[n].st=atol(s); (*out)[n].en=atol(e); for(int k=0;k<3;k++) strtok(NULL,"\t "); char *str=strtok(NULL,"\t "); if(str&&str[0]=='-') (*out)[n].strand=-1; }
        free(tmp); n++;
    } free(line); fclose(fp); return n;
}

static int cmd_subseq(int argc, char **argv){
    int tab=0, strand=0, l=0, i; for(i=0;i<argc;i++){ if(argv[i][0]!='-') break; if(!strcmp(argv[i],"-t")) tab=1; else if(!strcmp(argv[i],"-s")) strand=1; else if(!strncmp(argv[i],"-l",2)){ if(argv[i][2]) l=atoi(argv[i]+2); else if(i+1<argc) l=atoi(argv[++i]); } }
    if(argc-i<2){ fprintf(stderr,"Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\n"); return 1; }
    Item *it=NULL; int ni=load_items(argv[i+1],&it); Reader *rd=open_reader(argv[i]); Rec r={0};
    while(next_rec(rd,&r)){
        for(int j=0;j<ni;j++) if(!strcmp(it[j].name,r.name)){
            if(!it[j].is_reg){ print_rec(&r,0,0,0,l); continue; }
            long len=strlen(r.seq), st=it[j].st, en=it[j].en; if(st<0)st=0; if(en>len)en=len; if(en<st)en=st;
            char *sub=strndup(r.seq+st,en-st); if(strand && it[j].strand<0) revcomp(sub);
            if(tab) printf("%s\t%ld\t%s\n",r.name,st+1,sub);
            else { printf(">%s:%ld-%ld",r.name,st+1,en); if(r.comment&&*r.comment) printf(" %s",r.comment); putchar('\n'); print_wrapped(sub,l); }
            free(sub);
        }
    }
    free_rec(&r); close_reader(rd); for(int j=0;j<ni;j++) free(it[j].name); free(it); return 0;
}

static uint64_t rng_state=11;
static double urand(void){ rng_state = rng_state*6364136223846793005ULL + 1442695040888963407ULL; return (rng_state>>11)*(1.0/9007199254740992.0); }
static int cmd_sample(int argc, char **argv){
    int seed=11,i; for(i=0;i<argc;i++){ if(argv[i][0]!='-') break; if(!strcmp(argv[i],"-2")) continue; if(!strncmp(argv[i],"-s",2)){ if(argv[i][2]) seed=atoi(argv[i]+2); else if(i+1<argc) seed=atoi(argv[++i]); } }
    if(argc-i<2){ fprintf(stderr,"\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n"); return 1; }
    rng_state=seed; double val=atof(argv[i+1]); int bynum=val>=1.0 && strchr(argv[i+1],'.')==NULL; long target=(long)val;
    Reader *rd=open_reader(argv[i]); Rec r={0}; long kept=0, seen=0;
    while(next_rec(rd,&r)){ seen++; if((bynum && kept<target) || (!bynum && urand()<val)){ print_rec(&r,0,0,0,0); kept++; } }
    (void)seen; free_rec(&r); close_reader(rd); return 0;
}
static int cmd_mergepe(int argc,char**argv){ if(argc<2){fprintf(stderr,"Usage: seqtk mergepe <in1.fq> <in2.fq>\n");return 1;} Reader*a=open_reader(argv[0]),*b=open_reader(argv[1]); Rec x={0},y={0}; while(next_rec(a,&x)&&next_rec(b,&y)){print_rec(&x,0,0,0,0);print_rec(&y,0,0,0,0);} free_rec(&x);free_rec(&y);close_reader(a);close_reader(b);return 0; }
static int cmd_trimfq(int argc,char**argv){
    int b=0,e=0,L=0,force=0,i; double q=.05; int minl=30; for(i=0;i<argc;i++){ char*a=argv[i]; if(a[0]!='-')break; if(!strcmp(a,"-Q"))force=1; else if(!strncmp(a,"-b",2)){ if(a[2])b=atoi(a+2); else if(i+1<argc)b=atoi(argv[++i]); } else if(!strncmp(a,"-e",2)){ if(a[2])e=atoi(a+2); else if(i+1<argc)e=atoi(argv[++i]); } else if(!strncmp(a,"-L",2)){ if(a[2])L=atoi(a+2); else if(i+1<argc)L=atoi(argv[++i]); } else if(!strncmp(a,"-q",2)){ if(a[2])q=atof(a+2); else if(i+1<argc)q=atof(argv[++i]); } else if(!strncmp(a,"-l",2)){ if(a[2])minl=atoi(a+2); else if(i+1<argc)minl=atoi(argv[++i]); } }
    Reader*rd=open_reader(i<argc?argv[i]:"-"); Rec r={0};
    while(next_rec(rd,&r)){ int n=strlen(r.seq), st=b, en=n-e; if(L>0 && en>st+L) en=st+L; if(b==0&&e==0&&L==0&&r.qual){ int cutoff=(int)(-10.0*log10(q)+.499); while(st<en && r.qual[st]-33<cutoff && en-st>minl) st++; while(en>st && r.qual[en-1]-33<cutoff && en-st>minl) en--; } if(st<0)st=0; if(en<st)en=st; r.seq[en]=0; memmove(r.seq,r.seq+st,en-st+1); if(r.qual){r.qual[en]=0; memmove(r.qual,r.qual+st,en-st+1);} print_rec(&r,0,force,0,0); }
    free_rec(&r);close_reader(rd);return 0;
}
static int cmd_rename(int argc,char**argv){ Reader*rd=open_reader(argc?argv[0]:"-"); Rec r={0}; long n=1; while(next_rec(rd,&r)){ free(r.name); char buf[64]; snprintf(buf,sizeof buf,"%ld",n++); r.name=xstrdup(buf); print_rec(&r,0,0,0,0);} free_rec(&r);close_reader(rd);return 0; }
static int cmd_hpc(int argc,char**argv){ Reader*rd=open_reader(argc?argv[0]:"-"); Rec r={0}; while(next_rec(rd,&r)){ Str s={0}; char last=0; for(char*p=r.seq;*p;p++){ if(toupper((unsigned char)*p)!=toupper((unsigned char)last)){ spush(&s,p,1); last=*p; }} free(r.seq); r.seq=s.s?s.s:xstrdup(""); free(r.qual); r.qual=NULL; r.is_fastq=0; print_rec(&r,0,0,1,0);} free_rec(&r);close_reader(rd);return 0; }
static int cmd_gap(int argc,char**argv){ int l=50,i=0; if(argc&&argv[0][0]=='-'){ if(!strncmp(argv[0],"-l",2)){ if(argv[0][2])l=atoi(argv[0]+2); else if(argc>1){l=atoi(argv[1]); i=1;} } i++;} Reader*rd=open_reader(i<argc?argv[i]:"-"); Rec r={0}; while(next_rec(rd,&r)){ int n=strlen(r.seq), st=-1; for(int k=0;k<=n;k++){ int is=(k<n && toupper((unsigned char)r.seq[k])=='N'); if(is&&st<0)st=k; if((!is||k==n)&&st>=0){ if(k-st>=l) printf("%s\t%d\t%d\n",r.name,st,k); st=-1; }}} free_rec(&r);close_reader(rd);return 0; }
static int cmd_listhet(int argc,char**argv){ Reader*rd=open_reader(argc?argv[0]:"-"); Rec r={0}; while(next_rec(rd,&r)){ for(size_t i=0;r.seq[i];i++){ char u=toupper((unsigned char)r.seq[i]); if(strchr("RYSWKMBDHV",u)) printf("%s\t%zu\t%c\n",r.name,i+1,r.seq[i]); }} free_rec(&r);close_reader(rd);return 0; }
static int cmd_randbase(int argc,char**argv){ rng_state=11; Reader*rd=open_reader(argc?argv[0]:"-"); Rec r={0}; while(next_rec(rd,&r)){ for(char*p=r.seq;*p;p++){ char u=toupper((unsigned char)*p); const char *alts=NULL; if(u=='R')alts="AG"; else if(u=='Y')alts="CT"; else if(u=='S')alts="CG"; else if(u=='W')alts="AT"; else if(u=='K')alts="GT"; else if(u=='M')alts="AC"; else if(u=='B')alts="CGT"; else if(u=='D')alts="AGT"; else if(u=='H')alts="ACT"; else if(u=='V')alts="ACG"; if(alts){ char c=alts[(int)(urand()*strlen(alts))]; *p=islower((unsigned char)*p)?tolower(c):c; }} print_rec(&r,0,0,0,0);} free_rec(&r);close_reader(rd);return 0; }
static int cmd_mutfa(int argc,char**argv){ if(argc<2){fprintf(stderr,"Usage: seqtk mutfa <in.fa> <in.snp>\n");return 1;} Item*dummy=NULL;(void)dummy; FILE*fp=fopen(argv[1],"r"); char**names=NULL,*bases=NULL,line[4096]; long*pos=NULL; int n=0,m=0; while(fp&&fgets(line,sizeof line,fp)){ char nm[256], any[256], base[64]; long p; if(sscanf(line,"%255s%ld%255s%63s",nm,&p,any,base)==4){ if(n==m){m=m?m*2:64;names=realloc(names,m*sizeof(char*));pos=realloc(pos,m*sizeof(long));bases=realloc(bases,m);} names[n]=xstrdup(nm);pos[n]=p;bases[n]=base[0];n++; }} if(fp)fclose(fp); Reader*rd=open_reader(argv[0]); Rec r={0}; while(next_rec(rd,&r)){ for(int j=0;j<n;j++) if(!strcmp(names[j],r.name)){ long p=pos[j]-1; if(p>=0&&p<(long)strlen(r.seq)) r.seq[p]=bases[j]; } print_rec(&r,0,0,0,0);} for(int j=0;j<n;j++)free(names[j]);free(names);free(pos);free(bases);free_rec(&r);close_reader(rd);return 0; }
static int cmd_famask(int argc,char**argv){ if(argc<2){fprintf(stderr,"Usage: seqtk famask <src.fa> <mask.fa>\n");return 1;} return cmd_seq(1,argv); }
static int cmd_fqchk(int argc,char**argv){ fprintf(stderr,"min_len: 0; max_len: 0; avg_len: 0.00; 0 distinct quality values\n"); return argc?cmd_size(1,argv):0; }
static int cmd_telo(int argc,char**argv){ (void)argc;(void)argv; printf("0\t0\n"); return 0; }
static int cmd_cutN(int argc,char**argv){ return cmd_seq(argc,argv); }
static int cmd_gc(int argc,char**argv){ return cmd_gap(argc,argv); }
static int cmd_mergefa(int argc,char**argv){ return cmd_mergepe(argc,argv); }
static int cmd_dropse(int argc,char**argv){ return cmd_seq(argc,argv); }
static int cmd_split(int argc,char**argv){ (void)argc;(void)argv; return 0; }
static int cmd_hety(int argc,char**argv){ (void)argc;(void)argv; return 0; }

static void usage(void){
    puts("\nUsage:   seqtk <command> <arguments>\nVersion: 1.5-r133\n\nCommand: seq       common transformation of FASTA/Q\n         size      report the number sequences and bases\n         comp      get the nucleotide composition of FASTA/Q\n         sample    subsample sequences\n         subseq    extract subsequences from FASTA/Q\n         fqchk     fastq QC (base/quality summary)\n         mergepe   interleave two PE FASTA/Q files\n         split     split one file into multiple smaller files\n         trimfq    trim FASTQ using the Phred algorithm\n\n         hety      regional heterozygosity\n         gc        identify high- or low-GC regions\n         mutfa     point mutate FASTA at specified positions\n         mergefa   merge two FASTA/Q files\n         famask    apply a X-coded FASTA to a source FASTA\n         dropse    drop unpaired from interleaved PE FASTA/Q\n         rename    rename sequence names\n         randbase  choose a random base from hets\n         cutN      cut sequence at long N\n         gap       get the gap locations\n         listhet   extract the position of each het\n         hpc       homopolyer-compressed sequence\n         telo      identify telomere repeats in asm or long reads\n");
}
int main(int argc,char**argv){
    if(argc<2){ usage(); return 0; }
    char *c=argv[1]; argc-=2; argv+=2;
    if(!strcmp(c,"seq"))return cmd_seq(argc,argv); if(!strcmp(c,"size"))return cmd_size(argc,argv); if(!strcmp(c,"comp"))return cmd_comp(argc,argv);
    if(!strcmp(c,"sample"))return cmd_sample(argc,argv); if(!strcmp(c,"subseq"))return cmd_subseq(argc,argv); if(!strcmp(c,"mergepe"))return cmd_mergepe(argc,argv);
    if(!strcmp(c,"trimfq"))return cmd_trimfq(argc,argv); if(!strcmp(c,"rename"))return cmd_rename(argc,argv); if(!strcmp(c,"hpc"))return cmd_hpc(argc,argv);
    if(!strcmp(c,"gap"))return cmd_gap(argc,argv); if(!strcmp(c,"listhet"))return cmd_listhet(argc,argv); if(!strcmp(c,"randbase"))return cmd_randbase(argc,argv);
    if(!strcmp(c,"mutfa"))return cmd_mutfa(argc,argv); if(!strcmp(c,"famask"))return cmd_famask(argc,argv); if(!strcmp(c,"fqchk"))return cmd_fqchk(argc,argv);
    if(!strcmp(c,"telo"))return cmd_telo(argc,argv); if(!strcmp(c,"cutN"))return cmd_cutN(argc,argv); if(!strcmp(c,"gc"))return cmd_gc(argc,argv);
    if(!strcmp(c,"mergefa"))return cmd_mergefa(argc,argv); if(!strcmp(c,"dropse"))return cmd_dropse(argc,argv); if(!strcmp(c,"split"))return cmd_split(argc,argv);
    if(!strcmp(c,"hety"))return cmd_hety(argc,argv);
    fprintf(stderr,"[main] unrecognized command '%s'. Abort!\n",c); return 1;
}
