#include <ctype.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct { unsigned char *p; size_t n, c; } Bytes;
typedef struct { char **v; int n, c; } Strs;

static void die(const char *s){ fprintf(stderr,"Error: %s\n",s); exit(1); }
static void *xrealloc(void *p,size_t n){ void *q=realloc(p,n); if(!q) die("out of memory"); return q; }
static char *xstrdup(const char *s){ size_t n=strlen(s)+1; char *r=xrealloc(0,n); memcpy(r,s,n); return r; }
static void bpush(Bytes *b,const void *p,size_t n){ if(b->n+n>b->c){ b->c=(b->n+n)*2+64; b->p=xrealloc(b->p,b->c);} memcpy(b->p+b->n,p,n); b->n+=n; }
static void bzero32(Bytes *b){ unsigned char z[32]={0}; bpush(b,z,32); }
static void wadd(Bytes *b,uint64_t x){ unsigned char w[32]={0}; for(int i=31;i>=0&&x;i--){w[i]=x&255; x>>=8;} bpush(b,w,32); }
static void shex(Bytes *b){ static const char h[]="0123456789abcdef"; for(size_t i=0;i<b->n;i++) printf("%c%c",h[b->p[i]>>4],h[b->p[i]&15]); printf("\n"); }
static int hexv(char c){ if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return -1; }
static const char *no0x(const char *s){ return (s[0]=='0'&&(s[1]=='x'||s[1]=='X'))?s+2:s; }
static Bytes hexbytes(const char *in,int allow0x){
  const char *s=allow0x?no0x(in):in; size_t l=strlen(s); if(l%2) die("Hex parsing error: Odd number of digits");
  Bytes b={0}; for(size_t i=0;i<l;i+=2){ int a=hexv(s[i]),c=hexv(s[i+1]); if(a<0||c<0){ char m[80]; snprintf(m,sizeof m,"Invalid character '%c' at position %zu", a<0?s[i]:s[i+1], a<0?i:i+1); die(m);} unsigned char v=(a<<4)|c; bpush(&b,&v,1);} return b;
}

/* Keccak-256, small public-domain style implementation for selectors/topics. */
static uint64_t rol64(uint64_t x,int s){ return (x<<s)|(x>>(64-s)); }
static void keccakf(uint64_t st[25]){
  static const uint64_t rc[24]={0x0000000000000001ULL,0x0000000000008082ULL,0x800000000000808aULL,0x8000000080008000ULL,0x000000000000808bULL,0x0000000080000001ULL,0x8000000080008081ULL,0x8000000000008009ULL,0x000000000000008aULL,0x0000000000000088ULL,0x0000000080008009ULL,0x000000008000000aULL,0x000000008000808bULL,0x800000000000008bULL,0x8000000000008089ULL,0x8000000000008003ULL,0x8000000000008002ULL,0x8000000000000080ULL,0x000000000000800aULL,0x800000008000000aULL,0x8000000080008081ULL,0x8000000000008080ULL,0x0000000080000001ULL,0x8000000080008008ULL};
  static const int r[25]={0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14};
  for(int ir=0;ir<24;ir++){ uint64_t c[5],d[5],b[25]; for(int x=0;x<5;x++) c[x]=st[x]^st[x+5]^st[x+10]^st[x+15]^st[x+20]; for(int x=0;x<5;x++) d[x]=c[(x+4)%5]^rol64(c[(x+1)%5],1); for(int i=0;i<25;i++) st[i]^=d[i%5]; for(int x=0;x<5;x++) for(int y=0;y<5;y++) b[y+5*((2*x+3*y)%5)]=rol64(st[x+5*y],r[x+5*y]); for(int x=0;x<5;x++) for(int y=0;y<5;y++) st[x+5*y]=b[x+5*y]^((~b[((x+1)%5)+5*y])&b[((x+2)%5)+5*y]); st[0]^=rc[ir]; }
}
static void keccak256(const unsigned char *in,size_t inlen,unsigned char out[32]){
  uint64_t st[25]={0}; unsigned char temp[136]; size_t rs=136;
  while(inlen>=rs){ for(size_t i=0;i<rs/8;i++){ uint64_t v=0; for(int j=0;j<8;j++) v|=(uint64_t)in[i*8+j]<<(8*j); st[i]^=v;} keccakf(st); in+=rs; inlen-=rs; }
  memset(temp,0,rs); memcpy(temp,in,inlen); temp[inlen]=1; temp[rs-1]|=0x80;
  for(size_t i=0;i<rs/8;i++){ uint64_t v=0; for(int j=0;j<8;j++) v|=(uint64_t)temp[i*8+j]<<(8*j); st[i]^=v;} keccakf(st);
  for(int i=0;i<32;i++) out[i]=(st[i/8]>>(8*(i%8)))&255;
}

typedef struct Type { char base[16]; int bits; int arr; } Type;
static Type ptype(const char *s){
  Type t; memset(&t,0,sizeof t); t.arr=-2; char buf[64]; strncpy(buf,s,63); buf[63]=0;
  char *br=strchr(buf,'['); if(br){ *br=0; t.arr = (br[1]==']') ? -1 : atoi(br+1); }
  if(!strncmp(buf,"uint",4)){ strcpy(t.base,"uint"); t.bits=atoi(buf+4); if(!t.bits)t.bits=256; }
  else if(!strncmp(buf,"int",3)){ strcpy(t.base,"int"); t.bits=atoi(buf+3); if(!t.bits)t.bits=256; }
  else if(!strncmp(buf,"bytes",5)&&buf[5]){ strcpy(t.base,"fixedbytes"); t.bits=atoi(buf+5); }
  else { strncpy(t.base,buf,15); }
  return t;
}
static int isdyn(Type t){ return !strcmp(t.base,"string")||!strcmp(t.base,"bytes")||t.arr==-1; }
static uint64_t readu(const unsigned char *p){ uint64_t x=0; for(int i=24;i<32;i++) x=(x<<8)|p[i]; return x; }
static void word_hex(const unsigned char *w,int start,int len){ for(int i=start;i<start+len;i++) printf("%02x",w[i]); }

static void enc_one(Bytes *out, Type t, const char *val, int lenient);
static void split_array(const char *s, Strs *a){
  const char *p=s; while(isspace(*p))p++; if(*p=='[')p++; char cur[1024]; int n=0,depth=0;
  for(;*p;p++){ if(*p=='[')depth++; if(*p==']'&&depth--<=0) break; if(*p==','&&depth==0){ cur[n]=0; while(n&&isspace(cur[n-1]))cur[--n]=0; char *q=cur; while(isspace(*q))q++; if(a->n==a->c){a->c=a->c*2+4;a->v=xrealloc(a->v,a->c*sizeof(char*));} a->v[a->n++]=xstrdup(q); n=0; } else if(n<(int)sizeof(cur)-1) cur[n++]=*p; }
  cur[n]=0; char *q=cur; while(isspace(*q))q++; while(n&&isspace(cur[n-1]))cur[--n]=0; if(*q){ if(a->n==a->c){a->c=a->c*2+4;a->v=xrealloc(a->v,a->c*sizeof(char*));} a->v[a->n++]=xstrdup(q); }
}
static void enc_static_word(Bytes *out, Type t, const char *val, int lenient){
  if(!strcmp(t.base,"bool")){ if(!strcmp(val,"true")||!strcmp(val,"1")) wadd(out,1); else if(!strcmp(val,"false")||!strcmp(val,"0")) wadd(out,0); else die("Invalid data"); }
  else if(!strcmp(t.base,"address")){ Bytes h=hexbytes(no0x(val),0); if(h.n!=20) die("Invalid data"); unsigned char w[32]={0}; memcpy(w+12,h.p,20); bpush(out,w,32); free(h.p); }
  else if(!strcmp(t.base,"uint")||!strcmp(t.base,"int")){
    unsigned char w[32]={0};
    if(lenient && val[0]!='-'){ unsigned long long x=strtoull(val,0,10); for(int i=31;i>=0&&x;i--){w[i]=x&255; x>>=8;} }
    else { Bytes h=hexbytes(val,0); if(h.n>32 || h.n!=32) die("Invalid data"); memcpy(w+32-h.n,h.p,h.n); free(h.p); }
    bpush(out,w,32);
  } else if(!strcmp(t.base,"fixedbytes")){ Bytes h=hexbytes(val,1); if((int)h.n!=t.bits) die("Invalid data"); unsigned char w[32]={0}; memcpy(w,h.p,h.n); bpush(out,w,32); free(h.p); }
  else die("Invalid data");
}
static void enc_dyn_payload(Bytes *out, Type t, const char *val, int lenient){
  if(!strcmp(t.base,"string")){ size_t l=strlen(val); wadd(out,l); bpush(out,val,l); while(out->n%32){ unsigned char z=0; bpush(out,&z,1);} }
  else if(!strcmp(t.base,"bytes")){ Bytes h=hexbytes(val,1); wadd(out,h.n); bpush(out,h.p,h.n); while(out->n%32){ unsigned char z=0; bpush(out,&z,1);} free(h.p); }
  else if(t.arr==-1){ Type e=t; e.arr=-2; Strs a={0}; split_array(val,&a); wadd(out,a.n); for(int i=0;i<a.n;i++) enc_one(out,e,a.v[i],lenient); }
}
static void enc_one(Bytes *out, Type t, const char *val, int lenient){
  if(t.arr>=0){ Type e=t; e.arr=-2; Strs a={0}; split_array(val,&a); if(a.n!=t.arr) die("Invalid data"); for(int i=0;i<a.n;i++) enc_one(out,e,a.v[i],lenient); return; }
  if(isdyn(t)) enc_dyn_payload(out,t,val,lenient); else enc_static_word(out,t,val,lenient);
}
static Bytes enc_params(char **types,char **vals,int n,int lenient){
  Bytes head={0},tail={0}; for(int i=0;i<n;i++){ Type t=ptype(types[i]); if(isdyn(t)){ wadd(&head,32*n+tail.n); enc_dyn_payload(&tail,t,vals[i],lenient); } else enc_one(&head,t,vals[i],lenient); } bpush(&head,tail.p,tail.n); free(tail.p); return head;
}

static void decode_one(Type t,const unsigned char *data,size_t n,size_t off);
static void decode_val(Type t,const unsigned char *data,size_t n,size_t off){
  if(off+32>n){ printf("<invalid>"); return; }
  const unsigned char *w=data+off;
  if(!strcmp(t.base,"bool")) printf("%s", readu(w)?"true":"false");
  else if(!strcmp(t.base,"address")) word_hex(w,12,20);
  else if(!strcmp(t.base,"uint")||!strcmp(t.base,"int")){ int i=0; while(i<32&&w[i]==0)i++; if(i==32) printf("0"); else word_hex(w,i,32-i); }
  else if(!strcmp(t.base,"fixedbytes")) word_hex(w,0,t.bits);
  else if(!strcmp(t.base,"string")||!strcmp(t.base,"bytes")){ size_t p=readu(w); if(p+32>n)return; size_t l=readu(data+p); if(!strcmp(t.base,"string")) printf("%.*s",(int)l,(const char*)data+p+32); else word_hex(data+p+32,0,l); }
  else if(t.arr==-1){ size_t p=readu(w); if(p+32>n)return; int cnt=(int)readu(data+p); Type e=t; e.arr=-2; printf("["); for(int i=0;i<cnt;i++){ if(i)printf(","); decode_one(e,data,n,p+32+32*i);} printf("]"); }
  else if(t.arr>=0){ Type e=t; e.arr=-2; printf("["); for(int i=0;i<t.arr;i++){ if(i)printf(","); decode_one(e,data,n,off+32*i);} printf("]"); }
}
static void decode_one(Type t,const unsigned char *data,size_t n,size_t off){ decode_val(t,data,n,off); }

typedef struct { char name[128]; char inputs[32][64]; char innames[32][64]; int nin; char outputs[32][64]; char outnames[32][64]; int nout; int is_event; int indexed[32]; int anonymous; } Abi;
static char *readfile(const char *p){ FILE *f=fopen(p,"rb"); if(!f) die("No such file or directory (os error 2)"); fseek(f,0,SEEK_END); long n=ftell(f); rewind(f); char *s=xrealloc(0,n+1); fread(s,1,n,f); s[n]=0; fclose(f); return s; }
static void json_get_string(const char *obj,const char *key,char *out,int cap){ char pat[64]; snprintf(pat,sizeof pat,"\"%s\"",key); char *p=strstr((char*)obj,pat); if(!p){*out=0;return;} p=strchr(p+strlen(pat),':'); if(!p)return; p=strchr(p,'"'); if(!p)return; p++; char *q=strchr(p,'"'); if(!q)return; int l=q-p; if(l>=cap)l=cap-1; memcpy(out,p,l); out[l]=0; }
static void json_get_late_name(const char *obj,char *out,int cap){
  const char *limit=strstr(obj,"\"outputs\""); if(!limit) limit=obj+strlen(obj);
  const char *p=obj,*last=0; while((p=strstr(p,"\"name\""))&&p<limit){ last=p; p+=6; }
  if(!last){ *out=0; return; }
  p=strchr(last,':'); if(!p)return; p=strchr(p,'"'); if(!p)return; p++; const char *q=strchr(p,'"'); if(!q)return; int l=q-p; if(l>=cap)l=cap-1; memcpy(out,p,l); out[l]=0;
}
static void parse_params(const char *sec, char arr[][64], char names[][64], int idx[], int *cnt){
  *cnt=0; const char *p=sec;
  while((p=strchr(p,'{'))){
    int d=0; const char *q=p; do{ if(*q=='{')d++; else if(*q=='}')d--; q++; }while(*q&&d);
    size_t n=q-p; char *obj=xrealloc(0,n+1); memcpy(obj,p,n); obj[n]=0;
    char ty[64]; json_get_string(obj,"type",ty,64);
    if(ty[0]){
      strncpy(arr[*cnt],ty,63); arr[*cnt][63]=0;
      if(names) json_get_string(obj,"name",names[*cnt],64);
      if(idx) idx[*cnt]=strstr(obj,"\"indexed\"")&&strstr(obj,"true");
      (*cnt)++;
    }
    free(obj); p=q;
  }
}
static char *array_section(char *obj,const char *key){
  char pat[64]; snprintf(pat,sizeof pat,"\"%s\"",key); char *p=strstr(obj,pat); if(!p)return 0; p=strchr(p,'['); if(!p)return 0;
  int d=0; char *q=p; do{ if(*q=='[')d++; else if(*q==']')d--; q++; }while(*q&&d);
  size_t n=q-p; char *r=xrealloc(0,n+1); memcpy(r,p,n); r[n]=0; return r;
}
static int json_bool_true(const char *obj,const char *key){
  char pat[64]; snprintf(pat,sizeof pat,"\"%s\"",key); char *p=strstr((char*)obj,pat); if(!p)return 0; p=strchr(p,':'); if(!p)return 0; while(*++p&&isspace(*p)); return !strncmp(p,"true",4);
}
static int load_abi(const char *path,Abi *list,int max){
  char *s=readfile(path); int n=0; char *p=s; while((p=strchr(p,'{'))&&n<max){ int depth=0; char *q=p; do{ if(*q=='{')depth++; else if(*q=='}')depth--; q++; }while(*q&&depth); size_t len=q-p; char *obj=xrealloc(0,len+1); memcpy(obj,p,len); obj[len]=0;
    int isfun=strstr(obj,"\"type\"")&&strstr(obj,"\"function\"");
    int isev=strstr(obj,"\"type\"")&&strstr(obj,"\"event\"");
    int isctor=strstr(obj,"\"type\"")&&strstr(obj,"\"constructor\"");
    if(isfun||isev||isctor){ Abi *a=&list[n]; memset(a,0,sizeof *a); a->is_event=isev; if(isctor) strcpy(a->name,"constructor"); else json_get_late_name(obj,a->name,128); a->anonymous=json_bool_true(obj,"anonymous"); char *in=array_section(obj,"inputs"); char *out=array_section(obj,"outputs"); if(in){ parse_params(in,a->inputs,a->innames,a->indexed,&a->nin); free(in); } if(out){ parse_params(out,a->outputs,a->outnames,0,&a->nout); free(out); } n++; }
    free(obj); p=q; }
  free(s); return n;
}
static void signature(Abi *a,char *buf,int event){ strcpy(buf,a->name); strcat(buf,"("); int first=1; for(int i=0;i<a->nin;i++){ if(!event || 1){ if(!first)strcat(buf,","); strcat(buf,a->inputs[i]); first=0; }} strcat(buf,")"); }
static Abi *find_abi(Abi *a,int n,const char *name,int event){
  int found=-1,c=0; for(int i=0;i<n;i++) if(a[i].is_event==event && !strcmp(a[i].name,name)){found=i;c++;} if(c>1){ fprintf(stderr,"Error: More than one function found for name `%s`, try providing the full signature\n",name); exit(1);} if(found<0) die("Invalid data"); return &a[found];
}

int main(int argc,char **argv){
  if(argc<2||!strcmp(argv[1],"--help")||!strcmp(argv[1],"-h")){ printf("ethabi-cli 18.0.0\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n"); return 0; }
  if(!strcmp(argv[1],"--version")||!strcmp(argv[1],"-V")){ printf("ethabi-cli 18.0.0\n"); return 0; }
  if(argc>=3&&!strcmp(argv[1],"encode")&&!strcmp(argv[2],"params")){
    int len=0,n=0; char *types[64],*vals[64]; for(int i=3;i<argc;i++){ if(!strcmp(argv[i],"-l")||!strcmp(argv[i],"--lenient")) len=1; else if(!strcmp(argv[i],"-v")&&i+2<argc){ types[n]=argv[++i]; vals[n]=argv[++i]; n++; } }
    Bytes b=enc_params(types,vals,n,len); shex(&b); return 0;
  }
  if(argc>=3&&!strcmp(argv[1],"decode")&&!strcmp(argv[2],"params")){
    char *types[64]; int nt=0; char *data=0; for(int i=3;i<argc;i++){ if(!strcmp(argv[i],"-t")&&i+1<argc) types[nt++]=argv[++i]; else data=argv[i]; } if(!data)die("Invalid data"); Bytes h=hexbytes(data,1); for(int i=0;i<nt;i++){ printf("%s ",types[i]); decode_one(ptype(types[i]),h.p,h.n,32*i); printf("\n"); } return 0;
  }
  if(argc>=4&&!strcmp(argv[1],"encode")&&!strcmp(argv[2],"function")){
    int len=0,np=0; char *params[64]; const char *abi=0,*fname=0; for(int i=3;i<argc;i++){ if(!strcmp(argv[i],"-l")||!strcmp(argv[i],"--lenient"))len=1; else if(!strcmp(argv[i],"-p")&&i+1<argc)params[np++]=argv[++i]; else if(!abi)abi=argv[i]; else if(!fname)fname=argv[i]; }
    Abi as[128]; int na=load_abi(abi,as,128); Abi *f=find_abi(as,na,fname,0); char *types[64]; for(int i=0;i<f->nin;i++)types[i]=f->inputs[i]; Bytes b=enc_params(types,params,f->nin,len); char sig[512]; signature(f,sig,0); unsigned char k[32]; keccak256((unsigned char*)sig,strlen(sig),k); Bytes out={0}; bpush(&out,k,4); bpush(&out,b.p,b.n); shex(&out); return 0;
  }
  if(argc>=6&&!strcmp(argv[1],"decode")&&!strcmp(argv[2],"function")){
    Abi as[128]; int na=load_abi(argv[3],as,128); Abi *f=find_abi(as,na,argv[4],0); Bytes h=hexbytes(argv[5],1); for(int i=0;i<f->nout;i++){ printf("%s ", f->outnames[i][0]?f->outnames[i]:f->outputs[i]); decode_one(ptype(f->outputs[i]),h.p,h.n,32*i); printf("\n"); } return 0;
  }
  if(argc>=6&&!strcmp(argv[1],"decode")&&!strcmp(argv[2],"log")){
    char *topics[64]; int nt=0; const char *abi=0,*ename=0,*data=0; for(int i=3;i<argc;i++){ if(!strcmp(argv[i],"-l")&&i+1<argc)topics[nt++]=argv[++i]; else if(!abi)abi=argv[i]; else if(!ename)ename=argv[i]; else data=argv[i]; }
    Abi as[128]; int na=load_abi(abi,as,128); Abi *e=find_abi(as,na,ename,1); Bytes d=hexbytes(data?data:"",1); int ti=e->anonymous?0:1, dio=0; for(int i=0;i<e->nin;i++){ printf("%s ", e->innames[i][0]?e->innames[i]:e->inputs[i]); if(e->indexed[i]){ if(ti>=nt) die("Invalid data"); Bytes th=hexbytes(topics[ti++],1); decode_one(ptype(e->inputs[i]),th.p,th.n,0); } else { decode_one(ptype(e->inputs[i]),d.p,d.n,32*dio++); } printf("\n"); } return 0;
  }
  fprintf(stderr,"error: Found argument '%s' which wasn't expected, or isn't valid in this context\n",argv[1]); return 1;
}
