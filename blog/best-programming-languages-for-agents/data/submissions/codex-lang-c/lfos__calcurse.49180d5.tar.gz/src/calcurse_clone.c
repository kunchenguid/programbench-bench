#define _GNU_SOURCE
#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct { int y,m,d; } Date;
typedef struct { Date date; int h,mi; } DateTime;
typedef struct {
  int is_apt, recur, note, priority, completed;
  Date start_date, end_date, until;
  int sh, sm, eh, em, interval;
  char rtype;
  int byday[64], nbyday, bymon[32], nbymon, bymday[80], nbymday;
  Date ex[128]; int nex;
  char *msg, notehash[64], *raw;
} Item;
typedef struct { Item *v; size_t n, cap; } Items;

static char datadir[PATH_MAX] = "";
static char calfile[PATH_MAX] = "";
static int input_fmt = 1;
static const char *output_fmt = "%m/%d/%y";
static const char *fmt_apt = " - %S -> %E\n\t%m\n";
static const char *fmt_event = " * %m\n";
static const char *fmt_todo = "%p. %m\n";
static const char *filter_type = NULL, *search_pat = NULL;
static int filter_prio = -999, filt_completed = 0, filt_uncompleted = 0;
static int limit_results = -1, printed_results = 0;

static char *xstrdup(const char *s){ char *r=strdup(s?s:""); if(!r){perror("strdup");exit(1);} return r; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1])) *--e=0; return s; }
static void add_item(Items *it, Item x){ if(it->n==it->cap){ it->cap=it->cap?it->cap*2:32; it->v=realloc(it->v,it->cap*sizeof(Item)); if(!it->v)exit(1);} it->v[it->n++]=x; }
static int leap(int y){ return (y%4==0&&y%100!=0)||y%400==0; }
static int mdays(int y,int m){ static int d[]={0,31,28,31,30,31,30,31,31,30,31,30,31}; return m==2?28+leap(y):d[m]; }
static time_t date_time(Date d,int h,int m){ struct tm tm={0}; tm.tm_year=d.y-1900; tm.tm_mon=d.m-1; tm.tm_mday=d.d; tm.tm_hour=h; tm.tm_min=m; tm.tm_isdst=-1; return mktime(&tm); }
static Date from_time(time_t t){ struct tm *tm=localtime(&t); Date d={tm->tm_year+1900,tm->tm_mon+1,tm->tm_mday}; return d; }
static Date add_days(Date d,int n){ return from_time(date_time(d,12,0)+(time_t)n*86400); }
static int date_cmp(Date a,Date b){ if(a.y!=b.y)return a.y-b.y; if(a.m!=b.m)return a.m-b.m; return a.d-b.d; }
static int date_eq(Date a,Date b){ return a.y==b.y&&a.m==b.m&&a.d==b.d; }
static int wday(Date d){ struct tm *tm; time_t t=date_time(d,12,0); tm=localtime(&t); return tm->tm_wday; }
static void date_out(Date d,char *buf,size_t n){ struct tm tm={0}; tm.tm_year=d.y-1900; tm.tm_mon=d.m-1; tm.tm_mday=d.d; strftime(buf,n,output_fmt,&tm); }
static char *fmt_date(Date d){ static char b[32]; snprintf(b,sizeof b,"%02d/%02d/%04d",d.m,d.d,d.y); return b; }

static int parse_date_num(const char *s, Date *d) {
  int a,b,c;
  if (sscanf(s,"%d-%d-%d",&a,&b,&c)==3) { d->y=a; d->m=b; d->d=c; return 1; }
  if (sscanf(s,"%d/%d/%d",&a,&b,&c)==3) {
    if (input_fmt==2) { d->d=a; d->m=b; d->y=c; }
    else if (input_fmt==3) { d->y=a; d->m=b; d->d=c; }
    else { d->m=a; d->d=b; d->y=c; }
    return 1;
  }
  return 0;
}
static int parse_date(const char *s, Date *d) {
  char low[64]; size_t i; for(i=0;i<sizeof(low)-1&&s[i]&&!isspace((unsigned char)s[i]);i++) low[i]=tolower((unsigned char)s[i]); low[i]=0;
  time_t now=time(NULL); Date today=from_time(now);
  if(!strcmp(low,"today")||!strcmp(low,"now")){*d=today;return 1;}
  if(!strcmp(low,"tomorrow")){*d=add_days(today,1);return 1;}
  if(!strcmp(low,"yesterday")){*d=add_days(today,-1);return 1;}
  const char *wd[]={"sun","mon","tue","wed","thu","fri","sat"};
  for(int k=0;k<7;k++) if(!strncmp(low,wd[k],3)){ int delta=(k-wday(today)+7)%7; *d=add_days(today,delta); return 1; }
  return parse_date_num(s,d);
}

/* Small SHA1 implementation, public-domain style. */
typedef struct { uint32_t h[5]; uint64_t len; unsigned char b[64]; size_t n; } SHA1C;
static uint32_t rol(uint32_t x,int n){ return (x<<n)|(x>>(32-n)); }
static void sha1_blk(SHA1C*c,const unsigned char*p){ uint32_t w[80],a,b,d,e,f,k,t,cc; for(int i=0;i<16;i++)w[i]=(uint32_t)p[4*i]<<24|(uint32_t)p[4*i+1]<<16|(uint32_t)p[4*i+2]<<8|p[4*i+3]; for(int i=16;i<80;i++)w[i]=rol(w[i-3]^w[i-8]^w[i-14]^w[i-16],1); a=c->h[0];b=c->h[1];cc=c->h[2];d=c->h[3];e=c->h[4]; for(int i=0;i<80;i++){ if(i<20){f=(b&cc)|((~b)&d);k=0x5a827999;}else if(i<40){f=b^cc^d;k=0x6ed9eba1;}else if(i<60){f=(b&cc)|(b&d)|(cc&d);k=0x8f1bbcdc;}else{f=b^cc^d;k=0xca62c1d6;} t=rol(a,5)+f+e+k+w[i]; e=d; d=cc; cc=rol(b,30); b=a; a=t;} c->h[0]+=a;c->h[1]+=b;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e; }
static void sha1_init(SHA1C*c){ c->h[0]=0x67452301;c->h[1]=0xefcdab89;c->h[2]=0x98badcfe;c->h[3]=0x10325476;c->h[4]=0xc3d2e1f0;c->len=0;c->n=0; }
static void sha1_up(SHA1C*c,const void*vp,size_t n){ const unsigned char*p=vp; c->len+=n*8; while(n){ size_t m=64-c->n; if(m>n)m=n; memcpy(c->b+c->n,p,m); c->n+=m;p+=m;n-=m; if(c->n==64){sha1_blk(c,c->b);c->n=0;} } }
static void sha1_fin(SHA1C*c,char out[41]){ uint64_t L=c->len; unsigned char z=0x80; sha1_up(c,&z,1); z=0; while(c->n!=56) sha1_up(c,&z,1); c->len=L; unsigned char l[8]; for(int i=7;i>=0;i--){l[i]=L&255;L>>=8;} sha1_up(c,l,8); for(int i=0;i<5;i++)sprintf(out+8*i,"%08x",c->h[i]); out[40]=0; }
static void sha1_hex(const char*s,char out[41]){ SHA1C c; sha1_init(&c); sha1_up(&c,s,strlen(s)); sha1_fin(&c,out); }

static char *unesc(const char *s, int sum) {
  char *r=malloc(strlen(s)*2+2), *o=r;
  for(;*s;s++) if(*s=='\\'&&s[1]){ s++; if(*s=='n'||*s=='N') *o++=sum?' ':'\n'; else *o++=*s; } else *o++=*s;
  *o=0; return r;
}
static void append(char **s,const char *fmt,...){ va_list ap; va_start(ap,fmt); char *buf=NULL; if(vasprintf(&buf,fmt,ap)<0) exit(1); va_end(ap); if(!*s)*s=xstrdup(""); *s=realloc(*s,strlen(*s)+strlen(buf)+1); strcat(*s,buf); free(buf); }
static void mkdirp(const char *p){ char tmp[PATH_MAX]; snprintf(tmp,sizeof tmp,"%s",p); for(char*q=tmp+1;*q;q++) if(*q=='/'){*q=0;mkdir(tmp,0777);*q='/';} mkdir(tmp,0777); }

static void load_files(Items *items) {
  char path[PATH_MAX], line[4096];
  snprintf(path,sizeof path,"%s/todo",datadir); FILE *f=fopen(path,"r");
  if(f){ while(fgets(line,sizeof line,f)){ char *s=trim(line); if(!*s)continue; Item it={0}; it.raw=xstrdup(s); if(s[0]=='['){ char *e=strchr(s,']'); if(e){ it.completed=(s[1]=='-'); it.priority=atoi(s+(it.completed?2:1)); it.msg=xstrdup(trim(e+1)); if(*it.msg=='>'){ strncpy(it.notehash,it.msg+1,40); it.note=1; it.msg=xstrdup(trim(it.msg+41)); } add_item(items,it); } } } fclose(f); }
  snprintf(path,sizeof path,"%s",calfile[0]?calfile:""); if(!*path) snprintf(path,sizeof path,"%s/apts",datadir);
  f=fopen(path,"r"); if(!f)return;
  while(fgets(line,sizeof line,f)){ char *s=trim(line); if(!*s)continue; Item it={0}; it.raw=xstrdup(s); char *p=s; if(!parse_date_num(p,&it.start_date)) continue; p+=10; if(strncmp(p," @ ",3)==0){ it.is_apt=1; p+=3; sscanf(p,"%d:%d",&it.sh,&it.sm); char *ar=strstr(p," -> "); if(!ar)continue; p=ar+4; parse_date_num(p,&it.end_date); p+=10; if(strncmp(p," @ ",3))continue; p+=3; sscanf(p,"%d:%d",&it.eh,&it.em); p+=5; } else { it.is_apt=0; it.end_date=it.start_date; if(strncmp(p," [",2)==0){ p=strchr(p,']'); if(p)p++; } }
    char *rb=strchr(p,'{'); if(rb){ it.recur=1; char *re=strchr(rb,'}'); if(re){ char inside[1024]; snprintf(inside,sizeof inside,"%.*s",(int)(re-rb-1),rb+1); char *tok=strtok(inside," "); if(tok){ it.interval=atoi(tok); it.rtype=tok[strlen(tok)-1]; } while((tok=strtok(NULL," "))){ if(!strcmp(tok,"->")){ tok=strtok(NULL," "); if(tok)parse_date_num(tok,&it.until); } else if(tok[0]=='!'){ if(it.nex<128)parse_date_num(tok+1,&it.ex[it.nex++]); } else if(tok[0]=='w') it.byday[it.nbyday++]=atoi(tok+1); else if(tok[0]=='m') it.bymon[it.nbymon++]=atoi(tok+1); else if(tok[0]=='d') it.bymday[it.nbymday++]=atoi(tok+1); } p=re+1; } }
    p=trim(p);
    if(*p=='>'){ strncpy(it.notehash,p+1,40); it.note=1; p+=41; }
    if(*p=='|') p++;
    it.msg=xstrdup(trim(p)); add_item(items,it);
  } fclose(f);
}
static int type_ok(Item *it){ if(!filter_type)return 1; if(strstr(filter_type,"cal")&&!it->msg)return 0; if(strstr(filter_type,"todo")&&!it->is_apt&&it->priority>=0)return 1; if(it->priority||it->completed)return strstr(filter_type,"todo")!=NULL; if(it->is_apt) return strstr(filter_type,"apt")||strstr(filter_type,"cal"); return strstr(filter_type,"event")||strstr(filter_type,"cal"); }
static int item_ok(Item *it){ if(!type_ok(it))return 0; if(search_pat){ regex_t r; if(regcomp(&r,search_pat,REG_EXTENDED|REG_NOSUB|REG_ICASE))return 0; int ok=!regexec(&r,it->msg,0,NULL,0); regfree(&r); if(!ok)return 0; } if(it->priority||it->completed){ if(filter_prio!=-999 && it->priority!=filter_prio)return 0; if(filt_completed&&!it->completed)return 0; if(filt_uncompleted&&it->completed)return 0; } return 1; }
static int exdate(Item *it,Date d){ for(int i=0;i<it->nex;i++)if(date_eq(it->ex[i],d))return 1; return 0; }
static int occurs(Item *it, Date day, Date *os) {
  Date st=it->start_date; int dur=(int)((date_time(it->end_date,it->eh,it->em)-date_time(st,it->sh,it->sm)+86399)/86400); if(!it->is_apt) dur=1;
  if(!it->recur){ if(date_cmp(day,st)>=0 && date_cmp(day,add_days(st,dur-1))<=0){*os=st;return 1;} return 0; }
  Date lim=it->until.y?it->until:day; if(date_cmp(day,lim)>0)return 0; int interval=it->interval?it->interval:1;
  for(Date d=st; date_cmp(d,day)<=0 && date_cmp(d,lim)<=0; ){
    int match=0; if(it->rtype=='D') match=1; else if(it->rtype=='W'){ if(it->nbyday){ for(int i=0;i<it->nbyday;i++) if(it->byday[i]==wday(d)) match=1; } else match=date_eq(d,st); } else if(it->rtype=='M'){ if(!it->nbymday&&!it->nbyday) match=(d.d==st.d); for(int i=0;i<it->nbymday;i++){ int md=it->bymday[i]>0?it->bymday[i]:mdays(d.y,d.m)+it->bymday[i]+1; if(d.d==md)match=1; } for(int i=0;i<it->nbyday;i++) if(abs(it->byday[i])%10==wday(d)) match=1; } else if(it->rtype=='Y'){ match=1; if(it->nbymon){match=0;for(int i=0;i<it->nbymon;i++)if(d.m==it->bymon[i])match=1;} if(it->nbymday){int m=0;for(int i=0;i<it->nbymday;i++)if(d.d==it->bymday[i])m=1;match&=m;} if(it->nbyday){int m=0;for(int i=0;i<it->nbyday;i++)if(abs(it->byday[i])%10==wday(d))m=1;match&=m;} }
    if(match&&!exdate(it,d)){ Date end=add_days(d,dur-1); if(date_cmp(day,d)>=0&&date_cmp(day,end)<=0){*os=d;return 1;} }
    d=add_days(d,1);
    if(it->rtype=='D' && interval>1) d=add_days(d,interval-1);
  } return 0;
}
static void out_item_fmt(Item*it,const char*fmt,Date day,Date os){
  for(const char*p=fmt;*p;p++){ if(*p!='%'){ if(*p=='\\'&&p[1]=='n'){putchar('\n');p++;} else if(*p=='\\'&&p[1]=='t'){putchar('\t');p++;} else putchar(*p); continue;} p++; char tb[16]; switch(*p){case 'm': fputs(it->msg,stdout); break; case 'p': printf("%d",it->priority); break; case 'S': if(!date_eq(day,os)) printf("..:.."); else printf("%02d:%02d",it->sh,it->sm); break; case 'E': { Date ed=it->end_date; if(it->recur){ int dd=(int)((date_time(it->end_date,it->eh,it->em)-date_time(it->start_date,it->sh,it->sm))/86400); ed=add_days(os,dd); } if(!date_eq(day,ed)) printf("..:.."); else printf("%02d:%02d",it->eh,it->em); break;} case 's': printf("%ld",(long)date_time(os,it->sh,it->sm)); break; case 'e': printf("%ld",(long)date_time(it->end_date,it->eh,it->em)); break; case 'n': if(it->note)fputs(it->notehash,stdout); break; default: if(*p=='%')putchar('%'); else {putchar('%'); putchar(*p);} } (void)tb; }
}
static void query(Items*items,Date from,Date to,int only_cal,int only_todo){
  if(!only_cal){ int any=0; for(size_t i=0;i<items->n;i++)if((items->v[i].priority||items->v[i].completed)&&item_ok(&items->v[i])){ if(!any){ printf(items->v[i].completed?"completed tasks:\n":"to do:\n"); any=1; } out_item_fmt(&items->v[i],fmt_todo,from,from); if(limit_results>=0&&++printed_results>=limit_results)return; } if(any)putchar('\n'); }
  if(only_todo)return;
  for(Date d=from; date_cmp(d,to)<=0; d=add_days(d,1)){ int any=0; for(size_t i=0;i<items->n;i++){ Item*it=&items->v[i]; if((it->priority||it->completed)||!item_ok(it))continue; Date os; if(occurs(it,d,&os)){ if(!any){ char b[128]; date_out(d,b,sizeof b); printf("%s:\n",b); any=1; } out_item_fmt(it,it->is_apt?fmt_apt:fmt_event,d,os); if(limit_results>=0&&++printed_results>=limit_results)return; } } if(any)putchar('\n'); }
}

static char *propval(char *line){ char *c=strchr(line,':'); return c?c+1:NULL; }
static int propis(char *line,const char *name){ size_t n=strlen(name); return !strncmp(line,name,n) && (line[n]==':'||line[n]==';'); }
static Date parse_ical_date(const char*s){ Date d={0}; if(strlen(s)>=8){ char b[5]; memcpy(b,s,4);b[4]=0;d.y=atoi(b);memcpy(b,s+4,2);b[2]=0;d.m=atoi(b);memcpy(b,s+6,2);d.d=atoi(b);} return d; }
static void parse_ical_time(const char*s,Date*d,int*h,int*m){ *d=parse_ical_date(s); if(strlen(s)>=13){ char b[3]; memcpy(b,s+9,2);b[2]=0;*h=atoi(b);memcpy(b,s+11,2);b[2]=0;*m=atoi(b);} }
static int parse_dur(const char*s){ int days=0,h=0,m=0,sec=0; const char*p=s; while(*p){ if(isdigit((unsigned char)*p)){ int v=strtol(p,(char**)&p,10); if(*p=='D')days=v; else if(*p=='H')h=v; else if(*p=='M')m=v; else if(*p=='S')sec=v; } else p++; } return days*1440+h*60+m+(sec?1:0); }
static void write_note(Item*it,const char*desc,const char*loc,const char*com,int multi){
  char *note=NULL; if(desc) append(&note,"%s\n",desc); if(loc||com||multi){ append(&note,"-- \n"); if(loc) append(&note,"Location: %s\n",loc); if(com){ char *c=xstrdup(com); append(&note,"Comment: "); for(char*p=c;*p;p++){ if(*p=='\n') append(&note,"\n    "); else { char z[2]={*p,0}; append(&note,"%s",z);} } append(&note,"\n"); free(c);} if(multi) append(&note,"Import: multi-day event changed to one-day event\n"); }
  sha1_hex(note,it->notehash); it->note=1; char nd[PATH_MAX], path[PATH_MAX]; snprintf(nd,sizeof nd,"%s/notes",datadir); mkdirp(nd); snprintf(path,sizeof path,"%s/%s",nd,it->notehash); FILE*f=fopen(path,"w"); if(f){fputs(note,f);fclose(f);} free(note);
}
static void import_ical(const char*file){
  FILE*f=fopen(file,"r"); if(!f){perror(file);exit(1);} char **lines=NULL; size_t n=0,cap=0; char buf[4096];
  while(fgets(buf,sizeof buf,f)){ buf[strcspn(buf,"\r\n")]=0; if((buf[0]==' '||buf[0]=='\t')&&n){ char *old=lines[n-1]; lines[n-1]=realloc(old,strlen(old)+strlen(buf)+1); strcat(lines[n-1],buf+1); } else { if(n==cap){cap=cap?cap*2:128;lines=realloc(lines,cap*sizeof(char*));} lines[n++]=xstrdup(buf); } } fclose(f);
  Items out={0}; for(size_t i=0;i<n;i++){ int todo=0, ev=0; if(!strcmp(lines[i],"BEGIN:VEVENT"))ev=1; else if(!strcmp(lines[i],"BEGIN:VTODO"))todo=1; else continue; Date st={0},en={0}; int sh=0,sm=0,eh=0,em=0,dur=-1,allday=0,prio=1,completed=0; char *summary=NULL,*desc=NULL,*loc=NULL,*com=NULL,*rr=NULL,*ex=NULL; size_t j=i+1; for(;j<n;j++){ if((ev&&!strcmp(lines[j],"END:VEVENT"))||(todo&&!strcmp(lines[j],"END:VTODO")))break; char *v=propval(lines[j]); if(!v)continue; if(propis(lines[j],"SUMMARY")) summary=unesc(v,1); else if(propis(lines[j],"DESCRIPTION")) desc=unesc(v,0); else if(propis(lines[j],"LOCATION")) loc=unesc(v,0); else if(propis(lines[j],"COMMENT")) com=unesc(v,0); else if(propis(lines[j],"PRIORITY")) prio=atoi(v); else if(propis(lines[j],"STATUS")&&!strcmp(v,"COMPLETED")) completed=1; else if(propis(lines[j],"DTSTART")){ allday=strstr(lines[j],"VALUE=DATE")!=NULL; if(allday)st=parse_ical_date(v); else parse_ical_time(v,&st,&sh,&sm); } else if(propis(lines[j],"DTEND")){ if(strstr(lines[j],"VALUE=DATE")) en=parse_ical_date(v); else parse_ical_time(v,&en,&eh,&em); } else if(propis(lines[j],"DURATION")) dur=parse_dur(v); else if(propis(lines[j],"RRULE")) rr=xstrdup(v); else if(propis(lines[j],"EXDATE")) ex=xstrdup(v); }
    i=j; if(!summary)summary=xstrdup(""); if(todo){ if(prio<1||prio>9) prio=1; Item it={0}; it.priority=completed?0:prio; it.completed=completed; it.msg=summary; if(desc||loc||com)write_note(&it,desc,loc,com,0); add_item(&out,it); continue; }
    if(!st.y)continue; Item it={0}; it.msg=summary; it.start_date=st; it.sh=sh; it.sm=sm;
    if(allday){ it.is_apt=0; it.end_date=st; int days=1; if(en.y) days=(int)((date_time(en,12,0)-date_time(st,12,0))/86400); else if(dur>0) days=(dur+1439)/1440; if(days>1){ it.recur=1; it.interval=1; it.rtype='D'; it.until=add_days(st,days-1); if(desc||loc||com)write_note(&it,desc,loc,com,1); } else if(desc||loc||com)write_note(&it,desc,loc,com,0); }
    else { it.is_apt=1; if(en.y){ it.end_date=en; it.eh=eh; it.em=em; } else { time_t et=date_time(st,sh,sm)+(dur<0?0:dur)*60; it.end_date=from_time(et); struct tm *tm=localtime(&et); it.eh=tm->tm_hour; it.em=tm->tm_min; } if(desc||loc||com)write_note(&it,desc,loc,com,0); }
    if(rr){ it.recur=1; it.interval=1; char *r=xstrdup(rr), *save1=NULL; for(char*t=strtok_r(r,";",&save1);t;t=strtok_r(NULL,";",&save1)){ char *eq=strchr(t,'='); if(!eq)continue; *eq++=0; if(!strcmp(t,"FREQ")) it.rtype=!strcmp(eq,"DAILY")?'D':!strcmp(eq,"WEEKLY")?'W':!strcmp(eq,"MONTHLY")?'M':!strcmp(eq,"YEARLY")?'Y':'D'; else if(!strcmp(t,"INTERVAL")) it.interval=atoi(eq); else if(!strcmp(t,"UNTIL")) it.until=parse_ical_date(eq); else if(!strcmp(t,"COUNT")) { } else if(!strcmp(t,"BYMONTH")) { char *save2=NULL; for(char*u=strtok_r(eq,",",&save2);u;u=strtok_r(NULL,",",&save2)) it.bymon[it.nbymon++]=atoi(u); } else if(!strcmp(t,"BYMONTHDAY")) { char *save2=NULL; for(char*u=strtok_r(eq,",",&save2);u;u=strtok_r(NULL,",",&save2)) it.bymday[it.nbymday++]=atoi(u); } else if(!strcmp(t,"BYDAY")){ char *save2=NULL; for(char*u=strtok_r(eq,",",&save2);u;u=strtok_r(NULL,",",&save2)){ int off=0; char *p=u; if(*p=='+'||*p=='-'||isdigit((unsigned char)*p)) off=strtol(p,&p,10); const char*ds[]={"SU","MO","TU","WE","TH","FR","SA"}; for(int k=0;k<7;k++)if(!strncmp(p,ds[k],2))it.byday[it.nbyday++]=off*10+k; }} } free(r); if(ex){ char *e=xstrdup(ex), *save3=NULL; for(char*u=strtok_r(e,",",&save3);u;u=strtok_r(NULL,",",&save3)) if(it.nex<128)it.ex[it.nex++]=parse_ical_date(u); free(e);} }
    add_item(&out,it);
  }
  mkdirp(datadir); char path[PATH_MAX]; snprintf(path,sizeof path,"%s/apts",datadir); FILE*af=fopen(path,"a"); snprintf(path,sizeof path,"%s/todo",datadir); FILE*tf=fopen(path,"a");
  for(size_t k=0;k<out.n;k++){ Item*it=&out.v[k]; FILE*of=(it->priority||it->completed)?tf:af; if(!of)continue; if(of==tf){ fprintf(of,"[%s%d]%s%s%s%s\n",it->completed?"-":"",it->priority,it->note?">":"",it->note?it->notehash:"",it->note?" ":"",it->msg); } else if(it->is_apt){ fprintf(of,"%s @ %02d:%02d -> %s @ %02d:%02d",fmt_date(it->start_date),it->sh,it->sm,fmt_date(it->end_date),it->eh,it->em); if(it->recur){ fprintf(of," {%d%c",it->interval,it->rtype); if(it->until.y)fprintf(of," -> %s",fmt_date(it->until)); for(int x=0;x<it->nex;x++)fprintf(of," !%s",fmt_date(it->ex[x])); for(int x=0;x<it->nbymday;x++)fprintf(of," d%d",it->bymday[x]); for(int x=0;x<it->nbyday;x++)fprintf(of," w%d",it->byday[x]); for(int x=0;x<it->nbymon;x++)fprintf(of," m%d",it->bymon[x]); fprintf(of,"}"); } fprintf(of,"%s%s%s |%s\n",it->note?" >":"",it->note?it->notehash:"",it->note?"":"",it->msg); } else { fprintf(of,"%s [1]",fmt_date(it->start_date)); if(it->recur){ fprintf(of," {%d%c",it->interval,it->rtype); if(it->until.y)fprintf(of," -> %s",fmt_date(it->until)); fprintf(of,"}"); } fprintf(of," %s%s%s%s\n",it->note?">":"",it->note?it->notehash:"",it->note?" ":"",it->msg); } }
  if(af)fclose(af); if(tf)fclose(tf);
}

static void help(void){ puts("Usage:\ncalcurse [-D <directory>] [-C <directory>] [-c <calendar file>]\ncalcurse -Q [--from <date>] [--to <date>] [--days <number>]\ncalcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]\ncalcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon\n\nOperations in command line mode:\n  -Q, --query   Print items in a given query range\n  -G, --grep    Grep items from the data files\n  -P, --purge   Read items and write them back\nQuery short forms:\n-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>\n\nMiscellaneous:\n  -h, --help              Show this help text\n  -v, --version           Show version information"); }
static void export_ical(Items*items){ puts("BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN"); for(size_t i=0;i<items->n;i++){ Item*it=&items->v[i]; if(it->priority||it->completed){ printf("BEGIN:VTODO\nPRIORITY:%d\nSUMMARY:%s\nEND:VTODO\n",it->priority,it->msg); } else if(it->is_apt){ printf("BEGIN:VEVENT\nDTSTART:%04d%02d%02dT%02d%02d00\nSUMMARY:%s\nEND:VEVENT\n",it->start_date.y,it->start_date.m,it->start_date.d,it->sh,it->sm,it->msg); } else printf("BEGIN:VEVENT\nDTSTART;VALUE=DATE:%04d%02d%02d\nSUMMARY:%s\nEND:VEVENT\n",it->start_date.y,it->start_date.m,it->start_date.d,it->msg); } puts("END:VCALENDAR"); }
static void defaults(void){ const char*h=getenv("HOME"); if(!h)h="/tmp"; snprintf(datadir,sizeof datadir,"%s/.local/share/calcurse",h); }
int main(int argc,char**argv){ defaults(); int op=0, only_cal=0, only_todo=0; Date from=from_time(time(NULL)), to=from; char *import_file=NULL; int days_set=0, days=1;
  enum{OPT_FROM=1000,OPT_TO,OPT_DAYS,OPT_STATUS,OPT_DAEMON,OPT_IN,OPT_OUT,OPT_FTYPE,OPT_FPAT,OPT_FPRIO,OPT_FCOMP,OPT_FUNCOMP,OPT_FMTAPT,OPT_FMTEVENT,OPT_FMTTODO};
  static struct option lo[]={{"help",0,0,'h'},{"version",0,0,'v'},{"datadir",1,0,'D'},{"confdir",1,0,'C'},{"calendar",1,0,'c'},{"query",0,0,'Q'},{"grep",0,0,'G'},{"purge",0,0,'P'},{"gc",0,0,'g'},{"import",1,0,'i'},{"export",2,0,'x'},{"todo",2,0,'t'},{"appointment",0,0,'a'},{"day",1,0,'d'},{"range",2,0,'r'},{"startday",2,0,'s'},{"search",1,0,'S'},{"limit",1,0,'l'},{"from",1,0,OPT_FROM},{"to",1,0,OPT_TO},{"days",1,0,OPT_DAYS},{"status",0,0,OPT_STATUS},{"daemon",0,0,OPT_DAEMON},{"input-datefmt",1,0,OPT_IN},{"output-datefmt",1,0,OPT_OUT},{"filter-type",1,0,OPT_FTYPE},{"filter-pattern",1,0,OPT_FPAT},{"filter-priority",1,0,OPT_FPRIO},{"filter-completed",0,0,OPT_FCOMP},{"filter-uncompleted",0,0,OPT_FUNCOMP},{"format-apt",1,0,OPT_FMTAPT},{"format-recur-apt",1,0,OPT_FMTAPT},{"format-event",1,0,OPT_FMTEVENT},{"format-recur-event",1,0,OPT_FMTEVENT},{"format-todo",1,0,OPT_FMTTODO},{0,0,0,0}};
  int c; while((c=getopt_long(argc,argv,"hvD:C:c:QGPgi:x::t::ad:r::s::S:l:n",lo,NULL))!=-1){ switch(c){case 'h':help();return 0;case 'v':puts("calcurse 4.8.2 -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions.");return 0;case 'D':snprintf(datadir,sizeof datadir,"%s",optarg);break;case 'c':snprintf(calfile,sizeof calfile,"%s",optarg);break;case 'Q':op='Q';break;case 'G':op='G';break;case 'P':op='P';break;case 'g':return 0;case 'i':op='i';import_file=optarg;break;case 'x':op='x';break;case 'a':op='Q';only_cal=1;filter_type="cal";break;case 't':op='Q';only_todo=1;filter_type="todo"; if(optarg){int p=atoi(optarg); if(p==0){filt_completed=1;filter_prio=0;}else{filter_prio=p;filt_uncompleted=1;}}break;case 'd':op='Q';only_cal=1;filter_type="cal"; if((optarg[0]=='-'||isdigit((unsigned char)optarg[0]))&&strspn(optarg+(optarg[0]=='-'),"0123456789")==strlen(optarg+(optarg[0]=='-'))){days=atoi(optarg);days_set=1;} else {parse_date(optarg,&from);to=from;} break;case 'r':op='Q';only_cal=1;filter_type="cal";days=optarg?atoi(optarg):1;days_set=1;break;case 's':op='Q';only_cal=1;filter_type="cal"; if(optarg)parse_date(optarg,&from);to=from;break;case 'n':op='Q';only_cal=1;filter_type="apt";days=1;days_set=1;limit_results=1;break;case 'S':search_pat=optarg;break;case 'l':limit_results=atoi(optarg);break;case OPT_FROM:parse_date(optarg,&from);to=from;break;case OPT_TO:parse_date(optarg,&to);break;case OPT_DAYS:days=atoi(optarg);days_set=1;break;case OPT_STATUS:puts("calcurse is not running");return 0;case OPT_DAEMON:return 0;case OPT_IN:input_fmt=atoi(optarg);break;case OPT_OUT:output_fmt=optarg;break;case OPT_FTYPE:filter_type=optarg;break;case OPT_FPAT:search_pat=optarg;break;case OPT_FPRIO:filter_prio=atoi(optarg);break;case OPT_FCOMP:filt_completed=1;break;case OPT_FUNCOMP:filt_uncompleted=1;break;case OPT_FMTAPT:fmt_apt=optarg;break;case OPT_FMTEVENT:fmt_event=optarg;break;case OPT_FMTTODO:fmt_todo=optarg;break;default:break;} }
  if(days_set){ if(days>=0) to=add_days(from,days-1); else { to=from; from=add_days(from,days+1); } }
  if(op=='i'){ import_ical(import_file); return 0; }
  Items items={0}; load_files(&items);
  if(op=='G'||op=='P'){ for(size_t i=0;i<items.n;i++) if(item_ok(&items.v[i])) printf("%s\n",items.v[i].raw); return 0; }
  if(op=='x'){ export_ical(&items); return 0; }
  if(op=='Q') { query(&items,from,to,only_cal,only_todo); return 0; }
  help(); return 0;
}
