#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char *path;
    double score;
    int64_t time;
} Entry;

typedef struct {
    Entry *v;
    size_t n, cap;
} DB;

static const char *VERSION = "zoxide 0.9.9";

static void die_mem(void) { fprintf(stderr, "zoxide: out of memory\n"); exit(1); }

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) die_mem();
    return p;
}

static void db_free(DB *db) {
    for (size_t i = 0; i < db->n; i++) free(db->v[i].path);
    free(db->v);
}

static void db_push(DB *db, const char *path, double score, int64_t t) {
    if (db->n == db->cap) {
        db->cap = db->cap ? db->cap * 2 : 16;
        db->v = realloc(db->v, db->cap * sizeof(Entry));
        if (!db->v) die_mem();
    }
    db->v[db->n].path = xstrdup(path);
    db->v[db->n].score = score;
    db->v[db->n].time = t;
    db->n++;
}

static int is_dir(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static void mkdir_p(const char *path) {
    char *tmp = xstrdup(path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    mkdir(tmp, 0777);
    free(tmp);
}

static char *data_dir(void) {
    const char *zo = getenv("_ZO_DATA_DIR");
    if (zo && *zo) return xstrdup(zo);
    const char *xdg = getenv("XDG_DATA_HOME");
    if (xdg && *xdg) {
        char *r;
        if (asprintf(&r, "%s/zoxide", xdg) < 0) die_mem();
        return r;
    }
    const char *home = getenv("HOME");
    if (!home) home = ".";
    char *r;
    if (asprintf(&r, "%s/.local/share/zoxide", home) < 0) die_mem();
    return r;
}

static char *db_path(void) {
    char *d = data_dir();
    char *r;
    if (asprintf(&r, "%s/db.zo", d) < 0) die_mem();
    free(d);
    return r;
}

static uint32_t rd32(FILE *f, int *ok) {
    unsigned char b[4];
    if (fread(b, 1, 4, f) != 4) { *ok = 0; return 0; }
    return (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
}

static uint64_t rd64(FILE *f, int *ok) {
    unsigned char b[8];
    if (fread(b, 1, 8, f) != 8) { *ok = 0; return 0; }
    uint64_t v = 0;
    for (int i = 7; i >= 0; i--) v = (v << 8) | b[i];
    return v;
}

static void wr32(FILE *f, uint32_t v) {
    unsigned char b[4] = {v, v >> 8, v >> 16, v >> 24};
    fwrite(b, 1, 4, f);
}

static void wr64(FILE *f, uint64_t v) {
    unsigned char b[8];
    for (int i = 0; i < 8; i++) { b[i] = (unsigned char)(v & 255); v >>= 8; }
    fwrite(b, 1, 8, f);
}

static DB db_load(void) {
    DB db = {0};
    char *p = db_path();
    FILE *f = fopen(p, "rb");
    free(p);
    if (!f) return db;
    int ok = 1;
    uint32_t ver = rd32(f, &ok);
    uint64_t n = rd64(f, &ok);
    if (!ok || ver != 3 || n > 1000000) { fclose(f); return db; }
    for (uint64_t i = 0; i < n; i++) {
        uint64_t len = rd64(f, &ok);
        if (!ok || len > 100000) break;
        char *s = calloc(1, (size_t)len + 1);
        if (!s) die_mem();
        if (fread(s, 1, (size_t)len, f) != len) { free(s); break; }
        union { uint64_t u; double d; } cv;
        cv.u = rd64(f, &ok);
        int64_t t = (int64_t)rd64(f, &ok);
        if (!ok) { free(s); break; }
        db_push(&db, s, cv.d, t);
        free(s);
    }
    fclose(f);
    return db;
}

static int db_save(DB *db) {
    char *dir = data_dir();
    mkdir_p(dir);
    char *path;
    if (asprintf(&path, "%s/db.zo", dir) < 0) die_mem();
    free(dir);
    FILE *f = fopen(path, "wb");
    if (!f) { fprintf(stderr, "zoxide: %s: %s\n", path, strerror(errno)); free(path); return 1; }
    wr32(f, 3);
    wr64(f, db->n);
    for (size_t i = 0; i < db->n; i++) {
        size_t len = strlen(db->v[i].path);
        union { uint64_t u; double d; } cv;
        cv.d = db->v[i].score;
        wr64(f, len);
        fwrite(db->v[i].path, 1, len, f);
        wr64(f, cv.u);
        wr64(f, (uint64_t)db->v[i].time);
    }
    fclose(f);
    free(path);
    return 0;
}

static int find_entry(DB *db, const char *path) {
    for (size_t i = 0; i < db->n; i++) if (strcmp(db->v[i].path, path) == 0) return (int)i;
    return -1;
}

static double frecency(const Entry *e) {
    time_t now = time(NULL);
    double age = difftime(now, (time_t)e->time);
    double mult = 1.0;
    if (age < 3600) mult = 4.0;
    else if (age < 86400) mult = 2.0;
    else if (age < 604800) mult = 0.5;
    else mult = 0.25;
    return e->score * mult;
}

static char *canon_path(const char *in) {
    char *out = NULL;
    if (getenv("_ZO_RESOLVE_SYMLINKS") && strcmp(getenv("_ZO_RESOLVE_SYMLINKS"), "1") == 0) {
        out = realpath(in, NULL);
        if (out) return out;
    }
    if (in[0] == '/') return xstrdup(in);
    char cwd[4096];
    if (!getcwd(cwd, sizeof(cwd))) return xstrdup(in);
    if (asprintf(&out, "%s/%s", cwd, in) < 0) die_mem();
    return out;
}

static int excluded(const char *path) {
    const char *ex = getenv("_ZO_EXCLUDE_DIRS");
    char *owned = NULL;
    if (!ex) {
        const char *home = getenv("HOME");
        if (!home || !*home) return 0;
        owned = xstrdup(home);
        ex = owned;
    }
    char *list = xstrdup(ex);
    int ret = 0;
    for (char *tok = strtok(list, ":"); tok; tok = strtok(NULL, ":")) {
        if (*tok && (strcmp(path, tok) == 0 || fnmatch(tok, path, 0) == 0)) { ret = 1; break; }
    }
    free(list);
    free(owned);
    return ret;
}

static int subseq_ci(const char *s, const char *q) {
    if (!*q) return 1;
    for (; *s && *q; s++) {
        char a = *s, b = *q;
        if (a >= 'A' && a <= 'Z') a += 32;
        if (b >= 'A' && b <= 'Z') b += 32;
        if (a == b) q++;
    }
    return *q == 0;
}

static int contains_ci(const char *s, const char *q) {
    size_t n = strlen(q);
    if (n == 0) return 1;
    for (; *s; s++) if (strncasecmp(s, q, n) == 0) return 1;
    return 0;
}

static int prefix_component(const char *path, const char *q) {
    size_t n = strlen(q);
    char *bare = xstrdup(q);
    if (n && bare[n - 1] == '/') bare[n - 1] = 0;
    n = strlen(bare);
    const char *p = path;
    int ok = 0;
    while (*p) {
        while (*p == '/') p++;
        if (strncasecmp(p, bare, n) == 0) { ok = 1; break; }
        p = strchr(p, '/');
        if (!p) break;
    }
    free(bare);
    return ok;
}

static const char *basename_c(const char *path) {
    const char *p = strrchr(path, '/');
    return p ? p + 1 : path;
}

static int one_match(const char *where, const char *q) {
    size_t l = strlen(q);
    return (l && q[l - 1] == '/') ? prefix_component(where, q) : (contains_ci(where, q) || subseq_ci(where, q));
}

static int path_match(const char *path, int argc, char **argv, const char *base) {
    if (base && strncmp(path, base, strlen(base)) != 0) return 0;
    for (int i = 0; i < argc; i++) {
        const char *q = argv[i];
        int ok = (i == argc - 1) ? one_match(basename_c(path), q) : one_match(path, q);
        if (!ok) return 0;
    }
    return 1;
}

static void common_env_help(void) {
    printf("\nEnvironment variables:\n");
    printf("  _ZO_DATA_DIR          Path for zoxide data files\n");
    printf("  _ZO_ECHO              Print the matched directory before navigating to it when set to 1\n");
    printf("  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded\n");
    printf("  _ZO_FZF_OPTS          Custom flags to pass to fzf\n");
    printf("  _ZO_MAXAGE            Maximum total age after which entries start getting deleted\n");
    printf("  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths\n");
}

static void help_root(FILE *out) {
    fprintf(out, "zoxide 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\n");
    fprintf(out, "A smarter cd command for your terminal\n\nUsage:\n  executable <COMMAND>\n\nCommands:\n");
    fprintf(out, "  add     Add a new directory or increment its rank\n  edit    Edit the database\n  import  Import entries from another application\n  init    Generate shell configuration\n  query   Search for a directory in the database\n  remove  Remove a directory from the database\n\n");
    fprintf(out, "Options:\n  -h, --help     Print help\n  -V, --version  Print version\n");
    if (out == stdout) common_env_help();
    else {
        fprintf(out, "\nEnvironment variables:\n  _ZO_DATA_DIR          Path for zoxide data files\n  _ZO_ECHO              Print the matched directory before navigating to it when set to 1\n  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded\n  _ZO_FZF_OPTS          Custom flags to pass to fzf\n  _ZO_MAXAGE            Maximum total age after which entries start getting deleted\n  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths\n");
    }
}

static void sub_help(const char *cmd) {
    if (!strcmp(cmd, "add")) {
        printf("zoxide-add 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nAdd a new directory or increment its rank\n\nUsage:\n  executable add [OPTIONS] <PATHS>...\n\nArguments:\n  <PATHS>...  \n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't\n  -h, --help           Print help\n  -V, --version        Print version\n");
    } else if (!strcmp(cmd, "query")) {
        printf("zoxide-query 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nSearch for a directory in the database\n\nUsage:\n  executable query [OPTIONS] [KEYWORDS]...\n\nArguments:\n  [KEYWORDS]...  \n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory\n  -h, --help             Print help\n  -V, --version          Print version\n");
    } else if (!strcmp(cmd, "init")) {
        printf("zoxide-init 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nGenerate shell configuration\n\nUsage:\n  executable init [OPTIONS] <SHELL>\n\nArguments:\n  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]\n  -h, --help         Print help\n  -V, --version      Print version\n");
    } else if (!strcmp(cmd, "import")) {
        printf("zoxide-import 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nImport entries from another application\n\nUsage:\n  executable import [OPTIONS] --from <FROM> <PATH>\n\nArguments:\n  <PATH>  \n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database\n  -h, --help         Print help\n  -V, --version      Print version\n");
    } else if (!strcmp(cmd, "remove")) {
        printf("zoxide-remove 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nRemove a directory from the database\n\nUsage:\n  executable remove [PATHS]...\n\nArguments:\n  [PATHS]...  \n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n");
    } else {
        printf("zoxide-edit 0.9.9\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nEdit the database\n\nUsage:\n  executable edit\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n");
    }
    common_env_help();
}

static int cmd_add(int argc, char **argv) {
    double score = 1.0;
    int start = 0;
    for (; start < argc; start++) {
        if (!strcmp(argv[start], "-h") || !strcmp(argv[start], "--help")) { sub_help("add"); return 0; }
        if (!strcmp(argv[start], "-V") || !strcmp(argv[start], "--version")) { puts(VERSION); return 0; }
        if (!strcmp(argv[start], "--")) { start++; break; }
        if (!strcmp(argv[start], "-s") || !strcmp(argv[start], "--score")) {
            if (start + 1 >= argc) return 2;
            score = atof(argv[++start]);
            continue;
        }
        break;
    }
    if (start >= argc) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.\n");
        return 2;
    }
    DB db = db_load();
    int changed = 0, rc = 0;
    for (int i = start; i < argc; i++) {
        char *p = canon_path(argv[i]);
        if (!is_dir(p)) { fprintf(stderr, "zoxide: not a directory: %s\n", argv[i]); free(p); rc = 1; continue; }
        if (excluded(p)) { free(p); continue; }
        int idx = find_entry(&db, p);
        if (idx >= 0) { db.v[idx].score += score; db.v[idx].time = time(NULL); }
        else db_push(&db, p, score, time(NULL));
        changed = 1;
        free(p);
    }
    if (changed) rc = db_save(&db) ? 1 : rc;
    db_free(&db);
    return rc;
}

typedef struct { Entry *e; double f; } Hit;
static int cmp_hit(const void *a, const void *b) {
    const Hit *x = a, *y = b;
    if (y->f > x->f) return 1;
    if (y->f < x->f) return -1;
    return strcmp(y->e->path, x->e->path);
}

static int cmd_query(int argc, char **argv) {
    int all = 0, list = 0, score = 0;
    const char *exclude = NULL, *base = NULL;
    char **keys = calloc(argc ? argc : 1, sizeof(char*));
    int nk = 0;
    int opts = 1;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { free(keys); sub_help("query"); return 0; }
        if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { free(keys); puts(VERSION); return 0; }
        if (opts && !strcmp(argv[i], "--")) { opts = 0; continue; }
        if (opts && (!strcmp(argv[i], "-a") || !strcmp(argv[i], "--all"))) all = 1;
        else if (opts && (!strcmp(argv[i], "-i") || !strcmp(argv[i], "--interactive"))) list = 1;
        else if (opts && (!strcmp(argv[i], "-l") || !strcmp(argv[i], "--list"))) list = 1;
        else if (opts && (!strcmp(argv[i], "-s") || !strcmp(argv[i], "--score"))) score = 1;
        else if (opts && argv[i][0] == '-' && argv[i][1] && argv[i][1] != '-' && strchr(argv[i], 'l')) {
            for (const char *p = argv[i] + 1; *p; p++) { if (*p == 'l') list = 1; else if (*p == 's') score = 1; else if (*p == 'a') all = 1; }
        } else if (opts && !strcmp(argv[i], "--exclude") && i + 1 < argc) exclude = argv[++i];
        else if (opts && !strcmp(argv[i], "--base-dir") && i + 1 < argc) base = argv[++i];
        else if (opts && argv[i][0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable query [OPTIONS] [KEYWORDS]...\n\nFor more information, try '--help'.\n", argv[i]);
            free(keys);
            return 2;
        }
        else keys[nk++] = argv[i];
    }
    DB db = db_load();
    Hit *hits = calloc(db.n ? db.n : 1, sizeof(Hit));
    size_t hn = 0;
    for (size_t i = 0; i < db.n; i++) {
        if (exclude && strcmp(db.v[i].path, exclude) == 0) continue;
        if (!all && !is_dir(db.v[i].path)) continue;
        if (path_match(db.v[i].path, nk, keys, base)) {
            hits[hn].e = &db.v[i];
            hits[hn].f = frecency(&db.v[i]);
            hn++;
        }
    }
    qsort(hits, hn, sizeof(Hit), cmp_hit);
    if (hn == 0) {
        if (nk > 0) fprintf(stderr, "zoxide: no match found\n");
        free(hits); free(keys); db_free(&db);
        return nk > 0 ? 1 : 0;
    }
    size_t outn = list ? hn : 1;
    for (size_t i = 0; i < outn; i++) {
        if (score) printf("%6.1f %s\n", hits[i].f, hits[i].e->path);
        else printf("%s\n", hits[i].e->path);
    }
    free(hits); free(keys); db_free(&db);
    return 0;
}

static int cmd_remove(int argc, char **argv) {
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { sub_help("remove"); return 0; }
        if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { puts(VERSION); return 0; }
    }
    DB db = db_load();
    for (int a = 0; a < argc; a++) {
        char *p = canon_path(argv[a]);
        for (size_t i = 0; i < db.n;) {
            if (strcmp(db.v[i].path, p) == 0) {
                free(db.v[i].path);
                memmove(&db.v[i], &db.v[i + 1], (db.n - i - 1) * sizeof(Entry));
                db.n--;
            } else i++;
        }
        free(p);
    }
    int rc = db_save(&db);
    db_free(&db);
    return rc;
}

static int cmd_import(int argc, char **argv) {
    const char *from = NULL, *path = NULL;
    int merge = 0;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { sub_help("import"); return 0; }
        if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { puts(VERSION); return 0; }
        if (!strcmp(argv[i], "--merge")) merge = 1;
        else if (!strcmp(argv[i], "--from") && i + 1 < argc) from = argv[++i];
        else if (!strncmp(argv[i], "--from=", 7)) from = argv[i] + 7;
        else path = argv[i];
    }
    if (!from || !path) { sub_help("import"); return 2; }
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "zoxide: %s: %s\n", path, strerror(errno)); return 1; }
    DB db = merge ? db_load() : (DB){0};
    char *line = NULL; size_t cap = 0; ssize_t len;
    while ((len = getline(&line, &cap, f)) >= 0) {
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = 0;
        char *p = NULL; double sc = 1.0;
        if (!strcmp(from, "z")) {
            char *a = strtok(line, "|");
            char *b = strtok(NULL, "|");
            if (!a || !b) continue;
            p = a; sc = atof(b);
        } else if (!strcmp(from, "autojump")) {
            char *a = strtok(line, "\t");
            char *b = strtok(NULL, "\t");
            if (!a || !b) continue;
            sc = atof(a); p = b;
        }
        if (p && is_dir(p)) {
            int idx = find_entry(&db, p);
            if (idx >= 0) db.v[idx].score += sc;
            else db_push(&db, p, sc, time(NULL));
        }
    }
    free(line); fclose(f);
    int rc = db_save(&db);
    db_free(&db);
    return rc;
}

static int cmd_init(int argc, char **argv) {
    const char *cmd = "z", *hook = "pwd", *shell = NULL;
    int no_cmd = 0;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { sub_help("init"); return 0; }
        if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { puts(VERSION); return 0; }
        if (!strcmp(argv[i], "--no-cmd")) no_cmd = 1;
        else if (!strcmp(argv[i], "--cmd") && i + 1 < argc) cmd = argv[++i];
        else if (!strncmp(argv[i], "--cmd=", 6)) cmd = argv[i] + 6;
        else if (!strcmp(argv[i], "--hook") && i + 1 < argc) hook = argv[++i];
        else if (!strncmp(argv[i], "--hook=", 7)) hook = argv[i] + 7;
        else shell = argv[i];
    }
    if (!shell) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable init <SHELL>\n\nFor more information, try '--help'.\n");
        return 2;
    }
    const char *valid[] = {"bash","elvish","fish","nushell","posix","powershell","tcsh","xonsh","zsh",NULL};
    int ok = 0; for (int i = 0; valid[i]; i++) if (!strcmp(shell, valid[i])) ok = 1;
    if (!ok) { fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'.\n", shell); return 2; }
    if (!strcmp(shell, "fish")) {
        printf("function __zoxide_pwd\n    builtin pwd -L\nend\nfunction __zoxide_hook --on-variable PWD\n    command zoxide add -- (__zoxide_pwd)\nend\n");
        if (!no_cmd) printf("function %s\n    __zoxide_z $argv\nend\nfunction %si\n    __zoxide_zi $argv\nend\n", cmd, cmd);
    } else if (!strcmp(shell, "powershell")) {
        printf("function global:__zoxide_pwd { Get-Location }\nfunction global:__zoxide_z { zoxide query @args | Set-Location }\n");
        if (!no_cmd) printf("Set-Alias -Name %s -Value __zoxide_z\n", cmd);
    } else {
        printf("# shellcheck shell=sh\n__zoxide_pwd() {\n    command pwd -L\n}\n__zoxide_cd() {\n    command cd \"$@\"\n}\n");
        if (strcmp(hook, "none")) printf("__zoxide_hook() {\n    command zoxide add -- \"$(__zoxide_pwd)\"\n}\n");
        printf("__zoxide_z() {\n    if [ \"$#\" -eq 0 ]; then __zoxide_cd ~; else __zoxide_cd \"$(command zoxide query -- \"$@\")\"; fi\n}\n__zoxide_zi() {\n    __zoxide_z \"$@\"\n}\n");
        if (!no_cmd) printf("alias %s='__zoxide_z'\nalias %si='__zoxide_zi'\n", cmd, cmd);
    }
    return 0;
}

static int cmd_edit(int argc, char **argv) {
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { sub_help("edit"); return 0; }
        if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { puts(VERSION); return 0; }
    }
    char *p = db_path();
    const char *ed = getenv("EDITOR"); if (!ed) ed = "vi";
    char *cmd;
    if (asprintf(&cmd, "%s %s", ed, p) < 0) die_mem();
    int rc = system(cmd);
    free(cmd); free(p);
    return rc == -1 ? 1 : WEXITSTATUS(rc);
}

int main(int argc, char **argv) {
    if (argc <= 1) { help_root(stderr); return 2; }
    const char *c = argv[1];
    if (!strcmp(c, "-h") || !strcmp(c, "--help")) { help_root(stdout); return 0; }
    if (!strcmp(c, "-V") || !strcmp(c, "--version")) { puts(VERSION); return 0; }
    if (!strcmp(c, "add")) return cmd_add(argc - 2, argv + 2);
    if (!strcmp(c, "query")) return cmd_query(argc - 2, argv + 2);
    if (!strcmp(c, "remove")) return cmd_remove(argc - 2, argv + 2);
    if (!strcmp(c, "import")) return cmd_import(argc - 2, argv + 2);
    if (!strcmp(c, "init")) return cmd_init(argc - 2, argv + 2);
    if (!strcmp(c, "edit")) return cmd_edit(argc - 2, argv + 2);
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", c);
    return 2;
}
