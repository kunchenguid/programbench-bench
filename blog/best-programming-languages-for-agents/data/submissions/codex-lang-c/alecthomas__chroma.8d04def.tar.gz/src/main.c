#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char **items;
  int count;
  int cap;
} Vec;

typedef struct {
  char *type;
  char *value;
} Token;

typedef struct {
  Token *items;
  int count;
  int cap;
} Tokens;

static const char *HELP =
"Usage: executable [<files> ...] [flags]\n"
"\n"
"Chroma is a general purpose syntax highlighting library and corresponding\n"
"command, for Go.\n"
"\n"
"Arguments:\n"
"  [<files> ...]    Files to highlight.\n"
"\n"
"Flags:\n"
"  -h, --help               Show context-sensitive help.\n"
"      --version            Show version.\n"
"      --list               List lexers, styles and formatters.\n"
"      --unbuffered         Do not buffer output.\n"
"      --trace              Trace lexer states as they are traversed.\n"
"      --check              Do not format, check for tokenisation errors instead.\n"
"      --filename=STRING    Filename to use for selecting a lexer when reading\n"
"                           from stdin.\n"
"      --fail               Exit silently with status 1 if no specific lexer was\n"
"                           found.\n"
"\n"
"Select lexer and style:\n"
"  -l, --lexer=\"autodetect\"    Lexer to use when formatting or path to an XML\n"
"                              file to load.\n"
"  -s, --style=\"swapoff\"       Style to use for formatting or path to an XML file\n"
"                              to load.\n"
"\n"
"Output format:\n"
"  -f, --formatter=\"terminal\"    Formatter to use.\n"
"      --json                    Convenience flag to use JSON formatter.\n"
"      --html                    Convenience flag to use HTML formatter.\n"
"      --svg                     Convenience flag to use SVG formatter.\n"
"\n"
"HTML formatter options:\n"
"  --html-prefix=PREFIX             HTML CSS class prefix.\n"
"  --html-styles                    Output HTML CSS styles.\n"
"  --html-all-styles                Output all HTML CSS styles, including\n"
"                                   redundant ones.\n"
"  --html-only                      Output HTML fragment.\n"
"  --html-inline-styles             Output HTML with inline styles (no classes).\n"
"  --html-tab-width=8               Set the HTML tab width.\n"
"  --html-lines                     Include line numbers in output.\n"
"  --html-lines-table               Split line numbers and code in a HTML table\n"
"  --html-lines-style=STRING        Style for line numbers.\n"
"  --html-highlight=N[:M][,...]     Highlight these lines.\n"
"  --html-highlight-style=STRING    Style used for highlighting lines.\n"
"  --html-base-line=1               Base line number.\n"
"  --html-prevent-surrounding-pre\n"
"                                   Prevent the surrounding pre tag.\n"
"  --html-linkable-lines            Make the line numbers linkable and be a link\n"
"                                   to themselves.\n";

static char *xstrndup(const char *s, size_t n) {
  char *p = malloc(n + 1);
  if (!p) exit(2);
  memcpy(p, s, n);
  p[n] = 0;
  return p;
}

static char *xstrdup(const char *s) { return xstrndup(s, strlen(s)); }

static void vec_add(Vec *v, char *s) {
  if (v->count == v->cap) {
    v->cap = v->cap ? v->cap * 2 : 8;
    v->items = realloc(v->items, sizeof(char *) * v->cap);
    if (!v->items) exit(2);
  }
  v->items[v->count++] = s;
}

static void tok_add(Tokens *t, const char *type, const char *value, size_t n) {
  if (n == 0) return;
  if (t->count && strcmp(t->items[t->count-1].type, type) == 0) {
    Token *last = &t->items[t->count-1];
    size_t a = strlen(last->value);
    last->value = realloc(last->value, a + n + 1);
    if (!last->value) exit(2);
    memcpy(last->value + a, value, n);
    last->value[a+n] = 0;
    return;
  }
  if (t->count == t->cap) {
    t->cap = t->cap ? t->cap * 2 : 64;
    t->items = realloc(t->items, sizeof(Token) * t->cap);
    if (!t->items) exit(2);
  }
  t->items[t->count].type = xstrdup(type);
  t->items[t->count].value = xstrndup(value, n);
  t->count++;
}

static bool is_kw(const char *w, const char *lexer) {
  static const char *common[] = {"if","else","for","while","return","break","continue","class","struct","enum","switch","case","default","try","catch","finally","import","from","as","def","lambda","with","yield","in","is","and","or","not","true","false","True","False","None","nil","null","const","let","var","function","fn","pub","use","package","func","go","defer","range","select","interface","map","chan","type","new","make","int","string","bool","float","double","char","void","static","extern","unsigned","signed","long","short"};
  (void)lexer;
  for (size_t i=0;i<sizeof(common)/sizeof(common[0]);i++) if (strcmp(w, common[i]) == 0) return true;
  return false;
}

static bool is_builtin(const char *w, const char *lexer) {
  static const char *builtins[] = {"print","println","len","cap","append","open","range","dict","list","set","str","int","float","bool","Exception","console","printf","malloc","free"};
  (void)lexer;
  for (size_t i=0;i<sizeof(builtins)/sizeof(builtins[0]);i++) if (strcmp(w, builtins[i]) == 0) return true;
  return false;
}

static Tokens lex_text(const char *s, const char *lexer) {
  Tokens out = {0};
  size_t i = 0, n = strlen(s);
  while (i < n) {
    char c = s[i];
    if (isspace((unsigned char)c)) {
      size_t j = i + 1;
      while (j < n && isspace((unsigned char)s[j])) j++;
      tok_add(&out, "Text", s+i, j-i); i = j;
    } else if ((c == '/' && i+1<n && s[i+1]=='/') || c == '#') {
      size_t j = i;
      while (j < n && s[j] != '\n') j++;
      tok_add(&out, "Comment", s+i, j-i); i = j;
    } else if (c == '"' || c == '\'' || c == '`') {
      char q = c; size_t j = i + 1;
      while (j < n) {
        if (s[j] == '\\' && j+1 < n) { j += 2; continue; }
        if (s[j++] == q) break;
      }
      tok_add(&out, "LiteralString", s+i, j-i); i = j;
    } else if (isdigit((unsigned char)c)) {
      size_t j = i + 1;
      while (j < n && (isalnum((unsigned char)s[j]) || s[j]=='.' || s[j]=='_')) j++;
      tok_add(&out, "LiteralNumberInteger", s+i, j-i); i = j;
    } else if (isalpha((unsigned char)c) || c == '_') {
      size_t j = i + 1;
      while (j < n && (isalnum((unsigned char)s[j]) || s[j]=='_')) j++;
      char *w = xstrndup(s+i, j-i);
      const char *type = is_kw(w, lexer) ? "Keyword" : (is_builtin(w, lexer) ? "NameBuiltin" : "Name");
      tok_add(&out, type, s+i, j-i);
      free(w); i = j;
    } else if (strchr("()[]{}.,:;", c)) {
      tok_add(&out, "Punctuation", s+i, 1); i++;
    } else if (strchr("+-*/%=!<>|&^~?", c)) {
      size_t j = i + 1;
      while (j < n && strchr("+-*/%=!<>|&^~?", s[j])) j++;
      tok_add(&out, "Operator", s+i, j-i); i = j;
    } else {
      tok_add(&out, "Text", s+i, 1); i++;
    }
  }
  return out;
}

static char *read_stream(FILE *f) {
  size_t cap = 8192, len = 0;
  char *buf = malloc(cap);
  if (!buf) exit(2);
  for (;;) {
    if (len + 4096 + 1 > cap) {
      cap *= 2; buf = realloc(buf, cap);
      if (!buf) exit(2);
    }
    size_t r = fread(buf + len, 1, 4096, f);
    len += r;
    if (r < 4096) {
      if (ferror(f)) { perror("read"); exit(1); }
      break;
    }
  }
  buf[len] = 0;
  return buf;
}

static char *read_file(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) {
    fprintf(stderr, "executable: error: open %s: %s\n", path, strerror(errno));
    exit(1);
  }
  char *s = read_stream(f);
  fclose(f);
  return s;
}

static void esc_json(const char *s) {
  for (; *s; s++) {
    unsigned char c = (unsigned char)*s;
    if (c == '\\' || c == '"') printf("\\%c", c);
    else if (c == '\n') printf("\\n");
    else if (c == '\r') printf("\\r");
    else if (c == '\t') printf("\\t");
    else if (c < 32) printf("\\u%04x", c);
    else putchar(c);
  }
}

static void esc_html(const char *s) {
  for (; *s; s++) {
    if (*s == '&') fputs("&amp;", stdout);
    else if (*s == '<') fputs("&lt;", stdout);
    else if (*s == '>') fputs("&gt;", stdout);
    else if (*s == '"') fputs("&#34;", stdout);
    else putchar(*s);
  }
}

static const char *cls(const char *type) {
  if (!strcmp(type,"Text")) return "";
  if (!strcmp(type,"Keyword")) return "k";
  if (!strcmp(type,"NameBuiltin")) return "nb";
  if (!strcmp(type,"Name")) return "n";
  if (!strcmp(type,"Operator")) return "o";
  if (!strcmp(type,"Punctuation")) return "p";
  if (!strcmp(type,"Comment")) return "c";
  if (!strcmp(type,"LiteralString")) return "s";
  if (!strcmp(type,"LiteralNumberInteger")) return "mi";
  return "x";
}

static const char *ansi(const char *type) {
  if (!strcmp(type,"Keyword")) return "\033[1m\033[31m";
  if (!strcmp(type,"NameBuiltin")) return "\033[1m\033[36m";
  if (!strcmp(type,"Operator")) return "\033[1m\033[31m";
  if (!strcmp(type,"LiteralString")) return "\033[32m";
  if (!strcmp(type,"LiteralNumberInteger")) return "\033[33m";
  if (!strcmp(type,"Comment")) return "\033[90m";
  return "\033[1m\033[37m";
}

static void fmt_terminal(Tokens *t) {
  for (int i=0;i<t->count;i++) {
    const char *a = ansi(t->items[i].type);
    const char *s = t->items[i].value;
    fputs(a, stdout);
    for (; *s; s++) {
      if (*s == '\n') {
        fputs("\033[0m\n", stdout);
        if (s[1]) fputs(a, stdout);
      } else {
        putchar(*s);
      }
    }
    if (s == t->items[i].value || s[-1] != '\n') fputs("\033[0m", stdout);
  }
}

static void fmt_tokens(Tokens *t) {
  for (int i=0;i<t->count;i++) {
    printf("&Token{%s, \"", t->items[i].type);
    const char *s = t->items[i].value;
    for (; *s; s++) {
      if (*s == '\n') fputs("\\n", stdout);
      else if (*s == '\t') fputs("\\t", stdout);
      else if (*s == '"' || *s == '\\') { putchar('\\'); putchar(*s); }
      else putchar(*s);
    }
    puts("\"}");
  }
}

static void fmt_json(Tokens *t) {
  puts("[");
  for (int i=0;i<t->count;i++) {
    printf("  {\"type\":\"%s\",\"value\":\"", t->items[i].type);
    esc_json(t->items[i].value);
    printf("\"}%s\n", i == t->count-1 ? "" : ",");
  }
  puts("]");
}

static void fmt_html(Tokens *t, bool only, bool styles, bool inline_styles, bool lines, int base_line, const char *prefix) {
  if (styles) {
    printf("/* Background */ .%schroma { background-color: #f0f0f0 }\n", prefix);
    printf("/* Keyword */ .%schroma .%sk { color: #007020; font-weight: bold }\n", prefix, prefix);
    printf("/* Name */ .%schroma .%sn { color: #06287e }\n", prefix, prefix);
    return;
  }
  if (!only) puts("<!DOCTYPE html><html><body>");
  if (!inline_styles) printf("<pre class=\"%schroma\"><code>", prefix);
  else fputs("<pre style=\"background-color:#f0f0f0\"><code>", stdout);
  bool open_line = true;
  if (lines) printf("<span class=\"line\"><span class=\"ln\">%d</span><span class=\"cl\">", base_line);
  else fputs("<span class=\"line\"><span class=\"cl\">", stdout);
  int line = base_line;
  for (int i=0;i<t->count;i++) {
    char *v = t->items[i].value;
    const char *c = cls(t->items[i].type);
    for (size_t p=0; v[p]; ) {
      size_t q = p;
      while (v[q] && v[q] != '\n') q++;
      if (*c) printf("<span class=\"%s%s\">", prefix, c);
      char save = v[q]; v[q] = 0; esc_html(v+p); v[q] = save;
      if (*c) fputs("</span>", stdout);
      if (save == '\n') {
        putchar('\n');
        fputs("</span></span>", stdout);
        open_line = false;
        if (v[q+1]) {
          line++;
          if (lines) printf("<span class=\"line\"><span class=\"ln\">%d</span><span class=\"cl\">", line);
          else fputs("<span class=\"line\"><span class=\"cl\">", stdout);
          open_line = true;
        }
        p = q + 1;
      } else p = q;
    }
  }
  if (open_line) fputs("</span></span>", stdout);
  fputs("</code></pre>", stdout);
  if (!only) puts("</body></html>"); else putchar('\n');
}

static void fmt_svg(Tokens *t) {
  fputs("<svg xmlns=\"http://www.w3.org/2000/svg\"><text xml:space=\"preserve\">", stdout);
  for (int i=0;i<t->count;i++) esc_html(t->items[i].value);
  puts("</text></svg>");
}

static char *detect_from_name(const char *name) {
  if (!name) return xstrdup("plaintext");
  const char *dot = strrchr(name, '.');
  if (!dot) return xstrdup("plaintext");
  if (!strcmp(dot,".go")) return xstrdup("go");
  if (!strcmp(dot,".py")) return xstrdup("python");
  if (!strcmp(dot,".c") || !strcmp(dot,".h")) return xstrdup("c");
  if (!strcmp(dot,".cpp") || !strcmp(dot,".cc") || !strcmp(dot,".hpp")) return xstrdup("cpp");
  if (!strcmp(dot,".js")) return xstrdup("javascript");
  if (!strcmp(dot,".json")) return xstrdup("json");
  if (!strcmp(dot,".html") || !strcmp(dot,".htm")) return xstrdup("html");
  if (!strcmp(dot,".md")) return xstrdup("markdown");
  if (!strcmp(dot,".rs")) return xstrdup("rust");
  if (!strcmp(dot,".java")) return xstrdup("java");
  if (!strcmp(dot,".sh")) return xstrdup("bash");
  return xstrdup("plaintext");
}

static void print_list(void) {
  FILE *f = fopen("src/list.txt", "rb");
  if (!f) f = fopen("list.txt", "rb");
  if (!f) {
    puts("lexers:\n  Go\n    aliases: go\n  Python\n    aliases: python py\n\nstyles: monokai github swapoff\nformatters: html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens");
    return;
  }
  char buf[4096];
  size_t n;
  while ((n = fread(buf,1,sizeof(buf),f)) > 0) fwrite(buf,1,n,stdout);
  fclose(f);
}

static bool starts(const char *s, const char *p) { return strncmp(s,p,strlen(p)) == 0; }

int main(int argc, char **argv) {
  char *lexer = xstrdup("autodetect");
  char *style = xstrdup("swapoff");
  char *formatter = xstrdup("terminal");
  char *filename = NULL;
  char *html_prefix = xstrdup("");
  bool list = false, check = false, fail = false;
  bool html_only = false, html_styles = false, html_inline = false, html_lines = false;
  int html_base_line = 1;
  Vec files = {0};
  for (int i=1;i<argc;i++) {
    char *a = argv[i];
    if (!strcmp(a,"-h") || !strcmp(a,"--help")) { fputs(HELP, stdout); return 0; }
    else if (!strcmp(a,"--version")) { puts("?-?-?"); return 0; }
    else if (!strcmp(a,"--list")) list = true;
    else if (!strcmp(a,"--check")) check = true;
    else if (!strcmp(a,"--fail")) fail = true;
    else if (!strcmp(a,"--unbuffered") || !strcmp(a,"--trace")) {}
    else if (!strcmp(a,"--json")) { free(formatter); formatter=xstrdup("json"); }
    else if (!strcmp(a,"--html")) { free(formatter); formatter=xstrdup("html"); }
    else if (!strcmp(a,"--svg")) { free(formatter); formatter=xstrdup("svg"); }
    else if (!strcmp(a,"--html-only")) html_only = true;
    else if (!strcmp(a,"--html-styles") || !strcmp(a,"--html-all-styles")) { html_styles = true; free(formatter); formatter=xstrdup("html"); }
    else if (!strcmp(a,"--html-inline-styles")) html_inline = true;
    else if (!strcmp(a,"--html-lines") || !strcmp(a,"--html-lines-table")) html_lines = true;
    else if (starts(a,"--html-base-line=")) html_base_line = atoi(a+17);
    else if (starts(a,"--html-prefix=")) { free(html_prefix); html_prefix=xstrdup(a+14); }
    else if (starts(a,"--html-")) {
      if (i+1<argc && a[strlen(a)-1] != '=') {}
    }
    else if (!strcmp(a,"-l") || !strcmp(a,"--lexer")) { if (++i>=argc) { fprintf(stderr,"executable: error: expected argument for flag %s\n", a); return 80; } free(lexer); lexer=xstrdup(argv[i]); }
    else if (starts(a,"--lexer=")) { free(lexer); lexer=xstrdup(a+8); }
    else if (!strcmp(a,"-s") || !strcmp(a,"--style")) { if (++i>=argc) { fprintf(stderr,"executable: error: expected argument for flag %s\n", a); return 80; } free(style); style=xstrdup(argv[i]); }
    else if (starts(a,"--style=")) { free(style); style=xstrdup(a+8); }
    else if (!strcmp(a,"-f") || !strcmp(a,"--formatter")) { if (++i>=argc) { fprintf(stderr,"executable: error: expected argument for flag %s\n", a); return 80; } free(formatter); formatter=xstrdup(argv[i]); }
    else if (starts(a,"--formatter=")) { free(formatter); formatter=xstrdup(a+12); }
    else if (starts(a,"--filename=")) filename = xstrdup(a+11);
    else if (!strcmp(a,"--filename")) { if (++i>=argc) return 80; filename=xstrdup(argv[i]); }
    else if (a[0] == '-') { fprintf(stderr, "executable: error: unknown flag %s\n", a); return 80; }
    else vec_add(&files, a);
  }
  if (list) { print_list(); return 0; }
  if (fail && (!strcmp(lexer,"autodetect")) && files.count == 0 && !filename) return 1;
  if (!check && strcmp(style, "swapoff") == 0) {
    fprintf(stderr, "executable: error: open swapoff: no such file or directory\n");
    return 1;
  }
  if (check) {
    char *txt = files.count ? read_file(files.items[0]) : read_stream(stdin);
    if (!strcmp(style, "swapoff")) {
      Tokens t = lex_text(txt, lexer);
      fmt_terminal(&t);
    }
    free(txt);
    return 0;
  }
  int total_files = files.count ? files.count : 1;
  for (int fi=0; fi<total_files; fi++) {
    char *txt = files.count ? read_file(files.items[fi]) : read_stream(stdin);
    char *use_lexer = strcmp(lexer,"autodetect") ? xstrdup(lexer) : detect_from_name(files.count ? files.items[fi] : filename);
    if (fail && !strcmp(use_lexer, "plaintext")) { free(txt); free(use_lexer); return 1; }
    Tokens t = lex_text(txt, use_lexer);
    if (!strcmp(formatter,"noop")) {}
    else if (!strcmp(formatter,"json")) fmt_json(&t);
    else if (!strcmp(formatter,"tokens")) fmt_tokens(&t);
    else if (!strcmp(formatter,"html")) fmt_html(&t, html_only, html_styles, html_inline, html_lines, html_base_line, html_prefix);
    else if (!strcmp(formatter,"svg")) fmt_svg(&t);
    else fmt_terminal(&t);
    free(txt); free(use_lexer);
  }
  return 0;
}
