#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct sqlite3 sqlite3;
typedef struct sqlite3_stmt sqlite3_stmt;
extern int sqlite3_open(const char *, sqlite3 **);
extern int sqlite3_close(sqlite3 *);
extern int sqlite3_exec(sqlite3 *, const char *, int (*)(void *, int, char **, char **), void *, char **);
extern int sqlite3_prepare_v2(sqlite3 *, const char *, int, sqlite3_stmt **, const char **);
extern int sqlite3_step(sqlite3_stmt *);
extern int sqlite3_finalize(sqlite3_stmt *);
extern int sqlite3_column_count(sqlite3_stmt *);
extern const char *sqlite3_column_name(sqlite3_stmt *, int);
extern const unsigned char *sqlite3_column_text(sqlite3_stmt *, int);
extern int sqlite3_column_type(sqlite3_stmt *, int);
extern const char *sqlite3_errmsg(sqlite3 *);
extern char *sqlite3_mprintf(const char *, ...);
extern void sqlite3_free(void *);

#define SQLITE_ROW 100
#define SQLITE_DONE 101
#define SQLITE_NULL 5

typedef enum { F_GUESS, F_CSV, F_LTSV, F_JSON, F_TEXT, F_TBLN, F_YAML } InFmt;
typedef enum { O_CSV, O_JSON, O_JSONL, O_LTSV, O_MD, O_AT, O_RAW, O_TBLN, O_VF, O_YAML } OutFmt;

typedef struct {
    char **v;
    int n;
    int cap;
} StrList;

typedef struct {
    char **cells;
    int n;
} Row;

typedef struct {
    char **cols;
    int ncols;
    Row *rows;
    int nrows;
    int caprows;
} Table;

typedef struct {
    InFmt ifmt;
    OutFmt ofmt;
    char *in_delim;
    char *out_delim;
    char quote;
    bool ih;
    bool oh;
    bool oaq;
    bool crlf;
    bool inum;
    int skip;
    int limit_read;
    char *in_null;
    char *out_null;
    char *query_file;
    char *table_file;
    char *out_file;
    int analyze;
    char *analyze_file;
    bool out_without_guess;
} Opt;

static const char *help_text =
"trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.\n"
"\n"
"Usage\n"
"\ttrdsql [OPTIONS] [SQL(SELECT...)]\n"
"\n"
"Options:\n"
"  -A string           analyze the file but only suggest SQL.\n"
"  -a string           analyze the file and suggest SQL.\n"
"  -config string      configuration file location.\n"
"  -db string          specify db name of the setting.\n"
"  -dblist             display db information.\n"
"  -debug              debug print.\n"
"  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]\n"
"  -dsn string         database driver specific data source name.\n"
"  -help               display usage information.\n"
"  -q string           read query from the specified file.\n"
"  -t string           read table name from the specified file.\n"
"  -version            display version information.\n"
"\n"
"Input Formats:\n"
"  -icsv               CSV format for input.\n"
"  -ig                 guess format from extension. (default \"true\")\n"
"  -ijson              JSON format for input.\n"
"  -iltsv              LTSV format for input.\n"
"  -itbln              TBLN format for input.\n"
"  -itext              text format for input.\n"
"  -iwidth             width specification format for input.\n"
"  -iyaml              YAML format for input.\n"
"\n"
"Input options:\n"
"  -id string          field delimiter for input. (default \",\")\n"
"  -ih                 the first line is interpreted as column names(CSV only).\n"
"  -ijq string         jq expression string for input(JSON/JSONL only).\n"
"  -ilr int            limited number of rows to read. (default 0)\n"
"  -inull value        value(string) to convert to null on input.\n"
"  -inum               add row number column.\n"
"  -ir int             number of rows to preread. (default 1)\n"
"  -is int             skip header row. (default 0)\n"
"\n"
"Output Formats:\n"
"  -oat                ASCII Table format for output.\n"
"  -ocsv               CSV format for output.\n"
"  -ojson              JSON format for output.\n"
"  -ojsonl             JSON lines format for output.\n"
"  -oltsv              LTSV format for output.\n"
"  -omd                Markdown format for output.\n"
"  -oraw               Raw format for output.\n"
"  -otbln              TBLN format for output.\n"
"  -ovf                Vertical format for output.\n"
"  -oyaml              YAML format for output.\n"
"\n"
"Output options:\n"
"  -oaq                enclose all fields in quotes for output.\n"
"  -ocrlf              use CRLF for output. End each output line with '\\r\\n' instead of '\\n'.\n"
"  -od string          field delimiter for output. (default \",\")\n"
"  -oh                 output column name as header.\n"
"  -onowrap            do not wrap long lines(at/md only).\n"
"  -onull value        value(string) to convert from null on output.\n"
"  -oq string          quote character for output. (default \"\\\"\")\n"
"  -out string         output file name\n"
"  -out-without-guess  output without guessing (when using -out).\n"
"  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]\n"
"\n"
"Examples:\n"
"  $ trdsql \"SELECT c1,c2 FROM test.csv\"\n"
"  $ trdsql -oltsv \"SELECT c1,c2 FROM test.json::.items\"\n"
"  $ cat test.csv | trdsql -icsv -oltsv \"SELECT c1,c2 FROM -\"\n";

static void *xcalloc(size_t n, size_t s) {
    void *p = calloc(n, s);
    if (!p) { perror("calloc"); exit(2); }
    return p;
}

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) { perror("strdup"); exit(2); }
    return p;
}

static char *xasprintf(const char *fmt, ...) {
    va_list ap;
    char *s = NULL;
    va_start(ap, fmt);
    if (vasprintf(&s, fmt, ap) < 0) { perror("vasprintf"); exit(2); }
    va_end(ap);
    return s;
}

static void sl_add(StrList *l, char *s) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 8;
        l->v = realloc(l->v, (size_t)l->cap * sizeof(char *));
        if (!l->v) { perror("realloc"); exit(2); }
    }
    l->v[l->n++] = s;
}

static int col_index(Table *t, const char *name) {
    for (int i = 0; i < t->ncols; i++) if (strcmp(t->cols[i], name) == 0) return i;
    return -1;
}

static int add_col(Table *t, const char *name) {
    int idx = col_index(t, name);
    if (idx >= 0) return idx;
    t->cols = realloc(t->cols, (size_t)(t->ncols + 1) * sizeof(char *));
    if (!t->cols) { perror("realloc"); exit(2); }
    t->cols[t->ncols] = xstrdup(name);
    for (int r = 0; r < t->nrows; r++) {
        t->rows[r].cells = realloc(t->rows[r].cells, (size_t)(t->ncols + 1) * sizeof(char *));
        t->rows[r].cells[t->ncols] = NULL;
        t->rows[r].n = t->ncols + 1;
    }
    return t->ncols++;
}

static void add_row(Table *t, char **cells, int n) {
    if (n > t->ncols) {
        for (int i = t->ncols; i < n; i++) {
            char buf[32];
            snprintf(buf, sizeof(buf), "c%d", i + 1);
            add_col(t, buf);
        }
    }
    if (t->nrows == t->caprows) {
        t->caprows = t->caprows ? t->caprows * 2 : 32;
        t->rows = realloc(t->rows, (size_t)t->caprows * sizeof(Row));
        if (!t->rows) { perror("realloc"); exit(2); }
    }
    Row row;
    row.n = t->ncols;
    row.cells = xcalloc((size_t)t->ncols, sizeof(char *));
    for (int i = 0; i < n && i < t->ncols; i++) row.cells[i] = cells[i];
    t->rows[t->nrows++] = row;
}

static char *trim_dup(const char *s, size_t n) {
    while (n && isspace((unsigned char)*s)) { s++; n--; }
    while (n && isspace((unsigned char)s[n - 1])) n--;
    char *out = xcalloc(n + 1, 1);
    memcpy(out, s, n);
    return out;
}

static void parse_csv_line(const char *line, char delim, StrList *fields) {
    const char *p = line;
    while (1) {
        char *buf = NULL;
        size_t n = 0, cap = 0;
        bool quoted = false;
        if (*p == '"') { quoted = true; p++; }
        while (*p) {
            char c = *p++;
            if (quoted) {
                if (c == '"') {
                    if (*p == '"') { c = *p++; }
                    else { quoted = false; continue; }
                }
            } else if (c == delim) {
                break;
            }
            if (n + 2 > cap) {
                cap = cap ? cap * 2 : 32;
                buf = realloc(buf, cap);
                if (!buf) { perror("realloc"); exit(2); }
            }
            buf[n++] = c;
        }
        if (!buf) buf = xstrdup("");
        else buf[n] = 0;
        sl_add(fields, buf);
        if (!*p) break;
    }
}

static FILE *open_input(const char *path) {
    if (!path || strcmp(path, "-") == 0) return stdin;
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "trdsql: %s: %s\n", path, strerror(errno));
        exit(1);
    }
    return f;
}

static char *read_all(const char *path) {
    FILE *f = open_input(path);
    char *buf = NULL;
    size_t n = 0, cap = 0;
    char tmp[4096];
    while (!feof(f)) {
        size_t r = fread(tmp, 1, sizeof(tmp), f);
        if (n + r + 1 > cap) {
            cap = (n + r + 1) * 2 + 128;
            buf = realloc(buf, cap);
            if (!buf) { perror("realloc"); exit(2); }
        }
        memcpy(buf + n, tmp, r);
        n += r;
    }
    if (f != stdin) fclose(f);
    if (!buf) buf = xstrdup("");
    else buf[n] = 0;
    return buf;
}

static void maybe_add_rownum(Table *t) {
    add_col(t, "rownum");
    int idx = col_index(t, "rownum");
    for (int r = 0; r < t->nrows; r++) {
        free(t->rows[r].cells[idx]);
        t->rows[r].cells[idx] = xasprintf("%d", r + 1);
    }
}

static void load_csv(Table *t, const char *path, Opt *o) {
    FILE *f = open_input(path);
    char *line = NULL;
    size_t len = 0;
    int lineno = 0, rows = 0;
    while (getline(&line, &len, f) >= 0) {
        lineno++;
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        if (lineno <= o->skip) continue;
        StrList fs = {0};
        parse_csv_line(line, o->in_delim[0], &fs);
        if (t->ncols == 0) {
            if (o->ih) {
                for (int i = 0; i < fs.n; i++) add_col(t, fs.v[i][0] ? fs.v[i] : xasprintf("c%d", i + 1));
                for (int i = 0; i < fs.n; i++) free(fs.v[i]);
                free(fs.v);
                continue;
            } else {
                for (int i = 0; i < fs.n; i++) {
                    char buf[32];
                    snprintf(buf, sizeof(buf), "c%d", i + 1);
                    add_col(t, buf);
                }
            }
        }
        add_row(t, fs.v, fs.n);
        free(fs.v);
        rows++;
        if (o->limit_read && rows >= o->limit_read) break;
    }
    free(line);
    if (f != stdin) fclose(f);
    if (o->inum) maybe_add_rownum(t);
}

static void load_text(Table *t, const char *path, Opt *o) {
    FILE *f = open_input(path);
    add_col(t, "c1");
    char *line = NULL;
    size_t len = 0;
    int lineno = 0, rows = 0;
    while (getline(&line, &len, f) >= 0) {
        lineno++;
        if (lineno <= o->skip) continue;
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        char **cells = xcalloc(1, sizeof(char *));
        cells[0] = xstrdup(line);
        add_row(t, cells, 1);
        free(cells);
        rows++;
        if (o->limit_read && rows >= o->limit_read) break;
    }
    free(line);
    if (f != stdin) fclose(f);
    if (o->inum) maybe_add_rownum(t);
}

static void load_ltsv(Table *t, const char *path, Opt *o) {
    FILE *f = open_input(path);
    char *line = NULL;
    size_t len = 0;
    int rows = 0;
    while (getline(&line, &len, f) >= 0) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        Row row = {0};
        row.cells = xcalloc((size_t)(t->ncols ? t->ncols : 1), sizeof(char *));
        char *work = xstrdup(line);
        for (char *tok = strtok(work, "\t"); tok; tok = strtok(NULL, "\t")) {
            char *colon = strchr(tok, ':');
            if (!colon) continue;
            *colon = 0;
            int idx = add_col(t, tok);
            row.cells = realloc(row.cells, (size_t)t->ncols * sizeof(char *));
            for (int i = row.n; i < t->ncols; i++) row.cells[i] = NULL;
            row.n = t->ncols;
            row.cells[idx] = xstrdup(colon + 1);
        }
        free(work);
        if (t->nrows == t->caprows) {
            t->caprows = t->caprows ? t->caprows * 2 : 32;
            t->rows = realloc(t->rows, (size_t)t->caprows * sizeof(Row));
        }
        t->rows[t->nrows++] = row;
        rows++;
        if (o->limit_read && rows >= o->limit_read) break;
    }
    free(line);
    if (f != stdin) fclose(f);
    if (o->inum) maybe_add_rownum(t);
}

static char *strip_bar_field(const char *s, size_t n) {
    char *v = trim_dup(s, n);
    size_t l = strlen(v);
    if (l && v[l - 1] == '|') {
        v[l - 1] = 0;
        char *t = trim_dup(v, strlen(v));
        free(v);
        v = t;
    }
    return v;
}

static void parse_tbln_fields(const char *line, StrList *fields) {
    const char *p = strchr(line, '|');
    while (p) {
        p++;
        const char *q = strchr(p, '|');
        if (!q) break;
        sl_add(fields, strip_bar_field(p, (size_t)(q - p)));
        p = q;
    }
}

static void load_tbln(Table *t, const char *path, Opt *o) {
    FILE *f = open_input(path);
    char *line = NULL;
    size_t len = 0;
    int rows = 0;
    while (getline(&line, &len, f) >= 0) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        if (!strncmp(line, "; name:", 7)) {
            StrList fs = {0};
            parse_tbln_fields(line, &fs);
            for (int i = 0; i < fs.n; i++) {
                add_col(t, fs.v[i][0] ? fs.v[i] : xasprintf("c%d", i + 1));
                free(fs.v[i]);
            }
            free(fs.v);
        } else if (line[0] == '|') {
            StrList fs = {0};
            parse_tbln_fields(line, &fs);
            if (t->ncols == 0) {
                for (int i = 0; i < fs.n; i++) {
                    char buf[32];
                    snprintf(buf, sizeof(buf), "c%d", i + 1);
                    add_col(t, buf);
                }
            }
            add_row(t, fs.v, fs.n);
            free(fs.v);
            rows++;
            if (o->limit_read && rows >= o->limit_read) break;
        }
    }
    free(line);
    if (f != stdin) fclose(f);
    if (o->inum) maybe_add_rownum(t);
}

static const char *json_skip_ws(const char *p) {
    while (*p && isspace((unsigned char)*p)) p++;
    return p;
}

static char *json_string(const char **pp) {
    const char *p = *pp;
    if (*p != '"') return NULL;
    p++;
    char *buf = NULL;
    size_t n = 0, cap = 0;
    while (*p && *p != '"') {
        char c = *p++;
        if (c == '\\' && *p) {
            c = *p++;
            if (c == 'n') c = '\n';
            else if (c == 't') c = '\t';
            else if (c == 'r') c = '\r';
        }
        if (n + 2 > cap) {
            cap = cap ? cap * 2 : 32;
            buf = realloc(buf, cap);
        }
        buf[n++] = c;
    }
    if (*p == '"') p++;
    if (!buf) buf = xstrdup("");
    else buf[n] = 0;
    *pp = p;
    return buf;
}

static char *json_value(const char **pp, bool *isnull) {
    const char *p = json_skip_ws(*pp);
    *isnull = false;
    if (*p == '"') {
        char *s = json_string(&p);
        *pp = p;
        return s;
    }
    const char *start = p;
    if (strncmp(p, "null", 4) == 0) {
        *isnull = true;
        *pp = p + 4;
        return NULL;
    }
    while (*p && !strchr(",}\n\r\t ", *p)) p++;
    *pp = p;
    return trim_dup(start, (size_t)(p - start));
}

static const char *parse_json_object(Table *t, const char *p) {
    p = json_skip_ws(p);
    if (*p != '{') return p;
    p++;
    Row row = {0};
    row.n = t->ncols;
    row.cells = xcalloc((size_t)(t->ncols ? t->ncols : 1), sizeof(char *));
    while (*p) {
        p = json_skip_ws(p);
        if (*p == '}') { p++; break; }
        char *key = json_string(&p);
        if (!key) break;
        p = json_skip_ws(p);
        if (*p == ':') p++;
        bool isnull = false;
        char *val = json_value(&p, &isnull);
        int idx = add_col(t, key);
        row.cells = realloc(row.cells, (size_t)t->ncols * sizeof(char *));
        for (int i = row.n; i < t->ncols; i++) row.cells[i] = NULL;
        row.n = t->ncols;
        if (!isnull) row.cells[idx] = val;
        else free(val);
        free(key);
        p = json_skip_ws(p);
        if (*p == ',') p++;
    }
    if (t->nrows == t->caprows) {
        t->caprows = t->caprows ? t->caprows * 2 : 32;
        t->rows = realloc(t->rows, (size_t)t->caprows * sizeof(Row));
    }
    t->rows[t->nrows++] = row;
    return p;
}

static void load_json(Table *t, const char *path, Opt *o) {
    char *buf = read_all(path);
    const char *p = buf;
    int rows = 0;
    while ((p = strchr(p, '{')) != NULL) {
        p = parse_json_object(t, p);
        rows++;
        if (o->limit_read && rows >= o->limit_read) break;
    }
    free(buf);
    if (o->inum) maybe_add_rownum(t);
}

static void row_put(Table *t, Row *row, const char *key, const char *val) {
    int idx = add_col(t, key);
    row->cells = realloc(row->cells, (size_t)t->ncols * sizeof(char *));
    if (!row->cells) { perror("realloc"); exit(2); }
    for (int i = row->n; i < t->ncols; i++) row->cells[i] = NULL;
    row->n = t->ncols;
    free(row->cells[idx]);
    row->cells[idx] = xstrdup(val);
}

static void append_existing_row(Table *t, Row *row) {
    if (row->n == 0) return;
    row->cells = realloc(row->cells, (size_t)t->ncols * sizeof(char *));
    for (int i = row->n; i < t->ncols; i++) row->cells[i] = NULL;
    row->n = t->ncols;
    if (t->nrows == t->caprows) {
        t->caprows = t->caprows ? t->caprows * 2 : 32;
        t->rows = realloc(t->rows, (size_t)t->caprows * sizeof(Row));
    }
    t->rows[t->nrows++] = *row;
    row->cells = NULL;
    row->n = 0;
}

static void yaml_keyval(Table *t, Row *row, char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *colon = strchr(s, ':');
    if (!colon) return;
    *colon = 0;
    char *key = trim_dup(s, strlen(s));
    char *val = trim_dup(colon + 1, strlen(colon + 1));
    size_t l = strlen(val);
    if (l >= 2 && ((val[0] == '"' && val[l - 1] == '"') || (val[0] == '\'' && val[l - 1] == '\''))) {
        val[l - 1] = 0;
        memmove(val, val + 1, l - 1);
    }
    row_put(t, row, key, val);
    free(key);
    free(val);
}

static void load_yaml(Table *t, const char *path, Opt *o) {
    FILE *f = open_input(path);
    char *line = NULL;
    size_t len = 0;
    Row cur = {0};
    int rows = 0;
    while (getline(&line, &len, f) >= 0) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r')) line[--l] = 0;
        char *p = line;
        while (isspace((unsigned char)*p)) p++;
        if (!*p || *p == '#') continue;
        if (*p == '-') {
            append_existing_row(t, &cur);
            rows++;
            p++;
            yaml_keyval(t, &cur, p);
        } else {
            yaml_keyval(t, &cur, p);
        }
        if (o->limit_read && rows >= o->limit_read) break;
    }
    append_existing_row(t, &cur);
    free(line);
    if (f != stdin) fclose(f);
    if (o->inum) maybe_add_rownum(t);
}

static InFmt guess_fmt(const char *path, InFmt fmt) {
    if (fmt != F_GUESS) return fmt;
    const char *p = path ? strrchr(path, '.') : NULL;
    if (!p) return F_CSV;
    if (!strcmp(p, ".json") || !strcmp(p, ".jsonl")) return F_JSON;
    if (!strcmp(p, ".yaml") || !strcmp(p, ".yml")) return F_YAML;
    if (!strcmp(p, ".ltsv")) return F_LTSV;
    if (!strcmp(p, ".tbln")) return F_TBLN;
    return F_CSV;
}

static char *quote_ident(const char *s) {
    char *out = xcalloc(strlen(s) * 2 + 3, 1);
    char *p = out;
    *p++ = '"';
    for (; *s; s++) {
        if (*s == '"') *p++ = '"';
        *p++ = *s;
    }
    *p++ = '"';
    return out;
}

static void sql_exec_or_die(sqlite3 *db, const char *sql) {
    char *err = NULL;
    if (sqlite3_exec(db, sql, NULL, NULL, &err) != 0) {
        fprintf(stderr, "trdsql: %s\n", err ? err : sqlite3_errmsg(db));
        if (err) sqlite3_free(err);
        exit(1);
    }
}

static void load_sqlite(sqlite3 *db, Table *t, Opt *o) {
    char *sql = xstrdup("CREATE TABLE t(");
    for (int i = 0; i < t->ncols; i++) {
        char *qi = quote_ident(t->cols[i]);
        char *tmp = xasprintf("%s%s%s TEXT", sql, i ? "," : "", qi);
        free(sql); free(qi); sql = tmp;
    }
    char *tmp = xasprintf("%s)", sql);
    free(sql); sql = tmp;
    sql_exec_or_die(db, sql);
    free(sql);

    for (int r = 0; r < t->nrows; r++) {
        sql = xstrdup("INSERT INTO t VALUES(");
        for (int c = 0; c < t->ncols; c++) {
            char *q = NULL;
            char *cell = t->rows[r].cells[c];
            if (cell && o->in_null && strcmp(cell, o->in_null) == 0) cell = NULL;
            q = cell ? sqlite3_mprintf("%Q", cell) : xstrdup("NULL");
            tmp = xasprintf("%s%s%s", sql, c ? "," : "", q);
            free(sql); sql = tmp;
            if (cell) sqlite3_free(q); else free(q);
        }
        tmp = xasprintf("%s)", sql);
        free(sql); sql = tmp;
        sql_exec_or_die(db, sql);
        free(sql);
    }
}

static bool ci_starts(const char *s, const char *kw) {
    while (*kw) {
        if (tolower((unsigned char)*s++) != tolower((unsigned char)*kw++)) return false;
    }
    return true;
}

static char *extract_from_path(const char *query) {
    const char *p = query;
    while (*p) {
        if ((p == query || !isalnum((unsigned char)p[-1])) && ci_starts(p, "from") && !isalnum((unsigned char)p[4])) {
            p += 4;
            while (isspace((unsigned char)*p)) p++;
            if (*p == '`' || *p == '"' || *p == '\'') {
                char q = *p++;
                const char *s = p;
                while (*p && *p != q) p++;
                return trim_dup(s, (size_t)(p - s));
            }
            const char *s = p;
            while (*p && !isspace((unsigned char)*p) && *p != ';') p++;
            return trim_dup(s, (size_t)(p - s));
        }
        p++;
    }
    return NULL;
}

static char *rewrite_query(const char *query) {
    const char *p = query;
    while (*p) {
        if ((p == query || !isalnum((unsigned char)p[-1])) && ci_starts(p, "from") && !isalnum((unsigned char)p[4])) {
            const char *before_end = p + 4;
            const char *after = before_end;
            while (isspace((unsigned char)*after)) after++;
            if (*after == '`' || *after == '"' || *after == '\'') {
                char q = *after++;
                while (*after && *after != q) after++;
                if (*after == q) after++;
            } else {
                while (*after && !isspace((unsigned char)*after) && *after != ';') after++;
            }
            size_t pre = (size_t)(before_end - query);
            return xasprintf("%.*s t%s", (int)pre, query, after);
        }
        p++;
    }
    return xstrdup(query);
}

typedef struct {
    char **names;
    char ***rows;
    int *isnull;
    int ncols;
    int nrows;
    int caprows;
} Result;

static void collect_result(sqlite3 *db, const char *query, Result *res) {
    sqlite3_stmt *st = NULL;
    if (sqlite3_prepare_v2(db, query, -1, &st, NULL) != 0) {
        fprintf(stderr, "trdsql: %s [%s]\n", sqlite3_errmsg(db), query);
        exit(1);
    }
    res->ncols = sqlite3_column_count(st);
    res->names = xcalloc((size_t)res->ncols, sizeof(char *));
    for (int i = 0; i < res->ncols; i++) res->names[i] = xstrdup(sqlite3_column_name(st, i));
    int rc;
    while ((rc = sqlite3_step(st)) == SQLITE_ROW) {
        if (res->nrows == res->caprows) {
            res->caprows = res->caprows ? res->caprows * 2 : 32;
            res->rows = realloc(res->rows, (size_t)res->caprows * sizeof(char **));
            res->isnull = realloc(res->isnull, (size_t)res->caprows * (size_t)res->ncols * sizeof(int));
        }
        char **row = xcalloc((size_t)res->ncols, sizeof(char *));
        for (int c = 0; c < res->ncols; c++) {
            int nullp = sqlite3_column_type(st, c) == SQLITE_NULL;
            res->isnull[res->nrows * res->ncols + c] = nullp;
            if (!nullp) row[c] = xstrdup((const char *)sqlite3_column_text(st, c));
        }
        res->rows[res->nrows++] = row;
    }
    if (rc != SQLITE_DONE) {
        fprintf(stderr, "trdsql: %s\n", sqlite3_errmsg(db));
        exit(1);
    }
    sqlite3_finalize(st);
}

static const char *cell(Result *r, Opt *o, int row, int col) {
    if (r->isnull[row * r->ncols + col]) return o->out_null ? o->out_null : "";
    return r->rows[row][col] ? r->rows[row][col] : "";
}

static void newline(FILE *out, Opt *o) { fputs(o->crlf ? "\r\n" : "\n", out); }

static void csv_field(FILE *out, const char *s, Opt *o) {
    bool need = o->oaq || strchr(s, o->out_delim[0]) || strchr(s, '\n') || strchr(s, '\r') || strchr(s, o->quote);
    if (!need) { fputs(s, out); return; }
    fputc(o->quote, out);
    for (; *s; s++) {
        if (*s == o->quote) fputc(o->quote, out);
        fputc(*s, out);
    }
    fputc(o->quote, out);
}

static void out_csv(FILE *out, Result *r, Opt *o) {
    if (o->oh) {
        for (int c = 0; c < r->ncols; c++) {
            if (c) fputs(o->out_delim, out);
            csv_field(out, r->names[c], o);
        }
        newline(out, o);
    }
    for (int i = 0; i < r->nrows; i++) {
        for (int c = 0; c < r->ncols; c++) {
            if (c) fputs(o->out_delim, out);
            csv_field(out, cell(r, o, i, c), o);
        }
        newline(out, o);
    }
}

static void json_escape(FILE *out, const char *s) {
    fputc('"', out);
    for (; *s; s++) {
        if (*s == '"' || *s == '\\') fprintf(out, "\\%c", *s);
        else if (*s == '\n') fputs("\\n", out);
        else if (*s == '\r') fputs("\\r", out);
        else if (*s == '\t') fputs("\\t", out);
        else fputc(*s, out);
    }
    fputc('"', out);
}

static void out_json(FILE *out, Result *r, Opt *o, bool lines) {
    if (!lines) fputs("[\n", out);
    for (int i = 0; i < r->nrows; i++) {
        if (!lines) fputs("  ", out);
        fputc('{', out);
        if (!lines && r->ncols) fputc('\n', out);
        for (int c = 0; c < r->ncols; c++) {
            if (!lines) fputs("    ", out);
            json_escape(out, r->names[c]);
            fputs(lines ? ":" : ": ", out);
            if (r->isnull[i * r->ncols + c] && !o->out_null) fputs("null", out);
            else json_escape(out, cell(r, o, i, c));
            if (c != r->ncols - 1) fputc(',', out);
            if (!lines) fputc('\n', out);
        }
        if (!lines) fputs("  ", out);
        fputc('}', out);
        if (!lines && i != r->nrows - 1) fputc(',', out);
        fputc('\n', out);
    }
    if (!lines) fputs("]\n", out);
}

static void out_ltsv(FILE *out, Result *r, Opt *o) {
    for (int i = 0; i < r->nrows; i++) {
        for (int c = 0; c < r->ncols; c++) {
            if (c) fputc('\t', out);
            fprintf(out, "%s:%s", r->names[c], cell(r, o, i, c));
        }
        newline(out, o);
    }
}

static int display_width(const char *s) { return (int)strlen(s); }

static void compute_widths(Result *r, Opt *o, int *w) {
    for (int c = 0; c < r->ncols; c++) w[c] = display_width(r->names[c]);
    for (int i = 0; i < r->nrows; i++) for (int c = 0; c < r->ncols; c++) {
        int n = display_width(cell(r, o, i, c));
        if (n > w[c]) w[c] = n;
    }
}

static bool numeric_col(Result *r, Opt *o, int c) {
    for (int i = 0; i < r->nrows; i++) {
        const char *s = cell(r, o, i, c);
        if (!*s) continue;
        char *end = NULL;
        strtod(s, &end);
        if (!end || *end) return false;
    }
    return true;
}

static void print_padded(FILE *out, const char *s, int w, bool right) {
    int n = display_width(s);
    int pad = w - n;
    if (right) for (int i = 0; i < pad; i++) fputc(' ', out);
    fputs(s, out);
    if (!right) for (int i = 0; i < pad; i++) fputc(' ', out);
}

static void sep_line(FILE *out, int *w, int ncols, bool plus) {
    fputc(plus ? '+' : '|', out);
    for (int c = 0; c < ncols; c++) {
        for (int i = 0; i < w[c] + 2; i++) fputc('-', out);
        fputc(plus ? '+' : '|', out);
    }
    fputc('\n', out);
}

static void out_table(FILE *out, Result *r, Opt *o, bool ascii) {
    int *w = xcalloc((size_t)r->ncols, sizeof(int));
    bool *num = xcalloc((size_t)r->ncols, sizeof(bool));
    compute_widths(r, o, w);
    for (int c = 0; c < r->ncols; c++) num[c] = numeric_col(r, o, c);
    if (ascii) sep_line(out, w, r->ncols, true);
    fputc('|', out);
    for (int c = 0; c < r->ncols; c++) {
        fputc(' ', out); print_padded(out, r->names[c], w[c], false); fputs(" |", out);
    }
    fputc('\n', out);
    if (ascii) sep_line(out, w, r->ncols, true);
    else sep_line(out, w, r->ncols, false);
    for (int i = 0; i < r->nrows; i++) {
        fputc('|', out);
        for (int c = 0; c < r->ncols; c++) {
            fputc(' ', out); print_padded(out, cell(r, o, i, c), w[c], num[c]); fputs(" |", out);
        }
        fputc('\n', out);
    }
    if (ascii) sep_line(out, w, r->ncols, true);
    free(w); free(num);
}

static void out_vf(FILE *out, Result *r, Opt *o) {
    for (int i = 0; i < r->nrows; i++) {
        fprintf(out, "---[ %d]------------------------", i + 1); newline(out, o);
        for (int c = 0; c < r->ncols; c++) {
            fprintf(out, "  %s | %s", r->names[c], cell(r, o, i, c));
            newline(out, o);
        }
    }
}

static bool yaml_plain_ok(const char *s) {
    if (!*s) return false;
    for (const char *p = s; *p; p++) {
        if (*p == ':' || *p == '#' || *p == '"' || *p == '\'' || *p == '\\' || *p == '\n' || *p == '\r' || *p == '\t') return false;
    }
    return true;
}

static void yaml_value(FILE *out, const char *s) {
    if (yaml_plain_ok(s)) fputs(s, out);
    else json_escape(out, s);
}

static void out_yaml(FILE *out, Result *r, Opt *o) {
    for (int i = 0; i < r->nrows; i++) {
        fputs("- ", out);
        for (int c = 0; c < r->ncols; c++) {
            if (c) fputs("  ", out);
            fprintf(out, "%s: ", r->names[c]);
            yaml_value(out, cell(r, o, i, c));
            fputc('\n', out);
        }
    }
}

static void out_tbln(FILE *out, Result *r, Opt *o) {
    fputs("; name: |", out);
    for (int c = 0; c < r->ncols; c++) fprintf(out, " %s |", r->names[c]);
    newline(out, o);
    fputs("; type: |", out);
    for (int c = 0; c < r->ncols; c++) fputs(" text |", out);
    newline(out, o);
    for (int i = 0; i < r->nrows; i++) {
        fputc('|', out);
        for (int c = 0; c < r->ncols; c++) fprintf(out, " %s |", cell(r, o, i, c));
        newline(out, o);
    }
}

static void output_result(FILE *out, Result *r, Opt *o) {
    switch (o->ofmt) {
        case O_CSV: out_csv(out, r, o); break;
        case O_JSON: out_json(out, r, o, false); break;
        case O_JSONL: out_json(out, r, o, true); break;
        case O_LTSV: out_ltsv(out, r, o); break;
        case O_MD: out_table(out, r, o, false); break;
        case O_AT: out_table(out, r, o, true); break;
        case O_RAW: out_csv(out, r, o); break;
        case O_TBLN: out_tbln(out, r, o); break;
        case O_VF: out_vf(out, r, o); break;
        case O_YAML: out_yaml(out, r, o); break;
    }
}

static void analyze_print(Table *t, const char *path, bool full) {
    if (full) {
        printf("The table name is %s.\n", path);
        printf("The file type is %s.\n\n", "CSV");
        puts("Data types:");
        puts("+-------------+------+");
        puts("| column name | type |");
        puts("+-------------+------+");
        for (int i = 0; i < t->ncols; i++) printf("| %-11s | text |\n", t->cols[i]);
        puts("+-------------+------+");
        puts("");
        puts("Data samples:");
        int *w = xcalloc((size_t)t->ncols, sizeof(int));
        for (int c = 0; c < t->ncols; c++) w[c] = (int)strlen(t->cols[c]);
        if (t->nrows) for (int c = 0; c < t->ncols; c++) {
            int n = (int)strlen(t->rows[0].cells[c] ? t->rows[0].cells[c] : "");
            if (n > w[c]) w[c] = n;
        }
        fputc('+', stdout);
        for (int c = 0; c < t->ncols; c++) { for (int k = 0; k < w[c] + 2; k++) fputc('-', stdout); fputc('+', stdout); }
        fputc('\n', stdout);
        fputc('|', stdout);
        for (int c = 0; c < t->ncols; c++) printf(" %-*s |", w[c], t->cols[c]);
        fputc('\n', stdout);
        fputc('+', stdout);
        for (int c = 0; c < t->ncols; c++) { for (int k = 0; k < w[c] + 2; k++) fputc('-', stdout); fputc('+', stdout); }
        fputc('\n', stdout);
        if (t->nrows) {
            fputc('|', stdout);
            for (int c = 0; c < t->ncols; c++) printf(" %-*s |", w[c], t->rows[0].cells[c] ? t->rows[0].cells[c] : "");
            fputc('\n', stdout);
        }
        fputc('+', stdout);
        for (int c = 0; c < t->ncols; c++) { for (int k = 0; k < w[c] + 2; k++) fputc('-', stdout); fputc('+', stdout); }
        fputs("\n\n", stdout);
        free(w);
        puts("Examples:");
    }
    if (t->ncols > 0) {
        char *cols = xstrdup("");
        for (int i = 0; i < t->ncols; i++) {
            char *tmp = xasprintf("%s%s%s", cols, i ? ", " : "", t->cols[i]);
            free(cols); cols = tmp;
        }
        const char *first = t->nrows && t->rows[0].cells[0] ? t->rows[0].cells[0] : "";
        printf("./executable \"SELECT %s FROM %s\"\n", cols, path);
        printf("./executable \"SELECT %s FROM %s WHERE %s = '%s'\"\n", cols, path, t->cols[0], first);
        printf("./executable \"SELECT %s, count(%s) FROM %s GROUP BY %s\"\n", t->cols[0], t->cols[0], path, t->cols[0]);
        printf("./executable \"SELECT %s FROM %s ORDER BY %s LIMIT 10\"\n", cols, path, t->cols[0]);
        free(cols);
    }
}

static char *read_file_text(const char *path) {
    char *s = read_all(path);
    size_t n = strlen(s);
    while (n && isspace((unsigned char)s[n - 1])) s[--n] = 0;
    return s;
}

static void init_opt(Opt *o) {
    memset(o, 0, sizeof(*o));
    o->ifmt = F_GUESS;
    o->ofmt = O_CSV;
    o->in_delim = ",";
    o->out_delim = ",";
    o->quote = '"';
}

static bool need_arg(int *i, int argc, char **argv) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "flag needs an argument: %s\n", argv[*i]);
        exit(2);
    }
    (*i)++;
    return true;
}

static int parse_int_arg(const char *s) { return s ? atoi(s) : 0; }

int main(int argc, char **argv) {
    Opt opt;
    init_opt(&opt);
    char *query = NULL;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-help") || !strcmp(a, "--help")) { fputs(help_text, stdout); return 2; }
        if (!strcmp(a, "-h")) { fputs(help_text, stdout); return 0; }
        else if (!strcmp(a, "-version") || !strcmp(a, "--version")) { puts("trdsql version devel"); return 0; }
        else if (!strcmp(a, "-dblist")) { return 0; }
        else if (!strcmp(a, "-q")) { need_arg(&i, argc, argv); opt.query_file = argv[i]; }
        else if (!strcmp(a, "-t")) { need_arg(&i, argc, argv); opt.table_file = argv[i]; }
        else if (!strcmp(a, "-out")) { need_arg(&i, argc, argv); opt.out_file = argv[i]; }
        else if (!strcmp(a, "-id")) { need_arg(&i, argc, argv); opt.in_delim = argv[i]; }
        else if (!strcmp(a, "-od")) { need_arg(&i, argc, argv); opt.out_delim = argv[i]; }
        else if (!strcmp(a, "-oq")) { need_arg(&i, argc, argv); opt.quote = argv[i][0] ? argv[i][0] : '"'; }
        else if (!strcmp(a, "-is")) { need_arg(&i, argc, argv); opt.skip = parse_int_arg(argv[i]); }
        else if (!strcmp(a, "-ilr")) { need_arg(&i, argc, argv); opt.limit_read = parse_int_arg(argv[i]); }
        else if (!strcmp(a, "-inull")) { need_arg(&i, argc, argv); opt.in_null = argv[i]; }
        else if (!strcmp(a, "-onull")) { need_arg(&i, argc, argv); opt.out_null = argv[i]; }
        else if (!strcmp(a, "-a") || !strcmp(a, "-A")) {
            opt.analyze = !strcmp(a, "-a") ? 1 : 2;
            need_arg(&i, argc, argv);
            opt.analyze_file = argv[i];
        }
        else if (!strcmp(a, "-ijq") || !strcmp(a, "-ir") || !strcmp(a, "-config") || !strcmp(a, "-db") || !strcmp(a, "-driver") || !strcmp(a, "-dsn") || !strcmp(a, "-oz")) {
            need_arg(&i, argc, argv);
        }
        else if (!strcmp(a, "-icsv")) opt.ifmt = F_CSV;
        else if (!strcmp(a, "-iltsv")) opt.ifmt = F_LTSV;
        else if (!strcmp(a, "-ijson")) opt.ifmt = F_JSON;
        else if (!strcmp(a, "-iyaml")) opt.ifmt = F_YAML;
        else if (!strcmp(a, "-itext") || !strcmp(a, "-iwidth")) opt.ifmt = F_TEXT;
        else if (!strcmp(a, "-itbln")) opt.ifmt = F_TBLN;
        else if (!strcmp(a, "-ig")) opt.ifmt = F_GUESS;
        else if (!strcmp(a, "-ih")) opt.ih = true;
        else if (!strcmp(a, "-inum")) opt.inum = true;
        else if (!strcmp(a, "-oh")) opt.oh = true;
        else if (!strcmp(a, "-oaq")) opt.oaq = true;
        else if (!strcmp(a, "-ocrlf")) opt.crlf = true;
        else if (!strcmp(a, "-ocsv")) opt.ofmt = O_CSV;
        else if (!strcmp(a, "-ojson")) opt.ofmt = O_JSON;
        else if (!strcmp(a, "-ojsonl")) opt.ofmt = O_JSONL;
        else if (!strcmp(a, "-oltsv")) opt.ofmt = O_LTSV;
        else if (!strcmp(a, "-omd")) opt.ofmt = O_MD;
        else if (!strcmp(a, "-oat")) opt.ofmt = O_AT;
        else if (!strcmp(a, "-oraw")) opt.ofmt = O_RAW;
        else if (!strcmp(a, "-otbln")) opt.ofmt = O_TBLN;
        else if (!strcmp(a, "-ovf")) opt.ofmt = O_VF;
        else if (!strcmp(a, "-oyaml")) opt.ofmt = O_YAML;
        else if (!strcmp(a, "-out-without-guess")) opt.out_without_guess = true;
        else if (!strcmp(a, "-debug") || !strcmp(a, "-onowrap")) {}
        else if (a[0] == '-' && !strncmp(a, "-o", 2) && strlen(a) > 2) {
            char *fmt = a + 2;
            if (!strcmp(fmt, "csv")) opt.ofmt = O_CSV;
            else if (!strcmp(fmt, "json")) opt.ofmt = O_JSON;
            else if (!strcmp(fmt, "jsonl")) opt.ofmt = O_JSONL;
            else if (!strcmp(fmt, "ltsv")) opt.ofmt = O_LTSV;
            else if (!strcmp(fmt, "md")) opt.ofmt = O_MD;
            else if (!strcmp(fmt, "at")) opt.ofmt = O_AT;
            else if (!strcmp(fmt, "raw")) opt.ofmt = O_RAW;
            else if (!strcmp(fmt, "tbln")) opt.ofmt = O_TBLN;
            else if (!strcmp(fmt, "vf")) opt.ofmt = O_VF;
            else if (!strcmp(fmt, "yaml")) opt.ofmt = O_YAML;
        } else if (!query) {
            query = a;
        }
    }
    if (opt.out_file && !opt.out_without_guess) {
        const char *e = strrchr(opt.out_file, '.');
        if (e) {
            if (!strcmp(e, ".json")) opt.ofmt = O_JSON;
            else if (!strcmp(e, ".jsonl")) opt.ofmt = O_JSONL;
            else if (!strcmp(e, ".ltsv")) opt.ofmt = O_LTSV;
            else if (!strcmp(e, ".md")) opt.ofmt = O_MD;
            else if (!strcmp(e, ".tbln")) opt.ofmt = O_TBLN;
            else if (!strcmp(e, ".yaml") || !strcmp(e, ".yml")) opt.ofmt = O_YAML;
        }
    }
    if (opt.analyze) {
        Table table = {0};
        InFmt fmt = guess_fmt(opt.analyze_file, opt.ifmt);
        if (fmt == F_LTSV) load_ltsv(&table, opt.analyze_file, &opt);
        else if (fmt == F_JSON) load_json(&table, opt.analyze_file, &opt);
        else if (fmt == F_YAML) load_yaml(&table, opt.analyze_file, &opt);
        else if (fmt == F_TEXT) load_text(&table, opt.analyze_file, &opt);
        else if (fmt == F_TBLN) load_tbln(&table, opt.analyze_file, &opt);
        else load_csv(&table, opt.analyze_file, &opt);
        analyze_print(&table, opt.analyze_file, opt.analyze == 1);
        return 0;
    }
    if (opt.query_file) query = read_file_text(opt.query_file);
    char *owned_query = NULL;
    if (!query && opt.table_file) {
        owned_query = xasprintf("SELECT * FROM `%s`", opt.table_file);
        query = owned_query;
    }
    if (!query) {
        fputs(help_text, stdout);
        return 2;
    }
    char *path = opt.table_file ? xstrdup(opt.table_file) : extract_from_path(query);
    if (!path || !*path) {
        fprintf(stderr, "trdsql: no input table\n");
        return 1;
    }
    char *jq = strstr(path, "::");
    if (jq) *jq = 0;

    Table table = {0};
    InFmt fmt = guess_fmt(path, opt.ifmt);
    if (fmt == F_LTSV) load_ltsv(&table, path, &opt);
    else if (fmt == F_JSON) load_json(&table, path, &opt);
    else if (fmt == F_YAML) load_yaml(&table, path, &opt);
    else if (fmt == F_TEXT) load_text(&table, path, &opt);
    else if (fmt == F_TBLN) load_tbln(&table, path, &opt);
    else load_csv(&table, path, &opt);

    sqlite3 *db = NULL;
    if (sqlite3_open(":memory:", &db) != 0) {
        fprintf(stderr, "trdsql: cannot open sqlite database\n");
        return 1;
    }
    load_sqlite(db, &table, &opt);
    char *sql = rewrite_query(query);
    Result res = {0};
    collect_result(db, sql, &res);
    FILE *out = stdout;
    if (opt.out_file) {
        out = fopen(opt.out_file, "w");
        if (!out) { fprintf(stderr, "trdsql: %s: %s\n", opt.out_file, strerror(errno)); return 1; }
    }
    output_result(out, &res, &opt);
    if (out != stdout) fclose(out);
    sqlite3_close(db);
    free(sql); free(path); free(owned_query);
    return 0;
}
