#define _XOPEN_SOURCE 700
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

typedef struct Node Node;
struct Node {
    char *name;
    char *path;
    uint64_t size;
    int is_dir;
    Node **children;
    size_t nchild, cap;
};

typedef struct {
    int depth_set;
    int depth;
    int aggr_set;
    uint64_t aggr;
    int usage;
    int bytes;
    int files_only;
    int no_hidden;
    int ascii;
    char **excludes;
    int nexcludes;
} Opt;

static const char *HELP =
"Usage: ./executable [options] <path> [<path>..]\n\n"
"Options:\n"
"    -d, --depth [DEPTH] show directories up to depth N (def 1)\n"
"    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)\n"
"    -s, --summary       equivalent to -da, or -d1 -a1M\n"
"    -u, --usage         report real disk usage instead of file size\n"
"    -b, --bytes         print sizes in bytes\n"
"    -f, --files-only    skip directories for a fast local overview\n"
"    -x, --exclude NAME  exclude matching files or directories\n"
"    -H, --no-hidden     exclude hidden files\n"
"    -A, --ascii         ASCII characters only, no colors\n"
"    -h, --help          show help\n"
"    -v, --version       print version number\n";

static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) exit(2); return p; }

static const char *base_name(const char *p) {
    if (!strcmp(p, ".")) {
        static char cwdbuf[PATH_MAX];
        if (getcwd(cwdbuf, sizeof(cwdbuf))) return base_name(cwdbuf);
    }
    size_t n = strlen(p);
    while (n > 1 && p[n-1] == '/') n--;
    const char *end = p + n;
    const char *b = end;
    while (b > p && b[-1] != '/') b--;
    static char buf[PATH_MAX];
    size_t len = (size_t)(end - b);
    if (len == 0) return ".";
    if (len >= sizeof(buf)) len = sizeof(buf)-1;
    memcpy(buf, b, len); buf[len] = 0;
    return buf;
}

static int is_number(const char *s) {
    if (!s || !*s) return 0;
    for (; *s; s++) if (*s < '0' || *s > '9') return 0;
    return 1;
}

static int parse_u64(const char *s, uint64_t *out, int allow_suffix) {
    if (!s || !*s) return 0;
    char *end = NULL;
    errno = 0;
    unsigned long long v = strtoull(s, &end, 10);
    if (errno || end == s) return 0;
    uint64_t mult = 1;
    if (*end) {
        if (!allow_suffix || end[1]) return 0;
        if (*end == 'K' || *end == 'k') mult = 1024ULL;
        else if (*end == 'M' || *end == 'm') mult = 1024ULL*1024ULL;
        else if (*end == 'G' || *end == 'g') mult = 1024ULL*1024ULL*1024ULL;
        else return 0;
    }
    *out = (uint64_t)v * mult;
    return 1;
}

static int excluded(Opt *o, const char *name) {
    if (o->no_hidden && name[0] == '.') return 1;
    for (int i = 0; i < o->nexcludes; i++) {
        if (strcmp(name, o->excludes[i]) == 0) return 1;
        if (strstr(name, o->excludes[i])) return 1;
    }
    return 0;
}

static void add_child(Node *n, Node *c) {
    if (n->nchild == n->cap) {
        n->cap = n->cap ? n->cap * 2 : 8;
        n->children = realloc(n->children, n->cap * sizeof(Node*));
        if (!n->children) exit(2);
    }
    n->children[n->nchild++] = c;
}

static Node *new_node(const char *path, const char *name) {
    Node *n = calloc(1, sizeof(Node));
    if (!n) exit(2);
    n->path = xstrdup(path);
    n->name = xstrdup(name);
    return n;
}

static uint64_t stat_size(const struct stat *st, int usage) {
    if (usage) return (uint64_t)st->st_blocks * 512ULL;
    return (uint64_t)st->st_size;
}

static int cmp_node(const void *a, const void *b) {
    const Node *na = *(const Node * const *)a;
    const Node *nb = *(const Node * const *)b;
    if (na->size < nb->size) return 1;
    if (na->size > nb->size) return -1;
    return strcmp(na->name, nb->name);
}

static Node *scan_path(const char *path, const char *name, Opt *o, int root) {
    struct stat st;
    if (lstat(path, &st) != 0) return NULL;
    Node *n = new_node(path, name);
    n->is_dir = S_ISDIR(st.st_mode);
    n->size = stat_size(&st, o->usage);
    if (n->is_dir && !o->files_only) {
        DIR *d = opendir(path);
        if (d) {
            struct dirent *de;
            while ((de = readdir(d)) != NULL) {
                if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
                if (excluded(o, de->d_name)) continue;
                char childpath[PATH_MAX];
                int r = snprintf(childpath, sizeof(childpath), "%s/%s", path, de->d_name);
                if (r < 0 || (size_t)r >= sizeof(childpath)) continue;
                struct stat cst;
                if (lstat(childpath, &cst) != 0) continue;
                if (o->files_only && S_ISDIR(cst.st_mode)) continue;
                Node *c = scan_path(childpath, de->d_name, o, 0);
                if (c) { n->size += c->size; add_child(n, c); }
            }
            closedir(d);
        }
        if (n->nchild) qsort(n->children, n->nchild, sizeof(Node*), cmp_node);
    } else if (n->is_dir && o->files_only && root) {
        DIR *d = opendir(path);
        if (d) {
            struct dirent *de;
            while ((de = readdir(d)) != NULL) {
                if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
                if (excluded(o, de->d_name)) continue;
                char childpath[PATH_MAX];
                int r = snprintf(childpath, sizeof(childpath), "%s/%s", path, de->d_name);
                if (r < 0 || (size_t)r >= sizeof(childpath)) continue;
                struct stat cst;
                if (lstat(childpath, &cst) != 0 || S_ISDIR(cst.st_mode)) continue;
                Node *c = new_node(childpath, de->d_name);
                c->is_dir = 0; c->size = stat_size(&cst, o->usage);
                n->size += c->size; add_child(n, c);
            }
            closedir(d);
        }
        if (n->nchild) qsort(n->children, n->nchild, sizeof(Node*), cmp_node);
    }
    return n;
}

static void free_node(Node *n) {
    if (!n) return;
    for (size_t i = 0; i < n->nchild; i++) free_node(n->children[i]);
    free(n->children); free(n->name); free(n->path); free(n);
}

static void fmt_size(uint64_t v, int bytes, char *buf, size_t len) {
    if (bytes) { snprintf(buf, len, "%llu B", (unsigned long long)v); return; }
    const char *units[] = {"B", "KiB", "MiB", "GiB", "TiB"};
    double x = (double)v; int u = 0;
    while (x >= 1024.0 && u < 4) { x /= 1024.0; u++; }
    if (u == 0) snprintf(buf, len, "%llu B", (unsigned long long)v);
    else snprintf(buf, len, "%.2f %s", x, units[u]);
}

static void print_name_col(const char *prefix, const char *branch, const char *name) {
    char temp[256];
    snprintf(temp, sizeof(temp), "%s%s%s", prefix, branch, name);
    int width = 26;
    int len = 0;
    for (const unsigned char *p = (const unsigned char *)temp; *p; p++) {
        if ((*p & 0xc0) != 0x80) len++;
    }
    if (len > width) {
        fwrite(temp, 1, width, stdout);
    } else {
        fputs(temp, stdout);
        for (int i = len; i < width; i++) putchar(' ');
    }
}

static void print_bar(uint64_t size, uint64_t parent, uint64_t maxsib, int ascii) {
    int pct = parent ? (int)((size * 100ULL) / parent) : 0;
    int fill = maxsib ? (int)((size * 32ULL) / maxsib) : 0;
    if (fill > 32) fill = 32;
    const char *ch = ascii ? "#" : "█";
    for (int i = 0; i < 32; i++) {
        if (i >= 32 - fill) fputs(ch, stdout); else putchar(' ');
    }
    printf("│%4d%%", pct);
}

static void print_line(const char *prefix, const char *branch, const char *name, uint64_t size, uint64_t parent, uint64_t maxsib, Opt *o) {
    char sbuf[64]; fmt_size(size, o->bytes, sbuf, sizeof(sbuf));
    print_name_col(prefix, branch, name);
    fputs("│ ", stdout);
    print_bar(size, parent, maxsib, o->ascii);
    printf(" %13s\n", sbuf);
}

static void print_children(Node *n, Opt *o, int level, const char *prefix) {
    if (o->depth_set && level >= o->depth) return;
    size_t visible = 0;
    uint64_t agsum = 0;
    uint64_t maxsib = 0;
    for (size_t i = 0; i < n->nchild; i++) {
        if (o->aggr_set && n->children[i]->size < o->aggr) agsum += n->children[i]->size;
        else {
            visible++;
            if (n->children[i]->size > maxsib) maxsib = n->children[i]->size;
        }
    }
    if (agsum > maxsib) maxsib = agsum;
    int total = (int)visible + (agsum ? 1 : 0);
    int idx = 0;
    for (size_t i = 0; i < n->nchild; i++) {
        Node *c = n->children[i];
        if (o->aggr_set && c->size < o->aggr) continue;
        idx++;
        int last = (idx == total);
        const char *branch = last ? "└─ " : "├─ ";
        print_line(prefix, branch, c->name, c->size, n->size, maxsib, o);
        char nprefix[512];
        snprintf(nprefix, sizeof(nprefix), "%s%s", prefix, last ? "   " : "│  ");
        print_children(c, o, level+1, nprefix);
    }
    if (agsum) {
        idx++;
        print_line(prefix, "└─ ", "<aggregated>", agsum, n->size, maxsib, o);
    }
}

static Node *collection(Node **roots, int n) {
    Node *c = new_node("", "<collection>"); c->is_dir = 1;
    for (int i = 0; i < n; i++) { c->size += roots[i]->size; add_child(c, roots[i]); }
    if (c->nchild) qsort(c->children, c->nchild, sizeof(Node*), cmp_node);
    return c;
}

static int is_option(const char *s) { return s && s[0] == '-' && s[1]; }

int main(int argc, char **argv) {
    Opt o; memset(&o, 0, sizeof(o));
    char **paths = calloc(argc + 1, sizeof(char*)); int npaths = 0;
    o.excludes = calloc(argc + 1, sizeof(char*));
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { fputs(HELP, stdout); return 0; }
        else if (!strcmp(a, "-v") || !strcmp(a, "--version")) { puts("dutree version 0.2.18"); return 0; }
        else if (!strcmp(a, "-A") || !strcmp(a, "--ascii")) o.ascii = 1;
        else if (!strcmp(a, "-u") || !strcmp(a, "--usage")) o.usage = 1;
        else if (!strcmp(a, "-b") || !strcmp(a, "--bytes")) o.bytes = 1;
        else if (!strcmp(a, "-f") || !strcmp(a, "--files-only")) o.files_only = 1;
        else if (!strcmp(a, "-H") || !strcmp(a, "--no-hidden")) o.no_hidden = 1;
        else if (!strcmp(a, "-s") || !strcmp(a, "--summary")) { o.depth_set = 1; o.depth = 1; o.aggr_set = 1; o.aggr = 1024ULL*1024ULL; }
        else if (!strcmp(a, "-da")) { o.depth_set = 1; o.depth = 1; o.aggr_set = 1; o.aggr = 1024ULL*1024ULL; }
        else if (!strcmp(a, "-d") || !strcmp(a, "--depth")) {
            o.depth_set = 1; o.depth = 1;
            if (i + 1 < argc && is_number(argv[i+1])) { o.depth = atoi(argv[++i]); }
            else if (i + 1 < argc && !is_option(argv[i+1])) { i++; }
        } else if (!strncmp(a, "-d", 2) && a[2]) {
            uint64_t v; if (!parse_u64(a+2, &v, 0)) { fprintf(stderr, "invalid argument '%s'\n", a+2); return 1; }
            o.depth_set = 1; o.depth = (int)v;
        } else if (!strncmp(a, "--depth=", 8)) {
            uint64_t v; if (!parse_u64(a+8, &v, 0)) { fprintf(stderr, "invalid argument '%s'\n", a+8); return 1; }
            o.depth_set = 1; o.depth = (int)v;
        } else if (!strcmp(a, "-a") || !strcmp(a, "--aggr")) {
            if (i + 1 >= argc) { o.aggr_set = 1; o.aggr = 1024ULL*1024ULL; }
            else { uint64_t v; if (!parse_u64(argv[i+1], &v, 1)) { fprintf(stderr, "invalid argument '%s'\n", argv[i+1]); return 1; } i++; o.aggr_set = 1; o.aggr = v; }
        } else if (!strncmp(a, "-a", 2) && a[2]) {
            uint64_t v; if (!parse_u64(a+2, &v, 1)) { fprintf(stderr, "invalid argument '%s'\n", a+2); return 1; }
            o.aggr_set = 1; o.aggr = v;
        } else if (!strncmp(a, "--aggr=", 7)) {
            uint64_t v; if (!parse_u64(a+7, &v, 1)) { fprintf(stderr, "invalid argument '%s'\n", a+7); return 1; }
            o.aggr_set = 1; o.aggr = v;
        } else if (!strcmp(a, "-x") || !strcmp(a, "--exclude")) {
            if (i + 1 >= argc) { fprintf(stderr, "Option '%s' requires an argument\n", a); return 1; }
            o.excludes[o.nexcludes++] = argv[++i];
        } else if (!strncmp(a, "--exclude=", 10)) o.excludes[o.nexcludes++] = a + 10;
        else if (is_option(a)) { fprintf(stderr, "Unrecognized option: '%c'\n%s", a[1], HELP); return 1; }
        else paths[npaths++] = a;
    }
    if (npaths == 0) paths[npaths++] = ".";
    Node **roots = calloc(npaths, sizeof(Node*)); int nr = 0;
    for (int i = 0; i < npaths; i++) {
        struct stat st;
        if (lstat(paths[i], &st) != 0) { fprintf(stderr, "path %s doesn't exist\n", paths[i]); continue; }
        roots[nr] = scan_path(paths[i], base_name(paths[i]), &o, 1);
        if (roots[nr]) nr++;
    }
    if (nr == 0) return 1;
    Node *root;
    if (nr == 1) root = roots[0]; else root = collection(roots, nr);
    char sbuf[64]; fmt_size(root->size, o.bytes, sbuf, sizeof(sbuf));
    printf("[ %s %s ]\n", root->name, sbuf);
    print_children(root, &o, 0, "");
    if (nr == 1) free_node(root); else { free(root->children); free(root->name); free(root->path); free(root); for (int i=0;i<nr;i++) free_node(roots[i]); }
    free(roots); free(paths); free(o.excludes);
    return 0;
}
