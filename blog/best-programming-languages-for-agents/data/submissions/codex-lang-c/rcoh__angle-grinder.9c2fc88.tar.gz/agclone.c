#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <regex.h>

typedef enum { V_STRING, V_NUMBER, V_BOOL, V_NULL, V_ARRAY } VType;

typedef struct {
    char *key;
    char *s;
    double n;
    VType type;
} Field;

typedef struct {
    Field *f;
    int len, cap;
    char *raw;
    bool drop;
} Row;

typedef struct {
    Row *rows;
    int len, cap;
} Rows;

typedef struct {
    char *name;
    char *arg;
    char *alias;
    char *cond;
    double sum, min, max;
    int count;
    double *vals;
    int vlen, vcap;
    char **distinct;
    int dlen, dcap;
} AggSpec;

typedef struct {
    char **keys;
    int klen;
    char *key_join;
    Field *out;
    int olen, ocap;
    AggSpec *aggs;
    int alen;
} Group;

static char *xstrdup(const char *s) { return strdup(s ? s : ""); }
static void *xrealloc(void *p, size_t n) { void *r = realloc(p, n); if (!r) { perror("realloc"); exit(2); } return r; }

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool starts_ci(const char *s, const char *p) {
    while (*p) { if (tolower((unsigned char)*s++) != tolower((unsigned char)*p++)) return false; }
    return true;
}

static int cmp_field(const void *a, const void *b) {
    const Field *fa = a, *fb = b;
    return strcmp(fa->key, fb->key);
}

static void row_add(Row *r, const char *k, const char *v, VType t) {
    if (!k || !*k) return;
    for (int i = 0; i < r->len; i++) {
        if (!strcmp(r->f[i].key, k)) {
            free(r->f[i].s);
            r->f[i].s = xstrdup(v);
            r->f[i].type = t;
            char *end = NULL; errno = 0; double d = strtod(v, &end);
            if (end && *trim(end) == 0 && errno == 0 && *v) { r->f[i].n = d; if (t == V_STRING) r->f[i].type = V_NUMBER; }
            return;
        }
    }
    if (r->len == r->cap) { r->cap = r->cap ? r->cap * 2 : 8; r->f = xrealloc(r->f, r->cap * sizeof(Field)); }
    Field *f = &r->f[r->len++];
    f->key = xstrdup(k); f->s = xstrdup(v); f->type = t; f->n = 0;
    char *end = NULL; errno = 0; double d = strtod(v, &end);
    if (end && *trim(end) == 0 && errno == 0 && *v && t == V_STRING) { f->type = V_NUMBER; f->n = d; }
    else if (t == V_NUMBER) f->n = d;
}

static Field *row_get(Row *r, const char *k) {
    if (!k) return NULL;
    if (!strcmp(k, "_raw")) { static Field raw; raw.key = "_raw"; raw.type = V_STRING; raw.n = 0; raw.s = NULL; raw.s = r->raw ? r->raw : ""; return &raw; }
    for (int i = 0; i < r->len; i++) if (!strcmp(r->f[i].key, k)) return &r->f[i];
    return NULL;
}

static char *field_value(Row *r, const char *k) {
    Field *f = row_get(r, k);
    return f ? f->s : "";
}

static bool is_num_str(const char *s, double *out) {
    if (!s || !*s) return false;
    char *end = NULL; errno = 0; double d = strtod(s, &end);
    if (errno || !end || *trim(end)) return false;
    if (out) *out = d;
    return true;
}

static void rows_add(Rows *rs, Row r) {
    if (rs->len == rs->cap) { rs->cap = rs->cap ? rs->cap * 2 : 64; rs->rows = xrealloc(rs->rows, rs->cap * sizeof(Row)); }
    rs->rows[rs->len++] = r;
}

static char *unquote(char *s) {
    s = trim(s);
    size_t n = strlen(s);
    if ((n >= 2 && s[0] == '"' && s[n-1] == '"') || (n >= 2 && s[0] == '\'' && s[n-1] == '\'')) {
        s[n-1] = 0; s++;
        char *w = s;
        for (char *p = s; *p; p++) {
            if (*p == '\\' && p[1]) p++;
            *w++ = *p;
        }
        *w = 0;
    }
    return s;
}

static char **split_commas(char *s, int *outn) {
    char **a = NULL; int n = 0, cap = 0, depth = 0; bool q = false; char qc = 0;
    char *start = s;
    for (char *p = s; ; p++) {
        char c = *p;
        if (q) { if (c == '\\' && p[1]) p++; else if (c == qc) q = false; }
        else if (c == '"' || c == '\'') { q = true; qc = c; }
        else if (c == '(') depth++;
        else if (c == ')' && depth) depth--;
        if ((!c || (c == ',' && depth == 0 && !q))) {
            char old = *p; *p = 0;
            if (n == cap) { cap = cap ? cap * 2 : 4; a = xrealloc(a, cap * sizeof(char*)); }
            a[n++] = xstrdup(trim(start));
            *p = old;
            if (!c) break;
            start = p + 1;
        }
    }
    *outn = n; return a;
}

static void parse_logfmt(Row *r, const char *text) {
    const char *p = text;
    while (*p) {
        while (isspace((unsigned char)*p)) p++;
        const char *ks = p;
        while (*p && *p != '=' && !isspace((unsigned char)*p)) p++;
        if (*p != '=') { while (*p && !isspace((unsigned char)*p)) p++; continue; }
        char *k = strndup(ks, p - ks); p++;
        char *v = NULL;
        if (*p == '"') {
            p++; const char *vs = p; char *buf = malloc(strlen(p) + 1), *w = buf;
            while (*p && *p != '"') { if (*p == '\\' && p[1]) p++; *w++ = *p++; }
            *w = 0; if (*p == '"') p++; v = buf; (void)vs;
        } else {
            const char *vs = p;
            while (*p && !isspace((unsigned char)*p)) p++;
            v = strndup(vs, p - vs);
        }
        row_add(r, k, v, V_STRING);
        free(k); free(v);
    }
}

static void skip_ws(const char **p) { while (isspace((unsigned char)**p)) (*p)++; }
static char *json_string(const char **p) {
    if (**p != '"') return NULL; (*p)++;
    char *buf = malloc(strlen(*p) + 1), *w = buf;
    while (**p && **p != '"') {
        if (**p == '\\') {
            (*p)++;
            char c = **p;
            if (c == 'n') *w++ = '\n'; else if (c == 't') *w++ = '\t'; else if (c == 'r') *w++ = '\r'; else if (c) *w++ = c;
            if (c) (*p)++;
        } else *w++ = *(*p)++;
    }
    if (**p == '"') (*p)++;
    *w = 0; return buf;
}

static char *json_scalar(const char **p, VType *t);
static void json_object(Row *r, const char **p, const char *prefix);
static char *join_key(const char *a, const char *b) {
    if (!a || !*a) return xstrdup(b);
    char *s = malloc(strlen(a) + strlen(b) + 2);
    sprintf(s, "%s.%s", a, b); return s;
}

static void json_array(Row *r, const char **p, const char *prefix) {
    if (**p != '[') return; (*p)++; int idx = 0;
    char flat[8192] = ""; bool first = true;
    while (**p) {
        skip_ws(p); if (**p == ']') { (*p)++; break; }
        VType t = V_STRING; char *v = NULL;
        if (**p == '{') {
            char id[64]; snprintf(id, sizeof(id), "%d", idx);
            char *pre = join_key(prefix, id); json_object(r, p, pre); free(pre); v = xstrdup("");
        } else if (**p == '[') { v = xstrdup(""); json_array(r, p, prefix); }
        else v = json_scalar(p, &t);
        if (v && *v) {
            if (!first) strncat(flat, ", ", sizeof(flat)-strlen(flat)-1);
            strncat(flat, v, sizeof(flat)-strlen(flat)-1); first = false;
        }
        free(v); skip_ws(p); if (**p == ',') { (*p)++; idx++; }
    }
    char wrap[8300]; snprintf(wrap, sizeof(wrap), "[%s]", flat);
    row_add(r, prefix, wrap, V_ARRAY);
}

static char *json_scalar(const char **p, VType *t) {
    skip_ws(p);
    if (**p == '"') { *t = V_STRING; return json_string(p); }
    const char *s = *p;
    if (starts_ci(s, "true")) { *p += 4; *t = V_BOOL; return xstrdup("true"); }
    if (starts_ci(s, "false")) { *p += 5; *t = V_BOOL; return xstrdup("false"); }
    if (starts_ci(s, "null")) { *p += 4; *t = V_NULL; return xstrdup("null"); }
    while (**p && !strchr(",}] \t\r\n", **p)) (*p)++;
    *t = V_NUMBER; return strndup(s, *p - s);
}

static void json_object(Row *r, const char **p, const char *prefix) {
    if (**p != '{') return; (*p)++;
    while (**p) {
        skip_ws(p); if (**p == '}') { (*p)++; break; }
        char *k = json_string(p); if (!k) break;
        skip_ws(p); if (**p == ':') (*p)++; skip_ws(p);
        char *full = join_key(prefix, k);
        if (**p == '{') json_object(r, p, full);
        else if (**p == '[') json_array(r, p, full);
        else { VType t; char *v = json_scalar(p, &t); row_add(r, full, v, t); free(v); }
        free(k); free(full); skip_ws(p); if (**p == ',') (*p)++;
    }
}

static bool parse_json(Row *r, const char *text) {
    const char *p = text; skip_ws(&p);
    if (*p != '{') return false;
    json_object(r, &p, "");
    return true;
}

static bool wildcard_ci(const char *pat, const char *s) {
    if (!*pat) return !*s;
    if (*pat == '*') {
        while (*pat == '*') pat++;
        if (!*pat) return true;
        for (; *s; s++) if (wildcard_ci(pat, s)) return true;
        return false;
    }
    if (!*s) return false;
    if (tolower((unsigned char)*pat) == tolower((unsigned char)*s)) return wildcard_ci(pat+1, s+1);
    return false;
}

static bool contains_ci_wild(const char *line, const char *tok) {
    if (!strcmp(tok, "*")) return true;
    if (strchr(tok, '*')) {
        for (const char *p = line; *p; p++) if (wildcard_ci(tok, p)) return true;
        return wildcard_ci(tok, line + strlen(line));
    }
    size_t n = strlen(tok);
    for (const char *p = line; *p; p++) if (!strncasecmp(p, tok, n)) return true;
    return n == 0;
}

static char **filter_toks; static int filter_ntok, filter_pos; static const char *filter_line;
static bool eval_filter_expr(void);
static bool eval_filter_atom(void) {
    if (filter_pos >= filter_ntok) return true;
    char *t = filter_toks[filter_pos++];
    if (!strcmp(t, "(")) { bool v = eval_filter_expr(); if (filter_pos < filter_ntok && !strcmp(filter_toks[filter_pos], ")")) filter_pos++; return v; }
    if (!strcasecmp(t, "NOT")) return !eval_filter_atom();
    size_t n = strlen(t);
    if (n >= 2 && t[0] == '"' && t[n-1] == '"') { t[n-1] = 0; return strstr(filter_line, t+1) != NULL; }
    return contains_ci_wild(filter_line, t);
}
static bool eval_filter_and(void) {
    bool v = eval_filter_atom();
    while (filter_pos < filter_ntok && !strcasecmp(filter_toks[filter_pos], "AND")) {
        filter_pos++;
        bool rhs = eval_filter_atom();
        v = v && rhs;
    }
    return v;
}
static bool eval_filter_expr(void) {
    bool v = eval_filter_and();
    while (filter_pos < filter_ntok && !strcasecmp(filter_toks[filter_pos], "OR")) {
        filter_pos++;
        bool rhs = eval_filter_and();
        v = v || rhs;
    }
    return v;
}

static char **tokenize_filter(const char *s, int *n) {
    char **a = NULL; int len = 0, cap = 0;
    const char *p = s;
    while (*p) {
        while (isspace((unsigned char)*p)) p++;
        if (!*p) break;
        const char *st = p; char *tok = NULL;
        if (*p == '(' || *p == ')') { tok = strndup(p, 1); p++; }
        else if (*p == '"') { p++; while (*p && *p != '"') p++; if (*p) p++; tok = strndup(st, p-st); }
        else { while (*p && !isspace((unsigned char)*p) && *p != '(' && *p != ')') p++; tok = strndup(st, p-st); }
        if (len == cap) { cap = cap ? cap*2 : 8; a = xrealloc(a, cap*sizeof(char*)); }
        a[len++] = tok;
    }
    *n = len; return a;
}

static bool line_matches(const char *filter, const char *line) {
    if (!filter || !*trim((char*)filter) || !strcmp(trim((char*)filter), "*")) return true;
    int n = 0; char **t = tokenize_filter(filter, &n);
    filter_toks = t; filter_ntok = n; filter_pos = 0; filter_line = line;
    bool v = eval_filter_expr();
    for (int i = 0; i < n; i++) free(t[i]); free(t);
    return v;
}

static bool parse_pattern(const char *pat, const char *text, char **vals, int nvals) {
    int vi = 0; const char *pp = pat, *tp = text;
    while (*pp) {
        if (*pp == '*') {
            pp++;
            const char *next = strchr(pp, '*');
            char lit[1024];
            if (next) { snprintf(lit, sizeof(lit), "%.*s", (int)(next - pp), pp); }
            else snprintf(lit, sizeof(lit), "%s", pp);
            char *endp = NULL;
            if (*lit) endp = strstr(tp, lit);
            else endp = (char*)tp + strlen(tp);
            if (!endp) return false;
            if (vi < nvals) vals[vi++] = strndup(tp, endp - tp);
            tp = endp + strlen(lit);
            pp += strlen(lit);
        } else if (isspace((unsigned char)*pp)) {
            while (isspace((unsigned char)*pp)) pp++;
            while (isspace((unsigned char)*tp)) tp++;
        } else {
            if (*pp != *tp) return false;
            pp++; tp++;
        }
    }
    return vi >= nvals;
}

static bool eval_condition(Row *r, char *expr);

static char *eval_simple(Row *r, char *expr, char *buf, size_t bufsz) {
    expr = trim(expr);
    size_t n = strlen(expr);
    if ((n >= 2 && expr[0] == '"' && expr[n-1] == '"') || (n >= 2 && expr[0] == '\'' && expr[n-1] == '\'')) {
        expr[n-1] = 0; snprintf(buf, bufsz, "%s", expr+1); return buf;
    }
    if (starts_ci(expr, "toLowerCase(") && expr[n-1] == ')') { expr[n-1]=0; char *v=eval_simple(r, expr+12, buf, bufsz); for(char*p=v;*p;p++)*p=tolower((unsigned char)*p); return buf; }
    if (starts_ci(expr, "toUpperCase(") && expr[n-1] == ')') { expr[n-1]=0; char *v=eval_simple(r, expr+12, buf, bufsz); for(char*p=v;*p;p++)*p=toupper((unsigned char)*p); return buf; }
    if (starts_ci(expr, "length(") && expr[n-1] == ')') { expr[n-1]=0; char tmp[4096]; eval_simple(r, expr+7, tmp, sizeof(tmp)); snprintf(buf, bufsz, "%zu", strlen(tmp)); return buf; }
    if (starts_ci(expr, "num(") && expr[n-1] == ')') { expr[n-1]=0; snprintf(buf, bufsz, "%s", eval_simple(r, expr+4, buf, bufsz)); return buf; }
    if (starts_ci(expr, "if(") && expr[n-1] == ')') {
        expr[n-1]=0; int cn=0; char **parts=split_commas(expr+3, &cn);
        char tmp[4096]=""; if (cn>=3) snprintf(buf, bufsz, "%s", eval_condition(r, parts[0]) ? eval_simple(r, parts[1], tmp, sizeof(tmp)) : eval_simple(r, parts[2], tmp, sizeof(tmp)));
        for(int i=0;i<cn;i++)free(parts[i]); free(parts); return buf;
    }
    char *op = NULL; char opc = 0;
    for (char *p = expr + strlen(expr)-1; p > expr; p--) if ((*p == '+' || *p == '-') && p[-1] != 'e') { op=p; opc=*p; break; }
    if (!op) for (char *p = expr; *p; p++) if (*p == '*' || *p == '/') { op=p; opc=*p; break; }
    if (op) {
        *op=0; char l[4096], rr[4096]; eval_simple(r, expr, l, sizeof(l)); eval_simple(r, op+1, rr, sizeof(rr));
        double a=0,b=0; if (is_num_str(l,&a)&&is_num_str(rr,&b)) {
            double res = opc=='+'?a+b:opc=='-'?a-b:opc=='*'?a*b:(b?a/b:0);
            snprintf(buf, bufsz, fabs(res-round(res))<1e-9 ? "%.0f" : "%.6g", res); return buf;
        }
        if (opc=='+') { snprintf(buf, bufsz, "%s%s", l, rr); return buf; }
    }
    Field *f = row_get(r, expr); if (f) { snprintf(buf, bufsz, "%s", f->s); return buf; }
    snprintf(buf, bufsz, "%s", expr); return buf;
}

static bool eval_condition(Row *r, char *expr) {
    expr = trim(expr);
    if (*expr == '!') return !eval_condition(r, expr+1);
    const char *ops[] = {"==","!=", "<>",">=","<=","<",">",NULL};
    for (int i=0; ops[i]; i++) {
        char *p = strstr(expr, ops[i]);
        if (p) {
            *p = 0; char lb[4096], rb[4096]; eval_simple(r, expr, lb, sizeof(lb)); eval_simple(r, p+strlen(ops[i]), rb, sizeof(rb));
            double a,b; bool na=is_num_str(lb,&a), nb=is_num_str(rb,&b); int c = (na&&nb) ? (a<b?-1:a>b?1:0) : strcmp(lb,rb);
            if (!strcmp(ops[i],"==")) return c==0; if (!strcmp(ops[i],"!=")||!strcmp(ops[i],"<>")) return c!=0;
            if (!strcmp(ops[i],">=")) return c>=0; if (!strcmp(ops[i],"<=")) return c<=0; if (!strcmp(ops[i],">")) return c>0; if (!strcmp(ops[i],"<")) return c<0;
        }
    }
    char b[4096]; eval_simple(r, expr, b, sizeof(b)); return *b && strcmp(b, "false") && strcmp(b, "0") && strcmp(b, "null");
}

static void op_parse(Rows *rs, char *op) {
    char *p = trim(op + 5); bool nodrop = strstr(p, "nodrop") != NULL;
    if (starts_ci(p, "regex")) {
        char *q1 = strchr(p, '"'); if (!q1) return; char *q2 = q1 + 1; while (*q2 && (*q2 != '"' || q2[-1] == '\\')) q2++; if (!*q2) return;
        *q2 = 0; char *pat = q1 + 1; char *after = q2 + 1;
        char *from = NULL; char *fromp = strstr(after, " from ");
        if (fromp) { fromp += 6; char *e = strstr(fromp, " nodrop"); from = strndup(trim(fromp), e ? (size_t)(e-fromp) : strlen(fromp)); }
        char **names = NULL; int nn = 0, ncap = 0;
        char rx[4096] = ""; char *w = rx;
        for (char *s = pat; *s && (size_t)(w-rx) < sizeof(rx)-8; s++) {
            if (s[0] == '(' && s[1] == '?' && s[2] == 'P' && s[3] == '<') {
                char *e = strchr(s+4, '>');
                if (e) {
                    if (nn == ncap) { ncap = ncap ? ncap*2 : 4; names = xrealloc(names, ncap*sizeof(char*)); }
                    names[nn++] = strndup(s+4, e-(s+4));
                    *w++ = '('; s = e; continue;
                }
            }
            if (s[0] == '\\' && s[1] == 'w') { strcpy(w, "[[:alnum:]_]"); w += strlen(w); s++; continue; }
            *w++ = *s;
        }
        *w = 0;
        regex_t re; if (regcomp(&re, rx, REG_EXTENDED)) { free(from); return; }
        int mcount = nn + 1; regmatch_t *m = calloc(mcount, sizeof(regmatch_t));
        for (int i=0;i<rs->len;i++) {
            Row *r=&rs->rows[i]; if (r->drop) continue;
            const char *src = from ? field_value(r, trim(from)) : r->raw;
            if (regexec(&re, src, mcount, m, 0) == 0) {
                for (int j=0;j<nn;j++) if (m[j+1].rm_so >= 0) {
                    char *v = strndup(src + m[j+1].rm_so, m[j+1].rm_eo - m[j+1].rm_so);
                    row_add(r, names[j], v, V_STRING); free(v);
                }
            } else if (!nodrop) r->drop = true;
        }
        regfree(&re); free(m); for(int i=0;i<nn;i++)free(names[i]); free(names); free(from); return;
    }
    char *q1 = strchr(p, '"'); if (!q1) return; char *q2 = q1+1; while (*q2 && (*q2 != '"' || q2[-1] == '\\')) q2++; if (!*q2) return;
    *q2 = 0; char *pat = q1 + 1; char *after = q2 + 1;
    char *from = NULL; char *as = strstr(after, " as ");
    char *fromp = strstr(after, " from ");
    if (fromp && (!as || fromp < as)) { fromp += 6; char *e = as ? as : fromp + strlen(fromp); from = strndup(trim(fromp), e-fromp); }
    if (!as) return; as += 4;
    char *flags = strstr(as, " nodrop"); if (flags) *flags = 0; flags = strstr(as, " noconvert"); if (flags) *flags = 0;
    int n=0; char **names = split_commas(as, &n);
    for (int i=0;i<rs->len;i++) {
        Row *r=&rs->rows[i]; if (r->drop) continue;
        char **vals = calloc(n, sizeof(char*));
        bool ok = parse_pattern(pat, from ? field_value(r, trim(from)) : r->raw, vals, n);
        if (!ok && !nodrop) r->drop = true;
        if (ok) for (int j=0;j<n;j++) { char *v=trim(vals[j] ? vals[j] : ""); row_add(r, trim(names[j]), v, V_STRING); }
        for (int j=0;j<n;j++) free(vals[j]); free(vals);
    }
    for(int i=0;i<n;i++)free(names[i]); free(names); free(from);
}

static void op_split(Rows *rs, char *op) {
    char *field = NULL, *sep = ","; char *out = "_split";
    char *lp = strchr(op, '('), *rp = lp ? strchr(lp, ')') : NULL;
    if (lp && rp) { *rp=0; field = trim(lp+1); out = field; }
    char *on = strstr(op, " on "); if (on) { on += 4; sep = unquote(on); char *as = strstr(sep, " as "); if (as) { *as=0; out=trim(as+4); } }
    for (int i=0;i<rs->len;i++) {
        Row *r=&rs->rows[i]; if (r->drop) continue; char *src=xstrdup(field ? field_value(r, field) : r->raw);
        char arr[8192]="["; char *save=NULL; bool first=true; for(char *tok=strtok_r(src, sep, &save); tok; tok=strtok_r(NULL, sep, &save)) {
            if(!first)strncat(arr,", ",sizeof(arr)-strlen(arr)-1); strncat(arr,trim(tok),sizeof(arr)-strlen(arr)-1); first=false;
        }
        strncat(arr,"]",sizeof(arr)-strlen(arr)-1); row_add(r,out,arr,V_ARRAY); free(src);
    }
}

static void op_fields(Rows *rs, char *op) {
    char *p = trim(op + 6); bool except = false;
    if (starts_ci(p, "except ")) { except=true; p=trim(p+7); } else if (*p=='-') { except=true; p=trim(p+1); } else if (starts_ci(p, "only ")) p=trim(p+5); else if (*p=='+') p=trim(p+1);
    int n=0; char **names=split_commas(p,&n);
    for (int i=0;i<rs->len;i++) {
        Row *r=&rs->rows[i]; if (r->drop) continue;
        for (int j=0;j<r->len;j++) {
            bool listed=false; for(int k=0;k<n;k++) if(!strcmp(r->f[j].key, trim(names[k]))) listed=true;
            if ((except && listed) || (!except && !listed)) { free(r->f[j].key); free(r->f[j].s); memmove(&r->f[j], &r->f[j+1], (r->len-j-1)*sizeof(Field)); r->len--; j--; }
        }
    }
    for(int i=0;i<n;i++)free(names[i]); free(names);
}

static void op_expr(Rows *rs, char *op) {
    char *as = strstr(op, " as "); if (!as) return; *as=0; char *name=trim(as+4);
    for(int i=0;i<rs->len;i++){ Row*r=&rs->rows[i]; if(r->drop)continue; char b[4096]; char *tmp=xstrdup(op); eval_simple(r,tmp,b,sizeof(b)); row_add(r,name,b,V_STRING); free(tmp); }
}

static void apply_nonagg(Rows *rs, char *op) {
    op = trim(op);
    if (!*op) return;
    if (!strcmp(op, "json") || starts_ci(op, "json ")) {
        char *from = strstr(op, " from "); if (from) from = trim(from+6);
        for(int i=0;i<rs->len;i++) if(!rs->rows[i].drop && !parse_json(&rs->rows[i], from ? field_value(&rs->rows[i], from) : rs->rows[i].raw)) rs->rows[i].drop=true;
    } else if (!strcmp(op, "logfmt") || starts_ci(op, "logfmt ")) {
        char *from = strstr(op, " from "); if (from) from = trim(from+6);
        for(int i=0;i<rs->len;i++) if(!rs->rows[i].drop) parse_logfmt(&rs->rows[i], from ? field_value(&rs->rows[i], from) : rs->rows[i].raw);
    } else if (starts_ci(op, "parse ")) op_parse(rs, op);
    else if (starts_ci(op, "split")) op_split(rs, op);
    else if (starts_ci(op, "fields")) op_fields(rs, op);
    else if (starts_ci(op, "where ")) {
        for(int i=0;i<rs->len;i++) if(!rs->rows[i].drop){ char *e=xstrdup(op+6); if(!eval_condition(&rs->rows[i],e)) rs->rows[i].drop=true; free(e); }
    } else if (starts_ci(op, "limit ")) {
        int lim=atoi(trim(op+6)), live=0; for(int i=0;i<rs->len;i++) if(!rs->rows[i].drop) live++;
        int seen=0; for(int i=0;i<rs->len;i++) if(!rs->rows[i].drop){ seen++; if((lim>=0 && seen>lim) || (lim<0 && seen<=live+lim)) rs->rows[i].drop=true; }
    } else if (strstr(op, " as ")) op_expr(rs, op);
}

static bool is_agg(char *op) {
    op=trim(op);
    return starts_ci(op,"count")||starts_ci(op,"sum(")||starts_ci(op,"average(")||starts_ci(op,"avg(")||starts_ci(op,"min(")||starts_ci(op,"max(")
        || ((op[0]=='p'||op[0]=='P') && isdigit((unsigned char)op[1]))
        || starts_ci(op,"pct")||starts_ci(op,"count_distinct(");
}

static void field_copy(Field **arr, int *len, int *cap, const char *k, const char *v, VType t) {
    if (*len == *cap) { *cap = *cap ? *cap*2 : 8; *arr = xrealloc(*arr, *cap * sizeof(Field)); }
    (*arr)[*len].key=xstrdup(k); (*arr)[*len].s=xstrdup(v); (*arr)[*len].type=t; (*arr)[*len].n=0; (*len)++;
}

static void parse_aggs(char *op, AggSpec **out, int *outn, char ***keys, int *keyn) {
    char *by = strstr(op, " by "); if (by) { *by=0; by += 4; *keys=split_commas(by,keyn); } else { *keys=NULL; *keyn=0; }
    int n=0; char **parts=split_commas(op,&n); AggSpec *a=calloc(n,sizeof(AggSpec));
    for(int i=0;i<n;i++){
        char *p=trim(parts[i]); char *as=strstr(p," as "); if(as){*as=0; a[i].alias=xstrdup(trim(as+4));}
        char *lp=strchr(p,'('), *rp=lp?strrchr(p,')'):NULL;
        if(lp){*lp=0; if(rp)*rp=0; a[i].arg=xstrdup(trim(lp+1));} else a[i].arg=NULL;
        a[i].name=xstrdup(trim(p));
        if(!a[i].alias){
            if(!strcasecmp(a[i].name,"count")) a[i].alias=xstrdup("_count");
            else if(!strcasecmp(a[i].name,"average")||!strcasecmp(a[i].name,"avg")) a[i].alias=xstrdup("_average");
            else if(!strcasecmp(a[i].name,"count_distinct")) a[i].alias=xstrdup("_count_distinct");
            else { char b[64]; snprintf(b,sizeof(b),"_%s",a[i].name); a[i].alias=xstrdup(b); }
        }
        a[i].min=INFINITY; a[i].max=-INFINITY;
        free(parts[i]);
    }
    free(parts); *out=a; *outn=n;
}

static Group *groups=NULL; static int glen=0,gcap=0;
static Group *get_group(Row *r, char **keys, int keyn, AggSpec *spec, int alen) {
    char join[8192]="";
    for(int i=0;i<keyn;i++){ if(i)strcat(join,"\037"); strcat(join,field_value(r,trim(keys[i]))); }
    for(int g=0;g<glen;g++) if(!strcmp(groups[g].key_join,join)) return &groups[g];
    if(glen==gcap){gcap=gcap?gcap*2:16; groups=xrealloc(groups,gcap*sizeof(Group));}
    Group *gr=&groups[glen++]; memset(gr,0,sizeof(*gr)); gr->key_join=xstrdup(join); gr->klen=keyn; gr->keys=calloc(keyn,sizeof(char*));
    for(int i=0;i<keyn;i++){ gr->keys[i]=xstrdup(field_value(r,trim(keys[i]))); field_copy(&gr->out,&gr->olen,&gr->ocap,trim(keys[i]),gr->keys[i],V_STRING); }
    gr->aggs=calloc(alen,sizeof(AggSpec)); gr->alen=alen;
    for(int i=0;i<alen;i++){ gr->aggs[i]=spec[i]; gr->aggs[i].name=xstrdup(spec[i].name); gr->aggs[i].arg=spec[i].arg?xstrdup(spec[i].arg):NULL; gr->aggs[i].alias=xstrdup(spec[i].alias); gr->aggs[i].min=INFINITY; gr->aggs[i].max=-INFINITY; }
    return gr;
}

static int dblcmp(const void*a,const void*b){double x=*(double*)a,y=*(double*)b;return x<y?-1:x>y?1:0;}
static void agg_add_val(AggSpec *a, double v) {
    a->sum += v; a->count++; if(v<a->min)a->min=v; if(v>a->max)a->max=v;
    if(a->vlen==a->vcap){a->vcap=a->vcap?a->vcap*2:16; a->vals=xrealloc(a->vals,a->vcap*sizeof(double));} a->vals[a->vlen++]=v;
}

static void aggregate(Rows *rs, char *op, Rows *outrows) {
    AggSpec *spec=NULL; int alen=0,keyn=0; char **keys=NULL; parse_aggs(op,&spec,&alen,&keys,&keyn);
    for(int i=0;i<rs->len;i++){ Row*r=&rs->rows[i]; if(r->drop)continue; Group*g=get_group(r,keys,keyn,spec,alen);
        for(int j=0;j<alen;j++){ AggSpec*a=&g->aggs[j];
            if(!strcasecmp(a->name,"count")) { if(!a->arg || eval_condition(r, xstrdup(a->arg))) a->count++; }
            else if(!strcasecmp(a->name,"count_distinct")) { char *v=field_value(r,a->arg); bool seen=false; for(int d=0;d<a->dlen;d++)if(!strcmp(a->distinct[d],v))seen=true; if(!seen){ if(a->dlen==a->dcap){a->dcap=a->dcap?a->dcap*2:8;a->distinct=xrealloc(a->distinct,a->dcap*sizeof(char*));} a->distinct[a->dlen++]=xstrdup(v); } }
            else { double v; if(is_num_str(field_value(r,a->arg),&v)) agg_add_val(a,v); }
        }
    }
    if(glen==0 && keyn==0){ Row dummy={0}; Group*g=get_group(&dummy,keys,keyn,spec,alen); (void)g; }
    for(int g=0;g<glen;g++){ Row r={0}; for(int k=0;k<groups[g].olen;k++) row_add(&r,groups[g].out[k].key,groups[g].out[k].s,V_STRING);
        for(int j=0;j<groups[g].alen;j++){ AggSpec*a=&groups[g].aggs[j]; char b[128]="";
            if(!strcasecmp(a->name,"count")) snprintf(b,sizeof(b),"%d",a->count);
            else if(!strcasecmp(a->name,"sum")) snprintf(b,sizeof(b),fabs(a->sum-round(a->sum))<1e-9?"%.0f":"%.6g",a->sum);
            else if(!strcasecmp(a->name,"average")||!strcasecmp(a->name,"avg")) snprintf(b,sizeof(b),a->count&&fabs(a->sum/a->count-round(a->sum/a->count))<1e-9?"%.0f":"%.2f",a->count?a->sum/a->count:0);
            else if(!strcasecmp(a->name,"min")) snprintf(b,sizeof(b),a->count?(fabs(a->min-round(a->min))<1e-9?"%.0f":"%.6g"):"",a->min);
            else if(!strcasecmp(a->name,"max")) snprintf(b,sizeof(b),a->count?(fabs(a->max-round(a->max))<1e-9?"%.0f":"%.6g"):"",a->max);
            else if(!strcasecmp(a->name,"count_distinct")) snprintf(b,sizeof(b),"%d",a->dlen);
            else if((a->name[0]=='p'||starts_ci(a->name,"pct"))&&a->vlen){ int pct=atoi(a->name+(starts_ci(a->name,"pct")?3:1)); qsort(a->vals,a->vlen,sizeof(double),dblcmp); int idx=(int)ceil((pct/100.0)*a->vlen)-1; if(idx<0)idx=0;if(idx>=a->vlen)idx=a->vlen-1; snprintf(b,sizeof(b),fabs(a->vals[idx]-round(a->vals[idx]))<1e-9?"%.0f":"%.6g",a->vals[idx]); }
            row_add(&r,a->alias,b,V_STRING);
        } rows_add(outrows,r);
    }
    for(int i=0;i<keyn;i++)free(keys[i]); free(keys);
}

static char *output_mode = "legacy";
static char *cli_alias_dir = NULL;
static bool no_alias = false;

static bool recognized_op(const char *op) {
    char *tmp = xstrdup(op), *t = trim(tmp);
    bool ok = starts_ci(t,"json") || starts_ci(t,"logfmt") || starts_ci(t,"parse ") || starts_ci(t,"split") ||
        starts_ci(t,"fields") || starts_ci(t,"where ") || starts_ci(t,"limit ") || starts_ci(t,"sort by ") ||
        is_agg(t) || strstr(t, " as ");
    free(tmp);
    return ok;
}

static char *read_file_text(const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    char *s = calloc(n + 1, 1); if (n > 0) fread(s, 1, n, f); fclose(f); return s;
}

static char *toml_value(char *txt, const char *key) {
    char *p = strstr(txt, key); if (!p) return NULL;
    p = strchr(p, '='); if (!p) return NULL; p = trim(p + 1);
    if (starts_ci(p, "\"\"\"")) {
        p += 3; char *e = strstr(p, "\"\"\""); if (!e) return NULL; return strndup(p, e-p);
    }
    if (*p == '"') { p++; char *e = strchr(p, '"'); if (!e) return NULL; return strndup(p, e-p); }
    char *e = p; while (*e && *e != '\n' && *e != '\r') e++; return strndup(p, e-p);
}

static char *find_alias_in_dir(const char *dir, const char *name) {
    DIR *d = opendir(dir); if (!d) return NULL;
    struct dirent *de; char *ret = NULL;
    while (!ret && (de = readdir(d))) {
        if (de->d_name[0] == '.') continue;
        char path[4096]; snprintf(path, sizeof(path), "%s/%s", dir, de->d_name);
        char *txt = read_file_text(path); if (!txt) continue;
        char *kw = toml_value(txt, "keyword");
        if (kw && !strcmp(trim(kw), name)) ret = toml_value(txt, "template");
        free(kw); free(txt);
    }
    closedir(d); return ret;
}

static char *load_alias(const char *name) {
    if (no_alias || recognized_op(name)) return NULL;
    if (cli_alias_dir) return find_alias_in_dir(cli_alias_dir, name);
    char cwd[4096]; if (!getcwd(cwd, sizeof(cwd))) return NULL;
    while (1) {
        char d[4096]; snprintf(d, sizeof(d), "%s/.agrind-aliases", cwd);
        char *r = find_alias_in_dir(d, name); if (r) return r;
        char *slash = strrchr(cwd, '/');
        if (!slash || slash == cwd) break;
        *slash = 0;
    }
    return find_alias_in_dir("/.agrind-aliases", name);
}

static void print_json_str(const char*s){ putchar('"'); for(;*s;s++){ if(*s=='"'||*s=='\\')printf("\\%c",*s); else if(*s=='\n')printf("\\n"); else putchar(*s);} putchar('"');}
static void print_row(Row *r) {
    qsort(r->f, r->len, sizeof(Field), cmp_field);
    if (!strcmp(output_mode,"json")) {
        putchar('{'); for(int i=0;i<r->len;i++){ if(i)putchar(','); print_json_str(r->f[i].key); putchar(':'); double d; if(r->f[i].type==V_NUMBER||is_num_str(r->f[i].s,&d)) printf("%s",r->f[i].s); else if(!strcmp(r->f[i].s,"true")||!strcmp(r->f[i].s,"false")||!strcmp(r->f[i].s,"null")) printf("%s",r->f[i].s); else print_json_str(r->f[i].s);} puts("}");
    } else if (!strcmp(output_mode,"logfmt")) {
        for(int i=0;i<r->len;i++){ if(i)putchar(' '); printf("%s=",r->f[i].key); bool q=strpbrk(r->f[i].s," \t\n\"")!=NULL; if(q)print_json_str(r->f[i].s); else printf("%s",r->f[i].s);} putchar('\n');
    } else if (starts_ci(output_mode,"format=")) {
        char *fmt=output_mode+7; for(char*p=fmt;*p;p++){ if(*p=='{' ){ char *e=strchr(p,'}'); if(e){ char k[256]; snprintf(k,sizeof(k),"%.*s",(int)(e-p-1),p+1); printf("%s",field_value(r,k)); p=e; } else putchar(*p); } else putchar(*p);} putchar('\n');
    } else {
        if (r->len==0) { printf("%s\n", r->raw ? r->raw : ""); return; }
        for(int i=0;i<r->len;i++){ if(i)printf("        "); printf("[%s=%s]",r->f[i].key,r->f[i].s);} putchar('\n');
    }
}

static Rows *table_rows;
static char *sort_key = NULL;
static bool sort_desc = false;
static int row_sort_cmp(const void *aa, const void *bb) {
    const Row *a = aa, *b = bb;
    char *av = field_value((Row*)a, sort_key), *bv = field_value((Row*)b, sort_key);
    double an, bn;
    int c;
    if (is_num_str(av, &an) && is_num_str(bv, &bn)) c = an < bn ? -1 : an > bn ? 1 : 0;
    else c = strcmp(av, bv);
    return sort_desc ? -c : c;
}
static void apply_sort(Rows *rs, char *op) {
    char *p = trim(op + 7);
    int n = 0; char **parts = split_commas(p, &n);
    if (n > 0) {
        char *k = trim(parts[0]);
        char *sp = strpbrk(k, " \t");
        sort_desc = false;
        if (sp) {
            *sp++ = 0; sp = trim(sp);
            sort_desc = starts_ci(sp, "desc");
        } else if (strstr(p, " desc")) sort_desc = true;
        free(sort_key); sort_key = xstrdup(k);
        qsort(rs->rows, rs->len, sizeof(Row), row_sort_cmp);
    }
    for (int i = 0; i < n; i++) free(parts[i]);
    free(parts);
}
static int table_cmp_count(const void *aa,const void*bb){
    const Row*a=aa,*b=bb; double ca=0,cb=0; is_num_str(field_value((Row*)a,"_count"),&ca); is_num_str(field_value((Row*)b,"_count"),&cb); if(cb>ca)return 1;if(cb<ca)return -1; return 0;
}
static void print_table(Rows *rs) {
    if (!strcmp(output_mode,"json") || !strcmp(output_mode,"logfmt") || starts_ci(output_mode,"format=")) { for(int i=0;i<rs->len;i++) print_row(&rs->rows[i]); return; }
    if (rs->len>1 && !sort_key) qsort(rs->rows, rs->len, sizeof(Row), table_cmp_count);
    int cols = rs->len ? rs->rows[0].len : 0; if(!cols) return;
    int *w=calloc(cols,sizeof(int)); for(int c=0;c<cols;c++) w[c]=strlen(rs->rows[0].f[c].key);
    for(int i=0;i<rs->len;i++) for(int c=0;c<cols&&c<rs->rows[i].len;c++){ int l=strlen(rs->rows[i].f[c].s); if(l>w[c])w[c]=l; }
    int total=0; for(int c=0;c<cols;c++) total+=w[c]+(c?8:0);
    for(int c=0;c<cols;c++) printf("%-*s%s",w[c],rs->rows[0].f[c].key,c==cols-1?"\n":"        ");
    for(int i=0;i<total;i++) putchar('-'); putchar('\n');
    for(int i=0;i<rs->len;i++){ for(int c=0;c<cols;c++) printf("%-*s%s",w[c], c<rs->rows[i].len?rs->rows[i].f[c].s:"", c==cols-1?"\n":"        "); }
    free(w);
}

int main(int argc, char **argv) {
    char *file=NULL, *query=NULL;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--help")) { printf("Usage: executable [OPTIONS] [QUERY]\n\nOptions:\n  -f, --file <FILE>\n  -o, --output <OUTPUT>\n  -h, --help\n  -V, --version\n"); return 0; }
        else if(!strcmp(argv[i],"-h")) { printf("Usage: executable [OPTIONS] [QUERY]\n"); return 0; }
        else if(!strcmp(argv[i],"--version")||!strcmp(argv[i],"-V")) { puts("ag 0.19.6"); return 0; }
        else if((!strcmp(argv[i],"-f")||!strcmp(argv[i],"--file")) && i+1<argc) file=argv[++i];
        else if((!strcmp(argv[i],"-o")||!strcmp(argv[i],"--output")) && i+1<argc) output_mode=argv[++i];
        else if(!strcmp(argv[i],"-m")||!strcmp(argv[i],"--format")) { if(i+1<argc){ static char buf[4096]; snprintf(buf,sizeof(buf),"format=%s",argv[++i]); output_mode=buf; } }
        else if(!strcmp(argv[i],"-a")||!strcmp(argv[i],"--alias-dir")) { if(i+1<argc) cli_alias_dir=argv[++i]; }
        else if(!strcmp(argv[i],"--no-alias")) { no_alias = true; }
        else query=argv[i];
    }
    if(!query) query="*";
    FILE *in = file ? fopen(file,"r") : stdin; if(!in){ perror(file); return 1; }
    char *q=xstrdup(query); int pn=0; char **parts=NULL; int pcap=0; char *save=NULL;
    for(char *tok=strtok_r(q,"|",&save); tok; tok=strtok_r(NULL,"|",&save)){ if(pn==pcap){pcap=pcap?pcap*2:8;parts=xrealloc(parts,pcap*sizeof(char*));} parts[pn++]=xstrdup(trim(tok)); }
    for (int i = 1; i < pn; i++) {
        char *alias = load_alias(trim(parts[i]));
        if (!alias) continue;
        char *asave = NULL; int insert = 0; char **aparts = NULL;
        for (char *tok = strtok_r(alias, "|", &asave); tok; tok = strtok_r(NULL, "|", &asave)) {
            aparts = xrealloc(aparts, (insert + 1) * sizeof(char*));
            aparts[insert++] = xstrdup(trim(tok));
        }
        if (insert) {
            int newpn = pn + insert - 1;
            parts = xrealloc(parts, (newpn + 1) * sizeof(char*));
            memmove(&parts[i + insert], &parts[i + 1], (pn - i - 1) * sizeof(char*));
            free(parts[i]);
            for (int j = 0; j < insert; j++) parts[i + j] = aparts[j];
            pn = newpn; i += insert - 1;
        }
        free(aparts); free(alias);
    }
    char *filter = pn ? parts[0] : "*";
    Rows rs={0}; char *line=NULL; size_t cap=0; ssize_t n;
    while((n=getline(&line,&cap,in))!=-1){ while(n>0 && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0; if(line_matches(filter,line)){ Row r={0}; r.raw=xstrdup(line); rows_add(&rs,r); } }
    free(line); if(file)fclose(in);
    bool didagg=false; Rows out={0};
    for(int i=1;i<pn;i++){
        if(is_agg(parts[i])){ aggregate(&rs,parts[i],&out); didagg=true; }
        else if(starts_ci(trim(parts[i]),"sort by ")) { if (didagg) apply_sort(&out, trim(parts[i])); else apply_sort(&rs, trim(parts[i])); }
        else if(!didagg) apply_nonagg(&rs,parts[i]);
    }
    if(didagg) print_table(&out); else for(int i=0;i<rs.len;i++) if(!rs.rows[i].drop) print_row(&rs.rows[i]);
    return 0;
}
