#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <regex.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef enum { JNULL, JBOOL, JNUM, JSTR, JARR, JOBJ } JType;
typedef struct J J;
typedef struct { char *key; J *val; } Pair;
struct J {
    JType type;
    double num;
    int boolean;
    char *str;
    J **items;
    int len;
    Pair *pairs;
};

typedef struct { char *s; size_t n, cap; } Buf;
typedef struct { char **v; int n, cap; } Errs;
typedef struct { const char *src; size_t i; int line, col; char err[128]; } Parser;

static void *xcalloc(size_t n, size_t z){ void *p=calloc(n,z); if(!p){perror("calloc"); exit(2);} return p; }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(2);} return p; }
static void binit(Buf *b){ b->n=0; b->cap=256; b->s=xcalloc(b->cap,1); }
static void bgrow(Buf *b,size_t add){ if(b->n+add+1>b->cap){ while(b->n+add+1>b->cap)b->cap*=2; b->s=realloc(b->s,b->cap); if(!b->s){perror("realloc");exit(2);} } }
static void baddn(Buf *b,const char*s,size_t n){ bgrow(b,n); memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void badds(Buf *b,const char*s){ baddn(b,s,strlen(s)); }
static void bprintf(Buf *b,const char *fmt,...){ va_list ap; va_start(ap,fmt); char tmp[512]; int n=vsnprintf(tmp,sizeof(tmp),fmt,ap); va_end(ap); if(n<0)return; if((size_t)n<sizeof(tmp)) baddn(b,tmp,n); else { char *p=xcalloc(n+1,1); va_start(ap,fmt); vsnprintf(p,n+1,fmt,ap); va_end(ap); baddn(b,p,n); free(p);} }

static void add_err(Errs *e,const char *fmt,...){
    if(e->n==e->cap){ e->cap=e->cap?e->cap*2:8; e->v=realloc(e->v,e->cap*sizeof(char*)); if(!e->v){perror("realloc");exit(2);} }
    va_list ap; va_start(ap,fmt); char tmp[1024]; vsnprintf(tmp,sizeof(tmp),fmt,ap); va_end(ap);
    e->v[e->n++]=xstrdup(tmp);
}

static J *jnew(JType t){ J*j=xcalloc(1,sizeof(J)); j->type=t; return j; }
static char peek(Parser*p){ return p->src[p->i]; }
static char getc_p(Parser*p){ char c=p->src[p->i++]; if(c=='\n'){p->line++;p->col=1;} else p->col++; return c; }
static void skipws(Parser*p){ while(isspace((unsigned char)peek(p))) getc_p(p); }
static void perr(Parser*p,const char*m){ if(!p->err[0]) snprintf(p->err,sizeof(p->err),"%s at line %d column %d",m,p->line,p->col); }
static J *parse_value(Parser*p);

static char *parse_string(Parser*p){
    if(getc_p(p)!='"'){ perr(p,"expected string"); return NULL; }
    Buf b; binit(&b);
    while(peek(p) && peek(p)!='"'){
        unsigned char c=getc_p(p);
        if(c=='\\'){
            c=getc_p(p);
            if(c=='"'||c=='\\'||c=='/') baddn(&b,(char*)&c,1);
            else if(c=='b') baddn(&b,"\b",1);
            else if(c=='f') baddn(&b,"\f",1);
            else if(c=='n') baddn(&b,"\n",1);
            else if(c=='r') baddn(&b,"\r",1);
            else if(c=='t') baddn(&b,"\t",1);
            else if(c=='u'){ for(int k=0;k<4 && isxdigit((unsigned char)peek(p));k++) getc_p(p); badds(&b,"?"); }
            else { perr(p,"invalid escape"); free(b.s); return NULL; }
        } else baddn(&b,(char*)&c,1);
    }
    if(peek(p)!='"'){ perr(p,"EOF while parsing a string"); free(b.s); return NULL; }
    getc_p(p); return b.s;
}

static J *parse_array(Parser*p){
    getc_p(p); J*j=jnew(JARR); skipws(p); if(peek(p)==']'){getc_p(p); return j;}
    while(1){
        skipws(p); J*v=parse_value(p); if(!v)return j;
        j->items=realloc(j->items,(j->len+1)*sizeof(J*)); j->items[j->len++]=v;
        skipws(p); if(peek(p)==']'){getc_p(p); return j;} if(peek(p)!=','){perr(p,"expected `,` or `]`"); return j;} getc_p(p);
    }
}

static J *parse_object(Parser*p){
    getc_p(p); J*j=jnew(JOBJ); skipws(p); if(peek(p)=='}'){getc_p(p); return j;}
    while(1){
        skipws(p); if(peek(p)!='"'){perr(p,"key must be a string"); return j;} char*k=parse_string(p);
        skipws(p); if(peek(p)!=':'){perr(p,"expected `:`"); free(k); return j;} getc_p(p);
        skipws(p); J*v=parse_value(p); if(!v){free(k); return j;}
        j->pairs=realloc(j->pairs,(j->len+1)*sizeof(Pair)); j->pairs[j->len].key=k; j->pairs[j->len].val=v; j->len++;
        skipws(p); if(peek(p)=='}'){getc_p(p); return j;} if(peek(p)!=','){perr(p,"expected `,` or `}`"); return j;} getc_p(p);
    }
}

static J *parse_value(Parser*p){
    skipws(p); char c=peek(p);
    if(c=='"'){ J*j=jnew(JSTR); j->str=parse_string(p); return p->err[0]?NULL:j; }
    if(c=='{') return parse_object(p);
    if(c=='[') return parse_array(p);
    if(!strncmp(p->src+p->i,"true",4)){p->i+=4;p->col+=4;J*j=jnew(JBOOL);j->boolean=1;return j;}
    if(!strncmp(p->src+p->i,"false",5)){p->i+=5;p->col+=5;return jnew(JBOOL);}
    if(!strncmp(p->src+p->i,"null",4)){p->i+=4;p->col+=4;return jnew(JNULL);}
    if(c=='-'||isdigit((unsigned char)c)){ char*end; errno=0; double d=strtod(p->src+p->i,&end); if(end==p->src+p->i||errno){perr(p,"invalid number");return NULL;} while(p->src+p->i<end)getc_p(p); J*j=jnew(JNUM); j->num=d; return j; }
    perr(p,"expected ident"); return NULL;
}

static J *parse_json(const char *s,char *err,size_t esz){
    Parser p={s,0,1,1,{0}}; J*j=parse_value(&p); skipws(&p);
    if(!p.err[0] && peek(&p)) perr(&p,"trailing characters");
    if(p.err[0]){ snprintf(err,esz,"%s",p.err); return NULL; }
    return j;
}

static char *readfile(const char *path){
    FILE*f=fopen(path,"rb"); if(!f)return NULL;
    size_t cap=4096,n=0; char*s=xcalloc(cap,1);
    for(;;){
        if(n+2048+1>cap){ cap*=2; s=realloc(s,cap); if(!s){perror("realloc");exit(2);} }
        size_t r=fread(s+n,1,2048,f); n+=r;
        if(r<2048){ if(ferror(f)){ free(s); fclose(f); return NULL; } break; }
    }
    s[n]=0; fclose(f); return s;
}

static J *objget(J*o,const char*k){ if(!o||o->type!=JOBJ)return NULL; for(int i=0;i<o->len;i++) if(!strcmp(o->pairs[i].key,k)) return o->pairs[i].val; return NULL; }
static bool hasprop(J*o,const char*k){ return objget(o,k)!=NULL; }
static bool isintnum(double d){ return isfinite(d) && fabs(d-round(d))<1e-9; }
static const char *typename_j(J*j){ switch(j->type){case JNULL:return "null";case JBOOL:return "boolean";case JNUM:return isintnum(j->num)?"integer":"number";case JSTR:return "string";case JARR:return "array";case JOBJ:return "object";} return "unknown"; }
static void jrepr(Buf*b,J*j){ if(j->type==JSTR)bprintf(b,"\"%s\"",j->str); else if(j->type==JNUM){ if(isintnum(j->num))bprintf(b,"%.0f",j->num); else bprintf(b,"%g",j->num);} else if(j->type==JBOOL)badds(b,j->boolean?"true":"false"); else if(j->type==JNULL)badds(b,"null"); else badds(b,typename_j(j)); }
static char *repr(J*j){ Buf b; binit(&b); jrepr(&b,j); return b.s; }

static bool equalj(J*a,J*b){
    if(a->type==JNUM&&b->type==JNUM) return fabs(a->num-b->num)<1e-12;
    if(a->type!=b->type)return false;
    if(a->type==JNULL)return true; if(a->type==JBOOL)return a->boolean==b->boolean; if(a->type==JSTR)return !strcmp(a->str,b->str);
    if(a->type==JARR){ if(a->len!=b->len)return false; for(int i=0;i<a->len;i++) if(!equalj(a->items[i],b->items[i])) return false; return true; }
    if(a->type==JOBJ){ if(a->len!=b->len)return false; for(int i=0;i<a->len;i++){ J*v=objget(b,a->pairs[i].key); if(!v||!equalj(a->pairs[i].val,v)) return false; } return true; }
    return false;
}

static bool typeok(J*inst,const char*t){
    if(!strcmp(t,"number")) return inst->type==JNUM;
    if(!strcmp(t,"integer")) return inst->type==JNUM && isintnum(inst->num);
    if(!strcmp(t,"string")) return inst->type==JSTR;
    if(!strcmp(t,"boolean")) return inst->type==JBOOL;
    if(!strcmp(t,"object")) return inst->type==JOBJ;
    if(!strcmp(t,"array")) return inst->type==JARR;
    if(!strcmp(t,"null")) return inst->type==JNULL;
    return true;
}

static J *resolve_ptr(J*root,const char*ref){
    const char*p=strchr(ref,'#'); if(!p)return NULL; p++; if(*p==0)return root; if(*p!='/')return NULL; J*cur=root; p++;
    char tok[256]; int n=0;
    for(;;p++){
        if(*p=='/'||*p==0){ tok[n]=0; char dec[256]; int d=0; for(int i=0;tok[i]&&d<255;i++){ if(tok[i]=='~'&&tok[i+1]=='1'){dec[d++]='/';i++;} else if(tok[i]=='~'&&tok[i+1]=='0'){dec[d++]='~';i++;} else dec[d++]=tok[i]; } dec[d]=0;
            if(cur->type==JOBJ) cur=objget(cur,dec); else if(cur->type==JARR) { int idx=atoi(dec); cur=(idx>=0&&idx<cur->len)?cur->items[idx]:NULL; } else return NULL;
            if(!cur)return NULL; n=0; if(*p==0)return cur;
        } else if(n<255) tok[n++]=*p;
    }
}

static int validate(J*schema,J*inst,J*root,Errs*errs);
static int validate_sub(J*s,J*i,J*r){ Errs e={0}; int ok=validate(s,i,r,&e); for(int k=0;k<e.n;k++)free(e.v[k]); free(e.v); return ok; }

static int validate(J*schema,J*inst,J*root,Errs*errs){
    if(!schema) return 1;
    if(schema->type==JBOOL){ if(!schema->boolean) add_err(errs,"False schema does not allow %s",typename_j(inst)); return schema->boolean; }
    if(schema->type!=JOBJ) return 1;
    J*ref=objget(schema,"$ref"); if(ref&&ref->type==JSTR){ J*t=resolve_ptr(root,ref->str); if(t) return validate(t,inst,root,errs); }
    int start=errs->n;
    J*type=objget(schema,"type");
    if(type){
        bool ok=false; char types[256]="";
        if(type->type==JSTR){ ok=typeok(inst,type->str); snprintf(types,sizeof(types),"\"%s\"",type->str); }
        else if(type->type==JARR){ for(int i=0;i<type->len;i++) if(type->items[i]->type==JSTR){ if(i)strncat(types,", ",sizeof(types)-strlen(types)-1); strncat(types,"\"",sizeof(types)-strlen(types)-1); strncat(types,type->items[i]->str,sizeof(types)-strlen(types)-1); strncat(types,"\"",sizeof(types)-strlen(types)-1); if(typeok(inst,type->items[i]->str))ok=true; } }
        if(!ok){ char*r=repr(inst); add_err(errs,"%s is not of type %s",r,types[0]?types:"requested"); free(r); }
    }
    J*en=objget(schema,"enum"); if(en&&en->type==JARR){ bool ok=false; for(int i=0;i<en->len;i++) if(equalj(en->items[i],inst))ok=true; if(!ok){char*r=repr(inst); add_err(errs,"%s is not one of the allowed values",r); free(r);} }
    J*co=objget(schema,"const"); if(co&&!equalj(co,inst)){ char*r=repr(co); add_err(errs,"%s was expected",r); free(r); }
    if(inst->type==JNUM){
        J*m=objget(schema,"minimum"); if(m&&m->type==JNUM&&inst->num<m->num) add_err(errs,"%.15g is less than the minimum of %.15g",inst->num,m->num);
        m=objget(schema,"maximum"); if(m&&m->type==JNUM&&inst->num>m->num) add_err(errs,"%.15g is greater than the maximum of %.15g",inst->num,m->num);
        m=objget(schema,"exclusiveMinimum"); if(m&&m->type==JNUM&&inst->num<=m->num) add_err(errs,"%.15g is less than or equal to the minimum of %.15g",inst->num,m->num);
        m=objget(schema,"exclusiveMaximum"); if(m&&m->type==JNUM&&inst->num>=m->num) add_err(errs,"%.15g is greater than or equal to the maximum of %.15g",inst->num,m->num);
        m=objget(schema,"multipleOf"); if(m&&m->type==JNUM&&m->num!=0){ double q=inst->num/m->num; if(fabs(q-round(q))>1e-9) add_err(errs,"%.15g is not a multiple of %.15g",inst->num,m->num); }
    }
    if(inst->type==JSTR){
        J*m=objget(schema,"minLength"); if(m&&m->type==JNUM&&(int)strlen(inst->str)<(int)m->num) add_err(errs,"\"%s\" is shorter than %.0f characters",inst->str,m->num);
        m=objget(schema,"maxLength"); if(m&&m->type==JNUM&&(int)strlen(inst->str)>(int)m->num) add_err(errs,"\"%s\" is longer than %.0f characters",inst->str,m->num);
        m=objget(schema,"pattern"); if(m&&m->type==JSTR){ regex_t re; if(!regcomp(&re,m->str,REG_EXTENDED|REG_NOSUB)){ if(regexec(&re,inst->str,0,NULL,0)) add_err(errs,"\"%s\" does not match \"%s\"",inst->str,m->str); regfree(&re); } }
        m=objget(schema,"format"); J*af=objget(schema,"x-assert-format"); (void)af; if(m&&m->type==JSTR){ /* formats are annotations unless --assert-format is modeled by caller */ }
    }
    if(inst->type==JARR){
        J*m=objget(schema,"minItems"); if(m&&m->type==JNUM&&inst->len<(int)m->num) add_err(errs,"%s has fewer than %.0f items","array",m->num);
        m=objget(schema,"maxItems"); if(m&&m->type==JNUM&&inst->len>(int)m->num) add_err(errs,"%s has more than %.0f items","array",m->num);
        m=objget(schema,"uniqueItems"); if(m&&m->type==JBOOL&&m->boolean){ for(int i=0;i<inst->len;i++)for(int j=i+1;j<inst->len;j++) if(equalj(inst->items[i],inst->items[j])){ add_err(errs,"array has non-unique elements"); i=inst->len; break; } }
        J*it=objget(schema,"items"); if(it){ if(it->type==JARR){ for(int i=0;i<inst->len&&i<it->len;i++) validate(it->items[i],inst->items[i],root,errs); } else for(int i=0;i<inst->len;i++) validate(it,inst->items[i],root,errs); }
        J*con=objget(schema,"contains"); if(con){ bool ok=false; for(int i=0;i<inst->len;i++) if(validate_sub(con,inst->items[i],root)) ok=true; if(!ok) add_err(errs,"array does not contain items matching the given schema"); }
    }
    if(inst->type==JOBJ){
        J*m=objget(schema,"minProperties"); if(m&&m->type==JNUM&&inst->len<(int)m->num) add_err(errs,"object has fewer than %.0f properties",m->num);
        m=objget(schema,"maxProperties"); if(m&&m->type==JNUM&&inst->len>(int)m->num) add_err(errs,"object has more than %.0f properties",m->num);
        J*req=objget(schema,"required"); if(req&&req->type==JARR) for(int i=0;i<req->len;i++) if(req->items[i]->type==JSTR&&!hasprop(inst,req->items[i]->str)) add_err(errs,"\"%s\" is a required property",req->items[i]->str);
        J*props=objget(schema,"properties"); if(props&&props->type==JOBJ) for(int i=0;i<props->len;i++){ J*v=objget(inst,props->pairs[i].key); if(v) validate(props->pairs[i].val,v,root,errs); }
        J*patp=objget(schema,"patternProperties"); if(patp&&patp->type==JOBJ) for(int p=0;p<patp->len;p++){ regex_t re; if(!regcomp(&re,patp->pairs[p].key,REG_EXTENDED|REG_NOSUB)){ for(int i=0;i<inst->len;i++) if(!regexec(&re,inst->pairs[i].key,0,NULL,0)) validate(patp->pairs[p].val,inst->pairs[i].val,root,errs); regfree(&re);} }
        J*add=objget(schema,"additionalProperties"); if(add){ for(int i=0;i<inst->len;i++){ bool known=props&&objget(props,inst->pairs[i].key); if(!known&&patp&&patp->type==JOBJ){ for(int p=0;p<patp->len&&!known;p++){ regex_t re; if(!regcomp(&re,patp->pairs[p].key,REG_EXTENDED|REG_NOSUB)){ known=!regexec(&re,inst->pairs[i].key,0,NULL,0); regfree(&re); } } } if(known) continue; if(add->type==JBOOL&&!add->boolean) add_err(errs,"Additional properties are not allowed ('%s' was unexpected)",inst->pairs[i].key); else if(add->type!=JBOOL) validate(add,inst->pairs[i].val,root,errs); } }
        J*deps=objget(schema,"dependentRequired"); if(!deps) deps=objget(schema,"dependencies"); if(deps&&deps->type==JOBJ) for(int d=0;d<deps->len;d++) if(hasprop(inst,deps->pairs[d].key)){ J*dv=deps->pairs[d].val; if(dv->type==JARR){ for(int k=0;k<dv->len;k++) if(dv->items[k]->type==JSTR&&!hasprop(inst,dv->items[k]->str)) add_err(errs,"\"%s\" is a dependency of \"%s\"",dv->items[k]->str,deps->pairs[d].key); } else if(dv->type==JOBJ) validate(dv,inst,root,errs); }
    }
    J*all=objget(schema,"allOf"); if(all&&all->type==JARR) for(int i=0;i<all->len;i++) validate(all->items[i],inst,root,errs);
    J*any=objget(schema,"anyOf"); if(any&&any->type==JARR){ bool ok=false; for(int i=0;i<any->len;i++) if(validate_sub(any->items[i],inst,root)) ok=true; if(!ok) add_err(errs,"%s is not valid under any of the given schemas",typename_j(inst)); }
    J*one=objget(schema,"oneOf"); if(one&&one->type==JARR){ int c=0; for(int i=0;i<one->len;i++) if(validate_sub(one->items[i],inst,root)) c++; if(c!=1) add_err(errs,"%s is valid under %d of the given schemas",typename_j(inst),c); }
    J*not=objget(schema,"not"); if(not&&validate_sub(not,inst,root)) add_err(errs,"%s should not be valid under the given schema",typename_j(inst));
    J*iff=objget(schema,"if"); if(iff){ if(validate_sub(iff,inst,root)){ J*then=objget(schema,"then"); if(then) validate(then,inst,root,errs); } else { J*els=objget(schema,"else"); if(els) validate(els,inst,root,errs); } }
    return errs->n==start;
}

static void json_escape(Buf*b,const char*s){ badds(b,"\""); for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\'){ char q[3]={'\\',c,0}; badds(b,q);} else if(c=='\n')badds(b,"\\n"); else if(c<32)bprintf(b,"\\u%04x",c); else baddn(b,(char*)&c,1);} badds(b,"\""); }
static char *abspath_uri(const char*path){ char cwd[4096]; getcwd(cwd,sizeof(cwd)); Buf b; binit(&b); badds(&b,"file://"); if(path[0]=='/') badds(&b,path); else { badds(&b,cwd); badds(&b,"/"); badds(&b,path);} return b.s; }

static void print_json_result(const char*out,const char*schema_path,const char*inst_path,int valid,Errs*errs){
    char*uri=abspath_uri(schema_path); Buf b; binit(&b); badds(&b,"{\"instance\":"); json_escape(&b,inst_path); badds(&b,",\"output\":"); json_escape(&b,out); badds(&b,",\"payload\":");
    if(!strcmp(out,"flag")) bprintf(&b,"{\"valid\":%s}",valid?"true":"false");
    else {
        if(!strcmp(out,"hierarchical")) badds(&b,"{\"details\":["); else badds(&b,"{\"details\":[{\"evaluationPath\":\"\",\"instanceLocation\":\"\",\"schemaLocation\":"); json_escape(&b,uri); bprintf(&b,"#\",\"valid\":%s}",valid?"true":"false"); if(errs->n)badds(&b,",");
        for(int i=0;i<errs->n;i++){ if(i)badds(&b,","); badds(&b,"{\"errors\":{\"error\":"); json_escape(&b,errs->v[i]); badds(&b,"},\"evaluationPath\":\"\",\"instanceLocation\":\"\",\"schemaLocation\":"); json_escape(&b,uri); bprintf(&b,"#\",\"valid\":false}"); }
        if(!strcmp(out,"hierarchical")) { badds(&b,"],\"evaluationPath\":\"\",\"instanceLocation\":\"\",\"schemaLocation\":"); json_escape(&b,uri); bprintf(&b,"#\",\"valid\":%s}",valid?"true":"false"); } else bprintf(&b,"],\"valid\":%s}",valid?"true":"false");
    }
    badds(&b,",\"schema\":"); json_escape(&b,schema_path); badds(&b,"}\n"); fputs(b.s,stdout); free(b.s); free(uri);
}

static int valid_email(const char*s){ const char*a=strchr(s,'@'); return a&&a!=s&&strchr(a+1,'.'); }
static void check_formats(J*schema,J*inst,Errs*errs){
    if(!schema||schema->type!=JOBJ)return; J*f=objget(schema,"format"); if(f&&f->type==JSTR&&inst->type==JSTR){ if(!strcmp(f->str,"email")&&!valid_email(inst->str)) add_err(errs,"\"%s\" is not a \"email\"",inst->str); }
    if(inst->type==JOBJ){ J*p=objget(schema,"properties"); if(p&&p->type==JOBJ) for(int i=0;i<p->len;i++){ J*v=objget(inst,p->pairs[i].key); if(v)check_formats(p->pairs[i].val,v,errs);} }
    if(inst->type==JARR){ J*it=objget(schema,"items"); if(it) for(int i=0;i<inst->len;i++) check_formats(it,inst->items[i],errs); }
}

int main(int argc,char**argv){
    const char*schema_path=NULL; const char*instances[256]; int ni=0; const char*out="text"; int assert_format=0;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){ puts("Usage: executable [OPTIONS] [SCHEMA]\n\nArguments:\n  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)\n\nOptions:\n  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)\n  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]\n      --assert-format              Turn ON format validation\n      --no-assert-format           Turn OFF format validation\n      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]\n  -v, --version                    Show program's version number and exit\n      --errors-only                Only show validation errors\n      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)\n      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)\n  -k, --insecure                   Skip TLS certificate verification (dangerous!)\n      --cacert <FILE>              Path to a custom CA certificate file (PEM format)\n  -h, --help                       Print help"); return 0; }
        else if(!strcmp(argv[i],"-v")||!strcmp(argv[i],"--version")){ puts("Version: 0.41.0"); return 0; }
        else if((!strcmp(argv[i],"-i")||!strcmp(argv[i],"--instance"))&&i+1<argc) instances[ni++]=argv[++i];
        else if((!strcmp(argv[i],"--output"))&&i+1<argc){ out=argv[++i]; if(strcmp(out,"text")&&strcmp(out,"flag")&&strcmp(out,"list")&&strcmp(out,"hierarchical")){ fprintf(stderr,"error: invalid value '%s' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.\n",out); return 2; } }
        else if((!strcmp(argv[i],"-d")||!strcmp(argv[i],"--draft"))&&i+1<argc){ const char*d=argv[++i]; if(strcmp(d,"4")&&strcmp(d,"6")&&strcmp(d,"7")&&strcmp(d,"2019")&&strcmp(d,"2020")){ fprintf(stderr,"error: invalid value '%s' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.\n",d); return 2; } }
        else if(!strcmp(argv[i],"--assert-format")) assert_format=1;
        else if(!strcmp(argv[i],"--no-assert-format")||!strcmp(argv[i],"--errors-only")||!strcmp(argv[i],"-k")) {}
        else if((!strcmp(argv[i],"--connect-timeout")||!strcmp(argv[i],"--timeout")||!strcmp(argv[i],"--cacert"))&&i+1<argc) i++;
        else if(argv[i][0]=='-'){ fprintf(stderr,"error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n",argv[i]); return 2; }
        else schema_path=argv[i];
    }
    if(!schema_path){ fprintf(stderr,"error: the following required arguments were not provided:\n  <SCHEMA>\n\nUsage: executable <SCHEMA>\n\nFor more information, try '--help'.\n"); return 2; }
    char*s=readfile(schema_path); if(!s){ fprintf(stderr,"Error: %s (os error %d)\n",strerror(errno),errno); return 1; }
    char per[256]; J*schema=parse_json(s,per,sizeof(per)); if(!schema){ fprintf(stderr,"Error: %s\n",per); return 1; }
    if(ni==0){ puts("Schema is valid"); return 0; }
    int exitcode=0;
    for(int i=0;i<ni;i++){
        char*txt=readfile(instances[i]); if(!txt){ fprintf(stderr,"Error: %s (os error %d)\n",strerror(errno),errno); exitcode=1; continue; }
        J*inst=parse_json(txt,per,sizeof(per)); if(!inst){ fprintf(stderr,"Error: %s\n",per); exitcode=1; free(txt); continue; }
        Errs errs={0}; validate(schema,inst,schema,&errs); if(assert_format) check_formats(schema,inst,&errs); int valid=errs.n==0; if(!valid) exitcode=1;
        if(!strcmp(out,"text")){ if(valid) printf("%s - VALID\n",instances[i]); else { printf("%s - INVALID. Errors:\n",instances[i]); for(int k=0;k<errs.n;k++) printf("%d. %s\n",k+1,errs.v[k]); } }
        else print_json_result(out,schema_path,instances[i],valid,&errs);
        for(int k=0;k<errs.n;k++)free(errs.v[k]); free(errs.v); free(txt);
    }
    return exitcode;
}
