#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/wait.h>

struct vec { char **v; int n, cap; };
static void push(struct vec *a, char *s){ if(a->n+1>=a->cap){ a->cap=a->cap? a->cap*2:32; a->v=realloc(a->v,a->cap*sizeof(char*)); } a->v[a->n++]=s; a->v[a->n]=NULL; }
static char *xstrdup(const char*s){ s=s?s:""; size_t n=strlen(s)+1; char*r=malloc(n); if(!r){perror("malloc"); exit(1);} memcpy(r,s,n); return r; }
static char *xasprintf2(const char*a,const char*b){ size_t n=strlen(a)+strlen(b)+1; char*r=malloc(n); if(!r)exit(1); strcpy(r,a); strcat(r,b); return r; }
static int starts(const char*s,const char*p){ return strncmp(s,p,strlen(p))==0; }
static int is_method(const char*s){ if(!*s) return 0; for(;*s;s++) if(!isupper((unsigned char)*s)) return 0; return 1; }
static int has_scheme(const char*s){ const char*p=strstr(s,"://"); if(!p) return 0; for(const char*q=s;q<p;q++) if(!isalpha((unsigned char)*q)) return 0; return 1; }
static char *display_url(const char*u){ return has_scheme(u)?xstrdup(u):xasprintf2("http://",u); }
static int noarg_long(const char*o){ static const char* L[]={"--anyauth","--append","--basic","--cert-status","--compressed","--compressed-ssh","--create-dirs","--crlf","--digest","--disable","--disable-eprt","--disable-epsv","--disallow-username-in-url","--doh-cert-status","--doh-insecure","--fail","--fail-early","--fail-with-body","--false-start","--form-escape","--ftp-create-dirs","--ftp-pasv","--ftp-pret","--ftp-skip-pasv-ip","--ftp-ssl-control","--get","--globoff","--haproxy-protocol","--head","--http0.9","--http1.0","--http1.1","--http2","--http2-prior-knowledge","--http3","--ignore-content-length","--include","--insecure","--ipv4","--ipv6","--junk-session-cookies","--location","--location-trusted","--manual","--metalink","--negotiate","--netrc","--netrc-optional","--next","--no-alpn","--no-buffer","--no-keepalive","--no-npn","--no-progress-meter","--no-sessionid","--ntlm","--ntlm-wb","--parallel","--parallel-immediate","--proxytunnel","--raw","--remote-header-name","--remote-name","--remote-name-all","--remote-time","--retry-all-errors","--retry-connrefused","--sasl-ir","--show-error","--silent","--ssl","--ssl-allow-beast","--ssl-auto-client-cert","--ssl-no-revoke","--ssl-reqd","--ssl-revoke-best-effort","--sslv2","--sslv3","--styled-output","--suppress-connect-headers","--tcp-fastopen","--tcp-nodelay","--tftp-no-options","--tlsv1","--tlsv1.0","--tlsv1.1","--tlsv1.2","--tlsv1.3","--tr-encoding","--verbose","--version","--xattr",NULL}; for(int i=0;L[i];i++) if(!strcmp(o,L[i])) return 1; return 0; }
static int noarg_short(const char*o){ return strlen(o)==2 && strchr("afqgGIjLMnNOpRJSsVZ0146#", o[1]); }
static int opt_needs_value(const char*o){ if(strchr(o,'=')) return 0; if(starts(o,"--")) return !noarg_long(o); return !noarg_short(o); }
static char *substr(const char*s,size_t n){ char*r=malloc(n+1); memcpy(r,s,n); r[n]=0; return r; }
static char *urlenc(const char*s){ size_t n=0; for(const unsigned char*p=(const unsigned char*)s;*p;p++) n += (isalnum(*p)||strchr("-_.~",*p))?1:3; char*r=malloc(n+1),*q=r; for(const unsigned char*p=(const unsigned char*)s;*p;p++){ if(isalnum(*p)||strchr("-_.~",*p))*q++=*p; else { sprintf(q,"%%%02X",*p); q+=3; } } *q=0; return r; }
static char *json_quote(const char*s){ size_t n=2; for(const unsigned char*p=(const unsigned char*)s;*p;p++){ if(*p=='"'||*p=='\\') n+=2; else if(*p<32) n+=6; else n++; } char*r=malloc(n+1),*q=r; *q++='"'; for(const unsigned char*p=(const unsigned char*)s;*p;p++){ if(*p=='"'||*p=='\\'){*q++='\\';*q++=*p;} else if(*p=='\n'){*q++='\\';*q++='n';} else if(*p=='\r'){*q++='\\';*q++='r';} else if(*p=='\t'){*q++='\\';*q++='t';} else if(*p<32){sprintf(q,"\\u%04x",*p); q+=6;} else *q++=*p; } *q++='"'; *q=0; return r; }
static void skip_ws(const char **s){ while(isspace((unsigned char)**s)) (*s)++; }
static int parse_json_value(const char **s);
static int parse_json_string(const char **s){ if(**s!='"') return 0; (*s)++; while(**s){ unsigned char c=*(*s)++; if(c=='"') return 1; if(c=='\\'){ if(!**s) return 0; (*s)++; } else if(c<32) return 0; } return 0; }
static int parse_json_number(const char **s){ const char*p=*s; if(*p=='-') p++; if(*p=='0') p++; else if(isdigit((unsigned char)*p)){ while(isdigit((unsigned char)*p)) p++; } else return 0; if(*p=='.'){ p++; if(!isdigit((unsigned char)*p)) return 0; while(isdigit((unsigned char)*p)) p++; } if(*p=='e'||*p=='E'){ p++; if(*p=='+'||*p=='-') p++; if(!isdigit((unsigned char)*p)) return 0; while(isdigit((unsigned char)*p)) p++; } *s=p; return 1; }
static int parse_json_array(const char **s){ if(**s!='[') return 0; (*s)++; skip_ws(s); if(**s==']'){(*s)++; return 1;} for(;;){ if(!parse_json_value(s)) return 0; skip_ws(s); if(**s==']'){(*s)++; return 1;} if(**s!=',') return 0; (*s)++; } }
static int parse_json_object(const char **s){ if(**s!='{') return 0; (*s)++; skip_ws(s); if(**s=='}'){(*s)++; return 1;} for(;;){ if(!parse_json_string(s)) return 0; skip_ws(s); if(**s!=':') return 0; (*s)++; if(!parse_json_value(s)) return 0; skip_ws(s); if(**s=='}'){(*s)++; return 1;} if(**s!=',') return 0; (*s)++; skip_ws(s); } }
static int parse_json_value(const char **s){ skip_ws(s); if(**s=='"') return parse_json_string(s); if(**s=='{') return parse_json_object(s); if(**s=='[') return parse_json_array(s); if(starts(*s,"true")){*s+=4; return 1;} if(starts(*s,"false")){*s+=5; return 1;} if(starts(*s,"null")){*s+=4; return 1;} return parse_json_number(s); }
static int raw_ok(const char*s){ const char*p=s; if(!parse_json_value(&p)) return 0; skip_ws(&p); return *p==0; }
struct field { char *k,*v; int raw, idx; };
static int cmp_field(const void*a,const void*b){ const struct field*x=a,*y=b; int c=strcmp(x->k,y->k); return c?c:(x->idx-y->idx); }
static char *build_json(struct field*f,int nf){ qsort(f,nf,sizeof(*f),cmp_field); size_t cap=128,len=0; char*r=malloc(cap); r[len++]='{'; for(int i=0;i<nf;i++){ if(i && !strcmp(f[i].k,f[i-1].k)){ /* skip duplicate before latest */ } }
 len=1; for(int i=0;i<nf;i++){ int last=1; for(int j=i+1;j<nf;j++) if(!strcmp(f[i].k,f[j].k)) last=0; if(!last) continue; char*k=json_quote(f[i].k); char*v=f[i].raw?(raw_ok(f[i].v)?xstrdup(f[i].v):xstrdup("null")):json_quote(f[i].v); size_t add=strlen(k)+strlen(v)+3; if(len+add+2>cap){ while(len+add+2>cap) cap*=2; r=realloc(r,cap);} if(len>1) r[len++]=','; strcpy(r+len,k); len+=strlen(k); r[len++]=':'; strcpy(r+len,v); len+=strlen(v); free(k); free(v); } r[len++]='}'; r[len]=0; return r; }
static void print_cmd(struct vec *curl){ printf("curl"); for(int i=1;i<curl->n;i++){ char*s=curl->v[i]; int quote=strpbrk(s," \t")!=NULL; printf(" "); if(quote){ putchar('"'); for(char*p=s;*p;p++){ if(*p=='"'||*p=='\\') putchar('\\'); putchar(*p);} putchar('"'); } else printf("%s",s); } putchar('\n'); }
static void pretty_stream(FILE*in){ int c,ind=0,str=0,esc=0; while((c=fgetc(in))!=EOF){ if(str){ putchar(c); if(esc) esc=0; else if(c=='\\') esc=1; else if(c=='"') str=0; continue;} if(isspace(c)) continue; if(c=='"'){str=1; putchar(c);} else if(c=='{'||c=='['){ putchar(c); putchar('\n'); ind+=2; for(int i=0;i<ind;i++) putchar(' ');} else if(c=='}'||c==']'){ putchar('\n'); ind-=2; if(ind<0)ind=0; for(int i=0;i<ind;i++) putchar(' '); putchar(c);} else if(c==','){ putchar(c); putchar('\n'); for(int i=0;i<ind;i++) putchar(' ');} else if(c==':'){ printf(": "); } else putchar(c); } }
int main(int argc,char**argv){ int showcurl=0, pretty=0; struct vec pre={0}, curl={0}; push(&curl,xstrdup("curl")); int i=1; for(;i<argc;i++){ if(!strcmp(argv[i],"--curl")){showcurl=1; continue;} if(!strcmp(argv[i],"--pretty")){pretty=1; continue;} if(!strcmp(argv[i],"--help")||!strcmp(argv[i],"-h")){ char *av[4]={argv[0],argv[i],NULL,NULL}; if(i+1<argc) av[2]=argv[i+1]; execvp("curl", av); perror("curl"); return 127; } if(!strcmp(argv[i],"--version")||!strcmp(argv[i],"-V")){ char *av[3]={argv[0],argv[i],NULL}; execvp("curl", av); perror("curl"); return 127; }
  if(argv[i][0]=='-' && strcmp(argv[i],"-")){ push(&pre,xstrdup(argv[i])); if(opt_needs_value(argv[i]) && i+1<argc) push(&pre,xstrdup(argv[++i])); continue; } break; }
 if(i>=argc){ char *av[]={"curl","--help",NULL}; execvp("curl",av); perror("curl"); return 127; }
 char *method=NULL; if(i+1<argc && is_method(argv[i]) && !strchr(argv[i],':')) method=argv[i++]; char *url=argv[i++]; char *durl=display_url(url);
 for(int j=0;j<pre.n;j++) push(&curl,pre.v[j]);
 if(method){ push(&curl,xstrdup("-X")); push(&curl,xstrdup(method)); }
 struct field *fields=NULL; int nf=0, fcap=0, hasdata=0; char *query=NULL; size_t qlen=0;
 for(;i<argc;i++){ char *a=argv[i]; char *p; if((p=strstr(a,"=="))){ char*k=substr(a,p-a),*v=xstrdup(p+2),*ek=urlenc(k),*ev=urlenc(v); size_t add=strlen(ek)+strlen(ev)+2; query=realloc(query,qlen+add+2); char sep = qlen ? '&' : '?'; query[qlen++]=sep; strcpy(query+qlen,ek); qlen+=strlen(ek); query[qlen++]='='; strcpy(query+qlen,ev); qlen+=strlen(ev); query[qlen]=0; free(k);free(v);free(ek);free(ev); }
  else if((p=strstr(a,":=")) || ((p=strchr(a,'=')) && p>a)){ if(nf>=fcap){fcap=fcap?fcap*2:8; fields=realloc(fields,fcap*sizeof(*fields));} fields[nf].raw = (p[0]==':'); fields[nf].idx=nf; fields[nf].k=substr(a,p-a); fields[nf].v=xstrdup(p+(fields[nf].raw?2:1)); nf++; hasdata=1; }
  else if((p=strchr(a,':')) && p>a){ push(&curl,xstrdup("-H")); push(&curl,xstrdup(a)); }
  else push(&curl,xstrdup(a)); }
 char *finaldisplay=durl, *finalurl=url;
 if(query){
  finaldisplay=malloc(strlen(durl)+strlen(query)+1); strcpy(finaldisplay,durl); strcat(finaldisplay,query);
  finalurl=malloc(strlen(url)+strlen(query)+1); strcpy(finalurl,url); strcat(finalurl,query);
 }
 fprintf(stderr,"%s\n",finaldisplay);
 if(nf){ char*j=build_json(fields,nf); push(&curl,xstrdup("-d")); push(&curl,j); }
 push(&curl,xstrdup(finalurl)); push(&curl,xstrdup("-s")); push(&curl,xstrdup("-S")); if(!hasdata){ push(&curl,xstrdup("-d@-")); }
 push(&curl,xstrdup("-H")); push(&curl,xstrdup("Content-Type: application/json")); push(&curl,xstrdup("-H")); push(&curl,xstrdup("Accept: application/json, */*"));
 if(showcurl){ print_cmd(&curl); return 0; }
 if(pretty){ int fd[2]; if(pipe(fd)!=0){perror("pipe"); return 1;} pid_t pid=fork(); if(pid==0){ close(fd[0]); dup2(fd[1],1); close(fd[1]); execvp("curl",curl.v); perror("curl"); _exit(127);} close(fd[1]); FILE*in=fdopen(fd[0],"r"); pretty_stream(in); fclose(in); int st; waitpid(pid,&st,0); return WIFEXITED(st)?WEXITSTATUS(st):1; }
 execvp("curl",curl.v); perror("curl"); return 127; }
