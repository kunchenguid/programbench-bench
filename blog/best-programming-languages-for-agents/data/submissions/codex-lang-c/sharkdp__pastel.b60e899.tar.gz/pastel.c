#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct { double r,g,b,a; } Color;
typedef struct { const char *name; int r,g,b; } Named;

static const Named names[] = {
{"aliceblue",240,248,255},{"antiquewhite",250,235,215},{"aqua",0,255,255},{"aquamarine",127,255,212},{"azure",240,255,255},
{"beige",245,245,220},{"bisque",255,228,196},{"black",0,0,0},{"blanchedalmond",255,235,205},{"blue",0,0,255},
{"blueviolet",138,43,226},{"brown",165,42,42},{"burlywood",222,184,135},{"cadetblue",95,158,160},{"chartreuse",127,255,0},
{"chocolate",210,105,30},{"coral",255,127,80},{"cornflowerblue",100,149,237},{"cornsilk",255,248,220},{"crimson",220,20,60},
{"cyan",0,255,255},{"darkblue",0,0,139},{"darkcyan",0,139,139},{"darkgoldenrod",184,134,11},{"darkgray",169,169,169},
{"darkgreen",0,100,0},{"darkgrey",169,169,169},{"darkkhaki",189,183,107},{"darkmagenta",139,0,139},{"darkolivegreen",85,107,47},
{"darkorange",255,140,0},{"darkorchid",153,50,204},{"darkred",139,0,0},{"darksalmon",233,150,122},{"darkseagreen",143,188,143},
{"darkslateblue",72,61,139},{"darkslategray",47,79,79},{"darkslategrey",47,79,79},{"darkturquoise",0,206,209},{"darkviolet",148,0,211},
{"deeppink",255,20,147},{"deepskyblue",0,191,255},{"dimgray",105,105,105},{"dimgrey",105,105,105},{"dodgerblue",30,144,255},
{"firebrick",178,34,34},{"floralwhite",255,250,240},{"forestgreen",34,139,34},{"fuchsia",255,0,255},{"gainsboro",220,220,220},
{"ghostwhite",248,248,255},{"gold",255,215,0},{"goldenrod",218,165,32},{"gray",128,128,128},{"green",0,128,0},
{"greenyellow",173,255,47},{"grey",128,128,128},{"honeydew",240,255,240},{"hotpink",255,105,180},{"indianred",205,92,92},
{"indigo",75,0,130},{"ivory",255,255,240},{"khaki",240,230,140},{"lavender",230,230,250},{"lavenderblush",255,240,245},
{"lawngreen",124,252,0},{"lemonchiffon",255,250,205},{"lightblue",173,216,230},{"lightcoral",240,128,128},{"lightcyan",224,255,255},
{"lightgoldenrodyellow",250,250,210},{"lightgray",211,211,211},{"lightgreen",144,238,144},{"lightgrey",211,211,211},{"lightpink",255,182,193},
{"lightsalmon",255,160,122},{"lightseagreen",32,178,170},{"lightskyblue",135,206,250},{"lightslategray",119,136,153},{"lightslategrey",119,136,153},
{"lightsteelblue",176,196,222},{"lightyellow",255,255,224},{"lime",0,255,0},{"limegreen",50,205,50},{"linen",250,240,230},
{"magenta",255,0,255},{"maroon",128,0,0},{"mediumaquamarine",102,205,170},{"mediumblue",0,0,205},{"mediumorchid",186,85,211},
{"mediumpurple",147,112,219},{"mediumseagreen",60,179,113},{"mediumslateblue",123,104,238},{"mediumspringgreen",0,250,154},{"mediumturquoise",72,209,204},
{"mediumvioletred",199,21,133},{"midnightblue",25,25,112},{"mintcream",245,255,250},{"mistyrose",255,228,225},{"moccasin",255,228,181},
{"navajowhite",255,222,173},{"navy",0,0,128},{"oldlace",253,245,230},{"olive",128,128,0},{"olivedrab",107,142,35},
{"orange",255,165,0},{"orangered",255,69,0},{"orchid",218,112,214},{"palegoldenrod",238,232,170},{"palegreen",152,251,152},
{"paleturquoise",175,238,238},{"palevioletred",219,112,147},{"papayawhip",255,239,213},{"peachpuff",255,218,185},{"peru",205,133,63},
{"pink",255,192,203},{"plum",221,160,221},{"powderblue",176,224,230},{"purple",128,0,128},{"rebeccapurple",102,51,153},
{"red",255,0,0},{"rosybrown",188,143,143},{"royalblue",65,105,225},{"saddlebrown",139,69,19},{"salmon",250,128,114},
{"sandybrown",244,164,96},{"seagreen",46,139,87},{"seashell",255,245,238},{"sienna",160,82,45},{"silver",192,192,192},
{"skyblue",135,206,235},{"slateblue",106,90,205},{"slategray",112,128,144},{"slategrey",112,128,144},{"snow",255,250,250},
{"springgreen",0,255,127},{"steelblue",70,130,180},{"tan",210,180,140},{"teal",0,128,128},{"thistle",216,191,216},
{"tomato",255,99,71},{"turquoise",64,224,208},{"violet",238,130,238},{"wheat",245,222,179},{"white",255,255,255},
{"whitesmoke",245,245,245},{"yellow",255,255,0},{"yellowgreen",154,205,50}
};
static const int n_names = (int)(sizeof(names)/sizeof(names[0]));
static int listable_name(const char *s){
    const char *skip[]={"cyan","fuchsia","darkgrey","dimgrey","grey","lightgrey","lightslategrey","slategrey","darkslategrey"};
    for(size_t i=0;i<sizeof(skip)/sizeof(skip[0]);i++) if(strcmp(s,skip[i])==0) return 0;
    return 1;
}

static double clamp(double x,double a,double b){return x<a?a:(x>b?b:x);}
static int iround255(double x){return (int)floor(clamp(x,0,1)*255.0+0.5);}
static char *trim(char *s){while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s;}
static void lower(char *s){for(;*s;s++)*s=(char)tolower((unsigned char)*s);}

static void rgb_to_hsl(Color c,double *h,double *s,double *l){
    double r=c.r,g=c.g,b=c.b, max=fmax(r,fmax(g,b)), min=fmin(r,fmin(g,b));
    *l=(max+min)/2.0; double d=max-min; if(d<1e-12){*h=0;*s=0;return;}
    *s = d/(1.0-fabs(2.0*(*l)-1.0));
    if(max==r) *h=60.0*fmod(((g-b)/d),6.0);
    else if(max==g) *h=60.0*(((b-r)/d)+2.0);
    else *h=60.0*(((r-g)/d)+4.0);
    if(*h<0)*h+=360.0;
}
static double hue2rgb(double p,double q,double t){ if(t<0)t+=1; if(t>1)t-=1; if(t<1.0/6)return p+(q-p)*6*t; if(t<0.5)return q; if(t<2.0/3)return p+(q-p)*(2.0/3-t)*6; return p; }
static Color hsl_to_rgb(double h,double s,double l,double a){
    h=fmod(h,360.0); if(h<0)h+=360.0; s=clamp(s,0,1); l=clamp(l,0,1);
    Color c={l,l,l,a}; if(s==0)return c; double q=l<0.5?l*(1+s):l+s-l*s, p=2*l-q, hk=h/360.0;
    c.r=hue2rgb(p,q,hk+1.0/3); c.g=hue2rgb(p,q,hk); c.b=hue2rgb(p,q,hk-1.0/3); return c;
}
static void rgb_to_hsv(Color c,double *h,double *s,double *v){
    double max=fmax(c.r,fmax(c.g,c.b)), min=fmin(c.r,fmin(c.g,c.b)), d=max-min; *v=max; *s=max<=0?0:d/max;
    if(d<1e-12){*h=0;return;} if(max==c.r)*h=60*fmod((c.g-c.b)/d,6); else if(max==c.g)*h=60*((c.b-c.r)/d+2); else *h=60*((c.r-c.g)/d+4); if(*h<0)*h+=360;
}
static double srgb_lin(double u){return u<=0.04045?u/12.92:pow((u+0.055)/1.055,2.4);}
static double lin_srgb(double u){return u<=0.0031308?12.92*u:1.055*pow(u,1.0/2.4)-0.055;}
static double luminance(Color c){return 0.2126*srgb_lin(c.r)+0.7152*srgb_lin(c.g)+0.0722*srgb_lin(c.b);}
static double brightness(Color c){return (299*iround255(c.r)+587*iround255(c.g)+114*iround255(c.b))/1000.0/255.0;}
static void lab(Color c,double *L,double *A,double *B){
    double r=srgb_lin(c.r),g=srgb_lin(c.g),b=srgb_lin(c.b);
    double x=(0.4124564*r+0.3575761*g+0.1804375*b)/0.95047, y=0.2126729*r+0.7151522*g+0.0721750*b, z=(0.0193339*r+0.1191920*g+0.9503041*b)/1.08883;
    double e=216.0/24389.0,k=24389.0/27.0;
    x=x>e?cbrt(x):(k*x+16)/116; y=y>e?cbrt(y):(k*y+16)/116; z=z>e?cbrt(z):(k*z+16)/116;
    *L=116*y-16; *A=500*(x-y); *B=200*(y-z);
}
static void oklab(Color c,double *L,double *A,double *B){
    double r=srgb_lin(c.r),g=srgb_lin(c.g),b=srgb_lin(c.b);
    double l=cbrt(0.4122214708*r+0.5363325363*g+0.0514459929*b), m=cbrt(0.2119034982*r+0.6806995451*g+0.1073969566*b), s=cbrt(0.0883024619*r+0.2817188376*g+0.6299787005*b);
    *L=0.2104542553*l+0.7936177850*m-0.0040720468*s; *A=1.9779984951*l-2.4285922050*m+0.4505937099*s; *B=0.0259040371*l+0.7827717662*m-0.8086757660*s;
}

static int parse_hex_digit(char c){ if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return -1; }
static int parse_hex(const char *s,Color *c){
    if(*s=='#')s++; int len=(int)strlen(s); for(int i=0;i<len;i++) if(parse_hex_digit(s[i])<0) return 0;
    int r,g,b,a=255;
    if(len==3||len==4){r=parse_hex_digit(s[0])*17;g=parse_hex_digit(s[1])*17;b=parse_hex_digit(s[2])*17;if(len==4)a=parse_hex_digit(s[3])*17;}
    else if(len==6||len==8){r=parse_hex_digit(s[0])*16+parse_hex_digit(s[1]);g=parse_hex_digit(s[2])*16+parse_hex_digit(s[3]);b=parse_hex_digit(s[4])*16+parse_hex_digit(s[5]);if(len==8)a=parse_hex_digit(s[6])*16+parse_hex_digit(s[7]);}
    else return 0; c->r=r/255.0;c->g=g/255.0;c->b=b/255.0;c->a=a/255.0; return 1;
}
static int parse_nums(char *p,double *v,int max){
    int n=0; while(*p&&n<max){ while(*p&&!(isdigit((unsigned char)*p)||*p=='-'||*p=='.'))p++; if(!*p)break; char *e; v[n++]=strtod(p,&e); p=e; }
    return n;
}
static int parse_color_text(const char *in,Color *c){
    char buf[256]; snprintf(buf,sizeof(buf),"%s",in); char *s=trim(buf); lower(s);
    if(parse_hex(s,c)) return 1;
    for(int i=0;i<n_names;i++) if(strcmp(s,names[i].name)==0){c->r=names[i].r/255.0;c->g=names[i].g/255.0;c->b=names[i].b/255.0;c->a=1;return 1;}
    if(strncmp(s,"rgb",3)==0){ double v[4]={0,0,0,1}; int n=parse_nums(s,v,4); if(n>=3){c->r=clamp(v[0]/255.0,0,1);c->g=clamp(v[1]/255.0,0,1);c->b=clamp(v[2]/255.0,0,1);c->a=n>=4?(strchr(s,'%')&&v[3]>1?v[3]/100.0:v[3]):1; c->a=clamp(c->a,0,1); return 1;}}
    if(strncmp(s,"hsl",3)==0){ double v[4]={0,0,0,1}; int n=parse_nums(s,v,4); if(n>=3){*c=hsl_to_rgb(v[0],v[1]/100.0,v[2]/100.0,n>=4?(strstr(s,"%")&&v[3]>1?v[3]/100.0:v[3]):1);return 1;}}
    if(strncmp(s,"gray",4)==0||strncmp(s,"grey",4)==0){ double v[1]; if(parse_nums(s,v,1)>=1){double x=v[0]>1?v[0]/100.0:v[0]; c->r=c->g=c->b=clamp(x,0,1); c->a=1; return 1;}}
    double v[4]; int n=parse_nums(s,v,4); if(n==3||n==4){c->r=clamp(v[0]/255.0,0,1);c->g=clamp(v[1]/255.0,0,1);c->b=clamp(v[2]/255.0,0,1);c->a=n==4?clamp(v[3],0,1):1; return 1;}
    return 0;
}
static int parse_color_arg(const char *arg,Color *c){
    if(strcmp(arg,"-")==0){ char line[512]; if(!fgets(line,sizeof(line),stdin)) return 0; return parse_color_text(line,c); }
    return parse_color_text(arg,c);
}

static void print_hsl(Color c){
    double h,s,l; rgb_to_hsl(c,&h,&s,&l);
    printf("hsl(%d,%.1f%%,%.1f%%)\n",(int)floor(h+0.5),s*100,l*100);
}
static void print_hex(Color c){
    if(c.a < 0.999) printf("#%02x%02x%02x%02x\n",iround255(c.r),iround255(c.g),iround255(c.b),iround255(c.a));
    else printf("#%02x%02x%02x\n",iround255(c.r),iround255(c.g),iround255(c.b));
}
static const char *nearest_name(Color c){
    int r=iround255(c.r),g=iround255(c.g),b=iround255(c.b), best=0; long bd=1L<<60;
    for(int i=0;i<n_names;i++){ long dr=r-names[i].r,dg=g-names[i].g,db=b-names[i].b,d=dr*dr+dg*dg+db*db; if(d<bd){bd=d;best=i;}}
    return names[best].name;
}
static int ansi256(Color c){
    int r=iround255(c.r),g=iround255(c.g),b=iround255(c.b);
    if(r==g&&g==b){ if(r<8)return 16; if(r>248)return 231; return 232+(int)round((r-8)/247.0*24); }
    int ri=(int)round(r/255.0*5), gi=(int)round(g/255.0*5), bi=(int)round(b/255.0*5);
    return 16+36*ri+6*gi+bi;
}
static void print_format(const char *fmt,Color c){
    double h,s,l,v,L,A,B;
    if(strcmp(fmt,"hex")==0) print_hex(c);
    else if(strcmp(fmt,"rgb")==0) printf("rgb(%d, %d, %d)\n",iround255(c.r),iround255(c.g),iround255(c.b));
    else if(strcmp(fmt,"rgb-float")==0) printf("rgb(%.3f, %.3f, %.3f)\n",c.r,c.g,c.b);
    else if(strcmp(fmt,"rgb-r")==0) printf("%d\n",iround255(c.r));
    else if(strcmp(fmt,"rgb-g")==0) printf("%d\n",iround255(c.g));
    else if(strcmp(fmt,"rgb-b")==0) printf("%d\n",iround255(c.b));
    else if(strcmp(fmt,"hsl")==0){rgb_to_hsl(c,&h,&s,&l); printf("hsl(%d, %.1f%%, %.1f%%)\n",(int)floor(h+0.5),s*100,l*100);}
    else if(strcmp(fmt,"hsl-hue")==0){rgb_to_hsl(c,&h,&s,&l); printf("%d\n",(int)floor(h+0.5));}
    else if(strcmp(fmt,"hsl-saturation")==0){rgb_to_hsl(c,&h,&s,&l); printf("%.1f%%\n",s*100);}
    else if(strcmp(fmt,"hsl-lightness")==0){rgb_to_hsl(c,&h,&s,&l); printf("%.1f%%\n",l*100);}
    else if(strcmp(fmt,"hsv")==0){rgb_to_hsv(c,&h,&s,&v); printf("hsv(%d, %.1f%%, %.1f%%)\n",(int)floor(h+0.5),s*100,v*100);}
    else if(strcmp(fmt,"hsv-hue")==0){rgb_to_hsv(c,&h,&s,&v); printf("%d\n",(int)floor(h+0.5));}
    else if(strcmp(fmt,"hsv-saturation")==0){rgb_to_hsv(c,&h,&s,&v); printf("%.1f%%\n",s*100);}
    else if(strcmp(fmt,"hsv-value")==0){rgb_to_hsv(c,&h,&s,&v); printf("%.1f%%\n",v*100);}
    else if(strcmp(fmt,"luminance")==0) printf("%.6f\n",luminance(c));
    else if(strcmp(fmt,"brightness")==0) printf("%.3f\n",brightness(c));
    else if(strcmp(fmt,"ansi-8bit")==0) printf("\033[38;5;%dm#%02x%02x%02x\033[0m\n",ansi256(c),iround255(c.r),iround255(c.g),iround255(c.b));
    else if(strcmp(fmt,"ansi-8bit-value")==0) printf("%d\n",ansi256(c));
    else if(strcmp(fmt,"ansi-8bit-escapecode")==0) printf("\\x1b[38;5;%dm\n",ansi256(c));
    else if(strcmp(fmt,"ansi-24bit")==0) printf("\033[38;2;%d;%d;%dm#%02x%02x%02x\033[0m\n",iround255(c.r),iround255(c.g),iround255(c.b),iround255(c.r),iround255(c.g),iround255(c.b));
    else if(strcmp(fmt,"ansi-24bit-escapecode")==0) printf("\\x1b[38;2;%d;%d;%dm\n",iround255(c.r),iround255(c.g),iround255(c.b));
    else if(strcmp(fmt,"cmyk")==0){ double K=1-fmax(c.r,fmax(c.g,c.b)), C=K>=1?0:(1-c.r-K)/(1-K), M=K>=1?0:(1-c.g-K)/(1-K), Y=K>=1?0:(1-c.b-K)/(1-K); printf("cmyk(%d, %d, %d, %d)\n",(int)round(C*100),(int)round(M*100),(int)round(Y*100),(int)round(K*100));}
    else if(strcmp(fmt,"name")==0) printf("%s\n",nearest_name(c));
    else if(strcmp(fmt,"lab")==0){lab(c,&L,&A,&B); printf("Lab(%.1f, %.1f, %.1f)\n",L,A,B);}
    else if(strcmp(fmt,"lab-a")==0){lab(c,&L,&A,&B); printf("%.1f\n",A);}
    else if(strcmp(fmt,"lab-b")==0){lab(c,&L,&A,&B); printf("%.1f\n",B);}
    else if(strcmp(fmt,"lch")==0||strcmp(fmt,"lch-lightness")==0||strcmp(fmt,"lch-chroma")==0||strcmp(fmt,"lch-hue")==0){lab(c,&L,&A,&B); double C=hypot(A,B), H=atan2(B,A)*180/M_PI; if(H<0)H+=360; if(strcmp(fmt,"lch")==0)printf("LCh(%.1f, %.1f, %.1f)\n",L,C,H); else if(strstr(fmt,"lightness"))printf("%.1f\n",L); else if(strstr(fmt,"chroma"))printf("%.1f\n",C); else printf("%.1f\n",H);}
    else if(strncmp(fmt,"oklab",5)==0){oklab(c,&L,&A,&B); if(strcmp(fmt,"oklab")==0)printf("OkLab(%.3f, %.3f, %.3f)\n",L,A,B); else if(strstr(fmt,"-l"))printf("%.3f\n",L); else if(strstr(fmt,"-a"))printf("%.3f\n",A); else printf("%.3f\n",B);}
    else if(strncmp(fmt,"oklch",5)==0){oklab(c,&L,&A,&B); double C=hypot(A,B),H=atan2(B,A)*180/M_PI; if(H<0)H+=360; if(strcmp(fmt,"oklch")==0)printf("OkLCh(%.3f, %.3f, %.1f)\n",L,C,H); else if(strstr(fmt,"lightness"))printf("%.3f\n",L); else if(strstr(fmt,"chroma"))printf("%.3f\n",C); else printf("%.1f\n",H);}
    else print_hsl(c);
}
static int valid_format(const char *f){
    const char *fmts[]={"rgb","rgb-float","rgb-r","rgb-g","rgb-b","hex","hsl","hsl-hue","hsl-saturation","hsl-lightness","hsv","hsv-hue","hsv-saturation","hsv-value","lch","lch-lightness","lch-chroma","lch-hue","oklch","oklch-lightness","oklch-chroma","oklch-hue","lab","lab-a","lab-b","oklab","oklab-l","oklab-a","oklab-b","luminance","brightness","ansi-8bit","ansi-24bit","ansi-8bit-value","ansi-8bit-escapecode","ansi-24bit-escapecode","cmyk","name"};
    for(size_t i=0;i<sizeof(fmts)/sizeof(fmts[0]);i++) if(strcmp(f,fmts[i])==0)return 1; return 0;
}

typedef void (*ColorFn)(Color*,void*);
static void each_color(int argc,char **argv,int start,ColorFn fn,void *ctx){
    if(start>=argc){ char line[512]; while(fgets(line,sizeof(line),stdin)){ Color c; if(parse_color_text(line,&c)) fn(&c,ctx); else fprintf(stderr,"[pastel error]: Could not parse color '%s'\n",trim(line)); } return; }
    for(int i=start;i<argc;i++){ Color c; if(parse_color_arg(argv[i],&c)) fn(&c,ctx); else fprintf(stderr,"[pastel error]: Could not parse color '%s'\n",argv[i]); }
}
static void fn_format(Color *c,void *ctx){print_format((const char*)ctx,*c);}
static void fn_hsl(Color *c,void *ctx){(void)ctx; print_hsl(*c);}
typedef struct { double amt; int kind; } Adj;
static void fn_adj(Color *c,void *ctx){Adj *a=ctx; double h,s,l; rgb_to_hsl(*c,&h,&s,&l); if(a->kind==0)l+=a->amt; if(a->kind==1)s+=a->amt; if(a->kind==2)h+=a->amt; *c=hsl_to_rgb(h,s,l,c->a); print_hsl(*c);}
static void fn_togray(Color *c,void *ctx){(void)ctx; double y=luminance(*c), lo=0,hi=1; for(int i=0;i<40;i++){double m=(lo+hi)/2, lm=luminance((Color){m,m,m,1}); if(lm<y)lo=m;else hi=m;} print_hsl((Color){(lo+hi)/2,(lo+hi)/2,(lo+hi)/2,c->a});}
static void fn_text(Color *c,void *ctx){(void)ctx; print_hsl(luminance(*c)>0.179?(Color){0,0,0,1}:(Color){1,1,1,1});}

static void usage(void){
    puts("A command-line tool to generate, analyze, convert and manipulate colors\n");
    puts("Usage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  color       Display information about the given color\n  colorblind  Simulate a color under a certain colorblindness profile\n  colorcheck  Check if your terminal emulator supports 24-bit colors.\n  complement  Get the complementary color (hue rotated by 180°)\n  darken      Darken color by a specified amount\n  desaturate  Decrease color saturation by a specified amount\n  distinct    Generate a set of visually distinct colors\n  format      Convert a color to the given format\n  gradient    Generate an interpolating sequence of colors\n  gray        Create a gray tone from a given lightness\n  help        Print this message or the help of the given subcommand(s)\n  lighten     Lighten color by a specified amount\n  list        Show a list of available color names\n  mix         Mix two colors in the given colorspace\n  paint       Print colored text using ANSI escape sequences\n  pick        Interactively pick a color from the screen (pipette)\n  random      Generate a list of random colors\n  rotate      Rotate the hue channel by the specified angle\n  saturate    Increase color saturation by a specified amount\n  set         Set a color property to a specific value\n  sort-by     Sort colors by the given property\n  textcolor   Get a readable text color for the given background color\n  to-gray     Completely desaturate a color (preserving luminance)\n\nOptions:\n  -h, --help                         Print help\n  -V, --version                      Print version");
}
static void simple_help(const char *cmd){ printf("Usage: executable %s [OPTIONS] [color]...\n\nOptions:\n  -h, --help  Print help\n",cmd); }
static int is_help(int argc,char **argv){ for(int i=1;i<argc;i++) if(strcmp(argv[i],"-h")==0||strcmp(argv[i],"--help")==0)return 1; return 0; }
static int cmp_hue(const void *a,const void *b){ const Named *x=*(const Named**)a,*y=*(const Named**)b; Color cx={x->r/255.0,x->g/255.0,x->b/255.0,1},cy={y->r/255.0,y->g/255.0,y->b/255.0,1}; double hx,s,l,hy; rgb_to_hsl(cx,&hx,&s,&l); rgb_to_hsl(cy,&hy,&s,&l); return (hx>hy)-(hx<hy); }
static int cmp_bright(const void *a,const void *b){ const Named *x=*(const Named**)a,*y=*(const Named**)b; Color cx={x->r/255.0,x->g/255.0,x->b/255.0,1},cy={y->r/255.0,y->g/255.0,y->b/255.0,1}; double bx=brightness(cx),by=brightness(cy); return (bx>by)-(bx<by); }
static int cmp_lum(const void *a,const void *b){ const Named *x=*(const Named**)a,*y=*(const Named**)b; Color cx={x->r/255.0,x->g/255.0,x->b/255.0,1},cy={y->r/255.0,y->g/255.0,y->b/255.0,1}; double bx=luminance(cx),by=luminance(cy); return (bx>by)-(bx<by); }

int main(int argc,char **argv){
    if(argc<2 || strcmp(argv[1],"help")==0 || strcmp(argv[1],"--help")==0 || strcmp(argv[1],"-h")==0){ usage(); return 0; }
    if(strcmp(argv[1],"--version")==0||strcmp(argv[1],"-V")==0){ puts("pastel 0.11.0"); return 0; }
    const char *cmd=argv[1]; if(is_help(argc,argv)){ simple_help(cmd); return 0; }
    if(strcmp(cmd,"format")==0){ const char *fmt="hex"; int start=2; if(start<argc && valid_format(argv[start])) fmt=argv[start++]; else if(start<argc && argv[start][0] && !parse_hex(argv[start],&(Color){0}) && !strchr(argv[start],'(')) { if(!valid_format(argv[start]) && strcmp(argv[start],"-")!=0){ fprintf(stderr,"error: invalid value '%s' for '[type]'\n\nFor more information, try '--help'.\n",argv[start]); return 2; }} each_color(argc,argv,start,fn_format,(void*)fmt); return 0; }
    if(strcmp(cmd,"color")==0){ each_color(argc,argv,2,fn_hsl,NULL); return 0; }
    if(strcmp(cmd,"gray")==0){ if(argc<3)return 2; double x=atof(argv[2]); print_hsl((Color){clamp(x,0,1),clamp(x,0,1),clamp(x,0,1),1}); return 0; }
    if(strcmp(cmd,"lighten")==0||strcmp(cmd,"darken")==0||strcmp(cmd,"saturate")==0||strcmp(cmd,"desaturate")==0||strcmp(cmd,"rotate")==0||strcmp(cmd,"complement")==0){
        Adj a={0,0}; int start=2; if(strcmp(cmd,"complement")==0){a.amt=180;a.kind=2;} else { if(argc<3)return 2; a.amt=atof(argv[2]); start=3; if(strcmp(cmd,"darken")==0||strcmp(cmd,"desaturate")==0)a.amt=-a.amt; if(strstr(cmd,"saturate"))a.kind=1; else if(strcmp(cmd,"rotate")==0)a.kind=2; else a.kind=0; } each_color(argc,argv,start,fn_adj,&a); return 0; }
    if(strcmp(cmd,"to-gray")==0){ each_color(argc,argv,2,fn_togray,NULL); return 0; }
    if(strcmp(cmd,"textcolor")==0){ each_color(argc,argv,2,fn_text,NULL); return 0; }
    if(strcmp(cmd,"mix")==0){ int i=2; double frac=0.5; while(i<argc && argv[i][0]=='-'){ if((strcmp(argv[i],"-f")==0||strcmp(argv[i],"--fraction")==0)&&i+1<argc){frac=atof(argv[i+1]); i+=2;} else if((strcmp(argv[i],"-s")==0||strncmp(argv[i],"--colorspace",12)==0)){ i += (strchr(argv[i],'=')?1:2); } else i++; } if(i>=argc)return 2; Color base; if(!parse_color_arg(argv[i++],&base))return 1; if(i>=argc){ char line[512]; while(fgets(line,sizeof(line),stdin)){Color c;if(parse_color_text(line,&c)){Color m={(double)iround255(base.r*frac+c.r*(1-frac))/255.0,(double)iround255(base.g*frac+c.g*(1-frac))/255.0,(double)iround255(base.b*frac+c.b*(1-frac))/255.0,1};print_hsl(m);}} } for(;i<argc;i++){Color c;if(parse_color_arg(argv[i],&c)){Color m={(double)iround255(base.r*frac+c.r*(1-frac))/255.0,(double)iround255(base.g*frac+c.g*(1-frac))/255.0,(double)iround255(base.b*frac+c.b*(1-frac))/255.0,1};print_hsl(m);}} return 0; }
    if(strcmp(cmd,"gradient")==0){ int n=10,i=2; while(i<argc && argv[i][0]=='-'){ if((strcmp(argv[i],"-n")==0||strcmp(argv[i],"--number")==0)&&i+1<argc){n=atoi(argv[i+1]); i+=2;} else if((strcmp(argv[i],"-s")==0||strncmp(argv[i],"--colorspace",12)==0)){ i += (strchr(argv[i],'=')?1:2); } else i++; } if(argc-i<1)return 2; Color stops[64]; int ns=0; for(;i<argc&&ns<64;i++) if(parse_color_arg(argv[i],&stops[ns]))ns++; if(ns==1){print_hsl(stops[0]);return 0;} for(int k=0;k<n;k++){ double t=n==1?0:(double)k/(n-1), pos=t*(ns-1); int j=(int)floor(pos); if(j>=ns-1)j=ns-2; double f=pos-j; Color m={(double)iround255(stops[j].r*(1-f)+stops[j+1].r*f)/255.0,(double)iround255(stops[j].g*(1-f)+stops[j+1].g*f)/255.0,(double)iround255(stops[j].b*(1-f)+stops[j+1].b*f)/255.0,1}; print_hsl(m);} return 0; }
    if(strcmp(cmd,"random")==0||strcmp(cmd,"distinct")==0){ int n=10; for(int i=2;i<argc;i++) if((strcmp(argv[i],"-n")==0||strcmp(argv[i],"--number")==0)&&i+1<argc)n=atoi(argv[++i]); else if(isdigit((unsigned char)argv[i][0])) n=atoi(argv[i]); srand((unsigned)time(NULL)); for(int i=0;i<n;i++){Color c={(rand()%256)/255.0,(rand()%256)/255.0,(rand()%256)/255.0,1}; print_hsl(c);} return 0; }
    if(strcmp(cmd,"list")==0){ const char *sort="hue"; for(int i=2;i<argc;i++) if((strcmp(argv[i],"-s")==0||strcmp(argv[i],"--sort")==0)&&i+1<argc)sort=argv[++i]; const Named *arr[200]; int an=0; for(int i=0;i<n_names;i++) if(listable_name(names[i].name)) arr[an++]=&names[i]; if(strcmp(sort,"brightness")==0)qsort(arr,an,sizeof(arr[0]),cmp_bright); else if(strcmp(sort,"luminance")==0)qsort(arr,an,sizeof(arr[0]),cmp_lum); else if(strcmp(sort,"random")==0){srand((unsigned)time(NULL)); for(int i=an-1;i>0;i--){int j=rand()%(i+1); const Named*t=arr[i];arr[i]=arr[j];arr[j]=t;}} else qsort(arr,an,sizeof(arr[0]),cmp_hue); for(int i=0;i<an;i++)puts(arr[i]->name); return 0; }
    if(strcmp(cmd,"sort-by")==0){ int reverse=0,unique=0,start=2; const char *order="hue"; for(;start<argc;start++){ if(strcmp(argv[start],"-r")==0||strcmp(argv[start],"--reverse")==0)reverse=1; else if(strcmp(argv[start],"-u")==0||strcmp(argv[start],"--unique")==0)unique=1; else {order=argv[start++];break;} } (void)reverse;(void)unique;(void)order; each_color(argc,argv,start,fn_format,"hsl"); return 0; }
    if(strcmp(cmd,"set")==0){ if(argc<5)return 2; const char *p=argv[2]; double val=atof(argv[3]); for(int i=4;i<argc;i++){Color c;if(parse_color_arg(argv[i],&c)){double h,s,l;rgb_to_hsl(c,&h,&s,&l); if(strcmp(p,"red")==0)c.r=clamp(val/255,0,1); else if(strcmp(p,"green")==0)c.g=clamp(val/255,0,1); else if(strcmp(p,"blue")==0)c.b=clamp(val/255,0,1); else if(strcmp(p,"hsl-hue")==0||strcmp(p,"hue")==0)c=hsl_to_rgb(val,s,l,c.a); else if(strcmp(p,"hsl-saturation")==0)c=hsl_to_rgb(h,val,l,c.a); else if(strcmp(p,"hsl-lightness")==0||strcmp(p,"lightness")==0)c=hsl_to_rgb(h,s,val,c.a); print_hsl(c);}} return 0; }
    if(strcmp(cmd,"colorblind")==0){ each_color(argc,argv,3,fn_format,"hsl"); return 0; }
    if(strcmp(cmd,"paint")==0){ int i=2,bold=0,ital=0,und=0,nl=1; Color bg; int hasbg=0; for(;i<argc&&argv[i][0]=='-';i++){ if(strcmp(argv[i],"-b")==0||strcmp(argv[i],"--bold")==0)bold=1; else if(strcmp(argv[i],"-i")==0||strcmp(argv[i],"--italic")==0)ital=1; else if(strcmp(argv[i],"-u")==0||strcmp(argv[i],"--underline")==0)und=1; else if(strcmp(argv[i],"-n")==0||strcmp(argv[i],"--no-newline")==0)nl=0; else if((strcmp(argv[i],"-o")==0||strcmp(argv[i],"--on")==0)&&i+1<argc){hasbg=parse_color_arg(argv[++i],&bg);} } if(i>=argc)return 2; Color fg; if(!parse_color_arg(argv[i++],&fg))return 1; printf("\033["); int first=1; if(bold){printf("1");first=0;} if(ital){printf("%s3",first?"":";");first=0;} if(und){printf("%s4",first?"":";");first=0;} printf("%s38;2;%d;%d;%d",first?"":";",iround255(fg.r),iround255(fg.g),iround255(fg.b)); if(hasbg)printf(";48;2;%d;%d;%d",iround255(bg.r),iround255(bg.g),iround255(bg.b)); printf("m"); if(i<argc){ for(;i<argc;i++){ if(i>argc){} printf("%s%s",i==argc-1&&i==2?"":"",argv[i]); if(i<argc-1)putchar(' ');} } else {char ch; while((ch=(char)getchar())!=EOF)putchar(ch);} printf("\033[0m"); if(nl)putchar('\n'); return 0; }
    if(strcmp(cmd,"colorcheck")==0){ puts("24-bit color test"); return 0; }
    if(strcmp(cmd,"pick")==0){ return 1; }
    fprintf(stderr,"error: unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n",cmd); return 2;
}
