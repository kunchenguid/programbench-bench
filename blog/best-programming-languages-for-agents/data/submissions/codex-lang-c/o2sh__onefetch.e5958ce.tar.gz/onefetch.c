#define _GNU_SOURCE
#include <ctype.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct { char *name,*email; int n; } Author;
typedef struct { char *name; long n; } Item;

static const char *langs_list[]={"ABNF","ABAP","Ada","Agda","Arduino C++","Assembly","ATS","AutoHotKey","BASH","C","CMake","C#","Ceylon","Clojure","CoffeeScript","ColdFusion","Coq","C++","Crystal","CSS","CUDA","D","Dart","Dockerfile","Emacs Lisp","Elixir","Elm","Emojicode","Erlang","F#","Fish","Forth","FORTRAN Legacy","FORTRAN Modern","GDScript","GLSL","Go","GraphQL","Groovy","Haskell","Haxe","HCL","HLSL","HolyC","HTML","Idris","Java","JavaScript","JSON","Jsonnet","JSX","Julia","Jupyter Notebooks","Kotlin","LLVM","Lean","Common Lisp","Lua","Makefile","Markdown","Modelica","Nim","Nix","OCaml","Objective-C","Odin","OpenSCAD","Org","Oz","Pascal","Perl","PHP","PowerShell","Processing","Prolog","Protocol Buffers","PureScript","Python","QML","R","Racket","Raku","Razor","Ren'Py","Ruby","Rust","Sass","Scala","Scheme","Shell","Solidity","SQL","Svelte","SVG","Swift","SystemVerilog","TCL","TeX","Plain Text","TOML","TSX","TypeScript","Typst","Vala","Verilog","VHDL","Vim Script","Visual Basic","Vue","WebAssembly","Wolfram","XSL","XAML","XML","YAML","Zig","Zsh",0};

static char *xstrdup(const char *s){char *p=strdup(s?s:""); if(!p) exit(1); return p;}
static void trim(char *s){size_t n=strlen(s); while(n&&isspace((unsigned char)s[n-1])) s[--n]=0; char *p=s; while(*p&&isspace((unsigned char)*p))p++; if(p!=s) memmove(s,p,strlen(p)+1);}
static char *quote(const char *s){size_t cap=strlen(s)*4+3,n=0; char *r=malloc(cap); r[n++]='\''; for(;*s;s++){ if(*s=='\''){memcpy(r+n,"'\\''",4);n+=4;} else r[n++]=*s;} r[n++]='\''; r[n]=0; return r;}
static char *cmd(const char *fmt,...){char c[8192]; va_list ap; va_start(ap,fmt); vsnprintf(c,sizeof c,fmt,ap); va_end(ap); FILE*f=popen(c,"r"); if(!f)return xstrdup(""); size_t cap=1024,n=0; char *r=malloc(cap); int ch; while((ch=fgetc(f))!=EOF){ if(n+2>cap){cap*=2;r=realloc(r,cap);} r[n++]=ch;} r[n]=0; pclose(f); trim(r); return r;}
static int cint(const char *fmt,...){char c[8192]; va_list ap; va_start(ap,fmt); vsnprintf(c,sizeof c,fmt,ap); va_end(ap); char *o=cmd("%s",c); int v=atoi(o); free(o); return v;}
static void jstr(const char*s){putchar('"'); for(;s&&*s;s++){unsigned char c=*s; if(c=='"'||c=='\\') printf("\\%c",c); else if(c=='\n') printf("\\n"); else if(c<32) printf("\\u%04x",c); else putchar(c);} putchar('"');}
static void ystr(const char*s){ if(!s||!*s){printf("''");return;} bool q=false; for(const char*p=s;*p;p++) if(*p==':'||*p=='#'||*p=='\''||*p=='"') q=true; if(!q){printf("%s",s);return;} putchar('\''); for(const char*p=s;*p;p++){ if(*p=='\'') printf("''"); else putchar(*p);} putchar('\'');}

static const char *lang(const char *p){const char*b=strrchr(p,'/'); b=b?b+1:p; if(!strcmp(b,"Makefile"))return"Makefile"; if(!strcmp(b,"Dockerfile"))return"Dockerfile"; const char*d=strrchr(b,'.'); if(!d)return 0; d++;
 if(!strcmp(d,"c")||!strcmp(d,"h"))return"C"; if(!strcmp(d,"cpp")||!strcmp(d,"cc")||!strcmp(d,"hpp"))return"C++"; if(!strcmp(d,"rs"))return"Rust"; if(!strcmp(d,"py"))return"Python"; if(!strcmp(d,"js"))return"JavaScript"; if(!strcmp(d,"ts"))return"TypeScript"; if(!strcmp(d,"java"))return"Java"; if(!strcmp(d,"go"))return"Go"; if(!strcmp(d,"md"))return"Markdown"; if(!strcmp(d,"json"))return"JSON"; if(!strcmp(d,"yml")||!strcmp(d,"yaml"))return"YAML"; if(!strcmp(d,"toml"))return"TOML"; if(!strcmp(d,"html"))return"HTML"; if(!strcmp(d,"css"))return"CSS"; if(!strcmp(d,"sh"))return"Shell"; if(!strcmp(d,"rb"))return"Ruby"; return 0;}
static long lines(const char *p,long *bytes){FILE*f=fopen(p,"rb"); if(!f)return 0; long l=0,b=0; int c,last='\n'; while((c=fgetc(f))!=EOF){b++; if(c=='\n')l++; last=c;} fclose(f); if(b&&last!='\n')l++; *bytes=b; return l;}
static void add_item(Item **a,int*n,const char*name,long v){if(!name||!*name||v<=0)return; for(int i=0;i<*n;i++)if(!strcmp((*a)[i].name,name)){(*a)[i].n+=v;return;} *a=realloc(*a,(*n+1)*sizeof**a); (*a)[*n].name=xstrdup(name); (*a)[*n].n=v; (*n)++;}
static int cmp_item(const void*a,const void*b){const Item*x=a,*y=b; if(y->n!=x->n)return y->n>x->n?1:-1; return strcmp(x->name,y->name);}
static int cmp_auth(const void*a,const void*b){const Author*x=a,*y=b; if(y->n!=x->n)return y->n-x->n; return strcmp(x->name,y->name);}
static char *age(long ts){time_t now=time(0); long days=(long)difftime(now,(time_t)ts)/86400; char*r=malloc(64); if(days<1)sprintf(r,"today"); else if(days<30)sprintf(r,"%ld day%s ago",days,days==1?"":"s"); else if(days<365){long m=days/30; sprintf(r,"%ld month%s ago",m,m==1?"":"s");} else {long y=days/365; sprintf(r,"%ld year%s ago",y,y==1?"":"s");} return r;}
static char *hsize(long b){char*r=malloc(64); if(b<1024)sprintf(r,"%ld B",b); else sprintf(r,"%.2f KiB",b/1024.0); return r;}

typedef struct{char*path,*q,*fmt;int na,nl,nc,pool;bool email;char**dis;int nd;} Opt;
static bool dis(Opt*o,const char*f){for(int i=0;i<o->nd;i++)if(!strcmp(o->dis[i],f))return true;return false;}
static bool field(const char*s){const char*f[]={"project","description","head","pending","version","created","languages","dependencies","authors","last-change","contributors","url","commits","churn","lines-of-code","size","license",0}; for(int i=0;f[i];i++)if(!strcmp(s,f[i]))return true;return false;}

static void help(void){puts("Command-line Git information tool\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]\n          Run as if onefetch was started in <input> instead of the current working directory\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nINFO:\n  -d, --disabled-fields <FIELD>...\n          Allows you to disable FIELD(s) from appearing in the output\n\n      --no-title\n          Hides the title\n\n      --number-of-authors <NUM>\n          Maximum NUM of authors to be shown\n          \n          [default: 3]\n\n      --number-of-languages <NUM>\n          Maximum NUM of languages to be shown\n          \n          [default: 6]\n\n      --number-of-file-churns <NUM>\n          Maximum NUM of file churns to be shown\n          \n          [default: 3]\n\n  -o, --output <FORMAT>\n          Outputs Onefetch in a specific format\n          \n          [possible values: json, yaml]\n\n      --generate <SHELL>\n          If provided, outputs the completion file for given SHELL\n          \n          [possible values: bash, elvish, fish, powershell, zsh]\n\nOTHER:\n  -l, --languages\n          Prints out supported languages\n\n  -p, --package-managers\n          Prints out supported package managers");}
static void completion(const char*s){if(!strcmp(s,"bash"))puts("_onefetch() { COMPREPLY=($(compgen -W \"--help --version --output --languages --package-managers --generate\" -- \"${COMP_WORDS[COMP_CWORD]}\")); }\ncomplete -F _onefetch onefetch"); else if(!strcmp(s,"fish"))puts("complete -c onefetch -l output -a 'json yaml'"); else if(!strcmp(s,"zsh"))puts("#compdef onefetch\n_arguments '--output:FORMAT:(json yaml)'"); else if(!strcmp(s,"elvish"))puts("edit:completion:arg-completer[onefetch] = {|@words| }"); else if(!strcmp(s,"powershell"))puts("Register-ArgumentCompleter -Native -CommandName onefetch -ScriptBlock {}"); else {fprintf(stderr,"error: invalid value '%s' for '--generate <SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n",s); exit(2);}}

static void collect(Opt*o,Author**au,int*nau,Item**la,int*nla,long*loc,long*bytes,int*files,Item**ch,int*nch){
 char *log=cmd("git -C %s log --format='%%an\t%%ae'",o->q),*save=0,*p=strtok_r(log,"\n",&save); while(p){char*t=strchr(p,'\t'); if(t){*t=0; int k=-1; for(int i=0;i<*nau;i++)if(!strcmp((*au)[i].name,p)&&!strcmp((*au)[i].email,t+1))k=i; if(k<0){*au=realloc(*au,(*nau+1)*sizeof**au);(*au)[*nau].name=xstrdup(p);(*au)[*nau].email=xstrdup(t+1);(*au)[*nau].n=1;(*nau)++;}else(*au)[k].n++;} p=strtok_r(0,"\n",&save);} free(log); qsort(*au,*nau,sizeof**au,cmp_auth);
 char *ls=cmd("git -C %s ls-files",o->q); save=0; p=strtok_r(ls,"\n",&save); while(p){char full[PATH_MAX]; snprintf(full,sizeof full,"%s/%s",o->path,p); long b=0,l=lines(full,&b); *bytes+=b; (*files)++; const char*lg=lang(p); if(lg){add_item(la,nla,lg,l); *loc+=l;} p=strtok_r(0,"\n",&save);} free(ls); qsort(*la,*nla,sizeof**la,cmp_item);
 int pool=o->pool?o->pool:1; char *co=cmd("git -C %s log -n %d --name-only --pretty=format:",o->q,pool); save=0; p=strtok_r(co,"\n",&save); while(p){trim(p); add_item(ch,nch,p,1); p=strtok_r(0,"\n",&save);} free(co); qsort(*ch,*nch,sizeof**ch,cmp_item);
}

static void output(Opt*o,bool yaml){
 char *gitver=cmd("git --version"),*user=cmd("git -C %s config user.name",o->q),*head=cmd("git -C %s rev-parse --short HEAD 2>/dev/null",o->q),*br=cmd("git -C %s branch --show-current",o->q),*ver=cmd("git -C %s describe --tags --abbrev=0 2>/dev/null",o->q),*url=cmd("git -C %s config --get remote.origin.url",o->q);
 int tags=cint("git -C %s tag --list | wc -l",o->q), commits=cint("git -C %s rev-list --count HEAD 2>/dev/null",o->q), add=0,mod=0,del=0;
 char *st=cmd("git -C %s status --porcelain",o->q),*save=0,*p=strtok_r(st,"\n",&save); while(p){if(p[0]=='?'&&p[1]=='?')add++; else{if(p[0]=='A'||p[1]=='A')add++; if(p[0]=='M'||p[1]=='M')mod++; if(p[0]=='D'||p[1]=='D')del++;} p=strtok_r(0,"\n",&save);}
 long first=atol(cmd("git -C %s log --reverse --format=%%ct | head -1",o->q)), last=atol(cmd("git -C %s log -1 --format=%%ct",o->q)); char *created=age(first),*changed=age(last);
 Author*au=0; Item*la=0,*ch=0; int nau=0,nla=0,nch=0,files=0; long loc=0,bytes=0; collect(o,&au,&nau,&la,&nla,&loc,&bytes,&files,&ch,&nch); char *sz=hsize(bytes);
 char *lic=xstrdup(""); char *lf=cmd("git -C %s ls-files | grep -i -m1 '^LICENSE\\|/LICENSE\\|COPYING' 2>/dev/null",o->q); if(*lf){char full[PATH_MAX];snprintf(full,sizeof full,"%s/%s",o->path,lf); char *qf=quote(full); char *txt=cmd("head -40 %s",qf); if(strstr(txt,"MIT License")||strstr(txt,"Permission is hereby granted")){free(lic);lic=xstrdup("MIT");} free(qf); free(txt);}
 if(!yaml){
  printf("{\n  \"title\": {\n    \"gitUsername\": ");jstr(user);printf(",\n    \"gitVersion\": ");jstr(gitver);printf("\n  },\n  \"infoFields\": [\n"); int comma=0;
#define JC() do{if(comma)printf(",\n"); comma=1;}while(0)
  if(!dis(o,"project")){JC();printf("    {\"ProjectInfo\":{\"repoName\":\"\",\"numberOfBranches\":0,\"numberOfTags\":%d}}",tags);}
  if(!dis(o,"description")){JC();printf("    {\"DescriptionInfo\":{\"description\":null}}");}
  if(!dis(o,"head")){JC();printf("    {\"HeadInfo\":{\"headRefs\":{\"shortCommitId\":");jstr(head);printf(",\"refs\":[");jstr(*br?br:"HEAD");printf("]}}}");}
  if(!dis(o,"pending")){JC();printf("    {\"PendingInfo\":{\"added\":%d,\"deleted\":%d,\"modified\":%d}}",add,del,mod);}
  if(!dis(o,"version")){JC();printf("    {\"VersionInfo\":{\"version\":");jstr(ver);printf("}}");}
  if(!dis(o,"created")){JC();printf("    {\"CreatedInfo\":{\"creationDate\":");jstr(created);printf("}}");}
  if(!dis(o,"languages")&&nla){JC();printf("    {\"LanguagesInfo\":{\"languagesWithPercentage\":["); long total=0;for(int i=0;i<nla;i++)total+=la[i].n; for(int i=0;i<nla&&i<o->nl;i++){if(i)printf(",");printf("{\"language\":");jstr(la[i].name);printf(",\"percentage\":%.1f}",total?100.0*la[i].n/total:0);} printf("]}}");}
  if(!dis(o,"dependencies")){JC();printf("    {\"DependenciesInfo\":{\"dependencies\":\"\"}}");}
  if(!dis(o,"authors")){JC();printf("    {\"AuthorsInfo\":{\"authors\":["); for(int i=0;i<nau&&i<o->na;i++){if(i)printf(",");printf("{\"name\":");jstr(au[i].name);printf(",\"email\":"); if(o->email)jstr(au[i].email); else printf("null"); printf(",\"nbrOfCommits\":%d,\"contribution\":%d}",au[i].n,commits?au[i].n*100/commits:0);} printf("]}}");}
  if(!dis(o,"last-change")){JC();printf("    {\"LastChangeInfo\":{\"lastChange\":");jstr(changed);printf("}}");}
  if(!dis(o,"contributors")){JC();printf("    {\"ContributorsInfo\":{\"totalNumberOfAuthors\":%d}}",nau);}
  if(!dis(o,"url")){JC();printf("    {\"UrlInfo\":{\"repoUrl\":");jstr(url);printf("}}");}
  if(!dis(o,"commits")){JC();printf("    {\"CommitsInfo\":{\"numberOfCommits\":%d,\"isShallow\":false}}",commits);}
  if(!dis(o,"churn")){JC();printf("    {\"ChurnInfo\":{\"file_churns\":["); for(int i=0;i<nch&&i<o->nc;i++){if(i)printf(",");printf("{\"filePath\":");jstr(ch[i].name);printf(",\"nbrOfCommits\":%ld}",ch[i].n);} printf("],\"churn_pool_size\":%d}}",o->pool?o->pool:1);}
  if(!dis(o,"lines-of-code")&&loc){JC();printf("    {\"LocInfo\":{\"linesOfCode\":%ld}}",loc);}
  if(!dis(o,"size")){JC();printf("    {\"SizeInfo\":{\"repoSize\":");jstr(sz);printf(",\"fileCount\":%d}}",files);}
  if(!dis(o,"license")){JC();printf("    {\"LicenseInfo\":{\"license\":");jstr(lic);printf("}}");}
  printf("\n  ]\n}\n");
 } else {
  printf("title:\n  gitUsername: ");ystr(user);printf("\n  gitVersion: ");ystr(gitver);printf("\ninfoFields:\n");
  if(!dis(o,"project"))printf("- ProjectInfo:\n    repoName: ''\n    numberOfBranches: 0\n    numberOfTags: %d\n",tags);
  if(!dis(o,"description"))printf("- DescriptionInfo:\n    description: null\n");
  if(!dis(o,"head")){printf("- HeadInfo:\n    headRefs:\n      shortCommitId: ");ystr(head);printf("\n      refs:\n      - ");ystr(*br?br:"HEAD");printf("\n");}
  if(!dis(o,"pending"))printf("- PendingInfo:\n    added: %d\n    deleted: %d\n    modified: %d\n",add,del,mod);
  if(!dis(o,"version")){printf("- VersionInfo:\n    version: ");ystr(ver);printf("\n");}
  if(!dis(o,"created")){printf("- CreatedInfo:\n    creationDate: ");ystr(created);printf("\n");}
  if(!dis(o,"languages")&&nla){printf("- LanguagesInfo:\n    languagesWithPercentage:\n"); long total=0;for(int i=0;i<nla;i++)total+=la[i].n; for(int i=0;i<nla&&i<o->nl;i++)printf("    - language: %s\n      percentage: %.1f\n",la[i].name,total?100.0*la[i].n/total:0);}
  if(!dis(o,"dependencies"))printf("- DependenciesInfo:\n    dependencies: ''\n");
  if(!dis(o,"authors")){printf("- AuthorsInfo:\n    authors:\n"); for(int i=0;i<nau&&i<o->na;i++){printf("    - name: ");ystr(au[i].name);printf("\n      email: "); if(o->email)ystr(au[i].email); else printf("null"); printf("\n      nbrOfCommits: %d\n      contribution: %d\n",au[i].n,commits?au[i].n*100/commits:0);}}
  if(!dis(o,"last-change")){printf("- LastChangeInfo:\n    lastChange: ");ystr(changed);printf("\n");}
  if(!dis(o,"contributors"))printf("- ContributorsInfo:\n    totalNumberOfAuthors: %d\n",nau);
  if(!dis(o,"url")){printf("- UrlInfo:\n    repoUrl: ");ystr(url);printf("\n");}
  if(!dis(o,"commits"))printf("- CommitsInfo:\n    numberOfCommits: %d\n    isShallow: false\n",commits);
  if(!dis(o,"churn")){printf("- ChurnInfo:\n    file_churns:\n"); for(int i=0;i<nch&&i<o->nc;i++)printf("    - filePath: %s\n      nbrOfCommits: %ld\n",ch[i].name,ch[i].n); printf("    churn_pool_size: %d\n",o->pool?o->pool:1);}
  if(!dis(o,"lines-of-code")&&loc)printf("- LocInfo:\n    linesOfCode: %ld\n",loc);
  if(!dis(o,"size"))printf("- SizeInfo:\n    repoSize: %s\n    fileCount: %d\n",sz,files);
  if(!dis(o,"license")){printf("- LicenseInfo:\n    license: ");ystr(lic);printf("\n");}
 }
}

int main(int argc,char**argv){Opt o={.path=".",.na=3,.nl=6,.nc=3}; for(int i=1;i<argc;i++){char*a=argv[i];
 if(!strcmp(a,"-h")||!strcmp(a,"--help")){help();return 0;} if(!strcmp(a,"-V")||!strcmp(a,"--version")){puts("onefetch 2.25.0");return 0;} if(!strcmp(a,"-l")||!strcmp(a,"--languages")){for(int j=0;langs_list[j];j++)puts(langs_list[j]);return 0;} if(!strcmp(a,"-p")||!strcmp(a,"--package-managers")){puts("Npm\nCargo");return 0;} if(!strcmp(a,"--generate")){if(++i<argc)completion(argv[i]);return 0;}
 if(!strcmp(a,"-o")||!strcmp(a,"--output")){if(++i>=argc)return 2; if(strcmp(argv[i],"json")&&strcmp(argv[i],"yaml")){fprintf(stderr,"error: invalid value '%s' for '--output <FORMAT>'\n  [possible values: json, yaml]\n\nFor more information, try '--help'.\n",argv[i]);return 2;} o.fmt=argv[i];}
 else if(!strcmp(a,"-E")||!strcmp(a,"--email"))o.email=1; else if(!strcmp(a,"--number-of-authors")&&i+1<argc)o.na=atoi(argv[++i]); else if(!strcmp(a,"--number-of-languages")&&i+1<argc)o.nl=atoi(argv[++i]); else if(!strcmp(a,"--number-of-file-churns")&&i+1<argc)o.nc=atoi(argv[++i]); else if(!strcmp(a,"--churn-pool-size")&&i+1<argc)o.pool=atoi(argv[++i]);
 else if((!strcmp(a,"-d")||!strcmp(a,"--disabled-fields"))){while(i+1<argc&&argv[i+1][0]!='-'){i++; if(!field(argv[i])){fprintf(stderr,"error: invalid value '%s' for '--disabled-fields <FIELD>...'\n  [possible values: project, description, head, pending, version, created, languages, dependencies, authors, last-change, contributors, url, commits, churn, lines-of-code, size, license]\n\nFor more information, try '--help'.\n",argv[i]);return 2;} o.dis=realloc(o.dis,(o.nd+1)*sizeof(char*)); o.dis[o.nd++]=argv[i];}}
 else if(a[0]=='-'){ if(i+1<argc && strcmp(a,"--no-art")&&strcmp(a,"--no-color-palette")&&strcmp(a,"--no-bold")&&strcmp(a,"--no-title")&&strcmp(a,"--no-merges")&&strcmp(a,"--include-hidden")&&strcmp(a,"--http-url")&&strcmp(a,"--hide-token")&&strcmp(a,"--nerd-fonts")) i++; }
 else o.path=a; }
 char real[PATH_MAX]; if(realpath(o.path,real))o.path=xstrdup(real); o.q=quote(o.path); char *inside=cmd("git -C %s rev-parse --is-inside-work-tree 2>/dev/null",o.q); if(strcmp(inside,"true")){fprintf(stderr,"Error: %s is not a git repository\n",o.path);return 1;} if(o.fmt&&strcmp(o.fmt,"yaml")==0)output(&o,1); else if(o.fmt&&strcmp(o.fmt,"json")==0)output(&o,0); else {printf("Onefetch - Command-line Git information tool\nRepository: %s\nCommits: %d\n",o.path,cint("git -C %s rev-list --count HEAD",o.q));} return 0;}
