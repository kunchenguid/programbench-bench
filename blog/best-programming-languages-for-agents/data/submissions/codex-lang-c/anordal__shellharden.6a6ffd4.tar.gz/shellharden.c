#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char *p; size_t n, cap; } Buf;

static void addn(Buf *b, const char *s, size_t n) {
    if (!n) return;
    if (b->n + n + 1 > b->cap) {
        size_t c = b->cap ? b->cap : 256;
        while (b->n + n + 1 > c) c *= 2;
        b->p = (char *)realloc(b->p, c);
        if (!b->p) exit(111);
        b->cap = c;
    }
    memcpy(b->p + b->n, s, n);
    b->n += n;
    b->p[b->n] = 0;
}

static void adds(Buf *b, const char *s) { addn(b, s, strlen(s)); }
static void addc(Buf *b, char c) { addn(b, &c, 1); }

static int is_name0(int c) { return isalpha((unsigned char)c) || c == '_'; }
static int is_name(int c) { return isalnum((unsigned char)c) || c == '_'; }
static int is_space(int c) { return c == ' ' || c == '\t' || c == '\r' || c == '\n'; }
static int is_word_break(int c) {
    return c == 0 || is_space(c) || c == ';' || c == '&' || c == '|' ||
           c == '(' || c == ')' || c == '<' || c == '>';
}

static char *xstrndup(const char *s, size_t n) {
    char *r = (char *)malloc(n + 1);
    if (!r) exit(111);
    memcpy(r, s, n);
    r[n] = 0;
    return r;
}

static char *read_stream(FILE *f) {
    Buf b = {0};
    char tmp[4096];
    size_t n;
    while ((n = fread(tmp, 1, sizeof tmp, f)) > 0) addn(&b, tmp, n);
    if (!b.p) adds(&b, "");
    return b.p;
}

static int starts_word(const char *s, size_t i, const char *w) {
    size_t n = strlen(w);
    if (i && !is_word_break((unsigned char)s[i-1])) return 0;
    return strncmp(s + i, w, n) == 0 && is_word_break((unsigned char)s[i+n]);
}

static size_t find_matching(const char *s, size_t i, char open, char close) {
    int depth = 1, sq = 0, dq = 0, esc = 0;
    for (; s[i]; i++) {
        char c = s[i];
        if (esc) { esc = 0; continue; }
        if (c == '\\') { esc = 1; continue; }
        if (sq) { if (c == '\'') sq = 0; continue; }
        if (dq) { if (c == '"') dq = 0; }
        else if (c == '\'') { sq = 1; continue; }
        if (!sq && c == '"') { dq = !dq; continue; }
        if (!sq && c == open) depth++;
        else if (!sq && c == close && --depth == 0) return i;
    }
    return (size_t)-1;
}

static size_t parse_dollar(const char *s, size_t i, char **text) {
    size_t j = i + 1;
    *text = NULL;
    if (s[j] == '{') {
        size_t e = find_matching(s, j + 1, '{', '}');
        if (e == (size_t)-1) return 0;
        char *raw = xstrndup(s + i, e - i + 1);
        if (strstr(raw, "[*]")) {
            char *p = strstr(raw, "[*]");
            p[1] = '@';
        }
        *text = raw;
        return e + 1;
    }
    if (is_name0((unsigned char)s[j])) {
        while (is_name((unsigned char)s[j])) j++;
        *text = xstrndup(s + i, j - i);
        return j;
    }
    if (isdigit((unsigned char)s[j]) || strchr("@*#?$!-", s[j])) {
        *text = xstrndup(s + i, 2);
        return j + 1;
    }
    return 0;
}

static char *transform_range(const char *s, size_t len, int in_dq);

static size_t transform_cmdsub(const char *s, size_t i, Buf *out, int quote_outer) {
    size_t start, end, close_len;
    if (s[i+1] == '(') {
        start = i + 2;
        end = find_matching(s, start, '(', ')');
        close_len = 1;
    } else {
        start = i + 1;
        int esc = 0;
        for (end = start; s[end]; end++) {
            if (esc) { esc = 0; continue; }
            if (s[end] == '\\') { esc = 1; continue; }
            if (s[end] == '`') break;
        }
        close_len = 1;
    }
    if (end == (size_t)-1 || !s[end]) return 0;
    char *inner = transform_range(s + start, end - start, 0);
    if (quote_outer) addc(out, '"');
    if (s[i+1] == '(') {
        adds(out, "$("); adds(out, inner); addc(out, ')');
    } else {
        adds(out, "$("); adds(out, inner); addc(out, ')');
    }
    if (quote_outer) addc(out, '"');
    free(inner);
    return end + close_len;
}

static int word_before_is_assignment_or_decl(const char *s, size_t i) {
    size_t a = i, b;
    while (a && !is_word_break((unsigned char)s[a-1])) a--;
    b = a;
    while (b < i && s[b] != '=') b++;
    if (b < i && b > a && is_name0((unsigned char)s[a])) return 1;
    while (a && is_space((unsigned char)s[a-1])) a--;
    b = a;
    while (a && !is_word_break((unsigned char)s[a-1])) a--;
    return (strncmp(s+a, "export", b-a) == 0 && b-a == 6) ||
           (strncmp(s+a, "local", b-a) == 0 && b-a == 5) ||
           (strncmp(s+a, "declare", b-a) == 0 && b-a == 7) ||
           (strncmp(s+a, "typeset", b-a) == 0 && b-a == 7);
}

static int previous_word_is(const char *s, size_t i, const char *want) {
    size_t b = i;
    while (b && is_space((unsigned char)s[b-1])) b--;
    while (b && !is_word_break((unsigned char)s[b-1])) b--;
    size_t e = b;
    while (s[e] && !is_word_break((unsigned char)s[e])) e++;
    return strlen(want) == e - b && strncmp(s + b, want, e - b) == 0;
}

static void normalize_simple_braces(char *v) {
    if (v[0] != '$' || v[1] != '{') return;
    size_t n = strlen(v);
    if (n < 4 || v[n-1] != '}') return;
    for (size_t i = 2; i + 1 < n; i++) {
        if (!is_name((unsigned char)v[i])) return;
    }
    memmove(v + 1, v + 2, n - 2);
    v[n - 2] = 0;
}

static char *array_form(const char *v) {
    if (v[0] == '$' && v[1] == '{') {
        size_t n = strlen(v);
        if (n > 3 && v[n-1] == '}') {
            char *r = (char *)malloc(n + 4);
            if (!r) exit(111);
            memcpy(r, v, n);
            r[n-1] = '['; r[n] = '@'; r[n+1] = ']'; r[n+2] = '}'; r[n+3] = 0;
            return r;
        }
    }
    if (v[0] == '$' && is_name0((unsigned char)v[1])) {
        size_t n = strlen(v);
        char *r = (char *)malloc(n + 6);
        if (!r) exit(111);
        snprintf(r, n + 6, "${%s[@]}", v + 1);
        return r;
    }
    return NULL;
}

static char *transform_range(const char *s, size_t len, int in_dq) {
    Buf out = {0};
    char *z = xstrndup(s, len);
    s = z;
    int sq = 0, dq = in_dq, esc = 0, bol = 1, heredoc = 0;
    char heredoc_tag[128] = "";
    int in_dbl_bracket = 0;
    for (size_t i = 0; s[i]; ) {
        if (bol && heredoc) {
            size_t j = i; while (s[j] && s[j] != '\n') j++;
            addn(&out, s+i, j-i);
            if (strncmp(s+i, heredoc_tag, strlen(heredoc_tag)) == 0 &&
                i + strlen(heredoc_tag) == j) heredoc = 0;
            if (s[j] == '\n') { addc(&out, '\n'); i = j + 1; bol = 1; } else i = j;
            continue;
        }
        char c = s[i];
        if (esc) { addc(&out, c); esc = 0; bol = (c == '\n'); i++; continue; }
        if (c == '\\') { addc(&out, c); esc = 1; i++; continue; }
        if (!sq && !dq && c == '#') {
            size_t j = i; while (s[j] && s[j] != '\n') j++;
            addn(&out, s+i, j-i); i = j; continue;
        }
        if (!dq && c == '\'') { sq = !sq; addc(&out, c); i++; continue; }
        if (!sq && c == '"') { dq = !dq; addc(&out, c); i++; continue; }
        if (!sq && !dq && starts_word(s, i, "[[")) in_dbl_bracket = 1;
        if (!sq && !dq && starts_word(s, i, "]]")) in_dbl_bracket = 0;
        if (!sq && !dq && s[i] == '<' && s[i+1] == '<') {
            addn(&out, s+i, 2); i += 2;
            if (s[i] == '-') { addc(&out, s[i++]); }
            while (is_space((unsigned char)s[i]) && s[i] != '\n') addc(&out, s[i++]);
            char q = 0; if (s[i] == '\'' || s[i] == '"') { q = s[i]; addc(&out, s[i++]); }
            size_t k = 0;
            while (s[i] && !is_word_break((unsigned char)s[i]) && (!q || s[i] != q)) {
                if (k + 1 < sizeof heredoc_tag) heredoc_tag[k++] = s[i];
                addc(&out, s[i++]);
            }
            heredoc_tag[k] = 0;
            if (q && s[i] == q) addc(&out, s[i++]);
            heredoc = heredoc_tag[0] != 0;
            continue;
        }
        if (!sq && c == '$' && s[i+1] == '(') {
            size_t ni = transform_cmdsub(s, i, &out, !dq);
            if (ni) { i = ni; bol = 0; continue; }
        }
        if (!sq && !dq && c == '`') {
            size_t ni = transform_cmdsub(s, i, &out, 1);
            if (ni) { i = ni; bol = 0; continue; }
        }
        if (!sq && c == '$') {
            char *v = NULL; size_t ni = parse_dollar(s, i, &v);
            if (ni) {
                if (dq || in_dbl_bracket || word_before_is_assignment_or_decl(s, i)) {
                    adds(&out, v);
                } else {
                    char *arr = previous_word_is(s, i, "in") ? array_form(v) : NULL;
                    if (!arr && is_word_break((unsigned char)s[ni])) normalize_simple_braces(v);
                    addc(&out, '"'); adds(&out, arr ? arr : v); addc(&out, '"');
                    free(arr);
                }
                free(v); i = ni; bol = 0; continue;
            }
        }
        addc(&out, c);
        bol = (c == '\n');
        i++;
    }
    free(z);
    if (!out.p) adds(&out, "");
    return out.p;
}

static char *fix_tests(const char *input) {
    char *s = transform_range(input, strlen(input), 0);
    const struct { const char *a, *b; } reps[] = {
        {"[ -n \"$", "[ \"$"}, {"[ -z \"$", "[ \"$"},
        {"\" ]", "\" != \"\" ]"}, {NULL, NULL}
    };
    (void)reps;
    return s;
}

static char *transform(const char *input) {
    char *s = fix_tests(input);
    /* Small compatibility pass for the common [ -n/-z "$x" ] rewrites. */
    Buf out = {0};
    for (size_t i = 0; s[i]; ) {
        if (strncmp(s+i, "[ -n \"", 6) == 0) {
            size_t j = i + 6;
            while (s[j] && strncmp(s+j, "\" ]", 3) != 0) j++;
            if (s[j]) { adds(&out, "[ \""); addn(&out, s+i+6, j-(i+6)); adds(&out, "\" != \"\" ]"); i = j + 3; continue; }
        }
        if (strncmp(s+i, "[ -z \"", 6) == 0) {
            size_t j = i + 6;
            while (s[j] && strncmp(s+j, "\" ]", 3) != 0) j++;
            if (s[j]) { adds(&out, "[ \""); addn(&out, s+i+6, j-(i+6)); adds(&out, "\" = \"\" ]"); i = j + 3; continue; }
        }
        addc(&out, s[i++]);
    }
    free(s);
    if (!out.p) adds(&out, "");
    return out.p;
}

static const char *help =
"Shellharden: The corrective bash syntax highlighter.\n\n"
"Usage:\n\tshellharden [options] [files]\n\tcat files | shellharden [options] ''\n\n"
"Shellharden is a syntax highlighter and a tool to semi-automate the rewriting\n"
"of scripts to ShellCheck conformance, mainly focused on quoting.\n\n"
"The default mode of operation is like `cat`, but with syntax highlighting in\n"
"foreground colors and suggestive changes in background colors.\n\n"
"Options:\n"
"\t--suggest         Output a colored diff suggesting changes.\n"
"\t--syntax          Output syntax highlighting with ANSI colors.\n"
"\t--syntax-suggest  Diff with syntax highlighting (default mode).\n"
"\t--transform       Output suggested changes.\n"
"\t--check           No output; exit with 2 if changes are suggested.\n"
"\t--replace         Replace file contents with suggested changes.\n"
"\t--                Don't treat further arguments as options.\n"
"\t-h|--help         Show help text.\n"
"\t--version         Show version.\n\n"
"The changes suggested by Shellharden inhibits word splitting and indirect\n"
"pathname expansion. This will make your script ShellCheck compliant in terms of\n"
"quoting. Whether your script will work afterwards is a different question:\n"
"If your script was using those features on purpose, it obviously won't anymore!\n\n"
"Every script is possible to write without using word splitting or indirect\n"
"pathname expansion, but it may involve doing things differently.\n"
"See the accompanying file how_to_do_things_safely_in_bash.md or online:\n"
"https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md\n";

enum Mode { M_SYNTAX_SUGGEST, M_SUGGEST, M_SYNTAX, M_TRANSFORM, M_CHECK, M_REPLACE };

static char *read_file(const char *path) {
    if (path[0] == 0) return read_stream(stdin);
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "%s: %s (os error %d)\n", path, strerror(errno), errno);
        return xstrndup("", 0);
    }
    char *s = read_stream(f);
    fclose(f);
    return s;
}

int main(int argc, char **argv) {
    enum Mode mode = M_SYNTAX_SUGGEST;
    int argi = 1, stop = 0, had_file = 0, changed = 0, info_only = 0, mode_set = 0;
    const char *output_path = NULL;
    for (; argi < argc; argi++) {
        char *a = argv[argi];
        if (!stop && strcmp(a, "--") == 0) { stop = 1; continue; }
        if (!stop && a[0] == '-' && a[1]) {
            if (!strcmp(a, "-h") || !strcmp(a, "--help")) { fputs(help, stdout); info_only = 1; continue; }
            else if (!strcmp(a, "--version")) { puts("4.3.1"); info_only = 1; continue; }
            else if (!strcmp(a, "--suggest")) { mode = M_SUGGEST; mode_set = 1; }
            else if (!strcmp(a, "--syntax")) { mode = M_SYNTAX; mode_set = 1; }
            else if (!strcmp(a, "--syntax-suggest")) { mode = M_SYNTAX_SUGGEST; mode_set = 1; }
            else if (!strcmp(a, "--transform")) { mode = M_TRANSFORM; mode_set = 1; }
            else if (!strcmp(a, "--check")) { mode = M_CHECK; mode_set = 1; }
            else if (!strcmp(a, "--replace")) { mode = M_REPLACE; mode_set = 1; }
            else if (!strcmp(a, "--preview")) { mode = M_SUGGEST; mode_set = 1; }
            else if (!strcmp(a, "-o") && argi + 1 < argc) { output_path = argv[++argi]; }
            else fprintf(stderr, "%s: No such option.\n", a);
            continue;
        }
        had_file = 1;
        char *in = read_file(a);
        char *tr = transform(in);
        if (strcmp(in, tr) != 0) changed = 1;
        if (mode == M_REPLACE) {
            if (a[0]) {
                FILE *f = fopen(a, "wb");
                if (f) { fwrite(tr, 1, strlen(tr), f); fclose(f); }
                else fprintf(stderr, "%s: %s (os error %d)\n", a, strerror(errno), errno);
            }
        } else if (mode == M_TRANSFORM || mode == M_SUGGEST || mode == M_SYNTAX_SUGGEST) {
            FILE *o = output_path ? fopen(output_path, "wb") : stdout;
            if (o) { fputs(tr, o); if (output_path) fclose(o); }
            else fprintf(stderr, "%s: %s (os error %d)\n", output_path, strerror(errno), errno);
        } else if (mode == M_SYNTAX) {
            fputs(in, stdout);
        }
        free(in); free(tr);
    }
    if (!had_file && (!info_only || mode_set)) {
        char *in = read_stream(stdin);
        char *tr = transform(in);
        if (strcmp(in, tr) != 0) changed = 1;
        if (mode == M_TRANSFORM || mode == M_SUGGEST || mode == M_SYNTAX_SUGGEST) {
            FILE *o = output_path ? fopen(output_path, "wb") : stdout;
            if (o) { fputs(tr, o); if (output_path) fclose(o); }
            else fprintf(stderr, "%s: %s (os error %d)\n", output_path, strerror(errno), errno);
        } else if (mode != M_CHECK && mode != M_REPLACE) fputs(in, stdout);
        free(in); free(tr);
    }
    return mode == M_CHECK && changed ? 2 : 0;
}
