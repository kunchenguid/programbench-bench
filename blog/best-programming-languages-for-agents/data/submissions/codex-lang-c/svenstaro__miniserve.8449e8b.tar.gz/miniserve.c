#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct {
    char root[PATH_MAX];
    char root_file_name[NAME_MAX + 1];
    int root_is_file;
    int port;
    int verbose;
    int hidden;
    int no_symlinks;
    int disable_indexing;
    int dirs_first;
    int upload;
    int mkdir_enabled;
    int rm_enabled;
    int pretty_urls;
    int spa;
    int readme;
    int hide_footer;
    int show_wget;
    int enable_webdav;
    char *index_name;
    char *title;
    char *auth;
    char *route_prefix;
    char *file_external_url;
    char *headers[64];
    int header_count;
} Config;

typedef struct {
    char method[16], target[2048], path[2048], query[2048], version[16];
    char *headers;
    unsigned char *body;
    size_t body_len;
} Request;

static Config cfg;
static volatile sig_atomic_t running = 1;

static void on_sig(int sig) { (void)sig; running = 0; }

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { perror("strdup"); exit(1); }
    return r;
}

static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static int starts_with(const char *s, const char *p) {
    return strncmp(s, p, strlen(p)) == 0;
}

static int is_truthy(const char *s) {
    return s && *s && strcasecmp(s, "0") && strcasecmp(s, "false") && strcasecmp(s, "no");
}

static void print_help(int long_help) {
    printf("For when you really just want to serve some files over HTTP right now!\n\n");
    printf("Usage: executable [OPTIONS] [PATH]\n\n");
    printf("Arguments:\n  [PATH]%s Which path to serve [env: MINISERVE_PATH=]\n\n", long_help ? "\n          " : " ");
    printf("Options:\n");
    printf("  -v, --verbose%sBe verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]\n", long_help ? "\n          " : "\n          ");
    printf("      --index <INDEX>\n          The name of a directory index file to serve, like \"index.html\" [env: MINISERVE_INDEX=]\n");
    printf("      --spa\n          Activate SPA (Single Page Application) mode [env: MINISERVE_SPA=]\n");
    printf("      --pretty-urls\n          Activate Pretty URLs mode [env: MINISERVE_PRETTY_URLS=]\n");
    printf("  -p, --port <PORT>\n          Port to use [env: MINISERVE_PORT=] [default: 8080]\n");
    printf("  -i, --interfaces <INTERFACES>\n          Interface to listen on [env: MINISERVE_INTERFACE=]\n");
    printf("  -a, --auth <AUTH>\n          Set authentication [env: MINISERVE_AUTH=]\n");
    printf("      --auth-file <AUTH_FILE>\n          Read authentication values from a file [env: MINISERVE_AUTH_FILE=]\n");
    printf("      --route-prefix <ROUTE_PREFIX>\n          Use a specific route prefix [env: MINISERVE_ROUTE_PREFIX=]\n");
    printf("      --random-route\n          Generate a random 6-hexdigit route [env: MINISERVE_RANDOM_ROUTE=]\n");
    printf("  -P, --no-symlinks\n          Hide symlinks in listing and prevent them from being followed [env: MINISERVE_NO_SYMLINKS=]\n");
    printf("  -H, --hidden\n          Show hidden files [env: MINISERVE_HIDDEN=]\n");
    printf("  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>\n          Default sorting method for file list [env: MINISERVE_DEFAULT_SORTING_METHOD=] [default: name] [possible values: name, size, date]\n");
    printf("  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>\n          Default sorting order for file list [env: MINISERVE_DEFAULT_SORTING_ORDER=] [default: desc] [possible values: asc, desc]\n");
    printf("  -c, --color-scheme <COLOR_SCHEME>\n          Default color scheme [env: MINISERVE_COLOR_SCHEME=] [default: squirrel] [possible values: squirrel, archlinux, zenburn, monokai]\n");
    printf("  -d, --color-scheme-dark <COLOR_SCHEME_DARK>\n          Default color scheme [env: MINISERVE_COLOR_SCHEME_DARK=] [default: archlinux] [possible values: squirrel, archlinux, zenburn, monokai]\n");
    printf("  -q, --qrcode\n          Enable QR code display [env: MINISERVE_QRCODE=]\n");
    printf("  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]\n          Enable file uploading (and optionally specify for which directory) [env: MINISERVE_ALLOWED_UPLOAD_DIR=]\n");
    printf("      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>\n          Configure amount of concurrent uploads when visiting the website [default: 0]\n");
    printf("      --chmod <CHMOD>\n          Set unix file permissions of uploaded files [env: MINISERVE_CHMOD=]\n");
    printf("      --directory-size\n          Enable recursive directory size calculation [env: MINISERVE_DIRECTORY_SIZE=]\n");
    printf("  -U, --mkdir\n          Enable creating directories [env: MINISERVE_MKDIR_ENABLED=]\n");
    printf("  -m, --media-type <MEDIA_TYPE>\n          Specify uploadable media types [possible values: image, audio, video]\n");
    printf("  -M, --raw-media-type <MEDIA_TYPE_RAW>\n          Directly specify the uploadable media type expression\n");
    printf("  -o, --on-duplicate-files <ON_DUPLICATE_FILES>\n          What to do if existing files with same name is present during file upload [default: error] [possible values: error, overwrite, rename]\n");
    printf("  -R, --rm-files [<ALLOWED_RM_DIR>]\n          Enable file and directory deletion (and optionally specify for which directory)\n");
    printf("  -r, --enable-tar\n          Enable uncompressed tar archive generation\n");
    printf("  -g, --enable-tar-gz\n          Enable gz-compressed tar archive generation\n");
    printf("  -z, --enable-zip\n          Enable zip archive generation\n");
    printf("  -C, --compress-response\n          Compress response\n");
    printf("  -D, --dirs-first\n          List directories first\n");
    printf("  -t, --title <TITLE>\n          Shown instead of host in page title and heading\n");
    printf("      --header <HEADER>\n          Inserts custom headers into the responses\n");
    printf("  -l, --show-symlink-info\n          Visualize symlinks in directory listing\n");
    printf("  -F, --hide-version-footer\n          Hide version footer\n");
    printf("      --hide-theme-selector\n          Hide theme selector\n");
    printf("  -W, --show-wget-footer\n          If enabled, display a wget command to recursively download the current directory\n");
    printf("      --print-completions <shell>\n          Generate completion file for a shell [possible values: bash, elvish, fish, powershell, zsh]\n");
    printf("      --print-manpage\n          Generate man page\n");
    printf("      --tls-cert <TLS_CERT>\n          TLS certificate to use\n");
    printf("      --tls-key <TLS_KEY>\n          TLS private key to use\n");
    printf("      --readme\n          Enable README.md rendering in directories\n");
    printf("  -I, --disable-indexing\n          Disable indexing\n");
    printf("      --enable-webdav\n          Enable read-only WebDAV support (PROPFIND requests)\n");
    printf("      --size-display <SIZE_DISPLAY>\n          Show served file size in exact bytes [default: human] [possible values: human, exact]\n");
    printf("      --file-external-url <FILE_EXTERNAL_URL>\n          Optional external URL prepended to file links in listings\n");
    printf("  -h, --help\n          Print help (see %s with '%s')\n", long_help ? "a summary" : "more", long_help ? "-h" : "--help");
    printf("  -V, --version\n          Print version\n");
}

static void print_manpage(void) {
    printf(".TH miniserve 1  \"miniserve 0.32.0\"\n.SH NAME\nminiserve \\- For when you really just want to serve some files over HTTP right now!\n.SH SYNOPSIS\n.B miniserve\n[OPTIONS] [PATH]\n.SH DESCRIPTION\nSmall command-line tool that serves files and directories over HTTP.\n");
}

static void print_completions(const char *shell) {
    if (!strcmp(shell, "bash")) printf("_executable() { COMPREPLY=(); }\ncomplete -F _executable executable\n");
    else if (!strcmp(shell, "fish")) printf("complete -c executable -s p -l port -d 'Port to use'\n");
    else printf("# completion for %s\n", shell);
}

static char *url_decode(const char *s) {
    char *out = malloc(strlen(s) + 1), *p = out;
    for (; *s; s++) {
        if (*s == '%' && isxdigit((unsigned char)s[1]) && isxdigit((unsigned char)s[2])) {
            char h[3] = {s[1], s[2], 0};
            *p++ = (char)strtol(h, NULL, 16); s += 2;
        } else if (*s == '+') *p++ = ' ';
        else *p++ = *s;
    }
    *p = 0;
    return out;
}

static char *html_escape(const char *s) {
    size_t n = 0;
    for (const char *p=s; *p; p++) n += (*p=='&'||*p=='<'||*p=='>'||*p=='"') ? 6 : 1;
    char *o = malloc(n+1), *q=o;
    for (; *s; s++) {
        if (*s=='&') { memcpy(q,"&amp;",5); q+=5; }
        else if (*s=='<') { memcpy(q,"&lt;",4); q+=4; }
        else if (*s=='>') { memcpy(q,"&gt;",4); q+=4; }
        else if (*s=='"') { memcpy(q,"&quot;",6); q+=6; }
        else *q++ = *s;
    }
    *q=0; return o;
}

static void append(char **buf, size_t *len, size_t *cap, const char *fmt, ...) {
    va_list ap;
    while (1) {
        if (*cap - *len < 1024) { *cap = *cap ? *cap * 2 : 8192; *buf = realloc(*buf, *cap); }
        va_start(ap, fmt);
        int n = vsnprintf(*buf + *len, *cap - *len, fmt, ap);
        va_end(ap);
        if (n < 0) return;
        if (*len + (size_t)n < *cap) { *len += (size_t)n; return; }
        *cap = (*len + (size_t)n + 1024) * 2; *buf = realloc(*buf, *cap);
    }
}

static const char *status_text(int code) {
    switch(code) {
        case 200: return "OK"; case 201: return "Created"; case 204: return "No Content";
        case 206: return "Partial Content"; case 301: return "Moved Permanently";
        case 302: return "Found"; case 400: return "Bad Request"; case 401: return "Unauthorized";
        case 403: return "Forbidden"; case 404: return "Not Found"; case 405: return "Method Not Allowed";
        case 409: return "Conflict"; case 416: return "Range Not Satisfiable";
        case 500: return "Internal Server Error"; default: return "OK";
    }
}

static void http_date(time_t t, char *buf, size_t n) {
    struct tm tm; gmtime_r(&t, &tm);
    strftime(buf, n, "%a, %d %b %Y %H:%M:%S GMT", &tm);
}

static void send_all(int fd, const void *buf, size_t len) {
    const char *p = buf;
    while (len) {
        ssize_t n = send(fd, p, len, MSG_NOSIGNAL);
        if (n <= 0) return;
        p += n; len -= (size_t)n;
    }
}

static void send_response(int fd, int code, const char *ctype, const void *body, size_t len, const char *extra, int head) {
    char hdr[8192], date[128];
    http_date(time(NULL), date, sizeof date);
    int n = snprintf(hdr, sizeof hdr, "HTTP/1.1 %d %s\r\ncontent-length: %zu\r\n", code, status_text(code), len);
    if (ctype) n += snprintf(hdr+n, sizeof hdr-n, "content-type: %s\r\n", ctype);
    for (int i=0; i<cfg.header_count; i++) n += snprintf(hdr+n, sizeof hdr-n, "%s\r\n", cfg.headers[i]);
    if (extra) n += snprintf(hdr+n, sizeof hdr-n, "%s", extra);
    n += snprintf(hdr+n, sizeof hdr-n, "date: %s\r\n\r\n", date);
    send_all(fd, hdr, (size_t)n);
    if (!head && body && len) send_all(fd, body, len);
}

static void send_error_page(int fd, int code, const char *msg, int head) {
    char *e = html_escape(msg ? msg : status_text(code));
    char body[4096];
    int n = snprintf(body, sizeof body, "<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>%d %s</title></head><body><h1>%d %s</h1><p>%s</p><div class=\"footer\"><a href=\"https://github.com/svenstaro/miniserve\">miniserve</a>/0.32.0</div></body></html>", code, status_text(code), code, status_text(code), e);
    free(e);
    send_response(fd, code, "text/html", body, (size_t)n, NULL, head);
}

static const char *mime_type(const char *path) {
    const char *e = strrchr(path, '.');
    if (!e) return "application/octet-stream";
    if (!strcasecmp(e,".html")||!strcasecmp(e,".htm")) return "text/html; charset=utf-8";
    if (!strcasecmp(e,".txt")||!strcasecmp(e,".md")||!strcasecmp(e,".c")||!strcasecmp(e,".h")||!strcasecmp(e,".log")) return "text/plain; charset=utf-8";
    if (!strcasecmp(e,".css")) return "text/css; charset=utf-8";
    if (!strcasecmp(e,".js")) return "application/javascript";
    if (!strcasecmp(e,".json")) return "application/json";
    if (!strcasecmp(e,".svg")) return "image/svg+xml";
    if (!strcasecmp(e,".png")) return "image/png";
    if (!strcasecmp(e,".jpg")||!strcasecmp(e,".jpeg")) return "image/jpeg";
    if (!strcasecmp(e,".gif")) return "image/gif";
    if (!strcasecmp(e,".pdf")) return "application/pdf";
    if (!strcasecmp(e,".wasm")) return "application/wasm";
    return "application/octet-stream";
}

static int is_inline_type(const char *ctype) {
    return starts_with(ctype, "text/") || starts_with(ctype, "image/") || strstr(ctype, "javascript") || strstr(ctype, "json");
}

static int safe_join(const char *url_path, char out[PATH_MAX]) {
    char *dec = url_decode(url_path);
    char *p = dec;
    while (*p == '/') p++;
    if (strstr(p, "..")) { free(dec); return 0; }
    snprintf(out, PATH_MAX, "%s/%s", cfg.root, p);
    free(dec);
    return 1;
}

static char *header_value(Request *r, const char *name) {
    size_t nl = strlen(name);
    char *p = r->headers;
    while (p && *p) {
        char *e = strstr(p, "\r\n");
        size_t ll = e ? (size_t)(e-p) : strlen(p);
        if (ll > nl && p[nl] == ':' && !strncasecmp(p, name, nl)) {
            char *v = p + nl + 1;
            while (*v == ' ' || *v == '\t') v++;
            char *out = strndup(v, ll - (size_t)(v-p));
            return out;
        }
        if (!e) break;
        p = e + 2;
    }
    return NULL;
}

static const char b64tab[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static char *b64(const unsigned char *in, size_t len) {
    char *out = malloc(((len+2)/3)*4 + 1), *p=out;
    for (size_t i=0; i<len; i+=3) {
        unsigned v = in[i]<<16 | (i+1<len?in[i+1]<<8:0) | (i+2<len?in[i+2]:0);
        *p++=b64tab[(v>>18)&63]; *p++=b64tab[(v>>12)&63];
        *p++=(i+1<len)?b64tab[(v>>6)&63]:'='; *p++=(i+2<len)?b64tab[v&63]:'=';
    }
    *p=0; return out;
}

static int check_auth(Request *r) {
    if (!cfg.auth) return 1;
    char *want = b64((unsigned char*)cfg.auth, strlen(cfg.auth));
    char expected[1024]; snprintf(expected, sizeof expected, "Basic %s", want); free(want);
    char *got = header_value(r, "Authorization");
    int ok = got && !strcmp(got, expected);
    free(got);
    return ok;
}

static int cmp_entries(const void *a, const void *b) {
    const struct dirent * const *da = a, * const *db = b;
    if (cfg.dirs_first) {
        int ad = (*da)->d_type == DT_DIR, bd = (*db)->d_type == DT_DIR;
        if (ad != bd) return bd - ad;
    }
    return strcasecmp((*da)->d_name, (*db)->d_name);
}

static char *human_size(off_t sz) {
    char *r = malloc(64);
    const char *u[] = {"B","KiB","MiB","GiB","TiB"};
    double v = (double)sz; int i=0;
    while (v >= 1024 && i < 4) { v /= 1024; i++; }
    if (i == 0) snprintf(r, 64, "%lld B", (long long)sz);
    else snprintf(r, 64, "%.1f %s", v, u[i]);
    return r;
}

static void send_file(int fd, const char *fs, const char *url, Request *r, struct stat *st, int head) {
    int f = open(fs, O_RDONLY);
    if (f < 0) { send_error_page(fd, 403, "Cannot open file", head); return; }
    off_t start = 0, end = st->st_size ? st->st_size - 1 : 0;
    int partial = 0;
    char *range = header_value(r, "Range");
    if (range && starts_with(range, "bytes=")) {
        char *dash = strchr(range+6, '-');
        if (dash) {
            *dash = 0;
            if (*(range+6)) start = atoll(range+6);
            if (*(dash+1)) end = atoll(dash+1);
            if (start < 0 || start >= st->st_size || end < start) {
                close(f); free(range);
                send_response(fd, 416, "text/plain", "", 0, "accept-ranges: bytes\r\n", head);
                return;
            }
            if (end >= st->st_size) end = st->st_size - 1;
            partial = 1;
        }
    }
    free(range);
    const char *ct = mime_type(fs);
    const char *base = strrchr(fs, '/'); base = base ? base + 1 : fs;
    char extra[2048], lm[128];
    http_date(st->st_mtime, lm, sizeof lm);
    snprintf(extra, sizeof extra, "last-modified: %s\r\ncontent-disposition: %s; filename=\"%s\"\r\naccept-ranges: bytes\r\n%s",
             lm, is_inline_type(ct) ? "inline" : "attachment", base,
             partial ? "" : "");
    char hdr[8192], date[128];
    http_date(time(NULL), date, sizeof date);
    size_t len = (size_t)(st->st_size ? end - start + 1 : 0);
    int n = snprintf(hdr, sizeof hdr, "HTTP/1.1 %d %s\r\ncontent-length: %zu\r\ncontent-type: %s\r\n%s",
                     partial ? 206 : 200, status_text(partial ? 206 : 200), len, ct, extra);
    if (partial) n += snprintf(hdr+n, sizeof hdr-n, "content-range: bytes %lld-%lld/%lld\r\n", (long long)start, (long long)end, (long long)st->st_size);
    for (int i=0; i<cfg.header_count; i++) n += snprintf(hdr+n, sizeof hdr-n, "%s\r\n", cfg.headers[i]);
    n += snprintf(hdr+n, sizeof hdr-n, "date: %s\r\n\r\n", date);
    send_all(fd, hdr, (size_t)n);
    if (!head && len) {
        lseek(f, start, SEEK_SET);
        char buf[16384]; size_t left = len;
        while (left) {
            ssize_t rd = read(f, buf, left > sizeof buf ? sizeof buf : left);
            if (rd <= 0) break;
            send_all(fd, buf, (size_t)rd); left -= (size_t)rd;
        }
    }
    close(f);
    (void)url;
}

static void send_listing(int fd, const char *fs, const char *url, int head) {
    if (cfg.disable_indexing) { send_error_page(fd, 404, "Directory listing disabled", head); return; }
    DIR *d = opendir(fs);
    if (!d) { send_error_page(fd, 403, "Cannot read directory", head); return; }
    struct dirent **items = NULL; size_t count=0, cap=0;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
        if (!cfg.hidden && de->d_name[0] == '.') continue;
        if (cfg.no_symlinks) {
            char p[PATH_MAX]; snprintf(p, sizeof p, "%s/%s", fs, de->d_name);
            struct stat lst; if (!lstat(p, &lst) && S_ISLNK(lst.st_mode)) continue;
        }
        if (count == cap) { cap = cap?cap*2:32; items = realloc(items, cap * sizeof *items); }
        items[count++] = memcpy(malloc(sizeof(struct dirent)), de, sizeof(struct dirent));
    }
    closedir(d);
    qsort(items, count, sizeof *items, cmp_entries);
    char *body=NULL; size_t len=0, bcap=0;
    char *title = html_escape(cfg.title ? cfg.title : "miniserve");
    char *u = html_escape(url);
    append(&body,&len,&bcap,"<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>%s</title><style>body{font-family:sans-serif;margin:2em}table{border-collapse:collapse;width:100%%}td,th{padding:.35em;border-bottom:1px solid #ddd;text-align:left}.size{text-align:right}.footer{margin-top:2em;color:#666}</style></head><body><h1 class=\"title\">%s%s</h1>", title, title, u);
    if (cfg.upload) append(&body,&len,&bcap,"<form action=\"/upload?path=%s\" method=\"post\" enctype=\"multipart/form-data\"><input type=\"file\" name=\"path\"><button>Upload</button></form>", u);
    if (cfg.mkdir_enabled) append(&body,&len,&bcap,"<form action=\"/mkdir?path=%s\" method=\"post\"><input name=\"name\"><button>Create directory</button></form>", u);
    append(&body,&len,&bcap,"<table><thead><tr><th class=\"name\"><a href=\"?sort=name&amp;order=asc\">Name</a></th><th class=\"size\">Size</th><th class=\"date\">Last modification</th></tr></thead><tbody>");
    if (strcmp(url, "/")) append(&body,&len,&bcap,"<tr class=\"entry-type-directory\"><td><a class=\"directory\" href=\"../\">../</a></td><td></td><td></td></tr>");
    for (size_t i=0; i<count; i++) {
        char p[PATH_MAX]; snprintf(p, sizeof p, "%s/%s", fs, items[i]->d_name);
        struct stat st; if (stat(p, &st)) continue;
        int isdir = S_ISDIR(st.st_mode);
        char *name = html_escape(items[i]->d_name);
        char href[4096]; snprintf(href, sizeof href, "%s%s%s", cfg.file_external_url ? cfg.file_external_url : "", url, items[i]->d_name);
        if (isdir) strncat(href, "/", sizeof href - strlen(href) - 1);
        char *ehref = html_escape(href);
        char *sz = isdir ? xstrdup("") : human_size(st.st_size);
        char dt[64]; struct tm tm; localtime_r(&st.st_mtime, &tm); strftime(dt, sizeof dt, "%Y-%m-%d %H:%M:%S %z", &tm);
        append(&body,&len,&bcap,"<tr class=\"entry-type-%s\"><td><a class=\"%s\" href=\"%s\">%s%s</a></td><td class=\"size-cell\">%s</td><td class=\"date-cell\">%s</td></tr>", isdir?"directory":"file", isdir?"directory":"file", ehref, name, isdir?"/":"", sz, dt);
        free(name); free(ehref); free(sz); free(items[i]);
    }
    free(items);
    append(&body,&len,&bcap,"</tbody></table>");
    if (cfg.readme) {
        char rp[PATH_MAX]; snprintf(rp, sizeof rp, "%s/README.md", fs);
        FILE *rf = fopen(rp, "rb");
        if (rf) { append(&body,&len,&bcap,"<h2>README.md</h2><pre>"); int c; while ((c=fgetc(rf))!=EOF) { char s[2]={(char)c,0}; char *e=html_escape(s); append(&body,&len,&bcap,"%s",e); free(e);} fclose(rf); append(&body,&len,&bcap,"</pre>"); }
    }
    if (cfg.show_wget) append(&body,&len,&bcap,"<div class=\"wget\">wget -r -np %s</div>", u);
    if (!cfg.hide_footer) append(&body,&len,&bcap,"<div class=\"footer\"><a href=\"https://github.com/svenstaro/miniserve\">miniserve</a>/0.32.0</div>");
    append(&body,&len,&bcap,"</body></html>");
    free(title); free(u);
    send_response(fd, 200, "text/html; charset=utf-8", body, len, NULL, head);
    free(body);
}

static void redirect_slash(int fd, const char *path) {
    char loc[4096]; snprintf(loc, sizeof loc, "location: %s/\r\n", path);
    send_response(fd, 301, "text/plain", "", 0, loc, 0);
}

static void handle_mkdir(int fd, Request *r, int head) {
    if (!cfg.mkdir_enabled) { send_error_page(fd, 403, "Directory creation is disabled", head); return; }
    char *name = strstr((char*)r->body, "name=");
    if (!name) name = "name=new-directory"; else name += 5;
    char *dec = url_decode(name);
    char *amp = strchr(dec, '&'); if (amp) *amp = 0;
    if (strstr(dec, "..") || strchr(dec, '/')) { free(dec); send_error_page(fd, 400, "Invalid directory name", head); return; }
    char base[PATH_MAX]; safe_join("/", base);
    char path[PATH_MAX]; snprintf(path, sizeof path, "%s/%s", base, dec);
    int ok = mkdir(path, 0777);
    free(dec);
    send_response(fd, ok ? 409 : 201, "text/plain", ok ? "Conflict\n" : "Created\n", ok ? 9 : 8, NULL, head);
}

static unsigned char *memmem2(unsigned char *h, size_t hl, const char *n, size_t nl) {
    if (!nl || hl < nl) return NULL;
    for (size_t i=0; i+nl<=hl; i++) if (!memcmp(h+i,n,nl)) return h+i;
    return NULL;
}

static void handle_upload(int fd, Request *r, int head) {
    if (!cfg.upload) { send_error_page(fd, 403, "File uploading is disabled", head); return; }
    char *ct = header_value(r, "Content-Type");
    char filename[PATH_MAX] = "upload.bin";
    unsigned char *data = r->body; size_t dlen = r->body_len;
    if (ct && strstr(ct, "multipart/form-data")) {
        char *b = strstr(ct, "boundary=");
        if (b) {
            char boundary[256]; snprintf(boundary, sizeof boundary, "--%s", b+9);
            unsigned char *part = memmem2(r->body, r->body_len, boundary, strlen(boundary));
            if (part) {
                unsigned char *hdrend = memmem2(part, r->body_len-(size_t)(part-r->body), "\r\n\r\n", 4);
                if (hdrend) {
                    char *ph = strndup((char*)part, (size_t)(hdrend-part));
                    char *fn = strstr(ph, "filename=\"");
                    if (fn) { fn += 10; char *q = strchr(fn, '"'); if (q) { *q=0; snprintf(filename, sizeof filename, "%s", fn); } }
                    free(ph);
                    data = hdrend + 4;
                    unsigned char *end = memmem2(data, r->body_len-(size_t)(data-r->body), boundary, strlen(boundary));
                    if (end) { dlen = (size_t)(end - data); if (dlen >= 2 && data[dlen-2]=='\r' && data[dlen-1]=='\n') dlen -= 2; }
                }
            }
        }
    }
    free(ct);
    char *baseq = strstr(r->query, "path=");
    char destdir[PATH_MAX];
    if (baseq) { char *dec = url_decode(baseq+5); char *amp=strchr(dec,'&'); if(amp)*amp=0; safe_join(dec, destdir); free(dec); }
    else safe_join("/", destdir);
    if (strstr(filename, "..") || strchr(filename, '/')) { send_error_page(fd, 400, "Invalid filename", head); return; }
    char dest[PATH_MAX]; snprintf(dest, sizeof dest, "%s/%s", destdir, filename);
    int f = open(dest, O_WRONLY|O_CREAT|O_EXCL, 0666);
    if (f < 0) { send_error_page(fd, errno == EEXIST ? 409 : 500, strerror(errno), head); return; }
    write(f, data, dlen); close(f);
    send_response(fd, 201, "text/plain", "Created\n", 8, NULL, head);
}

static void handle_delete(int fd, Request *r, int head) {
    if (!cfg.rm_enabled) { send_error_page(fd, 403, "Deletion is disabled", head); return; }
    char fs[PATH_MAX]; if (!safe_join(r->path, fs)) { send_error_page(fd,403,"Forbidden",head); return; }
    struct stat st; if (lstat(fs, &st)) { send_error_page(fd,404,"Not found",head); return; }
    int ok = S_ISDIR(st.st_mode) ? rmdir(fs) : unlink(fs);
    send_response(fd, ok ? 500 : 204, "text/plain", ok ? strerror(errno) : "", ok ? strlen(strerror(errno)) : 0, NULL, head);
}

static void handle_propfind(int fd, Request *r, int head) {
    if (!cfg.enable_webdav) { send_error_page(fd, 405, "Method Not Allowed", head); return; }
    char fs[PATH_MAX]; safe_join(r->path, fs);
    struct stat st; if (stat(fs,&st)) { send_error_page(fd,404,"Not Found",head); return; }
    char body[4096];
    int n = snprintf(body,sizeof body,"<?xml version=\"1.0\"?><D:multistatus xmlns:D=\"DAV:\"><D:response><D:href>%s</D:href><D:propstat><D:prop><D:getcontentlength>%lld</D:getcontentlength></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response></D:multistatus>", r->path, (long long)st.st_size);
    send_response(fd,207,"application/xml",body,(size_t)n,NULL,head);
}

static void serve_path(int fd, Request *r, int head) {
    if (!check_auth(r)) { send_response(fd, 401, NULL, NULL, 0, "www-authenticate: Basic\r\n", head); return; }
    if (!strcmp(r->path, "/__miniserve_internal/favicon.svg")) {
        const char *svg="<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><rect width=\"64\" height=\"64\" rx=\"12\" fill=\"#477\"/><text x=\"32\" y=\"42\" font-size=\"32\" text-anchor=\"middle\" fill=\"white\">m</text></svg>";
        send_response(fd,200,"image/svg+xml",svg,strlen(svg),NULL,head); return;
    }
    if (!strcmp(r->path, "/__miniserve_internal/style.css")) {
        const char *css="body{font-family:sans-serif}a{color:#06c}.entry-type-directory{font-weight:bold}";
        send_response(fd,200,"text/css; charset=utf-8",css,strlen(css),NULL,head); return;
    }
    if (!strcmp(r->path, "/upload")) { handle_upload(fd,r,head); return; }
    if (!strcmp(r->path, "/mkdir")) { handle_mkdir(fd,r,head); return; }
    if (!strcmp(r->method, "DELETE")) { handle_delete(fd,r,head); return; }
    if (!strcmp(r->method, "PROPFIND")) { handle_propfind(fd,r,head); return; }
    if (cfg.root_is_file) {
        struct stat fst;
        if (stat(cfg.root, &fst)) { send_error_page(fd, 404, "Not Found", head); return; }
        char want[NAME_MAX + 3];
        snprintf(want, sizeof want, "/%s", cfg.root_file_name);
        if (!strcmp(r->path, "/") || !strcmp(r->path, want)) send_file(fd, cfg.root, r->path, r, &fst, head);
        else send_error_page(fd, 404, "Route could not be found", head);
        return;
    }
    char fs[PATH_MAX];
    if (!safe_join(r->path, fs)) { send_error_page(fd, 403, "Forbidden", head); return; }
    struct stat st;
    if (!stat(fs, &st) && cfg.no_symlinks) {
        struct stat lst; if (!lstat(fs,&lst) && S_ISLNK(lst.st_mode)) { send_error_page(fd,404,"Not Found",head); return; }
    }
    if (stat(fs, &st)) {
        if (cfg.pretty_urls) {
            char hp[PATH_MAX]; snprintf(hp, sizeof hp, "%s.html", fs);
            if (!stat(hp, &st) && S_ISREG(st.st_mode)) { send_file(fd,hp,r->path,r,&st,head); return; }
        }
        if (cfg.spa && cfg.index_name) {
            char ip[PATH_MAX]; snprintf(ip, sizeof ip, "%s/%s", cfg.root, cfg.index_name);
            if (!stat(ip,&st) && S_ISREG(st.st_mode)) { send_file(fd,ip,r->path,r,&st,head); return; }
        }
        send_error_page(fd, 404, "Route could not be found", head); return;
    }
    if (S_ISDIR(st.st_mode)) {
        size_t pl = strlen(r->path);
        if (pl && r->path[pl-1] != '/') { redirect_slash(fd, r->path); return; }
        if (cfg.index_name) {
            char ip[PATH_MAX]; snprintf(ip, sizeof ip, "%s/%s", fs, cfg.index_name);
            struct stat ist; if (!stat(ip, &ist) && S_ISREG(ist.st_mode)) { send_file(fd, ip, r->path, r, &ist, head); return; }
        }
        send_listing(fd, fs, r->path, head);
    } else if (S_ISREG(st.st_mode)) send_file(fd, fs, r->path, r, &st, head);
    else send_error_page(fd, 404, "Not Found", head);
}

static int read_request(int fd, Request *r) {
    memset(r, 0, sizeof *r);
    size_t cap = 16384, len = 0;
    unsigned char *buf = malloc(cap);
    while (1) {
        if (len == cap) { cap *= 2; buf = realloc(buf, cap); }
        ssize_t n = recv(fd, buf+len, cap-len, 0);
        if (n <= 0) { free(buf); return 0; }
        len += (size_t)n;
        if (memmem2(buf, len, "\r\n\r\n", 4)) break;
        if (len > 1024*1024) { free(buf); return 0; }
    }
    unsigned char *hend = memmem2(buf, len, "\r\n\r\n", 4);
    size_t hlen = (size_t)(hend - buf);
    char *head = strndup((char*)buf, hlen);
    char *line_end = strstr(head, "\r\n");
    if (!line_end) { free(head); free(buf); return 0; }
    *line_end = 0;
    sscanf(head, "%15s %2047s %15s", r->method, r->target, r->version);
    char *q = strchr(r->target, '?');
    if (q) { *q=0; snprintf(r->query,sizeof r->query,"%s",q+1); }
    snprintf(r->path,sizeof r->path,"%s",r->target[0]?r->target:"/");
    r->headers = xstrdup(line_end+2);
    free(head);
    char *clv = header_value(r, "Content-Length");
    size_t cl = clv ? (size_t)atoll(clv) : 0; free(clv);
    r->body_len = cl;
    r->body = malloc(cl ? cl : 1);
    size_t have = len - (size_t)((hend+4) - buf);
    if (have > cl) have = cl;
    memcpy(r->body, hend+4, have);
    free(buf);
    while (have < cl) {
        ssize_t n = recv(fd, r->body+have, cl-have, 0);
        if (n <= 0) break;
        have += (size_t)n;
    }
    return 1;
}

static void free_request(Request *r) { free(r->headers); free(r->body); }

static void handle_client(int fd) {
    Request r;
    if (!read_request(fd, &r)) { close(fd); return; }
    if (cfg.route_prefix && strcmp(cfg.route_prefix, "/")) {
        size_t lp = strlen(cfg.route_prefix);
        if (!starts_with(r.path, cfg.route_prefix)) {
            char loc[1024]; snprintf(loc,sizeof loc,"location: %s/\r\n",cfg.route_prefix);
            send_response(fd,302,"text/plain","",0,loc,0);
            free_request(&r); close(fd); return;
        }
        memmove(r.path, r.path+lp, strlen(r.path+lp)+1);
        if (!r.path[0]) strcpy(r.path, "/");
    }
    int head = !strcmp(r.method, "HEAD");
    if (strcmp(r.method,"GET") && strcmp(r.method,"HEAD") && strcmp(r.method,"POST") && strcmp(r.method,"DELETE") && strcmp(r.method,"PROPFIND")) {
        send_error_page(fd,405,"Method Not Allowed",head);
    } else serve_path(fd, &r, head);
    if (cfg.verbose) fprintf(stderr, "%s %s\n", r.method, r.target);
    free_request(&r);
    close(fd);
}

static int option_has_value(const char *opt) {
    const char *opts[] = {"--temp-directory","--index","--port","-p","--interfaces","-i","--auth","-a","--auth-file","--route-prefix","--default-sorting-method","-S","--default-sorting-order","-O","--color-scheme","-c","--color-scheme-dark","-d","--web-upload-files-concurrency","--chmod","--media-type","-m","--raw-media-type","-M","--on-duplicate-files","-o","--title","-t","--header","--print-completions","--tls-cert","--tls-key","--size-display","--file-external-url",NULL};
    for (int i=0; opts[i]; i++) if (!strcmp(opt, opts[i])) return 1;
    return 0;
}

static void load_auth_file(const char *path) {
    FILE *f=fopen(path,"r"); if(!f) die("error: cannot read auth file");
    char line[512]; if(fgets(line,sizeof line,f)) { line[strcspn(line,"\r\n")]=0; if(*line) cfg.auth=xstrdup(line); }
    fclose(f);
}

static void parse_args(int argc, char **argv) {
    char cwd[PATH_MAX]; getcwd(cwd,sizeof cwd);
    snprintf(cfg.root,sizeof cfg.root,"%s", getenv("MINISERVE_PATH") ? getenv("MINISERVE_PATH") : cwd);
    cfg.port = getenv("MINISERVE_PORT") ? atoi(getenv("MINISERVE_PORT")) : 8080;
    cfg.verbose = is_truthy(getenv("MINISERVE_VERBOSE"));
    cfg.hidden = is_truthy(getenv("MINISERVE_HIDDEN"));
    cfg.no_symlinks = is_truthy(getenv("MINISERVE_NO_SYMLINKS"));
    cfg.pretty_urls = is_truthy(getenv("MINISERVE_PRETTY_URLS"));
    cfg.spa = is_truthy(getenv("MINISERVE_SPA"));
    cfg.upload = is_truthy(getenv("MINISERVE_ALLOWED_UPLOAD_DIR"));
    cfg.mkdir_enabled = is_truthy(getenv("MINISERVE_MKDIR_ENABLED"));
    cfg.rm_enabled = is_truthy(getenv("MINISERVE_ALLOWED_RM_DIR"));
    cfg.disable_indexing = is_truthy(getenv("MINISERVE_DISABLE_INDEXING"));
    cfg.enable_webdav = is_truthy(getenv("MINISERVE_ENABLE_WEBDAV"));
    if (getenv("MINISERVE_INDEX")) cfg.index_name=xstrdup(getenv("MINISERVE_INDEX"));
    if (getenv("MINISERVE_AUTH")) cfg.auth=xstrdup(getenv("MINISERVE_AUTH"));
    if (getenv("MINISERVE_TITLE")) cfg.title=xstrdup(getenv("MINISERVE_TITLE"));
    if (getenv("MINISERVE_ROUTE_PREFIX")) cfg.route_prefix=xstrdup(getenv("MINISERVE_ROUTE_PREFIX"));
    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (!strcmp(a,"-h")) { print_help(0); exit(0); }
        if (!strcmp(a,"--help")) { print_help(1); exit(0); }
        if (!strcmp(a,"-V")||!strcmp(a,"--version")) { puts("miniserve 0.32.0"); exit(0); }
        if (!strcmp(a,"--print-manpage")) { print_manpage(); exit(0); }
        if (!strcmp(a,"--print-completions")) { if (++i>=argc) die("error: a value is required for '--print-completions <shell>'"); print_completions(argv[i]); exit(0); }
        if (!strcmp(a,"--")) { if (++i<argc) snprintf(cfg.root,sizeof cfg.root,"%s",argv[i]); break; }
        if (a[0] == '-') {
            char *eq = strchr(a,'='), *val = NULL;
            if (eq) { *eq=0; val=eq+1; }
            if (!strcmp(a,"-v")||!strcmp(a,"--verbose")) cfg.verbose=1;
            else if (!strcmp(a,"-H")||!strcmp(a,"--hidden")) cfg.hidden=1;
            else if (!strcmp(a,"-P")||!strcmp(a,"--no-symlinks")) cfg.no_symlinks=1;
            else if (!strcmp(a,"--pretty-urls")) cfg.pretty_urls=1;
            else if (!strcmp(a,"--spa")) cfg.spa=1;
            else if (!strcmp(a,"-u")||!strcmp(a,"--upload-files")) { cfg.upload=1; if (!val && i+1<argc && argv[i+1][0] != '-') i++; }
            else if (!strcmp(a,"-U")||!strcmp(a,"--mkdir")) cfg.mkdir_enabled=1;
            else if (!strcmp(a,"-R")||!strcmp(a,"--rm-files")) { cfg.rm_enabled=1; if (!val && i+1<argc && argv[i+1][0] != '-') i++; }
            else if (!strcmp(a,"-I")||!strcmp(a,"--disable-indexing")) cfg.disable_indexing=1;
            else if (!strcmp(a,"-D")||!strcmp(a,"--dirs-first")) cfg.dirs_first=1;
            else if (!strcmp(a,"-F")||!strcmp(a,"--hide-version-footer")) cfg.hide_footer=1;
            else if (!strcmp(a,"-W")||!strcmp(a,"--show-wget-footer")) cfg.show_wget=1;
            else if (!strcmp(a,"--readme")) cfg.readme=1;
            else if (!strcmp(a,"--enable-webdav")) cfg.enable_webdav=1;
            else if (!strcmp(a,"--random-route")) cfg.route_prefix=xstrdup("/abcdef");
            else if (!strcmp(a,"-r")||!strcmp(a,"--enable-tar")||!strcmp(a,"-g")||!strcmp(a,"--enable-tar-gz")||!strcmp(a,"-z")||!strcmp(a,"--enable-zip")||!strcmp(a,"-C")||!strcmp(a,"--compress-response")||!strcmp(a,"-q")||!strcmp(a,"--qrcode")||!strcmp(a,"-l")||!strcmp(a,"--show-symlink-info")||!strcmp(a,"--hide-theme-selector")||!strcmp(a,"--directory-size")) { }
            else if (option_has_value(a)) {
                if (!val) { if (++i>=argc) die("error: a value is required for '%s'", a); val=argv[i]; }
                if (!strcmp(a,"-p")||!strcmp(a,"--port")) cfg.port=atoi(val);
                else if (!strcmp(a,"--index")) cfg.index_name=xstrdup(val);
                else if (!strcmp(a,"-a")||!strcmp(a,"--auth")) cfg.auth=xstrdup(val);
                else if (!strcmp(a,"--auth-file")) load_auth_file(val);
                else if (!strcmp(a,"--route-prefix")) cfg.route_prefix=xstrdup(val);
                else if (!strcmp(a,"-t")||!strcmp(a,"--title")) cfg.title=xstrdup(val);
                else if (!strcmp(a,"--header") && cfg.header_count < 64) cfg.headers[cfg.header_count++]=xstrdup(val);
                else if (!strcmp(a,"--file-external-url")) cfg.file_external_url=xstrdup(val);
                else if ((!strcmp(a,"-S")||!strcmp(a,"--default-sorting-method")) && strcmp(val,"name") && strcmp(val,"size") && strcmp(val,"date")) die("error: invalid value '%s' for '--default-sorting-method <DEFAULT_SORTING_METHOD>'\n  [possible values: name, size, date]", val);
                else if ((!strcmp(a,"-O")||!strcmp(a,"--default-sorting-order")) && strcmp(val,"asc") && strcmp(val,"desc")) die("error: invalid value '%s' for '--default-sorting-order <DEFAULT_SORTING_ORDER>'\n  [possible values: asc, desc]", val);
            } else {
                fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [PATH]\n\nFor more information, try '--help'.\n", a);
                exit(2);
            }
            if (eq) *eq='=';
        } else snprintf(cfg.root,sizeof cfg.root,"%s",a);
    }
    char real[PATH_MAX];
    if (!realpath(cfg.root, real)) die("Error: No such file or directory: %s", cfg.root);
    snprintf(cfg.root,sizeof cfg.root,"%s", real);
    struct stat root_st;
    if (!stat(cfg.root, &root_st) && S_ISREG(root_st.st_mode)) {
        cfg.root_is_file = 1;
        const char *b = strrchr(cfg.root, '/');
        snprintf(cfg.root_file_name, sizeof cfg.root_file_name, "%s", b ? b + 1 : cfg.root);
    }
    if (!cfg.title) cfg.title = xstrdup("127.0.0.1");
}

int main(int argc, char **argv) {
    parse_args(argc, argv);
    signal(SIGINT, on_sig); signal(SIGTERM, on_sig); signal(SIGPIPE, SIG_IGN);
    int s = socket(AF_INET6, SOCK_STREAM, 0);
    if (s < 0) die("socket: %s", strerror(errno));
    int one=1, zero=0; setsockopt(s,SOL_SOCKET,SO_REUSEADDR,&one,sizeof one); setsockopt(s,IPPROTO_IPV6,IPV6_V6ONLY,&zero,sizeof zero);
    struct sockaddr_in6 addr; memset(&addr,0,sizeof addr); addr.sin6_family=AF_INET6; addr.sin6_addr=in6addr_any; addr.sin6_port=htons((uint16_t)cfg.port);
    if (bind(s,(struct sockaddr*)&addr,sizeof addr)) die("Error: Failed to bind: %s", strerror(errno));
    if (listen(s,64)) die("listen: %s", strerror(errno));
    printf("miniserve v0.32.0\nBound to [::]:%d, 0.0.0.0:%d\nServing path %s\nAvailable at (non-exhaustive list):\n    http://127.0.0.1:%d\n    http://[::1]:%d\n\n", cfg.port,cfg.port,cfg.root,cfg.port,cfg.port);
    fflush(stdout);
    while (running) {
        struct sockaddr_storage ss; socklen_t sl=sizeof ss;
        int c = accept(s,(struct sockaddr*)&ss,&sl);
        if (c < 0) { if (errno==EINTR) continue; break; }
        handle_client(c);
    }
    close(s);
    return 0;
}
