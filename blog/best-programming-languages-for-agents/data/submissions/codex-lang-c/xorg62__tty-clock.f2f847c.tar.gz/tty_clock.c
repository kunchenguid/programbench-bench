#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <locale.h>
#include <ncurses.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t running = 1;

struct options {
    int seconds;
    int screensaver;
    int box;
    int center;
    int color;
    int bold;
    int twelve;
    int utc;
    int rebound;
    int noquit;
    int hide_date;
    int blink;
    int delay_sec;
    long delay_nsec;
    const char *format;
    const char *tty;
};

static const char *usage_text =
"usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] \n"
"    -s            Show seconds                                   \n"
"    -S            Screensaver mode                               \n"
"    -x            Show box                                       \n"
"    -c            Set the clock at the center of the terminal    \n"
"    -C [0-7]      Set the clock color                            \n"
"    -b            Use bold colors                                \n"
"    -t            Set the hour in 12h format                     \n"
"    -u            Use UTC time                                   \n"
"    -T tty        Display the clock on the specified terminal    \n"
"    -r            Do rebound the clock                           \n"
"    -f format     Set the date format                            \n"
"    -n            Don't quit on keypress                         \n"
"    -v            Show tty-clock version                         \n"
"    -i            Show some info about tty-clock                 \n"
"    -h            Show this page                                 \n"
"    -D            Hide date                                      \n"
"    -B            Enable blinking colon                          \n"
"    -d delay      Set the delay between two redraws of the clock. Default 1s. \n"
"    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.\n";

static const unsigned char segs[10] = {
    0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f
};

static void on_signal(int sig) {
    (void)sig;
    running = 0;
}

static void show_usage(void) {
    fputs(usage_text, stdout);
}

static void option_requires(char opt) {
    printf("./executable: option requires an argument -- '%c'\n", opt);
    show_usage();
}

static void invalid_option(char opt) {
    printf("./executable: invalid option -- '%c'\n", opt);
    show_usage();
}

static int parse_int(const char *s, int def) {
    if (!s || !*s) return def;
    char *end = NULL;
    long v = strtol(s, &end, 10);
    if (end == s) return def;
    return (int)v;
}

static long parse_long(const char *s, long def) {
    if (!s || !*s) return def;
    char *end = NULL;
    long v = strtol(s, &end, 10);
    if (end == s) return def;
    return v;
}

static int parse_args(int argc, char **argv, struct options *o) {
    for (int i = 1; i < argc; i++) {
        char *arg = argv[i];
        if (arg[0] != '-' || arg[1] == '\0') continue;
        if (strcmp(arg, "--") == 0) continue;
        for (int j = 1; arg[j]; j++) {
            char c = arg[j];
            switch (c) {
            case 's': o->seconds = 1; break;
            case 'S': o->screensaver = 1; break;
            case 'x': o->box = 1; break;
            case 'c': o->center = 1; break;
            case 'b': o->bold = 1; break;
            case 't': o->twelve = 1; break;
            case 'u': o->utc = 1; break;
            case 'r': o->rebound = 1; break;
            case 'n': o->noquit = 1; break;
            case 'D': o->hide_date = 1; break;
            case 'B': o->blink = 1; break;
            case 'h': show_usage(); return 1;
            case 'v': printf("TTY-Clock 2 © devel version\n"); return 1;
            case 'i': printf("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)\n"); return 1;
            case 'C':
            case 'f':
            case 'd':
            case 'a':
            case 'T': {
                const char *val = NULL;
                if (arg[j+1]) {
                    val = &arg[j+1];
                    j = (int)strlen(arg) - 1;
                } else if (i + 1 < argc) {
                    val = argv[++i];
                } else {
                    option_requires(c);
                    return 1;
                }
                if (c == 'C') o->color = parse_int(val, o->color);
                else if (c == 'f') o->format = val;
                else if (c == 'd') o->delay_sec = parse_int(val, o->delay_sec);
                else if (c == 'a') o->delay_nsec = parse_long(val, o->delay_nsec);
                else if (c == 'T') o->tty = val;
                break;
            }
            default:
                invalid_option(c);
                return 1;
            }
        }
    }
    return 0;
}

static void fill_rect(int y, int x, int h, int w) {
    for (int r = 0; r < h; r++) {
        move(y + r, x);
        for (int c = 0; c < w; c++) addch(' ');
    }
}

static void draw_digit(int y, int x, int d) {
    if (d < 0 || d > 9) return;
    unsigned char s = segs[d];
    if (s & 0x01) fill_rect(y,     x + 1, 1, 6);
    if (s & 0x02) fill_rect(y + 1, x + 7, 2, 2);
    if (s & 0x04) fill_rect(y + 4, x + 7, 2, 2);
    if (s & 0x08) fill_rect(y + 6, x + 1, 1, 6);
    if (s & 0x10) fill_rect(y + 4, x,     2, 2);
    if (s & 0x20) fill_rect(y + 1, x,     2, 2);
    if (s & 0x40) fill_rect(y + 3, x + 1, 1, 6);
}

static void draw_colon(int y, int x, int on) {
    if (!on) return;
    fill_rect(y + 2, x, 1, 2);
    fill_rect(y + 4, x, 1, 2);
}

static int color_pair_from_option(int color) {
    int c = ((color % 8) + 8) % 8;
    int curses_color = COLOR_GREEN;
    switch (c) {
    case 0: curses_color = COLOR_BLACK; break;
    case 1: curses_color = COLOR_RED; break;
    case 2: curses_color = COLOR_GREEN; break;
    case 3: curses_color = COLOR_YELLOW; break;
    case 4: curses_color = COLOR_BLUE; break;
    case 5: curses_color = COLOR_MAGENTA; break;
    case 6: curses_color = COLOR_CYAN; break;
    case 7: curses_color = COLOR_WHITE; break;
    }
    init_pair(1, curses_color, curses_color);
    init_pair(2, curses_color, -1);
    return 1;
}

static void draw_box(int y, int x, int h, int w) {
    mvaddch(y, x, ACS_ULCORNER);
    mvhline(y, x + 1, ACS_HLINE, w - 2);
    mvaddch(y, x + w - 1, ACS_URCORNER);
    mvvline(y + 1, x, ACS_VLINE, h - 2);
    mvvline(y + 1, x + w - 1, ACS_VLINE, h - 2);
    mvaddch(y + h - 1, x, ACS_LLCORNER);
    mvhline(y + h - 1, x + 1, ACS_HLINE, w - 2);
    mvaddch(y + h - 1, x + w - 1, ACS_LRCORNER);
}

static void draw_clock(const struct options *o, int posy, int posx, int frame) {
    time_t now = time(NULL);
    struct tm tmv;
    if (o->utc) gmtime_r(&now, &tmv); else localtime_r(&now, &tmv);

    int hour = tmv.tm_hour;
    if (o->twelve) {
        hour %= 12;
        if (hour == 0) hour = 12;
    }
    char timebuf[16];
    if (o->seconds) snprintf(timebuf, sizeof(timebuf), "%02d:%02d:%02d", hour, tmv.tm_min, tmv.tm_sec);
    else snprintf(timebuf, sizeof(timebuf), "%02d:%02d", hour, tmv.tm_min);

    int chars = (int)strlen(timebuf);
    int width = 0;
    for (int i = 0; i < chars; i++) width += (timebuf[i] == ':') ? 4 : 9;
    int height = o->hide_date ? 7 : 9;
    int y = posy, x = posx;
    if (o->box) { y++; x++; }

    if (o->box) draw_box(posy, posx, height + 2, width + 2);

    attr_t attr = COLOR_PAIR(1);
    if (o->bold) attr |= A_BOLD;
    if (o->blink) attr |= A_BLINK;
    attron(attr);
    int cx = x;
    for (int i = 0; timebuf[i]; i++) {
        if (isdigit((unsigned char)timebuf[i])) {
            draw_digit(y, cx, timebuf[i] - '0');
            cx += 9;
        } else {
            draw_colon(y, cx, !o->blink || (frame % 2 == 0));
            cx += 4;
        }
    }
    attroff(attr);

    if (!o->hide_date) {
        char datebuf[128];
        const char *fmt = o->format ? o->format : "%F";
        if (strftime(datebuf, sizeof(datebuf), fmt, &tmv) == 0) datebuf[0] = '\0';
        attron(COLOR_PAIR(2) | (o->bold ? A_BOLD : 0));
        mvaddstr(y + 8, x + (width - (int)strlen(datebuf)) / 2, datebuf);
        attroff(COLOR_PAIR(2) | (o->bold ? A_BOLD : 0));
    }
}

static void run_clock(const struct options *o) {
    FILE *ttyfp = NULL;
    if (o->tty) {
        struct stat st;
        if (stat(o->tty, &st) != 0) {
            fprintf(stderr, "tty-clock: error: couldn't stat '%s': %s.\n", o->tty, strerror(errno));
            exit(1);
        }
        if (!S_ISCHR(st.st_mode)) {
            fprintf(stderr, "tty-clock: error: '%s' is not a character device.\n", o->tty);
            exit(1);
        }
        ttyfp = fopen(o->tty, "r+");
        if (!ttyfp) {
            fprintf(stderr, "tty-clock: error: couldn't open '%s': %s.\n", o->tty, strerror(errno));
            exit(1);
        }
        newterm(NULL, ttyfp, ttyfp);
    } else {
        initscr();
    }

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    set_escdelay(25);
    cbreak();
    noecho();
    nodelay(stdscr, TRUE);
    keypad(stdscr, TRUE);
    curs_set(0);
    if (has_colors()) {
        start_color();
#ifdef NCURSES_VERSION
        use_default_colors();
#endif
        color_pair_from_option(o->color);
    }

    int px = 0, py = 0, dx = 1, dy = 1, frame = 0;
    struct timespec ts;
    ts.tv_sec = o->delay_sec;
    ts.tv_nsec = o->delay_nsec;
    if (ts.tv_sec < 0) ts.tv_sec = 0;
    if (ts.tv_nsec < 0) ts.tv_nsec = 0;
    if (ts.tv_nsec > 999999999L) ts.tv_nsec = 999999999L;

    while (running) {
        int ch;
        while ((ch = getch()) != ERR) {
            ch = toupper(ch);
            if ((o->screensaver || ch == 'Q') && !o->noquit) running = 0;
            else if (ch >= '0' && ch <= '7') color_pair_from_option(ch - '0');
        }
        int width = o->seconds ? 53 : 34;
        int height = o->hide_date ? 7 : 9;
        if (o->box) { width += 2; height += 2; }
        int y = py, x = px;
        if (o->center) {
            y = (LINES - height) / 2;
            x = (COLS - width) / 2;
        } else if (o->rebound) {
            px += dx;
            py += dy;
            if (px < 0) { px = 0; dx = 1; }
            if (py < 0) { py = 0; dy = 1; }
            if (px + width >= COLS) { px = COLS - width - 1; dx = -1; }
            if (py + height >= LINES) { py = LINES - height - 1; dy = -1; }
            if (px < 0) px = 0;
            if (py < 0) py = 0;
            x = px; y = py;
        }
        erase();
        draw_clock(o, y, x, frame++);
        refresh();
        nanosleep(&ts, NULL);
        if (ts.tv_sec == 0 && ts.tv_nsec == 0) {
            struct timespec tiny = {0, 10000000L};
            nanosleep(&tiny, NULL);
        }
    }
    endwin();
    if (ttyfp) fclose(ttyfp);
}

int main(int argc, char **argv) {
    setlocale(LC_ALL, "");
    struct options o;
    memset(&o, 0, sizeof(o));
    o.color = 2;
    o.delay_sec = 1;
    o.delay_nsec = 0;
    if (parse_args(argc, argv, &o)) return 0;
    run_clock(&o);
    return 0;
}
