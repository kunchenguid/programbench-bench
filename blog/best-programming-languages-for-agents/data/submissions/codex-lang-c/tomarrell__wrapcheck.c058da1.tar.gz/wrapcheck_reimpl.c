#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>
#ifndef PATH_MAX
#define PATH_MAX 4096
#endif
#include <fnmatch.h>

#define MAX_ITEMS 8192
#define MAX_LINE 8192

typedef struct { char *key; char *val; } Map;
typedef struct { char *path; char *import_path; char *pkg; int analyze; } Package;
typedef struct { char *pkg_path; char *name; char *sig; int returns_error; } Function;
typedef struct { char *file; int line; int col; char *msg; char *pkg; } Diagnostic;
typedef struct { char *name; char *sig; int internal; } Origin;

typedef struct {
    char **ignore_sigs; int n_ignore_sigs;
    char **extra_ignore_sigs; int n_extra_ignore_sigs;
    char **ignore_pkg_globs; int n_ignore_pkg_globs;
    int report_internal;
    int has_ignore_override;
} Config;

static Package packages[MAX_ITEMS]; static int n_packages;
static Function funcs[MAX_ITEMS]; static int n_funcs;
static Diagnostic diags[MAX_ITEMS]; static int n_diags;
static Config cfg;
static char module_path[1024]="";
static char workspace[PATH_MAX]="";

static char *xstrdup(const char *s){ if(!s) s=""; char *p=malloc(strlen(s)+1); if(!p){perror("malloc"); exit(2);} strcpy(p,s); return p; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }
static int starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }
static int ends(const char *s,const char *p){ size_t a=strlen(s),b=strlen(p); return a>=b && strcmp(s+a-b,p)==0; }
static int contains(const char *s,const char *p){ return p && *p && strstr(s,p)!=NULL; }
static void add_str(char ***arr,int *n,const char *s){ *arr=realloc(*arr,(*n+1)*sizeof(char*)); (*arr)[(*n)++]=xstrdup(s); }
static void path_join(char *out,size_t n,const char *a,const char *b){ snprintf(out,n,"%s/%s",a,b); }
static int is_dir(const char *p){ struct stat st; return stat(p,&st)==0 && S_ISDIR(st.st_mode); }
static int is_file(const char *p){ struct stat st; return stat(p,&st)==0 && S_ISREG(st.st_mode); }

static char *json_escape(const char *s){ size_t cap=strlen(s)*2+16; char *o=malloc(cap); size_t j=0; for(size_t i=0;s[i];i++){ unsigned char c=s[i]; if(j+8>=cap){cap*=2;o=realloc(o,cap);} if(c=='"'||c=='\\'){o[j++]='\\';o[j++]=c;} else if(c=='\n'){o[j++]='\\';o[j++]='n';} else if(c=='\t'){o[j++]='\\';o[j++]='t';} else o[j++]=c;} o[j]=0; return o; }

static void default_config(){
    const char *defs[]={".Errorf(","errors.New(","errors.Unwrap(","errors.Join(",".Wrap(",".Wrapf(",".WithMessage(",".WithMessagef(",".WithStack("};
    for(size_t i=0;i<sizeof(defs)/sizeof(defs[0]);i++) add_str(&cfg.ignore_sigs,&cfg.n_ignore_sigs,defs[i]);
}

static void parse_config_file(const char *path){
    FILE *f=fopen(path,"r"); if(!f) return;
    char line[MAX_LINE], section[128]="";
    while(fgets(line,sizeof(line),f)){
        char *hash=strchr(line,'#'); if(hash) *hash=0;
        char *t=trim(line); if(!*t) continue;
        if(strchr(t,':') && t[strlen(t)-1]==':'){ strncpy(section,t,sizeof(section)-1); section[strlen(section)-1]=0; continue; }
        char *colon=strchr(t,':');
        if(colon && t[0]!='-'){
            *colon=0; char *k=trim(t), *v=trim(colon+1);
            strncpy(section,k,sizeof(section)-1); section[sizeof(section)-1]=0;
            if(strcmp(k,"reportInternalErrors")==0) cfg.report_internal = starts(v,"true") || starts(v,"True");
            continue;
        }
        if(t[0]=='-'){
            char *v=trim(t+1); if((*v=='"'||*v=='\'') && v[strlen(v)-1]==*v){ v[strlen(v)-1]=0; v++; }
            if(strcmp(section,"ignoreSigs")==0){ if(!cfg.has_ignore_override){ cfg.n_ignore_sigs=0; cfg.has_ignore_override=1; } add_str(&cfg.ignore_sigs,&cfg.n_ignore_sigs,v); }
            else if(strcmp(section,"extraIgnoreSigs")==0) add_str(&cfg.extra_ignore_sigs,&cfg.n_extra_ignore_sigs,v);
            else if(strcmp(section,"ignorePackageGlobs")==0) add_str(&cfg.ignore_pkg_globs,&cfg.n_ignore_pkg_globs,v);
        }
    }
    fclose(f);
}

static void load_config(){
    default_config();
    char path[PATH_MAX];
    if(getcwd(path,sizeof(path))){ char p2[PATH_MAX]; snprintf(p2,sizeof(p2),"%s/.wrapcheck.yaml",path); parse_config_file(p2); }
    char *home=getenv("HOME"); if(home){ char p2[PATH_MAX]; snprintf(p2,sizeof(p2),"%s/.wrapcheck.yaml",home); parse_config_file(p2); }
}

static void find_workspace(){
    char cwd[PATH_MAX]; getcwd(cwd,sizeof(cwd)); strcpy(workspace,cwd);
    char cur[PATH_MAX]; strcpy(cur,cwd);
    while(1){ char gm[PATH_MAX]; snprintf(gm,sizeof(gm),"%s/go.mod",cur); if(is_file(gm)){ strcpy(workspace,cur); FILE*f=fopen(gm,"r"); if(f){ char line[MAX_LINE]; while(fgets(line,sizeof(line),f)){ char *t=trim(line); if(starts(t,"module ")){ strncpy(module_path,trim(t+7),sizeof(module_path)-1); break; }} fclose(f);} return; } char *slash=strrchr(cur,'/'); if(!slash||slash==cur) break; *slash=0; }
}

static int has_go_files(const char *dir,int include_tests){ DIR*d=opendir(dir); if(!d) return 0; struct dirent*e; int ok=0; while((e=readdir(d))){ if(ends(e->d_name,".go") && (include_tests || !ends(e->d_name,"_test.go"))){ ok=1; break; }} closedir(d); return ok; }
static void add_package_dir2(const char *dir,int analyze){ if(n_packages>=MAX_ITEMS) return; char real[PATH_MAX]; if(!realpath(dir,real)) snprintf(real,sizeof(real),"%s",dir); for(int i=0;i<n_packages;i++) if(strcmp(packages[i].path,real)==0){ packages[i].analyze |= analyze; return; } packages[n_packages].path=xstrdup(real); packages[n_packages].pkg=xstrdup(""); packages[n_packages].analyze=analyze; char rel[PATH_MAX]=""; if(module_path[0] && starts(real,workspace)){ const char *r=real+strlen(workspace); if(*r=='/') r++; if(*r) snprintf(rel,sizeof(rel),"%s/%s",module_path,r); else snprintf(rel,sizeof(rel),"%s",module_path); packages[n_packages].import_path=xstrdup(rel); } else packages[n_packages].import_path=xstrdup(real); n_packages++; }
static void add_package_dir(const char *dir){ add_package_dir2(dir,1); }
static void walk_packages2(const char *dir,int include_tests,int analyze){ if(!is_dir(dir)) return; if(has_go_files(dir,include_tests)) add_package_dir2(dir,analyze); DIR*d=opendir(dir); if(!d) return; struct dirent*e; while((e=readdir(d))){ if(e->d_name[0]=='.' || strcmp(e->d_name,"vendor")==0) continue; char p[PATH_MAX]; path_join(p,sizeof(p),dir,e->d_name); if(is_dir(p)) walk_packages2(p,include_tests,analyze); } closedir(d); }
static void walk_packages(const char *dir,int include_tests){ walk_packages2(dir,include_tests,1); }

static char *normalize_arg_path(const char *arg){ static char out[PATH_MAX]; if(strcmp(arg,".")==0){ getcwd(out,sizeof(out)); return out; } if(ends(arg,"/...")){ char tmp[PATH_MAX]; snprintf(tmp,sizeof(tmp),"%.*s",(int)(strlen(arg)-4),arg); realpath(tmp,out); return out; } realpath(arg,out); return out; }

static char *strip_comments(char *line){ static int block=0; char *out=malloc(strlen(line)+1); int j=0; for(int i=0;line[i];i++){ if(block){ if(line[i]=='*'&&line[i+1]=='/'){block=0;i++;} continue;} if(line[i]=='/'&&line[i+1]=='*'){block=1;i++; continue;} if(line[i]=='/'&&line[i+1]=='/') break; out[j++]=line[i]; } out[j]=0; return out; }

static void parse_import_line(char *t, Map *imports, int *nimp){
    char alias[128]="", path[512]=""; char *q=strchr(t,'"'); if(!q) return; char *q2=strchr(q+1,'"'); if(!q2) return; snprintf(path,sizeof(path),"%.*s",(int)(q2-q-1),q+1);
    char before[256]; snprintf(before,sizeof(before),"%.*s",(int)(q-t),t); char *b=trim(before);
    if(starts(b,"import")) b=trim(b+6);
    if(*b && strcmp(b,".")!=0 && strcmp(b,"_")!=0) strncpy(alias,b,sizeof(alias)-1); else { const char *slash=strrchr(path,'/'); strncpy(alias,slash?slash+1:path,sizeof(alias)-1); }
    imports[*nimp].key=xstrdup(alias); imports[*nimp].val=xstrdup(path); (*nimp)++;
}

static char *return_part_after_params(const char *s){
    int depth=0; const char *last=NULL; for(const char*p=s;*p;p++){ if(*p=='(') depth++; else if(*p==')'){ depth--; if(depth==0) last=p; }} return last ? xstrdup(trim((char*)last+1)) : xstrdup("");
}

static void collect_funcs_in_file(const char *file,const char *pkg_path,char *pkgname_out){
    FILE*f=fopen(file,"r"); if(!f) return; char raw[MAX_LINE];
    while(fgets(raw,sizeof(raw),f)){
        char *line=strip_comments(raw); char *t=trim(line);
        if(starts(t,"package ") && pkgname_out && !*pkgname_out){ char *p=trim(t+8); char *e=p; while(*e && (isalnum((unsigned char)*e)||*e=='_')) e++; *e=0; strcpy(pkgname_out,p); }
        char *fp=strstr(t,"func "); if(fp==t || (fp && fp>t && isspace((unsigned char)fp[-1]))){
            fp+=5; if(*fp=='('){ char *close=strchr(fp,')'); if(close) fp=trim(close+1); }
            char name[256]=""; int k=0; while((isalnum((unsigned char)*fp)||*fp=='_') && k<255) name[k++]=*fp++; name[k]=0; if(!name[0]) { free(line); continue; }
            char *open=strchr(fp,'('); char *ret=xstrdup(""); if(open){ int dep=0; char *q=open; for(;*q;q++){ if(*q=='(') dep++; else if(*q==')'){ dep--; if(dep==0){ ret=xstrdup(trim(q+1)); break; } } } } char *body=strchr(ret,'{'); if(body) *body=0; ret=trim(ret); int re=contains(ret,"error");
            if(re && n_funcs<MAX_ITEMS){ funcs[n_funcs].pkg_path=xstrdup(pkg_path); funcs[n_funcs].name=xstrdup(name); char sig[2048]; snprintf(sig,sizeof(sig),"func %s.%s() %s",pkg_path,name,ret); funcs[n_funcs].sig=xstrdup(sig); funcs[n_funcs].returns_error=1; n_funcs++; }
            free(ret);
        }
        free(line);
    }
    fclose(f);
}

static void collect_all_functions(int include_tests){
    for(int i=0;i<n_packages;i++){
        DIR*d=opendir(packages[i].path); if(!d) continue; struct dirent*e; char pkgname[128]="";
        while((e=readdir(d))){ if(!ends(e->d_name,".go") || (!include_tests && ends(e->d_name,"_test.go"))) continue; char p[PATH_MAX]; path_join(p,sizeof(p),packages[i].path,e->d_name); collect_funcs_in_file(p,packages[i].import_path,pkgname); }
        closedir(d); free(packages[i].pkg); packages[i].pkg=xstrdup(pkgname[0]?pkgname:"");
    }
}

static Function *find_func(const char *pkg,const char *name){ for(int i=0;i<n_funcs;i++) if(strcmp(funcs[i].pkg_path,pkg)==0 && strcmp(funcs[i].name,name)==0) return &funcs[i]; return NULL; }
static const char *import_lookup(Map *imports,int n,const char *alias){ for(int i=0;i<n;i++) if(strcmp(imports[i].key,alias)==0) return imports[i].val; return NULL; }
static int ignored_sig(const char *sig,const char *pkg){ for(int i=0;i<cfg.n_ignore_sigs;i++) if(contains(sig,cfg.ignore_sigs[i])) return 1; for(int i=0;i<cfg.n_extra_ignore_sigs;i++) if(contains(sig,cfg.extra_ignore_sigs[i])) return 1; for(int i=0;i<cfg.n_ignore_pkg_globs;i++) if(fnmatch(cfg.ignore_pkg_globs[i],pkg,0)==0) return 1; return 0; }

static void add_diag(const char *file,int line,int col,const char *pkg,const char *sig,int internal){
    if(ignored_sig(sig,pkg)) return; if(internal && !cfg.report_internal) return;
    if(n_diags>=MAX_ITEMS) return; diags[n_diags].file=xstrdup(file); diags[n_diags].line=line; diags[n_diags].col=col; diags[n_diags].pkg=xstrdup(pkg);
    char msg[4096]; snprintf(msg,sizeof(msg),"%s: sig: %s", internal?"package-internal error should be wrapped":"error returned from external package is unwrapped", sig);
    diags[n_diags].msg=xstrdup(msg); n_diags++;
}

static void set_origin(Origin *orig,int *n,const char *name,const char *sig,int internal){ for(int i=0;i<*n;i++) if(strcmp(orig[i].name,name)==0){ free(orig[i].sig); orig[i].sig=xstrdup(sig); orig[i].internal=internal; return;} orig[*n].name=xstrdup(name); orig[*n].sig=xstrdup(sig); orig[*n].internal=internal; (*n)++; }
static Origin *get_origin(Origin *orig,int n,const char *name){ for(int i=0;i<n;i++) if(strcmp(orig[i].name,name)==0) return &orig[i]; return NULL; }

static int parse_call_sig(const char *expr,const char *curpkg,Map *imports,int nimp,char *sig,size_t sigsz,char *pkgout,size_t pkgsz,int *internal){
    char buf[MAX_LINE]; strncpy(buf,expr,sizeof(buf)-1); buf[sizeof(buf)-1]=0; char *p=trim(buf); char *paren=strchr(p,'('); if(!paren) return 0; *paren=0; char *call=trim(p);
    if(contains(call," ") || contains(call,"{") || contains(call,"==")) return 0;
    char *dot=strrchr(call,'.');
    if(dot){ *dot=0; char *left=call; char *fname=dot+1; const char *imp=import_lookup(imports,nimp,left); if(imp){ Function *fn=find_func(imp,fname); strncpy(pkgout,imp,pkgsz-1); *internal=strcmp(imp,curpkg)==0; if(fn) snprintf(sig,sigsz,"%s",fn->sig); else snprintf(sig,sigsz,"func %s.%s() error",imp,fname); return 1; }
        /* method or selector on a value: treat as external unless clearly local */
        snprintf(pkgout,pkgsz,"%s",left); snprintf(sig,sigsz,"func %s.%s() error",left,fname); *internal=0; return 1;
    } else {
        Function *fn=find_func(curpkg,call); if(fn){ strncpy(pkgout,curpkg,pkgsz-1); snprintf(sig,sigsz,"%s",fn->sig); *internal=1; return 1; }
    }
    return 0;
}

static void analyze_file(const char *file,Package *pkg,int include_tests,int context){
    (void)include_tests; (void)context; FILE*f=fopen(file,"r"); if(!f) return; char *lines[20000]; int nlines=0; char raw[MAX_LINE];
    while(nlines<20000 && fgets(raw,sizeof(raw),f)) lines[nlines++]=xstrdup(raw); fclose(f);
    Map imports[512]; int nimp=0, in_import=0; Origin orig[1024]; int norig=0; int brace_depth=0, in_func=0;
    for(int i=0;i<nlines;i++){
        char *clean=strip_comments(lines[i]); char *t=trim(clean);
        if(starts(t,"import (") || strcmp(t,"import(")==0){ in_import=1; free(clean); continue; }
        if(in_import){ if(strchr(t,')')) in_import=0; else parse_import_line(t,imports,&nimp); free(clean); continue; }
        if(starts(t,"import ")) parse_import_line(t,imports,&nimp);
        if(starts(t,"func ") || strstr(t," func ")){ in_func=1; norig=0; }
        if(in_func){
            /* assignments from calls */
            char *assign=strstr(t,":="); if(!assign) assign=strchr(t,'=');
            if(assign && !starts(t,"return ")){
                char lhs[MAX_LINE], rhs[MAX_LINE]; snprintf(lhs,sizeof(lhs),"%.*s",(int)(assign-t),t); snprintf(rhs,sizeof(rhs),"%s",assign+((*assign==':' && assign[1]=='=')?2:1));
                char sig[2048]="", pk[1024]=""; int internal=0; if(parse_call_sig(rhs,pkg->import_path,imports,nimp,sig,sizeof(sig),pk,sizeof(pk),&internal)){
                    char *save=NULL; char *tok=strtok_r(lhs,",",&save); while(tok){ char *v=trim(tok); if(strcmp(v,"_")!=0 && *v){ char *e=v+strlen(v); while(e>v && !isalnum((unsigned char)e[-1]) && e[-1]!='_') *--e=0; char *s=v; while(*s && !(isalpha((unsigned char)*s)||*s=='_')) s++; char *last=s; for(char *q=s; *q; q++) if(isspace((unsigned char)*q)) last=q+1; s=last; if(*s) set_origin(orig,&norig,s,sig,internal); } tok=strtok_r(NULL,",",&save); }
                }
            }
            char *ret=strstr(t,"return"); if(ret && (ret==t || isspace((unsigned char)ret[-1]))){
                char *expr=trim(ret+6); int basecol=(int)(ret-clean)+8;
                char exprcopy[MAX_LINE]; strncpy(exprcopy,expr,sizeof(exprcopy)-1); exprcopy[sizeof(exprcopy)-1]=0;
                int skip_origins=0; for(int ii=0; ii<cfg.n_ignore_sigs; ii++) if(contains(expr, cfg.ignore_sigs[ii])) skip_origins=1; for(int ii=0; ii<cfg.n_extra_ignore_sigs; ii++) if(contains(expr, cfg.extra_ignore_sigs[ii])) skip_origins=1;
                char sig[2048]="", pk[1024]=""; int internal=0;
                if(parse_call_sig(exprcopy,pkg->import_path,imports,nimp,sig,sizeof(sig),pk,sizeof(pk),&internal)) add_diag(file,i+1,basecol,pkg->import_path,sig,internal);
                char *save=NULL; char *tok= skip_origins ? NULL : strtok_r(exprcopy,",",&save); int offset=0; while(tok){ char *v=trim(tok); char *ve=v+strlen(v); while(ve>v && !(isalnum((unsigned char)ve[-1])||ve[-1]=='_')) *--ve=0; while(*v && !(isalnum((unsigned char)*v)||*v=='_')) v++; Origin *o=get_origin(orig,norig,v); if(o){ char *loc=strstr(expr,v); int col=loc?(int)(loc-clean)+1:basecol+offset; add_diag(file,i+1,col,pkg->import_path,o->sig,o->internal); } offset += strlen(tok)+1; tok=strtok_r(NULL,",",&save); }
            }
            for(char *p=t;*p;p++){ if(*p=='{') brace_depth++; else if(*p=='}'){ if(brace_depth>0) brace_depth--; }}
            if(brace_depth==0 && strchr(t,'}')) in_func=0;
        }
        free(clean);
    }
    for(int i=0;i<nlines;i++) free(lines[i]);
}

static void analyze_all(int include_tests,int context){ for(int i=0;i<n_packages;i++){ DIR*d=opendir(packages[i].path); if(!d) continue; struct dirent*e; while((e=readdir(d))){ if(!packages[i].analyze || !ends(e->d_name,".go") || (!include_tests && ends(e->d_name,"_test.go"))) continue; char p[PATH_MAX]; path_join(p,sizeof(p),packages[i].path,e->d_name); analyze_file(p,&packages[i],include_tests,context); } closedir(d);} }

static void print_flags(){ puts("["); const char*names[]={"V","all","c","diff","flags","json","source","tags","test","v"}; const int bools[]={1,1,0,1,1,1,1,0,1,1}; const char*usage[]={"print version and exit","no effect (deprecated)","display offending line with this many lines of context","with -fix, don't update the files, but print a unified diff","print analyzer flags in JSON","emit JSON output","no effect (deprecated)","no effect (deprecated)","indicates whether test files should be analyzed, too","no effect (deprecated)"}; for(int i=0;i<10;i++){ printf("\t{\n\t\t\"Name\": \"%s\",\n\t\t\"Bool\": %s,\n\t\t\"Usage\": \"%s\"\n\t}%s\n",names[i],bools[i]?"true":"false",usage[i],i==9?"":","); } puts("]"); }
static void print_help(){ printf("wrapcheck: Checks that errors returned from external packages are wrapped\n\nUsage: wrapcheck [-flag] [package]\n\n\nFlags:\n  -V\tprint version and exit\n  -all\n    \tno effect (deprecated)\n  -c int\n    \tdisplay offending line with this many lines of context (default -1)\n  -diff\n    \twith -fix, don't update the files, but print a unified diff\n  -fix\n    \tapply all suggested fixes\n  -flags\n    \tprint analyzer flags in JSON\n  -json\n    \temit JSON output\n  -source\n    \tno effect (deprecated)\n  -tags string\n    \tno effect (deprecated)\n  -test\n    \tindicates whether test files should be analyzed, too (default true)\n  -v\tno effect (deprecated)\n"); }

static void output_plain(int context){
    for(int i=0;i<n_diags;i++){
        printf("%s:%d:%d: %s\n",diags[i].file,diags[i].line,diags[i].col,diags[i].msg);
        if(context>=0){ FILE*f=fopen(diags[i].file,"r"); if(f){ char line[MAX_LINE]; int ln=0; int start=diags[i].line-context; if(start<1) start=1; int end=diags[i].line+context; while(fgets(line,sizeof(line),f)){ ln++; if(ln>=start && ln<=end) printf("%d\t%s",ln,line); if(ln>end) break; } fclose(f); }
        }
    }
}
static void output_json(){
    printf("{"); int firstpkg=1; for(int p=0;p<n_packages;p++){ int count=0; for(int i=0;i<n_diags;i++) if(strcmp(diags[i].pkg,packages[p].import_path)==0) count++; if(!count) continue; char *kp=json_escape(packages[p].import_path); printf("%s\n\t\"%s\": {\n\t\t\"wrapcheck\": [",firstpkg?"":",",kp); free(kp); firstpkg=0; int first=1; for(int i=0;i<n_diags;i++) if(strcmp(diags[i].pkg,packages[p].import_path)==0){ char pos[PATH_MAX+64]; snprintf(pos,sizeof(pos),"%s:%d:%d",diags[i].file,diags[i].line,diags[i].col); char *pe=json_escape(pos), *me=json_escape(diags[i].msg); printf("%s\n\t\t\t{\n\t\t\t\t\"posn\": \"%s\",\n\t\t\t\t\"message\": \"%s\"\n\t\t\t}",first?"":",",pe,me); first=0; free(pe); free(me);} printf("\n\t\t]\n\t}"); }
    printf("\n}\n");
}

int main(int argc,char**argv){ int json=0, flags=0, context=-1, include_tests=1; char *args[256]; int nargs=0; load_config();
    for(int i=1;i<argc;i++){
        if(strcmp(argv[i],"--help")==0 || strcmp(argv[i],"-h")==0){ print_help(); return 0; }
        else if(strcmp(argv[i],"-flags")==0){ flags=1; }
        else if(strcmp(argv[i],"-json")==0){ json=1; }
        else if(starts(argv[i],"-c=")){ context=atoi(argv[i]+3); }
        else if(strcmp(argv[i],"-c")==0 && i+1<argc){ context=atoi(argv[++i]); }
        else if(strcmp(argv[i],"-test=false")==0){ include_tests=0; }
        else if(strcmp(argv[i],"-test")==0){ include_tests=1; }
        else if(strcmp(argv[i],"-V=full")==0){ printf("wrapcheck version unknown\n"); return 0; }
        else if(strcmp(argv[i],"-V")==0 || starts(argv[i],"-V=")){ fprintf(stderr,"wrapcheck: unsupported flag value: %s (use -V=full)\n", strchr(argv[i],'=')?argv[i]:"-V=true"); return 1; }
        else if(argv[i][0]=='-') { /* accept no-op analyzer flags */ if(strcmp(argv[i],"-fix")==0||strcmp(argv[i],"-diff")==0||strcmp(argv[i],"-all")==0||strcmp(argv[i],"-source")==0||strcmp(argv[i],"-v")==0){} else if(strcmp(argv[i],"-tags")==0 && i+1<argc) i++; else if(starts(argv[i],"-tags=")){} }
        else args[nargs++]=argv[i];
    }
    if(flags){ print_flags(); return 0; }
    find_workspace(); if(nargs==0) args[nargs++]=".";
    if(module_path[0]) walk_packages2(workspace,include_tests,0);
    for(int i=0;i<nargs;i++){ if(ends(args[i],"/...")){ char base[PATH_MAX]; snprintf(base,sizeof(base),"%.*s",(int)(strlen(args[i])-4),args[i]); char *p=normalize_arg_path(base); walk_packages(p,include_tests); } else { char *p=normalize_arg_path(args[i]); if(is_dir(p)) add_package_dir(p); }}
    collect_all_functions(include_tests); analyze_all(include_tests,context);
    if(json){ output_json(); return 0; } output_plain(context); return n_diags?3:0;
}
