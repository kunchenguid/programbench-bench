#define _XOPEN_SOURCE 700
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef enum { SORT_NAME, SORT_SIZE, SORT_DATE, SORT_TYPE_FIRST, SORT_TYPE_LAST, SORT_NONE } SortMode;

typedef struct {
    int hidden, only_folders, sizes, dates, perms, trim_root, no_tree;
    int max_depth;
    int height;
    int color;
    SortMode sort;
    const char *cmd, *outcmd, *verb_output, *root;
} Opts;

typedef struct {
    char *name, *path, *link_target;
    struct stat st;
    int is_dir, is_link;
    long long size;
} Entry;

static const char *version = "broot 1.54.0";

static void print_help(void) {
    printf("                   broot 1.54.0\n\n\n");
    printf("broot lets you explore file hierarchies with a\n");
    printf("tree-like view, manipulate and preview files,\n");
    printf("launch actions, and define your own shortcuts.\n\n");
    printf("broot is best launched as br: this shell function\n");
    printf("gives you access to more commands, especially cd.\n");
    printf("The br shell function is interactively installed\n");
    printf("on first broot launch.\n\n");
    printf("Flags and options can be classically passed on\n");
    printf("launch but also written in the configuration file.\n");
    printf("Each flag has a counter-flag so that you can\n");
    printf("cancel at command line a flag which has been set\n");
    printf("in the configuration file.\n\n");
    printf("Complete documentation and tips at\n");
    printf("https://dystroy.org/broot\n\n");
    printf("Usage:  broot [options] [ROOT]\n\n");
    printf("Options:\n");
    printf("      --help                       Print help information\n");
    printf("      --version                    print the version\n");
    printf("      --conf <paths>               Semicolon separated paths to specific config files\n");
    printf("  -d, --dates                      Show the last modified date of files and directories\n");
    printf("  -D, --no-dates                   Don't show the last modified date\n");
    printf("  -f, --only-folders               Only show folders\n");
    printf("  -F, --no-only-folders            Show folders and files alike\n");
    printf("      --show-root-fs               Show filesystem info on top\n");
    printf("      --max-depth <MAX_DEPTH>      Only show trees up to a certain depth\n");
    printf("  -g, --show-git-info              Show git statuses on files and stats on repo\n");
    printf("  -G, --no-show-git-info           Don't show git statuses on files and stats on repo\n");
    printf("      --git-status                 Only show files having an interesting git status\n");
    printf("  -h, --hidden                     Show hidden files\n");
    printf("  -H, --no-hidden                  Don't show hidden files\n");
    printf("  -i, --git-ignored                Show git ignored files\n");
    printf("  -I, --no-git-ignored             Don't show git ignored files\n");
    printf("  -p, --permissions                Show permissions\n");
    printf("  -P, --no-permissions             Don't show permissions\n");
    printf("  -s, --sizes                      Show the size of files and directories\n");
    printf("  -S, --no-sizes                   Don't show sizes\n");
    printf("      --sort-by-count              Sort by count (only show one level of the tree)\n");
    printf("      --sort-by-date               Sort by date (only show one level of the tree)\n");
    printf("      --sort-by-size               Sort by size (only show one level of the tree)\n");
    printf("      --sort-by-type               Same as sort-by-type-dirs-first\n");
    printf("      --sort-by-type-dirs-first    Sort by type, directories first\n");
    printf("      --sort-by-type-dirs-last     Sort by type, directories last\n");
    printf("      --no-sort                    Don't sort\n");
    printf("  -w, --whale-spotting             Sort by size, show ignored and hidden files\n");
    printf("  -t, --trim-root                  Trim the root too and don't show a scrollbar\n");
    printf("  -T, --no-trim-root               Don't trim the root level, show a scrollbar\n");
    printf("      --outcmd <path>              Where to write the produced cmd (if any)\n");
    printf("      --verb-output <path>         Optional path for verbs using :write_output\n");
    printf("  -c, --cmd <cmd>                  Semicolon separated commands to execute\n");
    printf("      --color <color>              Whether to have styles and colors [auto, yes, no]\n");
    printf("      --height <height>            Height (if you don't want to fill the screen)\n");
    printf("      --install                    Install or reinstall the br shell function\n");
    printf("      --set-install-state <state>  Manually set installation state\n");
    printf("      --print-shell-function <sh>  Print to stdout the br function for a given shell\n");
    printf("      --write-default-conf <path>  Write default conf files in given directory\n");
}

static int is_flag_with_value(const char *s) {
    const char *names[] = {"--conf","--max-depth","--outcmd","--verb-output","--cmd","-c","--color","--height","--set-install-state","--print-shell-function","--listen","--send","--write-default-conf",NULL};
    for (int i=0; names[i]; i++) if (!strcmp(s, names[i])) return 1;
    return 0;
}

static int apply_short_cluster(const char *a, Opts *o) {
    if (a[0] != '-' || a[1] == '-' || !a[1] || !a[2]) return 0;
    for (int j = 1; a[j]; j++) {
        switch (a[j]) {
            case 'h': o->hidden = 1; break;
            case 'H': o->hidden = 0; break;
            case 'f': o->only_folders = 1; break;
            case 'F': o->only_folders = 0; break;
            case 's': o->sizes = 1; break;
            case 'S': o->sizes = 0; break;
            case 'd': o->dates = 1; break;
            case 'D': o->dates = 0; break;
            case 'p': o->perms = 1; break;
            case 'P': o->perms = 0; break;
            case 't': o->trim_root = 1; break;
            case 'T': o->trim_root = 0; break;
            case 'w': o->hidden = 1; o->sort = SORT_SIZE; break;
            case 'W': o->hidden = 0; o->sort = SORT_NONE; break;
            case 'g': case 'G': case 'i': case 'I': break;
            default: return 0;
        }
    }
    return 1;
}

static int parse_int_arg(const char *name, const char *v, int *out) {
    char *end = NULL; long x = strtol(v, &end, 10);
    if (!v[0] || *end) {
        fprintf(stderr, "error: invalid value '%s' for '%s': invalid digit found in string\n", v, name);
        return 2;
    }
    *out = (int)x; return 0;
}

static void shell_bash(void) {
    puts("\n# This script was automatically generated by the broot program");
    puts("# More information can be found in https://github.com/Canop/broot");
    puts("# This function starts broot and executes the command");
    puts("# it produces, if any.");
    puts("# It's needed because some shell commands, like `cd`,");
    puts("# have no useful effect if executed in a subshell.");
    puts("function br {");
    puts("    local cmd cmd_file code");
    puts("    cmd_file=$(mktemp)");
    puts("    if broot --outcmd \"$cmd_file\" \"$@\"; then");
    puts("        cmd=$(<\"$cmd_file\")");
    puts("        command rm -f \"$cmd_file\"");
    puts("        eval \"$cmd\"");
    puts("    else");
    puts("        code=$?");
    puts("        command rm -f \"$cmd_file\"");
    puts("        return \"$code\"");
    puts("    fi");
    puts("}");
    puts("");
}

static void shell_fish(void) {
    puts("\n# This script was automatically generated by the broot program");
    puts("# More information can be found in https://github.com/Canop/broot");
    puts("# This function starts broot and executes the command");
    puts("# it produces, if any.");
    puts("# It's needed because some shell commands, like `cd`,");
    puts("# have no useful effect if executed in a subshell.");
    puts("function br --wraps=broot");
    puts("    set -l cmd_file (mktemp)");
    puts("    if broot --outcmd $cmd_file $argv");
    puts("        source $cmd_file");
    puts("        rm -f $cmd_file");
    puts("    else");
    puts("        set -l code $status");
    puts("        rm -f $cmd_file");
    puts("        return $code");
    puts("    end");
    puts("end");
    puts("");
}

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX]; snprintf(tmp, sizeof tmp, "%s", path);
    for (char *p = tmp + 1; *p; p++) if (*p == '/') { *p = 0; mkdir(tmp, 0777); *p = '/'; }
    return mkdir(tmp, 0777) == 0 || errno == EEXIST ? 0 : -1;
}

static int write_file(const char *path, const char *content) {
    FILE *f = fopen(path, "w");
    if (!f) return -1;
    fputs(content, f);
    fclose(f);
    return 0;
}

static int write_default_conf(const char *dir) {
    char p[PATH_MAX];
    mkdir_p(dir);
    snprintf(p, sizeof p, "%s/skins", dir); mkdir_p(p);
    snprintf(p, sizeof p, "%s/conf.hjson", dir);
    write_file(p,
        "###############################################################\n"
        "# This configuration file lets you\n"
        "# - define new commands\n"
        "# - change the shortcut or triggering keys of built-in verbs\n"
        "# - change the colors\n"
        "# - set default values for flags\n"
        "# - set special behaviors on specific paths\n"
        "# - and more...\n#\n"
        "# Configuration documentation is available at\n"
        "#     https://dystroy.org/broot\n#\n"
        "###############################################################\n\n"
        "# default_flags:\n"
        "verbs: [\n    { invocation: edit, shortcut: e, execution: \"$EDITOR {file}\" }\n]\n");
    snprintf(p, sizeof p, "%s/verbs.hjson", dir);
    write_file(p, "# default verbs configuration for broot\n");
    const char *skins[] = {"catppuccin-macchiato","catppuccin-mocha","dark-blue","dark-gruvbox","dark-orange","native-16","solarized-dark","solarized-light","white",NULL};
    for (int i=0; skins[i]; i++) {
        snprintf(p, sizeof p, "%s/skins/%s.hjson", dir, skins[i]);
        write_file(p, "# skin file\n");
    }
    printf("New Configuration files written in \"%s\".\n", dir);
    printf("You should have a look at them: their comments will help you configure broot.\n");
    return 0;
}

static char *xstrdup(const char *s) { char *r = malloc(strlen(s)+1); if (!r) exit(3); strcpy(r,s); return r; }

static long long dir_size(const char *path, int max_depth);

static long long entry_size(const char *path, const struct stat *st, int depth) {
    if (S_ISDIR(st->st_mode)) return dir_size(path, depth);
    return (long long)st->st_size;
}

static long long dir_size(const char *path, int max_depth) {
    struct stat st; if (lstat(path, &st)) return 0;
    long long total = st.st_size;
    if (max_depth == 0 || !S_ISDIR(st.st_mode)) return total;
    DIR *d = opendir(path); if (!d) return total;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
        char child[PATH_MAX]; snprintf(child, sizeof child, "%s/%s", path, de->d_name);
        struct stat cs; if (!lstat(child, &cs)) total += entry_size(child, &cs, max_depth > 0 ? max_depth-1 : -1);
    }
    closedir(d);
    return total;
}

static Opts *cmp_opts;
static int cmp_entry(const void *a, const void *b) {
    const Entry *ea = a, *eb = b;
    if (cmp_opts->sort == SORT_NONE) return 0;
    if (cmp_opts->sort == SORT_TYPE_FIRST && ea->is_dir != eb->is_dir) return eb->is_dir - ea->is_dir;
    if (cmp_opts->sort == SORT_TYPE_LAST && ea->is_dir != eb->is_dir) return ea->is_dir - eb->is_dir;
    if (cmp_opts->sort == SORT_SIZE && ea->size != eb->size) return (ea->size < eb->size) ? 1 : -1;
    if (cmp_opts->sort == SORT_DATE && ea->st.st_mtime != eb->st.st_mtime) return (ea->st.st_mtime < eb->st.st_mtime) ? 1 : -1;
    return strcmp(ea->name, eb->name);
}

static void mode_string(mode_t m, char out[11]) {
    out[0] = S_ISDIR(m)?'d':S_ISLNK(m)?'l':'-';
    const char *rwx = "rwx";
    for (int i=0; i<9; i++) out[i+1] = (m & (1 << (8-i))) ? rwx[i%3] : '-';
    out[10] = 0;
}

static void size_string(long long n, char *buf, size_t len) {
    const char *u[] = {"B","KB","MB","GB","TB"};
    double v = (double)n; int i=0;
    while (v >= 1000.0 && i < 4) { v /= 1000.0; i++; }
    if (i == 0) snprintf(buf, len, "%lld B", n);
    else snprintf(buf, len, "%.1f %s", v, u[i]);
}

static void print_prefix(int depth, int *last_stack, int is_last) {
    for (int i=0; i<depth-1; i++) printf("%s", last_stack[i] ? "   " : "│  ");
    if (depth > 0) printf("%s", is_last ? "└──" : "├──");
}

static void print_entry_line(const Opts *o, const char *name, const char *link, const struct stat *st, long long sz, int depth, int *last_stack, int is_last) {
    char pre[128] = "";
    if (o->perms) { char m[11]; mode_string(st->st_mode, m); strcat(pre, m); strcat(pre, " "); }
    if (o->dates) {
        char tb[32]; struct tm tm; localtime_r(&st->st_mtime, &tm);
        strftime(tb, sizeof tb, "%Y/%m/%d", &tm); strcat(pre, tb); strcat(pre, " ");
    }
    if (o->sizes) { char sb[32]; size_string(sz, sb, sizeof sb); strcat(pre, sb); strcat(pre, " "); }
    print_prefix(depth, last_stack, is_last);
    printf("%s%s", pre, name);
    if (link) printf(" -> %s", link);
    putchar('\n');
}

static int read_entries(const char *path, const Opts *o, Entry **out, int size_depth) {
    DIR *d = opendir(path); if (!d) return -1;
    int cap=32, n=0; Entry *arr = calloc(cap, sizeof *arr);
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
        if (!o->hidden && de->d_name[0] == '.') continue;
        char child[PATH_MAX]; snprintf(child, sizeof child, "%s/%s", path, de->d_name);
        struct stat st; if (lstat(child, &st)) continue;
        int isdir = S_ISDIR(st.st_mode);
        if (o->only_folders && !isdir) continue;
        if (n == cap) { cap *= 2; arr = realloc(arr, cap * sizeof *arr); if (!arr) exit(3); }
        arr[n].name = xstrdup(de->d_name);
        arr[n].path = xstrdup(child);
        arr[n].st = st;
        arr[n].is_dir = isdir;
        arr[n].is_link = S_ISLNK(st.st_mode);
        arr[n].size = entry_size(child, &st, size_depth);
        if (arr[n].is_link) {
            char lnk[PATH_MAX]; ssize_t r = readlink(child, lnk, sizeof lnk - 1);
            if (r >= 0) { lnk[r] = 0; arr[n].link_target = xstrdup(lnk); }
        }
        n++;
    }
    closedir(d);
    *out = arr; return n;
}

static void free_entries(Entry *e, int n) {
    for (int i=0; i<n; i++) { free(e[i].name); free(e[i].path); free(e[i].link_target); }
    free(e);
}

static void print_tree_rec(const Opts *o, const char *path, int depth, int *last_stack) {
    if (o->max_depth >= 0 && depth >= o->max_depth) return;
    Entry *e = NULL; int n = read_entries(path, o, &e, 4);
    if (n < 0) return;
    cmp_opts = (Opts *)o; qsort(e, n, sizeof *e, cmp_entry);
    for (int i=0; i<n; i++) {
        int last = (i == n-1); last_stack[depth] = last;
        print_entry_line(o, e[i].name, e[i].link_target, &e[i].st, e[i].size, depth+1, last_stack, last);
        if (e[i].is_dir) print_tree_rec(o, e[i].path, depth+1, last_stack);
    }
    free_entries(e, n);
}

static int print_tree(const Opts *o) {
    char root[PATH_MAX];
    if (!realpath(o->root ? o->root : ".", root)) snprintf(root, sizeof root, "%s", o->root ? o->root : ".");
    struct stat st;
    if (lstat(root, &st)) { fprintf(stderr, "Can not read %s: %s\n", root, strerror(errno)); return 1; }
    if (!o->trim_root) {
        long long sz = entry_size(root, &st, 4);
        int stack[256] = {0};
        print_entry_line(o, root, NULL, &st, sz, 0, stack, 1);
    }
    if (S_ISDIR(st.st_mode)) {
        int stack[256] = {0};
        print_tree_rec(o, root, 0, stack);
    }
    return 0;
}

static int contains_cmd(const char *cmd, const char *needle) {
    return cmd && strstr(cmd, needle);
}

static int handle_cmd(const Opts *o) {
    if (!o->cmd) return print_tree(o);
    if (contains_cmd(o->cmd, ":q") || !strcmp(o->cmd, "q")) return 0;
    if (contains_cmd(o->cmd, ":print_path") || contains_cmd(o->cmd, ":pp")) {
        char root[PATH_MAX];
        if (realpath(o->root ? o->root : ".", root)) puts(root); else puts(o->root ? o->root : ".");
        return 0;
    }
    if (contains_cmd(o->cmd, ":print_tree") || contains_cmd(o->cmd, ":pt") || contains_cmd(o->cmd, "print_tree")) return print_tree(o);
    if (contains_cmd(o->cmd, ":cd")) {
        if (o->outcmd) {
            FILE *f = fopen(o->outcmd, "w");
            if (f) { fprintf(f, "cd %s\n", o->root ? o->root : "."); fclose(f); }
        }
        return 0;
    }
    return print_tree(o);
}

int main(int argc, char **argv) {
    Opts o = {.max_depth = -1, .height = 0, .color = 0, .sort = SORT_NAME, .root = "."};
    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (apply_short_cluster(a, &o)) {
        } else if (!strcmp(a, "--help")) { print_help(); return 0; }
        else if (!strcmp(a, "--version") || !strcmp(a, "-V")) { puts(version); return 0; }
        else if (!strcmp(a, "-h") || !strcmp(a, "--hidden")) o.hidden = 1;
        else if (!strcmp(a, "-H") || !strcmp(a, "--no-hidden")) o.hidden = 0;
        else if (!strcmp(a, "-f") || !strcmp(a, "--only-folders")) o.only_folders = 1;
        else if (!strcmp(a, "-F") || !strcmp(a, "--no-only-folders")) o.only_folders = 0;
        else if (!strcmp(a, "-s") || !strcmp(a, "--sizes")) o.sizes = 1;
        else if (!strcmp(a, "-S") || !strcmp(a, "--no-sizes")) o.sizes = 0;
        else if (!strcmp(a, "-d") || !strcmp(a, "--dates")) o.dates = 1;
        else if (!strcmp(a, "-D") || !strcmp(a, "--no-dates")) o.dates = 0;
        else if (!strcmp(a, "-p") || !strcmp(a, "--permissions")) o.perms = 1;
        else if (!strcmp(a, "-P") || !strcmp(a, "--no-permissions")) o.perms = 0;
        else if (!strcmp(a, "-t") || !strcmp(a, "--trim-root")) o.trim_root = 1;
        else if (!strcmp(a, "-T") || !strcmp(a, "--no-trim-root")) o.trim_root = 0;
        else if (!strcmp(a, "-w") || !strcmp(a, "--whale-spotting")) { o.hidden = 1; o.sort = SORT_SIZE; }
        else if (!strcmp(a, "-W") || !strcmp(a, "--no-whale-spotting")) { o.hidden = 0; o.sort = SORT_NONE; }
        else if (!strcmp(a, "--sort-by-size") || !strcmp(a, "--sort-by-count")) o.sort = SORT_SIZE;
        else if (!strcmp(a, "--sort-by-date")) o.sort = SORT_DATE;
        else if (!strcmp(a, "--sort-by-type") || !strcmp(a, "--sort-by-type-dirs-first")) o.sort = SORT_TYPE_FIRST;
        else if (!strcmp(a, "--sort-by-type-dirs-last")) o.sort = SORT_TYPE_LAST;
        else if (!strcmp(a, "--no-sort")) o.sort = SORT_NONE;
        else if (!strcmp(a, "--tree")) o.no_tree = 0;
        else if (!strcmp(a, "--no-tree")) o.no_tree = 1;
        else if (!strcmp(a, "-g") || !strcmp(a, "--show-git-info") || !strcmp(a, "-G") || !strcmp(a, "--no-show-git-info") || !strcmp(a, "-i") || !strcmp(a, "--git-ignored") || !strcmp(a, "-I") || !strcmp(a, "--no-git-ignored") || !strcmp(a, "--git-status") || !strcmp(a, "--show-root-fs") || !strcmp(a, "--listen-auto") || !strcmp(a, "--install")) {
        } else if (is_flag_with_value(a)) {
            if (i + 1 >= argc) { fprintf(stderr, "error: a value is required for '%s <value>' but none was supplied\n", a); return 2; }
            char *v = argv[++i];
            if (!strcmp(a, "--cmd") || !strcmp(a, "-c")) o.cmd = v;
            else if (!strcmp(a, "--outcmd")) o.outcmd = v;
            else if (!strcmp(a, "--verb-output")) o.verb_output = v;
            else if (!strcmp(a, "--max-depth")) { int rc = parse_int_arg("--max-depth <MAX_DEPTH>", v, &o.max_depth); if (rc) return rc; }
            else if (!strcmp(a, "--height")) { int rc = parse_int_arg("--height <height>", v, &o.height); if (rc) return rc; }
            else if (!strcmp(a, "--color")) {
                if (strcmp(v,"auto") && strcmp(v,"yes") && strcmp(v,"no")) {
                    fprintf(stderr, "error: invalid value '%s' for '--color <color>'\n  [possible values: auto, yes, no]\n", v);
                    return 2;
                }
            } else if (!strcmp(a, "--print-shell-function")) {
                if (!strcmp(v,"bash") || !strcmp(v,"zsh")) shell_bash();
                else if (!strcmp(v,"fish")) shell_fish();
                else { fprintf(stderr, "Unknown shell: %s\n", v); return 1; }
                return 0;
            } else if (!strcmp(a, "--write-default-conf")) return write_default_conf(v);
            else if (!strcmp(a, "--set-install-state")) {
                if (strcmp(v,"undefined") && strcmp(v,"refused") && strcmp(v,"installed")) {
                    fprintf(stderr, "error: invalid value '%s' for '--set-install-state <state>'\n", v);
                    return 2;
                }
                return 0;
            }
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [ROOT]\n", a, a, a);
            return 2;
        } else {
            o.root = a;
        }
    }
    return handle_cmd(&o);
}
