#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { char *data; size_t len, cap; } Str;
typedef struct { char **v; int n, cap; } List;
typedef struct {
    char *title, *author, *lang, *subject, *description, *subtitle, *output_html, *output_epub, *output_pdf, *output_tex, *output_odt, *output_base;
    List chapters;
} Book;

static void die_oom(void){ fprintf(stderr,"out of memory\n"); exit(1); }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) die_oom(); return p; }
static void s_init(Str *s){ s->cap=4096; s->len=0; s->data=malloc(s->cap); if(!s->data) die_oom(); s->data[0]=0; }
static void s_reserve(Str *s,size_t add){ if(s->len+add+1>s->cap){ while(s->len+add+1>s->cap) s->cap*=2; s->data=realloc(s->data,s->cap); if(!s->data) die_oom(); } }
static void s_cat(Str *s,const char *t){ size_t n=strlen(t); s_reserve(s,n); memcpy(s->data+s->len,t,n+1); s->len+=n; }
static void s_ncat(Str *s,const char *t,size_t n){ s_reserve(s,n); memcpy(s->data+s->len,t,n); s->len+=n; s->data[s->len]=0; }
static void s_printf(Str *s,const char *fmt,...){ va_list ap; va_start(ap,fmt); char buf[4096]; int n=vsnprintf(buf,sizeof buf,fmt,ap); va_end(ap); if(n<0)return; if((size_t)n<sizeof buf)s_cat(s,buf); else{ char *p=malloc(n+1); if(!p)die_oom(); va_start(ap,fmt); vsnprintf(p,n+1,fmt,ap); va_end(ap); s_cat(s,p); free(p);} }
static void list_add(List *l,const char *s){ if(l->n==l->cap){ l->cap=l->cap?l->cap*2:8; l->v=realloc(l->v,l->cap*sizeof(char*)); if(!l->v)die_oom(); } l->v[l->n++]=xstrdup(s); }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static bool starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }
static void setstr(char **dst,const char *v){ free(*dst); *dst=xstrdup(v); }
static void book_init(Book *b){ memset(b,0,sizeof *b); b->lang=xstrdup("en"); b->title=xstrdup(""); b->author=xstrdup(""); b->subject=xstrdup(""); b->description=xstrdup(""); b->subtitle=xstrdup(""); }

static char *read_file(const char *path){
    FILE *f=fopen(path,"rb"); if(!f)return NULL; Str s; s_init(&s); char buf[4096]; size_t n;
    while((n=fread(buf,1,sizeof buf,f))>0)s_ncat(&s,buf,n);
    fclose(f); return s.data;
}
static char *dir_of(const char *p){ const char *slash=strrchr(p,'/'); if(!slash)return xstrdup("."); size_t n=slash-p; char *d=malloc(n+1); if(!d)die_oom(); memcpy(d,p,n); d[n]=0; return d; }
static char *join_path(const char *d,const char *p){ if(!p||!*p)return xstrdup(d); if(p[0]=='/'||strcmp(d,".")==0)return xstrdup(p); Str s; s_init(&s); s_cat(&s,d); s_cat(&s,"/"); s_cat(&s,p); return s.data; }
static void html_escape(Str *o,const char *s){
    for(;*s;s++){ if(*s=='&')s_cat(o,"&amp;"); else if(*s=='<')s_cat(o,"&lt;"); else if(*s=='>')s_cat(o,"&gt;"); else if(*s=='\"')s_cat(o,"&quot;"); else { char c[2]={*s,0}; s_cat(o,c);} }
}
static char *inline_html(const char *s){
    Str o; s_init(&o);
    for(size_t i=0;s[i];){
        if(s[i]=='*'&&s[i+1]=='*'){ const char *e=strstr(s+i+2,"**"); if(e){ s_cat(&o,"<b>"); char *tmp=strndup(s+i+2,e-(s+i+2)); html_escape(&o,tmp); free(tmp); s_cat(&o,"</b>"); i=(e-s)+2; continue; } }
        if(s[i]=='*'){ const char *e=strchr(s+i+1,'*'); if(e){ s_cat(&o,"<em>"); char *tmp=strndup(s+i+1,e-(s+i+1)); html_escape(&o,tmp); free(tmp); s_cat(&o,"</em>"); i=(e-s)+1; continue; } }
        if(s[i]=='`'){ const char *e=strchr(s+i+1,'`'); if(e){ s_cat(&o,"<code>"); char *tmp=strndup(s+i+1,e-(s+i+1)); html_escape(&o,tmp); free(tmp); s_cat(&o,"</code>"); i=(e-s)+1; continue; } }
        char c[2]={s[i++],0}; html_escape(&o,c);
    }
    return o.data;
}
static char *latex_escape(const char *s){ Str o; s_init(&o); for(;*s;s++){ switch(*s){case '\\':s_cat(&o,"\\textbackslash{}");break;case '&':case '%':case '$':case '#':case '_':case '{':case '}': {char b[3]={'\\',*s,0};s_cat(&o,b);break;} case '~':s_cat(&o,"\\textasciitilde{}");break; case '^':s_cat(&o,"\\textasciicircum{}");break; default:{char b[2]={*s,0};s_cat(&o,b);} } } return o.data; }

static char *markdown_to_html(const char *md,int *chars,int *words){
    Str o; s_init(&o); char *copy=xstrdup(md), *save=NULL, *line; int para=1; bool in_ul=false, in_ol=false, in_pre=false;
    for(line=strtok_r(copy,"\n",&save); line; line=strtok_r(NULL,"\n",&save)){
        char *t=trim(line);
        if(starts(t,"```")){ if(!in_pre){ if(in_ul){s_cat(&o,"</ul>\n");in_ul=false;} s_cat(&o,"<pre><code>"); in_pre=true; } else { s_cat(&o,"</code></pre>\n"); in_pre=false; } continue; }
        if(in_pre){ html_escape(&o,t); s_cat(&o,"\n"); continue; }
        if(!*t){ if(in_ul){s_cat(&o,"</ul>\n");in_ul=false;} if(in_ol){s_cat(&o,"</ol>\n");in_ol=false;} continue; }
        if(t[0]=='#'){ int lvl=0; while(t[lvl]=='#')lvl++; if(t[lvl]==' '&&lvl<=6){ if(in_ul){s_cat(&o,"</ul>\n");in_ul=false;} char *ih=inline_html(trim(t+lvl)); s_printf(&o,"<h%d id = \"link-%d\">%s</h%d>\n",lvl,para++,ih,lvl); free(ih); continue; } }
        if(starts(t,"- ")||starts(t,"* ")){ if(!in_ul){s_cat(&o,"<ul>\n");in_ul=true;} char *ih=inline_html(trim(t+2)); s_printf(&o,"<li><p id = \"para-%d\">%s</p>\n",para++,ih); free(ih); continue; }
        char *p=t; while(isdigit((unsigned char)*p))p++; if(*p=='.'&&p[1]==' '){ if(!in_ol){s_cat(&o,"<ol>\n");in_ol=true;} char *ih=inline_html(trim(p+2)); s_printf(&o,"<li><p id = \"para-%d\">%s</p>\n",para++,ih); free(ih); continue; }
        char *ih=inline_html(t); s_printf(&o,"<p id = \"para-%d\">%s</p>\n",para++,ih); free(ih);
        for(char *q=t;*q;q++){ if(!isspace((unsigned char)*q))(*chars)++; }
        bool inw=false; for(char *q=t;*q;q++){ if(isspace((unsigned char)*q)){inw=false;} else if(!inw){(*words)++; inw=true;} }
    }
    if(in_ul)s_cat(&o,"</ul>\n"); if(in_ol)s_cat(&o,"</ol>\n"); free(copy); return o.data;
}

static char *first_heading(const char *md){
    char *copy=xstrdup(md), *save=NULL, *line; for(line=strtok_r(copy,"\n",&save);line;line=strtok_r(NULL,"\n",&save)){ char *t=trim(line); if(starts(t,"# ")){ char *r=xstrdup(trim(t+2)); free(copy); return r; } } free(copy); return xstrdup("");
}
static char *without_first_heading(const char *md){
    Str o; s_init(&o); char *copy=xstrdup(md), *save=NULL, *line; bool skipped=false;
    for(line=strtok_r(copy,"\n",&save); line; line=strtok_r(NULL,"\n",&save)){
        char *t=trim(line);
        if(!skipped && starts(t,"# ")){ skipped=true; continue; }
        s_cat(&o,line); s_cat(&o,"\n");
    }
    free(copy); return o.data;
}
static void parse_config(Book *b,const char *path){
    char *txt=read_file(path); if(!txt){ printf("CROWBOOK 0.17.0\nERROR Could not find file '%s' for book\n",path); exit(0); }
    char *base=dir_of(path), *save=NULL, *line;
    for(line=strtok_r(txt,"\n",&save); line; line=strtok_r(NULL,"\n",&save)){
        char *t=trim(line); if(!*t||t[0]=='#')continue;
        if(t[0]=='+'||t[0]=='-'||t[0]=='!'){ char *p=trim(t+1); char *j=join_path(base,p); list_add(&b->chapters,j); free(j); continue; }
        char *c=strchr(t,':'); if(!c)continue; *c=0; char *k=trim(t), *v=trim(c+1);
        if(strcmp(k,"title")==0)setstr(&b->title,v); else if(strcmp(k,"author")==0)setstr(&b->author,v); else if(strcmp(k,"lang")==0)setstr(&b->lang,v);
        else if(strcmp(k,"subject")==0)setstr(&b->subject,v); else if(strcmp(k,"description")==0)setstr(&b->description,v); else if(strcmp(k,"subtitle")==0)setstr(&b->subtitle,v);
        else if(strcmp(k,"output.html")==0){ char *j=join_path(base,v); setstr(&b->output_html,j); free(j); }
        else if(strcmp(k,"output.epub")==0){ char *j=join_path(base,v); setstr(&b->output_epub,j); free(j); }
        else if(strcmp(k,"output.pdf")==0){ char *j=join_path(base,v); setstr(&b->output_pdf,j); free(j); }
        else if(strcmp(k,"output.tex")==0){ char *j=join_path(base,v); setstr(&b->output_tex,j); free(j); }
        else if(strcmp(k,"output.odt")==0){ char *j=join_path(base,v); setstr(&b->output_odt,j); free(j); }
        else if(strcmp(k,"output")==0){ if(strstr(v,"html")){ char *j=join_path(base,"output.html"); setstr(&b->output_html,j); free(j);} if(strstr(v,"epub")){ char *j=join_path(base,"output.epub"); setstr(&b->output_epub,j); free(j);} if(strstr(v,"pdf")){ char *j=join_path(base,"output.pdf"); setstr(&b->output_pdf,j); free(j);} }
    }
    free(base); free(txt);
}
static void apply_set(Book *b,const char *k,const char *v){ if(strcmp(k,"title")==0)setstr(&b->title,v); else if(strcmp(k,"author")==0)setstr(&b->author,v); else if(strcmp(k,"lang")==0)setstr(&b->lang,v); else if(strcmp(k,"output.html")==0)setstr(&b->output_html,v); else if(strcmp(k,"output.epub")==0)setstr(&b->output_epub,v); else if(strcmp(k,"output.tex")==0)setstr(&b->output_tex,v); }

static const char *css="body {\n    font-family: \"Linux Libertine\", \"Georgia\", serif;\n    text-align: justify;\n    font-size: 100%;\n}\n\np {\n    text-indent: 1.25em;\n    margin:0;\n    hyphens: auto;\n}\ncode { background-color: #F0F0F0; }\nh1, h2, h3, h4, h5, h6 { text-align: left; font-family: Linux Biolinum, sans-serif; font-variant: small-caps; }\nh1.title { text-align: center; font-size: 300%; }\nh2.author { text-align: right; font-size: 200%; }\n";
static const char *js="function toggle() { }\nfunction on(name) { }\nfunction off(name) { }\n";
static void render_html(Book *b,FILE *out){
    Str body; s_init(&body); int totalc=0,totalw=0;
    for(int i=0;i<b->chapters.n;i++){ char *md=read_file(b->chapters.v[i]); if(!md){ printf("CROWBOOK 0.17.0\nERROR %s: Could not find file '%s' for book chapter\n",b->chapters.v[i],b->chapters.v[i]); exit(0);} int c=0,w=0; char *body_md=without_first_heading(md); char *h=markdown_to_html(body_md,&c,&w); char *head=first_heading(md); s_printf(&body,"<div id = \"chapter-%d\" class = \"chapter\">\n",i); if(*head){ char *eh=inline_html(head); s_printf(&body,"  <h1 id = 'link-%d'><span class = 'chapter-header'>Chapter %d</span><br />%s</h1>",i+1,i+1,eh); free(eh); } s_cat(&body,h); s_cat(&body,"\n</div>\n"); totalc+=c; totalw+=w; free(body_md); free(head); free(h); free(md); }
    (void)totalc; (void)totalw;
    fprintf(out,"<!DOCTYPE html>\n<html lang=\"%s\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"generator\" content=\"crowbook\">\n    <meta name=\"viewport\" content=\"width=device-width\">\n    <meta name=\"author\" content=\"%s\">\n    \n    <title>%s</title>\n    <style type = \"text/css\">\n      %s\n    </style>\n   <script>\n    %s\n   </script>\n  </head>\n  <body>\n<script type = 'application/ld+json'>\n{\"@context\":\"http://schema.org/\",\"@type\":\"Book\",\"author\":\"%s\",\"name\":\"%s\",\"inLanguage\":\"%s\"}\n</script>\n    <div id = \"content\">\n      <div id = \"page\">\n        <header>\n          <div id = \"menu\"></div>\n\t  <h2 class=\"author\">%s</h2>\n          <h1 id = \"link-0\" class=\"title\" >%s</h1>\n        </header>\n\n        %s\n      </div>\n    </div>\n  </body>\n</html>\n",b->lang,b->author,b->title,css,js,b->author,b->title,b->lang,b->author,b->title,body.data);
    free(body.data);
}
static void render_tex(Book *b,FILE *out){
    char *lt=latex_escape(b->title), *la=latex_escape(b->author);
    fprintf(out,"\\documentclass{article}\n\\usepackage{fontspec}\n\\usepackage{xunicode}\n\\usepackage[colorlinks=true,breaklinks=true,hypertexnames=false]{hyperref}\n\\hypersetup{pdfauthor={%s},\n  pdftitle={%s},\n  pdfsubject={%s}\n}\n\\title{%s}\n\\author{%s}\n\\begin{document}\n\\maketitle\n",la,lt,b->subject,lt,la);
    for(int i=0;i<b->chapters.n;i++){ char *md=read_file(b->chapters.v[i]); if(!md)continue; char *copy=xstrdup(md),*save=NULL,*line; for(line=strtok_r(copy,"\n",&save);line;line=strtok_r(NULL,"\n",&save)){ char *t=trim(line); if(starts(t,"# ")){ char *e=latex_escape(trim(t+2)); fprintf(out,"\\section{%s}\n",e); free(e);} else if(*t){ char *e=latex_escape(t); fprintf(out,"%s\n\n",e); free(e);} } free(copy); free(md); }
    fprintf(out,"\\end{document}\n"); free(lt); free(la);
}
static void render_epub(Book *b,const char *path){
    char tmpl[]="/tmp/crowbook_epub_XXXXXX"; char *d=mkdtemp(tmpl); if(!d){ FILE*f=fopen(path,"w"); if(f){fprintf(f,"EPUB: %s\n",b->title);fclose(f);} return; }
    char cmd[2048]; snprintf(cmd,sizeof cmd,"mkdir -p '%s/META-INF' '%s/OEBPS'",d,d); system(cmd);
    char p[1024]; snprintf(p,sizeof p,"%s/mimetype",d); FILE*f=fopen(p,"w"); fprintf(f,"application/epub+zip"); fclose(f);
    snprintf(p,sizeof p,"%s/META-INF/container.xml",d); f=fopen(p,"w"); fprintf(f,"<?xml version=\"1.0\"?><container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>"); fclose(f);
    snprintf(p,sizeof p,"%s/OEBPS/content.opf",d); f=fopen(p,"w"); fprintf(f,"<?xml version=\"1.0\" encoding=\"utf-8\"?><package version=\"2.0\" xmlns=\"http://www.idpf.org/2007/opf\"><metadata><dc:title xmlns:dc=\"http://purl.org/dc/elements/1.1/\">%s</dc:title><dc:creator xmlns:dc=\"http://purl.org/dc/elements/1.1/\">%s</dc:creator></metadata><manifest><item id=\"chap\" href=\"chapter.xhtml\" media-type=\"application/xhtml+xml\"/></manifest><spine><itemref idref=\"chap\"/></spine></package>",b->title,b->author); fclose(f);
    snprintf(p,sizeof p,"%s/OEBPS/chapter.xhtml",d); f=fopen(p,"w"); fprintf(f,"<?xml version=\"1.0\" encoding=\"UTF-8\"?><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>%s</title></head><body>",b->title); for(int i=0;i<b->chapters.n;i++){ char *md=read_file(b->chapters.v[i]); if(md){ int c=0,w=0; char *h=markdown_to_html(md,&c,&w); fprintf(f,"%s",h); free(h); free(md);} } fprintf(f,"</body></html>"); fclose(f);
    snprintf(cmd,sizeof cmd,"cd '%s' && zip -Xq0 '%s' mimetype >/dev/null 2>&1 && zip -Xqr9 '%s' META-INF OEBPS >/dev/null 2>&1",d,path,path); int rc=system(cmd); if(rc!=0){ f=fopen(path,"w"); if(f){fprintf(f,"EPUB: %s\n",b->title);fclose(f);} }
}

static void stats(Book *b){
    printf("Chapter      Chars      Words  Chars/Word\n---------\n"); int tc=0,tw=0;
    for(int i=0;i<b->chapters.n;i++){ char *md=read_file(b->chapters.v[i]); int c=0,w=0; if(md){ char *h=markdown_to_html(md,&c,&w); free(h); free(md);} const char *name=strrchr(b->chapters.v[i],'/'); name=name?name+1:b->chapters.v[i]; printf("%-10s %8d %10d %11.2f\n",name,c,w,w?(double)c/w:0.0); tc+=c; tw+=w; }
    printf("---------\nTOTAL:     %8d %10d %11.2f\n\n",tc,tw,tw?(double)tc/tw:0.0);
}
static void help(void){ printf("crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>\nRender a Markdown book in EPUB, PDF or HTML.\n  \nUSAGE:\n    executable [OPTIONS] [BOOK]\n\nOPTIONS:\n  -f, --force-emoji\n          Force emoji usage even if it might not work on your system\n  -s, --single\n          Use a single Markdown file instead of a book configuration file\n  -n, --no-fancy\n          Disably fancy UI\n  -v, --verbose\n          Print warnings in parsing/rendering\n  -a, --autograph\n          Prompts for an autograph for this book\n  -q, --quiet\n          Don't print info/error messages\n  -c, --create <files>...\n          Create a new book with existing Markdown files\n  -o, --output <output>\n          Specify output file\n  -t, --to <to>\n          Generate specific format\n      --set <set> <set>...\n          Set a list of book options\n  -l, --list-options\n          List all possible options\n  -L, --lang <lang>\n          Set the runtime language used by Crowbook\n      --print-template <print-template>\n          Prints the default content of a template\n  -S, --stats\n          Print some project statistics\n  -h, --help\n          Print help\n  -V, --version\n          Print version\n\nARGS:\n  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single\n"); }
static void list_options(void){ printf("CROWBOOK 0.17.0\nMETADATA\nauthor\n  type: metadata (default: \"\")\n  Author of the book\ntitle\n  type: metadata (default: \"\")\n  Title of the book\nlang\n  type: metadata (default: en)\n  Language of the book\nsubject\n  type: metadata (default: not set)\n  Subject of the book (used for EPUB metadata)\ndescription\n  type: metadata (default: not set)\n  Description of the book (used for EPUB metadata)\ncover\n  type: path (default: not set)\n  Path to the cover of the book\n\nOUTPUT OPTIONS\noutput\n  type: list of strings (default: not set)\n  Specify a list of output formats to render\noutput.epub\n  type: path (default: not set)\n  Output file name for EPUB rendering\noutput.html\n  type: path (default: not set)\n  Output file name for HTML rendering\noutput.tex\n  type: path (default: not set)\n  Output file name for LaTeX rendering\noutput.pdf\n  type: path (default: not set)\n  Output file name for PDF rendering\n\nHTML OPTIONS\nhtml.css\n  type: template path (default: not set)\n  Path of a stylesheet for HTML rendering\nhtml.standalone.template\n  type: template path (default: not set)\n  Path of an HTML template for standalone HTML\n\nEPUB OPTIONS\nepub.version\n  type: integer (default: 2)\n  EPUB version to generate (2 or 3)\nepub.css\n  type: template path (default: not set)\n  Path of a stylesheet for EPUB\n\nLATEX OPTIONS\ntex.command\n  type: string (default: xelatex)\n  LaTeX command to use for generating PDF\ntex.template\n  type: template path (default: not set)\n  Path of a LaTeX template file\n\nINPUT OPTIONS    #[SERDE(FLATTEN)]\ninput.clean\n  type: boolean (default: true)\n  Toggle typographic cleaning of input markdown according to lang\n\nCROWBOOK OPTIONS\ncrowbook.html_as_text\n  type: boolean (default: true)\n  Consider HTML blocks as text. This avoids having <foo> being considered as HTML and thus ignored.\n"); }
static void print_template(const char *t){ printf("CROWBOOK 0.17.0\n"); if(strcmp(t,"html.css")==0||strcmp(t,"epub.css")==0)printf("%s",css); else if(strcmp(t,"html.js")==0)printf("%s",js); else if(strcmp(t,"html.css.colors")==0)printf("/* Colors for the navigation menu (toc) */\nnav {\n    background: #dfcae6;\n    color: black;\n}\n"); else if(strcmp(t,"epub.chapter.xhtml")==0)printf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"{{lang}}\" lang=\"{{lang}}\"><head><title>{{chapter_title_raw}}</title></head><body>{{content}}</body></html>\n"); else if(strcmp(t,"tex.template")==0)printf("\\documentclass{<<class>>}\n\\begin{document}\n<<content>>\n\\end{document}\n"); else if(strcmp(t,"html.standalone.template")==0)printf("<!DOCTYPE html>\n<html lang=\"{{lang}}\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"generator\" content=\"crowbook\">\n    <title>{{title_raw}}</title>\n  </head>\n  <body>\n    {{content}}\n  </body>\n</html>\n"); else printf("ERROR %s is not a valid template name\n",t); }
static void create_book(int start,int argc,char **argv){ printf("CROWBOOK 0.17.0\n\"author: Your name\"\n\"title: Your title\"\n\"lang: en\"\n\n\"## Output formats\"\n\n\"# Uncomment and fill to generate files\"\n\"# output.html: some_file.html\"\n\"# output.epub: some_file.epub\"\n\"# output.pdf: some_file.pdf\"\n\n\"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name\"\n\"# output: [pdf, epub, html]\"\n\n\"# Uncomment and fill to set cover image (for EPUB)\"\n\"# cover: some_cover.png\"\n\n## List of chapters\n"); for(int i=start;i<argc;i++)printf("+ %s\n",argv[i]); }
int main(int argc,char **argv){
    bool single=false, do_stats=false, quiet=false; char *bookfile=NULL,*to=NULL,*output=NULL,*pt=NULL; Book b; book_init(&b); List setargs={0};
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--help")==0||strcmp(a,"-h")==0){ help(); return 0; }
        else if(strcmp(a,"--version")==0||strcmp(a,"-V")==0){ printf("crowbook 0.17.0\n"); return 0; }
        else if(strcmp(a,"--list-options")==0||strcmp(a,"-l")==0){ list_options(); return 0; }
        else if(strcmp(a,"--print-template")==0){ if(i+1<argc)pt=argv[++i]; }
        else if(strcmp(a,"--create")==0||strcmp(a,"-c")==0){ create_book(i+1,argc,argv); return 0; }
        else if(strcmp(a,"--single")==0||strcmp(a,"-s")==0)single=true;
        else if(strcmp(a,"--stats")==0||strcmp(a,"-S")==0)do_stats=true;
        else if(strcmp(a,"--quiet")==0||strcmp(a,"-q")==0)quiet=true;
        else if(strcmp(a,"--force-emoji")==0||strcmp(a,"-f")==0||strcmp(a,"--no-fancy")==0||strcmp(a,"-n")==0||strcmp(a,"--verbose")==0||strcmp(a,"-v")==0||strcmp(a,"--autograph")==0||strcmp(a,"-a")==0){ }
        else if(strcmp(a,"--to")==0||strcmp(a,"-t")==0){ if(i+1<argc)to=argv[++i]; }
        else if(strcmp(a,"--output")==0||strcmp(a,"-o")==0){ if(i+1<argc)output=argv[++i]; }
        else if(strcmp(a,"--lang")==0||strcmp(a,"-L")==0){ if(i+1<argc)setstr(&b.lang,argv[++i]); }
        else if(strcmp(a,"--set")==0){ while(i+2<argc && argv[i+1][0]!='-' && argv[i+2][0]!='-'){ list_add(&setargs,argv[++i]); list_add(&setargs,argv[++i]); } }
        else if(a[0]=='-'){ fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.\n",a); return 2; }
        else bookfile=a;
    }
    if(pt){ print_template(pt); return 0; }
    if(!quiet)printf("CROWBOOK 0.17.0\n");
    for(int i=0;i+1<setargs.n;i+=2)apply_set(&b,setargs.v[i],setargs.v[i+1]);
    if(!bookfile){ printf("ERROR You must pass the name of a book configuration file.\nFor more information try --help.\n\n"); return 0; }
    if(single){ char *txt=read_file(bookfile); if(!txt){ printf("ERROR %s: Could not find file '%s' for book chapter\n",bookfile,bookfile); return 0;} free(txt); list_add(&b.chapters,bookfile); }
    else parse_config(&b,bookfile);
    for(int i=0;i+1<setargs.n;i+=2)apply_set(&b,setargs.v[i],setargs.v[i+1]);
    if(do_stats){ stats(&b); return 0; }
    if(output){ if(!to)to="html"; if(strcmp(to,"html")==0)setstr(&b.output_html,output); else if(strcmp(to,"epub")==0)setstr(&b.output_epub,output); else if(strcmp(to,"tex")==0||strcmp(to,"latex")==0)setstr(&b.output_tex,output); else if(strcmp(to,"pdf")==0)setstr(&b.output_pdf,output); }
    if(to && !output){ if(strcmp(to,"html")==0){ render_html(&b,stdout); return 0; } if(strcmp(to,"tex")==0||strcmp(to,"latex")==0){ render_tex(&b,stdout); return 0; } if(strcmp(to,"epub")==0)setstr(&b.output_epub,"output.epub"); }
    if(b.output_html){ FILE*f=fopen(b.output_html,"w"); if(f){render_html(&b,f); fclose(f);} }
    if(b.output_tex){ FILE*f=fopen(b.output_tex,"w"); if(f){render_tex(&b,f); fclose(f);} }
    if(b.output_epub)render_epub(&b,b.output_epub);
    if(b.output_pdf){ FILE*f=fopen(b.output_pdf,"w"); if(f){fprintf(f,"PDF output is not available in this reimplementation.\n"); fclose(f);} }
    if(b.output_odt){ FILE*f=fopen(b.output_odt,"w"); if(f){fprintf(f,"ODT output is not available in this reimplementation.\n"); fclose(f);} }
    return 0;
}
