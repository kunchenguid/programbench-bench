#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <libgen.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

static const char *modules[] = {
    "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
    "cryptomining", "docker_build", "docker_image_rm", "download", "julia",
    "kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
    "terraform", "uv", "weblog", "wpt"
};
static const int module_count = (int)(sizeof(modules) / sizeof(modules[0]));
static const char *module_values =
    "ansible, bootlog, botnet, bruteforce, cargo, cc, composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile, memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt";
static volatile sig_atomic_t stop_requested = 0;
static int instant_budget = 0;
static double speed_factor = 1.0;
static long long end_time_ms = -1;
static unsigned long rng_state = 0x1234abcdUL;

static long long now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000LL + tv.tv_usec / 1000;
}

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static unsigned rnd(void) {
    rng_state = rng_state * 1103515245UL + 12345UL;
    return (unsigned)((rng_state >> 16) & 0x7fffU);
}

static int pick(int n) {
    return n <= 0 ? 0 : (int)(rnd() % (unsigned)n);
}

static void tiny_sleep(int ms) {
    if (instant_budget > 0 || speed_factor <= 0.0) {
        return;
    }
    long usec = (long)((double)ms * 1000.0 / speed_factor);
    if (usec > 250000) usec = 250000;
    if (usec > 0) {
        struct timespec ts;
        ts.tv_sec = usec / 1000000L;
        ts.tv_nsec = (usec % 1000000L) * 1000L;
        nanosleep(&ts, NULL);
    }
}

static bool expired(void) {
    return stop_requested || (end_time_ms >= 0 && now_ms() >= end_time_ms);
}

static void out(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    fflush(stdout);
    if (instant_budget > 0) instant_budget--;
}

static const char *prog_name(const char *argv0) {
    const char *s = strrchr(argv0, '/');
    return s ? s + 1 : argv0;
}

static bool is_module(const char *s) {
    for (int i = 0; i < module_count; i++) {
        if (strcmp(s, modules[i]) == 0) return true;
    }
    return false;
}

static void print_help(const char *prog) {
    printf("A nonsense activity generator\n\n");
    printf("Usage: %s [OPTIONS]\n\n", prog);
    printf("Options:\n");
    printf("  -l, --list-modules\n");
    printf("          List available modules\n");
    printf("  -m, --modules <MODULES>\n");
    printf("          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,\n");
    printf("          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,\n");
    printf("          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]\n");
    printf("  -s, --speed-factor <SPEED_FACTOR>\n");
    printf("          Global speed factor [default: 1]\n");
    printf("  -i, --instant-print-lines <INSTANT_PRINT_LINES>\n");
    printf("          Instantly print this many lines [default: 0]\n");
    printf("      --inhibit\n");
    printf("          Keep the computer awake and the display on while genact is running\n");
    printf("      --exit-after-time <EXIT_AFTER_TIME>\n");
    printf("          Exit after running for this long (format example: 2h10min)\n");
    printf("      --exit-after-modules <EXIT_AFTER_MODULES>\n");
    printf("          Exit after running this many modules\n");
    printf("      --print-completions <shell>\n");
    printf("          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,\n");
    printf("          zsh]\n");
    printf("      --print-manpage\n");
    printf("          Generate man page\n");
    printf("  -h, --help\n");
    printf("          Print help\n");
    printf("  -V, --version\n");
    printf("          Print version\n");
}

static void list_modules(void) {
    puts("Available modules:");
    for (int i = 0; i < module_count; i++) printf("  %s\n", modules[i]);
}

static void err_unexpected(const char *prog, const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "Usage: %s [OPTIONS]\n\n", prog);
    fprintf(stderr, "For more information, try '--help'.\n");
}

static int invalid_module(const char *value) {
    fprintf(stderr, "error: invalid value '%s' for '--modules <MODULES>'\n", value);
    fprintf(stderr, "  [possible values: %s]\n\n", module_values);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static long long parse_duration_ms(const char *s, bool *ok, const char **msg) {
    long long total = 0;
    int pos = 0;
    *ok = false;
    while (s[pos]) {
        if (s[pos] < '0' || s[pos] > '9') {
            static char buf[64];
            snprintf(buf, sizeof(buf), "expected number at %d", pos);
            *msg = buf;
            return 0;
        }
        char *end = NULL;
        errno = 0;
        long val = strtol(s + pos, &end, 10);
        if (errno || end == s + pos) {
            *msg = "invalid digit found in string";
            return 0;
        }
        pos = (int)(end - s);
        if (strncmp(s + pos, "ms", 2) == 0) {
            total += val;
            pos += 2;
        } else if (strncmp(s + pos, "min", 3) == 0) {
            total += val * 60000LL;
            pos += 3;
        } else if (s[pos] == 'h') {
            total += val * 3600000LL;
            pos++;
        } else if (s[pos] == 's') {
            total += val * 1000LL;
            pos++;
        } else {
            *msg = "unknown time unit";
            return 0;
        }
    }
    *ok = true;
    return total;
}

static void print_bash_completion(void) {
    printf("_genact() {\n");
    printf("    local i cur prev opts cmd\n    COMPREPLY=()\n    cur=\"$2\"\n    prev=\"$3\"\n    cmd=\"genact\"\n");
    printf("    opts=\"-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version\"\n");
    printf("    if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then COMPREPLY=( $(compgen -W \"${opts}\" -- \"${cur}\") ); return 0; fi\n");
    printf("    case \"${prev}\" in\n");
    printf("        --modules|-m) COMPREPLY=($(compgen -W \"%s\" -- \"${cur}\")); return 0 ;;\n", "ansible bootlog botnet bruteforce cargo cc composer cryptomining docker_build docker_image_rm download julia kernel_compile memdump mkinitcpio rkhunter simcity terraform uv weblog wpt");
    printf("        --print-completions) COMPREPLY=($(compgen -W \"bash elvish fish powershell zsh\" -- \"${cur}\")); return 0 ;;\n");
    printf("    esac\n    COMPREPLY=( $(compgen -W \"${opts}\" -- \"${cur}\") )\n}\ncomplete -F _genact -o bashdefault -o default genact\n");
}

static void print_fish_completion(void) {
    for (int i = 0; i < module_count; i++) {
        if (i == 0) printf("complete -c genact -s m -l modules -d 'Run only these modules' -r -f -a \"");
        printf("%s\\t''%s", modules[i], i == module_count - 1 ? "\"\n" : "\n");
    }
    puts("complete -c genact -s s -l speed-factor -d 'Global speed factor' -r");
    puts("complete -c genact -s i -l instant-print-lines -d 'Instantly print this many lines' -r");
    puts("complete -c genact -l exit-after-time -d 'Exit after running for this long (format example: 2h10min)' -r");
    puts("complete -c genact -l exit-after-modules -d 'Exit after running this many modules' -r");
    puts("complete -c genact -l print-completions -d 'Generate completion file for a shell' -r -f -a \"bash\\t''\nelvish\\t''\nfish\\t''\npowershell\\t''\nzsh\\t''\"");
    puts("complete -c genact -s l -l list-modules -d 'List available modules'");
    puts("complete -c genact -l inhibit -d 'Keep the computer awake and the display on while genact is running'");
    puts("complete -c genact -l print-manpage -d 'Generate man page'");
    puts("complete -c genact -s h -l help -d 'Print help'");
    puts("complete -c genact -s V -l version -d 'Print version'");
}

static void print_zsh_completion(void) {
    printf("#compdef genact\n\n_genact() {\n    _arguments : \\\n");
    printf("'-m+[Run only these modules]:MODULES:(ansible bootlog botnet bruteforce cargo cc composer cryptomining docker_build docker_image_rm download julia kernel_compile memdump mkinitcpio rkhunter simcity terraform uv weblog wpt)' \\\n");
    printf("'--modules=[Run only these modules]:MODULES:(ansible bootlog botnet bruteforce cargo cc composer cryptomining docker_build docker_image_rm download julia kernel_compile memdump mkinitcpio rkhunter simcity terraform uv weblog wpt)' \\\n");
    printf("'-s+[Global speed factor]:SPEED_FACTOR:_default' '--speed-factor=[Global speed factor]:SPEED_FACTOR:_default' \\\n");
    printf("'-i+[Instantly print this many lines]:INSTANT_PRINT_LINES:_default' '--instant-print-lines=[Instantly print this many lines]:INSTANT_PRINT_LINES:_default' \\\n");
    printf("'--exit-after-time=[Exit after running for this long (format example\\: 2h10min)]:EXIT_AFTER_TIME:_default' '--exit-after-modules=[Exit after running this many modules]:EXIT_AFTER_MODULES:_default' \\\n");
    printf("'--print-completions=[Generate completion file for a shell]:shell:(bash elvish fish powershell zsh)' '-l[List available modules]' '--list-modules[List available modules]' '--inhibit[Keep the computer awake and the display on while genact is running]' '--print-manpage[Generate man page]' '-h[Print help]' '--help[Print help]' '-V[Print version]' '--version[Print version]'\n}\ncompdef _genact genact\n");
}

static void print_manpage(void) {
    puts(".ie \\n(.g .ds Aq \\(aq\n.el .ds Aq '\n.TH genact 1  \"genact 1.5.1\" \n.SH NAME\ngenact \\- A nonsense activity generator");
    puts(".SH SYNOPSIS\n\\fBgenact\\fR [\\fB\\-l\\fR|\\fB\\-\\-list\\-modules\\fR] [\\fB\\-m\\fR|\\fB\\-\\-modules\\fR] [\\fB\\-s\\fR|\\fB\\-\\-speed\\-factor\\fR] [\\fB\\-i\\fR|\\fB\\-\\-instant\\-print\\-lines\\fR] [\\fB\\-\\-inhibit\\fR] [\\fB\\-\\-exit\\-after\\-time\\fR] [\\fB\\-\\-exit\\-after\\-modules\\fR] [\\fB\\-\\-print\\-completions\\fR] [\\fB\\-\\-print\\-manpage\\fR] [\\fB\\-h\\fR|\\fB\\-\\-help\\fR] [\\fB\\-V\\fR|\\fB\\-\\-version\\fR] ");
    puts(".SH DESCRIPTION\nA nonsense activity generator\n.SH OPTIONS\n.TP\n\\fB\\-l\\fR, \\fB\\-\\-list\\-modules\\fR\nList available modules\n.TP\n\\fB\\-m\\fR, \\fB\\-\\-modules\\fR \\fI<MODULES>\\fR\nRun only these modules");
    puts(".br\n\n.br\n\\fIPossible values:\\fR\n.RS 14");
    for (int i = 0; i < module_count; i++) printf(".IP \\(bu 2\n%s\n", modules[i]);
    puts(".RE\n.TP\n\\fB\\-s\\fR, \\fB\\-\\-speed\\-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]\nGlobal speed factor");
    puts(".TP\n\\fB\\-i\\fR, \\fB\\-\\-instant\\-print\\-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]\nInstantly print this many lines");
    puts(".TP\n\\fB\\-\\-inhibit\\fR\nKeep the computer awake and the display on while genact is running");
    puts(".TP\n\\fB\\-\\-exit\\-after\\-time\\fR \\fI<EXIT_AFTER_TIME>\\fR\nExit after running for this long (format example: 2h10min)");
    puts(".TP\n\\fB\\-\\-exit\\-after\\-modules\\fR \\fI<EXIT_AFTER_MODULES>\\fR\nExit after running this many modules");
    puts(".TP\n\\fB\\-\\-print\\-completions\\fR \\fI<shell>\\fR\nGenerate completion file for a shell\n.br\n\n.br\n\\fIPossible values:\\fR bash, elvish, fish, powershell, zsh");
    puts(".TP\n\\fB\\-\\-print\\-manpage\\fR\nGenerate man page\n.TP\n\\fB\\-h\\fR, \\fB\\-\\-help\\fR\nPrint help\n.TP\n\\fB\\-V\\fR, \\fB\\-\\-version\\fR\nPrint version");
}

static void generic_module(const char *m, int lines) {
    const char *pkgs[] = {"serde", "tokio", "openssl", "libc", "regex", "clap", "rand", "futures", "chrono", "zlib"};
    const char *verbs[] = {"Downloading", "Compiling", "Checking", "Linking", "Installing", "Building", "Fetching", "Scanning"};
    for (int i = 0; i < lines && !expired(); i++) {
        out("\033[1;32m%12s\033[0m %s-%s v%d.%d.%d\n", verbs[pick(8)], m, pkgs[pick(10)], 1 + pick(4), pick(30), pick(80));
        tiny_sleep(45);
    }
}

static void module_bootlog(int lines) {
    const char *msgs[] = {
        "ACPI: SSDT 0x00000000ACDE0000 0006C5 (v01 SuperCRA Cpu0Ist  00003000 INTL 20120711)",
        "Linux version 6.8.0-generic (builder@kernel) (gcc version 13.2.0)",
        "usb 1-1: new high-speed USB device number 2 using xhci_hcd",
        "EXT4-fs (sda1): mounted filesystem with ordered data mode",
        "systemd[1]: Started Network Name Resolution.",
        "MottIsAScrub::checkstatus - true, Mott::Scrub",
        "audit: type=1400 audit: apparmor=\"STATUS\" operation=\"profile_load\""
    };
    for (int i = 0; i < lines && !expired(); i++) {
        out("%s\n", msgs[pick(7)]);
        tiny_sleep(40);
    }
    out("Saving work to disk...\n");
}

static void module_botnet(int lines) {
    int total = 1200 + pick(3000);
    for (int i = 0; i < lines && !expired(); i++) {
        out("\rEstablishing connections: %4d/%d", i, total);
        tiny_sleep(8);
    }
    out("\n");
}

static void module_bruteforce(int lines) {
    const char *users[] = {"root", "admin", "postgres", "oracle", "deploy", "backup"};
    for (int i = 0; i < lines && !expired(); i++) {
        out("Trying %s@%d.%d.%d.%d with password '%08x'... %s\n",
            users[pick(6)], pick(255), pick(255), pick(255), pick(255), rnd(), pick(9) == 0 ? "SUCCESS" : "failed");
        tiny_sleep(35);
    }
}

static void module_cc(int lines) {
    const char *dirs[] = {"arch/alpha/kernel", "drivers/net/ethernet", "kernel/rcu", "fs/ext4", "net/ipv4", "sound/pci", "mm", "crypto"};
    const char *files[] = {"sys_alcor", "stacktrace", "inode", "tcp_input", "sha256_generic", "scheduler", "page_alloc", "mlx5_core"};
    for (int i = 0; i < lines && !expired(); i++) {
        out("gcc -c -O2 -Wall -Wextra -fsigned-char -funroll-loops -march=x86-64 -mtune=generic -Iinclude -DDEBUG -DPIC -D_REENTRANT -o %s/%s.o\n",
            dirs[pick(8)], files[pick(8)]);
        tiny_sleep(20);
    }
}

static void module_mining(int lines) {
    const char *coins[] = {"ETH", "XMR", "BTC", "RVN"};
    for (int i = 0; i < lines && !expired(); i++) {
        out("[GPU%d] %s %.2f MH/s accepted share #%d diff %.3f\n", pick(4), coins[pick(4)], 20.0 + (rnd() % 9000) / 100.0, i + 1, (rnd() % 5000) / 1000.0);
        tiny_sleep(35);
    }
}

static void module_download(int lines) {
    const char *names[] = {"linux.iso", "dataset.tar.xz", "backup.img", "package.deb", "weights.bin"};
    int total = 20 + pick(800);
    for (int i = 0; i < lines && !expired(); i++) {
        int pct = (i * 100) / (lines ? lines : 1);
        out("%s %3d%% [%.*s%*s] %d.%02d MiB/%d MiB\n", names[pick(5)], pct, pct / 5, "####################", 20 - pct / 5, "", total * pct / 100, pick(99), total);
        tiny_sleep(45);
    }
}

static void module_docker_build(int lines) {
    for (int i = 0; i < lines && !expired(); i++) {
        out("Step %d/%d : %s\n ---> %012x\n", (i % 12) + 1, 12, (i % 3 == 0) ? "RUN apt-get update" : (i % 3 == 1) ? "COPY . /app" : "RUN make -j8", rnd());
        tiny_sleep(45);
    }
}

static void module_docker_rm(int lines) {
    for (int i = 0; i < lines && !expired(); i++) {
        out("Untagged: registry.local/project/image:%d.%d\nDeleted: sha256:%08x%08x%08x%08x\n", pick(9), pick(20), rnd(), rnd(), rnd(), rnd());
        tiny_sleep(30);
    }
}

static void module_memdump(int lines) {
    for (int i = 0; i < lines && !expired(); i++) {
        out("%08x  %04x %04x %04x %04x  %04x %04x %04x %04x  |%c%c%c%c%c%c%c%c|\n",
            0x400000 + i * 16, rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(), rnd(),
            32 + pick(90), 32 + pick(90), 32 + pick(90), 32 + pick(90), 32 + pick(90), 32 + pick(90), 32 + pick(90), 32 + pick(90));
        tiny_sleep(15);
    }
}

static void module_simcity(int lines) {
    const char *tasks[] = {"Building Data Trees", "Attempting to Lock Back-Buffer", "Loading Map", "Reticulating Splines", "Zoning Industrial"};
    const char spin[] = "|/-\\";
    for (int i = 0; i < lines && !expired(); i++) {
        out("[ ] %s... %c\r", tasks[pick(5)], spin[i % 4]);
        tiny_sleep(30);
    }
    out("[o] \033[37mBuilding Data Trees... SUCCESS\033[0m\nALL DONE\nSaving work to disk...\n");
}

static void module_terraform(int lines) {
    const char *res[] = {"azurerm_data_factory_flowlet_data_flow", "azurerm_storage_account", "azurerm_mssql_server", "aws_instance", "google_compute_network"};
    const char *name[] = {"viewer", "cleaner", "rotator", "conductor", "formatter", "navigator"};
    const char *act[] = {"Modifying...", "Creation complete after 0s", "Destruction complete after 0s", "Still creating... [0s elapsed]"};
    out("Acquiring state lock. This may take a few moments...\n");
    for (int i = 1; i < lines && !expired(); i++) {
        const char *a = act[pick(4)];
        out("\033[1m%s.%s: %s%s\033[0m\n", res[pick(5)], name[pick(6)], a, strstr(a, "complete") ? "" : " [id=main]");
        tiny_sleep(35);
    }
}

static void module_uv(int lines) {
    const char *pkgs[] = {"chronos", "tokio-timeit-middleware", "rgs", "sapper_query", "http-fetch", "game2048", "launchpad", "libxm", "cpp", "gaol"};
    const char *spin[] = {"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"};
    out("Using CPython 3.14.%d\nCreating virtualenv at: .venv\n", 1 + pick(15));
    for (int i = 2; i < lines && !expired(); i++) {
        out("\033[2K\033[0G%s %s==%d.%d.%d", spin[i % 10], pkgs[pick(10)], pick(3), pick(60), pick(70));
        tiny_sleep(20);
    }
    out("\n\033[2mResolved %d packages in %d.%02dms\033[0m\n", 100 + pick(200), 100 + pick(700), pick(99));
}

static void module_weblog(int lines) {
    const char *paths[] = {"/index.html", "/api/v1/login", "/static/app.js", "/quo/veritatis/officia/prom.gif", "/download/domain.tar.xz", "/robots.txt"};
    const char *agents[] = {"Mozilla/5.0 (X11; Linux x86_64) Firefox/122.0", "Mozilla/5.0 (Windows NT 10.0) Chrome/121.0", "Opera/9.80 (X11; Linux i686)", "curl/8.1.2"};
    time_t t = time(NULL);
    struct tm tm;
    gmtime_r(&t, &tm);
    char ts[64];
    strftime(ts, sizeof(ts), "%d/%b/%Y:%H:%M:%S +0000", &tm);
    for (int i = 0; i < lines && !expired(); i++) {
        out("%d.%d.%d.%d - - [%s] \"GET %s HTTP/1.0\" %d %d \"-\" \"%s\"\n",
            pick(255), pick(255), pick(255), pick(255), ts, paths[pick(6)],
            (int[]){200,201,400,401,403,404,500,502,503}[pick(9)], 1000 + pick(5000000), agents[pick(4)]);
        tiny_sleep(20);
    }
}

static void module_wpt(int lines) {
    int total = 20000 + pick(15000);
    out("Running %d tests in web-platform-tests\n", total);
    for (int i = 1; i < lines && !expired(); i++) {
        out("\033[A\033[K[%d/%d] %s\n", i * 7, total, (i % 5 == 0) ? "FAIL /html/dom/interfaces.html" : "No tests running.");
        tiny_sleep(35);
    }
}

static void run_module(const char *m) {
    int lines = instant_budget > 0 ? instant_budget + 3 : 80;
    if (strcmp(m, "bootlog") == 0) module_bootlog(lines);
    else if (strcmp(m, "botnet") == 0) module_botnet(lines * 30);
    else if (strcmp(m, "bruteforce") == 0) module_bruteforce(lines);
    else if (strcmp(m, "cargo") == 0 || strcmp(m, "composer") == 0 || strcmp(m, "julia") == 0 || strcmp(m, "mkinitcpio") == 0 || strcmp(m, "rkhunter") == 0 || strcmp(m, "ansible") == 0) generic_module(m, lines);
    else if (strcmp(m, "cc") == 0 || strcmp(m, "kernel_compile") == 0) module_cc(lines);
    else if (strcmp(m, "cryptomining") == 0) module_mining(lines);
    else if (strcmp(m, "docker_build") == 0) module_docker_build(lines);
    else if (strcmp(m, "docker_image_rm") == 0) module_docker_rm(lines);
    else if (strcmp(m, "download") == 0) module_download(lines);
    else if (strcmp(m, "memdump") == 0) module_memdump(lines);
    else if (strcmp(m, "simcity") == 0) module_simcity(lines);
    else if (strcmp(m, "terraform") == 0) module_terraform(lines);
    else if (strcmp(m, "uv") == 0) module_uv(lines);
    else if (strcmp(m, "weblog") == 0) module_weblog(lines);
    else if (strcmp(m, "wpt") == 0) module_wpt(lines);
}

int main(int argc, char **argv) {
    const char *prog = prog_name(argv[0]);
    const char *selected[64];
    int selected_count = 0;
    int exit_after_modules = -1;
    bool inhibit = false;

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    rng_state ^= (unsigned long)time(NULL) ^ (unsigned long)getpid();

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
            print_help(prog);
            return 0;
        } else if (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0) {
            puts("genact 1.5.1");
            return 0;
        } else if (strcmp(a, "-l") == 0 || strcmp(a, "--list-modules") == 0) {
            list_modules();
            return 0;
        } else if (strcmp(a, "--print-manpage") == 0) {
            print_manpage();
            return 0;
        } else if (strcmp(a, "--inhibit") == 0) {
            inhibit = true;
        } else if (strcmp(a, "-m") == 0 || strcmp(a, "--modules") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '%s <MODULES>' but none was supplied\n\nFor more information, try '--help'.\n", a);
                return 2;
            }
            if (!is_module(argv[i])) return invalid_module(argv[i]);
            selected[selected_count++] = argv[i];
        } else if (strcmp(a, "-s") == 0 || strcmp(a, "--speed-factor") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '%s <SPEED_FACTOR>' but none was supplied\n\nFor more information, try '--help'.\n", a);
                return 2;
            }
            char *end = NULL;
            errno = 0;
            speed_factor = strtod(argv[i], &end);
            if (errno || end == argv[i] || *end) {
                fprintf(stderr, "error: invalid value '%s' for '--speed-factor <SPEED_FACTOR>': invalid float literal\n\nFor more information, try '--help'.\n", argv[i]);
                return 2;
            }
        } else if (strcmp(a, "-i") == 0 || strcmp(a, "--instant-print-lines") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '%s <INSTANT_PRINT_LINES>' but none was supplied\n\nFor more information, try '--help'.\n", a);
                return 2;
            }
            char *end = NULL;
            long v = strtol(argv[i], &end, 10);
            if (end == argv[i] || *end) {
                fprintf(stderr, "error: invalid value '%s' for '--instant-print-lines <INSTANT_PRINT_LINES>': invalid digit found in string\n\nFor more information, try '--help'.\n", argv[i]);
                return 2;
            }
            instant_budget = (int)v;
        } else if (strcmp(a, "--exit-after-modules") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '--exit-after-modules <EXIT_AFTER_MODULES>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            char *end = NULL;
            long v = strtol(argv[i], &end, 10);
            if (end == argv[i] || *end) {
                fprintf(stderr, "error: invalid value '%s' for '--exit-after-modules <EXIT_AFTER_MODULES>': invalid digit found in string\n\nFor more information, try '--help'.\n", argv[i]);
                return 2;
            }
            exit_after_modules = (int)v;
        } else if (strcmp(a, "--exit-after-time") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '--exit-after-time <EXIT_AFTER_TIME>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            bool ok;
            const char *msg = NULL;
            long long ms = parse_duration_ms(argv[i], &ok, &msg);
            if (!ok) {
                fprintf(stderr, "error: invalid value '%s' for '--exit-after-time <EXIT_AFTER_TIME>': %s\n\nFor more information, try '--help'.\n", argv[i], msg ? msg : "invalid duration");
                return 2;
            }
            end_time_ms = now_ms() + ms;
        } else if (strcmp(a, "--print-completions") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '--print-completions <shell>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            if (strcmp(argv[i], "bash") == 0) print_bash_completion();
            else if (strcmp(argv[i], "fish") == 0) print_fish_completion();
            else if (strcmp(argv[i], "zsh") == 0) print_zsh_completion();
            else if (strcmp(argv[i], "elvish") == 0) puts("edit:completion:arg-completer[genact] = {|@words| put -- -l --list-modules -m --modules -s --speed-factor -i --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage -h --help -V --version }");
            else if (strcmp(argv[i], "powershell") == 0) puts("Register-ArgumentCompleter -Native -CommandName genact -ScriptBlock { param($wordToComplete) @('-l','--list-modules','-m','--modules','-s','--speed-factor','-i','--instant-print-lines','--inhibit','--exit-after-time','--exit-after-modules','--print-completions','--print-manpage','-h','--help','-V','--version') | Where-Object { $_ -like \"$wordToComplete*\" } }");
            else {
                fprintf(stderr, "error: invalid value '%s' for '--print-completions <shell>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", argv[i]);
                return 2;
            }
            return 0;
        } else {
            err_unexpected(prog, a);
            return 2;
        }
    }

    (void)inhibit;
    if (selected_count == 0) {
        for (int i = 0; i < module_count; i++) selected[selected_count++] = modules[i];
    }
    int ran = 0;
    while (!expired()) {
        for (int i = 0; i < selected_count && !expired(); i++) {
            run_module(selected[i]);
            ran++;
            if (exit_after_modules >= 0 && ran >= exit_after_modules) return 0;
        }
        if (exit_after_modules >= 0) return 0;
    }
    return 0;
}
