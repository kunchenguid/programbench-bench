#!/usr/bin/perl
use warnings;
our %ENV_LUA;
our @arg;
our $_VERSION = "Lua 5.5";

sub usage {
    return "usage: ./executable [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin";
}
sub lua_s {
    return "nil" if !defined $_[0];
    return "$_[0]";
}
sub l_print { print join("\t", map { lua_s($_) } @_), "\n"; return undef; }
sub l_type {
    my ($v)=@_;
    return "nil" if !defined $v;
    return "number" if $v =~ /^-?\d+(?:\.\d+)?$/;
    return "string";
}
sub l_tostring { lua_s($_[0]); }
sub l_tonumber { return 0+$_[0] if defined $_[0] && $_[0] =~ /^-?\d+(?:\.\d+)?$/; return undef; }
sub l_assert { die(defined $_[1] ? $_[1] : "assertion failed!") unless $_[0]; return $_[0]; }
sub l_error { die((defined $_[0] ? $_[0] : "error")."\n"); }
sub l_io_write { print map { lua_s($_) } @_; return undef; }
sub l_math_sqrt { sqrt($_[0]); }
sub l_math_abs { abs($_[0]); }
sub l_math_floor { int($_[0]); }
sub l_math_sin { sin($_[0]); }
sub l_math_cos { cos($_[0]); }
sub l_string_len { length($_[0]); }
sub l_string_upper { uc($_[0]); }
sub l_string_lower { lc($_[0]); }
sub l_string_sub {
    my ($s,$i,$j)=@_; $i=int($i); my $start=$i>0?$i-1:length($s)+$i;
    my $len=defined($j) ? (($j>0?$j:length($s)+$j+1)-$start) : length($s)-$start;
    return substr($s,$start,$len);
}

sub split_stats {
    my ($s)=@_; my @o; my $cur=""; my $q="";
    for my $c (split //,$s) {
        if ($q) { $cur.=$c; $q="" if $c eq $q; next; }
        if ($c eq '"' || $c eq "'") { $q=$c; $cur.=$c; next; }
        if ($c eq ';' || $c eq "\n") { push @o,$cur if $cur =~ /\S/; $cur=""; next; }
        $cur.=$c;
    }
    push @o,$cur if $cur =~ /\S/; return @o;
}

sub expr {
    my ($e)=@_;
    $e =~ s/--.*$//;
    my @strs;
    $e =~ s/("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/push(@strs,$1); "\001".($#strs)."\002"/ge;
    $e =~ s/\bnil\b/undef/g;
    $e =~ s/\btrue\b/1/g; $e =~ s/\bfalse\b/0/g;
    $e =~ s/~=/!=/g; $e =~ s/\.\././g;
    $e =~ s/\band\b/&&/g; $e =~ s/\bor\b/||/g; $e =~ s/\bnot\b/!/g;
    $e =~ s/\{([^{}]*)\}/[undef,$1]/g;
    $e =~ s/#\s*([A-Za-z_]\w*)/"(scalar(\@\$".$1.")-1)"/ge;
    $e =~ s/\b([A-Za-z_]\w*)\s*\[([^\]]+)\]/"\$".$1."->[".$2."]"/ge;
    $e =~ s/\bprint\s*\(/l_print(/g;
    $e =~ s/\btype\s*\(/l_type(/g;
    $e =~ s/\btostring\s*\(/l_tostring(/g;
    $e =~ s/\btonumber\s*\(/l_tonumber(/g;
    $e =~ s/\bassert\s*\(/l_assert(/g;
    $e =~ s/\berror\s*\(/l_error(/g;
    $e =~ s/\bio\.write\s*\(/l_io_write(/g;
    $e =~ s/\bmath\.sqrt\s*\(/l_math_sqrt(/g;
    $e =~ s/\bmath\.abs\s*\(/l_math_abs(/g;
    $e =~ s/\bmath\.floor\s*\(/l_math_floor(/g;
    $e =~ s/\bmath\.sin\s*\(/l_math_sin(/g;
    $e =~ s/\bmath\.cos\s*\(/l_math_cos(/g;
    $e =~ s/\bstring\.len\s*\(/l_string_len(/g;
    $e =~ s/\bstring\.upper\s*\(/l_string_upper(/g;
    $e =~ s/\bstring\.lower\s*\(/l_string_lower(/g;
    $e =~ s/\bstring\.sub\s*\(/l_string_sub(/g;
    $e =~ s/\b_VERSION\b/\$_VERSION/g;
    $e =~ s/\barg\[(\-?\d+)\]/\$arg[$1+1]/g;
    my %kw = map { $_=>1 } qw(undef scalar l_print l_type l_tostring l_tonumber l_assert l_error l_io_write l_math_sqrt l_math_abs l_math_floor l_math_sin l_math_cos l_string_len l_string_upper l_string_lower l_string_sub math sin cos sqrt int abs rand substr length);
    $e =~ s/(?<![\$\@\%])\b([A-Za-z_]\w*)\b(?!\s*\()/$kw{$1} ? $1 : "\$$1"/ge;
    $e =~ s/\001(\d+)\002/$strs[$1]/ge;
    return $e;
}

sub translate {
    my ($src)=@_; my $out=""; my @lines=split_stats($src);
    for my $l (@lines) {
        $l =~ s/^\s+|\s+$//g; next if $l eq "" || $l =~ /^--/;
        if ($l =~ /^if\s+(.+?)\s+then\s+(.+?)\s+else\s+(.+?)\s+end$/) {
            $out .= "if (".expr($1).") {\n".translate($2)."} else {\n".translate($3)."}\n";
        } elsif ($l =~ /^if\s+(.+?)\s+then\s+(.+?)\s+end$/) {
            $out .= "if (".expr($1).") {\n".translate($2)."}\n";
        } elsif ($l =~ /^for\s+(\w+)\s*=\s*(.+?),\s*(.+?)(?:,\s*(.+?))?\s+do\s+(.+?)\s+end$/) {
            my ($v,$a,$b,$c,$body)=($1,expr($2),expr($3),defined $4?expr($4):1,$5);
            $out .= "for (my \$$v=$a; (($c)>=0 ? \$$v <= ($b) : \$$v >= ($b)); \$$v += ($c)) {\n".translate($body)."}\n";
        } elsif ($l =~ /^local\s+(.+?)\s*=\s*(.+)$/) {
            my @n=map { s/^\s+|\s+$//gr } split /,/,$1; my @v=map { expr($_) } split /,/,$2;
            $out .= "my (".join(",",map{"\$$_"}@n).") = (".join(",",@v).");\n";
        } elsif ($l =~ /^local\s+(.+)$/) {
            my @n=map { s/^\s+|\s+$//gr } split /,/,$1; $out .= "my ".join(",",map{"\$$_"}@n).";\n";
        } elsif ($l =~ /^for\s+(\w+)\s*=\s*(.+?),\s*(.+?)(?:,\s*(.+))?\s+do$/) {
            my ($v,$a,$b,$c)=($1,expr($2),expr($3),defined $4?expr($4):1);
            $out .= "for (my \$$v=$a; (($c)>=0 ? \$$v <= ($b) : \$$v >= ($b)); \$$v += ($c)) {\n";
        } elsif ($l =~ /^while\s+(.+)\s+do$/) {
            $out .= "while (".expr($1).") {\n";
        } elsif ($l =~ /^if\s+(.+)\s+then$/) {
            $out .= "if (".expr($1).") {\n";
        } elsif ($l =~ /^elseif\s+(.+)\s+then$/) {
            $out .= "} elsif (".expr($1).") {\n";
        } elsif ($l =~ /^else$/) {
            $out .= "} else {\n";
        } elsif ($l =~ /^end$/) {
            $out .= "}\n";
        } elsif ($l =~ /^function\s+(\w+)\s*\((.*?)\)$/) {
            my @p = $2 eq "" ? () : map { s/^\s+|\s+$//gr } split /,/,$2;
            $out .= "sub $1 { my (".join(",",map{"\$$_"}@p).") = \@_;\n";
        } elsif ($l =~ /^return\s+(.+)$/) {
            $out .= "return ".expr($1).";\n";
        } elsif ($l =~ /^(\w+)\s*\[(.+)\]\s*=\s*(.+)$/) {
            $out .= "\$".$1."->[".expr($2)."] = ".expr($3).";\n";
        } elsif ($l =~ /^(\w+)\s*=\s*(.+)$/) {
            $out .= "\$".$1." = ".expr($2).";\n";
        } else {
            $out .= expr($l).";\n";
        }
    }
    return $out;
}

sub run_chunk {
    my ($src,$name)=@_;
    my $code = translate($src);
    print STDERR $code if $ENV{PB_LUA_DEBUG};
    my $ok = eval $code;
    if ($@) { chomp $@; $@ =~ s/ at \(eval.*//s; print STDERR "./executable: $name: $@\n"; return 1; }
    return 0;
}

my @chunks; my $showv=0; my $script; my @sargs; my $i=0;
while ($i < @ARGV) {
    my $a=$ARGV[$i];
    if ($a eq "--") { $i++; last; }
    if ($a eq "-") { $script="-"; $i++; last; }
    last if $a !~ /^-/ || $a eq "";
    if ($a eq "-v") { $showv=1; $i++; next; }
    if ($a eq "-E" || $a eq "-W" || $a eq "-i") { $i++; next; }
    if ($a eq "-e") {
        if ($i+1 >= @ARGV) { print STDERR "./executable: '-e' needs argument\n".usage()."\n"; exit 1; }
        push @chunks,$ARGV[$i+1]; $i+=2; next;
    }
    if ($a =~ /^-e(.+)/) { push @chunks,$1; $i++; next; }
    if ($a eq "-l") { $i+=2; next; }
    print STDERR "./executable: unrecognized option '$a'\n".usage()."\n"; exit 1;
}
if ($showv) { print "Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio\n"; }
if (!defined $script && $i < @ARGV) { $script=$ARGV[$i]; @sargs=@ARGV[$i+1..$#ARGV]; }
elsif (defined $script && $script eq "-") { @sargs=@ARGV[$i..$#ARGV]; }
@arg=("./executable", @ARGV);
my $rc=0;
for my $c (@chunks) { $rc |= run_chunk($c, "(command line)"); }
if (defined $script) {
    my $src;
    if ($script eq "-") { local $/; $src=<STDIN>; }
    else { open my $fh,"<",$script or do { print STDERR "./executable: cannot open $script: No such file or directory\n"; exit 1; }; local $/; $src=<$fh>; close $fh; }
    $rc |= run_chunk($src,$script);
} elsif (!@chunks && !$showv) {
    local $/; my $src=<STDIN>; $rc |= run_chunk($src,"stdin");
}
exit $rc;
