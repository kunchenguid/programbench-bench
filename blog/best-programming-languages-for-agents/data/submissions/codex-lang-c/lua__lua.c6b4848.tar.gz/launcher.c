#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static char *script_path(const char *argv0) {
    static char path[PATH_MAX];
    const char *slash = strrchr(argv0, '/');
    if (slash) {
        size_t n = (size_t)(slash - argv0);
        if (n >= sizeof(path) - 16) n = sizeof(path) - 16;
        memcpy(path, argv0, n);
        path[n] = '\0';
        strcat(path, "/pylua.pl");
    } else {
        strcpy(path, "./pylua.pl");
    }
    return path;
}

int main(int argc, char **argv) {
    char **nargv = calloc((size_t)argc + 3, sizeof(char *));
    if (!nargv) return 1;
    nargv[0] = "perl";
    nargv[1] = script_path(argv[0]);
    for (int i = 1; i < argc; i++) nargv[i + 1] = argv[i];
    nargv[argc + 1] = NULL;
    execvp("perl", nargv);
    perror("perl");
    return 127;
}
