#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    char **v;
    size_t n, cap;
} Lines;

typedef struct {
    bool number;
    bool show_all;
    bool squeeze_blank;
    bool quiet_empty;
    bool decorations_always;
    bool grid;
    bool header;
    bool filesize;
    bool plain;
    bool list_languages;
    bool list_themes;
    bool config_file;
    bool acknowledgements;
    bool diagnostic;
    bool short_number;
    bool tabs_explicit;
    char *line_range;
    int tabs;
    int terminal_width;
    char **files;
    int file_count;
} Opt;

static const char *themes =
"1337\n"
"Catppuccin Frappe\n"
"Catppuccin Latte\n"
"Catppuccin Macchiato\n"
"Catppuccin Mocha\n"
"Coldark-Cold\n"
"Coldark-Dark\n"
"DarkNeon\n"
"Dracula\n"
"GitHub\n"
"Monokai Extended\n"
"Monokai Extended Bright\n"
"Monokai Extended Light\n"
"Monokai Extended Origin\n"
"Nord\n"
"OneHalfDark\n"
"OneHalfLight\n"
"Solarized (dark)\n"
"Solarized (light)\n"
"Sublime Snazzy\n"
"TwoDark\n"
"Visual Studio Dark+\n"
"ansi\n"
"base16\n"
"base16-256\n"
"gruvbox-dark\n"
"gruvbox-light\n"
"zenburn\n";

static const char *short_help =
"A cat(1) clone with wings.\n"
"\n"
"Usage: bat [OPTIONS] [FILE]...\n"
"       bat <COMMAND>\n"
"\n"
"Arguments:\n"
"  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.\n"
"\n"
"Options:\n"
"  -A, --show-all\n"
"          Show non-printable characters (space, tab, newline, ..).\n"
"      --nonprintable-notation <notation>\n"
"          Set notation for non-printable characters.\n"
"      --binary <behavior>\n"
"          How to treat binary content. (default: no-printing)\n"
"  -p, --plain...\n"
"          Show plain style (alias for '--style=plain').\n"
"  -l, --language <language>\n"
"          Set the language for syntax highlighting.\n"
"      --fallback-syntax <fallback-syntax>\n"
"          Set a fallback language for undetected syntaxes. [aliases: --fallback-language]\n"
"  -H, --highlight-line <N:M>\n"
"          Highlight lines N through M.\n"
"      --file-name <name>\n"
"          Specify the name to display for a file.\n"
"  -d, --diff\n"
"          Only show lines that have been added/removed/modified.\n"
"      --tabs <T>\n"
"          Set the tab width to T spaces.\n"
"      --wrap <mode>\n"
"          Specify the text-wrapping mode (*auto*, never, character, word).\n"
"  -S, --chop-long-lines\n"
"          Truncate all lines longer than screen width. Alias for '--wrap=never'.\n"
"  -n, --number\n"
"          Show line numbers (alias for '--style=numbers').\n"
"      --color <when>\n"
"          When to use colors (*auto*, never, always).\n"
"      --italic-text <when>\n"
"          Use italics in output (always, *never*)\n"
"      --decorations <when>\n"
"          When to show the decorations (*auto*, never, always).\n"
"      --paging <when>\n"
"          Specify when to use the pager, or use `-P` to disable (*auto*, never, always).\n"
"  -m, --map-syntax <glob:syntax>\n"
"          Use the specified syntax for files matching the glob pattern ('*.cpp:C++').\n"
"      --theme <theme>\n"
"          Set the color theme for syntax highlighting.\n"
"      --theme-light <theme>\n"
"          Sets the color theme for syntax highlighting used for light backgrounds.\n"
"      --theme-dark <theme>\n"
"          Sets the color theme for syntax highlighting used for dark backgrounds.\n"
"      --list-themes\n"
"          Display all supported highlighting themes.\n"
"  -s, --squeeze-blank\n"
"          Squeeze consecutive empty lines.\n"
"      --style <components>\n"
"          Comma-separated list of style elements to display (*default*, auto, full, plain, changes,\n"
"          header, header-filename, header-filesize, grid, rule, numbers, snip).\n"
"  -r, --line-range <N:M>\n"
"          Only print the lines from N to M.\n"
"  -L, --list-languages\n"
"          Display all supported languages.\n"
"  -u, --unbuffered\n"
"          Enable unbuffered input reading for streaming use cases.\n"
"      --completion <SHELL>\n"
"          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]\n"
"  -E, --quiet-empty\n"
"          Produce no output when the input is empty.\n"
"  -h, --help\n"
"          Print help (see more with '--help')\n"
"  -V, --version\n"
"          Print version\n";

static const char *long_help =
"A cat(1) clone with syntax highlighting and Git integration.\n"
"\n"
"Usage: bat [OPTIONS] [FILE]...\n"
"       bat <COMMAND>\n"
"\n"
"Arguments:\n"
"  [FILE]...\n"
"          File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from\n"
"          standard input.\n"
"\n"
"Options:\n"
"  -A, --show-all\n"
"          Show non-printable characters like space, tab or newline. This option can also be used to\n"
"          print binary files. Use '--tabs' to control the width of the tab-placeholders.\n"
"\n"
"      --nonprintable-notation <notation>\n"
"          Set notation for non-printable characters.\n"
"          \n"
"          Possible values:\n"
"            * unicode (␇, ␊, ␀, ..)\n"
"            * caret   (^G, ^J, ^@, ..)\n"
"\n"
"      --binary <behavior>\n"
"          How to treat binary content. (default: no-printing)\n"
"          \n"
"          Possible values:\n"
"            * no-printing: do not print any binary content\n"
"            * as-text: treat binary content as normal text\n"
"\n"
"  -p, --plain...\n"
"          Only show plain style, no decorations. This is an alias for '--style=plain'. When '-p' is\n"
"          used twice ('-pp'), it also disables automatic paging (alias for '--style=plain\n"
"          --paging=never').\n"
"\n"
"  -l, --language <language>\n"
"          Explicitly set the language for syntax highlighting. The language can be specified as a\n"
"          name (like 'C++' or 'LaTeX') or possible file extension (like 'cpp', 'hpp' or 'md'). Use\n"
"          '--list-languages' to show all supported language names and file extensions.\n"
"\n"
"      --fallback-syntax <fallback-syntax>\n"
"          Set a fallback language for syntax highlighting when auto-detection fails. Unlike\n"
"          '--language', this is only used when no syntax could be detected from filename, custom\n"
"          syntax mappings, or first-line detection.\n"
"          \n"
"          [aliases: --fallback-language]\n"
"\n"
"  -H, --highlight-line <N:M>\n"
"          Highlight the specified line ranges with a different background color For example:\n"
"            '--highlight-line 40' highlights line 40\n"
"            '--highlight-line 30:40' highlights lines 30 to 40\n"
"            '--highlight-line :40' highlights lines 1 to 40\n"
"            '--highlight-line 40:' highlights lines 40 to the end of the file\n"
"            '--highlight-line 30:+10' highlights lines 30 to 40\n"
"\n"
"      --file-name <name>\n"
"          Specify the name to display for a file. Useful when piping data to bat from STDIN when bat\n"
"          does not otherwise know the filename. Note that the provided file name is also used for\n"
"          syntax detection.\n"
"\n"
"  -d, --diff\n"
"          Only show lines that have been added/removed/modified with respect to the Git index. Use\n"
"          --diff-context=N to control how much context you want to see.\n"
"\n"
"      --diff-context <N>\n"
"          Include N lines of context around added/removed/modified lines when using '--diff'.\n"
"\n"
"      --tabs <T>\n"
"          Set the tab width to T spaces. Use a width of 0 to pass tabs through directly\n"
"\n"
"      --wrap <mode>\n"
"          Specify the text-wrapping mode (*auto*, never, character, word). The '--terminal-width'\n"
"          option can be used in addition to control the output width.\n"
"\n"
"  -S, --chop-long-lines\n"
"          Truncate all lines longer than screen width. Alias for '--wrap=never'.\n"
"\n"
"      --terminal-width <width>\n"
"          Explicitly set the width of the terminal instead of determining it automatically. If\n"
"          prefixed with '+' or '-', the value will be treated as an offset to the actual terminal\n"
"          width. This can also be configured via the BAT_WIDTH environment variable (e.g. export\n"
"          BAT_WIDTH=\"100\"). See also: '--wrap'.\n"
"\n"
"  -n, --number\n"
"          Only show line numbers, no other decorations. This is an alias for '--style=numbers'\n"
"\n"
"      --color <when>\n"
"          Specify when to use colored output. The automatic mode only enables colors if an\n"
"          interactive terminal is detected - colors are automatically disabled if the output goes to\n"
"          a pipe.\n"
"          Possible values: *auto*, never, always.\n"
"\n"
"      --italic-text <when>\n"
"          Specify when to use ANSI sequences for italic text in the output. Possible values: always,\n"
"          *never*.\n"
"\n"
"      --decorations <when>\n"
"          Specify when to use the decorations that have been specified via '--style'. The automatic\n"
"          mode only enables decorations if an interactive terminal is detected. The always mode will\n"
"          show decorations even when piping output. Possible values: *auto*, never, always.\n"
"\n"
"  -f, --force-colorization\n"
"          Alias for '--decorations=always --color=always'. This is useful if the output of bat is\n"
"          piped to another program, but you want to keep the colorization/decorations.\n"
"\n"
"      --paging <when>\n"
"          Specify when to use the pager. To disable the pager, use '--paging=never' or its\n"
"          alias,'-P'. To disable the pager permanently, set BAT_PAGING to 'never'. To control which\n"
"          pager is used, see the '--pager' option. Possible values: *auto*, never, always.\n"
"\n"
"      --pager <command>\n"
"          Determine which pager is used. This option will override the PAGER and BAT_PAGER\n"
"          environment variables. The default pager is 'less'. If you provide '--pager=builtin', use\n"
"          the built-in 'minus' pager. To control when the pager is used, see the '--paging' option.\n"
"          Example: '--pager \"less -RF\"'.\n"
"\n"
"  -m, --map-syntax <glob:syntax>\n"
"          Map a glob pattern to an existing syntax name. The glob pattern is matched on the full\n"
"          path and the filename. For example, to highlight *.build files with the Python syntax, use\n"
"          -m '*.build:Python'. To highlight files named '.myignore' with the Git Ignore syntax, use\n"
"          -m '.myignore:Git Ignore'. Note that the right-hand side is the *name* of the syntax, not\n"
"          a file extension.\n"
"\n"
"      --ignored-suffix <ignored-suffix>\n"
"          Ignore extension. For example:\n"
"            'bat --ignored-suffix \".dev\" my_file.json.dev' will use JSON syntax, and ignore '.dev'\n"
"\n"
"      --theme <theme>\n"
"          Set the theme for syntax highlighting. Use '--list-themes' to see all available themes. To\n"
"          set a default theme, add the '--theme=\"...\"' option to the configuration file or export\n"
"          the BAT_THEME environment variable (e.g.: export BAT_THEME=\"...\").\n"
"          \n"
"          Special values:\n"
"          \n"
"            * auto: Picks a dark or light theme depending on the terminal's colors (default).\n"
"                    Use '--theme-light' and '--theme-dark' to customize the selected theme.\n"
"              * auto:always: Detect the terminal's colors even when the output is redirected.\n"
"              * auto:system: Detect the color scheme from the system-wide preference (macOS only).\n"
"            * dark: Use the dark theme specified by '--theme-dark'.\n"
"            * light: Use the light theme specified by '--theme-light'.\n"
"\n"
"      --theme-light <theme>\n"
"          Sets the theme name for syntax highlighting used when the terminal uses a light\n"
"          background. Use '--list-themes' to see all available themes. To set a default theme, add\n"
"          the '--theme-light=\"...\" option to the configuration file or export the BAT_THEME_LIGHT\n"
"          environment variable (e.g. export BAT_THEME_LIGHT=\"...\").\n"
"\n"
"      --theme-dark <theme>\n"
"          Sets the theme name for syntax highlighting used when the terminal uses a dark background.\n"
"          Use '--list-themes' to see all available themes. To set a default theme, add the\n"
"          '--theme-dark=\"...\" option to the configuration file or export the BAT_THEME_DARK\n"
"          environment variable (e.g. export BAT_THEME_DARK=\"...\").\n"
"\n"
"      --list-themes\n"
"          Display a list of supported themes for syntax highlighting.\n"
"\n"
"  -s, --squeeze-blank\n"
"          Squeeze consecutive empty lines into a single empty line.\n"
"\n"
"      --squeeze-limit <squeeze-limit>\n"
"          Set the maximum number of consecutive empty lines to be printed.\n"
"\n"
"      --strip-ansi <when>\n"
"          Specify when to strip ANSI escape sequences from the input. The automatic mode will remove\n"
"          escape sequences unless the syntax highlighting language is plain text. Possible values:\n"
"          auto, always, *never*.\n"
"\n"
"      --style <components>\n"
"          Configure which elements (line numbers, file headers, grid borders, Git modifications, ..)\n"
"          to display in addition to the file contents. The argument is a comma-separated list of\n"
"          components to display (e.g. 'numbers,changes,grid') or a pre-defined style ('full'). To\n"
"          set a default style, add the '--style=\"..\"' option to the configuration file or export the\n"
"          BAT_STYLE environment variable (e.g.: export BAT_STYLE=\"..\").\n"
"\n"
"  -r, --line-range <N:M>\n"
"          Only print the specified range of lines for each file.\n"
"\n"
"  -L, --list-languages\n"
"          Display a list of supported languages for syntax highlighting.\n"
"\n"
"  -u, --unbuffered\n"
"          Enable unbuffered input reading. When this flag is set, bat will display data as soon as\n"
"          it is available, without waiting for a complete line.\n"
"\n"
"      --completion <SHELL>\n"
"          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]\n"
"\n"
"      --diagnostic\n"
"          Show diagnostic information for bug reports.\n"
"\n"
"  -E, --quiet-empty\n"
"          When this flag is set, bat will produce no output at all when the input is empty.\n"
"\n"
"      --acknowledgements\n"
"          Show acknowledgements.\n"
"\n"
"      --set-terminal-title\n"
"          Sets terminal title to filenames when using a pager.\n"
"\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n"
"\n"
"  -V, --version\n"
"          Print version\n"
"\n"
"You can use 'bat cache' to customize syntaxes and themes. See 'bat cache --help' for more\n"
"information\n";

static const char *languages =
"ActionScript:as\n"
"Ada:adb,ads,gpr\n"
"Apache Conf:envvars,htaccess,HTACCESS,htgroups,HTGROUPS,htpasswd,HTPASSWD,.htaccess,.HTACCESS,.htgroups,.HTGROUPS,.htpasswd,.HTPASSWD,httpd.conf,/etc/apache2/**/*.conf,/etc/apache2/sites-*/**/*,/etc/httpd/conf/**/*.conf\n"
"AppleScript:applescript,script editor\n"
"ARM Assembly:s,S\n"
"AsciiDoc (Asciidoctor):adoc,ad,asciidoc\n"
"ASP:asa\n"
"Authorized Keys:authorized_keys,pub,authorized_keys2\n"
"AWK:awk\n"
"Batch File:bat,cmd\n"
"BibTeX:bib\n"
"Bourne Again Shell (bash):sh,bash,zsh,ash,.bash_aliases,.bash_completions,.bash_functions,.bash_login,.bash_logout,.bash_profile,.bash_variables,.bashrc,.profile,.textmate_init,.zlogin,.zlogout,.zprofile,.zshenv,.zshrc,PKGBUILD,ebuild,eclass,**/bat/config,*.ksh,*.kshrc,/etc/os-release,/usr/lib/os-release,/etc/initrd-release,/usr/lib/extension-release.d/extension-release.*,/etc/profile,bashrc,*.bashrc,bash_profile,*.bash_profile,bash_login,*.bash_login,bash_logout,*.bash_logout,zshrc,*.zshrc,zprofile,*.zprofile,zlogin,*.zlogin,zlogout,*.zlogout,zshenv,*.zshenv\n"
"C:c\n"
"C#:cs,csx\n"
"C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h\n"
"Cabal:cabal\n"
"CFML:cfml,cfm,cfc\n"
"Clojure:clj,cljc,cljs,edn\n"
"CMake:CMakeLists.txt,cmake\n"
"CMake C Header:h.in\n"
"CMake C++ Header:hh.in,hpp.in,hxx.in,h++.in\n"
"CMakeCache:CMakeCache.txt\n"
"CoffeeScript:coffee,Cakefile,coffee.erb,cson\n"
"Command Help:cmd-help,help\n"
"CpuInfo:cpuinfo\n"
"Crontab:tab,crontab,cron.d\n"
"Crystal:cr\n"
"CSS:css,css.erb,css.liquid\n"
"D:d,di\n"
"Dart:dart\n"
"debsources:sources.list\n"
"Diff:diff,patch,*.debdiff\n"
"Dockerfile:Dockerfile,dockerfile,.Dockerfile,Containerfile\n"
"DotENV:.env,.env.dist,.env.local,.env.sample,.env.example,.env.template,.env.test,.env.test.local,.env.testing,.env.dev,.env.development,.env.development.local,.env.prod,.env.production,.env.production.local,.env.dusk.local,.env.staging,.env.default,.env.defaults,.envrc,.flaskenv,env,env.example,env.sample,env.template\n"
"Elixir:ex,exs\n"
"Elm:elm\n"
"Email:eml,msg,mbx,mboxz,/var/spool/mail/*,/var/mail/*\n"
"Erlang:erl,hrl,Emakefile,emakefile,escript\n"
"F#:fs,fsi,fsx,*.fs\n"
"Fish:fish\n"
"Fortran (Fixed Form):f,F,f77,F77,for,FOR,fpp,FPP\n"
"Fortran (Modern):f90,F90,f95,F95,f03,F03,f08,F08\n"
"Fortran Namelist:namelist\n"
"fstab:fstab,crypttab,mtab\n"
"GDScript (Godot Engine):gd\n"
"Git Attributes:attributes,gitattributes,.gitattributes,/home/agent/.config/git/attributes\n"
"Git Commit:COMMIT_EDITMSG,MERGE_MSG,TAG_EDITMSG\n"
"Git Config:gitconfig,.gitconfig,.gitmodules,/home/agent/.config/git/config\n"
"Git Ignore:exclude,gitignore,.gitignore,.gcloudignore,/home/agent/.config/git/ignore,.?*ignore\n"
"Git Link:.git\n"
"Git Log:gitlog\n"
"Git Mailmap:.mailmap,mailmap\n"
"Git Rebase Todo:git-rebase-todo\n"
"GLSL:vs,gs,vsh,fsh,gsh,vshader,fshader,gshader,vert,frag,geom,tesc,tese,comp,glsl,mesh,task,rgen,rint,rahit,rchit,rmiss,rcall\n"
"gnuplot:gp,gpl,gnuplot,gnu,plot,plt\n"
"Go:go\n"
"Gomod:go.mod,go.work\n"
"Gosum:go.sum\n"
"GraphQL:graphql,graphqls,gql\n"
"Graphviz (DOT):dot,DOT,gv\n"
"Groff/troff:groff,troff,1,2,3,4,5,6,7,8,9\n"
"Groovy:groovy,gvy,gradle,Jenkinsfile\n"
"Haskell:hs\n"
"HTML:html,htm,shtml,xhtml\n"
"INI:ini,cfg,conf\n"
"Java:java\n"
"JavaScript:js,mjs,jsx,cjs\n"
"JSON:json,jsonl,jsonc\n"
"LaTeX:tex,ltx\n"
"Lua:lua\n"
"Makefile:make,GNUmakefile,makefile,Makefile,mk\n"
"Manpage:man\n"
"Markdown:md,mdown,markdown\n"
"Perl:pl,pm,pod\n"
"PHP:php\n"
"Plain Text:txt,text\n"
"Python:py,py3,pyw,SConstruct,SConscript\n"
"Ruby:rb,rbw,Rakefile,Gemfile\n"
"Rust:rs\n"
"SQL:sql\n"
"TOML:toml\n"
"TypeScript:ts,tsx\n"
"XML:xml,xsd,xsl,svg\n"
"YAML:yml,yaml\n";

static void print_file_or(const char *path, const char *fallback) {
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        fputs(fallback, stdout);
        return;
    }
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) fwrite(buf, 1, n, stdout);
    fclose(fp);
}

static void lines_push(Lines *ls, char *s) {
    if (ls->n == ls->cap) {
        ls->cap = ls->cap ? ls->cap * 2 : 64;
        ls->v = realloc(ls->v, ls->cap * sizeof(char *));
        if (!ls->v) exit(2);
    }
    ls->v[ls->n++] = s;
}

static void free_lines(Lines *ls) {
    for (size_t i = 0; i < ls->n; i++) free(ls->v[i]);
    free(ls->v);
    ls->v = NULL;
    ls->n = ls->cap = 0;
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) exit(2);
    return r;
}

static void read_stream(FILE *fp, Lines *ls) {
    char *buf = NULL;
    size_t cap = 0;
    ssize_t n;
    while ((n = getline(&buf, &cap, fp)) >= 0) {
        lines_push(ls, xstrdup(buf));
    }
    free(buf);
}

static bool is_blank_line(const char *s) {
    return s[0] == '\n' || s[0] == '\0';
}

static void parse_style(Opt *o, const char *style, bool force) {
    if (!style) return;
    char *tmp = xstrdup(style);
    char *save = NULL;
    bool replacement = true;
    for (char *p = strtok_r(tmp, ",", &save); p; p = strtok_r(NULL, ",", &save)) {
        if (*p == '+' || *p == '-') replacement = false;
    }
    if (replacement || force) {
        o->plain = o->number = o->grid = o->header = o->filesize = false;
    }
    free(tmp);
    tmp = xstrdup(style);
    save = NULL;
    for (char *p = strtok_r(tmp, ",", &save); p; p = strtok_r(NULL, ",", &save)) {
        bool add = true;
        if (*p == '+') p++;
        else if (*p == '-') { add = false; p++; }
        if (!strcmp(p, "plain")) o->plain = add;
        else if (!strcmp(p, "numbers")) o->number = add;
        else if (!strcmp(p, "grid")) o->grid = add;
        else if (!strcmp(p, "header") || !strcmp(p, "header-filename")) o->header = add;
        else if (!strcmp(p, "header-filesize")) o->filesize = add;
        else if (!strcmp(p, "full")) {
            o->number = o->grid = o->header = o->filesize = add;
            o->plain = false;
        } else if (!strcmp(p, "default")) {
            o->number = o->grid = o->header = add;
            o->filesize = false;
            o->plain = false;
        }
    }
    free(tmp);
}

static void print_rule(int width, const char *join) {
    for (int i = 0; i < 5; i++) fputs("─", stdout);
    fputs(join, stdout);
    for (int i = 6; i < width; i++) fputs("─", stdout);
    putchar('\n');
}

static void print_show_all_line(const char *s, int tabs) {
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p == '\n') {
            fputs("␊\n", stdout);
        } else if (*p == '\t') {
            if (tabs <= 0) putchar('\t');
            else {
                fputs("├", stdout);
                for (int i = 0; i < tabs - 2; i++) fputs("─", stdout);
                fputs("┤", stdout);
            }
        } else if (*p == ' ') {
            fputs("·", stdout);
        } else if (*p < 32) {
            fputs("␀", stdout);
        } else {
            putchar(*p);
        }
    }
}

static void print_normal_line(const char *s, int tabs) {
    if (tabs == 0) {
        fputs(s, stdout);
        return;
    }
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (*p == '\t') {
            int n = tabs > 0 ? tabs : 4;
            for (int i = 0; i < n; i++) putchar(' ');
        } else {
            putchar(*p);
        }
    }
    size_t len = strlen(s);
    if (len == 0 || s[len - 1] != '\n') putchar('\n');
}

static void range_for(const char *spec, size_t total, long *start, long *end) {
    *start = 1;
    *end = (long)total;
    if (!spec || !*spec) return;
    char *tmp = xstrdup(spec);
    char *c1 = strchr(tmp, ':');
    if (!c1) {
        long n = strtol(tmp, NULL, 10);
        *start = *end = n;
    } else {
        *c1 = '\0';
        char *right = c1 + 1;
        char *c2 = strchr(right, ':');
        long context = 0;
        if (c2) {
            *c2 = '\0';
            context = strtol(c2 + 1, NULL, 10);
        }
        if (tmp[0]) {
            long n = strtol(tmp, NULL, 10);
            *start = (n < 0 && tmp[0] == '-') ? (long)total + n + 1 : n;
        }
        if (right[0] == '+') {
            long add = strtol(right + 1, NULL, 10);
            *end = *start + add;
        } else if (right[0]) {
            *end = strtol(right, NULL, 10);
        }
        if (context > 0) {
            *start -= context;
            *end += context;
        }
    }
    if (*start < 1) *start = 1;
    if (*end > (long)total) *end = (long)total;
    free(tmp);
}

static int process_lines(Opt *o, Lines *ls, const char *name, off_t size) {
    if (o->quiet_empty && ls->n == 0) return 0;
    bool effective_number = o->short_number || (o->decorations_always && o->number);
    bool decorated = o->decorations_always && !o->plain && (o->grid || o->header || o->filesize || effective_number);
    int width = o->terminal_width > 0 ? o->terminal_width : 80;
    if (decorated && o->grid) print_rule(width, "┬");
    if (decorated && (o->header || o->filesize)) {
        if (o->header && name) printf("     │ File: %s\n", name);
        if (o->filesize && size >= 0) printf("     │ Size: %lld B\n", (long long)size);
        if (o->grid) print_rule(width, "┼");
    }
    long start, end;
    range_for(o->line_range, ls->n, &start, &end);
    int blank_run = 0;
    for (long i = start; i <= end; i++) {
        if (i < 1 || i > (long)ls->n) continue;
        char *line = ls->v[i - 1];
        if (o->squeeze_blank && is_blank_line(line)) {
            blank_run++;
            if (blank_run > 1) continue;
        } else if (!is_blank_line(line)) {
            blank_run = 0;
        }
        if (effective_number) printf("%4ld ", i);
        if (decorated && o->grid) fputs("│ ", stdout);
        if (o->show_all) print_show_all_line(line, o->tabs);
        else print_normal_line(line, (effective_number || decorated || o->tabs_explicit) ? o->tabs : 0);
    }
    if (decorated && o->grid) print_rule(width, "┴");
    return 0;
}

static int process_file(Opt *o, const char *path) {
    FILE *fp = NULL;
    const char *display = path;
    off_t size = -1;
    if (!strcmp(path, "-")) {
        fp = stdin;
        display = "STDIN";
    } else {
        fp = fopen(path, "rb");
        if (!fp) {
            fprintf(stderr, "\033[31m[bat error]\033[0m: '%s': %s (os error %d)\n",
                    path, strerror(errno), errno);
            return 1;
        }
        struct stat st;
        if (stat(path, &st) == 0) size = st.st_size;
    }
    Lines ls = {0};
    read_stream(fp, &ls);
    if (fp != stdin) fclose(fp);
    process_lines(o, &ls, display, size);
    free_lines(&ls);
    return 0;
}

static void print_completion(const char *shell) {
    char path[64];
    snprintf(path, sizeof(path), "completion_%s.txt", shell ? shell : "");
    FILE *fp = fopen(path, "rb");
    if (fp) {
        char buf[8192];
        size_t n;
        while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) fwrite(buf, 1, n, stdout);
        fclose(fp);
        return;
    }
    printf("# completion script for bat (%s)\n", shell ? shell : "");
    puts("complete -F _bat bat 2>/dev/null || true");
}

static void cache_help(void) {
    puts("Modify the syntax-definition and theme cache\n");
    puts("Usage: executable cache [OPTIONS]\n");
    puts("Options:");
    puts("  -h, --help              Print help");
    puts("  -b, --build             Initialize (or update) the syntax/theme cache.");
    puts("  -c, --clear             Remove the cached syntax definitions and themes.");
    puts("      --source <dir>      Use a different directory to load syntaxes and themes from.");
    puts("      --target <dir>      Use a different directory to store the cached syntax and theme set.");
    puts("      --blank             Create completely new syntax and theme sets (instead of appending to the");
    puts("                          default sets).");
    puts("      --acknowledgements  Build acknowledgements.bin.");
}

int main(int argc, char **argv) {
    Opt o = {0};
    o.tabs = 4;
    o.terminal_width = 80;

    const char *env_style = getenv("BAT_STYLE");
    if (env_style) parse_style(&o, env_style, true);

    if (argc > 1 && !strcmp(argv[1], "cache")) {
        if (argc > 2 && (!strcmp(argv[2], "--help") || !strcmp(argv[2], "-h"))) {
            print_file_or("cache_help.txt", "");
            return 0;
        }
        cache_help();
        return 2;
    }

    enum {
        OPT_NONPRINT = 1000, OPT_BINARY, OPT_FALLBACK, OPT_FILE_NAME, OPT_DIFF_CONTEXT,
        OPT_TABS, OPT_WRAP, OPT_TERMINAL_WIDTH, OPT_COLOR, OPT_ITALIC, OPT_DECORATIONS,
        OPT_PAGING, OPT_PAGER, OPT_THEME, OPT_THEME_LIGHT, OPT_THEME_DARK, OPT_LIST_THEMES,
        OPT_STYLE, OPT_SQUEEZE_LIMIT, OPT_STRIP_ANSI, OPT_LIST_LANG, OPT_COMPLETION,
        OPT_DIAGNOSTIC, OPT_ACK, OPT_SET_TITLE, OPT_CONFIG_FILE, OPT_IGNORED_SUFFIX,
        OPT_LONG_HELP
    };
    static struct option longopts[] = {
        {"show-all", no_argument, 0, 'A'}, {"plain", no_argument, 0, 'p'},
        {"language", required_argument, 0, 'l'}, {"highlight-line", required_argument, 0, 'H'},
        {"diff", no_argument, 0, 'd'}, {"chop-long-lines", no_argument, 0, 'S'},
        {"number", no_argument, 0, 'n'}, {"force-colorization", no_argument, 0, 'f'},
        {"squeeze-blank", no_argument, 0, 's'}, {"line-range", required_argument, 0, 'r'},
        {"list-languages", no_argument, 0, OPT_LIST_LANG}, {"unbuffered", no_argument, 0, 'u'},
        {"quiet-empty", no_argument, 0, 'E'}, {"help", no_argument, 0, OPT_LONG_HELP},
        {"version", no_argument, 0, 'V'}, {"nonprintable-notation", required_argument, 0, OPT_NONPRINT},
        {"binary", required_argument, 0, OPT_BINARY}, {"fallback-syntax", required_argument, 0, OPT_FALLBACK},
        {"fallback-language", required_argument, 0, OPT_FALLBACK}, {"file-name", required_argument, 0, OPT_FILE_NAME},
        {"diff-context", required_argument, 0, OPT_DIFF_CONTEXT}, {"tabs", required_argument, 0, OPT_TABS},
        {"wrap", required_argument, 0, OPT_WRAP}, {"terminal-width", required_argument, 0, OPT_TERMINAL_WIDTH},
        {"color", required_argument, 0, OPT_COLOR}, {"italic-text", required_argument, 0, OPT_ITALIC},
        {"decorations", required_argument, 0, OPT_DECORATIONS}, {"paging", required_argument, 0, OPT_PAGING},
        {"pager", required_argument, 0, OPT_PAGER}, {"map-syntax", required_argument, 0, 'm'},
        {"ignored-suffix", required_argument, 0, OPT_IGNORED_SUFFIX}, {"theme", required_argument, 0, OPT_THEME},
        {"theme-light", required_argument, 0, OPT_THEME_LIGHT}, {"theme-dark", required_argument, 0, OPT_THEME_DARK},
        {"list-themes", no_argument, 0, OPT_LIST_THEMES}, {"style", required_argument, 0, OPT_STYLE},
        {"squeeze-limit", required_argument, 0, OPT_SQUEEZE_LIMIT}, {"strip-ansi", required_argument, 0, OPT_STRIP_ANSI},
        {"completion", required_argument, 0, OPT_COMPLETION}, {"diagnostic", no_argument, 0, OPT_DIAGNOSTIC},
        {"acknowledgements", no_argument, 0, OPT_ACK}, {"set-terminal-title", no_argument, 0, OPT_SET_TITLE},
        {"config-file", no_argument, 0, OPT_CONFIG_FILE}, {0, 0, 0, 0}
    };

    opterr = 0;
    int c;
    while ((c = getopt_long(argc, argv, "Apl:H:dSnfsr:LuEVhVPm:", longopts, NULL)) != -1) {
        switch (c) {
        case 'A': o.show_all = true; break;
        case 'p': o.plain = true; o.number = o.grid = o.header = o.filesize = false; break;
        case 'n': o.number = true; o.short_number = true; o.plain = false; break;
        case 'f': o.decorations_always = true; break;
        case 's': o.squeeze_blank = true; break;
        case 'r': o.line_range = optarg; break;
        case 'L': o.list_languages = true; break;
        case 'E': o.quiet_empty = true; break;
        case 'V': puts("bat 0.26.1 (610b77c)"); return 0;
        case 'h': print_file_or("short_help.txt", short_help); return 0;
        case OPT_LONG_HELP: print_file_or("long_help.txt", long_help); return 0;
        case 'l': case 'H': case 'd': case 'S': case 'u': case 'P': case 'm':
            break;
        case OPT_LIST_LANG: o.list_languages = true; break;
        case OPT_LIST_THEMES: o.list_themes = true; break;
        case OPT_TABS: o.tabs = atoi(optarg); o.tabs_explicit = true; break;
        case OPT_TERMINAL_WIDTH: o.terminal_width = atoi(optarg); break;
        case OPT_DECORATIONS: if (!strcmp(optarg, "always")) o.decorations_always = true; break;
        case OPT_STYLE: parse_style(&o, optarg, true); break;
        case OPT_COMPLETION: print_completion(optarg); return 0;
        case OPT_DIAGNOSTIC: o.diagnostic = true; break;
        case OPT_ACK: o.acknowledgements = true; break;
        case OPT_CONFIG_FILE: o.config_file = true; break;
        case OPT_NONPRINT: case OPT_BINARY: case OPT_FALLBACK: case OPT_FILE_NAME:
        case OPT_DIFF_CONTEXT: case OPT_WRAP: case OPT_COLOR: case OPT_ITALIC:
        case OPT_PAGING: case OPT_PAGER: case OPT_THEME: case OPT_THEME_LIGHT:
        case OPT_THEME_DARK: case OPT_SQUEEZE_LIMIT: case OPT_STRIP_ANSI:
        case OPT_SET_TITLE: case OPT_IGNORED_SUFFIX:
            break;
        case '?':
        default:
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", argv[optind - 1]);
            fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", argv[optind - 1], argv[optind - 1]);
            fprintf(stderr, "Usage: executable [OPTIONS] [FILE]...\n       executable <COMMAND>\n");
            return 2;
        }
    }

    if (o.list_themes) { print_file_or("list_themes.txt", themes); return 0; }
    if (o.list_languages) { print_file_or("list_languages.txt", languages); return 0; }
    if (o.config_file) { puts("/home/agent/.config/bat/config"); return 0; }
    if (o.acknowledgements) { print_file_or("acknowledgements.txt", "bat uses syntect, clircle, clap, git2, and other open source crates.\n"); return 0; }
    if (o.diagnostic) {
        FILE *fp = fopen("diagnostic.txt", "rb");
        if (fp) {
            char buf[8192];
            size_t n;
            while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) fwrite(buf, 1, n, stdout);
            fclose(fp);
            return 0;
        }
        puts("#### Software version");
        puts("bat 0.26.1 (610b77c)");
        return 0;
    }

    o.files = argv + optind;
    o.file_count = argc - optind;
    int status = 0;
    if (o.file_count == 0) {
        char *dash = "-";
        o.files = &dash;
        o.file_count = 1;
    }
    for (int i = 0; i < o.file_count; i++) {
        if (process_file(&o, o.files[i]) != 0) status = 1;
    }
    return status;
}
