#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef enum { V_UNDEF, V_NULL, V_NUM, V_BOOL, V_STR, V_ARRAY, V_FUNC } VType;
typedef struct Value Value;
typedef struct Env Env;
typedef struct Function Function;

struct Value {
    VType t;
    double n;
    int b;
    char *s;
    Value *items;
    int len;
    Function *fn;
};

typedef struct Var {
    char *name;
    Value v;
    struct Var *next;
} Var;

struct Env {
    Var *vars;
    Env *parent;
    int returning;
    Value ret;
};

struct Function {
    char **params;
    int argc;
    char *body;
    Env *closure;
};

static const char *SRC, *P, *FILENAME = "<cmdline>";
static int HAD_ERROR = 0;

static Value v_undef(void){ Value v={V_UNDEF,0,0,NULL,NULL,0,NULL}; return v; }
static Value v_null(void){ Value v={V_NULL,0,0,NULL,NULL,0,NULL}; return v; }
static Value v_num(double n){ Value v={V_NUM,n,0,NULL,NULL,0,NULL}; return v; }
static Value v_bool(int b){ Value v={V_BOOL,0,b,NULL,NULL,0,NULL}; return v; }
static Value v_str(const char *s){ Value v={V_STR,0,0,strdup(s?s:""),NULL,0,NULL}; return v; }
static Value v_func(Function *f){ Value v={V_FUNC,0,0,NULL,NULL,0,f}; return v; }
static Value v_array(Value *it,int len){ Value v={V_ARRAY,0,0,NULL,it,len,NULL}; return v; }

static char *xstrndup(const char *s, size_t n){ char *r=malloc(n+1); if(!r) exit(2); memcpy(r,s,n); r[n]=0; return r; }
static void skip_ws(void);
static Value parse_expr(Env *env);
static void exec_block_text(const char *txt, Env *env);

static void js_error(const char *fmt, ...) {
    if (HAD_ERROR) return;
    HAD_ERROR = 1;
    va_list ap; va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n");
}

static Var *find_var(Env *e, const char *name) {
    for (; e; e=e->parent) for (Var *v=e->vars; v; v=v->next) if (!strcmp(v->name,name)) return v;
    return NULL;
}
static Value env_get(Env *e, const char *name) {
    if (!strcmp(name,"undefined")) return v_undef();
    if (!strcmp(name,"null")) return v_null();
    if (!strcmp(name,"true")) return v_bool(1);
    if (!strcmp(name,"false")) return v_bool(0);
    Var *v=find_var(e,name);
    if (v) return v->v;
    return v_undef();
}
static void env_set_local(Env *e, const char *name, Value val) {
    Var *v=find_var(e,name);
    if (v) { v->v=val; return; }
    v=calloc(1,sizeof(*v)); v->name=strdup(name); v->v=val; v->next=e->vars; e->vars=v;
}
static void env_set_existing_or_global(Env *e, const char *name, Value val) {
    Var *v=find_var(e,name);
    if (v) { v->v=val; return; }
    while (e->parent) e=e->parent;
    env_set_local(e,name,val);
}

static int truthy(Value v) {
    if (v.t==V_UNDEF || v.t==V_NULL) return 0;
    if (v.t==V_BOOL) return v.b;
    if (v.t==V_NUM) return v.n!=0 && !isnan(v.n);
    if (v.t==V_STR) return v.s && v.s[0];
    return 1;
}
static double num(Value v) {
    if (v.t==V_NUM) return v.n;
    if (v.t==V_BOOL) return v.b;
    if (v.t==V_NULL) return 0;
    if (v.t==V_STR) return atof(v.s);
    return NAN;
}

static char *to_string(Value v);
static char *fmt_num(double n) {
    if (isnan(n)) return strdup("NaN");
    if (isinf(n)) return strdup(n<0 ? "-Infinity" : "Infinity");
    char buf[80];
    if (fabs(n - (long long)n) < 1e-10 && fabs(n) < 9e15) snprintf(buf,sizeof(buf),"%lld",(long long)n);
    else snprintf(buf,sizeof(buf),"%.15g",n);
    return strdup(buf);
}
static char *to_string(Value v) {
    if (v.t==V_UNDEF) return strdup("undefined");
    if (v.t==V_NULL) return strdup("null");
    if (v.t==V_BOOL) return strdup(v.b?"true":"false");
    if (v.t==V_NUM) return fmt_num(v.n);
    if (v.t==V_STR) return strdup(v.s?v.s:"");
    if (v.t==V_FUNC) return strdup("function");
    if (v.t==V_ARRAY) {
        size_t cap=32; char *out=malloc(cap); strcpy(out,"");
        for (int i=0;i<v.len;i++) {
            char *p=to_string(v.items[i]);
            size_t need=strlen(out)+strlen(p)+3;
            if (need>cap) { while(need>cap) cap*=2; out=realloc(out,cap); }
            if (i) strcat(out,",");
            strcat(out,p); free(p);
        }
        return out;
    }
    return strdup("");
}
static void print_value(Value v, int inspect) {
    if (v.t==V_STR) { fputs(v.s?v.s:"", stdout); return; }
    if (v.t==V_ARRAY && inspect) {
        fputs("[ ", stdout);
        for (int i=0;i<v.len;i++) {
            if (i) fputs(", ", stdout);
            if (v.items[i].t==V_STR) printf("\"%s\"", v.items[i].s);
            else print_value(v.items[i], 1);
        }
        fputs(" ]", stdout);
        return;
    }
    char *s=to_string(v); fputs(s, stdout); free(s);
}

static void skip_ws(void) {
    for (;;) {
        while (isspace((unsigned char)*P)) P++;
        if (P[0]=='/' && P[1]=='/') { P+=2; while(*P && *P!='\n') P++; continue; }
        if (P[0]=='/' && P[1]=='*') { P+=2; while(P[0] && !(P[0]=='*'&&P[1]=='/')) P++; if(*P) P+=2; continue; }
        break;
    }
}
static int match(const char *s) {
    skip_ws(); size_t n=strlen(s);
    if (!strncmp(P,s,n)) { P+=n; return 1; }
    return 0;
}
static int isid0(int c){ return isalpha(c)||c=='_'||c=='$'; }
static int isid(int c){ return isalnum(c)||c=='_'||c=='$'; }
static char *read_ident(void) {
    skip_ws(); if (!isid0((unsigned char)*P)) return NULL;
    const char *s=P++; while(isid((unsigned char)*P)) P++;
    return xstrndup(s, P-s);
}
static char *read_string_lit(void) {
    skip_ws(); char q=*P; if(q!='\'' && q!='"') return NULL; P++;
    char *out=malloc(1); size_t len=0, cap=1; out[0]=0;
    while(*P && *P!=q) {
        char c=*P++;
        if(c=='\\' && *P) {
            c=*P++;
            if(c=='n') c='\n'; else if(c=='t') c='\t'; else if(c=='r') c='\r';
        }
        if(len+2>cap){ cap*=2; out=realloc(out,cap); }
        out[len++]=c; out[len]=0;
    }
    if(*P==q) P++;
    return out;
}
static char *capture_balanced(char open, char close) {
    skip_ws(); if(*P!=open) return strdup("");
    const char *start=++P; int depth=1; char quote=0;
    while(*P && depth) {
        if(quote) { if(*P=='\\' && P[1]) P+=2; else { if(*P==quote) quote=0; P++; } continue; }
        if(*P=='\''||*P=='"') { quote=*P++; continue; }
        if(*P==open) depth++;
        else if(*P==close) { depth--; if(!depth) break; }
        P++;
    }
    char *r=xstrndup(start, P-start);
    if(*P==close) P++;
    return r;
}

static Value parse_assignment(Env *env);
static Value parse_primary(Env *env) {
    skip_ws();
    char *id=NULL;
    Value base=v_undef();
    if (*P=='(') { P++; Value v=parse_expr(env); match(")"); return v; }
    if (*P=='[') {
        P++; Value *items=NULL; int len=0, cap=0;
        skip_ws();
        while(*P && *P!=']') {
            if(len>=cap){ cap=cap?cap*2:4; items=realloc(items,cap*sizeof(Value)); }
            items[len++]=parse_expr(env);
            skip_ws(); if(*P==',') P++; else break;
        }
        match("]");
        base=v_array(items,len); id=strdup(""); goto postfix;
    }
    if (*P=='\'' || *P=='"') { char *s=read_string_lit(); base=v_str(s); id=strdup(""); free(s); goto postfix; }
    if (isdigit((unsigned char)*P) || (*P=='.' && isdigit((unsigned char)P[1]))) {
        char *end; double d=strtod(P,&end); P=end; if(*P=='n') P++; base=v_num(d); id=strdup(""); goto postfix;
    }
    id=read_ident();
    if (!id) return v_undef();
    skip_ws();
    if (!strcmp(id,"typeof")) { Value v=parse_primary(env); (void)v; free(id); return v_str(v.t==V_UNDEF?"undefined":v.t==V_FUNC?"function":v.t==V_BOOL?"boolean":v.t==V_STR?"string":v.t==V_NUM?"number":"object"); }
    if (!strcmp(id,"BigInt")) { match("("); Value v=parse_expr(env); match(")"); free(id); return v_num(num(v)); }
    if (!strcmp(id,"Number")) { match("("); Value v=parse_expr(env); match(")"); free(id); return v_num(num(v)); }
    if (!strcmp(id,"String")) { match("("); Value v=parse_expr(env); match(")"); char *s=to_string(v); Value r=v_str(s); free(s); free(id); return r; }
    if (!strcmp(id,"Boolean")) { match("("); Value v=parse_expr(env); match(")"); free(id); return v_bool(truthy(v)); }
    base=env_get(env,id);
postfix:
    for (;;) {
        skip_ws();
        if (*P=='.') {
            P++; char *prop=read_ident(); skip_ws();
            if (*P=='(') {
                char *args=capture_balanced('(',')');
                const char *save_src=SRC,*save_p=P; SRC=args; P=args;
                Value av[32]; int ac=0; skip_ws();
                while(*P && ac<32){ av[ac++]=parse_expr(env); skip_ws(); if(*P==',') P++; else break; }
                SRC=save_src; P=save_p; free(args);
                if (!strcmp(id,"console") && prop && (!strcmp(prop,"log") || !strcmp(prop,"error") || !strcmp(prop,"warn"))) {
                    FILE *old = stdout;
                    if(strcmp(prop,"log")) stdout = stderr;
                    for(int i=0;i<ac;i++){ if(i) putchar(' '); print_value(av[i],1); } putchar('\n'); base=v_undef();
                    stdout = old;
                } else if (!strcmp(id,"std") && prop) {
                    if(!strcmp(prop,"puts")) { if(ac) print_value(av[0],0); base=v_undef(); }
                    else if(!strcmp(prop,"printf")) { for(int i=1;i<ac;i++){ if(i>1) putchar(' '); print_value(av[i],0); } base=v_undef(); }
                    else if(!strcmp(prop,"exit")) { exit(ac ? (int)num(av[0]) : 0); }
                    else if(!strcmp(prop,"getenv")) { char *k=ac?to_string(av[0]):strdup(""); char *g=getenv(k); base=g?v_str(g):v_undef(); free(k); }
                    else if(!strcmp(prop,"gc")) base=v_undef();
                    else base=v_undef();
                } else if (!strcmp(id,"os") && prop) {
                    if(!strcmp(prop,"getcwd")) { char buf[4096]; base=getcwd(buf,sizeof(buf))?v_str(buf):v_undef(); }
                    else if(!strcmp(prop,"chdir")) { char *p=ac?to_string(av[0]):strdup(""); base=v_num(chdir(p)); free(p); }
                    else if(!strcmp(prop,"sleep")) { if(ac) usleep((useconds_t)(num(av[0])*1000000.0)); base=v_undef(); }
                    else base=v_undef();
                } else if (!strcmp(id,"JSON") && prop && !strcmp(prop,"stringify")) {
                    if(!ac) base=v_undef();
                    else if(av[0].t==V_STR) { char *s=malloc(strlen(av[0].s)*2+3), *o=s; *o++='"'; for(char *p=av[0].s; *p; p++){ if(*p=='"'||*p=='\\') *o++='\\'; *o++=*p; } *o++='"'; *o=0; base=v_str(s); free(s); }
                    else if(av[0].t==V_ARRAY) {
                        size_t cap=64; char *out=malloc(cap); strcpy(out,"[");
                        for(int i=0;i<av[0].len;i++){ char *s=to_string(av[0].items[i]); size_t need=strlen(out)+strlen(s)+4; if(need>cap){while(need>cap)cap*=2;out=realloc(out,cap);} if(i)strcat(out,","); if(av[0].items[i].t==V_STR)strcat(out,"\""); strcat(out,s); if(av[0].items[i].t==V_STR)strcat(out,"\""); free(s); }
                        strcat(out,"]"); base=v_str(out); free(out);
                    } else { char *s=to_string(av[0]); base=v_str(s); free(s); }
                } else if (!strcmp(id,"Math") && prop) {
                    double x=ac?num(av[0]):0, y=ac>1?num(av[1]):0;
                    if(!strcmp(prop,"abs")) base=v_num(fabs(x)); else if(!strcmp(prop,"floor")) base=v_num(floor(x));
                    else if(!strcmp(prop,"ceil")) base=v_num(ceil(x)); else if(!strcmp(prop,"round")) base=v_num(round(x));
                    else if(!strcmp(prop,"sqrt")) base=v_num(sqrt(x)); else if(!strcmp(prop,"pow")) base=v_num(pow(x,y));
                    else if(!strcmp(prop,"max")) { double m=x; for(int i=1;i<ac;i++) if(num(av[i])>m)m=num(av[i]); base=v_num(m); }
                    else if(!strcmp(prop,"min")) { double m=x; for(int i=1;i<ac;i++) if(num(av[i])<m)m=num(av[i]); base=v_num(m); }
                    else base=v_undef();
                } else if (base.t==V_ARRAY && prop && !strcmp(prop,"join")) {
                    const char *sep = (ac && av[0].t==V_STR) ? av[0].s : ",";
                    size_t cap=32; char *out=malloc(cap); out[0]=0;
                    for(int i=0;i<base.len;i++){ char *s=to_string(base.items[i]); size_t need=strlen(out)+strlen(s)+strlen(sep)+1; if(need>cap){while(need>cap)cap*=2;out=realloc(out,cap);} if(i)strcat(out,sep); strcat(out,s); free(s);}
                    base=v_str(out); free(out);
                } else if (base.t==V_ARRAY && prop && !strcmp(prop,"push")) {
                    base.items=realloc(base.items,(base.len+ac)*sizeof(Value));
                    for(int i=0;i<ac;i++) base.items[base.len++]=av[i];
                    if(id && *id) env_set_existing_or_global(env,id,base);
                    base=v_num(base.len);
                } else if (base.t==V_STR && prop) {
                    if(!strcmp(prop,"toUpperCase") || !strcmp(prop,"toLowerCase")) {
                        char *s=strdup(base.s?base.s:"");
                        for(char *q=s; *q; q++) *q = !strcmp(prop,"toUpperCase") ? toupper((unsigned char)*q) : tolower((unsigned char)*q);
                        base=v_str(s); free(s);
                    } else if(!strcmp(prop,"charAt")) {
                        int ix=ac?(int)num(av[0]):0; char tmp[2]="";
                        if(ix>=0 && ix<(int)strlen(base.s)) tmp[0]=base.s[ix];
                        base=v_str(tmp);
                    } else if(!strcmp(prop,"indexOf")) {
                        char *needle=ac?to_string(av[0]):strdup(""); char *f=strstr(base.s?base.s:"",needle); base=v_num(f?f-(base.s?base.s:""):-1); free(needle);
                    } else if(!strcmp(prop,"slice") || !strcmp(prop,"substring")) {
                        int l=strlen(base.s?base.s:""), a=ac?(int)num(av[0]):0, b=ac>1?(int)num(av[1]):l; if(a<0)a=l+a; if(b<0)b=l+b; if(a<0)a=0; if(b>l)b=l; if(b<a)b=a;
                        char *s=xstrndup((base.s?base.s:"")+a,b-a); base=v_str(s); free(s);
                    } else base=v_undef();
                } else base=v_undef();
            } else {
                if (base.t==V_ARRAY && prop && !strcmp(prop,"length")) base=v_num(base.len);
                else if (base.t==V_STR && prop && !strcmp(prop,"length")) base=v_num(strlen(base.s?base.s:""));
                else if (!strcmp(id,"Math") && prop && !strcmp(prop,"PI")) base=v_num(M_PI);
                else if (!strcmp(id,"os") && prop && !strcmp(prop,"platform")) base=v_str("linux");
                else base=v_undef();
            }
            free(prop);
        } else if (*P=='(') {
            char *args=capture_balanced('(',')');
            const char *save_src=SRC,*save_p=P; SRC=args; P=args;
            Value av[64]; int ac=0; skip_ws();
            while(*P && ac<64){ av[ac++]=parse_expr(env); skip_ws(); if(*P==',') P++; else break; }
            SRC=save_src; P=save_p; free(args);
            if (!strcmp(id,"print")) { for(int i=0;i<ac;i++){ if(i) putchar(' '); print_value(av[i],1); } putchar('\n'); base=v_undef(); }
            else if (base.t==V_FUNC) {
                Env call={0}; call.parent=base.fn->closure?base.fn->closure:env;
                for(int i=0;i<base.fn->argc;i++) env_set_local(&call, base.fn->params[i], i<ac?av[i]:v_undef());
                exec_block_text(base.fn->body,&call);
                base=call.returning?call.ret:v_undef();
            } else base=v_undef();
        } else if (*P=='[') {
            P++; Value ix=parse_expr(env); match("]");
            int i=(int)num(ix);
            if(base.t==V_ARRAY && i>=0 && i<base.len) base=base.items[i]; else if(base.t==V_STR && i>=0 && i<(int)strlen(base.s)){ char tmp[2]={base.s[i],0}; base=v_str(tmp); } else base=v_undef();
        } else break;
    }
    free(id);
    return base;
}
static Value parse_unary(Env *env) {
    skip_ws();
    if(match("!")) return v_bool(!truthy(parse_unary(env)));
    if(match("-")) return v_num(-num(parse_unary(env)));
    if(match("+")) return v_num(num(parse_unary(env)));
    return parse_primary(env);
}
static Value parse_pow(Env *env){ Value a=parse_unary(env); while(match("**")) a=v_num(pow(num(a),num(parse_unary(env)))); return a; }
static Value parse_mul(Env *env){ Value a=parse_pow(env); for(;;){ if(match("*")) a=v_num(num(a)*num(parse_pow(env))); else if(match("/")) a=v_num(num(a)/num(parse_pow(env))); else if(match("%")) a=v_num(fmod(num(a),num(parse_pow(env)))); else return a; } }
static Value parse_add(Env *env){ Value a=parse_mul(env); for(;;){ if(match("+")){ Value b=parse_mul(env); if(a.t==V_STR||b.t==V_STR){ char *sa=to_string(a),*sb=to_string(b); char *s=malloc(strlen(sa)+strlen(sb)+1); strcpy(s,sa); strcat(s,sb); a=v_str(s); free(sa); free(sb); free(s);} else a=v_num(num(a)+num(b)); } else if(match("-")) a=v_num(num(a)-num(parse_mul(env))); else return a; } }
static Value parse_rel(Env *env){ Value a=parse_add(env); for(;;){ if(match("<=")) a=v_bool(num(a)<=num(parse_add(env))); else if(match(">=")) a=v_bool(num(a)>=num(parse_add(env))); else if(match("<")) a=v_bool(num(a)<num(parse_add(env))); else if(match(">")) a=v_bool(num(a)>num(parse_add(env))); else return a; } }
static int eqv(Value a, Value b){ if(a.t==V_STR||b.t==V_STR){ char *sa=to_string(a),*sb=to_string(b); int r=!strcmp(sa,sb); free(sa);free(sb);return r;} return num(a)==num(b); }
static Value parse_eq(Env *env){ Value a=parse_rel(env); for(;;){ if(match("===")||match("==")) a=v_bool(eqv(a,parse_rel(env))); else if(match("!==")||match("!=")) a=v_bool(!eqv(a,parse_rel(env))); else return a; } }
static Value parse_and(Env *env){ Value a=parse_eq(env); while(match("&&")){ Value b=parse_eq(env); a=truthy(a)?b:a; } return a; }
static Value parse_or(Env *env){ Value a=parse_and(env); while(match("||")){ Value b=parse_and(env); a=truthy(a)?a:b; } return a; }
static char *capture_until_top(const char *stops) {
    skip_ws();
    const char *s=P; char quote=0; int par=0, br=0, brace=0;
    while(*P) {
        if(quote){ if(*P=='\\'&&P[1]) P+=2; else { if(*P==quote) quote=0; P++; } continue; }
        if(*P=='\''||*P=='"'){ quote=*P++; continue; }
        if(*P=='(') par++; else if(*P==')'){ if(!par && strchr(stops,')')) break; par--; }
        else if(*P=='[') br++; else if(*P==']'){ if(!br && strchr(stops,']')) break; br--; }
        else if(*P=='{') brace++; else if(*P=='}'){ if(!brace && strchr(stops,'}')) break; brace--; }
        if(!par && !br && !brace && strchr(stops,*P)) break;
        P++;
    }
    return xstrndup(s,P-s);
}
static Value eval_text_expr(const char *txt, Env *env) {
    const char *ss=SRC,*pp=P; SRC=txt; P=txt; Value v=parse_expr(env); SRC=ss; P=pp; return v;
}
static Value parse_cond(Env *env){
    Value a=parse_or(env);
    if(match("?")){
        char *t=capture_until_top(":"); if(*P==':') P++;
        char *f=capture_until_top(";,\n)}]");
        Value r=truthy(a)?eval_text_expr(t,env):eval_text_expr(f,env);
        free(t); free(f); return r;
    }
    return a;
}
static Value parse_assignment(Env *env) {
    skip_ws(); const char *save=P; char *id=read_ident();
    if(id){ skip_ws();
        if(match("++")){ Value v=env_get(env,id); env_set_existing_or_global(env,id,v_num(num(v)+1)); free(id); return v; }
        if(match("--")){ Value v=env_get(env,id); env_set_existing_or_global(env,id,v_num(num(v)-1)); free(id); return v; }
        if(match("+=")){ Value old=env_get(env,id), rhs=parse_assignment(env); Value v=v_num(num(old)+num(rhs)); env_set_existing_or_global(env,id,v); free(id); return v; }
        if(match("-=")){ Value old=env_get(env,id), rhs=parse_assignment(env); Value v=v_num(num(old)-num(rhs)); env_set_existing_or_global(env,id,v); free(id); return v; }
        if(match("=")){ Value v=parse_assignment(env); env_set_existing_or_global(env,id,v); free(id); return v; }
        free(id); P=save;
    }
    return parse_cond(env);
}
static Value parse_expr(Env *env){ return parse_assignment(env); }

static char *capture_statement_text(void) {
    skip_ws();
    if(*P=='{') return capture_balanced('{','}');
    const char *s=P; char quote=0; int par=0, br=0;
    while(*P) {
        if(quote){ if(*P=='\\'&&P[1])P+=2; else { if(*P==quote) quote=0; P++; } continue; }
        if(*P=='\''||*P=='"'){ quote=*P++; continue; }
        if(*P=='(') par++; else if(*P==')') par--; else if(*P=='[') br++; else if(*P==']') br--;
        if(!par && !br && (*P==';' || *P=='\n')) break;
        P++;
    }
    char *r=xstrndup(s,P-s); if(*P==';') P++; return r;
}
static void exec_statement(Env *env) {
    skip_ws(); if(!*P || env->returning) return;
    if(match(";")) return;
    const char *save=P; char *kw=read_ident();
    if(kw && (!strcmp(kw,"let")||!strcmp(kw,"var")||!strcmp(kw,"const"))) {
        do { char *id=read_ident(); Value v=v_undef(); skip_ws(); if(match("=")) v=parse_expr(env); if(id){ env_set_local(env,id,v); free(id);} skip_ws(); } while(match(","));
        match(";"); free(kw); return;
    }
    if(kw && !strcmp(kw,"function")) {
        char *name=read_ident(); char *par=capture_balanced('(',')'); char *body=capture_balanced('{','}');
        Function *f=calloc(1,sizeof(*f)); f->body=body; f->closure=env;
        const char *ss=SRC,*pp=P; SRC=par; P=par; char *pname;
        while((pname=read_ident())){ f->params=realloc(f->params,(f->argc+1)*sizeof(char*)); f->params[f->argc++]=pname; skip_ws(); match(","); }
        SRC=ss; P=pp; free(par);
        if(name){ env_set_local(env,name,v_func(f)); free(name); }
        free(kw); return;
    }
    if(kw && !strcmp(kw,"return")) { env->ret=parse_expr(env); env->returning=1; match(";"); free(kw); return; }
    if(kw && !strcmp(kw,"if")) {
        char *cond=capture_balanced('(',')'); char *thenb=capture_statement_text(); skip_ws();
        char *elseb=NULL; const char *sp=P; char *e=read_ident(); if(e && !strcmp(e,"else")) elseb=capture_statement_text(); else P=sp; free(e);
        const char *ss=SRC,*pp=P; SRC=cond; P=cond; Value cv=parse_expr(env); SRC=ss; P=pp;
        if(truthy(cv)) exec_block_text(thenb,env); else if(elseb) exec_block_text(elseb,env);
        free(cond); free(thenb); free(elseb); free(kw); return;
    }
    if(kw && !strcmp(kw,"for")) {
        char *head=capture_balanced('(',')'); char *body=capture_statement_text();
        char *a=strdup(head), *semi1=strchr(a,';'), *semi2=semi1?strchr(semi1+1,';'):NULL;
        if(semi1&&semi2){ *semi1=0; *semi2=0; exec_block_text(a,env);
            for(int guard=0; guard<100000 && !env->returning; guard++){
                const char *ss=SRC,*pp=P; SRC=semi1+1; P=semi1+1; Value cv=parse_expr(env); SRC=ss; P=pp; if(!truthy(cv)) break;
                exec_block_text(body,env); if(env->returning) break;
                ss=SRC; pp=P; SRC=semi2+1; P=semi2+1; parse_expr(env); SRC=ss; P=pp;
            }}
        free(a); free(head); free(body); free(kw); return;
    }
    if(kw && !strcmp(kw,"while")) {
        char *cond=capture_balanced('(',')'); char *body=capture_statement_text();
        for(int guard=0; guard<100000 && !env->returning; guard++){ const char *ss=SRC,*pp=P; SRC=cond; P=cond; Value cv=parse_expr(env); SRC=ss; P=pp; if(!truthy(cv)) break; exec_block_text(body,env); }
        free(cond); free(body); free(kw); return;
    }
    free(kw); P=save; parse_expr(env); match(";");
}
static void exec_block_text(const char *txt, Env *env) {
    const char *ss=SRC,*pp=P; SRC=txt; P=txt;
    while(*P && !HAD_ERROR && !env->returning) exec_statement(env);
    SRC=ss; P=pp;
}

static char *read_file(const char *path) {
    FILE *f=fopen(path,"rb"); if(!f) return NULL;
    fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET);
    char *s=malloc(n+1); if(fread(s,1,n,f)!=(size_t)n){ fclose(f); free(s); return NULL; }
    s[n]=0; fclose(f); return s;
}
static void usage(FILE *out) {
    fprintf(out,"QuickJS version 2025-09-13\n");
    fprintf(out,"usage: qjs [options] [file [args]]\n");
    fprintf(out,"-h  --help         list options\n-e  --eval EXPR    evaluate EXPR\n-i  --interactive  go to interactive mode\n-m  --module       load as ES6 module (default=autodetect)\n    --script       load as ES6 script (default=autodetect)\n    --strict       force strict mode\n-I  --include file include an additional file\n    --std          make 'std' and 'os' available to the loaded script\n-T  --trace        trace memory allocation\n-d  --dump         dump the memory usage stats\n    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)\n    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)\n    --no-unhandled-rejection  ignore unhandled promise rejections\n-s                    strip all the debug info\n    --strip-source    strip the source code\n-q  --quit         just instantiate the interpreter and quit\n");
}
static void init_args(Env *env, int argc, char **argv, int start, const char *file) {
    int len=0; Value *it=NULL;
    if(file){ len=argc-start+1; it=calloc(len,sizeof(Value)); it[0]=v_str(file); for(int i=start;i<argc;i++) it[i-start+1]=v_str(argv[i]); }
    env_set_local(env,"scriptArgs",v_array(it,len));
    env_set_local(env,"console",v_num(0));
    env_set_local(env,"Math",v_num(0));
}
int main(int argc, char **argv) {
    Env global={0};
    char *evals[128]; int ec=0; char *includes[128]; int ic=0; int file_i=0;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"-h")||!strcmp(a,"--help")){ usage(stdout); return 0; }
        else if(!strcmp(a,"-q")||!strcmp(a,"--quit")) return 0;
        else if(!strcmp(a,"-e")||!strcmp(a,"--eval")){ if(i+1<argc) evals[ec++]=argv[++i]; }
        else if(!strcmp(a,"-I")||!strcmp(a,"--include")){ if(i+1<argc) includes[ic++]=argv[++i]; }
        else if(!strcmp(a,"-m")||!strcmp(a,"--module")||!strcmp(a,"--script")||!strcmp(a,"--strict")||!strcmp(a,"--std")||!strcmp(a,"-s")||!strcmp(a,"--strip-source")||!strcmp(a,"--no-unhandled-rejection")||!strcmp(a,"-T")||!strcmp(a,"--trace")){}
        else if(!strcmp(a,"--memory-limit")||!strcmp(a,"--stack-size")){ if(i+1<argc) i++; }
        else if(!strcmp(a,"-d")||!strcmp(a,"--dump")){}
        else if(a[0]=='-'){ fprintf(stderr,"qjs: unknown option '%s'\n",a); usage(stderr); return 1; }
        else { file_i=i; break; }
    }
    init_args(&global, argc, argv, file_i?file_i+1:argc, file_i?argv[file_i]:NULL);
    for(int i=0;i<ic;i++){ char *s=read_file(includes[i]); if(!s){ fprintf(stderr,"%s: %s\n",includes[i],strerror(errno)); return 1;} FILENAME=includes[i]; exec_block_text(s,&global); free(s); }
    for(int i=0;i<ec;i++){ FILENAME="<cmdline>"; exec_block_text(evals[i],&global); }
    if(file_i){ char *s=read_file(argv[file_i]); if(!s){ fprintf(stderr,"%s: %s\n",argv[file_i],strerror(errno)); return 1;} FILENAME=argv[file_i]; exec_block_text(s,&global); free(s); }
    else if(ec==0) { char line[4096]; while(fgets(line,sizeof(line),stdin)) exec_block_text(line,&global); }
    if(HAD_ERROR) return 1;
    return 0;
}
