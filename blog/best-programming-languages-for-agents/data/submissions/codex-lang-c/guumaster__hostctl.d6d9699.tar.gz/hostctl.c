#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct { char *ip, *host; } Entry;
typedef struct { char *name, *status; Entry *entries; int n, cap; } Profile;
typedef struct { char **lines; int n, cap; Profile *profiles; int pn, pcap; } Hosts;
typedef struct {
    char *host_file, *out, *columns;
    bool quiet, raw, json, markdown;
} Opts;

static const char *INFO="\xE2\x84\xB9", *OK="\xE2\x9C\x94", *BAD="\xE2\x9C\x96";
static const char *MARK1="##################################################################";
static const char *MARK2="# Content under this line is handled by hostctl. DO NOT EDIT.";

static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(1);} return p; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1])) *--e=0; return s; }
static void add_line(Hosts *h,const char *s){ if(h->n==h->cap){h->cap=h->cap?2*h->cap:16; h->lines=realloc(h->lines,h->cap*sizeof(char*));} h->lines[h->n++]=xstrdup(s); }
static void add_entry(Profile *p,const char *ip,const char *host){ if(p->n==p->cap){p->cap=p->cap?2*p->cap:8; p->entries=realloc(p->entries,p->cap*sizeof(Entry));} p->entries[p->n].ip=xstrdup(ip); p->entries[p->n].host=xstrdup(host); p->n++; }
static Profile *profile(Hosts *h,const char *name,bool create){ for(int i=0;i<h->pn;i++) if(strcmp(h->profiles[i].name,name)==0) return &h->profiles[i]; if(!create) return NULL; if(h->pn==h->pcap){h->pcap=h->pcap?2*h->pcap:8; h->profiles=realloc(h->profiles,h->pcap*sizeof(Profile));} Profile *p=&h->profiles[h->pn++]; memset(p,0,sizeof(*p)); p->name=xstrdup(name); p->status=xstrdup("on"); return p; }

static void free_hosts(Hosts *h){
    for(int i=0;i<h->n;i++) free(h->lines[i]); free(h->lines);
    for(int i=0;i<h->pn;i++){ Profile *p=&h->profiles[i]; free(p->name); free(p->status); for(int j=0;j<p->n;j++){free(p->entries[j].ip); free(p->entries[j].host);} free(p->entries); }
    free(h->profiles);
}

static Hosts read_hosts(const char *path){
    Hosts h={0}; FILE *f=fopen(path,"r"); if(!f) return h;
    char *line=NULL; size_t sz=0; bool managed=false; Profile *cur=NULL;
    while(getline(&line,&sz,f)!=-1){
        line[strcspn(line,"\n")]=0;
        char *copy=xstrdup(line), *t=trim(copy);
        if(!managed && strcmp(t,MARK1)==0){ managed=true; free(copy); continue; }
        if(!managed){ add_line(&h,line); free(copy); continue; }
        if(strncmp(t,"# profile.",10)==0){
            char *s=t+10; char *sp=strchr(s,' ');
            if(sp){ *sp=0; cur=profile(&h,trim(sp+1),true); free(cur->status); cur->status=xstrdup(s); }
        } else if(cur && strcmp(t,"# end")!=0 && strcmp(t,MARK2)!=0 && strcmp(t,MARK1)!=0 && *t){
            if(strcmp(cur->status,"off")==0 && t[0]=='#') t=trim(t+1);
            if(t[0]!='#'){
                char *ip=strtok(t," \t"); char *host;
                while(ip && (host=strtok(NULL," \t"))) add_entry(cur,ip,host);
            }
        }
        free(copy);
    }
    free(line); fclose(f); return h;
}

static int write_hosts(const char *path, Hosts *h){
    FILE *f=fopen(path,"w"); if(!f) return -1;
    for(int i=0;i<h->n;i++) fprintf(f,"%s\n",h->lines[i]);
    fprintf(f,"\n%s\n%s\n%s\n",MARK1,MARK2,MARK1);
    for(int i=0;i<h->pn;i++){
        Profile *p=&h->profiles[i];
        fprintf(f,"\n# profile.%s %s\n",p->status,p->name);
        for(int j=0;j<p->n;j++) fprintf(f,"%s%s %s\n",strcmp(p->status,"off")==0?"# ":"",p->entries[j].ip,p->entries[j].host);
        fprintf(f,"# end\n");
    }
    fclose(f); return 0;
}

typedef struct { char *profile,*status,*ip,*host; } Row;
typedef struct { Row *r; int n, cap; } Rows;
static void row(Rows *rs,const char *p,const char *s,const char *ip,const char *host){ if(rs->n==rs->cap){rs->cap=rs->cap?2*rs->cap:16; rs->r=realloc(rs->r,rs->cap*sizeof(Row));} rs->r[rs->n++]=(Row){xstrdup(p),xstrdup(s),xstrdup(ip),xstrdup(host)}; }
static void free_rows(Rows *rs){ for(int i=0;i<rs->n;i++){free(rs->r[i].profile);free(rs->r[i].status);free(rs->r[i].ip);free(rs->r[i].host);} free(rs->r); }

static bool want_profile(int argc,char **argv,const char *p){ if(argc==0) return true; for(int i=0;i<argc;i++) if(strcmp(argv[i],p)==0) return true; return false; }
static Rows collect_list(Hosts *h,int argc,char **argv,const char *filter){
    Rows rs={0};
    if((!filter || strcmp(filter,"off")!=0) && want_profile(argc,argv,"default")){
        for(int i=0;i<h->n;i++){ char *c=xstrdup(h->lines[i]), *t=trim(c); if(*t && *t!='#'){ char *ip=strtok(t," \t"), *host; while(ip && (host=strtok(NULL," \t"))) row(&rs,"default","on",ip,host); } free(c); }
    }
    for(int i=0;i<h->pn;i++){ Profile *p=&h->profiles[i]; if(filter && strcmp(p->status,filter)!=0) continue; if(!want_profile(argc,argv,p->name)) continue; for(int j=0;j<p->n;j++) row(&rs,p->name,p->status,p->entries[j].ip,p->entries[j].host); }
    return rs;
}
static Rows collect_status(Hosts *h,int argc,char **argv){ Rows rs={0}; for(int i=0;i<h->pn;i++){ Profile *p=&h->profiles[i]; if(want_profile(argc,argv,p->name)) row(&rs,p->name,p->status,"",""); } return rs; }

static int col_index(const char *c){ if(!strcasecmp(c,"profile"))return 0; if(!strcasecmp(c,"status"))return 1; if(!strcasecmp(c,"ip"))return 2; if(!strcasecmp(c,"domain")||!strcasecmp(c,"host"))return 3; return -1; }
static int setup_cols(Opts *o, bool status, int cols[4]){
    int n=0; if(o->columns){ char *c=xstrdup(o->columns), *tok; for(tok=strtok(c,","); tok; tok=strtok(NULL,",")){ int x=col_index(trim(tok)); if(x>=0) cols[n++]=x; } free(c); }
    if(!n){ cols[n++]=0; cols[n++]=1; if(!status){ cols[n++]=2; cols[n++]=3; } }
    return n;
}
static const char *cell(Row *r,int c){ return c==0?r->profile:c==1?r->status:c==2?r->ip:r->host; }
static const char *head(int c){ return c==0?"PROFILE":c==1?"STATUS":c==2?"IP":"DOMAIN"; }
static void sep(int *w,int n,char ch){ putchar('+'); for(int i=0;i<n;i++){ for(int j=0;j<w[i]+2;j++) putchar(ch); putchar('+'); } putchar('\n'); }
static void print_rows(Rows *rs, Opts *o, bool status){
    if(o->quiet) return; int cols[4]; int cn=setup_cols(o,status,cols);
    if(o->json){ putchar('['); for(int i=0;i<rs->n;i++){ if(i) putchar(','); printf("{\"Profile\":\"%s\",\"Status\":\"%s\",\"IP\":\"%s\",\"Host\":\"%s\"}",rs->r[i].profile,rs->r[i].status,rs->r[i].ip,rs->r[i].host); } printf("]\n"); return; }
    int w[4]; for(int i=0;i<cn;i++) w[i]=strlen(head(cols[i]));
    for(int i=0;i<rs->n;i++) for(int j=0;j<cn;j++){ int l=strlen(cell(&rs->r[i],cols[j])); if(l>w[j]) w[j]=l; }
    if(o->raw){ for(int j=0;j<cn;j++) printf("%-*s%c",w[j],head(cols[j]),j==cn-1?'\n':'\t'); for(int i=0;i<rs->n;i++){ for(int j=0;j<cn;j++) printf("%-*s%c",w[j],cell(&rs->r[i],cols[j]),j==cn-1?'\n':'\t'); } return; }
    if(o->markdown){
        printf("|"); for(int j=0;j<cn;j++) printf(" %-*s |",w[j],head(cols[j])); printf("\n|"); for(int j=0;j<cn;j++){ for(int k=0;k<w[j]+2;k++) putchar('-'); putchar('|'); } putchar('\n');
        const char *last=NULL; for(int i=0;i<rs->n;i++){ if(!status && last && strcmp(last,rs->r[i].profile)!=0){ printf("|"); for(int j=0;j<cn;j++){ for(int k=0;k<w[j]+2;k++) putchar('-'); putchar('|'); } putchar('\n'); } printf("|"); for(int j=0;j<cn;j++) printf(" %-*s |",w[j],cell(&rs->r[i],cols[j])); putchar('\n'); last=rs->r[i].profile; } return;
    }
    sep(w,cn,'-'); printf("|"); for(int j=0;j<cn;j++) printf(" %-*s |",w[j],head(cols[j])); putchar('\n'); sep(w,cn,'-');
    const char *last=NULL; for(int i=0;i<rs->n;i++){ if(!status && last && strcmp(last,rs->r[i].profile)!=0) sep(w,cn,'-'); printf("|"); for(int j=0;j<cn;j++) printf(" %-*s |",w[j],cell(&rs->r[i],cols[j])); putchar('\n'); last=rs->r[i].profile; } sep(w,cn,'-');
}

static void info(Opts *o){ if(!o->quiet && !o->json) printf("[%s] Using hosts file: %s\n\n",INFO,o->host_file); }
static int errx(const char *m){ fprintf(stderr,"[%s] error: %s\n",BAD,m); return 1; }
static int read_entries_file(Profile *p,const char *path){ FILE *f=fopen(path,"r"); if(!f){ fprintf(stderr,"[%s] error: open %s: %s\n",BAD,path,strerror(errno)); return 1;} char *line=NULL; size_t sz=0; while(getline(&line,&sz,f)!=-1){ char *t=trim(line); if(!*t||*t=='#') continue; char *ip=strtok(t," \t"), *host; while(ip && (host=strtok(NULL," \t"))) add_entry(p,ip,host); } free(line); fclose(f); return 0; }

static void help_root(void){ puts("\nhostctl is a CLI tool to manage your hosts file with ease.\nYou can have multiple profiles, enable/disable exactly what\nyou need each time with a simple interface.\n\nUsage:\n  hostctl [command]\n\nAvailable Commands:\n  add         Add content to a profile in your hosts file.\n  backup      Creates a backup copy of your hosts file\n  disable     Disable a profile from your hosts file.\n  enable      Enable a profile on your hosts file.\n  help        Help about any command\n  list        Shows a detailed list of profiles on your hosts file.\n  remove      Remove a profile from your hosts file.\n  replace     Replace content to a profile in your hosts file.\n  restore     Restore hosts file content from a backup file.\n  status      Shows a list of profile names and statuses on your hosts file.\n  sync        Sync some system IPs with a profile.\n  toggle      Change status of a profile on your hosts file.\n\nFlags:\n  -c, --column strings     Column names to show on lists. comma separated\n  -h, --help               help for hostctl\n      --host-file string   Hosts file path (default \"/etc/hosts\")\n      --no-color           force colorless output\n  -o, --out string         Output type (table|raw|markdown|json) (default \"table\")\n  -q, --quiet              Run command without output\n      --raw                Output without borders (same as -o raw)\n  -v, --version            version for hostctl\n\nUse \"hostctl [command] --help\" for more information about a command."); }
static void help_cmd(const char *c,const char *sub){
    if(!strcmp(c,"add") && sub && (!strcmp(sub,"domains")||!strcmp(sub,"domain"))) puts("\nSet content in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add domains [profile] [domains] [flags]\n\nAliases:\n  domains, domain [profile] [domains] [flags]\n\nFlags:\n  -h, --help        help for domains\n      --ip string   domains ip (default \"127.0.0.1\")");
    else if(!strcmp(c,"remove") && sub && (!strcmp(sub,"domains")||!strcmp(sub,"domain"))) puts("\nCompletely remove domains from your hosts file.\nIt cannot be undone unless you have a backup and restore it.\n\nUsage:\n  hostctl remove domains [profile] [domains] [flags]\n\nAliases:\n  domains, domain [profile] [domains] [flags]\n\nFlags:\n  -h, --help   help for domains");
    else if(!strcmp(c,"add")) puts("\nReads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add [profiles] [flags]\n  hostctl add [command]\n\nAvailable Commands:\n  domains     Add content in your hosts file.\n\nFlags:\n  -f, --from string     file to read\n  -h, --help            help for add\n  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)");
    else if(!strcmp(c,"replace")) puts("\nReads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be overwritten.\n\nUsage:\n  hostctl replace [profile] [flags]\n\nFlags:\n  -f, --from string   file to read\n  -h, --help          help for replace");
    else if(!strcmp(c,"status")) puts("\nShows a list of unique profile names on your hosts file with its status.\n\nThe \"default\" profile is always on and will be skipped.\n\nUsage:\n  hostctl status [profiles] [flags]\n\nFlags:\n  -h, --help   help for status");
    else if(!strcmp(c,"list")) puts("\nShows a detailed list of profiles on your hosts file with name, ip and host name.\nYou can filter by profile name.\n\nThe \"default\" profile is all the content that is not handled by hostctl tool.\n\nUsage:\n  hostctl list [profiles] [flags]\n  hostctl list [command]\n\nAvailable Commands:\n  disabled    Shows list of disabled profiles on your hosts file.\n  enabled     Shows list of enabled profiles on your hosts file.\n\nFlags:\n  -h, --help   help for list");
    else if(!strcmp(c,"enable")) puts("\nEnables an existing profile.\nIt will be listed as \"on\" while it is enabled.\n\nUsage:\n  hostctl enable [profiles] [flags]\n\nFlags:\n      --all             Enable all profiles\n  -h, --help            help for enable\n      --only            Disable all other profiles\n  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)");
    else if(!strcmp(c,"disable")) puts("\nDisable a profile from your hosts file without removing it.\nIt will be listed as \"off\" while it is disabled.\n\nUsage:\n  hostctl disable [profiles] [flags]\n\nFlags:\n      --all             Disable all profiles\n  -h, --help            help for disable\n      --only            Enable all other profiles\n  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)");
    else if(!strcmp(c,"remove")||!strcmp(c,"rm")) puts("\nCompletely remove a profile content from your hosts file.\nIt cannot be undone unless you have a backup and restore it.\n\nIf you want to remove a profile but would like to use it later,\nuse 'hosts disable' instead.\n\nUsage:\n  hostctl remove [profiles] [flags]\n  hostctl remove [command]\n\nAliases:\n  remove, rm [profiles] [flags]\n\nAvailable Commands:\n  domains     Remove domains from your hosts file.\n\nFlags:\n      --all    Remove all profiles\n  -h, --help   help for remove");
    else if(!strcmp(c,"backup")) puts("\nCreates a backup copy of your hosts file with the date in .YYYYMMDD\nas extension.\n\nUsage:\n  hostctl backup [flags]\n\nFlags:\n  -h, --help          help for backup\n      --path string   A path to save the backup (default \"/workspace\")");
    else if(!strcmp(c,"restore")) puts("\nReads from a file and replace the content of your hosts file.\n\nWARNING: the complete hosts file will be overwritten with the backup data.\n\nUsage:\n  hostctl restore [flags]\n\nFlags:\n      --from string   The file to restore from\n  -h, --help          help for restore");
    else if(!strcmp(c,"toggle")) puts("\nAlternates between on/off status of an existing profile.\n\nUsage:\n  hostctl toggle [flags]\n\nFlags:\n  -h, --help            help for toggle\n  -w, --wait duration   Toggles a profile for a specific amount of time (default -1ns)");
    else help_root();
}

static int cmd_list(Opts *o,int argc,char **argv,const char *filter){ info(o); Hosts h=read_hosts(o->host_file); Rows rs=collect_list(&h,argc,argv,filter); print_rows(&rs,o,false); free_rows(&rs); free_hosts(&h); return 0; }
static int cmd_status(Opts *o,int argc,char **argv){ info(o); Hosts h=read_hosts(o->host_file); Rows rs=collect_status(&h,argc,argv); print_rows(&rs,o,true); free_rows(&rs); free_hosts(&h); return 0; }

static int cmd_add(Opts *o,int argc,char **argv,bool replace,bool domains){
    if(argc<1) return errx("missing profile name"); char *name=argv[0]; char *from=NULL, *ip="127.0.0.1";
    for(int i=1;i<argc;i++){ if((!strcmp(argv[i],"-f")||!strcmp(argv[i],"--from"))&&i+1<argc) from=argv[++i]; else if(!strcmp(argv[i],"--ip")&&i+1<argc) ip=argv[++i]; }
    info(o); Hosts h=read_hosts(o->host_file); Profile *p=profile(&h,name,true); if(replace){ for(int j=0;j<p->n;j++){free(p->entries[j].ip);free(p->entries[j].host);} p->n=0; free(p->status); p->status=xstrdup("on"); }
    int rc=0; if(domains){ for(int i=1;i<argc;i++){ if(!strcmp(argv[i],"--ip")){i++; continue;} if(argv[i][0]=='-') continue; add_entry(p,ip,argv[i]); } }
    else { if(!from) return errx("missing file name"); rc=read_entries_file(p,from); if(rc) { free_hosts(&h); return rc; } }
    write_hosts(o->host_file,&h); Rows rs={0}; for(int j=0;j<p->n;j++) row(&rs,p->name,p->status,p->entries[j].ip,p->entries[j].host);
    if(domains && !o->quiet && !o->json){ printf("[%s] Domains '",OK); bool first=true; for(int i=1;i<argc;i++){ if(!strcmp(argv[i],"--ip")){i++; continue;} if(argv[i][0]=='-') continue; printf("%s%s",first?"":", ",argv[i]); first=false; } printf("' added.\n\n"); }
    print_rows(&rs,o,false); free_rows(&rs); free_hosts(&h); return 0;
}

static int cmd_setstatus(Opts *o,int argc,char **argv,const char *status,bool toggle){
    bool all=false, only=false; for(int i=0;i<argc;i++){ if(!strcmp(argv[i],"--all")) all=true; if(!strcmp(argv[i],"--only")) only=true; }
    if(!all && argc<1 && !toggle) return errx("missing profile name");
    info(o); Hosts h=read_hosts(o->host_file); bool found=false; Rows rs={0};
    for(int i=0;i<h.pn;i++){
        Profile *p=&h.profiles[i]; bool sel=all;
        for(int a=0;a<argc;a++) if(argv[a][0]!='-' && strcmp(argv[a],p->name)==0) sel=true;
        if(sel){ found=true; free(p->status); p->status=xstrdup(toggle?(strcmp(p->status,"on")==0?"off":"on"):status); for(int j=0;j<p->n;j++) row(&rs,p->name,p->status,p->entries[j].ip,p->entries[j].host); }
        else if(only && !toggle){ free(p->status); p->status=xstrdup(strcmp(status,"on")==0?"off":"on"); }
    }
    if(!found){ free_hosts(&h); return errx("unknown profile name"); } write_hosts(o->host_file,&h); print_rows(&rs,o,false); free_rows(&rs); free_hosts(&h); return 0;
}

static int cmd_remove(Opts *o,int argc,char **argv,bool domains){
    if(argc<1) return errx("missing profile name"); char *name=argv[0]; info(o); Hosts h=read_hosts(o->host_file);
    if(!domains && !strcmp(name,"--all")){
        for(int i=0;i<h.pn;i++){ Profile *p=&h.profiles[i]; for(int j=0;j<p->n;j++){free(p->entries[j].ip);free(p->entries[j].host);} free(p->entries); free(p->name); free(p->status); }
        h.pn=0; write_hosts(o->host_file,&h); if(!o->quiet&&!o->json) printf("[%s] Profile(s) 'all' removed.\n\n\n",OK); free_hosts(&h); return 0;
    }
    Profile *p=profile(&h,name,false); if(!p){free_hosts(&h); return errx("unknown profile name");}
    if(domains){ for(int a=1;a<argc;a++){ for(int j=0;j<p->n;){ if(strcmp(p->entries[j].host,argv[a])==0){ free(p->entries[j].ip); free(p->entries[j].host); memmove(&p->entries[j],&p->entries[j+1],(p->n-j-1)*sizeof(Entry)); p->n--; } else j++; } } }
    else { int idx=p-h.profiles; for(int j=0;j<p->n;j++){free(p->entries[j].ip);free(p->entries[j].host);} free(p->entries); free(p->name); free(p->status); memmove(&h.profiles[idx],&h.profiles[idx+1],(h.pn-idx-1)*sizeof(Profile)); h.pn--; }
    write_hosts(o->host_file,&h); if(!o->quiet&&!o->json){ if(domains){ printf("[%s] Domains '",OK); for(int a=1;a<argc;a++) printf("%s%s",a==1?"":", ",argv[a]); printf("' removed.\n\n"); } else printf("[%s] Profile(s) '%s' removed.\n\n\n",OK,name); }
    if(domains){ Rows rs={0}; p=profile(&h,name,false); if(p) for(int j=0;j<p->n;j++) row(&rs,p->name,p->status,p->entries[j].ip,p->entries[j].host); print_rows(&rs,o,false); free_rows(&rs); }
    free_hosts(&h); return 0;
}

static int copy_file(const char *src,const char *dst){ FILE *a=fopen(src,"rb"); if(!a){fprintf(stderr,"[%s] error: open %s: %s\n",BAD,src,strerror(errno)); return 1;} FILE *b=fopen(dst,"wb"); if(!b){fprintf(stderr,"[%s] error: open %s: %s\n",BAD,dst,strerror(errno)); fclose(a); return 1;} char buf[8192]; size_t n; while((n=fread(buf,1,sizeof(buf),a))) fwrite(buf,1,n,b); fclose(a); fclose(b); return 0; }
static int cmd_backup(Opts *o){ info(o); char date[32]; time_t t=time(NULL); strftime(date,sizeof(date),"%Y%m%d",gmtime(&t)); char *dst=NULL; if(asprintf(&dst,"%s.%s",o->host_file,date)<0) return 1; int rc=copy_file(o->host_file,dst); if(!rc&&!o->quiet&&!o->json) printf("[%s] Backup '%s' created.\n\n",OK,dst); free(dst); if(!rc){ Hosts h=read_hosts(o->host_file); Rows rs=collect_list(&h,0,NULL,NULL); print_rows(&rs,o,false); free_rows(&rs); free_hosts(&h); } return rc; }
static int cmd_restore(Opts *o,int argc,char **argv){ char *from=NULL; for(int i=0;i<argc;i++) if(!strcmp(argv[i],"--from")&&i+1<argc) from=argv[++i]; if(!from) return errx("missing file name"); info(o); int rc=copy_file(from,o->host_file); if(!rc&&!o->quiet&&!o->json) printf("[%s] File '%s' restored.\n",OK,from); return rc; }

int main(int argc,char **argv){
    Opts o={.host_file="/etc/hosts",.out="table"}; char **args=calloc(argc+1,sizeof(char*)); int ac=0;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--host-file")&&i+1<argc) o.host_file=argv[++i];
        else if((!strcmp(argv[i],"-o")||!strcmp(argv[i],"--out"))&&i+1<argc) o.out=argv[++i];
        else if((!strcmp(argv[i],"-c")||!strcmp(argv[i],"--column"))&&i+1<argc) o.columns=argv[++i];
        else if((!strcmp(argv[i],"-w")||!strcmp(argv[i],"--wait"))&&i+1<argc) i++;
        else if(!strcmp(argv[i],"--raw")) o.raw=true;
        else if(!strcmp(argv[i],"-q")||!strcmp(argv[i],"--quiet")) o.quiet=true;
        else if(!strcmp(argv[i],"--no-color")) {}
        else if(!strcmp(argv[i],"-v")||!strcmp(argv[i],"--version")){ printf("hostctl version dev\n"); free(args); return 0; }
        else if((!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")) && ac==0){ help_root(); free(args); return 0; }
        else args[ac++]=argv[i];
    }
    if(!strcmp(o.out,"raw")) o.raw=true; if(!strcmp(o.out,"json")) o.json=true; if(!strcmp(o.out,"markdown")) o.markdown=true;
    if(ac==0 || !strcmp(args[0],"help")){ help_root(); free(args); return 0; }
    for(int i=0;i<ac;i++) if(!strcmp(args[i],"-h")||!strcmp(args[i],"--help")){ help_cmd(args[0], ac>1?args[1]:NULL); free(args); return 0; }
    char *cmd=args[0]; int rc=0;
    if(!strcmp(cmd,"list")){ if(ac>1 && (!strcmp(args[1],"enabled")||!strcmp(args[1],"on"))) rc=cmd_list(&o,0,NULL,"on"); else if(ac>1 && (!strcmp(args[1],"disabled")||!strcmp(args[1],"off"))) rc=cmd_list(&o,0,NULL,"off"); else rc=cmd_list(&o,ac-1,args+1,NULL); }
    else if(!strcmp(cmd,"status")) rc=cmd_status(&o,ac-1,args+1);
    else if(!strcmp(cmd,"add")){ if(ac>1 && (!strcmp(args[1],"domains")||!strcmp(args[1],"domain"))) rc=cmd_add(&o,ac-2,args+2,false,true); else rc=cmd_add(&o,ac-1,args+1,false,false); }
    else if(!strcmp(cmd,"replace")) rc=cmd_add(&o,ac-1,args+1,true,false);
    else if(!strcmp(cmd,"enable")) rc=cmd_setstatus(&o,ac-1,args+1,"on",false);
    else if(!strcmp(cmd,"disable")) rc=cmd_setstatus(&o,ac-1,args+1,"off",false);
    else if(!strcmp(cmd,"toggle")) rc=cmd_setstatus(&o,ac-1,args+1,"",true);
    else if(!strcmp(cmd,"remove")||!strcmp(cmd,"rm")){ if(ac>1 && (!strcmp(args[1],"domains")||!strcmp(args[1],"domain"))) rc=cmd_remove(&o,ac-2,args+2,true); else rc=cmd_remove(&o,ac-1,args+1,false); }
    else if(!strcmp(cmd,"backup")) rc=cmd_backup(&o);
    else if(!strcmp(cmd,"restore")) rc=cmd_restore(&o,ac-1,args+1);
    else if(!strcmp(cmd,"sync")) rc=errx("docker is not available");
    else { fprintf(stderr,"[%s] error: unknown command \"%s\" for \"hostctl\"\n",BAD,cmd); rc=1; }
    free(args); return rc;
}
