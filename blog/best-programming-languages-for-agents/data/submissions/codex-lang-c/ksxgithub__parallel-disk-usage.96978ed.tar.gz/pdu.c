#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef unsigned long long u64;

typedef struct Node {
    char *name;
    char *path;
    u64 size;
    dev_t dev;
    ino_t ino;
    nlink_t nlink;
    bool is_dir;
    struct Node **children;
    size_t len, cap;
} Node;

typedef enum { FMT_PLAIN, FMT_METRIC, FMT_BINARY } BytesFmt;
typedef enum { Q_APPARENT, Q_BLOCK_SIZE, Q_BLOCK_COUNT } Quantity;

typedef struct {
    bool json_input, json_output, dedupe, top_down, align_right, no_sort, silent;
    bool omit_details, omit_summary;
    BytesFmt fmt;
    Quantity quantity;
    int max_depth;
    double min_ratio;
    int total_width, tree_width, bar_width;
} Opt;

typedef struct Seen {
    dev_t dev;
    ino_t ino;
    u64 size;
    nlink_t links;
    char **paths;
    size_t path_len, path_cap;
    struct Seen *next;
} Seen;

static Opt opt = {
    .fmt = FMT_METRIC,
    .quantity = Q_BLOCK_SIZE,
    .max_depth = 10,
    .min_ratio = 0.01
};
static Seen *seen_head = NULL;

static void *xcalloc(size_t n, size_t s) { void *p = calloc(n, s); if (!p) { perror("calloc"); exit(2); } return p; }
static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) { perror("strdup"); exit(2); } return p; }

static char *join_path(const char *a, const char *b) {
    if (!a || !*a) return xstrdup(b);
    size_t la = strlen(a), lb = strlen(b);
    bool slash = la && a[la-1] == '/';
    char *r = xcalloc(la + lb + (slash ? 1 : 2), 1);
    memcpy(r, a, la);
    if (!slash) r[la++] = '/';
    memcpy(r + la, b, lb + 1);
    return r;
}

static Node *new_node(const char *name, const char *path) {
    Node *n = xcalloc(1, sizeof(*n));
    n->name = xstrdup(name);
    n->path = xstrdup(path ? path : name);
    return n;
}

static void add_child(Node *p, Node *c) {
    if (p->len == p->cap) {
        p->cap = p->cap ? p->cap * 2 : 8;
        p->children = realloc(p->children, p->cap * sizeof(Node*));
        if (!p->children) { perror("realloc"); exit(2); }
    }
    p->children[p->len++] = c;
}

static u64 stat_size(const struct stat *st) {
    if (opt.quantity == Q_APPARENT) return st->st_size < 0 ? 0 : (u64)st->st_size;
    if (opt.quantity == Q_BLOCK_COUNT) return st->st_blocks < 0 ? 0 : (u64)st->st_blocks;
    return st->st_blocks < 0 ? 0 : (u64)st->st_blocks * 512ULL;
}

static Seen *seen_get(dev_t dev, ino_t ino, u64 size, nlink_t links, const char *path) {
    for (Seen *s = seen_head; s; s = s->next) if (s->dev == dev && s->ino == ino) {
        if (s->path_len == s->path_cap) {
            s->path_cap = s->path_cap ? s->path_cap * 2 : 4;
            s->paths = realloc(s->paths, s->path_cap * sizeof(char*));
            if (!s->paths) { perror("realloc"); exit(2); }
        }
        s->paths[s->path_len++] = xstrdup(path);
        return s;
    }
    Seen *s = xcalloc(1, sizeof(*s));
    s->dev = dev; s->ino = ino; s->size = size; s->links = links;
    s->path_cap = 4; s->paths = xcalloc(s->path_cap, sizeof(char*));
    s->paths[s->path_len++] = xstrdup(path);
    s->next = seen_head; seen_head = s;
    return s;
}

static Node *scan_path(const char *path, const char *display, int depth) {
    struct stat st;
    if (lstat(path, &st) != 0) {
        if (!opt.silent) fprintf(stderr, "[error] symlink_metadata \"%s\": %s (os error %d)\n", path, strerror(errno), errno);
        return new_node(display ? display : path, path);
    }
    Node *n = new_node(display ? display : path, path);
    n->size = stat_size(&st);
    n->dev = st.st_dev; n->ino = st.st_ino; n->nlink = st.st_nlink;
    n->is_dir = S_ISDIR(st.st_mode);
    if (opt.dedupe && st.st_nlink > 1 && !S_ISDIR(st.st_mode)) seen_get(st.st_dev, st.st_ino, n->size, st.st_nlink, path);
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) {
            if (!opt.silent) fprintf(stderr, "[error] read_dir \"%s\": %s (os error %d)\n", path, strerror(errno), errno);
        } else {
            struct dirent *e;
            while ((e = readdir(d))) {
                if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
                char *cp = join_path(path, e->d_name);
                Node *c = scan_path(cp, e->d_name, depth + 1);
                n->size += c->size;
                if (opt.max_depth < 0 || depth + 1 < opt.max_depth) add_child(n, c);
                free(cp);
            }
            closedir(d);
        }
    }
    return n;
}

static int cmp_node(const void *a, const void *b) {
    const Node *x = *(const Node * const *)a, *y = *(const Node * const *)b;
    if (x->size < y->size) return 1;
    if (x->size > y->size) return -1;
    return strcmp(x->name, y->name);
}

static void sort_tree(Node *n) {
    if (!n) return;
    if (!opt.no_sort && n->len) qsort(n->children, n->len, sizeof(Node*), cmp_node);
    for (size_t i = 0; i < n->len; i++) sort_tree(n->children[i]);
}

static void dedupe_root(Node *root) {
    if (!opt.dedupe) return;
    for (Seen *s = seen_head; s; s = s->next) {
        if (s->path_len > 1 && root->size >= s->size * (u64)(s->path_len - 1))
            root->size -= s->size * (u64)(s->path_len - 1);
    }
}

static void fmt_size(u64 v, char *buf, size_t z) {
    if (opt.fmt == FMT_PLAIN || opt.quantity == Q_BLOCK_COUNT) { snprintf(buf, z, "%llu", v); return; }
    double base = opt.fmt == FMT_BINARY ? 1024.0 : 1000.0;
    const char *units[] = {"", "K", "M", "G", "T", "P", "E"};
    double x = (double)v; int u = 0;
    while (x >= base && u < 6) { x /= base; u++; }
    if (u == 0) snprintf(buf, z, "%llu", v);
    else if (x >= 10.0) snprintf(buf, z, "%.0f%s", x, units[u]);
    else snprintf(buf, z, "%.1f%s", x, units[u]);
}

static void json_str(const char *s) {
    putchar('"');
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') printf("\\%c", c);
        else if (c == '\n') printf("\\n");
        else if (c == '\r') printf("\\r");
        else if (c == '\t') printf("\\t");
        else if (c < 32) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

static void print_json_node(Node *n) {
    printf("{\"name\":"); json_str(n->name);
    printf(",\"size\":%llu,\"children\":[", n->size);
    for (size_t i = 0; i < n->len; i++) {
        if (i) putchar(',');
        print_json_node(n->children[i]);
    }
    printf("]}");
}

static void print_shared_json(void) {
    if (!opt.dedupe) return;
    u64 inodes = 0, links = 0, shared = 0;
    for (Seen *s = seen_head; s; s = s->next) if (s->path_len > 1) { inodes++; links += s->path_len; shared += s->size; }
    if (!inodes) return;
    printf(",\"shared\":{");
    bool comma = false;
    if (!opt.omit_details) {
        printf("\"details\":[");
        size_t j = 0;
        for (Seen *s = seen_head; s; s = s->next) if (s->path_len > 1) {
            if (j++) putchar(',');
            printf("{\"ino\":%llu,\"size\":%llu,\"links\":%llu,\"paths\":[", (u64)s->ino, s->size, (u64)s->links);
            for (size_t i = 0; i < s->path_len; i++) { if (i) putchar(','); json_str(s->paths[i]); }
            printf("]}");
        }
        printf("]");
        comma = true;
    }
    if (!opt.omit_summary) {
        if (comma) putchar(',');
        printf("\"summary\":{\"inodes\":%llu,\"exclusive_inodes\":%llu,\"all_links\":%llu,\"detected_links\":%llu,\"exclusive_links\":%llu,\"shared_size\":%llu,\"exclusive_shared_size\":%llu}",
               inodes, inodes, links, links, links, shared, shared);
    }
    printf("}");
}

static void print_json(Node *root) {
    printf("{\"schema-version\":\"2024-11-02\",\"pdu\":\"0.21.1\",\"unit\":\"%s\",\"tree\":",
           opt.quantity == Q_BLOCK_COUNT ? "blocks" : "bytes");
    print_json_node(root);
    print_shared_json();
    printf("}\n");
}

static int count_digits(u64 v) { int n = 1; while (v >= 10) { v /= 10; n++; } return n; }

static void print_bar(u64 size, u64 total, int width, bool shade) {
    double ratio = total ? (double)size / (double)total : 0.0;
    int filled = (int)(ratio * width + 0.5);
    if (filled < 0) filled = 0;
    if (filled > width) filled = width;
    int shade_len = shade && filled < width ? (width - filled) / 3 : 0;
    if (opt.align_right) {
        for (int i = 0; i < width - filled - shade_len; i++) putchar(' ');
        for (int i = 0; i < shade_len; i++) fputs("░", stdout);
        for (int i = 0; i < filled; i++) fputs("█", stdout);
    } else {
        for (int i = 0; i < filled; i++) fputs("█", stdout);
        for (int i = 0; i < shade_len; i++) fputs("░", stdout);
        for (int i = filled + shade_len; i < width; i++) putchar(' ');
    }
}

static void chart_line(Node *n, const char *prefix, const char *connector, u64 total, int sizew, int barw) {
    double ratio = total ? (double)n->size / (double)total : 0.0;
    if (n->size != total && ratio + 1e-12 < opt.min_ratio) return;
    char sbuf[64]; fmt_size(n->size, sbuf, sizeof(sbuf));
    printf("%*s %s%s%-*s│", sizew, sbuf, prefix, connector, opt.tree_width, n->name);
    print_bar(n->size, total, barw, n->size != total);
    printf("│%3.0f%%\n", ratio * 100.0);
}

static void print_chart_rec(Node *n, const char *prefix, bool last, u64 total, int sizew, int barw, int depth) {
    char conn[16];
    if (depth == 0) strcpy(conn, opt.top_down ? "└─┬" : "┌─┴");
    else if (n->len) strcpy(conn, opt.top_down ? (last ? "└─┬" : "├─┬") : (last ? "└─┴" : "├─┴"));
    else strcpy(conn, opt.top_down ? (last ? "└──" : "├──") : (last ? "└──" : "├──"));
    if (opt.top_down) chart_line(n, prefix, conn, total, sizew, barw);
    char next[1024];
    snprintf(next, sizeof(next), "%s%s", prefix, depth == 0 ? "  " : (last ? "  " : "│ "));
    for (size_t i = 0; i < n->len; i++) {
        print_chart_rec(n->children[i], next, i == n->len - 1, total, sizew, barw, depth + 1);
    }
    if (!opt.top_down) chart_line(n, prefix, conn, total, sizew, barw);
}

static void max_size_width(Node *n, int *w) {
    char b[64]; fmt_size(n->size, b, sizeof(b));
    int l = (int)strlen(b);
    if (l > *w) *w = l;
    for (size_t i = 0; i < n->len; i++) max_size_width(n->children[i], w);
}

static void print_chart(Node *root) {
    int sizew = count_digits(root->size);
    max_size_width(root, &sizew);
    if (opt.tree_width <= 0) opt.tree_width = 12;
    int barw = opt.bar_width;
    if (barw <= 0) {
        if (opt.total_width > 0) {
            barw = opt.total_width - sizew - opt.tree_width - 8;
            if (barw < 5) barw = 5;
        } else barw = 122;
    }
    print_chart_rec(root, "", true, root->size, sizew, barw, 0);
    if (opt.dedupe) {
        u64 inodes = 0, links = 0, shared = 0;
        for (Seen *s = seen_head; s; s = s->next) if (s->path_len > 1) { inodes++; links += s->path_len; shared += s->size; }
        if (inodes) {
            char b[64]; fmt_size(shared, b, sizeof(b));
            printf("Hardlinks detected! No files have links outside this tree\n");
            printf("* Number of shared inodes: %llu\n* Total number of links: %llu\n* Total shared size: %s\n", inodes, links, b);
        }
    }
}

static char *read_all_stdin(void) {
    size_t cap = 4096, len = 0; char *buf = xcalloc(cap, 1);
    int c;
    while ((c = getchar()) != EOF) {
        if (len + 2 >= cap) { cap *= 2; buf = realloc(buf, cap); if (!buf) exit(2); }
        buf[len++] = (char)c;
    }
    buf[len] = 0; return buf;
}

typedef struct { const char *p; } Parser;
static void ws(Parser *ps) { while (*ps->p == ' ' || *ps->p == '\n' || *ps->p == '\r' || *ps->p == '\t') ps->p++; }
static bool lit(Parser *ps, const char *s) { ws(ps); size_t n = strlen(s); if (!strncmp(ps->p, s, n)) { ps->p += n; return true; } return false; }
static char *parse_string(Parser *ps) {
    ws(ps); if (*ps->p != '"') return xstrdup(""); ps->p++;
    char *out = xcalloc(strlen(ps->p) + 1, 1); size_t k = 0;
    while (*ps->p && *ps->p != '"') {
        if (*ps->p == '\\') {
            ps->p++;
            if (*ps->p == 'n') out[k++] = '\n';
            else if (*ps->p == 'r') out[k++] = '\r';
            else if (*ps->p == 't') out[k++] = '\t';
            else if (*ps->p) out[k++] = *ps->p;
            if (*ps->p) ps->p++;
        } else out[k++] = *ps->p++;
    }
    if (*ps->p == '"') ps->p++;
    out[k] = 0; return out;
}
static u64 parse_num(Parser *ps) { ws(ps); u64 v = 0; while (*ps->p >= '0' && *ps->p <= '9') v = v * 10 + (u64)(*ps->p++ - '0'); return v; }
static void skip_value(Parser *ps);
static void skip_array(Parser *ps) { lit(ps, "["); while (1) { ws(ps); if (lit(ps, "]")) return; skip_value(ps); lit(ps, ","); } }
static void skip_object(Parser *ps) { lit(ps, "{"); while (1) { ws(ps); if (lit(ps, "}")) return; char *k = parse_string(ps); free(k); lit(ps, ":"); skip_value(ps); lit(ps, ","); } }
static void skip_value(Parser *ps) {
    ws(ps);
    if (*ps->p == '"') { char *s = parse_string(ps); free(s); }
    else if (*ps->p == '{') skip_object(ps);
    else if (*ps->p == '[') skip_array(ps);
    else while (*ps->p && !strchr(",]}", *ps->p)) ps->p++;
}
static Node *parse_node(Parser *ps) {
    Node *n = new_node("", "");
    lit(ps, "{");
    while (1) {
        ws(ps); if (lit(ps, "}")) break;
        char *key = parse_string(ps); lit(ps, ":");
        if (!strcmp(key, "name")) { free(n->name); n->name = parse_string(ps); }
        else if (!strcmp(key, "size")) n->size = parse_num(ps);
        else if (!strcmp(key, "children")) {
            lit(ps, "[");
            while (1) { ws(ps); if (lit(ps, "]")) break; add_child(n, parse_node(ps)); lit(ps, ","); }
        } else skip_value(ps);
        free(key); lit(ps, ",");
    }
    return n;
}
static Node *parse_json_tree(char *s) {
    Parser ps = {s};
    if (!strstr(s, "\"schema-version\"")) fprintf(stderr, "[error] DeserializationFailure: missing field `schema-version`\n");
    char *t = strstr(s, "\"tree\"");
    if (!t) return new_node("(empty)", "(empty)");
    ps.p = strchr(t, ':'); if (!ps.p) return new_node("(empty)", "(empty)");
    ps.p++;
    return parse_node(&ps);
}

static void usage_short(void) {
    puts("Summarize disk usage of the set of files, recursively for directories.\n");
    puts("Usage: executable [OPTIONS] [FILES]...\n");
    puts("Arguments:\n  [FILES]...  List of files and/or directories\n");
    puts("Options:");
    puts("      --json-input\n      --json-output");
    puts("  -b, --bytes-format <BYTES_FORMAT> [default: metric] [possible values: plain, metric, binary]");
    puts("  -H, --deduplicate-hardlinks");
    puts("      --top-down\n      --align-right");
    puts("  -q, --quantity <QUANTITY> [default: block-size] [possible values: apparent-size, block-size, block-count]");
    puts("  -d, --max-depth <MAX_DEPTH> [default: 10]");
    puts("  -w, --total-width <TOTAL_WIDTH>");
    puts("      --column-width <TREE_WIDTH> <BAR_WIDTH>");
    puts("  -m, --min-ratio <MIN_RATIO> [default: 0.01]");
    puts("      --no-sort\n  -s, --silent-errors\n  -p, --progress\n      --threads <THREADS>");
    puts("      --omit-json-shared-details\n      --omit-json-shared-summary");
    puts("  -h, --help\n  -V, --version");
}

static void set_arg_value(int *i, int argc, char **argv, const char *cur, const char *eq, const char **val) {
    if (eq) *val = eq + 1;
    else {
        if (*i + 1 >= argc) { fprintf(stderr, "error: a value is required for '%s'\n", cur); exit(2); }
        *val = argv[++(*i)];
    }
}

int main(int argc, char **argv) {
    char **files = xcalloc(argc + 2, sizeof(char*));
    int filec = 0;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage_short(); return 0; }
        if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("pdu 0.21.1"); return 0; }
        if (!strcmp(a, "--json-input")) opt.json_input = true;
        else if (!strcmp(a, "--json-output")) opt.json_output = true;
        else if (!strcmp(a, "-H") || !strcmp(a, "--deduplicate-hardlinks") || !strcmp(a, "--detect-links") || !strcmp(a, "--dedupe-links")) opt.dedupe = true;
        else if (!strcmp(a, "--top-down")) opt.top_down = true;
        else if (!strcmp(a, "--align-right")) opt.align_right = true;
        else if (!strcmp(a, "--no-sort")) opt.no_sort = true;
        else if (!strcmp(a, "-s") || !strcmp(a, "--silent-errors") || !strcmp(a, "--no-errors")) opt.silent = true;
        else if (!strcmp(a, "-p") || !strcmp(a, "--progress")) {}
        else if (!strcmp(a, "--omit-json-shared-details")) opt.omit_details = true;
        else if (!strcmp(a, "--omit-json-shared-summary")) opt.omit_summary = true;
        else if (!strncmp(a, "--bytes-format", 14) || !strcmp(a, "-b")) {
            const char *v, *eq = strchr(a, '='); set_arg_value(&i, argc, argv, a, eq, &v);
            if (!strcmp(v, "plain")) opt.fmt = FMT_PLAIN; else if (!strcmp(v, "binary")) opt.fmt = FMT_BINARY; else opt.fmt = FMT_METRIC;
        } else if (!strncmp(a, "--quantity", 10) || !strcmp(a, "-q")) {
            const char *v, *eq = strchr(a, '='); set_arg_value(&i, argc, argv, a, eq, &v);
            if (!strcmp(v, "apparent-size")) opt.quantity = Q_APPARENT; else if (!strcmp(v, "block-count")) opt.quantity = Q_BLOCK_COUNT; else opt.quantity = Q_BLOCK_SIZE;
        } else if (!strncmp(a, "--max-depth", 11) || !strncmp(a, "--depth", 7) || !strcmp(a, "-d")) {
            const char *v, *eq = strchr(a, '='); set_arg_value(&i, argc, argv, a, eq, &v);
            opt.max_depth = !strcmp(v, "inf") ? -1 : atoi(v);
        } else if (!strncmp(a, "--total-width", 13) || !strncmp(a, "--width", 7) || !strcmp(a, "-w")) {
            const char *v, *eq = strchr(a, '='); set_arg_value(&i, argc, argv, a, eq, &v); opt.total_width = atoi(v);
        } else if (!strcmp(a, "--column-width")) {
            if (i + 2 >= argc) { fprintf(stderr, "error: --column-width requires two values\n"); return 2; }
            opt.tree_width = atoi(argv[++i]); opt.bar_width = atoi(argv[++i]);
        } else if (!strncmp(a, "--min-ratio", 11) || !strcmp(a, "-m")) {
            const char *v, *eq = strchr(a, '='); set_arg_value(&i, argc, argv, a, eq, &v); opt.min_ratio = atof(v);
        } else if (!strncmp(a, "--threads", 9)) {
            const char *v, *eq = strchr(a, '='); set_arg_value(&i, argc, argv, a, eq, &v); (void)v;
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s'\n", a); return 2;
        } else files[filec++] = a;
    }

    Node *root = NULL;
    if (opt.json_input) {
        char *buf = read_all_stdin();
        root = parse_json_tree(buf);
    } else {
        if (filec == 0) files[filec++] = ".";
        if (filec == 1) root = scan_path(files[0], files[0], 0);
        else {
            root = new_node("(total)", "(total)");
            for (int i = 0; i < filec; i++) {
                Node *c = scan_path(files[i], files[i], 0);
                root->size += c->size;
                add_child(root, c);
            }
        }
        dedupe_root(root);
    }
    sort_tree(root);
    if (opt.json_output) print_json(root);
    else print_chart(root);
    return 0;
}
