#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

typedef struct {
    char *text;
    int line;
    int col;
    int err;
} Error;

typedef struct {
    Error *v;
    int n;
    int cap;
} Errors;

typedef struct {
    char *name;
    char *value;
} Var;

typedef struct {
    Var *v;
    int n;
    int cap;
} Vars;

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { perror("strdup"); exit(1); }
    return r;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (n < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)n + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0;
    fclose(f);
    return buf;
}

static void add_error(Errors *e, int line, int col, const char *fmt, ...) {
    if (e->n == e->cap) {
        e->cap = e->cap ? e->cap * 2 : 16;
        e->v = realloc(e->v, (size_t)e->cap * sizeof(Error));
        if (!e->v) exit(1);
    }
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    e->v[e->n++] = (Error){xstrdup(buf), line, col, 1};
}

static void print_errors(const char *path, Errors *e) {
    for (int i = 0; i < e->n; i++)
        fprintf(stderr, "Error: %s (line %d, column %d) - %s\n",
                path, e->v[i].line, e->v[i].col, e->v[i].text);
}

static bool is_ident0(int c) { return isalpha(c) || c == '_'; }
static bool is_ident(int c) { return isalnum(c) || c == '_'; }

static bool is_keyword(const char *s) {
    const char *kw[] = {"let","if","then","else","end","function","return","for","in","do",
        "while","and","or","not","true","false","nil","self","std", NULL};
    for (int i = 0; kw[i]; i++) if (!strcmp(s, kw[i])) return true;
    return false;
}

static void vars_add(Vars *vs, const char *name, const char *val) {
    for (int i = 0; i < vs->n; i++) if (!strcmp(vs->v[i].name, name)) {
        free(vs->v[i].value); vs->v[i].value = xstrdup(val); return;
    }
    if (vs->n == vs->cap) {
        vs->cap = vs->cap ? vs->cap * 2 : 16;
        vs->v = realloc(vs->v, (size_t)vs->cap * sizeof(Var));
        if (!vs->v) exit(1);
    }
    vs->v[vs->n++] = (Var){xstrdup(name), xstrdup(val)};
}

static const char *vars_get(Vars *vs, const char *name) {
    for (int i = vs->n - 1; i >= 0; i--) if (!strcmp(vs->v[i].name, name)) return vs->v[i].value;
    return NULL;
}

static char *norm_number(const char *src, int len) {
    char tmp[128];
    if (len >= (int)sizeof(tmp)) len = (int)sizeof(tmp) - 1;
    memcpy(tmp, src, (size_t)len); tmp[len] = 0;
    if (strchr(tmp, 'e') || strchr(tmp, 'E')) {
        double d = strtod(tmp, NULL);
        double rd = d < 0 ? d - 0.5 : d + 0.5;
        long long ll = (long long)rd;
        char out[128];
        snprintf(out, sizeof(out), "%lld", ll);
        return xstrdup(out);
    }
    return xstrdup(tmp);
}

static char *scan_string(const char *s, int *i, int *line, int *col, Errors *errs, bool lex_stdout) {
    int start = *i, quote = s[*i], l = *line, c = *col;
    (*i)++; (*col)++;
    bool bad = false;
    while (s[*i] && s[*i] != quote) {
        if (s[*i] == '\\') {
            char n = s[*i + 1];
            if (!(n == 'n' || n == 't' || n == 'r' || n == '\\' || n == '"' || n == '\'' || n == '0' || n == '$')) {
                add_error(errs, *line, *col, "invalid escape sequence '\\%c'.", n ? n : ' ');
                if (lex_stdout) printf("Error: line %d, column %d - invalid escape sequence '\\%c'.\n", *line, *col, n ? n : ' ');
                bad = true;
            }
            if (n) { *i += 2; *col += 2; } else break;
        } else {
            if (s[*i] == '\n') { (*line)++; *col = 0; (*i)++; }
            else { (*i)++; (*col)++; }
        }
    }
    if (s[*i] == quote) { (*i)++; (*col)++; }
    if (bad) {
        char z[5] = {quote, '\\', '0', quote, 0};
        return xstrdup(z);
    }
    int len = *i - start;
    char *r = malloc((size_t)len + 1);
    memcpy(r, s + start, (size_t)len); r[len] = 0;
    (void)l; (void)c;
    return r;
}

static void emit_token(const char *path, int line, int col, const char *tok) {
    printf("%s (line %d, column %d):\t%s\n", path, line, col, tok);
}

static bool is_unexpected_outside(const char *tok) {
    return !strcmp(tok, "|") || !strcmp(tok, ";") || !strcmp(tok, "$") || !strcmp(tok, "@") || !strcmp(tok, "}");
}

static void collect_decl(const char *s, Vars *vars) {
    int line = 1, col = 0;
    for (int i = 0; s[i]; ) {
        if (isspace((unsigned char)s[i])) { if (s[i++] == '\n') { line++; col = 0; } else col++; continue; }
        if (s[i] == '#') { while (s[i] && s[i] != '\n') i++, col++; continue; }
        if (!strncmp(s + i, "let", 3) && !is_ident(s[i+3])) {
            i += 3; col += 3;
            while (isspace((unsigned char)s[i]) && s[i] != '\n') i++, col++;
            while (s[i] && !is_ident0(s[i]) && s[i] != '\n') i++, col++;
            if (is_ident0(s[i])) {
                int st = i;
                while (is_ident(s[i])) i++, col++;
                char name[128]; int len = i - st; if (len > 127) len = 127;
                memcpy(name, s + st, (size_t)len); name[len] = 0;
                vars_add(vars, name, "");
            }
        } else if (!strncmp(s + i, "function", 8) && !is_ident(s[i+8])) {
            i += 8; col += 8;
            while (isspace((unsigned char)s[i]) && s[i] != '\n') i++, col++;
            if (is_ident0(s[i])) {
                int st = i;
                while (is_ident(s[i])) i++, col++;
                char name[128]; int len = i - st; if (len > 127) len = 127;
                memcpy(name, s + st, (size_t)len); name[len] = 0;
                vars_add(vars, name, "");
            }
        } else { i++; col++; }
        (void)line;
    }
}

static void lex_file(const char *path, const char *s, bool print, Errors *errs, Vars *vars) {
    int line = 1, col = 0, cmd_depth = 0;
    if (print) printf("--------------------------------------------------\n");
    for (int i = 0; s[i]; ) {
        unsigned char ch = (unsigned char)s[i];
        if (ch == '\n') { i++; line++; col = 0; continue; }
        if (isspace(ch)) { i++; col++; continue; }
        if (ch == '#') { while (s[i] && s[i] != '\n') i++, col++; continue; }
        int l = line, c = col;
        char *tok = NULL;
        if ((s[i] == '$' || s[i] == '&') && s[i+1] == '{') {
            tok = malloc(3); tok[0] = s[i]; tok[1] = '{'; tok[2] = 0; i += 2; col += 2; cmd_depth++;
        } else if (cmd_depth > 0 && s[i] == '$' && is_ident0(s[i+1])) {
            int st = ++i; col++;
            while (is_ident(s[i])) i++, col++;
            int len = i - st;
            char name[128]; if (len > 127) len = 127; memcpy(name, s+st, (size_t)len); name[len]=0;
            tok = malloc((size_t)len + 7);
            sprintf(tok, "${{%s}}", name);
        } else if (s[i] == '"' || s[i] == '\'') {
            tok = scan_string(s, &i, &line, &col, errs, print);
        } else if (isdigit(ch)) {
            int st = i;
            while (isdigit((unsigned char)s[i])) i++, col++;
            if (s[i] == '.') { i++; col++; while (isdigit((unsigned char)s[i])) i++, col++; }
            if (s[i] == 'e' || s[i] == 'E') { i++; col++; if (s[i]=='+'||s[i]=='-') i++, col++; while (isdigit((unsigned char)s[i])) i++, col++; }
            tok = norm_number(s + st, i - st);
        } else if (is_ident0(ch)) {
            int st = i;
            while (is_ident((unsigned char)s[i])) i++, col++;
            int len = i - st;
            tok = malloc((size_t)len + 1); memcpy(tok, s+st, (size_t)len); tok[len] = 0;
        } else {
            if (!strncmp(s+i, "++", 2) || !strncmp(s+i, "<<", 2) || !strncmp(s+i, ">>", 2) ||
                !strncmp(s+i, "==", 2) || !strncmp(s+i, "!=", 2) || !strncmp(s+i, "<=", 2) || !strncmp(s+i, ">=", 2)) {
                tok = malloc(3); tok[0] = s[i]; tok[1] = s[i+1]; tok[2] = 0; i += 2; col += 2;
            } else {
                tok = malloc(2); tok[0] = s[i]; tok[1] = 0; i++; col++;
            }
            int before_depth = cmd_depth;
            if (!strcmp(tok, "{")) cmd_depth++;
            if (!strcmp(tok, "}")) { if (cmd_depth > 0) cmd_depth--; }
            if (before_depth == 0 && cmd_depth == 0 && is_unexpected_outside(tok)) {
                add_error(errs, l, c, "unexpected '%s'.", tok);
                if (print) printf("Error: line %d, column %d - unexpected '%s'.\n", l, c, tok);
            }
        }
        if (print && tok) emit_token(path, l, c, tok);
        free(tok);
    }
    if (print) printf("--------------------------------------------------\n");
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static void simple_ast_program(const char *path, const char *s, bool program) {
    printf("--------------------------------------------------\n");
    printf("%s for %s\n", program ? "Program" : "AST", path);
    if (program) printf("let #0: auto\n");
    int id = 1;
    char *copy = xstrdup(s);
    for (char *line = strtok(copy, "\n"); line; line = strtok(NULL, "\n")) {
        char *p = trim(line);
        if (!*p || *p == '#') continue;
        if (!strncmp(p, "let ", 4)) {
            char *name = p + 4;
            while (isspace((unsigned char)*name)) name++;
            char *eq = strchr(name, '=');
            if (program) {
                printf("let #%d: auto\n", id);
                if (eq) printf("#%d = %s\n", id, trim(eq + 1)); else printf("#%d = nil\n", id);
            } else {
                if (eq) { *eq = 0; printf("let %s = %s\n", trim(name), trim(eq + 1)); }
                else printf("let %s = nil\n", trim(name));
            }
            id++;
        } else if (!strncmp(p, "{", 1) || !strncmp(p, "${", 2) || !strncmp(p, "&{", 2)) {
            printf("%s\n", p);
        } else {
            printf("%s\n", p);
        }
    }
    free(copy);
    printf("--------------------------------------------------\n");
}

static void static_check(const char *s, Errors *errs, Vars *vars) {
    collect_decl(s, vars);
    int line = 1, col = 0, cmd = 0;
    for (int i = 0; s[i]; ) {
        if (s[i] == '\n') { i++; line++; col = 0; continue; }
        if (isspace((unsigned char)s[i])) { i++; col++; continue; }
        if (s[i] == '#') { while (s[i] && s[i] != '\n') i++, col++; continue; }
        if ((s[i] == '$' || s[i] == '&') && s[i+1] == '{') { cmd++; i+=2; col+=2; continue; }
        if (s[i] == '{') { cmd++; i++; col++; continue; }
        if (s[i] == '}') { if (cmd>0) cmd--; i++; col++; continue; }
        if (cmd && s[i] == '$' && is_ident0(s[i+1])) {
            int l=line,c=col, st=++i; col++;
            while (is_ident((unsigned char)s[i])) i++, col++;
            char name[128]; int len=i-st; if(len>127)len=127; memcpy(name,s+st,(size_t)len); name[len]=0;
            if (!vars_get(vars, name)) add_error(errs, l, c, "undeclared variable '%s'", name);
            continue;
        }
        if (!cmd && is_ident0((unsigned char)s[i])) {
            int l=line,c=col, st=i;
            while (is_ident((unsigned char)s[i])) i++, col++;
            char name[128]; int len=i-st; if(len>127)len=127; memcpy(name,s+st,(size_t)len); name[len]=0;
            if (c > 0 && s[st - 1] == '.') continue;
            if (!is_keyword(name) && !vars_get(vars, name)) add_error(errs, l, c, "undeclared variable '%s'", name);
            continue;
        }
        if (s[i] == '"' || s[i] == '\'') {
            char q=s[i++]; col++;
            while (s[i] && s[i] != q) {
                if (s[i]=='\\' && s[i+1]) { i+=2; col+=2; }
                else if (cmd && s[i] == '$' && is_ident0((unsigned char)s[i+1])) {
                    int l=line,c=col, st=++i; col++;
                    while (is_ident((unsigned char)s[i])) i++, col++;
                    char name[128]; int len=i-st; if(len>127)len=127; memcpy(name,s+st,(size_t)len); name[len]=0;
                    if (!vars_get(vars, name)) add_error(errs, l, c, "undeclared variable '%s'", name);
                } else if (s[i++]=='\n') { line++; col=0; } else col++;
            }
            if (s[i]==q) i++, col++;
        } else { i++; col++; }
    }
}

static void assign_simple_vars(const char *s, Vars *vars) {
    char *copy = xstrdup(s);
    for (char *ln = strtok(copy, "\n"); ln; ln = strtok(NULL, "\n")) {
        char *p = trim(ln);
        if (strncmp(p, "let ", 4)) continue;
        p = trim(p + 4);
        char *eq = strchr(p, '=');
        if (!eq) continue;
        *eq = 0;
        char *name = trim(p), *val = trim(eq + 1);
        if ((*val == '"' || *val == '\'') && val[strlen(val)-1] == *val) {
            val[strlen(val)-1] = 0; val++;
        }
        vars_add(vars, name, val);
    }
    free(copy);
}

static char *expand_vars(const char *cmd, Vars *vars) {
    size_t cap = strlen(cmd) * 2 + 64, n = 0;
    char *out = malloc(cap);
    for (int i = 0; cmd[i]; ) {
        if (cmd[i] == '$' && is_ident0((unsigned char)cmd[i+1])) {
            int st = ++i;
            while (is_ident((unsigned char)cmd[i])) i++;
            char name[128]; int len=i-st; if(len>127)len=127; memcpy(name,cmd+st,(size_t)len); name[len]=0;
            const char *v = vars_get(vars, name); if (!v) v = "";
            size_t vl = strlen(v);
            if (n + vl + 1 > cap) { cap = (n + vl + 1) * 2; out = realloc(out, cap); }
            memcpy(out+n, v, vl); n += vl;
        } else {
            if (n + 2 > cap) { cap *= 2; out = realloc(out, cap); }
            out[n++] = cmd[i++];
        }
    }
    out[n] = 0;
    return out;
}

static int run_shell_line(const char *cmd) {
    int rc = system(cmd);
    if (rc == -1) return 127;
    if (WIFEXITED(rc)) return WEXITSTATUS(rc);
    return 127;
}

static int run_blocks(const char *s, Vars *vars) {
    int status = 0;
    for (int i = 0; s[i]; i++) {
        if (s[i] == '{' && (i == 0 || s[i-1] != '$')) {
            int st = i + 1, depth = 1, j = st;
            for (; s[j]; j++) {
                if (s[j] == '{') depth++;
                else if (s[j] == '}' && --depth == 0) break;
            }
            char *body = strndup(s + st, (size_t)(j - st));
            char *save = NULL;
            for (char *part = strtok_r(body, ";", &save); part; part = strtok_r(NULL, ";", &save)) {
                char *cmd = trim(part);
                if (!*cmd || *cmd == '#') continue;
                char *hash = strchr(cmd, '#'); if (hash) *hash = 0;
                cmd = trim(cmd);
                if (!*cmd) continue;
                char *expanded = expand_vars(cmd, vars);
                status = run_shell_line(expanded);
                free(expanded);
                if (status != 0) break;
            }
            free(body);
            i = j;
        }
    }
    return status;
}

static void help(void) {
    puts("Hush 0.1.4");
    puts("gahag <gabriel.s.b@live.com>");
    puts("Hush is a unix shell scripting language based on the Lua programming language\n");
    puts("USAGE:");
    puts("    executable [FLAGS] [arguments]...\n");
    puts("FLAGS:");
    puts("        --ast        Print the AST");
    puts("        --check      Perform only static analysis instead of executing.");
    puts("    -h, --help       Prints help information");
    puts("        --lex        Print the lexemes");
    puts("        --program    Print the PROGAM");
    puts("    -V, --version    Prints version information\n");
    puts("ARGS:");
    puts("    <arguments>...    Script and/or arguments");
}

int main(int argc, char **argv) {
    bool f_lex=false, f_ast=false, f_prog=false, f_check=false;
    const char *script = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) { help(); return 0; }
        else if (!strcmp(argv[i], "--version") || !strcmp(argv[i], "-V")) { puts("Hush 0.1.4"); return 0; }
        else if (!strcmp(argv[i], "--lex")) f_lex = true;
        else if (!strcmp(argv[i], "--ast")) f_ast = true;
        else if (!strcmp(argv[i], "--program")) f_prog = true;
        else if (!strcmp(argv[i], "--check")) f_check = true;
        else if (!script) script = argv[i];
    }
    if (!script) return 0;
    char *src = read_file(script);
    if (!src) { fprintf(stderr, "Error: failed to read '%s': %s\n", script, strerror(errno)); return 1; }
    Errors errs = {0};
    Vars vars = {0};
    collect_decl(src, &vars);
    if (f_lex) lex_file(script, src, true, &errs, &vars);
    else lex_file(script, src, false, &errs, &vars);
    static_check(src, &errs, &vars);
    if (f_ast) simple_ast_program(script, src, false);
    if (f_prog) simple_ast_program(script, src, true);
    print_errors(script, &errs);
    if (errs.n) return 2;
    if (f_check) return 0;
    assign_simple_vars(src, &vars);
    int st = run_blocks(src, &vars);
    return st;
}
