#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct Item {
    char *scope;
    char *text;
    char *hash;
    char *body;
    struct Item *next;
} Item;

typedef struct Section {
    const char *title;
    int order;
    Item *items;
    Item *tail;
    struct Section *next;
} Section;

typedef struct {
    char *repository, *from, *to, *format, *git_dir, *work_tree, *subtitle;
    char *outfile, *config, *infile, *setversion, *link_style, *changelog;
    bool major, minor, patch, from_latest_tag;
} Opt;

static char *xstrdup(const char *s) {
    if (!s) return NULL;
    char *r = strdup(s);
    if (!r) { perror("strdup"); exit(2); }
    return r;
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static char *shell_quote(const char *s) {
    size_t n = 3;
    for (const char *p = s ? s : ""; *p; p++) n += (*p == '\'') ? 4 : 1;
    char *r = malloc(n), *q = r;
    *q++ = '\'';
    for (const char *p = s ? s : ""; *p; p++) {
        if (*p == '\'') { memcpy(q, "'\\''", 4); q += 4; }
        else *q++ = *p;
    }
    *q++ = '\'';
    *q = 0;
    return r;
}

static char *run_capture(const char *cmd) {
    FILE *p = popen(cmd, "r");
    if (!p) return NULL;
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) exit(2);
    int c;
    while ((c = fgetc(p)) != EOF) {
        if (len + 2 >= cap) { cap *= 2; buf = realloc(buf, cap); if (!buf) exit(2); }
        buf[len++] = (char)c;
    }
    int st = pclose(p);
    if (st != 0) { free(buf); return NULL; }
    buf[len] = 0;
    while (len && (buf[len-1] == '\n' || buf[len-1] == '\r')) buf[--len] = 0;
    return buf;
}

static void today(char out[11]) {
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    strftime(out, 11, "%Y-%m-%d", &tmv);
}

static void usage(FILE *f) {
    fprintf(f, "a conventional changelog for the rest of us\n\n");
    fprintf(f, "Usage: executable [OPTIONS]\n\nOptions:\n");
    fprintf(f, "  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,\n");
    fprintf(f, "                          e.g. https://github.com/thoughtram/clog)\n");
    fprintf(f, "  -f, --from <COMMIT>     e.g. 12a8546\n");
    fprintf(f, "  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible\n");
    fprintf(f, "                          values: markdown, json]\n");
    fprintf(f, "  -M, --major             Increment major version by one (Sets minor and patch to 0)\n");
    fprintf(f, "  -g, --git-dir <PATH>    Local .git directory (defaults to \"$(pwd)/.git\")\n");
    fprintf(f, "  -w, --work-tree <PATH>  Local working tree of the git project (defaults to \"$(pwd)\")\n");
    fprintf(f, "  -m, --minor             Increment minor version by one (Sets patch to 0)\n");
    fprintf(f, "  -p, --patch             Increment patch version by one\n");
    fprintf(f, "  -s, --subtitle <STR>    \n");
    fprintf(f, "  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]\n");
    fprintf(f, "  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)\n");
    fprintf(f, "  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]\n");
    fprintf(f, "  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with\n");
    fprintf(f, "                          --outfile)\n");
    fprintf(f, "      --setversion <VER>  e.g. 1.0.1\n");
    fprintf(f, "  -F, --from-latest-tag   use latest tag as start (instead of --from)\n");
    fprintf(f, "  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible\n");
    fprintf(f, "                          values: github, gitlab, stash, cgit]\n");
    fprintf(f, "  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the\n");
    fprintf(f, "                          same file for both --infile and --outfile and should not be used in\n");
    fprintf(f, "                          conjunction with either)\n");
    fprintf(f, "  -h, --help              Print help\n");
    fprintf(f, "  -V, --version           Print version\n");
}

static void parse_config(Opt *o) {
    FILE *f = fopen(o->config, "r");
    if (!f) return;
    char line[4096];
    while (fgets(line, sizeof line, f)) {
        char *s = trim(line);
        if (*s == '#' || *s == '[' || !*s) continue;
        char *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = 0;
        char *k = trim(s), *v = trim(eq + 1);
        if (*v == '"') {
            v++;
            char *e = strrchr(v, '"');
            if (e) *e = 0;
        }
        if (!strcmp(k, "repository") && !o->repository) o->repository = xstrdup(v);
        else if (!strcmp(k, "from-latest-tag")) o->from_latest_tag = strstr(v, "true") != NULL;
        else if (!strcmp(k, "link-style") && !o->link_style) o->link_style = xstrdup(v);
        else if (!strcmp(k, "subtitle") && !o->subtitle) o->subtitle = xstrdup(v);
        else if (!strcmp(k, "changelog") && !o->changelog) o->changelog = xstrdup(v);
    }
    fclose(f);
}

static const char *section_for(const char *type, bool breaking, int *order) {
    if (breaking) { *order = 0; return "Breaking Changes"; }
    if (!strcmp(type, "feat") || !strcmp(type, "feature")) { *order = 1; return "Features"; }
    if (!strcmp(type, "fix") || !strcmp(type, "bugfix")) { *order = 2; return "Bug Fixes"; }
    if (!strcmp(type, "docs") || !strcmp(type, "doc")) { *order = 3; return "Documentation"; }
    if (!strcmp(type, "style")) { *order = 4; return "Style Fixes"; }
    if (!strcmp(type, "refactor")) { *order = 5; return "Code Refactoring"; }
    if (!strcmp(type, "perf")) { *order = 6; return "Performance"; }
    if (!strcmp(type, "test") || !strcmp(type, "tests")) { *order = 7; return "Tests"; }
    if (!strcmp(type, "build")) { *order = 8; return "Build"; }
    if (!strcmp(type, "chore")) { *order = 9; return "Chores"; }
    return NULL;
}

static Section *get_section(Section **head, const char *title, int order) {
    Section **pp = head;
    while (*pp && (*pp)->order <= order) {
        if ((*pp)->order == order && !strcmp((*pp)->title, title)) return *pp;
        pp = &(*pp)->next;
    }
    Section *s = calloc(1, sizeof *s);
    s->title = title; s->order = order; s->next = *pp; *pp = s;
    return s;
}

static void add_item(Section **secs, const char *title, int order, char *scope, char *text, char *hash, char *body) {
    Section *s = get_section(secs, title, order);
    Item *it = calloc(1, sizeof *it);
    it->scope = scope; it->text = text; it->hash = hash; it->body = body;
    if (s->tail) s->tail->next = it; else s->items = it;
    s->tail = it;
}

static bool parse_subject(const char *subj, char **type, char **scope, char **text, bool *breaking) {
    const char *colon = strchr(subj, ':');
    if (!colon) return false;
    const char *p = subj;
    while (p < colon && (isalnum((unsigned char)*p) || *p == '-' || *p == '_')) p++;
    *scope = NULL; *breaking = false;
    if (*p == '(') {
        const char *q = strchr(p + 1, ')');
        if (!q || q > colon) return false;
        *scope = strndup(p + 1, (size_t)(q - p - 1));
        p = q + 1;
    }
    if (*p == '!') { *breaking = true; p++; }
    if (p != colon) return false;
    *type = strndup(subj, (size_t)(strchr(subj, '(') && strchr(subj, '(') < colon ? strchr(subj, '(') - subj : (p - subj - (*breaking ? 1 : 0))));
    for (char *q = *type; *q; q++) *q = (char)tolower((unsigned char)*q);
    const char *msg = colon + 1;
    while (*msg == ' ') msg++;
    *text = xstrdup(msg);
    return **text != 0;
}

static char *commit_link(const Opt *o, const char *hash) {
    char short_hash[9];
    snprintf(short_hash, sizeof short_hash, "%.8s", hash);
    if (!o->repository || !*o->repository) return xstrdup(short_hash);
    const char *mid = "/commit/";
    if (o->link_style && !strcmp(o->link_style, "gitlab")) mid = "/commit/";
    else if (o->link_style && !strcmp(o->link_style, "stash")) mid = "/commits/";
    else if (o->link_style && !strcmp(o->link_style, "cgit")) mid = "/commit/?id=";
    size_t n = strlen(short_hash) + strlen(o->repository) + strlen(mid) + strlen(hash) + 16;
    char *r = malloc(n);
    snprintf(r, n, "[%s](%s%s%s)", short_hash, o->repository, mid, hash);
    return r;
}

static char *replace_issues(const Opt *o, const char *body) {
    if (!body || !*body || !o->repository) return xstrdup(body ? body : "");
    size_t cap = strlen(body) * 3 + 128, len = 0;
    char *out = malloc(cap); out[0] = 0;
    for (size_t i = 0; body[i]; ) {
        if (body[i] == '#') {
            size_t j = i + 1;
            while (isdigit((unsigned char)body[j])) j++;
            if (j > i + 1) {
                char num[32];
                snprintf(num, sizeof num, "%.*s", (int)(j - i - 1), body + i + 1);
                char repl[1024];
                snprintf(repl, sizeof repl, "[#%s](%s/issues/%s)", num, o->repository, num);
                size_t rn = strlen(repl);
                if (len + rn + 1 > cap) { cap = (len + rn + 1) * 2; out = realloc(out, cap); }
                memcpy(out + len, repl, rn); len += rn; out[len] = 0; i = j; continue;
            }
        }
        if (len + 2 > cap) { cap *= 2; out = realloc(out, cap); }
        out[len++] = body[i++]; out[len] = 0;
    }
    return out;
}

static Section *collect_commits(Opt *o) {
    if (!o->from && o->from_latest_tag) {
        char *gd = shell_quote(o->git_dir), *wt = shell_quote(o->work_tree);
        char cmd[4096];
        snprintf(cmd, sizeof cmd, "git --git-dir=%s --work-tree=%s describe --tags --abbrev=0 2>/dev/null", gd, wt);
        o->from = run_capture(cmd);
        free(gd); free(wt);
        if (!o->from || !*o->from) return NULL;
    }
    char *gd = shell_quote(o->git_dir), *wt = shell_quote(o->work_tree);
    char *range = NULL;
    if (o->from) {
        size_t n = strlen(o->from) + strlen(o->to) + 3;
        range = malloc(n); snprintf(range, n, "%s..%s", o->from, o->to);
    } else range = xstrdup(o->to);
    char *qr = shell_quote(range);
    char cmd[8192];
    snprintf(cmd, sizeof cmd, "git --git-dir=%s --work-tree=%s log --reverse --pretty=format:'%%H%%x1f%%s%%x1f%%b%%x1e' %s 2>/dev/null", gd, wt, qr);
    char *log = run_capture(cmd);
    free(gd); free(wt); free(range); free(qr);
    Section *secs = NULL;
    if (!log) return NULL;
    char *rec = log;
    while (*rec) {
        char *end = strchr(rec, 0x1e);
        if (end) *end = 0;
        char *h = rec, *s = strchr(h, 0x1f);
        if (s) {
            *s++ = 0;
            char *b = strchr(s, 0x1f);
            if (b) {
                *b++ = 0;
                char *type = NULL, *scope = NULL, *text = NULL;
                bool breaking = strstr(b, "BREAKING CHANGE") != NULL || strstr(b, "BREAKING-CHANGE") != NULL;
                if (parse_subject(s, &type, &scope, &text, &breaking)) {
                    int order = 99;
                    const char *title = section_for(type, breaking, &order);
                    if (title) add_item(&secs, title, order, scope, text, xstrdup(h), xstrdup(b));
                    else { free(scope); free(text); }
                    free(type);
                }
            }
        }
        if (!end) break;
        rec = end + 1;
        while (*rec == '\n' || *rec == '\r') rec++;
    }
    free(log);
    return secs;
}

static char *read_file(const char *path) {
    if (!path) return NULL;
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *b = malloc((size_t)n + 1);
    fread(b, 1, (size_t)n, f);
    b[n] = 0;
    fclose(f);
    return b;
}

static void write_markdown(FILE *out, Opt *o, Section *secs, const char *date) {
    const char *ver = o->setversion ? o->setversion : "";
    const char *sub = o->subtitle ? o->subtitle : "";
    fprintf(out, "<a name=\"%s\"></a>\n", ver);
    bool patch_header = o->patch && !o->setversion;
    fprintf(out, "%s %s %s (%s)\n\n", patch_header ? "###" : "##", ver, sub, date);
    for (Section *s = secs; s; s = s->next) {
        fprintf(out, "#### %s\n\n", s->title);
        for (Item *it = s->items; it; it = it->next) {
            char *lnk = commit_link(o, it->hash);
            fprintf(out, "* ");
            if (it->scope && *it->scope) fprintf(out, "**%s**: ", it->scope);
            fprintf(out, "%s (%s", it->text, lnk);
            char *issues = replace_issues(o, it->body);
            if (issues && *trim(issues)) fprintf(out, ", %s", trim(issues));
            fprintf(out, ")\n");
            free(issues); free(lnk);
        }
        fprintf(out, "\n");
    }
    fprintf(out, "\n");
}

static void write_json(FILE *out, Opt *o, Section *secs, const char *date) {
    fprintf(out, "{\"header\":{\"version\":");
    if (o->setversion) fprintf(out, "Some(\"%s\")", o->setversion); else fprintf(out, "None");
    fprintf(out, ",\"patch_version\":%s,\"subtitle\":", (o->patch && !o->setversion) ? "true" : "false");
    if (o->subtitle) fprintf(out, "\"%s\"", o->subtitle); else fprintf(out, "null");
    fprintf(out, ",\"date\":\"%s\"},\"sections\":", date);
    if (!secs) { fprintf(out, "null}"); return; }
    fprintf(out, "[");
    bool fs = true;
    for (Section *s = secs; s; s = s->next) {
        if (!fs) fprintf(out, ","); fs = false;
        fprintf(out, "{\"title\":\"%s\",\"commits\":[", s->title);
        bool fi = true;
        for (Item *it = s->items; it; it = it->next) {
            if (!fi) fprintf(out, ","); fi = false;
            fprintf(out, "{\"scope\":");
            if (it->scope) fprintf(out, "\"%s\"", it->scope); else fprintf(out, "null");
            fprintf(out, ",\"subject\":\"%s\",\"hash\":\"%s\"}", it->text, it->hash);
        }
        fprintf(out, "]}");
    }
    fprintf(out, "]}");
}

static bool valid_semver(const char *v) {
    int a, b, c; char extra;
    return v && sscanf(v, "%d.%d.%d%c", &a, &b, &c, &extra) == 3;
}

int main(int argc, char **argv) {
    Opt o = {.format=xstrdup("markdown"), .to=xstrdup("HEAD"), .config=xstrdup(".clog.toml"), .link_style=xstrdup("github")};
    char cwd[4096];
    getcwd(cwd, sizeof cwd);
    asprintf(&o.work_tree, "%s", cwd);
    asprintf(&o.git_dir, "%s/.git", cwd);
    static struct option lo[] = {
        {"repository",1,0,'r'}, {"from",1,0,'f'}, {"format",1,0,'T'}, {"major",0,0,'M'},
        {"git-dir",1,0,'g'}, {"work-tree",1,0,'w'}, {"minor",0,0,'m'}, {"patch",0,0,'p'},
        {"subtitle",1,0,'s'}, {"to",1,0,'t'}, {"outfile",1,0,'o'}, {"config",1,0,'c'},
        {"infile",1,0,'i'}, {"setversion",1,0,1000}, {"from-latest-tag",0,0,'F'},
        {"link-style",1,0,'l'}, {"changelog",1,0,'C'}, {"help",0,0,'h'}, {"version",0,0,'V'}, {0,0,0,0}
    };
    int ch;
    while ((ch = getopt_long(argc, argv, "r:f:T:Mg:w:mps:t:o:c:i:Fl:C:hV", lo, NULL)) != -1) {
        switch (ch) {
            case 'r': o.repository=xstrdup(optarg); break; case 'f': o.from=xstrdup(optarg); break;
            case 'T': free(o.format); o.format=xstrdup(optarg); break; case 'M': o.major=true; break;
            case 'g': free(o.git_dir); o.git_dir=xstrdup(optarg); break; case 'w': free(o.work_tree); o.work_tree=xstrdup(optarg); break;
            case 'm': o.minor=true; break; case 'p': o.patch=true; break; case 's': o.subtitle=xstrdup(optarg); break;
            case 't': free(o.to); o.to=xstrdup(optarg); break; case 'o': o.outfile=xstrdup(optarg); break;
            case 'c': free(o.config); o.config=xstrdup(optarg); break; case 'i': o.infile=xstrdup(optarg); break;
            case 1000: o.setversion=xstrdup(optarg); break; case 'F': o.from_latest_tag=true; break;
            case 'l': free(o.link_style); o.link_style=xstrdup(optarg); break; case 'C': o.changelog=xstrdup(optarg); break;
            case 'h': usage(stdout); return 0; case 'V': puts("clog 0.10.0"); return 0;
            default: fprintf(stderr, "For more information, try '--help'.\n"); return 2;
        }
    }
    if (strcmp(o.format, "markdown") && strcmp(o.format, "json")) {
        fprintf(stderr, "error: invalid value '%s' for '--format <STR>'\n  [possible values: markdown, json]\n\nFor more information, try '--help'.\n", o.format);
        return 2;
    }
    parse_config(&o);
    if ((o.major || o.minor || o.patch) && !valid_semver(o.setversion)) {
        fprintf(stderr, "\033[1;31merror:\033[0m Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.\n");
        return 1;
    }
    Section *secs = collect_commits(&o);
    char date[11]; today(date);
    char *append = NULL;
    if (o.changelog) { o.infile = o.changelog; o.outfile = o.changelog; }
    if (o.infile) append = read_file(o.infile);
    FILE *out = stdout;
    if (o.outfile) {
        out = fopen(o.outfile, "wb");
        if (!out) { fprintf(stderr, "\033[1;31merror:\033[0m fatal I/O error with output file\n"); return 1; }
    }
    if (!strcmp(o.format, "json")) write_json(out, &o, secs, date);
    else write_markdown(out, &o, secs, date);
    if (append) fprintf(out, "\n\n%s", append);
    if (out != stdout) fclose(out);
    fprintf(stderr, "changelog written. (took 100 ms)\n");
    return 0;
}
