#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <regex.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    int error_duration, only_last, stdin_mode, summary;
    int until_changes, until_fail, until_same, until_success;
    long count_by, offset;
    long num;
    int has_num;
    long long every_us, for_duration_us;
    int has_duration;
    char *for_list, *until_contains, *until_error, *until_match, *until_time;
    char **cmdv;
    int cmdc;
} Opt;

static const char *prog = "executable";
static volatile sig_atomic_t interrupted = 0;

static void onint(int sig) { (void)sig; interrupted = 1; }

static void help(void) {
    printf("loop 0.6.1\n");
    printf("Rich Jones <miserlou@gmail.com>\n");
    printf("UNIX's missing `loop` command\n\n");
    printf("USAGE:\n    %s [FLAGS] [OPTIONS] [input]...\n\n", prog);
    printf("FLAGS:\n");
    printf("    -D, --error-duration    Exit with timeout error code on duration\n");
    printf("    -h, --help              Prints help information\n");
    printf("    -l, --only-last         Only print the output of the last execution of the command\n");
    printf("    -i, --stdin             Read from standard input\n");
    printf("        --summary           Provide a summary\n");
    printf("    -C, --until-changes     Keep going until the output changes\n");
    printf("    -f, --until-fail        Keep going until the command exit status is non-zero\n");
    printf("    -S, --until-same        Keep going until the output changes\n");
    printf("    -s, --until-success     Keep going until the command exit status is zero\n");
    printf("    -V, --version           Prints version information\n\n");
    printf("OPTIONS:\n");
    printf("    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]\n");
    printf("    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]\n");
    printf("        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue\n");
    printf("    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)\n");
    printf("    -n, --num <num>                          Number of iterations to execute\n");
    printf("    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]\n");
    printf("    -c, --until-contains <until_contains>    Keep going until the output contains this string\n");
    printf("    -r, --until-error <until_error>          Keep going until the command exit status is the value given\n");
    printf("    -m, --until-match <until_match>          Keep going until the output matches this regular expression\n");
    printf("    -t, --until-time <until_time>            Keep going until a future time, ex. \"2018-04-20 04:20:00\" (Times in UTC.)\n\n");
    printf("ARGS:\n    <input>...    The command to be looped\n");
}

static void version(void) { printf("loop 0.6.1\n"); }

static int need_value(int i, int argc, const char *name) {
    if (i + 1 < argc) return 0;
    fprintf(stderr, "error: The argument '%s' requires a value but none was supplied\n\n", name);
    fprintf(stderr, "USAGE:\n    %s --count-by <count_by> --every <every> --num <num> --offset <offset>\n\n", prog);
    fprintf(stderr, "For more information try --help\n");
    return 1;
}

static int parse_long_value(const char *s, long *out, const char *opt, int float_err) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) {
        fprintf(stderr, "error: Invalid value for '%s': %s\n", opt, float_err ? "invalid float literal" : "invalid digit found in string");
        return -1;
    }
    *out = v;
    return 0;
}

static long long parse_duration(const char *s, const char *optname) {
    long long total = 0;
    size_t i = 0, n = strlen(s);
    while (i < n) {
        if (!isdigit((unsigned char)s[i])) {
            fprintf(stderr, "error: Invalid value for '%s': expected number at %zu\n", optname, i);
            return -1;
        }
        long long val = 0;
        while (i < n && isdigit((unsigned char)s[i])) val = val * 10 + (s[i++] - '0');
        long long mult = 0;
        if (i < n && s[i] == 'h') { mult = 3600LL * 1000000; i++; }
        else if (i < n && s[i] == 'm') {
            if (i + 1 < n && s[i+1] == 's') { mult = 1000; i += 2; }
            else { mult = 60LL * 1000000; i++; }
        } else if (i < n && s[i] == 's') { mult = 1000000; i++; }
        else if (i + 1 < n && s[i] == 'u' && s[i+1] == 's') { mult = 1; i += 2; }
        else {
            fprintf(stderr, "error: Invalid value for '%s': invalid character at %zu\n", optname, i);
            return -1;
        }
        total += val * mult;
    }
    return total;
}

static char *join_cmd(char **v, int c) {
    size_t len = 1;
    for (int i = 0; i < c; i++) len += strlen(v[i]) + 1;
    char *s = calloc(1, len);
    if (!s) exit(2);
    for (int i = 0; i < c; i++) {
        if (i) strcat(s, " ");
        strcat(s, v[i]);
    }
    return s;
}

static char **split_commas(char *s, int *count) {
    if (!s) { *count = 0; return NULL; }
    char *copy = strdup(s);
    int cap = 8, n = 0;
    char **arr = malloc(sizeof(char*) * cap);
    char *p = copy, *start = p;
    for (;;) {
        if (*p == ',' || *p == '\0') {
            char save = *p; *p = 0;
            if (n == cap) { cap *= 2; arr = realloc(arr, sizeof(char*) * cap); }
            arr[n++] = strdup(start);
            if (!save) break;
            start = p + 1;
        }
        p++;
    }
    free(copy);
    *count = n;
    return arr;
}

static char **read_stdin_lines(int *count) {
    char **arr = NULL;
    int cap = 0, n = 0;
    char *line = NULL;
    size_t sz = 0;
    while (getline(&line, &sz, stdin) != -1) {
        size_t l = strlen(line);
        while (l && (line[l-1] == '\n' || line[l-1] == '\r')) line[--l] = 0;
        if (n == cap) { cap = cap ? cap * 2 : 8; arr = realloc(arr, sizeof(char*) * cap); }
        arr[n++] = strdup(line);
    }
    free(line);
    *count = n;
    return arr;
}

static char *run_command(const char *cmd, long count, const char *item, int *status) {
    char countbuf[64];
    snprintf(countbuf, sizeof countbuf, "%ld", count);
    setenv("COUNT", countbuf, 1);
    if (item) setenv("ITEM", item, 1);
    else unsetenv("ITEM");
    char *full = malloc(strlen(cmd) + 6);
    sprintf(full, "%s 2>&1", cmd);
    FILE *fp = popen(full, "r");
    free(full);
    if (!fp) {
        *status = 127;
        return strdup("");
    }
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        if (len + 2 >= cap) { cap *= 2; buf = realloc(buf, cap); }
        buf[len++] = (char)ch;
    }
    buf[len] = 0;
    int rc = pclose(fp);
    if (WIFEXITED(rc)) *status = WEXITSTATUS(rc);
    else if (WIFSIGNALED(rc)) *status = 128 + WTERMSIG(rc);
    else *status = rc;
    return buf;
}

static long long now_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);
    return (long long)ts.tv_sec * 1000000 + ts.tv_nsec / 1000;
}

static int past_until_time(const char *s) {
    if (!s) return 0;
    struct tm tm;
    memset(&tm, 0, sizeof tm);
    char *end = strptime(s, "%Y-%m-%d %H:%M:%S", &tm);
    if (!end || *end) return 0;
    time_t target = timegm(&tm);
    return time(NULL) >= target;
}

static int regex_match(const char *pat, const char *text) {
    regex_t re;
    if (regcomp(&re, pat, REG_EXTENDED | REG_NOSUB | REG_NEWLINE) != 0) return 0;
    int ok = regexec(&re, text, 0, NULL, 0) == 0;
    regfree(&re);
    return ok;
}

static int parse_args(int argc, char **argv, Opt *o) {
    memset(o, 0, sizeof *o);
    o->count_by = 1;
    o->offset = 0;
    o->every_us = 1;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "--")) { o->cmdv = &argv[i+1]; o->cmdc = argc - i - 1; return 0; }
        if (a[0] != '-' || !strcmp(a, "-")) { o->cmdv = &argv[i]; o->cmdc = argc - i; return 0; }
        char *val = strchr(a, '=');
        char namebuf[128];
        if (val) {
            size_t l = (size_t)(val - a);
            if (l >= sizeof namebuf) l = sizeof namebuf - 1;
            memcpy(namebuf, a, l); namebuf[l] = 0;
            a = namebuf; val++;
        }
#define VALUE(display) (val ? val : (need_value(i, argc, display) ? NULL : argv[++i]))
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { help(); exit(0); }
        else if (!strcmp(a, "-V") || !strcmp(a, "--version")) { version(); exit(0); }
        else if (!strcmp(a, "-D") || !strcmp(a, "--error-duration")) o->error_duration = 1;
        else if (!strcmp(a, "-l") || !strcmp(a, "--only-last")) o->only_last = 1;
        else if (!strcmp(a, "-i") || !strcmp(a, "--stdin")) o->stdin_mode = 1;
        else if (!strcmp(a, "--summary")) o->summary = 1;
        else if (!strcmp(a, "-C") || !strcmp(a, "--until-changes")) o->until_changes = 1;
        else if (!strcmp(a, "-f") || !strcmp(a, "--until-fail")) o->until_fail = 1;
        else if (!strcmp(a, "-S") || !strcmp(a, "--until-same")) o->until_same = 1;
        else if (!strcmp(a, "-s") || !strcmp(a, "--until-success")) o->until_success = 1;
        else if (!strcmp(a, "-b") || !strcmp(a, "--count-by")) { char *v = VALUE("--count-by <count_by>"); if (!v || parse_long_value(v, &o->count_by, "--count-by <count_by>", 1)) return 1; }
        else if (!strcmp(a, "-o") || !strcmp(a, "--offset")) { char *v = VALUE("--offset <offset>"); if (!v || parse_long_value(v, &o->offset, "--offset <offset>", 1)) return 1; }
        else if (!strcmp(a, "-n") || !strcmp(a, "--num")) { char *v = VALUE("--num <num>"); if (!v || parse_long_value(v, &o->num, "--num <num>", 1)) return 1; o->has_num = 1; }
        else if (!strcmp(a, "-e") || !strcmp(a, "--every")) { char *v = VALUE("--every <every>"); if (!v) return 1; o->every_us = parse_duration(v, "--every <every>"); if (o->every_us < 0) return 1; }
        else if (!strcmp(a, "-d") || !strcmp(a, "--for-duration")) { char *v = VALUE("--for-duration <for_duration>"); if (!v) return 1; o->for_duration_us = parse_duration(v, "--for-duration <for_duration>"); if (o->for_duration_us < 0) return 1; o->has_duration = 1; }
        else if (!strcmp(a, "--for")) { char *v = VALUE("--for <ffor>"); if (!v) return 1; o->for_list = v; }
        else if (!strcmp(a, "-c") || !strcmp(a, "--until-contains")) { char *v = VALUE("--until-contains <until_contains>"); if (!v) return 1; o->until_contains = v; }
        else if (!strcmp(a, "-r") || !strcmp(a, "--until-error")) { char *v = VALUE("--until-error <until_error>"); if (!v) return 1; o->until_error = v; }
        else if (!strcmp(a, "-m") || !strcmp(a, "--until-match")) { char *v = VALUE("--until-match <until_match>"); if (!v) return 1; o->until_match = v; }
        else if (!strcmp(a, "-t") || !strcmp(a, "--until-time")) { char *v = VALUE("--until-time <until_time>"); if (!v) return 1; o->until_time = v; }
        else {
            fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n", argv[i]);
            fprintf(stderr, "USAGE:\n    %s [FLAGS] [OPTIONS] [input]...\n\n", prog);
            fprintf(stderr, "For more information try --help\n");
            return 1;
        }
#undef VALUE
    }
    return 0;
}

int main(int argc, char **argv) {
    prog = strrchr(argv[0], '/');
    prog = prog ? prog + 1 : argv[0];
    Opt o;
    if (parse_args(argc, argv, &o)) return 1;
    if (o.cmdc <= 0) {
        printf("No command supplied, exiting.\n");
        return 0;
    }
    signal(SIGINT, onint);
    char *cmd = join_cmd(o.cmdv, o.cmdc);
    int item_count = 0;
    char **items = NULL;
    if (o.stdin_mode) items = read_stdin_lines(&item_count);
    else if (o.for_list) items = split_commas(o.for_list, &item_count);
    long max_iter = -1;
    if (o.has_num) max_iter = o.num;
    else if (item_count > 0) max_iter = item_count;
    long total = 0, successes = 0, failures = 0;
    int *failure_codes = NULL;
    int failure_n = 0, failure_cap = 0;
    char *last_output = NULL;
    char *prev_output = NULL;
    long long start = now_us();
    for (long iter = 0; !interrupted; iter++) {
        if (max_iter >= 0 && iter >= max_iter) break;
        if (o.has_duration && now_us() - start >= o.for_duration_us) break;
        if (o.until_time && past_until_time(o.until_time)) break;
        const char *item = NULL;
        if (items) {
            if (item_count == 0) item = "";
            else item = items[iter < item_count ? iter : item_count - 1];
        }
        int st = 0;
        char *out = run_command(cmd, o.offset + iter * o.count_by, item, &st);
        total++;
        if (st == 0) successes++;
        else {
            failures++;
            if (failure_n == failure_cap) { failure_cap = failure_cap ? failure_cap * 2 : 8; failure_codes = realloc(failure_codes, sizeof(int) * failure_cap); }
            failure_codes[failure_n++] = st;
        }
        if (!o.only_last) fputs(out, stdout);
        free(last_output);
        last_output = strdup(out);
        int stop = 0;
        if (o.until_success && st == 0) stop = 1;
        if (o.until_fail && st != 0) stop = 1;
        if (o.until_error) {
            long want;
            if (parse_long_value(o.until_error, &want, "--until-error <until_error>", 0) == 0 && st == want) stop = 1;
        }
        if (o.until_contains && strstr(out, o.until_contains)) stop = 1;
        if (o.until_match && regex_match(o.until_match, out)) stop = 1;
        if (o.until_changes && prev_output && strcmp(prev_output, out) != 0) stop = 1;
        if (o.until_same && prev_output && strcmp(prev_output, out) == 0) stop = 1;
        free(prev_output);
        prev_output = out;
        if (stop) break;
        if (o.every_us > 0) usleep((useconds_t)o.every_us);
    }
    if (o.only_last && last_output) fputs(last_output, stdout);
    if (o.summary) {
        printf("Total runs:\t%ld\n", total);
        printf("Successes:\t%ld\n", successes);
        printf("Failures:\t%ld", failures);
        if (failures) {
            printf(" (");
            for (int i = 0; i < failure_n; i++) printf("%s%d", i ? ", " : "", failure_codes[i]);
            printf(")");
        }
        printf("\n");
    }
    int ret = 0;
    if (o.error_duration && o.has_duration && now_us() - start >= o.for_duration_us) ret = 124;
    free(cmd);
    free(last_output);
    free(prev_output);
    return ret;
}
