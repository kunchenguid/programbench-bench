#define _XOPEN_SOURCE 700
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char help_text[] =
"usage: nnn [OPTIONS] [PATH]\n"
"\n"
"The unorthodox terminal file manager.\n"
"\n"
"positional args:\n"
"  PATH   start dir/file [default: .]\n"
"\n"
"optional args:\n"
" -a      auto NNN_FIFO\n"
" -A      no dir auto-enter during filter\n"
" -b key  open bookmark key (trumps -s/S)\n"
" -B      use bsdtar for archives\n"
" -c      cli-only NNN_OPENER (trumps -e)\n"
" -C      8-color scheme\n"
" -d      detail mode\n"
" -D      dirs in context color\n"
" -e      text in $VISUAL/$EDITOR/vi\n"
" -E      internal edits in EDITOR\n"
" -f      use history file\n"
" -F val  fifo mode [0:preview 1:explore]\n"
" -g      regex filters\n"
" -H      show hidden files\n"
" -i      show current file info\n"
" -J      no auto-advance on selection\n"
" -K      detect key collision and exit\n"
" -l val  set scroll lines\n"
" -n      type-to-nav mode\n"
" -N      use native prompt\n"
" -o      open files only on Enter\n"
" -p file selection file [-:stdout]\n"
" -P key  run plugin key\n"
" -Q      no quit confirmation\n"
" -r      use advcpmv patched cp, mv\n"
" -R      no rollover at edges\n"
" -s name load session by name\n"
" -S      persistent session\n"
" -t secs timeout to lock\n"
" -T key  sort order [a/d/e/r/s/t/v]\n"
" -u      use selection (no prompt)\n"
" -U      show user and group\n"
" -V      show version\n"
" -x      notis, selection sync, xterm title\n"
" -z      in order fuzzy filters\n"
" -0      null separator in picker mode\n"
" -h      show help\n"
"\n"
"v5.2\n"
"BSD 2-Clause\n"
"https://github.com/jarun/nnn\n";

static void print_help(void)
{
    fputs(help_text, stdout);
}

static void simple_listing(const char *path)
{
    DIR *dir = opendir(path);
    if (!dir) {
        fprintf(stderr, "%s: %s\n", path, strerror(errno));
        return;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;
        puts(entry->d_name);
    }

    closedir(dir);
}

static void wait_forever(void)
{
    fflush(stdout);
    fflush(stderr);
    for (;;)
        pause();
}

int main(int argc, char **argv)
{
    int opt;

    while ((opt = getopt(argc, argv, "aAb:BCcdDeEfF:gHiJKl:nNoOp:P:QrRs:St:T:uUVxz0h")) != -1) {
        switch (opt) {
        case 'h':
            print_help();
            return 0;
        case 'V':
            puts("5.2");
            return 0;
        case 'F':
            if (atoi(optarg) > 1)
                return 1;
            break;
        case '?':
        default:
            print_help();
            return 1;
        }
    }

    const char *path = optind < argc ? argv[optind] : ".";

    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fprintf(stderr, "0 entries\n");
        wait_forever();
    }

    simple_listing(path);
    wait_forever();
}
