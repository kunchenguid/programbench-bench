#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

static const char *prog = "executable";
static struct termios saved_termios;
static bool raw_enabled = false;

static void print_help(void) {
    printf("A simple terminal UI for search and replace, ala VS Code\n\n");
    printf("Usage: %s [OPTIONS]\n\n", prog);
    printf("Options:\n");
    printf("  -p, --project-root <PATH>  Path to the project root [default: .]\n");
    printf("  -h, --help                 Print help\n");
    printf("  -V, --version              Print version\n");
}

static void print_version(void) {
    const char *home = getenv("HOME");
    if (!home || !*home) home = "/home/agent";
    printf("serpl 0.3.4- (2026-04-20)\n\n");
    printf("Authors: Yassine Bridi <ybridi@gmail.com>\n\n");
    printf("Config directory: %s/.config/serpl\n", home);
}

static int clap_error_unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "Usage: %s [OPTIONS]\n\n", prog);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int clap_error_missing_project_root(void) {
    fprintf(stderr, "error: a value is required for '--project-root <PATH>' but none was supplied\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int clap_error_help_value(const char *value) {
    fprintf(stderr, "error: unexpected value '%s' for '--help' found; no more were expected\n\n", value);
    fprintf(stderr, "Usage: %s --help\n\n", prog);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int terminal_unavailable(void) {
    fprintf(stderr, "serpl error: Something went wrong\n");
    fprintf(stderr, "Error: \n");
    fprintf(stderr, "   0: \033[91mResource temporarily unavailable (os error 11)\033[0m\n");
    return 1;
}

static void disable_raw(void) {
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &saved_termios);
        raw_enabled = false;
    }
    printf("\033[?25h\033[?1049l");
    fflush(stdout);
}

static void on_signal(int sig) {
    (void)sig;
    disable_raw();
    _exit(0);
}

static int enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &saved_termios) != 0) return -1;
    struct termios raw = saved_termios;
    raw.c_lflag &= (tcflag_t)~(ECHO | ICANON | IEXTEN);
    raw.c_iflag &= (tcflag_t)~(IXON | ICRNL);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) != 0) return -1;
    raw_enabled = true;
    atexit(disable_raw);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    return 0;
}

static void repeat_str(const char *s, int n) {
    for (int i = 0; i < n; i++) fputs(s, stdout);
}

static void draw_ui(const char *search, const char *replace, int focus, bool help) {
    struct winsize ws;
    int rows = 24, cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
        if (ws.ws_row > 0) rows = ws.ws_row;
        if (ws.ws_col > 0) cols = ws.ws_col;
    }
    if (cols < 60) cols = 60;
    if (rows < 18) rows = 18;
    int left_w = cols < 90 ? 24 : 30;
    int right_w = cols - left_w - 2;
    if (right_w < 30) right_w = 30;

    printf("\033[?1049h\033[?25l\033[H\033[2J");
    printf("\033[1m\033[38;5;%dm", focus == 0 ? 2 : 15);
    printf("╭Search────────[Simple]");
    repeat_str("─", left_w - 22);
    printf("╮\033[0m");
    printf("╭Preview");
    repeat_str("─", right_w - 7);
    printf("╮\n");

    printf("\033[38;5;%dm│\033[0m %-*.*s \033[38;5;%dm│\033[0m", focus == 0 ? 2 : 15,
           left_w - 4, left_w - 4, search, focus == 0 ? 2 : 15);
    printf("│%-*s│\n", right_w - 2, "");

    printf("\033[38;5;%dm╰", focus == 0 ? 2 : 15);
    repeat_str("─", left_w - 2);
    printf("╯\033[0m│%-*s│\n", right_w - 2, "");

    printf("\033[38;5;%dm╭Replace───────[Simple]", focus == 1 ? 2 : 15);
    repeat_str("─", left_w - 23);
    printf("╮\033[0m│%-*s│\n", right_w - 2, "");
    printf("\033[38;5;%dm│\033[0m %-*.*s \033[38;5;%dm│\033[0m│%-*s│\n", focus == 1 ? 2 : 15,
           left_w - 4, left_w - 4, replace, focus == 1 ? 2 : 15, right_w - 2, "");
    printf("\033[38;5;%dm╰", focus == 1 ? 2 : 15);
    repeat_str("─", left_w - 2);
    printf("╯\033[0m│%-*s│\n", right_w - 2, "");

    printf("╭Result List");
    repeat_str("─", left_w - 13);
    printf("╮│%-*s│\n", right_w - 2, "");
    int list_rows = rows - 10;
    if (help) {
        const char *lines[] = {
            " Ctrl-d/Ctrl-c  Quit",
            " Tab            Change field",
            " Enter          Search",
            " Ctrl-b         Toggle help",
            " Ctrl-o         Replace"
        };
        for (int i = 0; i < list_rows; i++) {
            const char *line = i < 5 ? lines[i] : "";
            printf("│%-*.*s││%-*s│\n", left_w - 2, left_w - 2, line, right_w - 2, "");
        }
    } else {
        for (int i = 0; i < list_rows; i++) {
            printf("│%-*s││%-*s│\n", left_w - 2, "", right_w - 2, "");
        }
    }
    printf("╰");
    repeat_str("─", left_w - 2);
    printf("╯╰");
    repeat_str("─", right_w - 2);
    printf("╯\n");
    printf("\033[38;5;4mHelp: <Ctrl-b> | Search: <Enter> | Toggle search mode: <Ctrl-s> | Quit: <Ctrl-d>\033[0m");
    printf("\033[?25h\033[%d;%dH", focus == 0 ? 2 : 5, 3 + (focus == 0 ? (int)strlen(search) : (int)strlen(replace)));
    fflush(stdout);
}

static int run_tui(const char *project_root) {
    (void)project_root;
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) return terminal_unavailable();
    if (enable_raw() != 0) return terminal_unavailable();

    char search[256] = "";
    char replace[256] = "";
    int focus = 0;
    bool help = false;
    draw_ui(search, replace, focus, help);

    for (;;) {
        unsigned char ch = 0;
        ssize_t n = read(STDIN_FILENO, &ch, 1);
        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        if (n == 0) {
            draw_ui(search, replace, focus, help);
            continue;
        }
        if (ch == 3 || ch == 4) break;
        if (ch == 2) help = !help;
        else if (ch == '\t') focus = (focus + 1) % 2;
        else if (ch == 127 || ch == '\b') {
            char *buf = focus == 0 ? search : replace;
            size_t len = strlen(buf);
            if (len) buf[len - 1] = '\0';
        } else if (ch == '\r' || ch == '\n') {
            focus = 2;
        } else if (isprint(ch)) {
            char *buf = focus == 0 ? search : replace;
            size_t len = strlen(buf);
            if (len + 1 < 255) {
                buf[len] = (char)ch;
                buf[len + 1] = '\0';
            }
        } else if (ch == 27) {
            unsigned char seq[2];
            if (read(STDIN_FILENO, seq, 2) > 0) {
                /* Consume common escape sequences. */
            }
        }
        if (focus == 2) focus = 0;
        draw_ui(search, replace, focus, help);
    }
    disable_raw();
    return 0;
}

int main(int argc, char **argv) {
    prog = argv[0] && strrchr(argv[0], '/') ? strrchr(argv[0], '/') + 1 : (argv[0] ? argv[0] : "executable");
    const char *project_root = ".";

    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "--help") == 0 || strcmp(arg, "-h") == 0) {
            print_help();
            return 0;
        } else if (strncmp(arg, "--help=", 7) == 0) {
            return clap_error_help_value(arg + 7);
        } else if (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0) {
            print_version();
            return 0;
        } else if (strcmp(arg, "--project-root") == 0 || strcmp(arg, "-p") == 0) {
            if (i + 1 >= argc || argv[i + 1][0] == '-') return clap_error_missing_project_root();
            project_root = argv[++i];
        } else if (strncmp(arg, "--project-root=", 15) == 0) {
            if (arg[15] == '\0') return clap_error_missing_project_root();
            project_root = arg + 15;
        } else if (strncmp(arg, "-p=", 3) == 0) {
            if (arg[3] == '\0') return clap_error_missing_project_root();
            project_root = arg + 3;
        } else if (strncmp(arg, "-p", 2) == 0 && arg[2] != '\0') {
            project_root = arg + 2;
        } else {
            return clap_error_unexpected(arg);
        }
    }
    return run_tui(project_root);
}
