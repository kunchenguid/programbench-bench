#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char n_arg[256];
    int n_mode;
    int top;
    int combi;
    int rep;
    int wpm;
    int acc;
    char emu_in[64];
    char emu_out[64];
    bool show_ortho;
    bool nokb;
    bool cat;
} Config;

static const char *bigrams[] = {
    "in","io","er","en","ti","te","es","on","st","nt","ed","at","to","or","an","re","he","is","it","al",
    "ar","ou","ng","se","ha","as","le","ve","co","me","de","hi","ri","ro","ic","ll","li","el","ra","ne",
    "wa","ce","la","ch","ma","om","ur","ca","ta","si","fo","ho","ec","no","us","lo","di","pe","il","ni",
    "ac","pr","et","ut","ss","so","rs","un","tr","ns","wh","we","ee","wi","em","ad","ol","rt","th","nd",
    "ea","of","nd","ha","io","yo","ke","be","po","pa","mi","go","fi","pl","cl","br","gr","qu","zz","xy"
};

static const char *trigrams[] = {
    "the","and","ing","ion","ent","her","tha","nth","int","ere","tio","ter","est","ers","ati","hat","ate","all","eth","hes",
    "ver","his","oft","ith","fth","sth","oth","res","ont","rea","ear","our","you","but","not","for","had","was","she","him",
    "out","day","get","has","man","new","now","old","see","two","way","who","boy","did","its","let","put","say","too","use"
};

static const char *tetragrams[] = {
    "tion","ther","with","here","ould","ight","have","hich","whic","this","that","ment","ions","ever","from","ough","were","hing","ance","ting",
    "atio","fore","sion","tive","they","will","your","been","when","what","more","some","them","than","into","time","only","over","also","most"
};

static const char *words[] = {
    "the","be","to","of","and","a","in","that","have","i","it","for","not","on","with","he","as","you","do","at",
    "this","but","his","by","from","they","we","say","her","she","or","an","will","my","one","all","would","there","their","what",
    "so","up","out","if","about","who","get","which","go","me","when","make","can","like","time","no","just","him","know","take"
};

static volatile sig_atomic_t stop_requested = 0;

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static void print_help(void) {
    puts("Usage: executable [OPTIONS]\n");
    puts("Options:");
    puts("  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]");
    puts("  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]");
    puts("  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]");
    puts("  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]");
    puts("  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]");
    puts("  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]");
    puts("      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --show-ortho        show keyboard in ortholinear format");
    puts("      --nokb              pass this flag to disable the keyboard layout display.");
    puts("      --cat               the most important flag. don't practice alone.");
    puts("  -h, --help              Print help");
}

static bool parse_int_strict(const char *s, int *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || end == s || *end != '\0' || v < -2147483647L || v > 2147483647L) return false;
    *out = (int)v;
    return true;
}

static void clap_invalid_value(const char *val, const char *flag, const char *metavar) {
    fprintf(stderr, "error: invalid value '%s' for '%s <%s>': invalid digit found in string\n\n", val, flag, metavar);
    fprintf(stderr, "For more information, try '--help'.\n");
}

static int need_value(const char *flag) {
    fprintf(stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\n", flag);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int set_number(const char *name, const char *flag, const char *meta, const char *val, int min, int max, int *target) {
    int parsed = 0;
    if (!parse_int_strict(val, &parsed)) {
        clap_invalid_value(val, flag, meta);
        return 2;
    }
    if (parsed < min || parsed > max) {
        fprintf(stderr, "Invalid argument for %s. Use a number between %d and %d.\n", name, min, max);
        return 1;
    }
    *target = parsed;
    return 0;
}

static int parse_args(int argc, char **argv, Config *cfg) {
    strcpy(cfg->n_arg, "2");
    cfg->n_mode = 2;
    cfg->top = 50;
    cfg->combi = 2;
    cfg->rep = 3;
    cfg->wpm = 40;
    cfg->acc = 94;
    cfg->emu_in[0] = '\0';
    cfg->emu_out[0] = '\0';
    cfg->show_ortho = false;
    cfg->nokb = false;
    cfg->cat = false;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_help();
            exit(0);
        } else if (!strcmp(a, "-n") || !strcmp(a, "--n")) {
            if (++i >= argc) return need_value(a);
            snprintf(cfg->n_arg, sizeof(cfg->n_arg), "%s", argv[i]);
            if (!strcmp(argv[i], "2")) cfg->n_mode = 2;
            else if (!strcmp(argv[i], "3")) cfg->n_mode = 3;
            else if (!strcmp(argv[i], "4")) cfg->n_mode = 4;
            else if (!strcmp(argv[i], "w")) cfg->n_mode = 5;
            else cfg->n_mode = 0;
        } else if (!strcmp(a, "-t") || !strcmp(a, "--top")) {
            if (++i >= argc) return need_value(a);
            int r = set_number("top", "--top", "1-200", argv[i], 1, 200, &cfg->top);
            if (r) return r;
        } else if (!strcmp(a, "-c") || !strcmp(a, "--combi")) {
            if (++i >= argc) return need_value(a);
            int r = set_number("combi", "--combi", "1-200", argv[i], 1, 200, &cfg->combi);
            if (r) return r;
        } else if (!strcmp(a, "-r") || !strcmp(a, "--rep")) {
            if (++i >= argc) return need_value(a);
            int r = set_number("rep", "--rep", "number", argv[i], 1, 200, &cfg->rep);
            if (r) return r;
        } else if (!strcmp(a, "-w") || !strcmp(a, "--wpm")) {
            if (++i >= argc) return need_value(a);
            int r = set_number("wpm", "--wpm", "number", argv[i], 1, 200, &cfg->wpm);
            if (r) return r;
        } else if (!strcmp(a, "-a") || !strcmp(a, "--acc")) {
            if (++i >= argc) return need_value(a);
            int r = set_number("acc", "--acc", "0-100", argv[i], 0, 100, &cfg->acc);
            if (r) return r;
        } else if (!strcmp(a, "--emu-in")) {
            if (++i >= argc) return need_value(a);
            snprintf(cfg->emu_in, sizeof(cfg->emu_in), "%s", argv[i]);
        } else if (!strcmp(a, "--emu-out")) {
            if (++i >= argc) return need_value(a);
            snprintf(cfg->emu_out, sizeof(cfg->emu_out), "%s", argv[i]);
        } else if (!strcmp(a, "--show-ortho")) {
            cfg->show_ortho = true;
        } else if (!strcmp(a, "--nokb")) {
            cfg->nokb = true;
        } else if (!strcmp(a, "--cat")) {
            cfg->cat = true;
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", a);
            fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
            fprintf(stderr, "For more information, try '--help'.\n");
            return 2;
        }
    }

    if ((cfg->emu_in[0] == '\0') != (cfg->emu_out[0] == '\0')) {
        fprintf(stderr, "You need to specify both emu_in and emu_out.\n");
        return 1;
    }
    return 0;
}

static char **load_file_words(const char *path, int *count) {
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "File not found: %s\n", path);
        return NULL;
    }
    char **items = calloc(256, sizeof(char *));
    int cap = 256, n = 0;
    char token[256];
    int len = 0, ch;
    while ((ch = fgetc(f)) != EOF) {
        if (ch == ',' || ch == '\n' || ch == '\r' || ch == '\t' || ch == ' ') {
            if (len > 0) {
                token[len] = '\0';
                if (n >= cap) {
                    cap *= 2;
                    items = realloc(items, (size_t)cap * sizeof(char *));
                }
                items[n++] = strdup(token);
                len = 0;
            }
        } else if (len < (int)sizeof(token) - 1) {
            token[len++] = (char)ch;
        }
    }
    if (len > 0) {
        token[len] = '\0';
        if (n >= cap) {
            cap *= 2;
            items = realloc(items, (size_t)cap * sizeof(char *));
        }
        items[n++] = strdup(token);
    }
    fclose(f);
    *count = n;
    return items;
}

static int repeat_count(const char *s) {
    int n = 0;
    while (*s) {
        if (*s == '\033') {
            s++;
            if (*s == '[') {
                while (*s && !isalpha((unsigned char)*s)) s++;
                if (*s) s++;
            }
        } else {
            n++;
            s++;
        }
    }
    return n;
}

static void center_line(int row, int width, const char *text) {
    int len = repeat_count(text);
    int col = (width - len) / 2;
    if (col < 1) col = 1;
    printf("\033[%d;%dH%s", row, col, text);
}

static void build_lesson(const Config *cfg, const char **base, int base_count, char *out, size_t out_sz) {
    out[0] = '\0';
    int limit = cfg->top < base_count ? cfg->top : base_count;
    if (limit <= 0) limit = base_count;
    int used = cfg->combi < limit ? cfg->combi : limit;
    for (int r = 0; r < cfg->rep; r++) {
        for (int i = 0; i < used; i++) {
            const char *word = base[(i + r) % limit];
            if (out[0]) strncat(out, " ", out_sz - strlen(out) - 1);
            strncat(out, word, out_sz - strlen(out) - 1);
        }
    }
}

static void draw_keyboard(bool ortho) {
    if (ortho) {
        center_line(16, 80, "[ q ][ w ][ e ][ r ][ t ][ y ][ u ][ i ][ o ][ p ]");
        center_line(18, 80, "[ a ][ s ][ d ][ f ][ g ][ h ][ j ][ k ][ l ][ ; ]");
        center_line(20, 80, "[ z ][ x ][ c ][ v ][ b ][ n ][ m ][ , ][ . ][ / ]");
    } else {
        center_line(16, 80, "q  w  e  r  t  y  u  i  o  p");
        center_line(18, 80, " a  s  d  f  g  h  j  k  l");
        center_line(20, 80, "  z  x  c  v  b  n  m");
    }
}

static void draw_screen(const Config *cfg, const char *lesson, const char *typed, int ok, int bad, int lesson_no, int width) {
    if (width < 60) width = 80;
    printf("\033[?1049h\033[2J\033[?25l");
    printf("\033[1;1H");
    for (int i = 0; i < width - 1; i++) putchar('-');
    printf("\033[1;%dHQuit \033[1m\033[38;5;4m<esc>\033[22m\033[39m", width > 20 ? width - 11 : 1);
    center_line(2, width, "\033[1mngrrram!\033[22m \033[3m\033[38;5;7mby winterveil\033[23m\033[39m");
    printf("\033[4;6HLesson #%d", lesson_no);
    printf("\033[4;%dH\033[38;5;2m✓: %d, \033[38;5;1m✘: %d\033[39m", width > 25 ? width - 20 : 40, ok, bad);
    center_line(7, width, lesson);
    center_line(8, width, "\033[38;5;7m");
    center_line(8, width, typed);
    printf("\033[11;3H\033[38;5;7mneed >= %3dWPM,   avg. \033[39m0WPM\033[38;5;7m,   last \033[39m0WPM", cfg->wpm);
    printf("\033[12;3H\033[38;5;7mneed >= %3d%% Acc, avg. \033[39m0%%Acc\033[38;5;7m, last \033[39m0%%Acc", cfg->acc);
    if (cfg->cat) {
        center_line(14, width, " /\\_/\\\\");
        center_line(15, width, "( o.o )");
        center_line(16, width, " > ^ <");
    } else if (!cfg->nokb) {
        draw_keyboard(cfg->show_ortho);
    }
    printf("\033[?25h");
    fflush(stdout);
}

static int interactive(const Config *cfg, const char *lesson) {
    printf("\033[?1049h");
    fflush(stdout);
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fprintf(stderr, "Error: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
        return 1;
    }

    struct termios oldt, raw;
    if (tcgetattr(STDIN_FILENO, &oldt) != 0) {
        fprintf(stderr, "Error: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
        return 1;
    }
    raw = oldt;
    raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    struct winsize ws;
    int width = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0) width = ws.ws_col;

    char typed[4096] = "";
    int pos = 0, ok = 0, bad = 0, lesson_no = 0;
    draw_screen(cfg, lesson, typed, ok, bad, lesson_no, width);
    while (!stop_requested) {
        unsigned char ch;
        ssize_t n = read(STDIN_FILENO, &ch, 1);
        if (n <= 0) {
            struct timespec pause_for = {0, 30000000L};
            nanosleep(&pause_for, NULL);
            continue;
        }
        if (ch == 27 || ch == 3 || ch == 4) break;
        if (ch == 127 || ch == 8) {
            if (pos > 0) typed[--pos] = '\0';
        } else if (isprint(ch) && pos < (int)sizeof(typed) - 1) {
            typed[pos++] = (char)ch;
            typed[pos] = '\0';
            if (lesson[pos - 1] == (char)ch) ok++; else bad++;
            if ((int)strlen(lesson) == pos) {
                lesson_no++;
                pos = 0;
                typed[0] = '\0';
            }
        }
        draw_screen(cfg, lesson, typed, ok, bad, lesson_no, width);
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\033[?25h\033[?1049l");
    fflush(stdout);
    return 0;
}

int main(int argc, char **argv) {
    Config cfg;
    int r = parse_args(argc, argv, &cfg);
    if (r) return r;

    const char **base = bigrams;
    int base_count = (int)(sizeof(bigrams) / sizeof(bigrams[0]));
    char **file_items = NULL;
    if (cfg.n_mode == 3) {
        base = trigrams;
        base_count = (int)(sizeof(trigrams) / sizeof(trigrams[0]));
    } else if (cfg.n_mode == 4) {
        base = tetragrams;
        base_count = (int)(sizeof(tetragrams) / sizeof(tetragrams[0]));
    } else if (cfg.n_mode == 5) {
        base = words;
        base_count = (int)(sizeof(words) / sizeof(words[0]));
    } else if (cfg.n_mode == 0) {
        file_items = load_file_words(cfg.n_arg, &base_count);
        if (!file_items) return 1;
        base = (const char **)file_items;
    }

    char lesson[4096];
    build_lesson(&cfg, base, base_count, lesson, sizeof(lesson));
    r = interactive(&cfg, lesson);

    if (file_items) {
        for (int i = 0; i < base_count; i++) free(file_items[i]);
        free(file_items);
    }
    return r;
}
