#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define VERSION "hwatch 0.3.19"

static volatile sig_atomic_t stop_flag = 0;
static void on_signal(int sig) { (void)sig; stop_flag = 1; }

typedef struct {
    int batch, beep, border, scrollbar, mouse, color, reverse, compress;
    int no_title, summary_char, line_number, no_help_banner, no_summary;
    int exec_direct, diff_output_only, precise;
    double interval;
    long limit;
    int tab_size;
    char *aftercommand, *logfile, *shell, *differences, *output, *keymap;
} Options;

typedef struct { char *data; size_t len, cap; } Buf;
static void binit(Buf *b){ b->cap=4096; b->len=0; b->data=malloc(b->cap); if(!b->data) exit(1); b->data[0]=0; }
static void baddn(Buf *b, const char *s, size_t n){ if(b->len+n+1>b->cap){ while(b->len+n+1>b->cap) b->cap*=2; b->data=realloc(b->data,b->cap); if(!b->data) exit(1);} memcpy(b->data+b->len,s,n); b->len+=n; b->data[b->len]=0; }
static void badds(Buf *b, const char *s){ baddn(b,s,strlen(s)); }

static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) exit(1); return p; }

static void print_help(void){
    puts("A modern alternative to the watch command, records the differences in execution results and can check this differences at after.\n");
    puts("Usage: executable [OPTIONS] [command]...\n");
    puts("Arguments:\n  [command]...  \n");
    puts("Options:");
    puts("  -b, --batch                         output execution results to stdout");
    puts("  -B, --beep                          beep if command has a change result");
    puts("      --border                        Surround each pane with a border frame");
    puts("      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.");
    puts("      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.");
    puts("  -c, --color                         interpret ANSI color and style sequences");
    puts("  -r, --reverse                       display text upside down.");
    puts("  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.");
    puts("  -t, --no-title                      hide the UI on start. Use `t` to toggle it.");
    puts("      --enable-summary-char           collect character-level diff count in summary.");
    puts("  -N, --line-number                   show line number");
    puts("      --no-help-banner                hide the \"Display help with h key\" message");
    puts("      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.");
    puts("  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.");
    puts("  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.");
    puts("  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.");
    puts("  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.");
    puts("  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: \"sh -c\"]");
    puts("  -n, --interval <interval>           seconds to wait between updates [default: 2]");
    puts("      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run");
    puts("  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]");
    puts("      --tab-size <tab_size>           Specifying tab display size [default: 4]");
    puts("  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]");
    puts("  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]");
    puts("  -K, --keymap <keymap>               Add keymap");
    puts("  -h, --help                          Print help");
    puts("  -V, --version                       Print version");
}

static int valid_choice(const char *s, const char **vals){ for(int i=0; vals[i]; i++) if(strcmp(s,vals[i])==0) return 1; return 0; }
static void init_opts(Options *o){ memset(o,0,sizeof(*o)); o->interval=2.0; o->limit=5000; o->tab_size=4; o->shell=xstrdup("sh -c"); o->differences=xstrdup("none"); o->output=xstrdup("output"); }

static char **split_words(const char *s, int *argc_out){
    int cap=8,n=0; char **v=calloc(cap,sizeof(char*)); const char *p=s;
    while(p && *p){ while(isspace((unsigned char)*p)) p++; if(!*p) break; char quote=0; Buf b; binit(&b);
        while(*p && (quote || !isspace((unsigned char)*p))){ if((*p=='\''||*p=='"') && !quote){ quote=*p++; continue; } if(quote && *p==quote){ quote=0; p++; continue; } if(*p=='\\' && p[1]) p++; baddn(&b,p++,1); }
        if(n+1>=cap){cap*=2; v=realloc(v,cap*sizeof(char*));} v[n++]=b.data;
    }
    v[n]=NULL; *argc_out=n; return v;
}

static void apply_arg(Options *o, const char *arg, const char *val){
    if(!strcmp(arg,"-b")||!strcmp(arg,"--batch")) o->batch=1;
    else if(!strcmp(arg,"-B")||!strcmp(arg,"--beep")) o->beep=1;
    else if(!strcmp(arg,"--border")) o->border=1;
    else if(!strcmp(arg,"--with-scrollbar")) o->scrollbar=1;
    else if(!strcmp(arg,"--mouse")) o->mouse=1;
    else if(!strcmp(arg,"-c")||!strcmp(arg,"--color")) o->color=1;
    else if(!strcmp(arg,"-r")||!strcmp(arg,"--reverse")) o->reverse=1;
    else if(!strcmp(arg,"-C")||!strcmp(arg,"--compress")) o->compress=1;
    else if(!strcmp(arg,"-t")||!strcmp(arg,"--no-title")) o->no_title=1;
    else if(!strcmp(arg,"--enable-summary-char")) o->summary_char=1;
    else if(!strcmp(arg,"-N")||!strcmp(arg,"--line-number")) o->line_number=1;
    else if(!strcmp(arg,"--no-help-banner")) o->no_help_banner=1;
    else if(!strcmp(arg,"--no-summary")) o->no_summary=1;
    else if(!strcmp(arg,"-x")||!strcmp(arg,"-e")||!strcmp(arg,"--exec")) o->exec_direct=1;
    else if(!strcmp(arg,"-O")||!strcmp(arg,"--diff-output-only")) o->diff_output_only=1;
    else if(!strcmp(arg,"--precise")) o->precise=1;
    else if(val && (!strcmp(arg,"-A")||!strcmp(arg,"--aftercommand"))) { free(o->aftercommand); o->aftercommand=xstrdup(val); }
    else if(!strcmp(arg,"-l")||!strcmp(arg,"--logfile")) { free(o->logfile); o->logfile=xstrdup(val?val:"hwatch.log"); }
    else if(val && (!strcmp(arg,"-s")||!strcmp(arg,"--shell"))) { free(o->shell); o->shell=xstrdup(val); }
    else if(val && (!strcmp(arg,"-n")||!strcmp(arg,"--interval"))) o->interval=strtod(val,NULL);
    else if(val && (!strcmp(arg,"-L")||!strcmp(arg,"--limit"))) o->limit=strtol(val,NULL,10);
    else if(val && !strcmp(arg,"--tab-size")) o->tab_size=(int)strtol(val,NULL,10);
    else if(!strcmp(arg,"-d")||!strcmp(arg,"--differences")) { free(o->differences); o->differences=xstrdup(val?val:"watch"); }
    else if(!strcmp(arg,"-o")||!strcmp(arg,"--output")) { free(o->output); o->output=xstrdup(val?val:"output"); }
    else if(val && (!strcmp(arg,"-K")||!strcmp(arg,"--keymap"))) { free(o->keymap); o->keymap=xstrdup(val); }
}

static int parse_all(int argc, char **argv, Options *o, int *cmd_index){
    char *env=getenv("HWATCH");
    if(env && *env){ int ea=0; char **ev=split_words(env,&ea); for(int i=0;i<ea;i++){
            char *a=ev[i], *val=NULL; char *eq=strchr(a,'='); if(eq && a[0]=='-'){ *eq=0; val=eq+1; }
            if((!strcmp(a,"-n")||!strcmp(a,"--interval")||!strcmp(a,"-A")||!strcmp(a,"--aftercommand")||!strcmp(a,"-s")||!strcmp(a,"--shell")||!strcmp(a,"-L")||!strcmp(a,"--limit")||!strcmp(a,"--tab-size")||!strcmp(a,"-K")||!strcmp(a,"--keymap")) && !val && i+1<ea) val=ev[++i];
            else if((!strcmp(a,"-d")||!strcmp(a,"--differences")||!strcmp(a,"-o")||!strcmp(a,"--output")||!strcmp(a,"-l")||!strcmp(a,"--logfile")) && !val && i+1<ea && ev[i+1][0]!='-') val=ev[++i];
            apply_arg(o,a,val);
        }}
    enum {OPT_BORDER=1000, OPT_SCROLL, OPT_SUMMARY_CHAR, OPT_NO_HELP, OPT_NO_SUMMARY, OPT_PRECISE, OPT_TAB};
    static struct option longopts[]={
        {"batch",0,0,'b'},{"beep",0,0,'B'},{"border",0,0,OPT_BORDER},{"with-scrollbar",0,0,OPT_SCROLL},{"mouse",0,0,1},{"color",0,0,'c'},
        {"reverse",0,0,'r'},{"compress",0,0,'C'},{"no-title",0,0,'t'},{"enable-summary-char",0,0,OPT_SUMMARY_CHAR},{"line-number",0,0,'N'},
        {"no-help-banner",0,0,OPT_NO_HELP},{"no-summary",0,0,OPT_NO_SUMMARY},{"exec",0,0,'x'},{"diff-output-only",0,0,'O'},
        {"aftercommand",1,0,'A'},{"logfile",2,0,'l'},{"shell",1,0,'s'},{"interval",1,0,'n'},{"precise",0,0,OPT_PRECISE},{"limit",1,0,'L'},
        {"tab-size",1,0,OPT_TAB},{"differences",2,0,'d'},{"output",2,0,'o'},{"keymap",1,0,'K'},{"help",0,0,'h'},{"version",0,0,'V'},{0,0,0,0}};
    opterr=0; int c, idx;
    while((c=getopt_long(argc,argv,"bBcrCtNxOA:l::s:n:L:d::o::K:hVe",longopts,&idx))!=-1){
        switch(c){
            case 'b': o->batch=1; break; case 'B': o->beep=1; break; case 1: o->mouse=1; break; case 'c': o->color=1; break; case 'r': o->reverse=1; break; case 'C': o->compress=1; break; case 't': o->no_title=1; break; case 'N': o->line_number=1; break; case 'x': case 'e': o->exec_direct=1; break; case 'O': o->diff_output_only=1; break; case OPT_BORDER: o->border=1; break; case OPT_SCROLL: o->scrollbar=1; break; case OPT_SUMMARY_CHAR: o->summary_char=1; break; case OPT_NO_HELP: o->no_help_banner=1; break; case OPT_NO_SUMMARY: o->no_summary=1; break; case OPT_PRECISE: o->precise=1; break;
            case 'A': free(o->aftercommand); o->aftercommand=xstrdup(optarg); break;
            case 'l':
                if(!optarg && optind<argc && argv[optind][0]!='-') optarg=argv[optind++];
                free(o->logfile); o->logfile=xstrdup(optarg?optarg:"hwatch.log"); break;
            case 's': free(o->shell); o->shell=xstrdup(optarg); break;
            case 'n': { char *end=NULL; double d=strtod(optarg,&end); if(!optarg[0]||*end){ fprintf(stderr,"error: invalid value '%s' for '--interval <interval>': invalid float literal\n\nFor more information, try '--help'.\n",optarg); return 2;} o->interval=d<0.001?0.001:d; break; }
            case 'L': o->limit=strtol(optarg,NULL,10); break; case OPT_TAB: o->tab_size=(int)strtol(optarg,NULL,10); break;
            case 'd':
                if(!optarg && optind<argc && argv[optind][0]!='-') optarg=argv[optind++];
                free(o->differences); o->differences=xstrdup(optarg?optarg:"watch"); break;
            case 'o':
                if(!optarg && optind<argc && argv[optind][0]!='-') optarg=argv[optind++];
                free(o->output); o->output=xstrdup(optarg?optarg:"output"); break;
            case 'K': free(o->keymap); o->keymap=xstrdup(optarg); break;
            case 'h': print_help(); exit(0); case 'V': puts(VERSION); exit(0);
            case '?': fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try '--help'.\n", argv[optind-1]); return 2;
        }
    }
    const char *diffs[]={"none","watch","line","word",NULL}; const char *outs[]={"output","stdout","stderr",NULL};
    if(!valid_choice(o->differences,diffs)){ fprintf(stderr,"error: invalid value '%s' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]\n\nFor more information, try '--help'.\n", o->differences); return 2; }
    if(!valid_choice(o->output,outs)){ fprintf(stderr,"error: invalid value '%s' for '--output [<output>]'\n  [possible values: output, stdout, stderr]\n\nFor more information, try '--help'.\n", o->output); return 2; }
    *cmd_index=optind; return 0;
}

static char *join_args(int argc, char **argv){ Buf b; binit(&b); for(int i=0;i<argc;i++){ if(i) badds(&b," "); badds(&b,argv[i]); } return b.data; }
static char *json_escape(const char *s){ Buf b; binit(&b); for(; *s; s++){ unsigned char c=*s; if(c=='\\'||c=='\"'){ char x[3]={'\\',c,0}; badds(&b,x);} else if(c=='\n') badds(&b,"\\n"); else if(c=='\r') badds(&b,"\\r"); else if(c=='\t') badds(&b,"\\t"); else if(c<32){ char tmp[7]; snprintf(tmp,sizeof tmp,"\\u%04x",c); badds(&b,tmp);} else baddn(&b,s,1);} return b.data; }
static void timestamp(char *buf, size_t n, int millis){ struct timeval tv; gettimeofday(&tv,NULL); struct tm tm; localtime_r(&tv.tv_sec,&tm); if(millis) snprintf(buf,n,"%04d-%02d-%02d %02d:%02d:%02d.%03ld",tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tv.tv_usec/1000); else strftime(buf,n,"%Y-%m-%dT%H:%M:%S",&tm); }

static int read_fd_nonblock(int fd, Buf *b){ char tmp[4096]; int total=0; for(;;){ ssize_t r=read(fd,tmp,sizeof tmp); if(r>0){ baddn(b,tmp,(size_t)r); total+=r; } else if(r<0 && (errno==EAGAIN||errno==EWOULDBLOCK)) break; else break; } return total; }
static int run_command(Options *o, int cargc, char **cargv, char **outp, char **errp){
    int po[2], pe[2]; pipe(po); pipe(pe); pid_t pid=fork();
    if(pid==0){ close(po[0]); close(pe[0]); dup2(po[1],1); dup2(pe[1],2); close(po[1]); close(pe[1]);
        if(o->exec_direct){ execvp(cargv[0],cargv); perror(cargv[0]); _exit(127); }
        char *cmd=join_args(cargc,cargv);
        char *brace=strstr(o->shell,"{COMMAND}");
        if(brace){ Buf full; binit(&full); baddn(&full,o->shell,(size_t)(brace-o->shell)); badds(&full,cmd); badds(&full,brace+9); execl("/bin/sh","sh","-c",full.data,(char*)NULL); }
        else { execl("/bin/sh","sh","-c",cmd,(char*)NULL); }
        perror("sh"); _exit(127);
    }
    close(po[1]); close(pe[1]); fcntl(po[0],F_SETFL,O_NONBLOCK); fcntl(pe[0],F_SETFL,O_NONBLOCK); Buf ob, eb; binit(&ob); binit(&eb); int status=0;
    for(;;){ read_fd_nonblock(po[0],&ob); read_fd_nonblock(pe[0],&eb); int w=waitpid(pid,&status,WNOHANG); if(w==pid) break; fd_set rf; FD_ZERO(&rf); FD_SET(po[0],&rf); FD_SET(pe[0],&rf); int max=po[0]>pe[0]?po[0]:pe[0]; struct timeval tv={0,100000}; select(max+1,&rf,NULL,NULL,&tv); }
    read_fd_nonblock(po[0],&ob); read_fd_nonblock(pe[0],&eb); close(po[0]); close(pe[0]); *outp=ob.data; *errp=eb.data; if(WIFEXITED(status)) return WEXITSTATUS(status); if(WIFSIGNALED(status)) return 128+WTERMSIG(status); return 1;
}
static char **split_lines(const char *s, int *n){ int cap=16; char **v=malloc(cap*sizeof(char*)); *n=0; const char *p=s; while(*p){ const char *e=strchr(p,'\n'); size_t len=e?(size_t)(e-p):strlen(p); char *line=malloc(len+2); memcpy(line,p,len); line[len]=0; if(*n>=cap){cap*=2; v=realloc(v,cap*sizeof(char*));} v[(*n)++]=line; if(!e) break; p=e+1;} return v; }
static void print_processed(const char *s, Options *o){
    if(!o->reverse && !o->line_number){ fputs(s,stdout); if(s[0] && s[strlen(s)-1]!='\n') putchar('\n'); return; }
    int n=0; char **lines=split_lines(s,&n); if(o->reverse){ for(int i=n-1;i>=0;i--){ if(o->line_number) printf("%6d: ", i+1); puts(lines[i]); } } else { for(int i=0;i<n;i++){ if(o->line_number) printf("%6d: ", i+1); puts(lines[i]); } } for(int i=0;i<n;i++) free(lines[i]); free(lines);
}
static void write_log(const char *path, const char *cmd, int status, const char *out, const char *err){ FILE *f=fopen(path,"a"); if(!f) return; char ts[64]; timestamp(ts,sizeof ts,0); Buf comb; binit(&comb); badds(&comb,out); badds(&comb,err); char *jts=json_escape(ts), *jc=json_escape(cmd), *jo=json_escape(comb.data), *jout=json_escape(out), *je=json_escape(err); fprintf(f,"{\"timestamp\":\"%s\",\"command\":\"%s\",\"status\":%s,\"output\":\"%s\",\"stdout\":\"%s\",\"stderr\":\"%s\"}\n",jts,jc,status==0?"true":"false",jo,jout,je); fclose(f); free(jts);free(jc);free(jo);free(jout);free(je);free(comb.data); }

int main(int argc, char **argv){ Options opt; init_opts(&opt); int cmdi=0; int pr=parse_all(argc,argv,&opt,&cmdi); if(pr) return pr; if(cmdi>=argc){ fprintf(stderr,"error: command not specified and logfile is empty.\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try '--help'.\n"); return 2; }
    signal(SIGTERM,on_signal); signal(SIGINT,on_signal); char *cmdstr=join_args(argc-cmdi, argv+cmdi); char *prev=NULL; int first=1;
    while(!stop_flag){ char ts[80]; timestamp(ts,sizeof ts,1); char *out=NULL,*err=NULL; int st=run_command(&opt,argc-cmdi,argv+cmdi,&out,&err); Buf selected; binit(&selected); if(strcmp(opt.output,"stderr")) badds(&selected,out); if(strcmp(opt.output,"stdout")) badds(&selected,err);
        int changed = !prev || strcmp(prev,selected.data)!=0;
        if(opt.batch || !isatty(1)){ printf("\033[38;5;240m=====[%s]=========================\033[0m\n",ts); print_processed(selected.data,&opt); putchar('\n'); fflush(stdout); }
        else { printf("Every %.3gs: %s\n", opt.interval, cmdstr); print_processed(selected.data,&opt); fflush(stdout); }
        if(opt.beep && !first && changed) { fputc('\a', stdout); fflush(stdout); }
        if(opt.logfile && changed) write_log(opt.logfile,cmdstr,st,out,err);
        if(opt.aftercommand && !first && changed){ char *jo=json_escape(selected.data); Buf data; binit(&data); badds(&data,"{\"output\":\""); badds(&data,jo); badds(&data,"\"}"); setenv("HWATCH_DATA",data.data,1); system(opt.aftercommand); free(jo); free(data.data); }
        free(prev); prev=xstrdup(selected.data); free(selected.data); free(out); free(err); first=0;
        if(stop_flag) break; usleep((useconds_t)(opt.interval*1000000.0)); }
    free(prev); free(cmdstr); return 0; }
