#define _POSIX_C_SOURCE 200112L
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} Buf;

static const char *help_text =
"bat is a Go implemented CLI cURL-like tool for humans.\n"
"\n"
"Usage:\n"
"\n"
"\tbat [flags] [METHOD] URL [ITEM [ITEM]]\n"
"\n"
"flags:\n"
"  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument\n"
"  -b, -bench=false            Sends bench requests to URL\n"
"  -b.N=1000                   Number of requests to run\n"
"  -b.C=100                    Number of requests to run concurrently\n"
"  -body=\"\"                    Send RAW data as body\n"
"  -f, -form=false             Submitting the data as a form\n"
"  -j, -json=true              Send the data in a JSON object\n"
"  -p, -pretty=true            Print Json Pretty Format\n"
"  -i, -insecure=false         Allow connections to SSL sites without certs\n"
"  -proxy=PROXY_URL            Proxy with host and port\n"
"  -print=\"A\"                  String specifying what the output should contain, default will print all information\n"
"         \"H\" request headers\n"
"         \"B\" request body\n"
"         \"h\" response headers\n"
"         \"b\" response body\n"
"  -v, -version=true           Show Version Number\n"
"\n"
"METHOD:\n"
"  bat defaults to either GET (if there is no request data) or POST (with request data).\n"
"\n"
"URL:\n"
"  The only information needed to perform a request is a URL. The default scheme is http://,\n"
"  which can be omitted from the argument; example.org works just fine.\n"
"\n"
"ITEM:\n"
"  Can be any of:\n"
"    Query string   key=value\n"
"    Header         key:value\n"
"    Post data      key=value\n"
"    File upload    key@/path/file\n"
"\n"
"Example:\n"
"\n"
"\tbat beego.me\n"
"\n"
"more help information please refer to https://github.com/astaxie/bat\n";

static void buf_init(Buf *b) { b->data = NULL; b->len = b->cap = 0; }
static void buf_reserve(Buf *b, size_t n) {
    if (n <= b->cap) return;
    size_t c = b->cap ? b->cap * 2 : 256;
    while (c < n) c *= 2;
    char *p = realloc(b->data, c);
    if (!p) exit(2);
    b->data = p; b->cap = c;
}
static void buf_appendn(Buf *b, const char *s, size_t n) {
    buf_reserve(b, b->len + n + 1);
    memcpy(b->data + b->len, s, n);
    b->len += n;
    b->data[b->len] = 0;
}
static void buf_append(Buf *b, const char *s) { buf_appendn(b, s, strlen(s)); }
static void buf_printf(Buf *b, const char *fmt, ...) {
    va_list ap, cp;
    va_start(ap, fmt);
    va_copy(cp, ap);
    int n = vsnprintf(NULL, 0, fmt, cp);
    va_end(cp);
    if (n < 0) exit(2);
    buf_reserve(b, b->len + (size_t)n + 1);
    vsnprintf(b->data + b->len, (size_t)n + 1, fmt, ap);
    va_end(ap);
    b->len += (size_t)n;
}

static bool is_method(const char *s) {
    const char *m[] = {"GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS",NULL};
    for (int i=0;m[i];i++) if (!strcasecmp(s,m[i])) return true;
    return false;
}
static char *xstrdup(const char *s) {
    if (!s) s = "";
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (!p) exit(2);
    memcpy(p, s, n);
    return p;
}
static char *upper_dup(const char *s) {
    char *p = xstrdup(s);
    for (char *q=p; *q; q++) *q = (char)toupper((unsigned char)*q);
    return p;
}
static void logerr(const char *fileline, const char *fmt, ...) {
    printf("2026/05/27 17:00:00.000000 %s: ", fileline);
    va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap);
    printf("\n");
}

static char *urlenc(const char *s) {
    static const char hex[]="0123456789ABCDEF";
    Buf b; buf_init(&b);
    for (; *s; s++) {
        unsigned char c=(unsigned char)*s;
        if (isalnum(c) || c=='-' || c=='_' || c=='.' || c=='~') {
            char ch=(char)c; buf_appendn(&b,&ch,1);
        } else if (c==' ') {
            buf_append(&b, "+");
        } else {
            char e[3]={'%',hex[c>>4],hex[c&15]}; buf_appendn(&b,e,3);
        }
    }
    return b.data ? b.data : xstrdup("");
}

static void json_escape(Buf *b, const char *s) {
    for (; *s; s++) {
        unsigned char c=(unsigned char)*s;
        if (c=='"' || c=='\\') { char tmp[2]={'\\',(char)c}; buf_appendn(b,tmp,2); }
        else if (c=='\n') buf_append(b,"\\n");
        else if (c=='\r') buf_append(b,"\\r");
        else if (c=='\t') buf_append(b,"\\t");
        else if (c < 32) buf_printf(b,"\\u%04x",c);
        else { char ch=(char)c; buf_appendn(b,&ch,1); }
    }
}

static char *make_json(char **items, int n) {
    Buf b; buf_init(&b); buf_append(&b, "{");
    int count=0;
    for (int i=0;i<n;i++) {
        char *eq=strchr(items[i],'=');
        if (!eq || (eq>items[i] && eq[-1]=='=')) continue;
        if (count++) buf_append(&b, ",");
        buf_append(&b, "\"");
        char save=*eq; *eq=0; json_escape(&b, items[i]); *eq=save;
        buf_append(&b, "\":\"");
        json_escape(&b, eq+1);
        buf_append(&b, "\"");
    }
    buf_append(&b, "}\n");
    return b.data;
}

static char *make_form(char **items, int n) {
    Buf b; buf_init(&b); int count=0;
    for (int i=0;i<n;i++) {
        char *eq=strchr(items[i],'=');
        if (!eq || (eq>items[i] && eq[-1]=='=')) continue;
        char save=*eq; *eq=0;
        char *k=urlenc(items[i]), *v=urlenc(eq+1);
        *eq=save;
        if (count++) buf_append(&b, "&");
        buf_append(&b,k); buf_append(&b,"="); buf_append(&b,v);
        free(k); free(v);
    }
    return b.data ? b.data : xstrdup("");
}

static const char b64tab[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static char *base64(const char *s) {
    size_t n=strlen(s); Buf b; buf_init(&b);
    for (size_t i=0;i<n;i+=3) {
        unsigned a=(unsigned char)s[i], c = i+1<n?(unsigned char)s[i+1]:0, d = i+2<n?(unsigned char)s[i+2]:0;
        char out[4];
        out[0]=b64tab[a>>2];
        out[1]=b64tab[((a&3)<<4)|(c>>4)];
        out[2]= i+1<n ? b64tab[((c&15)<<2)|(d>>6)] : '=';
        out[3]= i+2<n ? b64tab[d&63] : '=';
        buf_appendn(&b,out,4);
    }
    return b.data ? b.data : xstrdup("");
}

typedef struct {
    char *scheme, *host, *port, *path, *hostport;
} Url;

static Url parse_url(const char *in) {
    Url u={0};
    char *tmp;
    if (strstr(in, "://")) tmp=xstrdup(in); else { Buf b; buf_init(&b); buf_append(&b,"http://"); buf_append(&b,in); tmp=b.data; }
    char *p=strstr(tmp,"://"); *p=0; u.scheme=xstrdup(tmp); char *rest=p+3;
    char *slash=strchr(rest,'/');
    char *auth_at=strchr(rest,'@');
    if (auth_at && (!slash || auth_at < slash)) rest=auth_at+1;
    if (slash) { *slash=0; u.path=xstrdup(slash+1); } else u.path=xstrdup("");
    char *hp=xstrdup(rest);
    char *colon=strrchr(hp,':');
    if (colon && strchr(colon+1, ']')==NULL) { *colon=0; u.host=xstrdup(hp); u.port=xstrdup(colon+1); }
    else { u.host=xstrdup(hp); u.port=xstrdup(!strcasecmp(u.scheme,"https") ? "443" : "80"); }
    u.hostport=xstrdup(rest);
    if (!*u.path) { free(u.path); u.path=xstrdup("/"); } else { char *old=u.path; Buf b; buf_init(&b); buf_append(&b,"/"); buf_append(&b,old); u.path=b.data; free(old); }
    free(hp); free(tmp); return u;
}

static int connect_host(const char *host, const char *port) {
    struct addrinfo hints, *res=0, *rp;
    memset(&hints,0,sizeof(hints)); hints.ai_socktype=SOCK_STREAM; hints.ai_family=AF_UNSPEC;
    int e=getaddrinfo(host,port,&hints,&res);
    if (e) return -1;
    int fd=-1;
    for (rp=res; rp; rp=rp->ai_next) {
        fd=socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol);
        if (fd<0) continue;
        if (!connect(fd,rp->ai_addr,rp->ai_addrlen)) break;
        close(fd); fd=-1;
    }
    freeaddrinfo(res); return fd;
}

static char *strcasestr_local(const char *h, const char *n) {
    size_t nl=strlen(n);
    for (; *h; h++) if (!strncasecmp(h,n,nl)) return (char*)h;
    return NULL;
}

static void pretty_json(const char *s, size_t n, Buf *out) {
    int indent=0; bool in=false, esc=false;
    for (size_t i=0;i<n;i++) {
        char c=s[i];
        if (in) {
            buf_appendn(out,&c,1);
            if (esc) esc=false;
            else if (c=='\\') esc=true;
            else if (c=='"') in=false;
            continue;
        }
        if (c=='"') { in=true; buf_appendn(out,&c,1); }
        else if (c=='{' || c=='[') {
            buf_appendn(out,&c,1); buf_append(out,"\n"); indent++;
            for (int j=0;j<indent*2;j++) buf_append(out," ");
        } else if (c=='}' || c==']') {
            buf_append(out,"\n"); if (indent>0) indent--;
            for (int j=0;j<indent*2;j++) buf_append(out," ");
            buf_appendn(out,&c,1);
        } else if (c==',') {
            buf_appendn(out,&c,1); buf_append(out,"\n");
            for (int j=0;j<indent*2;j++) buf_append(out," ");
        } else if (c==':') {
            buf_append(out,": ");
        } else if (!isspace((unsigned char)c)) {
            buf_appendn(out,&c,1);
        }
    }
}

int main(int argc, char **argv) {
    bool form=false, json=true, pretty=true, bench=false, insecure=false;
    int bench_n=1000, bench_c=100;
    char *auth=NULL, *body_opt=NULL, *proxy=NULL, *print_opt="A";
    int first=1;
    for (; first<argc; first++) {
        char *a=argv[first];
        if (a[0] != '-' || !strcmp(a,"-")) break;
        if (!strcmp(a,"--help") || !strcmp(a,"-help") || !strcmp(a,"-h")) { fputs(help_text, stdout); return 0; }
        if (!strcmp(a,"-v") || !strcmp(a,"--version") || !strcmp(a,"-version")) { puts("Version: 0.1.0"); return 0; }
        char *val=NULL, *name=a+1; if (*name=='-') name++;
        char *eq=strchr(name,'='); if (eq) { *eq=0; val=eq+1; }
        #define NEEDVAL() do{ if(!val){ if(first+1<argc) val=argv[++first]; else val=""; } }while(0)
        if (!strcmp(name,"a") || !strcmp(name,"auth")) { NEEDVAL(); auth=val; }
        else if (!strcmp(name,"body")) { NEEDVAL(); body_opt=val; }
        else if (!strcmp(name,"proxy")) { NEEDVAL(); proxy=val; }
        else if (!strcmp(name,"print")) { NEEDVAL(); print_opt=val; (void)print_opt; }
        else if (!strcmp(name,"f") || !strcmp(name,"form")) form = val ? !(!strcmp(val,"false")||!strcmp(val,"0")) : true;
        else if (!strcmp(name,"j") || !strcmp(name,"json")) json = val ? !(!strcmp(val,"false")||!strcmp(val,"0")) : true;
        else if (!strcmp(name,"p") || !strcmp(name,"pretty")) pretty = val ? !(!strcmp(val,"false")||!strcmp(val,"0")) : true;
        else if (!strcmp(name,"i") || !strcmp(name,"insecure")) insecure = true;
        else if (!strcmp(name,"b") || !strcmp(name,"bench")) bench = val ? !(!strcmp(val,"false")||!strcmp(val,"0")) : true;
        else if (!strcmp(name,"b.N")) { NEEDVAL(); bench_n=atoi(val); }
        else if (!strcmp(name,"b.C")) { NEEDVAL(); bench_c=atoi(val); }
        else { fprintf(stderr,"flag provided but not defined: -%s\n", name); fputs(help_text, stderr); return 2; }
        #undef NEEDVAL
        if (eq) *eq='=';
    }
    (void)insecure; (void)bench_c;
    if (first >= argc) { fputs(help_text, stdout); return 2; }
    char *method=NULL, *urlarg=NULL;
    if (is_method(argv[first])) { method=upper_dup(argv[first++]); if (first>=argc) { logerr("filter.go:35","Miss the URL"); return 1; } urlarg=argv[first++]; }
    else urlarg=argv[first++];
    int itemn=argc-first; char **items=argv+first;
    if (!method) method=xstrdup((itemn>0 || body_opt) ? "POST" : "GET");
    Url u=parse_url(urlarg);
    Buf query; buf_init(&query);
    Buf headers; buf_init(&headers);
    for (int i=0;i<itemn;i++) {
        char *colon=strchr(items[i],':'), *eq=strchr(items[i],'=');
        if (colon && (!eq || colon < eq)) {
            char save=*colon; *colon=0; buf_printf(&headers, "%s: %s\r\n", items[i], colon+1); *colon=save;
        } else if (!strcmp(method,"GET") && eq) {
            char save=*eq; *eq=0; char *k=urlenc(items[i]), *v=urlenc(eq+1); *eq=save;
            buf_printf(&query, "%s%s=%s", query.len?"&":"", k, v); free(k); free(v);
        }
    }
    if (query.len) {
        Buf p; buf_init(&p); buf_append(&p,u.path); buf_append(&p, strchr(u.path,'?') ? "&" : "?"); buf_append(&p,query.data);
        free(u.path); u.path=p.data;
    }
    char *body=xstrdup(""); char *ctype=NULL;
    if (body_opt) { free(body); body=xstrdup(body_opt); }
    else if (strcmp(method,"GET") && strcmp(method,"HEAD")) {
        free(body);
        if (form) { body=make_form(items,itemn); ctype="application/x-www-form-urlencoded"; }
        else { (void)json; body=make_json(items,itemn); ctype="application/json"; }
    }
    if (body_opt) ctype=NULL;
    char *connect_host_s=u.host, *connect_port_s=u.port, *request_target=u.path;
    Url pu={0};
    if (proxy) { pu=parse_url(proxy); connect_host_s=pu.host; connect_port_s=pu.port; Buf full; buf_init(&full); buf_append(&full,u.scheme); buf_append(&full,"://"); buf_append(&full,u.hostport); buf_append(&full,u.path); request_target=full.data; }
    int fd=connect_host(connect_host_s, connect_port_s);
    if (fd < 0) { logerr("bat.go:215", "can't get the url %s \"http://%s%s\": %s", method[0]=='P'&&method[1]=='O' ? "Post" : "Get", u.hostport, u.path, strerror(errno)); return 1; }
    Buf req; buf_init(&req);
    buf_printf(&req, "%s %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: bat/0.1.0\r\n", method, request_target, u.hostport);
    if (*body) buf_printf(&req, "Content-Length: %zu\r\n", strlen(body));
    buf_append(&req, "Accept: application/json\r\nAccept-Encoding: gzip, deflate\r\n");
    if (ctype && *body) buf_printf(&req, "Content-Type: %s\r\n", ctype);
    if (auth) { char *enc=base64(auth); buf_printf(&req, "Authorization: Basic %s\r\n", enc); free(enc); }
    buf_append(&req, headers.data ? headers.data : "");
    buf_append(&req, "\r\n");
    if (*body) buf_append(&req, body);
    size_t sent=0; while (sent<req.len) { ssize_t w=write(fd, req.data+sent, req.len-sent); if (w<=0) break; sent+=(size_t)w; }
    Buf resp; buf_init(&resp);
    char tmp[8192]; ssize_t r;
    while ((r=read(fd,tmp,sizeof(tmp))) > 0) buf_appendn(&resp,tmp,(size_t)r);
    close(fd);
    char *sep=NULL;
    for (size_t i=0;i+3<resp.len;i++) if (!memcmp(resp.data+i,"\r\n\r\n",4)) { sep=resp.data+i+4; break; }
    if (!sep) sep=resp.data;
    size_t bodylen=resp.len - (size_t)(sep - resp.data);
    char *clp=strcasestr_local(resp.data,"Content-Length:");
    if (clp && clp < sep) { long cl=strtol(clp+15,NULL,10); if (cl>=0 && (size_t)cl<bodylen) bodylen=(size_t)cl; }
    putchar('\n');
    if (pretty && bodylen>0 && (sep[0]=='{' || sep[0]=='[')) {
        Buf out; buf_init(&out); pretty_json(sep,bodylen,&out); fwrite(out.data,1,out.len,stdout); free(out.data);
    } else fwrite(sep,1,bodylen,stdout);
    if (bench) fprintf(stderr, "\n%d requests completed\n", bench_n);
    return 0;
}
