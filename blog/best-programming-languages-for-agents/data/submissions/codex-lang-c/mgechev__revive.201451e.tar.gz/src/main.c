#define _DEFAULT_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    char *file;
    int line, col, end_col, offset;
    char *rule, *msg, *severity, *category;
} Finding;

typedef struct {
    Finding *v;
    size_t n, cap;
} Findings;

typedef struct {
    char **v;
    size_t n, cap;
} StrList;

typedef struct {
    bool package_comments, exported, line_length, blank_imports;
    int line_limit;
    int order[16];
    int order_n;
    char severity[32];
    bool has_config;
} Config;

enum { R_PACKAGE = 1, R_EXPORTED = 2, R_LINE_LENGTH = 3, R_BLANK_IMPORTS = 4 };

static void cfg_add_rule(Config *c, int r) {
    for (int i = 0; i < c->order_n; i++) if (c->order[i] == r) return;
    if (c->order_n < (int)(sizeof c->order / sizeof c->order[0])) c->order[c->order_n++] = r;
}

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) { perror("strdup"); exit(2); }
    return p;
}

static void sl_add(StrList *l, const char *s) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->v = realloc(l->v, l->cap * sizeof(char *));
        if (!l->v) { perror("realloc"); exit(2); }
    }
    l->v[l->n++] = xstrdup(s);
}

static void add_finding(Findings *fs, const char *file, int line, int col, int end_col, int offset,
                        const char *rule, const char *msg, const char *severity, const char *category) {
    if (fs->n == fs->cap) {
        fs->cap = fs->cap ? fs->cap * 2 : 32;
        fs->v = realloc(fs->v, fs->cap * sizeof(Finding));
        if (!fs->v) { perror("realloc"); exit(2); }
    }
    Finding *f = &fs->v[fs->n++];
    f->file = xstrdup(file); f->line = line; f->col = col; f->end_col = end_col; f->offset = offset;
    f->rule = xstrdup(rule); f->msg = xstrdup(msg); f->severity = xstrdup(severity); f->category = xstrdup(category);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool endswith(const char *s, const char *suf) {
    size_t a = strlen(s), b = strlen(suf);
    return a >= b && strcmp(s + a - b, suf) == 0;
}

static bool startswith(const char *s, const char *pre) {
    return strncmp(s, pre, strlen(pre)) == 0;
}

static const char *display_path(const char *p, bool from_dir) {
    if (from_dir && startswith(p, "./")) return p + 2;
    return p;
}

static void print_help(void) {
    printf("Usage of ./executable:\n\n");
    printf(" _ __ _____   _(_)__  _____\n");
    printf("| '__/ _ \\ \\ / / \\ \\ / / _ \\\n");
    printf("| | |  __/\\ V /| |\\ V /  __/\n");
    printf("|_|  \\___| \\_/ |_| \\_/ \\___|\n\n");
    printf("Example:\n");
    printf("  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...\n\n");
    printf("  -config string\n");
    printf("    \tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)\n");
    printf("  -exclude value\n");
    printf("    \tlist of globs which specify files to be excluded (i.e. -exclude foo/...)\n");
    printf("  -formatter string\n");
    printf("    \tformatter to be used for the output (i.e. -formatter stylish)\n");
    printf("  -max_open_files int\n");
    printf("    \tmaximum number of open files at the same time\n");
    printf("  -set_exit_status\n");
    printf("    \tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config\n");
    printf("  -version\n");
    printf("    \tget revive version\n");
}

static void print_version(void) {
    printf("Version:\ta75b67b\nCommit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05\nBuilt\t\t2026-04-17 19:59 UTC by build.sh\n");
}

static void default_init_error(void) {
    fprintf(stderr, "initializing revive - getting lint rules: cannot configure rule: \"var-naming\": load std packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: \n");
}

static int parse_config(const char *path, Config *c) {
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;
    c->has_config = true;
    strcpy(c->severity, "warning");
    char line[2048], current[128] = "";
    while (fgets(line, sizeof line, fp)) {
        char *s = trim(line);
        char *hash = strchr(s, '#'); if (hash) *hash = 0;
        s = trim(s);
        if (!*s) continue;
        if (*s == '[') {
            char *e = strchr(s, ']'); if (!e) continue; *e = 0;
            strncpy(current, s + 1, sizeof current - 1); current[sizeof current - 1] = 0;
            if (startswith(current, "rule.")) {
                const char *r = current + 5;
                if (!strcmp(r, "package-comments")) { c->package_comments = true; cfg_add_rule(c, R_PACKAGE); }
                else if (!strcmp(r, "exported")) { c->exported = true; cfg_add_rule(c, R_EXPORTED); }
                else if (!strcmp(r, "line-length-limit")) { c->line_length = true; if (!c->line_limit) c->line_limit = 80; cfg_add_rule(c, R_LINE_LENGTH); }
                else if (!strcmp(r, "blank-imports")) { c->blank_imports = true; cfg_add_rule(c, R_BLANK_IMPORTS); }
            }
            continue;
        }
        if (startswith(s, "severity")) {
            char *q = strchr(s, '"'); if (q) { char *e = strchr(q + 1, '"'); if (e) { *e = 0; strncpy(c->severity, q + 1, sizeof c->severity - 1); } }
        } else if (strstr(current, "line-length-limit") && startswith(s, "arguments")) {
            char *b = strchr(s, '['); if (b) { int v = atoi(b + 1); if (v > 0) c->line_limit = v; }
        } else if (startswith(s, "Disabled") || startswith(s, "disabled")) {
            if (strstr(s, "true")) {
                if (!strcmp(current, "rule.package-comments")) c->package_comments = false;
                if (!strcmp(current, "rule.exported")) c->exported = false;
                if (!strcmp(current, "rule.line-length-limit")) c->line_length = false;
                if (!strcmp(current, "rule.blank-imports")) c->blank_imports = false;
            }
        }
    }
    fclose(fp);
    return 0;
}

static bool is_excluded(const char *path, StrList *ex) {
    for (size_t i = 0; i < ex->n; i++) {
        const char *pat = ex->v[i];
        if (fnmatch(pat, path, 0) == 0) return true;
        if (endswith(pat, "/...")) {
            char base[1024]; snprintf(base, sizeof base, "%.*s", (int)(strlen(pat)-4), pat);
            if (startswith(path, base)) return true;
            if (startswith(base, "./") && startswith(path, base+2)) return true;
        }
    }
    return false;
}

static void collect_dir(const char *dir, bool rec, StrList *files, StrList *ex, bool from_dir) {
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..") || !strcmp(de->d_name, ".git")) continue;
        char p[4096]; snprintf(p, sizeof p, "%s/%s", dir, de->d_name);
        struct stat st; if (stat(p, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) { if (rec) collect_dir(p, true, files, ex, from_dir); }
        else if (S_ISREG(st.st_mode) && endswith(p, ".go") && !endswith(p, "_test.go") && !is_excluded(display_path(p, from_dir), ex)) sl_add(files, display_path(p, from_dir));
    }
    closedir(d);
}

static void collect_files(char **args, int n, StrList *files, StrList *ex) {
    if (n == 0) { collect_dir(".", false, files, ex, true); return; }
    for (int i = 0; i < n; i++) {
        char *a = args[i];
        if (endswith(a, "/...")) {
            char base[4096]; snprintf(base, sizeof base, "%.*s", (int)(strlen(a)-4), a);
            collect_dir(base, true, files, ex, true);
        } else {
            struct stat st;
            if (stat(a, &st) != 0) continue;
            if (S_ISDIR(st.st_mode)) collect_dir(a, false, files, ex, true);
            else if (S_ISREG(st.st_mode) && endswith(a, ".go") && !is_excluded(a, ex)) sl_add(files, a);
        }
    }
}

static bool ident_start(char c) { return isalpha((unsigned char)c) || c == '_'; }
static bool ident_char(char c) { return isalnum((unsigned char)c) || c == '_'; }

static bool has_package_comment(char **lines, int count, const char *pkg) {
    for (int i = 0; i < count; i++) {
        char *s = trim(lines[i]);
        if (!*s || startswith(s, "//go:") || startswith(s, "// +build") || startswith(s, "//go:build")) continue;
        if (startswith(s, "/*") || startswith(s, "//")) {
            if (strstr(s, "Package ") || strstr(s, "package ")) return true;
            continue;
        }
        if (startswith(s, "package ")) break;
    }
    (void)pkg;
    return false;
}

static bool prev_comment_matches(char **lines, int idx, const char *name) {
    for (int i = idx - 1; i >= 0; i--) {
        char tmp[4096]; strncpy(tmp, lines[i], sizeof tmp - 1); tmp[sizeof tmp - 1] = 0;
        char *s = trim(tmp);
        if (!*s) continue;
        if (startswith(s, "//")) {
            s = trim(s + 2);
            return startswith(s, name);
        }
        if (strstr(s, "*/")) return true;
        return false;
    }
    return false;
}

static bool extract_decl_name(char *s, char *name, size_t n) {
    char *p = trim(s);
    const char *keys[] = {"func", "type", "var", "const"};
    for (int k = 0; k < 4; k++) {
        size_t len = strlen(keys[k]);
        if (strncmp(p, keys[k], len) || !isspace((unsigned char)p[len])) continue;
        p = trim(p + len);
        if (!strcmp(keys[k], "func") && *p == '(') {
            char *r = strchr(p, ')'); if (!r) return false; p = trim(r + 1);
        }
        if (!ident_start(*p)) return false;
        size_t j = 0; while (ident_char(*p) && j + 1 < n) name[j++] = *p++;
        name[j] = 0; return j > 0;
    }
    return false;
}

static void lint_file(const char *path, const Config *cfg, Findings *fs) {
    FILE *fp = fopen(path, "r"); if (!fp) return;
    char **lines = NULL; int count = 0, cap = 0; char buf[8192];
    while (fgets(buf, sizeof buf, fp)) {
        if (count == cap) { cap = cap ? cap * 2 : 128; lines = realloc(lines, cap * sizeof(char*)); if (!lines) exit(2); }
        lines[count++] = xstrdup(buf);
    }
    fclose(fp);
    for (int oi = 0; oi < cfg->order_n; oi++) {
        int rule = cfg->order[oi];
        int offset = 0;
        for (int i = 0; i < count; i++) {
            char tmp[8192]; strncpy(tmp, lines[i], sizeof tmp - 1); tmp[sizeof tmp - 1] = 0;
            char *s = trim(tmp);
            if (rule == R_PACKAGE && cfg->package_comments && startswith(s, "package ")) {
                char pkg[256] = "";
                char *p = trim(s + 8); int j = 0; while (ident_char(*p) && j < 255) pkg[j++] = *p++; pkg[j] = 0;
                if (!has_package_comment(lines, count, pkg)) {
                    int endc = 1; while (lines[i][endc-1] && lines[i][endc-1] != '\n') endc++;
                    add_finding(fs, path, i+1, 1, endc, offset, "package-comments", "should have a package comment", cfg->severity, "comments");
                }
            } else if (rule == R_BLANK_IMPORTS && cfg->blank_imports && strstr(s, "import _ ")) {
                add_finding(fs, path, i+1, 8, 8, offset+7, "blank-imports", "a blank import should be only in a main or test package, or have a comment justifying it", cfg->severity, "imports");
            } else if (rule == R_LINE_LENGTH && cfg->line_length && cfg->line_limit > 0) {
                int len = (int)strlen(lines[i]); while (len > 0 && (lines[i][len-1] == '\n' || lines[i][len-1] == '\r')) len--;
                if (len > cfg->line_limit) {
                    char msg[256]; snprintf(msg, sizeof msg, "line is %d characters", len);
                    add_finding(fs, path, i+1, cfg->line_limit+1, len, offset+cfg->line_limit, "line-length-limit", msg, cfg->severity, "style");
                }
            } else if (rule == R_EXPORTED && cfg->exported) {
                char name[256];
                if (extract_decl_name(s, name, sizeof name) && isupper((unsigned char)name[0]) && !prev_comment_matches(lines, i, name)) {
                    char kind[32] = "declaration";
                    if (startswith(s, "func")) strcpy(kind, "function");
                    else if (startswith(s, "type")) strcpy(kind, "type");
                    else if (startswith(s, "var")) strcpy(kind, "var");
                    else if (startswith(s, "const")) strcpy(kind, "const");
                    char msg[512]; snprintf(msg, sizeof msg, "exported %s %s should have comment or be unexported", kind, name);
                    int col = startswith(s, "func") ? 1 : ((int)(strstr(lines[i], name) - lines[i]) + 1);
                    add_finding(fs, path, i+1, col, col + (int)strlen(name), offset + col - 1, "exported", msg, cfg->severity, "comments");
                }
            }
            offset += (int)strlen(lines[i]);
        }
    }
    for (int i = 0; i < count; i++) free(lines[i]);
    free(lines);
}

static void json_escape(const char *s) {
    for (; *s; s++) {
        if (*s == '"' || *s == '\\') printf("\\%c", *s);
        else if (*s == '\n') printf("\\n");
        else putchar(*s);
    }
}

static void print_json_obj(Finding *f) {
    printf("{\"Severity\":\"%s\",\"Failure\":\"", f->severity); json_escape(f->msg);
    printf("\",\"RuleName\":\"%s\",\"Category\":\"%s\",\"Position\":{\"Start\":{\"Filename\":\"", f->rule, f->category); json_escape(f->file);
    printf("\",\"Offset\":%d,\"Line\":%d,\"Column\":%d},\"End\":{\"Filename\":\"", f->offset, f->line, f->col); json_escape(f->file);
    printf("\",\"Offset\":%d,\"Line\":%d,\"Column\":%d}},\"Confidence\":1,\"ReplacementLine\":\"\"}", f->offset + (f->end_col - f->col), f->line, f->end_col);
}

static void output_findings(const char *fmt, Findings *fs) {
    if (!fmt || !*fmt || !strcmp(fmt, "default")) {
        for (size_t i = 0; i < fs->n; i++) printf("%s:%d:%d: %s\n", fs->v[i].file, fs->v[i].line, fs->v[i].col, fs->v[i].msg);
    } else if (!strcmp(fmt, "unix")) {
        for (size_t i = 0; i < fs->n; i++) printf("%s:%d:%d: [%s] %s\n\n", fs->v[i].file, fs->v[i].line, fs->v[i].col, fs->v[i].rule, fs->v[i].msg);
    } else if (!strcmp(fmt, "plain")) {
        for (size_t i = 0; i < fs->n; i++) printf("%s:%d:%d: %s https://revive.run/r#%s\n", fs->v[i].file, fs->v[i].line, fs->v[i].col, fs->v[i].msg, fs->v[i].rule);
    } else if (!strcmp(fmt, "json")) {
        putchar('['); for (size_t i = 0; i < fs->n; i++) { if (i) putchar(','); print_json_obj(&fs->v[i]); } printf("]\n");
    } else if (!strcmp(fmt, "ndjson")) {
        for (size_t i = 0; i < fs->n; i++) { print_json_obj(&fs->v[i]); printf("\n\n"); }
    } else if (!strcmp(fmt, "friendly")) {
        for (size_t i = 0; i < fs->n; i++) printf("  \342\232\240  https://revive.run/r#%s  %s\n  %s:%d:%d\n\n", fs->v[i].rule, fs->v[i].msg, fs->v[i].file, fs->v[i].line, fs->v[i].col);
        printf("\342\232\240 %zu problem (0 errors, %zu warning)\n\nWarnings:\n", fs->n, fs->n);
        for (size_t i = 0; i < fs->n; i++) printf("  1  %s\n", fs->v[i].rule);
        printf("\n");
    } else if (!strcmp(fmt, "stylish")) {
        const char *last = "";
        for (size_t i = 0; i < fs->n; i++) {
            if (strcmp(last, fs->v[i].file)) { if (i) printf("\n"); printf("%s\n", fs->v[i].file); last = fs->v[i].file; }
            printf("  (%d, %d)  https://revive.run/r#%s  %s\n", fs->v[i].line, fs->v[i].col, fs->v[i].rule, fs->v[i].msg);
        }
        printf("\n\n \342\234\226 %zu problem (0 errors) (%zu warning)\n", fs->n, fs->n);
    } else if (!strcmp(fmt, "checkstyle")) {
        printf("<?xml version='1.0' encoding='UTF-8'?>\n<checkstyle version=\"5.0\">\n");
        const char *last = "";
        for (size_t i = 0; i < fs->n; i++) {
            if (strcmp(last, fs->v[i].file)) {
                if (i) printf("    </file>\n");
                printf("    <file name=\"%s\">\n", fs->v[i].file); last = fs->v[i].file;
            }
            printf("      <error line=\"%d\" column=\"%d\" message=\"", fs->v[i].line, fs->v[i].col); json_escape(fs->v[i].msg);
            printf(" (confidence 1)\" severity=\"%s\" source=\"revive/%s\"/>\n", fs->v[i].severity, fs->v[i].rule);
        }
        if (fs->n) printf("    </file>\n");
        printf("</checkstyle>\n");
    } else if (!strcmp(fmt, "sarif")) {
        printf("{\n  \"runs\": [\n    {\n      \"results\": [\n");
        for (size_t i = 0; i < fs->n; i++) {
            printf("        {\"locations\":[{\"physicalLocation\":{\"artifactLocation\":{\"uri\":\""); json_escape(fs->v[i].file);
            printf("\"},\"region\":{\"startColumn\":%d,\"startLine\":%d}}}],\"message\":{\"text\":\"", fs->v[i].col, fs->v[i].line); json_escape(fs->v[i].msg);
            printf("\"},\"ruleId\":\"%s\"}%s\n", fs->v[i].rule, i+1<fs->n ? "," : "");
        }
        printf("      ],\n      \"tool\": {\"driver\": {\"informationUri\":\"https://revive.run\",\"name\":\"revive\",\"rules\": []}}\n    }\n  ],\n  \"version\": \"2.1.0\"\n}\n");
    }
}

int main(int argc, char **argv) {
    char *config_path = NULL, *formatter = "";
    bool set_exit = false;
    StrList excludes = {0}, positional = {0};
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) { print_help(); return 0; }
        else if (!strcmp(argv[i], "-version") || !strcmp(argv[i], "--version")) { print_version(); return 0; }
        else if (!strcmp(argv[i], "-config") && i+1 < argc) config_path = argv[++i];
        else if (!strcmp(argv[i], "-formatter") && i+1 < argc) formatter = argv[++i];
        else if (!strcmp(argv[i], "-exclude") && i+1 < argc) sl_add(&excludes, argv[++i]);
        else if (!strcmp(argv[i], "-max_open_files") && i+1 < argc) i++;
        else if (!strcmp(argv[i], "-set_exit_status")) set_exit = true;
        else sl_add(&positional, argv[i]);
    }
    const char *known[] = {"", "default", "json", "ndjson", "friendly", "stylish", "checkstyle", "sarif", "plain", "unix", NULL};
    bool okfmt = false; for (int i = 0; known[i]; i++) if (!strcmp(formatter, known[i])) okfmt = true;
    if (!okfmt) { fprintf(stderr, "formatting - getting formatter: unknown formatter %s\n", formatter); return 1; }

    Config cfg = {0}; cfg.line_limit = 80; strcpy(cfg.severity, "warning");
    if (config_path) {
        if (parse_config(config_path, &cfg) != 0) { fprintf(stderr, "cannot read the config file\n"); return 1; }
    } else {
        char *home = getenv("HOME"); char hp[4096] = "";
        if (home) { snprintf(hp, sizeof hp, "%s/revive.toml", home); if (access(hp, R_OK) == 0) config_path = hp; }
        if (config_path) parse_config(config_path, &cfg);
        else { default_init_error(); return 1; }
    }
    StrList files = {0};
    collect_files(positional.v, (int)positional.n, &files, &excludes);
    Findings fs = {0};
    for (size_t i = 0; i < files.n; i++) lint_file(files.v[i], &cfg, &fs);
    output_findings(formatter, &fs);
    return (set_exit && fs.n > 0) ? 1 : 0;
}
