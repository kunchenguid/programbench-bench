#define _GNU_SOURCE
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef enum { N_DOC, N_ELEM, N_TEXT, N_COMMENT } NodeType;

typedef struct Attr {
    char *name;
    char *value;
} Attr;

typedef struct Node {
    NodeType type;
    char *name;
    char *text;
    Attr *attrs;
    int nattrs, capattrs;
    struct Node **child;
    int nchild, capchild;
    struct Node *parent;
    bool removed;
} Node;

typedef struct {
    char *s;
    size_t len, cap;
} Str;

static void die(const char *msg) { fprintf(stderr, "%s\n", msg); exit(1); }
static char *xstrndup(const char *s, size_t n) { char *r=malloc(n+1); if(!r) exit(1); memcpy(r,s,n); r[n]=0; return r; }
static char *xstrdup(const char *s) { return xstrndup(s, strlen(s)); }

static void sb_init(Str *b){ b->cap=256; b->len=0; b->s=malloc(b->cap); b->s[0]=0; }
static void sb_need(Str *b,size_t n){ if(b->len+n+1>b->cap){ while(b->len+n+1>b->cap)b->cap*=2; b->s=realloc(b->s,b->cap);} }
static void sb_addn(Str *b,const char*s,size_t n){ sb_need(b,n); memcpy(b->s+b->len,s,n); b->len+=n; b->s[b->len]=0; }
static void sb_add(Str *b,const char*s){ sb_addn(b,s,strlen(s)); }
static void sb_ch(Str *b,char c){ sb_need(b,1); b->s[b->len++]=c; b->s[b->len]=0; }

static bool streqi(const char *a,const char*b){ for(;*a&&*b;a++,b++) if(tolower((unsigned char)*a)!=tolower((unsigned char)*b)) return false; return *a==0&&*b==0; }
static void lower_inplace(char*s){ for(;*s;s++) *s=tolower((unsigned char)*s); }

static char *decode_entities(const char *s, size_t n) {
    Str b; sb_init(&b);
    for(size_t i=0;i<n;i++){
        if(s[i]=='&'){
            size_t j=i+1; while(j<n && j-i<16 && s[j]!=';') j++;
            if(j<n && s[j]==';'){
                char *e=xstrndup(s+i+1,j-i-1);
                if(!strcmp(e,"amp")) sb_ch(&b,'&');
                else if(!strcmp(e,"lt")) sb_ch(&b,'<');
                else if(!strcmp(e,"gt")) sb_ch(&b,'>');
                else if(!strcmp(e,"quot")) sb_ch(&b,'"');
                else if(!strcmp(e,"apos")) sb_ch(&b,'\'');
                else if(e[0]=='#'){
                    long v=0;
                    if(e[1]=='x'||e[1]=='X') v=strtol(e+2,NULL,16); else v=strtol(e+1,NULL,10);
                    if(v>0 && v<128) sb_ch(&b,(char)v); else { sb_addn(&b,s+i,j-i+1); }
                } else sb_addn(&b,s+i,j-i+1);
                free(e); i=j; continue;
            }
        }
        sb_ch(&b,s[i]);
    }
    return b.s;
}

static void encode_text(Str*b,const char*s){
    for(;*s;s++){ if(*s=='&') sb_add(b,"&amp;"); else if(*s=='<') sb_add(b,"&lt;"); else if(*s=='>') sb_add(b,"&gt;"); else sb_ch(b,*s); }
}
static void encode_attr(Str*b,const char*s){
    for(;*s;s++){ if(*s=='&') sb_add(b,"&amp;"); else if(*s=='"') sb_add(b,"&quot;"); else if(*s=='<') sb_add(b,"&lt;"); else if(*s=='>') sb_add(b,"&gt;"); else sb_ch(b,*s); }
}

static Node *node_new(NodeType t, const char *name) {
    Node*n=calloc(1,sizeof(Node)); n->type=t; if(name){ n->name=xstrdup(name); lower_inplace(n->name);} return n;
}
static void add_child(Node*p,Node*c){ if(p->nchild==p->capchild){p->capchild=p->capchild?p->capchild*2:8;p->child=realloc(p->child,p->capchild*sizeof(Node*));} p->child[p->nchild++]=c; c->parent=p; }
static void add_attr(Node*n,char*name,char*value){ lower_inplace(name); if(n->nattrs==n->capattrs){n->capattrs=n->capattrs?n->capattrs*2:4;n->attrs=realloc(n->attrs,n->capattrs*sizeof(Attr));} n->attrs[n->nattrs].name=name; n->attrs[n->nattrs].value=value; n->nattrs++; }

static bool is_void_tag(const char*n){
    const char*vs[]={"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr",NULL};
    for(int i=0;vs[i];i++) if(!strcmp(n,vs[i])) return true; return false;
}

static const char *skip_ws(const char*p){ while(*p && isspace((unsigned char)*p)) p++; return p; }

static Node *parse_html(const char *html) {
    Node *doc=node_new(N_DOC,NULL), *cur=doc;
    const char *p=html;
    while(*p){
        if(*p!='<'){
            const char *q=strchr(p,'<'); if(!q) q=p+strlen(p);
            if(q>p){ Node*t=node_new(N_TEXT,NULL); t->text=decode_entities(p,q-p); add_child(cur,t); }
            p=q; continue;
        }
        if(!strncmp(p,"<!--",4)){
            const char*q=strstr(p+4,"-->"); if(!q) q=p+strlen(p); else q+=3;
            Node*c=node_new(N_COMMENT,NULL); c->text=xstrndup(p,q-p); add_child(cur,c); p=q; continue;
        }
        if(!strncmp(p,"<!",2) || !strncmp(p,"<?",2)){ const char*q=strchr(p,'>'); p=q?q+1:p+strlen(p); continue; }
        if(p[1]=='/'){
            p+=2; p=skip_ws(p); const char *s=p; while(*p && (isalnum((unsigned char)*p)||*p=='-'||*p==':')) p++;
            char *name=xstrndup(s,p-s); lower_inplace(name);
            Node*x=cur; while(x && x->type!=N_DOC){ if(!strcmp(x->name,name)){ cur=x->parent; break; } x=x->parent; }
            free(name); const char*q=strchr(p,'>'); p=q?q+1:p; continue;
        }
        p++; p=skip_ws(p); const char*s=p; while(*p && (isalnum((unsigned char)*p)||*p=='-'||*p==':')) p++;
        if(p==s){ p++; continue; }
        char *name=xstrndup(s,p-s); lower_inplace(name); Node*e=node_new(N_ELEM,name); free(name);
        bool selfclose=false;
        while(*p && *p!='>'){
            p=skip_ws(p); if(*p=='/' && p[1]=='>'){ selfclose=true; p+=2; break; }
            if(*p=='>' || !*p) break;
            const char*as=p; while(*p && (isalnum((unsigned char)*p)||*p=='-'||*p==':'||*p=='_')) p++;
            if(p==as){ p++; continue; }
            char *an=xstrndup(as,p-as); p=skip_ws(p); char *av=xstrdup("");
            if(*p=='='){
                p++; p=skip_ws(p);
                if(*p=='"' || *p=='\''){ char quote=*p++; const char*vs=p; while(*p && *p!=quote) p++; free(av); av=decode_entities(vs,p-vs); if(*p==quote)p++; }
                else { const char*vs=p; while(*p && !isspace((unsigned char)*p) && *p!='>') p++; free(av); av=decode_entities(vs,p-vs); }
            }
            add_attr(e,an,av);
        }
        if(*p=='>') p++;
        add_child(cur,e);
        if(!selfclose && !is_void_tag(e->name)) cur=e;
    }
    return doc;
}

static void wrap_fragment(Node *doc) {
    for(int i=0;i<doc->nchild;i++) {
        if(doc->child[i]->type==N_ELEM && !strcmp(doc->child[i]->name,"html")) return;
    }
    Node *html=node_new(N_ELEM,"html");
    Node *head=node_new(N_ELEM,"head");
    Node *body=node_new(N_ELEM,"body");
    Node **old=doc->child; int nold=doc->nchild;
    doc->child=NULL; doc->nchild=doc->capchild=0;
    add_child(doc,html); add_child(html,head); add_child(html,body);
    for(int i=0;i<nold;i++) add_child(body,old[i]);
    free(old);
}

static char *attr_val(Node*n,const char*name){ for(int i=0;i<n->nattrs;i++) if(!strcmp(n->attrs[i].name,name)) return n->attrs[i].value; return NULL; }
static int attrcmp(const void*a,const void*b){ const Attr*aa=a,*bb=b; return strcmp(aa->name,bb->name); }

static void serialize_node(Str*b,Node*n,bool pretty,int depth);
static void indent(Str*b,int d){ sb_ch(b,'\n'); for(int i=0;i<d;i++) sb_add(b,"  "); }
static void serialize_children(Str*b,Node*n,bool pretty,int depth){ for(int i=0;i<n->nchild;i++) serialize_node(b,n->child[i],pretty,depth); }
static void serialize_node(Str*b,Node*n,bool pretty,int depth){
    if(n->removed) return;
    if(n->type==N_DOC){ serialize_children(b,n,pretty,depth); return; }
    if(n->type==N_TEXT){ encode_text(b,n->text?n->text:""); return; }
    if(n->type==N_COMMENT){ sb_add(b,n->text?n->text:""); return; }
    if(pretty) indent(b,depth);
    sb_ch(b,'<'); sb_add(b,n->name);
    if(n->nattrs>1) qsort(n->attrs,n->nattrs,sizeof(Attr),attrcmp);
    for(int i=0;i<n->nattrs;i++){ sb_ch(b,' '); sb_add(b,n->attrs[i].name); sb_add(b,"=\""); encode_attr(b,n->attrs[i].value); sb_ch(b,'"'); }
    sb_ch(b,'>');
    if(!is_void_tag(n->name)){
        bool block=pretty && n->nchild>0;
        if(pretty){
            bool only_text=n->nchild==1 && n->child[0]->type==N_TEXT;
            if(!only_text){ for(int i=0;i<n->nchild;i++) serialize_node(b,n->child[i],pretty,depth+1); indent(b,depth); }
            else serialize_children(b,n,pretty,depth+1);
        } else serialize_children(b,n,pretty,depth+1);
        (void)block; sb_add(b,"</"); sb_add(b,n->name); sb_ch(b,'>');
    }
}

typedef struct Simple {
    char *tag,*id;
    char **classes; int nclass;
    char **attrs,* *attrvals; char *attrops; int nattr;
    struct Simple *not_s;
    int pseudo; /* 1 first, 2 last, 3 nth num, 4 odd, 5 even */
    int nth;
} Simple;
typedef struct Step { char comb; Simple s; } Step;
typedef struct Sel { Step *st; int n; } Sel;

static void simple_add_class(Simple*s,char*c){ s->classes=realloc(s->classes,(s->nclass+1)*sizeof(char*)); s->classes[s->nclass++]=c; }
static void simple_add_attr(Simple*s,char*a,char*v,char op){ s->attrs=realloc(s->attrs,(s->nattr+1)*sizeof(char*)); s->attrvals=realloc(s->attrvals,(s->nattr+1)*sizeof(char*)); s->attrops=realloc(s->attrops,(s->nattr+1)); s->attrs[s->nattr]=a; s->attrvals[s->nattr]=v; s->attrops[s->nattr]=op; s->nattr++; }
static void sel_add(Sel*sel,char comb,Simple s){ sel->st=realloc(sel->st,(sel->n+1)*sizeof(Step)); sel->st[sel->n].comb=comb; sel->st[sel->n].s=s; sel->n++; }

static char *read_ident(const char **pp){
    const char*p=*pp; const char*s=p;
    while(*p && (isalnum((unsigned char)*p)||*p=='-'||*p=='_')) p++;
    *pp=p; return xstrndup(s,p-s);
}
static Simple parse_simple(const char **pp){
    Simple s={0}; const char*p=*pp;
    if(*p=='*'){ p++; }
    else if(isalnum((unsigned char)*p)){ s.tag=read_ident(&p); lower_inplace(s.tag); }
    while(*p){
        if(*p=='#'){ p++; s.id=read_ident(&p); }
        else if(*p=='.'){ p++; simple_add_class(&s,read_ident(&p)); }
        else if(*p=='['){
            p++; p=skip_ws(p); char*a=read_ident(&p); lower_inplace(a); p=skip_ws(p); char*v=NULL;
            char op='=';
            if(*p=='=' || ((*p=='^'||*p=='$'||*p=='*'||*p=='~'||*p=='|') && p[1]=='=')){
                if(*p!='=') op=*p++;
                if(*p=='=') p++;
                p=skip_ws(p); if(*p=='"'||*p=='\''){ char q=*p++; const char*vs=p; while(*p&&*p!=q)p++; v=xstrndup(vs,p-vs); if(*p==q)p++; } else { const char*vs=p; while(*p&&*p!=']'&&!isspace((unsigned char)*p))p++; v=xstrndup(vs,p-vs); }
            }
            while(*p&&*p!=']')p++; if(*p==']')p++; simple_add_attr(&s,a,v,op);
        } else if(*p==':'){
            p++; char*ps=read_ident(&p);
            if(!strcmp(ps,"first-child")) s.pseudo=1;
            else if(!strcmp(ps,"last-child")) s.pseudo=2;
            else if(!strcmp(ps,"nth-child") && *p=='('){ p++; p=skip_ws(p); if(!strncmp(p,"odd",3)){s.pseudo=4;p+=3;} else if(!strncmp(p,"even",4)){s.pseudo=5;p+=4;} else {s.pseudo=3; s.nth=atoi(p); while(*p&&*p!=')')p++;} if(*p==')')p++; }
            else if(!strcmp(ps,"not") && *p=='('){ p++; s.not_s=malloc(sizeof(Simple)); *s.not_s=parse_simple(&p); while(*p&&*p!=')')p++; if(*p==')')p++; }
            free(ps);
        } else break;
    }
    *pp=p; return s;
}

static Sel parse_selector_group(const char *text){
    Sel sel={0}; const char*p=text; char next=' ';
    while(1){
        p=skip_ws(p); if(!*p) break;
        if(*p=='>'||*p=='+'||*p=='~'){ next=*p++; p=skip_ws(p); }
        Simple s=parse_simple(&p); sel_add(&sel,next,s); next=' ';
        const char*q=p; bool hadws=false; while(isspace((unsigned char)*q)){hadws=true;q++;}
        p=q; if(*p=='>'||*p=='+'||*p=='~') continue; if(hadws) next=' ';
        if(*p==0) break;
    }
    return sel;
}

static int elem_index(Node*n){
    if(!n->parent) return 0; int k=0;
    for(int i=0;i<n->parent->nchild;i++) if(n->parent->child[i]->type==N_ELEM && !n->parent->child[i]->removed){ k++; if(n->parent->child[i]==n) return k; }
    return 0;
}
static int elem_count(Node*p){ int k=0; if(!p) return 0; for(int i=0;i<p->nchild;i++) if(p->child[i]->type==N_ELEM && !p->child[i]->removed) k++; return k; }
static bool has_class(Node*n,const char*c){
    char*v=attr_val(n,"class"); if(!v) return false; size_t cl=strlen(c); const char*p=v;
    while(*p){ while(isspace((unsigned char)*p))p++; const char*s=p; while(*p&&!isspace((unsigned char)*p))p++; if((size_t)(p-s)==cl && !strncmp(s,c,cl)) return true; }
    return false;
}
static bool attr_op_match(const char*v,const char*want,char op){
    if(!want) return true;
    size_t vl=strlen(v), wl=strlen(want);
    if(op=='=') return !strcmp(v,want);
    if(op=='^') return vl>=wl && !strncmp(v,want,wl);
    if(op=='$') return vl>=wl && !strcmp(v+vl-wl,want);
    if(op=='*') return strstr(v,want)!=NULL;
    if(op=='~'){
        const char*p=v; while(*p){ while(isspace((unsigned char)*p))p++; const char*s=p; while(*p&&!isspace((unsigned char)*p))p++; if((size_t)(p-s)==wl&&!strncmp(s,want,wl)) return true; }
        return false;
    }
    if(op=='|') return !strcmp(v,want) || (vl>wl && !strncmp(v,want,wl) && v[wl]=='-');
    return false;
}
static bool match_simple(Node*n,Simple*s){
    if(!n || n->type!=N_ELEM || n->removed) return false;
    if(s->tag && strcmp(n->name,s->tag)) return false;
    if(s->id){ char*v=attr_val(n,"id"); if(!v || strcmp(v,s->id)) return false; }
    for(int i=0;i<s->nclass;i++) if(!has_class(n,s->classes[i])) return false;
    for(int i=0;i<s->nattr;i++){ char*v=attr_val(n,s->attrs[i]); if(!v) return false; if(!attr_op_match(v,s->attrvals[i],s->attrops[i])) return false; }
    int idx=elem_index(n);
    if(s->pseudo==1 && idx!=1) return false;
    if(s->pseudo==2 && idx!=elem_count(n->parent)) return false;
    if(s->pseudo==3 && idx!=s->nth) return false;
    if(s->pseudo==4 && idx%2!=1) return false;
    if(s->pseudo==5 && idx%2!=0) return false;
    if(s->not_s && match_simple(n,s->not_s)) return false;
    return true;
}
static Node *prev_elem(Node*n){ if(!n||!n->parent)return NULL; Node*prev=NULL; for(int i=0;i<n->parent->nchild;i++){ Node*c=n->parent->child[i]; if(c==n) return prev; if(c->type==N_ELEM&&!c->removed) prev=c; } return NULL; }
static bool match_step(Node*n,Sel*sel,int i){
    if(i<0) return true;
    if(!match_simple(n,&sel->st[i].s)) return false;
    if(i==0) return true;
    char comb=sel->st[i].comb;
    if(comb=='>') return match_step(n->parent,sel,i-1);
    if(comb=='+') return match_step(prev_elem(n),sel,i-1);
    if(comb=='~'){ for(Node*p=prev_elem(n);p;p=prev_elem(p)) if(match_step(p,sel,i-1)) return true; return false; }
    for(Node*p=n->parent;p;p=p->parent) if(match_step(p,sel,i-1)) return true;
    return false;
}
static bool matches_selector(Node*n,const char*selector){
    char *copy=xstrdup(selector), *save=NULL; bool ok=false;
    for(char*part=strtok_r(copy,",",&save); part; part=strtok_r(NULL,",",&save)){ Sel s=parse_selector_group(part); if(s.n && match_step(n,&s,s.n-1)){ok=true; break;} }
    free(copy); return ok;
}

typedef struct { Node **v; int n,cap; } NodeVec;
static void vec_add(NodeVec*v,Node*n){ for(int i=0;i<v->n;i++) if(v->v[i]==n) return; if(v->n==v->cap){v->cap=v->cap?v->cap*2:16;v->v=realloc(v->v,v->cap*sizeof(Node*));} v->v[v->n++]=n; }
static void collect(Node*n,const char*sel,NodeVec*out){ if(n->type==N_ELEM && matches_selector(n,sel)) vec_add(out,n); for(int i=0;i<n->nchild;i++) collect(n->child[i],sel,out); }
static void mark_removed(Node*n,const char*sel){ if(n->type==N_ELEM && matches_selector(n,sel)){ n->removed=true; return; } for(int i=0;i<n->nchild;i++) mark_removed(n->child[i],sel); }

static bool all_ws(const char*s){ for(;*s;s++) if(!isspace((unsigned char)*s)) return false; return true; }
static void gather_text(Node*n,Str*b,bool ignore_ws){
    if(n->removed) return;
    if(n->type==N_TEXT){ if(!(ignore_ws && all_ws(n->text))) sb_add(b,n->text); return; }
    if(n->type==N_COMMENT) return;
    for(int i=0;i<n->nchild;i++) gather_text(n->child[i],b,ignore_ws);
}

static void print_text_nodes(FILE*out,Node*n){
    if(n->removed) return;
    if(n->type==N_TEXT){
        if(!all_ws(n->text)) fprintf(out,"%s\n",n->text);
        return;
    }
    if(n->type==N_COMMENT) return;
    for(int i=0;i<n->nchild;i++) print_text_nodes(out,n->child[i]);
}

static char *read_all(FILE*f){ Str b; sb_init(&b); char buf[4096]; size_t n; while((n=fread(buf,1,sizeof(buf),f))>0) sb_addn(&b,buf,n); return b.s; }

static char *find_base(Node*root){
    if(root->type==N_ELEM && !strcmp(root->name,"base")){ char*v=attr_val(root,"href"); if(v) return v; }
    for(int i=0;i<root->nchild;i++){ char*v=find_base(root->child[i]); if(v) return v; } return NULL;
}
static bool has_scheme(const char*s){ for(const char*p=s;*p;p++){ if(*p==':') return true; if(!isalnum((unsigned char)*p)&&*p!='+'&&*p!='-'&&*p!='.') return false; } return false; }
static char *resolve_url(const char*base,const char*href){
    if(!base || !*base || has_scheme(href) || href[0]=='#') return xstrdup(href);
    if(href[0]=='/' && href[1]=='/'){
        const char *c=strstr(base,"://");
        if(c){ Str b; sb_init(&b); sb_addn(&b,base,(size_t)(c-base+1)); sb_add(&b,href); return b.s; }
        return xstrdup(href);
    }
    if(href[0]=='/'){
        const char *c=strstr(base,"://");
        if(c){
            const char *host=c+3; const char *slash=strchr(host,'/');
            Str b; sb_init(&b); sb_addn(&b,base,slash?(size_t)(slash-base):strlen(base)); sb_add(&b,href); return b.s;
        }
        return xstrdup(href);
    }
    const char*slash=strrchr(base,'/'); size_t n=slash?(size_t)(slash-base+1):strlen(base);
    Str b; sb_init(&b); sb_addn(&b,base,n); sb_add(&b,href); return b.s;
}

static void print_help(void){
    puts("htmlq 0.4.0\nMichael Maclean <michael@mgdm.net>\nRuns CSS selectors on HTML\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFLAGS:\n    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to\n                               the value of --base, if supplied\n    -h, --help                 Prints help information\n    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace\n    -p, --pretty               Pretty-print the serialised output\n    -t, --text                 Output only the contents of text nodes inside selected elements\n    -V, --version              Prints version information\n\nOPTIONS:\n    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements\n    -b, --base <base>                   Use this URL as the base for links\n    -f, --filename <FILE>               The input file. Defaults to stdin\n    -o, --output <FILE>                 The output file. Defaults to stdout\n    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple\n                                        times\n\nARGS:\n    <selector>...    The CSS expression to select [default: html]");
}

int main(int argc,char**argv){
    bool text=false,pretty=false,ignore_ws=false,detect_base=false;
    char *attribute=NULL,*base=NULL,*filename=NULL,*outfile=NULL;
    char **removes=NULL; int nrem=0; Str sels; sb_init(&sels);
    for(int i=1;i<argc;i++){
        char*a=argv[i];
        if(!strcmp(a,"--")){ for(i++;i<argc;i++){ if(sels.len) sb_ch(&sels,' '); sb_add(&sels,argv[i]); } break; }
        else if(!strcmp(a,"-h")||!strcmp(a,"--help")){ print_help(); return 0; }
        else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("htmlq 0.4.0"); return 0; }
        else if(!strcmp(a,"-t")||!strcmp(a,"--text")) text=true;
        else if(!strcmp(a,"-p")||!strcmp(a,"--pretty")) pretty=true;
        else if(!strcmp(a,"-w")||!strcmp(a,"--ignore-whitespace")) ignore_ws=true;
        else if(!strcmp(a,"-B")||!strcmp(a,"--detect-base")) detect_base=true;
        else if((!strcmp(a,"-a")||!strcmp(a,"--attribute")) && i+1<argc) attribute=argv[++i];
        else if((!strcmp(a,"-b")||!strcmp(a,"--base")) && i+1<argc) base=argv[++i];
        else if((!strcmp(a,"-f")||!strcmp(a,"--filename")) && i+1<argc) filename=argv[++i];
        else if((!strcmp(a,"-o")||!strcmp(a,"--output")) && i+1<argc) outfile=argv[++i];
        else if((!strcmp(a,"-r")||!strcmp(a,"--remove-nodes")) && i+1<argc){ removes=realloc(removes,(nrem+1)*sizeof(char*)); removes[nrem++]=argv[++i]; }
        else if(a[0]=='-' && a[1]){
            for(int j=1;a[j];j++){ if(a[j]=='t') text=true; else if(a[j]=='p') pretty=true; else if(a[j]=='w') ignore_ws=true; else if(a[j]=='B') detect_base=true; else { fprintf(stderr,"error: Found argument '%s' which wasn't expected, or isn't valid in this context\n",a); return 1; } }
        } else { if(sels.len) sb_ch(&sels,' '); sb_add(&sels,a); }
    }
    if(sels.len==0) sb_add(&sels,"html");
    FILE*in=stdin; if(filename){ in=fopen(filename,"rb"); if(!in){ perror("should have opened input file"); return 1; } }
    char*html=read_all(in); if(filename) fclose(in);
    Node*doc=parse_html(html);
    wrap_fragment(doc);
    for(int i=0;i<nrem;i++) mark_removed(doc,removes[i]);
    char *actual_base=base; if(detect_base){ char*b=find_base(doc); if(b) actual_base=b; }
    NodeVec v={0}; collect(doc,sels.s,&v);
    FILE*out=stdout; if(outfile){ out=fopen(outfile,"wb"); if(!out){ perror("output"); return 1; } }
    for(int i=0;i<v.n;i++){
        if(text){
            if(ignore_ws){ print_text_nodes(out,v.v[i]); fputc('\n',out); }
            else { Str b; sb_init(&b); gather_text(v.v[i],&b,false); fprintf(out,"%s\n",b.s); free(b.s); }
        }
        else if(attribute){ char*vattr=attr_val(v.v[i],attribute); if(vattr){ char*r=(!strcmp(attribute,"href"))?resolve_url(actual_base,vattr):xstrdup(vattr); fprintf(out,"%s\n",r); free(r); } }
        else { Str b; sb_init(&b); serialize_node(&b,v.v[i],pretty,0); fprintf(out,"%s\n",b.s); free(b.s); }
    }
    if(outfile) fclose(out);
    return 0;
}
