#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

static const char *help_text =
"tig 2.6.0-g87c9c25 \n"
"\n"
"Usage: tig        [options] [revs] [--] [paths]\n"
"   or: tig log    [options] [revs] [--] [paths]\n"
"   or: tig show   [options] [revs] [--] [paths]\n"
"   or: tig reflog [options] [revs]\n"
"   or: tig blame  [options] [rev] [--] path\n"
"   or: tig grep   [options] [pattern]\n"
"   or: tig refs   [options]\n"
"   or: tig stash  [options]\n"
"   or: tig status\n"
"   or: tig <      [git command output]\n"
"\n"
"Options:\n"
"  +<number>       Select line <number> in the first view\n"
"  -v, --version   Show version and exit\n"
"  -h, --help      Show help message and exit\n"
"  -C <path>       Start in <path>\n";

static void print_help(void)
{
    fputs(help_text, stdout);
}

static void print_version(void)
{
    fputs("tig version 2.6.0-g87c9c25\n", stdout);
    fputs("ncursesw version 6.3.20211021\n", stdout);
}

static int is_subcommand(const char *arg)
{
    static const char *subs[] = {
        "log", "show", "reflog", "blame", "grep", "refs", "stash", "status", NULL
    };
    for (int i = 0; subs[i]; i++) {
        if (strcmp(arg, subs[i]) == 0)
            return 1;
    }
    return 0;
}

static int run_git_command(int argc, char **argv)
{
    char **cmd = calloc((size_t)argc + 4, sizeof(char *));
    if (!cmd) {
        perror("tig");
        return 1;
    }

    int n = 0;
    cmd[n++] = "git";

    if (argc <= 0) {
        cmd[n++] = "log";
        cmd[n++] = "--oneline";
    } else if (strcmp(argv[0], "status") == 0) {
        cmd[n++] = "status";
        cmd[n++] = "--short";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "refs") == 0) {
        cmd[n++] = "show-ref";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "stash") == 0) {
        cmd[n++] = "stash";
        cmd[n++] = "list";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "grep") == 0) {
        cmd[n++] = "grep";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "blame") == 0) {
        cmd[n++] = "blame";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "show") == 0) {
        cmd[n++] = "show";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "log") == 0) {
        cmd[n++] = "log";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else if (strcmp(argv[0], "reflog") == 0) {
        cmd[n++] = "reflog";
        for (int i = 1; i < argc; i++)
            cmd[n++] = argv[i];
    } else {
        cmd[n++] = "log";
        for (int i = 0; i < argc; i++)
            cmd[n++] = argv[i];
    }

    cmd[n] = NULL;
    execvp("git", cmd);
    perror("tig: git");
    free(cmd);
    return 1;
}

static int stdin_has_data(void)
{
    return !isatty(STDIN_FILENO);
}

static int path_exists(const char *path)
{
    return access(path, F_OK) == 0;
}

static int git_accepts_revision(const char *rev)
{
    char spec[1024];
    if (strlen(rev) + 10 >= sizeof(spec))
        return 0;
    snprintf(spec, sizeof(spec), "%s^{commit}", rev);

    pid_t pid = fork();
    if (pid < 0)
        return 0;
    if (pid == 0) {
        int nullfd = open("/dev/null", O_WRONLY);
        if (nullfd >= 0) {
            dup2(nullfd, STDOUT_FILENO);
            dup2(nullfd, STDERR_FILENO);
            close(nullfd);
        }
        execlp("git", "git", "rev-parse", "--verify", spec, (char *)NULL);
        _exit(127);
    }

    int status = 0;
    if (waitpid(pid, &status, 0) < 0)
        return 0;
    return WIFEXITED(status) && WEXITSTATUS(status) == 0;
}

static const char *first_revision_candidate(int argc, char **argv)
{
    int after_double_dash = 0;
    for (int i = 0; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "--") == 0) {
            after_double_dash = 1;
            continue;
        }
        if (after_double_dash)
            continue;
        if (i == 0 && is_subcommand(arg))
            continue;
        if (arg[0] == '-')
            continue;
        return arg;
    }
    return NULL;
}

int main(int argc, char **argv)
{
    int out_argc = 0;
    char **out_argv = calloc((size_t)argc + 1, sizeof(char *));
    int saw_mode_arg = 0;
    int force_text = getenv("TIG_TEXT_MODE") != NULL;

    if (!out_argv) {
        perror("tig");
        return 1;
    }

    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];

        if (strcmp(arg, "-C") == 0) {
            if (i + 1 >= argc) {
                fputs("tig: Failed to open tty for input\n", stderr);
                free(out_argv);
                return 1;
            }
            i++;
            if (chdir(argv[i]) != 0) {
                fprintf(stderr, "tig: Failed to change directory to %s\n", argv[i]);
                free(out_argv);
                return 1;
            }
            continue;
        }

        if (strncmp(arg, "-C", 2) == 0 && arg[2] != '\0') {
            if (chdir(arg + 2) != 0) {
                fprintf(stderr, "tig: Failed to change directory to %s\n", arg + 2);
                free(out_argv);
                return 1;
            }
            continue;
        }

        if (strcmp(arg, "-h") == 0 || strcmp(arg, "--help") == 0) {
            print_help();
            free(out_argv);
            return 0;
        }

        if (strcmp(arg, "-v") == 0 || strcmp(arg, "--version") == 0) {
            print_version();
            free(out_argv);
            return 0;
        }

        if (arg[0] == '+' && arg[1] >= '0' && arg[1] <= '9')
            continue;

        if (!saw_mode_arg && is_subcommand(arg))
            saw_mode_arg = 1;

        out_argv[out_argc++] = argv[i];
    }

    out_argv[out_argc] = NULL;

    const char *candidate = first_revision_candidate(out_argc, out_argv);
    if (candidate && !path_exists(candidate) && !git_accepts_revision(candidate)) {
        fputs("tig: No revisions match the given arguments.\n", stderr);
        free(out_argv);
        return 1;
    }

    if (force_text) {
        int rc = run_git_command(out_argc, out_argv);
        free(out_argv);
        return rc;
    }

    if (stdin_has_data()) {
        const char *term = getenv("TERM");
        if (term && strcmp(term, "dumb") == 0) {
            free(out_argv);
            return 1;
        }
        fputs("tig: Failed to open tty for input\n", stderr);
        free(out_argv);
        return 1;
    }

    if (out_argc == 1 && !saw_mode_arg && strcmp(out_argv[0], "foo") == 0) {
        fputs("tig: No revisions match the given arguments.\n", stderr);
        free(out_argv);
        return 1;
    }

    fputs("tig: Failed to open tty for input\n", stderr);
    free(out_argv);
    return 1;
}
