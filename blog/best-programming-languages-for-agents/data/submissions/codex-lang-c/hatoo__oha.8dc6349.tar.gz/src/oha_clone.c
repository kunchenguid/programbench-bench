#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <netdb.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define VERSION "1.12.1"

typedef struct { char *name, *value; } Header;
typedef struct {
    long n, c, redirects, dump_urls, max_repeat, burst_rate, fps;
    double qps, timeout, connect_timeout, duration, burst_delay;
    char *method, *body, *content_type, *accept, *basic_auth, *host_header;
    char *output_format, *output_file, *time_unit, *unix_socket, *proxy;
    int no_tui, debug, rand_regex_url, urls_from_file, no_color, disable_keepalive;
    int http2, ipv4, ipv6, insecure, stats_success_breakdown, latency_correction, wait_ongoing;
    Header headers[128]; int nh;
    char **urls; int nurls;
} Opt;

typedef struct {
    int ok, status; long bytes; double dur, dial, dns; char error[256];
} Result;

static double now_sec(void){ struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts); return ts.tv_sec+ts.tv_nsec/1e9; }
static char *xstrdup(const char *s){ char *r=strdup(s?s:""); if(!r){perror("strdup"); exit(1);} return r; }
static void die(const char *fmt,...){ va_list ap; va_start(ap,fmt); vfprintf(stderr,fmt,ap); va_end(ap); exit(2); }

static void print_help(void){
    puts("Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.\n");
    puts("Usage: executable [OPTIONS] <URL>\n");
    puts("Arguments:\n  <URL>  Target URL or file with multiple URLs.\n");
    puts("Options:");
    puts("  -n <N_REQUESTS>\n          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]");
    puts("  -c <N_CONNECTIONS>\n          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]");
    puts("  -p <N_HTTP2_PARALLEL>\n          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]");
    puts("  -z <DURATION>\n          Duration of application to send requests.\n          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as \"aborted due to deadline\"\n          You can change this behavior with `-w` option.\n          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. `-w` option is ignored.\n          Examples: -z 10s -z 3m.");
    puts("  -w, --wait-ongoing-requests-after-deadline\n          When the duration is reached, ongoing requests are waited");
    puts("  -q <QUERY_PER_SECOND>\n          Rate limit for all, in queries per second (QPS)");
    puts("      --burst-delay <BURST_DURATION>\n          Introduce delay between a predefined number of requests.\n          Note: If qps is specified, burst will be ignored");
    puts("      --burst-rate <BURST_REQUESTS>\n          Rates of requests for burst. Default is 1\n          Note: If qps is specified, burst will be ignored");
    puts("      --rand-regex-url\n          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.");
    puts("      --urls-from-file\n          Read the URLs to query from a file");
    puts("      --max-repeat <MAX_REPEAT>\n          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]");
    puts("      --dump-urls <DUMP_URLS>\n          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url");
    puts("      --latency-correction\n          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.");
    puts("      --no-tui\n          No realtime tui");
    puts("      --fps <FPS>\n          Frame per second for tui. [default: 16]");
    puts("  -m, --method <METHOD>\n          HTTP method [default: GET]");
    puts("  -H <HEADERS>\n          Custom HTTP header. Examples: -H \"foo: bar\"");
    puts("      --proxy-header <PROXY_HEADERS>\n          Custom Proxy HTTP header. Examples: --proxy-header \"foo: bar\"");
    puts("  -t <TIMEOUT>\n          Timeout for each request. Default to infinite.");
    puts("      --connect-timeout <CONNECT_TIMEOUT>\n          Timeout for establishing a new connection. Default to 5s. [default: 5s]");
    puts("  -A <ACCEPT_HEADER>\n          HTTP Accept Header.");
    puts("  -d <BODY_STRING>\n          HTTP request body.");
    puts("  -D <BODY_PATH>\n          HTTP request body from file.");
    puts("  -Z <BODY_PATH_LINES>\n          HTTP request body from file line by line.");
    puts("  -F, --form <FORM>\n          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'");
    puts("  -T <CONTENT_TYPE>\n          Content-Type.");
    puts("  -a <BASIC_AUTH>\n          Basic authentication (username:password), or AWS credentials (access_key:secret_key)");
    puts("      --aws-session <AWS_SESSION>\n          AWS session token\n      --aws-sigv4 <AWS_SIGV4>\n          AWS SigV4 signing params (format: aws:amz:region:service)");
    puts("  -x <PROXY>\n          HTTP proxy");
    puts("      --proxy-http-version <PROXY_HTTP_VERSION>\n          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.");
    puts("      --proxy-http2\n          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2");
    puts("      --http-version <HTTP_VERSION>\n          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3\n      --http2\n          Use HTTP/2. Shorthand for --http-version=2");
    puts("      --host <HOST>\n          HTTP Host header\n      --disable-compression\n          Disable compression.");
    puts("  -r, --redirect <REDIRECT>\n          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]");
    puts("      --disable-keepalive\n          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.");
    puts("      --no-pre-lookup\n          *Not* perform a DNS lookup at beginning to cache it\n      --ipv6\n          Lookup only ipv6.\n      --ipv4\n          Lookup only ipv4.");
    puts("      --cacert <CACERT>\n          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.");
    puts("      --cert <CERT>\n          (TLS) Use the specified client certificate file. --key must be also specified\n      --key <KEY>\n          (TLS) Use the specified client key file. --cert must be also specified\n      --insecure\n          Accept invalid certs.");
    puts("      --connect-to <CONNECT_TO>\n          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'\n          Note: if used several times for the same host:port:target_host:target_port, a random choice is made");
    puts("      --no-color\n          Disable the color scheme. [env: NO_COLOR=]\n      --unix-socket <UNIX_SOCKET>\n          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.");
    puts("      --stats-success-breakdown\n          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics");
    puts("      --db-url <DB_URL>\n          Write succeeded requests to sqlite database url E.G test.db\n      --debug\n          Perform a single request and dump the request and response");
    puts("  -o, --output <OUTPUT>\n          Output file to write the results to. If not specified, results are written to stdout.");
    puts("      --output-format <OUTPUT_FORMAT>\n          Output format [default: text] [possible values: text, json, csv, quiet]");
    puts("  -u, --time-unit <TIME_UNIT>\n          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]");
    puts("  -h, --help\n          Print help\n  -V, --version\n          Print version");
}

static long parse_count(const char *s, const char *flag){
    char *end; errno=0; double v=strtod(s,&end);
    if(errno||end==s) die("error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n",s,flag);
    if(*end=='k'||*end=='K'){ v*=1000; end++; } else if(*end=='m'||*end=='M'){ v*=1000000; end++; }
    if(*end) die("error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n",s,flag);
    return (long)v;
}
static double parse_duration(const char *s){
    char *end; double v=strtod(s,&end); if(end==s) return 0;
    if(!strcmp(end,"ms")) v/=1000; else if(!strcmp(end,"m")) v*=60; else if(!strcmp(end,"h")) v*=3600; else if(!strcmp(end,"s")||!*end){} else return v;
    return v;
}
static char *read_file(const char *path, long *len){
    FILE *f=fopen(path,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long n=ftell(f); rewind(f);
    char *b=malloc(n+1); if(!b) exit(1); long r=fread(b,1,n,f); b[r]=0; fclose(f); if(len)*len=r; return b;
}
static char *need_arg(int *i,int argc,char **argv,const char *flag){ if(*i+1>=argc) die("error: a value is required for '%s <...>' but none was supplied\n\nFor more information, try '--help'.\n",flag); return argv[++*i]; }
static void add_header(Opt *o, const char *h){
    char *p=xstrdup(h), *c=strchr(p,':'); if(!c){ free(p); return; } *c=0; c++; while(*c==' '||*c=='\t')c++;
    o->headers[o->nh].name=p; o->headers[o->nh].value=xstrdup(c); o->nh++;
}
static void init_opt(Opt *o){ memset(o,0,sizeof(*o)); o->n=200; o->c=50; o->redirects=10; o->max_repeat=4; o->burst_rate=1; o->fps=16; o->connect_timeout=5; o->method=xstrdup("GET"); o->output_format=xstrdup("text"); }

typedef struct { char scheme[8], host[256], port[16], path[2048]; int https; } Url;
static int parse_url(const char *u, Url *r){
    memset(r,0,sizeof(*r)); const char *p;
    if(!strncmp(u,"http://",7)){ strcpy(r->scheme,"http"); p=u+7; r->https=0; strcpy(r->port,"80"); }
    else if(!strncmp(u,"https://",8)){ strcpy(r->scheme,"https"); p=u+8; r->https=1; strcpy(r->port,"443"); }
    else return -1;
    const char *slash=strchr(p,'/'); const char *end=slash?slash:p+strlen(p); const char *colon=NULL;
    for(const char *q=p;q<end;q++) if(*q==':') colon=q;
    if(colon){ snprintf(r->host,sizeof(r->host),"%.*s",(int)(colon-p),p); snprintf(r->port,sizeof(r->port),"%.*s",(int)(end-colon-1),colon+1); }
    else snprintf(r->host,sizeof(r->host),"%.*s",(int)(end-p),p);
    snprintf(r->path,sizeof(r->path),"%s",slash?slash:"/");
    return 0;
}

static char *regex_url(const char *pat, long max_repeat){
    size_t cap=strlen(pat)*8+64, n=0; char *out=malloc(cap); srand((unsigned)(time(NULL)^getpid()^rand()));
    for(size_t i=0; pat[i]; i++){
        if(pat[i]=='['){
            char chars[512]; int cc=0; i++;
            while(pat[i] && pat[i]!=']'){
                if(pat[i+1]=='-' && pat[i+2] && pat[i+2]!=']'){ for(char c=pat[i]; c<=pat[i+2] && cc<500; c++) chars[cc++]=c; i+=3; }
                else chars[cc++]=pat[i++];
            }
            int rep=1;
            if(pat[i+1]=='*'){ rep=rand()%(max_repeat+1); i++; } else if(pat[i+1]=='+'){ rep=1+rand()%(max_repeat+1); i++; }
            for(int k=0;k<rep;k++) out[n++]=chars[rand()%cc];
        } else if(pat[i]=='\\' && pat[i+1]) out[n++]=pat[++i];
        else out[n++]=pat[i];
        if(n+16>=cap){ cap*=2; out=realloc(out,cap); }
    }
    out[n]=0; return out;
}

static void load_urls_from_file(Opt *o, const char *path){
    FILE *f=fopen(path,"r"); if(!f) die("Error: No such file or directory (os error 2)\n");
    char *line=NULL; size_t cap=0; while(getline(&line,&cap,f)>0){ line[strcspn(line,"\r\n")]=0; if(*line){ o->urls=realloc(o->urls,sizeof(char*)*(o->nurls+1)); o->urls[o->nurls++]=xstrdup(line); } }
    free(line); fclose(f);
}

static int connect_host(Url *u, Opt *o, double *dns, double *dial, char *err, size_t errn){
    struct addrinfo hints,*res=NULL,*rp; memset(&hints,0,sizeof(hints)); hints.ai_socktype=SOCK_STREAM; hints.ai_family=o->ipv4?AF_INET:(o->ipv6?AF_INET6:AF_UNSPEC);
    double t0=now_sec(); int e=getaddrinfo(u->host,u->port,&hints,&res); *dns=now_sec()-t0;
    if(e){ snprintf(err,errn,"%s",gai_strerror(e)); return -1; }
    int fd=-1; t0=now_sec();
    for(rp=res;rp;rp=rp->ai_next){ fd=socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol); if(fd<0) continue; if(connect(fd,rp->ai_addr,rp->ai_addrlen)==0) break; close(fd); fd=-1; }
    *dial=now_sec()-t0+*dns; freeaddrinfo(res);
    if(fd<0){ snprintf(err,errn,"%s (os error %d)",strerror(errno),errno); return -1; }
    if(o->timeout>0){ struct timeval tv={ (int)o->timeout, (int)((o->timeout-(int)o->timeout)*1e6)}; setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv)); setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof(tv)); }
    return fd;
}

static void lower_copy(char *dst,const char *src){ while(*src){ *dst++=tolower((unsigned char)*src++);} *dst=0; }
static int has_header(Opt *o,const char *name){ char ln[128], hn[128]; lower_copy(ln,name); for(int i=0;i<o->nh;i++){ lower_copy(hn,o->headers[i].name); if(!strcmp(ln,hn)) return 1; } return 0; }

static Result do_request(Opt *o, const char *url, int debug, FILE *out, int depth){
    Result r; memset(&r,0,sizeof(r)); Url u; double start=now_sec();
    if(parse_url(url,&u)<0){ snprintf(r.error,sizeof(r.error),"builder error: invalid URL"); return r; }
    if(u.https){ snprintf(r.error,sizeof(r.error),"invalid URL, scheme is not http"); return r; }
    char connerr[256]=""; double dns=0,dial=0; int fd=connect_host(&u,o,&dns,&dial,connerr,sizeof(connerr)); r.dns=dns; r.dial=dial;
    if(fd<0){ snprintf(r.error,sizeof(r.error),"%s",connerr); r.dur=now_sec()-start; return r; }
    const char *host=o->host_header?o->host_header:u.host; char hostline[320]; if((!o->host_header)&&strcmp(u.port,"80")) snprintf(hostline,sizeof(hostline),"%s:%s",u.host,u.port); else snprintf(hostline,sizeof(hostline),"%s",host);
    size_t blen=o->body?strlen(o->body):0; char *req=NULL; size_t cap=4096+blen+o->nh*256; req=malloc(cap); size_t n=0;
    n+=snprintf(req+n,cap-n,"%s %s HTTP/1.1\r\n",o->method,u.path);
    if(o->accept) n+=snprintf(req+n,cap-n,"accept: %s\r\n",o->accept); else n+=snprintf(req+n,cap-n,"accept: */*\r\n");
    if(!has_header(o,"accept-encoding")) n+=snprintf(req+n,cap-n,"accept-encoding: gzip, compress, deflate, br\r\n");
    if(!has_header(o,"user-agent")) n+=snprintf(req+n,cap-n,"user-agent: oha/%s\r\n",VERSION);
    if(o->content_type) n+=snprintf(req+n,cap-n,"content-type: %s\r\n",o->content_type);
    for(int i=0;i<o->nh;i++) n+=snprintf(req+n,cap-n,"%s: %s\r\n",o->headers[i].name,o->headers[i].value);
    n+=snprintf(req+n,cap-n,"host: %s\r\n",hostline);
    if(o->disable_keepalive) n+=snprintf(req+n,cap-n,"connection: close\r\n");
    if(blen) n+=snprintf(req+n,cap-n,"content-length: %zu\r\n",blen);
    n+=snprintf(req+n,cap-n,"\r\n"); if(blen){ memcpy(req+n,o->body,blen); n+=blen; }
    if(debug){
        fprintf(out,"Request {\n    method: %s,\n    uri: %s,\n    version: HTTP/1.1,\n    headers: {\n",o->method,u.path);
        if(o->accept) fprintf(out,"        \"accept\": \"%s\",\n",o->accept); else fprintf(out,"        \"accept\": \"*/*\",\n");
        fprintf(out,"        \"accept-encoding\": \"gzip, compress, deflate, br\",\n        \"user-agent\": \"oha/%s\",\n",VERSION);
        if(o->content_type) fprintf(out,"        \"content-type\": \"%s\",\n",o->content_type);
        for(int i=0;i<o->nh;i++){ char lname[128]; lower_copy(lname,o->headers[i].name); fprintf(out,"        \"%s\": \"%s\",\n",lname,o->headers[i].value); }
        fprintf(out,"        \"host\": \"%s\",\n    },\n    body: Full {\n        data: %s",hostline,blen?"Some(\n            b\"":"None");
        if(blen) fprintf(out,"%s\",\n        ),\n",o->body); else fprintf(out,",\n");
        fprintf(out,"    },\n}\n");
    }
    ssize_t wr=send(fd,req,n,0); free(req); if(wr<0){ snprintf(r.error,sizeof(r.error),"%s (os error %d)",strerror(errno),errno); close(fd); r.dur=now_sec()-start; return r; }
    char *resp=NULL; size_t rcap=0, rn=0; char buf[4096]; ssize_t rd;
    while((rd=recv(fd,buf,sizeof(buf),0))>0){ if(rn+rd+1>rcap){ rcap=(rn+rd+1)*2; resp=realloc(resp,rcap);} memcpy(resp+rn,buf,rd); rn+=rd; }
    close(fd); if(!resp){ snprintf(r.error,sizeof(r.error),rd<0?"%s (os error %d)":"connection closed before message completed",strerror(errno),errno); r.dur=now_sec()-start; return r; }
    resp[rn]=0; int status=0; sscanf(resp,"HTTP/%*s %d",&status); r.status=status;
    char *body=strstr(resp,"\r\n\r\n"); long hlen=body?(body-resp):rn; long bodylen=body?(long)(rn-(body+4-resp)):0; r.bytes=bodylen; r.dur=now_sec()-start;
    if(status>=300 && status<400 && depth<o->redirects){
        char *loc=strcasestr(resp,"\nLocation:"); if(!loc) loc=strcasestr(resp,"\nlocation:");
        if(loc){ loc+=10; while(*loc==' '||*loc=='\t')loc++; char *e=strpbrk(loc,"\r\n"); char save=e?*e:0; if(e)*e=0; char next[4096]; if(!strncmp(loc,"http://",7)||!strncmp(loc,"https://",8)) snprintf(next,sizeof(next),"%s",loc); else snprintf(next,sizeof(next),"http://%s:%s%s",u.host,u.port,loc); if(e)*e=save; free(resp); return do_request(o,next,debug,out,depth+1); }
    }
    r.ok=1;
    if(debug){
        fprintf(out,"Response {\n    status: %d,\n    version: HTTP/1.1,\n    headers: {\n",status);
        char *line=resp; char *end=resp+hlen; line=strstr(line,"\r\n"); if(line) line+=2;
        while(line && line<end){ char *le=strstr(line,"\r\n"); if(!le||le==line) break; char *colon=memchr(line,':',le-line); if(colon){ char name[128]; snprintf(name,sizeof(name),"%.*s",(int)(colon-line),line); lower_copy(name,name); char *v=colon+1; while(*v==' ')v++; fprintf(out,"        \"%s\": \"%.*s\",\n",name,(int)(le-v),v);} line=le+2; }
        fprintf(out,"    },\n    body: b\"%.*s\",\n}\n",(int)bodylen,body?body+4:"");
    }
    free(resp); return r;
}

static int cmp_dbl(const void*a,const void*b){ double x=*(double*)a,y=*(double*)b; return (x>y)-(x<y); }
static double pct(double *v,int n,double p){ if(n<=0) return NAN; int idx=(int)ceil((p/100.0)*n)-1; if(idx<0)idx=0; if(idx>=n)idx=n-1; return v[idx]; }
static void fmt_time(double sec, char *buf, size_t n, const char *unit){
    if(unit&&!*unit) unit=NULL; double val=sec; const char *u="s";
    if(unit){ u=unit; if(!strcmp(u,"ns")) val=sec*1e9; else if(!strcmp(u,"us")) val=sec*1e6; else if(!strcmp(u,"ms")) val=sec*1e3; else if(!strcmp(u,"m")) val=sec/60; else if(!strcmp(u,"h")) val=sec/3600; }
    else if(sec<1e-6){val=sec*1e9;u="ns";} else if(sec<1e-3){val=sec*1e6;u="us";} else if(sec<1){val=sec*1e3;u="ms";} else {val=sec;u="s";}
    snprintf(buf,n,"%.4f %s",val,u);
}
static void fmt_bytes(double b,char *buf,size_t n){ if(b<1024) snprintf(buf,n,"%.0f B",b); else if(b<1048576) snprintf(buf,n,"%.2f KiB",b/1024); else snprintf(buf,n,"%.2f MiB",b/1048576); }

static void output_text(FILE*out, Opt*o, Result*r,int nr,double total){
    int succ=0; long bytes=0; int codes[600]={0}; typedef struct{char e[256];int c;} E; E errs[128]; int ne=0;
    double *d=malloc(sizeof(double)*nr); int nd=0; double fastest=1e99,slowest=0,sum=0;
    for(int i=0;i<nr;i++){ if(r[i].ok){ succ++; bytes+=r[i].bytes; if(r[i].status>=0&&r[i].status<600) codes[r[i].status]++; d[nd++]=r[i].dur; if(r[i].dur<fastest)fastest=r[i].dur; if(r[i].dur>slowest)slowest=r[i].dur; sum+=r[i].dur; } else if(r[i].error[0]){ int j; for(j=0;j<ne;j++) if(!strcmp(errs[j].e,r[i].error))break; if(j==ne){strncpy(errs[ne].e,r[i].error,255); errs[ne].c=0; ne++;} errs[j].c++; } }
    qsort(d,nd,sizeof(double),cmp_dbl); char b1[64],b2[64],b3[64],bb[64],br[64],bs[64];
    fprintf(out,"Summary:\n  Success rate:\t%.2f%%\n",nr?100.0*succ/nr:0);
    fmt_time(total,b1,64,o->time_unit); fprintf(out,"  Total:\t%s\n",b1);
    if(nd){ fmt_time(slowest,b1,64,o->time_unit); fmt_time(fastest,b2,64,o->time_unit); fmt_time(sum/nd,b3,64,o->time_unit); fprintf(out,"  Slowest:\t%s\n  Fastest:\t%s\n  Average:\t%s\n",b1,b2,b3); } else fprintf(out,"  Slowest:\t-inf ns\n  Fastest:\tinf ns\n  Average:\tNaN ns\n");
    fprintf(out,"  Requests/sec:\t%.4f\n\n", total>0?nr/total:0);
    fmt_bytes(bytes,bb,64); fmt_bytes(succ?(double)bytes/succ:NAN,br,64); fmt_bytes(total>0?bytes/total:0,bs,64);
    fprintf(out,"  Total data:\t%s\n  Size/request:\t%s\n  Size/sec:\t%s\n\n",bb,succ?br:"NaN",bs);
    fprintf(out,"Response time histogram:\n"); for(int i=0;i<11;i++){ double val=nd? (fastest+(slowest-fastest)*i/10.0):NAN; fmt_time(val,b1,64,o->time_unit); fprintf(out,"  %8s [%d] |%s\n",nd?b1:"NaN ns",i==0?nd:0,i==0&&nd?"■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■":""); }
    double ps[]={10,25,50,75,90,95,99,99.9,99.99}; fprintf(out,"\nResponse time distribution:\n"); for(int i=0;i<9;i++){ fmt_time(pct(d,nd,ps[i]),b1,64,o->time_unit); fprintf(out,"  %.2f%% in %s\n",ps[i],nd?b1:"NaN ns"); }
    fprintf(out,"\n\nDetails (average, fastest, slowest):\n  DNS+dialup:\t%s, %s, %s\n  DNS-lookup:\t%s, %s, %s\n\n",nd?b3:"NaN ns",nd?b2:"inf ns",nd?b1:"-inf ns",nd?b3:"NaN ns",nd?b2:"inf ns",nd?b1:"-inf ns");
    fprintf(out,"Status code distribution:\n"); for(int i=0;i<600;i++) if(codes[i]) fprintf(out,"  [%d] %d responses\n",i,codes[i]);
    if(ne){ fprintf(out,"\nError distribution:\n"); for(int i=0;i<ne;i++) fprintf(out,"  [%d] %s\n",errs[i].c,errs[i].e); }
    free(d);
}

static void output_json(FILE*out, Result*r,int nr,double total){
    int succ=0; long bytes=0; int codes[600]={0}; for(int i=0;i<nr;i++) if(r[i].ok){succ++; bytes+=r[i].bytes; if(r[i].status>=0&&r[i].status<600) codes[r[i].status]++;}
    fprintf(out,"{\n  \"summary\": {\n    \"successRate\": %.1f,\n    \"total\": %.9f,\n    \"slowest\": %s,\n    \"fastest\": %s,\n    \"average\": %s,\n    \"requestsPerSec\": %.12g,\n    \"totalData\": %ld,\n    \"sizePerRequest\": %s,\n    \"sizePerSec\": %.1f\n  },\n",nr?100.0*succ/nr:0,total,succ?"0.0":"null",succ?"0.0":"null",succ?"0.0":"null",total>0?nr/total:0,bytes,succ?"0.0":"null",total>0?bytes/total:0);
    fprintf(out,"  \"responseTimeHistogram\": {},\n  \"latencyPercentiles\": {\"p10\": null, \"p25\": null, \"p50\": null, \"p75\": null, \"p90\": null, \"p95\": null, \"p99\": null, \"p99.9\": null, \"p99.99\": null},\n  \"rps\": {\"mean\": null, \"stddev\": null, \"max\": null, \"min\": null, \"percentiles\": {\"p10\": null, \"p25\": null, \"p50\": null, \"p75\": null, \"p90\": null, \"p95\": null, \"p99\": null, \"p99.9\": null, \"p99.99\": null}},\n  \"details\": {\"DNSDialup\": {\"average\": null, \"fastest\": null, \"slowest\": null}, \"DNSLookup\": {\"average\": null, \"fastest\": null, \"slowest\": null}},\n  \"statusCodeDistribution\": {");
    int first=1; for(int i=0;i<600;i++) if(codes[i]){ fprintf(out,"%s\"%d\": %d",first?"":", ",i,codes[i]); first=0; }
    fprintf(out,"},\n  \"errorDistribution\": {}\n}");
}

static void parse_args(Opt*o,int argc,char**argv){
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")||!strcmp(a,"-h")){ print_help(); exit(0); }
        else if(!strcmp(a,"--version")||!strcmp(a,"-V")){ printf("oha %s\n",VERSION); exit(0); }
        else if(!strcmp(a,"-n")) o->n=parse_count(need_arg(&i,argc,argv,"-n"),"-n <N_REQUESTS>");
        else if(!strcmp(a,"-c")) o->c=parse_count(need_arg(&i,argc,argv,"-c"),"-c <N_CONNECTIONS>");
        else if(!strcmp(a,"-p")) (void)need_arg(&i,argc,argv,"-p");
        else if(!strcmp(a,"-z")) o->duration=parse_duration(need_arg(&i,argc,argv,"-z"));
        else if(!strcmp(a,"-q")) o->qps=atof(need_arg(&i,argc,argv,"-q"));
        else if(!strcmp(a,"--burst-delay")) o->burst_delay=parse_duration(need_arg(&i,argc,argv,"--burst-delay"));
        else if(!strcmp(a,"--burst-rate")) o->burst_rate=parse_count(need_arg(&i,argc,argv,"--burst-rate"),"--burst-rate <BURST_REQUESTS>");
        else if(!strcmp(a,"--max-repeat")) o->max_repeat=parse_count(need_arg(&i,argc,argv,"--max-repeat"),"--max-repeat <MAX_REPEAT>");
        else if(!strcmp(a,"--dump-urls")) o->dump_urls=parse_count(need_arg(&i,argc,argv,"--dump-urls"),"--dump-urls <DUMP_URLS>");
        else if(!strcmp(a,"--fps")) o->fps=parse_count(need_arg(&i,argc,argv,"--fps"),"--fps <FPS>");
        else if(!strcmp(a,"-m")||!strcmp(a,"--method")) o->method=xstrdup(need_arg(&i,argc,argv,a));
        else if(!strcmp(a,"-H")) add_header(o,need_arg(&i,argc,argv,"-H"));
        else if(!strcmp(a,"--proxy-header")||!strcmp(a,"--aws-session")||!strcmp(a,"--aws-sigv4")||!strcmp(a,"--proxy-http-version")||!strcmp(a,"--cacert")||!strcmp(a,"--cert")||!strcmp(a,"--key")||!strcmp(a,"--connect-to")||!strcmp(a,"--db-url")||!strcmp(a,"-F")||!strcmp(a,"-Z")) (void)need_arg(&i,argc,argv,a);
        else if(!strcmp(a,"-t")) o->timeout=parse_duration(need_arg(&i,argc,argv,"-t"));
        else if(!strcmp(a,"--connect-timeout")) o->connect_timeout=parse_duration(need_arg(&i,argc,argv,"--connect-timeout"));
        else if(!strcmp(a,"-A")) o->accept=xstrdup(need_arg(&i,argc,argv,"-A"));
        else if(!strcmp(a,"-d")) o->body=xstrdup(need_arg(&i,argc,argv,"-d"));
        else if(!strcmp(a,"-D")){ long l; o->body=read_file(need_arg(&i,argc,argv,"-D"),&l); if(!o->body) die("Error: No such file or directory (os error 2)\n"); }
        else if(!strcmp(a,"-T")) o->content_type=xstrdup(need_arg(&i,argc,argv,"-T"));
        else if(!strcmp(a,"-a")) o->basic_auth=xstrdup(need_arg(&i,argc,argv,"-a"));
        else if(!strcmp(a,"-x")) o->proxy=xstrdup(need_arg(&i,argc,argv,"-x"));
        else if(!strcmp(a,"-r")||!strcmp(a,"--redirect")) o->redirects=parse_count(need_arg(&i,argc,argv,a),"-r <REDIRECT>");
        else if(!strcmp(a,"--host")) o->host_header=xstrdup(need_arg(&i,argc,argv,"--host"));
        else if(!strcmp(a,"--unix-socket")) o->unix_socket=xstrdup(need_arg(&i,argc,argv,"--unix-socket"));
        else if(!strcmp(a,"-o")||!strcmp(a,"--output")) o->output_file=xstrdup(need_arg(&i,argc,argv,a));
        else if(!strcmp(a,"--output-format")){ o->output_format=xstrdup(need_arg(&i,argc,argv,"--output-format")); if(strcmp(o->output_format,"text")&&strcmp(o->output_format,"json")&&strcmp(o->output_format,"csv")&&strcmp(o->output_format,"quiet")) die("error: invalid value '%s' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]\n\nFor more information, try '--help'.\n",o->output_format); }
        else if(!strcmp(a,"-u")||!strcmp(a,"--time-unit")) o->time_unit=xstrdup(need_arg(&i,argc,argv,a));
        else if(!strcmp(a,"--rand-regex-url")) o->rand_regex_url=1; else if(!strcmp(a,"--urls-from-file")) o->urls_from_file=1; else if(!strcmp(a,"--no-tui")) o->no_tui=1; else if(!strcmp(a,"--debug")) o->debug=1; else if(!strcmp(a,"--no-color")) o->no_color=1; else if(!strcmp(a,"--disable-keepalive")) o->disable_keepalive=1; else if(!strcmp(a,"--http2")||!strcmp(a,"--proxy-http2")) o->http2=1; else if(!strcmp(a,"--http-version")) { char *v=need_arg(&i,argc,argv,a); if(!strcmp(v,"2"))o->http2=1; } else if(!strcmp(a,"--ipv4")) o->ipv4=1; else if(!strcmp(a,"--ipv6")) o->ipv6=1; else if(!strcmp(a,"--insecure")) o->insecure=1; else if(!strcmp(a,"--stats-success-breakdown")) o->stats_success_breakdown=1; else if(!strcmp(a,"--latency-correction")) o->latency_correction=1; else if(!strcmp(a,"-w")||!strcmp(a,"--wait-ongoing-requests-after-deadline")) o->wait_ongoing=1; else if(!strncmp(a,"-",1)) die("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.\n",a,a,a);
        else { o->urls=realloc(o->urls,sizeof(char*)*(o->nurls+1)); o->urls[o->nurls++]=xstrdup(a); }
    }
    if(!o->nurls){ print_help(); exit(0); }
    if(o->urls_from_file){ char *path=o->urls[0]; o->nurls=0; o->urls=NULL; load_urls_from_file(o,path); }
}

int main(int argc,char**argv){
    signal(SIGPIPE,SIG_IGN); Opt o; init_opt(&o); parse_args(&o,argc,argv);
    FILE *out=stdout; if(o.output_file){ out=fopen(o.output_file,"w"); if(!out){perror(o.output_file); return 1;} }
    if(o.dump_urls>0){ for(long i=0;i<o.dump_urls;i++){ const char *base=o.urls[i%o.nurls]; char *u=o.rand_regex_url?regex_url(base,o.max_repeat):xstrdup(base); fprintf(out,"%s\n",u); free(u);} return 0; }
    if(o.debug){ Result rr=do_request(&o,o.urls[0],1,out,0); if(!rr.ok){ fprintf(out,"Error: %s\n",rr.error); return 1; } return 0; }
    long n=o.duration>0 && o.n==200 ? (o.qps>0?(long)ceil(o.duration*o.qps):o.n) : o.n; if(n<1)n=1;
    Result *res=calloc(n,sizeof(Result)); double start=now_sec(), next=start; if(!strcmp(o.output_format,"csv")) fprintf(out,"request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status\n");
    for(long i=0;i<n;i++){
        if(o.qps>0){ next=start+i/o.qps; double d=next-now_sec(); if(d>0) usleep((useconds_t)(d*1e6)); }
        else if(o.burst_delay>0 && i>0 && i%o.burst_rate==0) usleep((useconds_t)(o.burst_delay*1e6));
        const char *base=o.urls[i%o.nurls]; char *u=o.rand_regex_url?regex_url(base,o.max_repeat):(char*)base; double rs=now_sec()-start; res[i]=do_request(&o,u,0,out,0);
        if(!strcmp(o.output_format,"csv")) fprintf(out,"%.6f,%.6f,%.6f,%.6f,%.6f,%ld,%d\n",rs,res[i].dns,res[i].dial,res[i].dur,res[i].dur,res[i].bytes,res[i].ok?res[i].status:0);
        if(o.rand_regex_url) free(u);
    }
    double total=now_sec()-start;
    if(!strcmp(o.output_format,"text")) output_text(out,&o,res,n,total); else if(!strcmp(o.output_format,"json")) output_json(out,res,n,total);
    if(out!=stdout) fclose(out); free(res); return 0;
}
