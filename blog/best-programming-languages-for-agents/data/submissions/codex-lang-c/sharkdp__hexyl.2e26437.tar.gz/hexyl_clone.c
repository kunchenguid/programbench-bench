#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <unistd.h>

typedef enum { BORDER_UNICODE, BORDER_ASCII, BORDER_NONE } Border;
typedef enum { BASE_HEX, BASE_DEC, BASE_OCT, BASE_BIN } Base;
typedef enum { CT_DEFAULT, CT_ASCII, CT_BRAILLE, CT_CP437, CT_CP1047 } CharTable;

typedef struct {
    long long length;
    bool has_length;
    long long skip;
    bool has_skip;
    long long display_offset;
    long long block_size;
    bool no_squeeze;
    Border border;
    bool chars;
    bool pos;
    bool plain;
    bool include;
    int panels;
    int group;
    bool little;
    Base base;
    CharTable ctable;
    const char *file;
} Opt;

static void usage_full(void) {
    puts("A command-line hex viewer\n");
    puts("Usage: executable [OPTIONS] [FILE]\n");
    puts("Arguments:");
    puts("  [FILE]");
    puts("          The file to display. If no FILE argument is given, read from STDIN\n");
    puts("Options:");
    puts("  -n, --length <N>");
    puts("          Only read N bytes from the input. The N argument can also include a unit with a");
    puts("          decimal prefix (kB, MB, ..) or binary prefix (kiB, MiB, ..), or can be specified");
    puts("          using a hex number. The short option '-l' can be used as an alias.");
    puts("          Examples: --length=64, --length=4KiB, --length=0xff\n");
    puts("  -s, --skip <N>");
    puts("          Skip the first N bytes of the input. The N argument can also include a unit (see");
    puts("          `--length` for details).");
    puts("          A negative value is valid and will seek from the end of the file.\n");
    puts("      --block-size <SIZE>         Sets the size of the `block` unit to SIZE. [default: 512]");
    puts("  -v, --no-squeezing              Displays all input data");
    puts("      --color <WHEN>              When to use colors [default: always]");
    puts("      --border <STYLE>            Whether to draw a border [default: unicode]");
    puts("  -p, --plain                     Display output with --no-characters, --no-position, --border=none, and --color=never");
    puts("      --no-characters             Do not show the character panel on the right");
    puts("  -C, --characters                Show the character panel on the right");
    puts("      --character-table <FORMAT>  Defines how bytes are mapped to characters");
    puts("      --color-scheme <FORMAT>     Defines the color scheme for the characters");
    puts("  -P, --no-position               Whether to display the position panel on the left");
    puts("  -o, --display-offset <N>        Add N bytes to the displayed file position");
    puts("      --panels <N>                Sets the number of hex data panels to be displayed");
    puts("  -g, --group-size <N>            Number of bytes/octets that should be grouped together");
    puts("      --endianness <FORMAT>       Whether to print out groups in little-endian or big-endian format");
    puts("  -b, --base <B>                  Sets the base used for the bytes");
    puts("      --terminal-width <N>        Sets the number of terminal columns to be displayed.");
    puts("      --print-color-table         Print a table showing how different types of bytes are colored");
    puts("  -i, --include                   Output in C include file style");
    puts("      --completion <SHELL>        Show shell completion for a certain shell");
    puts("  -h, --help                      Print help (see more with '--help')");
    puts("  -V, --version                   Print version");
}

static long long parse_num(const char *s, long long block) {
    bool neg = false;
    if (*s == '-') { neg = true; s++; }
    char *end = NULL;
    unsigned long long v;
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X'))
        v = strtoull(s + 2, &end, 16);
    else
        v = strtoull(s, &end, 10);
    long double mult = 1;
    if (end && *end) {
        if (!strcasecmp(end, "b")) mult = 1;
        else if (!strcasecmp(end, "kb") || !strcasecmp(end, "k")) mult = 1000.0L;
        else if (!strcasecmp(end, "mb") || !strcasecmp(end, "m")) mult = 1000000.0L;
        else if (!strcasecmp(end, "gb") || !strcasecmp(end, "g")) mult = 1000000000.0L;
        else if (!strcasecmp(end, "kib")) mult = 1024.0L;
        else if (!strcasecmp(end, "mib")) mult = 1024.0L * 1024.0L;
        else if (!strcasecmp(end, "gib")) mult = 1024.0L * 1024.0L * 1024.0L;
        else if (!strcasecmp(end, "block")) mult = (long double)block;
    }
    long long r = (long long)((long double)v * mult);
    return neg ? -r : r;
}

static unsigned char *read_all(FILE *f, size_t *len) {
    size_t cap = 8192, n = 0;
    unsigned char *buf = malloc(cap);
    if (!buf) exit(1);
    for (;;) {
        if (n == cap) {
            cap *= 2;
            buf = realloc(buf, cap);
            if (!buf) exit(1);
        }
        size_t r = fread(buf + n, 1, cap - n, f);
        n += r;
        if (r == 0) break;
    }
    *len = n;
    return buf;
}

static int unit_width(Base b) {
    switch (b) {
        case BASE_BIN: return 8;
        case BASE_DEC: return 3;
        case BASE_OCT: return 3;
        default: return 2;
    }
}

static int panel_width(Base b, int group) {
    int w = unit_width(b);
    if (b != BASE_HEX || group == 1) return 1 + 8 * (w + 1);
    return 1 + (8 / group) * (w * group + 1);
}

static void print_repeat(const char *s, int n) { for (int i = 0; i < n; i++) fputs(s, stdout); }

static void border_line(const Opt *o, bool top) {
    if (o->border == BORDER_NONE) return;
    const char *tl = o->border == BORDER_ASCII ? "+" : (top ? "┌" : "└");
    const char *tr = o->border == BORDER_ASCII ? "+" : (top ? "┐" : "┘");
    const char *cross = o->border == BORDER_ASCII ? "+" : (top ? "┬" : "┴");
    const char *h = o->border == BORDER_ASCII ? "-" : "─";
    fputs(tl, stdout);
    bool need_cross = false;
    if (o->pos) {
        print_repeat(h, 8);
        need_cross = true;
    }
    for (int p = 0; p < o->panels; p++) {
        if (need_cross) fputs(cross, stdout);
        print_repeat(h, panel_width(o->base, o->group));
        need_cross = true;
    }
    if (o->chars) {
        for (int p = 0; p < o->panels; p++) {
            if (need_cross) fputs(cross, stdout);
            print_repeat(h, 8);
            need_cross = true;
        }
    }
    fputs(tr, stdout);
    putchar('\n');
}

static void fmt_byte(char *out, unsigned char b, Base base) {
    switch (base) {
        case BASE_DEC: sprintf(out, "%03u", b); break;
        case BASE_OCT: sprintf(out, "%03o", b); break;
        case BASE_BIN:
            for (int i = 7; i >= 0; i--) *out++ = (b & (1 << i)) ? '1' : '0';
            *out = 0; break;
        default: sprintf(out, "%02x", b); break;
    }
}

static const char *ch_default(unsigned char b, char tmp[8]) {
    if (b == 0) return "⋄";
    if (b == ' ') return " ";
    if (b == '\t' || b == '\n' || b == '\r') return "_";
    if (b >= 0x21 && b <= 0x7e) { tmp[0] = (char)b; tmp[1] = 0; return tmp; }
    if (b < 0x80) return "•";
    return "×";
}

static const char *ch_ascii(unsigned char b, char tmp[8]) {
    if (b >= 0x21 && b <= 0x7e) { tmp[0] = (char)b; tmp[1] = 0; return tmp; }
    if (b == ' ') return " ";
    return ".";
}

static const char *ch_braille(unsigned char b, char tmp[8]) {
    if (b >= 0x20 && b <= 0x7e) { tmp[0] = (char)b; tmp[1] = 0; return tmp; }
    unsigned code = 0x2800 + b;
    if (code <= 0x7ff) {
        tmp[0] = 0xc0 | (code >> 6); tmp[1] = 0x80 | (code & 0x3f); tmp[2] = 0;
    } else {
        tmp[0] = 0xe0 | (code >> 12); tmp[1] = 0x80 | ((code >> 6) & 0x3f); tmp[2] = 0x80 | (code & 0x3f); tmp[3] = 0;
    }
    return tmp;
}

static const char *char_repr(unsigned char b, CharTable t, char tmp[8]) {
    if (t == CT_ASCII || t == CT_CP1047 || t == CT_CP437) return ch_ascii(b, tmp);
    if (t == CT_BRAILLE) return ch_braille(b, tmp);
    return ch_default(b, tmp);
}

static void print_hex_panel(const unsigned char *row, int rowlen, int panel, const Opt *o) {
    int start = panel * 8, w = unit_width(o->base);
    putchar(' ');
    if (o->base == BASE_HEX && o->group > 1) {
        for (int g = 0; g < 8; g += o->group) {
            if (start + g + o->group <= rowlen) {
                for (int k = 0; k < o->group; k++) {
                    int idx = o->little ? start + g + (o->group - 1 - k) : start + g + k;
                    printf("%02x", row[idx]);
                }
            } else {
                print_repeat(" ", w * o->group);
            }
            putchar(' ');
        }
    } else {
        for (int j = 0; j < 8; j++) {
            if (start + j < rowlen) {
                char b[16]; fmt_byte(b, row[start + j], o->base); fputs(b, stdout);
            } else {
                print_repeat(" ", w);
            }
            putchar(' ');
        }
    }
}

static void print_char_panel(const unsigned char *row, int rowlen, int panel, const Opt *o) {
    int start = panel * 8;
    for (int j = 0; j < 8; j++) {
        if (start + j < rowlen) {
            char tmp[8]; fputs(char_repr(row[start + j], o->ctable, tmp), stdout);
        } else {
            putchar(' ');
        }
    }
}

static bool same_row(const unsigned char *a, int alen, const unsigned char *b, int blen, int rowbytes) {
    if (alen != rowbytes || blen != rowbytes) return false;
    return memcmp(a, b, rowbytes) == 0;
}

static void print_star(const Opt *o) {
    if (o->border == BORDER_NONE) {
        if (o->plain) puts(" *                                                   ");
        else puts(" *");
        return;
    }
    const char *v = o->border == BORDER_ASCII ? "|" : "│";
    const char *sep = o->border == BORDER_ASCII ? "|" : "┊";
    fputs(v, stdout);
    if (o->pos) fputs("*       ", stdout);
    for (int p = 0; p < o->panels; p++) {
        fputs(p == 0 && !o->pos ? "*" : sep, stdout);
        print_repeat(" ", panel_width(o->base, o->group));
    }
    if (o->chars) {
        for (int p = 0; p < o->panels; p++) {
            fputs(p == 0 ? v : sep, stdout);
            print_repeat(" ", 8);
        }
    }
    fputs(v, stdout);
    putchar('\n');
}

static void dump(const unsigned char *data, size_t len, const Opt *o) {
    int rowbytes = o->panels * 8;
    border_line(o, true);
    unsigned char prev[256];
    int prevlen = -1;
    bool squeezed = false;
    for (size_t off = 0; off < len; off += rowbytes) {
        int rowlen = (int)((len - off) < (size_t)rowbytes ? len - off : (size_t)rowbytes);
        if (!o->no_squeeze && same_row(data + off, rowlen, prev, prevlen, rowbytes)) {
            if (!squeezed) print_star(o);
            squeezed = true;
            memcpy(prev, data + off, rowlen); prevlen = rowlen;
            continue;
        }
        squeezed = false;
        if (o->border != BORDER_NONE) {
            const char *v = o->border == BORDER_ASCII ? "|" : "│";
            const char *sep = o->border == BORDER_ASCII ? "|" : "┊";
            fputs(v, stdout);
            if (o->pos) printf("%08llx%s", (unsigned long long)(off + o->display_offset), v);
            for (int p = 0; p < o->panels; p++) {
                print_hex_panel(data + off, rowlen, p, o);
                fputs(p == o->panels - 1 ? v : sep, stdout);
            }
            if (o->chars) {
                for (int p = 0; p < o->panels; p++) {
                    print_char_panel(data + off, rowlen, p, o);
                    fputs(p == o->panels - 1 ? v : sep, stdout);
                }
            }
            putchar('\n');
        } else {
            if (o->pos) printf(" %08llx ", (unsigned long long)(off + o->display_offset));
            else fputs(" ", stdout);
            for (int p = 0; p < o->panels; p++) {
                print_hex_panel(data + off, rowlen, p, o);
                putchar(' ');
            }
            if (o->chars) {
                putchar(' ');
                for (int p = 0; p < o->panels; p++) {
                    print_char_panel(data + off, rowlen, p, o);
                    putchar(' ');
                }
            }
            putchar('\n');
        }
        memcpy(prev, data + off, rowlen); prevlen = rowlen;
    }
    if (squeezed && o->border == BORDER_NONE) print_star(o);
    border_line(o, false);
}

static void sanitize_name(const char *path, char *out, size_t cap) {
    const char *base = strrchr(path ? path : "stdin", '/');
    base = base ? base + 1 : (path ? path : "stdin");
    size_t n = 0;
    for (; *base && n + 1 < cap; base++) out[n++] = isalnum((unsigned char)*base) ? *base : '_';
    out[n] = 0;
    if (!n) strcpy(out, "stdin");
}

static void include_dump(const unsigned char *data, size_t len, const char *file) {
    char name[256]; sanitize_name(file, name, sizeof name);
    printf("unsigned char %s[] = {\n", name);
    for (size_t i = 0; i < len; i++) {
        if (i % 12 == 0) fputs("  ", stdout);
        printf("0x%02x", data[i]);
        if (i + 1 != len) {
            if (i % 12 == 11) putchar(',');
            else fputs(", ", stdout);
        }
        if (i % 12 == 11 || i + 1 == len) putchar('\n');
    }
    puts("};");
    printf("unsigned int %s_len = %zu;\n", name, len);
}

int main(int argc, char **argv) {
    Opt o = {.block_size = 512, .border = BORDER_UNICODE, .chars = true, .pos = true,
             .panels = 2, .group = 1, .base = BASE_HEX, .ctable = CT_DEFAULT};
    enum { OPT_BLOCK = 1000, OPT_COLOR, OPT_BORDER, OPT_NOCH, OPT_CTABLE, OPT_CSCHEME,
           OPT_PANELS, OPT_ENDIAN, OPT_TWIDTH, OPT_COLOR_TABLE, OPT_COMPLETION, OPT_BYTES, OPT_GROUPS };
    static struct option lo[] = {
        {"length", required_argument, 0, 'n'}, {"bytes", required_argument, 0, OPT_BYTES},
        {"skip", required_argument, 0, 's'}, {"block-size", required_argument, 0, OPT_BLOCK},
        {"no-squeezing", no_argument, 0, 'v'}, {"color", required_argument, 0, OPT_COLOR},
        {"border", required_argument, 0, OPT_BORDER}, {"plain", no_argument, 0, 'p'},
        {"no-characters", no_argument, 0, OPT_NOCH}, {"characters", no_argument, 0, 'C'},
        {"character-table", required_argument, 0, OPT_CTABLE}, {"color-scheme", required_argument, 0, OPT_CSCHEME},
        {"no-position", no_argument, 0, 'P'}, {"display-offset", required_argument, 0, 'o'},
        {"panels", required_argument, 0, OPT_PANELS}, {"group-size", required_argument, 0, 'g'},
        {"groupsize", required_argument, 0, OPT_GROUPS}, {"endianness", required_argument, 0, OPT_ENDIAN},
        {"base", required_argument, 0, 'b'}, {"terminal-width", required_argument, 0, OPT_TWIDTH},
        {"print-color-table", no_argument, 0, OPT_COLOR_TABLE}, {"include", no_argument, 0, 'i'},
        {"completion", required_argument, 0, OPT_COMPLETION}, {"help", no_argument, 0, 'h'},
        {"version", no_argument, 0, 'V'}, {0,0,0,0}
    };
    int c;
    while ((c = getopt_long(argc, argv, "n:l:c:s:vpCPo:g:eb:ihV", lo, NULL)) != -1) {
        switch (c) {
            case 'n': case 'l': case 'c': case OPT_BYTES: o.length = parse_num(optarg, o.block_size); o.has_length = true; break;
            case 's': o.skip = parse_num(optarg, o.block_size); o.has_skip = true; break;
            case OPT_BLOCK: o.block_size = parse_num(optarg, o.block_size); break;
            case 'v': o.no_squeeze = true; break;
            case OPT_COLOR: break;
            case OPT_BORDER:
                if (!strcmp(optarg, "ascii")) o.border = BORDER_ASCII;
                else if (!strcmp(optarg, "none")) o.border = BORDER_NONE;
                else o.border = BORDER_UNICODE;
                break;
            case 'p': o.plain = true; o.chars = false; o.pos = false; o.border = BORDER_NONE; break;
            case OPT_NOCH: o.chars = false; break;
            case 'C': o.chars = true; break;
            case OPT_CTABLE:
                if (!strcmp(optarg, "ascii")) o.ctable = CT_ASCII;
                else if (!strcmp(optarg, "braille")) o.ctable = CT_BRAILLE;
                else if (!strcmp(optarg, "codepage-437")) o.ctable = CT_CP437;
                else if (!strcmp(optarg, "codepage-1047")) o.ctable = CT_CP1047;
                break;
            case OPT_CSCHEME: break;
            case 'P': o.pos = false; break;
            case 'o': o.display_offset = parse_num(optarg, o.block_size); break;
            case OPT_PANELS: o.panels = !strcmp(optarg, "auto") ? 2 : atoi(optarg); if (o.panels < 1) o.panels = 1; if (o.panels > 16) o.panels = 16; break;
            case 'g': case OPT_GROUPS: o.group = atoi(optarg); if (!(o.group == 1 || o.group == 2 || o.group == 4 || o.group == 8)) o.group = 1; break;
            case OPT_ENDIAN: if (!strcmp(optarg, "little")) o.little = true; break;
            case 'e': o.little = true; break;
            case 'b':
                if (!strcmp(optarg, "decimal")) o.base = BASE_DEC;
                else if (!strcmp(optarg, "octal")) o.base = BASE_OCT;
                else if (!strcmp(optarg, "binary")) o.base = BASE_BIN;
                else o.base = BASE_HEX;
                break;
            case OPT_TWIDTH: { int tw = atoi(optarg); o.panels = tw < 60 ? 1 : (tw / 34); if (o.panels < 1) o.panels = 1; break; }
            case OPT_COLOR_TABLE: puts("Color table: NULL, ASCII whitespace, printable ASCII, other ASCII, non-ASCII"); return 0;
            case 'i': o.include = true; break;
            case OPT_COMPLETION: return 0;
            case 'h': usage_full(); return 0;
            case 'V': puts("hexyl 0.16.0"); return 0;
            default: return 2;
        }
    }
    if (optind < argc) o.file = argv[optind];
    FILE *f = stdin;
    if (o.file) {
        f = fopen(o.file, "rb");
        if (!f) { fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno); return 1; }
    }
    size_t inlen = 0;
    unsigned char *buf = read_all(f, &inlen);
    if (f != stdin) fclose(f);
    long long start = o.has_skip ? o.skip : 0;
    if (start < 0) start = (long long)inlen + start;
    if (start < 0) start = 0;
    if ((size_t)start > inlen) start = (long long)inlen;
    size_t avail = inlen - (size_t)start;
    if (o.has_length && o.length >= 0 && (unsigned long long)o.length < avail) avail = (size_t)o.length;
    if (o.display_offset < 0) o.display_offset = (long long)inlen + o.display_offset;
    if (o.include) include_dump(buf + start, avail, o.file);
    else dump(buf + start, avail, &o);
    free(buf);
    return 0;
}
