#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { double x,y,z; } V3;
typedef struct { char name[96]; int r,g,b; } Mat;
typedef struct { int a,b,c; int mat; } Tri;
typedef struct {
    V3 *v; int nv, cv;
    Tri *t; int nt, ct;
    Mat *m; int nm, cm;
    int curmat;
} Mesh;

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) { fprintf(stderr, "out of memory\n"); exit(2); }
    return q;
}

static int add_v(Mesh *m, V3 v) {
    if (m->nv == m->cv) { m->cv = m->cv ? m->cv * 2 : 256; m->v = xrealloc(m->v, m->cv * sizeof(V3)); }
    m->v[m->nv] = v; return m->nv++;
}
static void add_tri(Mesh *m, int a, int b, int c, int mat) {
    if (a < 0 || b < 0 || c < 0) return;
    if (m->nt == m->ct) { m->ct = m->ct ? m->ct * 2 : 256; m->t = xrealloc(m->t, m->ct * sizeof(Tri)); }
    m->t[m->nt++] = (Tri){a,b,c,mat};
}
static int add_mat(Mesh *m, const char *name, int r, int g, int b) {
    if (m->nm == m->cm) { m->cm = m->cm ? m->cm * 2 : 32; m->m = xrealloc(m->m, m->cm * sizeof(Mat)); }
    snprintf(m->m[m->nm].name, sizeof(m->m[m->nm].name), "%s", name);
    m->m[m->nm].r = r; m->m[m->nm].g = g; m->m[m->nm].b = b;
    return m->nm++;
}
static int find_mat(Mesh *m, const char *name) {
    for (int i=0;i<m->nm;i++) if (!strcmp(m->m[i].name, name)) return i;
    return -1;
}

static char *dirname_dup(const char *path) {
    const char *s = strrchr(path, '/');
    if (!s) return strdup(".");
    size_t n = (size_t)(s - path);
    char *d = malloc(n + 1); if (!d) exit(2);
    memcpy(d, path, n); d[n] = 0; return d;
}

static int load_mtl(Mesh *mesh, const char *obj, const char *mtl) {
    char *dir = dirname_dup(obj);
    char path[1024];
    snprintf(path, sizeof(path), "%s/%s", dir, mtl);
    free(dir);
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "\nthread 'main' panicked at src/inputs.rs:112:39:\nExpected to have materials.: OpenFileFailed\n");
        return 0;
    }
    char line[512], name[96] = "";
    while (fgets(line, sizeof line, f)) {
        if (sscanf(line, "newmtl %95s", name) == 1) {
            if (find_mat(mesh, name) < 0) add_mat(mesh, name, 255, 255, 255);
        } else if (!strncmp(line, "Kd ", 3) && name[0]) {
            double r,g,b;
            if (sscanf(line + 3, "%lf %lf %lf", &r, &g, &b) == 3) {
                int idx = find_mat(mesh, name);
                if (idx >= 0) {
                    mesh->m[idx].r = (int)floor(r * 255.0 + 0.5);
                    mesh->m[idx].g = (int)floor(g * 255.0 + 0.5);
                    mesh->m[idx].b = (int)floor(b * 255.0 + 0.5);
                }
            }
        }
    }
    fclose(f); return 1;
}

static int obj_index(const char *tok, int base, int nverts) {
    int v = atoi(tok);
    if (v < 0) return nverts + v;
    return base + v - 1;
}

static int load_obj(Mesh *mesh, const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "\nthread 'main' panicked at src/inputs.rs:126:39:\ncalled `Result::unwrap()` on an `Err` value: \"filename: [%s] couldn't load, tobj couldnt load/parse OBJ. open file failed\"\n", path);
        return 0;
    }
    int base = mesh->nv, have_mtl = 0;
    char line[2048];
    while (fgets(line, sizeof line, f)) {
        if (!strncmp(line, "mtllib ", 7)) {
            char mt[512];
            if (sscanf(line+7, "%511s", mt) == 1) { if (!load_mtl(mesh, path, mt)) { fclose(f); return 0; } have_mtl = 1; }
        } else if (!strncmp(line, "v ", 2)) {
            V3 v; if (sscanf(line+2, "%lf %lf %lf", &v.x, &v.y, &v.z) == 3) add_v(mesh, v);
        } else if (!strncmp(line, "usemtl ", 7)) {
            char nm[96]; if (sscanf(line+7, "%95s", nm) == 1) { int idx=find_mat(mesh,nm); if (idx>=0) mesh->curmat=idx; }
        } else if (!strncmp(line, "f ", 2)) {
            char *save = NULL, *tok, *rest = line + 2;
            int ids[256], n = 0;
            while ((tok = strtok_r(rest, " \t\r\n", &save)) && n < 256) {
                rest = NULL; ids[n++] = obj_index(tok, base, mesh->nv);
            }
            for (int i=1; i+1<n; i++) add_tri(mesh, ids[0], ids[i], ids[i+1], mesh->curmat);
        }
    }
    fclose(f);
    if (!have_mtl && mesh->nm == 0) add_mat(mesh, "default", 255, 255, 0);
    return 1;
}

static int load_stl(Mesh *mesh, const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "error: could not open %s: %s\n", path, strerror(errno)); return 0; }
    if (mesh->nm == 0) mesh->curmat = add_mat(mesh, "default", 255, 255, 0);
    char line[512]; V3 vv[3]; int n = 0;
    while (fgets(line, sizeof line, f)) {
        V3 v;
        char *p = line; while (isspace((unsigned char)*p)) p++;
        if (sscanf(p, "vertex %lf %lf %lf", &v.x, &v.y, &v.z) == 3) {
            vv[n++] = v;
            if (n == 3) {
                int a = add_v(mesh, vv[0]), b = add_v(mesh, vv[1]), c = add_v(mesh, vv[2]);
                add_tri(mesh, a,b,c, mesh->curmat); n = 0;
            }
        }
    }
    fclose(f); return 1;
}

static int endswith(const char *s, const char *e) {
    size_t a=strlen(s), b=strlen(e); return a>=b && !strcasecmp(s+a-b,e);
}

static V3 rot(V3 p, double ax, double ay, double az) {
    double c=cos(ax), s=sin(ax), y=p.y*c-p.z*s, z=p.y*s+p.z*c; p.y=y; p.z=z;
    c=cos(ay); s=sin(ay); double x=p.x*c+p.z*s; z=-p.x*s+p.z*c; p.x=x; p.z=z;
    c=cos(az); s=sin(az); x=p.x*c-p.y*s; y=p.x*s+p.y*c; p.x=x; p.y=y;
    return p;
}
static V3 sub(V3 a,V3 b){return (V3){a.x-b.x,a.y-b.y,a.z-b.z};}
static V3 cross(V3 a,V3 b){return (V3){a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static double dot(V3 a,V3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}

typedef struct { char ch; int r,g,b; double z; } Pix;

static char shade_char(double nz, int no_color) {
    double v = fabs(nz);
    if (no_color) return '#';
    if (v > .85) return '@';
    if (v > .60) return '#';
    if (v > .35) return '*';
    return '.';
}

static void render(Mesh *mesh, int w, int h, int color, int web, double ax, double ay, double az) {
    if (w <= 0) w = 80; if (h <= 0) h = w * 3 / 5;
    int n = w*h;
    V3 *rv = xrealloc(NULL, mesh->nv * sizeof(V3));
    double minx=1e99,maxx=-1e99,miny=1e99,maxy=-1e99;
    for (int i=0;i<mesh->nv;i++) {
        rv[i] = rot(mesh->v[i], ax, ay, az);
        if (rv[i].x<minx) minx=rv[i].x; if (rv[i].x>maxx) maxx=rv[i].x;
        if (rv[i].y<miny) miny=rv[i].y; if (rv[i].y>maxy) maxy=rv[i].y;
    }
    double sx = (w-1) / (maxx-minx ? maxx-minx : 1), sy = (h-1) / (maxy-miny ? maxy-miny : 1);
    double sc = sx < sy ? sx : sy; sc *= 0.92;
    double cx=(minx+maxx)/2, cy=(miny+maxy)/2;
    Pix *pix = xrealloc(NULL, n * sizeof(Pix));
    for (int i=0;i<n;i++) pix[i]=(Pix){' ',0,0,0,-1e99};
    for (int ti=0; ti<mesh->nt; ti++) {
        Tri tr=mesh->t[ti]; if (tr.a>=mesh->nv||tr.b>=mesh->nv||tr.c>=mesh->nv) continue;
        V3 a=rv[tr.a], b=rv[tr.b], c=rv[tr.c];
        V3 norm = cross(sub(b,a), sub(c,a));
        double len = sqrt(dot(norm,norm)); if (len == 0) continue; norm.x/=len; norm.y/=len; norm.z/=len;
        double x0=(a.x-cx)*sc+w/2.0, y0=h/2.0-(a.y-cy)*sc;
        double x1=(b.x-cx)*sc+w/2.0, y1=h/2.0-(b.y-cy)*sc;
        double x2=(c.x-cx)*sc+w/2.0, y2=h/2.0-(c.y-cy)*sc;
        int minpx=(int)floor(fmin(x0,fmin(x1,x2))), maxpx=(int)ceil(fmax(x0,fmax(x1,x2)));
        int minpy=(int)floor(fmin(y0,fmin(y1,y2))), maxpy=(int)ceil(fmax(y0,fmax(y1,y2)));
        if (minpx<0) minpx=0; if (minpy<0) minpy=0; if (maxpx>=w) maxpx=w-1; if (maxpy>=h) maxpy=h-1;
        double den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2);
        if (fabs(den)<1e-12) continue;
        Mat mat = (tr.mat>=0 && tr.mat<mesh->nm) ? mesh->m[tr.mat] : (Mat){"",255,255,0};
        for (int y=minpy;y<=maxpy;y++) for (int x=minpx;x<=maxpx;x++) {
            double px=x+0.5, py=y+0.5;
            double l1=((y1-y2)*(px-x2)+(x2-x1)*(py-y2))/den;
            double l2=((y2-y0)*(px-x2)+(x0-x2)*(py-y2))/den;
            double l3=1-l1-l2;
            if (l1>=-1e-6 && l2>=-1e-6 && l3>=-1e-6) {
                double z=l1*a.z+l2*b.z+l3*c.z;
                int idx=y*w+x; if (z>pix[idx].z) pix[idx]=(Pix){shade_char(norm.z,!color),mat.r,mat.g,mat.b,z};
            }
        }
    }
    if (web) {
        printf("let frames = [`\n");
        for (int y=0;y<h;y++) {
            for (int x=0;x<w;x++) {
                Pix p=pix[y*w+x];
                printf("<span style=\"color:rgb(%d,%d,%d)\">%c", p.r,p.g,p.b,p.ch);
            }
            putchar('\n');
        }
        printf("`];\n");
    } else {
        for (int y=0;y<h;y++) {
            for (int x=0;x<w;x++) {
                Pix p=pix[y*w+x];
                if (color) printf("\033[48;2;25;25;25m\033[38;2;%d;%d;%dm%c\033[49m\033[39m", p.r,p.g,p.b,p.ch);
                else putchar(p.ch);
            }
            putchar('\n');
        }
    }
    free(pix); free(rv);
}

static void help(void) {
    puts("Sloth 0.1\nMitchell Hynes. <mshynes@mun.ca>\nA toy for rendering 3D objects in the command line\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFLAGS:\n    -h, --help       Prints help information\n    -b               Flags the rasterizer to render without color\n    -V, --version    Prints version information\n\nOPTIONS:\n    -x, --yaw <x>      Sets the object's static X rotation (in radians)\n    -y, --pitch <y>    Sets the object's static Y rotation (in radians)\n    -z, --roll <z>     Sets the object's static Z rotation (in radians)\n\nARGS:\n    <input filename(s)>...    Sets the input file to render\n\nSUBCOMMANDS:\n    help     Prints this message or the help of the given subcommand(s)\n    image    Generates a colorless terminal output as lines of text");
}
static void image_help(void) {
    puts("executable-image \nMitchell Hynes <mitchell.hynes@ecumene.xyz>\nGenerates a colorless terminal output as lines of text\n\nUSAGE:\n    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>\n\nFLAGS:\n        --help       Prints help information\n    -b               Flags the rasterizer to render without color\n    -V, --version    Prints version information\n\nOPTIONS:\n    -j, --webify <frame count>    Generates a portable JS based render of your object for the web\n    -h <height>                   Sets the height of the image to generate\n    -w <width>                    Sets the width of the image to generate\n    -x, --yaw <x>                 Sets the object's static X rotation (in radians)\n    -y, --pitch <y>               Sets the object's static Y rotation (in radians)\n    -z, --roll <z>                Sets the object's static Z rotation (in radians)");
}

int main(int argc, char **argv) {
    if (argc == 1) { fprintf(stderr, "error: The following required arguments were not provided:\n    <input filename(s)>...\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFor more information try --help\n"); return 1; }
    Mesh mesh = {0}; mesh.curmat = -1;
    char **files = calloc(argc, sizeof(char*)); int nf=0, image=0, color=1, web=0, width=0, height=0;
    double ax=0, ay=0, az=0;
    for (int i=1;i<argc;i++) {
        char *a=argv[i];
        if (!strcmp(a,"--help") || (!image && !strcmp(a,"-h")) || !strcmp(a,"help")) { if (image) image_help(); else help(); free(files); return 0; }
        if (!strcmp(a,"--version") || !strcmp(a,"-V")) { puts("Sloth 0.1"); free(files); return 0; }
        if (!strcmp(a,"image")) { image=1; continue; }
        if (!strcmp(a,"-b")) { color=0; continue; }
        if (!strcmp(a,"-w")) { if (++i>=argc) return 1; width=atoi(argv[i]); if (width==0 && strcmp(argv[i],"0")) { fprintf(stderr,"Error: ParseIntError { kind: InvalidDigit }\n"); return 1; } continue; }
        if (!strcmp(a,"-h") && image) { if (++i>=argc) return 1; height=atoi(argv[i]); if (height==0 && strcmp(argv[i],"0")) { fprintf(stderr,"Error: ParseIntError { kind: InvalidDigit }\n"); return 1; } continue; }
        if (!strcmp(a,"-j") || !strcmp(a,"--webify")) { web=1; if (i+1<argc) i++; continue; }
        if (!strcmp(a,"-x") || !strcmp(a,"--yaw")) { if (++i<argc) ax=atof(argv[i]); continue; }
        if (!strcmp(a,"-y") || !strcmp(a,"--pitch")) { if (++i<argc) ay=atof(argv[i]); continue; }
        if (!strcmp(a,"-z") || !strcmp(a,"--roll")) { if (++i<argc) az=atof(argv[i]); continue; }
        if (a[0]=='-' && strcmp(a,"-")) { fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFor more information try --help\n", a); return 1; }
        files[nf++] = a;
    }
    if (nf == 0) { if (image) image_help(); else help(); free(files); return image ? 1 : 0; }
    if (image && width <= 0) { fprintf(stderr, "error: The following required arguments were not provided:\n    -w <width>\n\nUSAGE:\n    executable image [FLAGS] [OPTIONS] -w <width>\n\nFor more information try --help\n"); free(files); return 1; }
    for (int i=0;i<nf;i++) {
        int ok = endswith(files[i], ".stl") ? load_stl(&mesh, files[i]) : load_obj(&mesh, files[i]);
        if (!ok) return 101;
    }
    if (mesh.nm == 0) mesh.curmat = add_mat(&mesh, "default", 255,255,0);
    if (!image) { width = 80; height = 40; color = 1; }
    render(&mesh, width, height, color, web, ax, ay, az);
    free(files); free(mesh.v); free(mesh.t); free(mesh.m);
    return 0;
}
