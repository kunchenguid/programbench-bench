#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define VERSION_TEXT "FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,\nChristiaan Keet and Claudio Matsuoka\nInternet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012\n\nFIGlet, along with the various FIGlet fonts and documentation, may be\nfreely copied and distributed.\n\nIf you use FIGlet, please send an e-mail message to <info@figlet.org>.\n\nThe latest version of FIGlet is available from the web site,\n\thttp://www.figlet.org/\n\n"
#define USAGE "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n              [ -C controlfile ] [ -I infocode ] [ message ]\n"

typedef struct {
    char **rows;
    int width;
} Glyph;

typedef struct {
    char hardblank;
    char endmark;
    int height, baseline, maxlen, old_layout, comment_lines;
    int print_dir, full_layout, code_count;
    int rtl;
    int layout;
    Glyph glyphs[256];
} Font;

typedef struct {
    char *fontdir;
    char *fontname;
    int width;
    int justify; /* -1 default, 0 left, 1 center, 2 right */
    int direction; /* -1 font, 0 ltr, 1 rtl */
    int paragraph;
    int layout_override; /* 99999 none; -1 full; 0 kern; -2 font; >0 smush */
    int old_smush;
    int deutsch;
    int info;
} Options;

static void die(const char *msg) {
    fprintf(stderr, "executable: %s\n", msg);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) die("out of memory");
    return r;
}

static void *xrealloc(void *p, size_t n) {
    void *r = realloc(p, n ? n : 1);
    if (!r) die("out of memory");
    return r;
}

static void append_mem(char **s, size_t *len, size_t *cap, const char *add, size_t n) {
    if (*len + n + 1 > *cap) {
        while (*len + n + 1 > *cap) *cap = *cap ? *cap * 2 : 128;
        *s = xrealloc(*s, *cap);
    }
    memcpy(*s + *len, add, n);
    *len += n;
    (*s)[*len] = 0;
}

static void append_char(char **s, size_t *len, size_t *cap, char c) {
    append_mem(s, len, cap, &c, 1);
}

static char *join_args(int argc, char **argv, int start) {
    size_t len = 0, cap = 0;
    char *out = NULL;
    for (int i = start; i < argc; i++) {
        if (i > start) append_char(&out, &len, &cap, ' ');
        append_mem(&out, &len, &cap, argv[i], strlen(argv[i]));
        if (argv[i][0] == 0 && i + 1 < argc) append_char(&out, &len, &cap, '\n');
    }
    if (!out) out = xstrdup("");
    return out;
}

static char *read_stdin_all(void) {
    size_t len = 0, cap = 0;
    char *out = NULL;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), stdin)) > 0) append_mem(&out, &len, &cap, buf, n);
    if (!out) out = xstrdup("");
    return out;
}

static void strip_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0;
}

static int file_exists(const char *p) {
    return access(p, R_OK) == 0;
}

static char *make_path(const char *dir, const char *name, const char *ext) {
    size_t n = strlen(dir) + strlen(name) + strlen(ext) + 3;
    char *p = malloc(n);
    if (!p) die("out of memory");
    snprintf(p, n, "%s/%s%s", dir, name, ext);
    return p;
}

static int has_ext(const char *s) {
    const char *dot = strrchr(s, '.');
    return dot && (!strcmp(dot, ".flf") || !strcmp(dot, ".tlf"));
}

static char *find_font_file(const Options *opt) {
    const char *name = opt->fontname;
    if (strchr(name, '/')) {
        if (file_exists(name)) return xstrdup(name);
        if (!has_ext(name)) {
            size_t n = strlen(name) + 5;
            char *p = malloc(n);
            if (!p) die("out of memory");
            snprintf(p, n, "%s.flf", name);
            if (file_exists(p)) return p;
            free(p);
            p = malloc(n);
            if (!p) die("out of memory");
            snprintf(p, n, "%s.tlf", name);
            if (file_exists(p)) return p;
            free(p);
        }
    }
    const char *dirs[] = { opt->fontdir, ".", "fonts", "assets", "/usr/local/share/figlet", NULL };
    const char *exts[] = { "", ".flf", ".tlf", NULL };
    for (int d = 0; dirs[d]; d++) {
        for (int e = 0; exts[e]; e++) {
            if (exts[e][0] && has_ext(name)) continue;
            char *p = make_path(dirs[d], name, exts[e]);
            if (file_exists(p)) return p;
            free(p);
        }
    }
    fprintf(stderr, "executable: %s: Unable to open font file\n", name);
    exit(1);
}

static char *clean_glyph_line(char *line, char endmark) {
    strip_newline(line);
    size_t n = strlen(line);
    while (n && line[n - 1] == endmark) line[--n] = 0;
    return line;
}

static char *read_glyph_line(FILE *fp, char endmark) {
    char *line = NULL;
    size_t cap = 0;
    if (getline(&line, &cap, fp) < 0) return xstrdup("");
    return clean_glyph_line(line, endmark);
}

static int parse_code(const char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    int base = 10;
    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) base = 16;
    return (int)strtol(s, NULL, base);
}

static void load_font(Font *f, const Options *opt) {
    memset(f, 0, sizeof(*f));
    char *path = find_font_file(opt);
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "executable: %s: Unable to open font file\n", opt->fontname);
        exit(1);
    }
    char *line = NULL;
    size_t cap = 0;
    if (getline(&line, &cap, fp) < 0) die("empty font");
    strip_newline(line);
    if (strncmp(line, "flf2", 4) && strncmp(line, "tlf2", 4)) die("Not a FIGlet 2 font file");
    f->hardblank = line[5];
    f->print_dir = 0;
    f->full_layout = 0;
    f->code_count = 0;
    sscanf(line + 6, "%d %d %d %d %d %d %d %d",
           &f->height, &f->baseline, &f->maxlen, &f->old_layout, &f->comment_lines,
           &f->print_dir, &f->full_layout, &f->code_count);
    if (f->height <= 0 || f->height > 100) die("invalid font");
    for (int i = 0; i < f->comment_lines; i++) {
        if (getline(&line, &cap, fp) < 0) die("invalid font");
    }
    f->endmark = 0;
    for (int ch = 32; ch <= 126; ch++) {
        f->glyphs[ch].rows = calloc(f->height, sizeof(char *));
        if (!f->glyphs[ch].rows) die("out of memory");
        int w = 0;
        for (int r = 0; r < f->height; r++) {
            if (!f->endmark) {
                char *raw = NULL;
                size_t rcap = 0;
                if (getline(&raw, &rcap, fp) < 0) raw = xstrdup("");
                strip_newline(raw);
                size_t rn = strlen(raw);
                f->endmark = rn ? raw[rn - 1] : '@';
                f->glyphs[ch].rows[r] = clean_glyph_line(raw, f->endmark);
            } else {
                f->glyphs[ch].rows[r] = read_glyph_line(fp, f->endmark);
            }
            int lw = (int)strlen(f->glyphs[ch].rows[r]);
            if (lw > w) w = lw;
        }
        f->glyphs[ch].width = w;
    }
    for (;;) {
        if (getline(&line, &cap, fp) < 0) break;
        int code = parse_code(line);
        if (code < 0 || code > 255) {
            for (int r = 0; r < f->height; r++) {
                if (getline(&line, &cap, fp) < 0) break;
            }
            continue;
        }
        if (!f->glyphs[code].rows) {
            f->glyphs[code].rows = calloc(f->height, sizeof(char *));
            if (!f->glyphs[code].rows) die("out of memory");
        }
        int w = 0;
        for (int r = 0; r < f->height; r++) {
            free(f->glyphs[code].rows[r]);
            f->glyphs[code].rows[r] = read_glyph_line(fp, f->endmark);
            int lw = (int)strlen(f->glyphs[code].rows[r]);
            if (lw > w) w = lw;
        }
        f->glyphs[code].width = w;
    }
    free(line);
    fclose(fp);
    free(path);
    f->rtl = opt->direction == 1 || (opt->direction < 0 && f->print_dir == 1);
    if (opt->layout_override == -1) f->layout = -1;
    else if (opt->layout_override == 0) f->layout = 0;
    else if (opt->layout_override > 0) f->layout = opt->layout_override;
    else {
        if (f->full_layout != 0) {
            int h = f->full_layout & 63;
            if (h == 0) f->layout = 0;
            else f->layout = h;
        } else {
            if (f->old_layout < 0) f->layout = -1;
            else if (f->old_layout == 0) f->layout = 0;
            else f->layout = f->old_layout & 63;
        }
    }
}

static char row_char(const Glyph *g, int r, int c) {
    int n = (int)strlen(g->rows[r]);
    return c >= 0 && c < n ? g->rows[r][c] : ' ';
}

static int smush_pair(char l, char r, int mode, char hardblank, char *out) {
    if (l == ' ') { *out = r; return 1; }
    if (r == ' ') { *out = l; return 1; }
    if (mode == 0) return 0;
    if (l == hardblank && r == hardblank) {
        if (mode & 32) { *out = hardblank; return 1; }
        return 0;
    }
    if (l == hardblank || r == hardblank) return 0;
    if ((mode & 1) && l == r) { *out = l; return 1; }
    if (mode & 2) {
        if (l == '_' && strchr("|/\\[]{}()<>", r)) { *out = r; return 1; }
        if (r == '_' && strchr("|/\\[]{}()<>", l)) { *out = l; return 1; }
    }
    if (mode & 4) {
        const char *h = "|/\\[]{}()<>";
        char *pl = strchr(h, l), *pr = strchr(h, r);
        if (pl && pr && pl != pr) { *out = (pl > pr) ? l : r; return 1; }
    }
    if (mode & 8) {
        if ((l == '[' && r == ']') || (l == ']' && r == '[') ||
            (l == '{' && r == '}') || (l == '}' && r == '{') ||
            (l == '(' && r == ')') || (l == ')' && r == '(')) {
            *out = '|'; return 1;
        }
    }
    if (mode & 16) {
        if (l == '/' && r == '\\') { *out = '|'; return 1; }
        if (l == '\\' && r == '/') { *out = 'Y'; return 1; }
        if (l == '>' && r == '<') { *out = 'X'; return 1; }
    }
    return 0;
}

static int fit_amount(char **rows, int height, int curw, const Glyph *g, int layout, char hardblank) {
    if (curw == 0) return 0;
    if (layout < 0) return 0;
    int best = curw + g->width;
    for (int r = 0; r < height; r++) {
        int left = -1;
        int rlen = (int)strlen(rows[r]);
        for (int i = rlen - 1; i >= 0; i--) {
            if (rows[r][i] != ' ') { left = i; break; }
        }
        int right = g->width;
        int glen = (int)strlen(g->rows[r]);
        for (int i = 0; i < glen; i++) {
            if (g->rows[r][i] != ' ') { right = i; break; }
        }
        int amt;
        if (left < 0 || right == g->width) {
            amt = g->width < curw ? g->width : curw;
        } else {
            amt = (curw - 1 - left) + right;
            char dummy;
            if (layout > 0 && smush_pair(rows[r][left], row_char(g, r, right), layout, hardblank, &dummy)) amt++;
        }
        if (amt < best) best = amt;
    }
    int maxo = g->width < curw ? g->width : curw;
    if (best < 0) best = 0;
    if (best > maxo) best = maxo;
    return best;
}

static void append_glyph(char ***prows, int height, int *pwidth, const Glyph *g, const Font *f) {
    char **rows = *prows;
    int curw = *pwidth;
    if (!rows) {
        rows = calloc(height, sizeof(char *));
        if (!rows) die("out of memory");
        for (int r = 0; r < height; r++) rows[r] = xstrdup("");
    }
    int overlap = fit_amount(rows, height, curw, g, f->layout, f->hardblank);
    for (int r = 0; r < height; r++) {
        int oldlen = (int)strlen(rows[r]);
        if (oldlen < curw) {
            rows[r] = xrealloc(rows[r], curw + 1);
            memset(rows[r] + oldlen, ' ', curw - oldlen);
            rows[r][curw] = 0;
        }
        int glen = (int)strlen(g->rows[r]);
        int neww = curw - overlap + glen;
        rows[r] = xrealloc(rows[r], neww + 1);
        for (int k = 0; k < overlap; k++) {
            char out;
            char l = rows[r][curw - overlap + k];
            char rr = row_char(g, r, k);
            smush_pair(l, rr, f->layout, f->hardblank, &out);
            rows[r][curw - overlap + k] = out;
        }
        memcpy(rows[r] + curw, g->rows[r] + overlap, glen > overlap ? glen - overlap : 0);
        rows[r][neww] = 0;
    }
    *pwidth = curw - overlap + g->width;
    *prows = rows;
}

static int visual_width(char **rows, int height) {
    int w = 0;
    for (int r = 0; r < height; r++) {
        int n = (int)strlen(rows[r]);
        if (n > w) w = n;
    }
    return w;
}

static void trim_left_common(char **rows, int height) {
    int trim = 1000000;
    for (int r = 0; r < height; r++) {
        int n = (int)strlen(rows[r]);
        int i = 0;
        while (i < n && rows[r][i] == ' ') i++;
        if (i < n && i < trim) trim = i;
    }
    if (trim <= 0 || trim == 1000000) return;
    for (int r = 0; r < height; r++) {
        int n = (int)strlen(rows[r]);
        if (n >= trim) memmove(rows[r], rows[r] + trim, n - trim + 1);
    }
}

static void print_rows(char **rows, int height, const Options *opt, const Font *f) {
    if (!rows) {
        for (int r = 0; r < height; r++) putchar('\n');
        return;
    }
    if (f->layout >= 0) trim_left_common(rows, height);
    int w = visual_width(rows, height);
    int just = opt->justify;
    if (just < 0) just = f->rtl ? 2 : 0;
    int pad = 0;
    if (opt->width > w) {
        if (just == 1) pad = (opt->width - w) / 2;
        else if (just == 2) pad = opt->width - w;
    }
    for (int r = 0; r < height; r++) {
        for (int i = 0; i < pad; i++) putchar(' ');
        for (char *p = rows[r]; *p; p++) putchar(*p == f->hardblank ? ' ' : *p);
        putchar('\n');
    }
}

static void free_rows(char **rows, int height) {
    if (!rows) return;
    for (int r = 0; r < height; r++) free(rows[r]);
    free(rows);
}

static int map_deutsch(int ch) {
    switch (ch) {
    case '[': return 196; case '\\': return 214; case ']': return 220;
    case '{': return 228; case '|': return 246; case '}': return 252;
    case '~': return 223; default: return ch;
    }
}

static char *paragraph_filter(const char *in) {
    size_t len = strlen(in), outl = 0, cap = 0;
    char *out = NULL;
    for (size_t i = 0; i < len; i++) {
        char c = in[i];
        if (c == '\n') {
            char prev = i ? in[i - 1] : '\n';
            char next = (i + 1 < len) ? in[i + 1] : '\n';
            if (prev != '\n' && next != ' ' && next != '\n' && next != '\t') c = ' ';
        }
        append_char(&out, &outl, &cap, c);
    }
    if (!out) out = xstrdup("");
    return out;
}

static void render_line(const char *line, const Options *opt, Font *f) {
    char **rows = NULL;
    int width = 0;
    size_t n = strlen(line);
    if (f->rtl) {
        for (ssize_t i = (ssize_t)n - 1; i >= 0; i--) {
            int ch = (unsigned char)line[i];
            if (opt->deutsch) ch = map_deutsch(ch);
            Glyph *g = f->glyphs[ch].rows ? &f->glyphs[ch] : &f->glyphs['?'];
            if (opt->width == 1 && ch != ' ' && width > 0) {
                print_rows(rows, f->height, opt, f); free_rows(rows, f->height); rows = NULL; width = 0;
            } else if (opt->width > 1 && width > 0 && width + g->width > opt->width) {
                print_rows(rows, f->height, opt, f); free_rows(rows, f->height); rows = NULL; width = 0;
            }
            append_glyph(&rows, f->height, &width, g, f);
        }
    } else {
        for (size_t i = 0; i < n; i++) {
            int ch = (unsigned char)line[i];
            if (opt->deutsch) ch = map_deutsch(ch);
            Glyph *g = f->glyphs[ch].rows ? &f->glyphs[ch] : &f->glyphs['?'];
            if (opt->width == 1 && ch != ' ' && width > 0) {
                print_rows(rows, f->height, opt, f); free_rows(rows, f->height); rows = NULL; width = 0;
            } else if (opt->width > 1 && width > 0 && width + g->width > opt->width) {
                print_rows(rows, f->height, opt, f); free_rows(rows, f->height); rows = NULL; width = 0;
            }
            append_glyph(&rows, f->height, &width, g, f);
        }
    }
    print_rows(rows, f->height, opt, f);
    free_rows(rows, f->height);
}

static void render_text(const char *input, const Options *opt, Font *f) {
    char *work = opt->paragraph ? paragraph_filter(input) : xstrdup(input);
    char *start = work;
    for (char *p = work; ; p++) {
        if (*p == '\n' || *p == 0) {
            char save = *p;
            *p = 0;
            render_line(start, opt, f);
            if (save == 0) break;
            start = p + 1;
        }
    }
    free(work);
}

static void print_info(const Options *opt) {
    if (opt->info == 0) {
        fputs(VERSION_TEXT, stdout);
        fputs(USAGE, stdout);
    } else if (opt->info == 1) printf("20205\n");
    else if (opt->info == 2) printf("%s\n", opt->fontdir);
    else if (opt->info == 3) printf("%s\n", opt->fontname);
    else if (opt->info == 4) printf("%d\n", opt->width);
    else if (opt->info == 5) printf("flf2 tlf2\n");
}

static int parse_int_arg(int *i, int argc, char **argv, const char *arg, int pos) {
    const char *v = arg[pos + 1] ? arg + pos + 1 : (++(*i) < argc ? argv[*i] : NULL);
    if (!v) { fputs(USAGE, stderr); exit(1); }
    return atoi(v);
}

static char *parse_str_arg(int *i, int argc, char **argv, const char *arg, int pos) {
    const char *v = arg[pos + 1] ? arg + pos + 1 : (++(*i) < argc ? argv[*i] : NULL);
    if (!v) { fputs(USAGE, stderr); exit(1); }
    return xstrdup(v);
}

int main(int argc, char **argv) {
    Options opt;
    opt.fontdir = xstrdup("/usr/local/share/figlet");
    opt.fontname = xstrdup("standard");
    opt.width = 80;
    opt.justify = -1;
    opt.direction = -1;
    opt.paragraph = 0;
    opt.layout_override = 99999;
    opt.old_smush = 0;
    opt.deutsch = 0;
    opt.info = -1;

    int first_msg = argc;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (a[0] != '-' || !strcmp(a, "-")) { first_msg = i; break; }
        if (!strcmp(a, "--")) { first_msg = i + 1; break; }
        for (int j = 1; a[j]; j++) {
            switch (a[j]) {
            case 'c': opt.justify = 1; break;
            case 'l': opt.justify = 0; break;
            case 'r': opt.justify = 2; break;
            case 'x': opt.justify = -1; break;
            case 'L': opt.direction = 0; break;
            case 'R': opt.direction = 1; break;
            case 'X': opt.direction = -1; break;
            case 'p': opt.paragraph = 1; break;
            case 'n': opt.paragraph = 0; opt.layout_override = 99999; break;
            case 's': opt.layout_override = -2; break;
            case 'S': opt.layout_override = 63; break;
            case 'k': opt.layout_override = 0; break;
            case 'W': opt.layout_override = -1; break;
            case 'o': opt.layout_override = 0; break;
            case 'D': opt.deutsch = 1; break;
            case 'E': opt.deutsch = 0; break;
            case 'N': break;
            case 't': {
                struct winsize ws;
                if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0) opt.width = ws.ws_col;
                break;
            }
            case 'v': opt.info = 0; break;
            case 'w': opt.width = parse_int_arg(&i, argc, argv, a, j); j = (int)strlen(a) - 1; break;
            case 'm': opt.layout_override = parse_int_arg(&i, argc, argv, a, j); j = (int)strlen(a) - 1; break;
            case 'I': opt.info = parse_int_arg(&i, argc, argv, a, j); j = (int)strlen(a) - 1; break;
            case 'd': free(opt.fontdir); opt.fontdir = parse_str_arg(&i, argc, argv, a, j); j = (int)strlen(a) - 1; break;
            case 'f': free(opt.fontname); opt.fontname = parse_str_arg(&i, argc, argv, a, j); j = (int)strlen(a) - 1; break;
            case 'C': free(parse_str_arg(&i, argc, argv, a, j)); j = (int)strlen(a) - 1; break;
            default:
                fprintf(stderr, "./executable: invalid option -- '%c'\n", a[j]);
                fputs(USAGE, stderr);
                return 1;
            }
        }
    }
    if (opt.layout_override == -2) opt.layout_override = 99999;
    if (opt.info >= 0) {
        print_info(&opt);
        return 0;
    }
    Font font;
    load_font(&font, &opt);
    char *input = first_msg < argc ? join_args(argc, argv, first_msg) : read_stdin_all();
    render_text(input, &opt, &font);
    free(input);
    return 0;
}
