#include <elf.h>
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct {
    unsigned char *data;
    size_t size;
    bool is64;
    bool little;
    uint16_t type, machine, phnum, shnum, phentsize, shentsize, shstrndx;
    uint64_t entry, phoff, shoff, flags, ehsize;
} ElfInfo;

typedef struct {
    uint32_t type, flags;
    uint64_t off, vaddr, paddr, filesz, memsz, align;
} Phdr;

typedef struct {
    uint32_t name, type, link, info;
    uint64_t flags, addr, off, size, entsize, addralign;
    const char *sname;
} Shdr;

static uint16_t rd16(const unsigned char *p, bool le) {
    return le ? (uint16_t)p[0] | ((uint16_t)p[1] << 8)
              : (uint16_t)p[1] | ((uint16_t)p[0] << 8);
}

static uint32_t rd32(const unsigned char *p, bool le) {
    if (le) return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    return (uint32_t)p[3] | ((uint32_t)p[2] << 8) | ((uint32_t)p[1] << 16) | ((uint32_t)p[0] << 24);
}

static uint64_t rd64(const unsigned char *p, bool le) {
    uint64_t lo, hi;
    if (le) {
        lo = rd32(p, true);
        hi = rd32(p + 4, true);
    } else {
        hi = rd32(p, false);
        lo = rd32(p + 4, false);
    }
    return lo | (hi << 32);
}

static const char *base_name(const char *s) {
    const char *slash = strrchr(s, '/');
    return slash ? slash + 1 : s;
}

static void html_text(FILE *f, const char *s) {
    for (; *s; s++) {
        switch (*s) {
            case '&': fputs("&amp;", f); break;
            case '<': fputs("&lt;", f); break;
            case '>': fputs("&gt;", f); break;
            case '"': fputs("&quot;", f); break;
            case '\'': fputs("&#39;", f); break;
            default: fputc((unsigned char)*s, f);
        }
    }
}

static const char *class_name(int c) {
    switch (c) {
        case ELFCLASS32: return "32-bit";
        case ELFCLASS64: return "64-bit";
        default: return "Invalid/unknown";
    }
}

static const char *data_name(int d) {
    switch (d) {
        case ELFDATA2LSB: return "Little endian";
        case ELFDATA2MSB: return "Big endian";
        default: return "Invalid/unknown";
    }
}

static const char *abi_name(int abi) {
    switch (abi) {
        case ELFOSABI_SYSV: return "SysV";
        case ELFOSABI_HPUX: return "HP-UX";
        case ELFOSABI_NETBSD: return "NetBSD";
        case ELFOSABI_LINUX: return "Linux";
        case ELFOSABI_SOLARIS: return "Solaris";
        case ELFOSABI_AIX: return "AIX";
        case ELFOSABI_IRIX: return "IRIX";
        case ELFOSABI_FREEBSD: return "FreeBSD";
        case ELFOSABI_TRU64: return "TRU64";
        case ELFOSABI_MODESTO: return "Modesto";
        case ELFOSABI_OPENBSD: return "OpenBSD";
        case ELFOSABI_ARM_AEABI: return "ARM EABI";
        case ELFOSABI_ARM: return "ARM";
        case ELFOSABI_STANDALONE: return "Standalone";
        default: return "Unknown";
    }
}

static const char *type_name(uint16_t t) {
    switch (t) {
        case ET_NONE: return "No file type (NONE)";
        case ET_REL: return "Relocatable file (REL)";
        case ET_EXEC: return "Executable file (EXEC)";
        case ET_DYN: return "Shared object file (DYN)";
        case ET_CORE: return "Core file (CORE)";
        default: return "Processor/OS specific";
    }
}

static const char *machine_name(uint16_t m) {
    switch (m) {
        case EM_NONE: return "None";
        case EM_386: return "Intel 80386";
        case EM_X86_64: return "x86-64";
        case EM_ARM: return "ARM";
        case EM_AARCH64: return "AArch64";
        case EM_MIPS: return "MIPS";
        case EM_PPC: return "PowerPC";
        case EM_PPC64: return "PowerPC64";
        case EM_RISCV: return "RISC-V";
        case EM_SPARC: return "SPARC";
        case EM_IA_64: return "Intel IA-64";
        default: return "Unknown";
    }
}

static const char *ph_type(uint32_t t) {
    switch (t) {
        case PT_NULL: return "NULL";
        case PT_LOAD: return "LOAD";
        case PT_DYNAMIC: return "DYNAMIC";
        case PT_INTERP: return "INTERP";
        case PT_NOTE: return "NOTE";
        case PT_SHLIB: return "SHLIB";
        case PT_PHDR: return "PHDR";
        case PT_TLS: return "TLS";
        case PT_GNU_EH_FRAME: return "GNU_EH_FRAME";
        case PT_GNU_STACK: return "GNU_STACK";
        case PT_GNU_RELRO: return "GNU_RELRO";
        case PT_GNU_PROPERTY: return "GNU_PROPERTY";
        default: return "UNKNOWN";
    }
}

static const char *sh_type(uint32_t t) {
    switch (t) {
        case SHT_NULL: return "NULL";
        case SHT_PROGBITS: return "PROGBITS";
        case SHT_SYMTAB: return "SYMTAB";
        case SHT_STRTAB: return "STRTAB";
        case SHT_RELA: return "RELA";
        case SHT_HASH: return "HASH";
        case SHT_DYNAMIC: return "DYNAMIC";
        case SHT_NOTE: return "NOTE";
        case SHT_NOBITS: return "NOBITS";
        case SHT_REL: return "REL";
        case SHT_DYNSYM: return "DYNSYM";
        case SHT_INIT_ARRAY: return "INIT_ARRAY";
        case SHT_FINI_ARRAY: return "FINI_ARRAY";
        case SHT_PREINIT_ARRAY: return "PREINIT_ARRAY";
        case SHT_GROUP: return "GROUP";
        case SHT_SYMTAB_SHNDX: return "SYMTAB_SHNDX";
        case SHT_GNU_HASH: return "GNU_HASH";
        case SHT_GNU_verdef: return "VERDEF";
        case SHT_GNU_verneed: return "VERNEED";
        case SHT_GNU_versym: return "VERSYM";
        default: return "UNKNOWN";
    }
}

static void ph_flags(char out[4], uint32_t f) {
    out[0] = (f & PF_R) ? 'R' : ' ';
    out[1] = (f & PF_W) ? 'W' : ' ';
    out[2] = (f & PF_X) ? 'E' : ' ';
    out[3] = 0;
}

static void sh_flags(char *out, size_t n, uint64_t f) {
    size_t k = 0;
    struct { uint64_t bit; char c; } bits[] = {
        {SHF_WRITE,'W'}, {SHF_ALLOC,'A'}, {SHF_EXECINSTR,'X'}, {SHF_MERGE,'M'},
        {SHF_STRINGS,'S'}, {SHF_INFO_LINK,'I'}, {SHF_LINK_ORDER,'L'},
        {SHF_OS_NONCONFORMING,'O'}, {SHF_GROUP,'G'}, {SHF_TLS,'T'},
        {SHF_COMPRESSED,'C'}, {SHF_EXCLUDE,'E'}
    };
    for (size_t i = 0; i < sizeof(bits)/sizeof(bits[0]) && k + 1 < n; i++)
        if (f & bits[i].bit) out[k++] = bits[i].c;
    out[k] = 0;
}

static char *read_file(const char *path, unsigned char **buf, size_t *sz, char *err, size_t errn) {
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        snprintf(err, errn, "Failed to read file \"%s\": %s (os error %d)", path, strerror(errno), errno);
        return err;
    }
    struct stat st;
    if (stat(path, &st) != 0) {
        snprintf(err, errn, "Failed to read file \"%s\": %s (os error %d)", path, strerror(errno), errno);
        fclose(fp);
        return err;
    }
    if (st.st_size < 0) st.st_size = 0;
    *sz = (size_t)st.st_size;
    *buf = malloc(*sz ? *sz : 1);
    if (!*buf) {
        snprintf(err, errn, "Failed to read file \"%s\": out of memory", path);
        fclose(fp);
        return err;
    }
    if (*sz && fread(*buf, 1, *sz, fp) != *sz) {
        snprintf(err, errn, "Failed to read file \"%s\": %s (os error %d)", path, ferror(fp) ? strerror(errno) : "short read", errno);
        fclose(fp);
        return err;
    }
    fclose(fp);
    return NULL;
}

static bool in_range(uint64_t off, uint64_t size, size_t file_size) {
    return off <= file_size && size <= file_size - off;
}

static char *parse_elf(ElfInfo *e, char *err, size_t errn) {
    if (e->size < EI_NIDENT) {
        snprintf(err, errn, "Failed to parse ELF: file is smaller than ELF header's e_ident");
        return err;
    }
    if (memcmp(e->data, ELFMAG, SELFMAG) != 0) {
        snprintf(err, errn, "Failed to parse ELF: mismatched magic: not an ELF file");
        return err;
    }
    int cls = e->data[EI_CLASS], dat = e->data[EI_DATA];
    if (cls != ELFCLASS32 && cls != ELFCLASS64) {
        snprintf(err, errn, "Failed to parse ELF: unsupported ELF class");
        return err;
    }
    if (dat != ELFDATA2LSB && dat != ELFDATA2MSB) {
        snprintf(err, errn, "Failed to parse ELF: unsupported ELF data encoding");
        return err;
    }
    e->is64 = cls == ELFCLASS64;
    e->little = dat == ELFDATA2LSB;
    size_t need = e->is64 ? sizeof(Elf64_Ehdr) : sizeof(Elf32_Ehdr);
    if (e->size < need) {
        snprintf(err, errn, "Failed to parse ELF: file is smaller than ELF file header");
        return err;
    }
    const unsigned char *p = e->data;
    e->type = rd16(p + 16, e->little);
    e->machine = rd16(p + 18, e->little);
    if (e->is64) {
        e->entry = rd64(p + 24, e->little);
        e->phoff = rd64(p + 32, e->little);
        e->shoff = rd64(p + 40, e->little);
        e->flags = rd32(p + 48, e->little);
        e->ehsize = rd16(p + 52, e->little);
        e->phentsize = rd16(p + 54, e->little);
        e->phnum = rd16(p + 56, e->little);
        e->shentsize = rd16(p + 58, e->little);
        e->shnum = rd16(p + 60, e->little);
        e->shstrndx = rd16(p + 62, e->little);
    } else {
        e->entry = rd32(p + 24, e->little);
        e->phoff = rd32(p + 28, e->little);
        e->shoff = rd32(p + 32, e->little);
        e->flags = rd32(p + 36, e->little);
        e->ehsize = rd16(p + 40, e->little);
        e->phentsize = rd16(p + 42, e->little);
        e->phnum = rd16(p + 44, e->little);
        e->shentsize = rd16(p + 46, e->little);
        e->shnum = rd16(p + 48, e->little);
        e->shstrndx = rd16(p + 50, e->little);
    }
    if (e->phnum && !in_range(e->phoff, (uint64_t)e->phentsize * e->phnum, e->size)) {
        snprintf(err, errn, "Failed to parse ELF: program header table extends past end of file");
        return err;
    }
    if (e->shnum && !in_range(e->shoff, (uint64_t)e->shentsize * e->shnum, e->size)) {
        snprintf(err, errn, "Failed to parse ELF: section header table extends past end of file");
        return err;
    }
    return NULL;
}

static void load_phdrs(const ElfInfo *e, Phdr *ph) {
    for (uint16_t i = 0; i < e->phnum; i++) {
        const unsigned char *p = e->data + e->phoff + (uint64_t)i * e->phentsize;
        if (e->is64) {
            ph[i].type = rd32(p, e->little);
            ph[i].flags = rd32(p + 4, e->little);
            ph[i].off = rd64(p + 8, e->little);
            ph[i].vaddr = rd64(p + 16, e->little);
            ph[i].paddr = rd64(p + 24, e->little);
            ph[i].filesz = rd64(p + 32, e->little);
            ph[i].memsz = rd64(p + 40, e->little);
            ph[i].align = rd64(p + 48, e->little);
        } else {
            ph[i].type = rd32(p, e->little);
            ph[i].off = rd32(p + 4, e->little);
            ph[i].vaddr = rd32(p + 8, e->little);
            ph[i].paddr = rd32(p + 12, e->little);
            ph[i].filesz = rd32(p + 16, e->little);
            ph[i].memsz = rd32(p + 20, e->little);
            ph[i].flags = rd32(p + 24, e->little);
            ph[i].align = rd32(p + 28, e->little);
        }
    }
}

static void load_shdrs(const ElfInfo *e, Shdr *sh) {
    for (uint16_t i = 0; i < e->shnum; i++) {
        const unsigned char *p = e->data + e->shoff + (uint64_t)i * e->shentsize;
        if (e->is64) {
            sh[i].name = rd32(p, e->little);
            sh[i].type = rd32(p + 4, e->little);
            sh[i].flags = rd64(p + 8, e->little);
            sh[i].addr = rd64(p + 16, e->little);
            sh[i].off = rd64(p + 24, e->little);
            sh[i].size = rd64(p + 32, e->little);
            sh[i].link = rd32(p + 40, e->little);
            sh[i].info = rd32(p + 44, e->little);
            sh[i].addralign = rd64(p + 48, e->little);
            sh[i].entsize = rd64(p + 56, e->little);
        } else {
            sh[i].name = rd32(p, e->little);
            sh[i].type = rd32(p + 4, e->little);
            sh[i].flags = rd32(p + 8, e->little);
            sh[i].addr = rd32(p + 12, e->little);
            sh[i].off = rd32(p + 16, e->little);
            sh[i].size = rd32(p + 20, e->little);
            sh[i].link = rd32(p + 24, e->little);
            sh[i].info = rd32(p + 28, e->little);
            sh[i].addralign = rd32(p + 32, e->little);
            sh[i].entsize = rd32(p + 36, e->little);
        }
    }
    if (e->shstrndx < e->shnum) {
        Shdr *tab = &sh[e->shstrndx];
        if (tab->type == SHT_STRTAB && in_range(tab->off, tab->size, e->size)) {
            const char *str = (const char *)e->data + tab->off;
            for (uint16_t i = 0; i < e->shnum; i++) {
                sh[i].sname = sh[i].name < tab->size ? str + sh[i].name : "";
            }
        }
    }
    for (uint16_t i = 0; i < e->shnum; i++)
        if (!sh[i].sname) sh[i].sname = "";
}

static void human_size(char *out, size_t n, size_t sz) {
    const char *u[] = {"B", "KiB", "MiB", "GiB"};
    double v = (double)sz;
    int i = 0;
    while (v >= 1024.0 && i < 3) { v /= 1024.0; i++; }
    if (i == 0) snprintf(out, n, "%zu B", sz);
    else snprintf(out, n, "%.1f %s (%zu B)", v, u[i], sz);
}

static void cell_hex(FILE *f, uint64_t v) {
    fprintf(f, "<span class='number' title='%" PRIu64 "'>0x%" PRIx64 "</span>", v, v);
}

static void write_hex_dump(FILE *f, const unsigned char *d, size_t sz) {
    fputs("<h2>Hexdump</h2>\n<table class='hexdump'>\n", f);
    for (size_t off = 0; off < sz; off += 16) {
        fprintf(f, "<tr><td class='offset'>%zx</td><td class='bytes'>", off);
        for (size_t i = 0; i < 16; i++) {
            if (off + i < sz) fprintf(f, "%02x ", d[off + i]);
            else fputs("   ", f);
        }
        fputs("</td><td class='ascii'>", f);
        for (size_t i = 0; i < 16 && off + i < sz; i++) {
            unsigned char c = d[off + i];
            if (c >= 32 && c <= 126) {
                char s[2] = {(char)c, 0};
                html_text(f, s);
            } else {
                fputc('.', f);
            }
        }
        fputs("</td></tr>\n", f);
    }
    fputs("</table>\n", f);
}

static int write_html(const char *input_name, const ElfInfo *e, const Phdr *ph, const Shdr *sh) {
    char outname[4096];
    snprintf(outname, sizeof(outname), "%s.html", base_name(input_name));
    FILE *f = fopen(outname, "w");
    if (!f) {
        fprintf(stderr, "Failed to write file \"%s\": %s (os error %d)\n", outname, strerror(errno), errno);
        return 1;
    }
    char hs[64];
    human_size(hs, sizeof(hs), e->size);
    const char *bn = base_name(input_name);
    fputs("<!doctype html>\n<html>\n  <head>\n    <meta charset='utf-8'>\n", f);
    fputs("    <meta name='viewport' content='width=900, initial-scale=1'>\n    <title>", f);
    html_text(f, bn);
    fputs("</title>\n    <style>\n", f);
    fputs("html{font-family:monospace}body{margin:1em}#credits{float:right;color:#777}.number{color:#070}.ehdr{background:#99e}.phdr{background:#eb9}.shdr{background:#9be}.segment{background:#f99}.section{background:#f9f}.ident{background:#e99}table{border-collapse:collapse;margin:1em 0}td,th{padding:.15em .6em;border-bottom:1px solid #ddd;text-align:left}.hexdump .offset{color:#777}.hexdump .bytes{white-space:pre}.ascii{white-space:pre}h1,h2{font-size:1.1em;margin-top:1.2em}.legend_rect{display:inline-block;width:3em;height:1em;border:1px solid #999;margin-right:.5em;vertical-align:middle}\n", f);
    fputs("    </style>\n  </head>\n  <body>\n", f);
    fputs("    <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a>\n", f);
    fputs("    <h1>ELF report</h1>\n    <table>\n", f);
    fputs("      <tr class='fileinfo_file_name'><td>File name:</td><td>", f); html_text(f, bn); fputs("</td></tr>\n", f);
    fprintf(f, "      <tr class='fileinfo_file_size'><td>File size:</td><td>%s</td></tr>\n", hs);
    fprintf(f, "      <tr class='fileinfo_class'><td>Object class:</td><td>%s</td></tr>\n", class_name(e->data[EI_CLASS]));
    fprintf(f, "      <tr class='fileinfo_data'><td>Data encoding:</td><td>%s</td></tr>\n", data_name(e->data[EI_DATA]));
    fprintf(f, "      <tr class='fileinfo_abi'><td>ABI:</td><td>%s</td></tr>\n", abi_name(e->data[EI_OSABI]));
    fprintf(f, "      <tr class='fileinfo_e_type'><td>Type:</td><td>%s</td></tr>\n", type_name(e->type));
    fprintf(f, "      <tr class='fileinfo_e_machine'><td>Architecture:</td><td>%s</td></tr>\n", machine_name(e->machine));
    fputs("      <tr class='fileinfo_e_entry'><td>Entrypoint:</td><td>", f); cell_hex(f, e->entry); fputs("</td></tr>\n", f);
    fprintf(f, "      <tr class='fileinfo_ph'><td>Program headers:</td><td><span title='0x%x' class='number fileinfo_e_phnum'>%u</span> * <span title='0x%x' class='number fileinfo_e_phentsize'>%u</span> @ <span title='0x%" PRIx64 "' class='number fileinfo_e_phoff'>%" PRIu64 "</span></td></tr>\n", e->phnum, e->phnum, e->phentsize, e->phentsize, e->phoff, e->phoff);
    fprintf(f, "      <tr class='fileinfo_sh'><td>Section headers:</td><td><span title='0x%x' class='number fileinfo_e_shnum'>%u</span> * <span title='0x%x' class='number fileinfo_e_shentsize'>%u</span> @ <span title='0x%" PRIx64 "' class='number fileinfo_e_shoff'>%" PRIu64 "</span></td></tr>\n", e->shnum, e->shnum, e->shentsize, e->shentsize, e->shoff, e->shoff);
    fputs("    </table>\n", f);

    fputs("<h2>ELF Header</h2>\n<table class='ehdr'>\n", f);
    fprintf(f, "<tr><td>Magic</td><td>%02x %02x %02x %02x</td></tr>\n", e->data[0], e->data[1], e->data[2], e->data[3]);
    fprintf(f, "<tr><td>Version</td><td>%u</td></tr>\n", e->data[EI_VERSION]);
    fprintf(f, "<tr><td>ABI version</td><td>%u</td></tr>\n", e->data[EI_ABIVERSION]);
    fprintf(f, "<tr><td>Flags</td><td>0x%" PRIx64 "</td></tr>\n", e->flags);
    fprintf(f, "<tr><td>ELF header size</td><td>%" PRIu64 "</td></tr>\n", e->ehsize);
    fprintf(f, "<tr><td>Section header string table index</td><td>%u</td></tr>\n", e->shstrndx);
    fputs("</table>\n", f);

    fputs("<h2>Program Headers</h2>\n<table class='phdrs'><tr><th>Nr</th><th>Type</th><th>Offset</th><th>VirtAddr</th><th>PhysAddr</th><th>FileSiz</th><th>MemSiz</th><th>Flags</th><th>Align</th></tr>\n", f);
    for (uint16_t i = 0; i < e->phnum; i++) {
        char fl[4]; ph_flags(fl, ph[i].flags);
        fprintf(f, "<tr class='bin_phdr%u phdr'><td>%u</td><td>%s</td><td>", i, i, ph_type(ph[i].type)); cell_hex(f, ph[i].off);
        fputs("</td><td>", f); cell_hex(f, ph[i].vaddr);
        fputs("</td><td>", f); cell_hex(f, ph[i].paddr);
        fputs("</td><td>", f); cell_hex(f, ph[i].filesz);
        fputs("</td><td>", f); cell_hex(f, ph[i].memsz);
        fprintf(f, "</td><td>%s</td><td>", fl); cell_hex(f, ph[i].align); fputs("</td></tr>\n", f);
    }
    fputs("</table>\n", f);

    fputs("<h2>Section Headers</h2>\n<table class='shdrs'><tr><th>Nr</th><th>Name</th><th>Type</th><th>Address</th><th>Offset</th><th>Size</th><th>EntSize</th><th>Flags</th><th>Link</th><th>Info</th><th>Align</th></tr>\n", f);
    for (uint16_t i = 0; i < e->shnum; i++) {
        char fl[32]; sh_flags(fl, sizeof(fl), sh[i].flags);
        fprintf(f, "<tr class='bin_shdr%u shdr'><td>%u</td><td>", i, i); html_text(f, sh[i].sname);
        fprintf(f, "</td><td>%s</td><td>", sh_type(sh[i].type)); cell_hex(f, sh[i].addr);
        fputs("</td><td>", f); cell_hex(f, sh[i].off);
        fputs("</td><td>", f); cell_hex(f, sh[i].size);
        fputs("</td><td>", f); cell_hex(f, sh[i].entsize);
        fprintf(f, "</td><td>%s</td><td>%u</td><td>%u</td><td>", fl, sh[i].link, sh[i].info);
        cell_hex(f, sh[i].addralign); fputs("</td></tr>\n", f);
    }
    fputs("</table>\n", f);

    fputs("<h2>Section to Segment mapping</h2>\n<table><tr><th>Segment</th><th>Sections</th></tr>\n", f);
    for (uint16_t i = 0; i < e->phnum; i++) {
        fprintf(f, "<tr><td>%02u</td><td>", i);
        bool first = true;
        for (uint16_t j = 0; j < e->shnum; j++) {
            if (sh[j].size == 0 || sh[j].type == SHT_NOBITS) continue;
            if (sh[j].off >= ph[i].off && sh[j].off + sh[j].size <= ph[i].off + ph[i].filesz) {
                if (!first) fputc(' ', f);
                html_text(f, sh[j].sname);
                first = false;
            }
        }
        fputs("</td></tr>\n", f);
    }
    fputs("</table>\n", f);
    write_hex_dump(f, e->data, e->size);
    fputs("  </body>\n</html>\n", f);
    fclose(f);
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "--help") == 0) {
        puts("Usage: elfcat <filename>");
        puts("Writes <filename>.html to CWD.");
        return 1;
    }
    ElfInfo e;
    memset(&e, 0, sizeof(e));
    char err[512];
    if (read_file(argv[1], &e.data, &e.size, err, sizeof(err))) {
        fprintf(stderr, "%s\n", err);
        return 1;
    }
    if (parse_elf(&e, err, sizeof(err))) {
        fprintf(stderr, "%s\n", err);
        free(e.data);
        return 1;
    }
    Phdr *ph = calloc(e.phnum ? e.phnum : 1, sizeof(*ph));
    Shdr *sh = calloc(e.shnum ? e.shnum : 1, sizeof(*sh));
    if (!ph || !sh) {
        fputs("out of memory\n", stderr);
        free(ph); free(sh); free(e.data);
        return 1;
    }
    load_phdrs(&e, ph);
    load_shdrs(&e, sh);
    int rc = write_html(argv[1], &e, ph, sh);
    free(ph);
    free(sh);
    free(e.data);
    return rc;
}
