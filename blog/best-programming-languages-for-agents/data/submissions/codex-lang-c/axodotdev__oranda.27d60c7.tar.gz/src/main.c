#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static const char *prog = "executable";
static bool json_output = false;

static void usage_root_long(void) {
    printf("🎁 generate beautiful landing pages for your projects\n\n");
    printf("Usage: %s [OPTIONS] <COMMAND>\n\n", prog);
    printf("Commands:\n");
    printf("  build     Build an oranda site\n");
    printf("  dev       Start a local development server that recompiles your oranda site if a file changes\n");
    printf("  serve     Start a file server to access your oranda site in a browser\n");
    printf("  generate  Generate infrastructure files for oranda sites\n");
    printf("  help      Print this message or the help of the given subcommand(s)\n\n");
    printf("Options:\n");
    printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
    printf("  -V, --version\n          Print version\n\n");
    printf("GLOBAL OPTIONS:\n");
    printf("  -v, --verbose\n          Whether to output more detailed debug information\n\n");
    printf("      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n");
    printf("          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n");
}

static void usage_root_short(void) {
    printf("🎁 generate beautiful landing pages for your projects\n\n");
    printf("Usage: %s [OPTIONS] <COMMAND>\n\n", prog);
    printf("Commands:\n");
    printf("  build     Build an oranda site\n");
    printf("  dev       Start a local development server that recompiles your oranda site if a file changes\n");
    printf("  serve     Start a file server to access your oranda site in a browser\n");
    printf("  generate  Generate infrastructure files for oranda sites\n");
    printf("  help      Print this message or the help of the given subcommand(s)\n\n");
    printf("Options:\n");
    printf("  -h, --help     Print help (see more with '--help')\n");
    printf("  -V, --version  Print version\n\n");
    printf("GLOBAL OPTIONS:\n");
    printf("  -v, --verbose                        Whether to output more detailed debug information\n");
    printf("      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n");
    printf("                                       human, json]\n");
}

static void global_opts_long(void) {
    printf("GLOBAL OPTIONS:\n");
    printf("  -v, --verbose\n          Whether to output more detailed debug information\n\n");
    printf("      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n");
    printf("          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n");
}

static void global_opts_short(void) {
    printf("GLOBAL OPTIONS:\n");
    printf("  -v, --verbose                        Whether to output more detailed debug information\n");
    printf("      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n");
    printf("                                       human, json]\n");
}

static void help_build(bool longf) {
    printf("Build an oranda site\n\nUsage: %s build [OPTIONS]\n\nOptions:\n", prog);
    if (longf) {
        printf("      --json-only\n          Only build the artifacts JSON file (if applicable) and other files that may be used to\n          support it, such as installer source files\n\n");
        printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
        global_opts_long();
    } else {
        printf("      --json-only  Only build the artifacts JSON file (if applicable) and other files that may be\n                   used to support it, such as installer source files\n");
        printf("  -h, --help       Print help (see more with '--help')\n\n");
        global_opts_short();
    }
}

static void help_dev(bool longf) {
    printf("Start a local development server that recompiles your oranda site if a file changes\n\nUsage: %s dev [OPTIONS]\n\nOptions:\n", prog);
    if (longf) {
        printf("      --port <PORT>\n          The port for the file server to be launched on\n\n");
        printf("      --no-first-build\n          Skip the first build before starting to watch for changes\n\n");
        printf("  -i, --include-paths <INCLUDE_PATHS>\n          List of extra paths to watch\n\n");
        printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
        global_opts_long();
    } else {
        printf("      --port <PORT>                    The port for the file server to be launched on\n");
        printf("      --no-first-build                 Skip the first build before starting to watch for changes\n");
        printf("  -i, --include-paths <INCLUDE_PATHS>  List of extra paths to watch\n");
        printf("  -h, --help                           Print help (see more with '--help')\n\n");
        global_opts_short();
    }
}

static void help_serve(bool longf) {
    printf("Start a file server to access your oranda site in a browser\n\nUsage: %s serve [OPTIONS]\n\nOptions:\n", prog);
    if (longf) {
        printf("      --port <PORT>\n          [default: 7979]\n\n");
        printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
        global_opts_long();
    } else {
        printf("      --port <PORT>  [default: 7979]\n");
        printf("  -h, --help         Print help (see more with '--help')\n\n");
        global_opts_short();
    }
}

static void help_generate(bool longf) {
    printf("Generate infrastructure files for oranda sites\n\nUsage: %s generate [OPTIONS] <COMMAND>\n\n", prog);
    printf("Commands:\n  ci    Generates a CI file that can be used to deploy your site\n  help  Print this message or the help of the given subcommand(s)\n\nOptions:\n");
    if (longf) {
        printf("  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n");
        printf("  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n");
        printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
        global_opts_long();
    } else {
        printf("  -o, --output-path <OUTPUT_PATH>  Path to the output file\n");
        printf("  -s, --site-path <SITE_PATH>      Path to your oranda site\n");
        printf("  -h, --help                       Print help (see more with '--help')\n\n");
        global_opts_short();
    }
}

static void help_generate_ci(bool longf) {
    printf("Generates a CI file that can be used to deploy your site\n\nUsage: %s generate ci [OPTIONS]\n\nOptions:\n", prog);
    if (longf) {
        printf("      --ci <CI>\n          What CI to generate a file for\n          \n          [default: github]\n\n");
        printf("          Possible values:\n          - github: Deploy to GitHub Pages using GitHub Actions\n\n");
        printf("  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n");
        printf("  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n");
        printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
        global_opts_long();
    } else {
        printf("      --ci <CI>                    What CI to generate a file for [default: github] [possible\n");
        printf("                                   values: github]\n");
        printf("  -o, --output-path <OUTPUT_PATH>  Path to the output file\n");
        printf("  -s, --site-path <SITE_PATH>      Path to your oranda site\n");
        printf("  -h, --help                       Print help (see more with '--help')\n\n");
        global_opts_short();
    }
}

static int err_unrecognized_sub(const char *s) {
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: %s [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n", s, prog);
    return 2;
}

static int parse_port(const char *s, int *port) {
    if (!s || !*s) return -1;
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || *end || v < 0 || v > 65535) return -1;
    *port = (int)v;
    return 0;
}

static void mkdir_p(const char *p) {
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", p);
    for (char *q = tmp + 1; *q; q++) {
        if (*q == '/') {
            *q = 0;
            mkdir(tmp, 0777);
            *q = '/';
        }
    }
    mkdir(tmp, 0777);
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n < 0) { fclose(f); return NULL; }
    char *buf = calloc((size_t)n + 1, 1);
    if (!buf) { fclose(f); return NULL; }
    fread(buf, 1, (size_t)n, f);
    fclose(f);
    return buf;
}

static void html_escape(FILE *out, const char *s) {
    for (; s && *s; s++) {
        if (*s == '&') fputs("&amp;", out);
        else if (*s == '<') fputs("&lt;", out);
        else if (*s == '>') fputs("&gt;", out);
        else if (*s == '"') fputs("&quot;", out);
        else fputc(*s, out);
    }
}

static int build_site(bool json_only) {
    (void)json_only;
    mkdir_p("public");
    FILE *ico = fopen("public/favicon.ico", "wb");
    if (ico) fclose(ico);
    char *readme = read_file("README.md");
    FILE *out = fopen("public/index.html", "w");
    if (!out) {
        fprintf(stderr, "  × failed to write public/index.html: %s\n", strerror(errno));
        free(readme);
        return 255;
    }
    const char *title = "oranda";
    if (readme && *readme) {
        static char first[256];
        size_t i = 0;
        while (readme[i] && readme[i] != '\n' && i + 1 < sizeof(first)) { first[i] = readme[i]; i++; }
        first[i] = 0;
        if (first[0]) title = first;
    }
    fprintf(out, "<!doctype html>\n<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>");
    html_escape(out, title);
    fprintf(out, "</title><style>body{font-family:system-ui,sans-serif;max-width:840px;margin:3rem auto;padding:0 1rem;line-height:1.55}pre{white-space:pre-wrap}</style></head><body><pre>");
    html_escape(out, readme ? readme : "oranda\n\nGenerate beautiful landing pages for your projects.\n");
    fprintf(out, "</pre></body></html>\n");
    fclose(out);
    free(readme);
    printf("✓ >o_o< SUCCESS: Your site build is located in `public`.\n");
    return 0;
}

static int serve_forever(int port) {
    struct stat st;
    if (stat("public", &st) != 0 || !S_ISDIR(st.st_mode)) {
        fprintf(stderr, "  × Could not find a build in public\n  help: Did you remember to run `oranda build`?\n");
        return 255;
    }
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons((uint16_t)port);
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(fd, 16) != 0) {
        fprintf(stderr, "  × failed to start server: %s\n", strerror(errno));
        close(fd);
        return 255;
    }
    if (port == 0) {
        socklen_t len = sizeof(addr);
        getsockname(fd, (struct sockaddr *)&addr, &len);
        port = ntohs(addr.sin_port);
    }
    printf("✓ >o_o< SUCCESS: Your project is available at: http://127.0.0.1:%d\n", port);
    fflush(stdout);
    signal(SIGPIPE, SIG_IGN);
    for (;;) {
        int c = accept(fd, NULL, NULL);
        if (c < 0) continue;
        char req[1024];
        read(c, req, sizeof(req) - 1);
        char *body = read_file("public/index.html");
        if (!body) body = strdup("<!doctype html><title>oranda</title><h1>oranda</h1>\n");
        dprintf(c, "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n%s", strlen(body), body);
        free(body);
        close(c);
    }
}

static int generate_ci(int argc, char **argv) {
    const char *out_path = NULL, *site = ".";
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h")) { help_generate_ci(false); return 0; }
        if (!strcmp(argv[i], "--help")) { help_generate_ci(true); return 0; }
        if ((!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output-path")) && i + 1 < argc) out_path = argv[++i];
        else if ((!strcmp(argv[i], "-s") || !strcmp(argv[i], "--site-path")) && i + 1 < argc) site = argv[++i];
        else if (!strcmp(argv[i], "--ci") && i + 1 < argc) {
            if (strcmp(argv[++i], "github")) {
                fprintf(stderr, "error: invalid value '%s' for '--ci <CI>'\n  [possible values: github]\n\nFor more information, try '--help'.\n", argv[i]);
                return 2;
            }
        } else if (!strcmp(argv[i], "--ci")) {
            fprintf(stderr, "error: a value is required for '--ci <CI>' but none was supplied\n\nFor more information, try '--help'.\n");
            return 2;
        }
    }
    if (!out_path) out_path = ".github/workflows/web.yml";
    char dir[512];
    snprintf(dir, sizeof(dir), "%s", out_path);
    char *slash = strrchr(dir, '/');
    if (slash) { *slash = 0; mkdir_p(dir); }
    FILE *f = fopen(out_path, "w");
    if (!f) {
        fprintf(stderr, "  × failed to write %s: %s\n", out_path, strerror(errno));
        return 255;
    }
    fprintf(f,
            "name: Web\n\non:\n  push:\n    branches: [main]\n  workflow_dispatch:\n\n"
            "permissions:\n  contents: read\n  pages: write\n  id-token: write\n\n"
            "jobs:\n  deploy:\n    runs-on: ubuntu-latest\n    steps:\n"
            "      - uses: actions/checkout@v4\n"
            "      - uses: axodotdev/oranda-action@v1\n        with:\n          path: %s\n"
            "      - uses: actions/upload-pages-artifact@v3\n        with:\n          path: public\n"
            "      - uses: actions/deploy-pages@v4\n", site);
    fclose(f);
    printf("↪ >o_o< INFO: Generating a CI deploy workflow for your site...\n");
    printf("✓ >o_o< SUCCESS: Wrote %s\n", out_path);
    return 0;
}

static int cmd_build(int argc, char **argv) {
    bool json_only = false;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h")) { help_build(false); return 0; }
        if (!strcmp(argv[i], "--help")) { help_build(true); return 0; }
        if (!strcmp(argv[i], "--json-only")) json_only = true;
        else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose")) {}
        else { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: %s build [OPTIONS]\n\nFor more information, try '--help'.\n", argv[i], prog); return 2; }
    }
    return build_site(json_only);
}

static int cmd_serve(int argc, char **argv) {
    int port = 7979;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h")) { help_serve(false); return 0; }
        if (!strcmp(argv[i], "--help")) { help_serve(true); return 0; }
        if (!strcmp(argv[i], "--port") && i + 1 < argc) {
            if (parse_port(argv[++i], &port)) { fprintf(stderr, "error: invalid value '%s' for '--port <PORT>': invalid digit found in string\n\nFor more information, try '--help'.\n", argv[i]); return 2; }
        } else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose")) {}
        else { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: %s serve [OPTIONS]\n\nFor more information, try '--help'.\n", argv[i], prog); return 2; }
    }
    return serve_forever(port);
}

static int cmd_dev(int argc, char **argv) {
    int port = 7979;
    bool first = true;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h")) { help_dev(false); return 0; }
        if (!strcmp(argv[i], "--help")) { help_dev(true); return 0; }
        if (!strcmp(argv[i], "--no-first-build")) first = false;
        else if ((!strcmp(argv[i], "-i") || !strcmp(argv[i], "--include-paths")) && i + 1 < argc) i++;
        else if (!strcmp(argv[i], "--port") && i + 1 < argc) {
            if (parse_port(argv[++i], &port)) { fprintf(stderr, "error: invalid value '%s' for '--port <PORT>': invalid digit found in string\n\nFor more information, try '--help'.\n", argv[i]); return 2; }
        } else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose")) {}
        else { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: %s dev [OPTIONS]\n\nFor more information, try '--help'.\n", argv[i], prog); return 2; }
    }
    if (first) {
        int r = build_site(false);
        if (r) return r;
    }
    printf("↪ >o_o< INFO: Found 1 paths to watch, starting watch...\n");
    return serve_forever(port);
}

static int cmd_generate(int argc, char **argv) {
    int idx = -1;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "-h")) { help_generate(false); return 0; }
        if (!strcmp(argv[i], "--help")) { help_generate(true); return 0; }
        if (!strcmp(argv[i], "help")) {
            if (i + 1 < argc && !strcmp(argv[i + 1], "ci")) help_generate_ci(true);
            else help_generate(true);
            return 0;
        }
        if (!strcmp(argv[i], "ci")) { idx = i; break; }
        if ((!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output-path") || !strcmp(argv[i], "-s") || !strcmp(argv[i], "--site-path")) && i + 1 < argc) i++;
    }
    if (idx < 0) {
        fprintf(stderr, "error: a subcommand is required\n\nUsage: %s generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n", prog);
        return 2;
    }
    return generate_ci(argc - idx - 1, argv + idx + 1);
}

int main(int argc, char **argv) {
    if (argc > 0 && argv[0] && *argv[0]) {
        const char *s = strrchr(argv[0], '/');
        prog = s ? s + 1 : argv[0];
    }
    char *args[256];
    int n = 0;
    for (int i = 1; i < argc && n < 255; i++) {
        if (!strcmp(argv[i], "--output-format")) {
            if (i + 1 >= argc) { fprintf(stderr, "error: a value is required for '--output-format <OUTPUT_FORMAT>' but none was supplied\n\nFor more information, try '--help'.\n"); return 2; }
            if (!strcmp(argv[i + 1], "json")) json_output = true;
            else if (strcmp(argv[i + 1], "human")) { fprintf(stderr, "error: invalid value '%s' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n\nFor more information, try '--help'.\n", argv[i + 1]); return 2; }
            i++;
        } else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose")) {
        } else args[n++] = argv[i];
    }
    args[n] = NULL;
    (void)json_output;
    if (n == 0) { usage_root_short(); return 2; }
    if (!strcmp(args[0], "-h")) { usage_root_short(); return 0; }
    if (!strcmp(args[0], "--help")) { usage_root_long(); return 0; }
    if (!strcmp(args[0], "-V") || !strcmp(args[0], "--version")) { printf("oranda 0.6.5\n"); return 0; }
    if (!strcmp(args[0], "help")) {
        if (n == 1) { usage_root_long(); return 0; }
        if (!strcmp(args[1], "build")) help_build(true);
        else if (!strcmp(args[1], "dev")) help_dev(true);
        else if (!strcmp(args[1], "serve")) help_serve(true);
        else if (!strcmp(args[1], "generate")) {
            if (n > 2 && !strcmp(args[2], "ci")) help_generate_ci(true);
            else help_generate(true);
        } else return err_unrecognized_sub(args[1]);
        return 0;
    }
    if (!strcmp(args[0], "build")) return cmd_build(n - 1, args + 1);
    if (!strcmp(args[0], "dev")) return cmd_dev(n - 1, args + 1);
    if (!strcmp(args[0], "serve")) return cmd_serve(n - 1, args + 1);
    if (!strcmp(args[0], "generate")) return cmd_generate(n - 1, args + 1);
    return err_unrecognized_sub(args[0]);
}
