#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>
#include <limits.h>

static const char *version_text = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1\n";

static void print_help_variant(const char *default_flag) {
    printf("executable\n\n");
    printf("  Usage:\n");
    printf("    executable [git-arg]\n\n");
    printf("  Positional Variables: \n");
    printf("    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.\n");
    printf("  Flags: \n");
    printf("    -h --help               Displays help with available flag, subcommand, and positional value parameters.\n");
    printf("    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)\n");
    printf("    -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted\n");
    printf("    -v --version            Print the current version%s\n", default_flag && strcmp(default_flag,"version")==0 ? " (default: false)" : "");
    printf("    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)\n");
    printf("    -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)\n");
    printf("       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.\n");
    printf("    -c --config             Print the default config%s\n", default_flag && strcmp(default_flag,"config")==0 ? " (default: false)" : "");
    printf("    -cd --print-config-dir   Print the config directory%s\n", default_flag && strcmp(default_flag,"print-config-dir")==0 ? " (default: false)" : "");
    printf("    -ucd --use-config-dir     override default config directory with provided directory\n");
    printf("    -w --work-tree          equivalent of the --work-tree git argument\n");
    printf("    -g --git-dir            equivalent of the --git-dir git argument\n");
    printf("    -ucf --use-config-file    Comma separated list to custom config file(s)\n");
    printf("    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'\n\n");
}

static int is_value_flag(const char *s) {
    const char *flags[] = {"-p","--path","-f","--filter","-ucd","--use-config-dir","-w","--work-tree","-g","--git-dir","-ucf","--use-config-file","-sm","--screen-mode",NULL};
    for (int i=0; flags[i]; i++) if (strcmp(s, flags[i]) == 0) return 1;
    return 0;
}
static const char *flag_name(const char *s) {
    while (*s == '-') s++;
    return s;
}

static bool has_git_dir(const char *path) {
    char buf[PATH_MAX];
    struct stat st;
    snprintf(buf, sizeof(buf), "%s/.git", path);
    return stat(buf, &st) == 0;
}

static void config_dir(char *out, size_t n, const char *override) {
    if (override && *override) { snprintf(out, n, "%s", override); return; }
    const char *xdg = getenv("XDG_CONFIG_HOME");
    const char *home = getenv("HOME");
    if (xdg && *xdg) snprintf(out, n, "%s/lazygit", xdg);
    else if (home && *home) snprintf(out, n, "%s/.config/lazygit", home);
    else snprintf(out, n, ".config/lazygit");
}

static void state_log_path(char *out, size_t n) {
    const char *xdg = getenv("XDG_STATE_HOME");
    const char *home = getenv("HOME");
    if (xdg && *xdg) snprintf(out, n, "%s/lazygit/development.log", xdg);
    else if (home && *home) snprintf(out, n, "%s/.local/state/lazygit/development.log", home);
    else snprintf(out, n, ".local/state/lazygit/development.log");
}

static int print_config(void) {
    FILE *f = fopen("default_config.yml", "rb");
    if (!f) f = fopen("/workspace/default_config.yml", "rb");
    if (!f) {
        puts("gui:\n    authorColors: {}\ngit:\n    pagers: []");
        return 0;
    }
    char buf[4096]; size_t r;
    while ((r = fread(buf, 1, sizeof buf, f)) > 0) fwrite(buf, 1, r, stdout);
    fclose(f);
    return 0;
}

static int run_command_capture(const char *cmd) {
    FILE *p = popen(cmd, "r");
    if (!p) return 1;
    char buf[512];
    while (fgets(buf, sizeof buf, p)) fputs(buf, stdout);
    int rc = pclose(p);
    return rc == 0 ? 0 : 1;
}

static int start_ui(const char *path) {
    const char *term = getenv("TERM");
    if (!term || !*term) {
        time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
        fprintf(stderr, "%04d/%02d/%02d %02d:%02d:%02d An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n", tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
        fprintf(stderr, "*fmt.wrapError terminal entry not found: term not set\n/workspace/pkg/app/app.go:55 (0xc91c3f)\n/workspace/pkg/app/entry_point.go:177 (0xc93eb6)\n/workspace/main.go:23 (0xc95258)\n");
        return 1;
    }
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
        fprintf(stderr, "%04d/%02d/%02d %02d:%02d:%02d An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n", tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
        fprintf(stderr, "*fs.PathError open /dev/tty: no such device or address\n/workspace/pkg/app/app.go:55 (0xc91c3f)\n/workspace/pkg/app/entry_point.go:177 (0xc93eb6)\n/workspace/main.go:23 (0xc95258)\n");
        return 1;
    }
    if (path && *path && chdir(path) != 0) { perror(path); return 1; }
    printf("\033[?1049h\033[H\033[2J");
    printf("Lazygit\r\n\r\n");
    printf("Status\r\n");
    run_command_capture("git status --short --branch 2>&1");
    printf("\r\nPress q to quit.\r\n");
    fflush(stdout);
    int c;
    while ((c = getchar()) != EOF) if (c == 'q' || c == 'Q' || c == 3) break;
    printf("\033[?1049l");
    return 0;
}

int main(int argc, char **argv) {
    bool want_help=false, want_version=false, want_config=false, want_config_dir=false, want_logs=false;
    const char *use_config_dir=NULL, *path=NULL;
    const char *default_flag=NULL;

    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (strcmp(a,"-h")==0 || strcmp(a,"--help")==0 || strcmp(a,"help")==0) want_help=true;
        else if (strcmp(a,"-v")==0 || strcmp(a,"--version")==0) { want_version=true; default_flag="version"; }
        else if (strcmp(a,"-c")==0 || strcmp(a,"--config")==0) { want_config=true; default_flag="config"; }
        else if (strcmp(a,"-cd")==0 || strcmp(a,"--print-config-dir")==0) { want_config_dir=true; default_flag="print-config-dir"; }
        else if (strcmp(a,"-l")==0 || strcmp(a,"--logs")==0) want_logs=true;
        else if (strcmp(a,"-d")==0 || strcmp(a,"--debug")==0 || strcmp(a,"--profile")==0) { }
        else if (is_value_flag(a)) {
            if (i+1 >= argc) { print_help_variant(default_flag); printf("Expected a following arg for flag %s, but it did not exist.\n", flag_name(a)); return 2; }
            const char *v = argv[++i];
            if (strcmp(a,"-ucd")==0 || strcmp(a,"--use-config-dir")==0) use_config_dir=v;
            else if (strcmp(a,"-p")==0 || strcmp(a,"--path")==0) path=v;
        } else if (a[0]=='-') {
            if (i+1 >= argc) { print_help_variant(default_flag); printf("Expected a following arg for flag %s, but it did not exist.\n", flag_name(a)); return 2; }
            print_help_variant(default_flag);
            printf("Unknown arguments supplied:  %s %s\n", flag_name(a), argv[i+1]);
            return 2;
        } else {
            /* positional panel name: accepted loosely */
        }
    }

    if (want_help) { print_help_variant(NULL); return 0; }

    if (path && !has_git_dir(path)) {
        time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
        fprintf(stderr, "%04d/%02d/%02d %02d:%02d:%02d %s is not a valid git repository.\n", tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec, path);
        return 1;
    }

    if (want_version) { fputs(version_text, stdout); return 0; }
    if (want_config_dir) { char d[PATH_MAX]; config_dir(d, sizeof d, use_config_dir); puts(d); return 0; }
    if (want_config) return print_config();
    if (want_logs) {
        char lp[PATH_MAX]; state_log_path(lp, sizeof lp);
        printf("Tailing log file %s\n\n", lp);
        fflush(stdout);
        if (access(lp, R_OK) != 0) {
            time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
            fprintf(stderr, "%04d/%02d/%02d %02d:%02d:%02d Log file does not exist. Run `lazygit --debug` first to create the log file\n", tm.tm_year+1900, tm.tm_mon+1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
            return 1;
        }
        char cmd[PATH_MAX+32]; snprintf(cmd, sizeof cmd, "tail -f '%s'", lp); return system(cmd);
    }
    return start_ui(path);
}
