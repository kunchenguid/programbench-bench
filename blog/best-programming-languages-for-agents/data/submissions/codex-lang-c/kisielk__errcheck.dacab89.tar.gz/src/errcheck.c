#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { char **v; int n, cap; } Strs;
static void add_str(Strs *s, const char *x){ if(s->n==s->cap){s->cap=s->cap?2*s->cap:16; s->v=realloc(s->v,s->cap*sizeof(char*));} s->v[s->n++]=strdup(x); }
static bool has_str(Strs *s, const char *x){ for(int i=0;i<s->n;i++) if(!strcmp(s->v[i],x)) return true; return false; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1])) *--e=0; return s; }
static bool starts(const char *s,const char*p){return strncmp(s,p,strlen(p))==0;}
static bool ends(const char *s,const char*p){size_t a=strlen(s),b=strlen(p);return a>=b&&!strcmp(s+a-b,p);}
static char *xasprintf(const char *fmt,...){ va_list ap; va_start(ap,fmt); char *r=NULL; if(vasprintf(&r,fmt,ap)<0) exit(2); va_end(ap); return r; }

typedef struct { char alias[128], path[256]; } Import;
typedef struct {
  char *path, **lines; int nlines;
  Import imports[256]; int nimports;
} GoFile;
typedef struct { GoFile *v; int n, cap; } Files;
typedef struct { char name[256], pkg[256], argtag[256]; regex_t re; bool has_re, whole_pkg; } Ignore;

static bool opt_abspath,opt_asserts,opt_blank,opt_excludeonly,opt_ignoregenerated,opt_ignoretests,opt_verbose;
static char *opt_exclude=NULL,*opt_mod=NULL,*opt_tags=NULL;
static Strs excludes, funcs, method_funcs, ignorepkgs, findings;
static Ignore ignores[256]; static int nignores;

static void usage(FILE *f,const char *argv0){
  fprintf(f,"Usage of %s:\n",argv0);
  fprintf(f,"  -abspath\n\tprint absolute paths to files\n");
  fprintf(f,"  -asserts\n\tif true, check for ignored type assertion results\n");
  fprintf(f,"  -blank\n\tif true, check for errors assigned to blank identifier\n");
  fprintf(f,"  -exclude string\n\tPath to a file containing a list of functions to exclude from checking\n");
  fprintf(f,"  -excludeonly\n\tUse only excludes from -exclude file\n");
  fprintf(f,"  -ignore value\n\t[deprecated] comma-separated list of pairs of the form pkg:regex\n\t            the regex is used to ignore names within pkg.\n");
  fprintf(f,"  -ignoregenerated\n\tif true, checking of files with generated code is disabled\n");
  fprintf(f,"  -ignorepkg string\n\tcomma-separated list of package paths to ignore\n");
  fprintf(f,"  -ignoretests\n\tif true, checking of _test.go files is disabled\n");
  fprintf(f,"  -mod string\n\tmodule download mode to use: readonly or vendor. See 'go help modules' for more.\n");
  fprintf(f,"  -tags value\n\tcomma or space-separated list of build tags to include\n");
  fprintf(f,"  -verbose\n\tproduce more verbose logging\n");
}

static void default_excludes(void){
  const char *d[]={"fmt.Print","fmt.Printf","fmt.Println","fmt.Fprint","fmt.Fprintf","fmt.Fprintln","fmt.Sprint","fmt.Sprintf","fmt.Sprintln","fmt.Errorf","bytes.Buffer.Write","bytes.Buffer.WriteString","strings.Builder.Write","strings.Builder.WriteString",NULL};
  for(int i=0;d[i];i++) add_str(&excludes,d[i]);
}
static void load_exclude(const char *p){
  FILE *f=fopen(p,"r"); if(!f){fprintf(stderr,"Could not read exclude file: %s\n",strerror(errno)); exit(2);}
  char *line=NULL; size_t cap=0;
  while(getline(&line,&cap,f)>0){ char *t=trim(line); if(!*t||starts(t,"//")) continue; add_str(&excludes,t); }
  free(line); fclose(f);
}
static void parse_ignore(char *s){
  char *save=NULL;
  for(char *tok=strtok_r(s,",",&save);tok;tok=strtok_r(NULL,",",&save)){
    char *colon=strchr(tok,':'); Ignore *ig=&ignores[nignores++]; memset(ig,0,sizeof(*ig));
    if(colon){ *colon=0; strncpy(ig->pkg,trim(tok),255); strncpy(ig->name,trim(colon+1),255); }
    else { ig->pkg[0]=0; strncpy(ig->name,trim(tok),255); }
    if(regcomp(&ig->re,ig->name,REG_EXTENDED|REG_NOSUB)==0) ig->has_re=true;
  }
}
static void parse_ignorepkg(char *s){ char *save=NULL; for(char *t=strtok_r(s,",",&save);t;t=strtok_r(NULL,",",&save)) add_str(&ignorepkgs,trim(t)); }

static bool generated(GoFile *gf){
  int lim=gf->nlines<20?gf->nlines:20;
  for(int i=0;i<lim;i++) if(strstr(gf->lines[i],"Code generated")&&strstr(gf->lines[i],"DO NOT EDIT")) return true;
  return false;
}
static bool is_dir(const char *p){ struct stat st; return stat(p,&st)==0&&S_ISDIR(st.st_mode); }
static bool is_file(const char *p){ struct stat st; return stat(p,&st)==0&&S_ISREG(st.st_mode); }

static void read_file(Files *fs,const char *path){
  if(!ends(path,".go")) return;
  if(opt_ignoretests && ends(path,"_test.go")) return;
  FILE *f=fopen(path,"r"); if(!f) return;
  GoFile gf; memset(&gf,0,sizeof(gf)); gf.path=strdup(path);
  char *line=NULL; size_t cap=0; Strs ls={0};
  while(getline(&line,&cap,f)>0){ size_t n=strlen(line); while(n&& (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0; add_str(&ls,line); }
  free(line); fclose(f); gf.lines=ls.v; gf.nlines=ls.n;
  if(opt_ignoregenerated && generated(&gf)) return;
  if(fs->n==fs->cap){fs->cap=fs->cap?fs->cap*2:16; fs->v=realloc(fs->v,fs->cap*sizeof(GoFile));}
  fs->v[fs->n++]=gf;
}
static void walk(Files *fs,const char *path){
  if(is_file(path)){ read_file(fs,path); return; }
  DIR *d=opendir(path); if(!d) return; struct dirent *e;
  while((e=readdir(d))){ if(e->d_name[0]=='.'||!strcmp(e->d_name,"vendor")) continue; char *p=xasprintf("%s/%s",path,e->d_name); if(is_dir(p)) walk(fs,p); else read_file(fs,p); free(p); }
  closedir(d);
}
static void collect_arg(Files *fs,const char *arg){
  if(!strcmp(arg,"all")) { walk(fs,"."); return; }
  size_t n=strlen(arg);
  if(n>=4 && !strcmp(arg+n-4,"/...")){ char *p=strdup(arg); p[n-4]=0; if(!*p) strcpy(p,"."); walk(fs,p); free(p); return; }
  walk(fs,arg);
}

static char *strip_comments(char *s){
  bool inq=false; char q=0;
  for(int i=0;s[i];i++){
    if(inq){ if(s[i]=='\\'&&s[i+1]) i++; else if(s[i]==q) inq=false; }
    else if(s[i]=='"'||s[i]=='`'||s[i]=='\''){inq=true;q=s[i];}
    else if(s[i]=='/'&&s[i+1]=='/'){s[i]=0;break;}
  }
  return s;
}
static bool returns_error(const char *sig){
  const char *b=strchr(sig,'{'); size_t n=b?(size_t)(b-sig):strlen(sig); char *tmp=strndup(sig,n);
  bool ok=false; char *p=strstr(tmp,")"); if(p){ p++; while(isspace((unsigned char)*p))p++; if(starts(p,"error")||strstr(p,", error")||strstr(p," error,")||strstr(p,"\terror")||strstr(p,") (")||strstr(p,")(")) ok=strstr(p,"error")!=NULL; }
  free(tmp); return ok;
}
static void collect_imports_and_funcs(Files *fs){
  for(int fi=0;fi<fs->n;fi++){
    GoFile *gf=&fs->v[fi]; bool inimp=false;
    for(int l=0;l<gf->nlines;l++){
      char *buf=strdup(gf->lines[l]); char *t=trim(strip_comments(buf));
      if(starts(t,"import (")){inimp=true; free(buf); continue;}
      if(inimp && starts(t,")")){inimp=false; free(buf); continue;}
      if(starts(t,"import ")||inimp){
        char alias[128]="", path[256]=""; char *q=strchr(t,'"');
        if(q){ char *r=strchr(q+1,'"'); if(r){ snprintf(path,sizeof(path),"%.*s",(int)(r-q-1),q+1); char pre[128]=""; snprintf(pre,sizeof(pre),"%.*s",(int)(q-t),t); char *pt=trim(pre); if(starts(pt,"import")) pt=trim(pt+6); if(*pt && strcmp(pt,".")&&strcmp(pt,"_")) strncpy(alias,pt,127); else { char *slash=strrchr(path,'/'); strncpy(alias,slash?slash+1:path,127); } strncpy(gf->imports[gf->nimports].alias,alias,127); strncpy(gf->imports[gf->nimports].path,path,255); gf->nimports++; }}
      }
      if(starts(t,"func ")&&returns_error(t)){
        char *p=t+5; if(*p=='('){ char *rp=strchr(p,')'); if(rp){ p=trim(rp+1); char name[256]=""; int k=0; while((isalnum((unsigned char)*p)||*p=='_')&&k<255) name[k++]=*p++; name[k]=0; if(*name){ add_str(&method_funcs,name); add_str(&funcs,name); }}}
        else { char name[256]=""; int k=0; while((isalnum((unsigned char)*p)||*p=='_')&&k<255) name[k++]=*p++; name[k]=0; if(*name) add_str(&funcs,name); }
      }
      free(buf);
    }
  }
}

static const char *import_path(GoFile *gf,const char *alias){ for(int i=0;i<gf->nimports;i++) if(!strcmp(gf->imports[i].alias,alias)) return gf->imports[i].path; return alias; }
static bool ignored_name(const char *pkg,const char *name,const char *full){
  if(has_str(&excludes,full)||has_str(&excludes,name)) return true;
  if(pkg && has_str(&ignorepkgs,pkg)) return true;
  for(int i=0;i<nignores;i++) if((!ignores[i].pkg[0]||(pkg&&!strcmp(ignores[i].pkg,pkg))) && ignores[i].has_re && regexec(&ignores[i].re,name,0,NULL,0)==0) return true;
  return false;
}
static bool known_std_error(const char *pkg,const char *name){
  const char *os[]={"Chdir","Chmod","Chown","Chtimes","Mkdir","MkdirAll","Remove","RemoveAll","Rename","Setenv","Unsetenv","Symlink","Link","Truncate","WriteFile","ReadFile","Open","OpenFile","Create","Getwd","UserHomeDir","UserCacheDir","UserConfigDir",NULL};
  const char *io[]={"Copy","CopyN","ReadAll","ReadAtLeast","ReadFull","WriteString",NULL};
  const char *json[]={"Marshal","MarshalIndent","Unmarshal","NewEncoder","NewDecoder",NULL};
  const char *strconv[]={"Atoi","ParseBool","ParseFloat","ParseInt","ParseUint","Unquote",NULL};
  const char *http[]={"Get","Post","PostForm","Head","ListenAndServe","ListenAndServeTLS","Serve","ServeTLS",NULL};
  const char **arr=NULL;
  if(!strcmp(pkg,"os")) arr=os; else if(!strcmp(pkg,"io")||!strcmp(pkg,"io/ioutil")) arr=io; else if(!strcmp(pkg,"encoding/json")) arr=json; else if(!strcmp(pkg,"strconv")) arr=strconv; else if(!strcmp(pkg,"net/http")) arr=http;
  if(!arr) return false;
  for(int i=0;arr[i];i++) if(!strcmp(arr[i],name)) return true;
  return false;
}
static bool known_error_method(const char *name){
  const char *m[]={"Close","Write","WriteString","WriteTo","Read","ReadFrom","ReadAt","WriteAt","Seek","Sync","Flush","Run","Start","Wait","Kill","Signal","Encode","Decode","Scan","Commit","Rollback","Ping","Exec","Query","QueryRow","Send","Recv",NULL};
  for(int i=0;m[i];i++) if(!strcmp(m[i],name)) return true;
  return false;
}
static bool call_returns_error(GoFile *gf,const char *callee,char *full_out,size_t outsz){
  char left[256]="", name[256]=""; const char *dot=strrchr(callee,'.');
  if(dot){ snprintf(left,sizeof(left),"%.*s",(int)(dot-callee),callee); strncpy(name,dot+1,255); const char *pkg=import_path(gf,left); snprintf(full_out,outsz,"%s.%s",pkg,name); if(ignored_name(pkg,name,full_out)) return false; if(known_std_error(pkg,name)) return true; if(has_str(&method_funcs,name)||known_error_method(name)) return true; return false; }
  strncpy(name,callee,255); snprintf(full_out,outsz,"%s",name); if(ignored_name(NULL,name,full_out)) return false; return has_str(&funcs,name);
}

static bool is_ident_char(char c){ return isalnum((unsigned char)c)||c=='_'||c=='.'; }
static void report(GoFile *gf,int line,int col,const char *expr){
  char pathbuf[PATH_MAX]; const char *p=gf->path;
  if(opt_abspath && realpath(gf->path,pathbuf)) p=pathbuf;
  char *msg=xasprintf("%s:%d:%d:\t%s",p,line,col,expr); add_str(&findings,msg); free(msg);
}
static void analyze_line(GoFile *gf,int li){
  char *buf=strdup(gf->lines[li]); char *s=trim(strip_comments(buf)); if(!*s){free(buf);return;}
  if(starts(s,"func ")||starts(s,"if ")||starts(s,"for ")||starts(s,"switch ")||starts(s,"select ")||starts(s,"return ")) { free(buf); return; }
  bool assignment=strstr(s,":=")||strchr(s,'=');
  if(assignment){
    if(opt_blank){
      char *eq=strstr(s,":="); if(!eq) eq=strchr(s,'=');
      char lhs[512]; snprintf(lhs,sizeof(lhs),"%.*s",(int)(eq-s),s);
      if(strstr(lhs,"_")){
        char *rp=strrchr(eq,')'); if(rp){ char *lp=rp; int depth=0; while(lp>=eq){ if(*lp==')') depth++; else if(*lp=='(' && --depth==0) break; lp--; } if(lp>eq){ char cal[256]; char *q=lp-1; while(q>=eq&&isspace((unsigned char)*q))q--; char *end=q; while(q>=eq&&is_ident_char(*q))q--; snprintf(cal,sizeof(cal),"%.*s",(int)(end-q),q+1); char full[512]; if(call_returns_error(gf,cal,full,sizeof(full))) report(gf,li+1,(int)(lp-buf+1),s); }}
      }
    }
    free(buf); return;
  }
  if(opt_asserts && strstr(s,".(")){ report(gf,li+1,(int)(s-buf+1),s); free(buf); return; }
  char *lp=strchr(s,'('); if(!lp){free(buf);return;}
  char *q=lp-1; while(q>=s&&isspace((unsigned char)*q))q--; char *end=q; while(q>=s&&is_ident_char(*q))q--; q++;
  if(end<q){free(buf);return;} char cal[256]; snprintf(cal,sizeof(cal),"%.*s",(int)(end-q+1),q);
  if(!strcmp(cal,"make")||!strcmp(cal,"new")||!strcmp(cal,"panic")||!strcmp(cal,"println")||!strcmp(cal,"print")){free(buf);return;}
  char full[512]; if(call_returns_error(gf,cal,full,sizeof(full))) report(gf,li+1,(int)(q-buf+1),s);
  free(buf);
}

int main(int argc,char **argv){
  Strs args={0};
  for(int i=1;i<argc;i++){
    char *a=argv[i];
    if(!strcmp(a,"-h")||!strcmp(a,"--help")){ usage(stderr,argv[0]); return 2; }
    else if(!strcmp(a,"-abspath")) opt_abspath=true; else if(!strcmp(a,"-asserts")) opt_asserts=true; else if(!strcmp(a,"-blank")) opt_blank=true;
    else if(!strcmp(a,"-excludeonly")) opt_excludeonly=true; else if(!strcmp(a,"-ignoregenerated")) opt_ignoregenerated=true; else if(!strcmp(a,"-ignoretests")) opt_ignoretests=true; else if(!strcmp(a,"-verbose")) opt_verbose=true;
    else if(!strcmp(a,"-exclude")||!strcmp(a,"-mod")||!strcmp(a,"-tags")||!strcmp(a,"-ignore")||!strcmp(a,"-ignorepkg")){
      if(i+1>=argc){ fprintf(stderr,"flag needs an argument: %s\n",a); usage(stderr,argv[0]); return 2; }
      char *v=argv[++i];
      if(!strcmp(a,"-exclude")) opt_exclude=v; else if(!strcmp(a,"-mod")) opt_mod=v; else if(!strcmp(a,"-tags")) opt_tags=v; else if(!strcmp(a,"-ignore")){ char *c=strdup(v); parse_ignore(c); free(c); } else { char *c=strdup(v); parse_ignorepkg(c); free(c); }
    } else if(a[0]=='-'){ fprintf(stderr,"flag provided but not defined: %s\n",a); usage(stderr,argv[0]); return 2; }
    else add_str(&args,a);
  }
  (void)opt_mod; (void)opt_tags; if(!opt_excludeonly) default_excludes(); if(opt_exclude) load_exclude(opt_exclude);
  if(args.n==0) add_str(&args,".");
  Files fs={0}; for(int i=0;i<args.n;i++) collect_arg(&fs,args.v[i]);
  if(fs.n==0){ fprintf(stderr,"error: failed to check packages: no go files to check\n"); return 2; }
  collect_imports_and_funcs(&fs);
  for(int i=0;i<fs.n;i++) for(int l=0;l<fs.v[i].nlines;l++) analyze_line(&fs.v[i],l);
  for(int i=0;i<findings.n;i++) puts(findings.v[i]);
  return findings.n?1:0;
}
