#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    bool valid;
    uint32_t footer_len;
    int32_t version;
    int64_t rows;
    char created_by[256];
    char columns[64][128];
    size_t column_count;
    char error[160];
} ParquetInfo;

typedef struct {
    const unsigned char *p;
    const unsigned char *end;
    ParquetInfo *info;
} Reader;

static void print_help(void) {
    puts("Command line tool to visualize parquet files\n");
    puts("Usage: executable <PATH>\n");
    puts("Arguments:");
    puts("  <PATH>  Path to the parquet file\n");
    puts("Options:");
    puts("  -h, --help     Print help");
    puts("  -V, --version  Print version");
}

static void print_version(void) {
    puts("parqeye 0.0.2");
}

static void usage_tail(void) {
    fputs("Usage: executable <PATH>\n\nFor more information, try '--help'.\n", stderr);
}

static bool starts_with_dash(const char *s) {
    return s && s[0] == '-' && s[1] != '\0';
}

static void unexpected_arg(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    if (starts_with_dash(arg)) {
        fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    }
    usage_tail();
}

static void missing_path(void) {
    fputs("error: the following required arguments were not provided:\n  <PATH>\n", stderr);
    fputc('\n', stderr);
    usage_tail();
}

static void panic_no_tty(void) {
    fprintf(stderr,
            "\nthread 'main' (%ld) panicked at "
            "/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/"
            "ratatui-0.29.0/src/terminal/init.rs:52:16:\n"
            "failed to initialize terminal: Os { code: 6, kind: Uncategorized, "
            "message: \"No such device or address\" }\n"
            "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n"
            "\033[?1049l\n",
            (long)getpid());
}

static uint32_t le32(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static bool read_uvar(Reader *r, uint64_t *out) {
    uint64_t result = 0;
    unsigned shift = 0;
    while (r->p < r->end && shift < 64) {
        unsigned char b = *r->p++;
        result |= (uint64_t)(b & 0x7f) << shift;
        if (!(b & 0x80)) {
            *out = result;
            return true;
        }
        shift += 7;
    }
    return false;
}

static int64_t zigzag(uint64_t n) {
    return (int64_t)((n >> 1) ^ (uint64_t)-(int64_t)(n & 1));
}

static bool read_i64(Reader *r, int64_t *out) {
    uint64_t u;
    if (!read_uvar(r, &u)) return false;
    *out = zigzag(u);
    return true;
}

static bool read_bytes(Reader *r, const unsigned char **p, uint64_t *len) {
    if (!read_uvar(r, len)) return false;
    if ((uint64_t)(r->end - r->p) < *len) return false;
    *p = r->p;
    r->p += *len;
    return true;
}

static bool skip_type(Reader *r, unsigned type);

static bool skip_collection(Reader *r, unsigned elem_type, uint64_t n) {
    for (uint64_t i = 0; i < n; i++) {
        if (!skip_type(r, elem_type)) return false;
    }
    return true;
}

static bool skip_type(Reader *r, unsigned type) {
    uint64_t len;
    const unsigned char *tmp;
    switch (type) {
        case 0: return true;
        case 1: return true;
        case 2: return true;
        case 3: return r->p++ < r->end;
        case 4: return r->p + 1 <= r->end ? (r->p += 1, true) : false;
        case 5: return read_uvar(r, &len);
        case 6: return r->p + 8 <= r->end ? (r->p += 8, true) : false;
        case 7: return r->p + 4 <= r->end ? (r->p += 4, true) : false;
        case 8: return read_bytes(r, &tmp, &len);
        case 9: {
            if (r->p >= r->end) return false;
            unsigned char h = *r->p++;
            uint64_t n = h >> 4;
            unsigned et = h & 0x0f;
            if (n == 15 && !read_uvar(r, &n)) return false;
            return skip_collection(r, et, n);
        }
        case 10: {
            if (r->p >= r->end) return false;
            unsigned char h = *r->p++;
            uint64_t n = h >> 4;
            unsigned kt = h & 0x0f;
            unsigned vt = *r->p++ & 0x0f;
            if (n == 15 && !read_uvar(r, &n)) return false;
            for (uint64_t i = 0; i < n; i++) {
                if (!skip_type(r, kt) || !skip_type(r, vt)) return false;
            }
            return true;
        }
        case 12: {
            int last = 0;
            while (r->p < r->end) {
                unsigned char h = *r->p++;
                if (h == 0) return true;
                unsigned t = h & 0x0f;
                if ((h >> 4) == 0) {
                    uint64_t ignored;
                    if (!read_uvar(r, &ignored)) return false;
                } else {
                    last += h >> 4;
                    (void)last;
                }
                if (!skip_type(r, t)) return false;
            }
            return false;
        }
        default:
            return false;
    }
}

static bool parse_schema_element(Reader *r) {
    int last = 0;
    char name[128] = "";
    int64_t type = -1;
    while (r->p < r->end) {
        unsigned char h = *r->p++;
        if (h == 0) {
            if (name[0] && type >= 0 && r->info->column_count < 64) {
                snprintf(r->info->columns[r->info->column_count++], 128, "%s", name);
            }
            return true;
        }
        unsigned ftype = h & 0x0f;
        int field;
        if ((h >> 4) == 0) {
            uint64_t u;
            if (!read_uvar(r, &u)) return false;
            field = (int)zigzag(u);
        } else {
            field = last + (h >> 4);
        }
        last = field;
        if (field == 1 && ftype == 5) {
            if (!read_i64(r, &type)) return false;
        } else if (field == 4 && ftype == 8) {
            const unsigned char *p;
            uint64_t len;
            if (!read_bytes(r, &p, &len)) return false;
            size_t n = len < sizeof(name) - 1 ? (size_t)len : sizeof(name) - 1;
            memcpy(name, p, n);
            name[n] = '\0';
        } else if (!skip_type(r, ftype)) {
            return false;
        }
    }
    return false;
}

static bool parse_file_metadata(Reader *r) {
    int last = 0;
    while (r->p < r->end) {
        unsigned char h = *r->p++;
        if (h == 0) return true;
        unsigned ftype = h & 0x0f;
        int field;
        if ((h >> 4) == 0) {
            uint64_t u;
            if (!read_uvar(r, &u)) return false;
            field = (int)zigzag(u);
        } else {
            field = last + (h >> 4);
        }
        last = field;

        if (field == 1 && ftype == 5) {
            int64_t v;
            if (!read_i64(r, &v)) return false;
            r->info->version = (int32_t)v;
        } else if (field == 2 && ftype == 9) {
            if (r->p >= r->end) return false;
            unsigned char lh = *r->p++;
            uint64_t n = lh >> 4;
            unsigned et = lh & 0x0f;
            if (n == 15 && !read_uvar(r, &n)) return false;
            if (et != 12) return skip_collection(r, et, n);
            for (uint64_t i = 0; i < n; i++) {
                if (!parse_schema_element(r)) return false;
            }
        } else if (field == 3 && (ftype == 5 || ftype == 6)) {
            if (!read_i64(r, &r->info->rows)) return false;
        } else if (field == 6 && ftype == 8) {
            const unsigned char *p;
            uint64_t len;
            if (!read_bytes(r, &p, &len)) return false;
            size_t n = len < sizeof(r->info->created_by) - 1 ? (size_t)len : sizeof(r->info->created_by) - 1;
            memcpy(r->info->created_by, p, n);
            r->info->created_by[n] = '\0';
        } else if (!skip_type(r, ftype)) {
            return false;
        }
    }
    return false;
}

static ParquetInfo inspect_parquet(const char *path, off_t *size_out) {
    ParquetInfo info;
    memset(&info, 0, sizeof(info));
    info.version = -1;
    info.rows = -1;
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        snprintf(info.error, sizeof(info.error), "%s", strerror(errno));
        return info;
    }
    struct stat st;
    if (fstat(fd, &st) != 0) {
        snprintf(info.error, sizeof(info.error), "%s", strerror(errno));
        close(fd);
        return info;
    }
    if (size_out) *size_out = st.st_size;
    if (st.st_size < 12) {
        snprintf(info.error, sizeof(info.error), "file is too small to be a parquet file");
        close(fd);
        return info;
    }
    unsigned char tail[8], head[4];
    if (pread(fd, head, 4, 0) != 4 || pread(fd, tail, 8, st.st_size - 8) != 8) {
        snprintf(info.error, sizeof(info.error), "%s", strerror(errno));
        close(fd);
        return info;
    }
    if (memcmp(head, "PAR1", 4) != 0 || memcmp(tail + 4, "PAR1", 4) != 0) {
        snprintf(info.error, sizeof(info.error), "invalid parquet magic bytes");
        close(fd);
        return info;
    }
    info.footer_len = le32(tail);
    if ((uint64_t)info.footer_len > (uint64_t)st.st_size - 8) {
        snprintf(info.error, sizeof(info.error), "invalid parquet footer length");
        close(fd);
        return info;
    }
    unsigned char *footer = malloc(info.footer_len ? info.footer_len : 1);
    if (!footer) {
        snprintf(info.error, sizeof(info.error), "out of memory");
        close(fd);
        return info;
    }
    if (pread(fd, footer, info.footer_len, st.st_size - 8 - info.footer_len) != (ssize_t)info.footer_len) {
        snprintf(info.error, sizeof(info.error), "%s", strerror(errno));
        free(footer);
        close(fd);
        return info;
    }
    Reader r = { footer, footer + info.footer_len, &info };
    if (!parse_file_metadata(&r)) {
        snprintf(info.error, sizeof(info.error), "could not decode parquet metadata");
    } else {
        info.valid = true;
    }
    free(footer);
    close(fd);
    return info;
}

static void ansi_printf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
}

static void render_screen(const char *path, const ParquetInfo *info, off_t size) {
    ansi_printf("\033[2J\033[H");
    ansi_printf("parqeye 0.0.2\n");
    ansi_printf("[Visualize]  Schema  Metadata  Row Groups\n\n");
    ansi_printf("File: %s\n", path);
    ansi_printf("Size: %jd bytes\n", (intmax_t)size);
    if (!info->valid) {
        ansi_printf("\nError: %s\n", info->error[0] ? info->error : "unable to inspect parquet file");
    } else {
        ansi_printf("Rows: %" PRId64 "\n", info->rows);
        ansi_printf("Parquet version: %d\n", info->version);
        ansi_printf("Footer length: %u bytes\n", info->footer_len);
        if (info->created_by[0]) ansi_printf("Created by: %s\n", info->created_by);
        ansi_printf("\nColumns\n");
        if (info->column_count == 0) {
            ansi_printf("  (schema unavailable)\n");
        } else {
            for (size_t i = 0; i < info->column_count && i < 20; i++) {
                ansi_printf("  %zu. %s\n", i + 1, info->columns[i]);
            }
            if (info->column_count > 20) ansi_printf("  ...\n");
        }
    }
    ansi_printf("\nPress q or Esc to quit.");
    fflush(stdout);
}

static int interactive(const char *path) {
    off_t size = 0;
    ParquetInfo info = inspect_parquet(path, &size);
    struct termios oldt, raw;
    bool raw_set = false;
    if (isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &oldt) == 0) {
        raw = oldt;
        raw.c_lflag &= (tcflag_t)~(ECHO | ICANON);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 1;
        raw_set = tcsetattr(STDIN_FILENO, TCSANOW, &raw) == 0;
    }
    ansi_printf("\033[?1049h\033[?25l");
    render_screen(path, &info, size);
    for (;;) {
        unsigned char ch;
        ssize_t n = read(STDIN_FILENO, &ch, 1);
        if (n == 1 && (ch == 'q' || ch == 'Q' || ch == 27 || ch == 3 || ch == 4)) break;
        if (n < 0 && errno != EAGAIN && errno != EINTR) break;
    }
    ansi_printf("\033[?25h\033[?1049l");
    fflush(stdout);
    if (raw_set) tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return 0;
}

int main(int argc, char **argv) {
    bool end_opts = false;
    const char *path = NULL;
    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (!end_opts && strcmp(arg, "--") == 0) {
            end_opts = true;
            continue;
        }
        if (!end_opts && (strcmp(arg, "-h") == 0 || strcmp(arg, "--help") == 0)) {
            print_help();
            return 0;
        }
        if (!end_opts && (strcmp(arg, "-V") == 0 || strcmp(arg, "--version") == 0)) {
            print_version();
            return 0;
        }
        if (!end_opts && starts_with_dash(arg)) {
            unexpected_arg(arg);
            return 2;
        }
        if (!path) {
            path = arg;
        } else {
            unexpected_arg(arg);
            return 2;
        }
    }
    if (!path) {
        missing_path();
        return 2;
    }
    if (!isatty(STDOUT_FILENO)) {
        panic_no_tty();
        return 101;
    }
    return interactive(path);
}
