#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX(a,b) ((a)>(b)?(a):(b))

typedef struct { char *s; int is_num, is_null; } Value;
typedef struct { Value *v; } Row;
typedef struct { char **cols; int ncols; Row *rows; int nrows, cap; char *name; } Table;
typedef struct { char *name; int table; int col; char *out; } Expr;

static char *xstrdup(const char *s){ if(!s) s=""; char *p=malloc(strlen(s)+1); if(!p){perror("malloc"); exit(1);} strcpy(p,s); return p; }
static char *xstrndup(const char *s,size_t n){ char *p=malloc(n+1); if(!p){perror("malloc"); exit(1);} memcpy(p,s,n); p[n]=0; return p; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }
static int ieq(const char*a,const char*b){ for(;*a&&*b;a++,b++) if(tolower((unsigned char)*a)!=tolower((unsigned char)*b)) return 0; return *a==0&&*b==0; }
static int istarts(const char*s,const char*p){ while(*p){ if(tolower((unsigned char)*s++)!=tolower((unsigned char)*p++)) return 0; } return 1; }
static char *istrstr(const char *h,const char *n){ size_t nl=strlen(n); for(;*h;h++) if(strncasecmp(h,n,nl)==0) return (char*)h; return NULL; }
static int is_number_str(const char *s){ if(!s||!*s) return 0; char *e; strtod(s,&e); return *trim(e)==0; }
static void val_free(Value v){ free(v.s); }
static Value make_val(const char*s,int is_num,int is_null){ Value v; v.s=xstrdup(s?s:""); v.is_num=is_num; v.is_null=is_null; return v; }

static void table_init(Table*t){ memset(t,0,sizeof(*t)); }
static void table_add_row(Table*t, Value *vals){ if(t->nrows==t->cap){ t->cap=t->cap? t->cap*2:16; t->rows=realloc(t->rows,t->cap*sizeof(Row)); if(!t->rows){perror("realloc");exit(1);} } t->rows[t->nrows++].v=vals; }
static int col_index(Table*t,const char*name){ for(int i=0;i<t->ncols;i++) if(ieq(t->cols[i],name)) return i; return -1; }
static void add_col(Table*t,const char*name){ t->cols=realloc(t->cols,(t->ncols+1)*sizeof(char*)); t->cols[t->ncols++]=xstrdup(name); for(int r=0;r<t->nrows;r++){ t->rows[r].v=realloc(t->rows[r].v,t->ncols*sizeof(Value)); t->rows[r].v[t->ncols-1]=make_val("",0,1); } }

static char *read_all(FILE*f){ size_t cap=4096,n=0; char *buf=malloc(cap+1); if(!buf) exit(1); int c; while((c=fgetc(f))!=EOF){ if(n+1>=cap){cap*=2; buf=realloc(buf,cap+1); if(!buf) exit(1);} buf[n++]=(char)c;} buf[n]=0; return buf; }
static char *read_file(const char*path){ FILE*f=fopen(path,"rb"); if(!f){ fprintf(stderr,"open %s: %s\n",path,strerror(errno)); exit(1);} char*b=read_all(f); fclose(f); return b; }

static char **parse_csv_line(const char *line, int *outn, char sep){ int cap=8,n=0; char **arr=malloc(cap*sizeof(char*)); const char*p=line; while(1){ if(n==cap){cap*=2; arr=realloc(arr,cap*sizeof(char*));} size_t bc=64,bl=0; char *b=malloc(bc); int quoted=0; if(*p=='"'){ quoted=1; p++; }
  while(*p){ char ch=*p; if(quoted){ if(ch=='"'){ if(p[1]=='"'){ ch='"'; p+=2; } else { p++; quoted=0; continue; } } else p++; } else { if(ch==sep){ p++; break; } if(ch=='\r'||ch=='\n'){ while(*p=='\r'||*p=='\n') p++; break; } p++; }
    if(bl+1>=bc){bc*=2;b=realloc(b,bc);} b[bl++]=ch; }
  b[bl]=0; arr[n++]=b; if(!*p) break; }
 *outn=n; return arr; }
static void free_fields(char**f,int n){ for(int i=0;i<n;i++) free(f[i]); free(f); }

static Table load_delim_text(const char*content,char sep,const char*name){ Table t; table_init(&t); t.name=xstrdup(name?name:"{0}"); char *buf=xstrdup(content), *save=NULL, *line=strtok_r(buf,"\n",&save); if(!line){ free(buf); return t; } if(strlen(line)&&line[strlen(line)-1]=='\r') line[strlen(line)-1]=0; int hn=0; char **h=parse_csv_line(line,&hn,sep); t.ncols=hn; t.cols=malloc(hn*sizeof(char*)); for(int i=0;i<hn;i++) t.cols[i]=xstrdup(trim(h[i])); free_fields(h,hn);
 while((line=strtok_r(NULL,"\n",&save))){ if(strlen(line)&&line[strlen(line)-1]=='\r') line[strlen(line)-1]=0; if(!*line) continue; int n=0; char **f=parse_csv_line(line,&n,sep); Value *vals=calloc(t.ncols,sizeof(Value)); for(int i=0;i<t.ncols;i++) vals[i]=make_val(i<n?f[i]:"",0,0); table_add_row(&t,vals); free_fields(f,n); } free(buf); return t; }

static void skip_ws(const char **p){ while(isspace((unsigned char)**p)) (*p)++; }
static char *json_string(const char **p){ if(**p!='"') return NULL; (*p)++; size_t cap=64,n=0; char*b=malloc(cap); while(**p && **p!='"'){ char c=*(*p)++; if(c=='\\'){ c=*(*p)++; if(c=='n') c='\n'; else if(c=='t') c='\t'; else if(c=='r') c='\r'; } if(n+1>=cap){cap*=2;b=realloc(b,cap);} b[n++]=c; } if(**p=='"') (*p)++; b[n]=0; return b; }
static char *json_atom(const char **p,int *isnum,int *isnull){ skip_ws(p); if(**p=='"'){ *isnum=0; *isnull=0; return json_string(p);} const char*s=*p; while(**p && !strchr(",}\n\r\t ]",**p)) (*p)++; char *a=xstrndup(s,*p-s); char *tr=trim(a); char *ret=xstrdup(tr); free(a); *isnull=ieq(ret,"null"); *isnum=is_number_str(ret); return ret; }
static void parse_json_object(Table*t,const char **p){ skip_ws(p); if(**p!='{') return; (*p)++; Value *vals= t->ncols? calloc(t->ncols,sizeof(Value)):NULL; for(int i=0;i<t->ncols;i++) vals[i]=make_val("",0,1); while(**p){ skip_ws(p); if(**p=='}'){(*p)++; break;} char *key=json_string(p); skip_ws(p); if(**p==':') (*p)++; int isn=0,isnull=0; char *val=json_atom(p,&isn,&isnull); int ci=col_index(t,key); if(ci<0){ add_col(t,key); ci=t->ncols-1; vals=realloc(vals,t->ncols*sizeof(Value)); vals[ci]=make_val("",0,1); }
 val_free(vals[ci]); vals[ci]=make_val(val,isn,isnull); free(key); free(val); skip_ws(p); if(**p==',') (*p)++; }
 if(vals) table_add_row(t,vals); }
static Table load_json_text(const char*content,const char*name){ Table t; table_init(&t); t.name=xstrdup(name?name:"{0}"); const char*p=content; skip_ws(&p); if(*p=='['){ p++; while(*p){ skip_ws(&p); if(*p==']') break; parse_json_object(&t,&p); skip_ws(&p); if(*p==',') p++; } } else { while(*p){ skip_ws(&p); if(*p=='{') parse_json_object(&t,&p); while(*p && *p!='\n' && *p!='{') p++; } } return t; }
static const char *ext(const char*path){ const char*s=strrchr(path,'.'); return s?s+1:""; }
static Table load_path(const char*path){ char *c=read_file(path); Table t; const char*e=ext(path); if(ieq(e,"tsv")) t=load_delim_text(c,'\t',path); else if(ieq(e,"json")||ieq(e,"ndjson")||ieq(e,"jsonl")) t=load_json_text(c,path); else if(ieq(e,"csv")||ieq(e,"txt")||ieq(e,"logfmt")||!*e) t=load_delim_text(c,',',path); else { fprintf(stderr,"Unknown mimetype for file: %s.\n",path); exit(1);} free(c); return t; }

static void json_escape_print(const char*s){ putchar('"'); for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\') printf("\\%c",c); else if(c=='\n') printf("\\n"); else if(c=='\t') printf("\\t"); else if(c<32) printf("\\u%04x",c); else putchar(c);} putchar('"'); }
static void print_val(Value v){ if(v.is_null) printf("null"); else if(v.is_num) printf("%s",v.s); else json_escape_print(v.s); }

static char *clean_ident(char*s){ s=trim(s); if(*s=='"'||*s=='`'||*s=='['){ char q=*s, end=(q=='['?']':q); s++; char*e=strrchr(s,end); if(e)*e=0; } if(strncmp(s,"{0}.",4)==0||strncmp(s,"{1}.",4)==0) s+=4; return trim(s); }
static int parse_table_ref(char **ps){ char*s=trim(*ps); if(strncmp(s,"{0}.",4)==0){*ps=s+4;return 0;} if(strncmp(s,"{1}.",4)==0){*ps=s+4;return 1;} return -1; }

typedef struct { int has; int table; char col[128], op[4], val[256]; int valnum; } Where;
static int value_cmp(Value v,const char*op,const char*rhs,int rhsnum){ if(v.is_null) return 0; int cmp=0; if(v.is_num||rhsnum||is_number_str(v.s)){ double a=strtod(v.s,NULL), b=strtod(rhs,NULL); cmp=(a>b)-(a<b); } else cmp=strcmp(v.s,rhs); if(strcmp(op,"=")==0||strcmp(op,"==")==0) return cmp==0; if(strcmp(op,"!=")==0||strcmp(op,"<>")==0) return cmp!=0; if(strcmp(op,">")==0) return cmp>0; if(strcmp(op,"<")==0) return cmp<0; if(strcmp(op,">=")==0) return cmp>=0; if(strcmp(op,"<=")==0) return cmp<=0; return 1; }
static int row_where(Table*t,Row*r,Where*w){ if(!w->has) return 1; int ci=col_index(t,w->col); if(ci<0) return 0; return value_cmp(r->v[ci],w->op,w->val,w->valnum); }

static void parse_where(char *s, Where*w){ memset(w,0,sizeof(*w)); if(!s) return; char *ops[]={">=","<=","!=","<>","=",">","<",NULL}; for(int i=0;ops[i];i++){ char *p=strstr(s,ops[i]); if(p){ *p=0; char *lhs=clean_ident(s); char *rhs=trim(p+strlen(ops[i])); if(*rhs=='\''||*rhs=='"'){ char q=*rhs++; char*e=strrchr(rhs,q); if(e)*e=0; } strncpy(w->col,lhs,sizeof(w->col)-1); strncpy(w->op,ops[i],sizeof(w->op)-1); strncpy(w->val,rhs,sizeof(w->val)-1); w->valnum=is_number_str(rhs); w->has=1; return; } } }

static int split_select(char *sel, Expr **out, Table*t0, Table*t1){ int cap=8,n=0; Expr*e=calloc(cap,sizeof(Expr)); char *save=NULL,*tok=strtok_r(sel,",",&save); while(tok){ if(n==cap){cap*=2;e=realloc(e,cap*sizeof(Expr));} char *x=trim(tok); char *as=istrstr(x," as "); char *outn=NULL; if(as){ *as=0; outn=trim(as+4); } char *ci=x; int tr=parse_table_ref(&ci); ci=clean_ident(ci); e[n].table=tr<0?0:tr; e[n].name=xstrdup(ci); e[n].col=(e[n].table==0?col_index(t0,ci):col_index(t1,ci)); e[n].out=xstrdup(outn?clean_ident(outn):ci); n++; tok=strtok_r(NULL,",",&save); } *out=e; return n; }

static void output_json(Table*t, int *idx, int n, Expr*expr, int nexpr){ printf("["); for(int ii=0;ii<n;ii++){ if(ii) printf(",\n"); Row*r=&t->rows[idx[ii]]; printf("{"); for(int j=0;j<nexpr;j++){ if(j) printf(","); json_escape_print(expr[j].out); printf(":"); int ci=expr[j].col; if(ci>=0 && ci<t->ncols) print_val(r->v[ci]); else printf("null"); } printf("}"); } printf("]\n"); }
static void output_json_all(Table*t,int pretty){ int *idx=malloc(MAX(1,t->nrows)*sizeof(int)); for(int i=0;i<t->nrows;i++) idx[i]=i; Expr *e=calloc(t->ncols,sizeof(Expr)); for(int i=0;i<t->ncols;i++){ e[i].col=i; e[i].out=t->cols[i]; } if(!pretty) output_json(t,idx,t->nrows,e,t->ncols); free(e); free(idx); }

static void output_pretty(Table*t,int*idx,int n,Expr*e,int ne){ int *w=calloc(ne,sizeof(int)); for(int j=0;j<ne;j++) w[j]=strlen(e[j].out); for(int i=0;i<n;i++) for(int j=0;j<ne;j++){ int ci=e[j].col; if(ci>=0) w[j]=MAX(w[j],(int)strlen(t->rows[idx[i]].v[ci].s)); }
 void sep(){ putchar('+'); for(int j=0;j<ne;j++){ for(int k=0;k<w[j]+2;k++) putchar('-'); putchar('+'); } putchar('\n'); }
 sep(); putchar('|'); for(int j=0;j<ne;j++) printf(" %-*s |",w[j],e[j].out); putchar('\n'); sep(); for(int i=0;i<n;i++){ putchar('|'); for(int j=0;j<ne;j++){ int ci=e[j].col; char*s=(ci>=0?t->rows[idx[i]].v[ci].s:""); if(is_number_str(s)) printf(" %*s |",w[j],s); else printf(" %-*s |",w[j],s); } putchar('\n'); } sep(); printf("(%d %s)\n",n,n==1?"row":"rows"); free(w); }

static int g_order_col=-1,g_desc=0; static Table*g_sort_table=NULL;
static int cmp_idx(const void*a,const void*b){ int ia=*(int*)a, ib=*(int*)b; Value va=g_sort_table->rows[ia].v[g_order_col], vb=g_sort_table->rows[ib].v[g_order_col]; int c; if(is_number_str(va.s)&&is_number_str(vb.s)){ double da=strtod(va.s,NULL), db=strtod(vb.s,NULL); c=(da>db)-(da<db);} else c=strcmp(va.s,vb.s); return g_desc?-c:c; }

static void schema(Table*t){ printf("{\n  \"kind\": \"array\",\n  \"array\": {\n    \"kind\": \"object\",\n    \"object\": {\n"); for(int i=0;i<t->ncols;i++){ printf("      "); json_escape_print(t->cols[i]); printf(": {\n        \"kind\": \"scalar\",\n        \"scalar\": \"string\"\n      }%s\n", i==t->ncols-1?"":","); } printf("    }\n  }\n}\n"); }

static void run_query(Table*t,char*q,int pretty){ char *query=xstrdup(q?q:""); char *qq=trim(query); if(!*qq){ output_json_all(t,pretty); free(query); return; } char *from=istrstr(qq," from "); if(!from || !istarts(qq,"select ")){ output_json_all(t,pretty); free(query); return; } *from=0; char *sel=trim(qq+7); char *rest=from+6; char *wherep=istrstr(rest," where "), *orderp=istrstr(rest," order by "), *limitp=istrstr(rest," limit "), *groupp=istrstr(rest," group by ");
 char *where_txt=NULL,*order_txt=NULL,*limit_txt=NULL,*group_txt=NULL; char *cuts[]={wherep,orderp,limitp,groupp,NULL}; for(int i=0;cuts[i];i++) *cuts[i]=0; if(wherep) where_txt=wherep+7; if(orderp) order_txt=orderp+10; if(limitp) limit_txt=limitp+7; if(groupp) group_txt=groupp+10; if(where_txt){ char*e=istrstr(where_txt," order by "); if(e)*e=0; e=istrstr(where_txt," limit "); if(e)*e=0; e=istrstr(where_txt," group by "); if(e)*e=0; }
 if(order_txt){ char*e=istrstr(order_txt," limit "); if(e)*e=0; } if(group_txt){ char*e=istrstr(group_txt," order by "); if(e)*e=0; e=istrstr(group_txt," limit "); if(e)*e=0; }
 if(istrstr(sel,"count(*)") && group_txt){ char gcol[128]; strncpy(gcol,clean_ident(group_txt),127); int ci=col_index(t,gcol); printf("["); int first=1; int *used=calloc(t->nrows,sizeof(int)); for(int i=0;i<t->nrows;i++){ if(used[i]) continue; int cnt=0; for(int j=i;j<t->nrows;j++) if(ci>=0 && strcmp(t->rows[i].v[ci].s,t->rows[j].v[ci].s)==0){used[j]=1;cnt++;} if(!first) printf(",\n"); first=0; printf("{"); json_escape_print(gcol); printf(":"); print_val(t->rows[i].v[ci]); printf(",\"count(*)\":%d}",cnt); } printf("]\n"); free(used); free(query); return; }
 if(ieq(trim(sel),"count(*)")){ Where w; parse_where(where_txt,&w); int cnt=0; for(int i=0;i<t->nrows;i++) if(row_where(t,&t->rows[i],&w)) cnt++; printf("[{\"count(*)\":%d}]\n",cnt); free(query); return; }
 Expr *expr=NULL; int nexpr=0; if(strcmp(trim(sel),"*")==0){ nexpr=t->ncols; expr=calloc(nexpr,sizeof(Expr)); for(int i=0;i<nexpr;i++){expr[i].col=i; expr[i].out=xstrdup(t->cols[i]);} } else nexpr=split_select(sel,&expr,t,t);
 Where w; parse_where(where_txt,&w); int *idx=malloc(MAX(1,t->nrows)*sizeof(int)), n=0; for(int i=0;i<t->nrows;i++) if(row_where(t,&t->rows[i],&w)) idx[n++]=i; if(order_txt){ char *ot=trim(order_txt); char *sp=strchr(ot,' '); if(sp){ *sp=0; g_desc=istarts(trim(sp+1),"desc"); } else g_desc=0; g_order_col=col_index(t,clean_ident(ot)); if(g_order_col>=0){ g_sort_table=t; qsort(idx,n,sizeof(int),cmp_idx); } }
 if(limit_txt){ int lim=atoi(trim(limit_txt)); if(lim>=0 && lim<n) n=lim; }
 if(pretty) output_pretty(t,idx,n,expr,nexpr); else output_json(t,idx,n,expr,nexpr); free(idx); for(int i=0;i<nexpr;i++){free(expr[i].name); free(expr[i].out);} free(expr); free(query); }

static void run_join_query(Table *t0, Table *t1, char *q){
 char *query=xstrdup(q?q:""), *qq=trim(query);
 char *from=istrstr(qq," from "), *join=istrstr(qq," join "), *on=istrstr(qq," on ");
 if(!from || !join || !on || !istarts(qq,"select ")){ run_query(t0,q,0); free(query); return; }
 *from=0; *on=0;
 char *sel=trim(qq+7), *cond=trim(on+4), *eq=strchr(cond,'=');
 if(!eq){ run_query(t0,q,0); free(query); return; }
 *eq=0;
 char *lhs=trim(cond), *rhs=trim(eq+1);
 int lt=parse_table_ref(&lhs), rt=parse_table_ref(&rhs);
 lhs=clean_ident(lhs); rhs=clean_ident(rhs);
 if(lt<0) lt=0;
 if(rt<0) rt=1;
 int lc=lt==0 ? col_index(t0,lhs) : col_index(t1,lhs);
 int rc=rt==0 ? col_index(t0,rhs) : col_index(t1,rhs);
 Expr *expr=NULL; int nexpr=split_select(sel,&expr,t0,t1);
 printf("[");
 int first=1;
 for(int i=0;i<t0->nrows;i++) for(int j=0;j<t1->nrows;j++){
   if(lc<0 || rc<0) continue;
   Value lv=lt==0 ? t0->rows[i].v[lc] : t1->rows[j].v[lc];
   Value rv=rt==0 ? t0->rows[i].v[rc] : t1->rows[j].v[rc];
   if(strcmp(lv.s,rv.s)!=0) continue;
   if(!first) printf(",\n");
   first=0;
   printf("{");
   for(int k=0;k<nexpr;k++){
     if(k) printf(",");
     json_escape_print(expr[k].out); printf(":");
     Table *tt=expr[k].table==1?t1:t0;
     Row *rr=expr[k].table==1?&t1->rows[j]:&t0->rows[i];
     int ci=expr[k].col;
     if(ci>=0 && ci<tt->ncols) print_val(rr->v[ci]); else printf("null");
   }
   printf("}");
 }
 printf("]\n");
 for(int i=0;i<nexpr;i++){ free(expr[i].name); free(expr[i].out); }
 free(expr); free(query);
}

static void usage(void){ printf("dsq (Version latest) - commandline SQL engine for data files\n\nUsage:  dsq [file...] $query\n        dsq $file [query]\n        cat $file | dsq -s $filetype [query]\n        dsq $file -f $queryfile\n\n"); }
int main(int argc,char**argv){ int pretty=0,schema_flag=0; char *stream_fmt=NULL,*qfile=NULL; char **pos=calloc(argc,sizeof(char*)); int npos=0; for(int i=1;i<argc;i++){ if(!strcmp(argv[i],"--help")||!strcmp(argv[i],"-h")){ usage(); return 0;} else if(!strcmp(argv[i],"--version")){ printf("dsq latest\n"); return 0;} else if(!strcmp(argv[i],"-p")||!strcmp(argv[i],"--pretty")) pretty=1; else if(!strcmp(argv[i],"--schema")) schema_flag=1; else if(!strcmp(argv[i],"-C")||!strcmp(argv[i],"--cache")){} else if(!strcmp(argv[i],"-i")||!strcmp(argv[i],"--interactive")){ fprintf(stderr,"interactive mode is not available in this build\n"); return 1;} else if((!strcmp(argv[i],"-s")||!strcmp(argv[i],"--source"))&&i+1<argc) stream_fmt=argv[++i]; else if((!strcmp(argv[i],"-f")||!strcmp(argv[i],"--file"))&&i+1<argc) qfile=argv[++i]; else pos[npos++]=argv[i]; }
 Table t; Table t2; int has_t2=0; if(stream_fmt){ char*c=read_all(stdin); if(ieq(stream_fmt,"json")||ieq(stream_fmt,"ndjson")||ieq(stream_fmt,"jsonl")) t=load_json_text(c,"stdin"); else if(ieq(stream_fmt,"tsv")) t=load_delim_text(c,'\t',"stdin"); else t=load_delim_text(c,',',"stdin"); free(c); } else { if(npos<1){ usage(); return 0; } t=load_path(pos[0]); if(npos>=3){ t2=load_path(pos[1]); has_t2=1; } }
 if(schema_flag){ schema(&t); return 0; } char *query=NULL; if(qfile) query=read_file(qfile); else if(stream_fmt){ if(npos>=1) query=xstrdup(pos[0]); } else if(npos>=2) query=xstrdup(pos[npos-1]); if(!query) query=xstrdup("select * from {}"); if(has_t2 && istrstr(query," join ")) run_join_query(&t,&t2,query); else run_query(&t,query,pretty); free(query); return 0; }
