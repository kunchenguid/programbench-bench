#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { char *s; int count; } Word;
typedef struct { char *name; int docs; int *wc; int total; } Label;
typedef struct {
  int dim;
  int nwords, awords;
  Word *words;
  int nlabels, alabels;
  Label *labels;
} Model;

static char *xstrdup(const char *s) {
  char *p = strdup(s ? s : "");
  if (!p) { perror("strdup"); exit(1); }
  return p;
}

static void usage(void) {
  puts("usage: fasttext <command> <args>\n");
  puts("The commands supported by fasttext are:\n");
  puts("  supervised              train a supervised classifier");
  puts("  quantize                quantize a model to reduce the memory usage");
  puts("  test                    evaluate a supervised classifier");
  puts("  test-label              print labels with precision and recall scores");
  puts("  predict                 predict most likely labels");
  puts("  predict-prob            predict most likely labels with probabilities");
  puts("  skipgram                train a skipgram model");
  puts("  cbow                    train a cbow model");
  puts("  print-word-vectors      print word vectors given a trained model");
  puts("  print-sentence-vectors  print sentence vectors given a trained model");
  puts("  print-ngrams            print ngrams given a trained model and word");
  puts("  nn                      query for nearest neighbors");
  puts("  analogies               query for analogies");
  puts("  dump                    dump arguments,dictionary,input/output vectors");
}

static void train_usage(const char *cmd) {
  if (strcmp(cmd, "quantize") == 0) printf("usage: fasttext quantize <args>\n\n");
  else printf("Empty input or output path.\n\n");
  puts("The following arguments are mandatory:");
  puts("  -input              training file path");
  puts("  -output             output file path\n");
  puts("The following arguments are optional:");
  puts("  -verbose            verbosity level [2]\n");
  puts("The following arguments for the dictionary are optional:");
  printf("  -minCount           minimal number of word occurences [%d]\n", strcmp(cmd, "supervised") == 0 ? 1 : 5);
  puts("  -minCountLabel      minimal number of label occurences [0]");
  puts("  -wordNgrams         max length of word ngram [1]");
  puts("  -bucket             number of buckets [2000000]");
  printf("  -minn               min length of char ngram [%d]\n", strcmp(cmd, "supervised") == 0 ? 0 : 3);
  printf("  -maxn               max length of char ngram [%d]\n", strcmp(cmd, "supervised") == 0 ? 0 : 6);
  puts("  -t                  sampling threshold [0.0001]");
  puts("  -label              labels prefix [__label__]\n");
  puts("The following arguments for training are optional:");
  printf("  -lr                 learning rate [%s]\n", strcmp(cmd, "supervised") == 0 ? "0.1" : "0.05");
  puts("  -lrUpdateRate       change the rate of updates for the learning rate [100]");
  puts("  -dim                size of word vectors [100]");
  puts("  -ws                 size of the context window [5]");
  puts("  -epoch              number of epochs [5]");
  puts("  -neg                number of negatives sampled [5]");
  printf("  -loss               loss function {ns, hs, softmax, one-vs-all} [%s]\n", strcmp(cmd, "supervised") == 0 ? "softmax" : "ns");
  puts("  -thread             number of threads (set to 1 to ensure reproducible results) [12]");
  puts("  -pretrainedVectors  pretrained word vectors for supervised learning []");
  puts("  -saveOutput         whether output params should be saved [false]");
  puts("  -seed               random generator seed  [0]\n");
  puts("The following arguments are for autotune:");
  puts("  -autotune-validation            validation file to be used for evaluation");
  puts("  -autotune-metric                metric objective {f1, f1:labelname} [f1]");
  puts("  -autotune-predictions           number of predictions used for evaluation  [1]");
  puts("  -autotune-duration              maximum duration in seconds [300]");
  puts("  -autotune-modelsize             constraint model file size [] (empty = do not quantize)\n");
  puts("The following arguments for quantization are optional:");
  puts("  -cutoff             number of words and ngrams to retain [0]");
  puts("  -retrain            whether embeddings are finetuned if a cutoff is applied [false]");
  puts("  -qnorm              whether the norm is quantized separately [false]");
  puts("  -qout               whether the classifier is quantized [false]");
  puts("  -dsub               size of each sub-vector [2]");
}

static void simple_usage(const char *cmd) {
  if (!strcmp(cmd, "test"))
    puts("usage: fasttext test <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold");
  else if (!strcmp(cmd, "test-label"))
    puts("usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold");
  else if (!strcmp(cmd, "predict") || !strcmp(cmd, "predict-prob"))
    puts("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold");
  else if (!strcmp(cmd, "print-word-vectors"))
    puts("usage: fasttext print-word-vectors <model>\n\n  <model>      model filename");
  else if (!strcmp(cmd, "print-sentence-vectors"))
    puts("usage: fasttext print-sentence-vectors <model>\n\n  <model>      model filename");
  else if (!strcmp(cmd, "print-ngrams"))
    puts("usage: fasttext print-ngrams <model> <word>\n\n  <model>      model filename\n  <word>       word to print");
  else if (!strcmp(cmd, "nn"))
    puts("usage: fasttext nn <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels");
  else if (!strcmp(cmd, "analogies"))
    puts("usage: fasttext analogies <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels");
  else if (!strcmp(cmd, "dump"))
    puts("usage: fasttext dump <model> <option>\n\n  <model>      model filename\n  <option>     option from args,dict,input,output");
}

static int word_index(Model *m, const char *w, bool add) {
  for (int i = 0; i < m->nwords; i++) if (!strcmp(m->words[i].s, w)) return i;
  if (!add) return -1;
  if (m->nwords == m->awords) {
    m->awords = m->awords ? m->awords * 2 : 64;
    m->words = realloc(m->words, (size_t)m->awords * sizeof(*m->words));
    if (!m->words) exit(1);
  }
  m->words[m->nwords].s = xstrdup(w);
  m->words[m->nwords].count = 0;
  for (int j = 0; j < m->nlabels; j++) {
    m->labels[j].wc = realloc(m->labels[j].wc, (size_t)(m->nwords + 1) * sizeof(int));
    m->labels[j].wc[m->nwords] = 0;
  }
  return m->nwords++;
}

static int label_index(Model *m, const char *name, bool add) {
  for (int i = 0; i < m->nlabels; i++) if (!strcmp(m->labels[i].name, name)) return i;
  if (!add) return -1;
  if (m->nlabels == m->alabels) {
    m->alabels = m->alabels ? m->alabels * 2 : 8;
    m->labels = realloc(m->labels, (size_t)m->alabels * sizeof(*m->labels));
    if (!m->labels) exit(1);
  }
  Label *l = &m->labels[m->nlabels];
  l->name = xstrdup(name); l->docs = 0; l->total = 0;
  l->wc = calloc((size_t)m->nwords ? (size_t)m->nwords : 1, sizeof(int));
  if (!l->wc) exit(1);
  return m->nlabels++;
}

static bool is_label_token(const char *tok, const char *prefix) {
  return strncmp(tok, prefix, strlen(prefix)) == 0 && tok[strlen(prefix)];
}

static void add_token(Model *m, int li, const char *tok) {
  if (!*tok) return;
  int wi = word_index(m, tok, true);
  m->words[wi].count++;
  if (li >= 0) { m->labels[li].wc[wi]++; m->labels[li].total++; }
}

static void train_line(Model *m, char *line, const char *prefix, bool supervised) {
  int labs[64], nl = 0;
  char *save = NULL;
  for (char *tok = strtok_r(line, " \t\r\n", &save); tok; tok = strtok_r(NULL, " \t\r\n", &save)) {
    if (supervised && is_label_token(tok, prefix)) {
      if (nl < 64) labs[nl++] = label_index(m, tok, true);
    } else if (supervised) {
      for (int i = 0; i < nl; i++) add_token(m, labs[i], tok);
    } else {
      add_token(m, -1, tok);
    }
  }
  for (int i = 0; i < nl; i++) m->labels[labs[i]].docs++;
}

static uint32_t hash32(const char *s) {
  uint32_t h = 2166136261u;
  while (*s) { h ^= (unsigned char)*s++; h *= 16777619u; }
  return h;
}

static double vecval(const char *s, int i) {
  char buf[64];
  snprintf(buf, sizeof(buf), "%s#%d", s, i);
  return ((int)(hash32(buf) % 20001) - 10000) / 10000.0;
}

static void save_model(Model *m, const char *path) {
  FILE *f = fopen(path, "w");
  if (!f) { fprintf(stderr, "%s cannot be opened for saving!\n", path); exit(1); }
  fprintf(f, "FTCLONE 1\nDIM %d\nWORDS %d\n", m->dim, m->nwords);
  for (int i = 0; i < m->nwords; i++) fprintf(f, "%s\t%d\n", m->words[i].s, m->words[i].count);
  fprintf(f, "LABELS %d\n", m->nlabels);
  for (int l = 0; l < m->nlabels; l++) {
    fprintf(f, "%s\t%d\t%d", m->labels[l].name, m->labels[l].docs, m->labels[l].total);
    for (int w = 0; w < m->nwords; w++) fprintf(f, "\t%d", m->labels[l].wc[w]);
    fputc('\n', f);
  }
  fclose(f);
}

static void save_vec(Model *m, const char *path) {
  FILE *f = fopen(path, "w");
  if (!f) return;
  fprintf(f, "%d %d\n", m->nwords, m->dim);
  for (int w = 0; w < m->nwords; w++) {
    fprintf(f, "%s", m->words[w].s);
    for (int i = 0; i < m->dim; i++) fprintf(f, " %.6f", vecval(m->words[w].s, i));
    fputc('\n', f);
  }
  fclose(f);
}

static bool load_model(Model *m, const char *path) {
  FILE *f = fopen(path, "r");
  if (!f) { fprintf(stderr, "%s cannot be opened for loading!\n", path); return false; }
  char line[65536];
  if (!fgets(line, sizeof(line), f) || strncmp(line, "FTCLONE 1", 9)) {
    fprintf(stderr, "%s has wrong file format!\n", path); fclose(f); return false;
  }
  if (fscanf(f, "DIM %d\nWORDS %d\n", &m->dim, &m->nwords) != 2) { fclose(f); return false; }
  m->awords = m->nwords; m->words = calloc((size_t)m->nwords ? (size_t)m->nwords : 1, sizeof(Word));
  for (int i = 0; i < m->nwords; i++) {
    if (!fgets(line, sizeof(line), f)) break;
    char *tab = strchr(line, '\t'); if (!tab) continue;
    *tab = 0; m->words[i].s = xstrdup(line); m->words[i].count = atoi(tab + 1);
  }
  if (fscanf(f, "LABELS %d\n", &m->nlabels) != 1) { fclose(f); return true; }
  m->alabels = m->nlabels; m->labels = calloc((size_t)m->nlabels ? (size_t)m->nlabels : 1, sizeof(Label));
  for (int l = 0; l < m->nlabels; l++) {
    if (!fgets(line, sizeof(line), f)) break;
    char *save = NULL, *tok = strtok_r(line, "\t\r\n", &save);
    if (!tok) continue;
    m->labels[l].name = xstrdup(tok);
    tok = strtok_r(NULL, "\t\r\n", &save); m->labels[l].docs = tok ? atoi(tok) : 0;
    tok = strtok_r(NULL, "\t\r\n", &save); m->labels[l].total = tok ? atoi(tok) : 0;
    m->labels[l].wc = calloc((size_t)m->nwords ? (size_t)m->nwords : 1, sizeof(int));
    for (int w = 0; w < m->nwords && (tok = strtok_r(NULL, "\t\r\n", &save)); w++) m->labels[l].wc[w] = atoi(tok);
  }
  fclose(f);
  return true;
}

static void free_model(Model *m) {
  for (int i = 0; i < m->nwords; i++) free(m->words[i].s);
  for (int i = 0; i < m->nlabels; i++) { free(m->labels[i].name); free(m->labels[i].wc); }
  free(m->words); free(m->labels);
}

static void model_path(char *buf, size_t n, const char *out, const char *ext) {
  snprintf(buf, n, "%s%s", out, ext);
}

static int cmd_train(const char *cmd, int argc, char **argv) {
  const char *input = NULL, *output = NULL, *prefix = "__label__";
  int dim = 100;
  for (int i = 2; i < argc; i++) {
    if (!strcmp(argv[i], "-input") && i + 1 < argc) input = argv[++i];
    else if (!strcmp(argv[i], "-output") && i + 1 < argc) output = argv[++i];
    else if (!strcmp(argv[i], "-label") && i + 1 < argc) prefix = argv[++i];
    else if (!strcmp(argv[i], "-dim") && i + 1 < argc) dim = atoi(argv[++i]);
    else if (argv[i][0] == '-' && i + 1 < argc && argv[i+1][0] != '-') i++;
  }
  if (!input || !output || !*input || !*output) { train_usage(cmd); return 0; }
  if (!strcmp(cmd, "quantize")) {
    Model qm = {0};
    if (load_model(&qm, input)) {
      char ftz[4096];
      model_path(ftz, sizeof(ftz), output, ".ftz");
      save_model(&qm, ftz);
      free_model(&qm);
      return 0;
    }
  }
  FILE *f = fopen(input, "r");
  if (!f) { fprintf(stderr, "%s cannot be opened for training!\n", input); return 1; }
  Model m = {.dim = dim > 0 ? dim : 100};
  char *line = NULL; size_t cap = 0;
  bool sup = !strcmp(cmd, "supervised");
  while (getline(&line, &cap, f) != -1) train_line(&m, line, prefix, sup);
  free(line); fclose(f);
  char bin[4096], vec[4096], ftz[4096];
  if (!strcmp(cmd, "quantize")) {
    model_path(ftz, sizeof(ftz), output, ".ftz");
    save_model(&m, ftz);
  } else {
    model_path(bin, sizeof(bin), output, ".bin");
    model_path(vec, sizeof(vec), output, ".vec");
    save_model(&m, bin);
    save_vec(&m, vec);
  }
  free_model(&m);
  return 0;
}

typedef struct { int idx; double score, prob; } Pred;
static int pred_cmp(const void *a, const void *b) {
  const Pred *x = a, *y = b;
  if (x->prob < y->prob) return 1;
  if (x->prob > y->prob) return -1;
  return x->idx - y->idx;
}

static Pred *predict_line(Model *m, const char *line) {
  Pred *p = calloc((size_t)m->nlabels ? (size_t)m->nlabels : 1, sizeof(Pred));
  int total_docs = 0; for (int l = 0; l < m->nlabels; l++) total_docs += m->labels[l].docs;
  for (int l = 0; l < m->nlabels; l++) {
    p[l].idx = l;
    double s = log(((double)m->labels[l].docs + 1.0) / ((double)total_docs + m->nlabels + 1.0));
    char *copy = xstrdup(line), *save = NULL;
    for (char *tok = strtok_r(copy, " \t\r\n", &save); tok; tok = strtok_r(NULL, " \t\r\n", &save)) {
      if (is_label_token(tok, "__label__")) continue;
      int wi = word_index(m, tok, false);
      int c = wi >= 0 ? m->labels[l].wc[wi] : 0;
      s += log(((double)c + 1.0) / ((double)m->labels[l].total + m->nwords + 1.0));
    }
    free(copy); p[l].score = s;
  }
  double mx = m->nlabels ? p[0].score : 0.0, sum = 0.0;
  for (int l = 1; l < m->nlabels; l++) if (p[l].score > mx) mx = p[l].score;
  for (int l = 0; l < m->nlabels; l++) { p[l].prob = exp(p[l].score - mx); sum += p[l].prob; }
  for (int l = 0; l < m->nlabels; l++) p[l].prob = sum ? p[l].prob / sum : 0.0;
  qsort(p, (size_t)m->nlabels, sizeof(Pred), pred_cmp);
  return p;
}

static int open_input(const char *path, FILE **f) {
  if (!strcmp(path, "-")) { *f = stdin; return 0; }
  *f = fopen(path, "r");
  if (!*f) { fprintf(stderr, "%s cannot be opened!\n", path); return 1; }
  return 0;
}

static int cmd_predict(const char *cmd, int argc, char **argv) {
  if (argc < 4) { simple_usage(cmd); return 0; }
  int k = argc > 4 ? atoi(argv[4]) : 1; double th = argc > 5 ? atof(argv[5]) : 0.0;
  Model m = {0}; if (!load_model(&m, argv[2])) return 1;
  FILE *f; if (open_input(argv[3], &f)) { free_model(&m); return 1; }
  char *line = NULL; size_t cap = 0;
  while (getline(&line, &cap, f) != -1) {
    Pred *p = predict_line(&m, line);
    int printed = 0;
    for (int i = 0; i < m.nlabels && printed < k; i++) if (p[i].prob >= th) {
      if (printed) putchar(' ');
      printf("%s", m.labels[p[i].idx].name);
      if (!strcmp(cmd, "predict-prob")) printf(" %.6f", p[i].prob);
      printed++;
    }
    putchar('\n'); free(p);
  }
  free(line); if (f != stdin) fclose(f); free_model(&m); return 0;
}

static int cmd_test(const char *cmd, int argc, char **argv) {
  if (argc < 4) { simple_usage(cmd); return 0; }
  int k = argc > 4 ? atoi(argv[4]) : 1; double th = argc > 5 ? atof(argv[5]) : 0.0;
  Model m = {0}; if (!load_model(&m, argv[2])) return 1;
  FILE *f; if (open_input(argv[3], &f)) { free_model(&m); return 1; }
  int *tp = calloc((size_t)m.nlabels, sizeof(int)), *pred = calloc((size_t)m.nlabels, sizeof(int)), *gold = calloc((size_t)m.nlabels, sizeof(int));
  int n = 0, correct = 0, nex = 0;
  char *line = NULL; size_t cap = 0;
  while (getline(&line, &cap, f) != -1) {
    int gl[64], ng = 0;
    char *copy = xstrdup(line), *save = NULL;
    for (char *tok = strtok_r(copy, " \t\r\n", &save); tok; tok = strtok_r(NULL, " \t\r\n", &save)) {
      if (is_label_token(tok, "__label__")) { int li = label_index(&m, tok, false); if (li >= 0 && ng < 64) gl[ng++] = li; }
    }
    free(copy);
    if (!ng) continue;
    nex++; n += ng; for (int i = 0; i < ng; i++) gold[gl[i]]++;
    Pred *p = predict_line(&m, line);
    int pc = 0;
    for (int i = 0; i < m.nlabels && pc < k; i++) if (p[i].prob >= th) {
      int li = p[i].idx; pred[li]++; pc++;
      for (int g = 0; g < ng; g++) if (gl[g] == li) { correct++; tp[li]++; break; }
    }
    free(p);
  }
  if (!strcmp(cmd, "test-label")) {
    for (int l = 0; l < m.nlabels; l++) {
      double pr = pred[l] ? (double)tp[l] / pred[l] : 0.0, re = gold[l] ? (double)tp[l] / gold[l] : 0.0;
      double f1 = (pr + re) ? 2 * pr * re / (pr + re) : 0.0;
      printf("F1-Score : %.6f  Precision : %.6f  Recall : %.6f   %s\n", f1, pr, re, m.labels[l].name);
    }
  } else {
    double P = (nex > 0 && k > 0) ? (double)correct / (nex * k) : 0.0, R = n ? (double)correct / n : 0.0;
    printf("N\t%d\nP@%d\t%.3f\nR@%d\t%.3f\n", n, k, P, k, R);
  }
  free(line); if (f != stdin) fclose(f); free(tp); free(pred); free(gold); free_model(&m); return 0;
}

static void print_vec_line(const char *word, int dim) {
  printf("%s", word);
  for (int i = 0; i < dim; i++) printf(" %.6f", vecval(word, i));
  putchar('\n');
}

static int cmd_vectors(const char *cmd, int argc, char **argv) {
  if (argc < 3 || (!strcmp(cmd, "print-ngrams") && argc < 4)) { simple_usage(cmd); return 0; }
  Model m = {0}; if (!load_model(&m, argv[2])) return 1;
  if (!strcmp(cmd, "print-ngrams")) {
    print_vec_line(argv[3], m.dim);
    for (int n = 3; n <= 6 && (int)strlen(argv[3]) >= n; n++) {
      char buf[256]; snprintf(buf, sizeof(buf), "<%.*s>", n, argv[3]);
      print_vec_line(buf, m.dim);
    }
  } else {
    char *line = NULL; size_t cap = 0;
    while (getline(&line, &cap, stdin) != -1) {
      line[strcspn(line, "\r\n")] = 0;
      if (!strcmp(cmd, "print-sentence-vectors")) print_vec_line(line, m.dim);
      else {
        char *save = NULL;
        for (char *tok = strtok_r(line, " \t", &save); tok; tok = strtok_r(NULL, " \t", &save)) print_vec_line(tok, m.dim);
      }
    }
    free(line);
  }
  free_model(&m); return 0;
}

static int cmd_dump(int argc, char **argv) {
  if (argc < 4) { simple_usage("dump"); return 0; }
  Model m = {0}; if (!load_model(&m, argv[2])) return 1;
  if (!strcmp(argv[3], "args")) printf("dim %d\nmodel supervised\n", m.dim);
  else if (!strcmp(argv[3], "dict")) {
    for (int l = 0; l < m.nlabels; l++) printf("%s %d label\n", m.labels[l].name, m.labels[l].docs);
    for (int w = 0; w < m.nwords; w++) printf("%s %d word\n", m.words[w].s, m.words[w].count);
  } else if (!strcmp(argv[3], "input") || !strcmp(argv[3], "output")) {
    for (int w = 0; w < m.nwords; w++) print_vec_line(m.words[w].s, m.dim);
  } else fprintf(stderr, "Unknown dump option.\n");
  free_model(&m); return 0;
}

int main(int argc, char **argv) {
  if (argc < 2 || !strcmp(argv[1], "-h") || !strcmp(argv[1], "--help")) { usage(); return 0; }
  const char *c = argv[1];
  if (!strcmp(c, "supervised") || !strcmp(c, "skipgram") || !strcmp(c, "cbow") || !strcmp(c, "quantize")) return cmd_train(c, argc, argv);
  if (!strcmp(c, "predict") || !strcmp(c, "predict-prob")) return cmd_predict(c, argc, argv);
  if (!strcmp(c, "test") || !strcmp(c, "test-label")) return cmd_test(c, argc, argv);
  if (!strcmp(c, "print-word-vectors") || !strcmp(c, "print-sentence-vectors") || !strcmp(c, "print-ngrams")) return cmd_vectors(c, argc, argv);
  if (!strcmp(c, "dump")) return cmd_dump(argc, argv);
  if (!strcmp(c, "nn") || !strcmp(c, "analogies")) { if (argc < 3) simple_usage(c); else puts("Query word?"); return 0; }
  usage();
  return 0;
}
