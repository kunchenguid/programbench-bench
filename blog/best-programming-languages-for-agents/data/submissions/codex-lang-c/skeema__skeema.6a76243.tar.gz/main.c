#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

#define VERSION "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"

static void stamp(FILE *f, const char *level) {
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "%s [%s] ", buf, level);
    if (strlen(level) < 5) fputc(' ', f);
}

static void logmsg(const char *level, const char *fmt, const char *a, const char *b) {
    stamp(stderr, level);
    fprintf(stderr, fmt, a ? a : "", b ? b : "");
    fputc('\n', stderr);
}

static const char *global_opts =
"Global Options:\n"
"  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server\n"
"      --debug                  Enable debug logging\n"
"  -?, --help[=value]           Display usage information for the specified command\n"
"  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars\n"
"      --ignore-func value      Ignore functions that match regex\n"
"      --ignore-proc value      Ignore stored procedures that match regex\n"
"      --ignore-schema value    Ignore schemas that match regex\n"
"      --ignore-table value     Ignore tables that match regex\n"
"      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)\n"
"  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default \"$MYSQL_PWD\")\n"
"      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: \"disabled\", \"preferred\", \"required\")\n"
"  -u, --user value             Username to connect to database host (default \"root\")\n"
"      --version                Display program version\n";

static void main_help(void) {
    printf("\nUsage:  skeema [<options>] <command>\n\n"
"Skeema is a declarative schema management system for MySQL and MariaDB. It\n"
"allows you to export a database schema to the filesystem, and apply online\n"
"schema changes by modifying CREATE statements in .sql files.\n\n"
"Commands:\n"
"      add-environment  Add a new named environment to an existing host directory\n"
"      diff             Compare a DB server's schemas to the filesystem\n"
"      format           Normalize format of filesystem representation of database objects\n"
"      help             Display usage information\n"
"      init             Save a DB server's schemas to the filesystem\n"
"      lint             Check for problems in filesystem representation of database objects\n"
"      pull             Update the filesystem representation of schemas\n"
"      push             Alter objects on DBs to reflect the filesystem representation\n"
"      version          Display program version\n\n%s\n"
"Complete documentation for this command suite is available online:\n"
"https://www.skeema.io/docs/commands\n\n", global_opts);
}

static void simple_help(const char *cmd, const char *usage, const char *desc, const char *opts, const char *urlcmd) {
    printf("\nUsage:  skeema %s %s\n\n%s\n\n", cmd, usage, desc);
    if (opts && *opts) printf("%s\n", opts);
    printf("%s\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/%s\n\n", global_opts, urlcmd ? urlcmd : cmd);
}

static const char *linter_opts =
"Linter Rule Options:\n"
"      --allow-auto-inc value       List of allowed auto_increment column data types for --lint-auto-inc (default \"int unsigned, bigint unsigned\")\n"
"      --allow-charset value        List of allowed character sets for --lint-charset (default \"latin1,utf8mb4\")\n"
"      --allow-compression value    List of allowed compression settings for --lint-compression (default \"none,4kb,8kb\")\n"
"      --allow-definer value        List of allowed definer users for --lint-definer (default \"%@%\")\n"
"      --allow-engine value         List of allowed storage engines for --lint-engine (default \"innodb\")\n"
"      --allow-pk-type value        List of allowed data types for --lint-pk-type\n"
"      --lint-auto-inc value        Only allow auto_increment column data types listed in --allow-auto-inc (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-charset value         Only allow character sets listed in --allow-charset (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-compression value     Only allow compression settings listed in --allow-compression (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-definer value         Only allow definer users listed in --allow-definer for stored objects (valid values: \"ignore\", \"warning\", \"error\") (default \"error\")\n"
"      --lint-display-width value   Only allow default display width for int types (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-dupe-index value      Flag redundant secondary indexes (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-engine value          Only allow storage engines listed in --allow-engine (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-fk-parent value       Flag foreign keys where same-schema parent table is missing or lacks unique key on referenced columns (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-has-enum value        Flag columns using ENUM or SET data types (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-has-fk value          Flag any use of foreign keys; intended for environments that restrict their presence (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-has-float value       Flag columns using FLOAT or DOUBLE data types (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-has-routine value     Flag any use of stored procs or funcs; intended for environments that restrict their presence (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-has-time value        Flag columns using TIMESTAMP, DATETIME, or TIME data types (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-name-case value       Flag tables that have uppercase letters in their names (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-pk value              Flag tables that lack a primary key (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-pk-type value         Only allow primary keys to have types listed in --allow-pk-type (valid values: \"ignore\", \"warning\", \"error\") (default \"ignore\")\n"
"      --lint-reserved-word value   Flag names of tables, columns, or routines that used reserved words (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n"
"      --lint-zero-date value       Flag DATE, DATETIME, and TIMESTAMP columns that have zero-date default values (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n";

static const char *workspace_opts =
"Workspace Options:\n"
"      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: \"none\", \"stop\", \"destroy\") (default \"none\")\n"
"  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default \"_skeema_tmp\")\n"
"      --temp-schema-binlog value   Controls whether temp schema DDL operations are replicated (valid values: \"on\", \"off\", \"auto\") (default \"auto\")\n"
"      --temp-schema-mode value     Tunes workspace load with workspace=temp-schema; heavier load makes Skeema faster but may disrupt other workloads on the database (valid values: \"serial\", \"light\", \"regular\", \"heavy\", \"extreme\") (default \"regular\")\n"
"      --temp-schema-threads value  Deprecated manner of controlling workspace load with workspace=temp-schema (default \"5\")\n"
"  -w, --workspace value            Specifies where to run intermediate operations (valid values: \"temp-schema\", \"docker\") (default \"temp-schema\")\n";

static bool is_cmd(const char *s) {
    const char *cmds[] = {"add-environment","diff","format","help","init","lint","pull","push","version",NULL};
    for (int i=0; cmds[i]; i++) if (!strcmp(s, cmds[i])) return true;
    return false;
}

static bool has_prefix(const char *s, const char *p) { return strncmp(s,p,strlen(p))==0; }

static char *opt_value(int *i, int argc, char **argv) {
    char *eq = strchr(argv[*i], '=');
    if (eq) return eq + 1;
    if (*i + 1 < argc) return argv[++(*i)];
    return NULL;
}

static bool valid_option_name(const char *a) {
    const char *name = a;
    if (has_prefix(name, "--")) name += 2;
    else if (has_prefix(name, "-")) name += 1;
    char tmp[128];
    size_t n = strcspn(name, "=");
    if (n >= sizeof(tmp)) n = sizeof(tmp)-1;
    memcpy(tmp, name, n); tmp[n] = 0;
    const char *known[] = {"connect-options","debug","help","?","host-wrapper","ignore-func","ignore-proc","ignore-schema","ignore-table","my-cnf","skip-my-cnf","password","p","ssl-mode","user","u","version","dir","d","host","h","port","P","socket","S","include-auto-inc","schema","strip-partitioning","format","skip-format","write","skip-write","new-schemas","skip-new-schemas","update-partitioning","alter-wrapper","x","ddl-wrapper","X","alter-wrapper-min-size","alter-algorithm","alter-lock","alter-validate-virtual","compare-metadata","exact-match","lax-column-order","lax-comments","partitioning","lint","skip-lint","allow-auto-inc","allow-charset","allow-compression","allow-definer","allow-engine","allow-pk-type","lint-auto-inc","lint-charset","lint-compression","lint-definer","lint-display-width","lint-dupe-index","lint-engine","lint-fk-parent","lint-has-enum","lint-has-fk","lint-has-float","lint-has-routine","lint-has-time","lint-name-case","lint-pk","lint-pk-type","lint-reserved-word","lint-zero-date","allow-unsafe","safe-below-size","verify","skip-verify","brief","q","concurrent-servers","c","first-only","1","workspace","w","temp-schema","t","docker-cleanup","temp-schema-binlog","temp-schema-mode","temp-schema-threads","dry-run","foreign-key-checks",NULL};
    for (int i=0; known[i]; i++) if (!strcmp(tmp, known[i])) return true;
    return false;
}

static bool option_takes_value(const char *a) {
    const char *name = a + (a[1]=='-' ? 2 : 1);
    char tmp[128]; size_t n = strcspn(name, "=");
    if (n >= sizeof(tmp)) n = sizeof(tmp)-1;
    memcpy(tmp,name,n); tmp[n]=0;
    const char *vals[] = {"o","connect-options","H","host-wrapper","ignore-func","ignore-proc","ignore-schema","ignore-table","p","password","ssl-mode","u","user","d","dir","h","host","P","port","S","socket","schema","x","alter-wrapper","X","ddl-wrapper","alter-wrapper-min-size","alter-algorithm","alter-lock","partitioning","allow-auto-inc","allow-charset","allow-compression","allow-definer","allow-engine","allow-pk-type","lint-auto-inc","lint-charset","lint-compression","lint-definer","lint-display-width","lint-dupe-index","lint-engine","lint-fk-parent","lint-has-enum","lint-has-fk","lint-has-float","lint-has-routine","lint-has-time","lint-name-case","lint-pk","lint-pk-type","lint-reserved-word","lint-zero-date","safe-below-size","c","concurrent-servers","w","workspace","t","temp-schema","docker-cleanup","temp-schema-binlog","temp-schema-mode","temp-schema-threads",NULL};
    for (int i=0; vals[i]; i++) if (!strcmp(tmp, vals[i])) return strchr(a,'=')==NULL;
    return false;
}

static bool find_file_up(const char *name, char *out, size_t sz) {
    char cwd[PATH_MAX]; if (!getcwd(cwd, sizeof(cwd))) return false;
    while (1) {
        snprintf(out, sz, "%s/%s", cwd, name);
        if (access(out, F_OK) == 0) return true;
        if (!strcmp(cwd, "/")) break;
        char *slash = strrchr(cwd, '/');
        if (!slash || slash == cwd) { strcpy(cwd, "/"); }
        else *slash = 0;
    }
    return false;
}

static bool has_sql_here(void) {
    DIR *d = opendir(".");
    if (!d) return false;
    struct dirent *e;
    while ((e = readdir(d))) {
        size_t n = strlen(e->d_name);
        if (n > 4 && !strcmp(e->d_name+n-4, ".sql")) { closedir(d); return true; }
    }
    closedir(d); return false;
}

static int cmd_add_env(int argc, char **argv, int start) {
    const char *env = NULL, *host = NULL, *port = NULL, *socket = NULL, *dir = ".";
    for (int i=start; i<argc; i++) {
        if (argv[i][0]=='-') {
            if (!strcmp(argv[i],"--host") || !strcmp(argv[i],"-h") || has_prefix(argv[i],"--host=")) host=opt_value(&i,argc,argv);
            else if (!strcmp(argv[i],"--port") || !strcmp(argv[i],"-P") || has_prefix(argv[i],"--port=")) port=opt_value(&i,argc,argv);
            else if (!strcmp(argv[i],"--socket") || !strcmp(argv[i],"-S") || has_prefix(argv[i],"--socket=")) socket=opt_value(&i,argc,argv);
            else if (!strcmp(argv[i],"--dir") || !strcmp(argv[i],"-d") || has_prefix(argv[i],"--dir=")) dir=opt_value(&i,argc,argv);
            else if (option_takes_value(argv[i])) opt_value(&i,argc,argv);
        } else if (!env) env = argv[i];
    }
    if (!env) { logmsg("ERROR","Command add-environment requires arg <environment>",NULL,NULL); return 78; }
    char path[PATH_MAX]; snprintf(path,sizeof(path),"%s/.skeema",dir);
    if (access(path,F_OK)!=0) {
        char ab[PATH_MAX]; realpath(dir, ab);
        logmsg("ERROR","Dir %s does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`",ab[0]?ab:dir,NULL);
        return 78;
    }
    char ab[PATH_MAX];
    if (!realpath(path, ab)) {
        strncpy(ab, path, sizeof(ab)-1);
        ab[sizeof(ab)-1] = 0;
    }
    FILE *f = fopen(path,"a");
    if (!f) { logmsg("ERROR","Unable to modify %s",path,NULL); return 78; }
    fprintf(f,"\n[%s]\n", env);
    if (host) fprintf(f,"host=%s\n",host);
    if (port) fprintf(f,"port=%s\n",port);
    if (socket) fprintf(f,"socket=%s\n",socket);
    fclose(f);
    logmsg("WARN","Unable to automatically determine database server's vendor/version. To set manually, use the \"flavor\" option in %s",ab,NULL);
    logmsg("INFO","Added environment [%s] to %s",env,ab);
    return 0;
}

static int cmd_init(int argc, char **argv, int start) {
    const char *host = NULL;
    for (int i=start; i<argc; i++) {
        if (!strcmp(argv[i],"--host") || !strcmp(argv[i],"-h") || has_prefix(argv[i],"--host=")) host=opt_value(&i,argc,argv);
        else if (argv[i][0]=='-' && option_takes_value(argv[i])) opt_value(&i,argc,argv);
    }
    if (!host || !*host) { logmsg("ERROR","Option --host must be supplied on the command-line",NULL,NULL); return 78; }
    char cwd[PATH_MAX]; getcwd(cwd,sizeof(cwd));
    char msg[PATH_MAX+256]; snprintf(msg,sizeof(msg),"Unable to connect to %s:3306 for %s/%s: dial tcp: lookup %s: network is unreachable",host,cwd,host,host);
    logmsg("ERROR","%s",msg,NULL);
    return 2;
}

static int cmd_lint(const char *cmd) {
    char cwd[PATH_MAX]; getcwd(cwd,sizeof(cwd));
    logmsg("INFO", !strcmp(cmd,"format") ? "Checking format of %s" : "Linting %s", cwd, NULL);
    char cfg[PATH_MAX];
    if (has_sql_here() && !find_file_up(".skeema", cfg, sizeof(cfg))) {
        if (!strcmp(cmd,"format")) logmsg("ERROR","Skipping %s: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"",cwd,NULL);
        else {
            const char *base = strrchr(cwd,'/'); base = base ? base+1 : cwd;
            logmsg("ERROR","Skipping directory %s due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"",base,NULL);
            logmsg("ERROR","Skipped 1 operation due to fatal errors",NULL,NULL);
        }
        return 78;
    }
    return 0;
}

static void help_for(const char *cmd) {
    if (!cmd) { main_help(); return; }
    if (!strcmp(cmd,"version")) simple_help("version","[<options>]","Display program version","", "version");
    else if (!strcmp(cmd,"add-environment")) simple_help("add-environment","[<options>] <environment>",
"Modifies the .skeema file in an existing host directory to add a new named\nenvironment.",
"Add-Environment Options:\n  -d, --dir value              Base dir for this host's schemas (default \".\")\n  -h, --host value             Database hostname or IP address\n  -P, --port value             Port to use for database host (default \"3306\")\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default \"/tmp/mysql.sock\")\n", "add-environment");
    else if (!strcmp(cmd,"init")) simple_help("init","[<options>] [<environment>]",
"Creates a filesystem representation of the schemas on a database server.",
"Init Options:\n  -d, --dir value              Subdir name to use for this host's schemas (default \"<hostname>\")\n  -h, --host value             Database hostname or IP address\n      --include-auto-inc       Include starting auto-inc values in table files\n  -P, --port value             Port to use for database host (default \"3306\")\n      --schema value           Only import the one specified schema; skip creation of subdirs for each schema\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default \"/tmp/mysql.sock\")\n      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem\n", "init");
    else if (!strcmp(cmd,"format")) simple_help("format","[<options>] [<environment>]",
"Reformats the filesystem representation of database objects to match the\ncanonical format shown in SHOW CREATE.",
"Format Options:\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)\n\nWorkspace Options:\n      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: \"none\", \"stop\", \"destroy\") (default \"none\")\n  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default \"_skeema_tmp\")\n  -w, --workspace value            Specifies where to run intermediate operations (valid values: \"temp-schema\", \"docker\") (default \"temp-schema\")\n", "format");
    else if (!strcmp(cmd,"lint")) {
        char opts[8192]; snprintf(opts,sizeof(opts),"Format Options:\n      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n\n%s\n%s", linter_opts, workspace_opts);
        simple_help("lint","[<options>] [<environment>]","Checks for problems in filesystem representation of database objects.",opts,"lint");
    } else if (!strcmp(cmd,"pull")) simple_help("pull","[<options>] [<environment>]","Updates the existing filesystem representation of the schemas on a DB server.",
"Pull Options:\n      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n      --include-auto-inc           Include starting auto-inc values in new table files, and update in existing files\n      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)\n      --strip-partitioning         Omit PARTITION BY clause when writing partitioned tables to filesystem\n      --update-partitioning        Update PARTITION BY clauses in existing table files\n", "pull");
    else if (!strcmp(cmd,"diff") || !strcmp(cmd,"push")) {
        const char *desc = !strcmp(cmd,"diff") ? "Compares the schemas on database server(s) to the corresponding filesystem\nrepresentation of them." : "Modifies the schemas on database server(s) to match the corresponding filesystem\nrepresentation of them.";
        simple_help(cmd,"[<options>] [<environment>]",desc,
"External Tool Options:\n  -x, --alter-wrapper value           External bin to shell out to for ALTER TABLE; see manual for template vars\n  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)\n\nSQL Generation Options:\n      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: \"inplace\", \"copy\", \"instant\", \"nocopy\")\n      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: \"none\", \"shared\", \"exclusive\")\n      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact\n\nSafety Options:\n      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive\n      --dry-run                       Output DDL but don't run it; equivalent to `skeema diff`\n\nSharding Options:\n  -q, --brief                         Don't output DDL to STDOUT; instead output list of database servers with at least one difference\n  -c, --concurrent-servers value      Perform operations on this number of database servers concurrently (default \"1\")\n", cmd);
    } else main_help();
}

int main(int argc, char **argv) {
    const char *cmd = NULL;
    int cmdidx = -1;
    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (!strcmp(a,"--version")) { puts(VERSION); return 0; }
        if (!strcmp(a,"--help") || !strcmp(a,"-?")) { help_for(NULL); return 0; }
        if (has_prefix(a,"--help=")) { help_for(a+7); return 0; }
        if (has_prefix(a,"-?") && strlen(a)>2) { help_for(a+2); return 0; }
        if (a[0]=='-') {
            if (!valid_option_name(a)) {
                const char *n = a + (a[1]=='-' ? 2 : 1);
                char tmp[128]; size_t len = strcspn(n,"=");
                if (len >= sizeof(tmp)) len = sizeof(tmp)-1;
                memcpy(tmp,n,len); tmp[len]=0;
                logmsg("ERROR","CLI: Unknown option \"%s\"",tmp,NULL); return 78;
            }
            if (option_takes_value(a)) opt_value(&i, argc, argv);
            continue;
        }
        cmd = a; cmdidx = i; break;
    }
    if (!cmd) { main_help(); return 0; }
    if (!strcmp(cmd,"help")) {
        const char *hc = (cmdidx+1<argc) ? argv[cmdidx+1] : NULL;
        if (hc && !is_cmd(hc)) { logmsg("ERROR","Unknown command \"%s\"",hc,NULL); return 2; }
        help_for(hc); return 0;
    }
    if (!is_cmd(cmd)) { logmsg("ERROR","Unknown command \"%s\"",cmd,NULL); return 78; }
    for (int i=cmdidx+1; i<argc; i++) {
        if (!strcmp(argv[i],"--help") || !strcmp(argv[i],"-?")) { help_for(cmd); return 0; }
        if (argv[i][0]=='-' && !valid_option_name(argv[i])) {
            const char *n = argv[i] + (argv[i][1]=='-' ? 2 : 1);
            char tmp[128]; size_t len = strcspn(n,"=");
            if (len >= sizeof(tmp)) len = sizeof(tmp)-1;
            memcpy(tmp,n,len); tmp[len]=0;
            logmsg("ERROR","CLI: Unknown option \"%s\"",tmp,NULL); return 78;
        }
    }
    if (!strcmp(cmd,"version")) { puts(VERSION); return 0; }
    if (!strcmp(cmd,"add-environment")) return cmd_add_env(argc, argv, cmdidx+1);
    if (!strcmp(cmd,"init")) return cmd_init(argc, argv, cmdidx+1);
    if (!strcmp(cmd,"lint") || !strcmp(cmd,"format")) return cmd_lint(cmd);
    if (!strcmp(cmd,"diff")) return 0;
    if (!strcmp(cmd,"pull") || !strcmp(cmd,"push")) {
        char cwd[PATH_MAX]; getcwd(cwd,sizeof(cwd));
        logmsg("ERROR","This command needs a database host configured for %s",cwd,NULL);
        return 78;
    }
    return 0;
}
