#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define DEG (M_PI / 180.0)
#define RAD (180.0 / M_PI)

typedef struct {
    char proj[32], ellps[32], datum[32], units[32];
    double a, f, e2, e, lon0, lat0, lat1, lat2, lat_ts, k0, x0, y0, mfac;
    int zone, south;
    int inverse, reverse_in, swap_out, echo, verbose, very_verbose;
    const char *fmt;
} Cfg;

static const char *proj_list =
"adams_hemi : Adams Hemisphere in a Square\n"
"adams_ws1 : Adams World in a Square I\n"
"adams_ws2 : Adams World in a Square II\n"
"aea : Albers Equal Area\n"
"aeqd : Azimuthal Equidistant\n"
"affine : Affine transformation\n"
"airy : Airy\n"
"aitoff : Aitoff\n"
"alsk : Modified Stereographic of Alaska\n"
"apian : Apian Globular I\n"
"august : August Epicycloidal\n"
"axisswap : Axis ordering\n"
"bacon : Bacon Globular\n"
"bertin1953 : Bertin 1953\n"
"bipc : Bipolar conic of western hemisphere\n"
"boggs : Boggs Eumorphic\n"
"bonne : Bonne (Werner lat_1=90)\n"
"cart : Geodetic/cartesian conversions\n"
"cass : Cassini\n"
"cc : Central Cylindrical\n"
"ccon : Central Conic\n"
"cea : Equal Area Cylindrical\n"
"chamb : Chamberlin Trimetric\n"
"collg : Collignon\n"
"col_urban : Colombia Urban\n"
"comill : Compact Miller\n"
"crast : Craster Parabolic (Putnins P4)\n"
"eqc : Equidistant Cylindrical (Plate Carree)\n"
"eqdc : Equidistant Conic\n"
"eck1 : Eckert I\n"
"eck2 : Eckert II\n"
"eck3 : Eckert III\n"
"eck4 : Eckert IV\n"
"eck5 : Eckert V\n"
"eck6 : Eckert VI\n"
"eqearth : Equal Earth\n"
"fahey : Fahey\n"
"gall : Gall (Gall Stereographic)\n"
"geoc : Geocentric Latitude\n"
"gnom : Gnomonic\n"
"goode : Goode Homolosine\n"
"hammer : Hammer & Eckert-Greifendorff\n"
"igh : Interrupted Goode Homolosine\n"
"laea : Lambert Azimuthal Equal Area\n"
"lonlat : Lat/long (Geodetic)\n"
"latlon : Lat/long (Geodetic alias)\n"
"lcc : Lambert Conformal Conic\n"
"merc : Mercator\n"
"mill : Miller Cylindrical\n"
"moll : Mollweide\n"
"ortho : Orthographic\n"
"poly : Polyconic (American)\n"
"robin : Robinson\n"
"sinu : Sinusoidal (Sanson-Flamsteed)\n"
"stere : Stereographic\n"
"tmerc : Transverse Mercator\n"
"utm : Universal Transverse Mercator (UTM)\n"
"vandg : van der Grinten (I)\n"
"webmerc : Web Mercator / Pseudo Mercator\n"
"wintri : Winkel Tripel\n";

static void init(Cfg *c) {
    memset(c, 0, sizeof(*c));
    strcpy(c->proj, "");
    strcpy(c->ellps, "WGS84");
    c->a = 6378137.0;
    c->f = 1.0 / 298.257223563;
    c->e2 = c->f * (2 - c->f);
    c->e = sqrt(c->e2);
    c->k0 = 1.0;
    c->mfac = 1.0;
    c->fmt = "%.2f";
}

static void usage(void) {
    printf("Rel. 9.9.0, September 15th, 2026\n");
    printf("usage: executable [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]\n");
}

static void fatal(const char *msg, const char *arg) {
    printf("Rel. 9.9.0, September 15th, 2026\n");
    printf("<executable>: \n");
    if (arg) printf(msg, arg); else printf("%s", msg);
    printf("\nprogram abnormally terminated\n");
}

static double unit_factor(const char *u) {
    if (!strcmp(u, "km")) return 0.001;
    if (!strcmp(u, "m") || !*u) return 1.0;
    if (!strcmp(u, "cm")) return 100.0;
    if (!strcmp(u, "mm")) return 1000.0;
    if (!strcmp(u, "ft")) return 1.0 / 0.3048;
    if (!strcmp(u, "us-ft")) return 1.0 / 0.304800609601219;
    if (!strcmp(u, "mi")) return 1.0 / 1609.344;
    return 1.0;
}

static double dmstor(const char *s, char **endp) {
    while (isspace((unsigned char)*s)) s++;
    int neg = 0;
    if (*s == '-' || *s == '+') neg = (*s++ == '-');
    char *e;
    double d = strtod(s, &e);
    double v = d;
    if (*e == 'd' || *e == 'D') {
        s = e + 1;
        double m = strtod(s, &e);
        v = fabs(d) + m / 60.0;
        if (*e == '\'') {
            s = e + 1;
            double sec = strtod(s, &e);
            v += sec / 3600.0;
            if (*e == '"') e++;
        }
    }
    if (*e == 'W' || *e == 'w' || *e == 'S' || *e == 's') { neg = 1; e++; }
    else if (*e == 'E' || *e == 'e' || *e == 'N' || *e == 'n') e++;
    if (endp) *endp = e;
    return neg ? -fabs(v) : v;
}

static double tsfn(double phi, double sinphi, double e) {
    double con = e * sinphi;
    return tan(0.5 * (M_PI / 2 - phi)) / pow((1 - con) / (1 + con), 0.5 * e);
}

static double msfn(double sinphi, double cosphi, double e2) {
    return cosphi / sqrt(1 - e2 * sinphi * sinphi);
}

static double mlfn(Cfg *c, double phi) {
    double e2 = c->e2, e4 = e2 * e2, e6 = e4 * e2;
    return c->a * ((1 - e2/4 - 3*e4/64 - 5*e6/256) * phi
        - (3*e2/8 + 3*e4/32 + 45*e6/1024) * sin(2*phi)
        + (15*e4/256 + 45*e6/1024) * sin(4*phi)
        - (35*e6/3072) * sin(6*phi));
}

static double inv_mlfn(Cfg *c, double m) {
    double mu = m / (c->a * (1 - c->e2/4 - 3*c->e2*c->e2/64 - 5*c->e2*c->e2*c->e2/256));
    double e1 = (1 - sqrt(1 - c->e2)) / (1 + sqrt(1 - c->e2));
    return mu + (3*e1/2 - 27*pow(e1,3)/32)*sin(2*mu)
        + (21*e1*e1/16 - 55*pow(e1,4)/32)*sin(4*mu)
        + (151*pow(e1,3)/96)*sin(6*mu)
        + (1097*pow(e1,4)/512)*sin(8*mu);
}

static void fwd_tmerc(Cfg *c, double lon, double lat, double *x, double *y) {
    if (fabs(lon - c->lon0) > 0.5) {
        double b = cos(lat) * sin(lon - c->lon0);
        if (b > 0.999999999) b = 0.999999999;
        if (b < -0.999999999) b = -0.999999999;
        *x = c->x0 + c->k0 * c->a * 0.5 * log((1 + b) / (1 - b));
        *y = c->y0 + c->k0 * c->a * (atan2(tan(lat), cos(lon - c->lon0)) - c->lat0);
        return;
    }
    double ep2 = c->e2 / (1 - c->e2), N = c->a / sqrt(1 - c->e2 * pow(sin(lat),2));
    double T = pow(tan(lat),2), C = ep2 * pow(cos(lat),2), A = cos(lat) * (lon - c->lon0);
    double M = mlfn(c, lat), M0 = mlfn(c, c->lat0);
    *x = c->x0 + c->k0 * N * (A + (1-T+C)*pow(A,3)/6 + (5-18*T+T*T+72*C-58*ep2)*pow(A,5)/120);
    *y = c->y0 + c->k0 * (M - M0 + N*tan(lat)*(A*A/2 + (5-T+9*C+4*C*C)*pow(A,4)/24 + (61-58*T+T*T+600*C-330*ep2)*pow(A,6)/720));
}

static void inv_tmerc(Cfg *c, double x, double y, double *lon, double *lat) {
    double ep2 = c->e2 / (1 - c->e2);
    double M = mlfn(c, c->lat0) + (y - c->y0) / c->k0;
    double fp = inv_mlfn(c, M);
    double C1 = ep2 * pow(cos(fp),2), T1 = pow(tan(fp),2);
    double N1 = c->a / sqrt(1 - c->e2 * pow(sin(fp),2));
    double R1 = c->a * (1 - c->e2) / pow(1 - c->e2 * pow(sin(fp),2), 1.5);
    double D = (x - c->x0) / (N1 * c->k0);
    *lat = fp - (N1*tan(fp)/R1) * (D*D/2 - (5+3*T1+10*C1-4*C1*C1-9*ep2)*pow(D,4)/24
        + (61+90*T1+298*C1+45*T1*T1-252*ep2-3*C1*C1)*pow(D,6)/720);
    *lon = c->lon0 + (D - (1+2*T1+C1)*pow(D,3)/6
        + (5-2*C1+28*T1-3*C1*C1+8*ep2+24*T1*T1)*pow(D,5)/120) / cos(fp);
}

static void project(Cfg *c, double lon_deg, double lat_deg, double *x, double *y) {
    double lon = lon_deg * DEG, lat = lat_deg * DEG;
    if (!strcmp(c->proj, "utm")) {
        c->lon0 = ((c->zone > 0 ? c->zone : (int)floor((lon_deg+180)/6)+1) * 6 - 183) * DEG;
        c->lat0 = 0; c->k0 = 0.9996; c->x0 = 500000; if (c->south) c->y0 = 10000000;
        fwd_tmerc(c, lon, lat, x, y); return;
    }
    if (!strcmp(c->proj, "tmerc") || !strcmp(c->proj, "etmerc")) { fwd_tmerc(c, lon, lat, x, y); return; }
    if (!strcmp(c->proj, "webmerc")) {
        *x = c->a * (lon - c->lon0) + c->x0;
        *y = c->a * log(tan(M_PI/4 + lat/2)) + c->y0; return;
    }
    if (!strcmp(c->proj, "merc")) {
        double k = c->k0;
        if (c->lat_ts != 999) k *= msfn(sin(c->lat_ts), cos(c->lat_ts), c->e2);
        *x = c->x0 + c->a * k * (lon - c->lon0);
        *y = c->y0 - c->a * k * log(tsfn(lat, sin(lat), c->e)); return;
    }
    if (!strcmp(c->proj, "eqc") || !strcmp(c->proj, "latlong")) {
        double k = cos(c->lat_ts == 999 ? 0 : c->lat_ts);
        *x = c->x0 + c->a * k * (lon - c->lon0);
        *y = c->y0 + mlfn(c, lat) - mlfn(c, c->lat0); return;
    }
    if (!strcmp(c->proj, "sinu")) { *x = c->x0 + c->a*(lon-c->lon0)*cos(lat); *y = c->y0 + c->a*lat; return; }
    if (!strcmp(c->proj, "mill")) { *x = c->x0 + c->a*(lon-c->lon0); *y = c->y0 + c->a*1.25*log(tan(M_PI/4 + 0.4*lat)); return; }
    if (!strcmp(c->proj, "moll")) {
        double th = lat;
        for (int i=0;i<10;i++) th -= (2*th + sin(2*th) - M_PI*sin(lat)) / (2 + 2*cos(2*th));
        *x = c->x0 + c->a * 2 * sqrt(2) / M_PI * (lon-c->lon0) * cos(th);
        *y = c->y0 + c->a * sqrt(2) * sin(th); return;
    }
    if (!strcmp(c->proj, "ortho")) {
        double dlon = lon - c->lon0;
        *x = c->x0 + c->a * cos(lat) * sin(dlon);
        *y = c->y0 + c->a * (cos(c->lat0)*sin(lat) - sin(c->lat0)*cos(lat)*cos(dlon)); return;
    }
    if (!strcmp(c->proj, "lcc")) {
        double p1 = c->lat1 ? c->lat1 : c->lat0, p2 = c->lat2 ? c->lat2 : p1;
        if (p1 == 0) p1 = 33 * DEG;
        if (p2 == 0) p2 = p1;
        double m1 = msfn(sin(p1), cos(p1), c->e2), t1 = tsfn(p1, sin(p1), c->e);
        double n = sin(p1);
        if (fabs(p1 - p2) > 1e-12) {
            double m2 = msfn(sin(p2), cos(p2), c->e2), t2 = tsfn(p2, sin(p2), c->e);
            n = log(m1 / m2) / log(t1 / t2);
        }
        double F = m1 / (n * pow(t1, n));
        double rho = c->a * F * pow(tsfn(lat, sin(lat), c->e), n);
        double rho0 = c->a * F * pow(tsfn(c->lat0, sin(c->lat0), c->e), n);
        double th = n * (lon - c->lon0);
        *x = c->x0 + c->k0 * rho * sin(th);
        *y = c->y0 + c->k0 * (rho0 - rho * cos(th)); return;
    }
    if (!strcmp(c->proj, "aea")) {
        double p1 = c->lat1 ? c->lat1 : 29.5 * DEG, p2 = c->lat2 ? c->lat2 : 45.5 * DEG;
        double e = c->e;
        #define QFUN(phi) ((1-c->e2)*(sin(phi)/(1-c->e2*sin(phi)*sin(phi)) - (0.5/e)*log((1-e*sin(phi))/(1+e*sin(phi)))))
        double q1 = QFUN(p1), q2 = QFUN(p2), q0 = QFUN(c->lat0), q = QFUN(lat);
        double m1 = msfn(sin(p1), cos(p1), c->e2), m2 = msfn(sin(p2), cos(p2), c->e2);
        double n = (m1*m1 - m2*m2) / (q2 - q1);
        double C = m1*m1 + n*q1;
        double rho = c->a * sqrt(C - n*q) / n, rho0 = c->a * sqrt(C - n*q0) / n;
        double th = n * (lon - c->lon0);
        *x = c->x0 + c->k0 * rho * sin(th);
        *y = c->y0 + c->k0 * (rho0 - rho * cos(th)); return;
        #undef QFUN
    }
    *x = c->x0 + c->a * (lon - c->lon0);
    *y = c->y0 + c->a * lat;
}

static void inverse(Cfg *c, double x, double y, double *lon_deg, double *lat_deg) {
    if (!strcmp(c->proj, "utm")) {
        c->lon0 = ((c->zone > 0 ? c->zone : 31) * 6 - 183) * DEG;
        c->lat0 = 0; c->k0 = 0.9996; c->x0 = 500000; if (c->south) c->y0 = 10000000;
        double lon, lat; inv_tmerc(c, x, y, &lon, &lat); *lon_deg = lon*RAD; *lat_deg = lat*RAD; return;
    }
    if (!strcmp(c->proj, "tmerc") || !strcmp(c->proj, "etmerc")) {
        double lon, lat; inv_tmerc(c, x, y, &lon, &lat); *lon_deg = lon*RAD; *lat_deg = lat*RAD; return;
    }
    if (!strcmp(c->proj, "webmerc")) {
        *lon_deg = ((x - c->x0) / c->a + c->lon0) * RAD;
        *lat_deg = (2 * atan(exp((y - c->y0) / c->a)) - M_PI/2) * RAD; return;
    }
    if (!strcmp(c->proj, "merc")) {
        double k = c->k0; if (c->lat_ts != 999) k *= msfn(sin(c->lat_ts), cos(c->lat_ts), c->e2);
        double t = exp(-(y - c->y0) / (c->a * k));
        double phi = M_PI/2 - 2*atan(t);
        for (int i=0;i<12;i++) phi = M_PI/2 - 2*atan(t * pow((1 - c->e*sin(phi))/(1 + c->e*sin(phi)), c->e/2));
        *lon_deg = ((x - c->x0)/(c->a*k) + c->lon0) * RAD; *lat_deg = phi * RAD; return;
    }
    double k = cos(c->lat_ts == 999 ? 0 : c->lat_ts);
    *lon_deg = ((x-c->x0)/(c->a*k) + c->lon0) * RAD;
    *lat_deg = inv_mlfn(c, y-c->y0+mlfn(c,c->lat0)) * RAD;
}

static void print_dms(double v, int is_lon) {
    char hemi = is_lon ? (v < 0 ? 'W' : 'E') : (v < 0 ? 'S' : 'N');
    v = fabs(v);
    int d = (int)floor(v + 1e-12);
    double rem = (v - d) * 60;
    int m = (int)floor(rem + 1e-12);
    double s = (rem - m) * 60;
    if (s < 0.0005) {
        if (m == 0) printf("%dd%c", d, hemi);
        else printf("%dd%d'%c", d, m, hemi);
    } else {
        printf("%dd%d'%.3f\"%c", d, m, s, hemi);
    }
}

static void output_pair(Cfg *c, double a, double b) {
    if (c->swap_out) { double t=a; a=b; b=t; }
    if (c->inverse && !strcmp(c->fmt, "%.2f")) {
        print_dms(a, 1); putchar('\t'); print_dms(b, 0);
    } else {
        printf(c->fmt, a); putchar('\t'); printf(c->fmt, b);
    }
}

static void process_stream(Cfg *c, FILE *fp) {
    char line[4096];
    while (fgets(line, sizeof line, fp)) {
        if (line[0] == '#') { fputs(line, stdout); continue; }
        char *p = line, *e1, *e2;
        double a = c->inverse ? strtod(p, &e1) : dmstor(p, &e1);
        double b = c->inverse ? strtod(e1, &e2) : dmstor(e1, &e2);
        if (c->reverse_in) { double t=a; a=b; b=t; }
        if (c->echo) fputs(line, stdout);
        double x, y;
        if (c->inverse) {
            inverse(c, a / c->mfac, b / c->mfac, &x, &y);
        } else {
            project(c, a, b, &x, &y); x *= c->mfac * unit_factor(c->units); y *= c->mfac * unit_factor(c->units);
        }
        output_pair(c, x, y);
        fputs(e2, stdout);
    }
}

static void set_ellps(Cfg *c, const char *v) {
    if (!strcmp(v, "sphere")) { c->a = 6370997.0; c->f = 0; }
    else if (!strcmp(v, "clrk66")) { c->a = 6378206.4; double b = 6356583.8; c->f = (c->a-b)/c->a; }
    else { c->a = 6378137.0; c->f = 1.0 / 298.257223563; }
    c->e2 = c->f * (2 - c->f); c->e = sqrt(c->e2);
}

static int parse_plus(Cfg *c, const char *arg) {
    const char *s = arg + 1; char key[64], val[128] = "";
    const char *eq = strchr(s, '=');
    if (eq) { snprintf(key, sizeof key, "%.*s", (int)(eq-s), s); snprintf(val, sizeof val, "%s", eq+1); }
    else snprintf(key, sizeof key, "%s", s);
    if (!strcmp(key, "proj")) snprintf(c->proj, sizeof c->proj, "%s", val);
    else if (!strcmp(key, "datum")) snprintf(c->datum, sizeof c->datum, "%s", val);
    else if (!strcmp(key, "ellps")) { snprintf(c->ellps, sizeof c->ellps, "%s", val); set_ellps(c, val); }
    else if (!strcmp(key, "a")) { c->a = atof(val); c->e2 = c->f*(2-c->f); c->e=sqrt(c->e2); }
    else if (!strcmp(key, "rf")) { c->f = 1.0/atof(val); c->e2=c->f*(2-c->f); c->e=sqrt(c->e2); }
    else if (!strcmp(key, "lon_0")) c->lon0 = atof(val) * DEG;
    else if (!strcmp(key, "lat_0")) c->lat0 = atof(val) * DEG;
    else if (!strcmp(key, "lat_1")) c->lat1 = atof(val) * DEG;
    else if (!strcmp(key, "lat_2")) c->lat2 = atof(val) * DEG;
    else if (!strcmp(key, "lat_ts")) c->lat_ts = atof(val) * DEG;
    else if (!strcmp(key, "k") || !strcmp(key, "k_0")) c->k0 = atof(val);
    else if (!strcmp(key, "x_0")) c->x0 = atof(val);
    else if (!strcmp(key, "y_0")) c->y0 = atof(val);
    else if (!strcmp(key, "zone")) c->zone = atoi(val);
    else if (!strcmp(key, "south")) c->south = 1;
    else if (!strcmp(key, "units")) snprintf(c->units, sizeof c->units, "%s", val);
    return 0;
}

int main(int argc, char **argv) {
    Cfg c; init(&c); c.lat_ts = 999;
    const char *files[128]; int nfiles = 0;
    if (argc == 1) { usage(); return 0; }
    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (a[0] == '+') { parse_plus(&c, a); continue; }
        if (a[0] == '-') {
            if (!strcmp(a, "--help")) { fatal("invalid option: --", NULL); return 1; }
            for (int j=1; a[j]; j++) {
                switch (a[j]) {
                    case 'I': c.inverse = 1; break;
                    case 'r': c.reverse_in = 1; break;
                    case 's': c.swap_out = 1; break;
                    case 'E': c.echo = 1; break;
                    case 'V': c.very_verbose = 1; break;
                    case 'v': c.verbose = 1; break;
                    case 'f': if (a[j+1]) c.fmt = &a[j+1], j = strlen(a)-1; else if (++i < argc) c.fmt = argv[i]; break;
                    case 'm': if (++i < argc) c.mfac = atof(argv[i]); break;
                    case 'l':
                        if (a[j+1] == '\0') { fputs(proj_list, stdout); return 0; }
                        if (a[j+1] == 'P') { fputs(proj_list, stdout); return 0; }
                        if (a[j+1] == 'u') { printf("          mm 0.001                millimetre\n          cm 0.01                 centimetre\n           m 1                    metre\n          ft 0.3048               foot\n       us-ft 0.304800609601219    US survey foot\n          km 1000                 kilometre\n"); return 0; }
                        if (a[j+1] == 'e') { printf("    MERIT a=6378137.0      rf=298.257       MERIT 1983\n    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)\n    WGS84 a=6378137.0      rf=298.257223563 WGS 84\n   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)\n"); return 0; }
                        fatal("invalid list option: %s", a+1); return 1;
                    default: fatal("invalid option: -%c", (char[]){a[j],0}); return 1;
                }
            }
        } else files[nfiles++] = a;
    }
    if (!*c.proj) { usage(); return 0; }
    if (!strcmp(c.proj, "latlong") || !strcmp(c.proj, "longlat") || !strcmp(c.proj, "lonlat") || !strcmp(c.proj, "latlon")) {
        fatal("can't initialize operations that produce angular output coordinates", NULL); return 1;
    }
    if (c.verbose || c.very_verbose) {
        const char *name = !strcmp(c.proj, "merc") ? "Mercator" : (!strcmp(c.proj, "utm") ? "Universal Transverse Mercator (UTM)" : c.proj);
        printf("#%s\n#\tCyl, Sph&Ell\n# +proj=%s", name, c.proj);
        if (*c.datum) printf(" +datum=%s", c.datum);
        printf(" +ellps=%s\n", c.ellps);
        if (c.very_verbose) printf("#Final Earth figure: ellipsoid\n#  Major axis (a): %.3f\n#  1/flattening: %.6f\n#  squared eccentricity: %.12f\n", c.a, c.f ? 1/c.f : 0, c.e2);
        return 0;
    }
    if (nfiles == 0) process_stream(&c, stdin);
    else for (int i=0; i<nfiles; i++) {
        FILE *fp = fopen(files[i], "r");
        if (!fp) { perror(files[i]); continue; }
        process_stream(&c, fp); fclose(fp);
    }
    return 0;
}
