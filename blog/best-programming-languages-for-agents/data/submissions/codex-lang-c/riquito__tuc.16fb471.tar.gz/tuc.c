#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct { long a,b; int has_a,has_b; char *fb; } Bound;
typedef struct { Bound *v; int n, cap; int is_format; char *fmt; } Bounds;
typedef struct { size_t s,e; } Span;
typedef struct {
    int greedy, compress, only_delim, zero, complement, join, join_set, json;
    int no_mmap; int mode; /* 0 fields, 1 bytes, 2 chars, 3 lines */
    char *bounds_s, *delim, *regex_s, *replace, *trim, *fallback;
} Opt;

static void die(const char *m){ fprintf(stderr,"%s\n",m); exit(1); }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) exit(2); return p; }
static void *xrealloc(void *p,size_t n){ void *q=realloc(p,n); if(!q) exit(2); return q; }
static void append_mem(char **o,size_t *l,size_t *c,const char *s,size_t n){ if(!n)return; if(*l+n+1>*c){ while(*l+n+1>*c)*c=*c?*c*2:128; *o=xrealloc(*o,*c);} memcpy(*o+*l,s,n); *l+=n; (*o)[*l]=0; }
static void append_str(char **o,size_t *l,size_t *c,const char *s){ append_mem(o,l,c,s,strlen(s)); }

static char *unescape_arg(const char *s){
    char *o=malloc(strlen(s)+1); size_t j=0;
    for(size_t i=0;s[i];i++){
        if(s[i]=='\\'){
            i++;
            if(!s[i]) { o[j++]='\\'; break; }
            if(s[i]=='t') o[j++]='\t'; else if(s[i]=='n') o[j++]='\n';
            else if(s[i]=='0') o[j++]='\0'; else o[j++]=s[i];
        } else o[j++]=s[i];
    }
    o[j]=0; return o;
}

static void usage(void){
    puts("tuc 1.3.0\nCut text (or bytes) where a delimiter matches, then keep the desired parts.\n\nUSAGE:\n    tuc [FLAGS] [OPTIONS] < input\n    tuc [FLAGS] [OPTIONS] filepath\n\nFLAGS:\n    -g, --greedy-delimiter        Match consecutive delimiters as if it was one\n    -p, --compress-delimiter      Print only the first delimiter of a sequence\n    -s, --only-delimited          Print only lines containing the delimiter\n    -V, --version                 Print version information\n    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)\n    -h, --help                    Print this help and exit\n    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')\n    -j, --(no-)join               Print selected parts with delimiter in between\n    --json                        Print fields as a JSON array of strings\n    --no-mmap                     Disable memory mapping\n\nOPTIONS:\n    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.\n    -b, --bytes <bounds>          Same as --fields, but it keeps bytes\n    -c, --characters <bounds>     Same as --fields, but it keeps characters\n    -l, --lines <bounds>          Same as --fields, but it keeps lines\n    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text\n                                  [default: \\t]\n    -e, --regex <some regex>      Use a regular expression as delimiter\n    -r, --replace-delimiter <new> Replace the delimiter with the provided text.\n    -t, --trim <type>             Trim the delimiter (greedy). Valid values are\n                                  (l|L)eft, (r|R)ight, (b|B)oth\n        --fallback-oob <fallback> Generic fallback output for any field that\n                                  cannot be found (oob stands for out of bound).\n    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.");
}

static void add_bound(Bounds *bs, Bound b){ if(bs->n==bs->cap){bs->cap=bs->cap?bs->cap*2:8; bs->v=xrealloc(bs->v,bs->cap*sizeof(Bound));} bs->v[bs->n++]=b; }
static long parse_long_part(const char *s,int len,int *ok){ char tmp[64]; if(len<=0){*ok=0;return 0;} if(len>63) len=63; memcpy(tmp,s,len); tmp[len]=0; char *e; long v=strtol(tmp,&e,10); *ok=(*e==0); return v; }
static Bounds parse_bounds(const char *s){
    Bounds bs={0};
    if(strchr(s,'{')){ bs.is_format=1; bs.fmt=xstrdup(s); return bs; }
    const char *p=s;
    while(*p){
        const char *q=strchr(p,','); if(!q) q=p+strlen(p);
        const char *eq=memchr(p,'=',q-p); const char *end=eq?eq:q;
        Bound b={0}; if(eq) b.fb=strndup(eq+1,q-eq-1);
        const char *col=memchr(p,':',end-p);
        if(col){ int ok; b.a=parse_long_part(p,col-p,&ok); b.has_a=ok; b.b=parse_long_part(col+1,end-col-1,&ok); b.has_b=ok; }
        else { int ok; b.a=parse_long_part(p,end-p,&ok); b.b=b.a; b.has_a=b.has_b=ok; }
        add_bound(&bs,b); p=(*q)?q+1:q;
    }
    if(bs.n==0) add_bound(&bs,(Bound){.a=1,.b=0,.has_a=1,.has_b=0});
    return bs;
}
static long norm_idx(long x,int n){ return x<0 ? n+1+x : x; }
static int cmp_span(const void *a,const void*b){ const Span *x=a,*y=b; return (x->s>y->s)-(x->s<y->s); }

static char *read_all(const char *path,size_t *len){
    FILE *f= path?fopen(path,"rb"):stdin; if(!f){ perror(path); exit(1); }
    char *buf=NULL; size_t l=0,c=0; char tmp[8192]; size_t n;
    while((n=fread(tmp,1,sizeof tmp,f))>0) append_mem(&buf,&l,&c,tmp,n);
    if(ferror(f)){ perror("read"); exit(1); } if(path) fclose(f);
    if(!buf){ buf=xstrdup(""); c=1; } *len=l; return buf;
}

static char *compress_fixed(const char *line,size_t len,const char *d,size_t dl,size_t *outl){
    if(dl==0){ *outl=len; return strndup(line,len); }
    char *o=NULL; size_t l=0,c=0;
    for(size_t i=0;i<len;){
        if(i+dl<=len && memcmp(line+i,d,dl)==0){ append_mem(&o,&l,&c,d,dl); i+=dl; while(i+dl<=len && memcmp(line+i,d,dl)==0) i+=dl; }
        else append_mem(&o,&l,&c,line+i++,1);
    }
    if(!o) o=xstrdup(""); *outl=l; return o;
}
static void trim_fixed(const char **lp,size_t *len,const char *d,size_t dl,const char *t){
    if(!t||dl==0)return; int left=tolower((unsigned char)t[0])=='l'||tolower((unsigned char)t[0])=='b'; int right=tolower((unsigned char)t[0])=='r'||tolower((unsigned char)t[0])=='b';
    const char *l=*lp; size_t n=*len;
    if(left) while(n>=dl && memcmp(l,d,dl)==0){ l+=dl; n-=dl; }
    if(right) while(n>=dl && memcmp(l+n-dl,d,dl)==0){ n-=dl; }
    *lp=l; *len=n;
}

static Span *split_fixed(const char *line,size_t len,const char *d,size_t dl,int greedy,Span **delims,int *dn,int *fn){
    int cap=8; Span *f=malloc(cap*sizeof* f); *delims=malloc(cap*sizeof**delims); *dn=0; *fn=0; size_t start=0;
    for(size_t i=0; dl && i+dl<=len; ){
        if(memcmp(line+i,d,dl)==0){
            size_t ds=i, de=i+dl; if(greedy) while(de+dl<=len && memcmp(line+de,d,dl)==0) de+=dl;
            if(*fn==cap){cap*=2; f=xrealloc(f,cap*sizeof*f); *delims=xrealloc(*delims,cap*sizeof**delims);}
            f[*fn]=(Span){start,ds}; (*delims)[*dn]=(Span){ds,de}; (*fn)++; (*dn)++; i=de; start=de;
        } else i++;
    }
    if(*fn==cap){cap++; f=xrealloc(f,cap*sizeof*f);} f[(*fn)++]=(Span){start,len}; return f;
}
static Span *split_regex(const char *line,size_t len,const char *pat,Span **delims,int *dn,int *fn){
    regex_t re; if(regcomp(&re,pat,REG_EXTENDED)){ die("invalid regex"); }
    int cap=8; Span *f=malloc(cap*sizeof*f); *delims=malloc(cap*sizeof**delims); *dn=0; *fn=0; size_t off=0,start=0;
    while(off<=len){ regmatch_t m; char *tmp=strndup(line+off,len-off); int r=regexec(&re,tmp,1,&m,0); free(tmp); if(r||m.rm_so<0) break; size_t ds=off+m.rm_so,de=off+m.rm_eo; if(de==ds) de++;
        if(*fn==cap){cap*=2; f=xrealloc(f,cap*sizeof*f); *delims=xrealloc(*delims,cap*sizeof**delims);} f[*fn]=(Span){start,ds}; (*delims)[*dn]=(Span){ds,de}; (*fn)++; (*dn)++; off=de; start=de; }
    if(*fn==cap){cap++; f=xrealloc(f,cap*sizeof*f);} f[(*fn)++]=(Span){start,len}; regfree(&re); return f;
}

static char *json_escape(const char *s,size_t n){ char *o=NULL; size_t l=0,c=0; for(size_t i=0;i<n;i++){ unsigned char ch=s[i]; if(ch=='"'||ch=='\\'){ char b[2]={'\\',ch}; append_mem(&o,&l,&c,b,2);} else if(ch=='\n') append_str(&o,&l,&c,"\\n"); else if(ch=='\r') append_str(&o,&l,&c,"\\r"); else if(ch=='\t') append_str(&o,&l,&c,"\\t"); else append_mem(&o,&l,&c,(char*)&ch,1);} if(!o)o=xstrdup(""); return o; }

static int emit_bounds(const char *base, Span *fields, int nf, Span *delims, int nd, Bounds *bs, Opt *opt, char recsep, char **out,size_t *ol,size_t *oc, int add_sep){
    int err=0, emitted=0; char *sep = opt->replace ? opt->replace : opt->delim;
    if(opt->json) append_str(out,ol,oc,"[");
    for(int bi=0; bi<bs->n; bi++){
        Bound b=bs->v[bi]; long a=b.has_a?norm_idx(b.a,nf):1; long z=b.has_b?norm_idx(b.b,nf):nf;
        if(opt->complement) continue;
        if(a<1||a>nf||z<1||z>nf){ const char *fb=b.fb?b.fb:opt->fallback; if(fb){ if(opt->json){ if(emitted) append_str(out,ol,oc,","); char *e=json_escape(fb,strlen(fb)); append_str(out,ol,oc,"\""); append_str(out,ol,oc,e); append_str(out,ol,oc,"\""); free(e);} else append_str(out,ol,oc,fb); emitted++; } else { fprintf(stderr,"Error: Out of bounds: %ld\n",(a<1||a>nf)?(b.has_a?b.a:a):(b.has_b?b.b:z)); err=1; } continue; }
        int step = a<=z?1:-1;
        if(!opt->join && !opt->json && step==1 && a!=z){
            if(emitted && opt->join_set) append_str(out,ol,oc,sep);
            append_mem(out,ol,oc,base+fields[a-1].s, fields[z-1].e-fields[a-1].s); emitted++; continue;
        }
        for(long k=a;;k+=step){
            if((opt->join||opt->replace||opt->json) && emitted){ if(opt->json) append_str(out,ol,oc,","); else append_str(out,ol,oc,sep); }
            if(opt->json){ char *e=json_escape(base+fields[k-1].s,fields[k-1].e-fields[k-1].s); append_str(out,ol,oc,"\""); append_str(out,ol,oc,e); append_str(out,ol,oc,"\""); free(e); }
            else append_mem(out,ol,oc,base+fields[k-1].s, fields[k-1].e-fields[k-1].s);
            emitted++; if(k==z)break;
        }
    }
    if(opt->complement){
        bool *sel=calloc(nf+1,sizeof(bool));
        for(int bi=0;bi<bs->n;bi++){ long a=bs->v[bi].has_a?norm_idx(bs->v[bi].a,nf):1; long z=bs->v[bi].has_b?norm_idx(bs->v[bi].b,nf):nf; if(a>=1&&a<=nf&&z>=1&&z<=nf){ int st=a<=z?1:-1; for(long k=a;;k+=st){ sel[k]=1; if(k==z)break; }}}
        for(int k=1;k<=nf;k++) if(!sel[k]){ if((opt->join||opt->replace||opt->json)&&emitted){ if(opt->json)append_str(out,ol,oc,","); else append_str(out,ol,oc,sep);} if(opt->json){ char *e=json_escape(base+fields[k-1].s,fields[k-1].e-fields[k-1].s); append_str(out,ol,oc,"\""); append_str(out,ol,oc,e); append_str(out,ol,oc,"\""); free(e);} else append_mem(out,ol,oc,base+fields[k-1].s,fields[k-1].e-fields[k-1].s); emitted++; }
        free(sel);
    }
    if(opt->json) append_str(out,ol,oc,"]");
    if(add_sep && (emitted > 0 || opt->json)) append_mem(out,ol,oc,&recsep,1);
    (void)delims; (void)nd; return err;
}

static int emit_format(const char *base, Span *fields, int nf, Bounds *bs, Opt *opt, char recsep, char **out,size_t *ol,size_t *oc,int add_sep){
    int err=0; size_t start_len=*ol; const char *p=bs->fmt;
    while(*p){
        if(p[0]=='{'&&p[1]=='{'){ append_mem(out,ol,oc,"{",1); p+=2; }
        else if(p[0]=='}'&&p[1]=='}'){ append_mem(out,ol,oc,"}",1); p+=2; }
        else if(*p=='{'){ const char *q=strchr(p,'}'); if(!q){ append_mem(out,ol,oc,p++,1); continue; } char *inside=strndup(p+1,q-p-1); Bounds sub=parse_bounds(inside); free(inside); err|=emit_bounds(base,fields,nf,NULL,0,&sub,opt,recsep,out,ol,oc,0); free(sub.v); p=q+1; }
        else append_mem(out,ol,oc,p++,1);
    }
    if(add_sep && *ol > start_len) append_mem(out,ol,oc,&recsep,1); return err;
}

static int process_fields_record(const char *rec,size_t len,Bounds *bs,Opt *opt,char recsep,char **out,size_t *ol,size_t *oc,int add_sep){
    size_t clen=len; char *comp=NULL; const char *line=rec; if(opt->compress && !opt->regex_s){ comp=compress_fixed(rec,len,opt->delim,strlen(opt->delim),&clen); line=comp; }
    trim_fixed(&line,&clen,opt->delim,strlen(opt->delim),opt->trim);
    Span *delims=NULL; int nd=0,nf=0; Span *fields= opt->regex_s?split_regex(line,clen,opt->regex_s,&delims,&nd,&nf):split_fixed(line,clen,opt->delim,strlen(opt->delim),opt->greedy||opt->compress,&delims,&nd,&nf);
    if(opt->only_delim && nd==0){ free(fields); free(delims); free(comp); return 0; }
    int e = bs->is_format ? emit_format(line,fields,nf,bs,opt,recsep,out,ol,oc,add_sep) : emit_bounds(line,fields,nf,delims,nd,bs,opt,recsep,out,ol,oc,add_sep);
    free(fields); free(delims); free(comp); return e;
}

static Span *char_spans(const char *s,size_t len,int *n){
    int cap=16; Span *v=malloc(cap*sizeof*v); *n=0;
    for(size_t i=0;i<len;){ size_t st=i; unsigned char c=s[i]; size_t w=(c<0x80)?1:((c&0xE0)==0xC0?2:((c&0xF0)==0xE0?3:((c&0xF8)==0xF0?4:1))); if(i+w>len) w=1; i+=w; if(*n==cap){cap*=2; v=xrealloc(v,cap*sizeof*v);} v[(*n)++]=(Span){st,i}; }
    return v;
}

static int process_unit_spans(const char *base, Span *sp, int n, Bounds *bs, Opt *opt, char recsep, char **out,size_t *ol,size_t *oc,int add_sep){
    return bs->is_format?emit_format(base,sp,n,bs,opt,recsep,out,ol,oc,add_sep):emit_bounds(base,sp,n,NULL,0,bs,opt,recsep,out,ol,oc,add_sep);
}

static void parse_args(int argc,char **argv,Opt *o,char **file){
    o->delim=xstrdup("\t"); o->bounds_s=xstrdup("1:");
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        #define NEED() do{ if(i+1>=argc) { fprintf(stderr,"the '%s' option doesn't have an associated value\n",a); exit(1);} }while(0)
        if(!strcmp(a,"-h")||!strcmp(a,"--help")){ usage(); exit(0); }
        else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("tuc 1.3.0"); exit(0); }
        else if(!strcmp(a,"-g")||!strcmp(a,"--greedy-delimiter")) o->greedy=1;
        else if(!strcmp(a,"-p")||!strcmp(a,"--compress-delimiter")) o->compress=1;
        else if(!strcmp(a,"-s")||!strcmp(a,"--only-delimited")) o->only_delim=1;
        else if(!strcmp(a,"-z")||!strcmp(a,"--zero-terminated")) o->zero=1;
        else if(!strcmp(a,"-m")||!strcmp(a,"--complement")) o->complement=1;
        else if(!strcmp(a,"-j")||!strcmp(a,"--join")){ o->join=1; o->join_set=1; }
        else if(!strcmp(a,"--no-join")){ o->join=0; o->join_set=1; }
        else if(!strcmp(a,"--json")) o->json=1;
        else if(!strcmp(a,"--no-mmap")) o->no_mmap=1;
        else if(!strcmp(a,"-f")||!strcmp(a,"--fields")){ NEED(); free(o->bounds_s); o->bounds_s=xstrdup(argv[++i]); o->mode=0; }
        else if(!strcmp(a,"-b")||!strcmp(a,"--bytes")){ NEED(); free(o->bounds_s); o->bounds_s=xstrdup(argv[++i]); o->mode=1; }
        else if(!strcmp(a,"-c")||!strcmp(a,"--characters")){ NEED(); free(o->bounds_s); o->bounds_s=xstrdup(argv[++i]); o->mode=2; }
        else if(!strcmp(a,"-l")||!strcmp(a,"--lines")){ NEED(); free(o->bounds_s); o->bounds_s=xstrdup(argv[++i]); o->mode=3; if(!o->join_set)o->join=1; }
        else if(!strcmp(a,"-d")||!strcmp(a,"--delimiter")){ NEED(); free(o->delim); o->delim=unescape_arg(argv[++i]); }
        else if(!strcmp(a,"-e")||!strcmp(a,"--regex")){ NEED(); o->regex_s=xstrdup(argv[++i]); }
        else if(!strcmp(a,"-r")||!strcmp(a,"--replace-delimiter")){ NEED(); o->replace=unescape_arg(argv[++i]); o->join=1; o->join_set=1; }
        else if(!strcmp(a,"-t")||!strcmp(a,"--trim")){ NEED(); o->trim=xstrdup(argv[++i]); }
        else if(!strcmp(a,"--fallback-oob")){ NEED(); o->fallback=xstrdup(argv[++i]); }
        else if(!strcmp(a,"-M")||!strcmp(a,"--fixed-memory")){ NEED(); i++; }
        else if(a[0]=='-'){ fprintf(stderr,"tuc: unexpected arguments: [\"%s\"]\nTry 'tuc --help' for more information.\n",a); exit(1); }
        else *file=a;
    }
}

int main(int argc,char **argv){
    Opt opt={0}; char *file=NULL; parse_args(argc,argv,&opt,&file); Bounds bs=parse_bounds(opt.bounds_s);
    size_t len=0; char *buf=read_all(file,&len); char *out=NULL; size_t ol=0,oc=0; int err=0; char recsep= opt.zero?'\0':'\n';
    if(opt.mode==3 && !opt.replace) {
        free(opt.delim);
        opt.delim = xstrdup(opt.zero ? "" : "\n");
    }
    if(opt.mode==1){
        Span *sp=malloc((len?len:1)*sizeof*sp); for(size_t i=0;i<len;i++) sp[i]=(Span){i,i+1}; err=process_unit_spans(buf,sp,(int)len,&bs,&opt,recsep,&out,&ol,&oc,0); free(sp);
    } else if(opt.mode==3){
        int cap=16,n=0; Span *sp=malloc(cap*sizeof*sp); size_t st=0; for(size_t i=0;i<len;i++) if(buf[i]==recsep){ if(n==cap){cap*=2; sp=xrealloc(sp,cap*sizeof*sp);} sp[n++]=(Span){st,i}; st=i+1; } if(st<len){ if(n==cap){cap++; sp=xrealloc(sp,cap*sizeof*sp);} sp[n++]=(Span){st,len}; }
        err=process_unit_spans(buf,sp,n,&bs,&opt,recsep,&out,&ol,&oc,0); free(sp);
    } else {
        size_t st=0; for(size_t i=0;i<=len;i++){ if(i==len || buf[i]==recsep){ if(i==len && st==len) break; size_t rlen=i-st; if(opt.mode==2){ int cn=0; Span *sp=char_spans(buf+st,rlen,&cn); err|=process_unit_spans(buf+st,sp,cn,&bs,&opt,recsep,&out,&ol,&oc,i<len); free(sp); } else err|=process_fields_record(buf+st,rlen,&bs,&opt,recsep,&out,&ol,&oc,i<len); st=i+1; } }
    }
    if(ol) fwrite(out,1,ol,stdout); free(out); free(buf); return err?1:0;
}
