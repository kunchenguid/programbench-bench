#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/icmp6.h>
#include <netinet/ip_icmp.h>
#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t interrupted = 0;

static const char *penguins[] = {
    " ...        .     ...   ..    ..     .........           ",
    " ...     ....          ..  ..      ... .....  .. ..      ",
    " ...    .......      ...         ... . ..... #######     ",
    ".....  ........ .###############.....  ... ##########.  .",
    " .... ........#####################.  ... ###########    ",
};

static void onint(int sig) {
    (void)sig;
    interrupted = 1;
}

static void usage(void) {
    printf("Usage:\n");
    printf("  pingu [OPTIONS] HOST\n\n");
    printf("`ping` command but with pingu\n\n");
    printf("Application Options:\n");
    printf("  -c, --count=     Stop after <count> replies (default: 20)\n");
    printf("  -P, --privilege  Enable privileged mode\n");
    printf("  -V, --version    Show version\n\n");
    printf("Help Options:\n");
    printf("  -h, --help       Show this help message\n");
}

static unsigned short checksum(const void *data, size_t len) {
    const unsigned char *p = data;
    unsigned long sum = 0;
    while (len > 1) {
        sum += (unsigned short)((p[0] << 8) | p[1]);
        p += 2;
        len -= 2;
    }
    if (len) sum += (unsigned short)(p[0] << 8);
    while (sum >> 16) sum = (sum & 0xffff) + (sum >> 16);
    return (unsigned short)~sum;
}

static double now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (double)tv.tv_sec * 1000.0 + (double)tv.tv_usec / 1000.0;
}

static void fmt_duration(double ms, char *buf, size_t n) {
    if (ms <= 0.0) {
        snprintf(buf, n, "0s");
    } else if (ms < 1.0) {
        double us = ms * 1000.0;
        if (us >= 100.0)
            snprintf(buf, n, "%.3gµs", us);
        else
            snprintf(buf, n, "%.3gµs", us);
    } else {
        snprintf(buf, n, "%.6gms", ms);
    }
}

static int parse_int(const char *s, int *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) return -1;
    *out = (int)v;
    return 0;
}

static const char *nameserver(void) {
    static char ns[128] = "192.168.65.7";
    FILE *f = fopen("/etc/resolv.conf", "r");
    if (!f) return ns;
    char line[256];
    while (fgets(line, sizeof line, f)) {
        char ip[120];
        if (sscanf(line, "nameserver %119s", ip) == 1) {
            strncpy(ns, ip, sizeof ns - 1);
            ns[sizeof ns - 1] = 0;
            break;
        }
    }
    fclose(f);
    return ns;
}

static int parse_args(int argc, char **argv, int *count, bool *priv, const char **host) {
    *count = 20;
    *priv = false;
    *host = NULL;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "--help")) {
            usage();
            exit(0);
        } else if (!strcmp(a, "--version")) {
            puts("pingu: v-rev9c2e3df");
            exit(0);
        } else if (!strcmp(a, "--privilege")) {
            *priv = true;
        } else if (!strcmp(a, "--count")) {
            if (i + 1 >= argc) {
                puts("expected argument for flag `-c, --count'");
                puts("[ ERROR ] parse error: expected argument for flag `-c, --count'");
                return 1;
            }
            if (parse_int(argv[++i], count)) {
                printf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", argv[i]);
                printf("[ ERROR ] parse error: invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", argv[i]);
                return 1;
            }
        } else if (!strncmp(a, "--count=", 8)) {
            const char *v = a + 8;
            if (parse_int(v, count)) {
                printf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", v);
                printf("[ ERROR ] parse error: invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", v);
                return 1;
            }
        } else if (!strncmp(a, "--", 2)) {
            printf("unknown flag `%s'\n", a + 2);
            printf("[ ERROR ] parse error: unknown flag `%s'\n", a + 2);
            return 1;
        } else if (a[0] == '-' && a[1]) {
            if (!strcmp(a, "-c")) {
                if (i + 1 >= argc) {
                    puts("expected argument for flag `-c, --count'");
                    puts("[ ERROR ] parse error: expected argument for flag `-c, --count'");
                    return 1;
                }
                if (parse_int(argv[++i], count)) {
                    printf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", argv[i]);
                    printf("[ ERROR ] parse error: invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", argv[i]);
                    return 1;
                }
            } else if (!strncmp(a, "-c=", 3) || (a[0] == '-' && a[1] == 'c' && a[2])) {
                const char *v = a[2] == '=' ? a + 3 : a + 2;
                if (parse_int(v, count)) {
                    printf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", v);
                    printf("[ ERROR ] parse error: invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", v);
                    return 1;
                }
            } else {
                for (int j = 1; a[j]; j++) {
                    if (a[j] == 'h') {
                        usage();
                        exit(0);
                    } else if (a[j] == 'V') {
                        puts("pingu: v-rev9c2e3df");
                        exit(0);
                    } else if (a[j] == 'P') {
                        *priv = true;
                    } else {
                        printf("unknown flag `%c'\n", a[j]);
                        printf("[ ERROR ] parse error: unknown flag `%c'\n", a[j]);
                        return 1;
                    }
                }
            }
        } else {
            if (*host) {
                puts("[ ERROR ] too many arguments");
                return 1;
            }
            *host = a;
        }
    }
    if (!*host) {
        puts("[ ERROR ] must requires an argument");
        return 1;
    }
    return 0;
}

static int make_packet(int family, unsigned short seq, unsigned short id, unsigned char *buf, size_t len) {
    memset(buf, 0, len);
    if (family == AF_INET) {
        struct icmphdr *h = (struct icmphdr *)buf;
        h->type = ICMP_ECHO;
        h->code = 0;
        h->un.echo.id = htons(id);
        h->un.echo.sequence = htons(seq);
        for (size_t i = sizeof *h; i < len; i++) buf[i] = (unsigned char)i;
        h->checksum = checksum(buf, len);
    } else {
        struct icmp6_hdr *h = (struct icmp6_hdr *)buf;
        h->icmp6_type = ICMP6_ECHO_REQUEST;
        h->icmp6_code = 0;
        h->icmp6_id = htons(id);
        h->icmp6_seq = htons(seq);
        for (size_t i = sizeof *h; i < len; i++) buf[i] = (unsigned char)i;
    }
    return (int)len;
}

static bool is_reply(int family, unsigned char *buf, ssize_t n, unsigned short seq, bool raw) {
    if (family == AF_INET) {
        size_t off = 0;
        if (raw && n >= 20) off = (buf[0] & 0x0f) * 4;
        if (n < (ssize_t)(off + sizeof(struct icmphdr))) return false;
        struct icmphdr *h = (struct icmphdr *)(buf + off);
        return h->type == ICMP_ECHOREPLY && ntohs(h->un.echo.sequence) == seq;
    } else {
        if (n < (ssize_t)sizeof(struct icmp6_hdr)) return false;
        struct icmp6_hdr *h = (struct icmp6_hdr *)buf;
        return h->icmp6_type == ICMP6_ECHO_REPLY && ntohs(h->icmp6_seq) == seq;
    }
}

int main(int argc, char **argv) {
    int count;
    bool priv;
    const char *host;
    int pr = parse_args(argc, argv, &count, &priv, &host);
    if (pr) return pr;

    struct addrinfo hints, *res = NULL;
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    int gai = getaddrinfo(host, NULL, &hints, &res);
    if (gai || !res) {
        printf("[ ERROR ] an error occurred while initializing pinger: failed to init pinger lookup %s on %s:53: dial udp %s:53: connect: network is unreachable\n", host, nameserver(), nameserver());
        return 0;
    }

    int family = res->ai_family;
    char ip[INET6_ADDRSTRLEN];
    void *addrp = NULL;
    if (family == AF_INET) {
        addrp = &((struct sockaddr_in *)res->ai_addr)->sin_addr;
    } else {
        addrp = &((struct sockaddr_in6 *)res->ai_addr)->sin6_addr;
    }
    inet_ntop(family, addrp, ip, sizeof ip);
    printf("PING %s (%s) type `Ctrl-C` to abort\n", host, ip);
    fflush(stdout);

    int socktype = priv ? SOCK_RAW : SOCK_DGRAM;
    int proto = family == AF_INET ? IPPROTO_ICMP : IPPROTO_ICMPV6;
    int fd = socket(family, socktype, proto);
    if (fd < 0) {
        printf("[ ERROR ] an error occurred when running ping: listen %s:icmp : socket: operation not permitted\n", family == AF_INET ? "ip4" : "ip6");
        freeaddrinfo(res);
        return 2;
    }
    struct timeval tv = {1, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    signal(SIGINT, onint);

    int limit = count <= 0 ? 2147483647 : count;
    int transmitted = 0, received = 0;
    double min = 0, max = 0, sum = 0, sumsq = 0;
    unsigned short id = (unsigned short)getpid();
    int run_error = 0;

    for (int seq = 0; seq < limit && !interrupted; seq++) {
        unsigned char pkt[32], recvbuf[1500];
        make_packet(family, (unsigned short)seq, id, pkt, sizeof pkt);
        double start = now_ms();
        ssize_t sent = sendto(fd, pkt, sizeof pkt, 0, res->ai_addr, res->ai_addrlen);
        if (sent < 0) {
            printf("\n───────── %s ping statistics ─────────\n", host);
            printf("PACKET STATISTICS: %d transmitted => %d received (0%% loss)\n", transmitted, received);
            printf("ROUND TRIP: min=0s avg=0s max=0s stddev=0s\n");
            const char *msg = errno == ENETUNREACH ? "network is unreachable" : strerror(errno);
            printf("[ ERROR ] an error occurred when running ping: write udp 0.0.0.0:9888->%s:0: sendmsg: %s\n", ip, msg);
            run_error = 2;
            break;
        }
        transmitted++;
        while (!interrupted) {
            ssize_t n = recv(fd, recvbuf, sizeof recvbuf, 0);
            if (n < 0) break;
            if (is_reply(family, recvbuf, n, (unsigned short)seq, priv)) {
                double elapsed = now_ms() - start;
                char tbuf[64];
                fmt_duration(elapsed, tbuf, sizeof tbuf);
                printf("%s seq=%d 32bytes from %s: ttl=64 time=%s\n", penguins[seq % 5], seq, ip, tbuf);
                fflush(stdout);
                received++;
                if (received == 1 || elapsed < min) min = elapsed;
                if (received == 1 || elapsed > max) max = elapsed;
                sum += elapsed;
                sumsq += elapsed * elapsed;
                break;
            }
        }
        if (seq + 1 < limit && !interrupted) sleep(1);
    }

    if (!run_error) {
        printf("\n───────── %s ping statistics ─────────\n", host);
        int loss = transmitted ? (int)((transmitted - received) * 100 / transmitted) : 0;
        printf("PACKET STATISTICS: %d transmitted => %d received (%d%% loss)\n", transmitted, received, loss);
        if (received) {
            double avg = sum / received;
            double var = sumsq / received - avg * avg;
            if (var < 0) var = 0;
            char a[64], b[64], c[64], d[64];
            fmt_duration(min, a, sizeof a);
            fmt_duration(avg, b, sizeof b);
            fmt_duration(max, c, sizeof c);
            fmt_duration(sqrt(var), d, sizeof d);
            printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s\n", a, b, c, d);
        } else {
            printf("ROUND TRIP: min=0s avg=0s max=0s stddev=0s\n");
        }
    }

    close(fd);
    freeaddrinfo(res);
    return run_error;
}
