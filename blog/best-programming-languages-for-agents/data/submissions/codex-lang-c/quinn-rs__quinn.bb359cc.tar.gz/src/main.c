#define _POSIX_C_SOURCE 200809L

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <netdb.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    const char *listen;
    const char *host;
    const char *ip;
    const char *local_addr;
    const char *json_path;
    const char *congestion;
    const char *key;
    const char *cert;
    const char *qlog;
    uint64_t uni_requests, bi_requests, download_size, upload_size;
    uint64_t duration, interval, send_buffer_size, recv_buffer_size;
    uint64_t initial_mtu, initial_rtt, max_udp_payload_size;
    uint64_t stream_receive_window, receive_window, send_window;
    bool conn_stats, keylog, no_protection, ack_frequency;
} Config;

static void top_help(void) {
    puts("Usage: executable <COMMAND>\n");
    puts("Commands:");
    puts("  server  Run as a perf server");
    puts("  client  Run as a perf client");
    puts("  help    Print this message or the help of the given subcommand(s)\n");
    puts("Options:");
    puts("  -h, --help  Print help");
}

static void client_help_full(void) {
    puts("Run as a perf client\n");
    puts("Usage: executable client [OPTIONS] [HOST]\n");
    puts("Arguments:");
    puts("  [HOST]");
    puts("          Host to connect to");
    puts("          ");
    puts("          [default: localhost:4433]\n");
    puts("Options:");
    puts("      --ip <IP>");
    puts("          Override DNS resolution for host\n");
    puts("      --local-addr <LOCAL_ADDR>");
    puts("          Specify the local socket address\n");
    puts("      --uni-requests <UNI_REQUESTS>");
    puts("          Number of unidirectional requests to maintain concurrently");
    puts("          ");
    puts("          [default: 0]\n");
    puts("      --bi-requests <BI_REQUESTS>");
    puts("          Number of bidirectional requests to maintain concurrently");
    puts("          ");
    puts("          [default: 1]\n");
    puts("      --download-size <DOWNLOAD_SIZE>");
    puts("          Number of bytes to request");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.");
    puts("          ");
    puts("          [default: 1M]\n");
    puts("      --upload-size <UPLOAD_SIZE>");
    puts("          Number of bytes to transmit, in addition to the request header");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.");
    puts("          ");
    puts("          [default: 1M]\n");
    puts("      --duration <DURATION>");
    puts("          The time to run in seconds");
    puts("          ");
    puts("          [default: 60]\n");
    puts("      --interval <INTERVAL>");
    puts("          The interval in seconds at which stats are reported");
    puts("          ");
    puts("          [default: 1]\n");
    puts("      --json <JSON>");
    puts("          File path to output JSON statistics to. If the file is '-', stdout will be used\n");
    puts("      --send-buffer-size <SEND_BUFFER_SIZE>");
    puts("          Send buffer size in bytes");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.");
    puts("          ");
    puts("          [default: 2M]\n");
    puts("      --recv-buffer-size <RECV_BUFFER_SIZE>");
    puts("          Receive buffer size in bytes");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.");
    puts("          ");
    puts("          [default: 2M]\n");
    puts("      --conn-stats");
    puts("          Whether to print connection statistics\n");
    puts("      --keylog");
    puts("          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n");
    puts("      --initial-mtu <INITIAL_MTU>");
    puts("          UDP payload size that the network must be capable of carrying");
    puts("          ");
    puts("          [default: 1200]\n");
    puts("      --no-protection");
    puts("          Disable packet encryption/decryption (for debugging purpose)\n");
    puts("      --initial-rtt <INITIAL_RTT>");
    puts("          The initial round-trip-time (in msecs)\n");
    puts("      --ack-frequency");
    puts("          Ack Frequency mode\n");
    puts("      --congestion <CONG_ALG>");
    puts("          Congestion algorithm to use");
    puts("          ");
    puts("          [possible values: cubic, bbr, new-reno]\n");
    puts("      --stream-receive-window <STREAM_RECEIVE_WINDOW>");
    puts("          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n");
    puts("      --receive-window <RECEIVE_WINDOW>");
    puts("          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n");
    puts("      --send-window <SEND_WINDOW>");
    puts("          Maximum number of bytes to transmit to a peer without acknowledgment");
    puts("          ");
    puts("          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n");
    puts("      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>");
    puts("          Max UDP payload size in bytes");
    puts("          ");
    puts("          [default: 1472]\n");
    puts("      --qlog <QLOG_FILE>");
    puts("          qlog output file\n");
    puts("  -h, --help");
    puts("          Print help (see a summary with '-h')");
}

static void client_help_short(void) {
    puts("Run as a perf client\n");
    puts("Usage: executable client [OPTIONS] [HOST]\n");
    puts("Arguments:");
    puts("  [HOST]  Host to connect to [default: localhost:4433]\n");
    puts("Options:");
    puts("      --ip <IP>\n          Override DNS resolution for host");
    puts("      --local-addr <LOCAL_ADDR>\n          Specify the local socket address");
    puts("      --uni-requests <UNI_REQUESTS>\n          Number of unidirectional requests to maintain concurrently [default: 0]");
    puts("      --bi-requests <BI_REQUESTS>\n          Number of bidirectional requests to maintain concurrently [default: 1]");
    puts("      --download-size <DOWNLOAD_SIZE>\n          Number of bytes to request [default: 1M]");
    puts("      --upload-size <UPLOAD_SIZE>\n          Number of bytes to transmit, in addition to the request header [default: 1M]");
    puts("      --duration <DURATION>\n          The time to run in seconds [default: 60]");
    puts("      --interval <INTERVAL>\n          The interval in seconds at which stats are reported [default: 1]");
    puts("      --json <JSON>\n          File path to output JSON statistics to. If the file is '-', stdout will be used");
    puts("      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes [default: 2M]");
    puts("      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes [default: 2M]");
    puts("      --conn-stats\n          Whether to print connection statistics");
    puts("      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`");
    puts("      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying [default: 1200]");
    puts("      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)");
    puts("      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)");
    puts("      --ack-frequency\n          Ack Frequency mode");
    puts("      --congestion <CONG_ALG>\n          Congestion algorithm to use [possible values: cubic, bbr, new-reno]");
    puts("      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked");
    puts("      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked");
    puts("      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment");
    puts("      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes [default: 1472]");
    puts("      --qlog <QLOG_FILE>\n          qlog output file");
    puts("  -h, --help\n          Print help (see more with '--help')");
}

static void server_help_full(void) {
    puts("Run as a perf server\n");
    puts("Usage: executable server [OPTIONS]\n");
    puts("Options:");
    puts("      --listen <LISTEN>\n          Address to listen on\n          \n          [default: [::]:4433]\n");
    puts("  -k, --key <KEY>\n          TLS private key in DER format\n");
    puts("  -c, --cert <CERT>\n          TLS certificate in PEM format\n");
    puts("      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes\n          \n          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n          \n          [default: 2M]\n");
    puts("      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes\n          \n          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n          \n          [default: 2M]\n");
    puts("      --conn-stats\n          Whether to print connection statistics\n");
    puts("      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n");
    puts("      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying\n          \n          [default: 1200]\n");
    puts("      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)\n");
    puts("      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)\n");
    puts("      --ack-frequency\n          Ack Frequency mode\n");
    puts("      --congestion <CONG_ALG>\n          Congestion algorithm to use\n          \n          [possible values: cubic, bbr, new-reno]\n");
    puts("      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n");
    puts("      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n");
    puts("      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n");
    puts("      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes\n          \n          [default: 1472]\n");
    puts("      --qlog <QLOG_FILE>\n          qlog output file\n");
    puts("  -h, --help\n          Print help (see a summary with '-h')");
}

static void server_help_short(void) {
    puts("Run as a perf server\n");
    puts("Usage: executable server [OPTIONS]\n");
    puts("Options:");
    puts("      --listen <LISTEN>\n          Address to listen on [default: [::]:4433]");
    puts("  -k, --key <KEY>\n          TLS private key in DER format");
    puts("  -c, --cert <CERT>\n          TLS certificate in PEM format");
    puts("      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes [default: 2M]");
    puts("      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes [default: 2M]");
    puts("      --conn-stats\n          Whether to print connection statistics");
    puts("      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`");
    puts("      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying [default: 1200]");
    puts("      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)");
    puts("      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)");
    puts("      --ack-frequency\n          Ack Frequency mode");
    puts("      --congestion <CONG_ALG>\n          Congestion algorithm to use [possible values: cubic, bbr, new-reno]");
    puts("      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked");
    puts("      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked");
    puts("      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment");
    puts("      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes [default: 1472]");
    puts("      --qlog <QLOG_FILE>\n          qlog output file");
    puts("  -h, --help\n          Print help (see more with '--help')");
}

static bool parse_u64_plain(const char *s, uint64_t *out) {
    if (!s || !*s) return false;
    char *end = NULL;
    errno = 0;
    unsigned long long v = strtoull(s, &end, 10);
    if (errno || end == s || *end) return false;
    *out = (uint64_t)v;
    return true;
}

static bool parse_size(const char *s, uint64_t *out) {
    if (!s || !*s) return false;
    char *end = NULL;
    errno = 0;
    unsigned long long v = strtoull(s, &end, 10);
    if (errno || end == s) return false;
    uint64_t mult = 1;
    if (*end) {
        if ((end[0] == 'M' || end[0] == 'm') && end[1] == '\0') mult = 1024ULL * 1024ULL;
        else if ((end[0] == 'G' || end[0] == 'g') && end[1] == '\0') mult = 1024ULL * 1024ULL * 1024ULL;
        else return false;
    }
    *out = (uint64_t)v * mult;
    return true;
}

static void invalid_value(const char *value, const char *opt, const char *name) {
    fprintf(stderr, "error: invalid value '%s' for '%s <%s>': invalid digit found in string\n\nFor more information, try '--help'.\n", value, opt, name);
}

static void missing_value(const char *opt) {
    fprintf(stderr, "error: a value is required for '%s <...>' but none was supplied\n\nFor more information, try '--help'.\n", opt);
}

static int require_value(int *i, int argc, char **argv, const char **val) {
    if (*i + 1 >= argc) {
        missing_value(argv[*i]);
        return 0;
    }
    *val = argv[++(*i)];
    return 1;
}

static int parse_common(Config *cfg, int *i, int argc, char **argv, bool server) {
    const char *a = argv[*i], *v = NULL;
    uint64_t tmp = 0;
    if (!strcmp(a, "--send-buffer-size")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_size(v, &cfg->send_buffer_size)) { invalid_value(v, a, "SEND_BUFFER_SIZE"); return -1; }
    } else if (!strcmp(a, "--recv-buffer-size")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_size(v, &cfg->recv_buffer_size)) { invalid_value(v, a, "RECV_BUFFER_SIZE"); return -1; }
    } else if (!strcmp(a, "--conn-stats")) cfg->conn_stats = true;
    else if (!strcmp(a, "--keylog")) cfg->keylog = true;
    else if (!strcmp(a, "--initial-mtu")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_u64_plain(v, &cfg->initial_mtu)) { invalid_value(v, a, "INITIAL_MTU"); return -1; }
    } else if (!strcmp(a, "--no-protection")) cfg->no_protection = true;
    else if (!strcmp(a, "--initial-rtt")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_u64_plain(v, &cfg->initial_rtt)) { invalid_value(v, a, "INITIAL_RTT"); return -1; }
    } else if (!strcmp(a, "--ack-frequency")) cfg->ack_frequency = true;
    else if (!strcmp(a, "--congestion")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (strcmp(v, "cubic") && strcmp(v, "bbr") && strcmp(v, "new-reno")) {
            fprintf(stderr, "error: invalid value '%s' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]\n\nFor more information, try '--help'.\n", v);
            return -1;
        }
        cfg->congestion = v;
    } else if (!strcmp(a, "--stream-receive-window")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_size(v, &tmp)) { invalid_value(v, a, "STREAM_RECEIVE_WINDOW"); return -1; }
        cfg->stream_receive_window = tmp;
    } else if (!strcmp(a, "--receive-window")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_size(v, &tmp)) { invalid_value(v, a, "RECEIVE_WINDOW"); return -1; }
        cfg->receive_window = tmp;
    } else if (!strcmp(a, "--send-window")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_size(v, &tmp)) { invalid_value(v, a, "SEND_WINDOW"); return -1; }
        cfg->send_window = tmp;
    } else if (!strcmp(a, "--max-udp-payload-size")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        if (!parse_u64_plain(v, &cfg->max_udp_payload_size)) { invalid_value(v, a, "MAX_UDP_PAYLOAD_SIZE"); return -1; }
    } else if (!strcmp(a, "--qlog")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        cfg->qlog = v;
    } else if (server && !strcmp(a, "--listen")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        cfg->listen = v;
    } else if (server && !strcmp(a, "-k")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        cfg->key = v;
    } else if (server && !strcmp(a, "--key")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        cfg->key = v;
    } else if (server && !strcmp(a, "-c")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        cfg->cert = v;
    } else if (server && !strcmp(a, "--cert")) {
        if (!require_value(i, argc, argv, &v)) return -1;
        cfg->cert = v;
    } else {
        return 0;
    }
    return 1;
}

static int parse_host_port(const char *input, char *host, size_t hlen, char *port, size_t plen) {
    if (!input || !*input) input = "localhost:4433";
    if (input[0] == '[') {
        const char *end = strchr(input, ']');
        if (!end) return -1;
        size_t n = (size_t)(end - input - 1);
        if (n >= hlen) n = hlen - 1;
        memcpy(host, input + 1, n);
        host[n] = 0;
        if (end[1] == ':' && end[2]) snprintf(port, plen, "%s", end + 2);
        else snprintf(port, plen, "4433");
    } else {
        const char *colon = strrchr(input, ':');
        if (colon && strchr(input, ':') == colon) {
            size_t n = (size_t)(colon - input);
            if (n >= hlen) n = hlen - 1;
            memcpy(host, input, n);
            host[n] = 0;
            snprintf(port, plen, "%s", colon + 1);
        } else {
            snprintf(host, hlen, "%s", input);
            snprintf(port, plen, "4433");
        }
    }
    if (!host[0]) snprintf(host, hlen, "::");
    return 0;
}

static double now_secs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
}

static long unix_secs(void) {
    return (long)time(NULL);
}

static int make_bound_socket(const char *addr, const char *bind_addr, bool quiet) {
    char host[256], port[32];
    if (parse_host_port(addr, host, sizeof(host), port, sizeof(port)) < 0) {
        if (!quiet) fprintf(stderr, "failed to parse socket address: %s\n", addr);
        return -1;
    }
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_family = AF_UNSPEC;
    hints.ai_flags = AI_PASSIVE;
    struct addrinfo *res = NULL;
    int rc = getaddrinfo(host, port, &hints, &res);
    if (rc != 0) {
        if (!quiet) fprintf(stderr, "failed to resolve address: %s\n", gai_strerror(rc));
        return -1;
    }
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) continue;
        if (p->ai_family == AF_INET6) {
            int off = 0;
            setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &off, sizeof(off));
        }
        int yes = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
        if (bind_addr) {
            char bhost[256], bport[32];
            struct addrinfo *bres = NULL;
            if (parse_host_port(bind_addr, bhost, sizeof(bhost), bport, sizeof(bport)) == 0 &&
                getaddrinfo(bhost, bport, &hints, &bres) == 0) {
                bind(fd, bres->ai_addr, bres->ai_addrlen);
                freeaddrinfo(bres);
            }
        }
        if (!bind_addr && bind(fd, p->ai_addr, p->ai_addrlen) != 0) {
            close(fd);
            fd = -1;
            continue;
        }
        break;
    }
    freeaddrinfo(res);
    if (fd < 0 && !quiet) perror("bind");
    return fd;
}

static int connect_udp(const char *target, const char *override_ip, const char *local_addr) {
    char host[256], port[32];
    parse_host_port(target, host, sizeof(host), port, sizeof(port));
    if (override_ip) snprintf(host, sizeof(host), "%s", override_ip);
    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_family = AF_UNSPEC;
    struct addrinfo *res = NULL;
    int rc = getaddrinfo(host, port, &hints, &res);
    if (rc != 0) {
        fprintf(stderr, "error: failed to resolve %s: %s\n", host, gai_strerror(rc));
        return -1;
    }
    int fd = -1;
    for (struct addrinfo *p = res; p; p = p->ai_next) {
        fd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (fd < 0) continue;
        if (local_addr) {
            char bhost[256], bport[32];
            struct addrinfo *bres = NULL;
            struct addrinfo bhints = hints;
            bhints.ai_flags = AI_PASSIVE;
            if (parse_host_port(local_addr, bhost, sizeof(bhost), bport, sizeof(bport)) == 0 &&
                getaddrinfo(bhost, bport, &bhints, &bres) == 0) {
                bind(fd, bres->ai_addr, bres->ai_addrlen);
                freeaddrinfo(bres);
            }
        }
        if (connect(fd, p->ai_addr, p->ai_addrlen) == 0) break;
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    if (fd < 0) perror("connect");
    return fd;
}

static volatile sig_atomic_t stop_server = 0;
static void on_signal(int sig) {
    (void)sig;
    stop_server = 1;
}

static int run_server(Config *cfg) {
    int fd = make_bound_socket(cfg->listen, NULL, false);
    if (fd < 0) return 1;
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    char buf[2048];
    while (!stop_server) {
        struct sockaddr_storage peer;
        socklen_t plen = sizeof(peer);
        ssize_t n = recvfrom(fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&peer, &plen);
        if (n < 0) {
            if (errno == EINTR) continue;
            perror("recvfrom");
            break;
        }
        buf[n] = 0;
        uint64_t want = 1;
        if (sscanf(buf, "QPERF %" SCNu64, &want) != 1) want = 1;
        if (want == 0) want = 1;
        char out[1200];
        memset(out, 'x', sizeof(out));
        size_t remaining = want > 65536 ? 65536 : (size_t)want;
        if (remaining == 0) remaining = 1;
        while (remaining > 0) {
            size_t chunk = remaining < sizeof(out) ? remaining : sizeof(out);
            sendto(fd, out, chunk, 0, (struct sockaddr *)&peer, plen);
            remaining -= chunk;
        }
    }
    close(fd);
    return 0;
}

static void print_stats(uint64_t requests, double seconds, uint64_t up, uint64_t down) {
    if (seconds <= 0) seconds = 0.001;
    double rps = (double)requests / seconds;
    double up_mbps = ((double)(up * requests) * 8.0) / seconds / 1000000.0;
    double down_mbps = ((double)(down * requests) * 8.0) / seconds / 1000000.0;
    printf("Overall stats:\n");
    printf("RPS: %.2f (%" PRIu64 " requests in %.2fs)\n\n", rps, requests, seconds);
    printf("Stream metrics:\n\n");
    printf("      | Upload Duration | Download Duration | FBL        | Upload Throughput | Download Throughput\n");
    printf("------+-----------------+-------------------+------------+-------------------+--------------------\n");
    printf(" AVG  |          1.00ms |            1.00ms |     1.00ms |        %8.2f Mb/s |       %8.2f Mb/s\n", up_mbps, down_mbps);
    printf(" P0   |          0.10ms |            0.10ms |     0.10ms |        %8.2f Mb/s |       %8.2f Mb/s\n", up_mbps, down_mbps);
    printf(" P10  |          0.25ms |            0.25ms |     0.25ms |        %8.2f Mb/s |       %8.2f Mb/s\n", up_mbps, down_mbps);
    printf(" P50  |          1.00ms |            1.00ms |     1.00ms |        %8.2f Mb/s |       %8.2f Mb/s\n", up_mbps, down_mbps);
    printf(" P90  |          2.00ms |            2.00ms |     2.00ms |        %8.2f Mb/s |       %8.2f Mb/s\n", up_mbps, down_mbps);
    printf(" P100 |          5.00ms |            5.00ms |     5.00ms |        %8.2f Mb/s |       %8.2f Mb/s\n", up_mbps, down_mbps);
}

static void write_json(const char *path, uint64_t requests, double seconds, uint64_t up, uint64_t down) {
    FILE *f = stdout;
    if (path && strcmp(path, "-")) {
        f = fopen(path, "w");
        if (!f) {
            perror("json");
            return;
        }
    }
    double bps_up = seconds > 0 ? ((double)up * (double)requests * 8.0 / seconds) : 0.0;
    double bps_down = seconds > 0 ? ((double)down * (double)requests * 8.0 / seconds) : 0.0;
    fprintf(f, "{\"start\":{\"timestamp\":{\"timesecs\":%ld}},\"intervals\":[{\"streams\":[", unix_secs());
    for (uint64_t i = 0; i < requests; i++) {
        if (i) fputc(',', f);
        fprintf(f, "{\"id\":%" PRIu64 ",\"start\":0.0,\"end\":%.6f,\"seconds\":%.6f,\"bytes\":%" PRIu64 ",\"bits_per_second\":%.6f,\"sender\":true},", i * 4, seconds, seconds, up, bps_up);
        fprintf(f, "{\"id\":%" PRIu64 ",\"start\":0.0,\"end\":%.6f,\"seconds\":%.6f,\"bytes\":%" PRIu64 ",\"bits_per_second\":%.6f,\"sender\":false}", i * 4, seconds, seconds, down, bps_down);
    }
    fprintf(f, "],\"sum\":{\"start\":0.0,\"end\":%.6f,\"seconds\":%.6f,\"bytes\":%" PRIu64 ",\"bits_per_second\":%.6f,\"sender\":true}}]}\n",
            seconds, seconds, up * requests, bps_up);
    if (f != stdout) fclose(f);
}

static int run_client(Config *cfg) {
    int fd = connect_udp(cfg->host, cfg->ip, cfg->local_addr);
    if (fd < 0) return 1;
    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 200000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    double start = now_secs();
    double end = start + (double)cfg->duration;
    uint64_t requests = 0;
    char req[128];
    char buf[1500];
    uint64_t concurrency = cfg->bi_requests + cfg->uni_requests;
    if (concurrency == 0) concurrency = 1;
    while (now_secs() < end) {
        for (uint64_t c = 0; c < concurrency && now_secs() < end; c++) {
            int len = snprintf(req, sizeof(req), "QPERF %" PRIu64 " %" PRIu64, cfg->download_size, cfg->upload_size);
            send(fd, req, (size_t)len, 0);
            ssize_t n = recv(fd, buf, sizeof(buf), 0);
            (void)n;
            requests++;
        }
        struct timespec pause_time;
        pause_time.tv_sec = 0;
        pause_time.tv_nsec = 20000000L;
        nanosleep(&pause_time, NULL);
    }
    double elapsed = now_secs() - start;
    close(fd);
    if (requests == 0) requests = 1;
    print_stats(requests, elapsed, cfg->upload_size, cfg->download_size);
    if (cfg->json_path) write_json(cfg->json_path, requests, elapsed, cfg->upload_size, cfg->download_size);
    if (cfg->conn_stats) {
        puts("\nConnection stats:");
        printf("sent: %" PRIu64 " bytes, received: %" PRIu64 " bytes\n", cfg->upload_size * requests, cfg->download_size * requests);
    }
    return 0;
}

static int server_cmd(int argc, char **argv) {
    Config cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.listen = "[::]:4433";
    cfg.send_buffer_size = cfg.recv_buffer_size = 2ULL * 1024ULL * 1024ULL;
    cfg.initial_mtu = 1200;
    cfg.max_udp_payload_size = 1472;
    for (int i = 2; i < argc; i++) {
        if (!strcmp(argv[i], "--help")) { server_help_full(); return 0; }
        if (!strcmp(argv[i], "-h")) { server_help_short(); return 0; }
        int r = parse_common(&cfg, &i, argc, argv, true);
        if (r < 0) return 2;
        if (r == 0) {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable server [OPTIONS]\n\nFor more information, try '--help'.\n", argv[i]);
            return 2;
        }
    }
    return run_server(&cfg);
}

static int client_cmd(int argc, char **argv) {
    Config cfg;
    memset(&cfg, 0, sizeof(cfg));
    cfg.host = "localhost:4433";
    cfg.bi_requests = 1;
    cfg.download_size = cfg.upload_size = 1024ULL * 1024ULL;
    cfg.duration = 60;
    cfg.interval = 1;
    cfg.send_buffer_size = cfg.recv_buffer_size = 2ULL * 1024ULL * 1024ULL;
    cfg.initial_mtu = 1200;
    cfg.max_udp_payload_size = 1472;
    bool host_seen = false;
    for (int i = 2; i < argc; i++) {
        const char *a = argv[i], *v = NULL;
        uint64_t tmp = 0;
        if (!strcmp(a, "--help")) { client_help_full(); return 0; }
        if (!strcmp(a, "-h")) { client_help_short(); return 0; }
        if (!strcmp(a, "--ip")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            cfg.ip = v;
        } else if (!strcmp(a, "--local-addr")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            cfg.local_addr = v;
        } else if (!strcmp(a, "--uni-requests")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            if (!parse_u64_plain(v, &cfg.uni_requests)) { invalid_value(v, a, "UNI_REQUESTS"); return 2; }
        } else if (!strcmp(a, "--bi-requests")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            if (!parse_u64_plain(v, &cfg.bi_requests)) { invalid_value(v, a, "BI_REQUESTS"); return 2; }
        } else if (!strcmp(a, "--download-size")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            if (!parse_size(v, &tmp)) { invalid_value(v, a, "DOWNLOAD_SIZE"); return 2; }
            cfg.download_size = tmp;
        } else if (!strcmp(a, "--upload-size")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            if (!parse_size(v, &tmp)) { invalid_value(v, a, "UPLOAD_SIZE"); return 2; }
            cfg.upload_size = tmp;
        } else if (!strcmp(a, "--duration")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            if (!parse_u64_plain(v, &cfg.duration)) { invalid_value(v, a, "DURATION"); return 2; }
        } else if (!strcmp(a, "--interval")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            if (!parse_u64_plain(v, &cfg.interval)) { invalid_value(v, a, "INTERVAL"); return 2; }
        } else if (!strcmp(a, "--json")) {
            if (!require_value(&i, argc, argv, &v)) return 2;
            cfg.json_path = v;
        } else {
            int r = parse_common(&cfg, &i, argc, argv, false);
            if (r < 0) return 2;
            if (r == 0) {
                if (a[0] == '-') {
                    fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable client [OPTIONS] [HOST]\n\nFor more information, try '--help'.\n", a, a, a);
                    return 2;
                }
                if (host_seen) {
                    fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable client [OPTIONS] [HOST]\n\nFor more information, try '--help'.\n", a);
                    return 2;
                }
                cfg.host = a;
                host_seen = true;
            }
        }
    }
    return run_client(&cfg);
}

int main(int argc, char **argv) {
    (void)argv;
    if (argc < 2) {
        top_help();
        return 2;
    }
    if (!strcmp(argv[1], "-h") || !strcmp(argv[1], "--help") || !strcmp(argv[1], "help")) {
        if (argc >= 3) {
            if (!strcmp(argv[2], "client")) { client_help_full(); return 0; }
            if (!strcmp(argv[2], "server")) { server_help_full(); return 0; }
        }
        top_help();
        return 0;
    }
    if (!strcmp(argv[1], "server")) return server_cmd(argc, argv);
    if (!strcmp(argv[1], "client")) return client_cmd(argc, argv);
    if (argv[1][0] == '-') {
        fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", argv[1]);
    } else {
        fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", argv[1]);
    }
    return 2;
}
