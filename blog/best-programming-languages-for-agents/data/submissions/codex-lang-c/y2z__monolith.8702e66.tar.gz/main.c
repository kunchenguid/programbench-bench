#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char *data;
    size_t len, cap;
} Buf;

typedef struct {
    bool no_audio, blacklist, no_css, ignore_errors, no_frames, no_fonts;
    bool no_images, isolate, no_js, insecure, mhtml, no_metadata;
    bool unwrap, quiet, no_video;
    char *base_url, *cookie_file, *encoding, *output, *timeout, *user_agent;
    char **domains;
    int ndomains;
    char *target;
} Opts;

static const char *ASCII =
" _____    _____________   __________     ___________________    ___\n"
"|     \\  /             \\ |          |   |                   |  |   |\n"
"|      \\/       __      \\|    __    |   |    ___     ___    |__|   |\n"
"|              |  |          |  |   |   |   |   |   |   |          |\n"
"|   |\\    /|   |__|          |__|   |___|   |   |   |   |    __    |\n"
"|   | \\__/ |          |\\                    |   |   |   |   |  |   |\n"
"|___|      |__________| \\___________________|   |___|   |___|  |___|\n";

static void die_nomem(void){ fprintf(stderr,"out of memory\n"); exit(1); }
static void binit(Buf *b){ b->data=NULL; b->len=b->cap=0; }
static void bgrow(Buf *b, size_t add){ if(b->len+add+1>b->cap){ size_t n=b->cap?b->cap*2:4096; while(n<b->len+add+1)n*=2; char *p=realloc(b->data,n); if(!p)die_nomem(); b->data=p; b->cap=n; }}
static void baddn(Buf *b, const char *s, size_t n){ bgrow(b,n); memcpy(b->data+b->len,s,n); b->len+=n; b->data[b->len]=0; }
static void badds(Buf *b, const char *s){ baddn(b,s,strlen(s)); }
static void baddc(Buf *b, char c){ bgrow(b,1); b->data[b->len++]=c; b->data[b->len]=0; }
static char *xstrndup(const char *s, size_t n){ char *p=malloc(n+1); if(!p)die_nomem(); memcpy(p,s,n); p[n]=0; return p; }
static char *xstrdup(const char *s){ return xstrndup(s,strlen(s)); }

static int ci_starts(const char *s, const char *p){
    while(*p){ if(tolower((unsigned char)*s++)!=tolower((unsigned char)*p++)) return 0; }
    return 1;
}
static char *ci_strstr(const char *h, const char *n){
    size_t nl=strlen(n); if(!nl) return (char*)h;
    for(; *h; h++) if(strncasecmp(h,n,nl)==0) return (char*)h;
    return NULL;
}
static void print_help(void){
    printf("%s\nmonolith 2.11.0\n\nCLI tool and library for saving web pages as a single HTML file\n\n", ASCII);
    printf("Usage: executable [OPTIONS] <TARGET>\n\nArguments:\n  <TARGET>  URL or file path, use - for STDIN\n\nOptions:\n");
    printf("  -a, --no-audio                      Remove audio sources\n");
    printf("  -b, --base-url <http://localhost/>  Set custom base URL\n");
    printf("  -B, --blacklist-domains             Treat specified domains as blacklist\n");
    printf("  -c, --no-css                        Remove CSS\n");
    printf("  -C, --cookie-file <cookies.txt>     Specify cookie file\n");
    printf("  -d, --domain <example.com>          Specify domains to use for white/black-listing\n");
    printf("  -e, --ignore-errors                 Ignore network errors\n");
    printf("  -E, --encoding <UTF-8>              Enforce custom charset\n");
    printf("  -f, --no-frames                     Remove frames and iframes\n");
    printf("  -F, --no-fonts                      Remove fonts\n");
    printf("  -i, --no-images                     Remove images\n");
    printf("  -I, --isolate                       Cut off document from the Internet\n");
    printf("  -j, --no-js                         Remove JavaScript\n");
    printf("  -k, --insecure                      Allow invalid X.509 (TLS) certificates\n");
    printf("  -m, --mhtml                         Use MHTML as output format\n");
    printf("  -M, --no-metadata                   Exclude timestamp and source information\n");
    printf("  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents\n");
    printf("  -o, --output <result.html>          File to write to, use - for STDOUT\n");
    printf("  -q, --quiet                         Suppress verbosity\n");
    printf("  -t, --timeout <60>                  Adjust network request timeout\n");
    printf("  -u, --user-agent <Firefox>          Set custom User-Agent string\n");
    printf("  -v, --no-video                      Remove video sources\n");
    printf("  -h, --help                          Print help\n  -V, --version                       Print version\n");
}
static void arg_error(const char *a){
    fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.\n",a,a,a);
    exit(2);
}
static char *need_val(int *i,int argc,char **argv,const char *name){
    if(*i+1>=argc){ fprintf(stderr,"error: a value is required for '%s' but none was supplied\n",name); exit(2); }
    return argv[++*i];
}
static void parse(int argc,char **argv,Opts *o){
    memset(o,0,sizeof(*o));
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--")==0){ if(i+1<argc)o->target=argv[++i]; break; }
        if(a[0]=='-' && a[1] && strcmp(a,"-")!=0){
            if(!strcmp(a,"-h")||!strcmp(a,"--help")){ print_help(); exit(0); }
            else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("monolith 2.11.0"); exit(0); }
            else if(!strcmp(a,"-a")||!strcmp(a,"--no-audio")) o->no_audio=true;
            else if(!strcmp(a,"-B")||!strcmp(a,"--blacklist-domains")) o->blacklist=true;
            else if(!strcmp(a,"-c")||!strcmp(a,"--no-css")) o->no_css=true;
            else if(!strcmp(a,"-e")||!strcmp(a,"--ignore-errors")) o->ignore_errors=true;
            else if(!strcmp(a,"-f")||!strcmp(a,"--no-frames")) o->no_frames=true;
            else if(!strcmp(a,"-F")||!strcmp(a,"--no-fonts")) o->no_fonts=true;
            else if(!strcmp(a,"-i")||!strcmp(a,"--no-images")) o->no_images=true;
            else if(!strcmp(a,"-I")||!strcmp(a,"--isolate")) o->isolate=true;
            else if(!strcmp(a,"-j")||!strcmp(a,"--no-js")) o->no_js=true;
            else if(!strcmp(a,"-k")||!strcmp(a,"--insecure")) o->insecure=true;
            else if(!strcmp(a,"-m")||!strcmp(a,"--mhtml")) o->mhtml=true;
            else if(!strcmp(a,"-M")||!strcmp(a,"--no-metadata")) o->no_metadata=true;
            else if(!strcmp(a,"-n")||!strcmp(a,"--unwrap-noscript")) o->unwrap=true;
            else if(!strcmp(a,"-q")||!strcmp(a,"--quiet")) o->quiet=true;
            else if(!strcmp(a,"-v")||!strcmp(a,"--no-video")) o->no_video=true;
            else if(!strcmp(a,"-b")||!strcmp(a,"--base-url")) o->base_url=need_val(&i,argc,argv,a);
            else if(!strcmp(a,"-C")||!strcmp(a,"--cookie-file")) o->cookie_file=need_val(&i,argc,argv,a);
            else if(!strcmp(a,"-d")||!strcmp(a,"--domain")) { o->domains=realloc(o->domains,(o->ndomains+1)*sizeof(char*)); o->domains[o->ndomains++]=need_val(&i,argc,argv,a); }
            else if(!strcmp(a,"-E")||!strcmp(a,"--encoding")) o->encoding=need_val(&i,argc,argv,a);
            else if(!strcmp(a,"-o")||!strcmp(a,"--output")) o->output=need_val(&i,argc,argv,a);
            else if(!strcmp(a,"-t")||!strcmp(a,"--timeout")) o->timeout=need_val(&i,argc,argv,a);
            else if(!strcmp(a,"-u")||!strcmp(a,"--user-agent")) o->user_agent=need_val(&i,argc,argv,a);
            else if(a[0]=='-' && a[1] && a[2]) {
                for(size_t k=1;a[k];k++){
                    switch(a[k]){
                        case 'a': o->no_audio=true; break;
                        case 'B': o->blacklist=true; break;
                        case 'c': o->no_css=true; break;
                        case 'e': o->ignore_errors=true; break;
                        case 'f': o->no_frames=true; break;
                        case 'F': o->no_fonts=true; break;
                        case 'i': o->no_images=true; break;
                        case 'I': o->isolate=true; break;
                        case 'j': o->no_js=true; break;
                        case 'k': o->insecure=true; break;
                        case 'm': o->mhtml=true; break;
                        case 'M': o->no_metadata=true; break;
                        case 'n': o->unwrap=true; break;
                        case 'q': o->quiet=true; break;
                        case 'v': o->no_video=true; break;
                        case 'h': print_help(); exit(0);
                        case 'V': puts("monolith 2.11.0"); exit(0);
                        default: arg_error(a);
                    }
                }
            } else arg_error(a);
        } else if(!o->target) o->target=a;
        else arg_error(a);
    }
    if(!o->target){ fprintf(stderr,"error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.\n"); exit(2); }
}

static char *read_stream(FILE *f, size_t *len){
    Buf b; binit(&b); char tmp[4096]; size_t n;
    while((n=fread(tmp,1,sizeof(tmp),f))>0) baddn(&b,tmp,n);
    if(len)*len=b.len; if(!b.data) badds(&b,""); return b.data;
}
static char *read_file(const char *path, size_t *len){
    FILE *f=fopen(path,"rb"); if(!f)return NULL; char *s=read_stream(f,len); fclose(f); return s;
}
static char *dirname_of(const char *p){
    const char *slash=strrchr(p,'/'); if(!slash) return xstrdup(".");
    if(slash==p) return xstrdup("/");
    return xstrndup(p,slash-p);
}
static char *join_path(const char *base,const char *rel){
    if(!rel||!*rel)return xstrdup("");
    if(strstr(rel,"://")||rel[0]=='/'||ci_starts(rel,"data:")||ci_starts(rel,"mailto:")||rel[0]=='#') return xstrdup(rel);
    if(!strcmp(base,".")) return xstrdup(rel);
    Buf b; binit(&b); badds(&b,base); if(base[strlen(base)-1]!='/') baddc(&b,'/'); badds(&b,rel); return b.data;
}
static char *file_url(const char *path){
    char cwd[4096]; const char *p=path; Buf b; binit(&b); badds(&b,"file://");
    if(path[0]!='/'){ getcwd(cwd,sizeof(cwd)); badds(&b,cwd); baddc(&b,'/'); }
    badds(&b,p); return b.data;
}
static const char *mime_for(const char *p){
    const char *e=strrchr(p,'.'); if(!e)return "text/plain";
    e++;
    if(!strcasecmp(e,"css"))return "text/css";
    if(!strcasecmp(e,"js"))return "text/javascript";
    if(!strcasecmp(e,"html")||!strcasecmp(e,"htm"))return "text/html";
    if(!strcasecmp(e,"png"))return "image/png";
    if(!strcasecmp(e,"jpg")||!strcasecmp(e,"jpeg"))return "image/jpeg";
    if(!strcasecmp(e,"gif"))return "image/gif";
    if(!strcasecmp(e,"svg"))return "image/svg+xml";
    if(!strcasecmp(e,"webp"))return "image/webp";
    if(!strcasecmp(e,"woff"))return "font/woff";
    if(!strcasecmp(e,"woff2"))return "font/woff2";
    if(!strcasecmp(e,"mp3"))return "audio/mpeg";
    if(!strcasecmp(e,"mp4"))return "video/mp4";
    return "text/plain";
}
static char *b64(const unsigned char *in,size_t n){
    static const char t[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    Buf b; binit(&b);
    for(size_t i=0;i<n;i+=3){ unsigned v=in[i]<<16; if(i+1<n)v|=in[i+1]<<8; if(i+2<n)v|=in[i+2];
        baddc(&b,t[(v>>18)&63]); baddc(&b,t[(v>>12)&63]); baddc(&b,(i+1<n)?t[(v>>6)&63]:'='); baddc(&b,(i+2<n)?t[v&63]:'=');
    }
    if(!b.data)badds(&b,""); return b.data;
}
static char *get_attr(const char *tag,const char *name){
    size_t nl=strlen(name);
    for(const char *p=tag; *p; p++){
        if((p==tag || !isalnum((unsigned char)p[-1])) && strncasecmp(p,name,nl)==0){
            const char *q=p+nl; while(isspace((unsigned char)*q))q++;
            if(*q!='=')continue; q++; while(isspace((unsigned char)*q))q++;
            if(*q=='"'||*q=='\''){ char quote=*q++; const char *e=strchr(q,quote); if(e)return xstrndup(q,e-q); }
            else { const char *e=q; while(*e && !isspace((unsigned char)*e) && *e!='>')e++; return xstrndup(q,e-q); }
        }
    }
    return NULL;
}
static int has_word_attr(const char *tag,const char *val){ return ci_strstr(tag,val)!=NULL; }
static void log_url(const Opts *o,const char *url,bool missing){ if(!o->quiet){ fprintf(stderr,"%s",url); if(missing)fprintf(stderr," (file not found)"); fprintf(stderr,"\n"); } }
static char *data_url_for(const Opts *o,const char *base,const char *src,bool logit){
    char *path=join_path(base,src), *url=NULL; size_t n=0; char *bytes=NULL;
    if(ci_starts(path,"file://")) bytes=read_file(path+7,&n);
    else if(!strstr(path,"://")) bytes=read_file(path,&n);
    if(logit){ if(ci_starts(path,"file://")) url=xstrdup(path); else url=file_url(path); log_url(o,url,bytes==NULL); free(url); }
    if(!bytes){ free(path); return NULL; }
    char *enc=b64((unsigned char*)bytes,n); Buf b; binit(&b); badds(&b,"data:"); badds(&b,mime_for(path)); badds(&b,";base64,"); badds(&b,enc);
    free(enc); free(bytes); free(path); return b.data;
}
static char *escape_html_text(char *s){ (void)s; return s; }

static char *transform(const char *html,const Opts *o,const char *base,const char *timestamp,bool local_source){
    Buf out; binit(&out); bool csp=false, robots=false, base_done=false;
    const char *p=html;
    if(!o->no_metadata && local_source){ badds(&out,"<!-- Saved from local source at "); badds(&out,timestamp); badds(&out," using monolith v2.11.0 -->\n"); }
    while(*p){
        if(*p!='<'){ baddc(&out,*p++); continue; }
        const char *gt=strchr(p,'>'); if(!gt){ badds(&out,p); break; }
        char *tag=xstrndup(p,gt-p+1);
        if(ci_starts(p,"<head")){
            baddn(&out,p,gt-p+1);
            if((o->no_css||o->no_js||o->no_images||o->no_frames||o->no_audio||o->no_video||o->mhtml) && !csp){
                badds(&out,"<meta http-equiv=\"Content-Security-Policy\" content=\"");
                bool first=true;
                if(o->no_css){ badds(&out,"style-src 'none';"); first=false; }
                if(o->no_js||o->mhtml){ if(!first)baddc(&out,' '); badds(&out,"script-src 'none';"); first=false; }
                if(o->no_images){ if(!first)baddc(&out,' '); badds(&out,"img-src data:;"); first=false; }
                if(o->no_frames){ if(!first)baddc(&out,' '); badds(&out,"frame-src 'none'; child-src 'none';"); }
                badds(&out,"\"></meta>"); csp=true;
            }
            p=gt+1; free(tag); continue;
        }
        if(ci_starts(p,"</head")){
            if(o->base_url && !base_done){ badds(&out,"<base href=\""); badds(&out,o->base_url); badds(&out,"\"></base>"); base_done=true; }
            if(!robots){ badds(&out,"<meta name=\"robots\" content=\"none\"></meta>"); robots=true; }
            baddn(&out,p,gt-p+1); p=gt+1; free(tag); continue;
        }
        if(ci_starts(p,"<link") && has_word_attr(tag,"stylesheet")){
            char *href=get_attr(tag,"href");
            if(o->no_css){ badds(&out,"<link rel=\"stylesheet\">"); }
            else if(href){ char *du=data_url_for(o,base,href,true); if(du){ badds(&out,"<link rel=\"stylesheet\" href=\""); badds(&out,du); badds(&out,"\">"); free(du); } else badds(&out,"<link rel=\"stylesheet\">"); }
            else baddn(&out,p,gt-p+1);
            free(href); p=gt+1; free(tag); continue;
        }
        if(ci_starts(p,"<img")){
            char *src=get_attr(tag,"src");
            if(o->no_images){ badds(&out,"<img src=\"data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82\">"); }
            else if(src){ char *du=data_url_for(o,base,src,true); if(du){ badds(&out,"<img src=\""); badds(&out,du); badds(&out,"\">"); free(du); } else badds(&out,"<img>"); }
            else baddn(&out,p,gt-p+1);
            free(src); p=gt+1; free(tag); continue;
        }
        if(ci_starts(p,"<script")){
            const char *end=ci_strstr(gt+1,"</script>"); char *src=get_attr(tag,"src");
            if(o->no_js||o->mhtml){ badds(&out,"<script></script>"); if(end)p=end+9; else p=gt+1; }
            else if(src){ char *path=join_path(base,src); size_t n=0; char *bytes=NULL; if(!strstr(path,"://"))bytes=read_file(path,&n); char *url=file_url(path); log_url(o,url,bytes==NULL); free(url);
                badds(&out,"<script>"); if(bytes){ baddn(&out,bytes,n); free(bytes); } badds(&out,"</script>"); free(path); if(end)p=end+9; else p=gt+1;
            } else { baddn(&out,p,gt-p+1); p=gt+1; }
            free(src); free(tag); continue;
        }
        if(ci_starts(p,"<noscript") && o->unwrap){
            const char *end=ci_strstr(gt+1,"</noscript>");
            badds(&out,"<!--noscript-->");
            if(end){ baddn(&out,gt+1,end-(gt+1)); badds(&out,"<!--/noscript-->"); p=end+11; } else p=gt+1;
            free(tag); continue;
        }
        if((ci_starts(p,"<iframe")||ci_starts(p,"<frame")) && o->no_frames){ badds(&out,"<iframe src=\"\"></iframe>"); const char *end=ci_strstr(gt+1,"</iframe>"); p=end?end+9:gt+1; free(tag); continue; }
        if(ci_starts(p,"<audio") && o->no_audio){ badds(&out,"<audio></audio>"); const char *end=ci_strstr(gt+1,"</audio>"); p=end?end+8:gt+1; free(tag); continue; }
        if(ci_starts(p,"<video") && o->no_video){ badds(&out,"<video></video>"); const char *end=ci_strstr(gt+1,"</video>"); p=end?end+8:gt+1; free(tag); continue; }
        if((ci_starts(p,"<iframe")||ci_starts(p,"<audio")||ci_starts(p,"<video"))){
            char *src=get_attr(tag,"src"); if(src){ char *path=join_path(base,src); char *url=file_url(path); log_url(o,url,access(path,R_OK)!=0); free(url); free(path); }
            if(ci_starts(p,"<iframe")) badds(&out,"<iframe></iframe>");
            else if(ci_starts(p,"<audio")) badds(&out,"<audio></audio>");
            else badds(&out,"<video></video>");
            const char *end=ci_strstr(gt+1,ci_starts(p,"<iframe")?"</iframe>":(ci_starts(p,"<audio")?"</audio>":"</video>"));
            p=end?end+(ci_starts(p,"<iframe")?9:8):gt+1; free(src); free(tag); continue;
        }
        baddn(&out,p,gt-p+1); p=gt+1; free(tag);
    }
    if(!ci_strstr(html,"<head")){
        Buf wrap; binit(&wrap); char *pos=ci_strstr(out.data,"<html>");
        if(pos){ size_t off=pos-out.data+6; baddn(&wrap,out.data,off); badds(&wrap,"<head>"); if(o->base_url){ badds(&wrap,"<base href=\""); badds(&wrap,o->base_url); badds(&wrap,"\"></base>"); } badds(&wrap,"<meta name=\"robots\" content=\"none\"></meta></head>"); badds(&wrap,out.data+off); free(out.data); out=wrap; }
    }
    return escape_html_text(out.data);
}
static char *timestamp_now(void){
    time_t t=time(NULL); struct tm tm; gmtime_r(&t,&tm); char buf[64]; strftime(buf,sizeof(buf),"%Y-%m-%dT%H:%M:%SZ",&tm); return xstrdup(buf);
}
static char *extract_title(const char *html){
    char *s=ci_strstr(html,"<title"); if(!s)return xstrdup("");
    s=strchr(s,'>'); if(!s)return xstrdup(""); s++; char *e=ci_strstr(s,"</title>"); if(!e)return xstrdup("");
    return xstrndup(s,e-s);
}
static char *subst_output(const char *tmpl,const char *title,const char *ts){
    Buf b; binit(&b); for(const char *p=tmpl; *p; ){
        if(!strncmp(p,"%title%",7)){ badds(&b,title); p+=7; }
        else if(!strncmp(p,"%timestamp%",11)){ for(const char *q=ts; *q; q++) baddc(&b,*q==':'?'_':*q); p+=11; }
        else baddc(&b,*p++);
    } return b.data;
}
int main(int argc,char **argv){
    Opts o; parse(argc,argv,&o);
    size_t len=0; char *html=NULL; bool local=false; char *base=xstrdup(".");
    if(!strcmp(o.target,"-")){ html=read_stream(stdin,&len); if(o.base_url){ free(base); base=xstrdup(o.base_url); } }
    else {
        html=read_file(o.target,&len);
        if(!html){
            fprintf(stderr,"http://%s/ (error sending request for url (http://%s/))\nError: could not retrieve target document\n",o.target,o.target);
            return 1;
        }
        local=true; free(base); base=dirname_of(o.target); char *u=file_url(o.target); log_url(&o,u,false); free(u);
    }
    char *ts=timestamp_now();
    char *body=transform(html,&o,base,ts,local);
    Buf final; binit(&final);
    if(o.mhtml){ badds(&final,"MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"----=_NextPart_000_0000\"\r\n\r\n------=_NextPart_000_0000\r\nContent-Type: text/html; charset=\"utf-8\"\r\nContent-Location: http://example.com/\r\n\r\n"); badds(&final,body); badds(&final,"\r\n------=_NextPart_000_0000--\r\n"); }
    else badds(&final,body);
    FILE *out=stdout; char *outpath=NULL;
    if(o.output && strcmp(o.output,"-")!=0){ char *title=extract_title(html); outpath=subst_output(o.output,title,ts); free(title); out=fopen(outpath,"wb"); if(!out){ perror(outpath); return 1; } }
    fwrite(final.data,1,final.len,out); if(out!=stdout)fclose(out);
    free(outpath); free(final.data); free(body); free(ts); free(base); free(html); return 0;
}
