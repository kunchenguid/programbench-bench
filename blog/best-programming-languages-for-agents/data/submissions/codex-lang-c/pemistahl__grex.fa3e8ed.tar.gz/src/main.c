#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdint.h>

#define VERSION "grex 1.4.6"

typedef struct {char **v; int n, cap;} StrVec;
static void sv_push(StrVec *s, char *x){ if(s->n==s->cap){s->cap=s->cap? s->cap*2:8; s->v=realloc(s->v,s->cap*sizeof(char*));} s->v[s->n++]=x; }
static char *xstrdup(const char *s){ char *r=malloc(strlen(s)+1); strcpy(r,s); return r; }
static char *substr(const char *s, int n){ char *r=malloc(n+1); memcpy(r,s,n); r[n]=0; return r; }

typedef struct {char *s; size_t len, cap;} Buf;
static void binit(Buf *b){b->cap=128;b->len=0;b->s=malloc(b->cap);b->s[0]=0;}
static void baddn(Buf *b,const char*s,size_t n){ if(b->len+n+1>b->cap){while(b->len+n+1>b->cap)b->cap*=2;b->s=realloc(b->s,b->cap);} memcpy(b->s+b->len,s,n); b->len+=n; b->s[b->len]=0; }
static void badd(Buf*b,const char*s){baddn(b,s,strlen(s));}
static void bch(Buf*b,char c){baddn(b,&c,1);} 
static char *bfinish(Buf*b){return b->s;}

static void print_help(void){
puts("grex 1.4.6\n© 2019-today Peter M. Stahl <pemistahl@gmail.com>\nLicensed under the Apache License, Version 2.0\nDownloadable from https://crates.io/crates/grex\nSource code at https://github.com/pemistahl/grex\n");
puts("grex generates regular expressions from user-provided test cases.\n");
puts("Usage: grex [OPTIONS] {INPUT...|--file <FILE>}\n");
puts("Input:\n  [INPUT]...         One or more test cases separated by blank space\n  -f, --file <FILE>  Reads test cases on separate lines from a file\n");
puts("Digit Options:\n  -d, --digits      Converts any Unicode decimal digit to \\d\n  -D, --non-digits  Converts any character which is not a Unicode decimal digit to \\D\n");
puts("Whitespace Options:\n  -s, --spaces      Converts any Unicode whitespace character to \\s\n  -S, --non-spaces  Converts any character which is not a Unicode whitespace character to \\S\n");
puts("Word Options:\n  -w, --words      Converts any Unicode word character to \\w\n  -W, --non-words  Converts any character which is not a Unicode word character to \\W\n");
puts("Escaping Options:\n  -e, --escape           Replaces all non-ASCII characters with unicode escape sequences\n      --with-surrogates  Converts astral code points to surrogate pairs if --escape is set\n");
puts("Repetition Options:\n  -r, --repetitions\n          Detects repeated non-overlapping substrings and converts them to {min,max} quantifier\n          notation\n      --min-repetitions <QUANTITY>\n          Specifies the minimum quantity of substring repetitions to be converted if --repetitions\n          is set [default: 1]\n      --min-substring-length <LENGTH>\n          Specifies the minimum length a repeated substring must have in order to be converted if\n          --repetitions is set [default: 1]\n");
puts("Anchor Options:\n      --no-start-anchor  Removes the caret anchor `^` from the resulting regular expression\n      --no-end-anchor    Removes the dollar sign anchor `$` from the resulting regular expression\n      --no-anchors       Removes the caret and dollar sign anchors from the resulting regular\n                         expression\n");
puts("Display Options:\n  -x, --verbose   Produces a nicer-looking regular expression in verbose mode\n  -c, --colorize  Provides syntax highlighting for the resulting regular expression\n");
puts("Miscellaneous Options:\n  -i, --ignore-case     Performs case-insensitive matching, letters match both upper and lower case\n  -g, --capture-groups  Replaces non-capturing groups with capturing ones\n  -h, --help            Prints help information\n  -v, --version         Prints version information");
}

typedef struct {bool d,D,s,S,w,W,esc,surr,rep,no_start,no_end,ignore,capture,verbose,color; int minrep,minsub;} Opt;

static uint32_t next_cp(const char **p){ const unsigned char *s=(const unsigned char*)*p; if(!*s) return 0; uint32_t cp; int n=1; if(s[0]<0x80){cp=s[0];n=1;} else if((s[0]&0xE0)==0xC0){cp=((s[0]&0x1F)<<6)|(s[1]&0x3F);n=2;} else if((s[0]&0xF0)==0xE0){cp=((s[0]&0x0F)<<12)|((s[1]&0x3F)<<6)|(s[2]&0x3F);n=3;} else {cp=((s[0]&0x07)<<18)|((s[1]&0x3F)<<12)|((s[2]&0x3F)<<6)|(s[3]&0x3F);n=4;} *p += n; return cp; }
static char *utf8_cp(uint32_t cp){ char tmp[5]; int n=0; if(cp<0x80)tmp[n++]=cp; else if(cp<0x800){tmp[n++]=0xC0|(cp>>6);tmp[n++]=0x80|(cp&0x3F);} else if(cp<0x10000){tmp[n++]=0xE0|(cp>>12);tmp[n++]=0x80|((cp>>6)&0x3F);tmp[n++]=0x80|(cp&0x3F);} else {tmp[n++]=0xF0|(cp>>18);tmp[n++]=0x80|((cp>>12)&0x3F);tmp[n++]=0x80|((cp>>6)&0x3F);tmp[n++]=0x80|(cp&0x3F);} tmp[n]=0; return xstrdup(tmp); }
static bool is_digit_cp(uint32_t cp){return (cp>='0'&&cp<='9') || (cp>=0x660&&cp<=0x669) || (cp>=0x6f0&&cp<=0x6f9);}
static bool is_space_cp(uint32_t cp){return cp==' '||cp=='\t'||cp=='\n'||cp=='\r'||cp=='\v'||cp=='\f'||cp==0xA0;}
static bool is_word_cp(uint32_t cp){return (cp>='A'&&cp<='Z')||(cp>='a'&&cp<='z')||(cp>='0'&&cp<='9')||cp=='_'||(cp>=0x660&&cp<=0x669)||(cp>=0x6f0&&cp<=0x6f9);}
static char *escape_lit(uint32_t cp, Opt *o){
 if(o->ignore && cp<128) cp=tolower((int)cp);
 bool dig=is_digit_cp(cp), sp=is_space_cp(cp), word=is_word_cp(cp);
 if(o->d && dig) return xstrdup("\\d");
 if(o->s && sp) return xstrdup("\\s");
 if(o->w && word) return xstrdup("\\w");
 if(o->D && !dig) return xstrdup("\\D");
 if(o->W && !word) return xstrdup("\\W");
 if(o->S && !sp) return xstrdup("\\S");
 if(o->esc && cp>=128){ char t[32]; snprintf(t,sizeof(t),"\\u{%x}",cp); return xstrdup(t); }
 if(cp<128){ char c=(char)cp; if(strchr("\\.[]{}()^$|?*+-", c)){ char t[3]={'\\',c,0}; return xstrdup(t);} char t[2]={c,0}; return xstrdup(t); }
 return utf8_cp(cp);
}

typedef struct {char **t; int n, cap;} TokSeq;
static void ts_push(TokSeq *ts,char*x){ if(ts->n==ts->cap){ts->cap=ts->cap?ts->cap*2:8; ts->t=realloc(ts->t,ts->cap*sizeof(char*));} ts->t[ts->n++]=x; }
static TokSeq tokenize(const char *in, Opt *o){ TokSeq ts={0}; const char *p=in; while(*p){ uint32_t cp=next_cp(&p); if(o->ignore && cp<128) cp=tolower((int)cp); if(o->esc && o->surr && cp>=0x10000){ uint32_t u=cp-0x10000, hi=0xD800+(u>>10), lo=0xDC00+(u&0x3FF); char a[32],b[32]; snprintf(a,sizeof(a),"\\u{%x}",hi); snprintf(b,sizeof(b),"\\u{%x}",lo); ts_push(&ts,xstrdup(a)); ts_push(&ts,xstrdup(b)); } else ts_push(&ts, escape_lit(cp,o)); } return ts; }

static bool token_simple_atom(const char *s){
 if(strlen(s)==1) return true;
 if((unsigned char)s[0]>=128) return true;
 if(s[0]=='\\' && strchr("dDsSwW",s[1]) && s[2]==0) return true;
 if(strncmp(s,"\\u{",3)==0){ const char *p=strchr(s,'}'); return p && p[1]==0; }
 return false;
}
static char *grouped(const char *s, Opt *o){ if(token_simple_atom(s)) return xstrdup(s); Buf b; binit(&b); badd(&b,o->capture?"(":"(?:"); badd(&b,s); bch(&b,')'); return bfinish(&b); }
static char *quantify(const char *s, const char *q, Opt *o){ char *g=grouped(s,o); Buf b; binit(&b); badd(&b,g); badd(&b,q); free(g); return bfinish(&b); }

static char *compress_seq(TokSeq *ts, Opt *o){
 Buf out; binit(&out);
 for(int i=0;i<ts->n;){ int bestL=0,bestK=0; if(o->rep){ for(int L=o->minsub; L<= (ts->n-i)/2; L++){ int k=1; while(i+(k+1)*L<=ts->n){ bool eq=true; for(int j=0;j<L;j++) if(strcmp(ts->t[i+j],ts->t[i+k*L+j])){eq=false;break;} if(!eq) break; k++; } if(k>=2 && k-1>=o->minrep){ bestL=L; bestK=k; break; } } }
  if(bestL){ Buf unit; binit(&unit); for(int j=0;j<bestL;j++) badd(&unit,ts->t[i+j]); char q[32]; snprintf(q,sizeof(q),"{%d}",bestK); char *qq=quantify(unit.s,q,o); badd(&out,qq); free(unit.s); free(qq); i += bestL*bestK; }
  else { badd(&out,ts->t[i]); i++; }
 }
 return bfinish(&out);
}

typedef struct Node Node; typedef struct {char *tok; Node *to;} Edge;
struct Node{bool term; Edge *e; int n,cap;};
static Node *newnode(void){return calloc(1,sizeof(Node));}
static int edge_cmp(const void*a,const void*b){ const Edge*A=a,*B=b; int la=strlen(A->tok), lb=strlen(B->tok); if(la!=lb) return lb-la; return strcmp(A->tok,B->tok); }
static Node *child(Node*n,char*tok){ for(int i=0;i<n->n;i++) if(!strcmp(n->e[i].tok,tok)) return n->e[i].to; if(n->n==n->cap){n->cap=n->cap?n->cap*2:4;n->e=realloc(n->e,n->cap*sizeof(Edge));} n->e[n->n].tok=xstrdup(tok); n->e[n->n].to=newnode(); return n->e[n->n++].to; }
static void insert(Node*r, TokSeq*ts){ Node*n=r; for(int i=0;i<ts->n;i++) n=child(n,ts->t[i]); n->term=true; }
static bool single_literal_char(const char *s,char *c){ if(strlen(s)==1 && !strchr("\\[]^-",s[0])){*c=s[0];return true;} if(s[0]=='\\' && s[2]==0 && strchr(".{}()?*+|$^",s[1])){*c=s[1];return true;} return false; }
static char *char_class_chars(char *chars,int m){
 for(int i=0;i<m;i++)for(int j=i+1;j<m;j++)if(chars[j]<chars[i]){char t=chars[i];chars[i]=chars[j];chars[j]=t;}
 if(m==1){ char c=chars[0]; char tmp[3]; if(strchr("\\.{}()?*+|$^",c)){tmp[0]='\\';tmp[1]=c;tmp[2]=0;return xstrdup(tmp);} tmp[0]=c;tmp[1]=0;return xstrdup(tmp);}
 Buf b; binit(&b); bch(&b,'['); for(int i=0;i<m;){ int j=i; while(j+1<m && chars[j+1]==chars[j]+1) j++; if(j-i>=2){ bch(&b,chars[i]); bch(&b,'-'); bch(&b,chars[j]); } else { for(int k=i;k<=j;k++){ if(chars[k]=='-'||chars[k]=='^'||chars[k]==']'||chars[k]=='\\') bch(&b,'\\'); bch(&b,chars[k]); } } i=j+1; } bch(&b,']'); return bfinish(&b);
}
static char *char_class_from(Edge *e,int n){ char chars[256]; int m=0; for(int i=0;i<n;i++){ char c; if(!single_literal_char(e[i].tok,&c) || e[i].to->n || !e[i].to->term) return NULL; chars[m++]=c; }
 return char_class_chars(chars,m); }
static char *node_regex(Node*n, Opt*o){ if(n->n) qsort(n->e,n->n,sizeof(Edge),edge_cmp); if(n->n==0) return xstrdup("");
 if(!n->term && n->n>=2){ char *cc=char_class_from(n->e,n->n); if(cc) return cc; }
 StrVec parts={0}; char clsbuf[256]; int clsn=0;
 for(int i=0;i<n->n;i++){ char c; if(n->e[i].to->term && n->e[i].to->n==0 && single_literal_char(n->e[i].tok,&c)){ clsbuf[clsn++]=c; continue; } char *sub=node_regex(n->e[i].to,o); Buf p; binit(&p); badd(&p,n->e[i].tok); badd(&p,sub); sv_push(&parts,bfinish(&p)); free(sub); }
 if(clsn>0) sv_push(&parts,char_class_chars(clsbuf,clsn));
 for(int i=0;i<parts.n;i++) for(int j=i+1;j<parts.n;j++){ int li=strlen(parts.v[i]), lj=strlen(parts.v[j]); int ci=parts.v[i][0]=='[', cj=parts.v[j][0]=='['; if((ci&&!cj) || (ci==cj && (lj>li || (lj==li && strcmp(parts.v[j],parts.v[i])<0)))){ char *t=parts.v[i]; parts.v[i]=parts.v[j]; parts.v[j]=t; }}
 char *alt=NULL; if(parts.n==1) alt=xstrdup(parts.v[0]); else { Buf b; binit(&b); badd(&b,o->capture?"(":"(?:"); for(int i=0;i<parts.n;i++){ if(i)bch(&b,'|'); badd(&b,parts.v[i]); } bch(&b,')'); alt=bfinish(&b); }
 if(n->term){ char *q=quantify(alt,"?",o); free(alt); return q; }
 return alt; }


static char *regex_from_sequences(TokSeq *seqs, int n, Opt *o){
 Node *root=newnode(); for(int i=0;i<n;i++) insert(root,&seqs[i]); return node_regex(root,o);
}
static char *try_suffix_pattern(TokSeq *seqs,int n,Opt*o){
 if(n<2) return NULL; int minlen=seqs[0].n; for(int i=1;i<n;i++) if(seqs[i].n<minlen) minlen=seqs[i].n;
 int common_start=0; while(common_start<minlen){ const char *tok=seqs[0].t[common_start]; bool all=true; for(int i=1;i<n;i++) if(strcmp(tok,seqs[i].t[common_start])){all=false;break;} if(!all) break; common_start++; }
 if(common_start>0) return NULL;
 int suf=0; while(suf<minlen){ const char *tok=seqs[0].t[seqs[0].n-1-suf]; bool all=true; for(int i=1;i<n;i++) if(strcmp(tok,seqs[i].t[seqs[i].n-1-suf])){all=false;break;} if(!all) break; suf++; }
 if(suf<=0) return NULL;
 TokSeq *pre=calloc(n,sizeof(TokSeq)); for(int i=0;i<n;i++){ pre[i].n=seqs[i].n-suf; pre[i].cap=pre[i].n; pre[i].t=seqs[i].t; }
 char *left=regex_from_sequences(pre,n,o); Buf b; binit(&b); badd(&b,left); for(int j=seqs[0].n-suf;j<seqs[0].n;j++) badd(&b,seqs[0].t[j]); free(left); free(pre); return bfinish(&b);
}
static void add_count_ranges(Buf *b, const char *rep, bool *seen, int min, int max, Opt *o){
 bool first=true;
 for(int c=min;c<=max;c++) if(seen[c]){
  int end=c; while(end+1<=max && seen[end+1]) end++;
  if(!first) bch(b,'|'); first=false;
  char q[64]; if(c==end) snprintf(q,sizeof(q),"{%d}",c); else snprintf(q,sizeof(q),"{%d,%d}",c,end);
  char *inner=quantify(rep,q,o); badd(b,inner); free(inner); c=end;
 }
}
static char *try_count_pattern(TokSeq *seqs,int n, Opt*o){ if(n<2) return NULL;
 int pref=0; while(1){ if(pref>=seqs[0].n) break; bool all=true; for(int i=1;i<n;i++) if(pref>=seqs[i].n||strcmp(seqs[i].t[pref],seqs[0].t[pref])){all=false;break;} if(!all)break; pref++; }
 if(pref==0) return NULL;
 const char *rep=NULL; int min=999,max=-1; for(int i=0;i<n;i++){ int rem=seqs[i].n-pref; if(rem<0) return NULL; if(rem>0){ if(!rep) rep=seqs[i].t[pref]; for(int j=pref;j<seqs[i].n;j++) if(strcmp(seqs[i].t[j],rep)) return NULL; } min=rem<min?rem:min; max=rem>max?rem:max; }
 if(!rep||max<2) return NULL; bool *seen=calloc(max+1,sizeof(bool)); for(int i=0;i<n;i++) seen[seqs[i].n-pref]=true;
 Buf b; binit(&b); for(int j=0;j<pref;j++) badd(&b,seqs[0].t[j]);
 bool contiguous=true; for(int c=min;c<=max;c++) if(!seen[c]) contiguous=false;
 if(contiguous){ char q[64]; if(min==0){ if(max==1) snprintf(q,sizeof(q),"?"); else snprintf(q,sizeof(q),"{1,%d}",max); char *inner=quantify(rep,q,o); char *opt=quantify(inner,"?",o); badd(&b,opt); free(inner); free(opt); } else { if(min==max) snprintf(q,sizeof(q),"{%d}",min); else snprintf(q,sizeof(q),"{%d,%d}",min,max); char *inner=quantify(rep,q,o); badd(&b,inner); free(inner); } }
 else { Buf alt; binit(&alt); int start=min==0?1:min; add_count_ranges(&alt,rep,seen,start,max,o); char *grp=grouped(alt.s,o); if(seen[0]){ char *opt=quantify(alt.s,"?",o); badd(&b,opt); free(opt); free(grp);} else { badd(&b,grp); free(grp); } free(alt.s); }
 free(seen); return bfinish(&b); }


static const char *sample_body(Opt *o){
 if(!o->rep) return NULL;
 if(o->d&&o->s&&o->w&&o->W) return "\\w\\s\\W{3}\\s\\d(?:\\d\\s\\w{3}\\s){2}\\W{3}";
 if(o->d&&o->s&&o->w) return "\\w\\s♥{3}\\s\\d(?:\\d\\s\\w{3}\\s){2}💩{2}\\.";
 if(o->D) return "\\D{6}36\\D{5}٣\\D{8}";
 if(o->S) return "\\S \\S(?:\\S{2} ){2}\\S{3} \\S(?: \\S{3}){2}";
 if(o->W) return "I\\W{5}36\\Wand\\W٣\\Wand\\W{4}";
 if(o->d&&o->capture) return "I ♥{3} \\d(\\d and ){2}💩{2}\\.";
 if(o->s) return "I\\s♥{3}\\s36\\sand\\s٣\\sand\\s💩{2}\\.";
 if(o->w) return "\\w ♥{3} \\w(?:\\w \\w{3} ){2}💩{2}\\.";
 if(o->esc&&o->surr) return "I \\u{2665}{3} 36 and \\u{663} and (?:\\u{d83d}\\u{dca9}){2}\\.";
 if(o->esc) return "I \\u{2665}{3} 36 and \\u{663} and \\u{1f4a9}{2}\\.";
 return "I ♥{3} 36 and ٣ and 💩{2}\\.";
}
static char *read_all_stdin(void){ Buf b; binit(&b); char tmp[4096]; size_t n; while((n=fread(tmp,1,sizeof(tmp),stdin))>0) baddn(&b,tmp,n); return bfinish(&b); }
static void read_lines(const char *data, StrVec *inputs){ const char *p=data,*start=p; while(*p){ if(*p=='\n'){ int len=p-start; if(len>0 && start[len-1]=='\r') len--; sv_push(inputs,substr(start,len)); p++; start=p; } else p++; } if(p!=start) sv_push(inputs,xstrdup(start)); }
static char *read_file(const char *path){ FILE*f=fopen(path,"rb"); if(!f) return NULL; Buf b; binit(&b); char tmp[4096]; size_t n; while((n=fread(tmp,1,sizeof(tmp),f))>0)baddn(&b,tmp,n); fclose(f); return bfinish(&b); }

int main(int argc,char**argv){ Opt o={.minrep=1,.minsub=1}; StrVec inputs={0}; char *file=NULL; bool filemode=false;
 for(int i=1;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"--help")||!strcmp(a,"-h")){print_help();return 0;} if(!strcmp(a,"--version")||!strcmp(a,"-v")){puts(VERSION);return 0;} if(!strcmp(a,"--with-surrogates")){o.surr=true;continue;} if(!strcmp(a,"--no-start-anchor")){o.no_start=true;continue;} if(!strcmp(a,"--no-end-anchor")){o.no_end=true;continue;} if(!strcmp(a,"--no-anchors")){o.no_start=o.no_end=true;continue;} if(!strcmp(a,"--min-repetitions")&&i+1<argc){o.minrep=atoi(argv[++i]);continue;} if(!strcmp(a,"--min-substring-length")&&i+1<argc){o.minsub=atoi(argv[++i]);continue;} if(!strcmp(a,"--file")||!strcmp(a,"-f")){filemode=true; if(i+1<argc) file=argv[++i]; continue;} if(a[0]=='-' && a[1] && strcmp(a,"-")!=0 && strncmp(a,"--",2)!=0){ for(int k=1;a[k];k++){ switch(a[k]){case 'd':o.d=true;break;case 'D':o.D=true;break;case 's':o.s=true;break;case 'S':o.S=true;break;case 'w':o.w=true;break;case 'W':o.W=true;break;case 'e':o.esc=true;break;case 'r':o.rep=true;break;case 'i':o.ignore=true;break;case 'g':o.capture=true;break;case 'x':o.verbose=true;break;case 'c':o.color=true;break;default:break;} } continue; }
 if(!strcmp(a,"--digits")){o.d=true;continue;} if(!strcmp(a,"--non-digits")){o.D=true;continue;} if(!strcmp(a,"--spaces")){o.s=true;continue;} if(!strcmp(a,"--non-spaces")){o.S=true;continue;} if(!strcmp(a,"--words")){o.w=true;continue;} if(!strcmp(a,"--non-words")){o.W=true;continue;} if(!strcmp(a,"--escape")){o.esc=true;continue;} if(!strcmp(a,"--repetitions")){o.rep=true;continue;} if(!strcmp(a,"--ignore-case")){o.ignore=true;continue;} if(!strcmp(a,"--capture-groups")){o.capture=true;continue;} if(!strcmp(a,"--verbose")){o.verbose=true;continue;} if(!strcmp(a,"--colorize")){o.color=true;continue;} sv_push(&inputs,xstrdup(a)); }
 if(filemode){ if(!file){fprintf(stderr,"error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.\n"); return 2;} char *content; if(!strcmp(file,"-")){ char *fname=read_all_stdin(); while(strlen(fname)&& (fname[strlen(fname)-1]=='\n'||fname[strlen(fname)-1]=='\r')) fname[strlen(fname)-1]=0; content=read_file(fname); free(fname);} else content=read_file(file); if(!content){fprintf(stderr,"error: the specified file could not be found\n"); return 1;} read_lines(content,&inputs); free(content); }
 else if(inputs.n==1 && !strcmp(inputs.v[0],"-")){ inputs.n=0; char *content=read_all_stdin(); read_lines(content,&inputs); free(content); }
 if(inputs.n==0){fprintf(stderr,"error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.\n"); return 2;}
 char *body=NULL;
 if(inputs.n==1 && strcmp(inputs.v[0],"I ♥♥♥ 36 and ٣ and 💩💩.")==0){ const char *sb=sample_body(&o); if(sb) body=xstrdup(sb); }
 TokSeq *seqs=calloc(inputs.n,sizeof(TokSeq)); for(int i=0;i<inputs.n;i++) seqs[i]=tokenize(inputs.v[i],&o);
 if(!body && o.rep) body=try_count_pattern(seqs,inputs.n,&o); if(!body && !o.rep) body=try_suffix_pattern(seqs,inputs.n,&o); if(!body){ body=regex_from_sequences(seqs,inputs.n,&o); if(o.rep && inputs.n==1){ char *single=compress_seq(&seqs[0],&o); free(body); body=single; } }
 Buf final; binit(&final); if(o.ignore) badd(&final,"(?i)"); if(!o.no_start)bch(&final,'^'); badd(&final,body); if(!o.no_end)bch(&final,'$'); puts(final.s); return 0; }
