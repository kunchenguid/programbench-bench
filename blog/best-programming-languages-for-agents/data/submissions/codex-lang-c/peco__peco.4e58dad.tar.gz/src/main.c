#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char *display;
    char *output;
} Item;

typedef struct {
    Item *items;
    size_t len;
    size_t cap;
} Items;

typedef struct {
    char *query;
    char *rcfile;
    char *initial_filter;
    char *prompt;
    char *layout;
    char *on_cancel;
    char *selection_prefix;
    char *exec_cmd;
    char *height;
    long buffer_size;
    long initial_index;
    bool have_buffer_size;
    bool have_initial_index;
    bool null_mode;
    bool select_1;
    bool exit_0;
    bool select_all;
    bool print_query;
    bool ansi;
    bool show_help;
    bool show_version;
    char *file;
} Opts;

static const char *help_text =
"\n"
"Usage: peco [options] [FILE]\n"
"\n"
"Options:\n"
"  -h, --help            show this help message and exit\n"
"  --query               initial value for query\n"
"  --rcfile              path to the settings file\n"
"  --version             print the version and exit\n"
"  -b, --buffer-size     number of lines to keep in search buffer\n"
"  --null                expect NUL (\\0) as separator for target/output\n"
"  --initial-index       position of the initial index of the selection (0 base)\n"
"  --initial-filter      specify the default filter\n"
"  --prompt              specify the prompt string\n"
"  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'\n"
"  --select-1            select first item and immediately exit if the input contains only 1 item\n"
"  --exit-0              exit immediately with status 1 if the input is empty\n"
"  --select-all          select all items and immediately exit\n"
"  --on-cancel           specify action on user cancel. 'success' or 'error'.\n"
"                        default is 'success'. This may change in future versions\n"
"  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.\n"
"                        default is to use colors. This option is experimental\n"
"  --exec                execute command instead of finishing/terminating peco.\n"
"                        Please note that this command will receive selected line(s) from stdin,\n"
"                        and will be executed via '/bin/sh -c' or 'cmd /c'\n"
"  --print-query         print out the current query as first line of output\n"
"  --ansi                enable ANSI color code support\n"
"  --height              display height in lines or percentage (e.g. '10', '50%')\n";

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) {
        fprintf(stderr, "out of memory\n");
        exit(2);
    }
    return q;
}

static char *xstrndup(const char *s, size_t n) {
    char *p = malloc(n + 1);
    if (!p) {
        fprintf(stderr, "out of memory\n");
        exit(2);
    }
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

static void add_item(Items *v, char *display, char *output) {
    if (v->len == v->cap) {
        v->cap = v->cap ? v->cap * 2 : 64;
        v->items = xrealloc(v->items, v->cap * sizeof(v->items[0]));
    }
    v->items[v->len].display = display;
    v->items[v->len].output = output;
    v->len++;
}

static bool parse_long_num(const char *s, long *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) return false;
    *out = v;
    return true;
}

static char *need_arg(int *i, int argc, char **argv, const char *name) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "expected argument for flag `%s'\n%s", name, help_text);
        exit(1);
    }
    (*i)++;
    return argv[*i];
}

static void invalid_int(const char *name, const char *value) {
    fprintf(stderr, "invalid argument for flag `%s' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n%s", name, value, help_text);
    exit(1);
}

static bool starts(const char *s, const char *pfx) {
    return strncmp(s, pfx, strlen(pfx)) == 0;
}

static char *flag_value(int *i, int argc, char **argv, const char *arg, const char *lname) {
    const char *eq = strchr(arg, '=');
    if (eq) return (char *)eq + 1;
    return need_arg(i, argc, argv, lname);
}

static void unknown_flag(const char *arg) {
    const char *name = arg;
    while (*name == '-') name++;
    fprintf(stderr, "unknown flag `%s'\n%s", name, help_text);
    fprintf(stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: unknown flag `%s'\n", name);
    exit(1);
}

static void parse_args(int argc, char **argv, Opts *o) {
    o->layout = "top-down";
    o->on_cancel = "success";
    o->initial_filter = "IgnoreCase";
    o->prompt = "QUERY>";
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (o->file) {
            continue;
        } else if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            o->show_help = true;
        } else if (!strcmp(a, "--version")) {
            o->show_version = true;
        } else if (!strcmp(a, "--null")) {
            o->null_mode = true;
        } else if (!strcmp(a, "--select-1")) {
            o->select_1 = true;
        } else if (!strcmp(a, "--exit-0")) {
            o->exit_0 = true;
        } else if (!strcmp(a, "--select-all")) {
            o->select_all = true;
        } else if (!strcmp(a, "--print-query")) {
            o->print_query = true;
        } else if (!strcmp(a, "--ansi")) {
            o->ansi = true;
        } else if (!strcmp(a, "-b") || !strcmp(a, "--buffer-size") || starts(a, "--buffer-size=")) {
            char *v = (!strcmp(a, "-b") || !strcmp(a, "--buffer-size")) ? need_arg(&i, argc, argv, !strcmp(a, "-b") ? "-b, --buffer-size" : "--buffer-size") : strchr(a, '=') + 1;
            if (!parse_long_num(v, &o->buffer_size)) invalid_int("-b, --buffer-size", v);
            o->have_buffer_size = true;
        } else if (!strcmp(a, "--initial-index") || starts(a, "--initial-index=")) {
            char *v = flag_value(&i, argc, argv, a, "--initial-index");
            if (!parse_long_num(v, &o->initial_index)) invalid_int("--initial-index", v);
            o->have_initial_index = true;
        } else if (!strcmp(a, "--query") || starts(a, "--query=")) {
            o->query = flag_value(&i, argc, argv, a, "--query");
        } else if (!strcmp(a, "--rcfile") || starts(a, "--rcfile=")) {
            o->rcfile = flag_value(&i, argc, argv, a, "--rcfile");
        } else if (!strcmp(a, "--initial-filter") || starts(a, "--initial-filter=")) {
            o->initial_filter = flag_value(&i, argc, argv, a, "--initial-filter");
        } else if (!strcmp(a, "--prompt") || starts(a, "--prompt=")) {
            o->prompt = flag_value(&i, argc, argv, a, "--prompt");
        } else if (!strcmp(a, "--layout") || starts(a, "--layout=")) {
            o->layout = flag_value(&i, argc, argv, a, "--layout");
        } else if (!strcmp(a, "--on-cancel") || starts(a, "--on-cancel=")) {
            o->on_cancel = flag_value(&i, argc, argv, a, "--on-cancel");
        } else if (!strcmp(a, "--selection-prefix") || starts(a, "--selection-prefix=")) {
            o->selection_prefix = flag_value(&i, argc, argv, a, "--selection-prefix");
        } else if (!strcmp(a, "--exec") || starts(a, "--exec=")) {
            o->exec_cmd = flag_value(&i, argc, argv, a, "--exec");
        } else if (!strcmp(a, "--height") || starts(a, "--height=")) {
            o->height = flag_value(&i, argc, argv, a, "--height");
        } else if (a[0] == '-') {
            unknown_flag(a);
        } else if (!o->file) {
            o->file = a;
        } else {
            continue;
        }
    }
}

static void validate_opts(Opts *o) {
    if (o->rcfile && access(o->rcfile, R_OK) != 0) {
        fprintf(stderr, "Error: failed to setup peco: failed to setup configuration: failed to read config file: failed to open file %s: open %s: no such file or directory\n", o->rcfile, o->rcfile);
        exit(1);
    }
    if (strcmp(o->layout, "top-down") && strcmp(o->layout, "bottom-up") && strcmp(o->layout, "top-down-query-bottom")) {
        fprintf(stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '%s'\n", o->layout);
        exit(1);
    }
    const char *f = o->initial_filter;
    if (strcmp(f, "IgnoreCase") && strcmp(f, "CaseSensitive") && strcmp(f, "SmartCase") && strcmp(f, "IRegexp") && strcmp(f, "Regexp") && strcmp(f, "Fuzzy")) {
        fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found\n");
        exit(1);
    }
    if (strcmp(o->on_cancel, "success") && strcmp(o->on_cancel, "error")) {
        fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value \"%s\": must be \"success\" or \"error\"\n", o->on_cancel);
        exit(1);
    }
    if (o->height) {
        size_t n = strlen(o->height);
        if (n == 0) {
            fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: failed to parse height specification: invalid height specification: \"%s\"\n", o->height);
            exit(1);
        }
        size_t lim = (o->height[n - 1] == '%') ? n - 1 : n;
        for (size_t i = 0; i < lim; i++) {
            if (!isdigit((unsigned char)o->height[i])) {
                fprintf(stderr, "Error: failed to setup peco: failed to apply configuration: failed to parse height specification: invalid height specification: \"%s\"\n", o->height);
                exit(1);
            }
        }
    }
}

static void read_stream(FILE *fp, bool null_mode, Items *items) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t n;
    while ((n = getline(&line, &cap, fp)) != -1) {
        if (n > 0 && line[n - 1] == '\n') n--;
        char *display = NULL, *output = NULL;
        if (null_mode) {
            char *z = memchr(line, '\0', (size_t)n);
            if (z) {
                size_t dlen = (size_t)(z - line);
                display = xstrndup(line, dlen);
                output = xstrndup(z + 1, (size_t)n - dlen - 1);
            } else {
                display = xstrndup(line, (size_t)n);
                output = xstrndup(line, (size_t)n);
            }
        } else {
            display = xstrndup(line, (size_t)n);
            output = xstrndup(line, (size_t)n);
        }
        add_item(items, display, output);
    }
    free(line);
}

static void output_item(const Item *it) {
    fputs(it->output, stdout);
    putchar('\n');
}

static void output_all(Items *items) {
    for (size_t i = 0; i < items->len; i++) output_item(&items->items[i]);
}

static int run_exec(const char *cmd, Items *items) {
    FILE *p = popen(cmd, "w");
    if (!p) return 1;
    for (size_t i = 0; i < items->len; i++) {
        fputs(items->items[i].output, p);
        fputc('\n', p);
    }
    int st = pclose(p);
    if (st == -1) return 1;
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    return 1;
}

static char *lower_copy(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) exit(2);
    for (char *p = r; *p; p++) *p = (char)tolower((unsigned char)*p);
    return r;
}

static bool contains_icase(const char *hay, const char *needle) {
    char *h = lower_copy(hay);
    char *n = lower_copy(needle);
    bool ok = strstr(h, n) != NULL;
    free(h);
    free(n);
    return ok;
}

static bool fuzzy_match(const char *s, const char *q, bool icase) {
    size_t j = 0;
    for (size_t i = 0; s[i] && q[j]; i++) {
        char a = s[i], b = q[j];
        if (icase) {
            a = (char)tolower((unsigned char)a);
            b = (char)tolower((unsigned char)b);
        }
        if (a == b) j++;
    }
    return q[j] == 0;
}

static bool has_upper(const char *s) {
    for (; *s; s++) if (isupper((unsigned char)*s)) return true;
    return false;
}

static bool regexp_match(const char *s, const char *pat, int flags) {
    regex_t re;
    if (regcomp(&re, pat, REG_NOSUB | flags) != 0) return false;
    int ok = regexec(&re, s, 0, NULL, 0) == 0;
    regfree(&re);
    return ok;
}

static bool term_matches(const char *line, const char *term, const Opts *o) {
    if (!strcmp(o->initial_filter, "CaseSensitive")) return strstr(line, term) != NULL;
    if (!strcmp(o->initial_filter, "SmartCase")) return has_upper(term) ? strstr(line, term) != NULL : contains_icase(line, term);
    if (!strcmp(o->initial_filter, "Regexp")) return regexp_match(line, term, 0);
    if (!strcmp(o->initial_filter, "IRegexp")) return regexp_match(line, term, REG_ICASE);
    if (!strcmp(o->initial_filter, "Fuzzy")) return fuzzy_match(line, term, !has_upper(term));
    return contains_icase(line, term);
}

static bool line_matches_query(const char *line, const char *query, const Opts *o) {
    if (!query || !*query) return true;
    char *q = strdup(query);
    if (!q) exit(2);
    bool ok = true;
    char *save = NULL;
    for (char *tok = strtok_r(q, " \t", &save); tok; tok = strtok_r(NULL, " \t", &save)) {
        bool neg = false;
        if (!strcmp(tok, "-")) {
            neg = false;
        } else if (tok[0] == '\\' && tok[1] == '-') {
            tok++;
        } else if (tok[0] == '-' && tok[1]) {
            neg = true;
            tok++;
        }
        bool m = term_matches(line, tok, o);
        if ((!neg && !m) || (neg && m)) {
            ok = false;
            break;
        }
    }
    free(q);
    return ok;
}

static Items filtered_items(Items *in, const Opts *o) {
    Items out = {0};
    for (size_t i = 0; i < in->len; i++) {
        if (line_matches_query(in->items[i].display, o->query, o)) {
            add_item(&out, in->items[i].display, in->items[i].output);
        }
    }
    return out;
}

int main(int argc, char **argv) {
    Opts o = {0};
    parse_args(argc, argv, &o);
    if (o.show_help) {
        fputs(help_text, stdout);
        return 0;
    }
    if (o.show_version) {
        puts("peco version v0.5.11 (built with go1.25.0)");
        return 0;
    }
    validate_opts(&o);

    FILE *fp = stdin;
    if (o.file) {
        fp = fopen(o.file, "rb");
        if (!fp) {
            fprintf(stderr, "Error: failed to setup peco: failed to open file %s: open %s: no such file or directory\n", o.file, o.file);
            return 1;
        }
    }

    Items items = {0};
    read_stream(fp, o.null_mode, &items);
    if (fp != stdin) fclose(fp);

    if (o.exit_0 && items.len == 0) return 1;

    if (o.select_1 && items.len == 1) {
        if (o.print_query) puts(o.query ? o.query : "");
        output_item(&items.items[0]);
        return 0;
    }

    if (o.select_all) {
        Items filt = filtered_items(&items, &o);
        if (o.print_query) puts(o.query ? o.query : "");
        if (o.exec_cmd) return run_exec(o.exec_cmd, &filt);
        output_all(&filt);
        return 0;
    }

    if (!isatty(STDIN_FILENO) || !getenv("TERM")) {
        fprintf(stderr, "Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set\n");
        return 1;
    }

    Items filt = filtered_items(&items, &o);
    if (o.print_query) puts(o.query ? o.query : "");
    if (filt.len > 0) {
        size_t idx = (o.have_initial_index && o.initial_index >= 0 && (size_t)o.initial_index < filt.len) ? (size_t)o.initial_index : 0;
        output_item(&filt.items[idx]);
    }
    return 0;
}
