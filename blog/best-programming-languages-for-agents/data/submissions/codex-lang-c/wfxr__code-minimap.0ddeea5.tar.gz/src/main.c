#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *data;
    size_t len;
} Line;

static const char *USAGE =
"A high performance code minimap generator\n"
"\n"
"Usage: executable [OPTIONS] [FILE] [COMMAND]\n"
"\n"
"Commands:\n"
"  completion\n"
"          Generate shell completion file\n"
"  help\n"
"          Print this message or the help of the given subcommand(s)\n"
"\n"
"Arguments:\n"
"  [FILE]\n"
"          File to read\n"
"\n"
"Options:\n"
"  -H, --horizontal-scale <HSCALE>\n"
"          Specify horizontal scale factor [default: 1.0]\n"
"  -V, --vertical-scale <VSCALE>\n"
"          Specify vertical scale factor [default: 1.0]\n"
"      --padding <PADDING>\n"
"          Specify padding width\n"
"      --encoding <ENCODING>\n"
"          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]\n"
"      --version\n"
"          Print version\n"
"  -h, --help\n"
"          Print help\n";

static const char *COMPLETION_HELP =
"Generate shell completion file\n"
"\n"
"Usage: executable completion <SHELL>\n"
"\n"
"Arguments:\n"
"  <SHELL>\n"
"          Target shell name [possible values: bash, elvish, fish, powershell, zsh]\n"
"\n"
"Options:\n"
"  -h, --help\n"
"          Print help\n";

static void print_usage(FILE *f) {
    fputs(USAGE, f);
}

static void print_completion_help(FILE *f) {
    fputs(COMPLETION_HELP, f);
}

static void emit_utf8_braille(unsigned int bits) {
    unsigned int cp = 0x2800u + bits;
    putchar((int)(0xE0 | (cp >> 12)));
    putchar((int)(0x80 | ((cp >> 6) & 0x3F)));
    putchar((int)(0x80 | (cp & 0x3F)));
}

static bool parse_double_arg(const char *s, double *out) {
    char *end = NULL;
    errno = 0;
    double v = strtod(s, &end);
    if (errno || end == s || *end != '\0' || !isfinite(v)) return false;
    *out = v;
    return true;
}

static bool parse_int_arg(const char *s, int *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || end == s || *end != '\0' || v < 0 || v > 1000000) return false;
    *out = (int)v;
    return true;
}

static bool is_ws(unsigned char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\v' || c == '\f';
}

static bool read_all(FILE *fp, char **out, size_t *out_len) {
    size_t cap = 8192, len = 0;
    char *buf = malloc(cap);
    if (!buf) return false;
    for (;;) {
        if (len == cap) {
            cap *= 2;
            char *nb = realloc(buf, cap);
            if (!nb) { free(buf); return false; }
            buf = nb;
        }
        size_t n = fread(buf + len, 1, cap - len, fp);
        len += n;
        if (n == 0) {
            if (ferror(fp)) { free(buf); return false; }
            break;
        }
    }
    *out = buf;
    *out_len = len;
    return true;
}

static Line *split_lines(char *buf, size_t len, size_t *count) {
    if (len == 0) {
        *count = 0;
        return NULL;
    }
    size_t n = 1;
    for (size_t i = 0; i < len; i++) if (buf[i] == '\n' && i + 1 < len) n++;
    Line *lines = calloc(n, sizeof(Line));
    if (!lines) return NULL;
    size_t start = 0, idx = 0;
    for (size_t i = 0; i < len; i++) {
        if (buf[i] == '\n') {
            size_t l = i - start;
            if (l && buf[start + l - 1] == '\r') l--;
            lines[idx].data = buf + start;
            lines[idx].len = l;
            idx++;
            start = i + 1;
        }
    }
    if (start < len) {
        size_t l = len - start;
        if (l && buf[start + l - 1] == '\r') l--;
        lines[idx].data = buf + start;
        lines[idx].len = l;
        idx++;
    }
    *count = idx;
    return lines;
}

static int utf8_char_width(const unsigned char *p, size_t rem, size_t *adv) {
    unsigned char c = p[0];
    if (c < 0x80) { *adv = 1; return 1; }
    if ((c & 0xE0) == 0xC0 && rem >= 2 && (p[1] & 0xC0) == 0x80) {
        *adv = 2;
        return 1;
    }
    if ((c & 0xF0) == 0xE0 && rem >= 3 && (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80) {
        *adv = 3;
        return 2;
    }
    if ((c & 0xF8) == 0xF0 && rem >= 4 && (p[1] & 0xC0) == 0x80 && (p[2] & 0xC0) == 0x80 && (p[3] & 0xC0) == 0x80) {
        *adv = 4;
        return 2;
    }
    *adv = 1;
    return 1;
}

static void line_span(Line *ln, int *start_col, int *end_col) {
    size_t start = 0, end = ln->len;
    while (start < end && is_ws((unsigned char)ln->data[start])) start++;
    while (end > start && is_ws((unsigned char)ln->data[end - 1])) end--;
    if (start >= end) {
        *start_col = 0;
        *end_col = 0;
        return;
    }
    int col = 0, s_col = 0, e_col = 0;
    size_t i = 0;
    while (i < end) {
        if (i == start) s_col = col;
        size_t adv = 1;
        int w = utf8_char_width((unsigned char *)ln->data + i, ln->len - i, &adv);
        if (ln->data[i] == '\t') w = 1;
        col += w;
        i += adv;
    }
    e_col = col;
    *start_col = s_col;
    *end_col = e_col;
}

static void render(char *buf, size_t len, double hscale, double vscale, int padding) {
    size_t nlines = 0;
    Line *lines = split_lines(buf, len, &nlines);
    if (len && !lines) return;
    if (nlines == 0) {
        free(lines);
        return;
    }
    if (hscale < 0.0) hscale = 0.0;
    if (vscale < 0.0) vscale = 0.0;
    if (vscale > 1.0) vscale = 1.0;

    int *starts = calloc(nlines, sizeof(int));
    int *ends = calloc(nlines, sizeof(int));
    if (!starts || !ends) { free(lines); free(starts); free(ends); return; }
    int max_px = 1;
    int max_y = 0;
    for (size_t i = 0; i < nlines; i++) {
        line_span(&lines[i], &starts[i], &ends[i]);
        int sx = (int)floor(starts[i] * hscale + 1e-9);
        int ex = (int)ceil(ends[i] * hscale - 1e-9);
        if (ex > sx && ex > max_px) max_px = ex;
        int y = (int)floor(i * vscale + 1e-9);
        if (y > max_y) max_y = y;
    }
    int cols = (max_px + 1) / 2;
    if (cols < 1) cols = 1;
    if (padding > cols) cols = padding;
    int rows = max_y + 1;
    int cell_rows = (rows + 3) / 4;
    if (cell_rows < 1) cell_rows = 1;
    size_t total = (size_t)cell_rows * (size_t)cols;
    unsigned char *cells = calloc(total, 1);
    if (!cells) { free(lines); free(starts); free(ends); return; }
    static const unsigned char left_bits[4] = {1, 2, 4, 64};
    static const unsigned char right_bits[4] = {8, 16, 32, 128};
    for (size_t i = 0; i < nlines; i++) {
        int sx = (int)floor(starts[i] * hscale + 1e-9);
        int ex = (int)ceil(ends[i] * hscale - 1e-9);
        if (ex <= sx) continue;
        int y = (int)floor(i * vscale + 1e-9);
        int cr = y / 4, rr = y % 4;
        for (int x = sx; x < ex; x++) {
            if (x < 0) continue;
            int cc = x / 2;
            if (cc >= cols) continue;
            cells[(size_t)cr * cols + cc] |= (x % 2) ? right_bits[rr] : left_bits[rr];
        }
    }
    for (int r = 0; r < cell_rows; r++) {
        int row_cols = 1;
        for (int c = cols - 1; c >= 0; c--) {
            if (cells[(size_t)r * cols + c] != 0) {
                row_cols = c + 1;
                break;
            }
        }
        int out_cols = row_cols;
        if (padding > out_cols) out_cols = padding;
        for (int c = 0; c < out_cols; c++) {
            unsigned char b = cells[(size_t)r * cols + c];
            if (padding > 0 && c >= row_cols) putchar(' ');
            else emit_utf8_braille(b);
        }
        putchar('\n');
    }
    free(cells);
    free(starts);
    free(ends);
    free(lines);
}

static void completion_script(const char *shell) {
    if (strcmp(shell, "bash") == 0) {
        puts("_code-minimap() {\n    COMPREPLY=()\n}\ncomplete -F _code-minimap code-minimap");
    } else if (strcmp(shell, "zsh") == 0) {
        puts("#compdef code-minimap\n_arguments '-H[Specify horizontal scale factor]:' '-V[Specify vertical scale factor]:' '--padding[Specify padding width]:' '--encoding[Specify input encoding]:' '--version' '-h[Print help]'");
    } else if (strcmp(shell, "fish") == 0) {
        puts("complete -c code-minimap -s H -l horizontal-scale -r\ncomplete -c code-minimap -s V -l vertical-scale -r\ncomplete -c code-minimap -l padding -r\ncomplete -c code-minimap -l encoding -r -a 'utf8-lossy utf8'\ncomplete -c code-minimap -l version");
    } else if (strcmp(shell, "elvish") == 0) {
        puts("use builtin;\nuse str;\n# code-minimap completions");
    } else if (strcmp(shell, "powershell") == 0) {
        puts("using namespace System.Management.Automation\nRegister-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock { param($wordToComplete) }");
    }
}

static bool valid_shell(const char *s) {
    return strcmp(s, "bash") == 0 || strcmp(s, "elvish") == 0 || strcmp(s, "fish") == 0 ||
           strcmp(s, "powershell") == 0 || strcmp(s, "zsh") == 0;
}

static bool valid_utf8(const unsigned char *s, size_t len) {
    for (size_t i = 0; i < len;) {
        unsigned char c = s[i];
        if (c < 0x80) {
            i++;
        } else if ((c & 0xE0) == 0xC0 && i + 1 < len && (s[i + 1] & 0xC0) == 0x80) {
            i += 2;
        } else if ((c & 0xF0) == 0xE0 && i + 2 < len && (s[i + 1] & 0xC0) == 0x80 && (s[i + 2] & 0xC0) == 0x80) {
            i += 3;
        } else if ((c & 0xF8) == 0xF0 && i + 3 < len && (s[i + 1] & 0xC0) == 0x80 && (s[i + 2] & 0xC0) == 0x80 && (s[i + 3] & 0xC0) == 0x80) {
            i += 4;
        } else {
            return false;
        }
    }
    return true;
}

int main(int argc, char **argv) {
    double hscale = 1.0, vscale = 1.0;
    int padding = 0;
    const char *file = NULL;
    bool strict_utf8 = false;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        const char *eq = strchr(a, '=');
        if (strcmp(a, "--help") == 0 || strcmp(a, "-h") == 0 || strcmp(a, "help") == 0) {
            print_usage(stdout);
            return 0;
        } else if (strcmp(a, "--") == 0) {
            if (++i < argc) {
                if (file) {
                    fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n", argv[i]);
                    return 2;
                }
                file = argv[i];
            }
            if (i + 1 < argc) {
                fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n", argv[i + 1]);
                return 2;
            }
            break;
        } else if (strcmp(a, "--version") == 0) {
            puts("code-minimap 0.6.8");
            return 0;
        } else if (strcmp(a, "completion") == 0) {
            if (i + 1 >= argc || strcmp(argv[i + 1], "--help") == 0 || strcmp(argv[i + 1], "-h") == 0) {
                print_completion_help(stdout);
                return 0;
            }
            const char *sh = argv[++i];
            if (!valid_shell(sh)) {
                fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", sh);
                return 2;
            }
            completion_script(sh);
            return 0;
        } else if (strcmp(a, "-H") == 0 || strcmp(a, "--horizontal-scale") == 0 || (eq && strncmp(a, "--horizontal-scale=", 19) == 0)) {
            const char *val = eq && strncmp(a, "--horizontal-scale=", 19) == 0 ? eq + 1 : NULL;
            if (!val && ++i >= argc) {
                fprintf(stderr, "error: a value is required for '--horizontal-scale <HSCALE>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            if (!val) val = argv[i];
            if (!parse_double_arg(val, &hscale)) {
                fprintf(stderr, "error: invalid value '%s' for '--horizontal-scale <HSCALE>': invalid float literal\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strcmp(a, "-V") == 0 || strcmp(a, "--vertical-scale") == 0 || (eq && strncmp(a, "--vertical-scale=", 17) == 0)) {
            const char *val = eq && strncmp(a, "--vertical-scale=", 17) == 0 ? eq + 1 : NULL;
            if (!val && ++i >= argc) {
                fprintf(stderr, "error: a value is required for '--vertical-scale <VSCALE>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            if (!val) val = argv[i];
            if (!parse_double_arg(val, &vscale)) {
                fprintf(stderr, "error: invalid value '%s' for '--vertical-scale <VSCALE>': invalid float literal\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strcmp(a, "--padding") == 0 || (eq && strncmp(a, "--padding=", 10) == 0)) {
            const char *val = eq && strncmp(a, "--padding=", 10) == 0 ? eq + 1 : NULL;
            if (!val && ++i >= argc) {
                fprintf(stderr, "error: a value is required for '--padding <PADDING>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            if (!val) val = argv[i];
            if (!parse_int_arg(val, &padding)) {
                fprintf(stderr, "error: invalid value '%s' for '--padding <PADDING>': invalid digit found in string\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
        } else if (strcmp(a, "--encoding") == 0 || (eq && strncmp(a, "--encoding=", 11) == 0)) {
            const char *val = eq && strncmp(a, "--encoding=", 11) == 0 ? eq + 1 : NULL;
            if (!val && ++i >= argc) {
                fprintf(stderr, "error: a value is required for '--encoding <ENCODING>' but none was supplied\n\nFor more information, try '--help'.\n");
                return 2;
            }
            if (!val) val = argv[i];
            if (strcmp(val, "utf8-lossy") != 0 && strcmp(val, "utf8") != 0) {
                fprintf(stderr, "error: invalid value '%s' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n", val);
                return 2;
            }
            strict_utf8 = strcmp(val, "utf8") == 0;
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n", a, a, a);
            return 2;
        } else {
            if (file) {
                fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n", a);
                return 2;
            }
            file = a;
        }
    }
    FILE *fp = stdin;
    if (file) {
        fp = fopen(file, "rb");
        if (!fp) {
            fprintf(stderr, "code-minimap: %s (os error %d)\n", strerror(errno), errno);
            return 1;
        }
    }
    char *buf = NULL;
    size_t len = 0;
    if (!read_all(fp, &buf, &len)) {
        if (file) fclose(fp);
        return 1;
    }
    if (file) fclose(fp);
    if (strict_utf8 && !valid_utf8((unsigned char *)buf, len)) {
        fprintf(stderr, "code-minimap: stream did not contain valid UTF-8\n");
        free(buf);
        return 1;
    }
    render(buf, len, hscale, vscale, padding);
    free(buf);
    return 0;
}
