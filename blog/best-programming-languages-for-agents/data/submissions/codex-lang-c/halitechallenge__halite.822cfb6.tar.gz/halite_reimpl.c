#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    int owner;
    int strength;
    int prod;
} Cell;

typedef struct {
    char *cmd;
    char name[64];
    pid_t pid;
    int in_fd;
    int out_fd;
    FILE *in;
    int alive;
    int last_alive;
} Player;

static const char *brief_usage =
"Brief USAGE: \n"
"   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a\n"
"                 string containing two space-seprated positive integers>]\n"
"                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]\n"
"                 [-h] <Array of strings> ...\n"
"\n"
"For complete USAGE and HELP type: \n"
"   ./executable --help\n";

static void print_help(void) {
    puts("");
    puts("USAGE: ");
    puts("");
    puts("   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a");
    puts("                 string containing two space-seprated positive integers>]");
    puts("                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]");
    puts("                 [-h] <Array of strings> ...");
    puts("");
    puts("");
    puts("Where: ");
    puts("");
    puts("   -i <path to directory>,  --replaydirectory <path to directory>");
    puts("     The path to directory for replay output.");
    puts("");
    puts("   -s <positive integer>,  --seed <positive integer>");
    puts("     The seed for the map generator.");
    puts("");
    puts("   -d <a string containing two space-seprated positive integers>, ");
    puts("      --dimensions <a string containing two space-seprated positive");
    puts("      integers>");
    puts("     The dimensions of the map.");
    puts("");
    puts("   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>");
    puts("     Create a map that will accommodate n players [SINGLE PLAYER MODE");
    puts("     ONLY].");
    puts("");
    puts("   -r,  --noreplay");
    puts("     Turns off the replay generation.");
    puts("");
    puts("   -t,  --timeout");
    puts("     Causes game environment to ignore timeouts (give all bots infinite");
    puts("     time).");
    puts("");
    puts("   -o,  --override");
    puts("     Overrides player-sent names using cmd args [SERVER ONLY].");
    puts("");
    puts("   -q,  --quiet");
    puts("     Runs game in quiet mode, producing machine-parsable output.");
    puts("");
    puts("   --,  --ignore_rest");
    puts("     Ignores the rest of the labeled arguments following this flag.");
    puts("");
    puts("   --version");
    puts("     Displays version information and exits.");
    puts("");
    puts("   -h,  --help");
    puts("     Displays usage information and exits.");
    puts("");
    puts("   <Array of strings>  (accepted multiple times)");
    puts("     Start commands for bots.");
    puts("");
    puts("");
    puts("   Halite Game Environment");
    puts("");
}

static int parse_pos_int(const char *s, int *out) {
    char *end = NULL;
    long v;
    errno = 0;
    if (!s || !*s) return 0;
    v = strtol(s, &end, 10);
    if (errno || *end || v <= 0 || v > 1000000) return 0;
    *out = (int)v;
    return 1;
}

static void parse_error(const char *arg, const char *longarg, const char *value) {
    printf("PARSE ERROR: Argument: %s (%s)\n", arg, longarg);
    printf("             Couldn't read argument value from string '%s'\n\n", value ? value : "");
    printf("%s", brief_usage);
}

static void appendf(char **buf, size_t *cap, size_t *len, const char *fmt, ...) {
    va_list ap;
    while (1) {
        if (*cap - *len < 128) {
            *cap = *cap ? *cap * 2 : 4096;
            *buf = realloc(*buf, *cap);
            if (!*buf) exit(2);
        }
        va_start(ap, fmt);
        int n = vsnprintf(*buf + *len, *cap - *len, fmt, ap);
        va_end(ap);
        if (n < 0) exit(2);
        if ((size_t)n < *cap - *len) {
            *len += (size_t)n;
            return;
        }
        *cap *= 2;
        *buf = realloc(*buf, *cap);
        if (!*buf) exit(2);
    }
}

static char *production_string(Cell *map, int w, int h) {
    char *buf = NULL; size_t cap = 0, len = 0;
    for (int i = 0; i < w * h; i++) appendf(&buf, &cap, &len, "%d ", map[i].prod);
    return buf;
}

static char *frame_string(Cell *map, int w, int h) {
    char *buf = NULL; size_t cap = 0, len = 0;
    int total = w * h, i = 0;
    while (i < total) {
        int owner = map[i].owner, count = 1;
        while (i + count < total && map[i + count].owner == owner) count++;
        appendf(&buf, &cap, &len, "%d %d ", count, owner);
        i += count;
    }
    for (i = 0; i < total; i++) appendf(&buf, &cap, &len, "%d ", map[i].strength);
    return buf;
}

static unsigned rnd_state;
static unsigned rnd_next(void) {
    rnd_state = rnd_state * 1103515245u + 12345u;
    return (rnd_state / 65536u) % 32768u;
}

static void make_map(Cell *map, int w, int h, int players, unsigned seed) {
    rnd_state = seed ? seed : (unsigned)time(NULL);
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            int idx = y * w + x;
            int cx = x < w / 2 ? x : w - 1 - x;
            int cy = y < h / 2 ? y : h - 1 - y;
            map[idx].owner = 0;
            map[idx].prod = 1 + ((cx * 3 + cy * 5 + (int)(rnd_next() % 5)) % 14);
            map[idx].strength = 20 + (int)(rnd_next() % 120);
        }
    }
    int xs[6] = {w / 4, (3 * w) / 4, w / 4, (3 * w) / 4, w / 2, w / 2};
    int ys[6] = {h / 4, (3 * h) / 4, (3 * h) / 4, h / 4, h / 5, (4 * h) / 5};
    for (int p = 1; p <= players; p++) {
        int x = xs[p - 1] % w, y = ys[p - 1] % h;
        int idx = y * w + x;
        map[idx].owner = p;
        map[idx].strength = 255;
        map[idx].prod = 5 + (p % 5);
    }
}

static int spawn_player(Player *p) {
    int to_child[2], from_child[2];
    if (pipe(to_child) || pipe(from_child)) return -1;
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        dup2(to_child[0], STDIN_FILENO);
        dup2(from_child[1], STDOUT_FILENO);
        close(to_child[0]); close(to_child[1]);
        close(from_child[0]); close(from_child[1]);
        execl("/bin/sh", "sh", "-c", p->cmd, (char *)NULL);
        _exit(127);
    }
    close(to_child[0]);
    close(from_child[1]);
    p->pid = pid;
    p->in_fd = to_child[1];
    p->out_fd = from_child[0];
    p->in = fdopen(p->in_fd, "w");
    setvbuf(p->in, NULL, _IONBF, 0);
    p->alive = 1;
    p->last_alive = 0;
    return 0;
}

static int read_line_timeout(int fd, char *buf, size_t n, int timeout_ms, int infinite) {
    size_t len = 0;
    int saw_line = 0;
    while (len + 1 < n) {
        if (!infinite) {
            fd_set rfds;
            struct timeval tv;
            FD_ZERO(&rfds);
            FD_SET(fd, &rfds);
            tv.tv_sec = timeout_ms / 1000;
            tv.tv_usec = (timeout_ms % 1000) * 1000;
            int r = select(fd + 1, &rfds, NULL, NULL, &tv);
            if (r <= 0) break;
        }
        char c;
        ssize_t got = read(fd, &c, 1);
        if (got <= 0) break;
        if (c == '\n') { saw_line = 1; break; }
        if (c != '\r') buf[len++] = c;
    }
    buf[len] = 0;
    return saw_line || len > 0;
}

static int is_alive_on_map(Cell *map, int total, int p) {
    for (int i = 0; i < total; i++) if (map[i].owner == p) return 1;
    return 0;
}

static void apply_moves(Cell *map, int w, int h, int pnum, char moves[][2048]) {
    Cell *next = malloc((size_t)w * h * sizeof(Cell));
    memcpy(next, map, (size_t)w * h * sizeof(Cell));
    for (int i = 0; i < w * h; i++) {
        if (next[i].owner > 0 && next[i].strength < 255) {
            next[i].strength += next[i].prod;
            if (next[i].strength > 255) next[i].strength = 255;
        }
    }
    for (int p = 1; p <= pnum; p++) {
        char *s = moves[p - 1], *end = s;
        while (*end) {
            long x = strtol(end, &end, 10);
            if (end == s) break;
            long y = strtol(end, &end, 10);
            long d = strtol(end, &end, 10);
            s = end;
            if (x < 0 || x >= w || y < 0 || y >= h || d < 0 || d > 4) continue;
            int src = (int)y * w + (int)x;
            if (map[src].owner != p || map[src].strength <= 0 || d == 0) continue;
            int nx = (int)x, ny = (int)y;
            if (d == 1) ny = (ny + h - 1) % h;
            else if (d == 2) nx = (nx + 1) % w;
            else if (d == 3) ny = (ny + 1) % h;
            else if (d == 4) nx = (nx + w - 1) % w;
            int dst = ny * w + nx;
            if (map[dst].owner == p) {
                int sum = next[dst].strength + map[src].strength;
                next[dst].strength = sum > 255 ? 255 : sum;
            } else if (map[src].strength > next[dst].strength) {
                next[dst].owner = p;
                next[dst].strength = map[src].strength - next[dst].strength;
            } else {
                next[dst].strength -= map[src].strength;
            }
            next[src].strength = 0;
        }
    }
    memcpy(map, next, (size_t)w * h * sizeof(Cell));
    free(next);
}

static void create_replay(const char *dir, int seed, int players, int w, int h) {
    char path[512];
    const char *d = dir ? dir : ".";
    snprintf(path, sizeof(path), "%s/%ld-%d.hlt", d, (long)time(NULL), seed ? seed : players);
    FILE *f = fopen(path, "w");
    if (f) {
        fprintf(f, "{\"version\":1,\"width\":%d,\"height\":%d,\"num_players\":%d}\n", w, h, players);
        fclose(f);
    }
}

int main(int argc, char **argv) {
    int seed = 0, w = 35, h = 35, nplayers_opt = 0, noreplay = 0, timeout_inf = 0, quiet = 0, override = 0;
    const char *replay_dir = ".";
    char **cmds = calloc((size_t)argc + 1, sizeof(char *));
    int ncmd = 0, ignore_rest = 0;

    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!ignore_rest && (!strcmp(a, "-h") || !strcmp(a, "--help"))) { print_help(); return 0; }
        if (!ignore_rest && !strcmp(a, "--version")) { printf("\n./executable  version: 1.2\n\n"); return 0; }
        if (!ignore_rest && (!strcmp(a, "-r") || !strcmp(a, "--noreplay"))) { noreplay = 1; continue; }
        if (!ignore_rest && (!strcmp(a, "-t") || !strcmp(a, "--timeout"))) { timeout_inf = 1; continue; }
        if (!ignore_rest && (!strcmp(a, "-q") || !strcmp(a, "--quiet"))) { quiet = 1; continue; }
        if (!ignore_rest && (!strcmp(a, "-o") || !strcmp(a, "--override"))) { override = 1; continue; }
        if (!ignore_rest && (!strcmp(a, "--") || !strcmp(a, "--ignore_rest"))) { ignore_rest = 1; continue; }
        if (!ignore_rest && (!strcmp(a, "-i") || !strcmp(a, "--replaydirectory"))) {
            if (i + 1 < argc) replay_dir = argv[++i];
            continue;
        }
        if (!ignore_rest && (!strcmp(a, "-s") || !strcmp(a, "--seed"))) {
            if (i + 1 >= argc || !parse_pos_int(argv[++i], &seed)) { parse_error("-s", "--seed", i < argc ? argv[i] : ""); return 0; }
            continue;
        }
        if (!ignore_rest && (!strcmp(a, "-n") || !strcmp(a, "--nplayers"))) {
            if (i + 1 >= argc || !parse_pos_int(argv[++i], &nplayers_opt) || nplayers_opt < 1 || nplayers_opt > 6) {
                parse_error("-n", "--nplayers", i < argc ? argv[i] : "");
                return 0;
            }
            continue;
        }
        if (!ignore_rest && (!strcmp(a, "-d") || !strcmp(a, "--dimensions"))) {
            if (i + 1 >= argc) { parse_error("-d", "--dimensions", ""); return 0; }
            char extra[8];
            if (sscanf(argv[++i], "%d %d %7s", &w, &h, extra) < 2 || w <= 0 || h <= 0) {
                parse_error("-d", "--dimensions", argv[i]);
                return 0;
            }
            continue;
        }
        cmds[ncmd++] = a;
    }

    if (ncmd == 0) {
        puts("Please provide the launch command string for at least one bot.");
        puts("Use the --help flag for usage details.");
        free(cmds);
        return 0;
    }
    if (nplayers_opt && ncmd > 1) {
        for (int i = 0; i < ncmd; i++) printf("%s\n%s\n", cmds[i], cmds[i]);
        puts("");
        puts("Only single-player mode enables specified n-player maps.  When entering multiple bots, please do not try to specify n.");
        free(cmds);
        return 1;
    }
    int players_for_map = nplayers_opt ? nplayers_opt : ncmd;
    if (players_for_map < ncmd) players_for_map = ncmd;
    if (players_for_map > 6) players_for_map = 6;

    for (int i = 0; i < ncmd; i++) {
        printf("%s\n", cmds[i]);
        if (!quiet) printf("%s\n", cmds[i]);
    }

    Cell *map = calloc((size_t)w * h, sizeof(Cell));
    make_map(map, w, h, players_for_map, (unsigned)seed);
    char *prod = production_string(map, w, h);
    char *frame = frame_string(map, w, h);

    Player *pl = calloc((size_t)ncmd, sizeof(Player));
    for (int i = 0; i < ncmd; i++) {
        pl[i].cmd = cmds[i];
        snprintf(pl[i].name, sizeof(pl[i].name), "Player%d", i + 1);
        if (spawn_player(&pl[i]) != 0) {
            pl[i].alive = 0;
        }
    }

    printf("%d %d\n", w, h);
    for (int i = 0; i < ncmd; i++) {
        if (!pl[i].alive) continue;
        fprintf(pl[i].in, "%d\n%d %d \n%s\n%s\n", i + 1, w, h, prod, frame);
        if (!quiet) printf("Init Message sent to player %d.\n", i + 1);
    }
    for (int i = 0; i < ncmd; i++) {
        if (!pl[i].alive) continue;
        char line[256] = "";
        if (read_line_timeout(pl[i].out_fd, line, sizeof(line), 1000, timeout_inf)) {
            if (override) snprintf(pl[i].name, sizeof(pl[i].name), "%s", pl[i].cmd);
            else snprintf(pl[i].name, sizeof(pl[i].name), "%.*s", 63, line);
        } else {
            snprintf(pl[i].name, sizeof(pl[i].name), "Bot #%d", i + 1);
            pl[i].alive = 0;
        }
        if (!quiet) printf("Init Message received from player %d, %s.\n", i + 1, pl[i].name);
    }

    int maxdim = w > h ? w : h;
    int maxturns = maxdim * 10;
    if (maxturns < 50) maxturns = 50;
    if (maxturns > 1000) maxturns = 1000;

    char moves[6][2048];
    for (int turn = 1; turn <= maxturns; turn++) {
        if (!quiet) printf("Turn %d\n", turn);
        memset(moves, 0, sizeof(moves));
        free(frame);
        frame = frame_string(map, w, h);
        int live_count = 0;
        for (int i = 0; i < ncmd; i++) {
            if (pl[i].alive && is_alive_on_map(map, w * h, i + 1)) {
                pl[i].last_alive = turn;
                live_count++;
                fprintf(pl[i].in, "%s\n", frame);
            } else {
                pl[i].alive = 0;
            }
        }
        for (int i = 0; i < ncmd; i++) {
            if (!pl[i].alive) continue;
            if (!read_line_timeout(pl[i].out_fd, moves[i], sizeof(moves[i]), 1000, timeout_inf)) {
                pl[i].alive = 0;
                if (!quiet) printf("Bot #%d timeout or error (Unix) 0\n", i + 1);
            }
        }
        apply_moves(map, w, h, ncmd, moves);
        if (live_count == 0) break;
    }

    int ranks[6];
    for (int i = 0; i < ncmd; i++) ranks[i] = 1;
    for (int i = 0; i < ncmd; i++)
        for (int j = 0; j < ncmd; j++)
            if (pl[j].last_alive > pl[i].last_alive || (pl[j].last_alive == pl[i].last_alive && j > i)) ranks[i]++;

    if (quiet) {
        for (int i = 0; i < ncmd; i++) printf("%d %d %d ", i + 1, ranks[i], pl[i].last_alive);
        printf("\n \n");
    } else {
        for (int i = 0; i < ncmd; i++)
            printf("Player #%d, %s, came in rank #%d and was last alive on frame #%d!\n", i + 1, pl[i].name, ranks[i], pl[i].last_alive);
    }

    for (int i = 0; i < ncmd; i++) {
        if (pl[i].in) fclose(pl[i].in);
        if (pl[i].out_fd >= 0) close(pl[i].out_fd);
        if (pl[i].pid > 0) {
            kill(pl[i].pid, SIGTERM);
            waitpid(pl[i].pid, NULL, 0);
        }
    }
    if (!noreplay) create_replay(replay_dir, seed, ncmd, w, h);
    free(prod); free(frame); free(map); free(pl); free(cmds);
    return 0;
}
