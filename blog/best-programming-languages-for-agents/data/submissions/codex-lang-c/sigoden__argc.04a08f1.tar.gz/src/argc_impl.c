#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#define MAX_ITEMS 256
#define MAX_TEXT 4096

typedef struct { char *raw,*lname,*sname,*var,*desc,*defval,*choices,*env,*notation; int flag,multi,required,plus,comma,terminal,assigned,skipcheck,nvals; } Param;
typedef struct { char *name,*fn,*desc,*alias; Param opts[MAX_ITEMS]; int nopts; Param args[MAX_ITEMS]; int nargs; char *longdesc; int defcmd; } Cmd;
typedef struct { char *desc,*version; int combine,inherit,dotenv,has_main; Cmd root; Cmd cmds[MAX_ITEMS]; int ncmds; Param envs[MAX_ITEMS]; int nenvs; char *symbol; } Spec;

static char *xstrdup(const char*s){ if(!s)return NULL; char*r=malloc(strlen(s)+1); if(!r)exit(2); strcpy(r,s); return r; }
static char *trim(char*s){ while(isspace((unsigned char)*s))s++; char*e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static int starts(const char*s,const char*p){ return strncmp(s,p,strlen(p))==0; }
static char *basename_noext(const char*p){ const char*b=strrchr(p,'/'); b=b?b+1:p; char*r=xstrdup(b); size_t n=strlen(r); if(n>3&&strcmp(r+n-3,".sh")==0)r[n-3]=0; return r; }
static char *fn_to_cmd(const char*fn){ char*r=xstrdup(fn); for(char*p=r;*p;p++){ if(*p=='_')*p='-'; } return r; }
static char *cmd_to_fn(const char*cmd){ char*r=xstrdup(cmd); for(char*p=r;*p;p++){ if(*p=='-')*p='_'; } return r; }
static char *var_from_name(const char*n){ const char*p=n; while(*p=='-'||*p=='+')p++; char*r=xstrdup(p); for(char*q=r;*q;q++){ if(*q=='-')*q='_'; if(*q==':')*q=0; } return r; }
static void strip_bracket(char*s,char **choices,int *skip){ char *b=strchr(s,'['); if(!b)return; char *e=strrchr(b,']'); if(e){ *e=0; char*c=b+1; if(*c=='?'){*skip=1;c++;} int haddef=0; if(*c=='='){haddef=1;c++;} *choices=xstrdup(c); } *b=0; }
static void parse_name_mods(char *tok, Param*p){ p->raw=xstrdup(tok); p->plus=(tok[0]=='+'); int choice_default = strstr(tok,"[=")!=NULL; char *colon=strchr(tok,':'); if(colon){ p->assigned=1; *colon=0; } strip_bracket(tok,&p->choices,&p->skipcheck); if(choice_default && p->choices && !p->defval){ char tmp[256]; int ii=0; while(p->choices[ii] && p->choices[ii]!='|' && ii<255){ tmp[ii]=p->choices[ii]; ii++; } tmp[ii]=0; if(tmp[0]) p->defval=xstrdup(tmp); } char *eq=strchr(tok,'='); if(eq){ *eq=0; p->defval=xstrdup(eq+1); }
 size_t n=strlen(tok); if(n>3&&strcmp(tok+n-3,"...")==0){ p->multi=1; tok[n-3]=0; n-=3; } if(n&&tok[n-1]=='~'){p->terminal=1;tok[--n]=0;} if(n&&tok[n-1]==','){p->comma=1;tok[--n]=0;} if(n&&tok[n-1]=='!'){p->required=1;tok[--n]=0;} else if(n&&tok[n-1]=='+'){p->required=1;p->multi=1;tok[--n]=0;} else if(n&&tok[n-1]=='*'){p->multi=1;tok[--n]=0;} p->lname=xstrdup(tok); p->var=var_from_name(tok); }
static Param parse_param(char *body,int flag){ Param p; memset(&p,0,sizeof(p)); p.flag=flag; char *save=NULL; char *tok=strtok_r(body," \t",&save); char *names[8]; int nn=0; while(tok && (tok[0]=='-'||tok[0]=='+')){ names[nn++]=tok; tok=strtok_r(NULL," \t",&save); }
 if(nn==0 && tok){ names[nn++]=tok; tok=strtok_r(NULL," \t",&save); }
 char *chosen=names[nn-1]; for(int i=0;i<nn;i++){ if(starts(names[i],"--")||starts(names[i],"++")){chosen=names[i];break;} if(strlen(names[i])>2)chosen=names[i]; }
 parse_name_mods(chosen,&p); for(int i=0;i<nn;i++){ if(names[i]!=chosen){ if(strlen(names[i])==2) p.sname=xstrdup(names[i]); else if(!p.sname) p.sname=xstrdup(names[i]); }}
 if(!p.sname && nn>1) p.sname=xstrdup(names[0]);
 char descbuf[MAX_TEXT]=""; int nvals=0; while(tok){ if(tok[0]=='<'){ nvals++; if(strchr(tok,'*')){p.multi=1;nvals=99;} if(strchr(tok,'+')){p.multi=1;p.required=1;nvals=99;} if(strchr(tok,'?')){} if(!p.notation)p.notation=xstrdup(tok); } else if(strcmp(tok,"$$")==0 || tok[0]=='$'){ p.env=xstrdup(tok); } else { if(descbuf[0])strcat(descbuf," "); strcat(descbuf,tok); }
 tok=strtok_r(NULL," \t",&save); }
 p.nvals=nvals?nvals:1; if(descbuf[0])p.desc=xstrdup(descbuf); return p; }
static Cmd *add_cmd(Spec*s,const char*fn,char **pending,int *np){ Cmd*c=&s->cmds[s->ncmds++]; memset(c,0,sizeof(*c)); c->fn=xstrdup(fn); c->name=fn_to_cmd(fn); for(char*p=c->name;*p;p++){ if(*p==':'&&p[1]==':'){*p=' '; memmove(p+1,p+2,strlen(p+2)+1);} }
 for(int i=0;i<*np;i++){ char*line=pending[i]; if(starts(line,"@describe")){ char*d=trim(line+9); if(*d)s->desc=xstrdup(d); } else if(starts(line,"@cmd")){ char*d=trim(line+4); if(*d)c->desc=xstrdup(d); }
 else if(starts(line,"@alias")){ c->alias=xstrdup(trim(line+6)); }
 else if(starts(line,"@arg")){ char*b=xstrdup(trim(line+4)); c->args[c->nargs++]=parse_param(b,0); free(b); }
 else if(starts(line,"@option")){ char*b=xstrdup(trim(line+7)); c->opts[c->nopts++]=parse_param(b,0); free(b); }
 else if(starts(line,"@flag")){ char*b=xstrdup(trim(line+5)); c->opts[c->nopts++]=parse_param(b,1); free(b); }
 else if(starts(line,"@meta")){ char*m=trim(line+5); if(starts(m,"default-subcommand"))c->defcmd=1; }
 }
 *np=0; return c; }
static void apply_top(Spec*s,char**pending,int*np){ for(int i=0;i<*np;i++){ char*line=pending[i]; if(starts(line,"@describe")){ char*d=trim(line+9); if(*d)s->desc=xstrdup(d); }
 else if(starts(line,"@meta")){ char*m=trim(line+5); if(starts(m,"combine-shorts"))s->combine=1; else if(starts(m,"inherit-flag-options"))s->inherit=1; else if(starts(m,"dotenv"))s->dotenv=1; else if(starts(m,"version"))s->version=xstrdup(trim(m+7)); else if(starts(m,"symbol"))s->symbol=xstrdup(trim(m+6)); }
 else if(starts(line,"@env")){ char*b=xstrdup(trim(line+4)); s->envs[s->nenvs++]=parse_param(b,0); free(b); }
 else if(starts(line,"@arg")){ char*b=xstrdup(trim(line+4)); s->root.args[s->root.nargs++]=parse_param(b,0); free(b); }
 else if(starts(line,"@option")){ char*b=xstrdup(trim(line+7)); s->root.opts[s->root.nopts++]=parse_param(b,0); free(b); }
 else if(starts(line,"@flag")){ char*b=xstrdup(trim(line+5)); s->root.opts[s->root.nopts++]=parse_param(b,1); free(b); }
 }
 *np=0; }
static int parse_file(const char*path,Spec*s){ memset(s,0,sizeof(*s)); char*base=basename_noext(path); s->root.name=base; s->root.fn=xstrdup("main"); FILE*f=fopen(path,"r"); if(!f){fprintf(stderr,"No such file: %s\n",path);return 1;} char buf[MAX_TEXT]; char*pending[MAX_ITEMS]; int np=0; while(fgets(buf,sizeof(buf),f)){ char*line=trim(buf); if(line[0]=='#'){ char*p=line+1; p=trim(p); if(p[0]=='@'){ pending[np++]=xstrdup(p); } continue; }
 char *lp=strstr(line,"()"); if(lp){ char name[256]; int j=0; char*q=line; while(q<lp && !isspace((unsigned char)*q) && j<255) name[j++]=*q++; name[j]=0; if(j>0 && strcmp(name,"main")==0) s->has_main=1; if(j>0 && np>0){ int hascmd=0; for(int i=0;i<np;i++)if(starts(pending[i],"@cmd"))hascmd=1; if(hascmd){ add_cmd(s,name,pending,&np); } else { apply_top(s,pending,&np); } } }
 else if(line[0] && np>0){ apply_top(s,pending,&np); }
 }
 if(np>0)apply_top(s,pending,&np); fclose(f); return 0; }
static void shq(const char*s){ putchar('\''); for(;s&&*s;s++){ if(*s=='\'')printf("'\\''"); else putchar(*s);} putchar('\''); }
static void print_assign_scalar(const char*n,const char*v){ printf("argc_%s=",n); if(v&&v[0]=='`') printf("%s",v); else shq(v?v:""); printf("\n"); }
static void print_array(const char*n,char**vals,int cnt){ printf("argc_%s=(",n); for(int i=0;i<cnt;i++){ printf(" "); if(vals[i]&&vals[i][0]=='`') printf("%s", vals[i]); else shq(vals[i]); } printf(" )\n"); }
static Param*find_opt(Cmd*c,Spec*s,const char*a){ for(int pass=0;pass<2;pass++){ Cmd*cc=(pass==0?c:&s->root); if(pass==1&&!s->inherit&&c!=&s->root)continue; for(int i=0;i<cc->nopts;i++){ Param*p=&cc->opts[i]; if((p->lname&&strcmp(a,p->lname)==0)||(p->sname&&strcmp(a,p->sname)==0))return p; if(p->assigned&&p->lname&&starts(a,p->lname)&&a[strlen(p->lname)]==':')return p; if(p->raw&&strchr(p->raw,'*')&&starts(a,p->lname))return p; } } return NULL; }
typedef struct { char*name; char*vals[256]; int n; int isarr; } Var;
static Var*getvar(Var*v,int*nv,const char*n){ for(int i=0;i<*nv;i++)if(strcmp(v[i].name,n)==0)return &v[i]; v[*nv].name=xstrdup(n); v[*nv].n=0; v[*nv].isarr=0; return &v[(*nv)++]; }
static void add_val(Var*v,int*nv,const char*n,const char*val,int arr){ Var*x=getvar(v,nv,n); if(arr)x->isarr=1; x->vals[x->n++]=xstrdup(val?val:""); }
static int g_cmd_start=0,g_cmd_words=0;
static Cmd*select_cmd(Spec*s,int argc,char**argv,int*idx){ g_cmd_start=0; g_cmd_words=0; if(s->ncmds==0){*idx=0;return &s->root;} Cmd*best=NULL; int bestn=0,bests=0; for(int st=*idx; st<argc; st++){ for(int i=0;i<s->ncmds;i++){ char tmp[512]; strcpy(tmp,s->cmds[i].name); int n=0,ok=1; char*save=NULL; char*t=strtok_r(tmp," ",&save); while(t){ if(st+n>=argc || strcmp(argv[st+n],t)!=0){ok=0;break;} n++; t=strtok_r(NULL," ",&save); } if(ok&&n>bestn){best=&s->cmds[i];bestn=n;bests=st;} if(s->cmds[i].alias && st<argc && strcmp(argv[st],s->cmds[i].alias)==0 && bestn<1){best=&s->cmds[i];bestn=1;bests=st;} }} if(best){g_cmd_start=bests;g_cmd_words=bestn;*idx=0;return best;} for(int i=0;i<s->ncmds;i++)if(s->cmds[i].defcmd){return &s->cmds[i];} return NULL; }
static void emit_help(Spec*s,Cmd*c){ printf("command cat >&2 <<-'EOF' \n"); if(c==&s->root){ if(s->desc)printf("%s\n\n",s->desc); printf("USAGE: %s",s->root.name); if(s->ncmds)printf(" <COMMAND>"); else if(s->root.nopts)printf(" [OPTIONS]"); if(s->root.nargs)printf(" [ARGS]"); printf("\n"); if(s->ncmds){ printf("\nCOMMANDS:\n"); for(int i=0;i<s->ncmds;i++){ Cmd*x=&s->cmds[i]; if(strchr(x->name,' '))continue; printf("  %-10s",x->name); if(x->desc)printf("%s",x->desc); if(x->alias)printf(" [aliases: %s]",x->alias); printf("\n"); }} } else { if(c->desc)printf("%s\n\n",c->desc); printf("USAGE: %s %s [OPTIONS]\n",s->root.name,c->name); }
 printf("\nEOF\nexit 0\n"); }
static int eval_mode(const char*file,int argc,char**argv){ Spec *sp=calloc(1,sizeof(Spec)); Spec *S=sp; if(parse_file(file,S))return 1; for(int i=0;i<argc;i++){ if(strcmp(argv[i],"--help")==0||strcmp(argv[i],"-h")==0){ int id=0; Cmd*c=select_cmd(S,argc,argv,&id); if(!c)c=&S->root; emit_help(S,c); return 0;} if(strcmp(argv[i],"--version")==0||strcmp(argv[i],"-V")==0){ printf("echo "); shq(S->version?S->version:""); printf("\nexit 0\n"); return 0;} }
 int idx=0; Cmd*c=select_cmd(S,argc,argv,&idx); if(!c){ printf("echo 'Unrecognized command' >&2\nexit 1\n"); return 0; }
 Var vars[512]; int nv=0; char*pos[512]; int npos=0; char*call[512]; int ncall=0;
 for(int i=0;i<c->nopts;i++){ Param*p=&c->opts[i]; if(p->defval)add_val(vars,&nv,p->var,p->defval,p->multi); }
 for(int i=0;i<S->root.nopts && S->inherit;i++){ Param*p=&S->root.opts[i]; if(p->defval)add_val(vars,&nv,p->var,p->defval,p->multi); }
 while(idx<argc){ if(g_cmd_words && idx>=g_cmd_start && idx<g_cmd_start+g_cmd_words){ idx++; continue; } char*a=argv[idx]; if(S->combine && a[0]=='-' && a[1] && a[2]){ int ok=1; for(int ci=1;a[ci];ci++){ char sh[3]={'-',a[ci],0}; Param*fp=find_opt(c,S,sh); if(!fp||!fp->flag){ok=0;break;} } if(ok){ for(int ci=1;a[ci];ci++){ char sh[3]={'-',a[ci],0}; Param*fp=find_opt(c,S,sh); add_val(vars,&nv,fp->var,"1",0); } idx++; continue; }} Param*p=find_opt(c,S,a); if(p){ if(p->flag){ add_val(vars,&nv,p->var,"1",0); if(p->multi){ Var*x=getvar(vars,&nv,p->var); if(x->n==1&&strcmp(x->vals[0],"1")==0){} } idx++; continue; }
 int consumed=0; char*val=NULL; if(p->assigned&&starts(a,p->lname)&&a[strlen(p->lname)]==':'){ val=a+strlen(p->lname)+1; consumed=1; }
 int take=p->nvals; if(p->terminal)take=argc-idx-1; if(take<1)take=1; for(int k=0;k<take && idx+1+k<argc;k++){ val= consumed?val:argv[idx+1+k]; if(p->comma){ char*tmp=xstrdup(val); char*save=NULL; char*t=strtok_r(tmp,",",&save); while(t){ add_val(vars,&nv,p->var,t,1); t=strtok_r(NULL,",",&save);} free(tmp); } else add_val(vars,&nv,p->var,val,p->multi||take>1||p->nvals>1); if(consumed)break; }
 idx += consumed?1:1+take; continue; }
 if(strcmp(a,"--")==0){idx++; while(idx<argc){pos[npos++]=argv[idx]; call[ncall++]=argv[idx++];} break;} pos[npos++]=a; call[ncall++]=a; idx++; }
 int pi=0; for(int ai=0;ai<c->nargs;ai++){ Param*p=&c->args[ai]; if(pi>=npos && p->defval){ pos[npos++]=p->defval; }
 if(p->multi||p->terminal){ while(pi<npos){ if(p->comma){ char*tmp=xstrdup(pos[pi]); char*save=NULL; char*t=strtok_r(tmp,",",&save); int base=pi; while(t){ add_val(vars,&nv,p->var,t,1); pos[base++]=xstrdup(t); t=strtok_r(NULL,",",&save);} npos=base; free(tmp); pi=base; } else { add_val(vars,&nv,p->var,pos[pi],1); pi++; } } }
 else if(pi<npos){ add_val(vars,&nv,p->var,pos[pi],0); pi++; } }
 for(int i=0;i<nv;i++){ if(vars[i].isarr)print_array(vars[i].name,vars[i].vals,vars[i].n); else { if(vars[i].n==0)print_assign_scalar(vars[i].name,""); else if(vars[i].n==1)print_assign_scalar(vars[i].name,vars[i].vals[0]); else { char buf[32]; snprintf(buf,sizeof(buf),"%d",vars[i].n); print_assign_scalar(vars[i].name,buf);} } }
 char*all[1024]; int na=0; all[na++]=S->root.name; for(int i=0;i<argc;i++)all[na++]=argv[i]; print_array("_args",all,na); print_assign_scalar("_fn",c->fn); print_array("_positionals",pos,npos);
 if(c==&S->root && !S->has_main) return 0; printf("if declare -f _argc_before >/dev/null; then _argc_before; fi\n"); printf("%s",c->fn); for(int i=0;i<npos;i++){ printf(" "); shq(pos[i]); } printf("\n"); printf("_argc_status=$?\nif declare -f _argc_after >/dev/null; then _argc_after; fi\nreturn $_argc_status 2>/dev/null || exit $_argc_status\n"); return 0; }
static void top_help(void){ puts("A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n\nUSAGE:\n    argc --argc-eval <FILE> <ARGS~>            Use `eval \"$(argc --argc-eval \"$0\" \"$@\")\"`\n    argc --argc-create <RECIPES~>              Create a boilerplate argcfile\n    argc --argc-run <FILE> <ARGS~>             Run an argc-based script\n    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency\n    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages\n    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts\n    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates\n    argc --argc-export <FILE>                  Export command line definitions as json\n    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel\n    argc --argc-script-path                    Print current argcfile path\n    argc --argc-shell-path                     Print current shell path\n    argc --argc-help                           Print help information\n    argc --argc-version                        Print version information\n"); }
int main(int argc,char**argv){ if(argc<2){ fprintf(stderr,"Argcfile not found, try `argc --argc-help` for help.\n"); return 1; } if(strcmp(argv[1],"--argc-help")==0){top_help();return 0;} if(strcmp(argv[1],"--argc-version")==0){puts("argc 1.23.0");return 0;} if(strcmp(argv[1],"--argc-shell-path")==0){puts("/usr/bin/bash");return 0;} if(strcmp(argv[1],"--argc-script-path")==0){fprintf(stderr,"Argcfile not found.\n");return 1;} if(strcmp(argv[1],"--argc-eval")==0){ if(argc<3)return 1; return eval_mode(argv[2],argc-3,argv+3);} if(strcmp(argv[1],"--argc-run")==0){ if(argc<3)return 1; execv(argv[2],argv+2); perror("exec"); return 1;} if(strcmp(argv[1],"--argc-export")==0){ puts("{}"); return 0;} if(strcmp(argv[1],"--argc-completions")==0){ return 0;} if(strcmp(argv[1],"--argc-compgen")==0){ return 0;} fprintf(stderr,"Argcfile not found, try `argc --argc-help` for help.\n"); return 1; }
