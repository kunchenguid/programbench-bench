#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    bool color_only;
    bool raw;
    bool line_numbers;
    bool side_by_side;
    bool keep_markers;
    bool inspect_raw;
    bool show_config;
    bool show_colors;
    bool show_themes;
    bool show_syntax_themes;
    bool list_syntax_themes;
    bool list_languages;
    const char *completion;
    const char *files[2];
    int file_count;
} Options;

static const char *HELP_TEXT =
#include "help.inc"
;

static const char *BASH_COMPLETION =
#include "completion_bash.inc"
;

static const char *FISH_COMPLETION =
#include "completion_fish.inc"
;

static const char *ZSH_COMPLETION =
#include "completion_zsh.inc"
;

static bool starts_with(const char *s, const char *prefix) {
    return strncmp(s, prefix, strlen(prefix)) == 0;
}

static void print_short_help(void) {
    puts("A viewer for git and diff output\n");
    puts("Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n");
    puts("Arguments:");
    puts("  [MINUS_FILE]  First file to be compared when delta is being used to diff two files");
    puts("  [PLUS_FILE]   Second file to be compared when delta is being used to diff two files\n");
    puts("Options:");
    puts("      --color-only              Do not alter the input structurally in any way");
    puts("      --line-numbers            Show line numbers");
    puts("  -s, --side-by-side            Display paired minus/plus diff lines side by side");
    puts("      --list-languages          List supported languages");
    puts("      --list-syntax-themes      List supported syntax-highlighting themes");
    puts("      --generate-completion <SHELL>");
    puts("  -h, --help                    Print help");
    puts("  -V, --version                 Print version");
}

static void list_languages(void) {
    const char *langs[] = {
        "Plain Text", "C", "C++", "C#", "CSS", "Diff", "Go", "HTML",
        "Java", "JavaScript", "JSON", "Markdown", "Python", "Ruby",
        "Rust", "Shell Script (Bash)", "TOML", "TypeScript", "XML", "YAML"
    };
    for (size_t i = 0; i < sizeof(langs) / sizeof(langs[0]); i++) puts(langs[i]);
}

static void list_themes(void) {
    const char *themes[] = {
        "1337", "Coldark-Cold", "Coldark-Dark", "DarkNeon", "Dracula",
        "GitHub", "Monokai Extended", "Monokai Extended Bright",
        "Monokai Extended Light", "Monokai Extended Origin", "Nord",
        "OneHalfDark", "OneHalfLight", "Solarized (dark)",
        "Solarized (light)", "TwoDark", "Visual Studio Dark+"
    };
    for (size_t i = 0; i < sizeof(themes) / sizeof(themes[0]); i++) puts(themes[i]);
}

static void show_config(void) {
    puts("delta.minus-style = normal auto");
    puts("delta.plus-style = syntax auto");
    puts("delta.file-style = blue");
    puts("delta.hunk-header-style = line-number syntax");
    puts("delta.syntax-theme = Monokai Extended");
    puts("delta.navigate = false");
    puts("delta.side-by-side = false");
    puts("delta.line-numbers = false");
}

static void show_colors(void) {
    const char *colors[] = {
        "black", "red", "green", "yellow", "blue", "magenta", "cyan", "white",
        "brightblack", "brightred", "brightgreen", "brightyellow",
        "brightblue", "brightmagenta", "brightcyan", "brightwhite"
    };
    for (size_t i = 0; i < sizeof(colors) / sizeof(colors[0]); i++) {
        printf("%3zu  %s\n", i, colors[i]);
    }
}

static bool option_takes_value(const char *arg) {
    static const char *names[] = {
        "--blame-code-style", "--blame-format", "--blame-palette",
        "--blame-separator-format", "--blame-separator-style",
        "--blame-timestamp-format", "--blame-timestamp-output-format",
        "--config", "--commit-decoration-style", "--commit-regex",
        "--commit-style", "--default-language", "--detect-dark-light",
        "--diff-args", "-@", "--diff-stat-align-width", "--features",
        "--file-added-label", "--file-copied-label", "--file-decoration-style",
        "--file-modified-label", "--file-removed-label", "--file-renamed-label",
        "--file-style", "--file-transformation", "--generate-completion",
        "--grep-context-line-style", "--grep-file-style",
        "--grep-header-decoration-style", "--grep-header-file-style",
        "--grep-line-number-style", "--grep-output-type",
        "--grep-match-line-style", "--grep-match-word-style",
        "--grep-separator-symbol", "--hunk-header-decoration-style",
        "--hunk-header-file-style", "--hunk-header-line-number-style",
        "--hunk-header-style", "--hunk-label",
        "--hyperlinks-commit-link-format", "--hyperlinks-file-link-format",
        "--inline-hint-style", "--inspect-raw-lines", "--line-buffer-size",
        "--line-fill-method", "--line-numbers-left-format",
        "--line-numbers-left-style", "--line-numbers-minus-style",
        "--line-numbers-plus-style", "--line-numbers-right-format",
        "--line-numbers-right-style", "--line-numbers-zero-style",
        "--map-styles", "--max-line-distance", "--max-line-length",
        "--merge-conflict-begin-symbol", "--merge-conflict-end-symbol",
        "--merge-conflict-ours-diff-header-decoration-style",
        "--merge-conflict-ours-diff-header-style",
        "--merge-conflict-theirs-diff-header-decoration-style",
        "--merge-conflict-theirs-diff-header-style",
        "--minus-empty-line-marker-style", "--minus-emph-style",
        "--minus-non-emph-style", "--minus-style", "--navigate-regex",
        "--pager", "--paging", "--plus-emph-style",
        "--plus-empty-line-marker-style", "--plus-non-emph-style",
        "--plus-style", "--right-arrow", "--syntax-theme", "--tabs",
        "--true-color", "--whitespace-error-style", "--width",
        "--word-diff-regex", "--wrap-left-symbol", "--wrap-max-lines",
        "--wrap-right-percent", "--wrap-right-prefix-symbol",
        "--wrap-right-symbol", "--zero-style", "--24-bit-color"
    };
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); i++) {
        if (strcmp(arg, names[i]) == 0) return true;
    }
    return false;
}

static bool is_known_flag(const char *arg) {
    static const char *flags[] = {
        "--color-only", "--dark", "--diff-highlight", "--diff-so-fancy",
        "--hyperlinks", "--keep-plus-minus-markers", "--light",
        "--line-numbers", "-n", "--list-languages", "--list-syntax-themes",
        "--navigate", "--no-gitconfig", "--parse-ansi", "--raw",
        "--relative-paths", "--show-colors", "--show-config",
        "--show-syntax-themes", "--show-themes", "--side-by-side", "-s",
        "--help", "-h", "--version", "-V"
    };
    for (size_t i = 0; i < sizeof(flags) / sizeof(flags[0]); i++) {
        if (strcmp(arg, flags[i]) == 0) return true;
    }
    return false;
}

static void strip_ansi(const char *in, FILE *out) {
    for (const unsigned char *p = (const unsigned char *)in; *p; p++) {
        if (*p == 0x1b && p[1] == '[') {
            p += 2;
            while (*p && !((*p >= '@' && *p <= '~'))) p++;
            if (!*p) break;
        } else {
            fputc(*p, out);
        }
    }
}

static void print_line_numbered(const char *line, long *oldn, long *newn) {
    bool minus = line[0] == '-' && !starts_with(line, "---");
    bool plus = line[0] == '+' && !starts_with(line, "+++");
    bool context = line[0] == ' ';
    if (minus) {
        printf("%4ld \342\213\256     \342\224\202 %s", (*oldn)++, line + 1);
    } else if (plus) {
        printf("     \342\213\256 %4ld \342\224\202 %s", (*newn)++, line + 1);
    } else if (context) {
        printf("%4ld \342\213\256 %4ld \342\224\202 %s", (*oldn)++, (*newn)++, line + 1);
    } else {
        fputs(line, stdout);
    }
}

static void parse_hunk(const char *line, long *oldn, long *newn) {
    long a = 0, b = 0;
    if (sscanf(line, "@@ -%ld%*[,0-9] +%ld", &a, &b) == 2) {
        *oldn = a;
        *newn = b;
    }
}

static void process_stream(const Options *opt, FILE *in) {
    char *line = NULL;
    size_t cap = 0;
    long oldn = 1, newn = 1;
    char *pending_minus = NULL;
    while (getline(&line, &cap, in) != -1) {
        if (opt->inspect_raw) {
            fputs("raw: ", stdout);
            strip_ansi(line, stdout);
            continue;
        }
        if (opt->side_by_side && line[0] == '-' && !starts_with(line, "---")) {
            free(pending_minus);
            pending_minus = strdup(line + 1);
            continue;
        }
        if (opt->side_by_side && line[0] == '+' && !starts_with(line, "+++")) {
            if (pending_minus) {
                pending_minus[strcspn(pending_minus, "\n")] = 0;
                line[strcspn(line, "\n")] = 0;
                printf("%-40s \342\224\202 %s\n", pending_minus, line + 1);
                free(pending_minus);
                pending_minus = NULL;
                continue;
            }
        }
        if (pending_minus) {
            fputs(pending_minus, stdout);
            free(pending_minus);
            pending_minus = NULL;
        }
        if (starts_with(line, "@@ ")) parse_hunk(line, &oldn, &newn);
        if (opt->line_numbers) {
            print_line_numbered(line, &oldn, &newn);
        } else if (!opt->keep_markers && !opt->color_only && !opt->raw &&
                   ((line[0] == '-' && !starts_with(line, "---")) ||
                    (line[0] == '+' && !starts_with(line, "+++")) ||
                    line[0] == ' ')) {
            fputs(line + 1, stdout);
        } else {
            fputs(line, stdout);
        }
    }
    if (pending_minus) {
        fputs(pending_minus, stdout);
        free(pending_minus);
    }
    free(line);
}

static int diff_two_files(const Options *opt) {
    const char *a = opt->files[0], *b = opt->files[1];
    char quoted[8192];
    const char *argv[2] = {a, b};
    strcpy(quoted, "diff -u -- ");
    for (int i = 0; i < 2; i++) {
        strcat(quoted, "'");
        for (const char *p = argv[i]; *p && strlen(quoted) + 5 < sizeof(quoted); p++) {
            if (*p == '\'') strcat(quoted, "'\\''");
            else {
                size_t n = strlen(quoted);
                quoted[n] = *p;
                quoted[n + 1] = 0;
            }
        }
        strcat(quoted, "' ");
    }
    FILE *fp = popen(quoted, "r");
    if (!fp) {
        fprintf(stderr, "delta: failed to run diff: %s\n", strerror(errno));
        return 2;
    }
    process_stream(opt, fp);
    int st = pclose(fp);
    if (WIFEXITED(st)) {
        int code = WEXITSTATUS(st);
        return code == 1 ? 0 : code;
    }
    return 2;
}

static int parse_args(int argc, char **argv, Options *opt) {
    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "--") == 0) {
            while (++i < argc && opt->file_count < 2) opt->files[opt->file_count++] = argv[i];
            break;
        }
        if (strcmp(arg, "--help") == 0) { fputs(HELP_TEXT, stdout); return 1; }
        if (strcmp(arg, "-h") == 0) { print_short_help(); return 1; }
        if (strcmp(arg, "--version") == 0 || strcmp(arg, "-V") == 0) {
            puts("delta 0.18.2");
            return 1;
        }
        if (starts_with(arg, "--generate-completion=")) {
            opt->completion = strchr(arg, '=') + 1;
            continue;
        }
        if (starts_with(arg, "--") && strchr(arg, '=')) {
            char name[256];
            size_t n = (size_t)(strchr(arg, '=') - arg);
            if (n >= sizeof(name)) n = sizeof(name) - 1;
            memcpy(name, arg, n); name[n] = 0;
            if (strcmp(name, "--generate-completion") == 0) opt->completion = strchr(arg, '=') + 1;
            else if (strcmp(name, "--inspect-raw-lines") == 0) opt->inspect_raw = true;
            else if (!option_takes_value(name) && !is_known_flag(name)) {
                fprintf(stderr, "error: unexpected argument '%s' found\n", arg);
                return -1;
            }
            continue;
        }
        if (strcmp(arg, "--color-only") == 0) opt->color_only = true;
        else if (strcmp(arg, "--raw") == 0) opt->raw = true;
        else if (strcmp(arg, "--line-numbers") == 0 || strcmp(arg, "-n") == 0) opt->line_numbers = true;
        else if (strcmp(arg, "--side-by-side") == 0 || strcmp(arg, "-s") == 0) opt->side_by_side = true;
        else if (strcmp(arg, "--keep-plus-minus-markers") == 0) opt->keep_markers = true;
        else if (strcmp(arg, "--list-languages") == 0) opt->list_languages = true;
        else if (strcmp(arg, "--list-syntax-themes") == 0) opt->list_syntax_themes = true;
        else if (strcmp(arg, "--show-syntax-themes") == 0) opt->show_syntax_themes = true;
        else if (strcmp(arg, "--show-themes") == 0) opt->show_themes = true;
        else if (strcmp(arg, "--show-config") == 0) opt->show_config = true;
        else if (strcmp(arg, "--show-colors") == 0) opt->show_colors = true;
        else if (strcmp(arg, "--inspect-raw-lines") == 0) opt->inspect_raw = true;
        else if (strcmp(arg, "--generate-completion") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '--generate-completion <GENERATE_COMPLETION>'\n");
                return -1;
            }
            opt->completion = argv[i];
        } else if (option_takes_value(arg)) {
            if (++i >= argc) {
                fprintf(stderr, "error: a value is required for '%s'\n", arg);
                return -1;
            }
        } else if (is_known_flag(arg)) {
            /* Accepted no-op flag. */
        } else if (arg[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n", arg);
            return -1;
        } else {
            if (opt->file_count >= 2) {
                fprintf(stderr, "error: unexpected argument '%s' found\n", arg);
                return -1;
            }
            opt->files[opt->file_count++] = arg;
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    Options opt;
    memset(&opt, 0, sizeof(opt));
    int parsed = parse_args(argc, argv, &opt);
    if (parsed > 0) return 0;
    if (parsed < 0) return 2;

    if (opt.completion) {
        if (strcmp(opt.completion, "bash") == 0) fputs(BASH_COMPLETION, stdout);
        else if (strcmp(opt.completion, "fish") == 0) fputs(FISH_COMPLETION, stdout);
        else if (strcmp(opt.completion, "zsh") == 0) fputs(ZSH_COMPLETION, stdout);
        else if (strcmp(opt.completion, "elvish") == 0 || strcmp(opt.completion, "powershell") == 0)
            printf("# completion for %s is not available in this build\n", opt.completion);
        else {
            fprintf(stderr, "error: invalid value '%s' for '--generate-completion <GENERATE_COMPLETION>'\n", opt.completion);
            return 2;
        }
        return 0;
    }
    if (opt.list_languages) { list_languages(); return 0; }
    if (opt.list_syntax_themes || opt.show_syntax_themes || opt.show_themes) { list_themes(); return 0; }
    if (opt.show_config) { show_config(); return 0; }
    if (opt.show_colors) { show_colors(); return 0; }

    if (opt.file_count == 1) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <PLUS_FILE>\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n");
        return 2;
    }
    if (opt.file_count == 2) return diff_two_files(&opt);
    process_stream(&opt, stdin);
    return ferror(stdout) ? 1 : 0;
}
