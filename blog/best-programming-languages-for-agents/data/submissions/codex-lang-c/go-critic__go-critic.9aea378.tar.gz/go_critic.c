#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    char **items;
    int len;
    int cap;
} StrList;

typedef struct {
    char *path;
    char **lines;
    int nlines;
} SourceFile;

typedef struct {
    bool enable_all;
    int exit_code;
    bool check_tests;
    bool check_generated;
    StrList enabled;
    StrList disabled;
    StrList targets;
} Config;

static const char *version = "v0.0.0-SNAPSHOT";

static const char *all_docs[] = {
    "appendAssign [diagnostic]",
    "appendCombine [performance]",
    "argOrder [diagnostic]",
    "assignOp [style]",
    "badCall [diagnostic]",
    "badCond [diagnostic]",
    "badLock [diagnostic experimental]",
    "badRegexp [diagnostic experimental]",
    "badSorting [diagnostic experimental]",
    "badSyncOnceFunc [diagnostic experimental]",
    "boolExprSimplify [style experimental]",
    "builtinShadow [style opinionated]",
    "builtinShadowDecl [diagnostic experimental]",
    "captLocal [style]",
    "caseOrder [diagnostic]",
    "codegenComment [diagnostic]",
    "commentFormatting [style]",
    "commentedOutCode [diagnostic experimental]",
    "commentedOutImport [style experimental]",
    "defaultCaseOrder [style]",
    "deferInLoop [diagnostic experimental]",
    "deferUnlambda [style experimental]",
    "deprecatedComment [diagnostic]",
    "docStub [style experimental]",
    "dupArg [diagnostic]",
    "dupBranchBody [diagnostic]",
    "dupCase [diagnostic]",
    "dupImport [style experimental]",
    "dupOption [diagnostic experimental]",
    "dupSubExpr [diagnostic]",
    "dynamicFmtString [diagnostic experimental]",
    "elseif [style]",
    "emptyDecl [diagnostic experimental]",
    "emptyFallthrough [style experimental]",
    "emptyStringTest [style experimental]",
    "equalFold [performance experimental]",
    "evalOrder [diagnostic experimental]",
    "exitAfterDefer [diagnostic]",
    "exposedSyncMutex [style experimental]",
    "externalErrorReassign [diagnostic experimental]",
    "filepathJoin [diagnostic experimental]",
    "flagDeref [diagnostic]",
    "flagName [diagnostic]",
    "hexLiteral [style experimental]",
    "httpNoBody [style experimental]",
    "hugeParam [performance]",
    "ifElseChain [style]",
    "importShadow [style opinionated]",
    "indexAlloc [performance]",
    "initClause [style opinionated experimental]",
    "mapKey [diagnostic]",
    "methodExprCall [style experimental]",
    "nestingReduce [style opinionated experimental]",
    "newDeref [style]",
    "nilValReturn [diagnostic experimental]",
    "octalLiteral [style experimental opinionated]",
    "offBy1 [diagnostic]",
    "paramTypeCombine [style opinionated]",
    "preferDecodeRune [performance experimental]",
    "preferFilepathJoin [style experimental]",
    "preferFprint [performance experimental]",
    "preferStringWriter [performance experimental]",
    "preferWriteByte [performance experimental opinionated]",
    "ptrToRefParam [style opinionated experimental]",
    "rangeAppendAll [diagnostic experimental]",
    "rangeExprCopy [performance]",
    "rangeValCopy [performance]",
    "redundantSprint [style experimental]",
    "regexpMust [style]",
    "regexpPattern [diagnostic experimental]",
    "regexpSimplify [style experimental opinionated]",
    "returnAfterHttpError [diagnostic experimental]",
    "ruleguard [style experimental]",
    "singleCaseSwitch [style]",
    "sliceClear [performance experimental]",
    "sloppyLen [diagnostic]",
    "sloppyReassign [diagnostic experimental]",
    "sloppyTypeAssert [diagnostic]",
    "sortSlice [diagnostic experimental]",
    "sprintfQuotedString [diagnostic experimental]",
    "sqlQuery [diagnostic experimental]",
    "stringConcatSimplify [style experimental]",
    "stringXbytes [performance]",
    "stringsCompare [style experimental]",
    "switchTrue [style]",
    "syncMapLoadAndDelete [diagnostic experimental]",
    "timeExprSimplify [style experimental]",
    "todoCommentWithoutDetail [style opinionated experimental]",
    "tooManyResultsChecker [style opinionated experimental]",
    "truncateCmp [diagnostic experimental]",
    "typeAssertChain [style experimental]",
    "typeDefFirst [style experimental]",
    "typeSwitchVar [style]",
    "typeUnparen [style opinionated]",
    "uncheckedInlineErr [diagnostic experimental]",
    "underef [style]",
    "unlabelStmt [style experimental]",
    "unlambda [style]",
    "unnamedResult [style opinionated experimental]",
    "unnecessaryBlock [style opinionated experimental]",
    "unnecessaryDefer [diagnostic experimental]",
    "unslice [style]",
    "valSwap [style]",
    "weakCond [diagnostic experimental]",
    "whyNoLint [style experimental]",
    "wrapperFunc [style]",
    "yodaStyleExpr [style experimental]",
    "zeroByteRepeat [performance]",
    NULL
};

static const char *default_checks =
    "appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,"
    "commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,"
    "dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,"
    "offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,"
    "typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc";

static void list_add(StrList *l, const char *s) {
    if (!s || !*s) return;
    if (l->len == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->items = realloc(l->items, (size_t)l->cap * sizeof(char *));
        if (!l->items) exit(2);
    }
    l->items[l->len++] = strdup(s);
}

static void add_csv(StrList *l, const char *s) {
    char *tmp = strdup(s ? s : "");
    char *p = tmp, *tok;
    while ((tok = strsep(&p, ",")) != NULL) {
        while (isspace((unsigned char)*tok)) tok++;
        char *end = tok + strlen(tok);
        while (end > tok && isspace((unsigned char)end[-1])) *--end = 0;
        if (*tok) list_add(l, tok);
    }
    free(tmp);
}

static bool list_has(const StrList *l, const char *s) {
    for (int i = 0; i < l->len; i++) {
        if (strcmp(l->items[i], s) == 0) return true;
        if (strcmp(l->items[i], "#diagnostic") == 0) {
            if (strcmp(s, "appendAssign") == 0 || strcmp(s, "badCond") == 0 ||
                strcmp(s, "dupArg") == 0 || strcmp(s, "dupCase") == 0 ||
                strcmp(s, "dupSubExpr") == 0 || strcmp(s, "exitAfterDefer") == 0 ||
                strcmp(s, "offBy1") == 0 || strcmp(s, "sloppyLen") == 0 ||
                strcmp(s, "sloppyTypeAssert") == 0) return true;
        }
        if (strcmp(l->items[i], "#style") == 0) {
            if (strcmp(s, "assignOp") == 0 || strcmp(s, "elseif") == 0 ||
                strcmp(s, "regexpMust") == 0 || strcmp(s, "singleCaseSwitch") == 0 ||
                strcmp(s, "switchTrue") == 0 || strcmp(s, "underef") == 0 ||
                strcmp(s, "unlambda") == 0 || strcmp(s, "unslice") == 0 ||
                strcmp(s, "valSwap") == 0) return true;
        }
    }
    return false;
}

static bool checker_enabled(Config *cfg, const char *name) {
    if (list_has(&cfg->disabled, name) || list_has(&cfg->disabled, "#all")) return false;
    if (cfg->enable_all) return true;
    if (cfg->enabled.len == 0) return strstr(default_checks, name) != NULL;
    return list_has(&cfg->enabled, name);
}

static void usage(void) {
    printf("Usage:\n\n");
    printf("    go-critic <command> [arguments...]\n\n");
    printf("The commands are:\n\n");
    printf("    check             run linter over specified targets\n");
    printf("    doc               get installed checkers documentation\n");
    printf("    help              shows help message\n");
    printf("    version           shows version of the application\n\n");
    printf("Version: %s\n\n", version);
}

static void check_help(void) {
    printf("Usage of go-critic:\n");
    printf("  -@captLocal.paramsOnly\n\twhether to restrict checker to params only (default true)\n");
    printf("  -@commentedOutCode.minLength int\n\tmin length of the comment that triggers a warning (default 15)\n");
    printf("  -@elseif.skipBalanced\n\twhether to skip balanced if-else pairs (default true)\n");
    printf("  -@hugeParam.sizeThreshold int\n\tsize in bytes that makes the warning trigger (default 80)\n");
    printf("  -@ifElseChain.minThreshold int\n\tmin number of if-else blocks that makes the warning trigger (default 2)\n");
    printf("  -@rangeExprCopy.sizeThreshold int\n\tsize in bytes that makes the warning trigger (default 512)\n");
    printf("  -@rangeExprCopy.skipTestFuncs\n\twhether to check test functions (default true)\n");
    printf("  -@rangeValCopy.sizeThreshold int\n\tsize in bytes that makes the warning trigger (default 128)\n");
    printf("  -@rangeValCopy.skipTestFuncs\n\twhether to check test functions (default true)\n");
    printf("  -@ruleguard.debug string\n\tenable debug for the specified named rules group\n");
    printf("  -@ruleguard.disable string\n\tcomma-separated list of disabled groups or skip empty to enable everything\n");
    printf("  -@ruleguard.enable string\n\tcomma-separated list of enabled groups or skip empty to enable everything (default \"<all>\")\n");
    printf("  -@ruleguard.failOn string\n\tDetermines the behavior when an error occurs while parsing ruleguard files.\n");
    printf("\tIf flag is not set, log error and skip rule files that contain an error.\n");
    printf("\tIf flag is set, the value must be a comma-separated list of error conditions.\n");
    printf("\t* 'import': rule refers to a package that cannot be loaded.\n");
    printf("\t* 'dsl':    gorule file does not comply with the ruleguard DSL.\n");
    printf("  -@ruleguard.failOnError\n\tdeprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''\n");
    printf("  -@ruleguard.rules string\n\tcomma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified\n");
    printf("  -@tooManyResultsChecker.maxResults int\n\tmaximum number of results (default 5)\n");
    printf("  -@truncateCmp.skipArchDependent\n\twhether to skip int/uint/uintptr types (default true)\n");
    printf("  -@underef.skipRecvDeref\n\twhether to skip (*x).method() calls where x is a pointer receiver (default true)\n");
    printf("  -@unnamedResult.checkExported\n\twhether to check exported functions\n");
    printf("  -checkGenerated\n\twhether to check generated files\n");
    printf("  -checkTests\n\twhether to check test files (default true)\n");
    printf("  -concurrency int\n\thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 14)\n");
    printf("  -cpuprofile string\n\twrite CPU profile to the specified file\n");
    printf("  -disable string\n\tcomma-separated list of checkers to be disabled. Can include #tags\n");
    printf("  -enable string\n\tcomma-separated list of enabled checkers. Can include #tags (default \"%s\")\n", default_checks);
    printf("  -enableAll\n\tidentical to -enable with all checkers listed. If true, -enable is ignored\n");
    printf("  -exitCode int\n\texit code to be used when lint issues are found (default 1)\n");
    printf("  -go string\n\tselect the Go version to target. Leave as string for the latest\n");
    printf("  -memprofile string\n\twrite memory profile to the specified file\n");
    printf("  -shorterErrLocation\n\twhether to replace error location prefix with $GOROOT and $GOPATH (default true)\n");
    printf("  -v\twhether to print output useful during linter debugging\n");
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool endswith(const char *s, const char *suffix) {
    size_t a = strlen(s), b = strlen(suffix);
    return a >= b && strcmp(s + a - b, suffix) == 0;
}

static int colof(const char *line, const char *p) {
    return p ? (int)(p - line) + 1 : 1;
}

static void report_issue(SourceFile *sf, int line, int col, const char *checker, const char *msg, int *count) {
    printf("%s:%d:%d: %s: %s\n", sf->path, line, col < 1 ? 1 : col, checker, msg);
    (*count)++;
}

static bool generated_file(SourceFile *sf) {
    int max = sf->nlines < 8 ? sf->nlines : 8;
    for (int i = 0; i < max; i++) {
        if (strstr(sf->lines[i], "Code generated") && strstr(sf->lines[i], "DO NOT EDIT")) return true;
    }
    return false;
}

static char *read_file(const char *path, long *len_out) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)n + 2);
    if (!buf) exit(2);
    long got = (long)fread(buf, 1, (size_t)n, f);
    fclose(f);
    buf[got] = 0;
    if (len_out) *len_out = got;
    return buf;
}

static SourceFile load_source(const char *path) {
    SourceFile sf = {0};
    sf.path = strdup(path);
    long n = 0;
    char *buf = read_file(path, &n);
    if (!buf) return sf;
    int cap = 64;
    sf.lines = calloc((size_t)cap, sizeof(char *));
    char *p = buf;
    while (*p) {
        if (sf.nlines == cap) {
            cap *= 2;
            sf.lines = realloc(sf.lines, (size_t)cap * sizeof(char *));
        }
        char *start = p;
        while (*p && *p != '\n') p++;
        if (*p == '\n') *p++ = 0;
        sf.lines[sf.nlines++] = strdup(start);
    }
    free(buf);
    return sf;
}

static void free_source(SourceFile *sf) {
    for (int i = 0; i < sf->nlines; i++) free(sf->lines[i]);
    free(sf->lines);
    free(sf->path);
}

static bool ident_char(int c) {
    return isalnum((unsigned char)c) || c == '_' || c == '.';
}

static void copy_token_before(char *out, size_t outsz, const char *line, const char *pos) {
    const char *e = pos;
    while (e > line && isspace((unsigned char)e[-1])) e--;
    const char *s = e;
    while (s > line && ident_char((unsigned char)s[-1])) s--;
    size_t n = (size_t)(e - s);
    if (n >= outsz) n = outsz - 1;
    memcpy(out, s, n);
    out[n] = 0;
}

static void copy_token_after(char *out, size_t outsz, const char *pos) {
    while (*pos && isspace((unsigned char)*pos)) pos++;
    const char *s = pos;
    while (*pos && ident_char((unsigned char)*pos)) pos++;
    size_t n = (size_t)(pos - s);
    if (n >= outsz) n = outsz - 1;
    memcpy(out, s, n);
    out[n] = 0;
}

static bool same_expr_around(const char *line, const char *op) {
    char a[128], b[128];
    copy_token_before(a, sizeof(a), line, op);
    copy_token_after(b, sizeof(b), op + 2);
    return a[0] && strcmp(a, b) == 0;
}

static void check_line_patterns(Config *cfg, SourceFile *sf, int i, int *issues) {
    char *line = sf->lines[i];
    char *s = trim(line);
    if (*s == 0 || strncmp(s, "//", 2) == 0) return;

    if (checker_enabled(cfg, "elseif") && strstr(s, "else if")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "else if")), "elseif", "can replace 'else {if cond {}}' with 'else if cond {}'", issues);
    }
    if (checker_enabled(cfg, "switchTrue") && strstr(s, "switch true")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "switch true")), "switchTrue", "can omit redundant true in switch expression", issues);
    }
    if (checker_enabled(cfg, "singleCaseSwitch") && strstr(s, "switch ") && strstr(s, "case ") && !strstr(s, "default")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "switch")), "singleCaseSwitch", "should rewrite switch statement to if statement", issues);
    }
    if (checker_enabled(cfg, "regexpMust") && strstr(s, "regexp.Compile(")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "regexp.Compile")), "regexpMust", "can use regexp.MustCompile", issues);
    }
    if (checker_enabled(cfg, "unslice") && strstr(s, "[:]")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "[:]")), "unslice", "could simplify expression by removing redundant slice operation", issues);
    }
    if (checker_enabled(cfg, "newDeref") && strstr(s, "*new(")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "*new(")), "newDeref", "replace *new(T) with T{}", issues);
    }
    if (checker_enabled(cfg, "underef") && strstr(s, "(*") && strstr(s, ").")) {
        report_issue(sf, i + 1, colof(line, strstr(line, "(*")), "underef", "could simplify (*x).y to x.y", issues);
    }
    if (checker_enabled(cfg, "sloppyLen")) {
        char *p = strstr(s, "len(");
        if (p && (strstr(p, ") == 0") || strstr(p, ")==0") || strstr(p, ") != 0") || strstr(p, ")!=0"))) {
            report_issue(sf, i + 1, colof(line, strstr(line, "len(")), "sloppyLen", "should replace len() comparison with direct string/slice comparison", issues);
        }
    }
    if (checker_enabled(cfg, "badCond")) {
        char *ops[] = {"==", "!=", "<=", ">=", NULL};
        for (int k = 0; ops[k]; k++) {
            char *p = strstr(s, ops[k]);
            if (p && same_expr_around(s, p)) {
                report_issue(sf, i + 1, colof(line, strstr(line, ops[k])), "badCond", "suspicious condition: left and right expressions are identical", issues);
                break;
            }
        }
    }
    if (checker_enabled(cfg, "dupSubExpr")) {
        char *ops[] = {" && ", " || ", NULL};
        for (int k = 0; ops[k]; k++) {
            char *p = strstr(s, ops[k]);
            if (p) {
                char left[128], right[128];
                copy_token_before(left, sizeof(left), s, p);
                copy_token_after(right, sizeof(right), p + strlen(ops[k]));
                if (left[0] && strcmp(left, right) == 0) {
                    report_issue(sf, i + 1, colof(line, strstr(line, ops[k]) + 1), "dupSubExpr", "suspicious duplicated sub-expression", issues);
                    break;
                }
            }
        }
    }
    if (checker_enabled(cfg, "assignOp")) {
        char *eq = strstr(s, " = ");
        if (eq) {
            char lhs[128], rhs[128];
            copy_token_before(lhs, sizeof(lhs), s, eq);
            copy_token_after(rhs, sizeof(rhs), eq + 3);
            char *op = eq + 3 + strlen(rhs);
            while (*op && isspace((unsigned char)*op)) op++;
            if (lhs[0] && strcmp(lhs, rhs) == 0 && strchr("+-*/%&|^", *op)) {
                report_issue(sf, i + 1, colof(line, strstr(line, " = ")), "assignOp", "replace assignment with operator assignment", issues);
            }
        }
    }
    if (checker_enabled(cfg, "appendAssign")) {
        char *eq = strstr(s, "=");
        char *ap = strstr(s, "append(");
        if (eq && ap && eq < ap) {
            char lhs[128], first[128];
            copy_token_before(lhs, sizeof(lhs), s, eq);
            copy_token_after(first, sizeof(first), ap + 7);
            if (lhs[0] && first[0] && strcmp(lhs, first) != 0) {
                report_issue(sf, i + 1, colof(line, strstr(line, "append(")), "appendAssign", "append result not assigned to the same slice", issues);
            }
        }
    }
    if (checker_enabled(cfg, "exitAfterDefer") && strstr(s, "defer ") && i + 1 < sf->nlines) {
        if (strstr(sf->lines[i + 1], "os.Exit(") || strstr(sf->lines[i + 1], "log.Fatal")) {
            report_issue(sf, i + 2, colof(sf->lines[i + 1], strstr(sf->lines[i + 1], "(")), "exitAfterDefer", "deferred function will not run after call to os.Exit/log.Fatal", issues);
        }
    }
    if (checker_enabled(cfg, "dupArg")) {
        char *lp = strchr(s, '('), *rp = strrchr(s, ')');
        if (lp && rp && rp > lp + 1 && !strstr(s, "func ")) {
            char inside[512];
            size_t n = (size_t)(rp - lp - 1);
            if (n >= sizeof(inside)) n = sizeof(inside) - 1;
            memcpy(inside, lp + 1, n);
            inside[n] = 0;
            char *save = inside;
            char *args[16];
            int argc = 0;
            char *tok;
            while ((tok = strsep(&save, ",")) && argc < 16) args[argc++] = trim(tok);
            for (int a = 0; a < argc; a++) {
                for (int b = a + 1; b < argc; b++) {
                    if (args[a][0] && strcmp(args[a], args[b]) == 0) {
                        report_issue(sf, i + 1, colof(line, strstr(line, args[b])), "dupArg", "suspicious duplicated argument", issues);
                        a = argc;
                        break;
                    }
                }
            }
        }
    }
}

static void check_file(Config *cfg, const char *path, int *issues) {
    if (!endswith(path, ".go")) return;
    if (!cfg->check_tests && endswith(path, "_test.go")) return;
    SourceFile sf = load_source(path);
    if (!sf.lines) {
        fprintf(stderr, "open %s: %s\n", path, strerror(errno));
        return;
    }
    if (!cfg->check_generated && generated_file(&sf)) {
        free_source(&sf);
        return;
    }

    for (int i = 0; i < sf.nlines; i++) {
        check_line_patterns(cfg, &sf, i, issues);
        if (checker_enabled(cfg, "dupCase") && strstr(sf.lines[i], "case ")) {
            char *p = strstr(sf.lines[i], "case ");
            char val[128];
            copy_token_after(val, sizeof(val), p + 5);
            for (int j = i + 1; j < sf.nlines; j++) {
                if (strstr(sf.lines[j], "switch ")) break;
                char *q = strstr(sf.lines[j], "case ");
                if (q) {
                    char val2[128];
                    copy_token_after(val2, sizeof(val2), q + 5);
                    if (val[0] && strcmp(val, val2) == 0) {
                        report_issue(&sf, j + 1, colof(sf.lines[j], q), "dupCase", "duplicated case clause", issues);
                        break;
                    }
                }
            }
        }
        if (checker_enabled(cfg, "valSwap") && i + 2 < sf.nlines) {
            char a[128], b[128], t1[128], t2[128], left[128], right[128];
            char *l1 = trim(sf.lines[i]), *l2 = trim(sf.lines[i + 1]), *l3 = trim(sf.lines[i + 2]);
            char *op1 = strstr(l1, ":=");
            if (op1) {
                copy_token_before(t1, sizeof(t1), l1, op1);
                copy_token_after(a, sizeof(a), op1 + 2);
                char *eq2 = strstr(l2, "="), *eq3 = strstr(l3, "=");
                if (eq2 && eq3) {
                    copy_token_before(left, sizeof(left), l2, eq2);
                    copy_token_after(b, sizeof(b), eq2 + 1);
                    copy_token_before(t2, sizeof(t2), l3, eq3);
                    copy_token_after(right, sizeof(right), eq3 + 1);
                    if (strcmp(left, a) == 0 && strcmp(t2, b) == 0 && strcmp(right, t1) == 0) {
                        report_issue(&sf, i + 1, 1, "valSwap", "replace 3 assignments with multi-assignment", issues);
                    }
                }
            }
        }
    }
    free_source(&sf);
}

static void walk_target(Config *cfg, const char *path, int *issues) {
    struct stat st;
    if (stat(path, &st) != 0) {
        fprintf(stderr, "stat %s: %s\n", path, strerror(errno));
        return;
    }
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) return;
        struct dirent *ent;
        while ((ent = readdir(d)) != NULL) {
            if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) continue;
            if (strcmp(ent->d_name, "vendor") == 0 || strcmp(ent->d_name, ".git") == 0) continue;
            char buf[4096];
            snprintf(buf, sizeof(buf), "%s/%s", path, ent->d_name);
            walk_target(cfg, buf, issues);
        }
        closedir(d);
    } else {
        check_file(cfg, path, issues);
    }
}

static int run_check(int argc, char **argv) {
    Config cfg = {0};
    cfg.exit_code = 1;
    cfg.check_tests = true;
    for (int i = 0; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "-help") == 0 || strcmp(a, "--help") == 0) {
            check_help();
            printf("parse args: flag: help requested\n");
            return 1;
        } else if (strcmp(a, "-enableAll") == 0) {
            cfg.enable_all = true;
        } else if (strcmp(a, "-checkGenerated") == 0) {
            cfg.check_generated = true;
        } else if (strcmp(a, "-checkTests=false") == 0) {
            cfg.check_tests = false;
        } else if (strcmp(a, "-checkTests") == 0) {
            cfg.check_tests = true;
        } else if (strncmp(a, "-enable=", 8) == 0) {
            add_csv(&cfg.enabled, a + 8);
        } else if (strcmp(a, "-enable") == 0 && i + 1 < argc) {
            add_csv(&cfg.enabled, argv[++i]);
        } else if (strncmp(a, "-disable=", 9) == 0) {
            add_csv(&cfg.disabled, a + 9);
        } else if (strcmp(a, "-disable") == 0 && i + 1 < argc) {
            add_csv(&cfg.disabled, argv[++i]);
        } else if (strncmp(a, "-exitCode=", 10) == 0) {
            cfg.exit_code = atoi(a + 10);
        } else if (strcmp(a, "-exitCode") == 0 && i + 1 < argc) {
            cfg.exit_code = atoi(argv[++i]);
        } else if (strcmp(a, "-v") == 0 || strcmp(a, "-shorterErrLocation") == 0 ||
                   strcmp(a, "-checkGenerated=false") == 0 || strcmp(a, "-shorterErrLocation=false") == 0 ||
                   strcmp(a, "-@captLocal.paramsOnly") == 0 || strcmp(a, "-@elseif.skipBalanced") == 0 ||
                   strncmp(a, "-@", 2) == 0) {
        } else if ((strcmp(a, "-go") == 0 || strcmp(a, "-concurrency") == 0 ||
                    strcmp(a, "-cpuprofile") == 0 || strcmp(a, "-memprofile") == 0) && i + 1 < argc) {
            i++;
        } else if (strncmp(a, "-go=", 4) == 0 || strncmp(a, "-concurrency=", 13) == 0 ||
                   strncmp(a, "-cpuprofile=", 12) == 0 || strncmp(a, "-memprofile=", 12) == 0) {
        } else if (a[0] == '-') {
            char flag[256];
            size_t n = strcspn(a, "=");
            if (n >= sizeof(flag)) n = sizeof(flag) - 1;
            memcpy(flag, a, n);
            flag[n] = 0;
            fprintf(stderr, "flag provided but not defined: %s\n", flag);
            check_help();
            fflush(stdout);
            fprintf(stderr, "parse args: flag provided but not defined: %s\n", flag);
            return 1;
        } else if (strcmp(a, "./...") == 0) {
            list_add(&cfg.targets, ".");
        } else {
            list_add(&cfg.targets, a);
        }
    }
    if (cfg.targets.len == 0) {
        fprintf(stderr, "load packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: \n");
        return 1;
    }
    int issues = 0;
    for (int i = 0; i < cfg.targets.len; i++) walk_target(&cfg, cfg.targets.items[i], &issues);
    return issues ? cfg.exit_code : 0;
}

static bool doc_one(const char *name) {
    if (strcmp(name, "appendAssign") == 0) {
        printf("appendAssign checker documentation\nURL: https://github.com/go-critic/go-critic/checkers\nTags: [diagnostic]\n\n");
        printf("Detects suspicious append result assignments.\n\nNon-compliant code:\np.positives = append(p.negatives, x)\np.negatives = append(p.negatives, y)\n\n");
        printf("Compliant code:\np.positives = append(p.positives, x)\np.negatives = append(p.negatives, y)\n");
        return true;
    }
    for (const char **p = all_docs; *p; p++) {
        size_t n = strcspn(*p, " ");
        if (strlen(name) == n && strncmp(*p, name, n) == 0) {
            printf("%s checker documentation\nURL: https://github.com/go-critic/go-critic/checkers\nTags: ", name);
            char *lb = strchr(*p, '[');
            puts(lb ? lb : "[]");
            printf("\n%s checker is installed in this go-critic build.\n", name);
            return true;
        }
    }
    return false;
}

static int run_doc(int argc, char **argv) {
    if (argc > 0 && argv[0][0] == '-') {
        printf("Usage of go-critic:\nflag: help requested\n");
        return 0;
    }
    if (argc == 0) {
        for (const char **p = all_docs; *p; p++) puts(*p);
        return 0;
    }
    if (!doc_one(argv[0])) {
        fprintf(stderr, "checker with name \"%s\" not found\n", argv[0]);
        return 1;
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc <= 1) {
        puts("no args provided");
        return 0;
    }
    const char *cmd = argv[1];
    if (strcmp(cmd, "help") == 0) {
        usage();
        return 0;
    }
    if (strcmp(cmd, "version") == 0) {
        printf("go-critic version: %s\n", version);
        return 0;
    }
    if (strcmp(cmd, "doc") == 0) return run_doc(argc - 2, argv + 2);
    if (strcmp(cmd, "check") == 0) return run_check(argc - 2, argv + 2);
    if (strcmp(cmd, "--help") == 0) {
        fprintf(stderr, "\"--help\" unknown command, did you mean \"help\"?\nRun \"go-critic help\" for usage.\n\nno such command \"--help\"\n");
        return 1;
    }
    fprintf(stderr, "no such command \"%s\"\n\"%s\" unknown command, did you mean \"doc\"?\nRun \"go-critic help\" for usage.\n\n", cmd, cmd);
    return 0;
}
