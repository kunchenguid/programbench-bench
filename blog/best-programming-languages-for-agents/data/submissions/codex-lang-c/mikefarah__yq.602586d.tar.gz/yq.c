#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { V_NULL, V_BOOL, V_NUM, V_STR, V_ARR, V_OBJ } Type;
typedef struct Val Val;
typedef struct { char *key; Val *val; } Pair;
struct Val {
    Type t;
    int b;
    double num;
    int is_int;
    char *s;
    Val **a;
    int an, ac;
    Pair *o;
    int on, oc;
};

static const char *VERSION = "yq (https://github.com/mikefarah/yq/) version v4.52.5\n";
static const char *HELP =
"yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) \n"
"See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.\n\n"
"Usage:\n  yq [flags]\n  yq [command]\n\n"
"Examples:\n\n"
"# yq tries to auto-detect the file format based off the extension, and defaults to YAML if it's unknown (or piping through STDIN)\n"
"# Use the '-p/--input-format' flag to specify a format type.\n"
"cat file.xml | yq -p xml\n\n"
"# read the \"stuff\" node from \"myfile.yml\"\n"
"yq '.stuff' < myfile.yml\n\n"
"# update myfile.yml in place\n"
"yq -i '.stuff = \"foo\"' myfile.yml\n\n"
"# print contents of sample.json as idiomatic YAML\n"
"yq -P -oy sample.json\n\n\n"
"Available Commands:\n"
"  completion  Generate the autocompletion script for the specified shell\n"
"  eval        (default) Apply the expression to each document in each yaml file in sequence\n"
"  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once\n"
"  help        Help about any command\n\n"
"Flags:\n"
"  -C, --colors                            force print with colors\n"
"  -e, --exit-status                       set exit status if there are no matches or null or false is returned\n"
"  -h, --help                              help for yq\n"
"  -I, --indent int                        sets indent level for output (default 2)\n"
"  -i, --inplace                           update the file in place of first file given.\n"
"  -n, --null-input                        Don't read input, simply evaluate the expression given. Useful for creating docs from scratch.\n"
"  -o, --output-format string              output format type. (default \"auto\")\n"
"  -p, --input-format string               parse format for input. (default \"auto\")\n"
"  -P, --prettyPrint                       pretty print, shorthand for '... style = \"\"'\n"
"  -r, --unwrapScalar                      unwrap scalar, print the value with no quotes, colours or comments. Defaults to true for yaml (default true)\n"
"  -v, --verbose                           verbose mode\n"
"  -V, --version                           Print version information and quit\n";

static Val *vnew(Type t){ Val *v=calloc(1,sizeof(*v)); if(!v){perror("calloc"); exit(2);} v->t=t; return v; }
static Val *vnull(void){ return vnew(V_NULL); }
static Val *vbool(int b){ Val*v=vnew(V_BOOL); v->b=b; return v; }
static Val *vnum(double n,int is_int){ Val*v=vnew(V_NUM); v->num=n; v->is_int=is_int; return v; }
static Val *vstr(const char*s){ Val*v=vnew(V_STR); v->s=strdup(s?s:""); return v; }
static Val *varr(void){ return vnew(V_ARR); }
static Val *vobj(void){ return vnew(V_OBJ); }
static void arr_add(Val*a, Val*x){ if(a->an==a->ac){a->ac=a->ac?a->ac*2:4; a->a=realloc(a->a,a->ac*sizeof(Val*));} a->a[a->an++]=x; }
static Pair *obj_find(Val*o,const char*k){ if(!o||o->t!=V_OBJ)return NULL; for(int i=0;i<o->on;i++) if(strcmp(o->o[i].key,k)==0)return &o->o[i]; return NULL; }
static void obj_set(Val*o,const char*k,Val*x){ Pair*p=obj_find(o,k); if(p){p->val=x; return;} if(o->on==o->oc){o->oc=o->oc?o->oc*2:4; o->o=realloc(o->o,o->oc*sizeof(Pair));} o->o[o->on].key=strdup(k); o->o[o->on].val=x; o->on++; }

static char *read_all(FILE*f){ char *buf=NULL; size_t n=0,cap=0; char tmp[4096]; for(;;){ size_t r=fread(tmp,1,sizeof(tmp),f); if(r){ if(n+r+1>cap){cap=(n+r+1)*2; buf=realloc(buf,cap);} memcpy(buf+n,tmp,r); n+=r;} if(r<sizeof(tmp)){ if(ferror(f)){perror("read"); exit(1);} break; }} if(!buf) buf=strdup(""); else buf[n]=0; return buf; }
static char *read_file(const char*name){ if(strcmp(name,"-")==0) return read_all(stdin); FILE*f=fopen(name,"rb"); if(!f){fprintf(stderr,"Error: open %s: %s\n",name,strerror(errno)); exit(1);} char*s=read_all(f); fclose(f); return s; }

typedef struct { const char*s; size_t i; } JP;
static void jws(JP*p){ while(isspace((unsigned char)p->s[p->i]))p->i++; }
static char *parse_jstr(JP*p){
    char q=p->s[p->i++]; size_t cap=32,n=0; char*out=malloc(cap);
    while(p->s[p->i] && p->s[p->i]!=q){ char c=p->s[p->i++]; if(c=='\\'){ c=p->s[p->i++]; if(c=='n')c='\n'; else if(c=='t')c='\t'; else if(c=='r')c='\r'; else if(c=='b')c='\b'; else if(c=='f')c='\f'; }
        if(n+2>cap){cap*=2; out=realloc(out,cap);} out[n++]=c; }
    if(p->s[p->i]==q)p->i++; out[n]=0; return out;
}
static Val *jval(JP*p);
static Val *jobj(JP*p){ Val*o=vobj(); p->i++; jws(p); while(p->s[p->i]&&p->s[p->i]!='}'){ jws(p); char*k=parse_jstr(p); jws(p); if(p->s[p->i]==':')p->i++; Val*v=jval(p); obj_set(o,k,v); free(k); jws(p); if(p->s[p->i]==',')p->i++; jws(p);} if(p->s[p->i]=='}')p->i++; return o; }
static Val *jarr(JP*p){ Val*a=varr(); p->i++; jws(p); while(p->s[p->i]&&p->s[p->i]!=']'){ arr_add(a,jval(p)); jws(p); if(p->s[p->i]==',')p->i++; jws(p);} if(p->s[p->i]==']')p->i++; return a; }
static Val *jatom(JP*p){ size_t st=p->i; while(p->s[p->i]&&!strchr(",]}\n\r\t ",p->s[p->i]))p->i++; char*t=strndup(p->s+st,p->i-st); Val*v; if(!strcmp(t,"null"))v=vnull(); else if(!strcmp(t,"true"))v=vbool(1); else if(!strcmp(t,"false"))v=vbool(0); else { char*e; double d=strtod(t,&e); v=(*e? vstr(t): vnum(d, strchr(t,'.')==NULL && strchr(t,'e')==NULL && strchr(t,'E')==NULL)); } free(t); return v; }
static Val *jval(JP*p){ jws(p); char c=p->s[p->i]; if(c=='{')return jobj(p); if(c=='[')return jarr(p); if(c=='"'||c=='\''){char*s=parse_jstr(p); Val*v=vstr(s); free(s); return v;} return jatom(p); }
static Val *parse_json(const char*s){ JP p={s,0}; return jval(&p); }

static char *trim(char*s){ while(isspace((unsigned char)*s))s++; char*e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static Val *scalar(const char*t){
    char *buf=strdup(t?t:""), *s=trim(buf); Val*v;
    if(!*s||!strcmp(s,"null")||!strcmp(s,"~")) v=vnull();
    else if(!strcmp(s,"true")) v=vbool(1);
    else if(!strcmp(s,"false")) v=vbool(0);
    else if((*s=='"'&&s[strlen(s)-1]=='"')||(*s=='\''&&s[strlen(s)-1]=='\'')){ JP p={s,0}; char*x=parse_jstr(&p); v=vstr(x); free(x); }
    else { char*e; double d=strtod(s,&e); if(*s&&!*e) v=vnum(d, strchr(s,'.')==NULL&&strchr(s,'e')==NULL&&strchr(s,'E')==NULL); else v=vstr(s); }
    free(buf); return v;
}

typedef struct { int ind; char *txt; } YLine;
typedef struct { YLine *l; int n,c; } YDoc;
static void yadd(YDoc*d,int ind,char*txt){ if(d->n==d->c){d->c=d->c?d->c*2:32; d->l=realloc(d->l,d->c*sizeof(YLine));} d->l[d->n].ind=ind; d->l[d->n].txt=strdup(txt); d->n++; }
static char *no_comment(char*s){ int q=0; for(int i=0;s[i];i++){ if(s[i]=='"'||s[i]=='\'') q = q==s[i]?0:(q? q:s[i]); if(s[i]=='#'&&!q&&(i==0||isspace((unsigned char)s[i-1]))){s[i]=0;break;} } return s; }
static Val *yblock(YDoc*d,int*pos,int ind);
static Val *parse_yaml(const char*text){
    YDoc d={0}; char *copy=strdup(text), *save=NULL;
    for(char*ln=strtok_r(copy,"\n",&save); ln; ln=strtok_r(NULL,"\n",&save)){ no_comment(ln); int len=strlen(ln); while(len&& (ln[len-1]=='\r'||isspace((unsigned char)ln[len-1]))) ln[--len]=0; char*p=ln; int ind=0; while(*p==' '){ind++;p++;} if(!*p||!strcmp(p,"---")||!strcmp(p,"..."))continue; yadd(&d,ind,p); }
    free(copy); if(!d.n)return vnull(); int pos=0; return yblock(&d,&pos,d.l[0].ind);
}

static Val *parse_delim(const char*text, char sep){
    Val*out=varr(); char*copy=strdup(text), *save=NULL; char**hdr=NULL; int hn=0;
    for(char*ln=strtok_r(copy,"\n",&save); ln; ln=strtok_r(NULL,"\n",&save)){
        size_t L=strlen(ln); if(L&&ln[L-1]=='\r')ln[L-1]=0;
        char**cols=NULL; int cn=0,cc=0; char*p=ln;
        for(;;){ if(cn==cc){cc=cc?cc*2:8; cols=realloc(cols,cc*sizeof(char*));} char*st=p; while(*p&&*p!=sep)p++; cols[cn++]=strndup(st,p-st); if(!*p)break; p++; }
        if(!hdr){ hdr=cols; hn=cn; }
        else { Val*o=vobj(); for(int i=0;i<hn;i++) obj_set(o,hdr[i], scalar(i<cn?cols[i]:"")); arr_add(out,o); for(int i=0;i<cn;i++)free(cols[i]); free(cols); }
    }
    if(hdr){ for(int i=0;i<hn;i++)free(hdr[i]); free(hdr); } free(copy); return out;
}

static Val *parse_props(const char*text){
    Val*o=vobj(); char*copy=strdup(text), *save=NULL;
    for(char*ln=strtok_r(copy,"\n",&save); ln; ln=strtok_r(NULL,"\n",&save)){
        char*s=trim(ln); if(!*s||*s=='#'||*s=='!')continue; char*e=strchr(s,'='); if(!e)e=strchr(s,':'); if(!e)continue; *e=0;
        obj_set(o, trim(s), scalar(trim(e+1)));
    }
    free(copy); return o;
}
static Val *yblock(YDoc*d,int*pos,int ind){
    if(*pos>=d->n)return vnull();
    if(d->l[*pos].ind==ind && !strncmp(d->l[*pos].txt,"- ",2)){
        Val*a=varr();
        while(*pos<d->n && d->l[*pos].ind==ind && !strncmp(d->l[*pos].txt,"- ",2)){
            char*item=trim(d->l[*pos].txt+2); (*pos)++;
            char*colon=strchr(item,':');
            if(!*item){ arr_add(a,yblock(d,pos,ind+2)); }
            else if(colon){ *colon=0; char*k[1024]; (void)k; Val*o=vobj(); char*key=trim(item); char*val=trim(colon+1); if(*val) obj_set(o,key,scalar(val)); else obj_set(o,key,yblock(d,pos,ind+2));
                while(*pos<d->n && d->l[*pos].ind==ind+2 && strncmp(d->l[*pos].txt,"- ",2)){ char*c=strchr(d->l[*pos].txt,':'); if(!c)break; *c=0; char*kk=trim(d->l[*pos].txt); char*vv=trim(c+1); (*pos)++; obj_set(o,kk,*vv?scalar(vv):yblock(d,pos,ind+4)); }
                arr_add(a,o);
            } else arr_add(a,scalar(item));
        }
        return a;
    }
    Val*o=vobj();
    while(*pos<d->n && d->l[*pos].ind==ind && strncmp(d->l[*pos].txt,"- ",2)){
        char*c=strchr(d->l[*pos].txt,':'); if(!c)return scalar(d->l[(*pos)++].txt);
        *c=0; char*k=trim(d->l[*pos].txt); char*v=trim(c+1); (*pos)++; obj_set(o,k,*v?scalar(v):yblock(d,pos,ind+2));
    }
    return o;
}

typedef struct { int is_idx; int idx; char *key; } Path;
static Path *parse_path(const char*e,int*n){
    *n=0; int cap=8; Path*p=calloc(cap,sizeof(Path)); int i=0; if(e[i]=='.')i++;
    while(e[i]){ if(*n==cap){cap*=2;p=realloc(p,cap*sizeof(Path));} if(e[i]=='.'){i++;continue;} if(e[i]=='['){ i++; int st=i; while(e[i]&&e[i]!=']')i++; char*t=strndup(e+st,i-st); p[*n].is_idx=1; p[*n].idx=atoi(t); free(t); if(e[i]==']')i++; (*n)++; } else { int st=i; while(e[i]&&e[i]!='.'&&e[i]!='[')i++; p[*n].key=strndup(e+st,i-st); (*n)++; } }
    return p;
}
static Val *get_path(Val*v,Path*p,int n){ for(int i=0;i<n;i++){ if(!v)return vnull(); if(p[i].is_idx){ if(v->t!=V_ARR||p[i].idx<0||p[i].idx>=v->an)return vnull(); v=v->a[p[i].idx]; } else { Pair*q=obj_find(v,p[i].key); if(!q)return vnull(); v=q->val; } } return v; }
static Val *set_path(Val*v,Path*p,int n,Val*x){ if(!v||v->t==V_NULL)v=vobj(); Val*cur=v; for(int i=0;i<n;i++){ int last=i==n-1; if(p[i].is_idx){ if(cur->t!=V_ARR) return v; while(cur->an<=p[i].idx)arr_add(cur,vnull()); if(last)cur->a[p[i].idx]=x; else { if(cur->a[p[i].idx]->t==V_NULL)cur->a[p[i].idx]=p[i+1].is_idx?varr():vobj(); cur=cur->a[p[i].idx]; } } else { if(cur->t!=V_OBJ)return v; if(last)obj_set(cur,p[i].key,x); else { Pair*q=obj_find(cur,p[i].key); if(!q){ obj_set(cur,p[i].key,p[i+1].is_idx?varr():vobj()); q=obj_find(cur,p[i].key);} cur=q->val; } } } return v; }

static Val *eval_expr(const char*expr, Val*data){
    char*buf=strdup(expr); char*s=trim(buf); if(!*s||!strcmp(s,".")){free(buf);return data;}
    char*eqpat=strstr(s," = ");
    char*eq=eqpat ? eqpat + 1 : strchr(s,'=');
    if(eq && strstr(s,"==")!=eq){ *eq=0; char*lhs=trim(s); char*rhs=trim(eq+1); Val*val;
        if(!strncmp(rhs,"strenv(",7)){ char*end=strrchr(rhs,')'); if(end)*end=0; val=vstr(getenv(rhs+7)?getenv(rhs+7):""); } else val=scalar(rhs);
        int n; Path*p=parse_path(lhs,&n); Val*r=set_path(data,p,n,val); free(buf); return r; }
    if(strstr(s,"[] | select(")){ char*br=strstr(s,"[]"); *br=0; int n; Path*p=parse_path(s,&n); Val*arr=get_path(data,p,n); Val*out=varr(); char*cond=strstr(br+2,"select(")+7; char*end=strrchr(cond,')'); if(end)*end=0;
        for(int i=0;arr&&arr->t==V_ARR&&i<arr->an;i++){ Val*ok=eval_expr(cond,arr->a[i]); int truth=(ok->t==V_BOOL?ok->b:ok->t!=V_NULL); if(truth)arr_add(out,arr->a[i]); } free(buf); return out; }
    char*cmp=strstr(s,"=="); if(cmp){ *cmp=0; Val*l=eval_expr(trim(s),data); Val*r=scalar(trim(cmp+2)); int ok=0; if(l->t==V_STR&&r->t==V_STR)ok=!strcmp(l->s,r->s); else if(l->t==V_NUM&&r->t==V_NUM)ok=l->num==r->num; else if(l->t==r->t&&l->t==V_BOOL)ok=l->b==r->b; free(buf); return vbool(ok); }
    int explode=0; size_t L=strlen(s); if(L>=2&&!strcmp(s+L-2,"[]")){ s[L-2]=0; explode=1; }
    int n; Path*p=parse_path(s,&n); Val*r=get_path(data,p,n); if(explode && r->t==V_ARR){ free(buf); return r; } free(buf); return r;
}

static void print_json_str(const char*s){ putchar('"'); for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\')printf("\\%c",c); else if(c=='\n')printf("\\n"); else if(c=='\t')printf("\\t"); else if(c<32)printf("\\u%04x",c); else putchar(c);} putchar('"'); }
static void out_json(Val*v,int ind,int step){ if(!v){printf("null");return;} switch(v->t){ case V_NULL:printf("null");break; case V_BOOL:printf(v->b?"true":"false");break; case V_NUM: if(v->is_int)printf("%.0f",v->num); else printf("%g",v->num); break; case V_STR:print_json_str(v->s);break; case V_ARR: printf("["); for(int i=0;i<v->an;i++){ if(i)printf(","); printf("\n%*s",ind+step,""); out_json(v->a[i],ind+step,step);} if(v->an)printf("\n%*s",ind,""); printf("]"); break; case V_OBJ: printf("{"); for(int i=0;i<v->on;i++){ if(i)printf(","); printf("\n%*s",ind+step,""); print_json_str(v->o[i].key); printf(": "); out_json(v->o[i].val,ind+step,step);} if(v->on)printf("\n%*s",ind,""); printf("}"); break; } }
static void yaml_scalar(Val*v){ if(!v||v->t==V_NULL)printf("null"); else if(v->t==V_BOOL)printf(v->b?"true":"false"); else if(v->t==V_NUM){ if(v->is_int)printf("%.0f",v->num); else printf("%g",v->num); } else if(v->t==V_STR)printf("%s",v->s); }
static void out_yaml(Val*v,int ind,int step){ if(!v){printf("null\n");return;} if(v->t==V_OBJ){ for(int i=0;i<v->on;i++){ printf("%*s%s:",ind,"",v->o[i].key); Val*x=v->o[i].val; if(x->t==V_OBJ||x->t==V_ARR){ printf("\n"); out_yaml(x,ind+step,step);} else { printf(" "); yaml_scalar(x); printf("\n"); } } } else if(v->t==V_ARR){ for(int i=0;i<v->an;i++){ Val*x=v->a[i]; if(x->t==V_OBJ && x->on>0){ printf("%*s- %s:",ind,"",x->o[0].key); Val*y=x->o[0].val; if(y->t==V_OBJ||y->t==V_ARR){printf("\n"); out_yaml(y,ind+step,step);} else {printf(" "); yaml_scalar(y); printf("\n");} for(int j=1;j<x->on;j++){ printf("%*s%s:",ind+step,"",x->o[j].key); y=x->o[j].val; if(y->t==V_OBJ||y->t==V_ARR){printf("\n"); out_yaml(y,ind+2*step,step);} else {printf(" "); yaml_scalar(y); printf("\n");} } } else { printf("%*s- ",ind,""); if(x->t==V_OBJ||x->t==V_ARR){printf("\n"); out_yaml(x,ind+step,step);} else {yaml_scalar(x); printf("\n");} } } } else { yaml_scalar(v); printf("\n"); } }
static void out_props_rec(Val*v,const char*pre){ if(v->t==V_OBJ){ for(int i=0;i<v->on;i++){ char*next; asprintf(&next,"%s%s%s",pre,*pre?".":"",v->o[i].key); out_props_rec(v->o[i].val,next); free(next);} } else if(v->t==V_ARR){ for(int i=0;i<v->an;i++){ char*next; asprintf(&next,"%s.%d",pre,i); out_props_rec(v->a[i],next); free(next);} } else { printf("%s = ",pre); yaml_scalar(v); printf("\n"); } }

int main(int argc,char**argv){
    const char *expr=NULL,*infmt="auto",*outfmt="auto"; int inplace=0,nullin=0,unwrap=-1,exit_status=0,indent=2; char*files[256]; int nf=0;
    int start=1; if(argc>1&&(!strcmp(argv[1],"eval")||!strcmp(argv[1],"e")||!strcmp(argv[1],"eval-all")||!strcmp(argv[1],"ea"))) start=2;
    for(int i=start;i<argc;i++){ char*a=argv[i]; if(!strcmp(a,"--help")||!strcmp(a,"-h")){printf("%s",HELP);return 0;} if(!strcmp(a,"--version")||!strcmp(a,"-V")){printf("%s",VERSION);return 0;} if(!strcmp(a,"-i")||!strcmp(a,"--inplace"))inplace=1; else if(!strcmp(a,"-n")||!strcmp(a,"--null-input"))nullin=1; else if(!strcmp(a,"-e")||!strcmp(a,"--exit-status"))exit_status=1; else if(!strcmp(a,"-r")||!strcmp(a,"--unwrapScalar"))unwrap=1; else if(!strcmp(a,"-P")||!strcmp(a,"-C")||!strcmp(a,"-M")||!strcmp(a,"-N")){} else if((!strcmp(a,"-o")||!strcmp(a,"--output-format"))&&i+1<argc)outfmt=argv[++i]; else if(!strncmp(a,"-o",2)&&strlen(a)>2){outfmt=a+2; if(*outfmt=='=')outfmt++;} else if((!strcmp(a,"-p")||!strcmp(a,"--input-format"))&&i+1<argc)infmt=argv[++i]; else if(!strncmp(a,"-p",2)&&strlen(a)>2){infmt=a+2; if(*infmt=='=')infmt++;} else if((!strcmp(a,"-I")||!strcmp(a,"--indent"))&&i+1<argc)indent=atoi(argv[++i]); else if(!strcmp(a,"--expression")&&i+1<argc)expr=argv[++i]; else if(a[0]=='-' && strcmp(a,"-")){ if(i+1<argc && (!strcmp(a,"--csv-separator")||!strcmp(a,"--properties-separator")||!strcmp(a,"--front-matter")||!strcmp(a,"-f")||!strcmp(a,"-s")))i++; } else { if(!expr && (a[0]=='.'||a[0]=='['||strchr(a,'=')))expr=a; else files[nf++]=a; } }
    if(!expr)expr="."; if(unwrap<0)unwrap=strcmp(infmt,"json")&&strcmp(infmt,"j");
    Val*res=NULL; const char*kind=infmt;
    if(nullin){ res=eval_expr(expr,vnull()); }
    else { if(!nf)files[nf++]="-"; for(int i=0;i<nf;i++){ char*txt=read_file(files[i]); size_t off=strspn(txt," \t\r\n"); Val*doc; int jsonish=0;
            if(!strcmp(infmt,"csv")||!strcmp(infmt,"c") || ((!strcmp(infmt,"auto")||!strcmp(infmt,"a"))&&strstr(files[i],".csv"))){ doc=parse_delim(txt,','); kind="yaml"; }
            else if(!strcmp(infmt,"tsv")||!strcmp(infmt,"t") || ((!strcmp(infmt,"auto")||!strcmp(infmt,"a"))&&strstr(files[i],".tsv"))){ doc=parse_delim(txt,'\t'); kind="yaml"; }
            else if(!strcmp(infmt,"props")||!strcmp(infmt,"p")||!strcmp(infmt,"properties") || ((!strcmp(infmt,"auto")||!strcmp(infmt,"a"))&&(strstr(files[i],".properties")||strstr(files[i],".props")))){ doc=parse_props(txt); kind="yaml"; }
            else { jsonish=(!strcmp(infmt,"json")||!strcmp(infmt,"j")) || ((!strcmp(infmt,"auto")||!strcmp(infmt,"a")) && (txt[off]=='{'||txt[off]=='[' || strstr(files[i],".json"))); kind=jsonish?"json":"yaml"; doc=jsonish?parse_json(txt):parse_yaml(txt); }
            res=eval_expr(expr,doc); if(inplace){ FILE*f=fopen(files[i],"wb"); if(!f){perror("inplace");return 1;} FILE*old=stdout; stdout=f; out_yaml(res,0,indent); stdout=old; fclose(f);} free(txt);} }
    if(!inplace){ const char*of=outfmt; if(!strcmp(of,"auto")||!strcmp(of,"a"))of=(!strcmp(kind,"json")?"json":"yaml"); if(nullin&&!strcmp(expr,".")&&res&&res->t==V_NULL)printf("\n"); else if(unwrap && res && res->t!=V_OBJ && res->t!=V_ARR){ yaml_scalar(res); printf("\n"); } else if(!strcmp(of,"json")||!strcmp(of,"j")){ out_json(res,0,indent); printf("\n"); } else if(!strcmp(of,"props")||!strcmp(of,"p")) out_props_rec(res,""); else out_yaml(res,0,indent); }
    int ok=res && res->t!=V_NULL && !(res->t==V_BOOL&&!res->b); return exit_status&&!ok?1:0;
}
