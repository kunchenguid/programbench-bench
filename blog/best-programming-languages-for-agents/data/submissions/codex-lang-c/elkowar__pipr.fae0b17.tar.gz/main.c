#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} Str;

typedef struct {
    char *def;
    char *out_file;
    char *in_file;
    bool raw_mode;
    bool no_isolation;
} Options;

static const char *CONFIG_REFERENCE =
"\n"
"#  ____  _\n"
"# |  _ \\(_)_ __  _ __       .________.\n"
"# | |_) | | '_ \\| '__|      |________|\n"
"# |  __/| | |_) | |          |_    -|\n"
"# |_|   |_| .__/|_|     xX  xXx___x_|\n"
"#         |_|\n"
"#\n"
"# A commandline utility by\n"
"# Leon Kowarschick\n"
"\n"
"# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.\n"
"# finish_hook = \"xclip -selection clipboard -in\"\n"
"\n"
"# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.\n"
"paranoid_history_mode_default = false\n"
"\n"
"autoeval_mode_default = true\n"
"\n"
"history_size = 500\n"
"cmdlist_always_show_preview = false\n"
"cmd_timeout_millis = 2000\n"
"\n"
"highlighting_enabled = true\n"
"\n"
"eval_environment = [\"bash\", \"-c\"]\n"
"\n"
"# Snippets can be used to quickly insert common bits of shell\n"
"# use || (two pipes) where you want your cursor to be after insertion\n"
"[snippets]\n"
"s = \" | sed -r 's/||//g'\"\n"
"\n"
"[help_viewers]\n"
"'m' = \"man ??\"\n"
"'h' = \"?? --help | less\"\n"
"\n"
"[output_viewers]\n"
"'l' = \"less\"\n";

static void die_oom(void) {
    fprintf(stderr, "out of memory\n");
    exit(1);
}

static void str_init(Str *s) {
    s->cap = 64;
    s->len = 0;
    s->data = malloc(s->cap);
    if (!s->data) die_oom();
    s->data[0] = '\0';
}

static void str_reserve(Str *s, size_t need) {
    if (need <= s->cap) return;
    while (s->cap < need) s->cap *= 2;
    char *n = realloc(s->data, s->cap);
    if (!n) die_oom();
    s->data = n;
}

static void str_set(Str *s, const char *text) {
    size_t n = text ? strlen(text) : 0;
    str_reserve(s, n + 1);
    if (n) memcpy(s->data, text, n);
    s->data[n] = '\0';
    s->len = n;
}

static void str_insert(Str *s, size_t pos, const char *buf, size_t n) {
    if (pos > s->len) pos = s->len;
    str_reserve(s, s->len + n + 1);
    memmove(s->data + pos + n, s->data + pos, s->len - pos + 1);
    memcpy(s->data + pos, buf, n);
    s->len += n;
}

static void str_delete_range(Str *s, size_t pos, size_t n) {
    if (pos >= s->len) return;
    if (pos + n > s->len) n = s->len - pos;
    memmove(s->data + pos, s->data + pos + n, s->len - pos - n + 1);
    s->len -= n;
}

static char *read_file_all(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        exit(1);
    }
    Str s;
    str_init(&s);
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) {
        str_insert(&s, s.len, buf, n);
    }
    if (ferror(f)) {
        int e = errno ? errno : EIO;
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(e), e);
        fclose(f);
        exit(1);
    }
    fclose(f);
    return s.data;
}

static void print_help(void) {
    printf("Usage: ./executable [options]\n"
           "\n"
           "Options:\n"
           "    -d, --default TEXT  text inserted into the textfield on startup\n"
           "    -o, --out-file FILE write final command to file\n"
           "        --in-file FILE  read initial command from file\n"
           "        --config-reference \n"
           "                        print out the default configuration file\n"
           "    -r, --raw-mode      keep linebreaks in finished command when closing\n"
           "        --no-isolation  disable isolation. This will run the commands directly\n"
           "                        on your system, without protection. Take care.\n"
           "    -h, --help          print this help menu\n");
}

static bool has_bwrap(void) {
    char *path = getenv("PATH");
    if (!path) return false;
    char *copy = strdup(path);
    if (!copy) die_oom();
    bool found = false;
    for (char *p = copy; p;) {
        char *next = strchr(p, ':');
        if (next) *next++ = '\0';
        char full[4096];
        snprintf(full, sizeof(full), "%s/%s", *p ? p : ".", "bwrap");
        if (access(full, X_OK) == 0) {
            found = true;
            break;
        }
        p = next;
    }
    free(copy);
    return found;
}

static void parse_args(int argc, char **argv, Options *o) {
    memset(o, 0, sizeof(*o));
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
            print_help();
            exit(0);
        } else if (strcmp(a, "--config-reference") == 0) {
            fputs(CONFIG_REFERENCE, stdout);
            exit(0);
        } else if (strcmp(a, "-r") == 0 || strcmp(a, "--raw-mode") == 0) {
            o->raw_mode = true;
        } else if (strcmp(a, "--no-isolation") == 0) {
            o->no_isolation = true;
        } else if (strcmp(a, "-d") == 0 || strcmp(a, "--default") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "./executable: Argument to option '%s' missing\n", a[1] == '-' ? "default" : "d");
                exit(1);
            }
            o->def = argv[i];
        } else if (strncmp(a, "--default=", 10) == 0) {
            o->def = a + 10;
        } else if (strcmp(a, "-o") == 0 || strcmp(a, "--out-file") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "./executable: Argument to option '%s' missing\n", a[1] == '-' ? "out-file" : "o");
                exit(1);
            }
            o->out_file = argv[i];
        } else if (strncmp(a, "--out-file=", 11) == 0) {
            o->out_file = a + 11;
        } else if (strcmp(a, "--in-file") == 0) {
            if (++i >= argc) {
                fprintf(stderr, "./executable: Argument to option 'in-file' missing\n");
                exit(1);
            }
            o->in_file = argv[i];
        } else if (strncmp(a, "--in-file=", 10) == 0) {
            o->in_file = a + 10;
        } else if (a[0] == '-') {
            const char *name = a;
            while (*name == '-') name++;
            fprintf(stderr, "./executable: Unrecognized option: '%s'\n", name);
            exit(1);
        }
    }
}

static void normalize_final(const char *in, bool raw, Str *out) {
    str_init(out);
    for (size_t i = 0; in[i]; i++) {
        char c = in[i];
        if (!raw && (c == '\n' || c == '\r')) {
            if (out->len == 0 || out->data[out->len - 1] != ' ') {
                str_insert(out, out->len, " ", 1);
            }
        } else {
            str_insert(out, out->len, &c, 1);
        }
    }
    while (out->len && out->data[out->len - 1] == ' ') {
        out->data[--out->len] = '\0';
    }
}

static void write_final(const Options *o, const char *cmd) {
    Str final;
    normalize_final(cmd, o->raw_mode, &final);
    if (o->out_file) {
        FILE *f = fopen(o->out_file, "wb");
        if (!f) {
            fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
            free(final.data);
            exit(1);
        }
        fwrite(final.data, 1, final.len, f);
        fclose(f);
    } else {
        fwrite(final.data, 1, final.len, stdout);
        fputc('\n', stdout);
    }
    free(final.data);
}

static char *run_command(const char *cmd) {
    if (!cmd || !*cmd) return strdup("");
    char *shellcmd;
    size_t n = strlen(cmd) + 16;
    shellcmd = malloc(n);
    if (!shellcmd) die_oom();
    snprintf(shellcmd, n, "%s 2>&1", cmd);
    FILE *p = popen(shellcmd, "r");
    free(shellcmd);
    if (!p) return strdup("");
    Str out;
    str_init(&out);
    char buf[1024];
    size_t r;
    while ((r = fread(buf, 1, sizeof(buf), p)) > 0) {
        if (out.len + r > 12000) break;
        str_insert(&out, out.len, buf, r);
    }
    pclose(p);
    return out.data;
}

static void tty_raw(int fd, struct termios *old) {
    if (tcgetattr(fd, old) != 0) return;
    struct termios t = *old;
    cfmakeraw(&t);
    tcsetattr(fd, TCSANOW, &t);
}

static void get_size(int fd, int *rows, int *cols) {
    struct winsize ws;
    *rows = 24;
    *cols = 80;
    if (ioctl(fd, TIOCGWINSZ, &ws) == 0) {
        if (ws.ws_row) *rows = ws.ws_row;
        if (ws.ws_col) *cols = ws.ws_col;
    }
}

static void term_printf(int fd, const char *fmt, ...) {
    char buf[4096];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n > 0) {
        ssize_t ignored = write(fd, buf, (size_t)n < sizeof(buf) ? (size_t)n : sizeof(buf));
        (void)ignored;
    }
}

static void draw_line_text(int fd, int row, int col, int width, const char *text, size_t start) {
    term_printf(fd, "\033[%d;%dH", row, col);
    int used = 0;
    for (size_t i = start; text[i] && used < width; i++) {
        unsigned char c = (unsigned char)text[i];
        if (c == '\n' || c == '\r') break;
        if (isprint(c) || c >= 128) {
            ssize_t ignored = write(fd, &c, 1);
            (void)ignored;
            used++;
        }
    }
    while (used++ < width) {
        ssize_t ignored = write(fd, " ", 1);
        (void)ignored;
    }
}

static void draw_box(int fd, int top, int left, int bottom, int right, const char *title) {
    if (right <= left + 1 || bottom <= top + 1) return;
    term_printf(fd, "\033[%d;%dH┌", top, left);
    if (title) term_printf(fd, " %s ", title);
    int used = title ? (int)strlen(title) + 2 : 0;
    for (int c = left + 1 + used; c < right; c++) term_printf(fd, "─");
    term_printf(fd, "┐");
    for (int r = top + 1; r < bottom; r++) {
        term_printf(fd, "\033[%d;%dH│\033[%d;%dH│", r, left, r, right);
    }
    term_printf(fd, "\033[%d;%dH└", bottom, left);
    for (int c = left + 1; c < right; c++) term_printf(fd, "─");
    term_printf(fd, "┘");
}

static void render(int fd, Str *cmd, size_t cursor, const char *output) {
    int rows, cols;
    get_size(fd, &rows, &cols);
    if (rows < 5 || cols < 20) {
        term_printf(fd, "\033[2J\033[H");
        return;
    }
    int right = cols - 1;
    int cmd_lines = 1;
    for (size_t i = 0; i < cmd->len; i++) if (cmd->data[i] == '\n') cmd_lines++;
    if (cmd_lines > rows / 3) cmd_lines = rows / 3;
    int cmd_bottom = 2 + cmd_lines + 1;
    term_printf(fd, "\033[?25l\033[2J");
    draw_box(fd, 2, 2, cmd_bottom, right, "Command [Autoeval]");
    int line = 0;
    size_t start = 0;
    for (size_t i = 0; line < cmd_lines; i++) {
        if (cmd->data[i] == '\n' || cmd->data[i] == '\0') {
            draw_line_text(fd, 3 + line, 3, right - 3, cmd->data, start);
            if (cmd->data[i] == '\0') break;
            start = i + 1;
            line++;
        }
    }
    int out_top = cmd_bottom + 1;
    draw_box(fd, out_top, 2, rows - 1, right, "Output [+]");
    int out_row = out_top + 1;
    size_t out_start = 0;
    for (const char *p = output ? output : ""; out_row < rows - 1 && *p;) {
        const char *nl = strchr(p, '\n');
        size_t len = nl ? (size_t)(nl - p) : strlen(p);
        char tmp[1024];
        if (len >= sizeof(tmp)) len = sizeof(tmp) - 1;
        memcpy(tmp, p, len);
        tmp[len] = '\0';
        draw_line_text(fd, out_row++, 3, right - 3, tmp, 0);
        p = nl ? nl + 1 : p + strlen(p);
        out_start++;
    }
    (void)out_start;
    term_printf(fd, "\033[%d;%dHHelp:\033[%d;%dHF1", rows - 1, right - 9, rows - 1, right - 3);
    int crow = 3, ccol = 3;
    for (size_t i = 0; i < cursor && i < cmd->len; i++) {
        if (cmd->data[i] == '\n') {
            crow++;
            ccol = 3;
        } else {
            ccol++;
            if (ccol >= right) ccol = right - 1;
        }
    }
    if (crow > cmd_bottom - 1) crow = cmd_bottom - 1;
    term_printf(fd, "\033[?25h\033[%d;%dH", crow, ccol);
}

static bool read_byte_timeout(int fd, unsigned char *ch, int millis) {
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(fd, &rfds);
    struct timeval tv;
    tv.tv_sec = millis / 1000;
    tv.tv_usec = (millis % 1000) * 1000;
    int r = select(fd + 1, &rfds, NULL, NULL, &tv);
    if (r > 0) return read(fd, ch, 1) == 1;
    return false;
}

static int interactive(const Options *o, const char *initial) {
    int tty = open("/dev/tty", O_RDWR);
    if (tty < 0) {
        printf("\033[?1049h");
        printf("Error: %s (os error %d)\n", strerror(errno), errno);
        return 0;
    }
    struct termios old;
    tty_raw(tty, &old);
    term_printf(tty, "\033[?1049h");

    Str cmd;
    str_init(&cmd);
    str_set(&cmd, initial ? initial : "");
    size_t cursor = cmd.len;
    char *output = run_command(cmd.data);
    render(tty, &cmd, cursor, output);

    bool done = false;
    while (!done) {
        unsigned char ch;
        ssize_t n = read(tty, &ch, 1);
        if (n <= 0) break;
        if (ch == 3 || ch == 4) {
            done = true;
        } else if (ch == '\r' || ch == '\n') {
            free(output);
            output = run_command(cmd.data);
        } else if (ch == 127 || ch == 8) {
            if (cursor > 0) {
                str_delete_range(&cmd, cursor - 1, 1);
                cursor--;
            }
        } else if (ch == 1) {
            cursor = 0;
        } else if (ch == 5) {
            cursor = cmd.len;
        } else if (ch == 11) {
            cmd.data[cursor] = '\0';
            cmd.len = cursor;
        } else if (ch == '\t') {
            str_insert(&cmd, cursor, "    ", 4);
            cursor += 4;
        } else if (ch == 27) {
            unsigned char a, b;
            if (!read_byte_timeout(tty, &a, 30)) {
                done = true;
            } else if (a == '[' && read_byte_timeout(tty, &b, 30)) {
                if (b == 'D' && cursor > 0) cursor--;
                else if (b == 'C' && cursor < cmd.len) cursor++;
                else if (b == 'H') cursor = 0;
                else if (b == 'F') cursor = cmd.len;
            }
        } else if (isprint(ch)) {
            char c = (char)ch;
            str_insert(&cmd, cursor, &c, 1);
            cursor++;
        }
        render(tty, &cmd, cursor, output);
    }

    term_printf(tty, "\033[?1049l");
    tcsetattr(tty, TCSANOW, &old);
    close(tty);
    free(output);
    write_final(o, cmd.data);
    free(cmd.data);
    return 0;
}

int main(int argc, char **argv) {
    Options opt;
    parse_args(argc, argv, &opt);

    char *initial = NULL;
    if (opt.in_file) initial = read_file_all(opt.in_file);
    else if (opt.def) initial = strdup(opt.def);
    else initial = strdup("");
    if (!initial) die_oom();

    if (!opt.no_isolation && !has_bwrap()) {
        printf("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode\n");
        free(initial);
        return 0;
    }

    int rc = interactive(&opt, initial);
    free(initial);
    return rc;
}
