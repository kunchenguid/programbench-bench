#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef enum { V_NULL, V_BOOL, V_NUM, V_STR, V_ARR, V_OBJ, V_UNDEF } Type;
typedef struct Val Val;
typedef struct { char *k; Val *v; } Pair;
struct Val {
    Type t;
    double num;
    int boolean;
    char *str;
    Val **items;
    int len, cap;
    Pair *pairs;
};

typedef struct { const char *s; size_t pos, len; char err[256]; } Parser;

static Val *val(Type t){ Val *v=calloc(1,sizeof(Val)); v->t=t; return v; }
static Val *vstr(const char *s){ Val *v=val(V_STR); v->str=strdup(s?s:""); return v; }
static Val *vnum(double d){ Val *v=val(V_NUM); v->num=d; return v; }
static Val *vbool(int b){ Val *v=val(V_BOOL); v->boolean=b; return v; }
static void arr_add(Val *a, Val *x){ if(a->len==a->cap){ a->cap=a->cap?a->cap*2:8; a->items=realloc(a->items,a->cap*sizeof(Val*)); } a->items[a->len++]=x; }
static void obj_add(Val *o, char *k, Val *x){ if(o->len==o->cap){ o->cap=o->cap?o->cap*2:8; o->pairs=realloc(o->pairs,o->cap*sizeof(Pair)); } o->pairs[o->len].k=k; o->pairs[o->len].v=x; o->len++; }
static Val *obj_get(Val *o, const char *k){ if(!o||o->t!=V_OBJ) return val(V_UNDEF); for(int i=0;i<o->len;i++) if(strcmp(o->pairs[i].k,k)==0) return o->pairs[i].v; return val(V_UNDEF); }

static void skip(Parser *p){ while(p->pos<p->len && isspace((unsigned char)p->s[p->pos])) p->pos++; }
static int eat(Parser*p,char c){ skip(p); if(p->s[p->pos]==c){p->pos++; return 1;} return 0; }
static void perr(Parser*p,const char*m){ if(!p->err[0]) snprintf(p->err,sizeof(p->err),"%s on line 1.",m); }

static char *parse_string(Parser*p){
    skip(p); if(p->s[p->pos]!='"'){ perr(p,"Expected string"); return strdup(""); }
    p->pos++; char *buf=malloc(1), tmp[8]; size_t n=0, cap=1; buf[0]=0;
    while(p->pos<p->len){
        unsigned char c=p->s[p->pos++];
        if(c=='"') break;
        if(c=='\\' && p->pos<p->len){
            c=p->s[p->pos++];
            if(c=='n') c='\n'; else if(c=='r') c='\r'; else if(c=='t') c='\t'; else if(c=='b') c='\b'; else if(c=='f') c='\f';
            else if(c=='u' && p->pos+4<=p->len){ memcpy(tmp,p->s+p->pos,4); tmp[4]=0; p->pos+=4; c='?'; }
        }
        if(n+2>cap){ cap*=2; buf=realloc(buf,cap); }
        buf[n++]=c; buf[n]=0;
    }
    return buf;
}
static Val *parse_value(Parser*p);
static Val *parse_array(Parser*p){
    Val *a=val(V_ARR); eat(p,'['); if(eat(p,']')) return a;
    while(p->pos<p->len){ arr_add(a,parse_value(p)); if(eat(p,']')) return a; if(!eat(p,',')){ perr(p,"Expected comma"); return a; } }
    perr(p,"Unexpected end"); return a;
}
static Val *parse_object(Parser*p){
    Val *o=val(V_OBJ); eat(p,'{'); if(eat(p,'}')) return o;
    while(p->pos<p->len){
        skip(p); if(p->s[p->pos]!='"'){ perr(p,"Expected object key to be a string"); return o; }
        char *k=parse_string(p); if(!eat(p,':')){ perr(p,"Expected colon"); free(k); return o; }
        obj_add(o,k,parse_value(p)); if(eat(p,'}')) return o; if(!eat(p,',')){ perr(p,"Expected comma"); return o; }
    }
    perr(p,"Unexpected end"); return o;
}
static Val *parse_value(Parser*p){
    skip(p); int c=p->s[p->pos];
    if(c=='{') return parse_object(p);
    if(c=='[') return parse_array(p);
    if(c=='"') return vstr(parse_string(p));
    if(!strncmp(p->s+p->pos,"true",4)){ p->pos+=4; return vbool(1); }
    if(!strncmp(p->s+p->pos,"false",5)){ p->pos+=5; return vbool(0); }
    if(!strncmp(p->s+p->pos,"null",4)){ p->pos+=4; return val(V_NULL); }
    if(c=='-'||isdigit(c)){ char *end; double d=strtod(p->s+p->pos,&end); p->pos=end-p->s; return vnum(d); }
    if(c) { char m[80]; snprintf(m,sizeof(m),"Unexpected character '%c'",c); perr(p,m); }
    return val(V_UNDEF);
}
static Val *parse_json(const char *s, char *err, size_t esz){
    Parser p={s,0,strlen(s),""}; Val *v=parse_value(&p); skip(&p);
    if(!p.err[0] && p.pos<p.len){ char m[80]; snprintf(m,sizeof(m),"Unexpected character '%c'",p.s[p.pos]); perr(&p,m); }
    if(p.err[0]){ snprintf(err,esz,"%s",p.err); return NULL; }
    return v;
}
static Val *parse_json_slurp(const char *s, char *err, size_t esz){
    Parser p={s,0,strlen(s),""}; Val *a=val(V_ARR);
    while(1){ skip(&p); if(p.pos>=p.len) break; arr_add(a,parse_value(&p)); if(p.err[0]){ snprintf(err,esz,"%s",p.err); return NULL; } }
    return a;
}

static char *read_all(FILE *f){ size_t cap=8192,n=0; char *b=malloc(cap+1); int c; while((c=fgetc(f))!=EOF){ if(n==cap){cap*=2;b=realloc(b,cap+1);} b[n++]=c; } b[n]=0; return b; }
static char *read_file(const char *path){ FILE*f=fopen(path,"rb"); if(!f) return NULL; char*b=read_all(f); fclose(f); return b; }
static int is_regular_file(const char *path){ struct stat st; return stat(path,&st)==0 && S_ISREG(st.st_mode); }

static void ind(int n){ for(int i=0;i<n;i++) putchar(' '); }
static int simple(Val*v){ if(!v) return 1; if(v->t==V_STR||v->t==V_NUM||v->t==V_BOOL||v->t==V_NULL||v->t==V_UNDEF) return 1; if(v->t==V_ARR){ if(v->len>6) return 0; for(int i=0;i<v->len;i++) if(!simple(v->items[i]) || v->items[i]->t==V_STR) return 0; return 1; } if(v->t==V_OBJ){ if(v->len>2) return 0; for(int i=0;i<v->len;i++) if(!simple(v->pairs[i].v) || v->pairs[i].v->t==V_STR) return 0; return 1; } return 0; }
static void print_json_str(const char*s){ putchar('"'); for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\') printf("\\%c",c); else if(c=='\n') putchar('\n'); else putchar(c); } putchar('"'); }
static void print_val(Val*v,int depth,int noinline,int top);
static void print_inline(Val*v){
    if(v->t==V_ARR){ printf("[ "); for(int i=0;i<v->len;i++){ if(i) printf(", "); if(simple(v->items[i])&&(v->items[i]->t==V_OBJ||v->items[i]->t==V_ARR)) print_inline(v->items[i]); else print_val(v->items[i],0,0,0); } printf(" ]"); }
    else if(v->t==V_OBJ){ printf("{ "); for(int i=0;i<v->len;i++){ if(i) printf(", "); print_json_str(v->pairs[i].k); printf(": "); print_val(v->pairs[i].v,0,0,0); } printf(" }"); }
    else print_val(v,0,0,0);
}
static void print_val(Val*v,int depth,int noinline,int top){
    if(!v||v->t==V_UNDEF){ printf("undefined"); return; }
    if(v->t==V_NULL) printf("null");
    else if(v->t==V_BOOL) printf(v->boolean?"true":"false");
    else if(v->t==V_NUM){ long long ll=(long long)v->num; if((double)ll==v->num) printf("%lld",ll); else printf("%g",v->num); }
    else if(v->t==V_STR){ if(top) printf("%s",v->str); else print_json_str(v->str); }
    else if(v->t==V_ARR){
        if(!top && !noinline && simple(v)){ print_inline(v); return; }
        printf("["); if(v->len) putchar('\n');
        for(int i=0;i<v->len;i++){ ind(depth+2); if(!noinline && simple(v->items[i]) && (v->items[i]->t==V_OBJ||v->items[i]->t==V_ARR)) print_inline(v->items[i]); else print_val(v->items[i],depth+2,noinline,0); if(i+1<v->len) putchar(','); putchar('\n'); }
        ind(depth); printf("]");
    } else if(v->t==V_OBJ){
        printf("{"); if(v->len) putchar('\n');
        for(int i=0;i<v->len;i++){ ind(depth+2); print_json_str(v->pairs[i].k); printf(": "); if(!noinline && simple(v->pairs[i].v) && v->pairs[i].v->t==V_ARR) print_inline(v->pairs[i].v); else print_val(v->pairs[i].v,depth+2,noinline,0); if(i+1<v->len) putchar(','); putchar('\n'); }
        ind(depth); printf("}");
    }
}

static Val *yaml_simple(const char *s){
    Val *o=val(V_OBJ); char *copy=strdup(s), *save=NULL, *line=strtok_r(copy,"\n",&save);
    while(line){ while(isspace((unsigned char)*line)) line++; if(*line && *line!='#'){ char *c=strchr(line,':'); if(c){ *c=0; char *k=strdup(line); char *x=c+1; while(isspace((unsigned char)*x)) x++; if(*x=='['){ char err[128]=""; Val*v=parse_json(x,err,sizeof(err)); obj_add(o,k,v?v:vstr(x)); } else if(isdigit((unsigned char)*x)||*x=='-') obj_add(o,k,vnum(strtod(x,NULL))); else if(!strcmp(x,"true")||!strcmp(x,"false")) obj_add(o,k,vbool(!strcmp(x,"true"))); else if(!strcmp(x,"null")) obj_add(o,k,val(V_NULL)); else obj_add(o,k,vstr(x)); } } line=strtok_r(NULL,"\n",&save); }
    free(copy); return o;
}
static Val *toml_simple(const char *s){
    Val *o=val(V_OBJ); char *copy=strdup(s), *save=NULL, *line=strtok_r(copy,"\n",&save);
    while(line){ while(isspace((unsigned char)*line)) line++; if(*line && *line!='#'){ char *eq=strchr(line,'='); if(eq){ *eq=0; char *k=line; char *e=k+strlen(k)-1; while(e>=k&&isspace((unsigned char)*e))*e--=0; char *x=eq+1; while(isspace((unsigned char)*x)) x++; if(*x=='"'){ Parser p={x,0,strlen(x),""}; obj_add(o,strdup(k),vstr(parse_string(&p))); } else if(*x=='['){ char err[128]=""; Val*v=parse_json(x,err,sizeof(err)); obj_add(o,strdup(k),v?v:vstr(x)); } else if(isdigit((unsigned char)*x)||*x=='-') obj_add(o,strdup(k),vnum(strtod(x,NULL))); else if(!strncmp(x,"true",4)||!strncmp(x,"false",5)) obj_add(o,strdup(k),vbool(!strncmp(x,"true",4))); } } line=strtok_r(NULL,"\n",&save); }
    free(copy); return o;
}

static Val *eval_path(Val *root, const char *e){
    if(!e||!*e) return root;
    if(!strcmp(e,".")||!strcmp(e,"this")||!strcmp(e,"x => x")||!strcmp(e,"x=>x")) return root;
    char *mapcall=strstr(e,".map(");
    if(mapcall){
        char prefix[256]; size_t n=(size_t)(mapcall-e); if(n>sizeof(prefix)-1)n=sizeof(prefix)-1; memcpy(prefix,e,n); prefix[n]=0;
        Val *base=eval_path(root,prefix);
        if(base && base->t==V_ARR){ Val *a=val(V_ARR); char op=0; double c=0; char *p=strstr(mapcall,"=>"); if(p){ p+=2; while(*p&&*p!='x')p++; if(*p=='x'){ p++; while(isspace((unsigned char)*p))p++; op=*p++; c=strtod(p,NULL); } } for(int j=0;j<base->len;j++){ if(base->items[j]->t==V_NUM && (op=='*'||op=='+')) arr_add(a,vnum(op=='*'?base->items[j]->num*c:base->items[j]->num+c)); else arr_add(a,base->items[j]); } return a; }
    }
    if(!strncmp(e,"this",4)) e+=4;
    if(e[0]!='.') return root;
    Val *cur=root; size_t i=0;
    while(e[i]){
        if(e[i]=='.'){ i++; char name[128]; int n=0; while(e[i]&&(isalnum((unsigned char)e[i])||e[i]=='_'||e[i]=='-')){ if(n<127) name[n++]=e[i]; i++; } name[n]=0; if(!strcmp(name,"length")&&cur->t==V_ARR) cur=vnum(cur->len); else if(n) cur=obj_get(cur,name); }
        else if(e[i]=='['){ i++; if(e[i]==']'){ while(e[i]&&e[i]!=']')i++; if(e[i])i++; continue; } int idx=atoi(e+i); while(e[i]&&e[i]!=']') i++; if(e[i]) i++; if(cur->t==V_ARR && idx>=0 && idx<cur->len) cur=cur->items[idx]; else cur=val(V_UNDEF); }
        else break;
    }
    return cur;
}

static void help(void){ puts("\n  fx 39.2.0\n    Terminal JSON viewer\n\n  Usage\n    fx data.json\n    fx data.json .field\n    curl ... | fx\n\n  Flags\n    -h, --help            print help\n    -v, --version         print version\n    --themes              print themes\n    --comp <shell>        print completion script\n    -r, --raw             treat input as a raw string\n    -s, --slurp           read all inputs into an array\n    --yaml                parse input as YAML\n    --toml                parse input as TOML\n    --strict              strict mode\n    --no-inline           disable inlining in output\n    --game-of-life        play the game of life\n\n  More info\n    https://fx.wtf\n\n  Author\n    Anton Medvedev <anton@medv.io>\n"); }
static void themes(void){ for(int i=0;i<9;i++) printf("export FX_THEME=\"%d\"\n{\n  \"string\": \"Fox jumps over the lazy dog\",\n  \"number\": 1234567890,\n  \"boolean\": true,\n  \"null\": null,\n  \"collapsed\": {\"preview\":...}\n}\n\n",i); }

int main(int argc,char**argv){
    int raw=0, yaml=0, toml=0, noinline=0, slurp=0; const char *expr=NULL, *file=NULL;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){ help(); return 0; }
        else if(!strcmp(argv[i],"-v")||!strcmp(argv[i],"--version")){ puts("39.2.0"); return 0; }
        else if(!strcmp(argv[i],"--themes")){ themes(); return 0; }
        else if(!strcmp(argv[i],"--comp")){ const char*s=i+1<argc?argv[++i]:""; if(!strcmp(s,"bash")) puts("complete -o filenames -C fx fx"); else if(!strcmp(s,"fish")) puts("complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'"); else if(!strcmp(s,"zsh")) puts("#compdef fx\n\n_fx() {\n    reply=(${(f)$(COMP_ZSH=\"${LBUFFER}\" fx)})\n}\ncompdef _fx fx"); else puts("unknown shell type"); return 0; }
        else if(!strcmp(argv[i],"-r")||!strcmp(argv[i],"--raw")) raw=1;
        else if(!strcmp(argv[i],"--yaml")) yaml=1;
        else if(!strcmp(argv[i],"--toml")) toml=1;
        else if(!strcmp(argv[i],"--no-inline")) noinline=1;
        else if(!strcmp(argv[i],"-s")||!strcmp(argv[i],"--slurp")) slurp=1;
        else if(!strcmp(argv[i],"--strict")) {}
        else if(!strcmp(argv[i],"--game-of-life")){ printf("\033[2J\033[?25l\033[H"); return 0; }
        else if(argv[i][0]=='.' || !strncmp(argv[i],"this",4) || strstr(argv[i],"=>")) expr=argv[i];
        else if(!file && is_regular_file(argv[i])) file=argv[i];
        else if(!expr) expr=argv[i];
        else expr=argv[i];
    }
    char *input=file?read_file(file):read_all(stdin); if(!input) input=strdup("");
    if(raw){ printf("%s",input); return 0; }
    int blank=1; for(char *bp=input; *bp; bp++) if(!isspace((unsigned char)*bp)){ blank=0; break; }
    if(blank) return 0;
    Val *root=NULL; char err[256]="";
    if(yaml) root=yaml_simple(input); else if(toml) root=toml_simple(input); else root=slurp?parse_json_slurp(input,err,sizeof(err)):parse_json(input,err,sizeof(err));
    if(!root){ fprintf(stderr,"%s\n",err); return 1; }
    Val *out=eval_path(root,expr?expr:"."); print_val(out,0,noinline,1); putchar('\n'); return 0;
}
