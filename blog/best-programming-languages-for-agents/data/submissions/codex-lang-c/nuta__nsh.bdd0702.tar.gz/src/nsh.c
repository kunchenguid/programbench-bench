#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

static const char *HELP =
    "nsh 0.4.2\n"
    "A command-line shell that focuses on performance and productivity.\n"
    "\n"
    "USAGE:\n"
    "    executable [FLAGS] [OPTIONS] [FILE]\n"
    "\n"
    "FLAGS:\n"
    "    -h, --help       Prints help information\n"
    "    -l, --login      Behave like a login shell\n"
    "        --norc       Don't load nshrc\n"
    "        --version    Print the version\n"
    "\n"
    "OPTIONS:\n"
    "    -c <command>        The command to be executed\n"
    "\n"
    "ARGS:\n"
    "    <FILE>    The file to be executed\n";

static const char *VERSION = "0.4.2\n";

static void die_errno(const char *what) {
    fprintf(stderr, "nsh: %s: %s\n", what, strerror(errno));
    exit(1);
}

static void clap_error(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fprintf(stderr, "\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n\nFor more information try --help\n");
    exit(1);
}

static bool file_exists(const char *path) {
    struct stat st;
    return path && stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

static char *join_path(const char *a, const char *b) {
    size_t alen = strlen(a), blen = strlen(b);
    bool slash = alen > 0 && a[alen - 1] == '/';
    char *out = malloc(alen + blen + (slash ? 1 : 2));
    if (!out) die_errno("malloc");
    sprintf(out, "%s%s%s", a, slash ? "" : "/", b);
    return out;
}

static char *find_rc(void) {
    const char *xdg = getenv("XDG_CONFIG_HOME");
    if (xdg && *xdg) {
        char *dir = join_path(xdg, "nsh");
        char *path = join_path(dir, "nshrc");
        free(dir);
        if (file_exists(path)) return path;
        free(path);
    }

    const char *home = getenv("HOME");
    if (home && *home) {
        char *path = join_path(home, ".nshrc");
        if (file_exists(path)) return path;
        free(path);
    }

    return NULL;
}

static void shell_quote(FILE *f, const char *s) {
    fputc('\'', f);
    for (; *s; s++) {
        if (*s == '\'') fputs("'\\''", f);
        else fputc(*s, f);
    }
    fputc('\'', f);
}

static char *make_temp_script(void) {
    char tmpl[] = "/tmp/nsh-script-XXXXXX";
    int fd = mkstemp(tmpl);
    if (fd < 0) die_errno("mkstemp");
    close(fd);
    return strdup(tmpl);
}

static int run_bash_script(const char *script, int extra_argc, char **extra_argv) {
    char **argv = calloc((size_t)extra_argc + 6, sizeof(char *));
    if (!argv) die_errno("calloc");
    int n = 0;
    argv[n++] = "bash";
    argv[n++] = "+B";
    argv[n++] = "-O";
    argv[n++] = "expand_aliases";
    argv[n++] = (char *)script;
    for (int i = 0; i < extra_argc; i++) argv[n++] = extra_argv[i];
    argv[n] = NULL;
    execvp("bash", argv);
    die_errno("exec bash");
    return 127;
}

static int exec_bash_c(const char *code, const char *arg0) {
    char *argv[] = {"bash", "+B", "-O", "expand_aliases", "-c", (char *)code, (char *)arg0, NULL};
    execvp("bash", argv);
    die_errno("exec bash");
    return 127;
}

static void write_prelude(FILE *f, bool norc) {
    fputs("shopt -s expand_aliases\nset +B\n", f);
    if (!norc) {
        char *rc = find_rc();
        if (rc) {
            fputs(". ", f);
            shell_quote(f, rc);
            fputc('\n', f);
            free(rc);
        }
    }
}

static int reject_unquoted_brace(const char *command) {
    bool single = false, dbl = false, esc = false;
    for (size_t i = 0; command[i]; i++) {
        char c = command[i];
        if (esc) {
            esc = false;
            continue;
        }
        if (c == '\\') {
            esc = true;
            continue;
        }
        if (!dbl && c == '\'') {
            single = !single;
            continue;
        }
        if (!single && c == '"') {
            dbl = !dbl;
            continue;
        }
        if (!single && !dbl && (c == '{' || c == '}')) {
            if (c == '{' && i > 0 && command[i - 1] == '$') {
                while (command[i] && command[i] != '}') i++;
                continue;
            }
            fprintf(stderr,
                    "nsh: parse error:  --> 1:%zu\n"
                    "  |\n"
                    "1 | %s\n"
                    "  | %*s^---\n"
                    "  |\n"
                    "  = expected EOI, word, redirect_direction, heredoc, and_or_list_sep, or compound_list_sep\n",
                    i + 1, command, (int)i, "");
            return 255;
        }
    }
    return 0;
}

static bool word_char(char c) {
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == ':' || c == '/';
}

static bool separator_char(char c) {
    return c == 0 || c == ' ' || c == '\t' || c == '\n' || c == ';' || c == '|' ||
           c == '&' || c == '<' || c == '>' || c == '(' || c == ')';
}

static void write_command_compat(FILE *f, const char *command) {
    bool single = false, dbl = false, esc = false;
    for (size_t i = 0; command[i]; i++) {
        char c = command[i];
        if (esc) {
            fputc(c, f);
            esc = false;
            continue;
        }
        if (c == '\\') {
            fputc(c, f);
            esc = true;
            continue;
        }
        if (!dbl && c == '\'') {
            single = !single;
            fputc(c, f);
            continue;
        }
        if (!single && c == '"') {
            dbl = !dbl;
            fputc(c, f);
            continue;
        }
        if (!single && !dbl && c == '$') {
            char prev = i == 0 ? 0 : command[i - 1];
            if (!separator_char(prev) && prev != '=') fputc(' ', f);
            fputc('$', f);
            if (command[i + 1] == '{') {
                i++;
                fputc('{', f);
                while (command[i + 1] && command[i + 1] != '}') fputc(command[++i], f);
                if (command[i + 1] == '}') {
                    i++;
                    fputc('}', f);
                }
            } else if ((command[i + 1] >= 'A' && command[i + 1] <= 'Z') ||
                       (command[i + 1] >= 'a' && command[i + 1] <= 'z') ||
                       command[i + 1] == '_') {
                while ((command[i + 1] >= 'A' && command[i + 1] <= 'Z') ||
                       (command[i + 1] >= 'a' && command[i + 1] <= 'z') ||
                       (command[i + 1] >= '0' && command[i + 1] <= '9') ||
                       command[i + 1] == '_') {
                    fputc(command[++i], f);
                }
            } else if (command[i + 1]) {
                fputc(command[++i], f);
            }
            if (word_char(command[i + 1])) fputc(' ', f);
            continue;
        }
        fputc(c, f);
        if (c == ';') fputc('\n', f);
    }
}

static int run_command(const char *command, bool norc) {
    int brace_status = reject_unquoted_brace(command);
    if (brace_status) return brace_status;

    char *script = make_temp_script();
    FILE *f = fopen(script, "w");
    if (!f) die_errno(script);
    write_prelude(f, norc);

    write_command_compat(f, command);
    size_t len = strlen(command);
    if (len == 0 || command[len - 1] != '\n') fputc('\n', f);
    fclose(f);
    chmod(script, 0700);
    return run_bash_script(script, 0, NULL);
}

static int run_file(const char *path, bool norc) {
    char *rc = norc ? NULL : find_rc();
    char *code = NULL;
    size_t len = 0;
    FILE *mem = open_memstream(&code, &len);
    if (!mem) die_errno("open_memstream");
    fputs("shopt -s expand_aliases; set +B; ", mem);
    if (rc) {
        fputs(". ", mem);
        shell_quote(mem, rc);
        free(rc);
        fputs("; ", mem);
    }
    fputs(". \"$0\"", mem);
    fclose(mem);
    return exec_bash_c(code, path);
}

static int run_interactive(bool norc, bool login) {
    if (!isatty(STDOUT_FILENO)) fprintf(stderr, "nsh: warning: stdout is not a tty\n");
    if (!isatty(STDIN_FILENO)) return 0;

    char *script = make_temp_script();
    FILE *f = fopen(script, "w");
    if (!f) die_errno(script);
    write_prelude(f, norc);
    if (isatty(STDIN_FILENO)) {
        fputs("exec bash -i\n", f);
    } else {
        fputs("cat | bash +B -O expand_aliases\n", f);
    }
    fclose(f);
    chmod(script, 0700);

    if (login) {
        char *argv[] = {"bash", "--login", "+B", "-O", "expand_aliases", script, NULL};
        execvp("bash", argv);
        die_errno("exec bash");
    }
    return run_bash_script(script, 0, NULL);
}

int main(int argc, char **argv) {
    bool norc = false;
    bool login = false;
    const char *command = NULL;
    const char *file = NULL;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
            fputs(HELP, stdout);
            return 0;
        } else if (strcmp(a, "--version") == 0) {
            fputs(VERSION, stdout);
            return 0;
        } else if (strcmp(a, "--norc") == 0) {
            norc = true;
        } else if (strcmp(a, "-l") == 0 || strcmp(a, "--login") == 0) {
            login = true;
        } else if (strcmp(a, "-c") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "error: The argument '-c <command>' requires a value but none was supplied\n\nUSAGE:\n    executable -c <command>\n\nFor more information try --help\n");
                return 1;
            }
            command = argv[++i];
        } else if (strncmp(a, "-c", 2) == 0 && a[2] != '\0') {
            command = a + 2;
        } else if (a[0] == '-') {
            clap_error("Found argument '%s' which wasn't expected, or isn't valid in this context", a);
        } else if (!file) {
            file = a;
        } else {
            clap_error("Found argument '%s' which wasn't expected, or isn't valid in this context", a);
        }
    }

    if (command && file) {
        clap_error("Found argument '%s' which wasn't expected, or isn't valid in this context", file);
    }
    if (command) return run_command(command, norc);
    if (file) return run_file(file, norc);
    return run_interactive(norc, login);
}
