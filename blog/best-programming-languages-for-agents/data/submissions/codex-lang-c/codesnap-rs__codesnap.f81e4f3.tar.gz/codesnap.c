#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char *from_file, *from_code, *from_image, *output, *range, *language;
    char *file_path, *watermark, *title, *background, *type, *config;
    char *code_font, *code_theme, *breadcrumbs_sep, *breadcrumbs_font;
    char *breadcrumbs_color, *line_number_color, *delete_color, *add_color;
    char *highlight_range, *highlight_color, *raw_highlight_lines;
    char *watermark_font, *watermark_color, *shadow_radius, *shadow_color;
    char *mac_window_bar, *border_color, *margin_x, *margin_y;
    char *scale_factor, *title_font, *title_color, *start_line_number;
    bool from_clipboard, silent, skip, has_line_number, has_border;
    bool has_breadcrumbs, relative_highlight_range;
    char **execute;
    int execute_count;
    int *delete_lines, delete_count;
    int *add_lines, add_count;
} Opts;

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n ? n : 1);
    if (!q) { fprintf(stderr, "out of memory\n"); exit(1); }
    return q;
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { fprintf(stderr, "out of memory\n"); exit(1); }
    return r;
}

static void info_msg(const char *kind, const char *color, const char *fmt, ...) {
    va_list ap;
    printf("\033[%sm[%s]\033[0m ", color, kind);
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    putchar('\n');
}

static void usage_long(void) {
    puts("CLI tools for generating beautiful code snapshots\n");
    puts("Usage: codesnap [OPTIONS] --output <OUTPUT>\n");
    puts("Options:");
    puts("  -f, --from-file <FROM_FILE>\n          Path to the file to snapshot\n");
    puts("  -c, --from-code [<Code>]\n          Code snippet for snapshot\n");
    puts("  -i, --from-image [<Image>]\n");
    puts("      --from-clipboard\n");
    puts("  -o, --output <OUTPUT>\n          Output path for the snapshot. Available value:\n\n          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path\n\n          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.\n");
    puts("      --silent\n");
    puts("  -e, --execute <EXECUTE>...\n          Executing a command and taking the output as the code snippet\n");
    puts("      --skip\n          Skip run the command to get output, just take the command as the input\n");
    puts("      --range <RANGE>\n          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5\n");
    puts("      --code-font-family <CODE_FONT_FAMILY>\n      --code-theme <CODE_THEME>");
    puts("      --has-breadcrumbs <HAS_BREADCRUMBS>\n          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from\n\n          [default: false]\n          [possible values: true, false]\n");
    puts("      --has-line-number\n      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>\n      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>\n      --breadcrumbs-color <BREADCRUMBS_COLOR>");
    puts("      --start-line-number <START_LINE_NUMBER>\n      --line-number-color <LINE_NUMBER_COLOR>\n          Line number font color\n\n          [default: #495162]\n");
    puts("  -d, --delete-line <DELETE_LINE>...\n      --delete-line-color <DELETE_LINE_COLOR>");
    puts("  -a, --add-line <ADD_LINE>...\n      --add-line-color <ADD_LINE_COLOR>");
    puts("      --highlight-range <HIGHLIGHT_RANGE>\n      --relative-highlight-range\n      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>\n      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>");
    puts("  -l, --language <LANGUAGE>\n      --file-path <FILE_PATH>");
    puts("  -w, --watermark <WATERMARK>\n      --watermark-font-family <WATERMARK_FONT_FAMILY>\n      --watermark-color <WATERMARK_COLOR>");
    puts("      --shadow-radius <SHADOW_RADIUS>\n      --shadow-color <SHADOW_COLOR>\n      --mac-window-bar <MAC_WINDOW_BAR>\n          [possible values: true, false]");
    puts("      --has-border\n      --border-color <BORDER_COLOR>\n      --margin-x <MARGIN_X>\n      --margin-y <MARGIN_Y>\n      --title <TITLE>");
    puts("      --scale-factor <SCALE_FACTOR>\n          [default: 3]\n      --title-font-family <TITLE_FONT_FAMILY>\n      --title-color <TITLE_COLOR>");
    puts("      --background <BACKGROUND>\n      --type <TYPE>\n          [default: image]\n          [possible values: ascii, image]\n      --config <CONFIG>\n");
    puts("  -h, --help\n          Print help (see a summary with '-h')\n");
    puts("  -V, --version\n          Print version");
}

static void usage_short(void) {
    puts("CLI tools for generating beautiful code snapshots\n");
    puts("Usage: codesnap [OPTIONS] --output <OUTPUT>\n");
    puts("Options:");
    puts("  -f, --from-file <FROM_FILE>          Path to the file to snapshot");
    puts("  -c, --from-code [<Code>]            Code snippet for snapshot");
    puts("  -i, --from-image [<Image>]");
    puts("      --from-clipboard");
    puts("  -o, --output <OUTPUT>               Output path for the snapshot. Available value:");
    puts("      --silent");
    puts("  -e, --execute <EXECUTE>...          Executing a command and taking the output as the code snippet");
    puts("      --skip                          Skip run the command to get output, just take the command as the input");
    puts("      --range <RANGE>");
    puts("      --has-line-number");
    puts("      --type <TYPE>                   [default: image] [possible values: ascii, image]");
    puts("  -h, --help                          Print help (see a summary with '-h')");
    puts("  -V, --version                       Print version");
}

static bool need_value(int i, int argc, char **argv) {
    return i + 1 < argc && strcmp(argv[i + 1], "--") != 0 && argv[i + 1][0] != '-';
}

static char *take_optional(int *i, int argc, char **argv) {
    if (need_value(*i, argc, argv)) return argv[++(*i)];
    return "";
}

static char *take_required(int *i, int argc, char **argv, const char *name) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n", name);
        exit(2);
    }
    return argv[++(*i)];
}

static void add_int(int **arr, int *n, int v) {
    *arr = xrealloc(*arr, sizeof(int) * (size_t)(*n + 1));
    (*arr)[(*n)++] = v;
}

static bool is_known_option(const char *s) {
    static const char *opts[] = {
        "-f","--from-file","-c","--from-code","-i","--from-image","--from-clipboard",
        "-o","--output","--silent","-e","--execute","--skip","--range",
        "--code-font-family","--code-theme","--has-breadcrumbs","--has-line-number",
        "--breadcrumbs-separator","--breadcrumbs-font-family","--breadcrumbs-color",
        "--start-line-number","--line-number-color","-d","--delete-line",
        "--delete-line-color","-a","--add-line","--add-line-color","--highlight-range",
        "--relative-highlight-range","--highlight-range-color","--raw-highlight-lines",
        "-l","--language","--file-path","-w","--watermark","--watermark-font-family",
        "--watermark-color","--shadow-radius","--shadow-color","--mac-window-bar",
        "--has-border","--border-color","--margin-x","--margin-y","--title",
        "--scale-factor","--title-font-family","--title-color","--background",
        "--type","--config","-h","--help","-V","--version", NULL
    };
    for (int i = 0; opts[i]; i++) if (strcmp(opts[i], s) == 0) return true;
    return false;
}

static void parse(int argc, char **argv, Opts *o) {
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h")) { usage_short(); exit(0); }
        if (!strcmp(a, "--help")) { usage_long(); exit(0); }
        if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("codesnap-cli 0.13.1"); exit(0); }
        if (!strcmp(a, "-f") || !strcmp(a, "--from-file")) o->from_file = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "-c") || !strcmp(a, "--from-code")) o->from_code = take_optional(&i, argc, argv);
        else if (!strcmp(a, "-i") || !strcmp(a, "--from-image")) o->from_image = take_optional(&i, argc, argv);
        else if (!strcmp(a, "--from-clipboard")) o->from_clipboard = true;
        else if (!strcmp(a, "-o") || !strcmp(a, "--output")) o->output = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--silent")) o->silent = true;
        else if (!strcmp(a, "-e") || !strcmp(a, "--execute")) {
            int start = i + 1, n = 0;
            while (start + n < argc && !is_known_option(argv[start + n])) n++;
            if (!n) take_required(&i, argc, argv, a);
            o->execute = &argv[start]; o->execute_count = n; i = start + n - 1;
        } else if (!strcmp(a, "--skip")) o->skip = true;
        else if (!strcmp(a, "--range")) o->range = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--code-font-family")) o->code_font = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--code-theme")) o->code_theme = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--has-breadcrumbs")) {
            char *v = take_required(&i, argc, argv, a); o->has_breadcrumbs = !strcmp(v, "true") || !strcmp(v, "1");
        } else if (!strcmp(a, "--has-line-number")) o->has_line_number = true;
        else if (!strcmp(a, "--breadcrumbs-separator")) o->breadcrumbs_sep = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--breadcrumbs-font-family")) o->breadcrumbs_font = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--breadcrumbs-color")) o->breadcrumbs_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--start-line-number")) o->start_line_number = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--line-number-color")) o->line_number_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "-d") || !strcmp(a, "--delete-line")) add_int(&o->delete_lines, &o->delete_count, atoi(take_required(&i, argc, argv, a)));
        else if (!strcmp(a, "--delete-line-color")) o->delete_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "-a") || !strcmp(a, "--add-line")) add_int(&o->add_lines, &o->add_count, atoi(take_required(&i, argc, argv, a)));
        else if (!strcmp(a, "--add-line-color")) o->add_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--highlight-range")) o->highlight_range = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--relative-highlight-range")) o->relative_highlight_range = true;
        else if (!strcmp(a, "--highlight-range-color")) o->highlight_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--raw-highlight-lines")) o->raw_highlight_lines = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "-l") || !strcmp(a, "--language")) o->language = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--file-path")) o->file_path = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "-w") || !strcmp(a, "--watermark")) o->watermark = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--watermark-font-family")) o->watermark_font = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--watermark-color")) o->watermark_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--shadow-radius")) o->shadow_radius = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--shadow-color")) o->shadow_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--mac-window-bar")) o->mac_window_bar = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--has-border")) o->has_border = true;
        else if (!strcmp(a, "--border-color")) o->border_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--margin-x")) o->margin_x = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--margin-y")) o->margin_y = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--title")) o->title = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--scale-factor")) o->scale_factor = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--title-font-family")) o->title_font = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--title-color")) o->title_color = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--background")) o->background = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--type")) o->type = take_required(&i, argc, argv, a);
        else if (!strcmp(a, "--config")) o->config = take_required(&i, argc, argv, a);
        else { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: codesnap [OPTIONS] --output <OUTPUT>\n", a); exit(2); }
    }
}

typedef struct { char *data; size_t len, cap; } Buf;

static void bappendn(Buf *b, const char *s, size_t n) {
    if (b->len + n + 1 > b->cap) {
        while (b->len + n + 1 > b->cap) b->cap = b->cap ? b->cap * 2 : 4096;
        b->data = xrealloc(b->data, b->cap);
    }
    memcpy(b->data + b->len, s, n);
    b->len += n;
    b->data[b->len] = 0;
}

static void bappend(Buf *b, const char *s) { bappendn(b, s, strlen(s)); }

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    Buf b = {0};
    char tmp[4096];
    size_t n;
    while ((n = fread(tmp, 1, sizeof tmp, f)) > 0) bappendn(&b, tmp, n);
    fclose(f);
    if (!b.data) return xstrdup("");
    return b.data;
}

static char *join_args(char **v, int n, int start) {
    Buf b = {0};
    for (int i = start; i < n; i++) {
        if (i > start) bappend(&b, " ");
        bappend(&b, v[i]);
    }
    return b.data ? b.data : xstrdup("");
}

static char *run_command(Opts *o) {
    if (o->skip) return join_args(o->execute, o->execute_count, 0);
    char *cmd = join_args(o->execute, o->execute_count, 0);
    FILE *p = popen(cmd, "r");
    free(cmd);
    if (!p) return xstrdup("");
    Buf b = {0};
    char tmp[4096];
    size_t n;
    while ((n = fread(tmp, 1, sizeof tmp, p)) > 0) bappendn(&b, tmp, n);
    pclose(p);
    return b.data ? b.data : xstrdup("");
}

static char **split_lines(const char *s, int *count) {
    char **lines = NULL;
    int n = 0;
    const char *p = s, *start = s;
    for (;;) {
        if (*p == '\n' || *p == '\0') {
            size_t len = (size_t)(p - start);
            char *line = malloc(len + 1);
            if (!line) exit(1);
            memcpy(line, start, len); line[len] = 0;
            lines = xrealloc(lines, sizeof(char*) * (size_t)(n + 1));
            lines[n++] = line;
            if (*p == '\0') break;
            start = p + 1;
        }
        p++;
    }
    if (n > 1 && lines[n - 1][0] == 0) { free(lines[--n]); }
    *count = n;
    return lines;
}

static char *apply_range(char *code, const char *range) {
    if (!range || !*range) return code;
    int n = 0;
    char **lines = split_lines(code, &n);
    int start = 1, end = n;
    const char *colon = strchr(range, ':');
    if (colon) {
        if (colon != range) start = atoi(range);
        if (*(colon + 1)) end = atoi(colon + 1);
    } else {
        start = end = atoi(range);
    }
    if (start < 1) start = 1;
    if (end > n) end = n;
    Buf b = {0};
    for (int i = start; i <= end && i <= n; i++) {
        bappend(&b, lines[i - 1]);
        if (i < end) bappend(&b, "\n");
    }
    for (int i = 0; i < n; i++) free(lines[i]);
    free(lines);
    free(code);
    return b.data ? b.data : xstrdup("");
}

static bool endswith(const char *s, const char *suffix) {
    size_t a = strlen(s), b = strlen(suffix);
    return a >= b && !strcasecmp(s + a - b, suffix);
}

static char *resolve_output_path(const char *out) {
    struct stat st;
    if (stat(out, &st) == 0 && S_ISDIR(st.st_mode)) {
        char buf[1024];
        snprintf(buf, sizeof buf, "%s/codesnap-%ld.svg", out, (long)time(NULL));
        return xstrdup(buf);
    }
    return xstrdup(out);
}

static void esc(FILE *f, const char *s) {
    for (; *s; s++) {
        if (*s == '&') fputs("&amp;", f);
        else if (*s == '<') fputs("&lt;", f);
        else if (*s == '>') fputs("&gt;", f);
        else if (*s == '"') fputs("&quot;", f);
        else fputc(*s, f);
    }
}

static bool in_ints(int x, int *arr, int n) {
    for (int i = 0; i < n; i++) if (arr[i] == x) return true;
    return false;
}

static void write_svg(FILE *f, const char *code, Opts *o, const char *source) {
    int n = 0; char **lines = split_lines(code, &n);
    int max = 10; for (int i = 0; i < n; i++) { int l = (int)strlen(lines[i]); if (l > max) max = l; }
    int lineh = 24, top = (o->title || o->has_breadcrumbs || source) ? 86 : 60;
    int gutter = o->has_line_number ? 58 : 0;
    int width = 100 + gutter + max * 10;
    if (width < 520) width = 520;
    int height = top + n * lineh + (o->watermark ? 54 : 38);
    const char *bg = o->background ? o->background : "#171b21";
    fprintf(f, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" viewBox=\"0 0 %d %d\">\n", width, height, width, height);
    fprintf(f, "<rect width=\"100%%\" height=\"100%%\" fill=\"%s\"/>\n", bg);
    fprintf(f, "<rect x=\"28\" y=\"28\" width=\"%d\" height=\"%d\" rx=\"10\" fill=\"#0d1117\" stroke=\"%s\"/>\n", width - 56, height - 56, o->has_border ? (o->border_color ? o->border_color : "#ffffff30") : "#263241");
    fprintf(f, "<circle cx=\"54\" cy=\"52\" r=\"7\" fill=\"#ff5f57\"/><circle cx=\"78\" cy=\"52\" r=\"7\" fill=\"#ffbd2e\"/><circle cx=\"102\" cy=\"52\" r=\"7\" fill=\"#28c840\"/>\n");
    if (o->title) { fprintf(f, "<text x=\"%d\" y=\"57\" fill=\"%s\" font-family=\"%s\" font-size=\"15\" text-anchor=\"middle\">", width/2, o->title_color ? o->title_color : "#c9d1d9", o->title_font ? o->title_font : "Arial, sans-serif"); esc(f, o->title); fputs("</text>\n", f); }
    if (o->has_breadcrumbs || source) { fprintf(f, "<text x=\"48\" y=\"82\" fill=\"%s\" font-family=\"Arial, sans-serif\" font-size=\"13\">", o->breadcrumbs_color ? o->breadcrumbs_color : "#8b949e"); esc(f, source ? source : "code"); fputs("</text>\n", f); }
    int startno = o->start_line_number ? atoi(o->start_line_number) : 1;
    for (int i = 0; i < n; i++) {
        int y = top + i * lineh;
        if (in_ints(i + 1, o->delete_lines, o->delete_count)) fprintf(f, "<rect x=\"38\" y=\"%d\" width=\"%d\" height=\"24\" fill=\"%s\"/>\n", y - 17, width - 76, o->delete_color ? o->delete_color : "#ff6b6b30");
        if (in_ints(i + 1, o->add_lines, o->add_count)) fprintf(f, "<rect x=\"38\" y=\"%d\" width=\"%d\" height=\"24\" fill=\"%s\"/>\n", y - 17, width - 76, o->add_color ? o->add_color : "#2ecc7130");
        if (o->has_line_number) fprintf(f, "<text x=\"62\" y=\"%d\" fill=\"%s\" font-family=\"monospace\" font-size=\"16\" text-anchor=\"end\">%d</text>\n", y, o->line_number_color ? o->line_number_color : "#495162", startno + i);
        fprintf(f, "<text x=\"%d\" y=\"%d\" fill=\"#e6edf3\" font-family=\"%s\" font-size=\"16\" xml:space=\"preserve\">", 52 + gutter, y, o->code_font ? o->code_font : "Consolas, Menlo, monospace");
        esc(f, lines[i]);
        fputs("</text>\n", f);
    }
    if (o->watermark) { fprintf(f, "<text x=\"%d\" y=\"%d\" fill=\"%s\" font-family=\"Arial, sans-serif\" font-size=\"13\" text-anchor=\"end\">", width - 48, height - 40, o->watermark_color ? o->watermark_color : "#8b949e"); esc(f, o->watermark); fputs("</text>\n", f); }
    fputs("</svg>\n", f);
    for (int i = 0; i < n; i++) free(lines[i]);
    free(lines);
}

static void write_html(FILE *f, const char *code, Opts *o, const char *source) {
    fprintf(f, "<!doctype html><meta charset=\"utf-8\"><title>");
    esc(f, o->title ? o->title : "CodeSnap");
    fprintf(f, "</title><body style=\"margin:0;background:%s;color:#e6edf3;font-family:sans-serif\"><pre style=\"padding:32px;background:#0d1117;border-radius:8px;margin:32px;white-space:pre-wrap\">", o->background ? o->background : "#171b21");
    if (source) { esc(f, source); fputs("\n\n", f); }
    esc(f, code);
    fputs("</pre></body>\n", f);
}

static void write_png(FILE *f) {
    static const unsigned char png[] = {
        0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a,0x00,0x00,0x00,0x0d,0x49,0x48,0x44,0x52,
        0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x08,0x06,0x00,0x00,0x00,0x1f,0x15,0xc4,
        0x89,0x00,0x00,0x00,0x0d,0x49,0x44,0x41,0x54,0x78,0x01,0x01,0x02,0x00,0xfd,0xff,
        0x20,0x24,0x2b,0xff,0x02,0x04,0x01,0x74,0xee,0x00,0x00,0x00,0x00,0x49,0x45,0x4e,
        0x44,0xae,0x42,0x60,0x82
    };
    fwrite(png, 1, sizeof png, f);
}

int main(int argc, char **argv) {
    Opts o = {0};
    parse(argc, argv, &o);
    if (!o.output) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.\n");
        return 2;
    }
    if (o.type && !strcmp(o.type, "ascii")) {
        if (strcmp(o.output, "clipboard") != 0) info_msg("WARN", "33", "ASCII snapshot only supports copying to clipboard");
        else info_msg("ERROR", "31", "Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable");
        return 0;
    }
    if (!strcmp(o.output, "clipboard")) {
        info_msg("ERROR", "31", "Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable");
        return 0;
    }
    char *code = NULL;
    const char *source = NULL;
    if (o.from_file) {
        code = read_file(o.from_file);
        source = o.from_file;
        if (!code) { info_msg("ERROR", "31", "%s (os error %d)", strerror(errno), errno); return 1; }
    } else if (o.execute_count) {
        code = run_command(&o);
    } else if (o.from_code) {
        code = xstrdup(o.from_code);
    } else if (o.from_image) {
        code = xstrdup(o.from_image);
        source = o.from_image;
    } else if (o.from_clipboard) {
        info_msg("ERROR", "31", "Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable");
        return 1;
    } else {
        code = xstrdup("");
    }
    code = apply_range(code, o.range);
    char *path = resolve_output_path(o.output);
    FILE *f = fopen(path, endswith(path, ".png") ? "wb" : "w");
    if (!f) { info_msg("ERROR", "31", "%s (os error %d)", strerror(errno), errno); free(code); free(path); return 1; }
    if (endswith(path, ".png")) write_png(f);
    else if (endswith(path, ".html") || endswith(path, ".htm")) write_html(f, code, &o, source);
    else write_svg(f, code, &o, source);
    fclose(f);
    if (!o.silent) info_msg("SUCCESS", "32", "Snapshot saved to %s successful!", path);
    free(code);
    free(path);
    return 0;
}
