#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int streq(const char *a, const char *b) { return strcmp(a, b) == 0; }

static void root_help_short(void) {
    puts("A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)\n");
    puts("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n");
    puts("Commands:");
    puts("  history   Show session history");
    puts("  stats     Show analytics");
    puts("  export    Export session data");
    puts("  cache     Manage challenge cache");
    puts("  repo      Manage repositories");
    puts("  trending  Select and practice with trending repositories from GitHub");
    puts("  help      Print this message or the help of the given subcommand(s)\n");
    puts("Arguments:");
    puts("  [REPO_PATH]  Repository path to extract code from\n");
    puts("Options:");
    puts("      --repo <REPO>    GitHub repository URL or path to clone and play with");
    puts("      --langs <LANGS>  Filter by programming languages (comma-separated)");
    puts("  -h, --help           Print help (see more with '--help')");
    puts("  -V, --version        Print version");
}

static void root_help_long(void) {
    puts("GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. \n");
    puts("Examples:");
    puts("  gittype                           # Use current directory");
    puts("  gittype /path/to/repo             # Use specific repository");
    puts("  gittype --repo owner/repo         # Clone and use GitHub repository");
    puts("  gittype --langs rust,python       # Filter by languages\n");
    puts("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n");
    puts("Commands:");
    puts("  history   Show session history");
    puts("  stats     Show analytics");
    puts("  export    Export session data");
    puts("  cache     Manage challenge cache");
    puts("  repo      Manage repositories");
    puts("  trending  Select and practice with trending repositories from GitHub");
    puts("  help      Print this message or the help of the given subcommand(s)\n");
    puts("Arguments:");
    puts("  [REPO_PATH]");
    puts("          Repository path to extract code from\n");
    puts("Options:");
    puts("      --repo <REPO>");
    puts("          GitHub repository URL or path to clone and play with. Supports formats:");
    puts("            - owner/repo");
    puts("            - https://github.com/owner/repo");
    puts("            - git@github.com:owner/repo.git\n");
    puts("      --langs <LANGS>");
    puts("          Filter by programming languages (comma-separated). Supported languages:");
    puts("            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig");
    puts("            Example: --langs rust,python,typescript\n");
    puts("  -h, --help");
    puts("          Print help (see a summary with '-h')\n");
    puts("  -V, --version");
    puts("          Print version");
}

static void cache_help(void) {
    puts("Manage challenge cache\n");
    puts("Usage: executable cache <COMMAND>\n");
    puts("Commands:");
    puts("  stats  Show cache statistics");
    puts("  clear  Clear all cached challenges");
    puts("  list   List cached repository keys");
    puts("  help   Print this message or the help of the given subcommand(s)\n");
    puts("Options:");
    puts("  -h, --help  Print help");
}

static void repo_help(void) {
    puts("Manage repositories\n");
    puts("Usage: executable repo <COMMAND>\n");
    puts("Commands:");
    puts("  list   List all cached repositories");
    puts("  clear  Clear all cached repositories");
    puts("  play   Play a cached repository interactively");
    puts("  help   Print this message or the help of the given subcommand(s)\n");
    puts("Options:");
    puts("  -h, --help  Print help");
}

static void trending_help_long(void) {
    puts("Select and practice with trending repositories from GitHub\n");
    puts("Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]\n");
    puts("Arguments:");
    puts("  [LANGUAGE]");
    puts("          Programming language to filter trending repositories.");
    puts("          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig\n");
    puts("  [REPO_NAME]");
    puts("          Specific repository name to select from trending list\n");
    puts("Options:");
    puts("      --period <PERIOD>");
    puts("          Time period for trending (daily, weekly, monthly)");
    puts("          ");
    puts("          [default: daily]\n");
    puts("  -h, --help");
    puts("          Print help (see a summary with '-h')");
}

static void trending_help_short(void) {
    puts("Select and practice with trending repositories from GitHub\n");
    puts("Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]\n");
    puts("Arguments:");
    puts("  [LANGUAGE]   Programming language to filter trending repositories");
    puts("  [REPO_NAME]  Specific repository name to select from trending list\n");
    puts("Options:");
    puts("      --period <PERIOD>  Time period for trending (daily, weekly, monthly) [default: daily]");
    puts("  -h, --help             Print help (see more with '--help')");
}

static void export_help(void) {
    puts("Export session data\n");
    puts("Usage: executable export [OPTIONS]\n");
    puts("Options:");
    puts("      --format <FORMAT>  Export format [default: json]");
    puts("      --output <OUTPUT>  Output file path");
    puts("  -h, --help             Print help");
}

static int simple_help(const char *name) {
    if (streq(name, "history")) {
        puts("Show session history\n\nUsage: executable history\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "stats")) {
        puts("Show analytics\n\nUsage: executable stats\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "cache stats")) {
        puts("Show cache statistics\n\nUsage: executable cache stats\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "cache clear")) {
        puts("Clear all cached challenges\n\nUsage: executable cache clear\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "cache list")) {
        puts("List cached repository keys\n\nUsage: executable cache list\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "repo list")) {
        puts("List all cached repositories\n\nUsage: executable repo list\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "repo play")) {
        puts("Play a cached repository interactively\n\nUsage: executable repo play\n\nOptions:\n  -h, --help  Print help");
    } else if (streq(name, "repo clear")) {
        puts("Clear all cached repositories\n\nUsage: executable repo clear [OPTIONS]\n\nOptions:\n      --force  Force clear without confirmation\n  -h, --help   Print help");
    }
    return 0;
}

static int unexpected_root(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    if (arg[0] == '-' && arg[1] == '-')
        fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fputs("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n\nFor more information, try '--help'.\n", stderr);
    return 2;
}

static int unexpected_cmd(const char *cmd, const char *usage, const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: %s\n\nFor more information, try '--help'.\n", arg, usage);
    (void)cmd;
    return 2;
}

static int unrecognized_sub(const char *sub, const char *usage) {
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: %s\n\nFor more information, try '--help'.\n", sub, usage);
    return 2;
}

static int missing_value(const char *opt, const char *meta) {
    fprintf(stderr, "error: a value is required for '%s <%s>' but none was supplied\n\nFor more information, try '--help'.\n", opt, meta);
    return 2;
}

static char *home_path(const char *suffix) {
    const char *home = getenv("HOME");
    if (!home) home = ".";
    size_t n = strlen(home) + strlen(suffix) + 2;
    char *p = malloc(n);
    if (!p) exit(1);
    snprintf(p, n, "%s/%s", home, suffix);
    return p;
}

static long file_size(const char *path) {
    struct stat st;
    if (stat(path, &st) == 0) return (long)st.st_size;
    return 0;
}

static int handle_cache(int argc, char **argv, int i) {
    if (i >= argc || streq(argv[i], "-h") || streq(argv[i], "--help") || streq(argv[i], "help")) {
        cache_help();
        return i >= argc ? 2 : 0;
    }
    if (streq(argv[i], "stats")) {
        if (i + 1 < argc && (streq(argv[i+1], "-h") || streq(argv[i+1], "--help"))) return simple_help("cache stats");
        if (i + 1 < argc) return unexpected_cmd("cache stats", "executable cache stats", argv[i+1]);
        char *db = home_path(".gittype/gittype.db");
        printf("Challenge Cache Statistics:\n  Cached repositories: 0\n  Total size: %ld bytes\n", file_size(db));
        free(db);
        return 0;
    }
    if (streq(argv[i], "list")) {
        if (i + 1 < argc && (streq(argv[i+1], "-h") || streq(argv[i+1], "--help"))) return simple_help("cache list");
        if (i + 1 < argc) return unexpected_cmd("cache list", "executable cache list", argv[i+1]);
        puts("No cached challenges found.");
        return 0;
    }
    if (streq(argv[i], "clear")) {
        if (i + 1 < argc && (streq(argv[i+1], "-h") || streq(argv[i+1], "--help"))) return simple_help("cache clear");
        if (i + 1 < argc) return unexpected_cmd("cache clear", "executable cache clear", argv[i+1]);
        puts("No cached challenges directory found.");
        return 0;
    }
    return unrecognized_sub(argv[i], "executable cache <COMMAND>");
}

static int pseudo_tui_error(void) {
    puts("💾 Error details written to: gittype_error_20260601_000000.log");
    puts("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)");
    return 1;
}

static int handle_repo(int argc, char **argv, int i) {
    if (i >= argc || streq(argv[i], "-h") || streq(argv[i], "--help") || streq(argv[i], "help")) {
        repo_help();
        return i >= argc ? 2 : 0;
    }
    if (streq(argv[i], "list")) {
        if (i + 1 < argc && (streq(argv[i+1], "-h") || streq(argv[i+1], "--help"))) return simple_help("repo list");
        if (i + 1 < argc) return unexpected_cmd("repo list", "executable repo list", argv[i+1]);
        return pseudo_tui_error();
    }
    if (streq(argv[i], "play")) {
        if (i + 1 < argc && (streq(argv[i+1], "-h") || streq(argv[i+1], "--help"))) return simple_help("repo play");
        if (i + 1 < argc) return unexpected_cmd("repo play", "executable repo play", argv[i+1]);
        return pseudo_tui_error();
    }
    if (streq(argv[i], "clear")) {
        int force = 0;
        if (i + 1 < argc && (streq(argv[i+1], "-h") || streq(argv[i+1], "--help"))) return simple_help("repo clear");
        if (i + 1 < argc && streq(argv[i+1], "--force")) { force = 1; i++; }
        if (i + 1 < argc) return unexpected_cmd("repo clear", "executable repo clear [OPTIONS]", argv[i+1]);
        (void)force;
        puts("No cached repositories directory found.");
        return 0;
    }
    return unrecognized_sub(argv[i], "executable repo <COMMAND>");
}

static int handle_export(int argc, char **argv, int i) {
    const char *format = "json", *output = NULL;
    for (; i < argc; i++) {
        if (streq(argv[i], "-h") || streq(argv[i], "--help")) { export_help(); return 0; }
        if (streq(argv[i], "--format")) {
            if (++i >= argc) return missing_value("--format", "FORMAT");
            format = argv[i];
        } else if (streq(argv[i], "--output")) {
            if (++i >= argc) return missing_value("--output", "OUTPUT");
            output = argv[i];
        } else {
            return unexpected_cmd("export", "executable export [OPTIONS]", argv[i]);
        }
    }
    puts("❌ Export command is not yet implemented");
    printf("💡 Requested format: %s\n", format);
    if (output) printf("💡 Requested output: %s\n", output);
    puts("💡 This feature is planned for a future release");
    return 1;
}

static int valid_language_name(const char *s) {
    const char *valid[] = {"rust","rs","typescript","ts","javascript","js","python","py","ruby","rb","go","swift","kotlin","kt","java","php","csharp","cs","c#","c","cpp","c++","haskell","hs","dart","scala","sc","zig","clojure","clj","cljs",NULL};
    char buf[64];
    size_t n = strlen(s);
    if (n >= sizeof(buf)) return 0;
    for (size_t i = 0; i <= n; i++) buf[i] = (char)tolower((unsigned char)s[i]);
    for (int i = 0; valid[i]; i++) if (streq(buf, valid[i])) return 1;
    return 0;
}

static int validate_langs(const char *langs) {
    char *copy = strdup(langs);
    if (!copy) exit(1);
    int ok = 1;
    char bad[256] = "";
    for (char *tok = strtok(copy, ","); tok; tok = strtok(NULL, ",")) {
        while (*tok && isspace((unsigned char)*tok)) tok++;
        if (!valid_language_name(tok)) {
            if (bad[0]) strncat(bad, ", ", sizeof(bad)-strlen(bad)-1);
            strncat(bad, tok, sizeof(bad)-strlen(bad)-1);
            ok = 0;
        }
    }
    free(copy);
    if (!ok) {
        printf("❌ Unsupported language(s): %s\n", bad);
        puts("💡 Supported languages:");
        puts("   rust, rs, typescript, ts, javascript, js");
        puts("   python, py, ruby, rb, go, swift");
        puts("   kotlin, kt, java, php, csharp, cs");
        puts("   c#, c, cpp, c++, haskell, hs");
        puts("   dart, scala, sc, zig, clojure, clj");
        puts("   cljs");
        return 0;
    }
    return 1;
}

static int handle_trending(int argc, char **argv, int i) {
    const char *pos[3] = {0};
    int pc = 0;
    for (; i < argc; i++) {
        if (streq(argv[i], "--help")) { trending_help_long(); return 0; }
        if (streq(argv[i], "-h")) { trending_help_short(); return 0; }
        if (streq(argv[i], "--period")) {
            if (++i >= argc) return missing_value("--period", "PERIOD");
        } else if (argv[i][0] == '-') {
            return unexpected_cmd("trending", "executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]", argv[i]);
        } else {
            if (pc >= 2) return unexpected_cmd("trending", "executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]", argv[i]);
            pos[pc++] = argv[i];
        }
    }
    if (pc == 2 && strchr(pos[1], '/') == NULL) {
        puts("⚠️ Repository name must be in format 'owner/repo'");
        return 0;
    }
    return pseudo_tui_error();
}

static int handle_simple_command(int argc, char **argv, int i, const char *cmd) {
    if (i < argc && (streq(argv[i], "-h") || streq(argv[i], "--help"))) return simple_help(cmd);
    if (i < argc) {
        char usage[64];
        snprintf(usage, sizeof(usage), "executable %s", cmd);
        return unexpected_cmd(cmd, usage, argv[i]);
    }
    if (streq(cmd, "history")) {
        puts("❌ History command is not yet implemented");
    } else {
        puts("❌ Stats command is not yet implemented");
    }
    puts("💡 This feature is planned for a future release");
    return 1;
}

int main(int argc, char **argv) {
    int i = 1;
    int saw_repo = 0, saw_langs = 0;
    (void)saw_repo;
    while (i < argc) {
        if (streq(argv[i], "-V") || streq(argv[i], "--version")) {
            puts("gittype 0.8.0");
            return 0;
        } else if (streq(argv[i], "-h")) {
            root_help_short();
            return 0;
        } else if (streq(argv[i], "--help")) {
            root_help_long();
            return 0;
        } else if (streq(argv[i], "--repo")) {
            if (++i >= argc) return missing_value("--repo", "REPO");
            saw_repo = 1;
            i++;
        } else if (streq(argv[i], "--langs")) {
            if (++i >= argc) return missing_value("--langs", "LANGS");
            saw_langs = 1;
            if (!validate_langs(argv[i])) return 1;
            i++;
        } else if (argv[i][0] == '-') {
            return unexpected_root(argv[i]);
        } else {
            break;
        }
    }
    if (i >= argc) {
        if (saw_repo || saw_langs) return pseudo_tui_error();
        return pseudo_tui_error();
    }
    if (streq(argv[i], "help")) {
        if (i + 1 >= argc) { root_help_long(); return 0; }
        if (streq(argv[i+1], "cache")) { cache_help(); return 0; }
        if (streq(argv[i+1], "repo")) { repo_help(); return 0; }
        if (streq(argv[i+1], "trending")) { trending_help_long(); return 0; }
        if (streq(argv[i+1], "export")) { export_help(); return 0; }
        if (streq(argv[i+1], "history")) return simple_help("history");
        if (streq(argv[i+1], "stats")) return simple_help("stats");
        return unrecognized_sub(argv[i+1], "executable [OPTIONS] [REPO_PATH] [COMMAND]");
    }
    if (streq(argv[i], "history")) return handle_simple_command(argc, argv, i+1, "history");
    if (streq(argv[i], "stats")) return handle_simple_command(argc, argv, i+1, "stats");
    if (streq(argv[i], "export")) return handle_export(argc, argv, i+1);
    if (streq(argv[i], "cache")) return handle_cache(argc, argv, i+1);
    if (streq(argv[i], "repo")) return handle_repo(argc, argv, i+1);
    if (streq(argv[i], "trending")) return handle_trending(argc, argv, i+1);
    if (i + 1 < argc) return unexpected_root(argv[i+1]);
    return pseudo_tui_error();
}
