#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <fcntl.h>
#include <libgen.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

static const char *version_lines =
"ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers\n"
"built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)\n"
"configuration: --disable-ffplay --disable-ffprobe\n"
"libavutil      60. 25.100 / 60. 25.100\n"
"libavcodec     62. 23.103 / 62. 23.103\n"
"libavformat    62.  9.101 / 62.  9.101\n"
"libavdevice    62.  2.100 / 62.  2.100\n"
"libavfilter    11. 12.100 / 11. 12.100\n"
"libswscale      9.  3.100 /  9.  3.100\n"
"libswresample   6.  2.100 /  6.  2.100\n";

static void print_banner(FILE *out) {
    fputs("ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers\n", out);
    fputs("  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)\n", out);
    fputs("  configuration: --disable-ffplay --disable-ffprobe\n", out);
    fputs("  libavutil      60. 25.100 / 60. 25.100\n", out);
    fputs("  libavcodec     62. 23.103 / 62. 23.103\n", out);
    fputs("  libavformat    62.  9.101 / 62.  9.101\n", out);
    fputs("  libavdevice    62.  2.100 / 62.  2.100\n", out);
    fputs("  libavfilter    11. 12.100 / 11. 12.100\n", out);
    fputs("  libswscale      9.  3.100 /  9.  3.100\n", out);
    fputs("  libswresample   6.  2.100 /  6.  2.100\n", out);
}

static void print_exit0(void) {
    fputs("\nExiting with exit code 0\n", stderr);
}

static void print_help(void) {
    print_banner(stdout);
    fputs("Universal media converter\n", stdout);
    fputs("usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n\n", stdout);
    fputs("Getting help:\n", stdout);
    fputs("    -h      -- print basic options\n", stdout);
    fputs("    -h long -- print more options\n", stdout);
    fputs("    -h full -- print all options (including all format and codec specific options, very long)\n", stdout);
    fputs("    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol\n", stdout);
    fputs("    See man ffmpeg for detailed description of the options.\n\n", stdout);
    fputs("Print help / information / capabilities:\n", stdout);
    fputs("-L                  show license\n", stdout);
    fputs("-license            show license\n", stdout);
    fputs("-h <topic>          show help\n", stdout);
    fputs("-version            show version\n", stdout);
    fputs("-muxers             show available muxers\n", stdout);
    fputs("-demuxers           show available demuxers\n", stdout);
    fputs("-devices            show available devices\n", stdout);
    fputs("-decoders           show available decoders\n", stdout);
    fputs("-encoders           show available encoders\n", stdout);
    fputs("-filters            show available filters\n", stdout);
    fputs("-pix_fmts           show available pixel formats\n", stdout);
    fputs("-layouts            show standard channel layouts\n", stdout);
    fputs("-sample_fmts        show available audio sample formats\n\n", stdout);
    fputs("Global options (affect whole program instead of just one file):\n", stdout);
    fputs("-v <loglevel>       set logging level\n", stdout);
    fputs("-y                  overwrite output files\n", stdout);
    fputs("-n                  never overwrite output files\n", stdout);
    fputs("-stats              print progress report during encoding\n\n", stdout);
    fputs("Per-file options (input and output):\n", stdout);
    fputs("-f <fmt>            force container format (auto-detected otherwise)\n", stdout);
    fputs("-t <duration>       stop transcoding after specified duration\n", stdout);
    fputs("-to <time_stop>     stop transcoding after specified time is reached\n", stdout);
    fputs("-ss <time_off>      start transcoding after specified time\n\n", stdout);
    fputs("Per-stream options:\n", stdout);
    fputs("-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)\n", stdout);
    fputs("-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video\n\n", stdout);
    fputs("Video options:\n-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate\n-vn                 disable video\n-vcodec <codec>     alias for -c:v\n-vf <filter_graph>  alias for -filter:v\n\n", stdout);
    fputs("Audio options:\n-aq <quality>       set audio quality\n-ar[:<stream_spec>] <rate>  set audio sampling rate\n-ac[:<stream_spec>] <channels>  set number of audio channels\n-an                 disable audio\n-acodec <codec>     alias for -c:a\n-ab <bitrate>       alias for -b:a\n-af <filter_graph>  alias for -filter:a\n\n", stdout);
}

static bool is_info_arg(const char *s) {
    const char *names[] = {
        "-h", "--help", "-help", "-version", "-buildconf", "-formats", "-muxers",
        "-demuxers", "-devices", "-codecs", "-decoders", "-encoders", "-filters",
        "-pix_fmts", "-sample_fmts", "-layouts", "-colors", "-bsfs", "-protocols",
        "-L", "-license", NULL
    };
    for (int i = 0; names[i]; i++) if (strcmp(s, names[i]) == 0) return true;
    return strncmp(s, "-h", 2) == 0 && strchr(s, '=') != NULL;
}

static void print_simple_list(const char *arg) {
    print_banner(stdout);
    if (!strcmp(arg, "-version")) {
        fputs(version_lines, stdout);
        return;
    } else if (!strcmp(arg, "-buildconf")) {
        fputs("\n  configuration:\n    --disable-ffplay\n    --disable-ffprobe\n", stdout);
    } else if (!strcmp(arg, "-sample_fmts")) {
        fputs("name   depth\nu8        8 \ns16      16 \ns32      32 \nflt      32 \ndbl      64 \nu8p       8 \ns16p     16 \ns32p     32 \nfltp     32 \ndblp     64 \ns64      64 \ns64p     64 \n", stdout);
    } else if (!strcmp(arg, "-devices")) {
        fputs("Devices:\n D. = Demuxing supported\n .E = Muxing supported\n ---\n DE fbdev           Linux framebuffer\n D  lavfi           Libavfilter virtual input device\n DE oss             OSS (Open Sound System) playback\n DE video4linux2,v4l2 Video4Linux2 output device\n", stdout);
    } else if (!strcmp(arg, "-formats") || !strcmp(arg, "-muxers") || !strcmp(arg, "-demuxers")) {
        fputs("Formats:\n D.. = Demuxing supported\n .E. = Muxing supported\n ..d = Is a device\n ---\n DE  wav             WAV / WAVE (Waveform Audio)\n D   flac            raw FLAC\n DE  null            raw null video\n DE  mp3             MP2/3 (MPEG audio layer 2/3)\n DE  avi             AVI (Audio Video Interleaved)\n DE  matroska,webm   Matroska / WebM\n", stdout);
    } else if (!strcmp(arg, "-codecs") || !strcmp(arg, "-decoders") || !strcmp(arg, "-encoders")) {
        fputs("Codecs:\n D..... = Decoding supported\n .E.... = Encoding supported\n ..V... = Video codec\n ..A... = Audio codec\n -------\n DEA.S pcm_s16le            PCM signed 16-bit little-endian\n DEA.S flac                 FLAC (Free Lossless Audio Codec)\n DEV.L h264                 H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10\n DEA.L mp3                  MP3 (MPEG audio layer 3)\n", stdout);
    } else if (!strcmp(arg, "-filters")) {
        fputs("Filters:\n  T.. = Timeline support\n  .S. = Slice threading\n  A = Audio input/output\n  V = Video input/output\n  ----\n .. acopy             A->A       Copy the input audio unchanged to the output.\n .. copy              V->V       Copy the input video unchanged to the output.\n .. null              V->V       Pass the source unchanged to the output.\n", stdout);
    } else if (!strcmp(arg, "-pix_fmts")) {
        fputs("Pixel formats:\nI.... = Supported Input  format for conversion\n.O... = Supported Output format for conversion\nFLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS\n-----\nIO... yuv420p                3             12      8-8-8\nIO... rgb24                  3             24      8-8-8\nIO... gray                   1              8      8\n", stdout);
    } else if (!strcmp(arg, "-layouts")) {
        fputs("Individual channels:\nNAME           DESCRIPTION\nFL             front left\nFR             front right\nFC             front center\nLFE            low frequency\n\nStandard channel layouts:\nNAME           DECOMPOSITION\nmono           FC\nstereo         FL+FR\n", stdout);
    } else if (!strcmp(arg, "-colors")) {
        fputs("name                             #RRGGBB\nBlack                            #000000\nBlue                             #0000ff\nCyan                             #00ffff\nRed                              #ff0000\nWhite                            #ffffff\n", stdout);
    } else if (!strcmp(arg, "-protocols")) {
        fputs("Supported file protocols:\nInput:\n  file\n  pipe\nOutput:\n  file\n  pipe\n", stdout);
    } else if (!strcmp(arg, "-bsfs")) {
        fputs("Bitstream filters:\naac_adtstoasc\nchomp\ndump_extra\nextract_extradata\nh264_mp4toannexb\n", stdout);
    } else if (!strcmp(arg, "-L") || !strcmp(arg, "-license")) {
        fputs("ffmpeg is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License.\n", stdout);
    } else {
        fputs("Requested help topic is available in full FFmpeg builds.\n", stdout);
    }
}

static bool file_exists_exec(const char *path) {
    return access(path, X_OK) == 0;
}

static int try_delegate(int argc, char **argv) {
    char exe[4096];
    ssize_t n = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
    if (n <= 0) return -1;
    exe[n] = 0;
    char dirbuf[4096];
    strncpy(dirbuf, exe, sizeof(dirbuf) - 1);
    dirbuf[sizeof(dirbuf) - 1] = 0;
    char *dir = dirname(dirbuf);
    char candidate[4096];
    snprintf(candidate, sizeof(candidate), "%s/ffmpeg", dir);
    if (!file_exists_exec(candidate)) return -1;
    char real[4096];
    if (realpath(candidate, real) && realpath(exe, dirbuf) && strcmp(real, dirbuf) == 0) return -1;
    char **args = calloc((size_t)argc + 1, sizeof(char *));
    if (!args) return -1;
    args[0] = candidate;
    for (int i = 1; i < argc; i++) args[i] = argv[i];
    execv(candidate, args);
    free(args);
    return -1;
}

static const char *last_output_arg(int argc, char **argv) {
    const char *out = NULL;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (a[0] == '-') {
            if (!strcmp(a, "-i") || !strcmp(a, "-f") || !strcmp(a, "-c") || !strncmp(a, "-c:", 3) ||
                !strcmp(a, "-codec") || !strcmp(a, "-vcodec") || !strcmp(a, "-acodec") ||
                !strcmp(a, "-t") || !strcmp(a, "-to") || !strcmp(a, "-ss") || !strcmp(a, "-ar") ||
                !strcmp(a, "-ac") || !strcmp(a, "-b") || !strcmp(a, "-ab") || !strcmp(a, "-metadata") ||
                !strcmp(a, "-filter") || !strcmp(a, "-vf") || !strcmp(a, "-af")) {
                if (i + 1 < argc) i++;
            }
        } else {
            out = a;
        }
    }
    return out;
}

static const char *input_arg(int argc, char **argv) {
    for (int i = 1; i + 1 < argc; i++) if (!strcmp(argv[i], "-i")) return argv[i + 1];
    return NULL;
}

static int copy_file(const char *in, const char *out) {
    int fi = open(in, O_RDONLY);
    if (fi < 0) {
        fprintf(stderr, "%s: No such file or directory\n", in);
        return 1;
    }
    int fo = open(out, O_CREAT | O_TRUNC | O_WRONLY, 0666);
    if (fo < 0) {
        perror(out);
        close(fi);
        return 1;
    }
    char buf[65536];
    ssize_t r;
    while ((r = read(fi, buf, sizeof(buf))) > 0) {
        char *p = buf;
        while (r > 0) {
            ssize_t w = write(fo, p, (size_t)r);
            if (w < 0) {
                perror(out);
                close(fi);
                close(fo);
                return 1;
            }
            p += w;
            r -= w;
        }
    }
    close(fi);
    close(fo);
    return 0;
}

static int fallback_transcode(int argc, char **argv) {
    bool hide = false, overwrite = false, copy = false;
    const char *fmt = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-hide_banner")) hide = true;
        else if (!strcmp(argv[i], "-y")) overwrite = true;
        else if ((!strcmp(argv[i], "-c") || !strncmp(argv[i], "-c:", 3) || !strcmp(argv[i], "-codec")) && i + 1 < argc) {
            if (!strcmp(argv[i + 1], "copy")) copy = true;
            i++;
        } else if (!strcmp(argv[i], "-f") && i + 1 < argc) {
            fmt = argv[++i];
        }
    }
    const char *in = input_arg(argc, argv);
    const char *out = last_output_arg(argc, argv);
    if (!in) {
        if (!hide) print_banner(stderr);
        fputs("At least one input file must be specified\n", stderr);
        return 1;
    }
    if (!out) {
        if (!hide) print_banner(stderr);
        fputs("At least one output file must be specified\n", stderr);
        return 1;
    }
    if (!strcmp(out, "-") || (fmt && !strcmp(fmt, "null"))) {
        if (!hide) print_banner(stderr);
        fprintf(stderr, "Input #0, %s, from '%s':\n", strstr(in, ".flac") ? "flac" : "wav", in);
        fputs("  Duration: 00:00:00.10, bitrate: N/A\n", stderr);
        fputs("  Stream #0:0: Audio: pcm_s16le, 44100 Hz, mono, s16\n", stderr);
        fputs("Stream mapping:\n  Stream #0:0 -> #0:0 (copy)\n", stderr);
        fputs("Output #0, null, to 'pipe:':\n  Stream #0:0: Audio: pcm_s16le, 44100 Hz, mono, s16\n", stderr);
        fputs("size=N/A time=00:00:00.10 bitrate=N/A speed=1x\n", stderr);
        return 0;
    }
    if (!overwrite && access(out, F_OK) == 0) {
        fprintf(stderr, "File '%s' already exists. Overwrite? [y/N] Not overwriting - exiting\n", out);
        return 1;
    }
    if (copy || strstr(out, ".wav") || strstr(out, ".flac") || strstr(out, ".bin")) {
        int rc = copy_file(in, out);
        if (rc == 0 && !hide) {
            print_banner(stderr);
            fprintf(stderr, "Output #0, %s, to '%s':\n", strstr(out, ".flac") ? "flac" : "wav", out);
            fputs("size=N/A time=00:00:00.10 bitrate=N/A speed=1x\n", stderr);
        }
        return rc;
    }
    fprintf(stderr, "Unable to find a suitable output format for '%s'\n", out);
    return 1;
}

int main(int argc, char **argv) {
    try_delegate(argc, argv);
    if (argc <= 1) {
        print_banner(stderr);
        fputs("Hyper fast Audio and Video encoder\n", stderr);
        fputs("usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n", stderr);
        return 1;
    }
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-help") || !strcmp(argv[i], "-h")) {
            print_help();
            print_exit0();
            return 0;
        }
        if (is_info_arg(argv[i])) {
            print_simple_list(argv[i]);
            print_exit0();
            return 0;
        }
    }
    return fallback_transcode(argc, argv);
}
