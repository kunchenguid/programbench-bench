#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { char *name, *type; } Field;
typedef struct {
    char *name, *recv_name, *recv_type, *type_params, *params_src, *returns_src;
    Field *params; int nparams;
    char **returns; int nreturns;
    bool last_error;
} Func;
typedef struct { Func *v; int n, cap; } FuncList;
typedef struct { char **v; int n, cap; } StrList;

typedef struct {
    bool all, exported, named, nosubtests, parallel, write, inputs, version, use_cmp, ai;
    char *only, *excl, *template_name, *template_dir, *template_params, *template_params_file;
    char *ai_model, *ai_endpoint; int ai_min, ai_max;
    StrList paths;
} Opts;

static char *xstrdup(const char *s){ if(!s) return NULL; char *p=strdup(s); if(!p){perror("strdup"); exit(2);} return p; }
static char *xstrndup(const char *s,size_t n){ char *p=malloc(n+1); if(!p){perror("malloc"); exit(2);} memcpy(p,s,n); p[n]=0; return p; }
static void *xrealloc(void *p,size_t n){ void *q=realloc(p,n); if(!q){perror("realloc"); exit(2);} return q; }
static void strlist_add(StrList *l,char *s){ if(l->n==l->cap){l->cap=l->cap?l->cap*2:8;l->v=xrealloc(l->v,l->cap*sizeof(char*));} l->v[l->n++]=s; }
static void funclist_add(FuncList *l,Func f){ if(l->n==l->cap){l->cap=l->cap?l->cap*2:8;l->v=xrealloc(l->v,l->cap*sizeof(Func));} l->v[l->n++]=f; }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static bool starts_word(const char *p,const char *w){ size_t n=strlen(w); return strncmp(p,w,n)==0 && !isalnum((unsigned char)p[n]) && p[n]!='_'; }
static bool is_exported(const char *s){ return s && s[0]>='A' && s[0]<='Z'; }
static bool is_ident_char(int c){ return isalnum(c)||c=='_'; }

static char *read_file(const char *path){
    FILE *f=fopen(path,"rb"); if(!f) return NULL;
    fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET);
    char *buf=malloc((size_t)n+1); if(!buf){perror("malloc"); exit(2);}
    if(fread(buf,1,(size_t)n,f)!=(size_t)n){ if(ferror(f)){perror(path); exit(2);} }
    buf[n]=0; fclose(f); return buf;
}

static void append(char **out,size_t *len,size_t *cap,const char *s){
    size_t n=strlen(s); if(*len+n+1>*cap){ while(*len+n+1>*cap)*cap=*cap?*cap*2:4096; *out=xrealloc(*out,*cap); }
    memcpy(*out+*len,s,n+1); *len+=n;
}
static void appendf(char **out,size_t *len,size_t *cap,const char *fmt,...){
    va_list ap; va_start(ap,fmt); char *tmp=NULL; if(vasprintf(&tmp,fmt,ap)<0){perror("vasprintf"); exit(2);} va_end(ap);
    append(out,len,cap,tmp); free(tmp);
}

static char *strip_comments(const char *src){
    size_t n=strlen(src); char *d=malloc(n+1); if(!d){perror("malloc"); exit(2);} size_t j=0;
    enum {N, SL, ML, STR, RAW, CHR} st=N;
    for(size_t i=0;i<n;i++){
        char c=src[i], nx=i+1<n?src[i+1]:0;
        if(st==N){
            if(c=='/'&&nx=='/'){ st=SL; d[j++]=' '; i++; }
            else if(c=='/'&&nx=='*'){ st=ML; d[j++]=' '; i++; }
            else { d[j++]=c; if(c=='"')st=STR; else if(c=='`')st=RAW; else if(c=='\'')st=CHR; }
        } else if(st==SL){ if(c=='\n'){ d[j++]=c; st=N; } else d[j++]=' '; }
        else if(st==ML){ if(c=='*'&&nx=='/'){ d[j++]=' '; i++; st=N; } else d[j++]=(c=='\n')?'\n':' '; }
        else if(st==STR){ d[j++]=c; if(c=='\\'&&nx){ d[j++]=nx; i++; } else if(c=='"') st=N; }
        else if(st==RAW){ d[j++]=c; if(c=='`') st=N; }
        else if(st==CHR){ d[j++]=c; if(c=='\\'&&nx){ d[j++]=nx; i++; } else if(c=='\'') st=N; }
    }
    d[j]=0; return d;
}

static const char *skip_ws(const char *p){ while(isspace((unsigned char)*p))p++; return p; }
static const char *find_matching(const char *p,char open,char close){
    int depth=0; enum {N,STR,RAW,CHR} st=N;
    for(;*p;p++){
        char c=*p,nx=p[1];
        if(st==N){ if(c==open)depth++; else if(c==close){ if(--depth==0)return p; } else if(c=='"')st=STR; else if(c=='`')st=RAW; else if(c=='\'')st=CHR; }
        else if(st==STR){ if(c=='\\'&&nx)p++; else if(c=='"')st=N; }
        else if(st==RAW){ if(c=='`')st=N; }
        else if(st==CHR){ if(c=='\\'&&nx)p++; else if(c=='\'')st=N; }
    }
    return NULL;
}
static const char *skip_balanced(const char *p,char open,char close){ const char *m=find_matching(p,open,close); return m?m+1:p; }

static char *base_recv_type(const char *rt){
    char *s=xstrdup(rt), *t=trim(s); while(*t=='*'||isspace((unsigned char)*t))t++;
    char *e=t; while(*e && *e!='[' && *e!='.' && !isspace((unsigned char)*e)) e++;
    char *r=xstrndup(t,(size_t)(e-t)); free(s); return r;
}
static char *recv_concrete(const char *rt){
    char *s=xstrdup(rt); char *lb=strchr(s,'['); if(lb){ *lb=0; strcat(s,"[string]"); }
    return s;
}

static void split_params(Func *f){
    char *src=xstrdup(f->params_src?f->params_src:""); char *items[256]; int ni=0; int start=0, depth=0; size_t n=strlen(src);
    for(size_t i=0;i<=n;i++){
        char c=src[i]; if(c=='('||c=='['||c=='{')depth++; else if(c==')'||c==']'||c=='}')depth--;
        if((c==','&&depth==0)||c==0){ src[i]=0; char *it=trim(src+start); if(*it&&ni<256)items[ni++]=xstrdup(it); start=(int)i+1; }
    }
    char *pending[128]; int np=0;
    for(int i=0;i<ni;i++){
        char *it=items[i]; char *last_space=NULL; int d=0;
        for(char *p=it;*p;p++){ if(*p=='('||*p=='['||*p=='{')d++; else if(*p==')'||*p==']'||*p=='}')d--; else if(isspace((unsigned char)*p)&&d==0)last_space=p; }
        if(last_space){
            *last_space=0; char *names=trim(it), *typ=trim(last_space+1);
            char *ns=xstrdup(names); char *tok=strtok(ns,",");
            while(tok){ char *nm=trim(tok); if(*nm) pending[np++]=xstrdup(nm); tok=strtok(NULL,","); }
            for(int k=0;k<np;k++){ f->params=xrealloc(f->params,(f->nparams+1)*sizeof(Field)); f->params[f->nparams++]=(Field){pending[k],xstrdup(typ)}; }
            np=0; free(ns);
        } else if(*it) {
            bool bare_name = true;
            for(char *p=it; *p; p++) if(!is_ident_char((unsigned char)*p)) bare_name = false;
            if(bare_name && i + 1 < ni) {
                pending[np++] = xstrdup(it);
            } else {
                f->params=xrealloc(f->params,(f->nparams+1)*sizeof(Field));
                char nm[32]; snprintf(nm,sizeof nm,"arg%d",f->nparams);
                f->params[f->nparams++]=(Field){xstrdup(nm),xstrdup(it)};
            }
        }
        free(items[i]);
    }
    free(src);
}

static void split_returns(Func *f){
    if(!f->returns_src) return; char *s=xstrdup(f->returns_src); char *t=trim(s); if(!*t){free(s);return;}
    if(*t=='('){ size_t l=strlen(t); if(l>1&&t[l-1]==')'){ t[l-1]=0; t++; } }
    int depth=0,start=0; size_t n=strlen(t);
    for(size_t i=0;i<=n;i++){
        char c=t[i]; if(c=='('||c=='['||c=='{')depth++; else if(c==')'||c==']'||c=='}')depth--;
        if((c==','&&depth==0)||c==0){ t[i]=0; char *it=trim(t+start); if(*it){ char *sp=strrchr(it,' '); if(sp && is_ident_char((unsigned char)it[0])) it=trim(sp+1); f->returns=xrealloc(f->returns,(f->nreturns+1)*sizeof(char*)); f->returns[f->nreturns++]=xstrdup(it);} start=(int)i+1; }
    }
    if(f->nreturns>0 && strcmp(f->returns[f->nreturns-1],"error")==0) f->last_error=true;
    free(s);
}

static char *extract_package(const char *src){
    const char *p=src; while((p=strstr(p,"package"))){ if((p==src||!is_ident_char((unsigned char)p[-1]))&&starts_word(p,"package")){ p=skip_ws(p+7); const char *q=p; while(is_ident_char((unsigned char)*q))q++; if(q>p)return xstrndup(p,(size_t)(q-p)); } p+=7; }
    return xstrdup("main");
}

static FuncList parse_funcs(const char *src){
    FuncList list={0}; char *clean=strip_comments(src); const char *p=clean;
    while((p=strstr(p,"func"))){
        if(!((p==clean||!is_ident_char((unsigned char)p[-1]))&&starts_word(p,"func"))){ p+=4; continue; }
        const char *q=skip_ws(p+4); Func f={0};
        if(*q=='('){ const char *m=find_matching(q,'(',')'); if(!m){p=q+1;continue;} char *r=xstrndup(q+1,(size_t)(m-q-1)); char *rt=trim(r); char *sp=strchr(rt,' '); if(sp){ *sp=0; f.recv_name=xstrdup(trim(rt)); f.recv_type=xstrdup(trim(sp+1)); } else { f.recv_name=xstrdup("recv"); f.recv_type=xstrdup(rt); } free(r); q=skip_ws(m+1); }
        if(!isalpha((unsigned char)*q)&&*q!='_'){ p=q; continue; }
        const char *name=q; while(is_ident_char((unsigned char)*q))q++; f.name=xstrndup(name,(size_t)(q-name)); q=skip_ws(q);
        if(*q=='['){ const char *m=find_matching(q,'[',']'); if(m){ f.type_params=xstrndup(q,(size_t)(m-q+1)); q=skip_ws(m+1); } }
        if(*q!='('){ p=q; continue; } const char *pm=find_matching(q,'(',')'); if(!pm){p=q+1;continue;}
        f.params_src=xstrndup(q+1,(size_t)(pm-q-1)); q=skip_ws(pm+1);
        const char *ret_start=q; while(*q && *q!='{'){ if(*q=='(') q=skip_balanced(q,'(',')'); else if(*q=='[') q=skip_balanced(q,'[',']'); else q++; }
        f.returns_src=xstrndup(ret_start,(size_t)(q-ret_start)); split_params(&f); split_returns(&f); funclist_add(&list,f); p=q;
    }
    free(clean); return list;
}

static bool regex_match(const char *pat,const char *s){
    regex_t re; int rc=regcomp(&re,pat,REG_EXTENDED|REG_NOSUB); if(rc!=0) return strstr(s,pat)!=NULL;
    rc=regexec(&re,s,0,NULL,0); regfree(&re); return rc==0;
}
static bool include_func(const Opts *o,const Func *f){
    char *full=NULL; if(f->recv_type){ char *b=base_recv_type(f->recv_type); asprintf(&full,"%s.%s",b,f->name); free(b); } else full=xstrdup(f->name);
    bool ok=o->all; if(o->only) ok=regex_match(o->only,f->name)||regex_match(o->only,full); if(o->exported) ok=is_exported(f->name); if(o->excl && (regex_match(o->excl,f->name)||regex_match(o->excl,full))) ok=false; free(full); return ok;
}

static bool scalar_type(const char *t){
    const char *sc[]={"bool","string","error","int","int8","int16","int32","int64","uint","uint8","uint16","uint32","uint64","uintptr","byte","rune","float32","float64","complex64","complex128",NULL};
    char *s=xstrdup(t), *x=trim(s); for(int i=0;sc[i];i++) if(strcmp(x,sc[i])==0){free(s);return true;} free(s); return false;
}
static char *exportish(const char *s){
    char *r=xstrdup(s);
    if(r[0]>='a' && r[0]<='z') r[0]=(char)(r[0]-'a'+'A');
    return r;
}
static char *call_type_params(const Func *f){
    if(!f->type_params) return xstrdup("");
    char *inside=xstrndup(f->type_params+1,strlen(f->type_params)-2), *out=xstrdup("["); int count=0, depth=0, start=0; size_t n=strlen(inside);
    for(size_t i=0;i<=n;i++){ char c=inside[i]; if(c=='['||c=='(')depth++; else if(c==']'||c==')')depth--; if((c==','&&depth==0)||c==0){ inside[i]=0; char *part=trim(inside+start); char *typ=strchr(part,' '); typ=typ?trim(typ+1):part; char *use="int"; if(strstr(typ,"comparable"))use="string"; else if(strstr(typ,"string"))use="string"; else if(strstr(typ,"float"))use="float64"; else if(strstr(typ,"int64"))use="int64"; if(count++) { char *tmp; asprintf(&tmp,"%s, %s",out,use); free(out); out=tmp; } else { char *tmp; asprintf(&tmp,"%s%s",out,use); free(out); out=tmp; } start=(int)i+1; } }
    char *tmp; asprintf(&tmp,"%s]",out); free(out); free(inside); return tmp;
}
static const char *concrete_for_constraint(const char *typ){
    if(strstr(typ,"comparable")) return "string";
    if(strstr(typ,"string")) return "string";
    if(strstr(typ,"float")) return "float64";
    if(strstr(typ,"int64")) return "int64";
    return "int";
}
static char *replace_word(const char *src,const char *word,const char *repl){
    char *out=xstrdup(""); size_t wl=strlen(word);
    for(const char *p=src; *p; ){
        if(strncmp(p,word,wl)==0 && (p==src || !is_ident_char((unsigned char)p[-1])) && !is_ident_char((unsigned char)p[wl])){
            char *tmp; asprintf(&tmp,"%s%s",out,repl); free(out); out=tmp; p+=wl;
        } else {
            size_t l=strlen(out); out=xrealloc(out,l+2); out[l]=*p++; out[l+1]=0;
        }
    }
    return out;
}
static char *concrete_type(const Func *f,const char *typ){
    char *out=xstrdup(typ);
    if(!f->type_params) {
        if(f->recv_type) {
            const char *lb=strchr(f->recv_type,'['), *rb=lb?strchr(lb,']'):NULL;
            if(lb&&rb&&rb>lb+1){ char *inside=xstrndup(lb+1,(size_t)(rb-lb-1)); char *tok=strtok(inside,","); while(tok){ char *name=trim(tok); char *tmp=replace_word(out,name,"string"); free(out); out=tmp; tok=strtok(NULL,","); } free(inside); }
        }
        return out;
    }
    char *inside=xstrndup(f->type_params+1,strlen(f->type_params)-2);
    int depth=0,start=0; size_t n=strlen(inside);
    for(size_t i=0;i<=n;i++){
        char c=inside[i]; if(c=='['||c=='(')depth++; else if(c==']'||c==')')depth--;
        if((c==','&&depth==0)||c==0){
            inside[i]=0; char *part=trim(inside+start); char *sp=strchr(part,' ');
            if(sp){ *sp=0; char *name=trim(part), *constraint=trim(sp+1); char *tmp=replace_word(out,name,concrete_for_constraint(constraint)); free(out); out=tmp; }
            start=(int)i+1;
        }
    }
    free(inside); return out;
}
static char *call_args(const Func *f){
    char *out=xstrdup(""); for(int i=0;i<f->nparams;i++){ char *tmp; asprintf(&tmp,"%s%s%s",out,i?", ":"",f->params[i].name[0]? "tt.args.":""); char *tmp2; asprintf(&tmp2,"%s%s",tmp,f->params[i].name); free(out); free(tmp); out=tmp2; } return out;
}

static void emit_func(char **out,size_t *len,size_t *cap,const Opts *o,const Func *f){
    char *testname;
    if(f->recv_type){ char *b=base_recv_type(f->recv_type); asprintf(&testname,"Test%s_%s",b,f->name); free(b); }
    else { char *en=exportish(f->name); asprintf(&testname,"Test%s",en); free(en); }
    appendf(out,len,cap,"func %s(t *testing.T) {\n",testname);
    if(f->nparams){ append(out,len,cap,"\ttype args struct {\n"); for(int i=0;i<f->nparams;i++){ char *ct=concrete_type(f,f->params[i].type); appendf(out,len,cap,"\t\t%s %s\n",f->params[i].name,ct); free(ct);} append(out,len,cap,"\t}\n"); }
    append(out,len,cap,"\ttests := ");
    if(o->named) append(out,len,cap,"map[string]struct {\n"); else append(out,len,cap,"[]struct {\n");
    if(!o->named) append(out,len,cap,"\t\tname string\n");
    if(f->recv_type){ char *rt=recv_concrete(f->recv_type); appendf(out,len,cap,"\t\t%s %s\n",f->recv_name&&*f->recv_name?f->recv_name:"recv",rt); free(rt); }
    if(f->nparams) append(out,len,cap,"\t\targs args\n");
    int nonerr=f->nreturns-(f->last_error?1:0);
    for(int i=0;i<nonerr;i++) {
        char *ct=concrete_type(f,f->returns[i]);
        if(i==0) appendf(out,len,cap,"\t\twant %s\n", ct);
        else appendf(out,len,cap,"\t\twant%d %s\n", i+1, ct);
        free(ct);
    }
    if(f->last_error) append(out,len,cap,"\t\twantErr bool\n");
    append(out,len,cap,"\t}{\n\t\t// TODO: Add test cases.\n\t}\n");
    append(out,len,cap,"\tfor ");
    if(o->named) append(out,len,cap,"name, tt := range tests {\n\t\tt.Run(name, func(t *testing.T) {\n"); else append(out,len,cap,"_, tt := range tests {\n");
    if(!o->nosubtests && !o->named) append(out,len,cap,"\t\tt.Run(tt.name, func(t *testing.T) {\n");
    if(o->parallel) append(out,len,cap,"\t\t\tt.Parallel()\n");
    char *args=call_args(f), *tp=call_type_params(f); char *call;
    if(f->recv_type) asprintf(&call,"tt.%s.%s%s(%s)",f->recv_name&&*f->recv_name?f->recv_name:"recv",f->name,tp,args);
    else asprintf(&call,"%s%s(%s)",f->name,tp,args);
    const char *ind=(!o->nosubtests||o->named)?"\t\t\t":"\t\t";
    if(f->nreturns==0) appendf(out,len,cap,"%s%s\n",ind,call);
    else {
        if(f->last_error){
            if(nonerr==0) appendf(out,len,cap,"%sif err := %s; (err != nil) != tt.wantErr {\n%s\tt.Errorf(\"%s() error = %%v, wantErr %%v\", err, tt.wantErr)\n%s}\n",ind,call,ind,f->name,ind);
            else appendf(out,len,cap,"%sgot, err := %s\n%sif (err != nil) != tt.wantErr {\n%s\tt.Errorf(\"%s() error = %%v, wantErr %%v\", err, tt.wantErr)\n%s\treturn\n%s}\n",ind,call,ind,ind,f->name,ind,ind);
        } else if(f->nreturns==1) appendf(out,len,cap,"%sgot := %s\n",ind,call);
        else { appendf(out,len,cap,"%sgot",ind); for(int i=1;i<f->nreturns;i++) appendf(out,len,cap,", got%d",i+1); appendf(out,len,cap," := %s\n",call); }
        for(int i=0;i<nonerr;i++){
            char gotbuf[32], wantbuf[32];
            if(i==0) { strcpy(gotbuf, "got"); strcpy(wantbuf, "tt.want"); }
            else { snprintf(gotbuf, sizeof gotbuf, "got%d", i+1); snprintf(wantbuf, sizeof wantbuf, "tt.want%d", i+1); }
            const char *got=gotbuf, *want=wantbuf; char *typ=concrete_type(f,f->returns[i]);
            if(o->use_cmp) appendf(out,len,cap,"%sif diff := cmp.Diff(%s, %s); diff != \"\" {\n%s\tt.Errorf(\"%s() mismatch (-want +got):\\n%%s\", diff)\n%s}\n",ind,want,got,ind,f->name,ind);
            else if(scalar_type(typ)) appendf(out,len,cap,"%sif %s != %s {\n%s\tt.Errorf(\"%s() = %%v, want %%v\", %s, %s)\n%s}\n",ind,got,want,ind,f->name,got,want,ind);
            else appendf(out,len,cap,"%sif !reflect.DeepEqual(%s, %s) {\n%s\tt.Errorf(\"%s() = %%v, want %%v\", %s, %s)\n%s}\n",ind,got,want,ind,f->name,got,want,ind);
            free(typ);
        }
    }
    if(!o->nosubtests || o->named) append(out,len,cap,"\t\t})\n");
    append(out,len,cap,"\t}\n}\n\n"); free(testname); free(args); free(tp); free(call);
}

static bool needs_reflect(FuncList *fl,const Opts *o){
    if(o->use_cmp) return false;
    for(int i=0;i<fl->n;i++){
        Func *f=&fl->v[i]; int non=f->nreturns-(f->last_error?1:0);
        for(int j=0;j<non;j++){ char *ct=concrete_type(f,f->returns[j]); bool scalar=scalar_type(ct); free(ct); if(!scalar) return true; }
    }
    return false;
}
static char *generate(const char *path,const Opts *o){
    char *src=read_file(path); if(!src){ char *e; asprintf(&e,"open %s: %s\n",path,strerror(errno)); return e; }
    char *pkg=extract_package(src); FuncList all=parse_funcs(src), sel={0};
    for(int i=0;i<all.n;i++) if(include_func(o,&all.v[i])) funclist_add(&sel,all.v[i]);
    char *out=NULL; size_t len=0,cap=0; appendf(&out,&len,&cap,"package %s\n\n",pkg);
    append(&out,&len,&cap,"import (\n"); if(!o->use_cmp && needs_reflect(&sel,o)) append(&out,&len,&cap,"\t\"reflect\"\n"); append(&out,&len,&cap,"\t\"testing\"\n"); if(o->use_cmp) append(&out,&len,&cap,"\n\t\"github.com/google/go-cmp/cmp\"\n"); append(&out,&len,&cap,")\n\n");
    for(int i=0;i<sel.n;i++) emit_func(&out,&len,&cap,o,&sel.v[i]);
    free(pkg); free(src); return out;
}

static bool has_suffix(const char *s,const char *suf){ size_t a=strlen(s),b=strlen(suf); return a>=b&&strcmp(s+a-b,suf)==0; }
static void collect_path(StrList *files,const char *path,bool recur){
    struct stat st; if(stat(path,&st)!=0) return;
    if(S_ISREG(st.st_mode)){ if(has_suffix(path,".go")&&!has_suffix(path,"_test.go")) strlist_add(files,xstrdup(path)); return; }
    if(S_ISDIR(st.st_mode)){ DIR *d=opendir(path); if(!d)return; struct dirent *e; while((e=readdir(d))){ if(strcmp(e->d_name,".")==0||strcmp(e->d_name,"..")==0)continue; char *p; asprintf(&p,"%s/%s",path,e->d_name); if(e->d_type==DT_DIR&&recur) collect_path(files,p,true); else if(e->d_type!=DT_DIR) collect_path(files,p,false); free(p);} closedir(d); }
}
static char *test_path(const char *p){ char *out=xstrdup(p); char *dot=strrchr(out,'.'); if(dot&&strcmp(dot,".go")==0){ *dot=0; char *r; asprintf(&r,"%s_test.go",out); free(out); return r; } return out; }

static void usage(const char *argv0){
    printf("Usage of %s:\n",argv0);
    printf("  -ai\n\tgenerate test cases using AI (requires Ollama)\n");
    printf("  -ai-endpoint string\n\tOllama API endpoint (default \"http://localhost:11434\")\n");
    printf("  -ai-max-cases int\n\tmaximum number of test cases to generate with AI (default 10)\n");
    printf("  -ai-min-cases int\n\tminimum number of test cases to generate with AI (default 3)\n");
    printf("  -ai-model string\n\tAI model to use for test generation (default \"qwen2.5-coder:0.5b\")\n");
    printf("  -all\n\tgenerate tests for all functions and methods\n  -excl string\n\tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all\n  -exported\n\tgenerate tests for exported functions and methods. Takes precedence over -only and -all\n  -i\tprint test inputs in error messages\n  -named\n\tswitch table tests from using slice to map (with test name for the key)\n  -nosubtests\n\tdisable generating tests using the Go 1.7 subtests feature\n  -only string\n\tregexp. generate tests for functions and methods that match only. Takes precedence over -all\n  -parallel\n\tenable generating parallel subtests using the Go 1.7 feature\n  -template string\n\toptional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE\n  -template_dir string\n\toptional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR\n  -template_params string\n\tread external parameters to template by json with stdin\n  -template_params_file string\n\tread external parameters to template by json with file\n  -use_go_cmp\n\tuse cmp.Equal (google/go-cmp) instead of reflect.DeepEqual\n  -version\n\tprint version information and exit\n  -w\twrite output to (test) files instead of stdout\n");
}

static char *need_arg(int *i,int argc,char **argv){ if(*i+1>=argc){ fprintf(stderr,"flag needs an argument: %s\n",argv[*i]); exit(2);} return argv[++*i]; }
int main(int argc,char **argv){
    Opts o={.ai_model="qwen2.5-coder:0.5b",.ai_endpoint="http://localhost:11434",.ai_min=3,.ai_max=10};
    for(int i=1;i<argc;i++){
        char *a=argv[i]; if(a[0]!='-'){ strlist_add(&o.paths,xstrdup(a)); continue; }
        char *eq=strchr(a,'=');
        if(eq){
            *eq=0; char *val=eq+1;
            if(strcmp(a,"-only")==0)o.only=val; else if(strcmp(a,"-excl")==0)o.excl=val; else if(strcmp(a,"-template")==0)o.template_name=val; else if(strcmp(a,"-template_dir")==0)o.template_dir=val; else if(strcmp(a,"-template_params")==0)o.template_params=val; else if(strcmp(a,"-template_params_file")==0)o.template_params_file=val; else if(strcmp(a,"-ai-model")==0)o.ai_model=val; else if(strcmp(a,"-ai-endpoint")==0)o.ai_endpoint=val; else if(strcmp(a,"-ai-min-cases")==0)o.ai_min=atoi(val); else if(strcmp(a,"-ai-max-cases")==0)o.ai_max=atoi(val); else { fprintf(stderr,"flag provided but not defined: %s\n",a); usage(argv[0]); return 2; }
            continue;
        }
        if(strcmp(a,"--help")==0||strcmp(a,"-h")==0){ usage(argv[0]); return 0; }
        else if(strcmp(a,"-all")==0)o.all=true; else if(strcmp(a,"-exported")==0)o.exported=true; else if(strcmp(a,"-named")==0)o.named=true; else if(strcmp(a,"-nosubtests")==0)o.nosubtests=true; else if(strcmp(a,"-parallel")==0)o.parallel=true; else if(strcmp(a,"-w")==0)o.write=true; else if(strcmp(a,"-i")==0)o.inputs=true; else if(strcmp(a,"-version")==0)o.version=true; else if(strcmp(a,"-use_go_cmp")==0)o.use_cmp=true; else if(strcmp(a,"-ai")==0)o.ai=true;
        else if(strcmp(a,"-only")==0)o.only=need_arg(&i,argc,argv); else if(strcmp(a,"-excl")==0)o.excl=need_arg(&i,argc,argv); else if(strcmp(a,"-template")==0)o.template_name=need_arg(&i,argc,argv); else if(strcmp(a,"-template_dir")==0)o.template_dir=need_arg(&i,argc,argv); else if(strcmp(a,"-template_params")==0)o.template_params=need_arg(&i,argc,argv); else if(strcmp(a,"-template_params_file")==0)o.template_params_file=need_arg(&i,argc,argv); else if(strcmp(a,"-ai-model")==0)o.ai_model=need_arg(&i,argc,argv); else if(strcmp(a,"-ai-endpoint")==0)o.ai_endpoint=need_arg(&i,argc,argv); else if(strcmp(a,"-ai-min-cases")==0)o.ai_min=atoi(need_arg(&i,argc,argv)); else if(strcmp(a,"-ai-max-cases")==0)o.ai_max=atoi(need_arg(&i,argc,argv)); else { fprintf(stderr,"flag provided but not defined: %s\n",a); usage(argv[0]); return 2; }
    }
    if(o.version){ printf("gotests v0.0.0-20260303205902-f3b63d74369a\nGo version: go1.24.5\nGit commit: f3b63d74369a8c405a9a3990a656a278a4f9096f\nBuild time: 2026-03-03T20:59:02Z\n"); return 0; }
    if(!o.all && !o.exported && !o.only && !o.excl){ printf("Please specify either the -only, -excl, -exported, or -all flag\n"); return 0; }
    if(o.paths.n==0){ printf("Please specify a path\n"); return 0; }
    StrList files={0}; for(int i=0;i<o.paths.n;i++){ char *p=o.paths.v[i]; size_t n=strlen(p); if(n>=4&&strcmp(p+n-4,"/...")==0){ char *b=xstrndup(p,n-4); collect_path(&files,b,true); free(b); } else collect_path(&files,p,false); }
    for(int i=0;i<files.n;i++){ char *g=generate(files.v[i],&o); if(o.write){ char *tp=test_path(files.v[i]); FILE *f=fopen(tp,"wb"); if(!f){fprintf(stderr,"open %s: %s\n",tp,strerror(errno)); free(tp); free(g); continue;} fputs(g,f); fclose(f); free(tp); } else fputs(g,stdout); free(g); }
    return 0;
}
