#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define CONTROL_PORT 7835
#define MAX_CONN 1024
#define BUF_SIZE 4096

typedef struct { uint32_t id; int fd; } Conn;

typedef struct {
    Conn items[MAX_CONN];
    size_t len;
} ConnMap;

static void add_conn(ConnMap *m, uint32_t id, int fd) {
    if (m->len < MAX_CONN) { m->items[m->len].id = id; m->items[m->len].fd = fd; m->len++; }
    else close(fd);
}

static int find_conn(ConnMap *m, uint32_t id) {
    for (size_t i=0;i<m->len;i++) if (m->items[i].id == id) return m->items[i].fd;
    return -1;
}

static void remove_conn(ConnMap *m, uint32_t id) {
    for (size_t i=0;i<m->len;i++) if (m->items[i].id == id) {
        close(m->items[i].fd);
        m->items[i] = m->items[m->len-1];
        m->len--;
        return;
    }
}

static int write_all(int fd, const void *buf, size_t len) {
    const char *p = (const char*)buf;
    while (len) {
        ssize_t n = write(fd, p, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) return -1;
        p += n; len -= (size_t)n;
    }
    return 0;
}

static int read_all(int fd, void *buf, size_t len) {
    char *p = (char*)buf;
    while (len) {
        ssize_t n = read(fd, p, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) return -1;
        p += n; len -= (size_t)n;
    }
    return 0;
}

static int send_frame(int fd, char type, uint32_t id, const void *data, uint32_t len) {
    unsigned char hdr[9];
    hdr[0] = (unsigned char)type;
    uint32_t nid = htonl(id), nlen = htonl(len);
    memcpy(hdr+1, &nid, 4); memcpy(hdr+5, &nlen, 4);
    if (write_all(fd, hdr, 9) < 0) return -1;
    if (len && write_all(fd, data, len) < 0) return -1;
    return 0;
}

static int recv_frame(int fd, char *type, uint32_t *id, unsigned char *buf, uint32_t *len) {
    unsigned char hdr[9];
    if (read_all(fd, hdr, 9) < 0) return -1;
    uint32_t nid, nlen;
    memcpy(&nid, hdr+1, 4); memcpy(&nlen, hdr+5, 4);
    *type = (char)hdr[0]; *id = ntohl(nid); *len = ntohl(nlen);
    if (*len > BUF_SIZE) return -1;
    if (*len && read_all(fd, buf, *len) < 0) return -1;
    return 0;
}

static int parse_u16(const char *s, const char *what, int *out) {
    char *end = NULL; errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) {
        fprintf(stderr, "error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n", s, what);
        return -1;
    }
    if (v < 0 || v > 65535) {
        fprintf(stderr, "error: invalid value '%s' for '%s': %ld is not in 0..=65535\n\nFor more information, try '--help'.\n", s, what, v);
        return -1;
    }
    *out = (int)v; return 0;
}

static int connect_host(const char *host, int port) {
    char portbuf[16]; snprintf(portbuf, sizeof portbuf, "%d", port);
    struct addrinfo hints, *res, *rp; memset(&hints,0,sizeof hints);
    hints.ai_socktype = SOCK_STREAM; hints.ai_family = AF_UNSPEC;
    if (getaddrinfo(host, portbuf, &hints, &res) != 0) return -1;
    int fd = -1;
    for (rp=res; rp; rp=rp->ai_next) {
        fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (fd < 0) continue;
        if (connect(fd, rp->ai_addr, rp->ai_addrlen) == 0) break;
        close(fd); fd = -1;
    }
    freeaddrinfo(res); return fd;
}

static int listen_addr(const char *addr, int port) {
    char portbuf[16]; snprintf(portbuf, sizeof portbuf, "%d", port);
    struct addrinfo hints, *res, *rp; memset(&hints,0,sizeof hints);
    hints.ai_socktype = SOCK_STREAM; hints.ai_family = AF_UNSPEC; hints.ai_flags = AI_PASSIVE;
    const char *node = (addr && strcmp(addr,"0.0.0.0")!=0) ? addr : NULL;
    if (getaddrinfo(node, portbuf, &hints, &res) != 0) return -1;
    int fd = -1, yes = 1;
    for (rp=res; rp; rp=rp->ai_next) {
        fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (fd < 0) continue;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);
        if (bind(fd, rp->ai_addr, rp->ai_addrlen) == 0 && listen(fd, 128) == 0) break;
        close(fd); fd = -1;
    }
    freeaddrinfo(res); return fd;
}

static void print_root_help(void) {
    printf("A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.\n\n");
    printf("Usage: executable <COMMAND>\n\nCommands:\n  local   Starts a local proxy to the remote server\n  server  Runs the remote proxy server\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n");
}
static void print_local_help(void) {
    printf("Starts a local proxy to the remote server\n\nUsage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>\n\nArguments:\n  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]\n\nOptions:\n  -l, --local-host <HOST>  The local host to expose [default: localhost]\n  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]\n  -p, --port <PORT>        Optional port on the remote server to select [default: 0]\n  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]\n  -h, --help               Print help\n");
}
static void print_server_help(void) {
    printf("Runs the remote proxy server\n\nUsage: executable server [OPTIONS]\n\nOptions:\n      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]\n      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]\n  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]\n      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]\n      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr\n  -h, --help                         Print help\n");
}

static int run_local(int argc, char **argv) {
    const char *local_host = "localhost", *to = getenv("BORE_SERVER"), *secret = getenv("BORE_SECRET");
    const char *envlp = getenv("BORE_LOCAL_PORT");
    int remote_port = 0, local_port = -1;
    if (envlp && *envlp && parse_u16(envlp, "<LOCAL_PORT>", &local_port) < 0) return 2;
    for (int i=2;i<argc;i++) {
        if (!strcmp(argv[i],"-h") || !strcmp(argv[i],"--help")) { print_local_help(); return 0; }
        else if ((!strcmp(argv[i],"-l") || !strcmp(argv[i],"--local-host")) && i+1<argc) local_host = argv[++i];
        else if ((!strcmp(argv[i],"-t") || !strcmp(argv[i],"--to")) && i+1<argc) to = argv[++i];
        else if ((!strcmp(argv[i],"-p") || !strcmp(argv[i],"--port")) && i+1<argc) { if (parse_u16(argv[++i], "--port <PORT>", &remote_port)<0) return 2; }
        else if ((!strcmp(argv[i],"-s") || !strcmp(argv[i],"--secret")) && i+1<argc) secret = argv[++i];
        else if (argv[i][0]=='-') { fprintf(stderr,"error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", argv[i]); return 2; }
        else { if (parse_u16(argv[i], "<LOCAL_PORT>", &local_port)<0) return 2; }
    }
    if (!to || !*to || local_port < 0) {
        fprintf(stderr,"error: the following required arguments were not provided:\n");
        if (!to || !*to) fprintf(stderr,"  --to <TO>\n");
        if (local_port < 0) fprintf(stderr,"  <LOCAL_PORT>\n");
        fprintf(stderr,"\nUsage: executable local --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.\n");
        return 2;
    }
    int ctl = connect_host(to, CONTROL_PORT);
    if (ctl < 0) { fprintf(stderr,"Error: could not connect to %s:%d\n", to, CONTROL_PORT); return 1; }
    char line[1024]; snprintf(line, sizeof line, "HELLO %d %s\n", remote_port, secret?secret:"");
    if (write_all(ctl, line, strlen(line)) < 0) return 1;
    size_t pos=0; char c;
    while (pos+1<sizeof line && read(ctl,&c,1)==1) { line[pos++]=c; if(c=='\n') break; }
    line[pos]=0;
    if (strncmp(line,"OK ",3)!=0) { fprintf(stderr,"Error: %s", line[0]?line:"server rejected connection\n"); return 1; }
    int assigned = atoi(line+3);
    fprintf(stderr,"INFO bore_cli::client: connected to server remote_port=%d\n", assigned);
    fprintf(stderr,"INFO bore_cli::client: listening at 127.0.0.1:%d\n", assigned);
    ConnMap conns = {0}; unsigned char buf[BUF_SIZE];
    for (;;) {
        fd_set rfds; FD_ZERO(&rfds); FD_SET(ctl,&rfds); int maxfd=ctl;
        for (size_t i=0;i<conns.len;i++) { FD_SET(conns.items[i].fd,&rfds); if(conns.items[i].fd>maxfd) maxfd=conns.items[i].fd; }
        if (select(maxfd+1,&rfds,NULL,NULL,NULL) < 0) { if(errno==EINTR) continue; break; }
        if (FD_ISSET(ctl,&rfds)) {
            char type; uint32_t id,len;
            if (recv_frame(ctl,&type,&id,buf,&len)<0) break;
            if (type=='O') {
                int fd = connect_host(local_host, local_port);
                if (fd < 0) send_frame(ctl,'C',id,NULL,0); else add_conn(&conns,id,fd);
            } else if (type=='D') {
                int fd = find_conn(&conns,id); if (fd>=0 && write_all(fd,buf,len)<0) { remove_conn(&conns,id); send_frame(ctl,'C',id,NULL,0); }
            } else if (type=='C') remove_conn(&conns,id);
        }
        for (size_t i=0;i<conns.len;) {
            int fd = conns.items[i].fd; uint32_t id = conns.items[i].id;
            if (!FD_ISSET(fd,&rfds)) { i++; continue; }
            ssize_t n = read(fd, buf, sizeof buf);
            if (n <= 0) { remove_conn(&conns,id); send_frame(ctl,'C',id,NULL,0); }
            else { if (send_frame(ctl,'D',id,buf,(uint32_t)n)<0) return 1; i++; }
        }
    }
    return 1;
}

static int read_line(int fd, char *line, size_t cap) {
    size_t pos=0; char c;
    while (pos+1<cap) {
        ssize_t n=read(fd,&c,1); if(n<=0) return -1;
        line[pos++]=c; if(c=='\n') break;
    }
    line[pos]=0; return 0;
}

static int choose_listener(const char *addr, int requested, int minp, int maxp, int *port_out) {
    if (requested) {
        if (requested < minp || requested > maxp) return -1;
        int fd=listen_addr(addr,requested); if(fd>=0) *port_out=requested; return fd;
    }
    for (int p=minp;p<=maxp;p++) { int fd=listen_addr(addr,p); if(fd>=0){*port_out=p; return fd;} }
    return -1;
}

static int run_server(int argc, char **argv) {
    int minp = getenv("BORE_MIN_PORT") ? atoi(getenv("BORE_MIN_PORT")) : 1024;
    int maxp = getenv("BORE_MAX_PORT") ? atoi(getenv("BORE_MAX_PORT")) : 65535;
    const char *secret = getenv("BORE_SECRET"), *bind_addr="0.0.0.0", *bind_tunnels=NULL;
    for (int i=2;i<argc;i++) {
        if (!strcmp(argv[i],"-h") || !strcmp(argv[i],"--help")) { print_server_help(); return 0; }
        else if (!strcmp(argv[i],"--min-port") && i+1<argc) { if(parse_u16(argv[++i],"--min-port <MIN_PORT>",&minp)<0)return 2; }
        else if (!strcmp(argv[i],"--max-port") && i+1<argc) { if(parse_u16(argv[++i],"--max-port <MAX_PORT>",&maxp)<0)return 2; }
        else if ((!strcmp(argv[i],"-s") || !strcmp(argv[i],"--secret")) && i+1<argc) secret=argv[++i];
        else if (!strcmp(argv[i],"--bind-addr") && i+1<argc) bind_addr=argv[++i];
        else if (!strcmp(argv[i],"--bind-tunnels") && i+1<argc) bind_tunnels=argv[++i];
        else { fprintf(stderr,"error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", argv[i]); return 2; }
    }
    if (minp > maxp) { fprintf(stderr,"error: port range is empty\n\nUsage: bore-cli <COMMAND>\n\nFor more information, try '--help'.\n"); return 2; }
    if (!bind_tunnels) bind_tunnels = bind_addr;
    int srv = listen_addr(bind_addr, CONTROL_PORT);
    if (srv < 0) { perror("bind"); return 1; }
    fprintf(stderr,"INFO bore_cli::server: server listening addr=%s\n", bind_addr);
    for (;;) {
        int ctl = accept(srv,NULL,NULL); if (ctl<0) continue;
        char line[1024], gotsec[512]=""; int req=0;
        if (read_line(ctl,line,sizeof line)<0 || sscanf(line,"HELLO %d %511[^\n]",&req,gotsec)<1) { close(ctl); continue; }
        if (secret && *secret && strcmp(secret, gotsec)) { write_all(ctl,"ERR unauthorized\n",17); close(ctl); continue; }
        int assigned=0, pub=choose_listener(bind_tunnels,req,minp,maxp,&assigned);
        if (pub<0) { write_all(ctl,"ERR could not listen\n",21); close(ctl); continue; }
        char ok[64]; snprintf(ok,sizeof ok,"OK %d\n",assigned); write_all(ctl,ok,strlen(ok));
        ConnMap conns={0}; uint32_t next_id=1; unsigned char buf[BUF_SIZE];
        for (;;) {
            fd_set rfds; FD_ZERO(&rfds); FD_SET(ctl,&rfds); FD_SET(pub,&rfds); int maxfd = ctl>pub?ctl:pub;
            for(size_t i=0;i<conns.len;i++){FD_SET(conns.items[i].fd,&rfds); if(conns.items[i].fd>maxfd)maxfd=conns.items[i].fd;}
            if(select(maxfd+1,&rfds,NULL,NULL,NULL)<0){ if(errno==EINTR)continue; break; }
            if(FD_ISSET(pub,&rfds)){ int fd=accept(pub,NULL,NULL); if(fd>=0){ uint32_t id=next_id++; add_conn(&conns,id,fd); if(send_frame(ctl,'O',id,NULL,0)<0) { close(fd); break; } } }
            if(FD_ISSET(ctl,&rfds)){ char type; uint32_t id,len; if(recv_frame(ctl,&type,&id,buf,&len)<0) break; if(type=='D'){int fd=find_conn(&conns,id); if(fd>=0 && write_all(fd,buf,len)<0){remove_conn(&conns,id); send_frame(ctl,'C',id,NULL,0);}} else if(type=='C') remove_conn(&conns,id); }
            for(size_t i=0;i<conns.len;){ int fd=conns.items[i].fd; uint32_t id=conns.items[i].id; if(!FD_ISSET(fd,&rfds)){i++; continue;} ssize_t n=read(fd,buf,sizeof buf); if(n<=0){remove_conn(&conns,id); send_frame(ctl,'C',id,NULL,0);} else { if(send_frame(ctl,'D',id,buf,(uint32_t)n)<0) goto done_client; i++; } }
        }
done_client:
        for(size_t i=0;i<conns.len;i++) close(conns.items[i].fd);
        close(pub); close(ctl);
    }
}

int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);
    if (argc < 2) { print_root_help(); return 2; }
    if (!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")) { print_root_help(); return 0; }
    if (!strcmp(argv[1],"help")) {
        if (argc >= 3 && !strcmp(argv[2],"local")) print_local_help();
        else if (argc >= 3 && !strcmp(argv[2],"server")) print_server_help();
        else print_root_help();
        return 0;
    }
    if (!strcmp(argv[1],"-V") || !strcmp(argv[1],"--version")) { printf("bore-cli 0.6.0\n"); return 0; }
    if (!strcmp(argv[1],"local")) return run_local(argc, argv);
    if (!strcmp(argv[1],"server")) return run_server(argc, argv);
    fprintf(stderr,"error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", argv[1]);
    return 2;
}
