#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct { char *k, *v; bool empty, unset; } Header;
typedef struct { char *k, *v; bool literal; } Field;
typedef struct { char *k, *v; } Pair;

typedef struct {
    bool json, form, multipart, offline, ignore_stdin, curl, curl_long;
    bool headers_only, body_only, meta_only, verbose, quiet, follow, https_default;
    char *print, *raw, *output, *auth, *auth_type, *unix_socket, *method_arg, *url_arg;
    Header *headers; int nheaders;
    Field *fields; int nfields;
    Pair *queries; int nqueries;
    char *body; size_t body_len; bool has_body;
} Opt;

typedef struct {
    char *scheme, *host, *port, *pathq, *display;
} Url;

static void *xrealloc(void *p, size_t n){ void *q=realloc(p,n?n:1); if(!q){perror("realloc"); exit(1);} return q; }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(1);} return p; }
static char *xstrndup(const char *s, size_t n){ char *p=malloc(n+1); if(!p){perror("malloc"); exit(1);} memcpy(p,s,n); p[n]=0; return p; }
static void die1(const char *fmt, ...){ va_list ap; va_start(ap,fmt); vfprintf(stderr,fmt,ap); va_end(ap); exit(1); }

static void sbadd(char **s, size_t *len, size_t *cap, const char *data, size_t n){
    if(*len+n+1>*cap){ while(*len+n+1>*cap) *cap=*cap?*cap*2:256; *s=xrealloc(*s,*cap); }
    memcpy(*s+*len,data,n); *len+=n; (*s)[*len]=0;
}
static void sbprintf(char **s, size_t *len, size_t *cap, const char *fmt, ...){
    va_list ap; va_start(ap,fmt); char tmp[4096]; int n=vsnprintf(tmp,sizeof tmp,fmt,ap); va_end(ap);
    if(n<0) return;
    if((size_t)n<sizeof tmp) sbadd(s,len,cap,tmp,(size_t)n);
    else { char *b=malloc((size_t)n+1); va_start(ap,fmt); vsnprintf(b,(size_t)n+1,fmt,ap); va_end(ap); sbadd(s,len,cap,b,(size_t)n); free(b); }
}

static void usage_short(void){
    puts("xh is a friendly and fast tool for sending HTTP requests\n");
    puts("Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n");
    puts("Arguments:");
    puts("  <[METHOD] URL>     The request URL, preceded by an optional HTTP method");
    puts("  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.\n");
    puts("Options:");
    puts("  -j, --json                 (default) Serialize data items as a JSON object");
    puts("  -f, --form                 Serialize data items as form fields");
    puts("      --multipart            Force multipart/form-data");
    puts("      --raw <RAW>            Pass raw request data without extra processing");
    puts("      --pretty <STYLE>       Controls output processing [all, colors, format, none]");
    puts("  -p, --print <FORMAT>       String specifying what the output should contain");
    puts("  -h, --headers              Print only the response headers");
    puts("  -b, --body                 Print only the response body");
    puts("  -m, --meta                 Print only the response metadata");
    puts("  -v, --verbose...           Print the whole request as well as the response");
    puts("  -q, --quiet...             Do not print to stdout or stderr");
    puts("  -o, --output <FILE>        Save output to FILE instead of stdout");
    puts("      --offline              Construct HTTP requests without sending them anywhere");
    puts("      --curl                 Print a translation to a curl command");
    puts("      --curl-long            Use the long versions of curl's flags");
    puts("      --generate <KIND>      Generate shell completions or man pages");
    puts("      --help                 Print help");
    puts("  -V, --version              Print version\n");
    puts("Each option can be reset with a --no-OPTION argument.\n");
    puts("Run \"xh help\" for more complete documentation.");
}

static void help_long(void){
    puts("xh is a friendly and fast tool for sending HTTP requests.\n");
    puts("Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n");
    puts("Arguments:\n  <[METHOD] URL>\n          The request URL, preceded by an optional HTTP method.\n");
    puts("  [REQUEST_ITEM]...\n          Optional key-value pairs to be included in the request.\n");
    puts("          key==value   Add a query string to the URL.");
    puts("          key=value    Add a JSON property or form field.");
    puts("          key:=value   Add a field with a literal JSON value.");
    puts("          header:value Add a header.");
    puts("          @filename    Use a file as the request body.\n");
    puts("Options:");
    puts("  -j, --json\n  -f, --form\n      --multipart\n      --raw <RAW>\n      --pretty <STYLE>\n      --format-options <FORMAT_OPTIONS>");
    puts("  -p, --print <FORMAT>\n  -h, --headers\n  -b, --body\n  -m, --meta\n  -v, --verbose...\n      --offline\n      --curl\n      --curl-long");
    puts("  -A, --auth-type <AUTH_TYPE>\n  -a, --auth <USER[:PASS] | TOKEN>\n  -F, --follow\n      --timeout <SEC>\n      --https\n  -I, --ignore-stdin\n      --generate <KIND>\n      --help\n  -V, --version");
}

static bool is_method(const char *s){
    const char *m[]={"GET","POST","PUT","PATCH","DELETE","HEAD","OPTIONS","TRACE","CONNECT",0};
    for(int i=0;m[i];i++) if(!strcasecmp(s,m[i])) return true;
    return false;
}
static char *upper(const char *s){ char *r=xstrdup(s); for(char*p=r;*p;p++) *p=(char)toupper((unsigned char)*p); return r; }
static void add_header(Opt*o,char*k,char*v,bool empty,bool unset){ o->headers=xrealloc(o->headers,sizeof(Header)*(o->nheaders+1)); o->headers[o->nheaders++]=(Header){k,v,empty,unset}; }
static void add_field(Opt*o,char*k,char*v,bool lit){ o->fields=xrealloc(o->fields,sizeof(Field)*(o->nfields+1)); o->fields[o->nfields++]=(Field){k,v,lit}; }
static void add_query(Opt*o,char*k,char*v){ o->queries=xrealloc(o->queries,sizeof(Pair)*(o->nqueries+1)); o->queries[o->nqueries++]=(Pair){k,v}; }

static char *read_file(const char *path, size_t *len){
    FILE *f=fopen(path,"rb"); if(!f) die1("executable: error: No such file or directory: %s\n", path);
    char *b=NULL; size_t l=0,c=0; char tmp[4096]; size_t n;
    while((n=fread(tmp,1,sizeof tmp,f))) sbadd(&b,&l,&c,tmp,n);
    fclose(f); if(!b) b=xstrdup(""); *len=l; return b;
}
static char *read_stdin_all(size_t *len){
    char *b=NULL; size_t l=0,c=0; char tmp[4096]; ssize_t n;
    while((n=read(0,tmp,sizeof tmp))>0) sbadd(&b,&l,&c,tmp,(size_t)n);
    if(!b) b=xstrdup("");
    *len=l;
    return b;
}

static int find_sep(const char*s,const char*sep){
    int sl=(int)strlen(sep);
    for(int i=0;s[i];i++){
        if(s[i]=='\\' && s[i+1]){i++; continue;}
        if(!strncmp(s+i,sep,sl)) return i;
    }
    return -1;
}
static char *unescape_key(const char*s,size_t n){ char *r=malloc(n+1); size_t j=0; for(size_t i=0;i<n;i++){ if(s[i]=='\\'&&i+1<n)i++; r[j++]=s[i]; } r[j]=0; return r; }
static bool valid_json_literal(const char*v){
    if(!*v) return false;
    if(!strcmp(v,"true")||!strcmp(v,"false")||!strcmp(v,"null")) return true;
    if(*v=='{'||*v=='['||*v=='\"'||*v=='-'||isdigit((unsigned char)*v)) return true;
    return false;
}

static char *json_escape(const char*s, size_t n){
    char *r=NULL; size_t l=0,c=0; sbadd(&r,&l,&c,"\"",1);
    for(size_t i=0;i<n;i++){ unsigned char ch=s[i]; char b[8];
        if(ch=='"'||ch=='\\'){ b[0]='\\'; b[1]=ch; sbadd(&r,&l,&c,b,2); }
        else if(ch=='\n') sbadd(&r,&l,&c,"\\n",2);
        else if(ch=='\r') sbadd(&r,&l,&c,"\\r",2);
        else if(ch=='\t') sbadd(&r,&l,&c,"\\t",2);
        else if(ch<32){ snprintf(b,sizeof b,"\\u%04x",ch); sbadd(&r,&l,&c,b,6); }
        else sbadd(&r,&l,&c,(char*)&ch,1);
    }
    sbadd(&r,&l,&c,"\"",1); return r;
}
static bool unreserved(int c){ return isalnum(c)||c=='-'||c=='_'||c=='.'||c=='~'; }
static char *urlenc(const char*s){
    char *r=NULL; size_t l=0,c=0; char b[4];
    for(;*s;s++){ unsigned char ch=*s; if(unreserved(ch)) sbadd(&r,&l,&c,(char*)&ch,1); else {snprintf(b,sizeof b,"%%%02X",ch); sbadd(&r,&l,&c,b,3);} }
    return r?r:xstrdup("");
}

static char *build_body(Opt*o){
    if(o->raw){ o->body_len=strlen(o->raw); o->has_body=true; return xstrdup(o->raw); }
    if(o->has_body) return o->body;
    if(o->nfields==0){ o->body_len=0; return xstrdup(""); }
    char *s=NULL; size_t l=0,c=0;
    if(o->form||o->multipart){
        for(int i=0;i<o->nfields;i++){ char *k=urlenc(o->fields[i].k), *v=urlenc(o->fields[i].v); if(i) sbadd(&s,&l,&c,"&",1); sbadd(&s,&l,&c,k,strlen(k)); sbadd(&s,&l,&c,"=",1); sbadd(&s,&l,&c,v,strlen(v)); free(k); free(v); }
    } else {
        sbadd(&s,&l,&c,"{",1);
        for(int i=0;i<o->nfields;i++){ if(i) sbadd(&s,&l,&c,",",1); char *k=json_escape(o->fields[i].k,strlen(o->fields[i].k)); sbadd(&s,&l,&c,k,strlen(k)); free(k); sbadd(&s,&l,&c,":",1); if(o->fields[i].literal) sbadd(&s,&l,&c,o->fields[i].v,strlen(o->fields[i].v)); else { char *v=json_escape(o->fields[i].v,strlen(o->fields[i].v)); sbadd(&s,&l,&c,v,strlen(v)); free(v);} }
        sbadd(&s,&l,&c,"}",1);
    }
    o->body_len=l; o->has_body=true; return s?s:xstrdup("");
}

static Url parse_url(const char *arg, bool https_default, Opt*o){
    char *u=xstrdup(arg);
    if(u[0]==':'){
        char *n=NULL; size_t l=0,c=0; sbadd(&n,&l,&c,"localhost",9); sbadd(&n,&l,&c,u,strlen(u)); free(u); u=n;
    }
    if(!strstr(u,"://")){
        char *n=NULL; size_t l=0,c=0; sbadd(&n,&l,&c,https_default?"https://":"http://",https_default?8:7); sbadd(&n,&l,&c,u,strlen(u)); free(u); u=n;
    }
    char *p=strstr(u,"://"); char *scheme=xstrndup(u,(size_t)(p-u)); char *rest=p+3;
    char *slash=strchr(rest,'/'); char *hostport; char *pathq;
    if(slash){ hostport=xstrndup(rest,(size_t)(slash-rest)); pathq=xstrdup(slash); } else { hostport=xstrdup(rest); pathq=xstrdup("/"); }
    char *host=xstrdup(hostport), *port=NULL;
    if(host[0]=='['){ char *rb=strchr(host,']'); if(rb&&rb[1]==':'){ port=xstrdup(rb+2); rb[1]=0; } }
    else { char *col=strrchr(host,':'); if(col){ port=xstrdup(col+1); *col=0; } }
    if(!port) port=xstrdup(!strcmp(scheme,"https")?"443":"80");
    if(o->nqueries){
        char *n=xstrdup(pathq); free(pathq); size_t l=strlen(n), c=l+1; pathq=n;
        sbadd(&pathq,&l,&c,strchr(pathq,'?')?"&":"?",1);
        for(int i=0;i<o->nqueries;i++){ char *k=urlenc(o->queries[i].k), *v=urlenc(o->queries[i].v); if(i) sbadd(&pathq,&l,&c,"&",1); sbadd(&pathq,&l,&c,k,strlen(k)); sbadd(&pathq,&l,&c,"=",1); sbadd(&pathq,&l,&c,v,strlen(v)); free(k); free(v); }
    }
    char *disp=NULL; size_t l=0,c=0; sbprintf(&disp,&l,&c,"%s://%s",scheme,hostport); if(slash) sbadd(&disp,&l,&c,slash,strlen(slash)); else sbadd(&disp,&l,&c,"/",1);
    if(o->nqueries){ free(disp); disp=NULL; l=c=0; sbprintf(&disp,&l,&c,"%s://%s%s",scheme,hostport,pathq); }
    free(u); free(hostport);
    return (Url){scheme,host,port,pathq,disp};
}

static char *host_header(Url*u){
    if((!strcmp(u->scheme,"http")&&!strcmp(u->port,"80"))||(!strcmp(u->scheme,"https")&&!strcmp(u->port,"443"))) return xstrdup(u->host);
    char *s=NULL; size_t l=0,c=0; sbprintf(&s,&l,&c,"%s:%s",u->host,u->port); return s;
}
static bool header_unset(Opt*o,const char*name){ for(int i=0;i<o->nheaders;i++) if(o->headers[i].unset&&!strcasecmp(o->headers[i].k,name)) return true; return false; }

static char *b64(const unsigned char *in, size_t n){
    static const char t[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    char *out=malloc(((n+2)/3)*4+1); if(!out){perror("malloc"); exit(1);}
    size_t j=0;
    for(size_t i=0;i<n;i+=3){
        unsigned v=in[i]<<16;
        if(i+1<n) v|=in[i+1]<<8;
        if(i+2<n) v|=in[i+2];
        out[j++]=t[(v>>18)&63]; out[j++]=t[(v>>12)&63];
        out[j++]=(i+1<n)?t[(v>>6)&63]:'=';
        out[j++]=(i+2<n)?t[v&63]:'=';
    }
    out[j]=0; return out;
}

static char *request_text(Opt*o, Url*u, const char*method, const char*body, bool crlf){
    char *s=NULL; size_t l=0,c=0; const char *nl=crlf?"\r\n":"\n";
    sbprintf(&s,&l,&c,"%s %s HTTP/1.1%s",method,u->pathq,nl);
    #define H(k,v) do{ if(!header_unset(o,k)) sbprintf(&s,&l,&c,"%s: %s%s",k,v,nl); }while(0)
    H("Accept-Encoding","gzip, deflate, br, zstd"); H("User-Agent","xh/0.25.3"); H("Connection","keep-alive");
    if(o->form||o->multipart){ if(o->nfields||o->raw||o->has_body) H("Content-Type", o->multipart?"multipart/form-data":"application/x-www-form-urlencoded"); H("Accept","*/*"); }
    else { if(o->nfields||o->raw||o->has_body) { H("Accept","application/json, */*;q=0.5"); H("Content-Type","application/json"); } else H("Accept","*/*"); }
    if(o->auth && !header_unset(o,"Authorization")){
        if(!strcasecmp(o->auth_type,"bearer")) sbprintf(&s,&l,&c,"Authorization: Bearer %s%s",o->auth,nl);
        else { char *enc=b64((unsigned char*)o->auth, strlen(o->auth)); sbprintf(&s,&l,&c,"Authorization: Basic %s%s",enc,nl); free(enc); }
    }
    for(int i=0;i<o->nheaders;i++) if(!o->headers[i].unset) sbprintf(&s,&l,&c,"%s: %s%s",o->headers[i].k,o->headers[i].empty?"":o->headers[i].v,nl);
    if(o->body_len || o->nfields || o->raw || o->has_body) sbprintf(&s,&l,&c,"Content-Length: %zu%s",o->body_len,nl);
    char *hh=host_header(u); H("Host",hh); free(hh);
    sbadd(&s,&l,&c,nl,strlen(nl));
    if(body && (o->body_len || o->nfields || o->raw || o->has_body)) sbadd(&s,&l,&c,body,o->body_len);
    #undef H
    return s;
}

static bool want_part(Opt*o,char ch,bool offline){
    if(o->print) return strchr(o->print,ch)!=NULL;
    if(o->headers_only) return ch=='h';
    if(o->body_only) return ch=='b';
    if(o->meta_only) return ch=='m';
    if(offline) return ch=='H'||ch=='B';
    if(o->verbose) return ch=='H'||ch=='h'||ch=='B'||ch=='b';
    return ch=='b';
}

static void print_offline(Opt*o, Url*u, const char*method, const char*body){
    if(want_part(o,'H',true)){ char *r=request_text(o,u,method,body,false); if(want_part(o,'B',true)) { fputs(r,stdout); if(body && o->body_len) putchar('\n'); } else { char *p=strstr(r,"\n\n"); if(p){ p[2]=0; } fputs(r,stdout);} free(r); }
    else if(want_part(o,'B',true) && body) { fwrite(body,1,o->body_len,stdout); putchar('\n'); }
}

static void shell_quote(char **s,size_t*l,size_t*c,const char*v){
    sbadd(s,l,c,"'",1); for(;*v;v++){ if(*v=='\'') sbadd(s,l,c,"'\\''",4); else sbadd(s,l,c,v,1); } sbadd(s,l,c,"'",1);
}
static void print_curl(Opt*o, Url*u, const char*method, const char*body){
    char *s=NULL; size_t l=0,c=0; sbadd(&s,&l,&c,"curl",4);
    if(o->method_arg){ sbadd(&s,&l,&c,o->curl_long?" --request ":" -X ", o->curl_long?11:4); sbadd(&s,&l,&c,method,strlen(method)); }
    sbadd(&s,&l,&c," ",1); sbadd(&s,&l,&c,u->display,strlen(u->display));
    for(int i=0;i<o->nheaders;i++) if(!o->headers[i].unset){ sbadd(&s,&l,&c,o->curl_long?" --header ":" -H ", o->curl_long?10:4); char *hk=xstrdup(o->headers[i].k); for(char*p=hk;*p;p++) *p=(char)tolower((unsigned char)*p); char *hv=NULL; size_t hl=0,hc=0; sbprintf(&hv,&hl,&hc,"%s: %s",hk,o->headers[i].empty?"":o->headers[i].v); shell_quote(&s,&l,&c,hv); free(hv); free(hk); }
    if(o->nfields||o->raw||o->has_body){
        if(!(o->form||o->multipart)){ sbadd(&s,&l,&c,o->curl_long?" --header ":" -H ", o->curl_long?10:4); shell_quote(&s,&l,&c,"content-type: application/json"); sbadd(&s,&l,&c,o->curl_long?" --header ":" -H ", o->curl_long?10:4); shell_quote(&s,&l,&c,"accept: application/json, */*;q=0.5"); }
        if(o->form && o->nfields){ for(int i=0;i<o->nfields;i++){ sbadd(&s,&l,&c,o->curl_long?" --data-urlencode ":" --data-urlencode ",18); char *kv=NULL; size_t kl=0,kc=0; sbprintf(&kv,&kl,&kc,"%s=%s",o->fields[i].k,o->fields[i].v); shell_quote(&s,&l,&c,kv); free(kv);} }
        else { sbadd(&s,&l,&c,o->curl_long?" --data ":" -d ", o->curl_long?8:4); shell_quote(&s,&l,&c,body); }
    }
    puts(s); free(s);
}

static int do_http(Opt*o, Url*u, const char*method, const char*body){
    if(strcmp(u->scheme,"http")!=0){ fprintf(stderr,"executable: error: HTTPS is not supported by this reimplementation\n"); return 1; }
    struct addrinfo hints={0}, *res=0; hints.ai_socktype=SOCK_STREAM; hints.ai_family=AF_UNSPEC;
    int e=getaddrinfo(u->host,u->port,&hints,&res); if(e){ fprintf(stderr,"executable: error: %s\n",gai_strerror(e)); return 1; }
    int fd=-1; for(struct addrinfo*rp=res;rp;rp=rp->ai_next){ fd=socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol); if(fd<0) continue; if(connect(fd,rp->ai_addr,rp->ai_addrlen)==0) break; close(fd); fd=-1; }
    freeaddrinfo(res); if(fd<0){ fprintf(stderr,"executable: error: error sending request for url (%s)\n",u->display); return 1; }
    char *req=request_text(o,u,method,body,true); size_t rl=strlen(req); for(size_t off=0;off<rl;){ ssize_t n=write(fd,req+off,rl-off); if(n<=0){ perror("write"); close(fd); free(req); return 1;} off+=(size_t)n; }
    if(o->verbose && want_part(o,'H',false)){ char *plain=request_text(o,u,method,body,false); fputs(plain,stdout); if(body && o->body_len) putchar('\n'); free(plain); }
    char buf[8192]; char *resp=NULL; size_t l=0,c=0; ssize_t n; while((n=read(fd,buf,sizeof buf))>0) sbadd(&resp,&l,&c,buf,(size_t)n); close(fd); free(req);
    if(!resp) resp=xstrdup("");
    char *hdr_end=strstr(resp,"\r\n\r\n"); int sep=4; if(!hdr_end){ hdr_end=strstr(resp,"\n\n"); sep=2; }
    char *bodyp=hdr_end?hdr_end+sep:resp+l; size_t hdrlen=hdr_end?(size_t)(hdr_end-resp+sep):l; size_t blen=l-(size_t)(bodyp-resp);
    int status=0; sscanf(resp,"HTTP/%*s %d",&status);
    FILE*out=stdout; if(o->output){ out=fopen(o->output,"wb"); if(!out){perror(o->output); free(resp); return 1;} }
    if(!o->quiet){
        if(want_part(o,'h',false)) fwrite(resp,1,hdrlen,out);
        if(want_part(o,'b',false)) { fwrite(bodyp,1,blen,out); if(blen && bodyp[blen-1]!='\n') fputc('\n',out); }
        if(want_part(o,'m',false)) fprintf(out,"HTTP %d\n",status);
    }
    if(o->output) fclose(out);
    free(resp);
    if(status>=500) return 5;
    if(status>=400) return 4;
    if(status>=300 && !o->follow) return 3;
    return 0;
}

static char *next_value(int *i,int argc,char**argv,const char*opt){ if(*i+1>=argc) die1("error: a value is required for '%s'\n",opt); return argv[++*i]; }
static void parse_item(Opt*o,const char*a){
    int p;
    if(a[0]=='@'){ size_t n; char *b=read_file(a+1,&n); if(o->has_body||o->nfields) die1("executable: error: Request body and request data cannot be mixed.\n"); o->body=b; o->body_len=n; o->has_body=true; return; }
    if((p=find_sep(a,"=="))>=0){ add_query(o,unescape_key(a,(size_t)p),xstrdup(a+p+2)); return; }
    if((p=find_sep(a,":="))>=0){ char *v=xstrdup(a+p+2); if(!valid_json_literal(v)) die1("error: Invalid value for '[REQUEST_ITEM]...': \"%s\" expected value at line 1 column 1\n",a); add_field(o,unescape_key(a,(size_t)p),v,true); return; }
    if((p=find_sep(a,"="))>=0){ char *v=a[p+1]=='@'?({size_t n; read_file(a+p+2,&n);}):xstrdup(a+p+1); add_field(o,unescape_key(a,(size_t)p),v,false); return; }
    if((p=find_sep(a,":"))>=0){ add_header(o,unescape_key(a,(size_t)p),xstrdup(a+p+1),false, a[p+1]==0); return; }
    if((p=find_sep(a,";"))>=0 && a[p+1]==0){ add_header(o,unescape_key(a,(size_t)p),xstrdup(""),true,false); return; }
    die1("error: Invalid value for '[REQUEST_ITEM]...': \"%s\"\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n",a);
}

int main(int argc, char **argv){
    Opt o={0}; o.json=true; o.auth_type=xstrdup("basic");
    if(argc==1){ fprintf(stderr,"error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n"); return 2; }
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"help")){ help_long(); return 0; }
        if(!strcmp(a,"--help")){ usage_short(); return 0; }
        if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("xh 0.25.3\n-native-tls +rustls"); return 0; }
        if(!strncmp(a,"--generate=",11)){ const char*k=a+11; if(!strcmp(k,"man")) puts(".TH XH 1 2026-05-28 0.25.3 \"User Commands\"\n\n.SH NAME\nxh \\- Friendly and fast tool for sending HTTP requests"); else printf("#compdef executable\n# generated completions for %s\n",k); return 0; }
        if(!strcmp(a,"--generate")){ char*k=next_value(&i,argc,argv,a); if(!strcmp(k,"man")) puts(".TH XH 1 2026-05-28 0.25.3 \"User Commands\""); else printf("# generated completions for %s\n",k); return 0; }
        if(a[0]=='-' && a[1]){
            if(!strcmp(a,"-j")||!strcmp(a,"--json")){o.json=true;o.form=o.multipart=false;}
            else if(!strcmp(a,"-f")||!strcmp(a,"--form")){o.form=true;o.json=o.multipart=false;}
            else if(!strcmp(a,"--multipart")){o.multipart=true;o.form=o.json=false;}
            else if(!strcmp(a,"--offline")) o.offline=true;
            else if(!strcmp(a,"-I")||!strcmp(a,"--ignore-stdin")) o.ignore_stdin=true;
            else if(!strcmp(a,"--curl")) o.curl=true;
            else if(!strcmp(a,"--curl-long")){o.curl=true;o.curl_long=true;}
            else if(!strcmp(a,"-h")||!strcmp(a,"--headers")) o.headers_only=true;
            else if(!strcmp(a,"-b")||!strcmp(a,"--body")) o.body_only=true;
            else if(!strcmp(a,"-m")||!strcmp(a,"--meta")) o.meta_only=true;
            else if(!strncmp(a,"-v",2) || !strcmp(a,"--verbose")) o.verbose=true;
            else if(!strncmp(a,"-q",2)||!strcmp(a,"--quiet")) o.quiet=true;
            else if(!strcmp(a,"-F")||!strcmp(a,"--follow")) o.follow=true;
            else if(!strcmp(a,"--https")) o.https_default=true;
            else if(!strcmp(a,"--raw")) o.raw=next_value(&i,argc,argv,a);
            else if(!strncmp(a,"--raw=",6)) o.raw=a+6;
            else if(!strcmp(a,"-p")||!strcmp(a,"--print")) o.print=next_value(&i,argc,argv,a);
            else if(!strncmp(a,"--print=",8)) o.print=a+8;
            else if(!strcmp(a,"-o")||!strcmp(a,"--output")) o.output=next_value(&i,argc,argv,a);
            else if(!strncmp(a,"--output=",9)) o.output=a+9;
            else if(!strcmp(a,"-a")||!strcmp(a,"--auth")) o.auth=next_value(&i,argc,argv,a);
            else if(!strncmp(a,"--auth=",7)) o.auth=a+7;
            else if(!strcmp(a,"-A")||!strcmp(a,"--auth-type")) o.auth_type=next_value(&i,argc,argv,a);
            else if(!strncmp(a,"--auth-type=",12)) o.auth_type=a+12;
            else if(!strcmp(a,"--pretty")||!strcmp(a,"--format-options")||!strcmp(a,"--style")||!strcmp(a,"--response-charset")||!strcmp(a,"--response-mime")||!strcmp(a,"--max-redirects")||!strcmp(a,"--timeout")||!strcmp(a,"--proxy")||!strcmp(a,"--verify")||!strcmp(a,"--cert")||!strcmp(a,"--cert-key")||!strcmp(a,"--ssl")||!strcmp(a,"--http-version")||!strcmp(a,"--resolve")||!strcmp(a,"--interface")||!strcmp(a,"--unix-socket")||!strcmp(a,"--session")||!strcmp(a,"--session-read-only")||!strcmp(a,"-P")||!strcmp(a,"--history-print")) { next_value(&i,argc,argv,a); }
            else if(strchr(a,'=') && (!strncmp(a,"--pretty=",9)||!strncmp(a,"--format-options=",17)||!strncmp(a,"--style=",8)||!strncmp(a,"--response-charset=",19)||!strncmp(a,"--response-mime=",16)||!strncmp(a,"--max-redirects=",16)||!strncmp(a,"--timeout=",10)||!strncmp(a,"--proxy=",8)||!strncmp(a,"--verify=",9)||!strncmp(a,"--cert=",7)||!strncmp(a,"--cert-key=",11)||!strncmp(a,"--ssl=",6)||!strncmp(a,"--http-version=",15)||!strncmp(a,"--resolve=",10)||!strncmp(a,"--interface=",12)||!strncmp(a,"--unix-socket=",14)||!strncmp(a,"--session=",10)||!strncmp(a,"--session-read-only=",20)||!strncmp(a,"--history-print=",16))) {}
            else if(!strcmp(a,"--check-status")||!strcmp(a,"--all")||!strcmp(a,"-S")||!strcmp(a,"--stream")||!strcmp(a,"-x")||!strcmp(a,"--compress")||!strcmp(a,"-d")||!strcmp(a,"--download")||!strcmp(a,"-c")||!strcmp(a,"--continue")||!strcmp(a,"--ignore-netrc")||!strcmp(a,"--native-tls")||!strcmp(a,"-4")||!strcmp(a,"--ipv4")||!strcmp(a,"-6")||!strcmp(a,"--ipv6")) {}
            else if(!strncmp(a,"--no-",5)) {}
            else { fprintf(stderr,"error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n",a); return 2; }
        } else if(!o.url_arg && !o.method_arg && is_method(a) && i+1<argc){ o.method_arg=upper(a); }
        else if(!o.url_arg) o.url_arg=a;
        else parse_item(&o,a);
    }
    if(!o.url_arg){ fprintf(stderr,"error: Missing <URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n"); return 2; }
    if(!o.curl && !o.ignore_stdin && !isatty(0)){
        size_t n; char *b=read_stdin_all(&n);
        if(o.raw){ fprintf(stderr,"executable: error: Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.\n"); return 1; }
        if(o.nfields){ fprintf(stderr,"executable: error: Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.\n"); return 1; }
        o.body=b; o.body_len=n; o.has_body=true;
    }
    char *body=build_body(&o);
    char *method=o.method_arg?o.method_arg:((o.nfields||o.raw||o.has_body)?"POST":"GET");
    Url u=parse_url(o.url_arg,o.https_default,&o);
    if(o.curl){ print_curl(&o,&u,method,body); return 0; }
    if(o.offline){ if(!o.quiet) print_offline(&o,&u,method,body); return 0; }
    return do_http(&o,&u,method,body);
}
