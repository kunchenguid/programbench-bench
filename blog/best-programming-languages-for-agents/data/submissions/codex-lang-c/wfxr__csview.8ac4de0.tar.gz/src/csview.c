#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <wchar.h>
#include <errno.h>

typedef struct { char **v; int n, cap; } Row;
typedef struct { Row *v; int n, cap; } Rows;
typedef enum { LEFT, CENTER, RIGHT } Align;
typedef enum { ST_NONE, ST_ASCII, ST_ASCII2, ST_SHARP, ST_ROUNDED, ST_REINF, ST_MARKDOWN, ST_GRID } Style;
typedef struct { int no_headers, number, padding, indent; long sniff; char delim; Style style; Align h_align, b_align; const char *file; } Opt;

static char *xstrdup2(const char *s){ char *p=strdup(s?s:""); if(!p){perror("malloc"); exit(1);} return p; }
static void row_add(Row *r, char *s){ if(r->n==r->cap){ r->cap=r->cap?r->cap*2:4; r->v=realloc(r->v,r->cap*sizeof(char*)); if(!r->v) exit(1);} r->v[r->n++]=s; }
static void rows_add(Rows *rs, Row r){ if(rs->n==rs->cap){ rs->cap=rs->cap?rs->cap*2:8; rs->v=realloc(rs->v,rs->cap*sizeof(Row)); if(!rs->v) exit(1);} rs->v[rs->n++]=r; }
static void sb_add(char **b,int *len,int *cap,int c){ if(*len+2>=*cap){ *cap=*cap?*cap*2:64; *b=realloc(*b,*cap); if(!*b) exit(1);} (*b)[(*len)++]=(char)c; (*b)[*len]=0; }

static void csv_error(int rec, long line, long byte, int got, int exp){
    fprintf(stderr,"csview: CSV error: record %d (line: %ld, byte: %ld): found record with %d fields, but the previous record has %d fields\n", rec,line,byte,got,exp);
}
static int finish_record(Rows *out, Row *cur, int *expected, int *recno, long line, long rec_byte){
    if(*expected<0) *expected=cur->n;
    else if(cur->n!=*expected){ csv_error(*recno,line,rec_byte,cur->n,*expected); return 1; }
    rows_add(out,*cur); *cur=(Row){0}; (*recno)++; return 0;
}

static int parse_csv(FILE *fp, char delim, Rows *out){
    Row cur={0}; char *field=NULL; int flen=0,fcap=0; int inq=0, afterq=0, any=0; long line=1, byte=0, rec_byte=0; int expected=-1, recno=0; int c;
    while((c=fgetc(fp))!=EOF){ byte++; any=1;
        if(inq){
            if(c=='"'){
                int n=fgetc(fp);
                if(n==EOF){ inq=0; afterq=1; break; }
                byte++;
                if(n=='"') sb_add(&field,&flen,&fcap,'"');
                else { inq=0; afterq=1; ungetc(n,fp); byte--; }
            } else { if(c=='\n') line++; sb_add(&field,&flen,&fcap,c); }
            continue;
        }
        if(afterq){
            if(c==delim){ row_add(&cur,xstrdup2(field?field:"")); flen=0; if(field) field[0]=0; afterq=0; }
            else if(c=='\n' || c=='\r'){
                if(c=='\r'){ int n=fgetc(fp); if(n!='\n' && n!=EOF) ungetc(n,fp); else if(n=='\n') byte++; }
                long errline=line; line++; row_add(&cur,xstrdup2(field?field:"")); flen=0; if(field) field[0]=0; afterq=0;
                if(finish_record(out,&cur,&expected,&recno,errline,rec_byte)) return 1; rec_byte=byte;
            } else if(c==' ' || c=='\t') { }
            else { sb_add(&field,&flen,&fcap,c); afterq=0; }
            continue;
        }
        if(c=='"' && flen==0){ inq=1; continue; }
        if(c==delim){ row_add(&cur,xstrdup2(field?field:"")); flen=0; if(field) field[0]=0; continue; }
        if(c=='\n' || c=='\r'){
            if(c=='\r'){ int n=fgetc(fp); if(n!='\n' && n!=EOF) ungetc(n,fp); else if(n=='\n') byte++; }
            long errline=line; line++;
            if(cur.n==0 && flen==0){ if(field) field[0]=0; rec_byte=byte; continue; }
            row_add(&cur,xstrdup2(field?field:"")); flen=0; if(field) field[0]=0;
            if(finish_record(out,&cur,&expected,&recno,errline,rec_byte)) return 1; rec_byte=byte; continue;
        }
        sb_add(&field,&flen,&fcap,c);
    }
    if(!any){
        rows_add(out,cur);
    } else if(inq || afterq || flen>0 || cur.n>0){
        row_add(&cur,xstrdup2(field?field:""));
        if(finish_record(out,&cur,&expected,&recno,line,rec_byte)) return 1;
    }
    free(field); return 0;
}

static int disp_width_n(const char *s, int *bytes_for, int limit){
    mbstate_t st; memset(&st,0,sizeof(st)); const char *p=s; int w=0, used=0;
    while(*p){ wchar_t wc; size_t n=mbrtowc(&wc,p,MB_CUR_MAX,&st); int cw;
        if(n==(size_t)-1 || n==(size_t)-2 || n==0){ n=1; memset(&st,0,sizeof(st)); cw=1; } else { cw=wcwidth(wc); if(cw<0) cw=0; }
        if(limit>=0 && w+cw>limit) break; w+=cw; p+=n; used=(int)(p-s);
    }
    if(bytes_for) *bytes_for=used; return w;
}
static int disp_width(const char *s){ return disp_width_n(s,NULL,-1); }
static void putn(char ch,int n){ for(int i=0;i<n;i++) putchar(ch); }
static void putsn(const char *s,int n){ for(int i=0;i<n;i++) fputs(s,stdout); }
static void indent(int n){ putn(' ',n); }
static void print_cell(const char *s,int inner,Align a){
    int b=0,w=disp_width_n(s,&b,inner); int rem=inner-w, l=0,r=0;
    if(a==LEFT) r=rem; else if(a==RIGHT) l=rem; else { l=rem/2; r=rem-l; }
    putn(' ',l); fwrite(s,1,b,stdout); putn(' ',r);
}

typedef struct { const char *tl,*tm,*tr,*ml,*mm,*mr,*bl,*bm,*br,*v,*h; } Border;
static Border border_for(Style st){
    if(st==ST_ASCII) return (Border){"+","+","+","+","+","+","+","+","+","|","-"};
    if(st==ST_ROUNDED) return (Border){"╭","┬","╮","├","┼","┤","╰","┴","╯","│","─"};
    if(st==ST_REINF) return (Border){"┏","┬","┓","├","┼","┤","┗","┴","┛","│","─"};
    return (Border){"┌","┬","┐","├","┼","┤","└","┴","┘","│","─"};
}
static void line_border(int *inner,int n,Border b,const char *l,const char *m,const char *r,int ind){ indent(ind); fputs(l,stdout); for(int i=0;i<n;i++){ putsn(b.h,inner[i]); fputs(i==n-1?r:m,stdout);} putchar('\n'); }
static void row_border(Row *row,int *w,int *inner,int n,Align a,Border b,int ind,int pad){ indent(ind); fputs(b.v,stdout); if(row->n==0){ fputs(b.v,stdout); putchar('\n'); return; } for(int i=0;i<n;i++){ putn(' ',pad); print_cell(i<row->n?row->v[i]:"",w[i],a); putn(' ',pad); (void)inner; fputs(b.v,stdout);} putchar('\n'); }
static void row_sep(Row *row,int *w,int n,Align a,const char *sep,int ind,int pad){ indent(ind); for(int i=0;i<n;i++){ putn(' ',pad); print_cell(i<row->n?row->v[i]:"",w[i],a); putn(' ',pad); if(i<n-1) fputs(sep,stdout);} putchar('\n'); }
static void rule_sep(int *inner,int n,const char *sep,int ind,int ends){ indent(ind); if(ends) fputs("|",stdout); for(int i=0;i<n;i++){ putn('-',inner[i]); if(i<n-1) fputs(sep,stdout);} if(ends) fputs("|",stdout); putchar('\n'); }

static char *numstr(int x){ char buf[32]; snprintf(buf,sizeof(buf),"%d",x); return xstrdup2(buf); }
static void add_numbers(Rows *rs,int no_headers){
    for(int i=0;i<rs->n;i++){ Row *r=&rs->v[i]; if(r->n==r->cap){ r->cap=r->cap?r->cap*2:4; r->v=realloc(r->v,r->cap*sizeof(char*)); if(!r->v) exit(1); }
        memmove(r->v+1,r->v,r->n*sizeof(char*)); r->n++; r->v[0]=(!no_headers && i==0)?xstrdup2("#"):numstr(no_headers?i+1:i); }
}

static void render(Rows *rs, Opt *o){
    if(o->number) add_numbers(rs,o->no_headers); int empty_table=(rs->n==1 && rs->v[0].n==0); int cols=(rs->n && rs->v[0].n>0)?rs->v[0].n:1; int *w=calloc(cols,sizeof(int));
    int sniff_rows=rs->n; if(o->sniff>0){ int head=o->no_headers?0:1; int allowed=head+(int)o->sniff; if(allowed<sniff_rows) sniff_rows=allowed; }
    for(int i=0;i<sniff_rows;i++) for(int j=0;j<cols && j<rs->v[i].n;j++){ int d=disp_width(rs->v[i].v[j]); if(d>w[j]) w[j]=d; }
    int *inner=calloc(cols,sizeof(int)); for(int j=0;j<cols;j++) inner[j]=empty_table?0:w[j]+2*o->padding;
    if(o->style==ST_NONE){ for(int i=0;i<rs->n;i++){ indent(o->indent); for(int j=0;j<cols;j++){ putn(' ',o->padding); print_cell(j<rs->v[i].n?rs->v[i].v[j]:"",w[j],(i==0&&!o->no_headers)?o->h_align:o->b_align); putn(' ',o->padding);} putchar('\n'); } }
    else if(o->style==ST_ASCII2){ for(int i=0;i<rs->n;i++){ row_sep(&rs->v[i],w,cols,(i==0&&!o->no_headers)?o->h_align:o->b_align,"|",o->indent,o->padding); if(i==0&&!o->no_headers&&!empty_table) rule_sep(inner,cols,"+",o->indent,0); } }
    else if(o->style==ST_MARKDOWN){ for(int i=0;i<rs->n;i++){ indent(o->indent); fputs("|",stdout); for(int j=0;j<cols;j++){ putn(' ',o->padding); print_cell(j<rs->v[i].n?rs->v[i].v[j]:"",w[j],(i==0&&!o->no_headers)?o->h_align:o->b_align); putn(' ',o->padding); fputs("|",stdout);} putchar('\n'); if(i==0&&!o->no_headers&&!empty_table) rule_sep(inner,cols,"|",o->indent,1); } }
    else { Border b=border_for(o->style); line_border(inner,cols,b,b.tl,b.tm,b.tr,o->indent); for(int i=0;i<rs->n;i++){ row_border(&rs->v[i],w,inner,cols,(i==0&&!o->no_headers)?o->h_align:o->b_align,b,o->indent,o->padding); if(i==0&&!o->no_headers&&!empty_table) line_border(inner,cols,b,b.ml,b.mm,b.mr,o->indent); } line_border(inner,cols,b,b.bl,b.bm,b.br,o->indent); }
    free(w); free(inner);
}

static void help(void){ puts("A high performance csv viewer with cjk/emoji support.\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]\n          File to view\n\nOptions:\n  -H, --no-headers\n          Specify that the input has no header row\n  -n, --number\n          Prepend a column of line numbers to the table\n  -t, --tsv\n          Use '\\t' as delimiter for tsv\n  -d, --delimiter <DELIMITER>\n          Specify the field delimiter [default: ,]\n  -s, --style <STYLE>\n          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,\n          rounded, reinforced, markdown, grid]\n  -p, --padding <PADDING>\n          Specify padding for table cell [default: 1]\n  -i, --indent <INDENT>\n          Specify global indent for table [default: 0]\n      --sniff <LIMIT>\n          Limit column widths sniffing to the specified number of rows. Specify \"0\" to cancel limit\n          [default: 1000]\n      --header-align <HEADER_ALIGN>\n          Specify the alignment of the table header [default: center] [possible values: left,\n          center, right]\n      --body-align <BODY_ALIGN>\n          Specify the alignment of the table body [default: left] [possible values: left, center,\n          right]\n  -P, --disable-pager\n          Disable pager\n  -h, --help\n          Print help\n  -V, --version\n          Print version"); }
static int parse_align(const char*s,Align*a){ if(!strcmp(s,"left"))*a=LEFT; else if(!strcmp(s,"center"))*a=CENTER; else if(!strcmp(s,"right"))*a=RIGHT; else return 1; return 0; }
static int parse_style(const char*s,Style*st){ const char *names[]={"none","ascii","ascii2","sharp","rounded","reinforced","markdown","grid"}; for(int i=0;i<8;i++) if(!strcmp(s,names[i])){*st=i; return 0;} return 1; }
static long parse_nonneg(const char*s,const char*name){ if(s[0]=='-'){ fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n",s,s,s); exit(2);} char *e; errno=0; long v=strtol(s,&e,10); if(errno||*e){ fprintf(stderr,"error: invalid value '%s' for '--%s <%s>': invalid digit found in string\n\nFor more information, try '--help'.\n",s,name,!strcmp(name,"padding")?"PADDING":(!strcmp(name,"indent")?"INDENT":"LIMIT")); exit(2);} return v; }

int main(int argc,char**argv){ if(!setlocale(LC_ALL,"C.UTF-8")) setlocale(LC_ALL,""); Opt o={0,0,1,0,1000,',',ST_SHARP,CENTER,LEFT,NULL};
    for(int i=1;i<argc;i++){ char *a=argv[i];
        if(!strcmp(a,"-h")||!strcmp(a,"--help")){ help(); return 0; } else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("csview 1.3.4"); return 0; }
        else if(!strcmp(a,"-H")||!strcmp(a,"--no-headers")) o.no_headers=1; else if(!strcmp(a,"-n")||!strcmp(a,"--number")) o.number=1; else if(!strcmp(a,"-t")||!strcmp(a,"--tsv")) o.delim='\t'; else if(!strcmp(a,"-P")||!strcmp(a,"--disable-pager")){}
        else if((!strcmp(a,"-d")||!strcmp(a,"--delimiter")) && i+1<argc){ char *v=argv[++i]; if(strlen(v)!=1){ fprintf(stderr,"error: invalid value '%s' for '--delimiter <DELIMITER>': too many characters in string\n\nFor more information, try '--help'.\n",v); return 2;} o.delim=v[0]; }
        else if((!strcmp(a,"-s")||!strcmp(a,"--style")) && i+1<argc){ char *v=argv[++i]; if(parse_style(v,&o.style)){ fprintf(stderr,"error: invalid value '%s' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]\n\nFor more information, try '--help'.\n",v); return 2; } }
        else if((!strcmp(a,"-p")||!strcmp(a,"--padding")) && i+1<argc) o.padding=(int)parse_nonneg(argv[++i],"padding");
        else if((!strcmp(a,"-i")||!strcmp(a,"--indent")) && i+1<argc) o.indent=(int)parse_nonneg(argv[++i],"indent");
        else if(!strcmp(a,"--sniff") && i+1<argc) o.sniff=parse_nonneg(argv[++i],"sniff");
        else if(!strcmp(a,"--header-align") && i+1<argc){ char *v=argv[++i]; if(parse_align(v,&o.h_align)){ fprintf(stderr,"error: invalid value '%s' for '--header-align <HEADER_ALIGN>'\n  [possible values: left, center, right]\n\nFor more information, try '--help'.\n",v); return 2; } }
        else if(!strcmp(a,"--body-align") && i+1<argc){ char *v=argv[++i]; if(parse_align(v,&o.b_align)){ fprintf(stderr,"error: invalid value '%s' for '--body-align <BODY_ALIGN>'\n  [possible values: left, center, right]\n\nFor more information, try '--help'.\n",v); return 2; } }
        else if(a[0]=='-'){ fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n",a,a,a); return 2; }
        else if(!o.file) o.file=a; else { fprintf(stderr,"error: unexpected argument '%s' found\n",a); return 2; }
    }
    FILE *fp=stdin; if(o.file){ fp=fopen(o.file,"rb"); if(!fp){ fprintf(stderr,"csview: %s (os error %d)\n",strerror(errno),errno); return 1; } }
    Rows rs={0}; int e=parse_csv(fp,o.delim,&rs); if(o.file) fclose(fp); if(e) return 1; render(&rs,&o); return 0; }
