#define _POSIX_C_SOURCE 200809L

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define VERSION "2025.89"
#define DEF_RECV_WINDOW 24576
#define MAX_RECV_WINDOW 10485760

static void logmsg(const char *fmt, ...) {
    va_list ap;
    time_t now = time(NULL);
    struct tm tmv;
    char tb[64];
    localtime_r(&now, &tmv);
    strftime(tb, sizeof(tb), "%b %e %H:%M:%S", &tmv);
    fprintf(stderr, "[%ld] %s ", (long)getpid(), tb);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
}

static void print_help(const char *argv0) {
    printf("Dropbear server v%s https://matt.ucc.asn.au/dropbear/dropbear.html\n", VERSION);
    printf("Usage: %s [options]\n", argv0);
    printf("-b bannerfile\tDisplay the contents of bannerfile before user login\n");
    printf("\t\t(default: none)\n");
    printf("-r keyfile      Specify hostkeys (repeatable)\n");
    printf("\t\tdefaults: \n");
    printf("\t\t- rsa /etc/dropbear/dropbear_rsa_host_key\n");
    printf("\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key\n");
    printf("\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key\n");
    printf("-D\t\tDirectory containing authorized_keys file\n");
    printf("-R\t\tCreate hostkeys as required\n");
    printf("-F\t\tDon't fork into background\n");
    printf("-e\t\tPass on server process environment to child process\n");
    printf("(Syslog support not compiled in, using stderr)\n");
    printf("-m\t\tDon't display the motd on login\n");
    printf("-w\t\tDisallow root logins\n");
    printf("-G\t\tRestrict logins to members of specified group\n");
    printf("-s\t\tDisable password logins\n");
    printf("-g\t\tDisable password logins for root\n");
    printf("-B\t\tAllow blank password logins\n");
    printf("-t\t\tEnable two-factor authentication (both password and public key required)\n");
    printf("-T\t\tMaximum authentication tries (default 10)\n");
    printf("-j\t\tDisable local port forwarding\n");
    printf("-k\t\tDisable remote port forwarding\n");
    printf("-a\t\tAllow connections to forwarded ports from any host\n");
    printf("-c command\tForce executed command\n");
    printf("-p [address:]port\n");
    printf("\t\tListen on specified tcp port (and optionally address),\n");
    printf("\t\tup to 10 can be specified\n");
    printf("\t\t(default port is 22 if none specified)\n");
    printf("-P PidFile\tCreate pid file PidFile\n");
    printf("\t\t(default /var/run/dropbear.pid)\n");
    printf("-l <interface>\n");
    printf("\t\tinterface to bind on\n");
    printf("-i\t\tStart for inetd\n");
    printf("-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)\n");
    printf("-K <keepalive>  (0 is never, default 0, in seconds)\n");
    printf("-I <idle_timeout>  (0 is never, default 0, in seconds)\n");
    printf("-z    disable QoS\n");
    printf("-V    Version\n");
}

static bool is_nonneg_int(const char *s) {
    if (!s || !*s) return false;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (!isdigit(*p)) return false;
    }
    return true;
}

static bool file_exists_nonempty(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0;
}

struct opts {
    const char *keys[32];
    int nkeys;
    bool auto_keys;
    bool inetd;
    const char *ports[16];
    int nports;
    const char *pidfile;
};

static int open_listener(const char *spec) {
    const char *host = NULL;
    const char *portstr = spec;
    char hostbuf[256];
    const char *colon = strrchr(spec, ':');
    if (colon) {
        size_t n = (size_t)(colon - spec);
        if (n >= sizeof(hostbuf)) n = sizeof(hostbuf) - 1;
        memcpy(hostbuf, spec, n);
        hostbuf[n] = 0;
        host = hostbuf;
        portstr = colon + 1;
    }
    long port = strtol(portstr, NULL, 10);
    if (port < 0 || port > 65535) port = 22;

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons((uint16_t)port);
    if (host && *host) {
        if (inet_pton(AF_INET, host, &a.sin_addr) != 1) a.sin_addr.s_addr = htonl(INADDR_ANY);
    } else {
        a.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    if (bind(fd, (struct sockaddr *)&a, sizeof(a)) != 0 || listen(fd, 16) != 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static void run_stub_server(const struct opts *o) {
    int fds[16], nfds = 0, maxfd = -1;
    const char *def = "22";
    int count = o->nports ? o->nports : 1;
    for (int i = 0; i < count && i < 16; i++) {
        const char *p = o->nports ? o->ports[i] : def;
        int fd = open_listener(p);
        if (fd >= 0) {
            fds[nfds++] = fd;
            if (fd > maxfd) maxfd = fd;
        }
    }
    if (o->pidfile) {
        FILE *fp = fopen(o->pidfile, "w");
        if (fp) {
            fprintf(fp, "%ld\n", (long)getpid());
            fclose(fp);
        }
    }
    if (nfds == 0) {
        logmsg("Early exit: No listening ports available.");
        exit(1);
    }
    signal(SIGTERM, SIG_DFL);
    signal(SIGINT, SIG_DFL);
    for (;;) {
        fd_set set;
        FD_ZERO(&set);
        for (int i = 0; i < nfds; i++) FD_SET(fds[i], &set);
        if (select(maxfd + 1, &set, NULL, NULL, NULL) < 0) continue;
        for (int i = 0; i < nfds; i++) {
            if (FD_ISSET(fds[i], &set)) {
                int c = accept(fds[i], NULL, NULL);
                if (c >= 0) {
                    const char *banner = "SSH-2.0-dropbear_" VERSION "\r\n";
                    ssize_t ignored = write(c, banner, strlen(banner));
                    (void)ignored;
                    close(c);
                }
            }
        }
    }
}

int main(int argc, char **argv) {
    struct opts o;
    memset(&o, 0, sizeof(o));

    for (int i = 1; i < argc; i++) {
        char *arg = argv[i];
        if (arg[0] != '-') {
            logmsg("Early exit: Invalid argument: %s", arg);
            return 1;
        }
        if (strcmp(arg, "-V") == 0 || strncmp(arg, "-V", 2) == 0) {
            printf("Dropbear v%s\n", VERSION);
            return 0;
        }
        if (strcmp(arg, "-h") == 0) {
            print_help(argv[0]);
            return 0;
        }
        if (arg[1] == '-') {
            printf("Invalid option --\n");
            print_help(argv[0]);
            return 1;
        }
        for (int pos = 1; arg[pos]; pos++) {
            char c = arg[pos];
            const char *val = NULL;
            bool takes = strchr("brDGTPplcWKI", c) != NULL;
            if (takes) {
                if (arg[pos + 1]) {
                    val = &arg[pos + 1];
                    pos = (int)strlen(arg) - 1;
                } else if (i + 1 < argc) {
                    val = argv[++i];
                } else {
                    logmsg("Early exit: Missing argument");
                    return 1;
                }
            }
            switch (c) {
                case 'b':
                    if (access(val, R_OK) != 0) logmsg("Error opening banner file '%s'", val);
                    break;
                case 'r':
                    if (o.nkeys < 32) o.keys[o.nkeys++] = val;
                    break;
                case 'D': case 'G': case 'c': case 'l':
                    (void)val;
                    break;
                case 'R':
                    o.auto_keys = true;
                    break;
                case 'F': case 'e': case 'm': case 'w': case 's': case 'g':
                case 'B': case 't': case 'j': case 'k': case 'a': case 'i':
                case 'z':
                    if (c == 'i') o.inetd = true;
                    break;
                case 'T':
                    if (!is_nonneg_int(val)) {
                        logmsg("Early exit: Bad maxauthtries '%s'", val);
                        return 1;
                    }
                    break;
                case 'W': {
                    char *end = NULL;
                    long v = strtol(val, &end, 10);
                    if (!val[0] || *end || v < 1) logmsg("Bad recv window '%s', using %d", val, DEF_RECV_WINDOW);
                    else if (v > MAX_RECV_WINDOW) logmsg("Bad recv window '%s', using %d", val, MAX_RECV_WINDOW);
                    break;
                }
                case 'K':
                    if (!is_nonneg_int(val)) {
                        logmsg("Early exit: Bad keepalive '%s'", val);
                        return 1;
                    }
                    break;
                case 'I':
                    if (!is_nonneg_int(val)) {
                        logmsg("Early exit: Bad idle_timeout '%s'", val);
                        return 1;
                    }
                    break;
                case 'p':
                    if (o.nports < 16) o.ports[o.nports++] = val;
                    break;
                case 'P':
                    o.pidfile = val;
                    break;
                default:
                    printf("Invalid option -%c\n", c);
                    print_help(argv[0]);
                    return 1;
            }
        }
    }

    if (o.inetd) {
        const char *banner = "SSH-2.0-dropbear_" VERSION "\r\n";
        ssize_t ignored = write(STDOUT_FILENO, banner, strlen(banner));
        (void)ignored;
        return 0;
    }

    int good_keys = 0;
    if (o.nkeys) {
        for (int i = 0; i < o.nkeys; i++) {
            if (file_exists_nonempty(o.keys[i])) {
                logmsg("Early exit: Bad buf_getptr");
                return 1;
            }
            logmsg("Failed loading %s", o.keys[i]);
        }
    } else if (!o.auto_keys) {
        const char *defs[] = {
            "/etc/dropbear/dropbear_rsa_host_key",
            "/etc/dropbear/dropbear_ecdsa_host_key",
            "/etc/dropbear/dropbear_ed25519_host_key"
        };
        for (size_t i = 0; i < sizeof(defs) / sizeof(defs[0]); i++) {
            if (file_exists_nonempty(defs[i])) good_keys++;
            else logmsg("Failed loading %s", defs[i]);
        }
    } else {
        good_keys = 1;
    }

    if (!good_keys && !o.auto_keys) {
        logmsg("Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
        return 1;
    }

    run_stub_server(&o);
    return 0;
}
