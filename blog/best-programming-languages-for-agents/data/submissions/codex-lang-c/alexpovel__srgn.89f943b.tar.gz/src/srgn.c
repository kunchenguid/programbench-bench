#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <glob.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct {
    char *data;
    size_t len, cap;
} Buf;

typedef struct {
    bool upper, lower, title, norm, german, symbols, delete_action, squeeze;
    bool invert, literal, fail_any, fail_none, fail_no_files, dry_run, sorted;
    bool german_naive, german_prefer_original, join_lang;
    char *scope, *replace, *glob_pat;
    char *lang_kind[16];
    int lang_count;
} Opt;

static void die(const char *s) { fprintf(stderr, "%s\n", s); exit(2); }
static void binit(Buf *b){ b->data=NULL; b->len=b->cap=0; }
static void bneed(Buf *b,size_t n){ if(n>b->cap){ size_t c=b->cap?b->cap*2:256; while(c<n)c*=2; b->data=realloc(b->data,c); if(!b->data)exit(2); b->cap=c; } }
static void baddn(Buf *b,const char*s,size_t n){ bneed(b,b->len+n+1); memcpy(b->data+b->len,s,n); b->len+=n; b->data[b->len]=0; }
static void badds(Buf *b,const char*s){ baddn(b,s,strlen(s)); }
static char *xstrndup(const char*s,size_t n){ char*r=malloc(n+1); if(!r)exit(2); memcpy(r,s,n); r[n]=0; return r; }

static char *read_stream(FILE *f, size_t *len){
    Buf b; binit(&b); char tmp[8192]; size_t n;
    while((n=fread(tmp,1,sizeof tmp,f))>0) baddn(&b,tmp,n);
    if(!b.data){ b.data=strdup(""); b.cap=1; }
    *len=b.len; return b.data;
}

static char *read_file(const char *path, size_t *len){
    FILE *f=fopen(path,"rb"); if(!f){ perror(path); return NULL; }
    char *s=read_stream(f,len); fclose(f); return s;
}
static int write_file(const char *path,const char *s,size_t n){
    FILE *f=fopen(path,"wb"); if(!f){ perror(path); return 1; }
    int ok=fwrite(s,1,n,f)==n?0:1; fclose(f); return ok;
}

static bool starts(const char *s,const char*p){ return strncmp(s,p,strlen(p))==0; }
static bool is_langopt(const char *a){
    const char *opts[]={"--python","--py","--rust","--rs","--go","--c","--csharp","--cs","--hcl","--typescript","--ts",
        "--python-query","--python-query-file","--rust-query","--rust-query-file","--go-query","--go-query-file",
        "--c-query","--c-query-file","--csharp-query","--csharp-query-file","--hcl-query","--hcl-query-file",
        "--typescript-query","--typescript-query-file",NULL};
    for(int i=0;opts[i];i++) if(strcmp(a,opts[i])==0) return true;
    return false;
}

static void usage_short(void){
    puts("A grep-like tool which understands source code syntax and allows for manipulation in\naddition to search\n");
    puts("Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n");
    puts("Options:\n  -h, --help                 Print help\n  -V, --version              Print version\n  -u, --upper                Uppercase anything in scope\n  -l, --lower                Lowercase anything in scope\n  -t, --titlecase            Titlecase anything in scope\n  -n, --normalize            Strip common diacritics\n  -g, --german               German substitutions\n  -S, --symbols              Symbol substitutions\n  -d, --delete               Delete anything in scope\n  -s, --squeeze              Squeeze repeated scope\n  -G, --glob <GLOB>          Work on files\n  -L, --literal-string       Treat scope literally");
}

static void completions(const char *sh){
    printf("# completion script for %s\n_complete_executable() { :; }\n", sh);
}

static void parse(int argc,char **argv,Opt *o){
    memset(o,0,sizeof *o);
    o->scope=strdup(".*");
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--")==0){ if(i+1<argc) o->replace=argv[++i]; continue; }
        if(strcmp(a,"-h")==0){ usage_short(); exit(0); }
        if(strcmp(a,"--help")==0){ usage_short(); exit(0); }
        if(strcmp(a,"-V")==0||strcmp(a,"--version")==0){ puts("srgn 0.14.1"); exit(0); }
        if(strcmp(a,"--completions")==0){ if(++i>=argc) die("error: a value is required for '--completions <SHELL>'"); completions(argv[i]); exit(0); }
        if(strcmp(a,"-u")==0||strcmp(a,"--upper")==0){ o->upper=true; continue; }
        if(strcmp(a,"-l")==0||strcmp(a,"--lower")==0){ o->lower=true; continue; }
        if(strcmp(a,"-t")==0||strcmp(a,"--titlecase")==0){ o->title=true; continue; }
        if(strcmp(a,"-n")==0||strcmp(a,"--normalize")==0){ o->norm=true; continue; }
        if(strcmp(a,"-g")==0||strcmp(a,"--german")==0){ o->german=true; continue; }
        if(strcmp(a,"-S")==0||strcmp(a,"--symbols")==0){ o->symbols=true; continue; }
        if(strcmp(a,"-d")==0||strcmp(a,"--delete")==0){ o->delete_action=true; continue; }
        if(strcmp(a,"-s")==0||strcmp(a,"--squeeze")==0||strcmp(a,"--squeeze-repeats")==0){ o->squeeze=true; continue; }
        if(strcmp(a,"-i")==0||strcmp(a,"--invert")==0){ o->invert=true; continue; }
        if(strcmp(a,"-L")==0||strcmp(a,"--literal-string")==0){ o->literal=true; continue; }
        if(strcmp(a,"--fail-any")==0){ o->fail_any=true; continue; }
        if(strcmp(a,"--fail-none")==0){ o->fail_none=true; continue; }
        if(strcmp(a,"--fail-no-files")==0){ o->fail_no_files=true; continue; }
        if(strcmp(a,"--dry-run")==0){ o->dry_run=true; continue; }
        if(strcmp(a,"--sorted")==0){ o->sorted=true; continue; }
        if(strcmp(a,"--german-naive")==0){ o->german_naive=true; continue; }
        if(strcmp(a,"--german-prefer-original")==0){ o->german_prefer_original=true; continue; }
        if(strcmp(a,"-j")==0||strcmp(a,"--join-language-scopes")==0){ o->join_lang=true; continue; }
        if(strcmp(a,"-G")==0||strcmp(a,"--glob")==0){ if(++i>=argc) die("error: a value is required for '--glob <GLOB>'"); o->glob_pat=argv[i]; continue; }
        if(strcmp(a,"--stdin-detection")==0||strcmp(a,"--stdout-detection")==0||strcmp(a,"--threads")==0){ i++; continue; }
        if(strcmp(a,"-H")==0||strcmp(a,"--hidden")==0||strcmp(a,"--gitignored")==0||starts(a,"-v")) continue;
        if(is_langopt(a)){ if(++i>=argc) die("error: missing language scope"); if(o->lang_count<16) o->lang_kind[o->lang_count++]=argv[i]; continue; }
        if(a[0]=='-' && a[1]) { fprintf(stderr,"error: unexpected argument '%s'\n",a); exit(2); }
        o->scope=a;
    }
    char *e;
    if(!o->upper && (e=getenv("UPPER")) && *e) o->upper=true;
    if(!o->lower && (e=getenv("LOWER")) && *e) o->lower=true;
    if(!o->title && (e=getenv("TITLECASE")) && *e) o->title=true;
    if(!o->norm && (e=getenv("NORMALIZE")) && *e) o->norm=true;
    if(!o->replace && (e=getenv("REPLACE")) && *e) o->replace=e;
}

static void mark_range(unsigned char*m,size_t n,size_t a,size_t b){ if(a>n)a=n; if(b>n)b=n; for(size_t i=a;i<b;i++)m[i]=1; }
static size_t line_start(const char*s,size_t p){ while(p>0&&s[p-1]!='\n')p--; return p; }
static size_t line_end(const char*s,size_t n,size_t p){ while(p<n&&s[p]!='\n')p++; if(p<n)p++; return p; }
static size_t find_block_end(const char*s,size_t n,size_t p){
    int ind=0; size_t ls=line_start(s,p); while(ls<n && (s[ls]==' '||s[ls]=='\t')){ ind += s[ls]=='\t'?4:1; ls++; }
    size_t q=line_end(s,n,p);
    while(q<n){ size_t r=q; int ci=0; while(r<n&&(s[r]==' '||s[r]=='\t')){ ci+=s[r]=='\t'?4:1; r++; } if(r<n&&s[r]!='\n'&&ci<=ind) break; q=line_end(s,n,r); }
    return q;
}

static unsigned char *language_mask(const char*s,size_t n,Opt*o){
    unsigned char *mask=calloc(n? n:1,1), *tmp=calloc(n? n:1,1); if(!mask||!tmp)exit(2);
    if(o->lang_count==0){ memset(mask,1,n); free(tmp); return mask; }
    for(int li=0; li<o->lang_count; li++){
        memset(tmp,0,n); const char*k=o->lang_kind[li];
        for(size_t i=0;i<n;i++){
            if((strcmp(k,"comments")==0||strcmp(k,"doc-comments")==0) && s[i]=='#') mark_range(tmp,n,i,line_end(s,n,i));
            if((strcmp(k,"comments")==0||strcmp(k,"doc-comments")==0) && s[i]=='/'&&i+1<n&&s[i+1]=='/') mark_range(tmp,n,i,line_end(s,n,i));
            if((strcmp(k,"comments")==0||strcmp(k,"doc-comments")==0) && s[i]=='/'&&i+1<n&&s[i+1]=='*'){ size_t j=i+2; while(j+1<n&&!(s[j]=='*'&&s[j+1]=='/'))j++; mark_range(tmp,n,i,j+2<n?j+2:n); }
        }
        if(strcmp(k,"strings")==0||strcmp(k,"doc-strings")==0){
            for(size_t i=0;i<n;i++) if(s[i]=='"'||s[i]=='\''||s[i]=='`'){
                char q=s[i]; size_t j=i+1; while(j<n){ if(s[j]=='\\'){ j+=2; continue; } if(s[j]==q){ j++; break; } j++; }
                mark_range(tmp,n,i,j); i=j?j-1:i;
            }
        } else if(strstr(k,"class")||strcmp(k,"def")==0||strstr(k,"fn")||strcmp(k,"func")==0||strcmp(k,"method")==0){
            const char *words[]={"class ","def ","async def ","fn ","func ",NULL};
            for(size_t i=0;i<n;i++) for(int w=0;words[w];w++){ size_t wl=strlen(words[w]); if(i+wl<=n&&memcmp(s+i,words[w],wl)==0) mark_range(tmp,n,line_start(s,i),find_block_end(s,n,i)); }
        } else if(strstr(k,"imports")||strstr(k,"uses")||strstr(k,"includes")||strcmp(k,"usings")==0){
            const char *words[]={"import ","from ","use ","#include","using ",NULL};
            for(size_t i=0;i<n;i++) for(int w=0;words[w];w++){ size_t wl=strlen(words[w]); if(i+wl<=n&&memcmp(s+i,words[w],wl)==0) mark_range(tmp,n,line_start(s,i),line_end(s,n,i)); }
        } else if(strcmp(k,"identifiers")==0||strcmp(k,"identifier")==0||strcmp(k,"variable-identifiers")==0){
            for(size_t i=0;i<n;i++) if(isalpha((unsigned char)s[i])||s[i]=='_'){ size_t j=i+1; while(j<n&&(isalnum((unsigned char)s[j])||s[j]=='_'))j++; mark_range(tmp,n,i,j); i=j-1; }
        } else if(strcmp(k,"unsafe")==0) {
            for(size_t i=0;i+6<=n;i++) if(memcmp(s+i,"unsafe",6)==0) mark_range(tmp,n,i,i+6);
        }
        if(li==0 || o->join_lang) {
            if(li==0 && !o->join_lang) memcpy(mask,tmp,n); else for(size_t i=0;i<n;i++) mask[i]|=tmp[i];
        } else {
            for(size_t i=0;i<n;i++) mask[i]&=tmp[i];
        }
    }
    free(tmp); return mask;
}

static char *quote_regex(const char*s){
    Buf b; binit(&b); for(;*s;s++){ if(strchr(".^$*+?()[]{}|\\",*s)) baddn(&b,"\\",1); baddn(&b,s,1); } return b.data?b.data:strdup("");
}

static char *case_map(const char*s,size_t n,int mode){
    char *r=xstrndup(s,n); bool newword=true;
    for(size_t i=0;i<n;i++){
        unsigned char c=r[i];
        if(mode==1) r[i]=toupper(c);
        else if(mode==2) r[i]=tolower(c);
        else {
            if(isalpha(c)){ if(newword) r[i]=toupper(c); newword=false; }
            else newword = !isalnum(c);
        }
    }
    return r;
}

typedef struct { const char *a,*b; } Pair;
static Pair sym_pairs[]={{"!=","≠"},{"->","→"},{"<-","←"},{"<=","≤"},{">=","≥"},{"=>","⇒"},{"---","—"},{"--","–"},{"...","…"}, {NULL,NULL}};
static Pair de_pairs[]={{"ae","ä"},{"oe","ö"},{"ue","ü"},{"Ae","Ä"},{"Oe","Ö"},{"Ue","Ü"},{"ss","ß"}, {NULL,NULL}};
static Pair norm_pairs[]={{"ä","a"},{"ö","o"},{"ü","u"},{"Ä","A"},{"Ö","O"},{"Ü","U"},{"ß","ss"},{"é","e"},{"è","e"},{"ê","e"},{"á","a"},{"à","a"},{"ó","o"},{"ñ","n"}, {NULL,NULL}};

static char *replace_pairs(const char*s,size_t n,Pair*p,bool inv){
    Buf b; binit(&b);
    for(size_t i=0;i<n;){
        bool hit=false;
        for(int k=0;p[k].a;k++){ const char *a=inv?p[k].b:p[k].a,*c=inv?p[k].a:p[k].b; size_t al=strlen(a); if(i+al<=n&&memcmp(s+i,a,al)==0){ badds(&b,c); i+=al; hit=true; break; } }
        if(!hit) baddn(&b,s+i++,1);
    }
    return b.data?b.data:strdup("");
}

static char *expand_repl(const char*rep,const char*src,regmatch_t*m,int n){
    Buf b; binit(&b);
    for(size_t i=0;rep[i];i++){
        if(rep[i]=='$' && isdigit((unsigned char)rep[i+1])){ int g=rep[++i]-'0'; if(g<n&&m[g].rm_so>=0) baddn(&b,src+m[g].rm_so,m[g].rm_eo-m[g].rm_so); }
        else baddn(&b,rep+i,1);
    }
    return b.data?b.data:strdup("");
}

static bool mask_allows(unsigned char*m,size_t a,size_t b){ if(a==b) return a==0 || m[a-1] || m[a]; for(size_t i=a;i<b;i++) if(!m[i]) return false; return true; }

static char *process(const char*in,size_t len,Opt*o,bool *any,bool *changed,bool search_mode,const char *name){
    char *pat=o->literal?quote_regex(o->scope):strdup(o->scope); regex_t re; int rc=regcomp(&re,pat,REG_EXTENDED|REG_NEWLINE); free(pat);
    if(rc){ char err[256]; regerror(rc,&re,err,sizeof err); fprintf(stderr,"Error: %s\n",err); exit(2); }
    unsigned char *mask=language_mask(in,len,o); Buf out; binit(&out); size_t pos=0; regmatch_t m[10]; *any=false; *changed=false;
    if(search_mode){
        const char *p=in; size_t off=0;
        while(off<=len && regexec(&re,p,10,m,0)==0){
            size_t a=off+m[0].rm_so,b=off+m[0].rm_eo; if(b==a){ if(off<len){off++;p++;continue;} break; }
            if(mask_allows(mask,a,b)){ *any=true; size_t ls=line_start(in,a), le=line_end(in,len,a); int line=1; for(size_t i=0;i<ls;i++) if(in[i]=='\n') line++; printf("%s:%d:%zu-%zu:%.*s",name,line,a-ls,b-ls,(int)(le-ls),in+ls); if(le==len||in[le-1]!='\n') putchar('\n'); }
            off=b; p=in+off;
        }
        free(mask); regfree(&re); return strdup(in);
    }
    const char *p=in; size_t off=0; bool prev_squeezed=false;
    while(off<=len && regexec(&re,p,10,m,0)==0){
        size_t a=off+m[0].rm_so,b=off+m[0].rm_eo; if(b==a){ if(off<len){ baddn(&out,in+pos,off+1-pos); off++; p=in+off; pos=off; continue; } break; }
        if(!mask_allows(mask,a,b)){ off=b; p=in+off; continue; }
        *any=true; baddn(&out,in+pos,a-pos);
        char *seg=xstrndup(in+a,b-a), *tmp=NULL;
        if(o->squeeze){ if(!prev_squeezed) baddn(&out,in+a,b-a); prev_squeezed=true; *changed=true; }
        else if(o->delete_action){ *changed=true; }
        else {
            if(o->replace){ tmp=expand_repl(o->replace,in+a,m,10); free(seg); seg=tmp; tmp=NULL; *changed=true; }
            if(o->symbols){ tmp=replace_pairs(seg,strlen(seg),sym_pairs,o->invert); free(seg); seg=tmp; }
            if(o->german){ tmp=replace_pairs(seg,strlen(seg),de_pairs,false); free(seg); seg=tmp; }
            if(o->norm){ tmp=replace_pairs(seg,strlen(seg),norm_pairs,false); free(seg); seg=tmp; }
            if(o->upper||o->lower||o->title){ tmp=case_map(seg,strlen(seg),o->upper?1:o->lower?2:3); free(seg); seg=tmp; }
            badds(&out,seg); free(seg);
        }
        pos=b; off=b; p=in+off;
    }
    baddn(&out,in+pos,len-pos);
    if(out.len!=len||memcmp(out.data,in,len)!=0) *changed=true;
    free(mask); regfree(&re); return out.data?out.data:strdup("");
}

static int handle_one(const char *input_name, Opt *o, bool file_mode){
    size_t len; char *in = file_mode ? read_file(input_name,&len) : read_stream(stdin,&len); if(!in) return 1;
    bool has_action=o->upper||o->lower||o->title||o->norm||o->german||o->symbols||o->delete_action||o->squeeze||o->replace;
    bool search_mode=!has_action && o->lang_count>0;
    if(!has_action && !search_mode) fprintf(stderr,"[2026-05-27T00:00:00.000000Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.\n");
    bool any=false, changed=false; char *out=process(in,len,o,&any,&changed,search_mode,file_mode?input_name:"(stdin)");
    int status=0;
    if(o->fail_any && any){ fprintf(stderr,"Error: Error applying: Some input was in scope\n"); status=1; }
    if(o->fail_none && !any){ fprintf(stderr,"Error: Error applying: No input was in scope\n"); status=1; }
    if(!file_mode){ if(!search_mode) fwrite(out,1,strlen(out),stdout); }
    else {
        if(o->dry_run){ if(changed) printf("--- %s\n+++ %s\n",input_name,input_name); else { fprintf(stderr,"Error: No input was in scope\n"); status=1; } }
        else { if(has_action && changed) write_file(input_name,out,strlen(out)); printf("%s\n",input_name); }
    }
    free(in); free(out); return status;
}

int main(int argc,char **argv){
    Opt o; parse(argc,argv,&o);
    if((o.delete_action||o.squeeze||o.literal) && strcmp(o.scope,".*")==0){ fprintf(stderr,"error: the following required arguments were not provided:\n  <SCOPE>\n\nUsage: executable --delete <SCOPE> [-- <REPLACEMENT>]\n"); return 2; }
    if((o.delete_action||o.squeeze) && (o.upper||o.lower||o.title||o.norm||o.german||o.symbols||o.replace)){ fprintf(stderr,"Error: standalone actions cannot be combined\n"); return 2; }
    if(o.glob_pat){
        glob_t g; int gr=glob(o.glob_pat,0,NULL,&g); if(gr||g.gl_pathc==0){ if(o.fail_no_files){ fprintf(stderr,"Error: No files found\n"); return 1; } return 0; }
        int st=0; for(size_t i=0;i<g.gl_pathc;i++) if(handle_one(g.gl_pathv[i],&o,true)) st=1; globfree(&g); return st;
    }
    return handle_one(NULL,&o,false);
}
