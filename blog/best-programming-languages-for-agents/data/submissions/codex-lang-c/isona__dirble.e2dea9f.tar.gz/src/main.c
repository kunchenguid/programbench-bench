#define _GNU_SOURCE
#define _POSIX_C_SOURCE 200809L
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

typedef struct { char **v; int n, cap; } StrList;
typedef struct {
    char *url, *redirect;
    int code;
    long size;
    bool is_dir, is_listable, from_listable;
} Result;
typedef struct { Result *v; int n, cap; } Results;
typedef struct {
    StrList uris, words, exts, prefixes, cookies, headers, hide_ranges;
    char *uri_file, *wordlist, *json_file, *xml_file, *txt_file, *output_all;
    char *verb, *user_agent, *username, *password;
    int timeout, max_errors, max_threads, split, throttle, max_depth;
    bool no_color, disable_validator, disable_recursion, force_ext, ext_sub;
    bool silent, scan_listable, scrape_listable, show_htaccess, no_proxy, burp;
    bool have_whitelist;
    int whitelist[700], blacklist[700];
} Opts;

static void die(const char *msg) { fprintf(stderr, "%s\n", msg); exit(1); }
static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) exit(2); return p; }
static void sl_add(StrList *l, const char *s){ if(l->n==l->cap){l->cap=l->cap?l->cap*2:8;l->v=realloc(l->v,l->cap*sizeof(char*)); if(!l->v)exit(2);} l->v[l->n++]=xstrdup(s); }
static void sl_prepend(StrList *l, const char *s){ if(l->n==l->cap){l->cap=l->cap?l->cap*2:8;l->v=realloc(l->v,l->cap*sizeof(char*)); if(!l->v)exit(2);} memmove(l->v+1,l->v,l->n*sizeof(char*)); l->v[0]=xstrdup(s); l->n++; }
static void sl_add_split(StrList *l, const char *s){ char *tmp=xstrdup(s), *p=tmp, *tok; while((tok=strsep(&p,","))){ if(*tok) sl_add(l,tok); } free(tmp); }
static void res_add(Results *r, Result it){ if(r->n==r->cap){r->cap=r->cap?r->cap*2:32;r->v=realloc(r->v,r->cap*sizeof(Result)); if(!r->v)exit(2);} r->v[r->n++]=it; }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }

static void print_help(void) {
puts("Fast directory scanning and scraping tool\n");
puts("Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n");
puts("Arguments:\n  [uri]\n          The URI of the host to scan, optionally supports basic auth with\n          http://user:pass@host:port\n");
puts("Options:\n  -u, --uri <uri>\n          Additional hosts to scan [aliases: url]\n  -U, --uri-file <uri-file>\n          The filename of a file containing a list of URIs to scan - cookies and\n          headers set will be applied to all URIs [aliases: url-file]\n      --verb <http_verb>\n          Specify which HTTP verb to use\n           [default: get] [possible values: get, head, post]\n  -w, --wordlist <wordlist>\n          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same\n          folder as the executable\n  -p, --prefixes <prefixes>...\n          Provides comma separated prefixes to extend queries with\n  -P, --prefix-file <prefix-file>\n          The name of a file containing extensions to extend queries with, one\n          per line\n  -x, --extensions <extensions>...\n          Provides comma separated extensions to extend queries with\n  -X, --extension-file <extension-file>\n          The name of a file containing extensions to extend queries with, one\n          per line\n      --ext-sub\n          Indicates whether the string \"%EXT%\" in a wordlist file should be \n          substituted with the current extension\n  -f, --force-extension\n          Only scan with provided extensions\n  -k, --ignore-cert\n          Ignore the certificate validity for HTTPS\n      --show-htaccess\n          Enable display of items containing .ht when they return 403 responses\n      --timeout <timeout>\n          Maximum time to wait for a response before giving up, given in seconds\n           [default: 5]\n      --max-errors <max_errors>\n          The number of consecutive errors a thread can have before it exits,\n          set to 0 to disable [default: 5]\n      --json-file <json_file>\n          Sets a file to write JSON output to [aliases: oJ]\n      --no-color\n          Disable coloring of terminal output\n  -o, --output-file <output_file>\n          Sets the file to write the report to [aliases: oN]\n      --xml-file <xml_file>\n          Sets a file to write XML output to [aliases: oX]\n      --hide-lengths <length_blacklist>...\n          Specify length ranges to hide, e.g. --hide-lengths 348,500-700\n      --output-all <output_all>\n          Stores all output types respectively as .txt, .json and .xml [aliases: oA]\n      --burp\n          Sets the proxy to use the default burp proxy values\n          (http://localhost:8080)\n      --no-proxy\n          Disables proxy use even if there is a system proxy\n      --proxy <proxy>\n          The proxy address to use, including type and port, can also include a\n          username and password in the form \n          \"http://username:password@proxy_url:proxy_port\"\n  -t, --max-threads <max-threads>\n          Sets the maximum number of request threads that will be spawned [default: 10]\n  -T, --wordlist-split <wordlist_split>\n          The number of threads to run for each folder/extension combo [default: 3]\n  -z, --throttle <milliseconds>\n          Time each thread will wait between requests, given in milliseconds\n      --username <username>\n          Sets the username to authenticate with\n      --password <password>\n          Sets the password to authenticate with\n  -l, --scan-listable\n          Scan listable directories\n      --max-recursion-depth <max_recursion_depth>\n          Sets the maximum directory depth to recurse to, 0 will disable\n          recursion\n  -r, --disable-recursion\n          Disable discovered subdirectory scanning\n      --scrape-listable\n          Enable scraping of listable directories for urls, often produces large\n          amounts of output\n  -a, --user-agent <user_agent>\n          Set the user-agent provided with requests, by default it isn't set\n  -c, --cookie <cookie>\n          Provide a cookie in the form \"name=value\", can be used multiple times\n  -H, --header <header>\n          Provide an arbitrary header in the form \"header:value\" - headers with\n          no value must end in a semicolon\n  -S, --silent\n          Don't output information during the scan, only output the report at\n          the end.\n  -v, --verbose...\n          Increase the verbosity level. Use twice for full verbosity.\n  -B, --code-blacklist <code_blacklist>...\n          Provide a comma separated list of response codes to not show in output\n      --disable-validator\n          Disable automatic detection of not found codes\n  -W, --code-whitelist <code_whitelist>...\n          Provide a comma separated list of response codes to show in output,\n          also disables detection of not found codes\n      --scan-401\n          Scan folders even if they return 401 - Unauthorized frequently\n      --scan-403\n          Scan folders if they return 403 - Forbidden frequently\n  -h, --help\n          Print help\n  -V, --version\n          Print version\n\nOUTPUT FORMAT:\n    + [url] - File\n    D [url] - Directory\n    L [url] - Listable Directory");
}

static void parse_codes(int arr[], const char *s){ char *tmp=xstrdup(s), *p=tmp, *tok; while((tok=strsep(&p,","))){ int a,b; if(sscanf(tok,"%d-%d",&a,&b)==2){ if(a<0)a=0; if(b>699)b=699; for(int i=a;i<=b;i++)arr[i]=1; } else { a=atoi(tok); if(a>=0&&a<700)arr[a]=1; } } free(tmp); }

static void read_lines(StrList *out, const char *path) {
    FILE *f=fopen(path,"r");
    if(!f){ fprintf(stderr,"\nthread 'main' panicked at src/wordlist.rs:112:37:\ncalled `Result::unwrap()` on an `Err` value: Os { code: %d, kind: NotFound, message: \"%s\" }\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n", errno, strerror(errno)); exit(101); }
    char *line=NULL; size_t n=0; ssize_t got;
    while((got=getline(&line,&n,f))!=-1){ (void)got; char *t=trim(line); if(*t && *t!='#') sl_add(out,t); }
    free(line); fclose(f);
}

typedef struct { char scheme[8], host[256], port[16], path[1024], auth[512], base[1400]; bool https; } Url;
static int parse_url(const char *u, Url *z){
    memset(z,0,sizeof(*z)); strcpy(z->path,"/"); strcpy(z->port,"80");
    const char *p=strstr(u,"://"); if(!p) return -1;
    int sl=p-u; if(sl>7) return -1; memcpy(z->scheme,u,sl); z->scheme[sl]=0; z->https=!strcasecmp(z->scheme,"https"); if(z->https) strcpy(z->port,"443");
    p+=3; const char *slash=strchr(p,'/'); size_t hostlen=slash?(size_t)(slash-p):strlen(p);
    char hp[800]; if(hostlen>=sizeof hp) return -1; memcpy(hp,p,hostlen); hp[hostlen]=0; if(slash) snprintf(z->path,sizeof z->path,"%s",slash);
    char *at=strrchr(hp,'@'); char *h=hp; if(at){ *at=0; snprintf(z->auth,sizeof z->auth,"%s",hp); h=at+1; }
    char *colon=strrchr(h,':'); if(colon && !strchr(colon,']')){ *colon=0; snprintf(z->port,sizeof z->port,"%s",colon+1); }
    snprintf(z->host,sizeof z->host,"%s",h);
    char rootpath[1024]; snprintf(rootpath,sizeof rootpath,"%s",z->path); if(rootpath[strlen(rootpath)-1]!='/') strcat(rootpath,"/");
    int def=(!z->https && !strcmp(z->port,"80")) || (z->https && !strcmp(z->port,"443"));
    snprintf(z->base,sizeof z->base,"%s://%s%s%s",z->scheme,z->host,def?"":":",def?"":z->port);
    return 0;
}

static const char b64tab[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static char *b64(const char *s){ size_t n=strlen(s), out=((n+2)/3)*4; char *r=malloc(out+1); size_t j=0; for(size_t i=0;i<n;i+=3){ unsigned v=(unsigned char)s[i]<<16; if(i+1<n)v|=(unsigned char)s[i+1]<<8; if(i+2<n)v|=(unsigned char)s[i+2]; r[j++]=b64tab[(v>>18)&63]; r[j++]=b64tab[(v>>12)&63]; r[j++]=(i+1<n)?b64tab[(v>>6)&63]:'='; r[j++]=(i+2<n)?b64tab[v&63]:'='; } r[j]=0; return r; }

static int http_request(const Opts *o, const char *url, Result *res) {
    Url z; memset(res,0,sizeof(*res)); res->url=xstrdup(url); res->redirect=xstrdup("");
    if(parse_url(url,&z)<0 || z.https) return -1;
    struct addrinfo hints={0}, *ai=0; hints.ai_socktype=SOCK_STREAM; hints.ai_family=AF_UNSPEC;
    if(getaddrinfo(z.host,z.port,&hints,&ai)!=0) return -1;
    int fd=-1; for(struct addrinfo *a=ai;a;a=a->ai_next){ fd=socket(a->ai_family,a->ai_socktype,a->ai_protocol); if(fd<0)continue; struct timeval tv={o->timeout,0}; setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof tv); setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof tv); if(connect(fd,a->ai_addr,a->ai_addrlen)==0) break; close(fd); fd=-1; }
    freeaddrinfo(ai); if(fd<0) return -1;
    const char *verb=!strcasecmp(o->verb,"head")?"HEAD":(!strcasecmp(o->verb,"post")?"POST":"GET");
    char req[8192]; int pos=snprintf(req,sizeof req,"%s %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n",verb,z.path,z.host);
    if(o->user_agent) pos+=snprintf(req+pos,sizeof(req)-pos,"User-Agent: %s\r\n",o->user_agent);
    if(z.auth[0] || (o->username&&o->password)){ char authbuf[600]; if(z.auth[0]) snprintf(authbuf,sizeof authbuf,"%s",z.auth); else snprintf(authbuf,sizeof authbuf,"%s:%s",o->username,o->password); char *enc=b64(authbuf); pos+=snprintf(req+pos,sizeof(req)-pos,"Authorization: Basic %s\r\n",enc); free(enc); }
    if(o->cookies.n){ pos+=snprintf(req+pos,sizeof(req)-pos,"Cookie: "); for(int i=0;i<o->cookies.n;i++) pos+=snprintf(req+pos,sizeof(req)-pos,"%s%s",i?"; ":"",o->cookies.v[i]); pos+=snprintf(req+pos,sizeof(req)-pos,"\r\n"); }
    for(int i=0;i<o->headers.n;i++){ char *h=o->headers.v[i]; pos+=snprintf(req+pos,sizeof(req)-pos,"%s%s\r\n",h, strchr(h,':')?"":":"); }
    if(!strcmp(verb,"POST")) pos+=snprintf(req+pos,sizeof(req)-pos,"Content-Length: 0\r\n");
    snprintf(req+pos,sizeof(req)-pos,"\r\n");
    write(fd,req,strlen(req));
    char buf[4096], *data=NULL; size_t cap=0,len=0; ssize_t n;
    while((n=read(fd,buf,sizeof buf))>0){ if(len+n+1>cap){cap=(len+n+1)*2;data=realloc(data,cap); if(!data)exit(2);} memcpy(data+len,buf,n); len+=n; }
    close(fd); if(!data) return -1; data[len]=0;
    int code=0; sscanf(data,"HTTP/%*s %d",&code); res->code=code;
    char *body=strstr(data,"\r\n\r\n"); size_t hlen=body?(size_t)(body-data)+4:len; long clen=-1;
    for(char *line=data; line && line < data+(long)hlen; ){ char *next=strstr(line,"\r\n"); if(!next)break; *next=0; if(!strncasecmp(line,"Content-Length:",15)) clen=atol(trim(line+15)); if(!strncasecmp(line,"Location:",9)){ char *loc=trim(line+9); if(strstr(loc,"://")){ free(res->redirect); res->redirect=xstrdup(loc); } else { Url uz; parse_url(url,&uz); char full[1600]; if(*loc=='/') snprintf(full,sizeof full,"%s%s",uz.base,loc); else snprintf(full,sizeof full,"%s/%s",uz.base,loc); free(res->redirect); res->redirect=xstrdup(full); } } line=next+2; }
    res->size = clen>=0 ? clen : (body ? (long)(len-hlen) : 0);
    if(code>=300 && code<400 && res->redirect[0]) {
        res->is_dir=true;
        free(res->url);
        res->url=xstrdup(res->redirect);
    }
    if(o->scan_listable && body && strcasestr(body,"Index of")) res->is_listable=true;
    free(data); return 0;
}

static char *join_url(const char *base, const char *word){
    size_t nb=strlen(base); while(nb && base[nb-1]=='/') nb--;
    while(*word=='/') word++;
    size_t nw=strlen(word); while(nw && word[nw-1]=='/') nw--;
    char *r=malloc(nb+nw+2); memcpy(r,base,nb); r[nb]='/'; memcpy(r+nb+1,word,nw); r[nb+1+nw]=0; return r;
}
static char *subst_ext(const char *w, const char *e, bool sub){
    if(!sub) { char *r=malloc(strlen(w)+strlen(e)+1); strcpy(r,w); strcat(r,e); return r; }
    const char *p=strstr(w,"%EXT%"); if(!p) return xstrdup(w);
    char *r=malloc(strlen(w)+strlen(e)+1); size_t a=p-w; memcpy(r,w,a); strcpy(r+a,e); strcpy(r+a+strlen(e),p+5); return r;
}
static char *clean_word(const char *w){
    while(*w=='/') w++;
    size_t n=strlen(w);
    while(n && w[n-1]=='/') n--;
    char *r=malloc(n+1);
    memcpy(r,w,n);
    r[n]=0;
    return r;
}
static bool hidden_len(const Opts *o, long sz){ for(int i=0;i<o->hide_ranges.n;i++){ int a,b; if(sscanf(o->hide_ranges.v[i],"%d-%d",&a,&b)==2){ if(sz>=a&&sz<=b)return true; } else if(sz==atoi(o->hide_ranges.v[i])) return true; } return false; }
static bool should_show(const Opts *o, const int nf[], Result *r){
    if(r->code<100) return false;
    if(o->have_whitelist) return r->code<700 && o->whitelist[r->code] && !hidden_len(o,r->size);
    if(r->code<700 && o->blacklist[r->code]) return false;
    if(!o->disable_validator && r->code<700 && nf[r->code]) return false;
    if(!o->show_htaccess && strstr(r->url,".ht") && r->code==403) return false;
    if(hidden_len(o,r->size)) return false;
    return true;
}

static void print_result(FILE *f, Result *r){
    fprintf(f,"%c %s (CODE:%d|SIZE:%ld", r->is_listable?'L':(r->is_dir?'D':'+'), r->url, r->code, r->size);
    if(r->redirect && r->redirect[0]) fprintf(f,"|DEST:%s", r->redirect);
    fprintf(f,")\n");
}
static char *json_escape(const char *s){ size_t cap=strlen(s)*2+1; char *r=malloc(cap); size_t j=0; for(size_t i=0;s[i];i++){ if(s[i]=='"'||s[i]=='\\') r[j++]='\\'; r[j++]=s[i]; } r[j]=0; return r; }
static void write_json(const char *path, Results *rs){ FILE*f=fopen(path,"w"); if(!f)return; fprintf(f,"["); for(int i=0;i<rs->n;i++){ Result*r=&rs->v[i]; char*u=json_escape(r->url),*d=json_escape(r->redirect?r->redirect:""); fprintf(f,"%s{\"url\":\"%s\",\"code\":%d,\"size\":%ld,\"is_directory\":%s,\"is_listable\":%s,\"redirect_url\":\"%s\",\"found_from_listable\":%s}",i?",\n":"",u,r->code,r->size,r->is_dir?"true":"false",r->is_listable?"true":"false",d,r->from_listable?"true":"false"); free(u); free(d);} fprintf(f,"]"); fclose(f); }
static void write_xml(const char *path, Results *rs){ FILE*f=fopen(path,"w"); if(!f)return; fprintf(f,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<dirble_scan>\n"); for(int i=0;i<rs->n;i++){ Result*r=&rs->v[i]; fprintf(f,"<path url=\"%s\" code=\"%d\" content_len=\"%ld\" is_directory=\"%s\" is_listable=\"%s\" redirect_url=\"%s\" found_from_listable=\"%s\"/>\n",r->url,r->code,r->size,r->is_dir?"true":"false",r->is_listable?"true":"false",r->redirect?r->redirect:"",r->from_listable?"true":"false"); } fprintf(f,"</dirble_scan>"); fclose(f); }
static int cmp_res(const void*a,const void*b){ const Result*x=a,*y=b; if(x->is_dir!=y->is_dir) return x->is_dir-y->is_dir; return strcmp(x->url,y->url); }
static void write_txt(const char *path, const char *base, Results *rs){ FILE*f=fopen(path,"w"); if(!f)return; fprintf(f,"Dirble Scan Report for %s%s:\n",base, base[strlen(base)-1]=='/'?"":"/"); for(int i=0;i<rs->n;i++) if(!rs->v[i].is_dir) print_result(f,&rs->v[i]); fprintf(f,"\n"); for(int i=0;i<rs->n;i++) if(rs->v[i].is_dir) print_result(f,&rs->v[i]); fclose(f); }

static void parse_args(Opts *o, int argc, char **argv){
    o->verb=xstrdup("get"); o->timeout=5; o->max_errors=5; o->max_threads=10; o->split=3;
    for(int i=1;i<argc;i++){ char *a=argv[i];
        #define NEED() do{ if(i+1>=argc) die("error: a value is required"); }while(0)
        if(!strcmp(a,"-h")||!strcmp(a,"--help")){print_help();exit(0);}
        else if(!strcmp(a,"-V")||!strcmp(a,"--version")){puts("Dirble 1.4.2 (commit d520c82, build 2026-04-17)");exit(0);}
        else if(!strcmp(a,"-u")||!strcmp(a,"--uri")||!strcmp(a,"--url")){NEED();sl_add(&o->uris,argv[++i]);}
        else if(!strcmp(a,"-U")||!strcmp(a,"--uri-file")||!strcmp(a,"--url-file")){NEED();o->uri_file=xstrdup(argv[++i]);}
        else if(!strcmp(a,"-w")||!strcmp(a,"--wordlist")){NEED();o->wordlist=xstrdup(argv[++i]);}
        else if(!strcmp(a,"--verb")){NEED(); free(o->verb); o->verb=xstrdup(argv[++i]); if(strcasecmp(o->verb,"get")&&strcasecmp(o->verb,"head")&&strcasecmp(o->verb,"post")){fprintf(stderr,"error: invalid value '%s' for '--verb <http_verb>'\n  [possible values: get, head, post]\n",o->verb);exit(2);}}
        else if(!strcmp(a,"-x")||!strcmp(a,"--extensions")){ while(i+1<argc && argv[i+1][0]!='-') sl_add_split(&o->exts,argv[++i]); }
        else if(!strcmp(a,"-p")||!strcmp(a,"--prefixes")){ while(i+1<argc && argv[i+1][0]!='-') sl_add_split(&o->prefixes,argv[++i]); }
        else if(!strcmp(a,"-X")||!strcmp(a,"--extension-file")){NEED(); read_lines(&o->exts,argv[++i]);}
        else if(!strcmp(a,"-P")||!strcmp(a,"--prefix-file")){NEED(); read_lines(&o->prefixes,argv[++i]);}
        else if(!strcmp(a,"--ext-sub")) o->ext_sub=true; else if(!strcmp(a,"-f")||!strcmp(a,"--force-extension")) o->force_ext=true;
        else if(!strcmp(a,"--json-file")||!strcmp(a,"--oJ")){NEED();o->json_file=xstrdup(argv[++i]);}
        else if(!strcmp(a,"--xml-file")||!strcmp(a,"--oX")){NEED();o->xml_file=xstrdup(argv[++i]);}
        else if(!strcmp(a,"-o")||!strcmp(a,"--output-file")||!strcmp(a,"--oN")){NEED();o->txt_file=xstrdup(argv[++i]);}
        else if(!strcmp(a,"--output-all")||!strcmp(a,"--oA")){NEED();o->output_all=xstrdup(argv[++i]);}
        else if(!strcmp(a,"--timeout")){NEED();o->timeout=atoi(argv[++i]);}
        else if(!strcmp(a,"--max-errors")){NEED();o->max_errors=atoi(argv[++i]);}
        else if(!strcmp(a,"-t")||!strcmp(a,"--max-threads")){NEED();o->max_threads=atoi(argv[++i]);}
        else if(!strcmp(a,"-T")||!strcmp(a,"--wordlist-split")){NEED();o->split=atoi(argv[++i]);}
        else if(!strcmp(a,"-z")||!strcmp(a,"--throttle")){NEED();o->throttle=atoi(argv[++i]);}
        else if(!strcmp(a,"--max-recursion-depth")){NEED();o->max_depth=atoi(argv[++i]);}
        else if(!strcmp(a,"-a")||!strcmp(a,"--user-agent")){NEED();o->user_agent=xstrdup(argv[++i]);}
        else if(!strcmp(a,"--username")){NEED();o->username=xstrdup(argv[++i]);} else if(!strcmp(a,"--password")){NEED();o->password=xstrdup(argv[++i]);}
        else if(!strcmp(a,"-c")||!strcmp(a,"--cookie")){NEED();sl_add(&o->cookies,argv[++i]);}
        else if(!strcmp(a,"-H")||!strcmp(a,"--header")){NEED();sl_add(&o->headers,argv[++i]);}
        else if(!strcmp(a,"-B")||!strcmp(a,"--code-blacklist")){ while(i+1<argc && argv[i+1][0]!='-') parse_codes(o->blacklist,argv[++i]);}
        else if(!strcmp(a,"-W")||!strcmp(a,"--code-whitelist")){ o->have_whitelist=true; o->disable_validator=true; while(i+1<argc && argv[i+1][0]!='-') parse_codes(o->whitelist,argv[++i]);}
        else if(!strcmp(a,"--hide-lengths")){ while(i+1<argc && argv[i+1][0]!='-') sl_add_split(&o->hide_ranges,argv[++i]);}
        else if(!strcmp(a,"--disable-validator")) o->disable_validator=true; else if(!strcmp(a,"-r")||!strcmp(a,"--disable-recursion")) o->disable_recursion=true;
        else if(!strcmp(a,"--no-color")) o->no_color=true; else if(!strcmp(a,"-S")||!strcmp(a,"--silent")) o->silent=true; else if(!strcmp(a,"-l")||!strcmp(a,"--scan-listable")) o->scan_listable=true;
        else if(!strcmp(a,"--scrape-listable")) o->scrape_listable=true; else if(!strcmp(a,"--show-htaccess")) o->show_htaccess=true; else if(!strcmp(a,"--no-proxy")) o->no_proxy=true;
        else if(!strcmp(a,"--burp")) o->burp=true; else if(!strcmp(a,"--proxy")||!strcmp(a,"-k")||!strcmp(a,"--ignore-cert")||!strcmp(a,"--scan-401")||!strcmp(a,"--scan-403")||!strcmp(a,"-v")||!strcmp(a,"--verbose")) { if(!strcmp(a,"--proxy")){NEED();i++;} }
        else if(a[0]=='-'){ fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'.\n",a); exit(2); }
        else sl_add(&o->uris,a);
    }
}

int main(int argc, char **argv){
    Opts o={0}; parse_args(&o,argc,argv);
    if(o.uri_file) read_lines(&o.uris,o.uri_file);
    if(o.uris.n==0){ print_help(); return 0; }
    if(!o.wordlist){ if(access("dirble_wordlist.txt",R_OK)==0) o.wordlist=xstrdup("dirble_wordlist.txt"); else { fprintf(stderr,"[ERROR] Unable to find default wordlist\n"); return 1; } }
    read_lines(&o.words,o.wordlist);
    if(o.prefixes.n==0 || strcmp(o.prefixes.v[0],"")) sl_prepend(&o.prefixes,"");
    if(!o.force_ext && (o.exts.n==0 || strcmp(o.exts.v[0],""))) sl_prepend(&o.exts,"");
    Results all={0};
    int nf[700]={0};
    for(int ui=0; ui<o.uris.n; ui++){
        Url base; if(parse_url(o.uris.v[ui],&base)<0){ fprintf(stderr,"[ERROR] Invalid URI: %s\n",o.uris.v[ui]); continue; }
        char scanbase[1600]; snprintf(scanbase,sizeof scanbase,"%s%s",base.base,base.path); if(scanbase[strlen(scanbase)-1]!='/') strcat(scanbase,"/");
        if(!o.disable_validator){ char *u=join_url(scanbase,"dirble_not_found_probe_404"); Result rr; if(http_request(&o,u,&rr)==0 && rr.code<700){ nf[rr.code]=1; if(!o.silent) printf("[INFO] Detected nonexistent paths for %s are (CODE:%d)\n",scanbase,rr.code); } free(u); }
        for(int pi=0; pi<o.prefixes.n; pi++) for(int ei=0; ei<o.exts.n; ei++) for(int wi=0; wi<o.words.n; wi++){
            char *cw=clean_word(o.words.v[wi]); char *se=subst_ext(cw,o.exts.v[ei],o.ext_sub); free(cw); char *word=malloc(strlen(o.prefixes.v[pi])+strlen(se)+1); strcpy(word,o.prefixes.v[pi]); strcat(word,se); free(se);
            char *url=join_url(scanbase,word); free(word);
            Result r; if(http_request(&o,url,&r)==0){ if(should_show(&o,nf,&r)) res_add(&all,r); } else if(o.max_errors!=0 && !o.silent) fprintf(stderr,"Curl error after requesting %s : [7] Could not connect to server\n",url);
            free(url); if(o.throttle>0) usleep((useconds_t)o.throttle*1000);
        }
    }
    qsort(all.v,all.n,sizeof(Result),cmp_res);
    if(!o.silent) for(int i=0;i<all.n;i++) print_result(stdout,&all.v[i]);
    if(o.output_all){ char p[1024]; snprintf(p,sizeof p,"%s.txt",o.output_all); o.txt_file=xstrdup(p); snprintf(p,sizeof p,"%s.json",o.output_all); o.json_file=xstrdup(p); snprintf(p,sizeof p,"%s.xml",o.output_all); o.xml_file=xstrdup(p); }
    if(o.txt_file) write_txt(o.txt_file,o.uris.v[0],&all);
    if(o.json_file) write_json(o.json_file,&all);
    if(o.xml_file) write_xml(o.xml_file,&all);
    return 0;
}
