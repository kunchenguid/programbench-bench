#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <zlib.h>

typedef struct {
    const unsigned char *data;
    size_t len;
    uint16_t flags, method, mod_time;
    uint32_t crc, comp_size, local_off;
    uint16_t name_len, extra_len;
    const unsigned char *extra;
} ZipInfo;

typedef struct {
    char *input, *dict, *charset_opt, *charset_file, *start;
    int min_len, max_len, file_number;
} Opts;

static uint16_t rd16(const unsigned char *p){ return (uint16_t)p[0] | ((uint16_t)p[1]<<8); }
static uint32_t rd32(const unsigned char *p){ return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }

static int exists_file(const char *p){ struct stat st; return p && stat(p,&st)==0 && S_ISREG(st.st_mode); }

static void print_help(void) {
    puts("Find the password of protected ZIP files\n");
    puts("Usage: executable [OPTIONS] --inputFile <inputFile>\n");
    puts("Options:");
    puts("  -i, --inputFile <inputFile>                    path to zip input file");
    puts("  -w, --workers <workers>                        number of workers");
    puts("  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file");
    puts("  -c, --charset <charset>                        charset to use to generate password [default: lud]");
    puts("      --charsetFile <charsetFile>                path to a charset file");
    puts("      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]");
    puts("      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]");
    puts("      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]");
    puts("  -s, --startingPassword <startingPassword>      password to start from");
    puts("  -h, --help                                     Print help");
    puts("  -V, --version                                  Print version");
}

static void arg_error(const char *msg) {
    fprintf(stderr, "%s\n", msg);
}

static char *xstrdup(const char *s) {
    size_t n = strlen(s) + 1;
    char *r = malloc(n);
    if (!r) exit(2);
    memcpy(r, s, n);
    return r;
}

static int parse_int(const char *s) {
    char *e = NULL; long v = strtol(s, &e, 10);
    if (!s[0] || (e && *e)) return 0;
    if (v < 0) v = 0;
    if (v > 1000000) v = 1000000;
    return (int)v;
}

static int parse_args(int argc, char **argv, Opts *o) {
    o->charset_opt = xstrdup("lud");
    o->min_len = 1; o->max_len = 10; o->file_number = 0;
    for (int i=1;i<argc;i++) {
        char *a = argv[i];
        if (!strcmp(a,"-h") || !strcmp(a,"--help")) { print_help(); exit(0); }
        if (!strcmp(a,"-V") || !strcmp(a,"--version")) { puts("zip-password-finder 0.10.3"); exit(0); }
        #define NEEDVAL() do{ if(i+1>=argc){ fprintf(stderr,"error: a value is required for '%s'\n",a); exit(2);} }while(0)
        if (!strcmp(a,"-i") || !strcmp(a,"--inputFile")) { NEEDVAL(); o->input=xstrdup(argv[++i]); }
        else if (!strcmp(a,"-p") || !strcmp(a,"--passwordDictionary")) { NEEDVAL(); o->dict=xstrdup(argv[++i]); }
        else if (!strcmp(a,"-c") || !strcmp(a,"--charset")) { NEEDVAL(); free(o->charset_opt); o->charset_opt=xstrdup(argv[++i]); }
        else if (!strcmp(a,"--charsetFile")) { NEEDVAL(); o->charset_file=xstrdup(argv[++i]); }
        else if (!strcmp(a,"--minPasswordLen")) { NEEDVAL(); o->min_len=parse_int(argv[++i]); }
        else if (!strcmp(a,"--maxPasswordLen")) { NEEDVAL(); o->max_len=parse_int(argv[++i]); }
        else if (!strcmp(a,"--fileNumber")) { NEEDVAL(); o->file_number=parse_int(argv[++i]); }
        else if (!strcmp(a,"-s") || !strcmp(a,"--startingPassword")) { NEEDVAL(); o->start=xstrdup(argv[++i]); }
        else if (!strcmp(a,"-w") || !strcmp(a,"--workers")) { NEEDVAL(); ++i; }
        else { fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] --inputFile <inputFile>\n\nFor more information, try '--help'.\n", a); exit(2); }
    }
    if (!o->input) { fputs("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.\n", stderr); return 0; }
    if (!exists_file(o->input)) { arg_error("CLI argument error - \"'inputFile' does not exist\""); return 0; }
    if (o->dict && !exists_file(o->dict)) { arg_error("CLI argument error - \"'passwordDictionary' does not exist\""); return 0; }
    if (o->charset_file && !exists_file(o->charset_file)) { arg_error("CLI argument error - \"'charsetFile' does not exist\""); return 0; }
    return 1;
}

static unsigned char *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    rewind(f);
    if (n < 0) { fclose(f); return NULL; }
    unsigned char *b = malloc((size_t)n + 1);
    if (!b) exit(2);
    size_t got = fread(b, 1, (size_t)n, f);
    fclose(f);
    b[got] = 0; *len = got; return b;
}

static int find_zip(const unsigned char *d, size_t n, int file_no, ZipInfo *z) {
    if (n < 22) return 0;
    size_t start = n > 66000 ? n - 66000 : 0, eocd = (size_t)-1;
    for (size_t i=n-22; i+1>start; i--) {
        if (rd32(d+i) == 0x06054b50) { eocd = i; break; }
        if (i == 0) break;
    }
    if (eocd == (size_t)-1 || eocd + 22 > n) return 0;
    uint16_t total = rd16(d+eocd+10);
    uint32_t cd_size = rd32(d+eocd+12), cd_off = rd32(d+eocd+16);
    if ((uint64_t)cd_off + cd_size > n) return 0;
    size_t p = cd_off;
    for (uint16_t idx=0; idx<total && p+46<=n; idx++) {
        if (rd32(d+p) != 0x02014b50) return 0;
        uint16_t fnl=rd16(d+p+28), exl=rd16(d+p+30), cml=rd16(d+p+32);
        if (p+46u+fnl+exl+cml > n) return 0;
        if ((int)idx == file_no) {
            memset(z,0,sizeof(*z)); z->data=d; z->len=n;
            z->flags=rd16(d+p+8); z->method=rd16(d+p+10); z->mod_time=rd16(d+p+12);
            z->crc=rd32(d+p+16); z->comp_size=rd32(d+p+20); z->local_off=rd32(d+p+42);
            z->extra=d+p+46+fnl; z->extra_len=exl;
            if ((uint64_t)z->local_off + 30 > n || rd32(d+z->local_off)!=0x04034b50) return 0;
            z->name_len=rd16(d+z->local_off+26); z->extra_len=rd16(d+z->local_off+28);
            size_t lo = z->local_off + 30u + z->name_len;
            if (lo + z->extra_len > n) return 0;
            z->extra = d + lo;
            return 1;
        }
        p += 46u + fnl + exl + cml;
    }
    return 0;
}

static uint32_t crc_tab[256]; static int crc_ready=0;
static void init_crc(void){ if(crc_ready) return; for(uint32_t i=0;i<256;i++){uint32_t c=i; for(int j=0;j<8;j++) c=(c&1)?0xedb88320u^(c>>1):(c>>1); crc_tab[i]=c;} crc_ready=1; }
static uint32_t crc32_upd(uint32_t c, unsigned char b){ return crc_tab[(c^b)&0xff] ^ (c>>8); }

typedef struct { uint32_t k0,k1,k2; } ZKeys;
static void zupdate(ZKeys *k, unsigned char c){ k->k0=crc32_upd(k->k0,c); k->k1 = k->k1 + (k->k0 & 0xff); k->k1 = k->k1 * 134775813u + 1u; k->k2=crc32_upd(k->k2,(unsigned char)(k->k1>>24)); }
static unsigned char zdecrypt_byte(ZKeys *k){ uint16_t t=(uint16_t)(k->k2 | 2); return (unsigned char)((t*(t^1))>>8); }
static int test_zipcrypto(const ZipInfo *z, const char *pw) {
    size_t off = z->local_off + 30u + z->name_len + z->extra_len;
    if (off + 12 > z->len) return 0;
    init_crc(); ZKeys k={0x12345678u,0x23456789u,0x34567890u};
    for (const unsigned char *p=(const unsigned char*)pw; *p; p++) zupdate(&k,*p);
    unsigned char h[12];
    for (int i=0;i<12;i++){ unsigned char c=z->data[off+i] ^ zdecrypt_byte(&k); zupdate(&k,c); h[i]=c; }
    unsigned char chk = (z->flags & 8) ? (unsigned char)(z->mod_time >> 8) : (unsigned char)(z->crc >> 24);
    if (h[11] != chk) return 0;
    if (z->comp_size < 12 || off + z->comp_size > z->len) return 0;
    size_t clen = z->comp_size - 12u;
    unsigned char *plain_comp = malloc(clen ? clen : 1);
    if (!plain_comp) exit(2);
    for (size_t i=0; i<clen; i++) {
        unsigned char c = z->data[off+12+i] ^ zdecrypt_byte(&k);
        zupdate(&k, c);
        plain_comp[i] = c;
    }
    unsigned char *out = NULL;
    size_t out_len = 0;
    int ok = 0;
    if (z->method == 0) {
        out = plain_comp;
        out_len = clen;
        plain_comp = NULL;
        ok = 1;
    } else if (z->method == 8) {
        size_t cap = clen * 4 + 1024;
        if (cap < 1024) cap = 1024;
        z_stream zs;
        memset(&zs, 0, sizeof(zs));
        if (inflateInit2(&zs, -MAX_WBITS) == Z_OK) {
            out = malloc(cap);
            if (!out) exit(2);
            zs.next_in = plain_comp;
            zs.avail_in = (uInt)clen;
            int ret;
            do {
                if (zs.total_out == cap) {
                    cap *= 2;
                    out = realloc(out, cap);
                    if (!out) exit(2);
                }
                zs.next_out = out + zs.total_out;
                zs.avail_out = (uInt)(cap - zs.total_out);
                ret = inflate(&zs, Z_NO_FLUSH);
            } while (ret == Z_OK);
            if (ret == Z_STREAM_END) {
                out_len = zs.total_out;
                ok = 1;
            }
            inflateEnd(&zs);
        }
    }
    if (ok) {
        uint32_t c = crc32(0L, Z_NULL, 0);
        c = crc32(c, out, (uInt)out_len);
        ok = (c == z->crc);
    }
    free(plain_comp);
    free(out);
    return ok;
}

typedef struct { uint32_t h[5]; uint64_t len; unsigned char buf[64]; size_t used; } SHA1;
static uint32_t rol(uint32_t x,int n){ return (x<<n)|(x>>(32-n)); }
static void sha1_block(SHA1*s,const unsigned char*b){ uint32_t w[80]; for(int i=0;i<16;i++)w[i]=((uint32_t)b[4*i]<<24)|((uint32_t)b[4*i+1]<<16)|((uint32_t)b[4*i+2]<<8)|b[4*i+3]; for(int i=16;i<80;i++)w[i]=rol(w[i-3]^w[i-8]^w[i-14]^w[i-16],1); uint32_t a=s->h[0],bb=s->h[1],c=s->h[2],d=s->h[3],e=s->h[4]; for(int i=0;i<80;i++){uint32_t f,k;if(i<20){f=(bb&c)|((~bb)&d);k=0x5a827999;}else if(i<40){f=bb^c^d;k=0x6ed9eba1;}else if(i<60){f=(bb&c)|(bb&d)|(c&d);k=0x8f1bbcdc;}else{f=bb^c^d;k=0xca62c1d6;}uint32_t t=rol(a,5)+f+e+k+w[i];e=d;d=c;c=rol(bb,30);bb=a;a=t;} s->h[0]+=a;s->h[1]+=bb;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e; }
static void sha1_init(SHA1*s){ s->h[0]=0x67452301;s->h[1]=0xefcdab89;s->h[2]=0x98badcfe;s->h[3]=0x10325476;s->h[4]=0xc3d2e1f0;s->len=0;s->used=0; }
static void sha1_update(SHA1*s,const unsigned char*d,size_t n){ s->len += (uint64_t)n*8; while(n){ size_t m=64-s->used; if(m>n)m=n; memcpy(s->buf+s->used,d,m); s->used+=m; d+=m; n-=m; if(s->used==64){sha1_block(s,s->buf);s->used=0;} } }
static void sha1_final(SHA1*s,unsigned char out[20]){ size_t u=s->used; s->buf[u++]=0x80; if(u>56){ memset(s->buf+u,0,64-u); sha1_block(s,s->buf); u=0; } memset(s->buf+u,0,56-u); for(int i=0;i<8;i++) s->buf[56+i]=(unsigned char)(s->len>>(56-8*i)); sha1_block(s,s->buf); for(int i=0;i<5;i++){ out[4*i]=s->h[i]>>24; out[4*i+1]=s->h[i]>>16; out[4*i+2]=s->h[i]>>8; out[4*i+3]=s->h[i]; } }
static void hmac_sha1(const unsigned char *key,size_t klen,const unsigned char*data,size_t dlen,unsigned char out[20]){ unsigned char k0[64],ipad[64],opad[64],tk[20]; if(klen>64){SHA1 s;sha1_init(&s);sha1_update(&s,key,klen);sha1_final(&s,tk);key=tk;klen=20;} memset(k0,0,64);memcpy(k0,key,klen); for(int i=0;i<64;i++){ipad[i]=k0[i]^0x36;opad[i]=k0[i]^0x5c;} SHA1 s;sha1_init(&s);sha1_update(&s,ipad,64);sha1_update(&s,data,dlen);sha1_final(&s,tk);sha1_init(&s);sha1_update(&s,opad,64);sha1_update(&s,tk,20);sha1_final(&s,out); }
static void pbkdf2_sha1(const unsigned char*pw,size_t plen,const unsigned char*salt,size_t slen,int iter,unsigned char*out,size_t olen){ uint32_t block=1; size_t pos=0; unsigned char *msg=malloc(slen+4),u[20],t[20]; if(!msg)exit(2); memcpy(msg,salt,slen); while(pos<olen){ msg[slen]=block>>24;msg[slen+1]=block>>16;msg[slen+2]=block>>8;msg[slen+3]=block; hmac_sha1(pw,plen,msg,slen+4,u); memcpy(t,u,20); for(int i=1;i<iter;i++){ hmac_sha1(pw,plen,u,20,u); for(int j=0;j<20;j++)t[j]^=u[j]; } size_t m=olen-pos; if(m>20)m=20; memcpy(out+pos,t,m); pos+=m; block++; } free(msg); }

static int find_aes(const ZipInfo*z,int *salt_len,int *key_len) {
    size_t e=0; while(e+4<=z->extra_len){ uint16_t id=rd16(z->extra+e), sz=rd16(z->extra+e+2); if(e+4u+sz>z->extra_len)break; if(id==0x9901 && sz>=7){ unsigned char strength=z->extra[e+4+6]; if(strength==1){*salt_len=8;*key_len=16;} else if(strength==2){*salt_len=12;*key_len=24;} else if(strength==3){*salt_len=16;*key_len=32;} else return 0; return 1; } e+=4u+sz; } return 0;
}
static int test_aes(const ZipInfo*z,const char*pw){ int sl=0,kl=0; if(!find_aes(z,&sl,&kl)) return 0; size_t off=z->local_off+30u+z->name_len+z->extra_len; if(off+(size_t)sl+2>z->len)return 0; unsigned char dk[66]; if((size_t)(2*kl+2)>sizeof(dk))return 0; pbkdf2_sha1((const unsigned char*)pw,strlen(pw),z->data+off,sl,1000,dk,2u*kl+2u); return dk[2*kl]==z->data[off+sl] && dk[2*kl+1]==z->data[off+sl+1]; }

static int test_password(const ZipInfo*z,const char*pw){ if(z->method==99) return test_aes(z,pw); if(!(z->flags&1)) return 1; return test_zipcrypto(z,pw); }

static char *build_charset(Opts*o) {
    if (o->charset_file) { size_t n; unsigned char *b=read_file(o->charset_file,&n); if(!b)return xstrdup(""); while(n && (b[n-1]=='\n'||b[n-1]=='\r')) b[--n]=0; return (char*)b; }
    const char *lower="abcdefghijklmnopqrstuvwxyz", *upper="ABCDEFGHIJKLMNOPQRSTUVWXYZ", *dig="0123456789", *hexl="0123456789abcdef", *hexu="0123456789ABCDEF";
    const char *sym=" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
    size_t cap=256,len=0; char *r=malloc(cap); if(!r)exit(2); r[0]=0;
    for(char *p=o->charset_opt; *p; p++){ const char *add=NULL; if(*p=='l')add=lower; else if(*p=='u')add=upper; else if(*p=='d')add=dig; else if(*p=='h')add=hexl; else if(*p=='H')add=hexu; else if(*p=='s')add=sym; else { fprintf(stderr,"CLI argument error - \"Unknown charset option '%c'\"\n",*p); free(r); return NULL; } size_t a=strlen(add); if(len+a+1>cap){cap*=2;r=realloc(r,cap);if(!r)exit(2);} memcpy(r+len,add,a);len+=a;r[len]=0; }
    return r;
}

static char *try_dict(const ZipInfo*z,const char*path){ FILE*f=fopen(path,"r"); if(!f)return NULL; char *line=NULL; size_t cap=0; ssize_t n; while((n=getline(&line,&cap,f))!=-1){ while(n>0 && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0; if(test_password(z,line)){ fclose(f); return line; } } free(line); fclose(f); return NULL; }

static char *try_brute(const ZipInfo*z,const char*cs,int minl,int maxl,const char*start) {
    int base=(int)strlen(cs); if(base<=0 || minl<0 || maxl<minl || maxl>64) return NULL;
    int started = start ? 0 : 1;
    for(int len=minl; len<=maxl; len++){
        int *idx=calloc((size_t)len,sizeof(int)); char *pw=malloc((size_t)len+1); if(!idx||!pw)exit(2);
        int done=0; while(!done){
            for(int i=0;i<len;i++) pw[i]=cs[idx[i]];
            pw[len]=0;
            if(!started && strcmp(pw,start)==0) started=1;
            if(started && test_password(z,pw)){ free(idx); return pw; }
            int pos=len-1; while(pos>=0){ idx[pos]++; if(idx[pos]<base) break; idx[pos]=0; pos--; } if(pos<0) done=1;
        }
        free(idx); free(pw);
    }
    return NULL;
}

static void elapsed_print(struct timespec a, struct timespec b) {
    long sec=b.tv_sec-a.tv_sec, ns=b.tv_nsec-a.tv_nsec; if(ns<0){sec--;ns+=1000000000L;}
    long ms=ns/1000000L, us=(ns/1000L)%1000L, rem=ns%1000L;
    if(sec>0) printf("Time elapsed: %lds %ldms %ldus %ldns\n",sec,ms,us,rem);
    else printf("Time elapsed: %ldms %ldus %ldns\n",ms,us,rem);
}

int main(int argc, char **argv) {
    Opts o={0}; if(!parse_args(argc,argv,&o)) return 1;
    struct timespec t0,t1; clock_gettime(CLOCK_MONOTONIC,&t0);
    size_t n=0; unsigned char *buf=read_file(o.input,&n); ZipInfo z;
    char *found=NULL;
    if(buf && find_zip(buf,n,o.file_number,&z)) {
        if(o.dict) found=try_dict(&z,o.dict);
        else { char *cs=build_charset(&o); if(cs){ found=try_brute(&z,cs,o.min_len,o.max_len,o.start); free(cs); } }
    }
    clock_gettime(CLOCK_MONOTONIC,&t1);
    elapsed_print(t0,t1);
    if(found){ printf("Password found:%s\n",found); free(found); }
    else puts("Password not found");
    free(buf); return found?0:0;
}
