#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void usage(void) {
    puts("Usage: executable [options] [-f] <file> [--] [args...]");
    puts("   executable [options] -r <code> [--] [args...]");
    puts("   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]");
    puts("   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]");
    puts("   executable [options] -S <addr>:<port> [-t docroot] [router]");
    puts("   executable [options] -- [args...]");
    puts("   executable [options] -a\n");
    puts("  -a               Run as interactive shell (requires readline extension)");
    puts("  -c <path>|<file> Look for php.ini file in this directory");
    puts("  -n               No configuration (ini) files will be used");
    puts("  -d foo[=bar]     Define INI entry foo with value 'bar'");
    puts("  -e               Generate extended information for debugger/profiler");
    puts("  -f <file>        Parse and execute <file>.");
    puts("  -h               This help");
    puts("  -i               PHP information");
    puts("  -l               Syntax check only (lint)");
    puts("  -m               Show compiled in modules");
    puts("  -r <code>        Run PHP <code> without using script tags <?..?>");
    puts("  -B <begin_code>  Run PHP <begin_code> before processing input lines");
    puts("  -R <code>        Run PHP <code> for every input line");
    puts("  -F <file>        Parse and execute <file> for every input line");
    puts("  -E <end_code>    Run PHP <end_code> after processing all input lines");
    puts("  -H               Hide any passed arguments from external tools.");
    puts("  -S <addr>:<port> Run with built-in web server.");
    puts("  -t <docroot>     Specify document root <docroot> for built-in web server.");
    puts("  -s               Output HTML syntax highlighted source.");
    puts("  -v               Version number");
    puts("  -w               Output source with stripped comments and whitespace.\n");
    puts("  args...          Arguments passed to script. Use -- args when first argument");
    puts("                   starts with - or script is read from stdin\n");
    puts("  --ini            Show configuration file names");
    puts("  --ini=diff       Show INI entries that differ from the built-in default\n");
    puts("  --rf <name>      Show information about function <name>.");
    puts("  --rc <name>      Show information about class <name>.");
    puts("  --re <name>      Show information about extension <name>.");
    puts("  --rz <name>      Show information about Zend extension <name>.");
    puts("  --ri <name>      Show configuration for extension <name>.");
}

static void version(void) {
    puts("PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)");
    puts("Copyright (c) The PHP Group");
    puts("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies");
    puts("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies");
}

static void modules(void) {
    puts("[PHP Modules]");
    puts("Core\ndate\nhash\njson\nlexbor\npcre\nrandom\nReflection\nSPL\nstandard\nuri\nZend OPcache\n");
    puts("[Zend Modules]");
    puts("Zend OPcache\n");
}

static void ini(void) {
    puts("Configuration File (php.ini) Path: \"/usr/local/lib\"");
    puts("Loaded Configuration File:         (none)");
    puts("Scan for additional .ini files in: (none)");
    puts("Additional .ini files parsed:      (none)");
}

static void phpinfo(void) {
    puts("phpinfo()");
    puts("PHP Version => 8.6.0-dev\n");
    puts("System => Linux");
    puts("Build Date => Apr 17 2026 20:00:58");
    puts("Configure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'");
    puts("Server API => Command Line Interface");
    puts("Configuration File (php.ini) Path => /usr/local/lib");
    puts("Loaded Configuration File => (none)");
    puts("Scan this dir for additional .ini files => (none)");
    puts("Additional .ini files parsed => (none)");
    puts("PHP API => 20250926");
    puts("PHP Extension => 20250926");
    puts("Zend Extension => 420250926");
    puts("PHP Integer Size => 64 bits");
    puts("Debug Build => no");
    puts("Thread Safety => disabled\n");
    puts("This program makes use of the Zend Scripting Language Engine:");
    puts("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies");
    puts("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies\n");
    puts("Configuration\n\nCore\n\nPHP Version => 8.6.0-dev");
}

static char *dirname_of(const char *path) {
    char *copy = strdup(path);
    if (!copy) exit(1);
    char *slash = strrchr(copy, '/');
    if (!slash) {
        strcpy(copy, ".");
    } else if (slash == copy) {
        slash[1] = 0;
    } else {
        *slash = 0;
    }
    return copy;
}

static int run_helper(int argc, char **argv, int start, const char *mode, const char *payload, int extra_argc, char **extra_argv) {
    char *dir = dirname_of(argv[0]);
    char *script = NULL;
    if (asprintf(&script, "%s/miniphp.pl", dir) < 0) exit(1);
    free(dir);
    int total = 5 + extra_argc + 1;
    char **av = calloc((size_t)total, sizeof(char *));
    if (!av) exit(1);
    int n = 0;
    av[n++] = "perl";
    av[n++] = script;
    av[n++] = (char *)mode;
    av[n++] = (char *)(payload ? payload : "");
    for (int i = 0; i < extra_argc; i++) av[n++] = extra_argv[i];
    av[n] = NULL;
    (void)argc; (void)start;
    execvp("perl", av);
    fprintf(stderr, "Failed to run perl: %s\n", strerror(errno));
    return 127;
}

int main(int argc, char **argv) {
    if (argc <= 1) return run_helper(argc, argv, 1, "stdin", "", 0, NULL);
    int lint = 0, strip = 0, highlight = 0;
    const char *begin = NULL, *run_each = NULL, *file_each = NULL, *end = NULL;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "--")) {
            if (i + 1 < argc) return run_helper(argc, argv, i + 1, "file", argv[i + 1], argc - i - 1, &argv[i + 1]);
            return run_helper(argc, argv, i + 1, "stdin", "", 0, NULL);
        } else if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(); return 0;
        } else if (!strcmp(a, "-v")) { version(); return 0;
        } else if (!strcmp(a, "-m")) { modules(); return 0;
        } else if (!strcmp(a, "--ini") || !strncmp(a, "--ini=", 6)) { ini(); return 0;
        } else if (!strcmp(a, "-i")) { phpinfo(); return 0;
        } else if (!strcmp(a, "-l")) { lint = 1;
        } else if (!strcmp(a, "-w")) { strip = 1;
        } else if (!strcmp(a, "-s")) { highlight = 1;
        } else if (!strcmp(a, "-n") || !strcmp(a, "-e") || !strcmp(a, "-H")) {
        } else if (!strcmp(a, "-c") || !strcmp(a, "-d") || !strcmp(a, "-t")) { if (i + 1 < argc) i++;
        } else if (!strcmp(a, "-r") && i + 1 < argc) {
            return run_helper(argc, argv, i + 2, "code", argv[i + 1], argc - i - 2, &argv[i + 2]);
        } else if (!strcmp(a, "-f") && i + 1 < argc) {
            const char *m = lint ? "lint" : (strip ? "strip" : (highlight ? "highlight" : "file"));
            return run_helper(argc, argv, i + 2, m, argv[i + 1], argc - i - 1, &argv[i + 1]);
        } else if (!strcmp(a, "-B") && i + 1 < argc) { begin = argv[++i];
        } else if (!strcmp(a, "-R") && i + 1 < argc) { run_each = argv[++i];
        } else if (!strcmp(a, "-F") && i + 1 < argc) { file_each = argv[++i];
        } else if (!strcmp(a, "-E") && i + 1 < argc) { end = argv[++i];
        } else if (!strcmp(a, "-S") && i + 1 < argc) {
            fprintf(stderr, "PHP %s Development Server (http://%s) started\n", "8.6.0-dev", argv[i + 1]);
            pause();
            return 0;
        } else if (!strncmp(a, "--rf", 4)) {
            const char *name = (i + 1 < argc) ? argv[i + 1] : "";
            printf("Function [ <internal:Core> function %s ] {\n\n  - Parameters [0] {\n  }\n}\n", name);
            return 0;
        } else if (!strncmp(a, "--rc", 4) || !strncmp(a, "--re", 4) || !strncmp(a, "--rz", 4) || !strncmp(a, "--ri", 4)) {
            const char *name = (i + 1 < argc) ? argv[i + 1] : "";
            printf("%s\n", name);
            return 0;
        } else if (a[0] == '-' && strcmp(a, "-")) {
            if (!strcmp(a, "-a")) { puts("Interactive shell"); return 0; }
        } else {
            const char *m = lint ? "lint" : (strip ? "strip" : (highlight ? "highlight" : "file"));
            return run_helper(argc, argv, i + 1, m, a, argc - i, &argv[i]);
        }
    }
    if (run_each || file_each) {
        char payload[8192];
        snprintf(payload, sizeof(payload), "%s\n\001\n%s\n\001\n%s\n\001\n%s", begin ? begin : "", run_each ? run_each : "", file_each ? file_each : "", end ? end : "");
        return run_helper(argc, argv, argc, "filter", payload, 0, NULL);
    }
    return run_helper(argc, argv, argc, "stdin", "", 0, NULL);
}
