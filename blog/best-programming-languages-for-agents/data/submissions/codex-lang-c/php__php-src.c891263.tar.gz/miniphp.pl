#!/usr/bin/perl
use warnings;
no strict;
no warnings 'uninitialized';
eval { require JSON::PP; JSON::PP->import(); };

package PHPBool;
use overload
    '0+' => sub { $_[0]->{v} ? 1 : 0 },
    '""' => sub { $_[0]->{v} ? '1' : '' },
    'bool' => sub { $_[0]->{v} ? 1 : 0 },
    fallback => 1;
sub new { bless { v => $_[1] ? 1 : 0 }, $_[0] }

package main;

my ($MODE, $PAYLOAD, @PHP_ARGV) = @ARGV;
$MODE ||= 'stdin';
$PAYLOAD = '' unless defined $PAYLOAD;

sub php_s {
    my ($v) = @_;
    return '' unless defined $v;
    return 'Array' if ref($v) eq 'ARRAY';
    return "$v";
}

sub var_dump {
    for my $v (@_) { dump_one($v, 0); }
}

sub dump_one {
    my ($v, $ind) = @_;
    my $pad = '  ' x $ind;
    if (!defined $v) { print "NULL\n"; }
    elsif (ref($v) eq 'PHPBool') { print "bool(".($v->{v} ? "true" : "false").")\n"; }
    elsif (ref($v) eq 'ARRAY') {
        print "array(".scalar(@$v).") {\n";
        for my $i (0..$#$v) {
            print $pad."  [$i]=>\n".$pad."  ";
            dump_one($v->[$i], $ind + 1);
        }
        print $pad."}\n";
    } elsif ($v =~ /^-?\d+\z/) { print "int($v)\n"; }
    elsif ($v =~ /^-?(?:\d+\.\d*|\.\d+)(?:[eE][+-]?\d+)?\z/) { print "float($v)\n"; }
    else { print 'string('.length("$v").') "'.$v."\"\n"; }
}

sub print_r {
    my ($v, $ret) = @_;
    my $s = pr($v, 0);
    return $s if $ret;
    print $s;
    return 1;
}

sub pr {
    my ($v, $ind) = @_;
    return php_s($v) unless ref($v) eq 'ARRAY';
    my $sp = ' ' x $ind;
    my $out = "Array\n$sp(\n";
    for my $i (0..$#$v) {
        $out .= (' ' x ($ind+4))."[$i] => ";
        $out .= ref($v->[$i]) eq 'ARRAY' ? pr($v->[$i], $ind+4) : php_s($v->[$i])."\n";
    }
    $out .= "$sp)\n";
    return $out;
}

sub strlen { length(php_s($_[0])) }
sub count { ref($_[0]) eq 'ARRAY' ? scalar(@{$_[0]}) : 0 }
sub sizeof { count(@_) }
sub strtoupper { uc(php_s($_[0])) }
sub strtolower { lc(php_s($_[0])) }
sub trim { my $s = php_s($_[0]); $s =~ s/^\s+|\s+$//g; $s }
sub php_substr { CORE::substr(php_s($_[0]), $_[1] || 0, defined $_[2] ? $_[2] : length(php_s($_[0]))) }
sub strpos { my $p = index(php_s($_[0]), php_s($_[1])); $p < 0 ? 0 : $p }
sub intval { int($_[0] || 0) }
sub floatval { 0.0 + ($_[0] || 0) }
sub strval { php_s($_[0]) }
sub phpversion { '8.6.0-dev' }
sub get_loaded_extensions { ['Core','date','hash','json','pcre','random','Reflection','SPL','standard','Zend OPcache'] }
sub isset { defined $_[0] ? 1 : 0 }
sub is_null { defined $_[0] ? 0 : 1 }
sub is_array { ref($_[0]) eq 'ARRAY' ? 1 : 0 }
sub is_string { !ref($_[0]) && defined($_[0]) && "$_[0]" !~ /^-?\d+(?:\.\d+)?\z/ ? 1 : 0 }
sub is_int { !ref($_[0]) && defined($_[0]) && "$_[0]" =~ /^-?\d+\z/ ? 1 : 0 }
sub is_float { !ref($_[0]) && defined($_[0]) && "$_[0]" =~ /^-?\d+\.\d+\z/ ? 1 : 0 }
sub explode { [ split(/\Q$_[0]\E/, php_s($_[1])) ] }
sub implode { my ($sep, $arr) = @_; if (ref($sep) eq 'ARRAY') { $arr = $sep; $sep = ''; } join(php_s($sep), @$arr) }
sub join { implode(@_) }
sub array_sum { my $s=0; $s += $_ for @{$_[0] || []}; $s }
sub array_merge { my @o; for my $a (@_) { push @o, ref($a) eq 'ARRAY' ? @$a : $a; } \@o }
sub in_array { my ($needle, $hay) = @_; for (@{$hay || []}) { return 1 if $_ eq $needle; } 0 }
sub array_reverse { [ reverse @{$_[0] || []} ] }
sub range { [ $_[0] .. $_[1] ] }
sub min { my $m = shift; for (@_) { $m = $_ if $_ < $m } $m }
sub max { my $m = shift; for (@_) { $m = $_ if $_ > $m } $m }
sub abs { CORE::abs($_[0]) }
sub floor { int($_[0]) }
sub ceil { my $x=$_[0]; int($x) == $x ? int($x) : int($x)+1 }
sub round { int($_[0] + ($_[0] < 0 ? -0.5 : 0.5)) }
sub time { CORE::time() }
sub rand { my ($a,$b)=@_; $a=0 unless defined $a; $b=2147483647 unless defined $b; int($a + CORE::rand($b-$a+1)) }
sub mt_rand { &rand(@_) }
sub json_encode { defined $JSON::PP::VERSION ? JSON::PP::encode_json($_[0]) : php_s($_[0]) }
sub json_decode { defined $JSON::PP::VERSION ? JSON::PP::decode_json($_[0]) : undef }
sub file_get_contents { my $s = slurp($_[0]); defined $s ? $s : 0 }
sub ord { CORE::ord(php_s($_[0])) }
sub chr { CORE::chr($_[0]) }

sub slurp {
    my ($path) = @_;
    open my $fh, '<', $path or return undef;
    local $/;
    return <$fh>;
}

sub qstr {
    my ($s) = @_;
    $s =~ s/\\/\\\\/g; $s =~ s/'/\\'/g; $s =~ s/\n/\\n/g; $s =~ s/\r/\\r/g; $s =~ s/\t/\\t/g;
    return "'$s'";
}

sub translate_expr_bits {
    my ($c) = @_;
    $c =~ s/\bPHP_EOL\b/"\\n"/g;
    $c =~ s/\btrue\b/PHPBool->new(1)/ig;
    $c =~ s/\bfalse\b/PHPBool->new(0)/ig;
    $c =~ s/\bnull\b/undef/ig;
    $c =~ s/\bsubstr\s*\(/php_substr(/ig;
    $c =~ s/(\$[A-Za-z_]\w*)\s*\[([^\]]+)\]/$1.'->['.$2.']'/ge;
    return $c;
}

sub translate {
    my ($code) = @_;
    $code =~ s/\r\n/\n/g;
    $code =~ s/<\?(?:php)?//ig;
    $code =~ s/\?>//g;
    $code =~ s{//[^\n]*}{}g;
    $code =~ s{#[^\n]*}{}g;
    $code =~ s{/\*.*?\*/}{}gs;
    $code =~ s/\belseif\b/elsif/ig;
    $code =~ s/\bfunction\s+([A-Za-z_]\w*)\s*\(([^)]*)\)\s*\{/"sub $1 { my (".CORE::join(",", ($2 =~ m{(\$[A-Za-z_]\w*)}g)).") = \@_;"/ge;
    $code =~ s/\becho\s+([^;]+);/"print ".translate_expr_bits($1).";"/ge;
    $code =~ s/\bprint\s+([^;]+);/"print ".translate_expr_bits($1).";"/ge;
    $code =~ s/\bforeach\s*\((\$[A-Za-z_]\w*)\s+as\s+(\$[A-Za-z_]\w*)\s*=>\s*(\$[A-Za-z_]\w*)\)/'foreach my '.$2.' (0..$#'.$1.') { my '.$3.' = '.$1.'->['.$2.'];'/ge;
    $code =~ s/\bforeach\s*\((\$[A-Za-z_]\w*)\s+as\s+(\$[A-Za-z_]\w*)\)/'foreach my '.$2.' (@{'.$1.'})'/ge;
    $code = translate_expr_bits($code);
    $code =~ s/\b(exit|die)\s*\(([^)]*)\)\s*;/exit($2);/g;
    return $code;
}

sub run_code {
    my ($code) = @_;
    our ($argc, $argv, $argn, $argi);
    local $argc = scalar(@PHP_ARGV);
    local $argv = \@PHP_ARGV;
    my $perl = translate($code);
    my $ok = eval $perl;
    if ($@) {
        print STDERR "$@\n$perl\n" if $ENV{MINIPHP_DEBUG};
        print STDERR "\nParse error: syntax error, unexpected token in Command line code on line 1\n";
        exit 255;
    }
    return $ok;
}

sub run_file {
    my ($path) = @_;
    my $src = slurp($path);
    if (!defined $src) {
        print STDERR "Could not open input file: $path\n";
        return 1;
    }
    my $pos = 0;
    while ($src =~ /<\?(php|=)?/ig) {
        print substr($src, $pos, $-[0] - $pos) if $-[0] > $pos;
        my $is_echo = defined($1) && $1 eq '=';
        my $start = pos($src);
        my $end = index($src, '?>', $start);
        $end = length($src) if $end < 0;
        my $code = substr($src, $start, $end - $start);
        $code = "echo $code;" if $is_echo;
        run_code($code);
        $pos = $end + (($end < length($src)) ? 2 : 0);
        pos($src) = $pos;
    }
    print substr($src, $pos) if $pos < length($src);
    return 0;
}

if ($MODE eq 'code') {
    run_code($PAYLOAD);
    exit 0;
} elsif ($MODE eq 'file') {
    exit run_file($PAYLOAD);
} elsif ($MODE eq 'stdin') {
    local $/;
    run_code(<STDIN>);
    exit 0;
} elsif ($MODE eq 'lint') {
    if (!defined slurp($PAYLOAD)) { print STDERR "Could not open input file: $PAYLOAD\n"; exit 1; }
    print "No syntax errors detected in $PAYLOAD\n";
    exit 0;
} elsif ($MODE eq 'strip') {
    my $s = slurp($PAYLOAD);
    if (!defined $s) { print STDERR "Could not open input file: $PAYLOAD\n"; exit 1; }
    print $s;
    exit 0;
} elsif ($MODE eq 'highlight') {
    my $s = slurp($PAYLOAD);
    if (!defined $s) { print STDERR "Could not open input file: $PAYLOAD\n"; exit 1; }
    $s =~ s/&/&amp;/g; $s =~ s/</&lt;/g; $s =~ s/>/&gt;/g;
    print '<pre><code style="color: #000000">'.$s.'</code></pre>';
    exit 0;
} elsif ($MODE eq 'filter') {
    my ($b, $r, $f, $e) = split(/\001/, $PAYLOAD, 4);
    run_code($b) if defined($b) && $b =~ /\S/;
    my $each = ($f && $f =~ /\S/) ? slurp($f) : ($r || '');
    our ($argn, $argi);
    $argi = 0;
    while (my $line = <STDIN>) {
        chomp $line;
        $argn = $line;
        $argi++;
        run_code($each);
    }
    run_code($e) if defined($e) && $e =~ /\S/;
    exit 0;
}
exit 0;
