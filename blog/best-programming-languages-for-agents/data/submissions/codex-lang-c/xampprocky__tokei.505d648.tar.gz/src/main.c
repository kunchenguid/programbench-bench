#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { long blanks, code, comments; } Counts;
typedef struct {
    char *name;
    char *lang;
    Counts c;
    Counts child;
    char *child_lang;
} Report;
typedef struct { char *lang; Counts c; long files; Counts child; char *child_lang; } Agg;
typedef struct { char **v; int n, cap; } Strs;

static Report *reports; static int nreports, capreports;
static Agg *aggs; static int naggs, capaggs;
static Strs excludes, types, inputs, ignores;
static int opt_files, opt_hidden, opt_no_ignore, opt_compact;
static char *opt_output, *opt_streaming, *sort_key, *rsort_key;
static char num_sep = 0;

static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(2);} return p; }
static void strs_add(Strs *s, const char *v){ if(s->n==s->cap){s->cap=s->cap? s->cap*2:8; s->v=realloc(s->v,s->cap*sizeof(char*)); if(!s->v) exit(2);} s->v[s->n++]=xstrdup(v); }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }
static bool starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }
static const char *base_name(const char *p){ const char *s=strrchr(p,'/'); return s?s+1:p; }
static const char *extension(const char *p){ const char *b=base_name(p), *d=strrchr(b,'.'); return d && d[1]? d+1:""; }

typedef struct { const char *ext, *lang, *kind; } Map;
static Map maps[] = {
{"c","C","c"},{"ec","C","c"},{"pgc","C","c"},{"h","C Header","c"},
{"cc","C++","c"},{"cpp","C++","c"},{"cxx","C++","c"},{"c++","C++","c"},{"hpp","C++ Header","c"},{"hh","C++ Header","c"},{"hxx","C++ Header","c"},
{"java","Java","c"},{"js","JavaScript","c"},{"jsx","JSX","c"},{"ts","TypeScript","c"},{"tsx","TSX","c"},{"css","CSS","c"},{"scss","Sass","c"},{"sass","Sass","hash"},
{"rs","Rust","c"},{"go","Go","c"},{"swift","Swift","c"},{"kt","Kotlin","c"},{"kts","Kotlin","c"},{"cs","C#","c"},{"php","PHP","c"},
{"py","Python","hash"},{"pyw","Python","hash"},{"rb","Ruby","hash"},{"pl","Perl","hash"},{"pm","Perl","hash"},{"r","R","hash"},
{"sh","Shell","hash"},{"bash","BASH","hash"},{"zsh","Zsh","hash"},{"fish","Fish","hash"},{"ksh","Ksh","hash"},{"csh","C Shell","hash"},
{"yaml","YAML","hash"},{"yml","YAML","hash"},{"toml","TOML","hash"},{"ini","INI","hash"},{"conf","Config","hash"},{"make","Makefile","hash"},
{"json","JSON","plain"},{"json5","JSON","c"},{"lock","JSON","plain"},{"xml","XML","xml"},{"html","HTML","html"},{"htm","HTML","html"},{"xhtml","HTML","html"},
{"md","Markdown","md"},{"markdown","Markdown","md"},{"mdx","MDX","md"},{"txt","Plain Text","text"},{"text","Plain Text","text"},
{"sql","SQL","dash"},{"lua","Lua","dash"},{"hs","Haskell","hs"},{"lhs","Haskell","hs"},{"erl","Erlang","percent"},{"ex","Elixir","hash"},{"exs","Elixir","hash"},
{"vim","Vim Script","quote"},{"dockerfile","Dockerfile","hash"},{"gradle","Groovy","c"},{"groovy","Groovy","c"},{"scala","Scala","c"},
{"dart","Dart","c"},{"m","Objective-C","c"},{"mm","Objective-C++","c"},{"vue","Vue","html"},{"svelte","Svelte","html"},
{NULL,NULL,NULL}};

static const char *lang_kind(const char *lang){
    for(int i=0; maps[i].ext; i++) if(strcmp(maps[i].lang,lang)==0) return maps[i].kind;
    return "plain";
}
static const char *detect_lang(const char *path){
    const char *b=base_name(path);
    if(!strcasecmp(b,"makefile")||!strcasecmp(b,"gnumakefile")) return "Makefile";
    if(!strcasecmp(b,"dockerfile")||strstr(b,".dockerfile")) return "Dockerfile";
    const char *ext=extension(path);
    for(int i=0; maps[i].ext; i++) if(!strcasecmp(ext,maps[i].ext)) return maps[i].lang;
    return NULL;
}
static int lang_index(const char *lang){
    for(int i=0;i<naggs;i++) if(!strcmp(aggs[i].lang,lang)) return i;
    if(naggs==capaggs){capaggs=capaggs?capaggs*2:32; aggs=realloc(aggs,capaggs*sizeof(Agg)); if(!aggs) exit(2);}
    aggs[naggs]=(Agg){.lang=xstrdup(lang)}; return naggs++;
}
static void add_report(const char *path, const char *lang, Counts c, const char *child_lang, Counts child){
    if(nreports==capreports){capreports=capreports?capreports*2:128; reports=realloc(reports,capreports*sizeof(Report)); if(!reports) exit(2);}
    reports[nreports++]=(Report){xstrdup(path),xstrdup(lang),c,child,child_lang?xstrdup(child_lang):NULL};
    int i=lang_index(lang); aggs[i].files++; aggs[i].c.blanks+=c.blanks; aggs[i].c.code+=c.code; aggs[i].c.comments+=c.comments;
    if(child_lang){ aggs[i].child_lang=xstrdup(child_lang); aggs[i].child.blanks+=child.blanks; aggs[i].child.code+=child.code; aggs[i].child.comments+=child.comments; }
}

static void count_plain(FILE *f, Counts *c, bool text_comments){
    char *line=NULL; size_t n=0;
    while(getline(&line,&n,f)!=-1){ char *t=trim(line); if(!*t)c->blanks++; else if(text_comments)c->comments++; else c->code++; }
    free(line);
}
static void count_hash(FILE *f, Counts *c, const char *kind){
    char *line=NULL; size_t n=0; const char *mark="#";
    if(!strcmp(kind,"dash")) mark="--"; else if(!strcmp(kind,"percent")) mark="%"; else if(!strcmp(kind,"quote")) mark="\""; else if(!strcmp(kind,"hs")) mark="--";
    while(getline(&line,&n,f)!=-1){
        char *t=trim(line); if(!*t){c->blanks++; continue;}
        if(starts(t,mark) || starts(t,"#!")) c->comments++; else c->code++;
    }
    free(line);
}
static void count_c(FILE *f, Counts *c){
    char *line=NULL; size_t n=0; bool block=false;
    while(getline(&line,&n,f)!=-1){
        char *p=line; bool code=false, comm=false, str=false, chr=false, esc=false;
        while(*p){
            if(block){ comm=true; if(p[0]=='*'&&p[1]=='/'){block=false; p+=2;} else p++; continue; }
            if(str){ code=true; if(esc) esc=false; else if(*p=='\\') esc=true; else if(*p=='"') str=false; p++; continue; }
            if(chr){ code=true; if(esc) esc=false; else if(*p=='\\') esc=true; else if(*p=='\'') chr=false; p++; continue; }
            if(p[0]=='/'&&p[1]=='/'){ comm=true; break; }
            if(p[0]=='/'&&p[1]=='*'){ comm=true; block=true; p+=2; continue; }
            if(*p=='"'){ str=true; code=true; p++; continue; }
            if(*p=='\''){ chr=true; code=true; p++; continue; }
            if(!isspace((unsigned char)*p)){ code=true; }
            p++;
        }
        char *t=trim(line);
        if(!*t)c->blanks++; else if(code)c->code++; else if(comm)c->comments++; else c->blanks++;
    }
    free(line);
}
static void count_xml(FILE *f, Counts *c){
    char *line=NULL; size_t n=0; bool block=false;
    while(getline(&line,&n,f)!=-1){ char *t=trim(line); if(!*t){c->blanks++; continue;} bool code=false, comm=false;
        char *p=t; while(*p){ if(block){comm=true; char *e=strstr(p,"-->"); if(e){block=false;p=e+3;} else break;} else if(starts(p,"<!--")){comm=true; block=true; p+=4;} else { if(!isspace((unsigned char)*p)) code=true; p++; } }
        if(code)c->code++; else if(comm)c->comments++; else c->blanks++;
    } free(line);
}
static void count_markdown(FILE *f, Counts *c, Counts *child, char **child_lang){
    char *line=NULL; size_t n=0; bool fence=false; char fence_lang[64]="";
    FILE *tmp=NULL;
    while(getline(&line,&n,f)!=-1){
        char *t=trim(line);
        if(starts(t,"```")||starts(t,"~~~")){
            if(!fence){ fence=true; snprintf(fence_lang,sizeof(fence_lang),"%s",trim(t+3)); if(fence_lang[0]) tmp=tmpfile(); c->comments++; }
            else { fence=false; if(tmp){ rewind(tmp); const char *cl=detect_lang(fence_lang[0]=='.'?fence_lang:fence_lang); if(!cl){ for(int i=0; maps[i].ext; i++) if(!strcasecmp(fence_lang,maps[i].ext)){cl=maps[i].lang;break;} } if(cl){ const char *k=lang_kind(cl); if(!strcmp(k,"c")) count_c(tmp,child); else if(!strcmp(k,"xml")||!strcmp(k,"html")) count_xml(tmp,child); else if(!strcmp(k,"text")||!strcmp(k,"md")) count_plain(tmp,child,true); else if(!strcmp(k,"plain")) count_plain(tmp,child,false); else count_hash(tmp,child,k); *child_lang=xstrdup(cl);} fclose(tmp); tmp=NULL;} c->comments++; }
            continue;
        }
        if(fence){ if(tmp) fputs(line,tmp); continue; }
        if(!*t)c->blanks++; else c->comments++;
    }
    if(tmp) fclose(tmp); free(line);
}
static Counts count_file(const char *path, const char *lang, Counts *child, char **child_lang){
    Counts c={0}; FILE *f=fopen(path,"r"); if(!f) return c;
    const char *k=lang_kind(lang);
    if(!strcmp(k,"c")) count_c(f,&c);
    else if(!strcmp(k,"xml")||!strcmp(k,"html")) count_xml(f,&c);
    else if(!strcmp(k,"plain")) count_plain(f,&c,false);
    else if(!strcmp(k,"text")) count_plain(f,&c,true);
    else if(!strcmp(k,"md")) count_markdown(f,&c,child,child_lang);
    else count_hash(f,&c,k);
    fclose(f); return c;
}

static bool type_allowed(const char *lang){ if(!types.n) return true; for(int i=0;i<types.n;i++) if(!strcasecmp(types.v[i],lang)) return true; return false; }
static bool pat_match(const char *pat, const char *path){
    const char *b=base_name(path);
    if(fnmatch(pat,path,FNM_PATHNAME)==0 || fnmatch(pat,b,0)==0) return true;
    if(pat[strlen(pat)-1]=='/'){ char tmp[512]; snprintf(tmp,sizeof(tmp),"%s*",pat); if(fnmatch(tmp,path,0)==0 || fnmatch(tmp,b,0)==0) return true; }
    return false;
}
static bool excluded(const char *path){ for(int i=0;i<excludes.n;i++) if(pat_match(excludes.v[i],path)) return true; if(!opt_no_ignore) for(int i=0;i<ignores.n;i++) if(pat_match(ignores.v[i],path)) return true; return false; }
static void read_ignore_file(const char *dir, const char *name){
    if(opt_no_ignore) return; char p[4096]; snprintf(p,sizeof(p),"%s/%s",dir,name); FILE *f=fopen(p,"r"); if(!f) return;
    char *line=NULL; size_t n=0; while(getline(&line,&n,f)!=-1){ char *t=trim(line); if(*t && *t!='#') strs_add(&ignores,t); } free(line); fclose(f);
}
static void scan_path(const char *path){
    struct stat st; if(lstat(path,&st)!=0){ fprintf(stderr,"Error: '%s' not found.\n",path); return; }
    const char *b=base_name(path); if(!opt_hidden && b[0]=='.' && strcmp(b,".") && strcmp(b,"..")) return; if(excluded(path)) return;
    if(S_ISDIR(st.st_mode)){
        if(!strcmp(b,".git")||!strcmp(b,"target")||!strcmp(b,"node_modules")) return;
        read_ignore_file(path,".gitignore"); read_ignore_file(path,".ignore"); read_ignore_file(path,".tokeignore");
        DIR *d=opendir(path); if(!d) return; struct dirent *e;
        while((e=readdir(d))){ if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")) continue; char p[4096]; snprintf(p,sizeof(p),"%s/%s",path,e->d_name); scan_path(p); }
        closedir(d);
    } else if(S_ISREG(st.st_mode)){
        const char *lang=detect_lang(path); if(!lang) return; if(!type_allowed(lang)) return;
        Counts child={0}; char *cl=NULL; Counts c=count_file(path,lang,&child,&cl); add_report(path,lang,c,cl,child); free(cl);
    }
}
static long total_lines(Counts c){ return c.blanks+c.code+c.comments; }
static long value_counts(Counts c, const char *k, long files){ if(!k||!strcmp(k,"")) return 0; if(!strcmp(k,"files")) return files; if(!strcmp(k,"lines")) return total_lines(c); if(!strcmp(k,"blanks")) return c.blanks; if(!strcmp(k,"code")) return c.code; if(!strcmp(k,"comments")) return c.comments; return 0; }
static int cmp_agg(const void *a,const void *b){
    const Agg *x=a,*y=b; if(sort_key||rsort_key){ const char *k=sort_key?sort_key:rsort_key; Counts cx=x->c, cy=y->c; cx.blanks+=x->child.blanks; cx.code+=x->child.code; cx.comments+=x->child.comments; cy.blanks+=y->child.blanks; cy.code+=y->child.code; cy.comments+=y->child.comments; long vx=value_counts(cx,k,x->files), vy=value_counts(cy,k,y->files); if(vx!=vy) return sort_key ? (vx>vy ? -1:1) : (vx<vy ? -1:1); }
    return strcmp(x->lang,y->lang);
}
static int cmp_rep(const void *a,const void *b){ const Report *x=a,*y=b; int c=strcmp(x->lang,y->lang); if(c) return c; return strcmp(x->name,y->name); }
static void fmt_num(long v, char *buf, size_t sz){
    char raw[64]; snprintf(raw,sizeof(raw),"%ld",v); if(!num_sep){snprintf(buf,sz,"%s",raw);return;} int len=strlen(raw), commas=(len-1)/3, out=len+commas; if((size_t)out+1>sz){snprintf(buf,sz,"%s",raw);return;} buf[out]=0; int r=len-1; for(int w=out-1, cnt=0; w>=0; w--){ if(cnt==3){buf[w]=num_sep; cnt=0;} else {buf[w]=raw[r--]; cnt++;} }
}
static void print_rule(const char *s){ puts(s); }
static void print_row(const char *name,long files,Counts c){
    char l[32],co[32],cm[32],b[32],f[32]; fmt_num(total_lines(c),l,32); fmt_num(c.code,co,32); fmt_num(c.comments,cm,32); fmt_num(c.blanks,b,32); if(files>=0) fmt_num(files,f,32); else strcpy(f,"");
    printf(" %-20s %8s %12s %12s %12s %12s\n",name,f,l,co,cm,b);
}
static void output_table(void){
    qsort(aggs,naggs,sizeof(Agg),cmp_agg); qsort(reports,nreports,sizeof(Report),cmp_rep);
    Counts total={0}; long tf=0; for(int i=0;i<naggs;i++){ Counts c=aggs[i].c; c.blanks+=aggs[i].child.blanks;c.code+=aggs[i].child.code;c.comments+=aggs[i].child.comments; total.blanks+=c.blanks; total.code+=c.code; total.comments+=c.comments; tf+=aggs[i].files; }
    print_rule("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    puts(" Language              Files        Lines         Code     Comments       Blanks");
    print_rule("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    for(int i=0;i<naggs;i++){ print_row(aggs[i].lang,aggs[i].files,aggs[i].c); if(aggs[i].child_lang&&!opt_compact){ char nm[128]; snprintf(nm,sizeof(nm),"|- %s",aggs[i].child_lang); print_row(nm,aggs[i].files,aggs[i].child); Counts tc=aggs[i].c; tc.blanks+=aggs[i].child.blanks; tc.code+=aggs[i].child.code; tc.comments+=aggs[i].child.comments; print_row("(Total)",-1,tc); } if(opt_files){ print_rule("─────────────────────────────────────────────────────────────────────────────────"); for(int r=0;r<nreports;r++) if(!strcmp(reports[r].lang,aggs[i].lang)) print_row(reports[r].name,-1,reports[r].c); } }
    print_rule("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"); print_row("Total",tf,total); print_rule("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
}
static void json_str(const char *s){ putchar('"'); for(;*s;s++){ if(*s=='"'||*s=='\\') printf("\\%c",*s); else if(*s=='\n') printf("\\n"); else putchar(*s);} putchar('"'); }
static void json_counts(Counts c){ printf("\"blanks\":%ld,\"code\":%ld,\"comments\":%ld,\"blobs\":{}",c.blanks,c.code,c.comments); }
static void json_lang_counts(Counts c){ printf("\"blanks\":%ld,\"code\":%ld,\"comments\":%ld",c.blanks,c.code,c.comments); }
static void output_json(void){
    qsort(aggs,naggs,sizeof(Agg),cmp_agg); bool first=true; putchar('{');
    Counts total={0}; long tf=0; (void)tf;
    for(int i=0;i<naggs;i++){ if(!first) putchar(','); first=false; json_str(aggs[i].lang); printf(":{"); json_lang_counts(aggs[i].c); printf(",\"reports\":["); bool rf=true; for(int r=0;r<nreports;r++) if(!strcmp(reports[r].lang,aggs[i].lang)){ if(!rf)putchar(','); rf=false; printf("{\"stats\":{"); json_counts(reports[r].c); printf("},\"name\":"); json_str(reports[r].name); printf("}"); } printf("],\"children\":{},\"inaccurate\":false}");
        Counts c=aggs[i].c; c.blanks+=aggs[i].child.blanks;c.code+=aggs[i].child.code;c.comments+=aggs[i].child.comments; total.blanks+=c.blanks; total.code+=c.code; total.comments+=c.comments; }
    printf(",\"Total\":{"); json_lang_counts(total); printf(",\"reports\":[],\"children\":{},\"inaccurate\":false}}");
}
static void output_stream(void){
    qsort(reports,nreports,sizeof(Report),cmp_rep);
    if(!strcmp(opt_streaming,"json")) for(int r=0;r<nreports;r++){ printf("{\"language\":"); json_str(reports[r].lang); printf(",\"stats\":{\"name\":"); json_str(reports[r].name); printf(",\"stats\":{"); json_counts(reports[r].c); printf("}}}\n"); }
    else { puts("# language                                        path                                          lines         code       comments      blanks   "); puts("########## ################################################################################ ############ ############ ############ ############"); for(int r=0;r<nreports;r++) printf("%10s %-80s %12ld %12ld %12ld %12ld\n",reports[r].lang,reports[r].name,total_lines(reports[r].c),reports[r].c.code,reports[r].c.comments,reports[r].c.blanks); }
}
static void print_help(void){
    puts("Count your code, quickly.\nSupport this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky\n");
    puts("Usage: executable [OPTIONS] [input]...\n\nArguments:\n  [input]...  The path(s) to the file or directory to be counted. (default current directory)\n\nOptions:\n  -c, --columns <columns>              Sets a strict column width of the output, only available for terminal output.\n  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.\n  -f, --files                          Will print out statistics on individual files.\n  -i, --input <file_input>             Gives statistics from a previous tokei run.\n      --hidden                         Count hidden files.\n  -l, --languages                      Prints out supported languages and their extensions.\n      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.).\n  -o, --output <output>                Outputs Tokei in a specific format.\n      --streaming <streaming>          [possible values: simple, json]\n  -s, --sort <sort>                    Sort languages based on column [possible values: files, lines, blanks, code, comments]\n  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values: files, lines, blanks, code, comments]\n  -t, --types <types>                  Filters output by language type, separated by a comma.\n  -C, --compact                        Do not print statistics about embedded languages.\n  -n, --num-format <num_format_style>  [possible values: commas, dots, plain, underscores]\n  -v, --verbose...                     Set log output level\n  -h, --help                           Print help\n  -V, --version                        Print version");
}
static void print_languages(void){
    puts("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    puts("┃ Language                              Extensions                     ┃");
    puts("┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃");
    const char *last=""; for(int i=0; maps[i].ext; i++){ if(strcmp(last,maps[i].lang)){ printf("┃ %-37s %-30s ┃\n",maps[i].lang,maps[i].ext); last=maps[i].lang; } }
    puts("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
}
static void split_types(char *s){ char *tok=strtok(s,","); while(tok){ strs_add(&types,trim(tok)); tok=strtok(NULL,","); } }
static bool valid_sort(const char *s){ return !strcmp(s,"files")||!strcmp(s,"lines")||!strcmp(s,"blanks")||!strcmp(s,"code")||!strcmp(s,"comments"); }
int main(int argc, char **argv){
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")||!strcmp(a,"-h")){print_help(); return 0;}
        else if(!strcmp(a,"--version")||!strcmp(a,"-V")){puts("tokei 14.0.0 compiled with serialization support: json"); return 0;}
        else if(!strcmp(a,"--languages")||!strcmp(a,"-l")){print_languages(); return 0;}
        else if(!strcmp(a,"--files")||!strcmp(a,"-f")) opt_files=1;
        else if(!strcmp(a,"--hidden")) opt_hidden=1;
        else if(!strcmp(a,"--no-ignore")||!strcmp(a,"--no-ignore-dot")||!strcmp(a,"--no-ignore-vcs")||!strcmp(a,"--no-ignore-parent")) opt_no_ignore=1;
        else if(!strcmp(a,"--compact")||!strcmp(a,"-C")) opt_compact=1;
        else if(starts(a,"-v")) {}
        else if((!strcmp(a,"--exclude")||!strcmp(a,"-e")) && i+1<argc) strs_add(&excludes,argv[++i]);
        else if((!strcmp(a,"--output")||!strcmp(a,"-o")) && i+1<argc) opt_output=argv[++i];
        else if(!strcmp(a,"--streaming") && i+1<argc) opt_streaming=argv[++i];
        else if((!strcmp(a,"--sort")||!strcmp(a,"-s")) && i+1<argc){ sort_key=argv[++i]; if(!valid_sort(sort_key)){fprintf(stderr,"error: invalid value '%s' for '--sort <sort>'\n",sort_key); return 1;}}
        else if((!strcmp(a,"--rsort")||!strcmp(a,"-r")) && i+1<argc){ rsort_key=argv[++i]; if(!valid_sort(rsort_key)){fprintf(stderr,"error: invalid value '%s' for '--rsort <rsort>'\n",rsort_key); return 1;}}
        else if((!strcmp(a,"--types")||!strcmp(a,"-t")||!strcmp(a,"--type")) && i+1<argc){ char *tmp=xstrdup(argv[++i]); split_types(tmp); free(tmp); }
        else if((!strcmp(a,"--columns")||!strcmp(a,"-c")||!strcmp(a,"--input")||!strcmp(a,"-i")) && i+1<argc) { i++; }
        else if((!strcmp(a,"--num-format")||!strcmp(a,"-n")) && i+1<argc){ char *v=argv[++i]; if(!strcmp(v,"commas")) num_sep=','; else if(!strcmp(v,"dots")) num_sep='.'; else if(!strcmp(v,"underscores")) num_sep='_'; else num_sep=0; }
        else if(a[0]=='-'){ fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [input]...\n\nFor more information, try '--help'.\n",a); return 1; }
        else strs_add(&inputs,a);
    }
    if(opt_output && strcmp(opt_output,"json")){ fprintf(stderr,"error: invalid value '%s' for '--output <output>': This version of tokei was compiled without any '%s' serialization support, to enable serialization, reinstall tokei with the features flag.\n",opt_output,opt_output); return 1; }
    if(inputs.n==0) strs_add(&inputs,".");
    for(int i=0;i<inputs.n;i++) scan_path(inputs.v[i]);
    if(opt_streaming) output_stream(); else if(opt_output && !strcmp(opt_output,"json")) output_json(); else output_table();
    return 0;
}
