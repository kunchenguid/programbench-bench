#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    char *name;
    double value;
    int parent;
    int depth;
    int first_child;
    int next_sibling;
} Node;

typedef struct {
    Node *items;
    size_t len;
    size_t cap;
} Nodes;

typedef struct {
    char *text;
    size_t len;
    size_t cap;
} Buffer;

static struct termios saved_termios;
static bool termios_saved = false;

static void die_oom(void) {
    fputs("out of memory\n", stderr);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) die_oom();
    return p;
}

static void buf_append(Buffer *b, const char *s, size_t n) {
    if (n == 0) return;
    if (b->len + n + 1 > b->cap) {
        size_t nc = b->cap ? b->cap * 2 : 4096;
        while (nc < b->len + n + 1) nc *= 2;
        char *p = realloc(b->text, nc);
        if (!p) die_oom();
        b->text = p;
        b->cap = nc;
    }
    memcpy(b->text + b->len, s, n);
    b->len += n;
    b->text[b->len] = 0;
}

static void nodes_push(Nodes *ns, const char *name, int parent, int depth) {
    if (ns->len == ns->cap) {
        size_t nc = ns->cap ? ns->cap * 2 : 64;
        Node *p = realloc(ns->items, nc * sizeof(Node));
        if (!p) die_oom();
        ns->items = p;
        ns->cap = nc;
    }
    ns->items[ns->len].name = xstrdup(name);
    ns->items[ns->len].value = 0.0;
    ns->items[ns->len].parent = parent;
    ns->items[ns->len].depth = depth;
    ns->items[ns->len].first_child = -1;
    ns->items[ns->len].next_sibling = -1;
    if (parent >= 0) {
        ns->items[ns->len].next_sibling = ns->items[parent].first_child;
        ns->items[parent].first_child = (int)ns->len;
    }
    ns->len++;
}

static int find_child(Nodes *ns, int parent, const char *name) {
    for (int i = ns->items[parent].first_child; i >= 0; i = ns->items[i].next_sibling) {
        if (strcmp(ns->items[i].name, name) == 0) return i;
    }
    return -1;
}

static int ensure_child(Nodes *ns, int parent, const char *name, int depth) {
    int found = find_child(ns, parent, name);
    if (found >= 0) return found;
    nodes_push(ns, name, parent, depth);
    return (int)ns->len - 1;
}

static void print_help(void) {
    puts("Usage: executable [OPTIONS] [FILENAME]\n");
    puts("Arguments:");
    puts("  [FILENAME]  Profile data filename\n");
    puts("Options:");
    puts("      --sorted   Whether to sort the stacks by time spent");
    puts("      --echo     Print data to stdout on exit. Useful when piping to other tools");
    puts("      --debug    Show debug info");
    puts("  -h, --help     Print help");
    puts("  -V, --version  Print version");
}

static bool is_known_option(const char *s) {
    return strcmp(s, "--sorted") == 0 || strcmp(s, "--echo") == 0 ||
           strcmp(s, "--debug") == 0 || strcmp(s, "-h") == 0 ||
           strcmp(s, "--help") == 0 || strcmp(s, "-V") == 0 ||
           strcmp(s, "--version") == 0;
}

static void unexpected_arg(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    if (strncmp(arg, "--", 2) == 0) {
        fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    }
    fprintf(stderr, "Usage: executable [OPTIONS] [FILENAME]\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

static Buffer read_all(FILE *fp) {
    Buffer b = {0};
    char tmp[8192];
    while (1) {
        size_t n = fread(tmp, 1, sizeof(tmp), fp);
        if (n) buf_append(&b, tmp, n);
        if (n < sizeof(tmp)) {
            if (ferror(fp)) {
                clearerr(fp);
            }
            break;
        }
    }
    return b;
}

static Buffer read_file_or_panic(const char *path) {
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        fprintf(stderr, "\nthread 'main' (%ld) panicked at src/main.rs:44:47:\n", (long)getpid());
        fprintf(stderr, "Could not read file: Os { code: %d, kind: %s, message: \"%s\" }\n",
                errno, errno == ENOENT ? "NotFound" : "Other", strerror(errno));
        fputs("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n", stderr);
        exit(101);
    }
    Buffer b = read_all(fp);
    fclose(fp);
    return b;
}

static char *trim(char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static void parse_folded(Nodes *ns, const char *data) {
    nodes_push(ns, "all", -1, 0);
    char *copy = xstrdup(data ? data : "");
    for (char *line = strtok(copy, "\n"); line; line = strtok(NULL, "\n")) {
        if (*line && line[strlen(line) - 1] == '\r') line[strlen(line) - 1] = 0;
        char *t = trim(line);
        if (*t == 0) continue;
        char *last_space = NULL;
        for (char *p = t; *p; p++) if (isspace((unsigned char)*p)) last_space = p;
        double val = 1.0;
        if (last_space) {
            char *num = trim(last_space + 1);
            *last_space = 0;
            char *end = NULL;
            double parsed = strtod(num, &end);
            if (end && *trim(end) == 0) val = parsed;
        }
        int parent = 0;
        int depth = 1;
        char *save = NULL;
        for (char *part = strtok_r(t, ";", &save); part; part = strtok_r(NULL, ";", &save)) {
            part = trim(part);
            if (*part == 0) continue;
            parent = ensure_child(ns, parent, part, depth++);
            ns->items[parent].value += val;
        }
        ns->items[0].value += val;
    }
    free(copy);
}

static int cmp_child_value(const void *a, const void *b, void *arg) {
    Nodes *ns = arg;
    int ia = *(const int *)a, ib = *(const int *)b;
    if (ns->items[ia].value < ns->items[ib].value) return 1;
    if (ns->items[ia].value > ns->items[ib].value) return -1;
    return strcmp(ns->items[ia].name, ns->items[ib].name);
}

static int collect_by_depth(Nodes *ns, int depth, int *out, int max, bool sorted) {
    int n = 0;
    for (size_t i = 0; i < ns->len && n < max; i++) {
        if (ns->items[i].depth == depth) out[n++] = (int)i;
    }
    if (sorted) qsort_r(out, (size_t)n, sizeof(int), cmp_child_value, ns);
    return n;
}

static void restore_terminal(void) {
    if (termios_saved) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &saved_termios);
        termios_saved = false;
    }
    fputs("\033[?1049l\033[?1006l\033[?1015l\033[?1003l\033[?1002l\033[?1000l\033[?25h", stdout);
    fflush(stdout);
}

static void on_signal(int sig) {
    (void)sig;
    restore_terminal();
    _exit(0);
}

static void enter_raw(void) {
    if (tcgetattr(STDIN_FILENO, &saved_termios) != 0) {
        fputs("Error: Os { code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }\n", stderr);
        exit(1);
    }
    termios_saved = true;
    struct termios raw = saved_termios;
    raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
    raw.c_iflag &= (tcflag_t)~(IXON | ICRNL);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    atexit(restore_terminal);
    fputs("\033[?1049h\033[?25l\033[2J", stdout);
}

static void repeat_line(int cols) {
    for (int i = 0; i < cols; i++) fputs("─", stdout);
}

static int term_cols(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0) return ws.ws_col;
    return 80;
}

static int term_rows(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 0) return ws.ws_row;
    return 24;
}

static void print_cell(const char *name, int width, int fg, int bg) {
    if (width <= 0) return;
    printf("\033[38;2;%d;%d;%d;48;2;%d;%d;%dm", fg, fg, fg, bg, bg > 80 ? bg - 20 : bg, bg > 40 ? bg - 35 : bg);
    int n = (int)strlen(name);
    if (n > width) n = width;
    fwrite(name, 1, (size_t)n, stdout);
    for (int i = n; i < width; i++) putchar(' ');
    fputs("\033[39m\033[49m", stdout);
}

static void draw_ui(Nodes *ns, const char *title, bool sorted, bool debug) {
    int cols = term_cols();
    int rows = term_rows();
    if (cols < 20) cols = 80;
    if (rows < 8) rows = 24;
    printf("\033[2J\033[1;1H");
    repeat_line(cols);
    printf("\033[2;2H\033[1m\033[38;5;3;49m[Flamegraph]\033[22m\033[39m | \033[1mTop\033[22m");
    if (title) printf("\033[2;%dH%s", cols / 2 - (int)strlen(title) / 2, title);
    printf("\033[2;%dHflamelens v0.3.1", cols > 18 ? cols - 16 : 1);
    printf("\033[3;1H");
    repeat_line(cols);

    int max_depth = rows - 8;
    if (max_depth > 40) max_depth = 40;
    int ids[512];
    for (int d = 0; d <= max_depth; d++) {
        int row = 4 + d;
        int count = collect_by_depth(ns, d, ids, 512, sorted);
        if (count == 0) continue;
        printf("\033[%d;1H", row);
        double total = ns->items[0].value > 0 ? ns->items[0].value : 1.0;
        int used = 0;
        for (int i = 0; i < count && used < cols; i++) {
            Node *node = &ns->items[ids[i]];
            int w = (int)((node->value / total) * cols + 0.5);
            if (d == 0) w = cols;
            if (w < 3) w = 3;
            if (w > cols - used) w = cols - used;
            int bg = 245 - ((ids[i] * 37) % 180);
            if (bg < 45) bg += 80;
            print_cell(node->name, w, bg > 150 ? 10 : 225, bg);
            used += w;
        }
    }
    int sel = rows - 3;
    if (sel < 6) sel = 6;
    printf("\033[%d;1H\033[1m\033[38;5;3;49mSelected \033[22m\033[39m", sel);
    repeat_line(cols > 9 ? cols - 9 : 1);
    printf("\033[%d;1Hall [%.0f samples, 100.00%% of all]", sel + 1, ns->items[0].value);
    if (debug) {
        printf("  nodes=%zu sorted=%s", ns->len, sorted ? "true" : "false");
    }
    printf("\033[%d;1H", rows - 1);
    repeat_line(cols);
    printf("\033[%d;2H[\033[1m\033[38;5;3;49mhjkl\033[22m\033[39m: move cursor] [\033[1m\033[38;5;3;49mf/b\033[22m\033[39m: scroll] [\033[1m\033[38;5;3;49menter/esc\033[22m\033[39m: zoom] [\033[1m\033[38;5;3;49m/\033[22m\033[39m: search] [\033[1m\033[38;5;3;49m#\033[22m\033[39m: search like]", rows);
    fputs("\033[0m\033[?25l", stdout);
    fflush(stdout);
}

static void event_loop(Nodes *ns, const char *title, bool sorted, bool debug) {
    enter_raw();
    draw_ui(ns, title, sorted, debug);
    for (;;) {
        unsigned char c = 0;
        ssize_t n = read(STDIN_FILENO, &c, 1);
        if (n == 1) {
            if (c == 'q' || c == 3) break;
            if (c == 'r' || c == 'g' || c == 'G' || c == '\n' || c == 27) draw_ui(ns, title, sorted, debug);
        } else {
            usleep(20000);
        }
    }
}

int main(int argc, char **argv) {
    bool sorted = false, echo = false, debug = false;
    const char *filename = NULL;
    bool positional_only = false;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!positional_only && strcmp(a, "--") == 0) {
            positional_only = true;
            continue;
        }
        if (!positional_only && (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0)) {
            print_help();
            return 0;
        }
        if (!positional_only && (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0)) {
            puts("flamelens 0.3.1");
            return 0;
        }
        if (!positional_only && strcmp(a, "--sorted") == 0) {
            sorted = true;
            continue;
        }
        if (!positional_only && strcmp(a, "--echo") == 0) {
            echo = true;
            continue;
        }
        if (!positional_only && strcmp(a, "--debug") == 0) {
            debug = true;
            continue;
        }
        if (!positional_only && a[0] == '-' && !is_known_option(a)) unexpected_arg(a);
        if (filename) unexpected_arg(a);
        filename = a;
    }

    Buffer input = filename ? read_file_or_panic(filename) : read_all(stdin);
    if (echo) {
        if (input.len) fwrite(input.text, 1, input.len, stdout);
        putchar('\n');
        fflush(stdout);
    }
    if (!isatty(STDIN_FILENO)) {
        fputs("Error: Os { code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }\n", stderr);
        return 1;
    }
    Nodes ns = {0};
    parse_folded(&ns, input.text ? input.text : "");
    event_loop(&ns, filename ? filename : "stdin", sorted, debug);
    return 0;
}
