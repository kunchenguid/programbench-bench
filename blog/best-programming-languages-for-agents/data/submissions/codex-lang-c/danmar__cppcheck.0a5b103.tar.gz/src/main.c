#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct {
    char file[PATH_MAX];
    int line;
    int col;
    char severity[24];
    char id[64];
    char msg[512];
} Diagnostic;

typedef struct {
    Diagnostic *v;
    size_t n, cap;
} Diagnostics;

typedef struct {
    char name[96];
    int size;
    int line;
} ArrayInfo;

typedef struct {
    char name[96];
    int line;
    bool initialized;
    bool used;
} VarInfo;

typedef struct {
    bool quiet;
    bool xml;
    bool verbose;
    bool enable_all;
    bool enable_style;
    bool enable_warning;
    bool enable_missing_include;
    bool check_config;
    bool preprocess_only;
    int error_exitcode;
    const char *output_file;
    const char *template_name;
} Options;

static void add_diag(Diagnostics *ds, const char *file, int line, int col,
                     const char *sev, const char *id, const char *fmt, ...) {
    if (ds->n == ds->cap) {
        ds->cap = ds->cap ? ds->cap * 2 : 16;
        ds->v = realloc(ds->v, ds->cap * sizeof(*ds->v));
        if (!ds->v) exit(2);
    }
    Diagnostic *d = &ds->v[ds->n++];
    snprintf(d->file, sizeof(d->file), "%s", file);
    d->line = line;
    d->col = col < 1 ? 1 : col;
    snprintf(d->severity, sizeof(d->severity), "%s", sev);
    snprintf(d->id, sizeof(d->id), "%s", id);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(d->msg, sizeof(d->msg), fmt, ap);
    va_end(ap);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool has_word(const char *s, const char *w) {
    size_t n = strlen(w);
    const char *p = s;
    while ((p = strstr(p, w))) {
        bool a = (p == s) || (!isalnum((unsigned char)p[-1]) && p[-1] != '_');
        bool b = !isalnum((unsigned char)p[n]) && p[n] != '_';
        if (a && b) return true;
        p += n;
    }
    return false;
}

static int column_of(const char *line, const char *needle) {
    const char *p = strstr(line, needle);
    return p ? (int)(p - line + 1) : 1;
}

static bool source_ext(const char *p) {
    const char *e = strrchr(p, '.');
    if (!e) return false;
    return !strcmp(e, ".c") || !strcmp(e, ".cc") || !strcmp(e, ".cpp") ||
           !strcmp(e, ".cxx") || !strcmp(e, ".c++") || !strcmp(e, ".h") ||
           !strcmp(e, ".hpp") || !strcmp(e, ".ipp") || !strcmp(e, ".ixx") ||
           !strcmp(e, ".tpp") || !strcmp(e, ".txx");
}

typedef struct { char **v; size_t n, cap; } StrList;

static void push_str(StrList *l, const char *s) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->v = realloc(l->v, l->cap * sizeof(char *));
        if (!l->v) exit(2);
    }
    l->v[l->n++] = strdup(s);
}

static void collect_path(StrList *files, const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) {
        push_str(files, path);
        return;
    }
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) return;
        struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
            char buf[PATH_MAX];
            snprintf(buf, sizeof(buf), "%s/%s", path, de->d_name);
            collect_path(files, buf);
        }
        closedir(d);
    } else if (source_ext(path)) {
        push_str(files, path);
    }
}

static void xml_escape(FILE *f, const char *s) {
    for (; *s; s++) {
        if (*s == '&') fputs("&amp;", f);
        else if (*s == '<') fputs("&lt;", f);
        else if (*s == '>') fputs("&gt;", f);
        else if (*s == '"') fputs("&quot;", f);
        else if (*s == '\'') fputs("&apos;", f);
        else fputc(*s, f);
    }
}

static bool is_decl_line(const char *s, char *type, size_t tsz, char *name, size_t nsz, int *arrsz) {
    char tmp[512];
    snprintf(tmp, sizeof(tmp), "%s", s);
    char *p = trim(tmp);
    if (*p == '#') return false;
    const char *types[] = {"char","short","int","long","float","double","bool","unsigned","signed","size_t",NULL};
    bool ok = false;
    for (int i = 0; types[i]; i++) {
        size_t n = strlen(types[i]);
        if (!strncmp(p, types[i], n) && isspace((unsigned char)p[n])) { ok = true; break; }
    }
    if (!ok) return false;
    char *semi = strchr(p, ';');
    if (!semi) return false;
    *semi = 0;
    char *eq = strchr(p, '=');
    char *br = strchr(p, '[');
    if (br && (!eq || br < eq)) {
        int sz = atoi(br + 1);
        *br = 0;
        char *q = br - 1;
        while (q > p && isspace((unsigned char)*q)) *q-- = 0;
        while (q > p && (isalnum((unsigned char)*q) || *q == '_')) q--;
        q++;
        snprintf(name, nsz, "%s", q);
        snprintf(type, tsz, "array");
        *arrsz = sz;
        return name[0] != 0 && sz > 0;
    }
    if (eq) *eq = 0;
    char *comma = strchr(p, ',');
    if (comma) *comma = 0;
    char *q = p + strlen(p) - 1;
    while (q > p && isspace((unsigned char)*q)) *q-- = 0;
    while (q > p && (isalnum((unsigned char)*q) || *q == '_' || *q == '*')) q--;
    q++;
    while (*q == '*') q++;
    if (!isalpha((unsigned char)*q) && *q != '_') return false;
    snprintf(name, nsz, "%s", q);
    char *sp = strchr(name, ' ');
    if (sp) *sp = 0;
    snprintf(type, tsz, "var");
    *arrsz = 0;
    return name[0] != 0;
}

static void strip_comments(char *line, bool *block) {
    char out[4096];
    size_t j = 0;
    for (size_t i = 0; line[i] && j + 1 < sizeof(out); i++) {
        if (*block) {
            if (line[i] == '*' && line[i+1] == '/') { *block = false; i++; }
            out[j++] = ' ';
        } else if (line[i] == '/' && line[i+1] == '*') {
            *block = true; out[j++] = ' '; i++;
        } else if (line[i] == '/' && line[i+1] == '/') {
            break;
        } else {
            out[j++] = line[i];
        }
    }
    out[j] = 0;
    strcpy(line, out);
}

static void analyze_file(const Options *opt, const char *file, Diagnostics *ds) {
    FILE *fp = fopen(file, "r");
    if (!fp) {
        add_diag(ds, file, 0, 1, "error", "file", "Could not open file: %s", strerror(errno));
        return;
    }
    if (!opt->quiet && !opt->xml && !opt->preprocess_only)
        printf("Checking %s...\n", file);
    ArrayInfo arrays[256]; int narr = 0;
    VarInfo vars[512]; int nvar = 0;
    char *line = NULL; size_t cap = 0; ssize_t len;
    int lineno = 0;
    bool block = false;
    while ((len = getline(&line, &cap, fp)) >= 0) {
        lineno++;
        if (opt->preprocess_only) {
            if (line[0] != '#') fputs(line, stdout);
            continue;
        }
        char raw[4096];
        snprintf(raw, sizeof(raw), "%s", line);
        strip_comments(raw, &block);
        char *s = trim(raw);
        if (!*s) continue;
        if (opt->enable_missing_include && !strncmp(s, "#include", 8) && strchr(s, '"')) {
            char inc[PATH_MAX] = {0};
            char *a = strchr(s, '"'), *b = a ? strchr(a + 1, '"') : NULL;
            if (a && b && b > a + 1) {
                snprintf(inc, (size_t)(b - a), "%s", a + 1);
                char dir[PATH_MAX], full[PATH_MAX];
                snprintf(dir, sizeof(dir), "%s", file);
                char *slash = strrchr(dir, '/');
                if (slash) *slash = 0; else strcpy(dir, ".");
                snprintf(full, sizeof(full), "%s/%s", dir, inc);
                struct stat st;
                if (stat(full, &st) != 0)
                    add_diag(ds, file, lineno, column_of(line, "#include"), "information", "missingInclude", "Include file: \"%s\" not found.", inc);
            }
        }
        char type[32], name[96]; int arrsz;
        bool declared_array_this_line = false;
        if (is_decl_line(s, type, sizeof(type), name, sizeof(name), &arrsz)) {
            if (!strcmp(type, "array") && narr < 256) {
                snprintf(arrays[narr].name, sizeof(arrays[narr].name), "%s", name);
                arrays[narr].size = arrsz; arrays[narr].line = lineno; narr++;
                declared_array_this_line = true;
                char *semi = strchr(s, ';');
                if (semi) {
                    char pat[160];
                    snprintf(pat, sizeof(pat), "%s[", name);
                    char *p = strstr(semi + 1, pat);
                    while (p) {
                        char *q = p + strlen(pat);
                        if (isdigit((unsigned char)*q)) {
                            int idx = atoi(q);
                            if (idx >= arrsz || idx < 0)
                                add_diag(ds, file, lineno, (int)(p - s + 1), "error", "arrayIndexOutOfBounds",
                                         "Array '%s[%d]' accessed at index %d, which is out of bounds.",
                                         name, arrsz, idx);
                        }
                        p = strstr(p + 1, pat);
                    }
                }
            } else if (nvar < 512) {
                snprintf(vars[nvar].name, sizeof(vars[nvar].name), "%s", name);
                vars[nvar].line = lineno;
                vars[nvar].initialized = strchr(s, '=') != NULL;
                vars[nvar].used = false;
                char *semi = strchr(s, ';');
                if (!vars[nvar].initialized && semi && has_word(semi + 1, vars[nvar].name)) {
                    add_diag(ds, file, lineno, column_of(line, vars[nvar].name), "error", "uninitvar",
                             "Uninitialized variable: %s", vars[nvar].name);
                    vars[nvar].used = true;
                }
                nvar++;
            }
        }
        for (int i = 0; !declared_array_this_line && i < narr; i++) {
            char pat[160];
            snprintf(pat, sizeof(pat), "%s[", arrays[i].name);
            char *p = strstr(s, pat);
            while (p) {
                char *q = p + strlen(pat);
                if (isdigit((unsigned char)*q)) {
                    int idx = atoi(q);
                    if (idx >= arrays[i].size || idx < 0)
                        add_diag(ds, file, lineno, (int)(p - s + 1), "error", "arrayIndexOutOfBounds",
                                 "Array '%s[%d]' accessed at index %d, which is out of bounds.",
                                 arrays[i].name, arrays[i].size, idx);
                }
                p = strstr(p + 1, pat);
            }
        }
        if (strstr(s, "/ 0") || strstr(s, "/0") || strstr(s, "% 0") || strstr(s, "%0"))
            add_diag(ds, file, lineno, column_of(line, "/"), "error", "zerodiv", "Division by zero.");
        if (strstr(s, "free(")) {
            for (int i = 0; i < nvar; i++) {
                char pat[128]; snprintf(pat, sizeof(pat), "free(%s", vars[i].name);
                if (strstr(s, pat))
                    add_diag(ds, file, lineno, column_of(line, "free"), "error", "autovarInvalidDeallocation", "Deallocation of an auto-variable results in undefined behaviour.");
            }
        }
        if (strstr(s, "= NULL") || strstr(s, "= 0")) {
            char lhs[96] = {0};
            if (sscanf(s, "%95[^=]", lhs) == 1) {
                char *t = trim(lhs);
                char *star = strrchr(t, '*');
                if (star) t = trim(star + 1);
                for (int i = 0; i < nvar; i++) if (!strcmp(vars[i].name, t)) vars[i].initialized = true;
            }
        }
        if (strstr(s, "strcpy(") || strstr(s, "strcat(") || strstr(s, "sprintf("))
            add_diag(ds, file, lineno, column_of(line, strstr(s, "strcpy(") ? "strcpy" : strstr(s, "strcat(") ? "strcat" : "sprintf"),
                     "warning", "unsafeFunction", "Obsolete function used. It is recommended to use a safer replacement.");
        if (strstr(s, "malloc(") && !strchr(s, '='))
            add_diag(ds, file, lineno, column_of(line, "malloc"), "error", "memleak", "Memory leak: allocated memory is not stored.");
        if (strstr(s, "return &")) {
            add_diag(ds, file, lineno, column_of(line, "return"), "error", "returnDanglingLifetime", "Returning object that will be invalid when returning.");
        }
        for (int i = 0; i < nvar; i++) {
            char deref[128]; snprintf(deref, sizeof(deref), "*%s", vars[i].name);
            if (strstr(s, deref) && (strstr(s, "= 0") || strstr(s, "= NULL") || strstr(s, "NULL;")))
                add_diag(ds, file, lineno, column_of(line, deref), "error", "nullPointer", "Null pointer dereference: %s", vars[i].name);
            if (!vars[i].initialized && lineno > vars[i].line && has_word(s, vars[i].name) && !strchr(s, '='))
                add_diag(ds, file, lineno, column_of(line, vars[i].name), "error", "uninitvar", "Uninitialized variable: %s", vars[i].name);
            if (lineno > vars[i].line && has_word(s, vars[i].name)) vars[i].used = true;
            if (strstr(s, "=") && has_word(s, vars[i].name)) vars[i].initialized = true;
        }
    }
    if ((opt->enable_all || opt->enable_style) && !opt->preprocess_only) {
        for (int i = 0; i < nvar; i++) {
            if (!vars[i].used && vars[i].line > 0)
                add_diag(ds, file, vars[i].line, 1, "style", "unusedVariable", "Variable '%s' is assigned a value that is never used.", vars[i].name);
        }
    }
    free(line);
    fclose(fp);
}

static void print_help(void) {
    puts("Cppcheck - A tool for static C/C++ code analysis\n");
    puts("Syntax:");
    puts("    cppcheck [OPTIONS] [files or paths]\n");
    puts("If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,");
    puts("*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.\n");
    puts("Options:");
    puts("    --enable=<severity>  Enable additional checks: warning, style, performance, portability, information, unusedFunction, missingInclude, all");
    puts("    --disable=<severity> Disable checks with the given severity.");
    puts("    --error-exitcode=<n> If errors are found, integer [n] is returned.");
    puts("    --errorlist          Print a list of all the error messages in XML format.");
    puts("    --file-list=<file>   Specify the files to check in a text file.");
    puts("    -h, --help           Print this help.");
    puts("    -I <dir>             Give path to search for include files.");
    puts("    --inline-suppr       Enable inline suppressions.");
    puts("    -j <jobs>            Start <jobs> threads to do the checking simultaneously.");
    puts("    --language=<language>, -x <language>  Forces cppcheck to check all files as c or c++.");
    puts("    --output-file=<file> Write results to file, rather than standard error.");
    puts("    -q, --quiet          Do not show progress reports.");
    puts("    --std=<id>           Set standard.");
    puts("    --template='<text>'  Format the error messages.");
    puts("    -v, --verbose        Output more detailed error information.");
    puts("    --version            Print out version number.");
    puts("    --xml                Write results in xml format to error stream.");
}

static void print_errorlist(void) {
    puts("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    puts("<results version=\"2\">");
    puts("    <cppcheck version=\"2.19 dev\"/>");
    puts("    <errors>");
    puts("        <error id=\"arrayIndexOutOfBounds\" severity=\"error\" msg=\"Array accessed out of bounds.\" verbose=\"Array accessed out of bounds.\" cwe=\"788\"/>");
    puts("        <error id=\"zerodiv\" severity=\"error\" msg=\"Division by zero.\" verbose=\"Division by zero.\" cwe=\"369\"/>");
    puts("        <error id=\"nullPointer\" severity=\"error\" msg=\"Null pointer dereference.\" verbose=\"Null pointer dereference.\" cwe=\"476\"/>");
    puts("        <error id=\"uninitvar\" severity=\"error\" msg=\"Uninitialized variable.\" verbose=\"Uninitialized variable.\" cwe=\"457\"/>");
    puts("        <error id=\"memleak\" severity=\"error\" msg=\"Memory leak.\" verbose=\"Memory leak.\" cwe=\"401\"/>");
    puts("        <error id=\"unusedVariable\" severity=\"style\" msg=\"Variable is assigned a value that is never used.\" verbose=\"Variable is assigned a value that is never used.\" cwe=\"563\"/>");
    puts("        <error id=\"missingInclude\" severity=\"information\" msg=\"Include file not found.\" verbose=\"Include file not found.\"/>");
    puts("    </errors>");
    puts("</results>");
}

static void output_diags(FILE *f, const Options *opt, const Diagnostics *ds) {
    if (opt->xml) {
        fputs("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<results version=\"2\">\n    <cppcheck version=\"2.19 dev\"/>\n    <errors>\n", f);
        for (size_t i = 0; i < ds->n; i++) {
            const Diagnostic *d = &ds->v[i];
            fputs("        <error id=\"", f); xml_escape(f, d->id);
            fputs("\" severity=\"", f); xml_escape(f, d->severity);
            fputs("\" msg=\"", f); xml_escape(f, d->msg);
            fputs("\" verbose=\"", f); xml_escape(f, d->msg);
            fprintf(f, "\">\n            <location file=\"");
            xml_escape(f, d->file);
            fprintf(f, "\" line=\"%d\" column=\"%d\"/>\n        </error>\n", d->line, d->col);
        }
        fputs("    </errors>\n</results>\n", f);
        return;
    }
    for (size_t i = 0; i < ds->n; i++) {
        const Diagnostic *d = &ds->v[i];
        if (opt->template_name && strstr(opt->template_name, "cppcheck1"))
            fprintf(f, "[%s:%d]: (%s) %s\n", d->file, d->line, d->severity, d->msg);
        else
            fprintf(f, "%s:%d:%d: %s: %s [%s]\n", d->file, d->line, d->col, d->severity, d->msg, d->id);
        if (opt->verbose)
            fprintf(f, "%s:%d:%d: note: Cppcheck cannot prove this code is safe.\n", d->file, d->line, d->col);
    }
}

static void read_file_list(StrList *files, const char *path) {
    FILE *fp = !strcmp(path, "-") ? stdin : fopen(path, "r");
    if (!fp) return;
    char *line = NULL; size_t cap = 0;
    while (getline(&line, &cap, fp) >= 0) {
        char *s = trim(line);
        if (*s) collect_path(files, s);
    }
    free(line);
    if (fp != stdin) fclose(fp);
}

int main(int argc, char **argv) {
    Options opt = {0};
    StrList inputs = {0}, files = {0};
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "--help") || !strcmp(a, "-h")) { print_help(); return 0; }
        if (!strcmp(a, "--version")) { puts("Cppcheck 2.19 dev"); return 0; }
        if (!strcmp(a, "--errorlist")) { print_errorlist(); return 0; }
        if (!strcmp(a, "--xml")) { opt.xml = true; continue; }
        if (!strcmp(a, "-q") || !strcmp(a, "--quiet")) { opt.quiet = true; continue; }
        if (!strcmp(a, "-v") || !strcmp(a, "--verbose")) { opt.verbose = true; continue; }
        if (!strcmp(a, "--check-config")) { opt.check_config = true; continue; }
        if (!strcmp(a, "-E")) { opt.preprocess_only = true; continue; }
        if (!strncmp(a, "--enable=", 9)) {
            const char *e = a + 9;
            if (strstr(e, "all")) opt.enable_all = opt.enable_style = opt.enable_warning = opt.enable_missing_include = true;
            if (strstr(e, "style")) opt.enable_style = true;
            if (strstr(e, "warning")) opt.enable_warning = true;
            if (strstr(e, "missingInclude")) opt.enable_missing_include = true;
            continue;
        }
        if (!strncmp(a, "--error-exitcode=", 17)) { opt.error_exitcode = atoi(a + 17); continue; }
        if (!strncmp(a, "--output-file=", 14)) { opt.output_file = a + 14; continue; }
        if (!strcmp(a, "--output-file") && i + 1 < argc) { opt.output_file = argv[++i]; continue; }
        if (!strncmp(a, "--template=", 11)) { opt.template_name = a + 11; continue; }
        if (!strncmp(a, "--file-list=", 12)) { read_file_list(&files, a + 12); continue; }
        if (!strcmp(a, "--file-list") && i + 1 < argc) { read_file_list(&files, argv[++i]); continue; }
        if (!strcmp(a, "-I") || !strcmp(a, "-D") || !strcmp(a, "-U") || !strcmp(a, "-j") || !strcmp(a, "-l") || !strcmp(a, "-x") || !strcmp(a, "--std") || !strcmp(a, "--language")) {
            if (i + 1 < argc) i++;
            continue;
        }
        if (a[0] == '-') {
            const char *with_arg[] = {"--std=","--language=","--library=","--suppress=","--suppressions-list=","--inline-suppr","--inconclusive","--force","--max-configs=","--platform=","--project=","--project-configuration=","--cppcheck-build-dir=","--relative-paths","-rp=","--addon=","--addon-python=","--check-level=","--check-library","--dump","--output-format=","--report-type=","--rule=","--rule-file=","--showtime=","--config-exclude=","--config-excludes-file=","--includes-file=","--include=","--file-filter=","--safety","--report-progress","--plist-output=","--max-ctu-depth=","--fsigned-char","--funsigned-char",NULL};
            bool known = false;
            for (int k = 0; with_arg[k]; k++) if (!strncmp(a, with_arg[k], strlen(with_arg[k]))) { known = true; break; }
            if (known) continue;
            fprintf(stderr, "cppcheck: error: unrecognized command line option: \"%s\".\n", a);
            return 1;
        }
        push_str(&inputs, a);
    }
    for (size_t i = 0; i < inputs.n; i++) collect_path(&files, inputs.v[i]);
    if (files.n == 0 && !opt.preprocess_only) {
        print_help();
        return 0;
    }
    Diagnostics ds = {0};
    for (size_t i = 0; i < files.n; i++) analyze_file(&opt, files.v[i], &ds);
    FILE *out = opt.output_file ? fopen(opt.output_file, "w") : (opt.xml ? stderr : stderr);
    if (!out) out = stderr;
    output_diags(out, &opt, &ds);
    if (opt.output_file && out) fclose(out);
    bool has_error = false;
    for (size_t i = 0; i < ds.n; i++) if (!strcmp(ds.v[i].severity, "error")) has_error = true;
    return has_error && opt.error_exitcode ? opt.error_exitcode : 0;
}
