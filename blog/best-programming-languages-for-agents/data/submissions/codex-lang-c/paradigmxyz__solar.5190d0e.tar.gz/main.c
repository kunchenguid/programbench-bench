#include <ctype.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct { char *s; size_t n, cap; } Str;
static void die_oom(void){ fputs("out of memory\n", stderr); exit(1); }
static void sb_init(Str *b){ b->s=NULL; b->n=b->cap=0; }
static void sb_res(Str *b,size_t add){ if(b->n+add+1>b->cap){ size_t c=b->cap?b->cap*2:256; while(c<b->n+add+1)c*=2; char*p=realloc(b->s,c); if(!p)die_oom(); b->s=p; b->cap=c; }}
static void sb_addn(Str*b,const char*s,size_t n){ sb_res(b,n); memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void sb_add(Str*b,const char*s){ sb_addn(b,s,strlen(s)); }
static void sb_ch(Str*b,char c){ sb_res(b,1); b->s[b->n++]=c; b->s[b->n]=0; }
static char *xstrdup(const char*s){ char*p=strdup(s?s:""); if(!p)die_oom(); return p; }
static char *xstrndup(const char*s,size_t n){ char*p=malloc(n+1); if(!p)die_oom(); memcpy(p,s,n); p[n]=0; return p; }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; size_t n=strlen(s); while(n&&isspace((unsigned char)s[n-1]))s[--n]=0; return s; }
static int starts_word(const char*s,const char*w){ size_t n=strlen(w); return strncmp(s,w,n)==0 && !isalnum((unsigned char)s[n]) && s[n]!='_'; }
static int is_ident_char(char c){ return isalnum((unsigned char)c)||c=='_'; }

typedef struct { char *name,*type,*internal; int indexed; } Param;
typedef struct { Param *v; int n,cap; } Params;
typedef struct { char *kind,*name,*mut; Params in,out; int anonymous; } Item;
typedef struct { Item *v; int n,cap; } Items;
typedef struct { char *file,*name; Items items; } Contract;
typedef struct { Contract *v; int n,cap; } Contracts;
static void params_add(Params*a,Param p){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:4; a->v=realloc(a->v,a->cap*sizeof(Param)); if(!a->v)die_oom();} a->v[a->n++]=p; }
static void items_add(Items*a,Item it){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:8; a->v=realloc(a->v,a->cap*sizeof(Item)); if(!a->v)die_oom();} a->v[a->n++]=it; }
static void contracts_add(Contracts*a,Contract c){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:4; a->v=realloc(a->v,a->cap*sizeof(Contract)); if(!a->v)die_oom();} a->v[a->n++]=c; }

static char *read_all(FILE*f){
  Str b; sb_init(&b); char tmp[4096]; size_t n;
  while((n=fread(tmp,1,sizeof tmp,f))>0) sb_addn(&b,tmp,n);
  if(!b.s) return xstrdup("");
  return b.s;
}
static char *read_file(const char*path){
  FILE*f=fopen(path,"rb"); if(!f){ fprintf(stderr,"error: file %s not found\n\nerror: aborting due to 1 previous error\n\n",path); exit(1); }
  char*s=read_all(f); fclose(f); return s;
}
static char *strip_comments(const char*s){
  Str o; sb_init(&o);
  for(size_t i=0;s[i];){
    if(s[i]=='/'&&s[i+1]=='/'){ while(s[i]&&s[i]!='\n')i++; }
    else if(s[i]=='/'&&s[i+1]=='*'){ i+=2; while(s[i]&&!(s[i]=='*'&&s[i+1]=='/'))i++; if(s[i])i+=2; }
    else if(s[i]=='"'||s[i]=='\''){ char q=s[i]; sb_ch(&o,s[i++]); while(s[i]){ sb_ch(&o,s[i]); if(s[i]=='\\'&&s[i+1]){i++; sb_ch(&o,s[i]);} else if(s[i]==q){i++;break;} i++; } }
    else sb_ch(&o,s[i++]);
  }
  return o.s?o.s:xstrdup("");
}

static char *canon_type(const char *raw){
  char *t=xstrdup(raw), *p=trim(t);
  Str o; sb_init(&o);
  for(size_t i=0;p[i];i++) if(!isspace((unsigned char)p[i])) sb_ch(&o,p[i]);
  free(t); char *r=o.s?o.s:xstrdup("");
  if(strcmp(r,"uint")==0){ free(r); return xstrdup("uint256"); }
  if(strcmp(r,"int")==0){ free(r); return xstrdup("int256"); }
  if(strncmp(r,"uint[",5)==0){ Str b; sb_init(&b); sb_add(&b,"uint256"); sb_add(&b,r+4); free(r); return b.s; }
  if(strncmp(r,"int[",4)==0){ Str b; sb_init(&b); sb_add(&b,"int256"); sb_add(&b,r+3); free(r); return b.s; }
  char *pos;
  if((pos=strstr(r,"uint[]")) && pos==r){ Str b; sb_init(&b); sb_add(&b,"uint256"); sb_add(&b,r+4); free(r); return b.s; }
  if((pos=strstr(r,"int[]")) && pos==r){ Str b; sb_init(&b); sb_add(&b,"int256"); sb_add(&b,r+3); free(r); return b.s; }
  return r;
}
static int is_qual(const char*w){
  const char*q[]={"memory","calldata","storage","indexed","public","private","internal","external","payable","view","pure","returns","virtual","override","immutable","constant",NULL};
  for(int i=0;q[i];i++) if(strcmp(w,q[i])==0) return 1; return 0;
}
static int has_word(const char*s,const char*w){
  size_t n=strlen(w);
  for(const char*p=s;(p=strstr(p,w));p+=n)
    if((p==s||!is_ident_char(p[-1])) && !is_ident_char(p[n])) return 1;
  return 0;
}
static Param parse_param(char *seg, int event_mode){
  Param p={xstrdup(""),xstrdup(""),xstrdup(""),0};
  char *s=trim(seg); if(!*s) return p;
  char *tok[64]; int nt=0; char *save=NULL;
  for(char *w=strtok_r(s," \t\r\n",&save); w&&nt<64; w=strtok_r(NULL," \t\r\n",&save)) tok[nt++]=w;
  if(nt==0) return p;
  int namei=-1;
  for(int i=0;i<nt;i++) if(strcmp(tok[i],"indexed")==0) p.indexed=1;
  for(int i=nt-1;i>=0;i--){ if(strcmp(tok[i],"indexed")==0) continue; if(!is_qual(tok[i])){ namei=i; break; } }
  int type_end=nt;
  if(namei>0){ type_end=namei; p.name=xstrdup(tok[namei]); }
  else if(namei==0){ type_end=1; free(p.name); p.name=xstrdup(""); }
  Str ty; sb_init(&ty);
  for(int i=0;i<type_end;i++){
    if(is_qual(tok[i])||strcmp(tok[i],"indexed")==0) continue;
    if(ty.n) sb_ch(&ty,' ');
    sb_add(&ty,tok[i]);
  }
  if(!ty.n && namei>=0) sb_add(&ty,tok[namei]);
  char *ct=canon_type(ty.s?ty.s:""); free(ty.s);
  free(p.type); free(p.internal); p.type=xstrdup(ct); p.internal=ct;
  (void)event_mode; return p;
}
static Params parse_params(const char *inside, int event_mode){
  Params ps={0}; int depth=0; size_t start=0,n=strlen(inside);
  for(size_t i=0;i<=n;i++){
    char c=inside[i];
    if(c=='('||c=='[') depth++; else if((c==')'||c==']')&&depth>0) depth--;
    if((c==','&&depth==0)||c==0){ char *seg=xstrndup(inside+start,i-start); char *tr=trim(seg); if(*tr) params_add(&ps,parse_param(tr,event_mode)); free(seg); start=i+1; }
  }
  return ps;
}
static char *between_parens(const char*s, const char **after){
  const char*p=strchr(s,'('); if(!p) return xstrdup("");
  int d=1; const char*q=p+1; while(*q&&d){ if(*q=='(')d++; else if(*q==')')d--; if(d)q++; }
  if(after)*after=(*q==')')?q+1:q;
  return xstrndup(p+1,q-p-1);
}
static char *word_after(const char*s,const char*kw){
  const char*p=strstr(s,kw); if(!p) return xstrdup("");
  p+=strlen(kw); while(isspace((unsigned char)*p))p++;
  const char*e=p; while(is_ident_char(*e))e++;
  return xstrndup(p,e-p);
}
static char *state_mut(const char*s){
  if(strstr(s,"payable")) return xstrdup("payable");
  if(strstr(s,"view")) return xstrdup("view");
  if(strstr(s,"pure")) return xstrdup("pure");
  return xstrdup("nonpayable");
}
static Item make_item(const char*kind,const char*name){ Item it; memset(&it,0,sizeof it); it.kind=xstrdup(kind); it.name=xstrdup(name?name:""); it.mut=xstrdup(""); return it; }

static void parse_statement(Contract*c, char *st){
  char *s=trim(st); if(!*s) return;
  if(starts_word(s,"function")){
    char *name=word_after(s,"function"); if(!*name){ free(name); return; }
    const char *after; char *pin=between_parens(s,&after);
    if(has_word(after,"internal") || has_word(after,"private")){ free(name); free(pin); return; }
    Item it=make_item("function",name); it.in=parse_params(pin,0); it.mut=state_mut(after);
    char *r=strstr(after,"returns"); if(r){ char *pout=between_parens(r,NULL); it.out=parse_params(pout,0); free(pout); }
    items_add(&c->items,it); free(name); free(pin);
  } else if(starts_word(s,"constructor")){
    const char *after; char *pin=between_parens(s,&after);
    Item it=make_item("constructor",""); it.in=parse_params(pin,0); it.mut=state_mut(after); items_add(&c->items,it); free(pin);
  } else if(starts_word(s,"event")){
    char *name=word_after(s,"event"); char *pin=between_parens(s,NULL);
    Item it=make_item("event",name); it.in=parse_params(pin,1); it.anonymous=strstr(s,"anonymous")!=NULL; items_add(&c->items,it); free(name); free(pin);
  } else if(starts_word(s,"error")){
    char *name=word_after(s,"error"); char *pin=between_parens(s,NULL);
    Item it=make_item("error",name); it.in=parse_params(pin,0); items_add(&c->items,it); free(name); free(pin);
  } else if(starts_word(s,"fallback")){
    Item it=make_item("fallback",""); free(it.mut); it.mut=state_mut(s); items_add(&c->items,it);
  } else if(starts_word(s,"receive")){
    Item it=make_item("receive",""); free(it.mut); it.mut=state_mut(s); items_add(&c->items,it);
  } else if(has_word(s,"public")){
    char *copy=xstrdup(s); char *tok[64],*save=NULL; int nt=0;
    for(char*w=strtok_r(copy," \t\r\n;",&save);w&&nt<64;w=strtok_r(NULL," \t\r\n;",&save)) {
      char *eq=strchr(w,'=');
      if(eq && eq[1] != '>') *eq=0;
      if(*w) tok[nt++]=w;
    }
    int pub=-1; for(int i=0;i<nt;i++) if(strcmp(tok[i],"public")==0){pub=i;break;}
    if(pub>0){
      int namei=nt-1; while(namei>=0&&is_qual(tok[namei])) namei--;
      if(namei>pub){
        Str ty; sb_init(&ty); for(int i=0;i<pub;i++){ if(is_qual(tok[i]))continue; if(ty.n)sb_ch(&ty,' '); sb_add(&ty,tok[i]); }
        char *ct=canon_type(ty.s?ty.s:""); Item it=make_item("function",tok[namei]);
        if(strstr(ct,"mapping(")){ char *a=strchr(ct,'('),*ar=strstr(ct,"=>"),*b=strrchr(ct,')'); if(a&&ar&&b){ char *kt=xstrndup(a+1,ar-a-1), *vt=xstrndup(ar+2,b-ar-2); params_add(&it.in,(Param){xstrdup(""),canon_type(kt),canon_type(kt),0}); params_add(&it.out,(Param){xstrdup(""),canon_type(vt),canon_type(vt),0}); free(kt); free(vt);} }
        else {
          char *br=strstr(ct,"[]");
          if(br&&br[2]==0) {
            params_add(&it.in,(Param){xstrdup(""),xstrdup("uint256"),xstrdup("uint256"),0});
            char *base=xstrndup(ct,(size_t)(br-ct)); params_add(&it.out,(Param){xstrdup(""),xstrdup(base),xstrdup(base),0}); free(base);
          } else params_add(&it.out,(Param){xstrdup(""),xstrdup(ct),xstrdup(ct),0});
        }
        free(it.mut); it.mut=xstrdup("view"); items_add(&c->items,it); free(ct); free(ty.s);
      }
    }
    free(copy);
  }
}
static void parse_body(Contract*c,const char*body,size_t len){
  size_t start=0; int depth=0;
  for(size_t i=0;i<len;i++){
    char ch=body[i];
    if(ch=='('||ch=='[') depth++; else if((ch==')'||ch==']')&&depth>0) depth--;
    else if(ch=='{'&&depth==0){ int d=1; i++; while(i<len&&d){ if(body[i]=='{')d++; else if(body[i]=='}')d--; i++; } char *st=xstrndup(body+start,i-start); parse_statement(c,st); free(st); start=i; }
    else if(ch==';'&&depth==0){ char *st=xstrndup(body+start,i-start); parse_statement(c,st); free(st); start=i+1; }
  }
}
static void parse_source(Contracts*cs,const char*file,const char*src){
  char *clean=strip_comments(src); const char*p=clean;
  while(*p){
    const char*k=NULL; const char*kind=NULL;
    const char*c1=strstr(p,"contract "); const char*c2=strstr(p,"interface "); const char*c3=strstr(p,"library ");
    k=c1; kind="contract"; if(c2&&(!k||c2<k)){k=c2;kind="interface";} if(c3&&(!k||c3<k)){k=c3;kind="library";} if(!k)break;
    const char*n=k+strlen(kind)+1; while(isspace((unsigned char)*n))n++; const char*e=n; while(is_ident_char(*e))e++;
    if(e==n){ p=n; continue; }
    const char*b=strchr(e,'{'); if(!b)break; int d=1; const char*q=b+1; while(*q&&d){ if(*q=='{')d++; else if(*q=='}')d--; q++; }
    Contract c; memset(&c,0,sizeof c); c.file=xstrdup(file); c.name=xstrndup(n,e-n);
    if(q>b+1) parse_body(&c,b+1,(size_t)(q-b-2));
    contracts_add(cs,c); p=q;
  }
  free(clean);
}

/* tiny Keccak-256 */
static uint64_t rol64(uint64_t x,int s){return (x<<s)|(x>>(64-s));}
static const uint64_t RC[24]={0x0000000000000001ULL,0x0000000000008082ULL,0x800000000000808aULL,0x8000000080008000ULL,0x000000000000808bULL,0x0000000080000001ULL,0x8000000080008081ULL,0x8000000000008009ULL,0x000000000000008aULL,0x0000000000000088ULL,0x0000000080008009ULL,0x000000008000000aULL,0x000000008000808bULL,0x800000000000008bULL,0x8000000000008089ULL,0x8000000000008003ULL,0x8000000000008002ULL,0x8000000000000080ULL,0x000000000000800aULL,0x800000008000000aULL,0x8000000080008081ULL,0x8000000000008080ULL,0x0000000080000001ULL,0x8000000080008008ULL};
static const int R[25]={0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14};
static void keccakf(uint64_t a[25]){
  for(int r=0;r<24;r++){ uint64_t c[5],d[5],b[25]; for(int x=0;x<5;x++)c[x]=a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20]; for(int x=0;x<5;x++)d[x]=c[(x+4)%5]^rol64(c[(x+1)%5],1); for(int i=0;i<25;i++)a[i]^=d[i%5]; for(int x=0;x<5;x++)for(int y=0;y<5;y++)b[y+5*((2*x+3*y)%5)]=rol64(a[x+5*y],R[x+5*y]); for(int x=0;x<5;x++)for(int y=0;y<5;y++)a[x+5*y]=b[x+5*y]^((~b[((x+1)%5)+5*y])&b[((x+2)%5)+5*y]); a[0]^=RC[r]; }
}
static void keccak256(const unsigned char*in,size_t inlen,unsigned char out[32]){
  uint64_t st[25]={0}; const size_t rate=136; size_t off=0;
  while(inlen>=rate){ for(size_t i=0;i<rate;i++) ((unsigned char*)st)[i]^=in[off+i]; keccakf(st); off+=rate; inlen-=rate; }
  unsigned char temp[136]={0}; memcpy(temp,in+off,inlen); temp[inlen]=0x01; temp[rate-1]|=0x80; for(size_t i=0;i<rate;i++)((unsigned char*)st)[i]^=temp[i]; keccakf(st); memcpy(out,st,32);
}

static int item_rank(const Item*a){ if(!strcmp(a->kind,"constructor"))return 0; if(!strcmp(a->kind,"error"))return 1; if(!strcmp(a->kind,"event"))return 2; if(!strcmp(a->kind,"fallback"))return 3; if(!strcmp(a->kind,"function"))return 4; if(!strcmp(a->kind,"receive"))return 5; return 9; }
static int cmp_item(const void*A,const void*B){ const Item*a=A,*b=B; int ra=item_rank(a),rb=item_rank(b); if(ra!=rb)return ra-rb; return strcmp(a->name,b->name); }
static void json_str(Str*o,const char*s){ sb_ch(o,'"'); for(;*s;s++){ if(*s=='"'||*s=='\\'){sb_ch(o,'\\');sb_ch(o,*s);} else if(*s=='\n')sb_add(o,"\\n"); else sb_ch(o,*s);} sb_ch(o,'"');}
static void emit_params(Str*o,Params*p,int event_mode){
  sb_ch(o,'['); for(int i=0;i<p->n;i++){ if(i)sb_ch(o,','); sb_ch(o,'{'); sb_add(o,"\"name\":"); json_str(o,p->v[i].name); sb_add(o,",\"type\":"); json_str(o,p->v[i].type); if(event_mode){ sb_add(o,",\"indexed\":"); sb_add(o,p->v[i].indexed?"true":"false"); } sb_add(o,",\"internalType\":"); json_str(o,p->v[i].internal); sb_ch(o,'}'); } sb_ch(o,']');
}
static void signature(Str*o,Item*it){ sb_add(o,it->name); sb_ch(o,'('); for(int i=0;i<it->in.n;i++){ if(i)sb_ch(o,','); sb_add(o,it->in.v[i].type);} sb_ch(o,')'); }
static char *build_json(Contracts*cs,int emit_abi,int emit_hashes){
  for(int i=0;i<cs->n;i++) qsort(cs->v[i].items.v,cs->v[i].items.n,sizeof(Item),cmp_item);
  Str o; sb_init(&o); sb_add(&o,"{\"contracts\":{");
  for(int ci=0;ci<cs->n;ci++){
    if(ci)sb_ch(&o,','); Str key; sb_init(&key); sb_add(&key,cs->v[ci].file); sb_ch(&key,':'); sb_add(&key,cs->v[ci].name); json_str(&o,key.s); free(key.s); sb_add(&o,":{"); int field=0;
    if(emit_abi){ sb_add(&o,"\"abi\":["); int cnt=0; for(int ii=0;ii<cs->v[ci].items.n;ii++){ Item*it=&cs->v[ci].items.v[ii]; if(!strcmp(it->kind,"error")||!strcmp(it->kind,"event")||!strcmp(it->kind,"function")||!strcmp(it->kind,"constructor")||!strcmp(it->kind,"fallback")||!strcmp(it->kind,"receive")){ if(cnt++)sb_ch(&o,','); sb_add(&o,"{\"type\":"); json_str(&o,it->kind); if(strcmp(it->kind,"constructor")&&strcmp(it->kind,"fallback")&&strcmp(it->kind,"receive")){ sb_add(&o,",\"name\":"); json_str(&o,it->name);} if(!strcmp(it->kind,"function")){ sb_add(&o,",\"inputs\":"); emit_params(&o,&it->in,0); sb_add(&o,",\"outputs\":"); emit_params(&o,&it->out,0); sb_add(&o,",\"stateMutability\":"); json_str(&o,it->mut);} else if(!strcmp(it->kind,"constructor")){ sb_add(&o,",\"inputs\":"); emit_params(&o,&it->in,0); sb_add(&o,",\"stateMutability\":"); json_str(&o,it->mut);} else if(!strcmp(it->kind,"event")){ sb_add(&o,",\"inputs\":"); emit_params(&o,&it->in,1); sb_add(&o,",\"anonymous\":"); sb_add(&o,it->anonymous?"true":"false");} else if(!strcmp(it->kind,"error")){ sb_add(&o,",\"inputs\":"); emit_params(&o,&it->in,0);} else { sb_add(&o,",\"stateMutability\":"); json_str(&o,it->mut);} sb_ch(&o,'}'); }} sb_ch(&o,']'); field=1; }
    if(emit_hashes){ if(field)sb_ch(&o,','); sb_add(&o,"\"hashes\":{"); int cnt=0; for(int ii=0;ii<cs->v[ci].items.n;ii++){ Item*it=&cs->v[ci].items.v[ii]; if(strcmp(it->kind,"function"))continue; if(cnt++)sb_ch(&o,','); Str sig; sb_init(&sig); signature(&sig,it); json_str(&o,sig.s); unsigned char h[32]; keccak256((unsigned char*)sig.s,strlen(sig.s),h); char hex[9]; for(int k=0;k<4;k++)sprintf(hex+2*k,"%02x",h[k]); hex[8]=0; sb_add(&o,":"); json_str(&o,hex); free(sig.s);} sb_ch(&o,'}'); }
    sb_ch(&o,'}');
  }
  sb_add(&o,"},\"version\":\"0.1.8\"}"); return o.s;
}
static char *pretty_json(const char*min){
  Str o; sb_init(&o); int ind=0, instr=0;
  for(size_t i=0;min[i];i++){ char c=min[i]; if(c=='"' && (i==0||min[i-1]!='\\')) instr=!instr; if(instr){sb_ch(&o,c);continue;} if(c=='{'||c=='['){ sb_ch(&o,c); sb_ch(&o,'\n'); ind+=2; for(int j=0;j<ind;j++)sb_ch(&o,' ');} else if(c=='}'||c==']'){ sb_ch(&o,'\n'); ind-=2; for(int j=0;j<ind;j++)sb_ch(&o,' '); sb_ch(&o,c);} else if(c==','){ sb_ch(&o,c); sb_ch(&o,'\n'); for(int j=0;j<ind;j++)sb_ch(&o,' ');} else if(c==':'){ sb_add(&o,": "); } else sb_ch(&o,c); }
  return o.s;
}
static void print_help(int longh){
  printf("Blazingly fast Solidity compiler\n\nUsage: executable [OPTIONS] [INPUT]...\n\nArguments:\n  [INPUT]...  Files to compile, or import remappings\n\nOptions:\n  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]\n      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]\n      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]\n      --out-dir <OUT_DIR>          Directory to write output files\n      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]\n  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time\n  -h, --help                       Print help (see %s with '--help')\n  -V, --version                    Print version\n\nInput options:\n      --base-path <BASE_PATH>        Use the given path as the root of the source tree\n  -I, --include-path <INCLUDE_PATH>  Directory to search for files\n      --allow-paths <ALLOW_PATHS>    Allow a given path for imports\n\nDisplay options:\n      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]\n  -v, --verbose                      Use verbose output\n      --pretty-json                  Pretty-print JSON output\n      --pretty-json-err              Pretty-print error JSON output\n      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]\n      --error-format-human <VALUE>   Human-readable error message style [default: unicode]\n      --diagnostic-width <WIDTH>     Terminal width for error message formatting\n      --no-warnings                  Whether to disable warnings\n", longh?"more":"more");
}
int main(int argc,char**argv){
  int emit_abi=0,emit_hashes=0,pretty=0,stop_after=0; char*outdir=NULL; char **inputs=calloc(argc?argc:1,sizeof(char*)); int nin=0;
  for(int i=1;i<argc;i++){
    char*a=argv[i];
    if(!strcmp(a,"-h")||!strcmp(a,"--help")){ print_help(!strcmp(a,"--help")); return 0; }
    else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("solar Version: 0.1.8\nCommit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5\nBuild Timestamp: 2026-04-17T19:59:51.519973035Z\nBuild Features: mimalloc,tracing\nBuild Profile: release"); return 0; }
    else if(!strcmp(a,"-Zhelp")||(!strcmp(a,"-Z")&&i+1<argc&&!strcmp(argv[i+1],"help"))){ puts("error: List of all unstable flags.\nWARNING: these are completely unstable, and may change at any time!\n\nOptions:\n      -Zui-testing\n          Enables UI testing mode\n\n      -Ztrack-diagnostics\n          Prints a note for every diagnostic that is emitted with the creation and emission location.\n\n      -Zparse-yul\n          Enables parsing Yul files for testing\n\n      -Zno-resolve-imports\n          Disables import resolution\n\n      -Zdump=<KIND[=PATHS...]>\n          Print additional information about the compiler's internal state.\n\n      -Zast-stats\n          Print AST stats\n\n      -Zspan-visitor\n          Run the span visitor after parsing\n\n      -Zprint-max-storage-sizes\n          Print contracts' max storage sizes\n\n      -Ztypeck\n          Type check the program. WIP\n\n      -Zhelp\n          Print help\n\nUsage: solar [OPTIONS] [INPUT]...\n\nFor more information, try '--help'."); return 0; }
    else if(!strcmp(a,"--pretty-json")||!strcmp(a,"--pretty-json-err")) pretty=1;
    else if(!strcmp(a,"--out-dir")&&i+1<argc) outdir=argv[++i];
    else if(!strncmp(a,"--out-dir=",10)) outdir=a+10;
    else if((!strcmp(a,"--emit")&&i+1<argc)||!strncmp(a,"--emit=",7)){ char*e=!strncmp(a,"--emit=",7)?a+7:argv[++i]; char*cp=xstrdup(e); char*save=NULL; for(char*t=strtok_r(cp,",",&save);t;t=strtok_r(NULL,",",&save)){ if(!strcmp(t,"abi"))emit_abi=1; else if(!strcmp(t,"hashes"))emit_hashes=1; else {fprintf(stderr,"error: invalid value '%s' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.\n",t); return 2;}} free(cp); }
    else if(!strcmp(a,"--stop-after")&&i+1<argc){ stop_after=1; i++; }
    else if(!strcmp(a,"-j")||!strcmp(a,"--threads")||!strcmp(a,"--jobs")){
      if(i+1<argc){ char *v=argv[++i]; for(char*p=v;*p;p++) if(!isdigit((unsigned char)*p)){ fprintf(stderr,"error: invalid value '%s' for '--threads <THREADS>': invalid digit found in string\n\nFor more information, try '--help'.\n",v); return 2; } }
    }
    else if(!strncmp(a,"--threads=",10)||!strncmp(a,"--jobs=",7)){
      char *v=strchr(a,'=')+1; for(char*p=v;*p;p++) if(!isdigit((unsigned char)*p)){ fprintf(stderr,"error: invalid value '%s' for '--threads <THREADS>': invalid digit found in string\n\nFor more information, try '--help'.\n",v); return 2; }
    }
    else if(!strcmp(a,"--evm-version")||!strncmp(a,"--evm-version=",14)){
      char *v=!strncmp(a,"--evm-version=",14)?a+14:(i+1<argc?argv[++i]:"");
      const char*vals[]={"homestead","tangerineWhistle","spuriousDragon","byzantium","constantinople","petersburg","istanbul","berlin","london","paris","shanghai","cancun","prague","osaka",NULL}; int ok=0; for(int k=0;vals[k];k++) if(!strcmp(v,vals[k])) ok=1;
      if(!ok){ fprintf(stderr,"error: invalid value '%s' for '--evm-version <EVM_VERSION>'\n  [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]\n\nFor more information, try '--help'.\n",v); return 2; }
    }
    else if(!strcmp(a,"--base-path")||!strcmp(a,"-I")||!strcmp(a,"--include-path")||!strcmp(a,"--allow-paths")||!strcmp(a,"--color")||!strcmp(a,"--error-format")||!strcmp(a,"--error-format-human")||!strcmp(a,"--diagnostic-width")||!strcmp(a,"-Z")){ if(i+1<argc)i++; }
    else if(!strcmp(a,"-v")||!strcmp(a,"--verbose")||!strcmp(a,"--no-warnings")){}
    else if(a[0]=='-'&&strcmp(a,"-")){ fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n",a); return 2; }
    else { if(strchr(a,'=')&&strcmp(a,"-")){} else inputs[nin++]=a; }
  }
  if(!emit_abi&&!emit_hashes){ print_help(0); return 2; }
  Contracts cs={0};
  for(int i=0;i<nin;i++){ char*src; const char*name=inputs[i]; if(!strcmp(name,"-")){ src=read_all(stdin); name="<stdin>"; } else src=read_file(name); parse_source(&cs,name,src); free(src); }
  if(stop_after) return 0;
  char *json=build_json(&cs,emit_abi,emit_hashes); char *out=pretty?pretty_json(json):json;
  if(outdir){ char path[4096]; snprintf(path,sizeof path,"%s/combined.json",outdir); FILE*f=fopen(path,"wb"); if(!f){ fprintf(stderr,"error: failed to write to output: %s (os error %d)\n\nerror: aborting due to 1 previous error\n\n",strerror(errno),errno); return 1; } fwrite(out,1,strlen(out),f); fclose(f); }
  else { fputs(out,stdout); }
  if(pretty) free(out); free(json); return 0;
}
