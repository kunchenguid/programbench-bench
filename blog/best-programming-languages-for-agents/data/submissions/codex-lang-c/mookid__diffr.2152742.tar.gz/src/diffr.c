#define _GNU_SOURCE
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESET "\033[0m"

typedef struct {
    char *s;
} Style;

typedef struct {
    Style added, removed, radded, rremoved;
} Styles;

typedef struct {
    char **v;
    int n, cap;
} Lines;

typedef enum { LN_NONE, LN_COMPACT, LN_ALIGNED, LN_FIXED } LineNumMode;

static const char *HELP_SHORT =
"diffr 0.1.5\n"
"Nathan Moreau <nathan.moreau@m4x.org>\n"
"\n"
"diffr adds word-level diff on top of unified diffs.\n"
"word-level diff information is displayed using text attributes.\n"
"\n"
"USAGE:\n"
"    diffr reads from standard input and writes to standard output.\n"
"\n"
"    Typical usage is for interactive use of diff:\n"
"    diff -u <file1> <file2> | diffr\n"
"    git show | diffr\n"
"\n"
"OPTIONS:\n"
"        --colors <COLOR_SPEC>...    Configure color settings.\n"
"        --line-numbers              Display line numbers.\n"
"    -h, --help                      Prints help information\n"
"    -V, --version                   Prints version information\n";

static const char *HELP_LONG =
"diffr 0.1.5\n"
"Nathan Moreau <nathan.moreau@m4x.org>\n"
"\n"
"diffr adds word-level diff on top of unified diffs.\n"
"word-level diff information is displayed using text attributes.\n"
"\n"
"USAGE:\n"
"    diffr reads from standard input and writes to standard output.\n"
"\n"
"    Typical usage is for interactive use of diff:\n"
"    diff -u <file1> <file2> | diffr\n"
"    git show | diffr\n"
"\n"
"OPTIONS:\n"
"        --colors <COLOR_SPEC>...\n"
"            Configure color settings for console ouput.\n"
"\n"
"            There are four faces to customize:\n"
"            +----------------+--------------+----------------+\n"
"            |  line prefix   |      +       |       -        |\n"
"            +----------------+--------------+----------------+\n"
"            | common segment |    added     |    removed     |\n"
"            | unique segment | refine-added | refine-removed |\n"
"            +----------------+--------------+----------------+\n"
"\n"
"            The customization allows\n"
"            - to change the foreground or background color;\n"
"            - to set or unset the attributes 'bold', 'intense', 'underline';\n"
"            - to clear all attributes.\n"
"\n"
"            Customization is done passing a color_spec argument.\n"
"            This flag may be provided multiple times.\n"
"\n"
"            The syntax is the following:\n"
"\n"
"            color_spec = face-name + ':' + attributes\n"
"            attributes = attribute\n"
"                       | attribute + ':' + attributes\n"
"            attribute  = ('foreground' | 'background') + ':' + color\n"
"                       | (<empty> | 'no') + font-flag\n"
"                       | 'none'\n"
"            font-flag  = 'italic'\n"
"                       | 'bold'\n"
"                       | 'intense'\n"
"                       | 'underline'\n"
"            color      = 'none'\n"
"                       | [0-255]\n"
"                       | [0-255] + ',' + [0-255] + ',' + [0-255]\n"
"                       | ('black', 'blue', 'green', 'red',\n"
"                          'cyan', 'magenta', 'yellow', 'white')\n"
"\n"
"            For example, the color_spec\n"
"\n"
"                'refine-added:background:blue:bold'\n"
"\n"
"            sets the color of unique added segments with\n"
"            a blue background, written with a bold font.\n"
"\n"
"        --line-numbers <compact|aligned>\n"
"            Display line numbers. Style is optional.\n"
"            When style = 'compact', take as little width as possible.\n"
"            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]\n"
"\n"
"    -h, --help\n"
"            Prints help information\n"
"\n"
"    -V, --version\n"
"            Prints version information\n";

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) exit(1);
    return r;
}

static void style_set(Style *st, const char *s) {
    free(st->s);
    st->s = xstrdup(s);
}

static void style_append(Style *st, const char *s) {
    size_t a = strlen(st->s), b = strlen(s);
    st->s = realloc(st->s, a + b + 1);
    if (!st->s) exit(1);
    memcpy(st->s + a, s, b + 1);
}

static int color_name(const char *s) {
    const char *names[] = {"black","red","green","yellow","blue","magenta","cyan","white",NULL};
    for (int i = 0; names[i]; i++) if (!strcmp(s, names[i])) return i;
    return -1;
}

static void append_color(Style *st, const char *which, const char *val) {
    char buf[64];
    int fg = !strcmp(which, "foreground");
    if (!strcmp(val, "none")) return;
    int n = color_name(val);
    if (n >= 0) {
        snprintf(buf, sizeof buf, "\033[%dm", (fg ? 30 : 40) + n);
        style_append(st, buf);
        return;
    }
    int r, g, b;
    if (sscanf(val, "%d,%d,%d", &r, &g, &b) == 3) {
        snprintf(buf, sizeof buf, "\033[%d;2;%d;%d;%dm", fg ? 38 : 48, r, g, b);
        style_append(st, buf);
        return;
    }
    if (sscanf(val, "%d", &n) == 1) {
        snprintf(buf, sizeof buf, "\033[%d;5;%dm", fg ? 38 : 48, n);
        style_append(st, buf);
    }
}

static void parse_color_spec(Styles *s, const char *spec) {
    char *tmp = xstrdup(spec);
    char *face = strtok(tmp, ":");
    if (!face) {
        fprintf(stderr, "unexpected face name: got '%s', expected added|refine-added|removed|refine-removed\n", spec);
        exit(255);
    }
    Style *st = NULL;
    if (!strcmp(face, "added")) st = &s->added;
    else if (!strcmp(face, "removed")) st = &s->removed;
    else if (!strcmp(face, "refine-added")) st = &s->radded;
    else if (!strcmp(face, "refine-removed")) st = &s->rremoved;
    else {
        fprintf(stderr, "unexpected face name: got '%s', expected added|refine-added|removed|refine-removed\n", face);
        exit(255);
    }
    style_set(st, "");
    char *tok;
    while ((tok = strtok(NULL, ":")) != NULL) {
        if (!strcmp(tok, "none")) {
            style_set(st, "");
        } else if (!strcmp(tok, "bold")) style_append(st, "\033[1m");
        else if (!strcmp(tok, "italic")) style_append(st, "\033[3m");
        else if (!strcmp(tok, "underline")) style_append(st, "\033[4m");
        else if (!strcmp(tok, "intense")) style_append(st, "\033[90m");
        else if (!strcmp(tok, "nobold") || !strcmp(tok, "nointense")) style_append(st, "\033[22m");
        else if (!strcmp(tok, "noitalic")) style_append(st, "\033[23m");
        else if (!strcmp(tok, "nounderline")) style_append(st, "\033[24m");
        else if (!strcmp(tok, "foreground") || !strcmp(tok, "background")) {
            char *val = strtok(NULL, ":");
            if (val) append_color(st, tok, val);
        }
    }
    free(tmp);
}

static void lines_push(Lines *l, char *s) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 32;
        l->v = realloc(l->v, sizeof(char*) * l->cap);
        if (!l->v) exit(1);
    }
    l->v[l->n++] = s;
}

static void lines_free(Lines *l) {
    for (int i = 0; i < l->n; i++) free(l->v[i]);
    free(l->v);
    l->v = NULL; l->n = l->cap = 0;
}

static int is_hunk(const char *line) { return !strncmp(line, "@@ ", 3); }

static void parse_hunk(const char *line, int *oldn, int *newn) {
    int a = 0, b = 0;
    if (sscanf(line, "@@ -%d%*[,0-9] +%d", &a, &b) >= 2) {
        *oldn = a; *newn = b;
    }
}

static void prefix_line(LineNumMode mode, int oldn, int newn, char sign, const Styles *st) {
    if (mode == LN_NONE) return;
    if (sign == '-') {
        printf("%s%s", RESET, st->removed.s);
        if (mode == LN_ALIGNED) printf("%d  \t", oldn);
        else if (mode == LN_FIXED) printf("%3d    ", oldn);
        else printf("%2d   ", oldn);
        printf("%s", RESET);
    } else if (sign == '+') {
        printf("%s%s", RESET, st->added.s);
        if (mode == LN_ALIGNED) printf("  %d\t", newn);
        else if (mode == LN_FIXED) printf("    %3d", newn);
        else printf("    %d", newn);
        printf("%s", RESET);
    } else {
        if (mode == LN_ALIGNED) printf("%d  %d\t", oldn, newn);
        else if (mode == LN_FIXED) printf("%3d %3d", oldn, newn);
        else printf("%2d %2d", oldn, newn);
    }
}

typedef struct { int a, b; } Span;

static Span *tokenize(const char *s, int *outn) {
    int cap = 16, n = 0;
    Span *sp = malloc(sizeof(Span) * cap);
    if (!sp) exit(1);
    int i = 0;
    while (s[i]) {
        int start = i;
        if (isalnum((unsigned char)s[i]) || s[i] == '_') {
            while (isalnum((unsigned char)s[i]) || s[i] == '_') i++;
        } else if (isspace((unsigned char)s[i])) {
            while (isspace((unsigned char)s[i])) i++;
        } else {
            i++;
        }
        if (n == cap) {
            cap *= 2;
            sp = realloc(sp, sizeof(Span) * cap);
            if (!sp) exit(1);
        }
        sp[n++] = (Span){start, i};
    }
    *outn = n;
    return sp;
}

static int token_eq(const char *a, Span x, const char *b, Span y) {
    int lx = x.b - x.a, ly = y.b - y.a;
    return lx == ly && !strncmp(a + x.a, b + y.a, lx);
}

static void print_range(const char *s, int a, int b) {
    if (b > a) fwrite(s + a, 1, b - a, stdout);
}

static int *changed_tokens(const char *body, const char *other, int *tn_out, Span **tok_out) {
    int n, m;
    Span *t = tokenize(body, &n), *u = tokenize(other, &m);
    int *chg = malloc(sizeof(int) * (n ? n : 1));
    if (!chg) exit(1);
    if (n == 1 && m == 1) {
        size_t bl = strlen(body), ol = strlen(other);
        if ((bl <= ol && !strncmp(body, other, bl)) || (ol <= bl && !strncmp(body, other, ol))) {
            chg[0] = bl > ol;
            free(u);
            *tn_out = n;
            *tok_out = t;
            return chg;
        }
    }
    int *dp = calloc((n + 1) * (m + 1), sizeof(int));
    if (!dp) exit(1);
    for (int i = n - 1; i >= 0; i--) {
        for (int j = m - 1; j >= 0; j--) {
            if (token_eq(body, t[i], other, u[j])) dp[i*(m+1)+j] = 1 + dp[(i+1)*(m+1)+j+1];
            else {
                int a = dp[(i+1)*(m+1)+j], b = dp[i*(m+1)+j+1];
                dp[i*(m+1)+j] = a > b ? a : b;
            }
        }
    }
    for (int i = 0; i < n; i++) chg[i] = 1;
    int i = 0, j = 0;
    while (i < n && j < m) {
        if (token_eq(body, t[i], other, u[j])) {
            chg[i] = 0; i++; j++;
        } else if (dp[(i+1)*(m+1)+j] >= dp[i*(m+1)+j+1]) {
            i++;
        } else {
            j++;
        }
    }
    free(dp); free(u);
    *tn_out = n;
    *tok_out = t;
    return chg;
}

static void print_styled_body(const char *body, const char *other, const Style *base, const Style *ref) {
    if (!other) {
        printf("%s%s", RESET, base->s);
        fputs(body, stdout);
        printf("%s", RESET);
        return;
    }
    int n;
    Span *tok;
    int *chg = changed_tokens(body, other, &n, &tok);
    int refined = -1;
    for (int i = 0; i < n; i++) {
        int now = chg[i];
        if (now != refined) {
            printf("%s%s", RESET, now ? ref->s : base->s);
            refined = now;
        }
        print_range(body, tok[i].a, tok[i].b);
    }
    printf("%s", RESET);
    free(tok);
    free(chg);
}

static void print_diff_line(const char *line, char sign, const char *other, int oldn, int newn, LineNumMode mode, const Styles *st) {
    const char *body = line + 1;
    const Style *base = sign == '+' ? &st->added : &st->removed;
    const Style *ref = sign == '+' ? &st->radded : &st->rremoved;
    printf("%s", RESET);
    prefix_line(mode, oldn, newn, sign, st);
    printf("%s%s%c%s", RESET, base->s, sign, RESET);
    print_styled_body(body, other ? other + 1 : NULL, base, ref);
    printf("\n");
}

static void print_plain(const char *line, int oldn, int newn, LineNumMode mode) {
    if (mode != LN_NONE && line[0] == ' ') {
        if (mode == LN_ALIGNED) printf("%d  %d\t", oldn, newn);
        else if (mode == LN_FIXED) printf("%3d %3d", oldn, newn);
        else printf("%2d %2d", oldn, newn);
    }
    printf("%s%s%s\n", RESET, line, RESET);
}

static char **collect_side(Lines *h, char sign, int *n) {
    char **r = malloc(sizeof(char*) * (h->n ? h->n : 1));
    int k = 0;
    for (int i = 0; i < h->n; i++) if (h->v[i][0] == sign) r[k++] = h->v[i];
    *n = k;
    return r;
}

static void process_hunk(Lines *h, int old_start, int new_start, LineNumMode mode, const Styles *st) {
    int rn, an, ri = 0, ai = 0, oldn = old_start, newn = new_start;
    char **rem = collect_side(h, '-', &rn);
    char **add = collect_side(h, '+', &an);
    for (int i = 0; i < h->n; i++) {
        char *line = h->v[i];
        if (line[0] == '-' && strncmp(line, "---", 3)) {
            char *other = ai < an ? add[ai] : NULL;
            print_diff_line(line, '-', other, oldn, newn, mode, st);
            oldn++; ri++;
        } else if (line[0] == '+' && strncmp(line, "+++", 3)) {
            char *other = ri <= rn && ai < rn ? rem[ai] : (ai < rn ? rem[ai] : NULL);
            print_diff_line(line, '+', other, oldn, newn, mode, st);
            newn++; ai++;
        } else {
            print_plain(line, oldn, newn, mode);
            if (line[0] == ' ') { oldn++; newn++; }
        }
    }
    free(rem); free(add);
}

int main(int argc, char **argv) {
    Styles st = { {xstrdup("\033[32m")}, {xstrdup("\033[31m")},
                  {xstrdup("\033[1m\033[38;2;255;255;255m\033[42m")},
                  {xstrdup("\033[1m\033[38;2;255;255;255m\033[41m")} };
    LineNumMode ln = LN_NONE;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) {
            puts("diffr 0.1.5");
            return 0;
        } else if (!strcmp(argv[i], "-h")) {
            fputs(HELP_SHORT, stdout);
            return 0;
        } else if (!strcmp(argv[i], "--help")) {
            fputs(HELP_LONG, stdout);
            return 0;
        } else if (!strcmp(argv[i], "--line-numbers")) {
            ln = LN_COMPACT;
            if (i + 1 < argc && argv[i+1][0] != '-') {
                i++;
                if (!strcmp(argv[i], "compact")) ln = LN_COMPACT;
                else if (!strcmp(argv[i], "aligned")) ln = LN_ALIGNED;
                else if (!strcmp(argv[i], "fixed")) ln = LN_FIXED;
                else {
                    fprintf(stderr, "unexpected line number style: got '%s', expected aligned|compact|fixed\n", argv[i]);
                    return 255;
                }
            }
        } else if (!strcmp(argv[i], "--colors")) {
            if (i + 1 >= argc) return 255;
            parse_color_spec(&st, argv[++i]);
        } else {
            fprintf(stderr, "bad argument: '%s'\n%s", argv[i], HELP_SHORT);
            return 2;
        }
    }

    Lines h = {0};
    char *line = NULL;
    size_t cap = 0;
    ssize_t len;
    int in_hunk = 0, old_start = 0, new_start = 0;
    while ((len = getline(&line, &cap, stdin)) >= 0) {
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r')) line[--len] = 0;
        if (is_hunk(line)) {
            if (in_hunk) { process_hunk(&h, old_start, new_start, ln, &st); lines_free(&h); }
            printf("%s%s%s\n", RESET, line, RESET);
            parse_hunk(line, &old_start, &new_start);
            in_hunk = 1;
        } else if (in_hunk) {
            if (!strncmp(line, "diff ", 5) || !strncmp(line, "index ", 6) || !strncmp(line, "--- ", 4) || !strncmp(line, "+++ ", 4)) {
                process_hunk(&h, old_start, new_start, ln, &st); lines_free(&h); in_hunk = 0;
                printf("%s%s%s\n", RESET, line, RESET);
            } else {
                lines_push(&h, xstrdup(line));
            }
        } else {
            printf("%s%s%s\n", RESET, line, RESET);
        }
    }
    if (in_hunk) { process_hunk(&h, old_start, new_start, ln, &st); lines_free(&h); }
    free(line);
    return 0;
}
