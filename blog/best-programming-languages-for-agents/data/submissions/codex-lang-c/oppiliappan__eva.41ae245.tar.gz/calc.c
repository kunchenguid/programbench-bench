#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>

#define ERRLEN 256
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#ifndef M_E
#define M_E 2.71828182845904523536
#endif
typedef struct { const char *s; int pos; int angle; double prev; int has_prev; char err[ERRLEN]; } Parser;
static void seterr(Parser *p, const char *msg){ if(!p->err[0]) snprintf(p->err, ERRLEN, "%s", msg); }
static void skip(Parser *p){ while(isspace((unsigned char)p->s[p->pos])) p->pos++; }
static int peek(Parser *p){ skip(p); return p->s[p->pos]; }
static int consume(Parser *p, char c){ skip(p); if(p->s[p->pos]==c){p->pos++; return 1;} return 0; }
static double parse_expr(Parser *p);

static int is_known_func(const char *name){
    const char *funcs[] = {"sin","cos","tan","csc","sec","cot","sinh","cosh","tanh","asin","acos","atan","acsc","asec","acot","ln","log2","log10","sqrt","ceil","floor","abs","log","nroot",NULL};
    for(int i=0; funcs[i]; i++) if(!strcmp(name, funcs[i])) return 1;
    return 0;
}
static int starts_primary(Parser *p){ int c=peek(p); return c=='('||c=='.'||c=='_'||isalpha(c)||isdigit(c); }
static double to_rad(Parser *p,double x){ if(p->angle==0) return x*M_PI/180.0; if(p->angle==2) return x*M_PI/200.0; return x; }

static double call1(Parser *p,const char *name,double a){
    if(!strcmp(name,"sin")) return sin(to_rad(p,a));
    if(!strcmp(name,"cos")) return cos(to_rad(p,a));
    if(!strcmp(name,"tan")) return tan(to_rad(p,a));
    if(!strcmp(name,"csc")){ double v=sin(to_rad(p,a)); if(fabs(v)<1e-15){seterr(p,"Math Error: Divide by zero error!"); return 0;} return 1/v; }
    if(!strcmp(name,"sec")){ double v=cos(to_rad(p,a)); if(fabs(v)<1e-15){seterr(p,"Math Error: Divide by zero error!"); return 0;} return 1/v; }
    if(!strcmp(name,"cot")){ double v=tan(to_rad(p,a)); if(fabs(v)<1e-15){seterr(p,"Math Error: Divide by zero error!"); return 0;} return 1/v; }
    if(!strcmp(name,"sinh")) return sinh(a); if(!strcmp(name,"cosh")) return cosh(a); if(!strcmp(name,"tanh")) return tanh(a);
    if(!strcmp(name,"asin")){ if(a<-1||a>1){seterr(p,"Domain Error: Out of bounds!"); return 0;} return asin(a); }
    if(!strcmp(name,"acos")){ if(a<-1||a>1){seterr(p,"Domain Error: Out of bounds!"); return 0;} return acos(a); }
    if(!strcmp(name,"atan")) return atan(a);
    if(!strcmp(name,"acsc")){ if(fabs(a)<1){seterr(p,"Domain Error: Out of bounds!"); return 0;} return asin(1/a); }
    if(!strcmp(name,"asec")){ if(fabs(a)<1){seterr(p,"Domain Error: Out of bounds!"); return 0;} return acos(1/a); }
    if(!strcmp(name,"acot")) return atan(1/a);
    if(!strcmp(name,"ln")){ if(a<=0){seterr(p,"Domain Error: Out of bounds!"); return 0;} return log(a); }
    if(!strcmp(name,"log2")){ if(a<=0){seterr(p,"Domain Error: Out of bounds!"); return 0;} return log2(a); }
    if(!strcmp(name,"log10")){ if(a<=0){seterr(p,"Domain Error: Out of bounds!"); return 0;} return log10(a); }
    if(!strcmp(name,"sqrt")){ if(a<0){seterr(p,"Domain Error: Out of bounds!"); return 0;} return sqrt(a); }
    if(!strcmp(name,"ceil")) return ceil(a); if(!strcmp(name,"floor")) return floor(a); if(!strcmp(name,"abs")) return fabs(a);
    char b[ERRLEN]; snprintf(b,sizeof(b),"Syntax Error: Unknown function '%s'",name); seterr(p,b); return 0;
}
static double call2(Parser *p,const char *name,double a,double b){
    if(!strcmp(name,"log")){ if(a<=0||b<=0||b==1){seterr(p,"Domain Error: Out of bounds!"); return 0;} return log(a)/log(b); }
    if(!strcmp(name,"nroot")){ if(b==0){seterr(p,"Math Error: Divide by zero error!"); return 0;} if(a<0 && fabs(fmod(b,2.0))<1e-12){seterr(p,"Domain Error: Out of bounds!"); return 0;} return pow(a,1.0/b); }
    char e[ERRLEN]; snprintf(e,sizeof(e),"Syntax Error: Unknown function '%s'",name); seterr(p,e); return 0;
}
static double parse_primary(Parser *p){
    skip(p); int c=p->s[p->pos];
    if(c=='('){ p->pos++; double v=parse_expr(p); consume(p,')'); return v; }
    if(c=='_'){ p->pos++; return p->has_prev?p->prev:0.0; }
    if(isdigit(c)||c=='.'){ char num[128]; int n=0; while(isdigit((unsigned char)p->s[p->pos])||p->s[p->pos]=='.'){ if(n<127) num[n++]=p->s[p->pos]; p->pos++; } num[n]=0; return atof(num); }
    if(isalpha(c)){
        char name[64]; int n=0; while(isalpha((unsigned char)p->s[p->pos])){ if(n<63) name[n++]=p->s[p->pos]; p->pos++; } if(n==3 && !strncmp(name,"log",3)){ while(isdigit((unsigned char)p->s[p->pos])){ if(n<63) name[n++]=p->s[p->pos]; p->pos++; } } name[n]=0;
        if(!strcmp(name,"pi")||!strcmp(name,"e")){ skip(p); if(p->s[p->pos]=='('){ char b[ERRLEN]; snprintf(b,sizeof(b),"Syntax Error: Unknown function '%s'",name); seterr(p,b); return 0; } return !strcmp(name,"pi") ? M_PI : M_E; }
        if(!consume(p,'(')){ if(is_known_func(name)){ char b[ERRLEN]; snprintf(b,sizeof(b),"Syntax Error: Function '%s' expected parentheses",name); seterr(p,b); } else seterr(p,"Parser Error: Too many operators, too few operands"); return 0; }
        if(consume(p,')')){ seterr(p,"Parser Error: To few arguments for function, need 1"); return 0; }
        double a=parse_expr(p); int args=1; double b=0;
        if(consume(p,',')){ args=2; b=parse_expr(p); }
        consume(p,')');
        if(!strcmp(name,"log")||!strcmp(name,"nroot")){ if(args<2){ seterr(p,"Parser Error: To few arguments for function, need 2"); return 0;} return call2(p,name,a,b); }
        return call1(p,name,a);
    }
    seterr(p,"Parser Error: Too many operators, too few operands"); return 0;
}
static double parse_unary(Parser *p){ if(consume(p,'+')) return parse_unary(p); if(consume(p,'-')) return -parse_unary(p); return parse_primary(p); }
static double parse_power(Parser *p){ double v=parse_unary(p); skip(p); if(p->s[p->pos]=='^' || (p->s[p->pos]=='*'&&p->s[p->pos+1]=='*')){ if(p->s[p->pos]=='*') p->pos+=2; else p->pos++; double r=parse_power(p); v=pow(v,r); if(!isfinite(v)) seterr(p,"Domain Error: Out of bounds!"); } return v; }
static double parse_term(Parser *p){ double v=parse_power(p); for(;;){ if(consume(p,'*')){ v*=parse_power(p); } else if(consume(p,'/')){ double r=parse_power(p); if(fabs(r)<1e-15){seterr(p,"Math Error: Divide by zero error!"); return 0;} v/=r; } else if(starts_primary(p)){ v*=parse_power(p); } else break; if(p->err[0]) return 0; } return v; }
static double parse_expr(Parser *p){ double v=parse_term(p); for(;;){ if(consume(p,'+')) v+=parse_term(p); else if(consume(p,'-')) v-=parse_term(p); else break; if(p->err[0]) return 0; } return v; }

static void add_commas(const char *in, char *out){ int neg=in[0]=='-'; const char *s=in+neg; int len=strlen(s), first=len%3; if(first==0) first=3; char *o=out; if(neg)*o++='-'; for(int i=0;i<len;i++){ if(i>0 && (i-first)%3==0) *o++=','; *o++=s[i]; } *o=0; }
static void format_base(double val,int base,int fix){
    if(base==10){ char fmt[32], raw[512], frac[512]=""; snprintf(fmt,sizeof(fmt),"%%.%df",fix); snprintf(raw,sizeof(raw),fmt,val); char *dot=strchr(raw,'.'); if(dot){ *dot=0; strcpy(frac,dot+1);} char ci[512]; add_commas(raw,ci); if(dot) printf("%s.%s\n",ci,frac); else printf("%s\n",ci); return; }
    const char digs[]="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"; double av=fabs(val); unsigned long long ip=(unsigned long long)floor(av+1e-12); char buf[128]; int n=0; if(ip==0) buf[n++]='0'; while(ip){ buf[n++]=digs[ip%base]; ip/=base; } char rev[128]; for(int i=0;i<n;i++) rev[i]=buf[n-1-i]; rev[n]=0; if(val<0){ memmove(rev+1,rev,n+1); rev[0]='-'; n++; }
    char grouped[256]; add_commas(rev,grouped); char groups[4][8]; strcpy(groups[0]," "); for(int i=1;i<4;i++) strcpy(groups[i],"   "); char tmp[256]; strcpy(tmp,grouped); char *parts[16]; int pc=0; char *tok=strtok(tmp,","); while(tok&&pc<16){parts[pc++]=tok; tok=strtok(NULL,",");}
    int start=4-pc; if(start<0) start=0; for(int i=0;i<pc && start+i<4;i++) snprintf(groups[start+i],8,"%3s",parts[i]); printf("%s,%s,%s,%s",groups[0],groups[1],groups[2],groups[3]);
    double frac=av-floor(av+1e-12); printf("."); if(frac<1e-12){ printf("0\n"); return; } int cnt=0; while(frac>1e-12 && cnt<fix){ frac*=base; int d=(int)floor(frac+1e-12); if(d>=base)d=base-1; printf("%c",digs[d]); frac-=d; cnt++; } printf("\n");
}
static int eval_line(const char *line,int base,int fix,int angle,double *prev,int *has_prev){ Parser p={line,0,angle,*prev,*has_prev,""}; if(strlen(line)==0){ printf("No previous history.\n"); return 0; } double v=parse_expr(&p); skip(&p); if(!p.err[0] && p.s[p.pos]==')') seterr(&p,"Syntax Error: Mismatched parentheses!"); if(!p.err[0] && p.s[p.pos]==',') seterr(&p,"Syntax Error: Mismatched parentheses!"); if(!p.err[0] && p.s[p.pos]) seterr(&p,"Parser Error: Too many operators, too few operands"); if(p.err[0]) printf("%s\n",p.err); else { format_base(v,base,fix); *prev=v; *has_prev=1; } return 0; }
static void usage(void){ puts("Calculator REPL similar to bc(1)\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]  Optional expression string to run eva in command mode\n\nOptions:\n  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]\n  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]\n  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]\n  -h, --help                     Print help\n  -V, --version                  Print version"); }
int main(int argc,char **argv){ int fix=10,base=10,angle=0; const char *input=NULL; int after=0; for(int i=1;i<argc;i++){ char *a=argv[i]; if(!after && (!strcmp(a,"-h")||!strcmp(a,"--help"))){usage(); return 0;} if(!after && (!strcmp(a,"-V")||!strcmp(a,"--version"))){puts("eva 0.3.1"); return 0;} if(!after && (!strcmp(a,"--"))){after=1; continue;} if(!after && (!strcmp(a,"-f")||!strcmp(a,"--fix")) && i+1<argc){fix=atoi(argv[++i]); if(fix<1||fix>64){printf("error: invalid value '%d' for '--fix <FIX>': %d is not in 1..=64\n\nFor more information, try '--help'.\n",fix,fix); return 0;} continue;} if(!after && (!strcmp(a,"-b")||!strcmp(a,"--base")) && i+1<argc){base=atoi(argv[++i]); if(base<1||base>36){printf("error: invalid value '%d' for '--base <RADIX>': %d is not in 1..=36\n\nFor more information, try '--help'.\n",base,base); return 0;} if(base<2) base=10; continue;} if(!after && (!strcmp(a,"-a")||!strcmp(a,"--angle_unit")) && i+1<argc){char *u=argv[++i]; if(!strcmp(u,"radian")) angle=1; else if(!strcmp(u,"gradian")) angle=2; else angle=0; continue;} if(!after && !strcmp(a,"-r")){angle=1; continue;} if(!after && a[0]=='-' && isdigit((unsigned char)a[1])){ printf("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.\n",a,a,a); return 0; } if(input){ printf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.\n",a); return 0; } input=a; } double prev=0; int has=0; if(input) return eval_line(input,base,fix,angle,&prev,&has); char line[1024]; puts("No previous history."); while(fgets(line,sizeof(line),stdin)){ line[strcspn(line,"\r\n")]=0; if(!strcmp(line,"exit")||!strcmp(line,"quit")) break; eval_line(line,base,fix,angle,&prev,&has);} return 0; }
