#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <time.h>
#include <stdarg.h>

#define HEADER_COUNT 5
static const char *headers[HEADER_COUNT] = {"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"};

typedef struct {
    char *path;
    char *version;
    char *time_s;
    char *update_version;
    char *update_time;
    int indirect;
    int has_update;
    int valid_ts;
} Module;

typedef struct {
    Module *items;
    size_t len;
    size_t cap;
} Vec;

static void die_log(const char *fmt, ...) {
    time_t t = time(NULL);
    struct tm lt;
    localtime_r(&t, &lt);
    fprintf(stderr, "%04d/%02d/%02d %02d:%02d:%02d ", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday,
            lt.tm_hour, lt.tm_min, lt.tm_sec);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) exit(1);
    return r;
}

static void vec_push(Vec *v, Module m) {
    if (v->len == v->cap) {
        v->cap = v->cap ? v->cap * 2 : 16;
        v->items = realloc(v->items, v->cap * sizeof(Module));
        if (!v->items) exit(1);
    }
    v->items[v->len++] = m;
}

static void skip_ws(const char **p) {
    while (**p && isspace((unsigned char)**p)) (*p)++;
}

static char *parse_string(const char **p) {
    if (**p != '"') die_log("invalid character '%c' looking for beginning of value", **p ? **p : 0);
    (*p)++;
    size_t cap = 32, len = 0;
    char *out = malloc(cap);
    if (!out) exit(1);
    while (**p && **p != '"') {
        unsigned char c = (unsigned char)*((*p)++);
        if (c == '\\') {
            c = (unsigned char)*((*p)++);
            switch (c) {
                case '"': c = '"'; break;
                case '\\': c = '\\'; break;
                case '/': c = '/'; break;
                case 'b': c = '\b'; break;
                case 'f': c = '\f'; break;
                case 'n': c = '\n'; break;
                case 'r': c = '\r'; break;
                case 't': c = '\t'; break;
                case 'u': {
                    /* The module data is ASCII in practice. Preserve non-ASCII escapes as '?'. */
                    for (int i = 0; i < 4 && isxdigit((unsigned char)**p); i++) (*p)++;
                    c = '?';
                    break;
                }
                default: break;
            }
        }
        if (len + 1 >= cap) {
            cap *= 2;
            out = realloc(out, cap);
            if (!out) exit(1);
        }
        out[len++] = (char)c;
    }
    if (**p != '"') die_log("unexpected EOF");
    (*p)++;
    out[len] = 0;
    return out;
}

static void skip_value(const char **p);

static void skip_object(const char **p) {
    if (**p != '{') return;
    (*p)++;
    skip_ws(p);
    if (**p == '}') { (*p)++; return; }
    while (**p) {
        skip_ws(p);
        char *k = parse_string(p);
        free(k);
        skip_ws(p);
        if (**p == ':') (*p)++; else die_log("invalid character '%c' after object key", **p);
        skip_ws(p);
        skip_value(p);
        skip_ws(p);
        if (**p == ',') { (*p)++; continue; }
        if (**p == '}') { (*p)++; return; }
        die_log("invalid character '%c' after object key:value pair", **p);
    }
    die_log("unexpected EOF");
}

static void skip_array(const char **p) {
    if (**p != '[') return;
    (*p)++;
    skip_ws(p);
    if (**p == ']') { (*p)++; return; }
    while (**p) {
        skip_value(p);
        skip_ws(p);
        if (**p == ',') { (*p)++; skip_ws(p); continue; }
        if (**p == ']') { (*p)++; return; }
        die_log("invalid character '%c' after array element", **p);
    }
    die_log("unexpected EOF");
}

static void skip_literal_or_number(const char **p) {
    while (**p && !isspace((unsigned char)**p) && **p != ',' && **p != '}' && **p != ']') (*p)++;
}

static void skip_value(const char **p) {
    skip_ws(p);
    if (**p == '"') { char *s = parse_string(p); free(s); }
    else if (**p == '{') skip_object(p);
    else if (**p == '[') skip_array(p);
    else skip_literal_or_number(p);
}

static bool parse_bool_lit(const char **p) {
    if (strncmp(*p, "true", 4) == 0) { *p += 4; return true; }
    if (strncmp(*p, "false", 5) == 0) { *p += 5; return false; }
    skip_literal_or_number(p);
    return false;
}

static void setstr(char **dst, char *src) {
    free(*dst);
    *dst = src;
}

static void parse_update(const char **p, Module *m) {
    if (**p != '{') { skip_value(p); return; }
    m->has_update = 1;
    (*p)++;
    skip_ws(p);
    if (**p == '}') { (*p)++; return; }
    while (**p) {
        skip_ws(p);
        char *key = parse_string(p);
        skip_ws(p);
        if (**p != ':') die_log("invalid character '%c' after object key", **p);
        (*p)++;
        skip_ws(p);
        if (strcmp(key, "Version") == 0 && **p == '"') setstr(&m->update_version, parse_string(p));
        else if (strcmp(key, "Time") == 0 && **p == '"') setstr(&m->update_time, parse_string(p));
        else skip_value(p);
        free(key);
        skip_ws(p);
        if (**p == ',') { (*p)++; continue; }
        if (**p == '}') { (*p)++; return; }
        die_log("invalid character '%c' after object key:value pair", **p);
    }
    die_log("unexpected EOF");
}

static Module parse_module(const char **p) {
    Module m;
    memset(&m, 0, sizeof(m));
    m.path = xstrdup("");
    m.version = xstrdup("");
    m.time_s = NULL;
    m.update_version = xstrdup("");
    m.update_time = NULL;
    m.indirect = 0;
    if (**p != '{') die_log("invalid character '%c' looking for beginning of value", **p ? **p : 0);
    (*p)++;
    skip_ws(p);
    if (**p == '}') { (*p)++; return m; }
    while (**p) {
        skip_ws(p);
        char *key = parse_string(p);
        skip_ws(p);
        if (**p != ':') die_log("invalid character '%c' after object key", **p);
        (*p)++;
        skip_ws(p);
        if (strcmp(key, "Path") == 0 && **p == '"') setstr(&m.path, parse_string(p));
        else if (strcmp(key, "Version") == 0 && **p == '"') setstr(&m.version, parse_string(p));
        else if (strcmp(key, "Time") == 0 && **p == '"') setstr(&m.time_s, parse_string(p));
        else if (strcmp(key, "Indirect") == 0) m.indirect = parse_bool_lit(p) ? 1 : 0;
        else if (strcmp(key, "Update") == 0) parse_update(p, &m);
        else skip_value(p);
        free(key);
        skip_ws(p);
        if (**p == ',') { (*p)++; continue; }
        if (**p == '}') { (*p)++; break; }
        die_log("invalid character '%c' after object key:value pair", **p);
    }
    return m;
}

static char *read_all_stdin(void) {
    size_t cap = 8192, len = 0;
    char *buf = malloc(cap + 1);
    if (!buf) exit(1);
    for (;;) {
        if (len == cap) {
            cap *= 2;
            buf = realloc(buf, cap + 1);
            if (!buf) exit(1);
        }
        size_t n = fread(buf + len, 1, cap - len, stdin);
        len += n;
        if (n == 0) break;
    }
    buf[len] = 0;
    return buf;
}

static int parse_rfc3339_utc(const char *s, time_t *out) {
    if (!s) return -2;
    struct tm tm;
    memset(&tm, 0, sizeof(tm));
    char *end = strptime(s, "%Y-%m-%dT%H:%M:%SZ", &tm);
    if (!end || *end) return -1;
    tm.tm_isdst = 0;
    *out = timegm(&tm);
    return 0;
}

static void compute_valid(Module *m) {
    m->valid_ts = 1;
    if (!m->has_update) return;
    time_t cur, upd;
    int a = parse_rfc3339_utc(m->time_s, &cur);
    if (a == -1) die_log("parsing time \"%s\" as \"2006-01-02T15:04:05Z07:00\": cannot parse \"%s\" as \"2006\"", m->time_s, m->time_s);
    int b = parse_rfc3339_utc(m->update_time, &upd);
    if (b == -1) die_log("parsing time \"%s\" as \"2006-01-02T15:04:05Z07:00\": cannot parse \"%s\" as \"2006\"", m->update_time, m->update_time);
    if (a == -2 || b == -2) {
        fprintf(stderr, "panic: runtime error: invalid memory address or nil pointer dereference\n");
        exit(2);
    }
    m->valid_ts = (cur <= upd) ? 1 : 0;
}

static void center_print(const char *s, int width) {
    int len = (int)strlen(s);
    int pad = width - len;
    int left = pad / 2;
    int right = pad - left;
    for (int i = 0; i < left; i++) putchar(' ');
    fputs(s, stdout);
    for (int i = 0; i < right; i++) putchar(' ');
}

static void print_sep(int widths[]) {
    putchar('|');
    for (int c = 0; c < HEADER_COUNT; c++) {
        int n = widths[c] + 2;
        for (int i = 0; i < n; i++) putchar('-');
        putchar('|');
    }
    putchar('\n');
}

static void print_border(int widths[]) {
    putchar('+');
    for (int c = 0; c < HEADER_COUNT; c++) {
        int n = widths[c] + 2;
        for (int i = 0; i < n; i++) putchar('-');
        putchar('+');
    }
    putchar('\n');
}

static void print_header(int widths[]) {
    putchar('|');
    for (int c = 0; c < HEADER_COUNT; c++) {
        putchar(' ');
        center_print(headers[c], widths[c]);
        printf(" |");
    }
    putchar('\n');
}

static void print_row(const char *cols[], int widths[]) {
    putchar('|');
    for (int c = 0; c < HEADER_COUNT; c++) {
        printf(" %-*s |", widths[c], cols[c]);
    }
    putchar('\n');
}

static void render(Vec *v, bool markdown) {
    int widths[HEADER_COUNT];
    for (int i = 0; i < HEADER_COUNT; i++) widths[i] = (int)strlen(headers[i]);
    for (size_t i = 0; i < v->len; i++) {
        Module *m = &v->items[i];
        const char *cols[HEADER_COUNT] = {m->path, m->version, m->update_version, m->indirect ? "false" : "true", m->valid_ts ? "true" : "false"};
        for (int c = 0; c < HEADER_COUNT; c++) {
            int l = (int)strlen(cols[c]);
            if (l > widths[c]) widths[c] = l;
        }
    }
    if (!markdown) print_border(widths);
    print_header(widths);
    if (markdown) print_sep(widths); else print_border(widths);
    for (size_t i = 0; i < v->len; i++) {
        Module *m = &v->items[i];
        const char *cols[HEADER_COUNT] = {m->path, m->version, m->update_version, m->indirect ? "false" : "true", m->valid_ts ? "true" : "false"};
        print_row(cols, widths);
    }
    if (!markdown) print_border(widths);
}

static void usage(FILE *f, const char *argv0) {
    fprintf(f, "Usage of %s:\n", argv0);
    fprintf(f, "  -ci\n\tNon-zero exit code when at least one outdated dependency was found\n");
    fprintf(f, "  -direct\n\tList only direct modules\n");
    fprintf(f, "  -style string\n\tOutput style, pass 'markdown' for a Markdown table (default \"default\")\n");
    fprintf(f, "  -update\n\tList only modules with updates\n");
}

int main(int argc, char **argv) {
    bool ci = false, direct = false, update = false;
    const char *style = "default";
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-ci") == 0) ci = true;
        else if (strcmp(argv[i], "-direct") == 0) direct = true;
        else if (strcmp(argv[i], "-update") == 0) update = true;
        else if (strcmp(argv[i], "-style") == 0) {
            if (i + 1 >= argc) { fprintf(stderr, "flag needs an argument: -style\n"); usage(stderr, argv[0]); return 2; }
            style = argv[++i];
        } else if (strncmp(argv[i], "-style=", 7) == 0) style = argv[i] + 7;
        else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-help") == 0) { usage(stdout, argv[0]); return 0; }
        else { fprintf(stderr, "flag provided but not defined: %s\n", argv[i]); usage(stderr, argv[0]); return 2; }
    }

    char *buf = read_all_stdin();
    const char *p = buf;
    Vec out = {0};
    int outdated_visible = 0;
    for (;;) {
        skip_ws(&p);
        if (!*p) break;
        Module m = parse_module(&p);
        compute_valid(&m);
        bool is_direct = !m.indirect;
        bool is_updated = m.has_update;
        bool keep = true;
        if (direct && !is_direct) keep = false;
        if (update && !is_updated) keep = false;
        if (keep) {
            if (is_updated) outdated_visible = 1;
            vec_push(&out, m);
        }
    }
    if (out.len > 0) render(&out, strcmp(style, "markdown") == 0);
    free(buf);
    return (ci && outdated_visible) ? 1 : 0;
}
