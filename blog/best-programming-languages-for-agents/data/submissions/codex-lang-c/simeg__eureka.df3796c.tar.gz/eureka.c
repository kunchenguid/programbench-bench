#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static const char *green_bold = "\033[0m\033[1m\033[32m";
static const char *yellow = "\033[0m\033[33m";
static const char *reset = "\033[0m";

static const char *home_dir(void) {
    const char *h = getenv("HOME");
    return h && *h ? h : ".";
}

static void mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    size_t n = strlen(path);
    if (n >= sizeof(tmp)) return;
    strcpy(tmp, path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    mkdir(tmp, 0777);
}

static void config_path(char *out, size_t n) {
    snprintf(out, n, "%s/.config/eureka/config.json", home_dir());
}

static void cache_init(void) {
    char p[PATH_MAX];
    snprintf(p, sizeof(p), "%s/.cache/rosetta", home_dir());
    mkdir_p(p);
}

static void error_msg(const char *msg) {
    fflush(stdout);
    fprintf(stderr, " ERROR eureka > %s\n", msg);
}

static char *read_line_alloc(FILE *f) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t got = getline(&line, &cap, f);
    if (got < 0) {
        free(line);
        return strdup("");
    }
    while (got > 0 && (line[got - 1] == '\n' || line[got - 1] == '\r')) {
        line[--got] = 0;
    }
    return line;
}

static void first_time_setup(void) {
    char cpath[PATH_MAX], cdir[PATH_MAX];
    config_path(cpath, sizeof(cpath));
    snprintf(cdir, sizeof(cdir), "%s/.config/eureka", home_dir());
    mkdir_p(cdir);
    cache_init();

    printf("%s############################################################\n", yellow);
    printf("####                  First Time Setup                  ####\n");
    printf("############################################################\n\n");
    printf("This tool requires you to have a repository with a README.md\n");
    printf("in the root folder. The markdown file is where your ideas\n");
    printf("will be stored.\n\n");
    printf("Once first time setup has completed, simply run Eureka again\n");
    printf("to begin writing down ideas.\n        \n%s", reset);

    printf("%sAbsolute path to your idea repo\n%s> ", green_bold, reset);
    fflush(stdout);
    char *repo = read_line_alloc(stdin);

    FILE *fp = fopen(cpath, "w");
    if (!fp) {
        error_msg(strerror(errno));
        free(repo);
        return;
    }
    fputs("{\"repo\":\"", fp);
    for (char *p = repo; *p; p++) {
        if (*p == '\\' || *p == '"') fputc('\\', fp);
        fputc(*p, fp);
    }
    fputs("\"}", fp);
    fclose(fp);
    printf("First time setup complete. Happy ideation!\n");
    free(repo);
}

static int read_config(char *repo, size_t n) {
    char cpath[PATH_MAX];
    config_path(cpath, sizeof(cpath));
    FILE *fp = fopen(cpath, "r");
    if (!fp) {
        cache_init();
        error_msg("No such file or directory (os error 2)");
        return 0;
    }
    char buf[8192];
    size_t len = fread(buf, 1, sizeof(buf) - 1, fp);
    fclose(fp);
    buf[len] = 0;
    char *key = strstr(buf, "\"repo\"");
    if (!key) {
        error_msg("key must be a string at line 1 column 2");
        return 0;
    }
    char *colon = strchr(key, ':');
    char *q = colon ? strchr(colon, '"') : NULL;
    if (!q) {
        error_msg("key must be a string at line 1 column 2");
        return 0;
    }
    q++;
    size_t o = 0;
    while (*q && *q != '"' && o + 1 < n) {
        if (*q == '\\' && q[1]) q++;
        repo[o++] = *q++;
    }
    repo[o] = 0;
    return 1;
}

static int shell_quote(const char *s, char *out, size_t n) {
    size_t o = 0;
    if (o + 1 >= n) return 0;
    out[o++] = '\'';
    for (; *s; s++) {
        if (*s == '\'') {
            if (o + 4 >= n) return 0;
            memcpy(out + o, "'\\''", 4);
            o += 4;
        } else {
            if (o + 1 >= n) return 0;
            out[o++] = *s;
        }
    }
    if (o + 2 > n) return 0;
    out[o++] = '\'';
    out[o] = 0;
    return 1;
}

static int run_quiet(const char *cmd) {
    int rc = system(cmd);
    if (rc == -1) return -1;
    if (WIFEXITED(rc)) return WEXITSTATUS(rc);
    return 1;
}

static void run_ignore(const char *cmd) {
    int ignored = system(cmd);
    (void)ignored;
}

static void capture_idea(void) {
    char repo[PATH_MAX], qrepo[PATH_MAX * 2], readme[PATH_MAX * 2], qreadme[PATH_MAX * 3];
    if (!read_config(repo, sizeof(repo))) return;

    printf("%s>> Idea summary\n%s> ", green_bold, reset);
    fflush(stdout);
    char *summary = read_line_alloc(stdin);
    while (summary[0] == 0) {
        free(summary);
        printf("%s>> Idea summary\n%s> ", green_bold, reset);
        fflush(stdout);
        summary = read_line_alloc(stdin);
    }

    snprintf(readme, sizeof(readme), "%s/README.md", repo);
    shell_quote(repo, qrepo, sizeof(qrepo));
    shell_quote(readme, qreadme, sizeof(qreadme));

    const char *editor = getenv("EDITOR");
    if (!editor || !*editor) editor = "vi";
    char cmd[PATH_MAX * 5];
    snprintf(cmd, sizeof(cmd), "%s %s", editor, qreadme);
    run_ignore(cmd);

    printf("Adding and committing your new idea to main..\n");
    snprintf(cmd, sizeof(cmd), "git -C %s branch main >/dev/null 2>&1 || true", qrepo);
    run_quiet(cmd);
    snprintf(cmd, sizeof(cmd), "git -C %s checkout main >/dev/null 2>&1 || git -C %s checkout -B main >/dev/null 2>&1", qrepo, qrepo);
    run_quiet(cmd);
    snprintf(cmd, sizeof(cmd), "git -C %s add README.md >/dev/null 2>&1", qrepo);
    run_quiet(cmd);

    char qsummary[8192];
    shell_quote(summary, qsummary, sizeof(qsummary));
    snprintf(cmd, sizeof(cmd), "git -C %s commit -m %s >/dev/null 2>&1", qrepo, qsummary);
    int crc = run_quiet(cmd);
    if (crc == 0) {
        printf("Added and committed!\n");
    } else {
        error_msg("nothing to commit, working tree clean");
        free(summary);
        return;
    }
    printf("Pushing your new idea..\n");
    snprintf(cmd, sizeof(cmd), "git -C %s push origin main >/tmp/eureka_push_out 2>&1", qrepo);
    int prc = run_quiet(cmd);
    if (prc == 0) {
        printf("Pushed!\n");
    } else {
        error_msg("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)");
    }
    free(summary);
}

static void view_ideas(void) {
    char repo[PATH_MAX], readme[PATH_MAX * 2], qreadme[PATH_MAX * 3], cmd[PATH_MAX * 4];
    if (!read_config(repo, sizeof(repo))) return;
    snprintf(readme, sizeof(readme), "%s/README.md", repo);
    if (access(readme, R_OK) != 0) {
        error_msg("No such file or directory (os error 2)");
        return;
    }
    shell_quote(readme, qreadme, sizeof(qreadme));
    const char *pager = getenv("PAGER");
    if (!pager || !*pager) pager = "less";
    snprintf(cmd, sizeof(cmd), "%s %s", pager, qreadme);
    run_ignore(cmd);
}

static void clear_config(void) {
    char cpath[PATH_MAX];
    config_path(cpath, sizeof(cpath));
    unlink(cpath);
    cache_init();
}

static void help(void) {
    puts("Input and store your ideas without leaving the terminal\n");
    puts("Usage: executable [OPTIONS]\n");
    puts("Options:");
    puts("      --clear-config  Clear your stored configuration");
    puts("  -v, --view          View ideas with your $PAGER env variable. If unset use less");
    puts("  -h, --help          Print help");
    puts("  -V, --version       Print version");
}

static void unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
}

int main(int argc, char **argv) {
    int view = 0, clear = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) {
            help();
            return 0;
        } else if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) {
            puts("eureka 2.0.0");
            return 0;
        } else if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--view")) {
            view = 1;
        } else if (!strcmp(argv[i], "--clear-config")) {
            clear = 1;
        } else {
            unexpected(argv[i]);
            return 2;
        }
    }
    if (view) {
        view_ideas();
    } else if (clear) {
        clear_config();
    } else {
        char cpath[PATH_MAX];
        config_path(cpath, sizeof(cpath));
        if (access(cpath, R_OK) != 0) first_time_setup();
        else capture_idea();
    }
    return 0;
}
