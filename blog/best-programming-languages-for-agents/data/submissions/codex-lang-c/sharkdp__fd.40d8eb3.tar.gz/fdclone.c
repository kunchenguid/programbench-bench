#define _GNU_SOURCE
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <fnmatch.h>
#include <grp.h>
#include <pwd.h>
#include <regex.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct { char **v; size_t n, cap; } StrVec;
typedef struct { char *path; char *out; struct stat st; int is_dir; int is_link; } Result;
typedef struct { Result *v; size_t n, cap; } ResVec;

typedef struct {
    int hidden, no_ignore, case_sensitive, ignore_case, glob, fixed, absolute, follow;
    int full_path, print0, quiet, show_errors, prune, list_details;
    int min_depth, max_depth, exact_depth, max_results, strip_mode;
    char sep;
    char *pattern, *format, *base_dir;
    StrVec ands, paths, search_paths, exts, excludes, ignore_contain, ignore_files;
    StrVec exec_cmd, batch_cmd;
    int do_exec, do_batch;
    int type_file, type_dir, type_link, type_exec, type_empty, type_socket, type_pipe, type_block, type_char;
    int any_type;
    int size_mode; long long size_value;
    int newer_set, older_set; time_t newer, older;
    int owner_user_set, owner_group_set, owner_user_neg, owner_group_neg; uid_t owner_uid; gid_t owner_gid;
    int implicit_path;
} Options;

static void sv_push(StrVec *s, const char *x){ if(s->n==s->cap){s->cap=s->cap? s->cap*2:8; s->v=realloc(s->v,s->cap*sizeof(char*));} s->v[s->n++]=strdup(x); }
static void rv_push(ResVec *r, Result x){ if(r->n==r->cap){r->cap=r->cap? r->cap*2:64; r->v=realloc(r->v,r->cap*sizeof(Result));} r->v[r->n++]=x; }
static int has_upper(const char *s){ for(;*s;s++) if(*s>='A'&&*s<='Z') return 1; return 0; }
static const char *base_name(const char *p){ const char *s=strrchr(p,'/'); return s? s+1:p; }
static char *xasprintf(const char *fmt, const char *a, const char *b){ char *r=NULL; if(asprintf(&r,fmt,a,b)<0) exit(2); return r; }
static char *join_path(const char *a,const char*b){ if(!a||!*a) return strdup(b); size_t l=strlen(a); if(l&&a[l-1]=='/') return xasprintf("%s%s",a,b); return xasprintf("%s/%s",a,b); }
static int is_hidden_name(const char *n){ return n[0]=='.' && strcmp(n,".") && strcmp(n,".."); }
static char *lower_dup(const char *s){ char *r=strdup(s); for(char*p=r;*p;p++) if(*p>='A'&&*p<='Z') *p+=32; return r; }

static char *path_parent(const char *p){
    char *r=strdup(p); char *s=strrchr(r,'/');
    if(!s){ strcpy(r,"."); return r; }
    if(s==r){ s[1]=0; return r; }
    *s=0; return r;
}
static char *path_no_ext(const char *p){
    char *r=strdup(p); char *b=(char*)base_name(r); char *dot=strrchr(b,'.');
    if(dot && dot!=b) *dot=0; return r;
}
static char *basename_no_ext(const char *p){ char *r=strdup(base_name(p)); char *dot=strrchr(r,'.'); if(dot&&dot!=r)*dot=0; return r; }

static char *replace_placeholders(const char *tmpl, const char *path){
    size_t cap=strlen(tmpl)+strlen(path)+64, n=0; char *out=malloc(cap); out[0]=0;
    for(size_t i=0; tmpl[i]; ){
        char *rep=NULL; size_t adv=1;
        if(!strncmp(tmpl+i,"{{",2)){ rep=strdup("{"); adv=2; }
        else if(!strncmp(tmpl+i,"}}",2)){ rep=strdup("}"); adv=2; }
        else if(!strncmp(tmpl+i,"{//}",4)){ rep=path_parent(path); adv=4; }
        else if(!strncmp(tmpl+i,"{/.}",4)){ rep=basename_no_ext(path); adv=4; }
        else if(!strncmp(tmpl+i,"{/}",3)){ rep=strdup(base_name(path)); adv=3; }
        else if(!strncmp(tmpl+i,"{.}",3)){ rep=path_no_ext(path); adv=3; }
        else if(!strncmp(tmpl+i,"{}",2)){ rep=strdup(path); adv=2; }
        else { char tmp[2]={tmpl[i],0}; rep=strdup(tmp); adv=1; }
        size_t rl=strlen(rep); if(n+rl+1>cap){ while(n+rl+1>cap) cap*=2; out=realloc(out,cap); }
        memcpy(out+n,rep,rl); n+=rl; out[n]=0; free(rep); i+=adv;
    }
    return out;
}
static int has_placeholder(StrVec *cmd){ for(size_t i=0;i<cmd->n;i++) if(strstr(cmd->v[i],"{}")||strstr(cmd->v[i],"{/}")||strstr(cmd->v[i],"{//}")||strstr(cmd->v[i],"{.}")||strstr(cmd->v[i],"{/.}")) return 1; return 0; }

static long long parse_size_num(const char *s, int *mode){
    *mode=0; if(*s=='+'){*mode=1;s++;} else if(*s=='-'){*mode=-1;s++;}
    char *end; double v=strtod(s,&end); char unit[8]={0}; for(int i=0; end[i]&&i<7; i++){ unit[i]=end[i]; if(unit[i]>='A'&&unit[i]<='Z') unit[i]+=32; }
    double mul=1; if(!strcmp(unit,"k"))mul=1000; else if(!strcmp(unit,"m"))mul=1000000; else if(!strcmp(unit,"g"))mul=1000000000.0; else if(!strcmp(unit,"t"))mul=1000000000000.0;
    else if(!strcmp(unit,"ki"))mul=1024; else if(!strcmp(unit,"mi"))mul=1048576; else if(!strcmp(unit,"gi"))mul=1073741824.0; else if(!strcmp(unit,"ti"))mul=1099511627776.0;
    return (long long)(v*mul);
}
static time_t parse_time_arg(const char *s){
    if(s[0]=='@') return (time_t)atoll(s+1);
    char *end; long v=strtol(s,&end,10);
    if(end>s && *end){
        long mul=1; if(!strncmp(end,"min",3))mul=60; else if(*end=='h')mul=3600; else if(*end=='d')mul=86400; else if(!strncmp(end,"week",4)||*end=='w')mul=604800; else if(*end=='s')mul=1;
        return time(NULL)-v*mul;
    }
    struct tm tm={0}; char *r=strptime(s,"%Y-%m-%d %H:%M:%S",&tm); if(!r) r=strptime(s,"%Y-%m-%d",&tm); if(r) return mktime(&tm);
    return time(NULL)-v;
}
static int parse_owner(Options *o, const char *s){
    char *tmp=strdup(s), *colon=strchr(tmp,':'); char *u=tmp, *g=NULL; if(colon){*colon=0; g=colon+1;}
    if(*u){ if(*u=='!'){o->owner_user_neg=1; u++;} struct passwd *pw=getpwnam(u); o->owner_uid=pw?pw->pw_uid:(uid_t)atoi(u); o->owner_user_set=1; }
    if(g&&*g){ if(*g=='!'){o->owner_group_neg=1; g++;} struct group *gr=getgrnam(g); o->owner_gid=gr?gr->gr_gid:(gid_t)atoi(g); o->owner_group_set=1; }
    free(tmp); return 0;
}

static int pattern_match_one(Options *o, const char *pat, const char *text){
    if(!pat || !*pat) return 1;
    if(o->fixed){
        if(o->case_sensitive) return strstr(text,pat)!=NULL;
        char *a=lower_dup(text), *b=lower_dup(pat); int ok=strstr(a,b)!=NULL; free(a); free(b); return ok;
    }
    if(o->glob){
        int flags=FNM_PATHNAME; if(!o->case_sensitive) flags|=FNM_CASEFOLD;
        if(fnmatch(pat,text,flags)==0) return 1;
        if(!strchr(pat,'*')&&!strchr(pat,'?')&&!strchr(pat,'[')){
            char *wrap=xasprintf("*%s*",pat,""); int ok=fnmatch(wrap,text,flags)==0; free(wrap); return ok;
        }
        return 0;
    }
    regex_t re; int flags=REG_EXTENDED|REG_NOSUB; if(!o->case_sensitive) flags|=REG_ICASE;
    if(regcomp(&re,pat,flags)!=0) return 0; int ok=regexec(&re,text,0,NULL,0)==0; regfree(&re); return ok;
}

static int ignored_by_patterns(StrVec *pats, const char *name, const char *rel){
    for(size_t i=0;i<pats->n;i++){
        const char *p=pats->v[i]; if(!*p || *p=='#') continue;
        int neg=0; if(*p=='!'){ neg=1; p++; }
        char *q=strdup(p); size_t l=strlen(q); while(l&& (q[l-1]=='\n'||q[l-1]=='\r')) q[--l]=0; if(!l){free(q); continue;}
        int m=0; if(strchr(q,'/')) m=fnmatch(q,rel,0)==0; else m=fnmatch(q,name,0)==0;
        if(!m && q[l-1]=='/') { q[l-1]=0; m=!strcmp(q,name)||!strcmp(q,rel); }
        if(m){ free(q); return neg?0:1; } free(q);
    }
    return 0;
}
static void load_ignore_file(StrVec *dest, const char *path){
    FILE *f=fopen(path,"r"); if(!f) return; char *line=NULL; size_t n=0;
    while(getline(&line,&n,f)>0){ size_t l=strlen(line); while(l&&(line[l-1]=='\n'||line[l-1]=='\r')) line[--l]=0; if(l) sv_push(dest,line); }
    free(line); fclose(f);
}

static int result_cmp(const void *A,const void*B){ const Result*a=A,*b=B; return strcmp(a->out,b->out); }
static int name_cmp(const void*A,const void*B){ const char*const*a=A,*const*b=B; return strcmp(*a,*b); }

static int is_empty_dir(const char *p){
    DIR*d=opendir(p); if(!d) return 0; struct dirent*e; int empty=1; while((e=readdir(d))){ if(strcmp(e->d_name,".")&&strcmp(e->d_name,"..")){empty=0;break;}} closedir(d); return empty;
}
static int type_ok(Options *o, const char *path, struct stat *st, int is_link){
    if(!o->any_type && !o->type_exec && !o->type_empty) return 1;
    int ok=0;
    if(o->type_file && S_ISREG(st->st_mode)) ok=1;
    if(o->type_dir && S_ISDIR(st->st_mode)) ok=1;
    if(o->type_link && is_link) ok=1;
    if(o->type_socket && S_ISSOCK(st->st_mode)) ok=1;
    if(o->type_pipe && S_ISFIFO(st->st_mode)) ok=1;
    if(o->type_block && S_ISBLK(st->st_mode)) ok=1;
    if(o->type_char && S_ISCHR(st->st_mode)) ok=1;
    if(o->type_exec && S_ISREG(st->st_mode) && (st->st_mode&0111)) ok=1;
    if(o->type_empty){
        int emp=(S_ISREG(st->st_mode)&&st->st_size==0);
        if(S_ISDIR(st->st_mode)) emp=is_empty_dir(path);
        if(!o->any_type && emp) ok=1; else if(emp && ok) ok=1; else if(o->any_type && !emp) ok=0;
    }
    return ok;
}
static int ext_ok(Options *o, const char *name){
    if(!o->exts.n) return 1; const char *dot=strrchr(name,'.'); if(!dot||dot==name) return 0; dot++;
    for(size_t i=0;i<o->exts.n;i++) if(!strcasecmp(dot,o->exts.v[i])) return 1; return 0;
}
static int filters_ok(Options *o, const char *match_text, const char *name, const char *path, struct stat *st, int is_link, int depth){
    if(o->min_depth>=0 && depth<o->min_depth) return 0; if(o->max_depth>=0 && depth>o->max_depth) return 0;
    if(!pattern_match_one(o,o->pattern,match_text)) return 0;
    for(size_t i=0;i<o->ands.n;i++) if(!pattern_match_one(o,o->ands.v[i],match_text)) return 0;
    if(!ext_ok(o,name)) return 0; if(!type_ok(o,path,st,is_link)) return 0;
    if(o->size_mode){ if(o->size_mode>0 && st->st_size<o->size_value) return 0; if(o->size_mode<0 && st->st_size>o->size_value) return 0; if(o->size_mode==2 && st->st_size!=o->size_value) return 0; }
    if(o->newer_set && st->st_mtime<=o->newer) return 0; if(o->older_set && st->st_mtime>=o->older) return 0;
    if(o->owner_user_set){ int m=(st->st_uid==o->owner_uid); if(o->owner_user_neg?m:!m) return 0; }
    if(o->owner_group_set){ int m=(st->st_gid==o->owner_gid); if(o->owner_group_neg?m:!m) return 0; }
    (void)path; return 1;
}

static void traverse(Options *o, const char *fs, const char *out, int depth, ResVec *res, StrVec ignores){
    DIR *dir=opendir(fs); if(!dir){ if(o->show_errors) fprintf(stderr,"[fd error]: %s: %s\n",fs,strerror(errno)); return; }
    StrVec local=ignores; if(!o->no_ignore){ char *ig=join_path(fs,".gitignore"); load_ignore_file(&local,ig); free(ig); ig=join_path(fs,".ignore"); load_ignore_file(&local,ig); free(ig); ig=join_path(fs,".fdignore"); load_ignore_file(&local,ig); free(ig); }
    char **names=NULL; size_t n=0,cap=0; struct dirent *e;
    while((e=readdir(dir))){ if(!strcmp(e->d_name,".")||!strcmp(e->d_name,"..")) continue; if(n==cap){cap=cap?cap*2:64; names=realloc(names,cap*sizeof(char*));} names[n++]=strdup(e->d_name); }
    closedir(dir); qsort(names,n,sizeof(char*),name_cmp);
    for(size_t i=0;i<n;i++){
        char *name=names[i]; char *child=join_path(fs,name); char *child_out=join_path(out,name);
        struct stat st,lst; if(lstat(child,&lst)!=0){ free(child); free(child_out); free(name); continue; }
        int is_link=S_ISLNK(lst.st_mode); if((o->follow?stat(child,&st):lstat(child,&st))!=0) st=lst;
        int is_dir=S_ISDIR(st.st_mode);
        if(ignored_by_patterns(&o->excludes,name,child_out)){ free(child); free(child_out); free(name); continue; }
        if(!o->hidden && is_hidden_name(name)){ free(child); free(child_out); free(name); continue; }
        if(!o->no_ignore && ignored_by_patterns(&local,name,child_out)){ free(child); free(child_out); free(name); continue; }
        int contain=0; if(is_dir){ for(size_t k=0;k<o->ignore_contain.n;k++){ char *p=join_path(child,o->ignore_contain.v[k]); if(access(p,F_OK)==0) contain=1; free(p);} }
        if(contain){ free(child); free(child_out); free(name); continue; }
        const char *mt=o->full_path? child : name;
        for(char *p=child_out; *p; p++) if(o->sep!='/' && *p=='/') *p=o->sep;
        int match=filters_ok(o,mt,name,child,&st,is_link,depth);
        if(match){
            char absbuf[4096]; char *final_out=child_out;
            if(o->absolute){ if(realpath(child,absbuf)) final_out=absbuf; }
            rv_push(res,(Result){strdup(child),strdup(final_out),st,is_dir,is_link});
            if(o->max_results>0 && (int)res->n>=o->max_results){ free(child); free(child_out); free(name); for(size_t j=i+1;j<n;j++) free(names[j]); free(names); return; }
        }
        if(is_dir && (o->max_depth<0 || depth<o->max_depth) && !(o->prune && match)) traverse(o,child,child_out,depth+1,res,local);
        free(child); free(child_out); free(name);
        if(o->max_results>0 && (int)res->n>=o->max_results){ for(size_t j=i+1;j<n;j++) free(names[j]); free(names); return; }
    }
    free(names);
}

static void print_help(int longh){
    printf("A program to find entries in your filesystem\n\nUsage: executable [OPTIONS] [pattern] [path]...\n\n");
    if(!longh){ printf("Arguments:\n  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)\n  [path]...  the root directories for the filesystem search (optional)\n\nOptions:\n  -H, --hidden                     Search hidden files and directories\n  -I, --no-ignore                  Do not respect .(git|fd)ignore files\n  -s, --case-sensitive             Case-sensitive search (default: smart case)\n  -i, --ignore-case                Case-insensitive search (default: smart case)\n  -g, --glob                       Glob-based search (default: regular expression)\n  -a, --absolute-path              Show absolute instead of relative paths\n  -l, --list-details               Use a long listing format with file metadata\n  -L, --follow                     Follow symbolic links\n  -p, --full-path                  Search full abs. path (default: filename only)\n  -d, --max-depth <depth>          Set maximum search depth (default: none)\n  -E, --exclude <pattern>          Exclude entries that match the given glob pattern\n  -t, --type <filetype>            Filter by type\n  -e, --extension <ext>            Filter by file extension\n  -x, --exec <cmd>...              Execute a command for each search result\n  -X, --exec-batch <cmd>...        Execute a command with all search results at once\n  -h, --help                       Print help (see more with '--help')\n  -V, --version                    Print version\n"); }
    else { printf("Arguments:\n  [pattern]\n          the search pattern which is either a regular expression (default) or a glob pattern (if\n          --glob is used).\n\n  [path]...\n          The directory where the filesystem search is rooted (optional).\n\nOptions:\n  -H, --hidden\n          Include hidden directories and files in the search results\n  -I, --no-ignore\n          Show search results from ignored files and directories\n  -u, --unrestricted...\n          Perform an unrestricted search, including ignored and hidden files.\n  -s, --case-sensitive\n  -i, --ignore-case\n  -g, --glob\n      --regex\n  -F, --fixed-strings\n      --and <pattern>\n  -a, --absolute-path\n  -l, --list-details\n  -L, --follow\n  -p, --full-path\n  -0, --print0\n  -d, --max-depth <depth>\n      --min-depth <depth>\n      --exact-depth <depth>\n  -E, --exclude <pattern>\n      --prune\n  -t, --type <filetype>\n  -e, --extension <ext>\n  -S, --size <size>\n      --changed-within <date|dur>\n      --changed-before <date|dur>\n  -o, --owner <user:group>\n      --format <fmt>\n  -x, --exec <cmd>...\n  -X, --exec-batch <cmd>...\n  -c, --color <when>\n      --hyperlink[=<when>]\n      --ignore-contain <name>\n  -j, --threads <num>\n      --max-results <count>\n  -1\n  -q, --quiet\n      --show-errors\n  -C, --base-directory <path>\n      --path-separator <separator>\n      --search-path <search-path>\n  -h, --help\n  -V, --version\n\nBugs can be reported on GitHub: https://github.com/sharkdp/fd/issues\n"); }
}
static void set_type(Options*o,const char*t){ o->any_type=1; if(!strcmp(t,"f")||!strcmp(t,"file"))o->type_file=1; else if(!strcmp(t,"d")||!strcmp(t,"dir")||!strcmp(t,"directory"))o->type_dir=1; else if(!strcmp(t,"l")||!strcmp(t,"symlink"))o->type_link=1; else if(!strcmp(t,"x")||!strcmp(t,"executable"))o->type_exec=1; else if(!strcmp(t,"e")||!strcmp(t,"empty"))o->type_empty=1; else if(!strcmp(t,"s")||!strcmp(t,"socket"))o->type_socket=1; else if(!strcmp(t,"p")||!strcmp(t,"pipe"))o->type_pipe=1; else if(!strcmp(t,"b")||!strcmp(t,"block-device"))o->type_block=1; else if(!strcmp(t,"c")||!strcmp(t,"char-device"))o->type_char=1; }

static void run_command(StrVec *cmd, const char *path){
    int hp=has_placeholder(cmd); size_t argc=cmd->n + (hp?0:1); char **argv=calloc(argc+1,sizeof(char*)); size_t n=0;
    for(size_t i=0;i<cmd->n;i++) argv[n++]=replace_placeholders(cmd->v[i],path);
    if(!hp) argv[n++]=strdup(path); argv[n]=NULL;
    pid_t pid=fork(); if(pid==0){ execvp(argv[0],argv); perror(argv[0]); _exit(127); }
    int st; waitpid(pid,&st,0); for(size_t i=0;i<n;i++) free(argv[i]); free(argv);
}
static void run_batch(StrVec *cmd, ResVec *res){
    if(!cmd->n) return; int hp=has_placeholder(cmd); size_t argc=cmd->n + (hp?0:res->n); char **argv=calloc(argc+1,sizeof(char*)); size_t n=0;
    for(size_t i=0;i<cmd->n;i++) argv[n++]=strdup(cmd->v[i]);
    if(!hp) for(size_t i=0;i<res->n;i++) argv[n++]=strdup(res->v[i].out); argv[n]=NULL;
    pid_t pid=fork(); if(pid==0){ execvp(argv[0],argv); perror(argv[0]); _exit(127); }
    int st; waitpid(pid,&st,0); for(size_t i=0;i<n;i++) free(argv[i]); free(argv);
}
static char *safe_rel(const char *s){
    if(s[0]=='/' || !strncmp(s,"./",2) || !strncmp(s,"../",3)) return strdup(s);
    return xasprintf("./%s",s,"");
}

int main(int argc, char **argv){
    Options o={0}; o.max_depth=-1; o.min_depth=-1; o.sep='/'; o.strip_mode=0; StrVec positionals={0};
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--")){ for(i++;i<argc;i++) sv_push(&positionals,argv[i]); break; }
        else if(!strcmp(a,"-h")){ print_help(0); return 0; } else if(!strcmp(a,"--help")){ print_help(1); return 0; } else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("fd 10.3.0"); return 0; }
        else if(!strcmp(a,"-x")||!strcmp(a,"--exec")||!strcmp(a,"-X")||!strcmp(a,"--exec-batch")){
            int batch=a[1]=='X'||strstr(a,"batch"); if(batch)o.do_batch=1; else o.do_exec=1; StrVec *cv=batch?&o.batch_cmd:&o.exec_cmd;
            while(++i<argc && strcmp(argv[i],";")) sv_push(cv,argv[i]); break;
        } else if(a[0]=='-' && a[1]){
            #define NEED() (i+1<argc?argv[++i]:(fprintf(stderr,"error: a value is required for '%s'\n",a),exit(2),(char*)0))
            if(!strcmp(a,"--hidden")||!strcmp(a,"--no-hidden")) o.hidden=strcmp(a,"--no-hidden")!=0;
            else if(!strcmp(a,"--no-ignore")||!strcmp(a,"--ignore")) o.no_ignore=strcmp(a,"--ignore")!=0;
            else if(!strcmp(a,"--no-ignore-vcs")||!strcmp(a,"--no-require-git")||!strcmp(a,"--no-ignore-parent")) {}
            else if(!strcmp(a,"--case-sensitive")) o.case_sensitive=1;
            else if(!strcmp(a,"--ignore-case")) o.ignore_case=1;
            else if(!strcmp(a,"--glob")) o.glob=1; else if(!strcmp(a,"--regex")) o.glob=0;
            else if(!strcmp(a,"--fixed-strings")) o.fixed=1;
            else if(!strcmp(a,"--absolute-path")) o.absolute=1; else if(!strcmp(a,"--relative-path")) o.absolute=0;
            else if(!strcmp(a,"--follow")) o.follow=1; else if(!strcmp(a,"--no-follow")) o.follow=0;
            else if(!strcmp(a,"--full-path")) o.full_path=1; else if(!strcmp(a,"--print0")) o.print0=1;
            else if(!strcmp(a,"--quiet")||!strcmp(a,"--has-results")) o.quiet=1; else if(!strcmp(a,"--show-errors")) o.show_errors=1;
            else if(!strcmp(a,"--prune")) o.prune=1; else if(!strcmp(a,"--list-details")) o.list_details=1;
            else if(!strcmp(a,"--max-depth")) o.max_depth=atoi(NEED()); else if(!strcmp(a,"--min-depth")) o.min_depth=atoi(NEED());
            else if(!strcmp(a,"--exact-depth")){ o.min_depth=o.max_depth=atoi(NEED()); }
            else if(!strcmp(a,"--max-results")) o.max_results=atoi(NEED());
            else if(!strcmp(a,"--extension")) sv_push(&o.exts,NEED()); else if(!strcmp(a,"--exclude")) sv_push(&o.excludes,NEED());
            else if(!strcmp(a,"--type")) set_type(&o,NEED()); else if(!strcmp(a,"--and")) sv_push(&o.ands,NEED());
            else if(!strcmp(a,"--size")){ int m; o.size_value=parse_size_num(NEED(),&m); o.size_mode=m?m:2; }
            else if(!strcmp(a,"--changed-within")||!strcmp(a,"--change-newer-than")||!strcmp(a,"--newer")||!strcmp(a,"--changed-after")){ o.newer=parse_time_arg(NEED()); o.newer_set=1; }
            else if(!strcmp(a,"--changed-before")||!strcmp(a,"--change-older-than")||!strcmp(a,"--older")){ o.older=parse_time_arg(NEED()); o.older_set=1; }
            else if(!strcmp(a,"--owner")) parse_owner(&o,NEED()); else if(!strcmp(a,"--format")) o.format=strdup(NEED());
            else if(!strcmp(a,"--base-directory")) o.base_dir=strdup(NEED()); else if(!strcmp(a,"--path-separator")) o.sep=*NEED();
            else if(!strcmp(a,"--search-path")) sv_push(&o.search_paths,NEED()); else if(!strcmp(a,"--ignore-contain")) sv_push(&o.ignore_contain,NEED());
            else if(!strcmp(a,"--ignore-file")) sv_push(&o.ignore_files,NEED()); else if(!strcmp(a,"--color")||!strcmp(a,"-c")||!strcmp(a,"--threads")||!strcmp(a,"-j")||!strcmp(a,"--batch-size")) { NEED(); }
            else if(!strncmp(a,"--",2) && strchr(a,'=')){
                char *eq=strchr(a,'='); char key[128]; snprintf(key,sizeof(key),"%.*s",(int)(eq-a),a); char *val=eq+1;
                if(!strcmp(key,"--max-depth")) o.max_depth=atoi(val); else if(!strcmp(key,"--min-depth")) o.min_depth=atoi(val); else if(!strcmp(key,"--max-results")) o.max_results=atoi(val);
                else if(!strcmp(key,"--extension")) sv_push(&o.exts,val); else if(!strcmp(key,"--exclude")) sv_push(&o.excludes,val); else if(!strcmp(key,"--type")) set_type(&o,val);
                else if(!strcmp(key,"--format")) o.format=strdup(val); else if(!strcmp(key,"--search-path")) sv_push(&o.search_paths,val); else if(!strcmp(key,"--color")||!strcmp(key,"--hyperlink")||!strcmp(key,"--strip-cwd-prefix")) {}
            } else if(a[0]=='-' && a[1] && a[1]!='-'){
                for(size_t k=1;a[k];k++){ char c=a[k]; if(c=='H')o.hidden=1; else if(c=='I')o.no_ignore=1; else if(c=='u'){o.hidden=1;o.no_ignore=1;} else if(c=='s')o.case_sensitive=1; else if(c=='i')o.ignore_case=1; else if(c=='g')o.glob=1; else if(c=='F')o.fixed=1; else if(c=='a')o.absolute=1; else if(c=='L')o.follow=1; else if(c=='p')o.full_path=1; else if(c=='0')o.print0=1; else if(c=='q')o.quiet=1; else if(c=='l')o.list_details=1; else if(c=='1')o.max_results=1; else if(c=='d'){ o.max_depth=atoi(a[k+1]?a+k+1:NEED()); break;} else if(c=='e'){ sv_push(&o.exts,a[k+1]?a+k+1:NEED()); break;} else if(c=='E'){ sv_push(&o.excludes,a[k+1]?a+k+1:NEED()); break;} else if(c=='t'){ set_type(&o,a[k+1]?a+k+1:NEED()); break;} else if(c=='S'){ int m; o.size_value=parse_size_num(a[k+1]?a+k+1:NEED(),&m); o.size_mode=m?m:2; break;} }
            }
        } else sv_push(&positionals,a);
    }
    if(o.base_dir && chdir(o.base_dir)!=0){ perror(o.base_dir); return 1; }
    if(positionals.n){ o.pattern=strdup(positionals.v[0]); for(size_t i=1;i<positionals.n;i++) sv_push(&o.paths,positionals.v[i]); } else o.pattern=strdup("");
    if(o.search_paths.n){ for(size_t i=0;i<o.search_paths.n;i++) sv_push(&o.paths,o.search_paths.v[i]); }
    if(!o.paths.n){ sv_push(&o.paths,"."); o.implicit_path=1; }
    if(o.ignore_case) o.case_sensitive=0; else if(!o.case_sensitive) o.case_sensitive=has_upper(o.pattern); 
    for(size_t i=0;i<o.ands.n && !o.ignore_case && !o.case_sensitive;i++) if(has_upper(o.ands.v[i])) o.case_sensitive=1;
    StrVec ignores={0}; if(!o.no_ignore){ for(size_t i=0;i<o.ignore_files.n;i++) load_ignore_file(&ignores,o.ignore_files.v[i]); }
    ResVec res={0};
    for(size_t i=0;i<o.paths.n;i++){
        char *p=o.paths.v[i]; struct stat st; if((o.follow?stat(p,&st):lstat(p,&st))!=0) continue;
        char *out;
        if(!strcmp(p,".") && o.implicit_path) out=strdup("");
        else out=strdup(p);
        if(S_ISDIR(st.st_mode)) traverse(&o,p,out,1,&res,ignores);
        else {
            const char *name=base_name(p); const char *mt=o.full_path?p:name;
            if(filters_ok(&o,mt,name,p,&st,S_ISLNK(st.st_mode),1)) rv_push(&res,(Result){strdup(p),strdup(out),st,0,S_ISLNK(st.st_mode)});
        }
        free(out);
    }
    qsort(res.v,res.n,sizeof(Result),result_cmp);
    if(o.quiet) return res.n?0:1;
    if(o.list_details){ StrVec cmd={0}; sv_push(&cmd,"ls"); sv_push(&cmd,"-ld"); for(size_t i=0;i<res.n;i++){ char *p=safe_rel(res.v[i].out); run_command(&cmd,p); free(p);} return 0; }
    if(o.do_exec){ for(size_t i=0;i<res.n;i++){ char *p=safe_rel(res.v[i].out); run_command(&o.exec_cmd,p); free(p);} return 0; }
    if(o.do_batch){
        for(size_t i=0;i<res.n;i++){ char *p=safe_rel(res.v[i].out); free(res.v[i].out); res.v[i].out=p; }
        run_batch(&o.batch_cmd,&res); return 0;
    }
    for(size_t i=0;i<res.n;i++){
        char *print_path = o.print0 ? safe_rel(res.v[i].out) : strdup(res.v[i].out);
        char *s=o.format?replace_placeholders(o.format,print_path):strdup(print_path);
        if(res.v[i].is_dir && !o.format && !o.print0){ size_t l=strlen(s); if(!l||s[l-1]!='/'){ printf("%s/",s); } else printf("%s",s); putchar('\n'); }
        else { fputs(s,stdout); putchar(o.print0?'\0':'\n'); }
        free(s); free(print_path);
    }
    return 0;
}
