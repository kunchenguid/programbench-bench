#define _GNU_SOURCE
#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define RED "\033[31m"
#define YELLOW "\033[33m"
#define RESET "\033[0m"

static const char *prog = "executable";

static bool streq(const char *a, const char *b) { return strcmp(a, b) == 0; }

static bool arg_is_help(const char *s) { return streq(s, "-h") || streq(s, "--help"); }

static void print_top_help(void) {
    printf("tree-sitter 0.27.0\n");
    printf("Max Brunsfeld <maxbrunsfeld@gmail.com>\n");
    printf("Amaan Qureshi <amaanq12@gmail.com>\n");
    printf("Generates and tests parsers\n\n");
    printf("Usage: %s <COMMAND>\n\n", prog);
    printf("Commands:\n");
    printf("  init-config     Generate a default config file\n");
    printf("  init            Initialize a grammar repository\n");
    printf("  generate        Generate a parser\n");
    printf("  build           Compile a parser\n");
    printf("  parse           Parse files\n");
    printf("  test            Run a parser's tests\n");
    printf("  version         Display or increment the version of a grammar\n");
    printf("  fuzz            Fuzz a parser\n");
    printf("  query           Search files using a syntax tree query\n");
    printf("  highlight       Highlight a file\n");
    printf("  tags            Generate a list of tags\n");
    printf("  playground      Start local playground for a parser in the browser\n");
    printf("  dump-languages  Print info about all known language parsers\n");
    printf("  complete        Generate shell completions\n\n");
    printf("Options:\n");
    printf("  -h, --help     Print help\n");
    printf("  -V, --version  Print version\n");
}

static void print_help_for(const char *cmd) {
    if (streq(cmd, "init-config")) {
        printf("Generate a default config file\n\nUsage: %s init-config\n\nOptions:\n  -h, --help  Print help\n", prog);
    } else if (streq(cmd, "init")) {
        printf("Initialize a grammar repository\n\nUsage: %s init [OPTIONS]\n\nOptions:\n  -u, --update                       Update outdated files\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory\n  -h, --help                         Print help\n", prog);
    } else if (streq(cmd, "generate")) {
        printf("Generate a parser\n\nUsage: %s generate [OPTIONS] [GRAMMAR_PATH]\n\nArguments:\n  [GRAMMAR_PATH]  The path to the grammar file\n\nOptions:\n  -l, --log\n          Show debug log during generation\n      --abi <VERSION>\n          Select the language ABI version to generate (default 15).\n          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]\n      --no-parser\n          Only generate `grammar.json` and `node-types.json`\n  -b, --build\n          Deprecated: use the `build` command\n  -0, --debug-build\n          Deprecated: use the `build` command\n      --libdir <PATH>\n          Deprecated: use the `build` command\n  -o, --output <DIRECTORY>\n          The path to output the generated source files\n      --report-states-for-rule <REPORT_STATES_FOR_RULE>\n          Produce a report of the states for the given rule, use `-` to report every rule\n      --json\n          Deprecated: use --json-summary\n      --json-summary\n          Report conflicts in a JSON format\n      --js-runtime <EXECUTABLE>\n          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]\n      --disable-optimizations\n          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states\n  -h, --help\n          Print help\n", prog);
    } else if (streq(cmd, "build")) {
        printf("Compile a parser\n\nUsage: %s build [OPTIONS] [PATH]\n\nArguments:\n  [PATH]  The path to the grammar directory\n\nOptions:\n  -w, --wasm             Build a Wasm module instead of a dynamic library\n  -o, --output <OUTPUT>  The path to output the compiled file\n      --reuse-allocator  Make the parser reuse the same allocator as the library\n  -0, --debug            Compile a parser in debug mode\n  -v, --verbose          Display verbose build information\n  -h, --help             Print help\n", prog);
    } else if (streq(cmd, "parse")) {
        printf("Parse files\n\nUsage: %s parse [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --dot                          Output the parse data with graphviz dot\n  -x, --xml                          Output the parse data in XML format\n  -c, --cst                          Output the parse data in a pretty-printed CST format\n  -s, --stat                         Show parsing statistic\n      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --edits <EDITS>...             Apply edits in the format: \\\"row,col|position delcount insert_text\\\", can be supplied multiple times\n      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --json                         Deprecated: use --json-summary\n  -j, --json-summary                 Output parsing results in a JSON format\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n      --no-ranges                    Omit ranges in the output\n  -h, --help                         Print help\n", prog);
    } else if (streq(cmd, "test")) {
        printf("Run a parser's tests\n\nUsage: %s test [OPTIONS]\n\nOptions:\n  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex\n      --file-name <FILE_NAME>        Only run corpus test cases from a given filename\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n  -u, --update                       Update all syntax trees in corpus files with current parser output\n  -d, --debug                        Show parsing debug log\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n      --show-fields                  Force showing fields in test diffs\n      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]\n  -r, --rebuild                      Force rebuild the parser\n      --overview-only                Show only the pass-fail overview tree\n      --json-summary                 Output the test summary in a JSON format\n  -h, --help                         Print help\n", prog);
    } else if (streq(cmd, "version")) {
        printf("Display or increment the version of a grammar\n\nUsage: %s version [OPTIONS] [VERSION]\n\nArguments:\n  [VERSION]\n          The version to bump to\n          \n          Examples:\n              tree-sitter version: display the current version\n              tree-sitter version <version>: bump to specified version\n              tree-sitter version --bump <level>: automatic bump\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory\n\n      --bump <BUMP>\n          Automatically bump from the current version\n          \n          [possible values: patch, minor, major]\n\n  -h, --help\n          Print help (see a summary with '-h')\n", prog);
    } else if (streq(cmd, "fuzz")) {
        printf("Fuzz a parser\n\nUsage: %s fuzz [OPTIONS]\n\nOptions:\n  -s, --skip <SKIP>                  List of test names to skip\n      --subdir <SUBDIR>              Subdirectory to the language\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)\n      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)\n  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex\n      --log-graphs                   Enable logging of graphs and input\n  -l, --log                          Enable parser logging\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n", prog);
    } else if (streq(cmd, "query")) {
        printf("Search files using a syntax tree query\n\nUsage: %s query [OPTIONS] <QUERY_PATH> [PATHS]...\n\nArguments:\n  <QUERY_PATH>  Path to a file with queries\n  [PATHS]...    The source file(s) to use\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>\n          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>\n          If `--lib-path` is used, the name of the language used to extract the library's language function\n  -t, --time\n          Measure execution time\n  -q, --quiet\n          Suppress main output\n      --paths <PATHS_FILE>\n          The path to a file with paths to source file(s)\n      --byte-range <BYTE_RANGE>\n          The range of byte offsets in which the query will be executed\n      --row-range <ROW_RANGE>\n          The range of rows in which the query will be executed\n      --containing-byte-range <CONTAINING_BYTE_RANGE>\n          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned\n      --containing-row-range <CONTAINING_ROW_RANGE>\n          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned\n      --scope <SCOPE>\n          Select a language by the scope instead of a file extension\n  -c, --captures\n          Order by captures instead of matches\n      --test\n          Whether to run query tests or not\n      --config-path <CONFIG_PATH>\n          The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>\n          Query the contents of a specific test\n  -r, --rebuild\n          Force rebuild the parser\n  -h, --help\n          Print help\n", prog);
    } else if (streq(cmd, "highlight")) {
        printf("Highlight a file\n\nUsage: %s highlight [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n  -H, --html                           Generate highlighting as an HTML document\n      --css-classes                    When generating HTML, use css classes rather than inline styles\n      --check                          Check that highlighting captures conform strictly to standards\n      --captures-path <CAPTURES_PATH>  The path to a file with captures\n      --query-paths <QUERY_PATHS>...   The paths to files with queries\n      --scope <SCOPE>                  Select a language by the scope instead of a file extension\n  -t, --time                           Measure execution time\n  -q, --quiet                          Suppress main output\n      --paths <PATHS_FILE>             The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>      The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test\n  -r, --rebuild                        Force rebuild the parser\n      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n  -h, --help                           Print help\n", prog);
    } else if (streq(cmd, "tags")) {
        printf("Generate a list of tags\n\nUsage: %s tags [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n", prog);
    } else if (streq(cmd, "playground")) {
        printf("Start local playground for a parser in the browser\n\nUsage: %s playground [OPTIONS]\n\nOptions:\n  -q, --quiet                        Don't open in default browser\n      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files\n  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them\n  -h, --help                         Print help\n", prog);
    } else if (streq(cmd, "dump-languages")) {
        printf("Print info about all known language parsers\n\nUsage: %s dump-languages [OPTIONS]\n\nOptions:\n      --config-path <CONFIG_PATH>  The path to an alternative config.json file\n  -h, --help                       Print help\n", prog);
    } else if (streq(cmd, "complete")) {
        printf("Generate shell completions\n\nUsage: %s complete --shell <SHELL>\n\nOptions:\n  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n  -h, --help           Print help\n", prog);
    }
}

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            if (mkdir(tmp, 0777) && errno != EEXIST) return -1;
            *p = '/';
        }
    }
    if (mkdir(tmp, 0777) && errno != EEXIST) return -1;
    return 0;
}

static void config_path(char *out, size_t n) {
    const char *xdg = getenv("XDG_CONFIG_HOME");
    const char *home = getenv("HOME");
    if (xdg && *xdg) snprintf(out, n, "%s/tree-sitter/config.json", xdg);
    else snprintf(out, n, "%s/.config/tree-sitter/config.json", home && *home ? home : ".");
}

static int cmd_init_config(void) {
    char path[PATH_MAX], dirbuf[PATH_MAX], homebuf[PATH_MAX];
    config_path(path, sizeof(path));
    if (access(path, F_OK) == 0) {
        fprintf(stderr, RED "Error:" RESET " Remove your existing config file first: %s\n", path);
        return 1;
    }
    snprintf(dirbuf, sizeof(dirbuf), "%s", path);
    if (mkdir_p(dirname(dirbuf)) != 0) {
        fprintf(stderr, RED "Error:" RESET " %s\n", strerror(errno));
        return 1;
    }
    const char *home = getenv("HOME");
    snprintf(homebuf, sizeof(homebuf), "%s", home && *home ? home : ".");
    FILE *f = fopen(path, "w");
    if (!f) {
        fprintf(stderr, RED "Error:" RESET " %s\n", strerror(errno));
        return 1;
    }
    fprintf(f,
            "{\n"
            "  \"parser-directories\": [\n"
            "    \"%s/github\",\n"
            "    \"%s/src\",\n"
            "    \"%s/source\",\n"
            "    \"%s/projects\",\n"
            "    \"%s/dev\",\n"
            "    \"%s/git\"\n"
            "  ],\n"
            "  \"theme\": {\n"
            "    \"attribute\": {\n      \"color\": 124,\n      \"italic\": true\n    },\n"
            "    \"comment\": {\n      \"color\": 245,\n      \"italic\": true\n    },\n"
            "    \"constant\": 94,\n"
            "    \"constant.builtin\": {\n      \"bold\": true,\n      \"color\": 94\n    },\n"
            "    \"constructor\": 136,\n"
            "    \"embedded\": null,\n"
            "    \"function\": 26,\n"
            "    \"function.builtin\": {\n      \"bold\": true,\n      \"color\": 26\n    },\n"
            "    \"keyword\": 56,\n"
            "    \"module\": 136,\n"
            "    \"number\": {\n      \"bold\": true,\n      \"color\": 94\n    },\n"
            "    \"operator\": {\n      \"bold\": true,\n      \"color\": 239\n    },\n"
            "    \"property\": 124,\n"
            "    \"property.builtin\": {\n      \"bold\": true,\n      \"color\": 124\n    },\n"
            "    \"punctuation\": 239,\n"
            "    \"punctuation.bracket\": 239,\n"
            "    \"punctuation.delimiter\": 239,\n"
            "    \"punctuation.special\": 239,\n"
            "    \"string\": 28,\n"
            "    \"string.special\": 30,\n"
            "    \"tag\": 18,\n"
            "    \"type\": 23,\n"
            "    \"type.builtin\": {\n      \"bold\": true,\n      \"color\": 23\n    },\n"
            "    \"variable\": 252,\n"
            "    \"variable.builtin\": {\n      \"bold\": true,\n      \"color\": 252\n    },\n"
            "    \"variable.parameter\": {\n      \"color\": 252,\n      \"underline\": true\n    }\n"
            "  }\n"
            "}\n",
            homebuf, homebuf, homebuf, homebuf, homebuf, homebuf);
    fclose(f);
    printf("Saved initial configuration to %s\n", path);
    return 0;
}

static int has_non_option_path(int argc, char **argv, int start) {
    for (int i = start; i < argc; i++) {
        if (argv[i][0] != '-') return i;
        if ((streq(argv[i], "-p") || streq(argv[i], "--grammar-path") || streq(argv[i], "-l") ||
             streq(argv[i], "--lib-path") || streq(argv[i], "--lang-name") || streq(argv[i], "--scope") ||
             streq(argv[i], "--paths") || streq(argv[i], "--config-path") || streq(argv[i], "-n") ||
             streq(argv[i], "--test-number") || streq(argv[i], "--encoding") || streq(argv[i], "--timeout")) && i + 1 < argc)
            i++;
    }
    return -1;
}

static int check_invalid_values(int argc, char **argv) {
    for (int i = 0; i < argc; i++) {
        if (streq(argv[i], "--encoding") && i + 1 < argc) {
            const char *v = argv[i + 1];
            if (!streq(v, "utf8") && !streq(v, "utf16-le") && !streq(v, "utf16-be")) {
                fprintf(stderr, "error: invalid value '%s' for '--encoding <ENCODING>'\n  [possible values: utf8, utf16-le, utf16-be]\n\nFor more information, try '--help'.\n", v);
                return 2;
            }
        }
    }
    return 0;
}

static void warn_no_language(const char *path) {
    char cfg[PATH_MAX];
    config_path(cfg, sizeof(cfg));
    const char *home = getenv("HOME");
    if (!home || !*home) home = "/home/agent";
    printf(YELLOW "Warning:" RESET " No language found for path `%s`\n\n", path);
    printf("If a language should be associated with this file extension, please ensure the path to `%s` is inside one of the following directories as specified by your 'config.json':\n\n", path);
    printf("  1. %s/github  \n  2. %s/src  \n  3. %s/source  \n  4. %s/projects  \n  5. %s/dev  \n  6. %s/git\n\n", home, home, home, home, home, home);
    printf("If the directory that contains the relevant grammar for `%s` is not listed above, please add the directory to the list of directories in your config file, located at %s\n", path, cfg);
}

static int cmd_complete(int argc, char **argv) {
    const char *shell = NULL;
    for (int i = 2; i < argc; i++) {
        if ((streq(argv[i], "-s") || streq(argv[i], "--shell")) && i + 1 < argc) shell = argv[++i];
    }
    if (!shell) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  --shell <SHELL>\n\nUsage: %s complete --shell <SHELL>\n\nFor more information, try '--help'.\n", prog);
        return 2;
    }
    if (!streq(shell, "bash") && !streq(shell, "elvish") && !streq(shell, "fish") && !streq(shell, "power-shell") && !streq(shell, "zsh") && !streq(shell, "nushell")) {
        fprintf(stderr, "error: invalid value '%s' for '--shell <SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\nFor more information, try '--help'.\n", shell);
        return 2;
    }
    if (streq(shell, "bash")) {
        printf("_tree-sitter() {\n    COMPREPLY=()\n}\ncomplete -F _tree-sitter -o bashdefault -o default tree-sitter\n");
    } else if (streq(shell, "fish")) {
        printf("complete -c tree-sitter -f -a \"init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete\"\n");
    } else if (streq(shell, "zsh")) {
        printf("#compdef tree-sitter\n\n_tree-sitter() { _arguments '*:: :->cmds' }\n");
    } else {
        printf("# completions for tree-sitter (%s)\n", shell);
    }
    return 0;
}

static int maybe_help(int argc, char **argv, const char *cmd) {
    for (int i = 2; i < argc; i++) {
        if (arg_is_help(argv[i])) {
            print_help_for(cmd);
            return 1;
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc > 0) {
        char *base = strrchr(argv[0], '/');
        prog = base ? base + 1 : argv[0];
    }
    if (argc == 1 || (argc == 2 && arg_is_help(argv[1]))) {
        print_top_help();
        return 0;
    }
    if (argc == 2 && (streq(argv[1], "-V") || streq(argv[1], "--version"))) {
        printf("tree-sitter 0.27.0\n");
        return 0;
    }

    const char *cmd = argv[1];
    const char *known[] = {"init-config","init","generate","build","parse","test","version","fuzz","query","highlight","tags","playground","dump-languages","complete",NULL};
    bool ok = false;
    for (int i = 0; known[i]; i++) if (streq(cmd, known[i])) ok = true;
    if (!ok) {
        fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: %s <COMMAND>\n\nFor more information, try '--help'.\n", cmd, prog);
        return 2;
    }
    if (maybe_help(argc, argv, cmd)) return 0;

    if (streq(cmd, "init-config")) return cmd_init_config();
    if (streq(cmd, "init")) {
        fprintf(stderr, RED "Error:" RESET " IO error: not a terminal\n");
        return 1;
    }
    if (streq(cmd, "generate")) {
        const char *path = "grammar.js";
        int p = has_non_option_path(argc, argv, 2);
        if (p >= 0) path = argv[p];
        fprintf(stderr, RED "Error:" RESET " Error when generating parser\n\nCaused by:\n    Failed to load %s -- No such file or directory (os error 2) (%s/%s)\n", path, getcwd(NULL, 0), path);
        return 1;
    }
    if (streq(cmd, "build")) {
        fprintf(stderr, RED "Error:" RESET " Failed to compile parser\n\nCaused by:\n    No such file or directory (os error 2) (%s/src/grammar.json)\n", getcwd(NULL, 0));
        return 1;
    }
    if (streq(cmd, "parse")) {
        int e = check_invalid_values(argc, argv);
        if (e) return e;
        int p = has_non_option_path(argc, argv, 2);
        if (p >= 0) {
            fprintf(stderr, RED "Error:" RESET " Failed to load language for path \"%s\"\n\nCaused by:\n    No language found\n", argv[p]);
        } else {
            fprintf(stderr, "\n" RED "Error:" RESET " No language found\n");
        }
        return 1;
    }
    if (streq(cmd, "test") || streq(cmd, "fuzz")) {
        fprintf(stderr, RED "Error:" RESET " No language found\n");
        return 1;
    }
    if (streq(cmd, "version")) {
        fprintf(stderr, RED "Error:" RESET " No such file or directory (os error 2)\n");
        return 1;
    }
    if (streq(cmd, "query")) {
        int p = has_non_option_path(argc, argv, 2);
        if (p < 0) {
            fprintf(stderr, "error: the following required arguments were not provided:\n  <QUERY_PATH>\n\nUsage: %s query <QUERY_PATH> [PATHS]...\n\nFor more information, try '--help'.\n", prog);
            return 2;
        }
        fprintf(stderr, RED "Error:" RESET " No language found\n");
        return 1;
    }
    if (streq(cmd, "highlight") || streq(cmd, "tags")) {
        int e = check_invalid_values(argc, argv);
        if (e) return e;
        int p = has_non_option_path(argc, argv, 2);
        if (p >= 0) warn_no_language(argv[p]);
        else fprintf(stderr, "\n" RED "Error:" RESET " No language found in current path\n");
        return p >= 0 ? 0 : 1;
    }
    if (streq(cmd, "playground")) {
        fprintf(stderr, "\nthread 'main' panicked at crates/cli/src/wasm.rs:15:10:\ncalled `Result::unwrap()` on an `Err` value: Failed to get Wasm filename\n\nCaused by:\n    0: Failed to read grammar file %s/src/grammar.json\n    1: No such file or directory (os error 2)\n", getcwd(NULL, 0));
        return 101;
    }
    if (streq(cmd, "dump-languages")) return 0;
    if (streq(cmd, "complete")) return cmd_complete(argc, argv);
    return 0;
}
