#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char *usage_text =
"\033[cUsage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n"
"\n"
"OPTIONS:\n"
"  -interval duration\n"
"    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)\n"
"  -rows int\n"
"    \tLimits the height of the graph output.\n"
"  -steps int\n"
"    \tNumber of values to plot. (default 100)\n"
"  -url string\n"
"    \tURL to fetch every second. Read JSON objects from stdin if not specified.\n"
"\n"
"FIELD_SPEC: [<option>[,<option>...]:]path\n"
"  option:\n"
"    - counter: Computes the difference with the last value. The value must increase monotonically.\n"
"    - marker: When the value is none-zero, a vertical line is drawn.\n"
"  path:\n"
"    JSON field path (eg: field.sub-field).\n";

typedef struct {
    char *path;
    bool counter;
    bool marker;
    double last;
    bool have_last;
} Field;

typedef struct {
    Field *fields;
    int nfields;
} Graph;

typedef struct {
    double *values;
    int n;
    int cap;
} Series;

static void parse_error(const char *msg) {
    fputs("\033[c", stderr);
    fputs(msg, stderr);
    fputc('\n', stderr);
    fputs(usage_text + 3, stderr);
}

static bool parse_int_flag(const char *s, int *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !end || *end != '\0') return false;
    *out = (int)v;
    return true;
}

static bool parse_duration(const char *s) {
    char *end = NULL;
    errno = 0;
    (void)strtod(s, &end);
    if (errno || end == s) return false;
    if (!strcmp(end, "ns") || !strcmp(end, "us") || !strcmp(end, "µs") ||
        !strcmp(end, "ms") || !strcmp(end, "s") || !strcmp(end, "m") ||
        !strcmp(end, "h")) return true;
    return false;
}

static char *xstrndup(const char *s, size_t n) {
    char *p = malloc(n + 1);
    if (!p) exit(2);
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

static void add_field(Graph *g, const char *spec, size_t len) {
    Field f;
    memset(&f, 0, sizeof(f));
    const char *colon = memchr(spec, ':', len);
    const char *path = spec;
    size_t path_len = len;
    if (colon) {
        const char *p = spec;
        while (p < colon) {
            const char *comma = memchr(p, ',', (size_t)(colon - p));
            const char *end = comma ? comma : colon;
            size_t olen = (size_t)(end - p);
            if (olen == 7 && !strncmp(p, "counter", 7)) f.counter = true;
            if (olen == 6 && !strncmp(p, "marker", 6)) f.marker = true;
            p = comma ? comma + 1 : colon;
        }
        path = colon + 1;
        path_len = len - (size_t)(path - spec);
    }
    f.path = xstrndup(path, path_len);
    g->fields = realloc(g->fields, sizeof(Field) * (size_t)(g->nfields + 1));
    if (!g->fields) exit(2);
    g->fields[g->nfields++] = f;
}

static Graph parse_graph(const char *arg) {
    Graph g = {0};
    const char *p = arg;
    while (*p) {
        const char *plus = strchr(p, '+');
        size_t len = plus ? (size_t)(plus - p) : strlen(p);
        add_field(&g, p, len);
        if (!plus) break;
        p = plus + 1;
    }
    return g;
}

static const char *skip_ws(const char *p) {
    while (*p && isspace((unsigned char)*p)) p++;
    return p;
}

static const char *skip_string(const char *p) {
    if (*p != '"') return p;
    p++;
    while (*p) {
        if (*p == '\\' && p[1]) { p += 2; continue; }
        if (*p == '"') return p + 1;
        p++;
    }
    return p;
}

static const char *skip_value(const char *p);

static const char *skip_array(const char *p) {
    p++;
    for (;;) {
        p = skip_ws(p);
        if (*p == ']') return p + 1;
        if (!*p) return p;
        p = skip_value(p);
        p = skip_ws(p);
        if (*p == ',') p++;
    }
}

static const char *skip_object(const char *p) {
    p++;
    for (;;) {
        p = skip_ws(p);
        if (*p == '}') return p + 1;
        if (!*p) return p;
        p = skip_string(p);
        p = skip_ws(p);
        if (*p == ':') p++;
        p = skip_value(p);
        p = skip_ws(p);
        if (*p == ',') p++;
    }
}

static const char *skip_value(const char *p) {
    p = skip_ws(p);
    if (*p == '"') return skip_string(p);
    if (*p == '{') return skip_object(p);
    if (*p == '[') return skip_array(p);
    while (*p && !strchr(",}]\n\r\t ", *p)) p++;
    return p;
}

static bool key_match(const char *p, const char *key, size_t klen, const char **after) {
    if (*p != '"') return false;
    p++;
    size_t i = 0;
    while (*p && *p != '"') {
        if (*p == '\\') return false;
        if (i >= klen || *p != key[i]) return false;
        i++; p++;
    }
    if (*p != '"' || i != klen) return false;
    *after = p + 1;
    return true;
}

static const char *find_key_value(const char *obj, const char *key, size_t klen) {
    const char *p = skip_ws(obj);
    if (*p != '{') return NULL;
    p++;
    for (;;) {
        p = skip_ws(p);
        if (*p == '}') return NULL;
        if (*p != '"') return NULL;
        const char *after_key = NULL;
        bool match = key_match(p, key, klen, &after_key);
        p = skip_string(p);
        p = skip_ws(p);
        if (*p != ':') return NULL;
        p++;
        if (match) return skip_ws(p);
        p = skip_value(p);
        p = skip_ws(p);
        if (*p == ',') p++;
    }
}

static bool json_path_number(const char *json, const char *path, double *out) {
    const char *cur = json;
    const char *p = path;
    while (1) {
        const char *dot = strchr(p, '.');
        size_t len = dot ? (size_t)(dot - p) : strlen(p);
        cur = find_key_value(cur, p, len);
        if (!cur) return false;
        if (!dot) break;
        p = dot + 1;
    }
    char *end = NULL;
    errno = 0;
    double v = strtod(cur, &end);
    if (errno || end == cur) return false;
    *out = v;
    return true;
}

static void series_add(Series *s, double v, int steps) {
    if (s->n == s->cap) {
        s->cap = s->cap ? s->cap * 2 : 32;
        s->values = realloc(s->values, sizeof(double) * (size_t)s->cap);
        if (!s->values) exit(2);
    }
    s->values[s->n++] = v;
    if (steps > 0 && s->n > steps) {
        memmove(s->values, s->values + 1, sizeof(double) * (size_t)(s->n - 1));
        s->n--;
    }
}

static void read_stdin(Graph *graphs, int ng, Series *series, int steps) {
    char *line = NULL;
    size_t cap = 0;
    while (getline(&line, &cap, stdin) != -1) {
        int si = 0;
        for (int gi = 0; gi < ng; gi++) {
            for (int fi = 0; fi < graphs[gi].nfields; fi++, si++) {
                Field *f = &graphs[gi].fields[fi];
                double v = 0.0;
                if (!json_path_number(line, f->path, &v)) v = 0.0;
                if (f->counter) {
                    double old = f->have_last ? f->last : v;
                    f->last = v;
                    f->have_last = true;
                    v = v - old;
                    if (v < 0) v = 0;
                }
                series_add(&series[si], v, steps);
            }
        }
    }
    free(line);
}

static void emit_sixel(Graph *graphs, int ng, Series *series, int rows, int steps) {
    (void)graphs;
    int width = steps > 0 ? steps : 80;
    if (width < 10) width = 10;
    if (width > 240) width = 240;
    int height = rows > 0 ? rows * 18 : 120;
    if (height < 24) height = 24;
    if (height > 360) height = 360;
    printf("\033P0;0;8q\"1;1#1;2;0;0;0#2;2;90;90;90#3;2;0;45;85");
    int total = 0;
    for (int gi = 0; gi < ng; gi++) total += graphs[gi].nfields;
    double maxv = 1.0;
    for (int i = 0; i < total; i++)
        for (int j = 0; j < series[i].n; j++)
            if (series[i].values[j] > maxv) maxv = series[i].values[j];
    for (int y = 0; y < height; y += 6) {
        printf("#1");
        for (int x = 0; x < width; x++) {
            int bits = 0;
            for (int b = 0; b < 6; b++) {
                int py = y + b;
                bool on = false;
                for (int s = 0; s < total; s++) {
                    if (series[s].n == 0) continue;
                    int idx = (int)((long long)x * series[s].n / width);
                    if (idx >= series[s].n) idx = series[s].n - 1;
                    int level = height - 1 - (int)((series[s].values[idx] / maxv) * (height - 1));
                    if (abs(level - py) <= 1) on = true;
                }
                if (on) bits |= 1 << b;
            }
            putchar(63 + bits);
        }
        if (y + 6 < height) putchar('-');
    }
    printf("\033\\");
}

int main(int argc, char **argv) {
    int steps = 100, rows = 0;
    const char *url = NULL;
    int argi = 1;
    for (; argi < argc; argi++) {
        char *a = argv[argi];
        if (a[0] != '-' || !strcmp(a, "-")) break;
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            fputs(usage_text, stderr);
            return 0;
        } else if (!strcmp(a, "-steps") || !strcmp(a, "--steps")) {
            if (++argi >= argc) { parse_error("flag needs an argument: -steps"); return 2; }
            if (!parse_int_flag(argv[argi], &steps)) {
                char buf[256]; snprintf(buf, sizeof(buf), "invalid value %c%s%c for flag -steps: parse error", '"', argv[argi], '"');
                parse_error(buf); return 2;
            }
        } else if (!strcmp(a, "-rows") || !strcmp(a, "--rows")) {
            if (++argi >= argc) { parse_error("flag needs an argument: -rows"); return 2; }
            if (!parse_int_flag(argv[argi], &rows)) {
                char buf[256]; snprintf(buf, sizeof(buf), "invalid value %c%s%c for flag -rows: parse error", '"', argv[argi], '"');
                parse_error(buf); return 2;
            }
        } else if (!strcmp(a, "-interval") || !strcmp(a, "--interval")) {
            if (++argi >= argc) { parse_error("flag needs an argument: -interval"); return 2; }
            if (!parse_duration(argv[argi])) {
                char buf[256]; snprintf(buf, sizeof(buf), "invalid value %c%s%c for flag -interval: parse error", '"', argv[argi], '"');
                parse_error(buf); return 2;
            }
        } else if (!strcmp(a, "-url") || !strcmp(a, "--url")) {
            if (++argi >= argc) { parse_error("flag needs an argument: -url"); return 2; }
            url = argv[argi];
        } else {
            char buf[256];
            const char *name = a;
            while (*name == '-') name++;
            snprintf(buf, sizeof(buf), "flag provided but not defined: -%s", name);
            parse_error(buf);
            return 2;
        }
    }

    int ng = argc - argi;
    Graph *graphs = NULL;
    if (ng > 0) {
        graphs = calloc((size_t)ng, sizeof(Graph));
        if (!graphs) return 2;
        for (int i = 0; i < ng; i++) graphs[i] = parse_graph(argv[argi + i]);
    }

    if (!isatty(STDOUT_FILENO)) {
        fputs("\033[cjplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n", stderr);
        return 1;
    }

    int total = 0;
    for (int i = 0; i < ng; i++) total += graphs[i].nfields;
    Series *series = calloc((size_t)(total > 0 ? total : 1), sizeof(Series));
    if (!series) return 2;
    if (url) {
        (void)url;
    } else {
        read_stdin(graphs, ng, series, steps);
    }
    emit_sixel(graphs, ng, series, rows, steps);
    return 0;
}
