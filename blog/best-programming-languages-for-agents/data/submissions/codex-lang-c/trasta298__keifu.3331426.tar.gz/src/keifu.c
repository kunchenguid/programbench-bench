#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <termios.h>
#include <unistd.h>

#define MAX_COMMITS 512
#define MAX_FILES 128

typedef struct {
    char hash[64];
    char short_hash[16];
    char refs[512];
    char author[256];
    char date[64];
    char subject[512];
    char body[2048];
} Commit;

typedef struct {
    char path[512];
    int added;
    int deleted;
    char status[8];
} FileStat;

static Commit commits[MAX_COMMITS];
static int commit_count = 0;
static int selected = 0;
static int rows = 24, cols = 80;
static struct termios old_termios;
static bool termios_saved = false;
static volatile sig_atomic_t resized = 1;

static void trim_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0;
}

static void chomp_spaces(char *s) {
    trim_newline(s);
    size_t n = strlen(s);
    while (n && isspace((unsigned char)s[n - 1])) s[--n] = 0;
    char *p = s;
    while (*p && isspace((unsigned char)*p)) p++;
    if (p != s) memmove(s, p, strlen(p) + 1);
}

static void run_quiet(const char *cmd) {
    FILE *fp = popen(cmd, "r");
    if (fp) pclose(fp);
}

static int command_ok(const char *cmd) {
    FILE *fp = popen(cmd, "r");
    if (!fp) return 0;
    int rc = pclose(fp);
    return rc == 0;
}

static char *read_command(const char *cmd) {
    FILE *fp = popen(cmd, "r");
    if (!fp) return NULL;
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) {
        pclose(fp);
        return NULL;
    }
    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (len + 1 >= cap) {
            cap *= 2;
            char *nb = realloc(buf, cap);
            if (!nb) {
                free(buf);
                pclose(fp);
                return NULL;
            }
            buf = nb;
        }
        buf[len++] = (char)c;
    }
    buf[len] = 0;
    pclose(fp);
    return buf;
}

static void copy_field(char *dst, size_t n, const char *src) {
    if (!dst || !n) return;
    if (!src) src = "";
    size_t len = strlen(src);
    if (len >= n) len = n - 1;
    memcpy(dst, src, len);
    dst[len] = 0;
}

static void load_commits(void) {
    commit_count = 0;
    char *out = read_command("git --no-pager log --all --decorate=short --date=short --pretty=format:'%H%x1f%h%x1f%D%x1f%an%x1f%ad%x1f%s%x1e' -n 512 2>/dev/null");
    if (!out) return;
    char *save_rec = NULL;
    for (char *rec = strtok_r(out, "\036", &save_rec); rec && commit_count < MAX_COMMITS; rec = strtok_r(NULL, "\036", &save_rec)) {
        Commit *c = &commits[commit_count];
        memset(c, 0, sizeof(*c));
        char *fields[6] = {0};
        char *save_field = NULL;
        int i = 0;
        for (char *f = strtok_r(rec, "\037", &save_field); f && i < 6; f = strtok_r(NULL, "\037", &save_field)) {
            fields[i++] = f;
        }
        if (i >= 6) {
            copy_field(c->hash, sizeof(c->hash), fields[0]);
            copy_field(c->short_hash, sizeof(c->short_hash), fields[1]);
            copy_field(c->refs, sizeof(c->refs), fields[2]);
            copy_field(c->author, sizeof(c->author), fields[3]);
            copy_field(c->date, sizeof(c->date), fields[4]);
            copy_field(c->subject, sizeof(c->subject), fields[5]);
            chomp_spaces(c->hash);
            chomp_spaces(c->refs);
            chomp_spaces(c->subject);
            commit_count++;
        }
    }
    free(out);
    if (selected >= commit_count) selected = commit_count ? commit_count - 1 : 0;
}

static void load_body(Commit *c) {
    if (!c || c->body[0]) return;
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "git --no-pager show -s --format='%%B' %.40s 2>/dev/null", c->hash);
    char *out = read_command(cmd);
    if (!out) return;
    copy_field(c->body, sizeof(c->body), out);
    trim_newline(c->body);
    free(out);
}

static int load_files(const Commit *c, FileStat *files, int max_files, int *total_add, int *total_del) {
    *total_add = *total_del = 0;
    if (!c) return 0;
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "git --no-pager show --numstat --format= %.40s 2>/dev/null", c->hash);
    char *out = read_command(cmd);
    if (!out) return 0;
    int n = 0;
    char *save = NULL;
    for (char *line = strtok_r(out, "\n", &save); line && n < max_files; line = strtok_r(NULL, "\n", &save)) {
        char a[32], d[32], path[512];
        if (sscanf(line, "%31s %31s %511[^\n]", a, d, path) == 3) {
            FileStat *fs = &files[n++];
            memset(fs, 0, sizeof(*fs));
            fs->added = strcmp(a, "-") == 0 ? 0 : atoi(a);
            fs->deleted = strcmp(d, "-") == 0 ? 0 : atoi(d);
            *total_add += fs->added;
            *total_del += fs->deleted;
            copy_field(fs->path, sizeof(fs->path), path);
            copy_field(fs->status, sizeof(fs->status), fs->added && !fs->deleted ? "A" : "M");
        }
    }
    free(out);
    return n;
}

static void get_size(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0 && ws.ws_row > 0) {
        cols = ws.ws_col;
        rows = ws.ws_row;
    }
    if (cols < 60) cols = 60;
    if (rows < 20) rows = 20;
    resized = 0;
}

static int utf8_len(const char *s) {
    int n = 0;
    for (; *s; s++) if (((unsigned char)*s & 0xc0) != 0x80) n++;
    return n;
}

static void putn_clean(const char *s, int width) {
    int used = 0;
    for (; *s && used < width; s++) {
        unsigned char ch = (unsigned char)*s;
        if (ch == '\033') continue;
        if (ch < 32) {
            putchar(' ');
            used++;
        } else {
            putchar(ch);
            if ((ch & 0xc0) != 0x80) used++;
        }
    }
    while (used++ < width) putchar(' ');
}

static void line_at(int r, const char *fmt, ...) {
    printf("\033[%d;1H", r);
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
}

static void border_top(int r, const char *title, int width) {
    line_at(r, "┌ %s ", title);
    int used = utf8_len(title) + 3;
    for (int i = used; i < width - 1; i++) printf("─");
    printf("┐");
}

static void border_bottom(int r, int width) {
    line_at(r, "└");
    for (int i = 1; i < width - 1; i++) printf("─");
    printf("┘");
}

static void draw_box_line(int r, int width, const char *text, bool inverse) {
    line_at(r, "│");
    if (inverse) printf("\033[1;38;5;15;48;5;8m");
    putn_clean(text ? text : "", width - 2);
    if (inverse) printf("\033[0m\033[38;5;8m");
    printf("│");
}

static void ref_label(const char *refs, char *out, size_t n) {
    out[0] = 0;
    if (!refs || !refs[0]) return;
    char tmp[512];
    copy_field(tmp, sizeof(tmp), refs);
    char *save = NULL;
    for (char *p = strtok_r(tmp, ",", &save); p; p = strtok_r(NULL, ",", &save)) {
        chomp_spaces(p);
        if (strncmp(p, "HEAD -> ", 8) == 0) p += 8;
        if (strncmp(p, "tag: ", 5) == 0) p += 5;
        if (strncmp(p, "origin/", 7) == 0 && out[0]) continue;
        if (!out[0]) snprintf(out, n, "[%s]", p);
    }
}

static void current_branch(char *out, size_t n) {
    char *b = read_command("git symbolic-ref --quiet --short HEAD 2>/dev/null || git rev-parse --short HEAD 2>/dev/null");
    if (!b) {
        copy_field(out, n, "detached");
        return;
    }
    trim_newline(b);
    copy_field(out, n, b[0] ? b : "detached");
    free(b);
}

static void repo_name(char *out, size_t n) {
    char *b = read_command("basename \"$(git rev-parse --show-toplevel 2>/dev/null)\"");
    if (!b) {
        copy_field(out, n, "repository");
        return;
    }
    trim_newline(b);
    copy_field(out, n, b[0] ? b : "repository");
    free(b);
}

static void draw(void) {
    if (resized) get_size();
    FileStat files[MAX_FILES];
    int total_add = 0, total_del = 0;
    Commit *cur = commit_count ? &commits[selected] : NULL;
    if (cur) load_body(cur);
    int file_count = load_files(cur, files, MAX_FILES, &total_add, &total_del);

    int commit_h = rows * 2 / 3;
    if (commit_h < 10) commit_h = 10;
    if (commit_h > rows - 7) commit_h = rows - 7;
    int bottom_top = commit_h + 1;
    int bottom_h = rows - bottom_top;
    int left_w = cols / 2;
    int right_w = cols - left_w;

    printf("\033[?1049h\033[?25l\033[0m\033[38;5;8m\033[2J");
    border_top(1, "Commits", cols);
    int visible = commit_h - 2;
    int start = selected >= visible ? selected - visible + 1 : 0;
    for (int i = 0; i < visible; i++) {
        int idx = start + i;
        char line[2048] = "";
        if (idx < commit_count) {
            char label[256];
            ref_label(commits[idx].refs, label, sizeof(label));
            snprintf(line, sizeof(line), " ◉  %-18s %-42s %10s  %.18s",
                     label, commits[idx].subject, commits[idx].date, commits[idx].author);
        }
        draw_box_line(2 + i, cols, line, idx == selected);
    }
    border_bottom(commit_h, cols);

    border_top(bottom_top, "Commit Detail", left_w);
    printf("┌ Changed Files ");
    int used = (int)strlen(" Changed Files ") + 1;
    for (int i = used; i < right_w - 1; i++) printf("─");
    printf("┐");

    int content = bottom_h - 3;
    for (int i = 0; i < content; i++) {
        char lbuf[1024] = "", rbuf[1024] = "";
        if (cur) {
            if (i == 0) snprintf(lbuf, sizeof(lbuf), "Commit:");
            else if (i == 1) snprintf(lbuf, sizeof(lbuf), "%.40s", cur->hash);
            else if (i == 3) snprintf(lbuf, sizeof(lbuf), "Author: %s", cur->author);
            else if (i == 4) snprintf(lbuf, sizeof(lbuf), "Date:   %s", cur->date);
            else if (i == 6) copy_field(lbuf, sizeof(lbuf), cur->body[0] ? cur->body : cur->subject);
        }
        if (i == 0) snprintf(rbuf, sizeof(rbuf), "%d files changed  +%d -%d", file_count, total_add, total_del);
        else if (i - 2 >= 0 && i - 2 < file_count) {
            FileStat *fs = &files[i - 2];
            snprintf(rbuf, sizeof(rbuf), " %s  %s  +%d -%d", fs->status, fs->path, fs->added, fs->deleted);
        }
        line_at(bottom_top + 1 + i, "│");
        putn_clean(lbuf, left_w - 2);
        printf("││");
        putn_clean(rbuf, right_w - 2);
        printf("│");
    }
    border_bottom(rows - 1, left_w);
    printf("└");
    for (int i = 1; i < right_w - 1; i++) printf("─");
    printf("┘");

    char branch[128], name[128];
    current_branch(branch, sizeof(branch));
    repo_name(name, sizeof(name));
    line_at(rows, "\033[1;38;5;0;48;5;5m %s \033[0m \033[1;38;5;0;48;5;2m %s \033[0m \033[1;38;5;0;48;5;6m j/k \033[0m move \033[1;38;5;0;48;5;6m Enter \033[0m checkout \033[1;38;5;0;48;5;6m b \033[0m branch \033[1;38;5;0;48;5;6m f \033[0m fetch \033[1;38;5;0;48;5;6m ? \033[0m help \033[1;38;5;0;48;5;6m q \033[0m quit", name, branch);
    fflush(stdout);
}

static void cleanup(void) {
    printf("\033[0m\033[?25h\033[?1049l");
    fflush(stdout);
    if (termios_saved) tcsetattr(STDIN_FILENO, TCSAFLUSH, &old_termios);
}

static void on_resize(int sig) {
    (void)sig;
    resized = 1;
}

static void enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &old_termios) == 0) {
        termios_saved = true;
        struct termios raw = old_termios;
        raw.c_lflag &= (tcflag_t)~(ECHO | ICANON);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 1;
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
    }
}

static void show_help_screen(void) {
    printf("\033[2J\033[1;1H");
    printf("keifu help\n\n");
    printf("Navigation: j/k or arrows move, g/G jump, q quits\n");
    printf("Git operations: Enter checkout, b create branch, d delete branch, f fetch\n");
    printf("\nPress any key to return.");
    fflush(stdout);
    char ch;
    while (read(STDIN_FILENO, &ch, 1) <= 0) {
        struct timeval tv = {0, 20000};
        select(0, NULL, NULL, NULL, &tv);
    }
}

static void checkout_selected(void) {
    if (!commit_count) return;
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "git checkout --quiet %.40s >/dev/null 2>&1", commits[selected].hash);
    run_quiet(cmd);
}

static void create_branch(void) {
    if (!commit_count) return;
    cleanup();
    printf("New branch name: ");
    fflush(stdout);
    char name[128];
    if (fgets(name, sizeof(name), stdin)) {
        chomp_spaces(name);
        if (name[0]) {
            char cmd[512];
            snprintf(cmd, sizeof(cmd), "git branch '%s' %.40s >/dev/null 2>&1", name, commits[selected].hash);
            run_quiet(cmd);
        }
    }
    enable_raw();
    resized = 1;
    load_commits();
}

static void delete_branch(void) {
    char branch[128];
    current_branch(branch, sizeof(branch));
    if (!branch[0] || strcmp(branch, "master") == 0 || strcmp(branch, "main") == 0) return;
    char cmd[512];
    snprintf(cmd, sizeof(cmd), "git branch -d '%s' >/dev/null 2>&1", branch);
    run_quiet(cmd);
    load_commits();
}

static int event_loop(void) {
    signal(SIGWINCH, on_resize);
    enable_raw();
    atexit(cleanup);
    load_commits();
    draw();
    time_t last_refresh = 0;
    (void)last_refresh;
    for (;;) {
        fd_set set;
        FD_ZERO(&set);
        FD_SET(STDIN_FILENO, &set);
        struct timeval tv = {1, 0};
        int rv = select(STDIN_FILENO + 1, &set, NULL, NULL, &tv);
        if (rv == 0) {
            draw();
            continue;
        }
        if (rv < 0) {
            if (errno == EINTR) {
                draw();
                continue;
            }
            return 1;
        }
        char ch = 0;
        if (read(STDIN_FILENO, &ch, 1) <= 0) continue;
        if (ch == 'q' || ch == 27) {
            if (ch == 27) {
                char seq[2];
                if (read(STDIN_FILENO, seq, 2) == 2 && seq[0] == '[') {
                    if (seq[1] == 'A' && selected > 0) selected--;
                    else if (seq[1] == 'B' && selected + 1 < commit_count) selected++;
                    else if (seq[1] == 'H') selected = 0;
                    else if (seq[1] == 'F' && commit_count) selected = commit_count - 1;
                    draw();
                    continue;
                }
            }
            return 0;
        } else if ((ch == 'j' || ch == 'J') && selected + 1 < commit_count) selected++;
        else if ((ch == 'k' || ch == 'K') && selected > 0) selected--;
        else if (ch == 'g') selected = 0;
        else if (ch == 'G' && commit_count) selected = commit_count - 1;
        else if (ch == '\r' || ch == '\n') checkout_selected();
        else if (ch == 'f') run_quiet("git fetch origin >/dev/null 2>&1");
        else if (ch == 'b') create_branch();
        else if (ch == 'd') delete_branch();
        else if (ch == 'R' || ch == 'r') load_commits();
        else if (ch == '?') show_help_screen();
        draw();
    }
}

static void print_help(void) {
    puts("A TUI tool to visualize Git commit graphs with branch genealogy\n");
    puts("Usage: executable\n");
    puts("Options:");
    puts("  -h, --help     Print help");
    puts("  -V, --version  Print version");
}

static void unexpected_arg(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "Usage: executable\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
}

int main(int argc, char **argv) {
    if (argc > 1) {
        if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
            print_help();
            return 0;
        }
        if (strcmp(argv[1], "-V") == 0 || strcmp(argv[1], "--version") == 0) {
            puts("keifu 0.2.3");
            return 0;
        }
        unexpected_arg(argv[1]);
        return 2;
    }

    if (!command_ok("git rev-parse --is-inside-work-tree >/dev/null 2>&1")) {
        fprintf(stderr, "Error: Git repository not found. Please run inside a Git repository.\n\n");
        fprintf(stderr, "Caused by:\n");
        fprintf(stderr, "    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n");
        return 1;
    }
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fprintf(stderr, "Error: No such device or address (os error 6)\n");
        return 1;
    }
    return event_loop();
}
