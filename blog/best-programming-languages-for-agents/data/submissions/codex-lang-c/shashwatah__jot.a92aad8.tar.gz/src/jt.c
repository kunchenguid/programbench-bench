#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define BLUE "\033[0;34m"
#define RED "\033[0;31m"
#define RESET "\033[0m"

typedef struct {
    char name[256];
    char loc[PATH_MAX];
} Vault;

typedef struct {
    Vault *v;
    int n;
    char current[256];
} Registry;

static const char *home(void) {
    const char *h = getenv("HOME");
    return h && *h ? h : ".";
}

static void join2(char *out, size_t n, const char *a, const char *b) {
    if (!a[0]) snprintf(out, n, "%s", b);
    else if (a[strlen(a)-1] == '/') snprintf(out, n, "%s%s", a, b);
    else snprintf(out, n, "%s/%s", a, b);
}

static void mkdir_p(const char *p) {
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof tmp, "%s", p);
    for (char *s = tmp + 1; *s; s++) {
        if (*s == '/') { *s = 0; mkdir(tmp, 0777); *s = '/'; }
    }
    mkdir(tmp, 0777);
}

static bool exists_path(const char *p) {
    struct stat st;
    return stat(p, &st) == 0;
}

static bool is_dir(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static void ensure_base(void) {
    char p[PATH_MAX];
    snprintf(p, sizeof p, "%s/.local/share/jot", home()); mkdir_p(p);
    snprintf(p, sizeof p, "%s/.config/jot", home()); mkdir_p(p);
    snprintf(p, sizeof p, "%s/.cache/rosetta", home()); mkdir_p(p);
    snprintf(p, sizeof p, "%s/.config/jot/config", home());
    if (!exists_path(p)) {
        FILE *f = fopen(p, "w");
        if (f) { fputs("editor = 'nvim'\nconflict = true\n", f); fclose(f); }
    }
    snprintf(p, sizeof p, "%s/.local/share/jot/vaults", home());
    if (!exists_path(p)) {
        FILE *f = fopen(p, "w");
        if (f) { fputs("[vaults]\n", f); fclose(f); }
    }
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static void strip_quotes(char *s) {
    char *t = trim(s);
    if ((*t == '\'' || *t == '"') && strlen(t) >= 2) {
        char q = *t;
        memmove(t, t + 1, strlen(t));
        char *e = strrchr(t, q);
        if (e) *e = 0;
    }
    if (t != s) memmove(s, t, strlen(t) + 1);
}

static Registry read_registry(void) {
    ensure_base();
    Registry r = {0};
    char p[PATH_MAX], line[4096];
    snprintf(p, sizeof p, "%s/.local/share/jot/vaults", home());
    FILE *f = fopen(p, "r");
    bool in = false;
    if (!f) return r;
    while (fgets(line, sizeof line, f)) {
        char *s = trim(line);
        if (!*s) continue;
        if (!strcmp(s, "[vaults]")) { in = true; continue; }
        char *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = 0;
        char *k = trim(s), *v = trim(eq + 1);
        strip_quotes(v);
        if (!in && !strcmp(k, "current")) snprintf(r.current, sizeof r.current, "%s", v);
        else if (in) {
            r.v = realloc(r.v, sizeof(Vault) * (r.n + 1));
            snprintf(r.v[r.n].name, sizeof r.v[r.n].name, "%s", k);
            snprintf(r.v[r.n].loc, sizeof r.v[r.n].loc, "%s", v);
            r.n++;
        }
    }
    fclose(f);
    return r;
}

static void write_registry(Registry *r) {
    char p[PATH_MAX];
    snprintf(p, sizeof p, "%s/.local/share/jot/vaults", home());
    FILE *f = fopen(p, "w");
    if (!f) return;
    if (r->current[0]) fprintf(f, "current = '%s'\n\n", r->current);
    fputs("[vaults]\n", f);
    for (int i = 0; i < r->n; i++) fprintf(f, "%s = '%s'\n", r->v[i].name, r->v[i].loc);
    fclose(f);
}

static int find_vault(Registry *r, const char *name) {
    for (int i = 0; i < r->n; i++) if (!strcmp(r->v[i].name, name)) return i;
    return -1;
}

static void vault_root(Vault *v, char *out) { join2(out, PATH_MAX, v->loc, v->name); }

static void data_path(Vault *v, char *out) {
    char root[PATH_MAX]; vault_root(v, root); snprintf(out, PATH_MAX, "%s/.jot/data", root);
}

static void read_folder(Vault *v, char *folder, size_t n) {
    folder[0] = 0;
    char p[PATH_MAX], line[4096]; data_path(v, p);
    FILE *f = fopen(p, "r");
    if (!f) return;
    while (fgets(line, sizeof line, f)) {
        char *s = trim(line), *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = 0;
        if (!strcmp(trim(s), "folder")) {
            char *val = trim(eq + 1); strip_quotes(val);
            snprintf(folder, n, "%s", val);
            break;
        }
    }
    fclose(f);
}

static void write_data(Vault *v, const char *folder) {
    char root[PATH_MAX], jot[PATH_MAX], p[PATH_MAX];
    vault_root(v, root); snprintf(jot, sizeof jot, "%s/.jot", root); mkdir_p(jot);
    data_path(v, p);
    FILE *f = fopen(p, "w");
    if (f) {
        fprintf(f, "name = '%s'\nlocation = '%s'\nfolder = '%s'\nhistory = []\n", v->name, v->loc, folder ? folder : "");
        fclose(f);
    }
}

static bool current_vault(Registry *r, Vault *out) {
    if (!r->current[0]) return false;
    int i = find_vault(r, r->current);
    if (i < 0) return false;
    *out = r->v[i];
    return true;
}

static void item_name_no_ext(const char *name, char *out, size_t n) {
    snprintf(out, n, "%s", name);
    char *dot = strchr(out, '.');
    if (dot) *dot = 0;
}

static void note_file(const char *name, char *out, size_t n) {
    snprintf(out, n, "%s", name);
    if (!strchr(name, '.')) strncat(out, ".md", n - strlen(out) - 1);
}

static void cur_path(Vault *v, char *out) {
    char root[PATH_MAX], folder[PATH_MAX];
    vault_root(v, root); read_folder(v, folder, sizeof folder);
    if (folder[0]) join2(out, PATH_MAX, root, folder);
    else snprintf(out, PATH_MAX, "%s", root);
}

static void rel_normalize(const char *base, const char *add, char *out, bool *ok) {
    char tmp[PATH_MAX];
    if (add[0] == '/') snprintf(tmp, sizeof tmp, "%s", add + 1);
    else if (base[0]) snprintf(tmp, sizeof tmp, "%s/%s", base, add);
    else snprintf(tmp, sizeof tmp, "%s", add);
    char copy[PATH_MAX]; snprintf(copy, sizeof copy, "%s", tmp);
    char *parts[256]; int n = 0; *ok = true;
    for (char *tok = strtok(copy, "/"); tok; tok = strtok(NULL, "/")) {
        if (!strcmp(tok, ".") || !*tok) continue;
        if (!strcmp(tok, "..")) {
            if (n == 0) { *ok = false; break; }
            n--;
        } else parts[n++] = tok;
    }
    out[0] = 0;
    for (int i = 0; i < n; i++) {
        if (i) strncat(out, "/", PATH_MAX - strlen(out) - 1);
        strncat(out, parts[i], PATH_MAX - strlen(out) - 1);
    }
}

static void print_main_help(void) {
    printf(BLUE "________      _____ \n______(_)_______  /_\n_____  /_  __ \\  __/\n____  / / /_/ / /_  \n___  /  \\____/\\__/  \n/___/         ᵥ₀.₁.₂  \n" RESET "         \n\n");
    printf("usage: jt <command>\n\n" BLUE "commands:" RESET "\n\n");
    printf("create items\n    " BLUE "vault" RESET ", " BLUE "vl" RESET "       create a vault or list vaults\n");
    printf("    create items in current folder\n        " BLUE "note" RESET ", " BLUE "nt" RESET "        create a note \n        " BLUE "folder" RESET ", " BLUE "fd" RESET "      create a folder\n\n");
    printf("interact with items\n    " BLUE "enter" RESET ", " BLUE "en" RESET "       enter a vault\n    " BLUE "open" RESET ", " BLUE "op" RESET "        open a note from current folder\n    " BLUE "opdir" RESET ", " BLUE "od" RESET "       open current folder in file explorer\n    " BLUE "chdir" RESET ", " BLUE "cd" RESET "       change folder within current vault\n    " BLUE "list" RESET ", " BLUE "ls" RESET "        list items in current folder\n\n");
    printf("perform fs operations on items\n    " BLUE "remove" RESET ", " BLUE "rm" RESET "      remove an item \n    " BLUE "rename" RESET ", " BLUE "rn" RESET "      rename an item \n    " BLUE "move" RESET ", " BLUE "mv" RESET "        move an item to a new location\n    " BLUE "vmove" RESET ", " BLUE "vm" RESET "       move an item to a different vault\n\n");
    printf("config\n    " BLUE "config" RESET ", " BLUE "cf" RESET "      display, set or open config\n\nget help \n    use " BLUE "help" RESET " or " BLUE "-h" RESET " and " BLUE "--help" RESET " flags along with a command to get corresponding help\n");
}

static void help_cmd(const char *c) {
    if (!strcmp(c,"vault")||!strcmp(c,"vl")) puts("executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information");
    else if (!strcmp(c,"note")||!strcmp(c,"nt")) puts("executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"folder")||!strcmp(c,"fd")) puts("executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"enter")||!strcmp(c,"en")) puts("executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"open")||!strcmp(c,"op")) puts("executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"opdir")||!strcmp(c,"od")) puts("executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"chdir")||!strcmp(c,"cd")) puts("executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"list")||!strcmp(c,"ls")) puts("executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"remove")||!strcmp(c,"rm")) puts("executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"rename")||!strcmp(c,"rn")) puts("executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"move")||!strcmp(c,"mv")) puts("executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"vmove")||!strcmp(c,"vm")) puts("executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c,"config")||!strcmp(c,"cf")) puts("executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information");
    else print_main_help();
}

static void err_msg(const char *fmt, ...) {
    va_list ap;
    printf(RED "error" RESET ": ");
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
}

static int cmd_vault(int argc, char **argv) {
    Registry r = read_registry();
    if (argc == 0 || (argc == 1 && !strcmp(argv[0], "-l"))) {
        bool loc = argc == 1;
        for (int i = 0; i < r.n; i++) {
            bool cur = r.current[0] && !strcmp(r.current, r.v[i].name);
            if (cur) printf("👉 " BLUE "%s" RESET, r.v[i].name);
            else printf("   %s", r.v[i].name);
            if (loc) printf(" \t %s", r.v[i].loc);
            printf("\n");
        }
        free(r.v); return 0;
    }
    if (argc < 2) { puts("error: The following required arguments were not provided:\n    <vault location>"); free(r.v); return 2; }
    if (find_vault(&r, argv[0]) >= 0) { err_msg("vault %s already exists", argv[0]); free(r.v); return 0; }
    r.v = realloc(r.v, sizeof(Vault) * (r.n + 1));
    snprintf(r.v[r.n].name, sizeof r.v[r.n].name, "%s", argv[0]);
    snprintf(r.v[r.n].loc, sizeof r.v[r.n].loc, "%s", argv[1]);
    r.n++;
    char root[PATH_MAX]; vault_root(&r.v[r.n-1], root); mkdir_p(root); write_data(&r.v[r.n-1], "");
    write_registry(&r);
    printf("vault " BLUE "%s" RESET " created\n", argv[0]);
    free(r.v); return 0;
}

static int cmd_enter(const char *name) {
    Registry r = read_registry(); int i = find_vault(&r, name);
    if (i < 0) { err_msg("vault %s doesn't exist", name); free(r.v); return 0; }
    snprintf(r.current, sizeof r.current, "%s", name); write_registry(&r); write_data(&r.v[i], "");
    printf("entered " BLUE "%s" RESET "\n", name); free(r.v); return 0;
}

static int need_current(Vault *v, Registry *r) {
    *r = read_registry();
    if (!current_vault(r, v)) { err_msg("%s", "no vault entered"); free(r->v); return 0; }
    return 1;
}

static int cmd_note(const char *name) {
    Vault v; Registry r; if (!need_current(&v, &r)) return 0;
    char dir[PATH_MAX], nf[PATH_MAX], p[PATH_MAX]; cur_path(&v, dir); note_file(name, nf, sizeof nf); join2(p, sizeof p, dir, nf);
    if (exists_path(p)) err_msg("a note named %s already exists in this location", name);
    else { FILE *f = fopen(p, "w"); if (f) fclose(f); printf("note " BLUE "%s" RESET " created\n", name); }
    free(r.v); return 0;
}

static int cmd_folder(const char *name) {
    Vault v; Registry r; if (!need_current(&v, &r)) return 0;
    char dir[PATH_MAX], p[PATH_MAX]; cur_path(&v, dir); join2(p, sizeof p, dir, name);
    if (exists_path(p)) err_msg("a folder named %s already exists in this location", name);
    else { mkdir_p(p); printf("folder " BLUE "%s" RESET " created\n", name); }
    free(r.v); return 0;
}

typedef struct { char *name; int type; } Ent;
static int entcmp(const void *a, const void *b) {
    const Ent *x=a,*y=b;
    return strcmp(x->name,y->name);
}

static void list_rec(const char *path, const char *prefix, int filter) {
    DIR *d = opendir(path); if (!d) return;
    Ent *e = NULL; int n = 0; struct dirent *de;
    while ((de = readdir(d))) {
        if (!strcmp(de->d_name,".")||!strcmp(de->d_name,"..")) continue;
        char p[PATH_MAX]; join2(p, sizeof p, path, de->d_name);
        bool dir = is_dir(p), note = !dir && strstr(de->d_name, ".md") && !strcmp(strstr(de->d_name, ".md"), ".md");
        if (filter == 0 && !strcmp(de->d_name, ".jot")) continue;
        if ((filter == 1 && !note) || (filter == 2 && !dir) || (filter == 0 && !dir && !note)) continue;
        e = realloc(e, sizeof(Ent)*(n+1)); e[n].name=strdup(de->d_name); e[n].type=dir?2:1; n++;
    }
    closedir(d); qsort(e,n,sizeof(Ent),entcmp);
    for (int i=0;i<n;i++) {
        bool last = i == n-1; char show[PATH_MAX];
        if (e[i].type == 1) item_name_no_ext(e[i].name, show, sizeof show); else snprintf(show,sizeof show,"%s",e[i].name);
        printf("%s%s", prefix, last ? "└── " : "├── ");
        if (e[i].type == 1) printf(BLUE "%s" RESET "\n", show); else printf("%s\n", show);
        if (e[i].type == 2) {
            char np[PATH_MAX], npre[PATH_MAX]; join2(np,sizeof np,path,e[i].name);
            snprintf(npre,sizeof npre,"%s%s",prefix,last?"    ":"│   ");
            list_rec(np,npre,filter);
        }
        free(e[i].name);
    }
    free(e);
}

static int cmd_list(const char *typ) {
    int filter = 0;
    if (typ) {
        if (!strcmp(typ,"note")||!strcmp(typ,"nt")) filter=1;
        else if (!strcmp(typ,"folder")||!strcmp(typ,"fd")) filter=2;
        else { fprintf(stderr,"error: \"%s\" isn't a valid value for '<item type>'\n\t[possible values: note, nt, folder, fd]\n\nFor more information try --help\n", typ); return 2; }
    }
    Vault v; Registry r; if (!need_current(&v, &r)) return 0;
    char root[PATH_MAX], folder[PATH_MAX], p[PATH_MAX]; vault_root(&v, root); read_folder(&v, folder, sizeof folder);
    printf("%s", v.name);
    if (folder[0]) {
        char tmp[PATH_MAX]; snprintf(tmp,sizeof tmp,"%s",folder);
        for(char *tok=strtok(tmp,"/"); tok; tok=strtok(NULL,"/")) printf(" > %s", tok);
    }
    printf("\n");
    if (folder[0]) join2(p,sizeof p,root,folder); else snprintf(p,sizeof p,"%s",root);
    list_rec(p,"",filter);
    free(r.v); return 0;
}

static bool item_path(Vault *v, const char *type, const char *name, char *p) {
    char dir[PATH_MAX], nf[PATH_MAX]; cur_path(v, dir);
    if (!strcmp(type,"note")||!strcmp(type,"nt")) { note_file(name,nf,sizeof nf); join2(p,PATH_MAX,dir,nf); }
    else { join2(p,PATH_MAX,dir,name); }
    return exists_path(p);
}

static int cmd_chdir(const char *path) {
    Vault v; Registry r; if (!need_current(&v, &r)) return 0;
    char cur[PATH_MAX], rel[PATH_MAX], root[PATH_MAX], full[PATH_MAX]; bool ok;
    if (!strcmp(path, "/")) { err_msg("%s", "path crosses the bounds of vault"); free(r.v); return 0; }
    read_folder(&v, cur, sizeof cur); rel_normalize(cur,path,rel,&ok);
    if (!ok) { err_msg("%s", "path crosses the bounds of vault"); free(r.v); return 0; }
    vault_root(&v, root); if (rel[0]) join2(full,sizeof full,root,rel); else snprintf(full,sizeof full,"%s",root);
    if (!is_dir(full)) err_msg("%s", "couldn't find the path specified");
    else { write_data(&v, rel); printf("folder changed\n"); }
    free(r.v); return 0;
}

static int cmd_remove(const char *type, const char *name) {
    Registry r = read_registry();
    if (!strcmp(type,"vault")||!strcmp(type,"vl")) {
        int i=find_vault(&r,name); if(i<0){err_msg("vault %s doesn't exist",name); free(r.v); return 0;}
        char root[PATH_MAX], cmd[PATH_MAX+32]; vault_root(&r.v[i],root); snprintf(cmd,sizeof cmd,"rm -rf -- '%s'",root); system(cmd);
        memmove(&r.v[i],&r.v[i+1],sizeof(Vault)*(r.n-i-1)); r.n--; if(!strcmp(r.current,name)) r.current[0]=0; write_registry(&r);
        printf("vault " BLUE "%s" RESET " removed\n",name); free(r.v); return 0;
    }
    Vault v; if (!current_vault(&r,&v)) { err_msg("%s","no vault entered"); free(r.v); return 0; }
    char p[PATH_MAX]; if(!item_path(&v,type,name,p)){ err_msg("%s %s not found", (!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note"); free(r.v); return 0; }
    char cmd[PATH_MAX+32]; snprintf(cmd,sizeof cmd,"rm -rf -- '%s'",p); system(cmd);
    printf("%s " BLUE "%s" RESET " removed\n",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note",name);
    free(r.v); return 0;
}

static int cmd_rename(const char *type, const char *name, const char *newn) {
    Registry r = read_registry();
    if (!strcmp(type,"vault")||!strcmp(type,"vl")) {
        int i=find_vault(&r,name); if(i<0){err_msg("vault %s doesn't exist",name); free(r.v); return 0;}
        char old[PATH_MAX], neu[PATH_MAX]; vault_root(&r.v[i],old); snprintf(r.v[i].name,sizeof r.v[i].name,"%s",newn); vault_root(&r.v[i],neu);
        rename(old,neu); if(!strcmp(r.current,name)) snprintf(r.current,sizeof r.current,"%s",newn); write_data(&r.v[i],""); write_registry(&r);
        printf("vault " BLUE "%s" RESET " renamed to " BLUE "%s" RESET "\n",name,newn); free(r.v); return 0;
    }
    Vault v; if (!current_vault(&r,&v)) { err_msg("%s","no vault entered"); free(r.v); return 0; }
    char p[PATH_MAX], dir[PATH_MAX], np[PATH_MAX], nf[PATH_MAX]; if(!item_path(&v,type,name,p)){err_msg("%s %s not found",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note"); free(r.v); return 0;}
    cur_path(&v,dir); if(!strcmp(type,"note")||!strcmp(type,"nt")){note_file(newn,nf,sizeof nf);join2(np,sizeof np,dir,nf);} else join2(np,sizeof np,dir,newn);
    rename(p,np); printf("%s " BLUE "%s" RESET " renamed to " BLUE "%s" RESET "\n",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note",name,newn);
    free(r.v); return 0;
}

static int cmd_move(const char *type, const char *name, const char *dest) {
    Vault v; Registry r; if (!need_current(&v, &r)) return 0;
    char src[PATH_MAX]; if(!item_path(&v,type,name,src)){err_msg("%s %s not found",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note"); free(r.v); return 0;}
    char cur[PATH_MAX], rel[PATH_MAX], root[PATH_MAX], dpath[PATH_MAX], base[PATH_MAX], target[PATH_MAX]; bool ok;
    read_folder(&v,cur,sizeof cur); if(!strcmp(dest,"/")){err_msg("%s","path crosses the bounds of vault"); free(r.v); return 0;} rel_normalize(cur,dest,rel,&ok); if(!ok){err_msg("%s","path crosses the bounds of vault"); free(r.v); return 0;}
    vault_root(&v,root); if(rel[0]) join2(dpath,sizeof dpath,root,rel); else snprintf(dpath,sizeof dpath,"%s",root);
    if(!is_dir(dpath)){err_msg("%s","couldn't find the path specified"); free(r.v); return 0;}
    const char *bn=strrchr(src,'/'); bn=bn?bn+1:src; snprintf(base,sizeof base,"%s",bn); join2(target,sizeof target,dpath,base);
    rename(src,target); printf("%s " BLUE "%s" RESET " moved\n",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note",name);
    free(r.v); return 0;
}

static int cmd_vmove(const char *type, const char *name, const char *vault) {
    Registry r=read_registry(); Vault cur; if(!current_vault(&r,&cur)){err_msg("%s","no vault entered"); free(r.v); return 0;}
    int vi=find_vault(&r,vault); if(vi<0){err_msg("vault %s doesn't exist",vault); free(r.v); return 0;}
    char src[PATH_MAX]; if(!item_path(&cur,type,name,src)){err_msg("%s %s not found",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note"); free(r.v); return 0;}
    char root[PATH_MAX], target[PATH_MAX]; vault_root(&r.v[vi],root); const char *bn=strrchr(src,'/'); bn=bn?bn+1:src; join2(target,sizeof target,root,bn);
    rename(src,target); printf("%s " BLUE "%s" RESET " moved to " BLUE "%s" RESET "\n",(!strcmp(type,"folder")||!strcmp(type,"fd"))?"folder":"note",name,vault);
    free(r.v); return 0;
}

static void read_config(char *editor, size_t en, char *conflict, size_t cn) {
    ensure_base(); snprintf(editor,en,"nvim"); snprintf(conflict,cn,"true");
    char p[PATH_MAX], line[1024]; snprintf(p,sizeof p,"%s/.config/jot/config",home()); FILE *f=fopen(p,"r"); if(!f) return;
    while(fgets(line,sizeof line,f)){ char *s=trim(line),*eq=strchr(s,'='); if(!eq)continue; *eq=0; char *k=trim(s),*v=trim(eq+1); strip_quotes(v); if(!strcmp(k,"editor"))snprintf(editor,en,"%s",v); else if(!strcmp(k,"conflict"))snprintf(conflict,cn,"%s",v); }
    fclose(f);
}

static int cmd_config(int argc, char **argv) {
    char editor[512], conflict[64]; read_config(editor,sizeof editor,conflict,sizeof conflict);
    if(argc==0) return 0;
    if(strcmp(argv[0],"editor")&&strcmp(argv[0],"conflict")) { fprintf(stderr,"error: \"%s\" isn't a valid value for '<config type>'\n\t[possible values: editor, conflict]\n\nFor more information try --help\n",argv[0]); return 2; }
    if(argc==1) { printf("%s: " BLUE "%s" RESET "\n",argv[0],!strcmp(argv[0],"editor")?editor:conflict); return 0; }
    if(!strcmp(argv[0],"editor")) snprintf(editor,sizeof editor,"%s",argv[1]); else snprintf(conflict,sizeof conflict,"%s",argv[1]);
    char p[PATH_MAX]; snprintf(p,sizeof p,"%s/.config/jot/config",home()); FILE*f=fopen(p,"w"); if(f){fprintf(f,"editor = '%s'\nconflict = %s\n",editor,conflict); fclose(f);}
    printf("set " BLUE "%s" RESET " to " BLUE "%s" RESET "\n",argv[0],argv[1]); return 0;
}

int main(int argc, char **argv) {
    ensure_base();
    if (argc < 2 || !strcmp(argv[1],"-h") || !strcmp(argv[1],"--help") || !strcmp(argv[1],"help")) {
        if (argc >= 3 && !strcmp(argv[1],"help")) help_cmd(argv[2]); else print_main_help();
        return 0;
    }
    char *c = argv[1];
    if (argc >= 3 && (!strcmp(argv[2],"-h") || !strcmp(argv[2],"--help"))) { help_cmd(c); return 0; }
    if (!strcmp(c,"vault")||!strcmp(c,"vl")) return cmd_vault(argc-2, argv+2);
    if (!strcmp(c,"enter")||!strcmp(c,"en")) { if(argc<3){puts("error: The following required arguments were not provided:\n    <vault name>"); return 2;} return cmd_enter(argv[2]); }
    if (!strcmp(c,"note")||!strcmp(c,"nt")) { if(argc<3){puts("error: The following required arguments were not provided:\n    <note name>\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nFor more information try --help"); return 2;} return cmd_note(argv[2]); }
    if (!strcmp(c,"folder")||!strcmp(c,"fd")) { if(argc<3){puts("error: The following required arguments were not provided:\n    <folder name>"); return 2;} return cmd_folder(argv[2]); }
    if (!strcmp(c,"list")||!strcmp(c,"ls")) return cmd_list(argc>=3?argv[2]:NULL);
    if (!strcmp(c,"chdir")||!strcmp(c,"cd")) { if(argc<3)return 2; return cmd_chdir(argv[2]); }
    if (!strcmp(c,"remove")||!strcmp(c,"rm")) { if(argc<4)return 2; return cmd_remove(argv[2],argv[3]); }
    if (!strcmp(c,"rename")||!strcmp(c,"rn")) { if(argc<5)return 2; return cmd_rename(argv[2],argv[3],argv[4]); }
    if (!strcmp(c,"move")||!strcmp(c,"mv")) { if(argc<5)return 2; return cmd_move(argv[2],argv[3],argv[4]); }
    if (!strcmp(c,"vmove")||!strcmp(c,"vm")) { if(argc<5)return 2; return cmd_vmove(argv[2],argv[3],argv[4]); }
    if (!strcmp(c,"config")||!strcmp(c,"cf")) return cmd_config(argc-2, argv+2);
    if (!strcmp(c,"open")||!strcmp(c,"op")) return 0;
    if (!strcmp(c,"opdir")||!strcmp(c,"od")) return 0;
    fprintf(stderr,"error: The subcommand '%s' wasn't recognized\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help\n", c);
    return 2;
}
