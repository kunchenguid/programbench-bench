#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <expat.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct Attr {
    char *name;
    char *value;
} Attr;

typedef struct Node {
    char *name;
    Attr *attrs;
    int attr_count, attr_cap;
    struct Node **children;
    int child_count, child_cap;
    struct Node *parent;
    char *text;
    size_t text_len, text_cap;
} Node;

typedef struct {
    Node *doc;
    Node *cur;
} ParseCtx;

typedef struct {
    int indent;
    bool tab, html, json, compact, node, inplace;
    int depth;
    char *xpath, *extract, *query, *attr;
    char *file;
} Opts;

static void *xmalloc(size_t n) {
    void *p = calloc(1, n ? n : 1);
    if (!p) { perror("calloc"); exit(1); }
    return p;
}

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) { perror("strdup"); exit(1); }
    return p;
}

static Node *new_node(const char *name) {
    Node *n = xmalloc(sizeof(Node));
    n->name = xstrdup(name);
    return n;
}

static void add_child(Node *p, Node *c) {
    if (p->child_count == p->child_cap) {
        p->child_cap = p->child_cap ? p->child_cap * 2 : 8;
        p->children = realloc(p->children, sizeof(Node*) * p->child_cap);
        if (!p->children) exit(1);
    }
    p->children[p->child_count++] = c;
    c->parent = p;
}

static void add_attr(Node *n, const char *k, const char *v) {
    if (n->attr_count == n->attr_cap) {
        n->attr_cap = n->attr_cap ? n->attr_cap * 2 : 4;
        n->attrs = realloc(n->attrs, sizeof(Attr) * n->attr_cap);
        if (!n->attrs) exit(1);
    }
    n->attrs[n->attr_count].name = xstrdup(k);
    n->attrs[n->attr_count].value = xstrdup(v ? v : "");
    n->attr_count++;
}

static const char *get_attr(Node *n, const char *k) {
    for (int i = 0; i < n->attr_count; i++)
        if (strcmp(n->attrs[i].name, k) == 0) return n->attrs[i].value;
    return NULL;
}

static void append_text_len(Node *n, const char *s, int len) {
    if (len <= 0) return;
    if (n->text_len + len + 1 > n->text_cap) {
        n->text_cap = (n->text_len + len + 1) * 2;
        n->text = realloc(n->text, n->text_cap);
        if (!n->text) exit(1);
    }
    memcpy(n->text + n->text_len, s, len);
    n->text_len += len;
    n->text[n->text_len] = 0;
}

static char *trim_dup(const char *s) {
    if (!s) return xstrdup("");
    while (isspace((unsigned char)*s)) s++;
    const char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) e--;
    char *r = xmalloc((size_t)(e - s) + 1);
    memcpy(r, s, (size_t)(e - s));
    return r;
}

static void collect_text(Node *n, char **buf, size_t *len, size_t *cap) {
    char *t = trim_dup(n->text);
    if (*t) {
        if (*len && (*buf)[*len - 1] != ' ') {
            if (*len + 2 > *cap) { *cap = (*len + 64) * 2; *buf = realloc(*buf, *cap); }
            (*buf)[(*len)++] = ' ';
        }
        size_t tl = strlen(t);
        if (*len + tl + 1 > *cap) { *cap = (*len + tl + 64) * 2; *buf = realloc(*buf, *cap); }
        memcpy(*buf + *len, t, tl); *len += tl; (*buf)[*len] = 0;
    }
    free(t);
    for (int i = 0; i < n->child_count; i++) collect_text(n->children[i], buf, len, cap);
}

static char *node_text(Node *n) {
    size_t cap = 64, len = 0;
    char *b = xmalloc(cap);
    b[0] = 0;
    collect_text(n, &b, &len, &cap);
    return b;
}

static void free_node(Node *n) {
    if (!n) return;
    free(n->name);
    for (int i = 0; i < n->attr_count; i++) { free(n->attrs[i].name); free(n->attrs[i].value); }
    free(n->attrs);
    for (int i = 0; i < n->child_count; i++) free_node(n->children[i]);
    free(n->children);
    free(n->text);
    free(n);
}

static void XMLCALL start_el(void *ud, const char *name, const char **atts) {
    ParseCtx *c = ud;
    Node *n = new_node(name);
    for (int i = 0; atts && atts[i]; i += 2) add_attr(n, atts[i], atts[i+1]);
    add_child(c->cur, n);
    c->cur = n;
}

static void XMLCALL end_el(void *ud, const char *name) {
    (void)name;
    ParseCtx *c = ud;
    if (c->cur->parent) c->cur = c->cur->parent;
}

static void XMLCALL char_data(void *ud, const XML_Char *s, int len) {
    ParseCtx *c = ud;
    append_text_len(c->cur, s, len);
}

static char *read_all(const char *file) {
    FILE *f = file ? fopen(file, "rb") : stdin;
    if (!f) {
        fprintf(stderr, "Error: open %s: %s\n", file, strerror(errno));
        exit(1);
    }
    size_t cap = 8192, len = 0;
    char *b = xmalloc(cap + 1);
    for (;;) {
        if (len == cap) { cap *= 2; b = realloc(b, cap + 1); if (!b) exit(1); }
        size_t n = fread(b + len, 1, cap - len, f);
        len += n;
        if (n == 0) break;
    }
    if (file) fclose(f);
    b[len] = 0;
    return b;
}

static Node *parse_xml(const char *input) {
    ParseCtx ctx;
    ctx.doc = new_node("#document");
    ctx.cur = ctx.doc;
    XML_Parser p = XML_ParserCreate(NULL);
    XML_SetUserData(p, &ctx);
    XML_SetElementHandler(p, start_el, end_el);
    XML_SetCharacterDataHandler(p, char_data);
    if (XML_Parse(p, input, (int)strlen(input), XML_TRUE) == XML_STATUS_ERROR) {
        fprintf(stderr, "Error: XML syntax error on line %lu: %s\n",
                XML_GetCurrentLineNumber(p), XML_ErrorString(XML_GetErrorCode(p)));
        XML_ParserFree(p);
        free_node(ctx.doc);
        exit(1);
    }
    XML_ParserFree(p);
    return ctx.doc;
}

static void lower(char *s) { for (; *s; s++) *s = (char)tolower((unsigned char)*s); }

static bool void_html(const char *s) {
    const char *v[] = {"area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr",NULL};
    for (int i = 0; v[i]; i++) if (!strcmp(s, v[i])) return true;
    return false;
}

static Node *parse_html(const char *in) {
    Node *doc = new_node("#document");
    Node *cur = doc;
    const char *p = in;
    while (*p) {
        const char *lt = strchr(p, '<');
        if (!lt) { append_text_len(cur, p, (int)strlen(p)); break; }
        append_text_len(cur, p, (int)(lt - p));
        if (!strncmp(lt, "<!--", 4)) {
            const char *e = strstr(lt + 4, "-->");
            p = e ? e + 3 : lt + strlen(lt);
            continue;
        }
        const char *gt = strchr(lt, '>');
        if (!gt) break;
        char *tag = xmalloc((size_t)(gt - lt));
        memcpy(tag, lt + 1, (size_t)(gt - lt - 1)); tag[gt - lt - 1] = 0;
        char *q = tag;
        while (isspace((unsigned char)*q)) q++;
        bool end = *q == '/';
        if (end) q++;
        while (isspace((unsigned char)*q)) q++;
        char name[128]; int ni = 0;
        while (*q && !isspace((unsigned char)*q) && *q != '/' && ni < 127) name[ni++] = *q++;
        name[ni] = 0; lower(name);
        if (*name && !end && *name != '!' && *name != '?') {
            Node *n = new_node(name);
            while (*q) {
                while (isspace((unsigned char)*q) || *q == '/') q++;
                if (!*q) break;
                char an[128]; int ai = 0;
                while (*q && *q != '=' && !isspace((unsigned char)*q) && *q != '/' && ai < 127) an[ai++] = *q++;
                an[ai] = 0; lower(an);
                while (isspace((unsigned char)*q)) q++;
                char av[1024] = "";
                if (*q == '=') {
                    q++; while (isspace((unsigned char)*q)) q++;
                    char quote = (*q == '"' || *q == '\'') ? *q++ : 0;
                    int vi = 0;
                    while (*q && ((quote && *q != quote) || (!quote && !isspace((unsigned char)*q) && *q != '/')) && vi < 1023) av[vi++] = *q++;
                    av[vi] = 0;
                    if (quote && *q == quote) q++;
                }
                if (*an) add_attr(n, an, av);
            }
            add_child(cur, n);
            if (!void_html(name) && gt[-1] != '/') cur = n;
        } else if (*name) {
            Node *t = cur;
            while (t != doc && strcmp(t->name, name) != 0) t = t->parent;
            if (t != doc && t->parent) cur = t->parent;
        }
        free(tag);
        p = gt + 1;
    }
    return doc;
}

static void print_indent(int level, const Opts *o) {
    if (o->compact) return;
    for (int i = 0; i < level; i++) {
        if (o->tab) putchar('\t');
        else for (int j = 0; j < o->indent; j++) putchar(' ');
    }
}

static void print_escaped_text(const char *s) {
    for (; s && *s; s++) {
        if (*s == '&') printf("&amp;");
        else if (*s == '<') printf("&lt;");
        else if (*s == '>') printf("&gt;");
        else putchar(*s);
    }
}

static void print_attrs(Node *n) {
    for (int i = 0; i < n->attr_count; i++) printf(" %s=\"%s\"", n->attrs[i].name, n->attrs[i].value);
}

static void serialize(Node *n, int level, const Opts *o) {
    char *t = trim_dup(n->text);
    print_indent(level, o);
    printf("<%s", n->name); print_attrs(n);
    if (n->child_count == 0 && !*t && !(o->html && !void_html(n->name))) {
        printf("/>\n"); free(t); return;
    }
    if (n->child_count == 0) {
        printf(">"); print_escaped_text(t); printf("</%s>\n", n->name); free(t); return;
    }
    if (*t) {
        printf(">"); print_escaped_text(t); putchar('\n');
    } else printf(">\n");
    for (int i = 0; i < n->child_count; i++) serialize(n->children[i], level + 1, o);
    print_indent(level, o);
    printf("</%s>\n", n->name);
    free(t);
}

typedef struct { Node **v; int n, cap; } NList;
static void nl_add(NList *l, Node *n) {
    if (l->n == l->cap) { l->cap = l->cap ? l->cap * 2 : 16; l->v = realloc(l->v, sizeof(Node*) * l->cap); if (!l->v) exit(1); }
    l->v[l->n++] = n;
}

static char **split_path(const char *path, int *count) {
    char *tmp = xstrdup(path);
    char **parts = NULL; int n = 0, cap = 0;
    for (char *tok = strtok(tmp, "/"); tok; tok = strtok(NULL, "/")) {
        if (!*tok) continue;
        if (n == cap) { cap = cap ? cap * 2 : 8; parts = realloc(parts, sizeof(char*) * cap); }
        parts[n++] = xstrdup(tok);
    }
    free(tmp); *count = n; return parts;
}

static void find_desc(Node *n, const char *name, NList *out) {
    for (int i = 0; i < n->child_count; i++) {
        if (!strcmp(n->children[i]->name, name)) nl_add(out, n->children[i]);
        find_desc(n->children[i], name, out);
    }
}

static NList xpath_nodes(Node *doc, const char *xp, char **attr_out) {
    NList cur = {0};
    *attr_out = NULL;
    if (!xp || !*xp) return cur;
    if (!strncmp(xp, "//", 2)) {
        const char *name = xp + 2;
        const char *slash = strchr(name, '/');
        if (!slash) { find_desc(doc, name, &cur); return cur; }
    }
    int pc = 0; char **parts = split_path(xp, &pc);
    if (pc && parts[pc-1][0] == '@') { *attr_out = xstrdup(parts[pc-1] + 1); free(parts[--pc]); }
    nl_add(&cur, doc);
    for (int i = 0; i < pc; i++) {
        NList next = {0};
        for (int j = 0; j < cur.n; j++) {
            for (int k = 0; k < cur.v[j]->child_count; k++)
                if (!strcmp(cur.v[j]->children[k]->name, parts[i])) nl_add(&next, cur.v[j]->children[k]);
        }
        free(cur.v); cur = next;
        free(parts[i]);
    }
    free(parts);
    return cur;
}

typedef struct { char tag[128], cls[128], id[128]; } Sel;

static Sel parse_sel(const char *s) {
    Sel r; memset(&r, 0, sizeof(r));
    while (isspace((unsigned char)*s)) s++;
    int ti = 0;
    while (*s && *s != '.' && *s != '#' && !isspace((unsigned char)*s) && *s != '>' && ti < 127) r.tag[ti++] = *s++;
    r.tag[ti] = 0; lower(r.tag);
    while (*s) {
        if (*s == '.') { s++; int i = 0; while (*s && *s!='.' && *s!='#' && !isspace((unsigned char)*s) && *s!='>' && i<127) r.cls[i++]=*s++; r.cls[i]=0; }
        else if (*s == '#') { s++; int i = 0; while (*s && *s!='.' && *s!='#' && !isspace((unsigned char)*s) && *s!='>' && i<127) r.id[i++]=*s++; r.id[i]=0; }
        else s++;
    }
    return r;
}

static bool class_has(const char *classes, const char *cls) {
    if (!cls[0]) return true;
    if (!classes) return false;
    size_t cl = strlen(cls);
    const char *p = classes;
    while (*p) {
        while (isspace((unsigned char)*p)) p++;
        if (!strncmp(p, cls, cl) && (p[cl] == 0 || isspace((unsigned char)p[cl]))) return true;
        while (*p && !isspace((unsigned char)*p)) p++;
    }
    return false;
}

static bool match_sel(Node *n, Sel *s) {
    if (s->tag[0] && strcmp(n->name, s->tag)) return false;
    if (s->id[0]) { const char *id = get_attr(n, "id"); if (!id || strcmp(id, s->id)) return false; }
    if (!class_has(get_attr(n, "class"), s->cls)) return false;
    return true;
}

static void desc_sel(Node *n, Sel *s, NList *out) {
    for (int i = 0; i < n->child_count; i++) {
        if (match_sel(n->children[i], s)) nl_add(out, n->children[i]);
        desc_sel(n->children[i], s, out);
    }
}

static NList css_query(Node *doc, const char *q) {
    char *tmp = xstrdup(q);
    bool child = strchr(tmp, '>') != NULL;
    NList cur = {0}; nl_add(&cur, doc);
    char *save = NULL;
    const char *delim = child ? ">" : " ";
    int step = 0;
    for (char *tok = strtok_r(tmp, delim, &save); tok; tok = strtok_r(NULL, delim, &save), step++) {
        Sel s = parse_sel(tok);
        NList next = {0};
        for (int i = 0; i < cur.n; i++) {
            if (child && step > 0) {
                for (int k = 0; k < cur.v[i]->child_count; k++) if (match_sel(cur.v[i]->children[k], &s)) nl_add(&next, cur.v[i]->children[k]);
            } else desc_sel(cur.v[i], &s, &next);
        }
        free(cur.v); cur = next;
    }
    free(tmp); return cur;
}

static void json_string(const char *s) {
    putchar('"');
    for (; s && *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') { putchar('\\'); putchar(c); }
        else if (c == '\n') printf("\\n");
        else if (c == '\r') printf("\\r");
        else if (c == '\t') printf("\\t");
        else if (c < 32) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

static int cmp_names(const void *a, const void *b) {
    Node * const *na = a, * const *nb = b;
    return strcmp((*na)->name, (*nb)->name);
}

static void json_node(Node *n, int level, const Opts *o, int maxdepth);

static void json_value(Node *n, int level, const Opts *o, int maxdepth) {
    char *t = node_text(n);
    if (maxdepth == 0 && (n->child_count || n->attr_count)) {
        json_string(t); free(t); return;
    }
    if (n->child_count == 0 && n->attr_count == 0 && *t) { json_string(t); free(t); return; }
    free(t); json_node(n, level, o, maxdepth < 0 ? -1 : maxdepth - 1);
}

static void jnl(int level, const Opts *o) { if (!o->compact) { putchar('\n'); print_indent(level, o); } }
static void jsep(const Opts *o) { if (!o->compact) printf(": "); else printf(": "); }

static void json_node(Node *n, int level, const Opts *o, int maxdepth) {
    putchar('{');
    int fields = 0;
    char *t = trim_dup(n->text);
    if (*t) {
        jnl(level + 1, o); json_string("#text"); jsep(o); json_string(t); fields++;
    }
    for (int i = 0; i < n->attr_count; i++) {
        if (fields++) putchar(',');
        jnl(level + 1, o);
        char key[512]; snprintf(key, sizeof(key), "@%s", n->attrs[i].name);
        json_string(key); jsep(o); json_string(n->attrs[i].value);
    }
    if (n->child_count) {
        Node **arr = xmalloc(sizeof(Node*) * n->child_count);
        memcpy(arr, n->children, sizeof(Node*) * n->child_count);
        qsort(arr, n->child_count, sizeof(Node*), cmp_names);
        for (int i = 0; i < n->child_count; ) {
            int j = i + 1; while (j < n->child_count && !strcmp(arr[i]->name, arr[j]->name)) j++;
            if (fields++) putchar(',');
            jnl(level + 1, o); json_string(arr[i]->name); jsep(o);
            if (j - i == 1) json_value(arr[i], level + 1, o, maxdepth);
            else {
                putchar('[');
                for (int k = i; k < j; k++) {
                    if (k > i) putchar(',');
                    jnl(level + 2, o);
                    json_value(arr[k], level + 2, o, maxdepth);
                }
                jnl(level + 1, o); putchar(']');
            }
            i = j;
        }
        free(arr);
    }
    if (fields || !o->compact) jnl(level, o);
    putchar('}');
    free(t);
}

static void print_selection(NList l, const char *attr, const Opts *o) {
    for (int i = 0; i < l.n; i++) {
        if (attr) {
            const char *v = get_attr(l.v[i], attr);
            if (v) printf("%s\n", v);
        } else if (o->node) {
            serialize(l.v[i], 0, o);
        } else {
            char *t = node_text(l.v[i]);
            printf("%s\n", t);
            free(t);
        }
    }
}

static void usage(void) {
    printf("Command-line XML and HTML beautifier and content extractor\n\n");
    printf("Usage:\n  xq [flags]\n\nFlags:\n");
    printf("  -a, --attr string      Extract an attribute value instead of node content for provided CSS query\n");
    printf("  -c, --color            Force colorful output\n");
    printf("      --compact          Compact JSON output (no indentation)\n");
    printf("  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)\n");
    printf("  -e, --extract string   Extract a single node from XML\n");
    printf("  -h, --help             Print this help message\n");
    printf("  -m, --html             Use HTML formatter\n");
    printf("  -i, --in-place         Format file in place\n");
    printf("      --indent int       Use the given number of spaces for indentation (default 2)\n");
    printf("  -j, --json             Output the result as JSON\n");
    printf("      --no-color         Disable colorful output\n");
    printf("  -n, --node             Return the node content instead of text\n");
    printf("  -q, --query string     Extract the node(s) using CSS selector\n");
    printf("      --tab              Use tabs for indentation\n");
    printf("  -v, --version          Print version information\n");
    printf("  -x, --xpath string     Extract the node(s) from XML\n");
}

static char *capture_format(Node *doc, Opts *o) {
    char *path = "/tmp/xq_capture_XXXXXX";
    char tmpl[64]; strcpy(tmpl, path);
    int fd = mkstemp(tmpl);
    if (fd < 0) return NULL;
    FILE *old = stdout;
    FILE *f = fdopen(fd, "w+");
    stdout = f;
    for (int i = 0; i < doc->child_count; i++) serialize(doc->children[i], 0, o);
    fflush(f);
    long sz = ftell(f);
    rewind(f);
    char *buf = xmalloc((size_t)sz + 1);
    size_t got = fread(buf, 1, (size_t)sz, f);
    buf[got] = 0;
    stdout = old;
    fclose(f); unlink(tmpl);
    return buf;
}

int main(int argc, char **argv) {
    Opts o = {.indent = 2, .depth = -1};
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(); return 0; }
        else if (!strcmp(a, "-v") || !strcmp(a, "--version")) { printf("xq version 1.4.0\n"); return 0; }
        else if (!strcmp(a, "-c") || !strcmp(a, "--color") || !strcmp(a, "--no-color")) {}
        else if (!strcmp(a, "-m") || !strcmp(a, "--html")) o.html = true;
        else if (!strcmp(a, "-i") || !strcmp(a, "--in-place")) o.inplace = true;
        else if (!strcmp(a, "-j") || !strcmp(a, "--json")) o.json = true;
        else if (!strcmp(a, "-n") || !strcmp(a, "--node")) o.node = true;
        else if (!strcmp(a, "--tab")) o.tab = true;
        else if (!strcmp(a, "--compact")) o.compact = true;
        else if ((!strcmp(a, "--indent") || !strcmp(a, "-d") || !strcmp(a, "--depth") || !strcmp(a, "-x") || !strcmp(a, "--xpath") || !strcmp(a, "-e") || !strcmp(a, "--extract") || !strcmp(a, "-q") || !strcmp(a, "--query") || !strcmp(a, "-a") || !strcmp(a, "--attr")) && i + 1 >= argc) {
            fprintf(stderr, "Error: flag needs an argument: %s\n", a); return 1;
        } else if (!strcmp(a, "--indent")) o.indent = atoi(argv[++i]);
        else if (!strcmp(a, "-d") || !strcmp(a, "--depth")) o.depth = atoi(argv[++i]);
        else if (!strcmp(a, "-x") || !strcmp(a, "--xpath")) o.xpath = argv[++i];
        else if (!strcmp(a, "-e") || !strcmp(a, "--extract")) o.extract = argv[++i];
        else if (!strcmp(a, "-q") || !strcmp(a, "--query")) o.query = argv[++i];
        else if (!strcmp(a, "-a") || !strcmp(a, "--attr")) o.attr = argv[++i];
        else if (a[0] == '-') { fprintf(stderr, "Error: unknown flag: %s\n", a); return 1; }
        else o.file = a;
    }
    char *input = read_all(o.file);
    Node *doc = o.html ? parse_html(input) : parse_xml(input);
    if (o.query) {
        NList l = css_query(doc, o.query);
        print_selection(l, o.attr, &o);
        free(l.v);
    } else if (o.xpath || o.extract) {
        char *attr = NULL;
        NList l = xpath_nodes(doc, o.xpath ? o.xpath : o.extract, &attr);
        if (o.extract && l.n > 1) l.n = 1;
        print_selection(l, attr, &o);
        free(attr); free(l.v);
    } else if (o.json) {
        putchar('{');
        if (doc->child_count == 1) {
            jnl(1, &o);
            json_string(doc->children[0]->name);
            jsep(&o);
            json_value(doc->children[0], 1, &o, o.depth);
        } else {
            for (int i = 0; i < doc->child_count; i++) {
                if (i) putchar(',');
                jnl(1, &o);
                json_string(doc->children[i]->name);
                jsep(&o);
                json_value(doc->children[i], 1, &o, o.depth);
            }
        }
        jnl(0, &o);
        putchar('}');
        putchar('\n');
    } else if (o.inplace && o.file) {
        char *buf = capture_format(doc, &o);
        FILE *f = fopen(o.file, "wb");
        if (!f) { fprintf(stderr, "Error: open %s: %s\n", o.file, strerror(errno)); return 1; }
        fputs(buf, f); fclose(f); free(buf);
    } else {
        for (int i = 0; i < doc->child_count; i++) serialize(doc->children[i], 0, &o);
    }
    free_node(doc);
    free(input);
    return 0;
}
