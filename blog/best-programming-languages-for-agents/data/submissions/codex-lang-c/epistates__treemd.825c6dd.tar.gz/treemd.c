#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

typedef struct {
    int level;
    char *title;
    int line;
    long offset;
    int parent;
} Heading;

typedef struct {
    char *text;
    char *url;
    int line;
} Link;

typedef struct {
    char *lang;
    char *body;
    int line;
} Code;

typedef struct {
    char **lines;
    int line_count;
    Heading *heads;
    int head_count, head_cap;
    Link *links;
    int link_count, link_cap;
    Code *codes;
    int code_count, code_cap;
    int word_count;
} Doc;

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { perror("strdup"); exit(1); }
    return r;
}

static char *trim_copy(const char *s) {
    while (*s && isspace((unsigned char)*s)) s++;
    size_t n = strlen(s);
    while (n && isspace((unsigned char)s[n-1])) n--;
    char *r = malloc(n + 1);
    if (!r) exit(1);
    memcpy(r, s, n);
    r[n] = 0;
    return r;
}

static void add_heading(Doc *d, int level, const char *title, int line, long offset) {
    if (d->head_count == d->head_cap) {
        d->head_cap = d->head_cap ? d->head_cap * 2 : 32;
        d->heads = realloc(d->heads, d->head_cap * sizeof(Heading));
        if (!d->heads) exit(1);
    }
    int parent = -1;
    for (int i = d->head_count - 1; i >= 0; --i) {
        if (d->heads[i].level < level) { parent = i; break; }
    }
    d->heads[d->head_count++] = (Heading){level, xstrdup(title), line, offset, parent};
}

static void add_link(Doc *d, const char *text, size_t tn, const char *url, size_t un, int line) {
    if (d->link_count == d->link_cap) {
        d->link_cap = d->link_cap ? d->link_cap * 2 : 16;
        d->links = realloc(d->links, d->link_cap * sizeof(Link));
        if (!d->links) exit(1);
    }
    char *t = malloc(tn + 1), *u = malloc(un + 1);
    if (!t || !u) exit(1);
    memcpy(t, text, tn); t[tn] = 0;
    memcpy(u, url, un); u[un] = 0;
    d->links[d->link_count++] = (Link){t, u, line};
}

static void add_code(Doc *d, const char *lang, const char *body, int line) {
    if (d->code_count == d->code_cap) {
        d->code_cap = d->code_cap ? d->code_cap * 2 : 8;
        d->codes = realloc(d->codes, d->code_cap * sizeof(Code));
        if (!d->codes) exit(1);
    }
    d->codes[d->code_count++] = (Code){xstrdup(lang), xstrdup(body), line};
}

static int heading_line(const char *s, int *level, char **title) {
    const char *p = s;
    int spaces = 0;
    while (*p == ' ' && spaces < 4) { p++; spaces++; }
    int n = 0;
    while (p[n] == '#') n++;
    if (n < 1 || n > 6) return 0;
    if (p[n] && !isspace((unsigned char)p[n])) return 0;
    p += n;
    while (*p && isspace((unsigned char)*p)) p++;
    char *t = trim_copy(p);
    size_t len = strlen(t);
    while (len && t[len-1] == '#') {
        size_t j = len - 1;
        while (j && t[j-1] == '#') j--;
        if (j && isspace((unsigned char)t[j-1])) {
            while (j && isspace((unsigned char)t[j-1])) j--;
            t[j] = 0; len = j;
        } else break;
    }
    *level = n;
    *title = t;
    return 1;
}

static void scan_links(Doc *d, const char *s, int line) {
    const char *p = s;
    while ((p = strchr(p, '['))) {
        if (p > s && p[-1] == '!') { p++; continue; }
        const char *rb = strchr(p + 1, ']');
        if (!rb || rb[1] != '(') { p++; continue; }
        const char *rp = strchr(rb + 2, ')');
        if (!rp) { p++; continue; }
        add_link(d, p + 1, (size_t)(rb - p - 1), rb + 2, (size_t)(rp - rb - 2), line);
        p = rp + 1;
    }
}

static void count_words(Doc *d, const char *s) {
    int in = 0;
    for (; *s; s++) {
        if (isalnum((unsigned char)*s)) {
            if (!in) d->word_count++;
            in = 1;
        } else in = 0;
    }
}

static char *read_stream(FILE *f) {
    size_t cap = 8192, len = 0;
    char *buf = malloc(cap);
    if (!buf) exit(1);
    int c;
    while ((c = fgetc(f)) != EOF) {
        if (len + 1 >= cap) {
            cap *= 2; buf = realloc(buf, cap);
            if (!buf) exit(1);
        }
        buf[len++] = (char)c;
    }
    buf[len] = 0;
    return buf;
}

static char *read_path(const char *path) {
    FILE *f;
    if (!path || strcmp(path, "-") == 0) f = stdin;
    else f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "Error reading input: I/O error: %s (os error %d)\n", strerror(errno), errno);
        exit(1);
    }
    char *s = read_stream(f);
    if (f != stdin) fclose(f);
    return s;
}

static void parse_doc(Doc *d, char *content) {
    memset(d, 0, sizeof(*d));
    int cap = 64;
    d->lines = malloc(cap * sizeof(char*));
    if (!d->lines) exit(1);
    char *p = content;
    long offset = 0;
    int in_code = 0, code_start = 0;
    char code_lang[128] = "";
    char *code_body = NULL;
    size_t code_len = 0, code_cap = 0;
    while (*p) {
        char *start = p;
        while (*p && *p != '\n') p++;
        size_t raw_len = (size_t)(p - start);
        char *line = malloc(raw_len + 1);
        if (!line) exit(1);
        memcpy(line, start, raw_len); line[raw_len] = 0;
        if (*p == '\n') p++;
        if (d->line_count == cap) {
            cap *= 2; d->lines = realloc(d->lines, cap * sizeof(char*));
            if (!d->lines) exit(1);
        }
        d->lines[d->line_count++] = line;
        int lineno = d->line_count;
        const char *t = line;
        while (*t == ' ' || *t == '\t') t++;
        if (strncmp(t, "```", 3) == 0 || strncmp(t, "~~~", 3) == 0) {
            if (!in_code) {
                in_code = 1; code_start = lineno;
                snprintf(code_lang, sizeof(code_lang), "%s", t + 3);
                char *tc = trim_copy(code_lang);
                snprintf(code_lang, sizeof(code_lang), "%s", tc);
                free(tc);
                free(code_body); code_body = xstrdup(""); code_len = 0; code_cap = 1;
            } else {
                in_code = 0;
                add_code(d, code_lang, code_body ? code_body : "", code_start);
            }
        } else if (in_code) {
            size_t need = code_len + strlen(line) + 2;
            if (need > code_cap) {
                code_cap = need * 2; code_body = realloc(code_body, code_cap);
                if (!code_body) exit(1);
            }
            strcpy(code_body + code_len, line);
            code_len += strlen(line);
            strcpy(code_body + code_len, "\n");
            code_len++;
        } else {
            int lev; char *title = NULL;
            if (heading_line(line, &lev, &title)) {
                add_heading(d, lev, title, lineno, offset + (long)raw_len + 1);
                free(title);
            }
            scan_links(d, line, lineno);
            count_words(d, line);
        }
        offset += (long)raw_len + 1;
    }
    free(code_body);
}

static void print_marks(int n) { for (int i = 0; i < n; i++) putchar('#'); }

static int contains_ci(const char *hay, const char *needle) {
    if (!needle || !*needle) return 1;
    size_t nl = strlen(needle);
    for (; *hay; hay++) if (strncasecmp(hay, needle, nl) == 0) return 1;
    return 0;
}

static int match_heading(Heading *h, int level, const char *filter) {
    return (!level || h->level == level) && contains_ci(h->title, filter);
}

static void output_list(Doc *d, int level, const char *filter) {
    for (int i = 0; i < d->head_count; i++) if (match_heading(&d->heads[i], level, filter)) {
        print_marks(d->heads[i].level);
        printf(" %s\n", d->heads[i].title);
    }
}

static int has_visible_child(Doc *d, int idx, int level, const char *filter) {
    for (int i = idx + 1; i < d->head_count; i++) {
        int p = d->heads[i].parent;
        while (p >= 0) {
            if (p == idx && match_heading(&d->heads[i], level, filter)) return 1;
            p = d->heads[p].parent;
        }
    }
    return 0;
}

static int is_last_visible_sibling(Doc *d, int idx, int level, const char *filter) {
    int par = d->heads[idx].parent;
    for (int i = idx + 1; i < d->head_count; i++) {
        if (d->heads[i].parent == par && (match_heading(&d->heads[i], level, filter) || has_visible_child(d, i, level, filter))) return 0;
    }
    return 1;
}

static void tree_rec(Doc *d, int idx, int level, const char *filter, int *anc_last, int depth) {
    int self = match_heading(&d->heads[idx], level, filter);
    if (self) {
        for (int j = 0; j < depth; j++) printf("%s", anc_last[j] ? "   " : "\xE2\x94\x82  ");
        int last = is_last_visible_sibling(d, idx, level, filter);
        printf("%s", last ? "\xE2\x94\x94\xE2\x94\x80\xE2\x94\x80" : "\xE2\x94\x9C\xE2\x94\x80\xE2\x94\x80");
        print_marks(d->heads[idx].level);
        printf(" %s\n", d->heads[idx].title);
        anc_last[depth++] = last;
    }
    for (int i = idx + 1; i < d->head_count; i++) if (d->heads[i].parent == idx) {
        if (match_heading(&d->heads[i], level, filter) || has_visible_child(d, i, level, filter))
            tree_rec(d, i, level, filter, anc_last, depth);
    }
}

static void output_tree(Doc *d, int level, const char *filter) {
    int anc[128] = {0};
    for (int i = 0; i < d->head_count; i++) if (d->heads[i].parent < 0) {
        if (match_heading(&d->heads[i], level, filter) || has_visible_child(d, i, level, filter))
            tree_rec(d, i, level, filter, anc, 0);
    }
}

static void json_escape(const char *s) {
    putchar('"');
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') printf("\\%c", c);
        else if (c == '\n') printf("\\n");
        else if (c == '\t') printf("\\t");
        else if (c < 32) printf("\\u%04x", c);
        else putchar(c);
    }
    putchar('"');
}

static char *slugify(const char *s) {
    char *r = malloc(strlen(s) * 2 + 1), *o = r;
    int dash = 0;
    if (!r) exit(1);
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        if (isalnum(c)) { *o++ = (char)tolower(c); dash = 0; }
        else if (!dash && o != r) { *o++ = '-'; dash = 1; }
    }
    if (o > r && o[-1] == '-') o--;
    *o = 0;
    return r;
}

static void print_json_headings(Doc *d) {
    printf("{\n  \"document\": {\n    \"metadata\": {\n      \"source\": null,\n      \"headingCount\": %d,\n      \"maxDepth\": ", d->head_count);
    int max = 0; for (int i = 0; i < d->head_count; i++) if (d->heads[i].level > max) max = d->heads[i].level;
    printf("%d,\n      \"wordCount\": %d\n    },\n    \"sections\": [\n", max ? max : 0, d->word_count);
    for (int i = 0; i < d->head_count; i++) {
        char *slug = slugify(d->heads[i].title);
        printf("      {\"id\": "); json_escape(slug);
        printf(", \"level\": %d, \"title\": ", d->heads[i].level); json_escape(d->heads[i].title);
        printf(", \"slug\": "); json_escape(slug);
        printf(", \"position\": {\"line\": %d, \"offset\": %ld}, \"children\": []}%s\n", d->heads[i].line, d->heads[i].offset, i == d->head_count-1 ? "" : ",");
        free(slug);
    }
    printf("    ]\n  }\n}\n");
}

static void output_count(Doc *d) {
    int c[7] = {0}, total = 0;
    for (int i = 0; i < d->head_count; i++) { c[d->heads[i].level]++; total++; }
    printf("Heading counts:\n");
    for (int i = 1; i <= 6; i++) if (c[i]) {
        printf("  "); print_marks(i); printf(": %d\n", c[i]);
    }
    printf("\nTotal: %d\n", total);
}

static void output_section(Doc *d, const char *name) {
    int idx = -1;
    for (int i = 0; i < d->head_count; i++) if (strcasecmp(d->heads[i].title, name) == 0 || contains_ci(d->heads[i].title, name)) { idx = i; break; }
    if (idx < 0) return;
    int start = d->heads[idx].line;
    int end = d->line_count;
    for (int i = idx + 1; i < d->head_count; i++) if (d->heads[i].level <= d->heads[idx].level) { end = d->heads[i].line - 1; break; }
    for (int l = start; l <= end && l <= d->line_count; l++) printf("%s\n", d->lines[l-1]);
}

static int *select_headings(Doc *d, const char *q, int *n) {
    int level = 0;
    if (strncmp(q, ".h", 2) == 0 && isdigit((unsigned char)q[2])) level = q[2] - '0';
    int *idx = malloc((d->head_count ? d->head_count : 1) * sizeof(int));
    *n = 0;
    for (int i = 0; i < d->head_count; i++) if (!level || d->heads[i].level == level) idx[(*n)++] = i;
    const char *lb = strchr(q, '['), *rb = lb ? strchr(lb, ']') : NULL;
    if (lb && rb && rb > lb + 1) {
        char filt[256]; size_t fl = (size_t)(rb - lb - 1); if (fl > 255) fl = 255;
        memcpy(filt, lb + 1, fl); filt[fl] = 0;
        if ((filt[0] == '"' && filt[strlen(filt)-1] == '"') || (filt[0] == '\'' && filt[strlen(filt)-1] == '\'')) {
            memmove(filt, filt + 1, strlen(filt) - 2); filt[strlen(filt)-2] = 0;
        }
        char *endp; long val = strtol(filt, &endp, 10);
        if (*endp == 0) {
            int pos = val < 0 ? *n + (int)val : (int)val;
            if (pos >= 0 && pos < *n) { idx[0] = idx[pos]; *n = 1; } else *n = 0;
        } else {
            int w = 0;
            for (int i = 0; i < *n; i++) if (contains_ci(d->heads[idx[i]].title, filt)) idx[w++] = idx[i];
            *n = w;
        }
    }
    return idx;
}

static void query_json_headings(Doc *d, int *idx, int n) {
    putchar('[');
    for (int i = 0; i < n; i++) {
        Heading *h = &d->heads[idx[i]];
        if (i) putchar(',');
        printf("{\"type\":\"heading\",\"level\":%d,\"text\":", h->level);
        json_escape(h->title);
        printf(",\"line\":%d}", h->line);
    }
    printf("]\n");
}

static int link_matches(Link *l, const char *q) {
    if (strstr(q, "[external]")) return strstr(l->url, "://") != NULL;
    if (strstr(q, "[relative]")) return strstr(l->url, "://") == NULL;
    return 1;
}

static void query_links(Doc *d, const char *q, const char *out, int urls_only) {
    if (out && strcmp(out, "json") == 0) {
        putchar('[');
        int written = 0;
        for (int i = 0; i < d->link_count; i++) if (link_matches(&d->links[i], q)) {
            if (written++) putchar(',');
            printf("{\"type\":\"link\",\"text\":"); json_escape(d->links[i].text);
            printf(",\"url\":"); json_escape(d->links[i].url);
            printf(",\"link_type\":\"%s\"}", strstr(d->links[i].url, "://") ? "external" : "relative");
        }
        printf("]\n");
    } else {
        for (int i = 0; i < d->link_count; i++) if (link_matches(&d->links[i], q)) {
            if (urls_only) printf("%s\n", d->links[i].url);
            else printf("[%s](%s)\n", d->links[i].text, d->links[i].url);
        }
    }
}

static int code_matches(Code *c, const char *filter) {
    return !filter || !*filter || contains_ci(c->lang, filter);
}

static void query_codes(Doc *d, const char *q, const char *out, int lang_only) {
    char filt[128] = "";
    const char *lb = strchr(q, '['), *rb = lb ? strchr(lb, ']') : NULL;
    if (lb && rb && rb > lb + 1) {
        size_t n = (size_t)(rb - lb - 1); if (n > sizeof(filt) - 1) n = sizeof(filt) - 1;
        memcpy(filt, lb + 1, n); filt[n] = 0;
    }
    if (out && strcmp(out, "json") == 0) {
        putchar('[');
        int written = 0;
        for (int i = 0; i < d->code_count; i++) if (code_matches(&d->codes[i], filt)) {
            if (written++) putchar(',');
            printf("{\"type\":\"code\",\"lang\":"); json_escape(d->codes[i].lang);
            printf(",\"content\":"); json_escape(d->codes[i].body); printf(",\"line\":%d}", d->codes[i].line);
        }
        printf("]\n");
    } else {
        for (int i = 0; i < d->code_count; i++) if (code_matches(&d->codes[i], filt)) {
            if (lang_only) printf("%s\n", d->codes[i].lang);
            else {
                printf("```%s\n%s", d->codes[i].lang, d->codes[i].body);
                if (d->codes[i].body[0] && d->codes[i].body[strlen(d->codes[i].body)-1] != '\n') putchar('\n');
                printf("```\n");
            }
        }
    }
}

static void output_query(Doc *d, const char *q, const char *out) {
    char *qc = trim_copy(q);
    int want_text = strstr(qc, "| text") || strstr(qc, "|text");
    int want_url = strstr(qc, "| url") || strstr(qc, "|url") || strstr(qc, "| href") || strstr(qc, "|href");
    int want_lang = strstr(qc, "| lang") || strstr(qc, "|lang");
    if (strstr(qc, "count")) {
        char *sel = qc;
        if (*sel == '[') sel++;
        if (strncmp(sel, ".h", 2) == 0 || strncmp(sel, ".heading", 8) == 0) {
            int n = 0; int *idx = select_headings(d, sel, &n);
            printf("%d\n", n);
            free(idx); free(qc); return;
        }
        if (strncmp(sel, ".link", 5) == 0 || strncmp(sel, ".a", 2) == 0) printf("%d\n", d->link_count);
        else if (strncmp(sel, ".code", 5) == 0) printf("%d\n", d->code_count);
        else printf("%d\n", d->head_count);
        free(qc); return;
    }
    if (strncmp(qc, ".link", 5) == 0 || strncmp(qc, ".a", 2) == 0) { query_links(d, qc, out, want_url); free(qc); return; }
    if (strncmp(qc, ".code", 5) == 0) { query_codes(d, qc, out, want_lang); free(qc); return; }
    if (strncmp(qc, ".h", 2) == 0 || strncmp(qc, ".heading", 8) == 0) {
        int n = 0; int *idx = select_headings(d, qc, &n);
        if (out && strcmp(out, "json") == 0) query_json_headings(d, idx, n);
        else if (out && strcmp(out, "tree") == 0) output_tree(d, 0, NULL);
        else for (int i = 0; i < n; i++) {
            if (want_text) printf("%s\n", d->heads[idx[i]].title);
            else { print_marks(d->heads[idx[i]].level); printf(" %s\n", d->heads[idx[i]].title); }
        }
        free(idx); free(qc); return;
    }
    free(qc);
}

static void help(void) {
    printf("treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.\n\n");
    printf("Usage: executable [OPTIONS] [FILE]... [COMMAND]\n\n");
    printf("Commands:\n  at-line  Show heading at specific line number\n  help     Print this message or the help of the given subcommand(s)\n\n");
    printf("Options:\n  -l, --list\n      --tree\n      --filter <PATTERN>\n  -L, --level <LEVEL>\n  -o, --output <OUTPUT>\n  -s, --section <HEADING>\n      --count\n  -q, --query <EXPR>\n      --query-help\n      --query-output <FORMAT>\n  -h, --help\n  -V, --version\n");
}

static void query_help(void) {
    printf("treemd Query Language (tql)\n\nELEMENT SELECTORS\n    .h, .heading    All headings (any level)\n    .h1 - .h6       Headings by level\n    .code           All code blocks\n    .link, .a       All links\n\nPIPES\n    .h2 | text          Get heading text (strips ##)\n    [.h2] | count       Count all h2s\n    .code | lang        Get code block languages\n    .link | url         Get link URLs\n");
}

int main(int argc, char **argv) {
    int list = 0, tree = 0, count = 0, level = 0, atline = 0;
    const char *filter = NULL, *output = "plain", *section = NULL, *query = NULL, *query_output = "plain", *file = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) { help(); return 0; }
        else if (!strcmp(argv[i], "--version") || !strcmp(argv[i], "-V")) { printf("treemd 0.5.7\n"); return 0; }
        else if (!strcmp(argv[i], "--query-help")) { query_help(); return 0; }
        else if (!strcmp(argv[i], "help") && i + 1 < argc && !strcmp(argv[i+1], "at-line")) { printf("Show heading at specific line number\n\nUsage: executable at-line <LINE>\n"); return 0; }
        else if (!strcmp(argv[i], "at-line") && i + 1 < argc) { atline = atoi(argv[++i]); }
        else if (!strcmp(argv[i], "-l") || !strcmp(argv[i], "--list")) list = 1;
        else if (!strcmp(argv[i], "--tree")) tree = 1;
        else if (!strcmp(argv[i], "--count")) count = 1;
        else if ((!strcmp(argv[i], "--filter")) && i + 1 < argc) filter = argv[++i];
        else if ((!strcmp(argv[i], "-L") || !strcmp(argv[i], "--level")) && i + 1 < argc) level = atoi(argv[++i]);
        else if ((!strcmp(argv[i], "-o") || !strcmp(argv[i], "--output")) && i + 1 < argc) output = argv[++i];
        else if ((!strcmp(argv[i], "-s") || !strcmp(argv[i], "--section")) && i + 1 < argc) section = argv[++i];
        else if ((!strcmp(argv[i], "-q") || !strcmp(argv[i], "--query")) && i + 1 < argc) query = argv[++i];
        else if (!strcmp(argv[i], "--query-output") && i + 1 < argc) query_output = argv[++i];
        else if (!strcmp(argv[i], "--theme") || !strcmp(argv[i], "--color-mode")) { if (i + 1 < argc) i++; }
        else if (!strcmp(argv[i], "--images") || !strcmp(argv[i], "--no-images") || !strcmp(argv[i], "--setup-completions")) { }
        else if (argv[i][0] != '-' && !file) file = argv[i];
    }
    char *content = read_path(file ? file : "-");
    Doc d; parse_doc(&d, content);
    if (atline) {
        int found = -1;
        for (int i = 0; i < d.head_count; i++) if (d.heads[i].line <= atline) found = i; else break;
        if (found >= 0) { print_marks(d.heads[found].level); printf(" %s\n", d.heads[found].title); }
    } else if (query) output_query(&d, query, query_output);
    else if (count) output_count(&d);
    else if (section) output_section(&d, section);
    else if (tree || !strcmp(output, "tree")) output_tree(&d, level, filter);
    else if (!strcmp(output, "json")) print_json_headings(&d);
    else if (list || filter || level) output_list(&d, level, filter);
    else output_list(&d, 0, NULL);
    free(content);
    return 0;
}
