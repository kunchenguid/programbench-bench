module sccclone

go 1.21
