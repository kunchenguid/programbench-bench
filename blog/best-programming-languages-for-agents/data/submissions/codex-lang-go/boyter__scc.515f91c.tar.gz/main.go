package main

import (
	"bufio"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"html"
	"io"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"
)

const version = "3.7.0"

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(s string) error {
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			*m = append(*m, p)
		}
	}
	return nil
}

type Language struct {
	Name      string
	Exts      []string
	Line      []string
	Block     [][2]string
	Complex   []string
	Text      bool
	Filenames []string
}

type FileStat struct {
	Language           string   `json:"Language"`
	PossibleLanguages  []string `json:"PossibleLanguages"`
	Filename           string   `json:"Filename"`
	Extension          string   `json:"Extension"`
	Location           string   `json:"Location"`
	Symlocation        string   `json:"Symlocation"`
	Bytes              int64    `json:"Bytes"`
	Lines              int      `json:"Lines"`
	Code               int      `json:"Code"`
	Comment            int      `json:"Comment"`
	Blank              int      `json:"Blank"`
	Complexity         int      `json:"Complexity"`
	WeightedComplexity int      `json:"WeightedComplexity"`
	Hash               any      `json:"Hash"`
	Binary             bool     `json:"Binary"`
	Minified           bool     `json:"Minified"`
	Generated          bool     `json:"Generated"`
	EndPoint           int      `json:"EndPoint"`
	Uloc               int      `json:"Uloc"`
}

type Summary struct {
	Name               string      `json:"Name"`
	Bytes              int64       `json:"Bytes"`
	CodeBytes          int         `json:"CodeBytes"`
	Lines              int         `json:"Lines"`
	Code               int         `json:"Code"`
	Comment            int         `json:"Comment"`
	Blank              int         `json:"Blank"`
	Complexity         int         `json:"Complexity"`
	Count              int         `json:"Count"`
	WeightedComplexity int         `json:"WeightedComplexity"`
	Files              []FileStat  `json:"Files"`
	LineLength         interface{} `json:"LineLength"`
	ULOC               int         `json:"ULOC"`
}

var languageLines = strings.TrimSpace(`ABAP (abap)
ABNF (abnf)
ActionScript (as)
Ada (ada,adb,ads,pad)
Agda (agda)
Alchemist (crn)
Alex (x)
Algol 68 (a68)
Alloy (als)
Amber (ab)
Android Interface Definition Language (aidl)
Apex (apex,trigger)
APL (apl,aplf,apln,aplc,dyalog)
AppleScript (applescript)
ArkTs (ets)
Arturo (art)
AsciiDoc (adoc)
ASP (asa,asp)
ASP.NET (asax,ascx,asmx,aspx,master,sitemap,webinfo)
Assembly (s,asm)
Astro (astro)
ATS (dats,sats,ats,hats)
Autoconf (in)
AutoHotKey (ahk)
Avro (avdl,avpr,avsc)
AWK (awk)
bait (bt)
BASH (bash,bash_login,bash_logout,bash_profile,bashrc,.bash_login,.bash_logout,.bash_profile,.bashrc)
Basic (bas)
Batch (bat,btm,cmd)
Bazel (bzl,build.bazel,build,workspace)
Bean (bean,beancount)
Bicep (bicep)
Bitbake (bb,bbappend,bbclass)
Bitbucket Pipeline (bitbucket-pipelines.yml)
Blade template (blade.php)
Blueprint (blp)
Boo (boo)
Bosque (bsq)
Brainfuck (bf)
Bru (bru)
BuildStream (bst)
C (c,ec,pgc)
C Header (h)
C Shell (csh,.cshrc)
C# (cs,csx)
C++ (cc,cpp,cxx,c++,pcc,ino,ccm,cppm,cxxm,c++m,mxx)
C++ Header (hh,hpp,hxx,h++,inl,ipp,ixx,tpp)
C3 (c3)
Cabal (cabal)
Cairo (cairo)
Cangjie (cj)
Cap'n Proto (capnp)
Cassius (cassius)
Ceylon (ceylon)
Chapel (chpl)
Circom (circom)
Clipper (prg,ch)
Clojure (clj,cljc)
ClojureScript (cljs)
Closure Template (soy)
CloudFormation (JSON) (json)
CloudFormation (YAML) (yaml,yml)
CMake (cmake,cmakelists.txt)
COBOL (cob,cbl,ccp,cobol,cpy)
CodeQL (ql,qll)
CoffeeScript (coffee)
Cogent (cogent)
ColdFusion (cfm)
ColdFusion CFScript (cfc)
Coq (v)
Creole (creole)
Crystal (cr)
CSS (css)
CSV (csv)
Cuda (cu,cuh)
Cypher (cypher,cql)
Cython (pyx,pxi,pxd)
D (d)
D2 (d2)
DAML (daml)
Dart (dart)
Device Tree (dts,dtsi)
Dhall (dhall)
DM (dm)
Docker ignore (.dockerignore)
Dockerfile (dockerfile,dockerfile)
Document Type Definition (dtd)
DOT (dot,gv)
Elixir (ex,exs)
Elixir Template (eex)
Elm (elm)
Emacs Dev Env (ede)
Emacs Lisp (el)
Erlang (erl,hrl)
Extensible Stylesheet Language Transformations (xslt,xsl)
F# (fs,fsi,fsx,fsscript)
F* (fst)
Fish (fish)
FORTRAN Legacy (f,for,ftn,f77,pfo)
Fortran Modern (f03,f08,f90,f95)
Freemarker Template (ftl)
GDScript (gd)
Gemfile (gemfile)
Gherkin Specification (feature)
gitignore (.gitignore)
Go (go)
Go Template (tmpl,gohtml,gotxt)
Gradle (gradle)
GraphQL (graphql)
Groovy (groovy,grt,gtpl,gvy)
HAML (haml)
Handlebars (hbs,handlebars)
Haskell (hs)
HCL (hcl)
HTML (html,htm)
INI (ini)
Java (java)
JavaScript (js,cjs,mjs)
JavaServer Pages (jsp)
Jenkins Buildfile (jenkinsfile)
Jinja (jinja,j2,jinja2)
JSON (json)
JSX (jsx)
Julia (jl)
Jupyter (ipynb,jpynb)
Kotlin (kt,kts)
LaTeX (tex)
LESS (less)
License (license,licence,copying,copying3,unlicense,unlicence,license-apache,licence-apache,license-mit,licence-mit,copyright)
Lisp (lisp,lsp)
Lua (lua)
Makefile (makefile,mak,mk,bp,makefile,gnumakefile)
Markdown (md,markdown)
MATLAB (m)
MSBuild (csproj,vbproj,fsproj,vcproj,vcxproj,vcxproj.filters,ilproj,myapp,props,rdlc,resx,settings,sln,targets)
Nim (nim)
Nix (nix)
Objective C (m)
Objective C++ (mm)
OCaml (ml,mli)
Org (org)
Pascal (pas)
Patch (patch)
Perl (pl,plx,pm)
PHP (php)
Plain Text (text,txt)
Powershell (ps1,psm1)
Properties File (properties)
Protocol Buffers (proto)
Python (py,pyw,pyi)
R (r)
Rakefile (rake,rakefile)
ReStructuredText (rst)
Ruby (rb)
Ruby HTML (rhtml,erb)
Rust (rs)
Sass (sass,scss)
Scala (sc,scala)
Scheme (scm,ss)
Shell (sh,.tcshrc)
Solidity (sol)
SQL (sql,dml,ddl,dql)
Svelte (svelte)
SVG (svg)
Swift (swift)
SystemVerilog (sv,svh)
TCL (tcl)
Terraform (tf,tfvars,tf.json)
TOML (toml)
Twig Template (twig)
TypeScript (ts,tsx,cts,mts)
TypeScript Typings (d.ts)
Vue (vue)
XML (xml)
YAML (yaml,yml)
Zig (zig)
Zsh (zsh,zshenv,zlogin,zlogout,zprofile,zshrc,.zshenv,.zlogin,.zlogout,.zprofile,.zshrc)`)

var extMap map[string]*Language
var nameMap map[string]*Language

func init() {
	extMap = map[string]*Language{}
	nameMap = map[string]*Language{}
	for _, line := range strings.Split(languageLines, "\n") {
		i := strings.LastIndex(line, " (")
		if i < 0 {
			continue
		}
		name := line[:i]
		exts := strings.Split(strings.TrimSuffix(line[i+2:], ")"), ",")
		l := &Language{Name: name, Exts: exts, Text: true}
		nameMap[strings.ToLower(name)] = l
		for _, e := range exts {
			extMap[strings.ToLower(e)] = l
		}
	}
	configure()
}

func set(name string, line []string, blocks [][2]string, complex []string) {
	if l := nameMap[strings.ToLower(name)]; l != nil {
		l.Line, l.Block, l.Complex, l.Text = line, blocks, complex, false
	}
}

func configure() {
	cLike := []string{"if", "for", "while", "case", "catch", "&&", "||", "?", "else if"}
	for _, n := range []string{"C", "C Header", "C++", "C++ Header", "C#", "Go", "Java", "JavaScript", "JSX", "TypeScript", "Rust", "Swift", "Kotlin", "Dart", "CSS", "PHP", "Scala", "Solidity", "SystemVerilog"} {
		set(n, []string{"//"}, [][2]string{{"/*", "*/"}}, cLike)
	}
	for _, n := range []string{"Python", "Ruby", "Perl", "R", "Shell", "BASH", "Zsh", "Powershell", "YAML", "TOML", "Dockerfile", "Makefile", "CMake", "Terraform", "Nix"} {
		set(n, []string{"#"}, nil, []string{"if", "for", "while", "elif", "case", "&&", "||"})
	}
	if l := nameMap["python"]; l != nil {
		l.Block = [][2]string{{`"""`, `"""`}, {`'''`, `'''`}}
	}
	for _, n := range []string{"HTML", "XML", "SVG", "Vue", "Svelte", "Jinja", "Ruby HTML", "ASP.NET", "MSBuild"} {
		set(n, nil, [][2]string{{"<!--", "-->"}}, nil)
	}
	set("SQL", []string{"--"}, [][2]string{{"/*", "*/"}}, []string{"select", "where", "join", "case", "when", "if"})
	set("Lua", []string{"--"}, [][2]string{{"--[[", "]]"}}, []string{"if", "for", "while", "repeat", "and", "or"})
	set("Haskell", []string{"--"}, [][2]string{{"{-", "-}"}}, []string{"if", "case", "where"})
	for _, n := range []string{"JSON", "CSV", "Markdown", "Plain Text", "License", "Jupyter"} {
		if l := nameMap[strings.ToLower(n)]; l != nil {
			l.Text = true
		}
	}
}

type options struct {
	format, output, sortBy, currency, projectType, sqlProject, sizeUnit string
	byFile, noCocomo, noSize, noComplexity, uloc, dryness, languages    bool
	wide, percent, noHBorder, ci, version                               bool
	include, excludeExt, excludeDir, excludeFile, notMatch              multiFlag
	countAs, remapUnknown, remapAll                                     string
	avgWage                                                             int
	eaf, overhead                                                       float64
}

func main() {
	var o options
	flag.StringVar(&o.format, "format", "tabular", "")
	flag.StringVar(&o.format, "f", "tabular", "")
	flag.BoolVar(&o.byFile, "by-file", false, "")
	flag.BoolVar(&o.noCocomo, "no-cocomo", false, "")
	flag.BoolVar(&o.noSize, "no-size", false, "")
	flag.BoolVar(&o.noComplexity, "no-complexity", false, "")
	flag.BoolVar(&o.uloc, "uloc", false, "")
	flag.BoolVar(&o.uloc, "u", false, "")
	flag.BoolVar(&o.dryness, "dryness", false, "")
	flag.BoolVar(&o.dryness, "a", false, "")
	flag.BoolVar(&o.languages, "languages", false, "")
	flag.BoolVar(&o.languages, "l", false, "")
	flag.BoolVar(&o.wide, "wide", false, "")
	flag.BoolVar(&o.wide, "w", false, "")
	flag.BoolVar(&o.percent, "percent", false, "")
	flag.BoolVar(&o.noHBorder, "no-hborder", false, "")
	flag.BoolVar(&o.ci, "ci", false, "")
	flag.BoolVar(&o.version, "version", false, "")
	flag.Var(&o.include, "include-ext", "")
	flag.Var(&o.include, "i", "")
	flag.Var(&o.excludeExt, "exclude-ext", "")
	flag.Var(&o.excludeExt, "x", "")
	flag.Var(&o.excludeDir, "exclude-dir", "")
	flag.Var(&o.excludeFile, "exclude-file", "")
	flag.Var(&o.excludeFile, "n", "")
	flag.Var(&o.notMatch, "not-match", "")
	flag.Var(&o.notMatch, "M", "")
	flag.StringVar(&o.output, "output", "", "")
	flag.StringVar(&o.output, "o", "", "")
	flag.StringVar(&o.sortBy, "sort", "files", "")
	flag.StringVar(&o.sortBy, "s", "files", "")
	flag.StringVar(&o.countAs, "count-as", "", "")
	flag.StringVar(&o.remapUnknown, "remap-unknown", "", "")
	flag.StringVar(&o.remapAll, "remap-all", "", "")
	flag.StringVar(&o.currency, "currency-symbol", "$", "")
	flag.StringVar(&o.projectType, "cocomo-project-type", "organic", "")
	flag.StringVar(&o.sqlProject, "sql-project", "", "")
	flag.StringVar(&o.sizeUnit, "size-unit", "si", "")
	flag.IntVar(&o.avgWage, "avg-wage", 56280, "")
	flag.Float64Var(&o.eaf, "eaf", 1.0, "")
	flag.Float64Var(&o.overhead, "overhead", 2.4, "")
	addIgnoredFlags()
	flag.Usage = usage
	flag.Parse()
	if o.version {
		fmt.Println("scc version " + version)
		return
	}
	if o.languages {
		fmt.Println(languageLines)
		return
	}
	if o.dryness {
		o.uloc = true
	}
	applyCountAs(o.countAs)
	paths := flag.Args()
	if len(paths) == 0 {
		paths = []string{"."}
	}
	sums, totalBytes := scan(paths, &o)
	sortSummaries(sums, o.sortBy)
	var out string
	switch o.format {
	case "json":
		b, _ := json.Marshal(sums)
		out = string(b)
	case "json2":
		out = json2(sums, &o)
	case "csv", "csv-stream":
		out = csvOut(sums)
	case "cloc-yaml":
		out = yamlOut(sums)
	case "html", "html-table":
		out = htmlOut(sums, o.format == "html")
	case "sql", "sql-insert":
		out = sqlOut(sums, o.sqlProject, o.format == "sql")
	case "openmetrics":
		out = metricsOut(sums)
	default:
		out = tableOut(sums, totalBytes, &o)
	}
	if o.output != "" && o.output != "stdout" {
		_ = os.WriteFile(o.output, []byte(out), 0644)
	} else {
		fmt.Print(out)
		if !strings.HasSuffix(out, "\n") {
			fmt.Println()
		}
	}
}

func addIgnoredFlags() {
	for _, b := range []string{"binary", "count-ignore", "debug", "format-multi-line", "gen", "include-symlinks", "locomo", "mcp", "min", "min-gen", "no-duplicates", "no-gen", "no-gitignore", "no-gitmodule", "no-ignore", "no-large", "no-min", "no-min-gen", "no-min-gen-ignore", "no-scc-ignore", "sloccount-format", "trace", "verbose", "cost-comparison", "size-unit-binary", "size-unit-mixed", "size-unit-xkcd", "size-unit-si"} {
		flag.Bool(b, false, "")
	}
	for _, s := range []string{"directory-walker-job-workers", "file-gc-count", "file-list-queue-size", "file-process-job-workers", "file-summary-job-queue-size", "large-byte-count", "large-line-count", "min-gen-line-length"} {
		flag.Int(s, 0, "")
	}
	for _, s := range []string{"generated-markers", "format-multi", "locomo-config", "locomo-preset"} {
		flag.String(s, "", "")
	}
	for _, s := range []string{"locomo-cycles", "locomo-input-price", "locomo-output-price", "locomo-review", "locomo-tps"} {
		flag.Float64(s, 0, "")
	}
}

func usage() {
	fmt.Println(`Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version 3.7.0
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
  -f, --format string    set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
      --by-file          display output for every file
  -l, --languages        print supported languages and extensions
      --version          version for scc
  -h, --help             help for scc`)
}

func applyCountAs(s string) {
	for _, p := range strings.Split(s, ",") {
		if !strings.Contains(p, ":") {
			continue
		}
		parts := strings.SplitN(p, ":", 2)
		ext := strings.Trim(strings.TrimSpace(parts[0]), ".\"'")
		target := strings.Trim(strings.TrimSpace(parts[1]), "\"'")
		if l := lookupLang(target); l != nil {
			extMap[strings.ToLower(ext)] = l
		}
	}
}

func lookupLang(s string) *Language {
	if l := nameMap[strings.ToLower(s)]; l != nil {
		return l
	}
	return extMap[strings.ToLower(strings.TrimPrefix(s, "."))]
}

func scan(paths []string, o *options) ([]Summary, int64) {
	m := map[string]*Summary{}
	var totalBytes int64
	for _, p := range paths {
		filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			name := d.Name()
			if d.IsDir() {
				if shouldSkipDir(name, o) && path != p {
					return filepath.SkipDir
				}
				return nil
			}
			if shouldSkipFile(path, name, o) {
				return nil
			}
			lang := langFor(path)
			if lang == nil {
				return nil
			}
			if len(o.include) > 0 && !hasExt(path, o.include) {
				return nil
			}
			if len(o.excludeExt) > 0 && hasExt(path, o.excludeExt) {
				return nil
			}
			st, err := countFile(path, lang, o)
			if err != nil {
				return nil
			}
			totalBytes += st.Bytes
			s := m[st.Language]
			if s == nil {
				s = &Summary{Name: st.Language, Files: []FileStat{}, LineLength: nil}
				m[st.Language] = s
			}
			s.Bytes += st.Bytes
			s.Lines += st.Lines
			s.Code += st.Code
			s.Comment += st.Comment
			s.Blank += st.Blank
			s.Complexity += st.Complexity
			s.Count++
			s.ULOC += st.Uloc
			if o.byFile {
				s.Files = append(s.Files, st)
			}
			return nil
		})
	}
	var sums []Summary
	for _, s := range m {
		sums = append(sums, *s)
	}
	return sums, totalBytes
}

func shouldSkipDir(name string, o *options) bool {
	defaults := []string{".git", ".hg", ".svn"}
	for _, d := range append(defaults, o.excludeDir...) {
		if name == d {
			return true
		}
	}
	return false
}

func shouldSkipFile(path, name string, o *options) bool {
	defaults := []string{"package-lock.json", "Cargo.lock", "yarn.lock", "pubspec.lock", "Podfile.lock", "pnpm-lock.yaml"}
	for _, f := range append(defaults, o.excludeFile...) {
		if name == f {
			return true
		}
	}
	for _, pat := range o.notMatch {
		if re, err := regexp.Compile(pat); err == nil && re.MatchString(path) {
			return true
		}
	}
	return false
}

func hasExt(path string, list []string) bool {
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(path)), ".")
	base := strings.ToLower(filepath.Base(path))
	for _, e := range list {
		e = strings.TrimPrefix(strings.ToLower(e), ".")
		if e == ext || e == base {
			return true
		}
	}
	return false
}

func langFor(path string) *Language {
	base := strings.ToLower(filepath.Base(path))
	if l := extMap[base]; l != nil {
		return l
	}
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(path)), ".")
	if base == "dockerfile" {
		ext = "dockerfile"
	}
	if l := extMap[ext]; l != nil {
		return l
	}
	return nil
}

func countFile(path string, lang *Language, o *options) (FileStat, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return FileStat{}, err
	}
	lines := splitLines(string(b))
	fs := FileStat{Language: lang.Name, PossibleLanguages: []string{lang.Name}, Filename: filepath.Base(path), Extension: strings.TrimPrefix(filepath.Ext(path), "."), Location: path, Bytes: int64(len(b)), Hash: nil}
	if !filepath.IsAbs(path) {
		fs.Location = filepath.Clean(path)
	}
	blockEnd := ""
	ul := map[string]bool{}
	for _, line := range lines {
		fs.Lines++
		trim := strings.TrimSpace(line)
		if trim == "" {
			fs.Blank++
			continue
		}
		isCode, isComment := classify(trim, lang, &blockEnd)
		if isComment {
			fs.Comment++
		} else if isCode {
			fs.Code++
			if o.uloc {
				ul[trim] = true
			}
			if !o.noComplexity {
				fs.Complexity += complexity(trim, lang)
			}
		}
	}
	if o.uloc {
		fs.Uloc = len(ul)
	}
	return fs, nil
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	sc := bufio.NewScanner(strings.NewReader(s))
	sc.Buffer(make([]byte, 1024), 1024*1024*50)
	var lines []string
	for sc.Scan() {
		lines = append(lines, sc.Text())
	}
	if strings.HasSuffix(s, "\n") || len(lines) > 0 {
		return lines
	}
	return []string{s}
}

func classify(trim string, lang *Language, blockEnd *string) (bool, bool) {
	if lang.Text {
		return true, false
	}
	if *blockEnd != "" {
		if idx := strings.Index(trim, *blockEnd); idx >= 0 {
			rest := strings.TrimSpace(trim[idx+len(*blockEnd):])
			*blockEnd = ""
			if rest != "" {
				return true, false
			}
		}
		return false, true
	}
	for _, p := range lang.Line {
		if strings.HasPrefix(trim, p) {
			return false, true
		}
	}
	for _, b := range lang.Block {
		if strings.HasPrefix(trim, b[0]) {
			if idx := strings.Index(trim[len(b[0]):], b[1]); idx >= 0 {
				rest := strings.TrimSpace(trim[len(b[0])+idx+len(b[1]):])
				return rest != "", rest == ""
			}
			*blockEnd = b[1]
			return false, true
		}
	}
	return true, false
}

func complexity(line string, lang *Language) int {
	l := strings.ToLower(line)
	c := 0
	for _, kw := range lang.Complex {
		if strings.Contains(kw, "&") || strings.Contains(kw, "?") {
			c += strings.Count(l, kw)
		} else if regexp.MustCompile(`\b` + regexp.QuoteMeta(strings.ToLower(kw)) + `\b`).MatchString(l) {
			c++
		}
	}
	return c
}

func sortSummaries(s []Summary, by string) {
	sort.Slice(s, func(i, j int) bool {
		a, b := s[i], s[j]
		switch by {
		case "name":
			return a.Name < b.Name
		case "lines":
			if a.Lines != b.Lines {
				return a.Lines > b.Lines
			}
		case "blanks":
			if a.Blank != b.Blank {
				return a.Blank > b.Blank
			}
		case "code":
			if a.Code != b.Code {
				return a.Code > b.Code
			}
		case "comments":
			if a.Comment != b.Comment {
				return a.Comment > b.Comment
			}
		case "complexity":
			if a.Complexity != b.Complexity {
				return a.Complexity > b.Complexity
			}
		default:
			if a.Count != b.Count {
				return a.Count > b.Count
			}
		}
		return a.Name < b.Name
	})
}

func totals(s []Summary) Summary {
	t := Summary{Name: "Total"}
	for _, x := range s {
		t.Bytes += x.Bytes
		t.Lines += x.Lines
		t.Blank += x.Blank
		t.Comment += x.Comment
		t.Code += x.Code
		t.Complexity += x.Complexity
		t.Count += x.Count
		t.ULOC += x.ULOC
	}
	return t
}

func tableOut(s []Summary, bytes int64, o *options) string {
	border := "───────────────────────────────────────────────────────────────────────────────"
	if o.ci {
		border = "-------------------------------------------------------------------------------"
	}
	var b strings.Builder
	if !o.noHBorder {
		b.WriteString(border + "\n")
	}
	uhead := ""
	if o.dryness {
		uhead = "   DRYness"
	} else if o.uloc {
		uhead = "    ULOC"
	}
	fmt.Fprintf(&b, "%-18s %8s %11s %9s %9s %10s %10s%s\n", "Language", "Files", "Lines", "Blanks", "Comments", "Code", "Complexity", uhead)
	if !o.noHBorder {
		b.WriteString(border + "\n")
	}
	for _, x := range s {
		writeRow(&b, x, o)
	}
	if !o.noHBorder {
		b.WriteString(border + "\n")
	}
	writeRow(&b, totals(s), o)
	if !o.noHBorder {
		b.WriteString(border + "\n")
	}
	if !o.noCocomo {
		cost, sched, people := cocomo(totals(s).Code, o)
		fmt.Fprintf(&b, "Estimated Cost to Develop (%s) %s%s\n", o.projectType, o.currency, comma(int(cost)))
		fmt.Fprintf(&b, "Estimated Schedule Effort (%s) %.2f months\n", o.projectType, sched)
		fmt.Fprintf(&b, "Estimated People Required (%s) %.2f\n", o.projectType, people)
		if !o.noHBorder {
			b.WriteString(border + "\n")
		}
	}
	if !o.noSize {
		fmt.Fprintf(&b, "Processed %d bytes, %.3f megabytes (SI)\n", bytes, float64(bytes)/1000000)
		if !o.noHBorder {
			b.WriteString(border + "\n")
		}
	}
	return b.String()
}

func writeRow(b *strings.Builder, x Summary, o *options) {
	extra := ""
	if o.dryness {
		val := 0.0
		if x.Code > 0 {
			val = float64(x.ULOC) / float64(x.Code) * 100
		}
		extra = fmt.Sprintf(" %9.1f%%", val)
	} else if o.uloc {
		extra = fmt.Sprintf(" %7s", comma(x.ULOC))
	}
	fmt.Fprintf(b, "%-18s %8s %11s %9s %9s %10s %10s%s\n", truncate(x.Name, 18), comma(x.Count), comma(x.Lines), comma(x.Blank), comma(x.Comment), comma(x.Code), comma(x.Complexity), extra)
}

func truncate(s string, n int) string {
	if utf8.RuneCountInString(s) <= n {
		return s
	}
	r := []rune(s)
	return string(r[:n-1]) + "…"
}

func comma(n int) string {
	sign := ""
	if n < 0 {
		sign = "-"
		n = -n
	}
	s := strconv.Itoa(n)
	for i := len(s) - 3; i > 0; i -= 3 {
		s = s[:i] + "," + s[i:]
	}
	return sign + s
}

func cocomo(code int, o *options) (float64, float64, float64) {
	a, b, c, d := 2.4, 1.05, 2.5, 0.38
	switch o.projectType {
	case "semi-detached":
		a, b, c, d = 3.0, 1.12, 2.5, 0.35
	case "embedded":
		a, b, c, d = 3.6, 1.20, 2.5, 0.32
	default:
		if strings.HasPrefix(o.projectType, "custom,") {
			ps := strings.Split(o.projectType, ",")
			if len(ps) == 5 {
				a, _ = strconv.ParseFloat(ps[1], 64)
				b, _ = strconv.ParseFloat(ps[2], 64)
				c, _ = strconv.ParseFloat(ps[3], 64)
				d, _ = strconv.ParseFloat(ps[4], 64)
			}
		}
	}
	effort := a * math.Pow(float64(code)/1000, b) * o.eaf
	sched := c * math.Pow(effort, d)
	people := 0.0
	if sched > 0 {
		people = effort / sched
	}
	return effort * float64(o.avgWage) / 12 * o.overhead, sched, people
}

func json2(s []Summary, o *options) string {
	t := totals(s)
	cost, sched, people := cocomo(t.Code, o)
	v := struct {
		LanguageSummary         []Summary `json:"languageSummary"`
		EstimatedCost           float64   `json:"estimatedCost"`
		EstimatedScheduleMonths float64   `json:"estimatedScheduleMonths"`
		EstimatedPeople         float64   `json:"estimatedPeople"`
	}{s, cost, sched, people}
	b, _ := json.Marshal(v)
	return string(b)
}

func csvOut(s []Summary) string {
	var b strings.Builder
	b.WriteString("Language,Lines,Code,Comments,Blanks,Complexity,Bytes,Files,ULOC\n")
	for _, x := range s {
		fmt.Fprintf(&b, "%s,%d,%d,%d,%d,%d,%d,%d,%d\n", x.Name, x.Lines, x.Code, x.Comment, x.Blank, x.Complexity, x.Bytes, x.Count, x.ULOC)
	}
	return b.String()
}

func yamlOut(s []Summary) string {
	t := totals(s)
	var b strings.Builder
	b.WriteString("# https://github.com/boyter/scc/\nheader:\n  url: https://github.com/boyter/scc/\n  version: 3.7.0\n")
	fmt.Fprintf(&b, "  n_files: %d\n  n_lines: %d\n", t.Count, t.Lines)
	for _, x := range s {
		fmt.Fprintf(&b, "%s:\n  name: %s\n  code: %d\n  comment: %d\n  blank: %d\n  nFiles: %d\n", x.Name, x.Name, x.Code, x.Comment, x.Blank, x.Count)
	}
	fmt.Fprintf(&b, "SUM:\n  code: %d\n  comment: %d\n  blank: %d\n  nFiles: %d\n", t.Code, t.Comment, t.Blank, t.Count)
	return b.String()
}

func htmlOut(s []Summary, full bool) string {
	var b strings.Builder
	if full {
		b.WriteString("<html><body>\n")
	}
	b.WriteString("<table><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr>\n")
	for _, x := range append(s, totals(s)) {
		fmt.Fprintf(&b, "<tr><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td>%d</td><td>%d</td><td>%d</td></tr>\n", html.EscapeString(x.Name), x.Count, x.Lines, x.Blank, x.Comment, x.Code, x.Complexity)
	}
	b.WriteString("</table>\n")
	if full {
		b.WriteString("</body></html>\n")
	}
	return b.String()
}

func sqlOut(s []Summary, project string, schema bool) string {
	if project == "" {
		project = "scc"
	}
	var b strings.Builder
	if schema {
		b.WriteString("CREATE TABLE IF NOT EXISTS t (Project TEXT, Language TEXT, Files INTEGER, Lines INTEGER, Blanks INTEGER, Comments INTEGER, Code INTEGER, Complexity INTEGER);\n")
	}
	for _, x := range s {
		fmt.Fprintf(&b, "INSERT INTO t VALUES ('%s','%s',%d,%d,%d,%d,%d,%d);\n", esc(project), esc(x.Name), x.Count, x.Lines, x.Blank, x.Comment, x.Code, x.Complexity)
	}
	return b.String()
}

func esc(s string) string { return strings.ReplaceAll(s, "'", "''") }

func metricsOut(s []Summary) string {
	var b strings.Builder
	for _, x := range s {
		h := fmt.Sprintf(`language="%s"`, strings.ReplaceAll(x.Name, `"`, `\"`))
		fmt.Fprintf(&b, "scc_files{%s} %d\nscc_lines{%s} %d\nscc_code{%s} %d\nscc_comments{%s} %d\nscc_blanks{%s} %d\nscc_complexity{%s} %d\n", h, x.Count, h, x.Lines, h, x.Code, h, x.Comment, h, x.Blank, h, x.Complexity)
	}
	return b.String()
}

func fileHash(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	h := sha1.New()
	_, _ = io.Copy(h, f)
	return hex.EncodeToString(h.Sum(nil))
}
