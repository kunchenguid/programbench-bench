module reimplementation

go 1.21
