package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"
)

type Module struct {
	Path     string     `json:"Path"`
	Version  string     `json:"Version"`
	Time     *time.Time `json:"Time"`
	Update   *Module    `json:"Update"`
	Indirect bool       `json:"Indirect"`
}

func (m Module) direct() bool {
	return !m.Indirect
}

func (m Module) hasUpdate() bool {
	return m.Update != nil
}

func (m Module) updateVersion() string {
	if m.Update == nil {
		return ""
	}
	return m.Update.Version
}

func (m Module) validTimestamps() bool {
	if m.Update == nil || m.Time == nil {
		return true
	}
	// The original dereferences the update timestamp here. Preserve that
	// observable behavior for malformed records with an update but no time.
	return !m.Update.Time.Before(*m.Time)
}

func main() {
	var onlyUpdates bool
	var onlyDirect bool
	var ci bool
	var style string

	flag.BoolVar(&ci, "ci", false, "Non-zero exit code when at least one outdated dependency was found")
	flag.BoolVar(&onlyDirect, "direct", false, "List only direct modules")
	flag.StringVar(&style, "style", "default", "Output style, pass 'markdown' for a Markdown table")
	flag.BoolVar(&onlyUpdates, "update", false, "List only modules with updates")
	flag.Parse()

	mods, ok := readModules(os.Stdin)
	if !ok {
		return
	}

	filtered := make([]Module, 0, len(mods))
	outdated := false
	for _, m := range mods {
		if onlyDirect && !m.direct() {
			continue
		}
		if m.hasUpdate() {
			outdated = true
		}
		if onlyUpdates && !m.hasUpdate() {
			continue
		}
		filtered = append(filtered, m)
	}

	if len(filtered) > 0 {
		renderTable(os.Stdout, filtered, style)
	}

	if ci && outdated {
		os.Exit(1)
	}
}

func readModules(r io.Reader) ([]Module, bool) {
	dec := json.NewDecoder(r)
	var mods []Module
	for {
		var m Module
		err := dec.Decode(&m)
		if err == io.EOF {
			return mods, true
		}
		if err != nil {
			log.Println(err)
			return nil, false
		}
		mods = append(mods, m)
	}
}

func renderTable(w io.Writer, mods []Module, style string) {
	headers := []string{"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"}
	rows := make([][]string, 0, len(mods))
	for _, m := range mods {
		rows = append(rows, []string{
			m.Path,
			m.Version,
			m.updateVersion(),
			fmt.Sprintf("%t", m.direct()),
			fmt.Sprintf("%t", m.validTimestamps()),
		})
	}

	widths := make([]int, len(headers))
	for i, h := range headers {
		widths[i] = len(h)
	}
	for _, row := range rows {
		for i, cell := range row {
			if len(cell) > widths[i] {
				widths[i] = len(cell)
			}
		}
	}

	if style == "markdown" {
		printHeader(w, headers, widths)
		printMarkdownSep(w, widths)
		for _, row := range rows {
			printRow(w, row, widths, false)
		}
		return
	}

	printBorder(w, widths)
	printHeader(w, headers, widths)
	printBorder(w, widths)
	for _, row := range rows {
		printRow(w, row, widths, false)
	}
	printBorder(w, widths)
}

func printBorder(w io.Writer, widths []int) {
	for _, width := range widths {
		fmt.Fprint(w, "+")
		fmt.Fprint(w, strings.Repeat("-", width+2))
	}
	fmt.Fprintln(w, "+")
}

func printMarkdownSep(w io.Writer, widths []int) {
	for _, width := range widths {
		fmt.Fprint(w, "|")
		fmt.Fprint(w, strings.Repeat("-", width+2))
	}
	fmt.Fprintln(w, "|")
}

func printHeader(w io.Writer, headers []string, widths []int) {
	cells := make([]string, len(headers))
	for i, h := range headers {
		pad := widths[i] - len(h)
		left := pad / 2
		right := pad - left
		cells[i] = strings.Repeat(" ", left) + h + strings.Repeat(" ", right)
	}
	printRow(w, cells, widths, true)
}

func printRow(w io.Writer, row []string, widths []int, alreadyPadded bool) {
	for i, cell := range row {
		if !alreadyPadded {
			cell = cell + strings.Repeat(" ", widths[i]-len(cell))
		}
		fmt.Fprintf(w, "| %s ", cell)
	}
	fmt.Fprintln(w, "|")
}
