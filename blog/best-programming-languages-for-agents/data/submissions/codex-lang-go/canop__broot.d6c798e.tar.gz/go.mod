module broot-reimpl

go 1.21
