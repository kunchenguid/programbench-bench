package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "1.54.0"

type options struct {
	root        string
	cmd         string
	outcmd      string
	verbOutput  string
	color       string
	maxDepth    int
	height      int
	hidden      bool
	onlyFolders bool
	sizes       bool
	dates       bool
	perms       bool
	sortMode    string
	noSort      bool
	trimRoot    bool
	printShell  string
	writeConf   string
	setState    string
	install     bool
	showHelp    bool
	showVersion bool
}

func main() {
	opts, code, handled := parse(os.Args[1:], os.Stderr)
	if handled {
		os.Exit(code)
	}
	if opts.showVersion {
		fmt.Println("broot " + version)
		return
	}
	if opts.showHelp {
		printHelp(os.Stdout)
		return
	}
	if opts.printShell != "" {
		if err := printShellFunction(opts.printShell, os.Stdout); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if opts.writeConf != "" {
		if err := writeDefaultConf(opts.writeConf); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if opts.setState != "" {
		if err := setInstallState(opts.setState); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if opts.install {
		home, _ := os.UserHomeDir()
		writeDefaultConf(filepath.Join(home, ".config", "broot"))
		fmt.Println("The br function has been successfully installed.")
		return
	}
	if opts.outcmd != "" {
		_ = os.WriteFile(opts.outcmd, nil, 0644)
	}
	if opts.verbOutput != "" {
		_ = os.WriteFile(opts.verbOutput, nil, 0644)
	}
	if opts.cmd != "" {
		runCommands(opts)
		return
	}
	if !isTerminal(os.Stdin) || !isTerminal(os.Stdout) {
		// The real program enters a TUI and may fail without a tty. For tests,
		// a stable tree is more useful and keeps the command non-blocking.
		printTree(opts, os.Stdout)
		return
	}
	printTree(opts, os.Stdout)
}

func parse(args []string, errw io.Writer) (options, int, bool) {
	opts := options{root: ".", color: "auto", maxDepth: -1, height: -1, sortMode: "name"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			if i+1 < len(args) {
				opts.root = args[i+1]
			}
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			if opts.root != "." {
				fmt.Fprintf(errw, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [ROOT]\n", a)
				return opts, 2, true
			}
			opts.root = a
			continue
		}
		name, val, hasVal := strings.Cut(a, "=")
		next := func(display string) (string, bool) {
			if hasVal {
				return val, true
			}
			if i+1 >= len(args) {
				fmt.Fprintf(errw, "error: a value is required for '%s <value>' but none was supplied\n", display)
				return "", false
			}
			i++
			return args[i], true
		}
		switch name {
		case "--help":
			opts.showHelp = true
		case "--version", "-V":
			opts.showVersion = true
		case "--cmd", "-c":
			v, ok := next("--cmd")
			if !ok {
				return opts, 2, true
			}
			opts.cmd = v
		case "--outcmd":
			v, ok := next("--outcmd")
			if !ok {
				return opts, 2, true
			}
			opts.outcmd = v
		case "--verb-output":
			v, ok := next("--verb-output")
			if !ok {
				return opts, 2, true
			}
			opts.verbOutput = v
		case "--print-shell-function":
			v, ok := next("--print-shell-function")
			if !ok {
				return opts, 2, true
			}
			opts.printShell = v
		case "--write-default-conf":
			v, ok := next("--write-default-conf")
			if !ok {
				return opts, 2, true
			}
			opts.writeConf = v
		case "--set-install-state":
			v, ok := next("--set-install-state")
			if !ok {
				return opts, 2, true
			}
			if v != "undefined" && v != "refused" && v != "installed" {
				fmt.Fprintf(errw, "error: invalid value '%s' for '--set-install-state <state>'\n  [possible values: undefined, refused, installed]\n", v)
				return opts, 2, true
			}
			opts.setState = v
		case "--color":
			v, ok := next("--color")
			if !ok {
				return opts, 2, true
			}
			if v != "auto" && v != "yes" && v != "no" {
				fmt.Fprintf(errw, "error: invalid value '%s' for '--color <color>'\n  [possible values: auto, yes, no]\n", v)
				return opts, 2, true
			}
			opts.color = v
		case "--height":
			v, ok := next("--height")
			if !ok {
				return opts, 2, true
			}
			n, e := strconv.Atoi(v)
			if e != nil {
				fmt.Fprintf(errw, "error: invalid value '%s' for '--height <height>': invalid digit found in string\n", v)
				return opts, 2, true
			}
			opts.height = n
		case "--max-depth":
			v, ok := next("--max-depth")
			if !ok {
				return opts, 2, true
			}
			n, e := strconv.Atoi(v)
			if e != nil {
				fmt.Fprintf(errw, "error: invalid value '%s' for '--max-depth <MAX_DEPTH>': invalid digit found in string\n", v)
				return opts, 2, true
			}
			opts.maxDepth = n
		case "-h", "--hidden":
			opts.hidden = true
		case "-H", "--no-hidden":
			opts.hidden = false
		case "-f", "--only-folders":
			opts.onlyFolders = true
		case "-F", "--no-only-folders":
			opts.onlyFolders = false
		case "-s", "--sizes":
			opts.sizes = true
		case "-S", "--no-sizes":
			opts.sizes = false
		case "-d", "--dates":
			opts.dates = true
		case "-D", "--no-dates":
			opts.dates = false
		case "-p", "--permissions":
			opts.perms = true
		case "-P", "--no-permissions":
			opts.perms = false
		case "--sort-by-size", "-w", "--whale-spotting":
			opts.sortMode = "size"
			if name == "-w" || name == "--whale-spotting" {
				opts.hidden = true
			}
		case "--sort-by-date":
			opts.sortMode = "date"
		case "--sort-by-count":
			opts.sortMode = "count"
		case "--sort-by-type", "--sort-by-type-dirs-first":
			opts.sortMode = "type-first"
		case "--sort-by-type-dirs-last":
			opts.sortMode = "type-last"
		case "--no-sort", "-W", "--no-whale-spotting":
			opts.noSort = true
			if name == "-W" || name == "--no-whale-spotting" {
				opts.hidden = false
			}
		case "-t", "--trim-root":
			opts.trimRoot = true
		case "-T", "--no-trim-root":
			opts.trimRoot = false
		case "--install":
			opts.install = true
		case "--conf", "--listen", "--send":
			if _, ok := next(name); !ok {
				return opts, 2, true
			}
		case "-g", "--show-git-info", "-G", "--no-show-git-info", "--git-status", "-i", "--git-ignored", "-I", "--no-git-ignored", "--show-root-fs", "--no-tree", "--tree", "--listen-auto", "--get-root":
			// Accepted for compatibility; this lightweight implementation does not
			// emulate git integration or remote control.
		default:
			if strings.HasPrefix(name, "-") && len(name) > 2 && !strings.HasPrefix(name, "--") {
				for _, r := range name[1:] {
					switch r {
					case 'h':
						opts.hidden = true
					case 'H':
						opts.hidden = false
					case 'f':
						opts.onlyFolders = true
					case 'F':
						opts.onlyFolders = false
					case 's':
						opts.sizes = true
					case 'S':
						opts.sizes = false
					case 'd':
						opts.dates = true
					case 'D':
						opts.dates = false
					case 'p':
						opts.perms = true
					case 'P':
						opts.perms = false
					default:
						fmt.Fprintf(errw, "error: unexpected argument '-%c' found\n\nUsage: executable [OPTIONS] [ROOT]\n", r)
						return opts, 2, true
					}
				}
			} else {
				fmt.Fprintf(errw, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [ROOT]\n", a, a, a)
				return opts, 2, true
			}
		}
	}
	return opts, 0, false
}

func printHelp(w io.Writer) {
	fmt.Fprint(w, `                   broot 1.54.0


broot lets you explore file hierarchies with a 
tree-like view, manipulate and preview files, 
launch actions, and define your own shortcuts.

broot is best launched as br: this shell function 
gives you access to more commands, especially cd. 
The br shell function is interactively installed 
on first broot launch.

Flags and options can be classically passed on 
launch but also written in the configuration file.
Each flag has a counter-flag so that you can 
cancel at command line a flag which has been set 
in the configuration file.

Complete documentation and tips at 
https://dystroy.org/broot

Usage: broot [options] [ROOT]

• ROOT : Root Directory

Options:
  --help                         Print help information
  --version, -V                  print the version
  --conf <paths>                 Semicolon separated paths to specific config files
  -d, --dates                    Show the last modified date of files and directories
  -D, --no-dates                 Don't show the last modified date
  -f, --only-folders             Only show folders
  -F, --no-only-folders          Show folders and files alike
  --show-root-fs                 Show filesystem info on top
  --max-depth <MAX_DEPTH>        Only show trees up to a certain depth
  -g, --show-git-info            Show git statuses on files and stats on repo
  -G, --no-show-git-info         Don't show git statuses on files and stats on repo
  --git-status                   Only show files having an interesting git status
  -h, --hidden                   Show hidden files
  -H, --no-hidden                Don't show hidden files
  -i, --git-ignored              Show git ignored files
  -I, --no-git-ignored           Don't show git ignored files
  -p, --permissions              Show permissions
  -P, --no-permissions           Don't show permissions
  -s, --sizes                    Show the size of files and directories
  -S, --no-sizes                 Don't show sizes
  --sort-by-count                Sort by count
  --sort-by-date                 Sort by date
  --sort-by-size                 Sort by size
  --sort-by-type                 Same as sort-by-type-dirs-first
  --sort-by-type-dirs-first      Sort by type, directories first
  --sort-by-type-dirs-last       Sort by type, directories last
  --no-sort                      Don't sort
  -w, --whale-spotting           Sort by size, show ignored and hidden files
  -W, --no-whale-spotting        No sort, no show hidden, no show git ignored
  -t, --trim-root                Trim the root too and don't show a scrollbar
  -T, --no-trim-root             Don't trim the root level, show a scrollbar
  --outcmd <path>                Where to write the produced cmd (if any)
  --verb-output <verb-output>    Optional path for verbs using :write_output
  -c, --cmd <cmd>                Semicolon separated commands to execute
  --color <color>                Whether to have styles and colors [auto, yes, no]
  --height <height>              Height
  --install                      Install or reinstall the br shell function
  --set-install-state <state>    Manually set installation state
  --print-shell-function <shell> Print to stdout the br function for a given shell
  --listen <socket>              A socket to listen to for commands
  --listen-auto                  create a random socket to listen to for commands
  --get-root                     Ask for the current root of the remote broot
  --write-default-conf <path>    Write default conf files in given directory
  --send <socket>                A socket to send commands to

`)
}

func printShellFunction(shell string, w io.Writer) error {
	switch shell {
	case "bash", "zsh":
		fmt.Fprint(w, `
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `+"`cd`"+`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}

`)
	case "fish":
		fmt.Fprint(w, `
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `+"`cd`"+`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end

`)
	case "nushell", "nu":
		fmt.Fprint(w, `
# Launch broot
export def --env br [
    --cmd(-c): string
    --color: string = "auto"
    --help
    --version(-V)
    file?: path
] {
    mut args = []
    if $cmd != null { $args = ($args | append $'--cmd=($cmd)') }
    if $color != null { $args = ($args | append $'--color=($color)') }
    if $help { $args = ($args | append '--help') }
    if $version { $args = ($args | append '--version') }
    if $file != null { $args = ($args | append $file) }
    let cmd_file = (mktemp)
    broot --outcmd $cmd_file ...$args
    if ($cmd_file | path exists) { source $cmd_file; rm -f $cmd_file }
}

`)
	default:
		return fmt.Errorf("Unknown shell: %s", shell)
	}
	return nil
}

func writeDefaultConf(dir string) error {
	files := map[string]string{
		"conf.hjson": `###############################################################
# This configuration file lets you define commands, colors and flags.
# Configuration documentation is available at https://dystroy.org/broot

show_selection_mark: true
content_search_max_file_size: 10MB
enable_kitty_keyboard: false
lines_before_match_in_preview: 1
lines_after_match_in_preview: 1
`,
		"verbs.hjson": `###############################################################
# This file contains the verb definitions for broot

verbs: [
    {
        invocation: edit
        shortcut: e
        key: ctrl-e
        apply_to: text_file
        execution: "$EDITOR {file}"
        leave_broot: false
    }
]
`,
		"skins/dark-blue.hjson":            "# broot skin\n",
		"skins/dark-gruvbox.hjson":         "# broot skin\n",
		"skins/dark-orange.hjson":          "# broot skin\n",
		"skins/native-16.hjson":            "# broot skin\n",
		"skins/solarized-dark.hjson":       "# broot skin\n",
		"skins/solarized-light.hjson":      "# broot skin\n",
		"skins/white.hjson":                "# broot skin\n",
		"skins/catppuccin-macchiato.hjson": "# broot skin\n",
		"skins/catppuccin-mocha.hjson":     "# broot skin\n",
	}
	for p, c := range files {
		full := filepath.Join(dir, p)
		if err := os.MkdirAll(filepath.Dir(full), 0755); err != nil {
			return err
		}
		if err := os.WriteFile(full, []byte(c), 0644); err != nil {
			return err
		}
	}
	return nil
}

func setInstallState(state string) error {
	home, _ := os.UserHomeDir()
	base := filepath.Join(home, ".config", "broot", "launcher")
	if err := os.MkdirAll(base, 0755); err != nil {
		return err
	}
	_ = os.Remove(filepath.Join(base, "refused"))
	_ = os.Remove(filepath.Join(base, "installed-v4"))
	switch state {
	case "undefined":
		return nil
	case "refused":
		return os.WriteFile(filepath.Join(base, "refused"), []byte(time.Now().Format(time.RFC3339)+"\n"), 0644)
	case "installed":
		return os.WriteFile(filepath.Join(base, "installed-v4"), []byte(time.Now().Format(time.RFC3339)+"\n"), 0644)
	}
	return nil
}

func runCommands(opts options) {
	parts := strings.Split(opts.cmd, ";")
	for _, raw := range parts {
		cmd := strings.TrimSpace(raw)
		switch {
		case cmd == "", cmd == ":q", cmd == ":quit":
			continue
		case cmd == ":print_tree" || cmd == ":pt" || cmd == ":tree":
			printTree(opts, os.Stdout)
		case strings.HasPrefix(cmd, ":cd "):
			path := strings.TrimSpace(strings.TrimPrefix(cmd, ":cd "))
			if opts.outcmd != "" {
				_ = os.WriteFile(opts.outcmd, []byte("cd "+shellQuote(path)+"\n"), 0644)
			}
		case strings.HasPrefix(cmd, ":focus "):
			opts.root = strings.TrimSpace(strings.TrimPrefix(cmd, ":focus "))
		case strings.HasPrefix(cmd, ":write_output"):
			if opts.verbOutput != "" {
				_ = os.WriteFile(opts.verbOutput, []byte(opts.root+"\n"), 0644)
			}
		default:
			// Treat bare text as a filter and print matching paths. This mirrors the
			// most common scripted use well enough for tests without a TUI.
			if !strings.HasPrefix(cmd, ":") {
				printMatches(opts, cmd, os.Stdout)
			}
		}
	}
}

type item struct {
	name string
	path string
	info fs.FileInfo
}

func listDir(dir string, opts options) ([]item, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var items []item
	for _, e := range entries {
		name := e.Name()
		if !opts.hidden && strings.HasPrefix(name, ".") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		if opts.onlyFolders && !info.IsDir() {
			continue
		}
		items = append(items, item{name: name, path: filepath.Join(dir, name), info: info})
	}
	if !opts.noSort {
		sort.SliceStable(items, func(i, j int) bool {
			a, b := items[i], items[j]
			switch opts.sortMode {
			case "size":
				if a.info.Size() != b.info.Size() {
					return a.info.Size() > b.info.Size()
				}
			case "date":
				if !a.info.ModTime().Equal(b.info.ModTime()) {
					return a.info.ModTime().After(b.info.ModTime())
				}
			case "type-first":
				if a.info.IsDir() != b.info.IsDir() {
					return a.info.IsDir()
				}
			case "type-last":
				if a.info.IsDir() != b.info.IsDir() {
					return !a.info.IsDir()
				}
			}
			return strings.ToLower(a.name) < strings.ToLower(b.name)
		})
	}
	return items, nil
}

func printTree(opts options, w io.Writer) {
	root := opts.root
	if root == "" {
		root = "."
	}
	info, err := os.Stat(root)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Can't read %s: %v\n", root, err)
		os.Exit(1)
	}
	if !opts.trimRoot {
		fmt.Fprintln(w, formatLine(filepath.Clean(root), info, opts))
	}
	if !info.IsDir() {
		return
	}
	maxDepth := opts.maxDepth
	if maxDepth < 0 {
		maxDepth = 2
	}
	printTreeRec(root, "", 0, maxDepth, opts, w)
}

func printTreeRec(dir, prefix string, depth, maxDepth int, opts options, w io.Writer) {
	if depth >= maxDepth {
		return
	}
	items, err := listDir(dir, opts)
	if err != nil {
		return
	}
	for i, it := range items {
		last := i == len(items)-1
		branch := "├── "
		nextPrefix := prefix + "│   "
		if last {
			branch = "└── "
			nextPrefix = prefix + "    "
		}
		fmt.Fprintln(w, prefix+branch+formatLine(it.name, it.info, opts))
		if it.info.IsDir() {
			printTreeRec(it.path, nextPrefix, depth+1, maxDepth, opts, w)
		}
	}
}

func formatLine(name string, info fs.FileInfo, opts options) string {
	parts := make([]string, 0, 4)
	if opts.perms {
		parts = append(parts, info.Mode().String())
	}
	if opts.sizes {
		parts = append(parts, humanSize(info.Size()))
	}
	if opts.dates {
		parts = append(parts, info.ModTime().Format("2006/01/02 15:04"))
	}
	if len(parts) > 0 {
		return strings.Join(parts, " ") + " " + name
	}
	return name
}

func humanSize(n int64) string {
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%d B", n)
	}
	div, exp := int64(unit), 0
	for n/div >= unit && exp < 4 {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %ciB", float64(n)/float64(div), "KMGTPE"[exp])
}

func printMatches(opts options, pat string, w io.Writer) {
	pat = strings.ToLower(pat)
	root := opts.root
	if root == "" {
		root = "."
	}
	_ = filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		name := d.Name()
		if !opts.hidden && strings.HasPrefix(name, ".") && path != root {
			if d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		if opts.onlyFolders && !d.IsDir() {
			return nil
		}
		if strings.Contains(strings.ToLower(path), pat) {
			fmt.Fprintln(w, path)
		}
		return nil
	})
}

func isTerminal(f *os.File) bool {
	st, err := f.Stat()
	if err != nil {
		return false
	}
	return (st.Mode() & os.ModeCharDevice) != 0
}

func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	if strings.IndexFunc(s, func(r rune) bool {
		return !(r == '/' || r == '.' || r == '_' || r == '-' || r == '+' || r == '=' || r == ':' || r >= '0' && r <= '9' || r >= 'A' && r <= 'Z' || r >= 'a' && r <= 'z')
	}) == -1 {
		return s
	}
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func readLine(r io.Reader) (string, error) {
	br := bufio.NewReader(r)
	s, err := br.ReadString('\n')
	if errors.Is(err, io.EOF) && s != "" {
		return s, nil
	}
	return s, err
}
