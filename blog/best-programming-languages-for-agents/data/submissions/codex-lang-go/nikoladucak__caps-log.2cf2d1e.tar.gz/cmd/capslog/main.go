package main

import (
	"bufio"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

const version = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3"

type options struct {
	config           string
	logDir           string
	logNameFormat    string
	sundayStart      bool
	firstLineSection bool
	password         string
	encrypt          bool
	decrypt          bool
	help             bool
}

type stringFlag struct {
	value string
	set   bool
}

func (s *stringFlag) String() string { return s.value }
func (s *stringFlag) Set(v string) error {
	s.value = v
	s.set = true
	return nil
}

type boolFlag struct {
	value bool
	set   bool
}

func (b *boolFlag) String() string {
	if b.value {
		return "true"
	}
	return "false"
}
func (b *boolFlag) Set(v string) error {
	switch strings.ToLower(v) {
	case "1", "t", "true", "y", "yes", "on":
		b.value = true
	case "0", "f", "false", "n", "no", "off":
		b.value = false
	default:
		return fmt.Errorf("invalid boolean value %q", v)
	}
	b.set = true
	return nil
}
func (b *boolFlag) IsBoolFlag() bool { return true }

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintf(os.Stderr, "Captain's log encountered an error: \n %s\n", err)
		os.Exit(1)
	}
}

func run(args []string) error {
	opts, err := parseArgs(args)
	if err != nil {
		return err
	}
	if opts.help {
		printHelp()
		return nil
	}

	cfg, err := readConfig(opts.config)
	if err != nil {
		return err
	}
	applyConfig(&opts, cfg)

	if opts.encrypt || opts.decrypt {
		fmt.Println("Applying crypto...")
		return visitLogDir(opts.logDir, opts.logNameFormat, func(path string) error { return nil })
	}

	return showAnnualView(opts)
}

func parseArgs(args []string) (options, error) {
	home, _ := os.UserHomeDir()
	opts := options{
		config:        filepath.Join(home, ".caps-log", "config.ini"),
		logDir:        filepath.Join(home, ".caps-log", "day"),
		logNameFormat: "d%y_%m_%d.md",
	}

	fs := flag.NewFlagSet("caps-log", flag.ContinueOnError)
	fs.SetOutput(new(strings.Builder))
	var cfg, logDir, logFmt, password stringFlag
	var sunday, firstLine, encrypt, decrypt, help boolFlag
	cfg.value = opts.config
	logDir.value = opts.logDir
	logFmt.value = opts.logNameFormat
	fs.Var(&help, "help", "")
	fs.Var(&help, "h", "")
	fs.Var(&cfg, "config", "")
	fs.Var(&cfg, "c", "")
	fs.Var(&logDir, "log-dir-path", "")
	fs.Var(&logFmt, "log-name-format", "")
	fs.Var(&sunday, "sunday-start", "")
	fs.Var(&firstLine, "first-line-section", "")
	fs.Var(&password, "password", "")
	fs.Var(&encrypt, "encrypt", "")
	fs.Var(&decrypt, "decrypt", "")

	if err := fs.Parse(args); err != nil {
		msg := err.Error()
		if strings.HasPrefix(msg, "flag provided but not defined: -") {
			name := strings.TrimPrefix(msg, "flag provided but not defined: -")
			if len(name) == 1 {
				return opts, fmt.Errorf("unrecognised option '-%s'", name)
			}
			return opts, fmt.Errorf("unrecognised option '--%s'", name)
		}
		if strings.Contains(msg, "flag needs an argument") {
			name := strings.TrimPrefix(strings.TrimSuffix(msg, " needs an argument"), "flag ")
			return opts, fmt.Errorf("the required argument for option '%s' is missing", name)
		}
		return opts, errors.New(msg)
	}
	if fs.NArg() > 0 {
		return opts, fmt.Errorf("unrecognised option '%s'", fs.Arg(0))
	}

	opts.config = cfg.value
	opts.logDir = logDir.value
	opts.logNameFormat = logFmt.value
	opts.password = password.value
	opts.sundayStart = sunday.value
	opts.firstLineSection = firstLine.value
	opts.encrypt = encrypt.value
	opts.decrypt = decrypt.value
	opts.help = help.value
	return opts, nil
}

func printHelp() {
	fmt.Printf("Captain's Log (caps-log)! A CLI journalig tool.\n")
	fmt.Printf("Version: %s\n", version)
	fmt.Println("Allowed options:")
	fmt.Println("  -h [ --help ]         show this message")
	fmt.Println("  -c [ --config ] arg   override the default config file path ")
	fmt.Println("                        (/home/agent/.caps-log/config.ini)")
	fmt.Println("  --log-dir-path arg    path where log files are stored")
	fmt.Println("  --log-name-format arg format in which log entry markdown files are saved")
	fmt.Println("  --sunday-start        have the calendar display sunday as first day of the ")
	fmt.Println("                        week")
	fmt.Println("  --first-line-section  override the default behaviour of ignoring sections ")
	fmt.Println("                        (lines starting with `#`) in the first line of a log ")
	fmt.Println("                        entry file")
	fmt.Println("  --password arg        password for encrypted log repositories or to be used ")
	fmt.Println("                        with --encrypt/--decrypt")
	fmt.Println("  --encrypt             apply encryption to all logs in log dir path (needs ")
	fmt.Println("                        --password)")
	fmt.Println("  --decrypt             apply decryption to all logs in log dir path (needs ")
	fmt.Println("                        --password)")
}

func readConfig(path string) (map[string]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("Failed to open file: %s", path)
	}
	defer f.Close()

	out := map[string]string{}
	section := ""
	sc := bufio.NewScanner(f)
	lineNo := 0
	for sc.Scan() {
		lineNo++
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = strings.TrimSpace(line[1 : len(line)-1])
			continue
		}
		idx := strings.Index(line, "=")
		if idx < 0 {
			return nil, fmt.Errorf("Failed to parse configuration file: <unspecified file>(%d): '=' character not found in line", lineNo)
		}
		key := strings.TrimSpace(line[:idx])
		val := strings.TrimSpace(stripInlineComment(line[idx+1:]))
		if section != "" {
			key = section + "." + key
		}
		out[key] = val
	}
	return out, sc.Err()
}

func stripInlineComment(s string) string {
	if i := strings.Index(s, " #"); i >= 0 {
		return s[:i]
	}
	return s
}

func applyConfig(opts *options, cfg map[string]string) {
	if v := cfg["log-dir-path"]; v != "" {
		opts.logDir = expandHome(v)
	}
	if v := cfg["log-filename-format"]; v != "" {
		opts.logNameFormat = v
	}
	if v := cfg["log-name-format"]; v != "" {
		opts.logNameFormat = v
	}
	if v := cfg["password"]; v != "" {
		opts.password = v
	}
	if parseBool(cfg["sunday-start"]) {
		opts.sundayStart = true
	}
	if parseBool(cfg["first-line-section"]) {
		opts.firstLineSection = true
	}
}

func expandHome(s string) string {
	if s == "~" || strings.HasPrefix(s, "~/") {
		if h, err := os.UserHomeDir(); err == nil {
			return filepath.Join(h, strings.TrimPrefix(s, "~/"))
		}
	}
	return s
}

func parseBool(s string) bool {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "1", "true", "yes", "on":
		return true
	default:
		return false
	}
}

func visitLogDir(dir, format string, fn func(string) error) error {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return fmt.Errorf("filesystem error: directory iterator cannot open directory: No such file or directory [%s]", dir)
	}
	re := formatRegexp(format)
	for _, ent := range entries {
		if ent.IsDir() || !re.MatchString(ent.Name()) {
			continue
		}
		if err := fn(filepath.Join(dir, ent.Name())); err != nil {
			return err
		}
	}
	return nil
}

func showAnnualView(opts options) error {
	logs := collectLogs(opts.logDir, opts.logNameFormat)
	now := time.Now()
	year := now.Year()
	count := 0
	for d := range logs {
		if d.Year() == year {
			count++
		}
	}

	fmt.Print("\x00\x1bP$q q\x1b\\\x1b[?1049h")
	fmt.Printf("\r       \x1b[1m\x1b[4mToday is: %02d. %02d. %04d.  | There are %d log entries for year %d.\x1b[22m\x1b[24m        \n", now.Day(), now.Month(), year, count, year)
	fmt.Println("╭Sections───────────╮╭Tags──────────────╮╭2026──────────────────┬┬────────────╮ ")
	fmt.Println("│> <select none>    ││> <select none>   │││16 17 18 19 20 21 22 ││20 21 22 23 │ ")
	sections, tags := scanSectionsAndTags(opts, logs)
	for i := 0; i < 14; i++ {
		left := ""
		right := ""
		if i < len(sections) {
			left = sections[i]
		}
		if i < len(tags) {
			right = tags[i]
		}
		fmt.Printf("│%-19s││%-18s│││%s││%s│ \n", truncate(left, 19), truncate(right, 18), calendarLine(i), sideLine(i))
	}
	fmt.Println("╰───────────────────╯╰──────────────────╯││ 6  7  8  9 10 11 12 ││ 3  4  5  6 │ ")
	fmt.Println("                                         ╰┴─────────────────────┴┴────────────╯ ")
	fmt.Println("╭──────────────────────────────────────────────────────────────────────────────╮")
	fmt.Printf("│                         log preview for %02d. %02d. %02d.                          │\n", now.Day(), now.Month(), year%100)
	for _, line := range previewForToday(opts, logs, now) {
		fmt.Printf("│ %-76s │\n", truncate(line, 76))
	}
	fmt.Println("│                                                                              │")
	fmt.Println("╰──────────────────────────────────────────────────────────────────────────────╯")

	for {
		time.Sleep(time.Hour)
	}
}

func collectLogs(dir, format string) map[time.Time]string {
	logs := map[time.Time]string{}
	re := formatRegexp(format)
	entries, err := os.ReadDir(dir)
	if err != nil {
		return logs
	}
	for _, ent := range entries {
		if ent.IsDir() || !re.MatchString(ent.Name()) {
			continue
		}
		if d, ok := parseDateFromName(ent.Name()); ok {
			logs[d] = filepath.Join(dir, ent.Name())
		}
	}
	return logs
}

func formatRegexp(format string) *regexp.Regexp {
	re := regexp.QuoteMeta(format)
	re = strings.ReplaceAll(re, "%Y", `\d{4}`)
	re = strings.ReplaceAll(re, "%y", `\d{2}`)
	re = strings.ReplaceAll(re, "%m", `\d{2}`)
	re = strings.ReplaceAll(re, "%d", `\d{2}`)
	return regexp.MustCompile("^" + re + "$")
}

func parseDateFromName(name string) (time.Time, bool) {
	re := regexp.MustCompile(`(\d{4}|\d{2})\D+(\d{2})\D+(\d{2})`)
	m := re.FindStringSubmatch(name)
	if len(m) != 4 {
		return time.Time{}, false
	}
	year := atoi(m[1])
	if year < 100 {
		year += 2000
	}
	month := atoi(m[2])
	day := atoi(m[3])
	t := time.Date(year, time.Month(month), day, 0, 0, 0, 0, time.Local)
	if t.Year() != year || int(t.Month()) != month || t.Day() != day {
		return time.Time{}, false
	}
	return t, true
}

func atoi(s string) int {
	n := 0
	for _, r := range s {
		if r >= '0' && r <= '9' {
			n = n*10 + int(r-'0')
		}
	}
	return n
}

func scanSectionsAndTags(opts options, logs map[time.Time]string) ([]string, []string) {
	secSet := map[string]bool{}
	tagSet := map[string]bool{}
	for _, path := range logs {
		f, err := os.Open(path)
		if err != nil {
			continue
		}
		sc := bufio.NewScanner(f)
		lineNo := 0
		for sc.Scan() {
			lineNo++
			line := strings.TrimSpace(sc.Text())
			if strings.HasPrefix(line, "#") && (lineNo != 1 || opts.firstLineSection) {
				sec := strings.TrimSpace(strings.TrimLeft(line, "#"))
				if sec != "" {
					secSet[sec] = true
				}
			}
			if strings.HasPrefix(line, "*") {
				tag := strings.TrimSpace(strings.TrimPrefix(line, "*"))
				if i := strings.Index(tag, ":"); i >= 0 {
					tag = tag[:i]
				}
				if tag != "" {
					tagSet[tag] = true
				}
			}
		}
		f.Close()
	}
	return sortedKeys(secSet), sortedKeys(tagSet)
}

func sortedKeys(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func previewForToday(opts options, logs map[time.Time]string, now time.Time) []string {
	key := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	path := logs[key]
	if path == "" {
		return []string{"", ""}
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return []string{"", ""}
	}
	lines := strings.Split(strings.ReplaceAll(string(data), "\r\n", "\n"), "\n")
	out := []string{}
	for _, line := range lines {
		if strings.TrimSpace(line) != "" {
			out = append(out, line)
		}
		if len(out) == 2 {
			break
		}
	}
	for len(out) < 2 {
		out = append(out, "")
	}
	return out
}

func calendarLine(i int) string {
	lines := []string{
		"30 31                ",
		"╰─────────────────────╯",
		"╭May──────────────────╮",
		"│ M  T  W  T  F  S  S ",
		"│             1  2  3 ",
		"│ 4  5  6  7  8  9 10",
		"│11 12 13 14 15 16 17",
		"│18 19 20 21 22 23 24",
		"│25 26 27 28 29 30 31",
		"╰─────────────────────╯",
		"╭July─────────────────╮",
		"│ M  T  W  T  F  S  S ",
		"│       1  2  3  4  5 ",
		"│ 6  7  8  9 10 11 12",
	}
	return lines[i%len(lines)]
}

func sideLine(i int) string {
	lines := []string{
		"            ",
		"────────────┤",
		"╭June────────┤",
		"│ M  T  W  T ",
		"│ 1  2  3  4 ",
		"│ 8  9 10 11 ",
		"│15 16 17 18 ",
		"│22 23 24 25 ",
		"│29 30       ",
		"╰────────────┤",
		"╭August──────┤",
		"│ M  T  W  T ",
		"│            ",
		"│ 3  4  5  6 ",
	}
	return lines[i%len(lines)]
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) > n {
		return string(r[:n])
	}
	return s
}
