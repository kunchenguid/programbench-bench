module capslog

go 1.21
