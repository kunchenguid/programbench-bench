package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

var defaultIgnoreSigs = []string{
	".Errorf(",
	"errors.New(",
	"errors.Unwrap(",
	"errors.Join(",
	".Wrap(",
	".Wrapf(",
	".WithMessage(",
	".WithMessagef(",
	".WithStack(",
}

type pkgInfo struct {
	ImportPath  string
	Dir         string
	GoFiles     []string
	TestGoFiles []string
	Error       *struct{ Err string }
}

type config struct {
	IgnoreSigs             []string
	ExtraIgnoreSigs        []string
	IgnoreSigRegexps       []string
	IgnorePackageGlobs     []string
	IgnoreInterfaceRegexps []string
	ReportInternalErrors   bool
}

type diagnostic struct {
	Pos     token.Position
	Msg     string
	PkgPath string
}

type analyzer struct {
	fset       *token.FileSet
	pkg        pkgInfo
	cfg        config
	ignoreSigs []string
	ignoreRe   []*regexp.Regexp
	imports    map[string]string
	decls      map[string]funcSig
}

type funcSig struct {
	name       string
	recv       string
	returnsErr bool
	params     []string
}

func main() {
	os.Exit(run())
}

func run() int {
	fs := flag.NewFlagSet("wrapcheck", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	fs.Usage = func() {
		fmt.Fprintln(fs.Output(), "wrapcheck: Checks that errors returned from external packages are wrapped")
		fmt.Fprintln(fs.Output())
		fmt.Fprintln(fs.Output(), "Usage: wrapcheck [-flag] [package]")
		fmt.Fprintln(fs.Output())
		fmt.Fprintln(fs.Output())
		fmt.Fprintln(fs.Output(), "Flags:")
		fs.PrintDefaults()
	}
	var (
		showV, all, source, verbose, flagsJSON, jsonOut bool
		testFiles                                       = true
		context                                         = -1
		tags, debug, cpu, mem, trace                    string
		fix, diff                                       bool
	)
	fs.BoolVar(&showV, "V", false, "print version and exit")
	fs.BoolVar(&all, "all", false, "no effect (deprecated)")
	fs.BoolVar(&source, "source", false, "no effect (deprecated)")
	fs.BoolVar(&verbose, "v", false, "no effect (deprecated)")
	fs.BoolVar(&flagsJSON, "flags", false, "print analyzer flags in JSON")
	fs.BoolVar(&jsonOut, "json", false, "emit JSON output")
	fs.BoolVar(&testFiles, "test", true, "indicates whether test files should be analyzed, too")
	fs.IntVar(&context, "c", -1, "display offending line with this many lines of context")
	fs.StringVar(&tags, "tags", "", "no effect (deprecated)")
	fs.StringVar(&debug, "debug", "", `debug flags, any subset of "fpstv"`)
	fs.StringVar(&cpu, "cpuprofile", "", "write CPU profile to this file")
	fs.StringVar(&mem, "memprofile", "", "write memory profile to this file")
	fs.StringVar(&trace, "trace", "", "write trace log to this file")
	fs.BoolVar(&fix, "fix", false, "apply all suggested fixes")
	fs.BoolVar(&diff, "diff", false, "with -fix, don't update the files, but print a unified diff")
	_ = all
	_ = source
	_ = verbose
	_ = tags
	_ = debug
	_ = cpu
	_ = mem
	_ = trace
	_ = fix
	_ = diff

	if err := fs.Parse(os.Args[1:]); err != nil {
		return 1
	}
	if showV {
		fmt.Fprintln(os.Stderr, "wrapcheck: unsupported flag value: -V=true (use -V=full)")
		return 1
	}
	if flagsJSON {
		printFlagsJSON()
		return 0
	}
	patterns := fs.Args()
	if len(patterns) == 0 {
		patterns = []string{"."}
	}
	pkgs, err := listPackages(patterns)
	if err != nil {
		fmt.Fprint(os.Stderr, err)
		return 1
	}
	cfg := readConfig()
	var diags []diagnostic
	for _, p := range pkgs {
		if p.Error != nil {
			fmt.Fprintf(os.Stderr, "%s\n", p.Error.Err)
			continue
		}
		diags = append(diags, analyzePackage(p, cfg, testFiles)...)
	}
	sort.Slice(diags, func(i, j int) bool {
		a, b := diags[i].Pos, diags[j].Pos
		if a.Filename != b.Filename {
			return a.Filename < b.Filename
		}
		if a.Line != b.Line {
			return a.Line < b.Line
		}
		return a.Column < b.Column
	})
	if jsonOut {
		printJSON(diags)
		return 0
	}
	for _, d := range diags {
		fmt.Printf("%s:%d:%d: %s\n", d.Pos.Filename, d.Pos.Line, d.Pos.Column, d.Msg)
		if context >= 0 {
			printContext(d.Pos.Filename, d.Pos.Line, context)
		}
	}
	if len(diags) > 0 {
		return 3
	}
	return 0
}

func printFlagsJSON() {
	type f struct {
		Name  string
		Bool  bool
		Usage string
	}
	out := []f{
		{"V", true, "print version and exit"},
		{"all", true, "no effect (deprecated)"},
		{"c", false, "display offending line with this many lines of context"},
		{"diff", true, "with -fix, don't update the files, but print a unified diff"},
		{"flags", true, "print analyzer flags in JSON"},
		{"json", true, "emit JSON output"},
		{"source", true, "no effect (deprecated)"},
		{"tags", false, "no effect (deprecated)"},
		{"test", true, "indicates whether test files should be analyzed, too"},
		{"v", true, "no effect (deprecated)"},
	}
	b, _ := json.MarshalIndent(out, "", "\t")
	fmt.Println(string(b))
}

func listPackages(patterns []string) ([]pkgInfo, error) {
	args := append([]string{"list", "-json"}, patterns...)
	cmd := exec.Command("go", args...)
	var out, errb bytes.Buffer
	cmd.Stdout, cmd.Stderr = &out, &errb
	if err := cmd.Run(); err != nil {
		if errb.Len() > 0 {
			return nil, fmt.Errorf("%s", errb.String())
		}
		return nil, err
	}
	dec := json.NewDecoder(&out)
	var pkgs []pkgInfo
	for dec.More() {
		var p pkgInfo
		if err := dec.Decode(&p); err != nil {
			return nil, err
		}
		pkgs = append(pkgs, p)
	}
	return pkgs, nil
}

func readConfig() config {
	var cfg config
	for _, path := range []string{".wrapcheck.yaml", ".wrapcheck.yml", filepath.Join(os.Getenv("HOME"), ".wrapcheck.yaml"), filepath.Join(os.Getenv("HOME"), ".wrapcheck.yml")} {
		b, err := os.ReadFile(path)
		if err == nil {
			parseYAMLConfig(string(b), &cfg)
			break
		}
	}
	return cfg
}

func parseYAMLConfig(s string, cfg *config) {
	sc := bufio.NewScanner(strings.NewReader(s))
	var key string
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasSuffix(line, ":") {
			key = strings.TrimSuffix(line, ":")
			continue
		}
		if i := strings.Index(line, ":"); i >= 0 && !strings.HasPrefix(line, "-") {
			k := strings.TrimSpace(line[:i])
			v := strings.Trim(strings.TrimSpace(line[i+1:]), `"'`)
			if k == "reportInternalErrors" {
				cfg.ReportInternalErrors = strings.EqualFold(v, "true")
			}
			key = k
			continue
		}
		if strings.HasPrefix(line, "-") {
			v := strings.Trim(strings.TrimSpace(strings.TrimPrefix(line, "-")), `"'`)
			switch key {
			case "ignoreSigs":
				cfg.IgnoreSigs = append(cfg.IgnoreSigs, v)
			case "extraIgnoreSigs":
				cfg.ExtraIgnoreSigs = append(cfg.ExtraIgnoreSigs, v)
			case "ignoreSigRegexps":
				cfg.IgnoreSigRegexps = append(cfg.IgnoreSigRegexps, v)
			case "ignorePackageGlobs":
				cfg.IgnorePackageGlobs = append(cfg.IgnorePackageGlobs, v)
			case "ignoreInterfaceRegexps":
				cfg.IgnoreInterfaceRegexps = append(cfg.IgnoreInterfaceRegexps, v)
			}
		}
	}
}

func analyzePackage(p pkgInfo, cfg config, includeTests bool) []diagnostic {
	fset := token.NewFileSet()
	files := append([]string{}, p.GoFiles...)
	if includeTests {
		files = append(files, p.TestGoFiles...)
	}
	var astFiles []*ast.File
	imports := map[string]string{}
	for _, name := range files {
		path := filepath.Join(p.Dir, name)
		f, err := parser.ParseFile(fset, path, nil, 0)
		if err != nil {
			continue
		}
		astFiles = append(astFiles, f)
		for _, im := range f.Imports {
			ip, _ := strconv.Unquote(im.Path.Value)
			alias := filepath.Base(ip)
			if im.Name != nil {
				alias = im.Name.Name
			}
			if alias != "_" && alias != "." {
				imports[alias] = ip
			}
		}
	}
	decls := collectDecls(astFiles)
	ignore := defaultIgnoreSigs
	if len(cfg.IgnoreSigs) > 0 {
		ignore = cfg.IgnoreSigs
	}
	ignore = append(append([]string{}, ignore...), cfg.ExtraIgnoreSigs...)
	var res []*regexp.Regexp
	for _, s := range cfg.IgnoreSigRegexps {
		if re, err := regexp.Compile(s); err == nil {
			res = append(res, re)
		}
	}
	a := &analyzer{fset: fset, pkg: p, cfg: cfg, ignoreSigs: ignore, ignoreRe: res, imports: imports, decls: decls}
	var diags []diagnostic
	for _, f := range astFiles {
		for _, d := range f.Decls {
			if fn, ok := d.(*ast.FuncDecl); ok && returnsError(fn.Type.Results) {
				diags = append(diags, a.analyzeFunc(fn)...)
			}
		}
	}
	return diags
}

func collectDecls(files []*ast.File) map[string]funcSig {
	out := map[string]funcSig{}
	for _, f := range files {
		for _, d := range f.Decls {
			fn, ok := d.(*ast.FuncDecl)
			if !ok {
				continue
			}
			s := funcSig{name: fn.Name.Name, returnsErr: returnsError(fn.Type.Results)}
			if fn.Recv != nil && len(fn.Recv.List) > 0 {
				s.recv = exprString(fn.Recv.List[0].Type)
			}
			if fn.Type.Params != nil {
				for _, p := range fn.Type.Params.List {
					s.params = append(s.params, exprString(p.Type))
				}
			}
			out[fn.Name.Name] = s
		}
	}
	return out
}

func returnsError(fl *ast.FieldList) bool {
	if fl == nil {
		return false
	}
	for _, f := range fl.List {
		if exprString(f.Type) == "error" {
			return true
		}
	}
	return false
}

func (a *analyzer) analyzeFunc(fn *ast.FuncDecl) []diagnostic {
	origins := map[string]string{}
	types := map[string]string{}
	var diags []diagnostic
	ast.Inspect(fn.Body, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.AssignStmt:
			if len(x.Rhs) == 1 && len(x.Lhs) > 1 {
				if sig := a.originOf(x.Rhs[0], origins, types); sig != "" {
					if id, ok := x.Lhs[len(x.Lhs)-1].(*ast.Ident); ok {
						origins[id.Name] = sig
					}
				}
				return true
			}
			for i, rhs := range x.Rhs {
				if i >= len(x.Lhs) {
					continue
				}
				id, ok := x.Lhs[i].(*ast.Ident)
				if !ok {
					continue
				}
				if sig := a.originOf(rhs, origins, types); sig != "" {
					origins[id.Name] = sig
				}
			}
		case *ast.ValueSpec:
			for _, name := range x.Names {
				if x.Type != nil {
					types[name.Name] = exprString(x.Type)
				}
			}
			if len(x.Values) == 1 && len(x.Names) > 1 {
				if sig := a.originOf(x.Values[0], origins, types); sig != "" {
					origins[x.Names[len(x.Names)-1].Name] = sig
				}
				return true
			}
			for i, val := range x.Values {
				if i >= len(x.Names) {
					continue
				}
				if types[x.Names[i].Name] == "" {
					types[x.Names[i].Name] = typeOfExpr(val)
				}
				if sig := a.originOf(val, origins, types); sig != "" {
					origins[x.Names[i].Name] = sig
				}
			}
		case *ast.DeclStmt:
			// handled through ValueSpec nodes as the walk descends
		case *ast.ReturnStmt:
			for _, e := range x.Results {
				if sig := a.originOf(e, origins, types); sig != "" && !a.ignored(sig) {
					pos := a.fset.Position(e.Pos())
					diags = append(diags, diagnostic{Pos: pos, PkgPath: a.pkg.ImportPath, Msg: "error returned from external package is unwrapped: sig: " + sig})
				}
			}
			return false
		}
		return true
	})
	return diags
}

func (a *analyzer) originOf(e ast.Expr, origins map[string]string, types map[string]string) string {
	switch x := e.(type) {
	case *ast.Ident:
		return origins[x.Name]
	case *ast.CallExpr:
		return a.callSig(x, types)
	}
	return ""
}

func (a *analyzer) callSig(c *ast.CallExpr, types map[string]string) string {
	switch f := c.Fun.(type) {
	case *ast.SelectorExpr:
		left := exprString(f.X)
		if ip := a.imports[left]; ip != "" {
			if a.isIgnoredPackage(ip) {
				return ""
			}
			if !a.cfg.ReportInternalErrors && ip == a.pkg.ImportPath {
				return ""
			}
			if ip == "fmt" && f.Sel.Name == "Errorf" {
				return "func fmt.Errorf(format string, a ...any) error"
			}
			if ip == "errors" && f.Sel.Name == "New" {
				return "func errors.New(text string) error"
			}
			if ip == "errors" && f.Sel.Name == "Unwrap" {
				return "func errors.Unwrap(err error) error"
			}
			if ip == "errors" && f.Sel.Name == "Join" {
				return "func errors.Join(errs ...error) error"
			}
			return "func " + ip + "." + f.Sel.Name + "(" + guessParams(c) + ") error"
		}
		// Method call on a value from an imported type, e.g. ext.T{}.M() or t.M().
		if ce, ok := f.X.(*ast.CompositeLit); ok {
			if se, ok := ce.Type.(*ast.SelectorExpr); ok {
				if ip := a.imports[exprString(se.X)]; ip != "" {
					if a.isIgnoredPackage(ip) {
						return ""
					}
					return "func (" + ip + "." + se.Sel.Name + ")." + f.Sel.Name + "() error"
				}
			}
		}
		if id, ok := f.X.(*ast.Ident); ok {
			if typ := types[id.Name]; typ != "" {
				base := strings.TrimPrefix(typ, "*")
				if dot := strings.Index(base, "."); dot > 0 {
					alias, name := base[:dot], base[dot+1:]
					if ip := a.imports[alias]; ip != "" {
						if a.isIgnoredPackage(ip) {
							return ""
						}
						prefix := ip + "." + name
						if strings.HasPrefix(typ, "*") {
							prefix = "*" + prefix
						}
						return "func (" + prefix + ")." + f.Sel.Name + "() error"
					}
				}
			}
		}
		// Unknown receiver. Report as external-looking only if selector base is not a local package function.
		if left != "" && left != "err" {
			return "func (" + left + ")." + f.Sel.Name + "() error"
		}
	case *ast.Ident:
		if sig, ok := a.decls[f.Name]; ok && sig.returnsErr {
			return ""
		}
	}
	return ""
}

func typeOfExpr(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.CompositeLit:
		return exprString(x.Type)
	case *ast.UnaryExpr:
		if x.Op == token.AND {
			return "*" + typeOfExpr(x.X)
		}
	}
	return ""
}

func (a *analyzer) isIgnoredPackage(ip string) bool {
	for _, g := range a.cfg.IgnorePackageGlobs {
		if ok, _ := filepath.Match(g, ip); ok {
			return true
		}
	}
	return false
}

func (a *analyzer) ignored(sig string) bool {
	for _, s := range a.ignoreSigs {
		if strings.Contains(sig, s) {
			return true
		}
	}
	for _, re := range a.ignoreRe {
		if re.MatchString(sig) {
			return true
		}
	}
	return false
}

func guessParams(c *ast.CallExpr) string {
	if len(c.Args) == 0 {
		return ""
	}
	var ps []string
	for range c.Args {
		ps = append(ps, "...")
	}
	return strings.Join(ps, ", ")
}

func exprString(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.Ident:
		return x.Name
	case *ast.SelectorExpr:
		return exprString(x.X) + "." + x.Sel.Name
	case *ast.StarExpr:
		return "*" + exprString(x.X)
	case *ast.ArrayType:
		return "[]" + exprString(x.Elt)
	case *ast.MapType:
		return "map[" + exprString(x.Key) + "]" + exprString(x.Value)
	case *ast.InterfaceType:
		return "interface{}"
	case *ast.CallExpr:
		return exprString(x.Fun)
	}
	return ""
}

func printJSON(diags []diagnostic) {
	type jd struct {
		Posn    string `json:"posn"`
		Message string `json:"message"`
	}
	out := map[string]map[string][]jd{}
	for _, d := range diags {
		if _, ok := out[d.PkgPath]; !ok {
			out[d.PkgPath] = map[string][]jd{}
		}
		out[d.PkgPath]["wrapcheck"] = append(out[d.PkgPath]["wrapcheck"], jd{
			Posn:    fmt.Sprintf("%s:%d:%d", d.Pos.Filename, d.Pos.Line, d.Pos.Column),
			Message: d.Msg,
		})
	}
	b, _ := json.MarshalIndent(out, "", "\t")
	fmt.Println(string(b))
}

func printContext(file string, line, n int) {
	b, err := os.ReadFile(file)
	if err != nil {
		return
	}
	lines := strings.Split(string(b), "\n")
	start := line - n
	if start < 1 {
		start = 1
	}
	end := line + n
	if end > len(lines) {
		end = len(lines)
	}
	for i := start; i <= end; i++ {
		fmt.Printf("%d\t%s\n", i, lines[i-1])
	}
}
