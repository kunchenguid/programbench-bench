package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"go/ast"
	"go/importer"
	"go/parser"
	"go/printer"
	"go/token"
	"go/types"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type valueList []string

func (v *valueList) String() string     { return strings.Join(*v, ",") }
func (v *valueList) Set(s string) error { *v = append(*v, s); return nil }

type options struct {
	abspath         bool
	asserts         bool
	blank           bool
	exclude         string
	excludeOnly     bool
	ignore          valueList
	ignoreGenerated bool
	ignorePkg       string
	ignoreTests     bool
	mod             string
	tags            valueList
	verbose         bool
}

type pkgJSON struct {
	ImportPath   string
	Name         string
	Dir          string
	GoFiles      []string
	TestGoFiles  []string
	XTestGoFiles []string
	Error        *struct{ Err string }
}

type diag struct {
	file string
	line int
	col  int
	text string
	fn   string
}

type ignoreRule struct {
	pkg string
	re  *regexp.Regexp
}

type checker struct {
	opt         options
	fset        *token.FileSet
	info        *types.Info
	lines       map[string][]string
	cwd         string
	excludes    map[string]bool
	ignoreRules []ignoreRule
	ignorePkgs  map[string]bool
}

func main() {
	var opt options
	flag.BoolVar(&opt.abspath, "abspath", false, "print absolute paths to files")
	flag.BoolVar(&opt.asserts, "asserts", false, "if true, check for ignored type assertion results")
	flag.BoolVar(&opt.blank, "blank", false, "if true, check for errors assigned to blank identifier")
	flag.StringVar(&opt.exclude, "exclude", "", "Path to a file containing a list of functions to exclude from checking")
	flag.BoolVar(&opt.excludeOnly, "excludeonly", false, "Use only excludes from -exclude file")
	flag.Var(&opt.ignore, "ignore", "[deprecated] comma-separated list of pairs of the form pkg:regex\n            the regex is used to ignore names within pkg.")
	flag.BoolVar(&opt.ignoreGenerated, "ignoregenerated", false, "if true, checking of files with generated code is disabled")
	flag.StringVar(&opt.ignorePkg, "ignorepkg", "", "comma-separated list of package paths to ignore")
	flag.BoolVar(&opt.ignoreTests, "ignoretests", false, "if true, checking of _test.go files is disabled")
	flag.StringVar(&opt.mod, "mod", "", "module download mode to use: readonly or vendor. See 'go help modules' for more.")
	flag.Var(&opt.tags, "tags", "comma or space-separated list of build tags to include")
	flag.BoolVar(&opt.verbose, "verbose", false, "produce more verbose logging")
	flag.Parse()

	if flag.NArg() == 0 {
		os.Exit(0)
	}
	code, err := run(opt, flag.Args())
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
	}
	os.Exit(code)
}

func run(opt options, patterns []string) (int, error) {
	excludes := map[string]bool{}
	if !opt.excludeOnly {
		addDefaultExcludes(excludes)
	}
	if opt.exclude != "" {
		if err := readExcludeFile(opt.exclude, excludes); err != nil {
			return 2, err
		}
	}
	ignoreRules, err := parseIgnore(opt.ignore)
	if err != nil {
		return 2, err
	}
	for _, r := range ignoreRules {
		if r.pkg == "fmt" {
			for k := range excludes {
				if strings.HasPrefix(k, "fmt.") {
					delete(excludes, k)
				}
			}
		}
	}
	ignorePkgs := map[string]bool{}
	for _, p := range strings.Split(opt.ignorePkg, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			ignorePkgs[p] = true
		}
	}
	pkgs, err := goList(opt, patterns)
	if err != nil {
		return 2, err
	}
	var all []diag
	for _, p := range pkgs {
		if p.Error != nil {
			return 2, errors.New(p.Error.Err)
		}
		if ignorePkgs[p.ImportPath] {
			continue
		}
		if opt.verbose {
			fmt.Fprintf(os.Stderr, "checking %s\n", p.ImportPath)
		}
		ds, err := checkPackage(opt, p, excludes, ignoreRules, ignorePkgs)
		if err != nil {
			return 2, fmt.Errorf("failed to check packages: %v", err)
		}
		all = append(all, ds...)
	}
	sort.SliceStable(all, func(i, j int) bool {
		if all[i].file != all[j].file {
			return all[i].file < all[j].file
		}
		if all[i].line != all[j].line {
			return all[i].line < all[j].line
		}
		return all[i].col < all[j].col
	})
	cwd, _ := os.Getwd()
	for _, d := range all {
		file := d.file
		if opt.abspath {
			if abs, err := filepath.Abs(file); err == nil {
				file = abs
			}
		} else if cwd != "" {
			if rel, err := filepath.Rel(cwd, file); err == nil && !strings.HasPrefix(rel, "..") {
				file = rel
			}
		}
		if opt.verbose && d.fn != "" {
			fmt.Printf("%s:%d:%d:\t%s\t%s\n", file, d.line, d.col, d.fn, d.text)
		} else {
			fmt.Printf("%s:%d:%d:\t%s\n", file, d.line, d.col, d.text)
		}
	}
	if len(all) > 0 {
		return 1, nil
	}
	return 0, nil
}

func goList(opt options, patterns []string) ([]pkgJSON, error) {
	args := []string{"list", "-json"}
	if opt.mod != "" {
		args = append(args, "-mod="+opt.mod)
	}
	if len(opt.tags) > 0 {
		var tagParts []string
		for _, raw := range opt.tags {
			for _, tag := range strings.FieldsFunc(raw, func(r rune) bool { return r == ',' || r == ' ' || r == '\t' || r == '\n' }) {
				if tag != "" {
					tagParts = append(tagParts, tag)
				}
			}
		}
		tags := strings.Join(tagParts, " ")
		args = append(args, "-tags="+tags)
	}
	args = append(args, patterns...)
	cmd := exec.Command("go", args...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("failed to load packages: %s", strings.TrimSpace(string(out)))
	}
	dec := json.NewDecoder(bytes.NewReader(out))
	var pkgs []pkgJSON
	for dec.More() {
		var p pkgJSON
		if err := dec.Decode(&p); err != nil {
			return nil, err
		}
		if p.ImportPath != "" {
			pkgs = append(pkgs, p)
		}
	}
	return pkgs, nil
}

func checkPackage(opt options, p pkgJSON, excludes map[string]bool, rules []ignoreRule, ignorePkgs map[string]bool) ([]diag, error) {
	fset := token.NewFileSet()
	var files []*ast.File
	paths := append([]string{}, p.GoFiles...)
	if !opt.ignoreTests {
		paths = append(paths, p.TestGoFiles...)
	}
	for _, name := range paths {
		path := filepath.Join(p.Dir, name)
		if opt.ignoreGenerated && isGenerated(path) {
			continue
		}
		f, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
		if err != nil {
			return nil, err
		}
		files = append(files, f)
	}
	if len(files) == 0 {
		return nil, nil
	}
	info := &types.Info{Types: map[ast.Expr]types.TypeAndValue{}, Uses: map[*ast.Ident]types.Object{}, Defs: map[*ast.Ident]types.Object{}, Selections: map[*ast.SelectorExpr]*types.Selection{}}
	conf := types.Config{Importer: importer.For("source", nil), Error: func(error) {}}
	_, _ = conf.Check(p.ImportPath, fset, files, info)
	cwd, _ := os.Getwd()
	c := &checker{opt: opt, fset: fset, info: info, lines: map[string][]string{}, cwd: cwd, excludes: excludes, ignoreRules: rules, ignorePkgs: ignorePkgs}
	var ds []diag
	for _, f := range files {
		ast.Inspect(f, func(n ast.Node) bool {
			switch x := n.(type) {
			case *ast.ExprStmt:
				if c.exprHasUncheckedError(x.X) && !c.isExcludedCall(x.X) {
					ds = append(ds, c.newCallDiag(x.X, c.callName(x.X)))
				}
				if opt.asserts && c.isTypeAssert(x.X) {
					ds = append(ds, c.newDiag(x.X, ""))
				}
			case *ast.GoStmt:
				if x.Call != nil && c.exprHasUncheckedError(x.Call) && !c.isExcludedCall(x.Call) {
					ds = append(ds, c.newCallDiag(x.Call, c.callName(x.Call)))
				}
			case *ast.DeferStmt:
				if x.Call != nil && c.exprHasUncheckedError(x.Call) && !c.isExcludedCall(x.Call) {
					ds = append(ds, c.newCallDiag(x.Call, c.callName(x.Call)))
				}
			case *ast.AssignStmt:
				if opt.blank {
					ds = append(ds, c.checkBlankAssign(x)...)
				}
				if opt.asserts {
					ds = append(ds, c.checkAssertAssign(x)...)
				}
			case *ast.ValueSpec:
				if opt.blank {
					ds = append(ds, c.checkBlankValueSpec(x)...)
				}
			}
			return true
		})
	}
	return ds, nil
}

func (c *checker) checkBlankAssign(a *ast.AssignStmt) []diag {
	var ds []diag
	if len(a.Lhs) == 1 && len(a.Rhs) == 1 {
		if id, ok := a.Lhs[0].(*ast.Ident); ok && id.Name == "_" && isCallLike(a.Rhs[0]) && c.exprHasUncheckedError(a.Rhs[0]) && !c.isExcludedCall(a.Rhs[0]) {
			ds = append(ds, c.newDiag(a, c.callName(a.Rhs[0])))
		}
		return ds
	}
	for i, lhs := range a.Lhs {
		id, ok := lhs.(*ast.Ident)
		if !ok || id.Name != "_" {
			continue
		}
		if len(a.Rhs) == 1 {
			if c.nthResultIsError(a.Rhs[0], i) && !c.isExcludedCall(a.Rhs[0]) {
				ds = append(ds, c.newDiag(a, c.callName(a.Rhs[0])))
				break
			}
		} else if i < len(a.Rhs) && isCallLike(a.Rhs[i]) && c.exprReturnsError(a.Rhs[i]) && !c.isExcludedCall(a.Rhs[i]) {
			ds = append(ds, c.newDiag(a, c.callName(a.Rhs[i])))
			break
		}
	}
	return ds
}

func (c *checker) checkBlankValueSpec(v *ast.ValueSpec) []diag {
	var ds []diag
	for i, name := range v.Names {
		if name.Name != "_" {
			continue
		}
		if len(v.Values) == 1 {
			if c.nthResultIsError(v.Values[0], i) && !c.isExcludedCall(v.Values[0]) {
				ds = append(ds, c.newDiag(v, c.callName(v.Values[0])))
				break
			}
		} else if i < len(v.Values) && isCallLike(v.Values[i]) && c.exprReturnsError(v.Values[i]) && !c.isExcludedCall(v.Values[i]) {
			ds = append(ds, c.newDiag(v, c.callName(v.Values[i])))
			break
		}
	}
	return ds
}

func (c *checker) checkAssertAssign(a *ast.AssignStmt) []diag {
	var ds []diag
	for _, r := range a.Rhs {
		if c.isTypeAssert(r) {
			ds = append(ds, c.newDiag(r, ""))
			break
		}
	}
	return ds
}

func (c *checker) exprHasUncheckedError(e ast.Expr) bool {
	tv, ok := c.info.Types[e]
	if !ok {
		return false
	}
	return typeContainsError(tv.Type)
}

func (c *checker) exprReturnsError(e ast.Expr) bool {
	tv, ok := c.info.Types[e]
	if !ok {
		return false
	}
	return isErrorType(tv.Type)
}

func isCallLike(e ast.Expr) bool {
	_, ok := unparen(e).(*ast.CallExpr)
	return ok
}

func (c *checker) nthResultIsError(e ast.Expr, n int) bool {
	tv, ok := c.info.Types[e]
	if !ok || tv.Type == nil {
		return false
	}
	if t, ok := tv.Type.(*types.Tuple); ok {
		return n < t.Len() && isErrorType(t.At(n).Type())
	}
	return n == 0 && isErrorType(tv.Type)
}

func typeContainsError(t types.Type) bool {
	if t == nil {
		return false
	}
	if tup, ok := t.(*types.Tuple); ok {
		for i := 0; i < tup.Len(); i++ {
			if isErrorType(tup.At(i).Type()) {
				return true
			}
		}
		return false
	}
	return isErrorType(t)
}

func isErrorType(t types.Type) bool {
	if t == nil {
		return false
	}
	if n, ok := t.(*types.Named); ok {
		obj := n.Obj()
		if obj != nil && obj.Name() == "error" && obj.Pkg() == nil {
			return true
		}
	}
	return t.String() == "error"
}

func (c *checker) isTypeAssert(e ast.Expr) bool {
	switch x := e.(type) {
	case *ast.TypeAssertExpr:
		return true
	case *ast.ParenExpr:
		return c.isTypeAssert(x.X)
	}
	return false
}

func (c *checker) isExcludedCall(e ast.Expr) bool {
	name := c.callName(e)
	if name == "" {
		return false
	}
	if c.excludes[name] {
		return true
	}
	pkg := strings.TrimSuffix(name, "."+baseName(name))
	if c.ignorePkgs[pkg] {
		return true
	}
	for _, r := range c.ignoreRules {
		if r.pkg != "" && r.pkg != pkg {
			continue
		}
		if r.re.MatchString(baseName(name)) || r.re.MatchString(name) {
			return true
		}
	}
	return false
}

func (c *checker) callName(e ast.Expr) string {
	call, ok := unparen(e).(*ast.CallExpr)
	if !ok {
		return ""
	}
	switch f := unparen(call.Fun).(type) {
	case *ast.Ident:
		if obj := c.info.Uses[f]; obj != nil {
			if fn, ok := obj.(*types.Func); ok {
				return funcFullName(fn)
			}
		}
		return f.Name
	case *ast.SelectorExpr:
		if sel := c.info.Selections[f]; sel != nil {
			if fn, ok := sel.Obj().(*types.Func); ok {
				return funcFullName(fn)
			}
		}
		if obj := c.info.Uses[f.Sel]; obj != nil {
			if fn, ok := obj.(*types.Func); ok {
				return funcFullName(fn)
			}
		}
		if id, ok := f.X.(*ast.Ident); ok {
			return id.Name + "." + f.Sel.Name
		}
	}
	return ""
}

func funcFullName(fn *types.Func) string {
	if fn == nil {
		return ""
	}
	if sig, ok := fn.Type().(*types.Signature); ok && sig.Recv() != nil {
		recv := sig.Recv().Type().String()
		return "(" + recv + ")." + fn.Name()
	}
	if fn.Pkg() != nil {
		return fn.Pkg().Path() + "." + fn.Name()
	}
	return fn.Name()
}

func baseName(s string) string {
	if i := strings.LastIndex(s, "."); i >= 0 {
		return s[i+1:]
	}
	return s
}

func unparen(e ast.Expr) ast.Expr {
	for {
		p, ok := e.(*ast.ParenExpr)
		if !ok {
			return e
		}
		e = p.X
	}
}

func (c *checker) newDiag(n ast.Node, fn string) diag {
	pos := c.fset.Position(n.Pos())
	path := pos.Filename
	text := c.lineText(path, pos.Line)
	if text == "" {
		text = nodeString(c.fset, n)
	}
	return diag{file: path, line: pos.Line, col: pos.Column, text: strings.TrimSpace(text), fn: fn}
}

func (c *checker) newCallDiag(e ast.Expr, fn string) diag {
	if call, ok := unparen(e).(*ast.CallExpr); ok && call.Lparen.IsValid() {
		pos := c.fset.Position(call.Lparen)
		path := pos.Filename
		text := c.lineText(path, pos.Line)
		if text == "" {
			text = nodeString(c.fset, e)
		}
		return diag{file: path, line: pos.Line, col: pos.Column, text: strings.TrimSpace(text), fn: fn}
	}
	return c.newDiag(e, fn)
}

func (c *checker) lineText(path string, line int) string {
	if _, ok := c.lines[path]; !ok {
		data, err := os.ReadFile(path)
		if err != nil {
			return ""
		}
		c.lines[path] = strings.Split(string(data), "\n")
	}
	arr := c.lines[path]
	if line <= 0 || line > len(arr) {
		return ""
	}
	return arr[line-1]
}

func nodeString(fset *token.FileSet, n any) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, fset, n)
	return b.String()
}

func addDefaultExcludes(m map[string]bool) {
	// Common errcheck defaults and functions documented or conventionally harmless.
	for _, s := range []string{
		"fmt.Print", "fmt.Printf", "fmt.Println", "fmt.Fprint", "fmt.Fprintf", "fmt.Fprintln", "fmt.Sprint", "fmt.Sprintf", "fmt.Sprintln",
		"bytes.(*Buffer).Write", "(*bytes.Buffer).Write", "(*bytes.Buffer).WriteString", "(*bytes.Buffer).WriteByte", "(*bytes.Buffer).WriteRune",
		"strings.(*Builder).Write", "(*strings.Builder).Write", "(*strings.Builder).WriteString", "(*strings.Builder).WriteByte", "(*strings.Builder).WriteRune",
		"hash.Hash.Write", "(hash.Hash).Write",
	} {
		m[s] = true
	}
}

func readExcludeFile(path string, m map[string]bool) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "//") {
			continue
		}
		m[line] = true
	}
	return sc.Err()
}

func parseIgnore(vals []string) ([]ignoreRule, error) {
	var out []ignoreRule
	for _, val := range vals {
		for _, part := range strings.Split(val, ",") {
			part = strings.TrimSpace(part)
			if part == "" {
				continue
			}
			pkg, pat := "", part
			if i := strings.Index(part, ":"); i >= 0 {
				pkg, pat = part[:i], part[i+1:]
			}
			re, err := regexp.Compile(pat)
			if err != nil {
				return nil, err
			}
			out = append(out, ignoreRule{pkg: pkg, re: re})
		}
	}
	return out, nil
}

func isGenerated(path string) bool {
	f, err := os.Open(path)
	if err != nil {
		return false
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for i := 0; i < 20 && sc.Scan(); i++ {
		s := sc.Text()
		if strings.Contains(s, "Code generated") && strings.Contains(s, "DO NOT EDIT") {
			return true
		}
	}
	return false
}
