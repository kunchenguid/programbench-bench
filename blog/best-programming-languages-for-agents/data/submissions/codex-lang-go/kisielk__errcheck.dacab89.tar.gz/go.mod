module pb/errcheck

go 1.21
