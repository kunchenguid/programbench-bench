package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
)

const version = "xcp 0.24.3"

type countFlag int

func (c *countFlag) String() string { return strconv.Itoa(int(*c)) }
func (c *countFlag) Set(string) error {
	*c = *c + 1
	return nil
}

type options struct {
	verbose      countFlag
	recursive    bool
	deref        bool
	workers      int
	blockSize    string
	noClobber    bool
	force        bool
	gitignore    bool
	glob         bool
	noProgress   bool
	noPerms      bool
	noTimestamps bool
	ownership    bool
	driver       string
	noTargetDir  bool
	targetDir    string
	fsync        bool
	reflink      string
	backup       string
}

type pathInfo struct {
	src string
	dst string
}

func main() {
	opts, paths, exit := parseArgs(os.Args[1:])
	if exit >= 0 {
		os.Exit(exit)
	}
	if err := run(opts, paths); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, []string, int) {
	opts := options{workers: 4, blockSize: "1MB", driver: "parfile", reflink: "auto", backup: "none"}
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.Var(&opts.verbose, "v", "")
	fs.Var(&opts.verbose, "verbose", "")
	fs.BoolVar(&opts.recursive, "r", false, "")
	fs.BoolVar(&opts.recursive, "recursive", false, "")
	fs.BoolVar(&opts.deref, "L", false, "")
	fs.BoolVar(&opts.deref, "dereference", false, "")
	fs.IntVar(&opts.workers, "w", 4, "")
	fs.IntVar(&opts.workers, "workers", 4, "")
	fs.StringVar(&opts.blockSize, "block-size", "1MB", "")
	fs.BoolVar(&opts.noClobber, "n", false, "")
	fs.BoolVar(&opts.noClobber, "no-clobber", false, "")
	fs.BoolVar(&opts.force, "f", false, "")
	fs.BoolVar(&opts.force, "force", false, "")
	fs.BoolVar(&opts.gitignore, "gitignore", false, "")
	fs.BoolVar(&opts.glob, "g", false, "")
	fs.BoolVar(&opts.glob, "glob", false, "")
	fs.BoolVar(&opts.noProgress, "no-progress", false, "")
	fs.BoolVar(&opts.noPerms, "no-perms", false, "")
	fs.BoolVar(&opts.noTimestamps, "no-timestamps", false, "")
	fs.BoolVar(&opts.ownership, "o", false, "")
	fs.BoolVar(&opts.ownership, "ownership", false, "")
	fs.StringVar(&opts.driver, "driver", "parfile", "")
	fs.BoolVar(&opts.noTargetDir, "T", false, "")
	fs.BoolVar(&opts.noTargetDir, "no-target-directory", false, "")
	fs.StringVar(&opts.targetDir, "target-directory", "", "")
	fs.BoolVar(&opts.fsync, "fsync", false, "")
	fs.StringVar(&opts.reflink, "reflink", "auto", "")
	fs.StringVar(&opts.backup, "backup", "none", "")
	fs.BoolFunc("h", "", func(string) error { fmt.Print(shortHelp()); os.Exit(0); return nil })
	fs.BoolFunc("help", "", func(string) error { fmt.Print(longHelp()); os.Exit(0); return nil })
	fs.BoolFunc("V", "", func(string) error { fmt.Println(version); os.Exit(0); return nil })
	fs.BoolFunc("version", "", func(string) error { fmt.Println(version); os.Exit(0); return nil })

	nargs := normalizeShortArgs(args)
	if err := fs.Parse(nargs); err != nil {
		printFlagError(nargs, err)
		return opts, nil, 2
	}
	if opts.workers <= 0 {
		opts.workers = runtime.NumCPU()
	}
	if opts.noClobber && opts.force {
		return opts, nil, fail("Invalid arguments: --force and --noclobber cannot be set at the same time.")
	}
	if msg, ok := validateValue(opts); !ok {
		fmt.Fprint(os.Stderr, msg)
		return opts, nil, 2
	}
	paths := fs.Args()
	if opts.glob {
		paths = expandGlobs(paths)
	}
	return opts, paths, -1
}

func fail(msg string) int {
	fmt.Fprintf(os.Stderr, "Error: %s\n", msg)
	return 1
}

func printFlagError(args []string, err error) {
	msg := err.Error()
	if strings.Contains(msg, "flag provided but not defined") {
		name := strings.TrimPrefix(strings.TrimPrefix(strings.TrimPrefix(msg, "flag provided but not defined: -"), "-"), "-")
		fmt.Fprintf(os.Stderr, "error: unexpected argument '--%s' found\n\n  tip: to pass '--%s' as a value, use '-- --%s'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n", name, name, name)
		return
	}
	fmt.Fprintf(os.Stderr, "error: %v\n\nFor more information, try '--help'.\n", err)
}

func normalizeShortArgs(args []string) []string {
	var out []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			out = append(out, args[i:]...)
			break
		}
		if strings.HasPrefix(a, "-") && !strings.HasPrefix(a, "--") && len(a) > 2 {
			body := a[1:]
			for j := 0; j < len(body); j++ {
				ch := body[j]
				if ch == 'w' {
					out = append(out, "-w")
					if j+1 < len(body) {
						out = append(out, body[j+1:])
					}
					break
				}
				out = append(out, "-"+string(ch))
			}
			continue
		}
		out = append(out, a)
	}
	return out
}

func validateValue(o options) (string, bool) {
	if _, err := parseSize(o.blockSize); err != nil {
		return fmt.Sprintf("error: invalid value '%s' for '--block-size <BLOCK_SIZE>': could not interpret string as byte size\n\nFor more information, try '--help'.\n", o.blockSize), false
	}
	if o.driver != "parfile" && o.driver != "parblock" && o.driver != "file-parallel" {
		return fmt.Sprintf("error: invalid value '%s' for '--driver <DRIVER>': Unknown driver: %s\n\nFor more information, try '--help'.\n", o.driver, o.driver), false
	}
	switch o.reflink {
	case "auto", "always", "never":
	default:
		return fmt.Sprintf("error: invalid value '%s' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': %s\n\nFor more information, try '--help'.\n", o.reflink, o.reflink), false
	}
	switch o.backup {
	case "none", "off", "numbered", "auto":
	default:
		return fmt.Sprintf("error: invalid value '%s' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': %s\n\nFor more information, try '--help'.\n", o.backup, o.backup), false
	}
	return "", true
}

func run(o options, paths []string) error {
	if o.targetDir != "" {
		if len(paths) == 0 {
			return errors.New("Invalid source: No source files found.")
		}
		st, err := os.Stat(o.targetDir)
		if err != nil || !st.IsDir() {
			return errors.New("Invalid destination: Destination is not a directory.")
		}
		for _, p := range paths {
			if err := copyPath(o, p, filepath.Join(o.targetDir, filepath.Base(p)), ""); err != nil {
				return err
			}
		}
		return nil
	}
	if len(paths) < 2 {
		return errors.New("Invalid source: No source files found.")
	}
	dstArg := paths[len(paths)-1]
	srcs := paths[:len(paths)-1]
	if len(srcs) > 1 {
		st, err := os.Stat(dstArg)
		if err != nil || !st.IsDir() {
			return errors.New("Invalid destination: Multiple sources and destination is not a directory.")
		}
		for _, src := range srcs {
			if err := copyPath(o, src, filepath.Join(dstArg, filepath.Base(src)), ""); err != nil {
				return err
			}
		}
		return nil
	}
	src := srcs[0]
	dst := dstArg
	if !o.noTargetDir {
		if st, err := os.Stat(dstArg); err == nil && st.IsDir() {
			dst = filepath.Join(dstArg, filepath.Base(src))
		}
	}
	return copyPath(o, src, dst, "")
}

func copyPath(o options, src, dst, ignoreRoot string) error {
	info, err := statSource(o, src)
	if err != nil {
		return err
	}
	if info.IsDir() {
		if !o.recursive {
			return errors.New("Invalid source: Source is directory and --recursive not specified.")
		}
		root := ignoreRoot
		if root == "" {
			root = src
		}
		return copyDir(o, src, dst, info, root)
	}
	mode := info.Mode()
	if mode&os.ModeSymlink != 0 && !o.deref {
		return copySymlink(o, src, dst)
	}
	if !mode.IsRegular() {
		return copySpecial(o, src, dst, info)
	}
	return copyFile(o, src, dst, info)
}

func statSource(o options, src string) (os.FileInfo, error) {
	if o.deref {
		return os.Stat(src)
	}
	return os.Lstat(src)
}

func copyDir(o options, src, dst string, info os.FileInfo, root string) error {
	if err := prepareDirDestination(o, dst); err != nil {
		return err
	}
	mode := info.Mode().Perm()
	if o.noPerms {
		mode = 0777
	}
	if err := os.MkdirAll(dst, mode); err != nil {
		return err
	}
	ignores := []string{}
	if o.gitignore {
		ignores = readGitignore(filepath.Join(root, ".gitignore"))
	}
	entries, err := os.ReadDir(src)
	if err != nil {
		return err
	}
	for _, ent := range entries {
		childSrc := filepath.Join(src, ent.Name())
		rel, _ := filepath.Rel(root, childSrc)
		if ignored(rel, ent.Name(), ignores) {
			continue
		}
		childDst := filepath.Join(dst, ent.Name())
		if err := copyPath(o, childSrc, childDst, root); err != nil {
			return err
		}
	}
	if !o.noPerms {
		_ = os.Chmod(dst, info.Mode().Perm())
	}
	if !o.noTimestamps {
		_ = os.Chtimes(dst, info.ModTime(), info.ModTime())
	}
	chownIfRequested(o, dst, info)
	return nil
}

func copyFile(o options, src, dst string, info os.FileInfo) error {
	if err := prepareFileDestination(o, dst); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	mode := info.Mode().Perm()
	if o.noPerms {
		mode = 0666
	}
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
	if err != nil {
		return err
	}
	_, cpErr := io.Copy(out, in)
	if o.fsync && cpErr == nil {
		cpErr = out.Sync()
	}
	closeErr := out.Close()
	if cpErr != nil {
		return cpErr
	}
	if closeErr != nil {
		return closeErr
	}
	if !o.noPerms {
		_ = os.Chmod(dst, info.Mode().Perm())
	}
	if !o.noTimestamps {
		_ = os.Chtimes(dst, info.ModTime(), info.ModTime())
	}
	chownIfRequested(o, dst, info)
	return nil
}

func copySymlink(o options, src, dst string) error {
	if err := prepareFileDestination(o, dst); err != nil {
		return err
	}
	target, err := os.Readlink(src)
	if err != nil {
		return err
	}
	return os.Symlink(target, dst)
}

func copySpecial(o options, src, dst string, info os.FileInfo) error {
	if info.Mode()&os.ModeNamedPipe != 0 {
		if err := prepareFileDestination(o, dst); err != nil {
			return err
		}
		return syscall.Mkfifo(dst, uint32(info.Mode().Perm()))
	}
	return copyFile(o, src, dst, info)
}

func prepareFileDestination(o options, dst string) error {
	if st, err := os.Lstat(dst); err == nil {
		if o.noClobber {
			return fmt.Errorf("Destination Exists: Destination file exists and --no-clobber is set., %s", dst)
		}
		if st.IsDir() {
			return syscall.EISDIR
		}
		if o.backup == "numbered" || (o.backup == "auto" && hasNumberedBackup(dst)) {
			if err := os.Rename(dst, nextBackup(dst)); err != nil {
				return err
			}
			return nil
		}
		if err := os.RemoveAll(dst); err != nil {
			return err
		}
	} else if !os.IsNotExist(err) {
		return err
	}
	parent := filepath.Dir(dst)
	if parent != "." && parent != "" {
		if _, err := os.Stat(parent); err != nil {
			return err
		}
	}
	return nil
}

func prepareDirDestination(o options, dst string) error {
	if st, err := os.Lstat(dst); err == nil {
		if st.IsDir() {
			if o.noClobber {
				return fmt.Errorf("Destination Exists: Destination file exists and --no-clobber is set., %s", dst)
			}
			return nil
		}
		if o.noClobber {
			return fmt.Errorf("Destination Exists: Destination file exists and --no-clobber is set., %s", dst)
		}
		if o.backup == "numbered" || (o.backup == "auto" && hasNumberedBackup(dst)) {
			if err := os.Rename(dst, nextBackup(dst)); err != nil {
				return err
			}
			return nil
		}
		if err := os.RemoveAll(dst); err != nil {
			return err
		}
	} else if !os.IsNotExist(err) {
		return err
	}
	parent := filepath.Dir(dst)
	if parent != "." && parent != "" {
		if _, err := os.Stat(parent); err != nil {
			return err
		}
	}
	return nil
}

func chownIfRequested(o options, path string, info os.FileInfo) {
	if !o.ownership {
		return
	}
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		if err := os.Chown(path, int(st.Uid), int(st.Gid)); err != nil && o.verbose > 0 {
			fmt.Fprintf(os.Stderr, "Warning: Could not copy ownership for %s: %v\n", path, err)
		}
	}
}

func expandGlobs(paths []string) []string {
	var out []string
	for _, p := range paths {
		matches, err := filepath.Glob(p)
		if err == nil && len(matches) > 0 {
			out = append(out, matches...)
		} else {
			out = append(out, p)
		}
	}
	return out
}

func readGitignore(path string) []string {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var patterns []string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
			continue
		}
		patterns = append(patterns, line)
	}
	return patterns
}

func ignored(rel, name string, patterns []string) bool {
	rel = filepath.ToSlash(rel)
	for _, pat := range patterns {
		dirOnly := strings.HasSuffix(pat, "/")
		pat = strings.TrimSuffix(pat, "/")
		pat = strings.TrimPrefix(pat, "/")
		if dirOnly && name == "" {
			continue
		}
		if ok, _ := filepath.Match(pat, rel); ok {
			return true
		}
		if ok, _ := filepath.Match(pat, name); ok {
			return true
		}
		if strings.HasSuffix(pat, "/"+name) || pat == name {
			return true
		}
	}
	return false
}

func hasNumberedBackup(path string) bool {
	dir, base := filepath.Dir(path), filepath.Base(path)
	matches, _ := filepath.Glob(filepath.Join(dir, base+".~*~"))
	return len(matches) > 0
}

func nextBackup(path string) string {
	dir, base := filepath.Dir(path), filepath.Base(path)
	n := 1
	matches, _ := filepath.Glob(filepath.Join(dir, base+".~*~"))
	for _, m := range matches {
		b := filepath.Base(m)
		s := strings.TrimSuffix(strings.TrimPrefix(b, base+".~"), "~")
		if i, err := strconv.Atoi(s); err == nil && i >= n {
			n = i + 1
		}
	}
	return filepath.Join(dir, fmt.Sprintf("%s.~%d~", base, n))
}

func parseSize(s string) (int64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, errors.New("empty")
	}
	i := 0
	for i < len(s) && ((s[i] >= '0' && s[i] <= '9') || s[i] == '.') {
		i++
	}
	num, err := strconv.ParseFloat(s[:i], 64)
	if err != nil {
		return 0, err
	}
	unit := strings.ToUpper(strings.TrimSpace(s[i:]))
	mul := float64(1)
	switch unit {
	case "", "B":
	case "K", "KB":
		mul = 1000
	case "M", "MB":
		mul = 1000 * 1000
	case "G", "GB":
		mul = 1000 * 1000 * 1000
	case "T", "TB":
		mul = 1000 * 1000 * 1000 * 1000
	case "KI", "KIB":
		mul = 1024
	case "MI", "MIB":
		mul = 1024 * 1024
	case "GI", "GIB":
		mul = 1024 * 1024 * 1024
	default:
		return 0, errors.New("bad unit")
	}
	return int64(num * mul), nil
}

func shortHelp() string {
	return `A (partial) clone of the Unix ` + "`cp`" + ` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`
}

func longHelp() string {
	return `A (partial) clone of the Unix ` + "`cp`" + ` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.
          
          Source and destination files, or multiple source(s) to a directory.

Options:
  -v, --verbose...
          Verbosity.
          
          Can be specified multiple times to increase logging.

  -r, --recursive
          Copy directories recursively

  -L, --dereference
          Dereference symlinks in source
          
          Follow symlinks, possibly recursively, when copying source files.

  -w, --workers <WORKERS>
          Number of parallel workers.
          
          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
          
          [default: 4]

      --block-size <BLOCK_SIZE>
          Block size for operations.
          
          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
          
          [default: 1MB]

  -n, --no-clobber
          Do not overwrite an existing file

  -f, --force
          Force (compatability only)
          
          Overwrite files; this is the default behaviour, this flag is for compatibility with ` + "`cp`" + ` only. See ` + "`--no-clobber`" + ` for the inverse flag. Using this in conjunction with ` + "`--no-clobber`" + ` will cause an error.

      --gitignore
          Use .gitignore if present.
          
          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

  -g, --glob
          Expand file patterns.
          
          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

      --no-progress
          Disable progress bar

      --no-perms
          Do not copy the file permissions

      --no-timestamps
          Do not copy the file timestamps

  -o, --ownership
          Copy ownership.

      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.
          
          [default: parfile]

  -T, --no-target-directory
          Target should not be a directory.

      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target

      --fsync
          Sync each file to disk after writing

      --reflink <REFLINK>
          Reflink options.
          
          [default: auto]

      --backup <BACKUP>
          Backup options
          
          [default: none]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`
}
