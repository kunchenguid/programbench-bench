module xcp-reimplementation

go 1.21
