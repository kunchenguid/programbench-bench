package main

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"strings"
	"unicode"
)

const helpText = `Shellharden: The corrective bash syntax highlighter.

Usage:
	shellharden [options] [files]
	cat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like ` + "`cat`" + `, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
	--suggest         Output a colored diff suggesting changes.
	--syntax          Output syntax highlighting with ANSI colors.
	--syntax-suggest  Diff with syntax highlighting (default mode).
	--transform       Output suggested changes.
	--check           No output; exit with 2 if changes are suggested.
	--replace         Replace file contents with suggested changes.
	--                Don't treat further arguments as options.
	-h|--help         Show help text.
	--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
`

type mode int

const (
	modeSyntaxSuggest mode = iota
	modeSuggest
	modeSyntax
	modeTransform
	modeCheck
	modeReplace
)

func main() {
	m := modeSyntaxSuggest
	var files []string
	options := true
	for _, a := range os.Args[1:] {
		if options && a == "--" {
			options = false
			continue
		}
		if options && strings.HasPrefix(a, "-") && a != "" {
			switch a {
			case "-h", "--help":
				fmt.Print(helpText)
				return
			case "--version":
				fmt.Println("4.3.1")
				return
			case "--suggest":
				m = modeSuggest
			case "--syntax":
				m = modeSyntax
			case "--syntax-suggest":
				m = modeSyntaxSuggest
			case "--transform":
				m = modeTransform
			case "--check":
				m = modeCheck
			case "--replace":
				m = modeReplace
			default:
				fmt.Fprintf(os.Stderr, "%s: No such option.\n", a)
				os.Exit(3)
			}
		} else {
			files = append(files, a)
		}
	}
	if len(files) == 0 {
		files = []string{""}
	}
	changedAny := false
	var out bytes.Buffer
	for _, f := range files {
		in, err := readInput(f)
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s: %v\n", f, err)
			os.Exit(1)
		}
		tr := transform(string(in))
		if tr != string(in) {
			changedAny = true
		}
		switch m {
		case modeCheck:
		case modeTransform:
			out.WriteString(tr)
		case modeReplace:
			if f == "" {
				fmt.Fprint(os.Stderr, "--replace: Cannot replace stdin.\n")
				os.Exit(1)
			}
			if err := os.WriteFile(f, []byte(tr), 0644); err != nil {
				fmt.Fprintf(os.Stderr, "%s: %v\n", f, err)
				os.Exit(1)
			}
		case modeSyntax:
			out.WriteString(colorSyntax(string(in)))
		case modeSuggest:
			out.WriteString(colorDiff(string(in), tr))
		case modeSyntaxSuggest:
			if string(in) == tr {
				out.WriteString(colorSyntax(string(in)))
			} else {
				out.WriteString(colorDiff(string(in), tr))
			}
		}
	}
	if m == modeCheck {
		if changedAny {
			os.Exit(2)
		}
		return
	}
	if _, err := io.Copy(os.Stdout, &out); err != nil {
		os.Exit(1)
	}
}

func readInput(name string) ([]byte, error) {
	if name == "" || name == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(name)
}

func colorSyntax(s string) string {
	var b strings.Builder
	for _, line := range strings.SplitAfter(s, "\n") {
		if line == "" {
			continue
		}
		i := 0
		for i < len(line) && (line[i] == ' ' || line[i] == '\t') {
			b.WriteByte(line[i])
			i++
		}
		j := i
		for j < len(line) && !isShellSpace(line[j]) && !strings.ContainsRune(";|&()<>", rune(line[j])) {
			j++
		}
		if j > i {
			b.WriteString("\x1b[0;38;2;192;0;128m")
			b.WriteString(line[i:j])
			b.WriteString("\x1b[m")
			b.WriteString(line[j:])
		} else {
			b.WriteString(line)
		}
	}
	return b.String()
}

func colorDiff(orig, tr string) string {
	if orig == tr {
		return orig
	}
	n, m := len(orig), len(tr)
	dp := make([][]int, n+1)
	for i := range dp {
		dp[i] = make([]int, m+1)
	}
	for i := n - 1; i >= 0; i-- {
		for j := m - 1; j >= 0; j-- {
			if orig[i] == tr[j] {
				dp[i][j] = dp[i+1][j+1] + 1
			} else if dp[i+1][j] >= dp[i][j+1] {
				dp[i][j] = dp[i+1][j]
			} else {
				dp[i][j] = dp[i][j+1]
			}
		}
	}
	var b strings.Builder
	i, j := 0, 0
	for i < n || j < m {
		if i < n && j < m && orig[i] == tr[j] {
			b.WriteByte(orig[i])
			i++
			j++
		} else if j < m && (i == n || dp[i][j+1] >= dp[i+1][j]) {
			b.WriteString("\x1b[0;42m")
			for j < m && (i == n || dp[i][j+1] >= dp[i+1][j]) && !(i < n && orig[i] == tr[j]) {
				b.WriteByte(tr[j])
				j++
			}
			b.WriteString("\x1b[m")
		} else if i < n {
			b.WriteString("\x1b[0;41m")
			for i < n && (j == m || dp[i][j+1] < dp[i+1][j]) && !(j < m && orig[i] == tr[j]) {
				b.WriteByte(orig[i])
				i++
			}
			b.WriteString("\x1b[m")
		}
	}
	return b.String()
}

type ctx struct {
	s          string
	i          int
	lineStart  bool
	cmdWord    bool
	inCaseHead bool
	inDblBr    bool
}

func transform(s string) string {
	c := &ctx{s: s, lineStart: true, cmdWord: true}
	var b strings.Builder
	for c.i < len(s) {
		ch := s[c.i]
		if ch == '\'' {
			b.WriteString(c.readSingle())
			continue
		}
		if ch == '"' {
			b.WriteString(c.readDouble())
			continue
		}
		if ch == '`' {
			b.WriteByte('"')
			b.WriteString(c.readBacktick())
			b.WriteByte('"')
			c.markWord()
			continue
		}
		if ch == '$' {
			if repl, ok := c.readDollar(false); ok {
				b.WriteString(repl)
				c.markWord()
				continue
			}
		}
		if ch == '#' && c.commentStart() {
			n := strings.IndexByte(s[c.i:], '\n')
			if n < 0 {
				b.WriteString(s[c.i:])
				c.i = len(s)
			} else {
				b.WriteString(s[c.i : c.i+n+1])
				c.i += n + 1
				c.lineStart = true
				c.cmdWord = true
			}
			continue
		}
		b.WriteByte(ch)
		c.advanceState(ch)
		c.i++
	}
	return b.String()
}

func (c *ctx) readSingle() string {
	start := c.i
	c.i++
	for c.i < len(c.s) {
		ch := c.s[c.i]
		c.i++
		if ch == '\'' {
			break
		}
	}
	c.markWord()
	return c.s[start:c.i]
}

func (c *ctx) readDouble() string {
	c.i++
	var b strings.Builder
	b.WriteByte('"')
	for c.i < len(c.s) {
		ch := c.s[c.i]
		if ch == '"' {
			b.WriteByte('"')
			c.i++
			c.markWord()
			return b.String()
		}
		if ch == '\\' && c.i+1 < len(c.s) {
			b.WriteByte(ch)
			c.i++
			b.WriteByte(c.s[c.i])
			c.i++
			continue
		}
		if ch == '`' {
			b.WriteString(c.readBacktick())
			continue
		}
		if ch == '$' {
			if repl, ok := c.readDollar(true); ok {
				b.WriteString(unquoteOuter(repl))
				continue
			}
		}
		b.WriteByte(ch)
		if ch == '\n' {
			c.lineStart = true
			c.cmdWord = true
		}
		c.i++
	}
	return b.String()
}

func (c *ctx) readBacktick() string {
	c.i++
	start := c.i
	for c.i < len(c.s) && c.s[c.i] != '`' {
		c.i++
	}
	inner := c.s[start:c.i]
	if c.i < len(c.s) {
		c.i++
	}
	return "$(" + inner + ")"
}

func (c *ctx) readDollar(inDouble bool) (string, bool) {
	if c.i+1 >= len(c.s) {
		return "", false
	}
	if c.s[c.i+1] == '(' {
		if c.i+2 < len(c.s) && c.s[c.i+2] == '(' {
			start := c.i
			c.i += 3
			for c.i+1 < len(c.s) && !(c.s[c.i] == ')' && c.s[c.i+1] == ')') {
				c.i++
			}
			if c.i+1 < len(c.s) {
				c.i += 2
			}
			return c.s[start:c.i], true
		}
		start := c.i
		c.i += 2
		depth := 1
		for c.i < len(c.s) && depth > 0 {
			switch c.s[c.i] {
			case '\'':
				c.readSingle()
				continue
			case '"':
				c.readDouble()
				continue
			case '(':
				depth++
			case ')':
				depth--
			}
			c.i++
		}
		expr := c.s[start:c.i]
		if inDouble || c.safeContext() {
			return expr, true
		}
		return `"` + expr + `"`, true
	}
	if c.s[c.i+1] == '{' {
		end := strings.IndexByte(c.s[c.i+2:], '}')
		if end < 0 {
			return "", false
		}
		raw := c.s[c.i : c.i+end+3]
		body := c.s[c.i+2 : c.i+end+2]
		c.i += end + 3
		if isSafeSpecialBody(body) || c.safeContext() {
			return raw, true
		}
		if strings.HasSuffix(body, "[*]") {
			body = strings.TrimSuffix(body, "[*]") + "[@]"
		}
		needBraces := c.i < len(c.s) && isIdent(c.s[c.i])
		if simpleIdent(body) && !needBraces {
			raw = "$" + body
		} else {
			raw = "${" + body + "}"
		}
		if inDouble {
			return raw, true
		}
		return `"` + raw + `"`, true
	}
	n := c.s[c.i+1]
	if strings.ContainsRune("?$!#", rune(n)) {
		c.i += 2
		return "$" + string(n), true
	}
	if n == '@' || n == '*' {
		c.i += 2
		if inDouble {
			return "$" + string(n), true
		}
		if n == '*' {
			n = '@'
		}
		return `"$` + string(n) + `"`, true
	}
	if n >= '0' && n <= '9' {
		c.i += 2
		if inDouble || c.safeContext() {
			return "$" + string(n), true
		}
		return `"$` + string(n) + `"`, true
	}
	if isIdentStart(n) {
		j := c.i + 2
		for j < len(c.s) && isIdent(c.s[j]) {
			j++
		}
		name := c.s[c.i+1 : j]
		c.i = j
		raw := "$" + name
		if inDouble || c.safeContext() {
			return raw, true
		}
		return `"` + raw + `"`, true
	}
	return "", false
}

func (c *ctx) safeContext() bool {
	if c.inDblBr || c.inCaseHead {
		return true
	}
	// Assignment words do not need quotes on the right hand side.
	j := c.i - 1
	for j >= 0 && c.s[j] != '\n' && !isShellSpace(c.s[j]) && !strings.ContainsRune(";|&()", rune(c.s[j])) {
		if c.s[j] == '=' {
			return true
		}
		j--
	}
	return false
}

func (c *ctx) advanceState(ch byte) {
	if ch == '\n' {
		c.lineStart = true
		c.cmdWord = true
		c.inDblBr = false
		c.inCaseHead = false
		return
	}
	if ch == ' ' || ch == '\t' || ch == '\r' {
		return
	}
	c.lineStart = false
	if strings.HasPrefix(c.s[c.i:], "[[") {
		c.inDblBr = true
	}
	if strings.HasPrefix(c.s[c.i:], "]]") {
		c.inDblBr = false
	}
	if strings.ContainsRune(";|&()", rune(ch)) {
		c.cmdWord = true
		c.inCaseHead = false
		return
	}
	if c.cmdWord {
		word := readWordAt(c.s, c.i)
		if word == "case" {
			c.inCaseHead = true
		}
		if word == "in" && c.inCaseHead {
			c.inCaseHead = false
		}
	}
	c.cmdWord = false
}

func (c *ctx) markWord() {
	c.lineStart = false
	c.cmdWord = false
}

func (c *ctx) commentStart() bool {
	if c.i == 0 {
		return true
	}
	p := c.s[c.i-1]
	return p == '\n' || p == ' ' || p == '\t' || strings.ContainsRune(";|&()", rune(p))
}

func readWordAt(s string, i int) string {
	j := i
	for j < len(s) && (unicode.IsLetter(rune(s[j])) || unicode.IsDigit(rune(s[j])) || s[j] == '_' || s[j] == '-') {
		j++
	}
	return s[i:j]
}

func unquoteOuter(s string) string {
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		return s[1 : len(s)-1]
	}
	return s
}

func isSafeSpecialBody(s string) bool {
	return strings.HasPrefix(s, "#") || s == "?" || s == "$" || s == "!" || s == "#"
}

func simpleIdent(s string) bool {
	if s == "" || !isIdentStart(s[0]) {
		return false
	}
	for i := 1; i < len(s); i++ {
		if !isIdent(s[i]) {
			return false
		}
	}
	return true
}

func isIdentStart(b byte) bool {
	return b == '_' || (b >= 'A' && b <= 'Z') || (b >= 'a' && b <= 'z')
}

func isIdent(b byte) bool {
	return isIdentStart(b) || (b >= '0' && b <= '9')
}

func isShellSpace(b byte) bool {
	return b == ' ' || b == '\t' || b == '\n' || b == '\r'
}
