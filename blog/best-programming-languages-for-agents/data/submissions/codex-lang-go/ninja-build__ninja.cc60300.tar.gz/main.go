package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "1.14.0.git"

type Rule struct {
	Name string
	Vars map[string]string
}

type Edge struct {
	Rule        *Rule
	RuleName    string
	ExplicitOut []string
	ImplicitOut []string
	Inputs      []string
	ImplicitIn  []string
	OrderOnly   []string
	Validations []string
	Vars        map[string]string
}

type State struct {
	Vars      map[string]string
	Rules     map[string]*Rule
	Edges     []*Edge
	ByOut     map[string]*Edge
	Defaults  []string
	BuildFile string
	Quiet     bool
	Verbose   bool
	DryRun    bool
	KeepGoing int
	Explain   bool
	failures  int
	started   int
	total     int
	visited   map[*Edge]bool
	built     map[*Edge]bool
	Log       map[string]string
	LogDirty  bool
}

func main() {
	st := &State{
		Vars:      map[string]string{},
		Rules:     map[string]*Rule{"phony": {Name: "phony", Vars: map[string]string{}}},
		ByOut:     map[string]*Edge{},
		BuildFile: "build.ninja",
		KeepGoing: 1,
		Log:       map[string]string{},
	}
	targets, tool, toolArgs, err := parseArgs(st, os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if tool == "__help" {
		printHelp()
		return
	}
	if tool == "__version" {
		fmt.Println(version)
		return
	}
	if err := parseFile(st, st.BuildFile, nil); err != nil {
		fmt.Fprintf(os.Stderr, "ninja: error: %v\n", err)
		os.Exit(1)
	}
	st.loadLog()
	if tool != "" {
		if runTool(st, tool, toolArgs) != nil {
			os.Exit(1)
		}
		return
	}
	if len(targets) == 0 {
		targets = st.Defaults
		if len(targets) == 0 {
			targets = rootTargets(st)
		}
	}
	if err := st.buildTargets(targets); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	st.saveLog()
}

func parseArgs(st *State, args []string) ([]string, string, []string, error) {
	targets := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-h" || a == "--help":
			return nil, "__help", nil, nil
		case a == "--version":
			return nil, "__version", nil, nil
		case a == "-v" || a == "--verbose":
			st.Verbose = true
		case a == "--quiet":
			st.Quiet = true
		case a == "-n" || a == "--dry-run":
			st.DryRun = true
		case a == "-C":
			i++
			if i >= len(args) {
				return nil, "", nil, errors.New("ninja: option requires an argument -- C")
			}
			fmt.Printf("ninja: Entering directory `%s'\n", args[i])
			if err := os.Chdir(args[i]); err != nil {
				return nil, "", nil, fmt.Errorf("ninja: fatal: chdir to '%s' - %v", args[i], err)
			}
		case strings.HasPrefix(a, "-C") && len(a) > 2:
			dir := a[2:]
			fmt.Printf("ninja: Entering directory `%s'\n", dir)
			if err := os.Chdir(dir); err != nil {
				return nil, "", nil, fmt.Errorf("ninja: fatal: chdir to '%s' - %v", dir, err)
			}
		case a == "-f":
			i++
			if i >= len(args) {
				return nil, "", nil, errors.New("ninja: option requires an argument -- f")
			}
			st.BuildFile = args[i]
		case strings.HasPrefix(a, "-f") && len(a) > 2:
			st.BuildFile = a[2:]
		case a == "-j" || a == "-k" || a == "-l" || a == "-d" || a == "-w":
			i++
			if i >= len(args) {
				return nil, "", nil, fmt.Errorf("ninja: option requires an argument -- %s", strings.TrimPrefix(a, "-"))
			}
			if a == "-k" {
				st.KeepGoing, _ = strconv.Atoi(args[i])
				if st.KeepGoing == 0 {
					st.KeepGoing = 1 << 30
				}
			}
			if a == "-d" && args[i] == "explain" {
				st.Explain = true
			}
			if a == "-d" && args[i] == "list" {
				printDebug()
				os.Exit(0)
			}
			if a == "-w" && args[i] == "list" {
				printWarn()
				os.Exit(0)
			}
		case strings.HasPrefix(a, "-j") || strings.HasPrefix(a, "-l"):
		case strings.HasPrefix(a, "-k") && len(a) > 2:
			st.KeepGoing, _ = strconv.Atoi(a[2:])
		case a == "-t":
			i++
			if i >= len(args) {
				return nil, "", nil, errors.New("ninja: option requires an argument -- t")
			}
			return targets, args[i], args[i+1:], nil
		case strings.HasPrefix(a, "-t") && len(a) > 2:
			return targets, a[2:], args[i+1:], nil
		default:
			if strings.HasPrefix(a, "-") {
				return nil, "", nil, fmt.Errorf("ninja: invalid option -- '%s'", a)
			}
			targets = append(targets, a)
		}
	}
	return targets, "", nil, nil
}

func printHelp() {
	fmt.Printf(`usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("%s")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)
`, version)
}

func printDebug() {
	fmt.Println(`debugging modes:
  stats        print operation counts/timing info
  explain      explain what caused a command to execute
  keepdepfile  don't delete depfiles after they're read by ninja
  keeprsp      don't delete @response files on success
multiple modes can be enabled via -d FOO -d BAR`)
}

func printWarn() {
	fmt.Println(`warning flags:
  phonycycle={err,warn}  phony build statement references itself`)
}

func parseFile(st *State, path string, parent map[string]string) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return fmt.Errorf("loading '%s': %v", path, err)
	}
	vars := cloneMap(parent)
	for k, v := range st.Vars {
		if _, ok := vars[k]; !ok {
			vars[k] = v
		}
	}
	dir := filepath.Dir(path)
	if dir == "." {
		dir = ""
	}
	lines := physicalLines(string(data))
	for i := 0; i < len(lines); i++ {
		line := stripComment(lines[i])
		if strings.TrimSpace(line) == "" {
			continue
		}
		if isIndented(line) {
			return fmt.Errorf("%s:%d: unexpected indent", path, i+1)
		}
		t := strings.TrimSpace(line)
		switch {
		case strings.HasPrefix(t, "rule "):
			name := strings.TrimSpace(t[5:])
			r := &Rule{Name: name, Vars: map[string]string{}}
			for i+1 < len(lines) && isIndented(lines[i+1]) {
				i++
				k, v, ok := parseAssign(strings.TrimSpace(stripComment(lines[i])))
				if ok {
					r.Vars[k] = strings.TrimLeft(v, " \t")
				}
			}
			st.Rules[name] = r
		case strings.HasPrefix(t, "build "):
			e, err := parseBuild(st, t[6:], vars)
			if err != nil {
				return fmt.Errorf("%s:%d: %v", path, i+1, err)
			}
			for i+1 < len(lines) && isIndented(lines[i+1]) {
				i++
				k, v, ok := parseAssign(strings.TrimSpace(stripComment(lines[i])))
				if ok {
					e.Vars[k] = expandValue(v, vars)
				}
			}
			st.Edges = append(st.Edges, e)
			for _, o := range append(append([]string{}, e.ExplicitOut...), e.ImplicitOut...) {
				st.ByOut[o] = e
			}
		case strings.HasPrefix(t, "default "):
			st.Defaults = append(st.Defaults, lexWords(t[8:], vars)...)
		case strings.HasPrefix(t, "include ") || strings.HasPrefix(t, "subninja "):
			fields := strings.Fields(t)
			if len(fields) >= 2 {
				p := expandValue(strings.Join(fields[1:], " "), vars)
				if !filepath.IsAbs(p) && dir != "" {
					p = filepath.Join(dir, p)
				}
				if strings.HasPrefix(t, "include ") {
					if err := parseFile(st, p, vars); err != nil {
						return err
					}
					for k, v := range st.Vars {
						vars[k] = v
					}
				} else {
					if err := parseFile(st, p, cloneMap(vars)); err != nil {
						return err
					}
				}
			}
		case strings.HasPrefix(t, "pool "):
			for i+1 < len(lines) && isIndented(lines[i+1]) {
				i++
			}
		default:
			if k, v, ok := parseAssign(t); ok {
				vars[k] = expandValue(v, vars)
				st.Vars[k] = vars[k]
			}
		}
	}
	return nil
}

func physicalLines(s string) []string {
	raw := strings.Split(strings.ReplaceAll(s, "\r\n", "\n"), "\n")
	out := []string{}
	for i := 0; i < len(raw); i++ {
		line := raw[i]
		for strings.HasSuffix(line, "$") && i+1 < len(raw) {
			line = strings.TrimSuffix(line, "$") + strings.TrimLeft(raw[i+1], " \t")
			i++
		}
		out = append(out, line)
	}
	return out
}

func stripComment(s string) string {
	esc := false
	for i, r := range s {
		if esc {
			esc = false
			continue
		}
		if r == '$' {
			esc = true
			continue
		}
		if r == '#' {
			return s[:i]
		}
	}
	return s
}

func isIndented(s string) bool {
	return strings.HasPrefix(s, " ") || strings.HasPrefix(s, "\t")
}

func parseAssign(s string) (string, string, bool) {
	idx := strings.Index(s, "=")
	if idx < 0 {
		return "", "", false
	}
	return strings.TrimSpace(s[:idx]), strings.TrimLeft(s[idx+1:], " \t"), true
}

func parseBuild(st *State, rest string, vars map[string]string) (*Edge, error) {
	colon := -1
	esc := false
	for i, r := range rest {
		if esc {
			esc = false
			continue
		}
		if r == '$' {
			esc = true
			continue
		}
		if r == ':' {
			colon = i
			break
		}
	}
	if colon < 0 {
		return nil, errors.New("expected ':' in build line")
	}
	outs := lexWords(rest[:colon], vars)
	right := lexWords(rest[colon+1:], vars)
	if len(right) == 0 {
		return nil, errors.New("expected rule name")
	}
	e := &Edge{RuleName: right[0], Rule: st.Rules[right[0]], Vars: map[string]string{}}
	if e.Rule == nil {
		return nil, fmt.Errorf("unknown build rule '%s'", right[0])
	}
	implicitOut := false
	for _, w := range outs {
		if w == "|" {
			implicitOut = true
			continue
		}
		if implicitOut {
			e.ImplicitOut = append(e.ImplicitOut, w)
		} else {
			e.ExplicitOut = append(e.ExplicitOut, w)
		}
	}
	mode := "in"
	for _, w := range right[1:] {
		switch w {
		case "|":
			mode = "implicit"
		case "||":
			mode = "order"
		case "|@":
			mode = "validation"
		default:
			switch mode {
			case "in":
				e.Inputs = append(e.Inputs, w)
			case "implicit":
				e.ImplicitIn = append(e.ImplicitIn, w)
			case "order":
				e.OrderOnly = append(e.OrderOnly, w)
			case "validation":
				e.Validations = append(e.Validations, w)
			}
		}
	}
	return e, nil
}

func lexWords(s string, vars map[string]string) []string {
	var words []string
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == ' ' || c == '\t' {
			if b.Len() > 0 {
				words = append(words, b.String())
				b.Reset()
			}
			continue
		}
		if c == '$' && i+1 < len(s) {
			i++
			n := s[i]
			switch n {
			case ' ', ':':
				b.WriteByte(n)
			case '$':
				b.WriteByte('$')
			case '^':
				b.WriteByte('\n')
			case '{':
				j := strings.IndexByte(s[i+1:], '}')
				if j >= 0 {
					name := s[i+1 : i+1+j]
					b.WriteString(vars[name])
					i += j + 1
				}
			default:
				if isNameChar(n) {
					start := i
					for i+1 < len(s) && isNameChar(s[i+1]) {
						i++
					}
					b.WriteString(vars[s[start:i+1]])
				} else {
					b.WriteByte(n)
				}
			}
		} else {
			b.WriteByte(c)
		}
	}
	if b.Len() > 0 {
		words = append(words, b.String())
	}
	return words
}

func expandValue(s string, vars map[string]string) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		if s[i] != '$' || i+1 >= len(s) {
			b.WriteByte(s[i])
			continue
		}
		i++
		switch s[i] {
		case '$':
			b.WriteByte('$')
		case ' ':
			b.WriteByte(' ')
		case ':':
			b.WriteByte(':')
		case '^':
			b.WriteByte('\n')
		case '{':
			j := strings.IndexByte(s[i+1:], '}')
			if j >= 0 {
				name := s[i+1 : i+1+j]
				b.WriteString(vars[name])
				i += j + 1
			}
		default:
			if isNameChar(s[i]) {
				start := i
				for i+1 < len(s) && isNameChar(s[i+1]) {
					i++
				}
				b.WriteString(vars[s[start:i+1]])
			} else {
				b.WriteByte(s[i])
			}
		}
	}
	return b.String()
}

func isNameChar(c byte) bool {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.'
}

func (st *State) buildTargets(targets []string) error {
	st.visited = map[*Edge]bool{}
	st.built = map[*Edge]bool{}
	needed := map[*Edge]bool{}
	for _, t := range targets {
		e := st.edgeForTarget(t)
		if e == nil {
			if _, err := os.Stat(t); err != nil {
				return fmt.Errorf("ninja: error: unknown target '%s'", t)
			}
			continue
		}
		markNeeded(st, e, needed)
	}
	for e := range needed {
		if dirty, _ := st.edgeDirty(e); dirty && e.RuleName != "phony" {
			st.total++
		}
	}
	for _, t := range targets {
		if err := st.buildTarget(t); err != nil {
			return err
		}
	}
	if st.started == 0 && !st.Quiet {
		fmt.Println("ninja: no work to do.")
	}
	return nil
}

func markNeeded(st *State, e *Edge, m map[*Edge]bool) {
	if m[e] {
		return
	}
	m[e] = true
	for _, in := range allDeps(e) {
		if de := st.ByOut[in]; de != nil {
			markNeeded(st, de, m)
		}
	}
	for _, v := range e.Validations {
		if de := st.ByOut[v]; de != nil {
			markNeeded(st, de, m)
		}
	}
}

func (st *State) edgeForTarget(t string) *Edge {
	if strings.HasSuffix(t, "^") {
		src := strings.TrimSuffix(t, "^")
		for _, e := range st.Edges {
			for _, in := range e.Inputs {
				if in == src && len(e.ExplicitOut) > 0 {
					return e
				}
			}
		}
	}
	return st.ByOut[t]
}

func (st *State) buildTarget(t string) error {
	e := st.edgeForTarget(t)
	if e == nil {
		if _, err := os.Stat(t); err != nil {
			return fmt.Errorf("ninja: error: '%s', missing and no known rule to make it", t)
		}
		return nil
	}
	return st.buildEdge(e)
}

func (st *State) buildEdge(e *Edge) error {
	if st.built[e] {
		return nil
	}
	if st.visited[e] {
		return nil
	}
	st.visited[e] = true
	for _, in := range allDeps(e) {
		if de := st.ByOut[in]; de != nil {
			if err := st.buildEdge(de); err != nil {
				return err
			}
		} else if !fileExists(in) && e.RuleName != "phony" {
			return fmt.Errorf("ninja: error: '%s', needed by '%s', missing and no known rule to make it", in, firstOut(e))
		}
	}
	for _, v := range e.Validations {
		if de := st.ByOut[v]; de != nil {
			if err := st.buildEdge(de); err != nil {
				return err
			}
		}
	}
	dirty, why := st.edgeDirty(e)
	if st.Explain && dirty && why != "" {
		fmt.Fprintf(os.Stderr, "ninja explain: %s\n", why)
	}
	if dirty && e.RuleName != "phony" {
		if err := st.runEdge(e); err != nil {
			st.failures++
			if st.failures >= st.KeepGoing {
				return errors.New("ninja: build stopped: subcommand failed.")
			}
		}
	}
	st.built[e] = true
	return nil
}

func (st *State) edgeDirty(e *Edge) (bool, string) {
	if e.RuleName == "phony" {
		for _, o := range append(append([]string{}, e.ExplicitOut...), e.ImplicitOut...) {
			if !fileExists(o) {
				return false, ""
			}
		}
		return false, ""
	}
	outs := append(append([]string{}, e.ExplicitOut...), e.ImplicitOut...)
	var oldest time.Time
	for _, o := range outs {
		info, err := os.Stat(o)
		if err != nil {
			return true, fmt.Sprintf("output %s doesn't exist", o)
		}
		if oldest.IsZero() || info.ModTime().Before(oldest) {
			oldest = info.ModTime()
		}
	}
	for _, in := range append(append([]string{}, e.Inputs...), e.ImplicitIn...) {
		if info, err := os.Stat(in); err == nil && info.ModTime().After(oldest) {
			return true, fmt.Sprintf("output %s older than input %s", firstOut(e), in)
		}
	}
	if old, ok := st.Log[firstOut(e)]; !ok || old != st.commandFor(e) {
		return true, fmt.Sprintf("command line changed for %s", firstOut(e))
	}
	return false, ""
}

func (st *State) runEdge(e *Edge) error {
	env := cloneMap(st.Vars)
	for k, v := range e.Vars {
		env[k] = v
	}
	env["in"] = joinShell(e.Inputs)
	env["in_newline"] = strings.Join(e.Inputs, "\n")
	env["out"] = joinShell(e.ExplicitOut)
	for k, v := range e.Rule.Vars {
		env[k] = expandValue(v, env)
	}
	cmdStr := env["command"]
	desc := expandValue(env["description"], env)
	if desc == "" || st.Verbose {
		desc = cmdStr
	}
	st.started++
	if !st.Quiet {
		fmt.Printf("[%d/%d] %s\n", st.started, max(st.total, st.started), desc)
	}
	for _, o := range append(append([]string{}, e.ExplicitOut...), e.ImplicitOut...) {
		if d := filepath.Dir(o); d != "." && d != "" {
			_ = os.MkdirAll(d, 0755)
		}
	}
	if rsp := env["rspfile"]; rsp != "" {
		_ = os.WriteFile(rsp, []byte(env["rspfile_content"]), 0644)
		defer os.Remove(rsp)
	}
	if st.DryRun {
		return nil
	}
	cmd := exec.Command("/bin/sh", "-c", cmdStr)
	var buf bytes.Buffer
	cmd.Stdout = &buf
	cmd.Stderr = &buf
	err := cmd.Run()
	if err != nil {
		code := 1
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		}
		fmt.Fprintf(os.Stderr, "FAILED: [code=%d] %s \n%s\n", code, strings.Join(e.ExplicitOut, " "), cmdStr)
		_, _ = io.Copy(os.Stderr, &buf)
		return err
	}
	if buf.Len() > 0 {
		_, _ = io.Copy(os.Stdout, &buf)
	}
	st.Log[firstOut(e)] = cmdStr
	st.LogDirty = true
	return nil
}

func runTool(st *State, tool string, args []string) error {
	switch tool {
	case "list":
		fmt.Println(`ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest`)
	case "rules":
		names := make([]string, 0, len(st.Rules))
		for n := range st.Rules {
			names = append(names, n)
		}
		sort.Strings(names)
		for _, n := range names {
			fmt.Println(n)
		}
	case "targets":
		return toolTargets(st, args)
	case "query":
		for _, a := range args {
			toolQuery(st, a)
		}
	case "commands":
		finalOnly := false
		var t []string
		for _, a := range args {
			if a == "-s" {
				finalOnly = true
			} else {
				t = append(t, a)
			}
		}
		if len(t) == 0 {
			t = st.Defaults
		}
		var cmds []string
		seen := map[*Edge]bool{}
		for _, target := range t {
			collectCommands(st, st.edgeForTarget(target), seen, &cmds)
		}
		if finalOnly && len(cmds) > 0 {
			cmds = cmds[len(cmds)-1:]
		}
		for _, c := range cmds {
			fmt.Println(c)
		}
	case "inputs", "multi-inputs":
		if len(args) == 0 {
			args = st.Defaults
		}
		for _, t := range args {
			seen := map[string]bool{}
			var ins []string
			collectInputs(st, st.edgeForTarget(t), seen, &ins)
			sort.Strings(ins)
			for _, in := range ins {
				if tool == "multi-inputs" {
					fmt.Printf("%s\t%s\n", t, in)
				} else {
					fmt.Println(in)
				}
			}
		}
	case "clean", "cleandead":
		count := 0
		for _, e := range st.Edges {
			if e.RuleName == "phony" {
				continue
			}
			for _, o := range append(append([]string{}, e.ExplicitOut...), e.ImplicitOut...) {
				if fileExists(o) {
					count++
					if st.Verbose || st.DryRun {
						fmt.Println("Remove", o)
					}
					if !st.DryRun {
						_ = os.Remove(o)
					}
				}
			}
		}
		fmt.Printf("Cleaning... %d files.\n", count)
	case "compdb":
		rules := map[string]bool{}
		expandRsp := false
		for _, a := range args {
			if a == "-x" {
				expandRsp = true
			} else {
				rules[a] = true
			}
		}
		_ = expandRsp
		emitCompDB(st, rules, nil)
	case "compdb-targets":
		emitCompDB(st, nil, args)
	case "graph":
		emitGraph(st, args)
	case "deps", "missingdeps", "recompact", "restat":
		// Best-effort no-op for metadata tools.
	default:
		fmt.Fprintf(os.Stderr, "ninja: fatal: unknown tool '%s'\n", tool)
		return errors.New("bad tool")
	}
	return nil
}

func toolTargets(st *State, args []string) error {
	if len(args) >= 2 && args[0] == "rule" {
		for _, e := range st.Edges {
			if e.RuleName == args[1] {
				for _, o := range e.ExplicitOut {
					fmt.Println(o)
				}
			}
		}
		return nil
	}
	if len(args) >= 1 && args[0] == "all" {
		for _, e := range st.Edges {
			for _, o := range append(append([]string{}, e.ExplicitOut...), e.ImplicitOut...) {
				fmt.Printf("%s: %s\n", o, e.RuleName)
			}
		}
		return nil
	}
	if len(args) == 0 || args[0] == "depth" {
		depth := 1
		if len(args) >= 2 {
			depth, _ = strconv.Atoi(args[1])
		}
		for _, t := range rootTargets(st) {
			printDepth(st, t, 0, depth)
		}
	}
	return nil
}

func printDepth(st *State, t string, level, maxDepth int) {
	if maxDepth != 0 && level >= maxDepth {
		return
	}
	fmt.Printf("%s%s\n", strings.Repeat("  ", level), t)
	if e := st.ByOut[t]; e != nil {
		for _, in := range allDeps(e) {
			printDepth(st, in, level+1, maxDepth)
		}
	}
}

func toolQuery(st *State, target string) {
	fmt.Printf("%s:\n", target)
	if e := st.ByOut[target]; e != nil {
		fmt.Printf("  input: %s\n", e.RuleName)
		for _, in := range e.Inputs {
			fmt.Printf("    %s\n", in)
		}
		if len(e.ImplicitIn) > 0 {
			fmt.Println("  implicit:")
			for _, in := range e.ImplicitIn {
				fmt.Printf("    %s\n", in)
			}
		}
		if len(e.OrderOnly) > 0 {
			fmt.Println("  order-only:")
			for _, in := range e.OrderOnly {
				fmt.Printf("    %s\n", in)
			}
		}
	}
	fmt.Println("  outputs:")
	for _, e := range st.Edges {
		for _, in := range allDeps(e) {
			if in == target {
				for _, o := range e.ExplicitOut {
					fmt.Printf("    %s\n", o)
				}
			}
		}
	}
}

func collectCommands(st *State, e *Edge, seen map[*Edge]bool, out *[]string) {
	if e == nil || seen[e] {
		return
	}
	seen[e] = true
	for _, in := range allDeps(e) {
		collectCommands(st, st.ByOut[in], seen, out)
	}
	if e.RuleName != "phony" {
		*out = append(*out, st.commandFor(e))
	}
}

func collectInputs(st *State, e *Edge, seen map[string]bool, out *[]string) {
	if e == nil {
		return
	}
	for _, in := range allDeps(e) {
		if de := st.ByOut[in]; de != nil {
			collectInputs(st, de, seen, out)
		} else if !seen[in] {
			seen[in] = true
			*out = append(*out, in)
		}
	}
}

func emitCompDB(st *State, rules map[string]bool, targets []string) {
	type entry struct {
		Directory string `json:"directory"`
		Command   string `json:"command"`
		File      string `json:"file"`
		Output    string `json:"output,omitempty"`
	}
	targetSet := map[*Edge]bool{}
	for _, t := range targets {
		collectEdges(st, st.edgeForTarget(t), targetSet)
	}
	wd, _ := os.Getwd()
	var entries []entry
	for _, e := range st.Edges {
		if e.RuleName == "phony" || (rules != nil && len(rules) > 0 && !rules[e.RuleName]) {
			continue
		}
		if len(targets) > 0 && !targetSet[e] {
			continue
		}
		file := ""
		if len(e.Inputs) > 0 {
			file = e.Inputs[0]
		}
		output := ""
		if len(e.ExplicitOut) > 0 {
			output = e.ExplicitOut[0]
		}
		entries = append(entries, entry{Directory: wd, Command: st.commandFor(e), File: file, Output: output})
	}
	b, _ := json.MarshalIndent(entries, "", "  ")
	fmt.Println(string(b))
}

func collectEdges(st *State, e *Edge, seen map[*Edge]bool) {
	if e == nil || seen[e] {
		return
	}
	seen[e] = true
	for _, in := range allDeps(e) {
		collectEdges(st, st.ByOut[in], seen)
	}
}

func emitGraph(st *State, args []string) {
	fmt.Println("digraph ninja {")
	for _, e := range st.Edges {
		for _, in := range allDeps(e) {
			for _, o := range e.ExplicitOut {
				fmt.Printf("  %q -> %q;\n", in, o)
			}
		}
	}
	fmt.Println("}")
}

func (st *State) commandFor(e *Edge) string {
	env := cloneMap(st.Vars)
	for k, v := range e.Vars {
		env[k] = v
	}
	env["in"] = joinShell(e.Inputs)
	env["in_newline"] = strings.Join(e.Inputs, "\n")
	env["out"] = joinShell(e.ExplicitOut)
	for k, v := range e.Rule.Vars {
		env[k] = expandValue(v, env)
	}
	return env["command"]
}

func rootTargets(st *State) []string {
	used := map[string]bool{}
	for _, e := range st.Edges {
		for _, in := range allDeps(e) {
			used[in] = true
		}
	}
	var roots []string
	for _, e := range st.Edges {
		for _, o := range e.ExplicitOut {
			if !used[o] {
				roots = append(roots, o)
			}
		}
	}
	return roots
}

func allDeps(e *Edge) []string {
	var r []string
	r = append(r, e.Inputs...)
	r = append(r, e.ImplicitIn...)
	r = append(r, e.OrderOnly...)
	return r
}

func firstOut(e *Edge) string {
	if len(e.ExplicitOut) > 0 {
		return e.ExplicitOut[0]
	}
	if len(e.ImplicitOut) > 0 {
		return e.ImplicitOut[0]
	}
	return ""
}

func fileExists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

func joinShell(paths []string) string {
	q := make([]string, len(paths))
	for i, p := range paths {
		q[i] = shellQuote(p)
	}
	return strings.Join(q, " ")
}

func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	ok := true
	for _, r := range s {
		if !((r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') ||
			r == '_' || r == '-' || r == '.' || r == '/' || r == '+') {
			ok = false
			break
		}
	}
	if ok {
		return s
	}
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func (st *State) loadLog() {
	data, err := os.ReadFile(".ninja_log")
	if err != nil {
		return
	}
	_ = json.Unmarshal(data, &st.Log)
	if st.Log == nil {
		st.Log = map[string]string{}
	}
}

func (st *State) saveLog() {
	if !st.LogDirty || st.DryRun {
		return
	}
	b, _ := json.Marshal(st.Log)
	_ = os.WriteFile(".ninja_log", b, 0644)
}

func cloneMap(m map[string]string) map[string]string {
	n := map[string]string{}
	for k, v := range m {
		n[k] = v
	}
	return n
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
