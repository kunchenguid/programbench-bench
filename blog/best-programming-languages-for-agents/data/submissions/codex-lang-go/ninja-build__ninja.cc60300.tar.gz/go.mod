module ninja_clone

go 1.21
