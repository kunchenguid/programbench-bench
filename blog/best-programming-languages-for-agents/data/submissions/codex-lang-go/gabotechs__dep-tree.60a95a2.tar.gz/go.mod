module depclone

go 1.21
