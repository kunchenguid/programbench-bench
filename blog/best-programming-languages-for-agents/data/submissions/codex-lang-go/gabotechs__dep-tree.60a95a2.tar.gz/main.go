package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

const banner = `
      ____         _ __       _
     |  _ \   ___ |  _ \    _| |_  _ __  ___   ___
     | | | | / _ \| |_) |  |_   _||  __|/ _ \ / _ \
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \__| |_|        | \__|_|   \___| \___|
`

type opts struct {
	config       string
	only         []string
	exclude      []string
	unwrap       bool
	overlapLeft  bool
	overlapRight bool
	jsonTree     bool
}

type graph struct {
	edges map[string][]string
	errs  map[string]string
}

type config struct {
	Only      []string
	Exclude   []string
	Entryp    []string
	AllowCirc bool
	Allow     map[string][]string
	Deny      map[string][]string
	Aliases   map[string][]string
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func run(args []string) error {
	o := opts{config: ".dep-tree.yml"}
	args = parseGlobal(args, &o)
	if len(args) == 0 {
		printRootHelp()
		return nil
	}
	cmd := args[0]
	args = args[1:]
	if cmd == "-h" || cmd == "--help" || cmd == "help" {
		printRootHelp()
		return nil
	}
	if cmd == "-v" || cmd == "--version" {
		fmt.Println("dep-tree version unknown")
		return nil
	}
	if len(args) > 0 && (args[0] == "-h" || args[0] == "--help") {
		printCmdHelp(cmd)
		return nil
	}
	switch cmd {
	case "config", "init":
		return writeConfig(o.config)
	case "tree":
		args = parseTreeFlags(args, &o)
		if len(args) < 1 {
			return errors.New("requires at least 1 arg(s), only received 0")
		}
		return doTree(args, o)
	case "explain":
		args = parseExplainFlags(args, &o)
		if o.overlapLeft && o.overlapRight {
			return errors.New("only one of --overlap-left (-l) or --overlap-right (-r) can be used at a time")
		}
		if len(args) != 2 {
			return fmt.Errorf("accepts 2 arg(s), received %d", len(args))
		}
		return doExplain(args[0], args[1], o)
	case "check":
		return doCheck(o)
	case "entropy":
		if len(args) == 0 {
			return errors.New("requires at least 1 arg(s), only received 0")
		}
		fmt.Println("Entropy rendering is not available in this build")
		return nil
	default:
		if fileExists(cmd) {
			return doTree([]string{cmd}, o)
		}
		return fmt.Errorf("%s does not match with any existing file", cmd)
	}
}

func parseGlobal(args []string, o *opts) []string {
	out := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-c", "--config":
			if i+1 < len(args) {
				o.config = args[i+1]
				i++
			}
		case "--only":
			if i+1 < len(args) {
				o.only = append(o.only, args[i+1])
				i++
			}
		case "--exclude":
			if i+1 < len(args) {
				o.exclude = append(o.exclude, args[i+1])
				i++
			}
		case "--unwrap-exports":
			o.unwrap = true
		case "--js-tsconfig-paths", "--js-workspaces":
		case "--python-exclude-conditional-imports":
		default:
			out = append(out, a)
		}
	}
	return out
}

func parseTreeFlags(args []string, o *opts) []string {
	out := []string{}
	for _, a := range args {
		if a == "--json" {
			o.jsonTree = true
		} else {
			out = append(out, a)
		}
	}
	return out
}

func parseExplainFlags(args []string, o *opts) []string {
	out := []string{}
	for _, a := range args {
		switch a {
		case "-l", "--overlap-left":
			o.overlapLeft = true
		case "-r", "--overlap-right":
			o.overlapRight = true
		default:
			out = append(out, a)
		}
	}
	return out
}

func printRootHelp() {
	fmt.Print(banner)
	fmt.Println(`
Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree

Use "dep-tree [command] --help" for more information about a command.`)
}

func printCmdHelp(cmd string) {
	switch cmd {
	case "tree":
		fmt.Println("Render the dependency tree starting from the provided entrypoint\n\nUsage:\n  dep-tree tree [flags]\n\nFlags:\n  -h, --help   help for tree\n      --json   render the dependency tree in a machine readable json format")
	case "explain":
		fmt.Println("Shows all the dependencies between two parts of the code\n\nUsage:\n  dep-tree explain [flags]\n\nFlags:\n  -h, --help            help for explain\n  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left\n  -r, --overlap-right   When there's an overlap between the files at the right")
	case "check":
		fmt.Println("Checks that the dependency rules defined in the configuration file are not broken\n\nUsage:\n  dep-tree check [flags]\n\nFlags:\n  -h, --help   help for check")
	case "config", "init":
		fmt.Println("Generates a sample config in case that there's not already one present\n\nUsage:\n  dep-tree config [flags]\n\nAliases:\n  config, init\n\nFlags:\n  -h, --help   help for config")
	case "entropy":
		fmt.Println("(default) Renders a 3d force-directed graph in the browser\n\nUsage:\n  dep-tree entropy [flags]\n\nFlags:\n      --enable-gui           Enables a GUI for changing rendering settings\n  -h, --help                 help for entropy\n      --no-browser-open      Disable the automatic browser open while rendering entropy\n      --render-path string   Sets the output path of the rendered html file")
	default:
		printRootHelp()
	}
}

func doTree(entries []string, o opts) error {
	for _, e := range entries {
		if !fileExists(e) {
			return fmt.Errorf("%s does not match with any existing file", e)
		}
	}
	g := buildGraph(entries, o)
	tree := map[string]interface{}{}
	for _, e := range entries {
		tree[clean(e)] = buildNode(clean(e), g, map[string]bool{})
	}
	if o.jsonTree {
		cycles := findCycles(g)
		if cycles == nil {
			cycles = [][]string{}
		}
		res := map[string]interface{}{"tree": tree, "circularDependencies": cycles, "errors": map[string]string{}}
		b, _ := json.MarshalIndent(res, "", "  ")
		fmt.Println(string(b))
		return nil
	}
	printTree(tree, "")
	return nil
}

func buildNode(n string, g graph, seen map[string]bool) interface{} {
	if seen[n] || len(g.edges[n]) == 0 {
		return nil
	}
	seen[n] = true
	m := map[string]interface{}{}
	for _, d := range g.edges[n] {
		m[d] = buildNode(d, g, cloneSeen(seen))
	}
	return m
}

func cloneSeen(in map[string]bool) map[string]bool {
	out := map[string]bool{}
	for k, v := range in {
		out[k] = v
	}
	return out
}

func doExplain(leftPat, rightPat string, o opts) error {
	left := matchFiles(leftPat)
	right := matchFiles(rightPat)
	if o.overlapLeft || o.overlapRight {
		ls, rs := set(left), set(right)
		if o.overlapLeft {
			right = diff(right, ls)
		} else {
			left = diff(left, rs)
		}
	}
	all := append([]string{}, left...)
	g := buildGraph(all, o)
	rs := set(right)
	var lines []string
	for _, l := range left {
		for _, d := range reachableDirect(clean(l), g) {
			if rs[d] {
				lines = append(lines, fmt.Sprintf("%s -> %s", clean(l), d))
			}
		}
	}
	sort.Strings(lines)
	for _, l := range lines {
		fmt.Println(l)
	}
	return nil
}

func doCheck(o opts) error {
	cfg, err := readConfig(o.config)
	if err != nil {
		return err
	}
	base := filepath.Dir(o.config)
	if base == "." {
		base = ""
	}
	if len(cfg.Entryp) == 0 {
		return nil
	}
	var entries []string
	for _, e := range cfg.Entryp {
		p := clean(filepath.Join(base, e))
		if !fileExists(p) {
			return fmt.Errorf("open %s: no such file or directory", absForErr(p))
		}
		entries = append(entries, p)
	}
	o.only = append(o.only, cfg.Only...)
	o.exclude = append(o.exclude, cfg.Exclude...)
	g := buildGraph(entries, o)
	var violations []string
	for from, deps := range g.edges {
		for _, to := range deps {
			relFrom, relTo := stripBase(from, base), stripBase(to, base)
			for pat, allowed := range cfg.Allow {
				if globMatch(pat, relFrom) {
					ok := false
					for _, ap := range expandAliases(allowed, cfg.Aliases) {
						if globMatch(ap, relTo) {
							ok = true
						}
					}
					if !ok {
						violations = append(violations, fmt.Sprintf("%s -> %s breaks allow rule %s", relFrom, relTo, pat))
					}
				}
			}
			for pat, denied := range cfg.Deny {
				if globMatch(pat, relFrom) {
					for _, dp := range expandAliases(denied, cfg.Aliases) {
						if globMatch(dp, relTo) {
							violations = append(violations, fmt.Sprintf("%s -> %s breaks deny rule %s", relFrom, relTo, pat))
						}
					}
				}
			}
		}
	}
	if !cfg.AllowCirc {
		for _, c := range findCycles(g) {
			violations = append(violations, "circular dependency: "+strings.Join(c, " -> "))
		}
	}
	if len(violations) > 0 {
		sort.Strings(violations)
		return errors.New(strings.Join(violations, "\n"))
	}
	return nil
}

func buildGraph(entries []string, o opts) graph {
	g := graph{edges: map[string][]string{}, errs: map[string]string{}}
	var visit func(string)
	seen := map[string]bool{}
	visit = func(p string) {
		p = clean(p)
		if seen[p] || !allowedByFilters(p, o) {
			return
		}
		seen[p] = true
		deps := parseDeps(p)
		for _, d := range deps {
			if allowedByFilters(d, o) {
				g.edges[p] = appendUnique(g.edges[p], d)
				visit(d)
			}
		}
		sort.Strings(g.edges[p])
	}
	for _, e := range entries {
		visit(e)
	}
	return g
}

func parseDeps(path string) []string {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	s := string(data)
	ext := filepath.Ext(path)
	switch ext {
	case ".py":
		return parsePython(path, s)
	case ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs":
		return parseJS(path, s)
	case ".go":
		return parseGo(path, s)
	case ".rs":
		return parseRust(path, s)
	}
	return nil
}

func parsePython(path, s string) []string {
	var deps []string
	dir := filepath.Dir(path)
	reImport := regexp.MustCompile(`(?m)^\s*import\s+([A-Za-z_][\w.]*)`)
	reFrom := regexp.MustCompile(`(?m)^\s*from\s+([.]?[A-Za-z_][\w.]*)\s+import\s+([A-Za-z_*][\w*]*)`)
	for _, m := range reImport.FindAllStringSubmatch(s, -1) {
		if p := resolvePy(dir, m[1]); p != "" {
			deps = appendUnique(deps, p)
		}
	}
	for _, m := range reFrom.FindAllStringSubmatch(s, -1) {
		mod := strings.TrimLeft(m[1], ".")
		cand := mod
		if m[2] != "*" {
			cand = mod + "." + m[2]
		}
		if p := resolvePy(dir, cand); p != "" {
			deps = appendUnique(deps, p)
		} else if p := resolvePy(dir, mod); p != "" {
			deps = appendUnique(deps, p)
		}
	}
	sort.Strings(deps)
	return deps
}

func resolvePy(dir, mod string) string {
	rel := strings.ReplaceAll(mod, ".", string(filepath.Separator))
	cands := []string{filepath.Join(dir, rel+".py"), filepath.Join(dir, rel, "__init__.py"), rel + ".py", filepath.Join(rel, "__init__.py")}
	root := packageRoot(dir)
	cands = append(cands, filepath.Join(root, rel+".py"), filepath.Join(root, rel, "__init__.py"))
	for cur := dir; cur != "." && cur != "/"; cur = filepath.Dir(cur) {
		cands = append(cands, filepath.Join(cur, rel+".py"), filepath.Join(cur, rel, "__init__.py"))
		next := filepath.Dir(cur)
		if next == cur {
			break
		}
	}
	for _, c := range cands {
		if fileExists(c) {
			return clean(c)
		}
	}
	suffix := clean(rel + ".py")
	var found string
	filepath.WalkDir(".", func(p string, d fs.DirEntry, err error) error {
		if err == nil && !d.IsDir() && clean(p) == suffix || (err == nil && !d.IsDir() && strings.HasSuffix(clean(p), "/"+suffix)) {
			found = clean(p)
			return filepath.SkipAll
		}
		return nil
	})
	return found
}

func packageRoot(dir string) string {
	cur := dir
	for {
		if fileExists(filepath.Join(cur, "__init__.py")) {
			parent := filepath.Dir(cur)
			if parent == cur {
				return cur
			}
			cur = parent
			continue
		}
		return cur
	}
}

func parseJS(path, s string) []string {
	var deps []string
	dir := filepath.Dir(path)
	res := []*regexp.Regexp{
		regexp.MustCompile(`(?m)\bimport\s+(?:[^'"]*\s+from\s+)?['"]([^'"]+)['"]`),
		regexp.MustCompile(`(?m)\bexport\s+[^'"]*\s+from\s+['"]([^'"]+)['"]`),
		regexp.MustCompile(`(?m)\brequire\(\s*['"]([^'"]+)['"]\s*\)`),
	}
	for _, re := range res {
		for _, m := range re.FindAllStringSubmatch(s, -1) {
			if p := resolveJS(dir, m[1]); p != "" {
				deps = appendUnique(deps, p)
			}
		}
	}
	sort.Strings(deps)
	return deps
}

func resolveJS(dir, imp string) string {
	if !strings.HasPrefix(imp, ".") {
		return ""
	}
	base := filepath.Clean(filepath.Join(dir, imp))
	for _, c := range []string{base, base + ".ts", base + ".tsx", base + ".js", base + ".jsx", filepath.Join(base, "index.ts"), filepath.Join(base, "index.tsx"), filepath.Join(base, "index.js"), filepath.Join(base, "index.jsx")} {
		if fileExists(c) {
			return clean(c)
		}
	}
	return ""
}

func parseGo(path, s string) []string {
	var deps []string
	dir := filepath.Dir(path)
	mod := goModuleFor(path)
	re := regexp.MustCompile(`(?m)^\s*(?:import\s+)?(?:"([^"]+)"|[.\w]+\s+"([^"]+)")`)
	for _, m := range re.FindAllStringSubmatch(s, -1) {
		imp := m[1]
		if imp == "" {
			imp = m[2]
		}
		if p := resolveGo(dir, mod, imp); p != "" {
			deps = appendUnique(deps, p)
		}
	}
	sort.Strings(deps)
	return deps
}

func goModuleFor(path string) string {
	cur := filepath.Dir(path)
	for {
		gm := filepath.Join(cur, "go.mod")
		if b, err := os.ReadFile(gm); err == nil {
			sc := bufio.NewScanner(strings.NewReader(string(b)))
			for sc.Scan() {
				f := strings.Fields(sc.Text())
				if len(f) >= 2 && f[0] == "module" {
					return f[1] + "|" + cur
				}
			}
		}
		p := filepath.Dir(cur)
		if p == cur {
			return ""
		}
		cur = p
	}
}

func resolveGo(dir, mod, imp string) string {
	var pkgDir string
	if strings.HasPrefix(imp, ".") {
		pkgDir = filepath.Clean(filepath.Join(dir, imp))
	} else if mod != "" {
		parts := strings.SplitN(mod, "|", 2)
		if strings.HasPrefix(imp, parts[0]+"/") {
			pkgDir = filepath.Join(parts[1], strings.TrimPrefix(imp, parts[0]+"/"))
		}
	}
	if pkgDir == "" {
		return ""
	}
	files, _ := filepath.Glob(filepath.Join(pkgDir, "*.go"))
	for _, f := range files {
		if !strings.HasSuffix(f, "_test.go") {
			return clean(f)
		}
	}
	return ""
}

func parseRust(path, s string) []string {
	var deps []string
	dir := filepath.Dir(path)
	re := regexp.MustCompile(`(?m)^\s*(?:pub\s+)?mod\s+([A-Za-z_][\w]*)\s*;`)
	for _, m := range re.FindAllStringSubmatch(s, -1) {
		for _, c := range []string{filepath.Join(dir, m[1]+".rs"), filepath.Join(dir, m[1], "mod.rs")} {
			if fileExists(c) {
				deps = appendUnique(deps, clean(c))
				break
			}
		}
	}
	sort.Strings(deps)
	return deps
}

func matchFiles(pattern string) []string {
	var out []string
	filepath.WalkDir(".", func(p string, d fs.DirEntry, err error) error {
		if err == nil && !d.IsDir() && globMatch(pattern, clean(p)) {
			out = append(out, clean(p))
		}
		return nil
	})
	sort.Strings(out)
	return out
}

func globMatch(pattern, name string) bool {
	pattern, name = clean(pattern), clean(name)
	if strings.Contains(pattern, "**/") {
		if globMatch(strings.ReplaceAll(pattern, "**/", ""), name) {
			return true
		}
	}
	re := regexp.QuoteMeta(pattern)
	re = strings.ReplaceAll(re, `\*\*`, `.*`)
	re = strings.ReplaceAll(re, `\*`, `[^/]*`)
	re = strings.ReplaceAll(re, `\?`, `.`)
	ok, _ := regexp.MatchString("^"+re+"$", name)
	if ok {
		return true
	}
	if strings.HasSuffix(pattern, "/**") {
		p := strings.TrimSuffix(pattern, "/**")
		return name == p || strings.HasPrefix(name, p+"/")
	}
	return false
}

func allowedByFilters(p string, o opts) bool {
	for _, ex := range o.exclude {
		if globMatch(ex, p) {
			return false
		}
	}
	if len(o.only) == 0 {
		return true
	}
	for _, on := range o.only {
		if globMatch(on, p) {
			return true
		}
	}
	return false
}

func readConfig(path string) (config, error) {
	var c config
	c.Allow, c.Deny, c.Aliases = map[string][]string{}, map[string][]string{}, map[string][]string{}
	b, err := os.ReadFile(path)
	if err != nil {
		return c, err
	}
	lines := strings.Split(string(b), "\n")
	section, sub, key := "", "", ""
	for i := 0; i < len(lines); i++ {
		raw := strings.Split(lines[i], "#")[0]
		if strings.TrimSpace(raw) == "" {
			continue
		}
		indent := len(raw) - len(strings.TrimLeft(raw, " "))
		t := strings.TrimSpace(raw)
		t = strings.Trim(t, "\"'")
		if indent == 0 {
			key = ""
			if strings.HasSuffix(t, ":") {
				section = strings.TrimSuffix(t, ":")
			}
			continue
		}
		if section == "only" && strings.HasPrefix(t, "- ") {
			c.Only = append(c.Only, unq(strings.TrimPrefix(t, "- ")))
		}
		if section == "exclude" && strings.HasPrefix(t, "- ") {
			c.Exclude = append(c.Exclude, unq(strings.TrimPrefix(t, "- ")))
		}
		if section != "check" {
			continue
		}
		if indent == 2 {
			if strings.HasPrefix(t, "allowCircularDependencies:") {
				c.AllowCirc = strings.Contains(t, "true")
			} else if strings.HasSuffix(t, ":") {
				sub = strings.TrimSuffix(t, ":")
				key = ""
			}
		} else if indent == 4 {
			if sub == "entrypoints" && strings.HasPrefix(t, "- ") {
				c.Entryp = append(c.Entryp, unq(strings.TrimPrefix(t, "- ")))
			} else if strings.HasSuffix(t, ":") {
				key = unq(strings.TrimSuffix(t, ":"))
			}
		} else if indent >= 6 && strings.HasPrefix(t, "- ") && key != "" {
			val := unq(strings.TrimPrefix(t, "- "))
			if strings.HasPrefix(val, "to:") {
				val = unq(strings.TrimSpace(strings.TrimPrefix(val, "to:")))
			}
			switch sub {
			case "allow":
				c.Allow[key] = append(c.Allow[key], val)
			case "deny":
				c.Deny[key] = append(c.Deny[key], val)
			case "aliases":
				c.Aliases[key] = append(c.Aliases[key], val)
			}
		} else if indent >= 6 && strings.HasPrefix(t, "to:") && key != "" {
			val := unq(strings.TrimSpace(strings.TrimPrefix(t, "to:")))
			if sub == "allow" {
				// next indented list contains actual values
			} else if sub == "deny" {
				c.Deny[key] = append(c.Deny[key], val)
			}
		}
	}
	return c, nil
}

func writeConfig(path string) error {
	if fileExists(path) {
		return fmt.Errorf("cannot generate config file, as one already exists in %s", path)
	}
	return os.WriteFile(path, []byte(sampleConfig), 0600)
}

const sampleConfig = `# Files that should be completely ignored by dep-tree. It's fine to ignore
# some big files that everyone depends on and that don't add
# value to the visualization, like auto generated code.
exclude:
  - 'some-glob-pattern/**/*.ts'

# The only files that will be included by dep-tree. If a file does not
# match any of the provided patters, it is ignored.
only:
  - 'some-glob-pattern/**/*.ts'

unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'
      - 'src/generated/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
  # None available at the moment.
`

func findCycles(g graph) [][]string {
	var cycles [][]string
	var dfs func(string, []string, map[string]bool)
	dfs = func(n string, stack []string, seen map[string]bool) {
		for i, s := range stack {
			if s == n {
				cycles = append(cycles, append([]string{}, stack[i:]...))
				return
			}
		}
		if seen[n] {
			return
		}
		seen[n] = true
		for _, d := range g.edges[n] {
			dfs(d, append(stack, n), seen)
		}
	}
	for n := range g.edges {
		dfs(n, nil, map[string]bool{})
	}
	return cycles
}

func printTree(m map[string]interface{}, indent string) {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Println(indent + k)
		if child, ok := m[k].(map[string]interface{}); ok {
			printTree(child, indent+"  ")
		}
	}
}

func clean(p string) string {
	p = filepath.ToSlash(filepath.Clean(p))
	p = strings.TrimPrefix(p, "./")
	return p
}

func fileExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

func appendUnique(s []string, v string) []string {
	for _, x := range s {
		if x == v {
			return s
		}
	}
	return append(s, v)
}

func set(s []string) map[string]bool {
	m := map[string]bool{}
	for _, v := range s {
		m[clean(v)] = true
	}
	return m
}

func diff(s []string, rem map[string]bool) []string {
	var out []string
	for _, v := range s {
		if !rem[clean(v)] {
			out = append(out, v)
		}
	}
	return out
}

func reachableDirect(p string, g graph) []string { return g.edges[p] }

func expandAliases(vals []string, aliases map[string][]string) []string {
	var out []string
	for _, v := range vals {
		if a, ok := aliases[v]; ok {
			out = append(out, a...)
		} else {
			out = append(out, v)
		}
	}
	return out
}

func stripBase(p, base string) string {
	if base == "" || base == "." {
		return p
	}
	return strings.TrimPrefix(strings.TrimPrefix(p, clean(base)), "/")
}

func absForErr(p string) string {
	if filepath.IsAbs(p) {
		return p
	}
	wd, _ := os.Getwd()
	return filepath.Join(wd, p)
}

func unq(s string) string {
	s = strings.TrimSpace(s)
	s = strings.TrimSuffix(s, ":")
	return strings.Trim(s, "\"'")
}
