package main

import (
	"bufio"
	"fmt"
	"html"
	"io"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

const version = "8.6.0-dev"

type Kind int

const (
	Nil Kind = iota
	Int
	Float
	Bool
	Str
	Array
)

type Val struct {
	K Kind
	I int64
	F float64
	B bool
	S string
	A []Val
}

func VNil() Val            { return Val{K: Nil} }
func VInt(i int64) Val     { return Val{K: Int, I: i} }
func VFloat(f float64) Val { return Val{K: Float, F: f} }
func VBool(b bool) Val     { return Val{K: Bool, B: b} }
func VStr(s string) Val    { return Val{K: Str, S: s} }
func VArray(a []Val) Val   { return Val{K: Array, A: a} }
func (v Val) truth() bool {
	switch v.K {
	case Nil:
		return false
	case Bool:
		return v.B
	case Int:
		return v.I != 0
	case Float:
		return v.F != 0
	case Str:
		return v.S != "" && v.S != "0"
	case Array:
		return len(v.A) != 0
	}
	return false
}
func (v Val) num() float64 {
	switch v.K {
	case Int:
		return float64(v.I)
	case Float:
		return v.F
	case Bool:
		if v.B {
			return 1
		}
		return 0
	case Str:
		f, _ := strconv.ParseFloat(strings.TrimSpace(v.S), 64)
		return f
	}
	return 0
}
func (v Val) intval() int64 {
	switch v.K {
	case Int:
		return v.I
	case Float:
		return int64(v.F)
	case Bool:
		if v.B {
			return 1
		}
		return 0
	case Str:
		i, _ := strconv.ParseInt(strings.TrimSpace(v.S), 10, 64)
		return i
	}
	return 0
}
func (v Val) out() string {
	switch v.K {
	case Nil:
		return ""
	case Bool:
		if v.B {
			return "1"
		}
		return ""
	case Int:
		return strconv.FormatInt(v.I, 10)
	case Float:
		return strconv.FormatFloat(v.F, 'g', -1, 64)
	case Str:
		return v.S
	case Array:
		return "Array"
	}
	return ""
}

type tok struct {
	typ, lit string
	line     int
}

var keywords = map[string]bool{"if": true, "else": true, "elseif": true, "while": true, "for": true, "foreach": true, "as": true, "function": true, "return": true, "echo": true, "print": true, "true": true, "false": true, "null": true, "array": true, "and": true, "or": true, "xor": true}

func lex(src string) []tok {
	var ts []tok
	line := 1
	for i := 0; i < len(src); {
		c := src[i]
		if c == '\n' {
			line++
			i++
			continue
		}
		if c == ' ' || c == '\t' || c == '\r' {
			i++
			continue
		}
		if c == '/' && i+1 < len(src) && src[i+1] == '/' {
			for i < len(src) && src[i] != '\n' {
				i++
			}
			continue
		}
		if c == '#' {
			for i < len(src) && src[i] != '\n' {
				i++
			}
			continue
		}
		if c == '/' && i+1 < len(src) && src[i+1] == '*' {
			i += 2
			for i+1 < len(src) && !(src[i] == '*' && src[i+1] == '/') {
				if src[i] == '\n' {
					line++
				}
				i++
			}
			if i+1 < len(src) {
				i += 2
			}
			continue
		}
		if c == '$' {
			j := i + 1
			for j < len(src) && (isAlnum(src[j]) || src[j] == '_') {
				j++
			}
			ts = append(ts, tok{"var", src[i+1 : j], line})
			i = j
			continue
		}
		if isAlpha(c) || c == '_' {
			j := i + 1
			for j < len(src) && (isAlnum(src[j]) || src[j] == '_') {
				j++
			}
			l := src[i:j]
			lo := strings.ToLower(l)
			if keywords[lo] {
				ts = append(ts, tok{lo, l, line})
			} else {
				ts = append(ts, tok{"id", l, line})
			}
			i = j
			continue
		}
		if isDigit(c) {
			j := i + 1
			dot := false
			for j < len(src) && (isDigit(src[j]) || (!dot && src[j] == '.')) {
				if src[j] == '.' {
					dot = true
				}
				j++
			}
			ts = append(ts, tok{"num", src[i:j], line})
			i = j
			continue
		}
		if c == '"' || c == '\'' {
			q := c
			j := i + 1
			var b strings.Builder
			for j < len(src) {
				if src[j] == '\n' {
					line++
				}
				if src[j] == q {
					break
				}
				if src[j] == '\\' && j+1 < len(src) {
					j++
					ch := src[j]
					if q == '"' {
						switch ch {
						case 'n':
							b.WriteByte('\n')
						case 'r':
							b.WriteByte('\r')
						case 't':
							b.WriteByte('\t')
						case '\\':
							b.WriteByte('\\')
						case '"':
							b.WriteByte('"')
						case '$':
							b.WriteByte('$')
						default:
							b.WriteByte(ch)
						}
					} else {
						if ch == '\\' || ch == '\'' {
							b.WriteByte(ch)
						} else {
							b.WriteByte('\\')
							b.WriteByte(ch)
						}
					}
				} else {
					b.WriteByte(src[j])
				}
				j++
			}
			ts = append(ts, tok{"str", b.String(), line})
			if j < len(src) {
				j++
			}
			i = j
			continue
		}
		if i+2 < len(src) {
			op3 := src[i : i+3]
			if op3 == "===" || op3 == "!==" {
				ts = append(ts, tok{op3, op3, line})
				i += 3
				continue
			}
		}
		if i+1 < len(src) {
			op2 := src[i : i+2]
			if strings.Contains("== != <= >= && || ++ -- += -= *= /= %= =>", op2) {
				ts = append(ts, tok{op2, op2, line})
				i += 2
				continue
			}
		}
		ts = append(ts, tok{string(c), string(c), line})
		i++
	}
	ts = append(ts, tok{"eof", "", line})
	return ts
}
func isAlpha(c byte) bool { return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' }
func isDigit(c byte) bool { return c >= '0' && c <= '9' }
func isAlnum(c byte) bool { return isAlpha(c) || isDigit(c) }

type Function struct {
	params []string
	body   []tok
}
type Env struct {
	vars   map[string]Val
	funcs  map[string]Function
	consts map[string]Val
	output io.Writer
	file   string
}

func newEnv(w io.Writer, file string, argv []string) *Env {
	env := &Env{vars: map[string]Val{}, funcs: map[string]Function{}, consts: map[string]Val{}, output: w, file: file}
	env.vars["_SERVER"] = VArray(nil)
	if argv != nil {
		env.vars["argc"] = VInt(int64(len(argv)))
		vals := make([]Val, len(argv))
		for i, a := range argv {
			vals[i] = VStr(a)
		}
		env.vars["argv"] = VArray(vals)
	}
	return env
}

type Parser struct {
	ts        []tok
	pos       int
	env       *Env
	err       error
	returning bool
	ret       Val
}

func (p *Parser) cur() tok {
	if p.pos >= len(p.ts) {
		return tok{"eof", "", 1}
	}
	return p.ts[p.pos]
}
func (p *Parser) next() tok { t := p.cur(); p.pos++; return t }
func (p *Parser) match(s string) bool {
	if p.cur().typ == s {
		p.pos++
		return true
	}
	return false
}
func (p *Parser) expect(s string) bool {
	if !p.match(s) {
		p.fail("syntax error, unexpected token \"" + p.cur().lit + "\"")
		return false
	}
	return true
}
func (p *Parser) fail(m string) {
	if p.err == nil {
		p.err = fmt.Errorf(m)
	}
}

func runPHP(src, file string, env *Env) error {
	code := extractPHP(src)
	p := &Parser{ts: lex(code), env: env}
	p.program()
	return p.err
}
func runPHPRaw(code string, env *Env) error {
	p := &Parser{ts: lex(code), env: env}
	p.program()
	return p.err
}

func extractPHP(src string) string {
	if !strings.Contains(src, "<?") {
		return `echo '` + phpString(src) + `';`
	}
	var b strings.Builder
	for {
		i := strings.Index(src, "<?")
		if i < 0 {
			if src != "" {
				b.WriteString(`echo '`)
				b.WriteString(phpString(src))
				b.WriteString(`';`)
			}
			break
		}
		if i > 0 {
			b.WriteString(`echo '`)
			b.WriteString(phpString(src[:i]))
			b.WriteString(`';`)
		}
		src = src[i+2:]
		if strings.HasPrefix(src, "php") || strings.HasPrefix(src, "PHP") {
			src = src[3:]
		}
		j := strings.Index(src, "?>")
		if j < 0 {
			b.WriteString(src)
			break
		}
		b.WriteString(src[:j])
		b.WriteByte('\n')
		src = src[j+2:]
	}
	return b.String()
}
func phpString(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `'`, `\'`)
	return s
}

func (p *Parser) program() {
	for p.cur().typ != "eof" && p.err == nil && !p.returning {
		p.stmt()
	}
}
func (p *Parser) stmt() {
	switch p.cur().typ {
	case ";":
		p.next()
	case "{":
		p.block(true)
	case "echo":
		p.next()
		for {
			v := p.expr()
			fmt.Fprint(p.env.output, v.out())
			if !p.match(",") {
				break
			}
		}
		p.expect(";")
	case "print":
		p.next()
		v := p.expr()
		fmt.Fprint(p.env.output, v.out())
		p.expect(";")
	case "var":
		p.assignOrExpr()
	case "if":
		p.ifstmt()
	case "while":
		p.whilestmt()
	case "for":
		p.forstmt()
	case "foreach":
		p.foreachstmt()
	case "function":
		p.funcdef()
	case "return":
		p.next()
		if !p.match(";") {
			p.ret = p.expr()
			p.expect(";")
		}
		p.returning = true
	default:
		p.expr()
		p.expect(";")
	}
}
func (p *Parser) block(exec bool) []tok {
	p.expect("{")
	start := p.pos
	depth := 1
	for p.pos < len(p.ts) && depth > 0 {
		if p.ts[p.pos].typ == "{" {
			depth++
		} else if p.ts[p.pos].typ == "}" {
			depth--
		}
		p.pos++
	}
	body := p.ts[start : p.pos-1]
	if exec {
		q := &Parser{ts: append(body, tok{"eof", "", p.cur().line}), env: p.env}
		q.program()
		p.err = q.err
		p.returning = q.returning
		p.ret = q.ret
	}
	return body
}
func (p *Parser) skipStmt() []tok {
	start := p.pos
	if p.cur().typ == "{" {
		return p.block(false)
	}
	for p.cur().typ != "eof" && p.cur().typ != ";" {
		p.pos++
	}
	if p.cur().typ == ";" {
		p.pos++
	}
	return p.ts[start:p.pos]
}
func (p *Parser) execTokens(body []tok) {
	q := &Parser{ts: append(append([]tok{}, body...), tok{"eof", "", 1}), env: p.env}
	q.program()
	p.err = q.err
	p.returning = q.returning
	p.ret = q.ret
}
func (p *Parser) parenTokens() []tok {
	p.expect("(")
	start := p.pos
	depth := 1
	for p.pos < len(p.ts) && depth > 0 {
		if p.ts[p.pos].typ == "(" {
			depth++
		} else if p.ts[p.pos].typ == ")" {
			depth--
		}
		p.pos++
	}
	if depth != 0 {
		p.fail("syntax error, unexpected end of file")
		return nil
	}
	return append([]tok{}, p.ts[start:p.pos-1]...)
}
func (p *Parser) evalTokens(ts []tok) Val {
	q := &Parser{ts: append(append([]tok{}, ts...), tok{"eof", "", 1}), env: p.env}
	v := q.expr()
	if q.err != nil {
		p.err = q.err
	}
	return v
}
func (p *Parser) execStmtTokens(ts []tok) {
	if len(ts) == 0 {
		return
	}
	q := &Parser{ts: append(append([]tok{}, ts...), tok{";", ";", 1}, tok{"eof", "", 1}), env: p.env}
	q.stmt()
	if q.err != nil {
		p.err = q.err
	}
}
func (p *Parser) assignOrExpr() {
	if p.cur().typ == "var" && p.pos+1 < len(p.ts) && (p.ts[p.pos+1].typ == "=" || strings.HasSuffix(p.ts[p.pos+1].typ, "=")) {
		name := p.next().lit
		op := p.next().typ
		v := p.expr()
		old := p.env.vars[name]
		switch op {
		case "=":
			p.env.vars[name] = v
		case "+=":
			p.env.vars[name] = add(old, v)
		case "-=":
			p.env.vars[name] = sub(old, v)
		case "*=":
			p.env.vars[name] = mul(old, v)
		case "/=":
			p.env.vars[name] = div(old, v)
		}
		p.expect(";")
		return
	}
	p.expr()
	p.expect(";")
}
func (p *Parser) ifstmt() {
	p.expect("if")
	p.expect("(")
	cond := p.expr().truth()
	p.expect(")")
	if cond {
		if p.cur().typ == "{" {
			p.block(true)
		} else {
			p.stmt()
		}
		if p.match("else") {
			p.skipStmt()
		}
	} else {
		p.skipStmt()
		if p.match("else") {
			if p.cur().typ == "{" {
				p.block(true)
			} else {
				p.stmt()
			}
		}
	}
}
func (p *Parser) whilestmt() {
	p.expect("while")
	cond := p.parenTokens()
	body := p.skipStmt()
	for guard := 0; guard < 100000; guard++ {
		if !p.evalTokens(cond).truth() || p.err != nil {
			break
		}
		p.execTokens(body)
		if p.err != nil || p.returning {
			return
		}
	}
}
func (p *Parser) forstmt() {
	p.expect("for")
	p.expect("(")
	var parts [][]tok
	start := p.pos
	depth := 0
	for p.cur().typ != "eof" {
		if depth == 0 && (p.cur().typ == ";" || p.cur().typ == ")") {
			parts = append(parts, append([]tok{}, p.ts[start:p.pos]...))
			if p.cur().typ == ")" {
				p.next()
				break
			}
			p.next()
			start = p.pos
			continue
		}
		if p.cur().typ == "(" || p.cur().typ == "[" {
			depth++
		} else if p.cur().typ == ")" || p.cur().typ == "]" {
			depth--
		}
		p.next()
	}
	for len(parts) < 3 {
		parts = append(parts, nil)
	}
	body := p.skipStmt()
	p.execStmtTokens(parts[0])
	for guard := 0; guard < 100000; guard++ {
		if len(parts[1]) > 0 && !p.evalTokens(parts[1]).truth() {
			break
		}
		p.execTokens(body)
		if p.err != nil || p.returning {
			return
		}
		p.execStmtTokens(parts[2])
	}
}
func (p *Parser) foreachstmt() {
	p.expect("foreach")
	p.expect("(")
	arr := p.expr()
	p.expect("as")
	key := ""
	if p.cur().typ == "var" {
		key = p.next().lit
	}
	val := key
	if p.match("=>") {
		if p.cur().typ == "var" {
			key = val
			val = p.next().lit
		}
	}
	p.expect(")")
	body := p.skipStmt()
	for i, x := range arr.A {
		if key != "" && key != val {
			p.env.vars[key] = VInt(int64(i))
		}
		if val != "" {
			p.env.vars[val] = x
		}
		p.execTokens(body)
		if p.err != nil || p.returning {
			return
		}
	}
}
func (p *Parser) funcdef() {
	p.expect("function")
	name := strings.ToLower(p.next().lit)
	p.expect("(")
	var ps []string
	for p.cur().typ != ")" && p.cur().typ != "eof" {
		if p.cur().typ == "var" {
			ps = append(ps, p.next().lit)
		} else {
			p.next()
		}
		p.match(",")
	}
	p.expect(")")
	body := p.block(false)
	p.env.funcs[name] = Function{ps, body}
}

func (p *Parser) expr() Val { return p.logicOr() }
func (p *Parser) logicOr() Val {
	v := p.logicAnd()
	for p.cur().typ == "||" || p.cur().typ == "or" {
		p.next()
		v = VBool(v.truth() || p.logicAnd().truth())
	}
	return v
}
func (p *Parser) logicAnd() Val {
	v := p.equality()
	for p.cur().typ == "&&" || p.cur().typ == "and" {
		p.next()
		v = VBool(v.truth() && p.equality().truth())
	}
	return v
}
func (p *Parser) equality() Val {
	v := p.compare()
	for p.cur().typ == "==" || p.cur().typ == "!=" || p.cur().typ == "===" || p.cur().typ == "!==" {
		op := p.next().typ
		r := p.compare()
		eq := v.out() == r.out()
		if op == "!=" || op == "!==" {
			eq = !eq
		}
		v = VBool(eq)
	}
	return v
}
func (p *Parser) compare() Val {
	v := p.concat()
	for strings.Contains("< > <= >=", p.cur().typ) {
		op := p.next().typ
		r := p.concat()
		a, b := v.num(), r.num()
		switch op {
		case "<":
			v = VBool(a < b)
		case ">":
			v = VBool(a > b)
		case "<=":
			v = VBool(a <= b)
		case ">=":
			v = VBool(a >= b)
		}
	}
	return v
}
func (p *Parser) concat() Val {
	v := p.term()
	for p.match(".") {
		v = VStr(v.out() + p.term().out())
	}
	return v
}
func (p *Parser) term() Val {
	v := p.factor()
	for p.cur().typ == "+" || p.cur().typ == "-" {
		op := p.next().typ
		if op == "+" {
			v = add(v, p.factor())
		} else {
			v = sub(v, p.factor())
		}
	}
	return v
}
func (p *Parser) factor() Val {
	v := p.unary()
	for p.cur().typ == "*" || p.cur().typ == "/" || p.cur().typ == "%" {
		op := p.next().typ
		r := p.unary()
		switch op {
		case "*":
			v = mul(v, r)
		case "/":
			v = div(v, r)
		case "%":
			v = VInt(v.intval() % maxi(1, r.intval()))
		}
	}
	return v
}
func (p *Parser) unary() Val {
	if p.match("!") {
		return VBool(!p.unary().truth())
	}
	if p.match("-") {
		v := p.unary()
		if v.K == Float {
			return VFloat(-v.F)
		}
		return VInt(-v.intval())
	}
	return p.primary()
}
func (p *Parser) primary() Val {
	t := p.next()
	switch t.typ {
	case "num":
		if strings.Contains(t.lit, ".") {
			f, _ := strconv.ParseFloat(t.lit, 64)
			return VFloat(f)
		}
		i, _ := strconv.ParseInt(t.lit, 10, 64)
		return VInt(i)
	case "str":
		return VStr(interpolate(t.lit, p.env))
	case "true":
		return VBool(true)
	case "false":
		return VBool(false)
	case "null":
		return VNil()
	case "var":
		v := p.env.vars[t.lit]
		for p.match("[") {
			idx := p.expr().intval()
			p.expect("]")
			if v.K == Array && int(idx) >= 0 && int(idx) < len(v.A) {
				v = v.A[idx]
			} else {
				v = VNil()
			}
		}
		if p.match("++") {
			p.env.vars[t.lit] = VInt(v.intval() + 1)
			return v
		}
		if p.match("--") {
			p.env.vars[t.lit] = VInt(v.intval() - 1)
			return v
		}
		return v
	case "id":
		name := strings.ToLower(t.lit)
		if p.match("(") {
			var args []Val
			for p.cur().typ != ")" && p.cur().typ != "eof" {
				args = append(args, p.expr())
				if !p.match(",") {
					break
				}
			}
			p.expect(")")
			return p.call(name, args)
		}
		return p.constVal(t.lit)
	case "array":
		p.expect("(")
		return p.arrayLit(")")
	case "[":
		return p.arrayLit("]")
	case "(":
		v := p.expr()
		p.expect(")")
		return v
	}
	p.fail("syntax error, unexpected token \"" + t.lit + "\"")
	return VNil()
}
func (p *Parser) arrayLit(end string) Val {
	var a []Val
	for p.cur().typ != end && p.cur().typ != "eof" {
		v := p.expr()
		if p.match("=>") {
			v = p.expr()
		}
		a = append(a, v)
		if !p.match(",") {
			break
		}
	}
	p.expect(end)
	return VArray(a)
}
func (p *Parser) call(name string, args []Val) Val {
	if f, ok := p.env.funcs[name]; ok {
		old := p.env.vars
		nv := map[string]Val{}
		for k, v := range old {
			nv[k] = v
		}
		for i, pn := range f.params {
			if i < len(args) {
				nv[pn] = args[i]
			} else {
				nv[pn] = VNil()
			}
		}
		p.env.vars = nv
		q := &Parser{ts: append(append([]tok{}, f.body...), tok{"eof", "", 1}), env: p.env}
		q.program()
		p.env.vars = old
		if q.err != nil {
			p.err = q.err
		}
		return q.ret
	}
	switch name {
	case "exit", "die":
		if len(args) > 0 {
			if args[0].K == Int {
				os.Exit(int(args[0].I))
			}
			fmt.Fprint(p.env.output, args[0].out())
		}
		os.Exit(0)
	case "strlen":
		if len(args) > 0 {
			return VInt(int64(len(args[0].out())))
		}
	case "strtoupper":
		if len(args) > 0 {
			return VStr(strings.ToUpper(args[0].out()))
		}
	case "strtolower":
		if len(args) > 0 {
			return VStr(strings.ToLower(args[0].out()))
		}
	case "trim":
		if len(args) > 0 {
			return VStr(strings.TrimSpace(args[0].out()))
		}
	case "count", "sizeof":
		if len(args) > 0 && args[0].K == Array {
			return VInt(int64(len(args[0].A)))
		}
		return VInt(0)
	case "intval":
		if len(args) > 0 {
			return VInt(args[0].intval())
		}
	case "floatval":
		if len(args) > 0 {
			return VFloat(args[0].num())
		}
	case "strval":
		if len(args) > 0 {
			return VStr(args[0].out())
		}
	case "is_null":
		return VBool(len(args) > 0 && args[0].K == Nil)
	case "is_int", "is_integer":
		return VBool(len(args) > 0 && args[0].K == Int)
	case "is_string":
		return VBool(len(args) > 0 && args[0].K == Str)
	case "is_bool":
		return VBool(len(args) > 0 && args[0].K == Bool)
	case "isset":
		for _, a := range args {
			if a.K == Nil {
				return VBool(false)
			}
		}
		return VBool(len(args) > 0)
	case "empty":
		return VBool(len(args) == 0 || !args[0].truth())
	case "abs":
		if len(args) > 0 {
			return VFloat(math.Abs(args[0].num()))
		}
	case "min":
		return minmax(args, false)
	case "max":
		return minmax(args, true)
	case "range":
		if len(args) >= 2 {
			var a []Val
			for i := args[0].intval(); i <= args[1].intval(); i++ {
				a = append(a, VInt(i))
			}
			return VArray(a)
		}
	case "array_sum":
		if len(args) > 0 && args[0].K == Array {
			var sum float64
			allInt := true
			for _, x := range args[0].A {
				sum += x.num()
				if x.K == Float {
					allInt = false
				}
			}
			if allInt {
				return VInt(int64(sum))
			}
			return VFloat(sum)
		}
	case "in_array":
		if len(args) >= 2 && args[1].K == Array {
			needle := args[0].out()
			for _, x := range args[1].A {
				if x.out() == needle {
					return VBool(true)
				}
			}
			return VBool(false)
		}
	case "substr":
		if len(args) >= 2 {
			s := args[0].out()
			start := int(args[1].intval())
			if start < 0 {
				start = len(s) + start
			}
			if start < 0 {
				start = 0
			}
			if start > len(s) {
				return VStr("")
			}
			end := len(s)
			if len(args) >= 3 {
				l := int(args[2].intval())
				if l >= 0 {
					end = start + l
				} else {
					end = len(s) + l
				}
			}
			if end < start {
				end = start
			}
			if end > len(s) {
				end = len(s)
			}
			return VStr(s[start:end])
		}
	case "strpos":
		if len(args) >= 2 {
			i := strings.Index(args[0].out(), args[1].out())
			if i < 0 {
				return VBool(false)
			}
			return VInt(int64(i))
		}
	case "str_replace":
		if len(args) >= 3 {
			return VStr(strings.ReplaceAll(args[2].out(), args[0].out(), args[1].out()))
		}
	case "implode", "join":
		if len(args) >= 2 && args[1].K == Array {
			parts := []string{}
			for _, v := range args[1].A {
				parts = append(parts, v.out())
			}
			return VStr(strings.Join(parts, args[0].out()))
		}
	case "explode":
		if len(args) >= 2 {
			ss := strings.Split(args[1].out(), args[0].out())
			a := []Val{}
			for _, s := range ss {
				a = append(a, VStr(s))
			}
			return VArray(a)
		}
	case "json_encode":
		if len(args) > 0 {
			return VStr(jsonish(args[0]))
		}
	case "file_get_contents":
		if len(args) > 0 {
			b, err := os.ReadFile(args[0].out())
			if err == nil {
				return VStr(string(b))
			}
			return VBool(false)
		}
	case "file_put_contents":
		if len(args) >= 2 {
			err := os.WriteFile(args[0].out(), []byte(args[1].out()), 0644)
			if err == nil {
				return VInt(int64(len(args[1].out())))
			}
			return VBool(false)
		}
	case "readfile":
		if len(args) > 0 {
			b, err := os.ReadFile(args[0].out())
			if err == nil {
				fmt.Fprint(p.env.output, string(b))
				return VInt(int64(len(b)))
			}
			return VBool(false)
		}
	case "include", "include_once", "require", "require_once":
		if len(args) > 0 {
			b, err := os.ReadFile(args[0].out())
			if err == nil {
				if e := runPHP(string(b), args[0].out(), p.env); e != nil {
					p.err = e
					return VBool(false)
				}
				return VInt(1)
			}
			return VBool(false)
		}
	case "print_r":
		if len(args) > 0 {
			printR(p.env.output, args[0])
			return VBool(true)
		}
	case "var_dump":
		for _, a := range args {
			varDump(p.env.output, a, 0)
		}
		return VNil()
	case "define":
		if len(args) >= 2 {
			p.env.consts[strings.ToUpper(args[0].out())] = args[1]
			return VBool(true)
		}
	case "defined":
		if len(args) > 0 {
			_, ok := p.env.consts[strings.ToUpper(args[0].out())]
			if !ok {
				switch strings.ToUpper(args[0].out()) {
				case "PHP_VERSION", "PHP_EOL", "STDIN", "STDOUT", "STDERR":
					ok = true
				}
			}
			return VBool(ok)
		}
	case "var_export":
		if len(args) > 0 {
			s := varExport(args[0])
			if len(args) > 1 && args[1].truth() {
				return VStr(s)
			}
			fmt.Fprint(p.env.output, s)
		}
		return VNil()
	}
	return VNil()
}

func add(a, b Val) Val {
	if a.K == Str || b.K == Str {
		return VInt(a.intval() + b.intval())
	}
	if a.K == Float || b.K == Float {
		return VFloat(a.num() + b.num())
	}
	return VInt(a.intval() + b.intval())
}
func sub(a, b Val) Val {
	if a.K == Float || b.K == Float {
		return VFloat(a.num() - b.num())
	}
	return VInt(a.intval() - b.intval())
}
func mul(a, b Val) Val {
	if a.K == Float || b.K == Float {
		return VFloat(a.num() * b.num())
	}
	return VInt(a.intval() * b.intval())
}
func div(a, b Val) Val {
	if b.num() == 0 {
		return VFloat(math.Inf(1))
	}
	return VFloat(a.num() / b.num())
}
func maxi(a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}
func minmax(args []Val, mx bool) Val {
	if len(args) == 0 {
		return VNil()
	}
	best := args[0].num()
	for _, v := range args[1:] {
		if mx && v.num() > best || !mx && v.num() < best {
			best = v.num()
		}
	}
	if best == math.Trunc(best) {
		return VInt(int64(best))
	}
	return VFloat(best)
}
func filepathDir(path string) string {
	if path == "" || strings.Contains(path, "Command line") {
		return ""
	}
	return filepath.Dir(path)
}
func (p *Parser) constVal(s string) Val {
	if v, ok := p.env.consts[strings.ToUpper(s)]; ok {
		return v
	}
	switch strings.ToUpper(s) {
	case "PHP_VERSION":
		return VStr(version)
	case "PHP_EOL":
		return VStr("\n")
	case "__FILE__":
		return VStr(p.env.file)
	case "__DIR__":
		return VStr(filepathDir(p.env.file))
	case "STDIN", "STDOUT", "STDERR":
		return VInt(0)
	}
	return VStr(s)
}
func interpolate(s string, env *Env) string {
	re := regexp.MustCompile(`\$([A-Za-z_][A-Za-z0-9_]*)`)
	return re.ReplaceAllStringFunc(s, func(m string) string { return env.vars[m[1:]].out() })
}
func jsonish(v Val) string {
	switch v.K {
	case Nil:
		return "null"
	case Bool:
		if v.B {
			return "true"
		}
		return "false"
	case Int:
		return strconv.FormatInt(v.I, 10)
	case Float:
		return strconv.FormatFloat(v.F, 'g', -1, 64)
	case Str:
		return strconv.Quote(v.S)
	case Array:
		ps := []string{}
		for _, x := range v.A {
			ps = append(ps, jsonish(x))
		}
		return "[" + strings.Join(ps, ",") + "]"
	}
	return "null"
}
func varExport(v Val) string {
	switch v.K {
	case Nil:
		return "NULL"
	case Bool:
		if v.B {
			return "true"
		}
		return "false"
	case Int:
		return strconv.FormatInt(v.I, 10)
	case Float:
		return strconv.FormatFloat(v.F, 'g', -1, 64)
	case Str:
		return "'" + strings.ReplaceAll(v.S, "'", "\\'") + "'"
	case Array:
		ps := []string{}
		for i, x := range v.A {
			ps = append(ps, fmt.Sprintf("%d => %s", i, varExport(x)))
		}
		return "array (\n  " + strings.Join(ps, ",\n  ") + "\n)"
	}
	return ""
}
func varDump(w io.Writer, v Val, indent int) {
	pad := strings.Repeat(" ", indent)
	switch v.K {
	case Nil:
		fmt.Fprintln(w, "NULL")
	case Bool:
		fmt.Fprintf(w, "bool(%v)\n", v.B)
	case Int:
		fmt.Fprintf(w, "int(%d)\n", v.I)
	case Float:
		fmt.Fprintf(w, "float(%s)\n", strconv.FormatFloat(v.F, 'g', -1, 64))
	case Str:
		fmt.Fprintf(w, "string(%d) \"%s\"\n", len(v.S), v.S)
	case Array:
		fmt.Fprintf(w, "array(%d) {\n", len(v.A))
		for i, x := range v.A {
			fmt.Fprintf(w, "%s  [%d]=>\n%s  ", pad, i, pad)
			varDump(w, x, indent+2)
		}
		fmt.Fprintf(w, "%s}\n", pad)
	}
}
func printR(w io.Writer, v Val) {
	if v.K != Array {
		fmt.Fprint(w, v.out())
		return
	}
	fmt.Fprintln(w, "Array\n(")
	for i, x := range v.A {
		fmt.Fprintf(w, "    [%d] => %s\n", i, x.out())
	}
	fmt.Fprintln(w, ")")
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		data, _ := io.ReadAll(os.Stdin)
		execute(string(data), "Standard input code")
		return
	}
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h", "--help":
			usage()
			return
		case "-v", "--version":
			versionOut()
			return
		case "-m":
			modules()
			return
		case "--ini":
			ini()
			return
		case "-i":
			info()
			return
		case "-n", "-e", "-H":
			continue
		case "-d", "-c":
			i++
			continue
		case "--rf":
			if i+1 < len(args) {
				rf(args[i+1])
			}
			return
		case "--ri", "--re", "--rz", "--rc":
			if i+1 < len(args) {
				fmt.Println(args[i+1])
			}
			return
		case "-r":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "Option -r requires an argument")
				os.Exit(1)
			}
			if strings.Contains(args[i+1], "<?") {
				parseErr("syntax error, unexpected token \"<\", expecting end of file", "Command line code")
				os.Exit(255)
			}
			executeRaw(args[i+1], "Command line code")
			return
		case "-R":
			runLines(args, i)
			return
		case "-B", "-E":
			continue
		case "-l":
			if i+1 < len(args) {
				lint(args[i+1])
			}
			return
		case "-s":
			if i+1 < len(args) {
				highlight(args[i+1])
			}
			return
		case "-w":
			if i+1 < len(args) {
				strip(args[i+1])
			}
			return
		case "-f":
			if i+1 < len(args) {
				runFile(args[i+1], args[i+2:])
			}
			return
		default:
			if strings.HasPrefix(args[i], "-") {
				usage()
				return
			}
			runFile(args[i], args[i+1:])
			return
		}
	}
}
func execute(code, file string) {
	env := newEnv(os.Stdout, file, nil)
	if err := runPHP(code, file, env); err != nil {
		parseErr(err.Error(), file)
		os.Exit(255)
	}
}
func executeRaw(code, file string) {
	env := newEnv(os.Stdout, file, nil)
	if err := runPHPRaw(code, env); err != nil {
		parseErr(err.Error(), file)
		os.Exit(255)
	}
}
func runFile(path string, scriptArgs []string) {
	b, err := os.ReadFile(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Could not open input file: %s\n", path)
		os.Exit(1)
	}
	env := newEnv(os.Stdout, path, append([]string{path}, scriptArgs...))
	if err := runPHP(string(b), path, env); err != nil {
		parseErr(err.Error(), path)
		os.Exit(255)
	}
}
func lint(path string) {
	b, err := os.ReadFile(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Could not open input file: %s\n", path)
		os.Exit(1)
	}
	env := newEnv(io.Discard, path, nil)
	if err := runPHP(string(b), path, env); err != nil {
		fmt.Printf("Errors parsing %s\n", path)
		os.Exit(255)
	}
	fmt.Printf("No syntax errors detected in %s\n", path)
}
func parseErr(msg, file string) { fmt.Printf("\nParse error: %s in %s on line 1\n", msg, file) }
func usage() {
	fmt.Print(`Usage: executable [options] [-f] <file> [--] [args...]
   executable [options] -r <code> [--] [args...]
   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]
   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]
   executable [options] -S <addr>:<port> [-t docroot] [router]
   executable [options] -- [args...]
   executable [options] -a

  -a               Run as interactive shell (requires readline extension)
  -c <path>|<file> Look for php.ini file in this directory
  -n               No configuration (ini) files will be used
  -d foo[=bar]     Define INI entry foo with value 'bar'
  -e               Generate extended information for debugger/profiler
  -f <file>        Parse and execute <file>.
  -h               This help
  -i               PHP information
  -l               Syntax check only (lint)
  -m               Show compiled in modules
  -r <code>        Run PHP <code> without using script tags <?..?>
  -B <begin_code>  Run PHP <begin_code> before processing input lines
  -R <code>        Run PHP <code> for every input line
  -F <file>        Parse and execute <file> for every input line
  -E <end_code>    Run PHP <end_code> after processing all input lines
  -H               Hide any passed arguments from external tools.
  -S <addr>:<port> Run with built-in web server.
  -t <docroot>     Specify document root <docroot> for built-in web server.
  -s               Output HTML syntax highlighted source.
  -v               Version number
  -w               Output source with stripped comments and whitespace.

  args...          Arguments passed to script. Use -- args when first argument
                   starts with - or script is read from stdin

  --ini            Show configuration file names
  --ini=diff       Show INI entries that differ from the built-in default

  --rf <name>      Show information about function <name>.
  --rc <name>      Show information about class <name>.
  --re <name>      Show information about extension <name>.
  --rz <name>      Show information about Zend extension <name>.
  --ri <name>      Show configuration for extension <name>.

  --repeat <count> Repeat script execution <count> times.
                   For internal purposes only.

`)
}
func versionOut() {
	fmt.Printf("PHP %s (cli) (built: Apr 17 2026 20:00:58) (NTS)\nCopyright (c) The PHP Group\nZend Engine v4.6.0-dev, Copyright (c) Zend Technologies\n    with Zend OPcache v%s, Copyright (c), by Zend Technologies\n", version, version)
}
func modules() {
	fmt.Println("[PHP Modules]\nCore\ndate\nhash\njson\nlexbor\npcre\nrandom\nReflection\nSPL\nstandard\nuri\nZend OPcache\n\n[Zend Modules]\nZend OPcache")
}
func ini() {
	fmt.Println("Configuration File (php.ini) Path: \"/usr/local/lib\"\nLoaded Configuration File:         (none)\nScan for additional .ini files in: (none)\nAdditional .ini files parsed:      (none)")
}
func info() {
	fmt.Printf("phpinfo()\nPHP Version => %s\n\nSystem => Linux\nBuild Date => Apr 17 2026 20:00:58\nConfigure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'\nServer API => Command Line Interface\nConfiguration File (php.ini) Path => /usr/local/lib\nLoaded Configuration File => (none)\n\nZend Engine v4.6.0-dev, Copyright (c) Zend Technologies\n", version)
}
func rf(name string) {
	fmt.Printf("Function [ <internal:standard> function %s ] {\n\n  - Parameters [0] {\n  }\n}\n", name)
}
func highlight(path string) {
	b, _ := os.ReadFile(path)
	fmt.Print("<code><span style=\"color: #000000\">\n" + html.EscapeString(string(b)) + "\n</span></code>")
}
func strip(path string) {
	b, _ := os.ReadFile(path)
	s := regexp.MustCompile(`(?s)/\*.*?\*/|//.*|#.*`).ReplaceAllString(string(b), "")
	fmt.Print(s)
}
func runLines(args []string, idx int) {
	begin, end, code := "", "", ""
	for i := 0; i < len(args); i++ {
		if args[i] == "-B" && i+1 < len(args) {
			begin = args[i+1]
		}
		if args[i] == "-E" && i+1 < len(args) {
			end = args[i+1]
		}
		if args[i] == "-R" && i+1 < len(args) {
			code = args[i+1]
		}
	}
	env := newEnv(os.Stdout, "Command line run code", nil)
	if begin != "" {
		runPHPRaw(begin, env)
	}
	sc := bufio.NewScanner(os.Stdin)
	n := 0
	for sc.Scan() {
		n++
		env.vars["argn"] = VStr(sc.Text())
		env.vars["argi"] = VInt(int64(n))
		if err := runPHPRaw(code, env); err != nil {
			parseErr(err.Error(), "Command line run code")
			os.Exit(255)
		}
	}
	if end != "" {
		runPHPRaw(end, env)
	}
}
