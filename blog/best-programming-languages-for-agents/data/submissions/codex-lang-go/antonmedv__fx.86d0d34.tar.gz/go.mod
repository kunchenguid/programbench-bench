module fxclone

go 1.21
