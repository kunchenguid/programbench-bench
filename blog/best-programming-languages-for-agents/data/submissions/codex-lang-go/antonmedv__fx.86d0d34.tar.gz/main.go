package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "39.2.0"

type undef struct{}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, in io.Reader, out, errw io.Writer) int {
	var raw, slurp, yaml, toml bool
	var exprs []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-h" || a == "--help":
			printHelp(out)
			return 0
		case a == "-v" || a == "--version":
			fmt.Fprintln(out, version)
			return 0
		case a == "--themes":
			printThemes(out)
			return 0
		case a == "--game-of-life":
			fmt.Fprint(out, "\033[2J\033[?25l\033[H")
			return 0
		case a == "-r" || a == "--raw":
			raw = true
		case a == "-s" || a == "--slurp":
			slurp = true
		case a == "--yaml":
			yaml = true
		case a == "--toml":
			toml = true
		case a == "--strict" || a == "--no-inline":
		case a == "--comp":
			if i+1 < len(args) {
				i++
				printComp(out, args[i])
			}
			return 0
		case strings.HasPrefix(a, "--comp="):
			printComp(out, strings.TrimPrefix(a, "--comp="))
			return 0
		case strings.HasPrefix(a, "-"):
			return 0
		default:
			exprs = append(exprs, a)
		}
	}

	var data []byte
	if len(exprs) > 0 && !looksLikeExpr(exprs[0]) {
		if b, err := os.ReadFile(exprs[0]); err == nil {
			data = b
			exprs = exprs[1:]
		}
	}
	if data == nil {
		data, _ = io.ReadAll(in)
	}
	if raw {
		if len(exprs) == 0 {
			return 2
		}
		return emitAll(out, []any{strings.TrimRight(string(data), "\n")}, exprs)
	}

	var vals []any
	var err error
	if yaml {
		v := parseYAML(string(data))
		vals = []any{v}
	} else if toml {
		v := parseTOML(string(data))
		vals = []any{v}
	} else {
		vals, err = parseJSONStream(data)
		if err != nil {
			fmt.Fprintln(errw, err.Error())
			return 1
		}
	}
	if slurp {
		vals = []any{vals}
	}
	if len(exprs) == 0 {
		if len(bytes.TrimSpace(data)) == 0 {
			fmt.Fprintln(errw, "panic: could not open a new TTY: open /dev/tty: no such device or address")
			return 2
		}
		exprs = []string{"."}
	}
	return emitAll(out, vals, exprs)
}

func emitAll(out io.Writer, vals []any, exprs []string) int {
	for _, v := range vals {
		cur := v
		var err error
		for _, e := range exprs {
			cur, err = evalExpr(cur, e)
			if err != nil {
				fmt.Fprintln(out, err.Error())
				return 1
			}
		}
		printValue(out, cur)
	}
	return 0
}

func parseJSONStream(data []byte) ([]any, error) {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var vals []any
	for {
		var v any
		err := dec.Decode(&v)
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		vals = append(vals, normalize(v))
	}
	return vals, nil
}

func normalize(v any) any {
	switch x := v.(type) {
	case json.Number:
		if i, err := x.Int64(); err == nil {
			return float64(i)
		}
		f, _ := x.Float64()
		return f
	case []any:
		for i := range x {
			x[i] = normalize(x[i])
		}
	case map[string]any:
		for k := range x {
			x[k] = normalize(x[k])
		}
	}
	return v
}

func evalExpr(root any, expr string) (any, error) {
	expr = strings.TrimSpace(expr)
	if expr == "" || expr == "." || expr == "x" || expr == "this" {
		return root, nil
	}
	if expr == "keys" || expr == "Object.keys(x)" || expr == "Object.keys(this)" {
		return keysOf(root), nil
	}
	if isScalarExpr(expr) {
		return parseScalar(expr), nil
	}
	if strings.HasPrefix(expr, "x =>") {
		return evalExpr(root, strings.TrimSpace(strings.TrimPrefix(expr, "x =>"))[1:])
	}
	if strings.HasPrefix(expr, "this.") {
		return evalPath(root, "."+strings.TrimPrefix(expr, "this."))
	}
	if strings.HasPrefix(expr, "x.") {
		return evalPath(root, "."+strings.TrimPrefix(expr, "x."))
	}
	if strings.Contains(expr, ".map(") {
		return evalMap(root, expr)
	}
	if hasBinary(expr) {
		return evalBinary(root, expr)
	}
	if strings.HasPrefix(expr, ".") {
		return evalPath(root, expr)
	}
	return evalPath(root, "."+expr)
}

func evalBinary(root any, expr string) (any, error) {
	for _, op := range []string{" + ", " - ", " * ", " / ", "+", "-", "*", "/"} {
		if p := strings.Index(expr, op); p >= 0 {
			a, err := evalExpr(root, expr[:p])
			if err != nil {
				return nil, err
			}
			b, err := evalExpr(root, expr[p+len(op):])
			if err != nil {
				b = parseScalar(strings.TrimSpace(expr[p+len(op):]))
			}
			af, aok := num(a)
			bf, bok := num(b)
			if aok && bok {
				switch strings.TrimSpace(op) {
				case "+":
					return af + bf, nil
				case "-":
					return af - bf, nil
				case "*":
					return af * bf, nil
				case "/":
					return af / bf, nil
				}
			}
			if strings.TrimSpace(op) == "+" {
				return fmt.Sprint(a) + fmt.Sprint(b), nil
			}
		}
	}
	return nil, fmt.Errorf("unsupported expression")
}

func evalMap(root any, expr string) (any, error) {
	p := strings.Index(expr, ".map(")
	base, err := evalExpr(root, expr[:p])
	if err != nil {
		return nil, err
	}
	arr, ok := base.([]any)
	if !ok {
		return undef{}, nil
	}
	body := strings.TrimSuffix(expr[p+5:], ")")
	if i := strings.Index(body, "=>"); i >= 0 {
		body = strings.TrimSpace(body[i+2:])
	}
	out := make([]any, 0, len(arr))
	for _, item := range arr {
		e := strings.ReplaceAll(body, "x.", ".")
		if e == "x" {
			out = append(out, item)
			continue
		}
		if strings.HasPrefix(e, "x") {
			e = "." + strings.TrimPrefix(e, "x")
		}
		v, err := evalExpr(item, e)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, nil
}

func hasBinary(expr string) bool {
	for _, op := range []string{" + ", " - ", " * ", " / ", "+", "-", "*", "/"} {
		if strings.Index(expr, op) > 0 {
			return true
		}
	}
	return false
}

func isScalarExpr(expr string) bool {
	if expr == "true" || expr == "false" || expr == "null" {
		return true
	}
	if strings.HasPrefix(expr, "\"") || strings.HasPrefix(expr, "'") {
		return true
	}
	_, err := strconv.ParseFloat(expr, 64)
	return err == nil
}

func looksLikeExpr(s string) bool {
	s = strings.TrimSpace(s)
	return s == "" || strings.HasPrefix(s, ".") || strings.HasPrefix(s, "x") || strings.HasPrefix(s, "this") ||
		strings.Contains(s, "=>") || strings.Contains(s, "(") || s == "keys" || isScalarExpr(s)
}

func evalPath(v any, path string) (any, error) {
	i := 0
	for i < len(path) {
		if path[i] == '.' {
			i++
			start := i
			for i < len(path) && (unicode.IsLetter(rune(path[i])) || unicode.IsDigit(rune(path[i])) || path[i] == '_' || path[i] == '-') {
				i++
			}
			if start == i {
				continue
			}
			key := path[start:i]
			if key == "length" {
				switch x := v.(type) {
				case []any:
					v = float64(len(x))
				case map[string]any:
					v = float64(len(x))
				case string:
					v = float64(len(x))
				default:
					v = undef{}
				}
			} else {
				v = getKey(v, key)
			}
			continue
		}
		if path[i] == '[' {
			j := strings.IndexByte(path[i:], ']')
			if j < 0 {
				return nil, fmt.Errorf("Unexpected token [")
			}
			inside := strings.TrimSpace(path[i+1 : i+j])
			if inside == "" {
				if arr, ok := v.([]any); ok {
					v = arr
				} else {
					v = undef{}
				}
			} else if strings.HasPrefix(inside, "\"") || strings.HasPrefix(inside, "'") {
				s, _ := strconv.Unquote(strings.ReplaceAll(inside, "'", "\""))
				v = getKey(v, s)
			} else {
				n, _ := strconv.Atoi(inside)
				if arr, ok := v.([]any); ok && n >= 0 && n < len(arr) {
					v = arr[n]
				} else {
					v = undef{}
				}
			}
			i += j + 1
			continue
		}
		i++
	}
	return v, nil
}

func getKey(v any, key string) any {
	if m, ok := v.(map[string]any); ok {
		if x, ok := m[key]; ok {
			return x
		}
		return undef{}
	}
	if arr, ok := v.([]any); ok {
		out := make([]any, 0, len(arr))
		for _, it := range arr {
			out = append(out, getKey(it, key))
		}
		return out
	}
	return undef{}
}

func keysOf(v any) any {
	if m, ok := v.(map[string]any); ok {
		keys := make([]string, 0, len(m))
		for k := range m {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		out := make([]any, len(keys))
		for i, k := range keys {
			out[i] = k
		}
		return out
	}
	if arr, ok := v.([]any); ok {
		out := make([]any, len(arr))
		for i := range arr {
			out[i] = fmt.Sprint(i)
		}
		return out
	}
	return []any{}
}

func printValue(w io.Writer, v any) {
	switch x := v.(type) {
	case undef:
		fmt.Fprintln(w, "undefined")
	case string:
		fmt.Fprintln(w, x)
	case float64:
		if x == float64(int64(x)) {
			fmt.Fprintln(w, int64(x))
		} else {
			fmt.Fprintln(w, strconv.FormatFloat(x, 'f', -1, 64))
		}
	case bool:
		fmt.Fprintln(w, x)
	case nil:
		fmt.Fprintln(w, "null")
	default:
		b, _ := json.MarshalIndent(clean(v), "", "  ")
		fmt.Fprintln(w, string(b))
	}
}

func clean(v any) any {
	switch x := v.(type) {
	case undef:
		return nil
	case float64:
		if x == float64(int64(x)) {
			return int64(x)
		}
	case []any:
		for i := range x {
			x[i] = clean(x[i])
		}
	case map[string]any:
		for k := range x {
			x[k] = clean(x[k])
		}
	}
	return v
}

func num(v any) (float64, bool) {
	switch x := v.(type) {
	case float64:
		return x, true
	case int:
		return float64(x), true
	case int64:
		return float64(x), true
	case string:
		f, err := strconv.ParseFloat(x, 64)
		return f, err == nil
	}
	return 0, false
}

func parseScalar(s string) any {
	s = strings.TrimSpace(s)
	if s == "true" {
		return true
	}
	if s == "false" {
		return false
	}
	if s == "null" {
		return nil
	}
	if strings.HasPrefix(s, "\"") || strings.HasPrefix(s, "'") {
		u, _ := strconv.Unquote(strings.ReplaceAll(s, "'", "\""))
		return u
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil {
		return f
	}
	return s
}

func parseYAML(s string) any {
	root := map[string]any{}
	lines := strings.Split(s, "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimRight(lines[i], "\r")
		if strings.TrimSpace(line) == "" || strings.HasPrefix(strings.TrimSpace(line), "#") {
			continue
		}
		if !strings.HasPrefix(line, " ") && strings.Contains(line, ":") {
			parts := strings.SplitN(line, ":", 2)
			key := strings.TrimSpace(parts[0])
			val := strings.TrimSpace(parts[1])
			if val != "" {
				root[key] = parseScalar(val)
				continue
			}
			var arr []any
			obj := map[string]any{}
			for i+1 < len(lines) && strings.HasPrefix(lines[i+1], " ") {
				i++
				t := strings.TrimSpace(lines[i])
				if strings.HasPrefix(t, "- ") {
					arr = append(arr, parseScalar(strings.TrimSpace(t[2:])))
				} else if strings.Contains(t, ":") {
					p := strings.SplitN(t, ":", 2)
					obj[strings.TrimSpace(p[0])] = parseScalar(strings.TrimSpace(p[1]))
				}
			}
			if arr != nil {
				root[key] = arr
			} else {
				root[key] = obj
			}
		}
	}
	return root
}

func parseTOML(s string) any {
	root := map[string]any{}
	cur := root
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			name := strings.Trim(line, "[] ")
			m := map[string]any{}
			root[name] = m
			cur = m
			continue
		}
		if strings.Contains(line, "=") {
			p := strings.SplitN(line, "=", 2)
			cur[strings.TrimSpace(p[0])] = parseScalar(strings.TrimSpace(p[1]))
		}
	}
	return root
}

func printHelp(w io.Writer) {
	fmt.Fprint(w, `
  fx 39.2.0
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>

`)
}

func printThemes(w io.Writer) {
	for i := 0; i < 10; i++ {
		fmt.Fprintf(w, "export FX_THEME=\"%d\"\n", i)
		fmt.Fprintln(w, "{")
		fmt.Fprintln(w, "  \"string\": \"Fox jumps over the lazy dog\",")
		fmt.Fprintln(w, "  \"number\": 1234567890,")
		fmt.Fprintln(w, "  \"boolean\": true,")
		fmt.Fprintln(w, "  \"null\": null,")
		fmt.Fprintln(w, "  \"collapsed\": {\"preview\":…}")
		fmt.Fprintln(w, "}")
	}
}

func printComp(w io.Writer, shell string) {
	switch shell {
	case "bash":
		fmt.Fprintln(w, "complete -o filenames -C fx fx")
	case "fish":
		fmt.Fprintln(w, "complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'")
	case "zsh":
		fmt.Fprintln(w, "#compdef fx\n\n_fx() {\n    local -a reply\n    reply=(\"${(@f)$(COMP_ZSH=\"${LBUFFER}\" fx)}\")\n}\ncompdef _fx fx")
	default:
		fmt.Fprintln(w, "unknown shell type")
	}
}
