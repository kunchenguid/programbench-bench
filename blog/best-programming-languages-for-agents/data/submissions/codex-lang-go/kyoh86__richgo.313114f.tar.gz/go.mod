module richgo-reimpl

go 1.21
