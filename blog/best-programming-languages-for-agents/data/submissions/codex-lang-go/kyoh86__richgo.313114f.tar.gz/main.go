package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"syscall"
)

const (
	reset   = "\x1b[0m"
	bold    = "\x1b[1m"
	red     = "\x1b[31m"
	green   = "\x1b[32m"
	yellow  = "\x1b[33m"
	cyan    = "\x1b[36m"
	magenta = "\x1b[35m"
	gray    = "\x1b[90m"
)

var (
	reRun      = regexp.MustCompile(`^=== RUN\s+(.+)$`)
	reStatus   = regexp.MustCompile(`^--- (PASS|FAIL|SKIP):\s+(.+)$`)
	reFileLine = regexp.MustCompile(`^(\s*)([^:\s][^:]*\.(?:go|s|c|h|cc|cpp|hpp)):(\d+):(.*)$`)
	reCoverage = regexp.MustCompile(`^coverage:\s+([0-9]+(?:\.[0-9]+)?)%\s+of\s+statements`)
)

func main() {
	args := os.Args[1:]
	if len(args) > 0 && args[0] == "testfilter" {
		filter(os.Stdin, os.Stdout, isTerminal(os.Stdout.Fd()))
		return
	}
	if len(args) > 0 && args[0] == "test" {
		os.Exit(runGoTest(args[1:]))
	}
	os.Exit(runGo(args))
}

func runGo(args []string) int {
	cmd := exec.Command("go", args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return ee.ExitCode()
		}
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func runGoTest(args []string) int {
	cmd := exec.Command("go", append([]string{"test"}, args...)...)
	cmd.Stdin = os.Stdin
	var out bytes.Buffer
	mw := io.MultiWriter(&out)
	cmd.Stdout = mw
	cmd.Stderr = mw
	err := cmd.Run()
	filter(bytes.NewReader(out.Bytes()), os.Stdout, isTerminal(os.Stdout.Fd()))
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return ee.ExitCode()
		}
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func isTerminal(fd uintptr) bool {
	var st syscall.Stat_t
	if err := syscall.Fstat(int(fd), &st); err != nil {
		return false
	}
	return (st.Mode & syscall.S_IFMT) == syscall.S_IFCHR
}

func filter(r io.Reader, w io.Writer, color bool) {
	sc := bufio.NewScanner(r)
	for sc.Scan() {
		line := sc.Text()
		if !color {
			fmt.Fprintln(w, line)
			continue
		}
		if out, ok := decorate(line); ok {
			fmt.Fprintln(w, out)
		}
	}
	fmt.Fprintln(w)
}

func decorate(line string) (string, bool) {
	if m := reRun.FindStringSubmatch(line); m != nil {
		return gray + "START| " + prettyTestName(m[1], true) + reset, true
	}
	if m := reStatus.FindStringSubmatch(line); m != nil {
		name := prettyTestName(m[2], false)
		switch m[1] {
		case "PASS":
			return green + "PASS | " + name + reset, true
		case "FAIL":
			return red + bold + "FAIL | " + name + reset, true
		case "SKIP":
			return gray + "SKIP | " + name + reset, true
		}
	}
	if m := reCoverage.FindStringSubmatch(line); m != nil {
		pct, _ := strconv.ParseFloat(m[1], 64)
		style := green
		if pct < 50 {
			style = yellow + bold
		}
		return style + "COVER| " + m[1] + "% " + coverBar(pct) + reset, true
	}
	if strings.HasPrefix(line, "# ") {
		return yellow + bold + "BUILD| " + strings.TrimPrefix(line, "# "), true
	}
	if m := reFileLine.FindStringSubmatch(line); m != nil {
		return gray + "     | " + m[1] + cyan + m[2] + reset + magenta + ":" + m[3] + reset + gray + ":" + m[4] + reset, true
	}
	if line == "PASS" || line == "FAIL" || strings.HasPrefix(line, "exit status ") {
		return "", false
	}
	if strings.HasPrefix(line, "ok  \t") || strings.HasPrefix(line, "ok  ") {
		rest := strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(line, "ok  \t"), "ok  "))
		parts := strings.Fields(rest)
		if len(parts) > 0 {
			text := parts[0]
			if i := strings.Index(line, "coverage:"); i >= 0 {
				text += " " + line[i:]
			}
			return green + "PASS | " + text + " " + reset, true
		}
	}
	if strings.HasPrefix(line, "?   \t") || strings.HasPrefix(line, "?   ") {
		rest := strings.TrimPrefix(strings.TrimPrefix(line, "?   \t"), "?   ")
		return gray + "SKIP | " + rest + reset, true
	}
	if strings.HasPrefix(line, "FAIL\t") || strings.HasPrefix(line, "FAIL ") {
		rest := strings.TrimPrefix(strings.TrimPrefix(line, "FAIL\t"), "FAIL ")
		return red + bold + "FAIL | \t" + rest + reset, true
	}
	return line, true
}

func prettyTestName(s string, start bool) string {
	if i := strings.LastIndex(s, " ("); i >= 0 {
		return prettyTestName(s[:i], start) + s[i:]
	}
	depth := strings.Count(s, "/")
	name := s
	if strings.HasPrefix(name, "Test") {
		name = strings.TrimPrefix(name, "Test")
	}
	if strings.HasPrefix(name, "Benchmark") {
		name = strings.TrimPrefix(name, "Benchmark")
	}
	if depth > 0 {
		return strings.Repeat("  ", depth) + name
	}
	return name
}

func coverBar(pct float64) string {
	n := int(pct / 10)
	if n < 0 {
		n = 0
	}
	if n > 10 {
		n = 10
	}
	return "[" + strings.Repeat("#", n) + strings.Repeat("_", 10-n) + "]"
}
