package main

import (
	"bytes"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
)

type config struct {
	indent   int
	tab      bool
	htmlMode bool
	jsonOut  bool
	compact  bool
	depth    int
	node     bool
	inPlace  bool
	color    bool
	noColor  bool
	version  bool
	help     bool
	xpath    string
	extract  string
	query    string
	attr     string
	file     string
}

type XNode struct {
	Name     string
	Attrs    []xml.Attr
	Children []*XNode
	Texts    []string
	Comments []string
}

type HNode struct {
	Name     string
	Attrs    []xml.Attr
	Children []*HNode
	Texts    []string
	Parent   *HNode
}

func main() {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	if cfg.help {
		printHelp()
		return
	}
	if cfg.version {
		fmt.Println("xq version 1.4.0")
		return
	}
	data, err := readInput(cfg.file)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	out, err := run(cfg, data)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	if cfg.inPlace {
		if cfg.file == "" {
			fmt.Fprintln(os.Stderr, "Error: in-place requires a file")
			os.Exit(1)
		}
		if err := os.WriteFile(cfg.file, []byte(out), 0644); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
		return
	}
	fmt.Print(out)
}

func parseArgs(args []string) (config, error) {
	cfg := config{indent: 2, depth: -1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func(name string) (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("flag needs an argument: %s", name)
			}
			i++
			return args[i], nil
		}
		switch a {
		case "-h", "--help":
			cfg.help = true
		case "-v", "--version":
			cfg.version = true
		case "-c", "--color":
			cfg.color = true
		case "--no-color":
			cfg.noColor = true
		case "--tab":
			cfg.tab = true
		case "-m", "--html":
			cfg.htmlMode = true
		case "-j", "--json":
			cfg.jsonOut = true
		case "--compact":
			cfg.compact = true
		case "-n", "--node":
			cfg.node = true
		case "-i", "--in-place":
			cfg.inPlace = true
		case "--indent":
			s, err := next(a)
			if err != nil {
				return cfg, err
			}
			n, err := strconv.Atoi(s)
			if err != nil {
				return cfg, fmt.Errorf("invalid argument %q for %q flag: %v", s, a, err)
			}
			cfg.indent = n
		case "-d", "--depth":
			s, err := next(a)
			if err != nil {
				return cfg, err
			}
			n, err := strconv.Atoi(s)
			if err != nil {
				return cfg, err
			}
			cfg.depth = n
		case "-x", "--xpath":
			s, err := next(a)
			if err != nil {
				return cfg, err
			}
			cfg.xpath = s
		case "-e", "--extract":
			s, err := next(a)
			if err != nil {
				return cfg, err
			}
			cfg.extract = s
		case "-q", "--query":
			s, err := next(a)
			if err != nil {
				return cfg, err
			}
			cfg.query = s
		case "-a", "--attr":
			s, err := next(a)
			if err != nil {
				return cfg, err
			}
			cfg.attr = s
		default:
			if strings.HasPrefix(a, "-") {
				return cfg, fmt.Errorf("unknown flag: %s", a)
			}
			if cfg.file != "" {
				return cfg, errors.New("accepts at most 1 arg(s), received 2")
			}
			cfg.file = a
		}
	}
	return cfg, nil
}

func printHelp() {
	fmt.Print(`Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
`)
}

func readInput(file string) ([]byte, error) {
	if file != "" {
		return os.ReadFile(file)
	}
	return io.ReadAll(os.Stdin)
}

func run(cfg config, data []byte) (string, error) {
	unit := strings.Repeat(" ", cfg.indent)
	if cfg.tab {
		unit = "\t"
	}
	if cfg.jsonOut {
		root, err := parseXML(data)
		if err != nil {
			return "", fmt.Errorf("error while parsing XML: %v", err)
		}
		v := map[string]any{root.Name: xmlToJSON(root, 0, cfg.depth)}
		var b []byte
		if cfg.compact {
			b, err = json.Marshal(v)
		} else {
			b, err = json.MarshalIndent(v, "", unit)
		}
		if err != nil {
			return "", err
		}
		return string(b) + "\n", nil
	}
	if cfg.htmlMode {
		return runHTML(cfg, data, unit)
	}
	root, err := parseXML(data)
	if err != nil {
		return partialXML(data), err
	}
	query := cfg.xpath
	one := false
	if cfg.extract != "" {
		query = cfg.extract
		one = true
	}
	if query != "" {
		return extractXML(root, query, cfg.node, one, unit), nil
	}
	return formatXNode(root, 0, unit) + "\n", nil
}

func parseXML(data []byte) (*XNode, error) {
	dec := xml.NewDecoder(bytes.NewReader(data))
	var stack []*XNode
	var root *XNode
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return root, err
		}
		switch t := tok.(type) {
		case xml.StartElement:
			n := &XNode{Name: t.Name.Local, Attrs: append([]xml.Attr(nil), t.Attr...)}
			if len(stack) > 0 {
				p := stack[len(stack)-1]
				p.Children = append(p.Children, n)
			} else if root == nil {
				root = n
			}
			stack = append(stack, n)
		case xml.EndElement:
			if len(stack) > 0 {
				stack = stack[:len(stack)-1]
			}
		case xml.CharData:
			if len(stack) > 0 {
				s := string([]byte(t))
				if strings.TrimSpace(s) != "" {
					stack[len(stack)-1].Texts = append(stack[len(stack)-1].Texts, strings.TrimSpace(s))
				}
			}
		case xml.Comment:
			if len(stack) > 0 {
				stack[len(stack)-1].Comments = append(stack[len(stack)-1].Comments, string([]byte(t)))
			}
		}
	}
	if root == nil {
		return nil, errors.New("no root element")
	}
	return root, nil
}

func partialXML(data []byte) string {
	s := strings.TrimSpace(string(data))
	if s == "" {
		return ""
	}
	return s
}

func formatAttrs(attrs []xml.Attr) string {
	var b strings.Builder
	for _, a := range attrs {
		b.WriteByte(' ')
		b.WriteString(a.Name.Local)
		b.WriteString(`="`)
		xml.EscapeText(&b, []byte(a.Value))
		b.WriteByte('"')
	}
	return b.String()
}

func formatXNode(n *XNode, depth int, unit string) string {
	pad := strings.Repeat(unit, depth)
	name := n.Name
	attrs := formatAttrs(n.Attrs)
	if len(n.Children) == 0 && len(n.Comments) == 0 {
		text := strings.Join(n.Texts, "")
		if text == "" {
			return pad + "<" + name + attrs + "/>"
		}
		return pad + "<" + name + attrs + ">" + escapeText(text) + "</" + name + ">"
	}
	var b strings.Builder
	b.WriteString(pad + "<" + name + attrs + ">")
	for _, t := range n.Texts {
		if strings.TrimSpace(t) != "" {
			b.WriteString("\n" + strings.Repeat(unit, depth+1) + escapeText(strings.TrimSpace(t)))
		}
	}
	for _, c := range n.Comments {
		b.WriteString("\n" + strings.Repeat(unit, depth+1) + "<!--" + c + "-->")
	}
	for _, ch := range n.Children {
		b.WriteByte('\n')
		b.WriteString(formatXNode(ch, depth+1, unit))
	}
	b.WriteString("\n" + pad + "</" + name + ">")
	return b.String()
}

func escapeText(s string) string {
	var b strings.Builder
	xml.EscapeText(&b, []byte(s))
	return b.String()
}

func xmlToJSON(n *XNode, depth, maxDepth int) any {
	if maxDepth >= 0 && depth >= maxDepth {
		return strings.TrimSpace(textOfX(n))
	}
	if len(n.Attrs) == 0 && len(n.Children) == 0 {
		if len(n.Texts) == 0 {
			return map[string]any{}
		}
		return strings.Join(n.Texts, "")
	}
	m := map[string]any{}
	for _, a := range n.Attrs {
		m["@"+a.Name.Local] = a.Value
	}
	if len(n.Texts) > 0 {
		m["#text"] = strings.Join(n.Texts, "")
	}
	for _, ch := range n.Children {
		v := xmlToJSON(ch, depth+1, maxDepth)
		if old, ok := m[ch.Name]; ok {
			if arr, ok := old.([]any); ok {
				m[ch.Name] = append(arr, v)
			} else {
				m[ch.Name] = []any{old, v}
			}
		} else {
			m[ch.Name] = v
		}
	}
	return m
}

func textOfX(n *XNode) string {
	var parts []string
	parts = append(parts, n.Texts...)
	for _, ch := range n.Children {
		parts = append(parts, textOfX(ch))
	}
	return strings.Join(parts, "")
}

func extractXML(root *XNode, query string, node bool, one bool, unit string) string {
	attr := ""
	if i := strings.LastIndex(query, "/@"); i >= 0 {
		attr = query[i+2:]
		query = query[:i]
	}
	nodes := selectXPath(root, query)
	var out []string
	for _, n := range nodes {
		if attr != "" {
			if v, ok := xAttr(n, attr); ok {
				out = append(out, v)
			}
		} else if node {
			out = append(out, formatXNode(n, 0, unit))
		} else {
			out = append(out, strings.TrimSpace(textOfX(n)))
		}
		if one && len(out) > 0 {
			break
		}
	}
	if len(out) == 0 {
		return ""
	}
	return strings.Join(out, "\n") + "\n"
}

func selectXPath(root *XNode, query string) []*XNode {
	query = strings.TrimSpace(query)
	if query == "" {
		return nil
	}
	if strings.HasPrefix(query, "//") {
		name := strings.TrimPrefix(query, "//")
		var res []*XNode
		var walk func(*XNode)
		walk = func(n *XNode) {
			if name == "*" || n.Name == name {
				res = append(res, n)
			}
			for _, ch := range n.Children {
				walk(ch)
			}
		}
		walk(root)
		return res
	}
	if strings.HasPrefix(query, "/") {
		parts := strings.Split(strings.Trim(query, "/"), "/")
		if len(parts) == 0 || parts[0] != root.Name {
			return nil
		}
		cur := []*XNode{root}
		for _, p := range parts[1:] {
			var next []*XNode
			for _, n := range cur {
				for _, ch := range n.Children {
					if p == "*" || ch.Name == p {
						next = append(next, ch)
					}
				}
			}
			cur = next
		}
		return cur
	}
	if root.Name == query {
		return []*XNode{root}
	}
	return nil
}

func xAttr(n *XNode, name string) (string, bool) {
	for _, a := range n.Attrs {
		if a.Name.Local == name {
			return a.Value, true
		}
	}
	return "", false
}

func runHTML(cfg config, data []byte, unit string) (string, error) {
	doc, err := parseHTML(data)
	if err != nil {
		return "", err
	}
	if cfg.query != "" {
		nodes := queryHTML(doc, cfg.query)
		var out []string
		for _, n := range nodes {
			if cfg.attr != "" {
				if v, ok := hAttr(n, cfg.attr); ok {
					out = append(out, v)
				}
			} else if cfg.node {
				out = append(out, formatHTMLNode(n, 0, unit))
			} else {
				out = append(out, strings.TrimSpace(textOfHTML(n)))
			}
		}
		if len(out) == 0 {
			return "", nil
		}
		return strings.Join(out, "\n") + "\n", nil
	}
	n := firstHElement(doc)
	if n == nil {
		return "", nil
	}
	return formatHTMLNode(n, 0, unit) + "\n", nil
}

func parseHTML(data []byte) (*HNode, error) {
	dec := xml.NewDecoder(bytes.NewReader(data))
	dec.Strict = false
	dec.AutoClose = xml.HTMLAutoClose
	dec.Entity = xml.HTMLEntity
	root := &HNode{Name: "__root__"}
	stack := []*HNode{root}
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		switch t := tok.(type) {
		case xml.StartElement:
			p := stack[len(stack)-1]
			n := &HNode{Name: strings.ToLower(t.Name.Local), Attrs: append([]xml.Attr(nil), t.Attr...), Parent: p}
			p.Children = append(p.Children, n)
			stack = append(stack, n)
		case xml.EndElement:
			name := strings.ToLower(t.Name.Local)
			for len(stack) > 1 {
				top := stack[len(stack)-1]
				stack = stack[:len(stack)-1]
				if top.Name == name {
					break
				}
			}
		case xml.CharData:
			if len(stack) > 0 {
				s := strings.TrimSpace(string([]byte(t)))
				if s != "" {
					stack[len(stack)-1].Texts = append(stack[len(stack)-1].Texts, s)
				}
			}
		}
	}
	return root, nil
}

func firstHElement(n *HNode) *HNode {
	if n.Name != "__root__" {
		return n
	}
	for _, c := range n.Children {
		if r := firstHElement(c); r != nil {
			return r
		}
	}
	return nil
}

func textOfHTML(n *HNode) string {
	var parts []string
	var walk func(*HNode)
	walk = func(x *HNode) {
		parts = append(parts, x.Texts...)
		for _, c := range x.Children {
			walk(c)
		}
	}
	walk(n)
	return strings.Join(parts, " ")
}

func hAttr(n *HNode, name string) (string, bool) {
	for _, a := range n.Attrs {
		if a.Name.Local == name {
			return a.Value, true
		}
	}
	return "", false
}

func formatHAttrs(attrs []xml.Attr) string {
	var b strings.Builder
	for _, a := range attrs {
		b.WriteByte(' ')
		b.WriteString(a.Name.Local)
		b.WriteString(`="`)
		xml.EscapeText(&b, []byte(a.Value))
		b.WriteByte('"')
	}
	return b.String()
}

func formatHTMLNode(n *HNode, depth int, unit string) string {
	pad := strings.Repeat(unit, depth)
	name := n.Name
	attrs := formatHAttrs(n.Attrs)
	elems := n.Children
	texts := n.Texts
	if len(elems) == 0 {
		if len(texts) == 0 {
			if !isVoidHTML(name) {
				return pad + "<" + name + attrs + "></" + name + ">"
			}
			return pad + "<" + name + attrs + "/>"
		}
		return pad + "<" + name + attrs + ">" + escapeText(strings.Join(texts, " ")) + "</" + name + ">"
	}
	var b strings.Builder
	b.WriteString(pad + "<" + name + attrs + ">")
	for _, t := range texts {
		b.WriteString(escapeText(t))
	}
	for _, e := range elems {
		b.WriteByte('\n')
		b.WriteString(formatHTMLNode(e, depth+1, unit))
	}
	b.WriteString("\n" + pad + "</" + name + ">")
	return b.String()
}

func isVoidHTML(name string) bool {
	switch name {
	case "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr":
		return true
	default:
		return false
	}
}

type selectorStep struct {
	raw    string
	direct bool
}

func parseSelector(q string) []selectorStep {
	var steps []selectorStep
	var b strings.Builder
	directNext := false
	for _, r := range q {
		switch r {
		case '>':
			if strings.TrimSpace(b.String()) != "" {
				steps = append(steps, selectorStep{raw: strings.TrimSpace(b.String()), direct: directNext})
				b.Reset()
			}
			directNext = true
		case ' ', '\t', '\n':
			if strings.TrimSpace(b.String()) != "" {
				steps = append(steps, selectorStep{raw: strings.TrimSpace(b.String()), direct: directNext})
				b.Reset()
				directNext = false
			}
		default:
			b.WriteRune(r)
		}
	}
	if strings.TrimSpace(b.String()) != "" {
		steps = append(steps, selectorStep{raw: strings.TrimSpace(b.String()), direct: directNext})
	}
	if len(steps) > 0 {
		steps[0].direct = false
	}
	return steps
}

func queryHTML(root *HNode, q string) []*HNode {
	steps := parseSelector(q)
	if len(steps) == 0 {
		return nil
	}
	cur := []*HNode{root}
	for _, st := range steps {
		var next []*HNode
		for _, n := range cur {
			if st.direct {
				for _, c := range n.Children {
					if matchHTML(c, st.raw) {
						next = append(next, c)
					}
				}
			} else {
				var walk func(*HNode)
				walk = func(x *HNode) {
					if x.Name != "__root__" && matchHTML(x, st.raw) {
						next = append(next, x)
					}
					for _, c := range x.Children {
						walk(c)
					}
				}
				walk(n)
			}
		}
		cur = next
	}
	return cur
}

func matchHTML(n *HNode, s string) bool {
	if s == "*" {
		return true
	}
	tag := s
	id := ""
	cls := ""
	if strings.HasPrefix(s, "#") {
		tag = ""
		id = s[1:]
	} else if strings.HasPrefix(s, ".") {
		tag = ""
		cls = s[1:]
	} else if i := strings.Index(s, "#"); i >= 0 {
		tag, id = s[:i], s[i+1:]
	} else if i := strings.Index(s, "."); i >= 0 {
		tag, cls = s[:i], s[i+1:]
	}
	if tag != "" && n.Name != tag {
		return false
	}
	if id != "" {
		v, ok := hAttr(n, "id")
		if !ok || v != id {
			return false
		}
	}
	if cls != "" {
		v, ok := hAttr(n, "class")
		if !ok {
			return false
		}
		for _, part := range strings.Fields(v) {
			if part == cls {
				return true
			}
		}
		return false
	}
	return true
}
