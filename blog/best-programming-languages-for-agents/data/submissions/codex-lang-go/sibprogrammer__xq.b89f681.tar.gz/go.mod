module xqreimpl

go 1.21
