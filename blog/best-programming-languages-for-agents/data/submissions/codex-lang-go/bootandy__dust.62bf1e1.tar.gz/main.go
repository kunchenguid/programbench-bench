package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type options struct {
	depth        int
	lines        int
	fullPaths    bool
	deref        bool
	apparent     bool
	reverse      bool
	noBars       bool
	barsRight    bool
	screen       bool
	skipTotal    bool
	fileCount    bool
	ignoreHidden bool
	onlyDir      bool
	onlyFile     bool
	jsonOut      bool
	printErrors  bool
	fileTypes    bool
	outFmt       string
	minSize      int64
	filter       *regexp.Regexp
	invert       []*regexp.Regexp
	ignoreNames  map[string]bool
	collapse     map[string]bool
	timeMode     string
	timeKind     byte
	paths        []string
}

type node struct {
	Name     string  `json:"name"`
	Path     string  `json:"-"`
	Size     int64   `json:"-"`
	Depth    int     `json:"-"`
	IsDir    bool    `json:"-"`
	IsLink   bool    `json:"-"`
	Children []*node `json:"children"`
}

type jsonNode struct {
	Size     string     `json:"size"`
	Name     string     `json:"name"`
	Children []jsonNode `json:"children"`
}

const helpShort = `Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter
  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them
  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -C, --force-colors               Force colors print
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -B, --bars-on-right              percent bars moved to right side of screen
  -z, --min-size <MIN_SIZE>        Minimum size file to include in output
  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)
      --skip-total                 No total row will be displayed
  -f, --filecount                  Directory 'size' is number of child files instead of disk size
  -i, --ignore-hidden              Do not display hidden files
  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v "\.png$"
  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e "\.png$"
  -t, --file-types                 show only these file types
  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width
  -P, --no-progress                Disable the progress indication
      --print-errors               Print path with errors
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]
  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)
  -j, --output-json                Output the directory tree as json to the current directory
  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago
  -A, --atime <ATIME>              just like -mtime, but based on file access time
  -y, --ctime <CTIME>              just like -mtime, but based on file change time
      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use '-' for stdin)
      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use '-' for stdin)
      --collapse <COLLAPSE>        Keep these directories collapsed
  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version`

func main() {
	opt, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if len(opt.paths) == 0 {
		opt.paths = []string{"."}
	}
	var roots []*node
	exitCode := 0
	for _, p := range opt.paths {
		n, err := build(p, 0, opt)
		if err != nil {
			fmt.Fprintf(os.Stderr, "No such file or directory: %s\n", p)
			exitCode = 1
			continue
		}
		if n != nil {
			roots = append(roots, n)
		}
	}
	if len(roots) == 0 {
		os.Exit(exitCode)
	}
	root := roots[0]
	if len(roots) > 1 {
		root = &node{Name: "(total)", Path: "(total)", IsDir: true, Children: roots}
		for _, r := range roots {
			r.Depth = 1
			root.Size += r.Size
		}
	}
	if opt.fileTypes {
		root = groupTypes(root, opt)
	}
	if opt.jsonOut {
		j := toJSON(root, opt)
		b, _ := json.Marshal(j)
		fmt.Println(string(b))
		os.Exit(exitCode)
	}
	printOutput(root, opt)
	os.Exit(exitCode)
}

func parseArgs(args []string) (*options, error) {
	o := &options{depth: -1, lines: 0, outFmt: "", ignoreNames: map[string]bool{}, collapse: map[string]bool{}}
	need := func(i *int) (string, error) {
		if *i+1 >= len(args) {
			return "", fmt.Errorf("error: a value is required")
		}
		*i++
		return args[*i], nil
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			o.paths = append(o.paths, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			o.paths = append(o.paths, a)
			continue
		}
		key, val, hasVal := strings.Cut(a, "=")
		readVal := func() (string, error) {
			if hasVal {
				return val, nil
			}
			return need(&i)
		}
		switch key {
		case "-h", "--help":
			fmt.Println(helpShort)
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("Dust 1.2.3")
			os.Exit(0)
		case "-d", "--depth":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.depth, _ = strconv.Atoi(v)
		case "-T", "--threads", "--config", "-S", "--stack-size", "-w", "--terminal-width":
			if _, e := readVal(); e != nil {
				return nil, e
			}
		case "-n", "--number-of-lines":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.lines, _ = strconv.Atoi(v)
		case "-p", "--full-paths":
			o.fullPaths = true
		case "-X", "--ignore-directory":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.ignoreNames[v] = true
			o.ignoreNames[filepath.Base(v)] = true
		case "-I", "--ignore-all-in-file":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			loadRegexFile(v, &o.invert)
		case "-L", "--dereference-links":
			o.deref = true
		case "-x", "--limit-filesystem", "-c", "--no-colors", "-C", "--force-colors", "-P", "--no-progress", "--print-errors":
			if key == "--print-errors" {
				o.printErrors = true
			}
		case "-s", "--apparent-size":
			o.apparent = true
		case "-r", "--reverse":
			o.reverse = true
		case "-b", "--no-percent-bars":
			o.noBars = true
		case "-B", "--bars-on-right":
			o.barsRight = true
		case "-z", "--min-size":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.minSize = parseSize(v)
		case "-R", "--screen-reader":
			o.screen = true
		case "--skip-total":
			o.skipTotal = true
		case "-f", "--filecount":
			o.fileCount = true
		case "-i", "--ignore-hidden":
			o.ignoreHidden = true
		case "-v", "--invert-filter":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			r, e := regexp.Compile(v)
			if e == nil {
				o.invert = append(o.invert, r)
			}
		case "-e", "--filter":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			r, e := regexp.Compile(v)
			if e != nil {
				return nil, e
			}
			o.filter = r
		case "-t", "--file-types":
			o.fileTypes = true
		case "-D", "--only-dir":
			o.onlyDir = true
		case "-F", "--only-file":
			o.onlyFile = true
		case "-o", "--output-format":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			if !validFmt(v) {
				return nil, fmt.Errorf("error: invalid value '%s' for '--output-format <FORMAT>'\n  [possible values: si, b, k, m, g, t, kb, mb, gb, tb]", v)
			}
			o.outFmt = v
		case "-j", "--output-json":
			o.jsonOut = true
		case "-M", "--mtime":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.timeMode = v
			o.timeKind = 'm'
		case "-A", "--atime":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.timeMode = v
			o.timeKind = 'a'
		case "-y", "--ctime":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.timeMode = v
			o.timeKind = 'c'
		case "--files-from":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.paths = append(o.paths, readPathList(v, '\n')...)
		case "--files0-from":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.paths = append(o.paths, readPathList(v, 0)...)
		case "--collapse":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			o.collapse[v] = true
			o.collapse[filepath.Base(v)] = true
		case "-m", "--filetime":
			v, e := readVal()
			if e != nil {
				return nil, e
			}
			if v != "" {
				o.fileCount = false
				o.timeKind = v[0]
			}
		default:
			return nil, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [PATH]...\n\nFor more information, try '--help'.", a)
		}
	}
	return o, nil
}

func build(path string, depth int, o *options) (*node, error) {
	var info fs.FileInfo
	var err error
	if o.deref {
		info, err = os.Stat(path)
	} else {
		info, err = os.Lstat(path)
	}
	if err != nil {
		return nil, err
	}
	base := filepath.Base(path)
	if o.ignoreHidden && strings.HasPrefix(base, ".") && base != "." {
		return nil, nil
	}
	if o.ignoreNames[base] || o.ignoreNames[path] {
		return nil, nil
	}
	full, _ := filepath.Abs(path)
	if excluded(full, o) {
		return nil, nil
	}
	isDir := info.IsDir()
	isLink := info.Mode()&os.ModeSymlink != 0
	n := &node{Name: base, Path: full, IsDir: isDir, IsLink: isLink, Depth: depth}
	if o.fileCount {
		if !isDir {
			if includeFile(full, o) && !isLink {
				n.Size = 1
			}
			return n, nil
		}
	} else if o.timeKind != 0 && o.timeMode == "" {
		n.Size = info.ModTime().Unix()
	} else {
		if !(isDir && o.filter != nil) {
			n.Size = fileSize(info, o)
		}
	}
	if isDir {
		ents, err := os.ReadDir(path)
		if err != nil {
			if o.printErrors {
				fmt.Fprintln(os.Stderr, err)
			}
			return n, nil
		}
		for _, e := range ents {
			childPath := filepath.Join(path, e.Name())
			c, err := build(childPath, depth+1, o)
			if err != nil {
				if o.printErrors {
					fmt.Fprintln(os.Stderr, err)
				}
				continue
			}
			if c == nil {
				continue
			}
			if o.fileCount {
				n.Size += c.Size
			} else if o.timeKind != 0 && o.timeMode == "" {
				if c.Size > n.Size {
					n.Size = c.Size
				}
			} else {
				n.Size += c.Size
			}
			n.Children = append(n.Children, c)
		}
		sortChildren(n)
	} else if !includeFile(full, o) {
		return nil, nil
	}
	if o.timeMode != "" && !matchTime(info, o) && !isDir {
		return nil, nil
	}
	return n, nil
}

func fileSize(info fs.FileInfo, o *options) int64 {
	if o.apparent {
		return info.Size()
	}
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		return st.Blocks * 512
	}
	return info.Size()
}

func includeFile(path string, o *options) bool {
	if o.filter != nil && !o.filter.MatchString(path) {
		return false
	}
	return !excluded(path, o)
}

func excluded(path string, o *options) bool {
	for _, r := range o.invert {
		if r.MatchString(path) {
			return true
		}
	}
	return false
}

func sortChildren(n *node) {
	sort.SliceStable(n.Children, func(i, j int) bool {
		if n.Children[i].Size == n.Children[j].Size {
			return n.Children[i].Name < n.Children[j].Name
		}
		return n.Children[i].Size > n.Children[j].Size
	})
	for _, c := range n.Children {
		sortChildren(c)
	}
}

func flatten(n *node, o *options) []*node {
	var out []*node
	var walk func(*node)
	walk = func(x *node) {
		if o.depth >= 0 && x.Depth > o.depth {
			return
		}
		if o.reverse {
			if x.Size >= o.minSize && visible(x, o) {
				out = append(out, x)
			}
			if o.collapse[x.Name] || o.collapse[x.Path] {
				return
			}
			for _, c := range x.Children {
				walk(c)
			}
		} else {
			if !(o.collapse[x.Name] || o.collapse[x.Path]) {
				for i := len(x.Children) - 1; i >= 0; i-- {
					walk(x.Children[i])
				}
			}
			if x.Size >= o.minSize && visible(x, o) {
				out = append(out, x)
			}
		}
	}
	walk(n)
	if o.lines > 0 && len(out) > o.lines {
		if containsNode(out[:o.lines], n) {
			out = out[:o.lines]
		} else {
			out = append(out[:o.lines-1], n)
		}
	}
	return out
}

func visible(n *node, o *options) bool {
	if o.skipTotal && n.Depth == 0 {
		return false
	}
	if o.onlyDir && !n.IsDir {
		return false
	}
	if o.onlyFile && n.IsDir && n.Depth != 0 {
		return false
	}
	if o.filter != nil && n.Size == 0 && n.Depth != 0 {
		return false
	}
	return true
}

func printOutput(root *node, o *options) {
	rows := flatten(root, o)
	if o.screen {
		printScreen(rows, root.Size, o)
		return
	}
	printTree(rows, root.Size, o)
}

func printScreen(rows []*node, total int64, o *options) {
	names, sizes := 0, 0
	type row struct {
		name, size string
		depth      int
		pct        int
	}
	var rs []row
	for _, n := range rows {
		name := displayName(n, o)
		sz := formatSize(n.Size, o.outFmt, o.fileCount)
		pct := percent(n.Size, total)
		rs = append(rs, row{name, sz, n.Depth, pct})
		if len(name) > names {
			names = len(name)
		}
		if len(sz) > sizes {
			sizes = len(sz)
		}
	}
	for _, r := range rs {
		fmt.Printf("%-*s %d %*s %3d%%\n", names, r.name, r.depth, sizes, r.size, r.pct)
	}
}

func printTree(rows []*node, total int64, o *options) {
	sizes := 0
	for _, n := range rows {
		if l := len(formatSize(n.Size, o.outFmt, o.fileCount)); l > sizes {
			sizes = l
		}
	}
	for i, n := range rows {
		name := displayName(n, o)
		indent := strings.Repeat("  ", n.Depth)
		conn := "├── "
		if i == len(rows)-1 {
			conn = "└── "
		}
		line := fmt.Sprintf("%*s %s%s%s", sizes, formatSize(n.Size, o.outFmt, o.fileCount), indent, conn, name)
		if !o.noBars {
			line += fmt.Sprintf(" %3d%% %s", percent(n.Size, total), bar(percent(n.Size, total)))
		}
		fmt.Println(line)
	}
}

func displayName(n *node, o *options) string {
	if o.fullPaths {
		return n.Path
	}
	return n.Name
}

func percent(size, total int64) int {
	if total <= 0 {
		return 0
	}
	return int((size*100 + total/2) / total)
}

func bar(p int) string {
	if p <= 0 {
		return ""
	}
	w := p / 2
	if w < 1 {
		w = 1
	}
	if w > 50 {
		w = 50
	}
	return strings.Repeat("█", w)
}

func formatSize(size int64, mode string, count bool) string {
	if count {
		return strconv.FormatInt(size, 10)
	}
	switch mode {
	case "b":
		return fmt.Sprintf("%dB", size)
	case "k":
		return fmt.Sprintf("%dK", size/1024)
	case "m":
		return fmt.Sprintf("%dM", size/(1024*1024))
	case "g":
		return fmt.Sprintf("%dG", size/(1024*1024*1024))
	case "t":
		return fmt.Sprintf("%dT", size/(1024*1024*1024*1024))
	case "kb":
		return fmt.Sprintf("%dkB", size/1000)
	case "mb":
		return fmt.Sprintf("%dMB", size/(1000*1000))
	case "gb":
		return fmt.Sprintf("%dGB", size/(1000*1000*1000))
	case "tb":
		return fmt.Sprintf("%dTB", size/(1000*1000*1000*1000))
	case "si":
		return human(size, 1000, []string{"B", "K", "M", "G", "T"})
	default:
		return human(size, 1024, []string{"B", "K", "M", "G", "T"})
	}
}

func human(size int64, base float64, units []string) string {
	v := float64(size)
	u := 0
	for v >= base && u < len(units)-1 {
		v /= base
		u++
	}
	if u == 0 {
		return fmt.Sprintf("%d%s", size, units[u])
	}
	if v < 10 {
		return fmt.Sprintf("%.1f%s", v, units[u])
	}
	return fmt.Sprintf("%.0f%s", v, units[u])
}

func validFmt(s string) bool {
	for _, v := range []string{"si", "b", "k", "m", "g", "t", "kb", "mb", "gb", "tb"} {
		if s == v {
			return true
		}
	}
	return false
}

func parseSize(s string) int64 {
	s = strings.TrimSpace(strings.ToLower(s))
	if s == "" {
		return 0
	}
	mul := int64(1)
	for _, suf := range []struct {
		s string
		m int64
	}{{"kb", 1000}, {"mb", 1000 * 1000}, {"gb", 1000 * 1000 * 1000}, {"tb", 1000 * 1000 * 1000 * 1000}, {"k", 1024}, {"m", 1024 * 1024}, {"g", 1024 * 1024 * 1024}, {"t", 1024 * 1024 * 1024 * 1024}, {"b", 1}} {
		if strings.HasSuffix(s, suf.s) {
			mul = suf.m
			s = strings.TrimSuffix(s, suf.s)
			break
		}
	}
	f, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return 0
	}
	return int64(f * float64(mul))
}

func loadRegexFile(path string, out *[]*regexp.Regexp) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		t := strings.TrimSpace(sc.Text())
		if t == "" {
			continue
		}
		if r, err := regexp.Compile(t); err == nil {
			*out = append(*out, r)
		}
	}
}

func readPathList(path string, sep byte) []string {
	var data []byte
	var err error
	if path == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(path)
	}
	if err != nil {
		return nil
	}
	if sep == 0 {
		parts := strings.Split(string(data), "\x00")
		return cleanList(parts)
	}
	return cleanList(strings.Split(string(data), "\n"))
}

func cleanList(parts []string) []string {
	var out []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func groupTypes(root *node, o *options) *node {
	counts := map[string]int64{}
	var walk func(*node)
	walk = func(n *node) {
		if !n.IsDir && !n.IsLink {
			ext := filepath.Ext(n.Name)
			if ext == "" {
				ext = "(no extension)"
			}
			counts[ext] += n.Size
		}
		for _, c := range n.Children {
			walk(c)
		}
	}
	walk(root)
	total := int64(0)
	g := &node{Name: "(total)", Path: "(total)", IsDir: true}
	for k, v := range counts {
		total += v
		g.Children = append(g.Children, &node{Name: k, Path: k, Size: v, Depth: 1})
	}
	g.Size = total
	sortChildren(g)
	return g
}

func toJSON(n *node, o *options) jsonNode {
	j := jsonNode{Size: formatSize(n.Size, o.outFmt, o.fileCount), Name: n.Path, Children: []jsonNode{}}
	if n.Path == "(total)" {
		j.Name = "(total)"
	}
	for _, c := range n.Children {
		j.Children = append(j.Children, toJSON(c, o))
	}
	return j
}

func matchTime(info fs.FileInfo, o *options) bool {
	if o.timeMode == "" {
		return true
	}
	days := int(time.Since(info.ModTime()).Hours() / 24)
	s := o.timeMode
	if strings.HasPrefix(s, "+") {
		n, _ := strconv.Atoi(strings.TrimPrefix(s, "+"))
		return days > n
	}
	if strings.HasPrefix(s, "-") {
		n, _ := strconv.Atoi(strings.TrimPrefix(s, "-"))
		return days < n
	}
	n, err := strconv.Atoi(s)
	if err != nil {
		return true
	}
	return days == n
}

func containsNode(ns []*node, needle *node) bool {
	for _, n := range ns {
		if n == needle {
			return true
		}
	}
	return false
}

var _ = errors.New
