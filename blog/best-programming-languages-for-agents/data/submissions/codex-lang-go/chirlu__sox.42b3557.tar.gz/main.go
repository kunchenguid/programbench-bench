package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const versionLine = "SoX v14.4.2"

type Audio struct {
	Rate     int
	Channels int
	Bits     int
	Encoding string
	Type     string
	FileSize int64
	Samples  []float64
	Comments []string
}

type Fmt struct {
	Type     string
	Rate     int
	Channels int
	Bits     int
	Encoding string
	Volume   float64
}

type InFile struct {
	Name string
	Fmt  Fmt
}

var effectNames = map[string]bool{
	"allpass": true, "band": true, "bandpass": true, "bandreject": true, "bass": true, "bend": true, "biquad": true,
	"chorus": true, "channels": true, "compand": true, "contrast": true, "dcshift": true, "deemph": true, "delay": true,
	"dither": true, "divide": true, "divide+": true, "downsample": true, "earwax": true, "echo": true, "echos": true,
	"equalizer": true, "fade": true, "fir": true, "firfit": true, "firfit+": true, "flanger": true, "gain": true,
	"highpass": true, "hilbert": true, "ladspa": true, "loudness": true, "lowpass": true, "mcompand": true,
	"noiseprof": true, "noisered": true, "norm": true, "oops": true, "overdrive": true, "pad": true, "phaser": true,
	"pitch": true, "rate": true, "remix": true, "repeat": true, "reverb": true, "reverse": true, "riaa": true,
	"silence": true, "sinc": true, "speed": true, "splice": true, "stat": true, "stats": true, "stretch": true,
	"swap": true, "synth": true, "tempo": true, "treble": true, "tremolo": true, "trim": true, "upsample": true,
	"vad": true, "vol": true,
}

func main() {
	base := filepath.Base(os.Args[0])
	if strings.Contains(base, "soxi") {
		os.Exit(runSoxi(os.Args[1:]))
	}
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	if len(args) == 0 {
		printHelp(os.Stdout)
		fmt.Fprintf(os.Stderr, "%s FAIL sox: No input filenames specified\n", os.Args[0])
		return 1
	}
	for i, a := range args {
		switch a {
		case "-h", "--help":
			printHelp(os.Stdout)
			return 0
		case "--version":
			fmt.Fprintf(os.Stdout, "%s:      %s\n", os.Args[0], versionLine)
			return 0
		case "--i", "--info":
			return runSoxi(args[i+1:])
		case "--help-effect":
			if i+1 >= len(args) {
				return fail("sox: `--help-effect' requires an argument")
			}
			return helpEffect(args[i+1])
		case "--help-format":
			if i+1 >= len(args) {
				return fail("sox: `--help-format' requires an argument")
			}
			return helpFormat(args[i+1])
		}
	}

	inputs, outName, outFmt, effects, combine, rc := parseSox(args)
	if rc != 0 {
		return rc
	}
	if len(inputs) == 0 || outName == "" {
		printHelp(os.Stdout)
		fmt.Fprintf(os.Stderr, "%s FAIL sox: No input filenames specified\n", os.Args[0])
		return 1
	}
	var aud Audio
	if len(inputs) == 1 && inputs[0].Name == "-n" {
		aud = Audio{Rate: def(outFmt.Rate, 48000), Channels: def(outFmt.Channels, 1), Bits: def(outFmt.Bits, 32), Encoding: "Signed Integer PCM"}
	} else {
		for idx, in := range inputs {
			a, err := readAudio(in.Name, in.Fmt)
			if err != nil {
				return fail("%s: %s", in.Name, err)
			}
			if in.Fmt.Volume != 0 && in.Fmt.Volume != 1 {
				for i := range a.Samples {
					a.Samples[i] *= in.Fmt.Volume
				}
			}
			if idx == 0 {
				aud = a
			} else {
				aud = combineAudio(aud, a, combine)
			}
		}
	}
	if outFmt.Rate != 0 {
		aud.Rate = outFmt.Rate
	}
	if outFmt.Channels != 0 {
		aud = setChannels(aud, outFmt.Channels)
	}
	if outFmt.Bits != 0 {
		aud.Bits = outFmt.Bits
	}
	if outFmt.Encoding != "" {
		aud.Encoding = encName(outFmt.Encoding)
	}

	aud = applyEffects(aud, effects)
	if strings.EqualFold(outName, "-n") {
		return 0
	}
	if err := writeAudio(outName, aud, outFmt); err != nil {
		return fail("%s: %s", outName, err)
	}
	return 0
}

func parseSox(args []string) ([]InFile, string, Fmt, []string, string, int) {
	cur := Fmt{Volume: 1}
	var inputs []InFile
	var files []InFile
	combine := "concatenate"
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "-V") && a != "-v" {
			continue
		}
		if a == "--" {
			continue
		}
		switch a {
		case "-q", "--no-show-progress", "-S", "--show-progress", "-D", "--no-dither", "-G", "--guard", "--norm", "--clobber", "--no-clobber", "--ignore-length", "--no-glob", "--multi-threaded", "--single-threaded", "-R":
			continue
		case "-m":
			combine = "mix"
			continue
		case "-M":
			combine = "merge"
			continue
		case "-T":
			combine = "multiply"
			continue
		case "--combine":
			if i+1 < len(args) {
				combine = args[i+1]
				i++
			}
			continue
		case "--buffer", "--input-buffer", "--temp", "--effects-file", "--dft-min", "--play-rate-arg", "--plot", "--replay-gain", "-V", "--comment", "--add-comment", "--comment-file", "-C", "--compression":
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
			}
			continue
		case "-t", "--type":
			i++
			if i < len(args) {
				cur.Type = args[i]
			}
			continue
		case "-r", "--rate":
			i++
			if i < len(args) {
				cur.Rate = parseRate(args[i])
			}
			continue
		case "-c", "--channels":
			i++
			if i < len(args) {
				cur.Channels = atoi(args[i])
			}
			continue
		case "-b", "--bits":
			i++
			if i < len(args) {
				cur.Bits = atoi(args[i])
			}
			continue
		case "-e", "--encoding":
			i++
			if i < len(args) {
				cur.Encoding = args[i]
			}
			continue
		case "-v", "--volume":
			i++
			if i < len(args) {
				cur.Volume = atof(args[i], 1)
			}
			continue
		case "-L", "-B", "-x", "-N", "-X":
			continue
		}
		if strings.HasPrefix(a, "--") {
			fmt.Fprintf(os.Stderr, "%s WARN getopt: parameter not recognized from `%s'\n", os.Args[0], a)
			return nil, "", Fmt{}, nil, combine, fail("sox: invalid option")
		}
		if effectNames[a] || strings.HasPrefix(a, "input") || strings.HasPrefix(a, "output") {
			if len(files) == 0 {
				return nil, "", Fmt{}, nil, combine, fail("sox: No input filenames specified")
			}
			inputs = files[:len(files)-1]
			return inputs, files[len(files)-1].Name, files[len(files)-1].Fmt, args[i:], combine, 0
		}
		files = append(files, InFile{Name: a, Fmt: cur})
		cur = Fmt{Volume: 1}
	}
	if len(files) >= 2 {
		inputs = files[:len(files)-1]
		return inputs, files[len(files)-1].Name, files[len(files)-1].Fmt, nil, combine, 0
	}
	return files, "", Fmt{}, nil, combine, 0
}

func runSoxi(args []string) int {
	if len(args) == 0 {
		fmt.Fprintf(os.Stderr, "%s FAIL soxi: missing filename\n", os.Args[0])
		return 1
	}
	total := false
	mode := ""
	var files []string
	for _, a := range args {
		if a == "-T" {
			total = true
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) >= 2 && mode == "" {
			for _, ch := range a[1:] {
				if strings.ContainsRune("trcsdDbBpea", ch) {
					mode = string(ch)
				}
			}
			continue
		}
		files = append(files, a)
	}
	var auds []Audio
	for _, f := range files {
		a, err := readAudio(f, Fmt{})
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s FAIL formats: can't open input file `%s': %s\n", os.Args[0], f, err)
			return 1
		}
		auds = append(auds, a)
		if mode == "" {
			printInfo(f, a)
		} else if !total {
			printSoxiValue(mode, a)
		}
	}
	if total && mode != "" && len(auds) > 0 {
		sum := auds[0]
		for _, a := range auds[1:] {
			sum.Samples = append(sum.Samples, make([]float64, frames(a))...)
		}
		printSoxiValue(mode, sum)
	}
	return 0
}

func readAudio(name string, f Fmt) (Audio, error) {
	if name == "-n" {
		return Audio{Rate: def(f.Rate, 48000), Channels: def(f.Channels, 1), Bits: def(f.Bits, 32), Encoding: "Signed Integer PCM"}, nil
	}
	var data []byte
	var err error
	if name == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(name)
	}
	if err != nil {
		return Audio{}, err
	}
	fileSize := int64(len(data))
	typ := strings.ToLower(f.Type)
	if typ == "" {
		typ = inferType(name, data)
	}
	switch typ {
	case "wav", "wavpcm":
		a, err := readWAV(data)
		a.Type = "wav"
		a.FileSize = fileSize
		return a, err
	case "au", "snd":
		a, err := readAU(data)
		a.Type = "au"
		a.FileSize = fileSize
		return a, err
	case "raw", "s16", "s1", "s8", "u8", "u1", "sb", "ub":
		a := readRaw(data, f)
		a.Type = "raw"
		a.FileSize = fileSize
		return a, nil
	default:
		if strings.HasPrefix(string(data), "RIFF") {
			a, err := readWAV(data)
			a.Type = "wav"
			a.FileSize = fileSize
			return a, err
		}
		a := readRaw(data, f)
		a.Type = typ
		a.FileSize = fileSize
		return a, nil
	}
}

func readWAV(b []byte) (Audio, error) {
	if len(b) < 44 || string(b[:4]) != "RIFF" || string(b[8:12]) != "WAVE" {
		return Audio{}, errors.New("WAVE: RIFF header not found")
	}
	pos := 12
	var fmtCode uint16 = 1
	rate, ch, bits := 0, 0, 0
	var pcm []byte
	comments := []string{}
	for pos+8 <= len(b) {
		id := string(b[pos : pos+4])
		sz := int(binary.LittleEndian.Uint32(b[pos+4 : pos+8]))
		pos += 8
		if pos+sz > len(b) {
			sz = len(b) - pos
		}
		chunk := b[pos : pos+sz]
		switch id {
		case "fmt ":
			if len(chunk) >= 16 {
				fmtCode = binary.LittleEndian.Uint16(chunk[0:2])
				ch = int(binary.LittleEndian.Uint16(chunk[2:4]))
				rate = int(binary.LittleEndian.Uint32(chunk[4:8]))
				bits = int(binary.LittleEndian.Uint16(chunk[14:16]))
			}
		case "data":
			pcm = chunk
		case "LIST":
			if len(chunk) > 4 {
				comments = append(comments, printable(chunk[4:])...)
			}
		}
		pos += sz
		if sz%2 == 1 {
			pos++
		}
	}
	if ch == 0 {
		ch = 1
	}
	if rate == 0 {
		rate = 8000
	}
	if bits == 0 {
		bits = 16
	}
	a := Audio{Rate: rate, Channels: ch, Bits: bits, Encoding: "Signed Integer PCM", Comments: comments}
	if fmtCode == 3 {
		a.Encoding = "Floating Point PCM"
	} else if bits == 8 {
		a.Encoding = "Unsigned Integer PCM"
	}
	a.Samples = decodePCM(pcm, bits, fmtCode, false)
	return a, nil
}

func readAU(b []byte) (Audio, error) {
	if len(b) < 24 || string(b[:4]) != ".snd" {
		return Audio{}, errors.New("AU header not found")
	}
	off := int(binary.BigEndian.Uint32(b[4:8]))
	size := int(binary.BigEndian.Uint32(b[8:12]))
	enc := int(binary.BigEndian.Uint32(b[12:16]))
	rate := int(binary.BigEndian.Uint32(b[16:20]))
	ch := int(binary.BigEndian.Uint32(b[20:24]))
	if off < 24 || off > len(b) {
		off = 24
	}
	end := len(b)
	if size > 0 && size != int(^uint32(0)) && off+size < end {
		end = off + size
	}
	bits := 16
	code := uint16(1)
	encName := "Signed Integer PCM"
	if enc == 2 {
		bits = 8
	} else if enc == 3 {
		bits = 16
	} else if enc == 4 {
		bits = 24
	} else if enc == 5 {
		bits = 32
	} else if enc == 6 {
		bits = 32
		code = 3
		encName = "Floating Point PCM"
	} else if enc == 1 {
		bits = 8
		encName = "u-law"
	}
	return Audio{Rate: rate, Channels: ch, Bits: bits, Encoding: encName, Samples: decodePCM(b[off:end], bits, code, true)}, nil
}

func readRaw(b []byte, f Fmt) Audio {
	bits := def(f.Bits, 16)
	rate := def(f.Rate, 8000)
	ch := def(f.Channels, 1)
	enc := encName(f.Encoding)
	if enc == "" {
		if bits == 8 {
			enc = "Unsigned Integer PCM"
		} else {
			enc = "Signed Integer PCM"
		}
	}
	var samples []float64
	if bits == 8 && strings.HasPrefix(enc, "Signed") {
		for _, x := range b {
			samples = append(samples, float64(int8(x))/128)
		}
	} else {
		samples = decodePCM(b, bits, 1, false)
	}
	return Audio{Rate: rate, Channels: ch, Bits: bits, Encoding: enc, Samples: samples}
}

func writeAudio(name string, a Audio, f Fmt) error {
	typ := strings.ToLower(f.Type)
	if typ == "" {
		typ = strings.ToLower(strings.TrimPrefix(filepath.Ext(name), "."))
	}
	if typ == "" {
		typ = "wav"
	}
	var data []byte
	var err error
	switch typ {
	case "raw", "s16", "s8", "u8", "sb", "ub":
		data = encodePCM(a.Samples, def(a.Bits, 16), false)
	case "au", "snd":
		data = writeAU(a)
	default:
		data = writeWAV(a)
	}
	if name == "-" {
		_, err = os.Stdout.Write(data)
	} else {
		err = os.WriteFile(name, data, 0644)
	}
	return err
}

func decodePCM(b []byte, bits int, fmtCode uint16, big bool) []float64 {
	var out []float64
	var order binary.ByteOrder = binary.LittleEndian
	if big {
		order = binary.BigEndian
	}
	if fmtCode == 3 && bits == 32 {
		for i := 0; i+4 <= len(b); i += 4 {
			out = append(out, float64(math.Float32frombits(order.Uint32(b[i:i+4]))))
		}
		return out
	}
	switch bits {
	case 8:
		for _, x := range b {
			out = append(out, (float64(x)-128)/128)
		}
	case 24:
		for i := 0; i+3 <= len(b); i += 3 {
			var v int32
			if big {
				v = int32(b[i])<<16 | int32(b[i+1])<<8 | int32(b[i+2])
			} else {
				v = int32(b[i]) | int32(b[i+1])<<8 | int32(b[i+2])<<16
			}
			if v&0x800000 != 0 {
				v |= ^0xffffff
			}
			out = append(out, float64(v)/8388608)
		}
	case 32:
		for i := 0; i+4 <= len(b); i += 4 {
			out = append(out, float64(int32(order.Uint32(b[i:i+4])))/2147483648)
		}
	default:
		for i := 0; i+2 <= len(b); i += 2 {
			out = append(out, float64(int16(order.Uint16(b[i:i+2])))/32768)
		}
	}
	return out
}

func encodePCM(s []float64, bits int, big bool) []byte {
	var buf bytes.Buffer
	var order binary.ByteOrder = binary.LittleEndian
	if big {
		order = binary.BigEndian
	}
	for _, v := range s {
		if v > 1 {
			v = 1
		}
		if v < -1 {
			v = -1
		}
		switch bits {
		case 8:
			buf.WriteByte(byte(math.Round(v*127 + 128)))
		case 24:
			x := int32(math.Round(v * 8388607))
			if big {
				buf.Write([]byte{byte(x >> 16), byte(x >> 8), byte(x)})
			} else {
				buf.Write([]byte{byte(x), byte(x >> 8), byte(x >> 16)})
			}
		case 32:
			var tmp [4]byte
			order.PutUint32(tmp[:], uint32(int32(math.Round(v*2147483647))))
			buf.Write(tmp[:])
		default:
			var tmp [2]byte
			order.PutUint16(tmp[:], uint16(int16(math.Round(v*32767))))
			buf.Write(tmp[:])
		}
	}
	return buf.Bytes()
}

func writeWAV(a Audio) []byte {
	bits := def(a.Bits, 16)
	if bits != 8 && bits != 16 && bits != 24 && bits != 32 {
		bits = 16
	}
	pcm := encodePCM(a.Samples, bits, false)
	var buf bytes.Buffer
	buf.WriteString("RIFF")
	binary.Write(&buf, binary.LittleEndian, uint32(36+len(pcm)))
	buf.WriteString("WAVE")
	buf.WriteString("fmt ")
	binary.Write(&buf, binary.LittleEndian, uint32(16))
	binary.Write(&buf, binary.LittleEndian, uint16(1))
	binary.Write(&buf, binary.LittleEndian, uint16(def(a.Channels, 1)))
	binary.Write(&buf, binary.LittleEndian, uint32(def(a.Rate, 8000)))
	block := def(a.Channels, 1) * bits / 8
	binary.Write(&buf, binary.LittleEndian, uint32(def(a.Rate, 8000)*block))
	binary.Write(&buf, binary.LittleEndian, uint16(block))
	binary.Write(&buf, binary.LittleEndian, uint16(bits))
	buf.WriteString("data")
	binary.Write(&buf, binary.LittleEndian, uint32(len(pcm)))
	buf.Write(pcm)
	return buf.Bytes()
}

func writeAU(a Audio) []byte {
	bits := def(a.Bits, 16)
	enc := uint32(3)
	if bits == 8 {
		enc = 2
	} else if bits == 24 {
		enc = 4
	} else if bits == 32 {
		enc = 5
	}
	pcm := encodePCM(a.Samples, bits, true)
	var buf bytes.Buffer
	buf.WriteString(".snd")
	binary.Write(&buf, binary.BigEndian, uint32(24))
	binary.Write(&buf, binary.BigEndian, uint32(len(pcm)))
	binary.Write(&buf, binary.BigEndian, enc)
	binary.Write(&buf, binary.BigEndian, uint32(def(a.Rate, 8000)))
	binary.Write(&buf, binary.BigEndian, uint32(def(a.Channels, 1)))
	buf.Write(pcm)
	return buf.Bytes()
}

func combineAudio(a, b Audio, mode string) Audio {
	if b.Rate != a.Rate {
		b = resample(b, a.Rate)
	}
	if b.Channels != a.Channels {
		b = setChannels(b, a.Channels)
	}
	switch mode {
	case "mix", "mix-power":
		n := max(len(a.Samples), len(b.Samples))
		out := make([]float64, n)
		for i := 0; i < n; i++ {
			if i < len(a.Samples) {
				out[i] += a.Samples[i]
			}
			if i < len(b.Samples) {
				out[i] += b.Samples[i]
			}
		}
		if mode == "mix-power" {
			for i := range out {
				out[i] /= math.Sqrt(2)
			}
		}
		a.Samples = out
	case "merge":
		fa, fb := frames(a), frames(b)
		n := min(fa, fb)
		out := make([]float64, 0, n*(a.Channels+b.Channels))
		for i := 0; i < n; i++ {
			out = append(out, a.Samples[i*a.Channels:(i+1)*a.Channels]...)
			out = append(out, b.Samples[i*b.Channels:(i+1)*b.Channels]...)
		}
		a.Channels += b.Channels
		a.Samples = out
	case "multiply":
		n := min(len(a.Samples), len(b.Samples))
		for i := 0; i < n; i++ {
			a.Samples[i] *= b.Samples[i]
		}
		a.Samples = a.Samples[:n]
	default:
		a.Samples = append(a.Samples, b.Samples...)
	}
	return a
}

func applyEffects(a Audio, eff []string) Audio {
	for i := 0; i < len(eff); i++ {
		e := eff[i]
		switch e {
		case "synth":
			dur := 0.0
			if i+1 < len(eff) {
				dur = parseDuration(eff[i+1], a.Rate)
				i++
			}
			if dur <= 0 {
				dur = 1
			}
			wave := "sine"
			freq := 440.0
			for j := i + 1; j < len(eff); j++ {
				if isEffect(eff[j]) {
					break
				}
				if isWave(eff[j]) {
					wave = eff[j]
					i = j
					if j+1 < len(eff) {
						if f := parseFreq(eff[j+1]); f > 0 {
							freq = f
							i = j + 1
						}
					}
					break
				}
			}
			a = synth(a, dur, wave, freq)
		case "trim":
			if i+1 < len(eff) {
				start := parseDuration(eff[i+1], a.Rate)
				i++
				length := -1.0
				if i+1 < len(eff) && !isEffect(eff[i+1]) {
					length = parseDuration(eff[i+1], a.Rate)
					i++
				}
				a = trim(a, start, length)
			}
		case "reverse":
			a = reverse(a)
		case "channels":
			if i+1 < len(eff) {
				a = setChannels(a, atoi(eff[i+1]))
				i++
			}
		case "rate":
			if i+1 < len(eff) {
				a = resample(a, parseRate(eff[i+1]))
				i++
			}
		case "speed":
			if i+1 < len(eff) {
				factor := atof(eff[i+1], 1)
				if factor > 0 {
					a = resampleKeepRate(a, factor)
				}
				i++
			}
		case "vol":
			if i+1 < len(eff) {
				g := atof(eff[i+1], 1)
				for k := range a.Samples {
					a.Samples[k] *= g
				}
				i++
			}
		case "gain":
			if i+1 < len(eff) && (!strings.HasPrefix(eff[i+1], "-") || isNumber(eff[i+1])) {
				db := atof(eff[i+1], 0)
				g := math.Pow(10, db/20)
				for k := range a.Samples {
					a.Samples[k] *= g
				}
				i++
			}
		case "norm":
			a = normalize(a, 0.99)
		case "repeat":
			if i+1 < len(eff) {
				n := atoi(eff[i+1])
				orig := append([]float64(nil), a.Samples...)
				for r := 0; r < n; r++ {
					a.Samples = append(a.Samples, orig...)
				}
				i++
			}
		case "stat", "stats":
			printStats(a)
		default:
			for i+1 < len(eff) && !isEffect(eff[i+1]) {
				i++
			}
		}
	}
	return a
}

func synth(a Audio, dur float64, wave string, freq float64) Audio {
	rate := def(a.Rate, 48000)
	ch := def(a.Channels, 1)
	n := int(math.Round(dur * float64(rate)))
	out := make([]float64, n*ch)
	for i := 0; i < n; i++ {
		t := float64(i) / float64(rate)
		v := 0.0
		ph := 2 * math.Pi * freq * t
		switch wave {
		case "square":
			if math.Sin(ph) >= 0 {
				v = .5
			} else {
				v = -.5
			}
		case "triangle":
			v = math.Asin(math.Sin(ph)) * (1 / math.Pi)
		case "sawtooth", "saw":
			v = 2 * (freq*t - math.Floor(freq*t+0.5)) * .5
		default:
			v = math.Sin(ph) * .5
		}
		for c := 0; c < ch; c++ {
			out[i*ch+c] = v
		}
	}
	a.Rate = rate
	a.Channels = ch
	if a.Bits == 0 {
		a.Bits = 16
	}
	a.Samples = out
	return a
}

func trim(a Audio, start, length float64) Audio {
	s := int(start*float64(a.Rate)) * a.Channels
	if s < 0 {
		s = 0
	}
	if s > len(a.Samples) {
		s = len(a.Samples)
	}
	e := len(a.Samples)
	if length >= 0 {
		e = s + int(length*float64(a.Rate))*a.Channels
		if e > len(a.Samples) {
			e = len(a.Samples)
		}
	}
	a.Samples = append([]float64(nil), a.Samples[s:e]...)
	return a
}
func reverse(a Audio) Audio {
	ch := def(a.Channels, 1)
	for i, j := 0, frames(a)-1; i < j; i, j = i+1, j-1 {
		for c := 0; c < ch; c++ {
			a.Samples[i*ch+c], a.Samples[j*ch+c] = a.Samples[j*ch+c], a.Samples[i*ch+c]
		}
	}
	return a
}
func setChannels(a Audio, ch int) Audio {
	if ch <= 0 || ch == a.Channels {
		return a
	}
	old := def(a.Channels, 1)
	n := frames(a)
	out := make([]float64, n*ch)
	for i := 0; i < n; i++ {
		avg := 0.0
		for c := 0; c < old; c++ {
			avg += a.Samples[i*old+c]
		}
		avg /= float64(old)
		for c := 0; c < ch; c++ {
			if c < old {
				out[i*ch+c] = a.Samples[i*old+c]
			} else {
				out[i*ch+c] = avg
			}
		}
		if ch == 1 {
			out[i] = avg
		}
	}
	a.Channels = ch
	a.Samples = out
	return a
}
func resample(a Audio, rate int) Audio {
	if rate <= 0 || rate == a.Rate {
		return a
	}
	factor := float64(rate) / float64(a.Rate)
	a.Samples = sampleScale(a.Samples, a.Channels, factor)
	a.Rate = rate
	return a
}
func resampleKeepRate(a Audio, speed float64) Audio {
	if speed <= 0 {
		return a
	}
	a.Samples = sampleScale(a.Samples, a.Channels, 1/speed)
	return a
}
func sampleScale(in []float64, ch int, factor float64) []float64 {
	nf := int(math.Round(float64(len(in)/ch) * factor))
	if nf < 0 {
		nf = 0
	}
	out := make([]float64, nf*ch)
	for i := 0; i < nf; i++ {
		src := float64(i) / factor
		i0 := int(src)
		frac := src - float64(i0)
		if i0 >= len(in)/ch-1 {
			i0 = len(in)/ch - 1
			frac = 0
		}
		for c := 0; c < ch; c++ {
			v := in[i0*ch+c]
			if i0+1 < len(in)/ch {
				v += (in[(i0+1)*ch+c] - v) * frac
			}
			out[i*ch+c] = v
		}
	}
	return out
}
func normalize(a Audio, peak float64) Audio {
	m := 0.0
	for _, v := range a.Samples {
		if math.Abs(v) > m {
			m = math.Abs(v)
		}
	}
	if m > 0 {
		g := peak / m
		for i := range a.Samples {
			a.Samples[i] *= g
		}
	}
	return a
}

func printInfo(name string, a Audio) {
	fmt.Printf("\nInput File     : '%s'\n", name)
	fmt.Printf("Channels       : %d\n", def(a.Channels, 1))
	fmt.Printf("Sample Rate    : %d\n", def(a.Rate, 8000))
	fmt.Printf("Precision      : %d-bit\n", def(a.Bits, 16))
	fmt.Printf("Duration       : %s = %d samples ~ %.2g CDDA sectors\n", durString(a), frames(a), duration(a)*75)
	if st, err := os.Stat(name); err == nil {
		fmt.Printf("File Size      : %s\n", humanSize(st.Size()))
	}
	fmt.Printf("Bit Rate       : %s\n", bitRateString(a, name))
	fmt.Printf("Sample Encoding: %d-bit %s\n", def(a.Bits, 16), a.Encoding)
}
func printSoxiValue(mode string, a Audio) {
	switch mode {
	case "t":
		if a.Type != "" {
			fmt.Println(a.Type)
		} else {
			fmt.Println("wav")
		}
	case "r":
		fmt.Println(def(a.Rate, 8000))
	case "c":
		fmt.Println(def(a.Channels, 1))
	case "s":
		fmt.Println(frames(a))
	case "d":
		fmt.Println(shortDur(a))
	case "D":
		fmt.Printf("%.6f\n", duration(a))
	case "b", "p":
		fmt.Println(def(a.Bits, 16))
	case "B":
		fmt.Println(bitRateString(a, ""))
	case "e":
		fmt.Println(strings.TrimPrefix(a.Encoding, fmt.Sprintf("%d-bit ", a.Bits)))
	case "a":
		for _, c := range a.Comments {
			fmt.Println(c)
		}
	}
}
func printStats(a Audio) {
	minv, maxv, sum, ss := 0.0, 0.0, 0.0, 0.0
	if len(a.Samples) > 0 {
		minv = a.Samples[0]
		maxv = a.Samples[0]
	}
	for _, v := range a.Samples {
		if v < minv {
			minv = v
		}
		if v > maxv {
			maxv = v
		}
		sum += v
		ss += v * v
	}
	n := float64(max(1, len(a.Samples)))
	fmt.Fprintf(os.Stderr, "Samples read:            %d\nLength (seconds):      %.6f\nScaled by:         2147483647.0\nMaximum amplitude:     %.6f\nMinimum amplitude:     %.6f\nMidline amplitude:     %.6f\nMean    norm:          %.6f\nRMS     amplitude:     %.6f\n", frames(a), duration(a), maxv, minv, (maxv+minv)/2, math.Abs(sum)/n, math.Sqrt(ss/n))
}

func printHelp(w io.Writer) {
	fmt.Fprintf(w, "%s:      %s\n\nUsage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...\n\n", os.Args[0], versionLine)
	fmt.Fprint(w, "SPECIAL FILENAMES (infile, outfile):\n-                        Pipe/redirect input/output (stdin/stdout); may need -t\n-d, --default-device     Use the default audio device (where available)\n-n, --null               Use the `null' file handler; e.g. with synth effect\n-p, --sox-pipe           Alias for `-t sox -'\n\n")
	fmt.Fprint(w, "GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):\n--buffer BYTES           Set the size of all processing buffers (default 8192)\n--combine concatenate    Concatenate all input files (default for sox, rec)\n-D, --no-dither          Don't dither automatically\n-h, --help               Display version number and usage information\n--help-effect NAME       Show usage of effect NAME, or NAME=all for all\n--help-format NAME       Show info on format NAME, or NAME=all for all\n--i, --info              Behave as soxi(1)\n-m, --combine mix        Mix multiple input files (instead of concatenating)\n-M, --combine merge      Merge multiple input files (instead of concatenating)\n--version                Display version number of SoX and exit\n-V[LEVEL]                Increment or set verbosity level (default 2)\n\n")
	fmt.Fprint(w, "FORMAT OPTIONS (fopts):\n-v|--volume FACTOR       Input file volume adjustment factor (real number)\n-t|--type FILETYPE       File type of audio\n-e|--encoding ENCODING   Set encoding\n-b|--bits BITS           Encoded sample size in bits\n-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo\n-r|--rate RATE           Sample rate of audio\n\n")
	fmt.Fprint(w, "AUDIO FILE FORMATS: au raw wav wavpcm\nPLAYLIST FORMATS: m3u pls\nAUDIO DEVICE DRIVERS: oss ossdsp\n\nEFFECTS: channels gain norm rate repeat reverse speed stat stats synth trim vol\n")
}

func helpEffect(name string) int {
	fmt.Fprintf(os.Stdout, "%s:      %s\n\n", os.Args[0], versionLine)
	if name == "all" {
		for n := range effectNames {
			helpEffect(n)
		}
		return 0
	}
	if !effectNames[name] {
		fmt.Fprintf(os.Stdout, "Cannot find an effect called `%s'.\nEFFECTS: allpass band bandpass bandreject bass bend biquad chorus channels compand contrast dcshift deemph delay dither divide+ downsample earwax echo echos equalizer fade fir firfit+ flanger gain highpass hilbert input# ladspa loudness lowpass mcompand noiseprof noisered norm oops output# overdrive pad phaser pitch rate remix repeat reverb reverse riaa silence sinc speed splice stat stats stretch swap synth tempo treble tremolo trim upsample vad vol\n  * Deprecated effect    + Experimental effect    # LibSoX-only effect\n", name)
		return 1
	}
	usage := map[string]string{"trim": "trim {position}", "synth": "synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}", "rate": "rate [-q|-l|-m|-h|-v] [override-options] RATE[k]", "channels": "channels CHANNELS", "vol": "vol GAIN [TYPE [LIMITERGAIN]]", "gain": "gain [OPTION]... [dB]", "reverse": "reverse", "norm": "norm [dB-level]", "repeat": "repeat count"}
	if usage[name] == "" {
		usage[name] = name + " [options]"
	}
	fmt.Fprintf(os.Stdout, "Effect usage:\n\n%s\n\n", usage[name])
	return 0
}
func helpFormat(name string) int {
	fmt.Fprintf(os.Stdout, "%s:      %s\n", os.Args[0], versionLine)
	if name != "wav" && name != "raw" && name != "au" && name != "all" {
		fmt.Fprintf(os.Stdout, "Cannot find a format called `%s'.\nAUDIO FILE FORMATS: 8svx aif aifc aiff aiffc al amb au avr cdda cdr cvs cvsd cvu dat dvms f32 f4 f64 f8 fssd gsrt hcom htk ima ircam la lpc lpc10 lu maud nist prc raw s1 s16 s2 s24 s3 s32 s4 s8 sb sf sl sln smp snd sndr sndt sou sox sph sw txw u1 u16 u2 u24 u3 u32 u4 u8 ub ul uw vms voc vox wav wavpcm wve xa\nPLAYLIST FORMATS: m3u pls\nAUDIO DEVICE DRIVERS: oss ossdsp\n", name)
		return 1
	}
	fmt.Fprint(os.Stdout, "\nFormat: wav\nDescription: Microsoft audio format\nReads: yes\nWrites:\n  16-bit Signed Integer PCM (16-bit precision)\n")
	return 0
}
func fail(format string, args ...interface{}) int {
	fmt.Fprintf(os.Stderr, "%s FAIL "+format+"\n", append([]interface{}{os.Args[0]}, args...)...)
	return 1
}

func inferType(name string, b []byte) string {
	ext := strings.ToLower(strings.TrimPrefix(filepath.Ext(name), "."))
	if ext != "" {
		return ext
	}
	if len(b) >= 12 && string(b[:4]) == "RIFF" {
		return "wav"
	}
	if len(b) >= 4 && string(b[:4]) == ".snd" {
		return "au"
	}
	return "raw"
}
func encName(s string) string {
	s = strings.ToLower(s)
	switch s {
	case "signed", "signed-integer", "":
		return "Signed Integer PCM"
	case "unsigned", "unsigned-integer":
		return "Unsigned Integer PCM"
	case "floating-point", "float":
		return "Floating Point PCM"
	case "mu-law", "ulaw":
		return "u-law"
	case "a-law", "alaw":
		return "A-law"
	}
	return s
}
func parseRate(s string) int {
	mult := 1.0
	s = strings.TrimSpace(strings.ToLower(s))
	if strings.HasSuffix(s, "k") {
		mult = 1000
		s = strings.TrimSuffix(s, "k")
	}
	return int(math.Round(atof(s, 0) * mult))
}
func parseFreq(s string) float64 {
	s = strings.TrimPrefix(s, "%")
	if strings.HasPrefix(s, "-") {
		return 0
	}
	mult := 1.0
	if strings.HasSuffix(strings.ToLower(s), "k") {
		mult = 1000
		s = s[:len(s)-1]
	}
	return atof(s, 0) * mult
}
func parseDuration(s string, rate int) float64 {
	if strings.Contains(s, ":") {
		parts := strings.Split(s, ":")
		v := 0.0
		for _, p := range parts {
			v = v*60 + atof(p, 0)
		}
		return v
	}
	if strings.HasSuffix(s, "s") {
		return atof(strings.TrimSuffix(s, "s"), 0) / float64(rate)
	}
	return atof(s, 0)
}
func isWave(s string) bool {
	switch s {
	case "sine", "sin", "square", "triangle", "sawtooth", "saw", "noise", "brownnoise", "pinknoise":
		return true
	}
	return false
}
func isEffect(s string) bool {
	return effectNames[s] || strings.HasSuffix(s, "#") || strings.HasSuffix(s, "+")
}
func isNumber(s string) bool {
	_, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
	return err == nil
}
func frames(a Audio) int       { return len(a.Samples) / def(a.Channels, 1) }
func duration(a Audio) float64 { return float64(frames(a)) / float64(def(a.Rate, 8000)) }
func durString(a Audio) string { return fmt.Sprintf("%s", shortDur(a)) }
func shortDur(a Audio) string {
	d := duration(a)
	h := int(d) / 3600
	m := (int(d) % 3600) / 60
	sec := d - float64(h*3600+m*60)
	return fmt.Sprintf("%02d:%02d:%05.2f", h, m, sec)
}
func humanSize(n int64) string {
	if n < 1000 {
		return fmt.Sprintf("%d", n)
	}
	if n < 1000000 {
		return fmt.Sprintf("%.2fk", float64(n)/1000)
	}
	return fmt.Sprintf("%.2fM", float64(n)/1000000)
}
func bitRateString(a Audio, name string) string {
	br := float64(def(a.Rate, 8000) * def(a.Channels, 1) * def(a.Bits, 16))
	if name != "" {
		if st, err := os.Stat(name); err == nil && duration(a) > 0 {
			br = float64(st.Size()*8) / duration(a)
		}
	} else if a.FileSize > 0 && duration(a) > 0 {
		br = float64(a.FileSize*8) / duration(a)
	}
	if br >= 1000000 {
		return fmt.Sprintf("%.2fM", br/1000000)
	}
	return fmt.Sprintf("%.0fk", br/1000)
}
func printable(b []byte) []string {
	fields := strings.FieldsFunc(string(b), func(r rune) bool { return r == 0 || r == '\n' || r == '\r' })
	return fields
}
func atoi(s string) int { i, _ := strconv.Atoi(strings.TrimSpace(s)); return i }
func atof(s string, d float64) float64 {
	f, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
	if err != nil {
		return d
	}
	return f
}
func def(v, d int) int {
	if v == 0 {
		return d
	}
	return v
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
