module qjslite

go 1.21
