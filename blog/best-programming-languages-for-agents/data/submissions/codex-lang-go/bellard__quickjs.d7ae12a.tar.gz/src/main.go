package main

import (
    "bufio"
    "encoding/json"
    "errors"
    "fmt"
    "io/ioutil"
    "math"
    "os"
    "path/filepath"
    "strconv"
    "strings"
    "unicode"
)

type Value struct{ kind string; num float64; str string; b bool; arr []Value; obj map[string]Value }
var Undefined = Value{kind:"undefined"}
var Null = Value{kind:"null"}
func Num(n float64) Value { return Value{kind:"number", num:n} }
func Big(n float64) Value { return Value{kind:"bigint", num:n} }
func Str(s string) Value { return Value{kind:"string", str:s} }
func Bool(b bool) Value { return Value{kind:"bool", b:b} }
func Arr(a []Value) Value { return Value{kind:"array", arr:a} }
func Obj(o map[string]Value) Value { return Value{kind:"object", obj:o} }

func (v Value) truthy() bool { switch v.kind {case "undefined","null": return false; case "bool": return v.b; case "number","bigint": return v.num != 0 && !math.IsNaN(v.num); case "string": return v.str!=""; default: return true} }
func (v Value) String() string { switch v.kind {case "undefined": return "undefined"; case "null": return "null"; case "bool": if v.b {return "true"}; return "false"; case "string": return v.str; case "bigint": return fmt.Sprintf("%dn", int64(v.num)); case "array": parts:=[]string{}; for _,x:= range v.arr { parts=append(parts,x.String())}; return strings.Join(parts,","); case "object": return "[object Object]"; default: if math.Abs(v.num-math.Round(v.num))<1e-9 { return fmt.Sprintf("%d", int64(math.Round(v.num))) }; return strconv.FormatFloat(v.num,'g',-1,64)} }
func (v Value) JSON() interface{} { switch v.kind {case "undefined": return nil; case "null": return nil; case "bool": return v.b; case "string": return v.str; case "number","bigint": if math.Abs(v.num-math.Round(v.num))<1e-9 {return int64(math.Round(v.num))}; return v.num; case "array": a:=make([]interface{},len(v.arr)); for i,x:=range v.arr{a[i]=x.JSON()}; return a; case "object": m:=map[string]interface{}{}; for k,x:=range v.obj{m[k]=x.JSON()}; return m}; return nil }

type Interp struct{ vars map[string]Value; scriptArgs []string; std bool; dump bool }
func NewInterp(args []string, std bool) *Interp { return &Interp{vars:map[string]Value{}, scriptArgs:args, std:std} }

func main(){ os.Exit(run(os.Args[1:])) }
func run(args []string) int {
    includes:=[]string{}; evals:=[]string{}; std:=false; interactive:=false; dump:=false
    file:=""; scriptArgs:=[]string{}; sawEval:=false
    for i:=0;i<len(args);i++{ a:=args[i]
        switch a{
        case "-h","--help": printHelp(); return 1
        case "-q","--quit": return 0
        case "-e","--eval": if i+1>=len(args){fmt.Fprintln(os.Stderr,"qjs: missing expression for -e"); return 1}; i++; evals=append(evals,args[i]); sawEval=true
        case "-i","--interactive": interactive=true
        case "-m","--module","--script","--strict","-s","--strip-source","--no-unhandled-rejection":
        case "--std": std=true
        case "-d","--dump": dump=true
        case "-T","--trace":
        case "-I","--include": if i+1>=len(args){fmt.Fprintln(os.Stderr,"qjs: missing filename for -I"); return 1}; i++; includes=append(includes,args[i])
        case "--memory-limit","--stack-size": if i+1<len(args){i++}
        default:
            if strings.HasPrefix(a,"-") { printHelp(); fmt.Fprintf(os.Stderr,"qjs: unknown option '%s'\n",a); return 1 }
            if sawEval { scriptArgs=args[i:]; i=len(args); break }
            file=a; if i+1<len(args){scriptArgs=args[i+1:]}; i=len(args)
        }
    }
    if file!="" { scriptArgs=append([]string{file}, scriptArgs...) }
    in:=NewInterp(scriptArgs,std); in.dump=dump
    for _,f:=range includes{ if code,err:=os.ReadFile(f); err==nil { if err:=in.Exec(string(code), f); err!=nil {fmt.Fprintln(os.Stderr,err); return 1} } else {fmt.Fprintf(os.Stderr,"Could not load '%s'\n",f); return 1} }
    for _,e:=range evals{ if err:=in.Exec(e,"<cmdline>"); err!=nil {fmt.Fprintln(os.Stderr,err); return 1} }
    if file!=""{ b,err:=os.ReadFile(file); if err!=nil {fmt.Fprintf(os.Stderr,"Could not load '%s'\n",file); return 1}; if err:=in.Exec(string(b),file); err!=nil {fmt.Fprintln(os.Stderr,err); return 1} }
    if interactive || (file=="" && len(evals)==0){ repl(in) }
    if dump { fmt.Fprintln(os.Stderr, "QuickJS memory usage -- unavailable in this reimplementation") }
    return 0
}
func argsAfterEval(args []string) []string { for i,a:=range args{ if a=="-e"||a=="--eval"{ if i+2<len(args){return args[i+2:]} } }; return nil }
func printHelp(){ fmt.Print("QuickJS version 2025-09-13\nusage: qjs [options] [file [args]]\n-h  --help         list options\n-e  --eval EXPR    evaluate EXPR\n-i  --interactive  go to interactive mode\n-m  --module       load as ES6 module (default=autodetect)\n    --script       load as ES6 script (default=autodetect)\n    --strict       force strict mode\n-I  --include file include an additional file\n    --std          make 'std' and 'os' available to the loaded script\n-T  --trace        trace memory allocation\n-d  --dump         dump the memory usage stats\n    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)\n    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)\n    --no-unhandled-rejection  ignore unhandled promise rejections\n-s                    strip all the debug info\n    --strip-source    strip the source code\n-q  --quit         just instantiate the interpreter and quit\n") }
func repl(in *Interp){ sc:=bufio.NewScanner(os.Stdin); for { fmt.Print("qjs > "); if !sc.Scan(){break}; line:=sc.Text(); if strings.TrimSpace(line)==".exit"{break}; if err:=in.Exec(line,"<stdin>"); err!=nil{fmt.Fprintln(os.Stderr,err)} } }

func (in *Interp) Exec(code, name string) error { code=stripComments(code); for _,st:=range splitStatements(code){ if err:=in.execStmt(strings.TrimSpace(st), name); err!=nil{return err} }; return nil }
func stripComments(s string) string { var b strings.Builder; inStr:=rune(0); esc:=false; for i:=0;i<len(s);i++{ c:=rune(s[i]); if inStr!=0{b.WriteByte(s[i]); if esc{esc=false}else if c=='\\'{esc=true}else if c==inStr{inStr=0}; continue}; if c=='"'||c=='\''||c=='`'{inStr=c; b.WriteByte(s[i]); continue}; if c=='/'&&i+1<len(s)&&s[i+1]=='/'{ for i<len(s)&&s[i]!='\n'{i++}; b.WriteByte('\n'); continue}; if c=='/'&&i+1<len(s)&&s[i+1]=='*'{ i+=2; for i+1<len(s)&&!(s[i]=='*'&&s[i+1]=='/'){i++}; i++; continue}; b.WriteByte(s[i])}; return b.String() }
func splitStatements(s string) []string { out:=[]string{}; var b strings.Builder; depth:=0; inStr:=rune(0); esc:=false; for _,c:=range s{ if inStr!=0{b.WriteRune(c); if esc{esc=false}else if c=='\\'{esc=true}else if c==inStr{inStr=0}; continue}; switch c{case '"','\'', '`': inStr=c; b.WriteRune(c); case '(', '[', '{': depth++; b.WriteRune(c); case ')',']','}': if depth>0{depth--}; b.WriteRune(c); case ';','\n': if depth==0{ t:=strings.TrimSpace(b.String()); if t!=""{out=append(out,t)}; b.Reset()} else {b.WriteRune(c)}; default: b.WriteRune(c)} }; if t:=strings.TrimSpace(b.String()); t!=""{out=append(out,t)}; return out }
func (in *Interp) execStmt(st,name string) error { if st==""{return nil};
    if strings.HasPrefix(st,"throw "){ return fmt.Errorf("Error: %s\n    at %s", strings.Trim(strings.TrimPrefix(st,"throw "),";"), name) }
    for _,kw:=range []string{"let ","var ","const "}{ if strings.HasPrefix(st,kw){ return in.declare(strings.TrimSpace(st[len(kw):]), name) } }
    if strings.HasSuffix(st,"++"){ id:=strings.TrimSpace(strings.TrimSuffix(st,"++")); v:=in.vars[id]; v.num++; v.kind="number"; in.vars[id]=v; return nil }
    if strings.HasSuffix(st,"--"){ id:=strings.TrimSpace(strings.TrimSuffix(st,"--")); v:=in.vars[id]; v.num--; v.kind="number"; in.vars[id]=v; return nil }
    if strings.HasPrefix(st,"if") { return in.execIf(st,name) }
    if strings.HasPrefix(st,"for") { return in.execFor(st,name) }
    if idx:=topAssign(st); idx>0 { id:=strings.TrimSpace(st[:idx]); op:=st[idx:idx+1]; ex:=strings.TrimSpace(st[idx+1:]); if strings.HasSuffix(id,"+")||strings.HasSuffix(id,"-")||strings.HasSuffix(id,"*")||strings.HasSuffix(id,"/"){op=id[len(id)-1:]+"="; id=strings.TrimSpace(id[:len(id)-1])}; val,err:=in.Eval(ex); if err!=nil{return err}; if op!="="{ old:=in.vars[id]; val=applyOp(strings.TrimSuffix(op,"="),old,val)}; in.vars[id]=val; return nil }
    _,err:=in.Eval(st); return err }
func (in *Interp) declare(s,name string) error { parts:=splitTop(s, ','); for _,p:=range parts{ p=strings.TrimSpace(p); if p==""{continue}; if idx:=topAssign(p); idx>=0{ id:=strings.TrimSpace(p[:idx]); val,err:=in.Eval(strings.TrimSpace(p[idx+1:])); if err!=nil{return err}; in.vars[id]=val } else {in.vars[p]=Undefined} }; return nil }
func topAssign(s string) int { depth:=0; inStr:=rune(0); esc:=false; for i,c:=range s{ if inStr!=0{ if esc{esc=false}else if c=='\\'{esc=true}else if c==inStr{inStr=0}; continue}; switch c{case '"','\'', '`': inStr=c; case '(', '[', '{': depth++; case ')',']','}': depth--; case '=': if depth==0 { if i>0 && strings.ContainsRune("=!<>", rune(s[i-1])){continue}; if i+1<len(s)&&s[i+1]=='='{continue}; return i } } }; return -1 }
func (in *Interp) execIf(st,name string) error { a:=strings.Index(st,"("); b:=matchAt(st,a); if a<0||b<0{return nil}; cond,_:=in.Eval(st[a+1:b]); rest:=strings.TrimSpace(st[b+1:]); if cond.truthy(){ return in.execBlock(rest,name)}; if idx:=strings.Index(rest,"else"); idx>=0{return in.execBlock(strings.TrimSpace(rest[idx+4:]),name)}; return nil }
func (in *Interp) execFor(st,name string) error { a:=strings.Index(st,"("); b:=matchAt(st,a); if a<0||b<0{return nil}; parts:=splitTop(st[a+1:b],';'); if len(parts)==3{ in.execStmt(parts[0],name); body:=strings.TrimSpace(st[b+1:]); for guard:=0;guard<100000;guard++{ c,_:=in.Eval(parts[1]); if !c.truthy(){break}; if err:=in.execBlock(body,name); err!=nil{return err}; in.execStmt(parts[2],name)} }; return nil }
func (in *Interp) execBlock(s,name string) error { s=strings.TrimSpace(s); if strings.HasPrefix(s,"{")&&strings.HasSuffix(s,"}"){s=s[1:len(s)-1]}; return in.Exec(s,name) }
func matchAt(s string, pos int) int { if pos<0{return -1}; open:=s[pos]; close:=byte(')'); if open=='{'{close='}'}; if open=='['{close=']'}; d:=0; instr:=byte(0); esc:=false; for i:=pos;i<len(s);i++{ c:=s[i]; if instr!=0{ if esc{esc=false}else if c=='\\'{esc=true}else if c==instr{instr=0}; continue}; if c=='"'||c=='\''||c=='`'{instr=c; continue}; if c==open{d++}; if c==close{d--; if d==0{return i}}}; return -1 }

func (in *Interp) Eval(s string)(Value,error){ p:=parser{s:s,in:in}; v,err:=p.parseExpr(0); if err!=nil{return Undefined,err}; return v,nil }
type parser struct{ s string; pos int; in *Interp }
func (p *parser) skip(){ for p.pos<len(p.s)&&unicode.IsSpace(rune(p.s[p.pos])){p.pos++} }
func (p *parser) parseExpr(min int)(Value,error){ p.skip(); left,err:=p.parseUnary(); if err!=nil{return left,err}; for{ p.skip(); op:=p.peekOp(); prec:=preced(op); if prec<min{return left,nil}; p.pos+=len(op); right,err:=p.parseExpr(prec+1); if err!=nil{return left,err}; left=applyOp(op,left,right)} }
func preced(op string) int { switch op{case "||":return 1; case "&&":return 2; case "==","===","!=","!==","<",">","<=",">=":return 3; case "+","-":return 4; case "*","/","%":return 5}; return -1 }
func (p *parser) peekOp() string { ops:=[]string{"===","!==","<=",">=","==","!=","&&","||","+","-","*","/","%","<",">"}; for _,o:=range ops{ if strings.HasPrefix(p.s[p.pos:],o){return o} }; return "" }
func (p *parser) parseUnary()(Value,error){ p.skip(); for _,pre:=range []string{"typeof","!","-","+"}{ if strings.HasPrefix(p.s[p.pos:],pre) && (len(pre)==1 || p.pos+len(pre)==len(p.s) || !isIdent(rune(p.s[p.pos+len(pre)]))){ p.pos+=len(pre); v,err:=p.parseUnary(); if err!=nil{return v,err}; switch pre{case "typeof": return Str(jsType(v)),nil; case "!": return Bool(!v.truthy()),nil; case "-": v.num=-v.num; return v,nil; case "+": return Num(v.num),nil} } }; return p.parsePrimary() }
func (p *parser) parsePrimary()(Value,error){ p.skip(); if p.pos>=len(p.s){return Undefined,nil}; c:=p.s[p.pos];
    if c=='"'||c=='\''||c=='`'{ return p.parseString() }
    if c=='(' { p.pos++; v,err:=p.parseExpr(0); p.skip(); if p.pos<len(p.s)&&p.s[p.pos]==')'{p.pos++}; return v,err }
    if c=='[' { return p.parseArray() }
    if c=='{' { return p.parseObject() }
    if unicode.IsDigit(rune(c)) { return p.parseNumber() }
    id:=p.parseIdentChain(); return p.evalIdentCall(id) }
func (p *parser) parseString()(Value,error){ q:=p.s[p.pos]; p.pos++; var b strings.Builder; for p.pos<len(p.s){ c:=p.s[p.pos]; p.pos++; if c==q{break}; if c=='\\'&&p.pos<len(p.s){ n:=p.s[p.pos]; p.pos++; switch n{case 'n':b.WriteByte('\n'); case 't':b.WriteByte('\t'); case 'r':b.WriteByte('\r'); default:b.WriteByte(n)} } else {b.WriteByte(c)} }; return Str(b.String()),nil }
func (p *parser) parseNumber()(Value,error){ start:=p.pos; for p.pos<len(p.s)&&(unicode.IsDigit(rune(p.s[p.pos]))||p.s[p.pos]=='.'){p.pos++}; big:=false; if p.pos<len(p.s)&&p.s[p.pos]=='n'{big=true; p.pos++}; txt:=strings.TrimSuffix(p.s[start:p.pos],"n"); n,_:=strconv.ParseFloat(txt,64); if big{return Big(n),nil}; return Num(n),nil }
func (p *parser) parseArray()(Value,error){ p.pos++; parts:=[]Value{}; for{ p.skip(); if p.pos<len(p.s)&&p.s[p.pos]==']'{p.pos++; break}; v,err:=p.parseExpr(0); if err!=nil{return Undefined,err}; parts=append(parts,v); p.skip(); if p.pos<len(p.s)&&p.s[p.pos]==','{p.pos++; continue}; if p.pos<len(p.s)&&p.s[p.pos]==']'{p.pos++; break} }; return Arr(parts),nil }
func (p *parser) parseObject()(Value,error){ p.pos++; m:=map[string]Value{}; for{ p.skip(); if p.pos<len(p.s)&&p.s[p.pos]=='}'{p.pos++; break}; key:=""; if p.s[p.pos]=='"'||p.s[p.pos]=='\''{v,_:=p.parseString(); key=v.str}else{key=p.parseBareIdent()}; p.skip(); if p.pos<len(p.s)&&p.s[p.pos]==':'{p.pos++}; v,err:=p.parseExpr(0); if err!=nil{return Undefined,err}; m[key]=v; p.skip(); if p.pos<len(p.s)&&p.s[p.pos]==','{p.pos++; continue}; if p.pos<len(p.s)&&p.s[p.pos]=='}'{p.pos++; break} }; return Obj(m),nil }
func (p *parser) parseBareIdent() string { start:=p.pos; for p.pos<len(p.s)&&isIdent(rune(p.s[p.pos])){p.pos++}; return p.s[start:p.pos] }
func (p *parser) parseIdentChain() string { start:=p.pos; for p.pos<len(p.s){ c:=p.s[p.pos]; if isIdent(rune(c))||c=='.'||c=='['||c==']'||unicode.IsDigit(rune(c)){p.pos++; continue}; break}; if p.pos<len(p.s)&&p.s[p.pos]=='(' { end:=matchAt(p.s,p.pos); if end>=0{p.pos=end+1} }; return strings.TrimSpace(p.s[start:p.pos]) }
func isIdent(c rune) bool { return unicode.IsLetter(c)||unicode.IsDigit(c)||c=='_'||c=='$' }
func (p *parser) evalIdentCall(id string)(Value,error){ id=strings.TrimSpace(id); switch id{case "undefined": return Undefined,nil; case "null": return Null,nil; case "true": return Bool(true),nil; case "false": return Bool(false),nil; case "NaN": return Num(math.NaN()),nil}
    if strings.HasSuffix(id,")") { return p.call(id) }
    if id=="scriptArgs.length"{return Num(float64(len(p.in.scriptArgs))),nil}
    if strings.HasPrefix(id,"scriptArgs["){ inside:=id[len("scriptArgs["):strings.LastIndex(id,"]")]; n,_:=strconv.Atoi(inside); if n>=0&&n<len(p.in.scriptArgs){return Str(p.in.scriptArgs[n]),nil}; return Undefined,nil }
    if id=="os.platform"{return Str("linux"),nil}
    if strings.HasPrefix(id,"Math."){ if id=="Math.PI"{return Num(math.Pi),nil} }
    if v,ok:=p.in.vars[id]; ok{return v,nil}; return Undefined,nil }
func (p *parser) call(id string)(Value,error){ i:=strings.Index(id,"("); name:=strings.TrimSpace(id[:i]); argsText:=strings.TrimSpace(id[i+1:len(id)-1]); vals:=[]Value{}; if argsText!=""{ for _,a:=range splitTop(argsText, ','){ v,err:=p.in.Eval(a); if err!=nil{return Undefined,err}; vals=append(vals,v)} }
    switch name{
    case "console.log": ss:=[]string{}; for _,v:=range vals{ss=append(ss,v.String())}; fmt.Println(strings.Join(ss," ")); return Undefined,nil
    case "print": ss:=[]string{}; for _,v:=range vals{ss=append(ss,v.String())}; fmt.Println(strings.Join(ss," ")); return Undefined,nil
    case "JSON.stringify": if len(vals)>0{ b,_:=json.Marshal(vals[0].JSON()); return Str(string(b)),nil}; return Undefined,nil
    case "Number": if len(vals)>0{n,_:=strconv.ParseFloat(vals[0].String(),64); return Num(n),nil}; return Num(0),nil
    case "String": if len(vals)>0{return Str(vals[0].String()),nil}; return Str(""),nil
    case "parseInt": if len(vals)>0{n,_:=strconv.ParseInt(strings.TrimSpace(vals[0].String()),10,64); return Num(float64(n)),nil}; return Num(math.NaN()),nil
    case "parseFloat": if len(vals)>0{n,_:=strconv.ParseFloat(strings.TrimSpace(vals[0].String()),64); return Num(n),nil}; return Num(math.NaN()),nil
    case "Math.floor": return Num(math.Floor(vals[0].num)),nil; case "Math.ceil": return Num(math.Ceil(vals[0].num)),nil; case "Math.round": return Num(math.Round(vals[0].num)),nil; case "Math.abs": return Num(math.Abs(vals[0].num)),nil; case "Math.max": m:=math.Inf(-1); for _,v:=range vals{if v.num>m{m=v.num}}; return Num(m),nil; case "Math.min": m:=math.Inf(1); for _,v:=range vals{if v.num<m{m=v.num}}; return Num(m),nil
    case "std.getenv": if len(vals)>0{return Str(os.Getenv(vals[0].String())),nil}; return Undefined,nil
    case "std.puts": if len(vals)>0{fmt.Print(vals[0].String())}; return Undefined,nil
    case "std.printf": if len(vals)>0{fmt.Printf(vals[0].String(), toIface(vals[1:])...)}; return Undefined,nil
    case "std.sprintf": if len(vals)>0{return Str(fmt.Sprintf(vals[0].String(), toIface(vals[1:])...)),nil}; return Str(""),nil
    case "std.exit": code:=0; if len(vals)>0{code=int(vals[0].num)}; os.Exit(code)
    case "std.readFile","std.loadFile": if len(vals)>0{b,err:=os.ReadFile(vals[0].String()); if err!=nil{return Null,nil}; return Str(string(b)),nil}; return Null,nil
    case "os.getcwd": wd,_:=os.Getwd(); return Str(wd),nil
    case "os.chdir": if len(vals)>0{return Undefined,os.Chdir(vals[0].String())}; return Undefined,nil
    case "os.remove": if len(vals)>0{return Undefined,os.Remove(vals[0].String())}; return Undefined,nil
    case "os.realpath": if len(vals)>0{p,err:=filepath.Abs(vals[0].String()); if err==nil{return Str(p),nil}}; return Undefined,nil
    }
    if name=="load" && len(vals)>0{ b,err:=ioutil.ReadFile(vals[0].String()); if err!=nil{return Undefined,err}; return Undefined,p.in.Exec(string(b),vals[0].String()) }
    return Undefined,nil }
func toIface(vals []Value) []interface{} { out:=make([]interface{},len(vals)); for i,v:=range vals{ if v.kind=="number"||v.kind=="bigint"{ if math.Abs(v.num-math.Round(v.num))<1e-9{out[i]=int64(math.Round(v.num))}else{out[i]=v.num} }else{out[i]=v.String()} }; return out }
func jsType(v Value) string { switch v.kind{case "undefined":return "undefined"; case "null","array","object":return "object"; case "bool":return "boolean"; case "number":return "number"; case "bigint":return "bigint"; case "string":return "string"}; return "undefined" }
func applyOp(op string,a,b Value) Value { switch op{case "+": if a.kind=="string"||b.kind=="string"{return Str(a.String()+b.String())}; if a.kind=="bigint"||b.kind=="bigint"{return Big(a.num+b.num)}; return Num(a.num+b.num); case "-":return Num(a.num-b.num); case "*":return Num(a.num*b.num); case "/":return Num(a.num/b.num); case "%":return Num(math.Mod(a.num,b.num)); case "==","===":return Bool(a.String()==b.String()); case "!=","!==":return Bool(a.String()!=b.String()); case "<":return Bool(a.num<b.num); case ">":return Bool(a.num>b.num); case "<=":return Bool(a.num<=b.num); case ">=":return Bool(a.num>=b.num); case "&&": if a.truthy(){return b}; return a; case "||": if a.truthy(){return a}; return b}; return Undefined }
func splitTop(s string, sep rune) []string { out:=[]string{}; var b strings.Builder; depth:=0; instr:=rune(0); esc:=false; for _,c:=range s{ if instr!=0{b.WriteRune(c); if esc{esc=false}else if c=='\\'{esc=true}else if c==instr{instr=0}; continue}; switch c{case '"','\'', '`': instr=c; b.WriteRune(c); case '(','[','{': depth++; b.WriteRune(c); case ')',']','}': depth--; b.WriteRune(c); default: if c==sep&&depth==0{out=append(out,strings.TrimSpace(b.String())); b.Reset()}else{b.WriteRune(c)}} }; out=append(out,strings.TrimSpace(b.String())); return out }
var _ = errors.New
