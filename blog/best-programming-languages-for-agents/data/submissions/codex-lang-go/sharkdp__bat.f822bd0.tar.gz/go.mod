module rebat

go 1.21
