package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

const shortHelp = `A cat(1) clone with wings.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.

Options:
  -A, --show-all
          Show non-printable characters (space, tab, newline, ..).
      --nonprintable-notation <notation>
          Set notation for non-printable characters.
      --binary <behavior>
          How to treat binary content. (default: no-printing)
  -p, --plain...
          Show plain style (alias for '--style=plain').
  -l, --language <language>
          Set the language for syntax highlighting.
      --fallback-syntax <fallback-syntax>
          Set a fallback language for undetected syntaxes. [aliases: --fallback-language]
  -H, --highlight-line <N:M>
          Highlight lines N through M.
      --file-name <name>
          Specify the name to display for a file.
  -d, --diff
          Only show lines that have been added/removed/modified.
      --tabs <T>
          Set the tab width to T spaces.
      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).
  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.
  -n, --number
          Show line numbers (alias for '--style=numbers').
      --color <when>
          When to use colors (*auto*, never, always).
      --italic-text <when>
          Use italics in output (always, *never*)
      --decorations <when>
          When to show the decorations (*auto*, never, always).
      --paging <when>
          Specify when to use the pager, or use ` + "`-P`" + ` to disable (*auto*, never, always).
  -m, --map-syntax <glob:syntax>
          Use the specified syntax for files matching the glob pattern ('*.cpp:C++').
      --theme <theme>
          Set the color theme for syntax highlighting.
      --theme-light <theme>
          Sets the color theme for syntax highlighting used for light backgrounds.
      --theme-dark <theme>
          Sets the color theme for syntax highlighting used for dark backgrounds.
      --list-themes
          Display all supported highlighting themes.
  -s, --squeeze-blank
          Squeeze consecutive empty lines.
      --style <components>
          Comma-separated list of style elements to display (*default*, auto, full, plain, changes,
          header, header-filename, header-filesize, grid, rule, numbers, snip).
  -r, --line-range <N:M>
          Only print the lines from N to M.
  -L, --list-languages
          Display all supported languages.
  -u, --unbuffered
          Enable unbuffered input reading for streaming use cases.
      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]
  -E, --quiet-empty
          Produce no output when the input is empty.
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`

const longHelpPrefix = `A cat(1) clone with syntax highlighting and Git integration.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...
          File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from
          standard input.

Options:
`

var themes = []string{"1337", "Catppuccin Frappe", "Catppuccin Latte", "Catppuccin Macchiato", "Catppuccin Mocha", "Coldark-Cold", "Coldark-Dark", "DarkNeon", "Dracula", "GitHub", "Monokai Extended", "Monokai Extended Bright", "Monokai Extended Light", "Monokai Extended Origin", "Nord", "OneHalfDark", "OneHalfLight", "Solarized (dark)", "Solarized (light)", "Sublime Snazzy", "TwoDark", "Visual Studio Dark+", "ansi", "base16", "base16-256", "gruvbox-dark", "gruvbox-light", "zenburn"}

var languages = []string{
	"ActionScript:as", "Ada:adb,ads,gpr", "Apache Conf:envvars,htaccess,HTACCESS,httpd.conf", "AppleScript:applescript", "ARM Assembly:s,S", "AsciiDoc (Asciidoctor):adoc,ad,asciidoc", "AWK:awk", "Batch File:bat,cmd", "BibTeX:bib", "Bourne Again Shell (bash):sh,bash,zsh,ash,.bashrc,.profile", "C:c", "C#:cs,csx", "C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++", "Cabal:cabal", "Clojure:clj,cljc,cljs,edn", "CMake:CMakeLists.txt,cmake", "CoffeeScript:coffee", "Command Help:cmd-help,help", "CSS:css", "D:d,di", "Dart:dart", "Diff:diff,patch", "Dockerfile:Dockerfile,dockerfile,Containerfile", "DotENV:.env,.env.example", "Elixir:ex,exs", "Elm:elm", "Erlang:erl,hrl", "Fish:fish", "Fortran (Modern):f90,F90,f95,F95", "Git Config:gitconfig,.gitconfig,.gitmodules", "Git Ignore:exclude,gitignore,.gitignore", "Go:go", "Gomod:go.mod,go.work", "Gosum:go.sum", "GraphQL:graphql,graphqls,gql", "Graphviz (DOT):dot,DOT,gv", "Groff/troff:groff,troff,1,2,3,4,5,6,7,8,9", "HTML:html,htm,shtml,xhtml", "INI:ini,conf,cfg", "Java:java", "JavaScript:js,jsx,mjs,cjs", "JSON:json,webmanifest", "Julia:jl", "Kotlin:kt,kts", "LaTeX:tex,ltx", "Less:less", "Lua:lua", "Makefile:Makefile,makefile,mk", "Markdown:md,markdown,mdown", "Nim:nim", "Objective-C:m,mm", "Perl:pl,pm,pod", "PHP:php", "Plain Text:txt", "PowerShell:ps1,psm1", "Python:py,pyw,pyi", "R:r,R", "Ruby:rb,rbw", "Rust:rs", "Scala:scala,sbt", "SCSS:scss", "SQL:sql", "Swift:swift", "TOML:toml", "TypeScript:ts,tsx", "VimL:vim", "XML:xml,xsd,svg", "YAML:yaml,yml",
}

type options struct {
	files          []string
	showAll        bool
	caret          bool
	tabWidth       int
	number         bool
	style          map[string]bool
	decorations    string
	lineRanges     []lineRange
	squeeze        bool
	squeezeLimit   int
	quietEmpty     bool
	fileName       string
	stripANSI      string
	binaryAsText   bool
	chop           bool
	terminalWidth  int
	forceDecorated bool
}

type lineRange struct {
	start int
	end   int
	tail  int
}

type line struct {
	text       []byte
	hasNewline bool
	num        int
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		var exit exitError
		if errors.As(err, &exit) {
			os.Exit(exit.code)
		}
		os.Exit(1)
	}
}

type exitError struct{ code int }

func (e exitError) Error() string { return fmt.Sprint(e.code) }

func run(args []string) error {
	args = prependEnvArgs(args)
	if len(args) > 0 && args[0] == "cache" {
		return cacheCmd(args[1:])
	}
	opt := defaultOptions()
	if err := parseArgs(args, &opt); err != nil {
		return err
	}
	if len(opt.files) == 0 {
		opt.files = []string{"-"}
	}
	status := 0
	for i, name := range opt.files {
		if i > 0 && decorated(&opt) && (opt.style["header"] || opt.style["header-filename"]) {
			fmt.Println()
		}
		if err := printOne(name, &opt); err != nil {
			status = 1
			fmt.Fprintln(os.Stderr, "\033[31m[bat error]\033[0m: "+err.Error())
		}
	}
	if status != 0 {
		return exitError{status}
	}
	return nil
}

func defaultOptions() options {
	o := options{tabWidth: 4, decorations: "auto", style: map[string]bool{}, squeezeLimit: 1, stripANSI: "never", terminalWidth: 80}
	if s := os.Getenv("BAT_STYLE"); s != "" {
		setStyle(&o, s)
	}
	return o
}

func prependEnvArgs(args []string) []string {
	if s := os.Getenv("BAT_OPTS"); s != "" {
		fields := strings.Fields(s)
		return append(fields, args...)
	}
	return args
}

func parseArgs(args []string, opt *options) error {
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opt.files = append(opt.files, args[i+1:]...)
			break
		}
		if a == "-" {
			opt.files = append(opt.files, a)
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a, "=")
			need := func() string {
				if has {
					return val
				}
				i++
				if i >= len(args) {
					fmt.Fprintf(os.Stderr, "error: a value is required for '%s <value>' but none was supplied\n", name)
					os.Exit(2)
				}
				return args[i]
			}
			switch name {
			case "--help":
				fmt.Print(longHelp())
				return exitError{0}
			case "--version":
				fmt.Println("bat 0.26.1 (610b77c)")
				return exitError{0}
			case "--list-themes":
				for _, t := range themes {
					fmt.Println(t)
				}
				return exitError{0}
			case "--list-languages":
				for _, l := range languages {
					fmt.Println(l)
				}
				return exitError{0}
			case "--config-file":
				fmt.Println(configPath())
				return exitError{0}
			case "--generate-config-file":
				path := configPath()
				_ = os.MkdirAll(filepath.Dir(path), 0755)
				_ = os.WriteFile(path, []byte(defaultConfig()), 0644)
				fmt.Println("Success! Config file written to " + path)
				return exitError{0}
			case "--diagnostic":
				diagnostic()
				return exitError{0}
			case "--acknowledgements":
				fmt.Print(acknowledgements())
				return exitError{0}
			case "--show-all":
				opt.showAll = true
				opt.binaryAsText = true
			case "--nonprintable-notation":
				v := need()
				if v == "caret" {
					opt.caret = true
				} else if v == "unicode" {
					opt.caret = false
				} else {
					invalidChoice("--nonprintable-notation", "<notation>", v, []string{"unicode", "caret"})
				}
			case "--binary":
				v := need()
				if v == "as-text" {
					opt.binaryAsText = true
				} else if v == "no-printing" {
					opt.binaryAsText = false
				} else {
					invalidChoice("--binary", "<behavior>", v, []string{"no-printing", "as-text"})
				}
			case "--plain":
				setStyle(opt, "plain")
			case "--number":
				opt.number = true
				setStyle(opt, "numbers")
			case "--language", "--fallback-syntax", "--fallback-language", "--highlight-line", "--file-name", "--map-syntax", "--theme", "--theme-light", "--theme-dark", "--pager", "--ignored-suffix", "--diff-context", "--completion":
				v := need()
				if name == "--file-name" {
					opt.fileName = v
				}
				if name == "--completion" {
					completion(v)
					return exitError{0}
				}
			case "--diff", "--unbuffered", "--set-terminal-title":
			case "--tabs":
				v := need()
				n, err := strconv.Atoi(v)
				if err != nil {
					fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--tabs <T>': must be a number\n", v)
					return exitError{2}
				}
				opt.tabWidth = n
			case "--wrap":
				v := need()
				if !oneOf(v, []string{"auto", "never", "character", "word"}) {
					invalidChoice("--wrap", "<mode>", v, []string{"auto", "never", "character", "word"})
				}
			case "--chop-long-lines":
				opt.chop = true
			case "--terminal-width":
				v := need()
				n, _ := strconv.Atoi(strings.TrimLeft(v, "+"))
				if n > 0 {
					opt.terminalWidth = n
				}
			case "--color":
				v := need()
				if !oneOf(v, []string{"auto", "never", "always"}) {
					invalidChoice("--color", "<when>", v, []string{"auto", "never", "always"})
				}
			case "--italic-text":
				v := need()
				if !oneOf(v, []string{"always", "never"}) {
					invalidChoice("--italic-text", "<when>", v, []string{"always", "never"})
				}
			case "--decorations":
				v := need()
				if !oneOf(v, []string{"auto", "never", "always"}) {
					invalidChoice("--decorations", "<when>", v, []string{"auto", "never", "always"})
				}
				opt.decorations = v
			case "--force-colorization":
				opt.decorations = "always"
				opt.forceDecorated = true
			case "--paging":
				v := need()
				if !oneOf(v, []string{"auto", "never", "always"}) {
					invalidChoice("--paging", "<when>", v, []string{"auto", "never", "always"})
				}
			case "--squeeze-blank":
				opt.squeeze = true
			case "--squeeze-limit":
				v := need()
				n, err := strconv.Atoi(v)
				if err != nil {
					fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--squeeze-limit <squeeze-limit>': must be a number\n", v)
					return exitError{2}
				}
				opt.squeezeLimit = n
			case "--strip-ansi":
				v := need()
				if !oneOf(v, []string{"auto", "always", "never"}) {
					invalidChoice("--strip-ansi", "<when>", v, []string{"auto", "always", "never"})
				}
				opt.stripANSI = v
			case "--style":
				setStyle(opt, need())
			case "--line-range":
				r, err := parseRange(need())
				if err != nil {
					fmt.Fprintln(os.Stderr, "\033[31m[bat error]\033[0m: "+err.Error())
					return exitError{1}
				}
				opt.lineRanges = append(opt.lineRanges, r)
			case "--quiet-empty":
				opt.quietEmpty = true
			default:
				unexpected(a)
			}
			continue
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			for j := 1; j < len(a); j++ {
				c := a[j]
				rest := ""
				if j+1 < len(a) {
					rest = a[j+1:]
				}
				needShort := func(flag string) string {
					if rest != "" {
						j = len(a)
						return rest
					}
					i++
					if i >= len(args) {
						fmt.Fprintf(os.Stderr, "error: a value is required for '%s <value>' but none was supplied\n", flag)
						os.Exit(2)
					}
					return args[i]
				}
				switch c {
				case 'h':
					fmt.Print(shortHelp)
					return exitError{0}
				case 'V':
					fmt.Println("bat 0.26.1 (610b77c)")
					return exitError{0}
				case 'A':
					opt.showAll = true
					opt.binaryAsText = true
				case 'p':
					setStyle(opt, "plain")
				case 'n':
					opt.number = true
					setStyle(opt, "numbers")
				case 'l', 'H', 'm':
					_ = needShort("-" + string(c))
				case 'd', 'u', 'f':
					if c == 'f' {
						opt.decorations = "always"
						opt.forceDecorated = true
					}
				case 'S':
					opt.chop = true
				case 's':
					opt.squeeze = true
				case 'E':
					opt.quietEmpty = true
				case 'P': // paging never
				case 'r':
					r, err := parseRange(needShort("-r"))
					if err != nil {
						fmt.Fprintln(os.Stderr, "\033[31m[bat error]\033[0m: "+err.Error())
						return exitError{1}
					}
					opt.lineRanges = append(opt.lineRanges, r)
				case 'L':
					for _, l := range languages {
						fmt.Println(l)
					}
					return exitError{0}
				default:
					unexpected("-" + string(c))
				}
				if rest != "" {
					break
				}
			}
			continue
		}
		opt.files = append(opt.files, a)
	}
	return nil
}

func invalidChoice(name, metav, val string, choices []string) {
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s %s'\n  [possible values: %s]\n", val, name, metav, strings.Join(choices, ", "))
	os.Exit(2)
}

func unexpected(a string) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [FILE]...\n       executable <COMMAND>\n", a, a, a)
	os.Exit(2)
}

func oneOf(s string, vals []string) bool {
	for _, v := range vals {
		if s == v {
			return true
		}
	}
	return false
}

func setStyle(o *options, s string) {
	if s == "" {
		return
	}
	for _, part := range strings.Split(s, ",") {
		p := strings.TrimSpace(part)
		switch p {
		case "plain":
			o.style = map[string]bool{}
		case "numbers":
			o.style["numbers"] = true
		case "header":
			o.style["header"] = true
			o.style["header-filename"] = true
		case "default", "auto":
			o.style["numbers"] = true
			o.style["grid"] = true
			o.style["header-filename"] = true
		case "full":
			for _, k := range []string{"numbers", "grid", "header", "header-filename", "header-filesize", "rule", "changes", "snip"} {
				o.style[k] = true
			}
		case "changes", "grid", "rule", "header-filename", "header-filesize", "snip":
			o.style[p] = true
		default:
			if strings.HasPrefix(p, "+") {
				o.style[p[1:]] = true
				continue
			}
			if strings.HasPrefix(p, "-") {
				delete(o.style, p[1:])
				continue
			}
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--style <components>': Unknown style '%s'\n", p, p)
			os.Exit(2)
		}
	}
}

func decorated(o *options) bool {
	if o.number {
		return true
	}
	if o.decorations == "always" {
		return true
	}
	if o.decorations == "never" {
		return false
	}
	st, _ := os.Stdout.Stat()
	return (st.Mode() & os.ModeCharDevice) != 0
}

func printOne(name string, opt *options) error {
	var data []byte
	display := name
	if name == "-" {
		b, err := io.ReadAll(os.Stdin)
		if err != nil {
			return err
		}
		data = b
		if opt.fileName != "" {
			display = opt.fileName
		} else {
			display = "STDIN"
		}
	} else {
		info, err := os.Stat(name)
		if err != nil {
			if os.IsNotExist(err) {
				return fmt.Errorf("'%s': No such file or directory (os error 2)", name)
			}
			return fmt.Errorf("'%s': %v", name, err)
		}
		if info.IsDir() {
			return fmt.Errorf("'%s' is a directory.", name)
		}
		b, err := os.ReadFile(name)
		if err != nil {
			return fmt.Errorf("'%s': %v", name, err)
		}
		data = b
	}
	if opt.quietEmpty && len(data) == 0 {
		return nil
	}
	if !opt.binaryAsText && bytes.Contains(data, []byte{0}) {
		return fmt.Errorf("'%s': Binary content detected. Use '--binary=as-text' or '-A' to print binary content.", name)
	}
	lines := splitLines(data)
	lines = applyRanges(lines, opt.lineRanges)
	if opt.squeeze {
		lines = squeeze(lines, opt.squeezeLimit)
	}
	if opt.stripANSI == "always" {
		lines = stripLines(lines)
	}
	if opt.chop {
		lines = chopLines(lines, opt.terminalWidth)
	}
	if decorated(opt) && (opt.style["header"] || opt.style["header-filename"]) {
		fmt.Printf("File: %s\n", display)
	}
	useNumbers := opt.number || (decorated(opt) && opt.style["numbers"])
	for _, ln := range lines {
		if useNumbers {
			fmt.Printf("%4d ", ln.num)
		}
		out := ln.text
		if opt.showAll {
			fmt.Print(showAll(out, ln.hasNewline, opt))
			if ln.hasNewline {
				fmt.Print("\n")
			}
		} else {
			os.Stdout.Write(out)
			if ln.hasNewline {
				fmt.Print("\n")
			}
		}
	}
	return nil
}

func splitLines(data []byte) []line {
	if len(data) == 0 {
		return nil
	}
	var out []line
	start := 0
	num := 1
	for i, b := range data {
		if b == '\n' {
			end := i
			if end > start && data[end-1] == '\r' {
				end--
			}
			out = append(out, line{text: append([]byte(nil), data[start:end]...), hasNewline: true, num: num})
			start = i + 1
			num++
		}
	}
	if start < len(data) {
		out = append(out, line{text: append([]byte(nil), data[start:]...), num: num})
	}
	return out
}

func parseRange(s string) (lineRange, error) {
	if strings.HasPrefix(s, "-") && strings.HasSuffix(s, ":") {
		n, err := strconv.Atoi(strings.TrimSuffix(s[1:], ":"))
		if err != nil {
			return lineRange{}, err
		}
		return lineRange{tail: n}, nil
	}
	parts := strings.Split(s, ":")
	atoi := func(x string) (int, error) {
		if x == "" {
			return 0, nil
		}
		return strconv.Atoi(strings.TrimPrefix(x, "+"))
	}
	if len(parts) == 1 {
		n, err := strconv.Atoi(parts[0])
		if err != nil {
			return lineRange{}, err
		}
		return lineRange{start: n, end: n}, nil
	}
	if len(parts) == 2 {
		st, err := atoi(parts[0])
		if err != nil {
			return lineRange{}, err
		}
		if strings.HasPrefix(parts[1], "+") {
			cnt, err := strconv.Atoi(parts[1][1:])
			if err != nil {
				return lineRange{}, err
			}
			return lineRange{start: st, end: st + cnt}, nil
		}
		en, err := atoi(parts[1])
		if err != nil {
			return lineRange{}, err
		}
		return lineRange{start: st, end: en}, nil
	}
	if len(parts) == 3 {
		st, err := atoi(parts[0])
		if err != nil {
			return lineRange{}, err
		}
		en := st
		if parts[1] != "" {
			en, err = atoi(parts[1])
			if err != nil {
				return lineRange{}, err
			}
		}
		ctx, err := atoi(parts[2])
		if err != nil {
			return lineRange{}, err
		}
		return lineRange{start: st - ctx, end: en + ctx}, nil
	}
	return lineRange{}, fmt.Errorf("invalid digit found in string")
}

func applyRanges(lines []line, ranges []lineRange) []line {
	if len(ranges) == 0 {
		return lines
	}
	var out []line
	n := len(lines)
	for _, r := range ranges {
		st, en := r.start, r.end
		if r.tail > 0 {
			st = n - r.tail + 1
			en = n
		}
		if st == 0 {
			st = 1
		}
		if en == 0 {
			en = n
		}
		if st < 1 {
			st = 1
		}
		if en > n {
			en = n
		}
		if st > en || st > n {
			continue
		}
		out = append(out, lines[st-1:en]...)
	}
	return out
}

func squeeze(lines []line, limit int) []line {
	if limit < 0 {
		limit = 0
	}
	var out []line
	blank := 0
	for _, l := range lines {
		if len(l.text) == 0 {
			blank++
			if blank > limit {
				continue
			}
		} else {
			blank = 0
		}
		out = append(out, l)
	}
	return out
}

var ansiRe = regexp.MustCompile(`\x1b\[[0-9;?]*[ -/]*[@-~]`)

func stripLines(lines []line) []line {
	out := make([]line, len(lines))
	for i, l := range lines {
		out[i] = line{text: ansiRe.ReplaceAll(l.text, nil), hasNewline: l.hasNewline, num: l.num}
	}
	return out
}

func chopLines(lines []line, width int) []line {
	if width <= 0 {
		return lines
	}
	out := make([]line, len(lines))
	for i, l := range lines {
		t := l.text
		if len(t) > width {
			t = t[:width]
		}
		out[i] = line{text: t, hasNewline: l.hasNewline, num: l.num}
	}
	return out
}

func showAll(b []byte, hasNL bool, opt *options) string {
	var sb strings.Builder
	col := 0
	for _, c := range b {
		switch c {
		case '\t':
			if opt.caret {
				sb.WriteString("^I")
			} else {
				w := opt.tabWidth - (col % max(1, opt.tabWidth))
				if opt.tabWidth <= 0 {
					w = 1
				}
				if w < 2 {
					w = 2
				}
				sb.WriteString("├")
				for i := 0; i < w-2; i++ {
					sb.WriteString("─")
				}
				sb.WriteString("┤")
			}
		case ' ':
			if opt.caret {
				sb.WriteByte(' ')
			} else {
				sb.WriteString("·")
			}
		default:
			if c < 32 || c == 127 {
				if opt.caret {
					if c == 127 {
						sb.WriteString("^?")
					} else {
						sb.WriteByte('^')
						sb.WriteByte(c + 64)
					}
				} else if c == 127 {
					sb.WriteRune('\u2421')
				} else {
					sb.WriteRune(rune(0x2400 + int(c)))
				}
			} else {
				sb.WriteByte(c)
			}
		}
		col++
	}
	if hasNL {
		if opt.caret {
			sb.WriteString("^J")
		} else {
			sb.WriteRune('\u240A')
		}
	}
	return sb.String()
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func configPath() string {
	if p := os.Getenv("BAT_CONFIG_PATH"); p != "" {
		return p
	}
	if x := os.Getenv("XDG_CONFIG_HOME"); x != "" {
		return filepath.Join(x, "bat", "config")
	}
	home, _ := os.UserHomeDir()
	return filepath.Join(home, ".config", "bat", "config")
}

func defaultConfig() string {
	return "# This is `bat`s configuration file. Each line either contains a comment or\n# a command-line option that you want to pass to `bat` by default.\n#--theme=\"TwoDark\"\n#--paging=never\n#--style=\"numbers,changes,header\"\n"
}

func cacheCmd(args []string) error {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print("Modify the syntax-definition and theme cache\n\nUsage: executable cache [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help\n\n  -b, --build\n          Initialize (or update) the syntax/theme cache by loading from the source directory\n          (default: the configuration directory).\n\n  -c, --clear\n          Remove the cached syntax definitions and themes.\n\n      --source <dir>\n          Use a different directory to load syntaxes and themes from.\n\n      --target <dir>\n          Use a different directory to store the cached syntax and theme set.\n\n      --blank\n          Create completely new syntax and theme sets (instead of appending to the default sets).\n\n      --acknowledgements\n          Build acknowledgements.bin.\n")
			return nil
		}
	}
	home, _ := os.UserHomeDir()
	cache := filepath.Join(home, ".cache", "bat")
	_ = os.MkdirAll(cache, 0755)
	fmt.Printf("No themes were found in '%s', using the default set\n", filepath.Join(home, ".config", "bat", "themes"))
	fmt.Printf("No syntaxes were found in '%s', using the default set.\n", filepath.Join(home, ".config", "bat", "syntaxes"))
	fmt.Printf("Writing theme set to %s ... okay\n", filepath.Join(cache, "themes.bin"))
	fmt.Printf("Writing syntax set to %s ... okay\n", filepath.Join(cache, "syntaxes.bin"))
	fmt.Printf("Writing metadata to folder %s ... okay\n", cache)
	return nil
}

func longHelp() string {
	return longHelpPrefix + strings.TrimPrefix(shortHelp[strings.Index(shortHelp, "  -A"):], "")
}

func diagnostic() {
	fmt.Print("#### Software version\n\nbat 0.26.1 (610b77c)\n\n#### Operating system\n\n- OS: Linux\n\n#### Command-line\n\n```bash\n")
	fmt.Print(strings.Join(os.Args, " "))
	fmt.Print(" \n```\n\n#### Environment variables\n\n```bash\n")
	for _, k := range []string{"BAT_CACHE_PATH", "BAT_CONFIG_PATH", "BAT_OPTS", "BAT_PAGER", "BAT_PAGING", "BAT_STYLE", "BAT_TABS", "BAT_THEME", "BAT_WIDTH", "BAT_THEME_DARK", "BAT_THEME_LIGHT", "COLORTERM", "LANG", "LC_ALL", "LESS", "MANPAGER", "NO_COLOR", "PAGER", "SHELL", "TERM", "XDG_CACHE_HOME", "XDG_CONFIG_HOME"} {
		v := os.Getenv(k)
		if v == "" {
			v = "<not set>"
		}
		fmt.Printf("%s=%s\n", k, v)
	}
	fmt.Print("```\n")
}

func acknowledgements() string {
	return "Copyright (c) 2018-2021 bat-developers (https://github.com/sharkdp/bat).\n\nbat is made available under the terms of either the MIT License or the Apache\nLicense 2.0, at your option.\n\nSee the LICENSE-APACHE and LICENSE-MIT files for license details.\n"
}

func completion(shell string) {
	w := bufio.NewWriter(os.Stdout)
	defer w.Flush()
	fmt.Fprintf(w, "# completion script for %s\n", shell)
}
