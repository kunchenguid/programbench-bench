package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type Heading struct {
	Level       int
	Text        string
	Line        int
	Offset      int
	Content     string
	ContentFrom int
	ContentTo   int
	Children    []*Heading
	Parent      *Heading
}

type CodeBlock struct {
	Lang  string `json:"lang,omitempty"`
	Text  string `json:"text"`
	Start int    `json:"line"`
	Raw   string `json:"-"`
}

type Link struct {
	Text string `json:"text"`
	URL  string `json:"url"`
	Type string `json:"link_type"`
}

type Table struct {
	Raw string `json:"raw"`
}

type ListBlock struct {
	Raw string `json:"raw"`
}

type Blockquote struct {
	Raw string `json:"raw"`
}

type Document struct {
	Source      *string
	Text        string
	Lines       []string
	Headings    []*Heading
	Roots       []*Heading
	CodeBlocks  []CodeBlock
	Links       []Link
	Tables      []Table
	Lists       []ListBlock
	Blockquotes []Blockquote
	Words       int
}

type Options struct {
	List             bool
	Tree             bool
	Filter           string
	Level            int
	Output           string
	Section          string
	Count            bool
	Query            string
	QueryHelp        bool
	QueryOutput      string
	Version          bool
	Help             bool
	SetupCompletions bool
	Files            []string
	AtLine           *int
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if opts.Help {
		printShortHelp()
		return
	}
	if opts.Version {
		fmt.Println("treemd 0.5.7")
		return
	}
	if opts.QueryHelp {
		printQueryHelp()
		return
	}
	if opts.SetupCompletions {
		fmt.Println("Shell completion setup is not available in this build.")
		return
	}
	if opts.AtLine != nil {
		doc, err := readDocument(opts.Files)
		if err != nil {
			fatalInput(err)
		}
		printAtLine(doc, *opts.AtLine)
		return
	}
	cli := opts.List || opts.Tree || opts.Count || opts.Section != "" || opts.Query != ""
	if !cli {
		if len(opts.Files) == 0 {
			fmt.Println("# Select a file")
			return
		}
		doc, err := readDocument(opts.Files)
		if err != nil {
			fatalInput(err)
		}
		printHeadings(filterHeadings(doc.Headings, opts), "plain", false)
		return
	}
	doc, err := readDocument(opts.Files)
	if err != nil {
		fatalInput(err)
	}
	switch {
	case opts.Query != "":
		if err := runQuery(doc, opts.Query, valueOr(opts.QueryOutput, "plain")); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
	case opts.Count:
		printCount(doc)
	case opts.Section != "":
		if !printSection(doc, opts.Section) {
			fmt.Printf("Section '%s' not found\n", opts.Section)
			os.Exit(1)
		}
	case opts.Tree:
		printHeadings(filterHeadings(doc.Headings, opts), valueOr(opts.Output, "plain"), true)
	case opts.List:
		printHeadings(filterHeadings(doc.Headings, opts), valueOr(opts.Output, "plain"), false)
	default:
		printHeadings(filterHeadings(doc.Headings, opts), "plain", false)
	}
}

func parseArgs(args []string) (Options, error) {
	o := Options{Output: "plain", QueryOutput: "plain"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help", "help":
			o.Help = true
		case "-V", "--version":
			o.Version = true
		case "-l", "--list":
			o.List = true
		case "--tree":
			o.Tree = true
		case "--count":
			o.Count = true
		case "--query-help":
			o.QueryHelp = true
		case "--setup-completions":
			o.SetupCompletions = true
		case "--no-images", "--images":
		case "--filter":
			i++; if i >= len(args) { return o, fmt.Errorf("error: a value is required for '--filter <PATTERN>'") }; o.Filter = args[i]
		case "-L", "--level":
			i++; if i >= len(args) { return o, fmt.Errorf("error: a value is required for '--level <LEVEL>'") }
			n, _ := strconv.Atoi(args[i]); o.Level = n
		case "-o", "--output":
			i++; if i >= len(args) { return o, fmt.Errorf("error: a value is required for '--output <OUTPUT>'") }
			if args[i] != "plain" && args[i] != "json" && args[i] != "tree" {
				return o, fmt.Errorf("error: invalid value '%s' for '--output <OUTPUT>'\n  [possible values: plain, json, tree]\n\nFor more information, try '--help'.", args[i])
			}
			o.Output = args[i]
		case "-s", "--section":
			i++; if i >= len(args) { return o, fmt.Errorf("error: a value is required for '--section <HEADING>'") }; o.Section = args[i]
		case "-q", "--query":
			i++; if i >= len(args) { return o, fmt.Errorf("error: a value is required for '--query <EXPR>'") }; o.Query = args[i]
		case "--query-output":
			i++; if i >= len(args) { return o, fmt.Errorf("error: a value is required for '--query-output <FORMAT>'") }; o.QueryOutput = args[i]
		case "--theme", "--color-mode":
			i++
		case "at-line":
			if i+1 >= len(args) { return o, fmt.Errorf("error: the following required arguments were not provided:\n  <LINE>") }
			n, err := strconv.Atoi(args[i+1]); if err != nil { return o, fmt.Errorf("error: invalid value '%s' for '<LINE>'", args[i+1]) }
			o.AtLine = &n
			i++
		default:
			if strings.HasPrefix(a, "-") {
				return o, fmt.Errorf("error: unexpected argument '%s' found", a)
			}
			o.Files = append(o.Files, a)
		}
	}
	return o, nil
}

func readDocument(files []string) (*Document, error) {
	if len(files) == 0 {
		return parseMarkdown("# Select a file\n", nil), nil
	}
	var parts []string
	for _, f := range files {
		var b []byte
		var err error
		if f == "-" {
			b, err = io.ReadAll(os.Stdin)
			if err == nil && len(strings.TrimSpace(string(b))) == 0 {
				return nil, fmt.Errorf("Empty input provided")
			}
		} else {
			info, statErr := os.Stat(f)
			if statErr == nil && info.IsDir() {
				matches, _ := filepath.Glob(filepath.Join(f, "*.md"))
				matches2, _ := filepath.Glob(filepath.Join(f, "*.markdown"))
				matches = append(matches, matches2...)
				sort.Strings(matches)
				if len(matches) == 0 {
					return parseMarkdown("# Select a file\n", nil), nil
				}
				f = matches[0]
			}
			b, err = os.ReadFile(f)
		}
		if err != nil {
			return nil, err
		}
		parts = append(parts, string(b))
	}
	return parseMarkdown(strings.Join(parts, "\n"), nil), nil
}

func parseMarkdown(text string, source *string) *Document {
	text = strings.ReplaceAll(text, "\r\n", "\n")
	lines := strings.Split(strings.TrimRight(text, "\n"), "\n")
	doc := &Document{Source: source, Text: text, Lines: lines, Words: countWords(text)}
	var inCode bool
	var codeLang string
	var codeStart int
	var codeLines []string
	var offset int
	for idx, line := range lines {
		lineNo := idx + 1
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") {
			if inCode {
				raw := fence(codeLang, codeLines)
				doc.CodeBlocks = append(doc.CodeBlocks, CodeBlock{Lang: codeLang, Text: strings.Join(codeLines, "\n"), Start: codeStart, Raw: raw})
				inCode = false
				codeLines = nil
			} else {
				inCode = true
				codeLang = strings.TrimSpace(trim[3:])
				codeStart = lineNo
			}
			offset += len(line) + 1
			continue
		}
		if inCode {
			codeLines = append(codeLines, line)
			offset += len(line) + 1
			continue
		}
		if lev, title, ok := parseHeading(line); ok {
			h := &Heading{Level: lev, Text: title, Line: lineNo, Offset: offset, ContentFrom: idx + 1}
			doc.Headings = append(doc.Headings, h)
		}
		for _, l := range extractLinks(line) {
			doc.Links = append(doc.Links, l)
		}
		offset += len(line) + 1
	}
	if inCode {
		doc.CodeBlocks = append(doc.CodeBlocks, CodeBlock{Lang: codeLang, Text: strings.Join(codeLines, "\n"), Start: codeStart, Raw: fence(codeLang, codeLines)})
	}
	for i, h := range doc.Headings {
		end := len(lines)
		for j := i + 1; j < len(doc.Headings); j++ {
			if doc.Headings[j].Level <= h.Level {
				end = doc.Headings[j].Line - 1
				break
			}
		}
		h.ContentTo = end
		if h.ContentFrom < end {
			h.Content = strings.TrimRight(strings.Join(lines[h.ContentFrom:end], "\n"), "\n")
		}
	}
	var stack []*Heading
	for _, h := range doc.Headings {
		for len(stack) > 0 && stack[len(stack)-1].Level >= h.Level {
			stack = stack[:len(stack)-1]
		}
		if len(stack) == 0 {
			doc.Roots = append(doc.Roots, h)
		} else {
			p := stack[len(stack)-1]
			h.Parent = p
			p.Children = append(p.Children, h)
		}
		stack = append(stack, h)
	}
	doc.Tables = parseTables(lines)
	doc.Lists = parseLists(lines)
	doc.Blockquotes = parseBlockquotes(lines)
	return doc
}

func parseHeading(line string) (int, string, bool) {
	s := strings.TrimLeft(line, " ")
	if len(line)-len(s) > 3 || !strings.HasPrefix(s, "#") {
		return 0, "", false
	}
	n := 0
	for n < len(s) && s[n] == '#' {
		n++
	}
	if n == 0 || n > 6 || (n < len(s) && s[n] != ' ' && s[n] != '\t') {
		return 0, "", false
	}
	title := strings.TrimSpace(s[n:])
	title = strings.TrimSpace(regexp.MustCompile(`\s+#+\s*$`).ReplaceAllString(title, ""))
	if title == "" {
		return 0, "", false
	}
	return n, title, true
}

func extractLinks(line string) []Link {
	var out []Link
	re := regexp.MustCompile(`(!?)\[([^\]]*)\]\(([^)\s]+)(?:\s+"[^"]*")?\)`)
	for _, m := range re.FindAllStringSubmatch(line, -1) {
		if m[1] == "!" {
			continue
		}
		t := "relative"
		if strings.HasPrefix(m[3], "http://") || strings.HasPrefix(m[3], "https://") || strings.HasPrefix(m[3], "mailto:") {
			t = "external"
		} else if strings.HasPrefix(m[3], "#") {
			t = "anchor"
		}
		out = append(out, Link{Text: m[2], URL: m[3], Type: t})
	}
	return out
}

func parseTables(lines []string) []Table {
	var out []Table
	for i := 0; i+1 < len(lines); i++ {
		if strings.Contains(lines[i], "|") && isSepRow(lines[i+1]) {
			j := i + 2
			for j < len(lines) && strings.Contains(lines[j], "|") && strings.TrimSpace(lines[j]) != "" {
				j++
			}
			out = append(out, Table{Raw: normalizeTable(lines[i:j])})
			i = j - 1
		}
	}
	return out
}

func isSepRow(s string) bool {
	s = strings.TrimSpace(s)
	if !strings.Contains(s, "-") || !strings.Contains(s, "|") {
		return false
	}
	for _, r := range s {
		if r != '|' && r != '-' && r != ':' && !unicode.IsSpace(r) {
			return false
		}
	}
	return true
}

func normalizeTable(lines []string) string {
	if len(lines) < 2 {
		return strings.Join(lines, "\n")
	}
	cells := splitCells(lines[0])
	out := []string{"| " + strings.Join(cells, " | ") + " |"}
	sep := make([]string, len(cells))
	for i := range sep {
		sep[i] = "---"
	}
	out = append(out, "| "+strings.Join(sep, " | ")+" |")
	for _, l := range lines[2:] {
		out = append(out, "| "+strings.Join(splitCells(l), " | ")+" |")
	}
	return strings.Join(out, "\n")
}

func splitCells(s string) []string {
	s = strings.TrimSpace(s)
	s = strings.Trim(s, "|")
	parts := strings.Split(s, "|")
	for i := range parts {
		parts[i] = strings.TrimSpace(parts[i])
	}
	return parts
}

func parseLists(lines []string) []ListBlock {
	var out []ListBlock
	for i := 0; i < len(lines); i++ {
		if isListLine(lines[i]) {
			j := i
			var block []string
			for j < len(lines) && isListLine(lines[j]) {
				block = append(block, strings.TrimSpace(lines[j]))
				j++
			}
			out = append(out, ListBlock{Raw: strings.Join(block, "\n")})
			i = j - 1
		}
	}
	return out
}

func isListLine(s string) bool {
	t := strings.TrimSpace(s)
	if strings.HasPrefix(t, "- ") || strings.HasPrefix(t, "* ") || strings.HasPrefix(t, "+ ") {
		return true
	}
	return regexp.MustCompile(`^\d+\.\s+`).MatchString(t)
}

func parseBlockquotes(lines []string) []Blockquote {
	var out []Blockquote
	for i := 0; i < len(lines); i++ {
		if strings.HasPrefix(strings.TrimSpace(lines[i]), ">") {
			j := i
			var block []string
			for j < len(lines) && strings.HasPrefix(strings.TrimSpace(lines[j]), ">") {
				block = append(block, strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(lines[j]), ">")))
				j++
			}
			out = append(out, Blockquote{Raw: strings.Join(block, "\n")})
			i = j - 1
		}
	}
	return out
}

func filterHeadings(hs []*Heading, o Options) []*Heading {
	var out []*Heading
	pat := strings.ToLower(o.Filter)
	for _, h := range hs {
		if o.Level > 0 && h.Level != o.Level {
			continue
		}
		if pat != "" && !strings.Contains(strings.ToLower(h.Text), pat) {
			continue
		}
		out = append(out, h)
	}
	return out
}

func printHeadings(hs []*Heading, format string, tree bool) {
	if format == "json" {
		if tree {
			type J struct { Level int `json:"level"`; Text string `json:"text"` }
			var arr []J
			for _, h := range hs { arr = append(arr, J{h.Level, h.Text}) }
			printJSON(arr, true)
		} else {
			printJSON(buildDocumentJSON(hs), true)
		}
		return
	}
	if format == "tree" && !tree {
		fmt.Println("Use --tree for tree output")
		return
	}
	if tree || format == "tree" {
		printTreeFlat(hs)
		return
	}
	for _, h := range hs {
		fmt.Printf("%s %s\n", strings.Repeat("#", h.Level), h.Text)
	}
}

func printTreeFlat(hs []*Heading) {
	if len(hs) == 0 {
		return
	}
	for i, h := range hs {
		lastAtLevel := isLastSibling(hs, i)
		prefix := ""
		for lev := 1; lev < h.Level; lev++ {
			if hasLaterAncestorSibling(hs, i, lev) {
				prefix += "│  "
			} else {
				prefix += "   "
			}
		}
		branch := "├──"
		if lastAtLevel {
			branch = "└──"
		}
		fmt.Printf("%s%s%s %s\n", prefix, branch, strings.Repeat("#", h.Level), h.Text)
	}
}

func isLastSibling(hs []*Heading, idx int) bool {
	h := hs[idx]
	parentLevel := 0
	for j := idx - 1; j >= 0; j-- {
		if hs[j].Level < h.Level { parentLevel = hs[j].Level; break }
	}
	for j := idx + 1; j < len(hs); j++ {
		if hs[j].Level <= parentLevel { return true }
		if hs[j].Level == h.Level { return false }
	}
	return true
}

func hasLaterAncestorSibling(hs []*Heading, idx, lev int) bool {
	for j := idx - 1; j >= 0; j-- {
		if hs[j].Level == lev {
			for k := idx + 1; k < len(hs); k++ {
				if hs[k].Level < lev { return false }
				if hs[k].Level == lev { return true }
			}
			return false
		}
	}
	return false
}

func buildDocumentJSON(hs []*Heading) map[string]any {
	var roots []*Heading
	set := map[*Heading]bool{}
	for _, h := range hs { set[h] = true }
	for _, h := range hs {
		if h.Parent == nil || !set[h.Parent] { roots = append(roots, h) }
	}
	var conv func(*Heading) map[string]any
	conv = func(h *Heading) map[string]any {
		children := []any{}
		for _, c := range h.Children {
			if set[c] { children = append(children, conv(c)) }
		}
		return map[string]any{
			"id": slug(h.Text), "level": h.Level, "title": h.Text, "slug": slug(h.Text),
			"position": map[string]any{"line": h.Line + 1, "offset": h.Offset + len(strings.Repeat("#", h.Level)) + len(h.Text) + 2},
			"content": map[string]any{"raw": h.Content, "blocks": []any{}},
			"children": children,
		}
	}
	sections := []any{}
	for _, r := range roots { sections = append(sections, conv(r)) }
	maxd := 0
	for h := range set { if h.Level > maxd { maxd = h.Level } }
	return map[string]any{"document": map[string]any{"metadata": map[string]any{"source": nil, "headingCount": len(hs), "maxDepth": maxd, "wordCount": 0}, "sections": sections}}
}

func printCount(doc *Document) {
	counts := map[int]int{}
	for _, h := range doc.Headings { counts[h.Level]++ }
	fmt.Println("Heading counts:")
	total := 0
	for i := 1; i <= 6; i++ {
		if counts[i] > 0 {
			fmt.Printf("  %s: %d\n", strings.Repeat("#", i), counts[i])
			total += counts[i]
		}
	}
	fmt.Printf("\nTotal: %d\n", total)
}

func printSection(doc *Document, name string) bool {
	lname := strings.ToLower(name)
	for _, h := range doc.Headings {
		if strings.ToLower(h.Text) == lname || strings.Contains(strings.ToLower(h.Text), lname) {
			fmt.Printf("%s %s\n", strings.Repeat("#", h.Level), h.Text)
			if h.Content != "" {
				fmt.Println(h.Content)
			}
			return true
		}
	}
	return false
}

func printAtLine(doc *Document, line int) {
	var cur *Heading
	for _, h := range doc.Headings {
		if h.Line <= line {
			cur = h
		}
	}
	if cur != nil {
		fmt.Printf("%s %s\n", strings.Repeat("#", cur.Level), cur.Text)
	}
}

func runQuery(doc *Document, expr, outfmt string) error {
	if outfmt == "jsonp" { return fmt.Errorf("Unknown output format: jsonp") }
	expr = strings.TrimSpace(expr)
	parts := strings.Split(expr, "|")
	selector := strings.TrimSpace(parts[0])
	fn := ""
	if len(parts) > 1 { fn = strings.TrimSpace(parts[1]) }
	items := selectItems(doc, selector)
	if fn != "" {
		return applyFunction(items, fn, outfmt)
	}
	return outputItems(items, outfmt)
}

type Item struct {
	Type string
	H    *Heading
	Code *CodeBlock
	Link *Link
	Raw  string
}

func selectItems(doc *Document, sel string) []Item {
	bracketCollection := false
	if strings.HasPrefix(sel, "[") && strings.HasSuffix(sel, "]") {
		bracketCollection = true
		sel = strings.TrimSpace(sel[1:len(sel)-1])
	}
	_ = bracketCollection
	if strings.Contains(sel, ">>") || strings.Contains(sel, ">") {
		op := ">"
		parts := strings.SplitN(sel, ">", 2)
		if strings.Contains(sel, ">>") {
			op = ">>"
			parts = strings.SplitN(sel, ">>", 2)
		}
		left := selectItems(doc, strings.TrimSpace(parts[0]))
		right := strings.TrimSpace(parts[1])
		level := 0
		if strings.HasPrefix(right, ".h") && len(right) >= 3 && right[2] >= '1' && right[2] <= '6' {
			level = int(right[2] - '0')
		}
		var arr []Item
		for _, it := range left {
			if it.H == nil {
				continue
			}
			if op == ">" {
				for _, c := range it.H.Children {
					if level == 0 || c.Level == level {
						arr = append(arr, Item{Type: "heading", H: c})
					}
				}
			} else {
				var walk func(*Heading)
				walk = func(h *Heading) {
					for _, c := range h.Children {
						if level == 0 || c.Level == level {
							arr = append(arr, Item{Type: "heading", H: c})
						}
						walk(c)
					}
				}
				walk(it.H)
			}
		}
		return arr
	}
	if strings.HasPrefix(sel, ".h") || sel == ".heading" {
		level := 0
		base := sel
		filter := ""
		if i := strings.Index(sel, "["); i >= 0 {
			base = sel[:i]
			filter = strings.TrimSuffix(sel[i+1:], "]")
		}
		if len(base) == 3 && base[2] >= '1' && base[2] <= '6' { level = int(base[2]-'0') }
		var arr []Item
		for _, h := range doc.Headings {
			if level == 0 || h.Level == level { arr = append(arr, Item{Type:"heading", H:h}) }
		}
		return filterItems(arr, filter)
	}
	if strings.HasPrefix(sel, ".code") {
		lang := betweenBracket(sel)
		var arr []Item
		for i := range doc.CodeBlocks {
			if lang == "" || strings.EqualFold(lang, doc.CodeBlocks[i].Lang) { arr = append(arr, Item{Type:"code", Code:&doc.CodeBlocks[i]}) }
		}
		return arr
	}
	if strings.HasPrefix(sel, ".link") || strings.HasPrefix(sel, ".a") {
		filter := betweenBracket(sel)
		var arr []Item
		for i := range doc.Links {
			if filter == "" || filter == doc.Links[i].Type { arr = append(arr, Item{Type:"link", Link:&doc.Links[i]}) }
		}
		return arr
	}
	if strings.HasPrefix(sel, ".table") {
		var arr []Item; for _, t := range doc.Tables { arr = append(arr, Item{Type:"table", Raw:t.Raw}) }; return arr
	}
	if strings.HasPrefix(sel, ".list") {
		var arr []Item; for _, l := range doc.Lists { arr = append(arr, Item{Type:"list", Raw:l.Raw}) }; return arr
	}
	if strings.HasPrefix(sel, ".blockquote") {
		var arr []Item; for _, b := range doc.Blockquotes { arr = append(arr, Item{Type:"blockquote", Raw:b.Raw}) }; return arr
	}
	return []Item{{Type:"document", Raw:doc.Text}}
}

func filterItems(items []Item, filter string) []Item {
	filter = strings.Trim(filter, `"'`)
	if filter == "" { return items }
	if strings.Contains(filter, ":") {
		parts := strings.SplitN(filter, ":", 2)
		start, end := 0, len(items)
		if parts[0] != "" {
			start, _ = strconv.Atoi(parts[0])
		}
		if parts[1] != "" {
			end, _ = strconv.Atoi(parts[1])
		}
		if start < 0 { start = len(items) + start }
		if end < 0 { end = len(items) + end }
		if start < 0 { start = 0 }
		if end > len(items) { end = len(items) }
		if start > end { return nil }
		return items[start:end]
	}
	if n, err := strconv.Atoi(filter); err == nil {
		if n < 0 { n = len(items)+n }
		if n >= 0 && n < len(items) { return []Item{items[n]} }
		return nil
	}
	var out []Item
	for _, it := range items {
		if it.H != nil && strings.Contains(strings.ToLower(it.H.Text), strings.ToLower(filter)) { out = append(out, it) }
	}
	return out
}

func applyFunction(items []Item, fn, outfmt string) error {
	fn = strings.TrimSpace(fn)
	if strings.HasPrefix(fn, "select") || strings.HasPrefix(fn, "where") || strings.HasPrefix(fn, "filter") {
		re := regexp.MustCompile(`contains\(["']([^"']+)["']\)`)
		m := re.FindStringSubmatch(fn)
		if len(m) == 2 {
			var out []Item
			for _, it := range items {
				if strings.Contains(strings.ToLower(itemText(it)), strings.ToLower(m[1])) { out = append(out, it) }
			}
			return outputItems(out, outfmt)
		}
	}
	if strings.HasPrefix(fn, "limit(") || strings.HasPrefix(fn, "take(") {
		n := argInt(fn)
		if n < len(items) { items = items[:n] }
		return outputItems(items, outfmt)
	}
	if strings.HasPrefix(fn, "skip(") || strings.HasPrefix(fn, "drop(") {
		n := argInt(fn)
		if n < len(items) { items = items[n:] } else { items = nil }
		return outputItems(items, outfmt)
	}
	switch fn {
	case "count", "length", "len", "size":
		fmt.Println(len(items)); return nil
	case "first", "head":
		if len(items) > 0 { return outputItems(items[:1], outfmt) }; return nil
	case "last":
		if len(items) > 0 { return outputItems(items[len(items)-1:], outfmt) }; return nil
	case "text":
		for _, it := range items { fmt.Println(itemText(it)) }; return nil
	case "url", "href", "src":
		for _, it := range items { if it.Link != nil { fmt.Println(it.Link.URL) } }; return nil
	case "lang":
		for _, it := range items { if it.Code != nil { fmt.Println(it.Code.Lang) } }; return nil
	case "upper":
		for _, it := range items { fmt.Println(strings.ToUpper(itemText(it))) }; return nil
	case "lower":
		for _, it := range items { fmt.Println(strings.ToLower(itemText(it))) }; return nil
	case "slugify":
		for _, it := range items { fmt.Println(slug(itemText(it))) }; return nil
	case "stats":
		return printStatsFromDoc(items)
	}
	return outputItems(items, outfmt)
}

func printStatsFromDoc(items []Item) error {
	// The document item keeps only raw text, so recompute a small document.
	if len(items) > 0 && items[0].Type == "document" {
		d := parseMarkdown(items[0].Raw, nil)
		fmt.Printf("headings: %d\ncode_blocks: %d\nlinks: %d\nimages: 0\ntables: %d\nlists: %d\nwords: %d\n", len(d.Headings), len(d.CodeBlocks), len(d.Links), len(d.Tables), len(d.Lists), d.Words)
	}
	return nil
}

func outputItems(items []Item, outfmt string) error {
	switch outfmt {
	case "plain", "":
		for _, it := range items { fmt.Println(itemPlain(it)) }
	case "md":
		for _, it := range items {
			if it.H != nil {
				fmt.Printf("%s %s\n", strings.Repeat("#", it.H.Level), it.H.Text)
				if it.H.Content != "" { fmt.Println(it.H.Content); fmt.Println() }
			} else { fmt.Println(itemPlain(it)) }
		}
	case "tree":
		var hs []*Heading
		for _, it := range items { if it.H != nil { hs = append(hs, it.H) } }
		if len(hs) > 0 { printTreeFlat(hs) }
	case "json", "json-pretty":
		var arr []any
		for _, it := range items { arr = append(arr, itemJSON(it)) }
		printJSON(arr, outfmt == "json-pretty")
	case "jsonl":
		for _, it := range items {
			b, _ := json.Marshal(itemJSON(it)); fmt.Println(string(b))
		}
	default:
		return fmt.Errorf("Unknown output format: %s", outfmt)
	}
	return nil
}

func itemPlain(it Item) string {
	switch {
	case it.H != nil:
		return fmt.Sprintf("%s %s", strings.Repeat("#", it.H.Level), it.H.Text)
	case it.Code != nil:
		return it.Code.Raw
	case it.Link != nil:
		return fmt.Sprintf("[%s](%s)", it.Link.Text, it.Link.URL)
	default:
		return it.Raw
	}
}

func itemText(it Item) string {
	switch {
	case it.H != nil: return it.H.Text
	case it.Code != nil: return it.Code.Text
	case it.Link != nil: return it.Link.Text
	default: return it.Raw
	}
}

func itemJSON(it Item) any {
	switch {
	case it.H != nil:
		return struct {
			Type  string `json:"type"`
			Level int    `json:"level"`
			Text  string `json:"text"`
			Line  int    `json:"line"`
		}{"heading", it.H.Level, it.H.Text, it.H.Line}
	case it.Code != nil:
		return struct {
			Type     string `json:"type"`
			Language string `json:"language"`
			Content  string `json:"content"`
			Line     int    `json:"line"`
		}{"code", it.Code.Lang, it.Code.Text, it.Code.Start}
	case it.Link != nil:
		return struct {
			Type     string `json:"type"`
			Text     string `json:"text"`
			URL      string `json:"url"`
			LinkType string `json:"link_type"`
		}{"link", it.Link.Text, it.Link.URL, it.Link.Type}
	default:
		return struct {
			Type    string `json:"type"`
			Content string `json:"content"`
		}{it.Type, it.Raw}
	}
}

func printJSON(v any, pretty bool) {
	var b []byte
	if pretty { b, _ = json.MarshalIndent(v, "", "  ") } else { b, _ = json.Marshal(v) }
	fmt.Println(string(b))
}

func printShortHelp() {
	fmt.Println(`A markdown navigator with tree-based structural navigation

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin

Options:
  -l, --list                   List all headings in the document (non-interactive)
      --tree                   Show heading tree structure with box-drawing characters (non-interactive)
      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>          Show only headings at specific level (1-6)
  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]
  -s, --section <HEADING>      Extract specific section by heading name
      --count                  Count headings by level (shows statistics)
      --setup-completions      Set up shell completions interactively
      --theme <THEME>          Set theme for TUI mode
      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, rgb, 256]
      --no-images              Disable image rendering in TUI mode
      --images                 Enable image rendering in TUI mode (override config)
  -q, --query <EXPR>           Query expression for selecting/filtering document elements
      --query-help             Show query language documentation and examples
      --query-output <FORMAT>  Output format for query results
  -h, --help                   Print help (see more with '--help')
  -V, --version                Print version`)
}

func printQueryHelp() {
	fmt.Println(`treemd Query Language (tql)

A jq-like query language for navigating and extracting markdown structure.

ELEMENT SELECTORS
    .h, .heading    All headings (any level)
    .h1 - .h6       Headings by level
    .code           All code blocks
    .code[rust]     Code blocks by language
    .link, .a       All links
    .link[external] External links only
    .img            All images
    .table          All tables
    .list           All lists
    .blockquote     All blockquotes

FILTERS & INDEXING
    .h2[Features]       Heading containing "Features" (fuzzy)
    .h2["Installation"] Heading with exact text
    .h2[0]              First h2
    .h2[-1]             Last h2
    .h2[1:3]            h2s at index 1 and 2
    .h2[:3]             First 3 h2s

EXAMPLES
    treemd -q '.h2' doc.md
    treemd -q '.h2 | text' doc.md
    treemd -q '[.h2] | count' doc.md`)
}

func fatalInput(err error) {
	fmt.Fprintln(os.Stderr, "Error reading input:", err)
	os.Exit(1)
}

func valueOr(s, def string) string { if s == "" { return def }; return s }
func fence(lang string, lines []string) string { return "```" + lang + "\n" + strings.Join(lines, "\n") + "\n```" }
func betweenBracket(s string) string { i := strings.Index(s, "["); if i < 0 { return "" }; return strings.Trim(strings.TrimSuffix(s[i+1:], "]"), `"'`) }
func argInt(s string) int { re := regexp.MustCompile(`\(([-0-9]+)\)`); m := re.FindStringSubmatch(s); if len(m)==2 { n,_:=strconv.Atoi(m[1]); return n }; return 0 }

func slug(s string) string {
	s = strings.ToLower(s)
	var b strings.Builder
	prevDash := false
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r); prevDash = false
		} else if !prevDash {
			b.WriteByte('-'); prevDash = true
		}
	}
	return strings.Trim(b.String(), "-")
}

func countWords(s string) int {
	sc := bufio.NewScanner(strings.NewReader(s))
	sc.Split(bufio.ScanWords)
	n := 0
	for sc.Scan() { n++ }
	return n
}
