module trdsqlclone

go 1.21
