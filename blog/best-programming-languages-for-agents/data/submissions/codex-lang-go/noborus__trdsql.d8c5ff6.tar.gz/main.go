package main

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"encoding/csv"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/tabwriter"
)

type multiFlag bool

func (m *multiFlag) Set(string) error { *m = true; return nil }
func (m *multiFlag) String() string   { return strconv.FormatBool(bool(*m)) }
func (m *multiFlag) IsBoolFlag() bool { return true }

type options struct {
	ih, inum, iguess, crlf, oh, oaq, nowrap bool
	id, od, oq, out, onull, inull, ijq      string
	tfile, qfile, analyze, analyzeOnly      string
	ilr, ir, iskip                          int
	inFmt, outFmt, oz                       string
	version, help, dblist, debug            bool
}

type table struct {
	cols []string
	rows [][]string
}

type selectItem struct {
	expr  string
	alias string
}

type query struct {
	raw       string
	selects   []selectItem
	from      string
	where     string
	order     string
	orderDesc bool
	limit     int
	group     string
	countOnly bool
}

func main() {
	opt := parseFlags()
	if opt.help || (flag.NArg() == 0 && opt.qfile == "" && opt.tfile == "" && opt.analyze == "" && opt.analyzeOnly == "" && !opt.version && !opt.dblist) {
		usage(os.Stdout)
		return
	}
	if opt.version {
		fmt.Println("trdsql version devel")
		return
	}
	if opt.dblist {
		return
	}
	if opt.analyze != "" || opt.analyzeOnly != "" {
		file := opt.analyze
		only := false
		if file == "" {
			file = opt.analyzeOnly
			only = true
		}
		t, _ := readTable(file, opt)
		examples := buildExamples(file, t.cols)
		if only {
			fmt.Print(examples)
			return
		}
		fmt.Printf("The table name is %s.\n", file)
		fmt.Printf("The file type is %s.\n\n", strings.ToUpper(guessFormat(file, opt)))
		fmt.Println("Data types:")
		printSimpleAT([]string{"column name", "type"}, typeRows(t.cols))
		fmt.Println("\nData samples:")
		sample := t.rows
		if len(sample) > 1 {
			sample = sample[:1]
		}
		printSimpleAT(t.cols, sample)
		fmt.Println("\nExamples:")
		fmt.Print(examples)
		return
	}
	if opt.qfile != "" {
		b, err := os.ReadFile(opt.qfile)
		fatal(err)
		_ = b
	}
	if opt.tfile != "" {
		t, err := readTable(opt.tfile, opt)
		fatal(err)
		fatal(writeTable(t, opt))
		return
	}
	sql := strings.Join(flag.Args(), " ")
	if opt.qfile != "" {
		b, err := os.ReadFile(opt.qfile)
		fatal(err)
		sql = string(bytes.TrimSpace(b))
	}
	q, err := parseQuery(sql)
	fatal(err)
	if opt.tfile == "" {
		opt.tfile = q.from
	}
	t, err := readTable(q.from, opt)
	fatal(err)
	res, err := evalQuery(t, q)
	fatal(err)
	fatal(writeTable(res, opt))
}

func parseFlags() options {
	opt := options{iguess: true, id: ",", od: ",", oq: "\"", ir: 1}
	flag.BoolVar(&opt.help, "help", false, "")
	flag.BoolVar(&opt.version, "version", false, "")
	flag.BoolVar(&opt.dblist, "dblist", false, "")
	flag.BoolVar(&opt.debug, "debug", false, "")
	flag.StringVar(&opt.tfile, "t", "", "")
	flag.StringVar(&opt.qfile, "q", "", "")
	flag.StringVar(&opt.analyze, "a", "", "")
	flag.StringVar(&opt.analyzeOnly, "A", "", "")
	flag.String("config", "", "")
	flag.String("db", "", "")
	flag.String("driver", "", "")
	flag.String("dsn", "", "")
	flag.Var((*multiFlag)(&opt.ih), "ih", "")
	flag.Var((*multiFlag)(&opt.inum), "inum", "")
	flag.BoolVar(&opt.iguess, "ig", true, "")
	flag.Var((*multiFlag)(&opt.crlf), "ocrlf", "")
	flag.Var((*multiFlag)(&opt.oh), "oh", "")
	flag.Var((*multiFlag)(&opt.oaq), "oaq", "")
	flag.Var((*multiFlag)(&opt.nowrap), "onowrap", "")
	flag.StringVar(&opt.id, "id", ",", "")
	flag.StringVar(&opt.od, "od", ",", "")
	flag.StringVar(&opt.oq, "oq", "\"", "")
	flag.StringVar(&opt.out, "out", "", "")
	flag.StringVar(&opt.onull, "onull", "", "")
	flag.StringVar(&opt.inull, "inull", "", "")
	flag.StringVar(&opt.ijq, "ijq", "", "")
	flag.IntVar(&opt.ilr, "ilr", 0, "")
	flag.IntVar(&opt.ir, "ir", 1, "")
	flag.IntVar(&opt.iskip, "is", 0, "")
	flag.StringVar(&opt.oz, "oz", "", "")
	for _, f := range []string{"icsv", "ijson", "iltsv", "itbln", "itext", "iwidth", "iyaml", "ocsv", "ojson", "ojsonl", "oltsv", "omd", "oat", "oraw", "otbln", "ovf", "oyaml"} {
		ff := f
		flag.BoolFunc(ff, "", func(string) error {
			if strings.HasPrefix(ff, "i") {
				opt.inFmt = strings.TrimPrefix(ff, "i")
			} else {
				opt.outFmt = strings.TrimPrefix(ff, "o")
			}
			return nil
		})
	}
	flag.BoolFunc("out-without-guess", "", func(string) error { return nil })
	flag.Usage = func() { usage(os.Stdout) }
	flag.Parse()
	return opt
}

func usage(w io.Writer) {
	fmt.Fprint(w, `trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.

Usage
	trdsql [OPTIONS] [SQL(SELECT...)]

Options:
  -A string           analyze the file but only suggest SQL.
  -a string           analyze the file and suggest SQL.
  -config string      configuration file location.
  -db string          specify db name of the setting.
  -dblist             display db information.
  -debug              debug print.
  -driver string      database driver.  [ mysql | postgres | sqlite3 | sqlite3_ext ]
  -dsn string         database driver specific data source name.
  -help               display usage information.
  -q string           read query from the specified file.
  -t string           read table name from the specified file.
  -version            display version information.

Input Formats:
  -icsv               CSV format for input.
  -ig                 guess format from extension. (default "true")
  -ijson              JSON format for input.
  -iltsv              LTSV format for input.
  -itbln              TBLN format for input.
  -itext              text format for input.
  -iwidth             width specification format for input.
  -iyaml              YAML format for input.

Input options:
  -id string          field delimiter for input. (default ",")
  -ih                 the first line is interpreted as column names(CSV only).
  -ijq string         jq expression string for input(JSON/JSONL only).
  -ilr int            limited number of rows to read. (default 0)
  -inull value        value(string) to convert to null on input.
  -inum               add row number column.
  -ir int             number of rows to preread. (default 1)
  -is int             skip header row. (default 0)

Output Formats:
  -oat                ASCII Table format for output.
  -ocsv               CSV format for output.
  -ojson              JSON format for output.
  -ojsonl             JSON lines format for output.
  -oltsv              LTSV format for output.
  -omd                Markdown format for output.
  -oraw               Raw format for output.
  -otbln              TBLN format for output.
  -ovf                Vertical format for output.
  -oyaml              YAML format for output.

Output options:
  -oaq                enclose all fields in quotes for output.
  -ocrlf              use CRLF for output. End each output line with '\r\n' instead of '\n'.
  -od string          field delimiter for output. (default ",")
  -oh                 output column name as header.
  -onowrap            do not wrap long lines(at/md only).
  -onull value        value(string) to convert from null on output.
  -oq string          quote character for output. (default "\"")
  -out string         output file name.
  -out-without-guess  output without guessing (when using -out).
  -oz string          output compression format. [ gz | bz2 | zstd | lz4 | xz ]

Examples:
  $ trdsql "SELECT c1,c2 FROM test.csv"
  $ trdsql -oltsv "SELECT c1,c2 FROM test.json::.items"
  $ cat test.csv | trdsql -icsv -oltsv "SELECT c1,c2 FROM -"
`)
}

func guessFormat(file string, opt options) string {
	if opt.inFmt != "" {
		return opt.inFmt
	}
	low := strings.ToLower(file)
	if i := strings.Index(low, "::"); i >= 0 {
		low = low[:i]
	}
	switch filepath.Ext(low) {
	case ".json", ".jsonl", ".ndjson":
		return "json"
	case ".ltsv":
		return "ltsv"
	case ".yaml", ".yml":
		return "yaml"
	case ".tbln":
		return "tbln"
	default:
		return "csv"
	}
}

func readAll(file string) ([]byte, error) {
	if file == "-" || file == "" {
		return io.ReadAll(os.Stdin)
	}
	if i := strings.Index(file, "::"); i >= 0 {
		file = file[:i]
	}
	return os.ReadFile(file)
}

func readTable(file string, opt options) (table, error) {
	b, err := readAll(file)
	if err != nil {
		return table{}, err
	}
	switch guessFormat(file, opt) {
	case "ltsv":
		return parseLTSV(string(b), opt), nil
	case "json":
		return parseJSON(b, file, opt)
	case "yaml":
		return parseYAML(string(b), opt), nil
	case "text":
		return parseText(string(b), opt), nil
	default:
		return parseCSV(bytes.NewReader(b), opt)
	}
}

func parseCSV(r io.Reader, opt options) (table, error) {
	cr := csv.NewReader(r)
	cr.FieldsPerRecord = -1
	if opt.id != "" {
		rs := []rune(opt.id)
		cr.Comma = rs[0]
	}
	records, err := cr.ReadAll()
	if err != nil {
		return table{}, err
	}
	if opt.iskip > 0 && opt.iskip < len(records) {
		records = records[opt.iskip:]
	}
	if len(records) == 0 {
		return table{}, nil
	}
	var cols []string
	if opt.ih {
		cols = cleanCols(records[0])
		records = records[1:]
	} else {
		cols = defaultCols(maxFields(records))
	}
	rows := normalizeRows(records, len(cols), opt)
	return addRowNum(table{cols, rows}, opt), nil
}

func parseLTSV(s string, opt options) table {
	var cols []string
	seen := map[string]bool{}
	var rows [][]string
	for _, line := range strings.Split(strings.TrimRight(s, "\r\n"), "\n") {
		if strings.TrimSpace(line) == "" {
			continue
		}
		m := map[string]string{}
		for _, p := range strings.Split(strings.TrimRight(line, "\r"), "\t") {
			kv := strings.SplitN(p, ":", 2)
			if len(kv) != 2 {
				continue
			}
			if !seen[kv[0]] {
				seen[kv[0]] = true
				cols = append(cols, kv[0])
			}
			m[kv[0]] = kv[1]
		}
		row := make([]string, len(cols))
		for i, c := range cols {
			row[i] = m[c]
		}
		rows = append(rows, row)
	}
	return addRowNum(table{cols, rows}, opt)
}

func parseJSON(b []byte, file string, opt options) (table, error) {
	var v any
	if err := json.Unmarshal(b, &v); err != nil {
		var arr []any
		for _, line := range strings.Split(strings.TrimSpace(string(b)), "\n") {
			if strings.TrimSpace(line) == "" {
				continue
			}
			var x any
			if e := json.Unmarshal([]byte(line), &x); e != nil {
				return table{}, err
			}
			arr = append(arr, x)
		}
		v = arr
	}
	path := ""
	if i := strings.Index(file, "::"); i >= 0 {
		path = file[i+2:]
	}
	if opt.ijq != "" {
		path = opt.ijq
	}
	v = descendJSON(v, path)
	arr, ok := v.([]any)
	if !ok {
		arr = []any{v}
	}
	var cols []string
	seen := map[string]bool{}
	var maps []map[string]string
	for _, item := range arr {
		m := flattenJSON(item)
		maps = append(maps, m)
		keys := make([]string, 0, len(m))
		for k := range m {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			if !seen[k] {
				seen[k] = true
				cols = append(cols, k)
			}
		}
	}
	var rows [][]string
	for _, m := range maps {
		row := make([]string, len(cols))
		for i, c := range cols {
			row[i] = m[c]
		}
		rows = append(rows, row)
	}
	return addRowNum(table{cols, rows}, opt), nil
}

func parseYAML(s string, opt options) table {
	var docs []map[string]string
	cur := map[string]string{}
	add := func() {
		if len(cur) > 0 {
			docs = append(docs, cur)
			cur = map[string]string{}
		}
	}
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if line == "---" || strings.HasPrefix(line, "- ") {
			add()
			line = strings.TrimPrefix(line, "- ")
			if line == "" {
				continue
			}
		}
		if kv := strings.SplitN(line, ":", 2); len(kv) == 2 {
			cur[strings.TrimSpace(kv[0])] = strings.Trim(strings.TrimSpace(kv[1]), `"'`)
		}
	}
	add()
	return mapsToTable(docs, opt)
}

func parseText(s string, opt options) table {
	var rows [][]string
	for _, line := range strings.Split(strings.TrimRight(s, "\r\n"), "\n") {
		rows = append(rows, []string{strings.TrimRight(line, "\r")})
	}
	return addRowNum(table{[]string{"c1"}, rows}, opt)
}

func mapsToTable(ms []map[string]string, opt options) table {
	var cols []string
	seen := map[string]bool{}
	for _, m := range ms {
		keys := make([]string, 0, len(m))
		for k := range m {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			if !seen[k] {
				seen[k] = true
				cols = append(cols, k)
			}
		}
	}
	var rows [][]string
	for _, m := range ms {
		row := make([]string, len(cols))
		for i, c := range cols {
			row[i] = m[c]
		}
		rows = append(rows, row)
	}
	return addRowNum(table{cols, rows}, opt)
}

func descendJSON(v any, path string) any {
	path = strings.TrimSpace(path)
	path = strings.TrimPrefix(path, ".")
	if path == "" {
		return v
	}
	for _, part := range strings.Split(path, ".") {
		if m, ok := v.(map[string]any); ok {
			v = m[part]
		}
	}
	return v
}

func flattenJSON(v any) map[string]string {
	if m, ok := v.(map[string]any); ok {
		out := map[string]string{}
		for k, x := range m {
			out[k] = scalar(x)
		}
		return out
	}
	return map[string]string{"c1": scalar(v)}
}

func scalar(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	case float64:
		if x == float64(int64(x)) {
			return strconv.FormatInt(int64(x), 10)
		}
		return strconv.FormatFloat(x, 'f', -1, 64)
	case bool:
		return strconv.FormatBool(x)
	default:
		b, _ := json.Marshal(x)
		return string(b)
	}
}

func cleanCols(in []string) []string {
	out := make([]string, len(in))
	for i, c := range in {
		c = strings.TrimSpace(c)
		if c == "" {
			c = fmt.Sprintf("c%d", i+1)
		}
		out[i] = c
	}
	return out
}

func defaultCols(n int) []string {
	cols := make([]string, n)
	for i := range cols {
		cols[i] = fmt.Sprintf("c%d", i+1)
	}
	return cols
}

func maxFields(records [][]string) int {
	n := 0
	for _, r := range records {
		if len(r) > n {
			n = len(r)
		}
	}
	return n
}

func normalizeRows(records [][]string, n int, opt options) [][]string {
	var rows [][]string
	for _, r := range records {
		row := make([]string, n)
		copy(row, r)
		for i, v := range row {
			if opt.inull != "" && v == opt.inull {
				row[i] = ""
			}
		}
		rows = append(rows, row)
		if opt.ilr > 0 && len(rows) >= opt.ilr {
			break
		}
	}
	return rows
}

func addRowNum(t table, opt options) table {
	if !opt.inum {
		return t
	}
	t.cols = append([]string{"n"}, t.cols...)
	for i := range t.rows {
		t.rows[i] = append([]string{strconv.Itoa(i + 1)}, t.rows[i]...)
	}
	return t
}

func parseQuery(sql string) (query, error) {
	q := query{raw: sql, limit: -1}
	sql = strings.TrimSpace(strings.TrimSuffix(sql, ";"))
	re := regexp.MustCompile(`(?is)^\s*select\s+(.*?)\s+from\s+(.+?)\s*(?:where\s+(.*?))?(?:group\s+by\s+(.+?))?(?:order\s+by\s+(.+?))?(?:limit\s+(\d+))?\s*$`)
	m := re.FindStringSubmatch(sql)
	if m == nil {
		return q, errors.New("unsupported query")
	}
	q.from = strings.Trim(strings.TrimSpace(m[2]), "`\"")
	q.where = strings.TrimSpace(m[3])
	q.group = strings.TrimSpace(m[4])
	order := strings.Fields(strings.TrimSpace(m[5]))
	if len(order) > 0 {
		q.order = strings.Trim(order[0], "`\"")
		if len(order) > 1 && strings.EqualFold(order[1], "desc") {
			q.orderDesc = true
		}
	}
	if m[6] != "" {
		q.limit, _ = strconv.Atoi(m[6])
	}
	for _, p := range splitCSVExpr(m[1]) {
		it := selectItem{expr: strings.TrimSpace(p)}
		if mm := regexp.MustCompile(`(?is)^(.+?)\s+as\s+([A-Za-z_][\w]*)$`).FindStringSubmatch(it.expr); mm != nil {
			it.expr = strings.TrimSpace(mm[1])
			it.alias = mm[2]
		}
		if regexp.MustCompile(`(?is)^count\s*\(.+\)$`).MatchString(it.expr) {
			q.countOnly = true
		}
		q.selects = append(q.selects, it)
	}
	return q, nil
}

func splitCSVExpr(s string) []string {
	var out []string
	var b strings.Builder
	depth := 0
	quote := rune(0)
	for _, r := range s {
		if quote != 0 {
			b.WriteRune(r)
			if r == quote {
				quote = 0
			}
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			b.WriteRune(r)
			continue
		}
		if r == '(' {
			depth++
		} else if r == ')' && depth > 0 {
			depth--
		}
		if r == ',' && depth == 0 {
			out = append(out, b.String())
			b.Reset()
		} else {
			b.WriteRune(r)
		}
	}
	out = append(out, b.String())
	return out
}

func evalQuery(t table, q query) (table, error) {
	rows := t.rows
	if q.where != "" {
		var f [][]string
		for _, r := range rows {
			if evalWhere(t, r, q.where) {
				f = append(f, r)
			}
		}
		rows = f
	}
	if q.group != "" && q.countOnly {
		return evalGroupCount(t, rows, q), nil
	}
	if q.countOnly && len(q.selects) == 1 {
		return table{cols: []string{"count(*)"}, rows: [][]string{{strconv.Itoa(len(rows))}}}, nil
	}
	if q.order != "" {
		idx := colIndex(t.cols, q.order)
		if idx >= 0 {
			sort.SliceStable(rows, func(i, j int) bool {
				c := compare(rows[i][idx], rows[j][idx])
				if q.orderDesc {
					return c > 0
				}
				return c < 0
			})
		}
	}
	if q.limit >= 0 && q.limit < len(rows) {
		rows = rows[:q.limit]
	}
	if len(q.selects) == 1 && q.selects[0].expr == "*" {
		return table{cols: append([]string{}, t.cols...), rows: cloneRows(rows)}, nil
	}
	var cols []string
	var out [][]string
	for _, it := range q.selects {
		if it.alias != "" {
			cols = append(cols, it.alias)
		} else {
			cols = append(cols, strings.Trim(it.expr, "`\""))
		}
	}
	for _, r := range rows {
		var row []string
		for _, it := range q.selects {
			row = append(row, evalExpr(t, r, it.expr))
		}
		out = append(out, row)
	}
	return table{cols: cols, rows: out}, nil
}

func evalGroupCount(t table, rows [][]string, q query) table {
	idx := colIndex(t.cols, strings.Trim(q.group, "`\""))
	if idx < 0 {
		return table{}
	}
	counts := map[string]int{}
	order := []string{}
	for _, r := range rows {
		k := r[idx]
		if _, ok := counts[k]; !ok {
			order = append(order, k)
		}
		counts[k]++
	}
	var out [][]string
	for _, k := range order {
		out = append(out, []string{k, strconv.Itoa(counts[k])})
	}
	return table{cols: []string{t.cols[idx], "count(" + t.cols[idx] + ")"}, rows: out}
}

func evalWhere(t table, r []string, where string) bool {
	parts := regexp.MustCompile(`(?i)\s+and\s+`).Split(where, -1)
	for _, p := range parts {
		if !evalCond(t, r, strings.TrimSpace(p)) {
			return false
		}
	}
	return true
}

func evalCond(t table, r []string, c string) bool {
	re := regexp.MustCompile(`(?is)^(.+?)\s*(>=|<=|<>|!=|=|>|<|like)\s*(.+)$`)
	m := re.FindStringSubmatch(c)
	if m == nil {
		return false
	}
	left := evalExpr(t, r, strings.TrimSpace(m[1]))
	right := literalOrExpr(t, r, strings.TrimSpace(m[3]))
	switch strings.ToLower(m[2]) {
	case "=", "==":
		return left == right
	case "!=", "<>":
		return left != right
	case ">":
		return compare(left, right) > 0
	case "<":
		return compare(left, right) < 0
	case ">=":
		return compare(left, right) >= 0
	case "<=":
		return compare(left, right) <= 0
	case "like":
		pat := "^" + regexp.QuoteMeta(right) + "$"
		pat = strings.ReplaceAll(pat, "%", ".*")
		ok, _ := regexp.MatchString(pat, left)
		return ok
	}
	return false
}

func literalOrExpr(t table, r []string, s string) string {
	if len(s) >= 2 && ((s[0] == '\'' && s[len(s)-1] == '\'') || (s[0] == '"' && s[len(s)-1] == '"')) {
		return s[1 : len(s)-1]
	}
	return evalExpr(t, r, s)
}

func evalExpr(t table, r []string, expr string) string {
	expr = strings.TrimSpace(expr)
	if len(expr) >= 2 && ((expr[0] == '\'' && expr[len(expr)-1] == '\'') || (expr[0] == '"' && expr[len(expr)-1] == '"')) {
		return expr[1 : len(expr)-1]
	}
	if mm := regexp.MustCompile(`(?is)^upper\((.+)\)$`).FindStringSubmatch(expr); mm != nil {
		return strings.ToUpper(evalExpr(t, r, mm[1]))
	}
	if mm := regexp.MustCompile(`(?is)^lower\((.+)\)$`).FindStringSubmatch(expr); mm != nil {
		return strings.ToLower(evalExpr(t, r, mm[1]))
	}
	if mm := regexp.MustCompile(`(?is)^(.+)\s*([+\-*/])\s*(.+)$`).FindStringSubmatch(expr); mm != nil {
		a, _ := strconv.ParseFloat(evalExpr(t, r, mm[1]), 64)
		b, _ := strconv.ParseFloat(evalExpr(t, r, mm[3]), 64)
		var v float64
		switch mm[2] {
		case "+":
			v = a + b
		case "-":
			v = a - b
		case "*":
			v = a * b
		case "/":
			if b != 0 {
				v = a / b
			}
		}
		if v == float64(int64(v)) {
			return strconv.FormatInt(int64(v), 10)
		}
		return strconv.FormatFloat(v, 'f', -1, 64)
	}
	if idx := colIndex(t.cols, strings.Trim(expr, "`\"")); idx >= 0 && idx < len(r) {
		return r[idx]
	}
	return strings.Trim(expr, "`\"")
}

func colIndex(cols []string, name string) int {
	for i, c := range cols {
		if strings.EqualFold(c, name) {
			return i
		}
	}
	return -1
}

func compare(a, b string) int {
	return strings.Compare(a, b)
}

func cloneRows(in [][]string) [][]string {
	out := make([][]string, len(in))
	for i, r := range in {
		out[i] = append([]string{}, r...)
	}
	return out
}

func writeTable(t table, opt options) error {
	var w io.Writer = os.Stdout
	var f *os.File
	var err error
	if opt.out != "" {
		f, err = os.Create(opt.out)
		if err != nil {
			return err
		}
		defer f.Close()
		w = f
	}
	if opt.oz == "gz" {
		gz := gzip.NewWriter(w)
		defer gz.Close()
		w = gz
	}
	nl := "\n"
	if opt.crlf {
		nl = "\r\n"
	}
	format := opt.outFmt
	if format == "" {
		format = "csv"
	}
	switch format {
	case "json":
		return writeJSON(w, t, true, nl)
	case "jsonl":
		return writeJSONL(w, t, nl)
	case "ltsv":
		return writeLTSV(w, t, nl, opt)
	case "md":
		return writeMD(w, t, nl)
	case "at":
		return writeAT(w, t, nl)
	case "raw":
		return writeRaw(w, t, nl, opt)
	case "vf":
		return writeVF(w, t, nl)
	case "yaml":
		return writeYAML(w, t, nl)
	default:
		return writeCSV(w, t, nl, opt)
	}
}

func writeCSV(w io.Writer, t table, nl string, opt options) error {
	var buf bytes.Buffer
	cw := csv.NewWriter(&buf)
	if opt.od != "" {
		cw.Comma = []rune(opt.od)[0]
	}
	if opt.oh {
		_ = cw.Write(t.cols)
	}
	for _, r := range t.rows {
		row := mapNulls(r, opt)
		if opt.oaq {
			for i, v := range row {
				row[i] = v
			}
		}
		_ = cw.Write(row)
	}
	cw.Flush()
	s := buf.String()
	if nl == "\r\n" {
		s = strings.ReplaceAll(s, "\n", "\r\n")
	}
	_, err := io.WriteString(w, s)
	return err
}

func mapNulls(r []string, opt options) []string {
	out := append([]string{}, r...)
	for i, v := range out {
		if v == "" && opt.onull != "" {
			out[i] = opt.onull
		}
	}
	return out
}

func writeJSON(w io.Writer, t table, pretty bool, nl string) error {
	var arr []map[string]string
	for _, r := range t.rows {
		m := map[string]string{}
		for i, c := range t.cols {
			if i < len(r) {
				m[c] = r[i]
			}
		}
		arr = append(arr, m)
	}
	var b []byte
	var err error
	if pretty {
		b, err = json.MarshalIndent(arr, "", "  ")
	} else {
		b, err = json.Marshal(arr)
	}
	if err != nil {
		return err
	}
	_, err = io.WriteString(w, string(b)+nl)
	return err
}

func writeJSONL(w io.Writer, t table, nl string) error {
	for _, r := range t.rows {
		m := map[string]string{}
		for i, c := range t.cols {
			if i < len(r) {
				m[c] = r[i]
			}
		}
		b, _ := json.Marshal(m)
		if _, err := io.WriteString(w, string(b)+nl); err != nil {
			return err
		}
	}
	return nil
}

func writeLTSV(w io.Writer, t table, nl string, opt options) error {
	for _, r := range t.rows {
		var parts []string
		for i, c := range t.cols {
			v := ""
			if i < len(r) {
				v = r[i]
			}
			if v == "" && opt.onull != "" {
				v = opt.onull
			}
			parts = append(parts, c+":"+v)
		}
		if _, err := io.WriteString(w, strings.Join(parts, "\t")+nl); err != nil {
			return err
		}
	}
	return nil
}

func colWidths(t table) []int {
	w := make([]int, len(t.cols))
	for i, c := range t.cols {
		w[i] = len(c)
	}
	for _, r := range t.rows {
		for i, v := range r {
			if i < len(w) && len(v) > w[i] {
				w[i] = len(v)
			}
		}
	}
	return w
}

func writeMD(w io.Writer, t table, nl string) error {
	width := colWidths(t)
	line := func(vals []string) string {
		var b strings.Builder
		b.WriteString("|")
		for i, c := range vals {
			pad := width[i] - len(c)
			left := pad / 2
			right := pad - left
			b.WriteString(" " + strings.Repeat(" ", left) + c + strings.Repeat(" ", right) + " |")
		}
		return b.String()
	}
	if _, err := io.WriteString(w, line(t.cols)+nl); err != nil {
		return err
	}
	var b strings.Builder
	b.WriteString("|")
	for _, n := range width {
		b.WriteString(strings.Repeat("-", n+2) + "|")
	}
	if _, err := io.WriteString(w, b.String()+nl); err != nil {
		return err
	}
	for _, r := range t.rows {
		if _, err := io.WriteString(w, line(r)+nl); err != nil {
			return err
		}
	}
	return nil
}

func writeAT(w io.Writer, t table, nl string) error {
	width := colWidths(t)
	border := "+"
	for _, n := range width {
		border += strings.Repeat("-", n+2) + "+"
	}
	row := func(vals []string) string {
		var b strings.Builder
		b.WriteString("|")
		for i, c := range vals {
			pad := width[i] - len(c)
			left := pad / 2
			right := pad - left
			b.WriteString(" " + strings.Repeat(" ", left) + c + strings.Repeat(" ", right) + " |")
		}
		return b.String()
	}
	io.WriteString(w, border+nl)
	io.WriteString(w, row(t.cols)+nl)
	io.WriteString(w, border+nl)
	for _, r := range t.rows {
		io.WriteString(w, row(r)+nl)
	}
	_, err := io.WriteString(w, border+nl)
	return err
}

func writeRaw(w io.Writer, t table, nl string, opt options) error {
	if opt.oh {
		io.WriteString(w, strings.Join(t.cols, opt.od)+nl)
	}
	for _, r := range t.rows {
		io.WriteString(w, strings.Join(r, opt.od)+nl)
	}
	return nil
}

func writeVF(w io.Writer, t table, nl string) error {
	for ri, r := range t.rows {
		if ri > 0 {
			io.WriteString(w, nl)
		}
		for i, c := range t.cols {
			v := ""
			if i < len(r) {
				v = r[i]
			}
			io.WriteString(w, fmt.Sprintf("%s: %s%s", c, v, nl))
		}
	}
	return nil
}

func writeYAML(w io.Writer, t table, nl string) error {
	for _, r := range t.rows {
		io.WriteString(w, "-")
		if len(t.cols) == 0 {
			io.WriteString(w, nl)
			continue
		}
		io.WriteString(w, nl)
		for i, c := range t.cols {
			v := ""
			if i < len(r) {
				v = r[i]
			}
			io.WriteString(w, fmt.Sprintf("  %s: %s%s", c, v, nl))
		}
	}
	return nil
}

func printSimpleAT(cols []string, rows [][]string) {
	_ = writeAT(os.Stdout, table{cols, rows}, "\n")
}

func typeRows(cols []string) [][]string {
	var rows [][]string
	for _, c := range cols {
		rows = append(rows, []string{c, "text"})
	}
	return rows
}

func buildExamples(file string, cols []string) string {
	if len(cols) == 0 {
		cols = []string{"c1"}
	}
	c1 := cols[0]
	c2 := c1
	if len(cols) > 1 {
		c2 = cols[1]
	}
	return fmt.Sprintf("./executable \"SELECT %s, %s FROM %s\"\n./executable \"SELECT %s, %s FROM %s WHERE %s = 'a'\"\n./executable \"SELECT %s, count(%s) FROM %s GROUP BY %s\"\n./executable \"SELECT %s, %s FROM %s ORDER BY %s LIMIT 10\"\n", c1, c2, file, c1, c2, file, c1, c1, c1, file, c1, c1, c2, file, c1)
}

func fatal(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func init() {
	// Keep imports useful when builds use older stripping rules.
	_ = bufio.ErrInvalidUnreadByte
	_ = tabwriter.Debug
}
