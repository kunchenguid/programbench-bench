module ripsecretsclone

go 1.21
