package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type options struct {
	installPreCommit bool
	strictIgnore     bool
	onlyMatching     bool
	additional       []string
	paths            []string
}

type ignoreRules struct {
	patterns []string
	secrets  map[string]bool
}

type finding struct {
	path  string
	line  int
	text  string
	match string
}

var builtins = []*regexp.Regexp{
	regexp.MustCompile(`AKIA[0-9A-Z]{16}`),
	regexp.MustCompile(`ASIA[0-9A-Z]{16}`),
	regexp.MustCompile(`A3T[A-Z0-9]{16}`),
	regexp.MustCompile(`ghp_[A-Za-z0-9_]{30,}`),
	regexp.MustCompile(`gho_[A-Za-z0-9_]{30,}`),
	regexp.MustCompile(`ghu_[A-Za-z0-9_]{30,}`),
	regexp.MustCompile(`ghs_[A-Za-z0-9_]{30,}`),
	regexp.MustCompile(`ghr_[A-Za-z0-9_]{30,}`),
	regexp.MustCompile(`github_pat_[A-Za-z0-9_]{36,}`),
	regexp.MustCompile(`glpat-[A-Za-z0-9_-]{20,}`),
	regexp.MustCompile(`xox[baprs]-[A-Za-z0-9-]{20,}`),
	regexp.MustCompile(`AIza[0-9A-Za-z_-]{20,}`),
	regexp.MustCompile(`(?i)(?:key|api[_-]?key|secret|token|password|passwd|pwd|client[_-]?secret|access[_-]?key)[A-Za-z0-9_ .:'"=-]{0,40}[:=][ \t]*["']?([A-Za-z0-9_./+=:-]{16,})["']?`),
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(2)
	}
	if opts.installPreCommit {
		if err := installHook(opts.paths); err != nil {
			fmt.Fprintln(os.Stderr, err.Error())
			os.Exit(1)
		}
		return
	}
	if len(opts.paths) == 0 {
		opts.paths = []string{"."}
	}

	addRegs := make([]*regexp.Regexp, 0, len(opts.additional))
	for _, pat := range opts.additional {
		re, err := regexp.Compile(pat)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: invalid regex %q: %v\n", pat, err)
			os.Exit(2)
		}
		addRegs = append(addRegs, re)
	}

	rules := readIgnore(".secretsignore")
	findings := []finding{}
	for _, p := range opts.paths {
		scanPath(p, opts, rules, addRegs, &findings)
	}
	for _, f := range findings {
		out := f.text
		if opts.onlyMatching {
			out = f.match
		}
		fmt.Printf("%s:%d:%s\n", f.path, f.line, out)
	}
	if len(findings) > 0 {
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, error) {
	var o options
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h":
			printShortHelp()
			os.Exit(0)
		case "--help":
			printLongHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("ripsecrets 0.1.11")
			os.Exit(0)
		case "--install-pre-commit":
			o.installPreCommit = true
		case "--strict-ignore":
			o.strictIgnore = true
		case "--only-matching":
			o.onlyMatching = true
		case "--additional-pattern":
			if i+1 >= len(args) {
				return o, errors.New("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied")
			}
			i++
			o.additional = append(o.additional, args[i])
		default:
			if strings.HasPrefix(a, "--additional-pattern=") {
				o.additional = append(o.additional, strings.TrimPrefix(a, "--additional-pattern="))
			} else if strings.HasPrefix(a, "-") {
				return o, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [Source files]...\n\nFor more information, try '--help'.", a)
			} else {
				o.paths = append(o.paths, a)
			}
		}
	}
	return o, nil
}

func printShortHelp() {
	fmt.Println("A command-line tool to prevent committing secret keys into your source code")
	fmt.Println()
	fmt.Println("Usage: executable [OPTIONS] [Source files]...")
	fmt.Println()
	fmt.Println("Arguments:")
	fmt.Println("  [Source files]...  Source files. Can be files or directories. Defaults to '.'")
	fmt.Println()
	fmt.Println("Options:")
	fmt.Println("      --install-pre-commit")
	fmt.Println("          Install `ripsecrets` as a pre-commit hook automatically in git directory provided")
	fmt.Println("      --strict-ignore")
	fmt.Println("          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit")
	fmt.Println("      --only-matching")
	fmt.Println("          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line")
	fmt.Println("      --additional-pattern <ADDITIONAL_PATTERNS>")
	fmt.Println("          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret")
	fmt.Println("  -h, --help")
	fmt.Println("          Print help (see more with '--help')")
	fmt.Println("  -V, --version")
	fmt.Println("          Print version")
}

func printLongHelp() {
	fmt.Println("ripsecrets searches files and directories recursively for secret API keys.")
	fmt.Println("It's primarily designed to be used as a pre-commit to prevent committing")
	fmt.Println("secrets into version control.")
	fmt.Println()
	fmt.Println("Usage: executable [OPTIONS] [Source files]...")
	fmt.Println()
	fmt.Println("Arguments:")
	fmt.Println("  [Source files]...")
	fmt.Println("          Source files. Can be files or directories. Defaults to '.'")
	fmt.Println()
	fmt.Println("Options:")
	fmt.Println("      --install-pre-commit")
	fmt.Println("          Install `ripsecrets` as a pre-commit hook automatically in git directory provided")
	fmt.Println()
	fmt.Println("      --strict-ignore")
	fmt.Println("          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit")
	fmt.Println()
	fmt.Println("      --only-matching")
	fmt.Println("          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line")
	fmt.Println()
	fmt.Println("      --additional-pattern <ADDITIONAL_PATTERNS>")
	fmt.Println("          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret")
	fmt.Println()
	fmt.Println("  -h, --help")
	fmt.Println("          Print help (see a summary with '-h')")
	fmt.Println()
	fmt.Println("  -V, --version")
	fmt.Println("          Print version")
}

func installHook(paths []string) error {
	dir := "."
	if len(paths) > 0 {
		dir = paths[0]
	}
	hookDir := filepath.Join(dir, ".git", "hooks")
	if st, err := os.Stat(hookDir); err != nil || !st.IsDir() {
		return fmt.Errorf("%s: No such file or directory (os error 2)", hookDir)
	}
	hook := filepath.Join(hookDir, "pre-commit")
	return os.WriteFile(hook, []byte("ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n"), 0755)
}

func readIgnore(path string) ignoreRules {
	r := ignoreRules{secrets: map[string]bool{}}
	f, err := os.Open(path)
	if err != nil {
		return r
	}
	defer f.Close()
	section := "patterns"
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.EqualFold(line, "[secrets]") {
			section = "secrets"
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = "patterns"
			continue
		}
		if section == "secrets" {
			r.secrets[line] = true
		} else {
			r.patterns = append(r.patterns, line)
		}
	}
	return r
}

func scanPath(path string, opts options, rules ignoreRules, addRegs []*regexp.Regexp, findings *[]finding) {
	explicit := path != "."
	if opts.strictIgnore && ignored(path, rules) {
		return
	}
	info, err := os.Stat(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s: %v\n", path, err)
		return
	}
	if !info.IsDir() {
		if (!explicit || opts.strictIgnore) && ignored(path, rules) {
			return
		}
		scanFile(path, rules, addRegs, findings)
		return
	}
	filepath.WalkDir(path, func(p string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if p != path {
			name := d.Name()
			if d.IsDir() && (name == ".git" || name == "node_modules" || name == "target" || name == "vendor") {
				return filepath.SkipDir
			}
			if ignored(p, rules) {
				if d.IsDir() {
					return filepath.SkipDir
				}
				return nil
			}
		}
		if !d.IsDir() {
			scanFile(p, rules, addRegs, findings)
		}
		return nil
	})
}

func ignored(path string, rules ignoreRules) bool {
	clean := filepath.ToSlash(filepath.Clean(path))
	base := filepath.Base(clean)
	for _, pat := range rules.patterns {
		p := filepath.ToSlash(strings.TrimSpace(pat))
		neg := strings.HasPrefix(p, "!")
		if neg {
			p = strings.TrimPrefix(p, "!")
		}
		matched := false
		if strings.HasSuffix(p, "/") {
			prefix := strings.TrimSuffix(p, "/")
			matched = clean == prefix || strings.HasPrefix(clean, prefix+"/") || strings.Contains(clean, "/"+prefix+"/")
		} else if strings.ContainsAny(p, "*?[）") {
			matched, _ = filepath.Match(p, clean)
			if !matched {
				matched, _ = filepath.Match(p, base)
			}
		} else if strings.Contains(p, "/") {
			matched = clean == strings.TrimPrefix(p, "/") || strings.HasSuffix(clean, "/"+strings.TrimPrefix(p, "/"))
		} else {
			matched = base == p || clean == p || strings.HasSuffix(clean, "/"+p)
		}
		if matched {
			return !neg
		}
	}
	return false
}

func scanFile(path string, rules ignoreRules, addRegs []*regexp.Regexp, findings *[]finding) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	br := bufio.NewReader(f)
	lineNo := 0
	for {
		line, err := br.ReadString('\n')
		if len(line) > 0 {
			lineNo++
			line = strings.TrimRight(line, "\r\n")
			if strings.IndexByte(line, 0) >= 0 {
				return
			}
			matches := lineMatches(line, addRegs)
			seenLine := false
			for _, m := range matches {
				if m == "" || rules.secrets[m] || rules.secrets[strings.Trim(m, "\"'")] {
					continue
				}
				if !seenLine {
					*findings = append(*findings, finding{path: displayPath(path), line: lineNo, text: line, match: m})
					seenLine = true
				} else {
					*findings = append(*findings, finding{path: displayPath(path), line: lineNo, text: line, match: m})
				}
			}
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			break
		}
	}
}

func displayPath(p string) string {
	if rel, err := filepath.Rel(".", p); err == nil && !strings.HasPrefix(rel, "..") {
		return filepath.ToSlash(rel)
	}
	return filepath.ToSlash(p)
}

func lineMatches(line string, addRegs []*regexp.Regexp) []string {
	out := []string{}
	for _, re := range builtins {
		found := re.FindAllStringSubmatch(line, -1)
		for _, sm := range found {
			candidate := sm[0]
			if len(sm) > 1 && sm[1] != "" {
				candidate = sm[1]
			}
			if knownToken(candidate) || suspicious(candidate) {
				out = append(out, candidate)
			}
		}
	}
	for _, re := range addRegs {
		found := re.FindAllStringSubmatch(line, -1)
		for _, sm := range found {
			candidate := sm[0]
			if len(sm) > 1 {
				for _, g := range sm[1:] {
					if g != "" {
						candidate = g
						break
					}
				}
			}
			if suspicious(candidate) || knownToken(candidate) {
				out = append(out, candidate)
			}
		}
	}
	return unique(out)
}

func knownToken(s string) bool {
	prefixes := []string{"AKIA", "ASIA", "ghp_", "gho_", "ghu_", "ghs_", "ghr_", "github_pat_", "glpat-", "xoxb-", "xoxp-", "xoxa-", "AIza"}
	for _, p := range prefixes {
		if strings.HasPrefix(s, p) {
			return true
		}
	}
	return false
}

func suspicious(s string) bool {
	s = strings.Trim(s, "\"'` ,;")
	if len(s) < 16 || len(s) > 4096 {
		return false
	}
	lower := strings.ToLower(s)
	boring := []string{"example", "changeme", "password", "secret", "dummy", "sample", "localhost", "000000000000", "111111111111", "abcdefghijklmnop"}
	for _, b := range boring {
		if strings.Contains(lower, b) && entropy(s) < 4.0 {
			return false
		}
	}
	classes := 0
	if regexp.MustCompile(`[a-z]`).MatchString(s) {
		classes++
	}
	if regexp.MustCompile(`[A-Z]`).MatchString(s) {
		classes++
	}
	if regexp.MustCompile(`[0-9]`).MatchString(s) {
		classes++
	}
	if regexp.MustCompile(`[+/=_:.-]`).MatchString(s) {
		classes++
	}
	if classes < 2 {
		return false
	}
	return entropy(s) >= 3.35
}

func entropy(s string) float64 {
	counts := map[rune]int{}
	n := 0
	for _, r := range s {
		counts[r]++
		n++
	}
	if n == 0 {
		return 0
	}
	e := 0.0
	for _, c := range counts {
		p := float64(c) / float64(n)
		e -= p * math.Log2(p)
	}
	return e
}

func unique(in []string) []string {
	m := map[string]bool{}
	out := []string{}
	for _, s := range in {
		if !m[s] {
			m[s] = true
			out = append(out, s)
		}
	}
	sort.SliceStable(out, func(i, j int) bool { return len(out[i]) > len(out[j]) })
	return out
}
