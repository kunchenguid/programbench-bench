module treesitterclone

go 1.21
