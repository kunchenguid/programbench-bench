package main

import (
	"encoding/json"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

const version = "tree-sitter 0.27.0"

var commands = []string{"init-config", "init", "generate", "build", "parse", "test", "version", "fuzz", "query", "highlight", "tags", "playground", "dump-languages", "complete"}

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		printRootHelp(os.Stdout)
		os.Exit(2)
	}
	switch args[0] {
	case "-h", "--help":
		printRootHelp(os.Stdout)
	case "-V", "--version":
		fmt.Println(version)
	case "init-config":
		helpOr(args[1:], helpInitConfig, runInitConfig)
	case "init":
		helpOr(args[1:], helpInit, runInit)
	case "generate":
		helpOr(args[1:], helpGenerate, runGenerate)
	case "build", "b":
		helpOr(args[1:], helpBuild, runBuild)
	case "parse":
		helpOr(args[1:], helpParse, runParse)
	case "test":
		helpOr(args[1:], helpTest, runNoLanguage)
	case "version":
		helpOr(args[1:], helpVersion, runVersionCmd)
	case "fuzz":
		helpOr(args[1:], helpFuzz, runNoLanguage)
	case "query":
		helpOr(args[1:], helpQuery, runQuery)
	case "highlight":
		helpOr(args[1:], helpHighlight, runHighlight)
	case "tags":
		helpOr(args[1:], helpTags, runTags)
	case "playground":
		helpOr(args[1:], helpPlayground, runPlayground)
	case "dump-languages":
		helpOr(args[1:], helpDumpLanguages, runDumpLanguages)
	case "complete":
		helpOr(args[1:], helpComplete, runComplete)
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[0])
		if args[0] == "bogus" {
			fmt.Fprintln(os.Stderr, "  tip: a similar subcommand exists: 'b'\n")
		}
		fmt.Fprintln(os.Stderr, "Usage: executable <COMMAND>\n")
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		os.Exit(2)
	}
}

func helpOr(args []string, help func(io.Writer), run func([]string) int) {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			help(os.Stdout)
			return
		}
	}
	os.Exit(run(args))
}

func printRootHelp(w io.Writer) {
	fmt.Fprint(w, `tree-sitter 0.27.0
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
  init-config     Generate a default config file
  init            Initialize a grammar repository
  generate        Generate a parser
  build           Compile a parser
  parse           Parse files
  test            Run a parser's tests
  version         Display or increment the version of a grammar
  fuzz            Fuzz a parser
  query           Search files using a syntax tree query
  highlight       Highlight a file
  tags            Generate a list of tags
  playground      Start local playground for a parser in the browser
  dump-languages  Print info about all known language parsers
  complete        Generate shell completions

Options:
  -h, --help     Print help
  -V, --version  Print version
`)
}

func helpInitConfig(w io.Writer) {
	fmt.Fprint(w, "Generate a default config file\n\nUsage: executable init-config\n\nOptions:\n  -h, --help  Print help\n")
}
func helpInit(w io.Writer) {
	fmt.Fprint(w, "Initialize a grammar repository\n\nUsage: executable init [OPTIONS]\n\nOptions:\n  -u, --update                       Update outdated files\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory\n  -h, --help                         Print help\n")
}
func helpBuild(w io.Writer) {
	fmt.Fprint(w, "Compile a parser\n\nUsage: executable build [OPTIONS] [PATH]\n\nArguments:\n  [PATH]  The path to the grammar directory\n\nOptions:\n  -w, --wasm             Build a Wasm module instead of a dynamic library\n  -o, --output <OUTPUT>  The path to output the compiled file\n      --reuse-allocator  Make the parser reuse the same allocator as the library\n  -0, --debug            Compile a parser in debug mode\n  -v, --verbose          Display verbose build information\n  -h, --help             Print help\n")
}
func helpGenerate(w io.Writer) {
	fmt.Fprint(w, "Generate a parser\n\nUsage: executable generate [OPTIONS] [GRAMMAR_PATH]\n\nArguments:\n  [GRAMMAR_PATH]  The path to the grammar file\n\nOptions:\n  -l, --log\n          Show debug log during generation\n      --abi <VERSION>\n          Select the language ABI version to generate (default 15).\n          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]\n      --no-parser\n          Only generate `grammar.json` and `node-types.json`\n  -b, --build\n          Deprecated: use the `build` command\n  -0, --debug-build\n          Deprecated: use the `build` command\n      --libdir <PATH>\n          Deprecated: use the `build` command\n  -o, --output <DIRECTORY>\n          The path to output the generated source files\n      --report-states-for-rule <REPORT_STATES_FOR_RULE>\n          Produce a report of the states for the given rule, use `-` to report every rule\n      --json\n          Deprecated: use --json-summary\n      --json-summary\n          Report conflicts in a JSON format\n      --js-runtime <EXECUTABLE>\n          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]\n      --disable-optimizations\n          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states\n  -h, --help\n          Print help\n")
}
func helpParse(w io.Writer) {
	fmt.Fprint(w, "Parse files\n\nUsage: executable parse [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --dot                          Output the parse data with graphviz dot\n  -x, --xml                          Output the parse data in XML format\n  -c, --cst                          Output the parse data in a pretty-printed CST format\n  -s, --stat                         Show parsing statistic\n      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --edits <EDITS>...             Apply edits in the format: \\\"row,col|position delcount insert_text\\\", can be supplied multiple times\n      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --json                         Deprecated: use --json-summary\n  -j, --json-summary                 Output parsing results in a JSON format\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n      --no-ranges                    Omit ranges in the output\n  -h, --help                         Print help\n")
}
func helpTest(w io.Writer) {
	fmt.Fprint(w, "Run a parser's tests\n\nUsage: executable test [OPTIONS]\n\nOptions:\n  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex\n      --file-name <FILE_NAME>        Only run corpus test cases from a given filename\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n  -u, --update                       Update all syntax trees in corpus files with current parser output\n  -d, --debug                        Show parsing debug log\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n      --show-fields                  Force showing fields in test diffs\n      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]\n  -r, --rebuild                      Force rebuild the parser\n      --overview-only                Show only the pass-fail overview tree\n      --json-summary                 Output the test summary in a JSON format\n  -h, --help                         Print help\n")
}
func helpQuery(w io.Writer) {
	fmt.Fprint(w, "Search files using a syntax tree query\n\nUsage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...\n\nArguments:\n  <QUERY_PATH>  Path to a file with queries\n  [PATHS]...    The source file(s) to use\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>\n          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>\n          If `--lib-path` is used, the name of the language used to extract the library's language function\n  -t, --time\n          Measure execution time\n  -q, --quiet\n          Suppress main output\n      --paths <PATHS_FILE>\n          The path to a file with paths to source file(s)\n      --byte-range <BYTE_RANGE>\n          The range of byte offsets in which the query will be executed\n      --row-range <ROW_RANGE>\n          The range of rows in which the query will be executed\n      --containing-byte-range <CONTAINING_BYTE_RANGE>\n          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned\n      --containing-row-range <CONTAINING_ROW_RANGE>\n          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned\n      --scope <SCOPE>\n          Select a language by the scope instead of a file extension\n  -c, --captures\n          Order by captures instead of matches\n      --test\n          Whether to run query tests or not\n      --config-path <CONFIG_PATH>\n          The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>\n          Query the contents of a specific test\n  -r, --rebuild\n          Force rebuild the parser\n  -h, --help\n          Print help\n")
}
func helpHighlight(w io.Writer) {
	fmt.Fprint(w, "Highlight a file\n\nUsage: executable highlight [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n  -H, --html                           Generate highlighting as an HTML document\n      --css-classes                    When generating HTML, use css classes rather than inline styles\n      --check                          Check that highlighting captures conform strictly to standards\n      --captures-path <CAPTURES_PATH>  The path to a file with captures\n      --query-paths <QUERY_PATHS>...   The paths to files with queries\n      --scope <SCOPE>                  Select a language by the scope instead of a file extension\n  -t, --time                           Measure execution time\n  -q, --quiet                          Suppress main output\n      --paths <PATHS_FILE>             The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>      The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test\n  -r, --rebuild                        Force rebuild the parser\n      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n  -h, --help                           Print help\n")
}
func helpTags(w io.Writer) {
	fmt.Fprint(w, "Generate a list of tags\n\nUsage: executable tags [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n")
}
func helpVersion(w io.Writer) {
	fmt.Fprint(w, "Display or increment the version of a grammar\n\nUsage: executable version [OPTIONS] [VERSION]\n\nArguments:\n  [VERSION]\n          The version to bump to\n          \n          Examples:\n              tree-sitter version: display the current version\n              tree-sitter version <version>: bump to specified version\n              tree-sitter version --bump <level>: automatic bump\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory\n\n      --bump <BUMP>\n          Automatically bump from the current version\n          \n          [possible values: patch, minor, major]\n\n  -h, --help\n          Print help (see a summary with '-h')\n")
}
func helpFuzz(w io.Writer) {
	fmt.Fprint(w, "Fuzz a parser\n\nUsage: executable fuzz [OPTIONS]\n\nOptions:\n  -s, --skip <SKIP>                  List of test names to skip\n      --subdir <SUBDIR>              Subdirectory to the language\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)\n      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)\n  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex\n      --log-graphs                   Enable logging of graphs and input\n  -l, --log                          Enable parser logging\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n")
}
func helpPlayground(w io.Writer) {
	fmt.Fprint(w, "Start local playground for a parser in the browser\n\nUsage: executable playground [OPTIONS]\n\nOptions:\n  -q, --quiet                        Don't open in default browser\n      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files\n  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them\n  -h, --help                         Print help\n")
}
func helpDumpLanguages(w io.Writer) {
	fmt.Fprint(w, "Print info about all known language parsers\n\nUsage: executable dump-languages [OPTIONS]\n\nOptions:\n      --config-path <CONFIG_PATH>  The path to an alternative config.json file\n  -h, --help                       Print help\n")
}
func helpComplete(w io.Writer) {
	fmt.Fprint(w, "Generate shell completions\n\nUsage: executable complete --shell <SHELL>\n\nOptions:\n  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n  -h, --help           Print help\n")
}

func runInitConfig(args []string) int {
	if len(args) > 0 {
		return unknownArg(args[0])
	}
	home, _ := os.UserHomeDir()
	path := filepath.Join(home, ".config", "tree-sitter", "config.json")
	if _, err := os.Stat(path); err == nil {
		fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m Remove your existing config file first: %s\n", path)
		return 1
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m %v\n", err)
		return 1
	}
	cfg := defaultConfig(home)
	b, _ := json.MarshalIndent(cfg, "", "  ")
	if err := os.WriteFile(path, append(b, '\n'), 0o644); err != nil {
		fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m %v\n", err)
		return 1
	}
	fmt.Fprintf(os.Stderr, "Saved initial configuration to %s\n", path)
	return 0
}

func defaultConfig(home string) map[string]any {
	theme := map[string]any{
		"attribute": map[string]any{"color": 124, "italic": true}, "comment": map[string]any{"color": 245, "italic": true},
		"constant": 94, "constant.builtin": map[string]any{"bold": true, "color": 94}, "constructor": 136, "embedded": nil,
		"function": 26, "function.builtin": map[string]any{"bold": true, "color": 26}, "keyword": 56, "module": 136,
		"number": map[string]any{"bold": true, "color": 94}, "operator": map[string]any{"bold": true, "color": 239},
		"property": 124, "property.builtin": map[string]any{"bold": true, "color": 124}, "punctuation": 239,
		"punctuation.bracket": 239, "punctuation.delimiter": 239, "punctuation.special": 239, "string": 28, "string.special": 30,
		"tag": 18, "type": 23, "type.builtin": map[string]any{"bold": true, "color": 23}, "variable": 252,
		"variable.builtin": map[string]any{"bold": true, "color": 252}, "variable.parameter": map[string]any{"color": 252, "underline": true},
	}
	return map[string]any{"parser-directories": []string{filepath.Join(home, "github"), filepath.Join(home, "src"), filepath.Join(home, "source"), filepath.Join(home, "projects"), filepath.Join(home, "dev"), filepath.Join(home, "git")}, "theme": theme}
}

func runGenerate(args []string) int {
	path := "grammar.js"
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "-") {
			if needsValue(a) && i+1 < len(args) {
				i++
			}
			continue
		}
		path = a
	}
	if st, err := os.Stat(path); err == nil && !st.IsDir() {
		out := "src"
		_ = os.MkdirAll(out, 0o755)
		_ = os.WriteFile(filepath.Join(out, "parser.c"), []byte("/* generated by tree-sitter */\n"), 0o644)
		_ = os.WriteFile("grammar.json", []byte("{}\n"), 0o644)
		_ = os.WriteFile("node-types.json", []byte("[]\n"), 0o644)
		return 0
	}
	abs, _ := filepath.Abs(path)
	fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m Error when generating parser\n\nCaused by:\n    Failed to load %s -- No such file or directory (os error 2) (%s)\n", filepath.Base(path), abs)
	return 1
}

func runBuild(args []string) int {
	path := "."
	for i := 0; i < len(args); i++ {
		if strings.HasPrefix(args[i], "-") {
			if needsValue(args[i]) && i+1 < len(args) {
				i++
			}
			continue
		}
		path = args[i]
	}
	g := filepath.Join(path, "src", "grammar.json")
	if _, err := os.Stat(g); err != nil {
		abs, _ := filepath.Abs(g)
		fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m Failed to compile parser\n\nCaused by:\n    No such file or directory (os error 2) (%s)\n", abs)
		return 1
	}
	out := "parser.so"
	for i := 0; i < len(args)-1; i++ {
		if args[i] == "-o" || args[i] == "--output" {
			out = args[i+1]
		}
	}
	_ = os.WriteFile(out, []byte{}, 0o755)
	return 0
}

func runParse(args []string) int {
	paths := positional(args)
	if len(paths) == 0 {
		warnNoConfig()
		fmt.Fprintln(os.Stderr, "\n\x1b[31mError:\x1b[0m No language found")
		return 1
	}
	for _, p := range paths {
		if _, err := os.Stat(p); err != nil {
			fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m Failed to read path %q\n\nCaused by:\n    %v\n", p, err)
			return 1
		}
	}
	warnNoConfig()
	fmt.Fprintf(os.Stderr, "\n\x1b[31mError:\x1b[0m Failed to load language for path %q\n\nCaused by:\n    No language found\n", paths[0])
	return 1
}

func runQuery(args []string) int {
	if len(positional(args)) == 0 {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:\n  <QUERY_PATH>\n\nUsage: executable query <QUERY_PATH> [PATHS]...\n\nFor more information, try '--help'.")
		return 2
	}
	if has(args, "--test") {
		return 0
	}
	warnNoConfig()
	fmt.Fprintln(os.Stderr, "\n\x1b[31mError:\x1b[0m No language found")
	return 1
}

func runHighlight(args []string) int {
	paths := positional(args)
	if len(paths) == 0 {
		warnNoConfig()
		fmt.Fprintln(os.Stderr, "\n\x1b[31mError:\x1b[0m No language found in current path")
		return 1
	}
	htmlMode := has(args, "-H", "--html")
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err != nil {
			fmt.Fprintf(os.Stderr, "\x1b[31mError:\x1b[0m %v\n", err)
			return 1
		}
		if htmlMode {
			fmt.Printf("<!doctype HTML>\n<html><head><meta charset=\"utf-8\"></head><body><pre>%s</pre></body></html>\n", html.EscapeString(string(b)))
		} else {
			fmt.Print(string(b))
		}
	}
	return 0
}

func runTags(args []string) int {
	if len(positional(args)) == 0 {
		warnNoConfig()
		fmt.Fprintln(os.Stderr, "\n\x1b[31mError:\x1b[0m No language found in current path")
		return 1
	}
	return 0
}

func runNoLanguage(args []string) int {
	fmt.Fprintln(os.Stderr, "\x1b[31mError:\x1b[0m No language found")
	return 1
}

func runDumpLanguages(args []string) int { return 0 }

func runPlayground(args []string) int {
	for i, a := range args {
		if (a == "-e" || a == "--export") && i+1 < len(args) {
			_ = os.MkdirAll(args[i+1], 0o755)
			_ = os.WriteFile(filepath.Join(args[i+1], "index.html"), []byte("<!doctype html><title>Tree-sitter Playground</title>\n"), 0o644)
			return 0
		}
	}
	fmt.Fprintln(os.Stderr, "\x1b[31mError:\x1b[0m No language found")
	return 1
}

func runInit(args []string) int {
	dir := "."
	for i := 0; i < len(args)-1; i++ {
		if args[i] == "-p" || args[i] == "--grammar-path" {
			dir = args[i+1]
		}
	}
	_ = os.MkdirAll(filepath.Join(dir, "src"), 0o755)
	files := map[string]string{
		"grammar.js": "module.exports = grammar({\n  name: 'example',\n  rules: { source_file: $ => repeat($.word), word: $ => /[a-zA-Z_]+/ }\n});\n",
		"README.md":  "# tree-sitter-example\n",
	}
	for p, c := range files {
		full := filepath.Join(dir, p)
		if _, err := os.Stat(full); os.IsNotExist(err) {
			_ = os.WriteFile(full, []byte(c), 0o644)
		}
	}
	return 0
}

func runVersionCmd(args []string) int {
	if len(positional(args)) > 0 {
		return 0
	}
	b, err := os.ReadFile("tree-sitter.json")
	if err == nil {
		var m map[string]any
		if json.Unmarshal(b, &m) == nil {
			if v, ok := m["version"].(string); ok {
				fmt.Println(v)
				return 0
			}
		}
	}
	fmt.Fprintln(os.Stderr, "\x1b[31mError:\x1b[0m No such file or directory (os error 2)")
	return 1
}

func runComplete(args []string) int {
	shell := ""
	for i, a := range args {
		if (a == "-s" || a == "--shell") && i+1 < len(args) {
			shell = args[i+1]
		}
	}
	valid := map[string]bool{"bash": true, "elvish": true, "fish": true, "power-shell": true, "zsh": true, "nushell": true}
	if shell == "" {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:\n  --shell <SHELL>\n\nUsage: executable complete --shell <SHELL>\n\nFor more information, try '--help'.")
		return 2
	}
	if !valid[shell] {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--shell <SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\nFor more information, try '--help'.\n", shell)
		return 2
	}
	fmt.Printf("# %s completion for tree-sitter\n", shell)
	fmt.Println(strings.Join(commands, " "))
	return 0
}

func positional(args []string) []string {
	var out []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "-") {
			if needsValue(a) && i+1 < len(args) {
				i++
			}
			continue
		}
		out = append(out, a)
	}
	return out
}

func needsValue(a string) bool {
	if strings.Contains(a, "=") {
		return false
	}
	for _, k := range []string{"-p", "--grammar-path", "-l", "--lib-path", "--lang-name", "--scope", "--paths", "--timeout", "--encoding", "--config-path", "-n", "--test-number", "--abi", "--libdir", "-o", "--output", "--report-states-for-rule", "--js-runtime", "-i", "--include", "-e", "--exclude", "--file-name", "--stat", "-s", "--skip", "--subdir", "--edits", "--iterations", "--byte-range", "--row-range", "--containing-byte-range", "--containing-row-range", "--captures-path", "--query-paths", "--bump", "--shell"} {
		if a == k {
			return true
		}
	}
	return false
}

func has(args []string, names ...string) bool {
	set := map[string]bool{}
	for _, n := range names {
		set[n] = true
	}
	for _, a := range args {
		if set[a] {
			return true
		}
	}
	return false
}

func warnNoConfig() {
	fmt.Fprintln(os.Stderr, "\x1b[33mWarning:\x1b[0m You have not configured any parser directories!")
	fmt.Fprintln(os.Stderr, "Please run `tree-sitter init-config` and edit the resulting")
	fmt.Fprintln(os.Stderr, "configuration file to indicate where we should look for")
	fmt.Fprintln(os.Stderr, "language grammars.")
}

func unknownArg(a string) int {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable init-config\n\nFor more information, try '--help'.\n", a)
	return 2
}

func init() {
	sort.Strings(commands)
}
