package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

type Stats struct {
	Blanks   int              `json:"blanks"`
	Code     int              `json:"code"`
	Comments int              `json:"comments"`
	Blobs    map[string]Stats `json:"blobs"`
}

type Report struct {
	Stats Stats  `json:"stats"`
	Name  string `json:"name"`
}

type Language struct {
	Blanks     int                 `json:"blanks"`
	Code       int                 `json:"code"`
	Comments   int                 `json:"comments"`
	Reports    []Report            `json:"reports"`
	Children   map[string][]Report `json:"children"`
	Inaccurate bool                `json:"inaccurate"`
}

type FileReport struct {
	Lang string
	Path string
	Stat Stats
}

type Options struct {
	inputs      []string
	excludes    []string
	types       map[string]bool
	files       bool
	hidden      bool
	noIgnore    bool
	languages   bool
	compact     bool
	output      string
	input       string
	streaming   string
	sortKey     string
	reverseSort string
	numFormat   string
	verbose     int
	columns     string
	showHelp    bool
	showVersion bool
}

type Rule struct {
	Name       string
	Exts       []string
	Names      []string
	Line       []string
	BlockStart string
	BlockEnd   string
	Nested     bool
	Text       bool
	Markdown   bool
}

var rules = []Rule{
	{Name: "ABNF", Exts: []string{"abnf"}, Line: []string{";"}},
	{Name: "AWK", Exts: []string{"awk"}, Line: []string{"#"}},
	{Name: "ABAP", Exts: []string{"abap"}, Line: []string{"*"}},
	{Name: "ActionScript", Exts: []string{"as"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Ada", Exts: []string{"ada", "adb", "ads", "pad"}, Line: []string{"--"}},
	{Name: "Agda", Exts: []string{"agda"}, Line: []string{"--"}, BlockStart: "{-", BlockEnd: "-}", Nested: true},
	{Name: "Alex", Exts: []string{"x"}, Line: []string{"--"}, BlockStart: "{-", BlockEnd: "-}", Nested: true},
	{Name: "Alloy", Exts: []string{"als"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "APL", Exts: []string{"apl", "aplf", "apls"}, Line: []string{"⍝"}},
	{Name: "Arduino C++", Exts: []string{"ino"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Ark TypeScript", Exts: []string{"ets"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "AsciiDoc", Exts: []string{"adoc", "asciidoc"}, Text: true},
	{Name: "ASN.1", Exts: []string{"asn1"}, Line: []string{"--"}},
	{Name: "ASP", Exts: []string{"asa", "asp"}, Line: []string{"'"}},
	{Name: "Assembly", Exts: []string{"asm"}, Line: []string{";", "#"}},
	{Name: "GNU Style Assembly", Exts: []string{"s"}, Line: []string{";", "#"}},
	{Name: "Astro", Exts: []string{"astro"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "AutoHotKey", Exts: []string{"ahk"}, Line: []string{";"}},
	{Name: "Autoconf", Exts: []string{"in"}, Line: []string{"#"}},
	{Name: "Automake", Exts: []string{"am"}, Line: []string{"#"}},
	{Name: "BASH", Exts: []string{"bash"}, Names: []string{".bashrc", ".bash_profile"}, Line: []string{"#"}},
	{Name: "Batch", Exts: []string{"bat", "btm", "cmd"}, Line: []string{"REM", "::"}},
	{Name: "Bazel", Exts: []string{"bzl", "bazel", "bzlmod"}, Names: []string{"BUILD", "BUILD.bazel", "WORKSPACE"}, Line: []string{"#"}},
	{Name: "Bicep", Exts: []string{"bicep", "bicepparam"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "C", Exts: []string{"c", "ec", "pgc"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "C Header", Exts: []string{"h"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "CMake", Exts: []string{"cmake"}, Names: []string{"CMakeLists.txt"}, Line: []string{"#"}},
	{Name: "C#", Exts: []string{"cs", "csx"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "C Shell", Exts: []string{"csh"}, Line: []string{"#"}},
	{Name: "Cabal", Exts: []string{"cabal"}, Line: []string{"--"}},
	{Name: "Clojure", Exts: []string{"clj"}, Line: []string{";"}},
	{Name: "ClojureC", Exts: []string{"cljc"}, Line: []string{";"}},
	{Name: "ClojureScript", Exts: []string{"cljs"}, Line: []string{";"}},
	{Name: "COBOL", Exts: []string{"cob", "cbl", "ccp", "cobol", "cpy"}, Line: []string{"*"}},
	{Name: "CoffeeScript", Exts: []string{"coffee", "cjsx"}, Line: []string{"#"}},
	{Name: "ColdFusion", Exts: []string{"cfm"}, BlockStart: "<!---", BlockEnd: "--->"},
	{Name: "ColdFusion CFScript", Exts: []string{"cfc"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Coq", Exts: []string{"v"}, BlockStart: "(*", BlockEnd: "*)", Nested: true},
	{Name: "C++", Exts: []string{"cc", "cpp", "cxx", "c++", "pcc", "tpp"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "C++ Header", Exts: []string{"hh", "hpp", "hxx", "inl", "ipp"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "C++ Module", Exts: []string{"cppm", "ixx", "ccm", "mpp", "mxx"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Crystal", Exts: []string{"cr"}, Line: []string{"#"}},
	{Name: "CSS", Exts: []string{"css"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "CUDA", Exts: []string{"cu"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "CUE", Exts: []string{"cue"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Cython", Exts: []string{"pyx", "pxd", "pxi"}, Line: []string{"#"}},
	{Name: "D", Exts: []string{"d"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/", Nested: true},
	{Name: "Dart", Exts: []string{"dart"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Dhall", Exts: []string{"dhall"}, Line: []string{"--"}, BlockStart: "{-", BlockEnd: "-}", Nested: true},
	{Name: "Dockerfile", Exts: []string{"dockerfile", "dockerignore"}, Names: []string{"Dockerfile", ".dockerignore"}, Line: []string{"#"}},
	{Name: "Elisp", Exts: []string{"el"}, Line: []string{";"}},
	{Name: "Elixir", Exts: []string{"ex", "exs"}, Line: []string{"#"}},
	{Name: "Elm", Exts: []string{"elm"}, Line: []string{"--"}, BlockStart: "{-", BlockEnd: "-}", Nested: true},
	{Name: "Erlang", Exts: []string{"erl", "hrl"}, Line: []string{"%"}},
	{Name: "F#", Exts: []string{"fs", "fsi", "fsx"}, Line: []string{"//"}, BlockStart: "(*", BlockEnd: "*)"},
	{Name: "Fish", Exts: []string{"fish"}, Line: []string{"#"}},
	{Name: "Forth", Exts: []string{"forth", "frt", "fth"}, Line: []string{"\\"}},
	{Name: "Fortran Legacy", Exts: []string{"f", "for", "ftn"}, Line: []string{"!", "C", "c", "*"}},
	{Name: "Fortran Modern", Exts: []string{"f90", "f95", "f03", "f08"}, Line: []string{"!"}},
	{Name: "GDB", Exts: []string{"gdb"}, Line: []string{"#"}},
	{Name: "GdScript", Exts: []string{"gd"}, Line: []string{"#"}},
	{Name: "Gherkin", Exts: []string{"feature"}, Line: []string{"#"}},
	{Name: "Gleam", Exts: []string{"gleam"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Glsl", Exts: []string{"glsl", "vert", "frag", "geom", "tesc", "tese", "comp"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Go", Exts: []string{"go"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Graphql", Exts: []string{"graphql", "gql"}, Line: []string{"#"}},
	{Name: "Groovy", Exts: []string{"groovy", "gradle"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Handlebars", Exts: []string{"hbs", "handlebars"}, BlockStart: "{{!", BlockEnd: "}}"},
	{Name: "Haskell", Exts: []string{"hs", "lhs"}, Line: []string{"--"}, BlockStart: "{-", BlockEnd: "-}", Nested: true},
	{Name: "Haxe", Exts: []string{"hx"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Hcl", Exts: []string{"hcl", "tf", "tfvars"}, Line: []string{"#", "//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Html", Exts: []string{"html", "htm"}, BlockStart: "<!--", BlockEnd: "-->"},
	{Name: "Ini", Exts: []string{"ini", "cfg", "conf"}, Line: []string{";", "#"}},
	{Name: "Java", Exts: []string{"java"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "JavaScript", Exts: []string{"js", "mjs", "cjs"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Jq", Exts: []string{"jq"}, Line: []string{"#"}},
	{Name: "Json", Exts: []string{"json", "jsonl"}, Text: false},
	{Name: "Jsx", Exts: []string{"jsx"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Julia", Exts: []string{"jl"}, Line: []string{"#"}, BlockStart: "#=", BlockEnd: "=#"},
	{Name: "Just", Exts: []string{"just"}, Names: []string{"justfile", "Justfile"}, Line: []string{"#"}},
	{Name: "Kotlin", Exts: []string{"kt", "kts"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Less", Exts: []string{"less"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Lisp", Exts: []string{"lisp", "lsp", "cl"}, Line: []string{";"}},
	{Name: "Lua", Exts: []string{"lua"}, Line: []string{"--"}, BlockStart: "--[[", BlockEnd: "]]"},
	{Name: "Makefile", Exts: []string{"mk", "mak"}, Names: []string{"Makefile", "makefile", "GNUmakefile"}, Line: []string{"#"}},
	{Name: "Markdown", Exts: []string{"md", "markdown", "mdown"}, Markdown: true, Text: true},
	{Name: "Mdx", Exts: []string{"mdx"}, Markdown: true, Text: true},
	{Name: "Meson", Exts: []string{"meson"}, Names: []string{"meson.build", "meson_options.txt"}, Line: []string{"#"}},
	{Name: "Nim", Exts: []string{"nim", "nims"}, Line: []string{"#"}},
	{Name: "Nix", Exts: []string{"nix"}, Line: []string{"#"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Objective-C", Exts: []string{"m"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Objective-C++", Exts: []string{"mm"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "OCaml", Exts: []string{"ml", "mli"}, BlockStart: "(*", BlockEnd: "*)", Nested: true},
	{Name: "Org", Exts: []string{"org"}, Text: true},
	{Name: "Pascal", Exts: []string{"pas", "pp", "inc"}, Line: []string{"//"}, BlockStart: "{", BlockEnd: "}"},
	{Name: "Perl", Exts: []string{"pl", "pm", "t"}, Line: []string{"#"}},
	{Name: "Perl 6", Exts: []string{"p6", "pm6", "raku"}, Line: []string{"#"}},
	{Name: "Php", Exts: []string{"php", "php3", "php4", "php5", "phtml"}, Line: []string{"//", "#"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Po", Exts: []string{"po", "pot"}, Line: []string{"#"}},
	{Name: "PowerShell", Exts: []string{"ps1", "psm1", "psd1"}, Line: []string{"#"}, BlockStart: "<#", BlockEnd: "#>"},
	{Name: "Prolog", Exts: []string{"plg", "pro"}, Line: []string{"%"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Protobuf", Exts: []string{"proto"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "PureScript", Exts: []string{"purs"}, Line: []string{"--"}, BlockStart: "{-", BlockEnd: "-}", Nested: true},
	{Name: "Python", Exts: []string{"py", "pyw"}, Line: []string{"#"}},
	{Name: "R", Exts: []string{"r", "R"}, Line: []string{"#"}},
	{Name: "Racket", Exts: []string{"rkt"}, Line: []string{";"}},
	{Name: "ReStructuredText", Exts: []string{"rst"}, Text: true},
	{Name: "RON", Exts: []string{"ron"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Ruby", Exts: []string{"rb", "rake"}, Names: []string{"Rakefile", "Gemfile"}, Line: []string{"#"}},
	{Name: "Rust", Exts: []string{"rs"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/", Nested: true},
	{Name: "Sass", Exts: []string{"sass", "scss"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Scala", Exts: []string{"scala", "sc"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Scheme", Exts: []string{"scm", "ss"}, Line: []string{";"}},
	{Name: "Shell", Exts: []string{"sh"}, Line: []string{"#"}},
	{Name: "Solidity", Exts: []string{"sol"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Sql", Exts: []string{"sql"}, Line: []string{"--"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Svelte", Exts: []string{"svelte"}, BlockStart: "<!--", BlockEnd: "-->"},
	{Name: "Svg", Exts: []string{"svg"}, BlockStart: "<!--", BlockEnd: "-->"},
	{Name: "Swift", Exts: []string{"swift"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/", Nested: true},
	{Name: "SystemVerilog", Exts: []string{"sv", "svh"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Tcl", Exts: []string{"tcl"}, Line: []string{"#"}},
	{Name: "Tex", Exts: []string{"tex", "sty", "cls"}, Line: []string{"%"}},
	{Name: "Text", Exts: []string{"txt", "text"}, Text: true},
	{Name: "Toml", Exts: []string{"toml"}, Line: []string{"#"}},
	{Name: "Tsx", Exts: []string{"tsx"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "TypeScript", Exts: []string{"ts", "mts", "cts"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Vala", Exts: []string{"vala"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "VBScript", Exts: []string{"vbs"}, Line: []string{"'"}},
	{Name: "Verilog", Exts: []string{"vlg", "vh"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Vhdl", Exts: []string{"vhd", "vhdl"}, Line: []string{"--"}},
	{Name: "VimScript", Exts: []string{"vim"}, Line: []string{"\""}},
	{Name: "Vue", Exts: []string{"vue"}, BlockStart: "<!--", BlockEnd: "-->"},
	{Name: "Xaml", Exts: []string{"xaml"}, BlockStart: "<!--", BlockEnd: "-->"},
	{Name: "Xml", Exts: []string{"xml"}, BlockStart: "<!--", BlockEnd: "-->"},
	{Name: "Yaml", Exts: []string{"yaml", "yml"}, Line: []string{"#"}},
	{Name: "Zig", Exts: []string{"zig"}, Line: []string{"//"}, BlockStart: "/*", BlockEnd: "*/"},
	{Name: "Zsh", Exts: []string{"zsh"}, Line: []string{"#"}},
}

var extMap map[string]Rule
var nameMap map[string]Rule

func init() {
	extMap = map[string]Rule{}
	nameMap = map[string]Rule{}
	for _, r := range rules {
		for _, e := range r.Exts {
			extMap[strings.ToLower(e)] = r
		}
		for _, n := range r.Names {
			nameMap[strings.ToLower(n)] = r
		}
	}
}

func main() {
	opt, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if opt.showHelp {
		printHelp()
		return
	}
	if opt.showVersion {
		fmt.Println("tokei 14.0.0 compiled with serialization support: json")
		return
	}
	if opt.languages {
		printLanguages()
		return
	}
	if opt.numFormat == "" {
		opt.numFormat = "plain"
	}
	if opt.output != "" && opt.numFormat != "plain" {
		fmt.Fprintln(os.Stderr, "error: the argument '--num-format <num_format_style>' cannot be used with '--output <output>'")
		os.Exit(2)
	}

	langs := map[string]*Language{}
	reports := []FileReport{}
	if opt.input != "" {
		if err := loadInput(opt.input, langs); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
	}
	if len(opt.inputs) == 0 {
		opt.inputs = []string{"."}
	}
	var missing []string
	for _, in := range opt.inputs {
		if _, err := os.Stat(in); err != nil {
			missing = append(missing, in)
			continue
		}
		rs, err := scanInput(in, opt)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
		for _, fr := range rs {
			addReport(langs, fr.Lang, fr.Path, fr.Stat)
			reports = append(reports, fr)
		}
	}
	if len(missing) > 0 {
		fmt.Fprintf(os.Stderr, "Error: '%s' not found.\n", missing[0])
		os.Exit(1)
	}
	if len(opt.types) > 0 {
		filterTypes(langs, opt.types)
	}
	addTotal(langs)

	switch {
	case opt.output == "json":
		b, _ := json.Marshal(langs)
		fmt.Print(string(b))
	case opt.output == "cbor" || opt.output == "yaml":
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--output <output>': This version of tokei was compiled without any '%s' serialization support, to enable serialization, reinstall tokei with the features flag.\n", opt.output, opt.output)
		os.Exit(2)
	case opt.output != "":
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--output <output>'\n", opt.output)
		os.Exit(2)
	case opt.streaming == "simple":
		printStreamingSimple(reports, opt)
	case opt.streaming == "json":
		printStreamingJSON(reports)
	default:
		printTable(langs, opt)
	}
}

func parseArgs(args []string) (Options, error) {
	var o Options
	o.types = map[string]bool{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		take := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("error: a value is required for '%s'", a)
			}
			i++
			return args[i], nil
		}
		switch {
		case a == "--":
			o.inputs = append(o.inputs, args[i+1:]...)
			i = len(args)
		case a == "-h" || a == "--help":
			o.showHelp = true
		case a == "-V" || a == "--version":
			o.showVersion = true
		case a == "-f" || a == "--files":
			o.files = true
		case a == "--hidden":
			o.hidden = true
		case a == "--no-ignore" || a == "--no-ignore-parent" || a == "--no-ignore-dot" || a == "--no-ignore-vcs":
			o.noIgnore = true
		case a == "-l" || a == "--languages":
			o.languages = true
		case a == "-C" || a == "--compact":
			o.compact = true
		case a == "-v" || a == "--verbose":
			o.verbose++
		case strings.HasPrefix(a, "-v") && len(a) > 2 && !strings.HasPrefix(a, "--"):
			o.verbose += len(a) - 1
		case a == "-e" || a == "--exclude":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.excludes = append(o.excludes, v)
		case strings.HasPrefix(a, "--exclude="):
			o.excludes = append(o.excludes, strings.TrimPrefix(a, "--exclude="))
		case a == "-o" || a == "--output":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.output = strings.ToLower(v)
		case strings.HasPrefix(a, "--output="):
			o.output = strings.ToLower(strings.TrimPrefix(a, "--output="))
		case a == "-i" || a == "--input":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.input = v
		case strings.HasPrefix(a, "--input="):
			o.input = strings.TrimPrefix(a, "--input=")
		case a == "--streaming":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.streaming = strings.ToLower(v)
		case strings.HasPrefix(a, "--streaming="):
			o.streaming = strings.ToLower(strings.TrimPrefix(a, "--streaming="))
		case a == "-s" || a == "--sort":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.sortKey = strings.ToLower(v)
		case strings.HasPrefix(a, "--sort="):
			o.sortKey = strings.ToLower(strings.TrimPrefix(a, "--sort="))
		case a == "-r" || a == "--rsort":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.reverseSort = strings.ToLower(v)
		case strings.HasPrefix(a, "--rsort="):
			o.reverseSort = strings.ToLower(strings.TrimPrefix(a, "--rsort="))
		case a == "-t" || a == "--types" || a == "--type":
			v, err := take()
			if err != nil {
				return o, err
			}
			addTypes(o.types, v)
		case strings.HasPrefix(a, "-t="):
			addTypes(o.types, strings.TrimPrefix(a, "-t="))
		case strings.HasPrefix(a, "--types="):
			addTypes(o.types, strings.TrimPrefix(a, "--types="))
		case strings.HasPrefix(a, "--type="):
			addTypes(o.types, strings.TrimPrefix(a, "--type="))
		case a == "-n" || a == "--num-format":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.numFormat = v
		case strings.HasPrefix(a, "--num-format="):
			o.numFormat = strings.TrimPrefix(a, "--num-format=")
		case a == "-c" || a == "--columns":
			v, err := take()
			if err != nil {
				return o, err
			}
			o.columns = v
		case strings.HasPrefix(a, "--columns="):
			o.columns = strings.TrimPrefix(a, "--columns=")
		case strings.HasPrefix(a, "-") && len(a) > 1:
			return o, fmt.Errorf("error: unexpected argument '%s' found", a)
		default:
			o.inputs = append(o.inputs, a)
		}
	}
	return o, nil
}

func addTypes(m map[string]bool, s string) {
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			m[p] = true
		}
	}
}

func printHelp() {
	fmt.Print(`Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for
                                       terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run. Can be given a
                                       file path, or "stdin" to read from stdin.
      --hidden                         Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.). This
                                       implies --no-ignore-parent, --no-ignore-dot, and
                                       --no-ignore-vcs.
      --no-ignore-parent               Don't respect ignore files (.gitignore, .ignore, etc.) in
                                       parent directories.
      --no-ignore-dot                  Don't respect .ignore and .tokeignore files, including those
                                       in parent directories.
      --no-ignore-vcs                  Don't respect VCS ignore files (.gitignore, .hgignore, etc.)
                                       including those in parent directories.
  -o, --output <output>                Outputs Tokei in a specific format. Compile with additional
                                       features for more format support.
      --streaming <streaming>          prints the (language, path, lines, blanks, code, comments)
                                       records as simple lines or as Json for batch processing
                                       [possible values: simple, json]
  -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                       lines, blanks, code, comments]
  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                       files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma. i.e.
                                       -t=Rust,Markdown
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  Format of printed numbers, i.e., plain (1234, default),
                                       commas (1,234), dots (1.234), or underscores (1_234). Cannot
                                       be used with --output. [possible values: commas, dots, plain,
                                       underscores]
  -v, --verbose...                     Set log output level:
                                                               1: to show unknown file extensions,
                                                               2: reserved for future debugging,
                                                               3: enable file level trace. Not
                                                               recommended on multiple files
  -h, --help                           Print help
  -V, --version                        Print version
`)
}

func printLanguages() {
	fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
	fmt.Println("┃ Language                              Extensions                     ┃")
	fmt.Println("┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃")
	for _, r := range rules {
		ext := strings.Join(r.Exts, ", ")
		if len(ext) > 30 {
			ext = ext[:27] + "..."
		}
		fmt.Printf("┃ %-37s %-30s ┃\n", r.Name, ext)
	}
	fmt.Println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
}

func scanInput(root string, opt Options) ([]FileReport, error) {
	ignores := loadIgnoreFiles(root, opt)
	var out []FileReport
	info, err := os.Stat(root)
	if err != nil {
		return nil, err
	}
	handle := func(path string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		base := filepath.Base(path)
		if !opt.hidden && strings.HasPrefix(base, ".") && path != "." && path != root {
			if d != nil && d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		if d != nil && d.IsDir() {
			if base == ".git" || base == "target" || base == "node_modules" || base == "vendor" {
				return filepath.SkipDir
			}
			return nil
		}
		if d != nil {
			if inf, err := d.Info(); err == nil && inf.Mode()&os.ModeSymlink != 0 {
				return nil
			}
		}
		if isExcluded(path, opt.excludes) || (!opt.noIgnore && isExcluded(path, ignores)) {
			return nil
		}
		r, ok := languageFor(path)
		if !ok {
			if opt.verbose > 0 {
				ext := filepath.Ext(path)
				if ext != "" {
					fmt.Fprintf(os.Stderr, "Unknown extension: %s\n", ext)
				}
			}
			return nil
		}
		st, err := countFile(path, r)
		if err != nil {
			return nil
		}
		out = append(out, FileReport{Lang: r.Name, Path: cleanPath(path), Stat: st})
		return nil
	}
	if !info.IsDir() {
		err := handle(root, nil, nil)
		return out, err
	}
	err = filepath.WalkDir(root, handle)
	sort.Slice(out, func(i, j int) bool { return out[i].Path < out[j].Path })
	return out, err
}

func cleanPath(p string) string {
	return filepath.ToSlash(filepath.Clean(p))
}

func loadIgnoreFiles(root string, opt Options) []string {
	if opt.noIgnore {
		return nil
	}
	var pats []string
	info, err := os.Stat(root)
	dir := root
	if err == nil && !info.IsDir() {
		dir = filepath.Dir(root)
	}
	for _, name := range []string{".gitignore", ".ignore", ".tokeignore"} {
		b, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil {
			continue
		}
		sc := bufio.NewScanner(bytes.NewReader(b))
		for sc.Scan() {
			line := strings.TrimSpace(sc.Text())
			if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
				continue
			}
			pats = append(pats, line)
		}
	}
	return pats
}

func isExcluded(path string, pats []string) bool {
	path = filepath.ToSlash(path)
	base := filepath.Base(path)
	for _, p := range pats {
		p = strings.TrimSpace(strings.TrimPrefix(filepath.ToSlash(p), "/"))
		if p == "" {
			continue
		}
		dirPat := strings.HasSuffix(p, "/")
		p = strings.TrimSuffix(p, "/")
		if ok, _ := filepath.Match(p, base); ok {
			return true
		}
		if ok, _ := filepath.Match(p, path); ok {
			return true
		}
		if strings.Contains(path, "/"+p+"/") || strings.HasSuffix(path, "/"+p) || base == p {
			return true
		}
		if dirPat && strings.Contains(path, "/"+p+"/") {
			return true
		}
	}
	return false
}

func languageFor(path string) (Rule, bool) {
	base := filepath.Base(path)
	if r, ok := nameMap[strings.ToLower(base)]; ok {
		return r, true
	}
	ext := strings.TrimPrefix(filepath.Ext(base), ".")
	if ext == "" {
		return Rule{}, false
	}
	r, ok := extMap[strings.ToLower(ext)]
	return r, ok
}

func countFile(path string, r Rule) (Stats, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Stats{}, err
	}
	if r.Markdown {
		return countMarkdown(string(b)), nil
	}
	lines := splitLines(string(b))
	st := Stats{Blobs: map[string]Stats{}}
	inBlock := 0
	for _, line := range lines {
		trim := strings.TrimSpace(line)
		if trim == "" {
			st.Blanks++
			continue
		}
		if r.Text {
			st.Comments++
			continue
		}
		code, comment, nb := classifyLine(line, r, inBlock)
		inBlock = nb
		if code {
			st.Code++
		} else if comment {
			st.Comments++
		} else {
			st.Code++
		}
	}
	return st, nil
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	s = strings.ReplaceAll(s, "\r\n", "\n")
	s = strings.ReplaceAll(s, "\r", "\n")
	parts := strings.Split(s, "\n")
	if parts[len(parts)-1] == "" {
		parts = parts[:len(parts)-1]
	}
	return parts
}

func classifyLine(line string, r Rule, inBlock int) (bool, bool, int) {
	trim := strings.TrimSpace(line)
	if inBlock > 0 {
		if r.BlockEnd != "" && strings.Contains(trim, r.BlockEnd) {
			after := trim[strings.Index(trim, r.BlockEnd)+len(r.BlockEnd):]
			inBlock--
			if inBlock < 0 {
				inBlock = 0
			}
			if strings.TrimSpace(after) != "" {
				return true, true, inBlock
			}
		}
		if r.Nested && r.BlockStart != "" && strings.Contains(trim, r.BlockStart) {
			inBlock++
		}
		return false, true, inBlock
	}
	for _, lc := range r.Line {
		if lineStarts(trim, lc) {
			return false, true, 0
		}
	}
	if r.BlockStart != "" {
		start := strings.Index(trim, r.BlockStart)
		if start >= 0 {
			end := strings.Index(trim[start+len(r.BlockStart):], r.BlockEnd)
			before := strings.TrimSpace(trim[:start])
			if end >= 0 {
				after := strings.TrimSpace(trim[start+len(r.BlockStart)+end+len(r.BlockEnd):])
				if before != "" || after != "" {
					return true, true, 0
				}
				return false, true, 0
			}
			if before != "" {
				return true, true, 1
			}
			return false, true, 1
		}
	}
	return true, false, 0
}

func lineStarts(trim, marker string) bool {
	if marker == "REM" {
		return strings.HasPrefix(strings.ToUpper(trim), "REM ")
	}
	return strings.HasPrefix(trim, marker)
}

func countMarkdown(s string) Stats {
	lines := splitLines(s)
	st := Stats{Blobs: map[string]Stats{}}
	inFence := false
	fenceLang := ""
	var fence []string
	for _, line := range lines {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") {
			if !inFence {
				inFence = true
				fenceLang = strings.TrimSpace(strings.TrimLeft(trim, "`~"))
				if fields := strings.Fields(fenceLang); len(fields) > 0 {
					fenceLang = fields[0]
				}
				fence = nil
			} else {
				if r, ok := langByFence(fenceLang); ok {
					child, _ := countContent(strings.Join(fence, "\n"), r)
					cur := st.Blobs[r.Name]
					cur.Blanks += child.Blanks
					cur.Code += child.Code
					cur.Comments += child.Comments
					if cur.Blobs == nil {
						cur.Blobs = map[string]Stats{}
					}
					st.Blobs[r.Name] = cur
				}
				inFence = false
			}
			st.Comments++
			continue
		}
		if inFence {
			fence = append(fence, line)
			continue
		}
		if trim == "" {
			st.Blanks++
		} else {
			st.Comments++
		}
	}
	return st
}

func countContent(s string, r Rule) (Stats, error) {
	tmp := Stats{Blobs: map[string]Stats{}}
	inBlock := 0
	for _, line := range splitLines(s) {
		trim := strings.TrimSpace(line)
		if trim == "" {
			tmp.Blanks++
			continue
		}
		code, comment, nb := classifyLine(line, r, inBlock)
		inBlock = nb
		if code {
			tmp.Code++
		} else if comment || r.Text {
			tmp.Comments++
		} else {
			tmp.Code++
		}
	}
	return tmp, nil
}

func langByFence(s string) (Rule, bool) {
	s = strings.ToLower(strings.TrimSpace(s))
	aliases := map[string]string{"golang": "go", "javascript": "js", "typescript": "ts", "python": "py", "rust": "rs", "shell": "sh", "bash": "bash", "c++": "cpp"}
	if e, ok := aliases[s]; ok {
		s = e
	}
	if r, ok := extMap[s]; ok {
		return r, true
	}
	for _, r := range rules {
		if strings.EqualFold(r.Name, s) {
			return r, true
		}
	}
	return Rule{}, false
}

func addReport(m map[string]*Language, lang, path string, st Stats) {
	l := m[lang]
	if l == nil {
		l = &Language{Reports: []Report{}, Children: map[string][]Report{}}
		m[lang] = l
	}
	l.Blanks += st.Blanks
	l.Code += st.Code
	l.Comments += st.Comments
	rep := Report{Stats: st, Name: path}
	l.Reports = append(l.Reports, rep)
	for childName, child := range st.Blobs {
		l.Children[childName] = append(l.Children[childName], Report{Stats: child, Name: path})
	}
}

func addTotal(m map[string]*Language) {
	delete(m, "Total")
	t := &Language{Reports: []Report{}, Children: map[string][]Report{}}
	for name, l := range m {
		t.Blanks += l.Blanks
		t.Code += l.Code
		t.Comments += l.Comments
		for _, r := range l.Reports {
			t.Children[name] = append(t.Children[name], r)
			for _, b := range r.Stats.Blobs {
				t.Blanks += b.Blanks
				t.Code += b.Code
				t.Comments += b.Comments
			}
		}
	}
	m["Total"] = t
}

func filterTypes(m map[string]*Language, types map[string]bool) {
	for k := range m {
		if !types[k] {
			delete(m, k)
		}
	}
}

func fileCount(l *Language) int { return len(l.Reports) }
func linesOf(l *Language) int   { return l.Blanks + l.Code + l.Comments }

func sortedLangs(m map[string]*Language, opt Options) []string {
	var names []string
	for k := range m {
		if k != "Total" {
			names = append(names, k)
		}
	}
	key := opt.sortKey
	rev := false
	if opt.reverseSort != "" {
		key = opt.reverseSort
		rev = true
	}
	less := func(i, j int) bool {
		a, b := m[names[i]], m[names[j]]
		if !opt.compact {
			ac, bc := len(a.Children) > 0, len(b.Children) > 0
			if ac != bc {
				return !ac
			}
		}
		var av, bv int
		switch key {
		case "files":
			av, bv = fileCount(a), fileCount(b)
		case "lines":
			av, bv = linesOf(a), linesOf(b)
		case "blanks":
			av, bv = a.Blanks, b.Blanks
		case "code":
			av, bv = a.Code, b.Code
		case "comments":
			av, bv = a.Comments, b.Comments
		default:
			if rev {
				return names[i] > names[j]
			}
			return names[i] < names[j]
		}
		if av == bv {
			if rev {
				return names[i] < names[j]
			}
			return names[i] < names[j]
		}
		if rev {
			return av < bv
		}
		return av > bv
	}
	sort.SliceStable(names, less)
	return names
}

func printTable(m map[string]*Language, opt Options) {
	line := strings.Repeat("━", 81)
	thin := strings.Repeat("─", 81)
	fmt.Println(line)
	fmt.Printf(" %-18s %8s %12s %12s %12s %12s\n", "Language", "Files", "Lines", "Code", "Comments", "Blanks")
	fmt.Println(line)
	names := sortedLangs(m, opt)
	for _, name := range names {
		l := m[name]
		hasChildren := len(l.Children) > 0 && !opt.compact
		if hasChildren {
			fmt.Println(thin)
		}
		fmt.Printf(" %-18s %8s %12s %12s %12s %12s\n", name, fmtNum(fileCount(l), opt), fmtNum(linesOf(l), opt), fmtNum(l.Code, opt), fmtNum(l.Comments, opt), fmtNum(l.Blanks, opt))
		if hasChildren {
			childNames := make([]string, 0, len(l.Children))
			for c := range l.Children {
				childNames = append(childNames, c)
			}
			sort.Strings(childNames)
			total := Stats{Blobs: map[string]Stats{}}
			for _, c := range childNames {
				cs := sumReports(l.Children[c])
				total.Blanks += cs.Blanks
				total.Code += cs.Code
				total.Comments += cs.Comments
				fmt.Printf(" |- %-15s %8s %12s %12s %12s %12s\n", c, fmtNum(len(l.Children[c]), opt), fmtNum(cs.Blanks+cs.Code+cs.Comments, opt), fmtNum(cs.Code, opt), fmtNum(cs.Comments, opt), fmtNum(cs.Blanks, opt))
			}
			fmt.Printf(" %-18s %8s %12s %12s %12s %12s\n", "(Total)", "", fmtNum(linesOf(l)+total.Blanks+total.Code+total.Comments, opt), fmtNum(l.Code+total.Code, opt), fmtNum(l.Comments+total.Comments, opt), fmtNum(l.Blanks+total.Blanks, opt))
		}
		if opt.files {
			fmt.Println(thin)
			reps := append([]Report(nil), l.Reports...)
			sort.Slice(reps, func(i, j int) bool { return reps[i].Name < reps[j].Name })
			for _, r := range reps {
				fmt.Printf(" %-27s %12s %12s %12s %12s\n", r.Name, fmtNum(r.Stats.Blanks+r.Stats.Code+r.Stats.Comments, opt), fmtNum(r.Stats.Code, opt), fmtNum(r.Stats.Comments, opt), fmtNum(r.Stats.Blanks, opt))
			}
		}
	}
	fmt.Println(line)
	t := m["Total"]
	if t == nil {
		t = &Language{}
	}
	totalFiles := 0
	for _, rs := range t.Children {
		totalFiles += len(rs)
	}
	fmt.Printf(" %-18s %8s %12s %12s %12s %12s\n", "Total", fmtNum(totalFiles, opt), fmtNum(linesOf(t), opt), fmtNum(t.Code, opt), fmtNum(t.Comments, opt), fmtNum(t.Blanks, opt))
	fmt.Println(line)
}

func sumReports(rs []Report) Stats {
	var s Stats
	for _, r := range rs {
		s.Blanks += r.Stats.Blanks
		s.Code += r.Stats.Code
		s.Comments += r.Stats.Comments
	}
	return s
}

func fmtNum(n int, opt Options) string {
	s := strconv.Itoa(n)
	var sep byte
	switch opt.numFormat {
	case "commas":
		sep = ','
	case "dots":
		sep = '.'
	case "underscores":
		sep = '_'
	default:
		return s
	}
	var out []byte
	for i, c := range []byte(s) {
		if i > 0 && (len(s)-i)%3 == 0 {
			out = append(out, sep)
		}
		out = append(out, c)
	}
	return string(out)
}

func printStreamingSimple(reports []FileReport, opt Options) {
	fmt.Printf("# %-47s %-45s %12s %12s %12s %12s\n", "language", "path", "lines", "code", "comments", "blanks")
	fmt.Printf("%s %s %s %s %s %s\n", strings.Repeat("#", 10), strings.Repeat("#", 80), strings.Repeat("#", 12), strings.Repeat("#", 12), strings.Repeat("#", 12), strings.Repeat("#", 12))
	for _, r := range reports {
		fmt.Printf("%10s %-80s %12s %12s %12s %12s\n", r.Lang, r.Path, fmtNum(r.Stat.Blanks+r.Stat.Code+r.Stat.Comments, opt), fmtNum(r.Stat.Code, opt), fmtNum(r.Stat.Comments, opt), fmtNum(r.Stat.Blanks, opt))
	}
}

func printStreamingJSON(reports []FileReport) {
	type streamReport struct {
		Name  string `json:"name"`
		Stats Stats  `json:"stats"`
	}
	type streamObj struct {
		Language string       `json:"language"`
		Stats    streamReport `json:"stats"`
	}
	for _, r := range reports {
		obj := streamObj{Language: r.Lang, Stats: streamReport{Name: r.Path, Stats: r.Stat}}
		b, _ := json.Marshal(obj)
		fmt.Println(string(b))
	}
}

func loadInput(name string, langs map[string]*Language) error {
	var data []byte
	var err error
	if name == "stdin" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(name)
	}
	if err != nil {
		return err
	}
	var parsed map[string]Language
	if err := json.Unmarshal(data, &parsed); err != nil {
		return errors.New("input format not supported")
	}
	for k, v := range parsed {
		if k == "Total" {
			continue
		}
		cp := v
		if cp.Children == nil {
			cp.Children = map[string][]Report{}
		}
		langs[k] = &cp
	}
	return nil
}
