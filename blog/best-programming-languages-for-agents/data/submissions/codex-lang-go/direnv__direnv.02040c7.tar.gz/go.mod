module programbench-direnv

go 1.21
