package main

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "2.37.1"

type silentError struct{ code int }

func (e silentError) Error() string { return "" }

func main() {
	if len(os.Args) < 2 {
		printHelp()
		return
	}
	cmd := os.Args[1]
	args := os.Args[2:]
	var err error
	switch cmd {
	case "help", "--help", "-h":
		printHelp()
	case "version":
		err = cmdVersion(args)
	case "allow", "permit", "grant":
		err = cmdAllow(args)
	case "block", "deny", "disallow", "revoke":
		err = cmdBlock(args)
	case "export":
		err = cmdExport(args)
	case "exec":
		err = cmdExec(args)
	case "hook":
		err = cmdHook(args)
	case "status":
		err = cmdStatus(args)
	case "stdlib":
		fmt.Print(stdlibScript())
	case "reload":
		fmt.Println("export DIRENV_DIFF='';")
	case "prune":
		err = prune()
	case "edit":
		err = cmdEdit(args)
	case "log":
		err = cmdLog(args)
	case "fetchurl":
		err = errors.New("fetchurl is not available without network access")
	default:
		err = fmt.Errorf("command %q not found", os.Args[0]+" "+cmd)
	}
	if err != nil {
		if _, ok := err.(silentError); !ok {
			logError(err.Error())
		}
		os.Exit(1)
	}
}

func printHelp() {
	fmt.Printf(`direnv v%s
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: [fish, json, tcsh, vim, zsh, pwsh, systemd, elvish, gha, gzenv, murex, bash]
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
`, version)
}

func logError(s string) { fmt.Fprintf(os.Stderr, "\033[31mdirenv: error %s\033[0m\n", s) }
func logMsg(format string, a ...any) {
	if os.Getenv("DIRENV_LOG_FORMAT") == "-" {
		return
	}
	fmt.Fprintf(os.Stderr, "\033[0mdirenv: "+format+"\n", a...)
}

func cmdVersion(args []string) error {
	if len(args) == 0 {
		fmt.Println(version)
		return nil
	}
	if cmpVersion(version, args[0]) < 0 {
		return fmt.Errorf("current version v%s is older than the desired version v%s", version, args[0])
	}
	return nil
}

func cmpVersion(a, b string) int {
	ap := strings.Split(strings.TrimPrefix(a, "v"), ".")
	bp := strings.Split(strings.TrimPrefix(b, "v"), ".")
	for len(ap) < 3 {
		ap = append(ap, "0")
	}
	for len(bp) < 3 {
		bp = append(bp, "0")
	}
	for i := 0; i < 3; i++ {
		ai, _ := strconv.Atoi(numPrefix(ap[i]))
		bi, _ := strconv.Atoi(numPrefix(bp[i]))
		if ai < bi {
			return -1
		}
		if ai > bi {
			return 1
		}
	}
	return 0
}

func numPrefix(s string) string {
	var b strings.Builder
	for _, r := range s {
		if r < '0' || r > '9' {
			break
		}
		b.WriteRune(r)
	}
	if b.Len() == 0 {
		return "0"
	}
	return b.String()
}

type rcFile struct {
	Path string
	Dir  string
	Kind string
}

func findRC(start string) (*rcFile, error) {
	if start == "" {
		start = "."
	}
	abs, err := filepath.Abs(start)
	if err != nil {
		return nil, err
	}
	if st, err := os.Stat(abs); err == nil && !st.IsDir() {
		return &rcFile{Path: abs, Dir: filepath.Dir(abs), Kind: filepath.Base(abs)}, nil
	}
	for {
		envrc := filepath.Join(abs, ".envrc")
		if fileExists(envrc) {
			return &rcFile{Path: envrc, Dir: abs, Kind: ".envrc"}, nil
		}
		if loadDotenv() {
			dotenv := filepath.Join(abs, ".env")
			if fileExists(dotenv) {
				return &rcFile{Path: dotenv, Dir: abs, Kind: ".env"}, nil
			}
		}
		parent := filepath.Dir(abs)
		if parent == abs {
			break
		}
		abs = parent
	}
	return nil, nil
}

func fileExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

func configDir() string {
	if v := os.Getenv("DIRENV_CONFIG"); v != "" {
		return v
	}
	if v := os.Getenv("XDG_CONFIG_HOME"); v != "" {
		return filepath.Join(v, "direnv")
	}
	return filepath.Join(homeDir(), ".config", "direnv")
}

func dataDir() string {
	if v := os.Getenv("XDG_DATA_HOME"); v != "" {
		return filepath.Join(v, "direnv")
	}
	return filepath.Join(homeDir(), ".local", "share", "direnv")
}

func homeDir() string {
	if v := os.Getenv("HOME"); v != "" {
		return v
	}
	return "/tmp"
}

func loadDotenv() bool {
	if os.Getenv("DIRENV_LOAD_DOTENV") == "1" || strings.EqualFold(os.Getenv("DIRENV_LOAD_DOTENV"), "true") {
		return true
	}
	b, err := os.ReadFile(filepath.Join(configDir(), "direnv.toml"))
	if err != nil {
		return false
	}
	return strings.Contains(string(b), "load_dotenv") && strings.Contains(string(b), "true")
}

func allowKey(path string) (string, error) {
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	b, err := os.ReadFile(abs)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	h.Write([]byte(abs))
	h.Write([]byte{0})
	h.Write(b)
	return hex.EncodeToString(h.Sum(nil)), nil
}

func isAllowed(rc *rcFile) bool {
	if rc == nil {
		return false
	}
	if isWhitelisted(rc.Path) {
		return true
	}
	key, err := allowKey(rc.Path)
	if err != nil {
		return false
	}
	return fileExists(filepath.Join(dataDir(), "allow", key)) && !fileExists(filepath.Join(dataDir(), "deny", key))
}

func isWhitelisted(path string) bool {
	b, err := os.ReadFile(filepath.Join(configDir(), "direnv.toml"))
	if err != nil {
		return false
	}
	s := string(b)
	for _, p := range parseTomlArray(s, "prefix") {
		p = expandHome(p)
		if strings.HasPrefix(path, p) {
			return true
		}
	}
	for _, p := range parseTomlArray(s, "exact") {
		p = expandHome(p)
		if st, err := os.Stat(p); err == nil && st.IsDir() {
			p = filepath.Join(p, ".envrc")
		}
		if path == p {
			return true
		}
	}
	return false
}

func parseTomlArray(s, key string) []string {
	var out []string
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if !strings.HasPrefix(line, key) || !strings.Contains(line, "[") {
			continue
		}
		line = line[strings.Index(line, "[")+1:]
		if i := strings.Index(line, "]"); i >= 0 {
			line = line[:i]
		}
		for _, part := range strings.Split(line, ",") {
			part = strings.Trim(strings.TrimSpace(part), `"'`)
			if part != "" {
				out = append(out, part)
			}
		}
	}
	return out
}

func expandHome(p string) string {
	if p == "~" {
		return homeDir()
	}
	if strings.HasPrefix(p, "~/") {
		return filepath.Join(homeDir(), p[2:])
	}
	return p
}

func targetRC(args []string) (*rcFile, error) {
	path := "."
	if len(args) > 0 && args[0] != "" {
		path = args[0]
	}
	if st, err := os.Stat(path); err == nil && st.IsDir() {
		if fileExists(filepath.Join(path, ".envrc")) {
			path = filepath.Join(path, ".envrc")
		} else if fileExists(filepath.Join(path, ".env")) {
			path = filepath.Join(path, ".env")
		} else {
			path = filepath.Join(path, ".envrc")
		}
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return nil, err
	}
	return &rcFile{Path: abs, Dir: filepath.Dir(abs), Kind: filepath.Base(abs)}, nil
}

func cmdAllow(args []string) error {
	rc, err := targetRC(args)
	if err != nil {
		return err
	}
	key, err := allowKey(rc.Path)
	if err != nil {
		return err
	}
	dir := filepath.Join(dataDir(), "allow")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(dir, key), []byte(rc.Path+"\n"), 0o644); err != nil {
		return err
	}
	_ = os.Remove(filepath.Join(dataDir(), "deny", key))
	return nil
}

func cmdBlock(args []string) error {
	rc, err := targetRC(args)
	if err != nil {
		return err
	}
	key, err := allowKey(rc.Path)
	if err != nil {
		return err
	}
	dir := filepath.Join(dataDir(), "deny")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	_ = os.Remove(filepath.Join(dataDir(), "allow", key))
	return os.WriteFile(filepath.Join(dir, key), []byte(rc.Path+"\n"), 0o644)
}

func cmdExport(args []string) error {
	if len(args) != 1 {
		return errors.New("export expects one shell argument")
	}
	rc, err := findRC(".")
	if err != nil {
		return err
	}
	before := envMap(os.Environ())
	after := cloneMap(before)
	if rc == nil {
		printExports(args[0], diff(before, after))
		return nil
	}
	if !isAllowed(rc) {
		logError(fmt.Sprintf("%s is blocked. Run `direnv allow` to approve its content", rc.Path))
		after["DIRENV_DIR"] = "-" + rc.Dir
		after["DIRENV_FILE"] = rc.Path
		after["DIRENV_WATCHES"] = watchBlob(rc)
		after["DIRENV_DIFF"] = diffBlob(before, after)
		printExports(args[0], diff(before, after))
		return silentError{1}
	}
	var child map[string]string
	if rc.Kind == ".env" {
		child, err = evalDotenv(rc, before)
	} else {
		child, err = evalEnvrc(rc, before)
	}
	if err != nil {
		return err
	}
	after = child
	after["DIRENV_DIR"] = "-" + rc.Dir
	after["DIRENV_FILE"] = rc.Path
	after["DIRENV_WATCHES"] = watchBlob(rc)
	after["DIRENV_DIFF"] = diffBlob(before, after)
	logMsg("loading %s", userRel(rc.Path))
	logDiff(before, after)
	printExports(args[0], diff(before, after))
	return nil
}

func evalEnvrc(rc *rcFile, base map[string]string) (map[string]string, error) {
	tmp, err := os.CreateTemp("", "direnv-stdlib-*.sh")
	if err != nil {
		return nil, err
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.WriteString(stdlibScript()); err != nil {
		return nil, err
	}
	tmp.Close()
	script := fmt.Sprintf(`set +e
cd %s || exit 1
source %s
if [ -f %s ]; then source %s; fi
for f in %s/lib/*.sh; do [ -f "$f" ] && source "$f"; done
source %s
env -0
`, shellQuote(rc.Dir), shellQuote(tmp.Name()), shellQuote(filepath.Join(configDir(), "direnvrc")), shellQuote(filepath.Join(configDir(), "direnvrc")), shellQuote(configDir()), shellQuote(rc.Path))
	cmd := exec.Command("/usr/bin/bash", "-c", script)
	cmd.Env = mapToEnv(base)
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = os.Stderr
	err = cmd.Run()
	if err != nil {
		return nil, err
	}
	return parseEnv0(out.Bytes()), nil
}

func evalDotenv(rc *rcFile, base map[string]string) (map[string]string, error) {
	out := cloneMap(base)
	b, err := os.ReadFile(rc.Path)
	if err != nil {
		return nil, err
	}
	sc := bufio.NewScanner(bytes.NewReader(b))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.TrimPrefix(line, "export ")
		k, v, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		k = strings.TrimSpace(k)
		v = strings.TrimSpace(v)
		v = strings.Trim(strings.Trim(v, `"`), `'`)
		out[k] = os.Expand(v, func(name string) string { return out[name] })
	}
	return out, sc.Err()
}

func cmdExec(args []string) error {
	if len(args) < 2 {
		return errors.New("usage: direnv exec DIR COMMAND [...ARGS]")
	}
	dir := args[0]
	rc, err := findRC(dir)
	if err != nil {
		return err
	}
	env := envMap(os.Environ())
	if rc != nil {
		if !isAllowed(rc) {
			return fmt.Errorf("%s is blocked. Run `direnv allow` to approve its content", rc.Path)
		}
		if rc.Kind == ".env" {
			env, err = evalDotenv(rc, env)
		} else {
			env, err = evalEnvrc(rc, env)
		}
		if err != nil {
			return err
		}
	}
	c := exec.Command(args[1], args[2:]...)
	c.Dir = dir
	c.Env = mapToEnv(env)
	c.Stdin = os.Stdin
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	if err := c.Run(); err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			os.Exit(ee.ExitCode())
		}
		return err
	}
	return nil
}

func cmdHook(args []string) error {
	if len(args) != 1 {
		return errors.New("unknown target shell ''")
	}
	self := selfPath()
	switch args[0] {
	case "bash":
		fmt.Printf(`
_direnv_hook() {
  local previous_exit_status=$?;
  vars="$("%s" export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
};
if [[ ";${PROMPT_COMMAND[*]:-};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "${PROMPT_COMMAND[@]}")
  else
    PROMPT_COMMAND="_direnv_hook${PROMPT_COMMAND:+;$PROMPT_COMMAND}"
  fi
fi
`, self)
	case "zsh":
		fmt.Printf(`
_direnv_hook() {
  vars="$("%s" export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}
typeset -ag precmd_functions
if (( ! ${precmd_functions[(I)_direnv_hook]} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! ${chpwd_functions[(I)_direnv_hook]} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi
`, self)
	case "fish":
		fmt.Printf(`
    function __direnv_export_eval --on-event fish_prompt;
        "%s" export fish | source;
    end;
`, self)
	case "tcsh":
		fmt.Printf("alias precmd 'eval `%s export tcsh`'", self)
	case "elvish", "murex", "pwsh":
		fmt.Printf("# direnv hook for %s\n", args[0])
	default:
		return fmt.Errorf("unknown target shell '%s'", args[0])
	}
	return nil
}

func selfPath() string {
	if p, err := os.Executable(); err == nil {
		return p
	}
	return "direnv"
}

func cmdStatus(args []string) error {
	rc, _ := findRC(".")
	if len(args) > 0 && args[0] == "--json" {
		type rcj struct {
			Allowed int    `json:"allowed"`
			Path    string `json:"path"`
		}
		var found *rcj
		if rc != nil {
			allowed := 2
			if isAllowed(rc) {
				allowed = 0
			}
			found = &rcj{Allowed: allowed, Path: rc.Path}
		}
		obj := map[string]any{
			"config": map[string]string{"ConfigDir": configDir(), "SelfPath": selfPath()},
			"state":  map[string]any{"foundRC": found, "loadedRC": nil},
		}
		b, _ := json.MarshalIndent(obj, "", "  ")
		fmt.Println(string(b))
		return nil
	}
	fmt.Println("direnv exec path", selfPath())
	fmt.Println("DIRENV_CONFIG", configDir())
	fmt.Println("bash_path /usr/bin/bash")
	fmt.Println("disable_stdin false")
	fmt.Println("warn_timeout 5s")
	fmt.Println("whitelist.prefix []")
	fmt.Println("whitelist.exact map[]")
	if rc == nil {
		fmt.Println("No .envrc or .env loaded")
		fmt.Println("No .envrc or .env found")
		return nil
	}
	fmt.Println("No .envrc or .env loaded")
	fmt.Println("Found RC path", rc.Path)
	if st, err := os.Stat(rc.Path); err == nil {
		fmt.Printf("Found watch: %q - %s\n", userRel(rc.Path), st.ModTime().UTC().Format(time.RFC3339))
	}
	if isAllowed(rc) {
		fmt.Println("Found RC allowed 0")
	} else {
		fmt.Println("Found RC allowed 2")
	}
	return nil
}

func cmdEdit(args []string) error {
	rc, err := targetRC(args)
	if err != nil {
		return err
	}
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = "vi"
	}
	c := exec.Command(editor, rc.Path)
	c.Stdin = os.Stdin
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	if err := c.Run(); err != nil {
		return err
	}
	return cmdAllow([]string{rc.Path})
}

func cmdLog(args []string) error {
	status, errMode := false, false
	if len(args) > 0 && args[0] == "--status" {
		status = true
		args = args[1:]
	}
	if len(args) > 0 && args[0] == "--error" {
		errMode = true
		args = args[1:]
	}
	msg := strings.Join(args, " ")
	if errMode {
		logError(msg)
	} else if status {
		fmt.Fprintln(os.Stderr, msg)
	} else {
		logMsg("%s", msg)
	}
	return nil
}

func prune() error {
	for _, d := range []string{filepath.Join(dataDir(), "allow"), filepath.Join(dataDir(), "deny")} {
		entries, _ := os.ReadDir(d)
		for _, e := range entries {
			b, err := os.ReadFile(filepath.Join(d, e.Name()))
			if err == nil && !fileExists(strings.TrimSpace(string(b))) {
				_ = os.Remove(filepath.Join(d, e.Name()))
			}
		}
	}
	return nil
}

type change struct {
	Key     string
	Value   string
	Present bool
}

func diff(before, after map[string]string) []change {
	keys := map[string]bool{}
	for k := range before {
		keys[k] = true
	}
	for k := range after {
		keys[k] = true
	}
	var out []change
	for k := range keys {
		if strings.HasPrefix(k, "DIRENV_IN_ENVRC") {
			continue
		}
		if k == "_" || k == "PWD" || k == "OLDPWD" || k == "SHLVL" {
			continue
		}
		bv, bok := before[k]
		av, aok := after[k]
		if !aok {
			out = append(out, change{Key: k})
		} else if !bok || bv != av {
			out = append(out, change{Key: k, Value: av, Present: true})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Key < out[j].Key })
	return out
}

func printExports(shell string, changes []change) {
	switch shell {
	case "bash", "zsh":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("export %s=%s;", c.Key, shellQuote(c.Value))
			} else {
				fmt.Printf("unset %s;", c.Key)
			}
		}
	case "fish":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("set -gx %s %s;\n", c.Key, fishQuote(c.Value))
			} else {
				fmt.Printf("set -e %s;\n", c.Key)
			}
		}
	case "tcsh":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("setenv %s %s;\n", c.Key, shellQuote(c.Value))
			} else {
				fmt.Printf("unsetenv %s;\n", c.Key)
			}
		}
	case "json", "elvish", "murex":
		m := map[string]any{}
		for _, c := range changes {
			if c.Present {
				m[c.Key] = c.Value
			} else {
				m[c.Key] = nil
			}
		}
		b, _ := json.MarshalIndent(m, "", "  ")
		fmt.Println(string(b))
	case "vim":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("let $%s=%s\n", c.Key, strconv.Quote(c.Value))
			} else {
				fmt.Printf("unlet $%s\n", c.Key)
			}
		}
	case "gha":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("%s=%s\n", c.Key, c.Value)
			}
		}
	case "gzenv", "systemd":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("%s=%s\n", c.Key, c.Value)
			} else {
				fmt.Printf("%s=\n", c.Key)
			}
		}
	case "pwsh":
		for _, c := range changes {
			if c.Present {
				fmt.Printf("$env:%s = %s\n", c.Key, strconv.Quote(c.Value))
			} else {
				fmt.Printf("Remove-Item Env:\\%s\n", c.Key)
			}
		}
	default:
		logError(fmt.Sprintf("unknown target shell '%s'", shell))
	}
}

func logDiff(before, after map[string]string) {
	var plus, minus, tilde []string
	for _, c := range diff(before, after) {
		if strings.HasPrefix(c.Key, "DIRENV_") {
			continue
		}
		if !c.Present {
			minus = append(minus, "-"+c.Key)
		} else if _, ok := before[c.Key]; ok {
			tilde = append(tilde, "~"+c.Key)
		} else {
			plus = append(plus, "+"+c.Key)
		}
	}
	all := append(append(plus, minus...), tilde...)
	if len(all) > 0 {
		logMsg("export %s", strings.Join(all, " "))
	}
}

func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func fishQuote(s string) string { return shellQuote(s) }

func envMap(env []string) map[string]string {
	m := map[string]string{}
	for _, e := range env {
		k, v, ok := strings.Cut(e, "=")
		if ok {
			m[k] = v
		}
	}
	return m
}

func cloneMap(in map[string]string) map[string]string {
	out := make(map[string]string, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}

func mapToEnv(m map[string]string) []string {
	out := make([]string, 0, len(m))
	for k, v := range m {
		out = append(out, k+"="+v)
	}
	sort.Strings(out)
	return out
}

func parseEnv0(b []byte) map[string]string {
	out := map[string]string{}
	for _, part := range bytes.Split(b, []byte{0}) {
		if len(part) == 0 {
			continue
		}
		k, v, ok := bytes.Cut(part, []byte("="))
		if ok {
			out[string(k)] = string(v)
		}
	}
	return out
}

func watchBlob(rc *rcFile) string {
	h := sha256.Sum256([]byte(rc.Path))
	return base64.RawURLEncoding.EncodeToString(h[:])
}

func diffBlob(before, after map[string]string) string {
	var buf bytes.Buffer
	for _, c := range diff(before, after) {
		if c.Present {
			buf.WriteString(c.Key + "=" + c.Value + "\n")
		} else {
			buf.WriteString("unset " + c.Key + "\n")
		}
	}
	h := sha256.Sum256(buf.Bytes())
	return base64.RawURLEncoding.EncodeToString(h[:])
}

func userRel(p string) string {
	h := homeDir()
	if p == h {
		return "~"
	}
	if strings.HasPrefix(p, h+"/") {
		return "~/" + strings.TrimPrefix(p, h+"/")
	}
	if wd, err := os.Getwd(); err == nil {
		if rel, err := filepath.Rel(wd, p); err == nil && !strings.HasPrefix(rel, "..") {
			return rel
		}
	}
	return p
}

func stdlibScript() string {
	return `#!/usr/bin/env bash
shopt -s nullglob
shopt -s extglob
direnv="` + selfPath() + `"
direnv_config_dir="${DIRENV_CONFIG:-${XDG_CONFIG_HOME:-$HOME/.config}/direnv}"
export DIRENV_IN_ENVRC=1

log_status() { "$direnv" log --status "$*"; }
log_error() { "$direnv" log --error "$*"; }
has() { type "$1" >/dev/null 2>&1; }
expand_path() {
  local path="$1" base="${2:-$PWD}"
  case "$path" in /*) printf "%s\n" "$path";; ~*) eval "printf '%s\n' \"$path\"";; *) (cd "$base" 2>/dev/null && cd "$(dirname "$path")" 2>/dev/null && printf "%s/%s\n" "$PWD" "$(basename "$path")");; esac
}
user_rel_path() { case "$1" in "$HOME"/*) printf "~/%s\n" "${1#$HOME/}";; "$HOME") echo "~";; *) echo "$1";; esac; }
find_up() {
  local name="${1:-.envrc}" dir="$PWD"
  while true; do
    if [ -e "$dir/$name" ]; then echo "$dir/$name"; return 0; fi
    [ "$dir" = "/" ] && return 1
    dir="$(dirname "$dir")"
  done
}
dotenv() {
  local f="${1:-.env}"
  [ -f "$f" ] || return 1
  set -a
  source "$f"
  set +a
}
dotenv_if_exists() { [ -f "${1:-.env}" ] && dotenv "$@" || true; }
source_env() {
  local f="$1"
  [ -d "$f" ] && f="$f/.envrc"
  source "$f"
}
source_env_if_exists() { [ -f "$1" ] && source "$1" || true; }
source_up() { local f; f="$(find_up "${1:-.envrc}")" || return 1; source "$f"; }
source_up_if_exists() { local f; f="$(find_up "${1:-.envrc}")" || return 0; source "$f"; }
path_add() {
  local var="$1" p; p="$(expand_path "$2")"
  local cur="${!var}"
  export "$var=$p${cur:+:$cur}"
}
PATH_add() { path_add PATH "$1"; }
MANPATH_add() { path_add MANPATH "$1"; }
PATH_rm() {
  local old="$PATH" new="" IFS=:
  for e in $old; do
    local keep=1 pat
    for pat in "$@"; do [[ "$e" == $pat ]] && keep=0; done
    [ "$keep" = 1 ] && new="${new:+$new:}$e"
  done
  export PATH="$new"
}
load_prefix() {
  local p; p="$(expand_path "$1")"
  PATH_add "$p/bin"; path_add CPATH "$p/include"; path_add LIBRARY_PATH "$p/lib"; path_add LD_LIBRARY_PATH "$p/lib"; MANPATH_add "$p/share/man"; path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"
}
layout() {
  case "$1" in
    go) export GOPATH="$PWD/.direnv/go${GOPATH:+:$GOPATH}"; PATH_add bin;;
    node) PATH_add node_modules/.bin;;
    julia) export JULIA_PROJECT="$PWD";;
    php) PATH_add vendor/bin;;
    python|python3) local py="${2:-${1/python3/python3}}"; [ "$1" = python ] && py="${2:-python}"; local d="$PWD/.direnv/${py}"; mkdir -p "$d/bin"; export VIRTUAL_ENV="$d"; PATH_add "$d/bin";;
    ruby) export GEM_HOME="$PWD/.direnv/ruby/$(ruby -e 'print RUBY_VERSION' 2>/dev/null || echo ruby)"; PATH_add "$GEM_HOME/bin";;
    *) local fn="layout_$1"; shift; "$fn" "$@";;
  esac
}
use() { local fn="use_$1"; shift; "$fn" "$@"; }
watch_file() { :; }
watch_dir() { :; }
require_allowed() { :; }
direnv_version() { "$direnv" version "$1"; }
strict_env() { set -euo pipefail; if [ "$#" -gt 0 ]; then "$@"; fi; }
unstrict_env() { set +e +u +o pipefail; if [ "$#" -gt 0 ]; then "$@"; fi; }
env_vars_required() { local v ok=0; for v in "$@"; do [ -n "${!v:-}" ] || { log_error "\$$v is required"; ok=1; }; done; return "$ok"; }
on_git_branch() { git rev-parse --is-inside-work-tree >/dev/null 2>&1 || return 1; [ "$#" = 0 ] && return 0; [ "$(git branch --show-current 2>/dev/null)" = "$1" ]; }
direnv_layout_dir() { echo "${XDG_CACHE_HOME:-$HOME/.cache}/direnv/layouts/$(pwd | sed 's#[/:]#-#g')"; }
direnv_load() { eval "$("$@")"; }
direnv_apply_dump() { source "$1"; }
fetchurl() { "$direnv" fetchurl "$@"; }
source_url() { source "$(fetchurl "$@")"; }
`
}

func copyStream(dst io.Writer, src io.Reader) {
	_, _ = io.Copy(dst, src)
}
