package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "clog 0.10.0"

type options struct {
	repo          string
	from          string
	to            string
	format        string
	major         bool
	minor         bool
	patch         bool
	gitDir        string
	workTree      string
	subtitle      string
	outfile       string
	config        string
	infile        string
	setVersion    string
	fromLatestTag bool
	linkStyle     string
	changelog     string
}

type config struct {
	repo          string
	fromLatestTag bool
	fromLatestSet bool
	linkStyle     string
	sections      map[string]string
	aliases       map[string]string
}

type commit struct {
	Hash      string
	Short     string
	Type      string
	Scope     string
	Subject   string
	Body      string
	Breaking  bool
	Issues    []string
	RawSubj   string
}

type section struct {
	Title   string   `json:"title"`
	Commits []commit `json:"commits"`
}

func main() {
	start := time.Now()
	opts, help, ver, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if help {
		printHelp()
		return
	}
	if ver {
		fmt.Println(version)
		return
	}
	cfg := readConfig(opts.config)
	applyConfig(&opts, cfg)
	if opts.changelog != "" {
		opts.infile = opts.changelog
		opts.outfile = opts.changelog
	}
	if opts.format != "markdown" && opts.format != "json" {
		badValue("--format", opts.format, "markdown, json")
	}
	if opts.linkStyle != "github" && opts.linkStyle != "gitlab" && opts.linkStyle != "stash" && opts.linkStyle != "cgit" {
		badValue("--link-style", opts.linkStyle, "github, gitlab, stash, cgit")
	}

	headerVersion, patchHeader, err := determineVersion(opts)
	if err != nil {
		die("Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.")
	}
	commits := collectCommits(opts, cfg)
	secs := buildSections(commits, cfg)
	out := render(opts, headerVersion, patchHeader, secs)
	if opts.infile != "" {
		if b, err := os.ReadFile(opts.infile); err == nil {
			if len(b) > 0 && !bytes.HasSuffix([]byte(out), []byte("\n")) {
				out += "\n"
			}
			out += string(b)
		}
	}
	if opts.outfile != "" {
		if err := os.WriteFile(opts.outfile, []byte(out), 0644); err != nil {
			die("fatal I/O error with output file")
		}
	} else {
		fmt.Print(out)
	}
	fmt.Printf("changelog written. (took %d ms)\n", time.Since(start).Milliseconds())
}

func parseArgs(args []string) (options, bool, bool, error) {
	opts := options{format: "markdown", to: "HEAD", config: ".clog.toml", linkStyle: "github"}
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(new(bytes.Buffer))
	fs.StringVar(&opts.repo, "repository", "", "")
	fs.StringVar(&opts.repo, "r", "", "")
	fs.StringVar(&opts.from, "from", "", "")
	fs.StringVar(&opts.from, "f", "", "")
	fs.StringVar(&opts.format, "format", "markdown", "")
	fs.StringVar(&opts.format, "T", "markdown", "")
	fs.BoolVar(&opts.major, "major", false, "")
	fs.BoolVar(&opts.major, "M", false, "")
	fs.StringVar(&opts.gitDir, "git-dir", "", "")
	fs.StringVar(&opts.gitDir, "g", "", "")
	fs.StringVar(&opts.workTree, "work-tree", "", "")
	fs.StringVar(&opts.workTree, "w", "", "")
	fs.BoolVar(&opts.minor, "minor", false, "")
	fs.BoolVar(&opts.minor, "m", false, "")
	fs.BoolVar(&opts.patch, "patch", false, "")
	fs.BoolVar(&opts.patch, "p", false, "")
	fs.StringVar(&opts.subtitle, "subtitle", "", "")
	fs.StringVar(&opts.subtitle, "s", "", "")
	fs.StringVar(&opts.to, "to", "HEAD", "")
	fs.StringVar(&opts.to, "t", "HEAD", "")
	fs.StringVar(&opts.outfile, "outfile", "", "")
	fs.StringVar(&opts.outfile, "o", "", "")
	fs.StringVar(&opts.config, "config", ".clog.toml", "")
	fs.StringVar(&opts.config, "c", ".clog.toml", "")
	fs.StringVar(&opts.infile, "infile", "", "")
	fs.StringVar(&opts.infile, "i", "", "")
	fs.StringVar(&opts.setVersion, "setversion", "", "")
	fs.BoolVar(&opts.fromLatestTag, "from-latest-tag", false, "")
	fs.BoolVar(&opts.fromLatestTag, "F", false, "")
	fs.StringVar(&opts.linkStyle, "link-style", "github", "")
	fs.StringVar(&opts.linkStyle, "l", "github", "")
	fs.StringVar(&opts.changelog, "changelog", "", "")
	fs.StringVar(&opts.changelog, "C", "", "")
	help := false
	ver := false
	for _, a := range args {
		if a == "--help" || a == "-h" {
			help = true
		}
		if a == "--version" || a == "-V" {
			ver = true
		}
	}
	if help || ver {
		return opts, help, ver, nil
	}
	if err := fs.Parse(args); err != nil {
		if strings.Contains(err.Error(), "flag provided but not defined") {
			name := strings.TrimPrefix(strings.TrimPrefix(strings.TrimSpace(strings.TrimPrefix(err.Error(), "flag provided but not defined: ")), "-"), "-")
			return opts, false, false, fmt.Errorf("error: unexpected argument '--%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", name)
		}
		return opts, false, false, err
	}
	if fs.NArg() > 0 {
		return opts, false, false, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", fs.Arg(0))
	}
	return opts, false, false, nil
}

func printHelp() {
	fmt.Print(`a conventional changelog for the rest of us

Usage: executable [OPTIONS]

Options:
  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,
                          e.g. https://github.com/thoughtram/clog)
  -f, --from <COMMIT>     e.g. 12a8546
  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible
                          values: markdown, json]
  -M, --major             Increment major version by one (Sets minor and patch to 0)
  -g, --git-dir <PATH>    Local .git directory (defaults to "$(pwd)/.git")
  -w, --work-tree <PATH>  Local working tree of the git project (defaults to "$(pwd)")
  -m, --minor             Increment minor version by one (Sets patch to 0)
  -p, --patch             Increment patch version by one
  -s, --subtitle <STR>    
  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]
  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)
  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]
  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with
                          --outfile)
      --setversion <VER>  e.g. 1.0.1
  -F, --from-latest-tag   use latest tag as start (instead of --from)
  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible
                          values: github, gitlab, stash, cgit]
  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the
                          same file for both --infile and --outfile and should not be used in
                          conjunction with either)
  -h, --help              Print help
  -V, --version           Print version


If your .git directory is a child of your project directory (most common, such as /myproject/.git)
AND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only
need to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you
don't need to use both.

If using the --config to specify a clog configuration TOML file NOT in the current working directory
(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project
directory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.
`)
}

func badValue(flagName, val, possible string) {
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s <STR>'\n  [possible values: %s]\n\nFor more information, try '--help'.\n", val, flagName, possible)
	os.Exit(2)
}

func die(msg string) {
	fmt.Fprintf(os.Stderr, "\033[1;31merror:\033[0m %s\n", msg)
	os.Exit(1)
}

func readConfig(path string) config {
	cfg := config{sections: map[string]string{}, aliases: map[string]string{}}
	b, err := os.ReadFile(path)
	if err != nil {
		return cfg
	}
	section := ""
	reKV := regexp.MustCompile(`^\s*([A-Za-z0-9_.-]+)\s*=\s*(.+?)\s*$`)
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(strings.Split(line, "#")[0])
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = strings.Trim(line, "[]")
			continue
		}
		m := reKV.FindStringSubmatch(line)
		if m == nil {
			continue
		}
		k, v := m[1], strings.Trim(m[2], `" '`)
		switch section {
		case "clog":
			switch k {
			case "repository":
				cfg.repo = v
			case "from-latest-tag":
				cfg.fromLatestSet = true
				cfg.fromLatestTag = v == "true"
			case "link-style":
				cfg.linkStyle = v
			}
		case "sections":
			cfg.sections[k] = v
		case "aliases":
			cfg.aliases[k] = v
		}
	}
	return cfg
}

func applyConfig(opts *options, cfg config) {
	if opts.repo == "" {
		opts.repo = cfg.repo
	}
	if cfg.fromLatestSet && !opts.fromLatestTag && opts.from == "" {
		opts.fromLatestTag = cfg.fromLatestTag
	}
	if opts.linkStyle == "github" && cfg.linkStyle != "" {
		opts.linkStyle = cfg.linkStyle
	}
	if opts.workTree == "" {
		if strings.Contains(opts.config, string(os.PathSeparator)) {
			opts.workTree = filepath.Dir(opts.config)
		} else {
			opts.workTree, _ = os.Getwd()
		}
	}
	if opts.gitDir == "" {
		opts.gitDir = filepath.Join(opts.workTree, ".git")
	}
}

func determineVersion(opts options) (string, bool, error) {
	v := opts.setVersion
	if v == "" && (opts.major || opts.minor || opts.patch) {
		base := latestTag(opts)
		if base == "" {
			return "", false, errors.New("no version")
		}
		prefix := ""
		raw := base
		if strings.HasPrefix(raw, "v") {
			prefix = "v"
			raw = strings.TrimPrefix(raw, "v")
		}
		parts := strings.Split(raw, ".")
		if len(parts) != 3 {
			return "", false, errors.New("bad semver")
		}
		maj, e1 := strconv.Atoi(parts[0])
		min, e2 := strconv.Atoi(parts[1])
		pat, e3 := strconv.Atoi(parts[2])
		if e1 != nil || e2 != nil || e3 != nil {
			return "", false, errors.New("bad semver")
		}
		if opts.major {
			maj++
			min, pat = 0, 0
		} else if opts.minor {
			min++
			pat = 0
		} else {
			pat++
		}
		v = fmt.Sprintf("%s%d.%d.%d", prefix, maj, min, pat)
	}
	return v, opts.patch && opts.setVersion == "" && isPatch(v), nil
}

func isPatch(v string) bool {
	v = strings.TrimPrefix(v, "v")
	parts := strings.Split(v, ".")
	return len(parts) == 3 && parts[2] != "0" && v != ""
}

func latestTag(opts options) string {
	out, err := git(opts, "describe", "--tags", "--abbrev=0")
	if err != nil {
		return ""
	}
	return strings.TrimSpace(out)
}

func collectCommits(opts options, cfg config) []commit {
	if opts.fromLatestTag {
		if t := latestTag(opts); t != "" {
			opts.from = t
		}
	}
	rangeSpec := opts.to
	if opts.from != "" {
		rangeSpec = opts.from + ".." + opts.to
	}
	format := "%H%x1f%s%x1f%b%x1e"
	out, err := git(opts, "log", "--reverse", "--no-merges", "--format="+format, rangeSpec)
	if err != nil {
		return nil
	}
	var commits []commit
	for _, rec := range strings.Split(out, "\x1e") {
		rec = strings.Trim(rec, "\n")
		if rec == "" {
			continue
		}
		parts := strings.SplitN(rec, "\x1f", 3)
		if len(parts) < 2 {
			continue
		}
		body := ""
		if len(parts) == 3 {
			body = parts[2]
		}
		if c, ok := parseCommit(parts[0], parts[1], body, cfg); ok {
			commits = append(commits, c)
		}
	}
	return commits
}

func git(opts options, args ...string) (string, error) {
	base := []string{}
	if opts.gitDir != "" {
		base = append(base, "--git-dir", opts.gitDir)
	}
	if opts.workTree != "" {
		base = append(base, "--work-tree", opts.workTree)
	}
	cmd := exec.Command("git", append(base, args...)...)
	out, err := cmd.Output()
	return string(out), err
}

func parseCommit(hash, subj, body string, cfg config) (commit, bool) {
	re := regexp.MustCompile(`^([A-Za-z]+)(?:\(([^)]*)\))?(!)?:\s*(.+)$`)
	m := re.FindStringSubmatch(subj)
	if m == nil {
		return commit{}, false
	}
	typ := strings.ToLower(m[1])
	if a, ok := cfg.aliases[typ]; ok {
		typ = a
	}
	c := commit{Hash: hash, Short: shortHash(hash), Type: typ, Scope: m[2], Subject: m[4], Body: body, Breaking: m[3] == "!" || strings.Contains(body, "BREAKING CHANGE"), RawSubj: subj}
	c.Issues = findIssues(body)
	return c, true
}

func shortHash(h string) string {
	if len(h) > 7 {
		return h[:7]
	}
	return h
}

func findIssues(s string) []string {
	re := regexp.MustCompile(`(?i)(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s+#([0-9]+)`)
	seen := map[string]bool{}
	var ids []string
	for _, m := range re.FindAllStringSubmatch(s, -1) {
		if !seen[m[1]] {
			seen[m[1]] = true
			ids = append(ids, m[1])
		}
	}
	return ids
}

func buildSections(commits []commit, cfg config) []section {
	titleFor := func(c commit) string {
		if c.Breaking {
			return "Breaking Changes"
		}
		if t, ok := cfg.sections[c.Type]; ok {
			return t
		}
		switch c.Type {
		case "feat", "feature":
			return "Features"
		case "fix", "bugfix":
			return "Bug Fixes"
		case "doc", "docs":
			return "Documentation"
		case "style":
			return "Style Fixes"
		case "perf":
			return "Performance"
		case "refactor":
			return "Refactor"
		case "test", "tests":
			return "Tests"
		default:
			return ""
		}
	}
	order := []string{"Breaking Changes", "Features", "Bug Fixes", "Documentation", "Style Fixes", "Performance", "Refactor", "Tests"}
	seenOrder := map[string]int{}
	for i, t := range order {
		seenOrder[t] = i
	}
	buckets := map[string][]commit{}
	for _, c := range commits {
		t := titleFor(c)
		if t == "" {
			continue
		}
		buckets[t] = append(buckets[t], c)
		if _, ok := seenOrder[t]; !ok {
			seenOrder[t] = len(seenOrder)
		}
	}
	var titles []string
	for t := range buckets {
		titles = append(titles, t)
	}
	sort.SliceStable(titles, func(i, j int) bool { return seenOrder[titles[i]] < seenOrder[titles[j]] })
	var secs []section
	for _, t := range titles {
		secs = append(secs, section{Title: t, Commits: buckets[t]})
	}
	return secs
}

func render(opts options, ver string, patchHeader bool, secs []section) string {
	date := time.Now().Format("2006-01-02")
	if opts.format == "json" {
		return renderJSON(ver, patchHeader, opts.subtitle, date, secs)
	}
	var b strings.Builder
	b.WriteString(fmt.Sprintf("<a name=\"%s\"></a>\n", ver))
	level := "##"
	if patchHeader {
		level = "###"
	}
	b.WriteString(fmt.Sprintf("%s %s %s (%s)\n\n", level, ver, opts.subtitle, date))
	for _, s := range secs {
		b.WriteString(fmt.Sprintf("#### %s\n\n", s.Title))
		for _, c := range s.Commits {
			b.WriteString("* ")
			if c.Scope != "" {
				b.WriteString("**" + c.Scope + "**: ")
			}
			b.WriteString(c.Subject)
			b.WriteString(" ([" + c.Short + "](" + commitURL(opts, c.Hash) + "))")
			for _, id := range c.Issues {
				b.WriteString(", closes [#" + id + "](" + issueURL(opts, id) + ")")
			}
			b.WriteString("\n")
		}
		b.WriteString("\n")
	}
	return b.String()
}

func renderJSON(ver string, patchHeader bool, subtitle string, date string, secs []section) string {
	var b strings.Builder
	b.WriteString(`{"header":{"version":`)
	if ver == "" {
		b.WriteString("None")
	} else {
		writeJSONString(&b, ver)
	}
	b.WriteString(`,"patch_version":`)
	if patchHeader {
		b.WriteString("true")
	} else {
		b.WriteString("false")
	}
	b.WriteString(`,"subtitle":`)
	if subtitle == "" {
		b.WriteString("null")
	} else {
		writeJSONString(&b, subtitle)
	}
	b.WriteString(`,"date":`)
	writeJSONString(&b, date)
	b.WriteString(`},"sections":`)
	if len(secs) == 0 {
		b.WriteString("null}")
		return b.String()
	}
	raw, _ := json.Marshal(secs)
	b.Write(raw)
	b.WriteString("}")
	return b.String()
}

func writeJSONString(b *strings.Builder, s string) {
	raw, _ := json.Marshal(s)
	b.Write(raw)
}

func commitURL(opts options, hash string) string {
	repo := strings.TrimSuffix(opts.repo, "/")
	if repo == "" {
		return hash
	}
	switch opts.linkStyle {
	case "gitlab":
		return repo + "/commit/" + hash
	case "stash":
		return repo + "/commits/" + hash
	case "cgit":
		return repo + "/commit/?id=" + hash
	default:
		return repo + "/commit/" + hash
	}
}

func issueURL(opts options, id string) string {
	repo := strings.TrimSuffix(opts.repo, "/")
	if repo == "" {
		return "#" + id
	}
	switch opts.linkStyle {
	case "stash":
		return repo + "/browse/" + id
	default:
		return repo + "/issues/" + id
	}
}
