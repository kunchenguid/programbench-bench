module dirble-reimplementation

go 1.21
