package main

import (
	"bufio"
	"bytes"
	"crypto/tls"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const helpText = `Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]
`

type Config struct {
	URIs              []string
	URIFile           string
	Verb              string
	Wordlist          string
	Prefixes          []string
	PrefixFile        string
	Extensions        []string
	ExtensionFile     string
	ExtSub            bool
	ForceExtension    bool
	IgnoreCert        bool
	ShowHTAccess      bool
	Timeout           int
	MaxErrors         int
	JSONFile          string
	NoColor           bool
	OutputFile        string
	XMLFile           string
	HideLengthsRaw    []string
	OutputAll         string
	Burp              bool
	NoProxy           bool
	Proxy             string
	MaxThreads        int
	WordlistSplit     int
	ThrottleMS        int
	Username          string
	Password          string
	ScanListable      bool
	MaxRecursionDepth int
	DisableRecursion  bool
	ScrapeListable    bool
	UserAgent         string
	Cookies           []string
	Headers           []string
	Silent            bool
	Verbose           int
	CodeBlacklistRaw  []string
	DisableValidator  bool
	CodeWhitelistRaw  []string
	Scan401           bool
	Scan403           bool
}

type Result struct {
	URL               string `json:"url"`
	Code              int    `json:"code"`
	Size              int64  `json:"size"`
	IsDirectory       bool   `json:"is_directory"`
	IsListable        bool   `json:"is_listable"`
	RedirectURL       string `json:"redirect_url"`
	FoundFromListable bool   `json:"found_from_listable"`
}

func main() {
	cfg := defaultConfig()
	if err := parseArgs(os.Args[1:], cfg); err != nil {
		fmt.Fprint(os.Stderr, err.Error())
		os.Exit(2)
	}
	if len(cfg.URIs) == 0 && cfg.URIFile == "" {
		fmt.Fprint(os.Stderr, helpText)
		os.Exit(2)
	}
	if cfg.OutputAll != "" {
		cfg.OutputFile = cfg.OutputAll + ".txt"
		cfg.JSONFile = cfg.OutputAll + ".json"
		cfg.XMLFile = cfg.OutputAll + ".xml"
	}
	if cfg.Wordlist == "" {
		exe, _ := os.Executable()
		cfg.Wordlist = filepath.Join(filepath.Dir(exe), "dirble_wordlist.txt")
	}
	uris, err := allURIs(cfg)
	if err != nil {
		panic(err)
	}
	words, err := readLines(cfg.Wordlist)
	if err != nil {
		panic(err)
	}
	prefixes, err := readOptionalList(cfg.Prefixes, cfg.PrefixFile)
	if err != nil {
		panic(err)
	}
	exts, err := readOptionalList(cfg.Extensions, cfg.ExtensionFile)
	if err != nil {
		panic(err)
	}
	hide, _ := parseRanges(cfg.HideLengthsRaw)
	blacklist := parseCodes(cfg.CodeBlacklistRaw)
	whitelist := parseCodes(cfg.CodeWhitelistRaw)
	allResults := make([]Result, 0)
	client := makeClient(cfg)
	for _, raw := range uris {
		base := normalizeBase(raw)
		results := scanBase(client, cfg, base, words, prefixes, exts, hide, blacklist, whitelist)
		allResults = append(allResults, results...)
	}
	sort.SliceStable(allResults, func(i, j int) bool { return allResults[i].URL < allResults[j].URL })
	if cfg.OutputFile != "" {
		writeTextReport(cfg.OutputFile, uris, allResults)
	}
	if cfg.JSONFile != "" {
		writeJSON(cfg.JSONFile, allResults)
	}
	if cfg.XMLFile != "" {
		writeXML(cfg.XMLFile, allResults)
	}
}

func defaultConfig() *Config {
	return &Config{Verb: "get", Timeout: 5, MaxErrors: 5, MaxThreads: 10, WordlistSplit: 3, MaxRecursionDepth: 0}
}

func parseArgs(args []string, c *Config) error {
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			for _, v := range args[i+1:] {
				c.URIs = append(c.URIs, v)
			}
			break
		}
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("Dirble 1.4.2 (commit d520c82, build 2026-04-17)")
			os.Exit(0)
		case "-u", "--uri", "--url":
			c.URIs = append(c.URIs, needValue(args, &i, a))
		case "-U", "--uri-file", "--url-file":
			c.URIFile = needValue(args, &i, a)
		case "--verb":
			v := strings.ToLower(needValue(args, &i, a))
			if v != "get" && v != "head" && v != "post" {
				return fmt.Errorf("error: invalid value '%s' for '--verb <http_verb>'\n  [possible values: get, head, post]\n\nFor more information, try '--help'.\n", v)
			}
			c.Verb = v
		case "-w", "--wordlist":
			c.Wordlist = needValue(args, &i, a)
		case "-p", "--prefixes":
			c.Prefixes = append(c.Prefixes, splitComma(needValue(args, &i, a))...)
		case "-P", "--prefix-file":
			c.PrefixFile = needValue(args, &i, a)
		case "-x", "--extensions":
			c.Extensions = append(c.Extensions, splitComma(needValue(args, &i, a))...)
		case "-X", "--extension-file":
			c.ExtensionFile = needValue(args, &i, a)
		case "--ext-sub":
			c.ExtSub = true
		case "-f", "--force-extension":
			c.ForceExtension = true
		case "-k", "--ignore-cert":
			c.IgnoreCert = true
		case "--show-htaccess":
			c.ShowHTAccess = true
		case "--timeout":
			c.Timeout = atoi(needValue(args, &i, a), c.Timeout)
		case "--max-errors":
			c.MaxErrors = atoi(needValue(args, &i, a), c.MaxErrors)
		case "--json-file", "--oJ":
			c.JSONFile = needValue(args, &i, a)
		case "--no-color":
			c.NoColor = true
		case "-o", "--output-file", "--oN":
			c.OutputFile = needValue(args, &i, a)
		case "--xml-file", "--oX":
			c.XMLFile = needValue(args, &i, a)
		case "--hide-lengths":
			c.HideLengthsRaw = append(c.HideLengthsRaw, splitComma(needValue(args, &i, a))...)
		case "--output-all", "--oA":
			c.OutputAll = needValue(args, &i, a)
		case "--burp":
			c.Burp = true
		case "--no-proxy":
			c.NoProxy = true
		case "--proxy":
			c.Proxy = needValue(args, &i, a)
		case "-t", "--max-threads":
			c.MaxThreads = atoi(needValue(args, &i, a), c.MaxThreads)
		case "-T", "--wordlist-split":
			c.WordlistSplit = atoi(needValue(args, &i, a), c.WordlistSplit)
		case "-z", "--throttle":
			c.ThrottleMS = atoi(needValue(args, &i, a), 0)
		case "--username":
			c.Username = needValue(args, &i, a)
		case "--password":
			c.Password = needValue(args, &i, a)
		case "-l", "--scan-listable":
			c.ScanListable = true
		case "--max-recursion-depth":
			c.MaxRecursionDepth = atoi(needValue(args, &i, a), 0)
		case "-r", "--disable-recursion":
			c.DisableRecursion = true
		case "--scrape-listable":
			c.ScrapeListable = true
		case "-a", "--user-agent":
			c.UserAgent = needValue(args, &i, a)
		case "-c", "--cookie":
			c.Cookies = append(c.Cookies, needValue(args, &i, a))
		case "-H", "--header":
			c.Headers = append(c.Headers, needValue(args, &i, a))
		case "-S", "--silent":
			c.Silent = true
		case "-v", "--verbose":
			c.Verbose++
		case "-vv":
			c.Verbose += 2
		case "-B", "--code-blacklist":
			c.CodeBlacklistRaw = append(c.CodeBlacklistRaw, splitComma(needValue(args, &i, a))...)
		case "--disable-validator":
			c.DisableValidator = true
		case "-W", "--code-whitelist":
			c.CodeWhitelistRaw = append(c.CodeWhitelistRaw, splitComma(needValue(args, &i, a))...)
			c.DisableValidator = true
		case "--scan-401":
			c.Scan401 = true
		case "--scan-403":
			c.Scan403 = true
		default:
			if strings.HasPrefix(a, "-") {
				return fmt.Errorf("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'.\n", a, a, a)
			}
			c.URIs = append(c.URIs, a)
		}
	}
	return nil
}

func needValue(args []string, i *int, flag string) string {
	*i = *i + 1
	if *i >= len(args) {
		fmt.Fprintf(os.Stderr, "error: a value is required for '%s <value>' but none was supplied\n\nFor more information, try '--help'.\n", flag)
		os.Exit(2)
	}
	return args[*i]
}

func splitComma(s string) []string {
	out := []string{}
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func atoi(s string, def int) int {
	n, err := strconv.Atoi(s)
	if err != nil {
		return def
	}
	return n
}

func allURIs(c *Config) ([]string, error) {
	out := append([]string{}, c.URIs...)
	if c.URIFile != "" {
		lines, err := readLines(c.URIFile)
		if err != nil {
			return nil, err
		}
		out = append(out, lines...)
	}
	return out, nil
}

func readLines(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	out := []string{}
	for sc.Scan() {
		s := strings.TrimSpace(sc.Text())
		if s == "" || strings.HasPrefix(s, "#") {
			continue
		}
		out = append(out, s)
	}
	return out, sc.Err()
}

func readOptionalList(vals []string, file string) ([]string, error) {
	out := append([]string{}, vals...)
	if file != "" {
		lines, err := readLines(file)
		if err != nil {
			return nil, err
		}
		out = append(out, lines...)
	}
	return out, nil
}

func normalizeBase(raw string) string {
	if !strings.Contains(raw, "://") {
		raw = "http://" + raw
	}
	u, err := url.Parse(raw)
	if err != nil || u.Scheme == "" || u.Host == "" {
		return raw
	}
	u.RawQuery = ""
	u.Fragment = ""
	if !strings.HasSuffix(u.Path, "/") {
		u.Path += "/"
	}
	return u.String()
}

func makeClient(c *Config) *http.Client {
	tr := &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: c.IgnoreCert}}
	if c.NoProxy {
		tr.Proxy = nil
	} else if c.Burp {
		u, _ := url.Parse("http://localhost:8080")
		tr.Proxy = http.ProxyURL(u)
	} else if c.Proxy != "" {
		u, _ := url.Parse(c.Proxy)
		tr.Proxy = http.ProxyURL(u)
	} else {
		tr.Proxy = http.ProxyFromEnvironment
	}
	return &http.Client{
		Timeout:   time.Duration(c.Timeout) * time.Second,
		Transport: tr,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
}

func scanBase(client *http.Client, c *Config, base string, words, prefixes, exts []string, hide []intRange, blacklist, whitelist map[int]bool) []Result {
	notFoundCodes := map[int]bool{}
	if !c.DisableValidator {
		for i := 0; i < 3; i++ {
			u := joinURL(base, randomPath(10+i*10))
			resp, _, _, err := request(client, c, u)
			if err != nil {
				if !c.Silent {
					fmt.Printf("Curl error after requesting %s : [7] Could not connect to server (%v)\n", u, err)
				}
				continue
			}
			notFoundCodes[resp.StatusCode] = true
		}
		if len(notFoundCodes) == 0 {
			if !c.Silent {
				fmt.Printf("[WARN] %s errored too often during validation, skipping scanning\n", base)
			}
			return nil
		}
		if !c.Silent {
			codes := keys(notFoundCodes)
			fmt.Printf("[INFO] Detected nonexistent paths for %s are (CODE:%s)\n", base, strings.Join(codes, ","))
			if c.WordlistSplit < 8 {
				fmt.Printf("[INFO] Increasing wordlist-split for initial scan of %s to 8\n", base)
			}
		}
	}
	paths := buildPaths(words, prefixes, exts, c.ExtSub, c.ForceExtension)
	results := []Result{}
	seenDirs := []string{}
	var mu sync.Mutex
	jobs := make(chan string)
	wg := sync.WaitGroup{}
	workers := c.MaxThreads
	if workers < 1 {
		workers = 1
	}
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for p := range jobs {
				if c.ThrottleMS > 0 {
					time.Sleep(time.Duration(c.ThrottleMS) * time.Millisecond)
				}
				u := joinURL(base, p)
				res, ok := checkPath(client, c, u, notFoundCodes, hide, blacklist, whitelist, false)
				if ok {
					mu.Lock()
					results = append(results, res)
					if res.IsDirectory && !c.DisableRecursion {
						seenDirs = append(seenDirs, ensureSlash(res.URL))
					}
					mu.Unlock()
					if !c.Silent {
						fmt.Println(formatResult(res))
					}
				}
			}
		}()
	}
	for _, p := range paths {
		jobs <- p
	}
	close(jobs)
	wg.Wait()
	if !c.DisableRecursion && c.MaxRecursionDepth > 0 {
		for _, d := range seenDirs {
			sub := scanBase(client, c, d, words, prefixes, exts, hide, blacklist, whitelist)
			results = append(results, sub...)
		}
	}
	return results
}

func buildPaths(words, prefixes, exts []string, extSub, forceExt bool) []string {
	if len(exts) == 0 {
		exts = []string{""}
	}
	prefixes = append([]string{""}, prefixes...)
	out := []string{}
	for _, word := range words {
		for _, pre := range prefixes {
			base := pre + strings.TrimLeft(word, "/")
			if strings.Contains(base, "%EXT%") && extSub {
				for _, e := range exts {
					out = append(out, strings.ReplaceAll(base, "%EXT%", cleanExt(e)))
				}
				continue
			}
			if !forceExt {
				out = append(out, base)
			}
			for _, e := range exts {
				if e == "" {
					continue
				}
				ext := cleanExt(e)
				out = append(out, strings.TrimSuffix(base, "/")+"."+ext)
			}
		}
	}
	return out
}

func cleanExt(e string) string {
	return strings.TrimPrefix(strings.TrimSpace(e), ".")
}

func checkPath(client *http.Client, c *Config, u string, notFound map[int]bool, hide []intRange, blacklist, whitelist map[int]bool, fromListable bool) (Result, bool) {
	resp, body, dest, err := request(client, c, u)
	if err != nil {
		if c.Verbose > 0 && !c.Silent {
			fmt.Printf("Curl error after requesting %s : %v\n", u, err)
		}
		return Result{}, false
	}
	code := resp.StatusCode
	size := int64(len(body))
	if len(whitelist) > 0 && !whitelist[code] {
		return Result{}, false
	}
	if blacklist[code] || notFound[code] {
		return Result{}, false
	}
	if code == 403 && strings.Contains(u, ".ht") && !c.ShowHTAccess {
		return Result{}, false
	}
	if inRanges(int(size), hide) {
		return Result{}, false
	}
	if code < 200 || code >= 500 {
		return Result{}, false
	}
	isDir := false
	isList := strings.HasSuffix(u, "/") && bytes.Contains(bytes.ToLower(body), []byte("index of"))
	if isList {
		isDir = true
	}
	if isList && !c.ScanListable && code == 200 {
		// The original reports listable directories; the flag mainly controls recursion.
	}
	return Result{URL: strings.TrimRight(u, "/"), Code: code, Size: size, IsDirectory: isDir, IsListable: isList, RedirectURL: dest, FoundFromListable: fromListable}, true
}

func request(client *http.Client, c *Config, u string) (*http.Response, []byte, string, error) {
	method := strings.ToUpper(c.Verb)
	req, err := http.NewRequest(method, u, nil)
	if err != nil {
		return nil, nil, "", err
	}
	if c.UserAgent != "" {
		req.Header.Set("User-Agent", c.UserAgent)
	}
	for _, ck := range c.Cookies {
		req.Header.Add("Cookie", ck)
	}
	for _, h := range c.Headers {
		if strings.Contains(h, ":") {
			parts := strings.SplitN(h, ":", 2)
			req.Header.Set(strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1]))
		} else if strings.HasSuffix(h, ";") {
			req.Header.Set(strings.TrimSuffix(h, ";"), "")
		}
	}
	if c.Username != "" || c.Password != "" {
		req.SetBasicAuth(c.Username, c.Password)
	} else if pu, err := url.Parse(u); err == nil && pu.User != nil {
		pw, _ := pu.User.Password()
		req.SetBasicAuth(pu.User.Username(), pw)
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, nil, "", err
	}
	defer resp.Body.Close()
	var body []byte
	if method == "HEAD" {
		body = []byte{}
	} else {
		body, _ = io.ReadAll(resp.Body)
	}
	dest := resp.Header.Get("Location")
	if dest != "" {
		if ru, err := url.Parse(dest); err == nil && !ru.IsAbs() {
			bu, _ := url.Parse(u)
			dest = bu.ResolveReference(ru).String()
		}
	}
	return resp, body, dest, nil
}

func joinURL(base, p string) string {
	b := ensureSlash(base)
	return b + strings.TrimLeft(p, "/")
}

func ensureSlash(s string) string {
	if !strings.HasSuffix(s, "/") {
		return s + "/"
	}
	return s
}

func randomPath(n int) string {
	const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	var b strings.Builder
	for i := 0; i < n; i++ {
		b.WriteByte(chars[r.Intn(len(chars))])
	}
	return b.String()
}

func keys(m map[int]bool) []string {
	ints := []int{}
	for k := range m {
		ints = append(ints, k)
	}
	sort.Ints(ints)
	out := []string{}
	for _, k := range ints {
		out = append(out, strconv.Itoa(k))
	}
	return out
}

func formatResult(r Result) string {
	prefix := "+"
	if r.IsListable {
		prefix = "L"
	} else if r.IsDirectory {
		prefix = "D"
	}
	s := fmt.Sprintf("%s %s (CODE:%d|SIZE:%d", prefix, r.URL, r.Code, r.Size)
	if r.RedirectURL != "" {
		s += "|DEST:" + r.RedirectURL
	}
	return s + ")"
}

type intRange struct{ lo, hi int }

func parseRanges(vals []string) ([]intRange, error) {
	out := []intRange{}
	for _, v := range vals {
		if v == "" {
			continue
		}
		if strings.Contains(v, "-") {
			parts := strings.SplitN(v, "-", 2)
			lo, e1 := strconv.Atoi(parts[0])
			hi, e2 := strconv.Atoi(parts[1])
			if e1 != nil || e2 != nil {
				return nil, errors.New("bad range")
			}
			out = append(out, intRange{lo, hi})
		} else {
			n, err := strconv.Atoi(v)
			if err != nil {
				return nil, err
			}
			out = append(out, intRange{n, n})
		}
	}
	return out, nil
}

func inRanges(n int, rs []intRange) bool {
	for _, r := range rs {
		if n >= r.lo && n <= r.hi {
			return true
		}
	}
	return false
}

func parseCodes(vals []string) map[int]bool {
	out := map[int]bool{}
	for _, v := range vals {
		n, err := strconv.Atoi(strings.TrimSpace(v))
		if err == nil {
			out[n] = true
		}
	}
	return out
}

func writeTextReport(path string, bases []string, results []Result) {
	var b strings.Builder
	if len(bases) == 1 {
		b.WriteString("Dirble Scan Report for " + normalizeBase(bases[0]) + ":\n")
	} else {
		b.WriteString("Dirble Scan Report:\n")
	}
	for _, r := range results {
		b.WriteString(formatResult(r) + "\n")
	}
	_ = os.WriteFile(path, []byte(b.String()), 0644)
}

func writeJSON(path string, results []Result) {
	data, _ := json.MarshalIndent(results, "", "")
	data = bytes.ReplaceAll(data, []byte("},{"), []byte("},\n{"))
	_ = os.WriteFile(path, data, 0644)
}

type xmlResult struct {
	XMLName           xml.Name `xml:"path"`
	URL               string   `xml:"url,attr"`
	Code              int      `xml:"code,attr"`
	ContentLen        int64    `xml:"content_len,attr"`
	IsDirectory       bool     `xml:"is_directory,attr"`
	IsListable        bool     `xml:"is_listable,attr"`
	RedirectURL       string   `xml:"redirect_url,attr"`
	FoundFromListable bool     `xml:"found_from_listable,attr"`
}

func writeXML(path string, results []Result) {
	var b strings.Builder
	b.WriteString("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<dirble_scan>\n")
	for _, r := range results {
		x := xmlResult{URL: r.URL, Code: r.Code, ContentLen: r.Size, IsDirectory: r.IsDirectory, IsListable: r.IsListable, RedirectURL: r.RedirectURL, FoundFromListable: r.FoundFromListable}
		data, _ := xml.Marshal(x)
		b.Write(data)
		b.WriteByte('\n')
	}
	b.WriteString("</dirble_scan>")
	_ = os.WriteFile(path, []byte(b.String()), 0644)
}
