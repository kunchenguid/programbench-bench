package main

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const usage = `Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.
`

type options struct {
	all, pass, skip, notests, smallscreen bool
	nocolor, follow, includeTimestamp     bool
	progress                              bool
	version, help                         bool
	slow                                  int
	sortBy, format, file, followOutput    string
	compare, trimpath                     string
}

type event struct {
	Time    string  `json:"Time"`
	Action  string  `json:"Action"`
	Package string  `json:"Package"`
	Test    string  `json:"Test"`
	Output  string  `json:"Output"`
	Elapsed float64 `json:"Elapsed"`
}

type testResult struct {
	Package string
	Name    string
	Status  string
	Elapsed float64
	Outputs []string
	Order   int
}

type pkgResult struct {
	Name       string
	Status     string
	Elapsed    float64
	Cover      string
	Pass, Fail int
	Skip       int
	NoTest     string
	Tests      map[string]*testResult
	Order      int
}

type runData struct {
	Packages map[string]*pkgResult
	Order    []string
	Tests    []*testResult
}

func main() {
	opts := parseFlags()
	if opts.help {
		fmt.Print(usage)
		return
	}
	if opts.version {
		fmt.Println("tparse version: (devel)")
		return
	}

	in, closeFn, err := input(opts.file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if closeFn != nil {
		defer closeFn()
	}

	data, err := parse(in, opts)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	render(data, opts)
	if hasFail(data) {
		os.Exit(1)
	}
}

func parseFlags() options {
	var o options
	fs := flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	fs.Usage = func() { fmt.Print(usage) }
	fs.BoolVar(&o.help, "h", false, "")
	fs.BoolVar(&o.help, "help", false, "")
	fs.BoolVar(&o.version, "v", false, "")
	fs.BoolVar(&o.version, "version", false, "")
	fs.BoolVar(&o.all, "all", false, "")
	fs.BoolVar(&o.pass, "pass", false, "")
	fs.BoolVar(&o.skip, "skip", false, "")
	fs.BoolVar(&o.notests, "notests", false, "")
	fs.BoolVar(&o.smallscreen, "smallscreen", false, "")
	fs.IntVar(&o.slow, "slow", 0, "")
	fs.StringVar(&o.sortBy, "sort", "name", "")
	fs.BoolVar(&o.nocolor, "nocolor", false, "")
	fs.StringVar(&o.format, "format", "basic", "")
	fs.StringVar(&o.file, "file", "", "")
	fs.BoolVar(&o.follow, "follow", false, "")
	fs.StringVar(&o.followOutput, "follow-output", "", "")
	fs.BoolVar(&o.includeTimestamp, "include-timestamp", false, "")
	fs.BoolVar(&o.progress, "progress", false, "")
	fs.StringVar(&o.compare, "compare", "", "")
	fs.StringVar(&o.trimpath, "trimpath", "", "")
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}
	return o
}

func input(path string) (io.Reader, func(), error) {
	if path != "" {
		f, err := os.Open(path)
		if err != nil {
			return nil, nil, err
		}
		return f, func() { _ = f.Close() }, nil
	}
	st, err := os.Stdin.Stat()
	if err != nil {
		return nil, nil, err
	}
	if st.Mode()&os.ModeCharDevice != 0 || st.Mode().IsRegular() {
		return nil, nil, fmt.Errorf("stdin must be a pipe, or use -file to open a go test output file")
	}
	return os.Stdin, nil, nil
}

func parse(r io.Reader, opts options) (*runData, error) {
	d := &runData{Packages: map[string]*pkgResult{}}
	var followFile *os.File
	if opts.followOutput != "" {
		var err error
		followFile, err = os.Create(opts.followOutput)
		if err != nil {
			return nil, err
		}
		defer followFile.Close()
	}
	sc := bufio.NewScanner(r)
	buf := make([]byte, 0, 1024*1024)
	sc.Buffer(buf, 64*1024*1024)
	order := 0
	for sc.Scan() {
		line := sc.Text()
		var ev event
		if err := json.Unmarshal([]byte(line), &ev); err != nil {
			return nil, err
		}
		p := d.pkg(ev.Package)
		if p.Order == 0 && len(d.Order) == 0 && p.Name == ev.Package {
			// Order zero is a valid first value; package creation appends to Order.
		}
		if ev.Test != "" {
			t := p.test(ev.Test, &order)
			switch ev.Action {
			case "output":
				t.Outputs = append(t.Outputs, ev.Output)
			case "pass", "fail", "skip":
				t.Status = strings.ToUpper(ev.Action)
				t.Elapsed = ev.Elapsed
				d.Tests = append(d.Tests, t)
				switch ev.Action {
				case "pass":
					p.Pass++
				case "fail":
					p.Fail++
				case "skip":
					p.Skip++
				}
			}
		} else {
			if ev.Action == "output" {
				if strings.Contains(ev.Output, "[no test files]") {
					p.Status = "NOTEST"
					p.NoTest = "[no test files]"
				}
				if strings.Contains(ev.Output, "testing: warning: no tests to run") || strings.Contains(ev.Output, "[no tests to run]") {
					p.NoTest = "[no tests to run]"
				}
				if c := parseCover(ev.Output); c != "" {
					p.Cover = c
				}
			}
			if ev.Action == "pass" || ev.Action == "fail" || ev.Action == "skip" {
				p.Elapsed = ev.Elapsed
				if p.NoTest != "" || (ev.Action == "skip" && p.Pass+p.Fail+p.Skip == 0) {
					p.Status = "NOTEST"
					if p.NoTest == "" {
						p.NoTest = "[no tests to run]"
					}
				} else {
					p.Status = strings.ToUpper(ev.Action)
				}
				if opts.progress {
					fmt.Printf("[%s]\t%9s\t%s\n", p.Status, fmt.Sprintf("%.2fs", p.Elapsed), trimPkg(p.Name, opts.trimpath))
				}
			}
		}
		if ev.Action == "output" && (opts.follow || followFile != nil) {
			out := ev.Output
			if opts.includeTimestamp && ev.Time != "" {
				out = ev.Time + " " + out
			}
			if followFile != nil {
				_, _ = followFile.WriteString(out)
			} else {
				fmt.Print(out)
			}
		}
	}
	return d, sc.Err()
}

func (d *runData) pkg(name string) *pkgResult {
	if name == "" {
		name = "(unknown)"
	}
	if p := d.Packages[name]; p != nil {
		return p
	}
	p := &pkgResult{Name: name, Status: "PASS", Cover: "--", Tests: map[string]*testResult{}, Order: len(d.Order)}
	d.Packages[name] = p
	d.Order = append(d.Order, name)
	return p
}

func (p *pkgResult) test(name string, order *int) *testResult {
	if t := p.Tests[name]; t != nil {
		return t
	}
	*order++
	t := &testResult{Package: p.Name, Name: name, Order: *order}
	p.Tests[name] = t
	return t
}

func parseCover(s string) string {
	i := strings.Index(s, "coverage:")
	if i < 0 {
		return ""
	}
	rest := strings.TrimSpace(s[i+len("coverage:"):])
	fields := strings.Fields(rest)
	if len(fields) > 0 {
		if !strings.HasSuffix(fields[0], "%") {
			return ""
		}
		return fields[0]
	}
	return ""
}

func render(d *runData, opts options) {
	if opts.format == "markdown" {
		renderMarkdown(d, opts)
		return
	}
	rows := selectedTests(d, opts)
	if len(rows) > 0 {
		if opts.format == "plain" {
			printPlain(testRows(rows, opts), []string{"Status", "Elapsed", "Test", "Package"})
		} else {
			printBox(testRows(rows, opts), []string{"Status", "Elapsed", "Test", "Package"})
		}
	}
	for _, name := range d.Order {
		p := d.Packages[name]
		if p.Fail > 0 {
			printFailure(p, opts)
		}
	}
	pkgRows := packageRows(d, opts)
	if len(pkgRows) > 0 {
		if opts.format == "plain" {
			printPlain(pkgRows, []string{"Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"})
		} else {
			printBox(pkgRows, []string{"Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"})
		}
	}
}

func selectedTests(d *runData, opts options) []*testResult {
	var out []*testResult
	for _, t := range d.Tests {
		if t.Status == "FAIL" || (opts.all && (t.Status == "PASS" || t.Status == "SKIP")) || (opts.pass && t.Status == "PASS") || (opts.skip && t.Status == "SKIP") {
			out = append(out, t)
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		a, b := out[i], out[j]
		switch opts.sortBy {
		case "elapsed":
			if a.Elapsed != b.Elapsed {
				return a.Elapsed > b.Elapsed
			}
		}
		if a.Package != b.Package {
			return a.Package < b.Package
		}
		if a.Status != b.Status {
			return statusRank(a.Status) < statusRank(b.Status)
		}
		if a.Status != "FAIL" && a.Elapsed != b.Elapsed {
			return a.Elapsed > b.Elapsed
		}
		return a.Name < b.Name
	})
	if opts.slow > 0 && len(out) > opts.slow {
		return out[:opts.slow]
	}
	return out
}

func statusRank(s string) int {
	switch s {
	case "PASS":
		return 0
	case "SKIP":
		return 1
	case "FAIL":
		return 2
	}
	return 3
}

func testRows(tests []*testResult, opts options) [][]string {
	var rows [][]string
	prev := ""
	for _, t := range tests {
		pkg := trimPkg(t.Package, opts.trimpath)
		if prev != "" && prev != pkg {
			rows = append(rows, []string{"", "", "", ""})
		}
		prev = pkg
		name := t.Name
		if opts.smallscreen {
			name = strings.ReplaceAll(name, "/", "\n")
		}
		rows = append(rows, []string{t.Status, fmt.Sprintf("%.2f", t.Elapsed), name, pkg})
	}
	return rows
}

func packageRows(d *runData, opts options) [][]string {
	var pkgs []*pkgResult
	for _, name := range d.Order {
		p := d.Packages[name]
		if p.Status == "NOTEST" && !opts.notests {
			continue
		}
		pkgs = append(pkgs, p)
	}
	sort.SliceStable(pkgs, func(i, j int) bool {
		a, b := pkgs[i], pkgs[j]
		switch opts.sortBy {
		case "elapsed":
			if a.Elapsed != b.Elapsed {
				return a.Elapsed > b.Elapsed
			}
		case "cover":
			if coverVal(a.Cover) != coverVal(b.Cover) {
				return coverVal(a.Cover) > coverVal(b.Cover)
			}
		}
		if (a.Status == "NOTEST") != (b.Status == "NOTEST") {
			return a.Status != "NOTEST"
		}
		return a.Name < b.Name
	})
	var rows [][]string
	for _, p := range pkgs {
		pass, fail, skip := strconv.Itoa(p.Pass), strconv.Itoa(p.Fail), strconv.Itoa(p.Skip)
		if p.Status == "NOTEST" {
			pass, fail, skip = "--", "--", "--"
		}
		rows = append(rows, []string{p.Status, fmt.Sprintf("%.2fs", p.Elapsed), trimPkg(p.Name, opts.trimpath), p.Cover, pass, fail, skip})
		if p.Status == "NOTEST" && p.NoTest != "" {
			rows = append(rows, []string{"", "", p.NoTest, "", "", "", ""})
		}
	}
	return rows
}

func coverVal(s string) float64 {
	s = strings.TrimSuffix(s, "%")
	v, _ := strconv.ParseFloat(s, 64)
	return v
}

func printFailure(p *pkgResult, opts options) {
	pkg := trimPkg(p.Name, opts.trimpath)
	title := "   FAIL  package: " + pkg + "   "
	if opts.format == "plain" {
		fmt.Printf("\nFAIL  package: %s\n\n", pkg)
	} else {
		line := strings.Repeat("━", len([]rune(title)))
		fmt.Println("┏" + line + "┓")
		fmt.Println("┃" + title + "┃")
		fmt.Println("┗" + line + "┛")
		fmt.Println()
	}
	first := true
	printed := map[string]bool{}
	var names []string
	for name, t := range p.Tests {
		if t.Status == "FAIL" && !strings.Contains(name, "/") {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	for _, name := range names {
		t := p.Tests[name]
		text := failureText(t)
		if text == "" {
			continue
		}
		if !first {
			fmt.Println()
			fmt.Println("────────────────────────────────────────────────────────────────────────────────────────────────")
			fmt.Println("                                                                                                ")
		}
		first = false
		fmt.Print(text)
		if !strings.HasSuffix(text, "\n") {
			fmt.Println()
		}
		printed[name] = true
		children := failedChildren(p, name)
		for _, child := range children {
			ctext := failureText(p.Tests[child])
			if ctext == "" || strings.Contains(text, strings.TrimSpace(ctext)) {
				continue
			}
			fmt.Print(ctext)
			if !strings.HasSuffix(ctext, "\n") {
				fmt.Println()
			}
			printed[child] = true
		}
	}
	var child []string
	for name, t := range p.Tests {
		if t.Status == "FAIL" && !printed[name] {
			child = append(child, name)
		}
	}
	sort.Strings(child)
	for _, name := range child {
		text := failureText(p.Tests[name])
		if text == "" {
			continue
		}
		if !first {
			// Children are often already present in parent output; print only if unique.
			if strings.Contains(strings.Join(outputsForPrinted(p, printed), ""), strings.TrimSpace(text)) {
				continue
			}
			fmt.Println()
		}
		first = false
		fmt.Print(text)
		if !strings.HasSuffix(text, "\n") {
			fmt.Println()
		}
	}
}

func failedChildren(p *pkgResult, parent string) []string {
	var out []string
	prefix := parent + "/"
	for name, t := range p.Tests {
		if t.Status == "FAIL" && strings.HasPrefix(name, prefix) {
			out = append(out, name)
		}
	}
	sort.Strings(out)
	return out
}

func outputsForPrinted(p *pkgResult, printed map[string]bool) []string {
	var s []string
	for name := range printed {
		s = append(s, strings.Join(p.Tests[name].Outputs, ""))
	}
	return s
}

func failureText(t *testResult) string {
	var heads, rest strings.Builder
	for _, o := range t.Outputs {
		if strings.HasPrefix(o, "=== RUN") || strings.HasPrefix(o, "=== PAUSE") || strings.HasPrefix(o, "=== CONT") {
			continue
		}
		if strings.HasPrefix(o, "--- PASS:") || strings.HasPrefix(o, "--- SKIP:") {
			continue
		}
		if strings.HasPrefix(o, "--- FAIL:") || strings.HasPrefix(o, "panic:") {
			heads.WriteString(o)
		} else {
			rest.WriteString(o)
		}
	}
	if heads.Len() > 0 && rest.Len() > 0 {
		return heads.String() + "\n" + rest.String()
	}
	return heads.String() + rest.String()
}

func printBox(rows [][]string, headers []string) {
	widths := widths(rows, headers)
	fmt.Println(border("╭", "┬", "╮", widths))
	fmt.Println(rowLine("│", headers, widths))
	fmt.Println(border("├", "┼", "┤", widths))
	for _, r := range rows {
		fmt.Println(rowLine("│", r, widths))
	}
	fmt.Println(border("╰", "┴", "╯", widths))
}

func border(l, m, r string, widths []int) string {
	parts := make([]string, len(widths))
	for i, w := range widths {
		parts[i] = strings.Repeat("─", w+2)
	}
	return l + strings.Join(parts, m) + r
}

func rowLine(sep string, row []string, widths []int) string {
	cells := make([]string, len(widths))
	for i, w := range widths {
		val := ""
		if i < len(row) {
			val = row[i]
		}
		cells[i] = " " + center(val, w) + " "
	}
	return sep + strings.Join(cells, sep) + sep
}

func printPlain(rows [][]string, headers []string) {
	widths := widths(rows, headers)
	fmt.Println(plainLine(headers, widths))
	fmt.Println(plainLine(make([]string, len(headers)), widths))
	for _, r := range rows {
		fmt.Println(plainLine(r, widths))
	}
}

func plainLine(row []string, widths []int) string {
	var parts []string
	for i, w := range widths {
		val := ""
		if i < len(row) {
			val = row[i]
		}
		parts = append(parts, " "+center(val, w)+" ")
	}
	return strings.Join(parts, " ")
}

func widths(rows [][]string, headers []string) []int {
	w := make([]int, len(headers))
	for i, h := range headers {
		w[i] = runeLen(h)
	}
	for _, r := range rows {
		for i := range w {
			if i < len(r) {
				for _, part := range strings.Split(r[i], "\n") {
					if runeLen(part) > w[i] {
						w[i] = runeLen(part)
					}
				}
			}
		}
	}
	return w
}

func center(s string, width int) string {
	n := runeLen(s)
	if n >= width {
		return s
	}
	left := (width - n) / 2
	right := width - n - left
	return strings.Repeat(" ", left) + s + strings.Repeat(" ", right)
}

func runeLen(s string) int { return len([]rune(s)) }

func renderMarkdown(d *runData, opts options) {
	for _, name := range d.Order {
		p := d.Packages[name]
		if p.Status == "NOTEST" && !opts.notests {
			continue
		}
		pkg := trimPkg(p.Name, opts.trimpath)
		fmt.Printf("## 📦 Package **`%s`**\n\n", pkg)
		fmt.Printf("Tests: ✓ %d passed | %d skipped | %d failed\n\n", p.Pass, p.Skip, p.Fail)
		tests := selectedTests(&runData{Tests: pkgTests(p), Packages: d.Packages, Order: d.Order}, opts)
		if len(tests) > 0 {
			fmt.Println("<details>\n")
			fmt.Println("<summary>Click for test summary</summary>\n")
			printMarkdown(testRowsNoPkg(tests), []string{"Status", "Elapsed", "Test"})
			fmt.Println("</details>\n")
		}
		if p.Fail > 0 {
			fmt.Printf("\n## FAIL • %s\n\n```\n", pkg)
			var parts []string
			for _, t := range tests {
				if t.Status == "FAIL" {
					if txt := strings.TrimRight(failureText(t), "\n"); txt != "" {
						parts = append(parts, txt)
					}
				}
			}
			fmt.Println(strings.Join(parts, "\n────────────────────────────────────────────────────────────────────────────────────────────────\n                                                                                                \n"))
			fmt.Println("```\n")
		}
	}
	printMarkdown(packageRows(d, opts), []string{"Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"})
}

func pkgTests(p *pkgResult) []*testResult {
	var out []*testResult
	for _, t := range p.Tests {
		out = append(out, t)
	}
	return out
}

func testRowsNoPkg(tests []*testResult) [][]string {
	var rows [][]string
	for _, t := range tests {
		rows = append(rows, []string{t.Status, fmt.Sprintf("%.2f", t.Elapsed), t.Name})
	}
	return rows
}

func printMarkdown(rows [][]string, headers []string) {
	if len(rows) == 0 {
		return
	}
	widths := widths(rows, headers)
	fmt.Println(mdRow(headers, widths))
	sep := make([]string, len(widths))
	for i, w := range widths {
		sep[i] = strings.Repeat("-", w+2)
	}
	fmt.Println("|" + strings.Join(sep, "|") + "|")
	for _, r := range rows {
		fmt.Println(mdRow(r, widths))
	}
}

func mdRow(row []string, widths []int) string {
	cells := make([]string, len(widths))
	for i, w := range widths {
		val := ""
		if i < len(row) {
			val = row[i]
		}
		cells[i] = " " + center(val, w) + " "
	}
	return "|" + strings.Join(cells, "|") + "|"
}

func hasFail(d *runData) bool {
	for _, p := range d.Packages {
		if p.Status == "FAIL" || p.Fail > 0 {
			return true
		}
	}
	return false
}

func trimPkg(pkg, prefix string) string {
	if prefix == "" {
		return pkg
	}
	prefix = filepath.Clean(prefix)
	if strings.HasPrefix(pkg, prefix) {
		return strings.TrimPrefix(strings.TrimPrefix(pkg, prefix), "/")
	}
	return pkg
}
