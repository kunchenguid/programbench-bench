module reimpl-tparse

go 1.21
