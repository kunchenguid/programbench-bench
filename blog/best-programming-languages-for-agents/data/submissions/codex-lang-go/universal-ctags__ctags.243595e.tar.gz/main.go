package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type Tag struct {
	Name      string
	Path      string
	Pattern   string
	Raw       string
	Line      int
	Kind      string
	KindLong  string
	Scope     string
	ScopeKind string
	TypeRef   string
	File      bool
}

type Config struct {
	OutFile      string
	OutputFormat string
	Sort         string
	Recurse      bool
	Append       bool
	Filter       bool
	PrintLang    bool
	Totals       bool
	Machinable   bool
	Header       bool
	Language     string
	ListFile     string
	Excludes     []string
	Files        []string
}

var ident = `[A-Za-z_][A-Za-z0-9_]*`

func main() {
	cfg := Config{OutFile: "tags", OutputFormat: "u-ctags", Sort: "yes", Header: true}
	if !parseArgs(os.Args[1:], &cfg) {
		os.Exit(1)
	}
	if handleListings(cfg) {
		return
	}
	if cfg.Filter {
		runFilter(cfg)
		return
	}
	files := collectFiles(cfg)
	if cfg.PrintLang {
		for _, f := range files {
			fmt.Println(languageFor(f, cfg.Language))
		}
		return
	}
	var tags []Tag
	for _, f := range files {
		tags = append(tags, parseFile(f, cfg)...)
	}
	if cfg.Sort != "no" {
		sort.SliceStable(tags, func(i, j int) bool {
			a, b := tags[i].Name, tags[j].Name
			if cfg.Sort == "foldcase" {
				a, b = strings.ToLower(a), strings.ToLower(b)
			}
			if a == b {
				if tags[i].Path == tags[j].Path {
					return tags[i].Kind < tags[j].Kind
				}
				return tags[i].Path < tags[j].Path
			}
			return a < b
		})
	}
	if err := writeOutput(cfg, tags, files); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parseArgs(args []string, cfg *Config) bool {
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--help" || a == "-?":
			printHelp()
			os.Exit(0)
		case a == "--help-full":
			printHelp()
			os.Exit(0)
		case strings.HasPrefix(a, "--version"):
			fmt.Println("Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team")
			fmt.Println("Universal Ctags is derived from Exuberant Ctags.")
			fmt.Println("Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert")
			os.Exit(0)
		case a == "--license":
			fmt.Println("Universal Ctags is free software, licensed under the GNU General Public License.")
			os.Exit(0)
		case a == "-R":
			cfg.Recurse = true
		case strings.HasPrefix(a, "--recurse"):
			cfg.Recurse = boolOpt(a, true)
		case a == "-x":
			cfg.OutputFormat = "xref"
			cfg.OutFile = "-"
		case a == "-e":
			cfg.OutputFormat = "etags"
			cfg.OutFile = "TAGS"
		case a == "-u":
			cfg.Sort = "no"
		case a == "-a":
			cfg.Append = true
		case a == "-f" || a == "-o":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "executable: Option requires an argument -- "+a)
				return false
			}
			cfg.OutFile = args[i]
		case strings.HasPrefix(a, "-f"):
			cfg.OutFile = strings.TrimPrefix(a, "-f")
		case a == "-L":
			i++
			if i >= len(args) {
				return false
			}
			cfg.ListFile = args[i]
		case strings.HasPrefix(a, "--output-format="):
			cfg.OutputFormat = strings.TrimPrefix(a, "--output-format=")
			if cfg.OutputFormat == "xref" || cfg.OutputFormat == "json" {
				cfg.OutFile = "-"
			}
		case strings.HasPrefix(a, "--sort="):
			cfg.Sort = strings.TrimPrefix(a, "--sort=")
		case strings.HasPrefix(a, "--language-force="):
			cfg.Language = strings.TrimPrefix(a, "--language-force=")
		case strings.HasPrefix(a, "--languages="), strings.HasPrefix(a, "--fields"), strings.HasPrefix(a, "--extras"), strings.HasPrefix(a, "--kinds-"), strings.HasPrefix(a, "--roles-"), strings.HasPrefix(a, "--excmd"), strings.HasPrefix(a, "--format"), strings.HasPrefix(a, "--tag-relative"), strings.HasPrefix(a, "--options"), strings.HasPrefix(a, "--quiet"), strings.HasPrefix(a, "--verbose"), strings.HasPrefix(a, "--links"), strings.HasPrefix(a, "--maxdepth"), strings.HasPrefix(a, "--pseudo-tags"), strings.HasPrefix(a, "--pattern-length-limit"), strings.HasPrefix(a, "--input-encoding"), strings.HasPrefix(a, "--output-encoding"), strings.HasPrefix(a, "--if0"), strings.HasPrefix(a, "--line-directives"), strings.HasPrefix(a, "--param-"), strings.HasPrefix(a, "--map-"), strings.HasPrefix(a, "--alias-"), strings.HasPrefix(a, "--langmap"), strings.HasPrefix(a, "--regex-"), strings.HasPrefix(a, "--mline-regex-"), strings.HasPrefix(a, "--kinddef-"), strings.HasPrefix(a, "--langdef"), strings.HasPrefix(a, "--optlib-dir"), strings.HasPrefix(a, "--etags-include"), strings.HasPrefix(a, "-I"), strings.HasPrefix(a, "-D"), a == "-B" || a == "-F" || a == "-G" || a == "-n" || a == "-N":
			if (a == "-I" || a == "-D" || a == "-h") && i+1 < len(args) {
				i++
			}
		case strings.HasPrefix(a, "--exclude="):
			cfg.Excludes = append(cfg.Excludes, strings.TrimPrefix(a, "--exclude="))
		case strings.HasPrefix(a, "--filter"):
			cfg.Filter = boolOpt(a, true)
			cfg.OutFile = "-"
		case strings.HasPrefix(a, "--totals"):
			cfg.Totals = true
		case strings.HasPrefix(a, "--machinable"):
			cfg.Machinable = boolOpt(a, true)
		case strings.HasPrefix(a, "--with-list-header"):
			cfg.Header = boolOpt(a, true)
		case a == "--print-language":
			cfg.PrintLang = true
		case strings.HasPrefix(a, "-") && len(a) > 1:
			// Many ctags options are accepted as no-ops to keep scripts working.
		default:
			cfg.Files = append(cfg.Files, a)
		}
	}
	return true
}

func boolOpt(s string, def bool) bool {
	if !strings.Contains(s, "=") {
		return def
	}
	v := strings.ToLower(s[strings.IndexByte(s, '=')+1:])
	return v == "yes" || v == "true" || v == "1"
}

func collectFiles(cfg Config) []string {
	files := append([]string{}, cfg.Files...)
	if cfg.ListFile != "" {
		var r io.Reader
		if cfg.ListFile == "-" {
			r = os.Stdin
		} else if f, err := os.Open(cfg.ListFile); err == nil {
			defer f.Close()
			r = f
		}
		if r != nil {
			sc := bufio.NewScanner(r)
			for sc.Scan() {
				if s := strings.TrimSpace(sc.Text()); s != "" {
					files = append(files, s)
				}
			}
		}
	}
	if len(files) == 0 {
		files = []string{"."}
		cfg.Recurse = true
	}
	var out []string
	for _, f := range files {
		info, err := os.Stat(f)
		if err != nil {
			continue
		}
		if info.IsDir() {
			if !cfg.Recurse {
				continue
			}
			filepath.WalkDir(f, func(path string, d os.DirEntry, err error) error {
				if err == nil && !d.IsDir() && !excluded(path, cfg.Excludes) {
					out = append(out, path)
				}
				return nil
			})
		} else if !excluded(f, cfg.Excludes) {
			out = append(out, f)
		}
	}
	return out
}

func excluded(path string, pats []string) bool {
	base := filepath.Base(path)
	for _, p := range pats {
		if ok, _ := filepath.Match(p, base); ok {
			return true
		}
		if ok, _ := filepath.Match(p, path); ok {
			return true
		}
	}
	return false
}

func parseFile(path string, cfg Config) []Tag {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	lines := strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
	lang := languageFor(path, cfg.Language)
	switch lang {
	case "C", "C++", "CUDA", "ObjectiveC":
		return parseC(path, lines)
	case "Go":
		return parseGo(path, lines)
	case "Python":
		return parsePython(path, lines)
	case "Java", "C#":
		return parseJavaLike(path, lines, lang)
	case "JavaScript", "TypeScript":
		return parseJS(path, lines)
	case "Rust":
		return parseRust(path, lines)
	case "Ruby":
		return parseRuby(path, lines)
	case "PHP":
		return parsePHP(path, lines)
	case "Sh":
		return parseSh(path, lines)
	case "Make":
		return parseMake(path, lines)
	default:
		return parseGeneric(path, lines)
	}
}

func languageFor(path, forced string) string {
	if forced != "" && forced != "auto" {
		return normLang(forced)
	}
	base := filepath.Base(path)
	ext := strings.ToLower(filepath.Ext(path))
	switch ext {
	case ".c", ".h":
		return "C"
	case ".cc", ".cpp", ".cxx", ".hpp", ".hh", ".hxx":
		return "C++"
	case ".go":
		return "Go"
	case ".py", ".pyw":
		return "Python"
	case ".java":
		return "Java"
	case ".js", ".mjs", ".cjs":
		return "JavaScript"
	case ".ts", ".tsx":
		return "TypeScript"
	case ".rs":
		return "Rust"
	case ".rb":
		return "Ruby"
	case ".php", ".phtml":
		return "PHP"
	case ".sh", ".bash", ".zsh", ".ksh":
		return "Sh"
	case ".cs":
		return "C#"
	case ".mk":
		return "Make"
	}
	if base == "Makefile" || base == "makefile" || strings.HasPrefix(base, "Makefile.") {
		return "Make"
	}
	return "Unknown"
}

func normLang(s string) string {
	l := strings.ToLower(s)
	switch l {
	case "c++", "cpp":
		return "C++"
	case "c":
		return "C"
	case "go":
		return "Go"
	case "python":
		return "Python"
	case "javascript", "js":
		return "JavaScript"
	case "typescript", "ts":
		return "TypeScript"
	case "java":
		return "Java"
	case "rust":
		return "Rust"
	case "ruby":
		return "Ruby"
	case "php":
		return "PHP"
	case "sh", "shell", "bash":
		return "Sh"
	case "make":
		return "Make"
	}
	return s
}

func parseC(path string, lines []string) []Tag {
	var tags []Tag
	reMacro := regexp.MustCompile(`^\s*#\s*define\s+(` + ident + `)`)
	reStruct := regexp.MustCompile(`\b(struct|union|enum)\s+(` + ident + `)`)
	reTypedef := regexp.MustCompile(`^\s*typedef\b.*\b(` + ident + `)\s*(?:\[[^\]]*\])?\s*;`)
	reFunc := regexp.MustCompile(`^\s*(?:static\s+)?(?:inline\s+)?(?:extern\s+)?([A-Za-z_][\w\s\*]*?)\s+(` + ident + `)\s*\([^;]*\)\s*(?:\{|$)`)
	reProto := regexp.MustCompile(`^\s*(?:extern\s+)?([A-Za-z_][\w\s\*]*?)\s+(` + ident + `)\s*\([^;]*\)\s*;`)
	reVar := regexp.MustCompile(`^\s*(?:static\s+)?(?:const\s+)?([A-Za-z_][\w\s\*]*?)\s+(` + ident + `)\s*(?:=[^;]*)?;`)
	for i, line := range lines {
		trim := strings.TrimSpace(line)
		if m := reMacro.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "d", "macro", "", "", "", true))
		}
		if m := reStruct.FindStringSubmatch(line); m != nil && strings.Contains(line, "{") {
			k, kl := "s", "struct"
			if m[1] == "union" {
				k, kl = "u", "union"
			} else if m[1] == "enum" {
				k, kl = "g", "enum"
			}
			tags = append(tags, tag(path, line, i+1, m[2], k, kl, "", "", "", strings.Contains(line, "static") || k != "g"))
			if k == "s" || k == "u" {
				tags = append(tags, cMembers(path, line, i+1, m[2], kl)...)
			}
		}
		if strings.HasPrefix(trim, "typedef") {
			if m := reTypedef.FindStringSubmatch(line); m != nil {
				tr := ""
				if sm := reStruct.FindStringSubmatch(line); sm != nil {
					tr = sm[1] + ":" + sm[2]
				}
				tags = append(tags, tag(path, line, i+1, m[1], "t", "typedef", "", "", tr, strings.Contains(line, "struct") || strings.Contains(line, "static")))
			}
			continue
		}
		if m := reFunc.FindStringSubmatch(line); m != nil && !isControl(m[2]) {
			tags = append(tags, tag(path, line, i+1, m[2], "f", "function", "", "", cleanType(m[1]), strings.Contains(line, "static")))
			continue
		}
		if m := reProto.FindStringSubmatch(line); m != nil && !isControl(m[2]) {
			tags = append(tags, tag(path, line, i+1, m[2], "p", "prototype", "", "", cleanType(m[1]), false))
			continue
		}
		if m := reVar.FindStringSubmatch(line); m != nil && !strings.Contains(line, "(") && !isKeyword(m[2]) {
			tags = append(tags, tag(path, line, i+1, m[2], "v", "variable", "", "", cleanType(m[1]), strings.Contains(line, "static")))
		}
	}
	return tags
}

func cMembers(path, line string, n int, scope, scopeKind string) []Tag {
	start, end := strings.Index(line, "{"), strings.LastIndex(line, "}")
	if start < 0 || end <= start {
		return nil
	}
	body := line[start+1 : end]
	var tags []Tag
	re := regexp.MustCompile(`\b([A-Za-z_][\w\s\*]*?)\s+(` + ident + `)\s*(?:;|:)`)
	for _, part := range strings.Split(body, ";") {
		if m := re.FindStringSubmatch(part + ";"); m != nil {
			tags = append(tags, tag(path, line, n, m[2], "m", "member", scope, scopeKind, cleanType(m[1]), true))
		}
	}
	return tags
}

func parseGo(path string, lines []string) []Tag {
	var tags []Tag
	pkg := ""
	rePkg := regexp.MustCompile(`^\s*package\s+(` + ident + `)`)
	reType := regexp.MustCompile(`^\s*type\s+(` + ident + `)\s+(struct|interface)\b`)
	reFunc := regexp.MustCompile(`^\s*func\s+(?:\(\s*\w+\s+\*?(` + ident + `)\s*\)\s*)?(` + ident + `)\s*\([^)]*\)\s*([A-Za-z_][\w\.\*\[\]]*)?`)
	reVarConst := regexp.MustCompile(`^\s*(var|const)\s+(` + ident + `)\s*([A-Za-z_][\w\.\*\[\]]*)?`)
	reMember := regexp.MustCompile(`\{\s*(` + ident + `)\s+([A-Za-z_][\w\.\*\[\]]*)`)
	reGroupItem := regexp.MustCompile(`^\s*(` + ident + `)\s+([A-Za-z_][\w\.\*\[\]]*)?`)
	group := ""
	for i, line := range lines {
		if group != "" {
			if strings.TrimSpace(line) == ")" {
				group = ""
				continue
			}
			if m := reGroupItem.FindStringSubmatch(line); m != nil {
				k, kl := "v", "var"
				if group == "const" {
					k, kl = "c", "const"
				}
				tags = append(tags, tag(path, line, i+1, m[1], k, kl, pkg, "package", m[2], false))
			}
			continue
		}
		if m := rePkg.FindStringSubmatch(line); m != nil {
			pkg = m[1]
			tags = append(tags, tag(path, line, i+1, m[1], "p", "package", "", "", "", false))
		}
		if strings.TrimSpace(line) == "var (" {
			group = "var"
			continue
		}
		if strings.TrimSpace(line) == "const (" {
			group = "const"
			continue
		}
		if m := reType.FindStringSubmatch(line); m != nil {
			k := "s"
			if m[2] == "interface" {
				k = "i"
			}
			tags = append(tags, tag(path, line, i+1, m[1], k, m[2], pkg, "package", "", false))
			if m[2] == "struct" {
				if mm := reMember.FindStringSubmatch(line); mm != nil {
					tags = append(tags, tag(path, line, i+1, mm[1], "m", "member", pkg+"."+m[1], "struct", mm[2], false))
				}
			} else {
				body := between(line, "{", "}")
				if body != "" {
					reMeth := regexp.MustCompile(`\b(` + ident + `)\s*\([^)]*\)\s*([A-Za-z_][\w\.\*\[\]]*)?`)
					for _, mm := range reMeth.FindAllStringSubmatch(body, -1) {
						tags = append(tags, tag(path, line, i+1, mm[1], "n", "methodSpec", pkg+"."+m[1], "interface", mm[2], false))
					}
				}
			}
		}
		if m := reFunc.FindStringSubmatch(line); m != nil {
			scope, sk := pkg, "package"
			if m[1] != "" {
				scope, sk = pkg+"."+m[1], "struct"
			}
			tags = append(tags, tag(path, line, i+1, m[2], "f", "func", scope, sk, m[3], false))
		}
		if m := reVarConst.FindStringSubmatch(line); m != nil {
			k, kl := "v", "var"
			if m[1] == "const" {
				k, kl = "c", "const"
			}
			tags = append(tags, tag(path, line, i+1, m[2], k, kl, pkg, "package", m[3], false))
		}
	}
	return tags
}

type pyFrame struct {
	indent     int
	name, kind string
}

func parsePython(path string, lines []string) []Tag {
	var tags []Tag
	var stack []pyFrame
	reClass := regexp.MustCompile(`^(\s*)class\s+(` + ident + `)`)
	reDef := regexp.MustCompile(`^(\s*)(?:async\s+)?def\s+(` + ident + `)`)
	reVar := regexp.MustCompile(`^(` + ident + `)\s*=`)
	for i, line := range lines {
		ind := countIndent(line)
		for len(stack) > 0 && ind <= stack[len(stack)-1].indent {
			stack = stack[:len(stack)-1]
		}
		if m := reClass.FindStringSubmatch(line); m != nil {
			scope, sk := pyScope(stack)
			tags = append(tags, tag(path, line, i+1, m[2], "c", "class", scope, sk, "", false))
			stack = append(stack, pyFrame{len(m[1]), m[2], "class"})
			continue
		}
		if m := reDef.FindStringSubmatch(line); m != nil {
			scope, sk := pyScope(stack)
			k, kl := "f", "function"
			if sk == "class" {
				k, kl = "m", "member"
			}
			tags = append(tags, tag(path, line, i+1, m[2], k, kl, scope, sk, "", false))
			stack = append(stack, pyFrame{len(m[1]), m[2], "function"})
			continue
		}
		if ind == 0 {
			if m := reVar.FindStringSubmatch(line); m != nil {
				tags = append(tags, tag(path, line, i+1, m[1], "v", "variable", "", "", "", false))
			}
		}
	}
	return tags
}

func pyScope(stack []pyFrame) (string, string) {
	for i := len(stack) - 1; i >= 0; i-- {
		if stack[i].kind == "class" {
			return stack[i].name, "class"
		}
	}
	return "", ""
}

func parseJavaLike(path string, lines []string, lang string) []Tag {
	var tags []Tag
	reType := regexp.MustCompile(`\b(class|interface|enum)\s+(` + ident + `)`)
	reMeth := regexp.MustCompile(`^\s*(?:public|private|protected|static|final|abstract|synchronized|\s)+\s*([A-Za-z_][\w<>\[\]]*)\s+(` + ident + `)\s*\(`)
	reField := regexp.MustCompile(`^\s*(?:public|private|protected|static|final|volatile|transient|\s)+\s*([A-Za-z_][\w<>\[\]]*)\s+(` + ident + `)\s*(?:=|;)`)
	scope := ""
	for i, line := range lines {
		if m := reType.FindStringSubmatch(line); m != nil {
			k := map[string]string{"class": "c", "interface": "i", "enum": "g"}[m[1]]
			tags = append(tags, tag(path, line, i+1, m[2], k, m[1], "", "", "", false))
			scope = m[2]
			continue
		}
		if m := reMeth.FindStringSubmatch(line); m != nil && !isControl(m[2]) {
			tags = append(tags, tag(path, line, i+1, m[2], "m", "method", scope, "class", m[1], false))
			continue
		}
		if m := reField.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[2], "f", "field", scope, "class", m[1], false))
		}
	}
	return tags
}

func parseJS(path string, lines []string) []Tag {
	var tags []Tag
	reFunc := regexp.MustCompile(`^\s*(?:export\s+)?(?:async\s+)?function\s+(` + ident + `)`)
	reVarFunc := regexp.MustCompile(`^\s*(?:export\s+)?(?:const|let|var)\s+(` + ident + `)\s*=\s*(?:async\s*)?(?:\([^)]*\)|` + ident + `)\s*=>`)
	reVar := regexp.MustCompile(`^\s*(?:export\s+)?(?:const|let|var)\s+(` + ident + `)\b`)
	reClass := regexp.MustCompile(`^\s*(?:export\s+)?class\s+(` + ident + `)`)
	reMethod := regexp.MustCompile(`^\s*(` + ident + `)\s*\([^)]*\)\s*\{?`)
	scope := ""
	for i, line := range lines {
		if m := reClass.FindStringSubmatch(line); m != nil {
			scope = m[1]
			tags = append(tags, tag(path, line, i+1, m[1], "c", "class", "", "", "", false))
			continue
		}
		if m := reFunc.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "f", "function", "", "", "", false))
			continue
		}
		if m := reVarFunc.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "f", "function", "", "", "", false))
			continue
		}
		if scope != "" {
			if m := reMethod.FindStringSubmatch(line); m != nil && !isKeyword(m[1]) {
				tags = append(tags, tag(path, line, i+1, m[1], "m", "method", scope, "class", "", false))
				continue
			}
		}
		if m := reVar.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "v", "variable", "", "", "", false))
		}
	}
	return tags
}

func parseRust(path string, lines []string) []Tag {
	var tags []Tag
	res := []struct {
		re    *regexp.Regexp
		k, kl string
	}{
		{regexp.MustCompile(`^\s*(?:pub\s+)?fn\s+(` + ident + `)`), "f", "function"},
		{regexp.MustCompile(`^\s*(?:pub\s+)?struct\s+(` + ident + `)`), "s", "struct"},
		{regexp.MustCompile(`^\s*(?:pub\s+)?enum\s+(` + ident + `)`), "g", "enum"},
		{regexp.MustCompile(`^\s*(?:pub\s+)?trait\s+(` + ident + `)`), "t", "trait"},
		{regexp.MustCompile(`^\s*(?:pub\s+)?mod\s+(` + ident + `)`), "m", "module"},
		{regexp.MustCompile(`^\s*(?:pub\s+)?(?:const|static)\s+(` + ident + `)`), "c", "constant"},
	}
	for i, line := range lines {
		for _, r := range res {
			if m := r.re.FindStringSubmatch(line); m != nil {
				tags = append(tags, tag(path, line, i+1, m[1], r.k, r.kl, "", "", "", false))
				break
			}
		}
	}
	return tags
}

func parseRuby(path string, lines []string) []Tag {
	var tags []Tag
	reClass := regexp.MustCompile(`^\s*(class|module)\s+(` + ident + `)`)
	reDef := regexp.MustCompile(`^\s*def\s+(?:self\.)?(` + ident + `[!?=]?)`)
	scope := ""
	for i, line := range lines {
		if m := reClass.FindStringSubmatch(line); m != nil {
			k, kl := "c", "class"
			if m[1] == "module" {
				k, kl = "m", "module"
			}
			scope = m[2]
			tags = append(tags, tag(path, line, i+1, m[2], k, kl, "", "", "", false))
		} else if m := reDef.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "f", "method", scope, "class", "", false))
		}
	}
	return tags
}

func parsePHP(path string, lines []string) []Tag {
	var tags []Tag
	reClass := regexp.MustCompile(`\b(class|interface|trait)\s+(` + ident + `)`)
	reFunc := regexp.MustCompile(`\bfunction\s+&?\s*(` + ident + `)\s*\(`)
	reConst := regexp.MustCompile(`\bconst\s+(` + ident + `)\b`)
	reVar := regexp.MustCompile(`\$(\w+)\s*=`)
	scope := ""
	for i, line := range lines {
		if m := reClass.FindStringSubmatch(line); m != nil {
			scope = m[2]
			tags = append(tags, tag(path, line, i+1, m[2], "c", m[1], "", "", "", false))
		}
		if m := reFunc.FindStringSubmatch(line); m != nil {
			k, kl := "f", "function"
			if scope != "" {
				k, kl = "m", "method"
			}
			tags = append(tags, tag(path, line, i+1, m[1], k, kl, scope, "class", "", false))
		}
		if m := reConst.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "d", "constant", scope, "class", "", false))
		} else if scope == "" {
			if m := reVar.FindStringSubmatch(line); m != nil {
				tags = append(tags, tag(path, line, i+1, m[1], "v", "variable", "", "", "", false))
			}
		}
	}
	return tags
}

func parseSh(path string, lines []string) []Tag {
	var tags []Tag
	re1 := regexp.MustCompile(`^\s*(` + ident + `)\s*\(\s*\)\s*\{?`)
	re2 := regexp.MustCompile(`^\s*function\s+(` + ident + `)`)
	for i, line := range lines {
		if m := re1.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "f", "function", "", "", "", false))
		} else if m := re2.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "f", "function", "", "", "", false))
		}
	}
	return tags
}

func parseMake(path string, lines []string) []Tag {
	var tags []Tag
	re := regexp.MustCompile(`^([A-Za-z0-9_.%/-]+)\s*:`)
	for i, line := range lines {
		if m := re.FindStringSubmatch(line); m != nil && !strings.HasPrefix(line, "\t") {
			tags = append(tags, tag(path, line, i+1, m[1], "t", "target", "", "", "", false))
		}
	}
	return tags
}

func parseGeneric(path string, lines []string) []Tag {
	var tags []Tag
	re := regexp.MustCompile(`^\s*(?:function|def|sub|proc)\s+(` + ident + `)`)
	for i, line := range lines {
		if m := re.FindStringSubmatch(line); m != nil {
			tags = append(tags, tag(path, line, i+1, m[1], "f", "function", "", "", "", false))
		}
	}
	return tags
}

func tag(path, line string, n int, name, kind, kindLong, scope, scopeKind, typeref string, file bool) Tag {
	t := Tag{Name: name, Path: path, Pattern: makePattern(line, kind), Raw: strings.TrimSpace(line), Line: n, Kind: kind, KindLong: kindLong, Scope: scope, ScopeKind: scopeKind, File: file}
	if typeref != "" {
		if strings.Contains(typeref, ":") {
			t.TypeRef = typeref
		} else {
			t.TypeRef = "typename:" + strings.TrimSpace(strings.ReplaceAll(typeref, "*", ""))
		}
	}
	return t
}

func makePattern(line, kind string) string {
	s := strings.TrimRight(line, "\n")
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `/`, `\/`)
	if kind == "d" && strings.Contains(s, "#define") {
		idx := strings.Index(s, "#define")
		parts := strings.Fields(s[idx:])
		if len(parts) >= 2 {
			prefix := s[:idx] + "#define " + parts[1] + " "
			prefix = strings.ReplaceAll(prefix, `/`, `\/`)
			return "/^" + prefix + "/"
		}
	}
	return "/^" + s + "$/"
}

func writeOutput(cfg Config, tags []Tag, files []string) error {
	var w io.Writer
	var f *os.File
	if cfg.OutFile == "-" || cfg.OutputFormat == "xref" || cfg.OutputFormat == "json" {
		w = os.Stdout
	} else {
		flag := os.O_CREATE | os.O_WRONLY
		if cfg.Append {
			flag |= os.O_APPEND
		} else {
			flag |= os.O_TRUNC
		}
		var err error
		f, err = os.OpenFile(cfg.OutFile, flag, 0644)
		if err != nil {
			return err
		}
		defer f.Close()
		w = f
		if !cfg.Append && cfg.OutputFormat == "u-ctags" {
			writePseudos(w)
		}
	}
	switch cfg.OutputFormat {
	case "json":
		for _, t := range tags {
			fields := [][2]string{
				{"_type", "tag"},
				{"name", t.Name},
				{"path", t.Path},
				{"pattern", strings.TrimSuffix(t.Pattern, `;"`)},
			}
			if t.File {
				fields = append(fields, [2]string{"file", "true"})
			}
			if t.TypeRef != "" {
				fields = append(fields, [2]string{"typeref", t.TypeRef})
			}
			fields = append(fields, [2]string{"kind", t.KindLong})
			if t.Scope != "" {
				fields = append(fields, [2]string{"scope", t.Scope}, [2]string{"scopeKind", t.ScopeKind})
			}
			fmt.Fprintln(w, jsonObject(fields))
		}
	case "xref":
		sort.SliceStable(tags, func(i, j int) bool {
			if tags[i].Name != tags[j].Name {
				return tags[i].Name < tags[j].Name
			}
			if tags[i].KindLong != tags[j].KindLong {
				return tags[i].KindLong < tags[j].KindLong
			}
			return tags[i].Path < tags[j].Path
		})
		for _, t := range tags {
			fmt.Fprintf(w, "%-16s %-10s %4d %-16s %s\n", t.Name, t.KindLong, t.Line, t.Path, t.Raw)
		}
	case "etags", "e-ctags":
		for _, t := range tags {
			fmt.Fprintf(w, "%s\t%s\t%d\n", t.Name, t.Path, t.Line)
		}
	default:
		for _, t := range tags {
			fmt.Fprintf(w, "%s\t%s\t%s;\"\t%s", t.Name, t.Path, t.Pattern, t.Kind)
			if t.Scope != "" {
				fmt.Fprintf(w, "\t%s:%s", t.ScopeKind, t.Scope)
			}
			if t.TypeRef != "" {
				fmt.Fprintf(w, "\ttyperef:%s", t.TypeRef)
			}
			if t.File {
				fmt.Fprint(w, "\tfile:")
			}
			fmt.Fprintln(w)
		}
	}
	if cfg.Totals {
		fmt.Fprintf(os.Stderr, "%d files, %d lines, %d tags\n", len(files), 0, len(tags))
	}
	return nil
}

func writePseudos(w io.Writer) {
	fmt.Fprintln(w, `!_TAG_FILE_FORMAT	2	/extended format; --format=1 will not append ;" to lines/`)
	fmt.Fprintln(w, `!_TAG_FILE_SORTED	1	/0=unsorted, 1=sorted, 2=foldcase/`)
	fmt.Fprintln(w, `!_TAG_OUTPUT_FILESEP	slash	/slash or backslash/`)
	fmt.Fprintln(w, `!_TAG_OUTPUT_MODE	u-ctags	/u-ctags or e-ctags/`)
	fmt.Fprintln(w, `!_TAG_PROGRAM_NAME	Universal Ctags	/Derived from Exuberant Ctags/`)
	fmt.Fprintln(w, `!_TAG_PROGRAM_VERSION	6.2.0	//`)
}

func rawLineForPattern(p string) string {
	p = strings.TrimPrefix(p, "/^")
	p = strings.TrimSuffix(p, "$/")
	p = strings.TrimSuffix(p, "/")
	p = strings.ReplaceAll(p, `\/`, `/`)
	p = strings.ReplaceAll(p, `\\`, `\`)
	return p
}

func jsonObject(fields [][2]string) string {
	var b strings.Builder
	b.WriteByte('{')
	for i, f := range fields {
		if i > 0 {
			b.WriteString(", ")
		}
		k, _ := json.Marshal(f[0])
		b.Write(k)
		b.WriteString(": ")
		if f[0] == "file" {
			b.WriteString(f[1])
		} else {
			v, _ := json.Marshal(f[1])
			b.Write(v)
		}
	}
	b.WriteByte('}')
	return b.String()
}

func handleListings(cfg Config) bool {
	args := os.Args[1:]
	for _, a := range args {
		name, val, ok := splitListOpt(a)
		if !ok {
			continue
		}
		switch name {
		case "--list-features":
			if cfg.Header {
				fmt.Println("#NAME             DESCRIPTION")
			}
			for _, l := range []string{"iconv             can convert input/output encodings", "interactive       accepts source code from stdin", "json              supports json format output", "option-directory  TO BE WRITTEN", "regex             can use regular expression based pattern matching", "wildcards         can use glob matching"} {
				fmt.Println(l)
			}
		case "--list-output-formats":
			fmt.Println("#OFORMAT DEFAULT AVAILABLE NULLTAG ")
			fmt.Println("e-ctags       no       yes      no ")
			fmt.Println("etags         no       yes      no ")
			fmt.Println("json          no       yes     yes ")
			fmt.Println("u-ctags      yes       yes      no ")
			fmt.Println("xref          no       yes     yes ")
		case "--list-languages":
			for _, l := range languages {
				fmt.Println(l)
			}
		case "--list-kinds", "--list-kinds-full":
			printKinds(normLang(defaultVal(val, "all")))
		case "--list-maps", "--list-map-extensions":
			printMaps(normLang(defaultVal(val, "all")))
		case "--list-excludes":
			fmt.Println("EIFGEN")
			fmt.Println("SCCS")
			fmt.Println("RCS")
			fmt.Println("CVS")
		case "--list-fields":
			fmt.Println("f  File-restricted scoping")
			fmt.Println("k  Kind of tag")
			fmt.Println("s  Scope of tag definition")
			fmt.Println("t  Type and name of a variable or typedef")
		case "--list-extras":
			fmt.Println("F  fileScope  Include tags of file scope")
			fmt.Println("q  qualified  Include an extra class-qualified tag entry")
		default:
			fmt.Println()
		}
		return true
	}
	return false
}

func splitListOpt(a string) (string, string, bool) {
	opts := []string{"--list-features", "--list-output-formats", "--list-languages", "--list-kinds-full", "--list-kinds", "--list-maps", "--list-map-extensions", "--list-excludes", "--list-fields", "--list-extras", "--list-aliases", "--list-pseudo-tags", "--list-regex-flags", "--list-roles", "--list-params", "--list-subparsers"}
	for _, o := range opts {
		if a == o {
			return o, "", true
		}
		if strings.HasPrefix(a, o+"=") {
			return o, strings.TrimPrefix(a, o+"="), true
		}
	}
	return "", "", false
}

func printKinds(lang string) {
	switch lang {
	case "C", "C++":
		fmt.Println("d  macro definitions")
		fmt.Println("f  function definitions")
		fmt.Println("m  struct, and union members")
		fmt.Println("p  function prototypes [off]")
		fmt.Println("s  structure names")
		fmt.Println("t  typedefs")
		fmt.Println("u  union names")
		fmt.Println("v  variable definitions")
	case "Python":
		fmt.Println("c  classes")
		fmt.Println("f  functions")
		fmt.Println("m  class members")
		fmt.Println("v  variables")
	case "Go":
		fmt.Println("c  constants")
		fmt.Println("f  functions")
		fmt.Println("i  interfaces")
		fmt.Println("m  struct members")
		fmt.Println("n  interface methods")
		fmt.Println("p  packages")
		fmt.Println("s  structs")
		fmt.Println("v  variables")
	default:
		printKinds("C")
	}
}

func printMaps(lang string) {
	m := map[string]string{"C": "*.c *.h", "C++": "*.c++ *.cc *.cpp *.cxx *.h++ *.hh *.hpp *.hxx", "Go": "*.go", "Python": "*.py *.pyx *.pxd *.pxi *.scons", "Java": "*.java", "JavaScript": "*.js *.jsx *.mjs", "Rust": "*.rs", "Make": "Makefile makefile *.mk"}
	if lang == "all" {
		for _, l := range []string{"C", "C++", "Go", "Java", "JavaScript", "Python", "Rust", "Make"} {
			fmt.Printf("%-8s %s\n", l, m[l])
		}
	} else if v, ok := m[lang]; ok {
		fmt.Printf("%-8s %s\n", lang, v)
	}
}

var languages = []string{"Abaqus", "Ada", "Ant", "Asm", "Awk", "Basic", "C", "C#", "C++", "CMake", "CSS", "Ctags", "Go", "HTML", "Java", "JavaScript", "JSON", "Lua", "M4", "Make", "Markdown", "ObjectiveC", "Perl", "PHP", "Python", "R", "Ruby", "Rust", "Scala", "Sh", "SQL", "Tcl", "TypeScript", "Vim", "XML", "Yaml"}

func printHelp() {
	fmt.Println("Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team")
	fmt.Println("Universal Ctags is derived from Exuberant Ctags.")
	fmt.Println("Usage: executable [options] [file(s)]")
	fmt.Println("  -f <tagfile>       Write tags to specified <tagfile>. Value of \"-\" writes tags to stdout")
	fmt.Println("  -R                 Recurse into directories")
	fmt.Println("  -x                 Print a tabular cross reference file to standard output")
	fmt.Println("  --output-format=(u-ctags|e-ctags|etags|xref|json)")
	fmt.Println("  --list-languages   Output list of supported languages")
	fmt.Println("  --list-kinds[=(<language>|all)]")
	fmt.Println("  --version          Print version identifier of the program")
}

func runFilter(cfg Config) {
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		f := strings.TrimSpace(sc.Text())
		for _, t := range parseFile(f, cfg) {
			fmt.Printf("%s\t%s\t%s;\"\t%s\n", t.Name, t.Path, t.Pattern, t.Kind)
		}
	}
}

func cleanType(s string) string {
	s = strings.TrimSpace(s)
	words := strings.Fields(s)
	if len(words) == 0 {
		return ""
	}
	return words[len(words)-1]
}

func between(s, a, b string) string {
	i, j := strings.Index(s, a), strings.LastIndex(s, b)
	if i >= 0 && j > i {
		return s[i+1 : j]
	}
	return ""
}

func countIndent(s string) int {
	n := 0
	for _, r := range s {
		if r == ' ' {
			n++
		} else if r == '\t' {
			n += 8
		} else {
			break
		}
	}
	return n
}

func isControl(s string) bool { return s == "if" || s == "for" || s == "while" || s == "switch" }
func isKeyword(s string) bool {
	switch s {
	case "if", "for", "while", "switch", "return", "else", "do", "case", "class", "struct":
		return true
	}
	return false
}
func defaultVal(a, b string) string {
	if a == "" {
		return b
	}
	return a
}

func atoi(s string) int {
	n, _ := strconv.Atoi(s)
	return n
}

func exported(s string) bool {
	if s == "" {
		return false
	}
	r := []rune(s)[0]
	return unicode.IsUpper(r)
}
