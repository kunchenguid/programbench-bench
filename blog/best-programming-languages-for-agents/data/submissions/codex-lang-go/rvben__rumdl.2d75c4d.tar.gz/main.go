package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Rule struct {
	Code     string `json:"code"`
	Name     string `json:"name"`
	Summary  string `json:"summary"`
	Category string `json:"category"`
	Fixable  bool
}

type Issue struct {
	File     string `json:"file"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
	Rule     string `json:"rule"`
	Message  string `json:"message"`
	Severity string `json:"severity"`
	Fixable  bool   `json:"fixable"`
}

var rules = []Rule{
	{"MD001", "heading-increment", "Heading levels should only increment by one level at a time", "heading", true},
	{"MD003", "heading-style", "Heading style", "heading", true},
	{"MD004", "ul-style", "Use consistent style for unordered list markers", "list", true},
	{"MD005", "list-indent", "List indentation should be consistent", "list", true},
	{"MD007", "ul-indent", "Unordered list indentation", "list", true},
	{"MD009", "no-trailing-spaces", "Trailing spaces should be removed", "whitespace", true},
	{"MD010", "no-hard-tabs", "No tabs", "whitespace", true},
	{"MD011", "no-reversed-links", "Reversed link syntax", "link", true},
	{"MD012", "no-multiple-blanks", "Multiple consecutive blank lines", "whitespace", true},
	{"MD013", "line-length", "Line length should not be excessive", "whitespace", false},
	{"MD014", "commands-show-output", "Commands in code blocks should show output", "code-block", true},
	{"MD018", "no-missing-space-atx", "No space after hash in heading", "heading", true},
	{"MD019", "no-multiple-space-atx", "Multiple spaces after hash in heading", "heading", true},
	{"MD020", "no-missing-space-closed-atx", "No space inside hashes on closed heading", "heading", true},
	{"MD021", "no-multiple-space-closed-atx", "Multiple spaces inside hashes on closed heading", "heading", true},
	{"MD022", "blanks-around-headings", "Headings should be surrounded by blank lines", "heading", true},
	{"MD023", "heading-start-left", "Headings must start at the beginning of the line", "heading", true},
	{"MD024", "no-duplicate-heading", "Multiple headings with the same content", "other", false},
	{"MD025", "single-title", "Multiple top-level headings in the same document", "heading", false},
	{"MD026", "no-trailing-punctuation", "Trailing punctuation in heading", "heading", true},
	{"MD027", "no-multiple-space-blockquote", "Multiple spaces after quote marker (>)", "blockquote", true},
	{"MD028", "no-blanks-blockquote", "Blank line inside blockquote", "other", false},
	{"MD029", "ol-prefix", "Ordered list marker value", "list", true},
	{"MD030", "list-marker-space", "Spaces after list markers should be consistent", "list", true},
	{"MD031", "blanks-around-fences", "Fenced code blocks should be surrounded by blank lines", "other", true},
	{"MD032", "blanks-around-lists", "Lists should be surrounded by blank lines", "list", true},
	{"MD033", "no-inline-html", "Inline HTML is not allowed", "html", false},
	{"MD034", "no-bare-urls", "No bare URLs - wrap URLs in angle brackets", "link", true},
	{"MD035", "hr-style", "Horizontal rule style", "other", true},
	{"MD036", "no-emphasis-as-heading", "Emphasis should not be used instead of a heading", "emphasis", false},
	{"MD037", "no-space-in-emphasis", "Spaces inside emphasis markers", "other", true},
	{"MD038", "no-space-in-code", "Spaces inside code span elements", "other", true},
	{"MD039", "no-space-in-links", "Spaces inside link text", "link", true},
	{"MD040", "fenced-code-language", "Code blocks should have a language specified", "code-block", false},
	{"MD041", "first-line-heading", "First line in file should be a top level heading", "heading", false},
	{"MD042", "no-empty-links", "No empty links", "link", false},
	{"MD043", "required-headings", "Required heading structure", "other", false},
	{"MD044", "proper-names", "Proper names should have the correct capitalization", "other", true},
	{"MD045", "no-alt-text", "Images should have alternate text (alt text)", "link", true},
	{"MD046", "code-block-style", "Code blocks should use a consistent style", "code-block", true},
	{"MD047", "single-trailing-newline", "Files should end with a single newline character", "whitespace", true},
	{"MD048", "code-fence-style", "Code fence style should be consistent", "other", true},
	{"MD049", "emphasis-style", "Emphasis style should be consistent", "other", true},
	{"MD050", "strong-style", "Strong emphasis style should be consistent", "other", true},
	{"MD051", "link-fragments", "Link fragments should reference valid headings", "link", false},
	{"MD052", "reference-links-images", "Reference links and images should use a reference that exists", "link", false},
	{"MD053", "link-image-definitions", "Link and image reference definitions should be needed", "link", true},
	{"MD054", "link-image-style", "Link and image style should be consistent", "link", false},
	{"MD055", "table-pipe-style", "Table pipe style should be consistent", "other", true},
	{"MD056", "table-column-count", "Table column count should be consistent", "other", false},
	{"MD057", "relative-links", "Relative links should point to existing files", "link", false},
	{"MD058", "blanks-around-tables", "Tables should be surrounded by blank lines", "other", true},
	{"MD059", "descriptive-link-text", "Link text should be descriptive", "link", false},
	{"MD060", "table-format", "Table columns should be consistently aligned", "other", true},
	{"MD061", "forbidden-terms", "Forbidden terms", "other", false},
	{"MD062", "link-destination-space", "Link destination should not have leading or trailing whitespace", "other", true},
	{"MD063", "heading-capitalization", "Heading capitalization", "other", true},
	{"MD064", "no-multiple-space", "Multiple consecutive spaces", "whitespace", true},
	{"MD065", "blanks-around-hr", "Horizontal rules should be surrounded by blank lines", "other", true},
	{"MD066", "footnote-validation", "Footnote validation", "other", false},
	{"MD067", "footnote-definition-order", "Footnote definitions should appear in order of first reference", "other", true},
	{"MD068", "empty-footnote-definition", "Footnote definitions should not be empty", "other", false},
	{"MD069", "no-duplicate-list-markers", "Duplicate list markers", "list", true},
	{"MD070", "nested-code-fence", "Nested code fence collision - use longer fence to avoid premature closure", "other", false},
	{"MD071", "blank-line-after-frontmatter", "Blank line after frontmatter", "front-matter", true},
	{"MD072", "frontmatter-key-sort", "Frontmatter keys should be sorted alphabetically", "other", true},
	{"MD073", "toc", "Table of Contents should match document headings", "other", false},
}

var ruleMap = map[string]Rule{}

func init() {
	for _, r := range rules {
		ruleMap[r.Code] = r
		ruleMap[strings.ToLower(r.Name)] = r
	}
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 || has(args, "-h") || has(args, "--help") && len(args) == 1 {
		printTopHelp()
		return
	}
	for len(args) > 0 && strings.HasPrefix(args[0], "-") {
		if args[0] == "-V" || args[0] == "--version" {
			fmt.Println("rumdl 0.1.13")
			return
		}
		if takesValue(args[0]) && len(args) > 1 {
			args = args[2:]
		} else {
			args = args[1:]
		}
	}
	if len(args) == 0 {
		printTopHelp()
		return
	}
	switch args[0] {
	case "check":
		os.Exit(runCheck(args[1:], false))
	case "fmt":
		os.Exit(runCheck(args[1:], true))
	case "rule":
		runRule(args[1:])
	case "explain":
		runExplain(args[1:])
	case "config":
		runConfig(args[1:])
	case "init":
		runInit(args[1:])
	case "version":
		fmt.Println("rumdl 0.1.13")
	case "clean":
		os.RemoveAll(".rumdl_cache")
		fmt.Println("Cache cleared")
	case "schema":
		fmt.Println(`{"$schema":"http://json-schema.org/draft-07/schema#","title":"rumdl configuration","type":"object"}`)
	case "completions":
		if len(args) > 1 {
			fmt.Printf("# %s completions for rumdl\n", args[1])
		}
	case "help":
		printTopHelp()
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[0])
		printTopHelp()
		os.Exit(2)
	}
}

func printTopHelp() {
	fmt.Println(`A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  check        Lint Markdown files and print warnings/errors
  fmt          Format Markdown files (alias for check --fix)
  init         Initialize a new configuration file
  rule         Show information about a rule or list all rules
  explain      Explain a rule with detailed information and examples
  config       Show configuration or query a specific key
  server       Start the Language Server Protocol server
  schema       Generate or check JSON schema for rumdl.toml
  import       Import and convert markdownlint configuration files
  vscode       Install the rumdl VS Code extension
  completions  Generate shell completion scripts
  clean        Clear the cache
  version      Show version information
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]
      --config <CONFIG>  Path to configuration file
      --no-config        Ignore all configuration files and use built-in defaults
      --isolated         Ignore all configuration files (alias for --no-config)
  -h, --help             Print help
  -V, --version          Print version`)
}

func runRule(args []string) {
	format := "text"
	category := ""
	fixableOnly := false
	listCats := false
	var query string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-o", "--output-format":
			i++; if i < len(args) { format = args[i] }
		case "-c", "--category":
			i++; if i < len(args) { category = args[i] }
		case "-f", "--fixable":
			fixableOnly = true
		case "--list-categories":
			listCats = true
		case "-h", "--help":
			fmt.Println("Show information about a rule or list all rules\n\nUsage: executable rule [OPTIONS] [RULE]")
			return
		default:
			if !strings.HasPrefix(args[i], "-") { query = args[i] }
		}
	}
	if listCats {
		fmt.Println("Available categories:")
		fmt.Println("  blockquote (1 rules)")
		fmt.Println("  code-block (4 rules)")
		fmt.Println("  emphasis (1 rules)")
		fmt.Println("  front-matter (1 rules)")
		fmt.Println("  heading (11 rules)")
		fmt.Println("  html (1 rules)")
		fmt.Println("  link (7 rules)")
		fmt.Println("  list (7 rules)")
		fmt.Println("  other (29 rules)")
		fmt.Println("  whitespace (5 rules)")
		return
	}
	out := filterRules(category, fixableOnly)
	if query != "" {
		r, ok := lookupRule(query); if !ok { fmt.Fprintf(os.Stderr, "Unknown rule: %s\n", query); os.Exit(1) }
		out = []Rule{r}
	}
	if format == "json" || format == "json-lines" {
		type jr struct {
			Code            string   `json:"code"`
			Name            string   `json:"name"`
			Aliases         []string `json:"aliases"`
			Summary         string   `json:"summary"`
			Category        string   `json:"category"`
			Fix             string   `json:"fix"`
			FixAvailability string   `json:"fix_availability"`
			URL             string   `json:"url"`
		}
		if format == "json-lines" {
			for _, r := range out {
				b, _ := json.Marshal(jr{r.Code, r.Name, []string{}, r.Summary, r.Category, fixText(r), fixAvail(r), "https://rumdl.dev/" + strings.ToLower(r.Code) + "/"})
				fmt.Println(string(b))
			}
		} else {
			arr := []jr{}
			for _, r := range out { arr = append(arr, jr{r.Code, r.Name, []string{}, r.Summary, r.Category, fixText(r), fixAvail(r), "https://rumdl.dev/" + strings.ToLower(r.Code) + "/"}) }
			b, _ := json.MarshalIndent(arr, "", "  "); fmt.Println(string(b))
		}
		return
	}
	if query != "" {
		r := out[0]
		fmt.Printf("%s - %s\n\nName: %s\nCategory: %s\nFix: %s\n", r.Code, r.Summary, r.Name, r.Category, fixText(r))
		return
	}
	fmt.Println("Available rules:")
	for _, r := range out { fmt.Printf("  %s - %s\n", r.Code, r.Summary) }
	fmt.Printf("\nTotal: %d rules\n", len(out))
}

func filterRules(category string, fixable bool) []Rule {
	out := []Rule{}
	for _, r := range rules {
		if category != "" && r.Category != category { continue }
		if fixable && !r.Fixable { continue }
		out = append(out, r)
	}
	return out
}

func fixText(r Rule) string { if r.Fixable { return "Fix is always available." }; return "Fix is not available." }
func fixAvail(r Rule) string { if r.Fixable { return "Always" }; return "None" }

func lookupRule(s string) (Rule, bool) {
	up := strings.ToUpper(s)
	if r, ok := ruleMap[up]; ok { return r, true }
	r, ok := ruleMap[strings.ToLower(s)]
	return r, ok
}

func runExplain(args []string) {
	for _, a := range args {
		if strings.HasPrefix(a, "-") { continue }
		if r, ok := lookupRule(a); ok {
			fmt.Printf("%s - %s\n\nAliases: `%s`\n\nWhat this rule does\n\n%s.\n\nWhy this matters\n\nMarkdown documents are easier to read, render, and maintain when this rule is followed.\n\nExamples\n\n✅ Correct\n\n```markdown\n# Title\n\nText\n```\n\n❌ Incorrect\n\n```markdown\n#Bad\n```\n", r.Code, r.Summary, r.Name, r.Summary)
			return
		}
	}
	fmt.Fprintln(os.Stderr, "error: missing required argument <RULE>")
	os.Exit(2)
}

func runConfig(args []string) {
	if len(args) > 0 && args[0] == "file" {
		if p := findConfig(""); p != "" { abs, _ := filepath.Abs(p); fmt.Println(abs) } else { fmt.Println("No configuration file found (using defaults)") }
		return
	}
	if len(args) > 1 && args[0] == "get" {
		key := args[1]
		switch key {
		case "global":
			fmt.Println("enable = []\ndisable = []\nexclude = []\ninclude = []\nrespect_gitignore = true\nflavor = Standard")
		case "MD013.line-length", "MD013.line_length":
			fmt.Println("MD013.line-length = 80 [from default]")
		case "global.exclude":
			fmt.Println("global.exclude = [] [from default]")
		default:
			fmt.Printf("%s = null [from default]\n", key)
		}
		return
	}
	fmt.Println("[global]")
	fmt.Println("enable = []                                                                                                                                                                      [from default]")
	fmt.Println("disable = []                                                                                                                                                                     [from default]")
	fmt.Println("exclude = []                                                                                                                                                                     [from default]")
	fmt.Println("include = []                                                                                                                                                                     [from default]")
	fmt.Println("respect_gitignore = true                                                                                                                                                         [from default]")
	fmt.Println("flavor = Standard                                                                                                                                                                [from default]")
	fmt.Println("\n[MD013]")
	fmt.Println("line-length = 80                                                                                                                                                                 [from default]")
}

func runInit(args []string) {
	py := has(args, "--pyproject")
	path := ".rumdl.toml"
	content := defaultConfig()
	if py {
		path = "pyproject.toml"
		content = "[tool.rumdl]\n\n" + content
	}
	if _, err := os.Stat(path); err == nil {
		fmt.Fprintf(os.Stderr, "Configuration file already exists: %s\n", path)
		os.Exit(1)
	}
	os.WriteFile(path, []byte(content), 0644)
	fmt.Printf("Created default configuration file: %s\n\nSetup complete! You can now:\n  • Run rumdl check . to lint your Markdown files\n  • Open your editor to see real-time linting\n", path)
}

func defaultConfig() string {
	return `# rumdl configuration file

# Global configuration options
[global]
# List of rules to disable (uncomment and modify as needed)
# disable = ["MD013", "MD033"]

# List of rules to enable exclusively (if provided, only these rules will run)
# enable = ["MD001", "MD003", "MD004"]

# List of file/directory patterns to include for linting (if provided, only these will be linted)
# include = [
#    "docs/*.md",
#    "src/**/*.md",
#    "README.md"
# ]

# List of file/directory patterns to exclude from linting
exclude = [
    ".git",
    ".github",
    "node_modules",
    "vendor",
    "dist",
    "build",
    "CHANGELOG.md",
    "LICENSE.md",
]

respect-gitignore = true
`
}

type Options struct {
	Fix, Diff, Check, Quiet, Silent, Stdin, Stderr, NoConfig bool
	OutputFormat, StdinFilename, Config, FailOn string
	Enable, Disable map[string]bool
	Paths []string
}

func runCheck(args []string, forceFix bool) int {
	if has(args, "-h") || has(args, "--help") { printCheckHelp(forceFix); return 0 }
	opt := parseCheck(args)
	if forceFix { opt.Fix = true }
	if opt.OutputFormat == "" { opt.OutputFormat = "text" }
	if opt.FailOn == "" { opt.FailOn = "any" }
	if !opt.NoConfig { applyConfig(&opt) }
	if len(opt.Enable) == 0 { opt.Disable["MD060"] = true; opt.Disable["MD063"] = true; opt.Disable["MD072"] = true; opt.Disable["MD073"] = true }
	if opt.Stdin || (len(opt.Paths) == 1 && opt.Paths[0] == "-") {
		data, _ := io.ReadAll(os.Stdin)
		name := opt.StdinFilename; if name == "" { name = "stdin.md" }
		issues, fixed := lintContent(name, string(data), opt)
		if opt.Check {
			if fixContent(string(data)) != string(data) { return 1 }
			return 0
		}
		if opt.Fix { fmt.Print(fixed) }
		printResults([]FileResult{{name, issues}}, opt, opt.Fix)
		if opt.Fix { return 0 }
		return exitCode(issues, opt)
	}
	files := collectFiles(opt.Paths)
	results := []FileResult{}
	all := []Issue{}
	fixedCount := 0
	for _, f := range files {
		b, err := os.ReadFile(f); if err != nil { continue }
		issues, fixed := lintContent(f, string(b), opt)
		if opt.Diff && fixed != string(b) {
			printDiff(f, string(b), fixed)
		}
		if opt.Fix && !opt.Diff && !opt.Check && fixed != string(b) {
			os.WriteFile(f, []byte(fixed), 0644)
		}
		for _, is := range issues { if is.Fixable { fixedCount++ } }
		results = append(results, FileResult{f, issues})
		all = append(all, issues...)
	}
	if opt.Check {
		for _, f := range files {
			b, err := os.ReadFile(f); if err == nil && fixContent(string(b)) != string(b) { return 1 }
		}
	}
	if opt.Silent { return exitCode(all, opt) }
	if opt.OutputFormat == "json" {
		b, _ := json.MarshalIndent(all, "", "  "); fmt.Println(string(b))
	} else if opt.OutputFormat == "json-lines" {
		for _, is := range all { b, _ := json.Marshal(is); fmt.Println(string(b)) }
	} else if opt.OutputFormat == "github" {
		for _, is := range all { fmt.Printf("::%s file=%s,line=%d,col=%d,title=%s::%s\n", ghaSeverity(is.Severity), is.File, is.Line, is.Column, is.Rule, is.Message) }
	} else if opt.OutputFormat == "pylint" {
		for _, is := range all { fmt.Printf("%s:%d:%d: %s: %s (%s)\n", is.File, is.Line, is.Column, strings.ToLower(is.Severity), is.Message, is.Rule) }
	} else if opt.OutputFormat == "gitlab" {
		b, _ := json.MarshalIndent(all, "", "  "); fmt.Println(string(b))
	} else if opt.OutputFormat == "sarif" {
		fmt.Println(`{"version":"2.1.0","runs":[{"tool":{"driver":{"name":"rumdl"}},"results":[]}]}`)
	} else if opt.OutputFormat == "junit" {
		fmt.Printf("<testsuite tests=\"%d\"></testsuite>\n", len(all))
	} else {
		printResults(results, opt, opt.Fix)
		if len(all) == 0 && !opt.Quiet {
			fmt.Printf("\nSuccess: No issues found in %d file%s (%dms)\n", len(files), plural(len(files)), elapsedMS())
		} else if len(all) > 0 && !opt.Quiet {
			if opt.Fix {
				fmt.Printf("\nFixed: Fixed %d/%d issues in %d file%s (%dms)\n", fixedCount, len(all), len(files), plural(len(files)), elapsedMS())
			} else {
				fmt.Printf("\nIssues: Found %d issue%s in %d file%s (%dms)\n", len(all), plural(len(all)), len(files), plural(len(files)), elapsedMS())
				if fixedCount > 0 { fmt.Printf("Run `rumdl fmt` to automatically fix %d of the %d issues\n", fixedCount, len(all)) }
			}
		}
	}
	return exitCode(all, opt)
}

func ghaSeverity(s string) string {
	if s == "error" { return "error" }
	return "warning"
}

func printDiff(path, old, fixed string) {
	fmt.Printf("--- %s\n+++ %s\n", path, path)
	oldLines := strings.Split(strings.TrimRight(old, "\n"), "\n")
	newLines := strings.Split(strings.TrimRight(fixed, "\n"), "\n")
	fmt.Println("@@")
	max := len(oldLines); if len(newLines) > max { max = len(newLines) }
	for i := 0; i < max; i++ {
		var a, b string
		if i < len(oldLines) { a = oldLines[i] }
		if i < len(newLines) { b = newLines[i] }
		if i >= len(oldLines) { fmt.Println("+" + b) } else if i >= len(newLines) { fmt.Println("-" + a) } else if a != b { fmt.Println("-" + a); fmt.Println("+" + b) } else { fmt.Println(" " + a) }
	}
}

var start = time.Now()
func elapsedMS() int { ms := int(time.Since(start).Milliseconds()); if ms < 1 { return 1 }; return ms }
func plural(n int) string { if n == 1 { return "" }; return "s" }

func printCheckHelp(fmtMode bool) {
	title := "Lint Markdown files and print warnings/errors"
	if fmtMode { title = "Format Markdown files (alias for check --fix)" }
	cmd := "check"; if fmtMode { cmd = "fmt" }
	fmt.Printf("%s\n\nUsage: executable %s [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  Files or directories to lint (use '-' for stdin)\n\nOptions:\n  -f, --fix          Fix issues automatically where possible\n      --diff         Show diff of what would be fixed instead of fixing files\n      --check        Exit with code 1 if any formatting changes would be made (for CI)\n  -l, --list-rules   List all available rules\n  -d, --disable <DISABLE>\n  -e, --enable <ENABLE>\n      --stdin\n      --stdin-filename <STDIN_FILENAME>\n  -h, --help         Print help\n", title, cmd)
}

func parseCheck(args []string) Options {
	o := Options{Enable: map[string]bool{}, Disable: map[string]bool{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-f", "--fix":
			o.Fix = true
		case "--diff":
			o.Diff = true
		case "--check":
			o.Check = true
		case "-q", "--quiet":
			o.Quiet = true
		case "-s", "--silent":
			o.Silent = true
		case "--stdin":
			o.Stdin = true
		case "--stderr":
			o.Stderr = true
		case "--no-config", "--isolated":
			o.NoConfig = true
		case "-l", "--list-rules":
			runRule(nil); os.Exit(0)
		case "-d", "--disable", "--extend-disable":
			i++; addList(o.Disable, args, i)
		case "-e", "--enable", "--rules", "--extend-enable":
			i++; addList(o.Enable, args, i)
		case "-o", "--output", "--output-format":
			i++; if i < len(args) { o.OutputFormat = args[i] }
		case "--stdin-filename":
			i++; if i < len(args) { o.StdinFilename = args[i] }
		case "--config":
			i++; if i < len(args) { o.Config = args[i] }
		case "--fail-on":
			i++; if i < len(args) { o.FailOn = args[i] }
		default:
			if strings.HasPrefix(a, "--color") || strings.HasPrefix(a, "--flavor") || strings.HasPrefix(a, "--cache-dir") || strings.HasPrefix(a, "--exclude") || strings.HasPrefix(a, "--include") || strings.HasPrefix(a, "--respect-gitignore") {
				if !strings.Contains(a, "=") && i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") { i++ }
			} else if !strings.HasPrefix(a, "-") {
				o.Paths = append(o.Paths, a)
			}
		}
	}
	return o
}

func addList(m map[string]bool, args []string, i int) {
	if i >= len(args) { return }
	for _, p := range strings.Split(args[i], ",") {
		p = strings.TrimSpace(strings.ToUpper(p)); if p != "" { m[p] = true }
	}
}

func applyConfig(o *Options) {
	p := findConfig(o.Config); if p == "" { return }
	b, err := os.ReadFile(p); if err != nil { return }
	txt := string(b)
	for _, key := range []string{"disable", "enable"} {
		re := regexp.MustCompile(`(?s)` + key + `\s*=\s*\[(.*?)\]`)
		if m := re.FindStringSubmatch(txt); m != nil {
			target := o.Disable; if key == "enable" { target = o.Enable }
			for _, q := range regexp.MustCompile(`"([^"]+)"`).FindAllStringSubmatch(m[1], -1) {
				target[strings.ToUpper(q[1])] = true
			}
		}
	}
}

func findConfig(explicit string) string {
	if explicit != "" { return explicit }
	if _, err := os.Stat(".rumdl.toml"); err == nil { return ".rumdl.toml" }
	if _, err := os.Stat("rumdl.toml"); err == nil { return "rumdl.toml" }
	if _, err := os.Stat("pyproject.toml"); err == nil { return "pyproject.toml" }
	return ""
}

type FileResult struct { File string; Issues []Issue }

func printResults(results []FileResult, opt Options, fixed bool) {
	w := io.Writer(os.Stdout)
	if opt.Stderr { w = os.Stderr }
	for _, r := range results {
		for _, is := range r.Issues {
			mark := ""
			if is.Fixable {
				if fixed { mark = " [fixed]" } else { mark = " [*]" }
			}
			fmt.Fprintf(w, "%s:%d:%d: [%s] %s%s\n", is.File, is.Line, is.Column, is.Rule, is.Message, mark)
		}
	}
}

func exitCode(issues []Issue, opt Options) int {
	if opt.FailOn == "never" { return 0 }
	if len(issues) == 0 { return 0 }
	if opt.FailOn == "error" {
		for _, is := range issues { if is.Severity == "error" { return 1 } }
		return 0
	}
	return 1
}

func collectFiles(paths []string) []string {
	if len(paths) == 0 { paths = []string{"."} }
	out := []string{}
	for _, p := range paths {
		info, err := os.Stat(p); if err != nil { continue }
		if !info.IsDir() {
			if isMarkdown(p) { out = append(out, p) }
			continue
		}
		filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
			if err != nil { return nil }
			name := d.Name()
			if d.IsDir() && (name == ".git" || name == "node_modules" || name == ".rumdl_cache") { return filepath.SkipDir }
			if !d.IsDir() && isMarkdown(path) { out = append(out, path) }
			return nil
		})
	}
	sort.Strings(out)
	return out
}

func isMarkdown(p string) bool {
	e := strings.ToLower(filepath.Ext(p))
	return e == ".md" || e == ".markdown" || e == ".mdx" || e == ".qmd"
}

func enabled(code string, o Options) bool {
	if len(o.Enable) > 0 && !o.Enable[code] { return false }
	return !o.Disable[code]
}

func addIssue(out *[]Issue, o Options, file string, line, col int, code, msg string, fixable bool) {
	if !enabled(code, o) { return }
	sev := "warning"
	switch code { case "MD011", "MD024", "MD025", "MD042", "MD045", "MD051", "MD057", "MD066", "MD068": sev = "error" }
	*out = append(*out, Issue{file, line, col, code, msg, sev, fixable})
}

func lintContent(file, content string, o Options) ([]Issue, string) {
	orig := content
	lines := splitLines(content)
	issues := []Issue{}
	inFence := false
	headings := map[string]int{}
	h1s := 0
	lastHeading := 0
	urlRe := regexp.MustCompile(`https?://[^\s<>)]+`)
	linkRe := regexp.MustCompile(`!?\[([^\]]*)\]\(([^)]*)\)`)
	refDefs := map[string]bool{}
	refUses := []struct{ id string; line int; col int }{}
	for i, line := range lines {
		ln := i + 1
		raw := strings.TrimRight(line, "\r\n")
		trim := strings.TrimSpace(raw)
		if strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") {
			if !inFence {
				inFence = true
				if enabled("MD040", o) && len(strings.TrimSpace(trim[3:])) == 0 {
					addIssue(&issues, o, file, ln, 1, "MD040", "Fenced code block should have a language specified", false)
				}
				if i > 0 && strings.TrimSpace(lines[i-1]) != "" { addIssue(&issues, o, file, ln, 1, "MD031", "Fenced code blocks should be surrounded by blank lines", true) }
			} else {
				inFence = false
				if i+1 < len(lines) && strings.TrimSpace(lines[i+1]) != "" { addIssue(&issues, o, file, ln, 1, "MD031", "Fenced code blocks should be surrounded by blank lines", true) }
			}
			continue
		}
		if inFence { continue }
		if strings.Contains(raw, "\t") {
			col := strings.Index(raw, "\t") + 1
			msg := "Found hard tab, use spaces instead"
			if col == 1 { msg = "Found leading tab, use 4 spaces instead" }
			addIssue(&issues, o, file, ln, col, "MD010", msg, true)
		}
		if n := trailingSpaces(raw); n > 0 {
			addIssue(&issues, o, file, ln, len(raw)-n+1, "MD009", fmt.Sprintf("%d trailing spaces found", n), true)
		}
		if len([]rune(raw)) > 80 && strings.TrimSpace(raw) != "" {
			addIssue(&issues, o, file, ln, 81, "MD013", fmt.Sprintf("Line length [%d] exceeds configured line length [80]", len([]rune(raw))), false)
		}
		if h := atxHeading(raw); h > 0 {
			if strings.HasPrefix(strings.TrimLeft(raw, " "), "#") && len(raw)-len(strings.TrimLeft(raw, " ")) > 0 {
				addIssue(&issues, o, file, ln, 1, "MD023", "Headings must start at the beginning of the line", true)
			}
			colAfter := h + 1
			if len(raw) == h || (len(raw) > h && raw[h] != ' ') {
				addIssue(&issues, o, file, ln, colAfter, "MD018", "No space after # in heading", true)
			} else if len(raw) > h+1 && raw[h+1] == ' ' {
				sp := countRun(raw[h:], ' ')
				addIssue(&issues, o, file, ln, colAfter, "MD019", fmt.Sprintf("Multiple spaces after # in heading (Expected: 1; Actual: %d)", sp), true)
			}
			if ln > 1 && strings.TrimSpace(lines[i-1]) != "" { addIssue(&issues, o, file, ln, 1, "MD022", "Expected 1 blank line above heading", true) }
			if i+1 < len(lines) && strings.TrimSpace(lines[i+1]) != "" { addIssue(&issues, o, file, ln, 1, "MD022", "Expected 1 blank line below heading", true) }
			if lastHeading > 0 && h > lastHeading+1 { addIssue(&issues, o, file, ln, 1, "MD001", fmt.Sprintf("Heading levels should only increment by one level at a time (expected h%d, got h%d)", lastHeading+1, h), true) }
			lastHeading = h
			text := headingText(raw)
			if strings.ContainsAny(strings.TrimRight(text, "# "), ".,;:!") {
				addIssue(&issues, o, file, ln, len(raw), "MD026", "Trailing punctuation in heading", true)
			}
			key := strings.ToLower(text)
			if headings[key] > 0 { addIssue(&issues, o, file, ln, 1, "MD024", fmt.Sprintf("Multiple headings with the same content: %q", text), false) }
			headings[key] = ln
			if h == 1 { h1s++; if h1s > 1 { addIssue(&issues, o, file, ln, 1, "MD025", "Multiple top-level headings in the same document", false) } }
		}
		if isList(raw) {
			m := regexp.MustCompile(`^(\s*)([-+*]|\d+[.)])(\s*)`).FindStringSubmatch(raw)
			if m != nil {
				spaces := len(m[3])
				if spaces != 1 { addIssue(&issues, o, file, ln, len(m[1])+len(m[2])+1, "MD030", fmt.Sprintf("Spaces after list markers (Expected: 1; Actual: %d)", spaces), true) }
			}
			if i > 0 && strings.TrimSpace(lines[i-1]) != "" && !isList(lines[i-1]) { addIssue(&issues, o, file, ln, 1, "MD032", "List should be preceded by blank line", true) }
			if i+1 < len(lines) && strings.TrimSpace(lines[i+1]) != "" && !isList(lines[i+1]) { addIssue(&issues, o, file, ln, 1, "MD032", "List should be followed by blank line", true) }
			if hasDuplicateListMarker(raw) { addIssue(&issues, o, file, ln, 1, "MD069", "Duplicate list marker", true) }
		}
		if strings.HasPrefix(trim, ">  ") { addIssue(&issues, o, file, ln, strings.Index(raw, ">")+2, "MD027", "Multiple spaces after blockquote symbol", true) }
		for _, m := range regexp.MustCompile(`\((https?://[^)\s]+|[^)\s]+)\)\[[^\]]+\]`).FindAllStringIndex(raw, -1) {
			addIssue(&issues, o, file, ln, m[0]+1, "MD011", "Reversed link syntax", true)
		}
		for _, m := range regexp.MustCompile("` [^`]+ `").FindAllStringIndex(raw, -1) {
			addIssue(&issues, o, file, ln, m[0]+1, "MD038", "Spaces inside code span elements", true)
		}
		for _, m := range regexp.MustCompile(`\[\s+[^\]]+|\[[^\]]+\s+\]`).FindAllStringIndex(raw, -1) {
			addIssue(&issues, o, file, ln, m[0]+1, "MD039", "Spaces inside link text", true)
		}
		for _, m := range regexp.MustCompile(`(\*\s+[^*]+\s+\*|_\s+[^_]+\s+_)`).FindAllStringIndex(raw, -1) {
			addIssue(&issues, o, file, ln, m[0]+1, "MD037", "Spaces inside emphasis markers", true)
		}
		if regexp.MustCompile(`^\s*(---|\*\*\*|___)\s*$`).MatchString(raw) {
			if i > 0 && strings.TrimSpace(lines[i-1]) != "" { addIssue(&issues, o, file, ln, 1, "MD065", "Horizontal rule should be surrounded by blank lines", true) }
			if i+1 < len(lines) && strings.TrimSpace(lines[i+1]) != "" { addIssue(&issues, o, file, ln, 1, "MD065", "Horizontal rule should be surrounded by blank lines", true) }
		}
		for _, m := range linkRe.FindAllStringSubmatchIndex(raw, -1) {
			full := raw[m[0]:m[1]]
			text := raw[m[2]:m[3]]
			dest := raw[m[4]:m[5]]
			col := m[0] + 1
			isImage := strings.HasPrefix(full, "!")
			if !isImage && (text == "" || strings.TrimSpace(dest) == "") { addIssue(&issues, o, file, ln, col, "MD042", "Empty link found: "+full, false) }
			if strings.HasPrefix(full, "!") && strings.TrimSpace(text) == "" { addIssue(&issues, o, file, ln, col, "MD045", "Image missing alt text (add description for accessibility: ![description](url))", true) }
			if dest != strings.TrimSpace(dest) { addIssue(&issues, o, file, ln, col, "MD062", "Link destination should not have leading or trailing whitespace", true) }
			if isRel(dest) && !existsRelative(file, dest) { addIssue(&issues, o, file, ln, col, "MD057", fmt.Sprintf("Relative link '%s' does not exist", dest), false) }
		}
		if regexp.MustCompile(`^\s*\[([^\]]+)\]:`).MatchString(raw) {
			m := regexp.MustCompile(`^\s*\[([^\]]+)\]:`).FindStringSubmatch(raw); refDefs[strings.ToLower(m[1])] = true
		} else {
			for _, m := range regexp.MustCompile(`!?\[[^\]]+\]\[([^\]]+)\]`).FindAllStringSubmatchIndex(raw, -1) {
				refUses = append(refUses, struct{ id string; line int; col int }{strings.ToLower(raw[m[2]:m[3]]), ln, m[0]+1})
			}
		}
		for _, m := range urlRe.FindAllStringIndex(raw, -1) {
			before := ""; if m[0] > 0 { before = raw[m[0]-1:m[0]] }
			if before != "<" && before != "(" {
				addIssue(&issues, o, file, ln, m[0]+1, "MD034", fmt.Sprintf("URL without angle brackets or link formatting: '%s'", raw[m[0]:m[1]]), true)
			}
		}
		if regexp.MustCompile(`<[A-Za-z][^>]*>`).MatchString(raw) && !strings.HasPrefix(trim, "<h1>") {
			addIssue(&issues, o, file, ln, strings.Index(raw, "<")+1, "MD033", "Inline HTML", false)
		}
		if !isList(raw) && regexp.MustCompile(`[A-Za-z0-9][ ]{2,}[A-Za-z0-9]`).MatchString(raw) {
			addIssue(&issues, o, file, ln, regexp.MustCompile(`[ ]{2,}`).FindStringIndex(raw)[0]+1, "MD064", "Multiple consecutive spaces", true)
		}
		if len(lines) > 0 && i == 0 && strings.TrimSpace(raw) == "---" {
			for j := 1; j < len(lines); j++ {
				if strings.TrimSpace(lines[j]) == "---" {
					if j+1 < len(lines) && strings.TrimSpace(lines[j+1]) != "" { addIssue(&issues, o, file, j+2, 1, "MD071", "Frontmatter should be followed by a blank line", true) }
					break
				}
			}
		}
		if strings.HasPrefix(trim, "[^") && regexp.MustCompile(`^\[\^[^\]]+\]:\s*$`).MatchString(trim) {
			addIssue(&issues, o, file, ln, 1, "MD068", "Footnote definition is empty", false)
		}
	}
	for _, u := range refUses {
		if !refDefs[u.id] { addIssue(&issues, o, file, u.line, u.col, "MD052", fmt.Sprintf("Reference link/image uses undefined label '%s'", u.id), false) }
	}
	if len(lines) > 0 {
		first := firstContent(lines)
		if first >= 0 && atxHeading(lines[first]) != 1 && !strings.HasPrefix(strings.TrimSpace(lines[first]), "<h1>") {
			addIssue(&issues, o, file, first+1, 1, "MD041", "First line in file should be a level 1 heading", false)
		}
	}
	if !strings.HasSuffix(orig, "\n") && orig != "" { addIssue(&issues, o, file, len(lines), len(lines[len(lines)-1])+1, "MD047", "File should end with a single newline character", true) }
	blankRun := 0
	for i, line := range lines {
		if strings.TrimSpace(line) == "" {
			blankRun++
			if blankRun > 1 { addIssue(&issues, o, file, i+1, 1, "MD012", "Multiple consecutive blank lines between content", true) }
		} else { blankRun = 0 }
	}
	fixed := orig
	if o.Fix || o.Diff || o.Check { fixed = fixContent(orig) }
	sort.SliceStable(issues, func(i, j int) bool { if issues[i].Line == issues[j].Line { return issues[i].Column < issues[j].Column }; return issues[i].Line < issues[j].Line })
	return issues, fixed
}

func splitLines(s string) []string {
	if s == "" { return []string{} }
	sc := bufio.NewScanner(strings.NewReader(s))
	sc.Buffer(make([]byte, 1024), 1024*1024*10)
	var lines []string
	for sc.Scan() { lines = append(lines, sc.Text()) }
	if strings.HasSuffix(s, "\n") { lines = append(lines, "") }
	return lines
}

func firstContent(lines []string) int {
	i := 0
	if len(lines) > 0 && strings.TrimSpace(lines[0]) == "---" {
		for j := 1; j < len(lines); j++ { if strings.TrimSpace(lines[j]) == "---" { i = j+1; break } }
	}
	for ; i < len(lines); i++ { if strings.TrimSpace(lines[i]) != "" { return i } }
	return -1
}

func trailingSpaces(s string) int { n := 0; for i := len(s)-1; i >= 0 && s[i] == ' '; i-- { n++ }; return n }
func atxHeading(s string) int {
	t := strings.TrimLeft(s, " ")
	n := 0; for n < len(t) && t[n] == '#' { n++ }
	if n >= 1 && n <= 6 { return n }
	return 0
}
func headingText(s string) string {
	t := strings.TrimLeft(s, " ")
	t = strings.TrimLeft(t, "#")
	t = strings.TrimSpace(t)
	t = strings.TrimRight(t, "#")
	return strings.TrimSpace(t)
}
func countRun(s string, b byte) int { n := 0; for n < len(s) && s[n] == b { n++ }; return n }
func isList(s string) bool { return regexp.MustCompile(`^\s*([-+*]|\d+[.)])\s+`).MatchString(s) }
func hasDuplicateListMarker(s string) bool {
	t := strings.TrimLeft(s, " ")
	if len(t) < 4 { return false }
	m := t[0]
	return (m == '-' || m == '+' || m == '*') && len(t) >= 4 && t[1] == ' ' && t[2] == m && t[3] == ' '
}
func isRel(dest string) bool {
	d := strings.TrimSpace(dest)
	return d != "" && !strings.HasPrefix(d, "#") && !strings.Contains(d, "://") && !strings.HasPrefix(d, "mailto:") && !strings.HasPrefix(d, "tel:")
}
func existsRelative(file, dest string) bool {
	d := strings.Split(dest, "#")[0]
	if d == "" { return true }
	base := filepath.Dir(file)
	_, err := os.Stat(filepath.Join(base, d))
	return err == nil
}

func fixContent(s string) string {
	lines := splitLines(s)
	out := []string{}
	for _, line := range lines {
		raw := strings.TrimRight(line, " ")
		raw = strings.ReplaceAll(raw, "\t", "    ")
		raw = regexp.MustCompile(`^(#{1,6})(\S)`).ReplaceAllString(raw, "$1 $2")
		raw = regexp.MustCompile(`^(#{1,6}) {2,}`).ReplaceAllString(raw, "$1 ")
		raw = regexp.MustCompile(`^(\s*[-+*]|\s*\d+[.)]) {2,}`).ReplaceAllString(raw, "$1 ")
		raw = regexp.MustCompile(`\(([^)\s]+)\)\[([^\]]+)\]`).ReplaceAllString(raw, "[$2]($1)")
		raw = regexp.MustCompile("` ([^`]+) `").ReplaceAllString(raw, "`$1`")
		raw = regexp.MustCompile(`\[\s+([^\]]+?)\s*\]`).ReplaceAllString(raw, "[$1]")
		raw = regexp.MustCompile(`\*\s+([^*]+?)\s+\*`).ReplaceAllString(raw, "*$1*")
		raw = regexp.MustCompile(`_\s+([^_]+?)\s+_`).ReplaceAllString(raw, "_$1_")
		raw = regexp.MustCompile(`(^|\s)(https?://[^\s<>)]+)`).ReplaceAllString(raw, "$1<$2>")
		raw = regexp.MustCompile(`!\[\]\(([^)]+)\)`).ReplaceAllStringFunc(raw, func(m string) string {
			dest := regexp.MustCompile(`\(([^)]+)\)`).FindStringSubmatch(m)[1]
			name := filepath.Base(strings.Split(dest, "#")[0])
			name = strings.TrimSuffix(name, filepath.Ext(name))
			if name == "" { name = "image" }
			return "![" + strings.Title(strings.ReplaceAll(name, "-", " ")) + " image](" + dest + ")"
		})
		out = append(out, raw)
	}
	// Collapse multiple blank lines.
	collapsed := []string{}
	blank := false
	for _, l := range out {
		if strings.TrimSpace(l) == "" {
			if !blank { collapsed = append(collapsed, "") }
			blank = true
		} else { collapsed = append(collapsed, l); blank = false }
	}
	res := strings.Join(collapsed, "\n")
	res = strings.TrimRight(res, "\n") + "\n"
	return res
}

func has(args []string, v string) bool { for _, a := range args { if a == v { return true } }; return false }
func takesValue(a string) bool { return a == "--config" || a == "--color" }

func atoi(s string) int { n, _ := strconv.Atoi(s); return n }
