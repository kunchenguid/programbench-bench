module rumdlclone

go 1.21
