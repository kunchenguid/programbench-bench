package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"cleanzstd/internalzstd"
)

const versionLine = "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***"

type options struct {
	decompress bool
	test       bool
	list       bool
	stdout     bool
	force      bool
	keep       bool
	rm         bool
	quiet      int
	verbose    int
	out        string
	inputs     []string
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if len(opts.inputs) == 0 {
		opts.inputs = []string{"-"}
		opts.stdout = true
	}
	if opts.test {
		opts.decompress = true
		opts.stdout = false
	}
	if opts.list {
		if err := listFiles(opts.inputs); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	for i, in := range opts.inputs {
		if opts.out != "" && len(opts.inputs) > 1 && !opts.stdout {
			fmt.Fprintln(os.Stderr, "zstd: multiple inputs cannot be used with -o")
			os.Exit(1)
		}
		if err := processOne(opts, in, i); err != nil {
			if opts.quiet < 2 {
				fmt.Fprintln(os.Stderr, err)
			}
			os.Exit(1)
		}
	}
}

func parseArgs(args []string) (options, error) {
	var opts options
	opts.keep = true
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opts.inputs = append(opts.inputs, args[i+1:]...)
			break
		}
		if a == "-" {
			opts.inputs = append(opts.inputs, a)
			continue
		}
		if !strings.HasPrefix(a, "-") || a == "" {
			opts.inputs = append(opts.inputs, a)
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasVal := strings.Cut(a, "=")
			switch name {
			case "--help":
				printLongHelp()
				os.Exit(0)
			case "--version":
				fmt.Println(versionLine)
				os.Exit(0)
			case "--decompress", "--uncompress":
				opts.decompress = true
			case "--test":
				opts.test = true
			case "--stdout", "--to-stdout":
				opts.stdout = true
				opts.keep = true
			case "--force":
				opts.force = true
			case "--keep":
				opts.keep = true
			case "--rm":
				opts.rm = true
				opts.keep = false
			case "--quiet":
				opts.quiet++
			case "--verbose":
				opts.verbose++
			case "--list":
				opts.list = true
			case "--output-dir-flat", "--output-dir-mirror", "--filelist", "--trace":
				if !hasVal {
					i++
					if i >= len(args) {
						return opts, fmt.Errorf("zstd: %s expects an argument", name)
					}
					val = args[i]
				}
				if name == "--filelist" {
					files, err := readFileList(val)
					if err != nil {
						return opts, err
					}
					opts.inputs = append(opts.inputs, files...)
				}
			case "--format", "--memory", "--memlimit", "--fast", "--long", "--adapt", "--ultra",
				"--single-thread", "--auto-threads", "--jobsize", "--rsyncable", "--exclude-compressed",
				"--stream-size", "--size-hint", "--target-compressed-block-size", "--no-dictID",
				"--compress-literals", "--no-compress-literals", "--row-match-finder", "--no-row-match-finder",
				"--mmap-dict", "--no-mmap-dict", "--check", "--no-check", "--progress", "--no-progress",
				"--asyncio", "--no-asyncio", "--sparse", "--no-sparse", "--pass-through", "--no-pass-through",
				"--train", "--train-cover", "--train-fastcover", "--train-legacy", "--maxdict", "--dictID",
				"--patch-from", "--patch-apply", "--priority", "--split":
				// Accepted for command-line compatibility. Compression remains raw zstd blocks.
			default:
				return opts, fmt.Errorf("zstd: unrecognized option '%s'", a)
			}
			_ = val
			continue
		}
		if len(a) >= 2 && a[1] >= '1' && a[1] <= '9' {
			continue
		}
		for j := 1; j < len(a); j++ {
			c := a[j]
			switch c {
			case 'd':
				opts.decompress = true
			case 'z':
				opts.decompress = false
			case 't':
				opts.test = true
			case 'l':
				opts.list = true
			case 'c':
				opts.stdout = true
				opts.keep = true
			case 'f':
				opts.force = true
			case 'k':
				opts.keep = true
			case 'q':
				opts.quiet++
			case 'v':
				opts.verbose++
			case 'h':
				printShortHelp()
				os.Exit(0)
			case 'H':
				printLongHelp()
				os.Exit(0)
			case 'V':
				fmt.Println(versionLine)
				os.Exit(0)
			case 'o', 'D', 'M', 'T', 'b', 'e', 'i':
				if j+1 < len(a) {
					if c == 'o' {
						opts.out = a[j+1:]
					}
					j = len(a)
				} else {
					i++
					if i >= len(args) {
						return opts, fmt.Errorf("zstd: -%c expects an argument", c)
					}
					if c == 'o' {
						opts.out = args[i]
					}
				}
			case 'r', 'S':
				// Accepted but not meaningfully needed for normal file tests.
			default:
				return opts, fmt.Errorf("zstd: unsupported option '-%c'", c)
			}
		}
	}
	return opts, nil
}

func processOne(opts options, input string, index int) error {
	data, err := readInput(input)
	if err != nil {
		return fmt.Errorf("zstd: %s: %w", input, err)
	}
	if opts.test {
		_, err := decodeZstd(data)
		return err
	}
	var outData []byte
	if opts.decompress {
		outData, err = decodeZstd(data)
	} else {
		outData = encodeRawZstd(data)
	}
	if err != nil {
		return fmt.Errorf("zstd: %s: %w", input, err)
	}
	if opts.stdout || input == "-" {
		_, err = os.Stdout.Write(outData)
		return err
	}
	outName := opts.out
	if outName == "" {
		if opts.decompress {
			outName = decompressedName(input)
		} else {
			outName = input + ".zst"
		}
	} else if index > 0 {
		return errors.New("zstd: internal multiple output error")
	}
	if !opts.force {
		if _, err := os.Stat(outName); err == nil {
			return fmt.Errorf("%s already exists; not overwritten", outName)
		}
	}
	if err := os.WriteFile(outName, outData, 0644); err != nil {
		return err
	}
	if opts.rm && input != "-" {
		_ = os.Remove(input)
	}
	if opts.quiet == 0 {
		if opts.decompress {
			fmt.Fprintf(os.Stderr, "%s: %d bytes \n", outName, len(outData))
		} else {
			ratio := 0.0
			if len(data) > 0 {
				ratio = 100 * float64(len(outData)) / float64(len(data))
			}
			fmt.Fprintf(os.Stderr, "%-20s:%6.2f%%   ( %d B => %d B, %s) \n", filepath.Base(input), ratio, len(data), len(outData), outName)
		}
	}
	return nil
}

func readInput(name string) ([]byte, error) {
	if name == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(name)
}

func encodeRawZstd(src []byte) []byte {
	var b bytes.Buffer
	b.Write([]byte{0x28, 0xb5, 0x2f, 0xfd})
	switch {
	case len(src) <= 255:
		b.WriteByte(0x20)
		b.WriteByte(byte(len(src)))
	case len(src) <= 65791:
		b.WriteByte(0x60)
		var tmp [2]byte
		binary.LittleEndian.PutUint16(tmp[:], uint16(len(src)-256))
		b.Write(tmp[:])
	case uint64(len(src)) <= uint64(^uint32(0)):
		b.WriteByte(0xa0)
		var tmp [4]byte
		binary.LittleEndian.PutUint32(tmp[:], uint32(len(src)))
		b.Write(tmp[:])
	default:
		b.WriteByte(0xe0)
		var tmp [8]byte
		binary.LittleEndian.PutUint64(tmp[:], uint64(len(src)))
		b.Write(tmp[:])
	}
	const maxBlock = 128 * 1024
	for off := 0; off < len(src) || off == 0; {
		n := len(src) - off
		if n > maxBlock {
			n = maxBlock
		}
		last := off+n >= len(src)
		header := uint32(n << 3)
		if last {
			header |= 1
		}
		b.WriteByte(byte(header))
		b.WriteByte(byte(header >> 8))
		b.WriteByte(byte(header >> 16))
		b.Write(src[off : off+n])
		off += n
		if len(src) == 0 {
			break
		}
	}
	return b.Bytes()
}

func decodeZstd(src []byte) ([]byte, error) {
	r := internalzstd.NewReader(bytes.NewReader(src))
	out, err := io.ReadAll(r)
	if err != nil {
		return nil, err
	}
	return out, nil
}

func decompressedName(name string) string {
	for _, suffix := range []string{".zst", ".zstd", ".tzst"} {
		if strings.HasSuffix(name, suffix) {
			return strings.TrimSuffix(name, suffix)
		}
	}
	return name + ".out"
}

func readFileList(path string) ([]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line != "" {
			out = append(out, line)
		}
	}
	return out, nil
}

func listFiles(inputs []string) error {
	fmt.Println("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
	for _, in := range inputs {
		data, err := readInput(in)
		if err != nil {
			return err
		}
		out, err := decodeZstd(data)
		if err != nil {
			return err
		}
		ratio := 0.0
		if len(data) > 0 {
			ratio = float64(len(out)) / float64(len(data))
		}
		fmt.Printf("%6d %6d %7s %9s %6.3f %6s  %s\n", 1, 0, byteCount(len(data)), byteCount(len(out)), ratio, "None", in)
	}
	return nil
}

func byteCount(n int) string {
	return strconv.Itoa(n) + " B"
}

func frameContentSize(data []byte) (uint64, bool) {
	if len(data) < 6 || binary.LittleEndian.Uint32(data[:4]) != 0xfd2fb528 {
		return 0, false
	}
	desc := data[4]
	ss := desc&(1<<5) != 0
	fcsSize := 1 << (desc >> 6)
	if fcsSize == 1 && !ss {
		fcsSize = 0
	}
	pos := 5
	if !ss {
		pos++
	}
	if desc&3 != 0 {
		pos += 1 << (desc & 3)
	}
	if pos+fcsSize > len(data) || fcsSize == 0 {
		return 0, false
	}
	switch fcsSize {
	case 1:
		return uint64(data[pos]), true
	case 2:
		return uint64(binary.LittleEndian.Uint16(data[pos:pos+2])) + 256, true
	case 4:
		return uint64(binary.LittleEndian.Uint32(data[pos : pos+4])), true
	case 8:
		return binary.LittleEndian.Uint64(data[pos : pos+8]), true
	}
	return 0, false
}

func printShortHelp() {
	fmt.Println("Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.")
	fmt.Println()
	fmt.Println("Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]")
	fmt.Println()
	fmt.Println("Options:")
	fmt.Println("  -o OUTPUT                     Write output to a single file, OUTPUT.")
	fmt.Println("  -k, --keep                    Preserve INPUT file(s). [Default] ")
	fmt.Println("  --rm                          Remove INPUT file(s) after successful (de)compression to file.")
	fmt.Println("  -d, --decompress              Perform decompression.")
	fmt.Println("  -f, --force                   Disable input and output checks.")
	fmt.Println("  -h                            Display short usage and exit.")
}

func printLongHelp() {
	fmt.Println(versionLine)
	fmt.Println()
	printShortHelp()
	fmt.Println("  -H, --help                    Display full help and exit.")
	fmt.Println("  -V, --version                 Display the program version and exit.")
	fmt.Println("  -c, --stdout                  Write to STDOUT and keep the INPUT file(s).")
	fmt.Println("  -q, --quiet                   Suppress warnings; pass twice to suppress errors.")
	fmt.Println("  -l                            Print information about Zstandard-compressed files.")
	fmt.Println("  --test                        Test compressed file integrity.")
}

var _ = flag.ErrHelp
var _ = frameContentSize
