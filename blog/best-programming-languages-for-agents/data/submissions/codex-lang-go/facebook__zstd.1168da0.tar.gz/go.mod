module cleanzstd

go 1.21
