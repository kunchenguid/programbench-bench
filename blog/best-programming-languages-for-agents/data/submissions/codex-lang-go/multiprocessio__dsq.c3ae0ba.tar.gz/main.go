package main

import (
	"bufio"
	"bytes"
	"database/sql"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"

	_ "github.com/mattn/go-sqlite3"
)

type tableData struct {
	Columns []string
	Types   map[string]string
	Rows    []map[string]any
}

type options struct {
	pretty      bool
	schema      bool
	cache       bool
	interactive bool
	streamType  string
	queryFile   string
	args        []string
}

const helpText = `dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq`

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run() error {
	opt, err := parseArgs(os.Args[1:])
	if err != nil {
		return err
	}
	if opt.cache {
		fmt.Fprintln(os.Stderr, "Cache invalid, re-import required.")
	}
	if opt.interactive {
		return errors.New("EOF")
	}

	var files []string
	var query string
	if opt.queryFile != "" {
		b, err := os.ReadFile(opt.queryFile)
		if err != nil {
			return err
		}
		query = strings.TrimSpace(string(b))
		files = opt.args
	} else if opt.streamType != "" {
		files = []string{"-"}
		if len(opt.args) > 0 {
			query = opt.args[len(opt.args)-1]
		}
	} else {
		files, query = splitFilesAndQuery(opt.args)
	}

	if len(files) == 0 {
		fmt.Println(helpText)
		return nil
	}

	tables := make([]tableData, 0, len(files))
	for _, f := range files {
		var td tableData
		if f == "-" {
			td, err = loadReader(os.Stdin, opt.streamType)
		} else {
			td, err = loadFile(f)
		}
		if err != nil {
			return err
		}
		tables = append(tables, td)
	}

	if opt.schema {
		return printSchema(tables[0])
	}
	if strings.TrimSpace(query) == "" {
		query = "select * from {}"
	}
	query = rewriteQuery(query, len(tables))

	db, err := sql.Open("sqlite3", ":memory:")
	if err != nil {
		return err
	}
	defer db.Close()
	for i, td := range tables {
		if err := importTable(db, fmt.Sprintf("t%d", i), td); err != nil {
			return err
		}
	}
	cols, rows, err := queryRows(db, query)
	if err != nil {
		return err
	}
	if opt.pretty {
		printPretty(cols, rows)
	} else {
		printJSON(rows)
	}
	return nil
}

func parseArgs(args []string) (options, error) {
	var opt options
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help", "-h":
			fmt.Println(helpText)
			os.Exit(0)
		case "--version":
			fmt.Println("dsq latest")
			os.Exit(0)
		case "-p", "--pretty":
			opt.pretty = true
		case "--schema":
			opt.schema = true
		case "-C", "--cache":
			opt.cache = true
		case "-i", "--interactive":
			opt.interactive = true
		case "-s":
			i++
			if i >= len(args) {
				return opt, errors.New("missing argument for -s")
			}
			opt.streamType = args[i]
		case "-f", "--file":
			i++
			if i >= len(args) {
				return opt, errors.New("missing argument for -f")
			}
			opt.queryFile = args[i]
		default:
			opt.args = append(opt.args, a)
		}
	}
	return opt, nil
}

func splitFilesAndQuery(args []string) ([]string, string) {
	if len(args) == 0 {
		return nil, ""
	}
	if len(args) == 1 {
		return []string{args[0]}, ""
	}
	last := args[len(args)-1]
	if looksLikeQuery(last) {
		return args[:len(args)-1], last
	}
	return args, ""
}

func looksLikeQuery(s string) bool {
	t := strings.TrimSpace(strings.ToLower(s))
	return strings.HasPrefix(t, "select ") || strings.HasPrefix(t, "with ") ||
		strings.HasPrefix(t, "pragma ") || strings.Contains(t, " from ")
}

func loadFile(path string) (tableData, error) {
	f, err := os.Open(path)
	if err != nil {
		return tableData{}, err
	}
	defer f.Close()
	ext := strings.ToLower(strings.TrimPrefix(filepath.Ext(path), "."))
	if ext == "gz" {
		ext = strings.ToLower(strings.TrimPrefix(filepath.Ext(strings.TrimSuffix(path, filepath.Ext(path))), "."))
	}
	switch ext {
	case "csv":
		return loadDelimited(f, ',')
	case "tsv", "tab":
		return loadDelimited(f, '\t')
	case "json":
		return loadJSON(f)
	case "jsonl", "ndjson":
		return loadNDJSON(f)
	case "logfmt":
		return loadLogfmt(f)
	default:
		return tableData{}, fmt.Errorf("Unknown mimetype for file: %s.", path)
	}
}

func loadReader(r io.Reader, typ string) (tableData, error) {
	switch strings.ToLower(typ) {
	case "csv", "":
		return loadDelimited(r, ',')
	case "tsv":
		return loadDelimited(r, '\t')
	case "json":
		return loadJSON(r)
	case "jsonl", "ndjson":
		return loadNDJSON(r)
	case "logfmt":
		return loadLogfmt(r)
	default:
		return tableData{}, fmt.Errorf("Unknown mimetype for file: -.")
	}
}

func loadDelimited(r io.Reader, comma rune) (tableData, error) {
	cr := csv.NewReader(r)
	cr.Comma = comma
	cr.FieldsPerRecord = -1
	records, err := cr.ReadAll()
	if err != nil {
		return tableData{}, err
	}
	if len(records) == 0 {
		return tableData{}, nil
	}
	cols := uniqueHeaders(records[0])
	rows := make([]map[string]any, 0, len(records)-1)
	for _, rec := range records[1:] {
		m := map[string]any{}
		for i, c := range cols {
			if i < len(rec) {
				m[c] = rec[i]
			} else {
				m[c] = ""
			}
		}
		rows = append(rows, m)
	}
	types := map[string]string{}
	for _, c := range cols {
		types[c] = "TEXT"
	}
	return tableData{Columns: cols, Types: types, Rows: rows}, nil
}

func loadJSON(r io.Reader) (tableData, error) {
	b, err := io.ReadAll(r)
	if err != nil {
		return tableData{}, err
	}
	b = bytes.TrimSpace(b)
	if len(b) == 0 {
		return tableData{}, nil
	}
	var v any
	if err := json.Unmarshal(b, &v); err != nil {
		return loadNDJSON(bytes.NewReader(b))
	}
	var vals []any
	switch x := v.(type) {
	case []any:
		vals = x
	default:
		vals = []any{x}
	}
	return rowsFromValues(vals), nil
}

func loadNDJSON(r io.Reader) (tableData, error) {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 1024), 1024*1024*100)
	var vals []any
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var v any
		if err := json.Unmarshal([]byte(line), &v); err != nil {
			return tableData{}, err
		}
		vals = append(vals, v)
	}
	if err := sc.Err(); err != nil {
		return tableData{}, err
	}
	return rowsFromValues(vals), nil
}

func loadLogfmt(r io.Reader) (tableData, error) {
	sc := bufio.NewScanner(r)
	var rows []map[string]any
	var cols []string
	seen := map[string]bool{}
	for sc.Scan() {
		m := map[string]any{}
		for _, part := range strings.Fields(sc.Text()) {
			k, v, ok := strings.Cut(part, "=")
			if !ok {
				continue
			}
			v = strings.Trim(v, `"`)
			m[k] = v
			if !seen[k] {
				seen[k] = true
				cols = append(cols, k)
			}
		}
		if len(m) > 0 {
			rows = append(rows, m)
		}
	}
	types := map[string]string{}
	for _, c := range cols {
		types[c] = "TEXT"
	}
	return tableData{Columns: cols, Types: types, Rows: rows}, sc.Err()
}

func rowsFromValues(vals []any) tableData {
	seen := map[string]bool{}
	var cols []string
	var rows []map[string]any
	for _, v := range vals {
		m := map[string]any{}
		switch x := v.(type) {
		case map[string]any:
			keys := make([]string, 0, len(x))
			for k := range x {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, k := range keys {
				m[k] = x[k]
				if !seen[k] {
					seen[k] = true
					cols = append(cols, k)
				}
			}
		default:
			m["value"] = x
			if !seen["value"] {
				seen["value"] = true
				cols = append(cols, "value")
			}
		}
		rows = append(rows, m)
	}
	return tableData{Columns: cols, Types: map[string]string{}, Rows: rows}
}

func uniqueHeaders(in []string) []string {
	used := map[string]int{}
	out := make([]string, len(in))
	for i, h := range in {
		h = strings.TrimSpace(h)
		if h == "" {
			h = fmt.Sprintf("column%d", i+1)
		}
		base := h
		if n := used[base]; n > 0 {
			h = fmt.Sprintf("%s_%d", base, n+1)
		}
		used[base]++
		out[i] = h
	}
	return out
}

var tableRefRE = regexp.MustCompile(`\{([0-9]+)\}`)
var qualifiedEqRE = regexp.MustCompile(`\b(t[0-9]+\.[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(t[0-9]+\.[A-Za-z_][A-Za-z0-9_]*)\b`)

func rewriteQuery(q string, n int) string {
	q = strings.ReplaceAll(q, "{}", "t0")
	q = tableRefRE.ReplaceAllString(q, "t$1")
	q = qualifiedEqRE.ReplaceAllString(q, "CAST($1 AS TEXT) = CAST($2 AS TEXT)")
	return q
}

func importTable(db *sql.DB, name string, td tableData) error {
	if len(td.Columns) == 0 {
		td.Columns = []string{"value"}
	}
	defs := make([]string, len(td.Columns))
	for i, c := range td.Columns {
		defs[i] = quoteIdent(c)
		if td.Types != nil && td.Types[c] != "" {
			defs[i] += " " + td.Types[c]
		}
	}
	if _, err := db.Exec("create table " + quoteIdent(name) + " (" + strings.Join(defs, ", ") + ")"); err != nil {
		return err
	}
	qs := make([]string, len(td.Columns))
	for i := range qs {
		qs[i] = "?"
	}
	stmt, err := db.Prepare("insert into " + quoteIdent(name) + " (" + joinQuoted(td.Columns) + ") values (" + strings.Join(qs, ",") + ")")
	if err != nil {
		return err
	}
	defer stmt.Close()
	for _, row := range td.Rows {
		args := make([]any, len(td.Columns))
		for i, c := range td.Columns {
			args[i] = normalizeValue(row[c])
		}
		if _, err := stmt.Exec(args...); err != nil {
			return err
		}
	}
	return nil
}

func normalizeValue(v any) any {
	switch x := v.(type) {
	case nil:
		return nil
	case bool:
		if x {
			return 1
		}
		return 0
	case float64:
		if x == float64(int64(x)) {
			return int64(x)
		}
		return x
	case []any, map[string]any:
		b, _ := json.Marshal(x)
		return string(b)
	default:
		return x
	}
}

func queryRows(db *sql.DB, q string) ([]string, []map[string]any, error) {
	rs, err := db.Query(q)
	if err != nil {
		return nil, nil, err
	}
	defer rs.Close()
	cols, err := rs.Columns()
	if err != nil {
		return nil, nil, err
	}
	var out []map[string]any
	for rs.Next() {
		vals := make([]any, len(cols))
		ptrs := make([]any, len(cols))
		for i := range vals {
			ptrs[i] = &vals[i]
		}
		if err := rs.Scan(ptrs...); err != nil {
			return nil, nil, err
		}
		m := map[string]any{}
		for i, c := range cols {
			m[c] = sqliteValue(vals[i])
		}
		out = append(out, m)
	}
	return cols, out, rs.Err()
}

func sqliteValue(v any) any {
	switch x := v.(type) {
	case []byte:
		return string(x)
	default:
		return x
	}
}

func printJSON(rows []map[string]any) {
	fmt.Print("[")
	for i, row := range rows {
		b, _ := json.Marshal(row)
		if i > 0 {
			fmt.Print(",\n")
		}
		fmt.Print(string(b))
	}
	fmt.Println("]")
}

func printSchema(td tableData) error {
	obj := map[string]any{}
	for _, c := range td.Columns {
		kind := "string"
		for _, r := range td.Rows {
			if v, ok := r[c]; ok && v != nil {
				kind = scalarKind(v)
				break
			}
		}
		obj[c] = map[string]any{"kind": "scalar", "scalar": kind}
	}
	root := map[string]any{
		"kind": "array",
		"array": map[string]any{
			"kind":   "object",
			"object": obj,
		},
	}
	b, err := json.MarshalIndent(root, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(b))
	return nil
}

func scalarKind(v any) string {
	switch v.(type) {
	case bool:
		return "boolean"
	case float64, int, int64:
		return "number"
	default:
		return "string"
	}
}

func printPretty(cols []string, rows []map[string]any) {
	widths := make([]int, len(cols))
	for i, c := range cols {
		widths[i] = len(c)
	}
	cells := make([][]string, len(rows))
	for r, row := range rows {
		cells[r] = make([]string, len(cols))
		for i, c := range cols {
			s := formatCell(row[c])
			cells[r][i] = s
			if len(s) > widths[i] {
				widths[i] = len(s)
			}
		}
	}
	border := func() {
		fmt.Print("+")
		for _, w := range widths {
			fmt.Print(strings.Repeat("-", w+2), "+")
		}
		fmt.Println()
	}
	border()
	fmt.Print("|")
	for i, c := range cols {
		fmt.Printf(" %-*s |", widths[i], c)
	}
	fmt.Println()
	border()
	for _, row := range cells {
		fmt.Print("|")
		for i, s := range row {
			if isNumberish(s) {
				fmt.Printf(" %*s |", widths[i], s)
			} else {
				fmt.Printf(" %-*s |", widths[i], s)
			}
		}
		fmt.Println()
	}
	border()
	if len(rows) == 1 {
		fmt.Println("(1 row)")
	} else {
		fmt.Printf("(%d rows)\n", len(rows))
	}
}

func formatCell(v any) string {
	if v == nil {
		return ""
	}
	switch x := v.(type) {
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	default:
		return fmt.Sprint(x)
	}
}

func isNumberish(s string) bool {
	if s == "" {
		return false
	}
	for i, r := range s {
		if !(unicode.IsDigit(r) || r == '-' || r == '+' || r == '.') || (r == '.' && i == len(s)-1) {
			return false
		}
	}
	return true
}

func quoteIdent(s string) string {
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func joinQuoted(cols []string) string {
	x := make([]string, len(cols))
	for i, c := range cols {
		x[i] = quoteIdent(c)
	}
	return strings.Join(x, ",")
}
