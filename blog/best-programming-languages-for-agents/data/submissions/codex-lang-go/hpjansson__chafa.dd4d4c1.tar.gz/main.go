package main

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"errors"
	"flag"
	"fmt"
	"image"
	"image/color"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
)

type options struct {
	filesPath       string
	files0Path      string
	probe           string
	probeMode       string
	verbose         bool
	format          string
	colors          string
	optimize        int
	relative        string
	passthrough     string
	polite          string
	align           string
	clear           bool
	exactSize       string
	fitWidth        bool
	fontRatio       float64
	grid            string
	label           string
	link            string
	marginBottom    int
	marginRight     int
	scale           string
	size            string
	stretch         bool
	viewSize        string
	animate         string
	duration        string
	speed           string
	watch           bool
	bg              string
	fg              string
	colorExtractor  string
	colorSpace      string
	dither          string
	ditherGrain     string
	ditherIntensity string
	invert          bool
	preprocess      string
	threshold       string
	threads         string
	work            int
	fgOnly          bool
	fill            string
	glyphFile       string
	symbols         string
}

const helpText = `Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
`

const versionText = `Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

`

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	opt, rest, code, handled := parse(args)
	if handled {
		return code
	}
	if code != 0 {
		return code
	}
	if err := validate(opt); err != nil {
		fmt.Fprintf(os.Stderr, "./executable: %s\n", err)
		return 2
	}
	files, err := collectFiles(opt, rest)
	if err != nil {
		fmt.Fprintf(os.Stderr, "./executable: %s\n", err)
		return 1
	}
	if len(files) == 0 {
		files = []string{"-"}
	}
	hadError := false
	for i, f := range files {
		if opt.clear {
			fmt.Print("\033[H\033[2J")
		}
		if i > 0 {
			fmt.Print("\n")
		}
		if err := processFile(f, opt); err != nil {
			fmt.Fprintf(os.Stderr, "./executable: %s\n", err)
			hadError = true
		}
	}
	if hadError {
		return 2
	}
	if opt.watch && len(files) == 1 {
		if d, _ := strconv.ParseFloat(opt.duration, 64); d > 0 {
			time.Sleep(time.Duration(d * float64(time.Second)))
		}
	}
	return 0
}

func parse(args []string) (options, []string, int, bool) {
	opt := options{probe: "auto", probeMode: "any", format: "symbols", optimize: -1, relative: "off", passthrough: "auto", polite: "off", exactSize: "auto", fontRatio: 0.5, label: "off", link: "auto", marginBottom: 1, scale: "", animate: "on", colorExtractor: "average", colorSpace: "rgb", dither: "", ditherGrain: "4x4", ditherIntensity: "1.0", preprocess: "", threshold: "0.0", work: 5, symbols: "", fill: "none"}
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	help := fs.Bool("help", false, "")
	helpShort := fs.Bool("h", false, "")
	version := fs.Bool("version", false, "")
	fs.StringVar(&opt.filesPath, "files", "", "")
	fs.StringVar(&opt.files0Path, "files0", "", "")
	fs.StringVar(&opt.probe, "probe", opt.probe, "")
	fs.StringVar(&opt.probeMode, "probe-mode", opt.probeMode, "")
	fs.BoolVar(&opt.verbose, "verbose", false, "")
	fs.BoolVar(&opt.verbose, "v", false, "")
	fs.StringVar(&opt.format, "format", opt.format, "")
	fs.StringVar(&opt.format, "f", opt.format, "")
	fs.IntVar(&opt.optimize, "optimize", -1, "")
	fs.IntVar(&opt.optimize, "O", -1, "")
	fs.StringVar(&opt.relative, "relative", opt.relative, "")
	fs.StringVar(&opt.passthrough, "passthrough", opt.passthrough, "")
	fs.StringVar(&opt.polite, "polite", opt.polite, "")
	fs.StringVar(&opt.align, "align", "", "")
	fs.BoolVar(&opt.clear, "clear", false, "")
	fs.StringVar(&opt.exactSize, "exact-size", opt.exactSize, "")
	fs.BoolVar(&opt.fitWidth, "fit-width", false, "")
	fs.Var(ratioValue{&opt.fontRatio}, "font-ratio", "")
	gridShort := fs.Bool("g", false, "")
	fs.StringVar(&opt.grid, "grid", "", "")
	labelShort := fs.Bool("l", false, "")
	fs.StringVar(&opt.label, "label", opt.label, "")
	fs.StringVar(&opt.link, "link", opt.link, "")
	fs.IntVar(&opt.marginBottom, "margin-bottom", 1, "")
	fs.IntVar(&opt.marginRight, "margin-right", 0, "")
	fs.StringVar(&opt.scale, "scale", "", "")
	fs.BoolVar(&opt.stretch, "stretch", false, "")
	fs.StringVar(&opt.viewSize, "view-size", "", "")
	fs.StringVar(&opt.size, "size", "", "")
	fs.StringVar(&opt.size, "s", "", "")
	fs.StringVar(&opt.animate, "animate", opt.animate, "")
	fs.StringVar(&opt.duration, "duration", "", "")
	fs.StringVar(&opt.duration, "d", "", "")
	fs.StringVar(&opt.speed, "speed", "", "")
	fs.BoolVar(&opt.watch, "watch", false, "")
	fs.StringVar(&opt.bg, "bg", "", "")
	fs.StringVar(&opt.colors, "colors", "", "")
	fs.StringVar(&opt.colors, "c", "", "")
	fs.StringVar(&opt.colorExtractor, "color-extractor", opt.colorExtractor, "")
	fs.StringVar(&opt.colorSpace, "color-space", opt.colorSpace, "")
	fs.StringVar(&opt.dither, "dither", "", "")
	fs.StringVar(&opt.ditherGrain, "dither-grain", opt.ditherGrain, "")
	fs.StringVar(&opt.ditherIntensity, "dither-intensity", opt.ditherIntensity, "")
	fs.StringVar(&opt.fg, "fg", "", "")
	fs.BoolVar(&opt.invert, "invert", false, "")
	fs.StringVar(&opt.preprocess, "preprocess", "", "")
	fs.StringVar(&opt.preprocess, "p", "", "")
	fs.StringVar(&opt.threshold, "threshold", opt.threshold, "")
	fs.StringVar(&opt.threshold, "t", opt.threshold, "")
	fs.StringVar(&opt.threads, "threads", "", "")
	fs.IntVar(&opt.work, "work", 5, "")
	fs.IntVar(&opt.work, "w", 5, "")
	fs.BoolVar(&opt.fgOnly, "fg-only", false, "")
	fs.StringVar(&opt.fill, "fill", opt.fill, "")
	fs.StringVar(&opt.glyphFile, "glyph-file", "", "")
	fs.StringVar(&opt.symbols, "symbols", "", "")
	if err := fs.Parse(args); err != nil {
		msg := err.Error()
		if strings.Contains(msg, "flag provided but not defined") {
			name := strings.TrimPrefix(strings.TrimSpace(strings.TrimPrefix(msg, "flag provided but not defined:")), "-")
			fmt.Fprintf(os.Stderr, "./executable: Unknown option --%s\n", name)
		} else {
			fmt.Fprintf(os.Stderr, "./executable: %s\n", msg)
		}
		return opt, nil, 2, true
	}
	if *help || *helpShort {
		fmt.Print(helpText)
		return opt, nil, 0, true
	}
	if *version {
		fmt.Print(versionText)
		return opt, nil, 0, true
	}
	if *labelShort {
		opt.label = "on"
	}
	if *gridShort {
		opt.grid = "auto"
	}
	return opt, fs.Args(), 0, false
}

type ratioValue struct{ p *float64 }

func (r ratioValue) String() string { return fmt.Sprint(*r.p) }
func (r ratioValue) Set(s string) error {
	v, err := parseRatio(s)
	if err == nil {
		*r.p = v
	}
	return err
}

func parseRatio(s string) (float64, error) {
	if strings.Contains(s, "/") {
		p := strings.SplitN(s, "/", 2)
		a, e1 := strconv.ParseFloat(p[0], 64)
		b, e2 := strconv.ParseFloat(p[1], 64)
		if e1 != nil || e2 != nil || b == 0 {
			return 0, errors.New("bad ratio")
		}
		return a / b, nil
	}
	return strconv.ParseFloat(s, 64)
}

func validate(o options) error {
	if o.format != "symbols" && o.format != "sixels" && o.format != "kitty" && o.format != "iterm" {
		return fmt.Errorf("Output format given as '%s'. Must be one of [iterm, kitty, sixels, symbols].", o.format)
	}
	if o.colors != "" {
		ok := map[string]bool{"none": true, "2": true, "8": true, "16/8": true, "16": true, "240": true, "256": true, "full": true}
		if !ok[o.colors] {
			return errors.New("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].")
		}
	}
	if o.size != "" {
		if _, _, err := parseSize(o.size); err != nil {
			return errors.New("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.")
		}
	}
	if o.viewSize != "" {
		if _, _, err := parseSize(o.viewSize); err != nil {
			return errors.New("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.")
		}
	}
	if o.work < 1 || o.work > 9 {
		return errors.New("Work factor must be in the range [1, 9].")
	}
	for _, s := range []string{o.symbols, o.fill} {
		if err := validateSymbols(s); err != nil {
			return err
		}
	}
	return nil
}

func validateSymbols(s string) error {
	if s == "" {
		return nil
	}
	classes := map[string]bool{"all": true, "ascii": true, "braille": true, "extra": true, "imported": true, "narrow": true, "solid": true, "ugly": true, "alnum": true, "bad": true, "diagonal": true, "geometric": true, "inverted": true, "none": true, "space": true, "vhalf": true, "alpha": true, "block": true, "digit": true, "half": true, "latin": true, "quad": true, "stipple": true, "wedge": true, "ambiguous": true, "border": true, "dot": true, "hhalf": true, "legacy": true, "sextant": true, "technical": true, "wide": true}
	f := func(r rune) bool { return r == '+' || r == '-' }
	for _, t := range strings.FieldsFunc(s, f) {
		if t != "" && !classes[t] {
			return fmt.Errorf("Unrecognized symbol tag '%s'.", t)
		}
	}
	return nil
}

func parseSize(s string) (int, int, error) {
	if !strings.Contains(s, "x") {
		return 0, 0, errors.New("bad")
	}
	p := strings.SplitN(s, "x", 2)
	w, h := 0, 0
	var err error
	if p[0] != "" {
		w, err = strconv.Atoi(p[0])
		if err != nil || w < 1 {
			return 0, 0, errors.New("bad")
		}
	}
	if p[1] != "" {
		h, err = strconv.Atoi(p[1])
		if err != nil || h < 1 {
			return 0, 0, errors.New("bad")
		}
	}
	if w == 0 && h == 0 {
		return 0, 0, errors.New("bad")
	}
	return w, h, nil
}

func collectFiles(o options, rest []string) ([]string, error) {
	out := append([]string{}, rest...)
	if o.filesPath != "" || o.files0Path != "" {
		path, nul := o.filesPath, false
		if o.files0Path != "" {
			path, nul = o.files0Path, true
		}
		var b []byte
		var err error
		if path == "-" {
			b, err = io.ReadAll(os.Stdin)
		} else {
			b, err = os.ReadFile(path)
		}
		if err != nil {
			return out, fmt.Errorf("Failed to open '%s': %s", path, errString(err))
		}
		if nul {
			for _, part := range bytes.Split(b, []byte{0}) {
				if len(part) > 0 {
					out = append(out, string(part))
				}
			}
		} else {
			sc := bufio.NewScanner(bytes.NewReader(b))
			for sc.Scan() {
				if sc.Text() != "" {
					out = append(out, sc.Text())
				}
			}
		}
	}
	return out, nil
}

func processFile(path string, o options) error {
	data, err := readInput(path)
	if err != nil {
		return fmt.Errorf("Failed to open '%s': %s", path, errString(err))
	}
	if o.format == "kitty" || o.format == "iterm" {
		return emitInline(path, data, o.format)
	}
	img, err := decodeImage(data)
	if err != nil {
		return fmt.Errorf("Failed to load '%s': %s", path, errString(err))
	}
	if o.format == "sixels" {
		fmt.Print("\033Pq\033\\")
		return nil
	}
	renderSymbols(img, path, o)
	return nil
}

func readInput(path string) ([]byte, error) {
	if path == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(path)
}

func decodeImage(b []byte) (image.Image, error) {
	if img, err := png.Decode(bytes.NewReader(b)); err == nil {
		return img, nil
	}
	if img, err := jpeg.Decode(bytes.NewReader(b)); err == nil {
		return img, nil
	}
	if img, err := gif.Decode(bytes.NewReader(b)); err == nil {
		return img, nil
	}
	img, _, err := image.Decode(bytes.NewReader(b))
	return img, err
}

func emitInline(path string, data []byte, format string) error {
	enc := base64.StdEncoding.EncodeToString(data)
	switch format {
	case "iterm":
		name := base64.StdEncoding.EncodeToString([]byte(filepath.Base(path)))
		fmt.Printf("\033]1337;File=name=%s;inline=1:%s\a\n", name, enc)
	case "kitty":
		fmt.Printf("\033_Gf=100,t=f;%s\033\\\n", enc)
	}
	return nil
}

func renderSymbols(img image.Image, path string, o options) {
	b := img.Bounds()
	iw, ih := b.Dx(), b.Dy()
	maxW, maxH := 80, 24
	if o.viewSize != "" {
		if w, h, err := parseSize(o.viewSize); err == nil {
			if w > 0 {
				maxW = w
			}
			if h > 0 {
				maxH = h
			}
		}
	}
	if o.size != "" {
		if w, h, err := parseSize(o.size); err == nil {
			if w > 0 {
				maxW = w
			}
			if h > 0 {
				maxH = h
			}
		}
	}
	scale := 4.0
	if o.scale != "" && o.scale != "max" {
		if v, err := strconv.ParseFloat(o.scale, 64); err == nil && v > 0 {
			scale = v
		}
	}
	outW := int(math.Max(1, math.Round(float64(iw)*scale*o.fontRatio)))
	outH := int(math.Max(1, math.Round(float64(ih)*scale*o.fontRatio*o.fontRatio)))
	if o.scale == "" && !o.stretch && iw <= 2 && ih <= 2 {
		outW = iw
		outH = int(math.Max(1, math.Round(float64(ih)*o.fontRatio)))
	}
	if o.scale == "max" || o.stretch {
		if maxW > 0 {
			outW = maxW
		}
		if maxH > 0 {
			outH = maxH
		}
	} else {
		if maxW > 0 && outW > maxW {
			ratio := float64(maxW) / float64(outW)
			outW = maxW
			outH = int(math.Max(1, math.Round(float64(outH)*ratio)))
		}
		if maxH > 0 && outH > maxH {
			ratio := float64(maxH) / float64(outH)
			outH = maxH
			outW = int(math.Max(1, math.Round(float64(outW)*ratio)))
		}
		// Preserve large image aspect better after constraints.
		if o.size != "" && iw > 1 && ih > 1 {
			targetH := int(math.Max(1, math.Round(float64(outW)*float64(ih)/float64(iw)*o.fontRatio)))
			if maxH == 0 || targetH <= maxH {
				outH = targetH
			}
		}
	}
	if outW < 1 {
		outW = 1
	}
	if outH < 1 {
		outH = 1
	}
	pal := palette(o.symbols)
	colored := o.colors != "none" && o.colors != "2"
	for y := 0; y < outH; y++ {
		var line strings.Builder
		for x := 0; x < outW; x++ {
			r, g, bc, a := sample(img, b, x, y, outW, outH)
			if a < 20 {
				line.WriteByte(' ')
				continue
			}
			lum := 0.2126*float64(r) + 0.7152*float64(g) + 0.0722*float64(bc)
			if r > 200 && (g > 200 || bc > 200) {
				lum = 255
			}
			ch := pal[int(math.Round(lum/255*float64(len(pal)-1)))]
			if colored {
				line.WriteString(ansiColor(r, g, bc, o.colors))
				line.WriteRune(ch)
				line.WriteString("\033[0m")
			} else {
				line.WriteRune(ch)
			}
		}
		fmt.Println(line.String())
	}
	if o.label == "on" || o.label == "true" {
		fmt.Println(path)
	}
}

func palette(sym string) []rune {
	if strings.Contains(sym, "space") || sym == "none" {
		return []rune(" ")
	}
	if strings.Contains(sym, "solid") {
		return []rune("█")
	}
	if strings.Contains(sym, "block") {
		return []rune(" ░▒▓█")
	}
	if strings.Contains(sym, "braille") {
		return []rune("⠀⡀⣀⣤⣶⣿")
	}
	if strings.Contains(sym, "ascii") || sym == "" {
		return []rune(" .'`^\",:;Il!i><~+_-?][}{1)(|\\//*tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@")
	}
	return []rune(" ░▒▓█@")
}

func sample(img image.Image, b image.Rectangle, ox, oy, ow, oh int) (uint8, uint8, uint8, uint8) {
	x0 := b.Min.X + ox*b.Dx()/ow
	x1 := b.Min.X + (ox+1)*b.Dx()/ow
	y0 := b.Min.Y + oy*b.Dy()/oh
	y1 := b.Min.Y + (oy+1)*b.Dy()/oh
	if x1 <= x0 {
		x1 = x0 + 1
	}
	if y1 <= y0 {
		y1 = y0 + 1
	}
	var rs, gs, bs, as uint64
	var n uint64
	for y := y0; y < y1; y++ {
		for x := x0; x < x1; x++ {
			rr, gg, bb, aa := img.At(clamp(x, b.Min.X, b.Max.X-1), clamp(y, b.Min.Y, b.Max.Y-1)).RGBA()
			rs += uint64(rr >> 8)
			gs += uint64(gg >> 8)
			bs += uint64(bb >> 8)
			as += uint64(aa >> 8)
			n++
		}
	}
	if n == 0 {
		return 0, 0, 0, 0
	}
	return uint8(rs / n), uint8(gs / n), uint8(bs / n), uint8(as / n)
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func ansiColor(r, g, b uint8, mode string) string {
	if mode == "full" || mode == "" {
		return fmt.Sprintf("\033[38;2;%d;%d;%dm", r, g, b)
	}
	if mode == "8" || mode == "16" || mode == "16/8" {
		return fmt.Sprintf("\033[%dm", 30+nearest8(r, g, b))
	}
	return fmt.Sprintf("\033[38;5;%dm", nearest256(r, g, b))
}

func nearest8(r, g, b uint8) int {
	colors := []color.RGBA{{0, 0, 0, 255}, {170, 0, 0, 255}, {0, 170, 0, 255}, {170, 85, 0, 255}, {0, 0, 170, 255}, {170, 0, 170, 255}, {0, 170, 170, 255}, {170, 170, 170, 255}}
	best, bd := 0, math.MaxFloat64
	for i, c := range colors {
		d := dist(r, g, b, c.R, c.G, c.B)
		if d < bd {
			best, bd = i, d
		}
	}
	return best
}
func nearest256(r, g, b uint8) int { return 16 + 36*int(r)/256*6 + 6*int(g)/256*6 + int(b)/256*6 }
func dist(r, g, b, cr, cg, cb uint8) float64 {
	dr := float64(r) - float64(cr)
	dg := float64(g) - float64(cg)
	db := float64(b) - float64(cb)
	return dr*dr + dg*dg + db*db
}

func errString(err error) string {
	if err == nil {
		return ""
	}
	if errors.Is(err, os.ErrNotExist) {
		return "No such file or directory"
	}
	if strings.Contains(err.Error(), "unknown format") {
		return "Unrecognized image format"
	}
	return err.Error()
}
