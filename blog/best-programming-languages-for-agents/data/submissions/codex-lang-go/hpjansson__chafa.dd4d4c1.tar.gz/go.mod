module chafa-reimpl

go 1.21
