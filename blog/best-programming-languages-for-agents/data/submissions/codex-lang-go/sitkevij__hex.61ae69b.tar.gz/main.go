package main

import (
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
)

type options struct {
	cols      int
	limit     int
	limitSet  bool
	format    string
	color     *bool
	array     string
	funcLen   int
	funcSet   bool
	places    int
	prefix    bool
	inputFile string
}

const helpText = `Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
`

func main() {
	opt, code := parseArgs(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}

	if opt.funcSet {
		printFunc(opt.funcLen, opt.places)
		return
	}

	data, err := readInput(opt.inputFile)
	if err != nil {
		if os.IsNotExist(err) {
			fmt.Fprintln(os.Stderr, "error: No such file or directory (os error 2)")
		} else {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
		}
		os.Exit(1)
	}
	if opt.limitSet && opt.limit > 0 && opt.limit < len(data) {
		data = data[:opt.limit]
	}

	if opt.array != "" {
		printArray(data, opt.array, opt.cols)
		return
	}

	useColor := false
	if opt.color != nil {
		useColor = *opt.color
	}
	printDump(data, opt, useColor)
}

func defaultOptions() options {
	return options{cols: 10, format: "x", places: 4, prefix: true}
}

func parseArgs(args []string) (options, int) {
	opt := defaultOptions()
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			fmt.Print(helpText)
			return opt, 0
		}
		if a == "-V" || a == "--version" {
			fmt.Println("hx 0.7.0")
			return opt, 0
		}
		if a == "--" {
			i++
			if i < len(args) {
				opt.inputFile = args[i]
				i++
			}
			if i < len(args) {
				unexpected(args[i])
				return opt, 2
			}
			break
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasEq := strings.Cut(a, "=")
			switch name {
			case "--cols", "--len", "--format", "--color", "--array", "--func", "--places", "--prefix":
				if !hasEq {
					i++
					if i >= len(args) {
						fmt.Fprintf(os.Stderr, "error: a value is required for '%s <value>' but none was supplied\n\nFor more information, try '--help'.\n", name)
						return opt, 2
					}
					val = args[i]
				}
				if code := setOpt(&opt, name, val); code >= 0 {
					return opt, code
				}
			default:
				unexpected(a)
				return opt, 2
			}
			continue
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			short := a[1:]
			key := short[:1]
			val := ""
			if len(short) > 1 {
				val = short[1:]
			} else {
				i++
				if i >= len(args) {
					fmt.Fprintf(os.Stderr, "error: a value is required for '-%s <value>' but none was supplied\n\nFor more information, try '--help'.\n", key)
					return opt, 2
				}
				val = args[i]
			}
			long := map[string]string{"c": "--cols", "l": "--len", "f": "--format", "t": "--color", "a": "--array", "u": "--func", "p": "--places", "r": "--prefix"}[key]
			if long == "" {
				unexpected(a)
				return opt, 2
			}
			if code := setOpt(&opt, long, val); code >= 0 {
				return opt, code
			}
			continue
		}
		if opt.inputFile == "" {
			opt.inputFile = a
		} else {
			unexpected(a)
			return opt, 2
		}
	}
	return opt, -1
}

func setOpt(opt *options, name, val string) int {
	switch name {
	case "--cols":
		n, err := strconv.Atoi(val)
		if err != nil {
			fmt.Fprintln(os.Stderr, "-c, --cols <integer> expected. ParseIntError { kind: InvalidDigit }")
			fmt.Fprintln(os.Stderr, "error: invalid digit found in string")
			return 1
		}
		if n <= 0 {
			n = 1
		}
		opt.cols = n
	case "--len":
		n, err := strconv.Atoi(val)
		if err != nil {
			fmt.Fprintln(os.Stderr, "-l, --len <integer> expected. ParseIntError { kind: InvalidDigit }")
			fmt.Fprintln(os.Stderr, "error: invalid digit found in string")
			return 1
		}
		opt.limit, opt.limitSet = n, true
	case "--format":
		if !strings.Contains("oxXb", val) || len(val) != 1 {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--format <format>'\n  [possible values: o, x, X, b]\n\nFor more information, try '--help'.\n", val)
			return 2
		}
		opt.format = val
	case "--color":
		if val != "0" && val != "1" {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--color <color>'\n  [possible values: 0, 1]\n\nFor more information, try '--help'.\n", val)
			return 2
		}
		b := val == "1"
		opt.color = &b
	case "--array":
		if !strings.Contains("rcgpkjsf", val) || len(val) != 1 {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--array <array_format>'\n  [possible values: r, c, g, p, k, j, s, f]\n\nFor more information, try '--help'.\n", val)
			return 2
		}
		opt.array = val
	case "--func":
		n, err := strconv.Atoi(val)
		if err != nil {
			fmt.Fprintln(os.Stderr, "-u, --func <integer> expected. ParseIntError { kind: InvalidDigit }")
			fmt.Fprintln(os.Stderr, "error: invalid digit found in string")
			return 1
		}
		opt.funcLen, opt.funcSet = n, true
	case "--places":
		n, err := strconv.Atoi(val)
		if err == nil {
			opt.places = n
		}
	case "--prefix":
		if val != "0" && val != "1" {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--prefix <prefix>'\n  [possible values: 0, 1]\n\nFor more information, try '--help'.\n", val)
			return 2
		}
		opt.prefix = val == "1"
	}
	return -1
}

func unexpected(arg string) {
	if strings.HasPrefix(arg, "--") {
		fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.\n", arg, arg, arg)
	} else {
		fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.\n", arg)
	}
}

func readInput(path string) ([]byte, error) {
	if path != "" {
		return os.ReadFile(path)
	}
	return io.ReadAll(os.Stdin)
}

func token(b byte, format string, prefix bool) string {
	switch format {
	case "o":
		if prefix {
			return fmt.Sprintf("0o%04o", b)
		}
		return fmt.Sprintf("%04o", b)
	case "X":
		if prefix {
			return fmt.Sprintf("0x%02X", b)
		}
		return fmt.Sprintf("%02X", b)
	case "b":
		if prefix {
			return fmt.Sprintf("0b%08b", b)
		}
		return fmt.Sprintf("%08b", b)
	default:
		if prefix {
			return fmt.Sprintf("0x%02x", b)
		}
		return fmt.Sprintf("%02x", b)
	}
}

func cellWidth(format string, prefix bool) int {
	return len(token(0, format, prefix)) + 1
}

func printable(b byte) string {
	if b >= 32 && b <= 126 {
		return string([]byte{b})
	}
	return "."
}

func colorize(b byte, s string) string {
	c := int(b)
	if c == 0 {
		c = 22
	}
	return fmt.Sprintf("\033[38;5;%dm%s\033[0m", c, s)
}

func printDump(data []byte, opt options, useColor bool) {
	cols := opt.cols
	rows := 1
	if len(data) > 0 {
		rows = (len(data) + cols - 1) / cols
		if len(data)%cols == 0 && len(data) >= cols && cols <= 3 {
			rows++
		}
	}
	for r := 0; r < rows; r++ {
		start := r * cols
		end := start + cols
		if end > len(data) {
			end = len(data)
		}
		fmt.Printf("0x%06x: ", start)
		for i := start; i < end; i++ {
			s := token(data[i], opt.format, opt.prefix)
			if useColor {
				s = colorize(data[i], s)
			}
			fmt.Print(s, " ")
		}
		for i := end - start; i < cols; i++ {
			fmt.Print(strings.Repeat(" ", 5))
		}
		for i := start; i < end; i++ {
			s := printable(data[i])
			if useColor {
				s = colorize(data[i], s)
			}
			fmt.Print(s)
		}
		fmt.Println()
	}
	fmt.Printf("   bytes: %d\n", len(data))
}

func hexVal(b byte) string {
	return fmt.Sprintf("0x%02x", b)
}

func printArray(data []byte, kind string, cols int) {
	switch kind {
	case "r":
		fmt.Printf("let ARRAY: [u8; %d] = [\n", len(data))
		arrayBody(data, cols, ", ", "", false)
		fmt.Println("];")
	case "c":
		fmt.Printf("unsigned char ARRAY[%d] = {\n", len(data))
		arrayBody(data, cols, ", ", "", false)
		fmt.Println("};")
	case "g":
		fmt.Printf("a := [%d]byte{\n", len(data))
		arrayBody(data, cols, ", ", "", true)
		fmt.Println("}")
	case "p":
		fmt.Println("a = [")
		arrayBody(data, cols, ", ", "", false)
		fmt.Println("]")
	case "k":
		fmt.Println("val a = byteArrayOf(")
		arrayBody(data, cols, ", ", "", false)
		fmt.Println(")")
	case "j":
		fmt.Println("byte[] a = new byte[]{")
		arrayBody(data, cols, ", ", "", false)
		fmt.Println("};")
	case "s":
		fmt.Println("let a: [UInt8] = [")
		arrayBody(data, cols, ", ", "", false)
		fmt.Println("]")
	case "f":
		fmt.Println("let a = [|")
		arrayBody(data, cols, "; ", "uy", false)
		fmt.Println("|]")
	}
}

func arrayBody(data []byte, cols int, sep, suffix string, alwaysTrail bool) {
	rows := 0
	if len(data) > 0 {
		rows = (len(data) + cols - 1) / cols
		if len(data)%cols == 0 && len(data) >= cols {
			rows++
		}
	}
	for r := 0; r < rows; r++ {
		start := r * cols
		end := start + cols
		if end > len(data) {
			end = len(data)
		}
		fmt.Print("    ")
		for i := start; i < end; i++ {
			fmt.Print(hexVal(data[i]), suffix)
			if alwaysTrail || i != len(data)-1 {
				fmt.Print(sep)
			}
		}
		fmt.Println()
	}
}

func printFunc(n, places int) {
	if n <= 0 {
		fmt.Println()
		return
	}
	format := "%." + strconv.Itoa(places) + "f,"
	for i := 0; i < n; i++ {
		fmt.Printf(format, math.Sin(float64(i)*math.Pi/float64(2*n)))
		if (i+1)%10 == 0 {
			fmt.Println()
		}
	}
	fmt.Println()
}
