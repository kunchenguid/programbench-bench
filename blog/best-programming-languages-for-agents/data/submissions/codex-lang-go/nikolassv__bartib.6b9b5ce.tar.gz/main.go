package main

import (
	"bufio"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "bartib 1.1.0"

type Activity struct {
	Start       time.Time
	Stop        *time.Time
	Project     string
	Description string
	Raw         string
	Line        int
}

type BadLine struct {
	Line int
	Text string
}

func main() {
	if len(os.Args) == 1 {
		printMainHelp()
		return
	}
	file, args, ok := parseGlobal(os.Args[1:])
	if !ok {
		os.Exit(1)
	}
	if len(args) == 0 {
		printMainHelp()
		return
	}
	cmd := args[0]
	if cmd == "-h" || cmd == "--help" || cmd == "help" {
		if len(args) > 1 {
			printSubHelp(args[1])
		} else {
			printMainHelp()
		}
		return
	}
	if cmd == "-V" || cmd == "--version" {
		fmt.Println(version)
		return
	}
	if needsFile(cmd) && file == "" {
		fmt.Fprintln(os.Stderr, "Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable")
		os.Exit(1)
	}
	if err := dispatch(cmd, args[1:], file); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func parseGlobal(args []string) (string, []string, bool) {
	file := os.Getenv("BARTIB_FILE")
	out := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-f", "--file":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "error: The argument '-f <FILE>' requires a value but none was supplied")
				return "", nil, false
			}
			file = args[i+1]
			i++
		default:
			out = append(out, args[i:]...)
			return file, out, true
		}
	}
	return file, out, true
}

func needsFile(cmd string) bool {
	switch cmd {
	case "start", "stop", "cancel", "change", "check", "continue", "current", "edit", "last", "list", "projects", "report", "sanity", "search", "status":
		return true
	}
	return false
}

func dispatch(cmd string, args []string, file string) error {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			printSubHelp(cmd)
			return nil
		}
	}
	switch cmd {
	case "start":
		return cmdStart(args, file)
	case "stop":
		return cmdStop(args, file)
	case "cancel":
		return cmdCancel(file)
	case "change":
		return cmdChange(args, file)
	case "continue":
		return cmdContinue(args, file)
	case "current":
		acts, _, _ := readActivities(file)
		printCurrent(runningOnly(acts))
	case "check":
		_, bad, err := readActivities(file)
		if err != nil {
			return err
		}
		if len(bad) == 0 {
			fmt.Println("All lines in the file have been successfully parsed as activities.")
		} else {
			fmt.Printf("Found %d line(s) with parsing errors\n\n", len(bad))
			for _, b := range bad {
				fmt.Println(b.Text)
				fmt.Printf("  -> could not parse activity (Line: %d)\n", b.Line)
			}
		}
	case "sanity":
		fmt.Println("No unusual activities.")
	case "last":
		return cmdLast(args, file)
	case "list":
		return cmdList(args, file)
	case "projects":
		return cmdProjects(args, file)
	case "report":
		return cmdReport(args, file)
	case "search":
		return cmdSearch(args, file)
	case "status":
		return cmdStatus(args, file)
	case "edit":
		return cmdEdit(args, file)
	default:
		printMainHelp()
	}
	return nil
}

func readActivities(path string) ([]Activity, []BadLine, error) {
	f, err := os.Open(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil, nil, nil
	}
	if err != nil {
		return nil, nil, err
	}
	defer f.Close()
	var acts []Activity
	var bad []BadLine
	sc := bufio.NewScanner(f)
	line := 0
	for sc.Scan() {
		line++
		txt := sc.Text()
		if strings.TrimSpace(txt) == "" {
			continue
		}
		a, err := parseActivity(txt)
		if err != nil {
			bad = append(bad, BadLine{line, txt})
			continue
		}
		a.Raw = txt
		a.Line = line
		acts = append(acts, a)
	}
	return acts, bad, sc.Err()
}

func parseActivity(s string) (Activity, error) {
	parts := strings.Split(s, " | ")
	if len(parts) != 3 {
		return Activity{}, errors.New("bad fields")
	}
	var a Activity
	a.Project = parts[1]
	a.Description = parts[2]
	if strings.Contains(parts[0], " - ") {
		ts := strings.SplitN(parts[0], " - ", 2)
		start, err := time.ParseInLocation("2006-01-02 15:04", ts[0], time.Local)
		if err != nil {
			return a, err
		}
		stop, err := time.ParseInLocation("2006-01-02 15:04", ts[1], time.Local)
		if err != nil {
			return a, err
		}
		a.Start = start
		a.Stop = &stop
	} else {
		start, err := time.ParseInLocation("2006-01-02 15:04", parts[0], time.Local)
		if err != nil {
			return a, err
		}
		a.Start = start
	}
	return a, nil
}

func writeActivities(path string, acts []Activity) error {
	var b strings.Builder
	for _, a := range acts {
		if a.Stop == nil {
			fmt.Fprintf(&b, "%s | %s | %s\n", a.Start.Format("2006-01-02 15:04"), a.Project, a.Description)
		} else {
			fmt.Fprintf(&b, "%s - %s | %s | %s\n", a.Start.Format("2006-01-02 15:04"), a.Stop.Format("2006-01-02 15:04"), a.Project, a.Description)
		}
	}
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func appendActivity(path string, a Activity) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = fmt.Fprintf(f, "%s | %s | %s\n", a.Start.Format("2006-01-02 15:04"), a.Project, a.Description)
	return err
}

func parseWhen(v string) (time.Time, error) {
	now := time.Now()
	if v == "" {
		return now.Truncate(time.Minute), nil
	}
	if t, err := time.ParseInLocation("15:04", v, time.Local); err == nil {
		return time.Date(now.Year(), now.Month(), now.Day(), t.Hour(), t.Minute(), 0, 0, time.Local), nil
	}
	return time.ParseInLocation("2006-01-02 15:04", v, time.Local)
}

func cmdStart(args []string, path string) error {
	fs := flag.NewFlagSet("start", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	desc := fs.String("description", "", "")
	proj := fs.String("project", "", "")
	tm := fs.String("time", "", "")
	fs.StringVar(desc, "d", "", "")
	fs.StringVar(proj, "p", "", "")
	fs.StringVar(tm, "t", "", "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *desc == "" || *proj == "" {
		return errors.New("The following required arguments were not provided: --description <DESCRIPTION>, --project <PROJECT>")
	}
	when, err := parseWhen(*tm)
	if err != nil {
		return err
	}
	a := Activity{Start: when, Project: *proj, Description: *desc}
	if err := appendActivity(path, a); err != nil {
		return err
	}
	fmt.Printf("Started activity: %q (%s) at %s\n", *desc, *proj, when.Format("2006-01-02 15:04"))
	return nil
}

func cmdStop(args []string, path string) error {
	fs := flag.NewFlagSet("stop", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	tm := fs.String("time", "", "")
	fs.StringVar(tm, "t", "", "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	when, err := parseWhen(*tm)
	if err != nil {
		return err
	}
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	count := 0
	for i := range acts {
		if acts[i].Stop == nil {
			stop := when
			acts[i].Stop = &stop
			count++
			fmt.Printf("Stopped activity: %q (%s) started at %s (%s)\n", acts[i].Description, acts[i].Project, acts[i].Start.Format("2006-01-02 15:04"), durString(stop.Sub(acts[i].Start)))
		}
	}
	if count == 0 {
		fmt.Println("No Activity is currently running")
		return nil
	}
	return writeActivities(path, acts)
}

func cmdCancel(path string) error {
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	var kept []Activity
	for _, a := range acts {
		if a.Stop != nil {
			kept = append(kept, a)
		}
	}
	if len(kept) == len(acts) {
		fmt.Println("No Activity is currently running")
	} else {
		fmt.Println("Cancelled all running activities")
	}
	return writeActivities(path, kept)
}

func cmdChange(args []string, path string) error {
	fs := flag.NewFlagSet("change", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	desc := fs.String("description", "", "")
	proj := fs.String("project", "", "")
	tm := fs.String("time", "", "")
	fs.StringVar(desc, "d", "", "")
	fs.StringVar(proj, "p", "", "")
	fs.StringVar(tm, "t", "", "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	when, err := parseWhen(*tm)
	if err != nil {
		return err
	}
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	for i := range acts {
		if acts[i].Stop == nil {
			acts = append(acts[:i], acts[i+1:]...)
			break
		}
	}
	a := Activity{Start: when, Project: *proj, Description: *desc}
	acts = append(acts, a)
	if err := writeActivities(path, acts); err != nil {
		return err
	}
	fmt.Printf("Changed activity: %q (%s) started at %s\n", a.Description, a.Project, when.Format("2006-01-02 15:04"))
	return nil
}

func cmdContinue(args []string, path string) error {
	fs := flag.NewFlagSet("continue", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	desc := fs.String("description", "", "")
	proj := fs.String("project", "", "")
	tm := fs.String("time", "", "")
	fs.StringVar(desc, "d", "", "")
	fs.StringVar(proj, "p", "", "")
	fs.StringVar(tm, "t", "", "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	n := 0
	if fs.NArg() > 0 {
		v, err := strconv.Atoi(fs.Arg(0))
		if err == nil {
			n = v
		}
	}
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	recent := uniqueRecent(acts, "")
	if n < 0 || n >= len(recent) {
		return errors.New("activity number out of range")
	}
	if *desc == "" {
		*desc = recent[n].Description
	}
	if *proj == "" {
		*proj = recent[n].Project
	}
	when, err := parseWhen(*tm)
	if err != nil {
		return err
	}
	a := Activity{Start: when, Project: *proj, Description: *desc}
	if err := appendActivity(path, a); err != nil {
		return err
	}
	fmt.Printf("Started activity: %q (%s) at %s\n", *desc, *proj, when.Format("2006-01-02 15:04"))
	return nil
}

func cmdLast(args []string, path string) error {
	fs := flag.NewFlagSet("last", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	num := fs.Int("number", 10, "")
	fs.IntVar(num, "n", 10, "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	recent := uniqueRecent(acts, "")
	if len(recent) == 0 {
		fmt.Println("No activities have been tracked yet")
		return nil
	}
	if *num < len(recent) {
		recent = recent[:*num]
	}
	fmt.Println("\033[4m # \033[0m \033[4mDescription\033[0m \033[4mProject\033[0m ")
	for i, a := range recent {
		fmt.Printf("[%d] %-11s %s  \n", i, a.Description, a.Project)
	}
	return nil
}

func cmdSearch(args []string, path string) error {
	if len(args) == 0 {
		args = []string{""}
	}
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	recent := uniqueRecent(acts, strings.ToLower(args[0]))
	if len(recent) == 0 {
		fmt.Println("No activities have been tracked yet")
		return nil
	}
	fmt.Println("\033[4m # \033[0m \033[4mDescription\033[0m \033[4mProject\033[0m ")
	for i, a := range recent {
		fmt.Printf("[%d] %-11s %s  \n", i, a.Description, a.Project)
	}
	return nil
}

func uniqueRecent(acts []Activity, term string) []Activity {
	seen := map[string]bool{}
	var out []Activity
	for i := len(acts) - 1; i >= 0; i-- {
		a := acts[i]
		key := a.Description + "\x00" + a.Project
		if seen[key] {
			continue
		}
		if term != "" && !strings.Contains(strings.ToLower(a.Description), term) && !strings.Contains(strings.ToLower(a.Project), term) {
			continue
		}
		seen[key] = true
		out = append(out, a)
	}
	return out
}

func cmdProjects(args []string, path string) error {
	current := false
	noQuotes := false
	for _, a := range args {
		if a == "-c" || a == "--current" {
			current = true
		}
		if a == "-n" || a == "--no-quotes" {
			noQuotes = true
		}
	}
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	set := map[string]bool{}
	for _, a := range acts {
		if current && a.Stop != nil {
			continue
		}
		set[a.Project] = true
	}
	var ps []string
	for p := range set {
		ps = append(ps, p)
	}
	sort.Strings(ps)
	for _, p := range ps {
		if noQuotes {
			fmt.Println(p)
		} else {
			fmt.Printf("%q\n", p)
		}
	}
	return nil
}

func cmdList(args []string, path string) error {
	opts := parseFilters(args)
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	acts = filterActivities(acts, opts)
	if opts.number > 0 && opts.number < len(acts) {
		acts = acts[len(acts)-opts.number:]
	}
	if len(acts) == 0 {
		fmt.Println("No activity to display")
		return nil
	}
	if opts.noGrouping {
		fmt.Println("\033[4mStarted          \033[0m \033[4mStopped\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m ")
		for _, a := range acts {
			printListLine(a, true)
		}
		return nil
	}
	fmt.Println("\033[4mStarted\033[0m \033[4mStopped\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m ")
	var last string
	for _, a := range acts {
		day := a.Start.Format("2006-01-02")
		if day != last {
			fmt.Printf("\n\033[1m%s\t%s\033[0m\n", day, durString(sumDay(acts, day)))
			last = day
		}
		printListLine(a, false)
	}
	return nil
}

func printListLine(a Activity, fullDate bool) {
	stop := "-"
	end := time.Now()
	if a.Stop != nil {
		stop = a.Stop.Format("15:04")
		end = *a.Stop
	}
	start := a.Start.Format("15:04")
	if fullDate {
		start = a.Start.Format("2006-01-02 15:04")
	}
	fmt.Printf("%-16s %-7s %-11s %-7s %-8s \n", start, stop, a.Description, a.Project, durString(end.Sub(a.Start)))
}

func cmdReport(args []string, path string) error {
	opts := parseFilters(args)
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	acts = filterActivities(acts, opts)
	type descDur map[string]time.Duration
	byProj := map[string]descDur{}
	var total time.Duration
	for _, a := range acts {
		end := time.Now()
		if a.Stop != nil {
			end = *a.Stop
		}
		d := end.Sub(a.Start)
		if d < 0 {
			d = 0
		}
		if byProj[a.Project] == nil {
			byProj[a.Project] = descDur{}
		}
		byProj[a.Project][a.Description] += d
		total += d
	}
	var projects []string
	for p := range byProj {
		projects = append(projects, p)
	}
	sort.Strings(projects)
	for _, p := range projects {
		var pd time.Duration
		for _, d := range byProj[p] {
			pd += d
		}
		fmt.Printf("\n\033[1m%s %s\033[0m\n", dotPad(p, 9), durString(pd))
		var ds []string
		for d := range byProj[p] {
			ds = append(ds, d)
		}
		sort.Strings(ds)
		for _, d := range ds {
			fmt.Printf("    %s %s\n", dotPad(d, 5), durString(byProj[p][d]))
		}
	}
	fmt.Printf("\n\033[1m%s %s\033[0m\n\n", dotPad("Total", 9), durString(total))
	return nil
}

type filters struct {
	project    string
	from, to   *time.Time
	noGrouping bool
	number     int
}

func parseFilters(args []string) filters {
	var f filters
	for i := 0; i < len(args); i++ {
		arg := args[i]
		val := func() string {
			if i+1 < len(args) {
				i++
				return args[i]
			}
			return ""
		}
		switch arg {
		case "-p", "--project":
			f.project = val()
		case "-d", "--date":
			if t, err := parseDate(val()); err == nil {
				f.from = &t
				u := t.Add(24*time.Hour - time.Nanosecond)
				f.to = &u
			}
		case "--from":
			if t, err := parseDate(val()); err == nil {
				f.from = &t
			}
		case "--to":
			if t, err := parseDate(val()); err == nil {
				u := t.Add(24*time.Hour - time.Nanosecond)
				f.to = &u
			}
		case "--today":
			t := beginning(time.Now(), 0)
			u := t.Add(24*time.Hour - time.Nanosecond)
			f.from, f.to = &t, &u
		case "--yesterday":
			t := beginning(time.Now(), -1)
			u := t.Add(24*time.Hour - time.Nanosecond)
			f.from, f.to = &t, &u
		case "--current_week":
			t := weekStart(time.Now())
			u := t.AddDate(0, 0, 7).Add(-time.Nanosecond)
			f.from, f.to = &t, &u
		case "--last_week":
			t := weekStart(time.Now()).AddDate(0, 0, -7)
			u := t.AddDate(0, 0, 7).Add(-time.Nanosecond)
			f.from, f.to = &t, &u
		case "--no_grouping":
			f.noGrouping = true
		case "-n", "--number":
			n, _ := strconv.Atoi(val())
			f.number = n
		case "--round":
			_ = val()
		}
	}
	return f
}

func parseDate(s string) (time.Time, error) {
	return time.ParseInLocation("2006-01-02", s, time.Local)
}

func beginning(t time.Time, offset int) time.Time {
	y, m, d := t.Date()
	return time.Date(y, m, d+offset, 0, 0, 0, 0, time.Local)
}

func weekStart(t time.Time) time.Time {
	b := beginning(t, 0)
	wd := int(b.Weekday())
	if wd == 0 {
		wd = 7
	}
	return b.AddDate(0, 0, -(wd - 1))
}

func filterActivities(acts []Activity, f filters) []Activity {
	var out []Activity
	for _, a := range acts {
		if f.project != "" && a.Project != f.project {
			continue
		}
		if f.from != nil && a.Start.Before(*f.from) {
			continue
		}
		if f.to != nil && a.Start.After(*f.to) {
			continue
		}
		out = append(out, a)
	}
	return out
}

func cmdStatus(args []string, path string) error {
	opts := parseFilters(args)
	acts, _, err := readActivities(path)
	if err != nil {
		return err
	}
	if opts.project != "" {
		acts = filterActivities(acts, opts)
	}
	current := runningOnly(acts)
	name := "ALL"
	if opts.project != "" {
		name = opts.project
	}
	fmt.Printf("\033[2m\n =======\033[0m\033[3m Status for \033[0m\033[1m%s\033[0m\033[3m projects \033[0m\033[2m ======= \n\033[0m", name)
	if len(current) == 0 {
		fmt.Print("\033[2;3m\n  NOW: \033[0m\033[1m NO Activity\n\n\033[0m")
	} else {
		fmt.Print("\033[2;3m\n  NOW: \033[0m")
		for _, a := range current {
			fmt.Printf("\033[1m%s (%s)\033[0m ", a.Description, a.Project)
		}
		fmt.Println()
	}
	now := time.Now()
	today := beginning(now, 0)
	week := weekStart(now)
	month := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.Local)
	fmt.Printf("\033[3m \033[0m\033[2;3m Today......................... \033[0m\033[1m%s\033[0m\033[3m\n", durString(sumSince(acts, today)))
	fmt.Printf("\033[0m\033[3m \033[0m\033[2;3m Current week.................. \033[0m\033[1m%s\033[0m\033[3m\n", durString(sumSince(acts, week)))
	fmt.Printf("\033[0m\033[3m \033[0m\033[2;3m Current month................. \033[0m\033[1m%s\033[0m\033[3m\n\033[0m", durString(sumSince(acts, month)))
	return nil
}

func cmdEdit(args []string, path string) error {
	editor := os.Getenv("EDITOR")
	for i := 0; i < len(args); i++ {
		if (args[i] == "-e" || args[i] == "--editor") && i+1 < len(args) {
			editor = args[i+1]
		}
	}
	if editor == "" {
		return errors.New("No editor specified")
	}
	c := exec.Command(editor, path)
	c.Stdin = os.Stdin
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	return c.Run()
}

func runningOnly(acts []Activity) []Activity {
	var out []Activity
	for _, a := range acts {
		if a.Stop == nil {
			out = append(out, a)
		}
	}
	return out
}

func printCurrent(acts []Activity) {
	if len(acts) == 0 {
		fmt.Println("No Activity is currently running")
		return
	}
	fmt.Println("\033[4mStarted At      \033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m ")
	for _, a := range acts {
		fmt.Printf("%s %-11s %-7s %-8s \n", a.Start.Format("2006-01-02 15:04"), a.Description, a.Project, durString(time.Since(a.Start)))
	}
}

func sumDay(acts []Activity, day string) time.Duration {
	var d time.Duration
	for _, a := range acts {
		if a.Start.Format("2006-01-02") == day {
			end := time.Now()
			if a.Stop != nil {
				end = *a.Stop
			}
			d += end.Sub(a.Start)
		}
	}
	return d
}

func sumSince(acts []Activity, since time.Time) time.Duration {
	var d time.Duration
	for _, a := range acts {
		if a.Start.Before(since) {
			continue
		}
		end := time.Now()
		if a.Stop != nil {
			end = *a.Stop
		}
		d += end.Sub(a.Start)
	}
	return d
}

func durString(d time.Duration) string {
	if d < 0 {
		d = 0
	}
	mins := int(d.Minutes())
	if mins <= 0 {
		return "<1m"
	}
	h := mins / 60
	m := mins % 60
	if h > 0 {
		return fmt.Sprintf("%dh %02dm", h, m)
	}
	return fmt.Sprintf("%dm", m)
}

func dotPad(s string, width int) string {
	if len(s) >= width {
		return s
	}
	return s + strings.Repeat(".", width-len(s))
}

func printMainHelp() {
	fmt.Println(`bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run ` + "`bartib [SUBCOMMAND] --help`" + `.
To get started, view the ` + "`start`" + ` help with ` + "`bartib start --help`" + ``)
}

func printSubHelp(s string) {
	helps := map[string]string{
		"start": `executable-start 
starts a new activity

USAGE:
    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)`,
		"stop": `executable-stop 
stops all currently running activities

USAGE:
    executable stop [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -t, --time <TIME>    the time for changing the activity status (HH:MM)`,
		"cancel": `executable-cancel 
cancels all currently running activities

USAGE:
    executable cancel

FLAGS:
    -h, --help    Prints help information`,
		"change": `executable-change 
changes the current activity

USAGE:
    executable change [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)`,
		"check": `executable-check 
checks file and reports parsing errors

USAGE:
    executable check

FLAGS:
    -h, --help    Prints help information`,
		"continue": `executable-continue 
continues a previous activity

USAGE:
    executable continue [OPTIONS] [NUMBER]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)

ARGS:
    <NUMBER>    the number of the activity to continue (see subcommand ` + "`last`" + `) [default: 0]`,
		"current": `executable-current 
lists all currently running activities

USAGE:
    executable current

FLAGS:
    -h, --help    Prints help information`,
		"edit": `executable-edit 
opens the activity log in an editor

USAGE:
    executable edit [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -e <editor>        the command to start your preferred text editor [env: EDITOR=]`,
		"last": `executable-last 
displays the descriptions and projects of recent activities

USAGE:
    executable last [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -n, --number <NUMBER>    maximum number of lines to display [default: 10]`,
		"list": `executable-list 
list recent activities

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --no_grouping     do not group activities by date in list
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -n, --number <NUMBER>      maximum number of activities to display
    -p, --project <PROJECT>    do list activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)`,
		"projects": `executable-projects 
list all projects

USAGE:
    executable projects [FLAGS]

FLAGS:
    -c, --current      prints currently running projects only
    -h, --help         Prints help information
    -n, --no-quotes    prints projects without quotes`,
		"report": `executable-report 
reports duration of tracked activities

USAGE:
    executable report [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -p, --project <PROJECT>    do report activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)`,
		"sanity": `executable-sanity 
checks sanity of bartib log

USAGE:
    executable sanity

FLAGS:
    -h, --help    Prints help information`,
		"search": `executable-search 
search for existing descriptions and projects

USAGE:
    executable search <SEARCH_TERM>

FLAGS:
    -h, --help    Prints help information

ARGS:
    <SEARCH_TERM>    the search term [default: '']`,
		"status": `executable-status 
shows current status and time reports for today, current week, and current month

USAGE:
    executable status [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -p, --project <PROJECT>    show status for this project only`,
	}
	if h, ok := helps[s]; ok {
		fmt.Println(h)
		return
	}
	printMainHelp()
}
