module bartib-reimpl

go 1.21
