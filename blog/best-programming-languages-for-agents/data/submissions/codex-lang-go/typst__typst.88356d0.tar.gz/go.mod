module typstclone

go 1.21
