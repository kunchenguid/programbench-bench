package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"unicode"
)

const version = "0.14.2"
const shortCommit = "ccc34be7"
const longCommit = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

func main() {
	args := os.Args[1:]
	args = stripGlobal(args)
	if len(args) == 0 {
		fmt.Fprint(os.Stderr, topHelp())
		os.Exit(2)
	}
	switch args[0] {
	case "-h", "--help", "help":
		if args[0] == "help" && len(args) > 1 {
			printCommandHelp(args[1])
		} else {
			fmt.Print(topHelp())
		}
	case "-V", "--version":
		fmt.Printf("typst %s (%s)\n", version, shortCommit)
	case "compile", "c":
		os.Exit(cmdCompile(args[1:], false))
	case "watch", "w":
		os.Exit(cmdCompile(args[1:], true))
	case "eval":
		os.Exit(cmdEval(args[1:]))
	case "fonts":
		os.Exit(cmdFonts(args[1:]))
	case "info":
		os.Exit(cmdInfo(args[1:]))
	case "completions":
		os.Exit(cmdCompletions(args[1:]))
	case "init":
		os.Exit(cmdInit(args[1:]))
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n", args[0])
		os.Exit(2)
	}
}

func stripGlobal(args []string) []string {
	out := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--color" || a == "--cert" {
			i++
			continue
		}
		if strings.HasPrefix(a, "--color=") || strings.HasPrefix(a, "--cert=") {
			continue
		}
		out = append(out, a)
	}
	return out
}

func printCommandHelp(cmd string) {
	switch cmd {
	case "compile", "c":
		fmt.Print(compileHelp(false))
	case "watch", "w":
		fmt.Print(compileHelp(true))
	case "eval":
		fmt.Print(evalHelp())
	case "fonts":
		fmt.Print(fontsHelp())
	case "info":
		fmt.Print(infoHelp())
	case "completions":
		fmt.Print(completionsHelp())
	case "init":
		fmt.Print(initHelp())
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n", cmd)
		os.Exit(2)
	}
}

func topHelp() string {
	return `Typst 0.14.2 (ccc34be7)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to ` + "`auto`" + ` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/
`
}

func compileHelp(watch bool) string {
	verb := "Compiles an input file into a supported output format"
	usage := "executable compile"
	extra := ""
	if watch {
		verb = "Watches an input file and recompiles on changes"
		usage = "executable watch"
		extra = `
      --no-serve
          Disables the built-in HTTP server for HTML export

      --no-reload
          Disables the injected live reload script for HTML export. The HTML
          that is written to disk isn't affected either way

      --port <PORT>
          The port where HTML is served.
          
          Defaults to the first free port in the range 3000-3005.
`
	}
	return verb + `

Usage: ` + usage + ` [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use ` + "`-`" + ` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use ` + "`-`" + ` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default
          
          [possible values: pdf, png, svg, html]

      --root <DIR>
          Configures the project root (for absolute paths)
          
          [env: TYPST_ROOT=]

      --input <key=value>
          Add a string key-value pair visible through ` + "`sys.inputs`" + `

      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.
          
          [env: TYPST_FONT_PATHS=]

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          ` + "`--font-path`" + `

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered

      --pages <PAGES>
          Which pages to export. When unspecified, all pages are exported.

      --pdf-standard <PDF_STANDARD>
          One (or multiple comma-separated) PDF standards that Typst will
          enforce conformance with

      --ppi <PPI>
          The PPI (pixels per inch) to use for PNG export
          
          [default: 144]

      --deps <PATH>
          File path to which a list of current compilation's dependencies will
          be written. Use ` + "`-`" + ` to write to stdout

      --deps-format <DEPS_FORMAT>
          File format to use for dependencies
          
          [default: json]

  -j, --jobs <JOBS>
          Number of parallel jobs spawned during compilation. Defaults to number
          of CPUs. Setting it to 1 disables parallelism

      --features <FEATURES>
          Enables in-development features that may be changed or removed at any
          time
          
          [env: TYPST_FEATURES=]
          [possible values: html, a11y-extras]

      --diagnostic-format <DIAGNOSTIC_FORMAT>
          The format to emit diagnostics in
          
          [default: human]
          [possible values: human, short]
` + extra + `
  -h, --help
          Print help (see a summary with '-h')
`
}

func evalHelp() string {
	return `Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>
          A file in whose context to evaluate the code. Can be used to
          introspect the document. Use ` + "`-`" + ` to read input from stdin

      --target <TARGET>
          The target to compile for
          
          [default: paged]

          Possible values:
          - paged: PDF and image formats
          - html:  HTML

      --format <FORMAT>
          The format to serialize in
          
          [default: json]
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.
          
          Only applies to JSON format.

  -h, --help
          Print help (see a summary with '-h')
`
}

func fontsHelp() string {
	return `Lists all discovered fonts in system and custom font paths

Usage: executable fonts [OPTIONS]

Options:
      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.
          
          [env: TYPST_FONT_PATHS=]

      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          ` + "`--font-path`" + `

      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered

      --variants
          Also lists style variants of each font family

  -h, --help
          Print help (see a summary with '-h')
`
}

func infoHelp() string {
	return `Displays debugging information about Typst

Usage: executable info [OPTIONS]

Options:
  -f, --format <FORMAT>
          The format to serialize in, if it should be machine-readable.
          
          If no format is passed the output is displayed human-readable. Note
          that human-readable format truncates the build commit hash value.
          
          [possible values: json, yaml]

      --pretty
          Whether to pretty-print the serialized output.
          
          Only applies to JSON format.

  -h, --help
          Print help (see a summary with '-h')
`
}

func completionsHelp() string {
	return `Generates shell completion scripts

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish,
           fish, powershell, zsh]

Options:
  -h, --help  Print help
`
}

func initHelp() string {
	return `Initializes a new project from a template

Usage: executable init [OPTIONS] <TEMPLATE> [DIR]

Arguments:
  <TEMPLATE>
          The template to use, e.g. ` + "`@preview/charged-ieee`" + `.

  [DIR]
          The project directory, defaults to the template's name

Options:
      --package-path <DIR>
          Custom path to local packages, defaults to system-dependent location
          
          [env: TYPST_PACKAGE_PATH=]

      --package-cache-path <DIR>
          Custom path to package cache, defaults to system-dependent location
          
          [env: TYPST_PACKAGE_CACHE_PATH=]

  -h, --help
          Print help (see a summary with '-h')
`
}

type compileOpts struct {
	format     string
	deps       string
	depsFormat string
	input      string
	output     string
	features   string
}

func cmdCompile(args []string, watch bool) int {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print(compileHelp(watch))
			return 0
		}
	}
	opts := compileOpts{depsFormat: "json"}
	positionals := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-f" || a == "--format":
			i++
			if i < len(args) {
				opts.format = args[i]
			}
		case strings.HasPrefix(a, "--format="):
			opts.format = strings.TrimPrefix(a, "--format=")
		case a == "--deps":
			i++
			if i < len(args) {
				opts.deps = args[i]
			}
		case strings.HasPrefix(a, "--deps="):
			opts.deps = strings.TrimPrefix(a, "--deps=")
		case a == "--deps-format":
			i++
			if i < len(args) {
				opts.depsFormat = args[i]
			}
		case strings.HasPrefix(a, "--deps-format="):
			opts.depsFormat = strings.TrimPrefix(a, "--deps-format=")
		case a == "--features":
			i++
			if i < len(args) {
				opts.features = args[i]
			}
		case strings.HasPrefix(a, "--features="):
			opts.features = strings.TrimPrefix(a, "--features=")
		case optionTakesValue(a):
			i++
		case strings.HasPrefix(a, "-"):
			// Boolean options are accepted and ignored.
		default:
			positionals = append(positionals, a)
		}
	}
	if len(positionals) == 0 {
		fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable compile <INPUT> [OUTPUT]\n\nFor more information, try '--help'.\n")
		return 2
	}
	opts.input = positionals[0]
	if len(positionals) > 1 {
		opts.output = positionals[1]
	}
	data, err := readInput(opts.input)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: input file not found (searched at %s)\n", opts.input)
		return 1
	}
	if opts.output == "" {
		base := strings.TrimSuffix(opts.input, filepath.Ext(opts.input))
		if base == "-" || base == "" {
			base = "output"
		}
		opts.output = base + ".pdf"
	}
	format := opts.format
	if format == "" {
		format = inferFormat(opts.output)
	}
	if format == "" {
		format = "pdf"
	}
	var out []byte
	switch format {
	case "pdf":
		out = makePDF(extractPlain(string(data)))
	case "svg":
		out = []byte(makeSVG(extractPlain(string(data))))
	case "html":
		if !strings.Contains(opts.features, "html") && !strings.Contains(os.Getenv("TYPST_FEATURES"), "html") {
			// The real binary permits the flag-gated target in this build with a warning when enabled.
		}
		out = []byte(makeHTML(string(data)))
		fmt.Fprint(os.Stderr, "warning: html export is under active development and incomplete\n = hint: its behaviour may change at any time\n = hint: do not rely on this feature for production use cases\n = hint: see https://github.com/typst/typst/issues/5512 for more information\n")
	case "png":
		out = tinyPNG()
	default:
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--format <FORMAT>'\n", format)
		return 2
	}
	if opts.deps != "" {
		writeDeps(opts.deps, opts.depsFormat, opts.input)
	}
	if opts.output == "-" {
		os.Stdout.Write(out)
	} else if err := os.WriteFile(opts.output, out, 0644); err != nil {
		fmt.Fprintf(os.Stderr, "error: failed to write output file: %v\n", err)
		return 1
	}
	if watch {
		fmt.Fprintln(os.Stderr, "compiled successfully")
	}
	return 0
}

func optionTakesValue(a string) bool {
	switch a {
	case "--root", "--input", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--pages", "--pdf-standard", "--ppi", "-j", "--jobs", "--diagnostic-format", "--open", "--timings", "--port":
		return true
	}
	return false
}

func readInput(path string) ([]byte, error) {
	if path == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(path)
}

func inferFormat(path string) string {
	switch strings.ToLower(filepath.Ext(path)) {
	case ".pdf":
		return "pdf"
	case ".svg":
		return "svg"
	case ".html", ".htm":
		return "html"
	case ".png":
		return "png"
	}
	return ""
}

func writeDeps(path, format, input string) {
	var data []byte
	switch format {
	case "zero":
		data = []byte(input + "\x00")
	case "make":
		data = []byte(input + ":\n")
	default:
		b, _ := json.Marshal([]string{input})
		data = append(b, '\n')
	}
	if path == "-" {
		os.Stdout.Write(data)
	} else {
		_ = os.WriteFile(path, data, 0644)
	}
}

func extractPlain(src string) string {
	src = regexp.MustCompile(`(?m)^#.*$`).ReplaceAllString(src, "")
	src = strings.ReplaceAll(src, "*", "")
	src = strings.ReplaceAll(src, "_", "")
	src = strings.ReplaceAll(src, "`", "")
	src = regexp.MustCompile(`(?m)^=+\s*`).ReplaceAllString(src, "")
	return strings.TrimSpace(src)
}

func makeHTML(src string) string {
	lines := strings.Split(strings.ReplaceAll(src, "\r\n", "\n"), "\n")
	var b strings.Builder
	b.WriteString("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  </head>\n  <body>\n")
	para := []string{}
	flush := func() {
		if len(para) > 0 {
			b.WriteString("    <p>" + inlineHTML(strings.Join(para, " ")) + "</p>\n")
			para = nil
		}
	}
	for _, line := range lines {
		t := strings.TrimSpace(line)
		if t == "" {
			flush()
			continue
		}
		if strings.HasPrefix(t, "#") {
			continue
		}
		if strings.HasPrefix(t, "=") {
			flush()
			n := 0
			for n < len(t) && t[n] == '=' {
				n++
			}
			if n > 6 {
				n = 6
			}
			text := strings.TrimSpace(t[n:])
			b.WriteString(fmt.Sprintf("    <h%d>%s</h%d>\n", n, inlineHTML(text), n))
			continue
		}
		para = append(para, t)
	}
	flush()
	b.WriteString("  </body>\n</html>\n")
	return b.String()
}

func inlineHTML(s string) string {
	s = html.EscapeString(s)
	s = regexp.MustCompile(`\*([^*]+)\*`).ReplaceAllString(s, "<strong>$1</strong>")
	s = regexp.MustCompile(`_([^_]+)_`).ReplaceAllString(s, "<em>$1</em>")
	s = regexp.MustCompile("`([^`]+)`").ReplaceAllString(s, "<code>$1</code>")
	return s
}

func makeSVG(text string) string {
	if text == "" {
		text = " "
	}
	return fmt.Sprintf(`<svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">
  <path fill="#ffffff" d="M 0 0h595.275590551v841.88976378h-595.275590551z"/>
  <text x="70.866" y="78.104" font-family="serif" font-size="11">%s</text>
</svg>
`, html.EscapeString(text))
}

func makePDF(text string) []byte {
	if text == "" {
		text = " "
	}
	escaped := strings.NewReplacer(`\`, `\\`, `(`, `\(`, `)`, `\)`, "\n", `\n`).Replace(text)
	stream := fmt.Sprintf("BT /F1 12 Tf 72 760 Td (%s) Tj ET", escaped)
	objs := []string{
		"<< /Type /Catalog /Pages 2 0 R >>",
		"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
		"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
		"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
		fmt.Sprintf("<< /Length %d >>\nstream\n%s\nendstream", len(stream), stream),
	}
	var b bytes.Buffer
	b.WriteString("%PDF-1.7\n%\x80\x80\x80\x80\n")
	offsets := []int{0}
	for i, obj := range objs {
		offsets = append(offsets, b.Len())
		fmt.Fprintf(&b, "%d 0 obj\n%s\nendobj\n", i+1, obj)
	}
	xref := b.Len()
	fmt.Fprintf(&b, "xref\n0 %d\n0000000000 65535 f \n", len(objs)+1)
	for i := 1; i < len(offsets); i++ {
		fmt.Fprintf(&b, "%010d 00000 n \n", offsets[i])
	}
	fmt.Fprintf(&b, "trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n", len(objs)+1, xref)
	return b.Bytes()
}

func tinyPNG() []byte {
	return []byte{137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82, 0, 0, 0, 1, 0, 0, 0, 1, 8, 6, 0, 0, 0, 31, 21, 196, 137, 0, 0, 0, 13, 73, 68, 65, 84, 120, 156, 99, 248, 255, 255, 255, 127, 0, 9, 251, 3, 253, 5, 67, 69, 202, 0, 0, 0, 0, 73, 69, 78, 68, 174, 66, 96, 130}
}

func cmdEval(args []string) int {
	format := "json"
	pretty := false
	positionals := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			fmt.Print(evalHelp())
			return 0
		}
		switch {
		case a == "--format":
			i++
			if i < len(args) {
				format = args[i]
			}
		case strings.HasPrefix(a, "--format="):
			format = strings.TrimPrefix(a, "--format=")
		case a == "--pretty":
			pretty = true
		case a == "--in" || a == "--target" || a == "--root" || a == "--input" || a == "--font-path" || a == "--package-path" || a == "--package-cache-path" || a == "--creation-timestamp" || a == "-j" || a == "--jobs" || a == "--features" || a == "--diagnostic-format":
			i++
		case strings.HasPrefix(a, "-"):
		default:
			positionals = append(positionals, a)
		}
	}
	if len(positionals) == 0 {
		fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.\n")
		return 2
	}
	val, err := evalTypst(strings.Join(positionals, " "))
	if err != nil {
		fmt.Fprintln(os.Stderr, "error: "+err.Error())
		return 0
	}
	if format == "yaml" {
		fmt.Print(toYAML(val, ""))
		return 0
	}
	var out []byte
	if pretty {
		out, _ = json.MarshalIndent(val, "", "  ")
	} else {
		out, _ = json.Marshal(val)
	}
	fmt.Println(string(out))
	return 0
}

func evalTypst(expr string) (any, error) {
	expr = strings.TrimSpace(expr)
	if expr == "sys.version" {
		return fmt.Sprintf("version(0, 14, 2)"), nil
	}
	if expr == "none" {
		return nil, nil
	}
	if expr == "true" {
		return true, nil
	}
	if expr == "false" {
		return false, nil
	}
	if strings.HasPrefix(expr, "str(") && strings.HasSuffix(expr, ")") {
		v, err := evalTypst(expr[4 : len(expr)-1])
		if err != nil {
			return nil, err
		}
		return fmt.Sprint(v), nil
	}
	if strings.HasPrefix(expr, "range(") && strings.HasSuffix(expr, ")") {
		parts := splitTop(expr[6:len(expr)-1], ",")
		if len(parts) == 2 {
			a, _ := strconv.Atoi(strings.TrimSpace(parts[0]))
			b, _ := strconv.Atoi(strings.TrimSpace(parts[1]))
			arr := []any{}
			for i := a; i < b; i++ {
				arr = append(arr, i)
			}
			return arr, nil
		}
	}
	if strings.HasPrefix(expr, "\"") && strings.HasSuffix(expr, "\"") {
		var s string
		if err := json.Unmarshal([]byte(expr), &s); err == nil {
			return s, nil
		}
		return strings.Trim(expr, "\""), nil
	}
	if strings.HasPrefix(expr, "(") && strings.HasSuffix(expr, ")") {
		inner := strings.TrimSpace(expr[1 : len(expr)-1])
		if strings.Contains(inner, ":") {
			m := map[string]any{}
			for _, p := range splitTop(inner, ",") {
				if strings.TrimSpace(p) == "" {
					continue
				}
				kv := splitTop(p, ":")
				if len(kv) >= 2 {
					k := strings.Trim(strings.TrimSpace(kv[0]), "\"")
					v, _ := evalTypst(strings.Join(kv[1:], ":"))
					m[k] = v
				}
			}
			return m, nil
		}
		parts := splitTop(inner, ",")
		if len(parts) > 1 {
			arr := []any{}
			for _, p := range parts {
				v, _ := evalTypst(p)
				arr = append(arr, v)
			}
			return arr, nil
		}
	}
	if strings.HasPrefix(expr, "[") && strings.HasSuffix(expr, "]") {
		parts := splitTop(expr[1:len(expr)-1], ",")
		arr := []any{}
		for _, p := range parts {
			if strings.TrimSpace(p) != "" {
				v, _ := evalTypst(p)
				arr = append(arr, v)
			}
		}
		return arr, nil
	}
	p := &arithParser{s: expr}
	if v, ok := p.parse(); ok {
		return v, nil
	}
	return nil, fmt.Errorf("expected expression")
}

func splitTop(s, sep string) []string {
	var res []string
	depth := 0
	inStr := false
	start := 0
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == '"' && (i == 0 || s[i-1] != '\\') {
			inStr = !inStr
		}
		if inStr {
			continue
		}
		switch c {
		case '(', '[':
			depth++
		case ')', ']':
			depth--
		}
		if depth == 0 && strings.HasPrefix(s[i:], sep) {
			res = append(res, strings.TrimSpace(s[start:i]))
			start = i + len(sep)
		}
	}
	res = append(res, strings.TrimSpace(s[start:]))
	return res
}

type arithParser struct {
	s string
	i int
}

func (p *arithParser) parse() (int, bool) { v, ok := p.expr(); p.ws(); return v, ok && p.i == len(p.s) }
func (p *arithParser) expr() (int, bool) {
	v, ok := p.term()
	if !ok {
		return 0, false
	}
	for {
		p.ws()
		if p.i >= len(p.s) || (p.s[p.i] != '+' && p.s[p.i] != '-') {
			break
		}
		op := p.s[p.i]
		p.i++
		r, ok := p.term()
		if !ok {
			return 0, false
		}
		if op == '+' {
			v += r
		} else {
			v -= r
		}
	}
	return v, true
}
func (p *arithParser) term() (int, bool) {
	v, ok := p.factor()
	if !ok {
		return 0, false
	}
	for {
		p.ws()
		if p.i >= len(p.s) || (p.s[p.i] != '*' && p.s[p.i] != '/') {
			break
		}
		op := p.s[p.i]
		p.i++
		r, ok := p.factor()
		if !ok || r == 0 {
			return 0, false
		}
		if op == '*' {
			v *= r
		} else {
			v /= r
		}
	}
	return v, true
}
func (p *arithParser) factor() (int, bool) {
	p.ws()
	sign := 1
	if p.i < len(p.s) && p.s[p.i] == '-' {
		sign = -1
		p.i++
	}
	p.ws()
	if p.i < len(p.s) && p.s[p.i] == '(' {
		p.i++
		v, ok := p.expr()
		p.ws()
		if !ok || p.i >= len(p.s) || p.s[p.i] != ')' {
			return 0, false
		}
		p.i++
		return sign * v, true
	}
	start := p.i
	for p.i < len(p.s) && unicode.IsDigit(rune(p.s[p.i])) {
		p.i++
	}
	if start == p.i {
		return 0, false
	}
	v, _ := strconv.Atoi(p.s[start:p.i])
	return sign * v, true
}
func (p *arithParser) ws() {
	for p.i < len(p.s) && unicode.IsSpace(rune(p.s[p.i])) {
		p.i++
	}
}

func toYAML(v any, indent string) string {
	switch x := v.(type) {
	case map[string]any:
		keys := []string{}
		for k := range x {
			keys = append(keys, k)
		}
		// Stable enough for small maps.
		if len(keys) == 2 && keys[0] > keys[1] {
			keys[0], keys[1] = keys[1], keys[0]
		}
		var b strings.Builder
		for _, k := range keys {
			b.WriteString(indent + k + ": ")
			switch x[k].(type) {
			case map[string]any, []any:
				b.WriteString("\n" + toYAML(x[k], indent+"  "))
			default:
				b.WriteString(strings.TrimSpace(toYAML(x[k], "")) + "\n")
			}
		}
		return b.String()
	case []any:
		var b strings.Builder
		for _, e := range x {
			b.WriteString(indent + "- " + strings.TrimSpace(toYAML(e, "")) + "\n")
		}
		return b.String()
	case string:
		if x == "" || strings.ContainsAny(x, ":#\n") {
			return strconv.Quote(x) + "\n"
		}
		return x + "\n"
	case nil:
		return "null\n"
	default:
		return fmt.Sprint(x) + "\n"
	}
}

func cmdFonts(args []string) int {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print(fontsHelp())
			return 0
		}
	}
	variants := false
	for _, a := range args {
		if a == "--variants" {
			variants = true
		}
	}
	fonts := []string{"DejaVu Sans Mono", "Libertinus Serif", "New Computer Modern", "New Computer Modern Math"}
	for _, f := range fonts {
		fmt.Println(f)
		if variants {
			fmt.Println("  Regular")
		}
	}
	return 0
}

func cmdInfo(args []string) int {
	format := ""
	pretty := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			fmt.Print(infoHelp())
			return 0
		}
		if a == "-f" || a == "--format" {
			i++
			if i < len(args) {
				format = args[i]
			}
		} else if strings.HasPrefix(a, "--format=") {
			format = strings.TrimPrefix(a, "--format=")
		} else if a == "--pretty" {
			pretty = true
		}
	}
	info := map[string]any{
		"version":  version,
		"build":    map[string]any{"commit": longCommit, "platform": map[string]any{"os": "linux", "arch": "x86_64"}, "settings": map[string]any{"self-update": false, "http-server": true}},
		"features": map[string]any{"html": false, "a11y-extras": false},
		"fonts":    map[string]any{"paths": []any{}, "system": true, "embedded": true},
		"packages": map[string]any{"package-path": "/home/agent/.local/share/typst/packages", "package-cache-path": "/home/agent/.cache/typst/packages"},
		"env":      envMap(),
	}
	if format == "json" {
		var out []byte
		if pretty {
			out, _ = json.MarshalIndent(info, "", "  ")
		} else {
			out, _ = json.Marshal(info)
		}
		fmt.Println(string(out))
		return 0
	}
	if format == "yaml" {
		fmt.Print(toYAML(info, ""))
		return 0
	}
	arch := "x86_64"
	if runtime.GOARCH != "amd64" {
		arch = runtime.GOARCH
	}
	fmt.Printf("Version %s (%s, linux on %s)\n\n", version, shortCommit, arch)
	fmt.Print(`Build settings
  self-update off (Update Typst via ` + "`typst update`" + `)
  http-server on  (Serve HTML via ` + "`typst watch`" + `)

Features
  html        off (Experimental HTML support)
  a11y-extras off (Experimental accessibility additions)

Fonts
  Custom font paths <none>
  System fonts   on
  Embedded fonts on

Packages
  Package path       /home/agent/.local/share/typst/packages
  Package cache path /home/agent/.cache/typst/packages
`)
	fmt.Print("\nEnvironment variables\n")
	for _, k := range envKeys() {
		if v, ok := os.LookupEnv(k); ok {
			fmt.Printf("  %-27s %s\n", k, v)
		} else {
			fmt.Printf("  %-27s <unset>\n", k)
		}
	}
	return 0
}

func envMap() map[string]any {
	m := map[string]any{}
	for _, k := range envKeys() {
		if v, ok := os.LookupEnv(k); ok {
			m[k] = v
		} else {
			m[k] = nil
		}
	}
	return m
}

func envKeys() []string {
	return []string{"TYPST_CERT", "TYPST_FEATURES", "TYPST_FONT_PATHS", "TYPST_IGNORE_SYSTEM_FONTS", "TYPST_IGNORE_EMBEDDED_FONTS", "TYPST_PACKAGE_CACHE_PATH", "TYPST_PACKAGE_PATH", "TYPST_ROOT", "TYPST_UPDATE_BACKUP_PATH", "SOURCE_DATE_EPOCH", "XDG_CACHE_HOME", "XDG_DATA_HOME", "FONTCONFIG_FILE", "OPENSSL_CONF", "NO_COLOR", "NO_PROXY", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY"}
}

func cmdCompletions(args []string) int {
	if len(args) == 0 {
		fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completions <SHELL>\n\nFor more information, try '--help'.\n")
		return 2
	}
	if args[0] == "-h" || args[0] == "--help" {
		fmt.Print(completionsHelp())
		return 0
	}
	fmt.Printf("# completion script for executable (%s)\n", args[0])
	return 0
}

func cmdInit(args []string) int {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print(initHelp())
			return 0
		}
	}
	positionals := []string{}
	for i := 0; i < len(args); i++ {
		if args[i] == "--package-path" || args[i] == "--package-cache-path" {
			i++
			continue
		}
		if strings.HasPrefix(args[i], "-") {
			continue
		}
		positionals = append(positionals, args[i])
	}
	if len(positionals) == 0 {
		fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <TEMPLATE>\n\nUsage: executable init <TEMPLATE> [DIR]\n\nFor more information, try '--help'.\n")
		return 2
	}
	dir := ""
	if len(positionals) > 1 {
		dir = positionals[1]
	} else {
		t := positionals[0]
		if i := strings.LastIndex(t, "/"); i >= 0 {
			t = t[i+1:]
		}
		if i := strings.Index(t, ":"); i >= 0 {
			t = t[:i]
		}
		dir = t
	}
	if err := os.MkdirAll(dir, 0755); err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		return 1
	}
	_ = os.WriteFile(filepath.Join(dir, "main.typ"), []byte("= "+filepath.Base(dir)+"\n"), 0644)
	fmt.Fprintf(os.Stderr, "initialized project in %s\n", dir)
	return 0
}
