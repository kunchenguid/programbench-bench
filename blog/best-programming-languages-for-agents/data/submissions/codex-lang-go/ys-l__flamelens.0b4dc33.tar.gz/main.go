package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const helpText = `Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
`

type options struct {
	sorted   bool
	echo     bool
	debug    bool
	filename string
}

type frame struct {
	name  string
	value int64
	depth int
}

func main() {
	opts, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(2)
	}

	data, err := readInput(opts.filename)
	if err != nil {
		rustPanicRead(err)
	}
	if opts.echo {
		fmt.Println(string(data))
	}

	if !isTerminal(os.Stdin) || !isTerminal(os.Stdout) {
		if opts.filename == "" && len(data) == 0 {
			fmt.Fprintln(os.Stderr, `Error: Os { code: 6, kind: Uncategorized, message: "No such device or address" }`)
		} else {
			fmt.Fprintln(os.Stderr, `Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }`)
		}
		os.Exit(1)
	}

	runTUI(data, opts)
}

func parseArgs(args []string) (options, bool) {
	var opts options
	positional := false
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if positional {
			if opts.filename != "" {
				unexpected(arg, "")
				return opts, false
			}
			opts.filename = arg
			continue
		}
		switch arg {
		case "--":
			positional = true
		case "--sorted":
			opts.sorted = true
		case "--echo":
			opts.echo = true
		case "--debug":
			opts.debug = true
		case "-h", "--help":
			fmt.Print(helpText)
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("flamelens 0.3.1")
			os.Exit(0)
		default:
			if strings.HasPrefix(arg, "-") {
				tip := ""
				if strings.HasPrefix(arg, "--") {
					tip = fmt.Sprintf("\n\n  tip: to pass '%s' as a value, use '-- %s'", arg, arg)
				}
				unexpected(arg, tip)
				return opts, false
			}
			if opts.filename != "" {
				unexpected(arg, "")
				return opts, false
			}
			opts.filename = arg
		}
	}
	return opts, true
}

func unexpected(arg, tip string) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found%s\n\nUsage: executable [OPTIONS] [FILENAME]\n\nFor more information, try '--help'.\n", arg, tip)
}

func readInput(filename string) ([]byte, error) {
	if filename != "" {
		return os.ReadFile(filename)
	}
	return io.ReadAll(os.Stdin)
}

func rustPanicRead(err error) {
	code := 2
	kind := "NotFound"
	msg := "No such file or directory"
	if pathErr, ok := err.(*os.PathError); ok {
		if errno, ok := pathErr.Err.(syscall.Errno); ok {
			code = int(errno)
			msg = pathErr.Err.Error()
			switch errno {
			case syscall.EACCES:
				kind = "PermissionDenied"
			case syscall.ENOENT:
				kind = "NotFound"
				msg = "No such file or directory"
			default:
				kind = "Uncategorized"
			}
		}
	}
	fmt.Fprintf(os.Stderr, "\nthread 'main' (%d) panicked at src/main.rs:44:47:\n", os.Getpid())
	fmt.Fprintf(os.Stderr, "Could not read file: Os { code: %d, kind: %s, message: %q }\n", code, kind, msg)
	fmt.Fprintln(os.Stderr, "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace")
	os.Exit(101)
}

func isTerminal(f *os.File) bool {
	info, err := f.Stat()
	if err != nil {
		return false
	}
	return (info.Mode() & os.ModeCharDevice) != 0
}

func parseFolded(data []byte, sorted bool) []frame {
	var frames []frame
	scanner := bufio.NewScanner(strings.NewReader(string(data)))
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		idx := strings.LastIndexAny(line, " \t")
		if idx < 0 {
			continue
		}
		stack := strings.TrimSpace(line[:idx])
		valText := strings.TrimSpace(line[idx+1:])
		val, err := strconv.ParseInt(valText, 10, 64)
		if err != nil {
			continue
		}
		parts := strings.Split(stack, ";")
		for i, p := range parts {
			p = strings.TrimSpace(p)
			if p == "" {
				continue
			}
			frames = append(frames, frame{name: p, value: val, depth: i})
		}
	}
	if sorted {
		sort.SliceStable(frames, func(i, j int) bool {
			if frames[i].value == frames[j].value {
				return frames[i].name < frames[j].name
			}
			return frames[i].value > frames[j].value
		})
	}
	return frames
}

func runTUI(data []byte, opts options) {
	frames := parseFolded(data, opts.sorted)
	fmt.Print("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[39m\x1b[49m\x1b[59m\x1b[0m")
	defer fmt.Print("\x1b[?25l\x1b[?1049l\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1002l\x1b[?1000l\x1b[?25h")

	render(frames, opts)

	oldState, termErr := makeRaw(int(os.Stdin.Fd()))
	if termErr == nil {
		defer restoreTerm(int(os.Stdin.Fd()), oldState)
	}
	buf := make([]byte, 1)
	for {
		os.Stdin.SetReadDeadline(time.Now().Add(250 * time.Millisecond))
		n, err := os.Stdin.Read(buf)
		if n > 0 {
			switch buf[0] {
			case 'q', 3:
				return
			case 'r':
				render(frames, opts)
			}
		}
		if err != nil {
			if strings.Contains(err.Error(), "i/o timeout") {
				continue
			}
			return
		}
	}
}

func render(frames []frame, opts options) {
	fmt.Print("\x1b[H")
	fmt.Println("flamelens")
	if opts.debug {
		fmt.Printf("debug: frames=%d sorted=%v\n", len(frames), opts.sorted)
	}
	limit := len(frames)
	if limit > 20 {
		limit = 20
	}
	for i := 0; i < limit; i++ {
		f := frames[i]
		indent := strings.Repeat("  ", f.depth)
		barLen := int(f.value)
		if barLen > 50 {
			barLen = 50
		}
		if barLen < 1 {
			barLen = 1
		}
		fmt.Printf("%s%-32s %8d %s\n", indent, f.name, f.value, strings.Repeat("#", barLen))
	}
}

type termios syscall.Termios

func makeRaw(fd int) (*termios, error) {
	var old syscall.Termios
	if _, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&old)), 0, 0, 0); errno != 0 {
		return nil, errno
	}
	raw := old
	raw.Iflag &^= syscall.ICRNL | syscall.IXON
	raw.Lflag &^= syscall.ECHO | syscall.ICANON | syscall.ISIG
	raw.Cc[syscall.VMIN] = 0
	raw.Cc[syscall.VTIME] = 1
	if _, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(&raw)), 0, 0, 0); errno != 0 {
		return nil, errno
	}
	t := termios(old)
	return &t, nil
}

func restoreTerm(fd int, state *termios) {
	if state == nil {
		return
	}
	old := syscall.Termios(*state)
	syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(&old)), 0, 0, 0)
}
