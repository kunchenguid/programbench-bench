module flamelens

go 1.21
