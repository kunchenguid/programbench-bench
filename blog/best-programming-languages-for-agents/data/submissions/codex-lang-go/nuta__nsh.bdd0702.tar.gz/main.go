package main

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
)

const version = "0.4.2"

func main() {
	os.Exit(run(os.Args))
}

func run(args []string) int {
	var command string
	var haveCommand bool
	norc := false

	for i := 1; i < len(args); i++ {
		arg := args[i]
		switch arg {
		case "-h", "--help":
			printHelp(os.Stdout)
			return 0
		case "--version":
			fmt.Fprintln(os.Stdout, version)
			return 0
		case "--norc":
			norc = true
		case "-l", "--login":
		case "-c":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: The argument '-c <command>' requires a value but none was supplied\n\n")
				fmt.Fprint(os.Stderr, "USAGE:\n    executable -c <command>\n\n")
				fmt.Fprint(os.Stderr, "For more information try --help\n")
				return 1
			}
			command = args[i+1]
			haveCommand = true
			i++
		default:
			if strings.HasPrefix(arg, "-") {
				fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n", arg)
				fmt.Fprint(os.Stderr, "USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n\n")
				fmt.Fprint(os.Stderr, "For more information try --help\n")
				return 1
			}
			if !haveCommand {
				printHelp(os.Stdout)
				return 0
			}
		}
	}

	if haveCommand {
		return execute(command, norc)
	}

	// In non-interactive contexts the reference exits quietly instead of reading
	// stdin. For a terminal, delegate to bash to provide a usable shell.
	if !isTerminal(os.Stdin.Fd()) {
		return 0
	}
	cmd := exec.Command("/bin/bash")
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return waitStatus(cmd.Run())
}

func printHelp(w io.Writer) {
	fmt.Fprint(w, `nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed
`)
}

func execute(command string, norc bool) int {
	script := buildScript(command, norc)
	cmd := exec.Command("/bin/bash", "--noprofile", "--norc")
	cmd.Stdin = strings.NewReader(script)
	cmd.Stdout = os.Stdout
	var stderr bytes.Buffer
	cmd.Stderr = &stderr

	err := cmd.Run()
	status := waitStatus(err)
	errText := stderr.String()
	if status == 127 && strings.Contains(errText, "command not found") {
		name := commandNotFoundName(errText)
		if name == "" {
			name = firstWord(command)
		}
		fmt.Fprintf(os.Stderr, "nsh: command not found `%s'\n", name)
		return 1
	}
	if strings.Contains(errText, "cd: ") && strings.Contains(errText, "No such file or directory") {
		if path := cdMissingPath(command); path != "" {
			fmt.Fprintf(os.Stderr, "nsh: cd: No such file or directory (os error 2): `%s'\n", path)
			return status
		}
	}
	io.WriteString(os.Stderr, errText)
	return status
}

func buildScript(command string, norc bool) string {
	var b strings.Builder
	b.WriteString("shopt -s expand_aliases\n")
	if !norc {
		if home, ok := os.LookupEnv("HOME"); ok && home != "" {
			writeSourceIfExists(&b, filepath.Join(home, ".nshrc"))
		}
		if xdg, ok := os.LookupEnv("XDG_CONFIG_HOME"); ok && xdg != "" {
			writeSourceIfExists(&b, filepath.Join(xdg, "nsh", "nshrc"))
		}
	}
	b.WriteString(splitSemicolons(command))
	b.WriteByte('\n')
	return b.String()
}

func writeSourceIfExists(b *strings.Builder, path string) {
	if _, err := os.Stat(path); err == nil {
		fmt.Fprintf(b, "source %s\n", shellQuote(path))
	}
}

func splitSemicolons(s string) string {
	var b strings.Builder
	var quote rune
	escaped := false
	for _, r := range s {
		if escaped {
			b.WriteRune(r)
			escaped = false
			continue
		}
		if r == '\\' {
			b.WriteRune(r)
			escaped = true
			continue
		}
		switch r {
		case '\'', '"':
			if quote == 0 {
				quote = r
			} else if quote == r {
				quote = 0
			}
			b.WriteRune(r)
		case ';':
			if quote == 0 {
				b.WriteByte('\n')
			} else {
				b.WriteRune(r)
			}
		default:
			b.WriteRune(r)
		}
	}
	return b.String()
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func commandNotFoundName(stderr string) string {
	lines := strings.Split(strings.TrimSpace(stderr), "\n")
	if len(lines) == 0 {
		return ""
	}
	line := lines[len(lines)-1]
	const suffix = ": command not found"
	if !strings.HasSuffix(line, suffix) {
		return ""
	}
	line = strings.TrimSuffix(line, suffix)
	if idx := strings.LastIndex(line, ": "); idx >= 0 {
		return strings.TrimSpace(line[idx+2:])
	}
	return ""
}

func firstWord(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return ""
	}
	fields := strings.Fields(s)
	if len(fields) == 0 {
		return ""
	}
	return strings.Trim(fields[0], "`'\"")
}

func cdMissingPath(command string) string {
	parts := strings.Fields(command)
	for i := 0; i+1 < len(parts); i++ {
		if parts[i] == "cd" {
			return strings.Trim(parts[i+1], "\"'")
		}
	}
	return ""
}

func waitStatus(err error) int {
	if err == nil {
		return 0
	}
	if exit, ok := err.(*exec.ExitError); ok {
		if ws, ok := exit.Sys().(syscall.WaitStatus); ok {
			if ws.Signaled() {
				return 128 + int(ws.Signal())
			}
			return ws.ExitStatus()
		}
	}
	return 1
}

func isTerminal(fd uintptr) bool {
	var stat syscall.Stat_t
	if err := syscall.Fstat(int(fd), &stat); err != nil {
		return false
	}
	return (stat.Mode & syscall.S_IFMT) == syscall.S_IFCHR
}
