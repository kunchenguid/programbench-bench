module statix-reimpl

go 1.21
