package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type diag struct {
	code, line, col int
	name, msg       string
	fixable         bool
}

var lintNames = map[int]string{
	1: "bool_comparison", 2: "empty_let_in", 3: "manual_inherit", 4: "manual_inherit_from",
	5: "legacy_let_syntax", 6: "collapsible_let_in", 7: "eta_reduction", 8: "useless_parens",
	10: "empty_pattern", 11: "redundant_pattern_bind", 12: "unquoted_uri", 14: "empty_inherit",
	17: "deprecated_to_path", 18: "bool_simplification", 19: "useless_has_attr",
	20: "repeated_keys", 23: "empty_list_concat",
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		help()
		return
	}
	if args[0] == "-V" || args[0] == "--version" {
		fmt.Println("statix 0.5.8")
		return
	}
	switch args[0] {
	case "help":
		if len(args) > 1 { subHelp(args[1]); return }
		help()
	case "list":
		if hasHelp(args[1:]) { subHelp("list"); return }
		list()
	case "dump":
		if hasHelp(args[1:]) { subHelp("dump"); return }
		fmt.Print("disabled = []\nignore = ['.direnv']\n\n")
	case "explain":
		if hasHelp(args[1:]) { subHelp("explain"); return }
		explain(args[1:])
	case "check":
		if hasHelp(args[1:]) { subHelp("check"); return }
		os.Exit(check(args[1:]))
	case "fix":
		if hasHelp(args[1:]) { subHelp("fix"); return }
		os.Exit(fix(args[1:], false))
	case "single":
		if hasHelp(args[1:]) { subHelp("single"); return }
		os.Exit(fix(args[1:], true))
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n", args[0])
		os.Exit(2)
	}
}

func hasHelp(args []string) bool {
	for _, a := range args { if a == "-h" || a == "--help" { return true } }
	return false
}

func subHelp(s string) {
	switch s {
	case "check":
		fmt.Print("executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run check on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files\n")
	case "fix":
		fmt.Print("executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run fix on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run               Do not fix files in place, display a diff instead\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files\n")
	case "single":
		fmt.Print("executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]\n\nARGS:\n    <TARGET>    File to run single-fix on\n\nOPTIONS:\n    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run                Do not fix files in place, display a diff instead\n    -h, --help                   Print help information\n    -p, --position <POSITION>    Position to attempt a fix at\n    -s, --stdin                  Enable \"streaming\" mode, accept file on stdin, output diagnostics\n                                 on stdout\n")
	case "explain":
		fmt.Print("executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information\n")
	case "list":
		fmt.Print("executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information\n")
	case "dump":
		fmt.Print("executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information\n")
	default:
		help()
	}
}

func help() {
	fmt.Print(`statix 0.5.8

Akshay <nerdy@peppe.rs>

Lints and suggestions for the Nix programming language

USAGE:
    executable <SUBCOMMAND>

OPTIONS:
    -h, --help       Print help information
    -V, --version    Print version information

SUBCOMMANDS:
    check      Lints and suggestions for the nix programming language
    dump       Dump a sample config to stdout
    explain    Print detailed explanation for a lint warning
    fix        Find and fix issues raised by statix-check
    help       Print this message or the help of the given subcommand(s)
    list       List all available lints
    single     Fix exactly one issue at provided position
`)
}

func list() {
	for _, n := range []int{1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 14, 17, 18, 19, 20, 23} {
		fmt.Printf("W%02d %s\n", n, lintNames[n])
	}
}

var explanations = map[int]string{
	1: "## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n\n## Example\nInstead of checking the value of `x`:\n\n```nix\nif x == true then 0 else 1\n```\n\nUse `x` directly:\n\n```nix\nif x then 0 else 1\n```\n",
	2: "## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\nThese are probably remnants from debugging or editing expressions.\n\n## Example\n\n```nix\nlet in pkgs.statix\n```\n\nPreserve only the body of the `let-in` expression:\n\n```nix\npkgs.statix\n```\n",
	3: "## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into\nthe current scope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  a = 2;\nin\n  { a = a; b = 3; }\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  a = 2;\nin\n  { inherit a; b = 3; }\n```\n",
	4: "## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into\nscope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  mtl = pkgs.haskellPackages.mtl;\nin\n  null\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  inherit (pkgs.haskellPackages) mtl;\nin\n  null\n```\n",
	5: "## What it does\nChecks for legacy-let syntax that was never formalized.\n\n## Why is this bad?\nThis syntax construct is undocumented, refrain from using it.\n",
	6: "## What it does\nChecks for `let-in` expressions whose body is another `let-in`\nexpression.\n\n## Why is this bad?\nUnnecessary code, the `let-in` expressions can be merged.\n",
	7: "## What it does\nChecks for eta-reducible functions, i.e.: converts lambda\nexpressions into free standing functions where applicable.\n",
	8: "## What it does\nChecks for unnecessary parentheses.\n\n## Why is this bad?\nUnnecessarily parenthesized code is hard to read.\n",
	10: "## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.\n\n## Why is this bad?\nThe intention with empty patterns is not instantly obvious. Prefer\nan underscore identifier instead, to indicate that the argument\nis being ignored.\n",
	11: "## What it does\nChecks for binds of the form `inputs @ { ... }` in function\narguments.\n\n## Why is this bad?\nThe variadic pattern here is redundant, as it does not capture\nanything.\n",
	12: "## What it does\nChecks for URI expressions that are not quoted.\n\n## Why is this bad?\nThe Nix language has a special syntax for URLs even though quoted\nstrings can also be used to represent them.\n",
	14: "## What it does\nChecks for empty inherit statements.\n\n## Why is this bad?\nUseless code, probably the result of a refactor.\n\n## Example\n\n```nix\ninherit;\n```\n\nRemove it altogether.\n",
	17: "## What it does\nChecks for usage of the `toPath` function.\n\n## Why is this bad?\n`toPath` is deprecated.\n",
	18: "## What it does\nChecks for boolean expressions that can be simplified.\n\n## Why is this bad?\nComplex booleans affect readibility.\n",
	19: "## What it does\nChecks for expressions that use the \"has attribute\" operator: `?`,\nwhere the `or` operator would suffice.\n",
	20: "## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using\nan attribute set instead.\n",
	23: "## What it does\nChecks for concatenations to empty lists\n\n## Why is this bad?\nConcatenation with the empty list is a no-op.\n",
}

func explain(args []string) {
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, "error: required argument missing")
		os.Exit(2)
	}
	s := strings.TrimPrefix(strings.ToUpper(args[0]), "W")
	n, err := strconv.Atoi(s)
	if err != nil {
		fmt.Println("syntax error")
		return
	}
	if e, ok := explanations[n]; ok {
		fmt.Print(e)
	} else {
		fmt.Printf("explain error: lint with code `%d` not found\n", n)
	}
}

type opts struct {
	target, format, conf, pos string
	stdin, dry               bool
	disabled                 map[int]bool
}

func parse(args []string) opts {
	o := opts{target: ".", format: "stderr", conf: ".", disabled: map[int]bool{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-s", "--stdin":
			o.stdin = true
		case "-d", "--dry-run":
			o.dry = true
		case "-o", "--format":
			i++; if i < len(args) { o.format = args[i] }
		case "-c", "--config":
			i++; if i < len(args) { o.conf = args[i] }
		case "-p", "--position":
			i++; if i < len(args) { o.pos = args[i] }
		case "-i", "--ignore":
			i++
		case "-u", "--unrestricted", "--":
		default:
			if !strings.HasPrefix(a, "-") {
				o.target = a
			}
		}
	}
	o.disabled = loadDisabled(o.conf)
	return o
}

func loadDisabled(p string) map[int]bool {
	out := map[int]bool{}
	st, err := os.Stat(p)
	if err == nil && st.IsDir() {
		p = filepath.Join(p, "statix.toml")
	}
	b, err := os.ReadFile(p)
	if err != nil { return out }
	re := regexp.MustCompile(`disabled\s*=\s*\[([^\]]*)\]`)
	m := re.FindStringSubmatch(string(b))
	if m == nil { return out }
	for _, part := range strings.Split(m[1], ",") {
		x := strings.Trim(part, " \t\r\n\"'")
		for n, name := range lintNames {
			if x == name || strings.EqualFold(x, fmt.Sprintf("W%02d", n)) {
				out[n] = true
			}
		}
	}
	return out
}

func check(args []string) int {
	o := parse(args)
	files := readInputs(o)
	found := false
	for _, f := range files {
		ds := analyze(f.name, f.text, o.disabled)
		if len(ds) > 0 { found = true }
		for _, d := range ds {
			if o.format == "errfmt" || o.stdin {
				fmt.Printf("%s>%d:%d:W:%d:%s\n", f.name, d.line, d.col, d.code, d.msg)
			} else {
				fmt.Printf("[W%02d] Warning: %s\n   --> %s:%d:%d\n    |\n%4d | %s\n    = %s\n", d.code, title(d.code), f.name, d.line, d.col, d.line, lineAt(f.text, d.line), d.msg)
			}
		}
	}
	if found { return 1 }
	return 0
}

type inputFile struct{ name, text string }

func readInputs(o opts) []inputFile {
	if o.stdin {
		b, _ := io.ReadAll(os.Stdin)
		return []inputFile{{"<stdin>", string(b)}}
	}
	var files []string
	st, err := os.Stat(o.target)
	if err != nil { return nil }
	if st.IsDir() {
		filepath.WalkDir(o.target, func(p string, d os.DirEntry, err error) error {
			if err != nil { return nil }
			if d.IsDir() && (d.Name() == ".git" || d.Name() == ".direnv") { return filepath.SkipDir }
			if !d.IsDir() && strings.HasSuffix(p, ".nix") { files = append(files, p) }
			return nil
		})
		sort.Strings(files)
	} else {
		files = []string{o.target}
	}
	out := []inputFile{}
	for _, p := range files {
		b, err := os.ReadFile(p)
		if err == nil { out = append(out, inputFile{p, string(b)}) }
	}
	return out
}

func title(c int) string {
	return map[int]string{1:"Unnecessary comparison with boolean",2:"Useless let-in expression",3:"Assignment instead of inherit",4:"Assignment instead of inherit from",5:"Prefer rec over let",6:"These let-in expressions are collapsible",7:"This function expression is eta-reducible",8:"Found useless parentheses",10:"Found empty pattern in function argument",11:"Found redundant pattern bind in function argument",12:"Found unquoted URI expression",14:"Found empty inherit statement",17:"Found usage of deprecated builtin toPath",18:"Boolean expression can be simplified",19:"Found useless has-attr expression",20:"Found repeated keys in attrset",23:"Unnecessary concatenation with empty list"}[c]
}

func lineAt(s string, n int) string {
	lines := strings.Split(strings.TrimRight(s, "\n"), "\n")
	if n > 0 && n <= len(lines) { return lines[n-1] }
	return ""
}

func col(line, sub string) int {
	i := strings.Index(line, sub)
	if i < 0 { return 1 }
	return i + 1
}

func add(ds *[]diag, disabled map[int]bool, c, l, co int, msg string, fix bool) {
	if !disabled[c] { *ds = append(*ds, diag{c, l, co, lintNames[c], msg, fix}) }
}

var (
	reAssign  = regexp.MustCompile(`^(\s*)([A-Za-z_][A-Za-z0-9_'-]*)\s*=\s*([A-Za-z_][A-Za-z0-9_'-]*)\s*;`)
	reFrom    = regexp.MustCompile(`^(\s*)([A-Za-z_][A-Za-z0-9_'-]*)\s*=\s*([A-Za-z_][A-Za-z0-9_'-]*)\.([A-Za-z_][A-Za-z0-9_'-]*)\s*;`)
	reBool    = regexp.MustCompile(`([A-Za-z_][A-Za-z0-9_'.-]*)\s*(==|!=)\s*(true|false)`)
	reParens  = regexp.MustCompile(`^(\s*[A-Za-z_][A-Za-z0-9_'.-]*\s*=\s*)\(([^()]+)\)(\s*;)`)
	reEta     = regexp.MustCompile(`^(\s*[A-Za-z_][A-Za-z0-9_'.-]*\s*=\s*)([A-Za-z_][A-Za-z0-9_'-]*)\s*:\s*([A-Za-z_][A-Za-z0-9_'.-]*)\s+([A-Za-z_][A-Za-z0-9_'-]*)(\s*;)`)
	reNotEq   = regexp.MustCompile(`!\(([^()]+?)\s*==\s*([^()]+?)\)`)
	reHas     = regexp.MustCompile(`if\s+([A-Za-z_][A-Za-z0-9_'.-]*)\s*\?\s*([A-Za-z_][A-Za-z0-9_'-]*)\s+then\s+([A-Za-z_][A-Za-z0-9_'.-]*)\.([A-Za-z_][A-Za-z0-9_'-]*)\s+else\s+([^;]+)`)
	reEmptyP  = regexp.MustCompile(`\{\s*\.\.\.\s*\}:`)
	reRedPat  = regexp.MustCompile(`([A-Za-z_][A-Za-z0-9_'-]*)\s*@\s*\{\s*\.\.\.\s*\}:`)
	reURI     = regexp.MustCompile(`=\s*([A-Za-z][A-Za-z0-9+.-]*:[^ \t\n;"']+)\s*;`)
	reLeftNil = regexp.MustCompile(`\[\]\s*\+\+\s*([^;]+)`)
	reRightNil= regexp.MustCompile(`([^=;]+?)\s*\+\+\s*\[\]`)
	reRepKey  = regexp.MustCompile(`^\s*([A-Za-z_][A-Za-z0-9_'-]*)\.([A-Za-z_][A-Za-z0-9_'-]*)\s*=`)
)

func analyze(name, text string, disabled map[int]bool) []diag {
	var ds []diag
	lines := strings.Split(strings.TrimRight(text, "\n"), "\n")
	if strings.Contains(text, "in\nlet") || strings.Contains(text, "in\r\nlet") {
		add(&ds, disabled, 6, 1, 1, "This `let in` expression contains a nested `let in` expression", true)
		for i, line := range lines {
			if strings.TrimSpace(line) == "let" || strings.HasPrefix(strings.TrimSpace(line), "let in") {
				if i > 0 { add(&ds, disabled, 6, i+1, col(line, "let"), "This `let in` expression is nested", true); break }
			}
		}
	}
	if strings.HasPrefix(strings.TrimSpace(text), "let {") {
		add(&ds, disabled, 5, 1, 1, "Prefer `rec` over undocumented `let` syntax", true)
	}
	keyLines := map[string][]int{}
	for i, line := range lines {
		n := i + 1
		if m := reAssign.FindStringSubmatch(line); m != nil && m[2] == m[3] {
			add(&ds, disabled, 3, n, len(m[1])+1, "This assignment is better written with `inherit`", true)
		} else if m := reFrom.FindStringSubmatch(line); m != nil && m[2] == m[4] {
			add(&ds, disabled, 4, n, len(m[1])+1, "This assignment is better written with `inherit`", true)
		}
		for _, m := range reBool.FindAllStringSubmatchIndex(line, -1) {
			expr := line[m[2]:m[3]]
			lit := line[m[6]:m[7]]
			add(&ds, disabled, 1, n, m[0]+1, fmt.Sprintf("Comparing `%s` with boolean literal `%s`", expr, lit), true)
		}
		if strings.Contains(line, "let in") {
			add(&ds, disabled, 2, n, col(line, "let"), "This let-in expression has no entries", true)
		}
		if strings.Contains(strings.TrimSpace(line), "inherit;") {
			add(&ds, disabled, 14, n, col(line, "inherit"), "Remove this empty `inherit` statement", true)
		}
		if reEmptyP.MatchString(line) && !reRedPat.MatchString(line) {
			add(&ds, disabled, 10, n, col(line, "{"), "This pattern is empty, use `_` instead", true)
		}
		if m := reRedPat.FindStringSubmatchIndex(line); m != nil {
			name := line[m[2]:m[3]]
			add(&ds, disabled, 11, n, m[0]+1, fmt.Sprintf("This pattern bind is redundant, use `%s` instead", name), true)
		}
		if reURI.MatchString(line) {
			add(&ds, disabled, 12, n, col(line, reURI.FindStringSubmatch(line)[1]), "Consider quoting this URI expression", true)
		}
		if strings.Contains(line, "builtins.toPath") || regexp.MustCompile(`\btoPath\b`).MatchString(line) {
			add(&ds, disabled, 17, n, col(line, "toPath")-9, "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more", false)
		}
		if reLeftNil.MatchString(line) || reRightNil.MatchString(line) {
			co := max(1, strings.Index(line, "[]")+1)
			if strings.Contains(line, "++ []") {
				if eq := strings.Index(line, "="); eq >= 0 { co = eq + 3 }
			}
			add(&ds, disabled, 23, n, co, "Concatenation with the empty list, `[]`, is a no-op", true)
		}
		if reParens.MatchString(line) {
			add(&ds, disabled, 8, n, col(line, "("), "Useless parentheses around value in binding", true)
		}
		if m := reEta.FindStringSubmatch(line); m != nil && m[2] == m[4] {
			add(&ds, disabled, 7, n, col(line, m[2]), fmt.Sprintf("Found eta-reduction: `%s`", m[3]), true)
		}
		if reNotEq.MatchString(line) {
			add(&ds, disabled, 18, n, col(line, "!"), "Try `!=` instead of `!(... == ...)`", true)
		}
		if m := reHas.FindStringSubmatch(line); m != nil && m[1] == m[3] && m[2] == m[4] {
			add(&ds, disabled, 19, n, col(line, "if"), fmt.Sprintf("Consider using `%s.%s or %s` instead of this `if` expression", m[1], m[2], strings.TrimSpace(m[5])), true)
		}
		if m := reRepKey.FindStringSubmatch(line); m != nil {
			keyLines[m[1]] = append(keyLines[m[1]], n)
		}
	}
	for _, ls := range keyLines {
		if len(ls) >= 3 {
			for _, n := range ls {
				add(&ds, disabled, 20, n, 3, "This key can be merged into an attribute set", false)
			}
		}
	}
	return ds
}

func max(a, b int) int { if a > b { return a }; return b }

func applyFixes(text string, onlyLine, onlyCol int, disabled map[int]bool) string {
	if strings.HasPrefix(strings.TrimSpace(text), "let {") && !disabled[5] {
		body := strings.TrimSpace(text)
		body = strings.TrimPrefix(body, "let")
		body = strings.TrimSpace(strings.Trim(body, "{} \n"))
		parts := strings.Split(body, ";")
		var out []string
		for _, p := range parts {
			p = strings.TrimSpace(p)
			if p != "" { out = append(out, "  "+p+";") }
		}
		return "rec {\n" + strings.Join(out, "\n") + "\n}.body\n"
	}
	lines := strings.SplitAfter(text, "\n")
	for i, orig := range lines {
		line := strings.TrimSuffix(orig, "\n")
		n := i + 1
		if onlyLine > 0 && onlyLine != n { continue }
		nl := strings.HasSuffix(orig, "\n")
		s := line
		if !disabled[3] {
			if m := reAssign.FindStringSubmatch(s); m != nil && m[2] == m[3] {
				s = m[1] + "inherit " + m[2] + ";"
			}
		}
		if !disabled[4] {
			if m := reFrom.FindStringSubmatch(s); m != nil && m[2] == m[4] {
				s = m[1] + "inherit (" + m[3] + ") " + m[2] + ";"
			}
		}
		if !disabled[1] {
			s = reBool.ReplaceAllStringFunc(s, func(x string) string {
				m := reBool.FindStringSubmatch(x)
				if (m[2] == "==" && m[3] == "true") || (m[2] == "!=" && m[3] == "false") { return m[1] }
				return "!" + m[1]
			})
		}
		if !disabled[2] && strings.Contains(s, "let in") {
			s = strings.Replace(s, "let in", "", 1)
		}
		if !disabled[14] && strings.TrimSpace(s) == "inherit;" {
			s = ""
		}
		if !disabled[11] { s = reRedPat.ReplaceAllString(s, `${1}:`) }
		if !disabled[10] && !reRedPat.MatchString(line) { s = reEmptyP.ReplaceAllString(s, "_:") }
		if !disabled[12] { s = reURI.ReplaceAllString(s, `= "$1";`) }
		if !disabled[23] {
			s = reLeftNil.ReplaceAllString(s, `$1`)
			s = reRightNil.ReplaceAllString(s, `$1`)
		}
		if !disabled[8] { s = reParens.ReplaceAllString(s, `${1}${2}${3}`) }
		if !disabled[7] {
			if m := reEta.FindStringSubmatch(s); m != nil && m[2] == m[4] {
				s = m[1] + m[3] + m[5]
			}
		}
		if !disabled[18] { s = reNotEq.ReplaceAllString(s, `$1 != $2`) }
		if !disabled[19] {
			if m := reHas.FindStringSubmatch(s); m != nil && m[1] == m[3] && m[2] == m[4] {
				s = reHas.ReplaceAllString(s, `$1.$2 or $5`)
			}
		}
		if s == "" && line != "" { lines[i] = "" } else if nl { lines[i] = s + "\n" } else { lines[i] = s }
		if onlyLine > 0 && s != line { break }
	}
	out := strings.Join(lines, "")
	if !disabled[6] {
		out = strings.Replace(out, "in\nlet in\n", "in\n", 1)
		out = strings.Replace(out, "in\nlet\n", "in\n", 1)
	}
	return out
}

func fix(args []string, single bool) int {
	o := parse(args)
	onlyLine, onlyCol := 0, 0
	if single {
		if o.pos == "" { fmt.Fprintln(os.Stderr, "error: required option '--position <POSITION>' missing"); return 2 }
		parts := strings.Split(o.pos, ",")
		if len(parts) != 2 {
			fmt.Fprintf(os.Stderr, "error: Invalid value for '--position <POSITION>': unable to parse `%s` as line and column\n\nFor more information try --help\n", o.pos)
			return 2
		}
		onlyLine, _ = strconv.Atoi(parts[0]); onlyCol, _ = strconv.Atoi(parts[1])
		_ = onlyCol
	}
	files := readInputs(o)
	for _, f := range files {
		fixed := applyFixes(f.text, onlyLine, onlyCol, o.disabled)
		if o.stdin && !o.dry {
			fmt.Print(fixed)
			continue
		}
		if o.dry {
			printDiff(f.name, f.text, fixed)
		} else if fixed != f.text && !o.stdin {
			os.WriteFile(f.name, []byte(fixed), 0644)
		}
	}
	return 0
}

func printDiff(name, a, b string) {
	if a == b { return }
	ta, _ := os.CreateTemp("", "statix-a-*")
	tb, _ := os.CreateTemp("", "statix-b-*")
	defer os.Remove(ta.Name()); defer os.Remove(tb.Name())
	ta.WriteString(a); tb.WriteString(b); ta.Close(); tb.Close()
	cmd := exec.Command("diff", "-u", "--label", name, "--label", name+" [fixed]", ta.Name(), tb.Name())
	out, _ := cmd.Output()
	if len(out) > 0 {
		sc := bufio.NewScanner(bytes.NewReader(out))
		for sc.Scan() { fmt.Println(sc.Text()) }
	}
}
