package main

import (
	"bufio"
	"errors"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

type vec3 struct{ x, y, z float64 }
type color struct{ r, g, b int }
type tri struct {
	p [3]vec3
	c color
}

type options struct {
	files       []string
	image       bool
	width       int
	height      int
	webify      int
	mono        bool
	yaw, pitch  float64
	roll        float64
	showHelp    bool
	showVersion bool
	imageHelp   bool
}

var (
	bgColor = color{25, 25, 25}
	yellow  = color{255, 255, 0}
	white   = color{255, 255, 255}
)

const mainHelp = `Sloth 0.1
Mitchell Hynes. <mshynes@mun.ca>
A toy for rendering 3D objects in the command line

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -x, --yaw <x>      Sets the object's static X rotation (in radians)
    -y, --pitch <y>    Sets the object's static Y rotation (in radians)
    -z, --roll <z>     Sets the object's static Z rotation (in radians)

ARGS:
    <input filename(s)>...    Sets the input file to render

SUBCOMMANDS:
    help     Prints this message or the help of the given subcommand(s)
    image    Generates a colorless terminal output as lines of text
`

const imageHelpWithArgs = `executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)
`

const imageHelpNoArgs = `executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)
`

func main() {
	opt, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprint(os.Stderr, err.Error())
		os.Exit(1)
	}
	if opt.showVersion {
		fmt.Println("Sloth 0.1")
		return
	}
	if opt.showHelp {
		fmt.Print(mainHelp)
		return
	}
	if opt.imageHelp {
		if len(opt.files) > 0 {
			fmt.Print(imageHelpWithArgs)
		} else {
			fmt.Print(imageHelpNoArgs)
		}
		return
	}
	if len(opt.files) == 0 {
		fmt.Fprint(os.Stderr, missingInput())
		os.Exit(1)
	}
	if opt.image && opt.width == 0 {
		fmt.Fprint(os.Stderr, missingWidth())
		os.Exit(1)
	}
	if opt.width == 0 {
		opt.width = 80
	}
	if opt.height == 0 {
		opt.height = opt.width
	}
	tris, err := loadAll(opt.files)
	if err != nil {
		fmt.Fprintf(os.Stderr, "\nthread 'main' panicked at src/inputs.rs:126:39:\ncalled `Result::unwrap()` on an `Err` value: %q\n", err.Error())
		os.Exit(101)
	}
	rotateAll(tris, opt.yaw, opt.pitch, opt.roll)
	if opt.webify > 0 {
		renderWebify(tris, opt)
		return
	}
	fmt.Print(renderANSI(tris, opt.width, opt.height, opt.mono))
}

func parseArgs(args []string) (options, error) {
	var opt options
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help":
			if opt.image {
				opt.imageHelp = true
			} else {
				opt.showHelp = true
			}
		case "-h":
			if opt.image {
				if i+1 >= len(args) {
					return opt, errors.New("error: The argument '-h <height>' requires a value but none was supplied\n")
				}
				v, err := strconv.Atoi(args[i+1])
				if err != nil {
					return opt, fmt.Errorf("Error: %v\n", err)
				}
				opt.height = v
				i++
			} else {
				opt.showHelp = true
			}
		case "-V", "--version":
			opt.showVersion = true
		case "-b":
			opt.mono = true
		case "help":
			if i+1 < len(args) && args[i+1] == "image" {
				opt.imageHelp = true
			} else {
				opt.showHelp = true
			}
			i = len(args)
		case "image":
			opt.image = true
		case "-w":
			if i+1 >= len(args) {
				return opt, errors.New("error: The argument '-w <width>' requires a value but none was supplied\n")
			}
			v, err := strconv.Atoi(args[i+1])
			if err != nil {
				return opt, fmt.Errorf("Error: %v\n", err)
			}
			opt.width = v
			i++
		case "-j", "--webify":
			if i+1 >= len(args) {
				return opt, errors.New("error: The argument '-j <frame count>' requires a value but none was supplied\n")
			}
			v, err := strconv.Atoi(args[i+1])
			if err != nil {
				return opt, fmt.Errorf("Error: %v\n", err)
			}
			opt.webify = v
			i++
		case "-x", "--yaw":
			v, ni, err := parseFloatOpt(args, i, a)
			if err != nil {
				return opt, err
			}
			opt.yaw = v
			i = ni
		case "-y", "--pitch":
			v, ni, err := parseFloatOpt(args, i, a)
			if err != nil {
				return opt, err
			}
			opt.pitch = v
			i = ni
		case "-z", "--roll":
			v, ni, err := parseFloatOpt(args, i, a)
			if err != nil {
				return opt, err
			}
			opt.roll = v
			i = ni
		default:
			if strings.HasPrefix(a, "-") {
				return opt, fmt.Errorf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFor more information try --help\n", a)
			}
			opt.files = append(opt.files, splitFiles(a)...)
		}
	}
	return opt, nil
}

func parseFloatOpt(args []string, i int, flag string) (float64, int, error) {
	if i+1 >= len(args) {
		return 0, i, fmt.Errorf("error: The argument '%s <x>' requires a value but none was supplied\n", flag)
	}
	v, err := strconv.ParseFloat(args[i+1], 64)
	if err != nil {
		return 0, i, fmt.Errorf("Error: %v\n", err)
	}
	return v, i + 1, nil
}

func splitFiles(s string) []string {
	var out []string
	for _, f := range strings.Fields(s) {
		out = append(out, f)
	}
	if len(out) == 0 && s != "" {
		out = append(out, s)
	}
	return out
}

func missingInput() string {
	return `error: The following required arguments were not provided:
    <input filename(s)>...

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

For more information try --help
`
}

func missingWidth() string {
	return `error: The following required arguments were not provided:
    -w <width>

USAGE:
    executable image -h <height> -w <width>

For more information try --help
`
}

func loadAll(files []string) ([]tri, error) {
	var all []tri
	for _, f := range files {
		t, err := loadFile(f)
		if err != nil {
			return nil, err
		}
		all = append(all, t...)
	}
	if len(all) == 0 {
		return nil, errors.New("file contained no faces")
	}
	return all, nil
}

func loadFile(name string) ([]tri, error) {
	ext := strings.ToLower(filepath.Ext(name))
	switch ext {
	case ".obj":
		return loadOBJ(name)
	case ".stl":
		return loadSTL(name)
	default:
		return nil, fmt.Errorf("filename: [%s] couldn't load, unknown file type", name)
	}
}

func loadOBJ(name string) ([]tri, error) {
	f, err := os.Open(name)
	if err != nil {
		return nil, fmt.Errorf("filename: [%s] couldn't load, OBJ load failed. %v", name, err)
	}
	defer f.Close()
	var verts []vec3
	var tris []tri
	mats := map[string]color{}
	cur := yellow
	dir := filepath.Dir(name)
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024), 1024*1024)
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) == 0 {
			continue
		}
		switch fields[0] {
		case "mtllib":
			for _, m := range fields[1:] {
				ms, err := loadMTL(filepath.Join(dir, m))
				if err != nil {
					return nil, errors.New("Expected to have materials.: OpenFileFailed")
				}
				for k, v := range ms {
					mats[k] = v
				}
			}
		case "usemtl":
			if len(fields) > 1 {
				if c, ok := mats[fields[1]]; ok {
					cur = c
				}
			}
		case "v":
			if len(fields) >= 4 {
				x, _ := strconv.ParseFloat(fields[1], 64)
				y, _ := strconv.ParseFloat(fields[2], 64)
				z, _ := strconv.ParseFloat(fields[3], 64)
				verts = append(verts, vec3{x, y, z})
			}
		case "f":
			var idx []int
			for _, p := range fields[1:] {
				part := strings.Split(p, "/")[0]
				n, err := strconv.Atoi(part)
				if err != nil {
					continue
				}
				if n < 0 {
					n = len(verts) + n + 1
				}
				if n > 0 && n <= len(verts) {
					idx = append(idx, n-1)
				}
			}
			for i := 1; i+1 < len(idx); i++ {
				tris = append(tris, tri{p: [3]vec3{verts[idx[0]], verts[idx[i]], verts[idx[i+1]]}, c: cur})
			}
		}
	}
	return tris, sc.Err()
}

func loadMTL(name string) (map[string]color, error) {
	f, err := os.Open(name)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	out := map[string]color{}
	cur := ""
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) == 0 {
			continue
		}
		if fields[0] == "newmtl" && len(fields) > 1 {
			cur = fields[1]
		} else if fields[0] == "Kd" && cur != "" && len(fields) >= 4 {
			r, _ := strconv.ParseFloat(fields[1], 64)
			g, _ := strconv.ParseFloat(fields[2], 64)
			b, _ := strconv.ParseFloat(fields[3], 64)
			out[cur] = color{clamp255(r * 255), clamp255(g * 255), clamp255(b * 255)}
		}
	}
	return out, sc.Err()
}

func loadSTL(name string) ([]tri, error) {
	f, err := os.Open(name)
	if err != nil {
		return nil, fmt.Errorf("filename: [%s] couldn't load, STL load failed. %v", name, err)
	}
	defer f.Close()
	var verts []vec3
	var tris []tri
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024), 1024*1024)
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) == 4 && fields[0] == "vertex" {
			x, _ := strconv.ParseFloat(fields[1], 64)
			y, _ := strconv.ParseFloat(fields[2], 64)
			z, _ := strconv.ParseFloat(fields[3], 64)
			verts = append(verts, vec3{x, y, z})
			if len(verts) == 3 {
				tris = append(tris, tri{p: [3]vec3{verts[0], verts[1], verts[2]}, c: yellow})
				verts = verts[:0]
			}
		}
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	return tris, nil
}

func rotateAll(tris []tri, yaw, pitch, roll float64) {
	for ti := range tris {
		for i := range tris[ti].p {
			tris[ti].p[i] = rotate(tris[ti].p[i], yaw, pitch, roll)
		}
	}
}

func rotate(v vec3, ax, ay, az float64) vec3 {
	c, s := math.Cos(ax), math.Sin(ax)
	v.y, v.z = v.y*c-v.z*s, v.y*s+v.z*c
	c, s = math.Cos(ay), math.Sin(ay)
	v.x, v.z = v.x*c+v.z*s, -v.x*s+v.z*c
	c, s = math.Cos(az), math.Sin(az)
	v.x, v.y = v.x*c-v.y*s, v.x*s+v.y*c
	return v
}

func renderANSI(tris []tri, w, h int, mono bool) string {
	pix, cols := rasterize(tris, w, h, mono)
	var b strings.Builder
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			ch := pix[y*w+x]
			c := cols[y*w+x]
			b.WriteString(fmt.Sprintf("\x1b[48;2;%d;%d;%dm\x1b[38;2;%d;%d;%dm%c\x1b[49m\x1b[39m", bgColor.r, bgColor.g, bgColor.b, c.r, c.g, c.b, ch))
		}
		b.WriteByte('\n')
	}
	return b.String()
}

func renderWebify(tris []tri, opt options) {
	frames := opt.webify
	if frames < 1 {
		frames = 1
	}
	fmt.Println("var frames = [`")
	for i := 0; i < frames; i++ {
		tmp := make([]tri, len(tris))
		copy(tmp, tris)
		rotateAll(tmp, 0, float64(i)*2*math.Pi/float64(frames), 0)
		pix, cols := rasterize(tmp, opt.width, opt.height, opt.mono)
		for y := 0; y < opt.height; y++ {
			for x := 0; x < opt.width; x++ {
				c := cols[y*opt.width+x]
				fmt.Printf("<span style=\"color:rgb(%d,%d,%d)\">%c", c.r, c.g, c.b, pix[y*opt.width+x])
			}
			fmt.Println()
		}
		if i+1 == frames {
			fmt.Println("`];")
		} else {
			fmt.Println("`,")
			fmt.Println("`")
		}
	}
}

func rasterize(tris []tri, w, h int, mono bool) ([]rune, []color) {
	pix := make([]rune, w*h)
	cols := make([]color, w*h)
	depth := make([]float64, w*h)
	for i := range pix {
		pix[i] = ' '
		cols[i] = color{0, 0, 0}
		depth[i] = math.Inf(-1)
	}
	minv, maxv := bounds(tris)
	cx, cy := (minv.x+maxv.x)/2, (minv.y+maxv.y)/2
	sx, sy := maxv.x-minv.x, maxv.y-minv.y
	scale := math.Min(float64(w-1)/max(sx, 1e-9), float64(h-1)/max(sy, 1e-9)) * 0.82
	if scale <= 0 || math.IsInf(scale, 0) || math.IsNaN(scale) {
		scale = 1
	}
	for _, t := range tris {
		var xs, ys, zs [3]float64
		for i, p := range t.p {
			xs[i] = (p.x-cx)*scale + float64(w)/2
			ys[i] = float64(h)/2 - (p.y-cy)*scale
			zs[i] = p.z
		}
		normal := cross(sub(t.p[1], t.p[0]), sub(t.p[2], t.p[0]))
		light := normDot(normal, vec3{0.4, -0.5, 1})
		if light < 0 {
			light = -light * 0.45
		}
		intensity := 0.25 + 0.75*light
		ch := shadeChar(intensity)
		c := t.c
		if mono {
			c = white
		}
		c = scaleColor(c, 0.55+0.45*intensity)
		fillTriangle(xs, ys, zs, depth, pix, cols, w, h, ch, c)
	}
	return pix, cols
}

func fillTriangle(xs, ys, zs [3]float64, depth []float64, pix []rune, cols []color, w, h int, ch rune, c color) {
	minx := int(math.Max(0, math.Floor(min3(xs[0], xs[1], xs[2]))))
	maxx := int(math.Min(float64(w-1), math.Ceil(max3(xs[0], xs[1], xs[2]))))
	miny := int(math.Max(0, math.Floor(min3(ys[0], ys[1], ys[2]))))
	maxy := int(math.Min(float64(h-1), math.Ceil(max3(ys[0], ys[1], ys[2]))))
	area := edge(xs[0], ys[0], xs[1], ys[1], xs[2], ys[2])
	if math.Abs(area) < 1e-9 {
		return
	}
	for y := miny; y <= maxy; y++ {
		for x := minx; x <= maxx; x++ {
			px, py := float64(x)+0.5, float64(y)+0.5
			w0 := edge(xs[1], ys[1], xs[2], ys[2], px, py) / area
			w1 := edge(xs[2], ys[2], xs[0], ys[0], px, py) / area
			w2 := edge(xs[0], ys[0], xs[1], ys[1], px, py) / area
			if w0 >= -1e-6 && w1 >= -1e-6 && w2 >= -1e-6 {
				z := w0*zs[0] + w1*zs[1] + w2*zs[2]
				idx := y*w + x
				if z > depth[idx] {
					depth[idx] = z
					pix[idx] = ch
					cols[idx] = c
				}
			}
		}
	}
}

func bounds(tris []tri) (vec3, vec3) {
	minv := vec3{math.Inf(1), math.Inf(1), math.Inf(1)}
	maxv := vec3{math.Inf(-1), math.Inf(-1), math.Inf(-1)}
	for _, t := range tris {
		for _, p := range t.p {
			minv.x = math.Min(minv.x, p.x)
			minv.y = math.Min(minv.y, p.y)
			minv.z = math.Min(minv.z, p.z)
			maxv.x = math.Max(maxv.x, p.x)
			maxv.y = math.Max(maxv.y, p.y)
			maxv.z = math.Max(maxv.z, p.z)
		}
	}
	return minv, maxv
}

func edge(ax, ay, bx, by, cx, cy float64) float64 { return (cx-ax)*(by-ay) - (cy-ay)*(bx-ax) }
func sub(a, b vec3) vec3                          { return vec3{a.x - b.x, a.y - b.y, a.z - b.z} }
func cross(a, b vec3) vec3 {
	return vec3{a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x}
}
func normDot(a, b vec3) float64 {
	la := math.Sqrt(a.x*a.x + a.y*a.y + a.z*a.z)
	lb := math.Sqrt(b.x*b.x + b.y*b.y + b.z*b.z)
	if la == 0 || lb == 0 {
		return 0
	}
	return (a.x*b.x + a.y*b.y + a.z*b.z) / (la * lb)
}
func shadeChar(v float64) rune {
	chars := []rune(" .:-=+*#%@")
	i := int(v * float64(len(chars)-1))
	if i < 0 {
		i = 0
	}
	if i >= len(chars) {
		i = len(chars) - 1
	}
	return chars[i]
}
func scaleColor(c color, f float64) color {
	return color{clamp255(float64(c.r) * f), clamp255(float64(c.g) * f), clamp255(float64(c.b) * f)}
}
func clamp255(v float64) int {
	if v < 0 {
		return 0
	}
	if v > 255 {
		return 255
	}
	return int(v + 0.5)
}
func min3(a, b, c float64) float64 { return math.Min(a, math.Min(b, c)) }
func max3(a, b, c float64) float64 { return math.Max(a, math.Max(b, c)) }
func max(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}
