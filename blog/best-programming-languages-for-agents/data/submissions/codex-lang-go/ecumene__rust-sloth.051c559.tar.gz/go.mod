module slothclone

go 1.21
