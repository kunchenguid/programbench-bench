module seqtkclone

go 1.21
