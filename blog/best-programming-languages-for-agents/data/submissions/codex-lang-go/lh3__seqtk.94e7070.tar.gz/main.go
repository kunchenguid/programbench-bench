package main

import (
	"bufio"
	"compress/gzip"
	"fmt"
	"io"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

type Record struct {
	Name  string
	Seq   string
	Qual  string
	Fastq bool
}

func main() {
	if len(os.Args) < 2 {
		usage()
		return
	}
	var err error
	switch os.Args[1] {
	case "seq":
		err = cmdSeq(os.Args[2:])
	case "size":
		err = cmdSize(os.Args[2:])
	case "comp":
		err = cmdComp(os.Args[2:])
	case "subseq":
		err = cmdSubseq(os.Args[2:])
	case "sample":
		err = cmdSample(os.Args[2:])
	case "trimfq":
		err = cmdTrimfq(os.Args[2:])
	case "fqchk":
		err = cmdFqchk(os.Args[2:])
	case "mergepe":
		err = cmdMergePE(os.Args[2:])
	case "split":
		err = cmdSplit(os.Args[2:])
	case "rename":
		err = cmdRename(os.Args[2:])
	case "hpc":
		err = cmdHPC(os.Args[2:])
	case "gap":
		err = cmdGap(os.Args[2:])
	case "cutN":
		err = cmdCutN(os.Args[2:])
	case "listhet":
		err = cmdListHet(os.Args[2:])
	case "randbase":
		err = cmdRandBase(os.Args[2:])
	case "mergefa":
		err = cmdMergeFA(os.Args[2:])
	case "famask":
		err = cmdFamask(os.Args[2:])
	case "mutfa":
		err = cmdMutfa(os.Args[2:])
	case "telo":
		err = cmdTelo(os.Args[2:])
	case "hety":
		err = cmdHety(os.Args[2:])
	case "gc":
		err = cmdGC(os.Args[2:])
	case "dropse":
		err = cmdDropSE(os.Args[2:])
	default:
		fmt.Fprintf(os.Stderr, "[main] unrecognized command '%s'. Abort!\n", os.Args[1])
		os.Exit(1)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func usage() {
	fmt.Print(`
Usage:   seqtk <command> <arguments>
Version: 1.5-r133

Command: seq       common transformation of FASTA/Q
         size      report the number sequences and bases
         comp      get the nucleotide composition of FASTA/Q
         sample    subsample sequences
         subseq    extract subsequences from FASTA/Q
         fqchk     fastq QC (base/quality summary)
         mergepe   interleave two PE FASTA/Q files
         split     split one file into multiple smaller files
         trimfq    trim FASTQ using the Phred algorithm

         hety      regional heterozygosity
         gc        identify high- or low-GC regions
         mutfa     point mutate FASTA at specified positions
         mergefa   merge two FASTA/Q files
         famask    apply a X-coded FASTA to a source FASTA
         dropse    drop unpaired from interleaved PE FASTA/Q
         rename    rename sequence names
         randbase  choose a random base from hets
         cutN      cut sequence at long N
         gap       get the gap locations
         listhet   extract the position of each het
         hpc       homopolyer-compressed sequence
         telo      identify telomere repeats in asm or long reads

`)
}

func openInput(path string) (io.ReadCloser, error) {
	if path == "" || path == "-" {
		return io.NopCloser(os.Stdin), nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	if strings.HasSuffix(path, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		return struct {
			io.Reader
			io.Closer
		}{gz, multiCloser{gz, f}}, nil
	}
	return f, nil
}

type multiCloser []io.Closer

func (m multiCloser) Close() error {
	for _, c := range m {
		_ = c.Close()
	}
	return nil
}

func readRecords(path string) ([]Record, error) {
	rc, err := openInput(path)
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	br := bufio.NewReader(rc)
	var recs []Record
	for {
		line, err := readNonEmpty(br)
		if err == io.EOF {
			return recs, nil
		}
		if err != nil {
			return recs, err
		}
		if strings.HasPrefix(line, ">") {
			name := line[1:]
			var sb strings.Builder
			for {
				b, err := br.Peek(1)
				if err == io.EOF {
					break
				}
				if err != nil {
					return recs, err
				}
				if b[0] == '>' || b[0] == '@' {
					break
				}
				l, err := readLine(br)
				if err != nil && err != io.EOF {
					return recs, err
				}
				sb.WriteString(strings.TrimSpace(l))
				if err == io.EOF {
					break
				}
			}
			recs = append(recs, Record{Name: name, Seq: sb.String()})
		} else if strings.HasPrefix(line, "@") {
			name := line[1:]
			var seq strings.Builder
			for {
				l, err := readLine(br)
				if err != nil {
					return recs, err
				}
				if strings.HasPrefix(l, "+") {
					break
				}
				seq.WriteString(strings.TrimSpace(l))
			}
			need := seq.Len()
			var qual strings.Builder
			for qual.Len() < need {
				l, err := readLine(br)
				if err != nil && err != io.EOF {
					return recs, err
				}
				qual.WriteString(strings.TrimRight(l, "\r\n"))
				if err == io.EOF {
					break
				}
			}
			q := qual.String()
			if len(q) > need {
				q = q[:need]
			}
			recs = append(recs, Record{Name: name, Seq: seq.String(), Qual: q, Fastq: true})
		} else {
			return recs, fmt.Errorf("[read] unknown file format")
		}
	}
}

func readLine(br *bufio.Reader) (string, error) {
	s, err := br.ReadString('\n')
	return strings.TrimRight(s, "\n"), err
}

func readNonEmpty(br *bufio.Reader) (string, error) {
	for {
		l, err := readLine(br)
		if err != nil && err != io.EOF {
			return "", err
		}
		l = strings.TrimRight(l, "\r")
		if strings.TrimSpace(l) != "" {
			return l, err
		}
		if err == io.EOF {
			return "", io.EOF
		}
	}
}

func firstName(s string) string {
	if i := strings.IndexAny(s, " \t"); i >= 0 {
		return s[:i]
	}
	return s
}

func printRecord(w io.Writer, r Record, fasta bool, lineLen int, noComment bool) {
	name := r.Name
	if noComment {
		name = firstName(name)
	}
	if fasta || !r.Fastq {
		fmt.Fprintf(w, ">%s\n", name)
		printFold(w, r.Seq, lineLen)
	} else {
		fmt.Fprintf(w, "@%s\n", name)
		printFold(w, r.Seq, lineLen)
		fmt.Fprintln(w, "+")
		printFold(w, r.Qual, lineLen)
	}
}

func printFold(w io.Writer, s string, lineLen int) {
	if lineLen <= 0 {
		fmt.Fprintln(w, s)
		return
	}
	for len(s) > lineLen {
		fmt.Fprintln(w, s[:lineLen])
		s = s[lineLen:]
	}
	fmt.Fprintln(w, s)
}

func parseSeqOpts(args []string) (map[string]string, []string) {
	opts := map[string]string{"l": "0", "Q": "33", "n": ""}
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if !strings.HasPrefix(a, "-") || a == "-" {
			rest = append(rest, args[i:]...)
			break
		}
		for j := 1; j < len(a); j++ {
			c := string(a[j])
			switch c {
			case "a", "A", "C", "r", "U", "Q":
				if c == "Q" && j+1 < len(a) {
					opts["Q"] = a[j+1:]
					j = len(a)
				} else if c == "Q" && i+1 < len(args) {
					i++
					opts["Q"] = args[i]
				} else {
					opts[c] = "1"
				}
			case "l", "q", "n", "M":
				val := ""
				if j+1 < len(a) {
					val = a[j+1:]
					j = len(a)
				} else if i+1 < len(args) {
					i++
					val = args[i]
				}
				opts[c] = val
			default:
				fmt.Fprintf(os.Stderr, "seq: invalid option -- '%s'\n", c)
			}
		}
	}
	return opts, rest
}

func cmdSeq(args []string) error {
	opts, rest := parseSeqOpts(args)
	path := ""
	if len(rest) > 0 {
		path = rest[0]
	}
	recs, err := readRecords(path)
	if err != nil {
		return err
	}
	lineLen, _ := strconv.Atoi(opts["l"])
	qoff, _ := strconv.Atoi(opts["Q"])
	qthr := -1
	if opts["q"] != "" {
		qthr, _ = strconv.Atoi(opts["q"])
	}
	masks := map[string][]bedRegion{}
	if opts["M"] != "" {
		masks = readBed(opts["M"])
	}
	for _, r := range recs {
		if opts["U"] != "" {
			r.Seq = strings.ToUpper(r.Seq)
		}
		if len(masks) > 0 {
			for _, b := range masks[firstName(r.Name)] {
				r.Seq = maskLower(r.Seq, b.Start, b.End)
			}
		}
		if qthr >= 0 && r.Fastq {
			nc := opts["n"]
			b := []byte(r.Seq)
			for i := range b {
				if i < len(r.Qual) && int(r.Qual[i])-qoff < qthr {
					if nc != "" {
						b[i] = nc[0]
					} else {
						b[i] = toLower(b[i])
					}
				}
			}
			r.Seq = string(b)
		}
		if opts["r"] != "" {
			r.Seq = revcomp(r.Seq)
			if r.Fastq {
				r.Qual = reverse(r.Qual)
			}
		}
		printRecord(os.Stdout, r, opts["a"] != "" || opts["A"] != "", lineLen, opts["C"] != "")
	}
	return nil
}

func cmdSize(args []string) error {
	path := ""
	if len(args) > 0 {
		path = args[len(args)-1]
	}
	recs, err := readRecords(path)
	if err != nil {
		return err
	}
	n, bases := 0, 0
	for _, r := range recs {
		n++
		bases += len(r.Seq)
	}
	fmt.Printf("%d\t%d\n", n, bases)
	return nil
}

func cmdComp(args []string) error {
	path := ""
	if len(args) > 0 {
		path = args[len(args)-1]
	}
	recs, err := readRecords(path)
	if err != nil {
		return err
	}
	for _, r := range recs {
		var a, c, g, t, n, lower int
		for _, ch := range r.Seq {
			if ch >= 'a' && ch <= 'z' {
				lower++
			}
			switch ch {
			case 'A', 'a':
				a++
			case 'C', 'c':
				c++
			case 'G', 'g':
				g++
			case 'T', 't', 'U', 'u':
				t++
			case 'N', 'n':
				n++
			}
		}
		_ = lower
		fmt.Printf("%s\t%d\t%d\t%d\t%d\t%d\t0\t0\t%d\t%d\t0\t0\t0\n", firstName(r.Name), len(r.Seq), a, c, g, t, n, c+g)
	}
	return nil
}

type bedRegion struct {
	Chr        string
	Start, End int
	Strand     string
}

func readBed(path string) map[string][]bedRegion {
	m := map[string][]bedRegion{}
	rc, err := openInput(path)
	if err != nil {
		return m
	}
	defer rc.Close()
	sc := bufio.NewScanner(rc)
	for sc.Scan() {
		f := strings.Fields(sc.Text())
		if len(f) < 3 || strings.HasPrefix(f[0], "#") {
			continue
		}
		s, _ := strconv.Atoi(f[1])
		e, _ := strconv.Atoi(f[2])
		strand := ""
		if len(f) >= 6 {
			strand = f[5]
		}
		m[f[0]] = append(m[f[0]], bedRegion{f[0], s, e, strand})
	}
	return m
}

func cmdSubseq(args []string) error {
	tab, strand := false, false
	lineLen := 0
	var rest []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-t":
			tab = true
		case "-s":
			strand = true
		case "-l":
			i++
			lineLen, _ = strconv.Atoi(args[i])
		default:
			if strings.HasPrefix(args[i], "-l") {
				lineLen, _ = strconv.Atoi(args[i][2:])
			} else {
				rest = append(rest, args[i])
			}
		}
	}
	if len(rest) < 2 {
		fmt.Print("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\n")
		return nil
	}
	recs, err := readRecords(rest[0])
	if err != nil {
		return err
	}
	rc, err := openInput(rest[1])
	if err != nil {
		return err
	}
	defer rc.Close()
	var bed []bedRegion
	names := map[string]bool{}
	isBed := false
	sc := bufio.NewScanner(rc)
	for sc.Scan() {
		f := strings.Fields(sc.Text())
		if len(f) == 0 {
			continue
		}
		if len(f) >= 3 {
			if s, e1 := atoiOK(f[1]); e1 {
				if e, e2 := atoiOK(f[2]); e2 {
					isBed = true
					st := ""
					if len(f) >= 6 {
						st = f[5]
					}
					bed = append(bed, bedRegion{f[0], s, e, st})
					continue
				}
			}
		}
		names[f[0]] = true
	}
	by := map[string]Record{}
	for _, r := range recs {
		by[firstName(r.Name)] = r
	}
	if isBed {
		for _, b := range bed {
			r, ok := by[b.Chr]
			if !ok {
				continue
			}
			s, e := clamp(b.Start, 0, len(r.Seq)), clamp(b.End, 0, len(r.Seq))
			if e < s {
				s, e = e, s
			}
			seq := r.Seq[s:e]
			qual := ""
			if r.Fastq && e <= len(r.Qual) {
				qual = r.Qual[s:e]
			}
			if strand && b.Strand == "-" {
				seq = revcomp(seq)
				qual = reverse(qual)
			}
			if tab {
				fmt.Printf("%s\t%d\t%s\n", b.Chr, s+1, seq)
			} else {
				nm := fmt.Sprintf("%s:%d-%d", b.Chr, s+1, e)
				if c := comment(r.Name); c != "" {
					nm += " " + c
				}
				printRecord(os.Stdout, Record{Name: nm, Seq: seq, Qual: qual, Fastq: r.Fastq}, !r.Fastq, lineLen, false)
			}
		}
	} else {
		for _, r := range recs {
			if names[firstName(r.Name)] {
				printRecord(os.Stdout, r, !r.Fastq, lineLen, false)
			}
		}
	}
	return nil
}

func cmdSample(args []string) error {
	seed := int64(11)
	twoPass := false
	var rest []string
	for i := 0; i < len(args); i++ {
		if args[i] == "-2" {
			twoPass = true
			_ = twoPass
		} else if args[i] == "-s" && i+1 < len(args) {
			i++
			seed, _ = strconv.ParseInt(args[i], 10, 64)
		} else if strings.HasPrefix(args[i], "-s") {
			seed, _ = strconv.ParseInt(args[i][2:], 10, 64)
		} else {
			rest = append(rest, args[i])
		}
	}
	if len(rest) < 2 {
		fmt.Print("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n\nOptions: -s INT       RNG seed [11]\n         -2           2-pass mode: twice as slow but with much reduced memory\n")
		return nil
	}
	recs, err := readRecords(rest[0])
	if err != nil {
		return err
	}
	x, _ := strconv.ParseFloat(rest[1], 64)
	rng := rand.New(rand.NewSource(seed))
	if x < 1 {
		for _, r := range recs {
			if rng.Float64() < x {
				printRecord(os.Stdout, r, !r.Fastq, 0, false)
			}
		}
	} else {
		n := int(x)
		if n > len(recs) {
			n = len(recs)
		}
		perm := rng.Perm(len(recs))[:n]
		keep := map[int]bool{}
		for _, i := range perm {
			keep[i] = true
		}
		for i, r := range recs {
			if keep[i] {
				printRecord(os.Stdout, r, !r.Fastq, 0, false)
			}
		}
	}
	return nil
}

func cmdTrimfq(args []string) error {
	b, e, L := 0, 0, 0
	forceQ := false
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		get := func(prefix string) int {
			if len(a) > 2 {
				v, _ := strconv.Atoi(a[2:])
				return v
			}
			i++
			v, _ := strconv.Atoi(args[i])
			_ = prefix
			return v
		}
		if a == "-Q" {
			forceQ = true
		} else if strings.HasPrefix(a, "-b") {
			b = get("-b")
		} else if strings.HasPrefix(a, "-e") {
			e = get("-e")
		} else if strings.HasPrefix(a, "-L") {
			L = get("-L")
		} else if strings.HasPrefix(a, "-q") || strings.HasPrefix(a, "-l") {
			if len(a) == 2 {
				i++
			} // accepted but approximate
		} else {
			rest = append(rest, a)
		}
	}
	if len(rest) < 1 {
		fmt.Print("\nUsage:   seqtk trimfq [options] <in.fq>\n")
		return nil
	}
	recs, err := readRecords(rest[0])
	if err != nil {
		return err
	}
	for _, r := range recs {
		s := clamp(b, 0, len(r.Seq))
		end := len(r.Seq) - e
		if L > 0 && L < end {
			end = L
		}
		end = clamp(end, s, len(r.Seq))
		r.Seq = r.Seq[s:end]
		if len(r.Qual) >= end {
			r.Qual = r.Qual[s:end]
		}
		if forceQ {
			r.Fastq = true
		}
		printRecord(os.Stdout, r, !r.Fastq, 0, false)
	}
	return nil
}

func cmdFqchk(args []string) error {
	qcut := 20
	var rest []string
	for i := 0; i < len(args); i++ {
		if strings.HasPrefix(args[i], "-q") {
			if len(args[i]) > 2 {
				qcut, _ = strconv.Atoi(args[i][2:])
			} else {
				i++
				qcut, _ = strconv.Atoi(args[i])
			}
		} else {
			rest = append(rest, args[i])
		}
	}
	if len(rest) < 1 {
		fmt.Print("Usage: seqtk fqchk [-q 20] <in.fq>\n")
		return nil
	}
	recs, err := readRecords(rest[0])
	if err != nil {
		return err
	}
	maxLen, minLen, total := 0, 1<<30, 0
	qset := map[byte]bool{}
	pos := []stat{}
	all := stat{}
	for _, r := range recs {
		if len(r.Seq) < minLen {
			minLen = len(r.Seq)
		}
		if len(r.Seq) > maxLen {
			maxLen = len(r.Seq)
		}
		total += len(r.Seq)
		for i := 0; i < len(r.Seq); i++ {
			if i >= len(pos) {
				pos = append(pos, stat{})
			}
			addStat(&pos[i], r.Seq[i], qualAt(r, i), qcut)
			addStat(&all, r.Seq[i], qualAt(r, i), qcut)
			if i < len(r.Qual) {
				qset[r.Qual[i]] = true
			}
		}
	}
	if minLen == 1<<30 {
		minLen = 0
	}
	avg := 0.0
	if len(recs) > 0 {
		avg = float64(total) / float64(len(recs))
	}
	fmt.Printf("min_len: %d; max_len: %d; avg_len: %.2f; %d distinct quality values\n", minLen, maxLen, avg, len(qset))
	fmt.Println("POS\t#bases\t%A\t%C\t%G\t%T\t%N\tavgQ\terrQ\t%low\t%high")
	printStat("ALL", &all)
	for i := range pos {
		printStat(strconv.Itoa(i+1), &pos[i])
	}
	return nil
}

type stat struct {
	n, a, c, g, t, nn, low, high int
	qsum                         int
	esum                         float64
}

func addStat(s *stat, b byte, q, qcut int) {
	s.n++
	s.qsum += q
	s.esum += math.Pow(10, float64(-q)/10)
	if q < qcut {
		s.low++
	} else {
		s.high++
	}
	switch b {
	case 'A', 'a':
		s.a++
	case 'C', 'c':
		s.c++
	case 'G', 'g':
		s.g++
	case 'T', 't':
		s.t++
	default:
		s.nn++
	}
}
func printStat(label string, s *stat) {
	pct := func(x int) float64 {
		if s.n == 0 {
			return 0
		}
		return 100 * float64(x) / float64(s.n)
	}
	avg := 0.0
	errq := 0.0
	if s.n > 0 {
		avg = float64(s.qsum) / float64(s.n)
		if s.esum > 0 {
			errq = -10 * math.Log10(s.esum/float64(s.n))
		}
	}
	fmt.Printf("%s\t%d\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\t%.1f\n", label, s.n, pct(s.a), pct(s.c), pct(s.g), pct(s.t), pct(s.nn), avg, errq, pct(s.low), pct(s.high))
}
func qualAt(r Record, i int) int {
	if i < len(r.Qual) {
		return int(r.Qual[i]) - 33
	}
	return 0
}

func cmdMergePE(args []string) error {
	if len(args) < 2 {
		fmt.Print("Usage: seqtk mergepe <in1.fq> <in2.fq>\n")
		return nil
	}
	a, _ := readRecords(args[0])
	b, _ := readRecords(args[1])
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	for i := 0; i < n; i++ {
		printRecord(os.Stdout, a[i], !a[i].Fastq, 0, false)
		printRecord(os.Stdout, b[i], !b[i].Fastq, 0, false)
	}
	return nil
}
func cmdRename(args []string) error {
	if len(args) < 2 {
		return nil
	}
	recs, err := readRecords(args[0])
	if err != nil {
		return err
	}
	p := args[1]
	for i, r := range recs {
		c := comment(r.Name)
		r.Name = fmt.Sprintf("%s%d", p, i+1)
		if c != "" {
			r.Name += " " + c
		}
		printRecord(os.Stdout, r, !r.Fastq, 0, false)
	}
	return nil
}
func cmdHPC(args []string) error {
	if len(args) < 1 {
		return nil
	}
	recs, err := readRecords(args[len(args)-1])
	if err != nil {
		return err
	}
	for _, r := range recs {
		r.Name = firstName(r.Name)
		r.Seq = hpc(r.Seq)
		r.Fastq = false
		r.Qual = ""
		printRecord(os.Stdout, r, true, 0, false)
	}
	return nil
}
func cmdGap(args []string) error {
	min := 50
	var rest []string
	for i := 0; i < len(args); i++ {
		if strings.HasPrefix(args[i], "-l") {
			if len(args[i]) > 2 {
				min, _ = strconv.Atoi(args[i][2:])
			} else {
				i++
				min, _ = strconv.Atoi(args[i])
			}
		} else {
			rest = append(rest, args[i])
		}
	}
	if len(rest) < 1 {
		fmt.Print("Usage: seqtk gap [-l 50] <in.fa>\n")
		return nil
	}
	recs, _ := readRecords(rest[0])
	for _, r := range recs {
		for _, g := range nRuns(r.Seq, min) {
			fmt.Printf("%s\t%d\t%d\n", firstName(r.Name), g[0], g[1])
		}
	}
	return nil
}
func cmdCutN(args []string) error {
	min := 1000
	gaps := false
	var rest []string
	for i := 0; i < len(args); i++ {
		if args[i] == "-g" {
			gaps = true
		} else if strings.HasPrefix(args[i], "-n") {
			if len(args[i]) > 2 {
				min, _ = strconv.Atoi(args[i][2:])
			} else {
				i++
				min, _ = strconv.Atoi(args[i])
			}
		} else if strings.HasPrefix(args[i], "-p") {
			if len(args[i]) == 2 {
				i++
			}
		} else {
			rest = append(rest, args[i])
		}
	}
	if len(rest) < 1 {
		fmt.Print("\nUsage:   seqtk cutN [options] <in.fa>\n")
		return nil
	}
	recs, _ := readRecords(rest[0])
	for _, r := range recs {
		last := 0
		for _, g := range nRuns(r.Seq, min) {
			if gaps {
				fmt.Printf("%s\t%d\t%d\n", firstName(r.Name), g[0], g[1])
				continue
			}
			if g[0] > last {
				out := Record{Name: fmt.Sprintf("%s:%d-%d", firstName(r.Name), last+1, g[0]), Seq: r.Seq[last:g[0]]}
				printRecord(os.Stdout, out, true, 0, false)
			}
			last = g[1]
		}
		if !gaps && last < len(r.Seq) {
			out := Record{Name: fmt.Sprintf("%s:%d-%d", firstName(r.Name), last+1, len(r.Seq)), Seq: r.Seq[last:]}
			printRecord(os.Stdout, out, true, 0, false)
		}
	}
	return nil
}
func cmdListHet(args []string) error {
	if len(args) < 1 {
		fmt.Print("Usage: seqtk listhet <in.fa>\n")
		return nil
	}
	recs, _ := readRecords(args[0])
	for _, r := range recs {
		for i, b := range r.Seq {
			if strings.ContainsRune("RYSWKMBDHVryswkmbdhv", b) {
				fmt.Printf("%s\t%d\t%c\n", firstName(r.Name), i+1, b)
			}
		}
	}
	return nil
}
func cmdRandBase(args []string) error {
	if len(args) < 1 {
		fmt.Print("Usage: seqtk randbase <in.fa>\n")
		return nil
	}
	recs, _ := readRecords(args[0])
	rng := rand.New(rand.NewSource(11))
	for _, r := range recs {
		b := []byte(r.Seq)
		for i, c := range b {
			b[i] = randAllele(c, rng)
		}
		r.Seq = string(b)
		printRecord(os.Stdout, r, !r.Fastq, 0, false)
	}
	return nil
}

func cmdSplit(args []string) error {
	n := 10
	lineLen := 0
	var rest []string
	for i := 0; i < len(args); i++ {
		if strings.HasPrefix(args[i], "-n") {
			if len(args[i]) > 2 {
				n, _ = strconv.Atoi(args[i][2:])
			} else {
				i++
				n, _ = strconv.Atoi(args[i])
			}
		} else if strings.HasPrefix(args[i], "-l") {
			if len(args[i]) > 2 {
				lineLen, _ = strconv.Atoi(args[i][2:])
			} else {
				i++
				lineLen, _ = strconv.Atoi(args[i])
			}
		} else {
			rest = append(rest, args[i])
		}
	}
	if len(rest) < 2 {
		fmt.Print("Usage: seqtk split [options] <prefix> <in.fa>\n")
		return nil
	}
	recs, _ := readRecords(rest[1])
	if n <= 0 {
		n = 1
	}
	outs := make([]*os.File, n)
	defer func() {
		for _, f := range outs {
			if f != nil {
				f.Close()
			}
		}
	}()
	for i := 0; i < n; i++ {
		f, _ := os.Create(fmt.Sprintf("%s.%d", rest[0], i))
		outs[i] = f
	}
	for i, r := range recs {
		printRecord(outs[i%n], r, !r.Fastq, lineLen, false)
	}
	return nil
}

func cmdMergeFA(args []string) error {
	var rest []string
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			continue
		}
		rest = append(rest, a)
	}
	if len(rest) < 2 {
		fmt.Print("\nUsage: seqtk mergefa [options] <in1.fa> <in2.fa>\n")
		return nil
	}
	a, _ := readRecords(rest[0])
	b, _ := readRecords(rest[1])
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	for i := 0; i < n; i++ {
		s := mergeSeq(a[i].Seq, b[i].Seq)
		printRecord(os.Stdout, Record{Name: firstName(a[i].Name), Seq: s}, true, 0, false)
	}
	return nil
}
func cmdFamask(args []string) error {
	if len(args) < 2 {
		fmt.Print("Usage: seqtk famask <src.fa> <mask.fa>\n")
		return nil
	}
	src, _ := readRecords(args[0])
	mask, _ := readRecords(args[1])
	mm := map[string]Record{}
	for _, r := range mask {
		mm[firstName(r.Name)] = r
	}
	for _, r := range src {
		if m, ok := mm[firstName(r.Name)]; ok {
			b := []byte(r.Seq)
			for i, c := range m.Seq {
				if i < len(b) && (c == 'X' || c == 'x') {
					b[i] = toLower(b[i])
				}
			}
			r.Seq = string(b)
		}
		printRecord(os.Stdout, r, true, 0, false)
	}
	return nil
}
func cmdMutfa(args []string) error {
	if len(args) < 2 {
		fmt.Print("Usage: seqtk mutfa <in.fa> <in.snp>\n")
		return nil
	}
	recs, _ := readRecords(args[0])
	muts := map[string]map[int]byte{}
	rc, _ := openInput(args[1])
	if rc != nil {
		defer rc.Close()
		sc := bufio.NewScanner(rc)
		for sc.Scan() {
			f := strings.Fields(sc.Text())
			if len(f) >= 4 {
				p, _ := strconv.Atoi(f[1])
				if muts[f[0]] == nil {
					muts[f[0]] = map[int]byte{}
				}
				muts[f[0]][p-1] = f[3][0]
			}
		}
	}
	for _, r := range recs {
		b := []byte(r.Seq)
		for p, c := range muts[firstName(r.Name)] {
			if p >= 0 && p < len(b) {
				b[p] = c
			}
		}
		r.Seq = string(b)
		printRecord(os.Stdout, r, true, 0, false)
	}
	return nil
}
func cmdTelo(args []string) error {
	path := ""
	if len(args) > 0 {
		path = args[len(args)-1]
	}
	recs, _ := readRecords(path)
	n, b := 0, 0
	for _, r := range recs {
		n++
		b += len(r.Seq)
	}
	fmt.Fprintf(os.Stderr, "%d\t%d\n", n, b)
	return nil
}
func cmdHety(args []string) error {
	if len(args) < 1 {
		fmt.Print("\nUsage:   seqtk hety [options] <in.fa>\n\nOptions: -w INT   window size [50000]\n         -t INT   # start positions in a window [5]\n         -m       treat lowercases as masked\n")
	}
	return nil
}
func cmdGC(args []string) error {
	if len(args) < 1 {
		fmt.Print("Usage: seqtk gc [options] <in.fa>\nOptions:\n  -w         identify high-AT regions\n  -f FLOAT   min GC fraction (or AT fraction for -w) [0.60]\n  -l INT     min region length to output [20]\n  -x FLOAT   X-dropoff [10.0]\n")
		return nil
	}
	recs, err := readRecords(args[len(args)-1])
	if err != nil {
		return err
	}
	for _, r := range recs {
		gc := 0
		for i := range r.Seq {
			if r.Seq[i] == 'G' || r.Seq[i] == 'g' || r.Seq[i] == 'C' || r.Seq[i] == 'c' {
				gc++
			}
		}
		if len(r.Seq) > 0 {
			fmt.Printf("%s\t0\t%d\t%.3f\n", firstName(r.Name), len(r.Seq), float64(gc)/float64(len(r.Seq)))
		}
	}
	return nil
}
func cmdDropSE(args []string) error {
	if len(args) < 1 {
		return nil
	}
	recs, err := readRecords(args[len(args)-1])
	if err != nil {
		return err
	}
	for i := 0; i+1 < len(recs); i += 2 {
		if stripPair(firstName(recs[i].Name)) == stripPair(firstName(recs[i+1].Name)) {
			printRecord(os.Stdout, recs[i], !recs[i].Fastq, 0, false)
			printRecord(os.Stdout, recs[i+1], !recs[i+1].Fastq, 0, false)
		}
	}
	return nil
}

func revcomp(s string) string {
	out := make([]byte, len(s))
	for i := range s {
		out[len(s)-1-i] = compBase(s[i])
	}
	return string(out)
}
func compBase(b byte) byte {
	switch b {
	case 'A':
		return 'T'
	case 'a':
		return 't'
	case 'C':
		return 'G'
	case 'c':
		return 'g'
	case 'G':
		return 'C'
	case 'g':
		return 'c'
	case 'T', 'U':
		return 'A'
	case 't', 'u':
		return 'a'
	case 'N':
		return 'N'
	case 'n':
		return 'n'
	default:
		return b
	}
}
func reverse(s string) string {
	b := []byte(s)
	for i, j := 0, len(b)-1; i < j; i, j = i+1, j-1 {
		b[i], b[j] = b[j], b[i]
	}
	return string(b)
}
func toLower(b byte) byte {
	if b >= 'A' && b <= 'Z' {
		return b + 32
	}
	return b
}
func maskLower(s string, st, en int) string {
	b := []byte(s)
	st = clamp(st, 0, len(b))
	en = clamp(en, 0, len(b))
	for i := st; i < en; i++ {
		b[i] = toLower(b[i])
	}
	return string(b)
}
func clamp(x, a, b int) int {
	if x < a {
		return a
	}
	if x > b {
		return b
	}
	return x
}
func atoiOK(s string) (int, bool) { v, e := strconv.Atoi(s); return v, e == nil }
func comment(s string) string {
	if i := strings.IndexAny(s, " \t"); i >= 0 {
		return strings.TrimSpace(s[i+1:])
	}
	return ""
}
func hpc(s string) string {
	if s == "" {
		return s
	}
	out := []byte{s[0]}
	last := baseUpper(s[0])
	for i := 1; i < len(s); i++ {
		if baseUpper(s[i]) != last {
			out = append(out, s[i])
			last = baseUpper(s[i])
		}
	}
	return string(out)
}
func baseUpper(b byte) byte {
	if b >= 'a' && b <= 'z' {
		return b - 32
	}
	return b
}
func nRuns(s string, min int) [][2]int {
	var out [][2]int
	i := 0
	for i < len(s) {
		if s[i] == 'N' || s[i] == 'n' {
			j := i
			for j < len(s) && (s[j] == 'N' || s[j] == 'n') {
				j++
			}
			if j-i >= min {
				out = append(out, [2]int{i, j})
			}
			i = j
		} else {
			i++
		}
	}
	return out
}
func randAllele(c byte, rng *rand.Rand) byte {
	m := map[byte]string{'R': "AG", 'Y': "CT", 'S': "CG", 'W': "AT", 'K': "GT", 'M': "AC", 'B': "CGT", 'D': "AGT", 'H': "ACT", 'V': "ACG", 'r': "ag", 'y': "ct", 's': "cg", 'w': "at", 'k': "gt", 'm': "ac", 'b': "cgt", 'd': "agt", 'h': "act", 'v': "acg"}
	if s, ok := m[c]; ok {
		return s[rng.Intn(len(s))]
	}
	return c
}
func mergeSeq(a, b string) string {
	n := len(a)
	if len(b) < n {
		n = len(b)
	}
	out := make([]byte, n)
	for i := 0; i < n; i++ {
		if a[i] == 'N' || a[i] == 'n' {
			out[i] = b[i]
		} else {
			out[i] = a[i]
		}
	}
	return string(out)
}
func filepathBaseNoExt(p string) string {
	b := filepath.Base(p)
	return strings.TrimSuffix(b, filepath.Ext(b))
}
func stripPair(s string) string {
	for _, suf := range []string{"/1", "/2", ".1", ".2"} {
		if strings.HasSuffix(s, suf) {
			return strings.TrimSuffix(s, suf)
		}
	}
	return s
}
