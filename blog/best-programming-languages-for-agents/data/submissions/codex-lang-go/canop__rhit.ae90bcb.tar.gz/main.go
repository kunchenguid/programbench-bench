package main

import (
	"bufio"
	"compress/gzip"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "2.0.4"

type options struct {
	color      string
	key        string
	length     int
	fields     string
	changes    bool
	date       string
	ip         string
	method     string
	path       string
	referer    string
	status     string
	timeOfDay  string
	allPaths   bool
	noName     bool
	output     string
	silentLoad bool
}

type hit struct {
	Date       string `json:"date"`
	Time       string `json:"time"`
	RemoteAddr string `json:"remote_addr"`
	Method     string `json:"method"`
	Path       string `json:"path"`
	Status     string `json:"status"`
	BytesSent  int64  `json:"bytes_sent"`
	Referer    string `json:"referer"`
	Raw        string `json:"-"`
	Stamp      time.Time `json:"-"`
}

type multiFlag struct{ vals []string }

func (m *multiFlag) String() string { return strings.Join(m.vals, ",") }
func (m *multiFlag) Set(v string) error { m.vals = append(m.vals, v); return nil }

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	if len(args) == 1 && args[0] == "--version" {
		fmt.Printf("rhit %s\n", version)
		return 0
	}
	if len(args) == 1 && args[0] == "--help" {
		printHelp()
		return 0
	}
	opts, files, err := parseArgs(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		return 1
	}
	if opts.output == "" {
		opts.output = "tables"
	}
	opts.output = normalizeOutput(opts.output)
	if opts.key == "" {
		opts.key = "hits"
	}
	opts.key = normalizeKey(opts.key)
	if opts.length < 0 {
		opts.length = 1
	}
	if len(files) == 0 {
		files = defaultFiles()
	}
	paths := expandFiles(files, opts.noName)
	var hits []hit
	for _, p := range paths {
		if err := readLog(p, func(h hit) {
			if keep(h, opts) {
				hits = append(hits, h)
				if opts.output == "raw" {
					fmt.Println(h.Raw)
				}
			}
		}); err != nil && !errors.Is(err, os.ErrNotExist) {
			fmt.Fprintln(os.Stderr, "Error:", err)
			return 1
		}
	}
	sort.SliceStable(hits, func(i, j int) bool { return hits[i].Stamp.Before(hits[j].Stamp) })
	switch opts.output {
	case "raw":
		return 0
	case "csv":
		printCSV(hits)
	case "json":
		b, _ := json.MarshalIndent(hits, "", "  ")
		fmt.Println(string(b))
	default:
		printTables(hits, opts)
	}
	return 0
}

func parseArgs(args []string) (options, []string, error) {
	var opts options
	var fields multiFlag
	fs := flag.NewFlagSet("rhit", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.StringVar(&opts.color, "color", "auto", "")
	fs.StringVar(&opts.key, "key", "hits", "")
	fs.StringVar(&opts.key, "k", "hits", "")
	fs.IntVar(&opts.length, "length", 1, "")
	fs.IntVar(&opts.length, "l", 1, "")
	fs.Var(&fields, "fields", "")
	fs.Var(&fields, "field", "")
	fs.Var(&fields, "f", "")
	fs.BoolVar(&opts.changes, "changes", false, "")
	fs.BoolVar(&opts.changes, "c", false, "")
	fs.StringVar(&opts.date, "date", "", "")
	fs.StringVar(&opts.date, "d", "", "")
	fs.StringVar(&opts.ip, "ip", "", "")
	fs.StringVar(&opts.ip, "i", "", "")
	fs.StringVar(&opts.method, "method", "", "")
	fs.StringVar(&opts.method, "m", "", "")
	fs.StringVar(&opts.path, "path", "", "")
	fs.StringVar(&opts.path, "p", "", "")
	fs.StringVar(&opts.referer, "referer", "", "")
	fs.StringVar(&opts.referer, "r", "", "")
	fs.StringVar(&opts.status, "status", "", "")
	fs.StringVar(&opts.status, "s", "", "")
	fs.StringVar(&opts.timeOfDay, "time", "", "")
	fs.StringVar(&opts.timeOfDay, "t", "", "")
	fs.BoolVar(&opts.allPaths, "all", false, "")
	fs.BoolVar(&opts.allPaths, "a", false, "")
	fs.BoolVar(&opts.noName, "no-name-check", false, "")
	fs.StringVar(&opts.output, "output", "tables", "")
	fs.StringVar(&opts.output, "o", "tables", "")
	fs.BoolVar(&opts.silentLoad, "silent-load", false, "")
	fs.BoolFunc("version", "", func(string) error { fmt.Printf("rhit %s\n", version); os.Exit(0); return nil })
	fs.BoolFunc("help", "", func(string) error { printHelp(); os.Exit(0); return nil })
	if err := fs.Parse(args); err != nil {
		return opts, nil, err
	}
	if len(fields.vals) > 0 {
		opts.fields = strings.Join(fields.vals, "+")
	}
	return opts, fs.Args(), nil
}

func printHelp() {
	fmt.Printf(`rhit %s

Rhit analyzes your nginx logs.

Complete documentation at https://dystroy.org/rhit

Usage: rhit [options] [FILES]

Options:
    --help                  Print help information
    --version               Print the version
    --color <auto|yes|no>   Whether to have styles and colors
 -k --key <hits|bytes>      Key used in sorting and histogram
 -l --length <0..6>         Detail level, impacts table lengths
 -f --fields <FIELDS>       Fields: date,time,method,status,ip,ref,path
 -c --changes               Add tables with more/less popular entries
 -d --date <DATE>           Filter dates on a day or inclusive range
 -i --ip <IP>               IP address filter, negatable with !
 -m --method <METHOD>       HTTP method filter, negatable with !
 -p --path <PATH>           Pattern for path filtering
 -r --referer <REFERER>     Referrer filter
 -s --status <STATUS>       Status list/range filter
 -t --time <TIME>           Filter time of day
 -a --all                   Show all paths, including resources
    --no-name-check         Try to open all files
 -o --output <OUTPUT>       tables, raw, csv, or json
    --silent-load           Don't print progress during load
`, version)
}

func normalizeOutput(s string) string {
	s = strings.ToLower(s)
	switch s {
	case "r":
		return "raw"
	case "c":
		return "csv"
	case "j":
		return "json"
	case "t":
		return "tables"
	}
	return s
}

func normalizeKey(s string) string {
	s = strings.ToLower(s)
	if strings.HasPrefix(s, "b") {
		return "bytes"
	}
	return "hits"
}

func defaultFiles() []string {
	var out []string
	for _, d := range []string{"/var/log/nginx", "/var/log"} {
		m, _ := filepath.Glob(filepath.Join(d, "access.log*"))
		out = append(out, m...)
	}
	return out
}

func expandFiles(inputs []string, noName bool) []string {
	seen := map[string]bool{}
	var out []string
	var add func(string)
	add = func(p string) {
		st, err := os.Stat(p)
		if err != nil {
			if !seen[p] { out = append(out, p); seen[p] = true }
			return
		}
		if st.IsDir() {
			entries, _ := os.ReadDir(p)
			for _, e := range entries {
				add(filepath.Join(p, e.Name()))
			}
			return
		}
		if noName || looksLikeLog(p) {
			if !seen[p] { out = append(out, p); seen[p] = true }
		}
	}
	for _, p := range inputs {
		add(p)
	}
	sort.Strings(out)
	return out
}

func looksLikeLog(p string) bool {
	base := filepath.Base(p)
	return strings.Contains(base, "access") || strings.HasSuffix(base, ".log") || strings.HasSuffix(base, ".log.gz") || strings.HasSuffix(base, ".gz")
}

var logRe = regexp.MustCompile(`^(\S+) \S+ \S+ \[([^\]]+)\] "([^"]*)" (\d{3}) (\S+) "([^"]*)"`)

func readLog(path string, emit func(hit)) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	var r io.Reader = f
	if strings.HasSuffix(path, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			return err
		}
		defer gz.Close()
		r = gz
	}
	sc := bufio.NewScanner(r)
	buf := make([]byte, 0, 1024*1024)
	sc.Buffer(buf, 16*1024*1024)
	for sc.Scan() {
		raw := sc.Text()
		if h, ok := parseLine(raw); ok {
			emit(h)
		}
	}
	return sc.Err()
}

func parseLine(raw string) (hit, bool) {
	m := logRe.FindStringSubmatch(raw)
	if m == nil {
		return hit{}, false
	}
	t, err := time.Parse("02/Jan/2006:15:04:05 -0700", m[2])
	if err != nil {
		return hit{}, false
	}
	req := m[3]
	method := "none"
	path := req
	parts := strings.Fields(req)
	if len(parts) >= 2 {
		method = parts[0]
		path = parts[1]
	}
	n, _ := strconv.ParseInt(m[5], 10, 64)
	return hit{
		Date: t.Format("2006/01/02"), Time: t.Format("15:04:05"), RemoteAddr: m[1],
		Method: method, Path: path, Status: m[4], BytesSent: n, Referer: m[6],
		Raw: raw, Stamp: t,
	}, true
}

func keep(h hit, o options) bool {
	if o.date != "" && !matchDateTime(h.Stamp, o.date) { return false }
	if o.timeOfDay != "" && !matchTimeOfDay(h.Time, o.timeOfDay) { return false }
	if o.ip != "" && !matchText(h.RemoteAddr, o.ip) { return false }
	if o.method != "" && !matchMethod(h.Method, o.method) { return false }
	if o.path != "" && !matchExpr(h.Path, o.path) { return false }
	if o.referer != "" && !matchExpr(h.Referer, o.referer) { return false }
	if o.status != "" && !matchStatus(h.Status, o.status) { return false }
	return true
}

func matchText(s, pat string) bool {
	neg := strings.HasPrefix(pat, "!")
	if neg { pat = strings.TrimPrefix(pat, "!") }
	ok := regexMatch(s, pat)
	if neg { return !ok }
	return ok
}

func matchMethod(s, pat string) bool {
	p := strings.TrimSpace(pat)
	neg := strings.HasPrefix(p, "!")
	if neg { p = strings.TrimPrefix(p, "!") }
	var ok bool
	if strings.EqualFold(p, "other") {
		switch s {
		case "GET", "POST", "HEAD", "PUT", "DELETE", "PATCH", "OPTIONS", "CONNECT", "TRACE", "none":
			ok = false
		default:
			ok = true
		}
	} else {
		ok = strings.EqualFold(s, p)
	}
	if neg { return !ok }
	return ok
}

func regexMatch(s, pat string) bool {
	re, err := regexp.Compile(pat)
	if err != nil {
		return strings.Contains(s, pat)
	}
	return re.MatchString(s)
}

func matchExpr(s, expr string) bool {
	expr = strings.TrimSpace(expr)
	if strings.Contains(expr, ",") {
		for _, part := range strings.Split(expr, ",") {
			if !matchExpr(s, part) { return false }
		}
		return true
	}
	if strings.HasPrefix(expr, "!") {
		return !matchExpr(s, strings.TrimSpace(expr[1:]))
	}
	if strings.Contains(expr, " | ") {
		for _, part := range strings.Split(expr, " | ") {
			if matchExpr(s, part) { return true }
		}
		return false
	}
	if strings.Contains(expr, " & ") {
		for _, part := range strings.Split(expr, " & ") {
			if !matchExpr(s, part) { return false }
		}
		return true
	}
	expr = strings.Trim(expr, " ")
	if strings.HasPrefix(expr, "(") && strings.HasSuffix(expr, ")") {
		return matchExpr(s, strings.TrimSpace(expr[1:len(expr)-1]))
	}
	return regexMatch(s, expr)
}

func matchStatus(status, spec string) bool {
	code, err := strconv.Atoi(status)
	if err != nil { return false }
	anyPositive := false
	result := false
	for _, tok := range strings.Split(spec, ",") {
		tok = strings.TrimSpace(tok)
		if tok == "" { continue }
		neg := strings.HasPrefix(tok, "!")
		if neg { tok = tok[1:] } else { anyPositive = true }
		ok := statusToken(code, tok)
		if neg && ok { return false }
		if !neg && ok { result = true }
	}
	if !anyPositive { return true }
	return result
}

func statusToken(code int, tok string) bool {
	if strings.HasSuffix(tok, "xx") && len(tok) == 3 {
		n, _ := strconv.Atoi(tok[:1])
		return code/100 == n
	}
	if strings.Contains(tok, "-") {
		p := strings.SplitN(tok, "-", 2)
		a, _ := strconv.Atoi(p[0]); b, _ := strconv.Atoi(p[1])
		return code >= a && code <= b
	}
	n, err := strconv.Atoi(tok)
	return err == nil && code == n
}

func matchTimeOfDay(hhmmss, spec string) bool {
	sec := parseClock(hhmmss)
	s := strings.TrimSpace(spec)
	if strings.HasPrefix(s, ">=") { return sec >= parseClock(s[2:]) }
	if strings.HasPrefix(s, "<=") { return sec <= parseClock(s[2:]) }
	if strings.HasPrefix(s, ">") { return sec > parseClock(s[1:]) }
	if strings.HasPrefix(s, "<") { return sec < parseClock(s[1:]) }
	if strings.Contains(s, "-") {
		p := strings.SplitN(s, "-", 2)
		return sec >= parseClock(p[0]) && sec <= parseClock(p[1])
	}
	return sec == parseClock(s)
}

func parseClock(s string) int {
	p := strings.Split(strings.TrimSpace(s), ":")
	h, _ := strconv.Atoi(p[0]); m, sec := 0, 0
	if len(p) > 1 { m, _ = strconv.Atoi(p[1]) }
	if len(p) > 2 { sec, _ = strconv.Atoi(p[2]) }
	return h*3600 + m*60 + sec
}

func matchDateTime(t time.Time, spec string) bool {
	s := strings.TrimSpace(spec)
	neg := strings.HasPrefix(s, "!")
	if neg { s = strings.TrimSpace(s[1:]) }
	var ok bool
	if strings.HasPrefix(s, ">") {
		b, _ := parseDateBound(s[1:], false)
		ok = t.After(b)
	} else if strings.HasPrefix(s, "<") {
		b, _ := parseDateBound(s[1:], true)
		ok = t.Before(b)
	} else if strings.Contains(s, "-") {
		p := strings.SplitN(s, "-", 2)
		a, _ := parseDateBound(p[0], false)
		b, _ := parseDateBound(p[1], true)
		ok = !t.Before(a) && !t.After(b)
	} else {
		a, _ := parseDateBound(s, false)
		b, _ := parseDateBound(s, true)
		ok = !t.Before(a) && !t.After(b)
	}
	if neg { return !ok }
	return ok
}

func parseDateBound(s string, end bool) (time.Time, error) {
	s = strings.TrimSpace(strings.ReplaceAll(s, "T", "/"))
	dateTime := strings.Split(s, "/")
	now := time.Now()
	y, m, d := now.Year(), int(time.January), 1
	hh, mm, ss := 0, 0, 0
	if len(dateTime) > 0 && len(dateTime[0]) == 4 {
		y, _ = strconv.Atoi(dateTime[0])
		if len(dateTime) > 1 { m, _ = strconv.Atoi(dateTime[1]) }
		if len(dateTime) > 2 { d, _ = strconv.Atoi(strings.Split(dateTime[2], ":")[0]) }
	} else {
		y = 0
		if len(dateTime) > 0 { m, _ = strconv.Atoi(dateTime[0]) }
		if len(dateTime) > 1 { d, _ = strconv.Atoi(strings.Split(dateTime[1], ":")[0]) }
	}
	if y == 0 { y = now.Year() }
	last := dateTime[len(dateTime)-1]
	if strings.Contains(last, ":") {
		timePart := last[strings.Index(last, ":")-2:]
		tp := strings.Split(timePart, ":")
		hh, _ = strconv.Atoi(tp[0])
		if len(tp) > 1 { mm, _ = strconv.Atoi(tp[1]) }
		if len(tp) > 2 { ss, _ = strconv.Atoi(tp[2]) }
	} else if end {
		hh, mm, ss = 23, 59, 59
		if len(dateTime) == 1 && len(dateTime[0]) == 4 {
			m, d = 12, 31
		} else if len(dateTime) == 2 && len(dateTime[0]) == 4 {
			d = daysInMonth(y, time.Month(m))
		}
	}
	return time.Date(y, time.Month(m), d, hh, mm, ss, 0, time.Local), nil
}

func daysInMonth(y int, m time.Month) int {
	return time.Date(y, m+1, 0, 0, 0, 0, 0, time.Local).Day()
}

func csvQuote(s string) string {
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func printCSV(hits []hit) {
	fmt.Println("date,time,remote address,method,path,status,bytes sent,referer")
	for _, h := range hits {
		fmt.Printf("%s,%s,%s,%s,%s,%s,%d,%s\n", h.Date, h.Time, h.RemoteAddr, h.Method, csvQuote(h.Path), h.Status, h.BytesSent, csvQuote(h.Referer))
	}
}

type agg struct{ hits int; bytes int64 }

func printTables(hits []hit, o options) {
	totalBytes := int64(0)
	for _, h := range hits { totalBytes += h.BytesSent }
	if len(hits) == 0 {
		fmt.Println("No hit")
		return
	}
	fmt.Printf("%d hits and %d from %s to %s\n", len(hits), totalBytes, hits[0].Date, hits[len(hits)-1].Date)
	fields := fieldList(o.fields)
	for _, f := range fields {
		switch f {
		case "date": printAgg("date", hits, func(h hit) string { return h.Date }, o)
		case "time": printAgg("hour", hits, func(h hit) string { return strings.Split(h.Time, ":")[0] }, o)
		case "method": printAgg("methods", hits, func(h hit) string { return h.Method }, o)
		case "status": printAgg("HTTP status codes", hits, func(h hit) string { return h.Status }, o)
		case "ip": printAgg("remote IP addresses", hits, func(h hit) string { return h.RemoteAddr }, o)
		case "ref": printAgg("referrers", hits, func(h hit) string { if h.Referer == "-" { return "" }; return h.Referer }, o)
		case "path": printAgg("paths", hits, func(h hit) string { if !o.allPaths && isResource(h.Path) { return "" }; return h.Path }, o)
		}
	}
}

func fieldList(spec string) []string {
	def := []string{"date", "status", "ref", "path"}
	if spec == "" { return def }
	all := []string{"date", "time", "method", "status", "ip", "ref", "path"}
	cur := []string{}
	if strings.HasPrefix(spec, "+") || strings.HasPrefix(spec, "-") { cur = append(cur, def...) }
	toks := regexp.MustCompile(`[+-]?[^+-]+`).FindAllString(spec, -1)
	for _, tok := range toks {
		op := byte(0)
		if tok[0] == '+' || tok[0] == '-' { op = tok[0]; tok = tok[1:] }
		for _, f := range strings.Split(tok, ",") {
			name := fieldName(strings.TrimSpace(f))
			names := []string{name}
			if name == "all" { names = all }
			for _, n := range names {
				if op == '-' {
					cur = remove(cur, n)
				} else {
					cur = append(remove(cur, n), n)
				}
			}
		}
	}
	return cur
}

func fieldName(s string) string {
	switch strings.ToLower(s) {
	case "a", "all": return "all"
	case "d", "date", "dates": return "date"
	case "t", "time": return "time"
	case "m", "method", "methods": return "method"
	case "s", "status": return "status"
	case "i", "ip": return "ip"
	case "r", "ref", "referer", "referrer": return "ref"
	case "p", "path", "paths": return "path"
	}
	return s
}

func remove(xs []string, x string) []string {
	var out []string
	for _, v := range xs { if v != x { out = append(out, v) } }
	return out
}

func printAgg(title string, hits []hit, keyfn func(hit) string, o options) {
	m := map[string]agg{}
	for _, h := range hits {
		k := keyfn(h)
		if k == "" { continue }
		a := m[k]; a.hits++; a.bytes += h.BytesSent; m[k] = a
	}
	type row struct{ k string; a agg }
	var rows []row
	for k, a := range m { rows = append(rows, row{k, a}) }
	sort.Slice(rows, func(i, j int) bool {
		if o.key == "bytes" && rows[i].a.bytes != rows[j].a.bytes { return rows[i].a.bytes > rows[j].a.bytes }
		if rows[i].a.hits != rows[j].a.hits { return rows[i].a.hits > rows[j].a.hits }
		return rows[i].k < rows[j].k
	})
	limit := tableLimit(o.length)
	if len(rows) > limit { rows = rows[:limit] }
	if title == "date" || title == "hour" {
		fmt.Println(title)
	} else if strings.Contains(title, "addresses") || title == "referrers" || title == "paths" {
		fmt.Printf("%d %s\n", len(m), title)
	} else {
		fmt.Println(title)
	}
	fmt.Println("value,hits,bytes")
	for _, r := range rows {
		fmt.Printf("%s,%d,%d\n", r.k, r.a.hits, r.a.bytes)
	}
}

func tableLimit(length int) int {
	switch {
	case length <= 0: return 5
	case length == 1: return 10
	case length == 2: return 20
	case length == 3: return 40
	default: return 1000000
	}
}

func isResource(p string) bool {
	l := strings.ToLower(strings.Split(p, "?")[0])
	for _, ext := range []string{".png", ".jpg", ".jpeg", ".gif", ".svg", ".css", ".js", ".ico", ".webp", ".woff", ".woff2", ".ttf", ".map"} {
		if strings.HasSuffix(l, ext) { return true }
	}
	return false
}
