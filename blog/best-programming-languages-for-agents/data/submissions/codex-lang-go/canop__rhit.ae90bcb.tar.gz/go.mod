module rhit-reimplementation

go 1.21
