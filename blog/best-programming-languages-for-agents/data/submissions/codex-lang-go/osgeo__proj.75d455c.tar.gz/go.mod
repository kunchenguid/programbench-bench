module programbench/projclone

go 1.21
