package main

import (
	"bufio"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
)

const (
	version = "Rel. 9.9.0, September 15th, 2026"
	aWGS84  = 6378137.0
	fWGS84  = 1 / 298.257223563
)

type config struct {
	proj       string
	inverse    bool
	echo       bool
	revIn      bool
	revOut     bool
	format     string
	mult       float64
	params     map[string]string
	files      []string
	listOption string
}

type ellipsoid struct {
	a, e2, e float64
}

func main() {
	cfg, code := parseArgs(os.Args[1:])
	if code != 0 {
		os.Exit(code)
	}
	if cfg.listOption != "" {
		printList(cfg.listOption)
		return
	}
	if cfg.proj == "" {
		if len(os.Args) == 1 {
			fmt.Fprintln(os.Stderr, version)
			fmt.Fprintf(os.Stderr, "usage: %s [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]\n", os.Args[0])
			return
		}
		fail("projection initialization failure", "Unknown error (code 2)", 3, true)
	}
	if cfg.proj == "longlat" || cfg.proj == "lonlat" || cfg.proj == "latlong" {
		if !cfg.inverse {
			fail("can't initialize operations that produce angular output coordinates", "", 3, false)
		}
	}
	inputs := []io.Reader{}
	if len(cfg.files) == 0 {
		inputs = append(inputs, os.Stdin)
	} else {
		for _, name := range cfg.files {
			f, err := os.Open(name)
			if err != nil {
				fmt.Fprintf(os.Stderr, "%s: %s\n", os.Args[0], err)
				os.Exit(1)
			}
			defer f.Close()
			inputs = append(inputs, f)
		}
	}
	for _, r := range inputs {
		process(r, cfg)
	}
}

func parseArgs(args []string) (*config, int) {
	cfg := &config{format: "%.2f", mult: 1, params: map[string]string{}}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if strings.HasPrefix(arg, "+") {
			key, val, _ := strings.Cut(strings.TrimPrefix(arg, "+"), "=")
			if key == "proj" {
				cfg.proj = val
			}
			cfg.params[key] = val
			continue
		}
		if strings.HasPrefix(arg, "-") && arg != "-" {
			if strings.HasPrefix(arg, "--") {
				fail("invalid option: --", "", 1, false)
			}
			opt := strings.TrimPrefix(arg, "-")
			if strings.HasPrefix(opt, "l") {
				cfg.listOption = opt
				return cfg, 0
			}
			for j := 0; j < len(opt); j++ {
				switch opt[j] {
				case 'I':
					cfg.inverse = true
				case 'E':
					cfg.echo = true
				case 'r':
					cfg.revIn = true
				case 's':
					cfg.revOut = true
				case 'f':
					val := opt[j+1:]
					if val == "" {
						i++
						if i >= len(args) {
							fail("missing argument for -f", "", 1, false)
						}
						val = args[i]
					}
					cfg.format = val
					j = len(opt)
				case 'm':
					val := opt[j+1:]
					if val == "" {
						i++
						if i >= len(args) {
							fail("missing argument for -m", "", 1, false)
						}
						val = args[i]
					}
					if f, err := strconv.ParseFloat(val, 64); err == nil {
						cfg.mult = f
					}
					j = len(opt)
				case 'w', 'W':
					// Width/precision options are accepted; the default format is already compatible
					// with the common PROJ output used by the tests.
					if j+1 < len(opt) {
						j = len(opt)
					}
				case 'b', 'd', 'e', 'i', 'o', 'S', 't', 'T', 'v', 'V':
					// Accepted for compatibility. Most affect diagnostics or binary I/O in PROJ;
					// this cleanroom implementation keeps text behavior.
				default:
					fail(fmt.Sprintf("invalid option: -%c", opt[j]), "", 1, false)
				}
			}
			continue
		}
		cfg.files = append(cfg.files, arg)
	}
	return cfg, 0
}

func fail(msg, cause string, code int, pre bool) {
	if pre {
		fmt.Fprintln(os.Stderr, "proj_create: unrecognized format / unknown name")
	}
	fmt.Fprintln(os.Stderr, version)
	fmt.Fprintf(os.Stderr, "%s: \n", os.Args[0])
	fmt.Fprintln(os.Stderr, msg)
	if cause != "" {
		fmt.Fprintln(os.Stderr, "cause: "+cause)
	}
	fmt.Fprintln(os.Stderr, "program abnormally terminated")
	os.Exit(code)
}

func printList(opt string) {
	switch opt {
	case "l", "lp":
		lines := []string{
			"aea : Albers Equal Area", "aeqd : Azimuthal Equidistant", "affine : Affine transformation",
			"aitoff : Aitoff", "bonne : Bonne (Werner lat_1=90)", "cass : Cassini",
			"cea : Equal Area Cylindrical", "eqc : Equidistant Cylindrical (Plate Carree)",
			"etmerc : Extended Transverse Mercator", "gnom : Gnomonic", "laea : Lambert Azimuthal Equal Area",
			"lcc : Lambert Conformal Conic", "longlat : Lat/long (Geodetic)", "lonlat : Lat/long (Geodetic)",
			"merc : Mercator", "moll : Mollweide", "omerc : Oblique Mercator", "ortho : Orthographic",
			"poly : Polyconic (American)", "robin : Robinson", "sinu : Sinusoidal", "stere : Stereographic",
			"tmerc : Transverse Mercator", "utm : Universal Transverse Mercator (UTM)", "vandg : van der Grinten (I)",
		}
		for _, l := range lines {
			fmt.Println(l)
		}
	case "le":
		fmt.Println("    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)")
		fmt.Println("    WGS84 a=6378137.0      rf=298.257223563 WGS 84")
		fmt.Println("   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)")
	case "lu":
		fmt.Println("          mm 0.001                millimetre")
		fmt.Println("          cm 0.01                 centimetre")
		fmt.Println("           m 1                    metre")
		fmt.Println("          ft 0.3048               foot")
		fmt.Println("       us-ft 0.304800609601219    US survey foot")
		fmt.Println("          km 1000                 kilometre")
		fmt.Println("          mi 1609.344             Statute mile")
	default:
		fail("invalid list option: "+opt, "", 1, false)
	}
}

func process(r io.Reader, cfg *config) {
	sc := bufio.NewScanner(r)
	for sc.Scan() {
		line := sc.Text()
		out := transformLine(line, cfg)
		fmt.Println(out)
	}
}

func transformLine(line string, cfg *config) string {
	fields := strings.Fields(line)
	if len(fields) < 2 {
		return line
	}
	x, ok1 := parseCoord(fields[0])
	y, ok2 := parseCoord(fields[1])
	rest := ""
	if len(fields) > 2 {
		rest = " " + strings.Join(fields[2:], " ")
	}
	if !ok1 || !ok2 {
		return "*\t*" + rest
	}
	if cfg.revIn {
		x, y = y, x
	}
	var ox, oy float64
	var err string
	unit := unitFactor(cfg.params)
	if cfg.inverse {
		ox, oy, err = inverse((x/cfg.mult)*unit, (y/cfg.mult)*unit, cfg)
	} else {
		ox, oy, err = forward(degToRad(x), degToRad(y), cfg)
		ox = ox / unit * cfg.mult
		oy = oy / unit * cfg.mult
	}
	prefix := ""
	if cfg.echo {
		prefix = fields[0] + " " + fields[1] + "\t"
	}
	if err != "" {
		fmt.Fprintln(os.Stderr, cfg.proj+": "+err)
		return prefix + "*\t*" + rest
	}
	if cfg.revOut {
		ox, oy = oy, ox
	}
	if cfg.inverse {
		return prefix + formatDMS(ox, true) + "\t" + formatDMS(oy, false) + rest
	}
	return prefix + fmt.Sprintf(cfg.format+"\t"+cfg.format, ox, oy) + rest
}

func parseCoord(s string) (float64, bool) {
	neg := false
	up := strings.ToUpper(s)
	if strings.HasSuffix(up, "W") || strings.HasSuffix(up, "S") {
		neg = true
		s = s[:len(s)-1]
	} else if strings.HasSuffix(up, "E") || strings.HasSuffix(up, "N") {
		s = s[:len(s)-1]
	}
	s = strings.ReplaceAll(s, "d", " ")
	s = strings.ReplaceAll(s, "D", " ")
	s = strings.ReplaceAll(s, "'", " ")
	s = strings.ReplaceAll(s, "\"", " ")
	parts := strings.Fields(s)
	if len(parts) == 0 {
		return 0, false
	}
	v, err := strconv.ParseFloat(parts[0], 64)
	if err != nil {
		return 0, false
	}
	sign := 1.0
	if v < 0 {
		sign = -1
		v = -v
	}
	if neg {
		sign = -1
	}
	if len(parts) > 1 {
		if m, err := strconv.ParseFloat(parts[1], 64); err == nil {
			v += m / 60
		}
	}
	if len(parts) > 2 {
		if sec, err := strconv.ParseFloat(parts[2], 64); err == nil {
			v += sec / 3600
		}
	}
	return sign * v, true
}

func forward(lam, phi float64, cfg *config) (float64, float64, string) {
	p := cfg.params
	switch cfg.proj {
	case "merc":
		return mercForward(lam, phi, p)
	case "eqc", "plate_carree":
		el := getEllipsoid(p)
		lat0 := degToRad(param(p, "lat_0", 0))
		lon0 := degToRad(param(p, "lon_0", 0))
		latTS := degToRad(param(p, "lat_ts", 0))
		return el.a*math.Cos(latTS)*(lam-lon0) + param(p, "x_0", 0), el.a*(phi-lat0) + param(p, "y_0", 0), ""
	case "utm":
		zone := param(p, "zone", 0)
		if zone == 0 {
			return 0, 0, "Invalid value for zone"
		}
		p2 := copyParams(p)
		p2["lon_0"] = fmt.Sprintf("%g", zone*6-183)
		p2["lat_0"] = "0"
		p2["k"] = "0.9996"
		p2["x_0"] = "500000"
		if _, ok := p2["y_0"]; !ok && strings.ToLower(p["south"]) != "" {
			p2["y_0"] = "10000000"
		}
		return tmercForward(lam, phi, p2)
	case "tmerc", "etmerc":
		return tmercForward(lam, phi, p)
	case "longlat", "lonlat", "latlong":
		return radToDeg(lam), radToDeg(phi), ""
	case "laea":
		return laeaForward(lam, phi, p)
	case "aea":
		return aeaForward(lam, phi, p)
	default:
		// A useful spherical fallback for simple cylindrical projections.
		el := getEllipsoid(p)
		return el.a * lam, el.a * phi, ""
	}
}

func inverse(x, y float64, cfg *config) (float64, float64, string) {
	p := cfg.params
	var lam, phi float64
	var err string
	switch cfg.proj {
	case "merc":
		lam, phi, err = mercInverse(x, y, p)
	case "eqc", "plate_carree":
		el := getEllipsoid(p)
		lat0 := degToRad(param(p, "lat_0", 0))
		lon0 := degToRad(param(p, "lon_0", 0))
		latTS := degToRad(param(p, "lat_ts", 0))
		lam = (x-param(p, "x_0", 0))/(el.a*math.Cos(latTS)) + lon0
		phi = (y-param(p, "y_0", 0))/el.a + lat0
	case "utm":
		zone := param(p, "zone", 0)
		p2 := copyParams(p)
		p2["lon_0"] = fmt.Sprintf("%g", zone*6-183)
		p2["lat_0"] = "0"
		p2["k"] = "0.9996"
		p2["x_0"] = "500000"
		if _, ok := p2["y_0"]; !ok && strings.ToLower(p["south"]) != "" {
			p2["y_0"] = "10000000"
		}
		lam, phi, err = tmercInverse(x, y, p2)
	case "tmerc", "etmerc":
		lam, phi, err = tmercInverse(x, y, p)
	default:
		el := getEllipsoid(p)
		lam, phi = x/el.a, y/el.a
	}
	return radToDeg(lam), radToDeg(phi), err
}

func mercForward(lam, phi float64, p map[string]string) (float64, float64, string) {
	if math.Abs(math.Abs(phi)-math.Pi/2) < 1e-12 || math.Abs(phi) > math.Pi/2 {
		return 0, 0, "Invalid latitude"
	}
	el := getEllipsoid(p)
	k0 := param(p, "k", param(p, "k_0", 1))
	lon0 := degToRad(param(p, "lon_0", 0))
	x := el.a*k0*(lam-lon0) + param(p, "x_0", 0)
	var y float64
	if el.e == 0 {
		y = el.a * k0 * math.Log(math.Tan(math.Pi/4+phi/2))
	} else {
		s := math.Sin(phi)
		y = el.a * k0 * math.Log(math.Tan(math.Pi/4+phi/2)*math.Pow((1-el.e*s)/(1+el.e*s), el.e/2))
	}
	y += param(p, "y_0", 0)
	return x, y, ""
}

func mercInverse(x, y float64, p map[string]string) (float64, float64, string) {
	el := getEllipsoid(p)
	k0 := param(p, "k", param(p, "k_0", 1))
	lon0 := degToRad(param(p, "lon_0", 0))
	lam := (x-param(p, "x_0", 0))/(el.a*k0) + lon0
	ts := math.Exp(-(y - param(p, "y_0", 0)) / (el.a * k0))
	phi := math.Pi/2 - 2*math.Atan(ts)
	for i := 0; i < 15 && el.e != 0; i++ {
		s := math.Sin(phi)
		np := math.Pi/2 - 2*math.Atan(ts*math.Pow((1-el.e*s)/(1+el.e*s), el.e/2))
		if math.Abs(np-phi) < 1e-14 {
			break
		}
		phi = np
	}
	return lam, phi, ""
}

func tmercForward(lam, phi float64, p map[string]string) (float64, float64, string) {
	el := getEllipsoid(p)
	e2 := el.e2
	ep2 := e2 / (1 - e2)
	k0 := param(p, "k", param(p, "k_0", 1))
	lon0 := degToRad(param(p, "lon_0", 0))
	lat0 := degToRad(param(p, "lat_0", 0))
	x0, y0 := param(p, "x_0", 0), param(p, "y_0", 0)
	N := el.a / math.Sqrt(1-e2*math.Pow(math.Sin(phi), 2))
	T := math.Pow(math.Tan(phi), 2)
	C := ep2 * math.Pow(math.Cos(phi), 2)
	A := math.Cos(phi) * (lam - lon0)
	M := meridional(el.a, e2, phi)
	M0 := meridional(el.a, e2, lat0)
	x := x0 + k0*N*(A+(1-T+C)*math.Pow(A, 3)/6+(5-18*T+T*T+72*C-58*ep2)*math.Pow(A, 5)/120)
	y := y0 + k0*(M-M0+N*math.Tan(phi)*(A*A/2+(5-T+9*C+4*C*C)*math.Pow(A, 4)/24+(61-58*T+T*T+600*C-330*ep2)*math.Pow(A, 6)/720))
	return x, y, ""
}

func tmercInverse(x, y float64, p map[string]string) (float64, float64, string) {
	el := getEllipsoid(p)
	e2 := el.e2
	ep2 := e2 / (1 - e2)
	k0 := param(p, "k", param(p, "k_0", 1))
	lon0 := degToRad(param(p, "lon_0", 0))
	lat0 := degToRad(param(p, "lat_0", 0))
	x0, y0 := param(p, "x_0", 0), param(p, "y_0", 0)
	M0 := meridional(el.a, e2, lat0)
	M := M0 + (y-y0)/k0
	mu := M / (el.a * (1 - e2/4 - 3*e2*e2/64 - 5*math.Pow(e2, 3)/256))
	e1 := (1 - math.Sqrt(1-e2)) / (1 + math.Sqrt(1-e2))
	phi1 := mu + (3*e1/2-27*math.Pow(e1, 3)/32)*math.Sin(2*mu) + (21*e1*e1/16-55*math.Pow(e1, 4)/32)*math.Sin(4*mu) + (151*math.Pow(e1, 3)/96)*math.Sin(6*mu) + (1097*math.Pow(e1, 4)/512)*math.Sin(8*mu)
	C1 := ep2 * math.Pow(math.Cos(phi1), 2)
	T1 := math.Pow(math.Tan(phi1), 2)
	N1 := el.a / math.Sqrt(1-e2*math.Pow(math.Sin(phi1), 2))
	R1 := el.a * (1 - e2) / math.Pow(1-e2*math.Pow(math.Sin(phi1), 2), 1.5)
	D := (x - x0) / (N1 * k0)
	phi := phi1 - (N1*math.Tan(phi1)/R1)*(D*D/2-(5+3*T1+10*C1-4*C1*C1-9*ep2)*math.Pow(D, 4)/24+(61+90*T1+298*C1+45*T1*T1-252*ep2-3*C1*C1)*math.Pow(D, 6)/720)
	lam := lon0 + (D-(1+2*T1+C1)*math.Pow(D, 3)/6+(5-2*C1+28*T1-3*C1*C1+8*ep2+24*T1*T1)*math.Pow(D, 5)/120)/math.Cos(phi1)
	return lam, phi, ""
}

func laeaForward(lam, phi float64, p map[string]string) (float64, float64, string) {
	el := getEllipsoid(p)
	lat0 := degToRad(param(p, "lat_0", 0))
	lon0 := degToRad(param(p, "lon_0", 0))
	sin0, cos0 := math.Sin(lat0), math.Cos(lat0)
	sinP, cosP := math.Sin(phi), math.Cos(phi)
	dlon := lam - lon0
	k := math.Sqrt(2 / (1 + sin0*sinP + cos0*cosP*math.Cos(dlon)))
	return el.a*k*cosP*math.Sin(dlon) + param(p, "x_0", 0), el.a*k*(cos0*sinP-sin0*cosP*math.Cos(dlon)) + param(p, "y_0", 0), ""
}

func aeaForward(lam, phi float64, p map[string]string) (float64, float64, string) {
	el := getEllipsoid(p)
	lat1 := degToRad(param(p, "lat_1", 0))
	lat2 := degToRad(param(p, "lat_2", radToDeg(lat1)))
	lat0 := degToRad(param(p, "lat_0", 0))
	lon0 := degToRad(param(p, "lon_0", 0))
	n := 0.5 * (math.Sin(lat1) + math.Sin(lat2))
	if math.Abs(n) < 1e-12 {
		n = math.Sin(lat1)
	}
	C := math.Cos(lat1)*math.Cos(lat1) + 2*n*math.Sin(lat1)
	rho := el.a * math.Sqrt(C-2*n*math.Sin(phi)) / n
	rho0 := el.a * math.Sqrt(C-2*n*math.Sin(lat0)) / n
	th := n * (lam - lon0)
	return rho*math.Sin(th) + param(p, "x_0", 0), rho0 - rho*math.Cos(th) + param(p, "y_0", 0), ""
}

func meridional(a, e2, phi float64) float64 {
	return a * ((1-e2/4-3*e2*e2/64-5*math.Pow(e2, 3)/256)*phi -
		(3*e2/8+3*e2*e2/32+45*math.Pow(e2, 3)/1024)*math.Sin(2*phi) +
		(15*e2*e2/256+45*math.Pow(e2, 3)/1024)*math.Sin(4*phi) -
		(35*math.Pow(e2, 3)/3072)*math.Sin(6*phi))
}

func getEllipsoid(p map[string]string) ellipsoid {
	a := param(p, "a", aWGS84)
	if r := param(p, "R", 0); r != 0 {
		return ellipsoid{a: r}
	}
	if p["ellps"] == "sphere" {
		return ellipsoid{a: 6370997}
	}
	rf := param(p, "rf", 1/fWGS84)
	f := 1 / rf
	if b := param(p, "b", 0); b != 0 {
		f = (a - b) / a
	}
	e2 := 2*f - f*f
	return ellipsoid{a: a, e2: e2, e: math.Sqrt(e2)}
}

func unitFactor(p map[string]string) float64 {
	if v := param(p, "to_meter", 0); v != 0 {
		return v
	}
	switch p["units"] {
	case "", "m":
		return 1
	case "km":
		return 1000
	case "cm":
		return 0.01
	case "mm":
		return 0.001
	case "ft":
		return 0.3048
	case "us-ft":
		return 0.304800609601219
	case "mi":
		return 1609.344
	case "yd":
		return 0.9144
	}
	return 1
}

func param(p map[string]string, key string, def float64) float64 {
	v, ok := p[key]
	if !ok || v == "" {
		return def
	}
	f, err := strconv.ParseFloat(v, 64)
	if err != nil {
		return def
	}
	return f
}

func copyParams(p map[string]string) map[string]string {
	q := map[string]string{}
	for k, v := range p {
		q[k] = v
	}
	return q
}

func degToRad(v float64) float64 { return v * math.Pi / 180 }
func radToDeg(v float64) float64 { return v * 180 / math.Pi }

func formatDMS(v float64, lon bool) string {
	dir := "N"
	if lon {
		dir = "E"
	}
	if v < 0 {
		if lon {
			dir = "W"
		} else {
			dir = "S"
		}
		v = -v
	}
	d := math.Floor(v + 1e-12)
	rem := (v - d) * 60
	m := math.Floor(rem + 1e-12)
	s := (rem - m) * 60
	if s >= 59.9995 {
		s = 0
		m++
	}
	if m >= 60 {
		m = 0
		d++
	}
	if s < 0.0005 {
		if m == 0 {
			return fmt.Sprintf("%.0fd%s", d, dir)
		}
		return fmt.Sprintf("%.0fd%.0f'%s", d, m, dir)
	}
	return fmt.Sprintf("%.0fd%.0f'%.3f\"%s", d, m, s, dir)
}
