module nnnclone

go 1.21
