package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

const version = "5.2"

const helpText = `usage: nnn [OPTIONS] [PATH]

The unorthodox terminal file manager.

positional args:
  PATH   start dir/file [default: .]

optional args:
 -a      auto NNN_FIFO
 -A      no dir auto-enter during filter
 -b key  open bookmark key (trumps -s/S)
 -B      use bsdtar for archives
 -c      cli-only NNN_OPENER (trumps -e)
 -C      8-color scheme
 -d      detail mode
 -D      dirs in context color
 -e      text in $VISUAL/$EDITOR/vi
 -E      internal edits in EDITOR
 -f      use history file
 -F val  fifo mode [0:preview 1:explore]
 -g      regex filters
 -H      show hidden files
 -i      show current file info
 -J      no auto-advance on selection
 -K      detect key collision and exit
 -l val  set scroll lines
 -n      type-to-nav mode
 -N      use native prompt
 -o      open files only on Enter
 -p file selection file [-:stdout]
 -P key  run plugin key
 -Q      no quit confirmation
 -r      use advcpmv patched cp, mv
 -R      no rollover at edges
 -s name load session by name
 -S      persistent session
 -t secs timeout to lock
 -T key  sort order [a/d/e/r/s/t/v]
 -u      use selection (no prompt)
 -U      show user and group
 -V      show version
 -x      notis, selection sync, xterm title
 -z      in order fuzzy filters
 -0      null separator in picker mode
 -h      show help

v5.2
BSD 2-Clause
https://github.com/jarun/nnn
`

type options struct {
	showHidden bool
	detail     bool
	keyCheck   bool
	picker     string
	nullSep    bool
	sortKey    byte
	paths      []string
}

func main() {
	opts, code := parseArgs(os.Args)
	if code >= 0 {
		os.Exit(code)
	}
	if opts.keyCheck {
		os.Exit(0)
	}

	path := "."
	if len(opts.paths) > 0 {
		path = opts.paths[0]
	}

	dir, err := preparePath(path)
	if err != nil {
		// The reference normally transitions into curses even for some bad paths
		// in a pipe. Keep the diagnostic compact for direct command-line use.
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	if !isTerminal(os.Stdin.Fd()) || !isTerminal(os.Stdout.Fd()) {
		fmt.Println("0 entries")
		if opts.picker == "-" {
			// Empty selection on immediate EOF.
			if opts.nullSep {
				fmt.Print("")
			}
		}
		os.Exit(124)
	}

	runScreen(dir, opts)
}

func parseArgs(argv []string) (options, int) {
	var opts options
	prog := argv[0]
	noArg := "aABcCdDeEfgHiJKnNoQrRSuUVxz0h"
	withArg := "bFlpPstT"

	for i := 1; i < len(argv); i++ {
		arg := argv[i]
		if arg == "--" {
			opts.paths = append(opts.paths, argv[i+1:]...)
			break
		}
		if len(arg) < 2 || arg[0] != '-' || arg == "-" {
			opts.paths = append(opts.paths, arg)
			continue
		}
		for j := 1; j < len(arg); j++ {
			ch := arg[j]
			if !strings.ContainsRune(noArg+withArg, rune(ch)) {
				fmt.Fprintf(os.Stderr, "%s: invalid option -- '%c'\n", prog, ch)
				printHelp(os.Stdout)
				return opts, 1
			}
			if strings.ContainsRune(withArg, rune(ch)) {
				val := ""
				if j+1 < len(arg) {
					val = arg[j+1:]
					j = len(arg)
				} else {
					i++
					if i >= len(argv) {
						fmt.Fprintf(os.Stderr, "%s: option requires an argument -- '%c'\n", prog, ch)
						printHelp(os.Stdout)
						return opts, 1
					}
					val = argv[i]
				}
				switch ch {
				case 'p':
					opts.picker = val
				case 'T':
					if val != "" {
						opts.sortKey = val[0]
					}
				case 'F':
					if n, ok := leadingNumber(val); ok && n > 1 {
						return opts, 1
					}
				case 'l', 't':
					_, _ = strconv.Atoi(val)
				}
				break
			}
			switch ch {
			case 'h':
				printHelp(os.Stdout)
				return opts, 0
			case 'V':
				fmt.Println(version)
				return opts, 0
			case 'K':
				opts.keyCheck = true
			case 'H':
				opts.showHidden = true
			case 'd':
				opts.detail = true
			case '0':
				opts.nullSep = true
			}
		}
	}
	return opts, -1
}

func printHelp(w io.Writer) {
	fmt.Fprint(w, helpText)
}

func preparePath(p string) (string, error) {
	if p == "" {
		p = "."
	}
	info, err := os.Stat(p)
	if err == nil {
		if info.IsDir() {
			return p, nil
		}
		return filepath.Dir(p), nil
	}
	if os.IsNotExist(err) {
		if strings.HasSuffix(p, string(os.PathSeparator)) || strings.HasSuffix(p, "/") {
			if mkerr := os.MkdirAll(p, 0755); mkerr != nil {
				return "", mkerr
			}
			return p, nil
		}
		parent := filepath.Dir(p)
		if mkerr := os.MkdirAll(parent, 0755); mkerr != nil {
			return "", mkerr
		}
		return parent, nil
	}
	return "", err
}

type entry struct {
	name string
	info os.FileInfo
}

func readEntries(dir string, showHidden bool, sortKey byte) ([]entry, error) {
	list, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	entries := make([]entry, 0, len(list))
	for _, de := range list {
		name := de.Name()
		if !showHidden && strings.HasPrefix(name, ".") {
			continue
		}
		info, err := de.Info()
		if err != nil {
			continue
		}
		entries = append(entries, entry{name: name, info: info})
	}
	sort.SliceStable(entries, func(i, j int) bool {
		a, b := entries[i], entries[j]
		if a.info.IsDir() != b.info.IsDir() {
			return a.info.IsDir()
		}
		switch sortKey {
		case 's':
			if a.info.Size() != b.info.Size() {
				return a.info.Size() < b.info.Size()
			}
		case 't':
			if !a.info.ModTime().Equal(b.info.ModTime()) {
				return a.info.ModTime().After(b.info.ModTime())
			}
		case 'e':
			ea, eb := filepath.Ext(a.name), filepath.Ext(b.name)
			if ea != eb {
				return strings.ToLower(ea) < strings.ToLower(eb)
			}
		}
		return naturalLess(a.name, b.name)
	})
	return entries, nil
}

func naturalLess(a, b string) bool {
	la, lb := strings.ToLower(a), strings.ToLower(b)
	ia, ib := 0, 0
	for ia < len(la) && ib < len(lb) {
		ca, cb := la[ia], lb[ib]
		if isDigit(ca) && isDigit(cb) {
			na, ja := readNumber(la, ia)
			nb, jb := readNumber(lb, ib)
			if na != nb {
				return na < nb
			}
			ia, ib = ja, jb
			continue
		}
		if ca != cb {
			return ca < cb
		}
		ia++
		ib++
	}
	return len(la) < len(lb)
}

func isDigit(c byte) bool { return c >= '0' && c <= '9' }

func leadingNumber(s string) (int, bool) {
	if s == "" || !isDigit(s[0]) {
		return 0, false
	}
	n := 0
	for i := 0; i < len(s) && isDigit(s[i]); i++ {
		n = n*10 + int(s[i]-'0')
	}
	return n, true
}

func readNumber(s string, i int) (int64, int) {
	var n int64
	for i < len(s) && isDigit(s[i]) {
		n = n*10 + int64(s[i]-'0')
		i++
	}
	return n, i
}

func runScreen(dir string, opts options) {
	entries, err := readEntries(dir, opts.showHidden, opts.sortKey)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	old, _ := makeRaw(int(os.Stdin.Fd()))
	defer restore(int(os.Stdin.Fd()), old)

	fmt.Print("\x1b[?1049h\x1b[?25l\x1b[H\x1b[2J")
	defer fmt.Print("\x1b[?25h\x1b[?1049l")

	draw(dir, entries, opts.detail)
	r := bufio.NewReader(os.Stdin)
	for {
		b, err := r.ReadByte()
		if err != nil {
			return
		}
		if b == 'q' || b == 3 || b == 27 {
			return
		}
		if b == '?' {
			printHelpScreen()
			continue
		}
		draw(dir, entries, opts.detail)
	}
}

func draw(dir string, entries []entry, detail bool) {
	fmt.Print("\x1b[H\x1b[2J")
	fmt.Printf("\x1b[1;7m\x1b[34m1\x1b[39m\x1b[0m 2 3 4 5 6 7 8 \x1b[4m\x1b[34m%s\x1b[0m\r\n\r\n", dir)
	limit := len(entries)
	if limit > 20 {
		limit = 20
	}
	for i := 0; i < limit; i++ {
		e := entries[i]
		prefix := " "
		if i == 0 {
			prefix = " \x1b[1;7m\x1b[34m"
		}
		suffix := "\x1b[0m"
		name := e.name
		if e.info.IsDir() {
			name += "/"
		}
		if detail {
			fmt.Printf("%s%-32s %8s %s%s\r\n", prefix, name, human(e.info.Size()), e.info.Mode().String(), suffix)
		} else {
			fmt.Printf("%s%s%s\r\n", prefix, name, suffix)
		}
	}
	if len(entries) == 0 {
		fmt.Print("0 entries\r\n")
	} else {
		first := entries[0].info
		fmt.Printf("\x1b[24;1H\x1b[34m1/%d  \x1b[7m\x1b[34m%s\x1b[0m\x1b[34m %s %s\r", len(entries), first.ModTime().Format("2006-01-02 15:04"), first.Mode().String(), human(first.Size()))
	}
}

func printHelpScreen() {
	fmt.Print("\x1b[H\x1b[2J")
	fmt.Print("nnn help\r\n\r\n")
	fmt.Print("q: quit  arrows: navigate  /: filter  Enter: open\r\n")
}

func human(n int64) string {
	units := []string{"", "K", "M", "G", "T"}
	v := float64(n)
	u := 0
	for v >= 1024 && u < len(units)-1 {
		v /= 1024
		u++
	}
	if u == 0 {
		return fmt.Sprintf("%d", n)
	}
	return fmt.Sprintf("%.0f%s", v, units[u])
}

func isTerminal(fd uintptr) bool {
	var st syscall.Termios
	_, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, fd, uintptr(syscall.TCGETS), uintptr(unsafePointer(&st)), 0, 0, 0)
	return errno == 0
}

func makeRaw(fd int) (*syscall.Termios, error) {
	var old syscall.Termios
	if _, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCGETS), uintptr(unsafePointer(&old)), 0, 0, 0); errno != 0 {
		return nil, errno
	}
	raw := old
	raw.Iflag &^= syscall.IGNBRK | syscall.BRKINT | syscall.PARMRK | syscall.ISTRIP | syscall.INLCR | syscall.IGNCR | syscall.ICRNL | syscall.IXON
	raw.Oflag &^= syscall.OPOST
	raw.Lflag &^= syscall.ECHO | syscall.ECHONL | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
	raw.Cflag &^= syscall.CSIZE | syscall.PARENB
	raw.Cflag |= syscall.CS8
	raw.Cc[syscall.VMIN] = 1
	raw.Cc[syscall.VTIME] = 0
	if _, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafePointer(&raw)), 0, 0, 0); errno != 0 {
		return nil, errno
	}
	return &old, nil
}

func restore(fd int, old *syscall.Termios) {
	if old != nil {
		syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafePointer(old)), 0, 0, 0)
	}
}

func unsafePointer(p *syscall.Termios) unsafe.Pointer { return unsafe.Pointer(p) }
