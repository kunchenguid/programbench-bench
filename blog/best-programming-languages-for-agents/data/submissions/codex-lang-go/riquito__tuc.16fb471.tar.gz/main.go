package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"regexp"
	"strconv"
	"strings"
	"unicode/utf8"
)

type mode int

const (
	modeFields mode = iota
	modeBytes
	modeChars
	modeLines
)

type opts struct {
	mode                                                               mode
	spec, delim, regex, repl, trim, fallback, file                     string
	join, joinSet, greedy, compress, onlyDelim, zero, complement, json bool
}
type item struct {
	a, b     int
	open     bool
	fallback *string
	raw      string
	isRange  bool
}
type spec struct {
	items  []item
	format bool
	fmtstr string
}

const help = `tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\0), not LF (\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
`

func dief(f string, a ...interface{}) { fmt.Fprintf(os.Stderr, f+"\n", a...); os.Exit(1) }
func need(args []string, i *int, name string) string {
	if *i+1 >= len(args) {
		dief("tuc: missing value for %s", name)
	}
	*i++
	return args[*i]
}

func parseArgs(args []string) opts {
	o := opts{mode: modeFields, spec: "1:", delim: "\t"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			fmt.Print(help)
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("tuc 1.3.0")
			os.Exit(0)
		case "-g", "--greedy-delimiter":
			o.greedy = true
		case "-p", "--compress-delimiter":
			o.compress = true
		case "-s", "--only-delimited":
			o.onlyDelim = true
		case "-z", "--zero-terminated":
			o.zero = true
		case "-m", "--complement":
			o.complement = true
		case "-j", "--join":
			o.join = true
			o.joinSet = true
		case "--no-join":
			o.join = false
			o.joinSet = true
		case "--json":
			o.json = true
		case "--no-mmap":
		case "-f", "--fields":
			o.mode = modeFields
			o.spec = need(args, &i, a)
		case "-b", "--bytes":
			o.mode = modeBytes
			o.spec = need(args, &i, a)
		case "-c", "--characters":
			o.mode = modeChars
			o.spec = need(args, &i, a)
		case "-l", "--lines":
			o.mode = modeLines
			o.spec = need(args, &i, a)
			if !o.joinSet {
				o.join = true
			}
		case "-d", "--delimiter":
			o.delim = need(args, &i, a)
		case "-e", "--regex":
			o.regex = need(args, &i, a)
		case "-r", "--replace-delimiter":
			o.repl = need(args, &i, a)
			o.join = true
			o.joinSet = true
		case "-t", "--trim":
			o.trim = need(args, &i, a)
		case "--fallback-oob":
			o.fallback = need(args, &i, a)
		case "-M", "--fixed-memory":
			_ = need(args, &i, a)
		default:
			if strings.HasPrefix(a, "-") {
				dief("tuc: unexpected arguments: [\"%s\"]\nTry 'tuc --help' for more information.", a)
			}
			if o.file != "" {
				dief("tuc: unexpected arguments: [\"%s\"]\nTry 'tuc --help' for more information.", a)
			}
			o.file = a
		}
	}
	return o
}

func parseNum(s, whole string) int {
	n, e := strconv.Atoi(s)
	if e != nil {
		dief("failed to parse '%s': Not a number `%s`", whole, s)
	}
	if n == 0 {
		dief("failed to parse '%s': Zero is not a valid field", whole)
	}
	return n
}
func parseSpec(s string) spec {
	if strings.Contains(s, "{") || strings.Contains(s, "}") {
		return spec{format: true, fmtstr: s}
	}
	sp := spec{}
	for _, p := range strings.Split(s, ",") {
		if p == "" {
			continue
		}
		raw := p
		var fb *string
		if k := strings.Index(p, "="); k >= 0 {
			v := p[k+1:]
			fb = &v
			p = p[:k]
		}
		it := item{raw: raw, fallback: fb}
		if k := strings.Index(p, ":"); k >= 0 {
			it.isRange = true
			left, right := p[:k], p[k+1:]
			if left == "" {
				it.a = 1
			} else {
				it.a = parseNum(left, raw)
			}
			if right == "" {
				it.open = true
			} else {
				it.b = parseNum(right, raw)
			}
		} else {
			it.a = parseNum(p, raw)
			it.b = it.a
		}
		sp.items = append(sp.items, it)
	}
	return sp
}
func idx(n, total int) int {
	if n < 0 {
		return total + n + 1
	}
	return n
}

func selectedFields(sp spec, total int, o opts) []item {
	if !o.complement {
		return sp.items
	}
	sel := map[int]bool{}
	for _, it := range sp.items {
		a := idx(it.a, total)
		b := idx(it.b, total)
		if it.open {
			b = total
		}
		if a > b {
			a, b = b, a
		}
		for i := a; i <= b; i++ {
			if i >= 1 && i <= total {
				sel[i] = true
			}
		}
	}
	out := []item{}
	start := 0
	for i := 1; i <= total; i++ {
		if !sel[i] && start == 0 {
			start = i
		}
		if (sel[i] || i == total) && start != 0 {
			end := i
			if sel[i] {
				end = i - 1
			}
			out = append(out, item{a: start, b: end, isRange: start != end})
			start = 0
		}
	}
	return out
}

func splitFixed(s, d string, greedy bool) ([]string, []string) {
	if d == "" {
		return []string{s}, nil
	}
	parts := []string{}
	delims := []string{}
	pos := 0
	for {
		k := strings.Index(s[pos:], d)
		if k < 0 {
			break
		}
		k += pos
		end := k + len(d)
		if greedy {
			for strings.HasPrefix(s[end:], d) {
				end += len(d)
			}
		}
		parts = append(parts, s[pos:k])
		delims = append(delims, s[k:end])
		pos = end
	}
	parts = append(parts, s[pos:])
	return parts, delims
}
func splitRegex(s string, re *regexp.Regexp) ([]string, []string) {
	locs := re.FindAllStringIndex(s, -1)
	parts := []string{}
	dels := []string{}
	pos := 0
	for _, l := range locs {
		if l[0] == l[1] {
			continue
		}
		parts = append(parts, s[pos:l[0]])
		dels = append(dels, s[l[0]:l[1]])
		pos = l[1]
	}
	parts = append(parts, s[pos:])
	return parts, dels
}
func compressLine(s, d string) string {
	if d == "" {
		return s
	}
	for strings.Contains(s, d+d) {
		s = strings.ReplaceAll(s, d+d, d)
	}
	return s
}
func trimLine(s, d, t string) string {
	if d == "" || t == "" {
		return s
	}
	lower := strings.ToLower(t[:1])
	if lower == "l" || lower == "b" {
		for strings.HasPrefix(s, d) {
			s = s[len(d):]
		}
	}
	if lower == "r" || lower == "b" {
		for strings.HasSuffix(s, d) {
			s = s[:len(s)-len(d)]
		}
	}
	return s
}

func fieldValue(i, total int, fields []string, it item, o opts) (string, bool) {
	j := idx(i, total)
	if j < 1 || j > total {
		if it.fallback != nil {
			return *it.fallback, true
		}
		if o.fallback != "" {
			return o.fallback, true
		}
		return "", false
	}
	return fields[j-1], true
}
func renderFormat(fmtstr string, fields []string, o opts) (string, bool) {
	total := len(fields)
	var b strings.Builder
	for i := 0; i < len(fmtstr); i++ {
		c := fmtstr[i]
		if c == '{' {
			if i+1 < len(fmtstr) && fmtstr[i+1] == '{' {
				b.WriteByte('{')
				i++
				continue
			}
			j := strings.IndexByte(fmtstr[i+1:], '}')
			if j < 0 {
				return "", false
			}
			key := fmtstr[i+1 : i+1+j]
			n := parseNum(key, key)
			v, ok := fieldValue(n, total, fields, item{}, o)
			if !ok {
				return "", false
			}
			b.WriteString(v)
			i = i + 1 + j
		} else if c == '}' {
			if i+1 < len(fmtstr) && fmtstr[i+1] == '}' {
				b.WriteByte('}')
				i++
			} else {
				return "", false
			}
		} else {
			b.WriteByte(c)
		}
	}
	return b.String(), true
}

func renderParts(sp spec, fields, delims []string, o opts, joiner string) ([]string, bool) {
	total := len(fields)
	if sp.format {
		v, ok := renderFormat(sp.fmtstr, fields, o)
		return []string{v}, ok
	}
	items := selectedFields(sp, total, o)
	vals := []string{}
	for _, it := range items {
		a := idx(it.a, total)
		b := idx(it.b, total)
		if it.open {
			b = total
		}
		if !it.isRange {
			b = a
		}
		if a < 1 || a > total || b < 1 || b > total {
			fb := ""
			if it.fallback != nil {
				fb = *it.fallback
			} else if o.fallback != "" {
				fb = o.fallback
			} else {
				return nil, false
			}
			vals = append(vals, fb)
			continue
		}
		if a > b {
			a, b = b, a
		}
		if it.isRange || it.open {
			var sb strings.Builder
			for i := a; i <= b; i++ {
				if i > a {
					if o.join || o.repl != "" {
						sb.WriteString(joiner)
					} else if i-2 < len(delims) {
						sb.WriteString(delims[i-2])
					}
				}
				sb.WriteString(fields[i-1])
			}
			vals = append(vals, sb.String())
		} else {
			vals = append(vals, fields[a-1])
		}
	}
	if o.join && !o.json && len(vals) > 1 {
		return []string{strings.Join(vals, joiner)}, true
	}
	return vals, true
}

func processFields(data []byte, o opts) int {
	sep := "\n"
	if o.zero {
		sep = "\x00"
	}
	text := string(data)
	recs := strings.Split(text, sep)
	if strings.HasSuffix(text, sep) {
		recs = recs[:len(recs)-1]
	}
	sp := parseSpec(o.spec)
	var re *regexp.Regexp
	if o.regex != "" {
		var err error
		re, err = regexp.Compile(o.regex)
		if err != nil {
			dief("%v", err)
		}
		if o.join && o.repl == "" {
			dief("tuc: runtime error. Cannot use --regex and --join without --replace-delimiter")
		}
	}
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	joiner := o.delim
	if o.repl != "" {
		joiner = o.repl
	}
	for _, rec := range recs {
		line := rec
		if o.compress {
			line = compressLine(line, o.delim)
		}
		line = trimLine(line, o.delim, o.trim)
		var fields, dels []string
		if re != nil {
			fields, dels = splitRegex(line, re)
		} else {
			fields, dels = splitFixed(line, o.delim, o.greedy)
		}
		if o.onlyDelim && len(dels) == 0 {
			continue
		}
		vals, ok := renderParts(sp, fields, dels, o, joiner)
		if !ok { // find first offending bound
			for _, it := range sp.items {
				n := idx(it.a, len(fields))
				if n < 1 || n > len(fields) {
					dief("Error: Out of bounds: %d", it.a)
				}
				if (it.isRange || it.open) && !it.open {
					n = idx(it.b, len(fields))
					if n < 1 || n > len(fields) {
						dief("Error: Out of bounds: %d", it.b)
					}
				}
			}
			dief("Error: Out of bounds")
		}
		if o.json {
			enc, _ := json.Marshal(vals)
			out.Write(enc)
		} else {
			out.WriteString(strings.Join(vals, ""))
		}
		out.WriteString(sep)
	}
	return 0
}

func processUnits(data []byte, o opts, chars bool) int {
	sp := parseSpec(o.spec)
	var units []string
	if chars {
		for len(data) > 0 {
			r, sz := utf8.DecodeRune(data)
			units = append(units, string(r))
			data = data[sz:]
		}
	} else {
		for _, b := range data {
			units = append(units, string([]byte{b}))
		}
	}
	vals, ok := renderParts(sp, units, nil, o, "")
	if !ok {
		for _, it := range sp.items {
			dief("Error: Out of bounds: %d", it.a)
		}
	}
	fmt.Print(strings.Join(vals, ""))
	return 0
}
func processChars(data []byte, o opts) int {
	sep := "\n"
	if o.zero {
		sep = "\x00"
	}
	text := string(data)
	recs := strings.Split(text, sep)
	if strings.HasSuffix(text, sep) {
		recs = recs[:len(recs)-1]
	}
	sp := parseSpec(o.spec)
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, rec := range recs {
		units := []string{}
		for _, r := range rec {
			units = append(units, string(r))
		}
		vals, ok := renderParts(sp, units, nil, o, "")
		if !ok {
			for _, it := range sp.items {
				dief("Error: Out of bounds: %d", it.a)
			}
		}
		if o.json {
			enc, _ := json.Marshal(vals)
			out.Write(enc)
		} else {
			out.WriteString(strings.Join(vals, ""))
		}
		out.WriteString(sep)
	}
	return 0
}
func processLines(data []byte, o opts) int {
	sep := "\n"
	if o.zero {
		sep = "\x00"
	}
	text := string(data)
	lines := strings.Split(text, sep)
	if strings.HasSuffix(text, sep) {
		lines = lines[:len(lines)-1]
	}
	sp := parseSpec(o.spec)
	vals, ok := renderParts(sp, lines, nil, o, sep)
	if !ok {
		for _, it := range sp.items {
			dief("Error: Out of bounds: %d", it.a)
		}
	}
	if o.json {
		enc, _ := json.Marshal(vals)
		os.Stdout.Write(enc)
		fmt.Print(sep)
		return 0
	}
	if o.join {
		fmt.Print(strings.Join(vals, sep))
		if len(vals) > 0 {
			fmt.Print(sep)
		}
	} else {
		fmt.Print(strings.Join(vals, ""))
		if len(vals) > 0 {
			fmt.Print(sep)
		}
	}
	return 0
}

func main() {
	o := parseArgs(os.Args[1:])
	var r io.Reader = os.Stdin
	if o.file != "" {
		f, err := os.Open(o.file)
		if err != nil {
			dief("%v", err)
		}
		defer f.Close()
		r = f
	}
	data, err := io.ReadAll(r)
	if err != nil {
		dief("%v", err)
	}
	switch o.mode {
	case modeBytes:
		processUnits(data, o, false)
	case modeChars:
		processChars(data, o)
	default:
		if o.mode == modeLines {
			processLines(data, o)
		} else {
			processFields(data, o)
		}
	}
}
