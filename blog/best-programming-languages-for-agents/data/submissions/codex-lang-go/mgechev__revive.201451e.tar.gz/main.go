package main

import (
	"encoding/json"
	"encoding/xml"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(v string) error {
	*m = append(*m, v)
	return nil
}

type posn struct {
	Filename string
	Offset   int
	Line     int
	Column   int
}

type position struct {
	Start posn
	End   posn
}

type failure struct {
	Severity        string
	Failure         string
	RuleName        string
	Category        string
	Position        position
	Confidence      float64
	ReplacementLine string
}

type config struct {
	Severity   string
	Confidence float64
	Rules      map[string]bool
}

var defaultRules = map[string]bool{
	"blank-imports":       true,
	"context-keys-type":   true,
	"context-as-argument": true,
	"dot-imports":         true,
	"error-return":        true,
	"error-strings":       true,
	"exported":            true,
	"indent-error-flow":   true,
	"increment-decrement": true,
	"package-comments":    true,
	"range":               true,
	"receiver-naming":     true,
	"unused-parameter":    true,
	"var-declaration":     true,
	"var-naming":          true,
}

func main() {
	var excludes multiFlag
	cfgPath := flag.String("config", "", "path to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)")
	formatter := flag.String("formatter", "", "formatter to be used for the output (i.e. -formatter stylish)")
	flag.Var(&excludes, "exclude", "list of globs which specify files to be excluded (i.e. -exclude foo/...)")
	flag.Int("max_open_files", 0, "maximum number of open files at the same time")
	setExit := flag.Bool("set_exit_status", false, "set exit status to 1 if any issues are found, overwrites errorCode and warningCode in config")
	version := flag.Bool("version", false, "get revive version")
	flag.Usage = func() {
		fmt.Fprintf(flag.CommandLine.Output(), "Usage of %s:\n", os.Args[0])
		flag.PrintDefaults()
		fmt.Fprintln(flag.CommandLine.Output(), "\n _ __ _____   _(_)__  _____")
		fmt.Fprintln(flag.CommandLine.Output(), "| '__/ _ \\ \\ / / \\ \\ / / _ \\")
		fmt.Fprintln(flag.CommandLine.Output(), "| | |  __/\\ V /| |\\ V /  __/")
		fmt.Fprintln(flag.CommandLine.Output(), "|_|  \\___| \\_/ |_| \\_/ \\___|")
		fmt.Fprintln(flag.CommandLine.Output(), "\nExample:")
		fmt.Fprintln(flag.CommandLine.Output(), "  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...")
	}
	flag.Parse()

	if *version {
		fmt.Println("Version:\ta75b67b")
		fmt.Println("Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05")
		fmt.Println("Built\t\t2026-04-17 19:59 UTC by build.sh")
		return
	}

	cfg := loadConfig(*cfgPath)
	args := flag.Args()
	if len(args) == 0 {
		return
	}
	files := collectFiles(args, excludes)
	var failures []failure
	for _, file := range files {
		failures = append(failures, lintFile(file, cfg)...)
	}
	sortFailures(failures)

	name := *formatter
	if name == "" || name == "default" {
		formatDefault(failures)
	} else {
		var err error
		switch name {
		case "json":
			err = formatJSON(failures)
		case "ndjson":
			err = formatNDJSON(failures)
		case "unix":
			formatUnix(failures)
		case "plain":
			formatPlain(failures)
		case "stylish":
			formatStylish(failures)
		case "friendly":
			formatFriendly(failures)
		case "checkstyle":
			err = formatCheckstyle(failures)
		case "sarif":
			err = formatSARIF(failures)
		default:
			fmt.Fprintf(os.Stderr, "formatting - getting formatter: unknown formatter %s\n", name)
			os.Exit(1)
		}
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if *setExit && len(failures) > 0 {
		os.Exit(1)
	}
}

func loadConfig(path string) config {
	cfg := config{Severity: "warning", Confidence: 0, Rules: copyRules(defaultRules)}
	if path == "" {
		for _, p := range []string{os.Getenv("XDG_CONFIG_HOME") + "/revive.toml", os.Getenv("HOME") + "/revive.toml"} {
			if p != "/revive.toml" {
				if _, err := os.Stat(p); err == nil {
					path = p
					break
				}
			}
		}
	}
	if path == "" {
		return cfg
	}
	b, err := os.ReadFile(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "cannot read the config file: %v\n", err)
		os.Exit(1)
	}
	cfg.Rules = map[string]bool{}
	curRule := ""
	for _, raw := range strings.Split(string(b), "\n") {
		line := strings.TrimSpace(strings.Split(raw, "#")[0])
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "[rule.") && strings.HasSuffix(line, "]") {
			curRule = strings.TrimSuffix(strings.TrimPrefix(line, "[rule."), "]")
			curRule = strings.Trim(curRule, "\"")
			cfg.Rules[curRule] = true
			continue
		}
		if strings.HasPrefix(line, "severity") {
			cfg.Severity = tomlString(line)
		}
		if strings.HasPrefix(line, "confidence") {
			if parts := strings.SplitN(line, "=", 2); len(parts) == 2 {
				if f, err := strconv.ParseFloat(strings.TrimSpace(parts[1]), 64); err == nil {
					cfg.Confidence = f
				}
			}
		}
		if curRule != "" && strings.HasPrefix(strings.ToLower(line), "disabled") && strings.Contains(strings.ToLower(line), "true") {
			cfg.Rules[curRule] = false
		}
	}
	if len(cfg.Rules) == 0 {
		cfg.Rules = copyRules(defaultRules)
	}
	return cfg
}

func tomlString(line string) string {
	parts := strings.SplitN(line, "=", 2)
	if len(parts) != 2 {
		return ""
	}
	return strings.Trim(strings.TrimSpace(parts[1]), "\"'")
}

func copyRules(in map[string]bool) map[string]bool {
	out := map[string]bool{}
	for k, v := range in {
		out[k] = v
	}
	return out
}

func collectFiles(args []string, excludes []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, arg := range args {
		targets := expandArg(arg)
		for _, t := range targets {
			info, err := os.Stat(t)
			if err != nil {
				continue
			}
			if info.IsDir() {
				filepath.WalkDir(t, func(path string, d fs.DirEntry, err error) error {
					if err != nil {
						return nil
					}
					if d.IsDir() {
						if d.Name() == "vendor" || strings.HasPrefix(d.Name(), ".") && d.Name() != "." {
							return filepath.SkipDir
						}
						return nil
					}
					if strings.HasSuffix(path, ".go") && !strings.HasSuffix(path, "_test.go") && !excluded(path, excludes) && !seen[path] {
						seen[path] = true
						out = append(out, filepath.ToSlash(path))
					}
					return nil
				})
			} else if strings.HasSuffix(t, ".go") && !excluded(t, excludes) && !seen[t] {
				seen[t] = true
				out = append(out, filepath.ToSlash(t))
			}
		}
	}
	sort.Strings(out)
	return out
}

func expandArg(arg string) []string {
	arg = strings.TrimSuffix(arg, "/")
	if arg == "./..." {
		return []string{"."}
	}
	if strings.HasSuffix(arg, "/...") {
		return []string{strings.TrimSuffix(arg, "/...")}
	}
	return []string{arg}
}

func excluded(path string, excludes []string) bool {
	path = filepath.ToSlash(path)
	for _, ex := range excludes {
		ex = filepath.ToSlash(ex)
		if strings.HasSuffix(ex, "/...") {
			if strings.HasPrefix(path, strings.TrimSuffix(ex, "/...")) {
				return true
			}
		}
		if ok, _ := filepath.Match(ex, path); ok || path == ex || strings.HasSuffix(path, strings.TrimPrefix(ex, "./")) {
			return true
		}
	}
	return false
}

func lintFile(path string, cfg config) []failure {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		return nil
	}
	disabled := disabledLines(fset, file)
	add := func(rule, cat, msg string, conf float64, start, end token.Pos, out *[]failure) {
		if !cfg.Rules[rule] || conf < cfg.Confidence {
			return
		}
		p := fset.Position(start)
		if disabled[p.Line] || disabled[0] {
			return
		}
		ep := fset.Position(end)
		*out = append(*out, failure{
			Severity: cfg.Severity, Failure: msg, RuleName: rule, Category: cat,
			Position:   position{Start: posn{filepath.ToSlash(p.Filename), p.Offset, p.Line, p.Column}, End: posn{filepath.ToSlash(ep.Filename), ep.Offset, ep.Line, ep.Column}},
			Confidence: conf, ReplacementLine: "",
		})
	}
	var out []failure
	if file.Doc == nil || !strings.Contains(file.Doc.Text(), "Package "+file.Name.Name) {
		add("package-comments", "comments", "should have a package comment", 1, file.Package, file.Name.End(), &out)
	}
	for _, im := range file.Imports {
		if im.Name != nil && im.Name.Name == "." {
			add("dot-imports", "imports", "should not use dot imports", 1, im.Pos(), im.End(), &out)
		}
		if im.Name != nil && im.Name.Name == "_" && file.Name.Name != "main" && im.Doc == nil && im.Comment == nil {
			add("blank-imports", "imports", "a blank import should be only in a main or test package, or have a comment justifying it", 1, im.Pos(), im.End(), &out)
		}
	}
	for _, d := range file.Decls {
		switch x := d.(type) {
		case *ast.FuncDecl:
			if x.Name.IsExported() && x.Doc == nil {
				add("exported", "comments", fmt.Sprintf("exported function %s should have comment or be unexported", x.Name.Name), 1, x.Pos(), x.End(), &out)
			}
			checkReceiver(x, add, &out)
			checkContextArg(x, add, &out)
			checkErrorReturn(x, add, &out)
			checkParams(x, add, &out)
		case *ast.GenDecl:
			for _, s := range x.Specs {
				switch spec := s.(type) {
				case *ast.TypeSpec:
					if spec.Name.IsExported() && x.Doc == nil && spec.Doc == nil {
						add("exported", "comments", fmt.Sprintf("exported type %s should have comment or be unexported", spec.Name.Name), 1, spec.Pos(), spec.End(), &out)
					}
					checkName("type", spec.Name, add, &out)
				case *ast.ValueSpec:
					kind := strings.ToLower(x.Tok.String())
					for _, n := range spec.Names {
						if n.IsExported() && x.Doc == nil && spec.Doc == nil {
							add("exported", "comments", fmt.Sprintf("exported %s %s should have comment or be unexported", kind, n.Name), 1, spec.Pos(), spec.End(), &out)
						}
						checkName(kind, n, add, &out)
					}
					checkVarDecl(spec, add, &out)
				}
			}
		}
	}
	ast.Inspect(file, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.AssignStmt:
			if len(x.Lhs) == 1 && len(x.Rhs) == 1 && (x.Tok == token.ADD_ASSIGN || x.Tok == token.SUB_ASSIGN) {
				if lit, ok := x.Rhs[0].(*ast.BasicLit); ok && lit.Value == "1" {
					op := "++"
					if x.Tok == token.SUB_ASSIGN {
						op = "--"
					}
					add("increment-decrement", "unary-op", fmt.Sprintf("should replace %s %s 1 with %s%s", exprString(x.Lhs[0]), x.Tok.String(), exprString(x.Lhs[0]), op), .8, x.Pos(), x.End(), &out)
				}
			}
		case *ast.IfStmt:
			if x.Else != nil && len(x.Body.List) > 0 && endsWithReturn(x.Body.List[len(x.Body.List)-1]) {
				add("indent-error-flow", "", "if block ends with a return statement, so drop this else and outdent its block", 1, x.Else.Pos(), x.Else.End(), &out)
			}
		case *ast.CallExpr:
			if sel, ok := x.Fun.(*ast.SelectorExpr); ok {
				if pkg, ok := sel.X.(*ast.Ident); ok && pkg.Name == "context" && sel.Sel.Name == "WithValue" && len(x.Args) >= 2 {
					if _, ok := x.Args[1].(*ast.BasicLit); ok {
						add("context-keys-type", "bad practice", "should not use basic type string as key in context.WithValue", 1, x.Args[1].Pos(), x.Args[1].End(), &out)
					}
				}
				if (pkgIdent(sel.X, "errors") && sel.Sel.Name == "New") || (pkgIdent(sel.X, "fmt") && sel.Sel.Name == "Errorf") {
					if len(x.Args) > 0 {
						if lit, ok := x.Args[0].(*ast.BasicLit); ok && lit.Kind == token.STRING {
							s, _ := strconv.Unquote(lit.Value)
							if badErrorString(s) {
								add("error-strings", "errors", "error strings should not be capitalized or end with punctuation or a newline", .8, lit.Pos(), lit.End(), &out)
							}
						}
					}
				}
			}
		case *ast.RangeStmt:
			if id, ok := x.Value.(*ast.Ident); ok && id.Name == "_" {
				add("range", "range", "should omit 2nd value from range; this loop is equivalent to `for "+exprString(x.Key)+" := range ...`", .8, x.Value.Pos(), x.Value.End(), &out)
			}
		}
		return true
	})
	return out
}

func checkReceiver(fn *ast.FuncDecl, add func(string, string, string, float64, token.Pos, token.Pos, *[]failure), out *[]failure) {
	if fn.Recv == nil || len(fn.Recv.List) == 0 || len(fn.Recv.List[0].Names) == 0 {
		return
	}
	n := fn.Recv.List[0].Names[0]
	if n.Name == "this" || n.Name == "self" || n.Name == "me" {
		add("receiver-naming", "naming", fmt.Sprintf("receiver name %s should be a reflection of its identity; don't use generic names such as \"this\" or \"self\"", n.Name), 1, n.Pos(), n.End(), out)
	}
}

func checkContextArg(fn *ast.FuncDecl, add func(string, string, string, float64, token.Pos, token.Pos, *[]failure), out *[]failure) {
	if fn.Type.Params == nil {
		return
	}
	for i, p := range fn.Type.Params.List {
		if isContextType(p.Type) && i > 0 {
			add("context-as-argument", "arg-order", "context.Context should be the first parameter of a function", 1, p.Pos(), p.End(), out)
		}
	}
}

func checkErrorReturn(fn *ast.FuncDecl, add func(string, string, string, float64, token.Pos, token.Pos, *[]failure), out *[]failure) {
	if fn.Type.Results == nil || len(fn.Type.Results.List) < 2 {
		return
	}
	for i, r := range fn.Type.Results.List {
		if isIdentType(r.Type, "error") && i != len(fn.Type.Results.List)-1 {
			add("error-return", "errors", "error should be the last type when returning multiple items", 1, r.Pos(), r.End(), out)
		}
	}
}

func checkVarDecl(spec *ast.ValueSpec, add func(string, string, string, float64, token.Pos, token.Pos, *[]failure), out *[]failure) {
	if spec.Type == nil || len(spec.Values) != len(spec.Names) {
		return
	}
	for i, v := range spec.Values {
		lit, ok := v.(*ast.BasicLit)
		if !ok {
			continue
		}
		if lit.Kind == token.STRING && isIdentType(spec.Type, "string") {
			add("var-declaration", "redundant-type", fmt.Sprintf("should omit type string from declaration of var %s; it will be inferred from the right-hand side", spec.Names[i].Name), .8, spec.Names[i].Pos(), spec.Names[i].End(), out)
		}
		if lit.Kind == token.INT || lit.Kind == token.FLOAT {
			if id, ok := spec.Type.(*ast.Ident); ok && (id.Name == "int" || id.Name == "float64" || id.Name == "float32") {
				add("var-declaration", "redundant-type", fmt.Sprintf("should omit type %s from declaration of var %s; it will be inferred from the right-hand side", id.Name, spec.Names[i].Name), .8, spec.Names[i].Pos(), spec.Names[i].End(), out)
			}
		}
	}
}

func disabledLines(fset *token.FileSet, file *ast.File) map[int]bool {
	m := map[int]bool{}
	for _, cg := range file.Comments {
		for _, c := range cg.List {
			if strings.Contains(c.Text, "revive:disable") && strings.Contains(c.Text, "next-line") {
				m[fset.Position(c.Pos()).Line+1] = true
			}
			if strings.TrimSpace(c.Text) == "//revive:disable" {
				m[0] = true
			}
		}
	}
	return m
}

func checkParams(fn *ast.FuncDecl, add func(string, string, string, float64, token.Pos, token.Pos, *[]failure), out *[]failure) {
	if fn.Body == nil || fn.Type.Params == nil {
		return
	}
	used := map[string]bool{}
	ast.Inspect(fn.Body, func(n ast.Node) bool {
		if id, ok := n.(*ast.Ident); ok {
			used[id.Name] = true
		}
		return true
	})
	for _, f := range fn.Type.Params.List {
		for _, n := range f.Names {
			if n.Name != "_" && !used[n.Name] {
				add("unused-parameter", "unused", fmt.Sprintf("parameter '%s' seems to be unused, consider removing or renaming it as _", n.Name), .8, n.Pos(), n.End(), out)
			}
		}
	}
}

func checkName(kind string, id *ast.Ident, add func(string, string, string, float64, token.Pos, token.Pos, *[]failure), out *[]failure) {
	name := id.Name
	if name == "_" {
		return
	}
	if strings.Contains(name, "_") {
		if strings.ToUpper(name) == name {
			add("var-naming", "naming", fmt.Sprintf("don't use ALL_CAPS in Go names; use CamelCase"), .8, id.Pos(), id.End(), out)
		} else {
			add("var-naming", "naming", fmt.Sprintf("don't use underscores in Go names; %s %s should be %s", kind, name, camel(name)), .9, id.Pos(), id.End(), out)
		}
	}
}

func camel(s string) string {
	parts := strings.Split(s, "_")
	for i, p := range parts {
		if p == "" {
			continue
		}
		if i == 0 {
			parts[i] = p
		} else {
			parts[i] = strings.ToUpper(p[:1]) + p[1:]
		}
	}
	return strings.Join(parts, "")
}

func pkgIdent(e ast.Expr, name string) bool {
	id, ok := e.(*ast.Ident)
	return ok && id.Name == name
}

func isIdentType(e ast.Expr, name string) bool {
	id, ok := e.(*ast.Ident)
	return ok && id.Name == name
}

func isContextType(e ast.Expr) bool {
	sel, ok := e.(*ast.SelectorExpr)
	if !ok || sel.Sel.Name != "Context" {
		return false
	}
	id, ok := sel.X.(*ast.Ident)
	return ok && id.Name == "context"
}

func badErrorString(s string) bool {
	if s == "" {
		return false
	}
	r := rune(s[0])
	return (r >= 'A' && r <= 'Z') || strings.HasSuffix(s, ".") || strings.HasSuffix(s, "!") || strings.HasSuffix(s, "\n")
}

func endsWithReturn(s ast.Stmt) bool {
	_, ok := s.(*ast.ReturnStmt)
	return ok
}

func exprString(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.Ident:
		return x.Name
	case *ast.SelectorExpr:
		return exprString(x.X) + "." + x.Sel.Name
	default:
		return "value"
	}
}

func sortFailures(fs []failure) {
	sort.SliceStable(fs, func(i, j int) bool {
		a, b := fs[i], fs[j]
		if a.Position.Start.Filename != b.Position.Start.Filename {
			return a.Position.Start.Filename < b.Position.Start.Filename
		}
		if a.Position.Start.Line != b.Position.Start.Line {
			return a.Position.Start.Line < b.Position.Start.Line
		}
		if a.Position.Start.Column != b.Position.Start.Column {
			return a.Position.Start.Column < b.Position.Start.Column
		}
		return a.RuleName < b.RuleName
	})
}

func formatDefault(fs []failure) {
	for _, f := range fs {
		fmt.Printf("%s:%d:%d: %s\n", f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column, f.Failure)
	}
}

func formatUnix(fs []failure) {
	for _, f := range fs {
		fmt.Printf("%s:%d:%d: [%s] %s\n", f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column, f.RuleName, f.Failure)
	}
	if len(fs) > 0 {
		fmt.Println()
	}
}

func formatPlain(fs []failure) {
	for _, f := range fs {
		fmt.Printf("%s:%d:%d: %s https://revive.run/r#%s\n", f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column, f.Failure, f.RuleName)
	}
	if len(fs) > 0 {
		fmt.Println()
	}
}

func formatJSON(fs []failure) error {
	b, err := json.Marshal(fs)
	if err == nil {
		fmt.Println(string(b))
	}
	return err
}

func formatNDJSON(fs []failure) error {
	enc := json.NewEncoder(os.Stdout)
	for _, f := range fs {
		if err := enc.Encode(f); err != nil {
			return err
		}
	}
	return nil
}

func formatStylish(fs []failure) {
	group := map[string][]failure{}
	var files []string
	for _, f := range fs {
		if _, ok := group[f.Position.Start.Filename]; !ok {
			files = append(files, f.Position.Start.Filename)
		}
		group[f.Position.Start.Filename] = append(group[f.Position.Start.Filename], f)
	}
	sort.Strings(files)
	for _, file := range files {
		fmt.Println(file)
		for _, f := range group[file] {
			fmt.Printf("  (%d, %d)  https://revive.run/r#%s  %s\n", f.Position.Start.Line, f.Position.Start.Column, f.RuleName, f.Failure)
		}
		fmt.Println()
	}
	if len(fs) > 0 {
		fmt.Printf("\n ✖ %d problems (0 errors) (%d warnings)\n", len(fs), len(fs))
	}
}

func formatFriendly(fs []failure) {
	counts := map[string]int{}
	for _, f := range fs {
		fmt.Printf("  ⚠  https://revive.run/r#%s  %s\n  %s:%d:%d\n\n", f.RuleName, f.Failure, f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column)
		counts[f.RuleName]++
	}
	if len(fs) > 0 {
		fmt.Printf("⚠ %d problems (0 errors, %d warnings)\n\nWarnings:\n", len(fs), len(fs))
		var rules []string
		for r := range counts {
			rules = append(rules, r)
		}
		sort.Slice(rules, func(i, j int) bool { return counts[rules[i]] > counts[rules[j]] })
		for _, r := range rules {
			fmt.Printf("  %d  %s\n", counts[r], r)
		}
		fmt.Println()
	}
}

type cs struct {
	XMLName xml.Name `xml:"checkstyle"`
	Version string   `xml:"version,attr"`
	Files   []csFile `xml:"file"`
}
type csFile struct {
	Name   string    `xml:"name,attr"`
	Errors []csError `xml:"error"`
}
type csError struct {
	Line     int    `xml:"line,attr"`
	Column   int    `xml:"column,attr"`
	Message  string `xml:"message,attr"`
	Severity string `xml:"severity,attr"`
	Source   string `xml:"source,attr"`
}

func formatCheckstyle(fs []failure) error {
	group := map[string][]failure{}
	var files []string
	for _, f := range fs {
		if _, ok := group[f.Position.Start.Filename]; !ok {
			files = append(files, f.Position.Start.Filename)
		}
		group[f.Position.Start.Filename] = append(group[f.Position.Start.Filename], f)
	}
	sort.Strings(files)
	out := cs{Version: "5.0"}
	for _, name := range files {
		cf := csFile{Name: name}
		for _, f := range group[name] {
			cf.Errors = append(cf.Errors, csError{f.Position.Start.Line, f.Position.Start.Column, fmt.Sprintf("%s (confidence %g)", f.Failure, f.Confidence), f.Severity, "revive/" + f.RuleName})
		}
		out.Files = append(out.Files, cf)
	}
	fmt.Println(`<?xml version='1.0' encoding='UTF-8'?>`)
	b, err := xml.MarshalIndent(out, "", "    ")
	if err == nil {
		fmt.Println(string(b))
	}
	return err
}

func formatSARIF(fs []failure) error {
	type loc struct {
		PhysicalLocation map[string]interface{} `json:"physicalLocation"`
	}
	type res struct {
		Level     string            `json:"level"`
		Locations []loc             `json:"locations"`
		Message   map[string]string `json:"message"`
		RuleID    string            `json:"ruleId"`
	}
	var results []res
	for _, f := range fs {
		results = append(results, res{
			Level: f.Severity,
			Locations: []loc{{PhysicalLocation: map[string]interface{}{
				"artifactLocation": map[string]string{"uri": f.Position.Start.Filename},
				"region":           map[string]int{"startLine": f.Position.Start.Line, "startColumn": f.Position.Start.Column},
			}}},
			Message: map[string]string{"text": f.Failure},
			RuleID:  f.RuleName,
		})
	}
	doc := map[string]interface{}{"version": "2.1.0", "$schema": "https://json.schemastore.org/sarif-2.1.0.json", "runs": []map[string]interface{}{{"tool": map[string]interface{}{"driver": map[string]interface{}{"name": "revive"}}, "results": results}}}
	b, err := json.MarshalIndent(doc, "", "  ")
	if err == nil {
		fmt.Println(string(b))
	}
	return err
}

var _ = regexp.MustCompile
