module reviveclone

go 1.21
