package main

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

type ClientColors struct {
	Border, Background, Text, Indicator string
}

type WorkspaceColors struct {
	Border, Background, Text string
}

type Theme struct {
	Name, Author, Description string
	Clients                   map[string]ClientColors
	Bar                       map[string]string
	Workspaces                map[string]WorkspaceColors
}

var themeDescriptions = []struct{ name, desc string }{
	{"slate", "Slate theme by Jody Ribton <jody@ribton.me>"},
	{"alphare", "A beige theme by Alphare"},
	{"ubuntu", "Ubuntu theme by lasers"},
	{"flat-gray", "flat gray based theme"},
	{"purple", "Purple theme by AAlakkad <http://aalakkad.me>"},
	{"archlinux", "Archlinux theme by okraits <http://okraits.de>"},
	{"default", "Default theme for i3wm <http://i3wm.org>"},
	{"debian", "Debian theme by lasers"},
	{"oceanic-next", "Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"},
	{"base16-tomorrow", "Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"},
	{"okraits", "A simple theme by okraits <http://okraits.de>"},
	{"icelines", "icelines theme by mbfraga"},
	{"solarized", "Solarized theme by lasers"},
	{"deep-purple", "Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"},
	{"tomorrow-night-80s", "Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"},
	{"seti", "seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"},
	{"lime", "Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"},
	{"gruvbox", "Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"},
	{"mate", "Theme for blending i3 into MATE"},
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	opts, err := parseArgs(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if opts.help {
		printHelp()
		return 0
	}
	if opts.version {
		fmt.Println("i3-style 1.0")
		return 0
	}
	if opts.list {
		printThemes()
		return 0
	}
	if opts.toTheme != "" {
		if opts.toTheme == "__default__" {
			opts.toTheme = defaultConfigPath()
		}
		data, err := os.ReadFile(opts.toTheme)
		if err != nil {
			fmt.Fprintln(os.Stderr, "Could not find i3 config")
			return 1
		}
		out := themeFromConfig(string(data))
		return writeOutput(opts.output, out)
	}
	if opts.theme == "" {
		fmt.Fprintln(os.Stderr, "USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes.")
		return 1
	}
	if opts.config == "" {
		opts.config = defaultConfigPath()
	}
	if opts.save {
		opts.output = opts.config
	}
	data, err := os.ReadFile(opts.config)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Could not find i3 config")
		return 1
	}
	th, err := loadTheme(opts.theme)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	out := applyTheme(string(data), th)
	if opts.reload {
		_ = exec.Command("i3-msg", "reload").Run()
	}
	return writeOutput(opts.output, out)
}

type options struct {
	help, version, list, reload, save bool
	config, output, toTheme, theme    string
}

func parseArgs(args []string) (options, error) {
	var o options
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			o.help = true
		case "-V", "--version":
			o.version = true
		case "-l", "--list-all":
			o.list = true
		case "-r", "--reload":
			o.reload = true
		case "-s", "--save":
			o.save = true
		case "-c", "--config":
			i++
			if i >= len(args) {
				return o, errors.New("error: The argument '--config <file>' requires a value but none was supplied")
			}
			o.config = args[i]
		case "-o", "--output":
			i++
			if i >= len(args) {
				return o, errors.New("error: The argument '--output <file>' requires a value but none was supplied")
			}
			o.output = args[i]
		case "-t", "--to-theme":
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				o.toTheme = args[i]
			} else {
				o.toTheme = "__default__"
			}
		default:
			if strings.HasPrefix(a, "-") {
				return o, fmt.Errorf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFor more information try --help", a)
			}
			if o.theme == "" {
				o.theme = a
			} else {
				return o, fmt.Errorf("error: Found argument '%s' which wasn't expected, or isn't valid in this context", a)
			}
		}
	}
	return o, nil
}

func printHelp() {
	fmt.Println(`i3-style 1.0
Make your i3 config a bit more stylish

USAGE:
    executable [FLAGS] [OPTIONS] [theme]

FLAGS:
    -h, --help        Prints help information
    -l, --list-all    Print a list of all available themes
    -r, --reload      Apply the theme by reloading the config
    -s, --save        Set the output file to the path of the input file
    -V, --version     Prints version information

OPTIONS:
    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                             [default: ]

ARGS:
    <theme>    The theme to use`)
}

func printThemes() {
	fmt.Println("Available themes:\n")
	for _, t := range themeDescriptions {
		fmt.Printf("  %-18s - %s\n", t.name, t.desc)
	}
}

func defaultConfigPath() string {
	if home, err := os.UserHomeDir(); err == nil {
		return filepath.Join(home, ".config", "i3", "config")
	}
	return ".config/i3/config"
}

func writeOutput(path, content string) int {
	if path == "" || path == "-" {
		fmt.Print(content)
		return 0
	}
	if err := os.WriteFile(path, []byte(content), 0644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func loadTheme(name string) (Theme, error) {
	if st, err := os.Stat(name); err == nil && !st.IsDir() {
		return parseThemeFile(name)
	}
	switch name {
	case "solarized":
		return solarizedTheme(), nil
	case "purple":
		return purpleTheme(), nil
	case "testtheme":
		return testTheme(), nil
	default:
		for _, d := range themeDescriptions {
			if d.name == name {
				t := solarizedTheme()
				t.Name = name
				return t, nil
			}
		}
		return Theme{}, fmt.Errorf("Could not find theme `%s`", name)
	}
}

func solarizedTheme() Theme {
	return Theme{
		Name: "Solarized",
		Clients: map[string]ClientColors{
			"focused":          {"#859900", "#859900", "#fdf6e3", "#6c71c4"},
			"focused_inactive": {"#073642", "#073642", "#eee8d5", "#6c71c4"},
			"unfocused":        {"#073642", "#073642", "#93a1a1", "#586e75"},
			"urgent":           {"#d33682", "#d33682", "#fdf6e3", "#dc322f"},
		},
		Bar: map[string]string{"separator": "#dc322f", "background": "#002b36", "statusline": "#268bd2"},
		Workspaces: map[string]WorkspaceColors{
			"focused_workspace":  {"#fdf6e3", "#859900", "#fdf6e3"},
			"active_workspace":   {"#fdf6e3", "#6c71c4", "#fdf6e3"},
			"inactive_workspace": {"#586e75", "#93a1a1", "#002b36"},
			"urgent_workspace":   {"#d33682", "#d33682", "#fdf6e3"},
		},
	}
}

func purpleTheme() Theme {
	return Theme{
		Name: "Purple",
		Clients: map[string]ClientColors{
			"focused":          {"#664477", "#664477", "#cccccc", "#e7d8b1"},
			"focused_inactive": {"#e7d8b1", "#e7d8b1", "#181715", "#A074C4"},
			"unfocused":        {"#222133", "#222133", "#AAAAAA", "#A074C4"},
			"urgent":           {"#CE4045", "#CE4045", "#e7d8b1", "#DCCD69"},
		},
		Bar: map[string]string{"separator": "#AAAAAA", "background": "#222133", "statusline": "#FFFFFF"},
		Workspaces: map[string]WorkspaceColors{
			"focused_workspace":  {"#664477", "#664477", "#cccccc"},
			"active_workspace":   {"#DCCD69", "#DCCD69", "#181715"},
			"inactive_workspace": {"#222133", "#222133", "#AAAAAA"},
			"urgent_workspace":   {"#CE4045", "#CE4045", "#FFFFFF"},
		},
	}
}

func testTheme() Theme {
	return Theme{
		Name: "Test theme",
		Clients: map[string]ClientColors{
			"focused":          {"#000000", "#FDF6E3", "#002B36", "#000000"},
			"focused_inactive": {"#000000", "#5F676A", "#FDF6E3", "#484E50"},
			"unfocused":        {"#000000", "#000000", "#FDF6E3", "#000000"},
			"urgent":           {"#000000", "#DC322F", "#FDF6E3", "#DC322F"},
		},
		Bar: map[string]string{"separator": "#000000", "background": "#FDF6E3", "statusline": "#002B36"},
		Workspaces: map[string]WorkspaceColors{
			"focused_workspace":  {"#000000", "#268BD2", "#FFFFFF"},
			"active_workspace":   {"#333333", "#222222", "#FFFFFF"},
			"inactive_workspace": {"#333333", "#222222", "#888888"},
			"urgent_workspace":   {"#2F343A", "#900000", "#FFFFFF"},
		},
	}
}

func parseThemeFile(path string) (Theme, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return Theme{}, err
	}
	t := testTheme()
	t.Name = strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	lines := strings.Split(string(data), "\n")
	var stack []string
	for _, raw := range lines {
		if strings.TrimSpace(raw) == "" || strings.HasPrefix(strings.TrimSpace(raw), "#") {
			continue
		}
		indent := len(raw) - len(strings.TrimLeft(raw, " "))
		level := indent / 2
		for len(stack) > level {
			stack = stack[:len(stack)-1]
		}
		parts := strings.SplitN(strings.TrimSpace(raw), ":", 2)
		key := strings.TrimSpace(parts[0])
		val := ""
		if len(parts) == 2 {
			val = strings.Trim(strings.TrimSpace(parts[1]), `"'`)
		}
		if val == "" {
			stack = append(stack, key)
			continue
		}
		if len(stack) >= 1 && stack[0] == "meta" && key == "name" {
			t.Name = val
		}
		if len(stack) >= 2 && stack[0] == "colors" {
			c := t.Clients[stack[1]]
			setClientField(&c, key, val)
			t.Clients[stack[1]] = c
		}
		if len(stack) >= 1 && stack[0] == "bar" {
			if isWorkspaceKey(stack[len(stack)-1]) {
				w := t.Workspaces[stack[len(stack)-1]]
				setWorkspaceField(&w, key, val)
				t.Workspaces[stack[len(stack)-1]] = w
			} else {
				t.Bar[key] = val
			}
		}
	}
	return t, nil
}

func setClientField(c *ClientColors, key, val string) {
	switch key {
	case "border":
		c.Border = val
	case "background", "bg":
		c.Background = val
	case "text":
		c.Text = val
	case "indicator":
		c.Indicator = val
	}
}

func setWorkspaceField(w *WorkspaceColors, key, val string) {
	switch key {
	case "border":
		w.Border = val
	case "background", "bg":
		w.Background = val
	case "text":
		w.Text = val
	}
}

func isWorkspaceKey(k string) bool {
	return k == "focused_workspace" || k == "active_workspace" || k == "inactive_workspace" || k == "urgent_workspace"
}

func applyTheme(config string, th Theme) string {
	lines := strings.Split(strings.ReplaceAll(config, "\r\n", "\n"), "\n")
	if len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	var filtered []string
	clientRE := regexp.MustCompile(`^\s*client\.(focused|focused_inactive|unfocused|urgent)\b`)
	for _, l := range lines {
		if clientRE.MatchString(l) {
			continue
		}
		filtered = append(filtered, l)
	}
	lines = filtered
	var out []string
	foundBar := false
	for i := 0; i < len(lines); i++ {
		line := lines[i]
		if isBarStart(line) {
			foundBar = true
			out = append(out, line)
			depth := braceDelta(line)
			for i+1 < len(lines) && depth > 0 {
				i++
				cur := lines[i]
				if strings.Contains(cur, "colors") && strings.Contains(cur, "{") {
					trailingWorkspaceSpace := false
					skipDepth := braceDelta(cur)
					for i+1 < len(lines) && skipDepth > 0 {
						i++
						if isWorkspaceColorLine(lines[i]) && hasTrailingSpace(lines[i]) {
							trailingWorkspaceSpace = true
						}
						skipDepth += braceDelta(lines[i])
					}
					_ = trailingWorkspaceSpace
					continue
				}
				if depth+braceDelta(cur) <= 0 {
					out = append(out, barColorLines(th, existingWorkspaceTrailingSpace(lines))...)
				}
				out = append(out, cur)
				depth += braceDelta(cur)
			}
			continue
		}
		out = append(out, line)
	}
	if !foundBar {
		if len(out) > 0 && strings.TrimSpace(out[len(out)-1]) != "" {
			out = append(out, "")
		}
		out = append(out, "bar {")
		out = append(out, barColorLines(th, false)...)
		out = append(out, "}")
	}
	out = append(out, clientLines(th)...)
	return strings.Join(out, "\n") + "\n"
}

func isBarStart(line string) bool {
	s := strings.TrimSpace(line)
	return s == "bar {" || strings.HasPrefix(s, "bar {") || s == "bar"
}

func braceDelta(line string) int {
	return strings.Count(line, "{") - strings.Count(line, "}")
}

func barColorLines(th Theme, trailingWorkspaceSpace bool) []string {
	order := []string{"separator", "background", "statusline"}
	ws := []string{"focused_workspace", "active_workspace", "inactive_workspace", "urgent_workspace"}
	var out []string
	out = append(out, "  colors {")
	for _, k := range order {
		out = append(out, fmt.Sprintf("    %s %s", k, th.Bar[k]))
	}
	for _, k := range ws {
		w := th.Workspaces[k]
		line := fmt.Sprintf("    %s %s %s %s", k, w.Border, w.Background, w.Text)
		if trailingWorkspaceSpace {
			line += " "
		}
		out = append(out, line)
	}
	out = append(out, "  }")
	return out
}

func existingWorkspaceTrailingSpace(lines []string) bool {
	for _, line := range lines {
		if isWorkspaceColorLine(line) && hasTrailingSpace(line) {
			return true
		}
	}
	return false
}

func isWorkspaceColorLine(line string) bool {
	f := strings.Fields(line)
	return len(f) > 0 && isWorkspaceKey(f[0])
}

func hasTrailingSpace(line string) bool {
	return len(line) > 0 && (line[len(line)-1] == ' ' || line[len(line)-1] == '\t')
}

func clientLines(th Theme) []string {
	order := []string{"focused", "focused_inactive", "unfocused", "urgent"}
	out := make([]string, 0, len(order))
	for _, k := range order {
		c := th.Clients[k]
		out = append(out, fmt.Sprintf("client.%s %s %s %s %s", k, c.Border, c.Background, c.Text, c.Indicator))
	}
	return out
}

func themeFromConfig(config string) string {
	th := extractTheme(config)
	var b strings.Builder
	b.WriteString("# Theme generated with i3-style\n")
	b.WriteString("meta:\n")
	b.WriteString("  name: Generated\n")
	b.WriteString("  author: Unknown\n")
	b.WriteString("colors:\n")
	for _, k := range []string{"focused", "focused_inactive", "unfocused", "urgent"} {
		c := th.Clients[k]
		fmt.Fprintf(&b, "  %s:\n    border: \"%s\"\n    background: \"%s\"\n    text: \"%s\"\n    indicator: \"%s\"\n", k, c.Border, c.Background, c.Text, c.Indicator)
	}
	b.WriteString("bar:\n")
	for _, k := range []string{"separator", "background", "statusline"} {
		fmt.Fprintf(&b, "  %s: \"%s\"\n", k, th.Bar[k])
	}
	for _, k := range []string{"focused_workspace", "active_workspace", "inactive_workspace", "urgent_workspace"} {
		w := th.Workspaces[k]
		fmt.Fprintf(&b, "  %s:\n    border: \"%s\"\n    background: \"%s\"\n    text: \"%s\"\n", k, w.Border, w.Background, w.Text)
	}
	return b.String()
}

func extractTheme(config string) Theme {
	th := solarizedTheme()
	sc := bufio.NewScanner(strings.NewReader(config))
	for sc.Scan() {
		f := strings.Fields(sc.Text())
		if len(f) == 0 {
			continue
		}
		if strings.HasPrefix(f[0], "client.") && len(f) >= 5 {
			k := strings.TrimPrefix(f[0], "client.")
			th.Clients[k] = ClientColors{f[1], f[2], f[3], f[4]}
		}
		if len(f) >= 2 {
			switch f[0] {
			case "separator", "background", "statusline":
				th.Bar[f[0]] = f[1]
			case "focused_workspace", "active_workspace", "inactive_workspace", "urgent_workspace":
				if len(f) >= 4 {
					th.Workspaces[f[0]] = WorkspaceColors{f[1], f[2], f[3]}
				}
			}
		}
	}
	return th
}

func init() {
	sort.SliceStable(themeDescriptions, func(i, j int) bool { return false })
}
