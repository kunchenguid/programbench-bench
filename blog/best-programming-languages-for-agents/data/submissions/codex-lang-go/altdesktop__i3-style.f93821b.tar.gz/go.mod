module i3style

go 1.21
