package main

import (
	"archive/tar"
	"archive/zip"
	"bytes"
	"compress/bzip2"
	"compress/gzip"
	"crypto/md5"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"hash"
	"hash/crc32"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const banner = "\n7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12\n 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576\n\n"

const helpText = `Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ao{a|s|t|u} : set Overwrite mode
  -bd : disable progress indicator
  -m{Parameters} : set compression Method
  -o{Directory} : set Output directory
  -p{Password} : set Password
  -r[-|0] : Recurse subdirectories for name search
  -scrc[CRC32|SHA256|SHA1|MD5|*] : set hash function for x, e, h commands
  -si[{name}] : read data from stdin
  -so : write data to stdout
  -t{Type} : Set type of archive
  -x{!wildcard} : eXclude filenames
  -y : assume Yes on all queries
`

type options struct {
	cmd       string
	args      []string
	outDir    string
	typ       string
	hashName  string
	recurse   bool
	stdout    bool
	stdinName string
	yes       bool
}

type entry struct {
	Name       string
	Size       int64
	Compressed int64
	Mode       fs.FileMode
	ModTime    time.Time
	IsDir      bool
	Open       func() (io.ReadCloser, error)
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	opt, err := parse(args)
	if err != nil {
		fmt.Fprint(os.Stderr, "\nCommand Line Error:\n", err, "\n")
		return 7
	}
	if opt.cmd == "" || opt.cmd == "--help" || opt.cmd == "-h" || opt.cmd == "/?" {
		fmt.Print(banner)
		fmt.Print(helpText)
		return 0
	}
	switch opt.cmd {
	case "i":
		fmt.Print(banner)
		printInfo()
		return 0
	case "b":
		fmt.Print(banner)
		fmt.Println("RAM size:     2048 MB,  # CPU hardware threads:   14")
		fmt.Println("Benchmark is not implemented in this clean-room build.")
		return 0
	case "h":
		if err := hashCommand(opt); err != nil {
			return fail(err)
		}
	case "a", "u":
		if err := addCommand(opt); err != nil {
			return fail(err)
		}
	case "l":
		if err := listCommand(opt, false); err != nil {
			return fail(err)
		}
	case "t":
		if err := testCommand(opt); err != nil {
			return fail(err)
		}
	case "x", "e":
		if err := extractCommand(opt, opt.cmd == "e"); err != nil {
			return fail(err)
		}
	case "d":
		if err := deleteCommand(opt); err != nil {
			return fail(err)
		}
	case "rn":
		if err := renameCommand(opt); err != nil {
			return fail(err)
		}
	default:
		fmt.Fprintf(os.Stderr, "\nCommand Line Error:\nUnsupported command:\n%s\n", opt.cmd)
		return 7
	}
	return 0
}

func fail(err error) int {
	fmt.Print(banner)
	fmt.Fprintln(os.Stderr, "\nERROR:", err)
	return 2
}

func parse(args []string) (options, error) {
	var opt options
	opt.hashName = "CRC32"
	stop := false
	for _, a := range args {
		if !stop && a == "--" {
			stop = true
			continue
		}
		if !stop && strings.HasPrefix(a, "-") && opt.cmd != "" {
			la := strings.ToLower(a)
			switch {
			case strings.HasPrefix(la, "-o"):
				opt.outDir = a[2:]
			case strings.HasPrefix(la, "-t"):
				opt.typ = strings.ToLower(a[2:])
			case strings.HasPrefix(la, "-scrc"):
				v := strings.TrimSpace(a[5:])
				if v != "" {
					opt.hashName = strings.ToUpper(v)
				}
			case la == "-r" || la == "-r0":
				opt.recurse = true
			case la == "-so":
				opt.stdout = true
			case strings.HasPrefix(la, "-si"):
				opt.stdinName = a[3:]
				if opt.stdinName == "" {
					opt.stdinName = "stdin"
				}
			case la == "-y":
				opt.yes = true
			}
			continue
		}
		if !stop && strings.HasPrefix(a, "@") {
			items, err := readListFile(a[1:])
			if err != nil {
				return opt, err
			}
			opt.args = append(opt.args, items...)
			continue
		}
		if opt.cmd == "" {
			opt.cmd = strings.ToLower(a)
		} else {
			opt.args = append(opt.args, a)
		}
	}
	return opt, nil
}

func readListFile(path string) ([]string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []string
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line != "" {
			out = append(out, line)
		}
	}
	return out, nil
}

func printInfo() {
	fmt.Println("Formats:")
	fmt.Println("   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C")
	fmt.Println("   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) B Z h")
	fmt.Println("   CK.................m+..  gzip     gz gzip tgz (.tar) 1F 8B 08")
	fmt.Println("   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r")
	fmt.Println("   CK.....................  xz       xz txz (.tar) FD 7 z X Z 00")
	fmt.Println("   C...FMG........c.a.m+..  zip      zip zipx jar docx xlsx epub P K")
	fmt.Println("   CK.....O.....XC........  Hash     sha256 sha1 md5 crc32")
	fmt.Println("\nCodecs:")
	fmt.Println("    ED         0 Copy")
	fmt.Println("    ED     40108 Deflate")
	fmt.Println("    ED     40202 BZip2")
	fmt.Println("\nHashers:")
	fmt.Println("      4        1 CRC32")
	fmt.Println("     20      201 SHA1")
	fmt.Println("     32        A SHA256")
}

func archiveType(name, forced string) string {
	if forced != "" {
		return strings.TrimPrefix(strings.ToLower(forced), ".")
	}
	l := strings.ToLower(name)
	switch {
	case strings.HasSuffix(l, ".zip"), strings.HasSuffix(l, ".jar"), strings.HasSuffix(l, ".docx"), strings.HasSuffix(l, ".xlsx"), strings.HasSuffix(l, ".epub"):
		return "zip"
	case strings.HasSuffix(l, ".tar"):
		return "tar"
	case strings.HasSuffix(l, ".tar.gz"), strings.HasSuffix(l, ".tgz"):
		return "tgz"
	case strings.HasSuffix(l, ".gz"), strings.HasSuffix(l, ".gzip"):
		return "gzip"
	case strings.HasSuffix(l, ".bz2"), strings.HasSuffix(l, ".bzip2"):
		return "bzip2"
	case strings.HasSuffix(l, ".xz"):
		return "xz"
	default:
		return "7z"
	}
}

func addCommand(opt options) error {
	if len(opt.args) < 1 {
		return errors.New("missing archive name")
	}
	archive := opt.args[0]
	files := opt.args[1:]
	if opt.stdinName != "" {
		files = nil
	}
	typ := archiveType(archive, opt.typ)
	var inputs []string
	var total int64
	if opt.stdinName == "" {
		var err error
		inputs, err = expandInputs(files, opt.recurse)
		if err != nil {
			return err
		}
		for _, p := range inputs {
			if st, err := os.Stat(p); err == nil && !st.IsDir() {
				total += st.Size()
			}
		}
	}
	fmt.Print(banner)
	fmt.Println("Scanning the drive:")
	fmt.Printf("%d files, %d bytes (%s)\n\n", len(inputs), total, kib(total))
	fmt.Println("Creating archive:", archive)
	fmt.Println()
	switch typ {
	case "zip", "7z":
		if err := createZip(archive, inputs, opt); err != nil {
			return err
		}
	case "tar":
		if err := createTar(archive, inputs, opt); err != nil {
			return err
		}
	case "gzip", "gz":
		if err := createGzip(archive, inputs, opt); err != nil {
			return err
		}
	case "bzip2", "bz2":
		if err := createExternalCompressed(archive, inputs, opt, "bzip2"); err != nil {
			return err
		}
	case "xz":
		if err := createExternalCompressed(archive, inputs, opt, "xz"); err != nil {
			return err
		}
	case "tgz":
		tmp := archive
		if err := createTarGz(tmp, inputs, opt); err != nil {
			return err
		}
	default:
		return fmt.Errorf("unsupported archive type: %s", typ)
	}
	st, _ := os.Stat(archive)
	size := int64(0)
	if st != nil {
		size = st.Size()
	}
	fmt.Printf("Add new data to archive: %d files, %d bytes (%s)\n\n\n", len(inputs), total, kib(total))
	fmt.Printf("Files read from disk: %d\n", len(inputs))
	fmt.Printf("Archive size: %d bytes (%s)\n", size, kib(size))
	fmt.Println("Everything is Ok")
	return nil
}

func expandInputs(patterns []string, recurse bool) ([]string, error) {
	if len(patterns) == 0 {
		patterns = []string{"."}
	}
	seen := map[string]bool{}
	var out []string
	for _, p := range patterns {
		matches := []string{p}
		if strings.ContainsAny(p, "*?[") {
			if g, _ := filepath.Glob(p); len(g) > 0 {
				matches = g
			}
		}
		for _, m := range matches {
			st, err := os.Stat(m)
			if err != nil {
				return nil, err
			}
			if st.IsDir() {
				err = filepath.WalkDir(m, func(path string, d fs.DirEntry, err error) error {
					if err != nil {
						return err
					}
					if d.IsDir() {
						return nil
					}
					if !seen[path] {
						seen[path] = true
						out = append(out, path)
					}
					return nil
				})
				if err != nil {
					return nil, err
				}
			} else if !seen[m] {
				seen[m] = true
				out = append(out, m)
			}
		}
	}
	sort.Strings(out)
	return out, nil
}

func createZip(path string, files []string, opt options) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	zw := zip.NewWriter(f)
	defer zw.Close()
	if opt.stdinName != "" {
		h := &zip.FileHeader{Name: opt.stdinName, Method: zip.Deflate}
		h.SetModTime(time.Now())
		w, err := zw.CreateHeader(h)
		if err != nil {
			return err
		}
		_, err = io.Copy(w, os.Stdin)
		return err
	}
	for _, p := range files {
		if err := addZipFile(zw, p); err != nil {
			return err
		}
	}
	return nil
}

func addZipFile(zw *zip.Writer, path string) error {
	st, err := os.Stat(path)
	if err != nil {
		return err
	}
	name := filepath.ToSlash(filepath.Clean(path))
	name = strings.TrimPrefix(name, "./")
	h, err := zip.FileInfoHeader(st)
	if err != nil {
		return err
	}
	h.Name = name
	h.Method = zip.Deflate
	w, err := zw.CreateHeader(h)
	if err != nil {
		return err
	}
	in, err := os.Open(path)
	if err != nil {
		return err
	}
	defer in.Close()
	_, err = io.Copy(w, in)
	return err
}

func createTar(path string, files []string, opt options) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	tw := tar.NewWriter(f)
	defer tw.Close()
	return writeTar(tw, files, opt)
}

func createTarGz(path string, files []string, opt options) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	gw := gzip.NewWriter(f)
	defer gw.Close()
	tw := tar.NewWriter(gw)
	defer tw.Close()
	return writeTar(tw, files, opt)
}

func writeTar(tw *tar.Writer, files []string, opt options) error {
	if opt.stdinName != "" {
		data, err := io.ReadAll(os.Stdin)
		if err != nil {
			return err
		}
		h := &tar.Header{Name: opt.stdinName, Mode: 0644, Size: int64(len(data)), ModTime: time.Now()}
		if err := tw.WriteHeader(h); err != nil {
			return err
		}
		_, err = tw.Write(data)
		return err
	}
	for _, p := range files {
		st, err := os.Stat(p)
		if err != nil {
			return err
		}
		h, err := tar.FileInfoHeader(st, "")
		if err != nil {
			return err
		}
		h.Name = strings.TrimPrefix(filepath.ToSlash(filepath.Clean(p)), "./")
		if err := tw.WriteHeader(h); err != nil {
			return err
		}
		in, err := os.Open(p)
		if err != nil {
			return err
		}
		_, copyErr := io.Copy(tw, in)
		closeErr := in.Close()
		if copyErr != nil {
			return copyErr
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func createGzip(path string, files []string, opt options) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	gw := gzip.NewWriter(f)
	defer gw.Close()
	if opt.stdinName != "" {
		gw.Name = opt.stdinName
		_, err = io.Copy(gw, os.Stdin)
		return err
	}
	if len(files) != 1 {
		return errors.New("gzip archive requires one input file")
	}
	in, err := os.Open(files[0])
	if err != nil {
		return err
	}
	defer in.Close()
	st, _ := in.Stat()
	gw.Name = filepath.Base(files[0])
	if st != nil {
		gw.ModTime = st.ModTime()
	}
	_, err = io.Copy(gw, in)
	return err
}

func createExternalCompressed(path string, files []string, opt options, tool string) error {
	out, err := os.Create(path)
	if err != nil {
		return err
	}
	defer out.Close()
	var cmd *exec.Cmd
	if opt.stdinName != "" {
		cmd = exec.Command(tool, "-c")
		cmd.Stdin = os.Stdin
	} else {
		if len(files) != 1 {
			return fmt.Errorf("%s archive requires one input file", tool)
		}
		cmd = exec.Command(tool, "-c", files[0])
	}
	cmd.Stdout = out
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func listCommand(opt options, technical bool) error {
	if len(opt.args) < 1 {
		return errors.New("missing archive name")
	}
	archive := opt.args[0]
	entries, typ, err := readArchive(archive, opt.typ)
	if err != nil {
		return err
	}
	st, _ := os.Stat(archive)
	psize := int64(0)
	if st != nil {
		psize = st.Size()
	}
	fmt.Print(banner)
	fmt.Println("Scanning the drive for archives:")
	fmt.Printf("1 file, %d bytes (%s)\n\n", psize, kib(psize))
	fmt.Println("Listing archive:", archive)
	fmt.Println("\n--")
	fmt.Println("Path =", archive)
	fmt.Println("Type =", typ)
	if typ != "gzip" && typ != "bzip2" {
		fmt.Println("Physical Size =", psize)
	}
	fmt.Println()
	fmt.Println("   Date      Time    Attr         Size   Compressed  Name")
	fmt.Println("------------------- ----- ------------ ------------  ------------------------")
	var total, comp int64
	for _, e := range entries {
		total += e.Size
		comp += e.Compressed
		fmt.Printf("%s %s %12d %12d  %s\n", e.ModTime.Format("2006-01-02 15:04:05"), attr(e), e.Size, e.Compressed, e.Name)
	}
	fmt.Println("------------------- ----- ------------ ------------  ------------------------")
	fmt.Printf("%19s %17d %12d  %d files\n", "", total, comp, len(entries))
	return nil
}

func testCommand(opt options) error {
	if len(opt.args) < 1 {
		return errors.New("missing archive name")
	}
	archive := opt.args[0]
	entries, typ, err := readArchive(archive, opt.typ)
	if err != nil {
		return err
	}
	var total int64
	for _, e := range entries {
		rc, err := e.Open()
		if err != nil {
			return err
		}
		n, err := io.Copy(io.Discard, rc)
		rc.Close()
		if err != nil {
			return err
		}
		total += n
	}
	st, _ := os.Stat(archive)
	psize := int64(0)
	if st != nil {
		psize = st.Size()
	}
	fmt.Print(banner)
	fmt.Println("Scanning the drive for archives:")
	fmt.Printf("1 file, %d bytes (%s)\n\n", psize, kib(psize))
	fmt.Println("Testing archive:", archive)
	fmt.Println("--")
	fmt.Println("Path =", archive)
	fmt.Println("Type =", typ)
	fmt.Println("Physical Size =", psize)
	fmt.Println("\nEverything is Ok\n")
	fmt.Printf("Files: %d\n", len(entries))
	fmt.Printf("Size:       %d\n", total)
	fmt.Printf("Compressed: %d\n", psize)
	return nil
}

func extractCommand(opt options, flatten bool) error {
	if len(opt.args) < 1 {
		return errors.New("missing archive name")
	}
	archive := opt.args[0]
	entries, typ, err := readArchive(archive, opt.typ)
	if err != nil {
		return err
	}
	outDir := opt.outDir
	if outDir == "" {
		outDir = "."
	}
	var total int64
	for _, e := range entries {
		if e.IsDir {
			continue
		}
		rc, err := e.Open()
		if err != nil {
			return err
		}
		if opt.stdout {
			n, err := io.Copy(os.Stdout, rc)
			rc.Close()
			total += n
			if err != nil {
				return err
			}
			continue
		}
		name := e.Name
		if flatten {
			name = filepath.Base(name)
		}
		target := filepath.Join(outDir, filepath.FromSlash(name))
		if err := safePath(outDir, target); err != nil {
			rc.Close()
			return err
		}
		if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
			rc.Close()
			return err
		}
		w, err := os.OpenFile(target, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0644)
		if err != nil {
			rc.Close()
			return err
		}
		n, err := io.Copy(w, rc)
		cerr := rc.Close()
		werr := w.Close()
		if err != nil {
			return err
		}
		if cerr != nil {
			return cerr
		}
		if werr != nil {
			return werr
		}
		if !e.ModTime.IsZero() {
			_ = os.Chtimes(target, e.ModTime, e.ModTime)
		}
		total += n
	}
	if !opt.stdout {
		fmt.Print(banner)
		fmt.Println("Scanning the drive for archives:")
		if st, _ := os.Stat(archive); st != nil {
			fmt.Printf("1 file, %d bytes (%s)\n\n", st.Size(), kib(st.Size()))
		}
		fmt.Println("Extracting archive:", archive)
		fmt.Println("--")
		fmt.Println("Path =", archive)
		fmt.Println("Type =", typ)
		fmt.Println("\nEverything is Ok\n")
		fmt.Printf("Files: %d\nSize:       %d\n", len(entries), total)
	}
	return nil
}

func safePath(root, target string) error {
	absRoot, _ := filepath.Abs(root)
	absTarget, _ := filepath.Abs(target)
	if absTarget != absRoot && !strings.HasPrefix(absTarget, absRoot+string(os.PathSeparator)) {
		return fmt.Errorf("unsafe archive path: %s", target)
	}
	return nil
}

func readArchive(path, forced string) ([]entry, string, error) {
	typ := archiveType(path, forced)
	switch typ {
	case "zip", "7z":
		es, err := readZip(path)
		return es, "zip", err
	case "tar":
		es, err := readTarFile(path, nil)
		return es, "tar", err
	case "tgz":
		f, err := os.Open(path)
		if err != nil {
			return nil, typ, err
		}
		defer f.Close()
		gz, err := gzip.NewReader(f)
		if err != nil {
			return nil, typ, err
		}
		defer gz.Close()
		es, err := readTarStream(gz)
		return es, "gzip", err
	case "gzip", "gz":
		es, err := readGzip(path)
		return es, "gzip", err
	case "bzip2", "bz2":
		es, err := readBzip2(path)
		return es, "bzip2", err
	case "xz":
		es, err := readExternalCompressed(path, "xz")
		return es, "xz", err
	default:
		return nil, typ, fmt.Errorf("unsupported archive type: %s", typ)
	}
}

func readZip(path string) ([]entry, error) {
	zr, err := zip.OpenReader(path)
	if err != nil {
		return nil, err
	}
	defer zr.Close()
	var out []entry
	for _, f := range zr.File {
		rc, err := f.Open()
		if err != nil {
			return nil, err
		}
		data, err := io.ReadAll(rc)
		cerr := rc.Close()
		if err != nil {
			return nil, err
		}
		if cerr != nil {
			return nil, cerr
		}
		name := f.Name
		modTime := f.Modified
		mode := f.Mode()
		isDir := f.FileInfo().IsDir()
		comp := int64(f.CompressedSize64)
		out = append(out, entry{
			Name:       name,
			Size:       int64(len(data)),
			Compressed: comp,
			Mode:       mode,
			ModTime:    modTime,
			IsDir:      isDir,
			Open: func() (io.ReadCloser, error) {
				return io.NopCloser(bytes.NewReader(data)), nil
			},
		})
	}
	return out, nil
}

func readTarFile(path string, r io.Reader) ([]entry, error) {
	if r != nil {
		return readTarStream(r)
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return readTarStream(f)
}

func readTarStream(r io.Reader) ([]entry, error) {
	tr := tar.NewReader(r)
	type mem struct {
		h    *tar.Header
		data []byte
	}
	var all []mem
	for {
		h, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		var data []byte
		if h.Typeflag == tar.TypeReg || h.Typeflag == tar.TypeRegA {
			data, err = io.ReadAll(tr)
			if err != nil {
				return nil, err
			}
		}
		hh := *h
		all = append(all, mem{h: &hh, data: data})
	}
	var out []entry
	for _, m := range all {
		mm := m
		out = append(out, entry{
			Name:       mm.h.Name,
			Size:       mm.h.Size,
			Compressed: ((mm.h.Size + 511) / 512) * 512,
			Mode:       fs.FileMode(mm.h.Mode),
			ModTime:    mm.h.ModTime,
			IsDir:      mm.h.Typeflag == tar.TypeDir,
			Open: func() (io.ReadCloser, error) {
				return io.NopCloser(bytes.NewReader(mm.data)), nil
			},
		})
	}
	return out, nil
}

func readGzip(path string) ([]entry, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	gz, err := gzip.NewReader(f)
	if err != nil {
		f.Close()
		return nil, err
	}
	data, err := io.ReadAll(gz)
	gz.Close()
	f.Close()
	if err != nil {
		return nil, err
	}
	name := gz.Name
	if name == "" {
		name = strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	}
	st, _ := os.Stat(path)
	comp := int64(len(data))
	if st != nil {
		comp = st.Size()
	}
	mt := gz.ModTime
	if mt.IsZero() && st != nil {
		mt = st.ModTime()
	}
	return []entry{{
		Name: name, Size: int64(len(data)), Compressed: comp, ModTime: mt,
		Open: func() (io.ReadCloser, error) { return io.NopCloser(bytes.NewReader(data)), nil },
	}}, nil
}

func readBzip2(path string) ([]entry, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	data, err := io.ReadAll(bzip2.NewReader(f))
	f.Close()
	if err != nil {
		return nil, err
	}
	name := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	st, _ := os.Stat(path)
	comp := int64(len(data))
	mt := time.Now()
	if st != nil {
		comp = st.Size()
		mt = st.ModTime()
	}
	return []entry{{
		Name: name, Size: int64(len(data)), Compressed: comp, ModTime: mt,
		Open: func() (io.ReadCloser, error) { return io.NopCloser(bytes.NewReader(data)), nil },
	}}, nil
}

func readExternalCompressed(path, tool string) ([]entry, error) {
	cmd := exec.Command(tool, "-dc", path)
	data, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	name := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	st, _ := os.Stat(path)
	comp := int64(len(data))
	mt := time.Now()
	if st != nil {
		comp = st.Size()
		mt = st.ModTime()
	}
	return []entry{{
		Name: name, Size: int64(len(data)), Compressed: comp, ModTime: mt,
		Open: func() (io.ReadCloser, error) { return io.NopCloser(bytes.NewReader(data)), nil },
	}}, nil
}

func hashCommand(opt options) error {
	files, err := expandInputs(opt.args, opt.recurse)
	if err != nil {
		return err
	}
	hname := strings.ToUpper(opt.hashName)
	if hname == "*" {
		hname = "CRC32"
	}
	fmt.Print(banner)
	fmt.Println("Scanning")
	var total int64
	for _, p := range files {
		if st, err := os.Stat(p); err == nil {
			total += st.Size()
		}
	}
	fmt.Printf("%d files, %d bytes (%s)\n\n", len(files), total, kib(total))
	fmt.Printf("%-8s %13s  %s\n", hname, "Size", "Name")
	fmt.Println("-------- -------------  ------------")
	for _, p := range files {
		sum, size, err := hashFile(p, hname)
		if err != nil {
			return err
		}
		fmt.Printf("%-8s %13d  %s\n", sum, size, p)
	}
	fmt.Println("-------- -------------  ------------")
	fmt.Printf("%23d  \n\n", total)
	fmt.Printf("Files: %d\nSize: %d\n\n", len(files), total)
	fmt.Println("Everything is Ok")
	return nil
}

func hashFile(path, hname string) (string, int64, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", 0, err
	}
	defer f.Close()
	var h hash.Hash
	switch hname {
	case "SHA1":
		h = sha1.New()
	case "SHA256", "SHA2":
		h = sha256.New()
	case "MD5":
		h = md5.New()
	case "CRC32", "":
		crc := crc32.NewIEEE()
		n, err := io.Copy(crc, f)
		if err != nil {
			return "", n, err
		}
		return fmt.Sprintf("%08X", crc.Sum32()), n, nil
	default:
		return "", 0, fmt.Errorf("unsupported hash: %s", hname)
	}
	n, err := io.Copy(h, f)
	if err != nil {
		return "", n, err
	}
	return strings.ToUpper(hex.EncodeToString(h.Sum(nil))), n, nil
}

func deleteCommand(opt options) error {
	if len(opt.args) < 2 {
		return errors.New("delete requires archive and file names")
	}
	archive := opt.args[0]
	if archiveType(archive, opt.typ) != "zip" {
		return errors.New("delete is implemented for zip archives only")
	}
	zr, err := zip.OpenReader(archive)
	if err != nil {
		return err
	}
	defer zr.Close()
	del := map[string]bool{}
	for _, n := range opt.args[1:] {
		del[filepath.ToSlash(n)] = true
	}
	tmp := archive + ".tmp"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	zw := zip.NewWriter(f)
	for _, zf := range zr.File {
		if del[zf.Name] {
			continue
		}
		if err := copyZipMember(zw, zf, zf.Name); err != nil {
			zw.Close()
			f.Close()
			return err
		}
	}
	if err := zw.Close(); err != nil {
		f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	fmt.Print(banner)
	if err := os.Rename(tmp, archive); err != nil {
		return err
	}
	fmt.Println("Everything is Ok")
	return nil
}

func renameCommand(opt options) error {
	if len(opt.args) < 3 || len(opt.args[1:])%2 != 0 {
		return errors.New("rename requires archive and old/new name pairs")
	}
	archive := opt.args[0]
	if archiveType(archive, opt.typ) != "zip" {
		return errors.New("rename is implemented for zip archives only")
	}
	ren := map[string]string{}
	for i := 1; i < len(opt.args); i += 2 {
		ren[filepath.ToSlash(opt.args[i])] = filepath.ToSlash(opt.args[i+1])
	}
	zr, err := zip.OpenReader(archive)
	if err != nil {
		return err
	}
	defer zr.Close()
	tmp := archive + ".tmp"
	f, err := os.Create(tmp)
	if err != nil {
		return err
	}
	zw := zip.NewWriter(f)
	for _, zf := range zr.File {
		name := zf.Name
		if nn, ok := ren[name]; ok {
			name = nn
		}
		if err := copyZipMember(zw, zf, name); err != nil {
			zw.Close()
			f.Close()
			return err
		}
	}
	if err := zw.Close(); err != nil {
		f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	fmt.Print(banner)
	if err := os.Rename(tmp, archive); err != nil {
		return err
	}
	fmt.Println("Everything is Ok")
	return nil
}

func copyZipMember(zw *zip.Writer, zf *zip.File, name string) error {
	h := zf.FileHeader
	h.Name = name
	w, err := zw.CreateHeader(&h)
	if err != nil {
		return err
	}
	rc, err := zf.Open()
	if err != nil {
		return err
	}
	defer rc.Close()
	_, err = io.Copy(w, rc)
	return err
}

func attr(e entry) string {
	if e.IsDir {
		return "D...."
	}
	return "....."
}

func kib(n int64) string {
	if n <= 0 {
		return "0 KiB"
	}
	k := (n + 1023) / 1024
	return strconv.FormatInt(k, 10) + " KiB"
}
