package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io/fs"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const version = "oranda 0.6.5"

type globalOpts struct {
	verbose bool
	format  string
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	g, rest, ok := parseGlobal(args)
	if !ok {
		return 2
	}
	if len(rest) == 0 {
		fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <COMMAND>\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n")
		return 2
	}
	switch rest[0] {
	case "-h":
		fmt.Print(rootHelpShort())
		return 0
	case "--help":
		fmt.Print(rootHelpLong())
		return 0
	case "-V", "--version":
		fmt.Println(version)
		return 0
	case "help":
		return helpCmd(rest[1:])
	case "build":
		return buildCmd(g, rest[1:])
	case "serve":
		return serveCmd(rest[1:])
	case "dev":
		return devCmd(rest[1:])
	case "generate":
		return generateCmd(rest[1:])
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n", rest[0])
		return 2
	}
}

func parseGlobal(args []string) (globalOpts, []string, bool) {
	g := globalOpts{format: "human"}
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-v" || a == "--verbose" {
			g.verbose = true
			continue
		}
		if a == "--output-format" {
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--output-format <OUTPUT_FORMAT>' but none was supplied\n\nFor more information, try '--help'.\n")
				return g, nil, false
			}
			i++
			if args[i] != "human" && args[i] != "json" {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n\nFor more information, try '--help'.\n", args[i])
				return g, nil, false
			}
			g.format = args[i]
			continue
		}
		if strings.HasPrefix(a, "--output-format=") {
			v := strings.TrimPrefix(a, "--output-format=")
			if v != "human" && v != "json" {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n\nFor more information, try '--help'.\n", v)
				return g, nil, false
			}
			g.format = v
			continue
		}
		rest = append(rest, args[i:]...)
		break
	}
	return g, rest, true
}

func helpCmd(args []string) int {
	if len(args) == 0 {
		fmt.Print(rootHelpLong())
		return 0
	}
	switch args[0] {
	case "build":
		fmt.Print(buildHelp())
	case "dev":
		fmt.Print(devHelp())
	case "serve":
		fmt.Print(serveHelp())
	case "generate":
		if len(args) > 1 && args[1] == "ci" {
			fmt.Print(generateCIHelp())
		} else {
			fmt.Print(generateHelp())
		}
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable help [COMMAND]...\n\nFor more information, try '--help'.\n", args[0])
		return 2
	}
	return 0
}

func buildCmd(g globalOpts, args []string) int {
	jsonOnly := false
	for _, a := range args {
		switch a {
		case "-h":
			fmt.Print(buildHelpShort())
			return 0
		case "--help":
			fmt.Print(buildHelp())
			return 0
		case "--json-only":
			jsonOnly = true
		default:
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable build [OPTIONS]\n\nFor more information, try '--help'.\n", a)
			return 2
		}
	}
	if err := validateConfig(); err != nil {
		fmt.Fprintf(os.Stderr, "  × %s\n", err.Error())
		return 255
	}
	if err := os.MkdirAll("public", 0755); err != nil {
		fmt.Fprintf(os.Stderr, "  × %v\n", err)
		return 255
	}
	if !jsonOnly {
		title, body := readReadme()
		page := renderPage(title, body)
		_ = os.WriteFile(filepath.Join("public", "index.html"), []byte(page), 0644)
		_ = os.WriteFile(filepath.Join("public", "oranda.css"), []byte(defaultCSS), 0644)
	}
	success("Your site build is located in `public`.")
	return 0
}

func validateConfig() error {
	data, err := os.ReadFile("oranda.json")
	if errors.Is(err, fs.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	var v any
	if err := json.Unmarshal(data, &v); err != nil {
		return fmt.Errorf("failed to parse JSON\n  ╰─▶ %s", err.Error())
	}
	return nil
}

func readReadme() (string, string) {
	data, err := os.ReadFile("README.md")
	if err != nil {
		return "oranda site", ""
	}
	lines := strings.Split(string(data), "\n")
	title := "oranda site"
	var out []string
	for _, line := range lines {
		if strings.HasPrefix(line, "# ") && title == "oranda site" {
			title = strings.TrimSpace(strings.TrimPrefix(line, "# "))
			continue
		}
		out = append(out, markdownLine(line))
	}
	return title, strings.Join(out, "\n")
}

func markdownLine(line string) string {
	t := strings.TrimSpace(line)
	if t == "" {
		return ""
	}
	if strings.HasPrefix(t, "## ") {
		return "<h2>" + html.EscapeString(strings.TrimSpace(strings.TrimPrefix(t, "## "))) + "</h2>"
	}
	if strings.HasPrefix(t, "### ") {
		return "<h3>" + html.EscapeString(strings.TrimSpace(strings.TrimPrefix(t, "### "))) + "</h3>"
	}
	return "<p>" + html.EscapeString(t) + "</p>"
}

func renderPage(title, body string) string {
	et := html.EscapeString(title)
	return "<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>" + et + "</title>\n<link rel=\"stylesheet\" href=\"oranda.css\">\n</head>\n<body>\n<main>\n<h1>" + et + "</h1>\n" + body + "\n</main>\n</body>\n</html>\n"
}

const defaultCSS = `body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;line-height:1.55;margin:0;background:#f8fafc;color:#111827}main{max-width:860px;margin:4rem auto;padding:0 1.25rem}h1{font-size:clamp(2rem,6vw,4rem);margin:0 0 1rem}h2{margin-top:2rem}p{font-size:1.05rem}`

func serveCmd(args []string) int {
	port := "7979"
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h":
			fmt.Print(serveHelpShort())
			return 0
		case "--help":
			fmt.Print(serveHelp())
			return 0
		case "--port":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--port <PORT>' but none was supplied\n\nFor more information, try '--help'.\n")
				return 2
			}
			i++
			port = args[i]
		default:
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable serve [OPTIONS]\n\nFor more information, try '--help'.\n", args[i])
			return 2
		}
	}
	if _, err := os.Stat("public"); err != nil {
		fmt.Fprint(os.Stderr, "  × Could not find a build in public\n  help: Did you remember to run `oranda build`?\n")
		return 255
	}
	success("Your project is available at: http://127.0.0.1:" + port)
	if err := http.ListenAndServe("127.0.0.1:"+port, http.FileServer(http.Dir("public"))); err != nil {
		fmt.Fprintf(os.Stderr, "  × %v\n", err)
		return 255
	}
	return 0
}

func devCmd(args []string) int {
	port := "7979"
	firstBuild := true
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h":
			fmt.Print(devHelpShort())
			return 0
		case "--help":
			fmt.Print(devHelp())
			return 0
		case "--no-first-build":
			firstBuild = false
		case "--port":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--port <PORT>' but none was supplied\n\nFor more information, try '--help'.\n")
				return 2
			}
			i++
			port = args[i]
		case "-i", "--include-paths":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--include-paths <INCLUDE_PATHS>' but none was supplied\n\nFor more information, try '--help'.\n")
				return 2
			}
			i++
		default:
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable dev [OPTIONS]\n\nFor more information, try '--help'.\n", args[i])
			return 2
		}
	}
	if firstBuild {
		if code := buildCmd(globalOpts{format: "human"}, nil); code != 0 {
			return code
		}
	}
	info("Found 0 paths to watch, starting watch...")
	success("Your project is available at: http://127.0.0.1:" + port)
	if _, err := os.Stat("public"); err != nil {
		fmt.Fprint(os.Stderr, "  × Could not find a build in public\n  help: Did you remember to run `oranda build`?\n")
		return 255
	}
	if err := http.ListenAndServe("127.0.0.1:"+port, http.FileServer(http.Dir("public"))); err != nil {
		fmt.Fprintf(os.Stderr, "  × %v\n", err)
		return 255
	}
	return 0
}

func generateCmd(args []string) int {
	if len(args) == 0 {
		fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <COMMAND>\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n")
		return 2
	}
	var pre []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h":
			fmt.Print(generateHelpShort())
			return 0
		case "--help":
			fmt.Print(generateHelp())
			return 0
		case "-o", "--output-path", "-s", "--site-path":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <%s>' but none was supplied\n\nFor more information, try '--help'.\n", args[i], optionName(args[i]))
				return 2
			}
			pre = append(pre, args[i], args[i+1])
			i++
		case "ci":
			return generateCICmd(append(pre, args[i+1:]...))
		default:
			fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n", args[i])
			return 2
		}
	}
	fmt.Fprint(os.Stderr, "error: the following required arguments were not provided:\n  <COMMAND>\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n")
	return 2
}

func optionName(opt string) string {
	switch opt {
	case "-o", "--output-path":
		return "OUTPUT_PATH"
	case "-s", "--site-path":
		return "SITE_PATH"
	}
	return "VALUE"
}

func generateCICmd(args []string) int {
	output := filepath.Join(".github", "workflows", "web.yml")
	site := "."
	ci := "github"
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h":
			fmt.Print(generateCIHelpShort())
			return 0
		case "--help":
			fmt.Print(generateCIHelp())
			return 0
		case "-o", "--output-path":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--output-path <OUTPUT_PATH>' but none was supplied\n\nFor more information, try '--help'.\n")
				return 2
			}
			i++
			output = args[i]
		case "-s", "--site-path":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--site-path <SITE_PATH>' but none was supplied\n\nFor more information, try '--help'.\n")
				return 2
			}
			i++
			site = args[i]
		case "--ci":
			if i+1 >= len(args) {
				fmt.Fprint(os.Stderr, "error: a value is required for '--ci <CI>' but none was supplied\n\nFor more information, try '--help'.\n")
				return 2
			}
			i++
			ci = args[i]
		default:
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable generate ci [OPTIONS]\n\nFor more information, try '--help'.\n", args[i])
			return 2
		}
	}
	if ci != "github" {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--ci <CI>'\n  [possible values: github]\n\nFor more information, try '--help'.\n", ci)
		return 2
	}
	info("Generating a CI deploy workflow for your site...")
	if err := os.MkdirAll(filepath.Dir(output), 0755); err != nil && filepath.Dir(output) != "." {
		fmt.Fprintf(os.Stderr, "  × %v\n", err)
		return 255
	}
	if err := os.WriteFile(output, []byte(ciWorkflow(site)), 0644); err != nil {
		fmt.Fprintf(os.Stderr, "  × %v\n", err)
		return 255
	}
	success("Generated GitHub Actions workflow at `" + output + "`.")
	return 0
}

func ciWorkflow(site string) string {
	return `name: Web

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: axodotdev/oranda-action@v1
        with:
          path: ` + site + `
`
}

func info(s string)    { fmt.Println("↪ >o_o< INFO: " + s) }
func success(s string) { fmt.Println("✓ >o_o< SUCCESS: " + s) }

func rootHelpShort() string {
	return "🎁 generate beautiful landing pages for your projects\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  build     Build an oranda site\n  dev       Start a local development server that recompiles your oranda site if a file changes\n  serve     Start a file server to access your oranda site in a browser\n  generate  Generate infrastructure files for oranda sites\n  help      Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help (see more with '--help')\n  -V, --version  Print version\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n                                       human, json]\n"
}

func rootHelpLong() string {
	return "🎁 generate beautiful landing pages for your projects\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  build     Build an oranda site\n  dev       Start a local development server that recompiles your oranda site if a file changes\n  serve     Start a file server to access your oranda site in a browser\n  generate  Generate infrastructure files for oranda sites\n  help      Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n"
}

func buildHelpShort() string {
	return "Build an oranda site\n\nUsage: executable build [OPTIONS]\n\nOptions:\n      --json-only  Only build the artifacts JSON file (if applicable) and other files that may be used to support it, such as installer source files\n  -h, --help       Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values: human, json]\n"
}

func buildHelp() string {
	return "Build an oranda site\n\nUsage: executable build [OPTIONS]\n\nOptions:\n      --json-only\n          Only build the artifacts JSON file (if applicable) and other files that may be used to\n          support it, such as installer source files\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n"
}

func devHelpShort() string {
	return "Start a local development server that recompiles your oranda site if a file changes\n\nUsage: executable dev [OPTIONS]\n\nOptions:\n      --port <PORT>                    The port for the file server to be launched on\n      --no-first-build                 Skip the first build before starting to watch for changes\n  -i, --include-paths <INCLUDE_PATHS>  List of extra paths to watch\n  -h, --help                           Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values: human, json]\n"
}

func devHelp() string {
	return "Start a local development server that recompiles your oranda site if a file changes\n\nUsage: executable dev [OPTIONS]\n\nOptions:\n      --port <PORT>\n          The port for the file server to be launched on\n\n      --no-first-build\n          Skip the first build before starting to watch for changes\n\n  -i, --include-paths <INCLUDE_PATHS>\n          List of extra paths to watch\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n"
}

func serveHelpShort() string {
	return "Start a file server to access your oranda site in a browser\n\nUsage: executable serve [OPTIONS]\n\nOptions:\n      --port <PORT>  [default: 7979]\n  -h, --help         Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values: human, json]\n"
}

func serveHelp() string {
	return "Start a file server to access your oranda site in a browser\n\nUsage: executable serve [OPTIONS]\n\nOptions:\n      --port <PORT>\n          [default: 7979]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n"
}

func generateHelpShort() string {
	return "Generate infrastructure files for oranda sites\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nCommands:\n  ci    Generates a CI file that can be used to deploy your site\n  help  Print this message or the help of the given subcommand(s)\n\nOptions:\n  -o, --output-path <OUTPUT_PATH>      Path to the output file\n  -s, --site-path <SITE_PATH>          Path to your oranda site\n  -h, --help                           Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values: human, json]\n"
}

func generateHelp() string {
	return "Generate infrastructure files for oranda sites\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nCommands:\n  ci    Generates a CI file that can be used to deploy your site\n  help  Print this message or the help of the given subcommand(s)\n\nOptions:\n  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n"
}

func generateCIHelpShort() string {
	return "Generates a CI file that can be used to deploy your site\n\nUsage: executable generate ci [OPTIONS]\n\nOptions:\n      --ci <CI>                        What CI to generate a file for [default: github] [possible values: github]\n  -o, --output-path <OUTPUT_PATH>      Path to the output file\n  -s, --site-path <SITE_PATH>          Path to your oranda site\n  -h, --help                           Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values: human, json]\n"
}

func generateCIHelp() string {
	return "Generates a CI file that can be used to deploy your site\n\nUsage: executable generate ci [OPTIONS]\n\nOptions:\n      --ci <CI>\n          What CI to generate a file for\n          \n          [default: github]\n\n          Possible values:\n          - github: Deploy to GitHub Pages using GitHub Actions\n\n  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n"
}

// Keep otherwise-unused imports/functions alive when compilers get stricter.
var _ = strconv.Itoa
var _ = time.Now
