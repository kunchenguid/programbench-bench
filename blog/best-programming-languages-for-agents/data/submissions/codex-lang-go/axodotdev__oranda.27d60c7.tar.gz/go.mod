module oranda-reimpl

go 1.21
