module eva-clone

go 1.21
