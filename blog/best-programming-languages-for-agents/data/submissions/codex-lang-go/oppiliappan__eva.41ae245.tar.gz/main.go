package main

import (
	"bufio"
	"errors"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
	"unicode"
)

type options struct {
	fix   int
	base  int
	angle string
	input *string
}

func main() {
	opt, code, handled := parseArgs(os.Args[1:])
	if handled {
		os.Exit(code)
	}
	last := 0.0
	if opt.input != nil {
		if strings.TrimSpace(*opt.input) == "" {
			fmt.Println("No previous history.")
			return
		}
		runOne(*opt.input, opt, &last)
		return
	}
	fmt.Println("No previous history.")
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		line := sc.Text()
		if strings.TrimSpace(line) == "" {
			continue
		}
		runOne(line, opt, &last)
	}
}

func parseArgs(args []string) (options, int, bool) {
	opt := options{fix: 10, base: 10, angle: "degree"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printHelp()
			return opt, 0, true
		case "-V", "--version":
			fmt.Println("eva 0.3.1")
			return opt, 0, true
		case "-f", "--fix":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <FIX>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return opt, 2, true
			}
			i++
			n, err := strconv.Atoi(args[i])
			if err != nil || n < 1 || n > 64 {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--fix <FIX>': %s is not in 1..=64\n\nFor more information, try '--help'.\n", args[i], args[i])
				return opt, 2, true
			}
			opt.fix = n
		case "-b", "--base":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <RADIX>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return opt, 2, true
			}
			i++
			n, err := strconv.Atoi(args[i])
			if err != nil || n < 1 || n > 36 {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--base <RADIX>': %s is not in 1..=36\n\nFor more information, try '--help'.\n", args[i], args[i])
				return opt, 2, true
			}
			opt.base = n
		case "-a", "--angle_unit":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <angle_unit>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return opt, 2, true
			}
			i++
			v := args[i]
			if v != "degree" && v != "radian" && v != "gradian" {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--angle_unit <angle_unit>'\n  [possible values: degree, radian, gradian]\n\nFor more information, try '--help'.\n", v)
				return opt, 2, true
			}
			opt.angle = v
		case "--":
			if i+1 < len(args) {
				s := strings.Join(args[i+1:], " ")
				opt.input = &s
			}
			return opt, 0, false
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.\n", a, a, a)
				return opt, 2, true
			}
			s := strings.Join(args[i:], " ")
			opt.input = &s
			return opt, 0, false
		}
	}
	return opt, 0, false
}

func printHelp() {
	fmt.Println(`Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version`)
}

func runOne(s string, opt options, last *float64) {
	p := newParser(s, opt, *last)
	v, err := p.parse()
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		if opt.input != nil {
			os.Exit(1)
		}
		return
	}
	*last = v
	fmt.Println(formatValue(v, opt))
}

type tokenType int

const (
	tEOF tokenType = iota
	tNum
	tIdent
	tOp
	tLParen
	tRParen
	tComma
)

type token struct {
	typ tokenType
	val string
	num float64
}

type lexer struct {
	s   []rune
	pos int
}

func (l *lexer) next() (token, error) {
	for l.pos < len(l.s) && unicode.IsSpace(l.s[l.pos]) {
		l.pos++
	}
	if l.pos >= len(l.s) {
		return token{typ: tEOF}, nil
	}
	ch := l.s[l.pos]
	if unicode.IsDigit(ch) || ch == '.' {
		start := l.pos
		dots := 0
		for l.pos < len(l.s) && (unicode.IsDigit(l.s[l.pos]) || l.s[l.pos] == '.') {
			if l.s[l.pos] == '.' {
				dots++
			}
			l.pos++
		}
		txt := string(l.s[start:l.pos])
		if dots > 1 || txt == "." {
			return token{}, fmt.Errorf("Syntax Error: Unexpected character '%s'", txt)
		}
		n, _ := strconv.ParseFloat(txt, 64)
		return token{typ: tNum, val: txt, num: n}, nil
	}
	if unicode.IsLetter(ch) || ch == '_' {
		start := l.pos
		for l.pos < len(l.s) && (unicode.IsLetter(l.s[l.pos]) || l.s[l.pos] == '_') {
			l.pos++
		}
		return token{typ: tIdent, val: string(l.s[start:l.pos])}, nil
	}
	l.pos++
	switch ch {
	case '(':
		return token{typ: tLParen, val: "("}, nil
	case ')':
		return token{typ: tRParen, val: ")"}, nil
	case ',':
		return token{typ: tComma, val: ","}, nil
	case '+', '-', '*', '/', '^':
		if ch == '*' && l.pos < len(l.s) && l.s[l.pos] == '*' {
			l.pos++
			return token{typ: tOp, val: "^"}, nil
		}
		return token{typ: tOp, val: string(ch)}, nil
	default:
		return token{}, fmt.Errorf("Syntax Error: Unexpected character '%c'", ch)
	}
}

type parser struct {
	l     lexer
	cur   token
	opt   options
	last  float64
	err   error
	funcs map[string]int
}

func newParser(s string, opt options, last float64) *parser {
	p := &parser{l: lexer{s: []rune(s)}, opt: opt, last: last, funcs: map[string]int{
		"sin": 1, "cos": 1, "tan": 1, "csc": 1, "sec": 1, "cot": 1, "sinh": 1, "cosh": 1, "tanh": 1,
		"asin": 1, "acos": 1, "atan": 1, "acsc": 1, "asec": 1, "acot": 1, "ln": 1, "log2": 1,
		"log10": 1, "sqrt": 1, "ceil": 1, "floor": 1, "abs": 1, "log": 2, "nroot": 2,
	}}
	p.advance()
	return p
}

func (p *parser) advance() {
	if p.err != nil {
		return
	}
	t, err := p.l.next()
	if err != nil {
		p.err = err
		return
	}
	p.cur = t
}

func (p *parser) parse() (float64, error) {
	if strings.TrimSpace(string(p.l.s)) == "" {
		return 0, nil
	}
	v := p.expr(0)
	if p.err != nil {
		return 0, p.err
	}
	if p.cur.typ == tComma {
		return 0, errors.New("Syntax Error: Mismatched parentheses!")
	}
	if p.cur.typ != tEOF && p.cur.typ != tRParen {
		return 0, errors.New("Parser Error: Too many operators, too few operands")
	}
	return v, nil
}

func (p *parser) expr(min int) float64 {
	left := p.prefix()
	for p.err == nil {
		if p.shouldMul() {
			op := "*"
			prec, _ := precedence(op)
			if prec < min {
				break
			}
			rhs := p.expr(prec + 1)
			left = p.applyOp(op, left, rhs)
			continue
		}
		if p.cur.typ != tOp {
			break
		}
		op := p.cur.val
		prec, rightAssoc := precedence(op)
		if prec < min {
			break
		}
		p.advance()
		nextMin := prec + 1
		if rightAssoc {
			nextMin = prec
		}
		rhs := p.expr(nextMin)
		left = p.applyOp(op, left, rhs)
	}
	return left
}

func precedence(op string) (int, bool) {
	switch op {
	case "+", "-":
		return 1, false
	case "*", "/":
		return 2, false
	case "^":
		return 4, true
	}
	return -1, false
}

func (p *parser) shouldMul() bool {
	return p.cur.typ == tNum || p.cur.typ == tIdent || p.cur.typ == tLParen
}

func (p *parser) prefix() float64 {
	if p.err != nil {
		return 0
	}
	switch p.cur.typ {
	case tNum:
		v := p.cur.num
		p.advance()
		return v
	case tOp:
		op := p.cur.val
		if op == "+" || op == "-" {
			p.advance()
			v := p.expr(3)
			if op == "-" {
				return -v
			}
			return v
		}
		p.err = errors.New("Parser Error: Too many operators, too few operands")
		return 0
	case tLParen:
		p.advance()
		v := p.expr(0)
		if p.cur.typ == tRParen {
			p.advance()
		}
		return v
	case tIdent:
		name := p.cur.val
		p.advance()
		if name == "_" {
			return p.last
		}
		if name == "pi" {
			return math.Pi
		}
		if name == "e" {
			return math.E
		}
		if _, ok := p.funcs[name]; ok {
			if p.cur.typ != tLParen {
				p.err = fmt.Errorf("Syntax Error: Function '%s' expected parentheses", name)
				return 0
			}
			return p.call(name)
		}
		p.err = errors.New("Parser Error: Too many operators, too few operands")
		return 0
	case tEOF, tRParen:
		p.err = errors.New("Parser Error: Too many operators, too few operands")
		return 0
	default:
		p.err = errors.New("Parser Error: Too many operators, too few operands")
		return 0
	}
}

func (p *parser) call(name string) float64 {
	need := p.funcs[name]
	p.advance()
	var args []float64
	if p.cur.typ != tRParen && p.cur.typ != tEOF {
		args = append(args, p.expr(0))
		for p.err == nil && p.cur.typ == tComma {
			p.advance()
			args = append(args, p.expr(0))
		}
	}
	if p.cur.typ == tRParen {
		p.advance()
	}
	if p.err != nil {
		return 0
	}
	if len(args) < need {
		p.err = fmt.Errorf("Parser Error: To few arguments for function, need %d", need)
		return 0
	}
	if len(args) > need {
		p.err = errors.New("Parser Error: Too many operators, too few operands")
		return 0
	}
	return p.applyFunc(name, args)
}

func (p *parser) applyOp(op string, a, b float64) float64 {
	switch op {
	case "+":
		return a + b
	case "-":
		return a - b
	case "*":
		return a * b
	case "/":
		if b == 0 {
			p.err = errors.New("Math Error: Divide by zero error!")
			return 0
		}
		return a / b
	case "^":
		v := math.Pow(a, b)
		if math.IsNaN(v) {
			p.err = errors.New("Domain Error: Out of bounds!")
		}
		return v
	}
	return 0
}

func (p *parser) rad(x float64) float64 {
	if p.opt.angle == "radian" {
		return x
	}
	return x * math.Pi / 180.0
}

func (p *parser) applyFunc(name string, a []float64) float64 {
	var v float64
	switch name {
	case "sin":
		v = math.Sin(p.rad(a[0]))
	case "cos":
		v = math.Cos(p.rad(a[0]))
	case "tan":
		v = math.Tan(p.rad(a[0]))
	case "csc":
		v = 1 / math.Sin(p.rad(a[0]))
	case "sec":
		v = 1 / math.Cos(p.rad(a[0]))
	case "cot":
		v = 1 / math.Tan(p.rad(a[0]))
	case "sinh":
		v = math.Sinh(a[0])
	case "cosh":
		v = math.Cosh(a[0])
	case "tanh":
		v = math.Tanh(a[0])
	case "asin":
		v = math.Asin(a[0])
	case "acos":
		v = math.Acos(a[0])
	case "atan":
		v = math.Atan(a[0])
	case "acsc":
		v = math.Asin(1 / a[0])
	case "asec":
		v = math.Acos(1 / a[0])
	case "acot":
		v = math.Atan(1 / a[0])
	case "ln":
		v = math.Log(a[0])
	case "log2":
		v = math.Log2(a[0])
	case "log10":
		v = math.Log10(a[0])
	case "sqrt":
		v = math.Sqrt(a[0])
	case "ceil":
		v = math.Ceil(a[0])
	case "floor":
		v = math.Floor(a[0])
	case "abs":
		v = math.Abs(a[0])
	case "log":
		v = math.Log(a[0]) / math.Log(a[1])
	case "nroot":
		v = math.Pow(a[0], 1/a[1])
	}
	if math.IsNaN(v) {
		p.err = errors.New("Domain Error: Out of bounds!")
		return 0
	}
	return v
}

func formatValue(v float64, opt options) string {
	if opt.base == 10 {
		s := fmt.Sprintf("%.*f", opt.fix, v)
		parts := strings.SplitN(s, ".", 2)
		parts[0] = groupDec(parts[0])
		if len(parts) == 2 {
			return parts[0] + "." + parts[1]
		}
		return parts[0]
	}
	return formatBase(v, opt.base, opt.fix)
}

func groupDec(s string) string {
	neg := ""
	if strings.HasPrefix(s, "-") {
		neg = "-"
		s = s[1:]
	}
	var out []byte
	for i, c := range s {
		if i > 0 && (len(s)-i)%3 == 0 {
			out = append(out, ',')
		}
		out = append(out, byte(c))
	}
	return neg + string(out)
}

func formatBase(v float64, base, fix int) string {
	if base < 2 {
		base = 10
	}
	sign := ""
	if v < 0 {
		sign = "-"
		v = -v
	}
	intPart := math.Floor(v)
	frac := v - intPart
	intStr := strconv.FormatInt(int64(intPart+1e-9), base)
	intStr = strings.ToUpper(intStr)
	if sign != "" {
		intStr = sign + intStr
	}
	intStr = groupBase(intStr)
	fracStr := "0"
	if frac > 0 {
		var b strings.Builder
		for i := 0; i < fix && frac > 1e-14; i++ {
			frac *= float64(base)
			d := int(frac)
			if d < 0 {
				d = 0
			}
			if d > 35 {
				d = 35
			}
			b.WriteByte("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"[d])
			frac -= float64(d)
		}
		if b.Len() > 0 {
			fracStr = b.String()
		}
	}
	return padBase(intStr) + "." + fracStr
}

func groupBase(s string) string {
	var out []byte
	for i := range s {
		if i > 0 && (len(s)-i)%3 == 0 {
			out = append(out, ',')
		}
		out = append(out, s[i])
	}
	return string(out)
}

func padBase(s string) string {
	groups := strings.Split(s, ",")
	if len(groups) >= 4 {
		return s
	}
	pad := make([]string, 0, 4)
	for i := 0; i < 4-len(groups); i++ {
		pad = append(pad, " ")
	}
	pad = append(pad, groups...)
	for i := range pad {
		if len(pad[i]) < 3 {
			pad[i] = strings.Repeat(" ", 3-len(pad[i])) + pad[i]
		}
	}
	if strings.TrimSpace(pad[0]) == "" {
		pad[0] = " "
	}
	return strings.Join(pad, ",")
}
