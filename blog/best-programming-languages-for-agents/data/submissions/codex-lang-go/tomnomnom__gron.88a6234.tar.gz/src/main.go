package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const helpText = `Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0	OK
  1	Failed to open file
  2	Failed to read input
  3	Failed to form statements
  4	Failed to fetch URL
  5	Failed to parse statements
  6	Failed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron
`

type options struct {
	ungron   bool
	values   bool
	stream   bool
	jsonMode bool
	noSort   bool
	color    bool
	version  bool
}

type statement struct {
	Path  []any
	Value any
}

func main() {
	os.Exit(run())
}

func run() int {
	for _, arg := range os.Args[1:] {
		if arg == "-h" || arg == "--help" {
			fmt.Fprint(os.Stdout, helpText)
			return 0
		}
	}
	opts, args, err := parseFlags(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		fmt.Fprint(os.Stderr, helpText)
		return 2
	}
	if opts.version {
		fmt.Println("gron version dev")
		return 0
	}
	if len(args) > 1 {
		fmt.Fprint(os.Stderr, helpText)
		return 2
	}
	if opts.ungron {
		input, code := readInput(args)
		if code != 0 {
			return code
		}
		var root any
		if opts.jsonMode {
			root, err = ungronJSON(input)
		} else {
			root, err = ungronText(input)
		}
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 5
		}
		if err := encodePretty(os.Stdout, root); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 6
		}
		return 0
	}
	if opts.values {
		input, code := readInput(args)
		if code != 0 {
			return code
		}
		if err := printValues(os.Stdout, input); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 5
		}
		return 0
	}
	input, code := readInput(args)
	if code != 0 {
		return code
	}
	var data any
	if opts.stream {
		data, err = parseStream(input)
	} else {
		data, err = parseJSON(input)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "failed to form statements: %v\n", err)
		return 3
	}
	stmts := flatten(data, opts.noSort)
	if !opts.noSort {
		sortStatements(stmts)
	}
	for _, st := range stmts {
		if opts.jsonMode {
			b, err := json.Marshal([]any{st.Path, st.Value})
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				return 6
			}
			fmt.Println(string(b))
		} else {
			fmt.Printf("%s = %s;\n", formatPath(st.Path), formatValue(st.Value))
		}
	}
	return 0
}

func parseFlags(args []string) (options, []string, error) {
	var opts options
	fs := flag.NewFlagSet("gron", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.BoolVar(&opts.ungron, "u", false, "")
	fs.BoolVar(&opts.ungron, "ungron", false, "")
	fs.BoolVar(&opts.values, "v", false, "")
	fs.BoolVar(&opts.values, "values", false, "")
	fs.BoolVar(&opts.color, "c", false, "")
	fs.BoolVar(&opts.color, "colorize", false, "")
	fs.Bool("m", false, "")
	fs.Bool("monochrome", false, "")
	fs.BoolVar(&opts.stream, "s", false, "")
	fs.BoolVar(&opts.stream, "stream", false, "")
	fs.Bool("k", false, "")
	fs.Bool("insecure", false, "")
	fs.String("x", "", "")
	fs.String("proxy", "", "")
	fs.String("noproxy", "", "")
	fs.BoolVar(&opts.jsonMode, "j", false, "")
	fs.BoolVar(&opts.jsonMode, "json", false, "")
	fs.BoolVar(&opts.noSort, "no-sort", false, "")
	fs.BoolVar(&opts.version, "version", false, "")
	if err := fs.Parse(args); err != nil {
		return opts, nil, err
	}
	return opts, fs.Args(), nil
}

func readInput(args []string) ([]byte, int) {
	if len(args) == 0 || args[0] == "-" {
		b, err := io.ReadAll(os.Stdin)
		if err != nil {
			fmt.Fprintf(os.Stderr, "failed to read input: %v\n", err)
			return nil, 2
		}
		return b, 0
	}
	name := args[0]
	if strings.HasPrefix(name, "http://") || strings.HasPrefix(name, "https://") {
		resp, err := http.Get(name)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			return nil, 4
		}
		defer resp.Body.Close()
		b, err := io.ReadAll(resp.Body)
		if err != nil {
			fmt.Fprintf(os.Stderr, "failed to read input: %v\n", err)
			return nil, 2
		}
		return b, 0
	}
	b, err := os.ReadFile(name)
	if err != nil {
		fmt.Fprintf(os.Stderr, "open %s: %v\n", name, err)
		return nil, 1
	}
	return b, 0
}

func parseJSON(input []byte) (any, error) {
	dec := json.NewDecoder(bytes.NewReader(input))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	return v, nil
}

func parseStream(input []byte) (any, error) {
	sc := bufio.NewScanner(bytes.NewReader(input))
	out := []any{}
	for sc.Scan() {
		line := bytes.TrimSpace(sc.Bytes())
		if len(line) == 0 {
			continue
		}
		v, err := parseJSON(line)
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	return out, nil
}

func flatten(v any, noSort bool) []statement {
	var out []statement
	var walk func([]any, any)
	walk = func(path []any, val any) {
		switch x := val.(type) {
		case map[string]any:
			out = append(out, statement{clonePath(path), map[string]any{}})
			keys := make([]string, 0, len(x))
			for k := range x {
				keys = append(keys, k)
			}
			if !noSort {
				sort.Strings(keys)
			}
			for _, k := range keys {
				walk(append(path, k), x[k])
			}
		case []any:
			out = append(out, statement{clonePath(path), []any{}})
			for i, e := range x {
				walk(append(path, i), e)
			}
		default:
			out = append(out, statement{clonePath(path), x})
		}
	}
	walk(nil, v)
	return out
}

func clonePath(p []any) []any {
	q := make([]any, len(p))
	copy(q, p)
	return q
}

func sortStatements(st []statement) {
	sort.SliceStable(st, func(i, j int) bool {
		return pathString(st[i].Path) < pathString(st[j].Path)
	})
}

func pathString(p []any) string {
	return formatPath(p)
}

func formatPath(path []any) string {
	var b strings.Builder
	b.WriteString("json")
	for _, part := range path {
		switch x := part.(type) {
		case int:
			fmt.Fprintf(&b, "[%d]", x)
		case json.Number:
			b.WriteString("[")
			b.WriteString(x.String())
			b.WriteString("]")
		case float64:
			fmt.Fprintf(&b, "[%g]", x)
		case string:
			if isIdentifier(x) {
				b.WriteByte('.')
				b.WriteString(x)
			} else {
				b.WriteByte('[')
				enc, _ := json.Marshal(x)
				b.Write(enc)
				b.WriteByte(']')
			}
		}
	}
	return b.String()
}

var reserved = map[string]bool{
	"break": true, "case": true, "catch": true, "class": true, "const": true, "continue": true,
	"debugger": true, "default": true, "delete": true, "do": true, "else": true, "export": true,
	"extends": true, "finally": true, "for": true, "function": true, "if": true, "import": true,
	"in": true, "instanceof": true, "new": true, "return": true, "super": true, "switch": true,
	"this": true, "throw": true, "try": true, "typeof": true, "var": true, "void": true,
	"while": true, "with": true, "yield": true, "true": true, "false": true, "null": true,
}

func isIdentifier(s string) bool {
	if s == "" || reserved[s] {
		return false
	}
	for i, r := range s {
		if i == 0 {
			if r != '$' && r != '_' && !unicode.IsLetter(r) {
				return false
			}
			continue
		}
		if r != '$' && r != '_' && !unicode.IsLetter(r) && !unicode.IsDigit(r) {
			return false
		}
	}
	return true
}

func formatValue(v any) string {
	switch x := v.(type) {
	case map[string]any:
		return "{}"
	case []any:
		return "[]"
	case json.Number:
		return x.String()
	default:
		b, _ := json.Marshal(x)
		return string(b)
	}
}

func encodePretty(w io.Writer, v any) error {
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(v)
}

func ungronJSON(input []byte) (any, error) {
	rootSet := false
	var root any
	sc := bufio.NewScanner(bytes.NewReader(input))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var pair []any
		dec := json.NewDecoder(strings.NewReader(line))
		dec.UseNumber()
		if err := dec.Decode(&pair); err != nil {
			return nil, err
		}
		if len(pair) != 2 {
			return nil, errors.New("invalid statement")
		}
		pathRaw, ok := pair[0].([]any)
		if !ok {
			return nil, errors.New("invalid statement")
		}
		path := convertPath(pathRaw)
		if len(path) == 0 {
			root = pair[1]
			rootSet = true
		} else {
			if !rootSet {
				root = containerFor(path[0])
				rootSet = true
			}
			setPath(&root, path, pair[1])
		}
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	if !rootSet {
		return nil, errors.New("invalid statement")
	}
	return root, nil
}

func convertPath(in []any) []any {
	out := make([]any, 0, len(in))
	for _, p := range in {
		switch x := p.(type) {
		case json.Number:
			if i, err := strconv.Atoi(x.String()); err == nil {
				out = append(out, i)
			} else {
				out = append(out, x.String())
			}
		case float64:
			out = append(out, int(x))
		case string:
			out = append(out, x)
		}
	}
	return out
}

func ungronText(input []byte) (any, error) {
	rootSet := false
	var root any
	sc := bufio.NewScanner(bytes.NewReader(input))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		path, val, err := parseStatement(line)
		if err != nil {
			return nil, fmt.Errorf("ungron failed for `%s`: %v", line, err)
		}
		if len(path) == 0 {
			root = val
			rootSet = true
		} else {
			if !rootSet {
				root = containerFor(path[0])
				rootSet = true
			}
			setPath(&root, path, val)
		}
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	if !rootSet {
		return nil, errors.New("ungron failed for ``: invalid statement")
	}
	return root, nil
}

func parseStatement(line string) ([]any, any, error) {
	if !strings.HasSuffix(line, ";") {
		return nil, nil, errors.New("invalid statement")
	}
	body := strings.TrimSpace(strings.TrimSuffix(line, ";"))
	eq := strings.Index(body, "=")
	if eq < 0 {
		return nil, nil, errors.New("invalid statement")
	}
	left := strings.TrimSpace(body[:eq])
	right := strings.TrimSpace(body[eq+1:])
	path, err := parsePath(left)
	if err != nil {
		return nil, nil, err
	}
	var val any
	dec := json.NewDecoder(strings.NewReader(right))
	dec.UseNumber()
	if err := dec.Decode(&val); err != nil {
		return nil, nil, err
	}
	return path, val, nil
}

func parsePath(s string) ([]any, error) {
	if !strings.HasPrefix(s, "json") {
		return nil, errors.New("invalid statement")
	}
	i := len("json")
	path := []any{}
	for i < len(s) {
		switch s[i] {
		case '.':
			i++
			start := i
			for i < len(s) {
				r, sz := rune(s[i]), 1
				if r >= 0x80 {
					r, sz = utf8DecodeRuneInString(s[i:])
				}
				if r == '$' || r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r) {
					i += sz
				} else {
					break
				}
			}
			if start == i {
				return nil, errors.New("invalid statement")
			}
			path = append(path, s[start:i])
		case '[':
			end, err := findBracket(s, i)
			if err != nil {
				return nil, err
			}
			inside := s[i+1 : end]
			if strings.HasPrefix(inside, "\"") {
				var k string
				if err := json.Unmarshal([]byte(inside), &k); err != nil {
					return nil, err
				}
				path = append(path, k)
			} else {
				n, err := strconv.Atoi(strings.TrimSpace(inside))
				if err != nil {
					return nil, err
				}
				path = append(path, n)
			}
			i = end + 1
		default:
			return nil, errors.New("invalid statement")
		}
	}
	return path, nil
}

func utf8DecodeRuneInString(s string) (rune, int) {
	for _, r := range s {
		return r, len(string(r))
	}
	return rune(s[0]), 1
}

func findBracket(s string, start int) (int, error) {
	inString := false
	esc := false
	for i := start + 1; i < len(s); i++ {
		c := s[i]
		if inString {
			if esc {
				esc = false
			} else if c == '\\' {
				esc = true
			} else if c == '"' {
				inString = false
			}
			continue
		}
		if c == '"' {
			inString = true
		} else if c == ']' {
			return i, nil
		}
	}
	return 0, errors.New("invalid statement")
}

func containerFor(next any) any {
	if _, ok := next.(int); ok {
		return []any{}
	}
	return map[string]any{}
}

func setPath(root *any, path []any, val any) {
	if len(path) == 0 {
		*root = val
		return
	}
	setRecursive(root, path, val)
}

func setRecursive(cur *any, path []any, val any) {
	if len(path) == 0 {
		*cur = val
		return
	}
	part := path[0]
	last := len(path) == 1
	switch p := part.(type) {
	case string:
		m, ok := (*cur).(map[string]any)
		if !ok {
			m = map[string]any{}
			*cur = m
		}
		if last {
			m[p] = val
			return
		}
		child, ok := m[p]
		if !ok {
			child = containerFor(path[1])
		}
		setRecursive(&child, path[1:], val)
		m[p] = child
	case int:
		a, ok := (*cur).([]any)
		if !ok {
			a = []any{}
		}
		for len(a) <= p {
			a = append(a, nil)
		}
		if last {
			a[p] = val
			*cur = a
			return
		}
		child := a[p]
		if child == nil {
			child = containerFor(path[1])
		}
		setRecursive(&child, path[1:], val)
		a[p] = child
		*cur = a
	}
}

func printValues(w io.Writer, input []byte) error {
	sc := bufio.NewScanner(bytes.NewReader(input))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		_, val, err := parseStatement(line)
		if err != nil {
			return err
		}
		switch x := val.(type) {
		case string:
			fmt.Fprintln(w, x)
		case map[string]any, []any:
		default:
			fmt.Fprintln(w, formatValue(x))
		}
	}
	return sc.Err()
}
