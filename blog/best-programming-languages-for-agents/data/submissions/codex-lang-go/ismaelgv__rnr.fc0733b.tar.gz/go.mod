module rnrclone

go 1.21
