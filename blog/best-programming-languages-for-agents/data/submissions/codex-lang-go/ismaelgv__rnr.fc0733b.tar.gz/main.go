package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"
)

const version = "rnr 0.5.1"

type options struct {
	dryRun      bool
	force       bool
	backup      bool
	silent      bool
	dump        bool
	noDump      bool
	dumpPrefix  string
	limit       int
	transform   string
	includeDirs bool
	recursive   bool
	maxDepth    int
	hidden      bool
	undo        bool
	color       string
}

type operation struct {
	Source string `json:"source"`
	Target string `json:"target"`
}

type dumpFile struct {
	Date       string      `json:"date"`
	Operations []operation `json:"operations"`
}

func defaultOptions() options {
	return options{dryRun: true, dumpPrefix: "rnr-", limit: 0, maxDepth: -1, color: "auto"}
}

func main() {
	if len(os.Args) < 2 {
		printTopHelp()
		os.Exit(2)
	}
	args := os.Args[1:]
	switch args[0] {
	case "-h", "--help", "help":
		if len(args) > 1 {
			switch args[1] {
			case "regex":
				printRegexHelp()
			case "from-file":
				printFromFileHelp()
			case "to-ascii":
				printAsciiHelp()
			default:
				printTopHelp()
			}
		} else {
			printTopHelp()
		}
	case "-V", "--version":
		fmt.Println(version)
	case "regex":
		if err := runRegex(args[1:]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	case "to-ascii":
		if err := runToASCII(args[1:]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	case "from-file":
		if err := runFromFile(args[1:]); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n", args[0])
		os.Exit(2)
	}
}

func printTopHelp() {
	fmt.Println(`RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`)
}

func printRegexHelp() {
	fmt.Println(`Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run
          Only show what would be done (default mode)
  -f, --force
          Make actual changes to files
  -b, --backup
          Generate file backups before renaming
  -s, --silent
          Do not print any information
      --color <COLOR>
          Set color output mode [default: auto] [possible values: always, never, auto]
      --dump
          Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>
          Set the dump file prefix [default: rnr-]
      --no-dump
          Do not dump operations into a file
  -l, --replace-limit <LIMIT>
          Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs
          Rename matching directories
  -r, --recursive
          Recursive mode
  -d, --max-depth <LEVEL>
          Set max depth in recursive mode
  -x, --hidden
          Include hidden files and directories
  -h, --help
          Print help`)
}

func printFromFileHelp() {
	fmt.Println(`Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>  

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -u, --undo                       Undo the operations from the dump file
  -h, --help                       Print help`)
}

func printAsciiHelp() {
	fmt.Println(`Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help`)
}

func parseCommon(args []string, allowRegex bool, allowUndo bool) (options, []string, error) {
	opt := defaultOptions()
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			rest = append(rest, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			rest = append(rest, args[i:]...)
			break
		}
		switch a {
		case "-h", "--help":
			opt.color = "__help__"
		case "-n", "--dry-run":
			opt.dryRun, opt.force = true, false
		case "-f", "--force":
			opt.force, opt.dryRun = true, false
		case "-b", "--backup":
			opt.backup = true
		case "-s", "--silent":
			opt.silent = true
		case "--dump":
			opt.dump = true
		case "--no-dump":
			opt.noDump = true
		case "-D", "--include-dirs":
			opt.includeDirs = true
		case "-r", "--recursive":
			opt.recursive = true
		case "-x", "--hidden":
			opt.hidden = true
		case "-u", "--undo":
			if !allowUndo {
				return opt, nil, fmt.Errorf("error: unexpected argument '%s'", a)
			}
			opt.undo = true
		case "--color", "--dump-prefix", "-l", "--replace-limit", "-t", "--replace-transform", "-d", "--max-depth":
			if i+1 >= len(args) {
				return opt, nil, fmt.Errorf("error: a value is required for '%s'", a)
			}
			i++
			v := args[i]
			switch a {
			case "--color":
				opt.color = v
			case "--dump-prefix":
				opt.dumpPrefix = v
			case "-l", "--replace-limit":
				n, err := strconv.Atoi(v)
				if err != nil || n < 0 {
					return opt, nil, fmt.Errorf("error: invalid value '%s' for '%s'", v, a)
				}
				opt.limit = n
			case "-t", "--replace-transform":
				if !allowRegex {
					return opt, nil, fmt.Errorf("error: unexpected argument '%s'", a)
				}
				opt.transform = v
			case "-d", "--max-depth":
				n, err := strconv.Atoi(v)
				if err != nil || n < 0 {
					return opt, nil, fmt.Errorf("error: invalid value '%s' for '%s'", v, a)
				}
				opt.maxDepth = n
			}
		default:
			return opt, nil, fmt.Errorf("error: unexpected argument '%s'", a)
		}
	}
	return opt, rest, nil
}

func runRegex(args []string) error {
	opt, rest, err := parseCommon(args, true, false)
	if err != nil {
		return err
	}
	if opt.color == "__help__" {
		printRegexHelp()
		return nil
	}
	if len(rest) < 3 {
		return errors.New("error: missing required arguments")
	}
	re, err := regexp.Compile(rest[0])
	if err != nil {
		return fmt.Errorf("Error: Bad expression provided\n\n%s", err.Error())
	}
	ops, err := buildRegexOps(re, rest[1], rest[2:], opt)
	if err != nil {
		return err
	}
	return executeOps(ops, opt)
}

func runToASCII(args []string) error {
	opt, rest, err := parseCommon(args, false, false)
	if err != nil {
		return err
	}
	if opt.color == "__help__" {
		printAsciiHelp()
		return nil
	}
	if len(rest) < 1 {
		return errors.New("error: missing required arguments")
	}
	ops, err := buildAsciiOps(rest, opt)
	if err != nil {
		return err
	}
	return executeOps(ops, opt)
}

func runFromFile(args []string) error {
	opt, rest, err := parseCommon(args, false, true)
	if err != nil {
		return err
	}
	if opt.color == "__help__" {
		printFromFileHelp()
		return nil
	}
	if len(rest) != 1 {
		return errors.New("error: missing required argument <DUMPFILE>")
	}
	b, err := os.ReadFile(rest[0])
	if err != nil {
		return err
	}
	var df dumpFile
	if err := json.Unmarshal(b, &df); err != nil {
		return err
	}
	ops := df.Operations
	if opt.undo {
		for i := range ops {
			ops[i].Source, ops[i].Target = ops[i].Target, ops[i].Source
		}
	}
	return executeOps(ops, opt)
}

func buildRegexOps(re *regexp.Regexp, repl string, paths []string, opt options) ([]operation, error) {
	var ops []operation
	for _, root := range paths {
		cands, err := candidates(root, opt)
		if err != nil {
			continue
		}
		for _, p := range cands {
			base := filepath.Base(p)
			newBase := replaceLimited(re, base, repl, opt.limit, opt.transform)
			if newBase == base {
				continue
			}
			ops = append(ops, operation{Source: p, Target: joinTarget(p, newBase)})
		}
	}
	return ops, nil
}

func buildAsciiOps(paths []string, opt options) ([]operation, error) {
	var ops []operation
	for _, root := range paths {
		cands, err := candidates(root, opt)
		if err != nil {
			continue
		}
		for _, p := range cands {
			base := filepath.Base(p)
			newBase := toASCII(base)
			if newBase == base {
				continue
			}
			ops = append(ops, operation{Source: p, Target: joinTarget(p, newBase)})
		}
	}
	return ops, nil
}

func candidates(root string, opt options) ([]string, error) {
	info, err := os.Lstat(root)
	if err != nil {
		return nil, err
	}
	if !opt.recursive {
		if info.IsDir() && !opt.includeDirs {
			return nil, nil
		}
		if !opt.hidden && isHiddenPath(root) {
			return nil, nil
		}
		return []string{root}, nil
	}
	var out []string
	err = walkPost(root, root, 0, opt, &out)
	return out, err
}

func walkPost(root, p string, level int, opt options, out *[]string) error {
	info, err := os.Lstat(p)
	if err != nil {
		return nil
	}
	if p != root && !opt.hidden && strings.HasPrefix(filepath.Base(p), ".") {
		if info.IsDir() {
			return nil
		}
		return nil
	}
	if opt.maxDepth >= 0 && level > opt.maxDepth {
		return nil
	}
	if info.IsDir() {
		entries, err := os.ReadDir(p)
		if err != nil {
			return nil
		}
		sort.SliceStable(entries, func(i, j int) bool {
			if entries[i].IsDir() != entries[j].IsDir() {
				return entries[i].IsDir()
			}
			return entries[i].Name() < entries[j].Name()
		})
		for _, e := range entries {
			if !opt.hidden && strings.HasPrefix(e.Name(), ".") {
				continue
			}
			if err := walkPost(root, filepath.Join(p, e.Name()), level+1, opt, out); err != nil {
				return err
			}
		}
		if p != root && opt.includeDirs {
			*out = append(*out, displayPath(root, p))
		}
		return nil
	}
	if p != root || !info.IsDir() {
		*out = append(*out, displayPath(root, p))
	}
	return nil
}

func displayPath(root, p string) string {
	if root == "." && p != "." && !strings.HasPrefix(p, ".") {
		return "." + string(filepath.Separator) + p
	}
	return p
}

func joinTarget(src, newBase string) string {
	if strings.HasPrefix(src, "."+string(filepath.Separator)) {
		trimmed := strings.TrimPrefix(src, "."+string(filepath.Separator))
		return "." + string(filepath.Separator) + filepath.Join(filepath.Dir(trimmed), newBase)
	}
	dir := filepath.Dir(src)
	return filepath.Join(dir, newBase)
}

func isHiddenPath(p string) bool {
	for _, part := range strings.Split(filepath.Clean(p), string(filepath.Separator)) {
		if strings.HasPrefix(part, ".") && part != "." && part != ".." {
			return true
		}
	}
	return false
}

func replaceLimited(re *regexp.Regexp, s, repl string, limit int, transform string) string {
	idxs := re.FindAllStringSubmatchIndex(s, -1)
	if len(idxs) == 0 {
		return s
	}
	if limit > 0 && len(idxs) > limit {
		idxs = idxs[:limit]
	}
	var buf bytes.Buffer
	last := 0
	for _, idx := range idxs {
		if idx[0] < last {
			continue
		}
		buf.WriteString(s[last:idx[0]])
		var rbuf []byte
		rbuf = re.ExpandString(rbuf, repl, s, idx)
		rep := string(rbuf)
		switch transform {
		case "upper":
			rep = strings.ToUpper(rep)
		case "lower":
			rep = strings.ToLower(rep)
		case "ascii":
			rep = toASCII(rep)
		}
		buf.WriteString(rep)
		last = idx[1]
	}
	buf.WriteString(s[last:])
	return buf.String()
}

func executeOps(ops []operation, opt options) error {
	if opt.dryRun && !opt.silent {
		fmt.Println("This is a DRY-RUN")
	}
	if len(ops) == 0 {
		if shouldDump(opt) {
			return writeDump(ops, opt.dumpPrefix)
		}
		return nil
	}
	for _, op := range ops {
		if op.Source == op.Target {
			continue
		}
		if _, err := os.Lstat(op.Target); err == nil {
			return fmt.Errorf("Error: Conflict with existing path %s -> %s", op.Source, op.Target)
		}
	}
	if !opt.dryRun {
		for _, op := range ops {
			if opt.backup {
				bak := op.Source + ".bk"
				if err := copyPath(op.Source, bak); err == nil && !opt.silent {
					fmt.Printf("Info:  Backup created - %s -> %s\n", op.Source, bak)
				}
			}
			if err := os.Rename(op.Source, op.Target); err != nil {
				return err
			}
			if !opt.silent {
				fmt.Printf("%s -> %s\n", op.Source, op.Target)
			}
		}
	} else if !opt.silent {
		for _, op := range ops {
			fmt.Printf("%s -> %s\n", op.Source, op.Target)
		}
	}
	if shouldDump(opt) {
		return writeDump(ops, opt.dumpPrefix)
	}
	return nil
}

func shouldDump(opt options) bool {
	if opt.noDump {
		return false
	}
	return opt.dump || opt.force
}

func writeDump(ops []operation, prefix string) error {
	df := dumpFile{Date: time.Now().Format("2006-01-02 15:04:05"), Operations: ops}
	b, err := json.MarshalIndent(df, "", "  ")
	if err != nil {
		return err
	}
	b = append(b, '\n')
	name := prefix + time.Now().Format("2006-01-02_150405") + ".json"
	return os.WriteFile(name, b, 0644)
}

func copyPath(src, dst string) error {
	info, err := os.Lstat(src)
	if err != nil {
		return err
	}
	if info.IsDir() {
		return os.MkdirAll(dst, info.Mode())
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_EXCL|os.O_WRONLY, info.Mode())
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}

func toASCII(s string) string {
	var b strings.Builder
	for _, r := range s {
		if r < 128 {
			b.WriteRune(r)
			continue
		}
		if rep, ok := accentMap[r]; ok {
			b.WriteString(rep)
			continue
		}
		if unicode.IsSpace(r) {
			b.WriteByte(' ')
		}
	}
	return b.String()
}

var accentMap = map[rune]string{
	'À': "A", 'Á': "A", 'Â': "A", 'Ã': "A", 'Ä': "A", 'Å': "A", 'Ā': "A", 'Ă': "A", 'Ą': "A",
	'à': "a", 'á': "a", 'â': "a", 'ã': "a", 'ä': "a", 'å': "a", 'ā': "a", 'ă': "a", 'ą': "a",
	'Æ': "AE", 'æ': "ae", 'Ç': "C", 'Ć': "C", 'Ĉ': "C", 'Ċ': "C", 'Č': "C",
	'ç': "c", 'ć': "c", 'ĉ': "c", 'ċ': "c", 'č': "c", 'Ð': "D", 'Ď': "D", 'Đ': "D",
	'ð': "d", 'ď': "d", 'đ': "d", 'È': "E", 'É': "E", 'Ê': "E", 'Ë': "E", 'Ē': "E", 'Ĕ': "E", 'Ė': "E", 'Ę': "E", 'Ě': "E",
	'è': "e", 'é': "e", 'ê': "e", 'ë': "e", 'ē': "e", 'ĕ': "e", 'ė': "e", 'ę': "e", 'ě': "e",
	'ƒ': "f", 'Ĝ': "G", 'Ğ': "G", 'Ġ': "G", 'Ģ': "G", 'ĝ': "g", 'ğ': "g", 'ġ': "g", 'ģ': "g",
	'Ĥ': "H", 'Ħ': "H", 'ĥ': "h", 'ħ': "h", 'Ì': "I", 'Í': "I", 'Î': "I", 'Ï': "I", 'Ĩ': "I", 'Ī': "I", 'Ĭ': "I", 'Į': "I", 'İ': "I",
	'ì': "i", 'í': "i", 'î': "i", 'ï': "i", 'ĩ': "i", 'ī': "i", 'ĭ': "i", 'į': "i", 'ı': "i",
	'Ĵ': "J", 'ĵ': "j", 'Ķ': "K", 'ķ': "k", 'ĸ': "k", 'Ĺ': "L", 'Ļ': "L", 'Ľ': "L", 'Ŀ': "L", 'Ł': "L",
	'ĺ': "l", 'ļ': "l", 'ľ': "l", 'ŀ': "l", 'ł': "l", 'Ñ': "N", 'Ń': "N", 'Ņ': "N", 'Ň': "N",
	'ñ': "n", 'ń': "n", 'ņ': "n", 'ň': "n", 'ŉ': "n", 'Ò': "O", 'Ó': "O", 'Ô': "O", 'Õ': "O", 'Ö': "O", 'Ø': "O", 'Ō': "O", 'Ŏ': "O", 'Ő': "O",
	'ò': "o", 'ó': "o", 'ô': "o", 'õ': "o", 'ö': "o", 'ø': "o", 'ō': "o", 'ŏ': "o", 'ő': "o",
	'Œ': "OE", 'œ': "oe", 'Ŕ': "R", 'Ŗ': "R", 'Ř': "R", 'ŕ': "r", 'ŗ': "r", 'ř': "r",
	'Ś': "S", 'Ŝ': "S", 'Ş': "S", 'Š': "S", 'ś': "s", 'ŝ': "s", 'ş': "s", 'š': "s", 'ß': "ss",
	'Ţ': "T", 'Ť': "T", 'Ŧ': "T", 'ţ': "t", 'ť': "t", 'ŧ': "t", 'Ù': "U", 'Ú': "U", 'Û': "U", 'Ü': "U", 'Ũ': "U", 'Ū': "U", 'Ŭ': "U", 'Ů': "U", 'Ű': "U", 'Ų': "U",
	'ù': "u", 'ú': "u", 'û': "u", 'ü': "u", 'ũ': "u", 'ū': "u", 'ŭ': "u", 'ů': "u", 'ű': "u", 'ų': "u",
	'Ŵ': "W", 'ŵ': "w", 'Ý': "Y", 'Ÿ': "Y", 'Ŷ': "Y", 'ý': "y", 'ÿ': "y", 'ŷ': "y",
	'Ź': "Z", 'Ż': "Z", 'Ž': "Z", 'ź': "z", 'ż': "z", 'ž': "z", 'Þ': "TH", 'þ': "th",
}
