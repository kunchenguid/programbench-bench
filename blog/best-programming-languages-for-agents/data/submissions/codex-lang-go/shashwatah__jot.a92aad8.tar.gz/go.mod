module jotclone

go 1.21
