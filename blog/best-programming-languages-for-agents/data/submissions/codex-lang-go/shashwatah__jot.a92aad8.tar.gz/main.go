package main

import (
	"bufio"
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
)

const blue = "\033[0;34m"
const red = "\033[0;31m"
const reset = "\033[0m"

type Store struct {
	Current string
	Vaults  map[string]string
}

type Config struct {
	Editor   string
	Conflict bool
}

type VaultData struct {
	Name     string
	Location string
	Folder   string
}

func main() {
	ensure()
	args := os.Args[1:]
	if len(args) == 0 || args[0] == "help" {
		if len(args) > 1 {
			args = append([]string{args[1], "--help"}, args[2:]...)
		} else {
			printMainHelp()
			if len(os.Args) == 1 {
				os.Exit(2)
			}
			return
		}
	}
	if len(args) > 0 && (args[0] == "-h" || args[0] == "--help") {
		printMainHelp()
		return
	}
	cmd := args[0]
	rest := args[1:]
	if len(rest) > 0 && (rest[0] == "-h" || rest[0] == "--help") {
		printCmdHelp(cmd)
		return
	}
	switch cmd {
	case "vault", "vl":
		cmdVault(rest)
	case "enter", "en":
		cmdEnter(rest)
	case "note", "nt":
		cmdNote(rest)
	case "folder", "fd":
		cmdFolder(rest)
	case "list", "ls":
		cmdList(rest)
	case "chdir", "cd":
		cmdChdir(rest)
	case "remove", "rm":
		cmdRemove(rest)
	case "rename", "rn":
		cmdRename(rest)
	case "move", "mv":
		cmdMove(rest)
	case "vmove", "vm":
		cmdVMove(rest)
	case "open", "op":
		cmdOpen(rest)
	case "opdir", "od":
		cmdOpdir(rest)
	case "config", "cf":
		cmdConfig(rest)
	default:
		fmt.Printf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help\n", cmd)
		os.Exit(2)
	}
}

func home() string {
	if h := os.Getenv("HOME"); h != "" {
		return h
	}
	return "."
}

func dataPath() string   { return filepath.Join(home(), ".local", "share", "jot", "vaults") }
func configPath() string { return filepath.Join(home(), ".config", "jot", "config") }

func ensure() {
	os.MkdirAll(filepath.Dir(dataPath()), 0755)
	os.MkdirAll(filepath.Dir(configPath()), 0755)
	os.MkdirAll(filepath.Join(home(), ".cache", "rosetta"), 0755)
	if _, err := os.Stat(dataPath()); err != nil {
		os.WriteFile(dataPath(), []byte("[vaults]\n"), 0644)
	}
	if _, err := os.Stat(configPath()); err != nil {
		os.WriteFile(configPath(), []byte("editor = 'nvim'\nconflict = true\n"), 0644)
	}
}

func readStore() Store {
	s := Store{Vaults: map[string]string{}}
	f, err := os.Open(dataPath())
	if err != nil {
		return s
	}
	defer f.Close()
	inVaults := false
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		if line == "[vaults]" {
			inVaults = true
			continue
		}
		if strings.HasPrefix(line, "current") {
			s.Current = val(line)
		} else if inVaults && strings.Contains(line, "=") {
			p := strings.SplitN(line, "=", 2)
			s.Vaults[strings.TrimSpace(p[0])] = trimQuote(strings.TrimSpace(p[1]))
		}
	}
	return s
}

func writeStore(s Store) {
	var b strings.Builder
	if s.Current != "" {
		fmt.Fprintf(&b, "current = '%s'\n\n", s.Current)
	}
	b.WriteString("[vaults]\n")
	keys := make([]string, 0, len(s.Vaults))
	for k := range s.Vaults {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Fprintf(&b, "%s = '%s'\n", k, s.Vaults[k])
	}
	os.WriteFile(dataPath(), []byte(b.String()), 0644)
}

func readConfig() Config {
	c := Config{Editor: "nvim", Conflict: true}
	b, _ := os.ReadFile(configPath())
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "editor") {
			c.Editor = val(line)
		}
		if strings.HasPrefix(line, "conflict") {
			c.Conflict = strings.TrimSpace(strings.SplitN(line, "=", 2)[1]) == "true"
		}
	}
	return c
}

func writeConfig(c Config) {
	os.WriteFile(configPath(), []byte(fmt.Sprintf("editor = '%s'\nconflict = %v\n", c.Editor, c.Conflict)), 0644)
}

func val(line string) string {
	if !strings.Contains(line, "=") {
		return ""
	}
	return trimQuote(strings.TrimSpace(strings.SplitN(line, "=", 2)[1]))
}

func trimQuote(s string) string {
	s = strings.TrimSpace(s)
	return strings.Trim(s, "'\"")
}

func currentVault() (Store, VaultData, string, bool) {
	s := readStore()
	if s.Current == "" {
		perr("not inside a vault")
		return s, VaultData{}, "", false
	}
	base, ok := s.Vaults[s.Current]
	if !ok {
		perr("not inside a vault")
		return s, VaultData{}, "", false
	}
	root := filepath.Join(base, s.Current)
	d := readVaultData(root)
	return s, d, root, true
}

func readVaultData(root string) VaultData {
	d := VaultData{Name: filepath.Base(root), Location: filepath.Dir(root)}
	b, _ := os.ReadFile(filepath.Join(root, ".jot", "data"))
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "name") {
			d.Name = val(line)
		}
		if strings.HasPrefix(line, "location") {
			d.Location = val(line)
		}
		if strings.HasPrefix(line, "folder") {
			d.Folder = val(line)
		}
	}
	return d
}

func writeVaultData(root string, d VaultData) {
	os.MkdirAll(filepath.Join(root, ".jot"), 0755)
	text := fmt.Sprintf("name = '%s'\nlocation = '%s'\nfolder = '%s'\nhistory = []\n", d.Name, d.Location, d.Folder)
	os.WriteFile(filepath.Join(root, ".jot", "data"), []byte(text), 0644)
}

func currentDir(root string, d VaultData) string {
	return filepath.Join(root, filepath.Clean("/"+d.Folder))
}

func relClean(p string) string {
	p = filepath.Clean("/" + p)
	p = strings.TrimPrefix(p, "/")
	if p == "." {
		return ""
	}
	return p
}

func inside(root, p string) bool {
	r, _ := filepath.Abs(root)
	a, _ := filepath.Abs(p)
	return a == r || strings.HasPrefix(a, r+string(os.PathSeparator))
}

func noteFile(name string) string {
	if strings.HasSuffix(name, ".md") {
		return name
	}
	return name + ".md"
}

func displayNote(name string) string {
	return strings.TrimSuffix(name, ".md")
}

func perr(s string)     { fmt.Printf("%serror%s: %s\n", red, reset, s) }
func b(s string) string { return blue + s + reset }

func cmdVault(args []string) {
	s := readStore()
	if len(args) == 0 || (len(args) == 1 && args[0] == "-l") {
		keys := make([]string, 0, len(s.Vaults))
		for k := range s.Vaults {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			prefix := "   "
			name := k
			if k == s.Current {
				prefix = "👉 "
				name = b(k)
			}
			if len(args) == 1 {
				fmt.Printf("%s%s \t %s\n", prefix, name, s.Vaults[k])
			} else {
				fmt.Printf("%s%s\n", prefix, name)
			}
		}
		return
	}
	if len(args) != 2 {
		fmt.Println("error: invalid arguments")
		os.Exit(2)
	}
	name, loc := args[0], args[1]
	if !filepath.IsAbs(loc) {
		perr("specified path isn't absolute")
		return
	}
	if _, ok := s.Vaults[name]; ok {
		perr(fmt.Sprintf("vault %s already exists", name))
		return
	}
	if st, err := os.Stat(loc); err != nil || !st.IsDir() {
		perr("couldn't find the path specified")
		return
	}
	root := filepath.Join(loc, name)
	if err := os.Mkdir(root, 0755); err != nil {
		perr("couldn't create vault")
		return
	}
	writeVaultData(root, VaultData{Name: name, Location: loc})
	s.Vaults[name] = loc
	writeStore(s)
	fmt.Printf("vault %s created\n", b(name))
}

func cmdEnter(args []string) {
	need(args, 1, "enter <vault name>")
	s := readStore()
	if _, ok := s.Vaults[args[0]]; !ok {
		perr(fmt.Sprintf("vault %s doesn't exist", args[0]))
		return
	}
	s.Current = args[0]
	writeStore(s)
	fmt.Printf("entered %s\n", b(args[0]))
}

func cmdNote(args []string) {
	if len(args) == 0 {
		fmt.Println("error: The following required arguments were not provided:\n    <note name>\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nFor more information try --help")
		os.Exit(2)
	}
	if len(args) != 1 {
		os.Exit(2)
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	path := filepath.Join(currentDir(root, d), noteFile(args[0]))
	if _, err := os.Stat(path); err == nil {
		perr(fmt.Sprintf("a note named %s already exists in this location", args[0]))
		return
	}
	os.WriteFile(path, []byte(""), 0644)
	fmt.Printf("note %s created\n", b(args[0]))
}

func cmdFolder(args []string) {
	if len(args) == 0 {
		fmt.Println("error: The following required arguments were not provided:\n    <folder name>\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nFor more information try --help")
		os.Exit(2)
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	path := filepath.Join(currentDir(root, d), args[0])
	if _, err := os.Stat(path); err == nil {
		perr(fmt.Sprintf("a folder named %s already exists in this location", args[0]))
		return
	}
	os.Mkdir(path, 0755)
	fmt.Printf("folder %s created\n", b(args[0]))
}

func cmdChdir(args []string) {
	need(args, 1, "chdir <folder path>")
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	target := args[0]
	var p string
	if filepath.IsAbs(target) {
		p = filepath.Join(root, strings.TrimPrefix(filepath.Clean(target), "/"))
	} else {
		p = filepath.Join(currentDir(root, d), target)
	}
	p = filepath.Clean(p)
	if !inside(root, p) {
		perr("path crosses the bounds of vault")
		return
	}
	if st, err := os.Stat(p); err != nil || !st.IsDir() {
		perr("couldn't find the path specified")
		return
	}
	d.Folder = relClean(strings.TrimPrefix(p, root))
	writeVaultData(root, d)
	fmt.Println("folder changed")
}

func cmdList(args []string) {
	typ := ""
	if len(args) > 0 {
		typ = args[0]
	}
	if typ != "" && typ != "note" && typ != "nt" && typ != "folder" && typ != "fd" {
		fmt.Printf("error: \"%s\" isn't a valid value for '<item type>'\n\t[possible values: note, nt, folder, fd]\n\nFor more information try --help\n", typ)
		os.Exit(2)
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	header := d.Name
	if d.Folder != "" {
		header += " > " + strings.ReplaceAll(d.Folder, string(os.PathSeparator), " > ")
	}
	fmt.Println(header)
	printTree(currentDir(root, d), typ, "")
}

func printTree(dir, typ, prefix string) {
	ents, _ := os.ReadDir(dir)
	var items []fs.DirEntry
	for _, e := range ents {
		if typ == "" && e.Name() == ".jot" {
			continue
		}
		if typ == "note" || typ == "nt" {
			if e.Type().IsRegular() && strings.HasSuffix(e.Name(), ".md") {
				items = append(items, e)
			}
			continue
		}
		if typ == "folder" || typ == "fd" {
			if e.IsDir() {
				items = append(items, e)
			}
			continue
		}
		if e.IsDir() || (e.Type().IsRegular() && strings.HasSuffix(e.Name(), ".md")) {
			items = append(items, e)
		}
	}
	sort.Slice(items, func(i, j int) bool {
		if items[i].IsDir() != items[j].IsDir() {
			return items[i].IsDir()
		}
		return items[i].Name() < items[j].Name()
	})
	for i, e := range items {
		conn := "├── "
		next := "│   "
		if i == len(items)-1 {
			conn = "└── "
			next = "    "
		}
		name := e.Name()
		if strings.HasSuffix(name, ".md") {
			name = b(displayNote(name))
		}
		fmt.Println(prefix + conn + name)
		if e.IsDir() && typ == "" {
			printTree(filepath.Join(dir, e.Name()), typ, prefix+next)
		}
	}
}

func itemPath(root string, d VaultData, typ, name string) string {
	switch typ {
	case "note", "nt":
		return filepath.Join(currentDir(root, d), noteFile(name))
	case "folder", "fd":
		return filepath.Join(currentDir(root, d), name)
	}
	return ""
}

func cmdRemove(args []string) {
	checkTypeArgs(args, "remove", true)
	typ, name := args[0], args[1]
	if typ == "vault" || typ == "vl" {
		s := readStore()
		base, ok := s.Vaults[name]
		if !ok {
			perr(fmt.Sprintf("vault %s not found", name))
			return
		}
		os.RemoveAll(filepath.Join(base, name))
		delete(s.Vaults, name)
		if s.Current == name {
			s.Current = ""
		}
		writeStore(s)
		fmt.Printf("vault %s removed\n", b(name))
		return
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	p := itemPath(root, d, typ, name)
	if _, err := os.Stat(p); err != nil {
		perr(fmt.Sprintf("%s %s not found", fullType(typ), name))
		return
	}
	os.RemoveAll(p)
	fmt.Printf("%s %s removed\n", fullType(typ), b(name))
}

func cmdRename(args []string) {
	checkTypeArgsN(args, "rename", 3, true)
	typ, name, nn := args[0], args[1], args[2]
	if typ == "vault" || typ == "vl" {
		s := readStore()
		base, ok := s.Vaults[name]
		if !ok {
			perr(fmt.Sprintf("vault %s not found", name))
			return
		}
		os.Rename(filepath.Join(base, name), filepath.Join(base, nn))
		delete(s.Vaults, name)
		s.Vaults[nn] = base
		if s.Current == name {
			s.Current = nn
		}
		writeVaultData(filepath.Join(base, nn), VaultData{Name: nn, Location: base})
		writeStore(s)
		fmt.Printf("vault %s renamed to %s\n", b(name), b(nn))
		return
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	old := itemPath(root, d, typ, name)
	newp := itemPath(root, d, typ, nn)
	if _, err := os.Stat(old); err != nil {
		perr(fmt.Sprintf("%s %s not found", fullType(typ), name))
		return
	}
	os.Rename(old, newp)
	fmt.Printf("%s %s renamed to %s\n", fullType(typ), b(name), b(nn))
}

func cmdMove(args []string) {
	checkTypeArgsN(args, "move", 3, true)
	typ, name, dest := args[0], args[1], args[2]
	if typ == "vault" || typ == "vl" {
		s := readStore()
		base, ok := s.Vaults[name]
		if !ok {
			perr(fmt.Sprintf("vault %s not found", name))
			return
		}
		if st, err := os.Stat(dest); err != nil || !st.IsDir() || !filepath.IsAbs(dest) {
			perr("couldn't find the path specified")
			return
		}
		os.Rename(filepath.Join(base, name), filepath.Join(dest, name))
		s.Vaults[name] = dest
		writeVaultData(filepath.Join(dest, name), VaultData{Name: name, Location: dest})
		writeStore(s)
		fmt.Printf("vault %s moved\n", b(name))
		return
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	src := itemPath(root, d, typ, name)
	if _, err := os.Stat(src); err != nil {
		perr(fmt.Sprintf("%s %s not found", fullType(typ), name))
		return
	}
	dstDir := filepath.Join(currentDir(root, d), dest)
	if filepath.IsAbs(dest) {
		dstDir = filepath.Join(root, strings.TrimPrefix(filepath.Clean(dest), "/"))
	}
	if st, err := os.Stat(dstDir); err != nil || !st.IsDir() || !inside(root, dstDir) {
		perr("couldn't find the path specified")
		return
	}
	os.Rename(src, filepath.Join(dstDir, filepath.Base(src)))
	fmt.Printf("%s %s moved\n", fullType(typ), b(name))
}

func cmdVMove(args []string) {
	checkTypeArgsN(args, "vmove", 3, false)
	typ, name, vname := args[0], args[1], args[2]
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	s := readStore()
	base, ok := s.Vaults[vname]
	if !ok {
		perr(fmt.Sprintf("vault %s doesn't exist", vname))
		return
	}
	src := itemPath(root, d, typ, name)
	if _, err := os.Stat(src); err != nil {
		perr(fmt.Sprintf("%s %s not found", fullType(typ), name))
		return
	}
	dst := filepath.Join(base, vname, filepath.Base(src))
	os.Rename(src, dst)
	fmt.Printf("%s %s moved to vault %s\n", fullType(typ), b(name), b(vname))
}

func cmdOpen(args []string) {
	need(args, 1, "open <note name>")
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	p := filepath.Join(currentDir(root, d), noteFile(args[0]))
	if _, err := os.Stat(p); err != nil {
		perr(fmt.Sprintf("note %s not found", args[0]))
		return
	}
	runEditor(p)
}

func cmdOpdir(args []string) {
	if len(args) != 0 {
		os.Exit(2)
	}
	_, d, root, ok := currentVault()
	if !ok {
		return
	}
	runEditor(currentDir(root, d))
}

func cmdConfig(args []string) {
	c := readConfig()
	if len(args) == 0 {
		runEditor(configPath())
		return
	}
	switch args[0] {
	case "editor":
		if len(args) == 1 {
			fmt.Printf("editor: %s\n", b(c.Editor))
		} else {
			c.Editor = args[1]
			writeConfig(c)
			fmt.Printf("set %s to %s\n", b("editor"), b(args[1]))
		}
	case "conflict":
		if len(args) == 1 {
			fmt.Printf("conflict: %s\n", b(fmt.Sprintf("%v", c.Conflict)))
		} else {
			c.Conflict = args[1] == "true"
			writeConfig(c)
			fmt.Printf("set %s to %s\n", b("conflict"), b(args[1]))
		}
	default:
		perr(fmt.Sprintf("config %s doesn't exist", args[0]))
	}
}

func runEditor(path string) {
	ed := readConfig().Editor
	c := exec.Command(ed, path)
	c.Stdin = os.Stdin
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	_ = c.Run()
}

func fullType(t string) string {
	switch t {
	case "vault", "vl":
		return "vault"
	case "note", "nt":
		return "note"
	}
	return "folder"
}

func checkTypeArgs(args []string, cmd string, vault bool) {
	checkTypeArgsN(args, cmd, 2, vault)
}

func checkTypeArgsN(args []string, cmd string, n int, vault bool) {
	if len(args) < 1 {
		os.Exit(2)
	}
	ok := args[0] == "note" || args[0] == "nt" || args[0] == "folder" || args[0] == "fd" || (vault && (args[0] == "vault" || args[0] == "vl"))
	if !ok {
		vals := "note, nt, folder, fd"
		if vault {
			vals = "vault, vl, note, nt, folder, fd"
		}
		fmt.Printf("error: \"%s\" isn't a valid value for '<item type>'\n\t[possible values: %s]\n\nFor more information try --help\n", args[0], vals)
		os.Exit(2)
	}
	if len(args) != n {
		os.Exit(2)
	}
}

func need(args []string, n int, usage string) {
	if len(args) != n {
		fmt.Printf("error: invalid arguments\n\nUSAGE:\n    executable %s\n", usage)
		os.Exit(2)
	}
}

func printMainHelp() {
	fmt.Print(blue + `________      _____ 
______(_)_______  /_
_____  /_  __ \  __/
____  / / /_/ / /_  
___  /  \____/\__/  
/___/         ᵥ₀.₁.₂  
` + reset + `         

usage: jt <command>

` + blue + `commands:` + reset + `

create items
    ` + blue + `vault` + reset + `, ` + blue + `vl` + reset + `       create a vault or list vaults
    create items in current folder
        ` + blue + `note` + reset + `, ` + blue + `nt` + reset + `        create a note 
        ` + blue + `folder` + reset + `, ` + blue + `fd` + reset + `      create a folder

interact with items
    ` + blue + `enter` + reset + `, ` + blue + `en` + reset + `       enter a vault
    ` + blue + `open` + reset + `, ` + blue + `op` + reset + `        open a note from current folder
    ` + blue + `opdir` + reset + `, ` + blue + `od` + reset + `       open current folder in file explorer
    ` + blue + `chdir` + reset + `, ` + blue + `cd` + reset + `       change folder within current vault
    ` + blue + `list` + reset + `, ` + blue + `ls` + reset + `        list items in current folder

perform fs operations on items
    ` + blue + `remove` + reset + `, ` + blue + `rm` + reset + `      remove an item 
    ` + blue + `rename` + reset + `, ` + blue + `rn` + reset + `      rename an item 
    ` + blue + `move` + reset + `, ` + blue + `mv` + reset + `        move an item to a new location
    ` + blue + `vmove` + reset + `, ` + blue + `vm` + reset + `       move an item to a different vault

config
    ` + blue + `config` + reset + `, ` + blue + `cf` + reset + `      display, set or open config

get help 
    use ` + blue + `help` + reset + ` or ` + blue + `-h` + reset + ` and ` + blue + `--help` + reset + ` flags along with a command to get corresponding help
`)
}

func printCmdHelp(cmd string) {
	canonical := map[string]string{"vl": "vault", "nt": "note", "fd": "folder", "en": "enter", "op": "open", "od": "opdir", "cd": "chdir", "ls": "list", "rm": "remove", "rn": "rename", "mv": "move", "vm": "vmove", "cf": "config"}
	if v, ok := canonical[cmd]; ok {
		cmd = v
	}
	switch cmd {
	case "vault":
		fmt.Println("executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information")
	case "note":
		fmt.Println("executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information")
	case "folder":
		fmt.Println("executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information")
	case "enter":
		fmt.Println("executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information")
	case "open":
		fmt.Println("executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information")
	case "opdir":
		fmt.Println("executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information")
	case "chdir":
		fmt.Println("executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information")
	case "list":
		fmt.Println("executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information")
	case "remove":
		fmt.Println("executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information")
	case "rename":
		fmt.Println("executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information")
	case "move":
		fmt.Println("executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information")
	case "vmove":
		fmt.Println("executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information")
	case "config":
		fmt.Println("executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information")
	default:
		fmt.Printf("error: The subcommand '%s' wasn't recognized\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help\n", cmd)
		os.Exit(2)
	}
}
