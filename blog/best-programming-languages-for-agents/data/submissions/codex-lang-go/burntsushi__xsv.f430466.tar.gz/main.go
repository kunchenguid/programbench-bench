package main

import (
	"encoding/csv"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"
)

const topHelp = `Usage:
    xsv <command> [<args>...]
    xsv [options]

Options:
    --list        List all commands available.
    -h, --help    Display this message
    <command> -h  Display the command help message
    --version     Print version info and exit

Commands:
    cat         Concatenate by row or column
    count       Count records
    fixlengths  Makes all records have same length
    flatten     Show one field per line
    fmt         Format CSV output (change field delimiter)
    frequency   Show frequency tables
    headers     Show header names
    help        Show this usage message.
    index       Create CSV index for faster access
    input       Read CSV data with special quoting rules
    join        Join CSV files
    partition   Partition CSV data based on a column value
    sample      Randomly sample CSV data
    reverse     Reverse rows of CSV data
    search      Search CSV data with regexes
    select      Select columns from CSV
    slice       Slice records from CSV
    sort        Sort CSV data
    split       Split CSV data into many files
    stats       Compute basic statistics
    table       Align CSV data into columns
`

const listText = `Installed commands:
    cat         Concatenate by row or column
    count       Count records
    fixlengths  Makes all records have same length
    flatten     Show one field per line
    fmt         Format CSV output (change field delimiter)
    frequency   Show frequency tables
    headers     Show header names
    help        Show this usage message.
    index       Create CSV index for faster access
    input       Read CSV data with special quoting rules
    join        Join CSV files
    partition   Partition CSV data based on a column value
    sample      Randomly sample CSV data
    reverse     Reverse rows of CSV data
    search      Search CSV data with regexes
    select      Select columns from CSV
    slice       Slice records from CSV
    sort        Sort CSV data
    split       Split CSV data into many files
    stats       Compute basic statistics
    table       Align CSV data into columns
`

type common struct {
	noHeaders bool
	delim     rune
	output    string
}

func main() {
	if len(os.Args) == 1 {
		fmt.Print(topHelp)
		return
	}
	switch os.Args[1] {
	case "-h", "--help", "help":
		fmt.Print(topHelp)
	case "--version":
		fmt.Println("0.13.0")
	case "--list":
		fmt.Print(listText)
	case "count":
		must(cmdCount(os.Args[2:]))
	case "headers":
		must(cmdHeaders(os.Args[2:]))
	case "select":
		must(cmdSelect(os.Args[2:]))
	case "slice":
		must(cmdSlice(os.Args[2:]))
	case "search":
		must(cmdSearch(os.Args[2:]))
	case "sort":
		must(cmdSort(os.Args[2:]))
	case "reverse":
		must(cmdReverse(os.Args[2:]))
	case "fmt":
		must(cmdFmt(os.Args[2:]))
	case "input":
		must(cmdInput(os.Args[2:]))
	case "fixlengths":
		must(cmdFixLengths(os.Args[2:]))
	case "flatten":
		must(cmdFlatten(os.Args[2:]))
	case "frequency":
		must(cmdFrequency(os.Args[2:]))
	case "stats":
		must(cmdStats(os.Args[2:]))
	case "table":
		must(cmdTable(os.Args[2:]))
	case "cat":
		must(cmdCat(os.Args[2:]))
	case "join":
		must(cmdJoin(os.Args[2:]))
	case "sample":
		must(cmdSample(os.Args[2:]))
	case "split":
		must(cmdSplit(os.Args[2:]))
	case "partition":
		must(cmdPartition(os.Args[2:]))
	case "index":
		must(cmdIndex(os.Args[2:]))
	default:
		die("Unrecognized command: %s", os.Args[1])
	}
}
func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
func die(f string, a ...any) { fmt.Fprintf(os.Stderr, f+"\n", a...); os.Exit(1) }

func newFS(name string) *flag.FlagSet {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.Bool("help", false, "")
	fs.Bool("h", false, "")
	return fs
}
func addCommon(fs *flag.FlagSet, c *common, out bool, nohead bool) {
	if nohead {
		fs.BoolVar(&c.noHeaders, "no-headers", false, "")
		fs.BoolVar(&c.noHeaders, "n", false, "")
	}
	fs.Func("delimiter", "", func(s string) error {
		if s == "\\t" {
			c.delim = '\t'
			return nil
		}
		r, sz := utf8.DecodeRuneInString(s)
		if r == utf8.RuneError || sz != len(s) {
			return errors.New("delimiter must be one char")
		}
		c.delim = r
		return nil
	})
	fs.Func("d", "", func(s string) error {
		if s == "\\t" {
			c.delim = '\t'
			return nil
		}
		r, sz := utf8.DecodeRuneInString(s)
		if r == utf8.RuneError || sz != len(s) {
			return errors.New("delimiter must be one char")
		}
		c.delim = r
		return nil
	})
	if out {
		fs.StringVar(&c.output, "output", "", "")
		fs.StringVar(&c.output, "o", "", "")
	}
}
func parse(fs *flag.FlagSet, args []string) bool {
	_ = fs.Parse(args)
	h := fs.Lookup("help").Value.String() == "true" || fs.Lookup("h").Value.String() == "true"
	return h
}

func readCSV(path string, delim rune) ([][]string, error) {
	var r io.Reader
	if path == "" || path == "-" {
		r = os.Stdin
	} else {
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer f.Close()
		r = f
	}
	cr := csv.NewReader(r)
	cr.FieldsPerRecord = -1
	cr.Comma = delim
	return cr.ReadAll()
}
func writer(path string, delim rune) (*csv.Writer, func(), error) {
	var w io.Writer
	close := func() {}
	if path == "" {
		w = os.Stdout
	} else {
		f, err := os.Create(path)
		if err != nil {
			return nil, nil, err
		}
		w = f
		close = func() { f.Close() }
	}
	cw := csv.NewWriter(w)
	cw.Comma = delim
	return cw, func() { cw.Flush(); close() }, nil
}
func writeRows(path string, rows [][]string, delim rune) error {
	cw, done, err := writer(path, delim)
	if err != nil {
		return err
	}
	defer done()
	for _, r := range rows {
		if err := cw.Write(r); err != nil {
			return err
		}
	}
	return nil
}
func splitHeader(rows [][]string, no bool) ([]string, [][]string) {
	if !no && len(rows) > 0 {
		return rows[0], rows[1:]
	}
	return nil, rows
}
func outRows(header []string, rows [][]string) [][]string {
	if header == nil {
		return rows
	}
	x := make([][]string, 0, len(rows)+1)
	x = append(x, header)
	x = append(x, rows...)
	return x
}

func cmdCount(args []string) error {
	c := common{delim: ','}
	fs := newFS("count")
	addCommon(fs, &c, false, true)
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv count [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	_, data := splitHeader(rows, c.noHeaders)
	fmt.Println(len(data))
	return nil
}
func cmdHeaders(args []string) error {
	c := common{delim: ','}
	just := false
	inter := false
	fs := newFS("headers")
	addCommon(fs, &c, false, false)
	fs.BoolVar(&just, "just-names", false, "")
	fs.BoolVar(&just, "j", false, "")
	fs.BoolVar(&inter, "intersect", false, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv headers [options] [<input>...]\n")
		return nil
	}
	files := fs.Args()
	if len(files) > 1 {
		just = true
	}
	var all [][]string
	if len(files) == 0 {
		files = []string{""}
	}
	for _, f := range files {
		r, e := readCSV(f, c.delim)
		if e != nil {
			return e
		}
		if len(r) > 0 {
			all = append(all, r[0])
		}
	}
	if len(all) == 0 {
		return nil
	}
	hdr := all[0]
	if inter {
		m := map[string]bool{}
		for _, h := range hdr {
			m[h] = true
		}
		for _, hs := range all[1:] {
			mm := map[string]bool{}
			for _, h := range hs {
				mm[h] = true
			}
			for h := range m {
				if !mm[h] {
					delete(m, h)
				}
			}
		}
		var nh []string
		for _, h := range hdr {
			if m[h] {
				nh = append(nh, h)
			}
		}
		hdr = nh
	}
	for i, h := range hdr {
		if just {
			fmt.Println(h)
		} else {
			fmt.Printf("%d   %s\n", i+1, h)
		}
	}
	return nil
}

func first(a []string) string {
	if len(a) == 0 {
		return ""
	}
	return a[0]
}
func atoi(s string) int { n, _ := strconv.Atoi(s); return n }

func parseSelection(sel string, header []string, width int) ([]int, error) {
	inv := false
	if strings.HasPrefix(sel, "!") {
		inv = true
		sel = strings.TrimPrefix(sel, "!")
	}
	parts := splitSel(sel)
	chosen := []int{}
	add := func(i int) {
		if i >= 0 && i < width {
			chosen = append(chosen, i)
		}
	}
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		a, b, hasRange := strings.Cut(p, "-")
		if hasRange {
			ai := colIndex(a, header, width)
			bi := width - 1
			if b != "" {
				bi = colIndex(b, header, width)
			}
			if ai < 0 {
				ai = 0
			}
			if bi < 0 {
				bi = width - 1
			}
			step := 1
			if ai > bi {
				step = -1
			}
			for i := ai; ; i += step {
				add(i)
				if i == bi {
					break
				}
			}
		} else {
			add(colIndex(p, header, width))
		}
	}
	if inv {
		set := map[int]bool{}
		for _, i := range chosen {
			set[i] = true
		}
		chosen = nil
		for i := 0; i < width; i++ {
			if !set[i] {
				chosen = append(chosen, i)
			}
		}
	}
	return chosen, nil
}
func splitSel(s string) []string {
	var out []string
	var b strings.Builder
	q := false
	for i := 0; i < len(s); i++ {
		ch := s[i]
		if ch == '"' {
			q = !q
			continue
		}
		if ch == ',' && !q {
			out = append(out, b.String())
			b.Reset()
		} else {
			b.WriteByte(ch)
		}
	}
	out = append(out, b.String())
	return out
}
func colIndex(s string, header []string, width int) int {
	s = strings.TrimSpace(s)
	if s == "" {
		return -1
	}
	if n, err := strconv.Atoi(s); err == nil {
		return n - 1
	}
	occ := 1
	if strings.HasSuffix(s, "]") {
		if i := strings.LastIndex(s, "["); i >= 0 {
			occ = atoi(s[i+1 : len(s)-1])
			s = s[:i]
		}
	}
	cnt := 0
	for i, h := range header {
		if h == s {
			cnt++
			if cnt == occ {
				return i
			}
		}
	}
	return -1
}
func project(row []string, idx []int) []string {
	out := make([]string, len(idx))
	for i, j := range idx {
		if j >= 0 && j < len(row) {
			out[i] = row[j]
		}
	}
	return out
}

func cmdSelect(args []string) error {
	c := common{delim: ','}
	fs := newFS("select")
	addCommon(fs, &c, true, true)
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv select [options] [--] <selection> [<input>]\n")
		return nil
	}
	a := fs.Args()
	if len(a) < 1 {
		return errors.New("selection required")
	}
	rows, err := readCSV(arg(a, 1), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	width := maxWidth(rows)
	idx, _ := parseSelection(a[0], hdr, width)
	var oh []string
	if hdr != nil {
		oh = project(hdr, idx)
	}
	out := [][]string{}
	for _, r := range data {
		out = append(out, project(r, idx))
	}
	return writeRows(c.output, outRows(oh, out), ',')
}
func maxWidth(rows [][]string) int {
	m := 0
	for _, r := range rows {
		if len(r) > m {
			m = len(r)
		}
	}
	return m
}
func arg(a []string, i int) string {
	if len(a) > i {
		return a[i]
	}
	return ""
}

func cmdSlice(args []string) error {
	c := common{delim: ','}
	start := 0
	end := -1
	ln := -1
	idx := -1
	fs := newFS("slice")
	addCommon(fs, &c, true, true)
	fs.IntVar(&start, "start", 0, "")
	fs.IntVar(&start, "s", 0, "")
	fs.IntVar(&end, "end", -1, "")
	fs.IntVar(&end, "e", -1, "")
	fs.IntVar(&ln, "len", -1, "")
	fs.IntVar(&ln, "l", -1, "")
	fs.IntVar(&idx, "index", -1, "")
	fs.IntVar(&idx, "i", -1, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv slice [options] [<input>]\n")
		return nil
	}
	if idx >= 0 {
		start = idx
		ln = 1
	}
	if ln >= 0 {
		end = start + ln
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	if start < 0 {
		start = 0
	}
	if end < 0 || end > len(data) {
		end = len(data)
	}
	if start > len(data) {
		start = len(data)
	}
	if end < start {
		end = start
	}
	return writeRows(c.output, outRows(hdr, data[start:end]), ',')
}
func cmdSearch(args []string) error {
	c := common{delim: ','}
	ic := false
	inv := false
	sel := ""
	fs := newFS("search")
	addCommon(fs, &c, true, true)
	fs.BoolVar(&ic, "ignore-case", false, "")
	fs.BoolVar(&ic, "i", false, "")
	fs.BoolVar(&inv, "invert-match", false, "")
	fs.BoolVar(&inv, "v", false, "")
	fs.StringVar(&sel, "select", "", "")
	fs.StringVar(&sel, "s", "", "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv search [options] <regex> [<input>]\n")
		return nil
	}
	a := fs.Args()
	if len(a) < 1 {
		return errors.New("regex required")
	}
	pat := a[0]
	if ic {
		pat = "(?i)" + pat
	}
	re, err := regexp.Compile(pat)
	if err != nil {
		return err
	}
	rows, err := readCSV(arg(a, 1), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	width := maxWidth(rows)
	var idx []int
	if sel != "" {
		idx, _ = parseSelection(sel, hdr, width)
	} else {
		for i := 0; i < width; i++ {
			idx = append(idx, i)
		}
	}
	out := [][]string{}
	for _, r := range data {
		m := false
		for _, j := range idx {
			if j < len(r) && re.MatchString(r[j]) {
				m = true
				break
			}
		}
		if m != inv {
			out = append(out, r)
		}
	}
	return writeRows(c.output, outRows(hdr, out), ',')
}
func cmdSort(args []string) error {
	c := common{delim: ','}
	sel := ""
	num := false
	rev := false
	fs := newFS("sort")
	addCommon(fs, &c, true, true)
	fs.StringVar(&sel, "select", "", "")
	fs.StringVar(&sel, "s", "", "")
	fs.BoolVar(&num, "numeric", false, "")
	fs.BoolVar(&num, "N", false, "")
	fs.BoolVar(&rev, "reverse", false, "")
	fs.BoolVar(&rev, "R", false, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv sort [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	width := maxWidth(rows)
	var idx []int
	if sel != "" {
		idx, _ = parseSelection(sel, hdr, width)
	} else {
		for i := 0; i < width; i++ {
			idx = append(idx, i)
		}
	}
	sort.SliceStable(data, func(i, j int) bool {
		cmp := compareRows(data[i], data[j], idx, num)
		if rev {
			return cmp > 0
		}
		return cmp < 0
	})
	return writeRows(c.output, outRows(hdr, data), ',')
}
func compareRows(a, b []string, idx []int, num bool) int {
	for _, k := range idx {
		av, bv := "", ""
		if k < len(a) {
			av = a[k]
		}
		if k < len(b) {
			bv = b[k]
		}
		var c int
		if num {
			af, _ := strconv.ParseFloat(av, 64)
			bf, _ := strconv.ParseFloat(bv, 64)
			if af < bf {
				c = -1
			} else if af > bf {
				c = 1
			}
		} else {
			if av < bv {
				c = -1
			} else if av > bv {
				c = 1
			}
		}
		if c != 0 {
			return c
		}
	}
	return 0
}
func cmdReverse(args []string) error {
	c := common{delim: ','}
	fs := newFS("reverse")
	addCommon(fs, &c, true, true)
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv reverse [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	for i, j := 0, len(data)-1; i < j; i, j = i+1, j-1 {
		data[i], data[j] = data[j], data[i]
	}
	return writeRows(c.output, outRows(hdr, data), ',')
}

func cmdFmt(args []string) error {
	c := common{delim: ','}
	out := ','
	crlf := false
	quoteAlways := false
	fs := newFS("fmt")
	addCommon(fs, &c, true, false)
	fs.Func("out-delimiter", "", func(s string) error { out = []rune(s)[0]; return nil })
	fs.Func("t", "", func(s string) error { out = []rune(s)[0]; return nil })
	fs.BoolVar(&crlf, "crlf", false, "")
	fs.BoolVar(&quoteAlways, "quote-always", false, "")
	fs.String("quote", "\"", "")
	fs.String("escape", "", "")
	fs.Bool("ascii", false, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv fmt [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	cw, done, err := writer(c.output, out)
	if err != nil {
		return err
	}
	cw.UseCRLF = crlf
	if quoteAlways { // encoding/csv cannot force quotes; manual
		done()
		return writeManual(c.output, rows, out, crlf, true)
	}
	defer done()
	for _, r := range rows {
		cw.Write(r)
	}
	return nil
}
func writeManual(path string, rows [][]string, delim rune, crlf, always bool) error {
	var w io.Writer = os.Stdout
	var f *os.File
	var err error
	if path != "" {
		f, err = os.Create(path)
		if err != nil {
			return err
		}
		defer f.Close()
		w = f
	}
	sep := string(delim)
	nl := "\n"
	if crlf {
		nl = "\r\n"
	}
	for _, r := range rows {
		for i, s := range r {
			if i > 0 {
				fmt.Fprint(w, sep)
			}
			if always || strings.ContainsAny(s, sep+"\n\r\"") {
				fmt.Fprint(w, "\""+strings.ReplaceAll(s, "\"", "\"\"")+"\"")
			} else {
				fmt.Fprint(w, s)
			}
		}
		fmt.Fprint(w, nl)
	}
	return nil
}
func cmdInput(args []string) error {
	c := common{delim: ','}
	fs := newFS("input")
	addCommon(fs, &c, true, false)
	fs.String("quote", "\"", "")
	fs.String("escape", "", "")
	fs.Bool("no-quoting", false, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv input [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	return writeRows(c.output, rows, ',')
}
func cmdFixLengths(args []string) error {
	c := common{delim: ','}
	l := 0
	fs := newFS("fixlengths")
	addCommon(fs, &c, true, false)
	fs.IntVar(&l, "length", 0, "")
	fs.IntVar(&l, "l", 0, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv fixlengths [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	if l <= 0 {
		for _, r := range rows {
			n := len(r)
			for n > 1 && r[n-1] == "" {
				n--
			}
			if n > l {
				l = n
			}
		}
		if l == 0 {
			l = 1
		}
	}
	for i, r := range rows {
		if len(r) > l {
			rows[i] = r[:l]
		} else if len(r) < l {
			nr := append([]string{}, r...)
			for len(nr) < l {
				nr = append(nr, "")
			}
			rows[i] = nr
		}
	}
	return writeRows(c.output, rows, ',')
}
func cmdFlatten(args []string) error {
	c := common{delim: ','}
	cond := 0
	sep := "#"
	fs := newFS("flatten")
	addCommon(fs, &c, false, true)
	fs.IntVar(&cond, "condense", 0, "")
	fs.IntVar(&cond, "c", 0, "")
	fs.StringVar(&sep, "separator", "#", "")
	fs.StringVar(&sep, "s", "#", "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv flatten [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	if hdr == nil {
		w := maxWidth(rows)
		for i := 0; i < w; i++ {
			hdr = append(hdr, strconv.Itoa(i+1))
		}
	}
	labelWidth := 0
	for _, h := range hdr {
		if len(h) > labelWidth {
			labelWidth = len(h)
		}
	}
	for ri, r := range data {
		for i, h := range hdr {
			v := ""
			if i < len(r) {
				v = r[i]
			}
			if cond > 0 && len([]rune(v)) > cond {
				rr := []rune(v)
				v = string(rr[:cond])
			}
			fmt.Printf("%-*s  %s\n", labelWidth, h, v)
		}
		if sep != "" && ri < len(data)-1 {
			fmt.Println(sep)
		}
	}
	return nil
}

func cmdFrequency(args []string) error {
	c := common{delim: ','}
	sel := ""
	limit := 10
	asc := false
	noNull := false
	fs := newFS("frequency")
	addCommon(fs, &c, true, true)
	fs.StringVar(&sel, "select", "", "")
	fs.StringVar(&sel, "s", "", "")
	fs.IntVar(&limit, "limit", 10, "")
	fs.IntVar(&limit, "l", 10, "")
	fs.BoolVar(&asc, "asc", false, "")
	fs.BoolVar(&asc, "a", false, "")
	fs.BoolVar(&noNull, "no-nulls", false, "")
	fs.Int("jobs", 0, "")
	fs.Int("j", 0, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv frequency [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	width := maxWidth(rows)
	var idx []int
	if sel != "" {
		idx, _ = parseSelection(sel, hdr, width)
	} else {
		for i := 0; i < width; i++ {
			idx = append(idx, i)
		}
	}
	out := [][]string{{"field", "value", "count"}}
	for _, j := range idx {
		m := map[string]int{}
		order := map[string]int{}
		for _, r := range data {
			v := ""
			if j < len(r) {
				v = r[j]
			}
			if noNull && v == "" {
				continue
			}
			if _, ok := order[v]; !ok {
				order[v] = len(order)
			}
			m[v]++
		}
		type kv struct {
			v string
			c int
		}
		arr := []kv{}
		for v, c := range m {
			arr = append(arr, kv{v, c})
		}
		sort.SliceStable(arr, func(a, b int) bool {
			if arr[a].c == arr[b].c {
				return order[arr[a].v] < order[arr[b].v]
			}
			if asc {
				return arr[a].c < arr[b].c
			}
			return arr[a].c > arr[b].c
		})
		name := strconv.Itoa(j + 1)
		if hdr != nil && j < len(hdr) {
			name = hdr[j]
		}
		for i, x := range arr {
			if limit > 0 && i >= limit {
				break
			}
			out = append(out, []string{name, x.v, strconv.Itoa(x.c)})
		}
	}
	return writeRows(c.output, out, ',')
}

type stat struct {
	vals           []float64
	strings        []string
	sum            float64
	count          int
	nulls          int
	minS, maxS     string
	minLen, maxLen int
	freq           map[string]int
	typ            string
}

func cmdStats(args []string) error {
	c := common{delim: ','}
	sel := ""
	everything := false
	modeF := false
	cardF := false
	medF := false
	nulls := false
	fs := newFS("stats")
	addCommon(fs, &c, true, true)
	fs.StringVar(&sel, "select", "", "")
	fs.StringVar(&sel, "s", "", "")
	fs.BoolVar(&everything, "everything", false, "")
	fs.BoolVar(&modeF, "mode", false, "")
	fs.BoolVar(&cardF, "cardinality", false, "")
	fs.BoolVar(&medF, "median", false, "")
	fs.BoolVar(&nulls, "nulls", false, "")
	fs.Int("jobs", 0, "")
	fs.Int("j", 0, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv stats [options] [<input>]\n")
		return nil
	}
	if everything {
		modeF = true
		cardF = true
		medF = true
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	width := maxWidth(rows)
	var idx []int
	if sel != "" {
		idx, _ = parseSelection(sel, hdr, width)
	} else {
		for i := 0; i < width; i++ {
			idx = append(idx, i)
		}
	}
	header := []string{"field", "type", "sum", "min", "max", "min_length", "max_length", "mean", "stddev"}
	if medF {
		header = append(header, "median")
	}
	if modeF {
		header = append(header, "mode")
	}
	if cardF {
		header = append(header, "cardinality")
	}
	out := [][]string{header}
	for _, j := range idx {
		st := calcStat(data, j, nulls)
		name := strconv.Itoa(j + 1)
		if hdr != nil && j < len(hdr) {
			name = hdr[j]
		}
		row := []string{name, st.typ, fmtNum(st.sum, st.count > 0 && st.typ != "Unicode"), st.minS, st.maxS, strconv.Itoa(st.minLen), strconv.Itoa(st.maxLen), "", ""}
		if st.typ != "Unicode" && st.count > 0 {
			mean := st.sum / float64(popCount(st, nulls))
			row[7] = fmtFloat(mean)
			row[8] = fmtFloat(stddev(st.vals, mean, nulls, st.nulls))
		}
		if medF {
			row = append(row, median(st.vals))
		}
		if modeF {
			row = append(row, mode(st.freq))
		}
		if cardF {
			row = append(row, strconv.Itoa(len(st.freq)))
		}
		out = append(out, row)
	}
	return writeRows(c.output, out, ',')
}
func calcStat(data [][]string, j int, nulls bool) stat {
	st := stat{freq: map[string]int{}, typ: "Integer"}
	firstLen := true
	firstVal := true
	allInt := true
	allFloat := true
	for _, r := range data {
		v := ""
		if j < len(r) {
			v = r[j]
		}
		st.freq[v]++
		l := len(v)
		if firstLen {
			st.minLen = l
			st.maxLen = l
			firstLen = false
		} else {
			if l < st.minLen {
				st.minLen = l
			}
			if l > st.maxLen {
				st.maxLen = l
			}
		}
		if v != "" {
			if firstVal {
				st.minS = v
				st.maxS = v
				firstVal = false
			} else {
				if v < st.minS {
					st.minS = v
				}
				if v > st.maxS {
					st.maxS = v
				}
			}
		}
		if v == "" {
			st.nulls++
			continue
		}
		f, err := strconv.ParseFloat(v, 64)
		if err != nil {
			allInt = false
			allFloat = false
		} else {
			st.vals = append(st.vals, f)
			st.sum += f
			st.count++
			if !isInt(v) {
				allInt = false
			}
		}
	}
	if !allFloat {
		st.typ = "Unicode"
	} else if allInt {
		st.typ = "Integer"
	} else {
		st.typ = "Float"
	}
	return st
}
func isInt(s string) bool { _, e := strconv.ParseInt(s, 10, 64); return e == nil }
func popCount(st stat, nulls bool) int {
	if nulls {
		return st.count + st.nulls
	}
	return st.count
}
func stddev(vals []float64, mean float64, nulls bool, nnull int) float64 {
	n := len(vals)
	if nulls {
		n += nnull
	}
	if n == 0 {
		return 0
	}
	ss := 0.0
	for _, v := range vals {
		d := v - mean
		ss += d * d
	}
	if nulls {
		d := 0 - mean
		ss += float64(nnull) * d * d
	}
	return math.Sqrt(ss / float64(n))
}
func median(vals []float64) string {
	if len(vals) == 0 {
		return ""
	}
	v := append([]float64{}, vals...)
	sort.Float64s(v)
	n := len(v)
	if n%2 == 1 {
		return fmtFloat(v[n/2])
	}
	return fmtFloat((v[n/2-1] + v[n/2]) / 2)
}
func mode(m map[string]int) string {
	best := ""
	bc := -1
	for v, c := range m {
		if c > bc || (c == bc && v < best) {
			best = v
			bc = c
		}
	}
	return best
}
func fmtNum(f float64, ok bool) string {
	if !ok {
		return ""
	}
	return fmtFloat(f)
}
func fmtFloat(f float64) string {
	if math.IsNaN(f) || math.IsInf(f, 0) {
		return ""
	}
	return strconv.FormatFloat(f, 'f', -1, 64)
}

func cmdTable(args []string) error {
	c := common{delim: ','}
	width := 2
	pad := 2
	cond := 0
	fs := newFS("table")
	addCommon(fs, &c, true, false)
	fs.IntVar(&width, "width", 2, "")
	fs.IntVar(&width, "w", 2, "")
	fs.IntVar(&pad, "pad", 2, "")
	fs.IntVar(&pad, "p", 2, "")
	fs.IntVar(&cond, "condense", 0, "")
	fs.IntVar(&cond, "c", 0, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv table [options] [<input>]\n")
		return nil
	}
	rows, err := readCSV(first(fs.Args()), c.delim)
	if err != nil {
		return err
	}
	for i, r := range rows {
		for j, v := range r {
			if cond > 0 && len([]rune(v)) > cond {
				rows[i][j] = string([]rune(v)[:cond])
			}
		}
	}
	cols := maxWidth(rows)
	w := make([]int, cols)
	for i := range w {
		w[i] = width
	}
	for _, r := range rows {
		for i, v := range r {
			if len(v) > w[i] {
				w[i] = len(v)
			}
		}
	}
	for _, r := range rows {
		for i := 0; i < cols; i++ {
			v := ""
			if i < len(r) {
				v = r[i]
			}
			if i == cols-1 {
				fmt.Print(v)
			} else {
				fmt.Printf("%-*s%s", w[i], v, strings.Repeat(" ", pad))
			}
		}
		fmt.Println()
	}
	return nil
}

func cmdCat(args []string) error {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		fmt.Print("Usage:\n    xsv cat rows    [options] [<input>...]\n    xsv cat columns [options] [<input>...]\n")
		return nil
	}
	mode := args[0]
	c := common{delim: ','}
	pad := false
	fs := newFS("cat")
	addCommon(fs, &c, true, true)
	fs.BoolVar(&pad, "pad", false, "")
	fs.BoolVar(&pad, "p", false, "")
	fs.Parse(args[1:])
	files := fs.Args()
	if mode == "rows" {
		var out [][]string
		for fi, f := range files {
			rows, e := readCSV(f, c.delim)
			if e != nil {
				return e
			}
			if c.noHeaders || fi == 0 {
				out = append(out, rows...)
			} else if len(rows) > 1 {
				out = append(out, rows[1:]...)
			}
		}
		return writeRows(c.output, out, ',')
	}
	if mode == "columns" {
		sets := [][][]string{}
		max := 0
		min := int(^uint(0) >> 1)
		for _, f := range files {
			r, e := readCSV(f, c.delim)
			if e != nil {
				return e
			}
			sets = append(sets, r)
			if len(r) > max {
				max = len(r)
			}
			if len(r) < min {
				min = len(r)
			}
		}
		n := min
		if pad {
			n = max
		}
		out := [][]string{}
		for i := 0; i < n; i++ {
			var row []string
			for _, s := range sets {
				if i < len(s) {
					row = append(row, s[i]...)
				} else {
					mw := maxWidth(s)
					for k := 0; k < mw; k++ {
						row = append(row, "")
					}
				}
			}
			out = append(out, row)
		}
		return writeRows(c.output, out, ',')
	}
	return errors.New("expected rows or columns")
}
func cmdJoin(args []string) error {
	c := common{delim: ','}
	left, right, full, cross, nocase, nulls := false, false, false, false, false, false
	fs := newFS("join")
	addCommon(fs, &c, true, true)
	fs.BoolVar(&left, "left", false, "")
	fs.BoolVar(&right, "right", false, "")
	fs.BoolVar(&full, "full", false, "")
	fs.BoolVar(&cross, "cross", false, "")
	fs.BoolVar(&nocase, "no-case", false, "")
	fs.BoolVar(&nulls, "nulls", false, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv join [options] <columns1> <input1> <columns2> <input2>\n")
		return nil
	}
	a := fs.Args()
	if len(a) < 4 {
		return errors.New("join requires columns1 input1 columns2 input2")
	}
	r1, e := readCSV(a[1], c.delim)
	if e != nil {
		return e
	}
	r2, e := readCSV(a[3], c.delim)
	if e != nil {
		return e
	}
	h1, d1 := splitHeader(r1, c.noHeaders)
	h2, d2 := splitHeader(r2, c.noHeaders)
	w1, w2 := maxWidth(r1), maxWidth(r2)
	idx1, _ := parseSelection(a[0], h1, w1)
	idx2, _ := parseSelection(a[2], h2, w2)
	out := [][]string{}
	if h1 != nil || h2 != nil {
		out = append(out, append(append([]string{}, h1...), h2...))
	}
	if cross {
		for _, x := range d1 {
			for _, y := range d2 {
				out = append(out, appendRows(x, y, w1, w2))
			}
		}
		return writeRows(c.output, out, ',')
	}
	m := map[string][]int{}
	for i, r := range d2 {
		k := key(r, idx2, nocase)
		if k == "" && !nulls {
			continue
		}
		m[k] = append(m[k], i)
	}
	matched := map[int]bool{}
	for _, r := range d1 {
		k := key(r, idx1, nocase)
		hits := m[k]
		if k == "" && !nulls {
			hits = nil
		}
		if len(hits) == 0 {
			if left || full {
				out = append(out, appendRows(r, nil, w1, w2))
			}
			continue
		}
		for _, hi := range hits {
			matched[hi] = true
			out = append(out, appendRows(r, d2[hi], w1, w2))
		}
	}
	if right || full {
		for i, r := range d2 {
			if !matched[i] {
				out = append(out, appendRows(nil, r, w1, w2))
			}
		}
	}
	return writeRows(c.output, out, ',')
}
func key(r []string, idx []int, nocase bool) string {
	parts := []string{}
	for _, i := range idx {
		v := ""
		if i < len(r) {
			v = strings.TrimSpace(r[i])
		}
		if nocase {
			v = strings.ToLower(v)
		}
		parts = append(parts, v)
	}
	return strings.Join(parts, "\x00")
}
func appendRows(a, b []string, w1, w2 int) []string {
	row := []string{}
	for i := 0; i < w1; i++ {
		if i < len(a) {
			row = append(row, a[i])
		} else {
			row = append(row, "")
		}
	}
	for i := 0; i < w2; i++ {
		if i < len(b) {
			row = append(row, b[i])
		} else {
			row = append(row, "")
		}
	}
	return row
}
func cmdSample(args []string) error {
	c := common{delim: ','}
	seed := int64(0)
	hasSeed := false
	fs := newFS("sample")
	addCommon(fs, &c, true, true)
	fs.Func("seed", "", func(s string) error { n, e := strconv.ParseInt(s, 10, 64); seed = n; hasSeed = true; return e })
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv sample [options] <sample-size> [<input>]\n")
		return nil
	}
	a := fs.Args()
	if len(a) < 1 {
		return errors.New("sample size required")
	}
	n := atoi(a[0])
	rows, e := readCSV(arg(a, 1), c.delim)
	if e != nil {
		return e
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	rng := rand.New(rand.NewSource(seed))
	if !hasSeed {
		rng = rand.New(rand.NewSource(1))
	}
	perm := rng.Perm(len(data))
	if n > len(data) {
		n = len(data)
	}
	sel := [][]string{}
	chosen := perm[:n]
	sort.Ints(chosen)
	for _, i := range chosen {
		sel = append(sel, data[i])
	}
	return writeRows(c.output, outRows(hdr, sel), ',')
}
func cmdSplit(args []string) error {
	c := common{delim: ','}
	size := 500
	tmpl := "{}.csv"
	fs := newFS("split")
	addCommon(fs, &c, false, true)
	fs.IntVar(&size, "size", 500, "")
	fs.IntVar(&size, "s", 500, "")
	fs.StringVar(&tmpl, "filename", "{}.csv", "")
	fs.Int("jobs", 0, "")
	fs.Int("j", 0, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv split [options] <outdir> [<input>]\n")
		return nil
	}
	a := fs.Args()
	if len(a) < 1 {
		return errors.New("outdir required")
	}
	rows, e := readCSV(arg(a, 1), c.delim)
	if e != nil {
		return e
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	os.MkdirAll(a[0], 0755)
	for start := 0; start < len(data); start += size {
		end := start + size
		if end > len(data) {
			end = len(data)
		}
		name := strings.ReplaceAll(tmpl, "{}", strconv.Itoa(start))
		writeRows(filepath.Join(a[0], name), outRows(hdr, data[start:end]), ',')
	}
	return nil
}
func cmdPartition(args []string) error {
	c := common{delim: ','}
	tmpl := "{}.csv"
	drop := false
	pref := 0
	fs := newFS("partition")
	addCommon(fs, &c, false, true)
	fs.StringVar(&tmpl, "filename", "{}.csv", "")
	fs.BoolVar(&drop, "drop", false, "")
	fs.IntVar(&pref, "prefix-length", 0, "")
	fs.IntVar(&pref, "p", 0, "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv partition [options] <column> <outdir> [<input>]\n")
		return nil
	}
	a := fs.Args()
	if len(a) < 2 {
		return errors.New("column and outdir required")
	}
	rows, e := readCSV(arg(a, 2), c.delim)
	if e != nil {
		return e
	}
	hdr, data := splitHeader(rows, c.noHeaders)
	idx := colIndex(a[0], hdr, maxWidth(rows))
	os.MkdirAll(a[1], 0755)
	buckets := map[string][][]string{}
	for _, r := range data {
		v := ""
		if idx < len(r) && idx >= 0 {
			v = r[idx]
		}
		if pref > 0 && len(v) > pref {
			v = v[:pref]
		}
		rr := r
		if drop {
			rr = dropCol(r, idx)
		}
		buckets[v] = append(buckets[v], rr)
	}
	oh := hdr
	if drop {
		oh = dropCol(hdr, idx)
	}
	for v, b := range buckets {
		name := strings.ReplaceAll(tmpl, "{}", sanitize(v))
		writeRows(filepath.Join(a[1], name), outRows(oh, b), ',')
	}
	return nil
}
func sanitize(s string) string {
	if s == "" {
		return "empty"
	}
	re := regexp.MustCompile(`[^A-Za-z0-9._-]+`)
	return re.ReplaceAllString(s, "_")
}
func dropCol(r []string, i int) []string {
	out := []string{}
	for j, v := range r {
		if j != i {
			out = append(out, v)
		}
	}
	return out
}
func cmdIndex(args []string) error {
	c := common{delim: ','}
	out := ""
	fs := newFS("index")
	addCommon(fs, &c, false, false)
	fs.StringVar(&out, "output", "", "")
	fs.StringVar(&out, "o", "", "")
	if parse(fs, args) {
		fmt.Print("Usage:\n    xsv index [options] <input>\n")
		return nil
	}
	in := first(fs.Args())
	if in == "" {
		return errors.New("input required")
	}
	if out == "" {
		out = in + ".idx"
	}
	rows, e := readCSV(in, c.delim)
	if e != nil {
		return e
	}
	return os.WriteFile(out, []byte(fmt.Sprintf("xsv-index\n%d\n", len(rows))), 0644)
}
