module xsvclone

go 1.21
