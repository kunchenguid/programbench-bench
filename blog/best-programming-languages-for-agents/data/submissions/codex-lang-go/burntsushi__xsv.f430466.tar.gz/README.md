# xsv - CSV Command Line Toolkit

**Note:** xsv is now unmaintained. Consider using [qsv](https://github.com/dathere/qsv) or [xan](https://github.com/medialab/xan) as alternatives.

## Overview

xsv is a command line program for indexing, slicing, analyzing, splitting and joining CSV files. Commands are designed to be simple, fast and composable.

## Available Commands

* **cat** - Concatenate CSV files by row or by column.
* **count** - Count the rows in a CSV file. (Instantaneous with an index.)
* **fixlengths** - Force a CSV file to have same-length records by either padding or truncating them.
* **flatten** - A flattened view of CSV records. Useful for viewing one record at a time. e.g., `xsv slice -i 5 data.csv | xsv flatten`.
* **fmt** - Reformat CSV data with different delimiters, record terminators or quoting rules. (Supports ASCII delimited data.)
* **frequency** - Build frequency tables of each column in CSV data. (Uses parallelism to go faster if an index is present.)
* **headers** - Show the headers of CSV data. Or show the intersection of all headers between many CSV files.
* **index** - Create an index for a CSV file. This is very quick and provides constant time indexing into the CSV file.
* **input** - Read CSV data with exotic quoting/escaping rules.
* **join** - Inner, outer and cross joins. Uses a simple hash index to make it fast.
* **partition** - Partition CSV data based on a column value.
* **sample** - Randomly draw rows from CSV data using reservoir sampling (i.e., use memory proportional to the size of the sample).
* **reverse** - Reverse order of rows in CSV data.
* **search** - Run a regex over CSV data. Applies the regex to each field individually and shows only matching rows.
* **select** - Select or re-order columns from CSV data.
* **slice** - Slice rows from any part of a CSV file. When an index is present, this only has to parse the rows in the slice (instead of all rows leading up to the start of the slice).
* **sort** - Sort CSV data.
* **split** - Split one CSV file into many CSV files of N chunks.
* **stats** - Show basic types and statistics of each column in the CSV file. (i.e., mean, standard deviation, median, range, etc.)
* **table** - Show aligned output of any CSV data using elastic tabstops.

## Usage Examples

### Viewing CSV Headers

```bash
$ xsv headers worldcitiespop.csv
1   Country
2   City
3   AccentCity
4   Region
5   Population
6   Latitude
7   Longitude
```

### Statistics Overview

Get an overview of data in each column:

```bash
$ xsv stats worldcitiespop.csv --everything | xsv table
```

### Selecting Columns

Select specific columns from a CSV file:

```bash
$ xsv select Country,AccentCity,Population worldcitiespop.csv | xsv table
```

### Searching with Regex

Search for rows matching a pattern:

```bash
$ xsv search -s Country '^US$' worldcitiespop.csv | xsv table
```

### Frequency Analysis

Build a frequency table for a column:

```bash
$ xsv frequency -s Country worldcitiespop.csv | xsv table
```

### Sampling Data

Randomly sample rows from a CSV file:

```bash
$ xsv sample 10 worldcitiespop.csv
```

### Sorting Data

Sort CSV data by a specific column:

```bash
$ xsv sort -s Population worldcitiespop.csv
```

### Joining CSV Files

Join two CSV files on a common column:

```bash
$ xsv join Country file1.csv Country file2.csv
```

### Slicing Rows

Extract specific rows from a CSV file:

```bash
$ xsv slice -s 10 -e 20 worldcitiespop.csv
```

### Counting Rows

Count the number of rows (extremely fast with an index):

```bash
$ xsv count worldcitiespop.csv
```

### Creating an Index

Create an index for faster operations:

```bash
$ xsv index worldcitiespop.csv
```

## License

Dual-licensed under MIT or the UNLICENSE.
