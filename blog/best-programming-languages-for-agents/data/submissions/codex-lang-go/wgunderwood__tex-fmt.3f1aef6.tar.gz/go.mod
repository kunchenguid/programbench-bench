module texfmtclone

go 1.21
