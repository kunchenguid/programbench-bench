package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const version = "0.5.6"

type Config struct {
	CliSet       map[string]bool
	Check        bool
	Print        bool
	FailOnChange bool
	Wrap         bool
	WrapLen      int
	WrapMin      int
	TabSize      int
	TabChar      string
	Stdin        bool
	ConfigPath   string
	NoConfig     bool
	Verbosity    string
	Recursive    bool
	Lists        []string
	Verbatims    []string
	NoIndentEnvs []string
	WrapChars    []string
	Files        []string
}

func defaultConfig() Config {
	return Config{CliSet: map[string]bool{}, Wrap: true, WrapLen: 80, WrapMin: 70, TabSize: 2, TabChar: "space", Verbosity: "warn",
		Lists: []string{"itemize", "enumerate", "description", "inlineroman", "inventory"},
		Verbatims: []string{"verbatim", "Verbatim", "lstlisting", "minted", "comment"},
		NoIndentEnvs: []string{"document"},
	}
}

func main() {
	cfg, special, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(2)
	}
	if special != "" {
		handleSpecial(special, cfg)
		return
	}
	if !cfg.NoConfig {
		loadConfig(&cfg)
	}
	if cfg.Stdin {
		b, _ := io.ReadAll(os.Stdin)
		fmt.Print(formatString(string(b), cfg))
		return
	}
	files := append([]string{}, cfg.Files...)
	if cfg.Recursive {
		roots := files
		if len(roots) == 0 { roots = []string{"."} }
		files = collectFiles(roots)
	}
	if len(files) == 0 {
		logErr(cfg, "", "No files specified. Provide filenames, or pass --recursive or --stdin.")
		os.Exit(1)
	}
	status := 0
	for _, f := range files {
		if cfg.Verbosity == "info" || cfg.Verbosity == "trace" { fmt.Fprintf(os.Stderr, "INFO: tex-fmt %s: Formatting started. \n", f) }
		b, err := os.ReadFile(f)
		if err != nil { logErr(cfg, f, "Could not open file."); status = 1; continue }
		out := formatString(string(b), cfg)
		changed := out != string(b)
		if cfg.Print { fmt.Print(out) }
		if cfg.Check {
			if changed { logErr(cfg, f, "Incorrect formatting."); status = 1 }
		} else if !cfg.Print {
			if changed {
				_ = os.WriteFile(f, []byte(out), 0644)
				if cfg.FailOnChange { status = 1 }
			}
		} else if cfg.FailOnChange && changed { status = 1 }
		if cfg.Verbosity == "info" || cfg.Verbosity == "trace" { fmt.Fprintf(os.Stderr, "INFO: tex-fmt %s: Formatting complete. \n", f) }
	}
	os.Exit(status)
}

func parseArgs(args []string) (Config, string, error) {
	cfg := defaultConfig()
	special := ""
	cliSet := map[string]bool{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help": return cfg, "help", nil
		case "-V", "--version": return cfg, "version", nil
		case "--man": return cfg, "man", nil
		case "--args": special = "args"
		case "-c", "--check": cfg.Check = true; cliSet["check"] = true
		case "-p", "--print": cfg.Print = true; cliSet["print"] = true
		case "-f", "--fail-on-change": cfg.FailOnChange = true; cliSet["fail"] = true
		case "-n", "--nowrap": cfg.Wrap = false; cliSet["wrap"] = true
		case "-s", "--stdin": cfg.Stdin = true; cliSet["stdin"] = true
		case "-r", "--recursive": cfg.Recursive = true
		case "--usetabs": cfg.TabChar = "tab"; cliSet["tabchar"] = true
		case "-v", "--verbose": cfg.Verbosity = "info"; cliSet["verbosity"] = true
		case "-q", "--quiet": cfg.Verbosity = "error"; cliSet["verbosity"] = true
		case "--trace": cfg.Verbosity = "trace"; cliSet["verbosity"] = true
		case "--noconfig": cfg.NoConfig = true
		case "-l", "--wraplen":
			i++; if i>=len(args) { return cfg, special, errors.New("error: a value is required for '--wraplen <N>'") }
			cfg.WrapLen = atoi(args[i], 80); cliSet["wraplen"] = true
		case "-t", "--tabsize":
			i++; if i>=len(args) { return cfg, special, errors.New("error: a value is required for '--tabsize <N>'") }
			cfg.TabSize = atoi(args[i], 2); cliSet["tabsize"] = true
		case "--config":
			i++; if i>=len(args) { return cfg, special, errors.New("error: a value is required for '--config <PATH>'") }
			cfg.ConfigPath = args[i]
		case "--completion":
			i++; if i>=len(args) { return cfg, special, errors.New("error: a value is required for '--completion <SHELL>'") }
			special = "completion:" + args[i]
		default:
			if strings.HasPrefix(a, "-") { return cfg, special, fmt.Errorf("error: unexpected argument '%s' found", a) }
			cfg.Files = append(cfg.Files, a)
		}
	}
	cfg.CliSet = cliSet
	return cfg, special, nil
}

func loadConfig(cfg *Config) {
	path := cfg.ConfigPath
	if path == "" {
		if _, err := os.Stat("tex-fmt.toml"); err == nil { path = "tex-fmt.toml" }
	}
	if path == "" { return }
	data, err := os.ReadFile(path); if err != nil { return }
	cfg.ConfigPath = path
	for _, raw := range strings.Split(string(data), "\n") {
		line := stripTomlComment(strings.TrimSpace(raw)); if line == "" || !strings.Contains(line, "=") { continue }
		parts := strings.SplitN(line, "=", 2); key := strings.TrimSpace(parts[0]); val := strings.TrimSpace(parts[1])
		switch key {
		case "check": if !cfg.CliSet["check"] { cfg.Check = parseBool(val) }
		case "print": if !cfg.CliSet["print"] { cfg.Print = parseBool(val) }
		case "fail-on-change": if !cfg.CliSet["fail"] { cfg.FailOnChange = parseBool(val) }
		case "wrap": if !cfg.CliSet["wrap"] { cfg.Wrap = parseBool(val) }
		case "wraplen": if !cfg.CliSet["wraplen"] { cfg.WrapLen = atoi(val, cfg.WrapLen) }
		case "wrapmin": cfg.WrapMin = atoi(val, cfg.WrapMin)
		case "tabsize": if !cfg.CliSet["tabsize"] { cfg.TabSize = atoi(val, cfg.TabSize) }
		case "tabchar": if !cfg.CliSet["tabchar"] { cfg.TabChar = unquote(val) }
		case "stdin": if !cfg.CliSet["stdin"] { cfg.Stdin = parseBool(val) }
		case "verbosity": if !cfg.CliSet["verbosity"] { cfg.Verbosity = unquote(val) }
		case "lists": cfg.Lists = append(parseArray(val), cfg.Lists...)
		case "verbatims": cfg.Verbatims = append(parseArray(val), cfg.Verbatims...)
		case "no-indent-envs": cfg.NoIndentEnvs = append(parseArray(val), cfg.NoIndentEnvs...)
		case "wrap-chars": cfg.WrapChars = parseArray(val)
		}
	}
}

func stripTomlComment(s string) string { if i:=strings.Index(s,"#"); i>=0 { return strings.TrimSpace(s[:i]) }; return s }
func parseBool(s string) bool { return strings.TrimSpace(s) == "true" }
func unquote(s string) string { s=strings.TrimSpace(s); s=strings.Trim(s, "\""); return s }
func atoi(s string, d int) int { n, err := strconv.Atoi(strings.Trim(strings.TrimSpace(s), "\"")); if err!=nil { return d }; return n }
func parseArray(s string) []string { s=strings.TrimSpace(s); s=strings.TrimPrefix(s,"["); s=strings.TrimSuffix(s,"]"); if strings.TrimSpace(s)=="" { return nil }; var out []string; for _,p:= range strings.Split(s,",") { v:=unquote(strings.TrimSpace(p)); if v!="" { out=append(out,v) } }; return out }

func handleSpecial(s string, cfg Config) {
	switch {
	case s == "help": printHelp()
	case s == "version": fmt.Println("tex-fmt " + version)
	case s == "man": printMan()
	case s == "args": loadConfig(&cfg); printArgs(cfg)
	case strings.HasPrefix(s, "completion:"):
		fmt.Println("# completion script for tex-fmt")
		fmt.Println("complete -W '--check --print --fail-on-change --nowrap --wraplen --tabsize --usetabs --stdin --config --noconfig --verbose --quiet --trace --completion --man --args --recursive --help --version' tex-fmt executable")
	}
}

func printHelp() { fmt.Print(`tex-fmt 0.5.6

LaTeX formatter written in Rust

Usage: executable [OPTIONS] [files]...

Arguments:
  [files]...  List of files to be formatted

Options:
  -c, --check               Check formatting, do not modify files
  -p, --print               Print to stdout, do not modify files
  -f, --fail-on-change      Format files and return non-zero exit code if files are modified
  -n, --nowrap              Do not wrap long lines
  -l, --wraplen <N>         Line length for wrapping [default: 80]
  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
      --usetabs             Use tabs instead of spaces for indentation
  -s, --stdin               Process stdin as a single file, output to stdout
      --config <PATH>       Path to config file
      --noconfig            Do not read any config file
  -v, --verbose             Show info messages
  -q, --quiet               Hide warning messages
      --trace               Show trace messages
      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
      --man                 Generate man page
      --args                Print arguments passed to tex-fmt and exit
  -r, --recursive           Recursively search for files to format
  -h, --help                Print help
  -V, --version             Print version
`) }

func printMan() { fmt.Printf(".TH tex-fmt 1  \"tex-fmt %s\" \n.SH NAME\ntex\\-fmt \\- LaTeX formatter written in Rust\n.SH SYNOPSIS\ntex-fmt [OPTIONS] [files]\n.SH VERSION\nv%s\n", version, version) }

func printArgs(c Config) {
	fmt.Println("tex-fmt")
	fmt.Printf("  check:                   %v\n", c.Check)
	fmt.Printf("  print:                   %v\n", c.Print)
	fmt.Printf("  fail-on-change:          %v\n", c.FailOnChange)
	fmt.Printf("  wrap:                    %v\n", c.Wrap)
	fmt.Printf("  wraplen:                 %d\n", c.WrapLen)
	fmt.Printf("  wrapmin:                 %d\n", c.WrapMin)
	fmt.Printf("  tabsize:                 %d\n", c.TabSize)
	fmt.Printf("  tabchar:                 %s\n", c.TabChar)
	fmt.Printf("  stdin:                   %v\n", c.Stdin)
	if c.ConfigPath=="" { fmt.Println("  config:                  None") } else { fmt.Println("  config:                  "+c.ConfigPath) }
	fmt.Printf("  verbosity:               %s\n", mapVerb(c.Verbosity))
	printList("lists", c.Lists); printList("verbatims", c.Verbatims); printList("no-indent-envs", c.NoIndentEnvs); printList("wrap-chars", c.WrapChars); printList("files", c.Files)
}
func mapVerb(v string) string { if v=="info" {return "info"}; if v=="trace" {return "trace"}; if v=="error" {return "error"}; return "warn" }
func printList(name string, xs []string) { fmt.Printf("  %-25s", name+":"); if len(xs)==0 { fmt.Println(" "); return }; fmt.Println(xs[0]); for _,x:= range xs[1:] { fmt.Printf("                           %s\n", x) } }
func logErr(c Config, file, msg string) { if c.Verbosity != "error" { fmt.Fprintf(os.Stderr, "ERROR: tex-fmt %s: %s \n", file, msg) } }

func collectFiles(roots []string) []string {
	var out []string
	for _, root := range roots { filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error { if err!=nil { return nil }; if d.IsDir() { if d.Name()==".git" || d.Name()=="target" { return filepath.SkipDir }; return nil }; ext:=strings.ToLower(filepath.Ext(path)); if ext==".tex" || ext==".bib" || ext==".cls" || ext==".sty" { out=append(out,path) }; return nil }) }
	return out
}

type state struct { indent int; listDepth int; verbatim string; off bool }

func formatString(input string, cfg Config) string {
	input = strings.ReplaceAll(input, "\r\n", "\n")
	hasFinal := strings.HasSuffix(input, "\n")
	scanner := bufio.NewScanner(strings.NewReader(input)); scanner.Buffer(make([]byte, 1024), 1024*1024*10)
	st := state{}
	var out []string
	for scanner.Scan() {
		orig := scanner.Text()
		trim := strings.TrimSpace(orig)
		if strings.Contains(orig, "% tex-fmt: skip") { out = append(out, orig); continue }
		if strings.Contains(orig, "% tex-fmt: off") { st.off = true; out = append(out, orig); continue }
		if strings.Contains(orig, "% tex-fmt: on") { st.off = false; out = append(out, orig); continue }
		if st.off { out=append(out, orig); continue }
		if st.verbatim != "" {
			out = append(out, orig)
			if isEndEnv(trim, st.verbatim) { st.verbatim = "" }
			continue
		}
		if trim == "" { out = append(out, ""); continue }
		endingList := false
		if env, ok := endEnvName(trim); ok && contains(cfg.Lists, env) && st.listDepth > 0 {
			endingList = true
			st.listDepth--
		}
		preDedent := shouldDedent(trim, cfg)
		if preDedent && st.indent > 0 { st.indent-- }
		level := st.indent + 2*st.listDepth
		if !endingList && st.listDepth > 0 && strings.HasPrefix(trim, `\item`) { level = st.indent + 2*st.listDepth - 1 }
		line := indentString(level, cfg) + trim
		if cfg.Wrap { out = append(out, wrapLine(line, level, cfg)...)} else { out=append(out,line) }
		if env, ok := beginEnv(trim); ok {
			if contains(cfg.Verbatims, env) { st.verbatim = env } else if contains(cfg.Lists, env) { st.listDepth++ } else if !contains(cfg.NoIndentEnvs, env) { st.indent++ }
		} else if isOpenMath(trim) || opensBrace(trim) || opensBib(trim) { st.indent++
		} else if isEndAny(trim) {
			// end handled before formatting for indentation
		}
		if postDedent(trim) && st.indent > 0 { st.indent-- }
	}
	res := strings.Join(out, "\n")
	if hasFinal || input=="" { res += "\n" }
	return res
}

func indentString(level int, cfg Config) string { if level<0 {level=0}; if cfg.TabChar=="tab" { return strings.Repeat("\t", level) }; return strings.Repeat(" ", level*cfg.TabSize) }
func contains(xs []string, s string) bool { for _,x:= range xs { if x==s {return true} }; return false }
func beginEnv(s string) (string,bool) { if !strings.HasPrefix(s, `\begin{`) { return "",false }; rest:=strings.TrimPrefix(s, `\begin{`); i:=strings.Index(rest,"}"); if i<0 {return "",false}; return rest[:i], true }
func isEndEnv(s, env string) bool { return strings.HasPrefix(s, `\end{`+env+`}`) }
func isEndAny(s string) bool { return strings.HasPrefix(s, `\end{`) }
func shouldDedent(s string, cfg Config) bool { if strings.HasPrefix(s, `\end{`) { if env,ok:=endEnvName(s); ok && !contains(cfg.NoIndentEnvs, env) { return true } }; return s=="}" || strings.HasPrefix(s, `\]`) || strings.HasPrefix(s, `\)`) || strings.HasPrefix(s, `\right`) }
func endEnvName(s string) (string,bool) { rest:=strings.TrimPrefix(s, `\end{`); if rest==s { return "",false }; i:=strings.Index(rest,"}"); if i<0 {return "",false}; return rest[:i],true }
func isOpenMath(s string) bool { return s==`\[` || s==`\(` || strings.HasPrefix(s, `\left`) }
func opensBrace(s string) bool { return s=="{" }
func postDedent(s string) bool { return false }

func wrapLine(line string, level int, cfg Config) []string {
	limit := cfg.WrapMin; if limit <= 0 { limit = cfg.WrapLen }; if limit <= 0 { limit = 80 }
	if len([]rune(line)) <= limit { return []string{line} }
	trim := strings.TrimLeft(line, " \t")
	prefix := line[:len(line)-len(trim)]
	comment := strings.HasPrefix(trim, "%")
	if strings.HasPrefix(trim, `\begin`) || strings.HasPrefix(trim, `\end`) || strings.HasPrefix(trim, `\item`) && !strings.Contains(trim," ") { return []string{line} }
	words := strings.Fields(trim)
	if len(words) < 2 { return []string{line} }
	var out []string
	curPrefix := prefix
	if comment { curPrefix = prefix + "% "; if len(words)>0 && words[0]=="%" { words=words[1:] } }
	cur := curPrefix
	for _, w := range words {
		if cur == curPrefix { cur += w; continue }
		if len([]rune(cur))+1+len([]rune(w)) > limit {
			out = append(out, cur)
			if comment { cur = curPrefix + w } else { cur = prefix + w }
		} else { cur += " " + w }
	}
	if cur != curPrefix { out=append(out, cur) }
	return out
}

func opensBib(s string) bool { return strings.HasPrefix(s, "@") && strings.Contains(s, "{") && strings.Count(s, "{") > strings.Count(s, "}") }
