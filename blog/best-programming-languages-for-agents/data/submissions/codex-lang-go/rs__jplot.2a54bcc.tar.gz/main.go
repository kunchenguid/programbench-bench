package main

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"net/http"
	"os"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const usageText = `Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:

OPTIONS:
  -interval duration
    	When url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)
  -rows int
    	Limits the height of the graph output.
  -steps int
    	Number of values to plot. (default 100)
  -url string
    	URL to fetch every second. Read JSON objects from stdin if not specified.

FIELD_SPEC: [<option>[,<option>...]:]path
  option:
    - counter: Computes the difference with the last value. The value must increase monotonically.
    - marker: When the value is none-zero, a vertical line is drawn.
  path:
    JSON field path (eg: field.sub-field).
`

const terminalRequired = "jplot:  iTerm2, Kitty, or DRCS Sixel graphics required\n"

type options struct {
	interval time.Duration
	rows     int
	steps    int
	url      string
}

type field struct {
	path    string
	counter bool
	marker  bool
	last    float64
	seen    bool
}

type group struct {
	fields []field
}

func main() {
	iterm := os.Getenv("TERM_PROGRAM") == "iTerm.app"
	if !iterm {
		fmt.Fprint(os.Stdout, "\x1b[c")
	}

	opts, specs, code := parseFlags(os.Args[1:])
	if code >= 0 {
		if code == 0 && isHelp(os.Args[1:]) {
			os.Exit(0)
		}
		os.Exit(code)
	}

	if !iterm {
		fmt.Fprint(os.Stdout, terminalRequired)
		os.Exit(1)
	}
	if _, _, err := termSize(os.Stdout.Fd()); err != nil {
		fmt.Fprintf(os.Stdout, "jplot:  Cannot get window size:  %v\n", err)
		os.Exit(1)
	}

	groups := parseSpecs(specs)
	if len(groups) == 0 {
		os.Exit(0)
	}
	if err := run(opts, groups); err != nil {
		fmt.Fprintf(os.Stdout, "jplot:  %v\n", err)
		os.Exit(1)
	}
}

func parseFlags(args []string) (options, []string, int) {
	var opts options
	fs := flag.NewFlagSet("jplot", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	fs.DurationVar(&opts.interval, "interval", time.Second, "")
	fs.IntVar(&opts.rows, "rows", 0, "")
	fs.IntVar(&opts.steps, "steps", 100, "")
	fs.StringVar(&opts.url, "url", "", "")
	fs.Usage = func() { fmt.Fprint(os.Stderr, usageText) }
	err := fs.Parse(args)
	if err != nil {
		if err == flag.ErrHelp {
			return opts, nil, 0
		}
		return opts, nil, 2
	}
	return opts, fs.Args(), -1
}

func isHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "-help" || a == "--help" {
			return true
		}
	}
	return false
}

func parseSpecs(args []string) []group {
	groups := make([]group, 0, len(args))
	for _, arg := range args {
		if arg == "" {
			continue
		}
		parts := strings.Split(arg, "+")
		g := group{fields: make([]field, 0, len(parts))}
		for _, p := range parts {
			if p == "" {
				continue
			}
			f := field{path: p}
			if i := strings.IndexByte(p, ':'); i >= 0 {
				for _, opt := range strings.Split(p[:i], ",") {
					switch opt {
					case "counter":
						f.counter = true
					case "marker":
						f.marker = true
					}
				}
				f.path = p[i+1:]
			}
			g.fields = append(g.fields, f)
		}
		groups = append(groups, g)
	}
	return groups
}

func run(opts options, groups []group) error {
	if opts.url != "" {
		tick := time.NewTicker(opts.interval)
		defer tick.Stop()
		for {
			if err := fetchAndRender(opts.url, opts.steps, groups); err != nil {
				return err
			}
			<-tick.C
		}
	}
	dec := json.NewDecoder(bufio.NewReader(os.Stdin))
	var rows [][]float64
	for {
		var obj any
		err := dec.Decode(&obj)
		if err == io.EOF {
			break
		}
		if err != nil {
			return err
		}
		rows = append(rows, sample(obj, groups))
		if opts.steps > 0 && len(rows) > opts.steps {
			rows = rows[len(rows)-opts.steps:]
		}
	}
	renderText(rows, groups, opts.rows)
	return nil
}

func fetchAndRender(url string, steps int, groups []group) error {
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	var obj any
	if err := json.NewDecoder(resp.Body).Decode(&obj); err != nil {
		return err
	}
	renderText([][]float64{sample(obj, groups)}, groups, 0)
	_ = steps
	return nil
}

func sample(obj any, groups []group) []float64 {
	var out []float64
	for gi := range groups {
		for fi := range groups[gi].fields {
			f := &groups[gi].fields[fi]
			v, _ := numberAt(obj, f.path)
			if f.counter {
				if f.seen {
					delta := v - f.last
					f.last = v
					v = delta
				} else {
					f.last = v
					f.seen = true
					v = 0
				}
			}
			out = append(out, v)
		}
	}
	return out
}

func numberAt(obj any, path string) (float64, bool) {
	cur := obj
	for _, p := range strings.Split(path, ".") {
		m, ok := cur.(map[string]any)
		if !ok {
			return 0, false
		}
		cur, ok = m[p]
		if !ok {
			return 0, false
		}
	}
	switch v := cur.(type) {
	case float64:
		return v, true
	case string:
		n, err := strconv.ParseFloat(v, 64)
		return n, err == nil
	case json.Number:
		n, err := v.Float64()
		return n, err == nil
	default:
		return 0, false
	}
}

func renderText(rows [][]float64, groups []group, limit int) {
	if len(rows) == 0 {
		return
	}
	names := make([]string, 0)
	for _, g := range groups {
		for _, f := range g.fields {
			names = append(names, f.path)
		}
	}
	maxRows := len(names)
	if limit > 0 && limit < maxRows {
		maxRows = limit
	}
	for i := 0; i < maxRows; i++ {
		min, max := math.Inf(1), math.Inf(-1)
		for _, r := range rows {
			if i < len(r) {
				if r[i] < min {
					min = r[i]
				}
				if r[i] > max {
					max = r[i]
				}
			}
		}
		last := rows[len(rows)-1][i]
		fmt.Fprintf(os.Stdout, "%s\t%.6g\t[min %.6g max %.6g]\n", names[i], last, min, max)
	}
}

type winsize struct {
	row    uint16
	col    uint16
	xpixel uint16
	ypixel uint16
}

func termSize(fd uintptr) (int, int, error) {
	var ws winsize
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TIOCGWINSZ), uintptr(unsafe.Pointer(&ws)))
	if errno != 0 {
		return 0, 0, errno
	}
	return int(ws.col), int(ws.row), nil
}
