module jplot

go 1.21
