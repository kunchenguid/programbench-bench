module zkclone

go 1.21
