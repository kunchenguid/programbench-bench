package main

import (
	"bufio"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "zk dev"

const rootHelp = `Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command.`

const defaultConfig = `# zk configuration file
[note]
template = "default.md"

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false

[tool]

[lsp]
[lsp.diagnostics]
dead-link = "error"

[lsp.completion]
[filter]
[alias]
`

const defaultTemplate = "# {{title}}\n\n{{content}}\n"

type globalOptions struct {
	notebookDir string
	workingDir  string
	noInput     bool
}

type note struct {
	Path     string    `json:"path"`
	AbsPath  string    `json:"absPath,omitempty"`
	Title    string    `json:"title"`
	Content  string    `json:"content,omitempty"`
	Tags     []string  `json:"tags"`
	Created  time.Time `json:"created"`
	Modified time.Time `json:"modified"`
	Links    []string  `json:"links"`
}

func main() {
	code := run(os.Args[1:], os.Stdout, os.Stderr, os.Stdin)
	os.Exit(code)
}

func run(args []string, stdout, stderr io.Writer, stdin io.Reader) int {
	globals, rest, err := parseGlobals(args)
	if err != nil {
		return fail(stderr, err.Error())
	}
	if globals.workingDir != "" {
		if err := os.Chdir(globals.workingDir); err != nil {
			return fail(stderr, fmt.Sprintf("failed to change working directory: %v", err))
		}
	}
	if len(rest) == 0 {
		fmt.Fprintln(stdout, rootHelp)
		return 0
	}
	cmd := rest[0]
	rest = rest[1:]
	if cmd == "-h" || cmd == "--help" {
		fmt.Fprintln(stdout, rootHelp)
		return 0
	}
	if cmd == "--version" || cmd == "version" {
		fmt.Fprintln(stdout, version)
		return 0
	}
	switch cmd {
	case "init":
		return cmdInit(globals, rest, stdout, stderr)
	case "index":
		return cmdIndex(globals, rest, stdout, stderr)
	case "new":
		return cmdNew(globals, rest, stdout, stderr, stdin)
	case "list":
		return cmdList(globals, rest, stdout, stderr)
	case "graph":
		return cmdGraph(globals, rest, stdout, stderr)
	case "edit":
		return cmdEdit(globals, rest, stdout, stderr)
	case "tag":
		return cmdTag(globals, rest, stdout, stderr)
	default:
		return fail(stderr, "unexpected argument "+cmd)
	}
}

func parseGlobals(args []string) (globalOptions, []string, error) {
	var g globalOptions
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--no-input":
			g.noInput = true
		case a == "-W":
			i++
			if i >= len(args) {
				return g, rest, fmt.Errorf("expected value after -W")
			}
			g.workingDir = args[i]
		case strings.HasPrefix(a, "-W="):
			g.workingDir = strings.TrimPrefix(a, "-W=")
		case a == "--working-dir":
			i++
			if i >= len(args) {
				return g, rest, fmt.Errorf("expected value after --working-dir")
			}
			g.workingDir = args[i]
		case strings.HasPrefix(a, "--working-dir="):
			g.workingDir = strings.TrimPrefix(a, "--working-dir=")
		case a == "--notebook-dir":
			i++
			if i >= len(args) {
				return g, rest, fmt.Errorf("expected value after --notebook-dir")
			}
			g.notebookDir = args[i]
		case strings.HasPrefix(a, "--notebook-dir="):
			g.notebookDir = strings.TrimPrefix(a, "--notebook-dir=")
		default:
			rest = append(rest, args[i:]...)
			return g, rest, nil
		}
	}
	return g, rest, nil
}

func fail(w io.Writer, msg string) int {
	fmt.Fprintf(w, "zk: error: %s\n", msg)
	return 1
}

func cmdInit(g globalOptions, args []string, stdout, stderr io.Writer) int {
	if hasHelp(args) {
		fmt.Fprintln(stdout, initHelp)
		return 0
	}
	dir := "."
	if len(args) > 0 {
		dir = args[0]
	}
	if err := os.MkdirAll(filepath.Join(dir, ".zk", "templates"), 0755); err != nil {
		return fail(stderr, err.Error())
	}
	writeIfMissing(filepath.Join(dir, ".zk", "config.toml"), []byte(defaultConfig))
	writeIfMissing(filepath.Join(dir, ".zk", "templates", "default.md"), []byte(defaultTemplate))
	writeIfMissing(filepath.Join(dir, ".zk", "notebook.db"), nil)
	return 0
}

func cmdIndex(g globalOptions, args []string, stdout, stderr io.Writer) int {
	applyEmbeddedGlobals(&g, args)
	if hasHelp(args) {
		fmt.Fprintln(stdout, indexHelp)
		return 0
	}
	nb, err := findNotebook(g)
	if err != nil {
		return fail(stderr, err.Error())
	}
	notes, _ := loadNotes(nb)
	if !flagPresent(args, "-q", "--quiet") {
		fmt.Fprintf(stdout, "Indexed %d notes\n", len(notes))
	}
	return 0
}

func cmdNew(g globalOptions, args []string, stdout, stderr io.Writer, stdin io.Reader) int {
	applyEmbeddedGlobals(&g, args)
	if hasHelp(args) {
		fmt.Fprintln(stdout, newHelp)
		return 0
	}
	args = normalizeNewArgs(args)
	opts, paths, err := parseFlagMap(args)
	if err != nil {
		return fail(stderr, err.Error())
	}
	nb, err := findNotebook(g)
	if err != nil {
		return fail(stderr, err.Error())
	}
	dir := ""
	if len(paths) > 0 {
		dir = paths[0]
	}
	title := firstValue(opts, "title", "t")
	if title == "" {
		title = "Untitled"
	}
	id := firstValue(opts, "id")
	if id == "" {
		id = randID()
	}
	ext := "md"
	name := safeFileName(id)
	if name == "" {
		name = randID()
	}
	path := filepath.Join(dir, name+"."+ext)
	full := filepath.Join(nb, path)
	content := ""
	if boolOpt(opts, "interactive", "i") {
		b, _ := io.ReadAll(stdin)
		content = string(b)
	}
	body := renderTemplate(nb, firstValue(opts, "template"), title, content)
	if boolOpt(opts, "dry-run", "n") {
		fmt.Fprint(stdout, body)
		fmt.Fprintln(stderr, path)
		return 0
	}
	if err := os.MkdirAll(filepath.Dir(full), 0755); err != nil {
		return fail(stderr, err.Error())
	}
	if err := os.WriteFile(full, []byte(body), 0644); err != nil {
		return fail(stderr, err.Error())
	}
	if boolOpt(opts, "print-path", "p") {
		fmt.Fprintln(stdout, path)
		return 0
	}
	editor := os.Getenv("VISUAL")
	if editor == "" {
		editor = os.Getenv("EDITOR")
	}
	if editor != "" {
		c := exec.Command(editor, full)
		c.Stdin, c.Stdout, c.Stderr = os.Stdin, os.Stdout, os.Stderr
		_ = c.Run()
	}
	return 0
}

func cmdList(g globalOptions, args []string, stdout, stderr io.Writer) int {
	applyEmbeddedGlobals(&g, args)
	if hasHelp(args) {
		fmt.Fprintln(stdout, listHelp)
		return 0
	}
	opts, paths, err := parseFlagMap(args)
	if err != nil {
		return fail(stderr, err.Error())
	}
	nb, err := findNotebook(g)
	if err != nil {
		return fail(stderr, err.Error())
	}
	notes, err := loadNotes(nb)
	if err != nil {
		return fail(stderr, err.Error())
	}
	notes = filterNotes(notes, paths, opts)
	sortNotes(notes, firstValue(opts, "sort", "s"))
	limit := intValue(firstValue(opts, "limit", "n"))
	if limit > 0 && limit < len(notes) {
		notes = notes[:limit]
	}
	format := firstValue(opts, "format", "f")
	if format == "" {
		format = "oneline"
	}
	printHeaderFooter(stdout, firstValue(opts, "header"))
	printNotes(stdout, notes, format, delimiter(opts))
	printHeaderFooter(stdout, firstValue(opts, "footer"))
	return 0
}

func cmdGraph(g globalOptions, args []string, stdout, stderr io.Writer) int {
	applyEmbeddedGlobals(&g, args)
	if hasHelp(args) {
		fmt.Fprintln(stdout, graphHelp)
		return 0
	}
	opts, paths, err := parseFlagMap(args)
	if err != nil {
		return fail(stderr, err.Error())
	}
	if firstValue(opts, "format", "f") == "" {
		return fail(stderr, "missing flags: --format=STRING")
	}
	nb, err := findNotebook(g)
	if err != nil {
		return fail(stderr, err.Error())
	}
	notes, _ := loadNotes(nb)
	notes = filterNotes(notes, paths, opts)
	type node struct {
		ID    string `json:"id"`
		Path  string `json:"path"`
		Title string `json:"title"`
	}
	type edge struct {
		Source string `json:"source"`
		Target string `json:"target"`
	}
	nodes := []node{}
	edges := []edge{}
	byTitle := map[string]string{}
	for _, n := range notes {
		nodes = append(nodes, node{ID: n.Path, Path: n.Path, Title: n.Title})
		byTitle[strings.ToLower(n.Title)] = n.Path
	}
	for _, n := range notes {
		for _, l := range n.Links {
			target := l
			if p, ok := byTitle[strings.ToLower(l)]; ok {
				target = p
			}
			edges = append(edges, edge{Source: n.Path, Target: target})
		}
	}
	enc := json.NewEncoder(stdout)
	enc.SetIndent("", "  ")
	_ = enc.Encode(map[string]any{"nodes": nodes, "edges": edges})
	return 0
}

func cmdEdit(g globalOptions, args []string, stdout, stderr io.Writer) int {
	applyEmbeddedGlobals(&g, args)
	if hasHelp(args) {
		fmt.Fprintln(stdout, editHelp)
		return 0
	}
	nb, err := findNotebook(g)
	if err != nil {
		return fail(stderr, err.Error())
	}
	notes, _ := loadNotes(nb)
	opts, paths, _ := parseFlagMap(args)
	notes = filterNotes(notes, paths, opts)
	if len(notes) == 0 {
		return 0
	}
	editor := os.Getenv("VISUAL")
	if editor == "" {
		editor = os.Getenv("EDITOR")
	}
	if editor == "" {
		return fail(stderr, "no editor set")
	}
	cmdArgs := []string{}
	for _, n := range notes {
		cmdArgs = append(cmdArgs, filepath.Join(nb, n.Path))
	}
	c := exec.Command(editor, cmdArgs...)
	c.Stdin, c.Stdout, c.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := c.Run(); err != nil {
		return fail(stderr, err.Error())
	}
	return 0
}

func cmdTag(g globalOptions, args []string, stdout, stderr io.Writer) int {
	applyEmbeddedGlobals(&g, args)
	if len(args) == 0 || hasHelp(args) {
		fmt.Fprintln(stdout, tagHelp)
		return 0
	}
	if args[0] != "list" {
		return fail(stderr, "unexpected argument "+args[0])
	}
	rest := args[1:]
	if hasHelp(rest) {
		fmt.Fprintln(stdout, tagListHelp)
		return 0
	}
	opts, _, err := parseFlagMap(rest)
	if err != nil {
		return fail(stderr, err.Error())
	}
	nb, err := findNotebook(g)
	if err != nil {
		return fail(stderr, err.Error())
	}
	notes, _ := loadNotes(nb)
	counts := map[string]int{}
	for _, n := range notes {
		for _, t := range n.Tags {
			counts[t]++
		}
	}
	tags := make([]string, 0, len(counts))
	for t := range counts {
		tags = append(tags, t)
	}
	sort.Strings(tags)
	format := firstValue(opts, "format", "f")
	if format == "" {
		format = "name"
	}
	delim := delimiter(opts)
	if format == "json" {
		arr := []map[string]any{}
		for _, t := range tags {
			arr = append(arr, map[string]any{"name": t, "noteCount": counts[t]})
		}
		b, _ := json.MarshalIndent(arr, "", "  ")
		fmt.Fprintln(stdout, string(b))
		return 0
	}
	for i, t := range tags {
		if i > 0 {
			fmt.Fprint(stdout, delim)
		}
		if format == "full" {
			fmt.Fprintf(stdout, "%s %d", t, counts[t])
		} else if format == "jsonl" {
			b, _ := json.Marshal(map[string]any{"name": t, "noteCount": counts[t]})
			fmt.Fprint(stdout, string(b))
		} else {
			fmt.Fprint(stdout, t)
		}
	}
	if len(tags) > 0 && delim != "\x00" {
		fmt.Fprint(stdout, "\n")
	}
	return 0
}

func writeIfMissing(path string, data []byte) {
	if _, err := os.Stat(path); err == nil {
		return
	}
	_ = os.WriteFile(path, data, 0644)
}

func findNotebook(g globalOptions) (string, error) {
	if g.notebookDir != "" {
		if _, err := os.Stat(filepath.Join(g.notebookDir, ".zk")); err != nil {
			return "", fmt.Errorf("failed to open notebook: no notebook found in %s", g.notebookDir)
		}
		return filepath.Abs(g.notebookDir)
	}
	wd, _ := os.Getwd()
	cur := wd
	for {
		if st, err := os.Stat(filepath.Join(cur, ".zk")); err == nil && st.IsDir() {
			return cur, nil
		}
		next := filepath.Dir(cur)
		if next == cur {
			break
		}
		cur = next
	}
	return "", fmt.Errorf("failed to open notebook: no notebook found in %s or a parent directory", wd)
}

func loadNotes(nb string) ([]note, error) {
	var notes []note
	err := filepath.WalkDir(nb, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() {
			if d.Name() == ".zk" || d.Name() == ".git" {
				return filepath.SkipDir
			}
			return nil
		}
		ext := strings.ToLower(filepath.Ext(path))
		if ext != ".md" && ext != ".markdown" && ext != ".txt" {
			return nil
		}
		b, err := os.ReadFile(path)
		if err != nil {
			return nil
		}
		info, _ := d.Info()
		rel, _ := filepath.Rel(nb, path)
		rel = filepath.ToSlash(rel)
		n := parseNote(rel, path, string(b), info.ModTime())
		notes = append(notes, n)
		return nil
	})
	return notes, err
}

func parseNote(rel, abs, body string, mod time.Time) note {
	title := ""
	sc := bufio.NewScanner(strings.NewReader(body))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if strings.HasPrefix(line, "# ") {
			title = strings.TrimSpace(strings.TrimPrefix(line, "# "))
			break
		}
	}
	if title == "" {
		title = strings.TrimSuffix(filepath.Base(rel), filepath.Ext(rel))
	}
	tags := uniqueMatches(regexp.MustCompile(`(^|[^\pL\pN_])#([A-Za-z0-9][A-Za-z0-9_/-]*)`).FindAllStringSubmatch(body, -1), 2)
	links := []string{}
	for _, m := range regexp.MustCompile(`\[\[([^\]|#]+)`).FindAllStringSubmatch(body, -1) {
		links = append(links, strings.TrimSpace(m[1]))
	}
	for _, m := range regexp.MustCompile(`\[[^\]]+\]\(([^)]+)\)`).FindAllStringSubmatch(body, -1) {
		links = append(links, strings.TrimSpace(m[1]))
	}
	sort.Strings(tags)
	return note{Path: rel, AbsPath: abs, Title: title, Content: body, Tags: tags, Created: mod, Modified: mod, Links: links}
}

func uniqueMatches(ms [][]string, idx int) []string {
	set := map[string]bool{}
	for _, m := range ms {
		if len(m) > idx {
			set[m[idx]] = true
		}
	}
	out := make([]string, 0, len(set))
	for v := range set {
		out = append(out, v)
	}
	return out
}

func filterNotes(notes []note, paths []string, opts map[string][]string) []note {
	var out []note
	matches := splitCSV(values(opts, "match", "m"))
	tags := splitCSV(values(opts, "tag", "t"))
	excludes := splitCSV(values(opts, "exclude", "x"))
	for _, n := range notes {
		if len(paths) > 0 && !pathMatches(n.Path, paths) {
			continue
		}
		if len(excludes) > 0 && pathMatches(n.Path, excludes) {
			continue
		}
		hay := strings.ToLower(n.Title + "\n" + n.Content + "\n" + n.Path)
		ok := true
		for _, m := range matches {
			if !strings.Contains(hay, strings.ToLower(m)) {
				ok = false
				break
			}
		}
		if !ok {
			continue
		}
		for _, t := range tags {
			t = strings.TrimPrefix(t, "#")
			if !contains(n.Tags, t) {
				ok = false
				break
			}
		}
		if boolOpt(opts, "tagless") && len(n.Tags) != 0 {
			ok = false
		}
		if ok {
			out = append(out, n)
		}
	}
	return out
}

func pathMatches(p string, prefixes []string) bool {
	p = filepath.ToSlash(strings.TrimPrefix(p, "./"))
	for _, q := range prefixes {
		q = filepath.ToSlash(strings.TrimPrefix(q, "./"))
		if p == q || strings.HasPrefix(p, strings.TrimSuffix(q, "/")+"/") {
			return true
		}
	}
	return false
}

func sortNotes(notes []note, spec string) {
	desc := strings.HasSuffix(spec, "-")
	key := strings.TrimSuffix(strings.TrimSuffix(spec, "-"), "+")
	sort.SliceStable(notes, func(i, j int) bool {
		var less bool
		switch key {
		case "title":
			less = strings.ToLower(notes[i].Title) < strings.ToLower(notes[j].Title)
		case "created", "modified":
			less = notes[i].Modified.Before(notes[j].Modified)
		default:
			less = notes[i].Path < notes[j].Path
		}
		if desc {
			return !less
		}
		return less
	})
}

func printNotes(w io.Writer, notes []note, format, delim string) {
	if format == "json" {
		b, _ := json.MarshalIndent(notes, "", "  ")
		fmt.Fprintln(w, string(b))
		return
	}
	for i, n := range notes {
		if i > 0 {
			fmt.Fprint(w, delim)
		}
		switch format {
		case "path":
			fmt.Fprint(w, n.Path)
		case "title":
			fmt.Fprint(w, n.Title)
		case "short":
			fmt.Fprintf(w, "%s\n%s", n.Title, n.Path)
		case "medium", "long", "full":
			fmt.Fprintf(w, "%s\n%s\n%s", n.Title, n.Path, strings.TrimSpace(n.Content))
		case "jsonl":
			b, _ := json.Marshal(n)
			fmt.Fprint(w, string(b))
		default:
			if n.Title != "" {
				fmt.Fprintf(w, "%s %s", n.Title, n.Path)
			} else {
				fmt.Fprint(w, n.Path)
			}
		}
	}
	if len(notes) > 0 && delim != "\x00" {
		fmt.Fprint(w, "\n")
	}
}

func parseFlagMap(args []string) (map[string][]string, []string, error) {
	opts := map[string][]string{}
	var paths []string
	boolean := map[string]bool{
		"help": true, "interactive": true, "print-path": true, "dry-run": true, "force": true,
		"quiet": true, "no-pager": true, "delimiter0": true, "recursive": true, "orphan": true, "no-input": true,
		"tagless": true, "missing-backlink": true, "verbose": true,
	}
	shortBool := map[string]string{"h": "help", "i": "interactive", "p": "print-path", "n": "limit", "f": "format", "q": "quiet", "P": "no-pager", "r": "recursive", "0": "delimiter0", "v": "verbose", "t": "t", "m": "match", "M": "match-strategy", "x": "exclude", "s": "sort", "d": "delimiter", "l": "link-to", "L": "linked-by", "g": "group"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			paths = append(paths, args[i+1:]...)
			break
		}
		if strings.HasPrefix(a, "--") {
			nameval := strings.TrimPrefix(a, "--")
			name, val, has := strings.Cut(nameval, "=")
			if !has && !boolean[name] {
				i++
				if i >= len(args) {
					return opts, paths, fmt.Errorf("expected value after --%s", name)
				}
				val = args[i]
			}
			if !has && boolean[name] {
				val = "true"
			}
			opts[name] = append(opts[name], val)
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) > 1 {
			key := strings.TrimPrefix(a, "-")
			name := shortBool[key]
			if name == "" {
				return opts, paths, fmt.Errorf("unknown flag -%s", key)
			}
			if boolean[name] {
				opts[name] = append(opts[name], "true")
			} else {
				i++
				if i >= len(args) {
					return opts, paths, fmt.Errorf("expected value after -%s", key)
				}
				opts[name] = append(opts[name], args[i])
			}
			continue
		}
		paths = append(paths, a)
	}
	return opts, paths, nil
}

func applyEmbeddedGlobals(g *globalOptions, args []string) {
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--no-input":
			g.noInput = true
		case a == "--notebook-dir" && i+1 < len(args):
			i++
			g.notebookDir = args[i]
		case strings.HasPrefix(a, "--notebook-dir="):
			g.notebookDir = strings.TrimPrefix(a, "--notebook-dir=")
		case (a == "--working-dir" || a == "-W") && i+1 < len(args):
			i++
			g.workingDir = args[i]
			_ = os.Chdir(g.workingDir)
		case strings.HasPrefix(a, "--working-dir="):
			g.workingDir = strings.TrimPrefix(a, "--working-dir=")
			_ = os.Chdir(g.workingDir)
		}
	}
}

func normalizeNewArgs(args []string) []string {
	out := make([]string, 0, len(args))
	for _, a := range args {
		if a == "-n" {
			out = append(out, "--dry-run")
		} else {
			out = append(out, a)
		}
	}
	return out
}

func hasHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			return true
		}
	}
	return false
}

func flagPresent(args []string, names ...string) bool {
	for _, a := range args {
		for _, n := range names {
			if a == n {
				return true
			}
		}
	}
	return false
}

func values(opts map[string][]string, names ...string) []string {
	var out []string
	for _, n := range names {
		out = append(out, opts[n]...)
	}
	return out
}

func firstValue(opts map[string][]string, names ...string) string {
	for _, n := range names {
		if len(opts[n]) > 0 {
			return opts[n][len(opts[n])-1]
		}
	}
	return ""
}

func boolOpt(opts map[string][]string, names ...string) bool {
	return firstValue(opts, names...) != ""
}

func intValue(s string) int {
	n, _ := strconv.Atoi(s)
	return n
}

func splitCSV(vs []string) []string {
	var out []string
	for _, v := range vs {
		for _, p := range strings.Split(v, ",") {
			p = strings.TrimSpace(p)
			if p != "" {
				out = append(out, p)
			}
		}
	}
	return out
}

func delimiter(opts map[string][]string) string {
	if boolOpt(opts, "delimiter0") {
		return "\x00"
	}
	d := firstValue(opts, "delimiter", "d")
	if d == "" {
		return "\n"
	}
	d = strings.ReplaceAll(d, `\n`, "\n")
	d = strings.ReplaceAll(d, `\t`, "\t")
	return d
}

func printHeaderFooter(w io.Writer, s string) {
	if s == "" {
		return
	}
	s = strings.ReplaceAll(s, `\n`, "\n")
	fmt.Fprint(w, s)
}

func contains(xs []string, x string) bool {
	for _, y := range xs {
		if y == x {
			return true
		}
	}
	return false
}

func safeFileName(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	repl := regexp.MustCompile(`[^a-z0-9_-]+`).ReplaceAllString(s, "-")
	return strings.Trim(repl, "-")
}

func randID() string {
	b := make([]byte, 2)
	if _, err := rand.Read(b); err == nil {
		return hex.EncodeToString(b)
	}
	return fmt.Sprintf("%04d", time.Now().UnixNano()%10000)
}

func renderTemplate(nb, custom, title, content string) string {
	tmpl := defaultTemplate
	if custom != "" {
		path := custom
		if !filepath.IsAbs(path) {
			path = filepath.Join(nb, ".zk", "templates", path)
		}
		if b, err := os.ReadFile(path); err == nil {
			tmpl = string(b)
		}
	} else if b, err := os.ReadFile(filepath.Join(nb, ".zk", "templates", "default.md")); err == nil {
		tmpl = string(b)
	}
	tmpl = strings.ReplaceAll(tmpl, "{{title}}", title)
	tmpl = strings.ReplaceAll(tmpl, "{{content}}", strings.TrimRight(content, "\n"))
	tmpl = strings.ReplaceAll(tmpl, "{{date}}", time.Now().Format("2006-01-02"))
	tmpl = strings.ReplaceAll(tmpl, "{{id}}", randID())
	return tmpl
}

const initHelp = `Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.`

const indexHelp = `Usage: zk index

Index the notes to be searchable.

You usually do not need to run ` + "`zk index`" + ` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress.`

const newHelp = `Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value.`

const listHelp = `Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with ` + "`xargs -0`" + `.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --tagless                    Find notes which have no tags.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.`

const graphHelp = `Usage: zk graph --format=STRING [<path> ...]

Produce a graph of the notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=STRING    Format of the graph among: json.
  -q, --quiet            Do not print the total number of notes found.`

const editHelp = `Usage: zk edit [<path> ...]

Edit notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Do not confirm before editing many notes at the
                             same time.`

const tagHelp = `Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.`

const tagListHelp = `Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with ` + "`xargs -0`" + `.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion.`
