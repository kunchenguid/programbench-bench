module gittype

go 1.21
