package main

import (
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

const version = "gittype 0.8.0"

var supported = map[string]bool{
	"rust": true, "rs": true, "typescript": true, "ts": true, "javascript": true, "js": true,
	"python": true, "py": true, "ruby": true, "rb": true, "go": true, "swift": true,
	"kotlin": true, "kt": true, "java": true, "php": true, "csharp": true, "cs": true,
	"c#": true, "c": true, "cpp": true, "c++": true, "haskell": true, "hs": true,
	"dart": true, "scala": true, "sc": true, "zig": true, "clojure": true, "clj": true, "cljs": true,
}

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	if len(args) == 0 {
		return start(".", "")
	}
	switch args[0] {
	case "-h":
		fmt.Print(shortHelp)
		return 0
	case "--help", "help":
		if len(args) > 1 {
			return helpFor(args[1:])
		}
		fmt.Print(longHelp)
		return 0
	case "-V", "--version":
		fmt.Println(version)
		return 0
	}

	var repoOpt, langs, repoPath string
	for len(args) > 0 {
		a := args[0]
		if a == "--repo" {
			if len(args) < 2 {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--repo <REPO>' but none was supplied\n\nFor more information, try '--help'.")
				return 2
			}
			repoOpt = args[1]
			args = args[2:]
			continue
		}
		if strings.HasPrefix(a, "--repo=") {
			repoOpt = strings.TrimPrefix(a, "--repo=")
			args = args[1:]
			continue
		}
		if a == "--langs" {
			if len(args) < 2 {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--langs <LANGS>' but none was supplied\n\nFor more information, try '--help'.")
				return 2
			}
			langs = args[1]
			args = args[2:]
			continue
		}
		if strings.HasPrefix(a, "--langs=") {
			langs = strings.TrimPrefix(a, "--langs=")
			args = args[1:]
			continue
		}
		if strings.HasPrefix(a, "-") {
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n\nFor more information, try '--help'.\n", a, a, a)
			return 2
		}
		break
	}
	if langs != "" {
		if bad := invalidLangs(langs); len(bad) > 0 {
			fmt.Printf("❌ Unsupported language(s): %s\n", strings.Join(bad, ", "))
			fmt.Print("💡 Supported languages:\n")
			fmt.Print("   rust, rs, typescript, ts, javascript, js\n")
			fmt.Print("   python, py, ruby, rb, go, swift\n")
			fmt.Print("   kotlin, kt, java, php, csharp, cs\n")
			fmt.Print("   c#, c, cpp, c++, haskell, hs\n")
			fmt.Print("   dart, scala, sc, zig, clojure, clj\n")
			fmt.Print("   cljs\n")
			return 1
		}
	}
	if len(args) == 0 {
		if repoOpt != "" {
			return start(repoOpt, langs)
		}
		return start(".", langs)
	}
	if isCommand(args[0]) {
		return command(args)
	}
	repoPath = args[0]
	args = args[1:]
	if len(args) > 0 && isCommand(args[0]) {
		return command(args)
	}
	if repoOpt != "" {
		repoPath = repoOpt
	}
	return start(repoPath, langs)
}

func helpFor(args []string) int {
	if len(args) == 0 {
		fmt.Print(longHelp)
		return 0
	}
	switch args[0] {
	case "cache":
		fmt.Print(cacheHelp)
	case "repo":
		fmt.Print(repoHelp)
	case "history":
		fmt.Print(historyHelp)
	case "stats":
		fmt.Print(statsHelp)
	case "export":
		fmt.Print(exportHelp)
	case "trending":
		fmt.Print(trendingHelp)
	default:
		fmt.Print(longHelp)
	}
	return 0
}

func isCommand(s string) bool {
	switch s {
	case "history", "stats", "export", "cache", "repo", "trending", "help":
		return true
	}
	return false
}

func command(args []string) int {
	switch args[0] {
	case "history":
		if hasHelp(args[1:]) {
			fmt.Print(historyHelp)
			return 0
		}
		fmt.Println("❌ History command is not yet implemented")
		fmt.Println("💡 This feature is planned for a future release")
		return 1
	case "stats":
		if hasHelp(args[1:]) {
			fmt.Print(statsHelp)
			return 0
		}
		fmt.Println("❌ Stats command is not yet implemented")
		fmt.Println("💡 This feature is planned for a future release")
		return 1
	case "export":
		return exportCmd(args[1:])
	case "cache":
		return cacheCmd(args[1:])
	case "repo":
		return repoCmd(args[1:])
	case "trending":
		return trendingCmd(args[1:])
	case "help":
		return helpFor(args[1:])
	default:
		return start(args[0], "")
	}
}

func exportCmd(args []string) int {
	format := "json"
	output := ""
	for len(args) > 0 {
		switch {
		case args[0] == "-h" || args[0] == "--help":
			fmt.Print(exportHelp)
			return 0
		case args[0] == "--format":
			if len(args) < 2 {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--format <FORMAT>' but none was supplied\n\nFor more information, try '--help'.")
				return 2
			}
			format = args[1]
			args = args[2:]
		case strings.HasPrefix(args[0], "--format="):
			format = strings.TrimPrefix(args[0], "--format=")
			args = args[1:]
		case args[0] == "--output":
			if len(args) < 2 {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--output <OUTPUT>' but none was supplied\n\nFor more information, try '--help'.")
				return 2
			}
			output = args[1]
			args = args[2:]
		case strings.HasPrefix(args[0], "--output="):
			output = strings.TrimPrefix(args[0], "--output=")
			args = args[1:]
		default:
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable export [OPTIONS]\n\nFor more information, try '--help'.\n", args[0])
			return 2
		}
	}
	fmt.Println("❌ Export command is not yet implemented")
	fmt.Printf("💡 Requested format: %s\n", format)
	if output != "" {
		fmt.Printf("💡 Requested output: %s\n", output)
	}
	fmt.Println("💡 This feature is planned for a future release")
	return 1
}

func cacheCmd(args []string) int {
	if len(args) == 0 || (len(args) == 1 && hasHelp(args)) {
		fmt.Print(cacheHelp)
		if len(args) == 0 {
			return 2
		}
		return 0
	}
	switch args[0] {
	case "stats":
		if hasHelp(args[1:]) {
			fmt.Print(cacheStatsHelp)
			return 0
		}
		fmt.Println("Challenge Cache Statistics:")
		fmt.Println("  Cached repositories: 0")
		fmt.Println("  Total size: 0 bytes")
	case "list":
		if hasHelp(args[1:]) {
			fmt.Print(cacheListHelp)
			return 0
		}
		fmt.Println("No cached challenges found.")
	case "clear":
		if hasHelp(args[1:]) {
			fmt.Print(cacheClearHelp)
			return 0
		}
		fmt.Println("Challenge cache cleared successfully.")
	case "help":
		fmt.Print(cacheHelp)
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable cache <COMMAND>\n\nFor more information, try '--help'.\n", args[0])
		return 2
	}
	return 0
}

func repoCmd(args []string) int {
	if len(args) == 0 || (len(args) == 1 && hasHelp(args)) {
		fmt.Print(repoHelp)
		if len(args) == 0 {
			return 2
		}
		return 0
	}
	switch args[0] {
	case "list":
		if hasHelp(args[1:]) {
			fmt.Print(repoListHelp)
			return 0
		}
		fmt.Println("No cached repositories found.")
	case "clear":
		if hasHelp(args[1:]) {
			fmt.Print(repoClearHelp)
			return 0
		}
		for _, a := range args[1:] {
			if a != "--force" {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable repo clear [OPTIONS]\n\nFor more information, try '--help'.\n", a)
				return 2
			}
		}
		fmt.Println("No cached repositories directory found.")
	case "play":
		if hasHelp(args[1:]) {
			fmt.Print(repoPlayHelp)
			return 0
		}
		fmt.Println("No cached repositories found.")
	case "help":
		fmt.Print(repoHelp)
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable repo <COMMAND>\n\nFor more information, try '--help'.\n", args[0])
		return 2
	}
	return 0
}

func trendingCmd(args []string) int {
	if hasHelp(args) {
		fmt.Print(trendingHelp)
		return 0
	}
	for len(args) > 0 && strings.HasPrefix(args[0], "--") {
		if args[0] == "--period" {
			if len(args) < 2 {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--period <PERIOD>' but none was supplied\n\nFor more information, try '--help'.")
				return 2
			}
			args = args[2:]
		} else if strings.HasPrefix(args[0], "--period=") {
			args = args[1:]
		} else {
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]\n\nFor more information, try '--help'.\n", args[0])
			return 2
		}
	}
	if len(args) >= 2 && !strings.Contains(args[1], "/") {
		fmt.Println("⚠️ Repository name must be in format 'owner/repo'")
		return 0
	}
	fmt.Println("Error: trending repositories require network access, which is unavailable in this environment")
	return 1
}

func start(path, langs string) int {
	if looksRemote(path) {
		fmt.Println("Error: cloning remote repositories requires network access, which is unavailable in this environment")
		return 1
	}
	info, err := os.Stat(path)
	if err != nil || !info.IsDir() {
		fmt.Printf("Error: Repository path does not exist: %s\n", path)
		return 1
	}
	files := collectCode(path, langs)
	if len(files) == 0 {
		fmt.Println("No code challenges found.")
		return 1
	}
	fmt.Printf("GitType loaded %d source file(s) from %s\n", len(files), path)
	for i, f := range files {
		if i >= 10 {
			break
		}
		fmt.Println(f)
	}
	return 0
}

func collectCode(root, langs string) []string {
	allowed := map[string]bool{}
	if langs != "" {
		for _, l := range strings.Split(langs, ",") {
			for _, ext := range langExt(strings.ToLower(strings.TrimSpace(l))) {
				allowed[ext] = true
			}
		}
	}
	var out []string
	_ = filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		name := d.Name()
		if d.IsDir() {
			if name == ".git" || name == "node_modules" || name == "target" || name == "vendor" {
				return filepath.SkipDir
			}
			return nil
		}
		ext := strings.TrimPrefix(filepath.Ext(name), ".")
		if ext == "" {
			return nil
		}
		if len(allowed) > 0 {
			if !allowed[ext] {
				return nil
			}
		} else if !knownExt(ext) {
			return nil
		}
		if rel, err := filepath.Rel(root, path); err == nil {
			out = append(out, rel)
		}
		return nil
	})
	sort.Strings(out)
	return out
}

func invalidLangs(s string) []string {
	var bad []string
	for _, p := range strings.Split(s, ",") {
		l := strings.ToLower(strings.TrimSpace(p))
		if l != "" && !supported[l] {
			bad = append(bad, l)
		}
	}
	return bad
}

func hasHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			return true
		}
	}
	return false
}

func looksRemote(s string) bool {
	return strings.Contains(s, "github.com:") || strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://") || (strings.Count(s, "/") == 1 && !strings.HasPrefix(s, ".") && !strings.HasPrefix(s, "/"))
}

func knownExt(ext string) bool {
	for _, e := range []string{"rs", "ts", "tsx", "js", "jsx", "py", "rb", "go", "swift", "kt", "java", "php", "cs", "c", "h", "cpp", "cc", "cxx", "hpp", "hs", "dart", "scala", "sc", "zig", "clj", "cljs"} {
		if ext == e {
			return true
		}
	}
	return false
}

func langExt(l string) []string {
	switch l {
	case "rust", "rs":
		return []string{"rs"}
	case "typescript", "ts":
		return []string{"ts", "tsx"}
	case "javascript", "js":
		return []string{"js", "jsx"}
	case "python", "py":
		return []string{"py"}
	case "ruby", "rb":
		return []string{"rb"}
	case "go":
		return []string{"go"}
	case "swift":
		return []string{"swift"}
	case "kotlin", "kt":
		return []string{"kt"}
	case "java":
		return []string{"java"}
	case "php":
		return []string{"php"}
	case "csharp", "cs", "c#":
		return []string{"cs"}
	case "c":
		return []string{"c", "h"}
	case "cpp", "c++":
		return []string{"cpp", "cc", "cxx", "hpp", "h"}
	case "haskell", "hs":
		return []string{"hs"}
	case "dart":
		return []string{"dart"}
	case "scala", "sc":
		return []string{"scala", "sc"}
	case "zig":
		return []string{"zig"}
	case "clojure", "clj", "cljs":
		return []string{"clj", "cljs"}
	}
	return nil
}

const shortHelp = `A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version
`

const longHelp = `GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`

const historyHelp = `Show session history

Usage: executable history

Options:
  -h, --help  Print help
`

const statsHelp = `Show analytics

Usage: executable stats

Options:
  -h, --help  Print help
`

const exportHelp = `Export session data

Usage: executable export [OPTIONS]

Options:
      --format <FORMAT>  Export format [default: json]
      --output <OUTPUT>  Output file path
  -h, --help             Print help
`

const cacheHelp = `Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`

const cacheStatsHelp = `Show cache statistics

Usage: executable cache stats

Options:
  -h, --help  Print help
`

const cacheListHelp = `List cached repository keys

Usage: executable cache list

Options:
  -h, --help  Print help
`

const cacheClearHelp = `Clear all cached challenges

Usage: executable cache clear

Options:
  -h, --help  Print help
`

const repoHelp = `Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`

const repoListHelp = `List all cached repositories

Usage: executable repo list

Options:
  -h, --help  Print help
`

const repoClearHelp = `Clear all cached repositories

Usage: executable repo clear [OPTIONS]

Options:
      --force  Force clear without confirmation
  -h, --help   Print help
`

const repoPlayHelp = `Play a cached repository interactively

Usage: executable repo play

Options:
  -h, --help  Print help
`

const trendingHelp = `Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')
`
