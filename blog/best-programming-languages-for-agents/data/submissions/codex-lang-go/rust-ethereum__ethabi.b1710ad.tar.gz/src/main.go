package main

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"os"
	"regexp"
	"strconv"
	"strings"
)

type ABIEntry struct {
	Type      string     `json:"type"`
	Name      string     `json:"name"`
	Inputs    []ABIParam `json:"inputs"`
	Outputs   []ABIParam `json:"outputs"`
	Anonymous bool       `json:"anonymous"`
}

type ABIParam struct {
	Name    string `json:"name"`
	Type    string `json:"type"`
	Indexed bool   `json:"indexed"`
}

type Type struct {
	Kind      string
	Size      int
	Array     *int
	ArrayElem *Type
}

func main() {
	if len(os.Args) < 2 || os.Args[1] == "-h" || os.Args[1] == "--help" {
		rootHelp()
		return
	}
	if os.Args[1] == "-V" || os.Args[1] == "--version" {
		fmt.Println("ethabi-cli 18.0.0")
		return
	}
	var err error
	switch os.Args[1] {
	case "encode":
		err = cmdEncode(os.Args[2:])
	case "decode":
		err = cmdDecode(os.Args[2:])
	case "help":
		rootHelp()
	default:
		err = fmt.Errorf("unknown subcommand")
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func rootHelp() {
	fmt.Println(`ethabi-cli 18.0.0
Ethereum ABI coder

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    decode    Decode ABI call result
    encode    Encode ABI call
    help      Prints this message or the help of the given subcommand(s)`)
}

func cmdEncode(args []string) error {
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		fmt.Println("executable-encode 18.0.0\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>")
		return nil
	}
	switch args[0] {
	case "params":
		return encodeParams(args[1:])
	case "function":
		return encodeFunction(args[1:])
	case "help":
		fmt.Println("executable-encode 18.0.0\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>")
		return nil
	}
	return fmt.Errorf("unknown encode subcommand")
}

func cmdDecode(args []string) error {
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		fmt.Println("executable-decode 18.0.0\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>")
		return nil
	}
	switch args[0] {
	case "params":
		return decodeParams(args[1:])
	case "function":
		return decodeFunction(args[1:])
	case "log":
		return decodeLog(args[1:])
	case "help":
		fmt.Println("executable-decode 18.0.0\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>")
		return nil
	}
	return fmt.Errorf("unknown decode subcommand")
}

func encodeParams(args []string) error {
	if hasHelp(args) {
		fmt.Println("executable-encode-params 18.0.0\nSpecify types of input params inline")
		return nil
	}
	lenient := false
	var types []Type
	var vals []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-l", "--lenient":
			lenient = true
		case "-v":
			if i+2 >= len(args) {
				return fmt.Errorf("missing -v arguments")
			}
			t, err := parseType(args[i+1])
			if err != nil {
				return err
			}
			types = append(types, t)
			vals = append(vals, args[i+2])
			i += 2
		default:
			return fmt.Errorf("unexpected argument %s", args[i])
		}
	}
	toks, err := parseValues(types, vals, lenient)
	if err != nil {
		return err
	}
	out, err := encodeTuple(types, toks)
	if err != nil {
		return err
	}
	fmt.Println(hex.EncodeToString(out))
	return nil
}

func encodeFunction(args []string) error {
	if hasHelp(args) {
		fmt.Println("executable-encode-function 18.0.0\nLoad function from JSON ABI file")
		return nil
	}
	lenient := false
	var params []string
	var rest []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-l", "--lenient":
			lenient = true
		case "-p":
			if i+1 >= len(args) {
				return fmt.Errorf("missing param")
			}
			params = append(params, args[i+1])
			i++
		default:
			rest = append(rest, args[i])
		}
	}
	if len(rest) != 2 {
		return fmt.Errorf("invalid arguments")
	}
	entries, err := loadABI(rest[0])
	if err != nil {
		return err
	}
	fn, err := findEntry(entries, "function", rest[1])
	if err != nil {
		return err
	}
	types := paramTypes(fn.Inputs)
	toks, err := parseValues(types, params, lenient)
	if err != nil {
		return err
	}
	body, err := encodeTuple(types, toks)
	if err != nil {
		return err
	}
	sig := fn.Name + "(" + typeList(fn.Inputs) + ")"
	sum := Keccak256([]byte(sig))
	fmt.Println(hex.EncodeToString(append(sum[:4], body...)))
	return nil
}

func decodeParams(args []string) error {
	if hasHelp(args) {
		fmt.Println("executable-decode-params 18.0.0\nSpecify types of input params inline")
		return nil
	}
	var types []Type
	var dataArg string
	for i := 0; i < len(args); i++ {
		if args[i] == "-t" {
			if i+1 >= len(args) {
				return fmt.Errorf("missing type")
			}
			t, err := parseType(args[i+1])
			if err != nil {
				return err
			}
			types = append(types, t)
			i++
		} else {
			dataArg = args[i]
		}
	}
	data, err := decodeHex(dataArg)
	if err != nil {
		return err
	}
	vals, err := decodeTuple(types, data, 0)
	if err != nil {
		return err
	}
	for i, v := range vals {
		fmt.Printf("%s %s\n", types[i].String(), formatValue(v))
	}
	return nil
}

func decodeFunction(args []string) error {
	if hasHelp(args) {
		fmt.Println("executable-decode-function 18.0.0\nLoad function from JSON ABI file")
		return nil
	}
	if len(args) != 3 {
		return fmt.Errorf("invalid arguments")
	}
	entries, err := loadABI(args[0])
	if err != nil {
		return err
	}
	fn, err := findEntry(entries, "function", args[1])
	if err != nil {
		return err
	}
	types := paramTypes(fn.Outputs)
	data, err := decodeHex(args[2])
	if err != nil {
		return err
	}
	vals, err := decodeTuple(types, data, 0)
	if err != nil {
		return err
	}
	for i, v := range vals {
		fmt.Printf("%s %s\n", types[i].String(), formatValue(v))
	}
	return nil
}

func decodeLog(args []string) error {
	if hasHelp(args) {
		fmt.Println("executable-decode-log 18.0.0\nDecode event log")
		return nil
	}
	var topics []string
	var rest []string
	for i := 0; i < len(args); i++ {
		if args[i] == "-l" {
			if i+1 >= len(args) {
				return fmt.Errorf("missing topic")
			}
			topics = append(topics, args[i+1])
			i++
		} else {
			rest = append(rest, args[i])
		}
	}
	if len(rest) != 3 {
		return fmt.Errorf("invalid arguments")
	}
	entries, err := loadABI(rest[0])
	if err != nil {
		return err
	}
	ev, err := findEntry(entries, "event", rest[1])
	if err != nil {
		return err
	}
	data, err := decodeHex(rest[2])
	if err != nil {
		return err
	}
	var nonIdx []ABIParam
	for _, p := range ev.Inputs {
		if !p.Indexed {
			nonIdx = append(nonIdx, p)
		}
	}
	types := paramTypes(nonIdx)
	vals, err := decodeTuple(types, data, 0)
	if err != nil {
		return err
	}
	vi := 0
	ti := 0
	if !ev.Anonymous && len(topics) > 0 {
		ti = 1
	}
	for _, p := range ev.Inputs {
		t, _ := parseType(p.Type)
		if p.Indexed {
			if ti >= len(topics) {
				continue
			}
			td, _ := decodeHex(topics[ti])
			ti++
			if t.IsDynamic() {
				fmt.Printf("%s %s\n", t.String(), hex.EncodeToString(td))
			} else if vv, err := decodeSingle(t, td, 0, 0); err == nil {
				fmt.Printf("%s %s\n", t.String(), formatValue(vv))
			}
		} else {
			fmt.Printf("%s %s\n", t.String(), formatValue(vals[vi]))
			vi++
		}
	}
	return nil
}

func hasHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" || a == "-V" || a == "--version" {
			if a == "-V" || a == "--version" {
				fmt.Println("ethabi-cli 18.0.0")
			}
			return true
		}
	}
	return false
}

func loadABI(path string) ([]ABIEntry, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var e []ABIEntry
	return e, json.Unmarshal(b, &e)
}

func findEntry(entries []ABIEntry, typ, name string) (*ABIEntry, error) {
	var matches []*ABIEntry
	for i := range entries {
		if entries[i].Type != typ {
			continue
		}
		if entryMatches(entries[i], name) {
			matches = append(matches, &entries[i])
		}
	}
	if len(matches) == 0 {
		return nil, fmt.Errorf("Invalid name: %s", name)
	}
	if len(matches) > 1 {
		return nil, fmt.Errorf("More than one function found for name `%s`, try providing the full signature", name)
	}
	return matches[0], nil
}

func entryMatches(e ABIEntry, q string) bool {
	if q == e.Name {
		return true
	}
	if strings.HasPrefix(q, e.Name+"(") {
		in, out, ok := parseSignatureQuery(q, e.Name)
		if !ok {
			return false
		}
		if in != typeList(e.Inputs) {
			return false
		}
		return out == "" || out == typeList(e.Outputs)
	}
	return false
}

func parseSignatureQuery(q, name string) (string, string, bool) {
	if !strings.HasPrefix(q, name+"(") {
		return "", "", false
	}
	rest := q[len(name):]
	i := strings.Index(rest, ")")
	if i < 0 || !strings.HasPrefix(rest, "(") {
		return "", "", false
	}
	in := rest[1:i]
	tail := rest[i+1:]
	if tail == "" {
		return in, "", true
	}
	if !strings.HasPrefix(tail, ":(") || !strings.HasSuffix(tail, ")") {
		return "", "", false
	}
	return in, tail[2 : len(tail)-1], true
}

func typeList(ps []ABIParam) string {
	parts := make([]string, len(ps))
	for i, p := range ps {
		parts[i] = p.Type
	}
	return strings.Join(parts, ",")
}

func paramTypes(ps []ABIParam) []Type {
	out := make([]Type, len(ps))
	for i, p := range ps {
		out[i], _ = parseType(p.Type)
	}
	return out
}

var arrRe = regexp.MustCompile(`^(.*)\[([0-9]*)\]$`)

func parseType(s string) (Type, error) {
	if m := arrRe.FindStringSubmatch(s); m != nil {
		el, err := parseType(m[1])
		if err != nil {
			return Type{}, err
		}
		if m[2] == "" {
			return Type{Kind: "array", Array: nil, ArrayElem: &el}, nil
		}
		n, _ := strconv.Atoi(m[2])
		return Type{Kind: "array", Array: &n, ArrayElem: &el}, nil
	}
	switch {
	case s == "bool", s == "address", s == "string", s == "bytes":
		return Type{Kind: s}, nil
	case strings.HasPrefix(s, "uint"):
		n := 256
		if len(s) > 4 {
			n, _ = strconv.Atoi(s[4:])
		}
		return Type{Kind: "uint", Size: n}, nil
	case strings.HasPrefix(s, "int"):
		n := 256
		if len(s) > 3 {
			n, _ = strconv.Atoi(s[3:])
		}
		return Type{Kind: "int", Size: n}, nil
	case strings.HasPrefix(s, "bytes"):
		n, err := strconv.Atoi(s[5:])
		if err != nil || n < 1 || n > 32 {
			return Type{}, fmt.Errorf("invalid type %s", s)
		}
		return Type{Kind: "fixedbytes", Size: n}, nil
	}
	return Type{}, fmt.Errorf("invalid type %s", s)
}

func (t Type) String() string {
	if t.Kind == "array" {
		if t.Array == nil {
			return t.ArrayElem.String() + "[]"
		}
		return fmt.Sprintf("%s[%d]", t.ArrayElem.String(), *t.Array)
	}
	switch t.Kind {
	case "uint":
		return fmt.Sprintf("uint%d", t.Size)
	case "int":
		return fmt.Sprintf("int%d", t.Size)
	case "fixedbytes":
		return fmt.Sprintf("bytes%d", t.Size)
	default:
		return t.Kind
	}
}

func (t Type) IsDynamic() bool {
	if t.Kind == "string" || t.Kind == "bytes" {
		return true
	}
	if t.Kind == "array" {
		return t.Array == nil || t.ArrayElem.IsDynamic()
	}
	return false
}

func (t Type) StaticWords() int {
	if t.IsDynamic() {
		return 1
	}
	if t.Kind == "array" && t.Array != nil {
		return *t.Array * t.ArrayElem.StaticWords()
	}
	return 1
}

type Token struct {
	T Type
	V interface{}
}

func parseValues(types []Type, vals []string, lenient bool) ([]Token, error) {
	toks := make([]Token, 0, len(types))
	vi := 0
	for _, t := range types {
		if t.Kind == "array" && t.Array != nil && !strings.HasPrefix(next(vals, vi), "[") {
			n := *t.Array
			if vi+n > len(vals) {
				return nil, fmt.Errorf("Invalid data")
			}
			var arr []Token
			for j := 0; j < n; j++ {
				tv, err := parseValue(*t.ArrayElem, vals[vi+j], lenient)
				if err != nil {
					return nil, err
				}
				arr = append(arr, tv)
			}
			toks = append(toks, Token{T: t, V: arr})
			vi += n
			continue
		}
		if t.Kind == "array" && t.Array == nil && !strings.HasPrefix(next(vals, vi), "[") {
			var arr []Token
			for vi < len(vals) {
				tv, err := parseValue(*t.ArrayElem, vals[vi], lenient)
				if err != nil {
					return nil, err
				}
				arr = append(arr, tv)
				vi++
			}
			toks = append(toks, Token{T: t, V: arr})
			continue
		}
		if vi >= len(vals) {
			return nil, fmt.Errorf("Invalid data")
		}
		tv, err := parseValue(t, vals[vi], lenient)
		if err != nil {
			return nil, err
		}
		toks = append(toks, tv)
		vi++
	}
	if vi != len(vals) {
		return nil, fmt.Errorf("Invalid data")
	}
	return toks, nil
}

func next(vals []string, i int) string {
	if i >= len(vals) {
		return ""
	}
	return vals[i]
}

func parseValue(t Type, s string, lenient bool) (Token, error) {
	switch t.Kind {
	case "bool":
		return Token{T: t, V: s == "1" || strings.EqualFold(s, "true")}, nil
	case "uint":
		var n *big.Int
		if lenient {
			n, _ = new(big.Int).SetString(s, 10)
		} else {
			b, err := decodeHex(s)
			if err != nil {
				return Token{}, err
			}
			if len(b) != 32 {
				return Token{}, fmt.Errorf("Invalid data")
			}
			n = new(big.Int).SetBytes(b)
		}
		if n == nil {
			return Token{}, fmt.Errorf("Invalid data")
		}
		return Token{T: t, V: n}, nil
	case "int":
		n, ok := new(big.Int).SetString(s, 10)
		if !ok {
			b, err := decodeHex(s)
			if err != nil {
				return Token{}, err
			}
			n = new(big.Int).SetBytes(b)
		}
		return Token{T: t, V: n}, nil
	case "address":
		b, err := decodeHex(s)
		if err != nil || len(b) != 20 {
			return Token{}, fmt.Errorf("Invalid data")
		}
		return Token{T: t, V: b}, nil
	case "fixedbytes":
		b, err := decodeHex(s)
		if err != nil || len(b) != t.Size {
			return Token{}, fmt.Errorf("Invalid data")
		}
		return Token{T: t, V: b}, nil
	case "bytes":
		b, err := decodeHex(s)
		if err != nil {
			return Token{}, err
		}
		return Token{T: t, V: b}, nil
	case "string":
		return Token{T: t, V: []byte(s)}, nil
	case "array":
		var raw []string
		if strings.HasPrefix(s, "[") {
			if err := json.Unmarshal([]byte(s), &raw); err != nil {
				return Token{}, err
			}
		} else {
			raw = strings.Split(s, ",")
		}
		var arr []Token
		for _, r := range raw {
			tv, err := parseValue(*t.ArrayElem, strings.TrimSpace(r), lenient)
			if err != nil {
				return Token{}, err
			}
			arr = append(arr, tv)
		}
		if t.Array != nil && len(arr) != *t.Array {
			return Token{}, fmt.Errorf("Invalid data")
		}
		return Token{T: t, V: arr}, nil
	}
	return Token{}, fmt.Errorf("Invalid data")
}

func decodeHex(s string) ([]byte, error) {
	s = strings.TrimPrefix(strings.TrimPrefix(s, "0x"), "0X")
	if s == "" {
		return []byte{}, nil
	}
	return hex.DecodeString(s)
}

func encodeTuple(types []Type, toks []Token) ([]byte, error) {
	headSize := 0
	for _, t := range types {
		headSize += 32 * t.StaticWords()
	}
	var head, tail []byte
	for i, t := range types {
		enc, err := encodeToken(toks[i])
		if err != nil {
			return nil, err
		}
		if t.IsDynamic() {
			head = append(head, word(big.NewInt(int64(headSize+len(tail))))...)
			tail = append(tail, enc...)
		} else {
			head = append(head, enc...)
		}
	}
	return append(head, tail...), nil
}

func encodeToken(tok Token) ([]byte, error) {
	t := tok.T
	switch t.Kind {
	case "bool":
		if tok.V.(bool) {
			return word(big.NewInt(1)), nil
		}
		return make([]byte, 32), nil
	case "uint", "int":
		return word(tok.V.(*big.Int)), nil
	case "address":
		out := make([]byte, 32)
		copy(out[12:], tok.V.([]byte))
		return out, nil
	case "fixedbytes":
		out := make([]byte, 32)
		copy(out, tok.V.([]byte))
		return out, nil
	case "string", "bytes":
		b := tok.V.([]byte)
		out := word(big.NewInt(int64(len(b))))
		out = append(out, padRight(b)...)
		return out, nil
	case "array":
		arr := tok.V.([]Token)
		types := make([]Type, len(arr))
		for i := range arr {
			types[i] = *t.ArrayElem
		}
		body, err := encodeTuple(types, arr)
		if err != nil {
			return nil, err
		}
		if t.Array == nil {
			return append(word(big.NewInt(int64(len(arr)))), body...), nil
		}
		return body, nil
	}
	return nil, fmt.Errorf("Invalid data")
}

func word(n *big.Int) []byte {
	out := make([]byte, 32)
	if n.Sign() < 0 {
		two := new(big.Int).Lsh(big.NewInt(1), 256)
		n = new(big.Int).Add(two, n)
	}
	b := n.Bytes()
	copy(out[32-len(b):], b)
	return out
}

func padRight(b []byte) []byte {
	n := ((len(b) + 31) / 32) * 32
	out := make([]byte, n)
	copy(out, b)
	return out
}

func decodeTuple(types []Type, data []byte, base int) ([]Token, error) {
	vals := make([]Token, len(types))
	pos := base
	for i, t := range types {
		if pos+32 > len(data) {
			return nil, fmt.Errorf("Invalid data")
		}
		if t.IsDynamic() {
			off := int(new(big.Int).SetBytes(data[pos : pos+32]).Int64())
			v, err := decodeSingle(t, data, base+off, base)
			if err != nil {
				return nil, err
			}
			vals[i] = v
		} else {
			v, err := decodeSingle(t, data, pos, base)
			if err != nil {
				return nil, err
			}
			vals[i] = v
		}
		pos += 32 * t.StaticWords()
	}
	return vals, nil
}

func decodeSingle(t Type, data []byte, pos int, base int) (Token, error) {
	if pos+32 > len(data) {
		return Token{}, fmt.Errorf("Invalid data")
	}
	switch t.Kind {
	case "bool":
		return Token{T: t, V: data[pos+31] != 0}, nil
	case "uint":
		return Token{T: t, V: new(big.Int).SetBytes(data[pos : pos+32])}, nil
	case "int":
		n := new(big.Int).SetBytes(data[pos : pos+32])
		if data[pos]&0x80 != 0 {
			n.Sub(n, new(big.Int).Lsh(big.NewInt(1), 256))
		}
		return Token{T: t, V: n}, nil
	case "address":
		return Token{T: t, V: append([]byte{}, data[pos+12:pos+32]...)}, nil
	case "fixedbytes":
		return Token{T: t, V: append([]byte{}, data[pos:pos+t.Size]...)}, nil
	case "string", "bytes":
		l := int(new(big.Int).SetBytes(data[pos : pos+32]).Int64())
		start := pos + 32
		if start+l > len(data) {
			return Token{}, fmt.Errorf("Invalid data")
		}
		return Token{T: t, V: append([]byte{}, data[start:start+l]...)}, nil
	case "array":
		l := 0
		start := pos
		if t.Array == nil {
			l = int(new(big.Int).SetBytes(data[pos : pos+32]).Int64())
			start = pos + 32
		} else {
			l = *t.Array
		}
		types := make([]Type, l)
		for i := range types {
			types[i] = *t.ArrayElem
		}
		vals, err := decodeTuple(types, data, start)
		if err != nil {
			return Token{}, err
		}
		return Token{T: t, V: vals}, nil
	}
	return Token{}, fmt.Errorf("Invalid data")
}

func formatValue(tok Token) string {
	switch tok.T.Kind {
	case "bool":
		if tok.V.(bool) {
			return "true"
		}
		return "false"
	case "uint", "int":
		return tok.V.(*big.Int).String()
	case "address":
		return hex.EncodeToString(tok.V.([]byte))
	case "fixedbytes", "bytes":
		return hex.EncodeToString(tok.V.([]byte))
	case "string":
		return string(tok.V.([]byte))
	case "array":
		arr := tok.V.([]Token)
		parts := make([]string, len(arr))
		for i := range arr {
			parts[i] = formatValue(arr[i])
		}
		return "[" + strings.Join(parts, ", ") + "]"
	}
	return ""
}

func Keccak256(data []byte) []byte {
	st := make([]uint64, 25)
	rate := 136
	for len(data) >= rate {
		xorBlock(st, data[:rate])
		keccakF1600(st)
		data = data[rate:]
	}
	block := make([]byte, rate)
	copy(block, data)
	block[len(data)] = 0x01
	block[rate-1] ^= 0x80
	xorBlock(st, block)
	keccakF1600(st)
	out := make([]byte, 32)
	for i := 0; i < 4; i++ {
		put64(out[i*8:], st[i])
	}
	return out
}

func xorBlock(st []uint64, b []byte) {
	for i := 0; i < len(b)/8; i++ {
		st[i] ^= get64(b[i*8:])
	}
}

func get64(b []byte) uint64 {
	var v uint64
	for i := 0; i < 8; i++ {
		v |= uint64(b[i]) << (8 * i)
	}
	return v
}

func put64(b []byte, v uint64) {
	for i := 0; i < 8; i++ {
		b[i] = byte(v >> (8 * i))
	}
}

var rc = []uint64{
	0x0000000000000001, 0x0000000000008082, 0x800000000000808a, 0x8000000080008000,
	0x000000000000808b, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
	0x000000000000008a, 0x0000000000000088, 0x0000000080008009, 0x000000008000000a,
	0x000000008000808b, 0x800000000000008b, 0x8000000000008089, 0x8000000000008003,
	0x8000000000008002, 0x8000000000000080, 0x000000000000800a, 0x800000008000000a,
	0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
}

var rotc = []uint{1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14, 27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44}
var piln = []int{10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1}

func keccakF1600(a []uint64) {
	for round := 0; round < 24; round++ {
		var c [5]uint64
		for i := 0; i < 5; i++ {
			c[i] = a[i] ^ a[i+5] ^ a[i+10] ^ a[i+15] ^ a[i+20]
		}
		for i := 0; i < 5; i++ {
			d := c[(i+4)%5] ^ bitsRotateLeft64(c[(i+1)%5], 1)
			for j := 0; j < 25; j += 5 {
				a[j+i] ^= d
			}
		}
		t := a[1]
		for i := 0; i < 24; i++ {
			j := piln[i]
			c0 := a[j]
			a[j] = bitsRotateLeft64(t, int(rotc[i]))
			t = c0
		}
		for j := 0; j < 25; j += 5 {
			for i := 0; i < 5; i++ {
				c[i] = a[j+i]
			}
			for i := 0; i < 5; i++ {
				a[j+i] ^= (^c[(i+1)%5]) & c[(i+2)%5]
			}
		}
		a[0] ^= rc[round]
	}
}

func bitsRotateLeft64(x uint64, k int) uint64 {
	return (x << uint(k)) | (x >> uint(64-k))
}

var _ = errors.New
