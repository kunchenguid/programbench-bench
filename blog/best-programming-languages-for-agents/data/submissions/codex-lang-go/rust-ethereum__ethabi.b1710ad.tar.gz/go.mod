module ethabi_re

go 1.21
