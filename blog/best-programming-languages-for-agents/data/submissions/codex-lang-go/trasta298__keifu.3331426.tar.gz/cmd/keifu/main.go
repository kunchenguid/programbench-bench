package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const version = "keifu 0.2.3"

type commit struct {
	Hash      string
	Short     string
	Author    string
	Email     string
	Date      string
	DateShort string
	Subject   string
	Body      string
	Refs      []string
	Branch    string
	Files     []fileStat
	Added     int
	Deleted   int
}

type fileStat struct {
	Status  string
	Path    string
	Added   int
	Deleted int
}

type app struct {
	root     string
	repoName string
	branch   string
	commits  []commit
	selected int
	showHelp bool
	message  string
}

func main() {
	if code := run(os.Args[1:], os.Stdout, os.Stderr); code != 0 {
		os.Exit(code)
	}
}

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) > 0 {
		switch args[0] {
		case "-h", "--help":
			fmt.Fprint(stdout, "A TUI tool to visualize Git commit graphs with branch genealogy\n\nUsage: executable\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n")
			return 0
		case "-V", "--version":
			fmt.Fprintln(stdout, version)
			return 0
		default:
			fmt.Fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable\n\nFor more information, try '--help'.\n", args[0])
			return 2
		}
	}

	root, err := gitOutput(".", "rev-parse", "--show-toplevel")
	if err != nil {
		fmt.Fprint(stderr, "Error: Git repository not found. Please run inside a Git repository.\n\nCaused by:\n    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n")
		return 1
	}
	root = strings.TrimSpace(root)
	if !isTTY(os.Stdin) || !isTTY(os.Stdout) {
		fmt.Fprintln(stderr, "Error: No such device or address (os error 6)")
		return 1
	}

	a := &app{root: root, repoName: filepath.Base(root)}
	a.refresh()
	return a.loop()
}

func (a *app) refresh() {
	a.branch = strings.TrimSpace(mustGit(a.root, "branch", "--show-current"))
	if a.branch == "" {
		a.branch = "DETACHED"
	}
	a.commits = loadCommits(a.root)
	if a.selected >= len(a.commits) {
		a.selected = len(a.commits) - 1
	}
	if a.selected < 0 {
		a.selected = 0
	}
}

func (a *app) loop() int {
	enterAlt()
	defer leaveAlt()
	raw := setRaw()
	defer raw()
	a.render()
	reader := bufio.NewReader(os.Stdin)
	for {
		b, err := reader.ReadByte()
		if err != nil {
			return 0
		}
		switch b {
		case 'q', 27:
			return 0
		case 'j':
			if a.selected+1 < len(a.commits) {
				a.selected++
			}
		case 'k':
			if a.selected > 0 {
				a.selected--
			}
		case 'g':
			a.selected = 0
		case 'G':
			if len(a.commits) > 0 {
				a.selected = len(a.commits) - 1
			}
		case '?':
			a.showHelp = !a.showHelp
		case 'R':
			a.refresh()
			a.message = "refreshed"
		case 'f':
			if err := runGit(a.root, "fetch", "origin"); err != nil {
				a.message = "fetch failed: " + oneLine(err.Error())
			} else {
				a.refresh()
				a.message = "fetched origin"
			}
		case '\r', '\n':
			a.checkoutSelected()
		case 'b':
			a.message = "branch creation requires an interactive name"
		case 'd':
			a.message = "delete branch is available for local non-HEAD branches"
		case '[':
			a.jumpLabel(-1)
		case ']', '\t':
			a.jumpLabel(1)
		case '@':
			a.jumpHead()
		}
		a.render()
	}
}

func (a *app) checkoutSelected() {
	if len(a.commits) == 0 {
		return
	}
	c := a.commits[a.selected]
	if c.Hash == "working tree" {
		a.message = "cannot checkout uncommitted changes"
		return
	}
	target := c.Branch
	if target == "" {
		target = c.Hash
	}
	if err := runGit(a.root, "checkout", target); err != nil {
		a.message = "checkout failed: " + oneLine(err.Error())
		return
	}
	a.refresh()
	a.message = "checked out " + target
}

func (a *app) jumpLabel(dir int) {
	if len(a.commits) == 0 {
		return
	}
	i := a.selected
	for {
		i += dir
		if i < 0 || i >= len(a.commits) {
			return
		}
		if len(a.commits[i].Refs) > 0 {
			a.selected = i
			return
		}
	}
}

func (a *app) jumpHead() {
	head := strings.TrimSpace(mustGit(a.root, "rev-parse", "HEAD"))
	for i, c := range a.commits {
		if c.Hash == head {
			a.selected = i
			return
		}
	}
}

func loadCommits(root string) []commit {
	format := "%H%x1f%h%x1f%an%x1f%ae%x1f%ad%x1f%D%x1f%s%x1f%b%x1e"
	out := mustGit(root, "log", "--all", "--max-count=500", "--date=format:%Y-%m-%d %H:%M:%S", "--pretty=format:"+format)
	var commits []commit
	for _, rec := range strings.Split(out, "\x1e") {
		rec = strings.Trim(rec, "\n\r")
		if rec == "" {
			continue
		}
		p := strings.SplitN(rec, "\x1f", 8)
		if len(p) < 8 {
			continue
		}
		c := commit{Hash: p[0], Short: p[1], Author: p[2], Email: p[3], Date: p[4], DateShort: shortDate(p[4]), Subject: p[6], Body: strings.TrimSpace(p[7])}
		c.Refs, c.Branch = parseRefs(p[5])
		c.Files, c.Added, c.Deleted = loadStats(root, c.Hash)
		commits = append(commits, c)
	}
	if hasUncommitted(root) {
		files, added, deleted := loadWorktreeStats(root)
		dirty := commit{
			Hash:      "working tree",
			Short:     "-------",
			Author:    "Working Tree",
			Date:      time.Now().Format("2006-01-02 15:04:05"),
			DateShort: time.Now().Format("2006-01-02"),
			Subject:   "uncommitted changes",
			Files:     files,
			Added:     added,
			Deleted:   deleted,
		}
		commits = append([]commit{dirty}, commits...)
	}
	return commits
}

func parseRefs(s string) ([]string, string) {
	var refs []string
	branch := ""
	for _, part := range strings.Split(s, ",") {
		r := strings.TrimSpace(part)
		r = strings.TrimPrefix(r, "HEAD -> ")
		if r == "" || r == "HEAD" || strings.HasPrefix(r, "tag: ") {
			continue
		}
		refs = append(refs, r)
		if branch == "" && !strings.HasPrefix(r, "origin/") {
			branch = r
		}
	}
	if branch == "" && len(refs) > 0 {
		branch = refs[0]
	}
	return refs, branch
}

func loadStats(root, hash string) ([]fileStat, int, int) {
	parent := strings.TrimSpace(mustGit(root, "rev-list", "--parents", "-n", "1", hash))
	statArgs := []string{"show", "--numstat", "--format=", "--find-renames", hash}
	nameArgs := []string{"show", "--name-status", "--format=", "--find-renames", hash}
	if len(strings.Fields(parent)) == 1 {
		statArgs = []string{"diff-tree", "--root", "--numstat", "--no-commit-id", "-r", hash}
		nameArgs = []string{"diff-tree", "--root", "--name-status", "--no-commit-id", "-r", hash}
	}
	out := mustGit(root, statArgs...)
	stats := map[string]fileStat{}
	totalA, totalD := 0, 0
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) >= 3 && isNum(fields[0]) && isNum(fields[1]) {
			a, _ := strconv.Atoi(fields[0])
			d, _ := strconv.Atoi(fields[1])
			path := strings.Join(fields[2:], " ")
			stats[path] = fileStat{Status: "M", Path: path, Added: a, Deleted: d}
			totalA += a
			totalD += d
		}
	}
	statusOut := mustGit(root, nameArgs...)
	var files []fileStat
	for _, line := range strings.Split(statusOut, "\n") {
		f := strings.Fields(line)
		if len(f) >= 2 {
			path := f[len(f)-1]
			fs := stats[path]
			if fs.Path == "" {
				fs.Path = path
			}
			fs.Status = f[0][:1]
			files = append(files, fs)
		}
	}
	if len(files) > 50 {
		files = files[:50]
	}
	return files, totalA, totalD
}

func loadWorktreeStats(root string) ([]fileStat, int, int) {
	var files []fileStat
	totalA, totalD := 0, 0
	for _, args := range [][]string{{"diff", "--numstat"}, {"diff", "--cached", "--numstat"}} {
		out := mustGit(root, args...)
		for _, line := range strings.Split(out, "\n") {
			f := strings.Fields(line)
			if len(f) < 3 || !isNum(f[0]) || !isNum(f[1]) {
				continue
			}
			a, _ := strconv.Atoi(f[0])
			d, _ := strconv.Atoi(f[1])
			path := strings.Join(f[2:], " ")
			files = append(files, fileStat{Status: "M", Path: path, Added: a, Deleted: d})
			totalA += a
			totalD += d
		}
	}
	if len(files) > 50 {
		files = files[:50]
	}
	return files, totalA, totalD
}

func (a *app) render() {
	w, h := termSize()
	if w < 60 {
		w = 60
	}
	if h < 20 {
		h = 20
	}
	fmt.Print("\033[H\033[2J\033[?25l")
	if a.showHelp {
		a.renderHelp(w, h)
		return
	}
	topH := h - 10
	if topH < 8 {
		topH = 8
	}
	if topH > h-5 {
		topH = h - 5
	}
	boxTop("Commits", w)
	inside := w - 2
	for i := 0; i < topH-2; i++ {
		line := ""
		if i < len(a.commits) {
			line = a.commitLine(i, inside)
		}
		boxLine(line, inside, i == a.selected)
	}
	boxBottom(w)
	detailH := h - topH - 2
	if detailH < 5 {
		detailH = 5
	}
	left := w / 2
	right := w - left
	boxPairTop("Commit Detail", left, "Changed Files", right)
	c := commit{}
	if len(a.commits) > 0 {
		c = a.commits[a.selected]
	}
	details := []string{"Commit: " + c.Hash, "Author: " + c.Author + email(c.Email), "Date:   " + c.Date, "", c.Subject}
	if c.Body != "" {
		details = append(details, strings.Split(c.Body, "\n")...)
	}
	files := []string{fmt.Sprintf("%d files changed  +%d -%d", len(c.Files), c.Added, c.Deleted), ""}
	for _, f := range c.Files {
		files = append(files, fmt.Sprintf(" %s  %s +%d -%d", f.Status, f.Path, f.Added, f.Deleted))
	}
	for i := 0; i < detailH-2; i++ {
		l, r := "", ""
		if i < len(details) {
			l = details[i]
		}
		if i < len(files) {
			r = files[i]
		}
		boxPairLine(l, left, r, right)
	}
	boxPairBottom(left, right)
	status := fmt.Sprintf(" %s  %s  j/k move  Enter checkout  b branch  f fetch  ? help  q quit", a.repoName, a.branch)
	if a.message != "" {
		status += "  " + a.message
	}
	fmt.Print(trunc(status, w))
}

func (a *app) commitLine(i, width int) string {
	c := a.commits[i]
	label := ""
	if len(c.Refs) > 0 {
		label = "[" + c.Refs[0]
		if len(c.Refs) > 1 {
			label += fmt.Sprintf(" +%d", len(c.Refs)-1)
		}
		label += "] "
	}
	graph := "◉"
	author := c.Author
	if len(author) > 12 {
		author = author[:12]
	}
	right := fmt.Sprintf("%s  %s  %s", c.DateShort, author, c.Short)
	left := fmt.Sprintf(" %s  %s%s", graph, label, c.Subject)
	gap := width - runeLen(left) - runeLen(right)
	if gap < 1 {
		return trunc(left+" "+right, width)
	}
	return left + strings.Repeat(" ", gap) + right
}

func (a *app) renderHelp(w, h int) {
	boxTop("Help", w)
	lines := []string{
		"Navigation:",
		"  j / Down      Move down",
		"  k / Up        Move up",
		"  g / Home      Go to top",
		"  G / End       Go to bottom",
		"  [ / ]         Jump between branch labels",
		"  @             Jump to HEAD",
		"",
		"Git operations:",
		"  Enter         Checkout selected branch/commit",
		"  b             Create branch at selected commit",
		"  d             Delete local branch",
		"  f             Fetch from origin",
		"",
		"Other:",
		"  R             Refresh",
		"  ?             Toggle help",
		"  q / Esc       Quit",
	}
	for i := 0; i < h-3; i++ {
		line := ""
		if i < len(lines) {
			line = lines[i]
		}
		boxLine(line, w-2, false)
	}
	boxBottom(w)
}

func boxTop(title string, w int) {
	fmt.Printf("┌ %s %s┐\n", title, strings.Repeat("─", max(0, w-runeLen(title)-4)))
}

func boxBottom(w int) {
	fmt.Printf("└%s┘\n", strings.Repeat("─", max(0, w-2)))
}

func boxLine(s string, width int, selected bool) {
	if selected {
		fmt.Print("│\033[1m\033[48;5;8m" + pad(trunc(s, width), width) + "\033[0m│\n")
	} else {
		fmt.Print("│" + pad(trunc(s, width), width) + "│\n")
	}
}

func boxPairTop(t1 string, w1 int, t2 string, w2 int) {
	fmt.Printf("┌ %s %s┐┌ %s %s┐\n", t1, strings.Repeat("─", max(0, w1-runeLen(t1)-4)), t2, strings.Repeat("─", max(0, w2-runeLen(t2)-4)))
}

func boxPairLine(l string, w1 int, r string, w2 int) {
	fmt.Printf("│%s││%s│\n", pad(trunc(l, w1-2), w1-2), pad(trunc(r, w2-2), w2-2))
}

func boxPairBottom(w1, w2 int) {
	fmt.Printf("└%s┘└%s┘\n", strings.Repeat("─", max(0, w1-2)), strings.Repeat("─", max(0, w2-2)))
}

func termSize() (int, int) {
	cmd := exec.Command("stty", "size")
	cmd.Stdin = os.Stdin
	out, err := cmd.Output()
	if err == nil {
		f := strings.Fields(string(out))
		if len(f) == 2 {
			h, _ := strconv.Atoi(f[0])
			w, _ := strconv.Atoi(f[1])
			if w > 0 && h > 0 {
				return w, h
			}
		}
	}
	return 120, 30
}

func setRaw() func() {
	cmd := exec.Command("stty", "-g")
	cmd.Stdin = os.Stdin
	old, err := cmd.Output()
	if err != nil {
		return func() {}
	}
	raw := exec.Command("stty", "-echo", "-icanon", "min", "1", "time", "0")
	raw.Stdin = os.Stdin
	_ = raw.Run()
	return func() {
		restore := exec.Command("stty", string(bytes.TrimSpace(old)))
		restore.Stdin = os.Stdin
		_ = restore.Run()
	}
}

func enterAlt() { fmt.Print("\033[?1049h\033[?25l") }
func leaveAlt() { fmt.Print("\033[0m\033[?25h\033[?1049l") }

func isTTY(f *os.File) bool {
	info, err := f.Stat()
	return err == nil && (info.Mode()&os.ModeCharDevice) != 0
}

func gitOutput(dir string, args ...string) (string, error) {
	cmd := exec.Command("git", args...)
	cmd.Dir = dir
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if err != nil {
		return "", errors.New(strings.TrimSpace(stderr.String()))
	}
	return string(out), nil
}

func mustGit(dir string, args ...string) string {
	out, _ := gitOutput(dir, args...)
	return out
}

func runGit(dir string, args ...string) error {
	cmd := exec.Command("git", args...)
	cmd.Dir = dir
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("%s", strings.TrimSpace(string(out)))
	}
	return nil
}

func hasUncommitted(root string) bool {
	out := mustGit(root, "status", "--porcelain")
	for _, line := range strings.Split(out, "\n") {
		if strings.TrimSpace(line) == "" || strings.HasPrefix(line, "??") {
			continue
		}
		return true
	}
	return false
}

func isNum(s string) bool {
	if s == "-" || s == "" {
		return false
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

func shortDate(s string) string {
	if len(s) >= 10 {
		return s[:10]
	}
	return s
}

func email(s string) string {
	if s == "" {
		return ""
	}
	return " <" + s + ">"
}

func oneLine(s string) string {
	return strings.Join(strings.Fields(s), " ")
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func runeLen(s string) int { return len([]rune(stripANSI(s))) }

func trunc(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n <= 1 {
		return string(r[:max(0, n)])
	}
	return string(r[:n-1]) + "…"
}

func pad(s string, n int) string {
	l := runeLen(s)
	if l >= n {
		return s
	}
	return s + strings.Repeat(" ", n-l)
}

func stripANSI(s string) string { return s }
