package main

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

const helpText = `dog ● command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information
`

const colorHelpText = "dog \x1b[1;32m●\x1b[0m command-line DNS client\n\n\x1b[4mUsage:\x1b[0m\n  \x1b[1mdog\x1b[0m \x1b[1;33m[OPTIONS]\x1b[0m [--] \x1b[32m<arguments>\x1b[0m\n\nExamples:\n  dog example.net                          Query a domain using default settings\n  dog example.net MX                       ...looking up MX records instead\n  dog example.net MX @1.1.1.1              ...using a specific nameserver instead\n  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP\n  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments\n\nQuery options:\n  <arguments>              Human-readable host names, nameservers, types, or classes\n  -q, --query=HOST         Host name or domain name to query\n  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)\n  -n, --nameserver=ADDR    Address of the nameserver to send packets to\n  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)\n\nSending options:\n  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)\n  --txid=NUMBER            Set the transaction ID to a specific value\n  -Z=TWEAKS                Set uncommon protocol-level tweaks\n\nProtocol options:\n  -U, --udp                Use the DNS protocol over UDP\n  -T, --tcp                Use the DNS protocol over TCP\n  -S, --tls                Use the DNS-over-TLS protocol\n  -H, --https              Use the DNS-over-HTTPS protocol\n\nOutput options:\n  -1, --short              Short mode: display nothing but the first result\n  -J, --json               Display the output as JSON\n  --color, --colour=WHEN   When to colourise the output (always, automatic, never)\n  --seconds                Do not format durations, display them as seconds\n  --time                   Print how long the response took to arrive\n\nMeta options:\n  -?, --help               Print list of command-line options\n  -v, --version            Print version information\n"

var typeCodes = map[string]uint16{"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "HINFO": 13, "MX": 15, "TXT": 16, "AAAA": 28, "SRV": 33, "NAPTR": 35, "CAA": 257, "TLSA": 52, "SSHFP": 44, "LOC": 29, "OPT": 41, "ANY": 255, "AFSDB": 18, "IXFR": 251}
var codeTypes = reverseTypes()
var classCodes = map[string]uint16{"IN": 1, "CH": 3, "HS": 4}
var codeClasses = map[uint16]string{1: "IN", 3: "CH", 4: "HS"}

type opts struct {
	queries, types, nss, classes []string
	edns                         string
	txid                         int
	haveTxid, short, json        bool
	seconds, showTime            bool
	transport, color             string
	tweaks                       []string
}

type question struct {
	Name  string `json:"name"`
	Class string `json:"class"`
	Type  string `json:"type"`
}

type record struct {
	Name  string      `json:"name"`
	Class string      `json:"class"`
	TTL   uint32      `json:"ttl"`
	Type  string      `json:"type"`
	Data  interface{} `json:"data"`
	text  string
}

type response struct {
	Queries     []question `json:"queries"`
	Answers     []record   `json:"answers"`
	Authorities []record   `json:"authorities"`
	Additionals []record   `json:"additionals"`
	Status      string     `json:"-"`
}

func main() {
	o, meta, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, "dog: Invalid options: "+err.Error())
		os.Exit(3)
	}
	if meta == "help" {
		if o.color == "always" {
			fmt.Print(colorHelpText)
		} else {
			fmt.Print(helpText)
		}
		return
	}
	if meta == "version" {
		fmt.Print("dog ● command-line DNS client\nv0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)\nmhttps://dns.lookup.dog/\n")
		return
	}
	if len(o.queries) == 0 {
		fmt.Print(helpText)
		return
	}
	if len(o.types) == 0 {
		o.types = []string{"A"}
	}
	if len(o.classes) == 0 {
		o.classes = []string{"IN"}
	}
	if len(o.nss) == 0 {
		ns, err := systemNS()
		if err != nil {
			fmt.Fprintln(os.Stderr, "Error [system]: "+err.Error())
			os.Exit(4)
		}
		o.nss = []string{ns}
	}
	start := time.Now()
	var responses []response
	exit := 0
	var shortPrinted bool
	for _, q := range o.queries {
		for _, typ := range o.types {
			for _, class := range o.classes {
				for _, ns := range o.nss {
					resp, err := doQuery(o, q, typ, class, ns)
					if err != nil {
						fmt.Fprintln(os.Stderr, "Error [network]: "+err.Error())
						exit = 1
						continue
					}
					responses = append(responses, resp)
					if o.short && !shortPrinted {
						for _, r := range resp.Answers {
							if r.text != "" {
								fmt.Println(shortValue(r))
								shortPrinted = true
								break
							}
						}
					}
				}
			}
		}
	}
	if o.short {
		if !shortPrinted {
			fmt.Println("No results")
			os.Exit(2)
		}
		return
	}
	if o.json {
		out, _ := json.Marshal(map[string]interface{}{"responses": responses})
		fmt.Println(string(out))
	} else {
		printTable(responses, o.seconds)
	}
	if o.showTime {
		fmt.Printf("Ran in %s\n", formatRun(time.Since(start), o.seconds))
	}
	if exit != 0 {
		os.Exit(exit)
	}
}

func parseArgs(args []string) (opts, string, error) {
	o := opts{edns: "hide", txid: -1, transport: "udp", color: "automatic"}
	positional := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if !positional && a == "--" {
			positional = true
			continue
		}
		if !positional && strings.HasPrefix(a, "-") && a != "-" {
			name, val, hasEq := splitOpt(a)
			need := func() (string, error) {
				if hasEq {
					return val, nil
				}
				if i+1 >= len(args) {
					return "", fmt.Errorf("Argument to option '%s' missing", strings.TrimLeft(name, "-"))
				}
				i++
				return args[i], nil
			}
			switch name {
			case "-?", "--help":
				return o, "help", nil
			case "-v", "--version":
				return o, "version", nil
			case "-q", "--query":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				o.queries = append(o.queries, v)
			case "-t", "--type":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				if !validType(v) {
					return o, "", fmt.Errorf("Invalid query type %q", v)
				}
				o.types = append(o.types, strings.ToUpper(v))
			case "-n", "--nameserver":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				o.nss = append(o.nss, strings.TrimPrefix(v, "@"))
			case "--class":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				if _, ok := classCodes[strings.ToUpper(v)]; !ok {
					return o, "", fmt.Errorf("Invalid query class %q", v)
				}
				o.classes = append(o.classes, strings.ToUpper(v))
			case "--edns":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				if v != "disable" && v != "hide" && v != "show" {
					return o, "", fmt.Errorf("Invalid EDNS setting %q", v)
				}
				o.edns = v
			case "--txid":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				n, er := strconv.Atoi(v)
				if er != nil || n < 0 || n > 65535 {
					return o, "", fmt.Errorf("Invalid transaction ID %q", v)
				}
				o.txid = n
				o.haveTxid = true
			case "-Z":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				if !validTweak(v) {
					return o, "", fmt.Errorf("Invalid protocol tweak %q", v)
				}
				o.tweaks = append(o.tweaks, v)
			case "-U", "--udp":
				o.transport = "udp"
			case "-T", "--tcp":
				o.transport = "tcp"
			case "-S", "--tls":
				o.transport = "tls"
			case "-H", "--https":
				o.transport = "https"
			case "-1", "--short":
				o.short = true
			case "-J", "--json":
				o.json = true
			case "--color", "--colour":
				v, e := need()
				if e != nil {
					return o, "", e
				}
				if v != "always" && v != "automatic" && v != "never" {
					return o, "", fmt.Errorf("Invalid colour setting %q", v)
				}
				o.color = v
			case "--seconds":
				o.seconds = true
			case "--time":
				o.showTime = true
			default:
				return o, "", fmt.Errorf("Unrecognized option: '%s'", strings.TrimLeft(name, "-"))
			}
		} else {
			classifyArg(a, &o)
		}
	}
	return o, "", nil
}

func splitOpt(a string) (string, string, bool) {
	if strings.HasPrefix(a, "-Z") && len(a) > 2 && a[2] == '=' {
		return "-Z", a[3:], true
	}
	if i := strings.IndexByte(a, '='); i >= 0 {
		return a[:i], a[i+1:], true
	}
	return a, "", false
}

func classifyArg(a string, o *opts) {
	if strings.HasPrefix(a, "@") {
		o.nss = append(o.nss, strings.TrimPrefix(a, "@"))
		return
	}
	u := strings.ToUpper(a)
	if validType(u) {
		o.types = append(o.types, u)
	} else if _, ok := classCodes[u]; ok {
		o.classes = append(o.classes, u)
	} else {
		o.queries = append(o.queries, a)
	}
}

func validType(v string) bool { _, ok := typeCodes[strings.ToUpper(v)]; return ok }
func validTweak(v string) bool {
	return v == "aa" || v == "ad" || v == "cd" || (strings.HasPrefix(v, "bufsize=") && v != "bufsize=")
}

func systemNS() (string, error) {
	b, err := os.ReadFile("/etc/resolv.conf")
	if err != nil {
		return "", err
	}
	for _, l := range strings.Split(string(b), "\n") {
		f := strings.Fields(l)
		if len(f) >= 2 && f[0] == "nameserver" {
			return f[1], nil
		}
	}
	return "", errors.New("No nameservers found")
}

func doQuery(o opts, name, typ, class, ns string) (response, error) {
	id := uint16(rand.New(rand.NewSource(time.Now().UnixNano())).Intn(65536))
	if o.haveTxid {
		id = uint16(o.txid)
	}
	packet := buildQuery(id, name, typeCodes[typ], classCodes[class], o)
	raw, err := exchange(packet, ns, o.transport)
	if err != nil {
		return response{}, err
	}
	return parseResponse(raw)
}

func buildQuery(id uint16, name string, typ, class uint16, o opts) []byte {
	var b bytes.Buffer
	binary.Write(&b, binary.BigEndian, id)
	flags := uint16(0x0100)
	for _, t := range o.tweaks {
		if t == "aa" {
			flags |= 0x0400
		}
		if t == "ad" {
			flags |= 0x0020
		}
		if t == "cd" {
			flags |= 0x0010
		}
	}
	binary.Write(&b, binary.BigEndian, flags)
	binary.Write(&b, binary.BigEndian, uint16(1))
	binary.Write(&b, binary.BigEndian, uint16(0))
	binary.Write(&b, binary.BigEndian, uint16(0))
	ar := uint16(0)
	if o.edns != "disable" {
		ar = 1
	}
	binary.Write(&b, binary.BigEndian, ar)
	writeName(&b, name)
	binary.Write(&b, binary.BigEndian, typ)
	binary.Write(&b, binary.BigEndian, class)
	if ar == 1 {
		b.WriteByte(0)
		binary.Write(&b, binary.BigEndian, uint16(41))
		size := uint16(512)
		for _, t := range o.tweaks {
			if strings.HasPrefix(t, "bufsize=") {
				if n, err := strconv.Atoi(strings.TrimPrefix(t, "bufsize=")); err == nil {
					size = uint16(n)
				}
			}
		}
		binary.Write(&b, binary.BigEndian, size)
		binary.Write(&b, binary.BigEndian, uint32(0))
		binary.Write(&b, binary.BigEndian, uint16(0))
	}
	return b.Bytes()
}

func writeName(b *bytes.Buffer, n string) {
	n = strings.TrimSuffix(n, ".")
	if n == "" {
		b.WriteByte(0)
		return
	}
	for _, p := range strings.Split(n, ".") {
		b.WriteByte(byte(len(p)))
		b.WriteString(p)
	}
	b.WriteByte(0)
}

func exchange(packet []byte, ns, transport string) ([]byte, error) {
	if transport == "https" {
		return exchangeHTTPS(packet, ns)
	}
	addr := ns
	if !strings.Contains(addr, ":") {
		if transport == "tls" {
			addr += ":853"
		} else {
			addr += ":53"
		}
	}
	if transport == "udp" {
		c, err := net.DialTimeout("udp", addr, 4*time.Second)
		if err != nil {
			return nil, err
		}
		defer c.Close()
		c.SetDeadline(time.Now().Add(5 * time.Second))
		if _, err = c.Write(packet); err != nil {
			return nil, err
		}
		buf := make([]byte, 65536)
		n, err := c.Read(buf)
		if err != nil {
			return nil, err
		}
		return buf[:n], nil
	}
	var c net.Conn
	var err error
	if transport == "tls" {
		c, err = tls.DialWithDialer(&net.Dialer{Timeout: 4 * time.Second}, "tcp", addr, &tls.Config{ServerName: strings.Split(ns, ":")[0]})
	} else {
		c, err = net.DialTimeout("tcp", addr, 4*time.Second)
	}
	if err != nil {
		return nil, err
	}
	defer c.Close()
	c.SetDeadline(time.Now().Add(5 * time.Second))
	var framed bytes.Buffer
	binary.Write(&framed, binary.BigEndian, uint16(len(packet)))
	framed.Write(packet)
	if _, err = c.Write(framed.Bytes()); err != nil {
		return nil, err
	}
	var ln uint16
	if err = binary.Read(c, binary.BigEndian, &ln); err != nil {
		return nil, err
	}
	resp := make([]byte, ln)
	_, err = io.ReadFull(c, resp)
	return resp, err
}

func exchangeHTTPS(packet []byte, ns string) ([]byte, error) {
	if !strings.HasPrefix(ns, "http://") && !strings.HasPrefix(ns, "https://") {
		return nil, errors.New("invalid HTTPS nameserver URL")
	}
	u, err := url.Parse(ns)
	if err != nil {
		return nil, err
	}
	q := u.Query()
	q.Set("dns", base64.RawURLEncoding.EncodeToString(packet))
	u.RawQuery = q.Encode()
	req, _ := http.NewRequest("GET", u.String(), nil)
	req.Header.Set("Accept", "application/dns-message")
	cl := http.Client{Timeout: 8 * time.Second}
	resp, err := cl.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return nil, fmt.Errorf("HTTP status %s", resp.Status)
	}
	return io.ReadAll(resp.Body)
}

func parseResponse(d []byte) (response, error) {
	if len(d) < 12 {
		return response{}, errors.New("Malformed DNS packet")
	}
	r := response{
		Queries:     []question{},
		Answers:     []record{},
		Authorities: []record{},
		Additionals: []record{},
	}
	if code := int(d[3] & 0x0f); code != 0 {
		r.Status = rcodeName(code)
	}
	qd, an, ns, ar := int(binary.BigEndian.Uint16(d[4:6])), int(binary.BigEndian.Uint16(d[6:8])), int(binary.BigEndian.Uint16(d[8:10])), int(binary.BigEndian.Uint16(d[10:12]))
	off := 12
	for i := 0; i < qd; i++ {
		n, no, err := readName(d, off)
		if err != nil {
			return r, err
		}
		off = no
		if off+4 > len(d) {
			return r, errors.New("Malformed DNS packet")
		}
		typ := binary.BigEndian.Uint16(d[off : off+2])
		class := binary.BigEndian.Uint16(d[off+2 : off+4])
		off += 4
		r.Queries = append(r.Queries, question{n, className(class), typeName(typ)})
	}
	for i := 0; i < an; i++ {
		rec, no, err := readRecord(d, off)
		if err != nil {
			return r, err
		}
		off = no
		r.Answers = append(r.Answers, rec)
	}
	for i := 0; i < ns; i++ {
		rec, no, err := readRecord(d, off)
		if err != nil {
			return r, err
		}
		off = no
		r.Authorities = append(r.Authorities, rec)
	}
	for i := 0; i < ar; i++ {
		rec, no, err := readRecord(d, off)
		if err != nil {
			return r, err
		}
		off = no
		if rec.Type != "OPT" {
			r.Additionals = append(r.Additionals, rec)
		}
	}
	return r, nil
}

func readRecord(d []byte, off int) (record, int, error) {
	n, no, err := readName(d, off)
	if err != nil {
		return record{}, off, err
	}
	off = no
	if off+10 > len(d) {
		return record{}, off, errors.New("Malformed DNS packet")
	}
	typ := binary.BigEndian.Uint16(d[off : off+2])
	class := binary.BigEndian.Uint16(d[off+2 : off+4])
	ttl := binary.BigEndian.Uint32(d[off+4 : off+8])
	l := int(binary.BigEndian.Uint16(d[off+8 : off+10]))
	off += 10
	if off+l > len(d) {
		return record{}, off, errors.New("Malformed DNS packet")
	}
	rd := d[off : off+l]
	rec := record{Name: n, Class: className(class), TTL: ttl, Type: typeName(typ)}
	rec.Data, rec.text = decodeData(typ, d, off, rd)
	return rec, off + l, nil
}

func decodeData(typ uint16, full []byte, rdoff int, rd []byte) (interface{}, string) {
	switch typ {
	case 1:
		if len(rd) == 4 {
			s := net.IP(rd).String()
			return map[string]string{"address": s}, s
		}
	case 28:
		if len(rd) == 16 {
			s := net.IP(rd).String()
			return map[string]string{"address": s}, s
		}
	case 2, 5, 12:
		if n, _, err := readName(full, rdoff); err == nil {
			key := map[uint16]string{2: "name", 5: "name", 12: "name"}[typ]
			return map[string]string{key: n}, n
		}
	case 15:
		if len(rd) >= 3 {
			pref := binary.BigEndian.Uint16(rd[:2])
			if n, _, err := readName(full, rdoff+2); err == nil {
				text := fmt.Sprintf("%d %q", pref, n)
				return map[string]interface{}{"preference": pref, "exchange": n}, text
			}
		}
	case 16:
		var parts []string
		for i := 0; i < len(rd); {
			if i+int(rd[i])+1 > len(rd) {
				break
			}
			parts = append(parts, string(rd[i+1:i+1+int(rd[i])]))
			i += 1 + int(rd[i-0])
		}
		qs := make([]string, len(parts))
		for i, p := range parts {
			qs[i] = strconv.Quote(p)
		}
		return map[string]interface{}{"texts": parts}, strings.Join(qs, " ")
	case 6:
		m, mo, e := readName(full, rdoff)
		if e == nil {
			rn, ro, e := readName(full, mo)
			if e == nil && ro+20 <= rdoff+len(rd) {
				vals := []uint32{}
				for i := 0; i < 5; i++ {
					vals = append(vals, binary.BigEndian.Uint32(full[ro+i*4:ro+i*4+4]))
				}
				text := fmt.Sprintf("%s %s %d %d %d %d %d", m, rn, vals[0], vals[1], vals[2], vals[3], vals[4])
				return map[string]interface{}{"mname": m, "rname": rn, "serial": vals[0], "refresh": vals[1], "retry": vals[2], "expire": vals[3], "minimum": vals[4]}, text
			}
		}
	case 33:
		if len(rd) >= 7 {
			pri := binary.BigEndian.Uint16(rd)
			w := binary.BigEndian.Uint16(rd[2:])
			port := binary.BigEndian.Uint16(rd[4:])
			if n, _, e := readName(full, rdoff+6); e == nil {
				text := fmt.Sprintf("%d %d %d %s", pri, w, port, n)
				return map[string]interface{}{"priority": pri, "weight": w, "port": port, "target": n}, text
			}
		}
	}
	nums := make([]int, len(rd))
	ss := make([]string, len(rd))
	for i, b := range rd {
		nums[i] = int(b)
		ss[i] = strconv.Itoa(int(b))
	}
	return map[string]interface{}{"bytes": nums}, strings.Join(ss, " ")
}

func readName(d []byte, off int) (string, int, error) {
	var parts []string
	pos := off
	end := 0
	jumped := false
	for depth := 0; depth < 40; depth++ {
		if pos >= len(d) {
			return "", off, errors.New("Malformed DNS packet")
		}
		l := int(d[pos])
		if l&0xc0 == 0xc0 {
			if pos+1 >= len(d) {
				return "", off, errors.New("Malformed DNS packet")
			}
			ptr := int(binary.BigEndian.Uint16(d[pos:pos+2]) & 0x3fff)
			if !jumped {
				end = pos + 2
			}
			jumped = true
			pos = ptr
			continue
		}
		if l == 0 {
			if !jumped {
				end = pos + 1
			}
			if len(parts) == 0 {
				return ".", end, nil
			}
			return strings.Join(parts, ".") + ".", end, nil
		}
		pos++
		if pos+l > len(d) {
			return "", off, errors.New("Malformed DNS packet")
		}
		parts = append(parts, string(d[pos:pos+l]))
		pos += l
	}
	return "", off, errors.New("Malformed DNS packet")
}

func printTable(resps []response, seconds bool) {
	var rows []record
	for _, resp := range resps {
		if resp.Status != "" {
			fmt.Println("Status: " + resp.Status)
		}
		rows = append(rows, resp.Answers...)
		rows = append(rows, resp.Authorities...)
		rows = append(rows, resp.Additionals...)
	}
	if len(rows) == 0 {
		return
	}
	tw, nw, ttlw := 0, 0, 0
	ttls := make([]string, len(rows))
	for i, r := range rows {
		if len(r.Type) > tw {
			tw = len(r.Type)
		}
		if len(r.Name) > nw {
			nw = len(r.Name)
		}
		ttls[i] = formatTTL(r.TTL, seconds)
		if len(ttls[i]) > ttlw {
			ttlw = len(ttls[i])
		}
	}
	for i, r := range rows {
		fmt.Printf("%*s %-*s %*s   %s\n", tw, r.Type, nw, r.Name, ttlw, ttls[i], r.text)
	}
}

func shortValue(r record) string {
	return strings.Trim(r.text, "\"")
}

func formatTTL(t uint32, seconds bool) string {
	if seconds {
		return strconv.FormatUint(uint64(t), 10)
	}
	d := time.Duration(t) * time.Second
	h := d / time.Hour
	d -= h * time.Hour
	m := d / time.Minute
	d -= m * time.Minute
	s := d / time.Second
	out := ""
	if h > 0 {
		out += fmt.Sprintf("%dh", h)
	}
	if m > 0 || h > 0 {
		out += fmt.Sprintf("%02dm", m)
	}
	out += fmt.Sprintf("%02ds", s)
	return out
}
func formatRun(d time.Duration, seconds bool) string {
	if seconds {
		return fmt.Sprintf("%.3fs", d.Seconds())
	}
	return fmt.Sprintf("%dms", (d+time.Millisecond/2)/time.Millisecond)
}
func typeName(c uint16) string {
	if s, ok := codeTypes[c]; ok {
		return s
	}
	return "TYPE" + strconv.Itoa(int(c))
}
func rcodeName(c int) string {
	switch c {
	case 1:
		return "FormErr"
	case 2:
		return "ServFail"
	case 3:
		return "NXDomain"
	case 4:
		return "NotImp"
	case 5:
		return "Refused"
	default:
		return "Error " + strconv.Itoa(c)
	}
}
func className(c uint16) string {
	if s, ok := codeClasses[c]; ok {
		return s
	}
	return "CLASS" + strconv.Itoa(int(c))
}
func reverseTypes() map[uint16]string {
	m := map[uint16]string{}
	for k, v := range typeCodes {
		m[v] = k
	}
	return m
}
