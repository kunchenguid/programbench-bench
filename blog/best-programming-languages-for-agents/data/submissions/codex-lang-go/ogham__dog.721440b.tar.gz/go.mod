module dogclone

go 1.21
