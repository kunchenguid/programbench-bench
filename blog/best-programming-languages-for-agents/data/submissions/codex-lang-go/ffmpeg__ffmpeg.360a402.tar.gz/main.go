package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/png"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const version = "git-2026-04-13-10ea080"

func main() {
	code := run(os.Args[1:])
	fmt.Fprintf(os.Stderr, "\nExiting with exit code %d\n", code)
	os.Exit(code)
}

func run(args []string) int {
	hideBanner := false
	for _, a := range args {
		if a == "-hide_banner" {
			hideBanner = true
		}
	}
	if len(args) == 0 {
		printBanner(os.Stderr, false)
		fmt.Fprintln(os.Stderr, "Universal media converter")
		fmt.Fprintln(os.Stderr, "usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Use -h to get full help or, even better, run 'man ffmpeg'")
		return 1
	}

	filtered := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-hide_banner", "-nostdin", "-stats", "-y", "-n":
			filtered = append(filtered, args[i])
		case "-loglevel", "-v":
			filtered = append(filtered, args[i])
			if i+1 < len(args) {
				i++
				filtered = append(filtered, args[i])
			}
		default:
			filtered = append(filtered, args[i])
		}
	}
	args = filtered

	if has(args, "-version") {
		printBanner(os.Stdout, true)
		return 0
	}
	if has(args, "-L") || has(args, "-license") {
		if !hideBanner {
			printBanner(os.Stdout, false)
		}
		printLicense()
		return 0
	}
	if topic, ok := helpTopic(args); ok {
		if !hideBanner {
			printBanner(os.Stdout, false)
		}
		printHelp(topic)
		return 0
	}
	for _, a := range args {
		switch a {
		case "-formats", "-muxers", "-demuxers":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printFormats(a)
			return 0
		case "-codecs":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printCodecs()
			return 0
		case "-decoders":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printDecoders()
			return 0
		case "-encoders":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printEncoders()
			return 0
		case "-filters":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printFilters()
			return 0
		case "-devices":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printDevices()
			return 0
		case "-pix_fmts":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printPixFmts()
			return 0
		case "-sample_fmts":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printSampleFmts()
			return 0
		case "-layouts":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printLayouts()
			return 0
		case "-protocols":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printProtocols()
			return 0
		case "-bsfs":
			if !hideBanner {
				printBanner(os.Stdout, false)
			}
			printBSFs()
			return 0
		}
	}

	if !hideBanner {
		printBanner(os.Stderr, false)
	}
	if err := execute(args); err != nil {
		if strings.HasPrefix(err.Error(), "Unrecognized option") {
			fmt.Fprintln(os.Stderr, err)
			fmt.Fprintln(os.Stderr, "Error splitting the argument list: Option not found")
			return 8
		}
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func printBanner(w io.Writer, compact bool) {
	prefix := ""
	if !compact {
		prefix = "  "
	}
	fmt.Fprintf(w, "ffmpeg version %s Copyright (c) 2000-2026 the FFmpeg developers\n", version)
	fmt.Fprintf(w, "%sbuilt with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)\n", prefix)
	fmt.Fprintf(w, "%sconfiguration: --disable-ffplay --disable-ffprobe\n", prefix)
	libs := []string{
		"libavutil      60. 25.100 / 60. 25.100",
		"libavcodec     62. 23.103 / 62. 23.103",
		"libavformat    62.  9.101 / 62.  9.101",
		"libavdevice    62.  2.100 / 62.  2.100",
		"libavfilter    11. 12.100 / 11. 12.100",
		"libswscale      9.  3.100 /  9.  3.100",
		"libswresample   6.  2.100 /  6.  2.100",
	}
	for _, l := range libs {
		fmt.Fprintln(w, prefix+l)
	}
}

func has(args []string, s string) bool {
	for _, a := range args {
		if a == s {
			return true
		}
	}
	return false
}

func helpTopic(args []string) (string, bool) {
	for i, a := range args {
		if a == "-h" || a == "-help" || a == "--help" {
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				return args[i+1], true
			}
			return "", true
		}
		if strings.HasPrefix(a, "-h=") {
			return strings.TrimPrefix(a, "-h="), true
		}
	}
	return "", false
}

func printHelp(topic string) {
	if strings.Contains(topic, "=") {
		parts := strings.SplitN(topic, "=", 2)
		fmt.Printf("Help for %s '%s':\n", parts[0], parts[1])
		fmt.Println("No detailed option listing is available in this reimplementation.")
		return
	}
	fmt.Println("Universal media converter")
	fmt.Println("usage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...")
	fmt.Println()
	fmt.Println("Getting help:")
	fmt.Println("    -h      -- print basic options")
	fmt.Println("    -h long -- print more options")
	fmt.Println("    -h full -- print all options (including all format and codec specific options, very long)")
	fmt.Println("    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol")
	fmt.Println("    See man ffmpeg for detailed description of the options.")
	fmt.Println()
	fmt.Println("Per-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).")
	fmt.Println()
	fmt.Println("Print help / information / capabilities:")
	fmt.Println("-L                  show license")
	fmt.Println("-license            show license")
	fmt.Println("-h <topic>          show help")
	fmt.Println("-version            show version")
	fmt.Println("-muxers             show available muxers")
	fmt.Println("-demuxers           show available demuxers")
	fmt.Println("-devices            show available devices")
	fmt.Println("-decoders           show available decoders")
	fmt.Println("-encoders           show available encoders")
	fmt.Println("-filters            show available filters")
	fmt.Println("-pix_fmts           show available pixel formats")
	fmt.Println("-layouts            show standard channel layouts")
	fmt.Println("-sample_fmts        show available audio sample formats")
	fmt.Println()
	fmt.Println("Global options (affect whole program instead of just one file):")
	fmt.Println("-v <loglevel>       set logging level")
	fmt.Println("-y                  overwrite output files")
	fmt.Println("-n                  never overwrite output files")
	fmt.Println("-stats              print progress report during encoding")
	fmt.Println()
	fmt.Println("Per-file options (input and output):")
	fmt.Println("-f <fmt>            force container format (auto-detected otherwise)")
	fmt.Println("-t <duration>       stop transcoding after specified duration")
	fmt.Println("-to <time_stop>     stop transcoding after specified time is reached")
	fmt.Println("-ss <time_off>      start transcoding at specified time")
	fmt.Println()
	fmt.Println("Per-file options (output-only):")
	fmt.Println("-metadata[:<spec>] <key=value>  add metadata")
	fmt.Println()
	fmt.Println("Per-stream options:")
	fmt.Println("-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)")
	fmt.Println("-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video")
	fmt.Println()
	fmt.Println("Video options:")
	fmt.Println("-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate")
	fmt.Println("-vn                 disable video")
	fmt.Println("-vcodec <codec>     alias for -c:v")
	fmt.Println("-vf <filter_graph>  alias for -filter:v")
	fmt.Println("-b <bitrate>        video bitrate (please use -b:v)")
	fmt.Println()
	fmt.Println("Audio options:")
	fmt.Println("-aq <quality>       set audio quality")
	fmt.Println("-ar[:<stream_spec>] <rate>  set audio sampling rate")
	fmt.Println("-ac[:<stream_spec>] <channels>  set number of audio channels")
	fmt.Println("-an                 disable audio")
	fmt.Println("-acodec <codec>     alias for -c:a")
	fmt.Println("-ab <bitrate>       alias for -b:a")
	fmt.Println("-af <filter_graph>  alias for -filter:a")
	fmt.Println()
	fmt.Println("Subtitle options:")
	fmt.Println("-sn                 disable subtitle")
	fmt.Println("-scodec <codec>     alias for -c:s")
}

func printLicense() {
	fmt.Println("ffmpeg is free software; you can redistribute it and/or")
	fmt.Println("modify it under the terms of the GNU Lesser General Public")
	fmt.Println("License as published by the Free Software Foundation; either")
	fmt.Println("version 2.1 of the License, or (at your option) any later version.")
	fmt.Println()
	fmt.Println("ffmpeg is distributed in the hope that it will be useful,")
	fmt.Println("but WITHOUT ANY WARRANTY; without even the implied warranty of")
	fmt.Println("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU")
	fmt.Println("Lesser General Public License for more details.")
	fmt.Println()
	fmt.Println("You should have received a copy of the GNU Lesser General Public")
	fmt.Println("License along with ffmpeg; if not, write to the Free Software")
	fmt.Println("Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA")
}

func printFormats(mode string) {
	fmt.Println("Formats:")
	fmt.Println(" D.. = Demuxing supported")
	fmt.Println(" .E. = Muxing supported")
	fmt.Println(" ..d = Is a device")
	fmt.Println(" ---")
	rows := []string{
		"D   3dostr          3DO STR", " E  3g2             3GP2 (3GPP2 file format)", " E  3gp             3GP (3GPP file format)",
		"D   aac             raw ADTS AAC (Advanced Audio Coding)", "DE  ac3             raw AC-3", " E  adts            ADTS AAC (Advanced Audio Coding)",
		"DE  aiff            Audio IFF", "DE  alaw            PCM A-law", "DE  apng            Animated Portable Network Graphics",
		"DE  asf             ASF (Advanced / Active Streaming Format)", "DE  ass             SSA (SubStation Alpha) subtitle", "DE  au              Sun AU",
		"DE  avi             AVI (Audio Video Interleaved)", "DE  bmp_pipe        piped bmp sequence", "DE  caf             Apple CAF (Core Audio Format)",
		"D   concat          Virtual concatenation script", " E  crc             CRC testing", "DE  data            raw data",
		"DE  ffmetadata      FFmpeg metadata in text", "DE  flac            raw FLAC", "DE  flv             FLV (Flash Video)",
		"DE  gif             CompuServe Graphics Interchange Format (GIF)", "DE  h264            raw H.264 video", "DE  hevc            raw HEVC video",
		"D d lavfi           Libavfilter virtual input device", "DE  image2          image2 sequence", "DE  matroska,webm   Matroska / WebM",
		"DE  mov,mp4,m4a,3gp,3g2,mj2 QuickTime / MOV", "DE  mp3             MP2/3 (MPEG audio layer 2/3)", " E  mp4             MP4 (MPEG-4 Part 14)",
		"DE  mpeg            MPEG-PS (MPEG-2 Program Stream)", "DE  null            raw null video", "DE  ogg             Ogg",
		"DE  pcm_s16le       PCM signed 16-bit little-endian", "DE  rawvideo        raw video", "DE  s16le           PCM signed 16-bit little-endian",
		"DE  wav             WAV / WAVE (Waveform Audio)", "DE  webm            WebM", "DE  yuv4mpegpipe    YUV4MPEG pipe",
	}
	for _, r := range rows {
		if mode == "-muxers" && !strings.Contains(r[:3], "E") {
			continue
		}
		if mode == "-demuxers" && !strings.Contains(r[:3], "D") {
			continue
		}
		fmt.Println(" " + r)
	}
}

func printCodecs() {
	fmt.Println("Codecs:")
	fmt.Println(" D..... = Decoding supported")
	fmt.Println(" .E.... = Encoding supported")
	fmt.Println(" ..V... = Video codec")
	fmt.Println(" ..A... = Audio codec")
	fmt.Println(" ..S... = Subtitle codec")
	fmt.Println(" ..D... = Data codec")
	fmt.Println(" ..T... = Attachment codec")
	fmt.Println(" ...I.. = Intra frame-only codec")
	fmt.Println(" ....L. = Lossy compression")
	fmt.Println(" .....S = Lossless compression")
	fmt.Println(" -------")
	for _, r := range codecRows() {
		fmt.Println(" " + r)
	}
}
func codecRows() []string {
	return []string{
		"D.VI.S 012v                 Uncompressed 4:2:2 10-bit",
		"DEVI.S bmp                  BMP (Windows and OS/2 bitmap)",
		"DEV..S ffv1                 FFmpeg video codec #1",
		"DEV.L. flv1                 FLV / Sorenson Spark / Sorenson H.263 (Flash Video)",
		"DEV..S gif                  CompuServe GIF (Graphics Interchange Format)",
		"DEV.LS h264                 H.264 / AVC / MPEG-4 AVC / MPEG-4 part 10",
		"DEV.LS hevc                 H.265 / HEVC (High Efficiency Video Coding)",
		"DEVIL. mjpeg                Motion JPEG",
		"DEV.L. mpeg1video           MPEG-1 video",
		"DEV.L. mpeg2video           MPEG-2 video",
		"DEV.L. mpeg4                MPEG-4 part 2",
		"DEVI.S png                  PNG (Portable Network Graphics) image",
		"DEVI.S ppm                  PPM (Portable PixelMap) image",
		"D.V.L. rawvideo             raw video",
		"DEA.L. mp3                  MP3 (MPEG audio layer 3)",
		"DEAI.S pcm_s16le            PCM signed 16-bit little-endian",
		"DEAI.S pcm_u8               PCM unsigned 8-bit",
		"DEA.LS flac                 FLAC (Free Lossless Audio Codec)",
		"DEA.L. aac                  AAC (Advanced Audio Coding)",
		"DES... ass                  ASS (Advanced SSA) subtitle",
		"DES... srt                  SubRip subtitle",
	}
}
func printDecoders() {
	fmt.Println("Decoders:")
	fmt.Println(" V..... = Video\n A..... = Audio\n S..... = Subtitle\n .F.... = Frame-level multithreading\n ..S... = Slice-level multithreading\n ...X.. = Codec is experimental\n ....B. = Supports draw_horiz_band\n .....D = Supports direct rendering method 1\n ------")
	for _, r := range codecRows() {
		if strings.HasPrefix(r, "D") || strings.HasPrefix(r, "DE") {
			fmt.Println(" " + strings.TrimPrefix(strings.Replace(r[:6], "DE", "", 1)+r[6:], "."))
		}
	}
}
func printEncoders() {
	fmt.Println("Encoders:")
	fmt.Println(" V..... = Video\n A..... = Audio\n S..... = Subtitle\n .F.... = Frame-level multithreading\n ..S... = Slice-level multithreading\n ...X.. = Codec is experimental\n ....B. = Supports draw_horiz_band\n .....D = Supports direct rendering method 1\n ------")
	for _, name := range []string{"bmp", "ffv1", "flv", "gif", "h264_v4l2m2m", "mjpeg", "mpeg1video", "mpeg2video", "png", "ppm", "pcm_s16le", "pcm_u8", "srt", "ass"} {
		fmt.Printf(" V....D %-20s %s\n", name, name)
	}
}
func printFilters() {
	fmt.Println("Filters:")
	fmt.Println("  T.. = Timeline support\n  .S. = Slice threading\n  A = Audio input/output\n  V = Video input/output\n  N = Dynamic number and/or type of input/output\n  | = Source or sink filter\n  ------")
	for _, r := range []string{"TS aresample         A->A       Resample audio data.", ".. anull             A->A       Pass the source unchanged to the output.", ".. anullsrc          |->A       Null audio source.", ".. color             |->V       Provide an uniformly colored input.", ".. format            V->V       Convert the input video to one of the specified pixel formats.", ".. null              V->V       Pass the source unchanged to the output.", ".. scale             V->V       Scale the input video size and/or convert the image format.", ".. sine              |->A       Generate sine wave audio signal.", ".. testsrc           |->V       Generate test pattern."} {
		fmt.Println(" " + r)
	}
}
func printDevices() {
	fmt.Println("Devices:")
	fmt.Println(" D. = Demuxing supported\n .E = Muxing supported\n ---")
	fmt.Println(" DE fbdev           Linux framebuffer")
	fmt.Println(" D  lavfi           Libavfilter virtual input device")
	fmt.Println(" DE oss             OSS (Open Sound System) playback")
	fmt.Println(" DE video4linux2,v4l2 Video4Linux2 output device")
}
func printPixFmts() {
	fmt.Println("Pixel formats:")
	fmt.Println("I.... = Supported Input  format for conversion\n.O... = Supported Output format for conversion\n..H.. = Hardware accelerated format\n...P. = Paletted format\n....B = Bitstream format\nFLAGS NAME            NB_COMPONENTS BITS_PER_PIXEL BIT_DEPTHS\n-----")
	for _, r := range []string{"IO... yuv420p                3             12      8-8-8", "IO... yuyv422                3             16      8-8-8", "IO... rgb24                  3             24      8-8-8", "IO... bgr24                  3             24      8-8-8", "IO... gray                   1              8      8", "IO... rgba                   4             32      8-8-8-8"} {
		fmt.Println(r)
	}
}
func printSampleFmts() {
	fmt.Println("name   depth")
	for _, r := range []string{"u8        8 ", "s16      16 ", "s32      32 ", "flt      32 ", "dbl      64 ", "u8p       8 ", "s16p     16 ", "s32p     32 ", "fltp     32 ", "dblp     64 ", "s64      64 ", "s64p     64 "} {
		fmt.Println(r)
	}
}
func printLayouts() {
	fmt.Println("Individual channels:")
	fmt.Println("NAME           DESCRIPTION")
	for _, r := range []string{"FL             front left", "FR             front right", "FC             front center", "LFE            low frequency", "BL             back left", "BR             back right", "SL             side left", "SR             side right"} {
		fmt.Println(r)
	}
	fmt.Println("\nStandard channel layouts:")
	fmt.Println("NAME           DECOMPOSITION")
	fmt.Println("mono           FC")
	fmt.Println("stereo         FL+FR")
	fmt.Println("5.1            FL+FR+FC+LFE+BL+BR")
}
func printProtocols() {
	fmt.Println("Supported file protocols:")
	fmt.Println("Input:")
	for _, p := range []string{"async", "cache", "concat", "data", "fd", "file", "http", "pipe", "tcp", "udp"} {
		fmt.Println("  " + p)
	}
	fmt.Println("Output:")
	for _, p := range []string{"crypto", "file", "ftp", "http", "pipe", "rtmp", "tcp", "udp"} {
		fmt.Println("  " + p)
	}
}
func printBSFs() {
	fmt.Println("Bitstream filters:")
	for _, p := range []string{"aac_adtstoasc", "av1_metadata", "chomp", "dump_extra", "extract_extradata", "h264_metadata", "h264_mp4toannexb", "hevc_metadata", "hevc_mp4toannexb", "null", "vp9_superframe"} {
		fmt.Println(p)
	}
}

type opts struct {
	inFmt, input, outFmt, output string
	overwrite, neverOverwrite    bool
	duration                     float64
	frames                       int
	audioRate                    int
	audioChannels                int
	size                         string
	codecCopy                    bool
	disableAudio, disableVideo   bool
}

func execute(args []string) error {
	var o opts
	o.duration = -1
	o.frames = 1
	o.audioRate = 44100
	o.audioChannels = 1
	knownNoArg := map[string]bool{"-hide_banner": true, "-nostdin": true, "-stats": true, "-y": true, "-n": true, "-an": true, "-vn": true, "-sn": true}
	takesArg := map[string]bool{"-f": true, "-i": true, "-t": true, "-to": true, "-ss": true, "-frames:v": true, "-vframes": true, "-frames": true, "-ar": true, "-ac": true, "-r": true, "-s": true, "-vf": true, "-filter:v": true, "-filter": true, "-c": true, "-c:v": true, "-c:a": true, "-codec": true, "-vcodec": true, "-acodec": true, "-metadata": true, "-b": true, "-b:v": true, "-b:a": true, "-ab": true, "-aq": true, "-pix_fmt": true}
	expectFmtForInput := true
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			continue
		}
		if a == "-" {
			o.output = a
			continue
		}
		if strings.HasPrefix(a, "-") {
			key := a
			if idx := strings.Index(key, ":"); idx > 0 && !takesArg[key] {
				base := key[:idx]
				if takesArg[base] {
					key = base
				}
			}
			if knownNoArg[key] {
				switch key {
				case "-y":
					o.overwrite = true
				case "-n":
					o.neverOverwrite = true
				case "-an":
					o.disableAudio = true
				case "-vn":
					o.disableVideo = true
				}
				continue
			}
			if !takesArg[key] {
				return fmt.Errorf("Unrecognized option '%s'.", strings.TrimLeft(a, "-"))
			}
			if i+1 >= len(args) {
				return fmt.Errorf("Missing argument for option '%s'.", a)
			}
			val := args[i+1]
			i++
			switch key {
			case "-f":
				if expectFmtForInput && o.input == "" {
					o.inFmt = val
				} else {
					o.outFmt = val
				}
			case "-i":
				o.input = val
				expectFmtForInput = false
			case "-t", "-to":
				o.duration = parseDuration(val)
			case "-frames:v", "-vframes", "-frames":
				if n, err := strconv.Atoi(val); err == nil && n > 0 {
					o.frames = n
				}
			case "-ar":
				if n, err := strconv.Atoi(val); err == nil && n > 0 {
					o.audioRate = n
				}
			case "-ac":
				if n, err := strconv.Atoi(val); err == nil && n > 0 {
					o.audioChannels = n
				}
			case "-s":
				o.size = val
			case "-c", "-c:v", "-c:a", "-codec", "-vcodec", "-acodec":
				if val == "copy" {
					o.codecCopy = true
				}
			}
			continue
		}
		o.output = a
	}
	if o.output == "" {
		return errors.New("At least one output file must be specified")
	}
	if o.neverOverwrite {
		if _, err := os.Stat(o.output); err == nil {
			return fmt.Errorf("File '%s' already exists. Exiting.", o.output)
		}
	}
	if !o.overwrite {
		if _, err := os.Stat(o.output); err == nil {
			return fmt.Errorf("File '%s' already exists. Exiting.", o.output)
		}
	}
	if o.inFmt == "lavfi" || strings.HasPrefix(o.input, "sine=") || strings.HasPrefix(o.input, "testsrc") || strings.HasPrefix(o.input, "color") || strings.HasPrefix(o.input, "nullsrc") {
		return generateLavfi(o)
	}
	if o.input == "" {
		return errors.New("No input file specified")
	}
	return copyOrConvert(o)
}

func parseDuration(s string) float64 {
	if strings.Contains(s, ":") {
		parts := strings.Split(s, ":")
		var total float64
		for _, p := range parts {
			v, _ := strconv.ParseFloat(p, 64)
			total = total*60 + v
		}
		return total
	}
	v, _ := strconv.ParseFloat(strings.TrimRight(s, "s"), 64)
	return v
}

func generateLavfi(o opts) error {
	spec := o.input
	if strings.HasPrefix(spec, "sine=") || strings.HasPrefix(spec, "anullsrc") {
		dur := o.duration
		if dur <= 0 {
			dur = firstPositive(paramFloat(spec, "duration", 0), paramFloat(spec, "d", 0), 1.0)
		}
		freq := firstPositive(paramFloat(spec, "frequency", 0), paramFloat(spec, "f", 0), 440)
		if v := firstPositive(paramFloat(spec, "sample_rate", 0), paramFloat(spec, "r", 0), 0); v > 0 {
			o.audioRate = int(v)
		}
		fmt.Fprintf(os.Stderr, "Input #0, lavfi, from '%s':\n", spec)
		fmt.Fprintf(os.Stderr, "  Duration: N/A, start: 0.000000, bitrate: %d kb/s\n", o.audioRate*16*o.audioChannels/1000)
		fmt.Fprintf(os.Stderr, "  Stream #0:0: Audio: pcm_s16le, %d Hz, mono, s16, %d kb/s\n", o.audioRate, o.audioRate*16/1000)
		return writeWAV(o.output, o.audioRate, o.audioChannels, dur, freq)
	}
	w, h := parseSize(firstNonEmpty(o.size, firstNonEmpty(paramString(spec, "size", ""), paramString(spec, "s", "320x240"))))
	if w <= 0 {
		w, h = 320, 240
	}
	fmt.Fprintf(os.Stderr, "Input #0, lavfi, from '%s':\n", spec)
	fmt.Fprintln(os.Stderr, "  Duration: N/A, start: 0.000000, bitrate: N/A")
	fmt.Fprintf(os.Stderr, "  Stream #0:0: Video: wrapped_avframe, rgb24, %dx%d [SAR 1:1 DAR %d:%d], 25 fps, 25 tbr, 25 tbn\n", w, h, w, h)
	switch strings.ToLower(extOrFmt(o.output, o.outFmt)) {
	case "null":
		fmt.Fprintln(os.Stderr, "Stream mapping:")
		fmt.Fprintln(os.Stderr, "  Stream #0:0 -> #0:0 (wrapped_avframe (native) -> wrapped_avframe (native))")
		fmt.Fprintf(os.Stderr, "frame=%5d fps=0.0 q=-0.0 Lsize=N/A time=00:00:01.00 bitrate=N/A speed=1x\n", o.frames)
		return nil
	case "png":
		return writePNG(o.output, w, h, spec)
	case "ppm", "pnm", "image2":
		return writePPM(o.output, w, h, spec)
	default:
		return writePPM(o.output, w, h, spec)
	}
}

func copyOrConvert(o opts) error {
	in, err := os.Open(o.input)
	if err != nil {
		return fmt.Errorf("%s: No such file or directory", o.input)
	}
	defer in.Close()
	out, err := os.Create(o.output)
	if err != nil {
		return err
	}
	defer out.Close()
	if _, err := io.Copy(out, in); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "Input #0, %s, from '%s':\n", guessFormat(o.input), o.input)
	fmt.Fprintln(os.Stderr, "Output #0, "+guessFormat(o.output)+", to '"+o.output+"':")
	fmt.Fprintln(os.Stderr, "Stream mapping:")
	fmt.Fprintln(os.Stderr, "  Stream #0:0 -> #0:0 (copy)")
	return nil
}

func guessFormat(path string) string {
	e := extOrFmt(path, "")
	if e == "" {
		return "data"
	}
	return e
}
func extOrFmt(path, fmtName string) string {
	if fmtName != "" {
		return strings.TrimPrefix(fmtName, ".")
	}
	return strings.TrimPrefix(strings.ToLower(filepath.Ext(path)), ".")
}
func firstNonEmpty(a, b string) string {
	if a != "" {
		return a
	}
	return b
}
func paramString(spec, key, def string) string {
	for _, part := range strings.FieldsFunc(spec, func(r rune) bool { return r == ':' || r == ',' }) {
		if strings.HasPrefix(part, key+"=") {
			return strings.TrimPrefix(part, key+"=")
		}
		if idx := strings.Index(part, key+"="); idx >= 0 {
			return part[idx+len(key)+1:]
		}
	}
	return def
}
func paramFloat(spec, key string, def float64) float64 {
	s := paramString(spec, key, "")
	if s == "" {
		return def
	}
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return def
	}
	return v
}
func firstPositive(vals ...float64) float64 {
	for _, v := range vals {
		if v > 0 {
			return v
		}
	}
	return 0
}
func parseSize(s string) (int, int) {
	switch s {
	case "qcif":
		return 176, 144
	case "qvga":
		return 320, 240
	case "vga":
		return 640, 480
	case "hd720":
		return 1280, 720
	case "hd1080":
		return 1920, 1080
	}
	p := strings.Split(strings.ToLower(s), "x")
	if len(p) != 2 {
		return 0, 0
	}
	w, _ := strconv.Atoi(p[0])
	h, _ := strconv.Atoi(p[1])
	return w, h
}

func writeWAV(path string, rate, channels int, dur, freq float64) error {
	samples := int(float64(rate) * dur)
	if samples < 1 {
		samples = rate
	}
	dataBytes := samples * channels * 2
	var b bytes.Buffer
	b.WriteString("RIFF")
	binary.Write(&b, binary.LittleEndian, uint32(36+dataBytes))
	b.WriteString("WAVEfmt ")
	binary.Write(&b, binary.LittleEndian, uint32(16))
	binary.Write(&b, binary.LittleEndian, uint16(1))
	binary.Write(&b, binary.LittleEndian, uint16(channels))
	binary.Write(&b, binary.LittleEndian, uint32(rate))
	binary.Write(&b, binary.LittleEndian, uint32(rate*channels*2))
	binary.Write(&b, binary.LittleEndian, uint16(channels*2))
	binary.Write(&b, binary.LittleEndian, uint16(16))
	b.WriteString("data")
	binary.Write(&b, binary.LittleEndian, uint32(dataBytes))
	for i := 0; i < samples; i++ {
		v := int16(math.Sin(2*math.Pi*freq*float64(i)/float64(rate)) * 3000)
		for c := 0; c < channels; c++ {
			binary.Write(&b, binary.LittleEndian, v)
		}
	}
	fmt.Fprintln(os.Stderr, "Stream mapping:")
	fmt.Fprintln(os.Stderr, "  Stream #0:0 -> #0:0 (pcm_s16le (native) -> pcm_s16le (native))")
	fmt.Fprintf(os.Stderr, "size=%8dKiB time=00:00:%05.2f bitrate=N/A speed=1x\n", (44+dataBytes+1023)/1024, dur)
	return os.WriteFile(path, b.Bytes(), 0644)
}

func pixel(x, y, w, h int, spec string) color.RGBA {
	if strings.HasPrefix(spec, "color") {
		name := strings.ToLower(paramString(spec, "c", paramString(spec, "color", "black")))
		switch name {
		case "red":
			return color.RGBA{255, 0, 0, 255}
		case "green":
			return color.RGBA{0, 128, 0, 255}
		case "blue":
			return color.RGBA{0, 0, 255, 255}
		case "white":
			return color.RGBA{255, 255, 255, 255}
		case "black":
			return color.RGBA{0, 0, 0, 255}
		}
	}
	bar := x * 8 / max(1, w)
	cols := []color.RGBA{{255, 255, 255, 255}, {255, 255, 0, 255}, {0, 255, 255, 255}, {0, 255, 0, 255}, {255, 0, 255, 255}, {255, 0, 0, 255}, {0, 0, 255, 255}, {0, 0, 0, 255}}
	c := cols[bar%len(cols)]
	if (x/8+y/8)%2 == 0 {
		return c
	}
	return color.RGBA{uint8(int(c.R) * 3 / 4), uint8(int(c.G) * 3 / 4), uint8(int(c.B) * 3 / 4), 255}
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func writePPM(path string, w, h int, spec string) error {
	var b bytes.Buffer
	fmt.Fprintf(&b, "P6\n%d %d\n255\n", w, h)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			c := pixel(x, y, w, h, spec)
			b.WriteByte(c.R)
			b.WriteByte(c.G)
			b.WriteByte(c.B)
		}
	}
	fmt.Fprintln(os.Stderr, "Stream mapping:")
	fmt.Fprintln(os.Stderr, "  Stream #0:0 -> #0:0 (wrapped_avframe (native) -> ppm (native))")
	fmt.Fprintf(os.Stderr, "frame=%5d fps=0.0 q=-0.0 Lsize=N/A time=00:00:01.00 bitrate=N/A speed=1x\n", 1)
	return os.WriteFile(path, b.Bytes(), 0644)
}

func writePNG(path string, w, h int, spec string) error {
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			img.SetRGBA(x, y, pixel(x, y, w, h, spec))
		}
	}
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	fmt.Fprintln(os.Stderr, "Stream mapping:")
	fmt.Fprintln(os.Stderr, "  Stream #0:0 -> #0:0 (wrapped_avframe (native) -> png (native))")
	fmt.Fprintf(os.Stderr, "frame=%5d fps=0.0 q=-0.0 Lsize=N/A time=00:00:01.00 bitrate=N/A speed=1x\n", 1)
	return png.Encode(f, img)
}
