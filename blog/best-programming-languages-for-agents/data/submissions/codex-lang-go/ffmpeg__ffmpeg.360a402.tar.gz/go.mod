module cleanffmpeg

go 1.21
