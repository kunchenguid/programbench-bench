package main

import (
	"bytes"
	"compress/flate"
	"crypto/hmac"
	"crypto/sha1"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"os"
	"strconv"
	"strings"
	"time"
)

type entry struct {
	name        string
	flags       uint16
	method      uint16
	modTime     uint16
	crc         uint32
	compSize    uint32
	uncompSize  uint32
	data        []byte
	aes         bool
	aesStrength byte
	aesMethod   uint16
}

type options struct {
	input       string
	workers     int
	dict        string
	charset     string
	charsetFile string
	minLen      int
	maxLen      int
	fileNumber  int
	start       string
}

func main() { os.Exit(run()) }

func run() int {
	opt, special, err := parseArgs(os.Args[1:])
	if special != "" {
		fmt.Print(special)
		return 0
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		return 2
	}
	if _, err := os.Stat(opt.input); err != nil {
		fmt.Println("CLI argument error - \"'inputFile' does not exist\"")
		return 1
	}
	if opt.dict != "" {
		if _, err := os.Stat(opt.dict); err != nil {
			fmt.Println("CLI argument error - \"'passwordDictionary' does not exist\"")
			return 1
		}
	}
	if opt.charsetFile != "" {
		if _, err := os.Stat(opt.charsetFile); err != nil {
			fmt.Println("CLI argument error - \"'charsetFile' does not exist\"")
			return 1
		}
	}
	if opt.maxLen < opt.minLen {
		fmt.Println("CLI argument error - \"'maxPasswordLen' must be equal or greater than 'minPasswordLen'\"")
		return 1
	}
	chars, err := buildCharset(opt.charset, opt.charsetFile)
	if err != nil {
		fmt.Printf("CLI argument error - \"%s\"\n", err.Error())
		return 1
	}
	entries, err := readZip(opt.input)
	if err != nil || len(entries) == 0 {
		fmt.Println("Invalid zip file error")
		return 1
	}
	if opt.fileNumber < 0 || opt.fileNumber >= len(entries) {
		fmt.Printf("File number not found within archive error - '%d'\n", opt.fileNumber)
		return 1
	}
	ent := entries[opt.fileNumber]
	if ent.flags&1 == 0 && !ent.aes {
		fmt.Printf("Invalid zip file error - the selected file in the archive is not encrypted (file_number:%d file_name:%s)\n", opt.fileNumber, ent.name)
		return 1
	}

	startTime := time.Now()
	found := ""
	if opt.dict != "" {
		b, _ := os.ReadFile(opt.dict)
		text := strings.ReplaceAll(string(b), "\r\n", "\n")
		text = strings.ReplaceAll(text, "\r", "\n")
		lines := strings.Split(text, "\n")
		if len(lines) > 0 && lines[len(lines)-1] == "" {
			lines = lines[:len(lines)-1]
		}
		for _, p := range lines {
			if checkPassword(ent, p) {
				found = p
				break
			}
		}
	} else {
		found = brute(ent, chars, opt.minLen, opt.maxLen, opt.start)
	}
	printElapsed(time.Since(startTime))
	if found != "" {
		fmt.Printf("Password found:%s\n", found)
	} else {
		fmt.Println("Password not found")
	}
	return 0
}

func parseArgs(args []string) (options, string, error) {
	opt := options{charset: "lud", minLen: 1, maxLen: 10, fileNumber: 0}
	for i := 0; i < len(args); i++ {
		a := args[i]
		val := func(name string) (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("error: a value is required for '%s' but none was supplied", name)
			}
			i++
			return args[i], nil
		}
		switch a {
		case "-h", "--help":
			return opt, helpText(), nil
		case "-V", "--version":
			return opt, "zip-password-finder 0.10.3\n", nil
		case "-i", "--inputFile":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.input = v
		case "-w", "--workers":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.workers, _ = strconv.Atoi(v)
		case "-p", "--passwordDictionary":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.dict = v
		case "-c", "--charset":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.charset = v
		case "--charsetFile":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.charsetFile = v
		case "--minPasswordLen":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.minLen, _ = strconv.Atoi(v)
		case "--maxPasswordLen":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.maxLen, _ = strconv.Atoi(v)
		case "--fileNumber":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.fileNumber, _ = strconv.Atoi(v)
		case "-s", "--startingPassword":
			v, e := val(a)
			if e != nil {
				return opt, "", e
			}
			opt.start = v
		default:
			if strings.HasPrefix(a, "-") {
				return opt, "", fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] --inputFile <inputFile>\n\nFor more information, try '--help'.", a)
			}
		}
	}
	if opt.input == "" {
		return opt, "", errors.New("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.")
	}
	return opt, "", nil
}

func helpText() string {
	return `Find the password of protected ZIP files

Usage: executable [OPTIONS] --inputFile <inputFile>

Options:
  -i, --inputFile <inputFile>                    path to zip input file
  -w, --workers <workers>                        number of workers
  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file
  -c, --charset <charset>                        charset to use to generate password [default: lud]
      --charsetFile <charsetFile>                path to a charset file
      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]
      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]
      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]
  -s, --startingPassword <startingPassword>      password to start from
  -h, --help                                     Print help
  -V, --version                                  Print version
`
}

func buildCharset(spec, file string) ([]rune, error) {
	out := []rune{}
	add := func(s string) {
		for _, r := range s {
			out = append(out, r)
		}
	}
	for _, c := range spec {
		switch c {
		case 'l':
			add("abcdefghijklmnopqrstuvwxyz")
		case 'u':
			add("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
		case 'd':
			add("0123456789")
		case 'h':
			add("0123456789abcdef")
		case 'H':
			add("0123456789ABCDEF")
		case 's':
			add(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")
		default:
			return nil, fmt.Errorf("Unknown charset option '%c'", c)
		}
	}
	if file != "" {
		b, err := os.ReadFile(file)
		if err == nil {
			for _, r := range string(b) {
				if r != '\n' && r != '\r' {
					out = append(out, r)
				}
			}
		}
	}
	return out, nil
}

func readZip(path string) ([]entry, error) {
	d, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	type cent struct {
		name                   string
		flags, method, modTime uint16
		crc, comp, uncomp      uint32
		off                    uint32
		aes                    bool
		aesStrength            byte
		aesMethod              uint16
	}
	centrals := []cent{}
	for p := 0; p+46 <= len(d); p++ {
		if binary.LittleEndian.Uint32(d[p:]) != 0x02014b50 {
			continue
		}
		flags := binary.LittleEndian.Uint16(d[p+8:])
		method := binary.LittleEndian.Uint16(d[p+10:])
		modTime := binary.LittleEndian.Uint16(d[p+12:])
		crc := binary.LittleEndian.Uint32(d[p+16:])
		comp := binary.LittleEndian.Uint32(d[p+20:])
		uncomp := binary.LittleEndian.Uint32(d[p+24:])
		nl := int(binary.LittleEndian.Uint16(d[p+28:]))
		xl := int(binary.LittleEndian.Uint16(d[p+30:]))
		cl := int(binary.LittleEndian.Uint16(d[p+32:]))
		if p+46+nl+xl+cl > len(d) {
			continue
		}
		c := cent{name: string(d[p+46 : p+46+nl]), flags: flags, method: method, modTime: modTime, crc: crc, comp: comp, uncomp: uncomp, off: binary.LittleEndian.Uint32(d[p+42:])}
		extra := d[p+46+nl : p+46+nl+xl]
		for q := 0; q+4 <= len(extra); {
			id := binary.LittleEndian.Uint16(extra[q:])
			sz := int(binary.LittleEndian.Uint16(extra[q+2:]))
			if q+4+sz > len(extra) {
				break
			}
			val := extra[q+4 : q+4+sz]
			if id == 0x9901 && sz >= 7 {
				c.aes = true
				c.aesStrength = val[4]
				c.aesMethod = binary.LittleEndian.Uint16(val[5:])
				c.method = 99
			}
			q += 4 + sz
		}
		centrals = append(centrals, c)
		p += 45 + nl + xl + cl
	}
	if len(centrals) > 0 {
		entries := make([]entry, 0, len(centrals))
		for _, c := range centrals {
			off := int(c.off)
			if off+30 > len(d) || binary.LittleEndian.Uint32(d[off:]) != 0x04034b50 {
				continue
			}
			nl := int(binary.LittleEndian.Uint16(d[off+26:]))
			xl := int(binary.LittleEndian.Uint16(d[off+28:]))
			if off+30+nl+xl > len(d) {
				continue
			}
			dataStart := off + 30 + nl + xl
			dataEnd := dataStart + int(c.comp)
			if dataEnd > len(d) {
				continue
			}
			e := entry{name: c.name, flags: c.flags, method: c.method, modTime: c.modTime, crc: c.crc, compSize: c.comp, uncompSize: c.uncomp, data: d[dataStart:dataEnd], aes: c.aes, aesStrength: c.aesStrength, aesMethod: c.aesMethod}
			extra := d[off+30+nl : off+30+nl+xl]
			for q := 0; q+4 <= len(extra); {
				id := binary.LittleEndian.Uint16(extra[q:])
				sz := int(binary.LittleEndian.Uint16(extra[q+2:]))
				if q+4+sz > len(extra) {
					break
				}
				val := extra[q+4 : q+4+sz]
				if id == 0x9901 && sz >= 7 {
					e.aes = true
					e.aesStrength = val[4]
					e.aesMethod = binary.LittleEndian.Uint16(val[5:])
					e.method = 99
				}
				q += 4 + sz
			}
			entries = append(entries, e)
		}
		if len(entries) > 0 {
			return entries, nil
		}
	}
	entries := []entry{}
	for off := 0; off+30 <= len(d); {
		sig := binary.LittleEndian.Uint32(d[off:])
		if sig == 0x02014b50 || sig == 0x06054b50 {
			break
		}
		if sig != 0x04034b50 {
			return entries, nil
		}
		flags := binary.LittleEndian.Uint16(d[off+6:])
		method := binary.LittleEndian.Uint16(d[off+8:])
		modTime := binary.LittleEndian.Uint16(d[off+10:])
		crc := binary.LittleEndian.Uint32(d[off+14:])
		comp := binary.LittleEndian.Uint32(d[off+18:])
		uncomp := binary.LittleEndian.Uint32(d[off+22:])
		nl := int(binary.LittleEndian.Uint16(d[off+26:]))
		xl := int(binary.LittleEndian.Uint16(d[off+28:]))
		if off+30+nl+xl > len(d) {
			return nil, errors.New("bad zip")
		}
		name := string(d[off+30 : off+30+nl])
		extra := d[off+30+nl : off+30+nl+xl]
		dataStart := off + 30 + nl + xl
		dataEnd := dataStart + int(comp)
		if dataEnd > len(d) {
			return nil, errors.New("bad zip")
		}
		e := entry{name: name, flags: flags, method: method, modTime: modTime, crc: crc, compSize: comp, uncompSize: uncomp, data: d[dataStart:dataEnd]}
		for p := 0; p+4 <= len(extra); {
			id := binary.LittleEndian.Uint16(extra[p:])
			sz := int(binary.LittleEndian.Uint16(extra[p+2:]))
			if p+4+sz > len(extra) {
				break
			}
			val := extra[p+4 : p+4+sz]
			if id == 0x9901 && sz >= 7 {
				e.aes = true
				e.aesStrength = val[4]
				e.aesMethod = binary.LittleEndian.Uint16(val[5:])
				e.method = 99
			}
			p += 4 + sz
		}
		entries = append(entries, e)
		off = dataEnd
	}
	return entries, nil
}

func checkPassword(e entry, p string) bool {
	if e.aes {
		return checkAES(e, p)
	}
	return checkZipCrypto(e, p)
}

func checkAES(e entry, password string) bool {
	keyLen := 16
	saltLen := 8
	switch e.aesStrength {
	case 1:
		keyLen = 16
		saltLen = 8
	case 2:
		keyLen = 24
		saltLen = 12
	case 3:
		keyLen = 32
		saltLen = 16
	default:
		return false
	}
	if len(e.data) < saltLen+2+10 {
		return false
	}
	salt := e.data[:saltLen]
	verifier := e.data[saltLen : saltLen+2]
	enc := e.data[saltLen+2 : len(e.data)-10]
	auth := e.data[len(e.data)-10:]
	dk := pbkdf2sha1([]byte(password), salt, 1000, 2*keyLen+2)
	if !bytes.Equal(dk[2*keyLen:2*keyLen+2], verifier) {
		return false
	}
	mac := hmac.New(sha1.New, dk[keyLen:2*keyLen])
	mac.Write(enc)
	return hmac.Equal(mac.Sum(nil)[:10], auth)
}

func pbkdf2sha1(password, salt []byte, iter, keyLen int) []byte {
	hLen := 20
	blocks := (keyLen + hLen - 1) / hLen
	out := make([]byte, 0, blocks*hLen)
	for b := 1; b <= blocks; b++ {
		mac := hmac.New(sha1.New, password)
		mac.Write(salt)
		var ib [4]byte
		binary.BigEndian.PutUint32(ib[:], uint32(b))
		mac.Write(ib[:])
		u := mac.Sum(nil)
		t := append([]byte(nil), u...)
		for i := 1; i < iter; i++ {
			mac = hmac.New(sha1.New, password)
			mac.Write(u)
			u = mac.Sum(nil)
			for j := range t {
				t[j] ^= u[j]
			}
		}
		out = append(out, t...)
	}
	return out[:keyLen]
}

func checkZipCrypto(e entry, password string) bool {
	if len(e.data) < 12 {
		return false
	}
	z := newZipCrypto(password)
	dec := make([]byte, len(e.data))
	for i, b := range e.data {
		dec[i] = z.decryptByte(b)
	}
	body := dec[12:]
	var plain []byte
	switch e.method {
	case 0:
		plain = body
	case 8:
		r := flate.NewReader(bytes.NewReader(body))
		defer r.Close()
		b, err := io.ReadAll(r)
		if err != nil {
			return false
		}
		plain = b
	default:
		return false
	}
	if uint32(len(plain)) != e.uncompSize {
		return false
	}
	return crc32.ChecksumIEEE(plain) == e.crc
}

type zipCrypto struct{ k0, k1, k2 uint32 }

func newZipCrypto(p string) *zipCrypto {
	z := &zipCrypto{0x12345678, 0x23456789, 0x34567890}
	for i := 0; i < len(p); i++ {
		z.update(p[i])
	}
	return z
}
func (z *zipCrypto) update(b byte) {
	z.k0 = crc32Update(z.k0, b)
	z.k1 = z.k1 + uint32(byte(z.k0))
	z.k1 = z.k1*134775813 + 1
	z.k2 = crc32Update(z.k2, byte(z.k1>>24))
}
func (z *zipCrypto) decryptByte(c byte) byte {
	t := uint16(z.k2) | 2
	p := byte((uint32(t) * (uint32(t) ^ 1)) >> 8)
	out := c ^ p
	z.update(out)
	return out
}
func crc32Update(crc uint32, b byte) uint32 {
	return crc32.IEEETable[(crc^uint32(b))&0xff] ^ (crc >> 8)
}

func brute(e entry, chars []rune, min, max int, start string) string {
	started := start == ""
	for l := min; l <= max; l++ {
		buf := make([]rune, l)
		var rec func(int) string
		rec = func(pos int) string {
			if pos == l {
				s := string(buf)
				if !started {
					if s == start {
						started = true
					} else {
						return ""
					}
				}
				if checkPassword(e, s) {
					return s
				}
				return ""
			}
			for _, c := range chars {
				buf[pos] = c
				if r := rec(pos + 1); r != "" {
					return r
				}
			}
			return ""
		}
		if r := rec(0); r != "" {
			return r
		}
	}
	return ""
}

func printElapsed(d time.Duration) {
	ms := d / time.Millisecond
	d -= ms * time.Millisecond
	us := d / time.Microsecond
	d -= us * time.Microsecond
	ns := d / time.Nanosecond
	fmt.Printf("Time elapsed: %dms %dus %dns\n", ms, us, ns)
}
