package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type arrayFlags []string

func (a *arrayFlags) String() string { return strings.Join(*a, ",") }
func (a *arrayFlags) Set(s string) error {
	*a = append(*a, s)
	return nil
}

type config struct {
	upper, lower, title, normalize bool
	german, symbols, invert        bool
	delete, squeeze                bool
	literal                        bool
	failAny, failNone              bool
	dryRun, failNoFiles            bool
	hidden, gitignored, sorted     bool
	joinScopes                     bool
	glob                           string
	threads, verbose               int
	stdinDetection, stdoutDetection string
	germanPrefer, germanNaive      bool
	scope, replacement             string
	hasReplacement, scopeProvided  bool
	langScopes                     []langScope
}

type langScope struct{ lang, kind string }

func main() {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	code, err := run(cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(code)
	}
	os.Exit(code)
}

func parseArgs(args []string) (config, error) {
	args = expandShortClusters(args)
	var cfg config
	cfg.scope = ".*"
	cfg.stdinDetection = "auto"
	cfg.stdoutDetection = "auto"
	if envBool("UPPER") { cfg.upper = true }
	if envBool("LOWER") { cfg.lower = true }
	if envBool("TITLECASE") { cfg.title = true }
	if envBool("NORMALIZE") { cfg.normalize = true }
	if envBool("INVERT") { cfg.invert = true }
	if envBool("LITERAL_STRING") { cfg.literal = true }
	if envBool("SQUEEZE") { cfg.squeeze = true }
	if envBool("REPLACE") {
		cfg.replacement = os.Getenv("REPLACE")
		cfg.hasReplacement = true
	}
	if envBool("C") { cfg.langScopes = append(cfg.langScopes, langScope{"c", os.Getenv("C")}) }
	if envBool("GO") { cfg.langScopes = append(cfg.langScopes, langScope{"go", os.Getenv("GO")}) }
	if envBool("PYTHON") { cfg.langScopes = append(cfg.langScopes, langScope{"python", os.Getenv("PYTHON")}) }
	if envBool("RUST") { cfg.langScopes = append(cfg.langScopes, langScope{"rust", os.Getenv("RUST")}) }
	if envBool("TYPESCRIPT") { cfg.langScopes = append(cfg.langScopes, langScope{"typescript", os.Getenv("TYPESCRIPT")}) }
	if envBool("CSHARP") { cfg.langScopes = append(cfg.langScopes, langScope{"csharp", os.Getenv("CSHARP")}) }
	if envBool("HCL") { cfg.langScopes = append(cfg.langScopes, langScope{"hcl", os.Getenv("HCL")}) }

	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			if i+1 >= len(args) { return cfg, errors.New("error: replacement expected after --") }
			cfg.replacement = args[i+1]
			cfg.hasReplacement = true
			i = len(args)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			if !cfg.scopeProvided {
				cfg.scope = a
				cfg.scopeProvided = true
			} else if !cfg.hasReplacement {
				cfg.replacement = a
				cfg.hasReplacement = true
			}
			continue
		}
		switch a {
		case "-h", "--help":
			printHelp(); os.Exit(0)
		case "-V", "--version":
			fmt.Println("srgn 0.14.1"); os.Exit(0)
		case "-u", "--upper": cfg.upper = true
		case "-l", "--lower": cfg.lower = true
		case "-t", "--titlecase": cfg.title = true
		case "-n", "--normalize": cfg.normalize = true
		case "-g", "--german": cfg.german = true
		case "-S", "--symbols": cfg.symbols = true
		case "-d", "--delete": cfg.delete = true
		case "-s", "--squeeze", "--squeeze-repeats": cfg.squeeze = true
		case "-i", "--invert": cfg.invert = true
		case "-L", "--literal-string": cfg.literal = true
		case "--fail-any": cfg.failAny = true
		case "--fail-none": cfg.failNone = true
		case "--dry-run": cfg.dryRun = true
		case "--fail-no-files": cfg.failNoFiles = true
		case "-H", "--hidden": cfg.hidden = true
		case "--gitignored": cfg.gitignored = true
		case "--sorted": cfg.sorted = true
		case "-j", "--join-language-scopes": cfg.joinScopes = true
		case "--german-prefer-original": cfg.germanPrefer = true
		case "--german-naive": cfg.germanNaive = true
		case "-G", "--glob":
			i++; if i >= len(args) { return cfg, errors.New("error: --glob requires a value") }; cfg.glob = args[i]
		case "--stdin-detection":
			i++; if i >= len(args) { return cfg, errors.New("error: --stdin-detection requires a value") }; cfg.stdinDetection = args[i]
		case "--stdout-detection":
			i++; if i >= len(args) { return cfg, errors.New("error: --stdout-detection requires a value") }; cfg.stdoutDetection = args[i]
		case "--threads":
			i++; if i >= len(args) { return cfg, errors.New("error: --threads requires a value") }
		case "-v", "--verbose":
			cfg.verbose++
		case "--completions":
			i++; if i >= len(args) { return cfg, errors.New("error: --completions requires a shell") }; printCompletion(args[i]); os.Exit(0)
		default:
			if isLangOpt(a) {
				i++; if i >= len(args) { return cfg, fmt.Errorf("error: %s requires a value", a) }
				cfg.langScopes = append(cfg.langScopes, langScope{langName(a), args[i]})
			} else if strings.HasPrefix(a, "--") && strings.HasSuffix(a, "-query-file") {
				i++; if i >= len(args) { return cfg, fmt.Errorf("error: %s requires a value", a) }
				b, _ := os.ReadFile(args[i]); cfg.langScopes = append(cfg.langScopes, langScope{strings.TrimSuffix(strings.TrimPrefix(a, "--"), "-query-file"), string(b)})
			} else if strings.HasPrefix(a, "--") && strings.HasSuffix(a, "-query") {
				i++; if i >= len(args) { return cfg, fmt.Errorf("error: %s requires a value", a) }
				cfg.langScopes = append(cfg.langScopes, langScope{strings.TrimSuffix(strings.TrimPrefix(a, "--"), "-query"), args[i]})
			} else {
				return cfg, fmt.Errorf("error: unexpected argument %s", a)
			}
		}
	}
	if cfg.delete && !cfg.scopeProvided {
		return cfg, errors.New("error: the following required arguments were not provided:\n  <SCOPE>")
	}
	if cfg.literal && !cfg.scopeProvided {
		return cfg, errors.New("Error: Literal string mode requires an explicit scope")
	}
	return cfg, nil
}

func expandShortClusters(args []string) []string {
	var out []string
	for _, a := range args {
		if strings.HasPrefix(a, "--") || !strings.HasPrefix(a, "-") || len(a) <= 2 {
			out = append(out, a)
			continue
		}
		ok := true
		for _, r := range a[1:] {
			if !strings.ContainsRune("ultngSdsiLHjv", r) {
				ok = false
				break
			}
		}
		if !ok || strings.ContainsAny(a[1:], "G") {
			out = append(out, a)
			continue
		}
		for _, r := range a[1:] {
			out = append(out, "-"+string(r))
		}
	}
	return out
}

func isLangOpt(s string) bool {
	switch s { case "--c", "--go", "--python", "--py", "--rust", "--rs", "--typescript", "--ts", "--csharp", "--cs", "--hcl": return true }
	return false
}
func langName(s string) string {
	s = strings.TrimPrefix(s, "--")
	switch s { case "py": return "python"; case "rs": return "rust"; case "ts": return "typescript"; case "cs": return "csharp" }
	return s
}
func envBool(k string) bool {
	v, ok := os.LookupEnv(k); if !ok { return false }
	return v == "" || strings.EqualFold(v, "true")
}

func run(cfg config) (int, error) {
	if cfg.glob != "" {
		return runFiles(cfg)
	}
	data, _ := io.ReadAll(os.Stdin)
	if len(data) == 0 && len(cfg.langScopes) > 0 && cfg.stdinDetection != "force-readable" {
		return runAutoFiles(cfg)
	}
	if len(data) == 0 && cfg.stdinDetection == "force-unreadable" {
		return 0, nil
	}
	out, matched, err := process(string(data), "(stdin)", cfg)
	if err != nil { return 1, err }
	if cfg.failAny && matched { return 1, errors.New("Error applying: Some input was in scope") }
	if cfg.failNone && !matched { return 1, errors.New("Error applying: No input was in scope") }
	if out != "" { fmt.Print(out) }
	return 0, nil
}

func runAutoFiles(cfg config) (int, error) {
	exts := map[string]bool{}
	for _, ls := range cfg.langScopes {
		switch ls.lang {
		case "go":
			exts[".go"] = true
		case "python":
			exts[".py"] = true
		case "rust":
			exts[".rs"] = true
		case "typescript":
			exts[".ts"] = true; exts[".tsx"] = true
		case "c":
			exts[".c"] = true; exts[".h"] = true
		case "csharp":
			exts[".cs"] = true
		case "hcl":
			exts[".tf"] = true; exts[".hcl"] = true
		}
	}
	var files []string
	filepath.WalkDir(".", func(path string, d os.DirEntry, err error) error {
		if err != nil { return nil }
		if d.IsDir() {
			base := filepath.Base(path)
			if !cfg.hidden && strings.HasPrefix(base, ".") && path != "." { return filepath.SkipDir }
			return nil
		}
		if exts[filepath.Ext(path)] { files = append(files, path) }
		return nil
	})
	if cfg.sorted { sort.Strings(files) }
	any := false
	for _, f := range files {
		b, err := os.ReadFile(f); if err != nil { continue }
		out, matched, err := process(string(b), f, cfg); if err != nil { return 1, err }
		any = any || matched
		if cfg.failAny && matched { return 1, errors.New("Error applying: Some input was in scope") }
		if hasAction(cfg) {
			if !cfg.dryRun {
				if err := os.WriteFile(f, []byte(out), 0644); err != nil { return 1, err }
				fmt.Println(f)
			} else if out != string(b) {
				fmt.Print(simpleDiff(f, string(b), out))
			}
		} else if out != "" {
			fmt.Print(out)
		}
	}
	if cfg.failNoFiles && len(files) == 0 { return 1, errors.New("No files found") }
	if cfg.failNone && !any { return 1, errors.New("Error applying: No input was in scope") }
	return 0, nil
}

func runFiles(cfg config) (int, error) {
	files, err := filepath.Glob(cfg.glob); if err != nil { return 1, err }
	var real []string
	for _, f := range files {
		info, err := os.Stat(f); if err == nil && !info.IsDir() { real = append(real, f) }
	}
	if cfg.sorted { sort.Strings(real) }
	if len(real) == 0 {
		if cfg.failNoFiles { return 1, errors.New("No files found") }
		return 0, nil
	}
	any := false
	var dry bytes.Buffer
	for _, f := range real {
		b, err := os.ReadFile(f); if err != nil { return 1, err }
		out, matched, err := process(string(b), f, cfg); if err != nil { return 1, err }
		any = any || matched
		if cfg.failAny && matched { return 1, errors.New("Error applying: Some input was in scope") }
		if hasAction(cfg) {
			if cfg.dryRun {
				if out != string(b) { dry.WriteString(simpleDiff(f, string(b), out)) }
			} else {
				if err := os.WriteFile(f, []byte(out), 0644); err != nil { return 1, err }
				fmt.Println(f)
			}
		} else if out != "" {
			fmt.Print(out)
		}
	}
	if cfg.failNone && !any { return 1, errors.New("Error applying: No input was in scope") }
	if cfg.dryRun {
		if dry.Len() == 0 { return 1, errors.New("No input was in scope") }
		fmt.Print(dry.String())
	}
	return 0, nil
}

func process(input, name string, cfg config) (string, bool, error) {
	re, err := makeRegex(cfg.scope, cfg.literal); if err != nil { return "", false, err }
	ranges := languageRanges(input, cfg)
	scopeRanges := intersectRegex(input, ranges, re)
	matched := len(scopeRanges) > 0
	if !hasAction(cfg) {
		if len(cfg.langScopes) > 0 {
			return searchOutput(input, name, scopeRanges, re), matched, nil
		}
		fmt.Fprintln(os.Stderr, "[2026-05-27T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.")
		return input, matched, nil
	}
	if cfg.delete {
		return replaceRanges(input, scopeRanges, func(s string, m []string) string { return "" }), matched, nil
	}
	if cfg.squeeze {
		return squeezeByRegex(input, re), matched, nil
	}
	if cfg.hasReplacement {
		input = replaceRegexInRanges(input, scopeRanges, re, cfg.replacement)
		ranges = languageRanges(input, cfg)
		scopeRanges = intersectRegex(input, ranges, re)
	}
	out := replaceRanges(input, scopeRanges, func(s string, _ []string) string {
		if cfg.symbols { s = symbols(s, cfg.invert) }
		if cfg.german { s = german(s, cfg.germanNaive) }
		if cfg.upper { s = strings.ToUpper(s) }
		if cfg.lower { s = strings.ToLower(s) }
		if cfg.title { s = titlecase(s) }
		if cfg.normalize { s = stripMarks(s) }
		return s
	})
	return out, matched, nil
}

func hasAction(c config) bool {
	return c.upper || c.lower || c.title || c.normalize || c.german || c.symbols || c.delete || c.squeeze || c.hasReplacement
}

func makeRegex(scope string, lit bool) (*regexp.Regexp, error) {
	if lit { scope = regexp.QuoteMeta(scope) }
	return regexp.Compile(scope)
}

type span struct{ start, end int }

func languageRanges(s string, cfg config) []span {
	all := []span{{0, len(s)}}
	if len(cfg.langScopes) == 0 { return all }
	var combined []span
	for i, ls := range cfg.langScopes {
		rs := rangesForLang(s, ls.lang, ls.kind)
		if cfg.joinScopes {
			combined = append(combined, rs...)
		} else if i == 0 {
			combined = rs
		} else {
			combined = intersectSpans(combined, rs)
		}
	}
	if cfg.joinScopes { return mergeSpans(combined) }
	return combined
}

func intersectRegex(s string, bases []span, re *regexp.Regexp) []span {
	var out []span
	for _, b := range bases {
		part := s[b.start:b.end]
		for _, loc := range re.FindAllStringIndex(part, -1) {
			if loc[0] == loc[1] { continue }
			out = append(out, span{b.start + loc[0], b.start + loc[1]})
		}
	}
	return mergeSpans(out)
}

func replaceRegexInRanges(s string, ranges []span, re *regexp.Regexp, repl string) string {
	var b strings.Builder
	pos := 0
	for _, r := range ranges {
		if r.start < pos { continue }
		b.WriteString(s[pos:r.start])
		b.WriteString(re.ReplaceAllString(s[r.start:r.end], repl))
		pos = r.end
	}
	b.WriteString(s[pos:])
	return b.String()
}

func replaceRanges(s string, ranges []span, fn func(string, []string) string) string {
	var b strings.Builder
	pos := 0
	for _, r := range ranges {
		if r.start < pos { continue }
		b.WriteString(s[pos:r.start])
		b.WriteString(fn(s[r.start:r.end], nil))
		pos = r.end
	}
	b.WriteString(s[pos:])
	return b.String()
}

func squeezeByRegex(s string, re *regexp.Regexp) string {
	locs := re.FindAllStringIndex(s, -1)
	if len(locs) == 0 { return s }
	var b strings.Builder
	pos, i := 0, 0
	for i < len(locs) {
		st, en := locs[i][0], locs[i][1]
		if st < pos || st == en { i++; continue }
		j := i + 1
		last := en
		for j < len(locs) && locs[j][0] == last {
			last = locs[j][1]; j++
		}
		b.WriteString(s[pos:st])
		b.WriteString(s[st:en])
		pos = last; i = j
	}
	b.WriteString(s[pos:])
	return b.String()
}

func searchOutput(s, name string, ranges []span, re *regexp.Regexp) string {
	var b strings.Builder
	seen := map[int]bool{}
	for _, r := range ranges {
		lineStart := strings.LastIndex(s[:r.start], "\n") + 1
		lineEndRel := strings.Index(s[r.start:], "\n")
		lineEnd := len(s); if lineEndRel >= 0 { lineEnd = r.start + lineEndRel }
		if seen[lineStart] { continue }
		seen[lineStart] = true
		lineNo := 1 + strings.Count(s[:lineStart], "\n")
		colStart := utf8Col(s[lineStart:r.start])
		colEnd := colStart + utf8Col(s[r.start:r.end])
		line := s[lineStart:lineEnd]
		fmt.Fprintf(&b, "%s:%d:%d-%d:%s\n", name, lineNo, colStart, colEnd, line)
		_ = re
	}
	return b.String()
}

func utf8Col(s string) int { return len([]rune(s)) }

func rangesForLang(s, lang, kind string) []span {
	base := strings.SplitN(kind, "~", 2)[0]
	switch lang {
	case "python":
		return pythonRanges(s, base)
	case "hcl":
		return hclRanges(s, base)
	default:
		return cLikeRanges(s, base)
	}
}

func cLikeRanges(s, kind string) []span {
	comments, stringsp := scanCStyle(s)
	switch kind {
	case "comments", "comment", "doc-comments":
		return comments
	case "strings", "string", "struct-tags":
		return stringsp
	case "func", "function", "function-def", "method", "free-func", "fn", "impl-fn", "pub-fn", "priv-fn", "const-fn", "async-fn", "unsafe-fn", "extern-fn", "test-fn":
		return blockRangesByKeywords(s, []string{"func", "function", "fn"})
	case "class", "struct", "enum", "interface", "trait", "impl", "union", "switch", "if", "for", "while", "do", "select", "go", "defer", "try-catch", "namespace":
		return blockRangesByKeywords(s, []string{strings.Split(kind, "-")[0]})
	case "imports", "includes", "uses", "usings":
		return lineRangesContaining(s, []string{"import", "#include", "use ", "using "})
	case "identifier", "identifiers", "type-identifier", "type-params", "expression", "variable", "var", "const", "let", "type-def", "type-alias", "declaration", "call-expression", "enum-variant", "attribute", "unsafe", "labeled", "goto":
		return []span{{0, len(s)}}
	default:
		return []span{{0, len(s)}}
	}
}

func scanCStyle(s string) ([]span, []span) {
	var comments, strs []span
	for i := 0; i < len(s); {
		if i+1 < len(s) && s[i] == '/' && s[i+1] == '/' {
			j := i+2; for j < len(s) && s[j] != '\n' { j++ }
			comments = append(comments, span{i, j}); i = j; continue
		}
		if i+1 < len(s) && s[i] == '/' && s[i+1] == '*' {
			j := i+2; for j+1 < len(s) && !(s[j] == '*' && s[j+1] == '/') { j++ }
			if j+1 < len(s) { j += 2 }
			comments = append(comments, span{i, j}); i = j; continue
		}
		if s[i] == '"' || s[i] == '\'' || s[i] == '`' {
			q := s[i]; j := i+1
			for j < len(s) {
				if q != '`' && s[j] == '\\' { j += 2; continue }
				if s[j] == q { j++; break }
				j++
			}
			strs = append(strs, span{i, j}); i = j; continue
		}
		i++
	}
	return comments, strs
}

func blockRangesByKeywords(s string, kws []string) []span {
	var out []span
	for _, kw := range kws {
		re := regexp.MustCompile(`\b` + regexp.QuoteMeta(kw) + `\b`)
		for _, loc := range re.FindAllStringIndex(s, -1) {
			st := loc[0]
			open := strings.IndexByte(s[loc[1]:], '{')
			if open < 0 { out = append(out, lineSpan(s, st)); continue }
			o := loc[1] + open
			depth, j := 0, o
			for ; j < len(s); j++ {
				if s[j] == '{' { depth++ }
				if s[j] == '}' { depth--; if depth == 0 { j++; break } }
			}
			out = append(out, span{st, j})
		}
	}
	return mergeSpans(out)
}

func lineSpan(s string, idx int) span {
	st := strings.LastIndex(s[:idx], "\n") + 1
	enRel := strings.IndexByte(s[idx:], '\n')
	if enRel < 0 { return span{st, len(s)} }
	return span{st, idx + enRel}
}

func lineRangesContaining(s string, needles []string) []span {
	var out []span
	off := 0
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := sc.Text()
		for _, n := range needles {
			if strings.Contains(line, n) { out = append(out, span{off, off + len(line)}); break }
		}
		off += len(line) + 1
	}
	return out
}

func pythonRanges(s, kind string) []span {
	switch kind {
	case "comments":
		var out []span
		for _, r := range lineRangesContaining(s, []string{"#"}) {
			line := s[r.start:r.end]; if i := strings.IndexByte(line, '#'); i >= 0 { out = append(out, span{r.start+i, r.end}) }
		}
		return out
	case "strings", "doc-strings":
		_, strs := scanPython(s); return strs
	case "class", "def", "async-def", "methods", "class-methods", "static-methods", "with", "try", "lambda":
		return pythonBlockRanges(s, kind)
	case "imports":
		return lineRangesContaining(s, []string{"import ", "from "})
	default:
		return []span{{0, len(s)}}
	}
}

func scanPython(s string) ([]span, []span) {
	var comments, strs []span
	for i := 0; i < len(s); {
		if s[i] == '#' { j := i+1; for j < len(s) && s[j] != '\n' { j++ }; comments = append(comments, span{i,j}); i=j; continue }
		if s[i] == '"' || s[i] == '\'' {
			q := s[i]; triple := i+2 < len(s) && s[i+1] == q && s[i+2] == q; j := i+1
			if triple { j = i+3 }
			for j < len(s) {
				if !triple && s[j] == '\\' { j += 2; continue }
				if triple && j+2 < len(s) && s[j] == q && s[j+1] == q && s[j+2] == q { j += 3; break }
				if !triple && s[j] == q { j++; break }
				j++
			}
			strs = append(strs, span{i,j}); i=j; continue
		}
		i++
	}
	return comments, strs
}

func pythonBlockRanges(s, kind string) []span {
	prefix := "def "
	if kind == "class" { prefix = "class " } else if kind == "async-def" { prefix = "async def " } else if kind == "with" || kind == "try" || kind == "lambda" { prefix = kind }
	var out []span
	lines := strings.SplitAfter(s, "\n")
	off := 0
	for i, line := range lines {
		trim := strings.TrimLeft(line, " \t")
		if strings.HasPrefix(trim, prefix) {
			indent := len(line) - len(trim)
			end := off + len(line)
			pos := off + len(line)
			for _, ln := range lines[i+1:] {
				t := strings.TrimLeft(ln, " \t\r\n")
				if t != "" && len(ln)-len(strings.TrimLeft(ln, " \t")) <= indent { break }
				pos += len(ln); end = pos
			}
			out = append(out, span{off, end})
		}
		off += len(line)
	}
	return out
}

func hclRanges(s, kind string) []span {
	switch kind {
	case "comments": return lineRangesContaining(s, []string{"#", "//"})
	case "strings": _, str := scanCStyle(s); return str
	case "variable", "resource", "data", "output", "provider", "terraform", "locals", "module", "required-providers":
		return blockRangesByKeywords(s, []string{strings.ReplaceAll(kind, "-", "_")})
	default: return []span{{0, len(s)}}
	}
}

func intersectSpans(a, b []span) []span {
	var out []span
	for _, x := range a {
		for _, y := range b {
			st, en := max(x.start, y.start), min(x.end, y.end)
			if st < en { out = append(out, span{st, en}) }
		}
	}
	return mergeSpans(out)
}
func mergeSpans(in []span) []span {
	if len(in) == 0 { return nil }
	sort.Slice(in, func(i,j int) bool { if in[i].start == in[j].start { return in[i].end < in[j].end }; return in[i].start < in[j].start })
	out := []span{in[0]}
	for _, r := range in[1:] {
		last := &out[len(out)-1]
		if r.start <= last.end { if r.end > last.end { last.end = r.end } } else { out = append(out, r) }
	}
	return out
}
func min(a,b int) int { if a < b { return a }; return b }
func max(a,b int) int { if a > b { return a }; return b }

func titlecase(s string) string {
	return strings.Map(func(r rune) rune { return r }, strings.Title(s))
}

func stripMarks(s string) string {
	repl := strings.NewReplacer("á","a","à","a","â","a","ä","a","ã","a","å","a","Á","A","À","A","Â","A","Ä","A","Ã","A","Å","A","é","e","è","e","ê","e","ë","e","É","E","È","E","Ê","E","Ë","E","í","i","ì","i","î","i","ï","i","Í","I","Ì","I","Î","I","Ï","I","ó","o","ò","o","ô","o","ö","o","õ","o","Ó","O","Ò","O","Ô","O","Ö","O","Õ","O","ú","u","ù","u","û","u","ü","u","Ú","U","Ù","U","Û","U","Ü","U","ñ","n","Ñ","N","ç","c","Ç","C","ß","ß")
	return repl.Replace(s)
}

func german(s string, naive bool) string {
	repl := strings.NewReplacer("Ae","Ä","Oe","Ö","Ue","Ü","ae","ä","oe","ö","ue","ü","ss","ß")
	return repl.Replace(s)
}

func symbols(s string, inv bool) string {
	pairs := [][2]string{{"!=", "≠"}, {"==", "≡"}, {"<=", "≤"}, {">=", "≥"}, {"->", "→"}, {"<-", "←"}, {"=>", "⇒"}, {"<=", "≤"}, {">>", "»"}, {"<<", "«"}, {"+-", "±"}, {"&&", "∧"}, {"||", "∨"}}
	if inv {
		var r []string
		for _, p := range pairs { r = append(r, p[1], p[0]) }
		return strings.NewReplacer(r...).Replace(s)
	}
	var r []string
	for _, p := range pairs { r = append(r, p[0], p[1]) }
	return strings.NewReplacer(r...).Replace(s)
}

func simpleDiff(name, old, new string) string {
	return fmt.Sprintf("--- %s\n+++ %s\n-%s\n+%s\n", name, name, strings.TrimRight(old, "\n"), strings.TrimRight(new, "\n"))
}

func printHelp() {
	fmt.Println(`A grep-like tool which understands source code syntax and allows for manipulation in addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Options:
  -h, --help       Print help
  -V, --version    Print version
  -u, --upper      Uppercase anything in scope
  -l, --lower      Lowercase anything in scope
  -t, --titlecase  Titlecase anything in scope
  -n, --normalize  Normalize anything in scope
  -g, --german     Perform substitutions on German words
  -S, --symbols    Perform substitutions on symbols
  -d, --delete     Delete anything in scope
  -s, --squeeze    Squeeze consecutive occurrences of scope into one
  -G, --glob GLOB  Glob of files to work on
      --dry-run    Do not overwrite files
  -L, --literal-string  Interpret scope as literal string`)
}

func printCompletion(shell string) {
	fmt.Printf("# completion script for %s\n", shell)
}

var _ = unicode.IsLetter
