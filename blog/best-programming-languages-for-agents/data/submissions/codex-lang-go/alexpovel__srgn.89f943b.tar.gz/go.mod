module srgnclone

go 1.21
