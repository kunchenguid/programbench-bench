package main

import (
	"bufio"
	"compress/gzip"
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
)

type Rec struct {
	Fields []string
	Chrom  string
	Start  int
	End    int
	Index  int
}

type Genome struct {
	Order []string
	Size  map[string]int
	Rank  map[string]int
}

func main() {
	if len(os.Args) < 2 || os.Args[1] == "--help" || os.Args[1] == "-h" {
		printMainHelp()
		return
	}
	if os.Args[1] == "--version" {
		fmt.Println("bedtools v2.31.0")
		return
	}
	cmd := os.Args[1]
	args := os.Args[2:]
	var err error
	switch cmd {
	case "intersect", "intersectBed":
		err = cmdIntersect(args)
	case "merge", "mergeBed":
		err = cmdMerge(args)
	case "complement", "complementBed":
		err = cmdComplement(args)
	case "genomecov", "genomeCoverageBed":
		err = cmdGenomecov(args)
	case "jaccard":
		err = cmdJaccard(args)
	case "closest", "closestBed":
		err = cmdClosest(args)
	case "makewindows":
		err = cmdMakewindows(args)
	case "flank", "flankBed":
		err = cmdFlank(args)
	case "slop", "slopBed":
		err = cmdSlop(args)
	case "subtract", "subtractBed":
		err = cmdSubtract(args)
	case "sort", "sortBed":
		err = cmdSort(args)
	case "groupby", "groupBy":
		err = cmdGroupby(args)
	case "coverage", "coverageBed":
		err = cmdCoverage(args)
	case "window":
		err = cmdWindow(args)
	default:
		fmt.Fprintf(os.Stderr, "*****ERROR: Unrecognized command: %s *****\n\n", cmd)
		printMainHelp()
		os.Exit(1)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func printMainHelp() {
	fmt.Println("bedtools is a powerful toolset for genome arithmetic.")
	fmt.Println()
	fmt.Println("Usage:     bedtools <subcommand> [options]")
	fmt.Println()
	fmt.Println("The bedtools sub-commands include:")
	fmt.Println("    intersect     Find overlapping intervals in various ways.")
	fmt.Println("    closest       Find the closest, potentially non-overlapping interval.")
	fmt.Println("    coverage      Compute the coverage over defined intervals.")
	fmt.Println("    genomecov     Compute the coverage over an entire genome.")
	fmt.Println("    merge         Combine overlapping/nearby intervals into a single interval.")
	fmt.Println("    complement    Extract intervals _not_ represented by an interval file.")
	fmt.Println("    subtract      Remove intervals based on overlaps b/w two files.")
	fmt.Println("    slop          Adjust the size of intervals.")
	fmt.Println("    flank         Create new intervals from the flanks of existing intervals.")
	fmt.Println("    sort          Order the intervals in a file.")
	fmt.Println("    makewindows   Make interval \"windows\" across a genome.")
	fmt.Println("    groupby       Group by common cols. & summarize oth. cols.")
}

func parseCommon(args []string) map[string][]string {
	m := map[string][]string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if !strings.HasPrefix(a, "-") {
			m["_"] = append(m["_"], a)
			continue
		}
		key := strings.TrimLeft(a, "-")
		switch key {
		case "wa", "wb", "wo", "wao", "loj", "u", "v", "e", "sorted", "header", "hist", "counts", "mean", "bg", "bga", "dz", "L", "reverse", "pct", "full", "inheader", "outheader", "A", "io":
			m[key] = append(m[key], "true")
		default:
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				m[key] = append(m[key], args[i])
			} else {
				m[key] = append(m[key], "true")
			}
		}
	}
	return m
}

func one(m map[string][]string, k string) string {
	if v := m[k]; len(v) > 0 {
		return v[0]
	}
	return ""
}

func has(m map[string][]string, k string) bool { return len(m[k]) > 0 }

func openMaybeGzip(path string) (io.ReadCloser, error) {
	if path == "" || path == "-" || path == "stdin" {
		return io.NopCloser(os.Stdin), nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	if strings.HasSuffix(path, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		return struct {
			io.Reader
			io.Closer
		}{gz, f}, nil
	}
	return f, nil
}

func readRecs(path string) ([]Rec, error) {
	r, err := openMaybeGzip(path)
	if err != nil {
		return nil, err
	}
	defer r.Close()
	var out []Rec
	sc := bufio.NewScanner(r)
	buf := make([]byte, 1024*1024)
	sc.Buffer(buf, 64*1024*1024)
	idx := 0
	for sc.Scan() {
		line := strings.TrimRight(sc.Text(), "\r")
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "track") || strings.HasPrefix(line, "browser") {
			continue
		}
		fs := strings.Fields(line)
		if len(fs) < 3 {
			continue
		}
		s, e, ok := parseCoords(fs[1], fs[2])
		if !ok {
			continue
		}
		out = append(out, Rec{Fields: fs, Chrom: fs[0], Start: s, End: e, Index: idx})
		idx++
	}
	return out, sc.Err()
}

func parseCoords(a, b string) (int, int, bool) {
	s, err1 := strconv.Atoi(a)
	e, err2 := strconv.Atoi(b)
	return s, e, err1 == nil && err2 == nil
}

func readGenome(path string) (Genome, error) {
	recs, err := readRawRows(path)
	g := Genome{Size: map[string]int{}, Rank: map[string]int{}}
	if err != nil {
		return g, err
	}
	for _, fs := range recs {
		if len(fs) < 2 {
			continue
		}
		n, err := strconv.Atoi(fs[1])
		if err != nil {
			continue
		}
		if _, ok := g.Size[fs[0]]; !ok {
			g.Rank[fs[0]] = len(g.Order)
			g.Order = append(g.Order, fs[0])
		}
		g.Size[fs[0]] = n
	}
	return g, nil
}

func readRawRows(path string) ([][]string, error) {
	r, err := openMaybeGzip(path)
	if err != nil {
		return nil, err
	}
	defer r.Close()
	var rows [][]string
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 1024*1024), 64*1024*1024)
	for sc.Scan() {
		line := strings.TrimRight(sc.Text(), "\r")
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		rows = append(rows, strings.Fields(line))
	}
	return rows, sc.Err()
}

func line(r Rec) string { return strings.Join(r.Fields, "\t") }

func overlap(a, b Rec) int {
	if a.Chrom != b.Chrom {
		return 0
	}
	s := max(a.Start, b.Start)
	e := min(a.End, b.End)
	if e > s {
		return e - s
	}
	return 0
}

func distance(a, b Rec) int {
	if a.Chrom != b.Chrom {
		return math.MaxInt / 4
	}
	if overlap(a, b) > 0 {
		return 0
	}
	if a.End <= b.Start {
		return b.Start - a.End
	}
	return a.Start - b.End
}

func passFrac(a, b Rec, ov int, f, F float64, reciprocal, either bool) bool {
	if ov <= 0 {
		return false
	}
	alen := max(1, a.End-a.Start)
	blen := max(1, b.End-b.Start)
	pa := float64(ov)/float64(alen) >= f-1e-12
	pb := float64(ov)/float64(blen) >= F-1e-12
	if reciprocal {
		return pa && pb
	}
	if either {
		return pa || pb
	}
	return pa && pb
}

func parseFloatDefault(s string, d float64) float64 {
	if s == "" {
		return d
	}
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return d
	}
	return v
}

func parseIntDefault(s string, d int) int {
	if s == "" {
		return d
	}
	v, err := strconv.Atoi(s)
	if err != nil {
		return d
	}
	return v
}

func cmdIntersect(args []string) error {
	m := parseCommon(args)
	af, bvals := one(m, "a"), m["b"]
	if af == "" || len(bvals) == 0 {
		return fmt.Errorf("*****ERROR: -a and -b are required")
	}
	a, err := readRecs(af)
	if err != nil {
		return err
	}
	var bfiles []string
	for _, v := range bvals {
		bfiles = append(bfiles, strings.Split(v, ",")...)
	}
	if extras := m["_"]; len(extras) > 0 {
		bfiles = append(bfiles, extras...)
	}
	var dbs [][]Rec
	for _, bf := range bfiles {
		br, err := readRecs(bf)
		if err != nil {
			return err
		}
		dbs = append(dbs, br)
	}
	names := m["names"]
	f := parseFloatDefault(one(m, "f"), 1e-9)
	F := parseFloatDefault(one(m, "F"), 1e-9)
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, ar := range a {
		count := 0
		wroteU := false
		var hits []struct{ db int; r Rec; ov int }
		for di, db := range dbs {
			for _, br := range db {
				if ov := overlap(ar, br); passFrac(ar, br, ov, f, F, has(m, "r"), has(m, "e")) {
					count++
					hits = append(hits, struct{ db int; r Rec; ov int }{di, br, ov})
					if has(m, "u") && !wroteU {
						fmt.Fprintln(out, line(ar))
						wroteU = true
					}
				}
			}
		}
		if has(m, "u") {
			continue
		}
		if has(m, "c") {
			fmt.Fprintf(out, "%s\t%d\n", line(ar), count)
			continue
		}
		if has(m, "v") {
			if count == 0 {
				fmt.Fprintln(out, line(ar))
			}
			continue
		}
		if (has(m, "wao") || has(m, "loj")) && count == 0 {
			nulls := ".\t-1\t-1"
			if has(m, "wao") {
				fmt.Fprintf(out, "%s\t%s\t0\n", line(ar), nulls)
			} else {
				fmt.Fprintf(out, "%s\t%s\n", line(ar), nulls)
			}
			continue
		}
		for _, h := range hits {
			if has(m, "wo") || has(m, "wao") {
				fmt.Fprintf(out, "%s\t%s\t%d\n", line(ar), line(h.r), h.ov)
			} else if has(m, "wa") && has(m, "wb") {
				if len(dbs) > 1 {
					label := strconv.Itoa(h.db + 1)
					if h.db < len(names) {
						label = names[h.db]
					}
					fmt.Fprintf(out, "%s\t%s\t%s\n", line(ar), label, line(h.r))
				} else {
					fmt.Fprintf(out, "%s\t%s\n", line(ar), line(h.r))
				}
			} else if has(m, "wa") {
				fmt.Fprintln(out, line(ar))
			} else if has(m, "wb") {
				fmt.Fprintln(out, line(h.r))
			} else {
				fs := append([]string{}, ar.Fields...)
				fs[1] = strconv.Itoa(max(ar.Start, h.r.Start))
				fs[2] = strconv.Itoa(min(ar.End, h.r.End))
				fmt.Fprintln(out, strings.Join(fs, "\t"))
			}
		}
	}
	return nil
}

func cmdMerge(args []string) error {
	m := parseCommon(args)
	in := one(m, "i")
	if in == "" {
		return fmt.Errorf("*****ERROR: -i is required")
	}
	recs, err := readRecs(in)
	if err != nil {
		return err
	}
	sortRecs(recs, nil, false, false)
	d := parseIntDefault(one(m, "d"), 0)
	cols := parseIntList(one(m, "c"))
	ops := parseStrList(one(m, "o"))
	if len(cols) == 0 && len(ops) > 0 {
		cols = []int{5}
	}
	if len(ops) == 0 && len(cols) > 0 {
		ops = []string{"sum"}
	}
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for i := 0; i < len(recs); {
		cur := recs[i]
		group := []Rec{cur}
		end := cur.End
		j := i + 1
		for j < len(recs) && recs[j].Chrom == cur.Chrom && recs[j].Start <= end+d {
			if recs[j].End > end {
				end = recs[j].End
			}
			group = append(group, recs[j])
			j++
		}
		fields := []string{cur.Chrom, strconv.Itoa(cur.Start), strconv.Itoa(end)}
		fields = append(fields, summarize(group, cols, ops, one(m, "delim"))...)
		fmt.Fprintln(out, strings.Join(fields, "\t"))
		i = j
	}
	return nil
}

func cmdComplement(args []string) error {
	m := parseCommon(args)
	recs, err := readRecs(one(m, "i"))
	if err != nil {
		return err
	}
	g, err := readGenome(one(m, "g"))
	if err != nil {
		return err
	}
	sortRecs(recs, &g, false, false)
	present := map[string]bool{}
	for _, r := range recs {
		present[r.Chrom] = true
	}
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	by := byChrom(recs)
	for _, c := range g.Order {
		if has(m, "L") && !present[c] {
			continue
		}
		pos := 0
		for _, r := range by[c] {
			if r.Start > pos {
				fmt.Fprintf(out, "%s\t%d\t%d\n", c, pos, r.Start)
			}
			if r.End > pos {
				pos = r.End
			}
		}
		if pos < g.Size[c] {
			fmt.Fprintf(out, "%s\t%d\t%d\n", c, pos, g.Size[c])
		}
	}
	return nil
}

func cmdGenomecov(args []string) error {
	m := parseCommon(args)
	recs, err := readRecs(one(m, "i"))
	if err != nil {
		return err
	}
	g, err := readGenome(one(m, "g"))
	if err != nil {
		return err
	}
	scale := parseFloatDefault(one(m, "scale"), 1)
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	if has(m, "d") || has(m, "dz") {
		by := byChrom(recs)
		for _, c := range g.Order {
			size := g.Size[c]
			diff := make([]int, size+1)
			for _, r := range by[c] {
				s, e := max(0, r.Start), min(size, r.End)
				if e > s {
					diff[s]++
					diff[e]--
				}
			}
			depth := 0
			for i := 0; i < size; i++ {
				depth += diff[i]
				if has(m, "dz") && depth == 0 {
					continue
				}
				if has(m, "dz") {
					fmt.Fprintf(out, "%s\t%d\t%s\n", c, i, fmtFloat(float64(depth)*scale))
				} else {
					fmt.Fprintf(out, "%s\t%d\t%s\n", c, i+1, fmtFloat(float64(depth)*scale))
				}
			}
		}
		return nil
	}
	if has(m, "bg") || has(m, "bga") {
		emitBedGraph(out, recs, g, has(m, "bga"), scale)
		return nil
	}
	hist := map[string]map[int]int{}
	totalHist := map[int]int{}
	totalGenome := 0
	by := byChrom(recs)
	for _, c := range g.Order {
		size := g.Size[c]
		totalGenome += size
		h := coverageHist(by[c], size)
		hist[c] = h
		for d, n := range h {
			totalHist[d] += n
		}
		for _, d := range sortedDepths(h) {
			fmt.Fprintf(out, "%s\t%d\t%d\t%d\t%s\n", c, d, h[d], size, fmtFloat(float64(h[d])/float64(size)))
		}
	}
	for _, d := range sortedDepths(totalHist) {
		fmt.Fprintf(out, "genome\t%d\t%d\t%d\t%s\n", d, totalHist[d], totalGenome, fmtFloat(float64(totalHist[d])/float64(totalGenome)))
	}
	return nil
}

func cmdJaccard(args []string) error {
	m := parseCommon(args)
	a, err := readRecs(one(m, "a"))
	if err != nil {
		return err
	}
	b, err := readRecs(one(m, "b"))
	if err != nil {
		return err
	}
	am := merged(a, 0)
	bm := merged(b, 0)
	inter, n := intersectionLen(am, bm)
	union := totalLen(am) + totalLen(bm) - inter
	fmt.Println("intersection\tunion-intersection\tjaccard\tn_intersections")
	j := 0.0
	if union > 0 {
		j = float64(inter) / float64(union)
	}
	fmt.Printf("%d\t%d\t%s\t%d\n", inter, union, fmtFloat(j), n)
	return nil
}

func cmdClosest(args []string) error {
	m := parseCommon(args)
	a, err := readRecs(one(m, "a"))
	if err != nil {
		return err
	}
	b, err := readRecs(one(m, "b"))
	if err != nil {
		return err
	}
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, ar := range a {
		best := math.MaxInt / 4
		var hits []Rec
		for _, br := range b {
			if ar.Chrom != br.Chrom {
				continue
			}
			if has(m, "io") && overlap(ar, br) > 0 {
				continue
			}
			d := distance(ar, br)
			if d < best {
				best = d
				hits = []Rec{br}
			} else if d == best {
				hits = append(hits, br)
			}
		}
		if len(hits) == 0 {
			null := ".\t-1\t-1"
			if has(m, "d") {
				fmt.Fprintf(out, "%s\t%s\t-1\n", line(ar), null)
			} else {
				fmt.Fprintf(out, "%s\t%s\n", line(ar), null)
			}
			continue
		}
		if one(m, "t") == "first" && len(hits) > 1 {
			hits = hits[:1]
		}
		if one(m, "t") == "last" && len(hits) > 1 {
			hits = hits[len(hits)-1:]
		}
		for _, br := range hits {
			if has(m, "d") {
				fmt.Fprintf(out, "%s\t%s\t%d\n", line(ar), line(br), best)
			} else {
				fmt.Fprintf(out, "%s\t%s\n", line(ar), line(br))
			}
		}
	}
	return nil
}

func cmdMakewindows(args []string) error {
	m := parseCommon(args)
	var bases []Rec
	if gf := one(m, "g"); gf != "" {
		g, err := readGenome(gf)
		if err != nil {
			return err
		}
		for i, c := range g.Order {
			bases = append(bases, Rec{Fields: []string{c, "0", strconv.Itoa(g.Size[c])}, Chrom: c, Start: 0, End: g.Size[c], Index: i})
		}
	} else {
		var err error
		bases, err = readRecs(one(m, "b"))
		if err != nil {
			return err
		}
	}
	w := parseIntDefault(one(m, "w"), 0)
	step := parseIntDefault(one(m, "s"), w)
	n := parseIntDefault(one(m, "n"), 0)
	id := one(m, "i")
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, r := range bases {
		windows := [][2]int{}
		if n > 0 {
			length := r.End - r.Start
			for k := 0; k < n; k++ {
				s := r.Start + int(math.Floor(float64(k*length)/float64(n)))
				e := r.Start + int(math.Floor(float64((k+1)*length)/float64(n)))
				windows = append(windows, [2]int{s, e})
			}
		} else {
			for s := r.Start; s < r.End; s += step {
				e := min(s+w, r.End)
				windows = append(windows, [2]int{s, e})
				if step <= 0 {
					break
				}
			}
		}
		for k, win := range windows {
			num := k + 1
			if has(m, "reverse") {
				num = len(windows) - k
			}
			fs := []string{r.Chrom, strconv.Itoa(win[0]), strconv.Itoa(win[1])}
			switch id {
			case "src":
				if len(r.Fields) >= 4 {
					fs = append(fs, r.Fields[3])
				}
			case "winnum":
				fs = append(fs, strconv.Itoa(num))
			case "srcwinnum":
				src := r.Chrom
				if len(r.Fields) >= 4 {
					src = r.Fields[3]
				}
				fs = append(fs, fmt.Sprintf("%s_%d", src, num))
			}
			fmt.Fprintln(out, strings.Join(fs, "\t"))
		}
	}
	return nil
}

func cmdSlop(args []string) error {
	return slopFlank(args, false)
}
func cmdFlank(args []string) error {
	return slopFlank(args, true)
}

func slopFlank(args []string, flank bool) error {
	m := parseCommon(args)
	recs, err := readRecs(one(m, "i"))
	if err != nil {
		return err
	}
	g, err := readGenome(one(m, "g"))
	if err != nil {
		return err
	}
	l, r := parseIntDefault(one(m, "l"), 0), parseIntDefault(one(m, "r"), 0)
	if b := one(m, "b"); b != "" {
		l, r = parseIntDefault(b, 0), parseIntDefault(b, 0)
	}
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, rec := range recs {
		size := g.Size[rec.Chrom]
		left, right := l, r
		if has(m, "s") && len(rec.Fields) >= 6 && rec.Fields[5] == "-" {
			left, right = r, l
		}
		if !flank {
			fs := append([]string{}, rec.Fields...)
			fs[1] = strconv.Itoa(max(0, rec.Start-left))
			fs[2] = strconv.Itoa(min(size, rec.End+right))
			fmt.Fprintln(out, strings.Join(fs, "\t"))
		} else {
			if rec.Start-left < rec.Start {
				s, e := max(0, rec.Start-left), rec.Start
				if e > s {
					fs := append([]string{}, rec.Fields...)
					fs[1], fs[2] = strconv.Itoa(s), strconv.Itoa(e)
					fmt.Fprintln(out, strings.Join(fs, "\t"))
				}
			}
			if rec.End < rec.End+right {
				s, e := rec.End, min(size, rec.End+right)
				if e > s {
					fs := append([]string{}, rec.Fields...)
					fs[1], fs[2] = strconv.Itoa(s), strconv.Itoa(e)
					fmt.Fprintln(out, strings.Join(fs, "\t"))
				}
			}
		}
	}
	return nil
}

func cmdSubtract(args []string) error {
	m := parseCommon(args)
	a, err := readRecs(one(m, "a"))
	if err != nil {
		return err
	}
	b, err := readRecs(one(m, "b"))
	if err != nil {
		return err
	}
	f := parseFloatDefault(one(m, "f"), 1e-9)
	F := parseFloatDefault(one(m, "F"), 1e-9)
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, ar := range a {
		segs := [][2]int{{ar.Start, ar.End}}
		removeAll := false
		for _, br := range b {
			ov := overlap(ar, br)
			if !passFrac(ar, br, ov, f, F, has(m, "r"), has(m, "e")) {
				continue
			}
			if has(m, "A") {
				removeAll = true
				break
			}
			var ns [][2]int
			for _, sg := range segs {
				if br.End <= sg[0] || br.Start >= sg[1] {
					ns = append(ns, sg)
				} else {
					if br.Start > sg[0] {
						ns = append(ns, [2]int{sg[0], min(br.Start, sg[1])})
					}
					if br.End < sg[1] {
						ns = append(ns, [2]int{max(br.End, sg[0]), sg[1]})
					}
				}
			}
			segs = ns
		}
		if removeAll {
			continue
		}
		for _, sg := range segs {
			if sg[1] > sg[0] {
				fs := append([]string{}, ar.Fields...)
				fs[1], fs[2] = strconv.Itoa(sg[0]), strconv.Itoa(sg[1])
				fmt.Fprintln(out, strings.Join(fs, "\t"))
			}
		}
	}
	return nil
}

func cmdSort(args []string) error {
	m := parseCommon(args)
	recs, err := readRecs(one(m, "i"))
	if err != nil {
		return err
	}
	var gp *Genome
	if gf := one(m, "g"); gf != "" {
		g, err := readGenome(gf)
		if err != nil {
			return err
		}
		gp = &g
	}
	sortRecs(recs, gp, has(m, "sizeA") || has(m, "chrThenSizeA"), has(m, "sizeD") || has(m, "chrThenSizeD"))
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, r := range recs {
		fmt.Fprintln(out, line(r))
	}
	return nil
}

func cmdGroupby(args []string) error {
	m := parseCommon(args)
	rows, err := readRawRows(firstNonEmpty(one(m, "i"), "-"))
	if err != nil {
		return err
	}
	gcols := parseIntList(firstNonEmpty(one(m, "g"), one(m, "grp"), "1,2,3"))
	cols := parseIntList(firstNonEmpty(one(m, "c"), one(m, "opCols")))
	ops := parseStrList(firstNonEmpty(one(m, "o"), one(m, "ops"), "sum"))
	delim := firstNonEmpty(one(m, "delim"), ",")
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for i := 0; i < len(rows); {
		key := groupKey(rows[i], gcols)
		group := [][]string{rows[i]}
		j := i + 1
		for j < len(rows) && groupKey(rows[j], gcols) == key {
			group = append(group, rows[j])
			j++
		}
		fs := selectCols(rows[i], gcols)
		if has(m, "full") {
			fs = append([]string{}, rows[i]...)
		}
		fs = append(fs, summarizeRows(group, cols, ops, delim)...)
		fmt.Fprintln(out, strings.Join(fs, "\t"))
		i = j
	}
	return nil
}

func cmdCoverage(args []string) error {
	m := parseCommon(args)
	a, err := readRecs(one(m, "a"))
	if err != nil {
		return err
	}
	b, err := readRecs(one(m, "b"))
	if err != nil {
		return err
	}
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, ar := range a {
		count := 0
		diff := make([]int, ar.End-ar.Start+1)
		for _, br := range b {
			if ov := overlap(ar, br); ov > 0 {
				count++
				s := max(ar.Start, br.Start) - ar.Start
				e := min(ar.End, br.End) - ar.Start
				diff[s]++
				diff[e]--
			}
		}
		if has(m, "counts") {
			fmt.Fprintf(out, "%s\t%d\n", line(ar), count)
			continue
		}
		depth, covered, sum := 0, 0, 0
		for i := 0; i < ar.End-ar.Start; i++ {
			depth += diff[i]
			sum += depth
			if depth > 0 {
				covered++
			}
			if has(m, "d") {
				fmt.Fprintf(out, "%s\t%d\t%d\n", line(ar), i+1, depth)
			}
		}
		if has(m, "d") {
			continue
		}
		length := max(1, ar.End-ar.Start)
		if has(m, "mean") {
			fmt.Fprintf(out, "%s\t%s\n", line(ar), fmtFloat(float64(sum)/float64(length)))
		} else {
			fmt.Fprintf(out, "%s\t%d\t%d\t%d\t%s\n", line(ar), count, covered, length, fmtFloat(float64(covered)/float64(length)))
		}
	}
	return nil
}

func cmdWindow(args []string) error {
	m := parseCommon(args)
	a, err := readRecs(one(m, "a"))
	if err != nil {
		return err
	}
	b, err := readRecs(one(m, "b"))
	if err != nil {
		return err
	}
	w := parseIntDefault(one(m, "w"), 1000)
	out := bufio.NewWriter(os.Stdout)
	defer out.Flush()
	for _, ar := range a {
		ext := ar
		ext.Start -= w
		ext.End += w
		for _, br := range b {
			if overlap(ext, br) > 0 {
				fmt.Fprintf(out, "%s\t%s\n", line(ar), line(br))
			}
		}
	}
	return nil
}

func sortRecs(recs []Rec, g *Genome, sizeA, sizeD bool) {
	sort.SliceStable(recs, func(i, j int) bool {
		a, b := recs[i], recs[j]
		if sizeA || sizeD {
			if !(strings.HasPrefix(os.Args[1], "sort") && strings.Contains(strings.Join(os.Args, " "), "chrThen")) {
				la, lb := a.End-a.Start, b.End-b.Start
				if la != lb {
					return (la < lb) == sizeA
				}
			}
		}
		if a.Chrom != b.Chrom {
			if g != nil {
				return g.Rank[a.Chrom] < g.Rank[b.Chrom]
			}
			return a.Chrom < b.Chrom
		}
		if sizeA || sizeD {
			la, lb := a.End-a.Start, b.End-b.Start
			if la != lb {
				return (la < lb) == sizeA
			}
		}
		if a.Start != b.Start {
			return a.Start < b.Start
		}
		return a.End < b.End
	})
}

func byChrom(recs []Rec) map[string][]Rec {
	m := map[string][]Rec{}
	for _, r := range recs {
		m[r.Chrom] = append(m[r.Chrom], r)
	}
	return m
}

func merged(recs []Rec, d int) []Rec {
	cp := append([]Rec{}, recs...)
	sortRecs(cp, nil, false, false)
	var out []Rec
	for _, r := range cp {
		if len(out) == 0 || out[len(out)-1].Chrom != r.Chrom || r.Start > out[len(out)-1].End+d {
			out = append(out, r)
		} else if r.End > out[len(out)-1].End {
			out[len(out)-1].End = r.End
			out[len(out)-1].Fields[2] = strconv.Itoa(r.End)
		}
	}
	return out
}

func totalLen(rs []Rec) int {
	n := 0
	for _, r := range rs {
		n += max(0, r.End-r.Start)
	}
	return n
}

func intersectionLen(a, b []Rec) (int, int) {
	sum, n := 0, 0
	for _, ar := range a {
		for _, br := range b {
			if ov := overlap(ar, br); ov > 0 {
				sum += ov
				n++
			}
		}
	}
	return sum, n
}

func coverageHist(rs []Rec, size int) map[int]int {
	events := map[int]int{0: 0, size: 0}
	for _, r := range rs {
		s, e := max(0, r.Start), min(size, r.End)
		if e > s {
			events[s]++
			events[e]--
		}
	}
	h := map[int]int{}
	var pos []int
	for p := range events {
		pos = append(pos, p)
	}
	sort.Ints(pos)
	depth := 0
	for i := 0; i < len(pos)-1; i++ {
		depth += events[pos[i]]
		if pos[i+1] > pos[i] {
			h[depth] += pos[i+1] - pos[i]
		}
	}
	return h
}

func emitBedGraph(out *bufio.Writer, recs []Rec, g Genome, includeZero bool, scale float64) {
	by := byChrom(recs)
	for _, c := range g.Order {
		size := g.Size[c]
		events := map[int]int{0: 0, size: 0}
		for _, r := range by[c] {
			s, e := max(0, r.Start), min(size, r.End)
			if e > s {
				events[s]++
				events[e]--
			}
		}
		var pos []int
		for p := range events {
			pos = append(pos, p)
		}
		sort.Ints(pos)
		depth := 0
		for i := 0; i < len(pos)-1; i++ {
			depth += events[pos[i]]
			if pos[i+1] > pos[i] && (depth > 0 || includeZero) {
				fmt.Fprintf(out, "%s\t%d\t%d\t%s\n", c, pos[i], pos[i+1], fmtFloat(float64(depth)*scale))
			}
		}
	}
}

func sortedDepths(h map[int]int) []int {
	var ds []int
	for d := range h {
		ds = append(ds, d)
	}
	sort.Ints(ds)
	return ds
}

func parseIntList(s string) []int {
	if s == "" {
		return nil
	}
	var out []int
	for _, p := range strings.Split(s, ",") {
		if v, err := strconv.Atoi(strings.TrimSpace(p)); err == nil {
			out = append(out, v)
		}
	}
	return out
}

func parseStrList(s string) []string {
	if s == "" {
		return nil
	}
	var out []string
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

func summarize(group []Rec, cols []int, ops []string, delim string) []string {
	rows := make([][]string, len(group))
	for i, r := range group {
		rows[i] = r.Fields
	}
	return summarizeRows(rows, cols, ops, firstNonEmpty(delim, ","))
}

func summarizeRows(rows [][]string, cols []int, ops []string, delim string) []string {
	if len(cols) == 0 || len(ops) == 0 {
		return nil
	}
	n := max(len(cols), len(ops))
	var out []string
	for i := 0; i < n; i++ {
		col := cols[min(i, len(cols)-1)]
		op := ops[min(i, len(ops)-1)]
		var vals []string
		for _, row := range rows {
			if col-1 >= 0 && col-1 < len(row) {
				vals = append(vals, row[col-1])
			}
		}
		out = append(out, applyOp(vals, op, delim))
	}
	return out
}

func applyOp(vals []string, op, delim string) string {
	switch op {
	case "count":
		return strconv.Itoa(len(vals))
	case "collapse":
		return strings.Join(vals, delim)
	case "concat":
		return strings.Join(vals, "")
	case "distinct", "distinct_only":
		seen := map[string]bool{}
		var out []string
		for _, v := range vals {
			if !seen[v] {
				seen[v] = true
				out = append(out, v)
			}
		}
		return strings.Join(out, delim)
	case "count_distinct":
		seen := map[string]bool{}
		for _, v := range vals {
			seen[v] = true
		}
		return strconv.Itoa(len(seen))
	case "first":
		if len(vals) > 0 {
			return vals[0]
		}
	case "last":
		if len(vals) > 0 {
			return vals[len(vals)-1]
		}
	case "min", "max", "sum", "mean", "median":
		nums := toNums(vals)
		if len(nums) == 0 {
			return "."
		}
		sort.Float64s(nums)
		if op == "min" {
			return fmtFloat(nums[0])
		}
		if op == "max" {
			return fmtFloat(nums[len(nums)-1])
		}
		sum := 0.0
		for _, v := range nums {
			sum += v
		}
		if op == "sum" {
			return fmtFloat(sum)
		}
		if op == "mean" {
			return fmtFloat(sum / float64(len(nums)))
		}
		if len(nums)%2 == 1 {
			return fmtFloat(nums[len(nums)/2])
		}
		return fmtFloat((nums[len(nums)/2-1] + nums[len(nums)/2]) / 2)
	}
	return strings.Join(vals, delim)
}

func toNums(vals []string) []float64 {
	var nums []float64
	for _, v := range vals {
		if x, err := strconv.ParseFloat(v, 64); err == nil {
			nums = append(nums, x)
		}
	}
	return nums
}

func groupKey(row []string, cols []int) string {
	return strings.Join(selectCols(row, cols), "\x00")
}

func selectCols(row []string, cols []int) []string {
	var out []string
	for _, c := range cols {
		if c-1 >= 0 && c-1 < len(row) {
			out = append(out, row[c-1])
		} else {
			out = append(out, "")
		}
	}
	return out
}

func firstNonEmpty(xs ...string) string {
	for _, x := range xs {
		if x != "" {
			return x
		}
	}
	return ""
}

func fmtFloat(f float64) string {
	if math.Abs(f-math.Round(f)) < 1e-9 {
		return strconv.FormatInt(int64(math.Round(f)), 10)
	}
	return strconv.FormatFloat(f, 'g', 6, 64)
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
