module mlrclone

go 1.21
