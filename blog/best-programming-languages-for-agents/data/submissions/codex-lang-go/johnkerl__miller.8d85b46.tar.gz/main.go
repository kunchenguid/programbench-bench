package main

import (
	"bufio"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type Record struct {
	Keys []string
	Vals map[string]string
}

type Config struct {
	inFmt, outFmt       string
	implicitCSV, noHead bool
	quoteAll           bool
}

func main() {
	cfg := Config{inFmt: "dkvp", outFmt: "dkvp"}
	args := os.Args[1:]
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		usage()
		return
	}
	if args[0] == "--version" {
		fmt.Println("mlr 6.16.0")
		return
	}
	if args[0] == "version" {
		fmt.Println("mlr version 6.16.0 for linux/amd64/go1.24.0")
		return
	}
	if args[0] == "help" || strings.HasPrefix(args[0], "-") && isHelpShort(args[0]) {
		help(args)
		return
	}
	for len(args) > 0 && strings.HasPrefix(args[0], "-") {
		a := args[0]
		args = args[1:]
		switch a {
		case "--csv", "-c", "--c2c":
			cfg.inFmt, cfg.outFmt = "csv", "csv"
		case "--tsv", "-t", "--t2t":
			cfg.inFmt, cfg.outFmt = "tsv", "tsv"
		case "--dkvp", "--d2d":
			cfg.inFmt, cfg.outFmt = "dkvp", "dkvp"
		case "--json", "-j", "--j2j":
			cfg.inFmt, cfg.outFmt = "json", "json"
		case "--jsonl", "--l2l":
			cfg.inFmt, cfg.outFmt = "jsonl", "jsonl"
		case "--nidx", "--n2n":
			cfg.inFmt, cfg.outFmt = "nidx", "nidx"
		case "--pprint", "--p2p":
			cfg.inFmt, cfg.outFmt = "pprint", "pprint"
		case "--icsv":
			cfg.inFmt = "csv"
		case "--itsv":
			cfg.inFmt = "tsv"
		case "--idkvp":
			cfg.inFmt = "dkvp"
		case "--ijson":
			cfg.inFmt = "json"
		case "--ijsonl":
			cfg.inFmt = "jsonl"
		case "--inidx":
			cfg.inFmt = "nidx"
		case "--ipprint":
			cfg.inFmt = "pprint"
		case "--ocsv":
			cfg.outFmt = "csv"
		case "--otsv":
			cfg.outFmt = "tsv"
		case "--odkvp":
			cfg.outFmt = "dkvp"
		case "--ojson":
			cfg.outFmt = "json"
		case "--ojsonl":
			cfg.outFmt = "jsonl"
		case "--onidx":
			cfg.outFmt = "nidx"
		case "--opprint":
			cfg.outFmt = "pprint"
		case "--headerless-csv-output", "--ho", "--headerless-tsv-output":
			cfg.noHead = true
		case "--implicit-csv-header", "--headerless-csv-input", "--hi", "--implicit-tsv-header":
			cfg.implicitCSV = true
		case "-N":
			cfg.implicitCSV, cfg.noHead = true, true
		case "--quote-all":
			cfg.quoteAll = true
		case "-i":
			if len(args) > 0 {
				cfg.inFmt = normFmt(args[0]); args = args[1:]
			}
		case "-o":
			if len(args) > 0 {
				cfg.outFmt = normFmt(args[0]); args = args[1:]
			}
		case "--io":
			if len(args) > 0 {
				cfg.inFmt = normFmt(args[0]); cfg.outFmt = cfg.inFmt; args = args[1:]
			}
		default:
			// Ignore unsupported global flags with an optional argument conservatively.
		}
	}
	if len(args) == 0 {
		usage()
		return
	}
	segments := splitThen(args)
	var files []string
	if len(segments) > 0 {
		last := segments[len(segments)-1]
		i := firstFileIndex(last)
		if i >= 0 {
			files = append(files, last[i:]...)
			segments[len(segments)-1] = last[:i]
		}
	}
	recs, err := readAll(cfg, files)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	for _, seg := range segments {
		if len(seg) == 0 {
			continue
		}
		recs = applyVerb(seg, recs)
	}
	if err := writeRecords(os.Stdout, cfg, recs); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func normFmt(s string) string {
	switch s {
	case "csv", "csvlite":
		return "csv"
	case "tsv", "tsvlite":
		return "tsv"
	case "json":
		return "json"
	case "jsonl":
		return "jsonl"
	case "pprint":
		return "pprint"
	case "nidx":
		return "nidx"
	default:
		return "dkvp"
	}
}

func splitThen(args []string) [][]string {
	var out [][]string
	var cur []string
	for _, a := range args {
		if a == "then" {
			out = append(out, cur)
			cur = nil
		} else {
			cur = append(cur, a)
		}
	}
	return append(out, cur)
}

func firstFileIndex(args []string) int {
	if len(args) == 0 {
		return -1
	}
	verbs := map[string]bool{"cat": true, "cut": true, "head": true, "tail": true, "sort": true, "count": true, "stats1": true, "filter": true, "put": true, "rename": true, "label": true, "uniq": true, "tac": true, "nothing": true, "top": true, "grep": true, "group-by": true, "regularize": true, "sort-within-records": true, "count-distinct": true}
	if !verbs[args[0]] {
		return 0
	}
	takes := map[string]bool{"-f": true, "-g": true, "-a": true, "-n": true, "-r": true, "-s": true}
	for i := 1; i < len(args); i++ {
		if args[i] == "--" {
			return i + 1
		}
		if strings.HasPrefix(args[i], "-") {
			if takes[args[i]] && i+1 < len(args) {
				i++
			}
			continue
		}
		if args[0] == "filter" || args[0] == "put" || args[0] == "grep" {
			if i == 1 {
				continue
			}
		}
		return i
	}
	return -1
}

func readAll(cfg Config, files []string) ([]Record, error) {
	if len(files) == 0 {
		return readFrom(cfg, os.Stdin)
	}
	var all []Record
	for _, f := range files {
		file, err := os.Open(f)
		if err != nil {
			return nil, err
		}
		recs, err := readFrom(cfg, file)
		file.Close()
		if err != nil {
			return nil, err
		}
		all = append(all, recs...)
	}
	return all, nil
}

func readFrom(cfg Config, r io.Reader) ([]Record, error) {
	switch cfg.inFmt {
	case "csv", "tsv", "pprint":
		return readTable(cfg, r)
	case "nidx":
		return readNIDX(r), nil
	case "json", "jsonl":
		return readJSON(r)
	default:
		return readDKVP(r), nil
	}
}

func readDKVP(r io.Reader) []Record {
	sc := bufio.NewScanner(r)
	var recs []Record
	for sc.Scan() {
		line := strings.TrimRight(sc.Text(), "\r")
		if line == "" {
			continue
		}
		rec := Record{Vals: map[string]string{}}
		parts := strings.Split(line, ",")
		for i, p := range parts {
			k, v, ok := strings.Cut(p, "=")
			if !ok {
				k, v = strconv.Itoa(i+1), p
			}
			add(&rec, k, v)
		}
		recs = append(recs, rec)
	}
	return recs
}

func readNIDX(r io.Reader) []Record {
	sc := bufio.NewScanner(r)
	var recs []Record
	for sc.Scan() {
		fs := strings.Fields(sc.Text())
		rec := Record{Vals: map[string]string{}}
		for i, v := range fs {
			add(&rec, strconv.Itoa(i+1), v)
		}
		recs = append(recs, rec)
	}
	return recs
}

func readTable(cfg Config, r io.Reader) ([]Record, error) {
	if cfg.inFmt == "pprint" {
		sc := bufio.NewScanner(r)
		var rows [][]string
		for sc.Scan() {
			if strings.TrimSpace(sc.Text()) != "" {
				rows = append(rows, strings.Fields(sc.Text()))
			}
		}
		return rowsToRecords(rows, cfg.implicitCSV), nil
	}
	cr := csv.NewReader(r)
	cr.FieldsPerRecord = -1
	if cfg.inFmt == "tsv" {
		cr.Comma = '\t'
	}
	rows, err := cr.ReadAll()
	if err != nil {
		return nil, err
	}
	return rowsToRecords(rows, cfg.implicitCSV), nil
}

func rowsToRecords(rows [][]string, implicit bool) []Record {
	if len(rows) == 0 {
		return nil
	}
	var header []string
	start := 1
	if implicit {
		start = 0
		for i := range rows[0] {
			header = append(header, strconv.Itoa(i+1))
		}
	} else {
		header = rows[0]
	}
	var recs []Record
	for _, row := range rows[start:] {
		rec := Record{Vals: map[string]string{}}
		for i, v := range row {
			k := strconv.Itoa(i + 1)
			if i < len(header) {
				k = header[i]
			}
			add(&rec, k, v)
		}
		for i := len(row); i < len(header); i++ {
			add(&rec, header[i], "")
		}
		recs = append(recs, rec)
	}
	return recs
}

func readJSON(r io.Reader) ([]Record, error) {
	b, _ := io.ReadAll(r)
	s := strings.TrimSpace(string(b))
	if s == "" {
		return nil, nil
	}
	var arr []map[string]interface{}
	if strings.HasPrefix(s, "[") {
		if err := json.Unmarshal([]byte(s), &arr); err != nil {
			return nil, err
		}
	} else {
		for _, line := range strings.Split(s, "\n") {
			var m map[string]interface{}
			if err := json.Unmarshal([]byte(line), &m); err == nil {
				arr = append(arr, m)
			}
		}
	}
	var recs []Record
	for _, m := range arr {
		rec := Record{Vals: map[string]string{}}
		flatten("", m, &rec)
		recs = append(recs, rec)
	}
	return recs, nil
}

func flatten(prefix string, m map[string]interface{}, rec *Record) {
	keys := make([]string, 0, len(m))
	for k := range m { keys = append(keys, k) }
	sort.Strings(keys)
	for _, k := range keys {
		name := k
		if prefix != "" { name = prefix + "." + k }
		switch v := m[k].(type) {
		case map[string]interface{}:
			flatten(name, v, rec)
		default:
			add(rec, name, fmt.Sprint(v))
		}
	}
}

func add(r *Record, k, v string) {
	if r.Vals == nil { r.Vals = map[string]string{} }
	if _, ok := r.Vals[k]; !ok {
		r.Keys = append(r.Keys, k)
	}
	r.Vals[k] = v
}

func applyVerb(args []string, recs []Record) []Record {
	switch args[0] {
	case "cat":
		return recs
	case "nothing":
		return nil
	case "head":
		n := intOpt(args, "-n", 10)
		if n < len(recs) { return recs[:n] }
		return recs
	case "tail":
		n := intOpt(args, "-n", 10)
		if n < len(recs) { return recs[len(recs)-n:] }
		return recs
	case "cut":
		return verbCut(args, recs)
	case "sort":
		return verbSort(args, recs)
	case "tac":
		for i, j := 0, len(recs)-1; i < j; i, j = i+1, j-1 { recs[i], recs[j] = recs[j], recs[i] }
		return recs
	case "count":
		return verbCount(args, recs)
	case "stats1":
		return verbStats1(args, recs)
	case "uniq", "count-distinct":
		return verbUniq(args, recs, args[0] == "count-distinct")
	case "filter":
		return verbFilter(args, recs)
	case "put":
		return verbPut(args, recs)
	case "rename":
		return verbRename(args, recs)
	case "label":
		return verbLabel(args, recs)
	case "regularize":
		for i := range recs { sortRecord(&recs[i]) }
		return recs
	case "sort-within-records":
		for i := range recs { sortRecord(&recs[i]) }
		return recs
	case "group-by":
		return recs
	case "top":
		return verbTop(args, recs)
	case "grep":
		return verbGrep(args, recs)
	default:
		return recs
	}
}

func listOpt(args []string, flag string) []string {
	for i := 1; i+1 < len(args); i++ {
		if args[i] == flag {
			if args[i+1] == "" { return nil }
			return strings.Split(args[i+1], ",")
		}
	}
	return nil
}

func intOpt(args []string, flag string, def int) int {
	for i := 1; i+1 < len(args); i++ {
		if args[i] == flag {
			if n, err := strconv.Atoi(args[i+1]); err == nil { return n }
		}
	}
	return def
}

func verbCut(args []string, recs []Record) []Record {
	fs := listOpt(args, "-f")
	if len(fs) == 0 { return recs }
	exclude := has(args, "-x") || has(args, "--complement")
	var out []Record
	for _, r := range recs {
		nr := Record{Vals: map[string]string{}}
		if exclude {
			ban := map[string]bool{}
			for _, f := range fs { ban[f] = true }
			for _, k := range r.Keys { if !ban[k] { add(&nr, k, r.Vals[k]) } }
		} else {
			for _, f := range fs { if v, ok := r.Vals[f]; ok { add(&nr, f, v) } }
		}
		out = append(out, nr)
	}
	return out
}

func verbSort(args []string, recs []Record) []Record {
	fs := listOpt(args, "-f")
	if len(fs) == 0 { fs = listOpt(args, "-n") }
	numeric := has(args, "-n") || has(args, "--numeric-sort")
	desc := has(args, "-r") || has(args, "--reverse")
	sort.SliceStable(recs, func(i, j int) bool {
		c := compareRecords(recs[i], recs[j], fs, numeric)
		if desc { return c > 0 }
		return c < 0
	})
	return recs
}

func compareRecords(a, b Record, fs []string, numeric bool) int {
	if len(fs) == 0 { fs = unionKeys([]Record{a, b}) }
	for _, f := range fs {
		av, bv := a.Vals[f], b.Vals[f]
		if numeric {
			af, _ := strconv.ParseFloat(av, 64); bf, _ := strconv.ParseFloat(bv, 64)
			if af < bf { return -1 }; if af > bf { return 1 }
		} else {
			if av < bv { return -1 }; if av > bv { return 1 }
		}
	}
	return 0
}

func verbCount(args []string, recs []Record) []Record {
	gs := listOpt(args, "-g")
	if len(gs) == 0 {
		return []Record{{Keys: []string{"count"}, Vals: map[string]string{"count": strconv.Itoa(len(recs))}}}
	}
	type bucket struct { vals []string; n int }
	m := map[string]*bucket{}
	var order []string
	for _, r := range recs {
		vals := make([]string, len(gs))
		for i, g := range gs { vals[i] = r.Vals[g] }
		key := strings.Join(vals, "\x00")
		if m[key] == nil { m[key] = &bucket{vals: vals}; order = append(order, key) }
		m[key].n++
	}
	var out []Record
	for _, key := range order {
		b := m[key]; nr := Record{Vals: map[string]string{}}
		for i, g := range gs { add(&nr, g, b.vals[i]) }
		add(&nr, "count", strconv.Itoa(b.n))
		out = append(out, nr)
	}
	return out
}

type agg struct { n int; sum, min, max float64 }

func verbStats1(args []string, recs []Record) []Record {
	as, fs, gs := listOpt(args, "-a"), listOpt(args, "-f"), listOpt(args, "-g")
	if len(as) == 0 { as = []string{"count"} }
	type group struct { vals []string; stats map[string]*agg }
	groups := map[string]*group{}; var order []string
	for _, r := range recs {
		gvals := make([]string, len(gs)); for i,g := range gs { gvals[i]=r.Vals[g] }
		gkey := strings.Join(gvals, "\x00")
		if groups[gkey] == nil { groups[gkey]=&group{vals:gvals, stats:map[string]*agg{}}; order=append(order,gkey) }
		for _, f := range fs {
			x, err := strconv.ParseFloat(r.Vals[f], 64); if err != nil { continue }
			a := groups[gkey].stats[f]; if a == nil { a=&agg{min:x,max:x}; groups[gkey].stats[f]=a }
			a.n++; a.sum += x; if x < a.min { a.min=x }; if x > a.max { a.max=x }
		}
	}
	var out []Record
	for _, key := range order {
		g := groups[key]; nr := Record{Vals: map[string]string{}}
		for i, name := range gs { add(&nr, name, g.vals[i]) }
		for _, f := range fs {
			a := g.stats[f]
			for _, op := range as {
				name := f + "_" + op
				val := ""
				if a != nil {
					switch op {
					case "count": val = strconv.Itoa(a.n)
					case "sum": val = fmtFloat(a.sum)
					case "mean", "avg": val = fmtFloat(a.sum/float64(a.n))
					case "min": val = fmtFloat(a.min)
					case "max": val = fmtFloat(a.max)
					case "range": val = fmtFloat(a.max-a.min)
					}
				}
				add(&nr, name, val)
			}
		}
		out = append(out, nr)
	}
	return out
}

func verbUniq(args []string, recs []Record, counts bool) []Record {
	fs := listOpt(args, "-f")
	if len(fs) == 0 && len(recs) > 0 { fs = recs[0].Keys }
	m := map[string]int{}; keep := map[string]Record{}; var order []string
	for _, r := range recs {
		vals := make([]string, len(fs)); for i,f := range fs { vals[i]=r.Vals[f] }
		key := strings.Join(vals, "\x00")
		if m[key] == 0 {
			nr := Record{Vals: map[string]string{}}
			for _, f := range fs { add(&nr, f, r.Vals[f]) }
			keep[key] = nr; order = append(order, key)
		}
		m[key]++
	}
	var out []Record
	for _, key := range order {
		nr := keep[key]
		if counts { add(&nr, "count", strconv.Itoa(m[key])) }
		out = append(out, nr)
	}
	return out
}

func verbFilter(args []string, recs []Record) []Record {
	if len(args) < 2 { return recs }
	expr := strings.Join(args[1:], " ")
	var out []Record
	for _, r := range recs {
		if evalBool(expr, r) { out = append(out, r) }
	}
	return out
}

var cmpRe = regexp.MustCompile(`\$([A-Za-z0-9_.-]+)\s*(==|!=|>=|<=|>|=~|<)\s*"?([^"]*)"?`)

func evalBool(expr string, r Record) bool {
	expr = strings.TrimSpace(expr)
	if expr == "true" || expr == "1" { return true }
	m := cmpRe.FindStringSubmatch(expr)
	if m == nil { return false }
	v, op, rhs := r.Vals[m[1]], m[2], m[3]
	switch op {
	case "==": return v == rhs
	case "!=": return v != rhs
	case "=~": ok, _ := regexp.MatchString(rhs, v); return ok
	case ">", "<", ">=", "<=":
		a, ea := strconv.ParseFloat(v, 64); b, eb := strconv.ParseFloat(rhs, 64)
		if ea == nil && eb == nil {
			return op == ">" && a > b || op == "<" && a < b || op == ">=" && a >= b || op == "<=" && a <= b
		}
		return op == ">" && v > rhs || op == "<" && v < rhs || op == ">=" && v >= rhs || op == "<=" && v <= rhs
	}
	return false
}

func verbPut(args []string, recs []Record) []Record {
	if len(args) < 2 { return recs }
	stmt := strings.Join(args[1:], " ")
	parts := strings.Split(stmt, ";")
	for i := range recs {
		for _, p := range parts {
			lhs, rhs, ok := strings.Cut(p, "="); if !ok { continue }
			lhs = strings.TrimSpace(strings.TrimPrefix(lhs, "$"))
			val := evalValue(strings.TrimSpace(rhs), recs[i])
			add(&recs[i], lhs, val)
		}
	}
	return recs
}

func evalValue(expr string, r Record) string {
	expr = strings.Trim(expr, `" `)
	if strings.HasPrefix(expr, "$") && !strings.ContainsAny(expr, "+-*/ ") {
		return r.Vals[strings.TrimPrefix(expr, "$")]
	}
	for _, op := range []string{"+", "-", "*", "/"} {
		if parts := strings.Split(expr, op); len(parts) == 2 {
			a := valueNum(parts[0], r); b := valueNum(parts[1], r)
			switch op { case "+": return fmtFloat(a+b); case "-": return fmtFloat(a-b); case "*": return fmtFloat(a*b); case "/": if b!=0 { return fmtFloat(a/b) } }
		}
	}
	return expr
}

func valueNum(s string, r Record) float64 {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(s, "$") { s = r.Vals[strings.TrimPrefix(s, "$")] }
	x, _ := strconv.ParseFloat(s, 64); return x
}

func verbRename(args []string, recs []Record) []Record {
	if len(args) < 2 { return recs }
	pairs := strings.Split(args[len(args)-1], ",")
	mp := map[string]string{}
	for _, p := range pairs { a,b,ok := strings.Cut(p, "="); if ok { mp[a]=b } }
	for i := range recs {
		for j,k := range recs[i].Keys {
			if nk, ok := mp[k]; ok {
				recs[i].Keys[j]=nk; recs[i].Vals[nk]=recs[i].Vals[k]; delete(recs[i].Vals,k)
			}
		}
	}
	return recs
}

func verbLabel(args []string, recs []Record) []Record {
	if len(args) < 2 { return recs }
	labels := strings.Split(args[1], ",")
	for i := range recs {
		nr := Record{Vals: map[string]string{}}
		for j,k := range recs[i].Keys {
			nk := k; if j < len(labels) { nk = labels[j] }
			add(&nr, nk, recs[i].Vals[k])
		}
		recs[i]=nr
	}
	return recs
}

func verbTop(args []string, recs []Record) []Record {
	n := intOpt(args, "-n", 10)
	recs = verbSort(args, recs)
	for i,j := 0,len(recs)-1; i<j; i,j=i+1,j-1 { recs[i],recs[j]=recs[j],recs[i] }
	if n < len(recs) { return recs[:n] }
	return recs
}

func verbGrep(args []string, recs []Record) []Record {
	if len(args) < 2 { return recs }
	re, err := regexp.Compile(args[1]); if err != nil { return nil }
	var out []Record
	for _, r := range recs {
		for _, k := range r.Keys {
			if re.MatchString(r.Vals[k]) { out=append(out,r); break }
		}
	}
	return out
}

func writeRecords(w io.Writer, cfg Config, recs []Record) error {
	switch cfg.outFmt {
	case "csv", "tsv":
		return writeCSV(w, cfg, recs)
	case "pprint":
		writePPrint(w, recs); return nil
	case "json":
		return writeJSON(w, recs, false)
	case "jsonl":
		return writeJSON(w, recs, true)
	case "nidx":
		for _, r := range recs {
			vals := make([]string, len(r.Keys)); for i,k := range r.Keys { vals[i]=r.Vals[k] }
			fmt.Fprintln(w, strings.Join(vals, " "))
		}
	default:
		for _, r := range recs {
			ps := make([]string, len(r.Keys)); for i,k := range r.Keys { ps[i]=k+"="+r.Vals[k] }
			fmt.Fprintln(w, strings.Join(ps, ","))
		}
	}
	return nil
}

func writeCSV(w io.Writer, cfg Config, recs []Record) error {
	cw := csv.NewWriter(w); if cfg.outFmt == "tsv" { cw.Comma = '\t' }
	keys := unionKeys(recs)
	if !cfg.noHead { if err := cw.Write(keys); err != nil { return err } }
	for _, r := range recs {
		row := make([]string, len(keys)); for i,k := range keys { row[i]=r.Vals[k] }
		if err := cw.Write(row); err != nil { return err }
	}
	cw.Flush(); return cw.Error()
}

func writePPrint(w io.Writer, recs []Record) {
	keys := unionKeys(recs); if len(keys)==0 { return }
	widths := make([]int,len(keys)); for i,k := range keys { widths[i]=len(k) }
	for _, r := range recs { for i,k := range keys { if len(r.Vals[k])>widths[i] { widths[i]=len(r.Vals[k]) } } }
	printRow := func(vals []string) {
		for i,v := range vals {
			if i>0 { fmt.Fprint(w," ") }
			fmt.Fprint(w, v)
			if i < len(vals)-1 { fmt.Fprint(w, strings.Repeat(" ", widths[i]-len(v))) }
		}
		fmt.Fprintln(w)
	}
	printRow(keys)
	for _, r := range recs {
		vals := make([]string,len(keys)); for i,k := range keys { vals[i]=r.Vals[k] }
		printRow(vals)
	}
}

func writeJSON(w io.Writer, recs []Record, lines bool) error {
	toMap := func(r Record) map[string]string { m:=map[string]string{}; for _,k:= range r.Keys { m[k]=r.Vals[k] }; return m }
	enc := json.NewEncoder(w)
	if lines {
		for _, r := range recs { if err := enc.Encode(toMap(r)); err != nil { return err } }
		return nil
	}
	arr := make([]map[string]string,len(recs)); for i,r := range recs { arr[i]=toMap(r) }
	enc.SetIndent("", "  "); return enc.Encode(arr)
}

func unionKeys(recs []Record) []string {
	seen := map[string]bool{}; var keys []string
	for _, r := range recs { for _, k := range r.Keys { if !seen[k] { seen[k]=true; keys=append(keys,k) } } }
	return keys
}

func sortRecord(r *Record) {
	sort.Strings(r.Keys)
}

func fmtFloat(f float64) string {
	if math.IsNaN(f) || math.IsInf(f, 0) { return "" }
	return strconv.FormatFloat(f, 'g', -1, 64)
}

func has(args []string, x string) bool {
	for _, a := range args { if a == x { return true } }
	return false
}

func usage() {
	fmt.Println("Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}")
	fmt.Println()
	fmt.Println("If zero file names are provided, standard input is read, e.g.")
	fmt.Println("  mlr --csv sort -f shape example.csv")
	fmt.Println()
	fmt.Println("Output of one verb may be chained as input to another using \"then\", e.g.")
	fmt.Println("  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv")
	fmt.Println()
	fmt.Println("Please see 'mlr help topics' for more information.")
	fmt.Println("Please also see https://miller.readthedocs.io")
}

func isHelpShort(s string) bool { return s=="-g"||s=="-l"||s=="-L"||s=="-f"||s=="-F"||s=="-k"||s=="-K" }

func help(args []string) {
	topic := ""; if len(args)>1 { topic=args[1] } else if len(args)>0 && isHelpShort(args[0]) { topic=args[0] }
	if topic=="topics" || topic=="" {
		fmt.Println("Type 'mlr help {topic}' for any of the following:")
		fmt.Println("Essentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats")
		fmt.Println("Verbs:\n  mlr help list-verbs\n  mlr help usage-verbs\n  mlr help verb")
		fmt.Println("Functions:\n  mlr help list-functions\n  mlr help usage-functions")
		return
	}
	if topic=="list-verbs" || topic=="-l" {
		fmt.Println(strings.Join([]string{"altkv","bar","bootstrap","case","cat","check","clean-whitespace","count-distinct","count","cut","decimate","fill-down","fill-empty","filter","flatten","format-values","fraction","gap","grep","group-by","group-like","gsub","head","histogram","join","label","least-frequent","most-frequent","put","regularize","rename","reorder","sample","sort","stats1","stats2","tail","top","uniq"}, "\n"))
		return
	}
	if topic=="flags" || topic=="-g" {
		fmt.Println("--csv --tsv --dkvp --json --jsonl --nidx --icsv --idkvp --ocsv --opprint -i -o --io")
		return
	}
	if topic=="file-formats" {
		fmt.Println("CSV, TSV, JSON, JSON Lines, PPRINT, DKVP, and NIDX are supported.")
		return
	}
	fmt.Printf("No detailed help for %s in this reimplementation.\n", topic)
}
