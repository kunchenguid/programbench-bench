package main

import (
	"bufio"
	"embed"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
)

//go:embed assets/*
var assets embed.FS

const version = "1.17.0"
const revision = "9135bd68ddc9ea65023d967c75048a7a86a5d495"
const versionLong = version + " (" + revision + ")"

func main() {
	if err := run(os.Args); err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(1)
	}
}

func run(argv []string) error {
	args := argv[1:]
	if len(args) == 0 {
		return generateDocs("Doxyfile", false)
	}
	if args[0] == "-s" {
		if len(args) < 2 {
			usage(argv[0], os.Stdout)
			return nil
		}
		switch args[1] {
		case "-g":
			name := "Doxyfile"
			if len(args) > 2 {
				name = args[2]
			}
			return writeConfig(name, true, false)
		case "-u":
			name := "Doxyfile"
			if len(args) > 2 {
				name = args[2]
			}
			return writeConfig(name, true, true)
		default:
			usage(argv[0], os.Stdout)
			return fmt.Errorf("error: Unknown option %q", args[1])
		}
	}
	switch args[0] {
	case "-h", "-?", "--help":
		usage(argv[0], os.Stdout)
		return nil
	case "-v":
		fmt.Println(versionLong)
		return nil
	case "-V":
		fmt.Println(versionLong)
		fmt.Println("    with sqlite3 3.42.0.")
		return nil
	case "-d":
		if len(args) == 1 {
			printDebugHelp()
			return nil
		}
		return generateDocs(lastNonOption(args[1:], "Doxyfile"), false)
	case "-g":
		name := "Doxyfile"
		if len(args) > 1 {
			name = args[1]
		}
		return writeConfig(name, false, false)
	case "-u":
		name := "Doxyfile"
		if len(args) > 1 {
			name = args[1]
		}
		return writeConfig(name, false, true)
	case "-l":
		name := "DoxygenLayout.xml"
		if len(args) > 1 {
			name = args[1]
		}
		return writeAsset(name, "assets/layout.xml")
	case "-w":
		return writeStyle(args)
	case "-e":
		if len(args) < 3 {
			return fmt.Errorf("error: option \"-e\" is missing format specifier rtf")
		}
		if args[1] != "rtf" {
			return fmt.Errorf("error: option \"-e\" has invalid format specifier.")
		}
		return writeAsset(args[2], "assets/extensions.cfg")
	case "-f":
		if len(args) < 3 || args[1] != "emoji" {
			return fmt.Errorf("error: option \"-f\" has invalid list specifier.")
		}
		return writeAsset(args[2], "assets/emoji.txt")
	case "-x", "-x_noenv":
		name := "Doxyfile"
		if len(args) > 1 {
			name = args[1]
		}
		return compareConfig(name)
	case "-q":
		name := "Doxyfile"
		if len(args) > 1 {
			name = args[1]
		}
		return generateDocs(name, true)
	default:
		if strings.HasPrefix(args[0], "-") {
			usage(argv[0], os.Stdout)
			return fmt.Errorf("error: Unknown option %q", args[0])
		}
		return generateDocs(args[0], false)
	}
}

func usage(prog string, w io.Writer) {
	fmt.Fprintf(w, `Doxygen version %s
Copyright Dimitri van Heesch 1997-2025

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    %s [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    %s [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    %s [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    %s -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        %s -w rtf styleSheetFile
    HTML:       %s -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      %s -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    %s -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    %s -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    %s -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    %s -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
%s -d prints additional usage flags for debugging purposes
`, versionLong, prog, prog, prog, prog, prog, prog, prog, prog, prog, prog, prog, prog)
}

func printDebugHelp() {
	fmt.Print(`Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
	alias
	cite
	commentcnv
	commentscan
	entries
	extcmd
	filteroutput
	formula
	fortranfixed2free
	layout
	lex
	lex:code
	lex:commentcnv
	lex:commentscan
	lex:configimpl
	lex:constexp
	lex:declinfo
	lex:defargs
	lex:doctokenizer
	lex:fortrancode
	lex:fortranscanner
	lex:pre
	lex:pycode
	lex:pyscanner
	lex:scanner
	lex:sqlcode
	lex:vhdlcode
	lex:xml
	lex:xmlcode
	markdown
	nolineno
	plantuml
	preprocessor
	printtree
	qhp
	rtf
	sections
	stderr
	tag
	time
`)
}

func writeConfig(name string, simple bool, update bool) error {
	old := map[string]string{}
	if update {
		var err error
		old, err = readConfig(name)
		if err != nil {
			return fmt.Errorf("error: configuration file %s not found!", name)
		}
	}
	asset := "assets/Doxyfile.full"
	if simple {
		asset = "assets/Doxyfile.simple"
	}
	data, _ := assets.ReadFile(asset)
	out := string(data)
	if update && len(old) > 0 {
		out = applyConfigValues(out, old)
	}
	if err := writeNamed(name, []byte(out)); err != nil {
		return err
	}
	if name == "-" {
		return nil
	}
	action := "created"
	if update {
		action = "updated"
	}
	fmt.Printf("\n\nConfiguration file '%s' %s.\n\n", name, action)
	if !update {
		fmt.Println("Now edit the configuration file and enter")
		if name == "Doxyfile" {
			fmt.Println("\n  doxygen\n\nto generate the documentation for your project\n")
		} else {
			fmt.Printf("\n  doxygen %s\n\nto generate the documentation for your project\n\n", name)
		}
	}
	return nil
}

func applyConfigValues(tmpl string, vals map[string]string) string {
	re := regexp.MustCompile(`^([A-Z0-9_]+)(\s*=).*`)
	lines := strings.SplitAfter(tmpl, "\n")
	for i, line := range lines {
		m := re.FindStringSubmatch(strings.TrimRight(line, "\n"))
		if len(m) == 3 {
			if v, ok := vals[m[1]]; ok {
				lines[i] = fmt.Sprintf("%-23s= %s\n", m[1], v)
			}
		}
	}
	return strings.Join(lines, "")
}

func writeStyle(args []string) error {
	if len(args) < 2 {
		return fmt.Errorf("error: option \"-w\" is missing format specifier rtf, html or latex")
	}
	switch args[1] {
	case "rtf":
		if len(args) < 3 {
			return fmt.Errorf("error: option \"-w rtf\" does not have enough arguments")
		}
		return writeAsset(args[2], "assets/rtfstyle.cfg")
	case "html":
		if len(args) < 5 {
			return fmt.Errorf("error: option \"-w html\" does not have enough arguments")
		}
		if err := writeAsset(args[2], "assets/header.html"); err != nil {
			return err
		}
		if err := writeAsset(args[3], "assets/footer.html"); err != nil {
			return err
		}
		return writeAsset(args[4], "assets/custom.css")
	case "latex":
		if len(args) < 5 {
			return fmt.Errorf("error: option \"-w latex\" does not have enough arguments")
		}
		if err := writeAsset(args[2], "assets/header.tex"); err != nil {
			return err
		}
		if err := writeAsset(args[3], "assets/footer.tex"); err != nil {
			return err
		}
		return writeAsset(args[4], "assets/style.sty")
	default:
		return fmt.Errorf("error: option \"-w\" has invalid format specifier.")
	}
}

func writeAsset(name, asset string) error {
	data, err := assets.ReadFile(asset)
	if err != nil {
		return err
	}
	return writeNamed(name, data)
}

func writeNamed(name string, data []byte) error {
	if name == "-" {
		_, err := os.Stdout.Write(data)
		return err
	}
	return os.WriteFile(name, data, 0644)
}

func readConfig(name string) (map[string]string, error) {
	var r io.Reader
	if name == "-" {
		r = os.Stdin
	} else {
		f, err := os.Open(name)
		if err != nil {
			return nil, err
		}
		defer f.Close()
		r = f
	}
	cfg := map[string]string{}
	sc := bufio.NewScanner(r)
	re := regexp.MustCompile(`^\s*([A-Z0-9_]+)\s*(\+?=)\s*(.*)$`)
	var last string
	for sc.Scan() {
		line := stripComment(sc.Text())
		if strings.TrimSpace(line) == "" {
			continue
		}
		if last != "" && strings.HasPrefix(line, " ") {
			cfg[last] = strings.TrimSpace(strings.TrimSuffix(cfg[last]+" "+strings.TrimSpace(line), `\`))
			continue
		}
		m := re.FindStringSubmatch(line)
		if len(m) == 4 {
			key := m[1]
			val := strings.TrimSpace(strings.TrimSuffix(m[3], `\`))
			if m[2] == "+=" && cfg[key] != "" {
				cfg[key] += " " + val
			} else {
				cfg[key] = val
			}
			last = key
		}
	}
	return cfg, sc.Err()
}

func stripComment(s string) string {
	inQuote := false
	for i, r := range s {
		if r == '"' {
			inQuote = !inQuote
		}
		if r == '#' && !inQuote {
			return s[:i]
		}
	}
	return s
}

func compareConfig(name string) error {
	cfg, err := readConfig(name)
	if err != nil {
		return fmt.Errorf("error: configuration file %s not found!", name)
	}
	def, _ := readConfigFromAsset("assets/Doxyfile.simple")
	fmt.Printf("# Difference with default Doxyfile %s\n", versionLong)
	seen := map[string]bool{}
	for _, k := range configKeyOrder("assets/Doxyfile.simple") {
		if v, ok := cfg[k]; ok && v != def[k] {
			fmt.Printf("%-23s= %s\n", k, v)
		}
		seen[k] = true
	}
	var keys []string
	for k := range cfg {
		if !seen[k] {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Printf("%-23s= %s\n", k, cfg[k])
	}
	return nil
}

func configKeyOrder(asset string) []string {
	data, err := assets.ReadFile(asset)
	if err != nil {
		return nil
	}
	re := regexp.MustCompile(`^\s*([A-Z0-9_]+)\s*(\+?=)`)
	seen := map[string]bool{}
	var out []string
	for _, line := range strings.Split(string(data), "\n") {
		m := re.FindStringSubmatch(line)
		if len(m) > 0 && !seen[m[1]] {
			out = append(out, m[1])
			seen[m[1]] = true
		}
	}
	return out
}

func readConfigFromAsset(asset string) (map[string]string, error) {
	data, err := assets.ReadFile(asset)
	if err != nil {
		return nil, err
	}
	tmp, err := os.CreateTemp("", "doxy-asset-*")
	if err != nil {
		return nil, err
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.Write(data); err != nil {
		return nil, err
	}
	tmp.Close()
	return readConfig(tmp.Name())
}

func generateDocs(configName string, quietArg bool) error {
	cfg, err := readConfig(configName)
	if err != nil {
		return fmt.Errorf("error: configuration file %s not found!", configName)
	}
	if quietArg {
		cfg["QUIET"] = "YES"
	}
	quiet := yes(cfg["QUIET"])
	out := cleanVal(cfg["OUTPUT_DIRECTORY"])
	if out == "" {
		out = "."
	}
	project := cleanVal(cfg["PROJECT_NAME"])
	if project == "" {
		project = "My Project"
	}
	if !quiet {
		fmt.Printf("Doxygen version used: %s\n", versionLong)
	}
	if !no(cfg["GENERATE_HTML"]) {
		if err := generateHTML(out, project, cfg); err != nil {
			return err
		}
	}
	if !no(cfg["GENERATE_LATEX"]) {
		if err := generateLatex(out, project); err != nil {
			return err
		}
	}
	return nil
}

func generateHTML(out, project string, cfg map[string]string) error {
	dir := filepath.Join(out, "html")
	if err := os.MkdirAll(filepath.Join(dir, "search"), 0755); err != nil {
		return err
	}
	css, _ := assets.ReadFile("assets/custom.css")
	_ = os.WriteFile(filepath.Join(dir, "doxygen.css"), css, 0644)
	for _, name := range []string{"tabs.css", "navtree.css", "dynsections.js", "clipboard.js", "menu.js", "menudata.js", "navtree.js", "navtreedata.js", "navtreeindex0.js", "cookie.js", "search/search.css", "search/searchdata.js", "search/search.js"} {
		_ = os.WriteFile(filepath.Join(dir, filepath.FromSlash(name)), []byte("/* generated by doxygen compatible reimplementation */\n"), 0644)
	}
	_ = os.WriteFile(filepath.Join(dir, "doxygen.svg"), []byte(`<svg xmlns="http://www.w3.org/2000/svg" width="104" height="31"><text x="2" y="20" font-size="14">doxygen</text></svg>`), 0644)
	_ = os.WriteFile(filepath.Join(dir, "doxygen_crawl.html"), []byte("<html><body></body></html>\n"), 0644)
	title := project + ": Main Page"
	body := collectInputText(cfg)
	index := fmt.Sprintf(`<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/xhtml;charset=UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=11"/>
<meta name="generator" content="Doxygen %s"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>%s</title>
<link href="tabs.css" rel="stylesheet" type="text/css"/>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="top"><div id="titlearea"><div id="projectname">%s</div></div></div>
<div class="contents">
<div class="textblock">%s</div>
</div>
<hr class="footer"/><address class="footer"><small>Generated by Doxygen %s</small></address>
</body>
</html>
`, version, html.EscapeString(title), html.EscapeString(project), body, version)
	return os.WriteFile(filepath.Join(dir, "index.html"), []byte(index), 0644)
}

func collectInputText(cfg map[string]string) string {
	inputs := fieldsLikeDoxygen(cfg["INPUT"])
	var b strings.Builder
	for _, in := range inputs {
		info, err := os.Stat(in)
		if err != nil {
			continue
		}
		if info.IsDir() {
			filepath.WalkDir(in, func(path string, d os.DirEntry, err error) error {
				if err == nil && !d.IsDir() {
					appendFileSummary(&b, path)
				}
				return nil
			})
		} else {
			appendFileSummary(&b, in)
		}
	}
	if b.Len() == 0 {
		return "<p></p>"
	}
	return b.String()
}

func appendFileSummary(b *strings.Builder, path string) {
	data, err := os.ReadFile(path)
	if err != nil {
		return
	}
	b.WriteString("<h2>")
	b.WriteString(html.EscapeString(filepath.Base(path)))
	b.WriteString("</h2><pre>")
	text := string(data)
	if len(text) > 20000 {
		text = text[:20000]
	}
	b.WriteString(html.EscapeString(text))
	b.WriteString("</pre>\n")
}

func generateLatex(out, project string) error {
	dir := filepath.Join(out, "latex")
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	ref := fmt.Sprintf(`%% Generated by Doxygen %s
\section*{%s}
`, version, project)
	return os.WriteFile(filepath.Join(dir, "refman.tex"), []byte(ref), 0644)
}

func fieldsLikeDoxygen(s string) []string {
	s = strings.ReplaceAll(s, "\\\n", " ")
	return strings.Fields(s)
}

func cleanVal(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		s = s[1 : len(s)-1]
	}
	return s
}

func yes(s string) bool { return strings.EqualFold(cleanVal(s), "YES") }
func no(s string) bool  { return strings.EqualFold(cleanVal(s), "NO") }

func lastNonOption(args []string, def string) string {
	out := def
	for _, a := range args {
		if !strings.HasPrefix(a, "-") {
			out = a
		}
	}
	return out
}
