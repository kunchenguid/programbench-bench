module cleanroom-doxygen

go 1.21
