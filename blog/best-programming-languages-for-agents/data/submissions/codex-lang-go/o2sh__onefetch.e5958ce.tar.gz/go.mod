module onefetchclone

go 1.21
