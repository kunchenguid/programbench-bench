package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "onefetch 2.25.0"

var languagesList = []string{"ABNF", "ABAP", "Ada", "Agda", "Arduino C++", "Assembly", "ATS", "AutoHotKey", "BASH", "C", "CMake", "C#", "Ceylon", "Clojure", "CoffeeScript", "ColdFusion", "Coq", "C++", "Crystal", "CSS", "CUDA", "D", "Dart", "Dockerfile", "Emacs Lisp", "Elixir", "Elm", "Emojicode", "Erlang", "F#", "Fish", "Forth", "FORTRAN Legacy", "FORTRAN Modern", "GDScript", "GLSL", "Go", "GraphQL", "Groovy", "Haskell", "Haxe", "HCL", "HLSL", "HolyC", "HTML", "Idris", "Java", "JavaScript", "JSON", "Jsonnet", "JSX", "Julia", "Jupyter Notebooks", "Kotlin", "LLVM", "Lean", "Common Lisp", "Lua", "Makefile", "Markdown", "Modelica", "Nim", "Nix", "OCaml", "Objective-C", "Odin", "OpenSCAD", "Org", "Oz", "Pascal", "Perl", "PHP", "PowerShell", "Processing", "Prolog", "Protocol Buffers", "PureScript", "Python", "QML", "R", "Racket", "Raku", "Razor", "Ren'Py", "Ruby", "Rust", "Sass", "Scala", "Scheme", "Shell", "Solidity", "SQL", "Svelte", "SVG", "Swift", "SystemVerilog", "TCL", "TeX", "Plain Text", "TOML", "TSX", "TypeScript", "Typst", "Vala", "Verilog", "VHDL", "Vim Script", "Visual Basic", "Vue", "WebAssembly", "Wolfram", "XSL", "XAML", "XML", "YAML", "Zig", "Zsh"}

type Options struct {
	input           string
	output          string
	disabled        map[string]bool
	noTitle         bool
	numAuthors      int
	numLangs        int
	numChurn        int
	churnPool       int
	excludes        []string
	noBots          bool
	botRegex        string
	noMerges        bool
	email           bool
	httpURL         bool
	hideToken       bool
	includeHidden   bool
	types           map[string]bool
	isoTime         bool
	numberSeparator string
	noArt           bool
	noPalette       bool
	noBold          bool
}

type RepoData struct {
	Root        string      `json:"-"`
	Title       Title       `json:"title"`
	InfoFields  []InfoField `json:"infoFields"`
	TextEntries []TextEntry `json:"-"`
}

type Title struct {
	GitUsername string `json:"gitUsername"`
	GitVersion  string `json:"gitVersion"`
}

type InfoField struct {
	ProjectInfo      *ProjectInfo      `json:"ProjectInfo,omitempty"`
	DescriptionInfo  *DescriptionInfo  `json:"DescriptionInfo,omitempty"`
	HeadInfo         *HeadInfo         `json:"HeadInfo,omitempty"`
	PendingInfo      *PendingInfo      `json:"PendingInfo,omitempty"`
	VersionInfo      *VersionInfo      `json:"VersionInfo,omitempty"`
	CreatedInfo      *CreatedInfo      `json:"CreatedInfo,omitempty"`
	LanguagesInfo    *LanguagesInfo    `json:"LanguagesInfo,omitempty"`
	DependenciesInfo *DependenciesInfo `json:"DependenciesInfo,omitempty"`
	AuthorsInfo      *AuthorsInfo      `json:"AuthorsInfo,omitempty"`
	LastChangeInfo   *LastChangeInfo   `json:"LastChangeInfo,omitempty"`
	ContributorsInfo *ContributorsInfo `json:"ContributorsInfo,omitempty"`
	UrlInfo          *UrlInfo          `json:"UrlInfo,omitempty"`
	CommitsInfo      *CommitsInfo      `json:"CommitsInfo,omitempty"`
	ChurnInfo        *ChurnInfo        `json:"ChurnInfo,omitempty"`
	LocInfo          *LocInfo          `json:"LocInfo,omitempty"`
	SizeInfo         *SizeInfo         `json:"SizeInfo,omitempty"`
	LicenseInfo      *LicenseInfo      `json:"LicenseInfo,omitempty"`
}

type ProjectInfo struct {
	RepoName         string `json:"repoName"`
	NumberOfBranches int    `json:"numberOfBranches"`
	NumberOfTags     int    `json:"numberOfTags"`
}
type DescriptionInfo struct {
	Description *string `json:"description"`
}
type HeadInfo struct {
	HeadRefs HeadRefs `json:"headRefs"`
}
type HeadRefs struct {
	ShortCommitID string   `json:"shortCommitId"`
	Refs          []string `json:"refs"`
}
type PendingInfo struct {
	Added    int `json:"added"`
	Deleted  int `json:"deleted"`
	Modified int `json:"modified"`
}
type VersionInfo struct {
	Version string `json:"version"`
}
type CreatedInfo struct {
	CreationDate string `json:"creationDate"`
}
type LanguagesInfo struct {
	LanguagesWithPercentage []LangPct `json:"languagesWithPercentage"`
}
type LangPct struct {
	Language   string  `json:"language"`
	Percentage float64 `json:"percentage"`
}

func (l LangPct) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(`{"language":%q,"percentage":%.1f}`, l.Language, l.Percentage)), nil
}

type DependenciesInfo struct {
	Dependencies string `json:"dependencies"`
}
type AuthorsInfo struct {
	Authors []Author `json:"authors"`
}
type Author struct {
	Name         string  `json:"name"`
	Email        *string `json:"email"`
	NbrOfCommits int     `json:"nbrOfCommits"`
	Contribution int     `json:"contribution"`
}
type LastChangeInfo struct {
	LastChange string `json:"lastChange"`
}
type ContributorsInfo struct {
	TotalNumberOfAuthors int `json:"totalNumberOfAuthors"`
}
type UrlInfo struct {
	RepoURL string `json:"repoUrl"`
}
type CommitsInfo struct {
	NumberOfCommits int  `json:"numberOfCommits"`
	IsShallow       bool `json:"isShallow"`
}
type ChurnInfo struct {
	FileChurns    []FileChurn `json:"file_churns"`
	ChurnPoolSize int         `json:"churn_pool_size"`
}
type FileChurn struct {
	FilePath     string `json:"filePath"`
	NbrOfCommits int    `json:"nbrOfCommits"`
}
type LocInfo struct {
	LinesOfCode int `json:"linesOfCode"`
}
type SizeInfo struct {
	RepoSize  string `json:"repoSize"`
	FileCount int    `json:"fileCount"`
}
type LicenseInfo struct {
	License string `json:"license"`
}
type TextEntry struct {
	Label string
	Lines []string
}

func main() {
	opts, done, code := parseArgs(os.Args[1:])
	if done {
		os.Exit(code)
	}
	data := collect(opts)
	switch opts.output {
	case "json":
		b, _ := json.MarshalIndent(data, "", "  ")
		fmt.Println(string(b))
	case "yaml":
		printYAML(data)
	default:
		printText(data, opts)
	}
}

func parseArgs(args []string) (Options, bool, int) {
	o := Options{disabled: map[string]bool{}, numAuthors: 3, numLangs: 6, numChurn: 3, numberSeparator: "plain", types: map[string]bool{"programming": true, "markup": true}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() string {
			if i+1 >= len(args) {
				return ""
			}
			i++
			return args[i]
		}
		switch {
		case a == "-h" || a == "--help":
			printHelp()
			return o, true, 0
		case a == "-V" || a == "--version":
			fmt.Println(version)
			return o, true, 0
		case a == "-l" || a == "--languages":
			for _, l := range languagesList {
				fmt.Println(l)
			}
			return o, true, 0
		case a == "-p" || a == "--package-managers":
			fmt.Println("Npm\nCargo")
			return o, true, 0
		case a == "--generate":
			shell := next()
			printCompletion(shell)
			return o, true, 0
		case a == "-o" || a == "--output":
			o.output = next()
		case a == "-d" || a == "--disabled-fields":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				o.disabled[args[i]] = true
			}
		case a == "--no-title":
			o.noTitle = true
		case a == "--number-of-authors":
			o.numAuthors = atoiDefault(next(), 3)
		case a == "--number-of-languages":
			o.numLangs = atoiDefault(next(), 6)
		case a == "--number-of-file-churns":
			o.numChurn = atoiDefault(next(), 3)
		case a == "--churn-pool-size":
			o.churnPool = atoiDefault(next(), 0)
		case a == "-e" || a == "--exclude":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				o.excludes = append(o.excludes, args[i])
			}
		case strings.HasPrefix(a, "--no-bots="):
			o.noBots = true
			o.botRegex = strings.TrimPrefix(a, "--no-bots=")
		case a == "--no-bots":
			o.noBots = true
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				o.botRegex = next()
			}
		case a == "--no-merges":
			o.noMerges = true
		case a == "-E" || a == "--email":
			o.email = true
		case a == "--http-url":
			o.httpURL = true
		case a == "--hide-token":
			o.hideToken = true
		case a == "--include-hidden":
			o.includeHidden = true
		case a == "-T" || a == "--type":
			o.types = map[string]bool{}
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				o.types[args[i]] = true
			}
		case a == "-z" || a == "--iso-time":
			o.isoTime = true
		case a == "--number-separator":
			o.numberSeparator = next()
		case a == "--no-art":
			o.noArt = true
		case a == "--no-color-palette":
			o.noPalette = true
		case a == "--no-bold":
			o.noBold = true
		case a == "-t" || a == "--text-colors" || a == "-c" || a == "--ascii-colors":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
			}
		case a == "-a" || a == "--ascii-language" || a == "--ascii-input" || a == "-i" || a == "--image" || a == "--image-protocol" || a == "--color-resolution" || a == "--true-color":
			_ = next()
		case strings.HasPrefix(a, "-"):
			// Unknown documented visual flags are accepted as no-ops.
		default:
			o.input = a
		}
	}
	return o, false, 0
}

func collect(o Options) RepoData {
	start := o.input
	if start == "" {
		start = "."
	}
	root := strings.TrimSpace(gitAt(start, "rev-parse", "--show-toplevel"))
	if root == "" {
		root, _ = filepath.Abs(start)
	}
	d := RepoData{Root: root}
	d.Title = Title{GitUsername: strings.TrimSpace(gitAt(root, "config", "user.name")), GitVersion: strings.TrimSpace(run("git", "--version"))}
	repoName := repoName(root)
	project := ProjectInfo{RepoName: repoName, NumberOfBranches: branchCount(root), NumberOfTags: countLines(gitAt(root, "tag", "--list"))}
	desc := readDescription(root)
	head := HeadInfo{HeadRefs: HeadRefs{ShortCommitID: strings.TrimSpace(gitAt(root, "rev-parse", "--short=7", "HEAD")), Refs: headRefs(root)}}
	pending := pending(root)
	ver := VersionInfo{Version: findVersion(root)}
	created := CreatedInfo{CreationDate: formatTime(firstCommit(root), o.isoTime)}
	files := listFiles(root, o)
	langs, loc := languages(root, files, o)
	deps := DependenciesInfo{Dependencies: dependencies(root)}
	authors, totalAuthors := authors(root, o)
	last := LastChangeInfo{LastChange: formatTime(lastCommit(root), o.isoTime)}
	url := UrlInfo{RepoURL: formatURL(strings.TrimSpace(gitAt(root, "config", "--get", "remote.origin.url")), o)}
	commits := CommitsInfo{NumberOfCommits: atoiDefault(strings.TrimSpace(gitAt(root, append([]string{"rev-list", "--count"}, logFilters(o, "HEAD")...)...)), 0), IsShallow: strings.TrimSpace(gitAt(root, "rev-parse", "--is-shallow-repository")) == "true"}
	churn := churn(root, o)
	size := sizeInfo(root, files)
	lic := LicenseInfo{License: detectLicense(root)}
	add := func(name string, f InfoField, label string, lines ...string) {
		if !o.disabled[name] {
			d.InfoFields = append(d.InfoFields, f)
			if len(lines) > 0 {
				d.TextEntries = append(d.TextEntries, TextEntry{label, lines})
			}
		}
	}
	add("project", InfoField{ProjectInfo: &project}, "Project", project.RepoName)
	add("description", InfoField{DescriptionInfo: &DescriptionInfo{Description: desc}}, "Description", deref(desc))
	add("head", InfoField{HeadInfo: &head}, "HEAD", head.Short())
	add("pending", InfoField{PendingInfo: &pending}, "Pending", pending.String())
	add("version", InfoField{VersionInfo: &ver}, "Version", ver.Version)
	add("created", InfoField{CreatedInfo: &created}, "Created", created.CreationDate)
	if len(langs) > 0 {
		add("languages", InfoField{LanguagesInfo: &LanguagesInfo{LanguagesWithPercentage: langs}}, singular("Language", "Languages", len(langs)), langLines(langs)...)
	}
	add("dependencies", InfoField{DependenciesInfo: &deps}, "Dependencies", deps.Dependencies)
	add("authors", InfoField{AuthorsInfo: &AuthorsInfo{Authors: authors}}, singular("Author", "Authors", len(authors)), authorLines(authors, o.email)...)
	add("last-change", InfoField{LastChangeInfo: &last}, "Last change", last.LastChange)
	add("contributors", InfoField{ContributorsInfo: &ContributorsInfo{TotalNumberOfAuthors: totalAuthors}}, "Contributors", fmt.Sprint(totalAuthors))
	add("url", InfoField{UrlInfo: &url}, "URL", url.RepoURL)
	add("commits", InfoField{CommitsInfo: &commits}, "Commits", formatNum(commits.NumberOfCommits, o))
	if len(churn.FileChurns) > 0 {
		add("churn", InfoField{ChurnInfo: &churn}, fmt.Sprintf("Churn (%d)", churn.ChurnPoolSize), churnLines(churn)...)
	}
	if loc > 0 {
		add("lines-of-code", InfoField{LocInfo: &LocInfo{LinesOfCode: loc}}, "Lines of code", formatNum(loc, o))
	}
	add("size", InfoField{SizeInfo: &size}, "Size", fmt.Sprintf("%s (%d files)", size.RepoSize, size.FileCount))
	add("license", InfoField{LicenseInfo: &lic}, "License", lic.License)
	return d
}

func (h HeadInfo) Short() string {
	if len(h.HeadRefs.Refs) > 0 {
		return h.HeadRefs.ShortCommitID + " (" + strings.Join(h.HeadRefs.Refs, ", ") + ")"
	}
	return h.HeadRefs.ShortCommitID
}
func (p PendingInfo) String() string {
	var parts []string
	if p.Added > 0 {
		parts = append(parts, fmt.Sprintf("%d+", p.Added))
	}
	if p.Deleted > 0 {
		parts = append(parts, fmt.Sprintf("%d-", p.Deleted))
	}
	if p.Modified > 0 {
		parts = append(parts, fmt.Sprintf("%d~", p.Modified))
	}
	return strings.Join(parts, " ")
}

func gitAt(dir string, args ...string) string {
	all := append([]string{"-C", dir}, args...)
	return run("git", all...)
}
func run(name string, args ...string) string {
	cmd := exec.Command(name, args...)
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = io.Discard
	_ = cmd.Run()
	return out.String()
}
func atoiDefault(s string, def int) int {
	n, err := strconv.Atoi(strings.TrimSpace(s))
	if err != nil {
		return def
	}
	return n
}
func countLines(s string) int {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0
	}
	return len(strings.Split(s, "\n"))
}
func repoName(root string) string {
	top := strings.TrimSpace(gitAt(root, "rev-parse", "--show-superproject-working-tree"))
	if top != "" {
		return filepath.Base(root)
	}
	remote := strings.TrimSpace(gitAt(root, "config", "--get", "remote.origin.url"))
	if remote != "" {
		remote = strings.TrimSuffix(remote, ".git")
		remote = strings.TrimRight(remote, "/")
		if b := filepath.Base(remote); b != "." {
			return b
		}
	}
	return ""
}

func branchCount(root string) int {
	out := strings.TrimSpace(gitAt(root, "branch", "-r", "--format=%(refname:short)"))
	if out == "" {
		return 0
	}
	n := 0
	for _, l := range strings.Split(out, "\n") {
		l = strings.TrimSpace(l)
		if l != "" && !strings.HasSuffix(l, "/HEAD") {
			n++
		}
	}
	return n
}
func readDescription(root string) *string {
	p := filepath.Join(root, ".git", "description")
	b, err := os.ReadFile(p)
	if err != nil {
		return nil
	}
	s := strings.TrimSpace(string(b))
	if s == "" || strings.Contains(s, "Unnamed repository") {
		return nil
	}
	return &s
}
func headRefs(root string) []string {
	out := strings.TrimSpace(gitAt(root, "branch", "--points-at", "HEAD", "--format=%(refname:short)"))
	var refs []string
	for _, l := range strings.Split(out, "\n") {
		l = strings.TrimSpace(strings.TrimPrefix(l, "*"))
		if l != "" {
			refs = append(refs, l)
		}
	}
	if len(refs) == 0 {
		if b := strings.TrimSpace(gitAt(root, "rev-parse", "--abbrev-ref", "HEAD")); b != "" && b != "HEAD" {
			refs = append(refs, b)
		}
	}
	sort.Strings(refs)
	return refs
}
func pending(root string) PendingInfo {
	out := gitAt(root, "status", "--porcelain")
	var p PendingInfo
	for _, l := range strings.Split(out, "\n") {
		if len(l) < 2 {
			continue
		}
		x, y := l[0], l[1]
		if x == '?' {
			p.Added++
			continue
		}
		if x == 'A' || y == 'A' {
			p.Added++
		}
		if x == 'D' || y == 'D' {
			p.Deleted++
		}
		if x == 'M' || y == 'M' {
			p.Modified++
		}
	}
	return p
}
func findVersion(root string) string {
	for _, p := range []string{"package.json", "Cargo.toml", "go.mod"} {
		b, err := os.ReadFile(filepath.Join(root, p))
		if err != nil {
			continue
		}
		s := string(b)
		if p == "package.json" {
			re := regexp.MustCompile(`"version"\s*:\s*"([^"]+)"`)
			if m := re.FindStringSubmatch(s); len(m) > 1 {
				return m[1]
			}
		}
		if p == "Cargo.toml" {
			re := regexp.MustCompile(`(?m)^version\s*=\s*"([^"]+)"`)
			if m := re.FindStringSubmatch(s); len(m) > 1 {
				return m[1]
			}
		}
	}
	return ""
}
func firstCommit(root string) time.Time { return gitTime(root, "--reverse") }
func lastCommit(root string) time.Time  { return gitTime(root) }
func gitTime(root string, extra ...string) time.Time {
	args := []string{"log", "-1", "--format=%cI"}
	if len(extra) > 0 {
		args = append([]string{"log", extra[0], "-1", "--format=%cI"})
	}
	t, _ := time.Parse(time.RFC3339, strings.TrimSpace(gitAt(root, args...)))
	return t
}
func formatTime(t time.Time, iso bool) string {
	if t.IsZero() {
		return ""
	}
	if iso {
		return t.UTC().Format("2006-01-02T15:04:05Z")
	}
	now := time.Now().UTC()
	if t.After(now) {
		return "now"
	}
	days := int(now.Sub(t).Hours() / 24)
	switch {
	case days < 1:
		return "today"
	case days < 30:
		if days == 1 {
			return "a day ago"
		}
		return fmt.Sprintf("%d days ago", days)
	case days < 365:
		mo := days / 30
		if mo <= 1 {
			return "a month ago"
		}
		return fmt.Sprintf("%d months ago", mo)
	default:
		y := days / 365
		if y <= 1 {
			return "a year ago"
		}
		return fmt.Sprintf("%d years ago", y)
	}
}
func listFiles(root string, o Options) []string {
	out := gitAt(root, "ls-files")
	var files []string
	for _, f := range strings.Split(out, "\n") {
		f = strings.TrimSpace(f)
		if f == "" {
			continue
		}
		if !o.includeHidden && isHidden(f) {
			continue
		}
		if excluded(f, o.excludes) {
			continue
		}
		files = append(files, f)
	}
	return files
}
func isHidden(p string) bool {
	for _, part := range strings.Split(p, string(os.PathSeparator)) {
		if strings.HasPrefix(part, ".") {
			return true
		}
	}
	return false
}
func excluded(p string, pats []string) bool {
	for _, pat := range pats {
		if ok, _ := filepath.Match(pat, filepath.Base(p)); ok {
			return true
		}
		if ok, _ := filepath.Match(pat, p); ok {
			return true
		}
		if strings.Contains(p, pat) {
			return true
		}
	}
	return false
}

var extLang = map[string]struct{ lang, typ string }{
	".go": {"Go", "programming"}, ".rs": {"Rust", "programming"}, ".py": {"Python", "programming"}, ".js": {"JavaScript", "programming"}, ".ts": {"TypeScript", "programming"}, ".tsx": {"TSX", "programming"}, ".jsx": {"JSX", "programming"}, ".java": {"Java", "programming"}, ".c": {"C", "programming"}, ".h": {"C", "programming"}, ".cpp": {"C++", "programming"}, ".cc": {"C++", "programming"}, ".hpp": {"C++", "programming"}, ".cs": {"C#", "programming"}, ".rb": {"Ruby", "programming"}, ".php": {"PHP", "programming"}, ".swift": {"Swift", "programming"}, ".kt": {"Kotlin", "programming"}, ".scala": {"Scala", "programming"}, ".sh": {"Shell", "programming"}, ".bash": {"BASH", "programming"}, ".zsh": {"Zsh", "programming"}, ".fish": {"Fish", "programming"}, ".lua": {"Lua", "programming"}, ".vim": {"Vim Script", "programming"}, ".dart": {"Dart", "programming"}, ".ex": {"Elixir", "programming"}, ".erl": {"Erlang", "programming"}, ".hs": {"Haskell", "programming"}, ".jl": {"Julia", "programming"}, ".r": {"R", "programming"}, ".R": {"R", "programming"}, ".zig": {"Zig", "programming"}, ".sql": {"SQL", "programming"}, ".proto": {"Protocol Buffers", "programming"},
	".html": {"HTML", "markup"}, ".htm": {"HTML", "markup"}, ".css": {"CSS", "markup"}, ".scss": {"Sass", "markup"}, ".sass": {"Sass", "markup"}, ".vue": {"Vue", "markup"}, ".svelte": {"Svelte", "markup"}, ".xml": {"XML", "markup"}, ".xaml": {"XAML", "markup"}, ".svg": {"SVG", "markup"}, ".md": {"Markdown", "prose"}, ".markdown": {"Markdown", "prose"}, ".org": {"Org", "prose"}, ".tex": {"TeX", "markup"},
	".json": {"JSON", "data"}, ".yaml": {"YAML", "data"}, ".yml": {"YAML", "data"}, ".toml": {"TOML", "data"}, ".lock": {"TOML", "data"}, ".csv": {"Plain Text", "data"}, ".txt": {"Plain Text", "prose"},
}

func langFor(path string) (string, string, bool) {
	base := filepath.Base(path)
	switch base {
	case "Dockerfile":
		return "Dockerfile", "programming", true
	case "Makefile":
		return "Makefile", "programming", true
	case "CMakeLists.txt":
		return "CMake", "programming", true
	}
	v, ok := extLang[filepath.Ext(path)]
	return v.lang, v.typ, ok
}
func languages(root string, files []string, o Options) ([]LangPct, int) {
	counts := map[string]int{}
	totalBytes, loc := 0, 0
	for _, f := range files {
		lang, typ, ok := langFor(f)
		if !ok || !o.types[typ] {
			continue
		}
		b, err := os.ReadFile(filepath.Join(root, f))
		if err != nil {
			continue
		}
		counts[lang] += len(b)
		totalBytes += len(b)
		if typ == "programming" {
			loc += countLoc(b)
		}
	}
	var out []LangPct
	for l, n := range counts {
		p := 0.0
		if totalBytes > 0 {
			p = math.Round(float64(n)*1000/float64(totalBytes)) / 10
		}
		out = append(out, LangPct{l, p})
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Percentage == out[j].Percentage {
			return out[i].Language < out[j].Language
		}
		return out[i].Percentage > out[j].Percentage
	})
	if len(out) > o.numLangs {
		out = out[:o.numLangs]
	}
	return out, loc
}
func countLoc(b []byte) int {
	sc := bufio.NewScanner(bytes.NewReader(b))
	n := 0
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line != "" && !strings.HasPrefix(line, "//") && !strings.HasPrefix(line, "#") && !strings.HasPrefix(line, "/*") && !strings.HasPrefix(line, "*") {
			n++
		}
	}
	return n
}
func dependencies(root string) string {
	type pm struct {
		name string
		n    int
	}
	var ps []pm
	if b, err := os.ReadFile(filepath.Join(root, "package.json")); err == nil {
		n := 0
		for _, key := range []string{"dependencies", "devDependencies", "peerDependencies"} {
			n += countJSONMap(string(b), key)
		}
		if n > 0 {
			ps = append(ps, pm{"Npm", n})
		}
	}
	if b, err := os.ReadFile(filepath.Join(root, "Cargo.toml")); err == nil {
		n := countTomlDeps(string(b))
		if n > 0 {
			ps = append(ps, pm{"Cargo", n})
		}
	}
	if len(ps) == 0 {
		return ""
	}
	total := 0
	names := []string{}
	for _, p := range ps {
		total += p.n
		names = append(names, p.name)
	}
	return fmt.Sprintf("%d (%s)", total, strings.Join(names, ", "))
}
func countJSONMap(s, key string) int {
	re := regexp.MustCompile(`"` + regexp.QuoteMeta(key) + `"\s*:\s*\{([^}]*)\}`)
	m := re.FindStringSubmatch(s)
	if len(m) < 2 {
		return 0
	}
	return len(regexp.MustCompile(`"[^"]+"\s*:`).FindAllString(m[1], -1))
}
func countTomlDeps(s string) int {
	sc := bufio.NewScanner(strings.NewReader(s))
	in := false
	n := 0
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if strings.HasPrefix(line, "[") {
			in = line == "[dependencies]"
		}
		if in && strings.Contains(line, "=") && !strings.HasPrefix(line, "#") {
			n++
		}
	}
	return n
}
func authors(root string, o Options) ([]Author, int) {
	args := append([]string{"shortlog", "-sne"}, logFilters(o, "HEAD")...)
	out := gitAt(root, args...)
	type rec struct {
		name, email string
		n           int
	}
	var recs []rec
	total := 0
	botre := regexp.MustCompile(`(?i)(bot|\[bot\])`)
	if o.botRegex != "" {
		if r, err := regexp.Compile(o.botRegex); err == nil {
			botre = r
		}
	}
	for _, l := range strings.Split(out, "\n") {
		f := strings.Fields(strings.TrimSpace(l))
		if len(f) < 2 {
			continue
		}
		n := atoiDefault(f[0], 0)
		rest := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(l), f[0]))
		name, email := rest, ""
		if i := strings.LastIndex(rest, "<"); i >= 0 && strings.HasSuffix(rest, ">") {
			name = strings.TrimSpace(rest[:i])
			email = strings.TrimSuffix(rest[i+1:], ">")
		}
		if o.noBots && botre.MatchString(name+" "+email) {
			continue
		}
		recs = append(recs, rec{name, email, n})
		total += n
	}
	sort.SliceStable(recs, func(i, j int) bool {
		if recs[i].n == recs[j].n {
			return recs[i].name < recs[j].name
		}
		return recs[i].n > recs[j].n
	})
	totalAuthors := len(recs)
	if len(recs) > o.numAuthors {
		recs = recs[:o.numAuthors]
	}
	var outa []Author
	for _, r := range recs {
		var ep *string
		if o.email {
			e := r.email
			ep = &e
		}
		c := 0
		if total > 0 {
			c = int(math.Round(float64(r.n) * 100 / float64(total)))
		}
		outa = append(outa, Author{Name: r.name, Email: ep, NbrOfCommits: r.n, Contribution: c})
	}
	return outa, totalAuthors
}
func logFilters(o Options, rev string) []string {
	args := []string{}
	if o.noMerges {
		args = append(args, "--no-merges")
	}
	args = append(args, rev)
	return args
}
func formatURL(u string, o Options) string {
	if o.httpURL && strings.HasPrefix(u, "git@github.com:") {
		u = "https://github.com/" + strings.TrimPrefix(u, "git@github.com:")
	}
	if o.hideToken {
		re := regexp.MustCompile(`https://[^/@]+@`)
		u = re.ReplaceAllString(u, "https://")
	}
	return u
}
func churn(root string, o Options) ChurnInfo {
	pool := o.churnPool
	if pool <= 0 {
		pool = 1
	}
	out := gitAt(root, "log", fmt.Sprintf("-%d", pool), "--name-only", "--format=")
	counts := map[string]int{}
	actual := min(pool, atoiDefault(strings.TrimSpace(gitAt(root, "rev-list", "--count", "HEAD")), 0))
	for _, l := range strings.Split(out, "\n") {
		l = strings.TrimSpace(l)
		if l != "" {
			counts[l]++
		}
	}
	var arr []FileChurn
	for f, n := range counts {
		arr = append(arr, FileChurn{f, n})
	}
	sort.Slice(arr, func(i, j int) bool {
		if arr[i].NbrOfCommits == arr[j].NbrOfCommits {
			return arr[i].FilePath < arr[j].FilePath
		}
		return arr[i].NbrOfCommits > arr[j].NbrOfCommits
	})
	if len(arr) > o.numChurn {
		arr = arr[:o.numChurn]
	}
	return ChurnInfo{FileChurns: arr, ChurnPoolSize: actual}
}
func sizeInfo(root string, files []string) SizeInfo {
	var total int64
	for _, f := range files {
		if st, err := os.Stat(filepath.Join(root, f)); err == nil {
			total += st.Size()
		}
	}
	return SizeInfo{RepoSize: humanSize(total), FileCount: len(files)}
}
func humanSize(n int64) string {
	if n < 1024 {
		return fmt.Sprintf("%d B", n)
	}
	units := []string{"KiB", "MiB", "GiB"}
	v := float64(n)
	for _, u := range units {
		v /= 1024
		if v < 1024 {
			return fmt.Sprintf("%.2f %s", v, u)
		}
	}
	return fmt.Sprintf("%.2f TiB", v/1024)
}
func detectLicense(root string) string {
	for _, name := range []string{"LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"} {
		b, err := os.ReadFile(filepath.Join(root, name))
		if err != nil {
			continue
		}
		s := strings.ToLower(string(b))
		switch {
		case strings.Contains(s, "mit license"):
			return "MIT"
		case strings.Contains(s, "apache license"):
			return "Apache-2.0"
		case strings.Contains(s, "gnu general public license"):
			return "GPL"
		case strings.Contains(s, "bsd"):
			return "BSD"
		default:
			return ""
		}
	}
	return ""
}

func printYAML(d RepoData) {
	fmt.Println("title:")
	fmt.Printf("  gitUsername: %s\n", yamlStr(d.Title.GitUsername))
	fmt.Printf("  gitVersion: %s\n", yamlStr(d.Title.GitVersion))
	fmt.Println("infoFields:")
	for _, f := range d.InfoFields {
		yamlField(f)
	}
}
func yamlField(f InfoField) {
	b, _ := json.Marshal(f)
	var m map[string]any
	_ = json.Unmarshal(b, &m)
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Printf("- %s:\n", k)
		yamlValue(m[k], 4)
	}
}
func yamlValue(v any, indent int) {
	p := strings.Repeat(" ", indent)
	switch x := v.(type) {
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			fmt.Printf("%s%s:", p, k)
			scalarOrNL(x[k], indent+2)
		}
	case []any:
		for _, e := range x {
			fmt.Printf("%s- ", p)
			if m, ok := e.(map[string]any); ok {
				fmt.Println()
				yamlValue(m, indent+2)
			} else {
				fmt.Println(yamlAtom(e))
			}
		}
	default:
		fmt.Printf("%s%s\n", p, yamlAtom(x))
	}
}
func scalarOrNL(v any, indent int) {
	switch v.(type) {
	case map[string]any, []any:
		fmt.Println()
		yamlValue(v, indent)
	default:
		fmt.Printf(" %s\n", yamlAtom(v))
	}
}
func yamlAtom(v any) string {
	if v == nil {
		return "null"
	}
	switch x := v.(type) {
	case string:
		return yamlStr(x)
	case float64:
		if math.Trunc(x) == x {
			return fmt.Sprintf("%.0f", x)
		}
		return fmt.Sprintf("%.1f", x)
	default:
		return fmt.Sprint(x)
	}
}
func yamlStr(s string) string {
	if s == "" {
		return "''"
	}
	if strings.ContainsAny(s, ":#{}[],'\"") {
		return "'" + strings.ReplaceAll(s, "'", "''") + "'"
	}
	return s
}

func printText(d RepoData, o Options) {
	fmt.Print("\033[?7l")
	if !o.noTitle {
		if d.Title.GitUsername != "" {
			fmt.Printf("%s ~ %s\n", d.Title.GitUsername, d.Title.GitVersion)
		} else {
			fmt.Println(d.Title.GitVersion)
		}
		fmt.Println(strings.Repeat("-", max(10, len(d.Title.GitUsername)+len(d.Title.GitVersion)+3)))
	}
	for _, e := range d.TextEntries {
		if len(e.Lines) == 0 || strings.Join(e.Lines, "") == "" {
			continue
		}
		fmt.Printf("%s: %s\n", e.Label, e.Lines[0])
		for _, l := range e.Lines[1:] {
			fmt.Printf("%s%s\n", strings.Repeat(" ", len(e.Label)+2), l)
		}
	}
	fmt.Print("\033[?7h\n")
}
func langLines(l []LangPct) []string {
	out := []string{}
	for _, x := range l {
		out = append(out, fmt.Sprintf("%s (%.1f %%)", x.Language, x.Percentage))
	}
	return out
}
func authorLines(a []Author, email bool) []string {
	out := []string{}
	for _, x := range a {
		n := x.Name
		if email && x.Email != nil && *x.Email != "" {
			n += " <" + *x.Email + ">"
		}
		out = append(out, fmt.Sprintf("%d%% %s %d", x.Contribution, n, x.NbrOfCommits))
	}
	return out
}
func churnLines(c ChurnInfo) []string {
	out := []string{}
	for _, x := range c.FileChurns {
		out = append(out, fmt.Sprintf("%s %d", x.FilePath, x.NbrOfCommits))
	}
	return out
}
func singular(a, b string, n int) string {
	if n == 1 {
		return a
	}
	return b
}
func deref(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}
func formatNum(n int, o Options) string {
	s := strconv.Itoa(n)
	var sep string
	switch o.numberSeparator {
	case "comma":
		sep = ","
	case "space":
		sep = " "
	case "underscore":
		sep = "_"
	default:
		return s
	}
	var out []byte
	for i, c := range []byte(s) {
		if i > 0 && (len(s)-i)%3 == 0 {
			out = append(out, sep...)
		}
		out = append(out, c)
	}
	return string(out)
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func printHelp() {
	fmt.Println(`Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help                 Print help (see a summary with '-h')
  -V, --version              Print version
  -d, --disabled-fields <FIELD>...
      --no-title
      --number-of-authors <NUM>       [default: 3]
      --number-of-languages <NUM>     [default: 6]
      --number-of-file-churns <NUM>   [default: 3]
      --churn-pool-size <NUM>
  -e, --exclude <EXCLUDE>...
      --no-bots[=<REGEX>]
      --no-merges
  -E, --email
      --http-url
      --hide-token
      --include-hidden
  -T, --type <TYPE>...
  -z, --iso-time
      --number-separator <SEPARATOR>
      --no-bold
      --no-color-palette
      --no-art
  -o, --output <FORMAT>      [possible values: json, yaml]
  -l, --languages
  -p, --package-managers`)
}
func printCompletion(shell string) {
	if shell == "" {
		shell = "bash"
	}
	fmt.Printf("# completion for onefetch (%s)\n", shell)
	fmt.Println("complete -W \"--help --version --languages --package-managers --output --disabled-fields\" onefetch")
}

// Keep fs imported in builds that strip filepath.Walk experiments.
var _ fs.FileInfo
