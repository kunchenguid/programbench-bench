package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "nomino 1.6.4"

type options struct {
	dir       string
	depth     *int
	maxDepth  *int
	noExt     bool
	gen       string
	mkdir     bool
	mapPath   string
	quiet     bool
	regex     string
	sortOrder string
	test      bool
	overwrite bool
}

type row struct{ in, out string }

type intFlag struct {
	set bool
	val int
}

func (i *intFlag) String() string { return strconv.Itoa(i.val) }
func (i *intFlag) Set(s string) error {
	v, err := strconv.Atoi(s)
	if err != nil {
		return err
	}
	i.val = v
	i.set = true
	return nil
}

type parser struct {
	opts *options
	args []string
}

func (p *parser) parse(argv []string) error {
	var depth, maxDepth intFlag
	for idx := 0; idx < len(argv); idx++ {
		a := argv[idx]
		switch a {
		case "-h", "--help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println(version)
			os.Exit(0)
		case "-E", "--no-extension":
			p.opts.noExt = true
		case "-k", "--mkdir":
			p.opts.mkdir = true
		case "-q", "--quiet":
			p.opts.quiet = true
		case "-t", "--test", "--dry-run":
			p.opts.test = true
		case "-w", "--overwrite":
			p.opts.overwrite = true
		case "-d", "--dir":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '%s <PATH>' but none was supplied", a)
			}
			p.opts.dir = argv[idx]
		case "-g", "--generate":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '%s <PATH>' but none was supplied", a)
			}
			p.opts.gen = argv[idx]
		case "-m", "--map", "--from-file":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '%s <PATH>' but none was supplied", a)
			}
			p.opts.mapPath = argv[idx]
		case "-r", "--regex":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '%s <PATTERN>' but none was supplied", a)
			}
			p.opts.regex = argv[idx]
		case "-s", "--sort":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '%s <ORDER>' but none was supplied", a)
			}
			p.opts.sortOrder = argv[idx]
		case "--depth":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '--depth <DEPTH>' but none was supplied")
			}
			if err := depth.Set(argv[idx]); err != nil {
				return err
			}
		case "--max-depth":
			idx++
			if idx >= len(argv) {
				return fmt.Errorf("a value is required for '--max-depth <DEPTH>' but none was supplied")
			}
			if err := maxDepth.Set(argv[idx]); err != nil {
				return err
			}
		default:
			if strings.HasPrefix(a, "--dir=") {
				p.opts.dir = strings.TrimPrefix(a, "--dir=")
			} else if strings.HasPrefix(a, "--depth=") {
				if err := depth.Set(strings.TrimPrefix(a, "--depth=")); err != nil {
					return err
				}
			} else if strings.HasPrefix(a, "--max-depth=") {
				if err := maxDepth.Set(strings.TrimPrefix(a, "--max-depth=")); err != nil {
					return err
				}
			} else if strings.HasPrefix(a, "--generate=") {
				p.opts.gen = strings.TrimPrefix(a, "--generate=")
			} else if strings.HasPrefix(a, "--map=") {
				p.opts.mapPath = strings.TrimPrefix(a, "--map=")
			} else if strings.HasPrefix(a, "--from-file=") {
				p.opts.mapPath = strings.TrimPrefix(a, "--from-file=")
			} else if strings.HasPrefix(a, "--regex=") {
				p.opts.regex = strings.TrimPrefix(a, "--regex=")
			} else if strings.HasPrefix(a, "--sort=") {
				p.opts.sortOrder = strings.TrimPrefix(a, "--sort=")
			} else if strings.HasPrefix(a, "-") {
				return fmt.Errorf("unexpected argument '%s' found", a)
			} else {
				p.args = append(p.args, a)
			}
		}
	}
	if depth.set {
		v := depth.val
		p.opts.depth = &v
	}
	if maxDepth.set {
		v := maxDepth.val
		p.opts.maxDepth = &v
	}
	return nil
}

func main() {
	opts := &options{dir: "."}
	p := &parser{opts: opts}
	if err := p.parse(os.Args[1:]); err != nil {
		fail(err.Error())
	}
	if opts.sortOrder != "" && opts.sortOrder != "asc" && opts.sortOrder != "desc" {
		fail("invalid value '" + opts.sortOrder + "' for '--sort <ORDER>'")
	}
	if err := os.Chdir(opts.dir); err != nil {
		fail(err.Error())
	}
	rows, err := buildRows(opts, p.args)
	if err != nil {
		fail(err.Error())
	}
	if !opts.quiet {
		printTable(rows)
	}
	if opts.gen != "" {
		_ = writeGenerated(opts.gen, rows)
	}
	if !opts.test {
		perform(rows, opts)
	}
}

func fail(msg string) {
	fmt.Fprintln(os.Stderr, "error: "+msg)
	fmt.Fprintln(os.Stderr, "usage: run '"+os.Args[0]+" --help' for more information.")
	os.Exit(1)
}

func buildRows(o *options, args []string) ([]row, error) {
	if o.mapPath != "" {
		return rowsFromMap(o)
	}
	if o.sortOrder != "" {
		if len(args) < 1 {
			return nil, errors.New("the following required arguments were not provided:\n  <[SOURCE] OUTPUT>...")
		}
		return rowsSort(o, args[len(args)-1])
	}
	pat := o.regex
	out := ""
	if pat != "" {
		if len(args) < 1 {
			return nil, errors.New("the following required arguments were not provided:\n  <[SOURCE] OUTPUT>...")
		}
		out = args[len(args)-1]
	} else if len(args) >= 2 {
		pat = args[len(args)-2]
		out = args[len(args)-1]
	} else {
		return nil, errors.New("one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.")
	}
	return rowsRegex(o, pat, out)
}

func rowsFromMap(o *options) ([]row, error) {
	b, err := os.ReadFile(o.mapPath)
	if err != nil {
		return nil, err
	}
	m := map[string]string{}
	if err := json.Unmarshal(b, &m); err != nil {
		return nil, err
	}
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	rows := []row{}
	for _, k := range keys {
		rows = append(rows, row{k, avoidCollision(m[k], o)})
	}
	return rows, nil
}

func rowsSort(o *options, outpat string) ([]row, error) {
	names, err := listEntries(1)
	if err != nil {
		return nil, err
	}
	sort.SliceStable(names, func(i, j int) bool {
		c := naturalCompare(names[i], names[j])
		if o.sortOrder == "desc" {
			return c > 0
		}
		return c < 0
	})
	rows := []row{}
	for i, n := range names {
		out := formatSortPattern(outpat, n, i+1)
		out = preserveExt(n, out, o)
		rows = append(rows, row{n, avoidCollision(out, o)})
	}
	return rows, nil
}

func rowsRegex(o *options, pat, outpat string) ([]row, error) {
	re, err := regexp.Compile(pat)
	if err != nil {
		return nil, err
	}
	depth := 1
	if o.depth != nil {
		depth = *o.depth
	}
	if o.maxDepth != nil {
		depth = *o.maxDepth
	}
	names, err := listEntries(depth)
	if err != nil {
		return nil, err
	}
	rows := []row{}
	nmap := map[string]int{}
	for i, n := range re.SubexpNames() {
		if i > 0 && n != "" {
			nmap[n] = i
		}
	}
	for _, name := range names {
		ms := re.FindStringSubmatch(name)
		if ms == nil {
			continue
		}
		out := formatRegexPattern(outpat, ms, nmap)
		out = preserveExt(name, out, o)
		rows = append(rows, row{name, avoidCollision(out, o)})
	}
	return rows, nil
}

func listEntries(depth int) ([]string, error) {
	if depth <= 0 {
		return []string{""}, nil
	}
	var out []string
	err := filepath.WalkDir(".", func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if path == "." {
			return nil
		}
		rel := strings.TrimPrefix(filepath.ToSlash(path), "./")
		dep := strings.Count(rel, "/") + 1
		if dep > depth {
			if d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		out = append(out, rel)
		return nil
	})
	sort.Slice(out, func(i, j int) bool { return naturalCompare(out[i], out[j]) < 0 })
	return out, err
}

func preserveExt(in, out string, o *options) string {
	if o.noExt {
		return out
	}
	ext := filepath.Ext(in)
	if ext == "" {
		return out
	}
	return out + ext
}

func avoidCollision(out string, o *options) string {
	if o.overwrite {
		return out
	}
	cand := out
	for {
		if _, err := os.Lstat(cand); os.IsNotExist(err) {
			return cand
		}
		cand = filepath.Join(filepath.Dir(cand), "_"+filepath.Base(cand))
	}
}

var phRe = regexp.MustCompile(`\{([^{}]*)\}`)

func parsePlaceholder(tok string) (string, int) {
	inner := tok[1 : len(tok)-1]
	gspec := inner
	pad := 0
	if strings.Contains(inner, ":") {
		parts := strings.SplitN(inner, ":", 2)
		gspec = parts[0]
		if parts[1] != "" {
			pad, _ = strconv.Atoi(parts[1])
		}
	}
	return gspec, pad
}

func applyPad(val string, pad int) string {
	if pad > 0 && isPositiveInt(val) && len(val) < pad {
		return strings.Repeat("0", pad-len(val)) + val
	}
	return val
}

func formatSortPattern(pat, name string, idx int) string {
	return phRe.ReplaceAllStringFunc(pat, func(tok string) string {
		gspec, pad := parsePlaceholder(tok)
		val := ""
		if gspec == "" || gspec == "1" {
			val = strconv.Itoa(idx)
		} else if gspec == "0" {
			val = name
		}
		return applyPad(val, pad)
	})
}

func formatRegexPattern(pat string, groups []string, names map[string]int) string {
	next := 1
	return phRe.ReplaceAllStringFunc(pat, func(tok string) string {
		gspec, pad := parsePlaceholder(tok)
		val := ""
		if gspec == "" {
			if next >= 0 && next < len(groups) {
				val = groups[next]
			}
			next++
		} else if idx, err := strconv.Atoi(gspec); err == nil {
			if idx >= 0 && idx < len(groups) {
				val = groups[idx]
			}
		} else if names != nil {
			if idx, ok := names[gspec]; ok && idx < len(groups) {
				val = groups[idx]
			}
		}
		return applyPad(val, pad)
	})
}

func isPositiveInt(s string) bool {
	if s == "" {
		return false
	}
	for _, r := range s {
		if !unicode.IsDigit(r) {
			return false
		}
	}
	return true
}

func writeGenerated(path string, rows []row) error {
	m := map[string]string{}
	for _, r := range rows {
		m[r.out] = r.in
	}
	b, _ := json.MarshalIndent(m, "", "  ")
	return os.WriteFile(path, b, 0644)
}

func perform(rows []row, o *options) {
	for _, r := range rows {
		if o.mkdir {
			_ = os.MkdirAll(filepath.Dir(r.out), 0755)
		}
		if err := os.Rename(r.in, r.out); err != nil {
			fmt.Fprintf(os.Stderr, "[error] unable to rename '%s': %v\n", r.in, err)
		}
	}
}

func printTable(rows []row) {
	wi, wo := 5, 6
	for _, r := range rows {
		if len(r.in) > wi {
			wi = len(r.in)
		}
		if len(r.out) > wo {
			wo = len(r.out)
		}
	}
	border := "+" + strings.Repeat("-", wi+2) + "+" + strings.Repeat("-", wo+2) + "+"
	fmt.Println(border)
	fmt.Printf("| %-*s | %-*s |\n", wi, "Input", wo, "Output")
	fmt.Println(border)
	for _, r := range rows {
		fmt.Printf("| %-*s | %-*s |\n", wi, r.in, wo, r.out)
	}
	fmt.Println(border)
}

func naturalCompare(a, b string) int {
	ia, ib := 0, 0
	for ia < len(a) && ib < len(b) {
		ra, rb := rune(a[ia]), rune(b[ib])
		if unicode.IsDigit(ra) && unicode.IsDigit(rb) {
			sa, ea := scanNum(a, ia)
			sb, eb := scanNum(b, ib)
			ta := strings.TrimLeft(a[sa:ea], "0")
			tb := strings.TrimLeft(b[sb:eb], "0")
			if ta == "" {
				ta = "0"
			}
			if tb == "" {
				tb = "0"
			}
			if len(ta) != len(tb) {
				if len(ta) < len(tb) {
					return -1
				}
				return 1
			}
			if ta != tb {
				if ta < tb {
					return -1
				}
				return 1
			}
			if ea-sa != eb-sb {
				if ea-sa < eb-sb {
					return -1
				}
				return 1
			}
			ia, ib = ea, eb
			continue
		}
		la, lb := unicode.ToLower(ra), unicode.ToLower(rb)
		if la != lb {
			if la < lb {
				return -1
			}
			return 1
		}
		ia++
		ib++
	}
	if ia < len(a) {
		return 1
	}
	if ib < len(b) {
		return -1
	}
	return bytes.Compare([]byte(a), []byte(b))
}
func scanNum(s string, i int) (int, int) {
	j := i
	for j < len(s) && s[j] >= '0' && s[j] <= '9' {
		j++
	}
	return i, j
}

func printHelp() {
	fmt.Printf(`Batch rename utility for developers

Usage: %s [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...
          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>          Sets the working directory
      --depth <DEPTH>       Optional value to overwrite inferred subdirectory depth value in 'regex' mode
  -E, --no-extension        Does not preserve the extension of input files in 'sort' and 'regex' options
  -g, --generate <PATH>     Stores a JSON map file in '<PATH>' after renaming files
  -h, --help                Print help (see a summary with '-h')
  -k, --mkdir               Recursively creates all parent directories of '<OUTPUT>' if they are missing
  -m, --map <PATH>          Sets the path of map file to be used for renaming files
      --from-file <PATH>    Alias for --map
      --max-depth <DEPTH>   Optional value to set the maximum of subdirectory depth value in 'regex' mode
  -q, --quiet               Does not print the map table to stdout
  -r, --regex <PATTERN>     Regex pattern to match by filenames
  -s, --sort <ORDER>        Sets the order of natural sorting (by name) to rename files using enumerator
  -t, --test                Runs in test mode without renaming actual files
      --dry-run             Alias for --test
  -V, --version             Print version
  -w, --overwrite           Overwrites output files, otherwise, a '_' is prepended to filename
`, filepath.Base(os.Args[0]))
}

var _ = flag.ErrHelp
