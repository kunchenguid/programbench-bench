module sdclone

go 1.21
