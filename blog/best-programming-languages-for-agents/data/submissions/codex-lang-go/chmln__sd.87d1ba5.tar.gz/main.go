package main

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

type config struct {
	preview bool
	fixed   bool
	limit   int
	flags   string
	find    string
	repl    string
	files   []string
}

const longHelp = `sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>
          The regexp or string (if using ` + "`-F`" + `) to search for

  <REPLACE_WITH>
          What to replace each match with. Unless in string mode, you may use captured values like
          $1, $2, etc

  [FILES]...
          The path to file(s). This is optional - sd can also read from STDIN.
          
          Note: sd modifies files in-place by default. See documentation for examples.

Options:
  -p, --preview
          Display changes in a human reviewable format (the specifics of the format are likely to
          change in the future)

  -F, --fixed-strings
          Treat FIND and REPLACE_WITH args as literal strings

  -n, --max-replacements <LIMIT>
          Limit the number of replacements that can occur per file. 0 indicates unlimited
          replacements
          
          [default: 0]

  -f, --flags <FLAGS>
          Regex flags. May be combined (like ` + "`-f mc`" + `).
          
          c - case-sensitive
          
          e - disable multi-line matching
          
          i - case-insensitive
          
          m - multi-line matching
          
          s - make ` + "`.`" + ` match newlines
          
          w - match full words only

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`

const shortHelp = `sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>          The regexp or string (if using ` + "`-F`" + `) to search for
  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured
                  values like $1, $2, etc
  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN

Options:
  -p, --preview                   Display changes in a human reviewable format (the specifics of the
                                  format are likely to change in the future)
  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings
  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0
                                  indicates unlimited replacements [default: 0]
  -f, --flags <FLAGS>             Regex flags. May be combined (like ` + "`-f mc`" + `).
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
`

func main() {
	cfg, code := parse(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}

	var re *regexp.Regexp
	if !cfg.fixed {
		pat := cfg.find
		if strings.Contains(cfg.flags, "w") {
			pat = `\b(?:` + pat + `)\b`
		}
		prefix := ""
		multi := true
		dotall := false
		caseInsensitive := false
		for _, r := range cfg.flags {
			switch r {
			case 'i':
				caseInsensitive = true
			case 'c':
				caseInsensitive = false
			case 'm':
				multi = true
			case 'e':
				multi = false
			case 's':
				dotall = true
			case 'w':
			default:
				fmt.Fprintf(os.Stderr, "error: invalid value '%c' for '--flags <FLAGS>'\n", r)
				os.Exit(2)
			}
		}
		if caseInsensitive || multi || dotall {
			var opts strings.Builder
			if caseInsensitive {
				opts.WriteByte('i')
			}
			if multi {
				opts.WriteByte('m')
			}
			if dotall {
				opts.WriteByte('s')
			}
			prefix = "(?" + opts.String() + ")"
		}
		var err error
		re, err = regexp.Compile(prefix + pat)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: invalid regex %s\n", err.Error())
			os.Exit(1)
		}
	}

	if len(cfg.files) == 0 {
		in, err := io.ReadAll(os.Stdin)
		if err != nil {
			fmt.Fprintln(os.Stderr, "error:", err)
			os.Exit(1)
		}
		out := transform(string(in), cfg, re)
		fmt.Print(out)
		return
	}

	for _, name := range cfg.files {
		b, err := os.ReadFile(name)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %s: %v\n", name, err)
			os.Exit(1)
		}
		out := transform(string(b), cfg, re)
		if cfg.preview {
			if len(cfg.files) > 1 {
				fmt.Printf("----- FILE %s -----\n", name)
			}
			fmt.Print(out)
			continue
		}
		info, _ := os.Stat(name)
		mode := os.FileMode(0644)
		if info != nil {
			mode = info.Mode()
		}
		if err := os.WriteFile(name, []byte(out), mode); err != nil {
			fmt.Fprintf(os.Stderr, "error: %s: %v\n", name, err)
			os.Exit(1)
		}
	}
}

func parse(args []string) (config, int) {
	cfg := config{}
	pos := []string{}
	endFlags := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if !endFlags && a == "--" {
			endFlags = true
			continue
		}
		if !endFlags && strings.HasPrefix(a, "-") && a != "-" {
			switch a {
			case "-p", "--preview":
				cfg.preview = true
			case "-F", "--fixed-strings":
				cfg.fixed = true
			case "-h":
				fmt.Print(shortHelp)
				return cfg, 0
			case "--help":
				fmt.Print(longHelp)
				return cfg, 0
			case "-V", "--version":
				fmt.Println("sd 1.0.0")
				return cfg, 0
			case "-n", "--max-replacements":
				if i+1 >= len(args) {
					missingValue(a)
					return cfg, 2
				}
				i++
				n, err := strconv.Atoi(args[i])
				if err != nil || n < 0 {
					fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s <LIMIT>': invalid digit found in string\n", args[i], a)
					return cfg, 2
				}
				cfg.limit = n
			case "-f", "--flags":
				if i+1 >= len(args) {
					missingValue(a)
					return cfg, 2
				}
				i++
				cfg.flags += args[i]
			default:
				if strings.HasPrefix(a, "--max-replacements=") {
					v := strings.TrimPrefix(a, "--max-replacements=")
					n, err := strconv.Atoi(v)
					if err != nil || n < 0 {
						fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--max-replacements <LIMIT>': invalid digit found in string\n", v)
						return cfg, 2
					}
					cfg.limit = n
				} else if strings.HasPrefix(a, "--flags=") {
					cfg.flags += strings.TrimPrefix(a, "--flags=")
				} else {
					unexpected(a)
					return cfg, 2
				}
			}
		} else {
			pos = append(pos, a)
		}
	}
	if len(pos) < 2 {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:")
		if len(pos) == 0 {
			fmt.Fprintln(os.Stderr, "  <FIND>")
		}
		fmt.Fprintln(os.Stderr, "  <REPLACE_WITH>")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Usage: executable <FIND> <REPLACE_WITH> [FILES]...")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return cfg, 2
	}
	cfg.find = pos[0]
	cfg.repl = pos[1]
	cfg.files = pos[2:]
	return cfg, -1
}

func missingValue(flag string) {
	fmt.Fprintf(os.Stderr, "error: a value is required for '%s' but none was supplied\n", flag)
}

func unexpected(arg string) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n", arg)
	if strings.HasPrefix(arg, "-") {
		fmt.Fprintf(os.Stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg)
	}
	fmt.Fprintln(os.Stderr, "Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...")
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
}

func transform(s string, cfg config, re *regexp.Regexp) string {
	if cfg.fixed {
		if cfg.limit == 0 {
			return strings.ReplaceAll(s, cfg.find, cfg.repl)
		}
		return strings.Replace(s, cfg.find, cfg.repl, cfg.limit)
	}
	if cfg.limit == 0 {
		return replaceRegexp(s, re, cfg.repl, -1)
	}
	return replaceRegexp(s, re, cfg.repl, cfg.limit)
}

func replaceRegexp(src string, re *regexp.Regexp, repl string, max int) string {
	matches := re.FindAllStringSubmatchIndex(src, max)
	if len(matches) == 0 {
		return src
	}
	names := re.SubexpNames()
	var buf bytes.Buffer
	last := 0
	for _, m := range matches {
		buf.WriteString(src[last:m[0]])
		buf.Write(expand(src, repl, m, names))
		last = m[1]
	}
	buf.WriteString(src[last:])
	return buf.String()
}

func expand(src, repl string, match []int, names []string) []byte {
	var out []byte
	for i := 0; i < len(repl); i++ {
		if repl[i] != '$' {
			out = append(out, repl[i])
			continue
		}
		if i+1 >= len(repl) {
			continue
		}
		if repl[i+1] == '$' {
			out = append(out, '$')
			i++
			continue
		}
		if repl[i+1] == '{' {
			j := i + 2
			for j < len(repl) && repl[j] != '}' {
				j++
			}
			if j < len(repl) {
				out = appendGroup(out, src, match, names, repl[i+2:j])
				i = j
				continue
			}
		}
		j := i + 1
		if j < len(repl) && repl[j] >= '0' && repl[j] <= '9' {
			for j < len(repl) && repl[j] >= '0' && repl[j] <= '9' {
				j++
			}
			out = appendGroup(out, src, match, names, repl[i+1:j])
			i = j - 1
			continue
		}
		if isNameStart(repl[j]) {
			for j < len(repl) && isNameChar(repl[j]) {
				j++
			}
			out = appendGroup(out, src, match, names, repl[i+1:j])
			i = j - 1
			continue
		}
	}
	return out
}

func appendGroup(out []byte, src string, match []int, names []string, key string) []byte {
	idx := -1
	if n, err := strconv.Atoi(key); err == nil {
		idx = n
	} else {
		for i, name := range names {
			if name == key {
				idx = i
				break
			}
		}
	}
	if idx >= 0 && 2*idx+1 < len(match) && match[2*idx] >= 0 {
		out = append(out, src[match[2*idx]:match[2*idx+1]]...)
	}
	return out
}

func isNameStart(b byte) bool {
	return (b >= 'A' && b <= 'Z') || (b >= 'a' && b <= 'z') || b == '_'
}

func isNameChar(b byte) bool {
	return isNameStart(b) || (b >= '0' && b <= '9')
}

func init() {
	_ = filepath.Separator
}
