module yj-reimpl

go 1.21.0

require (
	github.com/pelletier/go-toml/v2 v2.2.4
	gopkg.in/yaml.v3 v3.0.1
)
