package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"

	toml "github.com/pelletier/go-toml/v2"
	"gopkg.in/yaml.v3"
)

type Pair struct {
	Key string
	Val *Node
}

type Node struct {
	Kind  string
	Pairs []Pair
	List  []*Node
	Val   any
}

func main() {
	inFmt, outFmt, indent, escapeHTML, keyParse, err := parseFlags(os.Args[1:])
	if err != nil {
		usage(os.Stdout)
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if inFmt == "help" {
		usage(os.Stdout)
		return
	}
	if inFmt == "version" {
		fmt.Println("v0.0.0")
		return
	}
	b, _ := io.ReadAll(os.Stdin)
	if strings.TrimSpace(string(b)) == "" && inFmt != "j" {
		return
	}
	n, err := parseInput(inFmt, b)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	out, err := emit(outFmt, n, indent, escapeHTML, keyParse)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	os.Stdout.Write(out)
}

func usage(w io.Writer) {
	fmt.Fprintf(w, `Usage: %s [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version

`, os.Args[0])
}

func parseFlags(args []string) (string, string, bool, bool, bool, error) {
	flags := ""
	for _, a := range args {
		flags += strings.TrimLeft(a, "-")
	}
	valid := "ytjcrneikhv"
	var bad []string
	for _, r := range flags {
		if !strings.ContainsRune(valid, r) {
			bad = append(bad, string(r))
		}
	}
	if len(bad) > 0 {
		return "", "", false, false, false, fmt.Errorf("Error: invalid flags specified: %s", strings.Join(bad, " "))
	}
	if strings.Contains(flags, "h") {
		return "help", "", false, false, false, nil
	}
	if strings.Contains(flags, "v") {
		return "version", "", false, false, false, nil
	}
	indent := strings.Contains(flags, "i")
	esc := strings.Contains(flags, "e")
	keyParse := strings.Contains(flags, "k")
	letters := []rune{}
	for _, r := range flags {
		if strings.ContainsRune("ytjrc", r) {
			letters = append(letters, r)
		}
	}
	in, out := "y", "j"
	if len(letters) == 1 {
		switch letters[0] {
		case 'y':
			in, out = "y", "j"
		case 't':
			in, out = "t", "j"
		case 'j':
			in, out = "j", "j"
		case 'r':
			in, out = "j", "y"
		case 'c':
			in, out = "c", "j"
		}
	} else if len(letters) >= 2 {
		in, out = string(letters[0]), string(letters[1])
	}
	if indent && out != "j" && out != "t" {
		return "", "", false, false, false, errors.New("Error: flag -i only valid for JSON or TOML output")
	}
	if keyParse && out != "y" {
		return "", "", false, false, false, errors.New("Error: flag -k only valid for YAML output")
	}
	return in, out, indent, esc, keyParse, nil
}

func parseInput(f string, b []byte) (*Node, error) {
	switch f {
	case "j":
		n, err := parseJSON(b)
		if err != nil {
			return nil, fmt.Errorf("Error parsing JSON: %v", err)
		}
		return n, nil
	case "y":
		n, err := parseYAML(b)
		if err != nil {
			return nil, fmt.Errorf("Error parsing YAML: %v", err)
		}
		return n, nil
	case "t":
		n, err := parseTOML(b)
		if err != nil {
			return nil, fmt.Errorf("Error parsing TOML: %v", err)
		}
		return n, nil
	case "c":
		n, err := parseHCL(string(b))
		if err != nil {
			return nil, fmt.Errorf("Error parsing HCL: %v", err)
		}
		return n, nil
	}
	return &Node{Kind: "map"}, nil
}

func emit(f string, n *Node, indent, esc, keyParse bool) ([]byte, error) {
	switch f {
	case "j":
		var buf bytes.Buffer
		w := orderedJSON(n, "", indent, esc)
		buf.WriteString(w)
		if indent {
			buf.WriteByte('\n')
		}
		return buf.Bytes(), nil
	case "y":
		return []byte(emitYAML(n, 0, keyParse)), nil
	case "t":
		return []byte(emitTOML(n, indent)), nil
	case "c":
		return []byte(emitHCL(n, 0, true)), nil
	}
	return nil, nil
}

func parseJSON(b []byte) (*Node, error) {
	dec := json.NewDecoder(bytes.NewReader(b))
	dec.UseNumber()
	return readJSONValue(dec)
}

func readJSONValue(dec *json.Decoder) (*Node, error) {
	t, err := dec.Token()
	if err != nil {
		return nil, err
	}
	switch v := t.(type) {
	case json.Delim:
		if v == '{' {
			n := &Node{Kind: "map"}
			for dec.More() {
				kt, err := dec.Token()
				if err != nil {
					return nil, err
				}
				child, err := readJSONValue(dec)
				if err != nil {
					return nil, err
				}
				n.Pairs = append(n.Pairs, Pair{fmt.Sprint(kt), child})
			}
			_, err = dec.Token()
			return n, err
		}
		if v == '[' {
			n := &Node{Kind: "seq"}
			for dec.More() {
				child, err := readJSONValue(dec)
				if err != nil {
					return nil, err
				}
				n.List = append(n.List, child)
			}
			_, err = dec.Token()
			return n, err
		}
	case string:
		return &Node{Kind: "scalar", Val: v}, nil
	case bool:
		return &Node{Kind: "scalar", Val: v}, nil
	case nil:
		return &Node{Kind: "scalar", Val: nil}, nil
	case json.Number:
		if strings.ContainsAny(v.String(), ".eE") {
			f, _ := v.Float64()
			return &Node{Kind: "scalar", Val: f}, nil
		}
		i, err := v.Int64()
		if err == nil {
			return &Node{Kind: "scalar", Val: i}, nil
		}
		f, _ := v.Float64()
		return &Node{Kind: "scalar", Val: f}, nil
	}
	return nil, errors.New("invalid JSON")
}

func parseYAML(b []byte) (*Node, error) {
	var yn yaml.Node
	if err := yaml.Unmarshal(b, &yn); err != nil {
		return nil, err
	}
	if len(yn.Content) == 0 {
		return &Node{Kind: "scalar", Val: nil}, nil
	}
	return fromYAML(yn.Content[0]), nil
}

func fromYAML(y *yaml.Node) *Node {
	switch y.Kind {
	case yaml.MappingNode:
		n := &Node{Kind: "map"}
		for i := 0; i+1 < len(y.Content); i += 2 {
			n.Pairs = append(n.Pairs, Pair{y.Content[i].Value, fromYAML(y.Content[i+1])})
		}
		return n
	case yaml.SequenceNode:
		n := &Node{Kind: "seq"}
		for _, c := range y.Content {
			n.List = append(n.List, fromYAML(c))
		}
		return n
	case yaml.ScalarNode:
		switch y.Tag {
		case "!!null":
			return &Node{Kind: "scalar", Val: nil}
		case "!!bool":
			return &Node{Kind: "scalar", Val: y.Value == "true" || y.Value == "True" || y.Value == "TRUE"}
		case "!!int":
			i, err := strconv.ParseInt(strings.ReplaceAll(y.Value, "_", ""), 0, 64)
			if err == nil {
				return &Node{Kind: "scalar", Val: i}
			}
		case "!!float":
			switch strings.ToLower(y.Value) {
			case ".inf", "+.inf", "+inf", "inf":
				return &Node{Kind: "scalar", Val: "inf"}
			case "-.inf", "-inf":
				return &Node{Kind: "scalar", Val: "-inf"}
			case ".nan", "nan":
				return &Node{Kind: "scalar", Val: "NaN"}
			}
			f, err := strconv.ParseFloat(strings.ReplaceAll(y.Value, "_", ""), 64)
			if err == nil {
				return &Node{Kind: "scalar", Val: f}
			}
		}
		return &Node{Kind: "scalar", Val: y.Value}
	}
	return &Node{Kind: "scalar", Val: nil}
}

func parseTOML(b []byte) (*Node, error) {
	if n, ok, err := parseSimpleTOML(string(b)); ok || err != nil {
		return n, err
	}
	var v map[string]any
	if err := toml.Unmarshal(b, &v); err != nil {
		return nil, err
	}
	return fromAny(v), nil
}

func parseSimpleTOML(s string) (*Node, bool, error) {
	root := &Node{Kind: "map"}
	current := root
	lines := strings.Split(s, "\n")
	for _, line := range lines {
		if i := strings.Index(line, "#"); i >= 0 {
			line = line[:i]
		}
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			name := strings.TrimSpace(line[1 : len(line)-1])
			if name == "" || strings.Contains(name, "[") {
				return nil, false, nil
			}
			current = ensureTable(root, strings.Split(name, "."))
			continue
		}
		eq := strings.Index(line, "=")
		if eq < 0 {
			return nil, false, nil
		}
		key := strings.TrimSpace(line[:eq])
		val := strings.TrimSpace(line[eq+1:])
		key = strings.Trim(key, `"`)
		v, ok := parseTomlScalarOrArray(val)
		if !ok {
			return nil, false, nil
		}
		setPair(current, key, v)
	}
	return root, true, nil
}

func ensureTable(root *Node, parts []string) *Node {
	cur := root
	for _, part := range parts {
		part = strings.Trim(strings.TrimSpace(part), `"`)
		var child *Node
		for _, p := range cur.Pairs {
			if p.Key == part && p.Val.Kind == "map" {
				child = p.Val
				break
			}
		}
		if child == nil {
			child = &Node{Kind: "map"}
			cur.Pairs = append(cur.Pairs, Pair{part, child})
		}
		cur = child
	}
	return cur
}

func setPair(n *Node, key string, val *Node) {
	for i := range n.Pairs {
		if n.Pairs[i].Key == key {
			n.Pairs[i].Val = val
			return
		}
	}
	n.Pairs = append(n.Pairs, Pair{key, val})
}

func parseTomlScalarOrArray(s string) (*Node, bool) {
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		inner := strings.TrimSpace(s[1 : len(s)-1])
		n := &Node{Kind: "seq"}
		if inner == "" {
			return n, true
		}
		for _, part := range splitCSV(inner) {
			v, ok := parseTomlScalarOrArray(strings.TrimSpace(part))
			if !ok {
				return nil, false
			}
			n.List = append(n.List, v)
		}
		return n, true
	}
	if strings.HasPrefix(s, "{") && strings.HasSuffix(s, "}") {
		inner := strings.TrimSpace(s[1 : len(s)-1])
		n := &Node{Kind: "map"}
		if inner == "" {
			return n, true
		}
		for _, part := range splitCSV(inner) {
			eq := strings.Index(part, "=")
			if eq < 0 {
				return nil, false
			}
			k := strings.Trim(strings.TrimSpace(part[:eq]), `"`)
			v, ok := parseTomlScalarOrArray(strings.TrimSpace(part[eq+1:]))
			if !ok {
				return nil, false
			}
			n.Pairs = append(n.Pairs, Pair{k, v})
		}
		return n, true
	}
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		u, err := strconv.Unquote(s)
		if err != nil {
			return nil, false
		}
		return &Node{Kind: "scalar", Val: u}, true
	}
	if s == "true" || s == "false" {
		return &Node{Kind: "scalar", Val: s == "true"}, true
	}
	if i, err := strconv.ParseInt(s, 10, 64); err == nil {
		return &Node{Kind: "scalar", Val: i}, true
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil {
		return &Node{Kind: "scalar", Val: f}, true
	}
	return nil, false
}

func splitCSV(s string) []string {
	var out []string
	start, depth := 0, 0
	inStr, esc := false, false
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inStr {
			if esc {
				esc = false
			} else if c == '\\' {
				esc = true
			} else if c == '"' {
				inStr = false
			}
			continue
		}
		switch c {
		case '"':
			inStr = true
		case '[', '{':
			depth++
		case ']', '}':
			depth--
		case ',':
			if depth == 0 {
				out = append(out, s[start:i])
				start = i + 1
			}
		}
	}
	out = append(out, s[start:])
	return out
}

func fromAny(v any) *Node {
	switch x := v.(type) {
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		n := &Node{Kind: "map"}
		for _, k := range keys {
			n.Pairs = append(n.Pairs, Pair{k, fromAny(x[k])})
		}
		return n
	case []any:
		n := &Node{Kind: "seq"}
		for _, e := range x {
			n.List = append(n.List, fromAny(e))
		}
		return n
	case int64, int, float64, bool, string, nil:
		return &Node{Kind: "scalar", Val: x}
	default:
		return &Node{Kind: "scalar", Val: fmt.Sprint(x)}
	}
}

func orderedJSON(n *Node, prefix string, pretty, esc bool) string {
	ind := func(level int) string {
		if pretty {
			return strings.Repeat("  ", level)
		}
		return ""
	}
	var rec func(*Node, int) string
	rec = func(n *Node, level int) string {
		switch n.Kind {
		case "map":
			if len(n.Pairs) == 0 {
				return "{}"
			}
			var parts []string
			for _, p := range n.Pairs {
				s := quoteJSON(p.Key, esc)
				if pretty {
					s = ind(level+1) + s + ": " + rec(p.Val, level+1)
				} else {
					s += ":" + rec(p.Val, level+1)
				}
				parts = append(parts, s)
			}
			if pretty {
				return "{\n" + strings.Join(parts, ",\n") + "\n" + ind(level) + "}"
			}
			return "{" + strings.Join(parts, ",") + "}"
		case "seq":
			if len(n.List) == 0 {
				return "[]"
			}
			var parts []string
			for _, e := range n.List {
				if pretty {
					parts = append(parts, ind(level+1)+rec(e, level+1))
				} else {
					parts = append(parts, rec(e, level+1))
				}
			}
			if pretty {
				return "[\n" + strings.Join(parts, ",\n") + "\n" + ind(level) + "]"
			}
			return "[" + strings.Join(parts, ",") + "]"
		default:
			return scalarJSON(n.Val, esc)
		}
	}
	return rec(n, 0)
}

func quoteJSON(s string, esc bool) string {
	if esc {
		b, _ := json.Marshal(s)
		return string(b)
	}
	var buf bytes.Buffer
	enc := json.NewEncoder(&buf)
	enc.SetEscapeHTML(false)
	enc.Encode(s)
	return strings.TrimSpace(buf.String())
}

func scalarJSON(v any, esc bool) string {
	switch x := v.(type) {
	case nil:
		return "null"
	case string:
		return quoteJSON(x, esc)
	case bool:
		if x {
			return "true"
		}
		return "false"
	case int:
		return strconv.Itoa(x)
	case int64:
		return strconv.FormatInt(x, 10)
	case float64:
		if math.IsInf(x, 1) {
			return quoteJSON("inf", esc)
		}
		if math.IsInf(x, -1) {
			return quoteJSON("-inf", esc)
		}
		if math.IsNaN(x) {
			return quoteJSON("NaN", esc)
		}
		return strconv.FormatFloat(x, 'f', -1, 64)
	default:
		return quoteJSON(fmt.Sprint(v), esc)
	}
}

func emitYAML(n *Node, level int, keyParse bool) string {
	var b strings.Builder
	writeYAML(&b, n, level, keyParse)
	return b.String()
}

func writeYAML(b *strings.Builder, n *Node, level int, keyParse bool) {
	pad := strings.Repeat("  ", level)
	switch n.Kind {
	case "map":
		for _, p := range n.Pairs {
			k := yamlKey(p.Key, keyParse)
			if p.Val.Kind == "scalar" {
				fmt.Fprintf(b, "%s%s: %s\n", pad, k, yamlScalar(p.Val.Val))
			} else {
				fmt.Fprintf(b, "%s%s:\n", pad, k)
				writeYAML(b, p.Val, level+1, keyParse)
			}
		}
	case "seq":
		for _, e := range n.List {
			if e.Kind == "scalar" {
				fmt.Fprintf(b, "%s- %s\n", pad, yamlScalar(e.Val))
			} else {
				fmt.Fprintf(b, "%s-\n", pad)
				writeYAML(b, e, level+1, keyParse)
			}
		}
	default:
		fmt.Fprintf(b, "%s\n", yamlScalar(n.Val))
	}
}

func yamlKey(k string, parse bool) string {
	if !parse {
		return k
	}
	return k
}

func yamlScalar(v any) string {
	switch x := v.(type) {
	case nil:
		return "null"
	case bool:
		if x {
			return "true"
		}
		return "false"
	case int:
		return strconv.Itoa(x)
	case int64:
		return strconv.FormatInt(x, 10)
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case string:
		if x == "" {
			return "\"\""
		}
		if needsYAMLQuote(x) {
			q, _ := yaml.Marshal(x)
			return strings.TrimSpace(string(q))
		}
		return x
	default:
		return fmt.Sprint(x)
	}
}

func needsYAMLQuote(s string) bool {
	l := strings.ToLower(s)
	if strings.ContainsAny(s, ":\n#{}[],&*?|-<>=!%@`\"'") || strings.HasPrefix(s, " ") || strings.HasSuffix(s, " ") {
		return true
	}
	switch l {
	case "true", "false", "null", "~", "yes", "no", "on", "off", "nan", ".nan", "inf", ".inf", "-inf", "-.inf":
		return true
	}
	if _, err := strconv.ParseFloat(s, 64); err == nil {
		return true
	}
	return false
}

func emitTOML(n *Node, indent bool) string {
	if n.Kind != "map" {
		return ""
	}
	var b strings.Builder
	writeTOMLMap(&b, n, "")
	return b.String()
}

func writeTOMLMap(b *strings.Builder, n *Node, prefix string) {
	firstTable := true
	for _, p := range n.Pairs {
		if p.Val.Kind == "map" {
			continue
		}
		fmt.Fprintf(b, "%s = %s\n", tomlKey(p.Key), tomlValue(p.Val))
	}
	for _, p := range n.Pairs {
		if p.Val.Kind != "map" {
			continue
		}
		name := p.Key
		if prefix != "" {
			name = prefix + "." + p.Key
		}
		if firstTable {
			b.WriteByte('\n')
			firstTable = false
		} else {
			b.WriteByte('\n')
		}
		fmt.Fprintf(b, "[%s]\n", name)
		writeTOMLMap(b, p.Val, name)
	}
}

func tomlKey(s string) string {
	if s == "" {
		return strconv.Quote(s)
	}
	for _, r := range s {
		if !(r == '_' || r == '-' || r >= 'A' && r <= 'Z' || r >= 'a' && r <= 'z' || r >= '0' && r <= '9') {
			return strconv.Quote(s)
		}
	}
	return s
}

func tomlValue(n *Node) string {
	switch n.Kind {
	case "seq":
		parts := make([]string, len(n.List))
		for i, e := range n.List {
			parts[i] = tomlValue(e)
		}
		return "[" + strings.Join(parts, ", ") + "]"
	case "map":
		parts := make([]string, len(n.Pairs))
		for i, p := range n.Pairs {
			parts[i] = tomlKey(p.Key) + " = " + tomlValue(p.Val)
		}
		return "{ " + strings.Join(parts, ", ") + " }"
	default:
		switch x := n.Val.(type) {
		case nil:
			return `""`
		case string:
			return strconv.Quote(x)
		case bool:
			return strconv.FormatBool(x)
		case int64:
			return strconv.FormatInt(x, 10)
		case int:
			return strconv.Itoa(x)
		case float64:
			return strconv.FormatFloat(x, 'f', -1, 64)
		default:
			return strconv.Quote(fmt.Sprint(x))
		}
	}
}

func emitHCL(n *Node, level int, top bool) string {
	var b strings.Builder
	if n.Kind == "map" {
		for i, p := range n.Pairs {
			if i > 0 && top {
				b.WriteString("\n\n")
			}
			fmt.Fprintf(&b, "%s%s = %s", strings.Repeat("  ", level), strconv.Quote(p.Key), hclValue(p.Val, level))
		}
		if top && len(n.Pairs) > 0 {
			// original generally omits the final newline for HCL.
		}
		return b.String()
	}
	return hclValue(n, level)
}

func hclValue(n *Node, level int) string {
	switch n.Kind {
	case "map":
		var b strings.Builder
		b.WriteString("{\n")
		for i, p := range n.Pairs {
			if i > 0 {
				b.WriteByte('\n')
			}
			fmt.Fprintf(&b, "%s%s = %s", strings.Repeat("  ", level+1), strconv.Quote(p.Key), hclValue(p.Val, level+1))
		}
		b.WriteString("\n" + strings.Repeat("  ", level) + "}")
		return b.String()
	case "seq":
		parts := make([]string, len(n.List))
		for i, e := range n.List {
			parts[i] = hclValue(e, level)
		}
		return "[" + strings.Join(parts, ", ") + "]"
	default:
		switch x := n.Val.(type) {
		case nil:
			return "null"
		case string:
			return strconv.Quote(x)
		case bool:
			return strconv.FormatBool(x)
		case int64:
			return strconv.FormatInt(x, 10)
		case int:
			return strconv.Itoa(x)
		case float64:
			return strconv.FormatFloat(x, 'f', -1, 64)
		default:
			return strconv.Quote(fmt.Sprint(x))
		}
	}
}

type hclParser struct {
	s string
	i int
}

func parseHCL(s string) (*Node, error) {
	p := &hclParser{s: s}
	n := &Node{Kind: "map"}
	for {
		p.ws()
		if p.eof() {
			return n, nil
		}
		k, err := p.key()
		if err != nil {
			return nil, err
		}
		p.ws()
		if !p.eat('=') {
			return nil, errors.New("expected =")
		}
		p.ws()
		v, err := p.value()
		if err != nil {
			return nil, err
		}
		n.Pairs = append(n.Pairs, Pair{k, v})
		p.ws()
	}
}

func (p *hclParser) eof() bool { return p.i >= len(p.s) }
func (p *hclParser) ws() {
	for !p.eof() {
		c := p.s[p.i]
		if c == '#' {
			for !p.eof() && p.s[p.i] != '\n' {
				p.i++
			}
		} else if c == '/' && p.i+1 < len(p.s) && p.s[p.i+1] == '/' {
			for !p.eof() && p.s[p.i] != '\n' {
				p.i++
			}
		} else if c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == ',' {
			p.i++
		} else {
			return
		}
	}
}
func (p *hclParser) eat(c byte) bool {
	if !p.eof() && p.s[p.i] == c {
		p.i++
		return true
	}
	return false
}
func (p *hclParser) key() (string, error) {
	if p.eof() {
		return "", io.EOF
	}
	if p.s[p.i] == '"' {
		return p.str()
	}
	start := p.i
	for !p.eof() {
		c := p.s[p.i]
		if c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '=' {
			break
		}
		p.i++
	}
	return p.s[start:p.i], nil
}
func (p *hclParser) str() (string, error) {
	start := p.i
	p.i++
	esc := false
	for !p.eof() {
		c := p.s[p.i]
		p.i++
		if esc {
			esc = false
			continue
		}
		if c == '\\' {
			esc = true
			continue
		}
		if c == '"' {
			var out string
			err := json.Unmarshal([]byte(p.s[start:p.i]), &out)
			return out, err
		}
	}
	return "", errors.New("unterminated string")
}
func (p *hclParser) value() (*Node, error) {
	p.ws()
	if p.eof() {
		return nil, io.EOF
	}
	switch p.s[p.i] {
	case '"':
		s, err := p.str()
		return &Node{Kind: "scalar", Val: s}, err
	case '{':
		p.i++
		n := &Node{Kind: "map"}
		for {
			p.ws()
			if p.eat('}') {
				return n, nil
			}
			k, err := p.key()
			if err != nil {
				return nil, err
			}
			p.ws()
			if !p.eat('=') {
				return nil, errors.New("expected =")
			}
			v, err := p.value()
			if err != nil {
				return nil, err
			}
			n.Pairs = append(n.Pairs, Pair{k, v})
			p.ws()
		}
	case '[':
		p.i++
		n := &Node{Kind: "seq"}
		for {
			p.ws()
			if p.eat(']') {
				return n, nil
			}
			v, err := p.value()
			if err != nil {
				return nil, err
			}
			n.List = append(n.List, v)
			p.ws()
			p.eat(',')
		}
	default:
		start := p.i
		for !p.eof() {
			c := p.s[p.i]
			if c == ',' || c == '\n' || c == '\r' || c == ']' || c == '}' || c == ' ' || c == '\t' {
				break
			}
			p.i++
		}
		tok := p.s[start:p.i]
		switch tok {
		case "true":
			return &Node{Kind: "scalar", Val: true}, nil
		case "false":
			return &Node{Kind: "scalar", Val: false}, nil
		case "null":
			return &Node{Kind: "scalar", Val: nil}, nil
		}
		if i, err := strconv.ParseInt(tok, 10, 64); err == nil {
			return &Node{Kind: "scalar", Val: i}, nil
		}
		if f, err := strconv.ParseFloat(tok, 64); err == nil {
			return &Node{Kind: "scalar", Val: f}, nil
		}
		return &Node{Kind: "scalar", Val: html.UnescapeString(tok)}, nil
	}
}
