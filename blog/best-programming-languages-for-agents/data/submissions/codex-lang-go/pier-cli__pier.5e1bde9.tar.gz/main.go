package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const version = "0.1.6"

type Script struct {
	Alias       string
	Command     string
	Description string
	Tags        []string
}

type Config struct {
	Scripts  map[string]*Script
	Defaults map[string]string
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	cfgPath := ""
	verbose := false
	for len(args) > 0 {
		a := args[0]
		if a == "-h" || a == "--help" {
			printMainHelp()
			return 0
		}
		if a == "-V" || a == "--version" {
			fmt.Printf("pier %s\n", version)
			return 0
		}
		if a == "-v" || a == "--verbose" {
			verbose = true
			_ = verbose
			args = args[1:]
			continue
		}
		if a == "-c" || a == "--config-file" {
			if len(args) < 2 {
				fmt.Fprintln(os.Stderr, "error: The argument '--config-file <path>' requires a value")
				return 1
			}
			cfgPath = args[1]
			args = args[2:]
			continue
		}
		break
	}
	if len(args) == 0 {
		printMainHelp()
		return 0
	}

	cmd := args[0]
	rest := args[1:]
	if cmd == "help" {
		if len(rest) == 0 {
			printMainHelp()
			return 0
		}
		printSubHelp(rest[0])
		return 0
	}
	if cmd == "--help" {
		printMainHelp()
		return 0
	}
	if cmd == "--version" || cmd == "-V" {
		fmt.Printf("pier %s\n", version)
		return 0
	}
	if isHelp(rest) {
		printSubHelp(cmd)
		return 0
	}

	switch cmd {
	case "config-init", "init":
		return configInit()
	case "add":
		return withConfig(cfgPath, true, func(path string, cfg *Config) int { return cmdAdd(path, cfg, rest) })
	case "list", "ls":
		return withConfig(cfgPath, false, func(path string, cfg *Config) int { return cmdList(cfg, rest) })
	case "show":
		return withConfig(cfgPath, false, func(path string, cfg *Config) int { return cmdShow(cfg, rest) })
	case "run":
		return withConfig(cfgPath, false, func(path string, cfg *Config) int { return cmdRun(cfg, rest) })
	case "remove", "rm":
		return withConfig(cfgPath, true, func(path string, cfg *Config) int { return cmdRemove(path, cfg, rest) })
	case "copy", "cp":
		return withConfig(cfgPath, true, func(path string, cfg *Config) int { return cmdCopy(path, cfg, rest) })
	case "move", "mv", "rename":
		return withConfig(cfgPath, true, func(path string, cfg *Config) int { return cmdMove(path, cfg, rest) })
	case "edit":
		return withConfig(cfgPath, true, func(path string, cfg *Config) int { return cmdEdit(path, cfg, rest) })
	default:
		return withConfig(cfgPath, false, func(path string, cfg *Config) int {
			return executeAlias(cfg, cmd, rest)
		})
	}
}

func isHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			return true
		}
	}
	return false
}

func withConfig(path string, write bool, f func(string, *Config) int) int {
	p, err := configPath(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, "error: "+err.Error())
		return 1
	}
	cfg, err := readConfig(p)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: Unable to read config from file %s: %v \n", p, err)
		return 1
	}
	if cfg.Scripts == nil {
		cfg.Scripts = map[string]*Script{}
	}
	if cfg.Defaults == nil {
		cfg.Defaults = map[string]string{}
	}
	return f(p, cfg)
}

func configPath(explicit string) (string, error) {
	if explicit != "" {
		return explicit, nil
	}
	if p := os.Getenv("PIER_CONFIG_PATH"); p != "" {
		return p, nil
	}
	if exists("pier.toml") {
		return "pier.toml", nil
	}
	xdg := os.Getenv("XDG_CONFIG_HOME")
	home := os.Getenv("HOME")
	candidates := []string{}
	if xdg != "" {
		candidates = append(candidates, filepath.Join(xdg, "pier", "config.toml"))
		candidates = append(candidates, filepath.Join(xdg, "pier", "config"))
		candidates = append(candidates, filepath.Join(xdg, "pier.toml"))
	}
	if home != "" {
		candidates = append(candidates, filepath.Join(home, ".pier.toml"), filepath.Join(home, ".pier"))
	}
	for _, p := range candidates {
		if exists(p) {
			return p, nil
		}
	}
	return "", errors.New("No default config file found. See help for more info.")
}

func exists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

func configInit() int {
	xdg := os.Getenv("XDG_CONFIG_HOME")
	if xdg == "" {
		xdg = filepath.Join(os.Getenv("HOME"), ".config")
	}
	dir := filepath.Join(xdg, "pier")
	if err := os.Mkdir(dir, 0755); err != nil && !os.IsExist(err) {
		fmt.Fprintf(os.Stderr, "error: Failed to create directory. %v\n", err)
		return 1
	}
	path := filepath.Join(dir, "config.toml")
	cfg := &Config{Scripts: map[string]*Script{
		"hello-pier": {Alias: "hello-pier", Command: "echo Hello, Pier!", Description: "This is an example command."},
	}, Defaults: map[string]string{}}
	if err := writeConfig(path, cfg); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		return 1
	}
	fmt.Println("Added hello-pier")
	return 0
}

func cmdAdd(path string, cfg *Config, args []string) int {
	alias, desc, tags, force, command, ok := parseAdd(args)
	if !ok || alias == "" {
		printSubHelp("add")
		return 1
	}
	if command == "" {
		text, err := editText("")
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: EditorError: Failed when trying to get input from editor %v\n", err)
			return 1
		}
		command = strings.TrimRight(text, "\n")
	}
	if _, found := cfg.Scripts[alias]; found && !force {
		fmt.Fprintf(os.Stderr, "error: AliasAlreadyExists:  %s\n", alias)
		return 1
	}
	cfg.Scripts[alias] = &Script{Alias: alias, Command: command, Description: desc, Tags: tags}
	if err := writeConfig(path, cfg); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		return 1
	}
	fmt.Printf("Added %s\n", alias)
	return 0
}

func parseAdd(args []string) (alias, desc string, tags []string, force bool, command string, ok bool) {
	ok = true
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--":
			if i+1 < len(args) {
				command = strings.Join(args[i+1:], " ")
			}
			return
		case "-f", "--force":
			force = true
		case "-a", "--alias":
			i++
			if i >= len(args) {
				ok = false
				return
			}
			alias = args[i]
		case "-d", "--description":
			i++
			if i >= len(args) {
				ok = false
				return
			}
			desc = args[i]
		case "-t", "--tag":
			i++
			if i >= len(args) {
				ok = false
				return
			}
			tags = append(tags, args[i])
		default:
			if strings.HasPrefix(a, "-") {
				ok = false
				return
			}
			command = strings.Join(args[i:], " ")
			return
		}
	}
	return
}

func cmdList(cfg *Config, args []string) int {
	aliasesOnly := false
	full := false
	width := 0
	filterTags := []string{}
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-q", "--list_aliases":
			aliasesOnly = true
		case "-l", "--cmd_full":
			full = true
		case "-c", "--cmd_width":
			i++
			if i < len(args) {
				width, _ = strconv.Atoi(args[i])
			}
		case "-t", "--tag":
			i++
			if i < len(args) {
				filterTags = append(filterTags, args[i])
			}
		}
	}
	if len(cfg.Scripts) == 0 {
		fmt.Fprintln(os.Stderr, "error: No scripts exist. Would you like to add a new script?")
		return 1
	}
	rows := filterScripts(cfg, filterTags)
	if aliasesOnly {
		for _, s := range rows {
			fmt.Println(s.Alias)
		}
		return 0
	}
	if full {
		width = 0
	}
	printTable(rows, width)
	return 0
}

func filterScripts(cfg *Config, tags []string) []*Script {
	names := make([]string, 0, len(cfg.Scripts))
	for n := range cfg.Scripts {
		names = append(names, n)
	}
	sort.Strings(names)
	var out []*Script
	for _, name := range names {
		s := cfg.Scripts[name]
		if len(tags) == 0 {
			out = append(out, s)
			continue
		}
		for _, t := range tags {
			if contains(s.Tags, t) {
				out = append(out, s)
			}
		}
	}
	return out
}

func printTable(rows []*Script, cmdWidth int) {
	headers := []string{"Alias", "Tags", "Command", "Description"}
	widths := []int{len(headers[0]), len(headers[1]), len(headers[2]), len(headers[3])}
	type row struct{ a, t, c, d string }
	rs := []row{}
	for _, s := range rows {
		c := s.Command
		if cmdWidth > 0 && len([]rune(c)) > cmdWidth {
			c = string([]rune(c)[:cmdWidth])
		}
		r := row{s.Alias, strings.Join(s.Tags, ","), c, s.Description}
		rs = append(rs, r)
		vals := []string{r.a, r.t, r.c, r.d}
		for i, v := range vals {
			if len([]rune(v)) > widths[i] {
				widths[i] = len([]rune(v))
			}
		}
	}
	border := strings.Repeat("≖", widths[0]+widths[1]+widths[2]+widths[3]+13)
	fmt.Println(border)
	fmt.Printf("⋮ %-*s ⋮ %-*s ⋮ %-*s ⋮ %-*s ⋮\n", widths[0], headers[0], widths[1], headers[1], widths[2], headers[2], widths[3], headers[3])
	fmt.Println(border)
	for _, r := range rs {
		fmt.Printf("⋮ %-*s ⋮ %-*s ⋮ %-*s ⋮ %-*s ⋮\n", widths[0], r.a, widths[1], r.t, widths[2], r.c, widths[3], r.d)
	}
	fmt.Println(border)
}

func cmdShow(cfg *Config, args []string) int {
	if len(args) < 1 {
		printSubHelp("show")
		return 1
	}
	s := cfg.Scripts[args[0]]
	if s == nil {
		fmt.Fprintf(os.Stderr, "error: AliasNotFound: No script found by alias %s\n", args[0])
		return 1
	}
	fmt.Println(s.Command)
	return 0
}

func cmdRun(cfg *Config, args []string) int {
	if len(args) < 1 {
		printSubHelp("run")
		return 1
	}
	return executeAlias(cfg, args[0], args[1:])
}

func executeAlias(cfg *Config, alias string, args []string) int {
	s := cfg.Scripts[alias]
	if s == nil {
		fmt.Fprintf(os.Stderr, "error: AliasNotFound: No script found by alias %s\n", alias)
		return 1
	}
	cmdArgs := append([]string{"-c", s.Command, alias}, args...)
	c := exec.Command("sh", cmdArgs...)
	c.Stdin = os.Stdin
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	if err := c.Run(); err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return ee.ExitCode()
		}
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func cmdRemove(path string, cfg *Config, args []string) int {
	if len(args) < 1 {
		printSubHelp("remove")
		return 1
	}
	if cfg.Scripts[args[0]] == nil {
		fmt.Fprintf(os.Stderr, "error: AliasNotFound: No script found by alias %s\n", args[0])
		return 1
	}
	delete(cfg.Scripts, args[0])
	if err := writeConfig(path, cfg); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		return 1
	}
	fmt.Printf("Removed %s\n", args[0])
	return 0
}

func cmdCopy(path string, cfg *Config, args []string) int {
	if len(args) < 2 {
		printSubHelp("copy")
		return 1
	}
	from, to := args[0], args[1]
	src := cfg.Scripts[from]
	if src == nil {
		fmt.Fprintf(os.Stderr, "error: AliasNotFound: No script found by alias %s\n", from)
		return 1
	}
	if cfg.Scripts[to] != nil {
		fmt.Fprintf(os.Stderr, "error: AliasAlreadyExists:  %s\n", to)
		return 1
	}
	cp := *src
	cp.Alias = to
	cp.Tags = append([]string{}, src.Tags...)
	cfg.Scripts[to] = &cp
	if err := writeConfig(path, cfg); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		return 1
	}
	fmt.Printf("Copy from alias %s to new alias %s\n", from, to)
	return 0
}

func cmdMove(path string, cfg *Config, args []string) int {
	force := false
	clean := []string{}
	for _, a := range args {
		if a == "-f" || a == "--force" {
			force = true
		} else {
			clean = append(clean, a)
		}
	}
	if len(clean) < 2 {
		printSubHelp("move")
		return 1
	}
	from, to := clean[0], clean[1]
	src := cfg.Scripts[from]
	if src == nil {
		fmt.Fprintf(os.Stderr, "error: AliasNotFound: No script found by alias %s\n", from)
		return 1
	}
	if cfg.Scripts[to] != nil && !force {
		fmt.Fprintf(os.Stderr, "error: AliasAlreadyExists:  %s\n", to)
		return 1
	}
	delete(cfg.Scripts, from)
	src.Alias = to
	cfg.Scripts[to] = src
	if err := writeConfig(path, cfg); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		return 1
	}
	fmt.Printf("Move from alias %s to new alias %s\n", from, to)
	return 0
}

func cmdEdit(path string, cfg *Config, args []string) int {
	if len(args) < 1 {
		printSubHelp("edit")
		return 1
	}
	s := cfg.Scripts[args[0]]
	if s == nil {
		fmt.Fprintf(os.Stderr, "error: AliasNotFound: No script found by alias %s\n", args[0])
		return 1
	}
	text, err := editText(s.Command)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: EditorError: Failed when trying to get input from editor %v\n", err)
		return 1
	}
	s.Command = strings.TrimRight(text, "\n")
	if err := writeConfig(path, cfg); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		return 1
	}
	fmt.Printf("Edited %s\n", args[0])
	return 0
}

func editText(initial string) (string, error) {
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = "vi"
	}
	tmp, err := os.CreateTemp("", "pier-edit-*")
	if err != nil {
		return "", err
	}
	name := tmp.Name()
	defer os.Remove(name)
	if initial != "" {
		_, _ = tmp.WriteString(initial)
	}
	tmp.Close()
	c := exec.Command(editor, name)
	c.Stdin = os.Stdin
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	if err := c.Run(); err != nil {
		return "", fmt.Errorf("Failed to open `%s` as a text editor or editor was terminated with errors.", editor)
	}
	b, err := os.ReadFile(name)
	return string(b), err
}

func contains(xs []string, x string) bool {
	for _, v := range xs {
		if v == x {
			return true
		}
	}
	return false
}

func readConfig(path string) (*Config, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	cfg := &Config{Scripts: map[string]*Script{}, Defaults: map[string]string{}}
	var current *Script
	inTags := false
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if inTags {
			if strings.HasPrefix(line, "]") {
				inTags = false
				continue
			}
			line = strings.TrimSuffix(line, ",")
			if current != nil {
				current.Tags = append(current.Tags, unquote(strings.TrimSpace(line)))
			}
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			name := strings.TrimSuffix(strings.TrimPrefix(line, "["), "]")
			current = nil
			if strings.HasPrefix(name, "scripts.") {
				alias := strings.TrimPrefix(name, "scripts.")
				s := &Script{Alias: alias}
				cfg.Scripts[alias] = s
				current = s
			}
			continue
		}
		k, v, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key := strings.TrimSpace(k)
		val := strings.TrimSpace(v)
		if current == nil {
			cfg.Defaults[key] = unquote(strings.TrimSuffix(val, ","))
			continue
		}
		switch key {
		case "command":
			current.Command = unquote(val)
		case "description":
			current.Description = unquote(val)
		case "tags":
			if strings.HasPrefix(val, "[") && strings.Contains(val, "]") {
				body := strings.TrimSpace(strings.TrimSuffix(strings.TrimPrefix(val, "["), "]"))
				if body != "" {
					for _, part := range strings.Split(body, ",") {
						p := strings.TrimSpace(part)
						if p != "" {
							current.Tags = append(current.Tags, unquote(p))
						}
					}
				}
			} else if strings.HasPrefix(val, "[") {
				inTags = true
			}
		}
	}
	return cfg, sc.Err()
}

func writeConfig(path string, cfg *Config) error {
	var b strings.Builder
	names := make([]string, 0, len(cfg.Scripts))
	for n := range cfg.Scripts {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, name := range names {
		s := cfg.Scripts[name]
		fmt.Fprintf(&b, "[scripts.%s]\n", s.Alias)
		fmt.Fprintf(&b, "command = '%s'\n", escapeSingle(s.Command))
		if s.Description != "" {
			fmt.Fprintf(&b, "description = '%s'\n", escapeSingle(s.Description))
		}
		if len(s.Tags) > 0 {
			b.WriteString("tags = [\n")
			for _, t := range s.Tags {
				fmt.Fprintf(&b, "    '%s',\n", escapeSingle(t))
			}
			b.WriteString("]\n")
		}
		b.WriteString("\n")
	}
	b.WriteString("[default]\n")
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func escapeSingle(s string) string {
	return strings.ReplaceAll(s, "'", "\\'")
}

func unquote(s string) string {
	s = strings.TrimSpace(strings.TrimSuffix(s, ","))
	if len(s) >= 2 {
		q := s[0]
		if (q == '\'' || q == '"') && s[len(s)-1] == q {
			x := s[1 : len(s)-1]
			x = strings.ReplaceAll(x, `\'`, `'`)
			x = strings.ReplaceAll(x, `\"`, `"`)
			x = strings.ReplaceAll(x, `\n`, "\n")
			x = strings.ReplaceAll(x, `\t`, "\t")
			x = strings.ReplaceAll(x, `\\`, `\`)
			return x
		}
	}
	return s
}

func printMainHelp() {
	fmt.Printf(`pier %s
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       
            Prints help information

    -V, --version    
            Prints version information

    -v, --verbose    
            The level of verbosity


OPTIONS:
    -c, --config-file <path>    
            Sets a custom config file.
            
            DEFAULT PATH is otherwise determined in this order:
            
            - $PIER_CONFIG_PATH (environment variable if set)
            
            - pier.toml (in the current directory)
            
            - $XDG_CONFIG_HOME/pier/config.toml
            
            - $XDG_CONFIG_HOME/pier/config
            
            - $XDG_CONFIG_HOME/pier.toml
            
            - $HOME/.pier.toml
            
            - $HOME/.pier
            
             [env: PIER_CONFIG_PATH=]

ARGS:
    <alias>      
            The alias or name for the script.

    <args>...    
            The positional arguments to send to script.


SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias.
`, version)
}

func printSubHelp(cmd string) {
	switch cmd {
	case "add":
		fmt.Printf("executable-add %s\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -a, --alias <alias>                The alias or name for the script.\n    -d, --description <description>    The description for the script.\n    -t, --tag <tags>...                Set which tags the script belongs to.\n\nARGS:\n    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR\n                 for you to enter the script into.\n", version)
	case "config-init", "init":
		fmt.Printf("executable-config-init %s\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n", version)
	case "copy", "cp":
		fmt.Printf("executable-copy %s\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be copied.\n    <to-alias>      The new alias of the copy of the script.\n", version)
	case "edit":
		fmt.Printf("executable-edit %s\nEdit a script matching alias.\n\nUSAGE:\n    executable edit <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n", version)
	case "list", "ls":
		fmt.Printf("executable-list %s\nalias: ls - List scripts\n\nDisplay options are determined by priority in this order:\n\n1. List only aliases\n\n2. Show full command\n\n3. Command display with (cli option)\n\n4. Command display with (config option)\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n    -l, --cmd_full        \n            Display the full command.\n\n    -h, --help            \n            Prints help information\n\n    -q, --list_aliases    \n            Only displays aliases of the scripts.\n\n    -V, --version         \n            Prints version information\n\n\nOPTIONS:\n    -c, --cmd_width <cmd-width>    \n            The max number of characters to display from the command.\n\n    -t, --tag <tags>...            \n            Filter based on tags.\n\n", version)
	case "move", "mv", "rename":
		fmt.Printf("executable-move %s\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be moved.\n    <to-alias>      The new alias of the script.\n", version)
	case "remove", "rm":
		fmt.Printf("executable-remove %s\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n", version)
	case "run":
		fmt.Printf("executable-run %s\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script.\n", version)
	case "show":
		fmt.Printf("executable-show %s\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script.\n", version)
	default:
		printMainHelp()
	}
}

var _ io.Reader
