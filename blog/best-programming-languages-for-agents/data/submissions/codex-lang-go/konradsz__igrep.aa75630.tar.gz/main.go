package main

import (
	_ "embed"
	"fmt"
	"os"
	"strings"
)

//go:embed types.txt
var typeList string

const versionText = "igrep 1.3.0\n"

const helpText = `Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
`

var editors = set("vim", "neovim", "nvim", "nano", "code", "vscode", "code-insiders", "emacs", "emacsclient", "hx", "helix", "subl", "sublime-text", "micro", "intellij", "goland", "pycharm", "less", "fresh")
var themes = set("light", "dark")
var viewers = set("none", "vertical", "horizontal")
var sorts = set("path", "modified", "created", "accessed")

func set(vals ...string) map[string]bool {
	m := make(map[string]bool, len(vals))
	for _, v := range vals {
		m[v] = true
	}
	return m
}

func knownTypes() map[string]bool {
	m := map[string]bool{}
	for _, line := range strings.Split(typeList, "\n") {
		if i := strings.IndexByte(line, ':'); i > 0 {
			m[line[:i]] = true
		}
	}
	return m
}

type state struct {
	typeList      bool
	pattern       string
	paths         []string
	editor        string
	customCommand string
	editorSet     bool
	customSet     bool
}

func main() {
	st, code := parse(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}
	if st.typeList {
		if st.pattern != "" || len(st.paths) != 0 {
			usage := "Usage: executable --type-list <PATTERN>"
			if len(st.paths) != 0 {
				usage += " <PATHS>..."
			} else {
				usage += " [PATHS]..."
			}
			fatal2("error: the argument '--type-list' cannot be used with '<PATTERN>'\n\n" + usage + "\n\nFor more information, try '--help'.\n")
		}
		fmt.Print(typeList)
		return
	}
	if st.pattern == "" {
		fatal2("error: the following required arguments were not provided:\n  --type-list\n  <PATTERN>\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n")
	}
	if st.editorSet && st.customSet {
		fatal2("error: the argument '--editor <EDITOR>' cannot be used with '--custom-command <CUSTOM_COMMAND>'\n\nUsage: executable --type-list --editor <EDITOR> <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n")
	}
	if !st.customSet {
		st.customCommand = os.Getenv("IGREP_CUSTOM_EDITOR")
	}
	if st.customCommand != "" {
		validateCommand(st.customCommand)
	}
	fmt.Fprintln(os.Stderr, "Error: Resource temporarily unavailable (os error 11)")
	os.Exit(1)
}

func parse(args []string) (state, int) {
	var st state
	types := knownTypes()
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			for _, v := range args[i+1:] {
				addArg(&st, v)
			}
			break
		}
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return st, 0
		case "-V", "--version":
			fmt.Print(versionText)
			return st, 0
		case "--type-list":
			st.typeList = true
		case "-i", "--ignore-case", "-S", "--smart-case", "-.", "--hidden", "-L", "--follow", "-w", "--word-regexp", "-F", "--fixed-strings", "-U", "--multiline":
		case "--editor":
			i++
			if i >= len(args) {
				missingValue("--editor <EDITOR>")
			}
			st.editor, st.editorSet = args[i], true
			validateChoice("--editor <EDITOR>", st.editor, editors, "vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh")
		case "--custom-command":
			i++
			if i >= len(args) {
				missingValue("--custom-command <CUSTOM_COMMAND>")
			}
			st.customCommand, st.customSet = args[i], true
		case "--theme":
			i++
			if i >= len(args) {
				missingValue("--theme <THEME>")
			}
			validateChoice("--theme <THEME>", args[i], themes, "light, dark")
		case "--context-viewer":
			i++
			if i >= len(args) {
				missingValue("--context-viewer <CONTEXT_VIEWER>")
			}
			validateChoice("--context-viewer <CONTEXT_VIEWER>", args[i], viewers, "none, vertical, horizontal")
		case "--sort":
			i++
			if i >= len(args) {
				missingValue("--sort <SORT_BY>")
			}
			validateChoice("--sort <SORT_BY>", args[i], sorts, "path, modified, created, accessed")
		case "--sortr":
			i++
			if i >= len(args) {
				missingValue("--sortr <SORT_BY_REVERSE>")
			}
			validateChoice("--sortr <SORT_BY_REVERSE>", args[i], sorts, "path, modified, created, accessed")
		case "-g", "--glob":
			i++
			if i >= len(args) {
				missingValue("--glob <GLOB>")
			}
		case "-t", "--type":
			i++
			if i >= len(args) {
				missingValue("--type <TYPE_MATCHING>")
			}
			if !types[args[i]] {
				fmt.Fprintf(os.Stderr, "Error: unrecognized file type: %s\n", args[i])
				os.Exit(1)
			}
		case "-T", "--type-not":
			i++
			if i >= len(args) {
				missingValue("--type-not <TYPE_NOT>")
			}
			if !types[args[i]] {
				fmt.Fprintf(os.Stderr, "Error: unrecognized file type: %s\n", args[i])
				os.Exit(1)
			}
		default:
			if strings.HasPrefix(a, "--editor=") {
				st.editor, st.editorSet = strings.TrimPrefix(a, "--editor="), true
				validateChoice("--editor <EDITOR>", st.editor, editors, "vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh")
			} else if strings.HasPrefix(a, "--theme=") {
				validateChoice("--theme <THEME>", strings.TrimPrefix(a, "--theme="), themes, "light, dark")
			} else if strings.HasPrefix(a, "--context-viewer=") {
				validateChoice("--context-viewer <CONTEXT_VIEWER>", strings.TrimPrefix(a, "--context-viewer="), viewers, "none, vertical, horizontal")
			} else if strings.HasPrefix(a, "--sort=") {
				validateChoice("--sort <SORT_BY>", strings.TrimPrefix(a, "--sort="), sorts, "path, modified, created, accessed")
			} else if strings.HasPrefix(a, "--sortr=") {
				validateChoice("--sortr <SORT_BY_REVERSE>", strings.TrimPrefix(a, "--sortr="), sorts, "path, modified, created, accessed")
			} else if strings.HasPrefix(a, "--custom-command=") {
				st.customCommand, st.customSet = strings.TrimPrefix(a, "--custom-command="), true
			} else if strings.HasPrefix(a, "--glob=") {
			} else if strings.HasPrefix(a, "--type=") {
				v := strings.TrimPrefix(a, "--type=")
				if !types[v] {
					fmt.Fprintf(os.Stderr, "Error: unrecognized file type: %s\n", v)
					os.Exit(1)
				}
			} else if strings.HasPrefix(a, "--type-not=") {
				v := strings.TrimPrefix(a, "--type-not=")
				if !types[v] {
					fmt.Fprintf(os.Stderr, "Error: unrecognized file type: %s\n", v)
					os.Exit(1)
				}
			} else if strings.HasPrefix(a, "-") && len(a) > 2 {
				consumeShortCluster(&st, a, args, &i, types)
			} else if strings.HasPrefix(a, "-") {
				fatal2(fmt.Sprintf("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n", a, a, a))
			} else {
				addArg(&st, a)
			}
		}
	}
	return st, -1
}

func consumeShortCluster(st *state, arg string, args []string, idx *int, types map[string]bool) {
	for pos := 1; pos < len(arg); pos++ {
		switch arg[pos] {
		case 'h':
			fmt.Print(helpText)
			os.Exit(0)
		case 'V':
			fmt.Print(versionText)
			os.Exit(0)
		case 'i', 'S', '.', 'L', 'w', 'F', 'U':
		case 'g':
			if pos+1 < len(arg) {
				return
			}
			*idx = *idx + 1
			if *idx >= len(args) {
				missingValue("--glob <GLOB>")
			}
			return
		case 't', 'T':
			var v string
			if pos+1 < len(arg) {
				v = arg[pos+1:]
			} else {
				*idx = *idx + 1
				if *idx >= len(args) {
					if arg[pos] == 't' {
						missingValue("--type <TYPE_MATCHING>")
					}
					missingValue("--type-not <TYPE_NOT>")
				}
				v = args[*idx]
			}
			if !types[v] {
				fmt.Fprintf(os.Stderr, "Error: unrecognized file type: %s\n", v)
				os.Exit(1)
			}
			return
		default:
			fatal2(fmt.Sprintf("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.\n", arg, arg, arg))
		}
	}
}

func addArg(st *state, v string) {
	if st.pattern == "" {
		st.pattern = v
	} else {
		st.paths = append(st.paths, v)
	}
}

func validateChoice(name, val string, allowed map[string]bool, list string) {
	if allowed[val] {
		return
	}
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s'\n  [possible values: %s]\n\nFor more information, try '--help'.\n", val, name, list)
	os.Exit(2)
}

func validateCommand(cmd string) {
	if strings.Count(cmd, "{file_name}") != 1 {
		fmt.Fprintf(os.Stderr, "Error: Incorrect editor command: '%s'\n\nCaused by:\n    Expected one occurrence of '{file_name}'.\n", cmd)
		os.Exit(1)
	}
	if strings.Count(cmd, "{line_number}") != 1 {
		fmt.Fprintf(os.Stderr, "Error: Incorrect editor command: '%s'\n\nCaused by:\n    Expected one occurrence of '{line_number}'.\n", cmd)
		os.Exit(1)
	}
}

func missingValue(name string) {
	fmt.Fprintf(os.Stderr, "error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.\n", name)
	os.Exit(2)
}

func fatal2(msg string) {
	fmt.Fprint(os.Stderr, msg)
	os.Exit(2)
}
