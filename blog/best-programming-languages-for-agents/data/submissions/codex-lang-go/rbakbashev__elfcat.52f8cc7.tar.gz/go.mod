module elfcat-reimpl

go 1.21
