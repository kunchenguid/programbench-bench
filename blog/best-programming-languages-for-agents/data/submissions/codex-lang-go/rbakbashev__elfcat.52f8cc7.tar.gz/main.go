package main

import (
	"bytes"
	"debug/elf"
	"encoding/hex"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const version = "0.1.10"

func usage(w io.Writer) {
	fmt.Fprintln(w, "Usage: elfcat <filename>")
	fmt.Fprintln(w, "Writes <filename>.html to CWD.")
}

func main() {
	args := os.Args[1:]
	if len(args) == 1 && (args[0] == "--help" || args[0] == "-h") {
		usage(os.Stdout)
		return
	}
	if len(args) == 1 && args[0] == "--version" {
		fmt.Printf("elfcat %s\n", version)
		return
	}
	if len(args) != 1 {
		usage(os.Stderr)
		os.Exit(1)
	}
	if err := run(args[0]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(name string) error {
	data, err := os.ReadFile(name)
	if err != nil {
		return fmt.Errorf("Failed to read file %q: %s", name, rustIOError(err))
	}
	ef, err := elf.NewFile(bytes.NewReader(data))
	if err != nil {
		return fmt.Errorf("Failed to parse ELF: %s", normalizeELFError(err, len(data)))
	}
	defer ef.Close()
	out := filepath.Base(name) + ".html"
	var b strings.Builder
	writeHTML(&b, name, data, ef)
	if err := os.WriteFile(out, []byte(b.String()), 0644); err != nil {
		return fmt.Errorf("Failed to write file %q: %s", out, rustIOError(err))
	}
	return nil
}

func rustIOError(err error) string {
	if os.IsNotExist(err) {
		return "No such file or directory (os error 2)"
	}
	if os.IsPermission(err) {
		return "Permission denied (os error 13)"
	}
	return err.Error()
}

func normalizeELFError(err error, n int) string {
	if n < 16 {
		return "file is smaller than ELF header's e_ident"
	}
	s := err.Error()
	s = strings.TrimPrefix(s, "bad magic number '")
	s = strings.TrimSuffix(s, "' in record at byte 0x0")
	if strings.Contains(err.Error(), "bad magic") {
		return "invalid ELF magic"
	}
	return s
}

func writeHTML(b *strings.Builder, fileName string, data []byte, ef *elf.File) {
	base := filepath.Base(fileName)
	fmt.Fprintf(b, "<!doctype html>\n<html>\n  <head>\n    <meta charset='utf-8'>\n    <meta name='viewport' content='width=900, initial-scale=1'>\n    <title>%s</title>\n", esc(base))
	b.WriteString(style())
	b.WriteString("  </head>\n  <body>\n")
	fmt.Fprintf(b, "    <div id='rightmenu'><a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat %s</a><button class='textbutton' id='settings_toggle'>Settings</button><button class='textbutton' id='help_toggle'>Help</button></div>\n", version)
	writeFileInfo(b, fileName, data, ef)
	writeDump(b, data)
	writeProgramHeaders(b, ef)
	writeSectionHeaders(b, ef)
	writeInfotables(b, data, ef)
	b.WriteString(script(ef))
	b.WriteString("  </body>\n</html>\n")
}

func style() string {
	return `    <style>
      html { font-family: monospace; }
      body { color: #111; }
      #rightmenu { vertical-align: top; text-align: right; float: right; }
      #credits { color: #999; text-decoration: none; margin-bottom: .5em; display: block; }
      .textbutton { color: #222; cursor: pointer; background: none; border: none; padding: 0; margin-left: .5em; font: inherit; }
      table { border-collapse: collapse; margin: .75em 0; }
      td, th { padding: .12em .6em .12em .2em; vertical-align: top; }
      th { text-align: left; border-bottom: 1px solid #ccc; }
      .number { color: #0645ad; }
      .ident { background-color: #e99; }
      .ehdr { background-color: #99e; }
      .phdr { background-color: #eb9; }
      .shdr { background-color: #9be; }
      .segment { background-color: #f99; }
      .section { background-color: #f9f; }
      .hover:hover, .ident:hover, .ehdr:hover, .phdr:hover, .shdr:hover, .segment:hover, .section:hover { background-color: #ee9; }
      .dumpwrap { display: grid; grid-template-columns: max-content max-content max-content; gap: 1em; align-items: start; }
      pre { margin: 0; line-height: 1.25; }
      .itable { border: 1px solid #ddd; display: inline-table; margin-right: 1em; }
      .conceal { }
    </style>
`
}

func writeFileInfo(b *strings.Builder, fileName string, data []byte, ef *elf.File) {
	h := ef.FileHeader
	b.WriteString("    <table>\n")
	row(b, "fileinfo_file_name", "File name:", esc(fileName))
	row(b, "fileinfo_file_size", "File size:", esc(fileSizeFmt(uint64(len(data)))))
	row(b, "fileinfo_class", "Object class:", esc(className(h.Class)))
	row(b, "fileinfo_data", "Data encoding:", esc(dataName(h.Data)))
	row(b, "fileinfo_abi", "ABI:", esc(abiName(h.OSABI)))
	row(b, "fileinfo_e_type", "Type:", esc(typeName(h.Type)))
	row(b, "fileinfo_e_machine", "Architecture:", esc(machineName(h.Machine)))
	row(b, "fileinfo_e_entry", "Entrypoint:", numberHex(uint64(h.Entry)))
	row(b, "fileinfo_ph", "Program headers:", fmt.Sprintf("<span title='0x%x' class='number fileinfo_e_phnum'>%d</span> * <span class='number'>%d</span> @ <span class='number'>%d</span>", len(ef.Progs), len(ef.Progs), phEntSize(h.Class), phOff(data, h.Class)))
	row(b, "fileinfo_sh", "Section headers:", fmt.Sprintf("<span title='0x%x' class='number fileinfo_e_shnum'>%d</span> * <span class='number'>%d</span> @ <span class='number'>%d</span>", len(ef.Sections), len(ef.Sections), shEntSize(h.Class), shOff(data, h.Class)))
	b.WriteString("    </table>\n")
}

func row(b *strings.Builder, class, key, val string) {
	fmt.Fprintf(b, "      <tr class='%s'> <td>%s</td> <td>%s</td> </tr>\n", class, key, val)
}

func writeDump(b *strings.Builder, data []byte) {
	b.WriteString("    <div class='dumpwrap'>\n      <pre id='offsets'>")
	for off := 0; off < len(data); off += 16 {
		fmt.Fprintf(b, "%x\n", off)
	}
	b.WriteString("</pre>\n      <pre id='hexdump'>")
	for off := 0; off < len(data); off += 16 {
		line := data[off:min(off+16, len(data))]
		for i, v := range line {
			if i > 0 {
				b.WriteByte(' ')
			}
			fmt.Fprintf(b, "%02x", v)
		}
		b.WriteByte('\n')
	}
	b.WriteString("</pre>\n      <pre id='ascii'>")
	for off := 0; off < len(data); off += 16 {
		for _, v := range data[off:min(off+16, len(data))] {
			if v >= 32 && v <= 126 {
				b.WriteByte(v)
			} else {
				b.WriteByte('.')
			}
		}
		b.WriteByte('\n')
	}
	b.WriteString("</pre>\n    </div>\n")
}

func writeProgramHeaders(b *strings.Builder, ef *elf.File) {
	b.WriteString("    <h2>Program Headers</h2>\n    <table class='program_headers'>\n      <tr><th>Index</th><th>Type</th><th>Flags</th><th>Offset</th><th>Vaddr</th><th>Filesz</th><th>Memsz</th><th>Align</th></tr>\n")
	for i, p := range ef.Progs {
		fmt.Fprintf(b, "      <tr class='bin_phdr%d phdr hover'><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
			i, i, esc(progTypeName(p.Type)), esc(progFlags(p.Flags)), numberHex(p.Off), numberHex(p.Vaddr), numberDecHex(p.Filesz), numberDecHex(p.Memsz), numberHex(p.Align))
	}
	b.WriteString("    </table>\n")
}

func writeSectionHeaders(b *strings.Builder, ef *elf.File) {
	b.WriteString("    <h2>Section Headers</h2>\n    <table class='section_headers'>\n      <tr><th>Index</th><th>Name</th><th>Type</th><th>Flags</th><th>Address</th><th>Offset</th><th>Size</th><th>Link</th><th>Info</th><th>Align</th><th>Entsize</th></tr>\n")
	for i, s := range ef.Sections {
		fmt.Fprintf(b, "      <tr class='bin_shdr%d shdr hover'><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
			i, i, esc(s.Name), esc(sectionTypeName(s.Type)), esc(sectionFlags(s.Flags)), numberHex(s.Addr), numberHex(s.Offset), numberDecHex(s.Size), s.Link, numberDecHex(uint64(s.Info)), numberHex(s.Addralign), numberDecHex(s.Entsize))
	}
	b.WriteString("    </table>\n")
}

func writeInfotables(b *strings.Builder, data []byte, ef *elf.File) {
	b.WriteString("    <table id='headertable'><tr><td class='infotables'>\n")
	for i, p := range ef.Progs {
		fmt.Fprintf(b, "      <table class='conceal itable' id='info_phdr%d'><th colspan='2' class='phdr_itable'></th>\n", i)
		infoRow(b, "Type:", esc(progTypeName(p.Type)))
		infoRow(b, "Flags:", esc(progFlags(p.Flags)))
		infoRow(b, "Offset in file:", numberHex(p.Off))
		infoRow(b, "Size in file:", numberDecHex(p.Filesz))
		infoRow(b, "Vaddr in memory:", numberHex(p.Vaddr))
		infoRow(b, "Size in memory:", numberDecHex(p.Memsz))
		infoRow(b, "Alignment:", numberHex(p.Align))
		if p.Type == elf.PT_INTERP {
			if interp := cstringAt(data, p.Off, p.Filesz); interp != "" {
				infoRow(b, "Interpreter:", esc(interp))
			}
		}
		b.WriteString("      </table>\n")
	}
	for i, s := range ef.Sections {
		fmt.Fprintf(b, "      <table class='conceal itable' id='info_shdr%d'><th colspan='2' class='shdr_itable'></th>\n", i)
		infoRow(b, "Index:", fmt.Sprint(i))
		infoRow(b, "Name:", esc(s.Name))
		infoRow(b, "Type:", esc(sectionTypeName(s.Type)))
		infoRow(b, "Flags:", esc(sectionFlags(s.Flags)))
		infoRow(b, "Vaddr in memory:", numberHex(s.Addr))
		infoRow(b, "Offset in file:", numberHex(s.Offset))
		infoRow(b, "Size in file:", numberDecHex(s.Size))
		infoRow(b, "Linked section:", fmt.Sprint(s.Link))
		infoRow(b, "Extra info:", numberDecHex(uint64(s.Info)))
		infoRow(b, "Alignment:", numberHex(s.Addralign))
		infoRow(b, "Size of entries:", numberDecHex(s.Entsize))
		if s.Type == elf.SHT_STRTAB {
			names := stringsFromSection(s)
			if len(names) > 0 {
				b.WriteString("        <tr><td></td><td><div>\n")
				for _, n := range names {
					fmt.Fprintf(b, "          %s<br>\n", esc(n))
				}
				b.WriteString("        </div></td></tr>\n")
			}
		}
		b.WriteString("      </table>\n")
	}
	b.WriteString("    </td><td class='infotables'>\n")
	for i, p := range ef.Progs {
		fmt.Fprintf(b, "      <table class='conceal itable' id='info_segment%d'><th colspan='2' class='segment_itable'></th>\n", i)
		infoRow(b, "Type:", esc(progTypeName(p.Type)))
		infoRow(b, "Size in file:", numberDecHex(p.Filesz))
		infoRow(b, "Size in memory:", numberDecHex(p.Memsz))
		b.WriteString("      </table>\n")
	}
	for i, s := range ef.Sections {
		fmt.Fprintf(b, "      <table class='conceal itable' id='info_section%d'><th colspan='2' class='section_itable'></th>\n", i)
		infoRow(b, "Type:", esc(sectionTypeName(s.Type)))
		infoRow(b, "Size:", numberDecHex(s.Size))
		b.WriteString("      </table>\n")
	}
	b.WriteString("    </td></tr></table>\n")
}

func infoRow(b *strings.Builder, k, v string) {
	fmt.Fprintf(b, "        <tr> <td>%s</td> <td>%s</td> </tr>\n", k, v)
}

func script(ef *elf.File) string {
	var b strings.Builder
	b.WriteString("    <script type='text/javascript'>\n")
	b.WriteString("      function connect(a,b) {}\n")
	for i := range ef.Progs {
		fmt.Fprintf(&b, "      connect('.bin_phdr%d > .p_offset', '.bin_segment%d');\n", i, i)
	}
	for i, s := range ef.Sections {
		fmt.Fprintf(&b, "      connect('.bin_shdr%d > .sh_offset', '.bin_section%d');\n", i, i)
		if s.Link != 0 {
			fmt.Fprintf(&b, "      connect('.bin_shdr%d > .sh_link', '.bin_shdr%d');\n", i, s.Link)
		}
	}
	b.WriteString("    </script>\n")
	return b.String()
}

func stringsFromSection(s *elf.Section) []string {
	data, err := s.Data()
	if err != nil {
		return nil
	}
	var out []string
	for _, part := range bytes.Split(data, []byte{0}) {
		if len(part) == 0 {
			continue
		}
		ok := true
		for _, c := range part {
			if c < 32 || c > 126 {
				ok = false
				break
			}
		}
		if ok {
			out = append(out, string(part))
		}
	}
	return out
}

func cstringAt(data []byte, off, size uint64) string {
	if off >= uint64(len(data)) {
		return ""
	}
	end := min(int(off+size), len(data))
	part := data[int(off):end]
	if i := bytes.IndexByte(part, 0); i >= 0 {
		part = part[:i]
	}
	return string(part)
}

func esc(s string) string { return html.EscapeString(s) }

func numberHex(v uint64) string {
	return fmt.Sprintf("<span class='number' title='%d'>0x%x</span>", v, v)
}

func numberDecHex(v uint64) string {
	return fmt.Sprintf("<span class='number' title='0x%x'>%s</span>", v, sizeFmt(v))
}

func sizeFmt(v uint64) string {
	if v >= 1024*1024 {
		return fmt.Sprintf("%d (%.1f MiB)", v, float64(v)/(1024*1024))
	}
	if v >= 1024 {
		return fmt.Sprintf("%d (%.1f KiB)", v, float64(v)/1024)
	}
	return fmt.Sprint(v)
}

func fileSizeFmt(v uint64) string {
	if v >= 1024*1024 {
		return fmt.Sprintf("%.1f MiB (%d B)", float64(v)/(1024*1024), v)
	}
	if v >= 1024 {
		return fmt.Sprintf("%.1f KiB (%d B)", float64(v)/1024, v)
	}
	return fmt.Sprintf("%d B", v)
}

func className(c elf.Class) string {
	switch c {
	case elf.ELFCLASS32:
		return "32-bit"
	case elf.ELFCLASS64:
		return "64-bit"
	}
	return c.String()
}

func dataName(d elf.Data) string {
	switch d {
	case elf.ELFDATA2LSB:
		return "Little endian"
	case elf.ELFDATA2MSB:
		return "Big endian"
	}
	return d.String()
}

func abiName(a elf.OSABI) string {
	if a == elf.ELFOSABI_NONE {
		return "SysV"
	}
	return strings.TrimPrefix(a.String(), "ELFOSABI_")
}

func typeName(t elf.Type) string {
	switch t {
	case elf.ET_NONE:
		return "No file type (NONE)"
	case elf.ET_REL:
		return "Relocatable file (REL)"
	case elf.ET_EXEC:
		return "Executable file (EXEC)"
	case elf.ET_DYN:
		return "Shared object file (DYN)"
	case elf.ET_CORE:
		return "Core file (CORE)"
	}
	return t.String()
}

func machineName(m elf.Machine) string {
	switch m {
	case elf.EM_X86_64:
		return "x86-64"
	case elf.EM_386:
		return "x86"
	case elf.EM_AARCH64:
		return "AArch64"
	case elf.EM_ARM:
		return "ARM"
	case elf.EM_RISCV:
		return "RISC-V"
	}
	return strings.TrimPrefix(m.String(), "EM_")
}

func progTypeName(t elf.ProgType) string {
	switch t {
	case elf.PT_NULL:
		return "NULL"
	case elf.PT_LOAD:
		return "LOAD"
	case elf.PT_DYNAMIC:
		return "DYNAMIC"
	case elf.PT_INTERP:
		return "INTERP"
	case elf.PT_NOTE:
		return "NOTE"
	case elf.PT_SHLIB:
		return "SHLIB"
	case elf.PT_PHDR:
		return "PHDR"
	case elf.PT_TLS:
		return "TLS"
	case elf.PT_GNU_EH_FRAME:
		return "GNU_EH_FRAME (OS-specific)"
	case elf.PT_GNU_STACK:
		return "GNU_STACK (OS-specific)"
	case elf.PT_GNU_RELRO:
		return "GNU_RELRO (OS-specific)"
	}
	return fmt.Sprintf("Unknown: %d", uint32(t))
}

func progFlags(f elf.ProgFlag) string {
	var s string
	if f&elf.PF_R != 0 {
		s += "R"
	}
	if f&elf.PF_W != 0 {
		s += "W"
	}
	if f&elf.PF_X != 0 {
		s += "X"
	}
	if s == "" {
		return "0"
	}
	return s
}

func sectionTypeName(t elf.SectionType) string {
	switch t {
	case elf.SHT_NULL:
		return "NULL"
	case elf.SHT_PROGBITS:
		return "PROGBITS"
	case elf.SHT_SYMTAB:
		return "SYMTAB"
	case elf.SHT_STRTAB:
		return "STRTAB"
	case elf.SHT_RELA:
		return "RELA"
	case elf.SHT_HASH:
		return "HASH"
	case elf.SHT_DYNAMIC:
		return "DYNAMIC"
	case elf.SHT_NOTE:
		return "NOTE"
	case elf.SHT_NOBITS:
		return "NOBITS"
	case elf.SHT_REL:
		return "REL"
	case elf.SHT_SHLIB:
		return "SHLIB"
	case elf.SHT_DYNSYM:
		return "DYNSYM"
	case elf.SHT_INIT_ARRAY:
		return "INIT_ARRAY"
	case elf.SHT_FINI_ARRAY:
		return "FINI_ARRAY"
	case elf.SHT_PREINIT_ARRAY:
		return "PREINIT_ARRAY"
	case elf.SHT_GROUP:
		return "GROUP"
	case elf.SHT_SYMTAB_SHNDX:
		return "SYMTAB_SHNDX"
	case elf.SHT_GNU_HASH:
		return "GNU_HASH (OS-specific)"
	case elf.SHT_GNU_VERDEF:
		return "VER_DEF (OS-specific)"
	case elf.SHT_GNU_VERNEED:
		return "VER_NEED (OS-specific)"
	case elf.SHT_GNU_VERSYM:
		return "HIOS"
	}
	return strings.TrimPrefix(t.String(), "SHT_")
}

func sectionFlags(f elf.SectionFlag) string {
	var s string
	if f&elf.SHF_WRITE != 0 {
		s += "W"
	}
	if f&elf.SHF_ALLOC != 0 {
		s += "A"
	}
	if f&elf.SHF_EXECINSTR != 0 {
		s += "X"
	}
	if f&elf.SHF_MERGE != 0 {
		s += "M"
	}
	if f&elf.SHF_STRINGS != 0 {
		s += "S"
	}
	if f&elf.SHF_INFO_LINK != 0 {
		s += "I"
	}
	if f&elf.SHF_LINK_ORDER != 0 {
		s += "L"
	}
	if f&elf.SHF_TLS != 0 {
		s += "T"
	}
	if s == "" {
		return "0"
	}
	return s
}

func phEntSize(class elf.Class) int {
	if class == elf.ELFCLASS32 {
		return 32
	}
	return 56
}

func shEntSize(class elf.Class) int {
	if class == elf.ELFCLASS32 {
		return 40
	}
	return 64
}

func phOff(data []byte, class elf.Class) uint64 {
	if class == elf.ELFCLASS32 && len(data) >= 32 {
		return uint64(le32(data[28:32]))
	}
	if len(data) >= 40 {
		return le64(data[32:40])
	}
	return 0
}

func shOff(data []byte, class elf.Class) uint64 {
	if class == elf.ELFCLASS32 && len(data) >= 36 {
		return uint64(le32(data[32:36]))
	}
	if len(data) >= 48 {
		return le64(data[40:48])
	}
	return 0
}

func le32(p []byte) uint32 { return uint32(p[0]) | uint32(p[1])<<8 | uint32(p[2])<<16 | uint32(p[3])<<24 }
func le64(p []byte) uint64 {
	return uint64(le32(p[:4])) | uint64(le32(p[4:8]))<<32
}

func _hexBytes(p []byte) string {
	dst := make([]byte, hex.EncodedLen(len(p)))
	hex.Encode(dst, p)
	return string(dst)
}
