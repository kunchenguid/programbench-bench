module fdclone

go 1.21
