package main

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unicode"
)

type config struct {
	hidden, noIgnore, caseSensitive, ignoreCase, glob, fixed, abs, list, follow, fullPath bool
	print0, quiet, showErrors, prune, regexMode                                           bool
	minDepth, maxDepth, maxResults                                                        int
	patterns, paths, exts, excludes, types, execCmd, batchCmd, ignoreContain              []string
	searchPaths                                                                           []string
	format, color, hyperlink, stripCwdPrefix                                              string
	sizeOp                                                                                byte
	size                                                                                  int64
	hasSize                                                                               bool
	changedWithin, changedBefore                                                          *time.Time
	owner                                                                                 ownerFilter
	hasOwner                                                                              bool
	batchSize                                                                             int
}

type ownerFilter struct {
	userSet, groupSet         bool
	notUser, notGroup         bool
	uid, gid                  uint32
	userName, groupName       string
	userNumeric, groupNumeric bool
}

type matcher struct {
	cfg      *config
	regexps  []*regexp.Regexp
	globs    []*regexp.Regexp
	literals []string
}

type result struct {
	path string
	info fs.FileInfo
	mode fs.FileMode
}

type ignoreRule struct {
	pattern string
	dirOnly bool
	negate  bool
	baseDir string
}

const shortHelp = `A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -d, --max-depth <depth>          Set maximum search depth (default: none)
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l), executable (x), empty (e)
  -e, --extension <ext>            Filter by file extension
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command with all search results at once
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
`

func main() {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, "[fd error]:", err)
		os.Exit(1)
	}
	if cfg == nil {
		return
	}
	if cfg.format != "" && (cfg.execCmd != nil || cfg.batchCmd != nil) {
		fmt.Fprintln(os.Stderr, "[fd error]: --format cannot be used with --exec or --exec-batch")
		os.Exit(1)
	}
	if cfg.batchSize == 0 {
		cfg.batchSize = 1 << 30
	}
	if cfg.maxDepth < 0 {
		cfg.maxDepth = 1 << 30
	}
	if cfg.stripCwdPrefix == "" {
		cfg.stripCwdPrefix = "auto"
	}
	if cfg.color == "" {
		cfg.color = "auto"
	}
	m, err := newMatcher(cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, "[fd error]:", err)
		os.Exit(1)
	}
	if cfg.format == "" && cfg.list {
		cfg.batchCmd = []string{"ls", "-l"}
	}
	var results []result
	for _, p := range cfg.paths {
		rs, err := searchRoot(cfg, m, p)
		if err != nil {
			fmt.Fprintf(os.Stderr, "[fd error]: %v\n", err)
			continue
		}
		results = append(results, rs...)
		if cfg.maxResults > 0 && len(results) >= cfg.maxResults {
			results = results[:cfg.maxResults]
			break
		}
	}
	if cfg.quiet {
		if len(results) > 0 {
			os.Exit(0)
		}
		os.Exit(1)
	}
	if len(cfg.execCmd) > 0 {
		os.Exit(runEach(cfg, results))
	}
	if len(cfg.batchCmd) > 0 {
		os.Exit(runBatch(cfg, results))
	}
	writeResults(cfg, results, os.Stdout)
}

func parseArgs(args []string) (*config, error) {
	cfg := &config{maxDepth: -1, minDepth: 1, batchSize: 0}
	var pos []string
	needVal := func(i *int, name string) (string, error) {
		if *i+1 >= len(args) {
			return "", fmt.Errorf("a value is required for '%s'", name)
		}
		*i++
		return args[*i], nil
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			pos = append(pos, args[i+1:]...)
			break
		}
		if a == "-x" || a == "--exec" {
			if i+1 >= len(args) {
				return nil, fmt.Errorf("a value is required for '%s'", a)
			}
			cfg.execCmd = append([]string{}, args[i+1:]...)
			break
		}
		if a == "-X" || a == "--exec-batch" {
			if i+1 >= len(args) {
				return nil, fmt.Errorf("a value is required for '%s'", a)
			}
			cfg.batchCmd = append([]string{}, args[i+1:]...)
			break
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a, "=")
			get := func() (string, error) {
				if has {
					return val, nil
				}
				return needVal(&i, name)
			}
			switch name {
			case "--help":
				fmt.Print(longHelp())
				return nil, nil
			case "--version":
				fmt.Println("fd 10.3.0")
				return nil, nil
			case "--hidden":
				cfg.hidden = true
			case "--no-hidden":
				cfg.hidden = false
			case "--no-ignore", "--no-ignore-vcs":
				cfg.noIgnore = true
			case "--ignore", "--ignore-vcs":
				cfg.noIgnore = false
			case "--unrestricted":
				cfg.hidden = true
				cfg.noIgnore = true
			case "--case-sensitive":
				cfg.caseSensitive = true
				cfg.ignoreCase = false
			case "--ignore-case":
				cfg.ignoreCase = true
				cfg.caseSensitive = false
			case "--glob":
				cfg.glob = true
				cfg.regexMode = false
			case "--regex":
				cfg.glob = false
				cfg.regexMode = true
			case "--fixed-strings":
				cfg.fixed = true
			case "--absolute-path":
				cfg.abs = true
			case "--relative-path":
				cfg.abs = false
			case "--list-details":
				cfg.list = true
			case "--follow":
				cfg.follow = true
			case "--no-follow":
				cfg.follow = false
			case "--full-path":
				cfg.fullPath = true
			case "--print0":
				cfg.print0 = true
			case "--quiet", "--has-results":
				cfg.quiet = true
			case "--show-errors":
				cfg.showErrors = true
			case "--prune":
				cfg.prune = true
			case "--one-file-system", "--mount", "--xdev", "--no-require-git", "--require-git", "--no-ignore-parent": // accepted no-op
			case "--max-depth":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.maxDepth, err = atoi(v)
				if err != nil {
					return nil, err
				}
			case "--min-depth":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.minDepth, err = atoi(v)
				if err != nil {
					return nil, err
				}
			case "--exact-depth":
				v, err := get()
				if err != nil {
					return nil, err
				}
				d, err := atoi(v)
				if err != nil {
					return nil, err
				}
				cfg.minDepth, cfg.maxDepth = d, d
			case "--exclude":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.excludes = append(cfg.excludes, v)
			case "--type":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.types = append(cfg.types, v)
			case "--extension":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.exts = append(cfg.exts, cleanExt(v))
			case "--size":
				v, err := get()
				if err != nil {
					return nil, err
				}
				if err := parseSize(cfg, v); err != nil {
					return nil, err
				}
			case "--changed-within", "--change-newer-than", "--newer", "--changed-after":
				v, err := get()
				if err != nil {
					return nil, err
				}
				t, err := parseTimeArg(v)
				if err != nil {
					return nil, err
				}
				cfg.changedWithin = &t
			case "--changed-before", "--change-older-than", "--older":
				v, err := get()
				if err != nil {
					return nil, err
				}
				t, err := parseTimeArg(v)
				if err != nil {
					return nil, err
				}
				cfg.changedBefore = &t
			case "--owner":
				v, err := get()
				if err != nil {
					return nil, err
				}
				of, err := parseOwner(v)
				if err != nil {
					return nil, err
				}
				cfg.owner, cfg.hasOwner = of, true
			case "--format":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.format = v
			case "--color":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.color = v
			case "--hyperlink":
				if has {
					cfg.hyperlink = val
				} else if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
					i++
					cfg.hyperlink = args[i]
				} else {
					cfg.hyperlink = "auto"
				}
			case "--ignore-contain":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.ignoreContain = append(cfg.ignoreContain, v)
			case "--threads":
				_, err := get()
				if err != nil {
					return nil, err
				}
			case "--max-results":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.maxResults, err = atoi(v)
				if err != nil {
					return nil, err
				}
			case "--base-directory":
				v, err := get()
				if err != nil {
					return nil, err
				}
				if err := os.Chdir(v); err != nil {
					return nil, err
				}
			case "--path-separator":
				v, err := get()
				if err != nil {
					return nil, err
				}
				_ = v
			case "--search-path":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.searchPaths = append(cfg.searchPaths, v)
			case "--strip-cwd-prefix":
				if has {
					cfg.stripCwdPrefix = val
				} else if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
					i++
					cfg.stripCwdPrefix = args[i]
				} else {
					cfg.stripCwdPrefix = "always"
				}
			case "--and":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.patterns = append(cfg.patterns, v)
			case "--batch-size":
				v, err := get()
				if err != nil {
					return nil, err
				}
				cfg.batchSize, err = atoi(v)
				if err != nil {
					return nil, err
				}
			default:
				return nil, fmt.Errorf("unexpected argument '%s' found", a)
			}
			continue
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			for j := 1; j < len(a); j++ {
				ch := a[j]
				rest := ""
				if j+1 < len(a) {
					rest = a[j+1:]
				}
				valueOpt := func(name string) (string, error) {
					if rest != "" {
						j = len(a)
						return rest, nil
					}
					return needVal(&i, name)
				}
				switch ch {
				case 'h':
					fmt.Print(shortHelp)
					return nil, nil
				case 'V':
					fmt.Println("fd 10.3.0")
					return nil, nil
				case 'H':
					cfg.hidden = true
				case 'I':
					cfg.noIgnore = true
				case 'u':
					cfg.hidden = true
					cfg.noIgnore = true
				case 's':
					cfg.caseSensitive = true
					cfg.ignoreCase = false
				case 'i':
					cfg.ignoreCase = true
					cfg.caseSensitive = false
				case 'g':
					cfg.glob = true
				case 'F':
					cfg.fixed = true
				case 'a':
					cfg.abs = true
				case 'l':
					cfg.list = true
				case 'L':
					cfg.follow = true
				case 'p':
					cfg.fullPath = true
				case '0':
					cfg.print0 = true
				case 'q':
					cfg.quiet = true
				case '1':
					cfg.maxResults = 1
				case 'd':
					v, err := valueOpt("-d")
					if err != nil {
						return nil, err
					}
					cfg.maxDepth, err = atoi(v)
					if err != nil {
						return nil, err
					}
				case 'E':
					v, err := valueOpt("-E")
					if err != nil {
						return nil, err
					}
					cfg.excludes = append(cfg.excludes, v)
				case 't':
					v, err := valueOpt("-t")
					if err != nil {
						return nil, err
					}
					cfg.types = append(cfg.types, v)
				case 'e':
					v, err := valueOpt("-e")
					if err != nil {
						return nil, err
					}
					cfg.exts = append(cfg.exts, cleanExt(v))
				case 'S':
					v, err := valueOpt("-S")
					if err != nil {
						return nil, err
					}
					if err := parseSize(cfg, v); err != nil {
						return nil, err
					}
				case 'o':
					v, err := valueOpt("-o")
					if err != nil {
						return nil, err
					}
					of, err := parseOwner(v)
					if err != nil {
						return nil, err
					}
					cfg.owner, cfg.hasOwner = of, true
				case 'c':
					v, err := valueOpt("-c")
					if err != nil {
						return nil, err
					}
					cfg.color = v
				case 'j':
					_, err := valueOpt("-j")
					if err != nil {
						return nil, err
					}
				default:
					return nil, fmt.Errorf("unexpected argument '-%c' found", ch)
				}
			}
			continue
		}
		pos = append(pos, a)
	}
	if len(cfg.searchPaths) > 0 {
		cfg.paths = cfg.searchPaths
		if len(pos) > 0 {
			cfg.patterns = append([]string{pos[0]}, cfg.patterns...)
		}
	} else {
		if len(pos) > 0 {
			cfg.patterns = append([]string{pos[0]}, cfg.patterns...)
			cfg.paths = append(cfg.paths, pos[1:]...)
		}
	}
	if len(cfg.paths) == 0 {
		cfg.paths = []string{"."}
	}
	return cfg, nil
}

func atoi(s string) (int, error) {
	n, err := strconv.Atoi(s)
	if err != nil || n < 0 {
		return 0, fmt.Errorf("invalid value '%s'", s)
	}
	return n, nil
}
func cleanExt(s string) string { return strings.TrimPrefix(strings.ToLower(s), ".") }

func longHelp() string {
	return `A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]
          the search pattern which is either a regular expression (default) or a glob pattern (if
          --glob is used). If no pattern has been specified, every entry is considered a match.

  [path]...
          The directory where the filesystem search is rooted (optional). If omitted, search the
          current working directory.

Options:
` + strings.Join(strings.Split(shortHelp, "\n")[9:], "\n")
}

func newMatcher(cfg *config) (*matcher, error) {
	m := &matcher{cfg: cfg}
	pats := cfg.patterns
	if len(pats) == 0 {
		return m, nil
	}
	ci := cfg.ignoreCase || (!cfg.caseSensitive && !hasUpper(strings.Join(pats, "")))
	for _, p := range pats {
		if cfg.fixed {
			if ci {
				p = strings.ToLower(p)
			}
			m.literals = append(m.literals, p)
		} else if cfg.glob {
			re, err := regexp.Compile(globRegexp(p, ci))
			if err != nil {
				return nil, err
			}
			m.globs = append(m.globs, re)
		} else {
			if ci {
				p = "(?i)" + p
			}
			re, err := regexp.Compile(p)
			if err != nil {
				return nil, err
			}
			m.regexps = append(m.regexps, re)
		}
	}
	return m, nil
}

func hasUpper(s string) bool {
	for _, r := range s {
		if unicode.IsUpper(r) {
			return true
		}
	}
	return false
}

func (m *matcher) match(path string, name string) bool {
	if len(m.cfg.patterns) == 0 {
		return true
	}
	target := name
	if m.cfg.fullPath {
		if abs, err := filepath.Abs(path); err == nil {
			target = filepath.ToSlash(abs)
		} else {
			target = filepath.ToSlash(path)
		}
	}
	if len(m.literals) > 0 {
		t := target
		if m.cfg.ignoreCase || (!m.cfg.caseSensitive && !hasUpper(strings.Join(m.cfg.patterns, ""))) {
			t = strings.ToLower(t)
		}
		for _, lit := range m.literals {
			if !strings.Contains(t, lit) {
				return false
			}
		}
		return true
	}
	for _, re := range m.regexps {
		if !re.MatchString(target) {
			return false
		}
	}
	for _, re := range m.globs {
		if !re.MatchString(filepath.ToSlash(target)) {
			return false
		}
	}
	return true
}

func globRegexp(p string, ci bool) string {
	var b strings.Builder
	if ci {
		b.WriteString("(?i)")
	}
	b.WriteString("^")
	for i := 0; i < len(p); i++ {
		c := p[i]
		if c == '*' {
			if i+1 < len(p) && p[i+1] == '*' {
				b.WriteString(".*")
				i++
			} else {
				b.WriteString("[^/]*")
			}
		} else if c == '?' {
			b.WriteString("[^/]")
		} else if c == '[' {
			j := i + 1
			for j < len(p) && p[j] != ']' {
				j++
			}
			if j < len(p) {
				b.WriteString(p[i : j+1])
				i = j
			} else {
				b.WriteString("\\[")
			}
		} else {
			b.WriteString(regexp.QuoteMeta(string(c)))
		}
	}
	b.WriteString("$")
	return b.String()
}

func searchRoot(cfg *config, m *matcher, root string) ([]result, error) {
	st, err := os.Stat(root)
	if err != nil || !st.IsDir() {
		return nil, fmt.Errorf("Search path '%s' is not a directory.", root)
	}
	var out []result
	var walk func(dir string, depth int, rules []ignoreRule)
	walk = func(dir string, depth int, rules []ignoreRule) {
		if cfg.maxResults > 0 && len(out) >= cfg.maxResults {
			return
		}
		for _, marker := range cfg.ignoreContain {
			if _, err := os.Lstat(filepath.Join(dir, marker)); err == nil {
				return
			}
		}
		if !cfg.noIgnore {
			rules = append(rules, readIgnoreFiles(dir)...)
		}
		ents, err := os.ReadDir(dir)
		if err != nil {
			if cfg.showErrors {
				fmt.Fprintf(os.Stderr, "[fd error]: %v\n", err)
			}
			return
		}
		sort.Slice(ents, func(i, j int) bool { return ents[i].Name() < ents[j].Name() })
		for _, de := range ents {
			if cfg.maxResults > 0 && len(out) >= cfg.maxResults {
				return
			}
			name := de.Name()
			path := filepath.Join(dir, name)
			info, lerr := os.Lstat(path)
			if lerr != nil {
				if cfg.showErrors {
					fmt.Fprintf(os.Stderr, "[fd error]: %v\n", lerr)
				}
				continue
			}
			mode := info.Mode()
			isDir := de.IsDir()
			if mode&os.ModeSymlink != 0 && cfg.follow {
				if fi, err := os.Stat(path); err == nil {
					info = fi
					isDir = fi.IsDir()
					mode = fi.Mode() | os.ModeSymlink
				}
			}
			if !cfg.hidden && strings.HasPrefix(name, ".") {
				continue
			}
			if !cfg.noIgnore && ignored(path, name, isDir, rules) {
				continue
			}
			if excluded(path, name, cfg.excludes) {
				continue
			}
			if depth >= cfg.minDepth && m.match(path, name) && filters(cfg, path, info, mode, isDir) {
				out = append(out, result{path: displayPath(cfg, path, isDir && mode&os.ModeSymlink == 0), info: info, mode: mode})
			}
			if isDir && (mode&os.ModeSymlink == 0 || cfg.follow) && depth < cfg.maxDepth {
				if cfg.prune && m.match(path, name) {
					continue
				}
				walk(path, depth+1, rules)
			}
		}
	}
	walk(filepath.Clean(root), 1, nil)
	if len(out) == 0 && len(cfg.paths) == 1 {
		// fd exits successfully for no matches.
	}
	return out, nil
}

func displayPath(cfg *config, p string, dir bool) string {
	var s string
	if cfg.abs {
		if a, err := filepath.Abs(p); err == nil {
			s = a
		} else {
			s = p
		}
	} else {
		s = filepath.ToSlash(p)
		if strings.HasPrefix(s, "./") && !(cfg.print0 || len(cfg.execCmd) > 0 || len(cfg.batchCmd) > 0) {
			s = strings.TrimPrefix(s, "./")
		}
	}
	if dir && !strings.HasSuffix(s, "/") {
		s += "/"
	}
	if cfg.stripCwdPrefix == "always" && strings.HasPrefix(s, "./") {
		s = strings.TrimPrefix(s, "./")
	}
	if cfg.stripCwdPrefix == "never" && !cfg.abs && !strings.HasPrefix(s, "./") && (cfg.print0 || len(cfg.execCmd) > 0 || len(cfg.batchCmd) > 0) {
		s = "./" + s
	}
	return s
}

func readIgnoreFiles(dir string) []ignoreRule {
	var rules []ignoreRule
	for _, fn := range []string{".gitignore", ".ignore", ".fdignore"} {
		data, err := os.ReadFile(filepath.Join(dir, fn))
		if err != nil {
			continue
		}
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			neg := strings.HasPrefix(line, "!")
			if neg {
				line = strings.TrimPrefix(line, "!")
			}
			dirOnly := strings.HasSuffix(line, "/")
			line = strings.Trim(line, "/")
			if line == "" {
				continue
			}
			rules = append(rules, ignoreRule{pattern: line, dirOnly: dirOnly, negate: neg, baseDir: dir})
		}
	}
	return rules
}

func ignored(path, name string, isDir bool, rules []ignoreRule) bool {
	ig := false
	for _, r := range rules {
		if r.dirOnly && !isDir {
			continue
		}
		rel, _ := filepath.Rel(r.baseDir, path)
		rel = filepath.ToSlash(rel)
		match := false
		if strings.Contains(r.pattern, "/") {
			match = globMatch(r.pattern, rel)
		} else {
			for _, part := range strings.Split(rel, "/") {
				if globMatch(r.pattern, part) {
					match = true
					break
				}
			}
		}
		if match {
			ig = !r.negate
		}
	}
	_ = name
	return ig
}

func excluded(path, name string, ex []string) bool {
	rel := filepath.ToSlash(path)
	for _, p := range ex {
		if globMatch(p, name) || globMatch(p, rel) {
			return true
		}
	}
	return false
}

func globMatch(p, s string) bool {
	re, err := regexp.Compile(globRegexp(p, false))
	if err != nil {
		return false
	}
	return re.MatchString(filepath.ToSlash(s))
}

func filters(cfg *config, path string, info fs.FileInfo, mode fs.FileMode, isDir bool) bool {
	if len(cfg.exts) > 0 {
		ext := cleanExt(filepath.Ext(path))
		ok := false
		for _, e := range cfg.exts {
			if e == ext {
				ok = true
				break
			}
		}
		if !ok {
			return false
		}
	}
	if len(cfg.types) > 0 && !typeMatch(cfg.types, path, info, mode, isDir) {
		return false
	}
	if cfg.hasSize {
		s := info.Size()
		switch cfg.sizeOp {
		case '+':
			if s < cfg.size {
				return false
			}
		case '-':
			if s > cfg.size {
				return false
			}
		default:
			if s != cfg.size {
				return false
			}
		}
	}
	if cfg.changedWithin != nil && !info.ModTime().After(*cfg.changedWithin) {
		return false
	}
	if cfg.changedBefore != nil && !info.ModTime().Before(*cfg.changedBefore) {
		return false
	}
	if cfg.hasOwner && !ownerMatches(cfg.owner, info) {
		return false
	}
	return true
}

func typeMatch(types []string, path string, info fs.FileInfo, mode fs.FileMode, isDir bool) bool {
	wantEmpty, regularType := false, false
	typeOK := false
	for _, t := range types {
		t = strings.ToLower(t)
		switch t {
		case "f", "file":
			regularType = true
			if mode.IsRegular() {
				typeOK = true
			}
		case "d", "dir", "directory":
			regularType = true
			if isDir && mode&os.ModeSymlink == 0 {
				typeOK = true
			}
		case "l", "symlink":
			regularType = true
			if mode&os.ModeSymlink != 0 {
				typeOK = true
			}
		case "x", "executable":
			regularType = true
			if mode.IsRegular() && mode&0111 != 0 {
				typeOK = true
			}
		case "e", "empty":
			wantEmpty = true
		case "s", "socket":
			regularType = true
			if mode&os.ModeSocket != 0 {
				typeOK = true
			}
		case "p", "pipe":
			regularType = true
			if mode&os.ModeNamedPipe != 0 {
				typeOK = true
			}
		case "b", "block-device":
			regularType = true
			if mode&os.ModeDevice != 0 && mode&os.ModeCharDevice == 0 {
				typeOK = true
			}
		case "c", "char-device":
			regularType = true
			if mode&os.ModeCharDevice != 0 {
				typeOK = true
			}
		}
	}
	if regularType && !typeOK {
		return false
	}
	if wantEmpty {
		if isDir && mode&os.ModeSymlink == 0 {
			ents, err := os.ReadDir(path)
			if err != nil || len(ents) != 0 {
				return false
			}
		} else if info.Size() != 0 {
			return false
		}
	}
	return true
}

func writeResults(cfg *config, results []result, w io.Writer) {
	sep := "\n"
	if cfg.print0 {
		sep = "\x00"
	}
	for _, r := range results {
		s := r.path
		if cfg.format != "" {
			s = applyFormat(cfg.format, r.path)
		}
		if cfg.hyperlink == "always" {
			s = hyperlink(s)
		}
		fmt.Fprint(w, s, sep)
	}
}

func applyFormat(f, p string) string {
	repl := map[string]string{
		"{}": p, "{/}": filepath.Base(strings.TrimSuffix(p, "/")),
		"{//}": filepath.ToSlash(filepath.Dir(strings.TrimSuffix(p, "/"))),
		"{.}":  trimExt(p), "{/.}": trimExt(filepath.Base(strings.TrimSuffix(p, "/"))),
		"{{": "{", "}}": "}",
	}
	keys := []string{"{/}", "{//}", "{/.}", "{.}", "{}", "{{", "}}"}
	for _, k := range keys {
		f = strings.ReplaceAll(f, k, repl[k])
	}
	return f
}

func trimExt(p string) string {
	ext := filepath.Ext(strings.TrimSuffix(p, "/"))
	if ext == "" {
		return strings.TrimSuffix(p, "/")
	}
	return strings.TrimSuffix(strings.TrimSuffix(p, "/"), ext)
}

func hyperlink(s string) string {
	target := strings.TrimSuffix(s, "/")
	if a, err := filepath.Abs(target); err == nil {
		return "\x1b]8;;file://" + a + "\x1b\\" + s + "\x1b]8;;\x1b\\"
	}
	return s
}

func substArgs(args []string, paths []string) []string {
	has := false
	for _, a := range args {
		if strings.Contains(a, "{") {
			has = true
			break
		}
	}
	if !has {
		return append(append([]string{}, args...), paths...)
	}
	var out []string
	for _, a := range args {
		if a == "{}" {
			out = append(out, paths...)
		} else {
			for _, p := range paths {
				out = append(out, applyFormat(a, p))
			}
		}
	}
	return out
}

func runEach(cfg *config, results []result) int {
	code := 0
	for _, r := range results {
		args := substArgs(cfg.execCmd, []string{r.path})
		if len(args) == 0 {
			continue
		}
		cmd := exec.Command(args[0], args[1:]...)
		cmd.Stdout, cmd.Stderr, cmd.Stdin = os.Stdout, os.Stderr, os.Stdin
		if err := cmd.Run(); err != nil {
			code = exitCode(err)
		}
	}
	return code
}

func runBatch(cfg *config, results []result) int {
	paths := make([]string, len(results))
	for i, r := range results {
		paths[i] = r.path
	}
	code := 0
	for start := 0; start < len(paths); start += cfg.batchSize {
		end := start + cfg.batchSize
		if end > len(paths) {
			end = len(paths)
		}
		args := substArgs(cfg.batchCmd, paths[start:end])
		if len(args) == 0 {
			continue
		}
		cmd := exec.Command(args[0], args[1:]...)
		cmd.Stdout, cmd.Stderr, cmd.Stdin = os.Stdout, os.Stderr, os.Stdin
		if err := cmd.Run(); err != nil {
			code = exitCode(err)
		}
	}
	return code
}

func exitCode(err error) int {
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		return ee.ExitCode()
	}
	return 1
}

func parseSize(cfg *config, s string) error {
	cfg.hasSize = true
	if strings.HasPrefix(s, "+") || strings.HasPrefix(s, "-") {
		cfg.sizeOp = s[0]
		s = s[1:]
	}
	re := regexp.MustCompile(`(?i)^([0-9]+)([a-z]*)$`)
	m := re.FindStringSubmatch(s)
	if m == nil {
		return fmt.Errorf("invalid size '%s'", s)
	}
	n, _ := strconv.ParseInt(m[1], 10, 64)
	mul := int64(1)
	switch strings.ToLower(m[2]) {
	case "", "b":
		mul = 1
	case "k":
		mul = 1000
	case "m":
		mul = 1000 * 1000
	case "g":
		mul = 1000 * 1000 * 1000
	case "t":
		mul = 1000 * 1000 * 1000 * 1000
	case "ki":
		mul = 1024
	case "mi":
		mul = 1024 * 1024
	case "gi":
		mul = 1024 * 1024 * 1024
	case "ti":
		mul = 1024 * 1024 * 1024 * 1024
	default:
		return fmt.Errorf("invalid size unit '%s'", m[2])
	}
	cfg.size = n * mul
	return nil
}

func parseTimeArg(s string) (time.Time, error) {
	now := time.Now()
	if strings.HasPrefix(s, "@") {
		n, err := strconv.ParseInt(strings.TrimPrefix(s, "@"), 10, 64)
		if err != nil {
			return time.Time{}, err
		}
		return time.Unix(n, 0), nil
	}
	if d, ok := parseDurationLoose(s); ok {
		return now.Add(-d), nil
	}
	for _, layout := range []string{"2006-01-02 15:04:05", "2006-01-02 15:04", "2006-01-02"} {
		if t, err := time.ParseInLocation(layout, s, time.Local); err == nil {
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("invalid date or duration '%s'", s)
}

func parseDurationLoose(s string) (time.Duration, bool) {
	re := regexp.MustCompile(`(?i)^([0-9]+)(s|sec|secs|second|seconds|min|mins|minute|minutes|h|hour|hours|d|day|days|w|week|weeks)$`)
	m := re.FindStringSubmatch(s)
	if m == nil {
		d, err := time.ParseDuration(s)
		return d, err == nil
	}
	n, _ := strconv.Atoi(m[1])
	switch strings.ToLower(m[2]) {
	case "s", "sec", "secs", "second", "seconds":
		return time.Duration(n) * time.Second, true
	case "min", "mins", "minute", "minutes":
		return time.Duration(n) * time.Minute, true
	case "h", "hour", "hours":
		return time.Duration(n) * time.Hour, true
	case "d", "day", "days":
		return time.Duration(n) * 24 * time.Hour, true
	case "w", "week", "weeks":
		return time.Duration(n) * 7 * 24 * time.Hour, true
	}
	return 0, false
}

func parseOwner(s string) (ownerFilter, error) {
	var of ownerFilter
	u, g, hasColon := strings.Cut(s, ":")
	if u != "" {
		of.userSet = true
		if strings.HasPrefix(u, "!") {
			of.notUser = true
			u = strings.TrimPrefix(u, "!")
		}
		if n, err := strconv.ParseUint(u, 10, 32); err == nil {
			of.uid = uint32(n)
			of.userNumeric = true
		} else if usr, err := user.Lookup(u); err == nil {
			id, _ := strconv.ParseUint(usr.Uid, 10, 32)
			of.uid = uint32(id)
		} else {
			of.userName = u
		}
	}
	if hasColon && g != "" {
		of.groupSet = true
		if strings.HasPrefix(g, "!") {
			of.notGroup = true
			g = strings.TrimPrefix(g, "!")
		}
		if n, err := strconv.ParseUint(g, 10, 32); err == nil {
			of.gid = uint32(n)
			of.groupNumeric = true
		} else if gr, err := user.LookupGroup(g); err == nil {
			id, _ := strconv.ParseUint(gr.Gid, 10, 32)
			of.gid = uint32(id)
		} else {
			of.groupName = g
		}
	}
	return of, nil
}

func ownerMatches(of ownerFilter, info fs.FileInfo) bool {
	st, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return false
	}
	if of.userSet {
		m := st.Uid == of.uid
		if of.userName != "" {
			m = false
		}
		if of.notUser {
			m = !m
		}
		if !m {
			return false
		}
	}
	if of.groupSet {
		m := st.Gid == of.gid
		if of.groupName != "" {
			m = false
		}
		if of.notGroup {
			m = !m
		}
		if !m {
			return false
		}
	}
	return true
}

func init() {
	_ = bytes.MinRead
}
