package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"sort"
	"strings"
	"syscall"
)

var usage = "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]"

var methodRe = regexp.MustCompile(`^[A-Z][A-Z0-9_-]*$`)

var valueOpts = map[string]bool{
	"-A": true, "--user-agent": true, "-b": true, "--cookie": true, "-c": true, "--cookie-jar": true,
	"-d": true, "--data": true, "--data-ascii": true, "--data-binary": true, "--data-raw": true, "--data-urlencode": true,
	"-D": true, "--dump-header": true, "-F": true, "--form": true, "--form-string": true, "-H": true, "--header": true,
	"-K": true, "--config": true, "-o": true, "--output": true, "-u": true, "--user": true, "-X": true, "--request": true,
	"-e": true, "--referer": true, "-m": true, "--max-time": true, "--connect-timeout": true, "--url": true,
	"--cacert": true, "--capath": true, "-E": true, "--cert": true, "--cert-type": true, "--ciphers": true,
	"--connect-to": true, "-C": true, "--continue-at": true, "--dns-interface": true, "--dns-ipv4-addr": true,
	"--dns-ipv6-addr": true, "--dns-servers": true, "--doh-url": true, "--engine": true, "--etag-compare": true,
	"--etag-save": true, "--expect100-timeout": true, "--ftp-account": true, "--ftp-alternative-to-user": true,
	"--ftp-method": true, "-P": true, "--ftp-port": true, "--ftp-ssl-ccc-mode": true, "--happy-eyeballs-timeout-ms": true,
	"--hostpubmd5": true, "--hostpubsha256": true, "--hsts": true, "--interface": true, "--keepalive-time": true,
	"--key": true, "--key-type": true, "--krb": true, "--libcurl": true, "--limit-rate": true, "--local-port": true,
	"--login-options": true, "--mail-auth": true, "--mail-from": true, "--mail-rcpt": true, "--max-filesize": true,
	"--max-redirs": true, "--netrc-file": true, "--output-dir": true, "--parallel-max": true, "--proto": true,
	"--proto-default": true, "--proto-redir": true, "-x": true, "--proxy": true, "--proxy-cacert": true,
	"--proxy-capath": true, "--proxy-cert": true, "--proxy-cert-type": true, "--proxy-ciphers": true,
	"--proxy-header": true, "--proxy-key": true, "--proxy-key-type": true, "--proxy-service-name": true,
	"--proxy-tls13-ciphers": true, "-U": true, "--proxy-user": true, "--preproxy": true, "-Q": true,
	"--quote": true, "-r": true, "--range": true, "--rate": true, "--request-target": true, "--resolve": true,
	"--retry": true, "--retry-delay": true, "--retry-max-time": true, "--service-name": true, "--socks5-basic": true,
	"--socks5-gssapi-service": true, "--speed-limit": true, "--speed-time": true, "--stderr": true,
	"--suppress-connect-headers": true, "--telnet-option": true, "--tftp-blksize": true, "--tftp-no-options": true,
	"--tls13-ciphers": true, "--tls-max": true, "--trace": true, "--trace-ascii": true, "--trace-time": false,
	"-T": true, "--upload-file": true, "--url-query": true, "--variable": true, "-w": true, "--write-out": true,
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		printCurlHelp([]string{"--help", "all"})
		return
	}
	if args[0] == "--version" || args[0] == "-V" {
		os.Exit(runCurl(args))
	}
	if args[0] == "--manual" || args[0] == "-M" {
		os.Exit(runCurl(args))
	}
	if args[0] == "--help" || args[0] == "-h" {
		if len(args) > 1 {
			printCurlHelp([]string{"--help", args[1]})
		} else {
			printCurlHelp([]string{"--help", "bogus"})
		}
		return
	}

	cfg, err := parse(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if cfg.dryRun {
		if cfg.url != "" {
			fmt.Fprintln(os.Stdout, normalizeURL(cfg.url))
		}
		fmt.Fprintln(os.Stdout, shellLine(cfg.curlArgs()))
		return
	}
	if cfg.url != "" {
		fmt.Fprintln(os.Stderr, normalizeURL(cfg.url))
	}
	if cfg.pretty {
		os.Exit(runCurlPretty(cfg.curlArgs()))
	}
	os.Exit(runCurl(cfg.curlArgs()))
}

type config struct {
	dryRun     bool
	pretty     bool
	form       bool
	curlPrefix []string
	method     string
	url        string
	headers    []string
	fields     map[string]any
	query      url.Values
	rawItems   []string
}

func parse(args []string) (*config, error) {
	cfg := &config{fields: map[string]any{}, query: url.Values{}}
	i := 0
	for i < len(args) {
		a := args[i]
		if a == "--curl" {
			cfg.dryRun = true
			i++
			continue
		}
		if a == "--pretty" {
			cfg.pretty = true
			i++
			continue
		}
		if a == "--form" || a == "-F" {
			cfg.form = true
			cfg.curlPrefix = append(cfg.curlPrefix, a)
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				cfg.curlPrefix = append(cfg.curlPrefix, args[i+1])
				i += 2
			} else {
				i++
			}
			continue
		}
		if strings.HasPrefix(a, "-") {
			cfg.curlPrefix = append(cfg.curlPrefix, a)
			name := a
			if p := strings.IndexByte(name, '='); p >= 0 {
				name = name[:p]
			}
			if valueOpts[name] && !strings.Contains(a, "=") && i+1 < len(args) {
				cfg.curlPrefix = append(cfg.curlPrefix, args[i+1])
				i += 2
			} else {
				i++
			}
			continue
		}
		break
	}
	if i >= len(args) {
		return cfg, nil
	}
	if methodRe.MatchString(args[i]) && i+1 < len(args) {
		cfg.method = args[i]
		i++
	}
	cfg.url = args[i]
	i++
	for ; i < len(args); i++ {
		cfg.addItem(args[i])
	}
	return cfg, nil
}

func (c *config) addItem(s string) {
	if c.form {
		c.rawItems = append(c.rawItems, "-F", s)
		return
	}
	if p := strings.Index(s, "=="); p > 0 {
		c.query.Add(s[:p], s[p+2:])
		return
	}
	if p := strings.Index(s, ":="); p > 0 {
		var v any
		if json.Unmarshal([]byte(s[p+2:]), &v) != nil {
			v = s[p+2:]
		}
		c.fields[s[:p]] = v
		return
	}
	if p := strings.Index(s, "="); p > 0 {
		c.fields[s[:p]] = s[p+1:]
		return
	}
	if p := strings.Index(s, ":"); p > 0 {
		c.headers = append(c.headers, s)
		return
	}
	c.rawItems = append(c.rawItems, s)
}

func (c *config) curlArgs() []string {
	var out []string
	out = append(out, c.curlPrefix...)
	if c.pretty {
		out = append(out, "-v")
	}
	if c.method != "" {
		out = append(out, "-X", c.method)
	}
	for _, h := range c.headers {
		out = append(out, "-H", h)
	}
	out = append(out, c.rawItems...)
	body := c.body()
	if body != "" {
		out = append(out, "-d", body)
	}
	if c.url != "" {
		out = append(out, c.urlWithQuery())
	}
	out = append(out, "-s", "-S")
	if !c.form {
		if body == "" {
			out = append(out, "-d@-")
		}
		out = append(out, "-H", "Content-Type: application/json")
	}
	out = append(out, "-H", "Accept: application/json, */*")
	return out
}

func (c *config) body() string {
	if len(c.fields) == 0 {
		return ""
	}
	keys := make([]string, 0, len(c.fields))
	for k := range c.fields {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var b bytes.Buffer
	b.WriteByte('{')
	for i, k := range keys {
		if i > 0 {
			b.WriteByte(',')
		}
		kb, _ := json.Marshal(k)
		vb, _ := json.Marshal(c.fields[k])
		b.Write(kb)
		b.WriteByte(':')
		b.Write(vb)
	}
	b.WriteByte('}')
	return b.String()
}

func (c *config) urlWithQuery() string {
	if len(c.query) == 0 {
		return c.url
	}
	u, err := url.Parse(c.url)
	if err != nil {
		return c.url
	}
	q := u.Query()
	for k, vs := range c.query {
		for _, v := range vs {
			q.Add(k, v)
		}
	}
	u.RawQuery = q.Encode()
	return u.String()
}

func normalizeURL(s string) string {
	if s == "" {
		return ""
	}
	if strings.Contains(s, "://") {
		return s
	}
	return "http://" + s
}

func shellLine(args []string) string {
	parts := []string{"curl"}
	for _, a := range args {
		parts = append(parts, quote(a))
	}
	return strings.Join(parts, " ")
}

func quote(s string) string {
	if s == "" {
		return `""`
	}
	if strings.ContainsAny(s, " \t\n") {
		return `"` + strings.ReplaceAll(s, `"`, `\"`) + `"`
	}
	return s
}

func runCurl(args []string) int {
	cmd := exec.Command("curl", args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	err := cmd.Run()
	if err == nil {
		return 0
	}
	if ee, ok := err.(*exec.ExitError); ok {
		if st, ok := ee.Sys().(syscall.WaitStatus); ok {
			return st.ExitStatus()
		}
	}
	fmt.Fprintln(os.Stderr, err)
	return 1
}

func runCurlPretty(args []string) int {
	cmd := exec.Command("curl", args...)
	cmd.Stdin = os.Stdin
	cmd.Stderr = os.Stderr
	out, err := cmd.Output()
	if len(out) > 0 {
		var v any
		if json.Unmarshal(out, &v) == nil {
			if pretty, e := json.MarshalIndent(v, "", "  "); e == nil {
				os.Stdout.Write(pretty)
				os.Stdout.Write([]byte("\n"))
			} else {
				os.Stdout.Write(out)
			}
		} else {
			os.Stdout.Write(out)
		}
	}
	if err == nil {
		return 0
	}
	if ee, ok := err.(*exec.ExitError); ok {
		if st, ok := ee.Sys().(syscall.WaitStatus); ok {
			return st.ExitStatus()
		}
	}
	fmt.Fprintln(os.Stderr, err)
	return 1
}

func printCurlHelp(args []string) {
	cmd := exec.Command("curl", args...)
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	_ = cmd.Run()
	text := out.String()
	lines := strings.Split(text, "\n")
	if len(lines) > 0 && strings.HasPrefix(lines[0], "Usage: curl ") {
		lines[0] = usage
	}
	fmt.Print(strings.Join(lines, "\n"))
}
