module curlie-reimpl

go 1.21
