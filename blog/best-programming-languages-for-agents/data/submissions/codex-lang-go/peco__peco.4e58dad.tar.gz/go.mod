module peco-reimpl

go 1.21
