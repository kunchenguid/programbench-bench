package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

const helpText = `
Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
`

type options struct {
	query           string
	rcfile          string
	bufferSize      int
	nullMode        bool
	initialIndex    int
	initialFilter   string
	prompt          string
	layout          string
	selectOne       bool
	exitZero        bool
	selectAll       bool
	onCancel        string
	selectionPrefix string
	execCommand     string
	printQuery      bool
	ansi            bool
	height          string
	file            string
}

type record struct {
	display string
	output  string
}

func main() {
	opts, showHelp, showVersion, err := parseArgs(os.Args[1:])
	if showHelp {
		fmt.Print(helpText)
		return
	}
	if showVersion {
		fmt.Println("peco version v0.5.11 (built with go1.25.0)")
		return
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		if strings.Contains(err.Error(), "unknown flag") || strings.Contains(err.Error(), "invalid argument for flag") {
			fmt.Fprint(os.Stderr, helpText)
			fmt.Fprintf(os.Stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: %v\n", err)
		} else {
			fmt.Fprintf(os.Stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: %v\n", err)
		}
		os.Exit(1)
	}
	if err := validateOptions(opts); err != nil {
		fmt.Fprintln(os.Stderr, "Error: failed to setup peco:", err)
		os.Exit(1)
	}

	recs, err := readInput(opts)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error: failed to setup input source:", err)
		os.Exit(1)
	}
	if opts.bufferSize > 0 && len(recs) > opts.bufferSize {
		recs = recs[len(recs)-opts.bufferSize:]
	}

	matches, err := applyQuery(recs, opts.query, opts.initialFilter, opts.ansi)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error: failed to filter input:", err)
		os.Exit(1)
	}
	if opts.exitZero && len(recs) == 0 {
		os.Exit(1)
	}

	switch {
	case opts.selectAll:
		if opts.printQuery {
			fmt.Println(opts.query)
		}
		if opts.execCommand != "" {
			if err := runExec(opts.execCommand, matches); err != nil {
				fmt.Fprintln(os.Stderr, "Error:", err)
				os.Exit(1)
			}
			return
		}
		writeRecords(os.Stdout, matches)
		return
	case opts.selectOne && len(matches) == 1:
		if opts.printQuery {
			fmt.Println(opts.query)
		}
		writeRecords(os.Stdout, matches)
		return
	}

	if len(matches) > 0 {
		idx := opts.initialIndex
		if idx < 0 || idx >= len(matches) {
			idx = 0
		}
		if opts.printQuery {
			fmt.Println(opts.query)
		}
		writeRecords(os.Stdout, matches[idx:idx+1])
		return
	}
	if opts.printQuery {
		fmt.Println(opts.query)
	}
}

func parseArgs(args []string) (options, bool, bool, error) {
	opts := options{initialFilter: "IgnoreCase", layout: "top-down", onCancel: "success", initialIndex: 0, bufferSize: 0}
	var files []string
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--" {
			files = append(files, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(arg, "-") || arg == "-" {
			files = append(files, arg)
			continue
		}
		name, value, hasValue := splitFlag(arg)
		needValue := func() (string, error) {
			if hasValue {
				return value, nil
			}
			if i+1 >= len(args) {
				return "", fmt.Errorf("missing argument for flag `%s'", name)
			}
			i++
			return args[i], nil
		}
		switch name {
		case "-h", "--help":
			return opts, true, false, nil
		case "--version":
			return opts, false, true, nil
		case "--query":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.query = v
		case "--rcfile":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.rcfile = v
		case "-b", "--buffer-size":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return opts, false, false, fmt.Errorf("invalid argument for flag `-b, --buffer-size' (expected int): strconv.ParseInt: parsing %q: invalid syntax", v)
			}
			opts.bufferSize = n
		case "--null":
			opts.nullMode = true
		case "--initial-index":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return opts, false, false, fmt.Errorf("invalid argument for flag `--initial-index' (expected int): strconv.ParseInt: parsing %q: invalid syntax", v)
			}
			opts.initialIndex = n
		case "--initial-filter":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.initialFilter = v
		case "--prompt":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.prompt = v
		case "--layout":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.layout = v
		case "--select-1":
			opts.selectOne = true
		case "--exit-0":
			opts.exitZero = true
		case "--select-all":
			opts.selectAll = true
		case "--on-cancel":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.onCancel = v
		case "--selection-prefix":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.selectionPrefix = v
		case "--exec":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.execCommand = v
		case "--print-query":
			opts.printQuery = true
		case "--ansi":
			opts.ansi = true
		case "--height":
			v, err := needValue()
			if err != nil {
				return opts, false, false, err
			}
			opts.height = v
		default:
			return opts, false, false, fmt.Errorf("unknown flag `%s'", strings.TrimLeft(name, "-"))
		}
	}
	if len(files) > 0 {
		opts.file = files[0]
	}
	return opts, false, false, nil
}

func splitFlag(arg string) (string, string, bool) {
	if eq := strings.IndexByte(arg, '='); eq >= 0 {
		return arg[:eq], arg[eq+1:], true
	}
	return arg, "", false
}

func validateOptions(opts options) error {
	switch opts.layout {
	case "top-down", "bottom-up", "top-down-query-bottom":
	default:
		return fmt.Errorf("failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '%s'", opts.layout)
	}
	switch opts.initialFilter {
	case "IgnoreCase", "CaseSensitive", "SmartCase", "IRegexp", "Regexp", "Fuzzy":
	default:
		return errors.New("failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found")
	}
	if opts.onCancel != "success" && opts.onCancel != "error" {
		return fmt.Errorf("failed to apply configuration: invalid --on-cancel value: invalid OnCancel value %q: must be \"success\" or \"error\"", opts.onCancel)
	}
	return nil
}

func readInput(opts options) ([]record, error) {
	var r io.Reader
	if opts.file != "" {
		f, err := os.Open(opts.file)
		if err != nil {
			return nil, fmt.Errorf("failed to open file for input: %w", err)
		}
		defer f.Close()
		r = f
	} else {
		r = os.Stdin
	}
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, err
	}
	data = bytes.TrimSuffix(data, []byte{'\n'})
	if len(data) == 0 {
		return nil, nil
	}
	parts := bytes.Split(data, []byte{'\n'})
	recs := make([]record, 0, len(parts))
	for _, p := range parts {
		if opts.nullMode {
			if idx := bytes.IndexByte(p, 0); idx >= 0 {
				recs = append(recs, record{display: string(p[:idx]), output: string(p[idx+1:])})
			} else {
				recs = append(recs, record{display: string(p), output: string(p)})
			}
		} else {
			s := string(p)
			recs = append(recs, record{display: s, output: s})
		}
	}
	return recs, nil
}

func writeRecords(w io.Writer, recs []record) {
	bw := bufio.NewWriter(w)
	for _, rec := range recs {
		fmt.Fprintln(bw, rec.output)
	}
	bw.Flush()
}

type term struct {
	raw     string
	pattern string
	neg     bool
}

func parseQuery(q string) []term {
	fields := strings.Fields(q)
	terms := make([]term, 0, len(fields))
	for _, f := range fields {
		t := term{raw: f, pattern: f}
		if f == "-" {
			t.pattern = "-"
		} else if strings.HasPrefix(f, `\-`) {
			t.pattern = f[1:]
		} else if strings.HasPrefix(f, "-") && len(f) > 1 {
			t.neg = true
			t.pattern = f[1:]
		}
		terms = append(terms, t)
	}
	return terms
}

func applyQuery(recs []record, query, filter string, stripANSI bool) ([]record, error) {
	if query == "" {
		return recs, nil
	}
	terms := parseQuery(query)
	out := make([]record, 0, len(recs))
	for _, rec := range recs {
		text := rec.display
		if stripANSI {
			text = stripSGR(text)
		}
		ok, err := matchAll(text, terms, filter)
		if err != nil {
			return nil, err
		}
		if ok {
			out = append(out, rec)
		}
	}
	return out, nil
}

func matchAll(text string, terms []term, filter string) (bool, error) {
	for _, t := range terms {
		ok, err := matchOne(text, t.pattern, filter, terms)
		if err != nil {
			return false, err
		}
		if t.neg {
			if ok {
				return false, nil
			}
		} else if !ok {
			return false, nil
		}
	}
	return true, nil
}

func matchOne(text, pat, filter string, all []term) (bool, error) {
	switch filter {
	case "CaseSensitive":
		return strings.Contains(text, pat), nil
	case "SmartCase":
		if allLower(all) {
			return strings.Contains(strings.ToLower(text), strings.ToLower(pat)), nil
		}
		return strings.Contains(text, pat), nil
	case "Regexp":
		return regexp.MatchString(pat, text)
	case "IRegexp":
		return regexp.MatchString("(?i)"+pat, text)
	case "Fuzzy":
		caseSensitive := !allLower(all)
		return fuzzyContains(text, pat, caseSensitive), nil
	default:
		return strings.Contains(strings.ToLower(text), strings.ToLower(pat)), nil
	}
}

func allLower(terms []term) bool {
	for _, t := range terms {
		for _, r := range t.pattern {
			if unicode.IsLetter(r) && !unicode.IsLower(r) {
				return false
			}
		}
	}
	return true
}

func fuzzyContains(text, pat string, caseSensitive bool) bool {
	if !caseSensitive {
		text = strings.ToLower(text)
		pat = strings.ToLower(pat)
	}
	j := 0
	for _, r := range text {
		if j < len([]rune(pat)) && r == []rune(pat)[j] {
			j++
		}
	}
	return j == len([]rune(pat))
}

var sgrRE = regexp.MustCompile(`\x1b\[[0-9;]*m`)

func stripSGR(s string) string {
	return sgrRE.ReplaceAllString(s, "")
}

func runExec(command string, recs []record) error {
	cmd := exec.Command("/bin/sh", "-c", command)
	var in bytes.Buffer
	for _, rec := range recs {
		in.WriteString(rec.output)
		in.WriteByte('\n')
	}
	cmd.Stdin = &in
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}
