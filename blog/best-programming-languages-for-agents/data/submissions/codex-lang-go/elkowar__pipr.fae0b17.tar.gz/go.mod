module pipr-reimpl

go 1.21
