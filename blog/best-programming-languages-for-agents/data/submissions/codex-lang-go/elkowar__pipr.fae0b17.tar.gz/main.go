package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strings"
	"unicode/utf8"
)

const helpText = `Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
`

const configReference = `
#  ____  _
# |  _ \(_)_ __  _ __       .________.
# | |_) | | '_ \| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"

`

type options struct {
	def             string
	outFile         string
	inFile          string
	raw             bool
	noIsolation     bool
	help            bool
	configReference bool
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintf(os.Stderr, "./executable: %s\n", err)
		os.Exit(1)
	}
	if opts.help {
		fmt.Print(helpText)
		return
	}
	if opts.configReference {
		fmt.Print(configReference)
		return
	}
	if !opts.noIsolation {
		if _, err := exec.LookPath("bwrap"); err != nil {
			fmt.Println("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode")
			os.Exit(1)
		}
	}

	cmdText := opts.def
	if opts.inFile != "" {
		b, err := os.ReadFile(opts.inFile)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %s\n", osErrorText(err))
			os.Exit(1)
		}
		cmdText = string(b)
	}

	if !isTerminal(os.Stdin) {
		fmt.Fprint(os.Stderr, "\x1b[?1049h")
		fmt.Fprintln(os.Stderr, "Error: No such device or address (os error 6)")
		os.Exit(1)
	}

	final, err := runTerminal(cmdText)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %s\n", err)
		os.Exit(1)
	}
	if !opts.raw {
		final = strings.Join(strings.FieldsFunc(final, func(r rune) bool { return r == '\n' || r == '\r' }), " ")
	}
	if opts.outFile != "" {
		if err := os.WriteFile(opts.outFile, []byte(final), 0644); err != nil {
			fmt.Fprintf(os.Stderr, "Error: %s\n", osErrorText(err))
			os.Exit(1)
		}
	} else if final != "" {
		fmt.Print(final)
	}
}

func parseArgs(args []string) (options, error) {
	var opts options
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--" {
			continue
		}
		if strings.HasPrefix(arg, "--") {
			name, val, hasVal := strings.Cut(arg[2:], "=")
			switch name {
			case "default":
				if !hasVal {
					i++
					if i >= len(args) {
						return opts, errors.New("Argument to option 'default' missing")
					}
					val = args[i]
				}
				opts.def = val
			case "out-file":
				if !hasVal {
					i++
					if i >= len(args) {
						return opts, errors.New("Argument to option 'out-file' missing")
					}
					val = args[i]
				}
				opts.outFile = val
			case "in-file":
				if !hasVal {
					i++
					if i >= len(args) {
						return opts, errors.New("Argument to option 'in-file' missing")
					}
					val = args[i]
				}
				opts.inFile = val
			case "config-reference":
				opts.configReference = true
			case "raw-mode":
				opts.raw = true
			case "no-isolation":
				opts.noIsolation = true
			case "help":
				opts.help = true
			default:
				return opts, fmt.Errorf("Unrecognized option: '%s'", name)
			}
			continue
		}
		if strings.HasPrefix(arg, "-") && arg != "-" {
			shorts := arg[1:]
			for j := 0; j < len(shorts); j++ {
				ch := shorts[j]
				switch ch {
				case 'd', 'o':
					var val string
					if j+1 < len(shorts) {
						val = shorts[j+1:]
						j = len(shorts)
					} else {
						i++
						if i >= len(args) {
							return opts, fmt.Errorf("Argument to option '%c' missing", ch)
						}
						val = args[i]
					}
					if ch == 'd' {
						opts.def = val
					} else {
						opts.outFile = val
					}
				case 'r':
					opts.raw = true
				case 'h':
					opts.help = true
				default:
					return opts, fmt.Errorf("Unrecognized option: '%c'", ch)
				}
			}
		}
	}
	return opts, nil
}

func isTerminal(f *os.File) bool {
	cmd := exec.Command("test", "-t", fmt.Sprint(f.Fd()))
	cmd.Stdin = f
	return cmd.Run() == nil
}

func runTerminal(initial string) (string, error) {
	restore, _ := setRaw()
	if restore != nil {
		defer restore()
	}
	fmt.Print("\x1b[?1049h")
	defer fmt.Print("\x1b[?1049l")

	text := initial
	output := ""
	draw(text, output)

	reader := bufio.NewReader(os.Stdin)
	for {
		b, err := reader.ReadByte()
		if err != nil {
			if err == io.EOF {
				return text, nil
			}
			return text, err
		}
		switch b {
		case 3, 4, 27: // Ctrl-C, Ctrl-D, Escape
			return text, nil
		case '\r', '\n':
			output = evaluate(text)
			draw(text, output)
		case 127, 8:
			if text != "" {
				_, size := utf8.DecodeLastRuneInString(text)
				text = text[:len(text)-size]
				draw(text, output)
			}
		case 12:
			draw(text, output)
		default:
			if b >= 32 || b == '\t' {
				text += string([]byte{b})
				draw(text, output)
			}
		}
	}
}

func setRaw() (func(), error) {
	save := exec.Command("stty", "-g")
	save.Stdin = os.Stdin
	old, err := save.Output()
	if err != nil {
		return nil, err
	}
	raw := exec.Command("stty", "raw", "-echo")
	raw.Stdin = os.Stdin
	if err := raw.Run(); err != nil {
		return nil, err
	}
	return func() {
		restore := exec.Command("stty", string(bytes.TrimSpace(old)))
		restore.Stdin = os.Stdin
		_ = restore.Run()
	}, nil
}

func draw(text, output string) {
	fmt.Print("\x1b[2J\x1b[H")
	fmt.Println("┌ Command [Autoeval] ───────────────────────────────────────────────────────┐")
	for _, line := range splitLines(text) {
		fmt.Printf("│ %-74.74s │\n", line)
	}
	fmt.Println("└────────────────────────────────────────────────────────────────────────────┘")
	fmt.Println("┌ Output [+] ────────────────────────────────────────────────────────────────┐")
	lines := splitLines(output)
	if len(lines) == 0 {
		lines = []string{""}
	}
	for i := 0; i < len(lines) && i < 12; i++ {
		fmt.Printf("│ %-74.74s │\n", lines[i])
	}
	fmt.Println("└──────────────────────────────────────────────────────────────────Help: F1─┘")
}

func splitLines(s string) []string {
	s = strings.TrimRight(s, "\n")
	if s == "" {
		return []string{""}
	}
	return strings.Split(s, "\n")
}

func evaluate(command string) string {
	if strings.TrimSpace(command) == "" {
		return ""
	}
	ctx := exec.Command("bash", "-c", command)
	var out bytes.Buffer
	ctx.Stdout = &out
	ctx.Stderr = &out
	_ = ctx.Run()
	return out.String()
}

func osErrorText(err error) string {
	if pe, ok := err.(*os.PathError); ok {
		return pe.Err.Error()
	}
	return err.Error()
}
