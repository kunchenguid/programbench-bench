package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

const reset = "\x1b[0m"

var hunkRE = regexp.MustCompile(`^@@ -([0-9]+)(?:,([0-9]+))? \+([0-9]+)(?:,([0-9]+))? @@`)

type style struct {
	none  bool
	codes []string
}

func (s style) on() string {
	if s.none || len(s.codes) == 0 {
		return ""
	}
	return strings.Join(s.codes, "")
}

type config struct {
	colors      map[string]style
	lineNumbers bool
	lineStyle   string
}

type diffLine struct {
	kind byte
	text string
	old  int
	new  int
}

func main() {
	cfg, err, code := parseArgs(os.Args[1:])
	if err != "" {
		fmt.Fprintln(os.Stderr, err)
		if code == 2 {
			printShortHelp(os.Stderr)
		}
		os.Exit(code)
	}
	if err := run(os.Stdin, os.Stdout, cfg); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func defaultConfig() config {
	return config{
		colors: map[string]style{
			"added":          {codes: []string{"\x1b[32m"}},
			"removed":        {codes: []string{"\x1b[31m"}},
			"refine-added":   {codes: []string{"\x1b[1m", "\x1b[38;2;255;255;255m", "\x1b[42m"}},
			"refine-removed": {codes: []string{"\x1b[1m", "\x1b[38;2;255;255;255m", "\x1b[41m"}},
		},
		lineStyle: "compact",
	}
}

func parseArgs(args []string) (config, string, int) {
	cfg := defaultConfig()
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printLongHelp(os.Stdout)
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("diffr 0.1.5")
			os.Exit(0)
		case "--colors":
			if i+1 >= len(args) {
				return cfg, "missing color spec", 255
			}
			i++
			if err := applyColorSpec(&cfg, args[i]); err != nil {
				return cfg, err.Error(), 255
			}
		case "--line-numbers":
			cfg.lineNumbers = true
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				n := args[i+1]
				if n != "compact" && n != "aligned" && n != "fixed" {
					return cfg, fmt.Sprintf("unexpected line number style: got '%s', expected aligned|compact|fixed", n), 255
				}
				cfg.lineStyle = n
				i++
			}
		default:
			if strings.HasPrefix(a, "--colors=") {
				if err := applyColorSpec(&cfg, strings.TrimPrefix(a, "--colors=")); err != nil {
					return cfg, err.Error(), 255
				}
			} else if strings.HasPrefix(a, "--line-numbers=") {
				cfg.lineNumbers = true
				n := strings.TrimPrefix(a, "--line-numbers=")
				if n != "compact" && n != "aligned" && n != "fixed" {
					return cfg, fmt.Sprintf("unexpected line number style: got '%s', expected aligned|compact|fixed", n), 255
				}
				cfg.lineStyle = n
			} else {
				return cfg, fmt.Sprintf("bad argument: '%s'", a), 2
			}
		}
	}
	return cfg, "", 0
}

func applyColorSpec(cfg *config, spec string) error {
	parts := strings.Split(spec, ":")
	if len(parts) < 2 {
		return fmt.Errorf("unexpected face name: got '%s', expected added|refine-added|removed|refine-removed", spec)
	}
	face := parts[0]
	if _, ok := cfg.colors[face]; !ok {
		return fmt.Errorf("unexpected face name: got '%s', expected added|refine-added|removed|refine-removed", face)
	}
	st := cfg.colors[face]
	for i := 1; i < len(parts); i++ {
		p := parts[i]
		switch p {
		case "none":
			st = style{none: true}
		case "bold":
			st.none = false
			st.codes = append(st.codes, "\x1b[1m")
		case "nobold":
			st.none = false
			st.codes = append(st.codes, "\x1b[22m")
		case "italic":
			st.none = false
			st.codes = append(st.codes, "\x1b[3m")
		case "noitalic":
			st.none = false
			st.codes = append(st.codes, "\x1b[23m")
		case "underline":
			st.none = false
			st.codes = append(st.codes, "\x1b[4m")
		case "nounderline":
			st.none = false
			st.codes = append(st.codes, "\x1b[24m")
		case "intense":
			st.none = false
			st.codes = append(st.codes, "\x1b[1m")
		case "nointense":
			st.none = false
			st.codes = append(st.codes, "\x1b[22m")
		case "foreground", "background":
			if i+1 >= len(parts) {
				return fmt.Errorf("missing color")
			}
			code, err := colorCode(p == "foreground", parts[i+1])
			if err != nil {
				return err
			}
			st.none = false
			st.codes = append(st.codes, code)
			i++
		default:
			return fmt.Errorf("unexpected attribute: %s", p)
		}
	}
	cfg.colors[face] = st
	return nil
}

func colorCode(fg bool, c string) (string, error) {
	base := 48
	if fg {
		base = 38
	}
	if c == "none" {
		if fg {
			return "\x1b[39m", nil
		}
		return "\x1b[49m", nil
	}
	names := map[string]int{"black": 0, "red": 1, "green": 2, "yellow": 3, "blue": 4, "magenta": 5, "cyan": 6, "white": 7}
	if v, ok := names[c]; ok {
		if fg {
			return fmt.Sprintf("\x1b[%dm", 30+v), nil
		}
		return fmt.Sprintf("\x1b[%dm", 40+v), nil
	}
	if strings.Contains(c, ",") {
		ps := strings.Split(c, ",")
		if len(ps) != 3 {
			return "", fmt.Errorf("invalid color: %s", c)
		}
		vals := make([]int, 3)
		for i, p := range ps {
			n, err := strconv.Atoi(p)
			if err != nil || n < 0 || n > 255 {
				return "", fmt.Errorf("invalid color: %s", c)
			}
			vals[i] = n
		}
		return fmt.Sprintf("\x1b[%d;2;%d;%d;%dm", base, vals[0], vals[1], vals[2]), nil
	}
	n, err := strconv.Atoi(c)
	if err != nil || n < 0 || n > 255 {
		return "", fmt.Errorf("invalid color: %s", c)
	}
	return fmt.Sprintf("\x1b[%d;5;%dm", base, n), nil
}

func run(in io.Reader, out io.Writer, cfg config) error {
	sc := bufio.NewScanner(in)
	sc.Buffer(make([]byte, 1024), 1024*1024*16)
	w := bufio.NewWriter(out)
	defer w.Flush()

	inHunk := false
	oldNo, newNo := 0, 0
	var block []diffLine
	flush := func() {
		if len(block) == 0 {
			return
		}
		renderBlock(w, cfg, block)
		block = nil
	}

	for sc.Scan() {
		line := sc.Text()
		if m := hunkRE.FindStringSubmatch(line); m != nil {
			flush()
			inHunk = true
			oldNo, _ = strconv.Atoi(m[1])
			newNo, _ = strconv.Atoi(m[3])
			fmt.Fprintln(w, reset+line+reset)
			continue
		}
		if !inHunk {
			fmt.Fprintln(w, reset+line+reset)
			continue
		}
		if strings.HasPrefix(line, `\ No newline at end of file`) {
			flush()
			fmt.Fprintln(w, reset+line+reset)
			continue
		}
		if line == "" {
			flush()
			fmt.Fprintln(w, reset+line+reset)
			continue
		}
		switch line[0] {
		case '-':
			block = append(block, diffLine{kind: '-', text: line[1:], old: oldNo})
			oldNo++
		case '+':
			block = append(block, diffLine{kind: '+', text: line[1:], new: newNo})
			newNo++
		case ' ':
			flush()
			renderContext(w, cfg, line[1:], oldNo, newNo)
			oldNo++
			newNo++
		default:
			flush()
			inHunk = false
			fmt.Fprintln(w, reset+line+reset)
		}
	}
	flush()
	return sc.Err()
}

func renderContext(w io.Writer, cfg config, text string, oldNo, newNo int) {
	if cfg.lineNumbers {
		fmt.Fprint(w, numberPrefix(cfg, ' ', oldNo, newNo))
	}
	fmt.Fprintln(w, reset+" "+text+reset)
}

func renderBlock(w io.Writer, cfg config, b []diffLine) {
	var dels, adds []int
	for i, l := range b {
		if l.kind == '-' {
			dels = append(dels, i)
		} else {
			adds = append(adds, i)
		}
	}
	pairs := min(len(dels), len(adds))
	refOld := map[int][]bool{}
	refNew := map[int][]bool{}
	for i := 0; i < pairs; i++ {
		a := b[dels[i]].text
		c := b[adds[i]].text
		ro, rn := refineMasks(a, c)
		refOld[dels[i]] = ro
		refNew[adds[i]] = rn
	}
	for i, l := range b {
		if l.kind == '-' {
			renderChanged(w, cfg, l, refOld[i])
		} else {
			renderChanged(w, cfg, l, refNew[i])
		}
	}
}

func renderChanged(w io.Writer, cfg config, l diffLine, mask []bool) {
	face := "added"
	ref := "refine-added"
	if l.kind == '-' {
		face = "removed"
		ref = "refine-removed"
	}
	if cfg.lineNumbers {
		pfx := numberPrefix(cfg, l.kind, l.old, l.new)
		if cfg.lineStyle == "aligned" {
			pfx = strings.TrimSuffix(pfx, "\t")
			fmt.Fprint(w, reset+cfg.colors[face].on()+pfx+reset+"\t")
		} else {
			fmt.Fprint(w, reset+cfg.colors[face].on()+pfx+reset)
		}
	}
	fmt.Fprint(w, reset+cfg.colors[face].on()+string(l.kind)+reset)
	writeStyledText(w, l.text, cfg.colors[face], cfg.colors[ref], mask)
	fmt.Fprintln(w)
}

func writeStyledText(w io.Writer, text string, base, ref style, mask []bool) {
	if len(mask) != len(text) {
		mask = nil
	}
	i := 0
	for i < len(text) {
		hi := false
		if mask != nil {
			hi = mask[i]
		}
		j := i + 1
		for j < len(text) {
			h := false
			if mask != nil {
				h = mask[j]
			}
			if h != hi {
				break
			}
			j++
		}
		st := base
		if hi {
			st = ref
		}
		fmt.Fprint(w, reset+st.on()+text[i:j]+reset)
		i = j
	}
	if text == "" || (len(mask) > 0 && mask[len(mask)-1]) {
		fmt.Fprint(w, reset+base.on()+reset)
	}
}

func numberPrefix(cfg config, kind byte, oldNo, newNo int) string {
	oldS, newS := "", ""
	switch kind {
	case '-':
		oldS = strconv.Itoa(oldNo)
		newS = ""
	case '+':
		oldS = ""
		newS = strconv.Itoa(newNo)
	default:
		oldS = strconv.Itoa(oldNo)
		newS = strconv.Itoa(newNo)
	}
	if len(oldS) < 2 {
		oldS = strings.Repeat(" ", 2-len(oldS)) + oldS
	}
	if len(newS) < 2 {
		newS = strings.Repeat(" ", 2-len(newS)) + newS
	}
	sep := ""
	if cfg.lineStyle == "aligned" {
		sep = "\t"
	}
	return oldS + " " + newS + sep
}

type token struct {
	s, e int
	val  string
}

func refineMasks(a, b string) ([]bool, []bool) {
	at, bt := tokens(a), tokens(b)
	ma := make([]bool, len(a))
	mb := make([]bool, len(b))
	if len(at) == 0 && len(bt) == 0 {
		return ma, mb
	}
	dp := make([][]int, len(at)+1)
	for i := range dp {
		dp[i] = make([]int, len(bt)+1)
	}
	for i := len(at) - 1; i >= 0; i-- {
		for j := len(bt) - 1; j >= 0; j-- {
			if at[i].val == bt[j].val {
				dp[i][j] = dp[i+1][j+1] + 1
			} else if dp[i+1][j] >= dp[i][j+1] {
				dp[i][j] = dp[i+1][j]
			} else {
				dp[i][j] = dp[i][j+1]
			}
		}
	}
	keepA := make([]bool, len(at))
	keepB := make([]bool, len(bt))
	var anchors [][2]int
	for i, j := 0, 0; i < len(at) && j < len(bt); {
		if at[i].val == bt[j].val {
			keepA[i], keepB[j] = true, true
			anchors = append(anchors, [2]int{i, j})
			i++
			j++
		} else if dp[i+1][j] >= dp[i][j+1] {
			i++
		} else {
			j++
		}
	}
	for i, t := range at {
		if !keepA[i] {
			for k := t.s; k < t.e && k < len(ma); k++ {
				ma[k] = true
			}
		}
	}
	for i, t := range bt {
		if !keepB[i] {
			for k := t.s; k < t.e && k < len(mb); k++ {
				mb[k] = true
			}
		}
	}
	prevA, prevB := -1, -1
	for _, an := range append(anchors, [2]int{len(at), len(bt)}) {
		a0, a1 := prevA+1, an[0]
		b0, b1 := prevB+1, an[1]
		if a0 == a1 && b0 < b1 {
			end := len(b)
			if b1 < len(bt) {
				end = bt[b1].s
			}
			for k := bt[b1-1].e; k < end && k < len(mb); k++ {
				mb[k] = true
			}
		}
		if b0 == b1 && a0 < a1 {
			end := len(a)
			if a1 < len(at) {
				end = at[a1].s
			}
			for k := at[a1-1].e; k < end && k < len(ma); k++ {
				ma[k] = true
			}
		}
		prevA, prevB = an[0], an[1]
	}
	return ma, mb
}

func tokens(s string) []token {
	var out []token
	for i := 0; i < len(s); {
		r, sz := rune(s[i]), 1
		if r >= 0x80 {
			r, sz = utf8Rune(s[i:])
		}
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' {
			start := i
			for i < len(s) {
				r2, sz2 := rune(s[i]), 1
				if r2 >= 0x80 {
					r2, sz2 = utf8Rune(s[i:])
				}
				if !(unicode.IsLetter(r2) || unicode.IsDigit(r2) || r2 == '_') {
					break
				}
				i += sz2
			}
			out = append(out, token{start, i, s[start:i]})
		} else if unicode.IsSpace(r) {
			i += sz
		} else {
			out = append(out, token{i, i + sz, s[i : i+sz]})
			i += sz
		}
	}
	return out
}

func utf8Rune(s string) (rune, int) {
	for i := 1; i <= len(s) && i <= 4; i++ {
		r := []rune(s[:i])
		if len(r) == 1 && string(r) == s[:i] {
			return r[0], i
		}
	}
	return rune(s[0]), 1
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func printShortHelp(w io.Writer) {
	fmt.Fprint(w, `diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
`)
}

func printLongHelp(w io.Writer) {
	fmt.Fprint(w, `diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
`)
}
