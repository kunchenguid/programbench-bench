module diffr

go 1.21
