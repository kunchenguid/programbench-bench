package main

import (
	"errors"
	"fmt"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const version = "thokr 0.4.1"

type options struct {
	words      uint64
	secs       uint64
	sentences  uint64
	language   string
	prompt     string
	hasWords   bool
	hasSecs    bool
	hasSent    bool
	hasLang    bool
	hasPrompt  bool
	showHelp   bool
	showVer    bool
}

var commonWords = []string{
	"the", "of", "and", "to", "a", "in", "is", "you", "that", "it",
	"he", "was", "for", "on", "are", "with", "as", "I", "his", "they",
	"be", "at", "one", "have", "this", "from", "or", "had", "by", "hot",
	"but", "some", "what", "there", "we", "can", "out", "other", "were", "all",
	"your", "when", "up", "use", "word", "how", "said", "an", "each", "she",
	"which", "do", "their", "time", "if", "will", "way", "about", "many", "then",
	"them", "write", "would", "like", "so", "these", "her", "long", "make", "thing",
	"see", "him", "two", "has", "look", "more", "day", "could", "go", "come",
	"did", "my", "sound", "no", "most", "number", "who", "over", "know", "water",
	"than", "call", "first", "people", "may", "down", "side", "been", "now", "find",
	"any", "new", "work", "part", "take", "get", "place", "made", "live", "where",
	"after", "back", "little", "only", "round", "man", "year", "came", "show", "every",
	"good", "me", "give", "our", "under", "name", "very", "through", "just", "form",
	"much", "great", "think", "say", "help", "low", "line", "before", "turn", "cause",
	"same", "mean", "differ", "move", "right", "boy", "old", "too", "does", "tell",
	"sentence", "set", "three", "want", "air", "well", "also", "play", "small", "end",
	"put", "home", "read", "hand", "port", "large", "spell", "add", "even", "land",
	"here", "must", "big", "high", "such", "follow", "act", "why", "ask", "men",
	"change", "went", "light", "kind", "off", "need", "house", "picture", "try", "us",
	"again", "animal", "point", "mother", "world", "near", "build", "self", "earth", "father",
	"head", "stand", "own", "page", "should", "country", "found", "answer", "school", "grow",
	"study", "still", "learn", "plant", "cover", "food", "sun", "four", "thought", "let",
	"keep", "eye", "never", "last", "door", "between", "city", "tree", "cross", "since",
	"hard", "start", "might", "story", "saw", "far", "sea", "draw", "left", "late",
	"run", "don't", "while", "press", "close", "night", "real", "life", "few", "north",
}

func main() {
	opts, exit := parseArgs(os.Args[1:], filepath.Base(os.Args[0]))
	if exit >= 0 {
		os.Exit(exit)
	}
	if !isTTY(os.Stdin.Fd()) {
		fmt.Fprint(os.Stderr, "error: stdin must be a tty\n\nUSAGE:\n    thokr [OPTIONS]\n\nFor more information try --help\n")
		os.Exit(2)
	}
	prompt := opts.prompt
	if prompt == "" {
		prompt = makePrompt(opts)
	}
	if err := runTyping(prompt, opts.secs); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parseArgs(args []string, prog string) (options, int) {
	o := options{words: 15, language: "english"}
	for _, arg := range args {
		if arg == "-h" || arg == "--help" || strings.Contains(shortCluster(arg), "h") {
			fmt.Print(helpText(prog))
			return o, 0
		}
		if arg == "-V" || arg == "--version" || strings.Contains(shortCluster(arg), "V") {
			fmt.Println(version)
			return o, 0
		}
	}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--" {
			continue
		}
		name, val, hasInline := splitLong(arg)
		switch {
		case name == "--number-of-words" || strings.HasPrefix(arg, "-w"):
			v, ni, ok := valueFor(args, i, arg, name, val, hasInline, "--number-of-words", "<NUMBER_OF_WORDS>", prog)
			if !ok {
				return o, 2
			}
			if o.hasWords {
				duplicate("--number-of-words", "<NUMBER_OF_WORDS>", prog)
				return o, 2
			}
			n, ok := parseUintValue(v, "--number-of-words", "<NUMBER_OF_WORDS>")
			if !ok {
				return o, 2
			}
			o.words, o.hasWords, i = n, true, ni
		case name == "--number-of-secs" || strings.HasPrefix(arg, "-s"):
			v, ni, ok := valueFor(args, i, arg, name, val, hasInline, "--number-of-secs", "<NUMBER_OF_SECS>", prog)
			if !ok {
				return o, 2
			}
			if o.hasSecs {
				duplicate("--number-of-secs", "<NUMBER_OF_SECS>", prog)
				return o, 2
			}
			n, ok := parseUintValue(v, "--number-of-secs", "<NUMBER_OF_SECS>")
			if !ok {
				return o, 2
			}
			o.secs, o.hasSecs, i = n, true, ni
		case name == "--full-sentences" || strings.HasPrefix(arg, "-f"):
			v, ni, ok := valueFor(args, i, arg, name, val, hasInline, "--full-sentences", "<NUMBER_OF_SENTENCES>", prog)
			if !ok {
				return o, 2
			}
			if o.hasSent {
				duplicate("--full-sentences", "<NUMBER_OF_SENTENCES>", prog)
				return o, 2
			}
			n, ok := parseUintValue(v, "--full-sentences", "<NUMBER_OF_SENTENCES>")
			if !ok {
				return o, 2
			}
			o.sentences, o.hasSent, i = n, true, ni
		case name == "--prompt" || strings.HasPrefix(arg, "-p"):
			v, ni, ok := valueFor(args, i, arg, name, val, hasInline, "--prompt", "<PROMPT>", prog)
			if !ok {
				return o, 2
			}
			if o.hasPrompt {
				duplicate("--prompt", "<PROMPT>", prog)
				return o, 2
			}
			o.prompt, o.hasPrompt, i = v, true, ni
		case name == "--supported-language" || strings.HasPrefix(arg, "-l"):
			v, ni, ok := valueFor(args, i, arg, name, val, hasInline, "--supported-language", "<SUPPORTED_LANGUAGE>", prog)
			if !ok {
				return o, 2
			}
			if o.hasLang {
				duplicate("--supported-language", "<SUPPORTED_LANGUAGE>", prog)
				return o, 2
			}
			if v != "english" && v != "english1k" && v != "english10k" {
				fmt.Fprintf(os.Stderr, "error: %q isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]\n\nUSAGE:\n    %s --supported-language <SUPPORTED_LANGUAGE>\n\nFor more information try --help\n", v, prog)
				return o, 2
			}
			o.language, o.hasLang, i = v, true, ni
		case strings.HasPrefix(arg, "-"):
			fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\nUSAGE:\n    %s [OPTIONS]\n\nFor more information try --help\n", arg, arg, arg, prog)
			return o, 2
		default:
			fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    %s [OPTIONS]\n\nFor more information try --help\n", arg, prog)
			return o, 2
		}
	}
	return o, -1
}

func splitLong(arg string) (string, string, bool) {
	if strings.HasPrefix(arg, "--") {
		if idx := strings.IndexByte(arg, '='); idx >= 0 {
			return arg[:idx], arg[idx+1:], true
		}
		return arg, "", false
	}
	return arg, "", false
}

func shortCluster(arg string) string {
	if strings.HasPrefix(arg, "-") && !strings.HasPrefix(arg, "--") && len(arg) > 2 {
		return arg[1:]
	}
	return ""
}

func valueFor(args []string, i int, arg, name, inline string, hasInline bool, longName, meta, prog string) (string, int, bool) {
	if hasInline {
		return inline, i, true
	}
	if strings.HasPrefix(arg, "-") && !strings.HasPrefix(arg, "--") && len(arg) > 2 {
		return arg[2:], i, true
	}
	if i+1 >= len(args) {
		fmt.Fprintf(os.Stderr, "error: The argument '%s %s' requires a value but none was supplied\n\nUSAGE:\n    %s [OPTIONS]\n\nFor more information try --help\n", longName, meta, prog)
		return "", i, false
	}
	if strings.HasPrefix(args[i+1], "-") {
		unexpectedFlag(args[i+1], prog)
		return "", i, false
	}
	return args[i+1], i + 1, true
}

func duplicate(flag, meta, prog string) {
	fmt.Fprintf(os.Stderr, "error: The argument '%s %s' was provided more than once, but cannot be used multiple times\n\nUSAGE:\n    %s [OPTIONS]\n\nFor more information try --help\n", flag, meta, prog)
}

func unexpectedFlag(arg, prog string) {
	fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\nUSAGE:\n    %s [OPTIONS]\n\nFor more information try --help\n", arg, arg, arg, prog)
}

func parseUintValue(v, flag, meta string) (uint64, bool) {
	n, err := strconv.ParseUint(v, 10, 64)
	if err == nil {
		return n, true
	}
	msg := "invalid digit found in string"
	if errors.Is(err, strconv.ErrRange) {
		msg = "number too large to fit in target type"
	}
	fmt.Fprintf(os.Stderr, "error: Invalid value %q for '%s %s': %s\n\nFor more information try --help\n", v, flag, meta, msg)
	return 0, false
}

func helpText(prog string) string {
	return fmt.Sprintf(`thokr 0.4.1
sleek typing tui with visualized results and historical logging

USAGE:
    %s [OPTIONS]

OPTIONS:
    -f, --full-sentences <NUMBER_OF_SENTENCES>
            number of sentences to use in test

    -h, --help
            Print help information

    -l, --supported-language <SUPPORTED_LANGUAGE>
            language to pull words from [default: english] [possible values: english, english1k,
            english10k]

    -p, --prompt <PROMPT>
            custom prompt to use

    -s, --number-of-secs <NUMBER_OF_SECS>
            number of seconds to run test

    -V, --version
            Print version information

    -w, --number-of-words <NUMBER_OF_WORDS>
            number of words to use in test [default: 15]
`, prog)
}

func makePrompt(o options) string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	if o.sentences > 0 {
		var ss []string
		for s := uint64(0); s < o.sentences; s++ {
			count := 7 + r.Intn(8)
			words := pickWords(r, uint64(count))
			if len(words[0]) > 0 {
				words[0] = strings.ToUpper(words[0][:1]) + words[0][1:]
			}
			ss = append(ss, strings.Join(words, " ")+".")
		}
		return strings.Join(ss, " ")
	}
	return strings.Join(pickWords(r, o.words), " ")
}

func pickWords(r *rand.Rand, n uint64) []string {
	if n > math.MaxInt32 {
		n = math.MaxInt32
	}
	out := make([]string, int(n))
	for i := range out {
		out[i] = commonWords[r.Intn(len(commonWords))]
	}
	return out
}

func runTyping(prompt string, seconds uint64) error {
	old, err := makeRaw(os.Stdin.Fd())
	if err == nil {
		defer restore(os.Stdin.Fd(), old)
	}
	start := time.Now()
	deadline := time.Time{}
	if seconds > 0 {
		deadline = start.Add(time.Duration(seconds) * time.Second)
	}
	fmt.Print("\x1b[2J\x1b[H")
	render(prompt, 0, start, seconds)
	pos := 0
	for pos < len(prompt) {
		if !deadline.IsZero() && time.Now().After(deadline) {
			break
		}
		ch, ok, err := readByteWithTimeout()
		if err != nil {
			return nil
		}
		if !ok {
			render(prompt, pos, start, seconds)
			continue
		}
		switch ch {
		case 3, 4, 27:
			fmt.Print("\x1b[?25h\x1b[0m\r\n")
			return nil
		case 8, 127:
			if pos > 0 {
				pos--
			}
		case '\r', '\n':
		default:
			if pos < len(prompt) && ch == prompt[pos] {
				pos++
			}
		}
		render(prompt, pos, start, seconds)
	}
	elapsed := time.Since(start).Seconds()
	if elapsed <= 0 {
		elapsed = 0.01
	}
	typed := prompt[:pos]
	wpm := (float64(len(typed)) / 5.0) / (elapsed / 60.0)
	fmt.Printf("\r\n\r\nwpm: %.0f | accuracy: 100%% | elapsed: %.1fs\r\n", wpm, elapsed)
	appendLog(wpm, elapsed, len(typed))
	return nil
}

func render(prompt string, pos int, start time.Time, seconds uint64) {
	elapsed := time.Since(start).Seconds()
	fmt.Print("\x1b[H\x1b[?25l")
	fmt.Println("thokr")
	if seconds > 0 {
		remaining := float64(seconds) - elapsed
		if remaining < 0 {
			remaining = 0
		}
		fmt.Printf("time: %.0fs\r\n\r\n", remaining)
	} else {
		fmt.Printf("time: %.1fs\r\n\r\n", elapsed)
	}
	fmt.Print("\x1b[32m")
	fmt.Print(prompt[:pos])
	fmt.Print("\x1b[0m")
	if pos < len(prompt) {
		fmt.Print(prompt[pos:])
	}
	fmt.Print("\x1b[J")
}

func appendLog(wpm, elapsed float64, chars int) {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return
	}
	dir := filepath.Join(home, ".config", "thokr")
	if os.MkdirAll(dir, 0755) != nil {
		return
	}
	f, err := os.OpenFile(filepath.Join(dir, "log.csv"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s,%.0f,%.2f,%d\n", time.Now().Format(time.RFC3339), wpm, elapsed, chars)
}

type termios syscall.Termios

func isTTY(fd uintptr) bool {
	var t termios
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&t)))
	return errno == 0
}

func makeRaw(fd uintptr) (*termios, error) {
	var old termios
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&old)))
	if errno != 0 {
		return nil, errno
	}
	raw := old
	raw.Iflag &^= syscall.IGNBRK | syscall.BRKINT | syscall.PARMRK | syscall.ISTRIP | syscall.INLCR | syscall.IGNCR | syscall.ICRNL | syscall.IXON
	raw.Oflag &^= syscall.OPOST
	raw.Lflag &^= syscall.ECHO | syscall.ECHONL | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
	raw.Cflag &^= syscall.CSIZE | syscall.PARENB
	raw.Cflag |= syscall.CS8
	raw.Cc[syscall.VMIN] = 0
	raw.Cc[syscall.VTIME] = 1
	_, _, errno = syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(&raw)))
	if errno != 0 {
		return nil, errno
	}
	return &old, nil
}

func readByteWithTimeout() (byte, bool, error) {
	var b [1]byte
	n, err := os.Stdin.Read(b[:])
	if n == 1 {
		return b[0], true, nil
	}
	if err != nil {
		return 0, false, err
	}
	return 0, false, nil
}

func restore(fd uintptr, old *termios) {
	if old != nil {
		syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(old)))
	}
}
