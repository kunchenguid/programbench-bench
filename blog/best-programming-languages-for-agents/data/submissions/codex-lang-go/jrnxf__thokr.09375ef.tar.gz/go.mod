module thokr-reimplementation

go 1.21
