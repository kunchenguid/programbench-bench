package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/printer"
	"go/token"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "v0.0.0-SNAPSHOT"

type checker struct{ name, tags, doc string }
type issue struct {
	file         string
	line, col    int
	checker, msg string
}

var checkers = []checker{
	{"appendAssign", "diagnostic", "Detects suspicious append result assignments."}, {"appendCombine", "performance", "Detects append chains that can be combined."}, {"argOrder", "diagnostic", "Detects suspicious argument order."}, {"assignOp", "style", "Detects assignments that can be simplified by using an assignment operator."}, {"badCall", "diagnostic", "Detects suspicious function calls."}, {"badCond", "diagnostic", "Detects suspicious condition expressions."}, {"badLock", "diagnostic experimental", "Detects suspicious lock usage."}, {"badRegexp", "diagnostic experimental", "Detects invalid regular expressions."}, {"badSorting", "diagnostic experimental", "Detects bad sort function usage."}, {"badSyncOnceFunc", "diagnostic experimental", "Detects suspicious sync.OnceFunc usage."}, {"boolExprSimplify", "style experimental", "Detects boolean expressions that can be simplified."}, {"builtinShadow", "style opinionated", "Detects shadowing of predeclared identifiers."}, {"builtinShadowDecl", "diagnostic experimental", "Detects declarations that shadow builtin identifiers."}, {"captLocal", "style", "Detects capitalized names for local variables."}, {"caseOrder", "diagnostic", "Detects erroneous case order."}, {"codegenComment", "diagnostic", "Detects malformed code generation comments."}, {"commentFormatting", "style", "Detects comments with incorrect formatting."}, {"commentedOutCode", "diagnostic experimental", "Detects commented-out code."}, {"commentedOutImport", "style experimental", "Detects commented-out imports."}, {"defaultCaseOrder", "style", "Detects default case order issues."}, {"deferInLoop", "diagnostic experimental", "Detects defer inside loops."}, {"deferUnlambda", "style experimental", "Detects defer statements that can be simplified."}, {"deprecatedComment", "diagnostic", "Detects malformed deprecation comments."}, {"docStub", "style experimental", "Detects documentation stubs."}, {"dupArg", "diagnostic", "Detects duplicated function call arguments."}, {"dupBranchBody", "diagnostic", "Detects duplicated branch bodies."}, {"dupCase", "diagnostic", "Detects duplicated switch cases."}, {"dupImport", "style experimental", "Detects duplicated imports."}, {"dupOption", "diagnostic experimental", "Detects duplicated options."}, {"dupSubExpr", "diagnostic", "Detects suspicious duplicated sub-expressions."}, {"dynamicFmtString", "diagnostic experimental", "Detects dynamic format strings."}, {"elseif", "style", "Detects else-if chains that can be simplified."}, {"emptyDecl", "diagnostic experimental", "Detects empty declarations."}, {"emptyFallthrough", "style experimental", "Detects empty fallthrough cases."}, {"emptyStringTest", "style experimental", "Detects empty string tests."}, {"equalFold", "performance experimental", "Detects strings.ToLower/ToUpper comparisons."}, {"evalOrder", "diagnostic experimental", "Detects evaluation order dependent expressions."}, {"exitAfterDefer", "diagnostic", "Detects os.Exit after defer."}, {"exposedSyncMutex", "style experimental", "Detects exposed sync.Mutex fields."}, {"externalErrorReassign", "diagnostic experimental", "Detects reassignment of external errors."}, {"filepathJoin", "diagnostic experimental", "Detects bad filepath.Join usage."}, {"flagDeref", "diagnostic", "Detects immediate flag pointer dereference."}, {"flagName", "diagnostic", "Detects suspicious flag names."}, {"hexLiteral", "style experimental", "Detects hex literals style issues."}, {"httpNoBody", "style experimental", "Detects nil request bodies that can use http.NoBody."}, {"hugeParam", "performance", "Detects huge function parameters."}, {"ifElseChain", "style", "Detects repeated if-else chains."}, {"importShadow", "style opinionated", "Detects imports that shadow identifiers."}, {"indexAlloc", "performance", "Detects strings.Index use that allocates."}, {"initClause", "style opinionated experimental", "Detects init clauses that can be simplified."}, {"mapKey", "diagnostic", "Detects suspicious map keys."}, {"methodExprCall", "style experimental", "Detects method expression calls that can be simplified."}, {"nestingReduce", "style opinionated experimental", "Detects code that can reduce nesting."}, {"newDeref", "style", "Detects immediate dereference of new."}, {"nilValReturn", "diagnostic experimental", "Detects nil value returns."}, {"octalLiteral", "style experimental opinionated", "Detects old-style octal literals."}, {"offBy1", "diagnostic", "Detects off-by-one index loops."}, {"paramTypeCombine", "style opinionated", "Detects adjacent parameters with same types."}, {"preferDecodeRune", "performance experimental", "Detects DecodeRuneInString opportunities."}, {"preferFilepathJoin", "style experimental", "Detects path.Join used for file paths."}, {"preferFprint", "performance experimental", "Detects fmt.Sprint before WriteString."}, {"preferStringWriter", "performance experimental", "Detects Write([]byte(string))."}, {"preferWriteByte", "performance experimental opinionated", "Detects WriteString of one byte strings."}, {"ptrToRefParam", "style opinionated experimental", "Detects pointer-to-reference parameters."}, {"rangeAppendAll", "diagnostic experimental", "Detects range append all patterns."}, {"rangeExprCopy", "performance", "Detects expensive range expression copies."}, {"rangeValCopy", "performance", "Detects expensive range value copies."}, {"redundantSprint", "style experimental", "Detects redundant fmt.Sprint calls."}, {"regexpMust", "style", "Detects regexp.Compile with constant patterns."}, {"regexpPattern", "diagnostic experimental", "Detects suspicious regexp patterns."}, {"regexpSimplify", "style experimental opinionated", "Detects regexp patterns that can be simplified."}, {"returnAfterHttpError", "diagnostic experimental", "Detects missing return after http.Error."}, {"ruleguard", "style experimental", "Runs dynamic ruleguard rules."}, {"singleCaseSwitch", "style", "Detects switch statements with a single case."}, {"sliceClear", "performance experimental", "Detects loops that can use clear."}, {"sloppyLen", "diagnostic", "Detects suspicious len comparisons."}, {"sloppyReassign", "diagnostic experimental", "Detects sloppy reassignments."}, {"sloppyTypeAssert", "diagnostic", "Detects type assertions that ignore comma-ok result."}, {"sortSlice", "diagnostic experimental", "Detects sort.Slice issues."}, {"sprintfQuotedString", "diagnostic experimental", "Detects quoted string formatting issues."}, {"sqlQuery", "diagnostic experimental", "Detects suspicious SQL queries."}, {"stringConcatSimplify", "style experimental", "Detects string concatenations that can be simplified."}, {"stringXbytes", "performance", "Detects redundant string/[]byte conversions."}, {"stringsCompare", "style experimental", "Detects strings.Compare use that can be simplified."}, {"switchTrue", "style", "Detects switch true statements."}, {"syncMapLoadAndDelete", "diagnostic experimental", "Detects Load followed by Delete."}, {"timeExprSimplify", "style experimental", "Detects time expressions that can be simplified."}, {"todoCommentWithoutDetail", "style opinionated experimental", "Detects TODO comments without detail."}, {"tooManyResultsChecker", "style opinionated experimental", "Detects functions with too many results."}, {"truncateCmp", "diagnostic experimental", "Detects suspicious truncated comparisons."}, {"typeAssertChain", "style experimental", "Detects chained type assertions."}, {"typeDefFirst", "style experimental", "Detects type definitions after methods."}, {"typeSwitchVar", "style", "Detects type switches that can use variable."}, {"typeUnparen", "style opinionated", "Detects unnecessary type parentheses."}, {"uncheckedInlineErr", "diagnostic experimental", "Detects unchecked inline errors."}, {"underef", "style", "Detects redundant pointer dereference/address operations."}, {"unlabelStmt", "style experimental", "Detects unnecessary labels."}, {"unlambda", "style", "Detects function literals that can be replaced by function values."}, {"unnamedResult", "style opinionated experimental", "Detects unnamed results."}, {"unnecessaryBlock", "style opinionated experimental", "Detects unnecessary blocks."}, {"unnecessaryDefer", "diagnostic experimental", "Detects unnecessary defer statements."}, {"unslice", "style", "Detects redundant full-slice expressions."}, {"valSwap", "style", "Detects value swaps that can use parallel assignment."}, {"weakCond", "diagnostic experimental", "Detects weak conditions."}, {"whyNoLint", "style experimental", "Detects nolint comments without explanations."}, {"wrapperFunc", "style", "Detects wrapper functions."}, {"yodaStyleExpr", "style experimental", "Detects yoda-style expressions."}, {"zeroByteRepeat", "performance", "Detects bytes.Repeat with zero count."},
}

var defaultEnabled = strings.Split("appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc", ",")

func main() {
	if len(os.Args) == 1 {
		fmt.Println("no args provided")
		return
	}
	switch os.Args[1] {
	case "help":
		printHelp()
		return
	case "version":
		fmt.Printf("go-critic version: %s\n", version)
		return
	case "doc":
		cmdDoc(os.Args[2:])
		return
	case "check":
		os.Exit(cmdCheck(os.Args[2:]))
	default:
		fmt.Fprintf(os.Stderr, "%q unknown command, did you mean \"help\"?\nRun \"go-critic help\" for usage.\n\nno such command %q\n", os.Args[1], os.Args[1])
		os.Exit(1)
	}
}
func printHelp() {
	fmt.Printf("Usage:\n\n    go-critic <command> [arguments...]\n\nThe commands are:\n\n    check             run linter over specified targets\n    doc               get installed checkers documentation\n    help              shows help message\n    version           shows version of the application\n\nVersion: %s\n", version)
}
func cmdDoc(args []string) {
	fs := flag.NewFlagSet("go-critic", flag.ContinueOnError)
	fs.SetOutput(os.Stdout)
	if err := fs.Parse(args); err != nil {
		fmt.Println(err)
		return
	}
	rest := fs.Args()
	if len(rest) == 0 {
		for _, c := range checkers {
			fmt.Printf("%s [%s]\n", c.name, c.tags)
		}
		return
	}
	name := rest[0]
	for _, c := range checkers {
		if c.name == name {
			fmt.Printf("%s checker documentation\nURL: https://github.com/go-critic/go-critic/checkers\nTags: [%s]\n\n%s\n", c.name, c.tags, c.doc)
			return
		}
	}
	fmt.Printf("checker with name %q not found\n", name)
}

type config struct {
	enabled                    map[string]bool
	exitCode                   int
	checkTests, checkGenerated bool
	verbose                    bool
}

func cmdCheck(args []string) int {
	cfg := config{enabled: map[string]bool{}, exitCode: 1, checkTests: true}
	for _, n := range defaultEnabled {
		cfg.enabled[n] = true
	}
	fs := flag.NewFlagSet("go-critic", flag.ContinueOnError)
	fs.SetOutput(os.Stdout)
	enable := fs.String("enable", strings.Join(defaultEnabled, ","), "comma-separated list of enabled checkers. Can include #tags")
	disable := fs.String("disable", "", "comma-separated list of checkers to be disabled. Can include #tags")
	enableAll := fs.Bool("enableAll", false, "identical to -enable with all checkers listed. If true, -enable is ignored")
	fs.BoolVar(&cfg.checkGenerated, "checkGenerated", false, "whether to check generated files")
	fs.BoolVar(&cfg.checkTests, "checkTests", true, "whether to check test files")
	fs.Int("concurrency", 14, "how many concurrent checkers to run (default is runtime.GOMAXPROCS(0))")
	fs.String("cpuprofile", "", "write CPU profile to the specified file")
	fs.String("memprofile", "", "write memory profile to the specified file")
	fs.IntVar(&cfg.exitCode, "exitCode", 1, "exit code to be used when lint issues are found")
	fs.String("go", "", "select the Go version to target. Leave as string for the latest")
	fs.Bool("shorterErrLocation", true, "whether to replace error location prefix with $GOROOT and $GOPATH")
	fs.BoolVar(&cfg.verbose, "v", false, "whether to print output useful during linter debugging")
	addParamFlags(fs)
	if err := fs.Parse(args); err != nil {
		fmt.Println("parse args:", err)
		return 1
	}
	cfg.enabled = selectEnabled(*enable, *disable, *enableAll)
	targets := fs.Args()
	if len(targets) == 0 {
		targets = []string{"."}
	}
	files := collectFiles(targets, cfg)
	var issues []issue
	for _, f := range files {
		issues = append(issues, analyzeFile(f, cfg)...)
	}
	sort.SliceStable(issues, func(i, j int) bool {
		if issues[i].file != issues[j].file {
			return issues[i].file < issues[j].file
		}
		if issues[i].line != issues[j].line {
			return issues[i].line < issues[j].line
		}
		if issues[i].col != issues[j].col {
			return issues[i].col < issues[j].col
		}
		return issues[i].checker < issues[j].checker
	})
	for _, is := range issues {
		fmt.Printf("%s:%d:%d: %s: %s\n", displayPath(is.file), is.line, is.col, is.checker, is.msg)
	}
	if len(issues) > 0 {
		return cfg.exitCode
	}
	return 0
}
func addParamFlags(fs *flag.FlagSet) {
	fs.Bool("@captLocal.paramsOnly", true, "whether to restrict checker to params only")
	fs.Int("@commentedOutCode.minLength", 15, "min length of the comment that triggers a warning")
	fs.Bool("@elseif.skipBalanced", true, "whether to skip balanced if-else pairs")
	fs.Int("@hugeParam.sizeThreshold", 80, "size in bytes that makes the warning trigger")
	fs.Int("@ifElseChain.minThreshold", 2, "min number of if-else blocks that makes the warning trigger")
	fs.Int("@nestingReduce.bodyWidth", 5, "min number of statements inside a branch to trigger a warning")
	fs.Int("@rangeExprCopy.sizeThreshold", 512, "size in bytes that makes the warning trigger")
	fs.Bool("@rangeExprCopy.skipTestFuncs", true, "whether to check test functions")
	fs.Int("@rangeValCopy.sizeThreshold", 128, "size in bytes that makes the warning trigger")
	fs.Bool("@rangeValCopy.skipTestFuncs", true, "whether to check test functions")
	fs.String("@ruleguard.debug", "", "enable debug for the specified named rules group")
	fs.String("@ruleguard.disable", "", "comma-separated list of disabled groups or skip empty to enable everything")
	fs.String("@ruleguard.enable", "<all>", "comma-separated list of enabled groups or skip empty to enable everything")
	fs.String("@ruleguard.failOn", "", "Determines the behavior when an error occurs while parsing ruleguard files.")
	fs.Bool("@ruleguard.failOnError", false, "deprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''")
	fs.String("@ruleguard.rules", "", "comma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified")
	fs.Int("@tooManyResultsChecker.maxResults", 5, "maximum number of results")
	fs.Bool("@truncateCmp.skipArchDependent", true, "whether to skip int/uint/uintptr types")
	fs.Bool("@underef.skipRecvDeref", true, "whether to skip (*x).method() calls where x is a pointer receiver")
	fs.Bool("@unnamedResult.checkExported", false, "whether to check exported functions")
}
func selectEnabled(enable, disable string, all bool) map[string]bool {
	m := map[string]bool{}
	if all {
		for _, c := range checkers {
			m[c.name] = true
		}
	} else {
		for _, x := range splitList(enable) {
			addByNameOrTag(m, x, true)
		}
	}
	for _, x := range splitList(disable) {
		addByNameOrTag(m, x, false)
	}
	return m
}
func splitList(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}
func addByNameOrTag(m map[string]bool, x string, v bool) {
	if strings.HasPrefix(x, "#") {
		tag := strings.TrimPrefix(x, "#")
		for _, c := range checkers {
			if strings.Contains(" "+c.tags+" ", " "+tag+" ") {
				m[c.name] = v
			}
		}
		return
	}
	m[x] = v
}
func collectFiles(targets []string, cfg config) []string {
	seen := map[string]bool{}
	var files []string
	add := func(p string) {
		if strings.HasSuffix(p, "_test.go") && !cfg.checkTests {
			return
		}
		if !cfg.checkGenerated {
			if b, err := os.ReadFile(p); err == nil && isGenerated(b) {
				return
			}
		}
		if !seen[p] {
			seen[p] = true
			files = append(files, p)
		}
	}
	for _, t := range targets {
		if strings.HasSuffix(t, "/...") {
			root := strings.TrimSuffix(t, "/...")
			if root == "" {
				root = "."
			}
			filepath.WalkDir(root, func(p string, d os.DirEntry, e error) error {
				if e != nil {
					return nil
				}
				if d.IsDir() {
					if strings.HasPrefix(d.Name(), ".") && p != root {
						return filepath.SkipDir
					}
					return nil
				}
				if strings.HasSuffix(p, ".go") {
					add(p)
				}
				return nil
			})
			continue
		}
		st, err := os.Stat(t)
		if err != nil {
			continue
		}
		if st.IsDir() {
			ents, _ := os.ReadDir(t)
			for _, e := range ents {
				if !e.IsDir() && strings.HasSuffix(e.Name(), ".go") {
					add(filepath.Join(t, e.Name()))
				}
			}
		} else if strings.HasSuffix(t, ".go") {
			add(t)
		}
	}
	sort.Strings(files)
	return files
}
func isGenerated(b []byte) bool {
	head := string(b)
	if len(head) > 2048 {
		head = head[:2048]
	}
	return strings.Contains(head, "Code generated") && strings.Contains(head, "DO NOT EDIT")
}
func displayPath(p string) string {
	p = filepath.ToSlash(p)
	if filepath.IsAbs(p) {
		return p
	}
	if strings.HasPrefix(p, "./") {
		return p
	}
	return "./" + p
}
func analyzeFile(path string, cfg config) []issue {
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		return nil
	}
	var out []issue
	emit := func(n ast.Node, ch, msg string) {
		if !cfg.enabled[ch] || n == nil {
			return
		}
		pos := fset.Position(n.Pos())
		out = append(out, issue{path, pos.Line, pos.Column, ch, msg})
	}
	ast.Inspect(f, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.AssignStmt:
			checkAssign(x, emit)
		case *ast.BinaryExpr:
			checkBinary(x, emit)
		case *ast.SliceExpr:
			if x.High != nil && x.Max == nil && exprString(x.High) == "len("+exprString(x.X)+")" {
				emit(x, "unslice", fmt.Sprintf("could simplify %s to %s", exprString(x), exprString(x.X)))
			}
		case *ast.StarExpr:
			if u, ok := x.X.(*ast.UnaryExpr); ok && u.Op == token.AND {
				emit(x, "underef", fmt.Sprintf("could simplify %s to %s", exprString(x), exprString(u.X)))
			}
		case *ast.UnaryExpr:
			if x.Op == token.AND {
				if st, ok := x.X.(*ast.StarExpr); ok {
					emit(x, "underef", fmt.Sprintf("could simplify %s to %s", exprString(x), exprString(st.X)))
				}
			}
		case *ast.CallExpr:
			checkCall(x, emit)
		case *ast.SwitchStmt:
			if len(x.Body.List) == 1 {
				emit(x, "singleCaseSwitch", "should rewrite switch statement to if statement")
			}
			if id, ok := x.Tag.(*ast.Ident); ok && id.Name == "true" {
				emit(x, "switchTrue", "replace 'switch true {}' with 'switch {}'")
			}
		case *ast.TypeSwitchStmt:
			if as, ok := x.Assign.(*ast.AssignStmt); ok && len(as.Lhs) == 1 {
				if id, ok := as.Lhs[0].(*ast.Ident); ok && id.Name == "_" {
					emit(x, "typeSwitchVar", "assign type switch expression to variable")
				}
			}
		case *ast.IfStmt:
			if _, ok := x.Else.(*ast.IfStmt); ok {
				emit(x.Else, "elseif", "can replace 'else {if cond {}}' with 'else if cond {}'")
			}
		case *ast.ForStmt:
			checkFor(x, emit)
		}
		return true
	})
	return out
}
func checkAssign(x *ast.AssignStmt, emit func(ast.Node, string, string)) {
	if len(x.Lhs) == 1 && len(x.Rhs) == 1 {
		l, r := exprString(x.Lhs[0]), x.Rhs[0]
		if call, ok := r.(*ast.CallExpr); ok && funName(call.Fun) == "append" && len(call.Args) > 0 && exprString(call.Args[0]) != l {
			emit(x, "appendAssign", "append result not assigned to the same slice")
		}
		if b, ok := r.(*ast.BinaryExpr); ok && exprString(b.X) == l {
			op := b.Op.String()
			repl := l + " " + op + "= " + exprString(b.Y)
			if b.Op == token.ADD {
				if lit, ok := b.Y.(*ast.BasicLit); ok && lit.Value == "1" {
					repl = l + "++"
				}
			}
			emit(x, "assignOp", fmt.Sprintf("replace `%s` with `%s`", exprString(x), repl))
		}
		if st, ok := r.(*ast.StarExpr); ok {
			if call, ok := st.X.(*ast.CallExpr); ok && funName(call.Fun) == "new" {
				emit(x, "newDeref", fmt.Sprintf("replace %s with %s", exprString(r), zeroFor(call)))
			}
		}
	}
	if len(x.Lhs) == 2 && len(x.Rhs) == 2 && exprString(x.Lhs[0]) == exprString(x.Rhs[1]) && exprString(x.Lhs[1]) == exprString(x.Rhs[0]) {
		emit(x, "valSwap", "can use parallel assignment")
	}
}
func checkBinary(x *ast.BinaryExpr, emit func(ast.Node, string, string)) {
	if sameExpr(x.X, x.Y) && (x.Op == token.EQL || x.Op == token.NEQ || x.Op == token.LSS || x.Op == token.GTR || x.Op == token.LEQ || x.Op == token.GEQ) {
		emit(x, "dupSubExpr", fmt.Sprintf("suspicious identical LHS and RHS for `%s` operator", x.Op.String()))
	}
	if isLenCall(x.X) || isLenCall(x.Y) {
		if (x.Op == token.LSS || x.Op == token.GTR || x.Op == token.LEQ || x.Op == token.GEQ) && (isZero(x.X) || isZero(x.Y)) {
			emit(x, "sloppyLen", "suspicious len() comparison")
		}
	}
}
func checkCall(x *ast.CallExpr, emit func(ast.Node, string, string)) {
	fn := funName(x.Fun)
	if (fn == "regexp.Compile" || fn == "regexp.MatchString") && len(x.Args) > 0 && isStringLit(x.Args[0]) {
		emit(x, "regexpMust", fmt.Sprintf("for const patterns like %s, use regexp.MustCompile", exprString(x.Args[0])))
	}
	if strings.HasPrefix(fn, "fmt.Sprint") && len(x.Args) == 1 && isStringLit(x.Args[0]) {
		emit(x, "redundantSprint", fmt.Sprintf("%s is already string", exprString(x.Args[0])))
	}
	if fn == "fmt.Sprintf" && len(x.Args) == 2 && isStringLit(x.Args[0]) {
		format := strings.Trim(exprString(x.Args[0]), "\"`")
		if (format == "%s" || format == "%v") && isStringLit(x.Args[1]) {
			emit(x, "redundantSprint", fmt.Sprintf("%s is already string", exprString(x.Args[1])))
		}
	}
	seen := map[string]bool{}
	for _, a := range x.Args {
		s := exprString(a)
		if seen[s] && s != "" {
			emit(x, "dupArg", fmt.Sprintf("suspicious duplicated argument %s", s))
			break
		}
		seen[s] = true
	}
	if sel, ok := x.Fun.(*ast.SelectorExpr); ok && sel.Sel.Name == "Errorf" && len(x.Args) > 0 && isStringLit(x.Args[0]) && !strings.Contains(strings.Trim(exprString(x.Args[0]), "\"`"), "%") {
		emit(x, "badCall", "use errors.New for simple error strings")
	}
}
func checkFor(x *ast.ForStmt, emit func(ast.Node, string, string)) {
	if x.Cond == nil {
		return
	}
	b, ok := x.Cond.(*ast.BinaryExpr)
	if !ok || b.Op != token.LEQ {
		return
	}
	if call, ok := b.Y.(*ast.CallExpr); ok && funName(call.Fun) == "len" {
		emit(x.Cond, "offBy1", "index can be equal to len()")
	}
}
func exprString(e interface{}) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, token.NewFileSet(), e)
	return b.String()
}
func sameExpr(a, b ast.Expr) bool { return exprString(a) == exprString(b) }
func funName(e ast.Expr) string {
	switch f := e.(type) {
	case *ast.Ident:
		return f.Name
	case *ast.SelectorExpr:
		return funName(f.X) + "." + f.Sel.Name
	}
	return exprString(e)
}
func isStringLit(e ast.Expr) bool { l, ok := e.(*ast.BasicLit); return ok && l.Kind == token.STRING }
func isZero(e ast.Expr) bool      { l, ok := e.(*ast.BasicLit); return ok && l.Value == "0" }
func isLenCall(e ast.Expr) bool   { c, ok := e.(*ast.CallExpr); return ok && funName(c.Fun) == "len" }
func zeroFor(call *ast.CallExpr) string {
	if len(call.Args) == 0 {
		return "nil"
	}
	s := exprString(call.Args[0])
	switch s {
	case "int", "int8", "int16", "int32", "int64", "uint", "uint8", "uint16", "uint32", "uint64", "uintptr", "byte", "rune":
		return "0"
	case "string":
		return "\"\""
	case "bool":
		return "false"
	}
	return s + "{}"
}

var _ = regexp.MustCompile
var _ = strconv.IntSize
