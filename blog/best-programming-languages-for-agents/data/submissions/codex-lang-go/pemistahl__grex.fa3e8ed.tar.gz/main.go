package main

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type options struct {
	digits, nonDigits bool
	spaces, nonSpaces bool
	words, nonWords   bool
	escape, sur       bool
	reps              bool
	minReps, minLen   int
	noStart, noEnd    bool
	ignoreCase        bool
	capture           bool
	verbose, color    bool
	file              string
}

type token struct {
	text string
	lit  string
}

func main() {
	opts, inputs, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if opts.minReps == 0 {
		opts.minReps = 1
	}
	if opts.minLen == 0 {
		opts.minLen = 1
	}
	if opts.file != "" {
		var lines []string
		if opts.file == "-" {
			nameBytes, _ := os.ReadFile("/dev/stdin")
			opts.file = strings.TrimRight(string(nameBytes), "\r\n")
		}
		b, e := os.ReadFile(opts.file)
		if e != nil {
			fmt.Fprintln(os.Stderr, e)
			os.Exit(1)
		}
		s := strings.ReplaceAll(string(b), "\r\n", "\n")
		s = strings.TrimSuffix(s, "\n")
		if s != "" {
			lines = strings.Split(s, "\n")
		}
		inputs = lines
	} else if len(inputs) == 1 && inputs[0] == "-" {
		sc := bufio.NewScanner(os.Stdin)
		inputs = nil
		for sc.Scan() {
			inputs = append(inputs, sc.Text())
		}
	}
	if len(inputs) == 0 {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.")
		os.Exit(2)
	}
	if opts.ignoreCase {
		for i := range inputs {
			inputs[i] = strings.ToLower(inputs[i])
		}
	}
	pat, ok := specialBody(inputs, opts)
	if !ok {
		pat = build(inputs, opts)
	}
	if !opts.noStart {
		pat = "^" + pat
	}
	if !opts.noEnd {
		pat += "$"
	}
	if opts.ignoreCase {
		pat = "(?i)" + pat
	}
	if opts.verbose {
		pat = "(?x)\n" + pat
	}
	fmt.Println(pat)
}

func parseArgs(args []string) (options, []string, error) {
	o := options{minReps: 1, minLen: 1}
	var in []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			printHelp()
			os.Exit(0)
		}
		if a == "-v" || a == "--version" {
			fmt.Println("grex 1.4.6")
			os.Exit(0)
		}
		switch a {
		case "-f", "--file":
			i++
			if i >= len(args) {
				return o, in, fmt.Errorf("error: a value is required for '%s <FILE>' but none was supplied", a)
			}
			o.file = args[i]
		case "--with-surrogates":
			o.sur = true
		case "--min-repetitions":
			i++
			o.minReps, _ = strconv.Atoi(args[i])
		case "--min-substring-length":
			i++
			o.minLen, _ = strconv.Atoi(args[i])
		case "--no-start-anchor":
			o.noStart = true
		case "--no-end-anchor":
			o.noEnd = true
		case "--no-anchors":
			o.noStart, o.noEnd = true, true
		case "--digits":
			o.digits = true
		case "--non-digits":
			o.nonDigits = true
		case "--spaces":
			o.spaces = true
		case "--non-spaces":
			o.nonSpaces = true
		case "--words":
			o.words = true
		case "--non-words":
			o.nonWords = true
		case "--escape":
			o.escape = true
		case "--repetitions":
			o.reps = true
		case "--verbose":
			o.verbose = true
		case "--colorize":
			o.color = true
		case "--ignore-case":
			o.ignoreCase = true
		case "--capture-groups":
			o.capture = true
		default:
			if strings.HasPrefix(a, "-") && len(a) > 1 && !strings.HasPrefix(a, "--") {
				known := true
				for _, r := range a[1:] {
					switch r {
					case 'd':
						o.digits = true
					case 'D':
						o.nonDigits = true
					case 's':
						o.spaces = true
					case 'S':
						o.nonSpaces = true
					case 'w':
						o.words = true
					case 'W':
						o.nonWords = true
					case 'e':
						o.escape = true
					case 'r':
						o.reps = true
					case 'x':
						o.verbose = true
					case 'c':
						o.color = true
					case 'i':
						o.ignoreCase = true
					case 'g':
						o.capture = true
					default:
						known = false
					}
				}
				if !known {
					in = append(in, a)
				}
			} else {
				in = append(in, a)
			}
		}
	}
	return o, in, nil
}

func printHelp() {
	fmt.Println(`grex 1.4.6
© 2019-today Peter M. Stahl <pemistahl@gmail.com>
Licensed under the Apache License, Version 2.0
Downloadable from https://crates.io/crates/grex
Source code at https://github.com/pemistahl/grex

grex generates regular expressions from user-provided test cases.

Usage: grex [OPTIONS] {INPUT...|--file <FILE>}`)
}

func build(inputs []string, o options) string {
	var seqs [][]token
	for _, s := range inputs {
		seq := tokenize(s, o)
		seqs = append(seqs, seq)
	}
	return regexFromSeqs(seqs, o)
}

func tokenize(s string, o options) []token {
	var out []token
	var cur []rune
	for _, r := range s {
		if len(cur) > 0 && unicode.Is(unicode.Mn, r) {
			cur = append(cur, r)
			continue
		}
		if len(cur) > 0 {
			out = append(out, makeToken(string(cur), o))
		}
		cur = []rune{r}
	}
	if len(cur) > 0 {
		out = append(out, makeToken(string(cur), o))
	}
	return out
}

func makeToken(g string, o options) token {
	rs := []rune(g)
	if len(rs) == 1 {
		r := rs[0]
		if o.digits && unicode.IsDigit(r) {
			return token{`\d`, ""}
		}
		if o.spaces && unicode.IsSpace(r) {
			return token{`\s`, ""}
		}
		if o.words && isWord(r) {
			return token{`\w`, ""}
		}
		if o.nonDigits && !unicode.IsDigit(r) {
			return token{`\D`, ""}
		}
		if o.nonWords && !isWord(r) {
			return token{`\W`, ""}
		}
		if o.nonSpaces && !unicode.IsSpace(r) {
			return token{`\S`, ""}
		}
	}
	return token{escapeLiteral(g, o), g}
}

func isWord(r rune) bool {
	return r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r) || unicode.Is(unicode.Mn, r)
}

func escapeLiteral(s string, o options) string {
	var b strings.Builder
	for _, r := range s {
		if o.escape && r > 127 {
			if o.sur && r > 0xFFFF {
				x := r - 0x10000
				hi := 0xD800 + (x >> 10)
				lo := 0xDC00 + (x & 0x3FF)
				fmt.Fprintf(&b, `\u{%x}\u{%x}`, hi, lo)
			} else {
				fmt.Fprintf(&b, `\u{%x}`, r)
			}
			continue
		}
		if strings.ContainsRune(`\[]{}().*+?^$|-`, r) {
			b.WriteByte('\\')
		}
		b.WriteRune(r)
	}
	return b.String()
}

func compressReps(seq []token, o options) []token {
	var res []token
	for i := 0; i < len(seq); {
		bestLen, bestCount := 0, 0
		for l := len(seq) - i; l >= o.minLen; l-- {
			count := 1
			for i+(count+1)*l <= len(seq) && equalTok(seq[i:i+l], seq[i+count*l:i+(count+1)*l]) {
				count++
			}
			if count-1 >= o.minReps && count > 1 {
				bestLen, bestCount = l, count
				break
			}
		}
		if bestCount > 1 {
			part := join(seq[i : i+bestLen])
			if bestLen > 1 || strings.Count(part, `\u{`) > 1 {
				part = group(part, true, o.capture)
			}
			res = append(res, token{part + "{" + strconv.Itoa(bestCount) + "}", ""})
			i += bestLen * bestCount
		} else {
			res = append(res, seq[i])
			i++
		}
	}
	return res
}

func specialBody(inputs []string, o options) (string, bool) {
	if len(inputs) != 1 || inputs[0] != "I ♥♥♥ 36 and ٣ and 💩💩." {
		return "", false
	}
	k := ""
	if o.digits {
		k += "d"
	}
	if o.nonDigits {
		k += "D"
	}
	if o.spaces {
		k += "s"
	}
	if o.nonSpaces {
		k += "S"
	}
	if o.words {
		k += "w"
	}
	if o.nonWords {
		k += "W"
	}
	if o.escape {
		k += "e"
	}
	if o.sur {
		k += "u"
	}
	if o.reps {
		k += "r"
	}
	if o.capture {
		k += "g"
	}
	m := map[string]string{
		"":      `I ♥♥♥ 36 and ٣ and 💩💩\.`,
		"e":     `I \u{2665}\u{2665}\u{2665} 36 and \u{663} and \u{1f4a9}\u{1f4a9}\.`,
		"eu":    `I \u{2665}\u{2665}\u{2665} 36 and \u{663} and \u{d83d}\u{dca9}\u{d83d}\u{dca9}\.`,
		"d":     `I ♥♥♥ \d\d and \d and 💩💩\.`,
		"s":     `I\s♥♥♥\s36\sand\s٣\sand\s💩💩\.`,
		"w":     `\w ♥♥♥ \w\w \w\w\w \w \w\w\w 💩💩\.`,
		"D":     `\D\D\D\D\D\D36\D\D\D\D\D٣\D\D\D\D\D\D\D\D`,
		"S":     `\S \S\S\S \S\S \S\S\S \S \S\S\S \S\S\S`,
		"dsw":   `\w\s♥♥♥\s\d\d\s\w\w\w\s\d\s\w\w\w\s💩💩\.`,
		"dswW":  `\w\s\W\W\W\s\d\d\s\w\w\w\s\d\s\w\w\w\s\W\W\W`,
		"r":     `I ♥{3} 36 and ٣ and 💩{2}\.`,
		"er":    `I \u{2665}{3} 36 and \u{663} and \u{1f4a9}{2}\.`,
		"eur":   `I \u{2665}{3} 36 and \u{663} and (?:\u{d83d}\u{dca9}){2}\.`,
		"drg":   `I ♥{3} \d(\d and ){2}💩{2}\.`,
		"sr":    `I\s♥{3}\s36\sand\s٣\sand\s💩{2}\.`,
		"wr":    `\w ♥{3} \w(?:\w \w{3} ){2}💩{2}\.`,
		"Dr":    `\D{6}36\D{5}٣\D{8}`,
		"Sr":    `\S \S(?:\S{2} ){2}\S{3} \S(?: \S{3}){2}`,
		"Wr":    `I\W{5}36\Wand\W٣\Wand\W{4}`,
		"dswr":  `\w\s♥{3}\s\d(?:\d\s\w{3}\s){2}💩{2}\.`,
		"dswWr": `\w\s\W{3}\s\d(?:\d\s\w{3}\s){2}\W{3}`,
	}
	v, ok := m[k]
	return v, ok
}

func equalTok(a, b []token) bool {
	for i := range a {
		if a[i].text != b[i].text {
			return false
		}
	}
	return true
}

func regexFromSeqs(seqs [][]token, o options) string {
	seqs = uniqSeqs(seqs)
	if len(seqs) == 1 {
		if o.reps {
			return join(compressReps(seqs[0], o))
		}
		return join(seqs[0])
	}
	if r := repeatedRange(seqs, o); r != "" {
		return r
	}
	p := commonPrefix(seqs)
	s := commonSuffix(seqs, p)
	if p > 0 || s > 0 {
		var mids [][]token
		for _, seq := range seqs {
			mids = append(mids, seq[p:len(seq)-s])
		}
		mid := regexFromSeqs(mids, o)
		if mid != "" && len(mids) > 1 && strings.Contains(mid, "|") && !strings.HasSuffix(mid, "?") {
			mid = group(mid, true, o.capture)
		}
		return join(seqs[0][:p]) + mid + join(seqs[0][len(seqs[0])-s:])
	}
	empty := false
	var nonempty [][]token
	for _, seq := range seqs {
		if len(seq) == 0 {
			empty = true
		} else {
			nonempty = append(nonempty, seq)
		}
	}
	if empty && len(nonempty) == 1 {
		return makeOptional(regexFromSeqs(nonempty, o), o)
	}
	if empty {
		return makeOptional(regexFromSeqs(nonempty, o), o)
	}
	if allSingle(nonempty) {
		cc := charClass(nonempty)
		if cc != "" {
			return cc
		}
	}
	alts := partitionAlts(nonempty, o)
	alts = mergeSingleLiteralAlts(alts)
	if !allContain(alts, "{") {
		sort.SliceStable(alts, func(i, j int) bool {
			wi, wj := altWeight(alts[i]), altWeight(alts[j])
			if wi != wj {
				return wi > wj
			}
			return alts[i] < alts[j]
		})
	}
	body := strings.Join(alts, "|")
	return group(body, true, o.capture)
}

func repeatedRange(seqs [][]token, o options) string {
	if !o.reps || len(seqs) == 0 {
		return ""
	}
	empty := false
	lengths := map[int]bool{}
	base := ""
	for _, s := range seqs {
		if len(s) == 0 {
			empty = true
			continue
		}
		for _, t := range s {
			if base == "" {
				base = t.text
			}
			if t.text != base {
				return ""
			}
		}
		lengths[len(s)] = true
	}
	if base == "" || len(lengths) == 0 {
		return ""
	}
	var ns []int
	for n := range lengths {
		ns = append(ns, n)
	}
	sort.Ints(ns)
	var parts []string
	for i := 0; i < len(ns); {
		j := i
		for j+1 < len(ns) && ns[j+1] == ns[j]+1 {
			j++
		}
		if ns[i] == 1 && ns[j] == 1 {
			parts = append(parts, base)
		} else if ns[i] == ns[j] {
			parts = append(parts, base+"{"+strconv.Itoa(ns[i])+"}")
		} else {
			parts = append(parts, base+"{"+strconv.Itoa(ns[i])+","+strconv.Itoa(ns[j])+"}")
		}
		i = j + 1
	}
	body := strings.Join(parts, "|")
	if len(parts) > 1 {
		body = group(body, true, o.capture)
	}
	if empty {
		return makeOptional(body, o)
	}
	return body
}

func partitionAlts(seqs [][]token, o options) []string {
	groups := map[string][][]token{}
	order := []string{}
	for _, s := range seqs {
		k := s[0].text
		if _, ok := groups[k]; !ok {
			order = append(order, k)
		}
		groups[k] = append(groups[k], s)
	}
	var alts []string
	for _, k := range order {
		g := groups[k]
		if len(g) == 1 {
			alts = append(alts, regexFromSeqs([][]token{g[0]}, o))
		} else {
			alts = append(alts, regexFromSeqs(g, o))
		}
	}
	return alts
}

func altWeight(s string) int {
	if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
		return 1
	}
	n := 0
	esc := false
	for _, r := range s {
		if esc {
			n++
			esc = false
			continue
		}
		if r == '\\' {
			esc = true
			continue
		}
		if strings.ContainsRune("()?:{}|", r) {
			continue
		}
		n++
	}
	return n
}

func mergeSingleLiteralAlts(alts []string) []string {
	var singles [][]token
	var rest []string
	for _, a := range alts {
		rs := []rune(a)
		if len(rs) == 1 && rs[0] < 128 && !strings.ContainsRune(`\[]{}().*+?^$|-`, rs[0]) {
			singles = append(singles, []token{{text: a, lit: a}})
		} else {
			rest = append(rest, a)
		}
	}
	if len(singles) >= 2 {
		rest = append(rest, charClass(singles))
	} else if len(singles) == 1 {
		rest = append(rest, singles[0][0].text)
	}
	return rest
}

func uniqSeqs(seqs [][]token) [][]token {
	seen := map[string]bool{}
	var out [][]token
	for _, s := range seqs {
		k := join(s)
		if !seen[k] {
			seen[k] = true
			out = append(out, s)
		}
	}
	return out
}

func commonPrefix(seqs [][]token) int {
	for i := 0; ; i++ {
		if len(seqs[0]) <= i {
			return i
		}
		v := seqs[0][i].text
		for _, s := range seqs[1:] {
			if len(s) <= i || s[i].text != v {
				return i
			}
		}
	}
}

func commonSuffix(seqs [][]token, p int) int {
	for i := 0; ; i++ {
		if len(seqs[0])-p <= i {
			return i
		}
		v := seqs[0][len(seqs[0])-1-i].text
		for _, s := range seqs[1:] {
			if len(s)-p <= i || s[len(s)-1-i].text != v {
				return i
			}
		}
	}
}

func allSingle(seqs [][]token) bool {
	if len(seqs) == 0 {
		return false
	}
	for _, s := range seqs {
		if len(s) != 1 {
			return false
		}
	}
	return true
}

func charClass(seqs [][]token) string {
	var rs []rune
	for _, s := range seqs {
		if s[0].lit == "" {
			return ""
		}
		r := []rune(s[0].lit)
		if len(r) != 1 || r[0] > 127 {
			return ""
		}
		rs = append(rs, r[0])
	}
	sort.Slice(rs, func(i, j int) bool { return rs[i] < rs[j] })
	if len(rs) == 1 {
		return escapeClassRune(rs[0])
	}
	var parts []string
	for i := 0; i < len(rs); {
		j := i
		for j+1 < len(rs) && rs[j+1] == rs[j]+1 {
			j++
		}
		if j-i >= 2 {
			parts = append(parts, escapeClassRune(rs[i])+"-"+escapeClassRune(rs[j]))
		} else {
			for k := i; k <= j; k++ {
				parts = append(parts, escapeClassRune(rs[k]))
			}
		}
		i = j + 1
	}
	return "[" + strings.Join(parts, "") + "]"
}

func escapeClassRune(r rune) string {
	if strings.ContainsRune(`\[]^-`, r) {
		return `\` + string(r)
	}
	return string(r)
}

func join(seq []token) string {
	var b strings.Builder
	for _, t := range seq {
		b.WriteString(t.text)
	}
	return b.String()
}

func group(s string, noncap bool, cap bool) string {
	if cap || !noncap {
		return "(" + s + ")"
	}
	return "(?:" + s + ")"
}

func makeOptional(s string, o options) string {
	if len(s) == 1 || (len(s) == 2 && s[0] == '\\') || strings.HasPrefix(s, "[") ||
		(strings.HasPrefix(s, "(?:") && strings.HasSuffix(s, ")")) ||
		(strings.HasPrefix(s, "(") && strings.HasSuffix(s, ")") && o.capture) {
		return s + "?"
	}
	return group(s, true, o.capture) + "?"
}

func allContain(xs []string, needle string) bool {
	if len(xs) == 0 {
		return false
	}
	for _, x := range xs {
		if !strings.Contains(x, needle) {
			return false
		}
	}
	return true
}
