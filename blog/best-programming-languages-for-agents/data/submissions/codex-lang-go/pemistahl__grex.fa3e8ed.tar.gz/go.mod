module grexclone

go 1.21
