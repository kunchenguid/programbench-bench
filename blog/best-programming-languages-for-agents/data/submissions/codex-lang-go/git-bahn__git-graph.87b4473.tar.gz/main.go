package main

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

const version = "git-graph 0.7.0"

type config struct {
	path      string
	model     string
	maxCount  string
	color     string
	noColor   bool
	format    string
	reverse   bool
	local     bool
	svg       bool
	debug     bool
	sparse    bool
	style     string
	command   string
	modelArg  string
	modelList bool
	showHelp  bool
	shortHelp bool
	showVer   bool
	skipOwner bool
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(1)
	}
}

func run() error {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		return err
	}
	if cfg.showVer {
		fmt.Println(version)
		return nil
	}
	if cfg.showHelp {
		if cfg.command == "model" {
			printModelHelp()
		} else if cfg.shortHelp {
			printShortHelp()
		} else {
			printLongHelp()
		}
		return nil
	}
	if cfg.command == "model" {
		return runModel(cfg)
	}
	return runGraph(cfg)
}

func parseArgs(args []string) (*config, error) {
	cfg := &config{path: ".", model: "", color: "auto", format: "oneline", style: "normal"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "help" {
			if i+1 < len(args) && args[i+1] == "model" {
				cfg.command = "model"
			}
			cfg.showHelp = true
			return cfg, nil
		}
		if a == "model" {
			cfg.command = "model"
			for j := i + 1; j < len(args); j++ {
				x := args[j]
				switch x {
				case "-h", "--help":
					cfg.showHelp = true
				case "-l", "--list":
					cfg.modelList = true
				default:
					if strings.HasPrefix(x, "-") {
						return nil, unexpected(x)
					}
					cfg.modelArg = x
				}
			}
			return cfg, nil
		}
		switch a {
		case "-h":
			cfg.showHelp, cfg.shortHelp = true, true
		case "--help":
			cfg.showHelp = true
		case "-V", "--version":
			cfg.showVer = true
		case "-p", "--path":
			i++
			if i >= len(args) {
				return nil, missing(a)
			}
			cfg.path = args[i]
		case "--skip-repo-owner-validation":
			cfg.skipOwner = true
		case "-m", "--model":
			i++
			if i >= len(args) {
				return nil, missing(a)
			}
			cfg.model = args[i]
		case "-n", "--max-count":
			i++
			if i >= len(args) {
				return nil, missing(a)
			}
			cfg.maxCount = args[i]
		case "--color":
			i++
			if i >= len(args) {
				return nil, missing(a)
			}
			cfg.color = args[i]
		case "--no-color":
			cfg.noColor = true
		case "-w", "--wrap":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
			}
		case "-f", "--format":
			i++
			if i >= len(args) {
				return nil, missing(a)
			}
			cfg.format = args[i]
		case "-r", "--reverse":
			cfg.reverse = true
		case "-l", "--local":
			cfg.local = true
		case "--svg":
			cfg.svg = true
		case "-d", "--debug":
			cfg.debug = true
		case "-S", "--sparse":
			cfg.sparse = true
		case "-s", "--style":
			i++
			if i >= len(args) {
				return nil, missing(a)
			}
			cfg.style = args[i]
		default:
			return nil, unexpected(a)
		}
	}
	return cfg, nil
}

func unexpected(arg string) error {
	return fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", arg)
}

func missing(arg string) error {
	return fmt.Errorf("error: a value is required for '%s' but none was supplied", arg)
}

func validateModel(m string) error {
	if m == "" || m == "none" || m == "simple" || m == "git-flow" {
		return nil
	}
	return fmt.Errorf("ERROR: No branching model named '%s' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow", m)
}

func runModel(cfg *config) error {
	if cfg.modelList {
		fmt.Println("none")
		fmt.Println("simple")
		fmt.Println("git-flow")
		return nil
	}
	root, err := repoRoot(cfg.path)
	if err != nil {
		return err
	}
	if cfg.modelArg == "" {
		m := readRepoModel(root)
		if m == "" {
			fmt.Print("No branching model set")
		} else {
			fmt.Print(m)
		}
		return nil
	}
	if err := validateModel(cfg.modelArg); err != nil {
		return err
	}
	path := filepath.Join(root, ".git", "git-graph.toml")
	if err := os.WriteFile(path, []byte("model = \""+cfg.modelArg+"\"\n"), 0644); err != nil {
		return err
	}
	fmt.Printf("Branching model set to '%s'", cfg.modelArg)
	return nil
}

func runGraph(cfg *config) error {
	if cfg.model == "" {
		if root, err := repoRoot(cfg.path); err == nil {
			cfg.model = readRepoModel(root)
		}
	}
	if cfg.model == "" {
		cfg.model = "git-flow"
	}
	if err := validateModel(cfg.model); err != nil {
		return err
	}
	if _, err := repoRoot(cfg.path); err != nil {
		return err
	}
	if cfg.svg {
		return runSVG(cfg)
	}
	out, err := gitLog(cfg)
	if err != nil {
		return err
	}
	out = styleGraph(out, cfg.style)
	if cfg.color == "always" && !cfg.noColor {
		out = colorize(out)
	}
	fmt.Print(out)
	return nil
}

func repoRoot(path string) (string, error) {
	if _, err := os.Stat(path); err != nil {
		return "", fmt.Errorf("ERROR: failed to resolve path '%s': %s\n       Navigate into a repository before running git-graph, or use option --path", path, err.Error())
	}
	cmd := exec.Command("git", "-C", path, "rev-parse", "--show-toplevel")
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("ERROR: could not find repository at '%s'\n       Navigate into a repository before running git-graph, or use option --path", path)
	}
	return strings.TrimSpace(string(out)), nil
}

func readRepoModel(root string) string {
	b, err := os.ReadFile(filepath.Join(root, ".git", "git-graph.toml"))
	if err != nil {
		return ""
	}
	re := regexp.MustCompile(`model\s*=\s*"([^"]+)"`)
	m := re.FindStringSubmatch(string(b))
	if len(m) == 2 {
		return m[1]
	}
	return ""
}

func gitLog(cfg *config) (string, error) {
	format := prettyFormat(cfg.format)
	args := []string{"-C", cfg.path, "log", "--graph", "--topo-order", "--decorate=short", "--date=default", "--pretty=format:" + format}
	if cfg.reverse {
		args = append(args, "--reverse")
	}
	if cfg.maxCount != "" {
		if _, err := strconv.Atoi(cfg.maxCount); err != nil {
			return "", errors.New("error: invalid value for '--max-count <n>'")
		}
		args = append(args, "-n", cfg.maxCount)
	}
	if cfg.local {
		args = append(args, "--branches", "--tags")
	} else {
		args = append(args, "--all")
	}
	cmd := exec.Command("git", args...)
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	out, err := cmd.Output()
	if err != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = err.Error()
		}
		return "", errors.New(msg)
	}
	s := string(out)
	if s != "" && !strings.HasSuffix(s, "\n") {
		s += "\n"
	}
	return s, nil
}

func prettyFormat(f string) string {
	switch f {
	case "", "oneline", "o":
		return "%h%d %s"
	case "short", "s":
		return "commit %H%d%nAuthor: %an <%ae>%n%n    %s%n"
	case "medium", "m":
		return "commit %H%d%nAuthor: %an <%ae>%nDate:   %ad%n%n    %s%n%+b"
	case "full", "f":
		return "commit %H%d%nAuthor: %an <%ae>%nCommit: %cn <%ce>%nDate:   %ad%n%n    %s%n%+b"
	default:
		return f
	}
}

func styleGraph(in, style string) string {
	lines := strings.SplitAfter(in, "\n")
	var b strings.Builder
	for _, line := range lines {
		if line == "" {
			continue
		}
		b.WriteString(styleLine(line, style))
	}
	return b.String()
}

func styleLine(line, style string) string {
	nl := strings.HasSuffix(line, "\n")
	raw := strings.TrimSuffix(line, "\n")
	i := 0
	for i < len(raw) {
		c := raw[i]
		if c == ' ' || c == '*' || c == '|' || c == '\\' || c == '/' || c == '_' || c == '-' {
			i++
			continue
		}
		break
	}
	prefix, rest := raw[:i], raw[i:]
	prefix = strings.ReplaceAll(prefix, "*", commitGlyph(style))
	prefix = strings.ReplaceAll(prefix, "|", vertGlyph(style))
	prefix = strings.ReplaceAll(prefix, "\\", downRightGlyph(style))
	prefix = strings.ReplaceAll(prefix, "/", upRightGlyph(style))
	prefix = strings.ReplaceAll(prefix, "_", horizGlyph(style))
	prefix = strings.ReplaceAll(prefix, "-", horizGlyph(style))
	if strings.TrimSpace(prefix) == commitGlyph(style) {
		prefix = " " + commitGlyph(style) + "  "
	} else if rest != "" {
		prefix = " " + prefix
		if strings.HasSuffix(prefix, " ") {
			prefix += " "
		}
	} else if strings.TrimSpace(prefix) != "" {
		prefix = " " + strings.TrimRight(prefix, " ") + "  "
	}
	if nl {
		return prefix + rest + "\n"
	}
	return prefix + rest
}

func commitGlyph(style string) string {
	switch strings.ToLower(style) {
	case "ascii", "a":
		return "*"
	case "round", "r":
		return "●"
	default:
		return "●"
	}
}

func vertGlyph(style string) string {
	switch strings.ToLower(style) {
	case "ascii", "a":
		return "|"
	case "bold", "b":
		return "┃"
	case "double", "d":
		return "║"
	default:
		return "│"
	}
}

func horizGlyph(style string) string {
	switch strings.ToLower(style) {
	case "ascii", "a":
		return "-"
	case "bold", "b":
		return "━"
	case "double", "d":
		return "═"
	default:
		return "─"
	}
}

func downRightGlyph(style string) string {
	switch strings.ToLower(style) {
	case "ascii", "a":
		return "."
	case "bold", "b":
		return "┓"
	case "double", "d":
		return "╗"
	default:
		return "┐"
	}
}

func upRightGlyph(style string) string {
	switch strings.ToLower(style) {
	case "ascii", "a":
		return "'"
	case "bold", "b":
		return "┛"
	case "double", "d":
		return "╝"
	default:
		return "┘"
	}
}

func colorize(s string) string {
	lines := strings.SplitAfter(s, "\n")
	for i, l := range lines {
		if strings.TrimSpace(l) == "" {
			continue
		}
		lines[i] = "\033[38;5;12m" + l + "\033[0m"
	}
	return strings.Join(lines, "")
}

func runSVG(cfg *config) error {
	args := []string{"-C", cfg.path, "rev-list", "--all"}
	if cfg.maxCount != "" {
		args = append(args, "-n", cfg.maxCount)
	}
	cmd := exec.Command("git", args...)
	out, err := cmd.Output()
	if err != nil {
		return err
	}
	count := 0
	for _, l := range strings.Split(strings.TrimSpace(string(out)), "\n") {
		if strings.TrimSpace(l) != "" {
			count++
		}
	}
	if count == 0 {
		count = 1
	}
	h := count*30 + 15
	fmt.Printf("<svg height=\"%d\" viewBox=\"0 0 30 %d\" width=\"30\" xmlns=\"http://www.w3.org/2000/svg\">\n", h, h)
	if count > 1 {
		fmt.Printf("<line stroke=\"blue\" stroke-width=\"1\" x1=\"15\" x2=\"15\" y1=\"15\" y2=\"%d\"/>\n", 15+(count-1)*30)
	}
	for i := 0; i < count; i++ {
		fmt.Printf("<circle cx=\"15\" cy=\"%d\" fill=\"blue\" r=\"4\" stroke=\"blue\" stroke-width=\"1\"/>\n", 15+i*30)
	}
	fmt.Println("</svg>")
	return nil
}

func printShortHelp() {
	fmt.Print(`Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version
`)
}

func printLongHelp() {
	printShortHelp()
	fmt.Print(`
Formatting placeholders include %H, %h, %P, %p, %d, %s, %b, %B, %an, %ae, %ad, %as, %cn, %ce, %cd and %cs.
`)
}

func printModelHelp() {
	fmt.Print(`Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help
`)
}
