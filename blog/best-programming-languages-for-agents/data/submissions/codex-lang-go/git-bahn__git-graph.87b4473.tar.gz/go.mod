module gitgraphclone

go 1.21
