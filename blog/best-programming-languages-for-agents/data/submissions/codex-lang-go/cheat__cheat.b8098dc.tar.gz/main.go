package main

import (
	"bufio"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/tabwriter"
)

const version = "5.1.0"

type CheatPath struct {
	Name     string
	Path     string
	Tags     []string
	Readonly bool
}

type Config struct {
	Path       string
	Editor     string
	Pager      string
	Colorize   bool
	CheatPaths []CheatPath
}

type Sheet struct {
	Title string
	File  string
	Tags  []string
	Body  string
	Path  CheatPath
}

type Options struct {
	all, brief, colorize, dirs, list, regex, tags, update, version, conf, init bool
	edit, path, search, tag, rm, completion                               string
	args                                                                 []string
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	opts, err := parseArgs(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if opts.version {
		fmt.Println(version)
		return 0
	}
	if opts.init {
		fmt.Print(defaultConfig())
		return 0
	}
	if opts.completion != "" {
		return completion(opts.completion)
	}
	if wantsHelp(args) {
		fmt.Print(helpText())
		return 0
	}

	cfg, err := loadConfig()
	if opts.conf {
		if err != nil {
			return missingConfig()
		}
		fmt.Println(cfg.Path)
		return 0
	}
	if err != nil {
		return missingConfig()
	}
	if opts.colorize {
		cfg.Colorize = true
	}

	sheets, err := collectSheets(cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	sheets, err = filterSheets(sheets, cfg, opts)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}

	switch {
	case opts.dirs:
		printDirs(cfg)
	case opts.tags:
		printTags(sheets)
	case opts.list || opts.brief:
		if len(sheets) == 0 {
			return 2
		}
		printList(sheets, opts.brief)
	case opts.search != "":
		if err := printSearch(sheets, opts.search, opts.regex, cfg.Colorize); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
	case opts.rm != "":
		return removeSheet(sheets, opts.rm)
	case opts.edit != "":
		return editSheet(sheets, cfg, opts)
	case opts.update:
		return updatePaths(cfg, opts.path)
	default:
		if len(opts.args) == 0 {
			fmt.Print(helpText())
			return 0
		}
		return viewSheet(sheets, opts.args[0], cfg.Colorize)
	}
	return 0
}

func parseArgs(args []string) (Options, error) {
	var o Options
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func(name string) (string, error) {
			if strings.Contains(a, "=") {
				return strings.SplitN(a, "=", 2)[1], nil
			}
			i++
			if i >= len(args) {
				return "", fmt.Errorf("flag needs an argument: %s", name)
			}
			return args[i], nil
		}
		switch {
		case a == "-a" || a == "--all":
			o.all = true
		case a == "-b" || a == "--brief":
			o.brief = true
		case a == "-c" || a == "--colorize":
			o.colorize = true
		case a == "-d" || a == "--directories":
			o.dirs = true
		case a == "-h" || a == "--help":
		case a == "--init":
			o.init = true
		case a == "--conf":
			o.conf = true
		case a == "-l" || a == "--list":
			o.list = true
		case a == "-r" || a == "--regex":
			o.regex = true
		case a == "-T" || a == "--tags":
			o.tags = true
		case a == "-u" || a == "--update":
			o.update = true
		case a == "-v" || a == "--version":
			o.version = true
		case a == "-e" || a == "--edit" || strings.HasPrefix(a, "--edit="):
			v, err := next("--edit")
			if err != nil {
				return o, err
			}
			o.edit = v
		case a == "-p" || a == "--path" || strings.HasPrefix(a, "--path="):
			v, err := next("--path")
			if err != nil {
				return o, err
			}
			o.path = v
		case a == "-s" || a == "--search" || strings.HasPrefix(a, "--search="):
			v, err := next("--search")
			if err != nil {
				return o, err
			}
			o.search = v
		case a == "-t" || a == "--tag" || strings.HasPrefix(a, "--tag="):
			v, err := next("--tag")
			if err != nil {
				return o, err
			}
			o.tag = v
		case a == "--rm" || strings.HasPrefix(a, "--rm="):
			v, err := next("--rm")
			if err != nil {
				return o, err
			}
			o.rm = v
		case a == "--completion" || strings.HasPrefix(a, "--completion="):
			v, err := next("--completion")
			if err != nil {
				return o, err
			}
			o.completion = v
		case strings.HasPrefix(a, "-"):
			return o, fmt.Errorf("unknown flag: %s", a)
		default:
			o.args = append(o.args, a)
		}
	}
	return o, nil
}

func wantsHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			return true
		}
	}
	return false
}

func loadConfig() (Config, error) {
	paths := configCandidates()
	for _, p := range paths {
		if p == "" {
			continue
		}
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			cfg, err := parseConfig(p)
			if err != nil {
				return cfg, err
			}
			return cfg, nil
		}
	}
	return Config{}, os.ErrNotExist
}

func configCandidates() []string {
	if p := os.Getenv("CHEAT_CONFIG_PATH"); p != "" {
		return []string{expandPath(p)}
	}
	home, _ := os.UserHomeDir()
	var out []string
	if xdg := os.Getenv("XDG_CONFIG_HOME"); xdg != "" {
		out = append(out, filepath.Join(expandPath(xdg), "cheat", "conf.yml"))
	}
	if home != "" {
		out = append(out, filepath.Join(home, ".config", "cheat", "conf.yml"))
		out = append(out, filepath.Join(home, ".cheat", "conf.yml"))
	}
	out = append(out, "/etc/cheat/conf.yml")
	return out
}

func parseConfig(path string) (Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Config{}, err
	}
	cfg := Config{Path: path, Editor: "EDITOR_PATH", Pager: "/usr/bin/pager"}
	lines := strings.Split(string(b), "\n")
	inPaths := false
	var cur *CheatPath
	flush := func() {
		if cur != nil {
			cur.Path = expandPath(cur.Path)
			cfg.CheatPaths = append(cfg.CheatPaths, *cur)
		}
		cur = nil
	}
	for _, raw := range lines {
		line := strings.TrimSpace(stripComment(raw))
		if line == "" || line == "---" {
			continue
		}
		if line == "cheatpaths:" {
			inPaths = true
			continue
		}
		if !inPaths {
			k, v, ok := splitKV(line)
			if !ok {
				continue
			}
			switch k {
			case "editor":
				cfg.Editor = unquote(v)
			case "pager":
				cfg.Pager = unquote(v)
			case "colorize":
				cfg.Colorize = parseBool(v)
			}
			continue
		}
		if strings.HasPrefix(line, "- ") {
			flush()
			cur = &CheatPath{}
			line = strings.TrimSpace(strings.TrimPrefix(line, "- "))
			if line == "" {
				continue
			}
		}
		if cur == nil {
			continue
		}
		k, v, ok := splitKV(line)
		if !ok {
			continue
		}
		switch k {
		case "name":
			cur.Name = unquote(v)
		case "path":
			cur.Path = unquote(v)
		case "tags":
			cur.Tags = parseTags(v)
		case "readonly":
			cur.Readonly = parseBool(v)
		}
	}
	flush()
	return cfg, nil
}

func stripComment(s string) string {
	inS, inD := false, false
	for i, r := range s {
		switch r {
		case '\'':
			if !inD {
				inS = !inS
			}
		case '"':
			if !inS {
				inD = !inD
			}
		case '#':
			if !inS && !inD {
				return s[:i]
			}
		}
	}
	return s
}

func splitKV(s string) (string, string, bool) {
	parts := strings.SplitN(s, ":", 2)
	if len(parts) != 2 {
		return "", "", false
	}
	return strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1]), true
}

func parseTags(v string) []string {
	v = strings.TrimSpace(v)
	v = strings.TrimPrefix(v, "[")
	v = strings.TrimSuffix(v, "]")
	if v == "" {
		return nil
	}
	parts := strings.Split(v, ",")
	var tags []string
	for _, p := range parts {
		p = strings.TrimSpace(unquote(p))
		if p != "" {
			tags = append(tags, p)
		}
	}
	return tags
}

func parseBool(v string) bool {
	v = strings.ToLower(strings.TrimSpace(v))
	return v == "true" || v == "yes" || v == "1"
}

func unquote(v string) string {
	v = strings.TrimSpace(v)
	if u, err := strconv.Unquote(v); err == nil {
		return u
	}
	return strings.Trim(v, `"'`)
}

func expandPath(p string) string {
	if strings.HasPrefix(p, "~/") {
		if h, err := os.UserHomeDir(); err == nil {
			return filepath.Join(h, p[2:])
		}
	}
	return os.ExpandEnv(p)
}

func collectSheets(cfg Config) ([]Sheet, error) {
	paths := append([]CheatPath{}, cfg.CheatPaths...)
	if p := nearestDotCheat(); p != "" {
		paths = append(paths, CheatPath{Name: ".cheat", Path: p, Tags: []string{".cheat"}})
	}
	var sheets []Sheet
	for _, cp := range paths {
		filepath.WalkDir(cp.Path, func(path string, d fs.DirEntry, err error) error {
			if err != nil || d.IsDir() {
				if d != nil && d.IsDir() && strings.HasPrefix(d.Name(), ".git") {
					return filepath.SkipDir
				}
				return nil
			}
			if strings.HasPrefix(d.Name(), ".") || strings.Contains(path, string(filepath.Separator)+".git"+string(filepath.Separator)) {
				return nil
			}
			rel, err := filepath.Rel(cp.Path, path)
			if err != nil {
				return nil
			}
			rel = filepath.ToSlash(rel)
			bodyBytes, err := os.ReadFile(path)
			if err != nil {
				return nil
			}
			body, ftags := parseFrontmatter(string(bodyBytes))
			tags := uniqueSorted(append(append([]string{}, cp.Tags...), ftags...))
			sheets = append(sheets, Sheet{Title: rel, File: path, Tags: tags, Body: body, Path: cp})
			return nil
		})
	}
	sort.SliceStable(sheets, func(i, j int) bool {
		if sheets[i].Title == sheets[j].Title {
			return sheets[i].File < sheets[j].File
		}
		return sheets[i].Title < sheets[j].Title
	})
	return sheets, nil
}

func nearestDotCheat() string {
	dir, err := os.Getwd()
	if err != nil {
		return ""
	}
	for {
		p := filepath.Join(dir, ".cheat")
		if st, err := os.Stat(p); err == nil && st.IsDir() {
			return p
		}
		next := filepath.Dir(dir)
		if next == dir {
			return ""
		}
		dir = next
	}
}

func parseFrontmatter(s string) (string, []string) {
	if !strings.HasPrefix(s, "---\n") && strings.TrimSpace(s) != "---" {
		return s, nil
	}
	lines := strings.Split(s, "\n")
	var tags []string
	for i := 1; i < len(lines); i++ {
		if strings.TrimSpace(lines[i]) == "---" {
			return strings.Join(lines[i+1:], "\n"), tags
		}
		k, v, ok := splitKV(strings.TrimSpace(lines[i]))
		if ok && k == "tags" {
			tags = append(tags, parseTags(v)...)
		}
	}
	return s, nil
}

func filterSheets(sheets []Sheet, cfg Config, opts Options) ([]Sheet, error) {
	if opts.path != "" {
		found := false
		for _, cp := range cfg.CheatPaths {
			if cp.Name == opts.path {
				found = true
				break
			}
		}
		if !found {
			return nil, fmt.Errorf("invalid option --path: cheatpath does not exist: %s", opts.path)
		}
	}
	var out []Sheet
	for _, s := range sheets {
		if opts.path != "" && s.Path.Name != opts.path {
			continue
		}
		if opts.tag != "" && !has(s.Tags, opts.tag) {
			continue
		}
		if (opts.list || opts.brief) && len(opts.args) > 0 && !strings.Contains(s.Title, opts.args[0]) {
			continue
		}
		out = append(out, s)
	}
	return out, nil
}

func printDirs(cfg Config) {
	max := 0
	for _, cp := range cfg.CheatPaths {
		if len(cp.Name) > max {
			max = len(cp.Name)
		}
	}
	for _, cp := range cfg.CheatPaths {
		fmt.Printf("%s:%*s%s\n", cp.Name, max-len(cp.Name)+1, "", cp.Path)
	}
}

func printTags(sheets []Sheet) {
	set := map[string]bool{}
	for _, s := range sheets {
		for _, t := range s.Tags {
			set[t] = true
		}
	}
	var tags []string
	for t := range set {
		tags = append(tags, t)
	}
	sort.Strings(tags)
	for _, t := range tags {
		fmt.Println(t)
	}
}

func printList(sheets []Sheet, brief bool) {
	w := tabwriter.NewWriter(os.Stdout, 0, 0, 1, ' ', 0)
	if brief {
		fmt.Fprintln(w, "title:\ttags:")
		for _, s := range sheets {
			fmt.Fprintf(w, "%s\t%s\n", s.Title, strings.Join(s.Tags, ","))
		}
	} else {
		fmt.Fprintln(w, "title:\tfile:\ttags:")
		for _, s := range sheets {
			fmt.Fprintf(w, "%s\t%s\t%s\n", s.Title, s.File, strings.Join(s.Tags, ","))
		}
	}
	w.Flush()
}

func printSearch(sheets []Sheet, phrase string, isRegex, color bool) error {
	var re *regexp.Regexp
	var err error
	if isRegex {
		re, err = regexp.Compile(phrase)
		if err != nil {
			return fmt.Errorf("failed to compile regexp: %s, %v", phrase, err)
		}
	}
	firstBlock := true
	for _, s := range sheets {
		matched := false
		sc := bufio.NewScanner(strings.NewReader(s.Body))
		for sc.Scan() {
			line := sc.Text()
			ok := false
			if isRegex {
				ok = re.MatchString(line)
			} else {
				ok = strings.Contains(strings.ToLower(line), strings.ToLower(phrase))
			}
			if ok {
				matched = true
				break
			}
		}
		if !matched {
			continue
		}
		if !firstBlock {
			fmt.Println()
		}
		firstBlock = false
		fmt.Printf("%s (%s)\n", s.Title, s.Path.Name)
		body := s.Body
		if color {
			if isRegex {
				body = re.ReplaceAllStringFunc(body, ansi)
			} else {
				body = highlightAllLiteral(body, phrase)
			}
		}
		lines := strings.SplitAfter(body, "\n")
		for _, part := range lines {
			if part == "" {
				continue
			}
			fmt.Print("\t", part)
		}
	}
	return nil
}

func highlightLiteral(s, phrase string) string {
	lower, p := strings.ToLower(s), strings.ToLower(phrase)
	idx := strings.Index(lower, p)
	if idx < 0 {
		return s
	}
	return s[:idx] + ansi(s[idx:idx+len(phrase)]) + s[idx+len(phrase):]
}

func highlightAllLiteral(s, phrase string) string {
	if phrase == "" {
		return s
	}
	var b strings.Builder
	rest := s
	lphrase := strings.ToLower(phrase)
	for {
		idx := strings.Index(strings.ToLower(rest), lphrase)
		if idx < 0 {
			b.WriteString(rest)
			break
		}
		b.WriteString(rest[:idx])
		b.WriteString(ansi(rest[idx : idx+len(phrase)]))
		rest = rest[idx+len(phrase):]
	}
	return b.String()
}

func ansi(s string) string { return "\033[38;5;196m" + s + "\033[0m" }

func viewSheet(sheets []Sheet, title string, color bool) int {
	var chosen *Sheet
	for i := range sheets {
		if sheets[i].Title == title {
			chosen = &sheets[i]
		}
	}
	if chosen == nil {
		fmt.Printf("No cheatsheet found for '%s'.\n", title)
		return 2
	}
	body := chosen.Body
	if color {
		body = "\033[38;5;231m" + strings.TrimRight(body, "\n") + "\033[0m\n"
	}
	fmt.Print(body)
	return 0
}

func removeSheet(sheets []Sheet, title string) int {
	var chosen *Sheet
	for i := range sheets {
		if sheets[i].Title == title {
			chosen = &sheets[i]
		}
	}
	if chosen == nil {
		fmt.Printf("No cheatsheet found for '%s'.\n", title)
		return 2
	}
	if err := os.Remove(chosen.File); err != nil {
		fmt.Fprintf(os.Stderr, "failed to remove cheatsheet: %v\n", err)
		return 1
	}
	return 0
}

func editSheet(sheets []Sheet, cfg Config, opts Options) int {
	title := opts.edit
	var file string
	for i := range sheets {
		if sheets[i].Title == title && (opts.path == "" || sheets[i].Path.Name == opts.path) && !sheets[i].Path.Readonly {
			file = sheets[i].File
		}
	}
	if file == "" {
		var cp *CheatPath
		for i := len(cfg.CheatPaths) - 1; i >= 0; i-- {
			if (opts.path == "" || cfg.CheatPaths[i].Name == opts.path) && !cfg.CheatPaths[i].Readonly {
				cp = &cfg.CheatPaths[i]
				break
			}
		}
		if cp == nil {
			fmt.Fprintln(os.Stderr, "failed to edit cheatsheet: no writeable cheatpath found")
			return 1
		}
		file = filepath.Join(cp.Path, filepath.FromSlash(title))
		if err := os.MkdirAll(filepath.Dir(file), 0755); err != nil {
			fmt.Fprintf(os.Stderr, "failed to edit cheatsheet: %v\n", err)
			return 1
		}
		if _, err := os.Stat(file); errors.Is(err, os.ErrNotExist) {
			os.WriteFile(file, []byte{}, 0644)
		}
	}
	editor := os.Getenv("VISUAL")
	if editor == "" {
		editor = os.Getenv("EDITOR")
	}
	if editor == "" {
		editor = cfg.Editor
	}
	fields := strings.Fields(editor)
	if len(fields) == 0 || fields[0] == "EDITOR_PATH" {
		fmt.Fprintln(os.Stderr, "failed to edit cheatsheet: editor is not configured")
		return 1
	}
	cmd := exec.Command(fields[0], append(fields[1:], file)...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := cmd.Run(); err != nil {
		fmt.Fprintf(os.Stderr, "failed to edit cheatsheet: %v\n", err)
		return 1
	}
	return 0
}

func updatePaths(cfg Config, pathName string) int {
	for _, cp := range cfg.CheatPaths {
		if pathName != "" && cp.Name != pathName {
			continue
		}
		if _, err := os.Stat(filepath.Join(cp.Path, ".git")); err == nil {
			cmd := exec.Command("git", "-C", cp.Path, "pull")
			cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
			if err := cmd.Run(); err != nil {
				return 1
			}
		}
	}
	return 0
}

func has(xs []string, x string) bool {
	for _, v := range xs {
		if v == x {
			return true
		}
	}
	return false
}

func uniqueSorted(xs []string) []string {
	m := map[string]bool{}
	for _, x := range xs {
		if x != "" {
			m[x] = true
		}
	}
	var out []string
	for x := range m {
		out = append(out, x)
	}
	sort.Strings(out)
	return out
}

func missingConfig() int {
	fmt.Print("A config file was not found. Would you like to create one now? [Y/n]: ")
	fmt.Fprintln(os.Stderr, "failed to create config: failed to prompt: EOF")
	return 1
}

func completion(shell string) int {
	switch shell {
	case "bash":
		fmt.Println("# bash completion V2 for cheat                                -*- shell-script -*-")
		fmt.Println("complete -o default -F __start_cheat cheat")
	case "zsh":
		fmt.Println("#compdef cheat")
		fmt.Println("_arguments '*:cheatsheet:_files'")
	case "fish":
		fmt.Println("complete -c cheat -f")
	case "powershell":
		fmt.Println("Register-ArgumentCompleter -CommandName cheat -ScriptBlock { param($wordToComplete) }")
	default:
		fmt.Fprintf(os.Stderr, "unsupported shell: %s (valid: bash, zsh, fish, powershell)\n", shell)
		return 1
	}
	return 0
}

func defaultConfig() string {
	home, _ := os.UserHomeDir()
	base := filepath.Join(home, ".config", "cheat", "cheatsheets")
	return fmt.Sprintf(`---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: EDITOR_PATH

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
# Options are available here:
#   https://github.com/alecthomas/chroma/tree/master/styles
style: monokai

# Which 'chroma' "formatter" should be applied?
# One of: "terminal", "terminal256", "terminal16m"
formatter: terminal256

# Through which pager should output be piped?
# 'less -FRX' is recommended on Unix systems
# 'more' is recommended on Windows
pager: /usr/bin/pager

# The paths at which cheatsheets are available. Tags associated with a cheatpath
# are automatically attached to all cheatsheets residing on that path.
#
# Whenever cheatsheets share the same title (like 'tar'), the most local
# cheatsheets (those which come later in this file) take precedence over the
# less local sheets. This allows you to create your own "overides" for
# "upstream" cheatsheets.
#
# But what if you want to view the "upstream" cheatsheets instead of your own?
# Cheatsheets may be filtered by 'tags' in combination with the '--tag' flag.
# 
# Example: 'cheat tar --tag=community' will display the 'tar' cheatsheet that
# is tagged as 'community' rather than your own.
#
# Paths that come earlier are considered to be the most "global", and paths
# that come later are considered to be the most "local". The most "local" paths
# take precedence.
#
# See: https://github.com/cheat/cheat/blob/master/doc/cheat.1.md#cheatpaths
cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: %s
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: %s
    tags: [ work ]
    readonly: false

  # Community cheatsheets (https://github.com/cheat/cheatsheets):
  # To install: git clone https://github.com/cheat/cheatsheets %s
  #- name: community
  #  path: %s
  #  tags: [ community ]
  #  readonly: true

  # You can also use glob patterns to automatically load cheatsheets from all
  # directories that match.
  #
  # Example: overload cheatsheets for projects under ~/src/github.com/example/*/
  #- name: example-projects
  #  path: ~/src/github.com/example/**/.cheat
  #  tags: [ example ]
  #  readonly: true
`, filepath.Join(base, "personal"), filepath.Join(base, "work"), filepath.Join(base, "community"), filepath.Join(base, "community"))
}

func helpText() string {
	return `cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number
`
}
