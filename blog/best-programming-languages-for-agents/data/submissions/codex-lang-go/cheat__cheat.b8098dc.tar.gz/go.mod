module cheatclone

go 1.21
