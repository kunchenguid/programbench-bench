module codesnap-reimpl

go 1.21
