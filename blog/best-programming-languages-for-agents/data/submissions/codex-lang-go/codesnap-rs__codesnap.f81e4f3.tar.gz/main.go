package main

import (
	"bytes"
	"errors"
	"fmt"
	"html"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
)

type options struct {
	output      string
	fromFile    string
	code        *string
	fromImage   string
	clipboard   bool
	execArgs    []string
	skip        bool
	rangeSpec   string
	silent      bool
	lineNumbers bool
	startLine   int
	title       string
	watermark   string
	background  string
	border      bool
}

const longHelp = `CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the ` + "`from_file`" + ` option as the input, and you just want to display part of the code snippet

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is / 

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of ` + "`--raw-highlight-lines`" + ` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

  -l, --language <LANGUAGE>
          Set the language of the code snippet, If you using the ` + "`file`" + ` option, CodeSnap will automatically detect the language from the file extension

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --has-border
          Display window border

      --title <TITLE>
          Set title of the window

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`

const shortHelp = `CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot
  -c, --from-code [<Code>]
          Code snippet for snapshot
  -i, --from-image [<Image>]
          
      --from-clipboard
          
  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
      --silent
          
  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet
      --skip
          Skip run the command to get output, just take the command as the input
      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the ` + "`from_file`" + ` option as the input, and you just want to display part of the code snippet
      --has-line-number
          
      --title <TITLE>
          Set title of the window
      --type <TYPE>
          [default: image] [possible values: ascii, image]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`

func main() {
	opts, typ, err := parse(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if typ == "help" {
		fmt.Print(longHelp)
		return
	}
	if typ == "short-help" {
		fmt.Print(shortHelp)
		return
	}
	if typ == "version" {
		fmt.Println("codesnap-cli 0.13.1")
		return
	}
	if opts.output == "" {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:\n  --output <OUTPUT>\n\nUsage: codesnap --output <OUTPUT>\n\nFor more information, try '--help'.")
		os.Exit(2)
	}
	if opts.output == "clipboard" || typ == "ascii" || opts.clipboard {
		if typ == "ascii" {
			fmt.Fprintln(os.Stderr, "\033[33m[WARN]\033[0m ASCII snapshot only supports copying to clipboard")
			return
		}
		fmt.Fprintln(os.Stderr, "\033[31m[ERROR]\033[0m Unknown error while interacting with the clipboard: X11 server connection timed out because it was unreachable")
		os.Exit(1)
	}
	code, err := collectCode(opts)
	if err != nil {
		fmt.Fprintf(os.Stderr, "\033[31m[ERROR]\033[0m %s\n", err)
		os.Exit(1)
	}
	if strings.TrimSpace(code) == "" {
		fmt.Fprintln(os.Stderr, "\033[31m[ERROR]\033[0m No code snippet provided")
		os.Exit(1)
	}
	code, err = applyRange(code, opts.rangeSpec)
	if err != nil {
		fmt.Fprintf(os.Stderr, "\033[31m[ERROR]\033[0m %s\n", err)
		os.Exit(1)
	}
	if err := writeOutput(opts, code); err != nil {
		fmt.Fprintf(os.Stderr, "\033[31m[ERROR]\033[0m %s\n", err)
		os.Exit(1)
	}
	if !opts.silent {
		fmt.Printf("\033[32m[SUCCESS]\033[0m Snapshot saved to %s successful!\n", opts.output)
	}
}

func parse(args []string) (options, string, error) {
	opts := options{startLine: 1, background: "#abb8c3"}
	typ := "image"
	valueOpts := map[string]bool{
		"--from-file": true, "--output": true, "--range": true, "--start-line-number": true,
		"--title": true, "--watermark": true, "--background": true, "--type": true,
		"--from-image": true, "--config": true, "--language": true, "--file-path": true,
		"--code-font-family": true, "--code-theme": true, "--has-breadcrumbs": true,
		"--breadcrumbs-separator": true, "--breadcrumbs-font-family": true, "--breadcrumbs-color": true,
		"--line-number-color": true, "--delete-line-color": true, "--add-line-color": true,
		"--highlight-range": true, "--highlight-range-color": true, "--raw-highlight-lines": true,
		"--watermark-font-family": true, "--watermark-color": true, "--shadow-radius": true,
		"--shadow-color": true, "--mac-window-bar": true, "--border-color": true,
		"--margin-x": true, "--margin-y": true, "--scale-factor": true, "--title-font-family": true,
		"--title-color": true,
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help":
			return opts, "help", nil
		case "-h":
			return opts, "short-help", nil
		case "--version", "-V":
			return opts, "version", nil
		case "-f", "--from-file":
			i++; if i >= len(args) { return opts, "", fmt.Errorf("error: a value is required for '%s <FROM_FILE>' but none was supplied", a) }
			opts.fromFile = args[i]
		case "-o", "--output":
			i++; if i >= len(args) { return opts, "", fmt.Errorf("error: a value is required for '%s <OUTPUT>' but none was supplied", a) }
			opts.output = args[i]
		case "-c", "--from-code":
			var s string
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				s = args[i]
			} else {
				b, _ := io.ReadAll(os.Stdin)
				s = string(b)
			}
			opts.code = &s
		case "-i", "--from-image":
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				opts.fromImage = args[i]
			}
		case "--from-clipboard":
			opts.clipboard = true
		case "-e", "--execute":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				opts.execArgs = append(opts.execArgs, args[i])
			}
		case "--skip":
			opts.skip = true
		case "--silent":
			opts.silent = true
		case "--has-line-number":
			opts.lineNumbers = true
		case "--has-border":
			opts.border = true
		case "-w", "--watermark":
			i++; if i < len(args) { opts.watermark = args[i] }
		case "--title":
			i++; if i < len(args) { opts.title = args[i] }
		case "--range":
			i++; if i < len(args) { opts.rangeSpec = args[i] }
		case "--start-line-number":
			i++; if i < len(args) { opts.startLine, _ = strconv.Atoi(args[i]) }
		case "--background":
			i++; if i < len(args) { opts.background = args[i] }
		case "--type":
			i++; if i < len(args) { typ = args[i] }
		case "-a", "--add-line", "-d", "--delete-line":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
			}
		default:
			if valueOpts[a] {
				i++
			} else if strings.HasPrefix(a, "-") {
				return opts, "", fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: codesnap [OPTIONS] --output <OUTPUT>\n\nFor more information, try '--help'.", a)
			}
		}
	}
	return opts, typ, nil
}

func collectCode(opts options) (string, error) {
	switch {
	case opts.code != nil:
		return *opts.code, nil
	case opts.fromFile != "":
		b, err := os.ReadFile(opts.fromFile)
		return string(b), err
	case len(opts.execArgs) > 0:
		if opts.skip {
			return strings.Join(opts.execArgs, " "), nil
		}
		cmd := exec.Command(opts.execArgs[0], opts.execArgs[1:]...)
		var out bytes.Buffer
		cmd.Stdout = &out
		cmd.Stderr = &out
		err := cmd.Run()
		if err != nil && out.Len() == 0 {
			return "", err
		}
		return out.String(), nil
	case opts.fromImage != "":
		return "", errors.New("Invalid PNG signature.")
	default:
		return "", nil
	}
}

func applyRange(code, spec string) (string, error) {
	if spec == "" {
		return code, nil
	}
	lines := strings.Split(strings.TrimRight(code, "\n"), "\n")
	start, end := 1, len(lines)
	if strings.Contains(spec, ":") {
		parts := strings.SplitN(spec, ":", 2)
		if parts[0] != "" {
			n, err := strconv.Atoi(parts[0]); if err != nil { return code, err }
			start = n
		}
		if parts[1] != "" {
			n, err := strconv.Atoi(parts[1]); if err != nil { return code, err }
			end = n
		}
	} else {
		n, err := strconv.Atoi(spec); if err != nil { return code, err }
		start, end = n, n
	}
	if start < 1 { start = 1 }
	if end < start || start > len(lines) {
		return "", nil
	}
	if end > len(lines) { end = len(lines) }
	return strings.Join(lines[start-1:end], "\n"), nil
}

func writeOutput(opts options, code string) error {
	ext := strings.ToLower(filepath.Ext(opts.output))
	switch ext {
	case ".svg":
		return os.WriteFile(opts.output, []byte(renderSVG(opts, code)), 0644)
	case ".png":
		return writePNG(opts.output, code)
	default:
		return errors.New("Unsupported output format")
	}
}

func renderSVG(opts options, code string) string {
	lines := strings.Split(strings.TrimRight(code, "\n"), "\n")
	maxLen := 1
	for _, l := range lines {
		if len([]rune(l)) > maxLen {
			maxLen = len([]rune(l))
		}
	}
	lineH, charW := 24, 9
	numW := 0
	if opts.lineNumbers {
		numW = 48
	}
	titleH := 0
	if opts.title != "" {
		titleH = 34
	}
	w := 80 + numW + maxLen*charW
	if w < 360 { w = 360 }
	h := 90 + titleH + len(lines)*lineH
	bg := opts.background
	if bg == "" { bg = "#abb8c3" }
	var b strings.Builder
	fmt.Fprintf(&b, `<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">`, w, h, w, h)
	fmt.Fprintf(&b, `<rect width="100%%" height="100%%" fill="%s"/>`, html.EscapeString(bg))
	fmt.Fprintf(&b, `<rect x="30" y="30" width="%d" height="%d" rx="10" fill="#1e1e2e"`, w-60, h-60)
	if opts.border { b.WriteString(` stroke="#ffffff30"`)}
	b.WriteString(`/>`)
	b.WriteString(`<circle cx="55" cy="52" r="6" fill="#ff5f57"/><circle cx="76" cy="52" r="6" fill="#ffbd2e"/><circle cx="97" cy="52" r="6" fill="#28c840"/>`)
	y := 82
	if opts.title != "" {
		fmt.Fprintf(&b, `<text x="%d" y="62" font-family="Arial, sans-serif" font-size="14" fill="#cdd6f4">%s</text>`, w/2-len(opts.title)*4, html.EscapeString(opts.title))
	}
	for i, l := range lines {
		yy := y + titleH + i*lineH
		if opts.lineNumbers {
			fmt.Fprintf(&b, `<text x="52" y="%d" font-family="monospace" font-size="15" fill="#495162">%d</text>`, yy, opts.startLine+i)
		}
		fmt.Fprintf(&b, `<text x="%d" y="%d" font-family="monospace" font-size="16" fill="#cdd6f4">%s</text>`, 52+numW, yy, html.EscapeString(l))
	}
	if opts.watermark != "" {
		fmt.Fprintf(&b, `<text x="%d" y="%d" text-anchor="end" font-family="Arial, sans-serif" font-size="13" fill="#ffffff80">%s</text>`, w-42, h-42, html.EscapeString(opts.watermark))
	}
	b.WriteString(`</svg>`)
	return b.String()
}

func writePNG(path, code string) error {
	lines := strings.Split(strings.TrimRight(code, "\n"), "\n")
	w, h := 900, 160+len(lines)*26
	if h < 260 { h = 260 }
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	draw.Draw(img, img.Bounds(), &image.Uniform{color.RGBA{0xab, 0xb8, 0xc3, 0xff}}, image.Point{}, draw.Src)
	draw.Draw(img, image.Rect(50, 50, w-50, h-50), &image.Uniform{color.RGBA{0x1e, 0x1e, 0x2e, 0xff}}, image.Point{}, draw.Src)
	for i, c := range []color.RGBA{{0xff, 0x5f, 0x57, 0xff}, {0xff, 0xbd, 0x2e, 0xff}, {0x28, 0xc8, 0x40, 0xff}} {
		drawCircle(img, 78+i*28, 78, 8, c)
	}
	for i, l := range lines {
		y := 120 + i*26
		x := 82
		for _, r := range []rune(l) {
			if r != ' ' && r != '\t' {
				draw.Draw(img, image.Rect(x, y-14, x+7, y+2), &image.Uniform{color.RGBA{0xcd, 0xd6, 0xf4, 0xff}}, image.Point{}, draw.Src)
			}
			x += 10
			if x > w-90 { break }
		}
	}
	f, err := os.Create(path)
	if err != nil { return err }
	defer f.Close()
	return png.Encode(f, img)
}

func drawCircle(img *image.RGBA, cx, cy, r int, c color.RGBA) {
	for y := cy - r; y <= cy+r; y++ {
		for x := cx - r; x <= cx+r; x++ {
			dx, dy := x-cx, y-cy
			if dx*dx+dy*dy <= r*r {
				img.SetRGBA(x, y, c)
			}
		}
	}
}
