package main

import (
    "errors"
    "fmt"
    "math"
    "net"
    "os"
    "strconv"
    "strings"
    "time"

    "golang.org/x/net/icmp"
    "golang.org/x/net/ipv4"
    "golang.org/x/net/ipv6"
)

const helpText = "Usage:\n  pingu [OPTIONS] HOST\n\n`ping` command but with pingu\n\nApplication Options:\n  -c, --count=     Stop after <count> replies (default: 20)\n  -P, --privilege  Enable privileged mode\n  -V, --version    Show version\n\nHelp Options:\n  -h, --help       Show this help message\n"

var art = []string{
    " ...        .     ...   ..    ..     .........           ",
    " ...     ....          ..  ..      ... .....  .. ..      ",
    " ...    .......      ...         ... . ..... #######      ",
    ".....  ........ .###############.....  ... ##########.  .",
    " .... ........#####################.  ... ###########    ",
    "    .. ......#########################...###########     ",
    "      . ....############################.#########       ",
    "         ..#####################################         ",
    "          .###################################           ",
    "          ####################################           ",
    "         ######################################          ",
    "        ########################################         ",
    "       ##########################################        ",
    "      ############################################       ",
    "     ##############################################      ",
    "    ################################################     ",
    "   ##################################################    ",
    "  ####################################################   ",
    " ######################################################  ",
    "######################################################## ",
}

type options struct {
    count int
    privileged bool
    host string
}

type parseError struct { msg string }
func (e parseError) Error() string { return e.msg }

func main() {
    opt, handled, err := parseArgs(os.Args[1:])
    if handled { return }
    if err != nil {
        if pe, ok := err.(parseError); ok {
            if strings.HasPrefix(pe.msg, "unknown flag `") || strings.HasPrefix(pe.msg, "invalid argument") {
                fmt.Fprintln(os.Stderr, pe.msg)
                fmt.Fprintf(os.Stderr, "[ ERROR ] parse error: %s\n", pe.msg)
            } else {
                fmt.Fprintf(os.Stderr, "[ ERROR ] %s\n", pe.msg)
            }
        } else {
            fmt.Fprintf(os.Stderr, "[ ERROR ] %s\n", err)
        }
        os.Exit(1)
    }
    code := run(opt)
    os.Exit(code)
}

func intFromString(s string) (int, error) {
    v, err := strconv.ParseInt(s, 10, 0)
    return int(v), err
}

func parseArgs(args []string) (options, bool, error) {
    opt := options{count: 20}
    hosts := []string{}
    for i := 0; i < len(args); i++ {
        a := args[i]
        switch {
        case a == "-h" || a == "--help":
            fmt.Print(helpText)
            return opt, true, nil
        case a == "-V" || a == "--version":
            fmt.Println("pingu: v-rev9c2e3df")
            return opt, true, nil
        case a == "-P" || a == "--privilege":
            opt.privileged = true
        case a == "-c" || a == "--count":
            if i+1 >= len(args) {
                return opt, false, parseError{fmt.Sprintf("expected argument for flag `%s'", a)}
            }
            i++
            n, e := intFromString(args[i])
            if e != nil {
                return opt, false, parseError{fmt.Sprintf("invalid argument for flag `-c, --count' (expected int): %v", e)}
            }
            opt.count = n
        case strings.HasPrefix(a, "-c="):
            n, e := intFromString(strings.TrimPrefix(a, "-c="))
            if e != nil { return opt, false, parseError{fmt.Sprintf("invalid argument for flag `-c, --count' (expected int): %v", e)} }
            opt.count = n
        case strings.HasPrefix(a, "--count="):
            n, e := intFromString(strings.TrimPrefix(a, "--count="))
            if e != nil { return opt, false, parseError{fmt.Sprintf("invalid argument for flag `-c, --count' (expected int): %v", e)} }
            opt.count = n
        case strings.HasPrefix(a, "-c") && len(a) > 2:
            n, e := intFromString(a[2:])
            if e != nil { return opt, false, parseError{fmt.Sprintf("invalid argument for flag `-c, --count' (expected int): %v", e)} }
            opt.count = n
        case strings.HasPrefix(a, "--"):
            return opt, false, parseError{fmt.Sprintf("unknown flag `%s'", strings.TrimPrefix(a, "--"))}
        case strings.HasPrefix(a, "-") && a != "-":
            return opt, false, parseError{fmt.Sprintf("unknown flag `%s'", strings.TrimPrefix(a, "-"))}
        default:
            hosts = append(hosts, a)
        }
    }
    if len(hosts) == 0 { return opt, false, parseError{"must requires an argument"} }
    if len(hosts) > 1 { return opt, false, parseError{"too many arguments"} }
    opt.host = hosts[0]
    return opt, false, nil
}

type reply struct { seq int; n int; addr string; ttl int; rtt time.Duration }

func run(opt options) int {
    ips, err := net.LookupIP(opt.host)
    if err != nil || len(ips) == 0 {
        if err == nil { err = errors.New("no such host") }
        fmt.Fprintf(os.Stderr, "[ ERROR ] an error occurred while initializing pinger: failed to init pinger %v\n", err)
        return 0
    }
    ip := chooseIP(ips)
    fmt.Printf("PING %s (%s) type `Ctrl-C` to abort\n", opt.host, ip.String())

    p, err := newPinger(ip, opt.privileged)
    if err != nil {
        fmt.Fprintf(os.Stderr, "[ ERROR ] an error occurred when running ping: %v\n", err)
        return 2
    }
    defer p.close()

    limit := opt.count
    if limit <= 0 { limit = math.MaxInt32 }
    times := make([]time.Duration, 0, limit)
    transmitted := 0
    received := 0
    for seq := 0; seq < limit; seq++ {
        transmitted++
        r, err := p.ping(seq)
        if err == nil {
            received++
            times = append(times, r.rtt)
            line := art[seq%len(art)]
            fmt.Printf("%s seq=%d 32bytes from %s: ttl=%d time=%s\n", line, seq, r.addr, r.ttl, r.rtt.String())
        }
        if seq+1 < limit { time.Sleep(time.Second) }
    }
    fmt.Printf("\n───────── %s ping statistics ─────────\n", opt.host)
    loss := 0
    if transmitted > 0 { loss = int(float64(transmitted-received) * 100 / float64(transmitted)) }
    fmt.Printf("PACKET STATISTICS: %d transmitted => %d received (%d%% loss)\n", transmitted, received, loss)
    if len(times) > 0 {
        min, max, sum := times[0], times[0], time.Duration(0)
        for _, d := range times { if d < min { min = d }; if d > max { max = d }; sum += d }
        avg := time.Duration(int64(sum) / int64(len(times)))
        var variance float64
        for _, d := range times { diff := float64(d - avg); variance += diff * diff }
        std := time.Duration(math.Sqrt(variance / float64(len(times))))
        fmt.Printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s\n", min, avg, max, std)
    }
    return 0
}

func chooseIP(ips []net.IP) net.IP {
    for _, ip := range ips { if v4 := ip.To4(); v4 != nil { return v4 } }
    return ips[0]
}

type pinger struct { c *icmp.PacketConn; ip net.IP; ipv6 bool; privileged bool; id int }

func newPinger(ip net.IP, privileged bool) (*pinger, error) {
    is6 := ip.To4() == nil
    network, listen := "udp4", "0.0.0.0"
    if privileged { network = "ip4:icmp" }
    if is6 { network, listen = "udp6", "::"; if privileged { network = "ip6:ipv6-icmp" } }
    listenAddr := listen
    if privileged { listenAddr = "" }
    c, err := icmp.ListenPacket(network, listenAddr)
    if err != nil { return nil, err }
    return &pinger{c:c, ip:ip, ipv6:is6, privileged:privileged, id:os.Getpid() & 0xffff}, nil
}

func (p *pinger) close() { _ = p.c.Close() }

func (p *pinger) ping(seq int) (reply, error) {
    var typ icmp.Type = ipv4.ICMPTypeEcho
    proto := 1
    if p.ipv6 { typ = ipv6.ICMPTypeEchoRequest; proto = 58 }
    body := &icmp.Echo{ID:p.id, Seq:seq, Data:[]byte("PINGU-PINGU-PINGU-PINGU")}
    msg := icmp.Message{Type:typ, Code:0, Body:body}
    b, err := msg.Marshal(nil)
    if err != nil { return reply{}, err }
    dst := net.Addr(&net.UDPAddr{IP:p.ip})
    if p.privileged { dst = &net.IPAddr{IP:p.ip} }
    start := time.Now()
    if _, err = p.c.WriteTo(b, dst); err != nil { return reply{}, err }
    deadline := time.Now().Add(2*time.Second)
    _ = p.c.SetReadDeadline(deadline)
    buf := make([]byte, 1500)
    for {
        n, peer, err := p.c.ReadFrom(buf)
        if err != nil { return reply{}, err }
        rm, err := icmp.ParseMessage(proto, buf[:n])
        if err != nil { continue }
        switch body := rm.Body.(type) {
        case *icmp.Echo:
            okType := rm.Type == ipv4.ICMPTypeEchoReply || rm.Type == ipv6.ICMPTypeEchoReply
            if okType && body.Seq == seq {
                return reply{seq:seq, n:n, addr:addrString(peer), ttl:64, rtt:time.Since(start).Round(time.Nanosecond)}, nil
            }
        }
    }
}

func addrString(a net.Addr) string {
    switch v := a.(type) {
    case *net.IPAddr: return v.IP.String()
    case *net.UDPAddr: return v.IP.String()
    default:
        s := a.String()
        if h, _, err := net.SplitHostPort(s); err == nil { return h }
        return s
    }
}
