package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type options struct {
	instances []string
	draft     string
	output    string
	errOnly   bool
	assertFmt bool
}

var rootSchema any
var assertFormat bool

type result struct {
	Instance string     `json:"instance,omitempty"`
	Output   string     `json:"output,omitempty"`
	Payload  any        `json:"payload"`
	Schema   string     `json:"schema"`
	Errors   []valError `json:"-"`
	Valid    bool       `json:"-"`
}

type detail struct {
	Errors           map[string]string `json:"errors,omitempty"`
	EvaluationPath   string            `json:"evaluationPath"`
	InstanceLocation string            `json:"instanceLocation"`
	SchemaLocation   string            `json:"schemaLocation"`
	Valid            bool              `json:"valid"`
	Details          []detail          `json:"details,omitempty"`
}

type valError struct {
	Keyword string
	Path    string
	Message string
}

func main() {
	opt, schemaPath, err := parseArgs(os.Args[1:])
	if err != nil {
		if err.Error() != "" {
			fmt.Fprintln(os.Stderr, err)
		}
		os.Exit(2)
	}
	if opt.output == "" {
		opt.output = "text"
	}
	assertFormat = opt.assertFmt

	schema, err := readJSON(schemaPath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Error: %s\n", err)
		os.Exit(1)
	}
	rootSchema = schema

	if len(opt.instances) == 0 {
		errs := validateSchemaShape(schema)
		if len(errs) == 0 {
			fmt.Println("Schema is valid")
			os.Exit(0)
		}
		fmt.Println("Schema is invalid. Errors:")
		for i, e := range errs {
			fmt.Printf("%d. %s\n", i+1, e.Message)
		}
		os.Exit(1)
	}

	anyInvalid := false
	for _, instPath := range opt.instances {
		inst, err := readJSON(instPath)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %s\n", err)
			os.Exit(1)
		}
		errs := validate(schema, inst, "", "")
		valid := len(errs) == 0
		if !valid {
			anyInvalid = true
		}
		writeOutput(opt, schemaPath, instPath, valid, errs)
	}
	if anyInvalid {
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, string, error) {
	var opt options
	var schema string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printHelp()
			os.Exit(0)
		case "-v", "--version":
			fmt.Println("Version: 0.41.0")
			os.Exit(0)
		case "-i", "--instance":
			i++
			if i >= len(args) {
				return opt, "", fmt.Errorf("error: a value is required for '%s <INSTANCES>' but none was supplied", a)
			}
			opt.instances = append(opt.instances, args[i])
		case "-d", "--draft":
			i++
			if i >= len(args) {
				return opt, "", fmt.Errorf("error: a value is required for '%s <DRAFT>' but none was supplied", a)
			}
			opt.draft = args[i]
		case "--assert-format":
			opt.assertFmt = true
		case "--no-assert-format", "-k", "--insecure":
		case "--errors-only":
			opt.errOnly = true
		case "--output":
			i++
			if i >= len(args) {
				return opt, "", fmt.Errorf("error: a value is required for '--output <OUTPUT>' but none was supplied")
			}
			opt.output = args[i]
			if opt.output != "text" && opt.output != "flag" && opt.output != "list" && opt.output != "hierarchical" {
				return opt, "", fmt.Errorf("error: invalid value '%s' for '--output <OUTPUT>'", opt.output)
			}
		case "--connect-timeout", "--timeout", "--cacert":
			i++
			if i >= len(args) {
				return opt, "", fmt.Errorf("error: a value is required for '%s' but none was supplied", a)
			}
		default:
			if strings.HasPrefix(a, "-") {
				return opt, "", fmt.Errorf("error: unexpected argument '%s' found", a)
			}
			if schema != "" {
				return opt, "", fmt.Errorf("error: unexpected argument '%s' found", a)
			}
			schema = a
		}
	}
	if schema == "" {
		return opt, "", fmt.Errorf("error: the following required arguments were not provided:\n  <SCHEMA>\n\nUsage: executable <SCHEMA>\n\nFor more information, try '--help'.")
	}
	return opt, schema, nil
}

func printHelp() {
	fmt.Println(`Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help`)
}

func readJSON(path string) (any, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, errors.New("No such file or directory (os error 2)")
		}
		return nil, err
	}
	dec := json.NewDecoder(bytes.NewReader(b))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil, err
	}
	return v, nil
}

func writeOutput(opt options, schemaPath, instPath string, valid bool, errs []valError) {
	switch opt.output {
	case "text":
		if opt.errOnly && valid {
			return
		}
		if valid {
			fmt.Printf("%s - VALID\n", instPath)
		} else {
			fmt.Printf("%s - INVALID. Errors:\n", instPath)
			for i, e := range errs {
				fmt.Printf("%d. %s\n", i+1, e.Message)
			}
		}
	case "flag":
		emitJSON(result{Instance: instPath, Output: "flag", Payload: map[string]bool{"valid": valid}, Schema: schemaPath})
	case "list", "hierarchical":
		root := detail{EvaluationPath: "", InstanceLocation: "", SchemaLocation: schemaURI(schemaPath) + "#", Valid: valid}
		if !valid {
			root.Errors = errorsMap(errs)
		}
		payload := map[string]any{"valid": valid, "details": []detail{root}}
		if opt.output == "hierarchical" {
			payload = map[string]any{"valid": valid, "details": root.Details}
			emitJSON(map[string]any{"instance": instPath, "output": opt.output, "payload": root, "schema": schemaPath})
			return
		}
		emitJSON(map[string]any{"instance": instPath, "output": opt.output, "payload": payload, "schema": schemaPath})
	}
}

func emitJSON(v any) {
	b, _ := json.Marshal(v)
	fmt.Println(string(b))
}

func errorsMap(errs []valError) map[string]string {
	if len(errs) == 0 {
		return nil
	}
	m := map[string]string{}
	for _, e := range errs {
		if _, ok := m[e.Keyword]; !ok {
			m[e.Keyword] = e.Message
		}
	}
	return m
}

func schemaURI(p string) string {
	abs, err := filepath.Abs(p)
	if err != nil {
		abs = p
	}
	u := url.URL{Scheme: "file", Path: abs}
	return u.String()
}

func validateSchemaShape(schema any) []valError {
	switch s := schema.(type) {
	case map[string]any:
		if t, ok := s["type"]; ok {
			switch tv := t.(type) {
			case string:
				if !knownType(tv) {
					return []valError{{Keyword: "type", Message: fmt.Sprintf("%q is not a valid type", tv)}}
				}
			case []any:
				for _, x := range tv {
					xs, ok := x.(string)
					if !ok || !knownType(xs) {
						return []valError{{Keyword: "type", Message: "type must be a string or array of strings"}}
					}
				}
			default:
				return []valError{{Keyword: "type", Message: "type must be a string or array of strings"}}
			}
		}
	}
	return nil
}

func validate(schema any, inst any, path, spath string) []valError {
	switch s := schema.(type) {
	case bool:
		if !s {
			return []valError{{Keyword: "false schema", Path: path, Message: fmt.Sprintf("%s is not allowed", render(inst))}}
		}
		return nil
	case map[string]any:
		if ref, ok := s["$ref"].(string); ok {
			if target, ok := resolveRef(rootSchema, ref); ok {
				return validate(target, inst, path, ref)
			}
			return []valError{ve("$ref", path, "Unresolvable JSON pointer: %q", ref)}
		}
		var errs []valError
		if c, ok := s["const"]; ok && !jsonEqual(c, inst) {
			errs = append(errs, ve("const", path, "%s was expected", render(c)))
		}
		if e, ok := s["enum"].([]any); ok {
			found := false
			for _, ev := range e {
				if jsonEqual(ev, inst) {
					found = true
					break
				}
			}
			if !found {
				errs = append(errs, ve("enum", path, "%s is not one of %s", render(inst), renderEnum(e)))
			}
		}
		if tv, ok := s["type"]; ok && !typeMatches(tv, inst) {
			errs = append(errs, ve("type", path, "%s is not of type %s", render(inst), render(tv)))
		}
		if len(errs) > 0 && hasOnlyTypeCritical(s) {
			return errs
		}
		errs = append(errs, validateCombiners(s, inst, path, spath)...)
		errs = append(errs, validateConditional(s, inst, path, spath)...)
		errs = append(errs, validateObject(s, inst, path, spath)...)
		errs = append(errs, validateArray(s, inst, path, spath)...)
		errs = append(errs, validateString(s, inst, path)...)
		errs = append(errs, validateNumber(s, inst, path)...)
		return errs
	default:
		return nil
	}
}

func validateCombiners(s map[string]any, inst any, path, spath string) []valError {
	var errs []valError
	if arr, ok := s["allOf"].([]any); ok {
		for i, sub := range arr {
			errs = append(errs, validate(sub, inst, path, spath+"/allOf/"+strconv.Itoa(i))...)
		}
	}
	if arr, ok := s["anyOf"].([]any); ok {
		okay := false
		var first []valError
		for i, sub := range arr {
			es := validate(sub, inst, path, spath+"/anyOf/"+strconv.Itoa(i))
			if i == 0 {
				first = es
			}
			if len(es) == 0 {
				okay = true
			}
		}
		if !okay {
			if len(first) > 0 {
				errs = append(errs, first...)
			}
			errs = append(errs, ve("anyOf", path, "%s is not valid under any of the given schemas", render(inst)))
		}
	}
	if arr, ok := s["oneOf"].([]any); ok {
		count := 0
		for _, sub := range arr {
			if len(validate(sub, inst, path, "")) == 0 {
				count++
			}
		}
		if count != 1 {
			errs = append(errs, ve("oneOf", path, "%s is valid under %d of the given schemas", render(inst), count))
		}
	}
	if sub, ok := s["not"]; ok && len(validate(sub, inst, path, spath+"/not")) == 0 {
		errs = append(errs, ve("not", path, "%s should not be valid under the given schema", render(inst)))
	}
	return errs
}

func validateConditional(s map[string]any, inst any, path, spath string) []valError {
	if cond, ok := s["if"]; ok {
		if len(validate(cond, inst, path, spath+"/if")) == 0 {
			if thenSchema, ok := s["then"]; ok {
				return validate(thenSchema, inst, path, spath+"/then")
			}
		} else if elseSchema, ok := s["else"]; ok {
			return validate(elseSchema, inst, path, spath+"/else")
		}
	}
	return nil
}

func validateObject(s map[string]any, inst any, path, spath string) []valError {
	obj, ok := inst.(map[string]any)
	if !ok {
		return nil
	}
	var errs []valError
	if req, ok := s["required"].([]any); ok {
		for _, r := range req {
			name, ok := r.(string)
			if !ok {
				continue
			}
			if _, exists := obj[name]; !exists {
				errs = append(errs, ve("required", path, "%q is a required property", name))
			}
		}
	}
	if min, ok := number(s["minProperties"]); ok && float64(len(obj)) < min {
		errs = append(errs, ve("minProperties", path, "%s has fewer than %.0f properties", render(inst), min))
	}
	if max, ok := number(s["maxProperties"]); ok && float64(len(obj)) > max {
		errs = append(errs, ve("maxProperties", path, "%s has more than %.0f properties", render(inst), max))
	}
	seen := map[string]bool{}
	if props, ok := s["properties"].(map[string]any); ok {
		keys := sortedKeys(props)
		for _, k := range keys {
			if v, exists := obj[k]; exists {
				seen[k] = true
				errs = append(errs, validate(props[k], v, path+"/"+escape(k), spath+"/properties/"+escape(k))...)
			}
		}
	}
	if patProps, ok := s["patternProperties"].(map[string]any); ok {
		for _, pat := range sortedKeys(patProps) {
			re, err := regexp.Compile(pat)
			if err != nil {
				continue
			}
			for _, k := range sortedKeysAny(obj) {
				if re.MatchString(k) {
					seen[k] = true
					errs = append(errs, validate(patProps[pat], obj[k], path+"/"+escape(k), spath+"/patternProperties/"+escape(pat))...)
				}
			}
		}
	}
	if add, exists := s["additionalProperties"]; exists {
		switch av := add.(type) {
		case bool:
			if !av {
				var extra []string
				for _, k := range sortedKeysAny(obj) {
					if !seen[k] {
						extra = append(extra, k)
					}
				}
				if len(extra) == 1 {
					errs = append(errs, ve("additionalProperties", path, "Additional properties are not allowed ('%s' was unexpected)", extra[0]))
				} else if len(extra) > 1 {
					var quoted []string
					for _, k := range extra {
						quoted = append(quoted, "'"+k+"'")
					}
					errs = append(errs, ve("additionalProperties", path, "Additional properties are not allowed (%s were unexpected)", strings.Join(quoted, ", ")))
				}
			}
		case map[string]any:
			for _, k := range sortedKeysAny(obj) {
				if !seen[k] {
					errs = append(errs, validate(av, obj[k], path+"/"+escape(k), spath+"/additionalProperties")...)
				}
			}
		}
	}
	if deps, ok := s["dependentRequired"].(map[string]any); ok {
		errs = append(errs, validateDeps(deps, obj, path)...)
	}
	if deps, ok := s["dependencies"].(map[string]any); ok {
		errs = append(errs, validateDeps(deps, obj, path)...)
	}
	return errs
}

func validateDeps(deps map[string]any, obj map[string]any, path string) []valError {
	var errs []valError
	for _, k := range sortedKeys(deps) {
		if _, exists := obj[k]; !exists {
			continue
		}
		if arr, ok := deps[k].([]any); ok {
			for _, d := range arr {
				ds, ok := d.(string)
				if !ok {
					continue
				}
				if _, has := obj[ds]; !has {
					errs = append(errs, ve("dependencies", path, "%q is a dependency of %q", ds, k))
				}
			}
		}
	}
	return errs
}

func validateArray(s map[string]any, inst any, path, spath string) []valError {
	arr, ok := inst.([]any)
	if !ok {
		return nil
	}
	var errs []valError
	if min, ok := number(s["minItems"]); ok && float64(len(arr)) < min {
		errs = append(errs, ve("minItems", path, "%s has fewer than %.0f items", render(inst), min))
	}
	if max, ok := number(s["maxItems"]); ok && float64(len(arr)) > max {
		errs = append(errs, ve("maxItems", path, "%s has more than %.0f items", render(inst), max))
	}
	if u, ok := s["uniqueItems"].(bool); ok && u {
		for i := 0; i < len(arr); i++ {
			for j := i + 1; j < len(arr); j++ {
				if jsonEqual(arr[i], arr[j]) {
					errs = append(errs, ve("uniqueItems", path, "%s has non-unique elements", render(inst)))
					i = len(arr)
					break
				}
			}
		}
	}
	if sub, ok := s["items"]; ok {
		if list, ok := sub.([]any); ok {
			for i, ss := range list {
				if i < len(arr) {
					errs = append(errs, validate(ss, arr[i], path+"/"+strconv.Itoa(i), spath+"/items/"+strconv.Itoa(i))...)
				}
			}
		} else {
			for i, v := range arr {
				errs = append(errs, validate(sub, v, path+"/"+strconv.Itoa(i), spath+"/items")...)
			}
		}
	}
	if pfx, ok := s["prefixItems"].([]any); ok {
		for i, ss := range pfx {
			if i < len(arr) {
				errs = append(errs, validate(ss, arr[i], path+"/"+strconv.Itoa(i), spath+"/prefixItems/"+strconv.Itoa(i))...)
			}
		}
	}
	if sub, ok := s["contains"]; ok {
		count := 0
		for i, v := range arr {
			if len(validate(sub, v, path+"/"+strconv.Itoa(i), spath+"/contains")) == 0 {
				count++
			}
		}
		min := 1.0
		if v, ok := number(s["minContains"]); ok {
			min = v
		}
		if count < int(min) {
			errs = append(errs, ve("contains", path, "%s does not contain items matching the given schema", render(inst)))
		}
		if max, ok := number(s["maxContains"]); ok && count > int(max) {
			errs = append(errs, ve("maxContains", path, "%s contains more than %.0f matching items", render(inst), max))
		}
	}
	return errs
}

func validateString(s map[string]any, inst any, path string) []valError {
	str, ok := inst.(string)
	if !ok {
		return nil
	}
	var errs []valError
	n := float64(len([]rune(str)))
	if min, ok := number(s["minLength"]); ok && n < min {
		errs = append(errs, ve("minLength", path, "%s is shorter than %.0f characters", render(inst), min))
	}
	if max, ok := number(s["maxLength"]); ok && n > max {
		errs = append(errs, ve("maxLength", path, "%s is longer than %.0f characters", render(inst), max))
	}
	if pat, ok := s["pattern"].(string); ok {
		re, err := regexp.Compile(pat)
		if err == nil && !re.MatchString(str) {
			errs = append(errs, ve("pattern", path, "%s does not match %q", render(inst), pat))
		}
	}
	if assertFormat {
		if f, ok := s["format"].(string); ok && !validFormat(f, str) {
			errs = append(errs, ve("format", path, "%s is not a %q", render(inst), f))
		}
	}
	return errs
}

func validateNumber(s map[string]any, inst any, path string) []valError {
	x, ok := number(inst)
	if !ok {
		return nil
	}
	var errs []valError
	if min, ok := number(s["minimum"]); ok && x < min {
		errs = append(errs, ve("minimum", path, "%s is less than the minimum of %s", render(inst), trimNum(min)))
	}
	if max, ok := number(s["maximum"]); ok && x > max {
		errs = append(errs, ve("maximum", path, "%s is greater than the maximum of %s", render(inst), trimNum(max)))
	}
	if min, ok := number(s["exclusiveMinimum"]); ok && x <= min {
		errs = append(errs, ve("exclusiveMinimum", path, "%s is less than or equal to the minimum of %s", render(inst), trimNum(min)))
	}
	if max, ok := number(s["exclusiveMaximum"]); ok && x >= max {
		errs = append(errs, ve("exclusiveMaximum", path, "%s is greater than or equal to the maximum of %s", render(inst), trimNum(max)))
	}
	if m, ok := number(s["multipleOf"]); ok && m != 0 {
		q := x / m
		if math.Abs(q-math.Round(q)) > 1e-9 {
			errs = append(errs, ve("multipleOf", path, "%s is not a multiple of %s", render(inst), trimNum(m)))
		}
	}
	return errs
}

func ve(keyword, path, format string, args ...any) valError {
	return valError{Keyword: keyword, Path: path, Message: fmt.Sprintf(format, args...)}
}

func typeMatches(tv any, inst any) bool {
	switch t := tv.(type) {
	case string:
		return matchesType(t, inst)
	case []any:
		for _, v := range t {
			if ts, ok := v.(string); ok && matchesType(ts, inst) {
				return true
			}
		}
		return false
	default:
		return true
	}
}

func matchesType(t string, v any) bool {
	switch t {
	case "null":
		return v == nil
	case "boolean":
		_, ok := v.(bool)
		return ok
	case "object":
		_, ok := v.(map[string]any)
		return ok
	case "array":
		_, ok := v.([]any)
		return ok
	case "number":
		_, ok := number(v)
		return ok
	case "integer":
		n, ok := number(v)
		return ok && math.Trunc(n) == n
	case "string":
		_, ok := v.(string)
		return ok
	default:
		return true
	}
}

func knownType(t string) bool {
	switch t {
	case "null", "boolean", "object", "array", "number", "integer", "string":
		return true
	default:
		return false
	}
}

func hasOnlyTypeCritical(map[string]any) bool { return false }

func number(v any) (float64, bool) {
	switch n := v.(type) {
	case json.Number:
		f, err := n.Float64()
		return f, err == nil
	case float64:
		return n, true
	case int:
		return float64(n), true
	default:
		return 0, false
	}
}

func render(v any) string {
	b, _ := json.Marshal(v)
	return string(b)
}

func renderEnum(e []any) string {
	var parts []string
	for _, v := range e {
		parts = append(parts, render(v))
	}
	return strings.Join(parts, ", ")
}

func trimNum(f float64) string {
	if math.Trunc(f) == f {
		return strconv.FormatInt(int64(f), 10)
	}
	return strconv.FormatFloat(f, 'f', -1, 64)
}

func jsonEqual(a, b any) bool {
	ab, _ := json.Marshal(a)
	bb, _ := json.Marshal(b)
	return bytes.Equal(ab, bb)
}

func sortedKeys(m map[string]any) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func sortedKeysAny(m map[string]any) []string { return sortedKeys(m) }

func escape(s string) string {
	s = strings.ReplaceAll(s, "~", "~0")
	s = strings.ReplaceAll(s, "/", "~1")
	return s
}

func unescape(s string) string {
	s = strings.ReplaceAll(s, "~1", "/")
	s = strings.ReplaceAll(s, "~0", "~")
	return s
}

func resolveRef(root any, ref string) (any, bool) {
	if ref == "#" || ref == "" {
		return root, true
	}
	if !strings.HasPrefix(ref, "#/") {
		return nil, false
	}
	cur := root
	for _, part := range strings.Split(strings.TrimPrefix(ref, "#/"), "/") {
		part = unescape(part)
		switch v := cur.(type) {
		case map[string]any:
			n, ok := v[part]
			if !ok {
				return nil, false
			}
			cur = n
		case []any:
			i, err := strconv.Atoi(part)
			if err != nil || i < 0 || i >= len(v) {
				return nil, false
			}
			cur = v[i]
		default:
			return nil, false
		}
	}
	return cur, true
}

func validFormat(name, s string) bool {
	switch name {
	case "email", "idn-email":
		return regexp.MustCompile(`^[^@\s]+@[^@\s]+\.[^@\s]+$`).MatchString(s)
	case "hostname", "idn-hostname":
		return regexp.MustCompile(`^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$`).MatchString(s)
	case "ipv4":
		parts := strings.Split(s, ".")
		if len(parts) != 4 {
			return false
		}
		for _, p := range parts {
			n, err := strconv.Atoi(p)
			if err != nil || n < 0 || n > 255 || (len(p) > 1 && p[0] == '0') {
				return false
			}
		}
		return true
	case "uri", "uri-reference", "iri", "iri-reference":
		u, err := url.Parse(s)
		return err == nil && (name == "uri-reference" || name == "iri-reference" || u.Scheme != "")
	case "uuid":
		return regexp.MustCompile(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$`).MatchString(s)
	case "date-time":
		return regexp.MustCompile(`^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d`).MatchString(s)
	case "date":
		return regexp.MustCompile(`^\d{4}-\d\d-\d\d$`).MatchString(s)
	case "time":
		return regexp.MustCompile(`^\d\d:\d\d:\d\d`).MatchString(s)
	default:
		return true
	}
}
