module pbjsonschema

go 1.21
