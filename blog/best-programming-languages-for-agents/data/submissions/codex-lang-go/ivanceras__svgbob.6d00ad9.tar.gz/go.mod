module svgbob-reimpl

go 1.21
