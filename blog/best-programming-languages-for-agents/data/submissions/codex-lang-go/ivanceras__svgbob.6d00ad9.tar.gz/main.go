package main

import (
	"bufio"
	"bytes"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

type options struct {
	background  string
	fillColor   string
	strokeColor string
	fontFamily  string
	fontSize    float64
	strokeWidth float64
	scale       float64
	output      string
	inline      bool
}

type shape struct {
	kind  string
	attrs string
}

func defaults() options {
	return options{
		background:  "white",
		fillColor:   "black",
		strokeColor: "black",
		fontFamily:  "Iosevka Fixed, monospace",
		fontSize:    14,
		strokeWidth: 2,
		scale:       1,
	}
}

func main() {
	if len(os.Args) > 1 && os.Args[1] == "build" {
		runBuild(os.Args[2:])
		return
	}
	opt, input, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(1)
	}
	var data []byte
	var err error
	if input != "" {
		if opt.inline {
			data = []byte(strings.ReplaceAll(input, `\n`, "\n"))
		} else {
			data, err = os.ReadFile(input)
			if err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
		}
	} else {
		data, err = io.ReadAll(os.Stdin)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	out := render(string(data), opt)
	if opt.output != "" && opt.output != "STDOUT" {
		if err := os.WriteFile(opt.output, []byte(out), 0644); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	fmt.Print(out)
}

func parseArgs(args []string) (options, string, bool) {
	opt := defaults()
	var input string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help", "help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("svgbob 0.7.6")
			os.Exit(0)
		case "-s", "--inline":
			opt.inline = true
		case "-o", "--output":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "error: The argument '--output <output>' requires a value but none was supplied")
				return opt, input, false
			}
			opt.output = args[i]
		case "--background", "--fill-color", "--stroke-color", "--font-family", "--font-size", "--stroke-width", "--scale":
			i++
			if i >= len(args) {
				fmt.Fprintf(os.Stderr, "error: The argument '%s' requires a value but none was supplied\n", a)
				return opt, input, false
			}
			v := args[i]
			switch a {
			case "--background":
				opt.background = v
			case "--fill-color":
				opt.fillColor = v
			case "--stroke-color":
				opt.strokeColor = v
			case "--font-family":
				opt.fontFamily = v
			case "--font-size":
				opt.fontSize = parseFloat(v, opt.fontSize)
			case "--stroke-width":
				opt.strokeWidth = parseFloat(v, opt.strokeWidth)
			case "--scale":
				opt.scale = parseFloat(v, opt.scale)
			}
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected\n", a)
				return opt, input, false
			}
			if input == "" {
				input = a
			}
		}
	}
	return opt, input, true
}

func runBuild(args []string) {
	if len(args) == 1 && (args[0] == "-h" || args[0] == "--help" || args[0] == "help") {
		printBuildHelp()
		return
	}
	if len(args) == 1 && (args[0] == "-V" || args[0] == "--version") {
		fmt.Println("executable-build 0.0.1")
		return
	}
	var pattern, outdir string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-i", "--input":
			i++
			if i < len(args) {
				pattern = args[i]
			}
		case "-o", "--outdir":
			i++
			if i < len(args) {
				outdir = args[i]
			}
		}
	}
	if pattern == "" {
		return
	}
	if outdir == "" {
		outdir = "."
	}
	_ = os.MkdirAll(outdir, 0755)
	matches, _ := filepath.Glob(pattern)
	for _, name := range matches {
		data, err := os.ReadFile(name)
		if err != nil {
			continue
		}
		base := strings.TrimSuffix(filepath.Base(name), filepath.Ext(name)) + ".svg"
		_ = os.WriteFile(filepath.Join(outdir, base), []byte(render(string(data), defaults())), 0644)
	}
}

func parseFloat(s string, def float64) float64 {
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		return def
	}
	return v
}

func printHelp() {
	fmt.Print(`svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
`)
}

func printBuildHelp() {
	fmt.Print(`executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
`)
}

func render(input string, opt options) string {
	lines := splitLines(input)
	widthChars := 1
	for _, l := range lines {
		if len([]rune(l)) > widthChars {
			widthChars = len([]rune(l))
		}
	}
	heightRows := len(lines)
	if heightRows == 0 {
		heightRows = 1
	}
	grid := make([][]rune, heightRows)
	used := make([][]bool, heightRows)
	for r := range grid {
		grid[r] = make([]rune, widthChars)
		used[r] = make([]bool, widthChars)
		for c := range grid[r] {
			grid[r][c] = ' '
		}
		rs := []rune(lines[r])
		copy(grid[r], rs)
	}
	var shapes []shape
	detectRects(grid, used, &shapes)
	detectArrowsAndLines(grid, used, &shapes)
	detectSlashes(grid, used, &shapes)
	detectText(grid, used, &shapes)
	w := f(float64(widthChars+1) * 8 * opt.scale)
	h := f(float64(heightRows+1) * 16 * opt.scale)
	var b bytes.Buffer
	fmt.Fprintf(&b, `<svg xmlns="http://www.w3.org/2000/svg" width="%s" height="%s" class="svgbob">`+"\n", w, h)
	b.WriteString(style(opt))
	b.WriteString(defs())
	fmt.Fprintf(&b, `  <rect class="backdrop" x="0" y="0" width="%s" height="%s"></rect>`+"\n", w, h)
	for _, s := range shapes {
		b.WriteString(s.attrs)
		b.WriteByte('\n')
	}
	b.WriteString("</svg>\n")
	return b.String()
}

func splitLines(s string) []string {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	s = strings.ReplaceAll(s, "\r", "\n")
	s = strings.TrimRight(s, "\n")
	if s == "" {
		return []string{""}
	}
	return strings.Split(s, "\n")
}

func detectRects(g [][]rune, used [][]bool, shapes *[]shape) {
	rows, cols := len(g), len(g[0])
	for r1 := 0; r1 < rows; r1++ {
		for c1 := 0; c1 < cols; c1++ {
			if g[r1][c1] != '+' {
				continue
			}
			for c2 := c1 + 2; c2 < cols; c2++ {
				if g[r1][c2] != '+' || !allRunes(g[r1][c1+1:c2], '-') {
					continue
				}
				for r2 := r1 + 2; r2 < rows; r2++ {
					if g[r2][c1] == '+' && g[r2][c2] == '+' && allRunes(g[r2][c1+1:c2], '-') && vertical(g, c1, r1+1, r2) && vertical(g, c2, r1+1, r2) {
						for c := c1; c <= c2; c++ {
							used[r1][c], used[r2][c] = true, true
						}
						for r := r1; r <= r2; r++ {
							used[r][c1], used[r][c2] = true, true
						}
						x, y := c1*8+4, r1*16+8
						w, h := (c2-c1)*8, (r2-r1)*16
						*shapes = append(*shapes, shape{"rect", fmt.Sprintf(`  <rect x="%d" y="%d" width="%d" height="%d" class="solid nofill" rx="0"></rect>`, x, y, w, h)})
						goto nextCell
					}
				}
			}
		nextCell:
		}
	}
}

func detectArrowsAndLines(g [][]rune, used [][]bool, shapes *[]shape) {
	rows, cols := len(g), len(g[0])
	for r := 0; r < rows; r++ {
		for c := 0; c < cols; {
			if used[r][c] || g[r][c] != '-' {
				c++
				continue
			}
			start := c
			for c < cols && g[r][c] == '-' && !used[r][c] {
				c++
			}
			end := c - 1
			if end-start+1 >= 1 {
				x1, x2, y := start*8, (end+1)*8, r*16+8
				if start > 0 && g[r][start-1] == '<' {
					*shapes = append(*shapes, shape{"polygon", fmt.Sprintf(`  <polygon points="%d,%d %d,%d %d,%d" class="filled"></polygon>`, x1, y-4, x1-8, y, x1, y+4)})
					used[r][start-1] = true
				}
				if end+1 < cols && g[r][end+1] == '>' {
					*shapes = append(*shapes, shape{"line", fmt.Sprintf(`  <line x1="%d" y1="%d" x2="%d" y2="%d" class="solid"></line>`, x1, y, x2, y)})
					*shapes = append(*shapes, shape{"polygon", fmt.Sprintf(`  <polygon points="%d,%d %d,%d %d,%d" class="filled"></polygon>`, x2, y-4, x2+8, y, x2, y+4)})
					used[r][end+1] = true
				} else {
					*shapes = append(*shapes, shape{"line", fmt.Sprintf(`  <line x1="%d" y1="%d" x2="%d" y2="%d" class="solid"></line>`, x1, y, x2, y)})
				}
				for i := start; i <= end; i++ {
					used[r][i] = true
				}
			}
		}
	}
	for c := 0; c < cols; c++ {
		for r := 0; r < rows; r++ {
			if used[r][c] || g[r][c] != '|' {
				continue
			}
			start := r
			for r < rows && g[r][c] == '|' && !used[r][c] {
				r++
			}
			end := r - 1
			x, y1, y2 := c*8+4, start*16, end*16+16
			if end+1 < rows && g[end+1][c] == 'v' {
				y2 = end*16 + 20
				*shapes = append(*shapes, shape{"line", fmt.Sprintf(`  <line x1="%d" y1="%d" x2="%d" y2="%d" class="solid"></line>`, x, y1, x, y2)})
				*shapes = append(*shapes, shape{"polygon", fmt.Sprintf(`  <polygon points="%d,%d %d,%d %d,%d" class="filled"></polygon>`, x-4, y2, x+4, y2, x, y2+12)})
				used[end+1][c] = true
			} else {
				*shapes = append(*shapes, shape{"line", fmt.Sprintf(`  <line x1="%d" y1="%d" x2="%d" y2="%d" class="solid"></line>`, x, y1, x, y2)})
			}
			for i := start; i <= end; i++ {
				used[i][c] = true
			}
		}
	}
}

func detectSlashes(g [][]rune, used [][]bool, shapes *[]shape) {
	for r := range g {
		for c, ch := range g[r] {
			if used[r][c] {
				continue
			}
			switch ch {
			case '/':
				*shapes = append(*shapes, shape{"line", fmt.Sprintf(`    <line x1="%d" y1="%d" x2="%d" y2="%d" class="solid"></line>`, c*8+8, r*16, c*8, r*16+16)})
				used[r][c] = true
			case '\\':
				*shapes = append(*shapes, shape{"line", fmt.Sprintf(`    <line x1="%d" y1="%d" x2="%d" y2="%d" class="solid"></line>`, c*8, r*16, c*8+8, r*16+16)})
				used[r][c] = true
			case '^':
				x, y := c*8+4, r*16+4
				*shapes = append(*shapes, shape{"polygon", fmt.Sprintf(`  <polygon points="%d,%d %d,%d %d,%d" class="filled"></polygon>`, x-4, y+8, x+4, y+8, x, y)})
				used[r][c] = true
			}
		}
	}
}

func detectText(g [][]rune, used [][]bool, shapes *[]shape) {
	for r := range g {
		c := 0
		for c < len(g[r]) {
			for c < len(g[r]) && (used[r][c] || g[r][c] == ' ') {
				c++
			}
			start := c
			var sb strings.Builder
			for c < len(g[r]) && !used[r][c] && g[r][c] != ' ' && !isDiagramOnly(g[r][c]) {
				sb.WriteRune(g[r][c])
				c++
			}
			if sb.Len() > 0 {
				*shapes = append(*shapes, shape{"text", fmt.Sprintf(`  <text x="%d" y="%d" >%s</text>`, start*8+2, r*16+12, html.EscapeString(sb.String()))})
			}
			if c == start {
				c++
			}
		}
	}
}

func allRunes(rs []rune, want rune) bool {
	for _, r := range rs {
		if r != want {
			return false
		}
	}
	return true
}

func vertical(g [][]rune, c, r1, r2 int) bool {
	for r := r1; r < r2; r++ {
		if g[r][c] != '|' {
			return false
		}
	}
	return true
}

func isDiagramOnly(r rune) bool {
	return strings.ContainsRune("+-|/\\<>^v", r)
}

func style(opt options) string {
	return fmt.Sprintf(`  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {
  stroke: %s;
  stroke-width: %s;
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}

.svgbob text {
  white-space: pre;
  fill: %s;
  font-family: %s;
  font-size: %spx;
}

.svgbob rect.backdrop {
  stroke: none;
  fill: %s;
}

.svgbob .broken {
  stroke-dasharray: 8;
}

.svgbob .filled {
  fill: %s;
}

.svgbob .bg_filled {
  fill: %s;
  stroke-width: 1;
}

.svgbob .nofill {
  fill: %s;
}

.svgbob .end_marked_arrow {
  marker-end: url(#arrow);
}

.svgbob .start_marked_arrow {
  marker-start: url(#arrow);
}

.svgbob .end_marked_diamond {
  marker-end: url(#diamond);
}

.svgbob .start_marked_diamond {
  marker-start: url(#diamond);
}

.svgbob .end_marked_circle {
  marker-end: url(#circle);
}

.svgbob .start_marked_circle {
  marker-start: url(#circle);
}

.svgbob .end_marked_open_circle {
  marker-end: url(#open_circle);
}

.svgbob .start_marked_open_circle {
  marker-start: url(#open_circle);
}

.svgbob .end_marked_big_open_circle {
  marker-end: url(#big_open_circle);
}

.svgbob .start_marked_big_open_circle {
  marker-start: url(#big_open_circle);
}

</style>
`, opt.strokeColor, f(opt.strokeWidth), opt.strokeColor, opt.fontFamily, f(opt.fontSize), opt.background, opt.fillColor, opt.background, opt.background)
}

func defs() string {
	return `  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>
`
}

func f(v float64) string {
	if v == float64(int64(v)) {
		return strconv.FormatInt(int64(v), 10)
	}
	return strconv.FormatFloat(v, 'f', -1, 64)
}

func readStdinLines() string {
	var b strings.Builder
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		b.WriteString(sc.Text())
		b.WriteByte('\n')
	}
	return b.String()
}
