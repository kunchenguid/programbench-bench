module pb/lua

go 1.21
