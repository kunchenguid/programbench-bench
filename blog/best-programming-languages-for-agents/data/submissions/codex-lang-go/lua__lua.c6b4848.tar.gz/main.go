package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
	"time"
	"unicode"
)

type token struct{ typ, lit string }

var keywords = map[string]bool{"and": true, "break": true, "do": true, "else": true, "elseif": true, "end": true, "false": true, "for": true, "function": true, "goto": true, "if": true, "in": true, "local": true, "nil": true, "not": true, "or": true, "repeat": true, "return": true, "then": true, "true": true, "until": true, "while": true}

func lex(src string) ([]token, error) {
	var out []token
	for i := 0; i < len(src); {
		r := rune(src[i])
		if unicode.IsSpace(r) {
			i++
			continue
		}
		if src[i] == '-' && i+1 < len(src) && src[i+1] == '-' {
			i += 2
			for i < len(src) && src[i] != '\n' {
				i++
			}
			continue
		}
		if unicode.IsLetter(r) || src[i] == '_' {
			j := i + 1
			for j < len(src) && (unicode.IsLetter(rune(src[j])) || unicode.IsDigit(rune(src[j])) || src[j] == '_') {
				j++
			}
			l := src[i:j]
			if keywords[l] {
				out = append(out, token{l, l})
			} else {
				out = append(out, token{"name", l})
			}
			i = j
			continue
		}
		if unicode.IsDigit(r) || (src[i] == '.' && i+1 < len(src) && unicode.IsDigit(rune(src[i+1]))) {
			j := i
			if j+1 < len(src) && src[j] == '0' && (src[j+1] == 'x' || src[j+1] == 'X') {
				j += 2
				for j < len(src) && (unicode.IsDigit(rune(src[j])) || (src[j] >= 'a' && src[j] <= 'f') || (src[j] >= 'A' && src[j] <= 'F')) {
					j++
				}
			} else {
				for j < len(src) && (unicode.IsDigit(rune(src[j])) || src[j] == '.') {
					j++
				}
				if j < len(src) && (src[j] == 'e' || src[j] == 'E') {
					j++
					if j < len(src) && (src[j] == '+' || src[j] == '-') {
						j++
					}
					for j < len(src) && unicode.IsDigit(rune(src[j])) {
						j++
					}
				}
			}
			out = append(out, token{"num", src[i:j]})
			i = j
			continue
		}
		if src[i] == '"' || src[i] == '\'' {
			q := src[i]
			j := i + 1
			var b strings.Builder
			for j < len(src) && src[j] != q {
				if src[j] == '\\' && j+1 < len(src) {
					j++
					switch src[j] {
					case 'n':
						b.WriteByte('\n')
					case 't':
						b.WriteByte('\t')
					case 'r':
						b.WriteByte('\r')
					case '\\', '"', '\'':
						b.WriteByte(src[j])
					default:
						b.WriteByte(src[j])
					}
				} else {
					b.WriteByte(src[j])
				}
				j++
			}
			if j >= len(src) {
				return nil, errors.New("unfinished string")
			}
			out = append(out, token{"str", b.String()})
			i = j + 1
			continue
		}
		if i+1 < len(src) {
			two := src[i : i+2]
			if two == "==" || two == "~=" || two == "<=" || two == ">=" || two == ".." || two == "//" {
				out = append(out, token{two, two})
				i += 2
				continue
			}
		}
		out = append(out, token{string(src[i]), string(src[i])})
		i++
	}
	out = append(out, token{"eof", ""})
	return out, nil
}

type Value interface{}
type Table struct {
	arr []Value
	m   map[string]Value
}
type Function struct {
	params []string
	body   []Stmt
	env    *Env
	native func([]Value) ([]Value, error)
}
type Env struct {
	parent *Env
	vars   map[string]Value
}

func (e *Env) get(k string) Value {
	for p := e; p != nil; p = p.parent {
		if v, ok := p.vars[k]; ok {
			return v
		}
	}
	return nil
}
func (e *Env) set(k string, v Value) {
	for p := e; p != nil; p = p.parent {
		if _, ok := p.vars[k]; ok {
			p.vars[k] = v
			return
		}
	}
	e.vars[k] = v
}
func (e *Env) local(k string, v Value) { e.vars[k] = v }

type Expr interface{ eval(*Env) (Value, error) }
type Stmt interface{ exec(*Env) (ret []Value, returned bool, err error) }
type Literal struct{ v Value }
func (l Literal) eval(*Env) (Value, error) { return l.v, nil }
type Var struct{ name string }
func (v Var) eval(e *Env) (Value, error) { return e.get(v.name), nil }
type Index struct{ obj, key Expr }
func (x Index) eval(e *Env) (Value, error) {
	o, _ := x.obj.eval(e); k, _ := x.key.eval(e)
	if t, ok := o.(*Table); ok { return tableGet(t, k), nil }
	return nil, nil
}
type Unary struct{ op string; x Expr }
func (u Unary) eval(e *Env) (Value, error) {
	v, _ := u.x.eval(e)
	switch u.op {
	case "-": return -num(v), nil
	case "not": return !truth(v), nil
	case "#":
		if s, ok := v.(string); ok { return float64(len(s)), nil }
		if t, ok := v.(*Table); ok { return float64(len(t.arr)), nil }
	}
	return nil, nil
}
type Binary struct{ op string; a, b Expr }
func (b Binary) eval(e *Env) (Value, error) {
	if b.op == "and" { av, _ := b.a.eval(e); if !truth(av) { return av, nil }; return b.b.eval(e) }
	if b.op == "or" { av, _ := b.a.eval(e); if truth(av) { return av, nil }; return b.b.eval(e) }
	a, _ := b.a.eval(e); c, _ := b.b.eval(e)
	switch b.op {
	case "+": return num(a)+num(c), nil
	case "-": return num(a)-num(c), nil
	case "*": return num(a)*num(c), nil
	case "/": return num(a)/num(c), nil
	case "//": return math.Floor(num(a)/num(c)), nil
	case "%": return math.Mod(num(a), num(c)), nil
	case "^": return math.Pow(num(a), num(c)), nil
	case "..": return str(a)+str(c), nil
	case "==": return eq(a,c), nil
	case "~=": return !eq(a,c), nil
	case "<": return cmp(a,c)<0, nil
	case ">": return cmp(a,c)>0, nil
	case "<=": return cmp(a,c)<=0, nil
	case ">=": return cmp(a,c)>=0, nil
	}
	return nil, nil
}
type Call struct{ fn Expr; args []Expr }
func (c Call) eval(e *Env) (Value, error) { vs, err := c.call(e); if len(vs)>0 { return vs[0], err }; return nil, err }
func (c Call) call(e *Env) ([]Value, error) {
	fv, _ := c.fn.eval(e)
	var args []Value
	for _, a := range c.args { v, _ := a.eval(e); args = append(args, v) }
	if f, ok := fv.(*Function); ok {
		if f.native != nil { return f.native(args) }
		ne := &Env{parent:f.env, vars:map[string]Value{}}
		for i,p := range f.params { if i < len(args) { ne.local(p,args[i]) } else { ne.local(p,nil) } }
		r, _, err := execBlock(f.body, ne); return r, err
	}
	return nil, fmt.Errorf("attempt to call a nil value")
}
type TableExpr struct{ vals []Expr; fields map[string]Expr }
func (t TableExpr) eval(e *Env) (Value,error) {
	tab := &Table{m:map[string]Value{}}
	for _, ex := range t.vals { v,_ := ex.eval(e); tab.arr = append(tab.arr,v) }
	for k, ex := range t.fields { v,_ := ex.eval(e); tab.m[k]=v }
	return tab,nil
}

type ExprStmt struct{ call Call }
func (s ExprStmt) exec(e *Env)([]Value,bool,error){ _,err:=s.call.call(e); return nil,false,err }
type Assign struct{ names []Expr; vals []Expr; local bool }
func (s Assign) exec(e *Env)([]Value,bool,error){
	var vs []Value; for _, ex := range s.vals { v,_:=ex.eval(e); vs=append(vs,v) }
	for i,n := range s.names { var v Value; if i<len(vs){v=vs[i]}
		switch x:=n.(type){case Var: if s.local{e.local(x.name,v)}else{e.set(x.name,v)}; case Index: o,_:=x.obj.eval(e); k,_:=x.key.eval(e); if t,ok:=o.(*Table);ok{tableSet(t,k,v)}}
	}
	return nil,false,nil
}
type Return struct{ vals []Expr }
func (s Return) exec(e *Env)([]Value,bool,error){ var vs []Value; for _,ex:=range s.vals{v,_:=ex.eval(e);vs=append(vs,v)}; return vs,true,nil }
type If struct{ cond Expr; then, els []Stmt }
func (s If) exec(e *Env)([]Value,bool,error){ v,_:=s.cond.eval(e); if truth(v){return execBlock(s.then,e)}; return execBlock(s.els,e)}
type While struct{ cond Expr; body []Stmt }
func (s While) exec(e *Env)([]Value,bool,error){ for{v,_:=s.cond.eval(e); if !truth(v){break}; if r,ret,err:=execBlock(s.body,e); ret||err!=nil{return r,ret,err}}; return nil,false,nil}
type ForNum struct{ name string; start,end,step Expr; body []Stmt }
func (s ForNum) exec(e *Env)([]Value,bool,error){ st,_:=s.start.eval(e); en,_:=s.end.eval(e); step:=float64(1); if s.step!=nil{sv,_:=s.step.eval(e); step=num(sv)}; for i:=num(st); (step>=0&&i<=num(en))||(step<0&&i>=num(en)); i+=step{e.local(s.name,i); if r,ret,err:=execBlock(s.body,e); ret||err!=nil{return r,ret,err}}; return nil,false,nil}
type ForIn struct{ names []string; src Expr; body []Stmt }
func (s ForIn) exec(e *Env)([]Value,bool,error){
	v,_:=s.src.eval(e); t,ok:=v.(*Table); if !ok{return nil,false,nil}
	for i,val:=range t.arr{ if len(s.names)>0{e.local(s.names[0],float64(i+1))}; if len(s.names)>1{e.local(s.names[1],val)}; if r,ret,err:=execBlock(s.body,e); ret||err!=nil{return r,ret,err} }
	for k,val:=range t.m{ if len(s.names)>0{e.local(s.names[0],k)}; if len(s.names)>1{e.local(s.names[1],val)}; if r,ret,err:=execBlock(s.body,e); ret||err!=nil{return r,ret,err} }
	return nil,false,nil
}
type FuncDef struct{ name string; params []string; body []Stmt; local bool }
func (s FuncDef) exec(e *Env)([]Value,bool,error){ f:=&Function{params:s.params,body:s.body,env:e}; if s.local{e.local(s.name,f)}else{e.set(s.name,f)}; return nil,false,nil}

func execBlock(st []Stmt,e *Env)([]Value,bool,error){ for _,s:=range st{r,ret,err:=s.exec(e); if ret||err!=nil{return r,ret,err}}; return nil,false,nil}

type Parser struct{ toks []token; pos int }
func (p *Parser) peek() token { return p.toks[p.pos] }
func (p *Parser) eat(t string) bool { if p.peek().typ==t { p.pos++; return true}; return false }
func (p *Parser) need(t string) error { if !p.eat(t){return fmt.Errorf("expected %s near '%s'",t,p.peek().lit)}; return nil }
func (p *Parser) parseBlock(ends map[string]bool)([]Stmt,error){ var ss []Stmt; for !ends[p.peek().typ] && p.peek().typ!="eof"{ if p.eat(";"){continue}; s,err:=p.stmt(); if err!=nil{return nil,err}; ss=append(ss,s)}; return ss,nil}
func (p *Parser) stmt()(Stmt,error){
	if p.eat("local"){ if p.eat("function"){return p.funcdef(true)}; return p.assign(true)}
	if p.eat("function"){return p.funcdef(false)}
	if p.eat("return"){xs,_:=p.exprList(); return Return{xs},nil}
	if p.eat("if"){c,_:=p.expr(0); p.need("then"); th,_:=p.parseBlock(map[string]bool{"else":true,"elseif":true,"end":true}); el:=p.elsePart(); p.need("end"); return If{c,th,el},nil}
	if p.eat("while"){c,_:=p.expr(0); p.need("do"); b,_:=p.parseBlock(map[string]bool{"end":true}); p.need("end"); return While{c,b},nil}
	if p.eat("for"){ name:=p.peek().lit; p.need("name"); if p.eat("="){ st,_:=p.expr(0); p.need(","); en,_:=p.expr(0); var step Expr; if p.eat(","){step,_=p.expr(0)}; p.need("do"); b,_:=p.parseBlock(map[string]bool{"end":true}); p.need("end"); return ForNum{name,st,en,step,b},nil}; names:=[]string{name}; for p.eat(","){names=append(names,p.peek().lit); p.need("name")}; p.need("in"); src,_:=p.expr(0); p.need("do"); b,_:=p.parseBlock(map[string]bool{"end":true}); p.need("end"); return ForIn{names,src,b},nil}
	x,err:=p.prefix(); if err!=nil{return nil,err}
	if c,ok:=x.(Call); ok && !p.eat("="){return ExprStmt{c},nil}
	var names []Expr; names=append(names,x); for p.eat(","){n,_:=p.prefix(); names=append(names,n)}
	p.need("="); vals,_:=p.exprList(); return Assign{names:names,vals:vals},nil
}
func (p *Parser) elsePart() []Stmt {
	if p.eat("else") {
		b,_:=p.parseBlock(map[string]bool{"end":true})
		return b
	}
	if p.eat("elseif") {
		c,_:=p.expr(0); p.need("then")
		th,_:=p.parseBlock(map[string]bool{"else":true,"elseif":true,"end":true})
		return []Stmt{If{c,th,p.elsePart()}}
	}
	return nil
}
func (p *Parser) funcdef(local bool)(Stmt,error){ name:=p.peek().lit; p.need("name"); p.need("("); var ps []string; if !p.eat(")") { for { ps=append(ps,p.peek().lit); p.need("name"); if p.eat(")") {break}; p.need(",") } }; b,_:=p.parseBlock(map[string]bool{"end":true}); p.need("end"); return FuncDef{name,ps,b,local},nil}
func (p *Parser) assign(local bool)(Stmt,error){ var ns []Expr; for{n:=p.peek().lit; p.need("name"); ns=append(ns,Var{n}); if !p.eat(","){break}}; var vals []Expr; if p.eat("="){vals,_=p.exprList()}; return Assign{ns,vals,local},nil}
func (p *Parser) exprList()([]Expr,error){ var xs []Expr; if p.peek().typ=="eof"||p.peek().typ=="end" {return xs,nil}; for{ x,_:=p.expr(0); xs=append(xs,x); if !p.eat(","){break}}; return xs,nil}

var prec=map[string]int{"or":1,"and":2,"==":3,"~=":3,"<":3,">":3,"<=":3,">=":3,"..":4,"+":5,"-":5,"*":6,"/":6,"//":6,"%":6,"^":8}
func (p *Parser) expr(min int)(Expr,error){ left,err:=p.unary(); if err!=nil{return nil,err}; for{op:=p.peek().typ; pr:=prec[op]; if pr<min||pr==0{break}; p.pos++; next:=pr+1; if op=="^"||op==".."{next=pr}; right,_:=p.expr(next); left=Binary{op,left,right}}; return left,nil}
func (p *Parser) unary()(Expr,error){ if p.peek().typ=="-"||p.peek().typ=="not"||p.peek().typ=="#"{op:=p.peek().typ;p.pos++;x,_:=p.unary();return Unary{op,x},nil}; return p.prefix()}
func (p *Parser) prefix()(Expr,error){
	var x Expr; tk:=p.peek(); p.pos++
	switch tk.typ{case "num": if strings.HasPrefix(tk.lit,"0x")||strings.HasPrefix(tk.lit,"0X"){n,_:=strconv.ParseInt(tk.lit[2:],16,64); x=Literal{float64(n)}}else{n,_:=strconv.ParseFloat(tk.lit,64); x=Literal{n}}
	case "str": x=Literal{tk.lit}
	case "true": x=Literal{true}
	case "false": x=Literal{false}
	case "nil": x=Literal{nil}
	case "name": x=Var{tk.lit}
	case "(": x,_=p.expr(0); p.need(")")
	case "{": te:=TableExpr{fields:map[string]Expr{}}; idx:=1; for !p.eat("}"){ if p.peek().typ=="name" && p.toks[p.pos+1].typ=="="{k:=p.peek().lit;p.pos+=2;v,_:=p.expr(0);te.fields[k]=v}else{v,_:=p.expr(0);te.vals=append(te.vals,v);_ = idx;idx++}; p.eat(","); p.eat(";")}; x=te
	default: return nil,fmt.Errorf("unexpected symbol near '%s'",tk.lit)}
	for{ if p.eat("."){k:=p.peek().lit;p.need("name"); x=Index{x,Literal{k}}; continue}; if p.eat("["){k,_:=p.expr(0);p.need("]");x=Index{x,k};continue}; if p.eat("("){var args []Expr; if !p.eat(")") {for{a,_:=p.expr(0);args=append(args,a); if p.eat(")"){break}; p.need(",")}}; x=Call{x,args}; continue}; break}
	return x,nil
}

func tableGet(t *Table,k Value)Value{ if n,ok:=isInt(k);ok{ if n>=1&&n<=len(t.arr){return t.arr[n-1]}; return nil}; return t.m[str(k)]}
func tableSet(t *Table,k,v Value){ if n,ok:=isInt(k);ok{ for len(t.arr)<n{t.arr=append(t.arr,nil)}; t.arr[n-1]=v; return}; t.m[str(k)]=v}
func isInt(v Value)(int,bool){ switch x:=v.(type){case float64: if x==math.Trunc(x){return int(x),true}; case int: return x,true}; return 0,false}
func truth(v Value)bool{ if v==nil{return false}; if b,ok:=v.(bool);ok{return b}; return true}
func num(v Value)float64{ switch x:=v.(type){case float64:return x; case int:return float64(x); case string:n,_:=strconv.ParseFloat(x,64);return n}; return 0}
func str(v Value)string{ switch x:=v.(type){case nil:return "nil"; case string:return x; case bool: if x{return "true"}; return "false"; case float64: if x==math.Trunc(x){return strconv.FormatInt(int64(x),10)}; return strconv.FormatFloat(x,'g',-1,64); case *Table:return "table: 0x1"; case *Function:return "function: 0x1"}; return fmt.Sprint(v)}
func eq(a,b Value)bool{ switch x:=a.(type){case nil:return b==nil; case bool: y,ok:=b.(bool);return ok&&x==y; case string:y,ok:=b.(string);return ok&&x==y; case float64:return x==num(b)}; return a==b}
func cmp(a,b Value)int{ if as,ok:=a.(string);ok{bs:=str(b); if as<bs{return -1}; if as>bs{return 1}; return 0}; an,bn:=num(a),num(b); if an<bn{return -1}; if an>bn{return 1}; return 0}

func baseEnv(args []string)*Env{
	e:=&Env{vars:map[string]Value{}}
	e.local("_VERSION","Lua 5.5")
	e.local("print",&Function{native:func(vs []Value)([]Value,error){for i,v:=range vs{if i>0{fmt.Print("\t")};fmt.Print(str(v))};fmt.Println();return nil,nil}})
	e.local("tonumber",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0{return []Value{nil},nil}; n,err:=strconv.ParseFloat(str(vs[0]),64); if err!=nil{return []Value{nil},nil}; return []Value{n},nil}})
	e.local("tostring",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0{return []Value{""},nil}; return []Value{str(vs[0])},nil}})
	e.local("type",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0||vs[0]==nil{return []Value{"nil"},nil}; switch vs[0].(type){case bool:return []Value{"boolean"},nil; case float64:return []Value{"number"},nil; case string:return []Value{"string"},nil; case *Table:return []Value{"table"},nil; case *Function:return []Value{"function"},nil}; return []Value{"userdata"},nil}})
	e.local("assert",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0||!truth(vs[0]){return nil,fmt.Errorf("assertion failed!")}; return vs,nil}})
	e.local("error",&Function{native:func(vs []Value)([]Value,error){if len(vs)>0{return nil,fmt.Errorf(str(vs[0]))}; return nil,fmt.Errorf("error")}})
	e.local("pcall",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0{return []Value{false,"attempt to call a nil value"},nil}; f,ok:=vs[0].(*Function); if !ok{return []Value{false,"attempt to call a non-function value"},nil}; r,err:=f.native(vs[1:]); if err!=nil{return []Value{false,err.Error()},nil}; return append([]Value{true},r...),nil}})
	e.local("pairs",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0{return []Value{nil},nil}; return []Value{vs[0]},nil}})
	e.local("ipairs",&Function{native:func(vs []Value)([]Value,error){if len(vs)==0{return []Value{nil},nil}; return []Value{vs[0]},nil}})
	argt:=&Table{m:map[string]Value{}}; for i,a:=range args{tableSet(argt,float64(i),a)}; e.local("arg",argt)
	mathT:=&Table{m:map[string]Value{"pi":math.Pi,"huge":math.Inf(1)}}; unaryMath:=map[string]func(float64)float64{"sin":math.Sin,"cos":math.Cos,"tan":math.Tan,"sqrt":math.Sqrt,"abs":math.Abs,"floor":math.Floor,"ceil":math.Ceil,"exp":math.Exp,"log":math.Log}
	for k,fn:=range unaryMath{f:=fn; mathT.m[k]=&Function{native:func(vs []Value)([]Value,error){return []Value{f(num(vs[0]))},nil}}}
	mathT.m["type"]=&Function{native:func(vs []Value)([]Value,error){if len(vs)==0{return []Value{nil},nil}; if _,ok:=isInt(vs[0]);ok{return []Value{"integer"},nil}; return []Value{"float"},nil}}
	mathT.m["max"]=&Function{native:func(vs []Value)([]Value,error){m:=num(vs[0]); for _,v:=range vs[1:]{if num(v)>m{m=num(v)}}; return []Value{m},nil}}
	mathT.m["min"]=&Function{native:func(vs []Value)([]Value,error){m:=num(vs[0]); for _,v:=range vs[1:]{if num(v)<m{m=num(v)}}; return []Value{m},nil}}
	e.local("math",mathT)
	stringT:=&Table{m:map[string]Value{}}
	stringT.m["len"]=&Function{native:func(vs []Value)([]Value,error){return []Value{float64(len(str(vs[0])))},nil}}
	stringT.m["upper"]=&Function{native:func(vs []Value)([]Value,error){return []Value{strings.ToUpper(str(vs[0]))},nil}}
	stringT.m["lower"]=&Function{native:func(vs []Value)([]Value,error){return []Value{strings.ToLower(str(vs[0]))},nil}}
	stringT.m["sub"]=&Function{native:func(vs []Value)([]Value,error){s:=str(vs[0]); i:=int(num(vs[1])); j:=len(s); if len(vs)>2{j=int(num(vs[2]))}; if i<0{i=len(s)+i+1}; if j<0{j=len(s)+j+1}; if i<1{i=1}; if j>len(s){j=len(s)}; if i>j{return []Value{""},nil}; return []Value{s[i-1:j]},nil}}
	e.local("string",stringT)
	tableT:=&Table{m:map[string]Value{}}
	tableT.m["insert"]=&Function{native:func(vs []Value)([]Value,error){if t,ok:=vs[0].(*Table);ok{t.arr=append(t.arr,vs[1])}; return nil,nil}}
	tableT.m["concat"]=&Function{native:func(vs []Value)([]Value,error){t,_:=vs[0].(*Table); sep:=""; if len(vs)>1{sep=str(vs[1])}; var ss []string; for _,v:=range t.arr{ss=append(ss,str(v))}; return []Value{strings.Join(ss,sep)},nil}}
	e.local("table",tableT)
	osT:=&Table{m:map[string]Value{}}
	osT.m["time"]=&Function{native:func(vs []Value)([]Value,error){return []Value{float64(time.Now().Unix())},nil}}
	osT.m["date"]=&Function{native:func(vs []Value)([]Value,error){layout:="%c"; if len(vs)>0{layout=str(vs[0])}; if layout=="%Y"{return []Value{time.Now().Format("2006")},nil}; return []Value{time.Now().Format(time.ANSIC)},nil}}
	e.local("os",osT)
	utf8T:=&Table{m:map[string]Value{}}
	utf8T.m["len"]=&Function{native:func(vs []Value)([]Value,error){return []Value{float64(len([]rune(str(vs[0]))))},nil}}
	e.local("utf8",utf8T)
	return e
}

func run(src string, args []string) int {
	toks,err:=lex(src); if err!=nil{fmt.Fprintln(os.Stderr,err); return 1}
	p:=&Parser{toks:toks}; st,err:=p.parseBlock(map[string]bool{"eof":true}); if err!=nil{fmt.Fprintln(os.Stderr,err); return 1}
	_,_,err=execBlock(st,baseEnv(args)); if err!=nil{fmt.Fprintln(os.Stderr,err); return 1}; return 0
}

func usage() {
	fmt.Fprintf(os.Stderr, "usage: %s [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin\n", os.Args[0])
}
func main(){
	var chunks []string; args:=os.Args[1:]; i:=0; interactive:=false
	for i<len(args){a:=args[i]; if a=="--"{i++;break}; if a=="-"{b,_:=io.ReadAll(os.Stdin);chunks=append(chunks,string(b));i++;break}; if !strings.HasPrefix(a,"-")||a=="-"{break}; switch a{case "-v":fmt.Println("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"); case "-i":interactive=true; case "-E","-W": case "-e": if i+1>=len(args){usage();os.Exit(1)}; chunks=append(chunks,args[i+1]); i++; case "-l": i++; default: fmt.Fprintf(os.Stderr,"%s: unrecognized option '%s'\n",os.Args[0],a); usage(); os.Exit(1)}; i++}
	if i<len(args){b,err:=os.ReadFile(args[i]); if err!=nil{fmt.Fprintf(os.Stderr,"%s: cannot open %s: %s\n",os.Args[0],args[i],err.Error()); os.Exit(1)}; chunks=append(chunks,string(b)); scriptArgs:=append([]string{args[i]},args[i+1:]...); os.Exit(run(strings.Join(chunks,"\n"),scriptArgs))}
	if len(chunks)==0 || interactive { if len(chunks)==0 { b,_:=io.ReadAll(bufio.NewReader(os.Stdin)); if len(b)>0{chunks=append(chunks,string(b))} } }
	if len(chunks)>0{os.Exit(run(strings.Join(chunks,"\n"),args[i:]))}
}
