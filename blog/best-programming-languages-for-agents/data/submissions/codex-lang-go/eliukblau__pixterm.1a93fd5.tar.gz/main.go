package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"log"
	"math"
	"net/http"
	"os"
	"strconv"
	"strings"

	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
)

const version = "1.3.2"

const banner = `   ___  _____  ____
  / _ \/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\__/\__/_/ /_/_/_/                1.3.2
`

const credits = `CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.
`

type options struct {
	dither  int
	scale   int
	cols    int
	rows    int
	matte   color.NRGBA
	noBG    bool
	goPrint bool
}

func main() {
	log.SetPrefix("[PIXTERM ERROR] ")
	log.SetFlags(log.LstdFlags)

	var showVersion, showCredits bool
	var matte string
	opts := options{cols: 80, rows: 24, matte: color.NRGBA{0, 0, 0, 255}}

	fs := flag.NewFlagSet(os.Args[0], flag.ExitOnError)
	fs.Usage = func() { printHelp() }
	fs.BoolVar(&showVersion, "version", false, "show PIXterm version")
	fs.BoolVar(&showCredits, "credits", false, "show some love to contributors <3")
	fs.IntVar(&opts.dither, "d", 0, "dithering mode")
	fs.BoolVar(&opts.goPrint, "go", false, "output Go code to 'fmt.Print()' the image")
	fs.StringVar(&matte, "m", "000000", "matte color for transparency or background")
	fs.BoolVar(&opts.noBG, "nobg", false, "disable background color")
	fs.IntVar(&opts.scale, "s", 0, "scale method")
	fs.IntVar(&opts.cols, "tc", 80, "terminal columns")
	fs.IntVar(&opts.rows, "tr", 24, "terminal rows")
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}

	if showVersion {
		fmt.Println(version)
		return
	}
	if showCredits {
		fmt.Println(banner)
		fmt.Print(credits)
		return
	}
	if opts.dither < 0 || opts.dither > 2 || opts.scale < 0 || opts.scale > 2 || opts.cols < 2 || opts.rows < 2 || fs.NArg() != 1 {
		printHelp()
		os.Exit(2)
	}
	c, err := parseHexColor(matte)
	if err != nil {
		printHelp()
		log.Fatalf("matte color : %s is not a hex-color", matte)
	}
	opts.matte = c

	img, err := loadImage(fs.Arg(0))
	if err != nil {
		printHelp()
		log.Fatal(err)
	}
	var out string
	if opts.dither == 0 {
		out = renderClassic(img, opts)
	} else {
		out = renderDither(img, opts)
	}
	if opts.goPrint {
		for _, line := range strings.SplitAfter(out, "\n") {
			if line == "" {
				continue
			}
			fmt.Printf("fmt.Print(%q)\n", line)
		}
	} else {
		fmt.Print(out)
	}
}

func printHelp() {
	fmt.Println(banner)
	fmt.Println("USAGE:")
	fmt.Println()
	fmt.Println("  executable [options] image/url")
	fmt.Println()
	fmt.Println("  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.")
	fmt.Println("  Supported URL protocols: HTTP, HTTPS.")
	fmt.Println()
	fmt.Println("OPTIONS:")
	fmt.Println()
	fmt.Println("  -credits")
	fmt.Println("    \tshow some love to contributors <3")
	fmt.Println("  -d mode")
	fmt.Println("    \tdithering mode:")
	fmt.Println("    \t   0 - no dithering (default)")
	fmt.Println("    \t   1 - with blocks")
	fmt.Println("    \t   2 - with chars")
	fmt.Println("  -go")
	fmt.Println("    \toutput Go code to 'fmt.Print()' the image")
	fmt.Println("  -m color")
	fmt.Println("    \tmatte color for transparency or background")
	fmt.Println("    \t(optional, hex format, default: 000000)")
	fmt.Println("  -nobg")
	fmt.Println("    \tdisable background color")
	fmt.Println("    \t(optional, only in dithering mode, ignores matte color)")
	fmt.Println("  -s method")
	fmt.Println("    \tscale method:")
	fmt.Println("    \t   0 - resize (default)")
	fmt.Println("    \t   1 - fill")
	fmt.Println("    \t   2 - fit")
	fmt.Println("  -tc columns")
	fmt.Println("    \tterminal columns (optional, >=2; when piping, default: 80)")
	fmt.Println("  -tr rows")
	fmt.Println("    \tterminal rows (optional, >=2; when piping, default: 24)")
	fmt.Println("  -version")
	fmt.Println("    \tshow PIXterm version")
	fmt.Println("  -help")
	fmt.Println("\tprints this message :D LOL")
	fmt.Println()
}

func parseHexColor(s string) (color.NRGBA, error) {
	if len(s) == 7 && s[0] == '#' {
		s = s[1:]
	}
	if len(s) != 6 {
		return color.NRGBA{}, errors.New("bad color")
	}
	v, err := strconv.ParseUint(s, 16, 32)
	if err != nil {
		return color.NRGBA{}, err
	}
	return color.NRGBA{uint8(v >> 16), uint8(v >> 8), uint8(v), 255}, nil
}

func loadImage(path string) (image.Image, error) {
	var data []byte
	var err error
	if strings.HasPrefix(path, "http://") || strings.HasPrefix(path, "https://") {
		resp, e := http.Get(path)
		if e != nil {
			return nil, e
		}
		defer resp.Body.Close()
		data, err = io.ReadAll(resp.Body)
	} else {
		data, err = os.ReadFile(path)
	}
	if err != nil {
		return nil, err
	}
	if img, format, err := image.Decode(bytes.NewReader(data)); err == nil && format != "" {
		return img, nil
	}
	if img, err := decodeBMP(data); err == nil {
		return img, nil
	}
	return nil, errors.New("image: unknown format")
}

func renderClassic(src image.Image, opts options) string {
	img := scaled(src, opts.cols, opts.rows*2, opts.scale, opts.matte)
	var b strings.Builder
	for y := 0; y < opts.rows; y++ {
		for x := 0; x < opts.cols; x++ {
			top := img.NRGBAAt(x, y*2)
			bot := img.NRGBAAt(x, y*2+1)
			fmt.Fprintf(&b, "\033[48;2;%d;%d;%dm\033[38;2;%d;%d;%dm▄", top.R, top.G, top.B, bot.R, bot.G, bot.B)
		}
		b.WriteString("\033[0m\n")
	}
	return b.String()
}

func renderDither(src image.Image, opts options) string {
	img := scaled(src, opts.cols, opts.rows, opts.scale, opts.matte)
	blocks := []rune{' ', '░', '▒', '▓', '█'}
	chars := []rune("  .,:;i1tfLCG08@")
	var b strings.Builder
	for y := 0; y < opts.rows; y++ {
		for x := 0; x < opts.cols; x++ {
			p := img.NRGBAAt(x, y)
			lum := 0.2126*float64(p.R) + 0.7152*float64(p.G) + 0.0722*float64(p.B)
			if opts.dither == 1 {
				idx := int(math.Round(lum / 255 * float64(len(blocks)-1)))
				if idx < 0 {
					idx = 0
				}
				if idx >= len(blocks) {
					idx = len(blocks) - 1
				}
				writeDitherPixel(&b, p, opts, blocks[idx])
			} else {
				idx := int(math.Round(lum / 255 * float64(len(chars)-1)))
				if idx < 0 {
					idx = 0
				}
				if idx >= len(chars) {
					idx = len(chars) - 1
				}
				writeDitherPixel(&b, p, opts, chars[idx])
			}
		}
		b.WriteString("\033[0m\n")
	}
	return b.String()
}

func writeDitherPixel(b *strings.Builder, p color.NRGBA, opts options, r rune) {
	if !opts.noBG {
		fmt.Fprintf(b, "\033[48;2;%d;%d;%dm", opts.matte.R, opts.matte.G, opts.matte.B)
	}
	fmt.Fprintf(b, "\033[38;2;%d;%d;%dm%c", p.R, p.G, p.B, r)
}

func scaled(src image.Image, w, h, method int, matte color.NRGBA) *image.NRGBA {
	canvas := image.NewNRGBA(image.Rect(0, 0, w, h))
	draw.Draw(canvas, canvas.Bounds(), &image.Uniform{matte}, image.Point{}, draw.Src)
	sb := src.Bounds()
	sw, sh := sb.Dx(), sb.Dy()
	dx, dy, dw, dh := 0, 0, w, h
	if method == 1 || method == 2 {
		rx := float64(w) / float64(sw)
		ry := float64(h) / float64(sh)
		r := rx
		if method == 1 {
			if ry > r {
				r = ry
			}
		} else if ry < r {
			r = ry
		}
		dw = int(math.Round(float64(sw) * r))
		dh = int(math.Round(float64(sh) * r))
		dx = (w - dw) / 2
		dy = (h - dh) / 2
	}
	for y := 0; y < dh; y++ {
		ty := dy + y
		if ty < 0 || ty >= h {
			continue
		}
		for x := 0; x < dw; x++ {
			tx := dx + x
			if tx < 0 || tx >= w {
				continue
			}
			sx := (float64(x)+0.5)*float64(sw)/float64(dw) - 0.5
			sy := (float64(y)+0.5)*float64(sh)/float64(dh) - 0.5
			p := sampleBilinear(src, sx+float64(sb.Min.X), sy+float64(sb.Min.Y), matte)
			canvas.SetNRGBA(tx, ty, p)
		}
	}
	return canvas
}

func sampleBilinear(img image.Image, fx, fy float64, matte color.NRGBA) color.NRGBA {
	b := img.Bounds()
	x0 := int(math.Floor(fx))
	y0 := int(math.Floor(fy))
	x1 := x0 + 1
	y1 := y0 + 1
	wx := fx - float64(x0)
	wy := fy - float64(y0)
	c00 := pixelAt(img, clamp(x0, b.Min.X, b.Max.X-1), clamp(y0, b.Min.Y, b.Max.Y-1), matte)
	c10 := pixelAt(img, clamp(x1, b.Min.X, b.Max.X-1), clamp(y0, b.Min.Y, b.Max.Y-1), matte)
	c01 := pixelAt(img, clamp(x0, b.Min.X, b.Max.X-1), clamp(y1, b.Min.Y, b.Max.Y-1), matte)
	c11 := pixelAt(img, clamp(x1, b.Min.X, b.Max.X-1), clamp(y1, b.Min.Y, b.Max.Y-1), matte)
	return color.NRGBA{
		R: uint8(math.Round(lerp(lerp(float64(c00.R), float64(c10.R), wx), lerp(float64(c01.R), float64(c11.R), wx), wy))),
		G: uint8(math.Round(lerp(lerp(float64(c00.G), float64(c10.G), wx), lerp(float64(c01.G), float64(c11.G), wx), wy))),
		B: uint8(math.Round(lerp(lerp(float64(c00.B), float64(c10.B), wx), lerp(float64(c01.B), float64(c11.B), wx), wy))),
		A: 255,
	}
}

func pixelAt(img image.Image, x, y int, matte color.NRGBA) color.NRGBA {
	r, g, b, a := img.At(x, y).RGBA()
	if a == 0 {
		return matte
	}
	af := float64(a) / 65535
	return color.NRGBA{
		R: uint8(math.Round(float64(r)/257*af + float64(matte.R)*(1-af))),
		G: uint8(math.Round(float64(g)/257*af + float64(matte.G)*(1-af))),
		B: uint8(math.Round(float64(b)/257*af + float64(matte.B)*(1-af))),
		A: 255,
	}
}

func lerp(a, b, t float64) float64 { return a + (b-a)*t }

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func decodeBMP(data []byte) (image.Image, error) {
	if len(data) < 54 || string(data[:2]) != "BM" {
		return nil, errors.New("not bmp")
	}
	off := int(binary.LittleEndian.Uint32(data[10:14]))
	w := int(int32(binary.LittleEndian.Uint32(data[18:22])))
	h0 := int(int32(binary.LittleEndian.Uint32(data[22:26])))
	bpp := int(binary.LittleEndian.Uint16(data[28:30]))
	comp := binary.LittleEndian.Uint32(data[30:34])
	if w <= 0 || h0 == 0 || comp != 0 || (bpp != 24 && bpp != 32) {
		return nil, errors.New("unsupported bmp")
	}
	topDown := h0 < 0
	h := h0
	if h < 0 {
		h = -h
	}
	img := image.NewNRGBA(image.Rect(0, 0, w, h))
	stride := ((w*bpp + 31) / 32) * 4
	for y := 0; y < h; y++ {
		sy := h - 1 - y
		if topDown {
			sy = y
		}
		row := off + sy*stride
		for x := 0; x < w; x++ {
			i := row + x*(bpp/8)
			if i+2 >= len(data) {
				return nil, io.ErrUnexpectedEOF
			}
			a := uint8(255)
			if bpp == 32 && i+3 < len(data) {
				a = data[i+3]
			}
			img.SetNRGBA(x, y, color.NRGBA{R: data[i+2], G: data[i+1], B: data[i], A: a})
		}
	}
	return img, nil
}

func init() {
	image.RegisterFormat("png", "\x89PNG\r\n\x1a\n", png.Decode, png.DecodeConfig)
	image.RegisterFormat("jpeg", "\xff\xd8", jpeg.Decode, jpeg.DecodeConfig)
	image.RegisterFormat("gif", "GIF8?a", gif.Decode, gif.DecodeConfig)
}
