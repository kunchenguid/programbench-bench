module pixterm-reimpl

go 1.21
