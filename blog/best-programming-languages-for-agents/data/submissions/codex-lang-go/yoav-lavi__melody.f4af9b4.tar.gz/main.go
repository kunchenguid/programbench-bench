package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"regexp"
	"strconv"
	"strings"
	"unicode"
)

const version = "melody_cli 0.20.0"

type tokenType int

const (
	tEOF tokenType = iota
	tIdent
	tNumber
	tString
	tRaw
	tSymbol
	tLBrace
	tRBrace
	tSemi
)

type token struct {
	typ  tokenType
	lit  string
	line int
	col  int
}

type lexer struct {
	src  []rune
	i    int
	line int
	col  int
}

func lex(src string) ([]token, error) {
	l := &lexer{src: []rune(src), line: 1, col: 1}
	var toks []token
	for {
		l.skipSpaceAndComments()
		if l.i >= len(l.src) {
			break
		}
		ch := l.peek()
		startLine, startCol := l.line, l.col
		switch {
		case ch == '{':
			l.next()
			toks = append(toks, token{tLBrace, "{", startLine, startCol})
		case ch == '}':
			l.next()
			toks = append(toks, token{tRBrace, "}", startLine, startCol})
		case ch == ';':
			l.next()
			toks = append(toks, token{tSemi, ";", startLine, startCol})
		case ch == '"':
			s, err := l.scanQuoted('"')
			if err != nil {
				return nil, err
			}
			toks = append(toks, token{tString, s, startLine, startCol})
		case ch == '`':
			s, err := l.scanQuoted('`')
			if err != nil {
				return nil, err
			}
			toks = append(toks, token{tRaw, s, startLine, startCol})
		case ch == '<':
			l.next()
			var b strings.Builder
			for l.i < len(l.src) && l.peek() != '>' {
				b.WriteRune(l.next())
			}
			if l.i >= len(l.src) {
				return nil, fmt.Errorf("unterminated symbol")
			}
			l.next()
			toks = append(toks, token{tSymbol, strings.TrimSpace(b.String()), startLine, startCol})
		case unicode.IsDigit(ch):
			var b strings.Builder
			for l.i < len(l.src) && unicode.IsDigit(l.peek()) {
				b.WriteRune(l.next())
			}
			toks = append(toks, token{tNumber, b.String(), startLine, startCol})
		case isIdentStart(ch):
			var b strings.Builder
			for l.i < len(l.src) && isIdentPart(l.peek()) {
				b.WriteRune(l.next())
			}
			toks = append(toks, token{tIdent, b.String(), startLine, startCol})
		default:
			return nil, fmt.Errorf("unexpected character %q", ch)
		}
	}
	toks = append(toks, token{tEOF, "", l.line, l.col})
	return toks, nil
}

func (l *lexer) peek() rune { return l.src[l.i] }
func (l *lexer) next() rune {
	ch := l.src[l.i]
	l.i++
	if ch == '\n' {
		l.line++
		l.col = 1
	} else {
		l.col++
	}
	return ch
}
func (l *lexer) skipSpaceAndComments() {
	for l.i < len(l.src) {
		ch := l.peek()
		if unicode.IsSpace(ch) {
			l.next()
			continue
		}
		if ch == '/' && l.i+1 < len(l.src) && l.src[l.i+1] == '/' {
			for l.i < len(l.src) && l.peek() != '\n' {
				l.next()
			}
			continue
		}
		if ch == '/' && l.i+1 < len(l.src) && l.src[l.i+1] == '*' {
			l.next()
			l.next()
			for l.i+1 < len(l.src) && !(l.src[l.i] == '*' && l.src[l.i+1] == '/') {
				l.next()
			}
			if l.i+1 < len(l.src) {
				l.next()
				l.next()
			}
			continue
		}
		break
	}
}
func (l *lexer) scanQuoted(q rune) (string, error) {
	l.next()
	var b strings.Builder
	for l.i < len(l.src) {
		ch := l.next()
		if ch == q {
			return b.String(), nil
		}
		if q == '"' && ch == '\\' && l.i < len(l.src) {
			n := l.next()
			switch n {
			case 'n':
				b.WriteRune('\n')
			case 't':
				b.WriteRune('\t')
			case 'r':
				b.WriteRune('\r')
			case 'f':
				b.WriteRune('\f')
			case 'v':
				b.WriteRune('\v')
			case '0':
				b.WriteRune(0)
			case '\\':
				b.WriteRune('\\')
			case '"':
				b.WriteRune('"')
			default:
				b.WriteRune(n)
			}
		} else {
			b.WriteRune(ch)
		}
	}
	return "", fmt.Errorf("unterminated string")
}
func isIdentStart(r rune) bool { return unicode.IsLetter(r) || r == '_' }
func isIdentPart(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '-'
}

type parser struct {
	toks []token
	pos  int
}

func compileMelody(src string) (string, error) {
	toks, err := lex(src)
	if err != nil {
		return "", err
	}
	p := &parser{toks: toks}
	out, err := p.parseSeq(false)
	if err != nil {
		return "", err
	}
	if !p.at(tEOF) {
		return "", p.err("expected root")
	}
	return out, nil
}

func (p *parser) cur() token           { return p.toks[p.pos] }
func (p *parser) at(tt tokenType) bool { return p.cur().typ == tt }
func (p *parser) match(tt tokenType) (token, bool) {
	if p.at(tt) {
		t := p.cur()
		p.pos++
		return t, true
	}
	return token{}, false
}
func (p *parser) matchIdent(s string) bool {
	if p.cur().typ == tIdent && p.cur().lit == s {
		p.pos++
		return true
	}
	return false
}
func (p *parser) expect(tt tokenType) (token, error) {
	if t, ok := p.match(tt); ok {
		return t, nil
	}
	return token{}, p.err("expected root")
}
func (p *parser) err(msg string) error {
	t := p.cur()
	return fmt.Errorf(" --> %d:%d\n  |\n%d | %s\n  | ^---\n  |\n  = %s", t.line, t.col, t.line, p.lineText(t.line), msg)
}
func (p *parser) lineText(line int) string { return "" }

func (p *parser) parseSeq(inBlock bool) (string, error) {
	var parts []string
	for !p.at(tEOF) && !(inBlock && p.at(tRBrace)) {
		if p.at(tSemi) {
			p.pos++
			continue
		}
		x, err := p.parseStmt()
		if err != nil {
			return "", err
		}
		parts = append(parts, x)
		p.match(tSemi)
	}
	return strings.Join(parts, ""), nil
}

func (p *parser) parseStmt() (string, error) {
	// quantifiers
	if p.cur().typ == tNumber || (p.cur().typ == tIdent && (p.cur().lit == "some" || p.cur().lit == "any" || p.cur().lit == "option" || p.cur().lit == "over")) {
		if q, ok, err := p.tryQuant(); ok || err != nil {
			return q, err
		}
	}
	if p.matchIdent("match") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?:" + body + ")", nil
	}
	if p.matchIdent("either") {
		alts, err := p.parseAltBlock()
		if err != nil {
			return "", err
		}
		return "(?:" + strings.Join(alts, "|") + ")", nil
	}
	if p.matchIdent("capture") {
		name := ""
		if p.cur().typ == tIdent {
			name = p.cur().lit
			p.pos++
		}
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		if name != "" {
			return "(?<" + name + ">" + body + ")", nil
		}
		return "(" + body + ")", nil
	}
	if p.matchIdent("ahead") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?=" + body + ")", nil
	}
	if p.matchIdent("behind") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?<=" + body + ")", nil
	}
	if p.matchIdent("not") {
		return p.parseNot()
	}
	return p.parseAtom()
}

func (p *parser) tryQuant() (string, bool, error) {
	start := p.pos
	var suffix string
	if p.cur().typ == tNumber {
		n := p.cur().lit
		p.pos++
		if p.matchIdent("to") {
			if p.cur().typ != tNumber {
				p.pos = start
				return "", false, nil
			}
			m := p.cur().lit
			p.pos++
			if !p.matchIdent("of") {
				p.pos = start
				return "", false, nil
			}
			suffix = "{" + n + "," + m + "}"
		} else if p.matchIdent("of") {
			suffix = "{" + n + "}"
		} else {
			p.pos = start
			return "", false, nil
		}
	} else if p.matchIdent("some") {
		if !p.matchIdent("of") {
			p.pos = start
			return "", false, nil
		}
		suffix = "+"
	} else if p.matchIdent("any") {
		if !p.matchIdent("of") {
			p.pos = start
			return "", false, nil
		}
		suffix = "*"
	} else if p.matchIdent("option") {
		if !p.matchIdent("of") {
			p.pos = start
			return "", false, nil
		}
		suffix = "?"
	} else if p.matchIdent("over") {
		if p.cur().typ != tNumber {
			return "", true, p.err("expected amount")
		}
		n, _ := strconv.Atoi(p.cur().lit)
		p.pos++
		if !p.matchIdent("of") {
			return "", true, p.err("expected of")
		}
		suffix = "{" + strconv.Itoa(n+1) + ",}"
	}
	atom, err := p.parseAtom()
	if err != nil {
		return "", true, err
	}
	return quantTarget(atom) + suffix, true, nil
}

func quantTarget(s string) string {
	if len([]rune(s)) == 1 || strings.HasPrefix(s, "[") || strings.HasPrefix(s, "\\") || s == "." {
		return s
	}
	if strings.HasPrefix(s, "(?:") || strings.HasPrefix(s, "(") || strings.HasPrefix(s, "(?") {
		return s
	}
	return "(?:" + s + ")"
}

func (p *parser) parseAtom() (string, error) {
	if t, ok := p.match(tString); ok {
		return regexp.QuoteMeta(t.lit), nil
	}
	if t, ok := p.match(tRaw); ok {
		return t.lit, nil
	}
	if t, ok := p.match(tSymbol); ok {
		return symbol(t.lit, false)
	}
	if isRangeStart(p.cur()) && p.pos+2 < len(p.toks) && p.toks[p.pos+1].typ == tIdent && p.toks[p.pos+1].lit == "to" && isRangeStart(p.toks[p.pos+2]) {
		a := p.cur().lit
		p.pos += 2
		b := p.cur().lit
		p.pos++
		return "[" + escapeClass(a) + "-" + escapeClass(b) + "]", nil
	}
	if p.matchIdent("match") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?:" + body + ")", nil
	}
	if p.matchIdent("either") {
		alts, err := p.parseAltBlock()
		if err != nil {
			return "", err
		}
		return "(?:" + strings.Join(alts, "|") + ")", nil
	}
	if p.matchIdent("capture") {
		name := ""
		if p.cur().typ == tIdent {
			name = p.cur().lit
			p.pos++
		}
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		if name != "" {
			return "(?<" + name + ">" + body + ")", nil
		}
		return "(" + body + ")", nil
	}
	if p.matchIdent("ahead") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?=" + body + ")", nil
	}
	if p.matchIdent("behind") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?<=" + body + ")", nil
	}
	if p.matchIdent("not") {
		return p.parseNot()
	}
	return "", p.err("expected root")
}

func (p *parser) parseNot() (string, error) {
	if p.matchIdent("ahead") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?!" + body + ")", nil
	}
	if p.matchIdent("behind") {
		body, err := p.parseBlock()
		if err != nil {
			return "", err
		}
		return "(?<!" + body + ")", nil
	}
	if t, ok := p.match(tSymbol); ok {
		return symbol(t.lit, true)
	}
	if isRangeStart(p.cur()) && p.pos+2 < len(p.toks) && p.toks[p.pos+1].typ == tIdent && p.toks[p.pos+1].lit == "to" && isRangeStart(p.toks[p.pos+2]) {
		a := p.cur().lit
		p.pos += 2
		b := p.cur().lit
		p.pos++
		return "[^" + escapeClass(a) + "-" + escapeClass(b) + "]", nil
	}
	return "", p.err("expected amount, class_content, or assertion_type")
}

func (p *parser) parseBlock() (string, error) {
	if _, err := p.expect(tLBrace); err != nil {
		return "", err
	}
	body, err := p.parseSeq(true)
	if err != nil {
		return "", err
	}
	if _, err := p.expect(tRBrace); err != nil {
		return "", err
	}
	return body, nil
}
func (p *parser) parseAltBlock() ([]string, error) {
	if _, err := p.expect(tLBrace); err != nil {
		return nil, err
	}
	var alts []string
	for !p.at(tEOF) && !p.at(tRBrace) {
		if p.at(tSemi) {
			p.pos++
			continue
		}
		s, err := p.parseStmt()
		if err != nil {
			return nil, err
		}
		alts = append(alts, s)
		p.match(tSemi)
	}
	if _, err := p.expect(tRBrace); err != nil {
		return nil, err
	}
	return alts, nil
}

func symbol(s string, neg bool) (string, error) {
	if neg {
		switch s {
		case "digit":
			return "\\D", nil
		case "word":
			return "\\W", nil
		case "whitespace":
			return "\\S", nil
		case "space":
			return "[^ ]", nil
		case "boundary":
			return "\\B", nil
		case "alphabetic":
			return "[^a-zA-Z]", nil
		case "alphanumeric":
			return "[^a-zA-Z0-9]", nil
		case "char":
			return "(?!)", nil
		}
	}
	switch s {
	case "char":
		return ".", nil
	case "space":
		return " ", nil
	case "whitespace":
		return "\\s", nil
	case "digit":
		return "\\d", nil
	case "word":
		return "\\w", nil
	case "start":
		return "^", nil
	case "end":
		return "$", nil
	case "alphabetic":
		return "[a-zA-Z]", nil
	case "alphanumeric":
		return "[a-zA-Z0-9]", nil
	case "newline":
		return "\\n", nil
	case "tab":
		return "\\t", nil
	case "return":
		return "\\r", nil
	case "feed":
		return "\\f", nil
	case "null":
		return "\\0", nil
	case "vertical":
		return "\\v", nil
	case "backspace":
		return "[\\b]", nil
	case "boundary":
		return "\\b", nil
	}
	return "", errors.New("usage of an unrecognized symbol")
}
func isRangeStart(t token) bool { return t.typ == tIdent || t.typ == tNumber }
func escapeClass(s string) string {
	return strings.NewReplacer("\\", "\\\\", "-", "\\-", "]", "\\]", "^", "\\^").Replace(s)
}

func printHelp() {
	fmt.Print(`A CLI wrapping the Melody language compiler

Usage: executable [OPTIONS] [INPUT_FILE_PATH]

Arguments:
  [INPUT_FILE_PATH]  Read from a file
                     Use '-' and or pipe input to read from stdin

Options:
  -o, --output <OUTPUT_FILE_PATH>           Write to a file
  -n, --no-color                            Print output with no color
  -r, --repl                                Start the Melody REPL
      --generate-completions <completions>  Outputs completions for the selected shell
                                            To use, write the output to the appropriate location for your shell
  -t, --test <test>                         Test the compiled regex against a string
  -f, --test-file <test-file>               Test the compiled regex against the contents of a file
  -h, --help                                Print help
  -V, --version                             Print version
`)
}

func main() {
	args := os.Args[1:]
	var inputPath, outPath, testStr, testFile, completion string
	repl := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printHelp()
			return
		case "-V", "--version":
			fmt.Println(version)
			return
		case "-n", "--no-color":
		case "-r", "--repl":
			repl = true
		case "-o", "--output":
			i++
			if i < len(args) {
				outPath = args[i]
			}
		case "-t", "--test":
			i++
			if i < len(args) {
				testStr = args[i]
			}
		case "-f", "--test-file":
			i++
			if i < len(args) {
				testFile = args[i]
			}
		case "--generate-completions":
			i++
			if i < len(args) {
				completion = args[i]
			}
		default:
			if strings.HasPrefix(a, "--output=") {
				outPath = strings.TrimPrefix(a, "--output=")
			} else if strings.HasPrefix(a, "--test=") {
				testStr = strings.TrimPrefix(a, "--test=")
			} else if strings.HasPrefix(a, "--test-file=") {
				testFile = strings.TrimPrefix(a, "--test-file=")
			} else if inputPath == "" {
				inputPath = a
			}
		}
	}
	if completion != "" {
		printCompletion(completion)
		return
	}
	if repl {
		runRepl()
		return
	}
	var data []byte
	var err error
	if inputPath == "" {
		st, _ := os.Stdin.Stat()
		if st != nil && (st.Mode()&os.ModeCharDevice) == 0 {
			data, err = io.ReadAll(os.Stdin)
		} else {
			fmt.Println()
			return
		}
	} else if inputPath == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(inputPath)
		if err != nil {
			fmt.Printf("Error: unable read file at path %s\n", inputPath)
			return
		}
	}
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	regex, err := compileMelody(string(data))
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	if outPath != "" {
		_ = os.WriteFile(outPath, []byte(regex), 0644)
		return
	}
	if testFile != "" {
		b, e := os.ReadFile(testFile)
		if e != nil {
			fmt.Printf("Error: unable read file at path %s\n", testFile)
			return
		}
		reportMatch(regex, testFile, string(b))
		return
	}
	if testStr != "" {
		reportMatch(regex, testStr, testStr)
		return
	}
	fmt.Println(regex)
}

func reportMatch(pattern, label, text string) {
	re, err := regexp.Compile(pattern)
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	if re.MatchString(text) {
		fmt.Printf("'%s' matched\n", label)
	} else {
		fmt.Printf("'%s' did not match\n", label)
	}
}
func runRepl() {
	sc := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("> ")
		if !sc.Scan() {
			break
		}
		out, err := compileMelody(sc.Text())
		if err != nil {
			fmt.Println("Error:", err)
		} else {
			fmt.Println(out)
		}
	}
}
func printCompletion(shell string) {
	if shell == "fish" {
		fmt.Print("complete -c melody -s o -l output -d 'Write to a file' -r\ncomplete -c melody -l generate-completions -d 'Outputs completions for the selected shell To use, write the output to the appropriate location for your shell' -r\ncomplete -c melody -s t -l test -d 'Test the compiled regex against a string' -r\ncomplete -c melody -s f -l test-file -d 'Test the compiled regex against the contents of a file' -r\ncomplete -c melody -s n -l no-color -d 'Print output with no color'\ncomplete -c melody -s r -l repl -d 'Start the Melody REPL'\ncomplete -c melody -s h -l help -d 'Print help'\ncomplete -c melody -s V -l version -d 'Print version'\n")
		return
	}
	fmt.Print("_melody() {\n    COMPREPLY=()\n}\n")
}
