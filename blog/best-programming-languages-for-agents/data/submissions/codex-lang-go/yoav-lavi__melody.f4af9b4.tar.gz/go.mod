module melody_reimpl

go 1.21
