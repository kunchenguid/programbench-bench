module entrclone

go 1.21
