package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const version = "5.7"

type options struct {
	all         bool
	clearCount  int
	dirCount    int
	nonTTY      bool
	postpone    bool
	reload      bool
	shell       bool
	statusCount int
	exitAfter   bool
}

type watch struct {
	input string
	path  string
	dir   bool
}

type fileState struct {
	exists  bool
	mode    os.FileMode
	size    int64
	mtime   int64
	entries string
}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	opts, cmdArgs, ok := parseArgs(args, stderr)
	if !ok {
		return 1
	}
	if len(cmdArgs) == 0 {
		usage(stderr)
		return 1
	}
	if opts.shell && len(cmdArgs) != 1 {
		fmt.Fprintln(stderr, "executable: -s requires commands to be formatted as a single argument")
		return 1
	}

	watches, hadErr := readWatches(stdin, stderr)
	if len(watches) == 0 {
		fmt.Fprintln(stderr, "executable: No regular files to watch")
		return 1
	}
	if hadErr && len(watches) == 0 {
		return 1
	}
	if !opts.nonTTY && !isTerminal(0) {
		fmt.Fprintln(stderr, "executable: unable to get terminal attributes, use '-n' to run non-interactively")
		return 1
	}

	states := map[string]fileState{}
	for _, w := range watches {
		states[w.path] = snapshot(w, opts)
		if opts.dirCount > 0 {
			parent := filepath.Dir(w.path)
			if _, ok := states[parent]; !ok {
				states[parent] = snapshot(watch{path: parent, dir: true}, opts)
			}
		}
	}

	signals := make(chan os.Signal, 2)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM)
	defer signal.Stop(signals)

	trigger := watches[0].input
	var child *exec.Cmd
	var childDone chan int

	start := func() int {
		if opts.clearCount > 0 {
			if opts.clearCount > 1 {
				fmt.Fprint(stdout, "\033[3J")
			}
			fmt.Fprint(stdout, "\033[H\033[2J")
		}
		c, err := buildCommand(opts, cmdArgs, trigger)
		if err != nil {
			fmt.Fprintln(stderr, "executable:", err)
			return 1
		}
		c.Stdout = stdout
		c.Stderr = stderr
		c.Stdin = os.Stdin
		c.Env = append(os.Environ(), "PAGER=/bin/cat")
		if opts.reload {
			c.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
		}
		if err := c.Start(); err != nil {
			fmt.Fprintf(stderr, "executable: unable to execute '%s': %v\n", commandName(opts, cmdArgs), err)
			return 1
		}
		if opts.reload && !opts.exitAfter {
			child = c
			childDone = make(chan int, 1)
			go func() { childDone <- waitStatus(c.Wait()) }()
			return 0
		}
		return waitStatus(c.Wait())
	}

	if !opts.postpone {
		status := start()
		if opts.exitAfter || status != 0 && !opts.reload {
			if opts.exitAfter {
				return status
			}
		}
	}

	tick := time.NewTicker(100 * time.Millisecond)
	defer tick.Stop()
	for {
		select {
		case <-signals:
			if child != nil && child.Process != nil {
				terminate(child)
				<-childDone
			}
			return 0
		case status := <-childDoneOrNil(childDone):
			child = nil
			childDone = nil
			if opts.exitAfter {
				return status
			}
		case <-tick.C:
			changed, dirChanged, name := detectChanges(watches, opts, states)
			if !changed {
				continue
			}
			trigger = name
			if dirChanged {
				return 2
			}
			if opts.reload && child != nil {
				terminate(child)
				<-childDone
				child = nil
				childDone = nil
			}
			status := start()
			if opts.exitAfter {
				return status
			}
		}
	}
}

func parseArgs(args []string, stderr io.Writer) (options, []string, bool) {
	var opts options
	for len(args) > 0 {
		a := args[0]
		if a == "--" {
			return opts, args[1:], true
		}
		if a == "" || a[0] != '-' || a == "-" {
			return opts, args, true
		}
		if a == "-h" {
			help(os.Stdout)
			usage(os.Stdout)
			return opts, nil, false
		}
		for _, r := range a[1:] {
			switch r {
			case 'a':
				opts.all = true
			case 'c':
				opts.clearCount++
			case 'd':
				opts.dirCount++
			case 'n':
				opts.nonTTY = true
			case 'p':
				opts.postpone = true
			case 'r':
				opts.reload = true
			case 's':
				opts.shell = true
			case 'x':
				opts.statusCount++
			case 'z':
				opts.exitAfter = true
			default:
				fmt.Fprintf(stderr, "./executable: invalid option -- '%c'\n", r)
				usage(stderr)
				return opts, nil, false
			}
		}
		args = args[1:]
	}
	return opts, args, true
}

func help(w io.Writer) {
	fmt.Fprintln(w, "summary:")
	fmt.Fprintln(w, "    -a  Do not consolidate events")
	fmt.Fprintln(w, "    -c  Clear screen before execution")
	fmt.Fprintln(w, "    -d  Track files added or removed from directories")
	fmt.Fprintln(w, "    -n  Non-interactive mode")
	fmt.Fprintln(w, "    -p  Wait for first event")
	fmt.Fprintln(w, "    -r  Run as a background process, use signal to restart")
	fmt.Fprintln(w, "    -s  Evaluate using a shell")
	fmt.Fprintln(w, "    -x  Format exit status")
	fmt.Fprintln(w, "    -z  Exit after the utility completes")
	fmt.Fprintln(w, "docs:")
	fmt.Fprintln(w, "    man entr")
}

func usage(w io.Writer) {
	fmt.Fprintf(w, "release: %s\n", version)
	fmt.Fprintln(w, "usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames")
	fmt.Fprintln(w, "hint: use -h to display option summary")
}

func readWatches(r io.Reader, stderr io.Writer) ([]watch, bool) {
	var watches []watch
	hadErr := false
	sc := bufio.NewScanner(r)
	seen := map[string]bool{}
	for sc.Scan() {
		name := strings.TrimRight(sc.Text(), "\r")
		if name == "" {
			continue
		}
		info, err := os.Stat(name)
		if err != nil {
			fmt.Fprintf(stderr, "executable: unable to stat '%s'\n", name)
			hadErr = true
			continue
		}
		if !info.Mode().IsRegular() && !info.IsDir() {
			continue
		}
		key, _ := filepath.Abs(name)
		if seen[key] {
			continue
		}
		seen[key] = true
		watches = append(watches, watch{input: name, path: name, dir: info.IsDir()})
	}
	if err := sc.Err(); err != nil {
		hadErr = true
	}
	return watches, hadErr
}

func snapshot(w watch, opts options) fileState {
	info, err := os.Stat(w.path)
	if err != nil {
		return fileState{}
	}
	s := fileState{exists: true, mode: info.Mode(), size: info.Size(), mtime: info.ModTime().UnixNano()}
	if info.IsDir() {
		s.entries = dirEntries(w.path, opts.dirCount > 1)
	}
	return s
}

func dirEntries(path string, includeHidden bool) string {
	ents, err := os.ReadDir(path)
	if err != nil {
		return ""
	}
	names := make([]string, 0, len(ents))
	for _, e := range ents {
		if !includeHidden && strings.HasPrefix(e.Name(), ".") {
			continue
		}
		names = append(names, e.Name())
	}
	sort.Strings(names)
	return strings.Join(names, "\n")
}

func detectChanges(watches []watch, opts options, states map[string]fileState) (bool, bool, string) {
	keys := make([]string, 0, len(states))
	for k := range states {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		old := states[k]
		now := snapshot(watch{path: k}, opts)
		states[k] = now
		if old.entries != now.entries {
			return true, true, displayName(k, watches)
		}
		if old.exists != now.exists || old.mode != now.mode || old.size != now.size || old.mtime != now.mtime {
			if old.entries != "" || now.entries != "" {
				return true, true, displayName(k, watches)
			}
			return true, false, displayName(k, watches)
		}
	}
	return false, false, ""
}

func displayName(path string, watches []watch) string {
	for _, w := range watches {
		if w.path == path {
			return w.input
		}
	}
	for _, w := range watches {
		if filepath.Dir(w.path) == path {
			return w.input
		}
	}
	return path
}

func buildCommand(opts options, args []string, trigger string) (*exec.Cmd, error) {
	if opts.shell {
		sh := os.Getenv("SHELL")
		if sh == "" {
			sh = "/bin/sh"
		}
		return exec.Command(sh, "-c", args[0], trigger), nil
	}
	out := make([]string, len(args))
	copy(out, args)
	for i, a := range out {
		if a == "/_" {
			out[i] = trigger
			break
		}
	}
	if len(out) == 0 {
		return nil, errors.New("missing utility")
	}
	return exec.Command(out[0], out[1:]...), nil
}

func commandName(opts options, args []string) string {
	if opts.shell {
		if sh := os.Getenv("SHELL"); sh != "" {
			return sh
		}
		return "/bin/sh"
	}
	if len(args) == 0 {
		return ""
	}
	return args[0]
}

func waitStatus(err error) int {
	if err == nil {
		return 0
	}
	var exitErr *exec.ExitError
	if errors.As(err, &exitErr) {
		if st, ok := exitErr.Sys().(syscall.WaitStatus); ok {
			if st.Signaled() {
				return 128 + int(st.Signal())
			}
			return st.ExitStatus()
		}
	}
	return 1
}

func terminate(c *exec.Cmd) {
	if c == nil || c.Process == nil {
		return
	}
	sig := restartSignal()
	if c.SysProcAttr != nil && c.SysProcAttr.Setpgid {
		_ = syscall.Kill(-c.Process.Pid, sig)
	} else {
		_ = c.Process.Signal(sig)
	}
}

func restartSignal() syscall.Signal {
	switch strings.ToUpper(strings.TrimPrefix(os.Getenv("ENTR_RESTART_SIGNAL"), "SIG")) {
	case "HUP":
		return syscall.SIGHUP
	case "INT":
		return syscall.SIGINT
	case "QUIT":
		return syscall.SIGQUIT
	case "USR1":
		return syscall.SIGUSR1
	case "USR2":
		return syscall.SIGUSR2
	default:
		return syscall.SIGTERM
	}
}

func childDoneOrNil(ch chan int) <-chan int {
	if ch == nil {
		return nil
	}
	return ch
}

func isTerminal(fd uintptr) bool {
	var termios syscall.Termios
	_, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, fd, uintptr(syscall.TCGETS), uintptr(syscallTermiosPointer(&termios)), 0, 0, 0)
	return errno == 0
}

func syscallTermiosPointer(p *syscall.Termios) unsafe.Pointer {
	return unsafe.Pointer(p)
}
