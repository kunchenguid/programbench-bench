package main

import (
	"bufio"
	"bytes"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/chacha20poly1305"
	"golang.org/x/crypto/curve25519"
	"golang.org/x/crypto/hkdf"
	"golang.org/x/crypto/scrypt"
)

const (
	versionLine    = "age-encryption.org/v1"
	x25519Info     = "age-encryption.org/v1/X25519"
	headerInfo     = "header"
	payloadInfo    = "payload"
	scryptLabel    = "age-encryption.org/v1/scrypt"
	chunkSize      = 64 * 1024
	armorBegin     = "-----BEGIN AGE ENCRYPTED FILE-----"
	armorEnd       = "-----END AGE ENCRYPTED FILE-----"
	versionString  = "v0.0.0-20260414014000-96fce988442d"
	identityPrefix = "AGE-SECRET-KEY-1"
)

var b64 = base64.RawStdEncoding

type recipient struct {
	pub [32]byte
}

type identity struct {
	sec [32]byte
	pub [32]byte
}

type stanza struct {
	typ  string
	args []string
	body []byte
}

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(v string) error {
	*m = append(*m, v)
	return nil
}

func main() {
	if strings.Contains(filepath.Base(os.Args[0]), "age-keygen") {
		keygenMain(os.Args[1:])
		return
	}
	if strings.Contains(filepath.Base(os.Args[0]), "age-inspect") {
		inspectMain(os.Args[1:])
		return
	}
	if err := ageMain(os.Args[1:]); err != nil {
		fmt.Fprintf(os.Stderr, "age: error: %v\n", err)
		os.Exit(1)
	}
}

func inspectMain(args []string) {
	fs := flag.NewFlagSet("age-inspect", flag.ExitOnError)
	var jsonOut, version bool
	fs.BoolVar(&jsonOut, "json", false, "")
	fs.BoolVar(&version, "version", false, "")
	fs.Parse(args)
	if version {
		fmt.Println(versionString)
		return
	}
	var r io.Reader = os.Stdin
	name := "standard input"
	if fs.NArg() > 0 && fs.Arg(0) != "-" {
		f, err := os.Open(fs.Arg(0))
		if err != nil {
			fmt.Fprintf(os.Stderr, "age-inspect: error: %v\n", err)
			os.Exit(1)
		}
		defer f.Close()
		r = f
		name = fs.Arg(0)
	}
	data, err := io.ReadAll(r)
	if err != nil {
		fmt.Fprintf(os.Stderr, "age-inspect: error: %v\n", err)
		os.Exit(1)
	}
	armored := bytes.HasPrefix(bytes.TrimSpace(data), []byte(armorBegin))
	raw := data
	if armored {
		raw, err = armorDecode(data)
		if err != nil {
			fmt.Fprintf(os.Stderr, "age-inspect: error: %v\n", err)
			os.Exit(1)
		}
	}
	header, payload, sts, _, err := parseHeader(raw)
	if err != nil {
		fmt.Fprintf(os.Stderr, "age-inspect: error: %v\n", err)
		os.Exit(1)
	}
	types := make([]string, 0, len(sts))
	pq := "no"
	for _, st := range sts {
		types = append(types, st.typ)
		if strings.Contains(strings.ToLower(st.typ), "mlkem") || strings.Contains(strings.ToLower(st.typ), "pq") {
			pq = "yes"
		}
	}
	sizes := map[string]int{
		"header":      len(header) + len("--- ") + 43 + 1,
		"armor":       0,
		"overhead":    payloadOverhead(len(payload)),
		"min_payload": payloadPlainSize(len(payload)),
		"max_payload": payloadPlainSize(len(payload)),
		"min_padding": 0,
		"max_padding": 0,
	}
	if armored {
		sizes["armor"] = len(data) - len(raw)
	}
	if jsonOut {
		obj := map[string]any{
			"version":      versionLine,
			"postquantum":  pq,
			"armor":        armored,
			"stanza_types": types,
			"sizes":        sizes,
		}
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "    ")
		enc.Encode(obj)
		return
	}
	fmt.Printf("%s is an age file, version %q.\n\n", name, versionLine)
	fmt.Println("This file is encrypted to the following recipient types:")
	for _, t := range types {
		fmt.Printf("- %q\n", t)
	}
	fmt.Println()
	if pq == "yes" {
		fmt.Println("This file uses post-quantum encryption.")
	} else {
		fmt.Println("This file does not use post-quantum encryption.")
	}
	fmt.Println()
	fmt.Println("Size breakdown (assuming it decrypts successfully):")
	fmt.Println()
	fmt.Printf("    Header                  %8d bytes\n", sizes["header"])
	if sizes["armor"] > 0 {
		fmt.Printf("    Armor                   %8d bytes\n", sizes["armor"])
	}
	fmt.Printf("    Encryption overhead     %8d bytes\n", sizes["overhead"])
	fmt.Printf("    Payload                 %8d bytes\n", sizes["min_payload"])
	fmt.Println("                    -------------------")
	fmt.Printf("    Total                   %8d bytes\n", len(data))
	fmt.Println()
	fmt.Println("Tip: for machine-readable output, use --json.")
}

func payloadOverhead(n int) int {
	if n <= 0 {
		return 0
	}
	chunks := (n + chunkSize + 15) / (chunkSize + 16)
	if chunks < 1 {
		chunks = 1
	}
	return chunks * 16
}

func payloadPlainSize(n int) int {
	return n - payloadOverhead(n)
}

func ageMain(args []string) error {
	fs := flag.NewFlagSet("age", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	var recips, recipFiles, ids, plugins multiFlag
	var encrypt, decrypt, armor, passphrase, version bool
	var output string
	fs.BoolVar(&encrypt, "encrypt", false, "")
	fs.BoolVar(&encrypt, "e", false, "")
	fs.BoolVar(&decrypt, "decrypt", false, "")
	fs.BoolVar(&decrypt, "d", false, "")
	fs.BoolVar(&armor, "armor", false, "")
	fs.BoolVar(&armor, "a", false, "")
	fs.BoolVar(&passphrase, "passphrase", false, "")
	fs.BoolVar(&passphrase, "p", false, "")
	fs.BoolVar(&version, "version", false, "")
	fs.StringVar(&output, "output", "", "")
	fs.StringVar(&output, "o", "", "")
	fs.Var(&recips, "recipient", "")
	fs.Var(&recips, "r", "")
	fs.Var(&recipFiles, "recipients-file", "")
	fs.Var(&recipFiles, "R", "")
	fs.Var(&ids, "identity", "")
	fs.Var(&ids, "i", "")
	fs.Var(&plugins, "j", "")
	if err := fs.Parse(args); err != nil {
		printHelp()
		return nil
	}
	if version {
		fmt.Println(versionString)
		return nil
	}
	if len(args) == 0 || hasHelp(args) {
		printHelp()
		return nil
	}
	if encrypt && decrypt {
		return errors.New("can't encrypt and decrypt at the same time")
	}
	if !decrypt {
		encrypt = true
	}
	for _, p := range plugins {
		if p == "batchpass" {
			passphrase = true
		} else {
			return fmt.Errorf("plugin %q not found", p)
		}
	}
	rest := fs.Args()
	if len(rest) > 1 {
		return errors.New("too many arguments")
	}
	var in io.Reader = os.Stdin
	var inf *os.File
	if len(rest) == 1 && rest[0] != "-" {
		f, err := os.Open(rest[0])
		if err != nil {
			return err
		}
		defer f.Close()
		inf = f
		in = f
	}
	var out io.Writer = os.Stdout
	if output != "" && output != "-" {
		f, err := os.Create(output)
		if err != nil {
			return err
		}
		defer f.Close()
		out = f
	}
	_ = inf
	if encrypt {
		var rs []recipient
		for _, s := range recips {
			r, err := parseRecipient(s)
			if err != nil {
				return err
			}
			rs = append(rs, r)
		}
		for _, p := range recipFiles {
			fileRs, err := readRecipientsFile(p)
			if err != nil {
				return err
			}
			rs = append(rs, fileRs...)
		}
		for _, p := range ids {
			fileIds, err := readIdentitiesFile(p)
			if err != nil {
				return err
			}
			for _, id := range fileIds {
				rs = append(rs, recipient{pub: id.pub})
			}
		}
		if passphrase {
			if len(rs) > 0 || len(recipFiles) > 0 {
				return errors.New("-p/--passphrase can't be used with recipients")
			}
			pw, err := getPassphrase("Enter passphrase:")
			if err != nil {
				return err
			}
			data, err := io.ReadAll(in)
			if err != nil {
				return err
			}
			enc, err := encryptPassphrase(data, []byte(pw))
			if err != nil {
				return err
			}
			if armor {
				enc = armorEncode(enc)
			}
			_, err = out.Write(enc)
			return err
		}
		if len(rs) == 0 {
			return errors.New("missing recipients")
		}
		data, err := io.ReadAll(in)
		if err != nil {
			return err
		}
		enc, err := encryptRecipients(data, rs)
		if err != nil {
			return err
		}
		if armor {
			enc = armorEncode(enc)
		}
		_, err = out.Write(enc)
		return err
	}
	identities, err := readAllIdentities(ids)
	if err != nil {
		return err
	}
	data, err := io.ReadAll(in)
	if err != nil {
		return err
	}
	plain, err := decryptAge(data, identities)
	if err != nil {
		return err
	}
	_, err = out.Write(plain)
	return err
}

func hasHelp(args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			return true
		}
	}
	return false
}

func printHelp() {
	fmt.Print(`Usage:
    age [--encrypt] (-r RECIPIENT | -R PATH)... [--armor] [-o OUTPUT] [INPUT]
    age [--encrypt] --passphrase [--armor] [-o OUTPUT] [INPUT]
    age --decrypt [-i PATH]... [-o OUTPUT] [INPUT]

Options:
    -e, --encrypt               Encrypt the input to the output. Default if omitted.
    -d, --decrypt               Decrypt the input to the output.
    -o, --output OUTPUT         Write the result to the file at path OUTPUT.
    -a, --armor                 Encrypt to a PEM encoded format.
    -p, --passphrase            Encrypt with a passphrase.
    -r, --recipient RECIPIENT   Encrypt to the specified RECIPIENT. Can be repeated.
    -R, --recipients-file PATH  Encrypt to recipients listed at PATH. Can be repeated.
    -i, --identity PATH         Use the identity file at PATH. Can be repeated.

INPUT defaults to standard input, and OUTPUT defaults to standard output.
If OUTPUT exists, it will be overwritten.

RECIPIENT can be an age public key generated by age-keygen ("age1...")
or an SSH public key ("ssh-ed25519 AAAA...", "ssh-rsa AAAA...").

Recipient files contain one or more recipients, one per line. Empty lines
and lines starting with "#" are ignored as comments. "-" may be used to
read recipients from standard input.

Identity files contain one or more secret keys ("AGE-SECRET-KEY-1..."),
one per line, or an SSH key. Empty lines and lines starting with "#" are
ignored as comments. Passphrase encrypted age files can be used as
identity files. Multiple key files can be provided, and any unused ones
will be ignored. "-" may be used to read identities from standard input.

When --encrypt is specified explicitly, -i can also be used to encrypt to an
identity file symmetrically, instead or in addition to normal recipients.

Example:
    $ age-keygen -o key.txt
    Public key: age1ql3z7hjy54pw3hyww5ayyfg7zqgvc7w3j2elw8zmrj2kg5sfn9aqmcac8p
    $ tar cvz ~/data | age -r age1ql3z7hjy54pw3hyww5ayyfg7zqgvc7w3j2kg5sfn9aqmcac8p > data.tar.gz.age
    $ age --decrypt -i key.txt -o data.tar.gz data.tar.gz.age
`)
}

func encryptRecipients(plain []byte, rs []recipient) ([]byte, error) {
	fileKey := make([]byte, 16)
	if _, err := rand.Read(fileKey); err != nil {
		return nil, err
	}
	var stanzas []stanza
	for _, r := range rs {
		var eph [32]byte
		if _, err := rand.Read(eph[:]); err != nil {
			return nil, err
		}
		ephPubBytes, err := curve25519.X25519(eph[:], curve25519.Basepoint)
		if err != nil {
			return nil, err
		}
		shared, err := curve25519.X25519(eph[:], r.pub[:])
		if err != nil {
			return nil, err
		}
		salt := append(append([]byte{}, ephPubBytes...), r.pub[:]...)
		wrapKey := hkdfKey(shared, salt, []byte(x25519Info), 32)
		aead, _ := chacha20poly1305.New(wrapKey)
		body := aead.Seal(nil, make([]byte, 12), fileKey, nil)
		stanzas = append(stanzas, stanza{typ: "X25519", args: []string{b64.EncodeToString(ephPubBytes)}, body: body})
	}
	return finishEncrypt(fileKey, stanzas, plain)
}

func encryptPassphrase(plain, pw []byte) ([]byte, error) {
	fileKey := make([]byte, 16)
	salt := make([]byte, 16)
	if _, err := rand.Read(fileKey); err != nil {
		return nil, err
	}
	if _, err := rand.Read(salt); err != nil {
		return nil, err
	}
	logN := 18
	wrapKey, err := scrypt.Key(pw, append([]byte(scryptLabel), salt...), 1<<logN, 8, 1, 32)
	if err != nil {
		return nil, err
	}
	aead, _ := chacha20poly1305.New(wrapKey)
	body := aead.Seal(nil, make([]byte, 12), fileKey, nil)
	st := stanza{typ: "scrypt", args: []string{b64.EncodeToString(salt), strconv.Itoa(logN)}, body: body}
	return finishEncrypt(fileKey, []stanza{st}, plain)
}

func finishEncrypt(fileKey []byte, stanzas []stanza, plain []byte) ([]byte, error) {
	var h bytes.Buffer
	h.WriteString(versionLine + "\n")
	for _, st := range stanzas {
		h.WriteString("-> " + st.typ)
		for _, a := range st.args {
			h.WriteByte(' ')
			h.WriteString(a)
		}
		h.WriteByte('\n')
		writeBody(&h, st.body)
	}
	macKey := hkdfKey(fileKey, nil, []byte(headerInfo), 32)
	mac := hmac.New(sha256.New, macKey)
	mac.Write(h.Bytes())
	h.WriteString("--- " + b64.EncodeToString(mac.Sum(nil)) + "\n")
	out := append([]byte{}, h.Bytes()...)
	payloadKey := hkdfKey(fileKey, nil, []byte(payloadInfo), 32)
	body, err := encryptPayload(payloadKey, plain)
	if err != nil {
		return nil, err
	}
	out = append(out, body...)
	return out, nil
}

func writeBody(w *bytes.Buffer, body []byte) {
	s := b64.EncodeToString(body)
	for len(s) > 64 {
		w.WriteString(s[:64] + "\n")
		s = s[64:]
	}
	w.WriteString(s + "\n")
}

func decryptAge(data []byte, ids []identity) ([]byte, error) {
	if bytes.HasPrefix(bytes.TrimSpace(data), []byte(armorBegin)) {
		var err error
		data, err = armorDecode(data)
		if err != nil {
			return nil, err
		}
	}
	header, payload, sts, macLine, err := parseHeader(data)
	if err != nil {
		return nil, err
	}
	var fileKey []byte
	for _, st := range sts {
		if st.typ == "X25519" {
			if len(st.args) != 1 {
				continue
			}
			eph, err := b64.DecodeString(st.args[0])
			if err != nil || len(eph) != 32 {
				continue
			}
			for _, id := range ids {
				shared, err := curve25519.X25519(id.sec[:], eph)
				if err != nil {
					continue
				}
				salt := append(append([]byte{}, eph...), id.pub[:]...)
				wrapKey := hkdfKey(shared, salt, []byte(x25519Info), 32)
				aead, _ := chacha20poly1305.New(wrapKey)
				fk, err := aead.Open(nil, make([]byte, 12), st.body, nil)
				if err == nil && len(fk) == 16 {
					fileKey = fk
					break
				}
			}
		} else if st.typ == "scrypt" {
			pw, _ := getPassphrase("Enter passphrase:")
			if len(st.args) != 2 {
				continue
			}
			salt, err := b64.DecodeString(st.args[0])
			if err != nil {
				continue
			}
			logN, err := strconv.Atoi(st.args[1])
			if err != nil || logN < 1 || logN > 30 {
				continue
			}
			wrapKey, err := scrypt.Key([]byte(pw), append([]byte(scryptLabel), salt...), 1<<logN, 8, 1, 32)
			if err != nil {
				continue
			}
			aead, _ := chacha20poly1305.New(wrapKey)
			fk, err := aead.Open(nil, make([]byte, 12), st.body, nil)
			if err == nil && len(fk) == 16 {
				fileKey = fk
			}
		}
		if fileKey != nil {
			break
		}
	}
	if fileKey == nil {
		return nil, errors.New("no identity matched any of the recipients")
	}
	macKey := hkdfKey(fileKey, nil, []byte(headerInfo), 32)
	mac := hmac.New(sha256.New, macKey)
	mac.Write(header)
	want := mac.Sum(nil)
	got, err := b64.DecodeString(macLine)
	if err != nil || !hmac.Equal(want, got) {
		return nil, errors.New("failed to verify header")
	}
	payloadKey := hkdfKey(fileKey, nil, []byte(payloadInfo), 32)
	return decryptPayload(payloadKey, payload)
}

func parseHeader(data []byte) (header, payload []byte, sts []stanza, macLine string, err error) {
	idx := bytes.IndexByte(data, '\n')
	if idx < 0 || string(data[:idx]) != versionLine {
		err = errors.New("not an age file")
		return
	}
	pos := 0
	var headerBuf bytes.Buffer
	lines := bytes.SplitAfter(data, []byte("\n"))
	if len(lines) == 0 {
		err = errors.New("invalid header")
		return
	}
	headerBuf.Write(lines[0])
	pos += len(lines[0])
	for pos < len(data) {
		lineEnd := bytes.IndexByte(data[pos:], '\n')
		if lineEnd < 0 {
			err = errors.New("invalid header")
			return
		}
		lineBytes := data[pos : pos+lineEnd+1]
		line := strings.TrimSuffix(string(lineBytes), "\n")
		pos += len(lineBytes)
		if strings.HasPrefix(line, "--- ") {
			macLine = strings.TrimPrefix(line, "--- ")
			header = headerBuf.Bytes()
			payload = data[pos:]
			return
		}
		if !strings.HasPrefix(line, "-> ") {
			err = errors.New("invalid stanza")
			return
		}
		headerBuf.Write(lineBytes)
		fields := strings.Fields(strings.TrimPrefix(line, "-> "))
		if len(fields) == 0 {
			err = errors.New("invalid stanza")
			return
		}
		st := stanza{typ: fields[0], args: fields[1:]}
		var encBody strings.Builder
		for pos < len(data) {
			lineEnd = bytes.IndexByte(data[pos:], '\n')
			if lineEnd < 0 {
				err = errors.New("invalid stanza body")
				return
			}
			lineBytes = data[pos : pos+lineEnd+1]
			line = strings.TrimSuffix(string(lineBytes), "\n")
			if strings.HasPrefix(line, "-> ") || strings.HasPrefix(line, "--- ") {
				break
			}
			headerBuf.Write(lineBytes)
			encBody.WriteString(line)
			pos += len(lineBytes)
		}
		body, decErr := b64.DecodeString(encBody.String())
		if decErr != nil {
			err = decErr
			return
		}
		st.body = body
		sts = append(sts, st)
	}
	err = errors.New("missing header MAC")
	return
}

func encryptPayload(key, plain []byte) ([]byte, error) {
	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return nil, err
	}
	var out []byte
	for seq := uint64(0); ; seq++ {
		n := nonce(seq, len(plain) <= chunkSize)
		take := len(plain)
		if take > chunkSize {
			take = chunkSize
		}
		out = aead.Seal(out, n[:], plain[:take], nil)
		plain = plain[take:]
		if len(plain) == 0 {
			break
		}
	}
	return out, nil
}

func decryptPayload(key, data []byte) ([]byte, error) {
	aead, err := chacha20poly1305.New(key)
	if err != nil {
		return nil, err
	}
	var out []byte
	for seq := uint64(0); ; seq++ {
		if len(data) == 0 {
			return nil, errors.New("truncated payload")
		}
		if len(data) > chunkSize+16 {
			part := data[:chunkSize+16]
			n := nonce(seq, false)
			p, err := aead.Open(nil, n[:], part, nil)
			if err != nil {
				return nil, err
			}
			out = append(out, p...)
			data = data[len(part):]
			continue
		}
		n := nonce(seq, true)
		p, err := aead.Open(nil, n[:], data, nil)
		if err != nil {
			return nil, err
		}
		out = append(out, p...)
		return out, nil
	}
}

func nonce(seq uint64, last bool) [12]byte {
	var n [12]byte
	binary.BigEndian.PutUint64(n[3:11], seq)
	if last {
		n[11] = 1
	}
	return n
}

func hkdfKey(secret, salt, info []byte, n int) []byte {
	r := hkdf.New(sha256.New, secret, salt, info)
	out := make([]byte, n)
	if _, err := io.ReadFull(r, out); err != nil {
		panic(err)
	}
	return out
}

func readRecipientsFile(path string) ([]recipient, error) {
	var r io.Reader
	if path == "-" {
		r = os.Stdin
	} else {
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer f.Close()
		r = f
	}
	var rs []recipient
	sc := bufio.NewScanner(r)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		rec, err := parseRecipient(line)
		if err != nil {
			return nil, err
		}
		rs = append(rs, rec)
	}
	return rs, sc.Err()
}

func readAllIdentities(paths []string) ([]identity, error) {
	var ids []identity
	for _, p := range paths {
		x, err := readIdentitiesFile(p)
		if err != nil {
			return nil, err
		}
		ids = append(ids, x...)
	}
	return ids, nil
}

func readIdentitiesFile(path string) ([]identity, error) {
	var r io.Reader
	if path == "-" {
		r = os.Stdin
	} else {
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer f.Close()
		r = f
	}
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, err
	}
	trimmed := bytes.TrimSpace(data)
	if bytes.HasPrefix(trimmed, []byte(versionLine)) || bytes.HasPrefix(trimmed, []byte(armorBegin)) {
		plain, err := decryptAge(data, nil)
		if err != nil {
			return nil, err
		}
		data = plain
	}
	var ids []identity
	sc := bufio.NewScanner(bytes.NewReader(data))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		id, err := parseIdentity(line)
		if err == nil {
			ids = append(ids, id)
		}
	}
	return ids, sc.Err()
}

func parseRecipient(s string) (recipient, error) {
	var r recipient
	s = strings.Fields(s)[0]
	hrp, data, err := bech32Decode(strings.ToLower(s))
	if err != nil {
		return r, err
	}
	if hrp != "age" {
		return r, errors.New("unknown recipient type")
	}
	b, err := convertBits(data, 5, 8, false)
	if err != nil {
		return r, err
	}
	if len(b) != 32 {
		return r, errors.New("invalid recipient")
	}
	copy(r.pub[:], b)
	return r, nil
}

func parseIdentity(s string) (identity, error) {
	var id identity
	s = strings.TrimSpace(s)
	hrp, data, err := bech32Decode(strings.ToLower(s))
	if err != nil {
		return id, err
	}
	if strings.ToUpper(hrp) != strings.TrimSuffix(identityPrefix, "1") {
		return id, errors.New("unknown identity type")
	}
	b, err := convertBits(data, 5, 8, false)
	if err != nil {
		return id, err
	}
	if len(b) != 32 {
		return id, errors.New("invalid identity")
	}
	copy(id.sec[:], b)
	pub, err := curve25519.X25519(id.sec[:], curve25519.Basepoint)
	if err != nil {
		return id, err
	}
	copy(id.pub[:], pub)
	return id, nil
}

func recipientString(pub []byte) string {
	five, _ := convertBits(pub, 8, 5, true)
	return bech32Encode("age", five)
}

func identityString(sec []byte) string {
	five, _ := convertBits(sec, 8, 5, true)
	return strings.ToUpper(bech32Encode("age-secret-key-", five))
}

func armorEncode(data []byte) []byte {
	enc := base64.StdEncoding.EncodeToString(data)
	var b bytes.Buffer
	b.WriteString(armorBegin + "\n")
	for len(enc) > 64 {
		b.WriteString(enc[:64] + "\n")
		enc = enc[64:]
	}
	if len(enc) > 0 {
		b.WriteString(enc + "\n")
	}
	b.WriteString(armorEnd + "\n")
	return b.Bytes()
}

func armorDecode(data []byte) ([]byte, error) {
	var enc strings.Builder
	sc := bufio.NewScanner(bytes.NewReader(data))
	seen := false
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == armorBegin {
			seen = true
			continue
		}
		if line == armorEnd {
			return base64.StdEncoding.DecodeString(enc.String())
		}
		if seen {
			enc.WriteString(line)
		}
	}
	return nil, errors.New("invalid armor")
}

func getPassphrase(prompt string) (string, error) {
	if v := os.Getenv("AGE_PASSPHRASE"); v != "" {
		return v, nil
	}
	if fd := os.Getenv("AGE_PASSPHRASE_FD"); fd != "" {
		n, err := strconv.Atoi(fd)
		if err != nil {
			return "", err
		}
		b, err := io.ReadAll(os.NewFile(uintptr(n), "passphrase"))
		if err != nil {
			return "", err
		}
		return strings.TrimRight(string(b), "\r\n"), nil
	}
	fmt.Fprintln(os.Stderr, prompt)
	br := bufio.NewReader(os.Stdin)
	s, err := br.ReadString('\n')
	return strings.TrimRight(s, "\r\n"), err
}

func keygenMain(args []string) {
	fs := flag.NewFlagSet("age-keygen", flag.ExitOnError)
	var output string
	var y, version bool
	fs.StringVar(&output, "o", "", "")
	fs.StringVar(&output, "output", "", "")
	fs.BoolVar(&y, "y", false, "")
	fs.BoolVar(&version, "version", false, "")
	_ = fs.Bool("pq", false, "")
	fs.Parse(args)
	if version {
		fmt.Println(versionString)
		return
	}
	if y {
		paths := fs.Args()
		var r io.Reader = os.Stdin
		if len(paths) > 0 {
			f, err := os.Open(paths[0])
			if err != nil {
				fmt.Fprintf(os.Stderr, "age-keygen: error: %v\n", err)
				os.Exit(1)
			}
			defer f.Close()
			r = f
		}
		tmp, _ := os.CreateTemp("", "ids")
		defer os.Remove(tmp.Name())
		io.Copy(tmp, r)
		tmp.Close()
		ids, err := readIdentitiesFile(tmp.Name())
		if err != nil {
			fmt.Fprintf(os.Stderr, "age-keygen: error: %v\n", err)
			os.Exit(1)
		}
		for _, id := range ids {
			fmt.Println(recipientString(id.pub[:]))
		}
		return
	}
	sec := make([]byte, 32)
	if _, err := rand.Read(sec); err != nil {
		panic(err)
	}
	pub, err := curve25519.X25519(sec, curve25519.Basepoint)
	if err != nil {
		panic(err)
	}
	text := fmt.Sprintf("# created: %s\n# public key: %s\n%s\n",
		time.Now().Format(time.RFC3339), recipientString(pub), identityString(sec))
	if output != "" {
		if err := os.WriteFile(output, []byte(text), 0600); err != nil {
			fmt.Fprintf(os.Stderr, "age-keygen: error: %v\n", err)
			os.Exit(1)
		}
		fmt.Fprintf(os.Stderr, "Public key: %s\n", recipientString(pub))
	} else {
		fmt.Print(text)
	}
}

const charset = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"

func bech32Polymod(values []byte) uint32 {
	chk := uint32(1)
	gen := [5]uint32{0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3}
	for _, v := range values {
		top := chk >> 25
		chk = (chk&0x1ffffff)<<5 ^ uint32(v)
		for i := 0; i < 5; i++ {
			if (top>>uint(i))&1 == 1 {
				chk ^= gen[i]
			}
		}
	}
	return chk
}

func bech32HrpExpand(hrp string) []byte {
	var out []byte
	for i := 0; i < len(hrp); i++ {
		out = append(out, hrp[i]>>5)
	}
	out = append(out, 0)
	for i := 0; i < len(hrp); i++ {
		out = append(out, hrp[i]&31)
	}
	return out
}

func bech32Decode(s string) (string, []byte, error) {
	if strings.ToLower(s) != s && strings.ToUpper(s) != s {
		return "", nil, errors.New("mixed-case bech32 string")
	}
	s = strings.ToLower(s)
	pos := strings.LastIndexByte(s, '1')
	if pos < 1 || pos+7 > len(s) {
		return "", nil, errors.New("invalid bech32 string")
	}
	hrp := s[:pos]
	var data []byte
	for i := pos + 1; i < len(s); i++ {
		p := strings.IndexByte(charset, s[i])
		if p < 0 {
			return "", nil, errors.New("invalid bech32 character")
		}
		data = append(data, byte(p))
	}
	check := append(bech32HrpExpand(hrp), data...)
	if bech32Polymod(check) != 1 {
		return "", nil, errors.New("invalid bech32 checksum")
	}
	return hrp, data[:len(data)-6], nil
}

func bech32Encode(hrp string, data []byte) string {
	values := append(bech32HrpExpand(hrp), data...)
	values = append(values, 0, 0, 0, 0, 0, 0)
	mod := bech32Polymod(values) ^ 1
	check := make([]byte, 6)
	for i := 0; i < 6; i++ {
		check[i] = byte((mod >> uint(5*(5-i))) & 31)
	}
	var b strings.Builder
	b.WriteString(hrp)
	b.WriteByte('1')
	for _, v := range append(data, check...) {
		b.WriteByte(charset[v])
	}
	return b.String()
}

func convertBits(data []byte, from, to uint, pad bool) ([]byte, error) {
	var acc uint
	var bits uint
	maxv := uint((1 << to) - 1)
	maxAcc := uint((1 << (from + to - 1)) - 1)
	var ret []byte
	for _, value := range data {
		v := uint(value)
		if v>>from != 0 {
			return nil, errors.New("invalid data range")
		}
		acc = ((acc << from) | v) & maxAcc
		bits += from
		for bits >= to {
			bits -= to
			ret = append(ret, byte((acc>>bits)&maxv))
		}
	}
	if pad {
		if bits > 0 {
			ret = append(ret, byte((acc<<(to-bits))&maxv))
		}
	} else if bits >= from || ((acc<<(to-bits))&maxv) != 0 {
		return nil, errors.New("invalid padding")
	}
	return ret, nil
}
