module reimpl

go 1.21

require (
 golang.org/x/crypto v0.0.0
 golang.org/x/sys v0.0.0
)

replace golang.org/x/crypto => ./xcrypto
replace golang.org/x/sys => ./xsys
