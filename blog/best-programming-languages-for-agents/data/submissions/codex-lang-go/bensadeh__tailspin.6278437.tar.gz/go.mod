module tailspinclone

go 1.21
