package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
	"unicode"
)

const reset = "\x1b[0m"

var colorCode = map[string]string{
	"red": "31", "green": "32", "yellow": "33", "blue": "34", "magenta": "35", "cyan": "36",
}

var validGroups = map[string]bool{
	"numbers": true, "urls": true, "pointers": true, "dates": true, "paths": true, "quotes": true,
	"key-value-pairs": true, "uuids": true, "ip-addresses": true, "processes": true, "json": true,
}

type options struct {
	follow         bool
	print          bool
	file           string
	execCmd        string
	configPath     string
	pager          string
	disableBuiltin bool
	enableSeen     bool
	enabled        map[string]bool
	disabled       map[string]bool
	custom         []customHighlight
}

type customHighlight struct{ style, word string }

type span struct {
	start, end int
	style      string
	pri        int
	repl       string
}

func main() {
	opts, exit, handled := parseArgs(os.Args[1:])
	if handled {
		os.Exit(exit)
	}

	var input io.Reader
	if opts.execCmd != "" {
		cmd := exec.Command("bash", "-lc", opts.execCmd)
		out, err := cmd.CombinedOutput()
		if len(out) > 0 {
			input = bytes.NewReader(out)
		} else {
			input = bytes.NewReader(nil)
		}
		if err != nil { /* tailspin still shows command output; keep exit 0 for pager-like behavior */
		}
	} else if opts.file != "" {
		if opts.follow {
			followFile(opts.file, opts)
			return
		}
		f, err := os.Open(opts.file)
		if err != nil {
			fileError(opts.file, err)
			os.Exit(1)
		}
		defer f.Close()
		input = f
	} else {
		input = os.Stdin
	}
	printHighlighted(input, os.Stdout, opts)
}

func parseArgs(args []string) (options, int, bool) {
	opts := options{enabled: map[string]bool{}, disabled: map[string]bool{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-h":
			fmt.Print(shortHelp())
			return opts, 0, true
		case a == "--help":
			fmt.Print(longHelp())
			return opts, 0, true
		case a == "-V" || a == "--version":
			fmt.Println("tspin 5.6.0")
			return opts, 0, true
		case a == "-f" || a == "--follow":
			opts.follow = true
		case a == "-p" || a == "--print":
			opts.print = true
		case a == "--disable-builtin-keywords":
			opts.disableBuiltin = true
		case a == "--config-path" || a == "--pager" || a == "-e" || a == "--exec" || a == "--highlight" || a == "--enable" || a == "--disable":
			if i+1 >= len(args) {
				missingValue(a)
				return opts, 2, true
			}
			i++
			if done, code := handleValue(a, args[i], &opts); done {
				return opts, code, true
			}
		case strings.HasPrefix(a, "--config-path="):
			opts.configPath = strings.TrimPrefix(a, "--config-path=")
		case strings.HasPrefix(a, "--pager="):
			opts.pager = strings.TrimPrefix(a, "--pager=")
		case strings.HasPrefix(a, "--exec="):
			opts.execCmd = strings.TrimPrefix(a, "--exec=")
		case strings.HasPrefix(a, "--highlight="):
			if done, code := addHighlight(strings.TrimPrefix(a, "--highlight="), &opts); done {
				return opts, code, true
			}
		case strings.HasPrefix(a, "--enable="):
			if done, code := addGroups("--enable", strings.TrimPrefix(a, "--enable="), &opts); done {
				return opts, code, true
			}
		case strings.HasPrefix(a, "--disable="):
			if done, code := addGroups("--disable", strings.TrimPrefix(a, "--disable="), &opts); done {
				return opts, code, true
			}
		case strings.HasPrefix(a, "-"):
			unexpected(a)
			return opts, 2, true
		default:
			if opts.file == "" {
				opts.file = a
			} else {
				unexpected(a)
				return opts, 2, true
			}
		}
	}
	if opts.enableSeen && len(opts.disabled) > 0 {
		fmt.Fprintln(os.Stderr, "Error:   × cannot both enable and disable highlighters")
		fmt.Fprintln(os.Stderr)
		return opts, 1, true
	}
	return opts, 0, false
}

func handleValue(flag, val string, opts *options) (bool, int) {
	switch flag {
	case "--config-path":
		opts.configPath = val
	case "--pager":
		opts.pager = val
	case "-e", "--exec":
		opts.execCmd = val
	case "--highlight":
		return addHighlight(val, opts)
	case "--enable":
		return addGroups("--enable", val, opts)
	case "--disable":
		return addGroups("--disable", val, opts)
	}
	return false, 0
}

func addHighlight(v string, opts *options) (bool, int) {
	parts := strings.SplitN(v, ":", 2)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--highlight <COLOR_WORD>': Expected format COLOR:word1,word2,... found `%s`\n\n", v, v)
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return true, 2
	}
	code, ok := colorCode[parts[0]]
	if !ok {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--highlight <COLOR_WORD>': invalid variant: %s\n\n", v, parts[0])
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return true, 2
	}
	for _, w := range strings.Split(parts[1], ",") {
		if w != "" {
			opts.custom = append(opts.custom, customHighlight{code, w})
		}
	}
	return false, 0
}

func addGroups(flag, v string, opts *options) (bool, int) {
	if flag == "--enable" {
		opts.enableSeen = true
	}
	for _, g := range strings.Split(v, ",") {
		if !validGroups[g] {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s <%sD_HIGHLIGHTERS>'\n", g, flag, strings.TrimPrefix(strings.ToUpper(flag), "--"))
			fmt.Fprintln(os.Stderr, "  [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json]")
			fmt.Fprintln(os.Stderr, "\nFor more information, try '--help'.")
			return true, 2
		}
		if flag == "--enable" {
			opts.enabled[g] = true
		} else {
			opts.disabled[g] = true
		}
	}
	return false, 0
}

func groupOn(opts options, g string) bool {
	if opts.enableSeen {
		return opts.enabled[g]
	}
	return !opts.disabled[g]
}

func printHighlighted(r io.Reader, w io.Writer, opts options) {
	s := bufio.NewScanner(r)
	buf := make([]byte, 1024*1024)
	s.Buffer(buf, 16*1024*1024)
	for s.Scan() {
		fmt.Fprintln(w, highlightLine(s.Text(), opts))
	}
}

func followFile(path string, opts options) {
	var off int64
	for {
		f, err := os.Open(path)
		if err == nil {
			st, _ := f.Stat()
			if st.Size() < off {
				off = 0
			}
			f.Seek(off, io.SeekStart)
			printHighlighted(f, os.Stdout, opts)
			off, _ = f.Seek(0, io.SeekCurrent)
			f.Close()
		} else if off == 0 {
			fileError(path, err)
			os.Exit(1)
		}
		time.Sleep(500 * time.Millisecond)
	}
}

var (
	reDate   = regexp.MustCompile(`\b\d{4}-\d{2}-\d{2}\b`)
	reTime   = regexp.MustCompile(`\b\d{2}:\d{2}:\d{2}([\.,]\d+)?\b`)
	reURL    = regexp.MustCompile(`https?://[^\s"'<>]+`)
	reUUID   = regexp.MustCompile(`\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b`)
	reIP     = regexp.MustCompile(`\b\d{1,3}(?:\.\d{1,3}){3}\b`)
	rePtr    = regexp.MustCompile(`\b0x[0-9a-fA-F]+\b`)
	rePath   = regexp.MustCompile(`(?:^|[\s=])(/[^\s:"'?]+|[A-Za-z]:\\[^\s:"'?]+)`)
	reKV     = regexp.MustCompile(`\b([A-Za-z_][A-Za-z0-9_.-]*)=`)
	reNumber = regexp.MustCompile(`\b\d+(?:\.\d+)?\b`)
	reDQuote = regexp.MustCompile(`"[^"]*"`)
)

func highlightLine(line string, opts options) string {
	spans := []span{}
	add := func(s, e int, style string, pri int) {
		if s < e && s >= 0 && e <= len(line) {
			spans = append(spans, span{s, e, style, pri, ""})
		}
	}

	if !opts.disableBuiltin {
		builtinWords(line, add, &spans)
	}
	for _, c := range opts.custom {
		addWord(line, c.word, c.style, 95, add)
	}
	if groupOn(opts, "json") {
		jsonSpans(line, add)
	}
	if groupOn(opts, "dates") {
		dateSpans(line, add)
	}
	if groupOn(opts, "urls") {
		urlSpans(line, add)
	}
	if groupOn(opts, "uuids") {
		regexWhole(reUUID, line, "3;34", 55, add)
	}
	if groupOn(opts, "ip-addresses") {
		ipSpans(line, add)
	}
	if groupOn(opts, "pointers") {
		regexWhole(rePtr, line, "35", 50, add)
	}
	if groupOn(opts, "paths") {
		pathSpans(line, add)
	}
	if groupOn(opts, "quotes") {
		quoteSpans(line, add)
	}
	if groupOn(opts, "processes") {
		addWord(line, "process", "33", 45, add)
	}
	if groupOn(opts, "key-value-pairs") {
		kvSpans(line, add)
	}
	if groupOn(opts, "numbers") {
		regexWhole(reNumber, line, "36", 10, add)
	}

	return render(line, spans)
}

func builtinWords(line string, add func(int, int, string, int), spans *[]span) {
	for w, st := range map[string]string{"ERROR": "31", "WARN": "33", "INFO": "37", "DEBUG": "32", "TRACE": "2"} {
		addWord(line, w, st, 100, add)
	}
	for w, st := range map[string]string{"GET": "42;30", "POST": "43;30", "PUT": "45;30", "PATCH": "45;30", "DELETE": "41;30"} {
		addREST(line, w, st, 100, spans)
	}
	for _, w := range []string{"true", "false", "null"} {
		addWord(line, w, "3;31", 100, add)
	}
}

func addWord(line, word, style string, pri int, add func(int, int, string, int)) {
	idx := 0
	for {
		i := strings.Index(line[idx:], word)
		if i < 0 {
			return
		}
		s := idx + i
		e := s + len(word)
		if boundary(line, s-1) && boundary(line, e) {
			add(s, e, style, pri)
		}
		idx = e
	}
}
func addREST(line, word, style string, pri int, spans *[]span) {
	idx := 0
	for {
		i := strings.Index(line[idx:], word)
		if i < 0 {
			return
		}
		s := idx + i
		e := s + len(word)
		if boundary(line, s-1) && boundary(line, e) {
			*spans = append(*spans, span{s, e, style, pri, " " + word + " "})
		}
		idx = e
	}
}
func boundary(line string, pos int) bool {
	if pos < 0 || pos >= len(line) {
		return true
	}
	r := rune(line[pos])
	return !(unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '-')
}

func regexWhole(re *regexp.Regexp, line, style string, pri int, add func(int, int, string, int)) {
	for _, m := range re.FindAllStringIndex(line, -1) {
		add(m[0], m[1], style, pri)
	}
}

func dateSpans(line string, add func(int, int, string, int)) {
	for _, m := range reDate.FindAllStringIndex(line, -1) {
		s := m[0]
		add(s, s+4, "35", 60)
		add(s+4, s+5, "2", 60)
		add(s+5, s+7, "35", 60)
		add(s+7, s+8, "2", 60)
		add(s+8, s+10, "35", 60)
		if m[1] < len(line) && (line[m[1]] == ' ' || line[m[1]] == 'T') {
			add(m[1], m[1]+1, "31", 60)
		}
	}
	for _, m := range reTime.FindAllStringIndex(line, -1) {
		s := m[0]
		e := m[1]
		if e-s >= 8 {
			add(s, s+2, "34", 60)
			add(s+2, s+3, "2", 60)
			add(s+3, s+5, "34", 60)
			add(s+5, s+6, "2", 60)
			add(s+6, s+8, "34", 60)
			if e > s+8 {
				add(s+8, s+9, "2", 60)
				add(s+9, e, "34", 60)
			}
		}
		if e < len(line) && (line[e] == 'Z') {
			add(e, e+1, "31", 60)
		}
	}
}
func urlSpans(line string, add func(int, int, string, int)) {
	for _, m := range reURL.FindAllStringIndex(line, -1) {
		s, e := m[0], m[1]
		u := line[s:e]
		if strings.HasPrefix(u, "http") {
			add(s, s+4, "2;31", 58)
		}
		p := strings.Index(u, "://")
		hostStart := s
		if p >= 0 {
			hostStart = s + p + 3
		}
		slash := strings.Index(u[p+3:], "/")
		hostEnd := e
		if p >= 0 && slash >= 0 {
			hostEnd = hostStart + slash
		}
		add(hostStart, hostEnd, "2;34", 58)
		for i := hostEnd; i < e; i++ {
			ch := line[i]
			switch ch {
			case '/', ':':
				add(i, i+1, "34", 58)
			case '?', '&', '=':
				add(i, i+1, "31", 58)
			default:
				if unicode.IsDigit(rune(ch)) {
					add(i, i+1, "36", 58)
				} else if unicode.IsLetter(rune(ch)) {
					add(i, i+1, "35", 58)
				}
			}
		}
	}
}
func ipSpans(line string, add func(int, int, string, int)) {
	for _, m := range reIP.FindAllStringIndex(line, -1) {
		parts := strings.Split(line[m[0]:m[1]], ".")
		pos := m[0]
		for i, p := range parts {
			add(pos, pos+len(p), "3;34", 57)
			pos += len(p)
			if i < 3 {
				add(pos, pos+1, "31", 57)
				pos++
			}
		}
	}
}
func pathSpans(line string, add func(int, int, string, int)) {
	for _, m := range rePath.FindAllStringSubmatchIndex(line, -1) {
		s, e := m[2], m[3]
		segStart := s
		for i := s; i < e; i++ {
			if line[i] == '/' {
				if segStart < i {
					add(segStart, i, "32", 52)
				}
				add(i, i+1, "33", 52)
				segStart = i + 1
			}
		}
		if segStart < e {
			add(segStart, e, "32", 52)
		}
	}
}
func quoteSpans(line string, add func(int, int, string, int)) {
	for _, m := range reDQuote.FindAllStringIndex(line, -1) {
		add(m[0], m[0]+1, "33", 40)
		add(m[1]-1, m[1], "33", 40)
	}
}
func kvSpans(line string, add func(int, int, string, int)) {
	for _, m := range reKV.FindAllStringSubmatchIndex(line, -1) {
		add(m[2], m[3], "2", 54)
		add(m[3], m[3]+1, "37", 54)
	}
}
func jsonSpans(line string, add func(int, int, string, int)) {
	trimmed := strings.TrimSpace(line)
	if !(strings.HasPrefix(trimmed, "{") || strings.HasPrefix(trimmed, "[")) {
		return
	}
	for i, ch := range line {
		if strings.ContainsRune("{}[],:\"", ch) {
			add(i, i+1, "2", 75)
		}
	}
}

func render(line string, spans []span) string {
	chosen := make([]*span, len(line))
	sort.SliceStable(spans, func(i, j int) bool {
		if spans[i].pri == spans[j].pri {
			return spans[i].start < spans[j].start
		}
		return spans[i].pri > spans[j].pri
	})
	for i := range spans {
		sp := &spans[i]
		for p := sp.start; p < sp.end; p++ {
			if p >= 0 && p < len(line) && chosen[p] == nil {
				chosen[p] = sp
			}
		}
	}
	var b strings.Builder
	cur := ""
	for i := 0; i < len(line); i++ {
		if chosen[i] != nil && chosen[i].start == i && chosen[i].repl != "" {
			if cur != "" {
				b.WriteString(reset)
				cur = ""
			}
			b.WriteString("\x1b[")
			b.WriteString(chosen[i].style)
			b.WriteByte('m')
			b.WriteString(chosen[i].repl)
			b.WriteString(reset)
			i = chosen[i].end - 1
			continue
		}
		st := ""
		if chosen[i] != nil {
			st = chosen[i].style
		}
		if st != cur {
			if cur != "" {
				b.WriteString(reset)
			}
			if st != "" {
				b.WriteString("\x1b[")
				b.WriteString(st)
				b.WriteByte('m')
			}
			cur = st
		}
		b.WriteByte(line[i])
	}
	if cur != "" {
		b.WriteString(reset)
	}
	return b.String()
}

func fileError(path string, err error) {
	msg := "No such file or directory"
	if !errors.Is(err, os.ErrNotExist) {
		msg = err.Error()
	}
	fmt.Fprintf(os.Stderr, "Error:   ⚠ \x1b[33m%s\x1b[0m: %s\n\n", path, msg)
}
func unexpected(a string) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n", a, a, a)
}
func missingValue(a string) {
	fmt.Fprintf(os.Stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", a)
}

func shortHelp() string {
	return "A log file highlighter\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]  Filepath\n\nOptions:\n  -f, --follow\n          Follow the contents of a file\n  -p, --print\n          Print the output to stdout\n      --config-path <CONFIG_PATH>\n          Provide a custom path to a configuration file\n  -e, --exec <EXEC>\n          Run command and view the output in a pager\n      --highlight <COLOR_WORD>\n          Highlights in the form color:word1,word2\n      --enable <ENABLED_HIGHLIGHTERS>\n          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,\n          quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n      --disable <DISABLED_HIGHLIGHTERS>\n          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,\n          quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n      --disable-builtin-keywords\n          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities\n          and common REST verbs)\n      --pager <PAGER>\n          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`) [env:\n          TAILSPIN_PAGER=]\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n"
}
func longHelp() string {
	return "A log file highlighter\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]\n          Filepath\n\nOptions:\n  -f, --follow\n          Follow the contents of a file\n\n  -p, --print\n          Print the output to stdout\n\n      --config-path <CONFIG_PATH>\n          Provide a custom path to a configuration file\n\n  -e, --exec <EXEC>\n          Run command and view the output in a pager\n\n      --highlight <COLOR_WORD>\n          Highlights in the form color:word1,word2\n          \n          [possible values: red, green, yellow, blue, magenta, cyan]\n\n      --enable <ENABLED_HIGHLIGHTERS>\n          Enable specific highlighters\n          \n          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,\n          ip-addresses, processes, json]\n\n      --disable <DISABLED_HIGHLIGHTERS>\n          Disable specific highlighters\n          \n          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,\n          ip-addresses, processes, json]\n\n      --disable-builtin-keywords\n          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities\n          and common REST verbs)\n\n      --pager <PAGER>\n          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`)\n          \n          [env: TAILSPIN_PAGER=]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n"
}

func init() { _ = filepath.Base }
