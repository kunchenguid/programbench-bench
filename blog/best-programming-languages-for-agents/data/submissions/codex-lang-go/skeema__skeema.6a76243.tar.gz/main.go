package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const versionLine = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"

type optSpec struct {
	name     string
	short    string
	hasValue bool
	optional bool
}

var specs = []optSpec{
	{"connect-options", "o", true, false}, {"debug", "", false, false}, {"help", "?", true, true},
	{"host-wrapper", "H", true, false}, {"ignore-func", "", true, false}, {"ignore-proc", "", true, false},
	{"ignore-schema", "", true, false}, {"ignore-table", "", true, false}, {"my-cnf", "", false, false},
	{"skip-my-cnf", "", false, false}, {"password", "p", true, true}, {"ssl-mode", "", true, false},
	{"user", "u", true, false}, {"version", "", false, false}, {"dir", "d", true, false},
	{"host", "h", true, false}, {"port", "P", true, false}, {"socket", "S", true, false},
	{"schema", "", true, false}, {"include-auto-inc", "", false, false}, {"strip-partitioning", "", false, false},
	{"write", "", false, false}, {"skip-write", "", false, false}, {"format", "", false, false},
	{"skip-format", "", false, false}, {"new-schemas", "", false, false}, {"skip-new-schemas", "", false, false},
	{"update-partitioning", "", false, false}, {"alter-wrapper", "x", true, false},
	{"alter-wrapper-min-size", "", true, false}, {"ddl-wrapper", "X", true, false},
	{"alter-algorithm", "", true, false}, {"alter-lock", "", true, false}, {"alter-validate-virtual", "", false, false},
	{"compare-metadata", "", false, false}, {"exact-match", "", false, false}, {"lax-column-order", "", false, false},
	{"lax-comments", "", false, false}, {"partitioning", "", true, false}, {"allow-auto-inc", "", true, false},
	{"allow-charset", "", true, false}, {"allow-compression", "", true, false}, {"allow-definer", "", true, false},
	{"allow-engine", "", true, false}, {"allow-pk-type", "", true, false}, {"lint", "", false, false},
	{"skip-lint", "", false, false}, {"lint-auto-inc", "", true, false}, {"lint-charset", "", true, false},
	{"lint-compression", "", true, false}, {"lint-definer", "", true, false}, {"lint-display-width", "", true, false},
	{"lint-dupe-index", "", true, false}, {"lint-engine", "", true, false}, {"lint-fk-parent", "", true, false},
	{"lint-has-enum", "", true, false}, {"lint-has-fk", "", true, false}, {"lint-has-float", "", true, false},
	{"lint-has-routine", "", true, false}, {"lint-has-time", "", true, false}, {"lint-name-case", "", true, false},
	{"lint-pk", "", true, false}, {"lint-pk-type", "", true, false}, {"lint-reserved-word", "", true, false},
	{"lint-zero-date", "", true, false}, {"allow-unsafe", "", false, false}, {"safe-below-size", "", true, false},
	{"verify", "", false, false}, {"skip-verify", "", false, false}, {"brief", "q", false, false},
	{"concurrent-servers", "c", true, false}, {"first-only", "1", false, false},
	{"docker-cleanup", "", true, false}, {"temp-schema", "t", true, false}, {"temp-schema-binlog", "", true, false},
	{"temp-schema-mode", "", true, false}, {"temp-schema-threads", "", true, false}, {"workspace", "w", true, false},
	{"dry-run", "", false, false}, {"foreign-key-checks", "", false, false}, {"flavor", "", true, false},
}

var byLong = map[string]optSpec{}
var byShort = map[string]optSpec{}

func init() {
	for _, s := range specs {
		byLong[s.name] = s
		if s.short != "" {
			byShort[s.short] = s
		}
	}
}

type parsed struct {
	cmd  string
	args []string
	opts map[string]string
	help string
}

func main() {
	p, err := parse(os.Args[1:])
	if err != "" {
		logErr(`CLI: ` + err)
		os.Exit(78)
	}
	if _, ok := p.opts["version"]; ok {
		fmt.Println(versionLine)
		return
	}
	if p.cmd == "help" && len(p.args) > 0 && p.args[0] == "version" {
		fmt.Println(versionLine)
		return
	}
	if p.help != "" {
		if p.help == "__main__" {
			printHelp("")
			return
		}
		printHelp(p.help)
		return
	}
	if p.cmd == "" || p.cmd == "help" {
		if len(p.args) > 0 {
			if !isCommand(p.args[0]) {
				logErr(fmt.Sprintf(`Unknown command "%s"`, p.args[0]))
				os.Exit(2)
			}
			if p.args[0] == "version" {
				fmt.Println(versionLine)
				return
			}
			printHelp(p.args[0])
			return
		}
		printHelp("")
		return
	}
	if !isCommand(p.cmd) {
		logErr(fmt.Sprintf(`Unknown command "%s"`, p.cmd))
		os.Exit(78)
	}
	switch p.cmd {
	case "version":
		fmt.Println(versionLine)
	case "add-environment":
		os.Exit(runAddEnvironment(p))
	case "init":
		os.Exit(runInit(p))
	case "lint", "format":
		os.Exit(runLocalCheck(p))
	case "diff", "push", "pull":
		os.Exit(runDBCommand(p))
	default:
		printHelp(p.cmd)
	}
}

func parse(args []string) (parsed, string) {
	p := parsed{opts: map[string]string{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			p.args = append(p.args, args[i+1:]...)
			break
		}
		if strings.HasPrefix(a, "--") && len(a) > 2 {
			nameVal := strings.TrimPrefix(a, "--")
			name, val, hasEq := strings.Cut(nameVal, "=")
			spec, ok := byLong[name]
			if !ok {
				return p, fmt.Sprintf(`Unknown option "%s"`, name)
			}
			if spec.hasValue {
				if !hasEq && !spec.optional && i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
					i++
					val = args[i]
				}
				if !hasEq && !spec.optional && val == "" {
					return p, fmt.Sprintf(`Option "%s" requires a value`, name)
				}
			}
			p.opts[name] = val
			if name == "help" {
				if val != "" {
					p.help = val
				} else if p.cmd != "" {
					p.help = p.cmd
				} else if len(p.args) > 0 {
					p.help = p.args[0]
				} else {
					p.help = "__main__"
				}
			}
			continue
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			key := strings.TrimPrefix(a, "-")
			spec, ok := byShort[key]
			if !ok {
				return p, fmt.Sprintf(`Unknown option "%s"`, key)
			}
			val := ""
			if spec.hasValue && !spec.optional && i+1 < len(args) {
				i++
				val = args[i]
			}
			p.opts[spec.name] = val
			if spec.name == "help" {
				if p.cmd != "" {
					p.help = p.cmd
				} else {
					p.help = "__main__"
				}
			}
			continue
		}
		if p.cmd == "" {
			p.cmd = a
		} else {
			p.args = append(p.args, a)
		}
	}
	if p.cmd == "help" && len(p.args) > 0 && p.help == "" {
		p.help = p.args[0]
	}
	if p.help == "__main__" && p.cmd != "" {
		p.help = p.cmd
	}
	return p, ""
}

func isCommand(s string) bool {
	switch s {
	case "add-environment", "diff", "format", "help", "init", "lint", "pull", "push", "version":
		return true
	}
	return false
}

func runAddEnvironment(p parsed) int {
	if len(p.args) < 1 {
		logErr("Too few positional args supplied on command line; command add-environment requires at least 1 args")
		return 78
	}
	dir := optDefault(p, "dir", ".")
	st, err := os.Stat(dir)
	if err != nil || !st.IsDir() {
		logErr("In add-environment, --dir must refer to a directory that already exists")
		return 78
	}
	path := filepath.Join(dir, ".skeema")
	if _, err := os.Stat(path); err != nil {
		abs, _ := filepath.Abs(dir)
		logErr(fmt.Sprintf("Dir %s does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`", abs))
		return 78
	}
	host := optDefault(p, "host", "localhost")
	port := optDefault(p, "port", "3306")
	socket := optDefault(p, "socket", "")
	block := fmt.Sprintf("\n[%s]\nhost=%s\nport=%s\n", p.args[0], host, port)
	if socket != "" {
		block += "socket=" + socket + "\n"
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0)
	if err != nil {
		logErr(err.Error())
		return 78
	}
	_, _ = f.WriteString(block)
	_ = f.Close()
	logWarn(fmt.Sprintf(`Unable to automatically determine database server's vendor/version. To set manually, use the "flavor" option in %s`, path))
	logInfo(fmt.Sprintf("Added environment [%s] to %s", p.args[0], path))
	return 0
}

func runInit(p parsed) int {
	if _, ok := p.opts["host"]; !ok {
		logErr("Option --host must be supplied on the command-line")
		return 78
	}
	host := optDefault(p, "host", "localhost")
	target := optDefault(p, "dir", host)
	if filepath.IsAbs(target) {
		target = filepath.Base(target)
	}
	if host == "localhost" || host == "127.0.0.1" {
		logErr(fmt.Sprintf("Unable to connect to localhost:/tmp/mysql.sock for %s/%s: dial unix /tmp/mysql.sock: connect: no such file or directory", cwd(), target))
	} else {
		logErr(fmt.Sprintf("Unable to connect to %s:3306 for %s/%s: dial tcp: lookup %s: no such host", host, cwd(), target, host))
	}
	return 2
}

func runLocalCheck(p parsed) int {
	if p.cmd == "format" {
		if hasSQL(".") {
			logInfo("Checking format of " + cwd())
			logErr(fmt.Sprintf("Skipping %s: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"", cwd()))
			return 78
		}
		return 0
	}
	if hasSQL(".") {
		logInfo("Linting " + cwd())
		logErr(fmt.Sprintf("Skipping directory %s due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"", filepath.Base(cwd())))
		logErr("Skipped 1 operation due to fatal errors")
		return 78
	}
	return 0
}

func runDBCommand(p parsed) int {
	if _, ok := p.opts["host"]; ok && (p.cmd == "diff" || p.cmd == "push" || p.cmd == "pull") {
		logErr("The host option cannot be set via command line for this command. For more information, visit https://www.skeema.io/docs/config/#limitations-on-host-and-schema-options")
		return 78
	}
	if p.cmd == "pull" && hasSQL(".") {
		logErr("Option --host must be supplied on the command-line")
		return 78
	}
	return 0
}

func hasSQL(root string) bool {
	found := false
	_ = filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil || found {
			return nil
		}
		base := filepath.Base(path)
		if d.IsDir() && (base == ".git" || base == "eval") {
			return filepath.SkipDir
		}
		if !d.IsDir() && strings.EqualFold(filepath.Ext(path), ".sql") {
			found = true
		}
		return nil
	})
	return found
}

func optDefault(p parsed, key, def string) string {
	if v, ok := p.opts[key]; ok && v != "" {
		return v
	}
	return def
}

func cwd() string {
	wd, _ := os.Getwd()
	return wd
}

func logInfo(s string) { fmt.Fprintf(os.Stderr, "%s [INFO]  %s\n", stamp(), s) }
func logWarn(s string) { fmt.Fprintf(os.Stderr, "%s [WARN]  %s\n", stamp(), s) }
func logErr(s string)  { fmt.Fprintf(os.Stderr, "%s [ERROR] %s\n", stamp(), s) }
func stamp() string    { return time.Now().Format("2006-01-02 15:04:05") }

func printHelp(cmd string) {
	if cmd == "" || cmd == "help" {
		fmt.Print(mainHelp)
		return
	}
	if h, ok := commandHelp[cmd]; ok {
		fmt.Print(h)
		return
	}
	logErr(fmt.Sprintf(`Unknown command "%s"`, cmd))
	os.Exit(2)
}

const mainHelp = `
Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands

`

var commandHelp = map[string]string{
	"version": `
Usage:  skeema version [<options>]

Display program version

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/version

`,
	"add-environment": `
Usage:  skeema add-environment [<options>] <environment>

Modifies the .skeema file in an existing host directory to add a new named
environment. For example, if ` + "`skeema init`" + ` was previously used to create a dir
for a host with the default "production" environment, ` + "`skeema add-environment`" + `
could be used to define a "staging" or "development" environment pointing at a
different host and port, or perhaps a "local" environment pointing at localhost
and a socket path.

This command currently only handles very simple cases. For many situations,
editing .skeema files directly is a better approach.

Add-Environment Options:
  -d, --dir value              Base dir for this host's schemas (default ".")
  -h, --host value             Database hostname or IP address
  -P, --port value             Port to use for database host (default "3306")
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/add-environment

`,
	"init": `
Usage:  skeema init [<options>] [<environment>]

Creates a filesystem representation of the schemas on a database server. For
each schema on the DB server (or just the single schema specified by --schema),
a subdir with a .skeema config file will be created. Each directory will be
populated with .sql files containing CREATE statements for every table and
routine in the schema.

Init Options:
  -d, --dir value              Subdir name to use for this host's schemas (default "<hostname>")
  -h, --host value             Database hostname or IP address
      --include-auto-inc       Include starting auto-inc values in table files
  -P, --port value             Port to use for database host (default "3306")
      --schema value           Only import the one specified schema; skip creation of subdirs for each schema
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem

Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/init

`,
}

func init() {
	for _, c := range []string{"diff", "push"} {
		commandHelp[c] = usageFor(c) + commonDiffPushOptions(c)
	}
	commandHelp["lint"] = usageFor("lint") + linterOptions + workspaceOptions + globalOptions("lint")
	commandHelp["format"] = usageFor("format") + `
Format Options:
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)

` + workspaceOptions + globalOptions("format")
	commandHelp["pull"] = usageFor("pull") + `
Pull Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --include-auto-inc           Include starting auto-inc values in new table files, and update in existing files
      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)
      --strip-partitioning         Omit PARTITION BY clause when writing partitioned tables to filesystem
      --update-partitioning        Update PARTITION BY clauses in existing table files

` + workspaceOptions + globalOptions("pull")
}

func usageFor(cmd string) string {
	text := map[string]string{
		"diff":   "Compares the schemas on database server(s) to the corresponding filesystem\nrepresentation of them. The output is a series of DDL commands that, if run on\nthe DB server, would cause its schemas to now match the definitions from the\nfilesystem.",
		"push":   "Modifies the schemas on database server(s) to match the corresponding filesystem\nrepresentation of them. This essentially performs the same diff logic as `skeema\ndiff`, but then actually runs the generated DDL. You should generally run\n`skeema diff` first to see what changes will be applied.",
		"pull":   "Updates the existing filesystem representation of the schemas on a DB server.\nUse this command when changes have been applied to the database manually or\noutside of Skeema, in order to make the filesystem representation reflect those\nchanges.",
		"lint":   "Checks the filesystem representation of database objects for problems.",
		"format": "Reformats the filesystem representation of database objects to match the\ncanonical format shown in SHOW CREATE.",
	}[cmd]
	arg := "[<environment>]"
	return fmt.Sprintf("\nUsage:  skeema %s [<options>] %s\n\n%s\n\n", cmd, arg, text)
}

func commonDiffPushOptions(cmd string) string {
	safety := `      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive
      --safe-below-size value         Always permit generating destructive operations for tables below this size in bytes (default "0")
      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)
`
	if cmd == "push" {
		safety = `      --allow-unsafe                  Permit running ALTER or DROP operations that are potentially destructive
      --dry-run                       Output DDL but don't run it; equivalent to ` + "`skeema diff`" + `
      --foreign-key-checks            Force the server to check referential integrity of any new foreign key
      --safe-below-size value         Always permit destructive operations for tables below this size in bytes (default "0")
      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)
`
	}
	return `External Tool Options:
  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars
      --alter-wrapper-min-size value  Ignore --alter-wrapper for tables smaller than this size in bytes (default "0")
  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)

SQL Generation Options:
      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: "inplace", "copy", "instant", "nocopy")
      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: "none", "shared", "exclusive")
      --alter-validate-virtual        Apply a WITH VALIDATION clause to ALTER TABLEs affecting virtual columns
      --compare-metadata              For stored programs, detect changes to creation-time sql_mode or DB collation
      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact
      --lax-column-order              When comparing tables, don't re-order columns if they only differ by position
      --lax-comments                  When comparing tables or routines, don't modify them if they only differ by comment clauses
      --partitioning value            Specify handling of partitioning status on the database side (valid values: "keep", "remove", "modify") (default "keep")

` + linterOptions + `
Safety Options:
` + safety + `
Sharding Options:
  -q, --brief                         Don't output DDL to STDOUT; instead output list of database servers with at least one difference
  -c, --concurrent-servers value      Perform operations on this number of database servers concurrently (default "1")
  -1, --first-only                    For dirs mapping to multiple hosts or schemas, only run against the first target per dir

` + workspaceOptions + globalOptions(cmd)
}

const linterOptions = `Linter Rule Options:
      --allow-auto-inc value          List of allowed auto_increment column data types for --lint-auto-inc (default "int unsigned, bigint unsigned")
      --allow-charset value           List of allowed character sets for --lint-charset (default "latin1,utf8mb4")
      --allow-compression value       List of allowed compression settings for --lint-compression (default "none,4kb,8kb")
      --allow-definer value           List of allowed definer users for --lint-definer (default "%@%")
      --allow-engine value            List of allowed storage engines for --lint-engine (default "innodb")
      --allow-pk-type value           List of allowed data types for --lint-pk-type
      --[skip-]lint                   Check modified objects for problems before proceeding (enabled by default; disable with --skip-lint)
      --lint-auto-inc value           Only allow auto_increment column data types listed in --allow-auto-inc (valid values: "ignore", "warning", "error") (default "warning")
      --lint-charset value            Only allow character sets listed in --allow-charset (valid values: "ignore", "warning", "error") (default "warning")
      --lint-compression value        Only allow compression settings listed in --allow-compression (valid values: "ignore", "warning", "error") (default "warning")
      --lint-definer value            Only allow definer users listed in --allow-definer for stored objects (valid values: "ignore", "warning", "error") (default "error")
      --lint-display-width value      Only allow default display width for int types (valid values: "ignore", "warning", "error") (default "warning")
      --lint-dupe-index value         Flag redundant secondary indexes (valid values: "ignore", "warning", "error") (default "warning")
      --lint-engine value             Only allow storage engines listed in --allow-engine (valid values: "ignore", "warning", "error") (default "warning")
      --lint-fk-parent value          Flag foreign keys where same-schema parent table is missing or lacks unique key on referenced columns (valid values: "ignore", "warning", "error") (default "warning")
      --lint-has-enum value           Flag columns using ENUM or SET data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-fk value             Flag any use of foreign keys; intended for environments that restrict their presence (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-float value          Flag columns using FLOAT or DOUBLE data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-routine value        Flag any use of stored procs or funcs; intended for environments that restrict their presence (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-time value           Flag columns using TIMESTAMP, DATETIME, or TIME data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-name-case value          Flag tables that have uppercase letters in their names (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-pk value                 Flag tables that lack a primary key (valid values: "ignore", "warning", "error") (default "warning")
      --lint-pk-type value            Only allow primary keys to have types listed in --allow-pk-type (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-reserved-word value      Flag names of tables, columns, or routines that used reserved words (valid values: "ignore", "warning", "error") (default "warning")
      --lint-zero-date value          Flag DATE, DATETIME, and TIMESTAMP columns that have zero-date default values (valid values: "ignore", "warning", "error") (default "warning")

`

const workspaceOptions = `Workspace Options:
      --docker-cleanup value          With --workspace=docker, specifies how to clean up containers (valid values: "none", "stop", "destroy") (default "none")
  -t, --temp-schema value             Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")
      --temp-schema-binlog value      Controls whether temp schema DDL operations are replicated (valid values: "on", "off", "auto") (default "auto")
      --temp-schema-mode value        Tunes workspace load with workspace=temp-schema; heavier load makes Skeema faster but may disrupt other workloads on the database (valid values: "serial", "light", "regular", "heavy", "extreme") (default "regular")
      --temp-schema-threads value     Deprecated manner of controlling workspace load with workspace=temp-schema (default "5")
  -w, --workspace value               Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")

`

func globalOptions(cmd string) string {
	return `Global Options:
  -o, --connect-options value         Comma-separated session options to set upon connecting to each database server
      --debug                         Enable debug logging
  -?, --help[=value]                  Display usage information for the specified command
  -H, --host-wrapper value            External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value             Ignore functions that match regex
      --ignore-proc value             Ignore stored procedures that match regex
      --ignore-schema value           Ignore schemas that match regex
      --ignore-table value            Ignore tables that match regex
      --[skip-]my-cnf                 Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]              Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value                Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value                    Username to connect to database host (default "root")
      --version                       Display program version

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/` + cmd + `

`
}
