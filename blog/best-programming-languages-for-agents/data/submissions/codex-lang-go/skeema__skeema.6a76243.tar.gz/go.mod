module programbench/skeema

go 1.21
