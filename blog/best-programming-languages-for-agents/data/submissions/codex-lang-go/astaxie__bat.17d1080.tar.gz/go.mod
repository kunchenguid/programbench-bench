module batclone

go 1.21
