package main

import (
	"bytes"
	"compress/gzip"
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strings"
)

const version = "0.1.0"

var helpText = `bat is a Go implemented CLI cURL-like tool for humans.

Usage:

	bat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

	bat beego.me

more help information please refer to https://github.com/astaxie/bat
`

type cliFlags struct {
	auth     string
	bench    bool
	benchN   int
	benchC   int
	body     string
	form     bool
	jsonMode bool
	pretty   bool
	insecure bool
	proxy    string
	print    string
	version  bool
}

type item struct {
	kind  string
	key   string
	value string
}

func main() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds | log.Lshortfile)
	flags, args := parseFlags()
	if flags.version {
		fmt.Println("Version: 0.1.0")
		os.Exit(2)
	}
	if len(args) == 0 {
		fmt.Print(helpText)
		os.Exit(2)
	}
	method := ""
	if isMethod(args[0]) {
		method = strings.ToUpper(args[0])
		args = args[1:]
	}
	if len(args) == 0 {
		fmt.Print(helpText)
		os.Exit(2)
	}
	rawURL := normalizeURL(args[0])
	args = args[1:]

	items := parseItems(args)
	hasData := false
	for _, it := range items {
		if it.kind == "data" || it.kind == "file" {
			hasData = true
		}
	}
	if flags.body != "" {
		hasData = true
	}
	if method == "" {
		if hasData {
			method = "POST"
		} else {
			method = "GET"
		}
	}

	if method == "GET" {
		rawURL = addQuery(rawURL, items)
	}

	body, contentType := buildBody(flags, items, method)
	req, err := http.NewRequest(method, rawURL, body)
	if err != nil {
		log.Fatalf("can't get the url %v", err)
	}
	req.Header.Set("User-Agent", "bat/0.1.0")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	for _, it := range items {
		if it.kind == "header" {
			req.Header.Set(it.key, it.value)
		}
	}
	if flags.auth != "" {
		req.Header.Set("Authorization", "Basic "+base64.StdEncoding.EncodeToString([]byte(strings.Replace(flags.auth, ":", ":", 1))))
	}
	if contentType != "" {
		req.Header.Set("Content-Type", contentType)
	}
	client := &http.Client{}
	if flags.proxy != "" {
		purl, err := url.Parse(flags.proxy)
		if err == nil {
			client.Transport = &http.Transport{Proxy: http.ProxyURL(purl)}
		}
	}
	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("can't get the url %v", err)
	}
	defer resp.Body.Close()
	out, err := readResponse(resp)
	if err != nil {
		log.Fatalf("can't get the url %v", err)
	}
	printBody(out, flags.pretty, resp.Header.Get("Content-Type"))
}

func parseFlags() (cliFlags, []string) {
	var c cliFlags
	fs := flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	fs.Usage = func() { fmt.Fprint(os.Stderr, helpText) }
	fs.StringVar(&c.auth, "a", "", "")
	fs.StringVar(&c.auth, "auth", "", "")
	fs.BoolVar(&c.bench, "b", false, "")
	fs.BoolVar(&c.bench, "bench", false, "")
	fs.IntVar(&c.benchN, "b.N", 1000, "")
	fs.IntVar(&c.benchC, "b.C", 100, "")
	fs.StringVar(&c.body, "body", "", "")
	fs.BoolVar(&c.form, "f", false, "")
	fs.BoolVar(&c.form, "form", false, "")
	c.jsonMode = true
	c.pretty = true
	c.version = false
	fs.BoolVar(&c.jsonMode, "j", true, "")
	fs.BoolVar(&c.jsonMode, "json", true, "")
	fs.BoolVar(&c.pretty, "p", true, "")
	fs.BoolVar(&c.pretty, "pretty", true, "")
	fs.BoolVar(&c.insecure, "i", false, "")
	fs.BoolVar(&c.insecure, "insecure", false, "")
	fs.StringVar(&c.proxy, "proxy", "", "")
	fs.StringVar(&c.print, "print", "A", "")
	fs.BoolVar(&c.version, "v", false, "")
	fs.BoolVar(&c.version, "version", false, "")
	err := fs.Parse(os.Args[1:])
	if err == flag.ErrHelp {
		os.Exit(2)
	}
	if err != nil {
		fmt.Fprint(os.Stderr, helpText)
		os.Exit(2)
	}
	return c, fs.Args()
}

func isMethod(s string) bool {
	switch strings.ToUpper(s) {
	case "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS":
		return true
	}
	return false
}

func normalizeURL(s string) string {
	if !strings.Contains(s, "://") {
		return "http://" + s
	}
	return s
}

func parseItems(args []string) []item {
	var out []item
	for _, a := range args {
		if i := strings.Index(a, "@"); i > 0 && !strings.Contains(a[:i], "=") && !strings.Contains(a[:i], ":") {
			out = append(out, item{kind: "file", key: a[:i], value: a[i+1:]})
			continue
		}
		if i := strings.Index(a, ":"); i > 0 {
			out = append(out, item{kind: "header", key: a[:i], value: a[i+1:]})
			continue
		}
		if i := strings.Index(a, "="); i > 0 {
			out = append(out, item{kind: "data", key: a[:i], value: a[i+1:]})
			continue
		}
	}
	return out
}

func addQuery(raw string, items []item) string {
	u, err := url.Parse(raw)
	if err != nil {
		return raw
	}
	q := u.Query()
	for _, it := range items {
		if it.kind == "data" {
			q.Add(it.key, it.value)
		}
	}
	u.RawQuery = q.Encode()
	return u.String()
}

func buildBody(flags cliFlags, items []item, method string) (io.Reader, string) {
	if flags.body != "" {
		return strings.NewReader(flags.body), ""
	}
	if method == "GET" || method == "HEAD" {
		return nil, ""
	}
	data := map[string]string{}
	form := url.Values{}
	files := []item{}
	for _, it := range items {
		switch it.kind {
		case "data":
			data[it.key] = it.value
			form.Add(it.key, it.value)
		case "file":
			files = append(files, it)
		}
	}
	if len(files) > 0 {
		var buf bytes.Buffer
		w := multipart.NewWriter(&buf)
		for _, it := range files {
			f, err := os.Open(it.value)
			if err != nil {
				continue
			}
			part, err := w.CreateFormFile(it.key, it.value)
			if err == nil {
				io.Copy(part, f)
			}
			f.Close()
		}
		w.Close()
		if buf.Len() > 0 {
			return &buf, w.FormDataContentType()
		}
		return strings.NewReader(""), ""
	}
	if flags.form {
		return strings.NewReader(form.Encode()), "application/x-www-form-urlencoded"
	}
	if len(data) > 0 {
		keys := make([]string, 0, len(data))
		for k := range data {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		var buf bytes.Buffer
		buf.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				buf.WriteByte(',')
			}
			kb, _ := json.Marshal(k)
			vb, _ := json.Marshal(data[k])
			buf.Write(kb)
			buf.WriteByte(':')
			buf.Write(vb)
		}
		buf.WriteString("}\n")
		return &buf, "application/json"
	}
	return strings.NewReader(""), ""
}

func readResponse(resp *http.Response) ([]byte, error) {
	var r io.Reader = resp.Body
	enc := strings.ToLower(resp.Header.Get("Content-Encoding"))
	if strings.Contains(enc, "gzip") {
		gr, err := gzip.NewReader(resp.Body)
		if err != nil {
			return nil, err
		}
		defer gr.Close()
		r = gr
	}
	return io.ReadAll(r)
}

func printBody(b []byte, pretty bool, ctype string) {
	fmt.Println()
	if strings.Contains(strings.ToLower(ctype), "json") {
		var out bytes.Buffer
		var err error
		if pretty {
			err = json.Indent(&out, b, "", "  ")
		} else {
			err = json.Compact(&out, b)
		}
		if err != nil {
			log.Fatalf("Response Json Indent: %v", err)
		}
		fmt.Println(out.String())
		return
	}
	os.Stdout.Write(b)
}
