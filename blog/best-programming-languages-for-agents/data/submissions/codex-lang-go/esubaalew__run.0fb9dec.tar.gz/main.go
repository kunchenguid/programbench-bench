package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type config struct {
	lang     string
	file     string
	code     string
	hasCode  bool
	noDetect bool
	args     []string
}

const helpText = `Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help
`

const versionText = `run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)
`

var languages = []string{
	"bash", "c", "cpp", "crystal", "csharp", "dart", "elixir", "go", "groovy",
	"haskell", "java", "javascript", "julia", "kotlin", "lua", "nim", "perl",
	"php", "python", "r", "ruby", "rust", "swift", "typescript", "zig",
}

func main() {
	cfg, handled, code := parse(os.Args[1:])
	if handled {
		os.Exit(code)
	}

	lang, content, fromFile, err := resolve(cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	lang = normalizeLang(lang)
	if lang == "" {
		lang = "python"
	}
	if !knownLang(lang) {
		fmt.Fprintf(os.Stderr, "Error: Unknown language '%s'. Available languages: %s\n", cfg.lang, strings.Join(languages, ", "))
		os.Exit(1)
	}

	exit := run(lang, content, fromFile)
	os.Exit(exit)
}

func parse(args []string) (config, bool, int) {
	var cfg config
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return cfg, true, 0
		case "-V", "--version":
			fmt.Print(versionText)
			return cfg, true, 0
		case "--no-detect":
			cfg.noDetect = true
		case "-l", "--lang":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <LANG>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return cfg, true, 2
			}
			i++
			cfg.lang = args[i]
		case "-f", "--file":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <PATH>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return cfg, true, 2
			}
			i++
			cfg.file = args[i]
		case "-c", "--code":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <CODE>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return cfg, true, 2
			}
			i++
			cfg.code = args[i]
			cfg.hasCode = true
		case "--":
			cfg.args = append(cfg.args, args[i+1:]...)
			return cfg, false, 0
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [ARGS]...\n\nFor more information, try '--help'.\n", a, a, a)
				return cfg, true, 2
			}
			cfg.args = append(cfg.args, a)
		}
	}
	return cfg, false, 0
}

func resolve(cfg config) (string, string, bool, error) {
	lang := cfg.lang
	if lang == "" && len(cfg.args) > 0 && knownLang(normalizeLang(cfg.args[0])) {
		lang = cfg.args[0]
		cfg.args = cfg.args[1:]
	}

	if cfg.file == "" && !cfg.hasCode && len(cfg.args) > 0 {
		if st, err := os.Stat(cfg.args[0]); err == nil && !st.IsDir() {
			cfg.file = cfg.args[0]
			cfg.args = cfg.args[1:]
		}
	}
	if cfg.file != "" {
		if _, err := os.Stat(cfg.file); err != nil {
			if os.IsNotExist(err) {
				return "", "", false, fmt.Errorf("stat %s: no such file or directory", filepath.Base(cfg.file))
			}
			return "", "", false, err
		}
		b, err := os.ReadFile(cfg.file)
		if err != nil {
			return "", "", false, err
		}
		if lang == "" && !cfg.noDetect {
			lang = detectFile(cfg.file)
		}
		return lang, string(b), true, nil
	}

	code := cfg.code
	if !cfg.hasCode && len(cfg.args) > 0 {
		code = strings.Join(cfg.args, " ")
	}
	if lang == "" && !cfg.noDetect {
		lang = detectCode(code)
	}
	return lang, code, false, nil
}

func normalizeLang(s string) string {
	switch strings.ToLower(s) {
	case "sh", "shell":
		return "bash"
	case "py", "python3":
		return "python"
	case "js", "node", "nodejs":
		return "javascript"
	case "ts":
		return "typescript"
	case "rs":
		return "rust"
	case "cc", "c++":
		return "cpp"
	default:
		return strings.ToLower(s)
	}
}

func knownLang(s string) bool {
	for _, l := range languages {
		if s == l {
			return true
		}
	}
	return false
}

func detectFile(path string) string {
	switch strings.ToLower(filepath.Ext(path)) {
	case ".sh", ".bash":
		return "bash"
	case ".go":
		return "go"
	case ".c", ".h":
		return "c"
	case ".cc", ".cpp", ".cxx", ".hpp":
		return "cpp"
	case ".js", ".mjs", ".cjs":
		return "javascript"
	case ".ts":
		return "typescript"
	case ".pl", ".pm":
		return "perl"
	case ".php":
		return "php"
	case ".rb":
		return "ruby"
	case ".rs":
		return "rust"
	case ".lua":
		return "lua"
	case ".py":
		return "python"
	default:
		return ""
	}
}

func detectCode(code string) string {
	t := strings.TrimSpace(code)
	switch {
	case strings.HasPrefix(t, "package main"), strings.Contains(t, "func main()"):
		return "go"
	case strings.HasPrefix(t, "#include"):
		return "c"
	case strings.HasPrefix(t, "echo "), strings.HasPrefix(t, "printf "), strings.Contains(t, "#!/bin/bash"), strings.Contains(t, "#!/usr/bin/env bash"):
		return "bash"
	case strings.HasPrefix(t, "console.log"), strings.Contains(t, "function "):
		return "javascript"
	case strings.HasPrefix(t, "<?php"):
		return "php"
	case strings.Contains(t, "fn main()"):
		return "rust"
	default:
		return "python"
	}
}

func run(lang, code string, fromFile bool) int {
	switch lang {
	case "python":
		fmt.Fprintln(os.Stderr, "python is not available in the go-mandated arm")
		return 127
	case "bash":
		return runCommandNoStdin("", "bash", "-c", code)
	case "go":
		return runGo(code)
	case "c":
		return runCompiled(code, "main.c", "a.out", "gcc")
	case "cpp":
		return runCompiled(code, "main.cpp", "a.out", "g++")
	case "perl":
		return runCommandWithInput(code, "perl", "-e", code)
	case "php":
		return runCommandWithInput(code, "php", "-r", stripPHP(code))
	case "javascript":
		if _, err := exec.LookPath("node"); err != nil {
			return 127
		}
		return runCommandWithInput(code, "node", "-e", code)
	case "rust":
		fmt.Fprintln(os.Stderr, "Error: Rust support requires the `rustc` executable. Install it via Rustup and ensure it is on your PATH.")
		return 1
	case "lua":
		fmt.Fprintln(os.Stderr, "Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.")
		return 1
	default:
		msgName := executableFor(lang)
		if msgName == "" {
			msgName = lang
		}
		fmt.Fprintf(os.Stderr, "Error: %s support requires the `%s` executable. Install it and ensure it is on your PATH.\n", title(lang), msgName)
		return 1
	}
	_ = fromFile
	return 1
}

func runCompiled(code, src, out, compiler string) int {
	return runTemp(code, src, func(dir string) *exec.Cmd {
		return exec.Command(compiler, src, "-o", out)
	}, "./"+out)
}

func runTemp(code, filename string, steps ...interface{}) int {
	dir, err := os.MkdirTemp("", "run-*")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer os.RemoveAll(dir)
	if err := os.WriteFile(filepath.Join(dir, filename), []byte(code), 0644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	for _, step := range steps {
		switch v := step.(type) {
		case func(string) *exec.Cmd:
			cmd := v(dir)
			cmd.Dir = dir
			if exit := runCmd(cmd, false); exit != 0 {
				return exit
			}
		case string:
			cmd := exec.Command(v)
			cmd.Dir = dir
			return runCmd(cmd, true)
		}
	}
	return 0
}

func runGo(code string) int {
	dir, err := os.MkdirTemp("", "run-*")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer os.RemoveAll(dir)
	if err := os.WriteFile(filepath.Join(dir, "main.go"), []byte(code), 0644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	cmd := exec.Command("go", "run", "main.go")
	cmd.Dir = dir
	return runCmd(cmd, true)
}

func runCommandNoStdin(dir, name string, args ...string) int {
	cmd := exec.Command(name, args...)
	cmd.Dir = dir
	return runCmd(cmd, false)
}

func runCommandWithInput(_ string, name string, args ...string) int {
	cmd := exec.Command(name, args...)
	return runCmd(cmd, true)
}

func runCmd(cmd *exec.Cmd, attachStdin bool) int {
	if attachStdin {
		cmd.Stdin = os.Stdin
	}
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	err := cmd.Run()
	if err == nil {
		return 0
	}
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		return ee.ExitCode()
	}
	if errors.Is(err, exec.ErrNotFound) {
		return 127
	}
	fmt.Fprintln(os.Stderr, err)
	return 1
}

func stripPHP(code string) string {
	s := strings.TrimSpace(code)
	s = strings.TrimPrefix(s, "<?php")
	s = strings.TrimSuffix(s, "?>")
	return s
}

func executableFor(lang string) string {
	switch lang {
	case "csharp":
		return "dotnet"
	case "javascript":
		return "node"
	case "typescript":
		return "deno"
	case "r":
		return "Rscript"
	default:
		return lang
	}
}

func title(s string) string {
	if s == "" {
		return s
	}
	return strings.ToUpper(s[:1]) + s[1:]
}

func init() {
	_, _ = io.Copy(io.Discard, strings.NewReader(""))
}
