module cppcheckclone

go 1.21
