package main

import (
	"bufio"
	"encoding/xml"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "Cppcheck 2.19 dev"

const helpText = `Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    --addon=<addon>
                         Execute addon. i.e. --addon=misra. If options must be
                         provided a json configuration is needed.
    --check-config       Check cppcheck configuration. The normal code
                         analysis is disabled by this flag.
    -D<ID>               Define preprocessor symbol.
    -E                   Print preprocessor output on stdout and don't do any
                         further processing.
    --enable=<severity>  Enable additional checks grouped by severity.
                         Severities include warning, performance, portability,
                         information, style, unusedFunction, missingInclude, all.
    --error-exitcode=<n> If errors are found, integer [n] is returned instead of
                         the default '0'.
    --errorlist          Print a list of all the error messages in XML format.
    --file-list=<file>   Specify the files to check in a text file.
    -f, --force          Force checking of all configurations in files.
    -h, --help           Print this help.
    -I <dir>             Give path to search for include files.
    --include=<file>     Force inclusion of a file before the checked file.
    --inline-suppr       Enable inline suppressions.
    -j <jobs>            Start <jobs> threads to do the checking simultaneously.
    --language=<language>, -x <language>
                         Forces cppcheck to check all files as the given language.
    --library=<cfg>      Load file <cfg> that contains information about types
                         and functions.
    --output-file=<file> Write results to file, rather than standard error.
    --output-format=<format>
                        Specify the output format. The available formats are:
                          * text
                          * sarif
                          * xml (deprecated)
                          * xmlv2
                          * xmlv3
    --project=<file>     Run Cppcheck on project.
    -q, --quiet          Do not show progress reports.
    --std=<id>           Set standard.
    --suppress=<spec>    Suppress warnings that match <spec>. The format of
                         <spec> is: [error id]:[filename]:[line]
    --suppressions-list=<file>
                         Suppress warnings listed in the file.
    --template='<text>'  Format the error messages. Available fields:
                           {file} {line} {column} {severity} {message} {id}
                         Pre-defined templates: gcc (default), cppcheck1, vs, edit.
    -U<ID>               Undefine preprocessor symbol.
    -v, --verbose        Output more detailed error information.
    --version            Print out version number.
    --xml                Write results in xml format to error stream (stderr).

Example usage:
  cppcheck .
  cppcheck --quiet ../myproject/
  cppcheck --enable=all --inconclusive --library=posix test.cpp
`

type options struct {
	quiet       bool
	xmlOut      bool
	sarif       bool
	preprocess  bool
	checkConfig bool
	inlineSuppr bool
	enableAll   bool
	enableStyle bool
	template    string
	outputFile  string
	errorCode   int
	suppress    []string
	files       []string
}

type finding struct {
	File     string
	Line     int
	Column   int
	Severity string
	ID       string
	Message  string
}

func main() {
	code := run(os.Args[1:], os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdout, stderr io.Writer) int {
	var opt options
	opt.template = "gcc"
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--help" || a == "-h" || len(args) == 0:
			fmt.Fprint(stdout, helpText)
			return 0
		case a == "--version":
			fmt.Fprintln(stdout, version)
			return 0
		case a == "--errorlist":
			printErrorList(stdout)
			return 0
		case a == "-q" || a == "--quiet":
			opt.quiet = true
		case a == "--xml":
			opt.xmlOut = true
		case a == "-E":
			opt.preprocess = true
		case a == "--check-config":
			opt.checkConfig = true
		case a == "--inline-suppr":
			opt.inlineSuppr = true
		case strings.HasPrefix(a, "--output-format="):
			f := strings.TrimPrefix(a, "--output-format=")
			opt.xmlOut = strings.HasPrefix(f, "xml")
			opt.sarif = f == "sarif"
		case strings.HasPrefix(a, "--output-file="):
			opt.outputFile = strings.TrimPrefix(a, "--output-file=")
		case a == "--output-file" && i+1 < len(args):
			i++
			opt.outputFile = args[i]
		case strings.HasPrefix(a, "--template="):
			opt.template = strings.Trim(strings.TrimPrefix(a, "--template="), "'\"")
		case strings.HasPrefix(a, "--error-exitcode="):
			opt.errorCode, _ = strconv.Atoi(strings.TrimPrefix(a, "--error-exitcode="))
		case strings.HasPrefix(a, "--enable="):
			v := strings.TrimPrefix(a, "--enable=")
			opt.enableAll = strings.Contains(v, "all")
			opt.enableStyle = opt.enableAll || strings.Contains(v, "style") || strings.Contains(v, "performance") || strings.Contains(v, "warning")
		case strings.HasPrefix(a, "--suppress="):
			opt.suppress = append(opt.suppress, strings.TrimPrefix(a, "--suppress="))
		case strings.HasPrefix(a, "--suppressions-list="):
			opt.suppress = append(opt.suppress, readSuppressions(strings.TrimPrefix(a, "--suppressions-list="))...)
		case strings.HasPrefix(a, "--file-list="):
			opt.files = append(opt.files, readList(strings.TrimPrefix(a, "--file-list="))...)
		case a == "--file-list" && i+1 < len(args):
			i++
			opt.files = append(opt.files, readList(args[i])...)
		case a == "-I" || a == "-j" || a == "-l" || a == "-x" || a == "--language" || a == "--include":
			if i+1 < len(args) {
				i++
			}
		case strings.HasPrefix(a, "-I") || strings.HasPrefix(a, "-D") || strings.HasPrefix(a, "-U"):
		case strings.HasPrefix(a, "--"):
			if knownPrefixOption(a) {
				continue
			}
			fmt.Fprintf(stderr, "cppcheck: error: unrecognized command line option: \"%s\".\n", a)
			return 1
		case strings.HasPrefix(a, "-") && a != "-":
			fmt.Fprintf(stderr, "cppcheck: error: unrecognized command line option: \"%s\".\n", a)
			return 1
		default:
			opt.files = append(opt.files, a)
		}
	}
	if len(args) == 0 {
		fmt.Fprint(stdout, helpText)
		return 0
	}
	if len(opt.files) == 0 {
		fmt.Fprintln(stderr, "cppcheck: error: no C or C++ source files found.")
		return 1
	}
	files := expandFiles(opt.files)
	if len(files) == 0 {
		fmt.Fprintln(stderr, "cppcheck: error: no C or C++ source files found.")
		return 1
	}
	if opt.preprocess {
		for _, f := range files {
			preprocess(f, stdout)
		}
		return 0
	}
	var finds []finding
	for idx, f := range files {
		if !opt.quiet {
			fmt.Fprintf(stdout, "Checking %s...\n", f)
			if len(files) > 1 {
				fmt.Fprintf(stdout, "%d/%d files checked %d%% done\n", idx+1, len(files), (idx+1)*100/len(files))
			}
		}
		if !opt.checkConfig {
			finds = append(finds, analyzeFile(f, opt)...)
		}
	}
	finds = applySuppressions(finds, opt.suppress)
	var out io.Writer = stderr
	var closeFn func() error
	if opt.outputFile != "" {
		f, err := os.Create(opt.outputFile)
		if err != nil {
			fmt.Fprintf(stderr, "cppcheck: error: could not open output file '%s'.\n", opt.outputFile)
			return 1
		}
		out, closeFn = f, f.Close
	}
	if opt.sarif {
		printSarif(out, finds)
	} else if opt.xmlOut {
		printXML(out, finds)
	} else {
		for _, f := range finds {
			fmt.Fprintln(out, formatFinding(f, opt.template))
		}
	}
	if closeFn != nil {
		_ = closeFn()
	}
	if len(finds) > 0 && opt.errorCode != 0 {
		return opt.errorCode
	}
	return 0
}

func knownPrefixOption(a string) bool {
	prefixes := []string{"--addon=", "--addon-python=", "--cppcheck-build-dir=", "--check-level=", "--checkers-report=", "--clang=", "--config-exclude=", "--config-excludes-file=", "--disable=", "--exitcode-suppressions=", "--file-filter=", "--fsigned-char", "--funsigned-char", "--includes-file=", "--include=", "--inconclusive", "--library=", "--max-configs=", "--max-ctu-depth=", "--platform=", "--plist-output=", "--project=", "--project-configuration=", "--relative-paths=", "--report-progress", "--report-type=", "--rule=", "--rule-file=", "--safety", "--showtime=", "--std=", "--suppress-xml=", "--template-location=", "--verbose", "--dump", "--force", "--check-library"}
	for _, p := range prefixes {
		if strings.HasSuffix(p, "=") {
			if strings.HasPrefix(a, p) {
				return true
			}
		} else if a == p {
			return true
		}
	}
	return false
}

func expandFiles(inputs []string) []string {
	var out []string
	seen := map[string]bool{}
	for _, p := range inputs {
		info, err := os.Stat(p)
		if err != nil {
			continue
		}
		if info.IsDir() {
			filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
				if err == nil && !d.IsDir() && isSource(path) && !seen[path] {
					seen[path] = true
					out = append(out, path)
				}
				return nil
			})
		} else if !seen[p] {
			seen[p] = true
			out = append(out, p)
		}
	}
	sort.Strings(out)
	return out
}

func isSource(p string) bool {
	switch strings.ToLower(filepath.Ext(p)) {
	case ".c", ".cc", ".cpp", ".cxx", ".c++", ".ipp", ".ixx", ".tpp", ".txx", ".h", ".hpp":
		return true
	}
	return false
}

func analyzeFile(path string, opt options) []finding {
	data, err := os.ReadFile(path)
	if err != nil {
		return []finding{{File: path, Line: 0, Column: 0, Severity: "error", ID: "fileNotFound", Message: "File not found: " + path}}
	}
	lines := strings.Split(string(data), "\n")
	var finds []finding
	arrays := map[string]int{}
	declRe := regexp.MustCompile(`\b(?:char|int|long|short|float|double|bool|unsigned|signed|size_t)\s+([A-Za-z_]\w*)\s*\[\s*(\d+)\s*\]`)
	accessRe := regexp.MustCompile(`\b([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]`)
	vars := map[string]int{}
	used := map[string]bool{}
	varDecl := regexp.MustCompile(`\b(?:int|char|long|short|float|double|bool|size_t)\s+([A-Za-z_]\w*)\s*(?:[;,=)])`)
	ptrNull := map[string]int{}
	ptrDecl := regexp.MustCompile(`\b(?:int|char|long|short|float|double|void)\s*\*\s*([A-Za-z_]\w*)\s*=\s*(?:0|NULL|nullptr)\b`)
	mallocs := map[string]int{}
	mallocRe := regexp.MustCompile(`\b([A-Za-z_]\w*)\s*=\s*(?:\([^)]+\)\s*)?(?:malloc|calloc|realloc)\s*\(`)
	for i, line := range lines {
		ln := i + 1
		if opt.inlineSuppr && i > 0 && strings.Contains(lines[i-1], "cppcheck-suppress") {
			continue
		}
		code := stripComments(line)
		declSpans := declRe.FindAllStringIndex(code, -1)
		for _, m := range declRe.FindAllStringSubmatch(code, -1) {
			n, _ := strconv.Atoi(m[2])
			arrays[m[1]] = n
		}
		accessMatches := accessRe.FindAllStringSubmatchIndex(code, -1)
		for _, mi := range accessMatches {
			if insideAny(mi[0], mi[1], declSpans) {
				continue
			}
			name := code[mi[2]:mi[3]]
			idxText := code[mi[4]:mi[5]]
			if sz, ok := arrays[name]; ok {
				idx, _ := strconv.Atoi(idxText)
				if idx < 0 || idx >= sz {
					finds = append(finds, finding{path, ln, mi[0] + 1, "error", "arrayIndexOutOfBounds", fmt.Sprintf("Array '%s[%d]' accessed at index %d, which is out of bounds.", name, sz, idx)})
				}
			}
		}
		for _, m := range ptrDecl.FindAllStringSubmatch(code, -1) {
			ptrNull[m[1]] = ln
		}
		for name := range ptrNull {
			if strings.Contains(code, "*"+name) && !strings.Contains(code, "*"+name+" = NULL") && ln != ptrNull[name] {
				finds = append(finds, finding{path, ln, col(line, "*"+name), "error", "nullPointer", "Null pointer dereference: " + name})
			}
		}
		if strings.Contains(code, "/ 0") || strings.Contains(code, "/0") || strings.Contains(code, "%0") || strings.Contains(code, "% 0") {
			finds = append(finds, finding{path, ln, 1, "error", "zerodiv", "Division by zero."})
		}
		if strings.Contains(code, "gets(") {
			finds = append(finds, finding{path, ln, col(line, "gets"), "warning", "getsCalled", "Obsolete function 'gets' called. It is recommended to use 'fgets' or 'gets_s' instead."})
		}
		for _, m := range mallocRe.FindAllStringSubmatch(code, -1) {
			mallocs[m[1]] = ln
		}
		for name := range mallocs {
			if strings.Contains(code, "free("+name+")") || strings.Contains(code, "delete "+name) || strings.Contains(code, "delete[] "+name) {
				delete(mallocs, name)
			}
		}
		for _, m := range varDecl.FindAllStringSubmatch(code, -1) {
			vars[m[1]] = ln
		}
		for name := range vars {
			if strings.Count(code, name) > 0 && ln != vars[name] {
				used[name] = true
			}
		}
	}
	if opt.enableStyle || opt.enableAll {
		for name, ln := range vars {
			if !used[name] && name != "main" {
				finds = append(finds, finding{path, ln, 1, "style", "unusedVariable", fmt.Sprintf("Variable '%s' is not assigned a value.", name)})
			}
		}
	}
	for name, ln := range mallocs {
		finds = append(finds, finding{path, ln, 1, "error", "memleak", fmt.Sprintf("Memory leak: %s", name)})
	}
	sort.SliceStable(finds, func(i, j int) bool {
		if finds[i].Line == finds[j].Line {
			return finds[i].ID < finds[j].ID
		}
		return finds[i].Line < finds[j].Line
	})
	return finds
}

func stripComments(s string) string {
	if idx := strings.Index(s, "//"); idx >= 0 {
		return s[:idx]
	}
	return s
}

func col(s, sub string) int {
	if idx := strings.Index(s, sub); idx >= 0 {
		return idx + 1
	}
	return 1
}

func insideAny(start, end int, spans [][]int) bool {
	for _, sp := range spans {
		if start >= sp[0] && end <= sp[1] {
			return true
		}
	}
	return false
}

func formatFinding(f finding, tmpl string) string {
	switch tmpl {
	case "cppcheck1":
		return fmt.Sprintf("[%s:%d]: (%s) %s", f.File, f.Line, f.Severity, f.Message)
	case "vs":
		return fmt.Sprintf("%s(%d): %s: %s [%s]", f.File, f.Line, f.Severity, f.Message, f.ID)
	case "edit":
		return fmt.Sprintf("%s +%d: %s: %s [%s]", f.File, f.Line, f.Severity, f.Message, f.ID)
	case "", "gcc":
		return fmt.Sprintf("%s:%d:%d: %s: %s [%s]", f.File, f.Line, f.Column, f.Severity, f.Message, f.ID)
	default:
		r := strings.NewReplacer("{file}", f.File, "{line}", strconv.Itoa(f.Line), "{column}", strconv.Itoa(f.Column), "{severity}", f.Severity, "{message}", f.Message, "{id}", f.ID, "\\n", "\n", "\\t", "\t", "\\r", "\r")
		return r.Replace(tmpl)
	}
}

func applySuppressions(in []finding, specs []string) []finding {
	if len(specs) == 0 {
		return in
	}
	var out []finding
	for _, f := range in {
		sup := false
		for _, s := range specs {
			parts := strings.Split(s, ":")
			id := parts[0]
			if id != "*" && id != f.ID {
				continue
			}
			if len(parts) > 1 && parts[1] != "" && !strings.Contains(f.File, parts[1]) {
				continue
			}
			if len(parts) > 2 && parts[2] != "" {
				n, _ := strconv.Atoi(parts[2])
				if n != f.Line {
					continue
				}
			}
			sup = true
		}
		if !sup {
			out = append(out, f)
		}
	}
	return out
}

func readList(path string) []string {
	if path == "-" {
		return nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	var out []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		t := strings.TrimSpace(sc.Text())
		if t != "" {
			out = append(out, t)
		}
	}
	return out
}

func readSuppressions(path string) []string {
	return readList(path)
}

func preprocess(path string, out io.Writer) {
	data, err := os.ReadFile(path)
	if err == nil {
		fmt.Fprint(out, string(data))
	}
}

func printErrorList(w io.Writer) {
	fmt.Fprintf(w, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<results version=\"2\">\n    <cppcheck version=\"2.19 dev\"/>\n    <errors>")
	for _, e := range []finding{
		{ID: "arrayIndexOutOfBounds", Severity: "error", Message: "Array 'arr[16]' accessed at index 16, which is out of bounds."},
		{ID: "zerodiv", Severity: "error", Message: "Division by zero."},
		{ID: "nullPointer", Severity: "error", Message: "Null pointer dereference."},
		{ID: "memleak", Severity: "error", Message: "Memory leak."},
		{ID: "unusedVariable", Severity: "style", Message: "Variable is not assigned a value."},
		{ID: "getsCalled", Severity: "warning", Message: "Obsolete function 'gets' called."},
	} {
		fmt.Fprintf(w, "        <error id=\"%s\" severity=\"%s\" msg=\"%s\" verbose=\"%s\"/>\n", e.ID, e.Severity, xmlEscape(e.Message), xmlEscape(e.Message))
	}
	fmt.Fprint(w, "    </errors>\n</results>\n")
}

func printXML(w io.Writer, finds []finding) {
	fmt.Fprintln(w, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
	fmt.Fprintln(w, "<results version=\"2\">")
	fmt.Fprintln(w, "    <cppcheck version=\"2.19 dev\"/>")
	fmt.Fprintln(w, "    <errors>")
	for _, f := range finds {
		fmt.Fprintf(w, "        <error id=\"%s\" severity=\"%s\" msg=\"%s\" verbose=\"%s\">\n", f.ID, f.Severity, xmlEscape(f.Message), xmlEscape(f.Message))
		fmt.Fprintf(w, "            <location file=\"%s\" line=\"%d\" column=\"%d\"/>\n", xmlEscape(f.File), f.Line, f.Column)
		fmt.Fprintln(w, "        </error>")
	}
	fmt.Fprintln(w, "    </errors>")
	fmt.Fprintln(w, "</results>")
}

func printSarif(w io.Writer, finds []finding) {
	fmt.Fprint(w, `{"version":"2.1.0","runs":[{"tool":{"driver":{"name":"Cppcheck","version":"2.19 dev"}},"results":[`)
	for i, f := range finds {
		if i > 0 {
			fmt.Fprint(w, ",")
		}
		fmt.Fprintf(w, `{"ruleId":%q,"level":%q,"message":{"text":%q},"locations":[{"physicalLocation":{"artifactLocation":{"uri":%q},"region":{"startLine":%d,"startColumn":%d}}}]}`, f.ID, f.Severity, f.Message, f.File, f.Line, f.Column)
	}
	fmt.Fprintln(w, `]}]}`)
}

func xmlEscape(s string) string {
	var b strings.Builder
	_ = xml.EscapeText(&b, []byte(s))
	return b.String()
}
