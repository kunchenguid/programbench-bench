module gittrim

go 1.21
