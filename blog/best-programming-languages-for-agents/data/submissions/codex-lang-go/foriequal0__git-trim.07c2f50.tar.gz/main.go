package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const longHelp = "Automatically trims your tracking branches whose upstream branches are merged or stray.\n" +
	"`git-trim` is a missing companion to the `git fetch --prune` and a proper, safer, faster alternative to your `<bash oneliner HERE>`.\n\n" +
	"Usage: executable [OPTIONS]\n\n" +
	"Options:\n" +
	"  -b, --bases <BASES>\n" +
	"          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]\n" +
	"          \n" +
	"          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.\n\n" +
	"  -p, --protected <PROTECTED>\n" +
	"          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]\n\n" +
	"      --no-update\n" +
	"          Do not update remotes [config: trim.update]\n\n" +
	"      --update-interval <UPDATE_INTERVAL>\n" +
	"          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]\n\n" +
	"      --no-confirm\n" +
	"          Do not ask confirm [config: trim.confirm]\n\n" +
	"      --no-detach\n" +
	"          Do not detach when HEAD is about to be deleted [config: trim.detach]\n\n" +
	"  -d, --delete <DELETE>\n" +
	"          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]\n" +
	"          \n" +
	"          `merged` implies `merged-local,merged-remote`.\n" +
	"          \n" +
	"          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.\n\n" +
	"      --dry-run\n" +
	"          Do not delete branches, show what branches will be deleted\n\n" +
	"  -h, --help\n" +
	"          Print help (see a summary with '-h')\n\n" +
	"  -V, --version\n" +
	"          Print version\n"

const shortHelp = "Automatically trims your tracking branches whose upstream branches are merged or stray.\n\n" +
	"Usage: executable [OPTIONS]\n\n" +
	"Options:\n" +
	"  -b, --bases <BASES>\n          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]\n" +
	"  -p, --protected <PROTECTED>\n          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]\n" +
	"      --no-update\n          Do not update remotes [config: trim.update]\n" +
	"      --update-interval <UPDATE_INTERVAL>\n          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]\n" +
	"      --no-confirm\n          Do not ask confirm [config: trim.confirm]\n" +
	"      --no-detach\n          Do not detach when HEAD is about to be deleted [config: trim.detach]\n" +
	"  -d, --delete <DELETE>\n          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]\n" +
	"      --dry-run\n          Do not delete branches, show what branches will be deleted\n" +
	"  -h, --help\n          Print help (see more with '--help')\n" +
	"  -V, --version\n          Print version\n"

type options struct {
	bases          []string
	protected      []string
	deleteSpec     string
	dryRun         bool
	update         bool
	noConfirm      bool
	noDetach       bool
	updateInterval int
}

type branch struct {
	name     string
	sha      string
	upstream string
	remote   bool
}

type decision struct {
	br          branch
	action      string
	reason      string
	protectedBy string
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func run() error {
	opt, done, err := parseArgs(os.Args[1:])
	if done || err != nil {
		return err
	}
	if opt.update {
		_ = gitRun("fetch", "--prune")
	}
	if gitRun("rev-parse", "--git-dir") != nil {
		return errors.New("could not find repository at '.'; class=Repository (6); code=NotFound (-3)")
	}
	remotes, err := lines(gitOut("remote"))
	if err != nil || len(remotes) == 0 {
		return errors.New("git-trim requires at least one remote")
	}
	locals, rems, err := readBranches()
	if err != nil {
		return err
	}
	bases := findBases(opt, locals, rems)
	if len(bases) == 0 {
		printBaseHelp()
		return errors.New("No base branch is found!")
	}
	del := parseDelete(opt.deleteSpec)
	localDec, remoteDec := classify(locals, rems, bases, del, opt.protected)
	printReport(localDec, remoteDec)
	if hasActions(localDec) || hasActions(remoteDec) {
		if !opt.dryRun && !opt.noConfirm {
			return errors.New("IO error: not a terminal\n\nCaused by:\n    not a terminal")
		}
		applyDeletes(localDec, remoteDec, opt.dryRun, opt.noDetach)
	}
	return nil
}

func parseArgs(args []string) (options, bool, error) {
	opt := options{update: true, updateInterval: 5}
	opt.deleteSpec = firstConfig("trim.delete", "merged:origin")
	if v := firstConfig("trim.bases", ""); v != "" {
		opt.bases = splitCSV(v)
	}
	if v := firstConfig("trim.protected", ""); v != "" {
		opt.protected = splitCSV(v)
	}
	if v := firstConfig("trim.update", ""); v != "" {
		opt.update = parseBool(v, true)
	}
	if v := firstConfig("trim.confirm", ""); v != "" {
		opt.noConfirm = !parseBool(v, true)
	}
	if v := firstConfig("trim.detach", ""); v != "" {
		opt.noDetach = !parseBool(v, true)
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("a value is required for '%s' but none was supplied", a)
			}
			i++
			return args[i], nil
		}
		switch {
		case a == "-h":
			fmt.Print(shortHelp)
			return opt, true, nil
		case a == "--help":
			fmt.Print(longHelp)
			return opt, true, nil
		case a == "-V" || a == "--version":
			fmt.Println("git-trim 0.4.4")
			return opt, true, nil
		case a == "-b" || a == "--bases":
			v, e := next()
			if e != nil {
				return opt, false, e
			}
			opt.bases = splitCSV(v)
		case strings.HasPrefix(a, "--bases="):
			opt.bases = splitCSV(strings.TrimPrefix(a, "--bases="))
		case a == "-p" || a == "--protected":
			v, e := next()
			if e != nil {
				return opt, false, e
			}
			opt.protected = splitCSV(v)
		case strings.HasPrefix(a, "--protected="):
			opt.protected = splitCSV(strings.TrimPrefix(a, "--protected="))
		case a == "-d" || a == "--delete":
			v, e := next()
			if e != nil {
				return opt, false, e
			}
			opt.deleteSpec = v
		case strings.HasPrefix(a, "--delete="):
			opt.deleteSpec = strings.TrimPrefix(a, "--delete=")
		case a == "--dry-run":
			opt.dryRun = true
		case a == "--no-update":
			opt.update = false
		case a == "--update":
			opt.update = true
		case a == "--no-confirm":
			opt.noConfirm = true
		case a == "--confirm":
			opt.noConfirm = false
		case a == "--no-detach":
			opt.noDetach = true
		case a == "--detach":
			opt.noDetach = false
		case a == "--update-interval":
			v, e := next()
			if e != nil {
				return opt, false, e
			}
			n, _ := strconv.Atoi(v)
			opt.updateInterval = n
		case strings.HasPrefix(a, "--update-interval="):
			n, _ := strconv.Atoi(strings.TrimPrefix(a, "--update-interval="))
			opt.updateInterval = n
		default:
			return opt, false, fmt.Errorf("unexpected argument '%s' found", a)
		}
	}
	return opt, false, nil
}

func firstConfig(key, def string) string {
	out, err := gitOut("config", "--get", key)
	if err != nil {
		return def
	}
	return strings.TrimSpace(out)
}

func readBranches() ([]branch, []branch, error) {
	out, err := gitOut("for-each-ref", "--format=%(refname:short)%00%(objectname)%00%(upstream:short)", "refs/heads", "refs/remotes")
	if err != nil {
		return nil, nil, err
	}
	var locals, rems []branch
	sc := bufio.NewScanner(strings.NewReader(out))
	for sc.Scan() {
		p := strings.Split(sc.Text(), "\x00")
		if len(p) < 2 || strings.HasSuffix(p[0], "/HEAD") {
			continue
		}
		b := branch{name: p[0], sha: p[1]}
		if len(p) > 2 {
			b.upstream = p[2]
		}
		if strings.HasPrefix(b.name, "refs/remotes/") || strings.Count(b.name, "/") > 0 && hasRemotePrefix(b.name) {
			b.remote = true
			rems = append(rems, b)
		} else {
			locals = append(locals, b)
		}
	}
	sort.Slice(locals, func(i, j int) bool { return locals[i].name < locals[j].name })
	sort.Slice(rems, func(i, j int) bool { return rems[i].name < rems[j].name })
	return locals, rems, nil
}

func hasRemotePrefix(name string) bool {
	remote := strings.SplitN(name, "/", 2)[0]
	out, err := gitOut("remote")
	if err != nil {
		return false
	}
	for _, r := range splitLines(out) {
		if r == remote {
			return true
		}
	}
	return false
}

func findBases(opt options, locals, rems []branch) map[string]bool {
	base := map[string]bool{}
	if len(opt.bases) > 0 {
		for _, b := range opt.bases {
			base[b] = true
			for _, l := range locals {
				if l.name == b || l.upstream == b || l.upstream == "origin/"+b {
					base[l.name] = true
				}
			}
			for _, r := range rems {
				if r.name == b || strings.HasSuffix(r.name, "/"+b) {
					base[r.name] = true
				}
			}
		}
		return base
	}
	for _, r := range remoteHeads() {
		for _, l := range locals {
			if l.upstream == r {
				base[l.name] = true
			}
		}
		for _, rr := range rems {
			if rr.name == r {
				base[rr.name] = true
			}
		}
	}
	return base
}

func remoteHeads() []string {
	out, _ := gitOut("for-each-ref", "--format=%(refname:short) %(symref:short)", "refs/remotes")
	var hs []string
	for _, l := range splitLines(out) {
		f := strings.Fields(l)
		if len(f) == 2 && strings.HasSuffix(f[0], "/HEAD") {
			hs = append(hs, f[1])
		}
	}
	return hs
}

type delSpec struct {
	mergedLocal  bool
	stray        bool
	local        bool
	mergedRemote map[string]bool
	remote       map[string]bool
	diverged     map[string]bool
}

func parseDelete(s string) delSpec {
	d := delSpec{mergedRemote: map[string]bool{}, remote: map[string]bool{}, diverged: map[string]bool{}}
	for _, part := range splitCSV(s) {
		rng, rem := part, "origin"
		if strings.Contains(part, ":") {
			x := strings.SplitN(part, ":", 2)
			rng, rem = x[0], x[1]
		}
		switch rng {
		case "merged":
			d.mergedLocal = true
			d.mergedRemote[rem] = true
		case "merged-local":
			d.mergedLocal = true
		case "merged-remote":
			d.mergedRemote[rem] = true
		case "stray":
			d.stray = true
		case "local":
			d.local = true
		case "remote":
			d.remote[rem] = true
		case "diverged":
			d.diverged[rem] = true
			d.mergedLocal = true
			d.mergedRemote[rem] = true
		}
	}
	return d
}

func classify(locals, rems []branch, bases map[string]bool, del delSpec, prot []string) ([]decision, []decision) {
	upstreamUsed := map[string]bool{}
	var lds, rds []decision
	onlyLocal := del.local && !del.mergedLocal && !del.stray && len(del.mergedRemote) == 0 && len(del.remote) == 0 && len(del.diverged) == 0
	for _, l := range locals {
		if l.upstream != "" {
			upstreamUsed[l.upstream] = true
		}
		dec := decision{br: l}
		if bases[l.name] {
			dec.reason = "base"
		} else if p := protected(l.name, prot); p != "" {
			dec.protectedBy = p
		}
		lds = append(lds, dec)
	}
	for i := range lds {
		l := lds[i].br
		if onlyLocal && l.upstream != "" {
			lds[i].reason = "*1"
			continue
		}
		if lds[i].reason == "base" {
			continue
		}
		if l.upstream != "" && !refExists("refs/remotes/"+l.upstream) {
			if lds[i].protectedBy != "" {
				lds[i].reason = "stray, but: protected by a pattern `" + lds[i].protectedBy + "`"
			} else if del.stray {
				lds[i].action = "stray-local"
			} else {
				lds[i].reason = "stray, but: delete range `stray` was not given"
			}
			continue
		}
		if isMergedIntoAny(l.sha, bases) {
			if l.upstream == "" {
				if lds[i].protectedBy != "" {
					lds[i].reason = "merged non-tracking, but: protected by a pattern `" + lds[i].protectedBy + "`"
				} else if del.local {
					lds[i].action = "merged-local-nontracking"
				} else {
					lds[i].reason = "*2"
				}
			} else {
				if lds[i].protectedBy != "" {
					lds[i].reason = "merged, but: protected by a pattern `" + lds[i].protectedBy + "`"
				} else if del.mergedLocal {
					lds[i].action = "merged-local"
				} else {
					lds[i].reason = "merged, but: delete range `merged-local` was not given"
				}
			}
		} else if l.upstream == "" {
			lds[i].reason = "*2"
		} else {
			lds[i].reason = ""
		}
	}
	for _, r := range rems {
		dec := decision{br: r}
		remote := strings.SplitN(r.name, "/", 2)[0]
		if onlyLocal {
			dec.reason = "*1"
			rds = append(rds, dec)
			continue
		} else if bases[r.name] {
			dec.reason = "base"
		} else if p := protected(r.name, prot); p != "" {
			dec.protectedBy = p
		}
		if dec.reason == "" {
			merged := isMergedIntoAny(r.sha, bases)
			if merged {
				if dec.protectedBy != "" {
					dec.reason = "merged, but: protected by a pattern `" + dec.protectedBy + "`"
				} else if del.mergedRemote[remote] || del.mergedRemote["*"] {
					dec.action = "merged-remote"
				} else {
					dec.reason = "merged, but: delete range `merged-remote:" + remote + "` was not given"
				}
			} else if !upstreamUsed[r.name] {
				if del.remote[remote] || del.remote["*"] {
					dec.action = "remote"
				} else {
					dec.reason = ""
				}
			} else {
				dec.reason = ""
			}
		}
		rds = append(rds, dec)
	}
	return lds, rds
}

func isMergedIntoAny(sha string, bases map[string]bool) bool {
	for b := range bases {
		if refExists(b) && gitRun("merge-base", "--is-ancestor", sha, b) == nil {
			return true
		}
	}
	return false
}

func refExists(ref string) bool {
	return gitRun("rev-parse", "--verify", "--quiet", ref) == nil
}

func printReport(localDec, remoteDec []decision) {
	fmt.Println("Branches that will remain:")
	fmt.Println("  local branches:")
	for _, d := range localDec {
		if d.action == "" {
			fmt.Printf("    %s", d.br.name)
			if d.reason != "" {
				fmt.Printf(" [%s]", d.reason)
			}
			fmt.Println()
		}
	}
	fmt.Println("  remote references:")
	for _, d := range remoteDec {
		if d.action == "" {
			fmt.Printf("    %s", d.br.name)
			if d.reason != "" {
				fmt.Printf(" [%s]", d.reason)
			}
			fmt.Println()
		}
	}
	if hasReason(localDec, "*1") || hasReason(remoteDec, "*1") || hasReason(localDec, "*2") {
		fmt.Println("  Some branches are skipped. Consider following to scan them:")
		if hasReason(localDec, "*1") || hasReason(remoteDec, "*1") {
			fmt.Println("    *1: Add `--delete 'merged:*'` flag.")
		}
		if hasReason(localDec, "*2") {
			fmt.Println("    *2: Set an upstream to make it a tracking branch or add `--delete 'local'` flag.")
		}
	}
	fmt.Println()
	printActionGroup(localDec, "merged-local", "Delete merged local branches:", false)
	printActionGroup(localDec, "merged-local-nontracking", "Delete merged local branches:", true)
	printActionGroup(localDec, "stray-local", "Delete stray local branches:", false)
	printRemoteGroup(remoteDec, "merged-remote", "Delete merged remote refs:")
	printRemoteGroup(remoteDec, "remote", "Delete remote refs:")
}

func printActionGroup(ds []decision, action, title string, nontracking bool) {
	var xs []decision
	for _, d := range ds {
		if d.action == action {
			xs = append(xs, d)
		}
	}
	if len(xs) == 0 {
		return
	}
	fmt.Println(title)
	for _, d := range xs {
		if nontracking {
			fmt.Printf("  - %s (non-tracking)\n", d.br.name)
		} else {
			fmt.Printf("  - %s\n", d.br.name)
		}
	}
}

func printRemoteGroup(ds []decision, action, title string) {
	var xs []decision
	for _, d := range ds {
		if d.action == action {
			xs = append(xs, d)
		}
	}
	if len(xs) == 0 {
		return
	}
	fmt.Println(title)
	for _, d := range xs {
		parts := strings.SplitN(d.br.name, "/", 2)
		if len(parts) == 2 {
			fmt.Printf("  - %s, refs/heads/%s\n", parts[0], parts[1])
		}
	}
}

func applyDeletes(localDec, remoteDec []decision, dry bool, noDetach bool) {
	for _, d := range remoteDec {
		if d.action == "merged-remote" || d.action == "remote" {
			p := strings.SplitN(d.br.name, "/", 2)
			if len(p) == 2 {
				args := []string{"push"}
				if dry {
					args = append(args, "--dry-run")
				}
				args = append(args, p[0], "--delete", p[1])
				_ = gitRunInherit(args...)
			}
		}
	}
	for _, d := range localDec {
		if strings.HasPrefix(d.action, "merged-local") || d.action == "stray-local" {
			if currentBranch() == d.br.name && !noDetach {
				if dry {
					fmt.Printf("Note: switching to 'refs/heads/%s' (dry run)\n", d.br.name)
					fmt.Println("You are in 'detached HED' state... blah blah...")
					fmt.Printf("HEAD is now at %s %s (dry run)\n", shortSHA(d.br.sha), subject(d.br.name))
				} else {
					_ = gitRunInherit("checkout", "refs/heads/"+d.br.name)
				}
			}
			if dry {
				fmt.Printf("Delete branch %s (dry run).\n", d.br.name)
			} else {
				_ = gitRunInherit("branch", "-d", d.br.name)
			}
		}
	}
}

func currentBranch() string {
	out, err := gitOut("symbolic-ref", "--quiet", "--short", "HEAD")
	if err != nil {
		return ""
	}
	return strings.TrimSpace(out)
}

func shortSHA(s string) string {
	if len(s) > 7 {
		return s[:7]
	}
	return s
}

func subject(ref string) string {
	out, err := gitOut("log", "-1", "--format=%s", ref)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(out)
}

func hasActions(ds ...[]decision) bool {
	for _, list := range ds {
		for _, d := range list {
			if d.action != "" {
				return true
			}
		}
	}
	return false
}

func hasReason(ds []decision, r string) bool {
	for _, d := range ds {
		if d.reason == r {
			return true
		}
	}
	return false
}

func protected(name string, pats []string) string {
	for _, p := range pats {
		if ok, _ := filepath.Match(p, name); ok {
			return p
		}
	}
	return ""
}

func printBaseHelp() {
	fmt.Println("I can't detect base branch! Try following any resolution:")
	fmt.Println(" * `git remote set-head origin --auto` will help `git-trim` to automatically")
	fmt.Println("   detect the base branch.")
	fmt.Println("   If you see `origin/HEAD set to <base branch>` in the output of the previous")
	fmt.Println("   command, then `git branch --set-upstream origin/<base branch> <base branch>`")
	fmt.Println("   to set an upstream branch for <base branch> if exists.")
	fmt.Println("You also can set bases manually with any of following commands:")
	fmt.Println(" * `git config trim.bases develop,master` for a repository.")
	fmt.Println(" * `git config --global trim.bases develop,master` to set globally.")
	fmt.Println(" * `git trim --bases develop,master` to set temporarily.")
}

func gitOut(args ...string) (string, error) {
	cmd := exec.Command("git", args...)
	var out, er bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &er
	err := cmd.Run()
	if err != nil {
		if er.Len() > 0 {
			return out.String(), errors.New(strings.TrimSpace(er.String()))
		}
		return out.String(), err
	}
	return out.String(), nil
}

func gitRun(args ...string) error {
	cmd := exec.Command("git", args...)
	return cmd.Run()
}

func gitRunInherit(args ...string) error {
	cmd := exec.Command("git", args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Stdin = os.Stdin
	return cmd.Run()
}

func lines(s string, err error) ([]string, error) {
	if err != nil {
		return nil, err
	}
	return splitLines(s), nil
}

func splitLines(s string) []string {
	var r []string
	for _, l := range strings.Split(strings.TrimSpace(s), "\n") {
		l = strings.TrimSpace(l)
		if l != "" {
			r = append(r, l)
		}
	}
	return r
}

func splitCSV(s string) []string {
	var r []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			r = append(r, p)
		}
	}
	return r
}

func parseBool(s string, def bool) bool {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "true", "yes", "on", "1":
		return true
	case "false", "no", "off", "0":
		return false
	}
	return def
}
