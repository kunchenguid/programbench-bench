package main

import (
	"errors"
	"fmt"
	"io/fs"
	"os"
	"os/user"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const version = "pls 0.0.1-beta.9"

var longHelp = `pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing "_" reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
`

var shortHelp = `pls is a prettier and powerful ls(1) for the pros.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

Detail view:
  -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:
                         dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
                         btime, ctime, mtime, atime, git, none, std, all]
  -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,
                         false]
  -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible
                         values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,
                     false]
  -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]

Presentation:
  -i, --icon <ICON>          display icons next to node names [default: true] [possible values:
                             true, false]
  -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]
                             [possible values: true, false]
  -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]
  -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:
                             true] [possible values: true, false]
  -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible
                             values: true, false]

Filtering:
  -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible
                           values: dir, symlink, fifo, socket, block-device, char-device, file,
                           none, all]
  -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]
  -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output
  -o, --only <ONLY>        the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>  the set of fields to sort by, trailing "_" reverses the direction
                           [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,
                           uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,
                           ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,
                           blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
`

type config struct {
	details []string
	header  bool
	unit    string
	icon    bool
	suffix  bool
	sym     bool
	align   bool
	types   map[string]bool
	sortBy  []string
	paths   []string
}

type node struct {
	path string
	name string
	info fs.FileInfo
	st   *syscall.Stat_t
	typ  string
	link string
}

func main() {
	cfg, exit, code := parse(os.Args[1:])
	if exit {
		os.Exit(code)
	}
	hadErr := false
	multi := len(cfg.paths) > 1
	for i, p := range cfg.paths {
		nodes, isDir, err := collect(p, cfg)
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s:\n\terror: %s\n", p, displayErr(err))
			hadErr = true
			continue
		}
		if multi {
			if i > 0 {
				fmt.Println()
			}
			if isDir {
				fmt.Printf("%s:\n", p)
			}
		}
		printNodes(nodes, cfg)
	}
	if hadErr {
		os.Exit(1)
	}
}

func parse(args []string) (config, bool, int) {
	cfg := config{
		header: true, unit: "binary", icon: true, suffix: true, sym: true, align: true,
		types: map[string]bool{"all": true}, sortBy: []string{"cat", "cname"},
	}
	validDet := set("dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all")
	validTyp := set("dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all")
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			cfg.paths = append(cfg.paths, args[i+1:]...)
			break
		}
		if a == "-h" {
			fmt.Print(shortHelp)
			return cfg, true, 0
		}
		if a == "--help" {
			fmt.Print(longHelp)
			return cfg, true, 0
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return cfg, true, 0
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			key := a
			val := ""
			if strings.Contains(a, "=") {
				parts := strings.SplitN(a, "=", 2)
				key, val = parts[0], parts[1]
			}
			need := func() string {
				if val != "" || strings.Contains(a, "=") {
					return val
				}
				if i+1 >= len(args) {
					usageErr(fmt.Sprintf("a value is required for '%s <VALUE>' but none was supplied", key))
					os.Exit(2)
				}
				i++
				return args[i]
			}
			switch key {
			case "-d", "--det":
				v := need()
				if !validDet[v] {
					invalid("--det <DETAILS>", v, "dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks, btime, ctime, mtime, atime, git, none, std, all")
				}
				if v == "none" {
					cfg.details = nil
				} else if v == "std" {
					cfg.details = append(cfg.details, "nlink", "typ", "perm", "user", "group", "size", "mtime")
				} else if v == "all" {
					cfg.details = []string{"dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid", "size", "blocks", "btime", "ctime", "mtime", "atime", "git"}
				} else {
					cfg.details = append(cfg.details, v)
				}
			case "-H", "--header":
				cfg.header = parseBool(need(), key)
			case "-u", "--unit":
				cfg.unit = need()
			case "-g", "--grid", "-D", "--down", "-c", "--collapse":
				_ = parseBool(need(), key)
			case "-i", "--icon":
				cfg.icon = parseBool(need(), key)
			case "-S", "--suffix":
				cfg.suffix = parseBool(need(), key)
			case "-l", "--sym":
				cfg.sym = parseBool(need(), key)
			case "-a", "--align":
				cfg.align = parseBool(need(), key)
			case "-t", "--typ":
				v := need()
				if !validTyp[v] {
					invalid("--typ <TYPES>", v, "dir, symlink, fifo, socket, block-device, char-device, file, none, all")
				}
				if cfg.types["all"] {
					cfg.types = map[string]bool{}
				}
				cfg.types[v] = true
			case "-I", "--imp", "-e", "--exclude", "-o", "--only":
				_ = need()
			case "-s", "--sort":
				v := need()
				if v == "none" {
					cfg.sortBy = nil
				} else {
					cfg.sortBy = append(cfg.sortBy[:0], v)
				}
			default:
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n", a, a, a)
				return cfg, true, 2
			}
		} else {
			cfg.paths = append(cfg.paths, a)
		}
	}
	if len(cfg.paths) == 0 {
		cfg.paths = []string{"."}
	}
	return cfg, false, 0
}

func usageErr(s string) {
	fmt.Fprintf(os.Stderr, "error: %s\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n", s)
}

func displayErr(err error) string {
	if os.IsNotExist(err) {
		return "No such file or directory (os error 2)"
	}
	if os.IsPermission(err) {
		return "Permission denied (os error 13)"
	}
	return err.Error()
}

func invalid(opt, val, possible string) {
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s'\n  [possible values: %s]\n\nFor more information, try '--help'.\n", val, opt, possible)
	os.Exit(2)
}

func parseBool(v, key string) bool {
	if v == "true" {
		return true
	}
	if v == "false" {
		return false
	}
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s <BOOL>'\n  [possible values: true, false]\n\nFor more information, try '--help'.\n", v, key)
	os.Exit(2)
	return false
}

func set(vals ...string) map[string]bool {
	m := map[string]bool{}
	for _, v := range vals {
		m[v] = true
	}
	return m
}

func collect(path string, cfg config) ([]node, bool, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, false, err
	}
	if !info.IsDir() {
		n := makeNode(path, path, info)
		if include(n, cfg) {
			return []node{n}, false, nil
		}
		return nil, false, nil
	}
	ents, err := os.ReadDir(path)
	if err != nil {
		return nil, true, err
	}
	nodes := []node{}
	for _, e := range ents {
		p := filepath.Join(path, e.Name())
		inf, err := os.Lstat(p)
		if err != nil {
			continue
		}
		n := makeNode(p, e.Name(), inf)
		if include(n, cfg) {
			nodes = append(nodes, n)
		}
	}
	sortNodes(nodes, cfg)
	return nodes, true, nil
}

func makeNode(path, name string, info fs.FileInfo) node {
	n := node{path: path, name: name, info: info, typ: typeOf(info)}
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		n.st = st
	}
	if n.typ == "symlink" {
		if l, err := os.Readlink(path); err == nil {
			n.link = l
		}
	}
	return n
}

func include(n node, cfg config) bool {
	if cfg.types["none"] {
		return false
	}
	return cfg.types["all"] || cfg.types[n.typ]
}

func typeOf(info fs.FileInfo) string {
	m := info.Mode()
	switch {
	case m.IsDir():
		return "dir"
	case m&os.ModeSymlink != 0:
		return "symlink"
	case m&os.ModeNamedPipe != 0:
		return "fifo"
	case m&os.ModeSocket != 0:
		return "socket"
	case m&os.ModeDevice != 0 && m&os.ModeCharDevice != 0:
		return "char-device"
	case m&os.ModeDevice != 0:
		return "block-device"
	default:
		return "file"
	}
}

func sortNodes(nodes []node, cfg config) {
	sort.SliceStable(nodes, func(i, j int) bool {
		a, b := nodes[i], nodes[j]
		keys := cfg.sortBy
		if len(keys) == 0 {
			return false
		}
		for _, k := range keys {
			rev := strings.HasSuffix(k, "_")
			k = strings.TrimSuffix(k, "_")
			cmp := compare(a, b, k)
			if cmp != 0 {
				if rev {
					return cmp > 0
				}
				return cmp < 0
			}
		}
		return false
	})
}

func compare(a, b node, key string) int {
	switch key {
	case "cat":
		return intCmp(cat(a), cat(b))
	case "name":
		return strings.Compare(a.name, b.name)
	case "cname":
		return strings.Compare(cleanName(a.name), cleanName(b.name))
	case "ext":
		return strings.Compare(filepath.Ext(a.name), filepath.Ext(b.name))
	case "size":
		return int64Cmp(a.info.Size(), b.info.Size())
	case "mtime":
		return int64Cmp(a.info.ModTime().UnixNano(), b.info.ModTime().UnixNano())
	case "typ":
		return strings.Compare(typeLetter(a), typeLetter(b))
	case "ino", "inode":
		return uint64Cmp(inode(a), inode(b))
	case "nlink", "nlinks":
		return uint64Cmp(uint64(nlink(a)), uint64(nlink(b)))
	}
	return strings.Compare(cleanName(a.name), cleanName(b.name))
}

func cat(n node) int {
	if n.typ == "dir" {
		return 0
	}
	return 1
}

func cleanName(s string) string {
	return strings.ToLower(strings.TrimLeft(s, "."))
}

func intCmp(a, b int) int {
	if a < b {
		return -1
	}
	if a > b {
		return 1
	}
	return 0
}
func int64Cmp(a, b int64) int {
	if a < b {
		return -1
	}
	if a > b {
		return 1
	}
	return 0
}
func uint64Cmp(a, b uint64) int {
	if a < b {
		return -1
	}
	if a > b {
		return 1
	}
	return 0
}

func printNodes(nodes []node, cfg config) {
	if len(cfg.details) == 0 {
		for _, n := range nodes {
			fmt.Println(displayName(n, cfg))
		}
		return
	}
	rows := [][]string{}
	headers := []string{}
	for _, d := range cfg.details {
		headers = append(headers, header(d))
	}
	headers = append(headers, "Name")
	if cfg.header {
		rows = append(rows, headers)
	}
	for _, n := range nodes {
		row := []string{}
		for _, d := range cfg.details {
			row = append(row, detail(n, d, cfg))
		}
		row = append(row, displayName(n, cfg))
		rows = append(rows, row)
	}
	widths := make([]int, len(headers))
	right := map[int]bool{}
	for i, d := range cfg.details {
		if d == "dev" || d == "ino" || d == "nlink" || d == "uid" || d == "gid" || d == "size" || d == "blocks" || d == "oct" {
			right[i] = true
		}
	}
	for _, r := range rows {
		for i, c := range r {
			if l := len([]rune(c)); l > widths[i] {
				widths[i] = l
			}
		}
	}
	for _, r := range rows {
		for i, c := range r {
			if i > 0 {
				fmt.Print(" ")
			}
			if i == len(r)-1 {
				fmt.Print(c)
				continue
			}
			if right[i] {
				fmt.Printf("%*s", widths[i], c)
			} else {
				fmt.Printf("%-*s", widths[i], c)
			}
		}
		fmt.Println()
	}
}

func header(d string) string {
	switch d {
	case "dev":
		return "Device"
	case "ino":
		return "inode"
	case "nlink":
		return "Link#"
	case "typ":
		return "T"
	case "perm":
		return "Permissions"
	case "oct":
		return "SUGO"
	case "user":
		return "User"
	case "uid":
		return "UID"
	case "group":
		return "Group"
	case "gid":
		return "GID"
	case "size":
		return "Size"
	case "blocks":
		return "Blocks"
	case "btime":
		return "Created"
	case "ctime":
		return "Changed"
	case "mtime":
		return "Modified"
	case "atime":
		return "Accessed"
	case "git":
		return "Git"
	}
	return d
}

func detail(n node, d string, cfg config) string {
	switch d {
	case "dev":
		if n.st != nil {
			return fmt.Sprint(n.st.Dev)
		}
	case "ino":
		return fmt.Sprint(inode(n))
	case "nlink":
		return fmt.Sprint(nlink(n))
	case "typ":
		return typeLetter(n)
	case "perm":
		return permString(n.info.Mode())
	case "oct":
		return fmt.Sprintf("%3o", n.info.Mode().Perm())
	case "user":
		return userName(uid(n))
	case "uid":
		return fmt.Sprint(uid(n))
	case "group":
		return groupName(gid(n))
	case "gid":
		return fmt.Sprint(gid(n))
	case "size":
		if n.typ == "dir" {
			return ""
		}
		return sizeString(n.info.Size(), cfg.unit)
	case "blocks":
		if n.st != nil {
			return fmt.Sprint(n.st.Blocks)
		}
	case "btime", "ctime", "mtime", "atime":
		return timeString(fileTime(n, d))
	case "git":
		return ""
	}
	return ""
}

func inode(n node) uint64 {
	if n.st != nil {
		return n.st.Ino
	}
	return 0
}
func nlink(n node) uint64 {
	if n.st != nil {
		return uint64(n.st.Nlink)
	}
	return 1
}
func uid(n node) uint32 {
	if n.st != nil {
		return n.st.Uid
	}
	return 0
}
func gid(n node) uint32 {
	if n.st != nil {
		return n.st.Gid
	}
	return 0
}

func fileTime(n node, d string) time.Time {
	if n.st == nil {
		return n.info.ModTime()
	}
	switch d {
	case "atime":
		return time.Unix(n.st.Atim.Sec, n.st.Atim.Nsec)
	case "ctime", "btime":
		return time.Unix(n.st.Ctim.Sec, n.st.Ctim.Nsec)
	default:
		return n.info.ModTime()
	}
}

func timeString(t time.Time) string {
	return t.Local().Format("2006-Jan-02 03:04pm")
}

func userName(id uint32) string {
	u, err := user.LookupId(strconv.Itoa(int(id)))
	if err != nil || u.Username == "" {
		return strconv.Itoa(int(id))
	}
	parts := strings.Split(u.Username, "\\")
	return parts[len(parts)-1]
}

func groupName(id uint32) string {
	g, err := user.LookupGroupId(strconv.Itoa(int(id)))
	if err != nil || g.Name == "" {
		return strconv.Itoa(int(id))
	}
	return g.Name
}

func typeLetter(n node) string {
	switch n.typ {
	case "dir":
		return "d"
	case "symlink":
		return "l"
	case "fifo":
		return "p"
	case "socket":
		return "s"
	case "block-device":
		return "b"
	case "char-device":
		return "c"
	default:
		return "f"
	}
}

func permString(m fs.FileMode) string {
	bits := []struct{ r, w, x fs.FileMode }{
		{0400, 0200, 0100}, {0040, 0020, 0010}, {0004, 0002, 0001},
	}
	parts := make([]string, 3)
	for i, p := range bits {
		s := []byte{'-', '-', '-'}
		if m&p.r != 0 {
			s[0] = 'r'
		}
		if m&p.w != 0 {
			s[1] = 'w'
		}
		if m&p.x != 0 {
			s[2] = 'x'
		}
		parts[i] = string(s)
	}
	return strings.Join(parts, " ")
}

func sizeString(sz int64, unit string) string {
	if unit == "none" {
		return fmt.Sprintf("%d B", sz)
	}
	base := float64(1024)
	if unit == "decimal" {
		base = 1000
	}
	units := []string{"B", "K", "M", "G", "T"}
	v := float64(sz)
	u := 0
	for v >= base && u < len(units)-1 {
		v /= base
		u++
	}
	if u == 0 {
		if unit == "decimal" {
			return fmt.Sprintf("%.1f  %s", v, units[u])
		}
		return fmt.Sprintf("%.1f   %s", v, units[u])
	}
	return fmt.Sprintf("%.1f %s", v, units[u])
}

func displayName(n node, cfg config) string {
	name := n.name
	if cfg.suffix {
		switch n.typ {
		case "dir":
			name += "/"
		case "symlink":
			name += "@"
		case "fifo":
			name += "|"
		case "socket":
			name += "="
		}
	}
	if cfg.sym && n.typ == "symlink" && n.link != "" {
		name += " 󰁔 " + n.link
	}
	if cfg.icon {
		sep := " "
		if cfg.align && !strings.HasPrefix(n.name, ".") {
			sep = "  "
		}
		return icon(n) + sep + name
	}
	if cfg.align && !strings.HasPrefix(n.name, ".") {
		return " " + name
	}
	return name
}

func icon(n node) string {
	switch n.typ {
	case "dir":
		return ""
	case "symlink":
		return "󰌹"
	case "fifo":
		return "󰟥"
	}
	if n.info.Mode()&0111 != 0 {
		return ""
	}
	switch filepath.Ext(n.name) {
	case ".md":
		return ""
	case ".txt":
		return ""
	default:
		return " "
	}
}

func (n node) IsZero() bool { return n.info == nil && n.name == "" && n.path == "" }

var _ = errors.New
