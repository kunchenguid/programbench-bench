package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

const version = "1.4.1"

const helpText = `  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
`

const keyText = "┌───────────┬────────────────┐\r\n" +
	"│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│\x1b[36m\x1b[49maction          \x1b[39m\x1b[49m│\r\n" +
	"├───────────┼────────────────┤\r\n" +
	"│Navigate   │← ↑ ↓ →         │\r\n" +
	"│           │h j k l         │\r\n" +
	"│           │Mouse::WheelUp  │\r\n" +
	"│           │Mouse::WheelDown│\r\n" +
	"├───────────┼────────────────┤\r\n" +
	"│Toggle     │enter           │\r\n" +
	"│           │Mouse::Left     │\r\n" +
	"├───────────┼────────────────┤\r\n" +
	"│Deep       │                │\r\n" +
	"│ - Expand  │+               │\r\n" +
	"│ - Collapse│-               │\r\n" +
	"├───────────┼────────────────┤\r\n" +
	"│Exit       │Escape          │\r\n" +
	"│           │q               │\r\n" +
	"├───────────┼────────────────┤\r\n" +
	"│Navigate   │                │\r\n" +
	"│ - first   │page-up         │\r\n" +
	"│ - last    │page-down       │\r\n" +
	"│ - top     │gg              │\r\n" +
	"│ - bottom  │G               │\r\n" +
	"└───────────┴────────────────┘\x00"

type options struct {
	fullscreen bool
	file       string
}

func main() {
	opts, action, ok := parseArgs(os.Args[1:])
	if !ok {
		fmt.Fprintln(os.Stderr, "Invalid arguments")
		os.Exit(1)
	}
	switch action {
	case "help":
		fmt.Print(helpText)
		return
	case "version":
		fmt.Println(version)
		return
	case "key":
		fmt.Print(keyText)
		return
	}

	var data []byte
	var err error
	if opts.file == "" {
		fmt.Println("Reading from stdin...")
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(opts.file)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Could not open file %s\n", opts.file)
			os.Exit(1)
		}
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	v, err := parseValue(dec)
	if err != nil {
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, formatParseError(data, dec.InputOffset(), err))
		os.Exit(1)
	}
	if tok, err := dec.Token(); err != io.EOF || tok != nil {
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "[json.exception.parse_error.101] parse error: unexpected extra input after JSON value")
		os.Exit(1)
	}

	runUI(v, opts.fullscreen)
}

type node struct {
	kind  string
	key   string
	value any
	kids  []node
}

func parseValue(dec *json.Decoder) (node, error) {
	tok, err := dec.Token()
	if err != nil {
		return node{}, err
	}
	switch t := tok.(type) {
	case json.Delim:
		switch t {
		case '{':
			n := node{kind: "object"}
			for dec.More() {
				ktok, err := dec.Token()
				if err != nil {
					return node{}, err
				}
				key, ok := ktok.(string)
				if !ok {
					return node{}, fmt.Errorf("expected object key")
				}
				child, err := parseValue(dec)
				if err != nil {
					return node{}, err
				}
				child.key = key
				n.kids = append(n.kids, child)
			}
			end, err := dec.Token()
			if err != nil {
				return node{}, err
			}
			if end != json.Delim('}') {
				return node{}, fmt.Errorf("expected '}'")
			}
			return n, nil
		case '[':
			n := node{kind: "array"}
			for dec.More() {
				child, err := parseValue(dec)
				if err != nil {
					return node{}, err
				}
				n.kids = append(n.kids, child)
			}
			end, err := dec.Token()
			if err != nil {
				return node{}, err
			}
			if end != json.Delim(']') {
				return node{}, fmt.Errorf("expected ']'")
			}
			return n, nil
		}
	case string:
		return node{kind: "string", value: t}, nil
	case json.Number:
		return node{kind: "number", value: t}, nil
	case bool:
		return node{kind: "bool", value: t}, nil
	case nil:
		return node{kind: "null"}, nil
	}
	return node{}, fmt.Errorf("unsupported JSON token")
}

func parseArgs(args []string) (options, string, bool) {
	var opts options
	positional := false
	for _, arg := range args {
		if positional {
			if opts.file != "" {
				return opts, "", false
			}
			opts.file = arg
			continue
		}
		switch arg {
		case "--":
			positional = true
		case "-h", "--help":
			return opts, "help", true
		case "-v", "--version":
			return opts, "version", true
		case "-k", "--key", "--keybinding", "-key", "-keybinding":
			return opts, "key", true
		case "-f", "--fullscreen":
			opts.fullscreen = true
		default:
			if strings.HasPrefix(arg, "-") {
				return opts, "", false
			}
			if opts.file != "" {
				return opts, "", false
			}
			opts.file = arg
		}
	}
	return opts, "", true
}

func formatParseError(data []byte, off int64, err error) string {
	if off < 0 {
		off = 0
	}
	if int(off) > len(data) {
		off = int64(len(data))
	}
	line, col := 1, 1
	for i := int64(0); i < off && i < int64(len(data)); i++ {
		if data[i] == '\n' {
			line++
			col = 1
		} else {
			col++
		}
	}
	return fmt.Sprintf("[json.exception.parse_error.101] parse error at line %d, column %d: %s", line, col, err.Error())
}

func runUI(v node, fullscreen bool) {
	if fullscreen {
		fmt.Print("\x1b[?1049h")
		defer fmt.Print("\x1b[?1049l")
	}
	fmt.Print("\x00\x1bP$q q\x1b\\\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h")
	lines := render(v, 0, true)
	width, _ := terminalSize()
	if width <= 0 {
		width = 80
	}
	for i, line := range lines {
		if i > 0 {
			fmt.Print("\r\n")
		}
		fmt.Print("\r\x1b[2K")
		if printableLen(stripANSI(line)) > width {
			line = truncatePrintable(line, width)
		}
		fmt.Print(line)
	}
	fmt.Print("\x1b[?25l")
	waitForQuit()
	fmt.Print("\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1000l\x1b[?7h\x1b[?25h\x1b[1 q\x00\r\n")
}

func waitForQuit() {
	fd := int(os.Stdin.Fd())
	var old syscall.Termios
	raw := false
	if ioctl(fd, syscall.TCGETS, uintptr(unsafe.Pointer(&old))) == nil {
		t := old
		t.Iflag &^= syscall.IGNBRK | syscall.BRKINT | syscall.PARMRK | syscall.ISTRIP | syscall.INLCR | syscall.IGNCR | syscall.ICRNL | syscall.IXON
		t.Oflag &^= syscall.OPOST
		t.Lflag &^= syscall.ECHO | syscall.ECHONL | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
		t.Cflag &^= syscall.CSIZE | syscall.PARENB
		t.Cflag |= syscall.CS8
		t.Cc[syscall.VMIN] = 1
		t.Cc[syscall.VTIME] = 0
		if ioctl(fd, syscall.TCSETS, uintptr(unsafe.Pointer(&t))) == nil {
			raw = true
			defer ioctl(fd, syscall.TCSETS, uintptr(unsafe.Pointer(&old)))
		}
	}
	r := bufio.NewReader(os.Stdin)
	for {
		b, err := r.ReadByte()
		if err != nil {
			return
		}
		if b == 'q' || b == 27 || b == 3 || b == 4 {
			return
		}
		if !raw && b == '\n' {
			return
		}
	}
}

func render(v node, indent int, root bool) []string {
	pad := strings.Repeat(" ", indent)
	switch v.kind {
	case "object":
		if len(v.kids) == 0 {
			return []string{bold("{}")}
		}
		lines := []string{bold("{")}
		for i, child := range v.kids {
			trailer := ","
			if i == len(v.kids)-1 {
				trailer = ""
			}
			if isContainer(child) {
				lines = append(lines, pad+"  "+blue(strconv.Quote(child.key))+": "+collapsed(child)+trailer)
			} else {
				rendered := render(child, indent+2, false)
				if len(rendered) == 1 {
					lines = append(lines, pad+"  "+blue(strconv.Quote(child.key))+": "+rendered[0]+trailer)
				} else {
					lines = append(lines, pad+"  "+blue(strconv.Quote(child.key))+": "+rendered[0])
					for _, l := range rendered[1:] {
						lines = append(lines, l)
					}
					lines[len(lines)-1] += trailer
				}
			}
		}
		lines = append(lines, pad+bold("}"))
		return lines
	case "array":
		if len(v.kids) == 0 {
			return []string{bold("[]")}
		}
		lines := []string{bold("[")}
		for i, child := range v.kids {
			trailer := ","
			if i == len(v.kids)-1 {
				trailer = ""
			}
			rendered := render(child, indent+2, false)
			for j, l := range rendered {
				if j == 0 {
					lines = append(lines, pad+"  "+l)
				} else {
					lines = append(lines, l)
				}
			}
			lines[len(lines)-1] += trailer
		}
		lines = append(lines, pad+bold("]"))
		return lines
	case "string":
		return []string{green(strconv.Quote(v.value.(string)))}
	case "number":
		return []string{cyan(v.value.(json.Number).String())}
	case "bool":
		if v.value.(bool) {
			return []string{cyan("true")}
		}
		return []string{cyan("false")}
	case "null":
		return []string{cyan("null")}
	default:
		return []string{fmt.Sprint(v.value)}
	}
}

func isContainer(v node) bool {
	return v.kind == "object" || v.kind == "array"
}

func collapsed(v node) string {
	switch v.kind {
	case "object":
		return bold("{...}")
	case "array":
		return bold("[...]")
	default:
		return ""
	}
}

func blue(s string) string  { return "\x1b[94m\x1b[49m" + s + "\x1b[39m\x1b[49m" }
func green(s string) string { return "\x1b[92m\x1b[49m" + s + "\x1b[39m\x1b[49m" }
func cyan(s string) string  { return "\x1b[96m\x1b[49m" + s + "\x1b[39m\x1b[49m" }
func bold(s string) string  { return "\x1b[1m" + s + "\x1b[22m" }

func ioctl(fd int, req uint, arg uintptr) error {
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, uintptr(fd), uintptr(req), arg)
	if errno != 0 {
		return errno
	}
	return nil
}

func terminalSize() (int, int) {
	type winsize struct {
		Row    uint16
		Col    uint16
		Xpixel uint16
		Ypixel uint16
	}
	var ws winsize
	if ioctl(int(os.Stdout.Fd()), syscall.TIOCGWINSZ, uintptr(unsafe.Pointer(&ws))) != nil {
		return 0, 0
	}
	return int(ws.Col), int(ws.Row)
}

func stripANSI(s string) string {
	var b strings.Builder
	inEsc := false
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inEsc {
			if (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') {
				inEsc = false
			}
			continue
		}
		if c == 0x1b {
			inEsc = true
			continue
		}
		b.WriteByte(c)
	}
	return b.String()
}

func printableLen(s string) int {
	n := 0
	for range s {
		n++
	}
	return n
}

func truncatePrintable(s string, width int) string {
	if width <= 0 {
		return ""
	}
	var out strings.Builder
	visible := 0
	inEsc := false
	for i := 0; i < len(s); i++ {
		c := s[i]
		out.WriteByte(c)
		if inEsc {
			if (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') {
				inEsc = false
			}
			continue
		}
		if c == 0x1b {
			inEsc = true
			continue
		}
		if c&0xC0 != 0x80 {
			visible++
			if visible >= width {
				break
			}
		}
	}
	return out.String()
}
