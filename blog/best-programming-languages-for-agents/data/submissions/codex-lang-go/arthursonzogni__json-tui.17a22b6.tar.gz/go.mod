module json-tui-reimplementation

go 1.21
