package main

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/gif"
	"image/jpeg"
	"image/png"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

type config struct {
	quality       *int
	lossless      bool
	maxSize       int64
	width         int
	height        int
	longEdge      int
	shortEdge     int
	noUpscale     bool
	output        string
	sameFolder    bool
	format        string
	pngLevel      int
	chroma        string
	baseline      bool
	zopfli        bool
	exif          bool
	keepDates     bool
	stripICC      bool
	suffix        string
	recursive     bool
	keepStructure bool
	dryRun        bool
	threads       int
	overwrite     string
	minSavingsRaw string
	quiet         bool
	verbose       int
	files         []string
}

type task struct {
	path string
	base string
	rel  string
}

type result struct {
	ok, skipped, err bool
	in, out          int64
	msg              string
}

const helpText = `A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`

func main() {
	cfg, exit := parse(os.Args[1:])
	if exit >= 0 {
		os.Exit(exit)
	}
	if err := validate(cfg); err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(2)
	}
	tasks, err := collectTasks(cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Unable to compute the base path for the files.")
		os.Exit(255)
	}
	var results []result
	for _, t := range tasks {
		r := process(cfg, t)
		results = append(results, r)
		if cfg.verbose >= 3 && !cfg.quiet {
			if r.ok {
				fmt.Printf("[Success] %s -> %s\n%s -> %s [%s | %s]\n\n", t.path, r.msg, human(r.in), human(r.out), signedHuman(r.out-r.in), signedPct(r.in, r.out))
			} else if r.skipped {
				fmt.Printf("[Skipped] %s\n\n", t.path)
			} else if r.err {
				fmt.Printf("[Error] %s: %s\n\n", t.path, r.msg)
			}
		}
	}
	if !cfg.quiet && cfg.verbose > 0 {
		var ok, skip, er int
		var in, out int64
		for _, r := range results {
			if r.ok {
				ok++
			}
			if r.skipped {
				skip++
			}
			if r.err {
				er++
			}
			in += r.in
			out += r.out
		}
		fmt.Printf("Compressed %d files (%d success, %d skipped, %d errors)\n", len(results), ok, skip, er)
		fmt.Printf("%s -> %s [%s | %s]\n", human(in), human(out), signedHuman(out-in), signedPct(in, out))
	}
	if len(results) == 0 {
		os.Exit(0)
	}
}

func parse(args []string) (*config, int) {
	cfg := &config{format: "original", pngLevel: 3, chroma: "auto", overwrite: "all", verbose: 1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			cfg.files = append(cfg.files, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			cfg.files = append(cfg.files, a)
			continue
		}
		if a == "-h" || a == "--help" {
			fmt.Println(helpText)
			return nil, 0
		}
		if a == "-V" || a == "--version" {
			fmt.Println("caesiumclt 1.3.0")
			return nil, 0
		}
		name, val, hasVal := splitOpt(a)
		need := func() string {
			if hasVal {
				return val
			}
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s'\n", a)
				os.Exit(2)
			}
			i++
			return args[i]
		}
		switch name {
		case "-q", "--quality":
			v, err := strconv.Atoi(need())
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value for '--quality <QUALITY>': %v\n", err)
				os.Exit(2)
			}
			cfg.quality = &v
		case "--lossless":
			cfg.lossless = true
		case "--max-size":
			v, err := parseSize(need())
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value for '--max-size <MAX_SIZE>'\n")
				os.Exit(2)
			}
			cfg.maxSize = v
		case "--width":
			cfg.width = atoiOpt(name, need())
		case "--height":
			cfg.height = atoiOpt(name, need())
		case "--long-edge":
			cfg.longEdge = atoiOpt(name, need())
		case "--short-edge":
			cfg.shortEdge = atoiOpt(name, need())
		case "--no-upscale":
			cfg.noUpscale = true
		case "-o", "--output":
			cfg.output = need()
		case "--same-folder-as-input":
			cfg.sameFolder = true
		case "--format":
			cfg.format = strings.ToLower(need())
		case "--png-opt-level":
			cfg.pngLevel = atoiOpt(name, need())
		case "--jpeg-chroma-subsampling":
			cfg.chroma = need()
		case "--jpeg-baseline":
			cfg.baseline = true
		case "--zopfli":
			cfg.zopfli = true
		case "-e", "--exif":
			cfg.exif = true
		case "--keep-dates":
			cfg.keepDates = true
		case "--strip-icc":
			cfg.stripICC = true
		case "--suffix":
			cfg.suffix = need()
		case "-R", "--recursive":
			cfg.recursive = true
		case "-S", "--keep-structure":
			cfg.keepStructure = true
		case "-d", "--dry-run":
			cfg.dryRun = true
		case "--threads":
			cfg.threads = atoiOpt(name, need())
		case "-O", "--overwrite":
			cfg.overwrite = strings.ToLower(need())
		case "--min-savings":
			cfg.minSavingsRaw = need()
		case "-Q", "--quiet":
			cfg.quiet = true
			cfg.verbose = 0
		case "--verbose":
			cfg.verbose = atoiOpt(name, need())
		default:
			// Accept grouped short flags used by examples, e.g. -RS.
			if strings.HasPrefix(a, "-") && !strings.HasPrefix(a, "--") && len(a) > 2 {
				for _, c := range a[1:] {
					switch c {
					case 'R':
						cfg.recursive = true
					case 'S':
						cfg.keepStructure = true
					case 'd':
						cfg.dryRun = true
					case 'Q':
						cfg.quiet = true
						cfg.verbose = 0
					default:
						fmt.Fprintf(os.Stderr, "error: unexpected argument '%s'\n", a)
						os.Exit(2)
					}
				}
			} else {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s'\n", a)
				os.Exit(2)
			}
		}
	}
	return cfg, -1
}

func splitOpt(s string) (name, val string, has bool) {
	if strings.HasPrefix(s, "--") {
		if p := strings.IndexByte(s, '='); p >= 0 {
			return s[:p], s[p+1:], true
		}
	}
	return s, "", false
}

func atoiOpt(name, s string) int {
	v, err := strconv.Atoi(s)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s'\n", s, name)
		os.Exit(2)
	}
	return v
}

func validate(c *config) error {
	modes := 0
	if c.quality != nil {
		modes++
		if *c.quality < 0 || *c.quality > 100 {
			return fmt.Errorf("error: invalid value '%d' for '--quality <QUALITY>': Quality must be between 0 and 100, but got %d\n\nFor more information, try '--help'.", *c.quality, *c.quality)
		}
	}
	if c.lossless {
		modes++
	}
	if c.maxSize > 0 {
		modes++
	}
	if modes == 0 {
		return errors.New("error: the following required arguments were not provided:\n  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>\n  <--output <OUTPUT>|--same-folder-as-input>\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.")
	}
	if modes > 1 {
		return errors.New("error: the argument '--lossless' cannot be used with '--quality <QUALITY>'\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.")
	}
	dest := 0
	if c.output != "" {
		dest++
	}
	if c.sameFolder {
		dest++
	}
	if dest == 0 {
		return errors.New("error: the following required arguments were not provided:\n  <--output <OUTPUT>|--same-folder-as-input>\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.")
	}
	if dest > 1 {
		return errors.New("error: the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'\n\nFor more information, try '--help'.")
	}
	if c.width > 0 && c.longEdge > 0 || c.width > 0 && c.shortEdge > 0 || c.height > 0 && c.longEdge > 0 || c.height > 0 && c.shortEdge > 0 || c.longEdge > 0 && c.shortEdge > 0 {
		return errors.New("error: resize options are mutually exclusive\n\nFor more information, try '--help'.")
	}
	if !oneOf(c.format, "jpeg", "png", "gif", "webp", "tiff", "original") {
		return fmt.Errorf("error: invalid value '%s' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]\n\nFor more information, try '--help'.", c.format)
	}
	if !oneOf(c.overwrite, "all", "never", "bigger") {
		return fmt.Errorf("error: invalid value '%s' for '--overwrite <OVERWRITE>'", c.overwrite)
	}
	if c.pngLevel < 0 || c.pngLevel > 6 {
		return fmt.Errorf("error: invalid value '%d' for '--png-opt-level <PNG_OPT_LEVEL>'", c.pngLevel)
	}
	return nil
}

func oneOf(s string, vals ...string) bool {
	for _, v := range vals {
		if s == v {
			return true
		}
	}
	return false
}

func collectTasks(c *config) ([]task, error) {
	var out []task
	if len(c.files) == 0 {
		return out, nil
	}
	for _, p := range c.files {
		info, err := os.Stat(p)
		if err != nil {
			return nil, err
		}
		if info.IsDir() {
			base := p
			if c.recursive {
				err := filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
					if err != nil || d.IsDir() {
						return nil
					}
					if isSupportedInput(path) {
						rel, _ := filepath.Rel(base, path)
						if !c.keepStructure {
							rel = filepath.Base(path)
						}
						out = append(out, task{path: path, base: base, rel: rel})
					}
					return nil
				})
				if err != nil {
					return nil, err
				}
			} else {
				ents, _ := os.ReadDir(p)
				for _, e := range ents {
					if e.IsDir() {
						continue
					}
					path := filepath.Join(p, e.Name())
					if isSupportedInput(path) {
						out = append(out, task{path: path, base: p, rel: e.Name()})
					}
				}
			}
		} else if isSupportedInput(p) {
			out = append(out, task{path: p, base: filepath.Dir(p), rel: filepath.Base(p)})
		}
	}
	return out, nil
}

func isSupportedInput(p string) bool {
	switch strings.ToLower(filepath.Ext(p)) {
	case ".jpg", ".jpeg", ".png", ".gif", ".webp":
		return true
	}
	return false
}

func process(c *config, t task) result {
	st, err := os.Stat(t.path)
	if err != nil {
		return result{err: true, msg: err.Error()}
	}
	inputSize := st.Size()
	outPath := outputPath(c, t)
	data, err := encode(c, t.path)
	if err != nil {
		b, e := os.ReadFile(t.path)
		if e != nil {
			return result{err: true, in: inputSize, msg: err.Error()}
		}
		data = b
	}
	outputSize := int64(len(data))
	if c.dryRun {
		return result{ok: true, in: inputSize, out: inputSize, msg: outPath}
	}
	if skipBySavings(c, inputSize, outputSize) {
		return result{skipped: true, in: inputSize, out: 0, msg: outPath}
	}
	if ex, err := os.Stat(outPath); err == nil {
		switch c.overwrite {
		case "never":
			return result{skipped: true, in: inputSize, out: ex.Size(), msg: outPath}
		case "bigger":
			if ex.Size() <= outputSize {
				return result{skipped: true, in: inputSize, out: ex.Size(), msg: outPath}
			}
		}
	}
	if err := os.MkdirAll(filepath.Dir(outPath), 0755); err != nil {
		return result{err: true, in: inputSize, msg: err.Error()}
	}
	if err := os.WriteFile(outPath, data, 0644); err != nil {
		return result{err: true, in: inputSize, msg: err.Error()}
	}
	if c.keepDates {
		_ = os.Chtimes(outPath, time.Now(), st.ModTime())
	}
	return result{ok: true, in: inputSize, out: outputSize, msg: outPath}
}

func outputPath(c *config, t task) string {
	rel := t.rel
	if rel == "" {
		rel = filepath.Base(t.path)
	}
	ext := filepath.Ext(rel)
	base := strings.TrimSuffix(rel, ext)
	outExt := ext
	switch c.format {
	case "jpeg":
		outExt = ".jpg"
	case "png":
		outExt = ".png"
	case "gif":
		outExt = ".gif"
	case "webp":
		outExt = ".webp"
	case "tiff":
		outExt = ".tiff"
	}
	rel = base + c.suffix + outExt
	if c.sameFolder {
		return filepath.Join(filepath.Dir(t.path), filepath.Base(base)+c.suffix+outExt)
	}
	return filepath.Join(c.output, rel)
}

func encode(c *config, path string) ([]byte, error) {
	if c.lossless && c.format == "original" && !hasResize(c) {
		return os.ReadFile(path)
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	img, fmtName, err := image.Decode(f)
	if err != nil {
		return nil, err
	}
	img = resizeIfNeeded(img, c)
	outFmt := c.format
	if outFmt == "original" {
		outFmt = normalizeFormat(fmtName, filepath.Ext(path))
	}
	if c.maxSize > 0 {
		return encodeMaxSize(img, outFmt, c.maxSize, c)
	}
	q := 100
	if c.quality != nil {
		q = *c.quality
	}
	if c.lossless {
		q = 100
	}
	return encodeImage(img, outFmt, q, c)
}

func hasResize(c *config) bool {
	return c.width > 0 || c.height > 0 || c.longEdge > 0 || c.shortEdge > 0
}

func normalizeFormat(name, ext string) string {
	if name == "jpeg" {
		return "jpeg"
	}
	if name == "png" || name == "gif" {
		return name
	}
	e := strings.ToLower(ext)
	if e == ".jpg" || e == ".jpeg" {
		return "jpeg"
	}
	if strings.HasPrefix(e, ".") {
		return strings.TrimPrefix(e, ".")
	}
	return name
}

func encodeMaxSize(img image.Image, format string, target int64, c *config) ([]byte, error) {
	best, _ := encodeImage(img, format, 1, c)
	if int64(len(best)) <= target {
		return best, nil
	}
	lo, hi := 1, 100
	for lo <= hi {
		mid := (lo + hi) / 2
		b, err := encodeImage(img, format, mid, c)
		if err != nil {
			return nil, err
		}
		if int64(len(b)) <= target {
			best = b
			lo = mid + 1
		} else {
			hi = mid - 1
		}
	}
	return best, nil
}

func encodeImage(img image.Image, format string, quality int, c *config) ([]byte, error) {
	var buf bytes.Buffer
	switch format {
	case "jpeg", "jpg":
		err := jpeg.Encode(&buf, flatten(img), &jpeg.Options{Quality: clamp(quality, 1, 100)})
		return buf.Bytes(), err
	case "png":
		enc := png.Encoder{CompressionLevel: png.BestCompression}
		if quality < 100 {
			img = quantizeImage(img, quality)
		}
		err := enc.Encode(&buf, img)
		return buf.Bytes(), err
	case "gif":
		err := gif.Encode(&buf, img, &gif.Options{NumColors: clamp(2+quality*254/100, 2, 256)})
		return buf.Bytes(), err
	case "webp", "tiff", "tif":
		return nil, fmt.Errorf("unsupported encoder")
	default:
		return nil, fmt.Errorf("unsupported format")
	}
}

func flatten(src image.Image) image.Image {
	b := src.Bounds()
	dst := image.NewRGBA(image.Rect(0, 0, b.Dx(), b.Dy()))
	draw.Draw(dst, dst.Bounds(), image.NewUniform(color.White), image.Point{}, draw.Src)
	draw.Draw(dst, dst.Bounds(), src, b.Min, draw.Over)
	return dst
}

func resizeIfNeeded(src image.Image, c *config) image.Image {
	b := src.Bounds()
	w, h := b.Dx(), b.Dy()
	nw, nh := w, h
	if c.width > 0 && c.height > 0 {
		nw, nh = c.width, c.height
	} else if c.width > 0 {
		nw = c.width
		nh = int(math.Round(float64(h) * float64(nw) / float64(w)))
	} else if c.height > 0 {
		nh = c.height
		nw = int(math.Round(float64(w) * float64(nh) / float64(h)))
	} else if c.longEdge > 0 {
		if w >= h {
			nw = c.longEdge
			nh = int(math.Round(float64(h) * float64(nw) / float64(w)))
		} else {
			nh = c.longEdge
			nw = int(math.Round(float64(w) * float64(nh) / float64(h)))
		}
	} else if c.shortEdge > 0 {
		if w <= h {
			nw = c.shortEdge
			nh = int(math.Round(float64(h) * float64(nw) / float64(w)))
		} else {
			nh = c.shortEdge
			nw = int(math.Round(float64(w) * float64(nh) / float64(h)))
		}
	}
	if c.noUpscale && (nw > w || nh > h) {
		return src
	}
	if nw <= 0 || nh <= 0 || (nw == w && nh == h) {
		return src
	}
	dst := image.NewRGBA(image.Rect(0, 0, nw, nh))
	sb := src.Bounds()
	for y := 0; y < nh; y++ {
		sy := sb.Min.Y + int(float64(y)*float64(h)/float64(nh))
		if sy >= sb.Max.Y {
			sy = sb.Max.Y - 1
		}
		for x := 0; x < nw; x++ {
			sx := sb.Min.X + int(float64(x)*float64(w)/float64(nw))
			if sx >= sb.Max.X {
				sx = sb.Max.X - 1
			}
			dst.Set(x, y, src.At(sx, sy))
		}
	}
	return dst
}

func quantizeImage(src image.Image, quality int) image.Image {
	if quality >= 100 {
		return src
	}
	step := uint32(1 + (100-quality)/8)
	if step <= 1 {
		return src
	}
	b := src.Bounds()
	dst := image.NewRGBA(image.Rect(0, 0, b.Dx(), b.Dy()))
	for y := 0; y < b.Dy(); y++ {
		for x := 0; x < b.Dx(); x++ {
			r, g, bl, a := src.At(b.Min.X+x, b.Min.Y+y).RGBA()
			q := func(v uint32) uint8 {
				v8 := (v >> 8) / step * step
				if v8 > 255 {
					v8 = 255
				}
				return uint8(v8)
			}
			dst.SetRGBA(x, y, color.RGBA{q(r), q(g), q(bl), uint8(a >> 8)})
		}
	}
	return dst
}

func skipBySavings(c *config, in, out int64) bool {
	if c.minSavingsRaw == "" {
		return false
	}
	s := strings.TrimSpace(c.minSavingsRaw)
	saved := in - out
	if strings.HasSuffix(s, "%") {
		v, err := strconv.ParseFloat(strings.TrimSuffix(s, "%"), 64)
		if err != nil || in <= 0 {
			return false
		}
		return (float64(saved)/float64(in))*100 < v
	}
	v, err := parseSize(s)
	if err != nil {
		return false
	}
	return saved < v
}

func parseSize(s string) (int64, error) {
	t := strings.TrimSpace(strings.ToUpper(s))
	units := []struct {
		s string
		m float64
	}{{"KIB", 1024}, {"MIB", 1024 * 1024}, {"GIB", 1024 * 1024 * 1024}, {"KB", 1000}, {"MB", 1000 * 1000}, {"GB", 1000 * 1000 * 1000}, {"B", 1}}
	m := float64(1)
	for _, u := range units {
		if strings.HasSuffix(t, u.s) {
			m = u.m
			t = strings.TrimSpace(strings.TrimSuffix(t, u.s))
			break
		}
	}
	v, err := strconv.ParseFloat(t, 64)
	return int64(v * m), err
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func human(n int64) string {
	sign := ""
	if n < 0 {
		sign = "-"
		n = -n
	}
	if n < 1024 {
		return fmt.Sprintf("%s%d B", sign, n)
	}
	units := []string{"KiB", "MiB", "GiB"}
	f := float64(n)
	i := -1
	for f >= 1024 && i+1 < len(units) {
		f /= 1024
		i++
	}
	return fmt.Sprintf("%s%.1f %s", sign, f, units[i])
}

func signedHuman(delta int64) string {
	if delta > 0 {
		return "+" + human(delta)
	}
	if delta == 0 {
		return "-0 B"
	}
	return "-" + human(-delta)
}

func signedPct(in, out int64) string {
	if in == 0 {
		return "-0.00%"
	}
	p := (float64(out-in) / float64(in)) * 100
	if p > 0 {
		return fmt.Sprintf("+%.2f%%", p)
	}
	return fmt.Sprintf("%.2f%%", p)
}
