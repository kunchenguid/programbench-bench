package main

import (
	"archive/zip"
	"bytes"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

const version = "0.17.0"

var globalQuiet bool

type options struct {
	single, quiet, stats bool
	create               []string
	output, to           string
	printTemplate        string
	set                  []string
	book                 string
}

type book struct {
	Meta     map[string]string
	Chapters []string
	Content  []string
	BaseDir  string
}

func main() {
	opts, code := parseArgs(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}
	if opts.quiet {
		run(opts)
		return
	}
	if !opts.helpLike() {
		fmt.Fprintln(os.Stderr, "CROWBOOK "+version)
	}
	run(opts)
}

func (o options) helpLike() bool { return false }

func parseArgs(args []string) (options, int) {
	var o options
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printHelp()
			return o, 0
		case "-V", "--version":
			fmt.Println("crowbook " + version)
			return o, 0
		case "-s", "--single":
			o.single = true
		case "-q", "--quiet":
			o.quiet = true
		case "-n", "--no-fancy", "-f", "--force-emoji", "-v", "--verbose", "-a", "--autograph", "-L", "--lang":
			if a == "-L" || a == "--lang" {
				if i+1 >= len(args) {
					argErr("a value is required for '" + a + "' but none was supplied")
					return o, 2
				}
				i++
			}
		case "-S", "--stats":
			o.stats = true
		case "-l", "--list-options":
			fmt.Fprintln(os.Stderr, "CROWBOOK "+version)
			fmt.Print(listOptions)
			return o, 0
		case "--print-template":
			if i+1 >= len(args) {
				argErr("a value is required for '--print-template <print-template>' but none was supplied")
				return o, 2
			}
			o.printTemplate = args[i+1]
			i++
		case "-o", "--output":
			if i+1 >= len(args) {
				argErr("a value is required for '--output <output>' but none was supplied")
				return o, 2
			}
			o.output = args[i+1]
			i++
		case "-t", "--to":
			if i+1 >= len(args) {
				argErr("a value is required for '--to <to>' but none was supplied")
				return o, 2
			}
			o.to = args[i+1]
			if !validFormat(o.to) {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--to <to>'\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'.\n", o.to)
				return o, 2
			}
			i++
		case "-c", "--create":
			if i+1 >= len(args) || strings.HasPrefix(args[i+1], "-") {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--create <files>...' but none was supplied\n\nFor more information, try '--help'.")
				return o, 2
			}
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				o.create = append(o.create, args[i+1])
				i++
			}
		case "--set":
			if i+2 >= len(args) {
				argErr("a value is required for '--set <set> <set>...' but none was supplied")
				return o, 2
			}
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				o.set = append(o.set, args[i+1])
				i++
			}
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.\n", a, a, a)
				return o, 2
			}
			if o.book == "" {
				o.book = a
			} else {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.\n", a)
				return o, 2
			}
		}
	}
	return o, -1
}

func argErr(s string) { fmt.Fprintln(os.Stderr, "error: "+s+"\n\nFor more information, try '--help'.") }

func validFormat(s string) bool {
	switch s {
	case "", "epub", "pdf", "html", "tex", "odt", "html.dir":
		return true
	}
	return false
}

func run(o options) {
	globalQuiet = o.quiet
	if o.printTemplate != "" {
		fmt.Fprintf(os.Stderr, "ERROR %s is not a valid template name\n", o.printTemplate)
		return
	}
	if len(o.create) > 0 {
		createBook(o.create)
		return
	}
	if o.book == "" {
		fmt.Fprintln(os.Stderr, "ERROR You must pass the name of a book configuration file.\nFor more information try --help.")
		return
	}
	b, err := loadBook(o)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR %s\n", err)
		return
	}
	applySet(&b, o.set)
	if o.stats {
		printStats(b)
		return
	}
	render(b, o)
}

func createBook(files []string) {
	lines := []string{
		`"author: Your name"`, `"title: Your title"`, `"lang: en"`, "",
		`"## Output formats"`, "",
		`"# Uncomment and fill to generate files"`,
		`"# output.html: some_file.html"`,
		`"# output.epub: some_file.epub"`,
		`"# output.pdf: some_file.pdf"`, "",
		`"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name"`,
		`"# output: [pdf, epub, html]"`, "",
		`"# Uncomment and fill to set cover image (for EPUB)"`,
		`"# cover: some_cover.png"`, "",
		"## List of chapters",
	}
	for _, f := range files {
		lines = append(lines, "+ "+f)
	}
	fmt.Println(strings.Join(lines, "\n"))
}

func loadBook(o options) (book, error) {
	b := book{Meta: map[string]string{"lang": "en"}, BaseDir: "."}
	if o.single {
		path := o.book
		data, err := os.ReadFile(path)
		if err != nil {
			return b, fmt.Errorf("Could not find file '%s' for book", path)
		}
		b.BaseDir = filepath.Dir(path)
		tmp := filepath.Join(os.TempDir(), filepath.Base(path))
		_ = tmp
		content := string(data)
		if strings.HasPrefix(content, "---\n") {
			parts := strings.SplitN(content[4:], "\n---", 2)
			if len(parts) == 2 {
				parseMetaLines(b.Meta, strings.Split(parts[0], "\n"))
				content = strings.TrimLeft(parts[1], "\r\n")
			}
		}
		name := filepath.Base(path)
		b.Chapters = []string{name}
		b.Content = []string{content}
		return b, nil
	}
	data, err := os.ReadFile(o.book)
	if err != nil {
		return b, fmt.Errorf("Could not find file '%s' for book", o.book)
	}
	b.BaseDir = filepath.Dir(o.book)
	for _, line := range strings.Split(string(data), "\n") {
		t := strings.TrimSpace(line)
		if t == "" || strings.HasPrefix(t, "#") {
			continue
		}
		if strings.HasPrefix(t, "+") || strings.HasPrefix(t, "-") {
			ch := strings.TrimSpace(t[1:])
			if ch != "" {
				b.Chapters = append(b.Chapters, ch)
			}
			continue
		}
		if idx := strings.Index(t, ":"); idx >= 0 {
			k := strings.TrimSpace(t[:idx])
			v := strings.Trim(strings.TrimSpace(t[idx+1:]), `"`)
			b.Meta[k] = v
		}
	}
	return b, nil
}

func parseMetaLines(m map[string]string, lines []string) {
	for _, l := range lines {
		if idx := strings.Index(l, ":"); idx >= 0 {
			m[strings.TrimSpace(l[:idx])] = strings.Trim(strings.TrimSpace(l[idx+1:]), `"`)
		}
	}
}

func applySet(b *book, set []string) {
	for i := 0; i+1 < len(set); i += 2 {
		b.Meta[set[i]] = set[i+1]
	}
}

func render(b book, o options) {
	formats := []string{}
	if o.to != "" {
		formats = append(formats, o.to)
	} else if out := b.Meta["output"]; out != "" {
		out = strings.Trim(out, "[]")
		for _, p := range strings.Split(out, ",") {
			p = strings.TrimSpace(p)
			if p != "" {
				formats = append(formats, p)
			}
		}
	} else {
		for _, f := range []string{"html", "epub", "tex", "pdf"} {
			if b.Meta["output."+f] != "" {
				formats = append(formats, f)
			}
		}
	}
	if len(formats) == 0 {
		return
	}
	for _, f := range formats {
		switch f {
		case "html":
			writeOutput(o.output, b.Meta["output.html"], genHTML(b), "HTML (standalone page)")
		case "tex":
			writeOutput(o.output, b.Meta["output.tex"], genTeX(b), "LaTeX")
		case "epub":
			data := genEPUB(b)
			writeBytes(o.output, b.Meta["output.epub"], data, "EPUB")
		case "pdf":
			fmt.Fprintln(os.Stderr, "ERROR Error during temporary files editing: xelatex didn't return succesfully")
		case "odt":
			writeBytes(o.output, b.Meta["output.odt"], []byte(""), "ODT")
		case "html.dir":
			dir := b.Meta["output.html.dir"]
			if dir == "" {
				dir = o.output
			}
			if dir == "" {
				dir = "html"
			}
			_ = os.MkdirAll(dir, 0755)
			_ = os.WriteFile(filepath.Join(dir, "index.html"), []byte(genHTML(b)), 0644)
			fmt.Fprintf(os.Stderr, "[INFO] Succesfully generated HTML directory: %s\n", dir)
		}
	}
}

func writeOutput(cli, conf, s, label string) {
	target := cli
	if target == "" {
		target = conf
	}
	if target == "" {
		fmt.Print(s)
		if !globalQuiet {
			fmt.Fprintf(os.Stderr, "[INFO] Succesfully generated %s\n", label)
		}
		return
	}
	_ = os.WriteFile(target, []byte(s), 0644)
	if !globalQuiet {
		fmt.Fprintf(os.Stderr, "[INFO] Succesfully generated %s: %s\n", label, target)
	}
}

func writeBytes(cli, conf string, data []byte, label string) {
	target := cli
	if target == "" {
		target = conf
	}
	if target == "" {
		_, _ = os.Stdout.Write(data)
		if !globalQuiet {
			fmt.Fprintf(os.Stderr, "[INFO] Succesfully generated %s\n", label)
		}
		return
	}
	_ = os.WriteFile(target, data, 0644)
	if !globalQuiet {
		fmt.Fprintf(os.Stderr, "[INFO] Succesfully generated %s: %s\n", label, target)
	}
}

func chapters(b book) []string {
	if len(b.Content) > 0 {
		return b.Content
	}
	var out []string
	for _, ch := range b.Chapters {
		p := ch
		if b.BaseDir != "." && b.BaseDir != "" {
			p = filepath.Join(b.BaseDir, ch)
		}
		data, err := os.ReadFile(p)
		if err == nil {
			out = append(out, string(data))
		}
	}
	return out
}

func genHTML(b book) string {
	title, author, lang := b.Meta["title"], b.Meta["author"], b.Meta["lang"]
	if lang == "" {
		lang = "en"
	}
	var body strings.Builder
	link, para := 1, 1
	for ci, md := range chapters(b) {
		body.WriteString(fmt.Sprintf(`<div id = "chapter-%d" class = "chapter">`+"\n  ", ci))
		body.WriteString(mdToHTML(md, &link, &para))
		body.WriteString("\n</div>\n")
	}
	return fmt.Sprintf(`<!DOCTYPE html>
<html lang="%s">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="%s">
    
    <title>%s</title>
    <style type = "text/css">
      body { font-family: "Linux Libertine", "Georgia", serif; text-align: justify; font-size: 100%%; }
p { text-indent: 1.25em; margin:0; hyphens: auto; }
h1, h2, h3, h4, h5, h6 { text-align: left; font-family: Linux Biolinum, sans-serif; font-variant: small-caps; }
h1.title { text-align: center; font-size: 300%%; }
h2.author { text-align: right; font-size: 200%%; }
span.chapter-header { font-size: 75%%; }
#content { text-align: center; }
#page { display: inline-block; text-align: justify; max-width: 33em; }
    </style>
  </head>
  <body>
<script type = 'application/ld+json'>
{
    "@context": "http://schema.org/",
    "@type": "Book",
    "author": "%s",
    "name": "%s",
    "inLanguage": "%s"
}
</script>
    <div id = "content">
      <div id = "page">
        <header>
          <div id = "menu">
          </div>
	  <h2 class="author">%s</h2>
          <h1 id = "link-0" class="title" >%s</h1>
        </header>

        %s
      </div>
    </div>
  </body>
</html>
`, html.EscapeString(lang), html.EscapeString(author), html.EscapeString(title), jsEsc(author), jsEsc(title), jsEsc(lang), html.EscapeString(author), html.EscapeString(title), body.String())
}

func mdToHTML(md string, link, para *int) string {
	var out strings.Builder
	lines := strings.Split(md, "\n")
	var p []string
	flush := func() {
		if len(p) == 0 {
			return
		}
		text := inlineHTML(strings.Join(p, " "))
		out.WriteString(fmt.Sprintf(`<p id = "para-%d">%s</p>`+"\n", *para, text))
		*para++
		p = nil
	}
	for _, line := range lines {
		t := strings.TrimSpace(line)
		if t == "" {
			flush()
			continue
		}
		if strings.HasPrefix(t, "#") {
			flush()
			n := 0
			for n < len(t) && t[n] == '#' {
				n++
			}
			if n > 0 && n < len(t) && t[n] == ' ' {
				txt := inlineHTML(strings.TrimSpace(t[n:]))
				if n == 1 {
					out.WriteString(fmt.Sprintf("<h1 id = 'link-%d'><span class = 'chapter-header'>Chapter %d</span><br />%s</h1>", *link, *link, txt))
				} else {
					out.WriteString(fmt.Sprintf(`<h%d id = "link-%d">%s</h%d>`+"\n", n, *link, txt, n))
				}
				*link++
				continue
			}
		}
		if strings.HasPrefix(t, "- ") || strings.HasPrefix(t, "* ") {
			flush()
			out.WriteString("<ul><li>" + inlineHTML(strings.TrimSpace(t[2:])) + "</li></ul>\n")
			continue
		}
		p = append(p, t)
	}
	flush()
	return out.String()
}

func inlineHTML(s string) string {
	s = html.EscapeString(s)
	repls := []struct{ re, by string }{
		{`\*\*([^*]+)\*\*`, `<b>$1</b>`},
		{`__([^_]+)__`, `<b>$1</b>`},
		{`\*([^*]+)\*`, `<em>$1</em>`},
		{`_([^_]+)_`, `<em>$1</em>`},
		{"`([^`]+)`", `<code>$1</code>`},
		{`!\[([^\]]*)\]\(([^)]+)\)`, `<img src="$2" alt="$1" />`},
		{`\[([^\]]+)\]\(([^)]+)\)`, `<a href="$2">$1</a>`},
	}
	for _, r := range repls {
		s = regexp.MustCompile(r.re).ReplaceAllString(s, r.by)
	}
	return s
}

func jsEsc(s string) string { return strings.ReplaceAll(s, `"`, `\"`) }

func genTeX(b book) string {
	title, author := texEsc(b.Meta["title"]), texEsc(b.Meta["author"])
	var body strings.Builder
	for _, md := range chapters(b) {
		for _, line := range strings.Split(md, "\n") {
			t := strings.TrimSpace(line)
			if t == "" {
				body.WriteString("\n")
			} else if strings.HasPrefix(t, "# ") {
				body.WriteString("\\section{" + texEsc(strings.TrimSpace(t[2:])) + "}\n\\label{chapter-0}\n")
			} else if strings.HasPrefix(t, "## ") {
				body.WriteString("\\subsection{" + texEsc(strings.TrimSpace(t[3:])) + "}\n")
			} else {
				body.WriteString(texEsc(stripMD(t)) + "\n")
			}
		}
	}
	return fmt.Sprintf(`\documentclass{article}
\usepackage{fontspec}
\usepackage{xunicode}
\usepackage[english]{babel}
\usepackage[colorlinks=true,breaklinks=true,hypertexnames=false]{hyperref}
\hypersetup{pdfauthor={%s}, pdftitle={%s}, pdfsubject={}}
\title{%s}
\author{%s}
\begin{document}
\maketitle

%s
\end{document}
`, author, title, title, author, body.String())
}

func texEsc(s string) string {
	r := strings.NewReplacer(`\`, `\textbackslash{}`, "&", `\&`, "%", `\%`, "$", `\$`, "#", `\#`, "_", `\_`, "{", `\{`, "}", `\}`)
	return r.Replace(s)
}

func stripMD(s string) string {
	s = strings.ReplaceAll(s, "**", "")
	s = strings.ReplaceAll(s, "*", "")
	s = strings.ReplaceAll(s, "__", "")
	s = strings.ReplaceAll(s, "_", "")
	return s
}

func genEPUB(b book) []byte {
	buf := new(bytes.Buffer)
	zw := zip.NewWriter(buf)
	addStore := func(name, content string) {
		h := &zip.FileHeader{Name: name, Method: zip.Store}
		h.SetModTime(time.Unix(0, 0))
		w, _ := zw.CreateHeader(h)
		_, _ = io.WriteString(w, content)
	}
	add := func(name, content string) {
		h := &zip.FileHeader{Name: name, Method: zip.Deflate}
		h.SetModTime(time.Unix(0, 0))
		w, _ := zw.CreateHeader(h)
		_, _ = io.WriteString(w, content)
	}
	addStore("mimetype", "application/epub+zip")
	add("META-INF/container.xml", `<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>`)
	add("OEBPS/title_page.xhtml", xhtmlPage(b.Meta["title"], "<h1>"+html.EscapeString(b.Meta["title"])+"</h1>"))
	for i, md := range chapters(b) {
		l, p := 1, 1
		add(fmt.Sprintf("OEBPS/chapter_%03d.xhtml", i), xhtmlPage(b.Meta["title"], mdToHTML(md, &l, &p)))
	}
	add("OEBPS/stylesheet.css", "body{font-family:serif} p{text-indent:1em}")
	add("OEBPS/content.opf", `<?xml version="1.0" encoding="utf-8"?><package version="2.0" xmlns="http://www.idpf.org/2007/opf" unique-identifier="bookid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>`+html.EscapeString(b.Meta["title"])+`</dc:title><dc:creator>`+html.EscapeString(b.Meta["author"])+`</dc:creator><dc:language>`+html.EscapeString(b.Meta["lang"])+`</dc:language></metadata><manifest><item id="title" href="title_page.xhtml" media-type="application/xhtml+xml"/></manifest><spine><itemref idref="title"/></spine></package>`)
	add("OEBPS/toc.ncx", `<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/"><docTitle><text>`+html.EscapeString(b.Meta["title"])+`</text></docTitle></ncx>`)
	add("OEBPS/nav.xhtml", xhtmlPage(b.Meta["title"], "<nav></nav>"))
	_ = zw.Close()
	return buf.Bytes()
}

func xhtmlPage(title, body string) string {
	return `<?xml version="1.0" encoding="utf-8"?><html xmlns="http://www.w3.org/1999/xhtml"><head><title>` + html.EscapeString(title) + `</title><link rel="stylesheet" href="stylesheet.css" type="text/css"/></head><body>` + body + `</body></html>`
}

func printStats(b book) {
	chars, words := 0, 0
	for _, md := range chapters(b) {
		chars += len([]rune(md))
		words += len(strings.Fields(md))
	}
	fmt.Fprintf(os.Stderr, "[INFO] %d characters, %d words\n", chars, words)
}

func printHelp() {
	fmt.Print(`crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>
Render a Markdown book in EPUB, PDF or HTML.
  
USAGE:
    executable [OPTIONS] [BOOK]

OPTIONS:
  -f, --force-emoji
          Force emoji usage even if it might not work on your system
  -s, --single
          Use a single Markdown file instead of a book configuration file
  -n, --no-fancy
          Disably fancy UI
  -v, --verbose
          Print warnings in parsing/rendering
  -a, --autograph
          Prompts for an autograph for this book
  -q, --quiet
          Don't print info/error messages
  -c, --create <files>...
          Create a new book with existing Markdown files
  -o, --output <output>
          Specify output file
  -t, --to <to>
          Generate specific format
      --set <set> <set>...
          Set a list of book options
  -l, --list-options
          List all possible options
  -L, --lang <lang>
          Set the runtime language used by Crowbook
      --print-template <print-template>
          Prints the default content of a template
  -S, --stats
          Print some project statistics
  -h, --help
          Print help
  -V, --version
          Print version

ARGS:
  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single
`)
}

var listOptions = `METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

ADDITIONAL METADATA
subtitle
  type: metadata (default: not set)
  Subtitle of the book
license
  type: metadata (default: not set)
  License of the book
version
  type: metadata (default: not set)
  Version of the book
date
  type: metadata (default: not set)
  Date the book was revised
autograph
  type: metadata (default: not set)
  An autograph

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
output.base_path
  type: path (default: "")
  Directory where those output files will we written

RENDERING OPTIONS
rendering.highlight
  type: string (default: syntect)
  If/how highligh code blocks. Possible values: "syntect" (default, performed at
  runtime), "highlight.js" (HTML-only, uses Javascript), "none"
rendering.highlight.theme
  type: string (default: InspiredGitHub)
  Theme for syntax highlighting (if rendering.highlight is set to 'syntect')
rendering.initials
  type: boolean (default: false)
  Use initials ('lettrines') for first letter of a chapter
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.inline_toc.name
  type: string (default: "{{loc_toc}}")
  Name of the table of contents if it is displayed in document
rendering.num_depth
  type: integer (default: 1)
  The  maximum heading levels that should be numbered (0: no numbering, 1: only
  chapters, ..., 6: all)
rendering.chapter
  type: string (default: not set)
  How to call chapters
rendering.part
  type: string (default: not set)
  How to call parts (or 'books', 'episodes', ...)
rendering.chapter.roman_numerals
  type: boolean (default: false)
  If set to true, display chapter number with roman numerals
rendering.part.roman_numerals
  type: boolean (default: true)
  If set to true, display part number with roman numerals
rendering.part.reset_counter
  type: boolean (default: true)
  If set to true, reset chapter number at each part
rendering.chapter.template
  type: string (default: "{{number}}. {{chapter_title}}")
  Naming scheme of chapters, for TOC
rendering.part.template
  type: string (default: "{{number}}. {{part_title}}")
  Naming scheme of parts, for TOC

SPECIAL OPTIONS
import
  type: path (default: not set)
  Import another book configuration file

HTML OPTIONS
html.icon
  type: path (default: not set)
  Path to an icon to be used for the HTML files(s)
html.highlight.theme
  type: string (default: not set)
  If set, set theme for syntax highlighting for HTML output (syntect only)
html.header
  type: string (default: not set)
  Custom header to display at the beginning of html file(s)
html.footer
  type: string (default: not set)
  Custom footer to display at the end of HTML file(s)
html.css
  type: template path (default: not set)
  Path of a stylesheet for HTML rendering
html.css.add
  type: string (default: not set)
  Some inline CSS added to the stylesheet template
html.css.colors
  type: template path (default: not set)
  Path of a stylesheet for the colors for HTML
html.js
  type: template path (default: not set)
  Path of a javascript file
html.css.print
  type: template path (default: not set)
  Path of a media print stylesheet for HTML rendering
html.highlight.js
  type: template path (default: not set)
  Set another highlight.js version than the bundled one
html.highlight.css
  type: template path (default: not set)
  Set another highlight.js CSS theme than the default one
html.side_notes
  type: boolean (default: false)
  Display footnotes as side notes in HTML/Epub (experimental)
html.escape_nb_spaces
  type: boolean (default: true)
  Replace unicode non breaking spaces with HTML entities and CSS
html.chapter.template
  type: string (default: "<h1 id = 'link-{{link}}'>{% if has_number %}<span class = 'chapter-header'>{{header}} {{number}}</span>{% if has_title %}<br />{% endif %}{% endif %}{{title}}</h1>")
  Inline template for HTML chapter formatting
html.part.template
  type: string (default: "<h2 class = 'part'>{{header}} {{number}}</h2> <h1 id = 'link-{{link}}' class = 'part'>{{title}}</h1>")
  Inline template for HTML part formatting

STANDALONE HTML OPTIONS
html.standalone.template
  type: template path (default: not set)
  Path of an HTML template for standalone HTML
html.standalone.one_chapter
  type: boolean (default: false)
  Display only one chapter at a time (with a button to display all)
html.standalone.js
  type: template path (default: not set)
  Path of a javascript file

MULTIFILE HTML OPTIONS
html.dir.template
  type: template path (default: not set)
  Path of a HTML template for multifile HTML

EPUB OPTIONS
epub.version
  type: integer (default: 2)
  EPUB version to generate (2 or 3)
epub.highlight.theme
  type: string (default: not set)
  If set, set theme for syntax highlighting for EPUB output (syntect only)
epub.css
  type: template path (default: not set)
  Path of a stylesheet for EPUB
epub.css.add
  type: string (default: not set)
  Inline CSS added to the EPUB stylesheet template
epub.chapter.xhtml
  type: template path (default: not set)
  Path of an xhtml template for each chapter
epub.titlepage.xhtml
  type: template path (default: not set)
  Path of an xhtml template for the title page
epub.toc.extras
  type: boolean (default: true)
  Add 'Title' and (if set) 'Cover' in the EPUB table of contents
epub.escape_nb_spaces
  type: boolean (default: true)
  Replace unicode non breaking spaces with HTML entities and CSS

LATEX OPTIONS
tex.cover
  type: boolean (default: false)
  Add cover to the LaTeX/PDF file
tex.highlight.theme
  type: string (default: not set)
  If set, set theme for syntax highlighting for LaTeX/PDF output (syntect only)
tex.links_as_footnotes
  type: boolean (default: true)
  Add foontotes to URL of links so they are readable when printed
tex.pageref_template
  type: string (default: "\\footnote{p\\pageref{<<key>>}}")
  Template (you can only use the '<<key>>' parameter) for the footnote (or
  something else) showing the page for the link
tex.command
  type: string (default: xelatex)
  LaTeX command to use for generating PDF
tex.escape_nb_spaces
  type: boolean (default: true)
  Replace unicode non breaking spaces with TeX code
tex.template
  type: template path (default: not set)
  Path of a LaTeX template file
tex.template.add
  type: string (default: not set)
  Inline code added in the LaTeX template
tex.class
  type: string (default: book)
  LaTeX class to use
tex.paper.size
  type: string (default: a5paper)
  Specifies the size of the page
tex.margin.left
  type: string (default: not set)
  Specifies left margin (note that with book class left and right margins are
  reversed for odd pages, thus the default value is 1.5cm for book class and
  2cm else)
tex.margin.right
  type: string (default: not set)
  Specifies right margin(note that with book class left and right margins are
  reversed for odd pages, thus the default value is 2.5cm for book class and
  2cm else)
tex.margin.top
  type: string (default: "2cm")
  Specifies top margin
tex.margin.bottom
  type: string (default: "1.5cm")
  Specifies bottom margin
tex.title
  type: boolean (default: true)
  If true, generate a title with \\maketitle
tex.font.size
  type: integer (default: not set)
  Specify latex font size (in pt, 10 (default), 11, or 12 are accepted)
tex.hyperref
  type: boolean (default: true)
  If disabled, don't try to find references inside the document
tex.stdpage
  type: boolean (default: false)
  If set to true, use 'stdpage' package to format a manuscript according to
  standards

RESOURCES OPTIONS
resources.files
  type: list of strings (default: not set)
  Whitespace-separated list of files to embed in e.g. EPUB file; useful for
  including e.g. fonts
resources.out_path
  type: path (default: data)
  Paths where additional resources should be copied in the EPUB file or HTML
  directory
resources.base_path
  type: path (default: not set)
  Path where to find resources (in the source tree). By default, links and
  images are relative to the Markdown file. If this is set, it will be to this
  path.
resources.base_path.links
  type: path (default: not set)
  Set base path but only for links. Useless if resources.base_path is set
resources.base_path.images
  type: path (default: .)
  Set base path but only for images. Useless if resources.base_path is set
resources.base_path.files
  type: path (default: .)
  Set base path but only for additional files. Useless if resources.base_path
  is set.
resources.base_path.templates
  type: path (default: .)
  Set base path but only for templates files. Useless if resources.base_path
  is set

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang
input.clean.smart_quotes
  type: boolean (default: true)
  If enabled, tries to replace vertical quotations marks to curly ones
input.clean.ligature.dashes
  type: boolean (default: false)
  If enabled, replaces '--' to en dash ('–') and '---' to em dash ('—')
input.clean.ligature.guillemets
  type: boolean (default: false)
  If enabled, replaces '<<' and '>>' to french "guillemets" ('«' and '»')
input.yaml_blocks
  type: boolean (default: false)
  Enable/disable inline YAML blocks to override options set in config file

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text. This avoids having <foo> being considered as
  HTML and thus ignored.
crowbook.files_mean_chapters
  type: boolean (default: not set)
  Consider that a new file is always a new chapter, even if it does not include
  heading (default: only for numbered chapters)
crowbook.markdown.superscript
  type: boolean (default: false)
  If enabled, allow support for superscript and subscript using respectively
  foo^up^  and bar~down~ syntax.
crowbook.temp_dir
  type: path (default: )
  Path where to create a temporary directory (default: uses result from Rust's
  std::env::temp_dir())
crowbook.zip.command
  type: string (default: zip)
  Command to use to zip files (for EPUB/ODT)

`

func init() {
	_ = sort.Strings
}
