module crowbookclone

go 1.21
