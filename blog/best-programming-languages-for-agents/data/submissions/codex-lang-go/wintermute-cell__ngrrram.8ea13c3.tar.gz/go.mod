module ngrrram

go 1.21
