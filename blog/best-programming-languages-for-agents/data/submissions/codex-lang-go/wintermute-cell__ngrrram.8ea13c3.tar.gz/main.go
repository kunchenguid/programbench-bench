package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"
)

const helpText = `Usage: executable [OPTIONS]

Options:
  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]
  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]
  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]
  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]
  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]
  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]
      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]
      --show-ortho        show keyboard in ortholinear format
      --nokb              pass this flag to disable the keyboard layout display.
      --cat               the most important flag. don't practice alone.
  -h, --help              Print help`

type config struct {
	n         string
	top       int
	combi     int
	rep       int
	wpm       int
	acc       int
	emuIn     string
	emuOut    string
	showOrtho bool
	nokb      bool
	cat       bool
}

var bigrams = []string{"th", "he", "in", "er", "an", "re", "on", "at", "en", "nd", "ti", "es", "or", "te", "of", "ed", "is", "it", "al", "ar", "st", "to", "nt", "ng", "se", "ha", "as", "ou", "io", "le", "ve", "co", "me", "de", "hi", "ri", "ro", "ic", "ne", "ea", "ra", "ce", "li", "ch", "ll", "be", "ma", "si", "om", "ur"}
var trigrams = []string{"the", "and", "ing", "ion", "tio", "ent", "ati", "for", "her", "ter", "hat", "tha", "ere", "ate", "his", "con", "res", "ver", "all", "ons", "nce", "men", "ith", "ted", "ers", "pro", "thi", "wit", "are", "ess", "not", "ive", "was", "ect", "rea", "com", "eve", "per", "int", "est", "sta", "cti", "ica", "ist", "ear", "ain", "one", "our", "iti", "rat"}
var tetragrams = []string{"tion", "ther", "that", "with", "ment", "ions", "this", "here", "from", "ould", "ting", "hich", "whic", "ctio", "ence", "have", "othe", "ight", "sion", "ever", "ical", "they", "inte", "ough", "ance", "were", "tive", "over", "ding", "pres", "nter", "comp", "able", "heir", "ally", "ated", "ring", "ress", "cons", "thin", "part", "form", "ning", "lect", "atio", "more", "esta", "some", "ship", "self"}
var words = []string{"the", "of", "and", "to", "in", "a", "is", "that", "for", "it", "as", "was", "with", "be", "by", "on", "not", "he", "i", "this", "are", "or", "his", "from", "at", "which", "but", "have", "an", "had", "they", "you", "were", "their", "one", "all", "we", "can", "her", "has", "there", "been", "if", "more", "when", "will", "would", "who", "so", "no"}

func main() {
	cfg, code := parse(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}
	if err := validate(&cfg); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	run(cfg)
}

func parse(args []string) (config, int) {
	cfg := config{n: "2", top: 50, combi: 2, rep: 3, wpm: 40, acc: 94}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch arg {
		case "-h", "--help":
			fmt.Println(helpText)
			return cfg, 0
		case "-n", "--n":
			if i+1 >= len(args) {
				valueRequired("--n <2|3|4|w|file>")
				return cfg, 2
			}
			i++
			cfg.n = args[i]
		case "-t", "--top":
			v, ok := parseIntArg(args, &i, "--top <1-200>")
			if !ok {
				return cfg, 2
			}
			cfg.top = v
		case "-c", "--combi":
			v, ok := parseIntArg(args, &i, "--combi <1-200>")
			if !ok {
				return cfg, 2
			}
			cfg.combi = v
		case "-r", "--rep":
			v, ok := parseIntArg(args, &i, "--rep <number>")
			if !ok {
				return cfg, 2
			}
			cfg.rep = v
		case "-w", "--wpm":
			v, ok := parseIntArg(args, &i, "--wpm <number>")
			if !ok {
				return cfg, 2
			}
			cfg.wpm = v
		case "-a", "--acc":
			v, ok := parseIntArg(args, &i, "--acc <0-100>")
			if !ok {
				return cfg, 2
			}
			cfg.acc = v
		case "--emu-in":
			if i+1 >= len(args) {
				valueRequired("--emu-in <layout>")
				return cfg, 2
			}
			i++
			cfg.emuIn = args[i]
		case "--emu-out":
			if i+1 >= len(args) {
				valueRequired("--emu-out <layout>")
				return cfg, 2
			}
			i++
			cfg.emuOut = args[i]
		case "--show-ortho":
			cfg.showOrtho = true
		case "--nokb":
			cfg.nokb = true
		case "--cat":
			cfg.cat = true
		default:
			if strings.HasPrefix(arg, "-") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", arg)
				return cfg, 2
			}
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", arg)
			return cfg, 2
		}
	}
	return cfg, -1
}

func parseIntArg(args []string, i *int, spec string) (int, bool) {
	if *i+1 >= len(args) {
		valueRequired(spec)
		return 0, false
	}
	*i = *i + 1
	s := args[*i]
	v, err := strconv.Atoi(s)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s': invalid digit found in string\n\nFor more information, try '--help'.\n", s, spec)
		return 0, false
	}
	return v, true
}

func valueRequired(spec string) {
	fmt.Fprintf(os.Stderr, "error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.\n", spec)
}

func validate(cfg *config) error {
	if cfg.top < 1 || cfg.top > 200 {
		return fmt.Errorf("Invalid argument for top. Use a number between 1 and 200.")
	}
	if cfg.combi < 1 || cfg.combi > 200 {
		return fmt.Errorf("Invalid argument for combi. Use a number between 1 and 200.")
	}
	if cfg.rep < 1 || cfg.rep > 200 {
		return fmt.Errorf("Invalid argument for rep. Use a number between 1 and 200.")
	}
	if cfg.wpm < 1 || cfg.wpm > 200 {
		return fmt.Errorf("Invalid argument for wpm. Use a number between 1 and 200.")
	}
	if cfg.acc < 0 || cfg.acc > 100 {
		return fmt.Errorf("Invalid argument for acc. Use a number between 0 and 100.")
	}
	if (cfg.emuIn == "") != (cfg.emuOut == "") {
		return fmt.Errorf("You need to specify both emu_in and emu_out.")
	}
	if !isBuiltInMode(cfg.n) {
		if _, err := os.Stat(cfg.n); err != nil {
			return fmt.Errorf("File not found: %s", cfg.n)
		}
	}
	return nil
}

func isBuiltInMode(n string) bool {
	return n == "2" || n == "3" || n == "4" || n == "w"
}

func run(cfg config) {
	pool := listFor(cfg)
	if len(pool) == 0 {
		pool = bigrams
	}
	if cfg.top < len(pool) {
		pool = pool[:cfg.top]
	}
	lesson := makeLesson(pool, cfg.combi, cfg.rep)
	if isTerminal() {
		fmt.Print("\033[?1049h\033[2J\033[?25l")
		defer fmt.Print("\033[?25h\033[?1049l")
	}
	draw(cfg, lesson)
	readLoop(lesson, cfg)
}

func listFor(cfg config) []string {
	switch cfg.n {
	case "2":
		return bigrams
	case "3":
		return trigrams
	case "4":
		return tetragrams
	case "w":
		return words
	default:
		b, err := os.ReadFile(cfg.n)
		if err != nil {
			return nil
		}
		fields := strings.FieldsFunc(string(b), func(r rune) bool {
			return r == ',' || r == '\n' || r == '\r' || r == '\t' || r == ' '
		})
		out := make([]string, 0, len(fields))
		for _, f := range fields {
			if f = strings.TrimSpace(f); f != "" {
				out = append(out, f)
			}
		}
		return out
	}
}

func makeLesson(pool []string, combi, rep int) string {
	r := rand.New(rand.NewSource(time.Now().UnixNano()))
	seen := map[int]bool{}
	chosen := make([]string, 0, combi)
	for len(chosen) < combi && len(chosen) < len(pool) {
		idx := r.Intn(len(pool))
		if !seen[idx] {
			seen[idx] = true
			chosen = append(chosen, pool[idx])
		}
	}
	parts := make([]string, 0, len(chosen)*rep)
	for i := 0; i < rep; i++ {
		for _, s := range chosen {
			parts = append(parts, s)
		}
	}
	return strings.Join(parts, " ")
}

func draw(cfg config, lesson string) {
	fmt.Print("\033[H")
	if cfg.cat {
		fmt.Println(" /\\_/\\\\")
		fmt.Println("( o.o )")
		fmt.Println(" > ^ <")
		fmt.Println()
	}
	fmt.Println(lesson)
	fmt.Println()
	fmt.Printf("wpm: 0/%d  acc: 100/%d\n", cfg.wpm, cfg.acc)
	if cfg.emuIn != "" {
		fmt.Printf("emulating %s -> %s\n", cfg.emuIn, cfg.emuOut)
	}
	if !cfg.nokb {
		fmt.Println()
		if cfg.showOrtho {
			fmt.Println("q w e r t y u i o p")
			fmt.Println("a s d f g h j k l ;")
			fmt.Println("z x c v b n m , . /")
		} else {
			fmt.Println("` 1 2 3 4 5 6 7 8 9 0 - =")
			fmt.Println("  q w e r t y u i o p [ ]")
			fmt.Println("   a s d f g h j k l ; '")
			fmt.Println("    z x c v b n m , . /")
		}
	}
	fmt.Println()
	fmt.Print("> ")
}

func readLoop(lesson string, cfg config) {
	reader := bufio.NewReader(os.Stdin)
	start := time.Time{}
	typed := strings.Builder{}
	for {
		r, _, err := reader.ReadRune()
		if err != nil {
			return
		}
		if r == 3 || r == 4 || r == 27 {
			return
		}
		if start.IsZero() && r != '\n' && r != '\r' {
			start = time.Now()
		}
		if r == '\r' || r == '\n' {
			break
		}
		typed.WriteRune(r)
		fmt.Print(string(r))
		if typed.String() == lesson {
			break
		}
	}
	elapsed := time.Since(start).Seconds()
	if elapsed <= 0 {
		elapsed = 1
	}
	acc := accuracy(typed.String(), lesson)
	wpm := int(float64(len([]rune(typed.String())))/5.0/(elapsed/60.0) + 0.5)
	fmt.Printf("\n\nwpm: %d/%d  acc: %d/%d\n", wpm, cfg.wpm, acc, cfg.acc)
	if wpm >= cfg.wpm && acc >= cfg.acc {
		fmt.Println("Success!")
	} else {
		fmt.Println("Try again.")
	}
}

func accuracy(got, want string) int {
	gr := []rune(got)
	wr := []rune(want)
	total := len(wr)
	if len(gr) > total {
		total = len(gr)
	}
	if total == 0 {
		return 100
	}
	ok := 0
	for i := 0; i < len(gr) && i < len(wr); i++ {
		if gr[i] == wr[i] {
			ok++
		}
	}
	return int(float64(ok)/float64(total)*100 + 0.5)
}

func isTerminal() bool {
	st, err := os.Stdin.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) != 0
}
