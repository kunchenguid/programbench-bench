package main

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const version = "2.11.0"

const banner = ` _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|
`

const help = banner + `
monolith 2.11.0

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version
`

type options struct {
	noAudio, blacklist, noCSS, ignoreErrors, noFrames, noFonts bool
	noImages, isolate, noJS, insecure, mhtml, noMetadata       bool
	unwrapNoscript, quiet, noVideo                             bool
	baseURL, cookieFile, encoding, output, userAgent           string
	timeout                                                    int
	domains                                                    []string
	target                                                     string
}

var attrRECache = map[string]*regexp.Regexp{}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprint(os.Stderr, err.Error())
		os.Exit(2)
	}
	if opts.timeout == 0 {
		opts.timeout = 60
	}

	input, base, source, err := loadTarget(opts)
	if err != nil {
		if !opts.quiet && source != "" {
			fmt.Fprintln(os.Stderr, source, "("+err.Error()+")")
		}
		fmt.Fprintln(os.Stderr, "Error: could not retrieve target document")
		os.Exit(1)
	}
	html := string(input)
	html = processHTML(html, base, opts)
	if !opts.noMetadata {
		stamp := time.Now().UTC().Format(time.RFC3339)
		src := "local source"
		if strings.HasPrefix(source, "http://") || strings.HasPrefix(source, "https://") {
			src = source
		}
		html = fmt.Sprintf("<!-- Saved from %s at %s using monolith v%s -->\n%s", src, stamp, version, html)
	}
	if opts.mhtml {
		html = mhtmlWrap(html, opts)
	}

	out := opts.output
	if out == "" || out == "-" {
		fmt.Print(html)
		return
	}
	out = expandOutputName(out, html)
	if err := os.WriteFile(out, []byte(html), 0644); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, error) {
	var o options
	needValue := func(name string, i *int) (string, error) {
		if *i+1 >= len(args) {
			return "", fmt.Errorf("error: a value is required for '%s' but none was supplied\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.\n", name)
		}
		*i++
		return args[*i], nil
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			if i+1 < len(args) {
				o.target = args[i+1]
				if i+2 < len(args) {
					return o, unexpected(args[i+2])
				}
			}
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			if o.target != "" {
				return o, unexpected(a)
			}
			o.target = a
			continue
		}
		switch {
		case a == "-h" || a == "--help":
			fmt.Print(help)
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Println("monolith", version)
			os.Exit(0)
		case strings.HasPrefix(a, "--"):
			name, val, has := strings.Cut(a, "=")
			set := func(v string) { val, has = v, true }
			switch name {
			case "--no-audio":
				o.noAudio = true
			case "--base-url":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.baseURL = val
			case "--blacklist-domains":
				o.blacklist = true
			case "--no-css":
				o.noCSS = true
			case "--cookie-file":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.cookieFile = val
			case "--domain":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.domains = append(o.domains, val)
			case "--ignore-errors":
				o.ignoreErrors = true
			case "--encoding":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.encoding = val
			case "--no-frames":
				o.noFrames = true
			case "--no-fonts":
				o.noFonts = true
			case "--no-images":
				o.noImages = true
			case "--isolate":
				o.isolate = true
			case "--no-js":
				o.noJS = true
			case "--insecure":
				o.insecure = true
			case "--mhtml":
				o.mhtml = true
			case "--no-metadata":
				o.noMetadata = true
			case "--unwrap-noscript":
				o.unwrapNoscript = true
			case "--output":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.output = val
			case "--quiet":
				o.quiet = true
			case "--timeout":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.timeout, _ = strconv.Atoi(val)
			case "--user-agent":
				if !has {
					v, e := needValue(name, &i)
					if e != nil {
						return o, e
					}
					set(v)
				}
				o.userAgent = val
			case "--no-video":
				o.noVideo = true
			default:
				return o, unexpected(a)
			}
		default:
			shorts := []rune(a[1:])
			for j := 0; j < len(shorts); j++ {
				c := shorts[j]
				valueRest := func() (string, error) {
					if j+1 < len(shorts) {
						return string(shorts[j+1:]), nil
					}
					return needValue("-"+string(c), &i)
				}
				switch c {
				case 'a':
					o.noAudio = true
				case 'b':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.baseURL = v
					j = len(shorts)
				case 'B':
					o.blacklist = true
				case 'c':
					o.noCSS = true
				case 'C':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.cookieFile = v
					j = len(shorts)
				case 'd':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.domains = append(o.domains, v)
					j = len(shorts)
				case 'e':
					o.ignoreErrors = true
				case 'E':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.encoding = v
					j = len(shorts)
				case 'f':
					o.noFrames = true
				case 'F':
					o.noFonts = true
				case 'i':
					o.noImages = true
				case 'I':
					o.isolate = true
				case 'j':
					o.noJS = true
				case 'k':
					o.insecure = true
				case 'm':
					o.mhtml = true
				case 'M':
					o.noMetadata = true
				case 'n':
					o.unwrapNoscript = true
				case 'o':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.output = v
					j = len(shorts)
				case 'q':
					o.quiet = true
				case 't':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.timeout, _ = strconv.Atoi(v)
					j = len(shorts)
				case 'u':
					v, e := valueRest()
					if e != nil {
						return o, e
					}
					o.userAgent = v
					j = len(shorts)
				case 'v':
					o.noVideo = true
				default:
					return o, unexpected("-" + string(c))
				}
			}
		}
	}
	if o.target == "" {
		return o, fmt.Errorf("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.\n")
	}
	return o, nil
}

func unexpected(a string) error {
	return fmt.Errorf("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.\n", a, a, a)
}

func loadTarget(o options) ([]byte, string, string, error) {
	if o.target == "-" {
		b, err := io.ReadAll(os.Stdin)
		base := o.baseURL
		if base == "" {
			base = "http://example.com/"
		}
		return b, ensureBase(base), "standard input", err
	}
	if u, err := url.Parse(o.target); err == nil && (u.Scheme == "http" || u.Scheme == "https") {
		b, err := fetchURL(o.target, o)
		return b, ensureBase(o.target), o.target, err
	}
	if _, err := os.Stat(o.target); err == nil {
		b, err := os.ReadFile(o.target)
		abs, _ := filepath.Abs(o.target)
		base := o.baseURL
		if base == "" {
			base = fileURL(filepath.Dir(abs)) + "/"
		}
		return b, ensureBase(base), "local source", err
	}
	u := "http://" + o.target
	b, err := fetchURL(u, o)
	return b, ensureBase(u), u, err
}

func fetchURL(s string, o options) ([]byte, error) {
	tr := &http.Transport{}
	if o.insecure {
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
	client := &http.Client{Timeout: time.Duration(o.timeout) * time.Second, Transport: tr}
	req, _ := http.NewRequest("GET", s, nil)
	if o.userAgent != "" {
		req.Header.Set("User-Agent", o.userAgent)
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf(resp.Status)
	}
	return io.ReadAll(resp.Body)
}

func processHTML(html, base string, o options) string {
	if o.unwrapNoscript {
		html = regexp.MustCompile(`(?is)<noscript[^>]*>(.*?)</noscript>`).ReplaceAllString(html, `$1`)
	}
	html = transformTagAttr(html, "a", "href", func(v string) string {
		if o.isolate {
			return "data:,"
		}
		return absURL(base, v)
	})
	html = transformTagAttr(html, "link", "href", func(v string) string {
		if o.noCSS {
			return ""
		}
		if strings.Contains(strings.ToLower(currentTag), `rel="stylesheet"`) || strings.Contains(strings.ToLower(currentTag), `rel=stylesheet`) {
			return dataForCSS(base, v, o)
		}
		return absURL(base, v)
	})
	html = transformTagAttr(html, "img", "src", func(v string) string {
		if o.noImages {
			return transparentPNG
		}
		return dataFor(base, v, o, "")
	})
	html = transformScripts(html, base, o)
	if o.noJS || o.mhtml {
		html = regexp.MustCompile(`(?is)<script([^>]*)>.*?</script>`).ReplaceAllString(html, `<script$1></script>`)
	}
	html = transformTagAttr(html, "iframe", "src", func(v string) string {
		if o.noFrames {
			return ""
		}
		return dataFor(base, v, o, "text/html")
	})
	html = transformTagAttr(html, "frame", "src", func(v string) string {
		if o.noFrames {
			return ""
		}
		return dataFor(base, v, o, "text/html")
	})
	html = transformTagAttr(html, "audio", "src", func(v string) string {
		if o.noAudio {
			return ""
		}
		return dataFor(base, v, o, "")
	})
	html = transformTagAttr(html, "video", "src", func(v string) string {
		if o.noVideo {
			return ""
		}
		return dataFor(base, v, o, "")
	})
	html = transformStyleBlocks(html, base, o)
	html = transformStyleAttrs(html, base, o)
	if o.noCSS {
		html = regexp.MustCompile(`(?is)<style[^>]*>.*?</style>`).ReplaceAllStringFunc(html, func(s string) string {
			i := strings.Index(s, ">")
			return s[:i+1] + "</style>"
		})
	}
	html = addHeadMeta(html, cspContent(o))
	return html
}

var currentTag string

func transformTagAttr(html, tag, attr string, fn func(string) string) string {
	re := regexp.MustCompile(`(?is)<` + tag + `\b[^>]*>`)
	return re.ReplaceAllStringFunc(html, func(t string) string {
		currentTag = t
		return replaceAttr(t, attr, fn)
	})
}

func replaceAttr(tag, attr string, fn func(string) string) string {
	re := attrRegex(attr)
	loc := re.FindStringSubmatchIndex(tag)
	if loc == nil {
		return tag
	}
	start, end := -1, -1
	for i := 2; i+1 < len(loc); i += 2 {
		if loc[i] >= 0 {
			start, end = loc[i], loc[i+1]
			break
		}
	}
	if start < 0 {
		return tag
	}
	old := tag[start:end]
	newv := fn(htmlUnescape(old))
	if strings.HasPrefix(newv, "__INLINE_SCRIPT__") {
		return re.ReplaceAllString(tag, "")
	}
	if newv == "" {
		return re.ReplaceAllString(tag, attr)
	}
	return tag[:start] + htmlEscape(newv) + tag[end:]
}

func attrRegex(attr string) *regexp.Regexp {
	if r := attrRECache[attr]; r != nil {
		return r
	}
	r := regexp.MustCompile(`(?is)\b` + regexp.QuoteMeta(attr) + `\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))`)
	attrRECache[attr] = r
	return r
}

func transformScripts(html, base string, o options) string {
	re := regexp.MustCompile(`(?is)<script([^>]*)\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))([^>]*)></script>`)
	return re.ReplaceAllStringFunc(html, func(s string) string {
		m := re.FindStringSubmatch(s)
		src := firstNonEmpty(m[2], m[3], m[4])
		attrs := strings.TrimSpace(m[1] + m[5])
		if attrs != "" {
			attrs = " " + attrs
		}
		if o.noJS || o.mhtml {
			return "<script" + attrs + "></script>"
		}
		return "<script" + attrs + ">" + dataForRaw(base, src, o) + "</script>"
	})
}

func transformStyleBlocks(html, base string, o options) string {
	re := regexp.MustCompile(`(?is)<style([^>]*)>(.*?)</style>`)
	return re.ReplaceAllStringFunc(html, func(s string) string {
		m := re.FindStringSubmatch(s)
		css := rewriteCSSURLs(m[2], base, o)
		if o.noCSS {
			css = ""
		}
		return "<style" + m[1] + ">" + css + "</style>"
	})
}

func transformStyleAttrs(html, base string, o options) string {
	re := regexp.MustCompile(`(?is)\bstyle\s*=\s*"([^"]*)"`)
	html = re.ReplaceAllStringFunc(html, func(s string) string {
		m := re.FindStringSubmatch(s)
		if o.noCSS {
			return `style`
		}
		return `style="` + htmlEscape(rewriteCSSURLs(htmlUnescape(m[1]), base, o)) + `"`
	})
	return html
}

func rewriteCSSURLs(css, base string, o options) string {
	if o.noCSS {
		return ""
	}
	re := regexp.MustCompile(`(?is)url\(\s*["']?([^'")]+)["']?\s*\)`)
	return re.ReplaceAllStringFunc(css, func(s string) string {
		m := re.FindStringSubmatch(s)
		u := strings.TrimSpace(m[1])
		if o.noFonts && looksFont(u) {
			return `url("")`
		}
		return `url("` + dataFor(base, u, o, "") + `")`
	})
}

func addHeadMeta(html, csp string) string {
	inserts := ""
	if csp != "" {
		inserts += `<meta http-equiv="Content-Security-Policy" content="` + csp + `"></meta>`
	}
	inserts += `<meta name="robots" content="none"></meta>`
	re := regexp.MustCompile(`(?is)<head[^>]*>`)
	if loc := re.FindStringIndex(html); loc != nil {
		return html[:loc[1]] + inserts + html[loc[1]:]
	}
	return inserts + html
}

func cspContent(o options) string {
	parts := []string{}
	if o.noCSS {
		parts = append(parts, "style-src 'none'")
	}
	if o.noFrames {
		parts = append(parts, "frame-src 'none'", "child-src 'none'")
	}
	if o.noJS || o.mhtml {
		parts = append(parts, "script-src 'none'")
	}
	if o.noImages {
		parts = append(parts, "img-src data:")
	}
	if o.isolate && len(parts) == 0 {
		parts = append(parts, "default-src 'none'", "img-src data:", "style-src 'unsafe-inline' data:", "font-src data:")
	}
	if len(parts) == 0 {
		return ""
	}
	return strings.Join(parts, ";") + ";"
}

func dataFor(base, ref string, o options, forcedType string) string {
	if strings.HasPrefix(ref, "data:") || strings.HasPrefix(ref, "javascript:") || strings.HasPrefix(ref, "mailto:") {
		return ref
	}
	data, final, err := readResource(base, ref, o)
	if err != nil {
		if o.ignoreErrors {
			data = nil
		} else {
			data = nil
		}
	}
	mt := forcedType
	if mt == "" {
		mt = mimeType(final)
	}
	return "data:" + mt + ";base64," + base64.StdEncoding.EncodeToString(data)
}

func dataForCSS(base, ref string, o options) string {
	data, final, err := readResource(base, ref, o)
	if err != nil && !o.ignoreErrors {
		data = nil
	}
	cssBase := ensureBase(final)
	if !strings.HasPrefix(cssBase, "http://") && !strings.HasPrefix(cssBase, "https://") && !strings.HasPrefix(cssBase, "file://") {
		if abs, err := filepath.Abs(final); err == nil {
			cssBase = fileURL(filepath.Dir(abs)) + "/"
		}
	}
	css := rewriteCSSURLs(string(data), cssBase, o)
	return "data:text/css;base64," + base64.StdEncoding.EncodeToString([]byte(css))
}

func dataForRaw(base, ref string, o options) string {
	b, _, err := readResource(base, ref, o)
	if err != nil {
		return ""
	}
	return string(b)
}

func readResource(base, ref string, o options) ([]byte, string, error) {
	abs := absURL(base, ref)
	u, err := url.Parse(abs)
	if err == nil && (u.Scheme == "http" || u.Scheme == "https") {
		if !domainPermitted(u.Hostname(), o) {
			return nil, abs, fmt.Errorf("domain blocked")
		}
		b, err := fetchURL(abs, o)
		return b, abs, err
	}
	if err == nil && u.Scheme == "file" {
		p, _ := url.PathUnescape(u.Path)
		b, err := os.ReadFile(p)
		return b, p, err
	}
	b, err := os.ReadFile(ref)
	return b, ref, err
}

func domainPermitted(host string, o options) bool {
	if len(o.domains) == 0 {
		return true
	}
	match := false
	for _, d := range o.domains {
		d = strings.ToLower(strings.TrimSpace(d))
		h := strings.ToLower(host)
		if d == "" {
			continue
		}
		if strings.HasPrefix(d, ".") {
			match = strings.HasSuffix(h, d) || h == strings.TrimPrefix(d, ".")
		} else {
			match = h == d || strings.HasSuffix(h, "."+d)
		}
		if match {
			break
		}
	}
	if o.blacklist {
		return !match
	}
	return match
}

func absURL(base, ref string) string {
	if ref == "" {
		return ref
	}
	u, err := url.Parse(ref)
	if err == nil && u.IsAbs() {
		return ref
	}
	b, err := url.Parse(ensureBase(base))
	if err != nil {
		return ref
	}
	return b.ResolveReference(&url.URL{Path: ref}).String()
}

func ensureBase(s string) string {
	if s == "" {
		return "http://example.com/"
	}
	if strings.HasPrefix(s, "file://") {
		if !strings.HasSuffix(s, "/") && filepath.Ext(s) == "" {
			s += "/"
		}
		return s
	}
	u, err := url.Parse(s)
	if err == nil && u.Scheme != "" {
		if !strings.HasSuffix(u.Path, "/") {
			u.Path = pathDir(u.Path) + "/"
		}
		return u.String()
	}
	return s
}

func pathDir(p string) string {
	i := strings.LastIndex(p, "/")
	if i < 0 {
		return ""
	}
	if i == 0 {
		return "/"
	}
	return p[:i]
}

func fileURL(path string) string {
	abs, _ := filepath.Abs(path)
	return "file://" + (&url.URL{Path: filepath.ToSlash(abs)}).EscapedPath()
}

func mimeType(name string) string {
	ext := strings.ToLower(filepath.Ext(name))
	switch ext {
	case ".css":
		return "text/css"
	case ".js", ".mjs":
		return "text/javascript"
	case ".html", ".htm":
		return "text/html"
	case ".svg":
		return "image/svg+xml"
	case ".png":
		return "image/png"
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".gif":
		return "image/gif"
	case ".webp":
		return "image/webp"
	case ".woff":
		return "font/woff"
	case ".woff2":
		return "font/woff2"
	case ".ttf":
		return "font/ttf"
	case ".otf":
		return "font/otf"
	case ".mp3":
		return "audio/mpeg"
	case ".mp4":
		return "video/mp4"
	case ".txt":
		return "text/plain"
	}
	if mt := mime.TypeByExtension(ext); mt != "" {
		return strings.Split(mt, ";")[0]
	}
	return "text/plain"
}

func looksFont(u string) bool {
	ext := strings.ToLower(filepath.Ext(strings.Split(u, "?")[0]))
	return ext == ".woff" || ext == ".woff2" || ext == ".ttf" || ext == ".otf" || ext == ".eot"
}

func expandOutputName(pattern, html string) string {
	title := ""
	re := regexp.MustCompile(`(?is)<title[^>]*>(.*?)</title>`)
	if m := re.FindStringSubmatch(html); m != nil {
		title = strings.TrimSpace(stripTags(m[1]))
	}
	ts := strings.ReplaceAll(time.Now().UTC().Format(time.RFC3339), ":", "_")
	pattern = strings.ReplaceAll(pattern, "%title%", title)
	pattern = strings.ReplaceAll(pattern, "%timestamp%", ts)
	return pattern
}

func stripTags(s string) string {
	return regexp.MustCompile(`(?is)<[^>]+>`).ReplaceAllString(s, "")
}

func mhtmlWrap(html string, o options) string {
	var b bytes.Buffer
	b.WriteString("MIME-Version: 1.0\r\n")
	b.WriteString("Content-Type: multipart/related; boundary=\"----=_NextPart_000_0000\"\r\n\r\n")
	b.WriteString("------=_NextPart_000_0000\r\n")
	b.WriteString("Content-Type: text/html; charset=\"utf-8\"\r\n")
	b.WriteString("Content-Location: http://example.com/\r\n\r\n")
	b.WriteString(html)
	b.WriteString("\r\n------=_NextPart_000_0000--\r\n")
	return b.String()
}

func firstNonEmpty(xs ...string) string {
	for _, x := range xs {
		if x != "" {
			return x
		}
	}
	return ""
}

func htmlEscape(s string) string {
	r := strings.NewReplacer("&", "&amp;", `"`, "&quot;", "<", "&lt;", ">", "&gt;")
	return r.Replace(s)
}

func htmlUnescape(s string) string {
	r := strings.NewReplacer("&quot;", `"`, "&#34;", `"`, "&apos;", "'", "&#39;", "'", "&amp;", "&")
	return r.Replace(s)
}

const transparentPNG = "data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82"
