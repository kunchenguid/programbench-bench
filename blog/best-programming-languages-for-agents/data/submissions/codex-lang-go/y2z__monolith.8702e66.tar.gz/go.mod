module monolith-reimpl

go 1.21
