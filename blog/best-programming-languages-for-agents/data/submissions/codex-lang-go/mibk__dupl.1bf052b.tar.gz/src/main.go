package main

import (
    "bufio"
    "bytes"
    "flag"
    "fmt"
    "go/ast"
    "go/parser"
    "go/token"
    "html"
    "io/fs"
    "log"
    "os"
    "path/filepath"
    "reflect"
    "sort"
    "strings"
)

const fullUsage = `Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    	read file names from stdin one at each line
  -html
    	output the results as HTML, including duplicate code fragments
  -plumbing
    	plumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    	minimum token sequence size as a clone (default 15)
  -vendor
    	check files in vendor directory
  -v, -verbose
    	explain what is being done

Examples:
  dupl -t 100
    	Search clones in the current directory of size at least
    	100 tokens.
  dupl $(find app/ -name '*_test.go')
    	Search for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    	The same as above.
`

type options struct { files, html, plumbing, vendor, verbose bool; threshold int }
type elem struct { key string; file string; start token.Pos; end token.Pos; sentinel bool }
type occ struct { start, end int }
type group struct { occs []occ; length int }

var fset = token.NewFileSet()
var source = map[string]string{}

func main() {
    log.SetFlags(log.LstdFlags)
    var opt options
    fsFlags := flag.NewFlagSet("dupl", flag.ExitOnError)
    fsFlags.BoolVar(&opt.files, "files", false, "read file names from stdin one at each line")
    fsFlags.BoolVar(&opt.html, "html", false, "output the results as HTML, including duplicate code fragments")
    fsFlags.BoolVar(&opt.plumbing, "plumbing", false, "plumbing (easy-to-parse) output for consumption by scripts or tools")
    fsFlags.IntVar(&opt.threshold, "t", 15, "minimum token sequence size as a clone")
    fsFlags.IntVar(&opt.threshold, "threshold", 15, "minimum token sequence size as a clone")
    fsFlags.BoolVar(&opt.vendor, "vendor", false, "check files in vendor directory")
    fsFlags.BoolVar(&opt.verbose, "v", false, "explain what is being done")
    fsFlags.BoolVar(&opt.verbose, "verbose", false, "explain what is being done")
    fsFlags.Usage = func() { fmt.Fprint(os.Stderr, fullUsage) }
    if err := fsFlags.Parse(os.Args[1:]); err != nil { os.Exit(2) }

    paths, err := collectPaths(fsFlags.Args(), opt)
    if err != nil { log.Fatal(err) }
    var seq []elem
    for _, p := range paths {
        addFile(p, &seq)
        seq = append(seq, elem{key: fmt.Sprintf("\xff%s", p), sentinel: true})
    }
    if opt.verbose { log.Print("Building suffix tree") }
    if opt.verbose { log.Print("Searching for clones") }
    groups := findGroups(seq, opt.threshold)
    output(groups, seq, opt)
}

func collectPaths(args []string, opt options) ([]string, error) {
    if opt.files {
        sc := bufio.NewScanner(os.Stdin)
        for sc.Scan() { if s := strings.TrimSpace(sc.Text()); s != "" { args = append(args, s) } }
        if err := sc.Err(); err != nil { return nil, err }
    }
    if len(args) == 0 { args = []string{"."} }
    var out []string
    for _, p := range args {
        info, err := os.Stat(p); if err != nil { return nil, err }
        if !info.IsDir() { out = append(out, filepath.Clean(p)); continue }
        filepath.WalkDir(p, func(path string, d fs.DirEntry, err error) error {
            if err != nil { log.Print(err); return nil }
            if d.IsDir() {
                if !opt.vendor && d.Name() == "vendor" { return filepath.SkipDir }
                if strings.HasPrefix(d.Name(), ".") && path != "." { return filepath.SkipDir }
                return nil
            }
            if strings.HasSuffix(d.Name(), ".go") { out = append(out, filepath.Clean(path)) }
            return nil
        })
    }
    sort.Strings(out)
    return out, nil
}

func addFile(path string, seq *[]elem) {
    b, err := os.ReadFile(path); if err == nil { source[path] = string(b) }
    file, err := parser.ParseFile(fset, path, b, parser.ParseComments)
    if err != nil { log.Print(err); return }
    for _, decl := range file.Decls {
    ast.Inspect(decl, func(n ast.Node) bool {
        if n == nil { return true }
        key := nodeKey(n)
        if key == "" { return true }
        *seq = append(*seq, elem{key:key, file:path, start:n.Pos(), end:n.End()})
        return true
    })
    }
}

func nodeKey(n ast.Node) string {
    switch x := n.(type) {
    case *ast.File:
        return ""
    case *ast.Ident:
        if x.Name == "_" { return "Ident:_" }
        return "Ident"
    case *ast.BasicLit:
        return "BasicLit:"+x.Kind.String()
    case *ast.BinaryExpr:
        return "BinaryExpr:"+x.Op.String()
    case *ast.UnaryExpr:
        return "UnaryExpr:"+x.Op.String()
    case *ast.AssignStmt:
        return "AssignStmt:"+x.Tok.String()
    case *ast.IncDecStmt:
        return "IncDecStmt:"+x.Tok.String()
    case *ast.BranchStmt:
        return "BranchStmt:"+x.Tok.String()
    case *ast.RangeStmt:
        return "RangeStmt:"+x.Tok.String()
    case *ast.GenDecl:
        return "GenDecl:"+x.Tok.String()
    case *ast.ValueSpec:
        return "ValueSpec"
    case *ast.TypeSpec:
        return "TypeSpec"
    case *ast.FuncDecl:
        return "FuncDecl"
    case *ast.FuncLit:
        return "FuncLit"
    case *ast.CallExpr:
        return "CallExpr"
    case *ast.SelectorExpr:
        return "SelectorExpr"
    }
    t := reflect.TypeOf(n)
    if t == nil { return "" }
    return strings.TrimPrefix(t.String(), "*ast.")
}

func findGroups(seq []elem, threshold int) []group {
    if threshold < 1 { threshold = 1 }
    n := len(seq)
    buckets := map[string][]int{}
    for i:=0; i+threshold<=n; i++ {
        if crosses(seq, i, threshold) { continue }
        var b strings.Builder
        for j:=0;j<threshold;j++ { b.WriteString(seq[i+j].key); b.WriteByte(0) }
        buckets[b.String()] = append(buckets[b.String()], i)
    }
    seen := map[string]map[int]bool{}
    cand := map[string]map[int]occ{}
    for _, starts := range buckets {
        if len(starts) < 2 { continue }
        for a:=0; a<len(starts); a++ { for b:=a+1; b<len(starts); b++ {
            i,j := starts[a], starts[b]
            if i==j { continue }
            l:=0
            for i+l<n && j+l<n && !seq[i+l].sentinel && !seq[j+l].sentinel && seq[i+l].key==seq[j+l].key { l++ }
            if seq[i].file == seq[j].file { if i < j && i+l > j { l = j-i }; if j < i && j+l > i { l = i-j } }
            if l < threshold { continue }
            // Prefer maximal occurrences; skip starts that can be extended left.
            if i>0 && j>0 && !seq[i-1].sentinel && !seq[j-1].sentinel && seq[i-1].key==seq[j-1].key { continue }
            sig := signature(seq, i, l)
            if seen[sig] == nil { seen[sig] = map[int]bool{}; cand[sig] = map[int]occ{} }
            if !seen[sig][i] { cand[sig][i] = occ{i,i+l-1}; seen[sig][i]=true }
            if !seen[sig][j] { cand[sig][j] = occ{j,j+l-1}; seen[sig][j]=true }
        }}
    }
    var groups []group
    for sig, om := range cand { _ = sig; if len(om) >= 2 {
        var os []occ; minLen:=1<<30
        for _, o := range om { os = append(os,o); if o.end-o.start+1 < minLen { minLen=o.end-o.start+1 } }
        sort.Slice(os, func(i,j int) bool { return lessOcc(seq, os[i], os[j]) })
        groups = append(groups, group{occs:os, length:minLen})
    }}
    sort.Slice(groups, func(i,j int) bool { return lessOcc(seq, groups[i].occs[0], groups[j].occs[0]) })
    // Drop smaller groups fully covered by previous larger groups with the same occurrence count.
    var filtered []group
    for _, g := range groups {
        covered := false
        for _, h := range filtered { if coversGroup(g,h) { covered = true; break } }
        if !covered { filtered = append(filtered, g) }
    }
    return filtered
}

func crosses(seq []elem, start, l int) bool { for i:=0;i<l;i++ { if seq[start+i].sentinel { return true } }; return false }
func signature(seq []elem, start, l int) string { var b strings.Builder; for i:=0;i<l;i++ { b.WriteString(seq[start+i].key); b.WriteByte(0) }; return b.String() }
func lessOcc(seq []elem, a,b occ) bool { pa,pb := fset.Position(seq[a.start].start), fset.Position(seq[b.start].start); if pa.Filename!=pb.Filename { return pa.Filename<pb.Filename }; return pa.Line<pb.Line || (pa.Line==pb.Line && pa.Column<pb.Column) }
func coversGroup(g,h group) bool { if len(g.occs)>len(h.occs) { return false }; c:=0; for _, gox := range g.occs { for _, ho := range h.occs { if gox.start>=ho.start && gox.end<=ho.end { c++; break } } }; return c==len(g.occs) }

func output(groups []group, seq []elem, opt options) {
    if opt.html { outputHTML(groups, seq); return }
    if opt.plumbing { outputPlumbing(groups, seq); return }
    for _, g := range groups {
        fmt.Printf("found %d clones:\n", len(g.occs))
        for _, o := range g.occs {
            p1 := fset.Position(seq[o.start].start); p2 := fset.Position(maxEnd(seq, o))
            fmt.Printf("  %s:%d,%d\n", p1.Filename, p1.Line, p2.Line)
        }
        fmt.Println()
    }
    fmt.Printf("Found total %d clone groups.\n", len(groups))
}

func outputPlumbing(groups []group, seq []elem) {
    for _, g := range groups { for i, o := range g.occs { for j, other := range g.occs { if i==j { continue }; printPlumb(seq,o,other) } } }
}
func printPlumb(seq []elem, a,b occ) { p1:=fset.Position(seq[a.start].start); p2:=fset.Position(maxEnd(seq,a)); q1:=fset.Position(seq[b.start].start); q2:=fset.Position(maxEnd(seq,b)); fmt.Printf("%s:%d-%d: duplicate of %s:%d-%d\n", p1.Filename,p1.Line,p2.Line,q1.Filename,q1.Line,q2.Line) }

func outputHTML(groups []group, seq []elem) {
    fmt.Print("<!DOCTYPE html>\n<meta charset=\"utf-8\"/>\n<title>Duplicates</title>\n<style>\n\tpre {\n\t\tbackground-color: #FFD;\n\t\tborder: 1px solid #E2E2E2;\n\t\tpadding: 1ex;\n\t}\n</style>\n")
    for i,g := range groups { fmt.Printf("<h1>#%d found %d clones</h1>\n", i+1, len(g.occs)); for _, o := range g.occs { p1:=fset.Position(seq[o.start].start); p2:=fset.Position(maxEnd(seq,o)); fmt.Printf("<h2>%s:%d</h2>\n<pre>%s</pre>\n", html.EscapeString(p1.Filename), p1.Line, html.EscapeString(fragment(p1.Filename,p1.Line,p2.Line))) } }
}
func fragment(path string, start,end int) string { lines:=bytes.Split([]byte(source[path]), []byte("\n")); if start<1 {start=1}; if end>len(lines) {end=len(lines)}; if start>len(lines) || start>end {return ""}; var b bytes.Buffer; for i:=start-1;i<end;i++ { if i>start-1 { b.WriteByte(10) }; b.Write(lines[i]) }; return b.String() }

func maxEnd(seq []elem, o occ) token.Pos {
    m := seq[o.end].end
    for i:=o.start; i<=o.end && i<len(seq); i++ { if seq[i].end > m { m = seq[i].end } }
    return m
}
