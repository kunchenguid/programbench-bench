module duplre

go 1.21
