module dutree_reimpl

go 1.21
