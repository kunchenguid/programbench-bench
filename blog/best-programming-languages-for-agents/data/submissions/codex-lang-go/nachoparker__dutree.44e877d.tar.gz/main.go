package main

import (
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
)

const version = "dutree version 0.2.18"

type options struct {
	depth    int
	aggr     int64
	usage    bool
	bytes    bool
	files    bool
	noHidden bool
	ascii    bool
	excludes []string
	paths    []string
}

type node struct {
	name     string
	path     string
	size     int64
	dir      bool
	children []*node
}

func usageText(prog string) string {
	return fmt.Sprintf(`Usage: %s [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number
`, prog)
}

func main() {
	opt, ok := parse(os.Args)
	if !ok {
		os.Exit(1)
	}
	if len(opt.paths) == 0 {
		opt.paths = []string{"."}
	}
	var roots []*node
	for _, p := range opt.paths {
		if _, err := os.Lstat(p); err != nil {
			fmt.Printf("path %s doesn't exist\n", p)
			os.Exit(1)
		}
		n, err := walk(p, opt)
		if err == nil && n != nil {
			roots = append(roots, n)
		}
	}
	if len(roots) == 0 {
		return
	}
	var root *node
	if len(roots) == 1 {
		root = roots[0]
	} else {
		root = &node{name: "<collection>", dir: true, children: roots}
		for _, r := range roots {
			root.size += r.size
		}
		sortChildren(root.children)
	}
	printTree(root, opt)
}

func parse(args []string) (options, bool) {
	opt := options{depth: 1, aggr: 1024 * 1024}
	prog := args[0]
	for i := 1; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opt.paths = append(opt.paths, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			opt.paths = append(opt.paths, a)
			continue
		}
		switch {
		case a == "-h" || a == "--help":
			fmt.Print(usageText(prog))
			os.Exit(0)
		case a == "-v" || a == "--version":
			fmt.Println(version)
			os.Exit(0)
		case a == "-s" || a == "--summary":
			opt.depth = 1
			opt.aggr = 1024 * 1024
		case a == "-u" || a == "--usage":
			opt.usage = true
		case a == "-b" || a == "--bytes":
			opt.bytes = true
		case a == "-f" || a == "--files-only":
			opt.files = true
		case a == "-H" || a == "--no-hidden":
			opt.noHidden = true
		case a == "-A" || a == "--ascii":
			opt.ascii = true
		case a == "-d" || a == "--depth":
			if i+1 < len(args) {
				if v, err := strconv.Atoi(args[i+1]); err == nil {
					i++
					opt.depth = v
				}
			}
		case a == "-da" || a == "-ad":
			opt.depth = 1
			opt.aggr = 1024 * 1024
		case strings.HasPrefix(a, "-d") && len(a) > 2:
			v, err := strconv.Atoi(a[2:])
			if err != nil {
				fmt.Printf("invalid argument '%s'\n", a[2:])
				return opt, false
			}
			opt.depth = v
		case strings.HasPrefix(a, "--depth="):
			v, err := strconv.Atoi(strings.TrimPrefix(a, "--depth="))
			if err != nil {
				fmt.Printf("invalid argument '%s'\n", strings.TrimPrefix(a, "--depth="))
				return opt, false
			}
			opt.depth = v
		case a == "-a" || a == "--aggr":
			if i+1 >= len(args) {
				fmt.Printf("invalid argument '%s'\n", "")
				return opt, false
			}
			i++
			v, err := parseSize(args[i])
			if err != nil {
				fmt.Printf("invalid argument '%s'\n", args[i])
				return opt, false
			}
			opt.aggr = v
		case strings.HasPrefix(a, "-a") && len(a) > 2:
			v, err := parseSize(a[2:])
			if err != nil {
				fmt.Printf("invalid argument '%s'\n", a[2:])
				return opt, false
			}
			opt.aggr = v
		case strings.HasPrefix(a, "--aggr="):
			s := strings.TrimPrefix(a, "--aggr=")
			v, err := parseSize(s)
			if err != nil {
				fmt.Printf("invalid argument '%s'\n", s)
				return opt, false
			}
			opt.aggr = v
		case a == "-x" || a == "--exclude":
			if i+1 >= len(args) {
				fmt.Printf("invalid argument '%s'\n", "")
				return opt, false
			}
			i++
			opt.excludes = append(opt.excludes, args[i])
		case strings.HasPrefix(a, "--exclude="):
			opt.excludes = append(opt.excludes, strings.TrimPrefix(a, "--exclude="))
		default:
			fmt.Print(usageText(prog))
			fmt.Printf("Unrecognized option: '%s'\n", strings.TrimLeft(a, "-"))
			return opt, false
		}
	}
	return opt, true
}

func parseSize(s string) (int64, error) {
	if s == "" {
		return 0, fmt.Errorf("empty")
	}
	mul := int64(1)
	last := s[len(s)-1]
	if last < '0' || last > '9' {
		switch last {
		case 'K', 'k':
			mul = 1024
		case 'M', 'm':
			mul = 1024 * 1024
		case 'G', 'g':
			mul = 1024 * 1024 * 1024
		default:
			return 0, fmt.Errorf("suffix")
		}
		s = s[:len(s)-1]
	}
	n, err := strconv.ParseInt(s, 10, 64)
	return n * mul, err
}

func walk(path string, opt options) (*node, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	name := filepath.Base(path)
	if path == "." {
		if wd, err := os.Getwd(); err == nil {
			name = filepath.Base(wd)
		}
	}
	n := &node{name: name, path: path, dir: info.IsDir(), size: entrySize(info, opt.usage)}
	if !info.IsDir() {
		return n, nil
	}
	entries, err := os.ReadDir(path)
	if err != nil {
		return n, nil
	}
	for _, e := range entries {
		childName := e.Name()
		if skipName(childName, opt) {
			continue
		}
		childPath := filepath.Join(path, childName)
		info, err := e.Info()
		if err != nil {
			continue
		}
		if opt.files && info.IsDir() {
			continue
		}
		c, err := walk(childPath, opt)
		if err != nil || c == nil {
			continue
		}
		n.children = append(n.children, c)
		n.size += c.size
	}
	sortChildren(n.children)
	return n, nil
}

func entrySize(info fs.FileInfo, usage bool) int64 {
	if usage {
		if st, ok := info.Sys().(*syscall.Stat_t); ok {
			return int64(st.Blocks) * 512
		}
	}
	return info.Size()
}

func skipName(name string, opt options) bool {
	if opt.noHidden && strings.HasPrefix(name, ".") {
		return true
	}
	for _, x := range opt.excludes {
		if name == x || strings.Contains(name, x) {
			return true
		}
	}
	return false
}

func sortChildren(ch []*node) {
	sort.SliceStable(ch, func(i, j int) bool {
		if ch[i].size == ch[j].size {
			return ch[i].name < ch[j].name
		}
		return ch[i].size > ch[j].size
	})
}

func printTree(root *node, opt options) {
	fmt.Printf("[ %s %s ]\n", root.name, fmtSize(root.size, opt.bytes))
	children := visibleChildren(root.children, opt.aggr)
	for i, c := range children {
		printNode(c, "", i == len(children)-1, root.size, root.size, 1, opt)
	}
}

func printNode(n *node, prefix string, last bool, parentSize, scaleSize int64, depth int, opt options) {
	conn := "├─"
	nextPrefix := prefix + "│  "
	if last {
		conn = "└─"
		nextPrefix = prefix + "   "
	}
	percent := 0
	if parentSize > 0 {
		percent = int((n.size * 100) / parentSize)
	}
	fmt.Printf("%s%s %-22s │ %s│ %3d%% %12s\n", prefix, conn, trimName(n.name), bar(n.size, scaleSize), percent, fmtSize(n.size, opt.bytes))
	if depth >= opt.depth {
		return
	}
	children := visibleChildren(n.children, opt.aggr)
	for i, c := range children {
		printNode(c, nextPrefix, i == len(children)-1, n.size, n.size, depth+1, opt)
	}
}

func visibleChildren(children []*node, threshold int64) []*node {
	if len(children) == 0 {
		return nil
	}
	var out []*node
	var ag int64
	for _, c := range children {
		if threshold > 0 && c.size < threshold {
			ag += c.size
		} else {
			out = append(out, c)
		}
	}
	if ag > 0 {
		out = append(out, &node{name: "<aggregated>", size: ag})
		sortChildren(out)
	}
	return out
}

func trimName(s string) string {
	r := []rune(s)
	if len(r) > 22 {
		return string(r[:22])
	}
	return s
}

func bar(size, scale int64) string {
	if scale <= 0 {
		return strings.Repeat(" ", 32)
	}
	n := int((size * 32) / scale)
	if n > 32 {
		n = 32
	}
	if n < 0 {
		n = 0
	}
	return strings.Repeat("#", n) + strings.Repeat(" ", 32-n)
}

func fmtSize(n int64, bytes bool) string {
	if bytes {
		return fmt.Sprintf("%d B", n)
	}
	units := []string{"B", "KiB", "MiB", "GiB", "TiB"}
	f := float64(n)
	u := 0
	for f >= 1024 && u < len(units)-1 {
		f /= 1024
		u++
	}
	if u == 0 {
		return fmt.Sprintf("%d B", n)
	}
	return fmt.Sprintf("%.2f %s", f, units[u])
}
