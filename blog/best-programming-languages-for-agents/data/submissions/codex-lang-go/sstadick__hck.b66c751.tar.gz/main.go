package main

import (
	"bufio"
	"compress/gzip"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type config struct {
	output          string
	delimiter       string
	delimLiteral    bool
	useInputDelim   bool
	outputDelimiter string
	fieldsSpec      string
	excludeSpec     string
	headerFields    []string
	excludeHeaders  []string
	headerRegex     bool
	tryDecompress   bool
	tryCompress     bool
	crlf            bool
	inputs          []string
}

type segment struct {
	start   int
	end     int
	openEnd bool
}

func main() {
	cfg, code, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(code)
	}
	if code != 0 {
		os.Exit(code)
	}
	if err := run(cfg); err != nil {
		fmt.Fprintf(os.Stderr, "[%s ERROR hck] %v\n", time.Now().UTC().Format(time.RFC3339), err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (config, int, error) {
	cfg := config{delimiter: `\s+`, outputDelimiter: "\t"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			cfg.inputs = append(cfg.inputs, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			cfg.inputs = append(cfg.inputs, a)
			continue
		}
		if a == "-h" {
			printShortHelp()
			return cfg, 0, nil
		}
		if a == "--help" {
			printLongHelp()
			return cfg, 0, nil
		}
		if a == "-V" || a == "--version" {
			fmt.Println("hck git:23bebe8-modified")
			return cfg, 0, nil
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a[2:], "=")
			need := func() (string, error) {
				if has {
					return val, nil
				}
				if i+1 >= len(args) {
					return "", fmt.Errorf("error: a value is required for '--%s' but none was supplied\n\nFor more information, try '--help'.", name)
				}
				i++
				return args[i], nil
			}
			switch name {
			case "output":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.output = v
			case "delimiter":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.delimiter = v
			case "delim-is-literal":
				cfg.delimLiteral = true
			case "use-input-delim":
				cfg.useInputDelim = true
			case "output-delimiter":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.outputDelimiter = v
			case "fields":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.fieldsSpec = v
			case "exclude":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.excludeSpec = v
			case "exclude-header":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.excludeHeaders = append(cfg.excludeHeaders, v)
			case "header-field":
				v, e := need()
				if e != nil {
					return cfg, 2, e
				}
				cfg.headerFields = append(cfg.headerFields, v)
			case "header-is-regex":
				cfg.headerRegex = true
			case "try-decompress":
				cfg.tryDecompress = true
			case "try-compress":
				cfg.tryCompress = true
			case "compression-threads", "compression-level":
				_, e := need()
				if e != nil {
					return cfg, 2, e
				}
			case "no-mmap":
			case "crlf":
				cfg.crlf = true
			default:
				return cfg, 2, fmt.Errorf("error: unexpected argument '--%s' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.", name)
			}
			continue
		}
		for j := 1; j < len(a); j++ {
			ch := a[j]
			rest := a[j+1:]
			needShort := func(name string) (string, error) {
				if rest != "" {
					j = len(a)
					return rest, nil
				}
				if i+1 >= len(args) {
					return "", fmt.Errorf("error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.", name)
				}
				i++
				j = len(a)
				return args[i], nil
			}
			switch ch {
			case 'o':
				v, e := needShort("--output <OUTPUT>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.output = v
			case 'd':
				v, e := needShort("--delimiter <DELIMITER>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.delimiter = v
			case 'L':
				cfg.delimLiteral = true
			case 'I':
				cfg.useInputDelim = true
			case 'D':
				v, e := needShort("--output-delimiter <OUTPUT_DELIMITER>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.outputDelimiter = v
			case 'f':
				v, e := needShort("--fields <FIELDS>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.fieldsSpec = v
			case 'e':
				v, e := needShort("--exclude <EXCLUDE>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.excludeSpec = v
			case 'E':
				v, e := needShort("--exclude-header <EXCLUDE_HEADER>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.excludeHeaders = append(cfg.excludeHeaders, v)
			case 'F':
				v, e := needShort("--header-field <HEADER_FIELD>")
				if e != nil {
					return cfg, 2, e
				}
				cfg.headerFields = append(cfg.headerFields, v)
			case 'r':
				cfg.headerRegex = true
			case 'z':
				cfg.tryDecompress = true
			case 'Z':
				cfg.tryCompress = true
			case 't':
				_, e := needShort("--compression-threads <COMPRESSION_THREADS>")
				if e != nil {
					return cfg, 2, e
				}
			case 'l':
				_, e := needShort("--compression-level <COMPRESSION_LEVEL>")
				if e != nil {
					return cfg, 2, e
				}
			default:
				return cfg, 2, fmt.Errorf("error: unexpected argument '-%c' found\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.", ch)
			}
		}
	}
	if cfg.useInputDelim && cfg.delimLiteral && cfg.outputDelimiter == "\t" {
		cfg.outputDelimiter = cfg.delimiter
	}
	return cfg, 0, nil
}

func run(cfg config) error {
	fieldSegs, err := parseRanges(cfg.fieldsSpec)
	if err != nil {
		return err
	}
	exclSegs, err := parseRanges(cfg.excludeSpec)
	if err != nil {
		return err
	}
	out, closer, err := outputWriter(cfg)
	if err != nil {
		return err
	}
	defer closer()
	bw := bufio.NewWriter(out)
	defer bw.Flush()

	if len(cfg.inputs) == 0 {
		return processReader(os.Stdin, bw, cfg, fieldSegs, exclSegs)
	}
	for _, name := range cfg.inputs {
		r, closeFn, err := inputReader(name, cfg.tryDecompress)
		if err != nil {
			return err
		}
		err = processReader(r, bw, cfg, fieldSegs, exclSegs)
		closeFn()
		if err != nil {
			return err
		}
	}
	return nil
}

func outputWriter(cfg config) (io.Writer, func(), error) {
	var w io.Writer = os.Stdout
	closeBase := func() {}
	if cfg.output != "" {
		f, err := os.Create(cfg.output)
		if err != nil {
			return nil, nil, err
		}
		w = f
		closeBase = func() { f.Close() }
	}
	if cfg.tryCompress {
		gz := gzip.NewWriter(w)
		return gz, func() { gz.Close(); closeBase() }, nil
	}
	return w, closeBase, nil
}

func inputReader(name string, decompress bool) (io.Reader, func(), error) {
	f, err := os.Open(name)
	if err != nil {
		return nil, nil, err
	}
	if !decompress {
		return f, func() { f.Close() }, nil
	}
	if strings.HasSuffix(name, ".gz") {
		gz, err := gzip.NewReader(f)
		if err == nil {
			return gz, func() { gz.Close(); f.Close() }, nil
		}
	}
	exts := map[string]string{".xz": "xzcat", ".bz2": "bzcat", ".zst": "zstdcat", ".lz4": "lz4cat"}
	for ext, bin := range exts {
		if strings.HasSuffix(name, ext) {
			cmd := exec.Command(bin, name)
			r, err := cmd.StdoutPipe()
			if err != nil {
				break
			}
			if err := cmd.Start(); err != nil {
				break
			}
			f.Close()
			return r, func() { cmd.Wait() }, nil
		}
	}
	return f, func() { f.Close() }, nil
}

func processReader(r io.Reader, w *bufio.Writer, cfg config, fieldSegs, exclSegs []segment) error {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 64*1024), 64*1024*1024)
	var splitter func(string) []string
	if cfg.delimLiteral {
		splitter = func(s string) []string { return strings.Split(s, cfg.delimiter) }
	} else {
		re, err := regexp.Compile(cfg.delimiter)
		if err != nil {
			return err
		}
		splitter = func(s string) []string { return re.Split(s, -1) }
	}
	var headerSelected []int
	headerDone := false
	headerMode := len(cfg.headerFields) > 0 || len(cfg.excludeHeaders) > 0
	for sc.Scan() {
		line := sc.Text()
		if cfg.crlf {
			line = strings.TrimSuffix(line, "\r")
		}
		cols := splitter(line)
		if !headerDone && headerMode {
			var err error
			headerSelected, err = headerIndexes(cols, cfg)
			if err != nil {
				return err
			}
			headerDone = true
		}
		idxs := selectIndexes(len(cols), fieldSegs, headerSelected)
		if len(fieldSegs) == 0 && !headerMode {
			idxs = make([]int, len(cols))
			for i := range cols {
				idxs[i] = i
			}
		}
		idxs = applyExclusions(idxs, exclSegs, len(cols))
		writeSelected(w, cols, idxs, cfg.outputDelimiter)
	}
	if err := sc.Err(); err != nil {
		return err
	}
	if !headerDone && len(cfg.headerFields) > 0 {
		return errors.New("No headers matched")
	}
	return nil
}

func headerIndexes(headers []string, cfg config) ([]int, error) {
	selected := []int{}
	seen := map[int]bool{}
	matchedAny := len(cfg.headerFields) == 0
	for _, pat := range cfg.headerFields {
		matchedThis := false
		if cfg.headerRegex {
			re, err := regexp.Compile(pat)
			if err != nil {
				return nil, err
			}
			for i, h := range headers {
				if re.MatchString(h) {
					matchedThis = true
					matchedAny = true
					if !seen[i] {
						selected = append(selected, i)
						seen[i] = true
					}
				}
			}
		} else {
			for i, h := range headers {
				if h == pat {
					matchedThis = true
					matchedAny = true
					if !seen[i] {
						selected = append(selected, i)
						seen[i] = true
					}
				}
			}
		}
		_ = matchedThis
	}
	if len(cfg.headerFields) > 0 && !matchedAny {
		return nil, errors.New("No headers matched")
	}
	if len(cfg.headerFields) == 0 {
		selected = make([]int, len(headers))
		for i := range headers {
			selected[i] = i
		}
	}
	if len(cfg.excludeHeaders) > 0 {
		ex := headerExcludeSet(headers, cfg)
		filtered := selected[:0]
		for _, i := range selected {
			if !ex[i] {
				filtered = append(filtered, i)
			}
		}
		selected = filtered
	}
	return selected, nil
}

func headerExcludeSet(headers []string, cfg config) map[int]bool {
	out := map[int]bool{}
	for _, pat := range cfg.excludeHeaders {
		if cfg.headerRegex {
			re, err := regexp.Compile(pat)
			if err != nil {
				continue
			}
			for i, h := range headers {
				if re.MatchString(h) {
					out[i] = true
				}
			}
		} else {
			for i, h := range headers {
				if h == pat {
					out[i] = true
				}
			}
		}
	}
	return out
}

func selectIndexes(n int, segs []segment, header []int) []int {
	out := []int{}
	seen := map[int]bool{}
	add := func(i int) {
		if i >= 0 && i < n && !seen[i] {
			out = append(out, i)
			seen[i] = true
		}
	}
	for _, s := range segs {
		start := s.start
		end := s.end
		if s.openEnd || end > n {
			end = n
		}
		for i := start; i < end; i++ {
			add(i)
		}
	}
	for _, i := range header {
		add(i)
	}
	return out
}

func applyExclusions(idxs []int, segs []segment, n int) []int {
	if len(segs) == 0 {
		return idxs
	}
	ex := map[int]bool{}
	for _, s := range segs {
		end := s.end
		if s.openEnd || end > n {
			end = n
		}
		for i := s.start; i < end; i++ {
			if i >= 0 && i < n {
				ex[i] = true
			}
		}
	}
	out := idxs[:0]
	for _, i := range idxs {
		if !ex[i] {
			out = append(out, i)
		}
	}
	return out
}

func writeSelected(w *bufio.Writer, cols []string, idxs []int, delim string) {
	for j, i := range idxs {
		if j > 0 {
			w.WriteString(delim)
		}
		if i >= 0 && i < len(cols) {
			w.WriteString(cols[i])
		}
	}
	w.WriteByte('\n')
}

func parseRanges(spec string) ([]segment, error) {
	if spec == "" {
		return nil, nil
	}
	var out []segment
	for _, part := range strings.Split(spec, ",") {
		if part == "" {
			continue
		}
		if strings.Contains(part, "-") {
			a, b, _ := strings.Cut(part, "-")
			start := 1
			if a != "" {
				v, err := parsePos(a)
				if err != nil {
					return nil, err
				}
				start = v
			}
			if b == "" {
				out = append(out, segment{start: start - 1, openEnd: true})
			} else {
				end, err := parsePos(b)
				if err != nil {
					return nil, err
				}
				out = append(out, segment{start: start - 1, end: end})
			}
		} else {
			v, err := parsePos(part)
			if err != nil {
				return nil, err
			}
			out = append(out, segment{start: v - 1, end: v})
		}
	}
	return out, nil
}

func parsePos(s string) (int, error) {
	v, err := strconv.Atoi(s)
	if err != nil || v < 1 {
		return 0, fmt.Errorf("Fields and positions are numbered from 1: %s", s)
	}
	return v, nil
}

func printShortHelp() {
	fmt.Print(`* ` + "`delimiter`" + ` is a regex by default and a fixed substring with ` + "`-L`" + ` * ` + "`header-fields`" + ` allows for specifying a literal or a regex to match header names to select columns * both ` + "`header-fields`" + ` and ` + "`fields`" + ` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with ` + "`-D`" + `

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>  Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>  Delimiter to use on input files [default: \s+]
  -L, --delim-is-literal
  -I, --use-input-delim
  -D, --output-delimiter <OUTPUT_DELIMITER> [default: "\t"]
  -f, --fields <FIELDS>
  -e, --exclude <EXCLUDE>
  -E, --exclude-header <EXCLUDE_HEADER>
  -F, --header-field <HEADER_FIELD>
  -r, --header-is-regex
  -z, --try-decompress
  -Z, --try-compress
      --crlf
  -h, --help
  -V, --version
`)
}

func printLongHelp() {
	printShortHelp()
}
