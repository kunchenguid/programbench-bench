module hckre

go 1.21
