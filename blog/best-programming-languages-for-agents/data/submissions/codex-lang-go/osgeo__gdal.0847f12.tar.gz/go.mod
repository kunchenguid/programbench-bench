module programbench/gdalcli

go 1.21
