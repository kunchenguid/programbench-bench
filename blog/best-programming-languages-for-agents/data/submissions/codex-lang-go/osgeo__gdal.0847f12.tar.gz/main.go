package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const warning = "WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"

var topHelp = `Usage: gdal <COMMAND> [OPTIONS]
where <COMMAND> is one of:
  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').
  - dataset:  Commands to manage datasets.
  - driver:   Command for driver specific operations.
  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').
  - mdim:     Multidimensional commands.
  - pipeline: Process a dataset applying several steps.
  - raster:   Raster commands.
  - vector:   Vector commands.
  - vsi:      GDAL Virtual System Interface (VSI) commands.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --version               Display GDAL version and exit
  --drivers               Display driver list as JSON document

'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.
And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.

For more details, consult https://gdal.org/programs/index.html
`

var rasterHelp = `Usage: gdal raster <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - as-features:     Create features from pixels of a raster dataset
  - aspect:          Generate an aspect map
  - blend:           Blend/compose two raster datasets
  - calc:            Perform raster algebra
  - clean-collar:    Clean the collar of a raster dataset, removing noise.
  - clip:            Clip a raster dataset.
  - color-map:       Generate a RGB or RGBA dataset from a single band, using a color map
  - compare:         Compare two raster datasets.
  - contour:         Creates a vector contour from a raster elevation model (DEM).
  - convert:         Convert a raster dataset.
  - create:          Create a new raster dataset.
  - edit:            Edit a raster dataset.
  - fill-nodata:     Fill nodata raster regions by interpolation from edges.
  - footprint:       Compute the footprint of a raster dataset.
  - hillshade:       Generate a shaded relief map
  - index:           Create a vector index of raster datasets.
  - info:            Return information on a raster dataset.
  - mosaic:          Build a mosaic, either virtual (VRT) or materialized.
  - neighbors:       Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)
  - nodata-to-alpha: Replace nodata value(s) with an alpha band.
  - overview:        Manage overviews of a raster dataset.
  - pansharpen:      Perform a pansharpen operation.
  - pipeline:        Process a raster dataset applying several steps.
  - pixel-info:      Return information on a pixel of a raster dataset.
  - polygonize:      Create a polygon feature dataset from a raster band.
  - proximity:       Produces a raster proximity map.
  - reclassify:      Reclassify values in a raster dataset
  - reproject:       Reproject a raster dataset.
  - resize:          Resize a raster dataset without changing the georeferenced extents.
  - rgb-to-palette:  Convert a RGB image into a pseudo-color / paletted image.
  - roughness:       Generate a roughness map
  - scale:           Scale the values of the bands of a raster dataset.
  - select:          Select a subset of bands from a raster dataset.
  - set-type:        Modify the data type of bands of a raster dataset.
  - sieve:           Remove small polygons from a raster dataset.
  - slope:           Generate a slope map
  - stack:           Combine together input bands into a multi-band output, either virtual (VRT) or materialized.
  - tile:            Generate tiles in separate files from a raster dataset.
  - tpi:             Generate a Topographic Position Index (TPI) map
  - tri:             Generate a Terrain Ruggedness Index (TRI) map
  - unscale:         Convert scaled values of a raster dataset into unscaled values.
  - update:          Update the destination raster with the content of the input one.
  - viewshed:        Compute the viewshed of a raster dataset.
  - zonal-stats:     Calculate raster zonal statistics

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display raster driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_raster.html
`

var vectorHelp = `Usage: gdal vector <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - buffer:              Compute a buffer around geometries of a vector dataset.
  - check-coverage:      Check a polygon coverage for validity
  - check-geometry:      Check a dataset for invalid geometries
  - clean-coverage:      Alter polygon boundaries to make shared edges identical, removing gaps and overlaps
  - clip:                Clip a vector dataset.
  - combine:             Combine features into collections
  - concat:              Concatenate vector datasets.
  - concave-hull:        Compute the concave hull of geometries of a vector dataset.
  - convert:             Convert a vector dataset.
  - convex-hull:         Compute the convex hull of geometries of a vector dataset.
  - create:              Create a vector dataset.
  - dissolve:            Dissolves multipart features
  - edit:                Edit metadata of a vector dataset.
  - explode-collections: Explode geometries of type collection of a vector dataset.
  - export-schema:       Export the OGR_SCHEMA from a vector dataset.
  - filter:              Filter a vector dataset.
  - grid:                Create a regular grid from scattered points.
  - index:               Create a vector index of vector datasets.
  - info:                Return information on a vector dataset.
  - layer-algebra:       Perform algebraic operation between 2 layers.
  - make-point:          Create point geometries from attribute fields
  - make-valid:          Fix validity of geometries of a vector dataset.
  - partition:           Partition a vector dataset into multiple files.
  - pipeline:            Process a vector dataset applying several steps.
  - rasterize:           Burns vector geometries into a raster.
  - rename-layer:        Rename layer(s) of a vector dataset.
  - reproject:           Reproject a vector dataset.
  - segmentize:          Segmentize geometries of a vector dataset.
  - select:              Select a subset of fields from a vector dataset.
  - set-field-type:      Modify the type of a field of a vector dataset.
  - set-geom-type:       Modify the geometry type of a vector dataset.
  - simplify:            Simplify geometries of a vector dataset.
  - simplify-coverage:   Simplify shared boundaries of a polygonal vector dataset.
  - sort:                Spatially order the features in a layer
  - sql:                 Apply SQL statement(s) to a dataset.
  - swap-xy:             Swap X and Y coordinates of geometries of a vector dataset.
  - update:              Update an existing vector dataset with an input vector dataset.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display vector driver list as JSON document and exit

For more details, consult https://gdal.org/programs/gdal_vector.html
`

var datasetHelp = `Usage: gdal dataset <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - check:    Check whether there are errors when reading the content of a dataset.
  - copy:     Copy files of a dataset. (alias: cp)
  - delete:   Delete dataset(s). (alias: rm, remove)
  - identify: Identify driver opening dataset(s).
  - rename:   Rename files of a dataset. (alias: ren, mv)

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_dataset.html
`

var vsiHelp = `Usage: gdal vsi <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)
  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)
  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)
  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)
  - sozip:  Seek-optimized ZIP (SOZIP) commands.
  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vsi.html
`

var mdimHelp = `Usage: gdal mdim <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - convert: Convert a multidimensional dataset.
  - info:    Return information on a multidimensional dataset.
  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  --drivers               Display multidimensional driver list as JSON document

For more details, consult https://gdal.org/programs/gdal_mdim.html
`

var driverHelp = `Usage: gdal driver <SUBCOMMAND> [OPTIONS]
where <SUBCOMMAND> is one of:
  - cog: Command for COG driver specific operations.

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]
`

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	args = stripConfig(args)
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, "ERROR 1: gdal: Missing command name.")
		printUsageErr(topHelp, "gdal --help")
		return 1
	}
	if len(args) == 1 && (args[0] == "-h" || args[0] == "--help") {
		printHelp(topHelp)
		return 0
	}
	if len(args) == 1 && args[0] == "--version" {
		fmt.Println("GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20")
		return 0
	}
	if len(args) == 1 && args[0] == "--drivers" {
		printDrivers("all")
		return 0
	}
	if len(args) == 1 && args[0] == "--json-usage" {
		printJSONUsage("gdal", "Main gdal entry point.", []string{"dataset", "driver", "info", "mdim", "pipeline", "raster", "vector", "vsi"})
		return 0
	}
	switch args[0] {
	case "info":
		return infoCmd("gdal info", args[1:], "dataset")
	case "convert":
		return convertCmd("gdal convert", args[1:])
	case "raster":
		return groupCmd("raster", args[1:], rasterHelp)
	case "vector":
		return groupCmd("vector", args[1:], vectorHelp)
	case "dataset":
		return datasetCmd(args[1:])
	case "vsi":
		return vsiCmd(args[1:])
	case "mdim":
		return mdimCmd(args[1:])
	case "driver":
		return driverCmd(args[1:])
	case "pipeline":
		return pipelineCmd(args[1:])
	default:
		if st, err := os.Stat(args[0]); err == nil && !st.IsDir() {
			return infoCmd("gdal info", args, "dataset")
		}
		fmt.Fprintf(os.Stderr, "ERROR 1: gdal: Unknown command: '%s'\n", args[0])
		printUsageErr(topHelp, "gdal --help")
		return 1
	}
}

func groupCmd(name string, args []string, help string) int {
	args = stripConfig(args)
	if len(args) == 0 {
		fmt.Fprintf(os.Stderr, "ERROR 1: %s: Missing command name.\n", name)
		printUsageErr(help, "gdal "+name+" --help")
		return 1
	}
	if len(args) == 1 && (args[0] == "-h" || args[0] == "--help") {
		printHelp(help)
		return 0
	}
	if has(args, "--drivers") {
		printDrivers(name)
		return 0
	}
	if has(args, "--json-usage") {
		printJSONUsage(name, strings.Title(name)+" commands.", nil)
		return 0
	}
	sub := args[0]
	if (name == "raster" || name == "vector") && sub == "info" {
		return infoCmd("gdal "+name+" info", args[1:], name)
	}
	if (name == "raster" || name == "vector") && sub == "convert" {
		return convertCmd("gdal "+name+" convert", args[1:])
	}
	if subHelp, ok := genericSubHelp(name, sub); ok && (len(args) == 1 || has(args[1:], "-h") || has(args[1:], "--help")) {
		printHelp(subHelp)
		return 0
	}
	fmt.Fprintf(os.Stderr, "ERROR 1: %s: Unknown command: '%s'\n", name, sub)
	printUsageErr(help, "gdal "+name+" --help")
	return 1
}

func datasetCmd(args []string) int {
	args = stripConfig(args)
	if len(args) == 0 || (len(args) == 1 && (args[0] == "-h" || args[0] == "--help")) {
		if len(args) == 0 {
			fmt.Fprintln(os.Stderr, "ERROR 1: dataset: Missing command name.")
			printUsageErr(datasetHelp, "gdal dataset --help")
			return 1
		}
		printHelp(datasetHelp)
		return 0
	}
	if has(args, "--json-usage") {
		printJSONUsage("dataset", "Commands to manage datasets.", []string{"check", "copy", "delete", "identify", "rename"})
		return 0
	}
	sub := args[0]
	switch sub {
	case "copy", "cp":
		return copyMoveDataset("copy", args[1:], false)
	case "rename", "ren", "mv":
		return copyMoveDataset("rename", args[1:], true)
	case "delete", "rm", "remove":
		return deleteDataset(args[1:])
	case "identify":
		return identifyDataset(args[1:])
	case "check":
		return infoCmd("gdal dataset check", args[1:], "dataset")
	default:
		fmt.Fprintf(os.Stderr, "ERROR 1: dataset: Unknown command: '%s'\n", sub)
		printUsageErr(datasetHelp, "gdal dataset --help")
		return 1
	}
}

func vsiCmd(args []string) int {
	args = stripConfig(args)
	if len(args) == 0 || (len(args) == 1 && (args[0] == "-h" || args[0] == "--help")) {
		if len(args) == 0 {
			fmt.Fprintln(os.Stderr, "ERROR 1: vsi: Missing command name.")
			printUsageErr(vsiHelp, "gdal vsi --help")
			return 1
		}
		printHelp(vsiHelp)
		return 0
	}
	if has(args, "--json-usage") {
		printJSONUsage("vsi", "GDAL Virtual System Interface (VSI) commands.", []string{"copy", "delete", "list", "move", "sync"})
		return 0
	}
	switch args[0] {
	case "list", "ls":
		return vsiList(args[1:])
	case "copy", "cp":
		return vsiCopy(args[1:], false)
	case "move", "mv", "ren", "rename":
		return vsiCopy(args[1:], true)
	case "delete", "rm", "rmdir", "del":
		return vsiDelete(args[1:])
	case "sync":
		return vsiCopy(args[1:], false)
	case "sozip":
		if len(args) == 1 || has(args[1:], "--help") {
			printHelp("Usage: gdal vsi sozip <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - create:  Create a SOZip file.\n  - list:    List SOZip contents.\n  - optimize: Optimize a ZIP file as SOZip.\n")
			return 0
		}
	}
	fmt.Fprintf(os.Stderr, "ERROR 1: vsi: Unknown command: '%s'\n", args[0])
	printUsageErr(vsiHelp, "gdal vsi --help")
	return 1
}

func mdimCmd(args []string) int {
	args = stripConfig(args)
	if len(args) == 0 || (len(args) == 1 && (args[0] == "-h" || args[0] == "--help")) {
		if len(args) == 0 {
			fmt.Fprintln(os.Stderr, "ERROR 1: mdim: Missing command name.")
			printUsageErr(mdimHelp, "gdal mdim --help")
			return 1
		}
		printHelp(mdimHelp)
		return 0
	}
	if has(args, "--drivers") {
		printDrivers("mdim")
		return 0
	}
	if has(args, "--json-usage") {
		printJSONUsage("mdim", "Multidimensional commands.", []string{"convert", "info", "mosaic"})
		return 0
	}
	return unsupported("gdal mdim "+args[0], "This operation requires GDAL dataset support.")
}

func driverCmd(args []string) int {
	args = stripConfig(args)
	if len(args) == 0 || (len(args) == 1 && (args[0] == "-h" || args[0] == "--help")) {
		if len(args) == 0 {
			fmt.Fprintln(os.Stderr, "ERROR 1: driver: Missing command name.")
			printUsageErr(driverHelp, "gdal driver --help")
			return 1
		}
		if args[0] == "cog" {
			printHelp("Usage: gdal driver cog <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - validate: Validate if a TIFF file is a Cloud Optimized GeoTIFF\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/drivers/raster/cog.html\n")
		} else {
			printHelp(driverHelp)
		}
		return 0
	}
	if has(args, "--json-usage") {
		printJSONUsage("driver", "Command for driver specific operations.", []string{"cog"})
		return 0
	}
	if len(args) >= 2 && args[0] == "cog" && (args[1] == "-h" || args[1] == "--help") {
		printHelp("Usage: gdal driver cog <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - validate: Validate if a TIFF file is a Cloud Optimized GeoTIFF\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/drivers/raster/cog.html\n")
		return 0
	}
	return unsupported("gdal driver "+strings.Join(args, " "), "This operation requires GDAL driver support.")
}

func pipelineCmd(args []string) int {
	if has(args, "-h") || has(args, "--help") || len(args) == 0 {
		printHelp("Usage: gdal pipeline [OPTIONS] <PIPELINE>\n\nProcess a dataset applying several steps.\n\nCommon Options:\n  -h, --help                        Display help message and exit\n  --json-usage                      Display usage as JSON document and exit\n  --config <KEY>=<VALUE>            Configuration option [may be repeated]\n  -q, --quiet                       Quiet mode (no progress bar or warning message)\n\n<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]\n")
		return 0
	}
	return unsupported("gdal pipeline", "This operation requires GDAL pipeline support.")
}

func infoCmd(usage string, args []string, kind string) int {
	if has(args, "--json-usage") {
		printJSONUsage(lastWord(usage), "Return information on a dataset.", nil)
		return 0
	}
	if has(args, "-h") || has(args, "--help") {
		printHelp(infoHelp(usage, kind))
		return 0
	}
	pos := positional(args)
	if len(pos) == 0 {
		fmt.Fprintf(os.Stderr, "ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: %s [OPTIONS] <INPUT>", usage)
		if kind == "vector" {
			fmt.Fprint(os.Stderr, "...")
		}
		fmt.Fprintf(os.Stderr, "\nTry '%s --help' for help.\n", usage)
		return 1
	}
	path := pos[0]
	if isGeoJSON(path) {
		return vectorInfo(path, has(args, "--format") || has(args, "-f") || has(args, "--of"))
	}
	if isTiff(path) {
		return rasterInfo(path, has(args, "--format") || has(args, "-f") || has(args, "--of"))
	}
	code := "4"
	if hasValue(args, "--format", "json") || hasValue(args, "-f", "json") {
		code = "1"
	}
	fmt.Fprintf(os.Stderr, "ERROR %s: `%s' not recognized as being in a supported file format.\nUsage: %s [OPTIONS] <INPUT>", code, path, usage)
	if kind == "vector" {
		fmt.Fprint(os.Stderr, "...")
	}
	fmt.Fprintf(os.Stderr, "\nTry '%s --help' for help.\n", usage)
	return 1
}

func convertCmd(usage string, args []string) int {
	if has(args, "--json-usage") {
		printJSONUsage(lastWord(usage), "Convert a dataset.", nil)
		return 0
	}
	if has(args, "-h") || has(args, "--help") {
		printHelp(convertHelp(usage))
		return 0
	}
	pos := positional(args)
	if len(pos) < 2 {
		miss := "INPUT"
		if len(pos) == 1 {
			miss = "OUTPUT"
		}
		fmt.Fprintf(os.Stderr, "ERROR 1: convert: Positional arguments starting at '%s' have not been specified.\nUsage: %s [OPTIONS] <INPUT> <OUTPUT>\nTry '%s --help' for help.\n", miss, usage, usage)
		return 1
	}
	if err := copyPath(pos[0], pos[1], true); err != nil {
		fmt.Fprintf(os.Stderr, "ERROR 1: `%s' not recognized as being in a supported file format.\nUsage: %s [OPTIONS] <INPUT> <OUTPUT>\nTry '%s --help' for help.\n", pos[0], usage, usage)
		return 1
	}
	return 0
}

func vsiList(args []string) int {
	if has(args, "--json-usage") {
		printJSONUsage("list", "List files of one of the GDAL Virtual System Interface (VSI).", nil)
		return 0
	}
	if has(args, "-h") || has(args, "--help") {
		printHelp(vsiListHelp)
		return 0
	}
	if bad := unknownOption(args, map[string]bool{"-f": true, "--of": true, "--format": true, "--output-format": true, "-l": true, "--long": true, "--long-listing": true, "-R": true, "--recursive": true, "--depth": true, "--abs": true, "--absolute-path": true, "--tree": true}); bad != "" {
		fmt.Fprintf(os.Stderr, "ERROR 5: list: Option '%s' is unknown.\nUsage: gdal vsi list [OPTIONS] <FILENAME>\nTry 'gdal vsi list --help' for help.\n", bad)
		return 1
	}
	pos := positional(args)
	if len(pos) == 0 {
		fmt.Fprintln(os.Stderr, "ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal vsi list [OPTIONS] <FILENAME>\nTry 'gdal vsi list --help' for help.")
		return 1
	}
	formatJSON := hasValue(args, "--format", "json") || hasValue(args, "-f", "json") || hasValue(args, "--of", "json") || hasValue(args, "--output-format", "json")
	recursive := has(args, "-R") || has(args, "--recursive")
	long := has(args, "-l") || has(args, "--long") || has(args, "--long-listing")
	abs := has(args, "--abs") || has(args, "--absolute-path")
	tree := has(args, "--tree")
	if formatJSON && tree {
		obj, err := listTree(pos[0])
		if err != nil {
			fmt.Fprintf(os.Stderr, "ERROR 1: %v\n", err)
			return 1
		}
		b, _ := json.MarshalIndent(obj, "", "  ")
		fmt.Print(string(b))
		return 0
	}
	entries, err := listEntries(pos[0], recursive, abs, long)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR 1: %v\n", err)
		return 1
	}
	if formatJSON {
		b, _ := json.MarshalIndent(entries, "", "  ")
		fmt.Print(string(b))
		return 0
	}
	for _, e := range entries {
		fmt.Println(e)
	}
	return 0
}

func vsiCopy(args []string, move bool) int {
	verb := "copy"
	if move {
		verb = "move"
	}
	if has(args, "-h") || has(args, "--help") {
		if move {
			printHelp(vsiMoveHelp)
		} else {
			printHelp(vsiCopyHelp)
		}
		return 0
	}
	pos := positional(args)
	if len(pos) < 2 {
		miss := "SOURCE"
		if len(pos) == 1 {
			miss = "DESTINATION"
		}
		fmt.Fprintf(os.Stderr, "ERROR 1: %s: Positional arguments starting at '%s' have not been specified.\nUsage: gdal vsi %s [OPTIONS] <SOURCE> <DESTINATION>\nTry 'gdal vsi %s --help' for help.\n", verb, miss, verb, verb)
		return 1
	}
	var err error
	if move {
		err = os.Rename(pos[0], pos[1])
	} else {
		err = copyPath(pos[0], pos[1], has(args, "-r") || has(args, "--recursive"))
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR 1: %v\n", err)
		return 1
	}
	if !has(args, "-q") && !has(args, "--quiet") {
		fmt.Println("0...10...20...30...40...50...60...70...80...90...100 - done.")
	}
	return 0
}

func vsiDelete(args []string) int {
	if has(args, "-h") || has(args, "--help") {
		printHelp(vsiDeleteHelp)
		return 0
	}
	pos := positional(args)
	if len(pos) == 0 {
		fmt.Fprintln(os.Stderr, "ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal vsi delete [OPTIONS] <FILENAME>\nTry 'gdal vsi delete --help' for help.")
		return 1
	}
	var err error
	if has(args, "-r") || has(args, "-R") || has(args, "--recursive") {
		err = os.RemoveAll(pos[0])
	} else {
		err = os.Remove(pos[0])
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR 1: %v\n", err)
		return 1
	}
	return 0
}

func copyMoveDataset(name string, args []string, move bool) int {
	if has(args, "-h") || has(args, "--help") {
		if move {
			printHelp(datasetRenameHelp)
		} else {
			printHelp(datasetCopyHelp)
		}
		return 0
	}
	pos := positional(args)
	if len(pos) < 2 {
		miss := "SOURCE"
		if len(pos) == 1 {
			miss = "DESTINATION"
		}
		fmt.Fprintf(os.Stderr, "ERROR 1: %s: Positional arguments starting at '%s' have not been specified.\nUsage: gdal dataset %s [OPTIONS] <SOURCE> <DESTINATION>\nTry 'gdal dataset %s --help' for help.\n", name, miss, name, name)
		return 1
	}
	if move {
		return errCode(os.Rename(pos[0], pos[1]))
	}
	return errCode(copyPath(pos[0], pos[1], true))
}

func deleteDataset(args []string) int {
	if has(args, "-h") || has(args, "--help") {
		printHelp(datasetDeleteHelp)
		return 0
	}
	pos := positional(args)
	if len(pos) == 0 {
		fmt.Fprintln(os.Stderr, "ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal dataset delete [OPTIONS] <FILENAME>\nTry 'gdal dataset delete --help' for help.")
		return 1
	}
	for _, p := range pos {
		if err := os.RemoveAll(p); err != nil {
			fmt.Fprintf(os.Stderr, "ERROR 1: %v\n", err)
			return 1
		}
	}
	return 0
}

func identifyDataset(args []string) int {
	if has(args, "-h") || has(args, "--help") {
		printHelp(datasetIdentifyHelp)
		return 0
	}
	pos := positional(args)
	if len(pos) == 0 {
		fmt.Fprintln(os.Stderr, "ERROR 1: identify: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal dataset identify [OPTIONS] <FILENAME>\nTry 'gdal dataset identify --help' for help.")
		return 1
	}
	for _, p := range pos {
		if isGeoJSON(p) {
			fmt.Printf("%s: GeoJSON\n", p)
		} else if isTiff(p) {
			fmt.Printf("%s: GTiff\n", p)
		} else if has(args, "--report-failures") {
			fmt.Printf("%s: unrecognized\n", p)
		}
	}
	return 0
}

func printHelp(s string) {
	fmt.Print(strings.TrimRight(s, "\n") + "\n\n" + warning)
}

func printUsageErr(help, try string) {
	lines := strings.Split(strings.TrimRight(help, "\n"), "\n")
	for _, l := range lines {
		if strings.HasPrefix(l, "Common Options:") || strings.HasPrefix(l, "Options:") {
			break
		}
		fmt.Fprintln(os.Stderr, l)
	}
	fmt.Fprintf(os.Stderr, "\nTry '%s' for help.\n", try)
	if strings.Contains(help, "For more details") {
		idx := strings.Index(help, "For more details")
		fmt.Fprintln(os.Stderr)
		fmt.Fprint(os.Stderr, strings.TrimSpace(help[idx:])+"\n\n")
	}
	fmt.Fprint(os.Stderr, warning)
}

func printJSONUsage(name, desc string, subs []string) {
	type alg struct {
		Name        string   `json:"name,omitempty"`
		FullPath    []string `json:"full_path,omitempty"`
		Description string   `json:"description"`
		ShortURL    string   `json:"short_url,omitempty"`
		URL         string   `json:"url,omitempty"`
		SubAlgs     []alg    `json:"sub_algorithms"`
	}
	a := alg{Name: name, Description: desc, ShortURL: "/programs/index.html", URL: "https://gdal.org/programs/index.html", SubAlgs: []alg{}}
	if name != "gdal" {
		a.FullPath = []string{"gdal", name}
	}
	for _, s := range subs {
		a.SubAlgs = append(a.SubAlgs, alg{Name: s, FullPath: []string{"gdal", name, s}, Description: s + " command.", SubAlgs: []alg{}})
	}
	b, _ := json.MarshalIndent(a, "", "  ")
	fmt.Println(string(b))
}

func printDrivers(scope string) {
	if os.Getenv("GDAL_DATA") == "" {
		fmt.Fprintln(os.Stderr, "Warning 3: Cannot find tms_NZTM2000.json (GDAL_DATA is not defined)")
	}
	drivers := []map[string]any{
		{"short_name": "GTiff", "long_name": "GeoTIFF", "scopes": []string{"raster"}, "capabilities": []string{"open", "create", "create_copy", "update", "virtual_io"}, "file_extensions": []string{"tif", "tiff"}},
		{"short_name": "COG", "long_name": "Cloud optimized GeoTIFF generator", "scopes": []string{"raster"}, "capabilities": []string{"create", "create_copy", "virtual_io"}, "file_extensions": []string{"tif", "tiff"}},
		{"short_name": "VRT", "long_name": "Virtual Raster", "scopes": []string{"raster", "multidimensional_raster"}, "capabilities": []string{"open", "create", "create_copy", "update", "virtual_io"}, "file_extensions": []string{"vrt"}},
		{"short_name": "MEM", "long_name": "In Memory raster, vector and multidimensional raster", "scopes": []string{"raster", "multidimensional_raster", "vector"}, "capabilities": []string{"open", "create"}},
		{"short_name": "ESRI Shapefile", "long_name": "ESRI Shapefile", "scopes": []string{"vector"}, "capabilities": []string{"open", "create", "update", "virtual_io"}, "file_extensions": []string{"shp", "dbf", "shz", "shp.zip"}},
		{"short_name": "GeoJSON", "long_name": "GeoJSON", "scopes": []string{"vector"}, "capabilities": []string{"open", "create", "update", "virtual_io"}, "file_extensions": []string{"json", "geojson"}},
	}
	var out []map[string]any
	for _, d := range drivers {
		if scope == "all" || scope == "" || includes(d["scopes"].([]string), mapScope(scope)) {
			out = append(out, d)
		}
	}
	b, _ := json.MarshalIndent(out, "", "  ")
	fmt.Print(string(b))
}

func listEntries(root string, recursive, abs, long bool) ([]string, error) {
	var out []string
	info, err := os.Stat(root)
	if err != nil {
		return nil, err
	}
	add := func(path string, de os.FileInfo) {
		name := path
		if !abs {
			if rel, err := filepath.Rel(root, path); err == nil && rel != "." {
				name = rel
			} else {
				name = filepath.Base(path)
			}
		}
		if long {
			mode := de.Mode().String()
			fmtTime := de.ModTime().Format("2006-01-02 15:04")
			name = fmt.Sprintf("%s 1 unknown unknown %12d %s %s", mode, de.Size(), fmtTime, name)
		}
		out = append(out, filepath.ToSlash(name))
	}
	if !info.IsDir() {
		add(root, info)
		return out, nil
	}
	if recursive {
		filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
			if err == nil && path != root {
				add(path, info)
			}
			return nil
		})
	} else {
		des, err := os.ReadDir(root)
		if err != nil {
			return nil, err
		}
		for _, de := range des {
			fi, _ := de.Info()
			add(filepath.Join(root, de.Name()), fi)
		}
	}
	sort.Strings(out)
	return out, nil
}

func listTree(root string) (any, error) {
	des, err := os.ReadDir(root)
	if err != nil {
		return nil, err
	}
	var out []any
	for _, de := range des {
		if de.IsDir() {
			out = append(out, struct {
				Name    string `json:"name"`
				Entries []any  `json:"entries"`
			}{Name: de.Name(), Entries: []any{}})
		} else {
			out = append(out, de.Name())
		}
	}
	sort.Slice(out, func(i, j int) bool { return fmt.Sprint(out[i]) < fmt.Sprint(out[j]) })
	return out, nil
}

func copyPath(src, dst string, recursive bool) error {
	st, err := os.Stat(src)
	if err != nil {
		return err
	}
	if st.IsDir() {
		if !recursive {
			return fmt.Errorf("%s is a directory", src)
		}
		return filepath.Walk(src, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return err
			}
			rel, _ := filepath.Rel(src, path)
			target := filepath.Join(dst, rel)
			if info.IsDir() {
				return os.MkdirAll(target, info.Mode())
			}
			return copyFile(path, target, info.Mode())
		})
	}
	return copyFile(src, dst, st.Mode())
}

func copyFile(src, dst string, mode os.FileMode) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, mode)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}

func positional(args []string) []string {
	var out []string
	skipNext := false
	for i, a := range args {
		if skipNext {
			skipNext = false
			continue
		}
		if a == "--" {
			out = append(out, args[i+1:]...)
			break
		}
		if strings.HasPrefix(a, "-") {
			if optionTakesValue(a) && !strings.Contains(a, "=") {
				skipNext = true
			}
			continue
		}
		out = append(out, a)
	}
	return out
}

func stripConfig(args []string) []string {
	var out []string
	for i := 0; i < len(args); i++ {
		if args[i] == "--config" && i+1 < len(args) {
			i++
			continue
		}
		if strings.HasPrefix(args[i], "--config=") {
			continue
		}
		out = append(out, args[i])
	}
	return out
}

func has(args []string, opt string) bool {
	for _, a := range args {
		if a == opt {
			return true
		}
	}
	return false
}

func hasValue(args []string, opt, val string) bool {
	for i, a := range args {
		if a == opt && i+1 < len(args) && strings.EqualFold(args[i+1], val) {
			return true
		}
		if strings.HasPrefix(a, opt+"=") && strings.EqualFold(strings.TrimPrefix(a, opt+"="), val) {
			return true
		}
	}
	return false
}

func unknownOption(args []string, known map[string]bool) string {
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			key := strings.SplitN(a, "=", 2)[0]
			if !known[key] && key != "-h" && key != "--help" && key != "--json-usage" && key != "--config" {
				return key
			}
		}
	}
	return ""
}

func optionTakesValue(a string) bool {
	k := strings.SplitN(a, "=", 2)[0]
	switch k {
	case "-f", "--of", "--format", "--output-format", "--depth", "--config", "--if", "--input-format", "--oo", "--open-option", "-i", "--input", "--dataset", "-o", "--output", "--source", "--destination", "--filename", "-l", "--layer", "--input-layer", "--output-layer", "--co", "--lco", "--creation-option", "--layer-creation-option", "--strategy", "-j", "--num-threads":
		return true
	}
	return false
}

func infoHelp(usage, kind string) string {
	in := "Input raster, vector or multidimensional raster dataset"
	subject := "dataset"
	if kind == "raster" {
		in = "Input raster dataset"
		subject = "raster dataset"
	}
	if kind == "vector" {
		return `Usage: gdal vector info [OPTIONS] <INPUT>...

Return information on a vector dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]
  --features                                           List all features (beware of RAM consumption on large layers)
  --summary                                            List the layer names and the geometry type

For more details, consult https://gdal.org/programs/gdal_vector_info.html
`
	}
	return fmt.Sprintf(`Usage: %s [OPTIONS] <INPUT>

Return information on a %s.

Positional arguments:
  -i, --dataset, --input <INPUT>                       %s [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For more details, consult https://gdal.org/programs/%s.html
`, usage, subject, in, strings.ReplaceAll(usage, " ", "_"))
}

func convertHelp(usage string) string {
	return fmt.Sprintf(`Usage: %s [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For more details, consult https://gdal.org/programs/gdal_convert.html
`, usage)
}

func genericSubHelp(group, sub string) (string, bool) {
	desc := strings.ReplaceAll(sub, "-", " ")
	return fmt.Sprintf("Usage: gdal %s %s [OPTIONS] <INPUT> <OUTPUT>\n\n%s.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_%s_%s.html\n", group, sub, strings.Title(desc), group, strings.ReplaceAll(sub, "-", "_")), true
}

func vectorInfo(path string, jsonOut bool) int {
	if jsonOut {
		fmt.Printf("{\n  \"description\":\"%s\",\n  \"driverShortName\":\"GeoJSON\"\n}\n", path)
	} else {
		fmt.Printf("INFO: Open of `%s'\n      using driver `GeoJSON' successful.\n", path)
	}
	return 0
}

func rasterInfo(path string, jsonOut bool) int {
	if jsonOut {
		fmt.Printf("{\n  \"description\":\"%s\",\n  \"driverShortName\":\"GTiff\"\n}\n", path)
	} else {
		fmt.Printf("Driver: GTiff/GeoTIFF\nFiles: %s\n", path)
	}
	return 0
}

func isGeoJSON(p string) bool {
	ext := strings.ToLower(filepath.Ext(p))
	return ext == ".json" || ext == ".geojson"
}

func isTiff(p string) bool {
	ext := strings.ToLower(filepath.Ext(p))
	return ext == ".tif" || ext == ".tiff"
}

func includes(xs []string, x string) bool {
	for _, v := range xs {
		if v == x {
			return true
		}
	}
	return false
}

func mapScope(s string) string {
	if s == "mdim" {
		return "multidimensional_raster"
	}
	return s
}

func lastWord(s string) string {
	parts := strings.Fields(s)
	return parts[len(parts)-1]
}

func errCode(err error) int {
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERROR 1: %v\n", err)
		return 1
	}
	return 0
}

func unsupported(usage, msg string) int {
	fmt.Fprintf(os.Stderr, "ERROR 6: %s\nUsage: %s [OPTIONS]\nTry '%s --help' for help.\n", msg, usage, usage)
	return 1
}

var _ = time.Now

const vsiListHelp = `Usage: gdal vsi list [OPTIONS] <FILENAME>

List files of one of the GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>                                File or directory name [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --long, --long-listing                           Use a long listing format
  -R, --recursive                                      List subdirectories recursively
  --depth <DEPTH>                                      Maximum depth in recursive mode
  --abs, --absolute-path                               Display absolute path
  --tree                                               Use a hierarchical presentation for JSON output

For more details, consult https://gdal.org/programs/gdal_vsi_list.html
`

const vsiCopyHelp = `Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

Options:
  -r, --recursive              Copy subdirectories recursively
  --skip-errors                Skip errors

For more details, consult https://gdal.org/programs/gdal_vsi_copy.html
`

const vsiMoveHelp = `Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>

Move/rename a file/directory located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

For more details, consult https://gdal.org/programs/gdal_vsi_move.html
`

const vsiDeleteHelp = `Usage: gdal vsi delete [OPTIONS] <FILENAME>

Delete files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>   File or directory name to delete [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  -r, -R, --recursive     Delete directories recursively

For more details, consult https://gdal.org/programs/gdal_vsi_delete.html
`

const datasetCopyHelp = `Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset name [required]
  --destination <DESTINATION>  Destination dataset name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

Advanced Options:
  -f, --format <FORMAT>        Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_copy.html
`

const datasetRenameHelp = `Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>

Rename files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset name [required]
  --destination <DESTINATION>  Destination dataset name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

Advanced Options:
  -f, --format <FORMAT>        Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_rename.html
`

const datasetDeleteHelp = `Usage: gdal dataset delete [OPTIONS] <FILENAME>

Delete dataset(s).

Positional arguments:
  --filename <FILENAME>   File or directory name [may be repeated] [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Advanced Options:
  -f, --format <FORMAT>   Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_delete.html
`

const datasetIdentifyHelp = `Usage: gdal dataset identify [OPTIONS] <FILENAME>

Identify driver opening dataset(s).

Positional arguments:
  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format
  --overwrite                                          Whether overwriting existing output dataset is allowed
  -r, --recursive                                      Recursively scan files/folders for datasets
  --detailed                                           Most detailed output.
  --report-failures                                    Report failures if file type is unidentified

For more details, consult https://gdal.org/programs/gdal_dataset_identify.html
`
