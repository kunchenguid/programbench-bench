module kiro

go 1.21
