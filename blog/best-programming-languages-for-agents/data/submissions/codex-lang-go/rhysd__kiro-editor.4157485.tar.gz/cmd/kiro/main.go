package main

import (
	"bufio"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"unicode/utf8"
	"unsafe"
)

const version = "0.4.3"

const helpText = `./executable: A tiny UTF-8 terminal text editor

Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
Specify file paths to edit as a command argument or run without argument to
start to write a new text.
Help can show up with key mapping Ctrl-?.

Usage:
    ./executable [options] [FILES...]

Mappings:
    Ctrl-Q                        : Quit
    Ctrl-S                        : Save to file
    Ctrl-O                        : Open text buffer
    Ctrl-X                        : Next text buffer
    Alt-X                         : Previous text buffer
    Ctrl-P or UP                  : Move cursor up
    Ctrl-N or DOWN                : Move cursor down
    Ctrl-F or RIGHT               : Move cursor right
    Ctrl-B or LEFT                : Move cursor left
    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
    Ctrl-] or Alt-V or PAGE UP    : Previous page
    Alt-F or Ctrl-RIGHT           : Move cursor to next word
    Alt-B or Ctrl-LEFT            : Move cursor to previous word
    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
    Alt-P or Ctrl-UP              : Move cursor to previous paragraph
    Alt-<                         : Move cursor to top of file
    Alt->                         : Move cursor to bottom of file
    Ctrl-H or BACKSPACE           : Delete character
    Ctrl-D or DELETE              : Delete next character
    Ctrl-W                        : Delete a word
    Ctrl-J                        : Delete until head of line
    Ctrl-K                        : Delete until end of line
    Ctrl-U                        : Undo last change
    Ctrl-R                        : Redo last undo change
    Ctrl-G                        : Search text
    Ctrl-M                        : New line
    Ctrl-L                        : Refresh screen
    Ctrl-?                        : Show this help

Options:
    -v, --version       Print version
    -h, --help          Print this help
`

type termios struct {
	Iflag  uint32
	Oflag  uint32
	Cflag  uint32
	Lflag  uint32
	Line   uint8
	Cc     [32]uint8
	Ispeed uint32
	Ospeed uint32
}

type winsize struct {
	Row, Col       uint16
	Xpixel, Ypixel uint16
}

func ioctl(fd uintptr, req uintptr, arg uintptr) error {
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, req, arg)
	if errno != 0 {
		return errno
	}
	return nil
}

func getTermios(fd int) (*termios, error) {
	var t termios
	if err := ioctl(uintptr(fd), syscall.TCGETS, uintptr(unsafe.Pointer(&t))); err != nil {
		return nil, err
	}
	return &t, nil
}

func setTermios(fd int, t *termios) error {
	return ioctl(uintptr(fd), syscall.TCSETS, uintptr(unsafe.Pointer(t)))
}

func enableRaw(fd int) (*termios, error) {
	orig, err := getTermios(fd)
	if err != nil {
		return nil, err
	}
	raw := *orig
	raw.Iflag &^= syscall.IGNBRK | syscall.BRKINT | syscall.PARMRK | syscall.ISTRIP | syscall.INLCR | syscall.IGNCR | syscall.ICRNL | syscall.IXON
	raw.Oflag &^= syscall.OPOST
	raw.Lflag &^= syscall.ECHO | syscall.ECHONL | syscall.ICANON | syscall.ISIG | syscall.IEXTEN
	raw.Cflag &^= syscall.CSIZE | syscall.PARENB
	raw.Cflag |= syscall.CS8
	raw.Cc[syscall.VMIN] = 1
	raw.Cc[syscall.VTIME] = 0
	if err := setTermios(fd, &raw); err != nil {
		return nil, err
	}
	return orig, nil
}

type Buffer struct {
	name     string
	lines    []string
	cx, cy   int
	rowoff   int
	coloff   int
	dirty    bool
	undo     [][]string
	redo     [][]string
	modified bool
}

type Editor struct {
	bufs          []*Buffer
	current       int
	rows, cols    int
	screenRows    int
	message       string
	quitWarned    bool
	reader        *bufio.Reader
	stdin, stdout *os.File
}

func main() {
	files, done, code := parseArgs(os.Args[1:])
	if done {
		os.Exit(code)
	}
	ed := &Editor{stdin: os.Stdin, stdout: os.Stdout, reader: bufio.NewReader(os.Stdin)}
	if err := ed.init(files); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	if err := ed.run(); err != nil {
		if errors.Is(err, syscall.ENOTTY) {
			fmt.Fprintln(os.Stderr, "Error: Inappropriate ioctl for device (os error 25)")
			os.Exit(1)
		}
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
}

func parseArgs(args []string) ([]string, bool, int) {
	var files []string
	for _, a := range args {
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return nil, true, 0
		case "-v", "--version":
			fmt.Println(version)
			return nil, true, 0
		default:
			if strings.HasPrefix(a, "-") && !strings.HasPrefix(a, "--") {
				short := strings.TrimPrefix(a, "-")
				if short != "" && strings.Trim(short, "hv") == "" {
					if strings.Contains(short, "v") {
						fmt.Println(version)
						return nil, true, 0
					}
					fmt.Print(helpText)
					return nil, true, 0
				}
			}
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "Error: Unrecognized option: '%s'. Please see --help for more details\n", strings.TrimLeft(a, "-"))
				return nil, true, 1
			}
			files = append(files, a)
		}
	}
	return files, false, 0
}

func (e *Editor) init(files []string) error {
	if len(files) == 0 {
		e.bufs = []*Buffer{newBuffer("")}
		return nil
	}
	for _, f := range files {
		b := newBuffer(f)
		if data, err := os.ReadFile(f); err == nil {
			text := strings.ReplaceAll(string(data), "\r\n", "\n")
			text = strings.TrimSuffix(text, "\n")
			if text == "" {
				b.lines = []string{""}
			} else {
				b.lines = strings.Split(text, "\n")
			}
		} else if !errors.Is(err, os.ErrNotExist) {
			return err
		}
		e.bufs = append(e.bufs, b)
	}
	return nil
}

func newBuffer(name string) *Buffer {
	return &Buffer{name: name, lines: []string{""}}
}

func (e *Editor) run() error {
	orig, err := enableRaw(int(e.stdin.Fd()))
	if err != nil {
		return err
	}
	defer setTermios(int(e.stdin.Fd()), orig)
	defer fmt.Fprint(e.stdout, "\x1b[?1049l\x1b[H")
	fmt.Fprint(e.stdout, "\x1b[?1049h")
	e.message = "Ctrl-? for help"
	for {
		e.updateSize()
		e.refresh()
		key, err := e.readKey()
		if err != nil {
			return nil
		}
		if e.handleKey(key) {
			return nil
		}
	}
}

func (e *Editor) updateSize() {
	var ws winsize
	if ioctl(e.stdout.Fd(), syscall.TIOCGWINSZ, uintptr(unsafe.Pointer(&ws))) == nil && ws.Row > 0 && ws.Col > 0 {
		e.rows, e.cols = int(ws.Row), int(ws.Col)
	} else {
		e.rows, e.cols = 24, 80
	}
	e.screenRows = e.rows - 2
	if e.screenRows < 1 {
		e.screenRows = 1
	}
}

func (e *Editor) buf() *Buffer { return e.bufs[e.current] }

func (e *Editor) refresh() {
	b := e.buf()
	e.scroll()
	var out strings.Builder
	out.WriteString("\x1b[?25l\x1b[39;0m")
	for y := 0; y < e.screenRows; y++ {
		out.WriteString(fmt.Sprintf("\x1b[%dH", y+1))
		filerow := y + b.rowoff
		if filerow >= len(b.lines) {
			out.WriteString("\x1b[37m~\x1b[39;0m")
			if len(e.bufs) == 1 && b.name == "" && len(b.lines) == 1 && b.lines[0] == "" && y == e.screenRows/3 {
				welcome := "Kiro editor -- version " + version
				if len(welcome) < e.cols {
					pad := (e.cols - len(welcome)) / 2
					if pad > 0 {
						out.WriteByte('~')
						pad--
					}
					out.WriteString(strings.Repeat(" ", pad))
				}
				out.WriteString(welcome)
			}
		} else {
			line := b.lines[filerow]
			runes := []rune(line)
			start := min(b.coloff, len(runes))
			end := min(start+e.cols, len(runes))
			out.WriteString(string(runes[start:end]))
			out.WriteString("\x1b[39;0m")
		}
		out.WriteString("\x1b[K")
	}
	out.WriteString(fmt.Sprintf("\x1b[%dH\x1b[7m", e.rows-1))
	status := e.status()
	if len([]rune(status)) > e.cols {
		status = string([]rune(status)[:e.cols])
	}
	out.WriteString(status)
	if pad := e.cols - len([]rune(status)); pad > 0 {
		out.WriteString(strings.Repeat(" ", pad))
	}
	out.WriteString("\x1b[39;0m")
	out.WriteString(fmt.Sprintf("\x1b[%dH", e.rows))
	msg := e.message
	if len([]rune(msg)) > e.cols {
		msg = string([]rune(msg)[:e.cols])
	}
	out.WriteString(msg)
	out.WriteString("\x1b[K")
	cy := b.cy - b.rowoff + 1
	cx := b.cx - b.coloff + 1
	if cy < 1 {
		cy = 1
	}
	if cx < 1 {
		cx = 1
	}
	out.WriteString(fmt.Sprintf("\x1b[%d;%dH\x1b[?25h", cy, cx))
	fmt.Fprint(e.stdout, out.String())
}

func (e *Editor) status() string {
	b := e.buf()
	name := "\"[No Name]\""
	if b.name != "" {
		name = "\"" + b.name + "\""
	}
	left := fmt.Sprintf("%s - %d/%d", name, e.current+1, len(e.bufs))
	if b.dirty {
		left += " (modified)"
	}
	right := fmt.Sprintf("plain %d/%d", b.cy+1, len(b.lines))
	space := e.cols - len([]rune(left)) - len([]rune(right))
	if space < 1 {
		space = 1
	}
	return left + strings.Repeat(" ", space) + right
}

func (e *Editor) scroll() {
	b := e.buf()
	if b.cy < b.rowoff {
		b.rowoff = b.cy
	}
	if b.cy >= b.rowoff+e.screenRows {
		b.rowoff = b.cy - e.screenRows + 1
	}
	if b.cx < b.coloff {
		b.coloff = b.cx
	}
	if b.cx >= b.coloff+e.cols {
		b.coloff = b.cx - e.cols + 1
	}
}

func (e *Editor) readKey() (string, error) {
	r, _, err := e.reader.ReadRune()
	if err != nil {
		return "", err
	}
	if r != 0x1b {
		return string(r), nil
	}
	b, err := e.reader.Peek(1)
	if err != nil || len(b) == 0 {
		return "esc", nil
	}
	if b[0] == '[' {
		e.reader.ReadByte()
		c, _ := e.reader.ReadByte()
		switch c {
		case 'A':
			return "up", nil
		case 'B':
			return "down", nil
		case 'C':
			return "right", nil
		case 'D':
			return "left", nil
		case 'H':
			return "home", nil
		case 'F':
			return "end", nil
		case '3':
			e.reader.ReadByte()
			return "del", nil
		case '5':
			e.reader.ReadByte()
			return "pageup", nil
		case '6':
			e.reader.ReadByte()
			return "pagedown", nil
		case '1':
			e.reader.ReadByte()
			d, _ := e.reader.ReadByte()
			e.reader.ReadByte()
			if d == 'C' {
				return "wordright", nil
			}
			if d == 'D' {
				return "wordleft", nil
			}
		}
	} else {
		c, _ := e.reader.ReadByte()
		switch c {
		case 'x', 'X':
			return "prevbuf", nil
		case 'f', 'F':
			return "wordright", nil
		case 'b', 'B':
			return "wordleft", nil
		case '<':
			return "top", nil
		case '>':
			return "bottom", nil
		case 'v', 'V':
			return "pageup", nil
		}
	}
	return "esc", nil
}

func (e *Editor) handleKey(k string) bool {
	b := e.buf()
	e.message = ""
	switch k {
	case "\x11":
		if e.anyDirty() && !e.quitWarned {
			e.quitWarned = true
			e.message = "At least one file has unsaved changes! Press Ctrl-Q again to quit"
			return false
		}
		return true
	case "\x13":
		e.save()
	case "\x18":
		e.current = (e.current + 1) % len(e.bufs)
	case "prevbuf":
		e.current = (e.current + len(e.bufs) - 1) % len(e.bufs)
	case "\x7f", "\b":
		e.backspace()
	case "\x04", "del":
		e.delete()
	case "\r":
		e.insertNewline()
	case "\x01", "home":
		b.cx = 0
	case "\x05", "end":
		b.cx = len([]rune(b.lines[b.cy]))
	case "\x10", "up":
		e.moveCursor("up")
	case "\x0e", "down":
		e.moveCursor("down")
	case "\x06", "right":
		e.moveCursor("right")
	case "\x02", "left":
		e.moveCursor("left")
	case "\x16", "pagedown":
		for i := 0; i < e.screenRows; i++ {
			e.moveCursor("down")
		}
	case "\x1d", "pageup":
		for i := 0; i < e.screenRows; i++ {
			e.moveCursor("up")
		}
	case "top":
		b.cy, b.cx = 0, 0
	case "bottom":
		b.cy = len(b.lines) - 1
		b.cx = len([]rune(b.lines[b.cy]))
	case "\x0b":
		e.snapshot()
		r := []rune(b.lines[b.cy])
		b.lines[b.cy] = string(r[:b.cx])
		b.dirty = true
	case "\x0a":
		e.snapshot()
		r := []rune(b.lines[b.cy])
		b.lines[b.cy] = string(r[b.cx:])
		b.cx = 0
		b.dirty = true
	case "\x17":
		e.deleteWord()
	case "\x15":
		e.undo()
	case "\x12":
		e.redo()
	case "\x0c":
		e.message = "Ctrl-? for help"
	case "\x1f", "\x7e":
		e.showHelp()
	case "\x07":
		e.searchPrompt()
	default:
		if len(k) > 0 {
			r, _ := utf8.DecodeRuneInString(k)
			if r >= 32 && r != utf8.RuneError {
				e.insertRune(r)
			}
		}
	}
	if k != "\x11" {
		e.quitWarned = false
	}
	return false
}

func (e *Editor) anyDirty() bool {
	for _, b := range e.bufs {
		if b.dirty {
			return true
		}
	}
	return false
}

func cloneLines(lines []string) []string {
	cp := make([]string, len(lines))
	copy(cp, lines)
	return cp
}

func (e *Editor) snapshot() {
	b := e.buf()
	b.undo = append(b.undo, cloneLines(b.lines))
	if len(b.undo) > 100 {
		b.undo = b.undo[1:]
	}
	b.redo = nil
}

func (e *Editor) insertRune(r rune) {
	e.snapshot()
	b := e.buf()
	line := []rune(b.lines[b.cy])
	if b.cx > len(line) {
		b.cx = len(line)
	}
	line = append(line[:b.cx], append([]rune{r}, line[b.cx:]...)...)
	b.lines[b.cy] = string(line)
	b.cx++
	b.dirty = true
}

func (e *Editor) insertNewline() {
	e.snapshot()
	b := e.buf()
	line := []rune(b.lines[b.cy])
	left, right := string(line[:b.cx]), string(line[b.cx:])
	b.lines[b.cy] = left
	b.lines = append(b.lines[:b.cy+1], append([]string{right}, b.lines[b.cy+1:]...)...)
	b.cy++
	b.cx = 0
	b.dirty = true
}

func (e *Editor) backspace() {
	b := e.buf()
	if b.cx == 0 && b.cy == 0 {
		return
	}
	e.snapshot()
	if b.cx > 0 {
		line := []rune(b.lines[b.cy])
		b.lines[b.cy] = string(append(line[:b.cx-1], line[b.cx:]...))
		b.cx--
	} else {
		prevLen := len([]rune(b.lines[b.cy-1]))
		b.lines[b.cy-1] += b.lines[b.cy]
		b.lines = append(b.lines[:b.cy], b.lines[b.cy+1:]...)
		b.cy--
		b.cx = prevLen
	}
	b.dirty = true
}

func (e *Editor) delete() {
	b := e.buf()
	if b.cy >= len(b.lines) {
		return
	}
	line := []rune(b.lines[b.cy])
	if b.cx == len(line) && b.cy == len(b.lines)-1 {
		return
	}
	e.snapshot()
	if b.cx < len(line) {
		b.lines[b.cy] = string(append(line[:b.cx], line[b.cx+1:]...))
	} else {
		b.lines[b.cy] += b.lines[b.cy+1]
		b.lines = append(b.lines[:b.cy+1], b.lines[b.cy+2:]...)
	}
	b.dirty = true
}

func (e *Editor) deleteWord() {
	b := e.buf()
	if b.cx == 0 {
		return
	}
	e.snapshot()
	line := []rune(b.lines[b.cy])
	start := b.cx
	for start > 0 && line[start-1] == ' ' {
		start--
	}
	for start > 0 && line[start-1] != ' ' {
		start--
	}
	b.lines[b.cy] = string(append(line[:start], line[b.cx:]...))
	b.cx = start
	b.dirty = true
}

func (e *Editor) undo() {
	b := e.buf()
	if len(b.undo) == 0 {
		return
	}
	b.redo = append(b.redo, cloneLines(b.lines))
	b.lines = b.undo[len(b.undo)-1]
	b.undo = b.undo[:len(b.undo)-1]
	e.clampCursor()
	b.dirty = true
}

func (e *Editor) redo() {
	b := e.buf()
	if len(b.redo) == 0 {
		return
	}
	b.undo = append(b.undo, cloneLines(b.lines))
	b.lines = b.redo[len(b.redo)-1]
	b.redo = b.redo[:len(b.redo)-1]
	e.clampCursor()
	b.dirty = true
}

func (e *Editor) moveCursor(dir string) {
	b := e.buf()
	switch dir {
	case "left":
		if b.cx > 0 {
			b.cx--
		} else if b.cy > 0 {
			b.cy--
			b.cx = len([]rune(b.lines[b.cy]))
		}
	case "right":
		lineLen := len([]rune(b.lines[b.cy]))
		if b.cx < lineLen {
			b.cx++
		} else if b.cy < len(b.lines)-1 {
			b.cy++
			b.cx = 0
		}
	case "up":
		if b.cy > 0 {
			b.cy--
		}
	case "down":
		if b.cy < len(b.lines)-1 {
			b.cy++
		}
	}
	e.clampCursor()
}

func (e *Editor) clampCursor() {
	b := e.buf()
	if b.cy < 0 {
		b.cy = 0
	}
	if b.cy >= len(b.lines) {
		b.cy = len(b.lines) - 1
	}
	ll := len([]rune(b.lines[b.cy]))
	if b.cx > ll {
		b.cx = ll
	}
	if b.cx < 0 {
		b.cx = 0
	}
}

func (e *Editor) save() {
	b := e.buf()
	if b.name == "" {
		name := e.prompt("Save as: ")
		if strings.TrimSpace(name) == "" {
			e.message = "Save aborted"
			return
		}
		b.name = name
	}
	data := strings.Join(b.lines, "\n")
	if err := os.MkdirAll(filepath.Dir(b.name), 0755); err != nil && filepath.Dir(b.name) != "." {
		e.message = "Error: " + err.Error()
		return
	}
	if err := os.WriteFile(b.name, []byte(data), 0644); err != nil {
		e.message = "Error: " + err.Error()
		return
	}
	b.dirty = false
	e.message = fmt.Sprintf("%d bytes written to %s", len([]byte(data)), b.name)
}

func (e *Editor) prompt(prefix string) string {
	var s []rune
	for {
		e.message = prefix + string(s)
		e.refresh()
		k, err := e.readKey()
		if err != nil {
			return ""
		}
		switch k {
		case "\r", "\n":
			return string(s)
		case "\x1b", "esc", "\x07":
			return ""
		case "\x7f", "\b":
			if len(s) > 0 {
				s = s[:len(s)-1]
			}
		default:
			r, _ := utf8.DecodeRuneInString(k)
			if r >= 32 && r != utf8.RuneError {
				s = append(s, r)
			}
		}
	}
}

func (e *Editor) searchPrompt() {
	q := e.prompt("Search: ")
	if q == "" {
		e.message = ""
		return
	}
	for y, line := range e.buf().lines {
		if x := strings.Index(line, q); x >= 0 {
			e.buf().cy = y
			e.buf().cx = utf8.RuneCountInString(line[:x])
			e.message = "Found: " + q
			return
		}
	}
	e.message = "Not found: " + q
}

func (e *Editor) showHelp() {
	lines := strings.Split(strings.TrimRight(helpText, "\n"), "\n")
	old := e.message
	for {
		var out strings.Builder
		out.WriteString("\x1b[?25l")
		for i := 0; i < e.rows; i++ {
			out.WriteString(fmt.Sprintf("\x1b[%dH", i+1))
			if i < len(lines) {
				line := lines[i]
				if len([]rune(line)) > e.cols {
					line = string([]rune(line)[:e.cols])
				}
				out.WriteString(line)
			}
			out.WriteString("\x1b[K")
		}
		out.WriteString("\x1b[H\x1b[?25h")
		fmt.Fprint(e.stdout, out.String())
		k, err := e.readKey()
		if err != nil || k != "\x0c" {
			break
		}
	}
	e.message = old
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
