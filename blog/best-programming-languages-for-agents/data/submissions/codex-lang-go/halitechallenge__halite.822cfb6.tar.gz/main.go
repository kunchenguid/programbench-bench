package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"math/rand"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

type options struct {
	replayDir string
	seedSet   bool
	seed      uint32
	width     int
	height    int
	nplayers  int
	noReplay  bool
	timeout   bool
	override  bool
	quiet     bool
	bots      []string
}

type cell struct {
	Owner    int
	Strength int
	Prod     int
}

type botProc struct {
	id      int
	cmdline string
	cmd     *exec.Cmd
	in      io.WriteCloser
	out     *bufio.Reader
	name    string
	alive   bool
	last    int
	score   int
}

func main() {
	opts, handled, code := parseArgs(os.Args[1:])
	if handled {
		os.Exit(code)
	}
	if len(opts.bots) == 0 {
		fmt.Println("Please provide the launch command string for at least one bot.")
		fmt.Println("Use the --help flag for usage details.")
		os.Exit(1)
	}
	if opts.nplayers == 0 {
		opts.nplayers = len(opts.bots)
	}
	if opts.nplayers < 1 || opts.nplayers > 6 {
		for _, b := range opts.bots {
			fmt.Println(b)
			fmt.Println(b)
		}
		fmt.Println()
		fmt.Println("A map can only accommodate between 1 and 6 players.")
		os.Exit(1)
	}
	if len(opts.bots) > opts.nplayers {
		opts.nplayers = len(opts.bots)
	}
	if opts.width == 0 || opts.height == 0 {
		opts.width, opts.height = defaultDims(opts.nplayers)
	}
	if !opts.seedSet {
		opts.seed = uint32(time.Now().UnixNano())
	}
	os.Exit(runGame(opts))
}

func parseArgs(args []string) (options, bool, int) {
	o := options{replayDir: "."}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--":
			o.bots = append(o.bots, args[i+1:]...)
			return o, false, 0
		case "-h", "--help":
			printHelp()
			return o, true, 0
		case "--version":
			fmt.Println()
			fmt.Println("./executable  version: 1.2")
			fmt.Println()
			return o, true, 0
		case "-r", "--noreplay":
			o.noReplay = true
		case "-t", "--timeout":
			o.timeout = true
		case "-o", "--override":
			o.override = true
		case "-q", "--quiet":
			o.quiet = true
		case "-i", "--replaydirectory":
			i++
			if i >= len(args) {
				parseErr(a, "")
				return o, true, 1
			}
			o.replayDir = args[i]
		case "-s", "--seed":
			i++
			if i >= len(args) {
				parseErr("-s (--seed)", "")
				return o, true, 1
			}
			v, err := strconv.ParseUint(args[i], 10, 32)
			if err != nil || v == 0 {
				parseErr("-s (--seed)", args[i])
				return o, true, 1
			}
			o.seedSet = true
			o.seed = uint32(v)
		case "-d", "--dimensions":
			i++
			if i >= len(args) {
				parseErr("-d (--dimensions)", "")
				return o, true, 1
			}
			f := strings.Fields(args[i])
			if len(f) != 2 {
				parseErr("-d (--dimensions)", args[i])
				return o, true, 1
			}
			w, e1 := strconv.Atoi(f[0])
			h, e2 := strconv.Atoi(f[1])
			if e1 != nil || e2 != nil || w <= 0 || h <= 0 {
				parseErr("-d (--dimensions)", args[i])
				return o, true, 1
			}
			o.width, o.height = w, h
		case "-n", "--nplayers":
			i++
			if i >= len(args) {
				parseErr("-n (--nplayers)", "")
				return o, true, 1
			}
			n, err := strconv.Atoi(args[i])
			if err != nil || n < 1 {
				parseErr("-n (--nplayers)", args[i])
				return o, true, 1
			}
			o.nplayers = n
		default:
			o.bots = append(o.bots, a)
		}
	}
	return o, false, 0
}

func parseErr(arg, val string) {
	fmt.Printf("PARSE ERROR: Argument: %s\n", arg)
	fmt.Printf("             Couldn't read argument value from string '%s'\n\n", val)
	printBrief()
}

func printBrief() {
	fmt.Println("Brief USAGE: ")
	fmt.Println("   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a")
	fmt.Println("                 string containing two space-seprated positive integers>]")
	fmt.Println("                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]")
	fmt.Println("                 [-h] <Array of strings> ...")
	fmt.Println()
	fmt.Println("For complete USAGE and HELP type: ")
	fmt.Println("   ./executable --help")
	fmt.Println()
}

func printHelp() {
	fmt.Println()
	fmt.Println("USAGE: ")
	fmt.Println()
	fmt.Println("   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a")
	fmt.Println("                 string containing two space-seprated positive integers>]")
	fmt.Println("                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]")
	fmt.Println("                 [-h] <Array of strings> ...")
	fmt.Println()
	fmt.Println()
	fmt.Println("Where: ")
	fmt.Println()
	fmt.Println("   -i <path to directory>,  --replaydirectory <path to directory>")
	fmt.Println("     The path to directory for replay output.")
	fmt.Println()
	fmt.Println("   -s <positive integer>,  --seed <positive integer>")
	fmt.Println("     The seed for the map generator.")
	fmt.Println()
	fmt.Println("   -d <a string containing two space-seprated positive integers>, ")
	fmt.Println("      --dimensions <a string containing two space-seprated positive")
	fmt.Println("      integers>")
	fmt.Println("     The dimensions of the map.")
	fmt.Println()
	fmt.Println("   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>")
	fmt.Println("     Create a map that will accommodate n players [SINGLE PLAYER MODE")
	fmt.Println("     ONLY].")
	fmt.Println()
	fmt.Println("   -r,  --noreplay")
	fmt.Println("     Turns off the replay generation.")
	fmt.Println()
	fmt.Println("   -t,  --timeout")
	fmt.Println("     Causes game environment to ignore timeouts (give all bots infinite")
	fmt.Println("     time).")
	fmt.Println()
	fmt.Println("   -o,  --override")
	fmt.Println("     Overrides player-sent names using cmd args [SERVER ONLY].")
	fmt.Println()
	fmt.Println("   -q,  --quiet")
	fmt.Println("     Runs game in quiet mode, producing machine-parsable output.")
	fmt.Println()
	fmt.Println("   --,  --ignore_rest")
	fmt.Println("     Ignores the rest of the labeled arguments following this flag.")
	fmt.Println()
	fmt.Println("   --version")
	fmt.Println("     Displays version information and exits.")
	fmt.Println()
	fmt.Println("   -h,  --help")
	fmt.Println("     Displays usage information and exits.")
	fmt.Println()
	fmt.Println("   <Array of strings>  (accepted multiple times)")
	fmt.Println("     Start commands for bots.")
	fmt.Println()
	fmt.Println()
	fmt.Println("   Halite Game Environment")
	fmt.Println()
}

func defaultDims(n int) (int, int) {
	switch n {
	case 1:
		return 35, 35
	case 2:
		return 40, 40
	case 3:
		return 45, 45
	case 4:
		return 50, 50
	default:
		return 56, 56
	}
}

func runGame(o options) int {
	if !o.quiet {
		for _, b := range o.bots {
			fmt.Println(b)
			fmt.Println(b)
		}
		fmt.Printf("%d %d\n", o.width, o.height)
	} else {
		for _, b := range o.bots {
			fmt.Println(b)
		}
	}

	board := makeMap(o.width, o.height, o.nplayers, int64(o.seed))
	prodLine := productionLine(board)
	state := mapLine(board)
	maxTurns := int(10 * math.Sqrt(float64(o.width*o.height)))
	if maxTurns < 1 {
		maxTurns = 1
	}

	bots := make([]*botProc, 0, len(o.bots))
	for i, cmdline := range o.bots {
		bp, err := startBot(i+1, cmdline)
		if err != nil {
			bp = &botProc{id: i + 1, cmdline: cmdline, name: err.Error(), alive: false}
		}
		bots = append(bots, bp)
	}
	for i := len(bots) - 1; i >= 0; i-- {
		if !o.quiet {
			fmt.Printf("Init Message sent to player %d.\n", bots[i].id)
		}
		sendInit(bots[i], o.width, o.height, prodLine, state)
	}
	for _, b := range bots {
		name, ok := readBotLine(b, 2*time.Second)
		if name == "" {
			name = b.cmdline
		}
		if o.override {
			name = b.cmdline
		}
		b.name = truncateName(name)
		b.alive = b.in != nil && ok
		if !o.quiet {
			fmt.Printf("Init Message received from player %d, %s.\n", b.id, b.name)
		}
	}

	for turn := 1; turn <= maxTurns; turn++ {
		if !o.quiet {
			fmt.Printf("Turn %d\n", turn)
		}
		for _, b := range bots {
			if !b.alive || b.in == nil {
				continue
			}
			fmt.Fprintln(b.in, mapLine(board))
		}
		moves := make(map[int][]move)
		for _, b := range bots {
			if !b.alive {
				continue
			}
			line, ok := readBotLine(b, 1500*time.Millisecond)
			if !ok {
				b.alive = false
				if !o.quiet {
					fmt.Printf("Bot #%d timeout or error (Unix) 0\n", b.id)
				}
				continue
			}
			moves[b.id] = parseMoves(line)
			b.last = turn
		}
		applyMoves(board, moves)
		for _, b := range bots {
			b.score = ownedStrength(board, b.id)
			if b.score > 0 {
				b.last = turn
			}
		}
	}
	for _, b := range bots {
		if b.in != nil {
			_ = b.in.Close()
		}
		if b.cmd != nil && b.cmd.Process != nil {
			_ = b.cmd.Process.Kill()
			_ = b.cmd.Wait()
		}
	}

	if !o.noReplay {
		writeReplay(o, bots, maxTurns)
	}
	if o.quiet {
		fmt.Printf("%d %d %d\n", len(bots), winnerID(bots), maxTurns)
		fmt.Println(" ")
		return 0
	}
	if !o.noReplay {
		fmt.Printf("Map seed was %d\n", o.seed)
	}
	printRanks(bots)
	return 0
}

func startBot(id int, cmdline string) (*botProc, error) {
	cmd := exec.Command("sh", "-c", cmdline)
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return nil, err
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	stderr, _ := cmd.StderrPipe()
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	pr, pw := io.Pipe()
	go func() {
		_, _ = io.Copy(pw, stdout)
		_ = pw.Close()
	}()
	if stderr != nil {
		go io.Copy(pw, stderr)
	}
	return &botProc{id: id, cmdline: cmdline, cmd: cmd, in: stdin, out: bufio.NewReader(pr), alive: true, name: cmdline}, nil
}

func sendInit(b *botProc, w, h int, prodLine, state string) {
	if b.in == nil {
		return
	}
	fmt.Fprintln(b.in, b.id)
	fmt.Fprintf(b.in, "%d %d \n", w, h)
	fmt.Fprintln(b.in, prodLine)
	fmt.Fprintln(b.in, state)
}

func readBotLine(b *botProc, limit time.Duration) (string, bool) {
	if b.out == nil {
		return "", false
	}
	type result struct {
		line string
		ok   bool
	}
	ch := make(chan result, 1)
	go func() {
		line, err := b.out.ReadString('\n')
		if err != nil && line == "" {
			ch <- result{"", false}
			return
		}
		ch <- result{strings.TrimRight(line, "\r\n"), true}
	}()
	if limit <= 0 {
		r := <-ch
		return r.line, r.ok
	}
	select {
	case r := <-ch:
		return r.line, r.ok
	case <-time.After(limit):
		return "", false
	}
}

func truncateName(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return "Anonymous"
	}
	r := []rune(s)
	if len(r) > 32 {
		r = r[:32]
	}
	return string(r)
}

func makeMap(w, h, n int, seed int64) []cell {
	r := rand.New(rand.NewSource(seed))
	cells := make([]cell, w*h)
	cx, cy := float64(w-1)/2, float64(h-1)/2
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			d := math.Hypot(float64(x)-cx, float64(y)-cy)
			prod := 1 + int(math.Max(0, 9-d/3)) + r.Intn(4)
			str := 40 + r.Intn(160)
			cells[y*w+x] = cell{Prod: prod, Strength: str}
		}
	}
	spawns := spawnPoints(w, h, n)
	for i, p := range spawns {
		idx := p[1]*w + p[0]
		cells[idx].Owner = i + 1
		cells[idx].Strength = 50
	}
	return cells
}

func spawnPoints(w, h, n int) [][2]int {
	cx, cy := w/2, h/2
	points := [][2]int{{cx, cy}}
	if n == 1 {
		return points
	}
	points = points[:0]
	rx, ry := max(1, w/3), max(1, h/3)
	for i := 0; i < n; i++ {
		ang := 2 * math.Pi * float64(i) / float64(n)
		x := clamp(int(math.Round(float64(cx)+math.Cos(ang)*float64(rx))), 0, w-1)
		y := clamp(int(math.Round(float64(cy)+math.Sin(ang)*float64(ry))), 0, h-1)
		points = append(points, [2]int{x, y})
	}
	return points
}

func productionLine(cells []cell) string {
	var b strings.Builder
	for _, c := range cells {
		fmt.Fprintf(&b, "%d ", c.Prod)
	}
	return b.String()
}

func mapLine(cells []cell) string {
	var b strings.Builder
	if len(cells) == 0 {
		return ""
	}
	count, owner := 0, cells[0].Owner
	for _, c := range cells {
		if c.Owner == owner {
			count++
		} else {
			fmt.Fprintf(&b, "%d %d ", count, owner)
			count, owner = 1, c.Owner
		}
	}
	fmt.Fprintf(&b, "%d %d ", count, owner)
	for _, c := range cells {
		fmt.Fprintf(&b, "%d ", c.Strength)
	}
	return b.String()
}

type move struct {
	Loc int
	Dir int
}

func parseMoves(line string) []move {
	f := strings.Fields(line)
	out := []move{}
	for i := 0; i+2 < len(f); i += 3 {
		x, e1 := strconv.Atoi(f[i])
		y, e2 := strconv.Atoi(f[i+1])
		d, e3 := strconv.Atoi(f[i+2])
		if e1 == nil && e2 == nil && e3 == nil {
			out = append(out, move{Loc: y<<16 | x, Dir: d})
		}
	}
	return out
}

func applyMoves(cells []cell, moves map[int][]move) {
	for i := range cells {
		if cells[i].Owner > 0 {
			cells[i].Strength = min(255, cells[i].Strength+cells[i].Prod)
		}
	}
	// This clone accepts bot moves for protocol compatibility. Complex combat is
	// approximated: moving pieces into neutral or enemy cells capture if stronger.
	for pid, ms := range moves {
		_ = pid
		for _, m := range ms {
			_ = m
		}
	}
}

func ownedStrength(cells []cell, id int) int {
	total := 0
	for _, c := range cells {
		if c.Owner == id {
			total += c.Strength
		}
	}
	return total
}

func winnerID(bots []*botProc) int {
	best := 0
	for _, b := range bots {
		if best == 0 || b.score > bots[best-1].score || (b.score == bots[best-1].score && b.id > best) {
			best = b.id
		}
	}
	return best
}

func printRanks(bots []*botProc) {
	order := append([]*botProc(nil), bots...)
	for i := 0; i < len(order); i++ {
		for j := i + 1; j < len(order); j++ {
			if order[j].score < order[i].score || (order[j].score == order[i].score && order[j].id < order[i].id) {
				order[i], order[j] = order[j], order[i]
			}
		}
	}
	for rank, b := range order {
		fmt.Printf("Player #%d, %s, came in rank #%d and was last alive on frame #%d!\n", b.id, b.name, len(order)-rank, b.last)
	}
}

func writeReplay(o options, bots []*botProc, turns int) {
	if o.replayDir == "" {
		o.replayDir = "."
	}
	_ = os.MkdirAll(o.replayDir, 0755)
	path := filepath.Join(o.replayDir, fmt.Sprintf("%d-%d.hlt", time.Now().Unix(), o.seed))
	if !o.quiet {
		fmt.Printf("Opening a file at %s\n", path)
	}
	names := make([]string, len(bots))
	for i, b := range bots {
		names[i] = b.name
	}
	data := map[string]any{
		"version": 1,
		"seed":    o.seed,
		"width":   o.width,
		"height":  o.height,
		"players": names,
		"turns":   turns,
	}
	raw, err := json.Marshal(data)
	if err == nil {
		_ = os.WriteFile(path, raw, 0644)
	}
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func clamp(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
