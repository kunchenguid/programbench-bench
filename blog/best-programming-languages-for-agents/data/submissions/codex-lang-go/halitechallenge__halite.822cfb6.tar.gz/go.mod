module haliteclone

go 1.21
