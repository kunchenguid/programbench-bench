package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "ast-grep 0.42.1"

type options struct {
	cmd              string
	pattern          string
	rewrite          string
	lang             string
	paths            []string
	stdin            bool
	jsonStyle        string
	filesWithMatches bool
	updateAll        bool
	ruleFile         string
	inlineRules      string
	reportStyle      string
	format           string
	config           string
	yes              bool
	name             string
	subcmd           string
}

type match struct {
	Text      string   `json:"text"`
	Range     rng      `json:"range"`
	File      string   `json:"file"`
	Lines     string   `json:"lines"`
	CharCount counts   `json:"charCount"`
	Language  string   `json:"language"`
	RuleID    string   `json:"ruleId,omitempty"`
	Severity  string   `json:"severity,omitempty"`
	Note      *string  `json:"note,omitempty"`
	Message   string   `json:"message,omitempty"`
	Labels    []label  `json:"labels,omitempty"`
	lineNo    int
	lineText  string
}
type rng struct {
	ByteOffset span `json:"byteOffset"`
	Start      pos  `json:"start"`
	End        pos  `json:"end"`
}
type span struct {
	Start int `json:"start"`
	End   int `json:"end"`
}
type pos struct {
	Line   int `json:"line"`
	Column int `json:"column"`
}
type counts struct {
	Leading  int `json:"leading"`
	Trailing int `json:"trailing"`
}
type label struct {
	Text  string `json:"text"`
	Range rng    `json:"range"`
	Style string `json:"style"`
}
type rule struct {
	ID       string
	Language string
	Pattern  string
	Message  string
	Severity string
	Fix      string
}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		printTopHelp(stdout)
		return 0
	}
	if args[0] == "--version" || args[0] == "-V" {
		fmt.Fprintln(stdout, version)
		return 0
	}
	if args[0] == "--help" || args[0] == "-h" {
		printTopHelp(stdout)
		return 0
	}
	cmds := map[string]bool{"run": true, "scan": true, "test": true, "new": true, "lsp": true, "completions": true, "help": true}
	cmd := "run"
	if cmds[args[0]] {
		cmd = args[0]
		args = args[1:]
	}
	switch cmd {
	case "run":
		return runSearch(args, stdin, stdout, stderr)
	case "scan":
		return runScan(args, stdin, stdout, stderr)
	case "new":
		return runNew(args, stdout, stderr)
	case "test":
		if hasHelp(args) {
			printTestHelp(stdout)
			return 0
		}
		fmt.Fprintln(stdout, "No tests found")
		return 0
	case "lsp":
		if hasHelp(args) {
			fmt.Fprintln(stdout, "Start language server\n\nUsage: executable lsp [OPTIONS]\n\nOptions:\n  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml\n  -h, --help                  Print help")
			return 0
		}
		return 0
	case "completions":
		if hasHelp(args) {
			fmt.Fprintln(stdout, "Generate shell completion script\n\nUsage: executable completions [OPTIONS] [SHELL]\n\nArguments:\n  [SHELL]  Output the completion file for given shell. If not provided, shell flavor will be inferred from environment [possible values: bash, elvish, fish, powershell, zsh]\n\nOptions:\n  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml\n  -h, --help                  Print help")
			return 0
		}
		fmt.Fprintln(stdout, "# completion script generation is not available in this reimplementation")
		return 0
	case "help":
		printTopHelp(stdout)
		return 0
	}
	return 2
}

func runSearch(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	if hasHelp(args) {
		printRunHelp(stdout)
		return 0
	}
	o, err := parseRunArgs(args)
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 2
	}
	if o.pattern == "" {
		fmt.Fprintln(stderr, "error: the following required arguments were not provided:\n  --pattern <PATTERN>\n\nUsage: executable run --pattern <PATTERN> [PATHS]...\n\nFor more information, try '--help'.")
		return 2
	}
	if !validLang(o.lang) {
		fmt.Fprintf(stderr, "error: invalid value '%s' for '--lang <LANG>': %s is not supported!\n\nFor more information, try '--help'.\n", o.lang, o.lang)
		return 2
	}
	files, contents, err := loadInputs(o.paths, o.stdin, stdin)
	if err != nil {
		fmt.Fprintln(stderr, err)
		return 1
	}
	var all []match
	for _, f := range files {
		all = append(all, findMatches(contents[f], f, o.pattern, langName(o.lang), "", "", "")...)
	}
	if o.filesWithMatches {
		seen := map[string]bool{}
		for _, m := range all {
			if !seen[m.File] {
				fmt.Fprintln(stdout, m.File)
				seen[m.File] = true
			}
		}
		if len(all) == 0 {
			return 1
		}
		return 0
	}
	if o.jsonStyle != "" {
		printJSON(stdout, all, o.jsonStyle)
		if len(all) == 0 {
			return 1
		}
		return 0
	}
	if o.rewrite != "" {
		if o.updateAll {
			applied := 0
			for _, f := range files {
				ms := filterFile(all, f)
				if len(ms) == 0 || f == "STDIN" {
					continue
				}
				newText := applyRewrite(contents[f], ms, o.rewrite, o.pattern)
				if newText != contents[f] {
					_ = os.WriteFile(f, []byte(newText), 0644)
					applied += len(ms)
				}
			}
			fmt.Fprintf(stdout, "Applied %d changes\n", applied)
		} else {
			for _, f := range files {
				ms := filterFile(all, f)
				if len(ms) > 0 {
					fmt.Fprint(stdout, diffPreview(f, contents[f], applyRewrite(contents[f], ms, o.rewrite, o.pattern)))
				}
			}
		}
		if len(all) == 0 {
			return 1
		}
		return 0
	}
	for _, m := range all {
		fmt.Fprintf(stdout, "%s:%d:%s\n", m.File, m.lineNo, m.lineText)
	}
	if len(all) == 0 {
		return 1
	}
	return 0
}

func parseRunArgs(args []string) (options, error) {
	o := options{jsonStyle: "", lang: "", paths: nil}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-p" || a == "--pattern":
			i++; if i < len(args) { o.pattern = args[i] }
		case strings.HasPrefix(a, "--pattern="):
			o.pattern = strings.TrimPrefix(a, "--pattern=")
		case a == "-r" || a == "--rewrite":
			i++; if i < len(args) { o.rewrite = args[i] }
		case strings.HasPrefix(a, "--rewrite="):
			o.rewrite = strings.TrimPrefix(a, "--rewrite=")
		case a == "-l" || a == "--lang":
			i++; if i < len(args) { o.lang = args[i] }
		case strings.HasPrefix(a, "--lang="):
			o.lang = strings.TrimPrefix(a, "--lang=")
		case a == "--stdin":
			o.stdin = true
		case a == "--files-with-matches":
			o.filesWithMatches = true
		case a == "-U" || a == "--update-all":
			o.updateAll = true
		case a == "--json":
			o.jsonStyle = "pretty"
		case strings.HasPrefix(a, "--json="):
			o.jsonStyle = strings.TrimPrefix(a, "--json=")
		case a == "-c" || a == "--config" || a == "--selector" || a == "--strictness" || a == "--color" || a == "--inspect" || a == "--globs" || a == "--no-ignore" || a == "-j" || a == "--threads" || a == "--debug-query":
			i++
		case strings.HasPrefix(a, "-"):
			// Accept unimplemented flags for compatibility.
			if needsValue(a) && i+1 < len(args) { i++ }
		default:
			o.paths = append(o.paths, a)
		}
	}
	if len(o.paths) == 0 {
		o.paths = []string{"."}
	}
	return o, nil
}

func loadInputs(paths []string, useStdin bool, stdin io.Reader) ([]string, map[string]string, error) {
	out := map[string]string{}
	var files []string
	if useStdin {
		b, _ := io.ReadAll(stdin)
		out["STDIN"] = string(b)
		return []string{"STDIN"}, out, nil
	}
	for _, p := range paths {
		info, err := os.Stat(p)
		if err != nil {
			return nil, nil, err
		}
		if info.IsDir() {
			filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
				if err != nil || d.IsDir() || strings.HasPrefix(filepath.Base(path), ".") {
					return nil
				}
				if likelyCode(path) {
					if b, e := os.ReadFile(path); e == nil {
						files = append(files, path)
						out[path] = string(b)
					}
				}
				return nil
			})
		} else if b, e := os.ReadFile(p); e == nil {
			files = append(files, p)
			out[p] = string(b)
		}
	}
	sort.Strings(files)
	return files, out, nil
}

func likelyCode(p string) bool {
	ext := strings.ToLower(filepath.Ext(p))
	switch ext {
	case ".js", ".jsx", ".ts", ".tsx", ".py", ".go", ".rs", ".java", ".c", ".h", ".cpp", ".cc", ".cs", ".rb", ".php", ".yml", ".yaml", ".json", ".sh", ".html", ".css", ".vue", ".svelte":
		return true
	}
	return ext == ""
}

func findMatches(content, file, pattern, language, ruleID, sev, msg string) []match {
	re, exact := patternRegexp(pattern)
	lines := splitLines(content)
	var ret []match
	offset := 0
	for li, line := range lines {
		search := strings.TrimRight(line, "\r\n")
		idxs := re.FindAllStringIndex(search, -1)
		if len(idxs) == 0 && exact != "" {
			if j := strings.Index(search, exact); j >= 0 {
				idxs = [][]int{{j, j + len(exact)}}
			}
		}
		for _, ix := range idxs {
			txt := search[ix[0]:ix[1]]
			m := match{
				Text: txt, File: file, Lines: search, Language: language,
				CharCount: counts{Leading: ix[0], Trailing: len(search) - ix[1]},
				Range: rng{ByteOffset: span{offset + ix[0], offset + ix[1]}, Start: pos{li, ix[0]}, End: pos{li, ix[1]}},
				lineNo: li + 1, lineText: search,
			}
			if ruleID != "" {
				m.RuleID, m.Severity, m.Message = ruleID, sev, msg
				m.Note = nil
				m.Labels = []label{{Text: txt, Range: m.Range, Style: "primary"}}
			}
			ret = append(ret, m)
		}
		offset += len(line)
	}
	return ret
}

func patternRegexp(p string) (*regexp.Regexp, string) {
	orig := strings.TrimSpace(p)
	body := regexp.QuoteMeta(orig)
	meta := regexp.MustCompile(`\\\$[A-Z_][A-Z0-9_]*`)
	body = meta.ReplaceAllString(body, `[^;\n,(){}]+`)
	body = strings.ReplaceAll(body, `\ `, `\s+`)
	body = strings.ReplaceAll(body, `\;`, `;?`)
	if strings.HasSuffix(body, `\(\)`) {
		body = strings.TrimSuffix(body, `\(\)`) + `\s*\(\s*\)`
	}
	re, err := regexp.Compile(body)
	if err != nil {
		return regexp.MustCompile(regexp.QuoteMeta(orig)), strings.TrimSuffix(orig, ";")
	}
	return re, strings.TrimSuffix(orig, ";")
}

func splitLines(s string) []string {
	if s == "" { return []string{""} }
	var lines []string
	start := 0
	for i, r := range s {
		if r == '\n' {
			lines = append(lines, s[start:i+1])
			start = i+1
		}
	}
	if start < len(s) { lines = append(lines, s[start:]) }
	return lines
}

func printJSON(w io.Writer, ms []match, style string) {
	for i := range ms {
		ms[i].lineNo = 0
		ms[i].lineText = ""
	}
	switch style {
	case "stream":
		enc := json.NewEncoder(w)
		for _, m := range ms { _ = enc.Encode(m) }
	case "compact":
		b, _ := json.Marshal(ms); fmt.Fprintln(w, string(b))
	default:
		b, _ := json.MarshalIndent(ms, "", "  "); fmt.Fprintln(w, string(b))
	}
}

func filterFile(ms []match, f string) []match {
	var out []match
	for _, m := range ms { if m.File == f { out = append(out, m) } }
	return out
}

func applyRewrite(content string, ms []match, repl, pattern string) string {
	if len(ms) == 0 { return content }
	sort.Slice(ms, func(i, j int) bool { return ms[i].Range.ByteOffset.Start > ms[j].Range.ByteOffset.Start })
	out := content
	for _, m := range ms {
		r := materializeRewrite(pattern, m.Text, repl)
		out = out[:m.Range.ByteOffset.Start] + r + out[m.Range.ByteOffset.End:]
	}
	return out
}

func materializeRewrite(pattern, text, repl string) string {
	pvars := regexp.MustCompile(`\$[A-Z_][A-Z0-9_]*`).FindAllString(pattern, -1)
	if len(pvars) == 0 { return repl }
	re, _ := regexp.Compile("^" + patternRegexpForCapture(pattern) + "$")
	sm := re.FindStringSubmatch(text)
	if sm == nil { return repl }
	vals := map[string]string{}
	for i, v := range pvars {
		if i+1 < len(sm) { vals[v] = sm[i+1] }
	}
	out := repl
	for k, v := range vals { out = strings.ReplaceAll(out, k, strings.TrimSpace(v)) }
	return out
}

func patternRegexpForCapture(p string) string {
	body := regexp.QuoteMeta(strings.TrimSpace(p))
	meta := regexp.MustCompile(`\\\$[A-Z_][A-Z0-9_]*`)
	body = meta.ReplaceAllString(body, `(.+?)`)
	body = strings.ReplaceAll(body, `\ `, `\s+`)
	body = strings.ReplaceAll(body, `\;`, `;?`)
	return body
}

func diffPreview(file, oldText, newText string) string {
	oldL, newL := strings.Split(strings.TrimRight(oldText, "\n"), "\n"), strings.Split(strings.TrimRight(newText, "\n"), "\n")
	var b strings.Builder
	fmt.Fprintf(&b, "%s\n@@ -0,%d +0,%d @@\n", file, len(oldL), len(newL))
	n := len(oldL); if len(newL) > n { n = len(newL) }
	for i:=0;i<n;i++ {
		var o, ne string
		if i < len(oldL) { o = oldL[i] }
		if i < len(newL) { ne = newL[i] }
		switch {
		case i < len(oldL) && i < len(newL) && o == ne:
			fmt.Fprintf(&b, "%d %d│ %s\n", i+1, i+1, o)
		default:
			if i < len(oldL) { fmt.Fprintf(&b, "%d  │-%s\n", i+1, o) }
			if i < len(newL) { fmt.Fprintf(&b, "  %d│+%s\n", i+1, ne) }
		}
	}
	return b.String()
}

func runScan(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	if hasHelp(args) { printScanHelp(stdout); return 0 }
	o := options{reportStyle:"rich"}
	for i:=0;i<len(args);i++ {
		a:=args[i]
		switch {
		case a=="-r" || a=="--rule": i++; if i<len(args){o.ruleFile=args[i]}
		case strings.HasPrefix(a,"--rule="): o.ruleFile=strings.TrimPrefix(a,"--rule=")
		case a=="--inline-rules": i++; if i<len(args){o.inlineRules=args[i]}
		case strings.HasPrefix(a,"--inline-rules="): o.inlineRules=strings.TrimPrefix(a,"--inline-rules=")
		case a=="--json": o.jsonStyle="pretty"
		case strings.HasPrefix(a,"--json="): o.jsonStyle=strings.TrimPrefix(a,"--json=")
		case a=="--format": i++; if i<len(args){o.format=args[i]}
		case strings.HasPrefix(a,"--format="): o.format=strings.TrimPrefix(a,"--format=")
		case a=="--report-style": i++; if i<len(args){o.reportStyle=args[i]}
		case strings.HasPrefix(a,"--report-style="): o.reportStyle=strings.TrimPrefix(a,"--report-style=")
		case strings.HasPrefix(a,"-"): if needsValue(a)&&i+1<len(args){i++}
		default: o.paths=append(o.paths,a)
		}
	}
	if len(o.paths)==0 { o.paths=[]string{"."} }
	var rules []rule
	if o.ruleFile != "" {
		b, err := os.ReadFile(o.ruleFile); if err != nil { fmt.Fprintln(stderr, err); return 1 }
		rules = append(rules, parseRule(string(b)))
	} else if o.inlineRules != "" {
		for _, part := range strings.Split(o.inlineRules, "---") { rules = append(rules, parseRule(part)) }
	} else {
		cfgRules := rulesFromConfig("sgconfig.yml")
		rules = append(rules, cfgRules...)
	}
	files, contents, err := loadInputs(o.paths, false, stdin); if err != nil { fmt.Fprintln(stderr, err); return 1 }
	var all []match
	for _, r := range rules {
		if r.Severity == "" { r.Severity = "warning" }
		for _, f := range files {
			all = append(all, findMatches(contents[f], f, r.Pattern, langName(r.Language), r.ID, r.Severity, r.Message)...)
		}
	}
	if o.jsonStyle != "" { printJSON(stdout, all, o.jsonStyle); if len(all)>0 {return 1}; return 0 }
	for _, m := range all {
		if o.format == "github" {
			fmt.Fprintf(stdout, "::%s file=%s,line=%d,endLine=%d,title=%s::%s\n", m.Severity, m.File, m.lineNo, m.lineNo, m.RuleID, m.Message)
		} else if o.reportStyle == "short" || o.reportStyle == "medium" {
			fmt.Fprintf(stdout, "%s:%d:%d: %s[%s]: %s\n", m.File, m.lineNo, m.Range.Start.Column+1, m.Severity, m.RuleID, m.Message)
		} else {
			fmt.Fprintf(stdout, "%s[%s]: %s\n  ┌─ %s:%d:%d\n  │\n%d │ %s\n  │ %s\n\n", m.Severity, m.RuleID, m.Message, m.File, m.lineNo, m.Range.Start.Column+1, m.lineNo, m.lineText, strings.Repeat("^", max(1, len(m.Text))))
		}
	}
	if len(all)>0 { return 1 }
	return 0
}

func parseRule(s string) rule {
	r := rule{Severity:"warning", Message:""}
	lines := strings.Split(s, "\n")
	for i:=0; i<len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if line=="" || strings.HasPrefix(line,"#") { continue }
		if strings.HasPrefix(line, "id:") { r.ID = cleanY(line[3:]) }
		if strings.HasPrefix(line, "language:") { r.Language = cleanY(line[9:]) }
		if strings.HasPrefix(line, "message:") { r.Message = cleanY(line[8:]) }
		if strings.HasPrefix(line, "severity:") { r.Severity = strings.Fields(cleanY(line[9:]))[0] }
		if strings.HasPrefix(line, "pattern:") { r.Pattern = cleanY(line[8:]) }
		if strings.HasPrefix(line, "fix:") { r.Fix = cleanY(line[4:]) }
	}
	if r.ID=="" { r.ID="rule" }
	if r.Pattern=="" { r.Pattern=r.ID }
	if r.Message=="" { r.Message=r.ID }
	return r
}

func cleanY(s string) string {
	s = strings.TrimSpace(s)
	s = strings.Trim(s, `"'`)
	return s
}

func rulesFromConfig(path string) []rule {
	b, err := os.ReadFile(path); if err != nil { return nil }
	var dirs []string
	sc := bufio.NewScanner(bytes.NewReader(b))
	inRules := false
	for sc.Scan() {
		t := strings.TrimSpace(sc.Text())
		if strings.HasPrefix(t,"ruleDirs:") { inRules=true; continue }
		if strings.HasSuffix(t,":") && !strings.HasPrefix(t,"-") { inRules=false }
		if inRules && strings.HasPrefix(t,"-") { dirs=append(dirs, cleanY(strings.TrimPrefix(t,"-"))) }
	}
	var rs []rule
	for _, d := range dirs {
		filepath.WalkDir(d, func(p string, de os.DirEntry, err error) error {
			if err==nil && !de.IsDir() && (strings.HasSuffix(p,".yml")||strings.HasSuffix(p,".yaml")) {
				if bb,e:=os.ReadFile(p); e==nil { rs=append(rs, parseRule(string(bb))) }
			}
			return nil
		})
	}
	return rs
}

func runNew(args []string, stdout, stderr io.Writer) int {
	if hasHelp(args) || len(args)==0 { printNewHelp(stdout); return 0 }
	sub := args[0]; args=args[1:]
	if hasHelp(args) { printNewSubHelp(stdout, sub); return 0 }
	o := options{subcmd:sub}
	for i:=0;i<len(args);i++ {
		a:=args[i]
		switch a {
		case "-l","--lang": i++; if i<len(args){o.lang=args[i]}
		case "-y","--yes": o.yes=true
		case "-c","--config": i++
		default:
			if !strings.HasPrefix(a,"-") && o.name=="" { o.name=a }
		}
	}
	switch sub {
	case "project":
		fmt.Fprintln(stdout, "Creating a new ast-grep project...")
		cwd,_:=os.Getwd()
		_ = os.MkdirAll("rules",0755); _=os.MkdirAll("rule-tests",0755); _=os.MkdirAll("utils",0755)
		_ = os.WriteFile("rules/.gitkeep", nil, 0644); _=os.WriteFile("rule-tests/.gitkeep", nil,0644); _=os.WriteFile("utils/.gitkeep", nil,0644)
		cfg := fmt.Sprintf("ruleDirs:\n- %s/rules\ntestConfigs:\n- testDir: %s/rule-tests\nutilDirs:\n- %s/utils\n", cwd,cwd,cwd)
		_ = os.WriteFile("sgconfig.yml", []byte(cfg), 0644)
		fmt.Fprintln(stdout, "Your new ast-grep project has been created!")
	case "rule":
		if o.name=="" { fmt.Fprintln(stderr,"Error: name is required"); return 1 }
		if o.lang=="" { o.lang="JavaScript" }
		_ = os.MkdirAll("rules",0755)
		p := filepath.Join("rules", o.name+".yml")
		txt := fmt.Sprintf("# yaml-language-server: $schema=https://raw.githubusercontent.com/ast-grep/ast-grep/main/schemas/rule.json\n\nid: %s\nmessage: Add your rule message here....\nseverity: error # error, warning, info, hint\nlanguage: %s\nrule:\n  pattern: Your Rule Pattern here...\n# utils: Extract repeated rule as local utility here.\n# note: Add detailed explanation for the rule.", o.name, langName(o.lang))
		if err:=writeNew(p,txt); err!=nil { fmt.Fprintln(stderr,err); return 1 }
		abs,_:=filepath.Abs(p); fmt.Fprintf(stdout,"Created rules at %s\n",abs)
	case "test":
		if o.name=="" { fmt.Fprintln(stderr,"Error: name is required"); return 1 }
		_ = os.MkdirAll("rule-tests",0755)
		p := filepath.Join("rule-tests", o.name+"-test.yml")
		txt := fmt.Sprintf("id: %s\nvalid:\n- \"valid code\"\ninvalid:\n- \"invalid code\"", o.name)
		if err:=writeNew(p,txt); err!=nil { fmt.Fprintln(stderr,err); return 1 }
		abs,_:=filepath.Abs(p); fmt.Fprintf(stdout,"Created test at %s\n",abs)
	case "util":
		if o.name=="" { fmt.Fprintln(stderr,"Error: name is required"); return 1 }
		if o.lang=="" { o.lang="JavaScript" }
		_ = os.MkdirAll("utils",0755)
		p := filepath.Join("utils", o.name+".yml")
		txt := fmt.Sprintf("id: %s\nlanguage: %s\nrule:\n  pattern: Your Rule Pattern here...\n# utils: Extract repeated rule as local utility here.", o.name, langName(o.lang))
		if err:=writeNew(p,txt); err!=nil { fmt.Fprintln(stderr,err); return 1 }
		abs,_:=filepath.Abs(p); fmt.Fprintf(stdout,"Created util at %s\n",abs)
	default:
		fmt.Fprintf(stderr,"error: unrecognized subcommand '%s'\n", sub); return 2
	}
	return 0
}

func writeNew(p, txt string) error {
	if _, err := os.Stat(p); err == nil { return errors.New("Error: File `" + p + "` already exists.") }
	return os.WriteFile(p, []byte(txt), 0644)
}

func validLang(l string) bool {
	if l=="" { return true }
	_, ok := langMap()[strings.ToLower(l)]
	return ok
}
func langName(l string) string {
	if l=="" { return "" }
	if v, ok := langMap()[strings.ToLower(l)]; ok { return v }
	return l
}
func langMap() map[string]string {
	return map[string]string{"js":"JavaScript","javascript":"JavaScript","ts":"TypeScript","typescript":"TypeScript","tsx":"Tsx","jsx":"JavaScript","py":"Python","python":"Python","go":"Go","golang":"Go","rs":"Rust","rust":"Rust","java":"Java","c":"C","cpp":"Cpp","c++":"Cpp","cs":"CSharp","csharp":"CSharp","rb":"Ruby","ruby":"Ruby","yaml":"Yaml","yml":"Yaml","json":"Json","bash":"Bash","sh":"Bash","html":"Html","css":"Css","php":"Php"}
}

func hasHelp(args []string) bool { for _, a := range args { if a=="--help"||a=="-h"{return true} }; return false }
func needsValue(a string) bool { return !strings.Contains(a,"=") && (a=="-c"||a=="--config"||a=="-l"||a=="--lang"||a=="-p"||a=="--pattern"||a=="-r"||a=="--rewrite"||a=="--format"||a=="--report-style"||a=="--globs"||a=="--no-ignore"||a=="-j"||a=="--threads") }
func max(a,b int) int { if a>b {return a}; return b }

func printTopHelp(w io.Writer) {
	fmt.Fprintln(w, `Search and Rewrite code at large scale using AST pattern.

Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>  Path to ast-grep root config, default is sgconfig.yml
  -h, --help                  Print help (see a summary with '-h')
  -V, --version               Print version`)
}
func printRunHelp(w io.Writer) { fmt.Fprintln(w, `Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Options:
  -p, --pattern <PATTERN>  AST pattern to match
  -r, --rewrite <FIX>      String to replace the matched AST node
  -l, --lang <LANG>        The language of the pattern
      --stdin              Enable search code from StdIn.
      --files-with-matches Print only the paths with at least one match
      --json[=<STYLE>]     Output matches in structured JSON
  -U, --update-all         Apply all rewrite without confirmation if true
  -h, --help               Print help`) }
func printScanHelp(w io.Writer) { fmt.Fprintln(w, `Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Options:
  -r, --rule <RULE_FILE>       Scan the codebase with the single rule located at the path RULE_FILE.
      --inline-rules <TEXT>    Scan with inline YAML rule text.
      --format <FORMAT>        Supported formats: github, sarif
      --report-style <STYLE>   rich, medium, short
      --json[=<STYLE>]         Output matches in structured JSON.
  -h, --help                   Print help`) }
func printTestHelp(w io.Writer) { fmt.Fprintln(w, `Test ast-grep rules

Usage: executable test [OPTIONS]

Options:
  -t, --test-dir <TEST_DIR>  the directories to search test YAML files
  -U, --update-all           Update snapshots
  -h, --help                 Print help`) }
func printNewHelp(w io.Writer) { fmt.Fprintln(w, `Create new ast-grep project or items like rules/tests

Usage: executable new [OPTIONS] [NAME] [COMMAND]

Commands:
  project  Create an new project by scaffolding
  rule     Create a new rule
  test     Create a new test case
  util     Create a new global utility rule
  help     Print this message or the help of the given subcommand(s)`) }
func printNewSubHelp(w io.Writer, sub string) {
	fmt.Fprintf(w, "Create a new %s.\n\nUsage: executable new %s [OPTIONS] [NAME]\n\nOptions:\n  -l, --lang <LANG>  The language of the item to create.\n  -y, --yes          Accept all default options without interactive input during creation.\n  -h, --help         Print help\n", sub, sub)
}

func atoi(s string) int { i,_ := strconv.Atoi(s); return i }
