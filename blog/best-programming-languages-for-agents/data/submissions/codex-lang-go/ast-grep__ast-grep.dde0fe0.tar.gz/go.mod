module sgclone

go 1.21
