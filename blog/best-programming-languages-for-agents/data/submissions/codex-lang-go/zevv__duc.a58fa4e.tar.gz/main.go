package main

import (
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"html"
	"io/fs"
	"math"
	"os"
	"os/user"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const version = "1.5.0-rc1"

type DB struct {
	Version string  `json:"version"`
	Created string  `json:"created"`
	Roots   []*Node `json:"roots"`
	Files   int     `json:"files"`
	Dirs    int     `json:"dirs"`
}

type Node struct {
	Name     string  `json:"name"`
	Path     string  `json:"path"`
	IsDir    bool    `json:"is_dir"`
	Apparent int64   `json:"size_apparent"`
	Actual   int64   `json:"size_actual"`
	Count    int     `json:"count,omitempty"`
	Children []*Node `json:"children,omitempty"`
}

type Options struct {
	db           string
	bytes        bool
	apparent     bool
	recursive    bool
	ascii        bool
	classify     bool
	directory    bool
	dirsOnly     bool
	fullPath     bool
	graph        bool
	nameSort     bool
	countMode    bool
	excludeFiles bool
	minSize      int64
	levels       int
	verbose      int
	quiet        bool
	checkLinks   bool
	hideNames    bool
	dryRun       bool
	excludes     []string
	topN         int
	topNMin      int64
	base10       bool
	format       string
	output       string
	size         string
}

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	if len(args) == 0 {
		printMainHelp()
		return 0
	}
	if args[0] == "--version" {
		fmt.Printf("duc version: %s\noptions: cairo x11 ui sqlite3\n", version)
		return 0
	}
	if args[0] == "-h" || args[0] == "--help" {
		printMainHelp()
		return 0
	}
	global := Options{db: defaultDB(), levels: 4, topN: 10, format: "png", output: "duc.png", size: "800"}
	for len(args) > 0 {
		switch args[0] {
		case "--debug":
			global.verbose = 2
		case "-v", "--verbose":
			global.verbose++
		case "-q", "--quiet":
			global.quiet = true
		default:
			goto doneGlobal
		}
		args = args[1:]
	}
doneGlobal:
	if len(args) == 0 {
		printMainHelp()
		return 0
	}
	cmd := args[0]
	if cmd == "help" {
		return cmdHelp(args[1:])
	}
	opts, rest, err := parseOptions(cmd, args[1:], global)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if opts.HelpRequested() {
		printCmdHelp(cmd)
		return 0
	}
	switch cmd {
	case "index":
		return cmdIndex(opts, rest)
	case "info":
		return withDB(opts, func(db *DB) int { return cmdInfo(opts, db) })
	case "ls":
		return withDB(opts, func(db *DB) int { return cmdLS(opts, db, rest) })
	case "json":
		return withDB(opts, func(db *DB) int { return cmdJSON(opts, db, rest) })
	case "xml":
		return withDB(opts, func(db *DB) int { return cmdXML(opts, db, rest) })
	case "topn":
		return withDB(opts, func(db *DB) int { return cmdTopN(opts, db) })
	case "histogram":
		return withDB(opts, func(db *DB) int { return cmdHistogram(opts, db) })
	case "graph":
		return withDB(opts, func(db *DB) int { return cmdGraph(opts, db, rest) })
	case "cgi":
		return withDB(opts, func(db *DB) int { return cmdCGI(opts, db, rest) })
	case "gui", "ui":
		fmt.Fprintf(os.Stderr, "Error: interactive command '%s' is not available in this reimplementation\n", cmd)
		return 1
	default:
		printMainHelp()
		return 0
	}
}

func defaultDB() string {
	if v := os.Getenv("DUC_DATABASE"); v != "" {
		return v
	}
	if h, err := os.UserHomeDir(); err == nil {
		return filepath.Join(h, ".duc.db")
	}
	return ".duc.db"
}

func parseOptions(cmd string, args []string, base Options) (Options, []string, error) {
	o := base
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			rest = append(rest, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			rest = append(rest, args[i:]...)
			break
		}
		key, val, hasVal := strings.Cut(a, "=")
		take := func() (string, error) {
			if hasVal {
				return val, nil
			}
			i++
			if i >= len(args) {
				return "", fmt.Errorf("Option '%s' requires an argument", key)
			}
			return args[i], nil
		}
		switch key {
		case "-h", "--help":
			o.quiet = o.quiet
			return optionHelp(o), rest, nil
		case "-d", "--database":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.db = expandHome(v)
		case "-b", "--bytes":
			o.bytes = true
		case "-a", "--apparent":
			o.apparent = true
		case "-R", "--recursive":
			o.recursive = true
		case "--ascii":
			o.ascii = true
		case "-F", "--classify":
			o.classify = true
		case "-D", "--directory":
			o.directory = true
		case "--dirs-only":
			o.dirsOnly = true
		case "--full-path":
			o.fullPath = true
		case "-g", "--graph":
			o.graph = true
		case "-n", "--name-sort":
			o.nameSort = true
		case "--count":
			o.countMode = true
		case "-x", "--exclude-files", "--one-file-system":
			if key == "--exclude-files" {
				o.excludeFiles = true
			}
		case "-l", "--levels":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.levels, _ = strconv.Atoi(v)
		case "-s", "--min_size", "--size":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			if cmd == "json" || cmd == "xml" {
				o.minSize = parseSize(v)
			} else {
				o.size = v
			}
		case "-e", "--exclude":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.excludes = append(o.excludes, v)
		case "-H", "--check-hard-links", "--histogram":
			if cmd == "index" {
				o.checkLinks = true
			}
		case "--hide-file-names":
			o.hideNames = true
		case "--dry-run":
			o.dryRun = true
		case "-T", "--topn":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.topN, _ = strconv.Atoi(v)
		case "-M", "--topn-min":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.topNMin = parseSize(v)
		case "-u", "--username":
			_, err := take()
			if err != nil {
				return o, nil, err
			}
		case "-U", "--uid", "-m", "--max-depth", "-B", "--buckets", "--fs-exclude", "--fs-include", "--dpi", "--fuzz", "--palette", "--ring-gap", "--css-url", "--header", "--footer":
			_, err := take()
			if err != nil {
				return o, nil, err
			}
		case "-f", "--force", "-p", "--progress", "--uncompressed", "--gradient", "--list", "--tooltip", "--dark", "--no-color":
			if key == "-f" || key == "--format" {
				if cmd == "graph" {
					v, err := take()
					if err != nil {
						return o, nil, err
					}
					o.format = v
				}
			}
		case "--format":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.format = v
		case "-o", "--output":
			v, err := take()
			if err != nil {
				return o, nil, err
			}
			o.output = v
		case "-t", "--base10":
			o.base10 = true
		case "-v", "--verbose":
			o.verbose++
		case "-q", "--quiet":
			o.quiet = true
		case "--debug":
			o.verbose = 2
		default:
			return o, nil, fmt.Errorf("Unknown option '%s'", key)
		}
	}
	return o, rest, nil
}

type helpOptions struct{ Options }

func optionHelp(o Options) Options    { o.output = "\x00HELP"; return o }
func (o Options) HelpRequested() bool { return o.output == "\x00HELP" }

func cmdHelp(args []string) int {
	if len(args) == 0 {
		printMainHelp()
		return 0
	}
	if args[0] == "-a" || args[0] == "--all" {
		printAllHelp()
		return 0
	}
	printCmdHelp(args[0])
	return 0
}

func cmdIndex(o Options, paths []string) int {
	if o.HelpRequested() {
		printCmdHelp("index")
		return 0
	}
	if len(paths) == 0 {
		fmt.Fprintln(os.Stderr, "No path given")
		return 1
	}
	start := time.Now()
	db := &DB{Version: version, Created: time.Now().Format("2006-01-02 15:04:05")}
	seen := map[string]bool{}
	for _, p := range paths {
		abs, _ := filepath.Abs(p)
		n, files, dirs, err := scan(abs, true, o, seen)
		if err != nil {
			if !o.quiet {
				fmt.Fprintf(os.Stderr, "Skipping %s: %v\n", p, err)
			}
			continue
		}
		db.Roots = append(db.Roots, n)
		db.Files += files
		db.Dirs += dirs
	}
	if o.verbose > 0 {
		fmt.Printf("Writing to database \"%s\"\n", o.db)
	}
	if !o.dryRun {
		if err := saveDB(o.db, db); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
	}
	if o.verbose > 0 {
		var app, act int64
		for _, r := range db.Roots {
			app += r.Apparent
			act += r.Actual + dirOwnActual(r.Path)
		}
		fmt.Printf("Indexed %d files and %d directories, (%s apparent, %s actual) in %.2f secs.\n", db.Files, db.Dirs, formatSizeVerbose(app, o.bytes), formatSizeVerbose(act, o.bytes), time.Since(start).Seconds())
	}
	return 0
}

func scan(path string, isRoot bool, o Options, seen map[string]bool) (*Node, int, int, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, 0, 0, err
	}
	name := filepath.Base(path)
	if isRoot {
		name = path
	}
	n := &Node{Name: name, Path: path, IsDir: info.IsDir()}
	if excluded(name, o.excludes) {
		return nil, 0, 0, fs.SkipDir
	}
	st, _ := info.Sys().(*syscall.Stat_t)
	ownActual := int64(0)
	if st != nil {
		ownActual = int64(st.Blocks) * 512
	}
	if !info.IsDir() {
		if o.checkLinks && st != nil {
			key := fmt.Sprintf("%d:%d", st.Dev, st.Ino)
			if seen[key] {
				return nil, 0, 0, nil
			}
			seen[key] = true
		}
		n.Apparent = info.Size()
		n.Actual = ownActual
		if o.hideNames {
			n.Name = "FILE"
		}
		return n, 1, 0, nil
	}
	files, dirs := 0, 1
	entries, err := os.ReadDir(path)
	if err != nil {
		return n, 0, 1, nil
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].Name() < entries[j].Name() })
	childActual := int64(0)
	for _, e := range entries {
		child, cf, cd, err := scan(filepath.Join(path, e.Name()), false, o, seen)
		if err != nil || child == nil {
			continue
		}
		n.Children = append(n.Children, child)
		files += cf
		dirs += cd
		n.Apparent += child.Apparent
		childActual += child.Actual
	}
	if isRoot {
		n.Actual = childActual
		n.Count = files + dirs - 1
	} else {
		n.Actual = ownActual + childActual
		n.Count = files + dirs
	}
	return n, files, dirs, nil
}

func excluded(name string, pats []string) bool {
	for _, p := range pats {
		if ok, _ := filepath.Match(p, name); ok {
			return true
		}
		if strings.Contains(name, p) {
			return true
		}
	}
	return false
}

func saveDB(path string, db *DB) error {
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil && filepath.Dir(path) != "." {
		return err
	}
	b, _ := json.MarshalIndent(db, "", "  ")
	return os.WriteFile(path, b, 0644)
}

func loadDB(path string) (*DB, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, errors.New("Error opening: " + path + " - Database not found")
	}
	var db DB
	if err := json.Unmarshal(b, &db); err != nil {
		return nil, errors.New("Error opening: " + path + " - Database not found")
	}
	return &db, nil
}

func withDB(o Options, fn func(*DB) int) int {
	if o.HelpRequested() {
		return 0
	}
	db, err := loadDB(o.db)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return fn(db)
}

func cmdInfo(o Options, db *DB) int {
	if o.HelpRequested() {
		printCmdHelp("info")
		return 0
	}
	fmt.Println("Date       Time       Files    Dirs    Size Path")
	for _, r := range db.Roots {
		size := r.Actual
		if !o.apparent {
			size += dirOwnActual(r.Path)
		}
		if o.apparent {
			size = r.Apparent
		}
		date, tm := "0000-00-00", "00:00:00"
		if t, err := time.Parse("2006-01-02 15:04:05", db.Created); err == nil {
			date, tm = t.Format("2006-01-02"), t.Format("15:04:05")
		}
		fmt.Printf("%s %s %7d %7d %7s %s\n", date, tm, countFiles(r), countDirs(r), formatSize(size, o.bytes), r.Path)
	}
	return 0
}

func cmdLS(o Options, db *DB, paths []string) int {
	if o.HelpRequested() {
		printCmdHelp("ls")
		return 0
	}
	if len(paths) == 0 {
		paths = []string{"."}
	}
	for pi, p := range paths {
		n := findPath(db, p)
		if n == nil {
			fmt.Fprintf(os.Stderr, "Path not found: %s\n", p)
			continue
		}
		if pi > 0 {
			fmt.Println()
		}
		if o.directory {
			fmt.Printf("%12s %s\n", valString(n, o), displayName(n, o, true))
			continue
		}
		if o.recursive {
			printTree(o, n, "", true, 0)
		} else {
			children := filteredSorted(n.Children, o)
			max := int64(0)
			for _, c := range children {
				if v := value(c, o); v > max {
					max = v
				}
			}
			for _, c := range children {
				fmt.Printf("%12s %s", valString(c, o), displayName(c, o, false))
				if o.graph {
					fmt.Printf(" [%s]", bar(value(c, o), max))
				}
				fmt.Println()
			}
		}
	}
	return 0
}

func printTree(o Options, n *Node, prefix string, last bool, depth int) {
	if depth >= o.levels && o.levels > 0 && depth != 0 {
		return
	}
	children := filteredSorted(n.Children, o)
	for i, c := range children {
		l := i == len(children)-1
		conn, next := "╰─ ", "   "
		if !l {
			conn, next = "├─ ", "│  "
		}
		if o.ascii {
			conn, next = "`- ", "   "
			if !l {
				conn, next = "|- ", "|  "
			}
		} else if c.IsDir && len(c.Children) > 0 {
			if l {
				conn = "╰┬─ "
			} else {
				conn = "├┬─ "
			}
		}
		fmt.Printf("%12s %s%s%s\n", valString(c, o), prefix, conn, displayName(c, o, false))
		if c.IsDir {
			printTree(o, c, prefix+next, l, depth+1)
		}
	}
}

func cmdJSON(o Options, db *DB, paths []string) int {
	if o.HelpRequested() {
		printCmdHelp("json")
		return 0
	}
	p := "."
	if len(paths) > 0 {
		p = paths[0]
	}
	n := findPath(db, p)
	if n == nil {
		fmt.Fprintf(os.Stderr, "Path not found: %s\n", p)
		return 1
	}
	printJSONNode(n, true, o, 0)
	fmt.Println()
	return 0
}

func printJSONNode(n *Node, root bool, o Options, indent int) {
	pad := strings.Repeat(" ", indent)
	pad2 := strings.Repeat(" ", indent+2)
	name := n.Name
	if root {
		name = n.Path
	}
	fmt.Printf("%s{\n", pad)
	fmt.Printf("%s\"name\": %q", pad2, name)
	if n.IsDir {
		fmt.Printf(",\n%s\"count\": %d", pad2, n.Count)
	}
	fmt.Printf(",\n%s\"size_apparent\": %d,\n%s\"size_actual\": %d", pad2, n.Apparent, pad2, n.Actual)
	if n.IsDir {
		kids := filteredChildrenForDump(n, o)
		fmt.Printf(",\n%s\"children\": [", pad2)
		if len(kids) == 0 {
			fmt.Printf("\n\n%s]", pad2)
		} else {
			fmt.Println()
			for i, c := range kids {
				printJSONNode(c, false, o, indent+4)
				if i != len(kids)-1 {
					fmt.Println(",")
				} else {
					fmt.Println()
				}
			}
			fmt.Printf("%s]", pad2)
		}
	}
	fmt.Printf("\n%s}", pad)
}

func cmdXML(o Options, db *DB, paths []string) int {
	if o.HelpRequested() {
		printCmdHelp("xml")
		return 0
	}
	p := "."
	if len(paths) > 0 {
		p = paths[0]
	}
	n := findPath(db, p)
	if n == nil {
		fmt.Fprintf(os.Stderr, "Path not found: %s\n", p)
		return 1
	}
	fmt.Println(`<?xml version="1.0" encoding="UTF-8"?>`)
	fmt.Printf(`<duc root="%s" size_apparent="%d" size_actual="%d" count="%d">`+"\n", xmlEscape(n.Path), n.Apparent, n.Actual, n.Count)
	for _, c := range filteredChildrenForDump(n, o) {
		printXML(c, 1, o)
	}
	fmt.Println("</duc>")
	return 0
}

func printXML(n *Node, depth int, o Options) {
	ind := strings.Repeat(" ", depth)
	if n.IsDir {
		fmt.Printf(`%s<ent type="dir" name="%s" size_apparent="%d" size_actual="%d" count="%d">`+"\n", ind, xmlEscape(n.Name), n.Apparent, n.Actual, n.Count)
		for _, c := range filteredChildrenForDump(n, o) {
			printXML(c, depth+1, o)
		}
		fmt.Printf("%s</ent>\n", ind)
	} else {
		fmt.Printf(`%s<ent name="%s" size_apparent="%d" size_actual="%d" />`+"\n", ind, xmlEscape(n.Name), n.Apparent, n.Actual)
	}
}

func cmdTopN(o Options, db *DB) int {
	if o.HelpRequested() {
		printCmdHelp("topn")
		return 0
	}
	var files []*Node
	for _, r := range db.Roots {
		collectFiles(r, &files)
	}
	sort.Slice(files, func(i, j int) bool {
		if files[i].Actual == files[j].Actual {
			return files[i].Path < files[j].Path
		}
		return files[i].Actual > files[j].Actual
	})
	fmt.Println("        Size Filename")
	limit := o.topN
	if limit <= 0 || limit > len(files) {
		limit = len(files)
	}
	for i := 0; i < limit; i++ {
		if files[i].Actual < o.topNMin {
			continue
		}
		fmt.Printf("%12s %s\n", formatSize(files[i].Actual, o.bytes), files[i].Path)
	}
	return 0
}

func cmdHistogram(o Options, db *DB) int {
	if o.HelpRequested() {
		printCmdHelp("histogram")
		return 0
	}
	for _, r := range db.Roots {
		fmt.Printf("Path: %s\n", r.Path)
		fmt.Println("Bkt       Size      Count")
		var files []*Node
		collectFiles(r, &files)
		base := 2.0
		maxB := 47
		if o.base10 {
			base = 10
			maxB = 15
		}
		for b := 0; b <= maxB; b++ {
			limit := int64(math.Pow(base, float64(b)))
			cnt := 0
			for _, f := range files {
				v := f.Apparent
				if bucket(v, base) == b {
					cnt++
				}
			}
			fmt.Printf("%3d %10s %10d\n", b, formatSize(limit, false), cnt)
		}
	}
	return 0
}

func cmdGraph(o Options, db *DB, paths []string) int {
	if o.HelpRequested() {
		printCmdHelp("graph")
		return 0
	}
	out := o.output
	data := []byte(`<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><text x="20" y="40">duc graph</text></svg>` + "\n")
	if o.format == "html" {
		data = []byte("<html><body>duc graph</body></html>\n")
	}
	if out == "-" {
		os.Stdout.Write(data)
	} else {
		os.WriteFile(out, data, 0644)
	}
	_ = db
	_ = paths
	return 0
}

func cmdCGI(o Options, db *DB, paths []string) int {
	if o.HelpRequested() {
		printCmdHelp("cgi")
		return 0
	}
	fmt.Println("Content-Type: text/html")
	fmt.Println()
	fmt.Println("<html><body><h1>Duc index</h1><ul>")
	for _, r := range db.Roots {
		fmt.Printf("<li>%s %s</li>\n", html.EscapeString(formatSize(r.Actual, o.bytes)), html.EscapeString(r.Path))
	}
	fmt.Println("</ul></body></html>")
	_ = paths
	return 0
}

func findPath(db *DB, p string) *Node {
	abs, _ := filepath.Abs(p)
	abs = filepath.Clean(abs)
	for _, r := range db.Roots {
		if filepath.Clean(r.Path) == abs {
			return r
		}
		if strings.HasPrefix(abs, filepath.Clean(r.Path)+string(os.PathSeparator)) {
			if n := findIn(r, abs); n != nil {
				return n
			}
		}
	}
	return nil
}

func findIn(n *Node, p string) *Node {
	if filepath.Clean(n.Path) == p {
		return n
	}
	for _, c := range n.Children {
		if x := findIn(c, p); x != nil {
			return x
		}
	}
	return nil
}

func filteredSorted(children []*Node, o Options) []*Node {
	var out []*Node
	for _, c := range children {
		if o.dirsOnly && !c.IsDir {
			continue
		}
		out = append(out, c)
	}
	sort.SliceStable(out, func(i, j int) bool {
		if o.nameSort {
			return out[i].Name < out[j].Name
		}
		vi, vj := value(out[i], o), value(out[j], o)
		if vi == vj {
			return out[i].Name < out[j].Name
		}
		return vi > vj
	})
	return out
}

func filteredChildrenForDump(n *Node, o Options) []*Node {
	var out []*Node
	for _, c := range n.Children {
		if o.excludeFiles && !c.IsDir {
			continue
		}
		v := c.Actual
		if o.apparent {
			v = c.Apparent
		}
		if o.minSize > 0 && v < o.minSize && !c.IsDir {
			continue
		}
		out = append(out, c)
	}
	sort.SliceStable(out, func(i, j int) bool {
		vi, vj := value(out[i], o), value(out[j], o)
		if vi == vj {
			return out[i].Name < out[j].Name
		}
		return vi > vj
	})
	return out
}

func value(n *Node, o Options) int64 {
	if o.countMode {
		return int64(n.Count)
	}
	if o.apparent {
		return n.Apparent
	}
	return n.Actual
}

func valString(n *Node, o Options) string {
	if o.countMode {
		return strconv.FormatInt(value(n, o), 10)
	}
	return formatSize(value(n, o), o.bytes)
}

func displayName(n *Node, o Options, full bool) string {
	name := n.Name
	if o.fullPath || full {
		name = n.Path
	}
	if o.classify {
		if n.IsDir {
			name += "/"
		} else {
			name += " "
		}
	}
	return name
}

func countFiles(n *Node) int {
	if !n.IsDir {
		return 1
	}
	s := 0
	for _, c := range n.Children {
		s += countFiles(c)
	}
	return s
}
func countDirs(n *Node) int {
	if !n.IsDir {
		return 0
	}
	s := 1
	for _, c := range n.Children {
		s += countDirs(c)
	}
	return s
}
func collectFiles(n *Node, out *[]*Node) {
	if !n.IsDir {
		*out = append(*out, n)
		return
	}
	for _, c := range n.Children {
		collectFiles(c, out)
	}
}

func formatSize(v int64, bytes bool) string {
	if bytes {
		return strconv.FormatInt(v, 10)
	}
	units := []string{"B", "K", "M", "G", "T", "P"}
	f := float64(v)
	i := 0
	for f >= 1024 && i < len(units)-1 {
		f /= 1024
		i++
	}
	if i == 0 {
		return fmt.Sprintf("%d", v)
	}
	return fmt.Sprintf("%.1f%s", f, units[i])
}

func formatSizeVerbose(v int64, bytes bool) string {
	if bytes {
		return strconv.FormatInt(v, 10) + "B"
	}
	s := formatSize(v, false)
	if len(s) > 0 {
		last := s[len(s)-1]
		if last < '0' || last > '9' {
			return s + "B"
		}
	}
	return s + "B"
}

func parseSize(s string) int64 {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0
	}
	mul := int64(1)
	last := s[len(s)-1]
	if last < '0' || last > '9' {
		switch strings.ToLower(string(last)) {
		case "k":
			mul = 1024
		case "m":
			mul = 1024 * 1024
		case "g":
			mul = 1024 * 1024 * 1024
		}
		s = s[:len(s)-1]
	}
	f, _ := strconv.ParseFloat(s, 64)
	return int64(f * float64(mul))
}

func bucket(v int64, base float64) int {
	if v <= 1 {
		return 0
	}
	return int(math.Floor(math.Log(float64(v)) / math.Log(base)))
}

func bar(v, max int64) string {
	width := 54
	if max <= 0 {
		return strings.Repeat(" ", width)
	}
	n := int(math.Round(float64(v) / float64(max) * float64(width)))
	if n > width {
		n = width
	}
	return strings.Repeat("+", n) + strings.Repeat(" ", width-n)
}

func dirOwnActual(path string) int64 {
	if st, err := os.Lstat(path); err == nil {
		if x, ok := st.Sys().(*syscall.Stat_t); ok {
			return int64(x.Blocks) * 512
		}
	}
	return 0
}

func expandHome(p string) string {
	if p == "~" {
		if h, err := os.UserHomeDir(); err == nil {
			return h
		}
	}
	if strings.HasPrefix(p, "~/") {
		if h, err := os.UserHomeDir(); err == nil {
			return filepath.Join(h, p[2:])
		}
	}
	return p
}

func xmlEscape(s string) string {
	var b strings.Builder
	xml.EscapeText(&b, []byte(s))
	return b.String()
}

func init() { _, _ = user.Current() }

func printMainHelp() {
	fmt.Print(`usage: duc <cmd> [options] [args]

Available subcommands:

  help      : Show help
  histogram : Dump histogram of file sizes found.
  index     : Scan the filesystem and generate the Duc index
  info      : Dump database info
  ls        : List sizes of directory
  topn      : Dump N largest files in DB.
  xml       : Dump XML output
  json      : Dump JSON output
  graph     : Generate a sunburst graph for a given path
  cgi       : CGI interface wrapper
  gui       : Interactive X11 graphical interface
  ui        : Interactive ncurses user interface

Global options:
       --debug               increase verbosity to debug level
  -h,  --help                show help
  -q,  --quiet               quiet mode, do not print any warning
  -v,  --verbose             increase verbosity
       --version             output version information and exit

Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all
options and detailed description of the subcommand.

Use 'duc help --all' for a complete list of all options for all subcommands.
`)
}

func printCmdHelp(cmd string) {
	text := map[string]string{
		"index":     "usage: duc index [options] PATH ...\n\nScan the filesystem and generate the Duc index.\n\nOptions for the command 'index':\n  -b,  --bytes               show file size in exact number of bytes\n  -d,  --database=VAL        use database file VAL\n  -e,  --exclude=VAL         exclude files matching VAL\n  -H,  --check-hard-links    count hard links only once. if two or more hard links point to the same file, only one of the hard links is displayed and counted \n  -f,  --force               force writing in case of corrupted db\n       --hide-file-names     hide file names in index (privacy)\n  -x,  --one-file-system     skip directories on different file systems\n  -p,  --progress            show progress during indexing\n       --dry-run             do not update database, just crawl\n",
		"info":      "usage: duc info [options]\n\nDump database info.\n\nOptions for the command 'info':\n  -a,  --apparent            show apparent instead of actual file size\n  -b,  --bytes               show file size in exact number of bytes\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n",
		"ls":        "usage: duc ls [options] [PATH]...\n\nList sizes of directory.\n\nOptions for the command 'ls':\n  -a,  --apparent            show apparent instead of actual file size\n       --ascii               use ASCII characters instead of UTF-8 to draw tree\n  -b,  --bytes               show file size in exact number of bytes\n  -F,  --classify            append file type indicator (one of */) to entries\n  -D,  --directory           list directory itself, not its contents\n       --dirs-only           list only directories, skip individual files\n  -g,  --graph               draw graph with relative size for each entry\n  -l,  --levels=VAL          traverse up to ARG levels deep [4]\n  -n,  --name-sort           sort output by name instead of by size\n  -R,  --recursive           recursively list subdirectories\n",
		"json":      "usage: duc json [options] [PATH]\n\nDump JSON output.\n\nOptions for the command 'json':\n  -a,  --apparent            interpret min_size/-s value as apparent size\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -x,  --exclude-files       exclude file from json output, only include directories\n  -s,  --min_size=VAL        specify min size for files or directories\n",
		"xml":       "usage: duc xml [options] [PATH]\n\nDump XML output.\n\nOptions for the command 'xml':\n  -a,  --apparent            interpret min_size/-s value as apparent size\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -x,  --exclude-files       exclude file from xml output, only include directories\n  -s,  --min_size=VAL        specify min size for files or directories\n",
		"topn":      "usage: duc topn [options]\n\nDump N largest files in DB..\n\nOptions for the command 'topn':\n  -b,  --bytes               show file size in exact number of bytes\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n",
		"histogram": "usage: duc histogram [options]\n\nDump histogram of file sizes found..\n\nOptions for the command 'histogram':\n  -a,  --apparent            show apparent instead of actual file size\n  -b,  --bytes               show bucket size in exact number of bytes\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -t,  --base10              show histogram in base 10 bucket spacing, default base2 bucket sizes.\n",
		"graph":     "usage: duc graph [options] [PATH]\n\nGenerate a sunburst graph for a given path.\n",
		"cgi":       "usage: duc cgi [options] [PATH]\n\nCGI interface wrapper.\n",
		"gui":       "usage: duc gui [options] [PATH]\n\nInteractive X11 graphical interface.\n",
		"ui":        "usage: duc ui [options] [PATH]\n\nInteractive ncurses user interface.\n",
		"help":      "usage: duc help [options]\n\nShow help.\n\nOptions for the command 'help':\n  -a,  --all                 show complete help for all commands\n",
	}
	if s, ok := text[cmd]; ok {
		fmt.Print(s)
		fmt.Print("\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n")
		return
	}
	printMainHelp()
}

func printAllHelp() {
	printMainHelp()
	for _, c := range []string{"help", "histogram", "index", "info", "ls", "topn", "xml", "json", "graph", "cgi", "gui", "ui"} {
		fmt.Println()
		printCmdHelp(c)
	}
}
