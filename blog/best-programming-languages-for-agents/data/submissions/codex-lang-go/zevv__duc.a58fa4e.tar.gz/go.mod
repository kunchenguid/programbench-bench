module ducclone

go 1.21
