module parqeye-reimpl

go 1.21
