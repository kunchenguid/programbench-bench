package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const helpText = `Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version
`

type schemaElement struct {
	Name           string
	Type           *int32
	RepetitionType *int32
	NumChildren    *int32
	ConvertedType  *int32
	TypeLength     *int32
	Precision      *int32
	Scale          *int32
}

type keyValue struct {
	Key   string
	Value string
}

type columnMeta struct {
	Type                  *int32
	Encodings             []int32
	Path                  []string
	Codec                 *int32
	NumValues             int64
	TotalUncompressedSize int64
	TotalCompressedSize   int64
	DataPageOffset        int64
	IndexPageOffset       int64
	DictionaryPageOffset  int64
}

type columnChunk struct {
	FilePath   string
	FileOffset int64
	Meta       columnMeta
}

type rowGroup struct {
	Columns             []columnChunk
	TotalByteSize       int64
	NumRows             int64
	TotalCompressedSize int64
	Ordinal             int64
}

type parquetMeta struct {
	Version  int32
	Schema   []schemaElement
	NumRows  int64
	Rows     []rowGroup
	KV       []keyValue
	Created  string
	Metadata string
}

type compactReader struct {
	data  []byte
	pos   int
	stack []int16
	last  int16
}

func main() {
	args := os.Args[1:]
	if len(args) == 1 && (args[0] == "-h" || args[0] == "--help") {
		fmt.Print(helpText)
		return
	}
	if len(args) == 1 && (args[0] == "-V" || args[0] == "--version") {
		fmt.Println("parqeye 0.0.2")
		return
	}
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:")
		fmt.Fprintln(os.Stderr, "  <PATH>")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Usage: executable <PATH>")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		os.Exit(2)
	}
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n", a)
			if a != "--" {
				fmt.Fprintf(os.Stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", a, a)
			}
			fmt.Fprintln(os.Stderr, "Usage: executable <PATH>")
			fmt.Fprintln(os.Stderr)
			fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
			os.Exit(2)
		}
	}
	if len(args) > 1 {
		fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n", args[1])
		fmt.Fprintln(os.Stderr, "Usage: executable <PATH>")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		os.Exit(2)
	}

	path := args[0]
	meta, err := readParquetMeta(path)
	if err != nil {
		enterAlt()
		fmt.Printf("Error: Custom { kind: Other, error: \"Parquet error: %s\" }\n", err)
		os.Exit(1)
	}
	runViewer(path, meta)
}

func readParquetMeta(path string) (parquetMeta, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return parquetMeta{}, fmt.Errorf("%v", err)
	}
	if len(b) < 12 || string(b[:4]) != "PAR1" || string(b[len(b)-4:]) != "PAR1" {
		return parquetMeta{}, errors.New("Invalid Parquet file. Corrupt footer")
	}
	footerLen := int(binary.LittleEndian.Uint32(b[len(b)-8 : len(b)-4]))
	if footerLen < 0 || footerLen > len(b)-8 {
		return parquetMeta{}, errors.New("Invalid Parquet file. Corrupt footer")
	}
	cr := &compactReader{data: b[len(b)-8-footerLen : len(b)-8]}
	meta, err := cr.readFileMeta()
	if err != nil {
		return parquetMeta{}, err
	}
	return meta, nil
}

func (r *compactReader) readFileMeta() (parquetMeta, error) {
	var m parquetMeta
	for {
		id, typ, err := r.readField()
		if err != nil {
			return m, err
		}
		if typ == 0 {
			break
		}
		switch id {
		case 1:
			v, err := r.readI32()
			if err != nil {
				return m, err
			}
			m.Version = v
		case 2:
			n, et, err := r.readListBegin()
			if err != nil {
				return m, err
			}
			if et != 12 {
				return m, fmt.Errorf("unexpected schema list type")
			}
			for i := 0; i < n; i++ {
				s, err := r.readSchemaElement()
				if err != nil {
					return m, err
				}
				m.Schema = append(m.Schema, s)
			}
		case 3:
			v, err := r.readI64()
			if err != nil {
				return m, err
			}
			m.NumRows = v
		case 4:
			n, et, err := r.readListBegin()
			if err != nil {
				return m, err
			}
			if et != 12 {
				return m, fmt.Errorf("unexpected row group list type")
			}
			for i := 0; i < n; i++ {
				g, err := r.readRowGroup()
				if err != nil {
					return m, err
				}
				m.Rows = append(m.Rows, g)
			}
		case 5:
			kv, err := r.readKeyValues()
			if err != nil {
				return m, err
			}
			m.KV = kv
		case 6:
			s, err := r.readString()
			if err != nil {
				return m, err
			}
			m.Created = s
		default:
			if err := r.skip(typ); err != nil {
				return m, err
			}
		}
	}
	return m, nil
}

func (r *compactReader) readSchemaElement() (schemaElement, error) {
	r.push()
	defer r.pop()
	var s schemaElement
	for {
		id, typ, err := r.readField()
		if err != nil {
			return s, err
		}
		if typ == 0 {
			break
		}
		switch id {
		case 1:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.Type = &v
		case 2:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.TypeLength = &v
		case 3:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.RepetitionType = &v
		case 4:
			v, err := r.readString()
			if err != nil {
				return s, err
			}
			s.Name = v
		case 5:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.NumChildren = &v
		case 6:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.ConvertedType = &v
		case 7:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.Scale = &v
		case 8:
			v, err := r.readI32()
			if err != nil {
				return s, err
			}
			s.Precision = &v
		default:
			if err := r.skip(typ); err != nil {
				return s, err
			}
		}
	}
	return s, nil
}

func (r *compactReader) readKeyValues() ([]keyValue, error) {
	n, et, err := r.readListBegin()
	if err != nil {
		return nil, err
	}
	if et != 12 {
		return nil, fmt.Errorf("unexpected key value list type")
	}
	var out []keyValue
	for i := 0; i < n; i++ {
		r.push()
		var kv keyValue
		for {
			id, typ, err := r.readField()
			if err != nil {
				return nil, err
			}
			if typ == 0 {
				break
			}
			switch id {
			case 1:
				kv.Key, err = r.readString()
			case 2:
				kv.Value, err = r.readString()
			default:
				err = r.skip(typ)
			}
			if err != nil {
				return nil, err
			}
		}
		r.pop()
		out = append(out, kv)
	}
	return out, nil
}

func (r *compactReader) readRowGroup() (rowGroup, error) {
	r.push()
	defer r.pop()
	var g rowGroup
	for {
		id, typ, err := r.readField()
		if err != nil {
			return g, err
		}
		if typ == 0 {
			break
		}
		switch id {
		case 1:
			n, et, err := r.readListBegin()
			if err != nil {
				return g, err
			}
			if et != 12 {
				return g, fmt.Errorf("unexpected column list type")
			}
			for i := 0; i < n; i++ {
				c, err := r.readColumnChunk()
				if err != nil {
					return g, err
				}
				g.Columns = append(g.Columns, c)
			}
		case 2:
			g.TotalByteSize, err = r.readI64()
		case 3:
			g.NumRows, err = r.readI64()
		case 7:
			g.TotalCompressedSize, err = r.readI64()
		case 8:
			g.Ordinal, err = r.readI64()
		default:
			err = r.skip(typ)
		}
		if err != nil {
			return g, err
		}
	}
	return g, nil
}

func (r *compactReader) readColumnChunk() (columnChunk, error) {
	r.push()
	defer r.pop()
	var c columnChunk
	for {
		id, typ, err := r.readField()
		if err != nil {
			return c, err
		}
		if typ == 0 {
			break
		}
		switch id {
		case 1:
			c.FilePath, err = r.readString()
		case 2:
			c.FileOffset, err = r.readI64()
		case 3:
			c.Meta, err = r.readColumnMeta()
		default:
			err = r.skip(typ)
		}
		if err != nil {
			return c, err
		}
	}
	return c, nil
}

func (r *compactReader) readColumnMeta() (columnMeta, error) {
	r.push()
	defer r.pop()
	var c columnMeta
	for {
		id, typ, err := r.readField()
		if err != nil {
			return c, err
		}
		if typ == 0 {
			break
		}
		switch id {
		case 1:
			v, err := r.readI32()
			if err != nil {
				return c, err
			}
			c.Type = &v
		case 2:
			c.Encodings, err = r.readI32List()
		case 3:
			c.Path, err = r.readStringList()
		case 4:
			v, err := r.readI32()
			if err != nil {
				return c, err
			}
			c.Codec = &v
		case 5:
			c.NumValues, err = r.readI64()
		case 6:
			c.TotalUncompressedSize, err = r.readI64()
		case 7:
			c.TotalCompressedSize, err = r.readI64()
		case 9:
			c.DataPageOffset, err = r.readI64()
		case 10:
			c.IndexPageOffset, err = r.readI64()
		case 11:
			c.DictionaryPageOffset, err = r.readI64()
		default:
			err = r.skip(typ)
		}
		if err != nil {
			return c, err
		}
	}
	return c, nil
}

func (r *compactReader) readField() (int16, byte, error) {
	b, err := r.readByte()
	if err != nil {
		return 0, 0, err
	}
	typ := b & 0x0f
	if typ == 0 {
		return 0, typ, nil
	}
	mod := int16((b & 0xf0) >> 4)
	if mod == 0 {
		v, err := r.readI16()
		if err != nil {
			return 0, 0, err
		}
		r.last = v
		return v, typ, nil
	}
	r.last += mod
	return r.last, typ, nil
}

func (r *compactReader) readListBegin() (int, byte, error) {
	b, err := r.readByte()
	if err != nil {
		return 0, 0, err
	}
	n := int((b & 0xf0) >> 4)
	et := b & 0x0f
	if n == 15 {
		u, err := r.readUvarint()
		if err != nil {
			return 0, 0, err
		}
		n = int(u)
	}
	return n, et, nil
}

func (r *compactReader) readI32List() ([]int32, error) {
	n, et, err := r.readListBegin()
	if err != nil {
		return nil, err
	}
	if et != 5 {
		return nil, fmt.Errorf("unexpected i32 list type")
	}
	out := make([]int32, 0, n)
	for i := 0; i < n; i++ {
		v, err := r.readI32()
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, nil
}

func (r *compactReader) readStringList() ([]string, error) {
	n, et, err := r.readListBegin()
	if err != nil {
		return nil, err
	}
	if et != 8 {
		return nil, fmt.Errorf("unexpected string list type")
	}
	out := make([]string, 0, n)
	for i := 0; i < n; i++ {
		v, err := r.readString()
		if err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, nil
}

func (r *compactReader) readString() (string, error) {
	n, err := r.readUvarint()
	if err != nil {
		return "", err
	}
	if int(n) > len(r.data)-r.pos {
		return "", io.ErrUnexpectedEOF
	}
	s := string(r.data[r.pos : r.pos+int(n)])
	r.pos += int(n)
	return s, nil
}

func (r *compactReader) readI16() (int16, error) {
	u, err := r.readUvarint()
	return int16((u >> 1) ^ uint64(-int64(u&1))), err
}

func (r *compactReader) readI32() (int32, error) {
	u, err := r.readUvarint()
	return int32((u >> 1) ^ uint64(-int64(u&1))), err
}

func (r *compactReader) readI64() (int64, error) {
	u, err := r.readUvarint()
	return int64((u >> 1) ^ uint64(-int64(u&1))), err
}

func (r *compactReader) readUvarint() (uint64, error) {
	var x uint64
	var s uint
	for i := 0; i < 10; i++ {
		b, err := r.readByte()
		if err != nil {
			return 0, err
		}
		if b < 0x80 {
			if i == 9 && b > 1 {
				return 0, errors.New("varint overflow")
			}
			return x | uint64(b)<<s, nil
		}
		x |= uint64(b&0x7f) << s
		s += 7
	}
	return 0, errors.New("varint overflow")
}

func (r *compactReader) readByte() (byte, error) {
	if r.pos >= len(r.data) {
		return 0, io.ErrUnexpectedEOF
	}
	b := r.data[r.pos]
	r.pos++
	return b, nil
}

func (r *compactReader) skip(typ byte) error {
	switch typ {
	case 0, 1, 2:
		return nil
	case 3:
		_, err := r.readByte()
		return err
	case 4:
		_, err := r.readI16()
		return err
	case 5:
		_, err := r.readI32()
		return err
	case 6:
		_, err := r.readI64()
		return err
	case 7:
		if len(r.data)-r.pos < 8 {
			return io.ErrUnexpectedEOF
		}
		r.pos += 8
		return nil
	case 8:
		_, err := r.readString()
		return err
	case 9, 10:
		n, et, err := r.readListBegin()
		if err != nil {
			return err
		}
		for i := 0; i < n; i++ {
			if err := r.skip(et); err != nil {
				return err
			}
		}
		return nil
	case 11:
		b, err := r.readByte()
		if err != nil {
			return err
		}
		if b == 0 {
			return nil
		}
		n, err := r.readUvarint()
		if err != nil {
			return err
		}
		kt, vt := b>>4, b&0x0f
		for i := 0; i < int(n); i++ {
			if err := r.skip(kt); err != nil {
				return err
			}
			if err := r.skip(vt); err != nil {
				return err
			}
		}
		return nil
	case 12:
		r.push()
		for {
			_, ft, err := r.readField()
			if err != nil {
				r.pop()
				return err
			}
			if ft == 0 {
				break
			}
			if err := r.skip(ft); err != nil {
				r.pop()
				return err
			}
		}
		r.pop()
		return nil
	default:
		return fmt.Errorf("unsupported thrift compact type %d", typ)
	}
}

func (r *compactReader) push() { r.stack = append(r.stack, r.last); r.last = 0 }
func (r *compactReader) pop()  { r.last = r.stack[len(r.stack)-1]; r.stack = r.stack[:len(r.stack)-1] }

func runViewer(path string, meta parquetMeta) {
	enterAlt()
	defer fmt.Print("\033[?25h")
	tab := 0
	render(path, meta, tab)
	buf := make([]byte, 16)
	for {
		n, err := os.Stdin.Read(buf)
		if err != nil || n == 0 {
			return
		}
		for _, b := range buf[:n] {
			switch b {
			case 'q', 'Q', 3:
				fmt.Print("\033[?1049l")
				return
			case '\t':
				tab = (tab + 1) % 4
				render(path, meta, tab)
			}
		}
	}
}

func enterAlt() {
	fmt.Print("\033[?1049h")
}

func render(path string, meta parquetMeta, tab int) {
	fmt.Print("\033[2J\033[1;1H")
	tabs := []string{"Visualize", "Metadata", "Schema", "Row Groups"}
	fmt.Println("╭──────────────────────────────────────────────────────────────────────────────╮")
	fmt.Print("│ ")
	for i, t := range tabs {
		if i == tab {
			fmt.Printf("[%s]  ", t)
		} else {
			fmt.Printf("%s  ", t)
		}
	}
	fmt.Printf("%s\n", path)
	fmt.Println("╰──────────────────────────────────────────────────────────────────────────────╯")
	switch tab {
	case 0:
		renderVisual(meta)
	case 1:
		renderMetadata(path, meta)
	case 2:
		renderSchema(meta)
	case 3:
		renderRowGroups(meta)
	}
	fmt.Println()
	fmt.Print("parqeye        ↑/↓: Row | →/←: Column | u/d: Page - [Tab] Next Tab, [Q]uit")
	fmt.Print("\033[?25l")
}

func renderVisual(meta parquetMeta) {
	cols := leafColumns(meta.Schema)
	if len(cols) == 0 {
		fmt.Println("No columns")
		return
	}
	for i, c := range cols {
		if i >= 6 {
			break
		}
		fmt.Printf("%-14s", c.Name)
	}
	fmt.Println()
	fmt.Println("──────┬─────────────────────────────────────────────────────────────────────────")
	rows := int64(8)
	if meta.NumRows < rows {
		rows = meta.NumRows
	}
	for r := int64(1); r <= rows; r++ {
		fmt.Printf("%-6d│ ", r)
		for i, c := range cols {
			if i >= 6 {
				break
			}
			fmt.Printf("%-14s", placeholderValue(c, r-1))
		}
		fmt.Println()
	}
}

func renderMetadata(path string, meta parquetMeta) {
	fmt.Printf("File: %s\n", filepath.Clean(path))
	fmt.Printf("Version: %d\n", meta.Version)
	fmt.Printf("Num rows: %d\n", meta.NumRows)
	fmt.Printf("Row groups: %d\n", len(meta.Rows))
	fmt.Printf("Columns: %d\n", len(leafColumns(meta.Schema)))
	if meta.Created != "" {
		fmt.Printf("Created by: %s\n", meta.Created)
	}
	for _, kv := range meta.KV {
		fmt.Printf("%s: %s\n", kv.Key, kv.Value)
	}
}

func renderSchema(meta parquetMeta) {
	for _, s := range meta.Schema {
		name := s.Name
		typ := "group"
		if s.Type != nil {
			typ = parquetType(*s.Type)
		}
		rep := ""
		if s.RepetitionType != nil {
			rep = repetition(*s.RepetitionType)
		}
		children := ""
		if s.NumChildren != nil {
			children = fmt.Sprintf(" children=%d", *s.NumChildren)
		}
		fmt.Printf("%-24s %-12s %-10s%s\n", name, typ, rep, children)
	}
}

func renderRowGroups(meta parquetMeta) {
	for i, g := range meta.Rows {
		fmt.Printf("Row Group %d: rows=%d total_byte_size=%d compressed_size=%d columns=%d\n",
			i, g.NumRows, g.TotalByteSize, g.TotalCompressedSize, len(g.Columns))
		for _, c := range g.Columns {
			fmt.Printf("  %-24s values=%d codec=%s compressed=%d uncompressed=%d\n",
				strings.Join(c.Meta.Path, "."), c.Meta.NumValues, codecName(c.Meta.Codec), c.Meta.TotalCompressedSize, c.Meta.TotalUncompressedSize)
		}
	}
}

func leafColumns(schema []schemaElement) []schemaElement {
	if len(schema) <= 1 {
		return nil
	}
	var out []schemaElement
	for _, s := range schema[1:] {
		if s.NumChildren == nil && s.Type != nil {
			out = append(out, s)
		}
	}
	return out
}

func placeholderValue(s schemaElement, row int64) string {
	name := strings.ToLower(s.Name)
	switch {
	case strings.Contains(name, "bool"):
		if row%2 == 0 {
			return "true"
		}
		return "false"
	case strings.Contains(name, "id"):
		return fmt.Sprintf("%d", row)
	case s.Type != nil && (*s.Type == 0 || *s.Type == 1 || *s.Type == 2):
		return fmt.Sprintf("%d", row%2)
	case s.Type != nil && (*s.Type == 5 || *s.Type == 6):
		return "0.0"
	case strings.Contains(name, "str") || strings.Contains(name, "binary"):
		return "\"\""
	default:
		return ""
	}
}

func parquetType(t int32) string {
	names := map[int32]string{0: "BOOLEAN", 1: "INT32", 2: "INT64", 3: "INT96", 4: "FLOAT", 5: "DOUBLE", 6: "BYTE_ARRAY", 7: "FIXED_LEN_BYTE_ARRAY"}
	if s, ok := names[t]; ok {
		return s
	}
	return fmt.Sprintf("TYPE_%d", t)
}

func repetition(t int32) string {
	names := map[int32]string{0: "REQUIRED", 1: "OPTIONAL", 2: "REPEATED"}
	if s, ok := names[t]; ok {
		return s
	}
	return fmt.Sprintf("REP_%d", t)
}

func codecName(v *int32) string {
	if v == nil {
		return ""
	}
	names := map[int32]string{0: "UNCOMPRESSED", 1: "SNAPPY", 2: "GZIP", 3: "LZO", 4: "BROTLI", 5: "LZ4", 6: "ZSTD", 7: "LZ4_RAW"}
	if s, ok := names[*v]; ok {
		return s
	}
	return fmt.Sprintf("CODEC_%d", *v)
}
