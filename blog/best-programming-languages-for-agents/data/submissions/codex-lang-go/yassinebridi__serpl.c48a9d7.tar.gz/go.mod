module serpl

go 1.21
