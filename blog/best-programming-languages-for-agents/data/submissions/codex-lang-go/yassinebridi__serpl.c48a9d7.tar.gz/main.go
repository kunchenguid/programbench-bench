package main

import (
	"bufio"
	"fmt"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

const helpText = `A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version
`

func main() {
	projectRoot, action, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(2)
	}

	switch action {
	case "help":
		fmt.Print(helpText)
	case "version":
		printVersion()
	default:
		if err := runTUI(projectRoot); err != nil {
			fmt.Fprint(os.Stderr, "serpl error: Something went wrong\n")
			fmt.Fprint(os.Stderr, "Error: \n")
			fmt.Fprintf(os.Stderr, "   0: \x1b[91m%s\x1b[0m\n", err)
			os.Exit(1)
		}
	}
}

func parseArgs(args []string) (string, string, bool) {
	projectRoot := "."
	projectRootSeen := false
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch {
		case arg == "--":
			for _, rest := range args[i+1:] {
				if rest != "" {
					unexpected(rest)
					return "", "", false
				}
			}
			return projectRoot, "", true
		case arg == "-h" || arg == "--help":
			return projectRoot, "help", true
		case arg == "-V" || arg == "--version":
			return projectRoot, "version", true
		case strings.HasPrefix(arg, "--help="):
			unexpectedValue(strings.TrimPrefix(arg, "--help="), "--help")
			return "", "", false
		case strings.HasPrefix(arg, "--version="):
			unexpectedValue(strings.TrimPrefix(arg, "--version="), "--version")
			return "", "", false
		case arg == "-p" || arg == "--project-root":
			if i+1 >= len(args) || args[i+1] == "" {
				missingProjectRoot()
				return "", "", false
			}
			i++
			projectRoot = args[i]
			projectRootSeen = true
		case strings.HasPrefix(arg, "--project-root="):
			value := strings.TrimPrefix(arg, "--project-root=")
			if value == "" {
				missingProjectRoot()
				return "", "", false
			}
			projectRoot = value
			projectRootSeen = true
		case strings.HasPrefix(arg, "-p="):
			value := strings.TrimPrefix(arg, "-p=")
			if value == "" {
				missingProjectRoot()
				return "", "", false
			}
			projectRoot = value
			projectRootSeen = true
		case strings.HasPrefix(arg, "-") && !strings.HasPrefix(arg, "--") && strings.Contains(arg[1:], "h"):
			prefix := arg[:strings.Index(arg, "h")]
			if prefix == "-" {
				return projectRoot, "help", true
			}
			unexpected(prefix)
			return "", "", false
		case strings.HasPrefix(arg, "-") && !strings.HasPrefix(arg, "--") && strings.Contains(arg[1:], "V"):
			prefix := arg[:strings.Index(arg, "V")]
			if prefix == "-" {
				return projectRoot, "version", true
			}
			unexpected(prefix)
			return "", "", false
		case strings.HasPrefix(arg, "-p") && len(arg) > 2:
			projectRoot = arg[2:]
			projectRootSeen = true
		default:
			unexpectedWithUsage(arg, projectRootSeen && strings.HasPrefix(arg, "-"))
			return "", "", false
		}
	}
	return projectRoot, "", true
}

func unexpected(arg string) {
	unexpectedWithUsage(arg, false)
}

func unexpectedWithUsage(arg string, projectRootUsage bool) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n", arg)
	if projectRootUsage {
		fmt.Fprint(os.Stderr, "Usage: executable --project-root <PATH>\n\n")
	} else {
		fmt.Fprint(os.Stderr, "Usage: executable [OPTIONS]\n\n")
	}
	fmt.Fprint(os.Stderr, "For more information, try '--help'.\n")
}

func unexpectedValue(value, flag string) {
	fmt.Fprintf(os.Stderr, "error: unexpected value '%s' for '%s' found; no more were expected\n\n", value, flag)
	fmt.Fprintf(os.Stderr, "Usage: executable %s\n\n", flag)
	fmt.Fprint(os.Stderr, "For more information, try '--help'.\n")
}

func missingProjectRoot() {
	fmt.Fprint(os.Stderr, "error: a value is required for '--project-root <PATH>' but none was supplied\n\n")
	fmt.Fprint(os.Stderr, "For more information, try '--help'.\n")
}

func printVersion() {
	fmt.Print("serpl 0.3.4- (2026-04-20)\n\n")
	fmt.Print("Authors: Yassine Bridi <ybridi@gmail.com>\n\n")
	fmt.Printf("Config directory: %s\n", configDir())
}

func configDir() string {
	if xdg := os.Getenv("XDG_CONFIG_HOME"); xdg != "" {
		return filepath.Join(xdg, "serpl")
	}
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		home = os.Getenv("HOME")
	}
	if home == "" {
		home = "."
	}
	return filepath.Join(home, ".config", "serpl")
}

func runTUI(projectRoot string) error {
	if !isTerminal(os.Stdin.Fd()) || !isTerminal(os.Stdout.Fd()) {
		return syscall.Errno(6)
	}

	signals := make(chan os.Signal, 2)
	signal.Notify(signals, os.Interrupt, syscall.SIGTERM)
	defer signal.Stop(signals)

	fmt.Print("\x1b[?1049h\x1b[?25l")
	defer fmt.Print("\x1b[?25h\x1b[?1049l")
	draw(projectRoot)

	input := make(chan byte, 1)
	go func() {
		reader := bufio.NewReader(os.Stdin)
		for {
			b, err := reader.ReadByte()
			if err != nil {
				close(input)
				return
			}
			input <- b
		}
	}()

	for {
		select {
		case <-signals:
			return nil
		case b, ok := <-input:
			if !ok {
				return nil
			}
			switch b {
			case 3, 4, 'q', 'Q':
				return nil
			case 12, 18:
				draw(projectRoot)
			case '?':
				drawHelp(projectRoot)
			default:
				draw(projectRoot)
			}
		}
	}
}

func draw(projectRoot string) {
	fmt.Print("\x1b[2J\x1b[H")
	fmt.Print("serpl\n")
	fmt.Print("Search:  \n")
	fmt.Print("Replace: \n")
	fmt.Printf("Project: %s\n\n", projectRoot)
	fmt.Print("Results\n")
	fmt.Print("No search term entered.\n\n")
	fmt.Print("Ctrl-o replace  Ctrl-r refresh  Tab tabs  Ctrl-b help  Ctrl-c quit\n")
}

func drawHelp(projectRoot string) {
	fmt.Print("\x1b[2J\x1b[H")
	fmt.Print("serpl help\n\n")
	fmt.Print("<Ctrl-d> Quit\n")
	fmt.Print("<Ctrl-c> Quit\n")
	fmt.Print("<Ctrl-z> Suspend\n")
	fmt.Print("<Ctrl-r> Refresh\n")
	fmt.Print("<Tab> LoopOverTabs\n")
	fmt.Print("<Backtab> BackLoopOverTabs\n")
	fmt.Print("<Ctrl-o> ProcessReplace\n")
	fmt.Print("<Ctrl-b> ShowHelp\n\n")
	fmt.Printf("Project: %s\n", projectRoot)
}

func isTerminal(fd uintptr) bool {
	var termios syscall.Termios
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&termios)))
	return errno == 0
}
