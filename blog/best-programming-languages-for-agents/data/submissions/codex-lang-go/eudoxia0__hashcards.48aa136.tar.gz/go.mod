module hashcards

go 1.21
