package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type Location struct {
	FilePath  string `json:"filePath"`
	LineStart int    `json:"lineStart"`
	LineEnd   int    `json:"lineEnd"`
}

type Basic struct {
	Question string `json:"question"`
	Answer   string `json:"answer"`
}

type Cloze struct {
	Text  string `json:"text"`
	Start int    `json:"start"`
	End   int    `json:"end"`
}

type Content struct {
	Basic *Basic `json:"basic,omitempty"`
	Cloze *Cloze `json:"cloze,omitempty"`
}

type Card struct {
	Hash        string      `json:"hash"`
	FamilyHash  *string     `json:"familyHash"`
	DeckName    string      `json:"deckName"`
	Location    Location    `json:"location"`
	Content     Content     `json:"content"`
	Performance interface{} `json:"performance"`
}

type Export struct {
	Cards    []Card        `json:"cards"`
	Sessions []interface{} `json:"sessions"`
}

type Stats struct {
	CardsInDeckCount        int `json:"cardsInDeckCount"`
	CardsInDbCount          int `json:"cardsInDbCount"`
	TexMacroCount           int `json:"texMacroCount"`
	CardsReviewedTodayCount int `json:"cardsReviewedTodayCount"`
}

func main() {
	if len(os.Args) < 2 {
		printRootHelp()
		os.Exit(2)
	}
	switch os.Args[1] {
	case "-h", "--help", "help":
		if len(os.Args) == 2 || os.Args[1] != "help" {
			printRootHelp()
			return
		}
		help(os.Args[2:])
	case "-V", "--version":
		fmt.Println("hashcards 0.3.0")
	case "stats":
		runStats(os.Args[2:])
	case "check":
		runCheck(os.Args[2:])
	case "export":
		runExport(os.Args[2:])
	case "orphans":
		runOrphans(os.Args[2:])
	case "drill":
		runDrill(os.Args[2:])
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", os.Args[1])
		fmt.Fprintln(os.Stderr, "Usage: executable <COMMAND>")
		os.Exit(2)
	}
}

func printRootHelp() {
	fmt.Println(`A plain text-based spaced repetition system.

Usage: executable <COMMAND>

Commands:
  drill    Drill cards through a web interface
  check    Check the integrity of a collection
  stats    Print collection statistics
  orphans  Commands relating to orphan cards
  export   Export a collection
  help     Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`)
}

func help(args []string) {
	if len(args) == 0 {
		printRootHelp()
		return
	}
	switch args[0] {
	case "stats":
		fmt.Println(`Print collection statistics

Usage: executable stats [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --format <FORMAT>
          Which output format to use

          Possible values:
          - html: HTML output
          - json: JSON output
          
          [default: html]

  -h, --help
          Print help (see a summary with '-h')`)
	case "check":
		fmt.Println(`Check the integrity of a collection

Usage: executable check [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help`)
	case "export":
		fmt.Println(`Export a collection

Usage: executable export [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout
  -h, --help             Print help`)
	case "orphans":
		if len(args) > 1 && args[1] == "list" {
			printOrphansListHelp()
			return
		}
		if len(args) > 1 && args[1] == "delete" {
			printOrphansDeleteHelp()
			return
		}
		fmt.Println(`Commands relating to orphan cards

Usage: executable orphans <COMMAND>

Commands:
  list    List the hashes of all orphan cards in the collection
  delete  Remove all orphan cards from the database
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help`)
	case "drill":
		fmt.Println(`Drill cards through a web interface

Usage: executable drill [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --card-limit <CARD_LIMIT>
          Maximum number of cards to drill in a session. By default, all cards due today are drilled

      --new-card-limit <NEW_CARD_LIMIT>
          Maximum number of new cards to drill in a session

      --host <HOST>
          The host address to bind to. Default is 127.0.0.1
          
          [default: 127.0.0.1]

      --port <PORT>
          The port to use for the web server. Default is 8000
          
          [default: 8000]

      --from-deck <FROM_DECK>
          Only drill cards from this deck

      --open-browser <OPEN_BROWSER>
          Whether to open the browser automatically. Default is true
          
          [possible values: true, false]

      --answer-controls <ANSWER_CONTROLS>
          Which answer controls to show:

          Possible values:
          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)
          - binary: Show only two rating buttons (Forgot/Good)
          
          [default: full]

      --bury-siblings <BURY_SIBLINGS>
          Whether or not to bury siblings. Default is true
          
          [possible values: true, false]

  -h, --help
          Print help (see a summary with '-h')`)
	default:
		printRootHelp()
	}
}

func runStats(args []string) {
	fs := flag.NewFlagSet("stats", flag.ExitOnError)
	fs.SetOutput(os.Stderr)
	format := fs.String("format", "html", "")
	fs.Bool("help", false, "")
	fs.Bool("h", false, "")
	if err := fs.Parse(args); err != nil {
		os.Exit(2)
	}
	if contains(args, "--help") || contains(args, "-h") {
		help([]string{"stats"})
		return
	}
	if *format != "html" && *format != "json" {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--format <FORMAT>'\n  [possible values: html, json]\n\nFor more information, try '--help'.\n", *format)
		os.Exit(2)
	}
	if *format == "html" {
		fmt.Println("HTML output is not implemented yet.")
		return
	}
	dir := collectionArg(fs.Args())
	cards, err := loadCards(dir)
	if err != nil {
		fail(err)
	}
	out := Stats{CardsInDeckCount: len(cards), CardsInDbCount: 0, TexMacroCount: countTex(dir), CardsReviewedTodayCount: 0}
	printJSON(out)
}

func runCheck(args []string) {
	if contains(args, "--help") || contains(args, "-h") {
		help([]string{"check"})
		return
	}
	dir := collectionArg(args)
	cards, err := loadCards(dir)
	if err != nil {
		fail(err)
	}
	seen := map[string]bool{}
	for _, c := range cards {
		if seen[c.Hash] {
			fmt.Fprintf(os.Stderr, "hashcards: error: duplicate card hash: %s\n", c.Hash)
			os.Exit(1)
		}
		seen[c.Hash] = true
	}
	fmt.Println("ok")
}

func runExport(args []string) {
	fs := flag.NewFlagSet("export", flag.ExitOnError)
	fs.SetOutput(os.Stderr)
	output := fs.String("output", "", "")
	fs.Bool("help", false, "")
	fs.Bool("h", false, "")
	if err := fs.Parse(args); err != nil {
		os.Exit(2)
	}
	if contains(args, "--help") || contains(args, "-h") {
		help([]string{"export"})
		return
	}
	dir := collectionArg(fs.Args())
	cards, err := loadCards(dir)
	if err != nil {
		fail(err)
	}
	data, _ := json.MarshalIndent(Export{Cards: cards, Sessions: []interface{}{}}, "", "  ")
	data = append(data, '\n')
	if *output != "" {
		if err := os.WriteFile(*output, data, 0644); err != nil {
			fail(err)
		}
		return
	}
	os.Stdout.Write(data)
}

func runOrphans(args []string) {
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		help([]string{"orphans"})
		return
	}
	if args[0] == "help" {
		if len(args) > 1 && args[1] == "list" {
			printOrphansListHelp()
			return
		}
		if len(args) > 1 && args[1] == "delete" {
			printOrphansDeleteHelp()
			return
		}
	}
	if len(args) > 1 && (args[1] == "-h" || args[1] == "--help") {
		if args[0] == "list" {
			printOrphansListHelp()
			return
		}
		if args[0] == "delete" {
			printOrphansDeleteHelp()
			return
		}
	}
	if args[0] != "list" && args[0] != "delete" {
		help([]string{"orphans"})
		os.Exit(2)
	}
	dir := collectionArg(args[1:])
	if _, err := os.Stat(dir); err != nil {
		fail(errors.New("directory does not exist."))
	}
}

func printOrphansListHelp() {
	fmt.Println(`List the hashes of all orphan cards in the collection

Usage: executable orphans list [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help`)
}

func printOrphansDeleteHelp() {
	fmt.Println(`Remove all orphan cards from the database

Usage: executable orphans delete [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help`)
}

func runDrill(args []string) {
	if contains(args, "--help") || contains(args, "-h") {
		help([]string{"drill"})
		return
	}
	host, port := "127.0.0.1", "8000"
	for i := 0; i < len(args); i++ {
		if args[i] == "--host" && i+1 < len(args) {
			host = args[i+1]
			i++
		} else if args[i] == "--port" && i+1 < len(args) {
			port = args[i+1]
			i++
		}
	}
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "<!doctype html><title>Hashcards</title><h1>Hashcards</h1>")
	})
	addr := host + ":" + port
	fmt.Printf("Listening on http://%s\n", addr)
	if err := http.ListenAndServe(addr, nil); err != nil {
		fail(err)
	}
}

func loadCards(dir string) ([]Card, error) {
	st, err := os.Stat(dir)
	if err != nil || !st.IsDir() {
		return nil, errors.New("directory does not exist.")
	}
	var files []string
	filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
		if err == nil && !d.IsDir() && strings.EqualFold(filepath.Ext(path), ".md") {
			files = append(files, path)
		}
		return nil
	})
	sort.Strings(files)
	var cards []Card
	for _, f := range files {
		cs, err := parseFile(f)
		if err != nil {
			return nil, err
		}
		cards = append(cards, cs...)
	}
	sort.Slice(cards, func(i, j int) bool { return cards[i].Hash < cards[j].Hash })
	return cards, nil
}

func parseFile(path string) ([]Card, error) {
	absPath, err := filepath.Abs(path)
	if err == nil {
		path = absPath
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	text := strings.ReplaceAll(string(b), "\r\n", "\n")
	lines := strings.Split(text, "\n")
	if len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	deck := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	var starts []int
	for i, line := range lines {
		t := strings.TrimSpace(line)
		if strings.HasPrefix(t, "Q:") || strings.HasPrefix(t, "C:") {
			starts = append(starts, i)
		}
	}
	var out []Card
	for si, start := range starts {
		next := len(lines)
		if si+1 < len(starts) {
			next = starts[si+1]
		}
		t := strings.TrimSpace(lines[start])
		if strings.HasPrefix(t, "Q:") {
			if c, ok := parseBasic(path, deck, lines, start, next); ok {
				out = append(out, c)
			}
		} else {
			out = append(out, parseClozes(path, deck, lines, start, next)...)
		}
	}
	return out, nil
}

func parseBasic(path, deck string, lines []string, start, next int) (Card, bool) {
	aLine := -1
	for i := start; i < next; i++ {
		if strings.HasPrefix(strings.TrimSpace(lines[i]), "A:") {
			aLine = i
			break
		}
	}
	if aLine < 0 {
		return Card{}, false
	}
	qFirst := strings.TrimSpace(lines[start])[2:]
	qParts := append([]string{qFirst}, lines[start+1:aLine]...)
	aFirst := strings.TrimSpace(lines[aLine])[2:]
	aParts := append([]string{aFirst}, lines[aLine+1:next]...)
	q := cleanField(qParts)
	a := cleanField(aParts)
	lineEnd := next - 1
	if next < len(lines) {
		lineEnd = next
	}
	c := Card{
		FamilyHash: nil,
		DeckName:   deck,
		Location:   Location{FilePath: path, LineStart: start, LineEnd: lineEnd},
		Content:    Content{Basic: &Basic{Question: q, Answer: a}},
	}
	c.Hash = hash("basic\x00" + deck + "\x00" + q + "\x00" + a)
	return c, true
}

func parseClozes(path, deck string, lines []string, start, next int) []Card {
	first := strings.TrimSpace(lines[start])[2:]
	parts := append([]string{first}, lines[start+1:next]...)
	raw := cleanField(parts)
	var text strings.Builder
	type span struct{ s, e int }
	var spans []span
	for i := 0; i < len(raw); i++ {
		if raw[i] == '[' {
			if j := strings.IndexByte(raw[i+1:], ']'); j >= 0 {
				inside := raw[i+1 : i+1+j]
				pos := text.Len()
				text.WriteString(inside)
				end := pos + len([]byte(inside)) - 1
				if end < pos {
					end = pos
				}
				spans = append(spans, span{pos, end})
				i = i + j + 1
				continue
			}
		}
		text.WriteByte(raw[i])
	}
	final := text.String()
	fh := hash("family\x00" + deck + "\x00" + final)
	var out []Card
	for _, sp := range spans {
		family := fh
		cl := &Cloze{Text: final, Start: sp.s, End: sp.e}
		c := Card{
			FamilyHash: &family,
			DeckName:   deck,
			Location:   Location{FilePath: path, LineStart: start, LineEnd: next - 1},
			Content:    Content{Cloze: cl},
		}
		c.Hash = hash("cloze\x00" + deck + "\x00" + final + fmt.Sprintf("\x00%d\x00%d", sp.s, sp.e))
		out = append(out, c)
	}
	return out
}

func cleanField(parts []string) string {
	s := strings.Join(parts, "\n")
	s = strings.TrimSpace(s)
	lines := strings.Split(s, "\n")
	for i := range lines {
		lines[i] = strings.TrimRight(lines[i], " \t")
	}
	for len(lines) > 0 && strings.TrimSpace(lines[0]) == "" {
		lines = lines[1:]
	}
	for len(lines) > 0 && strings.TrimSpace(lines[len(lines)-1]) == "" {
		lines = lines[:len(lines)-1]
	}
	return strings.Join(lines, "\n")
}

func countTex(dir string) int {
	total := 0
	filepath.WalkDir(dir, func(path string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() || strings.ToLower(filepath.Ext(path)) != ".tex" {
			return nil
		}
		b, err := os.ReadFile(path)
		if err == nil {
			for _, line := range strings.Split(string(b), "\n") {
				if strings.TrimSpace(line) != "" {
					total++
				}
			}
		}
		return nil
	})
	return total
}

func hash(s string) string {
	sum := sha256.Sum256([]byte(s))
	return hex.EncodeToString(sum[:])
}

func collectionArg(args []string) string {
	if len(args) > 0 {
		return args[len(args)-1]
	}
	wd, _ := os.Getwd()
	return wd
}

func printJSON(v interface{}) {
	b, _ := json.MarshalIndent(v, "", "  ")
	fmt.Println(string(b))
}

func fail(err error) {
	fmt.Fprintf(os.Stderr, "hashcards: error: %v\n", err)
	os.Exit(1)
}

func contains(args []string, s string) bool {
	for _, a := range args {
		if a == s {
			return true
		}
	}
	return false
}
