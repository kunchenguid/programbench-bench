module cmatrix

go 1.21
