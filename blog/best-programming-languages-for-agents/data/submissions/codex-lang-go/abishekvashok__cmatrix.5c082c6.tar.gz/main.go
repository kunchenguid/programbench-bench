package main

import (
	"fmt"
	"math/rand"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const usageText = ` Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: "Screensaver" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
`

var colorCodes = map[string]int{
	"black":   30,
	"red":     31,
	"green":   32,
	"yellow":  33,
	"blue":    34,
	"magenta": 35,
	"cyan":    36,
	"white":   37,
}

type options struct {
	color   string
	delay   int
	message string
	lambda  bool
	rainbow bool
}

func main() {
	opts, shouldRun := parseArgs(os.Args[1:])
	if !shouldRun {
		return
	}

	term := os.Getenv("TERM")
	if term == "" || term == "unknown" {
		fmt.Fprintln(os.Stderr, "Error opening terminal: unknown.")
		os.Exit(1)
	}

	runMatrix(opts)
}

func parseArgs(args []string) (options, bool) {
	opts := options{color: "green", delay: 4}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "" || arg[0] != '-' {
			continue
		}
		if arg == "--" {
			continue
		}
		if strings.HasPrefix(arg, "--") {
			printUsage()
			return opts, false
		}
		for j := 1; j < len(arg); j++ {
			switch arg[j] {
			case 'h', '?':
				printUsage()
				return opts, false
			case 'V':
				fmt.Println(" CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)")
				fmt.Println("Email: abishekvashok@gmail.com")
				fmt.Println("Web: https://github.com/abishekvashok/cmatrix")
				return opts, false
			case 'C':
				val, ok := optionValue(arg, j, args, &i)
				if !ok {
					printUsage()
					return opts, false
				}
				if _, exists := colorCodes[val]; !exists {
					fmt.Println(" Invalid color selection")
					fmt.Println(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.")
					return opts, false
				}
				opts.color = val
				j = len(arg)
			case 'u':
				val, ok := optionValue(arg, j, args, &i)
				if !ok {
					printUsage()
					return opts, false
				}
				if n, err := strconv.Atoi(val); err == nil {
					opts.delay = n
				}
				j = len(arg)
			case 'M':
				val, ok := optionValue(arg, j, args, &i)
				if !ok {
					printUsage()
					return opts, false
				}
				opts.message = val
				j = len(arg)
			case 't':
				_, ok := optionValue(arg, j, args, &i)
				if !ok {
					printUsage()
					return opts, false
				}
				j = len(arg)
			case 'm':
				opts.lambda = true
			case 'r':
				opts.rainbow = true
			case 'a', 'b', 'B', 'c', 'f', 'l', 'L', 'o', 'n', 's', 'x', 'k':
			default:
				printUsage()
				return opts, false
			}
		}
	}
	return opts, true
}

func optionValue(arg string, pos int, args []string, index *int) (string, bool) {
	if pos+1 < len(arg) {
		return arg[pos+1:], true
	}
	if *index+1 >= len(args) {
		return "", false
	}
	(*index)++
	return args[*index], true
}

func printUsage() {
	fmt.Print(usageText)
}

func runMatrix(opts options) {
	rand.Seed(time.Now().UnixNano())
	width, height := terminalSize()
	if width < 1 {
		width = 80
	}
	if height < 1 {
		height = 24
	}

	cleanup := func() {
		fmt.Print("\x1b[39m\x1b(B\x1b[m\x1b[?12l\x1b[?25h\x1b[?1049l\x1b[23;0;0t\r\x1b[?1l\x1b>")
	}
	sig := make(chan os.Signal, 2)
	signal.Notify(sig, os.Interrupt, syscall.SIGTERM)
	go func() {
		<-sig
		cleanup()
		os.Exit(0)
	}()

	fmt.Printf("\x1b[?1049h\x1b[22;0;0t\x1b[1;%dr\x1b(B\x1b[m\x1b[4l\x1b[?7h\x1b[?25l", height)
	fmt.Print("\x1b[39;49m\x1b[39;49m\x1b(B\x1b[m\x1b[H\x1b[2J")

	code := colorCodes[opts.color]
	clearWithColor(width, height, code)
	if opts.message != "" {
		row := height / 2
		col := (width - len(opts.message)) / 2
		if col < 1 {
			col = 1
		}
		fmt.Printf("\x1b[%d;%dH\x1b[37m%s", row, col, opts.message)
	}

	chars := []rune("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@#$%^&*+-=<>")
	if opts.lambda {
		chars = []rune{'&'}
	}
	delays := []time.Duration{
		10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110,
	}
	d := 50 * time.Millisecond
	if opts.delay >= 0 && opts.delay < len(delays) {
		d = delays[opts.delay] * time.Millisecond
	}
	t := time.NewTicker(d)
	defer t.Stop()
	for tick := 0; ; tick++ {
		<-t.C
		for n := 0; n < width/12+1; n++ {
			x := rand.Intn(width) + 1
			y := rand.Intn(height) + 1
			c := code
			if opts.rainbow {
				c = 31 + rand.Intn(7)
			}
			r := chars[rand.Intn(len(chars))]
			fmt.Printf("\x1b[%d;%dH\x1b[37m%c\x1b[%dm", y, x, r, c)
			if y > 1 {
				fmt.Printf("\x1b[%d;%dH%c", y-1, x, r)
			}
			if y > 3 {
				fmt.Printf("\x1b[%d;%dH ", y-3, x)
			}
		}
		if opts.message != "" && tick%8 == 0 {
			row := height / 2
			col := (width - len(opts.message)) / 2
			if col < 1 {
				col = 1
			}
			fmt.Printf("\x1b[%d;%dH\x1b[37m%s\x1b[%dm", row, col, opts.message, code)
		}
	}
}

func clearWithColor(width, height, code int) {
	for y := 1; y <= height; y++ {
		if y == 1 {
			fmt.Print("\x1b[H")
		} else {
			fmt.Printf("\r\x1b[%dd", y)
		}
		for x := 0; x < width/2; x++ {
			fmt.Printf("\x1b[%dm \x1b[39m\x1b(B\x1b[m ", code)
		}
	}
}

func terminalSize() (int, int) {
	width := envInt("COLUMNS", 80)
	height := envInt("LINES", 24)
	return width, height
}

func envInt(name string, fallback int) int {
	val := os.Getenv(name)
	if val == "" {
		return fallback
	}
	n, err := strconv.Atoi(val)
	if err != nil || n <= 0 {
		return fallback
	}
	return n
}
