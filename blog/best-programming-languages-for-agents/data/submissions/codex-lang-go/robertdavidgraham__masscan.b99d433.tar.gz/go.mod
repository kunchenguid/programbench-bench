module masscan-reimplementation

go 1.21
