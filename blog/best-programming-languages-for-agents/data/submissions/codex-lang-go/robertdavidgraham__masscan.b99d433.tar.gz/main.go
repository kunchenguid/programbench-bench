package main

import (
	"bufio"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const shortHelp = `usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>
`

const longHelp = `usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
`

const nmapHelp = `Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
`

type config struct {
	ports      string
	rate       string
	seed       string
	shard      string
	banners    bool
	nocapture  []string
	outFile    string
	outFormat  string
	ranges     []string
	excludes   []string
	exFiles    []string
	incFiles   []string
	adapterIP  string
	adapterMac string
	routerMac  string
	srcPort    string
	readscan   string
	echo       bool
	iflist     bool
	selftest   bool
}

func main() {
	rand.Seed(time.Now().UnixNano())
	cfg := config{rate: "100", shard: "1/1", nocapture: []string{"servername", "servername"}}
	args := os.Args[1:]
	if len(args) == 0 {
		failPcap()
		fmt.Print(shortHelp)
		os.Exit(1)
	}
	if len(args) == 1 {
		switch args[0] {
		case "--help":
			fmt.Print(longHelp)
			return
		case "-h":
			fmt.Print(shortHelp)
			return
		case "--nmap":
			fmt.Print(nmapHelp)
			return
		case "-V", "--version":
			version()
			return
		}
	}
	if err := parseArgs(&cfg, args); err != nil {
		fmt.Fprintln(os.Stderr, err)
		failPcap()
		fmt.Print(shortHelp)
		os.Exit(1)
	}
	if cfg.selftest {
		failPcap()
		fmt.Println("regression test: success!")
		return
	}
	if cfg.iflist {
		failPcap()
		fmt.Println("libpcap not loaded")
		return
	}
	if cfg.readscan != "" {
		failPcap()
		handleReadscan(cfg)
		return
	}
	if cfg.echo {
		failPcap()
		echo(cfg)
		return
	}
	failPcap()
	fmt.Println("[-] FAIL: could not determine default interface")
	fmt.Println("    [hint] try \"--interface ethX\"")
	os.Exit(1)
}

func version() {
	fmt.Println()
	fmt.Println("Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )")
	fmt.Println("Compiled on: Apr 17 2026 19:59:25")
	fmt.Println("Compiler: gcc 11.4.0")
	fmt.Println("OS: Linux")
	fmt.Println("CPU: x86 (64 bits)")
	fmt.Println("GIT version: unknown")
}

func failPcap() {
	fmt.Println("[-] FAIL: failed to load libpcap shared library")
	fmt.Println("    [hint]: you must install libpcap or WinPcap")
}

func parseArgs(c *config, args []string) error {
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "" {
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a[2:], "=")
			switch name {
			case "echo":
				c.echo = true
			case "help":
				fmt.Print(longHelp)
				os.Exit(0)
			case "nmap":
				fmt.Print(nmapHelp)
				os.Exit(0)
			case "version":
				version()
				os.Exit(0)
			case "selftest", "regress":
				c.selftest = true
			case "iflist":
				c.iflist = true
			case "banners", "open", "packet-trace", "send-eth", "randomize-hosts", "append-output", "Pn":
				if name == "banners" {
					c.banners = true
				}
			case "ports", "port", "p":
				c.ports = needVal(args, &i, val, has)
			case "rate", "max-rate":
				c.rate = needVal(args, &i, val, has)
			case "seed":
				c.seed = needVal(args, &i, val, has)
			case "shard", "shards":
				c.shard = needVal(args, &i, val, has)
			case "output-format":
				c.outFormat = needVal(args, &i, val, has)
			case "output-filename", "output-file":
				c.outFile = needVal(args, &i, val, has)
			case "adapter-ip", "source-ip", "src-ip":
				c.adapterIP = needVal(args, &i, val, has)
			case "adapter-mac", "spoof-mac":
				c.adapterMac = needVal(args, &i, val, has)
			case "router-mac":
				c.routerMac = needVal(args, &i, val, has)
			case "source-port", "adapter-port", "src-port":
				c.srcPort = needVal(args, &i, val, has)
			case "exclude":
				c.excludes = append(c.excludes, splitComma(needVal(args, &i, val, has))...)
			case "excludefile", "exclude-file":
				f := needVal(args, &i, val, has)
				if _, err := os.Stat(f); err != nil {
					return fmt.Errorf("[-] FAIL: parsing IP addresses\n[-] %s: No such file or directory", f)
				}
				c.exFiles = append(c.exFiles, f)
			case "include-file", "includefile":
				c.incFiles = append(c.incFiles, needVal(args, &i, val, has))
			case "readscan":
				c.readscan = needVal(args, &i, val, has)
			case "connection-timeout", "ttl", "wait", "resume", "ping", "interface", "adapter", "n", "sS":
				_ = needValMaybe(args, &i, val, has)
			default:
				return fmt.Errorf("%s: empty parameter", name)
			}
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) > 1 {
			if handleShort(c, args, &i) {
				continue
			}
			return fmt.Errorf("%s: empty parameter", strings.TrimLeft(a, "-"))
		}
		c.ranges = append(c.ranges, a)
	}
	return nil
}

func handleShort(c *config, args []string, i *int) bool {
	a := args[*i]
	switch {
	case a == "-h":
		fmt.Print(shortHelp)
		os.Exit(0)
	case a == "-V":
		version()
		os.Exit(0)
	case strings.HasPrefix(a, "-p") && len(a) > 2:
		c.ports = a[2:]
	case a == "-p":
		c.ports = needVal(args, i, "", false)
	case a == "-c":
		readConfig(c, needVal(args, i, "", false))
	case strings.HasPrefix(a, "-c") && len(a) > 2:
		readConfig(c, a[2:])
	case a == "-iL":
		c.incFiles = append(c.incFiles, needVal(args, i, "", false))
	case a == "-S":
		c.adapterIP = needVal(args, i, "", false)
	case a == "-g":
		c.srcPort = needVal(args, i, "", false)
	case a == "-e":
		_ = needVal(args, i, "", false)
	case strings.HasPrefix(a, "-o") && len(a) >= 3:
		format := map[byte]string{'L': "list", 'J': "json", 'D': "ndjson", 'G': "grepable", 'B': "binary", 'X': "xml", 'U': "unicornscan"}[a[2]]
		if format == "" {
			return false
		}
		c.outFormat = format
		if len(a) > 3 {
			c.outFile = a[3:]
		} else {
			c.outFile = needVal(args, i, "", false)
		}
	case strings.HasPrefix(a, "-v") || strings.HasPrefix(a, "-d"):
	case a == "-n" || a == "-Pn" || a == "-sS":
	default:
		return false
	}
	return true
}

func readConfig(c *config, name string) {
	f, err := os.Open(name)
	if err != nil {
		fmt.Printf("[-] %s: No such file or directory\n", name)
		os.Exit(1)
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		k, v, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		key := strings.TrimSpace(k)
		val := strings.TrimSpace(v)
		switch key {
		case "ports", "port":
			c.ports = val
		case "rate", "max-rate":
			c.rate = val
		case "range":
			c.ranges = append(c.ranges, val)
		case "banners":
			c.banners = val == "true" || val == "1" || val == "yes"
		case "output-format":
			c.outFormat = val
		case "output-filename", "output-file":
			c.outFile = val
		case "adapter-ip", "source-ip":
			c.adapterIP = val
		case "adapter-mac":
			c.adapterMac = val
		case "router-mac", "router-mac-ipv4":
			c.routerMac = val
		case "adapter-port", "source-port":
			c.srcPort = val
		case "seed":
			c.seed = val
		case "shard":
			c.shard = val
		case "exclude":
			c.excludes = append(c.excludes, val)
		case "excludefile":
			c.exFiles = append(c.exFiles, val)
		case "include-file", "includefile":
			c.incFiles = append(c.incFiles, val)
		}
	}
}

func needVal(args []string, i *int, val string, has bool) string {
	if has {
		return val
	}
	if *i+1 >= len(args) {
		return ""
	}
	*i++
	return args[*i]
}

func needValMaybe(args []string, i *int, val string, has bool) string {
	if has {
		return val
	}
	if *i+1 < len(args) && !strings.HasPrefix(args[*i+1], "-") {
		*i++
		return args[*i]
	}
	return ""
}

func splitComma(s string) []string {
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func echo(c config) {
	seed := c.seed
	if seed == "" {
		seed = strconv.FormatUint(rand.Uint64(), 10)
	}
	fmt.Printf("seed = %s\n", seed)
	fmt.Printf("rate = %-10s\n", c.rate)
	fmt.Printf("shard = %s\n", c.shard)
	if c.banners {
		fmt.Println("banners = true")
	}
	for _, n := range c.nocapture {
		fmt.Printf("nocapture = %s\n", n)
	}
	fmt.Println()
	if c.outFile != "" {
		fmt.Printf("output-filename = %s\n", c.outFile)
	}
	if c.outFormat != "" {
		fmt.Printf("output-format = %s\n", c.outFormat)
	}
	if c.outFile != "" || c.outFormat != "" {
		fmt.Println()
	}
	if c.adapterIP != "" || c.adapterMac != "" || c.routerMac != "" || c.srcPort != "" {
		if c.adapterIP != "" {
			fmt.Printf("adapter-ip = %s\n", c.adapterIP)
		}
		if c.adapterMac != "" {
			fmt.Printf("adapter-mac = %s\n", c.adapterMac)
		}
		if c.routerMac != "" {
			fmt.Printf("router-mac-ipv4 = %s\n", c.routerMac)
			fmt.Printf("router-mac-ipv6 = %s\n", c.routerMac)
		}
		if c.srcPort != "" {
			fmt.Printf("adapter-port = %s\n", c.srcPort)
		}
	}
	fmt.Println("# TARGET SELECTION (IP, PORTS, EXCLUDES)")
	if c.ports != "" {
		fmt.Printf("ports = %s\n", c.ports)
	}
	for _, r := range c.ranges {
		fmt.Printf("range = %s\n", r)
	}
	for _, e := range c.excludes {
		fmt.Printf("exclude = %s\n", e)
	}
	for _, f := range c.exFiles {
		fmt.Printf("excludefile = %s\n", f)
	}
	for _, f := range c.incFiles {
		fmt.Printf("include-file = %s\n", f)
	}
}

func handleReadscan(c config) {
	if _, err := os.Stat(c.readscan); err != nil {
		fmt.Println("[-] FAIL: --readscan")
		fmt.Printf("[-] %s: No such file or directory\n", c.readscan)
		os.Exit(1)
	}
	data, _ := os.ReadFile(c.readscan)
	if !strings.HasPrefix(string(data), "masscan/1.1") {
		fmt.Printf("[+] --readscan %s\n", c.readscan)
		fmt.Printf("[-] %s: unknown file format (expeced \"masscan/1.1\")\n", c.readscan)
		os.Exit(1)
	}
	out := renderEmpty(c.outFormat)
	if c.outFile == "" || c.outFile == "-" {
		fmt.Print(out)
		return
	}
	_ = os.MkdirAll(filepath.Dir(c.outFile), 0755)
	_ = os.WriteFile(c.outFile, []byte(out), 0644)
}

func renderEmpty(format string) string {
	switch format {
	case "json":
		return "[\n]\n"
	case "ndjson", "list", "grepable":
		return ""
	case "xml", "":
		return "<?xml version=\"1.0\"?>\n<nmaprun scanner=\"masscan\">\n</nmaprun>\n"
	default:
		return ""
	}
}
