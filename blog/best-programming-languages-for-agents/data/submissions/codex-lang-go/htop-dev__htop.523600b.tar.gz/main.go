package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"os/user"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"
)

const version = "htop 3.5.0-dev-878e0ce"

const helpText = `htop 3.5.0-dev-878e0ce
(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.
Released under the GNU GPLv2+.

-C --no-color                   Use a monochrome color scheme
-d --delay=DELAY                Set the delay between updates, in tenths of seconds
-F --filter=FILTER              Show only the commands matching the given filter
   --no-function-bar             Hide the function bar
-h --help                       Print this help screen
-H --highlight-changes[=DELAY]  Highlight new and old processes
-M --no-mouse                   Disable the mouse
   --no-meters                  Hide meters
-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates
-p --pid=PID[,PID,PID...]       Show only the given PIDs
   --readonly                   Disable all system and process changing features
-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)
-t --tree                       Show the tree view (can be combined with -s)
-u --user[=USERNAME]            Show only processes for a given user (or $USER)
-U --no-unicode                 Do not use unicode but plain ASCII
-V --version                    Print version info

Press F1 inside htop for online help.
See 'man htop' for more information.
`

const sortHelp = `                PID Process/thread ID
            Command Command line (insert as last column only)
              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)
               PPID Parent process ID
               PGRP Process group ID
            SESSION Process's session ID
                TTY Controlling terminal
              TPGID Process ID of the fg process group of the controlling terminal
             MINFLT Number of minor faults which have not required loading a memory page from disk
            CMINFLT Children processes' minor faults
             MAJFLT Number of major faults which have required loading a memory page from disk
            CMAJFLT Children processes' major faults
              UTIME User CPU time - time the process spent executing in user mode
              STIME System CPU time - time the kernel spent running system calls for this process
             CUTIME Children processes' user CPU time
             CSTIME Children processes' system CPU time
           PRIORITY Kernel's internal priority for the process
               NICE Nice value (the higher the value, the more it lets other processes take priority)
          STARTTIME Time the process was started
          PROCESSOR Id of the CPU the process last executed on
             M_VIRT Total program size in virtual memory
         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage
            M_SHARE Size of the process's shared pages
              M_TRS Size of the .text segment of the process (CODE)
              M_DRS Size of the .data segment plus stack usage of the process (DATA)
              M_LRS The library size of the process (calculated from memory maps)
             ST_UID User ID of the process owner
        PERCENT_CPU Percentage of the CPU time the process used in the last sampling
        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size
               USER Username of the process owner (or user ID if name cannot be determined)
               TIME Total time the process has spent in user and system time
               NLWP Number of threads in the process
               TGID Thread group ID (i.e. process ID)
   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)
            ELAPSED Time since the process was started
    SCHEDULERPOLICY Current scheduling policy of the process
              RCHAR Number of bytes the process has read
              WCHAR Number of bytes the process has written
              SYSCR Number of read(2) syscalls for the process
              SYSCW Number of write(2) syscalls for the process
             RBYTES Bytes of read(2) I/O for the process
             WBYTES Bytes of write(2) I/O for the process
             CNCLWB Bytes of cancelled write(2) I/O
       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process
      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process
            IO_RATE Total I/O rate in bytes per second
             CGROUP Which cgroup the process is in
                OOM OOM (Out-of-Memory) killer score
        IO_PRIORITY I/O priority
              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it
             M_SWAP Size of the process's swapped pages
            M_PSSWP shows proportional swap share of this mapping, unlike "Swap", this does not take into account swapped out page of underlying shmem objects
               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)
            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)
               COMM comm string of the process from /proc/[pid]/comm
                EXE Basename of exe of the process from /proc/[pid]/exe
                CWD The current working directory of the process
       AUTOGROUP_ID The autogroup identifier of the process
     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup
            CCGROUP Which cgroup the process is in (condensed to essentials)
          CONTAINER Name of the container the process is in (guessed by heuristics)
             M_PRIV The private memory size of the process - resident set size minus shared memory
           GPU_TIME Total GPU time
        GPU_PERCENT Percentage of the GPU time the process used in the last sampling
        ISCONTAINER Whether the process is running inside a child container
`

var validColumns = map[string]bool{}

func init() {
	for _, k := range []string{"PID", "Command", "STATE", "PPID", "PGRP", "SESSION", "TTY", "TPGID", "MINFLT", "CMINFLT", "MAJFLT", "CMAJFLT", "UTIME", "STIME", "CUTIME", "CSTIME", "PRIORITY", "NICE", "STARTTIME", "PROCESSOR", "M_VIRT", "M_RESIDENT", "M_SHARE", "M_TRS", "M_DRS", "M_LRS", "ST_UID", "PERCENT_CPU", "PERCENT_MEM", "USER", "TIME", "NLWP", "TGID", "PERCENT_NORM_CPU", "ELAPSED", "SCHEDULERPOLICY", "RCHAR", "WCHAR", "SYSCR", "SYSCW", "RBYTES", "WBYTES", "CNCLWB", "IO_READ_RATE", "IO_WRITE_RATE", "IO_RATE", "CGROUP", "OOM", "IO_PRIORITY", "M_PSS", "M_SWAP", "M_PSSWP", "CTXT", "SECATTR", "COMM", "EXE", "CWD", "AUTOGROUP_ID", "AUTOGROUP_NICE", "CCGROUP", "CONTAINER", "M_PRIV", "GPU_TIME", "GPU_PERCENT", "ISCONTAINER"} {
		validColumns[k] = true
	}
}

type options struct {
	delay      int
	filter     string
	maxIter    int
	pids       map[int]bool
	sortKey    string
	tree       bool
	noColor    bool
	noMeters   bool
	noFuncBar  bool
	noUnicode  bool
	noMouse    bool
	readonly   bool
	userFilter string
}

func main() {
	opts, action, err := parseArgs(os.Args)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	switch action {
	case "help":
		fmt.Print(helpText)
		return
	case "version":
		fmt.Println(version)
		return
	case "sorthelp":
		fmt.Print(sortHelp)
		return
	}
	if os.Getenv("TERM") == "" || os.Getenv("TERM") == "unknown" {
		fmt.Fprintln(os.Stderr, "Error opening terminal: unknown.")
		os.Exit(1)
	}
	if opts.delay <= 0 {
		opts.delay = 15
	}
	if opts.maxIter == 0 && !isCharDevice(os.Stdin) {
		opts.maxIter = 1
	}
	if opts.maxIter == 0 {
		opts.maxIter = -1
	}
	renderLoop(opts)
}

func parseArgs(argv []string) (options, string, error) {
	opts := options{delay: 15}
	args := argv[1:]
	prog := argv[0]
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			if i+1 < len(args) {
				return opts, "", fmt.Errorf("Error: unsupported non-option ARGV-elements: %s", strings.Join(args[i+1:], " "))
			}
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			return opts, "", fmt.Errorf("Error: unsupported non-option ARGV-elements: %s", strings.Join(args[i:], " "))
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasVal := strings.Cut(a[2:], "=")
			switch name {
			case "help":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				return opts, "help", nil
			case "version":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				return opts, "version", nil
			case "no-color", "no-colour":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.noColor = true
			case "no-function-bar":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.noFuncBar = true
			case "no-meters":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.noMeters = true
			case "no-mouse":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.noMouse = true
			case "no-unicode":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.noUnicode = true
			case "readonly":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.readonly = true
			case "tree":
				if hasVal {
					return opts, "", fmt.Errorf("%s: option '--%s' doesn't allow an argument", prog, name)
				}
				opts.tree = true
			case "delay", "filter", "pid", "sort-key", "max-iterations":
				if !hasVal {
					if i+1 >= len(args) {
						return opts, "", fmt.Errorf("%s: option '--%s' requires an argument", prog, name)
					}
					i++
					val = args[i]
				}
				if err := setLong(&opts, name, val); err != nil {
					if errors.Is(err, errSortHelp) {
						return opts, "sorthelp", nil
					}
					return opts, "", err
				}
			case "user":
				if !hasVal {
					if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
						i++
						val = args[i]
					} else {
						val = defaultUser()
					}
				} else if val == "" {
					return opts, "", fmt.Errorf("Error: invalid user %q.", val)
				}
				if err := setUser(&opts, val); err != nil {
					return opts, "", err
				}
			case "highlight-changes":
				if hasVal {
					if _, err := strconv.Atoi(val); err != nil {
						return opts, "", fmt.Errorf("Error: invalid highlight delay value %q.", val)
					}
				}
			default:
				return opts, "", fmt.Errorf("%s: unrecognized option '--%s'", prog, name)
			}
			continue
		}
		shorts := a[1:]
		for j := 0; j < len(shorts); j++ {
			c := shorts[j]
			switch c {
			case 'h':
				return opts, "help", nil
			case 'V':
				return opts, "version", nil
			case 'C':
				opts.noColor = true
			case 'M':
				opts.noMouse = true
			case 'U':
				opts.noUnicode = true
			case 't':
				opts.tree = true
			case 'd', 'F', 'n', 'p', 's':
				val := shorts[j+1:]
				if val == "" {
					if i+1 >= len(args) {
						return opts, "", fmt.Errorf("%s: option requires an argument -- '%c'", prog, c)
					}
					i++
					val = args[i]
				}
				if err := setShort(&opts, c, val); err != nil {
					if errors.Is(err, errSortHelp) {
						return opts, "sorthelp", nil
					}
					return opts, "", err
				}
				j = len(shorts)
			case 'u':
				val := shorts[j+1:]
				if val == "" {
					if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
						i++
						val = args[i]
					} else {
						val = defaultUser()
					}
				}
				if err := setUser(&opts, val); err != nil {
					return opts, "", err
				}
				j = len(shorts)
			case 'H':
				val := shorts[j+1:]
				if val != "" {
					if _, err := strconv.Atoi(val); err != nil {
						return opts, "", fmt.Errorf("Error: invalid highlight delay value %q.", val)
					}
					j = len(shorts)
				}
			default:
				return opts, "", fmt.Errorf("%s: invalid option -- '%c'", prog, c)
			}
		}
	}
	return opts, "", nil
}

var errSortHelp = errors.New("sort help")

func setLong(opts *options, name, val string) error {
	switch name {
	case "delay":
		return setDelay(opts, val)
	case "filter":
		opts.filter = val
	case "pid":
		opts.pids = parsePIDList(val)
	case "sort-key":
		return setSort(opts, val)
	case "max-iterations":
		return setMaxIter(opts, val)
	}
	return nil
}

func setShort(opts *options, c byte, val string) error {
	switch c {
	case 'd':
		return setDelay(opts, val)
	case 'F':
		opts.filter = val
	case 'n':
		return setMaxIter(opts, val)
	case 'p':
		opts.pids = parsePIDList(val)
	case 's':
		return setSort(opts, val)
	case 'u':
		return setUser(opts, val)
	}
	return nil
}

func setDelay(opts *options, val string) error {
	n, err := strconv.Atoi(val)
	if err != nil {
		return fmt.Errorf("Error: invalid delay value %q.", val)
	}
	if n < 1 {
		n = 1
	}
	if n > 100 {
		n = 100
	}
	opts.delay = n
	return nil
}

func setMaxIter(opts *options, val string) error {
	n, err := strconv.Atoi(val)
	if err != nil {
		return fmt.Errorf("Error: invalid maximum iteration count %q.", val)
	}
	if n <= 0 {
		return fmt.Errorf("Error: maximum iteration count must be positive.")
	}
	opts.maxIter = n
	return nil
}

func setSort(opts *options, val string) error {
	if val == "help" {
		return errSortHelp
	}
	if !validColumns[val] {
		return fmt.Errorf("Error: invalid column %q.", val)
	}
	opts.sortKey = val
	return nil
}

func setUser(opts *options, val string) error {
	if val == "" {
		val = defaultUser()
	}
	if _, err := user.Lookup(val); err == nil {
		opts.userFilter = val
		return nil
	}
	if _, err := user.LookupId(val); err == nil {
		opts.userFilter = val
		return nil
	}
	return fmt.Errorf("Error: invalid user %q.", val)
}

func defaultUser() string {
	if u, err := user.Current(); err == nil {
		if u.Username != "" {
			return u.Username
		}
		return u.Uid
	}
	if v := os.Getenv("USER"); v != "" {
		return v
	}
	return strconv.Itoa(os.Getuid())
}

func parsePIDList(s string) map[int]bool {
	out := map[int]bool{}
	for _, part := range strings.Split(s, ",") {
		n, err := strconv.Atoi(strings.TrimSpace(part))
		if err == nil && n > 0 {
			out[n] = true
		}
	}
	return out
}

func isCharDevice(f *os.File) bool {
	st, err := f.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) != 0
}

type proc struct {
	pid, ppid int
	uid       string
	user      string
	state     string
	priority  int
	nice      int
	vsize     uint64
	rss       int64
	utime     uint64
	stime     uint64
	cmd       string
	comm      string
}

func renderLoop(opts options) {
	first := true
	count := 0
	for opts.maxIter < 0 || count < opts.maxIter {
		if first {
			fmt.Print("\x1b[?1049h\x1b[H\x1b[2J\x1b[?25l")
			first = false
		} else {
			fmt.Print("\x1b[H")
		}
		renderFrame(os.Stdout, opts)
		count++
		if opts.maxIter >= 0 && count >= opts.maxIter {
			break
		}
		time.Sleep(time.Duration(opts.delay) * 100 * time.Millisecond)
	}
	fmt.Print("\x1b[?25h\x1b[?1049l")
}

func renderFrame(w io.Writer, opts options) {
	cols, rows := terminalSize()
	procs := readProcesses(opts)
	load := readLoad()
	memUsed, memTotal, swapUsed, swapTotal := readMem()
	cpus := cpuCount()
	if !opts.noMeters {
		for i := 0; i < cpus && i < 8; i += 2 {
			fmt.Fprintf(w, "  %3d[%s]  %3d[%s]\r\n", i, bar(0, 10), i+1, bar(0, 10))
		}
		fmt.Fprintf(w, "  Mem[%s %s/%s] Tasks: %d; %d running\r\n", bar(float64(memUsed)/float64(max64(memTotal, 1)), 14), humanKB(memUsed), humanKB(memTotal), len(procs), countRunning(procs))
		fmt.Fprintf(w, "  Swp[%s %s/%s] Load average: %s  Uptime: %s\r\n", bar(float64(swapUsed)/float64(max64(swapTotal, 1)), 14), humanKB(swapUsed), humanKB(swapTotal), load, uptime())
	}
	fmt.Fprintln(w, "  [Main] [I/O]")
	fmt.Fprintln(w, "  PID USER       PRI  NI  VIRT   RES S  CPU% MEM%   TIME+  Command")
	avail := rows - 7
	if opts.noMeters {
		avail = rows - 3
	}
	if avail < 1 {
		avail = 1
	}
	for i, p := range procs {
		if i >= avail {
			break
		}
		cmd := p.cmd
		if opts.tree && p.ppid > 0 {
			cmd = "|-" + cmd
		}
		line := fmt.Sprintf("%5d %-10.10s %3d %3d %5s %5s %-1s %5.1f %4.1f %8s %s",
			p.pid, p.user, p.priority, p.nice, humanKB(p.vsize/1024), humanKB(uint64(max64(uint64(p.rss), 0))*pageKB()), p.state, 0.0, percentMem(p, memTotal), cpuTime(p), cmd)
		if len(line) > cols {
			line = line[:cols]
		}
		fmt.Fprintln(w, line)
	}
	if !opts.noFuncBar {
		fmt.Fprintln(w, "F1Help F2Setup F3Search F4Filter F5Tree F6SortBy F9Kill F10Quit")
	}
}

func terminalSize() (int, int) {
	cols, _ := strconv.Atoi(os.Getenv("COLUMNS"))
	rows, _ := strconv.Atoi(os.Getenv("LINES"))
	if cols <= 0 {
		cols = 80
	}
	if rows <= 0 {
		rows = 24
	}
	return cols, rows
}

func readProcesses(opts options) []proc {
	ents, err := os.ReadDir("/proc")
	if err != nil {
		return nil
	}
	var ps []proc
	for _, e := range ents {
		if !e.IsDir() || !allDigits(e.Name()) {
			continue
		}
		pid, _ := strconv.Atoi(e.Name())
		if len(opts.pids) > 0 && !opts.pids[pid] {
			continue
		}
		p, err := readProc(pid)
		if err != nil {
			continue
		}
		if opts.userFilter != "" && p.user != opts.userFilter && p.uid != opts.userFilter {
			continue
		}
		if opts.filter != "" && !matchesFilter(p.cmd, opts.filter) {
			continue
		}
		ps = append(ps, p)
	}
	sort.Slice(ps, func(i, j int) bool {
		switch opts.sortKey {
		case "USER":
			if ps[i].user == ps[j].user {
				return ps[i].pid < ps[j].pid
			}
			return ps[i].user < ps[j].user
		case "PPID":
			if ps[i].ppid == ps[j].ppid {
				return ps[i].pid < ps[j].pid
			}
			return ps[i].ppid < ps[j].ppid
		case "M_RESIDENT", "PERCENT_MEM":
			return ps[i].rss > ps[j].rss
		case "TIME":
			return ps[i].utime+ps[i].stime > ps[j].utime+ps[j].stime
		default:
			return ps[i].pid < ps[j].pid
		}
	})
	return ps
}

func readProc(pid int) (proc, error) {
	var p proc
	p.pid = pid
	statBytes, err := os.ReadFile(fmt.Sprintf("/proc/%d/stat", pid))
	if err != nil {
		return p, err
	}
	stat := string(statBytes)
	l := strings.LastIndex(stat, ")")
	r := strings.Index(stat, "(")
	if r < 0 || l < 0 || l <= r {
		return p, errors.New("bad stat")
	}
	p.comm = stat[r+1 : l]
	fields := strings.Fields(stat[l+2:])
	if len(fields) < 22 {
		return p, errors.New("short stat")
	}
	p.state = fields[0]
	p.ppid, _ = strconv.Atoi(fields[1])
	p.utime, _ = strconv.ParseUint(fields[11], 10, 64)
	p.stime, _ = strconv.ParseUint(fields[12], 10, 64)
	p.priority, _ = strconv.Atoi(fields[15])
	p.nice, _ = strconv.Atoi(fields[16])
	p.vsize, _ = strconv.ParseUint(fields[20], 10, 64)
	rss, _ := strconv.ParseInt(fields[21], 10, 64)
	p.rss = rss
	p.uid = readUID(pid)
	p.user = username(p.uid)
	p.cmd = readCmd(pid, p.comm)
	return p, nil
}

func readUID(pid int) string {
	f, err := os.Open(fmt.Sprintf("/proc/%d/status", pid))
	if err != nil {
		return ""
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		if strings.HasPrefix(line, "Uid:") {
			fs := strings.Fields(line)
			if len(fs) > 1 {
				return fs[1]
			}
		}
	}
	return ""
}

func username(uid string) string {
	if u, err := user.LookupId(uid); err == nil {
		return u.Username
	}
	return uid
}

func readCmd(pid int, comm string) string {
	b, err := os.ReadFile(fmt.Sprintf("/proc/%d/cmdline", pid))
	if err == nil && len(b) > 0 {
		parts := strings.Split(strings.TrimRight(string(b), "\x00"), "\x00")
		return strings.Join(parts, " ")
	}
	if exe, err := os.Readlink(fmt.Sprintf("/proc/%d/exe", pid)); err == nil {
		return filepath.Base(exe)
	}
	return comm
}

func matchesFilter(cmd, filter string) bool {
	cmd = strings.ToLower(cmd)
	for _, term := range strings.Split(filter, "|") {
		term = strings.ToLower(strings.TrimSpace(term))
		if term != "" && strings.Contains(cmd, term) {
			return true
		}
	}
	return false
}

func allDigits(s string) bool {
	for _, r := range s {
		if !unicode.IsDigit(r) {
			return false
		}
	}
	return s != ""
}

func readLoad() string {
	b, err := os.ReadFile("/proc/loadavg")
	if err != nil {
		return "0.00 0.00 0.00"
	}
	fs := strings.Fields(string(b))
	if len(fs) >= 3 {
		return strings.Join(fs[:3], " ")
	}
	return strings.TrimSpace(string(b))
}

func readMem() (uint64, uint64, uint64, uint64) {
	b, err := os.ReadFile("/proc/meminfo")
	if err != nil {
		return 0, 1, 0, 1
	}
	vals := map[string]uint64{}
	for _, line := range strings.Split(string(b), "\n") {
		fs := strings.Fields(line)
		if len(fs) >= 2 {
			n, _ := strconv.ParseUint(fs[1], 10, 64)
			vals[strings.TrimSuffix(fs[0], ":")] = n
		}
	}
	total := vals["MemTotal"]
	avail := vals["MemAvailable"]
	swapTotal := vals["SwapTotal"]
	swapFree := vals["SwapFree"]
	return total - avail, total, swapTotal - swapFree, swapTotal
}

func cpuCount() int {
	b, err := os.ReadFile("/proc/stat")
	if err != nil {
		return 1
	}
	n := 0
	for _, line := range strings.Split(string(b), "\n") {
		if strings.HasPrefix(line, "cpu") && len(line) > 3 && unicode.IsDigit(rune(line[3])) {
			n++
		}
	}
	if n == 0 {
		n = 1
	}
	return n
}

func countRunning(ps []proc) int {
	n := 0
	for _, p := range ps {
		if p.state == "R" {
			n++
		}
	}
	return n
}

func bar(frac float64, width int) string {
	if frac < 0 {
		frac = 0
	}
	if frac > 1 {
		frac = 1
	}
	n := int(frac * float64(width))
	return strings.Repeat("|", n) + strings.Repeat(" ", width-n)
}

func humanKB(kb uint64) string {
	if kb >= 1024*1024 {
		return fmt.Sprintf("%.1fG", float64(kb)/1024.0/1024.0)
	}
	if kb >= 1024 {
		return fmt.Sprintf("%dM", kb/1024)
	}
	return fmt.Sprintf("%dK", kb)
}

func pageKB() uint64 {
	return uint64(os.Getpagesize() / 1024)
}

func percentMem(p proc, memTotal uint64) float64 {
	if memTotal == 0 {
		return 0
	}
	return float64(uint64(max64(uint64(p.rss), 0))*pageKB()) * 100 / float64(memTotal)
}

func cpuTime(p proc) string {
	hz := uint64(100)
	sec := (p.utime + p.stime) / hz
	return fmt.Sprintf("%d:%02d.%02d", sec/60, sec%60, ((p.utime+p.stime)%hz)*100/hz)
}

func uptime() string {
	b, err := os.ReadFile("/proc/uptime")
	if err != nil {
		return "0 days, 00:00:00"
	}
	fs := strings.Fields(string(b))
	if len(fs) == 0 {
		return "0 days, 00:00:00"
	}
	f, _ := strconv.ParseFloat(fs[0], 64)
	sec := int(f)
	days := sec / 86400
	sec %= 86400
	return fmt.Sprintf("%d days, %02d:%02d:%02d", days, sec/3600, (sec/60)%60, sec%60)
}

func max64(a, b uint64) uint64 {
	if a > b {
		return a
	}
	return b
}
