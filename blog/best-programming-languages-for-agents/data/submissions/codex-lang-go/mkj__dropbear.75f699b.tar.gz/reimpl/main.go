package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const version = "2025.89"

var defaultKeys = []string{
	"/etc/dropbear/dropbear_rsa_host_key",
	"/etc/dropbear/dropbear_ecdsa_host_key",
	"/etc/dropbear/dropbear_ed25519_host_key",
}

type options struct {
	hostKeys      []string
	createKeys    bool
	foreground    bool
	inetd         bool
	noPass        bool
	twoFactor     bool
	pidFile       string
	ports         []string
	banner        string
	bindIface     string
	forcedCommand string
}

func prog() string {
	if len(os.Args) == 0 || os.Args[0] == "" {
		return "dropbear"
	}
	return os.Args[0]
}

func usage() {
	p := prog()
	fmt.Fprintf(os.Stderr, "Dropbear server v%s https://matt.ucc.asn.au/dropbear/dropbear.html\n", version)
	fmt.Fprintf(os.Stderr, "Usage: %s [options]\n", p)
	fmt.Fprintln(os.Stderr, "-b bannerfile\tDisplay the contents of bannerfile before user login")
	fmt.Fprintln(os.Stderr, "\t\t(default: none)")
	fmt.Fprintln(os.Stderr, "-r keyfile      Specify hostkeys (repeatable)")
	fmt.Fprintln(os.Stderr, "\t\tdefaults: ")
	fmt.Fprintln(os.Stderr, "\t\t- rsa /etc/dropbear/dropbear_rsa_host_key")
	fmt.Fprintln(os.Stderr, "\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key")
	fmt.Fprintln(os.Stderr, "\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key")
	fmt.Fprintln(os.Stderr, "-D\t\tDirectory containing authorized_keys file")
	fmt.Fprintln(os.Stderr, "-R\t\tCreate hostkeys as required")
	fmt.Fprintln(os.Stderr, "-F\t\tDon't fork into background")
	fmt.Fprintln(os.Stderr, "-e\t\tPass on server process environment to child process")
	fmt.Fprintln(os.Stderr, "(Syslog support not compiled in, using stderr)")
	fmt.Fprintln(os.Stderr, "-m\t\tDon't display the motd on login")
	fmt.Fprintln(os.Stderr, "-w\t\tDisallow root logins")
	fmt.Fprintln(os.Stderr, "-G\t\tRestrict logins to members of specified group")
	fmt.Fprintln(os.Stderr, "-s\t\tDisable password logins")
	fmt.Fprintln(os.Stderr, "-g\t\tDisable password logins for root")
	fmt.Fprintln(os.Stderr, "-B\t\tAllow blank password logins")
	fmt.Fprintln(os.Stderr, "-t\t\tEnable two-factor authentication (both password and public key required)")
	fmt.Fprintln(os.Stderr, "-T\t\tMaximum authentication tries (default 10)")
	fmt.Fprintln(os.Stderr, "-j\t\tDisable local port forwarding")
	fmt.Fprintln(os.Stderr, "-k\t\tDisable remote port forwarding")
	fmt.Fprintln(os.Stderr, "-a\t\tAllow connections to forwarded ports from any host")
	fmt.Fprintln(os.Stderr, "-c command\tForce executed command")
	fmt.Fprintln(os.Stderr, "-p [address:]port")
	fmt.Fprintln(os.Stderr, "\t\tListen on specified tcp port (and optionally address),")
	fmt.Fprintln(os.Stderr, "\t\tup to 10 can be specified")
	fmt.Fprintln(os.Stderr, "\t\t(default port is 22 if none specified)")
	fmt.Fprintln(os.Stderr, "-P PidFile\tCreate pid file PidFile")
	fmt.Fprintln(os.Stderr, "\t\t(default /var/run/dropbear.pid)")
	fmt.Fprintln(os.Stderr, "-l <interface>")
	fmt.Fprintln(os.Stderr, "\t\tinterface to bind on")
	fmt.Fprintln(os.Stderr, "-i\t\tStart for inetd")
	fmt.Fprintln(os.Stderr, "-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)")
	fmt.Fprintln(os.Stderr, "-K <keepalive>  (0 is never, default 0, in seconds)")
	fmt.Fprintln(os.Stderr, "-I <idle_timeout>  (0 is never, default 0, in seconds)")
	fmt.Fprintln(os.Stderr, "-z    disable QoS")
	fmt.Fprintln(os.Stderr, "-V    Version")
}

func logf(format string, a ...any) {
	now := time.Now().Format("Jan _2 15:04:05")
	fmt.Fprintf(os.Stderr, "[%d] %s %s\n", os.Getpid(), now, fmt.Sprintf(format, a...))
}

func die(msg string, a ...any) int {
	logf("Early exit: "+msg, a...)
	return 1
}

func needArg(args []string, i *int) (string, bool) {
	if *i+1 >= len(args) {
		return "", false
	}
	*i++
	return args[*i], true
}

func parsePort(s string) bool {
	p := s
	if idx := strings.LastIndexByte(s, ':'); idx >= 0 {
		p = s[idx+1:]
	}
	if p == "" {
		return false
	}
	n, err := strconv.Atoi(p)
	return err == nil && n >= 0 && n <= 65535
}

func parseArgs(args []string) (options, int) {
	op := options{pidFile: "/var/run/dropbear.pid"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--help" {
			fmt.Fprintln(os.Stderr, "Invalid option --")
			usage()
			return op, 1
		}
		if a == "" || a[0] != '-' || a == "-" {
			return op, die("Invalid argument: %s", a)
		}
		if len(a) != 2 {
			fmt.Fprintf(os.Stderr, "Invalid option %s\n", a)
			usage()
			return op, 1
		}
		switch a[1] {
		case 'h':
			usage()
			return op, 0
		case 'V':
			fmt.Printf("Dropbear v%s\n", version)
			return op, 0
		case 'b':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			op.banner = v
		case 'r':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			op.hostKeys = append(op.hostKeys, v)
		case 'D', 'G':
			_, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
		case 'R':
			op.createKeys = true
		case 'F':
			op.foreground = true
		case 'e', 'm', 'w', 'g', 'B', 'j', 'k', 'a', 'z':
			// accepted flags
		case 's':
			op.noPass = true
		case 't':
			op.twoFactor = true
		case 'T':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			if _, err := strconv.Atoi(v); err != nil { return op, die("Bad maxauthtries '%s'", v) }
		case 'c':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			op.forcedCommand = v
			logf("Forced command set to '%s'", v)
		case 'p':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			op.ports = append(op.ports, v)
			if len(op.ports) > 10 { return op, die("Too many ports") }
		case 'P':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			op.pidFile = v
		case 'l':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			op.bindIface = v
			logf("Binding to interface '%s'", v)
		case 'i':
			op.inetd = true
		case 'W':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			n, err := strconv.Atoi(v)
			if err != nil || n < 1 {
				logf("Bad recv window '%s', using 24576", v)
			} else if n > 10485760 {
				logf("Bad recv window '%s', using 10485760", v)
			}
		case 'K':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			if _, err := strconv.Atoi(v); err != nil { return op, die("Bad keepalive '%s'", v) }
		case 'I':
			v, ok := needArg(args, &i); if !ok { return op, die("Missing argument") }
			if _, err := strconv.Atoi(v); err != nil { return op, die("Bad idle_timeout '%s'", v) }
		default:
			fmt.Fprintf(os.Stderr, "Invalid option -%c\n", a[1])
			usage()
			return op, 1
		}
	}
	if op.noPass && op.twoFactor {
		return op, die("-t and -s are incompatible")
	}
	return op, -1
}

func checkHostKeys(op options) bool {
	keys := op.hostKeys
	if len(keys) == 0 {
		keys = defaultKeys
	}
	loaded := false
	for _, k := range keys {
		if st, err := os.Stat(k); err == nil && !st.IsDir() && st.Size() > 0 {
			loaded = true
		} else {
			logf("Failed loading %s", k)
		}
	}
	return loaded
}

func bindAddress(spec string) string {
	if spec == "" {
		return ":22"
	}
	if strings.Contains(spec, ":") {
		return spec
	}
	return ":" + spec
}

func runServer(op options) int {
	if op.banner != "" {
		if _, err := os.Open(op.banner); err != nil {
			logf("Error opening banner file '%s'", op.banner)
		}
	}
	if !op.createKeys && !checkHostKeys(op) {
		return die("No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.")
	}
	if op.inetd {
		fmt.Fprint(os.Stdout, "SSH-2.0-dropbear_2025.89\r\n")
		return 0
	}
	if len(op.ports) == 0 {
		op.ports = []string{"22"}
	}
	if op.pidFile != "" && op.foreground {
		_ = os.WriteFile(op.pidFile, []byte(strconv.Itoa(os.Getpid())+"\n"), 0644)
	}
	listeners := make([]net.Listener, 0, len(op.ports))
	for _, p := range op.ports {
		ln, err := net.Listen("tcp", bindAddress(p))
		if err != nil {
			logf("Failed listening on '%s': %s", p, err)
			continue
		}
		listeners = append(listeners, ln)
		go func(l net.Listener) {
			for {
				c, err := l.Accept()
				if err != nil { return }
				go func(conn net.Conn) {
					defer conn.Close()
					fmt.Fprint(conn, "SSH-2.0-dropbear_2025.89\r\n")
					_, _ = bufio.NewReader(conn).ReadString('\n')
				}(c)
			}
		}(ln)
	}
	if len(listeners) == 0 {
		return die("No listening ports available")
	}
	if !op.foreground {
		logf("Running in background")
		return 0
	}
	select {}
}

func main() {
	// Match Dropbear's argv[0] convention for symlinked names in diagnostics.
	if base := filepath.Base(prog()); base == "" {
		_ = base
	}
	op, status := parseArgs(os.Args[1:])
	if status >= 0 {
		os.Exit(status)
	}
	os.Exit(runServer(op))
}
