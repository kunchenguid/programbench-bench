package main

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"unicode"
)

type options struct {
	file          string
	lengthSet     bool
	length        int64
	skipSet       bool
	skip          int64
	blockSize     int64
	noSqueeze     bool
	color         string
	border        string
	showChars     bool
	showPos       bool
	charTable     string
	colorScheme   string
	displayOffset int64
	panels        int
	groupSize     int
	endianness    string
	base          string
	include       bool
	termWidth     int
	plain         bool
}

var reset = "\x1b[39m"

func main() {
	opt := defaultOptions()
	if err := parseArgs(os.Args[1:], &opt); err != nil {
		if err == errExit {
			return
		}
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if opt.color == "auto" || (os.Getenv("NO_COLOR") != "" && opt.color != "force") {
		opt.color = "never"
	}
	if opt.include {
		if err := includeOutput(opt); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
		return
	}
	if err := dump(opt); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func defaultOptions() options {
	return options{
		blockSize: 512, color: "always", border: "unicode", showChars: true,
		showPos: true, charTable: "default", colorScheme: "default",
		panels: 2, groupSize: 1, endianness: "big", base: "hexadecimal",
	}
}

var errExit = errors.New("exit")

func parseArgs(args []string, opt *options) error {
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			if i+1 < len(args) {
				if opt.file != "" {
					return fmt.Errorf("error: unexpected argument '%s' found", args[i+1])
				}
				opt.file = args[i+1]
			}
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			if opt.file != "" {
				return fmt.Errorf("error: unexpected argument '%s' found", a)
			}
			opt.file = a
			continue
		}
		name, val, hasVal := strings.Cut(a, "=")
		take := func() (string, error) {
			if hasVal {
				return val, nil
			}
			i++
			if i >= len(args) {
				return "", fmt.Errorf("error: a value is required for '%s <value>' but none was supplied", name)
			}
			return args[i], nil
		}
		switch name {
		case "-h", "--help":
			printHelp(false)
			return errExit
		case "-V", "--version":
			fmt.Println("hexyl 0.16.0")
			return errExit
		case "--print-color-table":
			printColorTable()
			return errExit
		case "-n", "--length", "--bytes", "-c", "-l":
			v, e := take()
			if e != nil {
				return e
			}
			n, e := parseCount(v, opt.blockSize, true)
			if e != nil {
				return fmt.Errorf("Error: failed to parse `%s` arg %q as byte count\n\nCaused by:\n    %v", name, v, e)
			}
			opt.lengthSet, opt.length = true, n
		case "-s", "--skip":
			v, e := take()
			if e != nil {
				return e
			}
			n, e := parseCount(v, opt.blockSize, false)
			if e != nil {
				return fmt.Errorf("Error: failed to parse `%s` arg %q as byte count\n\nCaused by:\n    %v", name, v, e)
			}
			opt.skipSet, opt.skip = true, n
		case "--block-size":
			v, e := take()
			if e != nil {
				return e
			}
			n, e := parseCount(v, opt.blockSize, true)
			if e != nil {
				return e
			}
			opt.blockSize = n
		case "-v", "--no-squeezing":
			opt.noSqueeze = true
		case "--color":
			v, e := take()
			if e != nil {
				return e
			}
			opt.color = v
		case "--border":
			v, e := take()
			if e != nil {
				return e
			}
			opt.border = v
		case "-p", "--plain":
			opt.showChars, opt.showPos, opt.border, opt.color = false, false, "none", "never"
			opt.plain = true
		case "--no-characters":
			opt.showChars = false
		case "-C", "--characters":
			if !opt.plain {
				opt.showChars = true
			}
		case "--character-table":
			v, e := take()
			if e != nil {
				return e
			}
			opt.charTable = v
		case "--color-scheme":
			v, e := take()
			if e != nil {
				return e
			}
			opt.colorScheme = v
		case "-P", "--no-position":
			opt.showPos = false
		case "-o", "--display-offset":
			v, e := take()
			if e != nil {
				return e
			}
			n, e := parseCount(v, opt.blockSize, true)
			if e != nil {
				return fmt.Errorf("Error: failed to parse `%s` arg %q as byte count\n\nCaused by:\n    %v", name, v, e)
			}
			opt.displayOffset = n
		case "--panels":
			v, e := take()
			if e != nil {
				return e
			}
			if v == "auto" {
				opt.panels = 2
			} else {
				n, e := strconv.Atoi(v)
				if e != nil || n < 1 {
					return fmt.Errorf("error: invalid value '%s'", v)
				}
				opt.panels = n
			}
		case "-g", "--group-size", "--groupsize":
			v, e := take()
			if e != nil {
				return e
			}
			n, e := strconv.Atoi(v)
			if e != nil || !(n == 1 || n == 2 || n == 4 || n == 8) {
				return fmt.Errorf("error: invalid value '%s'", v)
			}
			opt.groupSize = n
		case "--endianness":
			v, e := take()
			if e != nil {
				return e
			}
			opt.endianness = v
		case "-e":
			opt.endianness = "little"
		case "-b", "--base":
			v, e := take()
			if e != nil {
				return e
			}
			opt.base = normalizeBase(v)
		case "--terminal-width":
			v, e := take()
			if e != nil {
				return e
			}
			n, _ := strconv.Atoi(v)
			opt.termWidth = n
			if n > 0 && n < 80 {
				opt.panels = 1
			}
		case "-i", "--include":
			opt.include = true
		case "--completion":
			v, e := take()
			if e != nil {
				return e
			}
			printCompletion(v)
			return errExit
		default:
			return fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.", a)
		}
	}
	return nil
}

func normalizeBase(s string) string {
	switch s {
	case "hex", "hexadecimal":
		return "hexadecimal"
	case "bin", "binary":
		return "binary"
	case "oct", "octal":
		return "octal"
	case "dec", "decimal":
		return "decimal"
	}
	return s
}

func parseCount(s string, block int64, positive bool) (int64, error) {
	neg := strings.HasPrefix(s, "-")
	if neg && positive {
		return 0, errors.New("negative offset specified, but only positive offsets (counts) are accepted in this context")
	}
	body := strings.TrimPrefix(s, "-")
	j := 0
	if strings.HasPrefix(body, "0x") || strings.HasPrefix(body, "0X") {
		j = 2
		for j < len(body) && ((body[j] >= '0' && body[j] <= '9') || (body[j] >= 'a' && body[j] <= 'f') || (body[j] >= 'A' && body[j] <= 'F')) {
			j++
		}
	} else {
		for j < len(body) && body[j] >= '0' && body[j] <= '9' {
			j++
		}
	}
	num, unit := body[:j], body[j:]
	if num == "" {
		return 0, fmt.Errorf("invalid digit found in string")
	}
	var n int64
	var err error
	if strings.HasPrefix(num, "0x") || strings.HasPrefix(num, "0X") {
		n, err = strconv.ParseInt(num[2:], 16, 64)
	} else {
		n, err = strconv.ParseInt(num, 10, 64)
	}
	if err != nil {
		return 0, err
	}
	mult := int64(1)
	switch strings.ToLower(unit) {
	case "", "b":
	case "kb":
		mult = 1000
	case "mb":
		mult = 1000 * 1000
	case "gb":
		mult = 1000 * 1000 * 1000
	case "kib", "k":
		mult = 1024
	case "mib", "m":
		mult = 1024 * 1024
	case "gib", "g":
		mult = 1024 * 1024 * 1024
	case "block", "blocks":
		mult = block
	default:
		return 0, fmt.Errorf("unknown unit %q", unit)
	}
	if neg {
		return -n * mult, nil
	}
	return n * mult, nil
}

func readInput(opt options) ([]byte, int64, error) {
	var data []byte
	var err error
	if opt.file == "" || opt.file == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(opt.file)
	}
	if err != nil {
		return nil, 0, err
	}
	start := int64(0)
	if opt.skipSet {
		if opt.skip < 0 {
			start = int64(len(data)) + opt.skip
		} else {
			start = opt.skip
		}
		if start < 0 {
			start = 0
		}
		if start > int64(len(data)) {
			start = int64(len(data))
		}
	}
	end := int64(len(data))
	if opt.lengthSet && start+opt.length < end {
		end = start + opt.length
	}
	return data[start:end], start, nil
}

func dump(opt options) error {
	data, start, err := readInput(opt)
	if err != nil {
		return err
	}
	p := layout{opt: opt, posWidth: posWidth(start + opt.displayOffset + int64(len(data)))}
	if opt.border != "none" {
		fmt.Println(p.borderLine(true))
	}
	lineBytes := opt.panels * 8
	var prev []byte
	squeezed := false
	for off := 0; off < len(data); off += lineBytes {
		end := off + lineBytes
		if end > len(data) {
			end = len(data)
		}
		chunk := data[off:end]
		if !opt.noSqueeze && len(chunk) == lineBytes && prev != nil && bytes.Equal(chunk, prev) {
			if !squeezed {
				fmt.Println(p.starLine())
				squeezed = true
			}
			continue
		}
		squeezed = false
		if len(chunk) == lineBytes {
			prev = append(prev[:0], chunk...)
		}
		fmt.Println(p.dataLine(start+int64(off)+opt.displayOffset, chunk))
	}
	if !opt.noSqueeze && squeezed && len(data)%lineBytes == 0 {
		fmt.Println(p.dataLine(start+int64(len(data))+opt.displayOffset, nil))
	}
	if opt.border != "none" {
		fmt.Println(p.borderLine(false))
	}
	return nil
}

type layout struct {
	opt      options
	posWidth int
}

func posWidth(max int64) int {
	if max < 0 {
		max = -max
	}
	w := len(fmt.Sprintf("%x", max))
	if w < 8 {
		w = 8
	}
	return w
}

func (l layout) unitWidth() int {
	switch l.opt.base {
	case "binary":
		return 8
	case "octal", "decimal":
		return 3
	default:
		return 2
	}
}

func (l layout) panelWidth() int {
	groups := (8 + l.opt.groupSize - 1) / l.opt.groupSize
	return 1 + 8*l.unitWidth() + (groups - 1) + 1
}

func (l layout) borderChars() (string, string, string, string, string, string, string) {
	if l.opt.border == "ascii" {
		return "+", "+", "+", "+", "-", "|", "|"
	}
	return "┌", "┬", "┐", "└", "─", "│", "┊"
}

func (l layout) borderLine(top bool) string {
	left, mid, right, bottomLeft, h, _, _ := l.borderChars()
	if !top {
		left, right = bottomLeft, "┘"
		if l.opt.border == "ascii" {
			left, right = "+", "+"
		} else {
			mid = "┴"
		}
	}
	parts := []string{}
	if l.opt.showPos {
		parts = append(parts, strings.Repeat(h, l.posWidth))
	}
	for i := 0; i < l.opt.panels; i++ {
		parts = append(parts, strings.Repeat(h, l.panelWidth()))
	}
	if l.opt.showChars {
		for i := 0; i < l.opt.panels; i++ {
			parts = append(parts, strings.Repeat(h, 8))
		}
	}
	return left + strings.Join(parts, mid) + right
}

func (l layout) dataLine(pos int64, b []byte) string {
	_, _, _, _, _, v, sep := l.borderChars()
	if l.opt.border == "ascii" {
		sep = "|"
	}
	var hexPanels, charPanels []string
	for i := 0; i < l.opt.panels; i++ {
		s := i * 8
		e := s + 8
		var part []byte
		if s < len(b) {
			if e > len(b) {
				e = len(b)
			}
			part = b[s:e]
		}
		hexPanels = append(hexPanels, l.hexPanel(part))
		if l.opt.showChars {
			charPanels = append(charPanels, l.charPanel(part))
		}
	}
	if l.opt.border == "none" {
		out := ""
		if l.opt.showPos {
			out += " " + fmt.Sprintf("%0*x", l.posWidth, pos) + " "
		} else {
			out += " "
		}
		out += strings.Join(hexPanels, " ")
		if l.opt.showChars {
			out += " " + strings.Join(charPanels, " ") + " "
		} else if !l.opt.showPos {
			out += " "
		}
		return out
	}
	cells := []string{}
	if l.opt.showPos {
		cells = append(cells, colorize(fmt.Sprintf("%0*x", l.posWidth, pos), "offset", l.opt))
	}
	cells = append(cells, hexPanels...)
	cells = append(cells, charPanels...)
	if l.opt.border == "unicode" && (l.opt.panels > 1 || (l.opt.showChars && l.opt.panels > 1)) {
		// Replace separators between peer data panels with dotted dividers.
		out := v
		idx := 0
		if l.opt.showPos {
			out += cells[0] + v
			idx = 1
		}
		for i := 0; i < l.opt.panels; i++ {
			out += cells[idx+i]
			if i == l.opt.panels-1 {
				out += v
			} else {
				out += sep
			}
		}
		idx += l.opt.panels
		if l.opt.showChars {
			for i := 0; i < l.opt.panels; i++ {
				out += cells[idx+i]
				if i == l.opt.panels-1 {
					out += v
				} else {
					out += sep
				}
			}
		}
		return out
	}
	return v + strings.Join(cells, v) + v
}

func (l layout) starLine() string {
	_, _, _, _, _, v, sep := l.borderChars()
	if l.opt.border == "ascii" {
		sep = "|"
	}
	if l.opt.border == "none" {
		out := ""
		if l.opt.showPos {
			out += " *" + strings.Repeat(" ", l.posWidth)
		}
		total := l.opt.panels*l.panelWidth() + (l.opt.panels - 1)
		if l.opt.showChars {
			total += 1 + l.opt.panels*8 + (l.opt.panels - 1) + 1
		}
		return out + strings.Repeat(" ", total)
	}
	blankHex := make([]string, l.opt.panels)
	for i := range blankHex {
		blankHex[i] = strings.Repeat(" ", l.panelWidth())
	}
	blankChar := make([]string, l.opt.panels)
	for i := range blankChar {
		blankChar[i] = strings.Repeat(" ", 8)
	}
	out := v
	if l.opt.showPos {
		out += "*" + strings.Repeat(" ", l.posWidth-1) + v
	}
	for i := 0; i < l.opt.panels; i++ {
		out += blankHex[i]
		if i == l.opt.panels-1 {
			out += v
		} else {
			out += sep
		}
	}
	if l.opt.showChars {
		for i := 0; i < l.opt.panels; i++ {
			out += blankChar[i]
			if i == l.opt.panels-1 {
				out += v
			} else {
				out += sep
			}
		}
	}
	return out
}

func (l layout) hexPanel(b []byte) string {
	g := l.opt.groupSize
	groups := []string{}
	for i := 0; i < 8; i += g {
		if i >= len(b) {
			groups = append(groups, strings.Repeat(" ", g*l.unitWidth()))
			continue
		}
		end := i + g
		if end > len(b) {
			end = len(b)
		}
		gb := append([]byte(nil), b[i:end]...)
		if l.opt.endianness == "little" && len(gb) == g {
			for a, z := 0, len(gb)-1; a < z; a, z = a+1, z-1 {
				gb[a], gb[z] = gb[z], gb[a]
			}
		}
		var s strings.Builder
		for _, x := range gb {
			s.WriteString(formatByte(x, l.opt.base))
		}
		if len(gb) < g {
			s.WriteString(strings.Repeat(" ", (g-len(gb))*l.unitWidth()))
		}
		groups = append(groups, colorize(s.String(), classByte(b[i]), l.opt))
	}
	return " " + strings.Join(groups, " ") + " "
}

func formatByte(b byte, base string) string {
	switch base {
	case "binary":
		return fmt.Sprintf("%08b", b)
	case "octal":
		return fmt.Sprintf("%03o", b)
	case "decimal":
		return fmt.Sprintf("%03d", b)
	default:
		return fmt.Sprintf("%02x", b)
	}
}

func (l layout) charPanel(b []byte) string {
	var s strings.Builder
	for i := 0; i < 8; i++ {
		if i < len(b) {
			ch := charFor(b[i], l.opt.charTable)
			s.WriteString(colorize(ch, classByte(b[i]), l.opt))
		} else {
			s.WriteByte(' ')
		}
	}
	return s.String()
}

func classByte(b byte) string {
	if b == 0 {
		return "null"
	}
	if b >= 0x80 {
		return "nonascii"
	}
	if b == ' ' || b == 0x09 || b == 0x0a || b == 0x0c || b == 0x0d {
		return "space"
	}
	if b >= 0x21 && b <= 0x7e {
		return "print"
	}
	return "other"
}

func charFor(b byte, table string) string {
	if table == "ascii" || table == "codepage-1047" {
		if b >= 0x21 && b <= 0x7e {
			return string(rune(b))
		}
		if b == ' ' {
			return " "
		}
		return "."
	}
	if table == "braille" {
		if b == 0 {
			return "⋄"
		}
		if b == 9 {
			return "→"
		}
		if b == 10 {
			return "↵"
		}
		if b == 13 {
			return "←"
		}
		if b >= 0x20 && b <= 0x7e {
			return string(rune(b))
		}
		if b < 0x20 {
			v := (b & 0x01) | ((b & 0x02) << 2) | ((b & 0x04) >> 1) | ((b & 0x08) << 1) | ((b & 0x10) >> 2)
			return string(rune(0x2800 + int(v)))
		}
		if b >= 0x80 {
			return "×"
		}
	}
	if table == "codepage-437" && b >= 0x80 {
		return cp437[b-0x80]
	}
	if b == 0 {
		return "⋄"
	}
	if b == ' ' {
		return " "
	}
	if b == 0x09 || b == 0x0a || b == 0x0c || b == 0x0d {
		return "_"
	}
	if b >= 0x21 && b <= 0x7e {
		return string(rune(b))
	}
	if b < 0x80 {
		return "•"
	}
	return "×"
}

var cp437 = []string{"Ç", "ü", "é", "â", "ä", "à", "å", "ç", "ê", "ë", "è", "ï", "î", "ì", "Ä", "Å", "É", "æ", "Æ", "ô", "ö", "ò", "û", "ù", "ÿ", "Ö", "Ü", "¢", "£", "¥", "₧", "ƒ", "á", "í", "ó", "ú", "ñ", "Ñ", "ª", "º", "¿", "⌐", "¬", "½", "¼", "¡", "«", "»", "░", "▒", "▓", "│", "┤", "╡", "╢", "╖", "╕", "╣", "║", "╗", "╝", "╜", "╛", "┐", "└", "┴", "┬", "├", "─", "┼", "╞", "╟", "╚", "╔", "╩", "╦", "╠", "═", "╬", "╧", "╨", "╤", "╥", "╙", "╘", "╒", "╓", "╫", "╪", "┘", "┌", "█", "▄", "▌", "▐", "▀", "α", "ß", "Γ", "π", "Σ", "σ", "µ", "τ", "Φ", "Θ", "Ω", "δ", "∞", "φ", "ε", "∩", "≡", "±", "≥", "≤", "⌠", "⌡", "÷", "≈", "°", "∙", "·", "√", "ⁿ", "²", "■", " "}

func colorize(s, cls string, opt options) string {
	if opt.color == "never" || s == "" || strings.TrimSpace(s) == "" {
		return s
	}
	code := "36"
	switch cls {
	case "offset", "null":
		code = "90"
	case "space", "other":
		code = "32"
	case "nonascii":
		code = "33"
	}
	return "\x1b[" + code + "m" + s + reset
}

func includeOutput(opt options) error {
	data, _, err := readInput(opt)
	if err != nil {
		return err
	}
	name := "stdin"
	if opt.file != "" && opt.file != "-" {
		name = filepath.Base(opt.file)
	}
	var b strings.Builder
	for _, r := range name {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
		} else {
			b.WriteByte('_')
		}
	}
	name = strings.Trim(b.String(), "_")
	if name == "" {
		name = "data"
	}
	fmt.Printf("unsigned char %s[] = {\n", name)
	for i, x := range data {
		if i%12 == 0 {
			fmt.Print("  ")
		} else {
			fmt.Print(" ")
		}
		if i == len(data)-1 {
			fmt.Printf("0x%02x", x)
		} else {
			fmt.Printf("0x%02x,", x)
		}
		if i%12 == 11 || i == len(data)-1 {
			fmt.Println()
		}
	}
	fmt.Println("};")
	fmt.Printf("unsigned int %s_len = %d;\n", name, len(data))
	return nil
}

func printColorTable() {
	fmt.Println("hexyl color reference:")
	fmt.Println()
	fmt.Println("\x1b[90m⋄ NULL bytes (0x00)")
	fmt.Println("\x1b[39m\x1b[36ma ASCII printable characters (0x20 - 0x7E)")
	fmt.Println("\x1b[39m\x1b[32m_ ASCII whitespace (0x09 - 0x0D, 0x20)")
	fmt.Println("\x1b[39m\x1b[32m• ASCII control characters (except NULL and whitespace)")
	fmt.Println("\x1b[39m\x1b[33m× Non-ASCII bytes (0x80 - 0xFF)")
	fmt.Print("\x1b[39m")
}

func printCompletion(shell string) {
	switch shell {
	case "bash":
		fmt.Println("_executable() { :; }")
	case "fish":
		fmt.Println("complete -c executable")
	default:
		fmt.Println("# completion for", shell)
	}
}

func printHelp(long bool) {
	fmt.Print(`A command-line hex viewer

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  The file to display. If no FILE argument is given, read from STDIN

Options:
  -n, --length <N>                Only read N bytes from the input. The N argument can
                                  also include a unit with a decimal prefix (kB, MB, ..)
                                  or binary prefix (kiB, MiB, ..), or can be specified
                                  using a hex number. The short option '-l' can be used as
                                  an alias.
                                  Examples: --length=64, --length=4KiB, --length=0xff
                                  [aliases: bytes] [short aliases: c]
  -s, --skip <N>                  Skip the first N bytes of the input. The N argument can
                                  also include a unit (see ` + "`--length`" + ` for details).
                                  A negative value is valid and will seek from the end of
                                  the file.
      --block-size <SIZE>         Sets the size of the ` + "`block`" + ` unit to SIZE.
                                  Examples: --block-size=1024, --block-size=4kB [default:
                                  512]
  -v, --no-squeezing              Displays all input data. Otherwise any number of groups
                                  of output lines which would be identical to the
                                  preceding group of lines, are replaced with a line
                                  comprised of a single asterisk
      --color <WHEN>              When to use colors [default: always] [possible values:
                                  always, auto, never, force]
      --border <STYLE>            Whether to draw a border [default: unicode] [possible
                                  values: unicode, ascii, none]
  -p, --plain                     Display output with --no-characters, --no-position,
                                  --border=none, and --color=never
      --no-characters             Do not show the character panel on the right
  -C, --characters                Show the character panel on the right. This is the
                                  default, unless --no-characters has been specified
      --character-table <FORMAT>  Defines how bytes are mapped to characters [default:
                                  default] [possible values: default, ascii,
                                  codepage-1047, codepage-437, braille]
      --color-scheme <FORMAT>     Defines the color scheme for the characters [default:
                                  default] [possible values: default, gradient]
  -P, --no-position               Whether to display the position panel on the left
  -o, --display-offset <N>        Add N bytes to the displayed file position. The N
                                  argument can also include a unit (see ` + "`--length`" + ` for
                                  details).
                                  A negative value is valid and calculates an offset
                                  relative to the end of the file. [default: 0]
      --panels <N>                Sets the number of hex data panels to be displayed.
                                  ` + "`--panels=auto`" + ` will display the maximum number of hex
                                  data panels based on the current terminal width. By
                                  default, hexyl will show two panels, unless the terminal
                                  is not wide enough for that
  -g, --group-size <N>            Number of bytes/octets that should be grouped together.
                                  You can use the '--endianness' option to control the
                                  ordering of the bytes within a group. '--groupsize' can
                                  be used as an alias (xxd-compatibility) [default: 1]
                                  [possible values: 1, 2, 4, 8]
      --endianness <FORMAT>       Whether to print out groups in little-endian or
                                  big-endian format. This option only has an effect if the
                                  '--group-size' is larger than 1. '-e' can be used as an
                                  alias for '--endianness=little' [default: big] [possible
                                  values: little, big]
  -b, --base <B>                  Sets the base used for the bytes. The possible options
                                  are binary, octal, decimal, and hexadecimal [default:
                                  hexadecimal]
      --terminal-width <N>        Sets the number of terminal columns to be displayed.
                                  Since the terminal width may not be an evenly divisible
                                  by the width per hex data column, this will use the
                                  greatest number of hex data panels that can fit in the
                                  requested width but still leave some space to the right.
                                  Cannot be used with other width-setting options.
      --print-color-table         Print a table showing how different types of bytes are
                                  colored
  -i, --include                   Output in C include file style
      --completion <SHELL>        Show shell completion for a certain shell [possible
                                  values: bash, elvish, fish, powershell, zsh]
  -h, --help                      Print help (see more with '--help')
  -V, --version                   Print version
`)
}
