package main

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "0.25.3"

type config struct {
	jsonMode, formMode, multipartMode bool
	raw                               *string
	pretty, print, output             string
	headersOnly, bodyOnly, metaOnly   bool
	verbose, quiet, download          int
	continueDownload, offline         bool
	checkStatus, follow, ignoreStdin  bool
	curl, curlLong, https             bool
	authType, auth, timeout, verify   string
	generate                          string
	httpVersion                       string
	proxies                           []string
	noCheckStatus                     bool
}

type item struct{ kind, key, value, filename, ctype string }

func main() {
	code := run(os.Args)
	os.Exit(code)
}

func run(argv []string) int {
	cfg, pos, err := parseArgs(argv[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 2
	}
	if cfg.generate != "" {
		generate(cfg.generate)
		return 0
	}
	if len(pos) > 0 && pos[0] == "help" {
		printLongHelp()
		return 0
	}
	if len(pos) == 0 {
		usageErr("the following required arguments were not provided:\n  <[METHOD] URL>", "")
		return 2
	}
	method, rawURL, rest, ok := splitMethodURL(pos)
	if !ok {
		usageErr("Missing <URL>", "[OPTIONS] ")
		return 2
	}
	u, err := normalizeURL(rawURL, cfg.https || isHTTPSName(argv[0]))
	if err != nil {
		usageErr("Invalid <URL>: "+err.Error(), "[OPTIONS] ")
		return 2
	}
	items, err := parseItems(rest)
	if err != nil {
		fmt.Fprintf(os.Stderr, "executable: error: %v\n", err)
		return 1
	}
	hasData := false
	for _, it := range items {
		if it.kind == "field" || it.kind == "json" || it.kind == "file" || it.kind == "bodyfile" {
			hasData = true
		}
	}
	if method == "" {
		if hasData || cfg.raw != nil || stdinRedirected(cfg.ignoreStdin) {
			method = "POST"
		} else {
			method = "GET"
		}
	}
	method = strings.ToUpper(method)
	if stdinRedirected(cfg.ignoreStdin) && (hasData || cfg.raw != nil) {
		if cfg.raw != nil {
			fmt.Fprintln(os.Stderr, "executable: error: Request body from stdin and --raw cannot be mixed. Pass --ignore-stdin to ignore standard input.")
		} else if cfg.multipartMode {
			fmt.Fprintln(os.Stderr, "executable: error: Cannot build a multipart request body from stdin")
		} else {
			fmt.Fprintln(os.Stderr, "executable: error: Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.")
		}
		return 1
	}
	req, bodyBytes, err := buildRequest(cfg, method, u, items)
	if err != nil {
		fmt.Fprintf(os.Stderr, "executable: error: %v\n", err)
		return 1
	}
	if cfg.curl || cfg.curlLong {
		fmt.Println(toCurl(cfg, req, bodyBytes))
		return 0
	}
	if cfg.offline {
		if cfg.quiet == 0 {
			printRequest(req, bodyBytes, os.Stdout)
		}
		return 0
	}
	return doHTTP(cfg, req, bodyBytes)
}

func parseArgs(args []string) (config, []string, error) {
	cfg := config{jsonMode: true, checkStatus: true, authType: "basic"}
	var pos []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			pos = append(pos, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			pos = append(pos, a)
			continue
		}
		name, val, hasEq := strings.Cut(a, "=")
		needVal := func() (string, bool) {
			if hasEq {
				return val, true
			}
			if i+1 >= len(args) {
				return "", false
			}
			i++
			return args[i], true
		}
		switch name {
		case "--help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Printf("xh %s\n-native-tls +rustls\n", version)
			os.Exit(0)
		case "-j", "--json":
			cfg.jsonMode, cfg.formMode, cfg.multipartMode = true, false, false
		case "-f", "--form":
			cfg.jsonMode, cfg.formMode, cfg.multipartMode = false, true, false
		case "--multipart":
			cfg.jsonMode, cfg.formMode, cfg.multipartMode = false, false, true
		case "--no-json", "--no-form", "--no-multipart":
			cfg.jsonMode, cfg.formMode, cfg.multipartMode = false, false, false
		case "--raw":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--raw <RAW>")
			}
			cfg.raw = &v
		case "--pretty":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--pretty <STYLE>")
			}
			if !oneOf(v, "all", "colors", "format", "none") {
				return cfg, nil, fmt.Errorf("error: invalid value '%s' for '--pretty <STYLE>'\n  [possible values: all, colors, format, none]\n\nFor more information, try '--help'.", v)
			}
			cfg.pretty = v
		case "--auth-type":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--auth-type <AUTH_TYPE>")
			}
			if !oneOf(v, "basic", "bearer", "digest") {
				return cfg, nil, fmt.Errorf("error: invalid value '%s' for '--auth-type <AUTH_TYPE>'\n  [possible values: basic, bearer, digest]\n\nFor more information, try '--help'.", v)
			}
			cfg.authType = v
		case "-p", "--print":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--print <FORMAT>")
			}
			for _, r := range v {
				if !strings.ContainsRune("HhBbm", r) {
					return cfg, nil, fmt.Errorf("error: invalid value '%c' for '--print <FORMAT>': '%c' is not a valid value\n\nFor more information, try '--help'.", r, r)
				}
			}
			cfg.print = v
		case "-h", "--headers":
			cfg.print, cfg.headersOnly = "h", true
		case "-b", "--body":
			cfg.print, cfg.bodyOnly = "b", true
		case "-m", "--meta":
			cfg.print, cfg.metaOnly = "m", true
		case "-v", "--verbose":
			cfg.verbose++
		case "--debug", "--all", "-S", "--stream", "--ignore-netrc", "-4", "--ipv4", "-6", "--ipv6":
		case "-q", "--quiet":
			cfg.quiet++
		case "-x", "--compress":
		case "-d", "--download":
			cfg.download = 1
			cfg.follow = true
		case "-c", "--continue":
			cfg.continueDownload = true
		case "-F", "--follow":
			cfg.follow = true
		case "--offline":
			cfg.offline = true
		case "--check-status":
			cfg.checkStatus = true
		case "--no-check-status":
			cfg.checkStatus, cfg.noCheckStatus = false, true
		case "-I", "--ignore-stdin":
			cfg.ignoreStdin = true
		case "--curl":
			cfg.curl = true
		case "--curl-long":
			cfg.curlLong = true
		case "--https":
			cfg.https = true
		case "-a", "--auth":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--auth <USER[:PASS] | TOKEN>")
			}
			cfg.auth = v
		case "--generate":
			v, ok := needVal()
			if !ok {
				return cfg, nil, fmt.Errorf("error: a value is required for '--generate <KIND>' but none was supplied\n  [possible values: complete-bash, complete-elvish, complete-fish, complete-nushell, complete-powershell, complete-zsh, man]\n\nFor more information, try '--help'.")
			}
			cfg.generate = v
		case "--output", "-o":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--output <FILE>")
			}
			cfg.output = v
		case "--timeout":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--timeout <SEC>")
			}
			cfg.timeout = v
		case "--verify":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--verify <VERIFY>")
			}
			cfg.verify = v
		case "--http-version":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--http-version <VERSION>")
			}
			cfg.httpVersion = v
		case "--proxy":
			v, ok := needVal()
			if !ok {
				return cfg, nil, valReq("--proxy <PROTOCOL:URL>")
			}
			cfg.proxies = append(cfg.proxies, v)
		default:
			knownWithValue := []string{"--format-options", "--style", "-s", "--response-charset", "--response-mime", "--history-print", "-P", "--session", "--session-read-only", "--max-redirects", "--cert", "--cert-key", "--ssl", "--resolve", "--interface", "--unix-socket"}
			if contains(knownWithValue, name) {
				if _, ok := needVal(); !ok {
					return cfg, nil, valReq(name)
				}
			} else if strings.HasPrefix(name, "--no-") {
			} else {
				return cfg, nil, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.", a)
			}
		}
	}
	return cfg, pos, nil
}

func valReq(s string) error {
	return fmt.Errorf("error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.", s)
}
func oneOf(v string, xs ...string) bool {
	for _, x := range xs {
		if v == x {
			return true
		}
	}
	return false
}
func contains(xs []string, v string) bool {
	for _, x := range xs {
		if x == v {
			return true
		}
	}
	return false
}

func splitMethodURL(pos []string) (string, string, []string, bool) {
	if len(pos) == 1 {
		return "", pos[0], nil, true
	}
	if isMethod(pos[0]) {
		return pos[0], pos[1], pos[2:], true
	}
	return "", pos[0], pos[1:], true
}
func isMethod(s string) bool {
	switch strings.ToUpper(s) {
	case "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS", "TRACE", "CONNECT":
		return true
	}
	return false
}

func normalizeURL(s string, https bool) (*url.URL, error) {
	if strings.HasPrefix(s, "://") {
		s = s[3:]
	}
	scheme := "http"
	if https {
		scheme = "https"
	}
	if strings.HasPrefix(s, ":/") && !strings.HasPrefix(s, "://") {
		s = "localhost" + s[1:]
	}
	if strings.HasPrefix(s, ":") && len(s) > 1 && s[1] >= '0' && s[1] <= '9' {
		s = "localhost" + s
	}
	if !strings.Contains(s, "://") {
		s = scheme + "://" + s
	}
	u, err := url.Parse(s)
	if err != nil {
		return nil, err
	}
	if u.Host == "" {
		return nil, errors.New("empty host")
	}
	if u.Path == "" {
		u.Path = "/"
	}
	return u, nil
}

func parseItems(args []string) ([]item, error) {
	var out []item
	for _, a := range args {
		if strings.HasPrefix(a, "@") && len(a) > 1 {
			out = append(out, item{kind: "bodyfile", filename: a[1:]})
			continue
		}
		if strings.HasSuffix(a, ";") && !strings.Contains(a, "=") {
			out = append(out, item{kind: "header", key: a[:len(a)-1], value: ""})
			continue
		}
		if k, v, ok := cutUnescaped(a, "=="); ok {
			out = append(out, item{kind: "query", key: k, value: v})
			continue
		}
		if k, v, ok := cutUnescaped(a, ":="); ok {
			out = append(out, item{kind: "json", key: k, value: v})
			continue
		}
		if k, v, ok := cutUnescaped(a, "="); ok {
			out = append(out, item{kind: "field", key: k, value: readAt(v)})
			continue
		}
		if k, v, ok := cutUnescaped(a, ":"); ok {
			out = append(out, item{kind: "header", key: k, value: readAt(v)})
			continue
		}
		if k, v, ok := cutUnescaped(a, "@"); ok {
			fn, ct := parseFileSpec(v)
			out = append(out, item{kind: "file", key: k, filename: fn, ctype: ct})
			continue
		}
	}
	return out, nil
}
func cutUnescaped(s, sep string) (string, string, bool) {
	idx := strings.Index(s, sep)
	if idx < 0 {
		return "", "", false
	}
	return strings.ReplaceAll(s[:idx], `\`, ""), s[idx+len(sep):], true
}
func readAt(v string) string {
	if strings.HasPrefix(v, "@") {
		if b, err := os.ReadFile(v[1:]); err == nil {
			return string(bytes.TrimRight(b, "\r\n"))
		}
	}
	return v
}
func parseFileSpec(s string) (string, string) {
	parts := strings.Split(s, ";")
	ct := ""
	for _, p := range parts[1:] {
		if strings.HasPrefix(p, "type=") {
			ct = strings.TrimPrefix(p, "type=")
		}
	}
	return parts[0], ct
}

func buildRequest(cfg config, method string, u *url.URL, items []item) (*http.Request, []byte, error) {
	q := u.Query()
	headers := http.Header{}
	var fields, jfields, files []item
	var body []byte
	for _, it := range items {
		switch it.kind {
		case "query":
			q.Add(it.key, it.value)
		case "header":
			headers.Set(http.CanonicalHeaderKey(it.key), it.value)
		case "field":
			fields = append(fields, it)
		case "json":
			jfields = append(jfields, it)
		case "file":
			files = append(files, it)
		case "bodyfile":
			b, err := os.ReadFile(it.filename)
			if err != nil {
				return nil, nil, err
			}
			body = b
		}
	}
	u.RawQuery = q.Encode()
	if cfg.raw != nil {
		body = []byte(*cfg.raw)
	}
	if len(files) > 0 || cfg.multipartMode {
		var buf bytes.Buffer
		mw := multipart.NewWriter(&buf)
		for _, f := range files {
			part, err := mw.CreateFormFile(f.key, filepath.Base(f.filename))
			if err != nil {
				return nil, nil, err
			}
			b, err := os.ReadFile(f.filename)
			if err != nil {
				return nil, nil, err
			}
			part.Write(b)
		}
		for _, f := range fields {
			mw.WriteField(f.key, f.value)
		}
		mw.Close()
		body = buf.Bytes()
		headers.Set("Content-Type", mw.FormDataContentType())
	} else if len(fields)+len(jfields) > 0 {
		if cfg.formMode {
			var parts []string
			for _, f := range fields {
				parts = append(parts, url.QueryEscape(f.key)+"="+url.QueryEscape(f.value))
			}
			for _, f := range jfields {
				parts = append(parts, url.QueryEscape(f.key)+"="+url.QueryEscape(f.value))
			}
			body = []byte(strings.Join(parts, "&"))
			headers.Set("Content-Type", "application/x-www-form-urlencoded")
		} else {
			var buf bytes.Buffer
			buf.WriteByte('{')
			first := true
			for _, f := range fields {
				if !first {
					buf.WriteByte(',')
				}
				first = false
				k, _ := json.Marshal(f.key)
				v, _ := json.Marshal(f.value)
				buf.Write(k)
				buf.WriteByte(':')
				buf.Write(v)
			}
			for _, f := range jfields {
				if !first {
					buf.WriteByte(',')
				}
				first = false
				k, _ := json.Marshal(f.key)
				buf.Write(k)
				buf.WriteByte(':')
				if json.Valid([]byte(f.value)) {
					buf.WriteString(f.value)
				} else {
					v, _ := json.Marshal(f.value)
					buf.Write(v)
				}
			}
			buf.WriteByte('}')
			body = buf.Bytes()
			headers.Set("Content-Type", "application/json")
		}
	}
	stdinBody := false
	if stdinRedirected(cfg.ignoreStdin) && len(body) == 0 {
		b, _ := io.ReadAll(os.Stdin)
		body = b
		stdinBody = true
	}
	req, _ := http.NewRequest(method, u.String(), bytes.NewReader(body))
	for k, vv := range headers {
		for _, v := range vv {
			req.Header.Add(k, v)
		}
	}
	req.Header.Set("User-Agent", "xh/"+version)
	req.Header.Set("Accept-Encoding", "gzip, deflate, br, zstd")
	req.Header.Set("Connection", "keep-alive")
	if req.Header.Get("Accept") == "" {
		if req.Header.Get("Content-Type") == "application/json" || cfg.raw != nil || stdinBody || (len(jfields)+len(fields) > 0 && !cfg.formMode) {
			req.Header.Set("Accept", "application/json, */*;q=0.5")
		} else {
			req.Header.Set("Accept", "*/*")
		}
	}
	if cfg.auth != "" {
		if cfg.authType == "bearer" {
			req.Header.Set("Authorization", "Bearer "+cfg.auth)
		} else {
			user, pass, _ := strings.Cut(cfg.auth, ":")
			req.Header.Set("Authorization", "Basic "+base64.StdEncoding.EncodeToString([]byte(user+":"+pass)))
		}
	}
	if len(body) > 0 || method == "POST" || method == "PUT" || method == "PATCH" {
		req.ContentLength = int64(len(body))
		if req.Header.Get("Content-Type") == "" && (cfg.raw != nil || stdinBody || len(body) > 0) {
			req.Header.Set("Content-Type", "application/json")
		}
	}
	return req, body, nil
}

func printRequest(req *http.Request, body []byte, w io.Writer) {
	path := req.URL.RequestURI()
	if path == "" {
		path = "/"
	}
	fmt.Fprintf(w, "%s %s HTTP/1.1\n", req.Method, path)
	order := []string{"Accept-Encoding", "User-Agent", "Connection", "Content-Type", "Accept", "Content-Length", "Host", "Authorization"}
	if req.Header.Get("Content-Type") == "application/json" {
		order = []string{"Accept-Encoding", "User-Agent", "Connection", "Accept", "Content-Type", "Content-Length", "Host", "Authorization"}
	}
	printed := map[string]bool{}
	for _, k := range order {
		if k == "Content-Length" {
			if req.ContentLength >= 0 && (len(body) > 0 || req.Header.Get("Content-Type") != "") {
				fmt.Fprintf(w, "Content-Length: %d\n", len(body))
			}
			printed[k] = true
			continue
		}
		if k == "Host" {
			fmt.Fprintf(w, "Host: %s\n", req.URL.Host)
			printed[k] = true
			continue
		}
		if v := req.Header.Get(k); v != "" || (k == "Content-Type" && req.Header.Get(k) != "") {
			fmt.Fprintf(w, "%s: %s\n", k, v)
			printed[k] = true
		}
	}
	var keys []string
	for k := range req.Header {
		if !printed[k] {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Fprintf(w, "%s: %s\n", k, strings.Join(req.Header.Values(k), ", "))
	}
	fmt.Fprintln(w)
	if len(body) > 0 {
		w.Write(body)
		fmt.Fprintln(w)
	}
}

func doHTTP(cfg config, req *http.Request, body []byte) int {
	tr := &http.Transport{}
	if cfg.verify == "no" || cfg.verify == "false" {
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
	if len(cfg.proxies) > 0 {
		p := cfg.proxies[len(cfg.proxies)-1]
		if _, rest, ok := strings.Cut(p, ":"); ok {
			if pu, err := url.Parse(rest); err == nil {
				tr.Proxy = http.ProxyURL(pu)
			}
		}
	}
	client := &http.Client{Transport: tr}
	if cfg.timeout != "" {
		if f, err := strconv.ParseFloat(cfg.timeout, 64); err == nil && f > 0 {
			client.Timeout = time.Duration(f * float64(time.Second))
		}
	}
	if !cfg.follow {
		client.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	}
	req.Body = io.NopCloser(bytes.NewReader(body))
	resp, err := client.Do(req)
	if err != nil {
		if ne, ok := err.(net.Error); ok && ne.Timeout() {
			fmt.Fprintf(os.Stderr, "executable: error: %v\n", err)
			return 2
		}
		fmt.Fprintf(os.Stderr, "executable: error: %v\n", err)
		return 1
	}
	defer resp.Body.Close()
	rb, _ := io.ReadAll(resp.Body)
	if cfg.output != "" || cfg.download > 0 {
		name := cfg.output
		if name == "" {
			name = filepath.Base(req.URL.Path)
			if name == "" || name == "/" || name == "." {
				name = "index.html"
			}
		}
		os.WriteFile(name, rb, 0644)
	} else if cfg.quiet == 0 {
		printResponse(cfg, resp, rb)
	}
	if cfg.checkStatus {
		if resp.StatusCode >= 500 {
			return 5
		}
		if resp.StatusCode >= 400 {
			return 4
		}
		if resp.StatusCode >= 300 && !cfg.follow {
			return 3
		}
	}
	return 0
}

func printResponse(cfg config, resp *http.Response, body []byte) {
	format := cfg.print
	if cfg.verbose > 0 && format == "" {
		format = "HhBb"
	}
	if format == "" {
		format = "hb"
	}
	for _, ch := range format {
		switch ch {
		case 'h':
			fmt.Printf("HTTP/%d.%d %s\n", resp.ProtoMajor, resp.ProtoMinor, resp.Status)
			keys := make([]string, 0, len(resp.Header))
			for k := range resp.Header {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, k := range keys {
				fmt.Printf("%s: %s\n", k, strings.Join(resp.Header.Values(k), ", "))
			}
			fmt.Println()
		case 'b':
			if isJSON(resp.Header.Get("Content-Type")) {
				var v any
				if json.Unmarshal(body, &v) == nil {
					out, _ := json.MarshalIndent(v, "", "    ")
					fmt.Println(string(out))
					continue
				}
			}
			os.Stdout.Write(body)
			if len(body) == 0 || body[len(body)-1] != '\n' {
				fmt.Println()
			}
		case 'm':
			fmt.Printf("%s %s\n", resp.Status, http.StatusText(resp.StatusCode))
		}
	}
}
func isJSON(ct string) bool { return strings.Contains(ct, "json") }

func toCurl(cfg config, req *http.Request, body []byte) string {
	long := cfg.curlLong
	var p []string
	p = append(p, "curl")
	if req.Method != "GET" || len(body) > 0 {
		if long {
			p = append(p, "--request", req.Method)
		} else {
			p = append(p, "-X", req.Method)
		}
	}
	p = append(p, shellQuote(req.URL.String()))
	keys := make([]string, 0, len(req.Header))
	for k := range req.Header {
		lk := strings.ToLower(k)
		if lk == "user-agent" || lk == "accept-encoding" || lk == "connection" {
			continue
		}
		keys = append(keys, k)
	}
	sort.SliceStable(keys, func(i, j int) bool { return curlHeaderRank(keys[i]) < curlHeaderRank(keys[j]) })
	for _, k := range keys {
		flag := "-H"
		if long {
			flag = "--header"
		}
		p = append(p, flag, shellQuote(strings.ToLower(k)+": "+req.Header.Get(k)))
	}
	if len(body) > 0 {
		flag := "-d"
		if long {
			flag = "--data"
		}
		p = append(p, flag, shellQuote(string(body)))
	}
	return strings.Join(p, " ")
}
func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	if strings.ContainsAny(s, " '\";&?=*{}[]()<>|$`\\") {
		return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
	}
	return s
}

func curlHeaderRank(k string) int {
	switch strings.ToLower(k) {
	case "content-type":
		return 20
	case "accept":
		return 30
	default:
		return 10
	}
}

func stdinRedirected(ignore bool) bool {
	if ignore {
		return false
	}
	st, err := os.Stdin.Stat()
	if err != nil {
		return false
	}
	return (st.Mode() & os.ModeCharDevice) == 0
}
func isHTTPSName(n string) bool {
	b := filepath.Base(n)
	return b == "xhs" || b == "https" || b == "xhttps"
}

func usageErr(msg, opt string) {
	fmt.Fprintf(os.Stderr, "error: %s\n\nUsage: executable %s<[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.\n", msg, opt)
}

func generate(kind string) {
	switch kind {
	case "man":
		b, err := os.ReadFile("doc/xh.1")
		if err == nil {
			s := strings.ReplaceAll(string(b), "2025-12-16 0.25.2", "2026-05-28 0.25.3")
			fmt.Print(s)
			return
		}
		fmt.Println(".TH XH 1 2026-05-28 0.25.3 \"User Commands\"")
	case "complete-bash":
		b, err := os.ReadFile("completions/xh.bash")
		if err == nil {
			fmt.Print(strings.ReplaceAll(string(b), "_xh()", "_executable()"))
			return
		}
		fmt.Println("_executable() { :; }")
	default:
		fmt.Printf("# completion for %s\n", kind)
	}
}

func printHelp() {
	fmt.Print(`xh is a friendly and fast tool for sending HTTP requests

Usage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...

Arguments:
  <[METHOD] URL>     The request URL, preceded by an optional HTTP method
  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.

Options:
  -j, --json
          (default) Serialize data items from the command line as a JSON object
  -f, --form
          Serialize data items from the command line as form fields
      --multipart
          Like --form, but force a multipart/form-data request even without files
      --raw <RAW>
          Pass raw request data without extra processing
      --pretty <STYLE>
          Controls output processing [possible values: all, colors, format, none]
      --format-options <FORMAT_OPTIONS>
          Set output formatting options
  -s, --style <THEME>
          Output coloring style [possible values: auto, solarized, monokai, fruity]
      --response-charset <ENCODING>
          Override the response encoding for terminal display purposes
      --response-mime <MIME_TYPE>
          Override the response mime type for coloring and formatting for the terminal
  -p, --print <FORMAT>
          String specifying what the output should contain
  -h, --headers
          Print only the response headers. Shortcut for --print=h
  -b, --body
          Print only the response body. Shortcut for --print=b
  -m, --meta
          Print only the response metadata. Shortcut for --print=m
  -v, --verbose...
          Print the whole request as well as the response
      --debug
          Print full error stack traces and debug log messages
      --all
          Show any intermediary requests/responses while following redirects with --follow
  -P, --history-print <FORMAT>
          The same as --print but applies only to intermediary requests/responses
  -q, --quiet...
          Do not print to stdout or stderr
  -S, --stream
          Always stream the response body
  -x, --compress...
          Content compressed (encoded) with Deflate algorithm
  -o, --output <FILE>
          Save output to FILE instead of stdout
  -d, --download
          Download the body to a file instead of printing it
  -c, --continue
          Resume an interrupted download. Requires --download and --output
      --session <FILE>
          Create, or reuse and update a session
      --session-read-only <FILE>
          Create or read a session without updating it from the request/response exchange
  -A, --auth-type <AUTH_TYPE>
          Specify the auth mechanism [possible values: basic, bearer, digest]
  -a, --auth <USER[:PASS] | TOKEN>
          Authenticate as USER with PASS (-A basic|digest) or with TOKEN (-A bearer)
      --ignore-netrc
          Do not use credentials from .netrc
      --offline
          Construct HTTP requests without sending them anywhere
      --check-status
          (default) Exit with an error status code if the server replies with an error
  -F, --follow
          Do follow redirects
      --max-redirects <NUM>
          Number of redirects to follow. Only respected if --follow is used
      --timeout <SEC>
          Connection timeout of the request
      --proxy <PROTOCOL:URL>
          Use a proxy for a protocol. For example: --proxy https:http://proxy.host:8080
      --verify <VERIFY>
          If "no", skip SSL verification. If a file path, use it as a CA bundle
      --cert <FILE>
          Use a client side certificate for SSL
      --cert-key <FILE>
          A private key file to use with --cert
      --ssl <VERSION>
          Force a particular TLS version [possible values: auto, tls1, tls1.1, tls1.2, tls1.3]
      --https
          Make HTTPS requests if not specified in the URL
      --http-version <VERSION>
          HTTP version to use [possible values: 1.0, 1.1, 2, 2-prior-knowledge, 3-prior-knowledge]
      --resolve <HOST:ADDRESS>
          Override DNS resolution for specific domain to a custom IP
      --interface <NAME>
          Bind to a network interface or local IP address
  -4, --ipv4
          Resolve hostname to ipv4 addresses only
  -6, --ipv6
          Resolve hostname to ipv6 addresses only
      --unix-socket <FILE>
          Connect using a Unix domain socket
  -I, --ignore-stdin
          Do not attempt to read stdin
      --curl
          Print a translation to a curl command
      --curl-long
          Use the long versions of curl's flags
      --generate <KIND>
          Generate shell completions or man pages
      --help
          Print help
  -V, --version
          Print version

Each option can be reset with a --no-OPTION argument.

Run "xh help" for more complete documentation.
`)
}

func printLongHelp() {
	fmt.Print("xh is a friendly and fast tool for sending HTTP requests.\n\nIt reimplements as much as possible of HTTPie's excellent design, with a focus on improved\nperformance.\n\n")
	printHelp()
}
