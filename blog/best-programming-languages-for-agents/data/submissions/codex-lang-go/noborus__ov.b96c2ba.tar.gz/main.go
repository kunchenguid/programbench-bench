package main

import (
	_ "embed"
	"fmt"
	"io"
	"os"
	"strings"
)

//go:embed helpkey.txt
var helpKeyText string

const versionText = "ov version dev rev:HEAD\n"

const helpText = `ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
`

var longNeedsValue = map[string]bool{
	"caption": true, "column-delimiter": true, "completion": true, "config": true,
	"converter": true, "exit-write-after": true, "exit-write-before": true,
	"filter": true, "header": true, "header-column": true, "hscroll-width": true,
	"jump-target": true, "memory-limit": true, "memory-limit-file": true,
	"multi-color": true, "non-match-filter": true, "notify-eof": true,
	"pattern": true, "ruler": true, "section-delimiter": true, "section-header-num": true,
	"section-start": true, "skip-lines": true, "tab-width": true, "vertical-header": true,
	"view-mode": true, "watch": true,
}

var longBool = map[string]bool{
	"align": true, "alternate-rows": true, "case-sensitive": true, "column-mode": true,
	"column-rainbow": true, "column-width": true, "debug": true, "disable-column-cycle": true,
	"disable-mouse": true, "exec": true, "exit-write": true, "follow-all": true,
	"follow-mode": true, "follow-name": true, "follow-section": true, "force-screen": true,
	"help": true, "help-key": true, "hide-other-section": true, "incsearch": true,
	"line-number": true, "list-view-modes": true, "plain": true, "quit-if-one-screen": true,
	"raw": true, "regexp-search": true, "section-header": true, "set-terminal-title": true,
	"skip-extract": true, "smart-case-sensitive": true, "status-line": true, "version": true,
	"wrap": true,
}

var shortNeedsValue = map[byte]bool{
	'd': true, 'a': true, 'b': true, 'H': true, 'Y': true, 'j': true,
	'M': true, 'x': true, 'y': true, 'm': true, 'T': true,
}

var shortBool = map[byte]bool{
	'l': true, 'C': true, 'i': true, 'c': true, 'e': true, 'X': true,
	'A': true, 'f': true, 'h': true, 'n': true, 'p': true, 'F': true,
	'r': true, 'v': true, 'w': true,
}

func main() {
	args := os.Args[1:]
	if len(args) > 0 && (args[0] == "__complete" || args[0] == "__completeNoDesc") {
		printComplete()
		return
	}

	files, code := parseAndAct(args)
	if code >= 0 {
		os.Exit(code)
	}

	if len(files) == 0 {
		_, _ = io.Copy(os.Stdout, os.Stdin)
		return
	}
	for _, name := range files {
		f, err := os.Open(name)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}
		_, copyErr := io.Copy(os.Stdout, f)
		closeErr := f.Close()
		if copyErr != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", copyErr)
			os.Exit(1)
		}
		if closeErr != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", closeErr)
			os.Exit(1)
		}
		// In redirected output the original emits the first document only.
		break
	}
}

func parseAndAct(args []string) ([]string, int) {
	var files []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			files = append(files, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			files = append(files, a)
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasEq := splitLong(a[2:])
			switch name {
			case "help":
				fmt.Print(helpText)
				return files, 0
			case "help-key":
				fmt.Print(helpKeyText)
				return files, 0
			case "version":
				fmt.Print(versionText)
				return files, 0
			case "list-view-modes":
				fmt.Println("general")
				return files, 0
			case "completion":
				if !hasEq {
					if i+1 >= len(args) {
						fmt.Fprintln(os.Stderr, "Error: flag needs an argument: --completion")
						return files, 1
					}
					i++
					val = args[i]
				}
				if !printCompletion(val) {
					fmt.Fprintln(os.Stderr, "Error: requires one of the arguments bash/zsh/fish/powershell")
					return files, 1
				}
				return files, 0
			case "config":
				if !hasEq {
					if i+1 < len(args) {
						i++
						val = args[i]
					}
				}
				if val != "" && !strings.HasSuffix(val, ".yaml") && !strings.HasSuffix(val, ".yml") {
					fmt.Fprintln(os.Stderr, `failed to read config file: Unsupported Config Type ""`)
				} else if val != "" {
					if f, err := os.Open(val); err != nil {
						fmt.Fprintf(os.Stderr, "failed to read config file: %v\n", err)
					} else {
						_ = f.Close()
					}
				}
				continue
			}
			if longNeedsValue[name] {
				if !hasEq {
					if i+1 >= len(args) {
						fmt.Fprintf(os.Stderr, "Error: flag needs an argument: --%s\n", name)
						return files, 1
					}
					i++
				}
				continue
			}
			if longBool[name] {
				continue
			}
			fmt.Fprintf(os.Stderr, "Error: unknown flag: --%s\n", name)
			return files, 1
		}
		for j := 1; j < len(a); j++ {
			ch := a[j]
			if ch == 'h' {
				fmt.Print(helpText)
				return files, 0
			}
			if ch == 'v' {
				fmt.Print(versionText)
				return files, 0
			}
			if shortNeedsValue[ch] {
				if j+1 < len(a) {
					break
				}
				if i+1 >= len(args) {
					fmt.Fprintf(os.Stderr, "Error: flag needs an argument: -%c\n", ch)
					return files, 1
				}
				i++
				break
			}
			if !shortBool[ch] {
				fmt.Fprintf(os.Stderr, "Error: unknown shorthand flag: '%c' in -%s\n", ch, a[1:])
				return files, 1
			}
		}
	}
	return files, -1
}

func splitLong(s string) (name, val string, hasEq bool) {
	if idx := strings.IndexByte(s, '='); idx >= 0 {
		return s[:idx], s[idx+1:], true
	}
	return s, "", false
}

func printCompletion(shell string) bool {
	switch shell {
	case "bash", "zsh", "fish", "powershell":
		switch shell {
		case "zsh":
			fmt.Println("#compdef ov")
			fmt.Println("compdef _ov ov")
			fmt.Println()
			fmt.Printf("# %s completion for ov                                   -*- shell-script -*-\n", shell)
			fmt.Println()
		case "fish":
			fmt.Printf("# %s completion for ov                                   -*- shell-script -*-\n\n", shell)
			fmt.Println("complete -c ov -f -a '(__fish_complete_path)'")
		case "powershell":
			fmt.Printf("# %s completion for ov                                   -*- shell-script -*-\n\n", shell)
			fmt.Println("Register-ArgumentCompleter -CommandName 'ov' -ScriptBlock {}")
		default:
			fmt.Printf("# %s completion for ov                                   -*- shell-script -*-\n\n", shell)
			fmt.Println("complete -F _ov ov")
		}
		return true
	default:
		return false
	}
}

func printComplete() {
	for _, line := range completionItems {
		fmt.Println(line)
	}
	fmt.Println(":4")
	fmt.Fprintln(os.Stderr, "Completion ended with directive: ShellCompDirectiveNoFileComp")
}

var completionItems = []string{
	"--align\talign the output columns for better readability",
	"--alternate-rows\talternately change the line color",
	"--caption\tcustom caption",
	"--case-sensitive\tcase-sensitive in search",
	"--column-delimiter\tcolumn delimiter `character`",
	"--column-mode\tcolumn mode",
	"--column-rainbow\tcolumn mode to rainbow",
	"--column-width\tcolumn mode for width",
	"--completion\tgenerate completion script [bash|zsh|fish|powershell]",
	"--config\tconfig `file` (default is $XDG_CONFIG_HOME/ov/config.yaml)",
	"--converter\tconverter [es|raw|align]",
	"--debug\tdebug mode",
	"--disable-column-cycle\tdisable column cycling",
	"--disable-mouse\tdisable mouse support",
	"--exec\tcommand execution result instead of file",
	"--exit-write\toutput the current screen when exiting",
	"--exit-write-after\tnumber after the current lines when exiting",
	"--exit-write-before\tnumber before the current lines when exiting",
	"--filter\tfilter search pattern",
	"--follow-all\tfollow multiple files and show the most recently updated one",
	"--follow-mode\tmonitor file and display new content as it is written",
	"--follow-name\tfollow mode to monitor by file name",
	"--follow-section\tsection-by-section follow mode",
	"--force-screen\tdisplay screen even when redirecting output",
	"--header\tnumber of header lines to be displayed constantly",
	"--header-column\tnumber of columns to display as a vertical header",
	"--help\thelp for ov",
	"--help-key\tdisplay key bind information",
	"--hide-other-section\thide other section",
	"--hscroll-width\twidth to scroll horizontally `[int|int%|.int]`",
	"--incsearch\tincremental search",
	"--jump-target\tjump target `[int|int%|.int|'section']`",
	"--line-number\tline number mode",
	"--list-view-modes\tlist available view modes defined in the configuration file",
	"--memory-limit\tnumber of chunks to limit in memory",
	"--memory-limit-file\tnumber of chunks to limit in memory for the file",
	"--multi-color\tcomma separated words(regexp) to color .e.g. \"ERROR,WARNING\"",
	"--non-match-filter\tfilter non match search pattern",
	"--notify-eof\tnotify at the end of the file",
	"--pattern\tsearch pattern",
	"--plain\tdisable original decoration",
	"--quit-if-one-screen\tquit if the output fits on one screen",
	"--raw\traw escape sequences without processing",
	"--regexp-search\tregular expression search",
	"--ruler\tdisplay ruler (=0: none, =1: relative, =2: absolute)",
	"--section-delimiter\t`regexp` for section delimiter .e.g. \"^#\"",
	"--section-header\tenable section-delimiter line as Header",
	"--section-header-num\tnumber of section header lines",
	"--section-start\tsection start position",
	"--set-terminal-title\tset terminal title",
	"--skip-extract\tskip extracting compressed files",
	"--skip-lines\tskip the number of lines",
	"--smart-case-sensitive\tsmart case-sensitive in search",
	"--status-line\tstatus line",
	"--tab-width\ttab stop width",
	"--version\tdisplay version information",
	"--vertical-header\tnumber of characters to display as a vertical header",
	"--view-mode\tapply predefined settings for a specific mode",
	"--watch\twatch mode interval(`seconds`)",
	"--wrap\twrap mode",
}
