module ascii-image-converter-reimplementation

go 1.21
