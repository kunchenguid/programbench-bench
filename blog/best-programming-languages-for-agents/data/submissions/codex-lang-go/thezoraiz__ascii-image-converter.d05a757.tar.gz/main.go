package main

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
)

const (
	version    = "v1.13.1"
	defaultMap = " .:-=+*#%@"
	complexMap = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
)

type intPair struct {
	vals []int
}

func (p *intPair) String() string { return fmt.Sprint(p.vals) }
func (p *intPair) Set(s string) error {
	parts := strings.Split(s, ",")
	p.vals = p.vals[:0]
	for _, part := range parts {
		if part == "" {
			return errors.New("invalid")
		}
		n, err := strconv.Atoi(strings.TrimSpace(part))
		if err != nil {
			return err
		}
		p.vals = append(p.vals, n)
	}
	return nil
}

type config struct {
	color, colorBG, braille, dither, grayscale, complex, full, negative bool
	flipX, flipY, onlySave, formats, help, ver                         bool
	dim, saveBG, fontColor                                             intPair
	width, height, threshold                                           int
	charMap, saveImg, saveTxt, saveGif, font                           string
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	cfg, paths, err := parse(args, stdout)
	if err == flag.ErrHelp {
		return 0
	}
	if err != nil {
		fmt.Fprintf(stderr, "Error: %v\n\n", err)
		return 1
	}
	if cfg.help {
		printHelp(stdout)
		return 0
	}
	if cfg.ver {
		fmt.Fprintln(stdout, version)
		return 0
	}
	if cfg.formats {
		fmt.Fprintln(stdout, "Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF")
		return 0
	}
	if len(cfg.dim.vals) > 0 && (len(cfg.dim.vals) != 2 || cfg.dim.vals[0] <= 0 || cfg.dim.vals[1] <= 0) {
		fmt.Fprintln(stderr, "Error: invalid values for dimensions\n")
		return 1
	}
	if cfg.charMap != "" && len([]rune(cfg.charMap)) < 2 {
		fmt.Fprintln(stderr, "Need at least 2 characters for --map flag\n")
		return 1
	}
	if cfg.threshold == 0 {
		cfg.threshold = 128
	}
	if cfg.threshold < 0 || cfg.threshold > 255 {
		fmt.Fprintln(stderr, "Error: invalid value for threshold\n")
		return 1
	}
	if len(paths) == 0 {
		fmt.Fprintln(stderr, "Error: Need at least 1 input path/url or piped input")
		fmt.Fprintln(stderr, "Use the -h flag for more info\n")
		return 1
	}
	if (cfg.color || cfg.colorBG || cfg.grayscale || len(cfg.fontColor.vals) > 0) && !terminalColorCapable() && cfg.saveImg == "" && cfg.saveGif == "" {
		fmt.Fprintln(stderr, "Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available\n")
		return 1
	}

	status := 0
	for _, path := range paths {
		img, frames, err := loadImage(path, stdin)
		if err != nil {
			fmt.Fprintf(stderr, "Error: %v\n\n", err)
			status = 1
			continue
		}
		_ = frames
		art := render(img, cfg)
		if cfg.saveTxt != "" {
			if err := saveText(cfg.saveTxt, path, art); err != nil {
				fmt.Fprintf(stderr, "Error: %v\n\n", err)
				status = 1
			}
		}
		if cfg.saveImg != "" {
			if err := savePNG(cfg.saveImg, path, art, cfg); err != nil {
				fmt.Fprintf(stderr, "Error: %v\n\n", err)
				status = 1
			}
		}
		if !cfg.onlySave || (cfg.saveTxt == "" && cfg.saveImg == "" && cfg.saveGif == "") {
			fmt.Fprint(stdout, art)
		}
	}
	return status
}

func parse(args []string, out io.Writer) (config, []string, error) {
	var cfg config
	fs := flag.NewFlagSet("ascii-image-converter", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.BoolVar(&cfg.color, "color", false, "")
	fs.BoolVar(&cfg.color, "C", false, "")
	fs.BoolVar(&cfg.colorBG, "color-bg", false, "")
	fs.Var(&cfg.dim, "dimensions", "")
	fs.Var(&cfg.dim, "d", "")
	fs.IntVar(&cfg.width, "width", 0, "")
	fs.IntVar(&cfg.width, "W", 0, "")
	fs.IntVar(&cfg.height, "height", 0, "")
	fs.IntVar(&cfg.height, "H", 0, "")
	fs.StringVar(&cfg.charMap, "map", "", "")
	fs.StringVar(&cfg.charMap, "m", "", "")
	fs.BoolVar(&cfg.braille, "braille", false, "")
	fs.BoolVar(&cfg.braille, "b", false, "")
	fs.IntVar(&cfg.threshold, "threshold", 128, "")
	fs.BoolVar(&cfg.dither, "dither", false, "")
	fs.BoolVar(&cfg.grayscale, "grayscale", false, "")
	fs.BoolVar(&cfg.grayscale, "g", false, "")
	fs.BoolVar(&cfg.complex, "complex", false, "")
	fs.BoolVar(&cfg.complex, "c", false, "")
	fs.BoolVar(&cfg.full, "full", false, "")
	fs.BoolVar(&cfg.full, "f", false, "")
	fs.BoolVar(&cfg.negative, "negative", false, "")
	fs.BoolVar(&cfg.negative, "n", false, "")
	fs.BoolVar(&cfg.flipX, "flipX", false, "")
	fs.BoolVar(&cfg.flipX, "x", false, "")
	fs.BoolVar(&cfg.flipY, "flipY", false, "")
	fs.BoolVar(&cfg.flipY, "y", false, "")
	fs.StringVar(&cfg.saveImg, "save-img", "", "")
	fs.StringVar(&cfg.saveImg, "s", "", "")
	fs.StringVar(&cfg.saveTxt, "save-txt", "", "")
	fs.StringVar(&cfg.saveGif, "save-gif", "", "")
	fs.Var(&cfg.saveBG, "save-bg", "")
	fs.StringVar(&cfg.font, "font", "", "")
	fs.Var(&cfg.fontColor, "font-color", "")
	fs.BoolVar(&cfg.onlySave, "only-save", false, "")
	fs.BoolVar(&cfg.formats, "formats", false, "")
	fs.BoolVar(&cfg.help, "help", false, "")
	fs.BoolVar(&cfg.help, "h", false, "")
	fs.BoolVar(&cfg.ver, "version", false, "")
	fs.BoolVar(&cfg.ver, "v", false, "")
	flagArgs, paths := permuteArgs(args)
	err := fs.Parse(flagArgs)
	if len(paths) == 0 {
		paths = fs.Args()
	}
	return cfg, paths, err
}

func permuteArgs(args []string) ([]string, []string) {
	valueFlags := map[string]bool{
		"-d": true, "--dimensions": true, "-W": true, "--width": true, "-H": true, "--height": true,
		"-m": true, "--map": true, "--threshold": true, "-s": true, "--save-img": true,
		"--save-txt": true, "--save-gif": true, "--save-bg": true, "--font": true, "--font-color": true,
	}
	boolFlags := map[string]bool{
		"-C": true, "--color": true, "--color-bg": true, "-b": true, "--braille": true, "--dither": true,
		"-g": true, "--grayscale": true, "-c": true, "--complex": true, "-f": true, "--full": true,
		"-n": true, "--negative": true, "-x": true, "--flipX": true, "-y": true, "--flipY": true,
		"--only-save": true, "--formats": true, "-h": true, "--help": true, "-v": true, "--version": true,
	}
	var flags, paths []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "--") && strings.Contains(a, "=") {
			name := strings.SplitN(a, "=", 2)[0]
			if valueFlags[name] || boolFlags[name] {
				flags = append(flags, a)
			} else {
				paths = append(paths, a)
			}
			continue
		}
		if valueFlags[a] {
			flags = append(flags, a)
			if i+1 < len(args) {
				i++
				flags = append(flags, args[i])
			}
		} else if boolFlags[a] {
			flags = append(flags, a)
		} else {
			paths = append(paths, a)
		}
	}
	return flags, paths
}

func printHelp(w io.Writer) {
	fmt.Fprint(w, `This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
      --color-bg          If some color flag is passed, use that color on character background instead of foreground
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
  -W, --width int         Set width for ascii art in CHARACTER length
  -H, --height int        Set height for ascii art in CHARACTER length
  -m, --map string        Give custom ascii characters to map against
  -b, --braille           Use braille characters instead of ascii
      --threshold int     Threshold for braille art
      --dither            Apply dithering on image for braille art conversion
  -g, --grayscale         Display grayscale ascii art
  -c, --complex           Display ascii characters in a larger range
  -f, --full              Use largest dimensions for ascii art that fill the terminal width
  -n, --negative          Display ascii art in negative colors
  -x, --flipX             Flip ascii art horizontally
  -y, --flipY             Flip ascii art vertically
  -s, --save-img string   Save ascii art as a .png file
      --save-txt string   Save ascii art as a .txt file
      --save-gif string   If input is a gif, save it as a .gif file
      --formats           Display supported input formats
  -h, --help              Help for ascii-image-converter
  -v, --version           Version for ascii-image-converter
`)
}

func loadImage(path string, stdin io.Reader) (image.Image, []*image.Paletted, error) {
	var data []byte
	var err error
	if path == "-" {
		data, err = io.ReadAll(stdin)
	} else if strings.HasPrefix(path, "http://") || strings.HasPrefix(path, "https://") {
		resp, e := http.Get(path)
		if e != nil {
			return nil, nil, e
		}
		defer resp.Body.Close()
		data, err = io.ReadAll(resp.Body)
	} else {
		data, err = os.ReadFile(path)
		if err != nil {
			return nil, nil, fmt.Errorf("unable to open file: %w", err)
		}
	}
	if err != nil {
		return nil, nil, err
	}
	if g, err := gif.DecodeAll(bytes.NewReader(data)); err == nil && len(g.Image) > 0 {
		return g.Image[0], g.Image, nil
	}
	if img, _, err := image.Decode(bytes.NewReader(data)); err == nil {
		return img, nil, nil
	}
	if img, err := decodeBMP(data); err == nil {
		return img, nil, nil
	}
	return nil, nil, errors.New("unsupported image format")
}

func render(src image.Image, cfg config) string {
	b := src.Bounds()
	w, h := dimensions(b.Dx(), b.Dy(), cfg)
	if cfg.braille {
		return renderBraille(src, w, h, cfg)
	}
	chars := defaultMap
	if cfg.complex {
		chars = complexMap
	}
	if cfg.charMap != "" {
		chars = cfg.charMap
	}
	runes := []rune(chars)
	var out strings.Builder
	for y := 0; y < h; y++ {
		yy := y
		if cfg.flipY {
			yy = h - 1 - y
		}
		for x := 0; x < w; x++ {
			xx := x
			if cfg.flipX {
				xx = w - 1 - x
			}
			l := sampleLum(src, xx, yy, w, h)
			if cfg.negative {
				l = 255 - l
			}
			idx := int(l) * len(runes) / 256
			if idx >= len(runes) {
				idx = len(runes) - 1
			}
			ch := runes[idx]
			if cfg.color || cfg.grayscale || len(cfg.fontColor.vals) > 0 {
				r, g, bl := sampleRGB(src, xx, yy, w, h)
				if cfg.negative {
					r, g, bl = 255-r, 255-g, 255-bl
				}
				if cfg.grayscale {
					r = l
					g = l
					bl = l
				}
				if len(cfg.fontColor.vals) == 3 && !cfg.color && !cfg.grayscale {
					r, g, bl = uint8(cfg.fontColor.vals[0]), uint8(cfg.fontColor.vals[1]), uint8(cfg.fontColor.vals[2])
				}
				if cfg.colorBG {
					fmt.Fprintf(&out, "\x1b[48;2;%d;%d;%dm%c\x1b[0m", r, g, bl, ch)
				} else {
					fmt.Fprintf(&out, "\x1b[38;2;%d;%d;%dm%c\x1b[0m", r, g, bl, ch)
				}
			} else {
				out.WriteRune(ch)
			}
		}
		out.WriteByte('\n')
	}
	return out.String()
}

func dimensions(sw, sh int, cfg config) (int, int) {
	if len(cfg.dim.vals) == 2 {
		return cfg.dim.vals[0], cfg.dim.vals[1]
	}
	if cfg.full {
		cfg.width = 80
	}
	if cfg.width > 0 {
		h := int(math.Round(float64(cfg.width) * float64(sh) / float64(sw) * 0.5))
		if h < 1 {
			h = 1
		}
		return cfg.width, h
	}
	if cfg.height > 0 {
		w := int(math.Round(float64(cfg.height) * float64(sw) / float64(sh) * 2.0))
		if w < 1 {
			w = 1
		}
		return w, cfg.height
	}
	w := 80
	h := int(math.Round(float64(w) * float64(sh) / float64(sw) * 0.5))
	if h < 1 {
		h = 1
	}
	return w, h
}

func sampleLum(src image.Image, x, y, w, h int) uint8 {
	r, g, b := sampleRGB(src, x, y, w, h)
	return uint8((299*int(r) + 587*int(g) + 114*int(b)) / 1000)
}

func sampleRGB(src image.Image, x, y, w, h int) (uint8, uint8, uint8) {
	sb := src.Bounds()
	x0 := sb.Min.X + int(float64(x)*float64(sb.Dx())/float64(w))
	x1 := sb.Min.X + int(float64(x+1)*float64(sb.Dx())/float64(w))
	y0 := sb.Min.Y + int(float64(y)*float64(sb.Dy())/float64(h))
	y1 := sb.Min.Y + int(float64(y+1)*float64(sb.Dy())/float64(h))
	if x1 <= x0 {
		x1 = x0 + 1
	}
	if y1 <= y0 {
		y1 = y0 + 1
	}
	var rs, gs, bs, as uint64
	for yy := y0; yy < y1 && yy < sb.Max.Y; yy++ {
		for xx := x0; xx < x1 && xx < sb.Max.X; xx++ {
			r, g, b, a := src.At(xx, yy).RGBA()
			rs += uint64(r >> 8)
			gs += uint64(g >> 8)
			bs += uint64(b >> 8)
			as += uint64(a >> 8)
		}
	}
	n := uint64((min(x1, sb.Max.X) - x0) * (min(y1, sb.Max.Y) - y0))
	if n == 0 {
		return 0, 0, 0
	}
	if as == 0 {
		return 255, 255, 255
	}
	return uint8(rs / n), uint8(gs / n), uint8(bs / n)
}

func renderBraille(src image.Image, w, h int, cfg config) string {
	dots := [4][2]int{{1, 8}, {2, 16}, {4, 32}, {64, 128}}
	var out strings.Builder
	for cy := 0; cy < h; cy++ {
		yy := cy
		if cfg.flipY {
			yy = h - 1 - cy
		}
		for cx := 0; cx < w; cx++ {
			xx := cx
			if cfg.flipX {
				xx = w - 1 - cx
			}
			mask := 0
			for py := 0; py < 4; py++ {
				for px := 0; px < 2; px++ {
					l := sampleLum(src, xx*2+px, yy*4+py, w*2, h*4)
					if cfg.negative {
						l = 255 - l
					}
					if int(l) >= cfg.threshold {
						mask += dots[py][px]
					}
				}
			}
			out.WriteRune(rune(0x2800 + mask))
		}
		out.WriteByte('\n')
	}
	return out.String()
}

func saveText(dir, input, art string) error {
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	name := strings.TrimSuffix(filepath.Base(input), filepath.Ext(input)) + "-ascii-art.txt"
	return os.WriteFile(filepath.Join(dir, name), []byte(art), 0644)
}

func savePNG(dir, input, art string, cfg config) error {
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	lines := strings.Split(strings.TrimRight(art, "\n"), "\n")
	width := 1
	for _, line := range lines {
		if n := len([]rune(stripANSI(line))); n > width {
			width = n
		}
	}
	cellW, cellH := 8, 14
	img := image.NewRGBA(image.Rect(0, 0, width*cellW, max(1, len(lines))*cellH))
	bg := color.RGBA{0, 0, 0, 100}
	if len(cfg.saveBG.vals) == 4 {
		bg = color.RGBA{uint8(cfg.saveBG.vals[0]), uint8(cfg.saveBG.vals[1]), uint8(cfg.saveBG.vals[2]), uint8(cfg.saveBG.vals[3])}
	}
	draw.Draw(img, img.Bounds(), &image.Uniform{bg}, image.Point{}, draw.Src)
	fg := color.RGBA{255, 255, 255, 255}
	if len(cfg.fontColor.vals) == 3 {
		fg = color.RGBA{uint8(cfg.fontColor.vals[0]), uint8(cfg.fontColor.vals[1]), uint8(cfg.fontColor.vals[2]), 255}
	}
	for y, line := range lines {
		for x, ch := range stripANSI(line) {
			if ch == ' ' {
				continue
			}
			drawGlyph(img, x*cellW, y*cellH, fg)
		}
	}
	name := strings.TrimSuffix(filepath.Base(input), filepath.Ext(input)) + "-ascii-art.png"
	f, err := os.Create(filepath.Join(dir, name))
	if err != nil {
		return err
	}
	defer f.Close()
	return png.Encode(f, img)
}

func drawGlyph(img *image.RGBA, x, y int, c color.RGBA) {
	for yy := y + 3; yy < y+11 && yy < img.Bounds().Max.Y; yy++ {
		for xx := x + 1; xx < x+7 && xx < img.Bounds().Max.X; xx++ {
			if xx == x+1 || xx == x+6 || yy == y+3 || yy == y+10 {
				img.SetRGBA(xx, yy, c)
			}
		}
	}
}

func stripANSI(s string) string {
	var b strings.Builder
	inEsc := false
	for i := 0; i < len(s); i++ {
		if s[i] == 0x1b {
			inEsc = true
			continue
		}
		if inEsc {
			if (s[i] >= 'A' && s[i] <= 'Z') || (s[i] >= 'a' && s[i] <= 'z') {
				inEsc = false
			}
			continue
		}
		b.WriteByte(s[i])
	}
	return b.String()
}

func terminalColorCapable() bool {
	return os.Getenv("COLORTERM") != "" || strings.Contains(os.Getenv("TERM"), "256color") || strings.Contains(os.Getenv("TERM"), "truecolor")
}

func decodeBMP(data []byte) (image.Image, error) {
	if len(data) < 54 || string(data[:2]) != "BM" {
		return nil, errors.New("not bmp")
	}
	off := int(binary.LittleEndian.Uint32(data[10:14]))
	w := int(int32(binary.LittleEndian.Uint32(data[18:22])))
	hRaw := int(int32(binary.LittleEndian.Uint32(data[22:26])))
	bpp := int(binary.LittleEndian.Uint16(data[28:30]))
	if w <= 0 || hRaw == 0 || (bpp != 24 && bpp != 32) {
		return nil, errors.New("unsupported bmp")
	}
	topDown := hRaw < 0
	h := hRaw
	if h < 0 {
		h = -h
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	stride := ((w*bpp + 31) / 32) * 4
	for y := 0; y < h; y++ {
		sy := h - 1 - y
		if topDown {
			sy = y
		}
		row := off + sy*stride
		for x := 0; x < w; x++ {
			i := row + x*(bpp/8)
			if i+2 >= len(data) {
				return nil, errors.New("truncated bmp")
			}
			a := uint8(255)
			if bpp == 32 && i+3 < len(data) {
				a = data[i+3]
			}
			img.SetRGBA(x, y, color.RGBA{data[i+2], data[i+1], data[i], a})
		}
	}
	return img, nil
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func init() {
	image.RegisterFormat("jpeg", "\xff\xd8", jpeg.Decode, jpeg.DecodeConfig)
	image.RegisterFormat("png", "\x89PNG\r\n\x1a\n", png.Decode, png.DecodeConfig)
	image.RegisterFormat("gif", "GIF8?a", gif.Decode, gif.DecodeConfig)
	_ = bufio.ErrInvalidUnreadByte
}
