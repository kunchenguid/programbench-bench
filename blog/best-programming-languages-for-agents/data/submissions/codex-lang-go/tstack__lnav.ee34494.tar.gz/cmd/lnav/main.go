package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

const version = "lnav 0.14.0-07efb63"

type options struct {
	headless bool
	quiet    bool
	noSyslog bool
	recurse  bool
	tstamp   bool
	check    bool
	warn     bool
	helpText bool
	install  bool
	manage   bool
	since    string
	until    string
	debug    string
	configs  []string
	cmds     []string
	files    []string
}

type logLine struct {
	text string
	when time.Time
	has  bool
	seq  int
}

var tsPatterns = []struct {
	re     *regexp.Regexp
	layout []string
}{
	{regexp.MustCompile(`^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?`), []string{
		time.RFC3339Nano, "2006-01-02 15:04:05.999999999Z07:00", "2006-01-02 15:04:05Z07:00",
		"2006-01-02T15:04:05.999999999-0700", "2006-01-02T15:04:05-0700",
		"2006-01-02 15:04:05.999999999", "2006-01-02 15:04:05", "2006-01-02T15:04:05.999999999", "2006-01-02T15:04:05",
	}},
	{regexp.MustCompile(`^\d{4}-\d{2}-\d{2}`), []string{"2006-01-02"}},
	{regexp.MustCompile(`^[A-Z][a-z]{2} [ 0-9]\d \d{2}:\d{2}:\d{2}`), []string{"Jan _2 15:04:05", "Jan 02 15:04:05"}},
}

func main() {
	opts, code := parse(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}

	if opts.helpText {
		if !opts.headless && !stdoutTTY() {
			uiError()
			os.Exit(1)
		}
		printInternalHelp()
		return
	}
	if opts.check || opts.warn || opts.install || opts.manage {
		return
	}
	if opts.debug != "" {
		_ = os.WriteFile(opts.debug, []byte(""), 0644)
	}

	if len(opts.cmds) > 0 {
		for _, c := range opts.cmds {
			if strings.HasPrefix(c, "|") {
				runCommandFile(strings.TrimPrefix(c, "|"), &opts)
			}
		}
	}
	if len(opts.files) == 0 && !opts.noSyslog && stdinTTY() && !opts.headless {
		if !stdoutTTY() {
			uiError()
			os.Exit(1)
		}
		return
	}
	if !opts.headless && !stdoutTTY() {
		uiError()
		os.Exit(1)
	}

	if err := runHeadless(opts); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parse(args []string) (options, int) {
	args = expandShortOptions(args)
	var opts options
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opts.files = append(opts.files, args[i+1:]...)
			break
		}
		switch a {
		case "-h", "--help":
			printUsage()
			return opts, 0
		case "-V", "--version":
			fmt.Println(version)
			return opts, 0
		case "-H":
			opts.helpText = true
		case "-n":
			opts.headless = true
		case "-N":
			opts.noSyslog = true
		case "-q":
			opts.quiet = true
		case "-r":
			opts.recurse = true
		case "-R", "-u":
		case "-W":
			opts.warn = true
		case "-C":
			opts.check = true
		case "-i":
			opts.install = true
		case "-m":
			opts.manage = true
		case "-t":
			opts.tstamp = true
		case "-I", "-d", "-c", "-f", "-e", "-S", "--since", "-U", "--until":
			if i+1 >= len(args) {
				name := a
				kind := "ARG"
				if a == "-d" {
					kind = "FILE"
				}
				fmt.Fprintf(os.Stderr, "  error: invalid command-line arguments\n reason: %s: 1 required %s missing\n", name, kind)
				return opts, 114
			}
			i++
			v := args[i]
			switch a {
			case "-I":
				opts.configs = append(opts.configs, v)
			case "-d":
				opts.debug = v
			case "-c":
				opts.cmds = append(opts.cmds, v)
			case "-f":
				opts.cmds = append(opts.cmds, "|"+v)
			case "-e":
				opts.cmds = append(opts.cmds, "$"+v)
			case "-S", "--since":
				opts.since = v
			case "-U", "--until":
				opts.until = v
			}
		default:
			if strings.HasPrefix(a, "--since=") {
				opts.since = strings.TrimPrefix(a, "--since=")
				continue
			}
			if strings.HasPrefix(a, "--until=") {
				opts.until = strings.TrimPrefix(a, "--until=")
				continue
			}
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "  error: invalid command-line arguments\n reason: The following argument was not expected: %s\n", a)
				return opts, 109
			}
			opts.files = append(opts.files, a)
		}
	}
	return opts, -1
}

func expandShortOptions(args []string) []string {
	var out []string
	noArg := "hVHnNqrRuWCitm"
	withArg := "IdcfeSU"
	for _, a := range args {
		if !strings.HasPrefix(a, "-") || strings.HasPrefix(a, "--") || len(a) <= 2 {
			out = append(out, a)
			continue
		}
		body := a[1:]
		ok := true
		for i, r := range body {
			if strings.ContainsRune(noArg, r) {
				continue
			}
			if strings.ContainsRune(withArg, r) {
				if i == len(body)-1 {
					continue
				}
				out = append(out, "-"+string(r), body[i+1:])
				ok = false
				break
			}
			ok = false
			break
		}
		if !ok {
			if len(out) > 0 && (out[len(out)-1] == "-"+string(body[0])) {
				continue
			}
			out = append(out, a)
			continue
		}
		for _, r := range body {
			out = append(out, "-"+string(r))
		}
	}
	return out
}

func runHeadless(opts options) error {
	var lines []logLine
	seq := 0
	for _, c := range opts.cmds {
		if strings.HasPrefix(c, "$") {
			out, _ := exec.Command("bash", "-lc", strings.TrimPrefix(c, "$")).CombinedOutput()
			if !opts.quiet {
				os.Stdout.Write(out)
			}
		}
	}
	if !stdinTTY() {
		readLines(os.Stdin, opts.tstamp, &lines, &seq)
	}
	for _, path := range opts.files {
		paths, err := expandPath(path, opts.recurse)
		if err != nil {
			return fmt.Errorf("  error: unable to open file: %s\n reason: %s", path, err)
		}
		for _, p := range paths {
			f, err := os.Open(p)
			if err != nil {
				return fmt.Errorf("  error: unable to open file: %s\n reason: %s", p, err)
			}
			readLines(f, false, &lines, &seq)
			f.Close()
		}
	}
	sort.SliceStable(lines, func(i, j int) bool {
		if lines[i].has && lines[j].has {
			return lines[i].when.Before(lines[j].when)
		}
		if lines[i].has != lines[j].has {
			return lines[i].has
		}
		return lines[i].seq < lines[j].seq
	})
	lines = filterByTime(lines, opts.since, opts.until)
	start := 0
	for _, c := range opts.cmds {
		if strings.HasPrefix(c, ":goto ") {
			var n int
			fmt.Sscanf(strings.TrimSpace(strings.TrimPrefix(c, ":goto ")), "%d", &n)
			if n > 0 && n < len(lines) {
				start = n
			}
		} else if strings.HasPrefix(c, ";") {
			query := strings.TrimPrefix(c, ";")
			fmt.Fprintf(os.Stderr, "  error: failed to compile SQL statement\n reason: no such table: logline\n --> command-option:1\n | %s\n", query)
		} else if strings.HasPrefix(c, ":write-to") {
			fmt.Fprintln(os.Stderr, "  error: no lines marked to write, use 'm' to mark lines")
			fmt.Fprintf(os.Stderr, " --> command-option:1\n | %-40s\n = help: :write-to [--anonymize] path\n", c)
		}
	}
	if opts.quiet {
		return nil
	}
	var buf bytes.Buffer
	for _, l := range lines[start:] {
		buf.WriteString(l.text)
		if !strings.HasSuffix(l.text, "\n") {
			buf.WriteByte('\n')
		}
	}
	_, err := io.Copy(os.Stdout, &buf)
	return err
}

func filterByTime(lines []logLine, sinceText, untilText string) []logLine {
	if sinceText == "" && untilText == "" {
		return lines
	}
	since, hasSince := parseUserTime(sinceText)
	until, hasUntil := parseUserTime(untilText)
	if !hasSince && !hasUntil {
		return lines
	}
	out := lines[:0]
	for _, l := range lines {
		if l.has {
			if hasSince && l.when.Before(since) {
				continue
			}
			if hasUntil && l.when.After(until) {
				continue
			}
		}
		out = append(out, l)
	}
	return out
}

func parseUserTime(s string) (time.Time, bool) {
	if s == "" {
		return time.Time{}, false
	}
	if t, ok := parseTime(s); ok {
		return t, true
	}
	layouts := []string{"2006-01-02 15:04", "2006-01-02T15:04", "2006-01-02"}
	for _, layout := range layouts {
		if t, err := time.ParseInLocation(layout, s, time.Local); err == nil {
			return t, true
		}
	}
	return time.Time{}, false
}

func expandPath(path string, recurse bool) ([]string, error) {
	st, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if !st.IsDir() {
		return []string{path}, nil
	}
	var out []string
	walk := func(p string, d os.DirEntry, err error) error {
		if err != nil || p == path {
			return nil
		}
		if d.IsDir() {
			if !recurse {
				return filepath.SkipDir
			}
			return nil
		}
		name := d.Name()
		if strings.HasSuffix(name, ".log") || strings.HasSuffix(name, ".log.1") || !strings.Contains(name, ".") {
			out = append(out, p)
		}
		return nil
	}
	filepath.WalkDir(path, walk)
	sort.Strings(out)
	return out, nil
}

func readLines(r io.Reader, stamp bool, lines *[]logLine, seq *int) {
	sc := bufio.NewScanner(r)
	for sc.Scan() {
		text := sc.Text()
		if stamp {
			text = time.Now().Format("2006-01-02T15:04:05.000000-0700") + " " + text
		}
		when, has := parseTime(text)
		*lines = append(*lines, logLine{text: text, when: when, has: has, seq: *seq})
		*seq = *seq + 1
	}
}

func parseTime(s string) (time.Time, bool) {
	for _, p := range tsPatterns {
		m := p.re.FindString(s)
		if m == "" {
			continue
		}
		if strings.Contains(m, " ") && len(m) >= 19 && m[10] == ' ' && !strings.ContainsAny(m[19:], "Z+-") {
			for _, layout := range p.layout {
				if t, err := time.ParseInLocation(layout, m, time.Local); err == nil {
					return t, true
				}
			}
		}
		for _, layout := range p.layout {
			if t, err := time.Parse(layout, m); err == nil {
				if strings.HasPrefix(layout, "Jan") {
					t = t.AddDate(time.Now().Year(), 0, 0)
				}
				return t, true
			}
		}
	}
	return time.Time{}, false
}

func runCommandFile(name string, opts *options) {
	var b []byte
	var err error
	if name == "-" {
		b, err = io.ReadAll(os.Stdin)
	} else {
		b, err = os.ReadFile(name)
	}
	if err != nil {
		return
	}
	sc := bufio.NewScanner(bytes.NewReader(b))
	for sc.Scan() {
		s := strings.TrimSpace(sc.Text())
		if s != "" && !strings.HasPrefix(s, "#") {
			opts.cmds = append(opts.cmds, s)
		}
	}
}

func stdinTTY() bool {
	st, _ := os.Stdin.Stat()
	return (st.Mode() & os.ModeCharDevice) != 0
}

func stdoutTTY() bool {
	st, _ := os.Stdout.Stat()
	return (st.Mode() & os.ModeCharDevice) != 0
}

func uiError() {
	fmt.Fprintln(os.Stderr, "  error: unable to display interactive text UI")
	fmt.Fprintln(os.Stderr, " reason: stdout is not a TTY")
	fmt.Fprintln(os.Stderr, " = help: pass the -n option to run lnav in headless mode or don't redirect stdout")
}

func printUsage() {
	fmt.Printf(`usage: %s [options] [logfile1 logfile2 ...]

A log file viewer for the terminal that indexes log messages to
make it easier to navigate through files quickly.

Key Bindings
  ?    View/leave the online help text.
  q    Quit the program.

Options
  -h         Print this message, then exit.
  -H         Display the internal help text.

  -I dir     An additional configuration directory.
  -W         Print warnings related to lnav's configuration.
  -u         Update formats installed from git repositories.
  -d file    Write debug messages to the given file.
  -V         Print version information.

  -S,--since Only index log content since this time.
  -U,--until Only index log content until this time.
  -r         Recursively load files from the given directory hierarchies.
  -R         Load older rotated log files as well.
  -c cmd     Execute a command after the files have been loaded.
  -f file    Execute the commands in the given file.
  -e cmd     Execute a shell command-line.
  -t         Treat data piped into standard in as a log file.
  -n         Run without the curses UI. (headless mode)
  -N         Do not open the default syslog file if no files are given.
  -q         Do not print informational messages.

Optional arguments
  logfileN   The log files, directories, or remote paths to view.
             If a directory is given, all of the files in the
             directory will be loaded.

Management-Mode Options
  -i         Install the given format files and exit.  Pass 'extra'
             to install the default set of third-party formats.
  -m         Switch to the management command-line mode.  This mode
             is used to work with lnav's configuration.

Examples
 • To load and follow the syslog file:
     $ lnav                                  

 • To load all of the files in /var/log:
     $ lnav /var/log                         

 • To watch the output of make:
     $ lnav -e 'make -j4'                    

Paths
 • This binary:
    🧭 %s
 • Format files are read from:
    📂 /etc/lnav
    📂 /usr/etc/lnav
 • Configuration, session, and format files are stored in:
    📂 %s/.lnav

 • Local copies of remote files, files extracted from
   archives, execution output, and so on are stored in:
    📂 /tmp/lnav-user-%d-work

Documentation: https://docs.lnav.org
Contact
  💬 https://github.com/tstack/lnav/discussions
  📫 lnav@googlegroups.com
Version: %s
`, os.Args[0], absArg0(), os.Getenv("HOME"), os.Getuid(), version)
}

func absArg0() string {
	if p, err := filepath.Abs(os.Args[0]); err == nil {
		return p
	}
	return os.Args[0]
}

func printInternalHelp() {
	fmt.Println(`lnav 0.14.0

A fancy log file viewer for the terminal.

Overview

The Logfile Navigator, lnav, is an enhanced log file viewer that takes
advantage of any semantic information that can be gleaned from the
files being viewed, such as timestamps and log levels. Using this
extra semantic information, lnav can interleave messages from different
files, generate histograms of messages over time, and provide hotkeys
for navigating through the file.

Opening Paths/URLs

The main arguments to lnav are the local/remote files, directories,
glob patterns, or URLs to be viewed. If no arguments are given, the
default syslog file for your system will be opened.

Options

 •  -r  Recursively load files from the given directory hierarchies.
 •  -R  Load older rotated log files as well.
 •  -c cmd  Execute a command, query, or file after loading.
 •  -f file Execute commands from a file.
 •  -n  Run without the interactive text UI.

Display

The main part of the display shows the log lines from the files
interleaved based on time-of-day. New lines are automatically loaded as
they are appended to the files.
`)
}
