module cleanroom-lnav

go 1.21
