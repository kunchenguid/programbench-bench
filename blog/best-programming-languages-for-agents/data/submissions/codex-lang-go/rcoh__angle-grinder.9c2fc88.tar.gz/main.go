package main

import (
	"bufio"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type Row struct {
	Raw    string
	Fields map[string]any
}

var tableOrder []string

func main() {
	file := flag.String("file", "", "")
	flag.StringVar(file, "f", "", "")
	out := flag.String("output", "legacy", "")
	flag.StringVar(out, "o", "legacy", "")
	format := flag.String("format", "", "")
	flag.StringVar(format, "m", "", "")
	aliasDir := flag.String("alias-dir", "", "")
	flag.StringVar(aliasDir, "a", "", "")
	noAlias := flag.Bool("no-alias", false, "")
	version := flag.Bool("version", false, "")
	flag.BoolVar(version, "V", false, "")
	_ = aliasDir
	_ = noAlias
	flag.Usage = usage
	flag.Parse()
	if *version {
		fmt.Println("ag 0.19.6")
		return
	}
	if *format != "" {
		*out = "format=" + *format
	}
	query := "*"
	if flag.NArg() > 0 {
		query = flag.Arg(0)
	}
	if !*noAlias {
		query = expandAliases(query, *aliasDir)
	}
	var r io.Reader = os.Stdin
	if *file != "" {
		f, err := os.Open(*file)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: %v\n", err)
			os.Exit(1)
		}
		defer f.Close()
		r = f
	}
	rows := readRows(r)
	rows = runQuery(rows, query)
	render(rows, *out)
}

func usage() {
	fmt.Fprintf(os.Stdout, "Usage: executable [OPTIONS] [QUERY]\n\nArguments:\n  [QUERY]  The query\n\nOptions:\n  -f, --file <FILE>            Optionally reads from a file instead of Stdin\n  -m, --format <FORMAT>        DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output\n  -o, --output <OUTPUT>        Set output format. One of (json|legacy|format=<rust fmt str>|logfmt)\n  -a, --alias-dir <ALIAS_DIR>  Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.\n      --no-alias               Disables aliases\n  -h, --help                   Print help (see more with '--help')\n  -V, --version                Print version\n\nFor more details + docs, see https://github.com/rcoh/angle-grinder\n")
}

func readRows(r io.Reader) []Row {
	var rows []Row
	sc := bufio.NewScanner(r)
	buf := make([]byte, 1024*1024)
	sc.Buffer(buf, 32*1024*1024)
	for sc.Scan() {
		rows = append(rows, Row{Raw: sc.Text(), Fields: map[string]any{}})
	}
	return rows
}

func runQuery(rows []Row, q string) []Row {
	tableOrder = nil
	parts := splitTop(q, '|')
	if len(parts) == 0 {
		return rows
	}
	filter := strings.TrimSpace(parts[0])
	rows = applyFilter(rows, filter)
	for _, p := range parts[1:] {
		op := strings.TrimSpace(p)
		if op == "" {
			continue
		}
		switch {
		case op == "json" || strings.HasPrefix(op, "json from "):
			rows = opJSON(rows, strings.TrimSpace(strings.TrimPrefix(op, "json from ")), op == "json")
		case op == "logfmt" || strings.HasPrefix(op, "logfmt from "):
			rows = opLogfmt(rows, strings.TrimSpace(strings.TrimPrefix(op, "logfmt from ")), op == "logfmt")
		case strings.HasPrefix(op, "parse regex "):
			rows = opParseRegex(rows, op)
		case strings.HasPrefix(op, "parse "):
			rows = opParse(rows, op)
		case strings.HasPrefix(op, "split"):
			rows = opSplit(rows, op)
		case strings.HasPrefix(op, "fields"):
			rows = opFields(rows, op)
		case strings.HasPrefix(op, "where "):
			rows = opWhere(rows, strings.TrimSpace(strings.TrimPrefix(op, "where ")))
		case strings.HasPrefix(op, "limit "):
			rows = opLimit(rows, op)
		case strings.HasPrefix(op, "total("):
			rows = opTotal(rows, op)
		case strings.HasPrefix(op, "sort by "):
			rows = opSort(rows, op)
		case strings.Contains(op, " as ") && !isAggregate(op):
			rows = opExpr(rows, op)
		case isAggregate(op):
			rows = opAggregate(rows, op)
		}
	}
	return rows
}

func expandAliases(query, aliasDir string) string {
	aliases := loadAliases(aliasDir)
	if len(aliases) == 0 {
		return query
	}
	parts := splitTop(query, '|')
	for i, p := range parts {
		key := strings.TrimSpace(p)
		if v, ok := aliases[key]; ok {
			parts[i] = v
		}
	}
	return strings.Join(parts, " | ")
}

func loadAliases(aliasDir string) map[string]string {
	res := map[string]string{}
	dirs := []string{}
	if aliasDir != "" {
		dirs = append(dirs, aliasDir)
	} else {
		wd, _ := os.Getwd()
		for {
			dirs = append(dirs, wd+"/.agrind-aliases")
			parent := strings.TrimRight(wd, "/")
			idx := strings.LastIndex(parent, "/")
			if idx <= 0 {
				break
			}
			wd = parent[:idx]
		}
	}
	for _, d := range dirs {
		ents, err := os.ReadDir(d)
		if err != nil {
			continue
		}
		for _, e := range ents {
			if e.IsDir() {
				continue
			}
			b, err := os.ReadFile(d + "/" + e.Name())
			if err == nil {
				k, v := parseAliasFile(string(b))
				if k != "" {
					res[k] = v
				}
			}
		}
	}
	return res
}

func parseAliasFile(s string) (string, string) {
	key, tmpl := "", ""
	lines := strings.Split(s, "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if strings.HasPrefix(line, "keyword") {
			if eq := strings.Index(line, "="); eq >= 0 {
				key = unquote(strings.TrimSpace(line[eq+1:]))
			}
		}
		if strings.HasPrefix(line, "template") {
			if strings.Contains(line, `"""`) {
				after := line[strings.Index(line, `"""`)+3:]
				var parts []string
				if j := strings.Index(after, `"""`); j >= 0 {
					tmpl = after[:j]
				} else {
					parts = append(parts, after)
					for i++; i < len(lines); i++ {
						if j := strings.Index(lines[i], `"""`); j >= 0 {
							parts = append(parts, lines[i][:j])
							break
						}
						parts = append(parts, lines[i])
					}
					tmpl = strings.Join(parts, "\n")
				}
			} else if eq := strings.Index(line, "="); eq >= 0 {
				tmpl = unquote(strings.TrimSpace(line[eq+1:]))
			}
		}
	}
	return strings.TrimSpace(key), strings.TrimSpace(tmpl)
}

func applyFilter(rows []Row, f string) []Row {
	f = strings.TrimSpace(f)
	if f == "" || f == "*" {
		return rows
	}
	var out []Row
	for _, r := range rows {
		if evalFilter(f, r.Raw) {
			out = append(out, r)
		}
	}
	return out
}

func evalFilter(f, s string) bool {
	f = strings.TrimSpace(f)
	if strings.Contains(f, " OR ") {
		for _, p := range strings.Split(f, " OR ") {
			if evalFilter(strings.Trim(p, "() "), s) {
				return true
			}
		}
		return false
	}
	if strings.Contains(f, " AND ") {
		for _, p := range strings.Split(f, " AND ") {
			if !evalFilter(strings.Trim(p, "() "), s) {
				return false
			}
		}
		return true
	}
	if strings.HasPrefix(f, "NOT ") {
		return !evalFilter(strings.TrimSpace(f[4:]), s)
	}
	if strings.HasPrefix(f, "\"") && strings.HasSuffix(f, "\"") {
		return strings.Contains(s, unquote(f))
	}
	pat := strings.ToLower(f)
	text := strings.ToLower(s)
	if strings.Contains(pat, "*") {
		re := regexp.QuoteMeta(pat)
		re = strings.ReplaceAll(re, "\\*", ".*")
		ok, _ := regexp.MatchString(re, text)
		return ok
	}
	return strings.Contains(text, pat)
}

func opJSON(rows []Row, field string, raw bool) []Row {
	var out []Row
	for _, r := range rows {
		src := r.Raw
		if !raw {
			src = toString(get(r, field))
		}
		var v any
		if err := json.Unmarshal([]byte(src), &v); err != nil {
			fmt.Fprintf(os.Stderr, "error: Expected JSON, found %s\n", src)
			continue
		}
		if m, ok := v.(map[string]any); ok {
			n := cloneRow(r)
			flatten("", m, n.Fields)
			out = append(out, n)
		}
	}
	return out
}

func flatten(prefix string, m map[string]any, dst map[string]any) {
	for k, v := range m {
		key := k
		if prefix != "" {
			key = prefix + "." + k
		}
		if mm, ok := v.(map[string]any); ok {
			flatten(key, mm, dst)
		} else {
			dst[key] = normalize(v)
		}
	}
}

func opLogfmt(rows []Row, field string, raw bool) []Row {
	var out []Row
	for _, r := range rows {
		src := r.Raw
		if !raw {
			src = toString(get(r, field))
		}
		m := parseLogfmt(src)
		if len(m) == 0 {
			continue
		}
		n := cloneRow(r)
		for k, v := range m {
			n.Fields[k] = auto(v)
		}
		out = append(out, n)
	}
	return out
}

func parseLogfmt(s string) map[string]string {
	res := map[string]string{}
	i := 0
	for i < len(s) {
		for i < len(s) && s[i] == ' ' {
			i++
		}
		start := i
		for i < len(s) && s[i] != '=' && s[i] != ' ' {
			i++
		}
		if i >= len(s) || s[i] != '=' || start == i {
			break
		}
		key := s[start:i]
		i++
		var val string
		if i < len(s) && s[i] == '"' {
			i++
			start = i
			for i < len(s) && s[i] != '"' {
				i++
			}
			val = s[start:i]
			if i < len(s) {
				i++
			}
		} else {
			start = i
			for i < len(s) && s[i] != ' ' {
				i++
			}
			val = s[start:i]
		}
		res[key] = val
	}
	return res
}

func opParse(rows []Row, op string) []Row {
	pat := betweenQuotes(op)
	rest := strings.TrimSpace(op[strings.Index(op, "\"")+len(pat)+2:])
	from := ""
	if strings.HasPrefix(rest, "from ") {
		idx := strings.Index(rest, " as ")
		if idx >= 0 {
			from = strings.TrimSpace(rest[5:idx])
			rest = strings.TrimSpace(rest[idx+4:])
		}
	}
	idx := strings.Index(rest, "as ")
	if idx >= 0 {
		rest = strings.TrimSpace(rest[idx+3:])
	}
	nodrop := strings.Contains(rest, "nodrop")
	noconv := strings.Contains(rest, "noconvert")
	rest = strings.ReplaceAll(rest, "nodrop", "")
	rest = strings.ReplaceAll(rest, "noconvert", "")
	names := splitCSV(rest)
	re := parsePatternRE(pat)
	var out []Row
	for _, r := range rows {
		src := r.Raw
		if from != "" {
			src = toString(get(r, from))
		}
		m := re.FindStringSubmatch(src)
		if m == nil {
			if nodrop {
				out = append(out, r)
			}
			continue
		}
		n := cloneRow(r)
		for i, name := range names {
			if i+1 < len(m) && name != "" {
				if noconv {
					n.Fields[name] = m[i+1]
				} else {
					n.Fields[name] = auto(m[i+1])
				}
			}
		}
		out = append(out, n)
	}
	return out
}

func parsePatternRE(p string) *regexp.Regexp {
	var b strings.Builder
	b.WriteString("(?s)^")
	stars := strings.Count(p, "*")
	seen := 0
	for i := 0; i < len(p); i++ {
		if p[i] == '*' {
			seen++
			if seen == stars {
				b.WriteString("(.*)")
			} else {
				b.WriteString("(.*?)")
			}
		} else if p[i] == ' ' {
			b.WriteString("\\s+")
		} else {
			b.WriteString(regexp.QuoteMeta(string(p[i])))
		}
	}
	b.WriteString(".*$")
	return regexp.MustCompile(b.String())
}

func opParseRegex(rows []Row, op string) []Row {
	pat := betweenQuotes(op)
	nodrop := strings.Contains(op, "nodrop")
	re, err := regexp.Compile(pat)
	if err != nil {
		fmt.Fprintln(os.Stderr, "error:", err)
		return nil
	}
	names := re.SubexpNames()
	var out []Row
	for _, r := range rows {
		m := re.FindStringSubmatch(r.Raw)
		if m == nil {
			if nodrop {
				out = append(out, r)
			}
			continue
		}
		n := cloneRow(r)
		for i, name := range names {
			if i > 0 && name != "" {
				n.Fields[name] = auto(m[i])
			}
		}
		out = append(out, n)
	}
	return out
}

func opSplit(rows []Row, op string) []Row {
	field, sep, as := "", ",", "_split"
	if strings.HasPrefix(op, "split(") {
		end := strings.Index(op, ")")
		field = strings.TrimSpace(op[6:end])
		as = field
	}
	if i := strings.Index(op, " on "); i >= 0 {
		sep = unquote(strings.Fields(op[i+4:])[0])
		if q := betweenQuotes(op[i+4:]); q != "" {
			sep = q
		}
	}
	if i := strings.Index(op, " as "); i >= 0 {
		as = strings.TrimSpace(op[i+4:])
	}
	for i := range rows {
		src := rows[i].Raw
		if field != "" {
			src = toString(get(rows[i], field))
		}
		parts := strings.Split(src, sep)
		vals := make([]any, len(parts))
		for j, p := range parts {
			vals[j] = auto(strings.TrimSpace(p))
		}
		rows[i].Fields[as] = vals
	}
	return rows
}

func opFields(rows []Row, op string) []Row {
	rest := strings.TrimSpace(strings.TrimPrefix(op, "fields"))
	only := false
	if strings.HasPrefix(rest, "+") || strings.HasPrefix(rest, "only") {
		only = true
		rest = strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(rest, "+"), "only"))
	}
	if strings.HasPrefix(rest, "-") || strings.HasPrefix(rest, "except") {
		rest = strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(rest, "-"), "except"))
	}
	names := splitCSV(rest)
	set := map[string]bool{}
	for _, n := range names {
		set[n] = true
	}
	for i := range rows {
		if only {
			nf := map[string]any{}
			for k, v := range rows[i].Fields {
				if set[k] {
					nf[k] = v
				}
			}
			rows[i].Fields = nf
		} else {
			for k := range set {
				delete(rows[i].Fields, k)
			}
		}
	}
	return rows
}

func opWhere(rows []Row, expr string) []Row {
	var out []Row
	for _, r := range rows {
		if truth(eval(expr, r)) {
			out = append(out, r)
		}
	}
	return out
}

func opLimit(rows []Row, op string) []Row {
	fs := strings.Fields(op)
	if len(fs) < 2 {
		return rows
	}
	n, _ := strconv.Atoi(fs[1])
	if n >= 0 {
		if n > len(rows) {
			return rows
		}
		return rows[:n]
	}
	n = -n
	if n > len(rows) {
		return rows
	}
	return rows[len(rows)-n:]
}

func opExpr(rows []Row, op string) []Row {
	idx := strings.LastIndex(op, " as ")
	expr, name := strings.TrimSpace(op[:idx]), strings.TrimSpace(op[idx+4:])
	for i := range rows {
		rows[i].Fields[name] = eval(expr, rows[i])
	}
	return rows
}

func isAggregate(op string) bool {
	t := strings.TrimSpace(op)
	for _, p := range []string{"count", "sum(", "average(", "avg(", "min(", "max(", "p", "pct", "count_distinct("} {
		if strings.HasPrefix(t, p) {
			return true
		}
	}
	return false
}

type aggSpec struct{ fn, field, name string }
type aggState struct {
	count int
	sum   float64
	min   float64
	max   float64
	vals  []float64
	set   map[string]bool
}

func opAggregate(rows []Row, op string) []Row {
	by := []string{}
	main := op
	if idx := strings.LastIndex(op, " by "); idx >= 0 {
		main = strings.TrimSpace(op[:idx])
		by = splitCSV(op[idx+4:])
	}
	specs := []aggSpec{}
	for _, part := range splitTop(main, ',') {
		part = strings.TrimSpace(part)
		name := ""
		if idx := strings.LastIndex(part, " as "); idx >= 0 {
			name = strings.TrimSpace(part[idx+4:])
			part = strings.TrimSpace(part[:idx])
		}
		fn, fld := part, ""
		if i := strings.Index(part, "("); i >= 0 {
			fn = strings.TrimSpace(part[:i])
			fld = strings.TrimSuffix(part[i+1:], ")")
		} else if strings.HasPrefix(part, "count ") {
			fn = "count"
			fld = strings.TrimSpace(strings.TrimPrefix(part, "count "))
		}
		if fn == "avg" {
			fn = "average"
		}
		if name == "" {
			switch fn {
			case "count":
				name = "_count"
			case "sum":
				name = "_sum"
			case "average":
				name = "_average"
			case "min":
				name = "_min"
			case "max":
				name = "_max"
			case "count_distinct":
				name = "count_distinct"
			default:
				name = fn
			}
		}
		specs = append(specs, aggSpec{fn, strings.TrimSpace(fld), name})
	}
	tableOrder = append([]string{}, by...)
	for _, sp := range specs {
		tableOrder = append(tableOrder, sp.name)
	}
	groups := map[string][]aggState{}
	keys := map[string][]any{}
	for _, r := range rows {
		kvals := make([]any, len(by))
		for i, b := range by {
			kvals[i] = eval(b, r)
		}
		key := keyOf(kvals)
		if _, ok := groups[key]; !ok {
			st := make([]aggState, len(specs))
			for i := range st {
				st[i].min = math.Inf(1)
				st[i].max = math.Inf(-1)
				st[i].set = map[string]bool{}
			}
			groups[key] = st
			keys[key] = kvals
		}
		st := groups[key]
		for i, sp := range specs {
			switch sp.fn {
			case "count":
				if sp.field == "" || truth(eval(sp.field, r)) {
					st[i].count++
				}
			case "sum", "average", "min", "max":
				if f, ok := toFloat(eval(sp.field, r)); ok {
					st[i].count++
					st[i].sum += f
					if f < st[i].min {
						st[i].min = f
					}
					if f > st[i].max {
						st[i].max = f
					}
				}
			case "count_distinct":
				st[i].set[toString(eval(sp.field, r))] = true
			default:
				if strings.HasPrefix(sp.fn, "p") || strings.HasPrefix(sp.fn, "pct") {
					if f, ok := toFloat(eval(sp.field, r)); ok {
						st[i].vals = append(st[i].vals, f)
					}
				}
			}
		}
		groups[key] = st
	}
	var out []Row
	for key, st := range groups {
		n := Row{Fields: map[string]any{}}
		for i, b := range by {
			n.Fields[b] = keys[key][i]
		}
		for i, sp := range specs {
			switch sp.fn {
			case "count":
				n.Fields[sp.name] = st[i].count
			case "sum":
				n.Fields[sp.name] = niceNum(st[i].sum)
			case "average":
				if st[i].count > 0 {
					n.Fields[sp.name] = niceNum(st[i].sum / float64(st[i].count))
				}
			case "min":
				if !math.IsInf(st[i].min, 1) {
					n.Fields[sp.name] = niceNum(st[i].min)
				}
			case "max":
				if !math.IsInf(st[i].max, -1) {
					n.Fields[sp.name] = niceNum(st[i].max)
				}
			case "count_distinct":
				n.Fields[sp.name] = len(st[i].set)
			default:
				vals := st[i].vals
				sort.Float64s(vals)
				if len(vals) > 0 {
					p := percentileOf(sp.fn)
					idx := int(math.Floor((p / 100) * float64(len(vals)-1)))
					n.Fields[sp.name] = niceNum(vals[idx])
				}
			}
		}
		out = append(out, n)
	}
	sort.Slice(out, func(i, j int) bool { return keyOf(rowVals(out[i], by)) < keyOf(rowVals(out[j], by)) })
	return out
}

func opTotal(rows []Row, op string) []Row {
	field := ""
	name := "_total"
	if i := strings.Index(op, "("); i >= 0 {
		if j := strings.Index(op[i+1:], ")"); j >= 0 {
			field = strings.TrimSpace(op[i+1 : i+1+j])
		}
	}
	if idx := strings.LastIndex(op, " as "); idx >= 0 {
		name = strings.TrimSpace(op[idx+4:])
	}
	var total float64
	for i := range rows {
		if f, ok := toFloat(eval(field, rows[i])); ok {
			total += f
			rows[i].Fields[name] = niceNum(total)
		}
	}
	return rows
}

func opSort(rows []Row, op string) []Row {
	rest := strings.TrimSpace(strings.TrimPrefix(op, "sort by "))
	desc := strings.HasSuffix(rest, " desc")
	rest = strings.TrimSuffix(strings.TrimSuffix(rest, " desc"), " asc")
	cols := splitCSV(rest)
	sort.Slice(rows, func(i, j int) bool {
		for _, c := range cols {
			a, b := eval(c, rows[i]), eval(c, rows[j])
			cmp := cmpVals(a, b)
			if cmp != 0 {
				if desc {
					return cmp > 0
				}
				return cmp < 0
			}
		}
		return false
	})
	return rows
}

func eval(expr string, r Row) any {
	expr = strings.TrimSpace(expr)
	if expr == "" {
		return nil
	}
	if strings.HasPrefix(expr, "if(") && strings.HasSuffix(expr, ")") {
		args := splitTop(expr[3:len(expr)-1], ',')
		if len(args) == 3 {
			if truth(eval(args[0], r)) {
				return eval(args[1], r)
			}
			return eval(args[2], r)
		}
	}
	for _, op := range []string{"==", "!=", "<>", ">=", "<=", ">", "<"} {
		if idx := indexTop(expr, op); idx >= 0 {
			a, b := eval(expr[:idx], r), eval(expr[idx+len(op):], r)
			c := cmpVals(a, b)
			switch op {
			case "==":
				return c == 0
			case "!=", "<>":
				return c != 0
			case ">=":
				return c >= 0
			case "<=":
				return c <= 0
			case ">":
				return c > 0
			case "<":
				return c < 0
			}
		}
	}
	for _, op := range []string{" or ", " || ", " and ", " && "} {
		if idx := indexTop(expr, op); idx >= 0 {
			a := truth(eval(expr[:idx], r))
			if strings.Contains(op, "or") || strings.Contains(op, "||") {
				return a || truth(eval(expr[idx+len(op):], r))
			}
			return a && truth(eval(expr[idx+len(op):], r))
		}
	}
	for _, ops := range [][]string{{"+", "-"}, {"*", "/"}} {
		for _, op := range ops {
			if idx := indexTopRight(expr, op); idx > 0 {
				a, b := eval(expr[:idx], r), eval(expr[idx+1:], r)
				af, aok := toFloat(a)
				bf, bok := toFloat(b)
				if op == "+" && (!aok || !bok) {
					return toString(a) + toString(b)
				}
				if aok && bok {
					switch op {
					case "+":
						return niceNum(af + bf)
					case "-":
						return niceNum(af - bf)
					case "*":
						return niceNum(af * bf)
					case "/":
						return af / bf
					}
				}
			}
		}
	}
	if strings.HasPrefix(expr, "!") {
		return !truth(eval(expr[1:], r))
	}
	if strings.HasPrefix(expr, "(") && strings.HasSuffix(expr, ")") {
		return eval(expr[1:len(expr)-1], r)
	}
	if strings.HasPrefix(expr, "\"") || strings.HasPrefix(expr, "'") {
		return unquote(expr)
	}
	if f, err := strconv.ParseFloat(expr, 64); err == nil {
		return niceNum(f)
	}
	if strings.Contains(expr, "(") && strings.HasSuffix(expr, ")") {
		return evalFunc(expr, r)
	}
	return get(r, expr)
}

func evalFunc(expr string, r Row) any {
	i := strings.Index(expr, "(")
	name := expr[:i]
	args := splitTop(expr[i+1:len(expr)-1], ',')
	val := func(n int) any {
		if n >= len(args) {
			return nil
		}
		return eval(args[n], r)
	}
	switch name {
	case "concat":
		var b strings.Builder
		for _, a := range args {
			b.WriteString(toString(eval(a, r)))
		}
		return b.String()
	case "contains":
		return strings.Contains(toString(val(0)), toString(val(1)))
	case "length":
		return len([]rune(toString(val(0))))
	case "num":
		f, _ := toFloat(val(0))
		return niceNum(f)
	case "parseHex":
		n, _ := strconv.ParseInt(strings.TrimPrefix(toString(val(0)), "0x"), 16, 64)
		return n
	case "substring":
		s := []rune(toString(val(0)))
		st, _ := toFloat(val(1))
		en := float64(len(s))
		if len(args) > 2 {
			en, _ = toFloat(val(2))
		}
		a, b := int(st), int(en)
		if a < 0 {
			a = 0
		}
		if b > len(s) {
			b = len(s)
		}
		if a > b {
			return ""
		}
		return string(s[a:b])
	case "toLowerCase":
		return strings.ToLower(toString(val(0)))
	case "toUpperCase":
		return strings.ToUpper(toString(val(0)))
	case "isNull":
		return val(0) == nil
	case "isEmpty":
		return val(0) == nil || toString(val(0)) == ""
	case "isBlank":
		return val(0) == nil || strings.TrimSpace(toString(val(0))) == ""
	case "isNumeric":
		_, ok := toFloat(val(0))
		return ok
	}
	if len(args) == 1 {
		f, _ := toFloat(val(0))
		switch name {
		case "abs":
			return math.Abs(f)
		case "ceil":
			return math.Ceil(f)
		case "floor":
			return math.Floor(f)
		case "round":
			return math.Round(f)
		case "sqrt":
			return math.Sqrt(f)
		case "sin":
			return math.Sin(f)
		case "cos":
			return math.Cos(f)
		case "tan":
			return math.Tan(f)
		case "log":
			return math.Log(f)
		case "log10":
			return math.Log10(f)
		}
	}
	return nil
}

func render(rows []Row, out string) {
	if strings.HasPrefix(out, "format=") {
		tpl := strings.TrimPrefix(out, "format=")
		for _, r := range rows {
			fmt.Println(formatRow(tpl, r))
		}
		return
	}
	switch out {
	case "json":
		for _, r := range rows {
			if len(r.Fields) == 0 {
				b, _ := json.Marshal(r.Raw)
				fmt.Println(string(b))
			} else {
				b, _ := json.Marshal(r.Fields)
				fmt.Println(string(b))
			}
		}
	case "logfmt":
		for _, r := range rows {
			fmt.Println(renderLogfmt(r.Fields))
		}
	default:
		if len(rows) == 0 {
			return
		}
		if len(rows[0].Fields) == 0 {
			for _, r := range rows {
				fmt.Println(r.Raw)
			}
			return
		}
		if isTable(rows) {
			renderTable(rows)
		} else {
			for _, r := range rows {
				fmt.Println(renderLegacy(r.Fields))
			}
		}
	}
}

func isTable(rows []Row) bool {
	for _, r := range rows {
		for k := range r.Fields {
			if strings.HasPrefix(k, "_") || strings.HasPrefix(k, "p") || k == "count_distinct" {
				return true
			}
		}
	}
	return false
}

func renderLegacy(m map[string]any) string {
	keys := sortedKeys(m)
	parts := make([]string, len(keys))
	for i, k := range keys {
		parts[i] = fmt.Sprintf("[%s=%s]", k, valString(m[k]))
	}
	return strings.Join(parts, "        ")
}

func renderTable(rows []Row) {
	keys := append([]string{}, tableOrder...)
	if len(keys) == 0 {
		keys = sortedKeys(rows[0].Fields)
	}
	for _, r := range rows[1:] {
		for _, k := range sortedKeys(r.Fields) {
			if !contains(keys, k) {
				keys = append(keys, k)
			}
		}
	}
	width := map[string]int{}
	for _, k := range keys {
		width[k] = len(k)
	}
	for _, r := range rows {
		for _, k := range keys {
			if l := len(valString(r.Fields[k])); l > width[k] {
				width[k] = l
			}
		}
	}
	var header strings.Builder
	for i, k := range keys {
		if i > 0 {
			header.WriteString("        ")
		}
		header.WriteString(pad(k, width[k]))
	}
	fmt.Println(header.String())
	fmt.Println(strings.Repeat("-", len(header.String())))
	for _, r := range rows {
		var b strings.Builder
		for i, k := range keys {
			if i > 0 {
				b.WriteString("        ")
			}
			b.WriteString(pad(valString(r.Fields[k]), width[k]))
		}
		fmt.Println(b.String())
	}
}

func formatRow(t string, r Row) string {
	return regexp.MustCompile(`\{([^}]+)\}`).ReplaceAllStringFunc(t, func(s string) string {
		return valString(get(r, s[1:len(s)-1]))
	})
}

func renderLogfmt(m map[string]any) string {
	keys := sortedKeys(m)
	parts := make([]string, len(keys))
	for i, k := range keys {
		parts[i] = k + "=" + valString(m[k])
	}
	return strings.Join(parts, " ")
}

func splitTop(s string, sep rune) []string {
	var out []string
	start, depth := 0, 0
	quote := rune(0)
	for i, r := range s {
		if quote != 0 {
			if r == quote {
				quote = 0
			}
			continue
		}
		if r == '"' || r == '\'' {
			quote = r
		} else if r == '(' || r == '[' {
			depth++
		} else if r == ')' || r == ']' {
			depth--
		} else if r == sep && depth == 0 {
			out = append(out, strings.TrimSpace(s[start:i]))
			start = i + 1
		}
	}
	out = append(out, strings.TrimSpace(s[start:]))
	return out
}

func splitCSV(s string) []string {
	ps := splitTop(s, ',')
	var out []string
	for _, p := range ps {
		p = strings.TrimSpace(p)
		p = strings.Trim(p, " ")
		if strings.HasPrefix(p, "[\"") && strings.HasSuffix(p, "\"]") {
			p = p[2 : len(p)-2]
		}
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func indexTop(s, op string) int {
	depth := 0
	quote := byte(0)
	for i := 0; i <= len(s)-len(op); i++ {
		c := s[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			quote = c
		} else if c == '(' {
			depth++
		} else if c == ')' {
			depth--
		} else if depth == 0 && strings.HasPrefix(s[i:], op) {
			return i
		}
	}
	return -1
}

func indexTopRight(s, op string) int {
	depth := 0
	quote := byte(0)
	for i := len(s) - 1; i >= 0; i-- {
		c := s[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
			continue
		}
		if c == '"' || c == '\'' {
			quote = c
		} else if c == ')' {
			depth++
		} else if c == '(' {
			depth--
		} else if depth == 0 && string(c) == op {
			return i
		}
	}
	return -1
}

func betweenQuotes(s string) string {
	i := strings.Index(s, "\"")
	if i < 0 {
		return ""
	}
	j := i + 1
	var b strings.Builder
	esc := false
	for ; j < len(s); j++ {
		if esc {
			b.WriteByte(s[j])
			esc = false
		} else if s[j] == '\\' {
			esc = true
		} else if s[j] == '"' {
			break
		} else {
			b.WriteByte(s[j])
		}
	}
	return b.String()
}

func unquote(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 && ((s[0] == '"' && s[len(s)-1] == '"') || (s[0] == '\'' && s[len(s)-1] == '\'')) {
		var v string
		if err := json.Unmarshal([]byte(s), &v); err == nil {
			return v
		}
		return s[1 : len(s)-1]
	}
	return s
}

func cloneRow(r Row) Row {
	n := Row{Raw: r.Raw, Fields: map[string]any{}}
	for k, v := range r.Fields {
		n.Fields[k] = v
	}
	return n
}

func get(r Row, name string) any {
	name = strings.TrimSpace(name)
	if name == "raw" || name == "_raw" {
		return r.Raw
	}
	if v, ok := r.Fields[name]; ok {
		return v
	}
	if strings.Contains(name, "[") || strings.Contains(name, ".") {
		return getPath(r.Fields, name)
	}
	return nil
}

func getPath(m map[string]any, path string) any {
	if v, ok := m[path]; ok {
		return v
	}
	parts := strings.Split(path, ".")
	var cur any = m
	for _, p := range parts {
		name := p
		indexes := []int{}
		for strings.Contains(name, "[") && strings.HasSuffix(name, "]") {
			l := strings.LastIndex(name, "[")
			n, _ := strconv.Atoi(name[l+1 : len(name)-1])
			indexes = append([]int{n}, indexes...)
			name = name[:l]
		}
		if mm, ok := cur.(map[string]any); ok {
			cur = mm[name]
		} else {
			return nil
		}
		for _, idx := range indexes {
			arr, ok := cur.([]any)
			if !ok {
				return nil
			}
			if idx < 0 {
				idx = len(arr) + idx
			}
			if idx < 0 || idx >= len(arr) {
				return nil
			}
			cur = arr[idx]
		}
	}
	return cur
}

func auto(s string) any {
	if s == "true" {
		return true
	}
	if s == "false" {
		return false
	}
	if s == "null" {
		return nil
	}
	if i, err := strconv.ParseInt(s, 10, 64); err == nil {
		return i
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil {
		return f
	}
	return s
}

func normalize(v any) any {
	if f, ok := v.(float64); ok {
		return niceNum(f)
	}
	return v
}

func niceNum(f float64) any {
	if math.IsNaN(f) || math.IsInf(f, 0) {
		return f
	}
	if math.Abs(f-math.Round(f)) < 1e-9 {
		return int64(math.Round(f))
	}
	return f
}

func toFloat(v any) (float64, bool) {
	switch x := v.(type) {
	case int:
		return float64(x), true
	case int64:
		return float64(x), true
	case float64:
		return x, true
	case json.Number:
		f, e := x.Float64(); return f, e == nil
	case string:
		f, e := strconv.ParseFloat(x, 64); return f, e == nil
	}
	return 0, false
}

func toString(v any) string {
	if v == nil {
		return ""
	}
	return valString(v)
}

func valString(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	case int64:
		return strconv.FormatInt(x, 10)
	case int:
		return strconv.Itoa(x)
	case float64:
		if math.Abs(x-math.Round(x)) < 1e-9 {
			return strconv.FormatInt(int64(math.Round(x)), 10)
		}
		return strconv.FormatFloat(x, 'f', -1, 64)
	case bool:
		return strconv.FormatBool(x)
	case []any:
		ps := make([]string, len(x))
		for i, v := range x { ps[i] = valString(v) }
		return "[" + strings.Join(ps, ", ") + "]"
	default:
		return fmt.Sprint(x)
	}
}

func truth(v any) bool {
	switch x := v.(type) {
	case nil:
		return false
	case bool:
		return x
	case string:
		return x != ""
	case int64:
		return x != 0
	case float64:
		return x != 0
	}
	return true
}

func cmpVals(a, b any) int {
	if af, ok := toFloat(a); ok {
		if bf, ok := toFloat(b); ok {
			if af < bf { return -1 }; if af > bf { return 1 }; return 0
		}
	}
	as, bs := valString(a), valString(b)
	if as < bs { return -1 }; if as > bs { return 1 }; return 0
}

func sortedKeys(m map[string]any) []string {
	keys := make([]string, 0, len(m))
	for k := range m { keys = append(keys, k) }
	sort.Strings(keys)
	return keys
}

func contains(xs []string, x string) bool {
	for _, y := range xs { if x == y { return true } }
	return false
}

func pad(s string, n int) string {
	if len(s) >= n { return s }
	return s + strings.Repeat(" ", n-len(s))
}

func keyOf(vals []any) string {
	ps := make([]string, len(vals))
	for i, v := range vals { ps[i] = valString(v) }
	return strings.Join(ps, "\x00")
}

func rowVals(r Row, keys []string) []any {
	vals := make([]any, len(keys))
	for i, k := range keys { vals[i] = r.Fields[k] }
	return vals
}

func percentileOf(fn string) float64 {
	fn = strings.TrimPrefix(strings.TrimPrefix(fn, "pct"), "p")
	p, _ := strconv.ParseFloat(fn, 64)
	return p
}
