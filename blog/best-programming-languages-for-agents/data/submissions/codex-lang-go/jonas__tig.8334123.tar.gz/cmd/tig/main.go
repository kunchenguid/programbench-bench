package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const version = "2.6.0-g87c9c25"

const helpText = `tig 2.6.0-g87c9c25 

Usage: tig        [options] [revs] [--] [paths]
   or: tig log    [options] [revs] [--] [paths]
   or: tig show   [options] [revs] [--] [paths]
   or: tig reflog [options] [revs]
   or: tig blame  [options] [rev] [--] path
   or: tig grep   [options] [pattern]
   or: tig refs   [options]
   or: tig stash  [options]
   or: tig status
   or: tig <      [git command output]

Options:
  +<number>       Select line <number> in the first view
  -v, --version   Show version and exit
  -h, --help      Show help message and exit
  -C <path>       Start in <path>
`

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}

func run(args []string, _ *os.File, stdout, stderr io.Writer) int {
	cwd, actionArgs := parseChdir(args)
	mode := firstImmediate(actionArgs)
	if mode == "help" {
		fmt.Fprint(stdout, helpText)
		return 0
	}
	if cwd != "" {
		if err := os.Chdir(cwd); err != nil {
			fmt.Fprintf(stderr, "tig: Failed to change directory to %s\n", cwd)
			return 1
		}
	}
	if mode == "version" {
		fmt.Fprintf(stdout, "tig version %s\nncursesw version 6.3.20211021\n", version)
		return 0
	}
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		fmt.Fprintln(stderr, "tig: Failed to open tty for input")
		return 1
	}
	defer tty.Close()

	view, gitArgs := commandFor(actionArgs)
	lines := collectLines(view, gitArgs)
	render(view, lines, stdout)
	waitForQuit(tty)
	return 0
}

func parseChdir(args []string) (string, []string) {
	out := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		if args[i] == "-C" {
			if i+1 < len(args) {
				i++
				if !strings.HasPrefix(args[i], "-") {
					return args[i], append(out, args[i+1:]...)
				}
				out = append(out, "-C", args[i])
				continue
			}
			out = append(out, args[i])
			continue
		}
		out = append(out, args[i])
	}
	return "", out
}

func firstImmediate(args []string) string {
	for _, arg := range args {
		switch arg {
		case "-h", "--help":
			return "help"
		case "-v", "--version":
			return "version"
		}
	}
	return ""
}

func commandFor(args []string) (string, []string) {
	if len(args) == 0 {
		return "main", []string{"log", "--oneline", "--decorate", "-100"}
	}
	switch args[0] {
	case "status":
		return "status", []string{"status", "--short", "--branch"}
	case "log":
		return "log", append([]string{"log", "--decorate", "--stat"}, args[1:]...)
	case "show":
		return "show", append([]string{"show", "--stat"}, args[1:]...)
	case "reflog":
		return "reflog", append([]string{"reflog"}, args[1:]...)
	case "refs":
		return "refs", []string{"for-each-ref", "--format=%(refname:short) %(objectname:short) %(subject)"}
	case "stash":
		return "stash", []string{"stash", "list"}
	case "grep":
		return "grep", append([]string{"grep", "-n"}, args[1:]...)
	case "blame":
		return "blame", append([]string{"blame"}, args[1:]...)
	default:
		return "main", append([]string{"log", "--oneline", "--decorate"}, args...)
	}
}

func collectLines(view string, gitArgs []string) []string {
	cmd := exec.Command("git", gitArgs...)
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Run(); err != nil && out.Len() == 0 {
		return []string{fmt.Sprintf("git %s failed: %v", strings.Join(gitArgs, " "), err)}
	}
	var lines []string
	sc := bufio.NewScanner(&out)
	for sc.Scan() {
		lines = append(lines, sc.Text())
		if len(lines) >= 200 {
			break
		}
	}
	if len(lines) == 0 {
		switch view {
		case "status":
			lines = []string{"On branch " + currentBranch(), "Nothing to update"}
		default:
			lines = []string{"No entries"}
		}
	}
	return lines
}

func currentBranch() string {
	cmd := exec.Command("git", "branch", "--show-current")
	out, err := cmd.Output()
	if err != nil {
		return "master"
	}
	name := strings.TrimSpace(string(out))
	if name == "" {
		return "HEAD"
	}
	return name
}

func render(view string, lines []string, w io.Writer) {
	fmt.Fprint(w, "\033[?1049h\033[H\033[2J\033[?25l")
	title := "[" + view + "]"
	if view == "main" {
		title = "[main]"
	}
	fmt.Fprintf(w, "\033[37m\033[42m%s\033[0m\r\n", title)
	limit := len(lines)
	if limit > 22 {
		limit = 22
	}
	for i := 0; i < limit; i++ {
		fmt.Fprint(w, sanitize(lines[i]), "\r\n")
	}
	fmt.Fprintf(w, "\033[23;1H\033[37m\033[44m%s %d%%\033[0m", title, 100)
}

func sanitize(s string) string {
	s = strings.ReplaceAll(s, "\x1b", "?")
	if len(s) > 160 {
		return s[:160]
	}
	return s
}

func waitForQuit(stdin *os.File) {
	old, ok := makeRaw(int(stdin.Fd()))
	if ok {
		defer restore(int(stdin.Fd()), old)
	}
	defer fmt.Print("\033[?25h\033[?1049l")
	buf := make([]byte, 1)
	deadline := time.Now().Add(30 * time.Second)
	for time.Now().Before(deadline) {
		_ = stdin.SetReadDeadline(time.Now().Add(250 * time.Millisecond))
		n, err := stdin.Read(buf)
		if n > 0 && (buf[0] == 'q' || buf[0] == 3 || buf[0] == 4) {
			return
		}
		if err != nil && !isTimeout(err) {
			return
		}
	}
}

type termios = syscall.Termios

func makeRaw(fd int) (*termios, bool) {
	var old termios
	if _, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCGETS), uintptr(unsafe.Pointer(&old)), 0, 0, 0); errno != 0 {
		return nil, false
	}
	raw := old
	raw.Iflag &^= syscall.ICRNL | syscall.IXON
	raw.Lflag &^= syscall.ECHO | syscall.ICANON | syscall.ISIG
	raw.Cc[syscall.VMIN] = 0
	raw.Cc[syscall.VTIME] = 1
	if _, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(&raw)), 0, 0, 0); errno != 0 {
		return nil, false
	}
	return &old, true
}

func restore(fd int, old *termios) {
	if old != nil {
		_, _, _ = syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), uintptr(syscall.TCSETS), uintptr(unsafe.Pointer(old)), 0, 0, 0)
	}
}

func isTimeout(err error) bool {
	if os.IsTimeout(err) {
		return true
	}
	return strings.Contains(err.Error(), "i/o timeout") || strings.Contains(err.Error(), "resource temporarily unavailable")
}
