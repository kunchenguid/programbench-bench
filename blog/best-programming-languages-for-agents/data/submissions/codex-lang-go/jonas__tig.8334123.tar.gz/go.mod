module tigclone

go 1.21
