module fzfclean

go 1.21
