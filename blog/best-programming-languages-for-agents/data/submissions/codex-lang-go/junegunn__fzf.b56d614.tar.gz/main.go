package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "0.68.0 (5676da4a)"

type opts struct {
	filter      *string
	query       string
	printQuery  bool
	expect      string
	read0       bool
	print0      bool
	exact       bool
	extended    bool
	caseMode    string
	noSort      bool
	tac         bool
	tail        int
	headerLines int
	nth         string
	withNth     string
	acceptNth   string
	delimiter   string
	disabled    bool
	walkerRoot  []string
	walkerOpts  map[string]bool
	walkerSkip  map[string]bool
	showHelp    bool
	showVersion bool
	showMan     bool
	shellScript string
}

type item struct {
	orig    string
	search  string
	display string
	index   int
	score   int
	begin   int
	end     int
}

func main() {
	o := defaultOpts()
	args := mergeEnvArgs(os.Args[1:])
	if err := parseArgs(args, &o); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	switch {
	case o.showVersion:
		fmt.Println(version)
		return
	case o.showHelp:
		fmt.Print(helpText)
		return
	case o.showMan:
		showMan()
		return
	case o.shellScript != "":
		printShell(o.shellScript)
		return
	}
	if o.filter != nil {
		code := runFilter(o)
		os.Exit(code)
	}
	// A faithful full-screen TUI is outside this clean-room reimplementation.
	// For script friendliness, non-filter mode acts like selecting the first item
	// when stdin is piped, and otherwise lists walker/default-command candidates.
	lines, err := loadInput(o)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if len(lines) == 0 {
		os.Exit(1)
	}
	out := transformAccept(lines[0], 0, o)
	writeRecord(os.Stdout, out, o.print0)
}

func defaultOpts() opts {
	return opts{
		extended:   true,
		caseMode:   "smart",
		tail:       -1,
		delimiter:  "",
		walkerRoot: []string{"."},
		walkerOpts: map[string]bool{"file": true, "follow": true, "hidden": true},
		walkerSkip: map[string]bool{".git": true, "node_modules": true},
	}
}

func mergeEnvArgs(args []string) []string {
	var merged []string
	if f := os.Getenv("FZF_DEFAULT_OPTS_FILE"); f != "" {
		if b, err := os.ReadFile(f); err == nil {
			merged = append(merged, shellFields(string(b))...)
		}
	}
	if s := os.Getenv("FZF_DEFAULT_OPTS"); s != "" {
		merged = append(merged, shellFields(s)...)
	}
	return append(merged, args...)
}

func parseArgs(args []string, o *opts) error {
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func(name string) (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("%s value required", name)
			}
			i++
			return args[i], nil
		}
		switch {
		case a == "--help" || a == "-h":
			o.showHelp = true
		case a == "--version":
			o.showVersion = true
		case a == "--man":
			o.showMan = true
		case a == "--bash" || a == "--zsh" || a == "--fish":
			o.shellScript = strings.TrimPrefix(a, "--")
		case a == "-f" || a == "--filter":
			v, err := next("query string")
			if err != nil {
				return fmt.Errorf("query string required")
			}
			o.filter = &v
		case strings.HasPrefix(a, "--filter="):
			v := strings.TrimPrefix(a, "--filter=")
			o.filter = &v
		case a == "-q" || a == "--query":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.query = v
		case strings.HasPrefix(a, "--query="):
			o.query = strings.TrimPrefix(a, "--query=")
		case a == "--print-query":
			o.printQuery = true
		case a == "--expect":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.expect = v
		case strings.HasPrefix(a, "--expect="):
			o.expect = strings.TrimPrefix(a, "--expect=")
		case a == "--read0":
			o.read0 = true
		case a == "--print0":
			o.print0 = true
		case a == "-e" || a == "--exact":
			o.exact = true
		case a == "-x" || a == "--extended":
			o.extended = true
		case a == "+x" || a == "--no-extended":
			o.extended = false
		case a == "-i" || a == "--ignore-case":
			o.caseMode = "ignore"
		case a == "+i" || a == "--no-ignore-case":
			o.caseMode = "respect"
		case a == "--smart-case":
			o.caseMode = "smart"
		case a == "+s" || a == "--no-sort":
			o.noSort = true
		case a == "--tac":
			o.tac = true
		case a == "--disabled":
			o.disabled = true
		case a == "-n" || a == "--nth":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.nth = v
		case strings.HasPrefix(a, "--nth="):
			o.nth = strings.TrimPrefix(a, "--nth=")
		case a == "--with-nth":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.withNth = v
		case strings.HasPrefix(a, "--with-nth="):
			o.withNth = strings.TrimPrefix(a, "--with-nth=")
		case a == "--accept-nth":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.acceptNth = v
		case strings.HasPrefix(a, "--accept-nth="):
			o.acceptNth = strings.TrimPrefix(a, "--accept-nth=")
		case a == "-d" || a == "--delimiter":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.delimiter = v
		case strings.HasPrefix(a, "--delimiter="):
			o.delimiter = strings.TrimPrefix(a, "--delimiter=")
		case a == "--tail":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.tail, _ = strconv.Atoi(v)
		case strings.HasPrefix(a, "--tail="):
			o.tail, _ = strconv.Atoi(strings.TrimPrefix(a, "--tail="))
		case a == "--header-lines":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.headerLines, _ = strconv.Atoi(v)
		case strings.HasPrefix(a, "--header-lines="):
			o.headerLines, _ = strconv.Atoi(strings.TrimPrefix(a, "--header-lines="))
		case a == "--walker":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.walkerOpts = parseSet(v)
		case strings.HasPrefix(a, "--walker="):
			o.walkerOpts = parseSet(strings.TrimPrefix(a, "--walker="))
		case a == "--walker-root":
			o.walkerRoot = nil
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") && !strings.HasPrefix(args[i+1], "+") {
				i++
				o.walkerRoot = append(o.walkerRoot, args[i])
			}
			if len(o.walkerRoot) == 0 {
				o.walkerRoot = []string{"."}
			}
		case strings.HasPrefix(a, "--walker-root="):
			o.walkerRoot = []string{strings.TrimPrefix(a, "--walker-root=")}
		case a == "--walker-skip":
			v, err := next(a)
			if err != nil {
				return err
			}
			o.walkerSkip = parseSet(v)
		case strings.HasPrefix(a, "--walker-skip="):
			o.walkerSkip = parseSet(strings.TrimPrefix(a, "--walker-skip="))
		case strings.HasPrefix(a, "--scheme="):
			v := strings.TrimPrefix(a, "--scheme=")
			if v != "default" && v != "path" && v != "history" {
				return fmt.Errorf("invalid scoring scheme: %s (expected: default|path|history)", v)
			}
		case isIgnoredOption(a):
			if optionNeedsValue(a) && !strings.Contains(a, "=") {
				if _, err := next(a); err != nil {
					return err
				}
			}
		default:
			return fmt.Errorf("unknown option: %s", a)
		}
	}
	return nil
}

func parseSet(s string) map[string]bool {
	m := map[string]bool{}
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			m[p] = true
		}
	}
	return m
}

func isIgnoredOption(a string) bool {
	if a == "-0" || a == "-1" || a == "-m" || a == "+m" || a == "--multi" || a == "--exit-0" || a == "--select-1" || a == "--no-multi" || strings.HasPrefix(a, "--multi=") {
		return true
	}
	if strings.HasPrefix(a, "--") {
		name := strings.TrimPrefix(a, "--")
		if idx := strings.IndexByte(name, '='); idx >= 0 {
			name = name[:idx]
		}
		ignored := map[string]bool{
			"ansi": true, "sync": true, "style": true, "color": true, "no-color": true, "no-bold": true,
			"height": true, "min-height": true, "tmux": true, "layout": true, "margin": true, "padding": true,
			"border": true, "border-label": true, "border-label-pos": true, "highlight-line": true, "cycle": true,
			"wrap": true, "wrap-sign": true, "no-multi-line": true, "raw": true, "track": true, "gap": true,
			"gap-line": true, "freeze-left": true, "freeze-right": true, "keep-right": true, "scroll-off": true,
			"no-hscroll": true, "hscroll-off": true, "jump-labels": true, "gutter": true, "gutter-raw": true,
			"pointer": true, "marker": true, "marker-multi-line": true, "ellipsis": true, "tabstop": true,
			"scrollbar": true, "no-scrollbar": true, "list-border": true, "list-label": true, "list-label-pos": true,
			"no-input": true, "prompt": true, "info": true, "info-command": true, "separator": true, "no-separator": true,
			"ghost": true, "filepath-word": true, "input-border": true, "input-label": true, "input-label-pos": true,
			"preview": true, "preview-window": true, "preview-border": true, "preview-label": true, "preview-label-pos": true,
			"header": true, "header-first": true, "header-border": true, "header-lines-border": true, "header-label": true,
			"header-label-pos": true, "footer": true, "footer-border": true, "footer-label": true, "footer-label-pos": true,
			"bind": true, "with-shell": true, "listen": true, "listen-unsafe": true, "history": true, "history-size": true,
			"literal": true, "tiebreak": true, "algo": true, "no-mouse": true, "no-unicode": true, "ambidouble": true,
		}
		return ignored[name]
	}
	return false
}

func optionNeedsValue(a string) bool {
	noValue := map[string]bool{
		"--ansi": true, "--sync": true, "--no-color": true, "--no-bold": true, "--border": true, "--cycle": true,
		"--wrap": true, "--raw": true, "--track": true, "--keep-right": true, "--no-hscroll": true, "--scrollbar": true,
		"--no-scrollbar": true, "--no-input": true, "--no-separator": true, "--header-first": true, "--no-mouse": true,
		"--no-unicode": true, "--ambidouble": true, "--literal": true, "--listen-unsafe": true,
		"--exit-0": true, "--select-1": true, "--no-multi": true,
	}
	return strings.HasPrefix(a, "--") && !noValue[a]
}

func runFilter(o opts) int {
	lines, err := loadInput(o)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 2
	}
	q := *o.filter
	items := make([]item, 0, len(lines))
	for i, line := range lines {
		if i < o.headerLines {
			continue
		}
		display := transformWith(line, i, o)
		search := display
		if o.nth != "" {
			search = transformExpr(display, i, o.nth, o)
		}
		it := item{orig: line, display: display, search: search, index: i}
		if o.disabled || q == "" {
			it.score = 0
			items = append(items, it)
			continue
		}
		ok, sc, b, e := matchQuery(search, q, o)
		if ok {
			it.score, it.begin, it.end = sc, b, e
			items = append(items, it)
		}
	}
	if !o.noSort && q != "" && !o.disabled {
		sort.SliceStable(items, func(i, j int) bool {
			a, b := items[i], items[j]
			if a.score != b.score {
				return a.score > b.score
			}
			if a.begin != b.begin {
				return a.begin < b.begin
			}
			if len(a.search) != len(b.search) {
				return len(a.search) < len(b.search)
			}
			return a.index < b.index
		})
	}
	if o.printQuery {
		writeRecord(os.Stdout, q, o.print0)
	}
	if o.expect != "" {
		// In --filter mode no key was pressed, so fzf does not print an
		// expected-key line.
	}
	for _, it := range items {
		out := it.orig
		if o.acceptNth != "" {
			out = transformExpr(it.orig, it.index, o.acceptNth, o)
		}
		writeRecord(os.Stdout, out, o.print0)
	}
	if len(items) == 0 {
		return 1
	}
	return 0
}

func loadInput(o opts) ([]string, error) {
	var data []byte
	var err error
	stat, _ := os.Stdin.Stat()
	if stat != nil && stat.Mode()&os.ModeCharDevice == 0 {
		data, err = io.ReadAll(os.Stdin)
	} else if cmd := os.Getenv("FZF_DEFAULT_COMMAND"); cmd != "" {
		c := exec.Command("sh", "-c", cmd)
		data, err = c.Output()
	} else {
		return walk(o), nil
	}
	if err != nil {
		return nil, err
	}
	var lines []string
	if o.read0 {
		parts := bytes.Split(data, []byte{0})
		for _, p := range parts {
			if len(p) > 0 {
				lines = append(lines, string(p))
			}
		}
	} else {
		sc := bufio.NewScanner(bytes.NewReader(data))
		buf := make([]byte, 0, 1024*1024)
		sc.Buffer(buf, 64*1024*1024)
		for sc.Scan() {
			lines = append(lines, sc.Text())
		}
		if err := sc.Err(); err != nil {
			return nil, err
		}
	}
	if o.tac {
		for i, j := 0, len(lines)-1; i < j; i, j = i+1, j-1 {
			lines[i], lines[j] = lines[j], lines[i]
		}
	}
	if o.tail >= 0 && len(lines) > o.tail {
		lines = lines[len(lines)-o.tail:]
	}
	return lines, nil
}

func walk(o opts) []string {
	var out []string
	for _, root := range o.walkerRoot {
		filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
			if err != nil || path == "." {
				return nil
			}
			name := d.Name()
			if d.IsDir() && o.walkerSkip[name] {
				return filepath.SkipDir
			}
			if !o.walkerOpts["hidden"] && strings.HasPrefix(name, ".") {
				if d.IsDir() {
					return filepath.SkipDir
				}
				return nil
			}
			if d.IsDir() {
				if o.walkerOpts["dir"] {
					out = append(out, path)
				}
				return nil
			}
			if o.walkerOpts["file"] {
				out = append(out, path)
			}
			return nil
		})
	}
	return out
}

type term struct {
	raw    string
	inv    bool
	exact  bool
	prefix bool
	suffix bool
	bound  bool
}

func matchQuery(text, query string, o opts) (bool, int, int, int) {
	groups := splitOrTerms(query)
	if len(groups) == 0 {
		return true, 0, 0, 0
	}
	bestOK, bestScore, bestB, bestE := false, -1<<30, 0, 0
	for _, group := range groups {
		ok, sc, b, e := matchAnd(text, group, o)
		if ok && sc > bestScore {
			bestOK, bestScore, bestB, bestE = true, sc, b, e
		}
	}
	return bestOK, bestScore, bestB, bestE
}

func splitOrTerms(q string) [][]string {
	parts := splitQuery(q)
	var groups [][]string
	var cur []string
	for _, p := range parts {
		if p == "|" {
			if len(cur) > 0 {
				groups = append(groups, cur)
				cur = nil
			}
		} else {
			cur = append(cur, p)
		}
	}
	if len(cur) > 0 {
		groups = append(groups, cur)
	}
	return groups
}

func matchAnd(text string, rawTerms []string, o opts) (bool, int, int, int) {
	total, firstB, lastE := 0, len(text), 0
	for _, r := range rawTerms {
		t := parseTerm(r, o)
		ok, sc, b, e := matchTerm(text, t, o)
		if t.inv {
			if ok {
				return false, 0, 0, 0
			}
			continue
		}
		if !ok {
			return false, 0, 0, 0
		}
		total += sc
		if b < firstB {
			firstB = b
		}
		if e > lastE {
			lastE = e
		}
	}
	if firstB == len(text) {
		firstB = 0
	}
	return true, total, firstB, lastE
}

func parseTerm(r string, o opts) term {
	t := term{raw: r}
	if strings.HasPrefix(t.raw, "!") {
		t.inv = true
		t.raw = strings.TrimPrefix(t.raw, "!")
	}
	if strings.HasPrefix(t.raw, "'") {
		t.exact = !o.exact
		t.bound = strings.HasSuffix(t.raw, "'") && len(t.raw) > 1
		t.raw = strings.TrimPrefix(t.raw, "'")
		t.raw = strings.TrimSuffix(t.raw, "'")
	} else {
		t.exact = o.exact || t.inv || !o.extended
	}
	if strings.HasPrefix(t.raw, "^") {
		t.prefix = true
		t.exact = true
		t.raw = strings.TrimPrefix(t.raw, "^")
	}
	if strings.HasSuffix(t.raw, "$") {
		t.suffix = true
		t.exact = true
		t.raw = strings.TrimSuffix(t.raw, "$")
	}
	return t
}

func matchTerm(text string, t term, o opts) (bool, int, int, int) {
	hay, needle := text, t.raw
	if ignoreCase(needle, o.caseMode) {
		hay = strings.ToLower(hay)
		needle = strings.ToLower(needle)
	}
	if needle == "" {
		return true, 0, 0, 0
	}
	if t.prefix {
		ok := strings.HasPrefix(hay, needle)
		return ok, scoreExact(text, 0, len(needle)), 0, len(needle)
	}
	if t.suffix {
		ok := strings.HasSuffix(hay, needle)
		b := len([]rune(hay)) - len([]rune(needle))
		return ok, scoreExact(text, b, b+len([]rune(needle))), b, b + len([]rune(needle))
	}
	if t.exact {
		idx := strings.Index(hay, needle)
		if idx < 0 {
			return false, 0, 0, 0
		}
		b := len([]rune(hay[:idx]))
		e := b + len([]rune(needle))
		if t.bound && !isBoundary(text, b) {
			return false, 0, 0, 0
		}
		return true, scoreExact(text, b, e), b, e
	}
	return fuzzyMatch(text, hay, needle)
}

func fuzzyMatch(orig, hay, needle string) (bool, int, int, int) {
	hr, nr := []rune(hay), []rune(needle)
	pos := make([]int, 0, len(nr))
	j := 0
	for i, r := range hr {
		if j < len(nr) && r == nr[j] {
			pos = append(pos, i)
			j++
		}
	}
	if j != len(nr) {
		return false, 0, 0, 0
	}
	b, e := pos[0], pos[len(pos)-1]+1
	gaps := (e - b) - len(nr)
	score := 1000 + len(nr)*100 - gaps*12 - b*3 - len(hr)
	run := 1
	for i := 1; i < len(pos); i++ {
		if pos[i] == pos[i-1]+1 {
			run++
			score += 25 * run
		}
	}
	for _, p := range pos {
		if isBoundary(orig, p) {
			score += 35
		}
	}
	return true, score, b, e
}

func scoreExact(text string, b, e int) int {
	return 2000 + (e-b)*100 - b*4 - len([]rune(text))
}

func ignoreCase(q, mode string) bool {
	switch mode {
	case "ignore":
		return true
	case "respect":
		return false
	default:
		for _, r := range q {
			if unicode.IsUpper(r) {
				return false
			}
		}
		return true
	}
}

func isBoundary(s string, idx int) bool {
	if idx <= 0 {
		return true
	}
	rs := []rune(s)
	if idx >= len(rs) {
		return true
	}
	prev, cur := rs[idx-1], rs[idx]
	return unicode.IsSpace(prev) || strings.ContainsRune("/:_-.+,", prev) || (unicode.IsLower(prev) && unicode.IsUpper(cur))
}

func splitQuery(q string) []string {
	var out []string
	var b strings.Builder
	esc := false
	for _, r := range q {
		if esc {
			b.WriteRune(r)
			esc = false
			continue
		}
		if r == '\\' {
			esc = true
			continue
		}
		if unicode.IsSpace(r) {
			if b.Len() > 0 {
				out = append(out, b.String())
				b.Reset()
			}
			continue
		}
		b.WriteRune(r)
	}
	if b.Len() > 0 {
		out = append(out, b.String())
	}
	return out
}

func splitFields(line string, delim string) []string {
	if delim == "" {
		return strings.Fields(line)
	}
	if delim == " " || delim == "\\s+" {
		return strings.Fields(line)
	}
	if len(delim) == 1 {
		return strings.Split(line, delim)
	}
	re, err := regexp.Compile(delim)
	if err != nil {
		return strings.Fields(line)
	}
	return re.Split(line, -1)
}

func transformWith(line string, idx int, o opts) string {
	if o.withNth == "" {
		return line
	}
	return transformExpr(line, idx, o.withNth, o)
}

func transformAccept(line string, idx int, o opts) string {
	if o.acceptNth == "" {
		return line
	}
	return transformExpr(line, idx, o.acceptNth, o)
}

func transformExpr(line string, idx int, expr string, o opts) string {
	if strings.Contains(expr, "{") {
		return renderTemplate(line, idx, expr, o)
	}
	fields := splitFields(line, o.delimiter)
	var parts []string
	for _, p := range strings.Split(expr, ",") {
		parts = append(parts, selectExpr(fields, strings.TrimSpace(p))...)
	}
	return strings.Join(parts, " ")
}

func renderTemplate(line string, idx int, tmpl string, o opts) string {
	fields := splitFields(line, o.delimiter)
	re := regexp.MustCompile(`\{([^{}]+)\}`)
	return re.ReplaceAllStringFunc(tmpl, func(m string) string {
		key := strings.TrimSuffix(strings.TrimPrefix(m, "{"), "}")
		if key == "n" {
			return strconv.Itoa(idx)
		}
		return strings.Join(selectExpr(fields, key), " ")
	})
}

func selectExpr(fields []string, expr string) []string {
	if expr == "" || expr == ".." {
		return append([]string{}, fields...)
	}
	if strings.Contains(expr, "..") {
		parts := strings.SplitN(expr, "..", 2)
		start, end := 1, len(fields)
		if parts[0] != "" {
			start = fieldIndex(parts[0], len(fields))
		}
		if parts[1] != "" {
			end = fieldIndex(parts[1], len(fields))
		}
		if start < 1 {
			start = 1
		}
		if end > len(fields) {
			end = len(fields)
		}
		if start > end || start > len(fields) {
			return nil
		}
		return append([]string{}, fields[start-1:end]...)
	}
	n := fieldIndex(expr, len(fields))
	if n < 1 || n > len(fields) {
		return nil
	}
	return []string{fields[n-1]}
}

func fieldIndex(s string, n int) int {
	v, _ := strconv.Atoi(strings.TrimSpace(s))
	if v < 0 {
		return n + v + 1
	}
	return v
}

func writeRecord(w io.Writer, s string, nul bool) {
	if nul {
		fmt.Fprint(w, s)
		fmt.Fprint(w, "\x00")
	} else {
		fmt.Fprintln(w, s)
	}
}

func shellFields(s string) []string {
	var out []string
	var b strings.Builder
	var quote rune
	esc := false
	for _, r := range s {
		if esc {
			b.WriteRune(r)
			esc = false
			continue
		}
		if r == '\\' {
			esc = true
			continue
		}
		if quote != 0 {
			if r == quote {
				quote = 0
			} else {
				b.WriteRune(r)
			}
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			continue
		}
		if unicode.IsSpace(r) {
			if b.Len() > 0 {
				out = append(out, b.String())
				b.Reset()
			}
			continue
		}
		b.WriteRune(r)
	}
	if b.Len() > 0 {
		out = append(out, b.String())
	}
	return out
}

func showMan() {
	paths := []string{"man/man1/fzf.1", "/workspace/man/man1/fzf.1"}
	for _, p := range paths {
		if b, err := os.ReadFile(p); err == nil {
			fmt.Print(string(b))
			return
		}
	}
	fmt.Print(helpText)
}

func printShell(kind string) {
	fmt.Printf("### key-bindings.%s ###\n", kind)
	switch kind {
	case "fish":
		fmt.Println("function fzf_key_bindings\nend")
		fmt.Println("function fzf --wraps fzf\n  command fzf $argv\nend")
	default:
		fmt.Println("__fzf_defaults() {")
		fmt.Println("  command cat \"${FZF_DEFAULT_OPTS_FILE-}\" 2> /dev/null")
		fmt.Println("  printf '%s\\n' \"${FZF_DEFAULT_OPTS-} $*\"")
		fmt.Println("}")
		fmt.Println("[[ $- =~ i ]] && bind -x '\"\\C-t\": fzf'")
	}
}

const helpText = `fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
    --with-nth=N[,..]        Transform the presentation of each line
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result
    --tail=NUM               Maximum number of items to keep in memory
    --disabled               Do not perform search

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes
    --sync                   Synchronous search for multi-staged filtering

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  DIRECTORY TRAVERSAL
    --walker=OPTS            [file][,dir][,follow][,hidden]
    --walker-root=DIR [...]  List of directories to walk (default: .)
    --walker-skip=DIRS       Comma-separated list of directory names to skip

  SHELL INTEGRATION
    --bash                   Print script to set up Bash shell integration
    --zsh                    Print script to set up Zsh shell integration
    --fish                   Print script to set up Fish shell integration

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page
`
