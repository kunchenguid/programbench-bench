module handlr-reimpl

go 1.21
