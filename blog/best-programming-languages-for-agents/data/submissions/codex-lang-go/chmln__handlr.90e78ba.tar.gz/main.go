package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
)

const version = "handlr 0.6.4"

type desktopEntry struct {
	ID       string
	Path     string
	Name     string
	Exec     string
	MimeType []string
}

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	ensureConfig()
	if len(args) == 0 {
		fmt.Fprint(os.Stderr, mainHelp())
		return 2
	}
	switch args[0] {
	case "-h", "--help":
		fmt.Print(mainHelp())
		return 0
	case "-V", "--version":
		fmt.Println(version)
		return 0
	case "list":
		return cmdList(args[1:])
	case "open":
		return cmdOpen(args[1:])
	case "set":
		return cmdSetAdd(args[1:], true)
	case "add":
		return cmdSetAdd(args[1:], false)
	case "unset":
		return cmdUnset(args[1:])
	case "get":
		return cmdGet(args[1:])
	case "launch":
		return cmdLaunch(args[1:])
	default:
		unexpected(args[0], "executable <SUBCOMMAND>")
		return 2
	}
}

func mainHelp() string {
	return version + "\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    list      List default apps and the associated handlers\n    open      Open a path/URL with its default handler\n    set       Set the default handler for mime/extension\n    unset     Unset the default handler for mime/extension\n    launch    Launch the handler for specified extension/mime with optional arguments\n    get       Get handler for this mime/extension\n    add       Add a handler for given mime/extension Note that the first handler is the default\n"
}

func subHelp(cmd string) string {
	switch cmd {
	case "list":
		return "executable-list \nList default apps and the associated handlers\n\nUSAGE:\n    executable list [FLAGS]\n\nFLAGS:\n    -a, --all        \n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	case "open":
		return "executable-open \nOpen a path/URL with its default handler\n\nUSAGE:\n    executable open <paths>...\n\nARGS:\n    <paths>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	case "set":
		return "executable-set \nSet the default handler for mime/extension\n\nUSAGE:\n    executable set <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	case "unset":
		return "executable-unset \nUnset the default handler for mime/extension\n\nUSAGE:\n    executable unset <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	case "launch":
		return "executable-launch \nLaunch the handler for specified extension/mime with optional arguments\n\nUSAGE:\n    executable launch <mime> [args]...\n\nARGS:\n    <mime>       \n    <args>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	case "get":
		return "executable-get \nGet handler for this mime/extension\n\nUSAGE:\n    executable get [FLAGS] <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n        --json       \n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	case "add":
		return "executable-add \nAdd a handler for given mime/extension Note that the first handler is the default\n\nUSAGE:\n    executable add <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n"
	}
	return ""
}

func cmdList(args []string) int {
	all := false
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print(subHelp("list"))
			return 0
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return 0
		}
		if a == "-a" || a == "--all" {
			all = true
			continue
		}
		unexpected(a, "executable list [FLAGS]")
		return 2
	}
	if all {
		fmt.Println("Default Apps")
	}
	printTable(defaultRows())
	if all {
		fmt.Println("System Apps")
		printTable(systemRows())
	}
	return 0
}

func cmdSetAdd(args []string, set bool) int {
	name := "add"
	usage := "executable add <mime> <handler>"
	if set {
		name, usage = "set", "executable set <mime> <handler>"
	}
	if helpVersion(name, args) {
		return 0
	}
	if len(args) < 2 {
		missing := "<mime>"
		if len(args) == 1 {
			missing = "<handler>"
		}
		required(missing, usage)
		return 2
	}
	if len(args) > 2 {
		unexpected(args[2], usage)
		return 2
	}
	mime, err := parseMime(args[0])
	if err != nil {
		invalid("mime", err.Error())
		return 2
	}
	if _, err := findDesktop(args[1]); err != nil {
		invalid("handler", err.Error())
		return 2
	}
	apps := readMimeApps()
	if set {
		apps[mime] = []string{args[1]}
	} else {
		apps[mime] = append(apps[mime], args[1])
	}
	writeMimeApps(apps)
	return 0
}

func cmdUnset(args []string) int {
	if helpVersion("unset", args) {
		return 0
	}
	if len(args) < 1 {
		required("<mime>", "executable unset <mime>")
		return 2
	}
	if len(args) > 1 {
		unexpected(args[1], "executable unset <mime>")
		return 2
	}
	mime, err := parseMime(args[0])
	if err != nil {
		invalid("mime", err.Error())
		return 2
	}
	apps := readMimeApps()
	delete(apps, mime)
	writeMimeApps(apps)
	return 0
}

func cmdGet(args []string) int {
	jsonOut := false
	var rest []string
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print(subHelp("get"))
			return 0
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return 0
		}
		if a == "--json" {
			jsonOut = true
			continue
		}
		rest = append(rest, a)
	}
	if len(rest) < 1 {
		required("<mime>", "executable get [FLAGS] <mime>")
		return 2
	}
	if len(rest) > 1 {
		unexpected(rest[1], "executable get [FLAGS] <mime>")
		return 2
	}
	mime, err := parseMime(rest[0])
	if err != nil {
		invalid("mime", err.Error())
		return 2
	}
	handler := firstValid(readMimeApps()[mime])
	if handler == "" {
		return 1
	}
	if jsonOut {
		de, _ := findDesktop(handler)
		payload := struct {
			Handler string `json:"handler"`
			Name    string `json:"name"`
			Cmd     string `json:"cmd"`
		}{handler, de.Name, stripExec(de.Exec)}
		var b bytes.Buffer
		enc := json.NewEncoder(&b)
		enc.SetEscapeHTML(false)
		_ = enc.Encode(payload)
		fmt.Print(b.String())
	} else {
		fmt.Println(handler)
	}
	return 0
}

func cmdLaunch(args []string) int {
	if helpVersion("launch", args) {
		return 0
	}
	if len(args) < 1 {
		required("<mime>", "executable launch <mime> [args]...")
		return 2
	}
	mime, err := parseMime(args[0])
	if err != nil {
		invalid("mime", err.Error())
		return 2
	}
	handler := firstValid(readMimeApps()[mime])
	if handler == "" {
		return 1
	}
	de, err := findDesktop(handler)
	if err != nil {
		return 1
	}
	return executeDesktop(de.Exec, args[1:])
}

func cmdOpen(args []string) int {
	if helpVersion("open", args) {
		return 0
	}
	if len(args) < 1 {
		required("<paths>", "executable open <paths>...")
		return 2
	}
	status := 0
	for _, p := range args {
		m := mimeForPath(p)
		if m == "" {
			status = 1
			continue
		}
		if cmdLaunch(append([]string{m}, p)) != 0 {
			status = 1
		}
	}
	return status
}

func helpVersion(cmd string, args []string) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			fmt.Print(subHelp(cmd))
			return true
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return true
		}
	}
	return false
}

func parseMime(s string) (string, error) {
	if strings.HasPrefix(s, ".") {
		return "", fmt.Errorf("could not figure out the mime type of '%s'", s)
	}
	if strings.Contains(s, ":") {
		pos := strings.IndexByte(s, ':')
		return "", fmt.Errorf("mime parse error: an invalid token was encountered, %X at position %d", s[pos], pos)
	}
	if strings.HasPrefix(s, "/") {
		return "", errors.New("mime parse error: an invalid token was encountered, 2F at position 0")
	}
	if !strings.Contains(s, "/") {
		return "", errors.New("mime parse error: a slash (/) was missing between the type and subtype")
	}
	return s, nil
}

func invalid(arg, msg string) {
	fmt.Fprintf(os.Stderr, "error: Invalid value for '<%s>': %s\n\nFor more information try --help\n", arg, msg)
}

func unexpected(arg, usage string) {
	fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nIf you tried to supply `%s` as a PATTERN use `-- %s`\n\nUSAGE:\n    %s\n\nFor more information try --help\n", arg, arg, arg, usage)
}

func required(arg, usage string) {
	fmt.Fprintf(os.Stderr, "error: The following required arguments were not provided:\n    %s\n\nUSAGE:\n    %s\n\nFor more information try --help\n", arg, usage)
}

func configHome() string {
	if v := os.Getenv("XDG_CONFIG_HOME"); v != "" {
		return v
	}
	if h := os.Getenv("HOME"); h != "" {
		return filepath.Join(h, ".config")
	}
	return "."
}

func dataHomes() []string {
	var dirs []string
	if v := os.Getenv("XDG_DATA_HOME"); v != "" {
		dirs = append(dirs, filepath.Join(v, "applications"))
	} else if h := os.Getenv("HOME"); h != "" {
		dirs = append(dirs, filepath.Join(h, ".local/share/applications"))
	}
	if v := os.Getenv("XDG_DATA_DIRS"); v != "" {
		for _, d := range strings.Split(v, ":") {
			if d != "" {
				dirs = append(dirs, filepath.Join(d, "applications"))
			}
		}
	} else {
		dirs = append(dirs, "/usr/local/share/applications", "/usr/share/applications")
	}
	return dirs
}

func ensureConfig() {
	_ = os.MkdirAll(filepath.Join(configHome(), "handlr"), 0o755)
	hconf := filepath.Join(configHome(), "handlr", "handlr.toml")
	if _, err := os.Stat(hconf); os.IsNotExist(err) {
		_ = os.WriteFile(hconf, []byte("enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n"), 0o644)
	}
	mp := filepath.Join(configHome(), "mimeapps.list")
	if _, err := os.Stat(mp); os.IsNotExist(err) {
		_ = os.WriteFile(mp, nil, 0o644)
	}
}

func readMimeApps() map[string][]string {
	out := map[string][]string{}
	b, err := os.ReadFile(filepath.Join(configHome(), "mimeapps.list"))
	if err != nil {
		return out
	}
	inDefault := false
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasPrefix(line, "[") {
			inDefault = line == "[Default Applications]"
			continue
		}
		if !inDefault || !strings.Contains(line, "=") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		for _, h := range strings.Split(parts[1], ";") {
			if h != "" {
				out[parts[0]] = append(out[parts[0]], h)
			}
		}
	}
	return out
}

func writeMimeApps(apps map[string][]string) {
	var keys []string
	for k := range apps {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var sb strings.Builder
	sb.WriteString("[Added Associations]\n\n[Default Applications]\n")
	for _, k := range keys {
		if len(apps[k]) == 0 {
			continue
		}
		sb.WriteString(k)
		sb.WriteByte('=')
		for _, h := range apps[k] {
			if h != "" {
				sb.WriteString(h)
				sb.WriteByte(';')
			}
		}
		sb.WriteByte('\n')
	}
	_ = os.WriteFile(filepath.Join(configHome(), "mimeapps.list"), []byte(sb.String()), 0o644)
}

func firstValid(list []string) string {
	for _, h := range list {
		if _, err := findDesktop(h); err == nil {
			return h
		}
	}
	return ""
}

func findDesktop(id string) (desktopEntry, error) {
	for _, d := range dataHomes() {
		p := filepath.Join(d, id)
		if de, err := parseDesktop(p, id); err == nil {
			return de, nil
		} else if !os.IsNotExist(err) {
			return desktopEntry{}, err
		}
	}
	return desktopEntry{}, fmt.Errorf("no handlers found for '%s'", id)
}

func parseDesktop(path, id string) (desktopEntry, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return desktopEntry{}, err
	}
	de := desktopEntry{ID: id, Path: path}
	in := false
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "[Desktop Entry]" {
			in = true
			continue
		}
		if strings.HasPrefix(line, "[") {
			in = false
			continue
		}
		if !in || !strings.Contains(line, "=") {
			continue
		}
		kv := strings.SplitN(line, "=", 2)
		switch kv[0] {
		case "Name":
			de.Name = kv[1]
		case "Exec":
			de.Exec = kv[1]
		case "MimeType":
			for _, m := range strings.Split(kv[1], ";") {
				if m != "" {
					de.MimeType = append(de.MimeType, m)
				}
			}
		}
	}
	if de.Exec == "" {
		return desktopEntry{}, fmt.Errorf("malformed desktop entry at %s", path)
	}
	return de, nil
}

func allDesktops() []desktopEntry {
	seen := map[string]bool{}
	var out []desktopEntry
	for _, d := range dataHomes() {
		ents, _ := os.ReadDir(d)
		for _, e := range ents {
			if e.IsDir() || !strings.HasSuffix(e.Name(), ".desktop") || seen[e.Name()] {
				continue
			}
			if de, err := parseDesktop(filepath.Join(d, e.Name()), e.Name()); err == nil {
				seen[e.Name()] = true
				out = append(out, de)
			}
		}
	}
	return out
}

func defaultRows() [][2]string {
	apps := readMimeApps()
	var keys []string
	for k := range apps {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var rows [][2]string
	for _, k := range keys {
		var hs []string
		for _, h := range apps[k] {
			if _, err := findDesktop(h); err == nil {
				hs = append(hs, h)
			}
		}
		if len(hs) > 0 {
			rows = append(rows, [2]string{k, strings.Join(hs, ", ")})
		}
	}
	return rows
}

func systemRows() [][2]string {
	m := map[string][]string{}
	for _, de := range allDesktops() {
		for _, mt := range de.MimeType {
			m[mt] = append(m[mt], de.ID)
		}
	}
	var keys []string
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var rows [][2]string
	for _, k := range keys {
		sort.Strings(m[k])
		rows = append(rows, [2]string{k, strings.Join(m[k], ", ")})
	}
	return rows
}

func printTable(rows [][2]string) {
	if len(rows) == 0 {
		fmt.Println("┌──┐")
		fmt.Println("│  │")
		fmt.Println("└──┘")
		return
	}
	w1, w2 := 0, 0
	for _, r := range rows {
		if len(r[0]) > w1 {
			w1 = len(r[0])
		}
		if len(r[1]) > w2 {
			w2 = len(r[1])
		}
	}
	fmt.Printf("┌%s┬%s┐\n", strings.Repeat("─", w1+2), strings.Repeat("─", w2+2))
	for _, r := range rows {
		fmt.Printf("│ %-*s │ %-*s │\n", w1, r[0], w2, r[1])
	}
	fmt.Printf("└%s┴%s┘\n", strings.Repeat("─", w1+2), strings.Repeat("─", w2+2))
}

func stripExec(s string) string {
	for _, p := range []string{"%f", "%u", "%F", "%U"} {
		s = strings.ReplaceAll(s, p, "")
	}
	fields := shellFields(s)
	var out []string
	for _, f := range fields {
		out = append(out, f)
	}
	return strings.Join(out, " ")
}

func executeDesktop(execLine string, args []string) int {
	fields := shellFields(execLine)
	if len(fields) == 0 {
		return 1
	}
	var cmdArgs []string
	for _, f := range fields[1:] {
		switch f {
		case "%f", "%u", "%F", "%U":
			cmdArgs = append(cmdArgs, args...)
		case "%%":
			cmdArgs = append(cmdArgs, "%")
		case "%i", "%c", "%k":
		default:
			cmdArgs = append(cmdArgs, f)
		}
	}
	c := exec.Command(fields[0], cmdArgs...)
	c.Stdout = os.Stdout
	c.Stderr = os.Stderr
	if err := c.Run(); err != nil {
		return 1
	}
	return 0
}

func shellFields(s string) []string {
	var out []string
	var b strings.Builder
	quote := rune(0)
	esc := false
	inTok := false
	for _, r := range s {
		if esc {
			b.WriteRune(r)
			esc = false
			inTok = true
			continue
		}
		if r == '\\' {
			esc = true
			inTok = true
			continue
		}
		if quote != 0 {
			if r == quote {
				quote = 0
			} else {
				b.WriteRune(r)
			}
			inTok = true
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			inTok = true
			continue
		}
		if r == ' ' || r == '\t' || r == '\n' {
			if inTok {
				out = append(out, b.String())
				b.Reset()
				inTok = false
			}
			continue
		}
		b.WriteRune(r)
		inTok = true
	}
	if inTok {
		out = append(out, b.String())
	}
	return out
}

func mimeForPath(p string) string {
	if strings.HasPrefix(p, "https://") {
		return "x-scheme-handler/https"
	}
	if strings.HasPrefix(p, "http://") {
		return "x-scheme-handler/http"
	}
	return ""
}
