package main

import (
	"archive/tar"
	"archive/zip"
	"compress/gzip"
	"crypto/sha256"
	"crypto/sha512"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"encoding/xml"
	"errors"
	"flag"
	"fmt"
	"html"
	"io"
	"log"
	"mime"
	"mime/multipart"
	"net"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const version = "0.32.0"

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(v string) error {
	*m = append(*m, v)
	return nil
}

type config struct {
	servePath       string
	port            string
	interfaces      string
	verbose         bool
	index           string
	spa             bool
	pretty          bool
	noSymlinks      bool
	hidden          bool
	sortMethod      string
	sortOrder       string
	dirsFirst       bool
	title           string
	routePrefix     string
	randomRoute     bool
	auth            multiFlag
	authFile        string
	upload          bool
	uploadDir       string
	tempDir         string
	chmod           string
	dupMode         string
	mkdir           bool
	rm              bool
	rmDir           string
	enableTar       bool
	enableTarGz     bool
	enableZip       bool
	compress        bool
	headers         multiFlag
	tlsCert         string
	tlsKey          string
	readme          bool
	disableIndex    bool
	webdav          bool
	sizeDisplay     string
	fileExternalURL string
	hideVersion     bool
	hideTheme       bool
	showWget        bool
	singleFile      bool
	creds           []credential
}

type credential struct {
	user string
	kind string
	secret string
}

func main() {
	cfg, special, code := parseArgs()
	if special {
		os.Exit(code)
	}
	if err := run(cfg); err != nil {
		fmt.Fprintln(os.Stderr, "miniserve:", err)
		os.Exit(1)
	}
}

func parseArgs() (config, bool, int) {
	cfg := config{
		port: os.Getenv("MINISERVE_PORT"),
		interfaces: os.Getenv("MINISERVE_INTERFACE"),
		index: os.Getenv("MINISERVE_INDEX"),
		sortMethod: envDefault("MINISERVE_DEFAULT_SORTING_METHOD", "name"),
		sortOrder: envDefault("MINISERVE_DEFAULT_SORTING_ORDER", "desc"),
		dupMode: envDefault("MINISERVE_ON_DUPLICATE_FILES", "error"),
		sizeDisplay: envDefault("MINISERVE_SIZE_DISPLAY", "human"),
		servePath: envDefault("MINISERVE_PATH", "."),
	}
	if cfg.port == "" {
		cfg.port = "8080"
	}
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.BoolVar(&cfg.verbose, "verbose", envBool("MINISERVE_VERBOSE"), "")
	fs.BoolVar(&cfg.verbose, "v", cfg.verbose, "")
	fs.StringVar(&cfg.tempDir, "temp-directory", os.Getenv("MINISERVER_TEMP_UPLOAD_DIRECTORY"), "")
	fs.StringVar(&cfg.index, "index", cfg.index, "")
	fs.BoolVar(&cfg.spa, "spa", envBool("MINISERVE_SPA"), "")
	fs.BoolVar(&cfg.pretty, "pretty-urls", envBool("MINISERVE_PRETTY_URLS"), "")
	fs.StringVar(&cfg.port, "port", cfg.port, "")
	fs.StringVar(&cfg.port, "p", cfg.port, "")
	fs.StringVar(&cfg.interfaces, "interfaces", cfg.interfaces, "")
	fs.StringVar(&cfg.interfaces, "i", cfg.interfaces, "")
	fs.Var(&cfg.auth, "auth", "")
	fs.Var(&cfg.auth, "a", "")
	fs.StringVar(&cfg.authFile, "auth-file", os.Getenv("MINISERVE_AUTH_FILE"), "")
	fs.StringVar(&cfg.routePrefix, "route-prefix", os.Getenv("MINISERVE_ROUTE_PREFIX"), "")
	fs.BoolVar(&cfg.randomRoute, "random-route", envBool("MINISERVE_RANDOM_ROUTE"), "")
	fs.BoolVar(&cfg.noSymlinks, "no-symlinks", envBool("MINISERVE_NO_SYMLINKS"), "")
	fs.BoolVar(&cfg.noSymlinks, "P", cfg.noSymlinks, "")
	fs.BoolVar(&cfg.hidden, "hidden", envBool("MINISERVE_HIDDEN"), "")
	fs.BoolVar(&cfg.hidden, "H", cfg.hidden, "")
	fs.StringVar(&cfg.sortMethod, "default-sorting-method", cfg.sortMethod, "")
	fs.StringVar(&cfg.sortMethod, "S", cfg.sortMethod, "")
	fs.StringVar(&cfg.sortOrder, "default-sorting-order", cfg.sortOrder, "")
	fs.StringVar(&cfg.sortOrder, "O", cfg.sortOrder, "")
	colorScheme := envDefault("MINISERVE_COLOR_SCHEME", "squirrel")
	colorSchemeDark := envDefault("MINISERVE_COLOR_SCHEME_DARK", "archlinux")
	fs.StringVar(&colorScheme, "color-scheme", colorScheme, "")
	fs.StringVar(&colorScheme, "c", colorScheme, "")
	fs.StringVar(&colorSchemeDark, "color-scheme-dark", colorSchemeDark, "")
	fs.StringVar(&colorSchemeDark, "d", colorSchemeDark, "")
	fs.Bool("qrcode", envBool("MINISERVE_QRCODE"), "")
	fs.Bool("q", envBool("MINISERVE_QRCODE"), "")
	uploadVal := optStringFlag{set: envSet("MINISERVE_ALLOWED_UPLOAD_DIR"), value: os.Getenv("MINISERVE_ALLOWED_UPLOAD_DIR")}
	fs.Var(&uploadVal, "upload-files", "")
	fs.Var(&uploadVal, "u", "")
	fs.Int("web-upload-files-concurrency", 0, "")
	fs.StringVar(&cfg.chmod, "chmod", os.Getenv("MINISERVE_CHMOD"), "")
	fs.Bool("directory-size", envBool("MINISERVE_DIRECTORY_SIZE"), "")
	fs.BoolVar(&cfg.mkdir, "mkdir", envBool("MINISERVE_MKDIR_ENABLED"), "")
	fs.BoolVar(&cfg.mkdir, "U", cfg.mkdir, "")
	fs.String("media-type", "", "")
	fs.String("m", "", "")
	fs.String("raw-media-type", "", "")
	fs.String("M", "", "")
	fs.StringVar(&cfg.dupMode, "on-duplicate-files", cfg.dupMode, "")
	fs.StringVar(&cfg.dupMode, "o", cfg.dupMode, "")
	rmVal := optStringFlag{set: envSet("MINISERVE_ALLOWED_RM_DIR"), value: os.Getenv("MINISERVE_ALLOWED_RM_DIR")}
	fs.Var(&rmVal, "rm-files", "")
	fs.Var(&rmVal, "R", "")
	fs.BoolVar(&cfg.enableTar, "enable-tar", envBool("MINISERVE_ENABLE_TAR"), "")
	fs.BoolVar(&cfg.enableTar, "r", cfg.enableTar, "")
	fs.BoolVar(&cfg.enableTarGz, "enable-tar-gz", envBool("MINISERVE_ENABLE_TAR_GZ"), "")
	fs.BoolVar(&cfg.enableTarGz, "g", cfg.enableTarGz, "")
	fs.BoolVar(&cfg.enableZip, "enable-zip", envBool("MINISERVE_ENABLE_ZIP"), "")
	fs.BoolVar(&cfg.enableZip, "z", cfg.enableZip, "")
	fs.BoolVar(&cfg.compress, "compress-response", envBool("MINISERVE_COMPRESS_RESPONSE"), "")
	fs.BoolVar(&cfg.compress, "C", cfg.compress, "")
	fs.BoolVar(&cfg.dirsFirst, "dirs-first", envBool("MINISERVE_DIRS_FIRST"), "")
	fs.BoolVar(&cfg.dirsFirst, "D", cfg.dirsFirst, "")
	fs.StringVar(&cfg.title, "title", os.Getenv("MINISERVE_TITLE"), "")
	fs.StringVar(&cfg.title, "t", cfg.title, "")
	fs.Var(&cfg.headers, "header", "")
	fs.Bool("show-symlink-info", envBool("MINISERVE_SHOW_SYMLINK_INFO"), "")
	fs.Bool("l", envBool("MINISERVE_SHOW_SYMLINK_INFO"), "")
	fs.BoolVar(&cfg.hideVersion, "hide-version-footer", envBool("MINISERVE_HIDE_VERSION_FOOTER"), "")
	fs.BoolVar(&cfg.hideVersion, "F", cfg.hideVersion, "")
	fs.BoolVar(&cfg.hideTheme, "hide-theme-selector", envBool("MINISERVE_HIDE_THEME_SELECTOR"), "")
	fs.BoolVar(&cfg.showWget, "show-wget-footer", envBool("MINISERVE_SHOW_WGET_FOOTER"), "")
	fs.BoolVar(&cfg.showWget, "W", cfg.showWget, "")
	var completion, color1, color2 string
	fs.StringVar(&completion, "print-completions", "", "")
	fs.Bool("print-manpage", false, "")
	fs.StringVar(&cfg.tlsCert, "tls-cert", os.Getenv("MINISERVE_TLS_CERT"), "")
	fs.StringVar(&cfg.tlsKey, "tls-key", os.Getenv("MINISERVE_TLS_KEY"), "")
	fs.BoolVar(&cfg.readme, "readme", envBool("MINISERVE_README"), "")
	fs.BoolVar(&cfg.disableIndex, "disable-indexing", envBool("MINISERVE_DISABLE_INDEXING"), "")
	fs.BoolVar(&cfg.disableIndex, "I", cfg.disableIndex, "")
	fs.BoolVar(&cfg.webdav, "enable-webdav", envBool("MINISERVE_ENABLE_WEBDAV"), "")
	fs.StringVar(&cfg.sizeDisplay, "size-display", cfg.sizeDisplay, "")
	fs.StringVar(&cfg.fileExternalURL, "file-external-url", os.Getenv("MINISERVE_FILE_EXTERNAL_URL"), "")
	fs.StringVar(&color1, "color-scheme-placeholder", "", "")
	fs.StringVar(&color2, "color-scheme-dark-placeholder", "", "")
	help := fs.Bool("help", false, "")
	helpShort := fs.Bool("h", false, "")
	ver := fs.Bool("version", false, "")
	verShort := fs.Bool("V", false, "")

	for _, a := range os.Args[1:] {
		if a == "--help" {
			printLongHelp()
			return cfg, true, 0
		}
		if a == "-h" {
			printShortHelp()
			return cfg, true, 0
		}
		if a == "--version" || a == "-V" {
			fmt.Println("miniserve " + version)
			return cfg, true, 0
		}
		if a == "--print-manpage" {
			printManpage()
			return cfg, true, 0
		}
	}
	argv := preprocessOptionalValues(os.Args[1:])
	if err := fs.Parse(argv); err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n\nFor more information, try '--help'.\n", err)
		return cfg, true, 2
	}
	if *help || *helpShort {
		printShortHelp()
		return cfg, true, 0
	}
	if *ver || *verShort {
		fmt.Println("miniserve " + version)
		return cfg, true, 0
	}
	if completion != "" {
		fmt.Printf("# completion script for miniserve (%s)\n_complete_miniserve() { :; }\n", completion)
		return cfg, true, 0
	}
	if !oneOf(cfg.sortMethod, "name", "size", "date") {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--default-sorting-method <DEFAULT_SORTING_METHOD>'\n  [possible values: name, size, date]\n\nFor more information, try '--help'.\n", cfg.sortMethod)
		return cfg, true, 2
	}
	if !oneOf(cfg.sortOrder, "asc", "desc") {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--default-sorting-order <DEFAULT_SORTING_ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.\n", cfg.sortOrder)
		return cfg, true, 2
	}
	if !oneOf(colorScheme, "squirrel", "archlinux", "zenburn", "monokai") {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--color-scheme <COLOR_SCHEME>'\n  [possible values: squirrel, archlinux, zenburn, monokai]\n\nFor more information, try '--help'.\n", colorScheme)
		return cfg, true, 2
	}
	if !oneOf(colorSchemeDark, "squirrel", "archlinux", "zenburn", "monokai") {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--color-scheme-dark <COLOR_SCHEME_DARK>'\n  [possible values: squirrel, archlinux, zenburn, monokai]\n\nFor more information, try '--help'.\n", colorSchemeDark)
		return cfg, true, 2
	}
	if !oneOf(cfg.dupMode, "error", "overwrite", "rename") {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--on-duplicate-files <ON_DUPLICATE_FILES>'\n  [possible values: error, overwrite, rename]\n\nFor more information, try '--help'.\n", cfg.dupMode)
		return cfg, true, 2
	}
	if !oneOf(cfg.sizeDisplay, "human", "exact") {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--size-display <SIZE_DISPLAY>'\n  [possible values: human, exact]\n\nFor more information, try '--help'.\n", cfg.sizeDisplay)
		return cfg, true, 2
	}
	cfg.upload, cfg.uploadDir = uploadVal.set, uploadVal.value
	cfg.rm, cfg.rmDir = rmVal.set, rmVal.value
	if envAuth := os.Getenv("MINISERVE_AUTH"); envAuth != "" && len(cfg.auth) == 0 {
		cfg.auth = append(cfg.auth, strings.Split(envAuth, ",")...)
	}
	args := fs.Args()
	if len(args) > 1 {
		fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", args[1])
		return cfg, true, 2
	}
	if len(args) == 1 {
		cfg.servePath = args[0]
	}
	return cfg, false, 0
}

type optStringFlag struct{ set bool; value string }
func (o *optStringFlag) String() string { return o.value }
func (o *optStringFlag) Set(v string) error { o.set = true; o.value = v; return nil }
func (o *optStringFlag) IsBoolFlag() bool { return true }

func run(cfg config) error {
	if _, err := strconv.Atoi(cfg.port); err != nil {
		return fmt.Errorf("invalid port %q", cfg.port)
	}
	if cfg.index == "" {
		cfg.index = ""
	}
	if cfg.randomRoute && cfg.routePrefix == "" {
		cfg.routePrefix = "/a1b2c3"
	}
	if cfg.routePrefix != "" && !strings.HasPrefix(cfg.routePrefix, "/") {
		cfg.routePrefix = "/" + cfg.routePrefix
	}
	cfg.routePrefix = strings.TrimRight(cfg.routePrefix, "/")
	abs, err := filepath.Abs(cfg.servePath)
	if err != nil { return err }
	st, err := os.Stat(abs)
	if err != nil { return err }
	cfg.servePath = abs
	cfg.singleFile = !st.IsDir()
	creds, err := loadCreds(cfg)
	if err != nil { return err }
	cfg.creds = creds
	app := &server{cfg: cfg}
	mux := http.NewServeMux()
	mux.HandleFunc("/", app.handle)
	handler := http.Handler(mux)
	if cfg.compress {
		handler = gzipMiddleware(handler)
	}
	addr := ":" + cfg.port
	if cfg.interfaces != "" {
		first := strings.Split(cfg.interfaces, ",")[0]
		addr = strings.TrimSpace(first) + ":" + cfg.port
	}
	proto := "http"
	if cfg.tlsCert != "" && cfg.tlsKey != "" {
		proto = "https"
	}
	fmt.Fprintf(os.Stderr, "miniserve v%s\nBound to %s\nServing path %s\nAvailable at (non-exhaustive list):\n    %s://127.0.0.1:%s%s\n", version, addr, cfg.servePath, proto, cfg.port, cfg.routePrefix)
	if cfg.tlsCert != "" && cfg.tlsKey != "" {
		return http.ListenAndServeTLS(addr, cfg.tlsCert, cfg.tlsKey, handler)
	}
	return http.ListenAndServe(addr, handler)
}

type server struct{ cfg config }

func (s *server) handle(w http.ResponseWriter, r *http.Request) {
	for _, h := range s.cfg.headers {
		if k, v, ok := strings.Cut(h, ":"); ok && w.Header().Get(strings.TrimSpace(k)) == "" {
			w.Header().Set(strings.TrimSpace(k), strings.TrimSpace(v))
		}
	}
	if s.cfg.webdav && r.Method == "OPTIONS" {
		w.Header().Set("dav", "1,2,3,sabredav-partialupdate")
		w.Header().Set("allow", "OPTIONS,PROPFIND")
		w.Header().Set("ms-author-via", "DAV")
		return
	}
	if s.cfg.webdav && r.Method == "PROPFIND" {
		s.handlePropfind(w, r)
		return
	}
	if !s.checkAuth(w, r) { return }
	p := r.URL.Path
	if s.cfg.routePrefix != "" {
		if p == s.cfg.routePrefix {
			http.Redirect(w, r, s.cfg.routePrefix+"/", http.StatusTemporaryRedirect)
			return
		}
		if !strings.HasPrefix(p, s.cfg.routePrefix+"/") {
			s.errorPage(w, http.StatusNotFound, "Route "+p+" could not be found")
			return
		}
		p = strings.TrimPrefix(p, s.cfg.routePrefix)
	}
	if strings.HasPrefix(p, "/__miniserve_internal/") {
		s.internal(w, r)
		return
	}
	if r.Method == "POST" && strings.HasPrefix(p, "/upload") && s.cfg.upload {
		s.handleUpload(w, r)
		return
	}
	if r.Method == "POST" && strings.HasPrefix(p, "/mkdir") && s.cfg.mkdir {
		s.handleMkdir(w, r)
		return
	}
	if (r.Method == "DELETE" || (r.Method == "POST" && strings.HasPrefix(p, "/delete"))) && s.cfg.rm {
		s.handleDelete(w, r)
		return
	}
	if r.Method != "GET" && r.Method != "HEAD" {
		w.Header().Set("Allow", "GET, HEAD")
		s.errorPage(w, http.StatusMethodNotAllowed, "Method not allowed")
		return
	}
	if r.URL.Query().Get("tar") != "" || r.URL.Query().Get("download") == "tar" || strings.HasSuffix(p, ".tar") && s.cfg.enableTar {
		s.archive(w, r, "tar")
		return
	}
	if r.URL.Query().Get("tgz") != "" || r.URL.Query().Get("download") == "tgz" || strings.HasSuffix(p, ".tar.gz") && s.cfg.enableTarGz {
		s.archive(w, r, "tgz")
		return
	}
	if r.URL.Query().Get("zip") != "" || r.URL.Query().Get("download") == "zip" || strings.HasSuffix(p, ".zip") && s.cfg.enableZip {
		s.archive(w, r, "zip")
		return
	}
	s.servePath(w, r, p)
}

func (s *server) servePath(w http.ResponseWriter, r *http.Request, urlPath string) {
	if s.cfg.singleFile {
		if urlPath != "/" && urlPath != "" {
			s.errorPage(w, http.StatusNotFound, "Route "+urlPath+" could not be found")
			return
		}
		s.sendFile(w, r, s.cfg.servePath)
		return
	}
	clean, ok := s.safeRel(urlPath)
	if !ok {
		s.errorPage(w, http.StatusBadRequest, "invalid path")
		return
	}
	fsPath := filepath.Join(s.cfg.servePath, clean)
	info, err := os.Stat(fsPath)
	if err != nil && s.cfg.pretty && filepath.Ext(fsPath) == "" {
		if st, e := os.Stat(fsPath + ".html"); e == nil && !st.IsDir() {
			fsPath += ".html"; info = st; err = nil
		}
	}
	if err != nil && s.cfg.spa && s.cfg.index != "" {
		idx := filepath.Join(s.cfg.servePath, s.cfg.index)
		if st, e := os.Stat(idx); e == nil && !st.IsDir() {
			s.sendFile(w, r, idx); return
		}
	}
	if err != nil {
		s.errorPage(w, http.StatusNotFound, "Route "+urlPath+" could not be found")
		return
	}
	if s.forbiddenPath(clean, info) {
		s.errorPage(w, http.StatusBadRequest, "segment started with invalid character: ('.')")
		return
	}
	if info.IsDir() {
		if !strings.HasSuffix(r.URL.Path, "/") {
			http.Redirect(w, r, r.URL.Path+"/", http.StatusTemporaryRedirect)
			return
		}
		if s.cfg.index != "" {
			idx := filepath.Join(fsPath, s.cfg.index)
			if st, e := os.Stat(idx); e == nil && !st.IsDir() {
				s.sendFile(w, r, idx); return
			}
		}
		if s.cfg.disableIndex {
			s.errorPage(w, http.StatusForbidden, "Directory listing disabled")
			return
		}
		s.listDir(w, r, fsPath, clean)
		return
	}
	s.sendFile(w, r, fsPath)
}

func (s *server) safeRel(p string) (string, bool) {
	u := path.Clean("/" + p)
	rel := strings.TrimPrefix(u, "/")
	if rel == "." { rel = "" }
	if strings.Contains(rel, "\x00") { return "", false }
	return filepath.FromSlash(rel), true
}

func (s *server) forbiddenPath(rel string, info os.FileInfo) bool {
	if s.cfg.noSymlinks && info.Mode()&os.ModeSymlink != 0 { return true }
	if s.cfg.hidden { return false }
	for _, part := range strings.Split(filepath.ToSlash(rel), "/") {
		if strings.HasPrefix(part, ".") && part != "" { return true }
	}
	return false
}

func (s *server) sendFile(w http.ResponseWriter, r *http.Request, p string) {
	name := filepath.Base(p)
	if mt := mime.TypeByExtension(filepath.Ext(name)); mt != "" {
		w.Header().Set("Content-Type", mt)
	}
	w.Header().Set("Content-Disposition", `inline; filename="`+strings.ReplaceAll(name, `"`, "")+`"`)
	http.ServeFile(w, r, p)
}

type entry struct { name, href, size, mod string; isDir bool; bytes int64 }

func (s *server) listDir(w http.ResponseWriter, r *http.Request, dir, rel string) {
	files, err := os.ReadDir(dir)
	if err != nil { s.errorPage(w, http.StatusForbidden, err.Error()); return }
	var entries []entry
	for _, f := range files {
		info, err := f.Info(); if err != nil { continue }
		if s.forbiddenPath(filepath.Join(rel, f.Name()), info) { continue }
		isDir := info.IsDir()
		n := f.Name()
		href := s.publicPath(filepath.ToSlash(path.Join(filepath.ToSlash(rel), n)))
		if isDir { href += "/" }
		if s.cfg.fileExternalURL != "" && !isDir {
			href = strings.TrimRight(s.cfg.fileExternalURL, "/") + "/" + strings.TrimLeft(path.Join(filepath.ToSlash(rel), n), "/")
		}
		entries = append(entries, entry{name:n, href:href, isDir:isDir, bytes:info.Size(), size:s.formatSize(info.Size()), mod:info.ModTime().Format("2006-01-02 15:04:05 -07:00")})
	}
	sort.Slice(entries, func(i,j int) bool {
		if s.cfg.dirsFirst && entries[i].isDir != entries[j].isDir { return entries[i].isDir }
		var less bool
		switch s.cfg.sortMethod {
		case "size": less = entries[i].bytes < entries[j].bytes
		case "date": less = entries[i].mod < entries[j].mod
		default: less = strings.ToLower(entries[i].name) < strings.ToLower(entries[j].name)
		}
		if s.cfg.sortOrder == "desc" { return !less }
		return less
	})
	title := s.pageTitle(r, rel)
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	fmt.Fprint(w, `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="icon" type="image/svg+xml" href="`+s.publicPrefix()+`/__miniserve_internal/favicon.svg"><link rel="stylesheet" href="`+s.publicPrefix()+`/__miniserve_internal/style.css"><title>`+html.EscapeString(title)+`</title></head><body id="drop-container"><div class="container">`)
	fmt.Fprint(w, `<h1 class="title" dir="ltr">`+html.EscapeString(title)+`/</h1><div class="toolbar">`)
	if s.cfg.enableTar { fmt.Fprint(w, `<a href="?download=tar">tar</a> `) }
	if s.cfg.enableTarGz { fmt.Fprint(w, `<a href="?download=tgz">tar.gz</a> `) }
	if s.cfg.enableZip { fmt.Fprint(w, `<a href="?download=zip">zip</a> `) }
	if s.cfg.upload { fmt.Fprint(w, `<form action="`+s.publicPrefix()+`/upload?path=/`+html.EscapeString(filepath.ToSlash(rel))+`" method="post" enctype="multipart/form-data"><input type="file" name="path" multiple><button>upload</button></form>`) }
	if s.cfg.mkdir { fmt.Fprint(w, `<form action="`+s.publicPrefix()+`/mkdir?path=/`+html.EscapeString(filepath.ToSlash(rel))+`" method="post"><input name="name"><button>mkdir</button></form>`) }
	fmt.Fprint(w, `</div><table><thead><tr><th class="name">Name</th><th class="size">Size</th><th class="date">Last modification</th></tr></thead><tbody>`)
	if rel != "" { fmt.Fprint(w, `<tr><td colspan="3"><p><span class="root-chevron">◂</span><a class="root" href="../">Parent directory</a></p></td></tr>`) }
	for _, e := range entries {
		cls := "file"; typ := "entry-type-file"; display := e.name
		size := e.size
		if e.isDir { cls = "directory"; typ = "entry-type-directory"; display += "/"; size = "" }
		fmt.Fprintf(w, `<tr class="%s"><td><p><a class="%s" href="%s">%s</a></p></td><td class="size-cell">%s</td><td class="date-cell"><span>%s </span></td></tr>`, typ, cls, html.EscapeString(e.href), html.EscapeString(display), html.EscapeString(size), html.EscapeString(e.mod))
	}
	fmt.Fprint(w, `</tbody></table>`)
	if s.cfg.readme {
		for _, n := range []string{"README.md", "README.txt"} {
			if b, err := os.ReadFile(filepath.Join(dir, n)); err == nil {
				fmt.Fprint(w, `<section class="readme"><pre>`+html.EscapeString(string(b))+`</pre></section>`)
				break
			}
		}
	}
	if s.cfg.showWget { fmt.Fprintf(w, `<div class="wget">wget -r %s</div>`, html.EscapeString("http://"+r.Host+r.URL.Path)) }
	if !s.cfg.hideVersion { fmt.Fprint(w, `<div class="footer"><div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/`+version+`</div></div>`) }
	fmt.Fprint(w, `</div></body></html>`)
}

func (s *server) pageTitle(r *http.Request, rel string) string {
	if s.cfg.title != "" {
		if rel == "" { return s.cfg.title }
		return s.cfg.title + "/" + filepath.ToSlash(rel)
	}
	if rel == "" { return r.Host }
	return r.Host + "/" + filepath.ToSlash(rel)
}

func (s *server) publicPrefix() string { return s.cfg.routePrefix }

func (s *server) publicPath(rel string) string {
	rel = "/" + strings.TrimLeft(rel, "/")
	if s.cfg.routePrefix == "" {
		return rel
	}
	if rel == "/" {
		return s.cfg.routePrefix + "/"
	}
	return s.cfg.routePrefix + rel
}

func (s *server) formatSize(n int64) string {
	if s.cfg.sizeDisplay == "exact" { return strconv.FormatInt(n, 10) + " B" }
	units := []string{"B","KiB","MiB","GiB","TiB"}
	f := float64(n); i := 0
	for f >= 1024 && i < len(units)-1 { f /= 1024; i++ }
	if i == 0 { return fmt.Sprintf("%d B", n) }
	return fmt.Sprintf("%.1f %s", f, units[i])
}

func (s *server) errorPage(w http.ResponseWriter, code int, msg string) {
	status := fmt.Sprintf("%d %s", code, http.StatusText(code))
	w.Header().Set("Content-Type", "text/html")
	w.WriteHeader(code)
	fmt.Fprintf(w, `<!DOCTYPE html><html><head><meta charset="utf-8"><title>%s</title></head><body><div class="error"><p>%s</p><p>%s</p><div class="error-nav"><a class="error-back" href="%s/">Go back to file listing</a></div>`, status, status, html.EscapeString(msg), s.publicPrefix())
	if !s.cfg.hideVersion { fmt.Fprintf(w, `<p class="footer"><div class="version"><a href="https://github.com/svenstaro/miniserve">miniserve</a>/%s</div></p>`, version) }
	fmt.Fprint(w, `</div></body></html>`)
}

func (s *server) internal(w http.ResponseWriter, r *http.Request) {
	if strings.HasSuffix(r.URL.Path, "favicon.svg") {
		w.Header().Set("Content-Type", "image/svg+xml")
		fmt.Fprint(w, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="8" fill="#222"/><path d="M12 20h40v8H12zm0 16h40v8H12z" fill="#eee"/></svg>`)
		return
	}
	w.Header().Set("Content-Type", "text/css")
	fmt.Fprint(w, `body{font-family:system-ui,sans-serif;margin:2rem;background:#fafafa;color:#222}a{color:#06c;text-decoration:none}table{border-collapse:collapse;width:100%;max-width:1000px}td,th{padding:.45rem;border-bottom:1px solid #ddd;text-align:left}.size,.size-cell{text-align:right}.footer{margin-top:2rem;color:#777}.error{font-family:system-ui;margin:3rem}.toolbar{margin:1rem 0}`)
}

func (s *server) checkAuth(w http.ResponseWriter, r *http.Request) bool {
	if len(s.cfg.creds) == 0 { return true }
	user, pass, ok := r.BasicAuth()
	if ok {
		for _, c := range s.cfg.creds {
			if subtle.ConstantTimeCompare([]byte(user), []byte(c.user)) == 1 && c.match(pass) { return true }
		}
	}
	w.Header().Set("WWW-Authenticate", `Basic realm="miniserve"`)
	s.errorPage(w, http.StatusUnauthorized, "Authentication required")
	return false
}

func (c credential) match(pass string) bool {
	switch c.kind {
	case "sha256":
		sum := sha256.Sum256([]byte(pass)); return subtle.ConstantTimeCompare([]byte(hex.EncodeToString(sum[:])), []byte(c.secret)) == 1
	case "sha512":
		sum := sha512.Sum512([]byte(pass)); return subtle.ConstantTimeCompare([]byte(hex.EncodeToString(sum[:])), []byte(c.secret)) == 1
	default:
		return subtle.ConstantTimeCompare([]byte(pass), []byte(c.secret)) == 1
	}
}

func loadCreds(cfg config) ([]credential, error) {
	var lines []string
	lines = append(lines, cfg.auth...)
	if cfg.authFile != "" {
		b, err := os.ReadFile(cfg.authFile); if err != nil { return nil, err }
		lines = append(lines, strings.Split(string(b), "\n")...)
	}
	var out []credential
	for _, l := range lines {
		l = strings.TrimSpace(l); if l == "" { continue }
		parts := strings.Split(l, ":")
		if len(parts) >= 3 && (parts[1] == "sha256" || parts[1] == "sha512") {
			out = append(out, credential{parts[0], parts[1], strings.Join(parts[2:], ":")})
		} else if len(parts) >= 2 {
			out = append(out, credential{parts[0], "plain", strings.Join(parts[1:], ":")})
		} else {
			out = append(out, credential{parts[0], "plain", ""})
		}
	}
	return out, nil
}

func (s *server) targetFromQuery(r *http.Request, base string) (string, bool) {
	p := r.URL.Query().Get("path")
	if p == "" { p = base }
	rel, ok := s.safeRel(p)
	if !ok { return "", false }
	full := filepath.Join(s.cfg.servePath, rel)
	root, _ := filepath.Abs(s.cfg.servePath)
	abs, _ := filepath.Abs(full)
	return abs, strings.HasPrefix(abs, root)
}

func (s *server) handleUpload(w http.ResponseWriter, r *http.Request) {
	dir, ok := s.targetFromQuery(r, "/"); if !ok { s.errorPage(w, 400, "invalid upload path"); return }
	if st, err := os.Stat(dir); err != nil || !st.IsDir() { s.errorPage(w, 400, "upload path is not a directory"); return }
	if err := r.ParseMultipartForm(1 << 30); err != nil { s.errorPage(w, 400, err.Error()); return }
	count := 0
	for _, fhs := range r.MultipartForm.File {
		for _, fh := range fhs {
			if err := s.saveUpload(dir, fh); err != nil { s.errorPage(w, 409, err.Error()); return }
			count++
		}
	}
	w.Header().Set("Content-Type", "text/plain")
	fmt.Fprintf(w, "Uploaded %d file(s)\n", count)
}

func (s *server) saveUpload(dir string, fh *multipart.FileHeader) error {
	src, err := fh.Open(); if err != nil { return err }; defer src.Close()
	name := filepath.Base(fh.Filename)
	dst := filepath.Join(dir, name)
	if _, err := os.Stat(dst); err == nil {
		switch s.cfg.dupMode {
		case "overwrite":
		case "rename":
			ext := filepath.Ext(name); base := strings.TrimSuffix(name, ext)
			for i := 1; ; i++ {
				c := filepath.Join(dir, fmt.Sprintf("%s-%d%s", base, i, ext))
				if _, err := os.Stat(c); errors.Is(err, os.ErrNotExist) { dst = c; break }
			}
		default:
			return fmt.Errorf("File already exists: %s", name)
		}
	}
	out, err := os.Create(dst); if err != nil { return err }
	_, err = io.Copy(out, src)
	cerr := out.Close()
	if err == nil { err = cerr }
	if err != nil { return err }
	if s.cfg.chmod != "" {
		if m, e := strconv.ParseUint(strings.TrimPrefix(s.cfg.chmod, "0"), 8, 32); e == nil { _ = os.Chmod(dst, os.FileMode(m)) }
	}
	return nil
}

func (s *server) handleMkdir(w http.ResponseWriter, r *http.Request) {
	base, ok := s.targetFromQuery(r, "/"); if !ok { s.errorPage(w, 400, "invalid path"); return }
	_ = r.ParseForm()
	name := r.Form.Get("name"); if name == "" { name = r.Form.Get("path") }
	name = filepath.Base(name)
	if name == "." || name == string(filepath.Separator) || name == "" { s.errorPage(w, 400, "missing directory name"); return }
	if err := os.MkdirAll(filepath.Join(base, name), 0777); err != nil { s.errorPage(w, 500, err.Error()); return }
	fmt.Fprintln(w, "Created directory")
}

func (s *server) handleDelete(w http.ResponseWriter, r *http.Request) {
	target, ok := s.targetFromQuery(r, r.URL.Path); if !ok { s.errorPage(w, 400, "invalid path"); return }
	if target == s.cfg.servePath { s.errorPage(w, 400, "cannot remove root"); return }
	if err := os.RemoveAll(target); err != nil { s.errorPage(w, 500, err.Error()); return }
	fmt.Fprintln(w, "Deleted")
}

func (s *server) archive(w http.ResponseWriter, r *http.Request, kind string) {
	if s.cfg.singleFile { s.sendFile(w, r, s.cfg.servePath); return }
	rel, _ := s.safeRel(r.URL.Path)
	root := filepath.Join(s.cfg.servePath, rel)
	name := filepath.Base(root); if name == "." || name == string(filepath.Separator) { name = filepath.Base(s.cfg.servePath) }
	switch kind {
	case "zip":
		w.Header().Set("Content-Type", "application/zip")
		w.Header().Set("Content-Disposition", `attachment; filename="`+name+`.zip"`)
		zw := zip.NewWriter(w); defer zw.Close()
		filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
			if err != nil || info.IsDir() { return nil }
			relp, _ := filepath.Rel(root, p)
			fw, err := zw.Create(filepath.ToSlash(relp)); if err != nil { return nil }
			f, err := os.Open(p); if err == nil { defer f.Close(); _, _ = io.Copy(fw, f) }
			return nil
		})
	case "tgz":
		w.Header().Set("Content-Type", "application/gzip")
		w.Header().Set("Content-Disposition", `attachment; filename="`+name+`.tar.gz"`)
		gz := gzip.NewWriter(w); defer gz.Close(); writeTar(gz, root)
	default:
		w.Header().Set("Content-Type", "application/x-tar")
		w.Header().Set("Content-Disposition", `attachment; filename="`+name+`.tar"`)
		writeTar(w, root)
	}
}

func writeTar(w io.Writer, root string) {
	tw := tar.NewWriter(w); defer tw.Close()
	filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
		if err != nil { return nil }
		relp, _ := filepath.Rel(root, p); if relp == "." { return nil }
		h, err := tar.FileInfoHeader(info, ""); if err != nil { return nil }
		h.Name = filepath.ToSlash(relp)
		if err := tw.WriteHeader(h); err != nil || info.IsDir() { return nil }
		f, err := os.Open(p); if err == nil { defer f.Close(); _, _ = io.Copy(tw, f) }
		return nil
	})
}

func (s *server) handlePropfind(w http.ResponseWriter, r *http.Request) {
	if r.Header.Get("Depth") == "infinity" {
		w.Header().Set("Content-Type", "application/xml; charset=utf-8")
		w.WriteHeader(403)
		fmt.Fprint(w, `<?xml version="1.0" encoding="utf-8" ?><D:error xmlns:D="DAV:"><D:propfind-finite-depth/></D:error>`)
		return
	}
	type prop struct { XMLName xml.Name `xml:"D:prop"`; DisplayName string `xml:"D:displayname"`; ContentLength int64 `xml:"D:getcontentlength,omitempty"`; ResourceType string `xml:"D:resourcetype"` }
	type resp struct { XMLName xml.Name `xml:"D:response"`; Href string `xml:"D:href"`; Propstat struct{ Prop prop `xml:"D:prop"`; Status string `xml:"D:status"` } `xml:"D:propstat"` }
	type mult struct { XMLName xml.Name `xml:"D:multistatus"`; Xmlns string `xml:"xmlns:D,attr"`; Responses []resp `xml:"D:response"` }
	p := strings.TrimPrefix(r.URL.Path, s.cfg.routePrefix)
	rel, _ := s.safeRel(p)
	full := filepath.Join(s.cfg.servePath, rel)
	var out mult; out.Xmlns = "DAV:"
	add := func(href, full string) {
		st, err := os.Stat(full); if err != nil { return }
		var rr resp; rr.Href = href; rr.Propstat.Status = "HTTP/1.1 200 OK"; rr.Propstat.Prop.DisplayName = filepath.Base(full); rr.Propstat.Prop.ContentLength = st.Size()
		if st.IsDir() { rr.Propstat.Prop.ResourceType = "collection" }
		out.Responses = append(out.Responses, rr)
	}
	add(r.URL.Path, full)
	if r.Header.Get("Depth") == "1" {
		if ds, err := os.ReadDir(full); err == nil {
			for _, d := range ds { add(path.Join(r.URL.Path, d.Name()), filepath.Join(full, d.Name())) }
		}
	}
	w.Header().Set("Content-Type", "application/xml; charset=utf-8")
	w.WriteHeader(207)
	_ = xml.NewEncoder(w).Encode(out)
}

func envDefault(k, d string) string { if v := os.Getenv(k); v != "" { return v }; return d }
func envSet(k string) bool { _, ok := os.LookupEnv(k); return ok }
func envBool(k string) bool { v := strings.ToLower(os.Getenv(k)); return v == "1" || v == "true" || v == "yes" || v == "on" }
func oneOf(v string, opts ...string) bool {
	for _, o := range opts {
		if v == o {
			return true
		}
	}
	return false
}

type gzipResponseWriter struct {
	http.ResponseWriter
	io.Writer
}
func (g gzipResponseWriter) Write(b []byte) (int, error) { return g.Writer.Write(b) }

func gzipMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
			next.ServeHTTP(w, r)
			return
		}
		w.Header().Set("Content-Encoding", "gzip")
		gz := gzip.NewWriter(w)
		defer gz.Close()
		next.ServeHTTP(gzipResponseWriter{ResponseWriter: w, Writer: gz}, r)
	})
}

func preprocessOptionalValues(args []string) []string {
	out := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			out = append(out, args[i:]...)
			break
		}
		if a == "-u" || a == "--upload-files" || a == "-R" || a == "--rm-files" {
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") && hasLaterPositional(args[i+2:]) {
				out = append(out, a+"="+args[i+1])
				i++
				continue
			}
		}
		out = append(out, a)
	}
	return out
}

func hasLaterPositional(args []string) bool {
	for _, a := range args {
		if a == "--" {
			return len(args) > 1
		}
		if !strings.HasPrefix(a, "-") {
			return true
		}
	}
	return false
}

func printShortHelp() {
	fmt.Println(`For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]  Which path to serve [env: MINISERVE_PATH=]

Options:
  -v, --verbose          Be verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]
  -p, --port <PORT>      Port to use [env: MINISERVE_PORT=] [default: 8080]
  -i, --interfaces <INTERFACES>  Interface to listen on [env: MINISERVE_INTERFACE=]
  -a, --auth <AUTH>      Set authentication [env: MINISERVE_AUTH=]
      --auth-file <AUTH_FILE>  Read authentication values from a file
      --route-prefix <ROUTE_PREFIX>  Use a specific route prefix
  -P, --no-symlinks      Hide symlinks in listing and prevent them from being followed
  -H, --hidden           Show hidden files
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]  Enable file uploading
  -U, --mkdir            Enable creating directories
  -R, --rm-files [<ALLOWED_RM_DIR>]  Enable file and directory deletion
  -r, --enable-tar       Enable uncompressed tar archive generation
  -g, --enable-tar-gz    Enable gz-compressed tar archive generation
  -z, --enable-zip       Enable zip archive generation
  -t, --title <TITLE>    Shown instead of host in page title and heading
  -I, --disable-indexing Disable indexing
  -h, --help             Print help (see more with '--help')
  -V, --version          Print version`)
}

func printLongHelp() {
	fmt.Println(`For when you really just want to serve some files over HTTP right now!

Usage: executable [OPTIONS] [PATH]

Arguments:
  [PATH]
          Which path to serve
          
          [env: MINISERVE_PATH=]

Options:
  -v, --verbose
          Be verbose, includes emitting access logs
  --index <INDEX>
          The name of a directory index file to serve, like "index.html"
  --spa
          Activate SPA (Single Page Application) mode
  --pretty-urls
          Activate Pretty URLs mode
  -p, --port <PORT>
          Port to use
          
          [env: MINISERVE_PORT=]
          [default: 8080]
  -i, --interfaces <INTERFACES>
          Interface to listen on
  -a, --auth <AUTH>
          Set authentication
  --auth-file <AUTH_FILE>
          Read authentication values from a file
  --route-prefix <ROUTE_PREFIX>
          Use a specific route prefix
  --random-route
          Generate a random 6-hexdigit route
  -P, --no-symlinks
          Hide symlinks in listing and prevent them from being followed
  -H, --hidden
          Show hidden files
  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>
          Default sorting method for file list [default: name] [possible values: name, size, date]
  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>
          Default sorting order for file list [default: desc] [possible values: asc, desc]
  -c, --color-scheme <COLOR_SCHEME>
          Default color scheme [default: squirrel] [possible values: squirrel, archlinux, zenburn, monokai]
  -d, --color-scheme-dark <COLOR_SCHEME_DARK>
          Default color scheme [default: archlinux] [possible values: squirrel, archlinux, zenburn, monokai]
  -q, --qrcode
          Enable QR code display
  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]
          Enable file uploading (and optionally specify for which directory)
  --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY>
          Configure amount of concurrent uploads when visiting the website [default: 0]
  --chmod <CHMOD>
          Set unix file permissions of uploaded files
  --directory-size
          Enable recursive directory size calculation
  -U, --mkdir
          Enable creating directories
  -m, --media-type <MEDIA_TYPE>
          Specify uploadable media types [possible values: image, audio, video]
  -M, --raw-media-type <MEDIA_TYPE_RAW>
          Directly specify the uploadable media type expression
  -o, --on-duplicate-files <ON_DUPLICATE_FILES>
          What to do if existing files with same name is present during file upload [default: error] [possible values: error, overwrite, rename]
  -R, --rm-files [<ALLOWED_RM_DIR>]
          Enable file and directory deletion
  -r, --enable-tar
          Enable uncompressed tar archive generation
  -g, --enable-tar-gz
          Enable gz-compressed tar archive generation
  -z, --enable-zip
          Enable zip archive generation
  -C, --compress-response
          Compress response
  -D, --dirs-first
          List directories first
  -t, --title <TITLE>
          Shown instead of host in page title and heading
  --header <HEADER>
          Inserts custom headers into the responses
  -l, --show-symlink-info
          Visualize symlinks in directory listing
  -F, --hide-version-footer
          Hide version footer
  --hide-theme-selector
          Hide theme selector
  -W, --show-wget-footer
          If enabled, display a wget command to recursively download the current directory
  --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell, zsh]
  --print-manpage
          Generate man page
  --tls-cert <TLS_CERT>
          TLS certificate to use
  --tls-key <TLS_KEY>
          TLS private key to use
  --readme
          Enable README.md rendering in directories
  -I, --disable-indexing
          Disable indexing
  --enable-webdav
          Enable read-only WebDAV support (PROPFIND requests)
  --size-display <SIZE_DISPLAY>
          Show served file size in exact bytes [default: human] [possible values: human, exact]
  --file-external-url <FILE_EXTERNAL_URL>
          Optional external URL prepended to file links in listings
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version`)
}

func printManpage() {
	fmt.Printf(".TH miniserve 1 \"\" \"miniserve %s\"\n.SH NAME\nminiserve \\- For when you really just want to serve some files over HTTP right now!\n.SH SYNOPSIS\n.B miniserve\n[OPTIONS] [PATH]\n.SH DESCRIPTION\nSmall static HTTP file server.\n", version)
}

func init() {
	log.SetFlags(0)
	_ = base64.StdEncoding
	_ = net.IPv4len
}
