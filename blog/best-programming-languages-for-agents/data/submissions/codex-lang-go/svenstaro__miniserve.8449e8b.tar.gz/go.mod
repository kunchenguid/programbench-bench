module miniserve-reimplementation

go 1.21
