package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const helpText = `# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
` + "`" + `fx` + "`" + ` => Show items in the current directory.
` + "`" + `fx <directory path>` + "`" + ` => Show items in the path.
Both relative and absolute path available.

## Options
` + "`" + `--help` + "`" + ` | ` + "`" + `-h` + "`" + `   => Print help.
` + "`" + `--log` + "`" + `  | ` + "`" + `-l` + "`" + `   => Launch the app, automatically generating a log file.
` + "`" + `--init` + "`" + `          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after ` + "`" + `i` + "`" + `, ` + "`" + `I` + "`" + `, ` + "`" + `c` + "`" + `, ` + "`" + `/` + "`" + `, ` + "`" + `:` + "`" + ` and ` + "`" + `z` + "`" + `.
ZZ                 :Exit without cd to last working directory
                    (if ` + "`" + `match_vim_exit_behavior` + "`" + ` is ` + "`" + `false` + "`" + `).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and ` + "`" + `match_vim_exit_behavior is ` + "`" + `false` + "`" + `).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both ` + "`" + `config.yaml` + "`" + ` and ` + "`" + `config.yml` + "`" + ` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. ` + "`" + `$HOME/Library/Application Support/felix/config.yaml(config.yml)` + "`" + `
2. ` + "`" + `$HOME/.config/felix/config.yaml` + "`" + `

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\AppData\\Roaming\\felix\\config.yaml(config.yml)
trash directory : $PROFILE\\AppData\\Local\\felix\\trash
log files       : $PROFILE\\AppData\\Local\\felix\\log

For more details, visit https://github.com/kyoheiu/felix
`

const initScript = `# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\$\$ command fx "\$@"

  if [ -f "\$RUNTIME_DIR/\$\$" ]; then
    cd "\$(cat "\$RUNTIME_DIR/\$\$")"
    rm "\$RUNTIME_DIR/\$\$"
  fi
}
EOF
  )"
`

type winsize struct {
	row, col       uint16
	xpixel, ypixel uint16
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		run(".", false)
		return
	}
	if args[0] == "-h" || args[0] == "--help" {
		fmt.Print(helpText)
		return
	}
	if args[0] == "--init" {
		if len(args) == 1 {
			fmt.Print(initScript)
		} else {
			fmt.Print(helpText)
		}
		return
	}
	if args[0] == "-l" || args[0] == "--log" {
		if len(args) == 1 {
			run(".", true)
		} else if len(args) == 2 {
			run(args[1], true)
		} else {
			fmt.Print(helpText)
		}
		return
	}
	if len(args) > 1 {
		fmt.Print(helpText)
		return
	}
	run(args[0], false)
}

func run(path string, logging bool) {
	dir, err := filepath.Abs(path)
	if err != nil {
		invalid(path)
		return
	}
	info, err := os.Stat(dir)
	if err != nil {
		invalid(path)
		return
	}
	if !info.IsDir() {
		fmt.Fprintln(os.Stderr, "Path should be directory.")
		fmt.Fprintln(os.Stderr, "`fx -h` shows help.")
		return
	}
	logf := setupData(logging)
	if logf != nil {
		defer logf.Close()
		logLine(logf, "INFO", "===START===")
	}
	rows, cols, ok := termSize()
	if !ok {
		if logf != nil {
			logLine(logf, "ERROR", "Failed to get terminal size")
		}
		fmt.Fprintln(os.Stderr, "Error: Cannot detect terminal size")
		return
	}
	if rows < 4 || cols < 4 {
		if logf != nil {
			logLine(logf, "ERROR", "Too small terminal size (less than 4 columns).")
		}
		fmt.Fprintln(os.Stderr, "Error: Too small window size")
		return
	}
	ui(dir, rows, cols, logf)
}

func invalid(path string) {
	fmt.Fprintln(os.Stdout)
	fmt.Fprintf(os.Stderr, "Invalid path: %s\n", path)
	fmt.Fprintln(os.Stderr, "`fx -h` shows help.")
}

func dataHome() string {
	if v := os.Getenv("XDG_DATA_HOME"); v != "" {
		return v
	}
	if h := os.Getenv("HOME"); h != "" {
		return filepath.Join(h, ".local", "share")
	}
	return "/tmp"
}

func setupData(logging bool) *os.File {
	base := filepath.Join(dataHome(), "felix")
	_ = os.MkdirAll(filepath.Join(base, "Trash"), 0o755)
	if !logging {
		return nil
	}
	logDir := filepath.Join(base, "log")
	_ = os.MkdirAll(logDir, 0o755)
	name := time.Now().Format("2006-01-02-15-04-05") + ".log"
	f, _ := os.Create(filepath.Join(logDir, name))
	return f
}

func logLine(f *os.File, level, msg string) {
	fmt.Fprintf(f, "%s [%s] %s\n", time.Now().Format("15:04:05"), level, msg)
}

func termSize() (int, int, bool) {
	ws := &winsize{}
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, os.Stdout.Fd(), uintptr(syscall.TIOCGWINSZ), uintptr(unsafe.Pointer(ws)))
	if errno != 0 || ws.row == 0 || ws.col == 0 {
		return 0, 0, false
	}
	return int(ws.row), int(ws.col), true
}

type item struct {
	name  string
	isDir bool
	mod   time.Time
	size  int64
	mode  os.FileMode
}

func readItems(dir string, showHidden bool, byTime bool) []item {
	ents, _ := os.ReadDir(dir)
	items := make([]item, 0, len(ents))
	for _, e := range ents {
		name := e.Name()
		if !showHidden && strings.HasPrefix(name, ".") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		items = append(items, item{name: name, isDir: info.IsDir(), mod: info.ModTime(), size: info.Size(), mode: info.Mode()})
	}
	sort.SliceStable(items, func(i, j int) bool {
		if byTime {
			if !items[i].mod.Equal(items[j].mod) {
				return items[i].mod.After(items[j].mod)
			}
		}
		if items[i].isDir != items[j].isDir {
			return items[i].isDir
		}
		return strings.ToLower(items[i].name) < strings.ToLower(items[j].name)
	})
	return items
}

func ui(dir string, rows, cols int, logf *os.File) {
	showHidden, byTime := true, false
	selected := 0
	fmt.Print("\x1b[?25l\x1b[?1049h")
	defer fmt.Print("\x1b[?1049l\x1b[?25h\x1b[0m")
	var cmd strings.Builder
	mode := byte(0)
	for {
		items := readItems(dir, showHidden, byTime)
		if selected >= len(items) {
			selected = len(items) - 1
		}
		if selected < 0 {
			selected = 0
		}
		render(dir, items, selected, rows, cols)
		var b [1]byte
		n, err := os.Stdin.Read(b[:])
		if err != nil || n == 0 {
			return
		}
		c := b[0]
		if mode == ':' || mode == '/' || mode == 'i' || mode == 'I' {
			if c == '\r' || c == '\n' {
				text := cmd.String()
				cmd.Reset()
				if handleLine(&dir, mode, text, selected, items) {
					return
				}
				mode = 0
				continue
			}
			if c == 27 {
				cmd.Reset()
				mode = 0
				continue
			}
			if c == 8 || c == 127 {
				s := cmd.String()
				if len(s) > 0 {
					cmd.Reset()
					cmd.WriteString(s[:len(s)-1])
				}
				continue
			}
			cmd.WriteByte(c)
			continue
		}
		switch c {
		case ':', '/', 'i', 'I':
			mode = c
			cmd.Reset()
		case 'q':
			return
		case 'j':
			if selected < len(items)-1 {
				selected++
			}
		case 'k':
			if selected > 0 {
				selected--
			}
		case 'G':
			selected = len(items) - 1
		case 'g':
			var b2 [1]byte
			os.Stdin.Read(b2[:])
			if b2[0] == 'g' {
				selected = 0
			}
		case 'h':
			parent := filepath.Dir(dir)
			if parent != dir {
				dir = parent
				selected = 0
			}
		case 'l', '\r', '\n':
			if selected < len(items) && items[selected].isDir {
				dir = filepath.Join(dir, items[selected].name)
				selected = 0
			} else if selected < len(items) {
				openFile(filepath.Join(dir, items[selected].name), logf)
			}
		case 127:
			showHidden = !showHidden
		case 't':
			byTime = !byTime
		case 'Z':
			var b2 [1]byte
			os.Stdin.Read(b2[:])
			if b2[0] == 'Z' || b2[0] == 'Q' {
				return
			}
		}
	}
}

func render(dir string, items []item, selected, rows, cols int) {
	fmt.Print("\x1b[2J\x1b[1;1H")
	fmt.Printf("\x1b[38;5;6m %s\x1b[0m", truncate(dir, cols-1))
	limit := rows - 3
	if limit < 0 {
		limit = 0
	}
	for i := 0; i < len(items) && i < limit; i++ {
		it := items[i]
		row := i + 3
		prefix := " "
		if i == selected {
			prefix = ">"
		}
		color := "15"
		if it.isDir {
			color = "14"
		}
		name := it.name
		if it.isDir {
			name += string(os.PathSeparator)
		}
		date := it.mod.Format("2006-01-02 15:04")
		room := cols - len(date) - 6
		if room < 1 {
			room = cols - 3
		}
		fmt.Printf("\x1b[%d;1H%s \x1b[38;5;%sm%s\x1b[0m", row, prefix, color, truncate(name, room))
		if cols > len(date)+2 {
			fmt.Printf("\x1b[%d;%dH\x1b[38;5;8m%s\x1b[0m", row, cols-len(date), date)
		}
	}
	count := len(items)
	status := fmt.Sprintf(" %d/%d", 0, count)
	if count > 0 {
		it := items[selected]
		status = fmt.Sprintf(" %d/%d %s %o", selected+1, count, humanSize(it.size), it.mode.Perm())
	}
	fmt.Printf("\x1b[%d;1H\x1b[7m%s%s\x1b[0m", rows, truncate(status, cols), strings.Repeat(" ", max(0, cols-len(status))))
}

func truncate(s string, n int) string {
	if n <= 0 {
		return ""
	}
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n == 1 {
		return string(r[0])
	}
	return string(r[:n-1]) + "~"
}

func humanSize(n int64) string {
	if n < 1024 {
		return fmt.Sprintf("%dB", n)
	}
	if n < 1024*1024 {
		return fmt.Sprintf("%dKB", (n+1023)/1024)
	}
	return fmt.Sprintf("%dMB", (n+1024*1024-1)/(1024*1024))
}

func handleLine(dir *string, mode byte, text string, selected int, items []item) bool {
	switch mode {
	case ':':
		fields := strings.Fields(text)
		if text == "q" || text == "qa" || text == "quit" {
			return true
		}
		if text == "h" || text == "help" {
			fmt.Print("\x1b[2J\x1b[1;1H")
			fmt.Print(helpText)
			return false
		}
		if len(fields) > 0 && fields[0] == "cd" {
			target := ""
			if len(fields) == 1 {
				target = os.Getenv("HOME")
			} else {
				target = strings.Join(fields[1:], " ")
			}
			if target != "" {
				if !filepath.IsAbs(target) {
					target = filepath.Join(*dir, target)
				}
				if info, err := os.Stat(target); err == nil && info.IsDir() {
					abs, _ := filepath.Abs(target)
					*dir = abs
				}
			}
			return false
		}
		if text != "" {
			c := exec.Command("sh", "-c", text)
			c.Dir = *dir
			_ = c.Run()
		}
	case 'i':
		if text != "" {
			f, _ := os.OpenFile(filepath.Join(*dir, text), os.O_CREATE|os.O_EXCL, 0o644)
			if f != nil {
				f.Close()
			}
		}
	case 'I':
		if text != "" {
			_ = os.Mkdir(filepath.Join(*dir, text), 0o755)
		}
	case '/':
		for i, it := range items {
			if strings.Contains(strings.ToLower(it.name), strings.ToLower(text)) {
				_ = i
				break
			}
		}
	}
	return false
}

func openFile(path string, logf *os.File) {
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = os.Getenv("VISUAL")
	}
	if editor == "" {
		return
	}
	c := exec.Command(editor, path)
	c.Stdin, c.Stdout, c.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := c.Run(); err != nil && logf != nil {
		logLine(logf, "ERROR", err.Error())
	}
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
