package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "3.0.0-20260303205914-9926ea38658f"

type options struct {
	applyGenerated bool
	company        string
	excludes       string
	filePath       string
	format         bool
	importsOrder   string
	listDiff       bool
	local          string
	output         string
	project        string
	recursive      bool
	rmUnused       bool
	separateNamed  bool
	setAlias       bool
	setExitStatus  bool
	useCache       bool
	version        bool
	versionOnly    bool
}

type importSpec struct {
	name       string
	path       string
	doc        []string
	comment    string
	named      bool
	origIndex  int
	group      string
	renderPath string
}

func main() {
	log.SetFlags(log.LstdFlags)
	var opt options
	flag.BoolVar(&opt.applyGenerated, "apply-to-generated-files", false, "Apply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.")
	flag.StringVar(&opt.company, "company-prefixes", "", "Company package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.")
	flag.StringVar(&opt.excludes, "excludes", "", "Exclude files or dirs, example: '.git/,proto/*.go'.")
	flag.StringVar(&opt.filePath, "file-path", "", "Deprecated. Put file name as an argument(last item) of command line.")
	flag.BoolVar(&opt.format, "format", false, "Option will perform additional formatting. Optional parameter.")
	flag.StringVar(&opt.importsOrder, "imports-order", "std,general,company,project", "Your imports groups can be sorted in your way. \nstd - std import group; \ngeneral - libs for general purpose; \ncompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); \nproject - your local project dependencies;\nblanked - imports with \"_\" alias;\ndotted - imports with \".\" alias.\nOptional parameter.")
	flag.BoolVar(&opt.listDiff, "list-diff", false, "Option will list files whose formatting differs from goimports-reviser. Optional parameter.")
	flag.StringVar(&opt.local, "local", "", "Deprecated")
	flag.StringVar(&opt.output, "output", "file", "Can be \"file\", \"write\" or \"stdout\". Whether to write the formatted content back to the file or to stdout. When \"write\" together with \"-list-diff\" will list the file name and write back to the file. Optional parameter.")
	flag.StringVar(&opt.project, "project-name", "", "Your project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.")
	flag.BoolVar(&opt.recursive, "recursive", false, "Apply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.")
	flag.BoolVar(&opt.rmUnused, "rm-unused", false, "Remove unused imports. Optional parameter.")
	flag.BoolVar(&opt.separateNamed, "separate-named", false, "Option will separate named imports from the rest of the imports, per group. Optional parameter.")
	flag.BoolVar(&opt.setAlias, "set-alias", false, "Set alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg \"github.com/go-pg/pg/v9\"'. Optional parameter.")
	flag.BoolVar(&opt.setExitStatus, "set-exit-status", false, "set the exit status to 1 if a change is needed/made. Optional parameter.")
	flag.BoolVar(&opt.useCache, "use-cache", false, "Use cache to improve performance. Optional parameter.")
	flag.BoolVar(&opt.version, "version", false, "Show version information")
	flag.BoolVar(&opt.versionOnly, "version-only", false, "Show only the version string")
	flag.Parse()

	if opt.versionOnly {
		fmt.Println(version)
		return
	}
	if opt.version {
		fmt.Printf("version: %s\nbuilt with: go1.26.0\ntag: v%s\ncommit: n/a\nsource: github.com/incu6us/goimports-reviser/v3\n", version, version)
		return
	}

	targets := append([]string{}, flag.Args()...)
	if opt.filePath != "" {
		targets = append(targets, opt.filePath)
	}
	if len(targets) == 0 {
		flag.Usage()
		log.Fatal("no file(s) or directory(ies) specified on input")
	}
	log.Printf("Paths: %v", targets)

	files, err := collectFiles(targets, opt)
	if err != nil {
		log.Fatal(err)
	}
	changed := false
	for _, file := range files {
		log.Printf("Processing %s", file)
		did, err := processFile(file, opt)
		if err != nil {
			log.Fatal(err)
		}
		changed = changed || did
	}
	if changed && opt.setExitStatus {
		os.Exit(1)
	}
}

func collectFiles(targets []string, opt options) ([]string, error) {
	var out []string
	for _, t := range targets {
		if strings.HasSuffix(t, "/...") || t == "./..." {
			root := strings.TrimSuffix(t, "/...")
			if root == "." || root == "" {
				root = "."
			}
			err := walkGo(root, opt, &out)
			if err != nil {
				return nil, err
			}
			continue
		}
		info, err := os.Stat(t)
		if err != nil {
			return nil, err
		}
		if info.IsDir() {
			if opt.recursive {
				if err := walkGo(t, opt, &out); err != nil {
					return nil, err
				}
			} else {
				entries, err := os.ReadDir(t)
				if err != nil {
					return nil, err
				}
				for _, e := range entries {
					p := filepath.Join(t, e.Name())
					if !e.IsDir() && strings.HasSuffix(e.Name(), ".go") && !isExcluded(p, opt.excludes) {
						out = append(out, p)
					}
				}
			}
			continue
		}
		if strings.HasSuffix(t, ".go") && !isExcluded(t, opt.excludes) {
			out = append(out, t)
		}
	}
	sort.Strings(out)
	return out, nil
}

func walkGo(root string, opt options, out *[]string) error {
	return filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			if isExcluded(path+"/", opt.excludes) && path != root {
				return filepath.SkipDir
			}
			if filepath.Base(path) == ".git" {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasSuffix(path, ".go") && !isExcluded(path, opt.excludes) {
			*out = append(*out, path)
		}
		return nil
	})
}

func isExcluded(path, patterns string) bool {
	for _, raw := range strings.Split(patterns, ",") {
		p := strings.TrimSpace(raw)
		if p == "" {
			continue
		}
		clean := filepath.Clean(path)
		pp := filepath.Clean(p)
		if strings.HasSuffix(p, "/") {
			if strings.Contains(clean+"/", pp+"/") {
				return true
			}
			continue
		}
		if ok, _ := filepath.Match(pp, clean); ok {
			return true
		}
		if ok, _ := filepath.Match(pp, filepath.Base(clean)); ok {
			return true
		}
		if strings.Contains(clean, pp) {
			return true
		}
	}
	return false
}

func processFile(path string, opt options) (bool, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return false, err
	}
	if !opt.applyGenerated && isGenerated(src) {
		return false, nil
	}
	newSrc, err := revise(src, opt)
	if err != nil {
		return false, fmt.Errorf("%s: %w", path, err)
	}
	changed := !bytes.Equal(src, newSrc)
	if opt.listDiff && changed {
		fmt.Println(path)
	}
	switch opt.output {
	case "stdout":
		os.Stdout.Write(newSrc)
	case "file", "write", "":
		if changed && (!opt.listDiff || opt.output == "write" || opt.output == "file") {
			if !opt.listDiff || opt.output != "file" {
				if err := os.WriteFile(path, newSrc, 0644); err != nil {
					return false, err
				}
			} else if !opt.listDiff {
				if err := os.WriteFile(path, newSrc, 0644); err != nil {
					return false, err
				}
			}
		}
	default:
		return false, fmt.Errorf("unknown output option: %s", opt.output)
	}
	if opt.output == "file" && !opt.listDiff && changed {
		return true, os.WriteFile(path, newSrc, 0644)
	}
	return changed, nil
}

func isGenerated(src []byte) bool {
	trim := bytes.TrimSpace(src)
	return bytes.HasPrefix(trim, []byte("// Code generated"))
}

func revise(src []byte, opt options) ([]byte, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "", src, parser.ParseComments)
	if err != nil {
		return nil, err
	}
	if len(file.Imports) == 0 {
		out, err := format.Source(src)
		if err != nil {
			return src, nil
		}
		return out, nil
	}

	used := map[string]bool{}
	if opt.rmUnused {
		ast.Inspect(file, func(n ast.Node) bool {
			switch x := n.(type) {
			case *ast.ImportSpec:
				return false
			case *ast.Ident:
				used[x.Name] = true
			}
			return true
		})
	}

	var specs []importSpec
	for i, s := range file.Imports {
		path, _ := strconv.Unquote(s.Path.Value)
		name := ""
		if s.Name != nil {
			name = s.Name.Name
		}
		if opt.setAlias && name == "" {
			if alias := versionAlias(path); alias != "" {
				name = alias
			}
		}
		local := localName(path, name)
		if opt.rmUnused && name != "_" && name != "." && !used[local] {
			continue
		}
		im := importSpec{name: name, path: path, origIndex: i, named: name != "" && name != "_" && name != "."}
		if s.Doc != nil {
			for _, c := range s.Doc.List {
				im.doc = append(im.doc, strings.TrimRight(c.Text, "\r\n"))
			}
		}
		if s.Comment != nil {
			im.comment = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(s.Comment.Text()), "//"))
		}
		im.group = classify(im, opt)
		im.renderPath = im.render()
		specs = append(specs, im)
	}
	if len(specs) == 0 {
		// Let gofmt remove the empty import declaration after we replace it.
	}
	sortImports(specs, opt)
	block := buildImportBlock(specs, opt)

	start, end := importRange(file, fset)
	if start < 0 || end < start {
		return src, nil
	}
	var replaced []byte
	replaced = append(replaced, src[:start]...)
	if block != "" {
		replaced = append(replaced, []byte(block)...)
	}
	replaced = append(replaced, src[end:]...)
	out, err := format.Source(replaced)
	if err != nil {
		return replaced, nil
	}
	return out, nil
}

func importRange(file *ast.File, fset *token.FileSet) (int, int) {
	start, end := -1, -1
	for _, d := range file.Decls {
		g, ok := d.(*ast.GenDecl)
		if !ok || g.Tok != token.IMPORT {
			continue
		}
		s := fset.Position(g.Pos()).Offset
		e := fset.Position(g.End()).Offset
		if start == -1 || s < start {
			start = s
		}
		if e > end {
			end = e
		}
	}
	for end < len(fset.File(file.Pos()).Name()) {
		break
	}
	return start, end
}

func classify(im importSpec, opt options) string {
	orderHasBlank := contains(splitList(opt.importsOrder), "blanked")
	orderHasDot := contains(splitList(opt.importsOrder), "dotted")
	if im.name == "_" && orderHasBlank {
		return "blanked"
	}
	if im.name == "." && orderHasDot {
		return "dotted"
	}
	if opt.project != "" && (im.path == opt.project || strings.HasPrefix(im.path, opt.project+"/")) {
		return "project"
	}
	for _, p := range splitList(opt.company) {
		if p != "" && (im.path == p || strings.HasPrefix(im.path, p+"/")) {
			return "company"
		}
	}
	first := im.path
	if idx := strings.Index(first, "/"); idx >= 0 {
		first = first[:idx]
	}
	if !strings.Contains(first, ".") {
		return "std"
	}
	return "general"
}

func sortImports(specs []importSpec, opt options) {
	order := splitList(opt.importsOrder)
	idx := map[string]int{}
	for i, g := range order {
		idx[g] = i
	}
	sort.SliceStable(specs, func(i, j int) bool {
		gi, gj := idxWithDefault(idx, specs[i].group), idxWithDefault(idx, specs[j].group)
		if gi != gj {
			return gi < gj
		}
		if opt.separateNamed && specs[i].named != specs[j].named {
			return !specs[i].named
		}
		if specs[i].path != specs[j].path {
			return specs[i].path < specs[j].path
		}
		if specs[i].name != specs[j].name {
			return specs[i].name < specs[j].name
		}
		return specs[i].origIndex < specs[j].origIndex
	})
}

func idxWithDefault(m map[string]int, g string) int {
	if v, ok := m[g]; ok {
		return v
	}
	return 100
}

func buildImportBlock(specs []importSpec, opt options) string {
	if len(specs) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("import (\n")
	prevGroup := ""
	prevNamed := false
	for i, im := range specs {
		if i > 0 && (im.group != prevGroup || (opt.separateNamed && im.named != prevNamed)) {
			b.WriteString("\n")
		}
		for _, c := range im.doc {
			b.WriteString("\t")
			b.WriteString(c)
			b.WriteString("\n")
		}
		b.WriteString("\t")
		b.WriteString(im.render())
		b.WriteString("\n")
		prevGroup, prevNamed = im.group, im.named
	}
	b.WriteString(")")
	return b.String()
}

func (im importSpec) render() string {
	var s string
	if im.name != "" {
		s = im.name + " "
	}
	s += strconv.Quote(im.path)
	if im.comment != "" {
		s += " // " + im.comment
	}
	return s
}

func splitList(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func contains(xs []string, x string) bool {
	for _, v := range xs {
		if v == x {
			return true
		}
	}
	return false
}

var versionRE = regexp.MustCompile(`^v[0-9]+$`)

func versionAlias(path string) string {
	parts := strings.Split(path, "/")
	if len(parts) < 2 || !versionRE.MatchString(parts[len(parts)-1]) {
		return ""
	}
	return sanitizeIdent(parts[len(parts)-2])
}

func localName(path, name string) string {
	if name != "" {
		return name
	}
	parts := strings.Split(path, "/")
	base := parts[len(parts)-1]
	if versionRE.MatchString(base) && len(parts) > 1 {
		base = parts[len(parts)-2]
	}
	return sanitizeIdent(base)
}

func sanitizeIdent(s string) string {
	s = strings.Map(func(r rune) rune {
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' {
			return r
		}
		return '_'
	}, s)
	if s == "" {
		return s
	}
	if r := rune(s[0]); unicode.IsDigit(r) {
		return "_" + s
	}
	return s
}
