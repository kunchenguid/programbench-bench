module pbsqlite

go 1.21
