package main

import (
	"bufio"
	"database/sql"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"

	sqlite3 "github.com/mattn/go-sqlite3"
)

const versionLine = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"
const sourceID = "2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b"

func init() {
	sql.Register("sqlite3_pb", &sqlite3.SQLiteDriver{
		ConnectHook: func(c *sqlite3.SQLiteConn) error {
			_ = c.RegisterFunc("sqlite_version", func() string { return "3.54.0" }, true)
			_ = c.RegisterFunc("sqlite_source_id", func() string { return sourceID }, true)
			return nil
		},
	})
}

type shell struct {
	db        *sql.DB
	dbfile    string
	mode      string
	headers   bool
	sep       string
	rowSep    string
	nullValue string
	bail      bool
	echo      bool
	exitCode  int
	insertTab string
}

func main() {
	sh := &shell{mode: "list", sep: "|", rowSep: "\n"}
	dbfile, sqlArgs, cmds, ok := parseArgs(os.Args[1:], sh)
	if !ok {
		os.Exit(1)
	}
	if dbfile == "" {
		dbfile = ":memory:"
	}
	if err := sh.open(dbfile); err != nil {
		fmt.Fprintf(os.Stderr, "Error: unable to open database %q: %v\n", dbfile, err)
		os.Exit(1)
	}
	defer sh.db.Close()
	for _, c := range cmds {
		if !sh.runInput(c, "command-line option", 0) && sh.bail {
			os.Exit(1)
		}
	}
	if len(sqlArgs) > 0 {
		for i, q := range sqlArgs {
			if !sh.runInput(q, fmt.Sprintf("%s command line argument", ordinal(i+2)), 0) && sh.bail {
				os.Exit(1)
			}
		}
		os.Exit(sh.exitCode)
	}
	if !isTerminal(os.Stdin) {
		sh.runReader(os.Stdin, "line", true)
	}
	os.Exit(sh.exitCode)
}

func parseArgs(args []string, sh *shell) (string, []string, []string, bool) {
	var dbfile string
	var sqlArgs []string
	var cmds []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if dbfile != "" || a == "--" || !strings.HasPrefix(a, "-") || a == "-" {
			if a == "--" && dbfile == "" {
				i++
				if i < len(args) {
					dbfile = args[i]
				}
			} else if dbfile == "" {
				dbfile = a
			} else {
				sqlArgs = append(sqlArgs, a)
			}
			continue
		}
		switch a {
		case "-help", "--help":
			printHelp()
			os.Exit(0)
		case "-version", "--version":
			fmt.Println(versionLine)
			os.Exit(0)
		case "-cmd":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "Error: missing argument to -cmd")
				return "", nil, nil, false
			}
			cmds = append(cmds, args[i])
		case "-header", "--header":
			sh.headers = true
		case "-noheader", "--noheader":
			sh.headers = false
		case "-csv":
			sh.mode = "csv"
			sh.sep = ","
		case "-list":
			sh.mode = "list"
		case "-line":
			sh.mode = "line"
		case "-column":
			sh.mode = "column"
		case "-quote":
			sh.mode = "quote"
		case "-json":
			sh.mode = "json"
		case "-html":
			sh.mode = "html"
		case "-table":
			sh.mode = "table"
		case "-markdown":
			sh.mode = "markdown"
		case "-box":
			sh.mode = "box"
		case "-ascii":
			sh.mode = "ascii"
			sh.sep = "\x1f"
			sh.rowSep = "\x1e"
		case "-tabs":
			sh.mode = "list"
			sh.sep = "\t"
		case "-separator":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "Error: missing argument to -separator")
				return "", nil, nil, false
			}
			sh.sep = unescapeArg(args[i])
		case "-newline":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "Error: missing argument to -newline")
				return "", nil, nil, false
			}
			sh.rowSep = unescapeArg(args[i])
		case "-nullvalue":
			i++
			if i >= len(args) {
				fmt.Fprintln(os.Stderr, "Error: missing argument to -nullvalue")
				return "", nil, nil, false
			}
			sh.nullValue = args[i]
		case "-bail":
			sh.bail = true
		case "-echo":
			sh.echo = true
		case "-batch", "-interactive", "-noinit", "-init", "-readonly", "-ifexists", "-safe", "-unsafe-testing", "-nofollow", "-zip", "-append", "-deserialize", "-maxsize", "-mmap", "-vfs", "-lookaside", "-pagecache", "-stats", "-memtrace", "-pcachetrace", "-vfstrace", "-escape", "-screenwidth", "-no-rowid-in-view":
			if takesValue(a) {
				i += valueCount(a)
				if i >= len(args) {
					fmt.Fprintf(os.Stderr, "Error: missing argument to %s\n", a)
					return "", nil, nil, false
				}
			}
		default:
			fmt.Fprintf(os.Stderr, "./executable: Error: unknown option: %s\nUse -help for a list of options.\n", a)
			return "", nil, nil, false
		}
	}
	return dbfile, sqlArgs, cmds, true
}

func takesValue(opt string) bool {
	switch opt {
	case "-init", "-maxsize", "-mmap", "-vfs", "-escape", "-screenwidth", "-lookaside", "-pagecache":
		return true
	}
	return false
}

func valueCount(opt string) int {
	if opt == "-lookaside" || opt == "-pagecache" {
		return 2
	}
	return 1
}

func (sh *shell) open(name string) error {
	if sh.db != nil {
		sh.db.Close()
	}
	db, err := sql.Open("sqlite3_pb", name)
	if err != nil {
		return err
	}
	if err := db.Ping(); err != nil {
		return err
	}
	sh.db = db
	sh.dbfile = name
	return nil
}

func (sh *shell) runReader(r io.Reader, label string, withLines bool) bool {
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 4096), 1024*1024*20)
	var buf strings.Builder
	lineNo := 0
	ok := true
	for sc.Scan() {
		lineNo++
		line := sc.Text()
		trim := strings.TrimSpace(line)
		if trim == "" && buf.Len() == 0 {
			continue
		}
		if strings.HasPrefix(trim, ".") && buf.Len() == 0 {
			if sh.echo {
				fmt.Println(line)
			}
			if !sh.dot(trim, label, lineNo) {
				ok = false
				if sh.bail {
					break
				}
			}
			continue
		}
		buf.WriteString(line)
		buf.WriteByte('\n')
		if completeSQL(buf.String()) {
			sqlText := buf.String()
			if sh.echo {
				fmt.Print(sqlText)
			}
			ctx := label
			if withLines {
				ctx = fmt.Sprintf("line %d", lineNo)
			}
			if !sh.execSQL(sqlText, ctx) {
				ok = false
				if sh.bail {
					break
				}
			}
			buf.Reset()
		}
	}
	if strings.TrimSpace(buf.String()) != "" {
		if !sh.execSQL(buf.String(), label) {
			ok = false
		}
	}
	return ok
}

func (sh *shell) runInput(input, label string, line int) bool {
	trim := strings.TrimSpace(input)
	if strings.HasPrefix(trim, ".") {
		return sh.dot(trim, label, line)
	}
	return sh.execSQL(input, label)
}

func (sh *shell) execSQL(sqlText, ctx string) bool {
	stmts := splitSQL(sqlText)
	ok := true
	for _, st := range stmts {
		if strings.TrimSpace(st) == "" {
			continue
		}
		if rows, err := sh.db.Query(st); err == nil {
			err = sh.printRows(rows)
			rows.Close()
			if err != nil {
				sh.reportErr(ctx, err)
				ok = false
			}
		} else {
			if _, err2 := sh.db.Exec(st); err2 != nil {
				sh.reportErr(ctx, err)
				ok = false
			}
		}
	}
	if !ok {
		sh.exitCode = 1
	}
	return ok
}

func (sh *shell) reportErr(ctx string, err error) {
	if strings.HasPrefix(ctx, "line ") {
		fmt.Fprintf(os.Stderr, "Parse error near %s: %v\n", ctx, err)
	} else if ctx != "" {
		fmt.Fprintf(os.Stderr, "Parse error in %s: %v\n", ctx, err)
	} else {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
	}
}

func (sh *shell) dot(line, ctx string, lineNo int) bool {
	fields := strings.Fields(line)
	if len(fields) == 0 {
		return true
	}
	cmd := fields[0]
	arg := strings.TrimSpace(strings.TrimPrefix(line, cmd))
	switch cmd {
	case ".quit", ".exit":
		os.Exit(sh.exitCode)
	case ".help":
		fmt.Println(".backup ?DB? FILE        Backup DB (default \"main\") to FILE")
		fmt.Println(".databases             List names and files of attached databases")
		fmt.Println(".dump ?TABLE?          Render database content as SQL")
		fmt.Println(".headers on|off        Turn display of headers on or off")
		fmt.Println(".indexes ?TABLE?       Show names of indexes")
		fmt.Println(".mode MODE             Set output mode")
		fmt.Println(".nullvalue STRING      Use STRING in place of NULL values")
		fmt.Println(".open ?OPTIONS? FILE   Close existing database and reopen FILE")
		fmt.Println(".read FILE             Read input from FILE")
		fmt.Println(".schema ?PATTERN?      Show CREATE statements")
		fmt.Println(".separator COL ?ROW?   Change column and row separators")
		fmt.Println(".tables ?PATTERN?      List names of tables")
	case ".headers", ".header":
		v := strings.ToLower(strings.TrimSpace(arg))
		sh.headers = v == "on" || v == "yes" || v == "1"
	case ".mode":
		if len(fields) > 1 {
			m := strings.ToLower(fields[1])
			switch m {
			case "csv":
				sh.mode, sh.sep = "csv", ","
			case "tabs":
				sh.mode, sh.sep = "list", "\t"
			case "insert":
				sh.mode = "insert"
				if len(fields) > 2 {
					sh.insertTab = fields[2]
				} else {
					sh.insertTab = "table"
				}
			case "list", "line", "column", "quote", "json", "html", "table", "markdown", "box", "ascii":
				sh.mode = m
				if m == "ascii" {
					sh.sep, sh.rowSep = "\x1f", "\x1e"
				}
			default:
				fmt.Fprintf(os.Stderr, "Error: mode should be one of: ascii box column csv html insert json line list markdown quote table tabs\n")
				sh.exitCode = 1
				return false
			}
		}
	case ".separator":
		if len(fields) > 1 {
			sh.sep = unquote(fields[1])
		}
		if len(fields) > 2 {
			sh.rowSep = unquote(fields[2])
		}
	case ".nullvalue":
		sh.nullValue = unquote(arg)
	case ".open":
		if len(fields) > 1 {
			file := fields[len(fields)-1]
			if err := sh.open(file); err != nil {
				fmt.Fprintf(os.Stderr, "Error: unable to open database %q: %v\n", file, err)
				sh.exitCode = 1
				return false
			}
		}
	case ".read":
		if len(fields) < 2 {
			fmt.Fprintln(os.Stderr, "Usage: .read FILE")
			sh.exitCode = 1
			return false
		}
		f, err := os.Open(unquote(fields[1]))
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: cannot open %q\n", fields[1])
			sh.exitCode = 1
			return false
		}
		defer f.Close()
		return sh.runReader(f, "line", true)
	case ".tables":
		return sh.listNames("table", arg)
	case ".indexes", ".indices":
		return sh.indexes(arg)
	case ".schema":
		return sh.schema(arg)
	case ".dump":
		return sh.dump(arg)
	case ".databases":
		rows, err := sh.db.Query("PRAGMA database_list")
		if err != nil {
			sh.reportErr(ctx, err)
			return false
		}
		defer rows.Close()
		for rows.Next() {
			var seq int
			var name, file string
			rows.Scan(&seq, &name, &file)
			fmt.Printf("%d: %s %s\n", seq, name, file)
		}
	case ".show":
		fmt.Printf("        echo: %s\n", onoff(sh.echo))
		fmt.Printf("     headers: %s\n", onoff(sh.headers))
		fmt.Printf("        mode: %s\n", sh.mode)
		fmt.Printf("   nullvalue: %q\n", sh.nullValue)
		fmt.Printf("   separator: %q\n", sh.sep)
	default:
		where := ""
		if lineNo > 0 {
			where = fmt.Sprintf(" near line %d", lineNo)
		}
		fmt.Fprintf(os.Stderr, "Error%s: unknown command or invalid arguments:  \"%s\". Enter \".help\" for help\n", where, cmd)
		sh.exitCode = 1
		return false
	}
	return true
}

func (sh *shell) listNames(kind, pattern string) bool {
	q := "SELECT name FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY 1"
	rows, err := sh.db.Query(q)
	if err != nil {
		sh.reportErr("", err)
		return false
	}
	defer rows.Close()
	var names []string
	pattern = strings.TrimSpace(pattern)
	for rows.Next() {
		var n string
		rows.Scan(&n)
		if pattern == "" || likeSimple(n, pattern) {
			names = append(names, n)
		}
	}
	printNameGrid(names)
	return true
}

func (sh *shell) indexes(table string) bool {
	table = strings.TrimSpace(table)
	q := "SELECT name FROM sqlite_schema WHERE type='index' AND name NOT LIKE 'sqlite_%'"
	var args []any
	if table != "" {
		q += " AND tbl_name=?"
		args = append(args, table)
	}
	q += " ORDER BY 1"
	rows, err := sh.db.Query(q, args...)
	if err != nil {
		sh.reportErr("", err)
		return false
	}
	defer rows.Close()
	var names []string
	for rows.Next() {
		var n string
		rows.Scan(&n)
		names = append(names, n)
	}
	printNameGrid(names)
	return true
}

func (sh *shell) schema(pattern string) bool {
	rows, err := sh.db.Query("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE sql IS NOT NULL ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 WHEN 'view' THEN 2 ELSE 3 END, name")
	if err != nil {
		sh.reportErr("", err)
		return false
	}
	defer rows.Close()
	pattern = strings.TrimSpace(pattern)
	for rows.Next() {
		var typ, name, tbl, sqlText string
		rows.Scan(&typ, &name, &tbl, &sqlText)
		if strings.HasPrefix(name, "sqlite_") {
			continue
		}
		if pattern != "" && !likeSimple(name, pattern) && !likeSimple(tbl, pattern) {
			continue
		}
		fmt.Print(sqlText)
		if typ != "view" && !strings.HasSuffix(strings.TrimSpace(sqlText), ";") {
			fmt.Print(";")
		}
		fmt.Println()
		if typ == "view" {
			if cols := sh.columns(name); len(cols) > 0 {
				fmt.Printf("/* %s(%s) */;\n", name, strings.Join(cols, ","))
			}
		}
	}
	return true
}

func (sh *shell) columns(table string) []string {
	rows, err := sh.db.Query("PRAGMA table_info(" + quoteIdent(table) + ")")
	if err != nil {
		return nil
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var cid int
		var name, typ string
		var notnull int
		var dflt any
		var pk int
		rows.Scan(&cid, &name, &typ, &notnull, &dflt, &pk)
		out = append(out, name)
	}
	return out
}

func (sh *shell) dump(pattern string) bool {
	fmt.Println("PRAGMA foreign_keys=OFF;")
	fmt.Println("BEGIN TRANSACTION;")
	rows, err := sh.db.Query("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'view' THEN 1 WHEN 'index' THEN 2 ELSE 3 END, name")
	if err != nil {
		sh.reportErr("", err)
		return false
	}
	defer rows.Close()
	type obj struct{ typ, name, tbl, sql string }
	var objs []obj
	pattern = strings.TrimSpace(pattern)
	for rows.Next() {
		var o obj
		rows.Scan(&o.typ, &o.name, &o.tbl, &o.sql)
		if pattern == "" || likeSimple(o.name, pattern) || likeSimple(o.tbl, pattern) {
			objs = append(objs, o)
		}
	}
	for _, o := range objs {
		if o.typ == "table" {
			fmt.Print(o.sql)
			if !strings.HasSuffix(strings.TrimSpace(o.sql), ";") {
				fmt.Print(";")
			}
			fmt.Println()
			sh.dumpTable(o.name)
		}
	}
	for _, o := range objs {
		if o.typ != "table" {
			fmt.Print(o.sql)
			if !strings.HasSuffix(strings.TrimSpace(o.sql), ";") {
				fmt.Print(";")
			}
			fmt.Println()
		}
	}
	fmt.Println("COMMIT;")
	return true
}

func (sh *shell) dumpTable(name string) {
	rows, err := sh.db.Query("SELECT * FROM " + quoteIdent(name))
	if err != nil {
		return
	}
	defer rows.Close()
	cols, _ := rows.Columns()
	vals := make([]any, len(cols))
	ptrs := make([]any, len(cols))
	for i := range vals {
		ptrs[i] = &vals[i]
	}
	for rows.Next() {
		rows.Scan(ptrs...)
		parts := make([]string, len(vals))
		for i, v := range vals {
			parts[i] = sqlLiteral(v)
		}
		fmt.Printf("INSERT INTO %s VALUES(%s);\n", dumpIdent(name), strings.Join(parts, ","))
	}
}

func (sh *shell) printRows(rows *sql.Rows) error {
	cols, err := rows.Columns()
	if err != nil {
		return err
	}
	vals := make([]any, len(cols))
	ptrs := make([]any, len(cols))
	for i := range vals {
		ptrs[i] = &vals[i]
	}
	var data [][]string
	var raw [][]any
	for rows.Next() {
		if err := rows.Scan(ptrs...); err != nil {
			return err
		}
		row := make([]string, len(cols))
		rv := make([]any, len(cols))
		for i, v := range vals {
			rv[i] = v
			row[i] = sh.format(v)
		}
		data = append(data, row)
		raw = append(raw, rv)
	}
	if err := rows.Err(); err != nil {
		return err
	}
	switch sh.mode {
	case "csv":
		w := csv.NewWriter(os.Stdout)
		w.UseCRLF = true
		if sh.headers {
			w.Write(cols)
		}
		for _, r := range data {
			w.Write(r)
		}
		w.Flush()
	case "json":
		var arr []map[string]any
		for _, r := range raw {
			m := map[string]any{}
			for i, c := range cols {
				m[c] = jsonValue(r[i])
			}
			arr = append(arr, m)
		}
		if arr == nil {
			arr = []map[string]any{}
		}
		b, _ := json.Marshal(arr)
		fmt.Println(string(b))
	case "line":
		width := 0
		for _, c := range cols {
			if len(c) > width {
				width = len(c)
			}
		}
		for _, r := range data {
			for i, c := range cols {
				fmt.Printf("%*s: %s\n", width, c, r[i])
			}
			fmt.Println()
		}
	case "quote":
		if sh.headers {
			fmt.Println(strings.Join(quoteStringSlice(cols), ","))
		}
		for _, r := range raw {
			parts := make([]string, len(r))
			for i, v := range r {
				parts[i] = quoteMode(v)
			}
			fmt.Println(strings.Join(parts, ","))
		}
	case "insert":
		tab := sh.insertTab
		if tab == "" {
			tab = "table"
		}
		for _, r := range raw {
			parts := make([]string, len(r))
			for i, v := range r {
				parts[i] = sqlLiteral(v)
			}
			fmt.Printf("INSERT INTO %s VALUES(%s);\n", dumpIdent(tab), strings.Join(parts, ","))
		}
	case "html":
		if sh.headers {
			fmt.Println("<TR>")
			for _, c := range cols {
				fmt.Printf("<TH>%s\n", html.EscapeString(c))
			}
			fmt.Println("</TR>")
		}
		for _, r := range data {
			fmt.Println("<TR>")
			for _, v := range r {
				fmt.Printf("<TD>%s\n", html.EscapeString(v))
			}
			fmt.Println("</TR>")
		}
	case "column", "table", "markdown", "box":
		printAligned(cols, data, sh.headers, sh.mode)
	default:
		if sh.headers {
			fmt.Print(strings.Join(cols, sh.sep), sh.rowSep)
		}
		for _, r := range data {
			fmt.Print(strings.Join(r, sh.sep), sh.rowSep)
		}
	}
	return nil
}

func (sh *shell) format(v any) string {
	if v == nil {
		return sh.nullValue
	}
	switch x := v.(type) {
	case []byte:
		return string(x)
	case string:
		return x
	default:
		return fmt.Sprint(x)
	}
}

func printAligned(cols []string, data [][]string, headers bool, mode string) {
	widths := make([]int, len(cols))
	for i, c := range cols {
		widths[i] = displayWidth(c)
	}
	for _, r := range data {
		for i, v := range r {
			if w := displayWidth(v); w > widths[i] {
				widths[i] = w
			}
		}
	}
	if mode == "markdown" {
		fmt.Print("|")
		for i, c := range cols {
			fmt.Printf(" %*s |", widths[i], c)
		}
		fmt.Println()
		fmt.Print("|")
		for _, w := range widths {
			fmt.Print(strings.Repeat("-", w+2), "|")
		}
		fmt.Println()
		for _, r := range data {
			fmt.Print("|")
			for i, v := range r {
				fmt.Printf(" %*s |", widths[i], v)
			}
			fmt.Println()
		}
		return
	}
	if mode == "box" {
		printBoxLine("╭", "┬", "╮", widths, "─")
		printBoxRow("│", cols, widths)
		printBoxLine("╞", "╪", "╡", widths, "═")
		for _, r := range data {
			printBoxRow("│", r, widths)
		}
		printBoxLine("╰", "┴", "╯", widths, "─")
		return
	}
	if mode == "table" {
		printASCIILine("+", "+", "+", widths)
		printASCIIRow(cols, widths)
		printASCIILine("+", "+", "+", widths)
		for _, r := range data {
			printASCIIRow(r, widths)
		}
		printASCIILine("+", "+", "+", widths)
		return
	}
	if headers {
		for i, c := range cols {
			if i > 0 {
				fmt.Print("  ")
			}
			fmt.Printf("%-*s", widths[i], c)
		}
		fmt.Println()
		for i, w := range widths {
			if i > 0 {
				fmt.Print("  ")
			}
			fmt.Print(strings.Repeat("-", w))
		}
		fmt.Println()
	}
	for _, r := range data {
		for i, v := range r {
			if i > 0 {
				fmt.Print("  ")
			}
			fmt.Printf("%*s", widths[i], v)
		}
		fmt.Println()
	}
}

func printBoxLine(l, mid, r string, widths []int, fill string) {
	fmt.Print(l)
	for i, w := range widths {
		if i > 0 {
			fmt.Print(mid)
		}
		fmt.Print(strings.Repeat(fill, w+2))
	}
	fmt.Println(r)
}

func printBoxRow(edge string, vals []string, widths []int) {
	fmt.Print(edge)
	for i, v := range vals {
		fmt.Printf(" %-*s %s", widths[i], v, edge)
	}
	fmt.Println()
}

func printASCIILine(l, mid, r string, widths []int) {
	fmt.Print(l)
	for i, w := range widths {
		if i > 0 {
			fmt.Print(mid)
		}
		fmt.Print(strings.Repeat("-", w+2))
	}
	fmt.Println(r)
}

func printASCIIRow(vals []string, widths []int) {
	fmt.Print("|")
	for i, v := range vals {
		fmt.Printf(" %-*s |", widths[i], v)
	}
	fmt.Println()
}

func printNameGrid(names []string) {
	if len(names) == 0 {
		return
	}
	sort.Strings(names)
	max := 0
	for _, n := range names {
		if len(n) > max {
			max = len(n)
		}
	}
	cols := 80 / (max + 2)
	if cols < 1 {
		cols = 1
	}
	for i, n := range names {
		if i > 0 && i%cols == 0 {
			fmt.Println()
		}
		if cols == 1 || i%cols == cols-1 || i == len(names)-1 {
			fmt.Print(n)
		} else {
			fmt.Printf("%-*s", max+2, n)
		}
	}
	fmt.Println()
}

func completeSQL(s string) bool {
	in := rune(0)
	esc := false
	for _, r := range s {
		if in != 0 {
			if r == in && !esc {
				in = 0
			}
			esc = r == '\\' && !esc
			if r != '\\' {
				esc = false
			}
			continue
		}
		if r == '\'' || r == '"' || r == '`' {
			in = r
			continue
		}
		if r == ';' {
			return true
		}
	}
	return false
}

func splitSQL(s string) []string {
	var out []string
	start := 0
	in := rune(0)
	rs := []rune(s)
	for i, r := range rs {
		if in != 0 {
			if r == in {
				if i+1 < len(rs) && rs[i+1] == in && in == '\'' {
					continue
				}
				in = 0
			}
			continue
		}
		if r == '\'' || r == '"' || r == '`' {
			in = r
		} else if r == ';' {
			out = append(out, string(rs[start:i+1]))
			start = i + 1
		}
	}
	if strings.TrimSpace(string(rs[start:])) != "" {
		out = append(out, string(rs[start:]))
	}
	return out
}

func sqlLiteral(v any) string {
	if v == nil {
		return "NULL"
	}
	switch x := v.(type) {
	case int64, int, float64:
		return fmt.Sprint(x)
	case []byte:
		return "X'" + fmt.Sprintf("%x", x) + "'"
	default:
		return "'" + strings.ReplaceAll(fmt.Sprint(x), "'", "''") + "'"
	}
}

func quoteMode(v any) string {
	if v == nil {
		return "NULL"
	}
	switch x := v.(type) {
	case int64, int, float64:
		return fmt.Sprint(x)
	default:
		return "'" + strings.ReplaceAll(fmt.Sprint(x), "'", "''") + "'"
	}
}

func quoteStringSlice(xs []string) []string {
	out := make([]string, len(xs))
	for i, x := range xs {
		out[i] = "'" + strings.ReplaceAll(x, "'", "''") + "'"
	}
	return out
}

func jsonValue(v any) any {
	switch x := v.(type) {
	case []byte:
		return string(x)
	default:
		return x
	}
}

func quoteIdent(s string) string {
	return "\"" + strings.ReplaceAll(s, "\"", "\"\"") + "\""
}

func dumpIdent(s string) string {
	if s == "" {
		return quoteIdent(s)
	}
	for i, r := range s {
		if i == 0 {
			if !(r == '_' || unicode.IsLetter(r)) {
				return quoteIdent(s)
			}
			continue
		}
		if !(r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r)) {
			return quoteIdent(s)
		}
	}
	return s
}

func unquote(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 {
		if (s[0] == '\'' && s[len(s)-1] == '\'') || (s[0] == '"' && s[len(s)-1] == '"') {
			return s[1 : len(s)-1]
		}
	}
	return unescapeArg(s)
}

func unescapeArg(s string) string {
	s = strings.ReplaceAll(s, `\n`, "\n")
	s = strings.ReplaceAll(s, `\t`, "\t")
	s = strings.ReplaceAll(s, `\r`, "\r")
	return s
}

func likeSimple(s, pat string) bool {
	pat = strings.TrimSpace(pat)
	if pat == "" {
		return true
	}
	if strings.ContainsAny(pat, "*%_?") {
		p := strings.NewReplacer("%", "*", "_", "?", "?", "?").Replace(pat)
		ok, _ := filepath.Match(p, s)
		return ok
	}
	return s == pat
}

func sqlLike(s string) string { return strings.ReplaceAll(s, "'", "''") }

func onoff(b bool) string {
	if b {
		return "on"
	}
	return "off"
}

func ordinal(n int) string {
	if n%100 >= 11 && n%100 <= 13 {
		return fmt.Sprintf("%dth", n)
	}
	switch n % 10 {
	case 1:
		return fmt.Sprintf("%dst", n)
	case 2:
		return fmt.Sprintf("%dnd", n)
	case 3:
		return fmt.Sprintf("%drd", n)
	default:
		return fmt.Sprintf("%dth", n)
	}
}

func displayWidth(s string) int {
	w := 0
	for len(s) > 0 {
		r, size := utf8.DecodeRuneInString(s)
		s = s[size:]
		if unicode.IsPrint(r) {
			w++
		}
	}
	return w
}

func isTerminal(f *os.File) bool {
	st, err := f.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) != 0
}

func printHelp() {
	fmt.Println("Usage: ./executable [OPTIONS] [FILENAME [SQL...]]")
	fmt.Println("FILENAME is the name of an SQLite database. A new database is created")
	fmt.Println("if the file does not previously exist. Defaults to :memory:.")
	fmt.Println("OPTIONS include:")
	fmt.Println("   --                   treat no subsequent arguments as options")
	fmt.Println("   -csv                 set output mode to 'csv'")
	fmt.Println("   -cmd COMMAND         run \"COMMAND\" before reading stdin")
	fmt.Println("   -[no]header          turn headers on or off")
	fmt.Println("   -help                show this message")
	fmt.Println("   -json                set output mode to 'json'")
	fmt.Println("   -list                set output mode to 'list'")
	fmt.Println("   -separator SEP       set output column separator. Default: '|'")
	fmt.Println("   -version             show SQLite version")
}

var _ = strconv.IntSize
var _ = sqlLike
