package main

import (
	"bufio"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)"

type Value struct {
	Null bool
	S    string
	N    float64
	Num  bool
}

func (v Value) Text(nulls string) string {
	if v.Null {
		return nulls
	}
	if v.Num {
		if v.N == float64(int64(v.N)) {
			return strconv.FormatInt(int64(v.N), 10)
		}
		return strconv.FormatFloat(v.N, 'g', -1, 64)
	}
	return v.S
}

type Table struct {
	Name   string
	Schema string
	Cols   []string
	Rows   [][]Value
}

type DB struct {
	Tables map[string]*Table
}

type Shell struct {
	db        DB
	file      string
	mode      string
	headers   bool
	sep       string
	rowSep    string
	nullValue string
	echo      bool
	bail      bool
}

func main() {
	sh := &Shell{db: DB{Tables: map[string]*Table{}}, mode: "list", sep: "|", rowSep: "\n"}
	args := os.Args[1:]
	var cmds []string
	filename := ":memory:"
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help", "-help":
			printHelp()
			return
		case "-version", "--version":
			fmt.Println(version)
			return
		case "-header", "--header":
			sh.headers = true
		case "-noheader", "--noheader":
			sh.headers = false
		case "-csv":
			sh.mode = "csv"
			sh.sep = ","
		case "-column":
			sh.mode = "column"
		case "-box":
			sh.mode = "box"
		case "-table":
			sh.mode = "table"
		case "-line":
			sh.mode = "line"
		case "-list":
			sh.mode = "list"
		case "-json":
			sh.mode = "json"
		case "-quote":
			sh.mode = "quote"
		case "-html":
			sh.mode = "html"
		case "-markdown":
			sh.mode = "markdown"
		case "-tabs":
			sh.mode = "list"
			sh.sep = "\t"
		case "-ascii":
			sh.mode = "list"
			sh.sep = "\x1f"
			sh.rowSep = "\x1e"
		case "-separator":
			i++
			if i < len(args) {
				sh.sep = unescapeArg(args[i])
			}
		case "-newline":
			i++
			if i < len(args) {
				sh.rowSep = unescapeArg(args[i])
			}
		case "-nullvalue":
			i++
			if i < len(args) {
				sh.nullValue = args[i]
			}
		case "-cmd":
			i++
			if i < len(args) {
				cmds = append(cmds, args[i])
			}
		case "-echo":
			sh.echo = true
		case "-bail":
			sh.bail = true
		case "--":
			if i+1 < len(args) {
				filename = args[i+1]
				i++
			}
			if i+1 < len(args) {
				cmds = append(cmds, strings.Join(args[i+1:], " "))
				break
			}
		default:
			if strings.HasPrefix(a, "-") {
				// Accepted but ignored compatibility flags.
				if takesValue(a) && i+1 < len(args) {
					i++
				}
				continue
			}
			filename = a
			if i+1 < len(args) {
				cmds = append(cmds, strings.Join(args[i+1:], " "))
			}
			i = len(args)
		}
	}
	sh.file = filename
	if filename != ":memory:" {
		_ = sh.load(filename)
	}
	var code int
	for _, c := range cmds {
		if err := sh.runScript(c, true); err != nil {
			fmt.Fprintf(os.Stderr, "Parse error in command line argument: %v\n", err)
			code = 1
			if sh.bail {
				break
			}
		}
	}
	if len(cmds) == 0 {
		input, _ := io.ReadAll(os.Stdin)
		if len(input) > 0 {
			if err := sh.runScript(string(input), false); err != nil {
				fmt.Fprintln(os.Stderr, "Parse error:", err)
				code = 1
			}
		}
	}
	if filename != ":memory:" {
		_ = sh.save(filename)
	}
	os.Exit(code)
}

func takesValue(a string) bool {
	switch a {
	case "-init", "-lookaside", "-maxsize", "-mmap", "-pagecache", "-screenwidth", "-vfs", "-nonce", "-escape", "-A":
		return true
	}
	return false
}

func printHelp() {
	fmt.Print(`Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -csv                 set output mode to 'csv'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -[no]header          turn headers on or off
   -help                show this message
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -separator SEP       set output column separator. Default: '|'
   -version             show SQLite version
`)
}

func (sh *Shell) load(path string) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	if len(b) == 0 {
		return nil
	}
	var db DB
	if json.Unmarshal(b, &db) == nil && db.Tables != nil {
		sh.db = db
		return nil
	}
	return nil
}

func (sh *Shell) save(path string) error {
	if path == "" || path == ":memory:" {
		return nil
	}
	b, _ := json.MarshalIndent(sh.db, "", "  ")
	return os.WriteFile(path, b, 0644)
}

func (sh *Shell) runScript(s string, cmdline bool) error {
	for _, stmt := range splitStatements(s) {
		stmt = strings.TrimSpace(stmt)
		if stmt == "" {
			continue
		}
		if sh.echo {
			fmt.Println(stmt)
		}
		if strings.HasPrefix(stmt, ".") {
			if err := sh.dot(stmt); err != nil {
				return err
			}
			continue
		}
		if err := sh.sql(stmt); err != nil {
			return err
		}
	}
	return nil
}

func (sh *Shell) dot(stmt string) error {
	f := fields(stmt)
	if len(f) == 0 {
		return nil
	}
	switch f[0] {
	case ".help":
		printDotHelp()
	case ".quit", ".exit":
		os.Exit(0)
	case ".headers", ".header":
		if len(f) > 1 {
			sh.headers = onoff(f[1])
		}
	case ".mode":
		if len(f) > 1 {
			sh.mode = f[1]
			if f[1] == "csv" {
				sh.sep = ","
			}
		}
	case ".separator":
		if len(f) > 1 {
			sh.sep = f[1]
		}
		if len(f) > 2 {
			sh.rowSep = f[2]
		}
	case ".nullvalue":
		if len(f) > 1 {
			sh.nullValue = f[1]
		}
	case ".print":
		if len(stmt) > len(f[0]) {
			fmt.Println(strings.TrimSpace(stmt[len(f[0]):]))
		}
	case ".tables":
		names := make([]string, 0, len(sh.db.Tables))
		for _, t := range sh.db.Tables {
			names = append(names, t.Name)
		}
		sort.Strings(names)
		if len(names) > 0 {
			fmt.Println(strings.Join(names, "  "))
		}
	case ".schema":
		names := make([]string, 0, len(sh.db.Tables))
		for n := range sh.db.Tables {
			names = append(names, n)
		}
		sort.Strings(names)
		for _, n := range names {
			fmt.Println(sh.db.Tables[n].Schema + ";")
		}
	case ".dump":
		fmt.Println("PRAGMA foreign_keys=OFF;")
		fmt.Println("BEGIN TRANSACTION;")
		names := make([]string, 0, len(sh.db.Tables))
		for n := range sh.db.Tables {
			names = append(names, n)
		}
		sort.Strings(names)
		for _, n := range names {
			t := sh.db.Tables[n]
			fmt.Println(t.Schema + ";")
			for _, r := range t.Rows {
				vals := make([]string, len(r))
				for i, v := range r {
					vals[i] = quoteVal(v)
				}
				fmt.Printf("INSERT INTO %s VALUES(%s);\n", t.Name, strings.Join(vals, ","))
			}
		}
		fmt.Println("COMMIT;")
	case ".version":
		fmt.Println("SQLite " + version)
	case ".read":
		if len(f) < 2 {
			return fmt.Errorf("missing filename")
		}
		b, err := os.ReadFile(f[1])
		if err != nil {
			return err
		}
		return sh.runScript(string(b), false)
	case ".open":
		if len(f) > 1 {
			sh.file = f[len(f)-1]
			sh.db = DB{Tables: map[string]*Table{}}
			_ = sh.load(sh.file)
		}
	case ".databases":
		fmt.Printf("main: %s r/w\n", sh.file)
	default:
		return fmt.Errorf("unknown command or invalid arguments:  \"%s\". Enter \".help\" for help", stmt)
	}
	return nil
}

func printDotHelp() {
	fmt.Print(`.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.version                 Show source, library and compiler versions
`)
}

func (sh *Shell) sql(stmt string) error {
	low := strings.ToLower(strings.TrimSpace(stmt))
	switch {
	case strings.HasPrefix(low, "create table"):
		return sh.createTable(stmt)
	case strings.HasPrefix(low, "insert into"):
		return sh.insert(stmt)
	case strings.HasPrefix(low, "select "):
		cols, rows, err := sh.selectStmt(stmt)
		if err != nil {
			return err
		}
		sh.output(cols, rows)
	case strings.HasPrefix(low, "drop table"):
		parts := strings.Fields(stmt)
		if len(parts) >= 3 {
			delete(sh.db.Tables, strings.ToLower(strings.Trim(parts[2], "`\"[]")))
		}
	case strings.HasPrefix(low, "delete from"):
		parts := strings.Fields(stmt)
		if len(parts) >= 3 {
			if t := sh.db.Tables[strings.ToLower(parts[2])]; t != nil {
				t.Rows = nil
			}
		}
	case strings.HasPrefix(low, "pragma"):
		if strings.Contains(low, "table_info") {
			name := between(stmt, "(", ")")
			t := sh.db.Tables[strings.ToLower(strings.TrimSpace(name))]
			var rows [][]Value
			if t != nil {
				for i, c := range t.Cols {
					rows = append(rows, []Value{num(float64(i)), str(c), str(""), num(0), null(), num(0)})
				}
			}
			sh.output([]string{"cid", "name", "type", "notnull", "dflt_value", "pk"}, rows)
		}
	default:
		// Ignore transaction and vacuum-like statements.
		if low == "begin" || low == "commit" || low == "rollback" || strings.HasPrefix(low, "vacuum") {
			return nil
		}
		return fmt.Errorf("near %q: syntax error", firstWord(stmt))
	}
	return nil
}

func (sh *Shell) createTable(stmt string) error {
	re := regexp.MustCompile(`(?is)create\s+table\s+(?:if\s+not\s+exists\s+)?([^\s(]+)\s*\((.*)\)\s*$`)
	m := re.FindStringSubmatch(stmt)
	if m == nil {
		return fmt.Errorf("near \"table\": syntax error")
	}
	name := cleanIdent(m[1])
	defs := splitCSV(m[2])
	var cols []string
	for _, d := range defs {
		fs := fields(strings.TrimSpace(d))
		if len(fs) > 0 {
			c := strings.ToLower(fs[0])
			if c != "primary" && c != "foreign" && c != "constraint" && c != "unique" && c != "check" {
				cols = append(cols, cleanIdent(fs[0]))
			}
		}
	}
	sh.db.Tables[strings.ToLower(name)] = &Table{Name: name, Schema: strings.TrimSpace(stmt), Cols: cols}
	return nil
}

func (sh *Shell) insert(stmt string) error {
	re := regexp.MustCompile(`(?is)insert\s+into\s+([^\s(]+)(?:\s*\((.*?)\))?\s+values\s*(.*)$`)
	m := re.FindStringSubmatch(stmt)
	if m == nil {
		return fmt.Errorf("near \"insert\": syntax error")
	}
	t := sh.db.Tables[strings.ToLower(cleanIdent(m[1]))]
	if t == nil {
		return fmt.Errorf("no such table: %s", cleanIdent(m[1]))
	}
	target := make([]int, len(t.Cols))
	for i := range target {
		target[i] = i
	}
	if strings.TrimSpace(m[2]) != "" {
		target = nil
		for _, c := range splitCSV(m[2]) {
			idx := -1
			for i, tc := range t.Cols {
				if strings.EqualFold(tc, cleanIdent(c)) {
					idx = i
					break
				}
			}
			if idx < 0 {
				return fmt.Errorf("table %s has no column named %s", t.Name, cleanIdent(c))
			}
			target = append(target, idx)
		}
	}
	vals := strings.TrimSpace(m[3])
	for _, grp := range valueGroups(vals) {
		exprs := splitCSV(grp)
		row := make([]Value, len(t.Cols))
		for i := range row {
			row[i] = null()
		}
		for i, e := range exprs {
			if i < len(target) && target[i] < len(row) {
				row[target[i]] = evalExpr(e, nil, nil)
			}
		}
		t.Rows = append(t.Rows, row)
	}
	return nil
}

func (sh *Shell) selectStmt(stmt string) ([]string, [][]Value, error) {
	stmt = strings.TrimSpace(stmt)
	body := strings.TrimSpace(stmt[len("select "):])
	parts := splitKeyword(body, " from ")
	exprPart := parts[0]
	if len(parts) == 1 {
		return sh.selectNoFrom(exprPart)
	}
	tablePart := strings.TrimSpace(parts[1])
	where := ""
	if p := splitKeyword(tablePart, " where "); len(p) == 2 {
		tablePart, where = p[0], p[1]
	}
	if p := splitKeyword(tablePart, " order by "); len(p) == 2 {
		tablePart = p[0]
	}
	name := cleanIdent(strings.Fields(tablePart)[0])
	if strings.EqualFold(name, "sqlite_master") || strings.EqualFold(name, "sqlite_schema") {
		return sh.selectSQLiteMaster(exprPart, where)
	}
	t := sh.db.Tables[strings.ToLower(name)]
	if t == nil {
		return nil, nil, fmt.Errorf("no such table: %s", name)
	}
	var cols []string
	exprs := splitCSV(exprPart)
	if len(exprs) == 1 && strings.EqualFold(strings.TrimSpace(exprs[0]), "count(*)") {
		n := 0
		for _, r := range t.Rows {
			if where == "" || evalCond(where, t, r) {
				n++
			}
		}
		return []string{"count(*)"}, [][]Value{{num(float64(n))}}, nil
	}
	all := len(exprs) == 1 && strings.TrimSpace(exprs[0]) == "*"
	if all {
		cols = append(cols, t.Cols...)
	} else {
		for _, e := range exprs {
			cols = append(cols, aliasName(e))
		}
	}
	var rows [][]Value
	for _, r := range t.Rows {
		if where != "" && !evalCond(where, t, r) {
			continue
		}
		var out []Value
		if all {
			out = append(out, r...)
		} else {
			for _, e := range exprs {
				out = append(out, evalExpr(stripAlias(e), t, r))
			}
		}
		rows = append(rows, out)
	}
	return cols, rows, nil
}

func (sh *Shell) selectSQLiteMaster(exprPart, where string) ([]string, [][]Value, error) {
	colsAll := []string{"type", "name", "tbl_name", "rootpage", "sql"}
	var raw [][]Value
	names := make([]string, 0, len(sh.db.Tables))
	for n := range sh.db.Tables {
		names = append(names, n)
	}
	sort.Strings(names)
	for i, n := range names {
		t := sh.db.Tables[n]
		raw = append(raw, []Value{str("table"), str(t.Name), str(t.Name), num(float64(i + 2)), str(t.Schema)})
	}
	tmp := &Table{Name: "sqlite_master", Cols: colsAll}
	exprs := splitCSV(exprPart)
	all := len(exprs) == 1 && strings.TrimSpace(exprs[0]) == "*"
	cols := colsAll
	if !all {
		cols = nil
		for _, e := range exprs {
			cols = append(cols, aliasName(e))
		}
	}
	var rows [][]Value
	for _, r := range raw {
		if where != "" && !evalCond(where, tmp, r) {
			continue
		}
		if all {
			rows = append(rows, r)
		} else {
			out := []Value{}
			for _, e := range exprs {
				out = append(out, evalExpr(stripAlias(e), tmp, r))
			}
			rows = append(rows, out)
		}
	}
	return cols, rows, nil
}

func evalCond(cond string, t *Table, row []Value) bool {
	cond = strings.TrimSpace(cond)
	for _, op := range []string{"!=", "<=", ">=", "=", "<", ">"} {
		if p := splitOp(cond, op); len(p) == 2 {
			a := evalExpr(p[0], t, row)
			b := evalExpr(p[1], t, row)
			as, bs := a.Text(""), b.Text("")
			af, ae := strconv.ParseFloat(as, 64)
			bf, be := strconv.ParseFloat(bs, 64)
			if ae == nil && be == nil {
				switch op {
				case "=":
					return af == bf
				case "!=":
					return af != bf
				case "<":
					return af < bf
				case ">":
					return af > bf
				case "<=":
					return af <= bf
				case ">=":
					return af >= bf
				}
			}
			switch op {
			case "=":
				return as == bs
			case "!=":
				return as != bs
			case "<":
				return as < bs
			case ">":
				return as > bs
			case "<=":
				return as <= bs
			case ">=":
				return as >= bs
			}
		}
	}
	return truth(evalExpr(cond, t, row))
}

func splitOp(s, op string) []string {
	q := byte(0)
	for i := 0; i <= len(s)-len(op); i++ {
		c := s[i]
		if q != 0 {
			if c == q {
				q = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			q = c
			continue
		}
		if strings.HasPrefix(s[i:], op) {
			return []string{strings.TrimSpace(s[:i]), strings.TrimSpace(s[i+len(op):])}
		}
	}
	return []string{s}
}

func (sh *Shell) selectNoFrom(exprPart string) ([]string, [][]Value, error) {
	if u := splitKeyword(exprPart, " union all select "); len(u) == 2 {
		c1, r1, _ := sh.selectNoFrom(u[0])
		_, r2, _ := sh.selectNoFrom(u[1])
		return c1, append(r1, r2...), nil
	}
	exprs := splitCSV(exprPart)
	cols := make([]string, len(exprs))
	row := make([]Value, len(exprs))
	for i, e := range exprs {
		cols[i] = aliasName(e)
		row[i] = evalExpr(stripAlias(e), nil, nil)
	}
	return cols, [][]Value{row}, nil
}

func (sh *Shell) output(cols []string, rows [][]Value) {
	switch sh.mode {
	case "csv":
		w := csv.NewWriter(os.Stdout)
		w.UseCRLF = true
		if sh.headers {
			_ = w.Write(cols)
		}
		for _, r := range rows {
			rec := make([]string, len(r))
			for i, v := range r {
				rec[i] = v.Text(sh.nullValue)
			}
			_ = w.Write(rec)
		}
		w.Flush()
	case "json":
		var arr []map[string]string
		for _, r := range rows {
			m := map[string]string{}
			for i, v := range r {
				if i < len(cols) {
					m[cols[i]] = v.Text(sh.nullValue)
				}
			}
			arr = append(arr, m)
		}
		b, _ := json.Marshal(arr)
		fmt.Println(string(b))
	case "line":
		for _, r := range rows {
			for i, v := range r {
				fmt.Printf("%12s = %s\n", cols[i], v.Text(sh.nullValue))
			}
			fmt.Print("\n")
		}
	case "column", "table", "markdown", "box":
		sh.outputTable(cols, rows)
	case "quote":
		if sh.headers {
			fmt.Println(strings.Join(cols, ","))
		}
		for _, r := range rows {
			out := make([]string, len(r))
			for i, v := range r {
				out[i] = quoteVal(v)
			}
			fmt.Println(strings.Join(out, ","))
		}
	case "html":
		for _, r := range rows {
			fmt.Print("<TR>")
			for _, v := range r {
				fmt.Printf("<TD>%s</TD>", htmlEsc(v.Text(sh.nullValue)))
			}
			fmt.Println("</TR>")
		}
	default:
		if sh.headers {
			fmt.Print(strings.Join(cols, sh.sep))
			fmt.Print(sh.rowSep)
		}
		for _, r := range rows {
			out := make([]string, len(r))
			for i, v := range r {
				out[i] = v.Text(sh.nullValue)
			}
			fmt.Print(strings.Join(out, sh.sep))
			fmt.Print(sh.rowSep)
		}
	}
}

func (sh *Shell) outputTable(cols []string, rows [][]Value) {
	width := make([]int, len(cols))
	for i, c := range cols {
		width[i] = len(c)
	}
	for _, r := range rows {
		for i, v := range r {
			if l := len(v.Text(sh.nullValue)); i < len(width) && l > width[i] {
				width[i] = l
			}
		}
	}
	if sh.mode == "markdown" {
		fmt.Print("|")
		for i, c := range cols {
			fmt.Printf(" %-*s |", width[i], c)
		}
		fmt.Println()
		fmt.Print("|")
		for _, w := range width {
			fmt.Print(strings.Repeat("-", w+2) + "|")
		}
		fmt.Println()
		for _, r := range rows {
			fmt.Print("|")
			for i, v := range r {
				fmt.Printf(" %-*s |", width[i], v.Text(sh.nullValue))
			}
			fmt.Println()
		}
		return
	}
	if sh.headers {
		for i, c := range cols {
			if i > 0 {
				fmt.Print("  ")
			}
			fmt.Printf("%-*s", width[i], c)
		}
		fmt.Println()
		for i, w := range width {
			if i > 0 {
				fmt.Print("  ")
			}
			fmt.Print(strings.Repeat("-", w))
		}
		fmt.Println()
	}
	for _, r := range rows {
		for i, v := range r {
			if i > 0 {
				fmt.Print("  ")
			}
			fmt.Printf("%-*s", width[i], v.Text(sh.nullValue))
		}
		fmt.Println()
	}
}

func evalExpr(expr string, t *Table, row []Value) Value {
	expr = strings.TrimSpace(stripAlias(expr))
	if expr == "" {
		return null()
	}
	low := strings.ToLower(expr)
	if low == "null" {
		return null()
	}
	if low == "sqlite_version()" {
		return str("3.54.0")
	}
	if strings.HasPrefix(low, "upper(") {
		return str(strings.ToUpper(evalExpr(inner(expr), t, row).Text("")))
	}
	if strings.HasPrefix(low, "lower(") {
		return str(strings.ToLower(evalExpr(inner(expr), t, row).Text("")))
	}
	if strings.HasPrefix(low, "length(") {
		return num(float64(len(evalExpr(inner(expr), t, row).Text(""))))
	}
	if len(expr) >= 2 && expr[0] == '\'' && expr[len(expr)-1] == '\'' {
		return str(strings.ReplaceAll(expr[1:len(expr)-1], "''", "'"))
	}
	if len(expr) >= 2 && expr[0] == '"' && expr[len(expr)-1] == '"' {
		return str(expr[1 : len(expr)-1])
	}
	if f, err := strconv.ParseFloat(expr, 64); err == nil {
		return num(f)
	}
	if t != nil {
		clean := cleanIdent(expr)
		for i, c := range t.Cols {
			if strings.EqualFold(c, clean) && i < len(row) {
				return row[i]
			}
		}
	}
	if strings.ContainsAny(expr, "+-*/%=<>") {
		return evalSimpleMath(expr, t, row)
	}
	return str(expr)
}

type parser struct {
	toks []string
	pos  int
	t    *Table
	row  []Value
}

func evalSimpleMath(s string, t *Table, row []Value) Value {
	p := parser{toks: tokenize(s), t: t, row: row}
	v := p.compare()
	return num(v)
}

func (p *parser) compare() float64 {
	left := p.expr()
	if p.pos < len(p.toks) {
		op := p.toks[p.pos]
		if op == "=" || op == "==" || op == "<" || op == ">" || op == "<=" || op == ">=" || op == "!=" {
			p.pos++
			right := p.expr()
			ok := false
			switch op {
			case "=", "==":
				ok = left == right
			case "<":
				ok = left < right
			case ">":
				ok = left > right
			case "<=":
				ok = left <= right
			case ">=":
				ok = left >= right
			case "!=":
				ok = left != right
			}
			if ok {
				return 1
			}
			return 0
		}
	}
	return left
}
func (p *parser) expr() float64 {
	v := p.term()
	for p.pos < len(p.toks) && (p.toks[p.pos] == "+" || p.toks[p.pos] == "-") {
		op := p.toks[p.pos]
		p.pos++
		r := p.term()
		if op == "+" {
			v += r
		} else {
			v -= r
		}
	}
	return v
}
func (p *parser) term() float64 {
	v := p.factor()
	for p.pos < len(p.toks) && (p.toks[p.pos] == "*" || p.toks[p.pos] == "/" || p.toks[p.pos] == "%") {
		op := p.toks[p.pos]
		p.pos++
		r := p.factor()
		if op == "*" {
			v *= r
		} else if op == "/" {
			if r != 0 {
				v = float64(int64(v) / int64(r))
			}
		} else if r != 0 {
			v = float64(int64(v) % int64(r))
		}
	}
	return v
}
func (p *parser) factor() float64 {
	if p.pos >= len(p.toks) {
		return 0
	}
	tok := p.toks[p.pos]
	p.pos++
	if tok == "(" {
		v := p.compare()
		if p.pos < len(p.toks) && p.toks[p.pos] == ")" {
			p.pos++
		}
		return v
	}
	if tok == "-" {
		return -p.factor()
	}
	if f, err := strconv.ParseFloat(tok, 64); err == nil {
		return f
	}
	v := evalExpr(tok, p.t, p.row)
	f, _ := strconv.ParseFloat(v.Text("0"), 64)
	return f
}

func tokenize(s string) []string {
	var out []string
	for i := 0; i < len(s); {
		c := s[i]
		if unicode.IsSpace(rune(c)) {
			i++
			continue
		}
		if strings.ContainsRune("()+-*/%", rune(c)) {
			out = append(out, string(c))
			i++
			continue
		}
		if strings.ContainsRune("=<>!", rune(c)) {
			j := i + 1
			if j < len(s) && s[j] == '=' {
				j++
			}
			out = append(out, s[i:j])
			i = j
			continue
		}
		j := i
		for j < len(s) && !unicode.IsSpace(rune(s[j])) && !strings.ContainsRune("()+-*/%=<>!", rune(s[j])) {
			j++
		}
		out = append(out, s[i:j])
		i = j
	}
	return out
}

func splitStatements(s string) []string {
	var out []string
	var b strings.Builder
	quote := rune(0)
	sc := bufio.NewScanner(strings.NewReader(s))
	sc.Split(bufio.ScanRunes)
	for sc.Scan() {
		r := []rune(sc.Text())[0]
		if quote != 0 {
			b.WriteRune(r)
			if r == quote {
				quote = 0
			}
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			b.WriteRune(r)
			continue
		}
		if r == ';' {
			out = append(out, b.String())
			b.Reset()
			continue
		}
		b.WriteRune(r)
	}
	if strings.TrimSpace(b.String()) != "" {
		out = append(out, b.String())
	}
	return out
}

func splitCSV(s string) []string {
	var out []string
	start := 0
	depth := 0
	quote := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			quote = c
			continue
		}
		if c == '(' {
			depth++
		} else if c == ')' {
			depth--
		} else if c == ',' && depth == 0 {
			out = append(out, strings.TrimSpace(s[start:i]))
			start = i + 1
		}
	}
	out = append(out, strings.TrimSpace(s[start:]))
	return out
}

func valueGroups(s string) []string {
	var out []string
	depth := 0
	start := -1
	quote := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		if quote != 0 {
			if c == quote {
				quote = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			quote = c
			continue
		}
		if c == '(' {
			if depth == 0 {
				start = i + 1
			}
			depth++
		} else if c == ')' {
			depth--
			if depth == 0 && start >= 0 {
				out = append(out, s[start:i])
			}
		}
	}
	return out
}

func splitKeyword(s, kw string) []string {
	low := strings.ToLower(s)
	q := byte(0)
	depth := 0
	for i := 0; i <= len(s)-len(kw); i++ {
		c := s[i]
		if q != 0 {
			if c == q {
				q = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			q = c
			continue
		}
		if c == '(' {
			depth++
		} else if c == ')' {
			depth--
		}
		if depth == 0 && strings.HasPrefix(low[i:], kw) {
			return []string{strings.TrimSpace(s[:i]), strings.TrimSpace(s[i+len(kw):])}
		}
	}
	return []string{s}
}

func aliasName(e string) string {
	p := splitKeyword(e, " as ")
	if len(p) == 2 {
		return cleanIdent(p[1])
	}
	fs := fields(e)
	if len(fs) > 1 {
		return cleanIdent(fs[len(fs)-1])
	}
	return strings.TrimSpace(e)
}
func stripAlias(e string) string {
	p := splitKeyword(e, " as ")
	if len(p) == 2 {
		return p[0]
	}
	return e
}
func fields(s string) []string   { return strings.Fields(s) }
func cleanIdent(s string) string { return strings.Trim(strings.TrimSpace(s), "`\"[]") }
func firstWord(s string) string {
	f := strings.Fields(s)
	if len(f) > 0 {
		return f[0]
	}
	return ""
}
func inner(s string) string {
	i := strings.Index(s, "(")
	j := strings.LastIndex(s, ")")
	if i >= 0 && j > i {
		return s[i+1 : j]
	}
	return ""
}
func between(s, a, b string) string {
	i := strings.Index(s, a)
	j := strings.LastIndex(s, b)
	if i >= 0 && j > i {
		return s[i+1 : j]
	}
	return ""
}
func onoff(s string) bool {
	s = strings.ToLower(s)
	return s == "on" || s == "yes" || s == "1" || s == "true"
}
func truth(v Value) bool {
	if v.Null {
		return false
	}
	if v.Num {
		return v.N != 0
	}
	return v.S != "" && v.S != "0"
}
func null() Value         { return Value{Null: true} }
func str(s string) Value  { return Value{S: s} }
func num(f float64) Value { return Value{N: f, Num: true} }
func quoteVal(v Value) string {
	if v.Null {
		return "NULL"
	}
	if v.Num {
		return v.Text("")
	}
	return "'" + strings.ReplaceAll(v.S, "'", "''") + "'"
}
func htmlEsc(s string) string {
	r := strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", "\"", "&quot;")
	return r.Replace(s)
}
func unescapeArg(s string) string {
	s = strings.ReplaceAll(s, `\n`, "\n")
	s = strings.ReplaceAll(s, `\t`, "\t")
	return s
}

func init() {
	_ = filepath.Separator
}
