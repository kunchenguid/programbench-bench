package main

import (
	"bufio"
	"crypto/sha1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "0.2.7"

type Config struct {
	Name                 string
	Tagline              string
	URL                  string
	HTTPS                *bool
	Footer               string
	Language             string
	Pagination           int
	ContentPath          string
	TemplatesPath        string
	StaticPath           string
	MediaPath            string
	DefaultDateFormat    string
	EnableSearch         bool
	EnableRelatedContent bool
	TOC                  bool
	JSONFeed             bool
	ShowNextPrevLinks    bool
	PublishMD            bool
	BuildSitemap         bool
	PublishURLsJSON      bool
	EnableShortcodes     bool
	Colorscheme          string
	Theme                string
	PagesTitle           string
	TagsTitle            string
	ArchivesTitle        string
	StreamsTitle         string
	SeriesTitle          string
	AuthorsTitle         string
	SearchTitle          string
}

type Content struct {
	Source      string
	Rel         string
	Title       string
	Slug        string
	Description string
	Date        *time.Time
	Tags        []string
	Authors     []string
	Series      []string
	Streams     []string
	IsPage      bool
	Body        string
	HTML        string
	URL         string
}

func defaultConfig() Config {
	return Config{
		Name: "Home", Tagline: "", Footer: `<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>`,
		Language: "en", Pagination: 10, ContentPath: "content", TemplatesPath: "templates", StaticPath: "static", MediaPath: "media",
		DefaultDateFormat: "%b %e, %Y", EnableRelatedContent: true, SearchTitle: "Search", BuildSitemap: true, PublishURLsJSON: true,
		EnableShortcodes: true, ShowNextPrevLinks: true, PagesTitle: "Pages", TagsTitle: "Tags", ArchivesTitle: "Archive",
		StreamsTitle: "Streams", SeriesTitle: "Series", AuthorsTitle: "Authors", Colorscheme: "default",
	}
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 {
		printHelp()
		return nil
	}
	opts := map[string]string{}
	flags := map[string]bool{}
	var pos []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printHelp()
			return nil
		case "-V", "--version":
			fmt.Println("marmite " + version)
			return nil
		case "-v", "-vv", "-vvv", "-vvvv", "--verbose", "-e", "-p":
			flags[a] = true
		case "-w", "--watch", "--serve", "--init-templates", "--generate-config", "--init-site", "--force", "--shortcodes", "--show-urls":
			flags[a] = true
		case "--enable-search", "--enable-related-content", "--https", "--toc", "--json-feed", "--show-next-prev-links", "--publish-md", "--build-sitemap", "--publish-urls-json", "--enable-shortcodes", "--skip-image-resize":
			if i+1 < len(args) {
				i++
				opts[a] = args[i]
			}
		case "-c", "--config", "--bind", "--start-theme", "--set-theme", "--new", "-t", "--name", "--tagline", "--url", "--footer", "--language", "--pagination", "--content-path", "--templates-path", "--static-path", "--media-path", "--default-date-format", "--colorscheme", "--source-repository", "--image-provider", "--theme", "--shortcode-pattern":
			if i+1 >= len(args) {
				return fmt.Errorf("error: a value is required for '%s'", a)
			}
			i++
			opts[a] = args[i]
		default:
			if strings.HasPrefix(a, "-") {
				return fmt.Errorf("error: unexpected argument '%s' found\n\nFor more information, try '--help'.", a)
			}
			pos = append(pos, a)
		}
	}
	if len(pos) == 0 {
		return fmt.Errorf("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.")
	}
	input := pos[0]
	output := filepath.Join(input, "site")
	if len(pos) > 1 {
		output = pos[1]
	}
	cfg := loadConfig(input, first(opts["--config"], opts["-c"], "marmite.yaml"))
	applyOpts(&cfg, opts)
	switch {
	case flags["--generate-config"]:
		if err := os.MkdirAll(input, 0755); err != nil {
			return err
		}
		p := filepath.Join(input, "marmite.yaml")
		if err := os.WriteFile(p, []byte(configYAML()), 0644); err != nil {
			return err
		}
		fmt.Fprintf(os.Stderr, "[%s INFO  marmite::config] Config file generated: %s\n", time.Now().UTC().Format(time.RFC3339), p)
		return nil
	case flags["--init-site"]:
		return initSite(input)
	case flags["--init-templates"]:
		return initTemplates(input, cfg)
	case opts["--new"] != "":
		return newContent(input, opts["--new"], flags["-p"], opts["-t"])
	case flags["--shortcodes"]:
		printShortcodes(cfg)
		return nil
	case flags["--show-urls"]:
		contents, _ := readContents(input, cfg)
		urls := buildURLs(contents, cfg)
		b, _ := json.MarshalIndent(urls, "", "  ")
		fmt.Println(string(b))
		return nil
	case flags["--serve"]:
		if err := buildSite(input, output, cfg); err != nil {
			return err
		}
		bind := first(opts["--bind"], "0.0.0.0:8000")
		fmt.Fprintf(os.Stderr, "Serving %s at http://%s\n", output, bind)
		return http.ListenAndServe(bind, http.FileServer(http.Dir(output)))
	default:
		return buildSite(input, output, cfg)
	}
}

func first(vals ...string) string {
	for _, v := range vals {
		if v != "" {
			return v
		}
	}
	return ""
}

func applyOpts(c *Config, opts map[string]string) {
	set := func(k string, p *string) { if opts[k] != "" { *p = opts[k] } }
	set("--name", &c.Name); set("--tagline", &c.Tagline); set("--url", &c.URL); set("--footer", &c.Footer); set("--language", &c.Language)
	set("--content-path", &c.ContentPath); set("--templates-path", &c.TemplatesPath); set("--static-path", &c.StaticPath); set("--media-path", &c.MediaPath)
	set("--default-date-format", &c.DefaultDateFormat); set("--colorscheme", &c.Colorscheme); set("--theme", &c.Theme)
	if v := opts["--pagination"]; v != "" { if n, err := strconv.Atoi(v); err == nil && n > 0 { c.Pagination = n } }
	boolOpt := func(k string, p *bool) { if v := opts[k]; v != "" { *p = v == "true" || v == "1" || v == "yes" } }
	boolOpt("--enable-search", &c.EnableSearch); boolOpt("--enable-related-content", &c.EnableRelatedContent); boolOpt("--toc", &c.TOC)
	boolOpt("--json-feed", &c.JSONFeed); boolOpt("--show-next-prev-links", &c.ShowNextPrevLinks); boolOpt("--publish-md", &c.PublishMD)
	boolOpt("--build-sitemap", &c.BuildSitemap); boolOpt("--publish-urls-json", &c.PublishURLsJSON); boolOpt("--enable-shortcodes", &c.EnableShortcodes)
	if v := opts["--https"]; v != "" { b := v == "true" || v == "1" || v == "yes"; c.HTTPS = &b }
	if c.Language == "" { c.Language = "en" }
	if c.SearchTitle == "" { c.SearchTitle = "Search" }
}

func printHelp() {
	fmt.Print(`Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: ` + "`input_folder/site`" + `]

Options:
  -v, --verbose...                  Verbosity level (0-4)
  -w, --watch                       Detect changes and rebuild the site automatically
      --serve                       Serve the site with a built-in HTTP server
      --bind <BIND>                 Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>             Path to custom configuration file [default: marmite.yaml]
      --init-templates              Initialize templates in the project
      --start-theme <START_THEME>   Initialize a theme with templates and static assets
      --set-theme <SET_THEME>       Download and set a theme from a remote URL or local folder
      --generate-config             Generate the configuration file
      --init-site                   Init a new site with sample content and default configuration
      --force                       Force the rebuild of the site
      --shortcodes                  List all available shortcodes
      --show-urls                   Show all site URLs organized by content type
      --new <NEW>                   Create a new post with the given title
  -e                                Edit the file in the default editor
  -p                                Set the new content as a page
  -t <TAGS>                         Set the tags for the new content tags are comma separated
      --name <NAME>                 Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>           Site tagline
      --url <URL>                   Site url
      --https <HTTPS>               If protocol is missing in the URL setting, whether to use HTTPS or not
      --pagination <PAGINATION>     Number of posts per page
      --enable-search <BOOL>        Enable search
      --toc <BOOL>                  Show Table of Contents in posts
  -h, --help                        Print help
  -V, --version                     Print version
`)
}

func configYAML() string {
	return `name: Home
tagline: ''
url: ''
https: null
footer: <div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
tags_content_title: Posts tagged with '$tag'
archives_title: Archive
archives_content_title: Posts from '$year'
streams_title: Streams
streams_content_title: Posts from '$stream'
series_title: Series
series_content_title: Posts from '$series' series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
card_image: ''
banner_image: ''
logo_image: ''
default_date_format: '%b %e, %Y'
menu:
- - Tags
  - tags.html
- - Archive
  - archive.html
- - Authors
  - authors.html
extra: null
authors: {}
streams: {}
series: {}
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
source_repository: null
image_provider: null
markdown_parser: null
theme: null
file_mapping: []
enable_shortcodes: true
shortcode_pattern: null
build_sitemap: true
publish_urls_json: true
gallery_path: gallery
gallery_create_thumbnails: true
gallery_thumb_size: 50
skip_image_resize: false
`
}

func loadConfig(input, name string) Config {
	cfg := defaultConfig()
	path := name
	if !filepath.IsAbs(path) {
		path = filepath.Join(input, name)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg
	}
	m := parseKV(string(data))
	cfg.Name = strDefault(m["name"], cfg.Name)
	cfg.Tagline = unquote(m["tagline"])
	cfg.URL = unquote(m["url"])
	cfg.Footer = strDefault(unquote(m["footer"]), cfg.Footer)
	cfg.Language = unquote(m["language"])
	if cfg.Language == "" { cfg.Language = "en" }
	cfg.ContentPath = strDefault(unquote(m["content_path"]), cfg.ContentPath)
	cfg.TemplatesPath = strDefault(unquote(m["templates_path"]), cfg.TemplatesPath)
	cfg.StaticPath = strDefault(unquote(m["static_path"]), cfg.StaticPath)
	cfg.MediaPath = strDefault(unquote(m["media_path"]), cfg.MediaPath)
	cfg.DefaultDateFormat = strDefault(unquote(m["default_date_format"]), cfg.DefaultDateFormat)
	cfg.PagesTitle = strDefault(unquote(m["pages_title"]), cfg.PagesTitle)
	cfg.TagsTitle = strDefault(unquote(m["tags_title"]), cfg.TagsTitle)
	cfg.ArchivesTitle = strDefault(unquote(m["archives_title"]), cfg.ArchivesTitle)
	cfg.StreamsTitle = strDefault(unquote(m["streams_title"]), cfg.StreamsTitle)
	cfg.SeriesTitle = strDefault(unquote(m["series_title"]), cfg.SeriesTitle)
	cfg.AuthorsTitle = strDefault(unquote(m["authors_title"]), cfg.AuthorsTitle)
	cfg.SearchTitle = strDefault(unquote(m["search_title"]), cfg.SearchTitle)
	if n, err := strconv.Atoi(unquote(m["pagination"])); err == nil && n > 0 { cfg.Pagination = n }
	cfg.EnableSearch = parseBool(m["enable_search"], cfg.EnableSearch)
	cfg.EnableRelatedContent = parseBool(m["enable_related_content"], cfg.EnableRelatedContent)
	cfg.TOC = parseBool(m["toc"], cfg.TOC)
	cfg.JSONFeed = parseBool(m["json_feed"], cfg.JSONFeed)
	cfg.ShowNextPrevLinks = parseBool(m["show_next_prev_links"], cfg.ShowNextPrevLinks)
	cfg.PublishMD = parseBool(m["publish_md"], cfg.PublishMD)
	cfg.BuildSitemap = parseBool(m["build_sitemap"], cfg.BuildSitemap)
	cfg.PublishURLsJSON = parseBool(m["publish_urls_json"], cfg.PublishURLsJSON)
	cfg.EnableShortcodes = parseBool(m["enable_shortcodes"], cfg.EnableShortcodes)
	return cfg
}

func parseKV(s string) map[string]string {
	m := map[string]string{}
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "-") { continue }
		if i := strings.Index(line, ":"); i >= 0 {
			m[strings.TrimSpace(line[:i])] = strings.TrimSpace(line[i+1:])
		}
	}
	return m
}

func unquote(s string) string {
	s = strings.TrimSpace(s)
	if s == "null" { return "" }
	if len(s) >= 2 && ((s[0] == '\'' && s[len(s)-1] == '\'') || (s[0] == '"' && s[len(s)-1] == '"')) {
		return s[1 : len(s)-1]
	}
	return s
}
func strDefault(s, d string) string { if s == "" { return d }; return s }
func parseBool(s string, d bool) bool {
	s = strings.ToLower(unquote(s))
	if s == "" || s == "null" { return d }
	return s == "true" || s == "yes" || s == "1"
}

func initSite(dir string) error {
	if err := os.MkdirAll(filepath.Join(dir, "content"), 0755); err != nil { return err }
	now := time.Now().UTC().Format("2006-01-02")
	files := map[string]string{
		"marmite.yaml": configYAML(),
		"custom.css": "/* Custom CSS */",
		"custom.js": "// Custom JS",
		filepath.Join("content", now+"-welcome.md"): "# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on `content/{date}-welcome.md`\n\n## Add more content\n\ncreate new markdown files in the `content` folder\n\nuse `marmite --new` to create new content\n\n## Customize your site\n\nedit `marmite.yaml` to change site settings\n\nedit the files starting with `_` in the `content` folder to change the layout\n\nor edit the templates to create a custom layout\n\n## Deploy your site\n\nread more on [marmite documentation](https://marmite.blog)\n",
		filepath.Join("content", "about.md"): "# About\n\nHi, edit `about.md` to change this content.\n",
		filepath.Join("content", "_404.md"): "# Not Found",
		filepath.Join("content", "_announce.md"): "Give us a &star; on [github]",
		filepath.Join("content", "_comments.md"): "##### Comments\n**edit `content/_comments.md` to adjust for your own site/repo**\n",
		filepath.Join("content", "_hero.md"): "##### Welcome to Marmite\n\nMarmite is a static site generator written in Rust.\n",
		filepath.Join("content", "_markdown_footer.md"): "<!-- Content Injected to every content markdown footer -->",
		filepath.Join("content", "_markdown_header.md"): "<!-- Content Injected to every content markdown header -->",
		filepath.Join("content", "_references.md"): "[github]: https://github.com/rochacbruno/marmite",
		filepath.Join("content", "_sidebar.example.md"): "\n{% set groups = ['tag', 'archive', 'author', 'stream'] %}\n",
	}
	for p, c := range files {
		full := filepath.Join(dir, p)
		if err := os.MkdirAll(filepath.Dir(full), 0755); err != nil { return err }
		if err := os.WriteFile(full, []byte(c), 0644); err != nil { return err }
	}
	fmt.Fprintf(os.Stderr, "[%s INFO  marmite::config] Config file generated: %s\n", time.Now().UTC().Format(time.RFC3339), filepath.Join(dir, "marmite.yaml"))
	fmt.Fprintf(os.Stderr, "[%s INFO  marmite::site] Site initialized in %s\n", time.Now().UTC().Format(time.RFC3339), dir)
	return nil
}

func initTemplates(dir string, cfg Config) error {
	names := []string{"base.html","base_feeds.html","comments.html","content.html","content_authors.html","content_date.html","content_title.html","custom_index.html.example","group.html","group_author_avatar.html","json_ld_author.html","json_ld_content.html","json_ld_index.html","list.html","pagination.html","sitemap.xml"}
	tdir := filepath.Join(dir, cfg.TemplatesPath)
	for _, n := range names {
		p := filepath.Join(tdir, n)
		if err := os.MkdirAll(filepath.Dir(p), 0755); err != nil { return err }
		if err := os.WriteFile(p, []byte("<!-- Marmite template: "+n+" -->\n"), 0644); err != nil { return err }
		fmt.Fprintf(os.Stderr, "[%s INFO  marmite::templates] Generated %s\n", time.Now().UTC().Format(time.RFC3339), p)
	}
	return nil
}

func newContent(dir, title string, page bool, tags string) error {
	if err := os.MkdirAll(dir, 0755); err != nil { return err }
	now := time.Now().UTC()
	name := slugify(title)
	prefix := now.Format("2006-01-02-15-04-05-")
	if page { prefix = "" }
	path := filepath.Join(dir, prefix+name+".md")
	var b strings.Builder
	if !page {
		b.WriteString("---\n")
		b.WriteString("date: " + now.Format("2006-01-02 15:04:05") + "\n")
		if tags != "" { b.WriteString("tags: [" + tags + "]\n") }
		b.WriteString("---\n\n")
	}
	b.WriteString("# " + title + "\n")
	if err := os.WriteFile(path, []byte(b.String()), 0644); err != nil { return err }
	fmt.Println(path)
	return nil
}

func printShortcodes(cfg Config) {
	pat := "<!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->"
	fmt.Printf("Shortcodes:\nEnabled: %v\nPattern: %s\n\n", cfg.EnableShortcodes, pat)
	fmt.Println("Reusable blocks of content that can be used in your markdown files.")
	fmt.Println("================")
	fmt.Println("Examples based on your configuration:")
	for _, n := range []string{"card","authors","pages"} {
		fmt.Printf("  <!-- .%s -->\n  <!-- .%s param=value -->\n", n, n)
	}
	fmt.Println("\nNote: Replace 'param' and 'value' with actual parameter names and values.")
	fmt.Println("--------------------------------")
	for _, s := range []string{"authors: Display a list of all authors with post counts. Params: ord=desc, items=0","card: Display a card for content based on slug with optional parameter overrides","gallery: Display a gallery of images","pages: Display a list of all pages. Params: ord=asc, items=0","posts: Display a list of recent posts. Params: ord=desc, items=10","series: Display a list of all content series with post counts. Params: ord=desc, items=0","socials: Display social network links","spotify: Embed Spotify content with custom dimensions","streams: Display a list of all content streams with post counts. Params: ord=desc, items=0","tags: Display a list of all tags with post counts. Params: ord=desc, items=0","toc: Display table of contents for the current content","youtube: Embed a YouTube video"} {
		fmt.Println("  - " + s)
	}
}

func buildSite(input, output string, cfg Config) error {
	contents, err := readContents(input, cfg)
	if err != nil { return err }
	if err := os.RemoveAll(output); err != nil { return err }
	if err := os.MkdirAll(output, 0755); err != nil { return err }
	writeStatic(input, output, cfg)
	for i := range contents {
		contents[i].HTML = markdownToHTML(contents[i].Body)
		if contents[i].IsPage {
			contents[i].URL = "/" + contents[i].Slug + ".html"
		} else {
			contents[i].URL = "/" + contents[i].Slug + ".html"
		}
		if err := os.WriteFile(filepath.Join(output, contents[i].Slug+".html"), []byte(renderContent(contents[i], cfg)), 0644); err != nil { return err }
		if cfg.PublishMD { copyFile(contents[i].Source, filepath.Join(output, contents[i].Slug+".md")) }
	}
	writeIndexPages(output, contents, cfg)
	urls := buildURLs(contents, cfg)
	if cfg.PublishURLsJSON {
		b, _ := json.MarshalIndent(urls, "", "  ")
		os.WriteFile(filepath.Join(output, "urls.json"), append(b, '\n'), 0644)
	}
	writeMeta(output, contents, cfg, urls)
	if cfg.JSONFeed { writeJSONFeed(output, contents, cfg) }
	return nil
}

func readContents(input string, cfg Config) ([]Content, error) {
	root := input
	if st, err := os.Stat(filepath.Join(input, cfg.ContentPath)); err == nil && st.IsDir() {
		root = filepath.Join(input, cfg.ContentPath)
	}
	var out []Content
	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() { return err }
		if strings.ToLower(filepath.Ext(path)) != ".md" { return nil }
		base := filepath.Base(path)
		if strings.HasPrefix(base, "_") { return nil }
		data, err := os.ReadFile(path); if err != nil { return err }
		c := parseContent(path, root, string(data))
		out = append(out, c)
		return nil
	})
	sort.Slice(out, func(i, j int) bool {
		if out[i].Date != nil && out[j].Date != nil { return out[i].Date.After(*out[j].Date) }
		return out[i].Title < out[j].Title
	})
	return out, err
}

func parseContent(path, root, data string) Content {
	rel, _ := filepath.Rel(root, path)
	body := data
	meta := map[string]string{}
	if strings.HasPrefix(data, "---\n") || strings.HasPrefix(data, "+++\n") {
		marker := data[:3]
		if end := strings.Index(data[4:], "\n"+marker); end >= 0 {
			fm := data[4 : 4+end]
			meta = parseKV(fm)
			body = strings.TrimLeft(data[4+end+4:], "\r\n")
		}
	}
	title := unquote(meta["title"])
	if title == "" { title = firstHeading(body) }
	if title == "" { title = strings.TrimSuffix(filepath.Base(path), filepath.Ext(path)) }
	slug := unquote(meta["slug"])
	if slug == "" {
		name := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
		if len(name) > 11 && datePrefix(name) != nil { name = name[11:] }
		slug = slugify(name)
	}
	var dt *time.Time
	if d := unquote(meta["date"]); d != "" {
		if t, ok := parseDate(d); ok { dt = &t }
	} else if t := datePrefix(strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))); t != nil {
		dt = t
	}
	c := Content{Source:path, Rel:rel, Title:title, Slug:slug, Description:unquote(meta["description"]), Date:dt, Body:body}
	c.Tags = parseList(first(meta["tags"], meta["tag"]))
	c.Authors = parseList(first(meta["authors"], meta["author"]))
	c.Series = parseList(meta["series"])
	c.Streams = parseList(first(meta["streams"], meta["stream"]))
	if c.Description == "" { c.Description = plainText(markdownToHTML(body)); if len(c.Description) > 160 { c.Description = c.Description[:160] } }
	c.IsPage = dt == nil
	return c
}

func datePrefix(s string) *time.Time {
	re := regexp.MustCompile(`^(\d{4})-(\d{2})-(\d{2})`)
	m := re.FindStringSubmatch(s)
	if m == nil { return nil }
	t, err := time.Parse("2006-01-02", m[0]); if err != nil { return nil }
	return &t
}

func parseDate(s string) (time.Time, bool) {
	layouts := []string{"2006-01-02", "2006-01-02 15:04:05", time.RFC3339, "2006-01-02T15:04:05"}
	for _, l := range layouts {
		if t, err := time.Parse(l, s); err == nil { return t, true }
	}
	return time.Time{}, false
}

func parseList(s string) []string {
	s = strings.TrimSpace(unquote(s))
	if s == "" { return nil }
	s = strings.TrimPrefix(strings.TrimSuffix(s, "]"), "[")
	parts := strings.Split(s, ",")
	var out []string
	for _, p := range parts {
		p = strings.TrimSpace(unquote(p))
		if p != "" { out = append(out, p) }
	}
	return out
}

func firstHeading(s string) string {
	for _, l := range strings.Split(s, "\n") {
		l = strings.TrimSpace(l)
		if strings.HasPrefix(l, "# ") { return strings.TrimSpace(l[2:]) }
	}
	return ""
}

func markdownToHTML(md string) string {
	md = regexp.MustCompile(`(?s)<!--\s*\.\w+.*?-->`).ReplaceAllString(md, "")
	lines := strings.Split(strings.ReplaceAll(md, "\r\n", "\n"), "\n")
	var b strings.Builder
	inP, inUL, inOL, inCode := false, false, false, false
	var para []string
	flushP := func() {
		if len(para) > 0 {
			b.WriteString("<p>" + inline(strings.Join(para, " ")) + "</p>\n")
			para = nil
		}
		inP = false
	}
	_ = inP
	for _, raw := range lines {
		line := strings.TrimRight(raw, " ")
		t := strings.TrimSpace(line)
		if strings.HasPrefix(t, "```") {
			flushP(); if inUL { b.WriteString("</ul>\n"); inUL=false }; if inOL { b.WriteString("</ol>\n"); inOL=false }
			if !inCode { b.WriteString("<pre><code>"); inCode=true } else { b.WriteString("</code></pre>\n"); inCode=false }
			continue
		}
		if inCode { b.WriteString(html.EscapeString(line)+"\n"); continue }
		if t == "" { flushP(); if inUL { b.WriteString("</ul>\n"); inUL=false }; if inOL { b.WriteString("</ol>\n"); inOL=false }; continue }
		if strings.HasPrefix(t, "#") {
			flushP(); if inUL { b.WriteString("</ul>\n"); inUL=false }; if inOL { b.WriteString("</ol>\n"); inOL=false }
			n := 0; for n < len(t) && t[n] == '#' { n++ }
			if n > 0 && n <= 6 && n < len(t) && t[n] == ' ' {
				text := strings.TrimSpace(t[n+1:])
				id := slugify(text)
				b.WriteString(fmt.Sprintf("<h%d><a href=\"#%s\" aria-hidden=\"true\" class=\"anchor\" id=\"%s\"></a>%s</h%d>\n", n, id, id, inline(text), n))
				continue
			}
		}
		if strings.HasPrefix(t, "- ") || strings.HasPrefix(t, "* ") {
			flushP(); if !inUL { b.WriteString("<ul>\n"); inUL=true }
			b.WriteString("<li>"+inline(strings.TrimSpace(t[2:]))+"</li>\n"); continue
		}
		if regexp.MustCompile(`^\d+\.\s+`).MatchString(t) {
			flushP(); if !inOL { b.WriteString("<ol>\n"); inOL=true }
			item := regexp.MustCompile(`^\d+\.\s+`).ReplaceAllString(t, "")
			b.WriteString("<li>"+inline(item)+"</li>\n"); continue
		}
		if strings.HasPrefix(t, "> ") {
			flushP(); b.WriteString("<blockquote><p>"+inline(strings.TrimSpace(t[2:]))+"</p></blockquote>\n"); continue
		}
		para = append(para, t); inP = true
	}
	flushP(); if inUL { b.WriteString("</ul>\n") }; if inOL { b.WriteString("</ol>\n") }; if inCode { b.WriteString("</code></pre>\n") }
	return b.String()
}

func inline(s string) string {
	s = html.EscapeString(s)
	repls := []struct{ re, rep string }{
		{`\!\[([^\]]*)\]\(([^\)]+)\)`, `<img src="$2" alt="$1">`},
		{`\[([^\]]+)\]\(([^\)]+)\)`, `<a href="$2">$1</a>`},
		{"`([^`]+)`", `<code>$1</code>`},
		{`\*\*([^*]+)\*\*`, `<strong>$1</strong>`},
		{`\*([^*]+)\*`, `<em>$1</em>`},
	}
	for _, r := range repls { s = regexp.MustCompile(r.re).ReplaceAllString(s, r.rep) }
	return s
}

func plainText(s string) string {
	return strings.TrimSpace(regexp.MustCompile(`<[^>]+>`).ReplaceAllString(s, ""))
}

func renderContent(c Content, cfg Config) string {
	body := `<article class="h-entry">` + "\n" + `<h1 class="p-name">` + html.EscapeString(c.Title) + `</h1>` + "\n"
	if c.Date != nil { body += `<p><small>` + c.Date.Format("Jan _2, 2006") + `</small></p>` + "\n" }
	body += `<div class="content-html e-content">` + c.HTML + `</div>` + "\n"
	if len(c.Authors) > 0 { body += `<p class="content-authors">Authors: ` + links("author", c.Authors) + `</p>` + "\n" }
	if len(c.Tags) > 0 { body += `<p class="content-tags">Tags: ` + links("tag", c.Tags) + `</p>` + "\n" }
	body += `</article>`
	return layout(c.Title, cfg, body, c.Description)
}

func links(kind string, vals []string) string {
	var out []string
	for _, v := range vals { out = append(out, fmt.Sprintf(`<a href="/%s-%s.html">%s</a>`, kind, slugify(v), html.EscapeString(v))) }
	return strings.Join(out, ", ")
}

func layout(title string, cfg Config, body string, desc string) string {
	if desc == "" { desc = cfg.Tagline }
	search := ""
	if cfg.EnableSearch { search = `<li><a href="#" id="search-toggle" class="secondary" title="Search (Ctrl + Shift + F)"> <span class="search-txt">`+html.EscapeString(cfg.SearchTitle)+`</span><span class="search-magnifier"></span></a></li>` }
	tagline := ""; if cfg.Tagline != "" { tagline = `<p class="p-note">`+html.EscapeString(cfg.Tagline)+`</p>` }
	return `<!DOCTYPE html>
<html lang="` + html.EscapeString(cfg.Language) + `">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="` + html.EscapeString(title) + `">
    <meta property="og:description" content="` + html.EscapeString(desc) + `">
    <meta property="og:site_name" content="` + html.EscapeString(cfg.Name) + `">
    <title>` + html.EscapeString(title) + ` | ` + html.EscapeString(cfg.Name) + `</title>
    <link rel="stylesheet" type="text/css" href="/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="/static/marmite.css">
    <link rel="stylesheet" type="text/css" href="/static/custom.css">
</head>
<body>
<main class="container">
<header class="header-content"><nav class="header-nav"><hgroup class="h-card"><h2><a href="/" class="contrast p-name u-url">` + html.EscapeString(cfg.Name) + `</a></h2>` + tagline + `</hgroup><ul class="header-menu"><li><a class="menu-item secondary" href="/tags.html">Tags</a></li><li><a class="menu-item secondary" href="/archive.html">Archive</a></li><li><a class="menu-item secondary" href="/authors.html">Authors</a></li>`+search+`</ul></nav></header>
<section class="main-content">
` + body + `
</section>
<footer>` + cfg.Footer + `</footer>
</main>
</body>
</html>
`
}

func writeIndexPages(output string, contents []Content, cfg Config) {
	var posts, pages []Content
	for _, c := range contents { if c.IsPage { pages=append(pages,c) } else { posts=append(posts,c) } }
	writeList(output, "index.html", "Welcome to Marmite", posts, cfg)
	if len(posts) > 0 { writeList(output, "index-1.html", "Posts - 1", posts, cfg); writeRSS(output, "index.rss", "index", posts, cfg) }
	writeList(output, "pages.html", cfg.PagesTitle, pages, cfg)
	if len(pages) > 0 { writeList(output, "pages-1.html", cfg.PagesTitle+" - 1", pages, cfg) }
	writeGroupPages(output, "tag", cfg.TagsTitle, collect(contents, "tag"), cfg)
	writeGroupPages(output, "author", cfg.AuthorsTitle, collect(contents, "author"), cfg)
	writeArchivePages(output, posts, cfg)
	writeList(output, "streams.html", cfg.StreamsTitle, nil, cfg)
	writeList(output, "series.html", cfg.SeriesTitle, nil, cfg)
	writeList(output, "404.html", "Page not found", []Content{{Title:" :/"}}, cfg)
}

func writeList(output, file, title string, items []Content, cfg Config) {
	var b strings.Builder
	b.WriteString("<h1>"+html.EscapeString(title)+"</h1>\n<ul class=\"content-list\">\n")
	for _, c := range items {
		b.WriteString(`<li><a href="`+c.URL+`">`+html.EscapeString(c.Title)+`</a>`)
		if c.Date != nil { b.WriteString(" <small>"+c.Date.Format("Jan _2, 2006")+"</small>") }
		b.WriteString("</li>\n")
	}
	b.WriteString("</ul>\n")
	os.WriteFile(filepath.Join(output, file), []byte(layout(title, cfg, b.String(), cfg.Tagline)), 0644)
}

func collect(contents []Content, kind string) map[string][]Content {
	m := map[string][]Content{}
	for _, c := range contents {
		var vals []string
		if kind == "tag" { vals = c.Tags } else { vals = c.Authors }
		for _, v := range vals { m[v] = append(m[v], c) }
	}
	return m
}

func writeGroupPages(output, kind, title string, groups map[string][]Content, cfg Config) {
	var names []string
	for n := range groups { names = append(names, n) }
	sort.Strings(names)
	var b strings.Builder
	b.WriteString("<h1>"+html.EscapeString(title)+"</h1>\n<ul>\n")
	for _, n := range names {
		fn := kind+"-"+slugify(n)+".html"
		b.WriteString(`<li><a href="/`+fn+`">`+html.EscapeString(n)+`</a> (`+strconv.Itoa(len(groups[n]))+`)</li>`+"\n")
		writeList(output, fn, n, groups[n], cfg)
		writeList(output, kind+"-"+slugify(n)+"-1.html", n+" - 1", groups[n], cfg)
		writeRSS(output, kind+"-"+slugify(n)+".rss", kind+": "+n, groups[n], cfg)
	}
	b.WriteString("</ul>\n")
	writeList(output, titleFile(kind), title, nil, cfg)
	os.WriteFile(filepath.Join(output, titleFile(kind)), []byte(layout(title, cfg, b.String(), cfg.Tagline)), 0644)
}

func titleFile(kind string) string { if kind=="tag" { return "tags.html" }; return "authors.html" }

func writeArchivePages(output string, posts []Content, cfg Config) {
	byYear := map[string][]Content{}
	for _, c := range posts { if c.Date != nil { byYear[c.Date.Format("2006")] = append(byYear[c.Date.Format("2006")], c) } }
	var years []string; for y := range byYear { years=append(years,y) }; sort.Sort(sort.Reverse(sort.StringSlice(years)))
	var b strings.Builder; b.WriteString("<h1>"+html.EscapeString(cfg.ArchivesTitle)+"</h1><ul>\n")
	for _, y := range years {
		b.WriteString(`<li><a href="/archive-`+y+`.html">`+y+`</a></li>`+"\n")
		writeList(output, "archive-"+y+".html", y, byYear[y], cfg)
		writeList(output, "archive-"+y+"-1.html", y+" - 1", byYear[y], cfg)
		writeRSS(output, "archive-"+y+".rss", "year: "+y, byYear[y], cfg)
	}
	b.WriteString("</ul>\n")
	os.WriteFile(filepath.Join(output, "archive.html"), []byte(layout(cfg.ArchivesTitle, cfg, b.String(), cfg.Tagline)), 0644)
}

func buildURLs(contents []Content, cfg Config) map[string]any {
	pre := func(u string) string {
		if cfg.URL == "" { return u }
		base := strings.TrimRight(cfg.URL, "/")
		if strings.HasPrefix(base, "http://") || strings.HasPrefix(base, "https://") { return base + u }
		return base + u
	}
	posts, pages, tags, authors := []string{}, []string{}, []string{}, []string{}
	archives, feeds, pagination := []string{}, []string{}, []string{}
	tagSet, authorSet, yearSet := map[string]bool{}, map[string]bool{}, map[string]bool{}
	for _, c := range contents {
		if c.IsPage { pages = append(pages, pre(c.URL)) } else { posts = append(posts, pre(c.URL)); feeds=append(feeds, pre("/index.rss")) }
		for _, t := range c.Tags { tagSet[t]=true }
		for _, a := range c.Authors { authorSet[a]=true }
		if c.Date != nil { yearSet[c.Date.Format("2006")]=true }
	}
	if len(pages) > 0 { pages = append(pages, pre("/pages.html")); pagination=append(pagination, pre("/pages-1.html")) }
	for t := range tagSet { tags=append(tags, pre("/tag-"+slugify(t)+".html")); feeds=append(feeds, pre("/tag-"+slugify(t)+".rss")); pagination=append(pagination, pre("/tag-"+slugify(t)+"-1.html")) }
	if len(tags)>0 { tags=append(tags, pre("/tags.html")) }
	for a := range authorSet { authors=append(authors, pre("/author-"+slugify(a)+".html")); feeds=append(feeds, pre("/author-"+slugify(a)+".rss")); pagination=append(pagination, pre("/author-"+slugify(a)+"-1.html")) }
	if len(authors)>0 { authors=append(authors, pre("/authors.html")) }
	for y := range yearSet { archives=append(archives, pre("/archive-"+y+".html")); feeds=append(feeds, pre("/archive-"+y+".rss")); pagination=append(pagination, pre("/archive-"+y+"-1.html")) }
	if len(archives)>0 { archives=append(archives, pre("/archive.html")) }
	sort.Strings(tags); sort.Strings(authors); sort.Strings(archives); sort.Strings(feeds); sort.Strings(pagination)
	streams := []string{}; if len(posts)>0 { streams=[]string{pre("/streams.html")} }
	misc := []string{pre("/index.html")}
	total := len(posts)+len(pages)+len(tags)+len(authors)+len(archives)+len(feeds)+len(pagination)+len(streams)+len(misc)
	return map[string]any{"posts":posts,"pages":pages,"tags":tags,"authors":authors,"series":[]string{},"streams":streams,"archives":archives,"feeds":unique(feeds),"pagination":pagination,"file_mappings":[]string{},"misc":misc,"summary":map[string]any{"posts":len(posts),"pages":len(pages),"tags":len(tags),"authors":len(authors),"series":0,"streams":len(streams),"archives":len(archives),"feeds":len(unique(feeds)),"pagination":len(pagination),"file_mappings":0,"misc":len(misc),"total":total,"meta":map[string]any{"url":cfg.URL,"absolute_urls":cfg.URL!=""}}}
}

func unique(in []string) []string { seen:=map[string]bool{}; out:=[]string{}; for _, x := range in { if !seen[x] { seen[x]=true; out=append(out,x) } }; return out }

func writeMeta(output string, contents []Content, cfg Config, urls map[string]any) {
	os.WriteFile(filepath.Join(output, "robots.txt"), []byte("User-agent: Mediapartners-Google\nDisallow:\n\nUser-agent: *\nAllow: /\n"), 0644)
	if cfg.BuildSitemap {
		var b strings.Builder
		b.WriteString("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n")
		for _, c := range contents { b.WriteString("  <url>\n    <loc>"+c.URL+"</loc>\n  </url>\n") }
		b.WriteString("  <url>\n    <loc>/index.html</loc>\n  </url>\n</urlset>")
		os.WriteFile(filepath.Join(output, "sitemap.xml"), []byte(b.String()), 0644)
	}
	meta := map[string]any{"marmite_version":version,"posts":countPosts(contents),"pages":countPages(contents),"generated_at":time.Now().UTC().String(),"timestamp":time.Now().UTC().Unix(),"elapsed_time":0.01,"config":configMap(cfg)}
	b,_ := json.MarshalIndent(meta,"","  "); os.WriteFile(filepath.Join(output,"marmite.json"), append(b,'\n'),0644)
}

func configMap(c Config) map[string]any {
	return map[string]any{
		"name": c.Name, "tagline": c.Tagline, "url": c.URL, "https": c.HTTPS, "footer": c.Footer, "language": c.Language,
		"pagination": c.Pagination, "pages_title": c.PagesTitle, "tags_title": c.TagsTitle, "archives_title": c.ArchivesTitle,
		"streams_title": c.StreamsTitle, "series_title": c.SeriesTitle, "authors_title": c.AuthorsTitle,
		"enable_search": c.EnableSearch, "enable_related_content": c.EnableRelatedContent, "search_title": c.SearchTitle,
		"content_path": c.ContentPath, "templates_path": c.TemplatesPath, "static_path": c.StaticPath, "media_path": c.MediaPath,
		"default_date_format": c.DefaultDateFormat, "toc": c.TOC, "json_feed": c.JSONFeed,
		"show_next_prev_links": c.ShowNextPrevLinks, "publish_md": c.PublishMD, "theme": c.Theme,
		"enable_shortcodes": c.EnableShortcodes, "build_sitemap": c.BuildSitemap, "publish_urls_json": c.PublishURLsJSON,
	}
}

func countPosts(cs []Content) int { n:=0; for _,c:= range cs { if !c.IsPage { n++ } }; return n }
func countPages(cs []Content) int { n:=0; for _,c:= range cs { if c.IsPage { n++ } }; return n }

func writeRSS(output, file, title string, items []Content, cfg Config) {
	var b strings.Builder
	b.WriteString(`<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>`+html.EscapeString(title)+`</title>`)
	for _, c := range items { b.WriteString(`<item><title>`+html.EscapeString(c.Title)+`</title><link>`+c.URL+`</link><description>`+html.EscapeString(c.Description)+`</description></item>`) }
	b.WriteString(`</channel></rss>`)
	os.WriteFile(filepath.Join(output,file), []byte(b.String()),0644)
}

func writeJSONFeed(output string, items []Content, cfg Config) {
	var arr []map[string]string
	for _, c := range items { if !c.IsPage { arr = append(arr, map[string]string{"id":c.URL,"url":c.URL,"title":c.Title,"content_html":c.HTML}) } }
	b,_ := json.MarshalIndent(map[string]any{"version":"https://jsonfeed.org/version/1.1","title":cfg.Name,"items":arr},"","  ")
	os.WriteFile(filepath.Join(output,"feed.json"), append(b,'\n'),0644)
}

func writeStatic(input, output string, cfg Config) {
	sdir := filepath.Join(output, "static"); os.MkdirAll(sdir,0755)
	assets := map[string]string{"pico.min.css":"body{font-family:sans-serif}","marmite.css":".container{max-width:900px;margin:auto}.content-list{line-height:1.8}.avatar{width:32px}","custom.css":"/* Custom CSS */","custom.js":"// Custom JS","marmite.js":"// Marmite","search.js":"// Search","robots.txt":"User-agent: *\nAllow: /\n","favicon.ico":"","logo.png":"","avatar-placeholder.png":"","Atkinson-Hyperlegible-Regular-102.woff":""}
	for n,c := range assets { os.WriteFile(filepath.Join(sdir,n), []byte(c),0644) }
	copyDir(filepath.Join(input, cfg.StaticPath), sdir)
	copyDir(filepath.Join(input, cfg.MediaPath), filepath.Join(output, cfg.MediaPath))
	for _, f := range []string{"custom.css","custom.js"} { copyFile(filepath.Join(input,f), filepath.Join(sdir,f)) }
}

func copyDir(src, dst string) {
	filepath.WalkDir(src, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() { return nil }
		rel,_ := filepath.Rel(src,path)
		copyFile(path, filepath.Join(dst,rel)); return nil
	})
}
func copyFile(src,dst string) {
	in,err:=os.Open(src); if err!=nil { return }; defer in.Close()
	os.MkdirAll(filepath.Dir(dst),0755); out,err:=os.Create(dst); if err!=nil { return }; defer out.Close(); io.Copy(out,in)
}

func slugify(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	var b strings.Builder
	lastDash := false
	for _, r := range s {
		ok := (r>='a'&&r<='z') || (r>='0'&&r<='9')
		if ok { b.WriteRune(r); lastDash=false } else if !lastDash { b.WriteByte('-'); lastDash=true }
	}
	res := strings.Trim(b.String(), "-")
	if res == "" {
		h:=sha1.Sum([]byte(s)); return hex.EncodeToString(h[:])[:8]
	}
	return res
}
