module marmiteclone

go 1.21
