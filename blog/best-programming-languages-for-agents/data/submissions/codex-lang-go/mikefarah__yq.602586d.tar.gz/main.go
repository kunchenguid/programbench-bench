package main

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"encoding/csv"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"
)

type Config struct {
	inFmt, outFmt, exprFile, exprFlag string
	inplace, nullInput, exitStatus    bool
	pretty, noDoc, nulOutput         bool
	indent                           int
	unwrap                           bool
	mode                             string
}

type Item struct {
	V         any
	FileIndex int
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func run(args []string) error {
	cfg := Config{inFmt: "auto", outFmt: "auto", indent: 2, unwrap: true, mode: "eval"}
	if len(args) > 0 {
		switch args[0] {
		case "help", "--help", "-h":
			printHelp()
			return nil
		case "eval", "e":
			cfg.mode = "eval"
			args = args[1:]
		case "eval-all", "ea":
			cfg.mode = "eval-all"
			args = args[1:]
		case "completion":
			fmt.Println("# completion is not implemented in this cleanroom reimplementation")
			return nil
		case "--version", "-V":
			fmt.Println("yq (https://github.com/mikefarah/yq/) version v4.52.5")
			return nil
		}
	}
	rest, err := parseFlags(args, &cfg)
	if err != nil {
		return err
	}
	if cfg.exprFile != "" {
		b, err := os.ReadFile(cfg.exprFile)
		if err != nil {
			return err
		}
		cfg.exprFlag = string(b)
	}
	expr := cfg.exprFlag
	files := []string{}
	if expr == "" && len(rest) > 0 && looksLikeExpr(rest[0]) {
		expr = rest[0]
		files = rest[1:]
	} else {
		files = rest
	}
	if expr == "" {
		expr = "."
	}
	if cfg.nullInput {
		files = nil
	}
	if cfg.inplace && len(files) == 0 {
		return errors.New("write in place flag only applicable when giving an expression and at least one file")
	}
	var items []Item
	if cfg.nullInput {
		items = []Item{{V: nil, FileIndex: 0}}
	} else if len(files) == 0 {
		b, _ := io.ReadAll(os.Stdin)
		v, err := parseInput(b, cfg.inFmt, "")
		if err != nil {
			return err
		}
		items = []Item{{V: v, FileIndex: 0}}
	} else {
		for i, f := range files {
			var b []byte
			var err error
			if f == "-" {
				b, err = io.ReadAll(os.Stdin)
			} else {
				b, err = os.ReadFile(f)
			}
			if err != nil {
				return err
			}
			v, err := parseInput(b, cfg.inFmt, f)
			if err != nil {
				return err
			}
			items = append(items, Item{V: v, FileIndex: i})
		}
	}
	var results []Item
	if cfg.mode == "eval-all" {
		results, err = evalAll(expr, items)
	} else {
		for _, it := range items {
			r, e := evalExpr(expr, []Item{it})
			if e != nil {
				return e
			}
			results = append(results, r...)
		}
	}
	if err != nil {
		return err
	}
	if cfg.inplace {
		var buf bytes.Buffer
		if err := writeResults(&buf, results, cfg, files[0]); err != nil {
			return err
		}
		return os.WriteFile(files[0], buf.Bytes(), 0644)
	}
	if err := writeResults(os.Stdout, results, cfg, firstFile(files), ); err != nil {
		return err
	}
	if cfg.exitStatus {
		if len(results) == 0 || isFalsey(results[len(results)-1].V) {
			os.Exit(1)
		}
	}
	return nil
}

func parseFlags(args []string, cfg *Config) ([]string, error) {
	var out []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() (string, error) {
			i++
			if i >= len(args) {
				return "", fmt.Errorf("flag needs an argument: %s", a)
			}
			return args[i], nil
		}
		switch {
		case a == "-h" || a == "--help":
			printHelp()
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Println("yq (https://github.com/mikefarah/yq/) version v4.52.5")
			os.Exit(0)
		case a == "-i" || a == "--inplace":
			cfg.inplace = true
		case a == "-n" || a == "--null-input":
			cfg.nullInput = true
		case a == "-e" || a == "--exit-status":
			cfg.exitStatus = true
		case a == "-P" || a == "--prettyPrint":
			cfg.pretty = true
		case a == "-N" || a == "--no-doc":
			cfg.noDoc = true
		case a == "-0" || a == "--nul-output":
			cfg.nulOutput = true
		case a == "-r" || a == "--unwrapScalar":
			cfg.unwrap = true
		case a == "-M" || a == "--no-colors" || a == "-C" || a == "--colors" || a == "-v" || a == "--verbose":
		case a == "-I" || a == "--indent":
			s, err := next(); if err != nil { return nil, err }
			n, _ := strconv.Atoi(s); if n > 0 { cfg.indent = n }
		case a == "-p" || a == "--input-format":
			s, err := next(); if err != nil { return nil, err }; cfg.inFmt = normFmt(s)
		case strings.HasPrefix(a, "-p="):
			cfg.inFmt = normFmt(a[3:])
		case strings.HasPrefix(a, "-p") && len(a) > 2:
			cfg.inFmt = normFmt(a[2:])
		case a == "-o" || a == "--output-format":
			s, err := next(); if err != nil { return nil, err }; cfg.outFmt = normFmt(s)
		case strings.HasPrefix(a, "-o="):
			cfg.outFmt = normFmt(a[3:])
		case strings.HasPrefix(a, "-o") && len(a) > 2:
			cfg.outFmt = normFmt(a[2:])
		case strings.HasPrefix(a, "--input-format="):
			cfg.inFmt = normFmt(strings.TrimPrefix(a, "--input-format="))
		case strings.HasPrefix(a, "--output-format="):
			cfg.outFmt = normFmt(strings.TrimPrefix(a, "--output-format="))
		case a == "--expression":
			s, err := next(); if err != nil { return nil, err }; cfg.exprFlag = s
		case a == "--from-file":
			s, err := next(); if err != nil { return nil, err }; cfg.exprFile = s
		case strings.HasPrefix(a, "--"):
			if strings.Contains(a, "=") {
				continue
			}
			// Skip known long flag arguments.
			if needsArg(a) {
				if _, err := next(); err != nil { return nil, err }
			}
		default:
			out = append(out, a)
		}
	}
	return out, nil
}

func needsArg(a string) bool {
	return strings.Contains(a, "separator") || strings.Contains(a, "prefix") || strings.Contains(a, "suffix") || strings.Contains(a, "front-matter") || strings.Contains(a, "split-exp")
}

func normFmt(s string) string {
	switch s {
	case "y", "yaml", "auto", "a", "":
		return "yaml"
	case "j", "json":
		return "json"
	case "c", "csv":
		return "csv"
	case "t", "tsv":
		return "tsv"
	case "x", "xml":
		return "xml"
	case "props", "p", "properties":
		return "props"
	case "base64", "uri", "shell", "lua", "ini":
		return s
	default:
		return s
	}
}

func looksLikeExpr(s string) bool {
	return s == "." || strings.HasPrefix(s, ".") || strings.HasPrefix(s, "[") || strings.Contains(s, "=") || strings.HasPrefix(s, "load(") || strings.HasPrefix(s, "select(")
}

func parseInput(b []byte, fmtName, file string) (any, error) {
	if fmtName == "auto" || fmtName == "yaml" {
		ext := strings.ToLower(filepath.Ext(file))
		if fmtName == "auto" {
			switch ext {
			case ".json": fmtName = "json"
			case ".csv": fmtName = "csv"
			case ".tsv": fmtName = "tsv"
			case ".xml": fmtName = "xml"
			case ".properties", ".props": fmtName = "props"
			default: fmtName = "yaml"
			}
		}
	}
	switch fmtName {
	case "json":
		var v any
		if len(bytes.TrimSpace(b)) == 0 { return nil, nil }
		if err := json.Unmarshal(b, &v); err != nil { return nil, err }
		return v, nil
	case "csv", "tsv":
		r := csv.NewReader(bytes.NewReader(b)); if fmtName == "tsv" { r.Comma = '\t' }
		rows, err := r.ReadAll(); if err != nil { return nil, err }
		return rows, nil
	case "props", "ini":
		return parseProps(string(b)), nil
	case "base64":
		dec, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(b))); if err != nil { return nil, err }
		return string(dec), nil
	case "uri":
		return url.QueryUnescape(strings.TrimSpace(string(b)))
	case "xml":
		return parseXML(b), nil
	default:
		var v any
		if len(bytes.TrimSpace(b)) == 0 { return nil, nil }
		if err := yaml.Unmarshal(b, &v); err != nil { return nil, err }
		return normalize(v), nil
	}
}

func normalize(v any) any {
	switch x := v.(type) {
	case map[string]any:
		m := map[string]any{}
		for k, v := range x { m[k] = normalize(v) }
		return m
	case map[any]any:
		m := map[string]any{}
		for k, v := range x { m[fmt.Sprint(k)] = normalize(v) }
		return m
	case []any:
		for i := range x { x[i] = normalize(x[i]) }
		return x
	default:
		return v
	}
}

func parseProps(s string) map[string]any {
	root := map[string]any{}
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") { continue }
		sep := strings.IndexAny(line, "=:")
		if sep < 0 { continue }
		setPath(root, parsePath("."+strings.TrimSpace(line[:sep])), parseLiteral(strings.TrimSpace(line[sep+1:])))
	}
	return root
}

func parseXML(b []byte) any {
	dec := xml.NewDecoder(bytes.NewReader(b))
	var stack []map[string]any
	var names []string
	for {
		tok, err := dec.Token(); if err != nil { break }
		switch t := tok.(type) {
		case xml.StartElement:
			m := map[string]any{}
			for _, a := range t.Attr { m["+@"+a.Name.Local] = a.Value }
			stack = append(stack, m); names = append(names, t.Name.Local)
		case xml.CharData:
			txt := strings.TrimSpace(string(t))
			if txt != "" && len(stack) > 0 { stack[len(stack)-1]["+content"] = txt }
		case xml.EndElement:
			if len(stack) == 1 { return map[string]any{names[0]: stack[0]} }
			child := stack[len(stack)-1]; name := names[len(names)-1]
			stack = stack[:len(stack)-1]; names = names[:len(names)-1]
			parent := stack[len(stack)-1]
			if old, ok := parent[name]; ok { parent[name] = append(asSlice(old), child) } else { parent[name] = child }
		}
	}
	return map[string]any{}
}

func evalAll(expr string, items []Item) ([]Item, error) {
	if strings.Contains(expr, "ireduce") {
		var acc any = map[string]any{}
		for _, it := range items { acc = merge(acc, it.V) }
		return []Item{{V: acc}}, nil
	}
	return evalExpr(expr, items)
}

func evalExpr(expr string, in []Item) ([]Item, error) {
	expr = strings.TrimSpace(expr)
	if expr == "" || expr == "." { return in, nil }
	if strings.Contains(expr, " | ") {
		parts := splitTop(expr, "|")
		if len(parts) > 1 {
			cur := in
			var err error
			for _, p := range parts { cur, err = evalExpr(p, cur); if err != nil { return nil, err } }
			return cur, nil
		}
	}
	if strings.HasPrefix(expr, "[") && strings.HasSuffix(expr, "]") {
		r, err := evalExpr(strings.TrimSpace(expr[1:len(expr)-1]), in); if err != nil { return nil, err }
		arr := []any{}; for _, it := range r { arr = append(arr, it.V) }
		return []Item{{V: arr}}, nil
	}
	if op, idx := findAssign(expr); idx >= 0 {
		left := strings.TrimSpace(expr[:idx]); right := strings.TrimSpace(expr[idx+len(op):])
		var out []Item
		for _, it := range in {
			root := clone(it.V)
			val, err := evalValue(right, []Item{{V: root, FileIndex: it.FileIndex}})
			if err != nil { return nil, err }
			path := parsePath(left)
			if op == "+=" {
				old := getPath(root, path)
				val = addVals(old, val)
			}
			root = setPathAny(root, path, val)
			out = append(out, Item{V: root, FileIndex: it.FileIndex})
		}
		return out, nil
	}
	if idx := findMerge(expr); idx >= 0 {
		l := strings.TrimSpace(expr[:idx]); r := strings.TrimSpace(expr[idx+1:])
		var out []Item
		for _, it := range in {
			lv, _ := evalValue(l, []Item{it}); rv, _ := evalValue(r, []Item{it})
			out = append(out, Item{V: merge(lv, rv), FileIndex: it.FileIndex})
		}
		return out, nil
	}
	if strings.HasPrefix(expr, "select(") && strings.HasSuffix(expr, ")") {
		cond := strings.TrimSpace(expr[7:len(expr)-1])
		var out []Item
		for _, it := range in { if evalCond(cond, it) { out = append(out, it) } }
		return out, nil
	}
	if strings.HasSuffix(expr, "| length") { expr = strings.TrimSuffix(expr, "| length") }
	if strings.HasSuffix(expr, " length") && strings.TrimSpace(strings.TrimSuffix(expr, " length")) != expr {
	}
	if expr == "length" {
		var out []Item
		for _, it := range in { out = append(out, Item{V: lengthOf(it.V), FileIndex: it.FileIndex}) }
		return out, nil
	}
	var out []Item
	for _, it := range in {
		vals := selectPath(it.V, parsePath(expr))
		for _, v := range vals { out = append(out, Item{V: v, FileIndex: it.FileIndex}) }
	}
	return out, nil
}

func evalValue(expr string, in []Item) (any, error) {
	expr = strings.TrimSpace(expr)
	if strings.HasPrefix(expr, "{") || strings.HasPrefix(expr, "[") {
		return parseLiteral(expr), nil
	}
	if strings.HasPrefix(expr, "strenv(") && strings.HasSuffix(expr, ")") {
		return os.Getenv(strings.TrimSpace(expr[7:len(expr)-1])), nil
	}
	if strings.HasPrefix(expr, "env(") && strings.HasSuffix(expr, ")") {
		return parseLiteral(os.Getenv(strings.TrimSpace(expr[4:len(expr)-1]))), nil
	}
	if strings.HasPrefix(expr, "load(") && strings.HasSuffix(expr, ")") {
		p := strings.Trim(expr[5:len(expr)-1], ` "'`)
		b, err := os.ReadFile(p); if err != nil { return nil, err }
		return parseInput(b, "auto", p)
	}
	if looksLikeExpr(expr) {
		r, err := evalExpr(expr, in); if err == nil && len(r) > 0 { return r[0].V, nil }
	}
	return parseLiteral(expr), nil
}

func findAssign(s string) (string, int) {
	for _, op := range []string{"+=", "="} {
		depth := 0; quote := rune(0)
		for i, r := range s {
			if quote != 0 { if r == quote { quote = 0 }; continue }
			if r == '\'' || r == '"' { quote = r; continue }
			if r == '[' || r == '{' || r == '(' { depth++ }
			if r == ']' || r == '}' || r == ')' { depth-- }
			if depth == 0 && strings.HasPrefix(s[i:], op) { return op, i }
		}
	}
	return "", -1
}

func findMerge(s string) int {
	depth := 0; quote := rune(0)
	for i, r := range s {
		if quote != 0 { if r == quote { quote = 0 }; continue }
		if r == '\'' || r == '"' { quote = r; continue }
		if r == '[' || r == '{' || r == '(' { depth++ }
		if r == ']' || r == '}' || r == ')' { depth-- }
		if depth == 0 && r == '*' { return i }
	}
	return -1
}

func splitTop(s, sep string) []string {
	var out []string; start, depth := 0, 0; quote := rune(0)
	for i, r := range s {
		if quote != 0 { if r == quote { quote = 0 }; continue }
		if r == '\'' || r == '"' { quote = r; continue }
		if r == '[' || r == '{' || r == '(' { depth++ }
		if r == ']' || r == '}' || r == ')' { depth-- }
		if depth == 0 && strings.HasPrefix(s[i:], sep) { out = append(out, strings.TrimSpace(s[start:i])); start = i+len(sep) }
	}
	out = append(out, strings.TrimSpace(s[start:]))
	return out
}

type Step struct { Key string; Index *int; All bool }

func parsePath(p string) []Step {
	p = strings.TrimSpace(p)
	if p == "." || p == "" { return nil }
	p = strings.TrimPrefix(p, ".")
	var steps []Step
	for i := 0; i < len(p); {
		if p[i] == '.' { i++; continue }
		if p[i] == '[' {
			j := strings.IndexByte(p[i:], ']'); if j < 0 { break }; j += i
			inside := strings.Trim(p[i+1:j], ` "'`)
			if inside == "" { steps = append(steps, Step{All:true}) } else if n, err := strconv.Atoi(inside); err == nil { steps = append(steps, Step{Index:&n}) } else { steps = append(steps, Step{Key:inside}) }
			i = j+1; continue
		}
		j := i
		for j < len(p) && p[j] != '.' && p[j] != '[' { j++ }
		part := p[i:j]
		if n, err := strconv.Atoi(part); err == nil { steps = append(steps, Step{Index:&n}) } else { steps = append(steps, Step{Key:part}) }
		i = j
	}
	return steps
}

func selectPath(v any, steps []Step) []any {
	if len(steps) == 0 { return []any{v} }
	s := steps[0]
	if s.All {
		var out []any
		for _, e := range asSlice(v) { out = append(out, selectPath(e, steps[1:])...) }
		return out
	}
	if s.Index != nil {
		arr, ok := v.([]any); if !ok { return []any{nil} }
		idx := *s.Index; if idx < 0 { idx = len(arr)+idx }
		if idx < 0 || idx >= len(arr) { return []any{nil} }
		return selectPath(arr[idx], steps[1:])
	}
	if m, ok := v.(map[string]any); ok { return selectPath(m[s.Key], steps[1:]) }
	return []any{nil}
}

func getPath(v any, steps []Step) any { vals := selectPath(v, steps); if len(vals)==0 { return nil }; return vals[0] }

func setPathAny(root any, steps []Step, val any) any {
	if len(steps) == 0 { return val }
	if root == nil {
		if steps[0].Index != nil { root = []any{} } else { root = map[string]any{} }
	}
	switch cur := root.(type) {
	case map[string]any:
		s := steps[0]
		if s.Key == "" && s.Index != nil { return root }
		cur[s.Key] = setPathAny(cur[s.Key], steps[1:], val)
		return cur
	case []any:
		s := steps[0]; if s.Index == nil { return root }
		idx := *s.Index; if idx < 0 { idx = len(cur)+idx }
		for len(cur) <= idx { cur = append(cur, nil) }
		cur[idx] = setPathAny(cur[idx], steps[1:], val)
		return cur
	default:
		return setPathAny(nil, steps, val)
	}
}

func setPath(root map[string]any, steps []Step, val any) { setPathAny(root, steps, val) }

func evalCond(cond string, it Item) bool {
	if strings.Contains(cond, "==") {
		parts := strings.SplitN(cond, "==", 2)
		l, _ := evalValue(parts[0], []Item{it}); r := parseLiteral(strings.TrimSpace(parts[1]))
		return fmt.Sprint(l) == fmt.Sprint(r)
	}
	if cond == "true" { return true }
	v, _ := evalValue(cond, []Item{it})
	return !isFalsey(v)
}

func parseLiteral(s string) any {
	s = strings.TrimSpace(s)
	if s == "null" || s == "~" { return nil }
	if s == "true" { return true }
	if s == "false" { return false }
	if (strings.HasPrefix(s, `"`) && strings.HasSuffix(s, `"`)) || (strings.HasPrefix(s, `'`) && strings.HasSuffix(s, `'`)) {
		u, err := strconv.Unquote(s); if err == nil { return u }
		return strings.Trim(s, `"'`)
	}
	if strings.HasPrefix(s, "{") || strings.HasPrefix(s, "[") {
		var v any
		if json.Unmarshal([]byte(s), &v) == nil { return v }
		if yaml.Unmarshal([]byte(s), &v) == nil { return normalize(v) }
	}
	if i, err := strconv.ParseInt(s, 10, 64); err == nil { return i }
	if f, err := strconv.ParseFloat(s, 64); err == nil { return f }
	return s
}

func addVals(a, b any) any {
	switch x := a.(type) {
	case []any:
		return append(x, asSlice(b)...)
	case string:
		return x + fmt.Sprint(b)
	case int, int64, float64:
		return toFloat(a) + toFloat(b)
	default:
		return b
	}
}

func merge(a, b any) any {
	am, aok := a.(map[string]any); bm, bok := b.(map[string]any)
	if aok && bok {
		out := clone(am).(map[string]any)
		for k, v := range bm { if ov, ok := out[k]; ok { out[k] = merge(ov, v) } else { out[k] = v } }
		return out
	}
	return b
}

func asSlice(v any) []any {
	if v == nil { return nil }
	if a, ok := v.([]any); ok { return a }
	return []any{v}
}

func clone(v any) any { b, _ := json.Marshal(v); var out any; json.Unmarshal(b, &out); return out }
func toFloat(v any) float64 { f, _ := strconv.ParseFloat(fmt.Sprint(v), 64); return f }
func lengthOf(v any) int { switch x := v.(type) { case []any: return len(x); case map[string]any: return len(x); case string: return len(x); default: if v==nil {return 0}; return 1 } }
func isFalsey(v any) bool { return v == nil || v == false }
func firstFile(files []string) string { if len(files)>0 { return files[0] }; return "" }

func writeResults(w io.Writer, items []Item, cfg Config, file string) error {
	sep := "\n"; if cfg.nulOutput { sep = "\x00" }
	for i, it := range items {
		if i > 0 { fmt.Fprint(w, sep) }
		if err := writeOne(w, it.V, cfg, file); err != nil { return err }
	}
	if len(items) > 0 { fmt.Fprint(w, sep) }
	return nil
}

func writeOne(w io.Writer, v any, cfg Config, file string) error {
	outFmt := cfg.outFmt
	if outFmt == "auto" || outFmt == "" {
		ext := strings.ToLower(filepath.Ext(file))
		if ext == ".json" { outFmt = "json" } else { outFmt = "yaml" }
	}
	if cfg.pretty && outFmt == "yaml" && strings.ToLower(filepath.Ext(file)) == ".json" { outFmt = "json" }
	switch outFmt {
	case "json":
		b, err := json.MarshalIndent(v, "", strings.Repeat(" ", cfg.indent)); if err != nil { return err }
		_, err = w.Write(b); return err
	case "base64":
		fmt.Fprint(w, base64.StdEncoding.EncodeToString([]byte(fmt.Sprint(v)))); return nil
	case "uri":
		fmt.Fprint(w, url.QueryEscape(fmt.Sprint(v))); return nil
	case "props":
		writeProps(w, "", v); return nil
	case "csv", "tsv":
		cw := csv.NewWriter(w); if outFmt=="tsv" { cw.Comma = '\t' }
		for _, row := range asSlice(v) { var rec []string; for _, c := range asSlice(row) { rec = append(rec, fmt.Sprint(c)) }; cw.Write(rec) }
		cw.Flush(); return cw.Error()
	default:
		if cfg.unwrap {
			switch v.(type) {
			case string, int, int64, float64, bool, nil:
				if v == nil { fmt.Fprint(w, "null"); return nil }
				fmt.Fprint(w, v); return nil
			}
		}
		var buf bytes.Buffer
		enc := yaml.NewEncoder(&buf); enc.SetIndent(cfg.indent)
		if err := enc.Encode(v); err != nil { return err }
		enc.Close()
		b := buf.Bytes()
		b = regexp.MustCompile(`(?m)^(\s*)"([A-Za-z_][A-Za-z0-9_-]*)":`).ReplaceAll(b, []byte(`${1}${2}:`))
		_, err := w.Write(bytes.TrimSuffix(b, []byte("\n")))
		return err
	}
}

func writeProps(w io.Writer, prefix string, v any) {
	switch x := v.(type) {
	case map[string]any:
		for k, v := range x { p := k; if prefix != "" { p = prefix+"."+k }; writeProps(w, p, v) }
	case []any:
		for i, v := range x { writeProps(w, fmt.Sprintf("%s.%d", prefix, i), v) }
	default:
		fmt.Fprintf(w, "%s = %v\n", prefix, x)
	}
}

func printHelp() {
	fmt.Print(`yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -e, --exit-status                       set exit status if there are no matches or null or false is returned
  -h, --help                              help for yq
  -I, --indent int                        sets indent level for output (default 2)
  -i, --inplace                           update the file in place of first file given.
  -n, --null-input                        Don't read input, simply evaluate the expression given.
  -o, --output-format string              output format type. (default "auto")
  -p, --input-format string               parse format for input. (default "auto")
  -P, --prettyPrint                       pretty print
  -V, --version                           Print version information and quit
`)
}

var _ = regexp.MustCompile
