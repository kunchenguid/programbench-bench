package main

import (
	"bufio"
	"database/sql"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"unicode"

	_ "github.com/mattn/go-sqlite3"
)

type Config struct {
	mode      string
	headers   bool
	sep       string
	rowSep    string
	nullValue string
	bail      bool
	echo      bool
}

type Result struct {
	Cols  []string
	Types []string
	Rows  [][]any
}

func main() {
	cfg := Config{mode: "duckbox", headers: false, sep: "|", rowSep: "\n", nullValue: "NULL"}
	dbName := ":memory:"
	var sqlText, fileText string
	var pre []string
	noStdin := false

	args := os.Args[1:]
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "-help", "--help":
			usage()
			return
		case "-version", "--version":
			fmt.Println("v0.0.1 (Unknown Version) 780a7396")
			return
		case "-csv":
			cfg.mode = "csv"; cfg.headers = true
		case "-list":
			cfg.mode = "list"; cfg.headers = true
		case "-column":
			cfg.mode = "column"; cfg.headers = true
		case "-line":
			cfg.mode = "line"
		case "-json":
			cfg.mode = "json"
		case "-jsonlines":
			cfg.mode = "jsonlines"
		case "-html":
			cfg.mode = "html"; cfg.headers = true
		case "-markdown":
			cfg.mode = "markdown"
		case "-quote":
			cfg.mode = "quote"; cfg.headers = true
		case "-ascii":
			cfg.mode = "ascii"; cfg.headers = true
		case "-table":
			cfg.mode = "table"
		case "-box":
			cfg.mode = "box"
		case "-header":
			cfg.headers = true
		case "-noheader":
			cfg.headers = false
		case "-bail":
			cfg.bail = true
		case "-echo":
			cfg.echo = true
		case "-batch", "-interactive", "-readonly", "-safe", "-unsigned", "-unredacted", "-no-init", "-ui":
		case "-no-stdin":
			noStdin = true
		case "-separator":
			i++; if i < len(args) { cfg.sep = decodeSep(args[i]) }
		case "-newline":
			i++; if i < len(args) { cfg.rowSep = decodeSep(args[i]) }
		case "-nullvalue":
			i++; if i < len(args) { cfg.nullValue = args[i] }
		case "-cmd", "-init":
			i++; if i < len(args) { pre = append(pre, readMaybeFile(args[i])) }
		case "-c", "-s":
			i++; if i < len(args) { sqlText = args[i]; noStdin = true }
		case "-f":
			i++; if i < len(args) { fileText = readMaybeFile(args[i]); noStdin = true }
		case "-format":
			b, _ := io.ReadAll(os.Stdin); fmt.Print(string(b)); return
		case "-format-file":
			i++; if i < len(args) { fmt.Print(readMaybeFile(args[i])) }; return
		case "-storage-version":
			i++
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "unknown option: %s\n", a)
				os.Exit(1)
			}
			dbName = a
			if i+1 < len(args) {
				sqlText = strings.Join(args[i+1:], " ")
				noStdin = true
			}
			i = len(args)
		}
	}

	db, err := sql.Open("sqlite3", dbPath(dbName))
	if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
	defer db.Close()

	ok := true
	for _, s := range pre {
		if !runScript(db, &cfg, s) && cfg.bail { ok = false; break }
	}
	if ok && fileText != "" { ok = runScript(db, &cfg, fileText) }
	if ok && sqlText != "" { ok = runScript(db, &cfg, sqlText) }
	if ok && !noStdin && !isTerminal() {
		b, _ := io.ReadAll(os.Stdin)
		if len(strings.TrimSpace(string(b))) > 0 { ok = runScript(db, &cfg, string(b)) }
	}
	if !ok { os.Exit(1) }
}

func usage() {
	fmt.Print("Usage: ./executable [OPTIONS] FILENAME [SQL]\n\nFILENAME is the name of a DuckDB database. A new database is created\nif the file does not previously exist.\n\nOPTIONS:\n  -csv                     set output mode to 'csv'\n  -c COMMAND               run \"COMMAND\" and exit\n  -s COMMAND               run \"COMMAND\" and exit\n  -f FILENAME              read/process named file and exit\n  -header                  turn headers on\n  -help                    show help message\n  -json                    set output mode to 'json'\n  -jsonlines               set output mode to 'jsonlines'\n  -list                    set output mode to 'list'\n  -separator SEP           set output column separator. Default: '|'\n  -version                 show DuckDB version\n")
}

func dbPath(name string) string {
	if name == "" || name == ":memory:" { return ":memory:" }
	return name
}

func readMaybeFile(path string) string {
	b, err := os.ReadFile(path)
	if err == nil { return string(b) }
	return path
}

func isTerminal() bool {
	st, err := os.Stdin.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) != 0
}

func decodeSep(s string) string {
	s = strings.ReplaceAll(s, `\n`, "\n")
	s = strings.ReplaceAll(s, `\t`, "\t")
	return s
}

func runScript(db *sql.DB, cfg *Config, script string) bool {
	ok := true
	for _, stmt := range splitStatements(script) {
		stmt = strings.TrimSpace(stmt)
		if stmt == "" { continue }
		if cfg.echo { fmt.Println(stmt + ";") }
		if strings.HasPrefix(stmt, ".") {
			if !dotCommand(db, cfg, stmt) { ok = false }
		} else if !runSQL(db, cfg, stmt) {
			ok = false
		}
		if !ok && cfg.bail { return false }
	}
	return ok
}

func splitStatements(s string) []string {
	var out []string
	var b strings.Builder
	inQuote := rune(0)
	lineStart := true
	for _, r := range s {
		if inQuote != 0 {
			b.WriteRune(r)
			if r == inQuote { inQuote = 0 }
			continue
		}
		if r == '\'' || r == '"' || r == '`' {
			inQuote = r; b.WriteRune(r); lineStart = false; continue
		}
		if r == '\n' {
			txt := strings.TrimSpace(b.String())
			if strings.HasPrefix(txt, ".") {
				out = append(out, txt); b.Reset(); lineStart = true; continue
			}
			b.WriteRune(r); lineStart = true; continue
		}
		if r == ';' {
			out = append(out, b.String()); b.Reset(); lineStart = true; continue
		}
		if lineStart && unicode.IsSpace(r) { b.WriteRune(r); continue }
		b.WriteRune(r); lineStart = false
	}
	if strings.TrimSpace(b.String()) != "" { out = append(out, b.String()) }
	return out
}

func dotCommand(db *sql.DB, cfg *Config, stmt string) bool {
	fields := strings.Fields(stmt)
	if len(fields) == 0 { return true }
	switch fields[0] {
	case ".quit", ".exit":
		os.Exit(0)
	case ".help":
		fmt.Print(".help                    Show help text\n.mode MODE               Set output mode\n.headers on|off          Turn display of headers on or off\n.tables                  List names of tables\n.schema ?TABLE?          Show CREATE statements\n.read FILE               Read input from FILE\n")
	case ".version":
		fmt.Println("v0.0.1 (Unknown Version) 780a7396")
	case ".mode":
		if len(fields) > 1 { cfg.mode = fields[1] }
	case ".headers", ".header":
		if len(fields) > 1 { cfg.headers = onoff(fields[1]) }
	case ".separator":
		if len(fields) > 1 { cfg.sep = decodeSep(fields[1]) }
		if len(fields) > 2 { cfg.rowSep = decodeSep(fields[2]) }
	case ".nullvalue":
		if len(fields) > 1 { cfg.nullValue = strings.Join(fields[1:], " ") }
	case ".print":
		if len(fields) > 1 { fmt.Println(strings.Join(fields[1:], " ")) }
	case ".read":
		if len(fields) > 1 { return runScript(db, cfg, readMaybeFile(fields[1])) }
	case ".import":
		if len(fields) > 2 { return importCSV(db, fields[1], fields[2]) }
	case ".tables":
		res, err := queryRows(db, "select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name")
		if err != nil { fmt.Fprintln(os.Stderr, err); return false }
		names := make([]string, 0, len(res.Rows))
		for _, r := range res.Rows { names = append(names, fmt.Sprint(r[0])) }
		if len(names) > 0 { fmt.Println(strings.Join(names, " ")) }
	case ".schema":
		q := "select sql from sqlite_master where sql is not null"
		if len(fields) > 1 { q += " and name = " + sqlQuote(fields[1]) }
		q += " order by name"
		res, err := queryRows(db, q)
		if err != nil { fmt.Fprintln(os.Stderr, err); return false }
		for _, r := range res.Rows { fmt.Println(fmt.Sprint(r[0]) + ";") }
	default:
		fmt.Fprintf(os.Stderr, "Unknown command or invalid arguments:  \"%s\". Enter \".help\" for help\n", stmt)
		return false
	}
	return true
}

func onoff(s string) bool {
	s = strings.ToLower(s)
	return s == "on" || s == "yes" || s == "1" || s == "true"
}

func runSQL(db *sql.DB, cfg *Config, stmt string) bool {
	if handled, ok := specialSQL(db, cfg, stmt); ok {
		return handled
	}
	if res, ok, err := tryCSVSelect(stmt); ok {
		if err != nil { fmt.Fprintln(os.Stderr, err); return false }
		render(cfg, res); return true
	}
	stmt = translate(stmt)
	rows, err := db.Query(stmt)
	if err == nil {
		defer rows.Close()
		res, err := collect(rows)
		if err != nil { fmt.Fprintln(os.Stderr, err); return false }
		render(cfg, res)
		return true
	}
	if _, e := db.Exec(stmt); e != nil {
		fmt.Fprintln(os.Stderr, formatErr(e))
		return false
	}
	return true
}

func specialSQL(db *sql.DB, cfg *Config, stmt string) (bool, bool) {
	t := strings.TrimSpace(stmt)
	low := strings.ToLower(t)
	if low == "show tables" || low == "show tables;" {
		res, err := queryRows(db, "select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name")
		if err != nil { fmt.Fprintln(os.Stderr, err); return false, true }
		res.Cols = []string{"name"}; render(cfg, res); return true, true
	}
	if regexp.MustCompile(`(?is)^select\s+version\s*\(\s*\)\s*$`).MatchString(t) {
		render(cfg, Result{Cols: []string{"version()"}, Types: []string{"varchar"}, Rows: [][]any{{"v0.0.1"}}})
		return true, true
	}
	if m := regexp.MustCompile(`(?is)^select\s+range\s*\(\s*([0-9]+)\s*\)\s*$`).FindStringSubmatch(t); m != nil {
		n, _ := strconv.Atoi(m[1])
		parts := make([]string, n)
		for i := 0; i < n; i++ { parts[i] = strconv.Itoa(i) }
		render(cfg, Result{Cols: []string{fmt.Sprintf("\"range\"(%d)", n)}, Types: []string{"int64[]"}, Rows: [][]any{{"[" + strings.Join(parts, ", ") + "]"}}})
		return true, true
	}
	if m := regexp.MustCompile(`(?is)^describe\s+([A-Za-z_][A-Za-z0-9_]*)\s*$`).FindStringSubmatch(t); m != nil {
		res, err := queryRows(db, "pragma table_info("+sqlQuote(m[1])+")")
		if err != nil { fmt.Fprintln(os.Stderr, err); return false, true }
		out := Result{Cols: []string{"column_name", "column_type", "null", "key", "default", "extra"}, Types: []string{"varchar", "varchar", "varchar", "varchar", "varchar", "varchar"}}
		for _, r := range res.Rows {
			out.Rows = append(out.Rows, []any{r[1], strings.ToUpper(fmt.Sprint(r[2])), "YES", "", r[4], ""})
		}
		render(cfg, out); return true, true
	}
	return false, false
}

var csvFromRe = regexp.MustCompile(`(?is)^\s*select\s+\*\s+from\s+(?:(?:read_csv_auto|read_csv)\()?['"]([^'"]+\.csv)['"]\)?\s*$`)

func tryCSVSelect(stmt string) (Result, bool, error) {
	m := csvFromRe.FindStringSubmatch(strings.TrimSpace(stmt))
	if m == nil { return Result{}, false, nil }
	f, err := os.Open(m[1])
	if err != nil {
		if !filepath.IsAbs(m[1]) {
			f, err = os.Open(filepath.Join("/workspace", m[1]))
		}
	}
	if err != nil { return Result{}, true, err }
	defer f.Close()
	cr := csv.NewReader(f)
	records, err := cr.ReadAll()
	if err != nil { return Result{}, true, err }
	if len(records) == 0 { return Result{}, true, nil }
	res := Result{Cols: records[0], Types: make([]string, len(records[0]))}
	for i := range res.Types { res.Types[i] = "varchar" }
	for _, rec := range records[1:] {
		row := make([]any, len(res.Cols))
		for i := range row {
			if i < len(rec) { row[i] = rec[i] } else { row[i] = nil }
		}
		res.Rows = append(res.Rows, row)
	}
	return res, true, nil
}

func importCSV(db *sql.DB, path, table string) bool {
	res, ok, err := tryCSVSelect("select * from '" + strings.ReplaceAll(path, "'", "''") + "'")
	if !ok || err != nil { if err != nil { fmt.Fprintln(os.Stderr, err) }; return false }
	if len(res.Cols) == 0 { return true }
	cols := make([]string, len(res.Cols))
	for i, c := range res.Cols { cols[i] = quoteIdent(c) + " text" }
	if _, err := db.Exec("create table if not exists " + quoteIdent(table) + "(" + strings.Join(cols, ",") + ")"); err != nil {
		fmt.Fprintln(os.Stderr, err); return false
	}
	names := make([]string, len(res.Cols)); qs := make([]string, len(res.Cols))
	for i, c := range res.Cols { names[i] = quoteIdent(c); qs[i] = "?" }
	tx, err := db.Begin(); if err != nil { fmt.Fprintln(os.Stderr, err); return false }
	st, err := tx.Prepare("insert into " + quoteIdent(table) + "(" + strings.Join(names, ",") + ") values (" + strings.Join(qs, ",") + ")")
	if err != nil { _ = tx.Rollback(); fmt.Fprintln(os.Stderr, err); return false }
	defer st.Close()
	for _, row := range res.Rows {
		if _, err := st.Exec(row...); err != nil { _ = tx.Rollback(); fmt.Fprintln(os.Stderr, err); return false }
	}
	if err := tx.Commit(); err != nil { fmt.Fprintln(os.Stderr, err); return false }
	return true
}

func quoteIdent(s string) string {
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func translate(s string) string {
	repls := []struct{ a, b string }{
		{`(?i)\btrue\b`, "1"}, {`(?i)\bfalse\b`, "0"},
		{`(?i)\bvarchar\b`, "text"}, {`(?i)\bdouble\b`, "real"}, {`(?i)\bboolean\b`, "integer"},
	}
	for _, r := range repls { s = regexp.MustCompile(r.a).ReplaceAllString(s, r.b) }
	return s
}

func queryRows(db *sql.DB, q string) (Result, error) {
	rows, err := db.Query(q)
	if err != nil { return Result{}, err }
	defer rows.Close()
	return collect(rows)
}

func collect(rows *sql.Rows) (Result, error) {
	cols, err := rows.Columns()
	if err != nil { return Result{}, err }
	res := Result{Cols: cols, Types: make([]string, len(cols))}
	for i := range res.Types { res.Types[i] = "varchar" }
	for rows.Next() {
		vals := make([]any, len(cols))
		ptr := make([]any, len(cols))
		for i := range vals { ptr[i] = &vals[i] }
		if err := rows.Scan(ptr...); err != nil { return res, err }
		for i, v := range vals {
			switch x := v.(type) {
			case int64:
				if x >= math.MinInt32 && x <= math.MaxInt32 { res.Types[i] = "int32" } else { res.Types[i] = "int64" }
			case float64:
				res.Types[i] = "double"
			case []byte:
				vals[i] = string(x); if res.Types[i] == "" { res.Types[i] = "varchar" }
			case nil:
			default:
				res.Types[i] = "varchar"
			}
		}
		res.Rows = append(res.Rows, vals)
	}
	return res, rows.Err()
}

func render(cfg *Config, res Result) {
	switch cfg.mode {
	case "csv":
		renderCSV(cfg, res, false)
	case "list":
		renderList(cfg, res, false)
	case "quote":
		renderList(cfg, res, true)
	case "column":
		renderColumn(cfg, res)
	case "line":
		renderLine(cfg, res)
	case "json":
		renderJSON(res, false)
	case "jsonlines":
		renderJSON(res, true)
	case "html":
		renderHTML(cfg, res)
	case "markdown":
		renderTable(cfg, res, "markdown")
	case "table":
		renderTable(cfg, res, "table")
	case "box":
		renderTable(cfg, res, "box")
	case "ascii":
		renderASCII(cfg, res)
	default:
		renderDuckBox(cfg, res)
	}
}

func cell(cfg *Config, v any) string {
	if v == nil { return cfg.nullValue }
	switch x := v.(type) {
	case int64: return strconv.FormatInt(x, 10)
	case float64: return strconv.FormatFloat(x, 'f', -1, 64)
	default: return fmt.Sprint(x)
	}
}

func renderCSV(cfg *Config, res Result, quote bool) {
	w := csv.NewWriter(os.Stdout)
	if cfg.headers { _ = w.Write(res.Cols) }
	for _, r := range res.Rows {
		rec := make([]string, len(r))
		for i := range r { rec[i] = cell(cfg, r[i]) }
		_ = w.Write(rec)
	}
	w.Flush()
}

func renderList(cfg *Config, res Result, quote bool) {
	write := func(parts []string) { fmt.Print(strings.Join(parts, cfg.sep) + cfg.rowSep) }
	if cfg.headers {
		h := append([]string(nil), res.Cols...)
		if quote { for i := range h { h[i] = sqlQuote(h[i]) } }
		write(h)
	}
	for _, r := range res.Rows {
		p := make([]string, len(r))
		for i := range r {
			p[i] = cell(cfg, r[i])
			if quote && r[i] != nil && !isNumber(r[i]) { p[i] = sqlQuote(p[i]) }
		}
		write(p)
	}
}

func renderColumn(cfg *Config, res Result) {
	widths := widths(cfg, res, false)
	if cfg.headers {
		printPadded(res.Cols, widths)
		d := make([]string, len(widths)); for i, w := range widths { d[i] = strings.Repeat("-", w) }
		printPadded(d, widths)
	}
	for _, r := range res.Rows {
		p := rowStrings(cfg, r); printPadded(p, widths)
	}
}

func printPadded(vals []string, widths []int) {
	for i, v := range vals {
		if i > 0 { fmt.Print("  ") }
		fmt.Print(v + strings.Repeat(" ", widths[i]-len(v)))
	}
	fmt.Println()
}

func renderLine(cfg *Config, res Result) {
	for ri, r := range res.Rows {
		if ri > 0 { fmt.Println() }
		for i, c := range res.Cols {
			fmt.Printf("%5s = %s\n", c, cell(cfg, r[i]))
		}
	}
}

func renderJSON(res Result, lines bool) {
	arr := make([]map[string]any, len(res.Rows))
	for i, r := range res.Rows {
		m := map[string]any{}
		for j, c := range res.Cols { m[c] = normJSON(r[j]) }
		arr[i] = m
	}
	if lines {
		for _, m := range arr { b, _ := json.Marshal(m); fmt.Println(string(b)) }
	} else {
		b, _ := json.MarshalIndent(arr, "", "")
		fmt.Println(string(b))
	}
}

func normJSON(v any) any {
	if b, ok := v.([]byte); ok { return string(b) }
	return v
}

func renderHTML(cfg *Config, res Result) {
	if cfg.headers {
		for _, c := range res.Cols { fmt.Printf("<tr><th>%s</th>\n", html.EscapeString(c)) }
		fmt.Println("</tr>")
	}
	for _, r := range res.Rows {
		for _, v := range r { fmt.Printf("<tr><td>%s</td>\n", html.EscapeString(cell(cfg, v))) }
		fmt.Println("</tr>")
	}
}

func renderASCII(cfg *Config, res Result) {
	if cfg.headers { for _, c := range res.Cols { fmt.Println(c) } }
	for _, r := range res.Rows { for _, v := range r { fmt.Println(cell(cfg, v)) } }
}

func renderDuckBox(cfg *Config, res Result) {
	if len(res.Cols) == 0 { return }
	vals := make([][]string, 0, len(res.Rows)+2)
	vals = append(vals, res.Cols, res.Types)
	for _, r := range res.Rows { vals = append(vals, rowStrings(cfg, r)) }
	w := tableWidths(vals)
	border("┌", "┬", "┐", w)
	printTableRow(res.Cols, w)
	printTableRow(res.Types, w)
	border("├", "┼", "┤", w)
	for _, r := range res.Rows { printTableRow(rowStrings(cfg, r), w) }
	border("└", "┴", "┘", w)
}

func renderTable(cfg *Config, res Result, style string) {
	rows := [][]string{res.Cols}
	for _, r := range res.Rows { rows = append(rows, rowStrings(cfg, r)) }
	w := tableWidths(rows)
	if style == "markdown" {
		printMDRow(res.Cols, w)
		sep := make([]string, len(w)); for i, n := range w { sep[i] = strings.Repeat("-", n) }
		printMDRow(sep, w)
		for _, r := range res.Rows { printMDRow(rowStrings(cfg, r), w) }
		return
	}
	if style == "table" {
		asciiBorder(w)
		printASCIIRow(res.Cols, w)
		asciiBorder(w)
		for _, r := range res.Rows { printASCIIRow(rowStrings(cfg, r), w) }
		asciiBorder(w)
		return
	}
	renderDuckBoxNoTypes(cfg, res, w)
}

func renderDuckBoxNoTypes(cfg *Config, res Result, w []int) {
	border("┌", "┬", "┐", w)
	printTableRow(res.Cols, w)
	border("├", "┼", "┤", w)
	for _, r := range res.Rows { printTableRow(rowStrings(cfg, r), w) }
	border("└", "┴", "┘", w)
}

func rowStrings(cfg *Config, r []any) []string {
	p := make([]string, len(r)); for i := range r { p[i] = cell(cfg, r[i]) }; return p
}

func widths(cfg *Config, res Result, types bool) []int {
	rows := [][]string{res.Cols}
	if types { rows = append(rows, res.Types) }
	for _, r := range res.Rows { rows = append(rows, rowStrings(cfg, r)) }
	return tableWidths(rows)
}

func tableWidths(rows [][]string) []int {
	if len(rows) == 0 { return nil }
	w := make([]int, len(rows[0]))
	for _, r := range rows { for i, s := range r { if len(s) > w[i] { w[i] = len(s) } } }
	for i := range w { w[i] += 2; if w[i] < 5 { w[i] = 5 } }
	return w
}

func border(l, m, r string, w []int) {
	fmt.Print(l); for i, n := range w { if i > 0 { fmt.Print(m) }; fmt.Print(strings.Repeat("─", n)) }; fmt.Println(r)
}

func printTableRow(vals []string, w []int) {
	fmt.Print("│")
	for i, v := range vals { fmt.Print(" " + pad(v, w[i]-2) + " │") }
	fmt.Println()
}

func pad(s string, n int) string {
	if len(s) >= n { return s }
	return s + strings.Repeat(" ", n-len(s))
}

func asciiBorder(w []int) {
	fmt.Print("+"); for _, n := range w { fmt.Print(strings.Repeat("-", n) + "+") }; fmt.Println()
}

func printASCIIRow(vals []string, w []int) {
	fmt.Print("|"); for i, v := range vals { fmt.Print(" " + pad(v, w[i]-2) + " |") }; fmt.Println()
}

func printMDRow(vals []string, w []int) {
	fmt.Print("|"); for i, v := range vals { fmt.Print(" " + pad(v, w[i]-2) + " |") }; fmt.Println()
}

func sqlQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }

func isNumber(v any) bool {
	switch v.(type) { case int64, float64: return true }
	return false
}

func formatErr(e error) string {
	msg := e.Error()
	if strings.Contains(msg, "no such column") { return "Binder Error: " + msg }
	if strings.Contains(msg, "syntax error") { return "Parser Error: " + msg }
	return "Error: " + msg
}

func init() {
	_ = bufio.ErrFinalToken
}
