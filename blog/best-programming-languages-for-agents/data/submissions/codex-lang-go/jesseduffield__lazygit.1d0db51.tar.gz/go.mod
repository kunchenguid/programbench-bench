module programbench-lazygit

go 1.21
