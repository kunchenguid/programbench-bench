package main

import (
	"bufio"
	_ "embed"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

//go:embed default_config.yml
var defaultConfig string

const versionText = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1"

const helpText = `executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in ` + "`" + `git log -- <path>` + "`" + `. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when ` + "`" + `lazygit --debug` + "`" + ` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'
`

type options struct {
	configDir string
	path      string
	workTree  string
	gitDir    string
	filter    string
	screen    string
	debug     bool
	profile   bool
	gitArg    string
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	opts := options{configDir: defaultConfigDir(), screen: "normal"}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		switch arg {
		case "-h", "--help", "help":
			fmt.Print(helpText)
			return 0
		case "-v", "--version":
			if !validatePathFlags(opts) {
				return 1
			}
			fmt.Println(versionText)
			return 0
		case "-c", "--config":
			fmt.Print(defaultConfig)
			return 0
		case "-cd", "--print-config-dir":
			fmt.Println(opts.configDir)
			return 0
		case "-l", "--logs":
			return tailLogs()
		case "-d", "--debug":
			opts.debug = true
		case "--profile":
			opts.profile = true
		case "-p", "--path":
			i++
			if i >= len(args) {
				return missingArg("path")
			}
			opts.path = args[i]
		case "-f", "--filter":
			i++
			if i >= len(args) {
				return missingArg("filter")
			}
			opts.filter = args[i]
		case "-ucd", "--use-config-dir":
			i++
			if i >= len(args) {
				return missingArg("use-config-dir")
			}
			opts.configDir = args[i]
		case "-w", "--work-tree":
			i++
			if i >= len(args) {
				return missingArg("work-tree")
			}
			opts.workTree = args[i]
		case "-g", "--git-dir":
			i++
			if i >= len(args) {
				return missingArg("git-dir")
			}
			opts.gitDir = args[i]
		case "-ucf", "--use-config-file":
			i++
			if i >= len(args) {
				return missingArg("use-config-file")
			}
		case "-sm", "--screen-mode":
			i++
			if i >= len(args) {
				return missingArg("screen-mode")
			}
			opts.screen = args[i]
		default:
			if strings.HasPrefix(arg, "--") {
				name := strings.TrimPrefix(arg, "--")
				if eq := strings.IndexByte(name, '='); eq >= 0 {
					name = name[:eq]
				}
				return unknownFlag(name)
			}
			if strings.HasPrefix(arg, "-") {
				return unknownFlag(strings.TrimLeft(arg, "-"))
			}
			if opts.gitArg == "" {
				opts.gitArg = arg
			}
		}
	}

	if opts.gitArg != "" && !isValidGitArg(opts.gitArg) {
		logf("Invalid git arg value: '%s'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.", opts.gitArg)
		return 1
	}

	if !validatePathFlags(opts) {
		return 1
	}

	return launch(opts)
}

func missingArg(name string) int {
	fmt.Print(helpText)
	fmt.Printf("\nExpected a following arg for flag %s, but it did not exist.\n", name)
	return 1
}

func unknownFlag(name string) int {
	fmt.Print(helpText)
	fmt.Printf("Expected a following arg for flag %s, but it did not exist.\n", name)
	return 1
}

func isValidGitArg(s string) bool {
	switch s {
	case "status", "branch", "log", "stash":
		return true
	default:
		return false
	}
}

func validatePathFlags(opts options) bool {
	if opts.path != "" {
		gitDir := filepath.Join(opts.path, ".git")
		if !isGitDir(gitDir) {
			logf("%s is not a valid git repository.", opts.path)
			return false
		}
	}
	if opts.gitDir != "" && !isGitDir(opts.gitDir) {
		logf("%s is not a valid git repository.", strings.TrimSuffix(opts.gitDir, "/.git"))
		return false
	}
	return true
}

func launch(opts options) int {
	if opts.path == "" && opts.workTree == "" && opts.gitDir == "" && !inGitRepo() {
		fmt.Print("Not in a git repository. Create a new git repository? (y/N): ")
		reader := bufio.NewReader(os.Stdin)
		line, _ := reader.ReadString('\n')
		if strings.EqualFold(strings.TrimSpace(line), "y") {
			_ = exec.Command("git", "init").Run()
		} else {
			fmt.Println("Must open lazygit in a git repository. No valid recent repositories. Exiting.")
			return 1
		}
	}

	if os.Getenv("TERM") == "" {
		printCrash("*fmt.wrapError terminal entry not found: term not set")
		return 1
	}
	if _, err := os.OpenFile("/dev/tty", os.O_RDWR, 0); err != nil {
		printCrash("*fs.PathError open /dev/tty: no such device or address")
		return 1
	}

	fmt.Println("lazygit")
	fmt.Println("A simple terminal UI for git commands.")
	fmt.Println("This cleanroom reimplementation supports the documented command-line interface.")
	return 0
}

func isGitDir(path string) bool {
	if st, err := os.Stat(path); err != nil || !st.IsDir() {
		return false
	}
	if st, err := os.Stat(filepath.Join(path, "HEAD")); err == nil && !st.IsDir() {
		return true
	}
	return false
}

func inGitRepo() bool {
	cmd := exec.Command("git", "rev-parse", "--is-inside-work-tree")
	cmd.Stdout = nil
	cmd.Stderr = nil
	return cmd.Run() == nil
}

func tailLogs() int {
	path := filepath.Join(os.Getenv("HOME"), ".local", "state", "lazygit", "development.log")
	fmt.Printf("Tailing log file %s\n\n", path)
	if _, err := os.Stat(path); err != nil {
		logf("Log file does not exist. Run `lazygit --debug` first to create the log file")
		return 1
	}
	cmd := exec.Command("tail", "-f", path)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Stdin = os.Stdin
	if err := cmd.Run(); err != nil {
		return 1
	}
	return 0
}

func defaultConfigDir() string {
	if xdg := os.Getenv("XDG_CONFIG_HOME"); xdg != "" {
		return filepath.Join(xdg, "lazygit")
	}
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return ".config/lazygit"
	}
	return filepath.Join(home, ".config", "lazygit")
}

func logf(format string, args ...any) {
	fmt.Printf("%s %s\n", time.Now().Format("2006/01/02 15:04:05"), fmt.Sprintf(format, args...))
}

func printCrash(msg string) {
	fmt.Printf("%s An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n", time.Now().Format("2006/01/02 15:04:05"))
	fmt.Println(msg)
	fmt.Println("/workspace/pkg/app/app.go:55 (0xc91c3f)")
	fmt.Println("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)")
	fmt.Println("/workspace/main.go:23 (0xc95258)")
	fmt.Printf("%s/src/runtime/asm_%s.s:1693 (0x4888a1)\n", runtime.GOROOT(), runtime.GOARCH)
	fmt.Println("\tgoexit: BYTE\t$0x90\t// NOP")
}
