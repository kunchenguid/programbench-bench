package main

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const version = "hyperfine 1.20.0"

type options struct {
	warmup        int
	minRuns       int
	maxRuns       int
	runs          int
	setup         string
	prepares      []string
	concludes     []string
	cleanup       string
	shell         string
	noShell       bool
	ignoreMode    string
	ignoreCodes   map[int]bool
	ignoreAll     bool
	style         string
	sortMethod    string
	timeUnit      string
	showOutput    bool
	outputs       []string
	input         string
	names         []string
	exportCSV     string
	exportJSON    string
	exportMD      string
	exportADoc    string
	exportOrg     string
	reference     string
	referenceName string
	params        []parameter
	commands      []string
}

type parameter struct {
	name   string
	values []string
}

type benchResult struct {
	Command     string    `json:"command"`
	Mean        float64   `json:"mean"`
	Stddev      float64   `json:"stddev"`
	Median      float64   `json:"median"`
	User        float64   `json:"user"`
	System      float64   `json:"system"`
	Min         float64   `json:"min"`
	Max         float64   `json:"max"`
	Times       []float64 `json:"times"`
	MemoryUsage []int64   `json:"memory_usage_byte,omitempty"`
	ExitCodes   []int     `json:"exit_codes"`
	displayName string
}

func main() {
	opt, err := parseArgs(os.Args[1:])
	if err != nil {
		if errors.Is(err, errHelp) {
			fmt.Print(helpText())
			os.Exit(0)
		}
		if errors.Is(err, errVersion) {
			fmt.Println(version)
			os.Exit(0)
		}
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if opt.style == "none" {
		// Still run benchmarks and exports, but suppress normal chatter.
	}
	results, code := runAll(opt)
	if len(results) > 0 {
		_ = writeExports(opt, results)
	}
	os.Exit(code)
}

var errHelp = errors.New("help")
var errVersion = errors.New("version")

func parseArgs(args []string) (*options, error) {
	opt := &options{minRuns: 10, shell: "default", style: "auto", sortMethod: "auto", input: "null", ignoreCodes: map[int]bool{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opt.commands = append(opt.commands, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			opt.commands = append(opt.commands, args[i:]...)
			break
		}
		next := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("error: a value is required for '%s' but none was supplied", a)
			}
			i++
			return args[i], nil
		}
		parseInt := func(name string) (int, error) {
			s, err := next()
			if err != nil {
				return 0, err
			}
			n, err := strconv.Atoi(s)
			if err != nil {
				return 0, fmt.Errorf("error: invalid value '%s' for '%s': invalid digit found in string", s, name)
			}
			return n, nil
		}
		switch {
		case a == "-h" || a == "--help":
			return nil, errHelp
		case a == "-V" || a == "--version":
			return nil, errVersion
		case a == "-w" || a == "--warmup":
			n, e := parseInt("--warmup")
			if e != nil {
				return nil, e
			}
			opt.warmup = n
		case a == "-m" || a == "--min-runs":
			n, e := parseInt("--min-runs")
			if e != nil {
				return nil, e
			}
			opt.minRuns = n
		case a == "-M" || a == "--max-runs":
			n, e := parseInt("--max-runs")
			if e != nil {
				return nil, e
			}
			opt.maxRuns = n
		case a == "-r" || a == "--runs":
			n, e := parseInt("--runs")
			if e != nil {
				return nil, e
			}
			opt.runs = n
		case a == "-s" || a == "--setup":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.setup = s
		case a == "--reference":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.reference = s
		case a == "--reference-name":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.referenceName = s
		case a == "-p" || a == "--prepare":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.prepares = append(opt.prepares, s)
		case a == "-C" || a == "--conclude" || a == "--conclude":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.concludes = append(opt.concludes, s)
		case a == "-c" || a == "--cleanup":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.cleanup = s
		case a == "-P" || a == "--parameter-scan":
			if i+3 >= len(args) {
				return nil, fmt.Errorf("error: the following required arguments were not provided:\n  <VAR> <MIN> <MAX>")
			}
			name, min, max := args[i+1], args[i+2], args[i+3]
			i += 3
			vals, err := scanValues(min, max, "1")
			if err != nil {
				return nil, err
			}
			opt.params = append(opt.params, parameter{name, vals})
		case a == "-D" || a == "--parameter-step-size":
			s, e := next()
			if e != nil {
				return nil, e
			}
			if len(opt.params) == 0 {
				return nil, fmt.Errorf("error: the argument '--parameter-step-size <DELTA>' requires '--parameter-scan <VAR> <MIN> <MAX>'")
			}
			// Recompute last scan if possible from stored first/last values.
			p := &opt.params[len(opt.params)-1]
			if len(p.values) >= 2 {
				vals, err := scanValues(p.values[0], p.values[len(p.values)-1], s)
				if err != nil {
					return nil, err
				}
				p.values = vals
			}
		case a == "-L" || a == "--parameter-list":
			if i+2 >= len(args) {
				return nil, fmt.Errorf("error: the following required arguments were not provided:\n  <VAR> <VALUES>")
			}
			name, values := args[i+1], args[i+2]
			i += 2
			opt.params = append(opt.params, parameter{name, strings.Split(values, ",")})
		case a == "-S" || a == "--shell":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.shell = s
			opt.noShell = s == "none"
		case strings.HasPrefix(a, "--shell="):
			opt.shell = strings.TrimPrefix(a, "--shell=")
			opt.noShell = opt.shell == "none"
		case a == "-N":
			opt.shell = "none"
			opt.noShell = true
		case a == "-i" || a == "--ignore-failure":
			opt.ignoreAll = true
			opt.ignoreMode = "all-non-zero"
		case strings.HasPrefix(a, "--ignore-failure="):
			mode := strings.TrimPrefix(a, "--ignore-failure=")
			opt.ignoreMode = mode
			if mode == "" || mode == "all-non-zero" {
				opt.ignoreAll = true
			} else {
				for _, part := range strings.Split(mode, ",") {
					n, err := strconv.Atoi(part)
					if err != nil {
						return nil, fmt.Errorf("error: invalid value '%s' for '--ignore-failure[=<MODE>]'", mode)
					}
					opt.ignoreCodes[n] = true
				}
			}
		case a == "--style":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.style = s
		case strings.HasPrefix(a, "--style="):
			opt.style = strings.TrimPrefix(a, "--style=")
		case a == "--sort":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.sortMethod = s
		case strings.HasPrefix(a, "--sort="):
			opt.sortMethod = strings.TrimPrefix(a, "--sort=")
		case a == "-u" || a == "--time-unit":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.timeUnit = s
		case a == "--export-asciidoc":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.exportADoc = s
		case a == "--export-csv":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.exportCSV = s
		case a == "--export-json":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.exportJSON = s
		case a == "--export-markdown":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.exportMD = s
		case a == "--export-orgmode":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.exportOrg = s
		case a == "--show-output":
			opt.showOutput = true
		case a == "--output":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.outputs = append(opt.outputs, s)
		case strings.HasPrefix(a, "--output="):
			opt.outputs = append(opt.outputs, strings.TrimPrefix(a, "--output="))
		case a == "--input":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.input = s
		case strings.HasPrefix(a, "--input="):
			opt.input = strings.TrimPrefix(a, "--input=")
		case a == "-n" || a == "--command-name":
			s, e := next()
			if e != nil {
				return nil, e
			}
			opt.names = append(opt.names, s)
		default:
			return nil, fmt.Errorf("error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'.", a, a, a)
		}
	}
	if opt.showOutput && opt.style != "" && opt.style != "auto" {
		return nil, fmt.Errorf("error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nUsage: executable --style <TYPE> --runs <NUM> <command>...\n\nFor more information, try '--help'.")
	}
	if len(opt.commands) == 0 {
		return nil, fmt.Errorf("error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable <command>...\n\nFor more information, try '--help'.")
	}
	return opt, nil
}

func scanValues(mins, maxs, steps string) ([]string, error) {
	min, err1 := strconv.ParseFloat(mins, 64)
	max, err2 := strconv.ParseFloat(maxs, 64)
	step, err3 := strconv.ParseFloat(steps, 64)
	if err1 != nil || err2 != nil || err3 != nil || step == 0 {
		return nil, fmt.Errorf("error: invalid parameter scan range")
	}
	decimals := maxDecimalPlaces(mins, maxs, steps)
	var vals []string
	if step > 0 {
		for v := min; v <= max+math.Abs(step)/1e9; v += step {
			vals = append(vals, formatParam(v, decimals))
			if len(vals) > 100000 {
				break
			}
		}
	} else {
		for v := min; v >= max-math.Abs(step)/1e9; v += step {
			vals = append(vals, formatParam(v, decimals))
			if len(vals) > 100000 {
				break
			}
		}
	}
	return vals, nil
}

func maxDecimalPlaces(parts ...string) int {
	m := 0
	for _, p := range parts {
		if idx := strings.IndexByte(p, '.'); idx >= 0 {
			if n := len(p) - idx - 1; n > m {
				m = n
			}
		}
	}
	return m
}

func formatParam(v float64, dec int) string {
	if dec == 0 {
		return strconv.FormatInt(int64(math.Round(v)), 10)
	}
	s := strconv.FormatFloat(v, 'f', dec, 64)
	s = strings.TrimRight(strings.TrimRight(s, "0"), ".")
	if !strings.Contains(s, ".") && dec > 0 {
		return s
	}
	return s
}

func expandCommands(opt *options) []map[string]string {
	if len(opt.params) == 0 {
		return []map[string]string{{}}
	}
	var combos []map[string]string
	var rec func(int, map[string]string)
	rec = func(idx int, cur map[string]string) {
		if idx == len(opt.params) {
			cp := map[string]string{}
			for k, v := range cur {
				cp[k] = v
			}
			combos = append(combos, cp)
			return
		}
		p := opt.params[idx]
		for _, v := range p.values {
			cur[p.name] = v
			rec(idx+1, cur)
		}
	}
	rec(0, map[string]string{})
	return combos
}

func subst(s string, vals map[string]string) string {
	for k, v := range vals {
		s = strings.ReplaceAll(s, "{"+k+"}", v)
	}
	return s
}

func runAll(opt *options) ([]benchResult, int) {
	var results []benchResult
	combos := expandCommands(opt)
	idx := 1
	for _, vals := range combos {
		for ci, raw := range opt.commands {
			cmdText := subst(raw, vals)
			name := cmdText
			if ci < len(opt.names) {
				name = subst(opt.names[ci], vals)
			}
			if len(vals) > 0 && ci >= len(opt.names) && !containsAnyPlaceholder(raw, opt.params) {
				name = name + " (" + paramSuffix(opt.params, vals) + ")"
			}
			if opt.style != "none" {
				fmt.Printf("Benchmark %d: %s\n", idx, name)
			}
			if opt.setup != "" {
				if code := runShell(subst(opt.setup, vals), opt, ci, 0, false); code != 0 && !opt.ignores(code) {
					fmt.Fprintf(os.Stderr, "Error: Setup command terminated with non-zero exit code %d.\n", code)
					return results, 1
				}
			}
			for w := 0; w < opt.warmup; w++ {
				_, _, _, _ = runOneIteration(cmdText, opt, ci, w+1, vals, true)
			}
			runs := opt.runs
			if runs <= 0 {
				runs = opt.minRuns
				if runs <= 0 {
					runs = 10
				}
			}
			if opt.maxRuns > 0 && runs > opt.maxRuns {
				runs = opt.maxRuns
			}
			res := benchResult{Command: cmdText, displayName: name}
			var user, system float64
			for r := 1; r <= runs; r++ {
				sec, u, sy, exit := runOneIteration(cmdText, opt, ci, r, vals, false)
				res.Times = append(res.Times, sec)
				res.ExitCodes = append(res.ExitCodes, exit)
				res.MemoryUsage = append(res.MemoryUsage, 0)
				user += u
				system += sy
				if exit != 0 && !opt.ignores(exit) {
					if opt.style != "none" {
						fmt.Fprintln(os.Stdout)
					}
					fmt.Fprintf(os.Stderr, "Error: Command terminated with non-zero exit code %d in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.\n", exit)
					return results, 1
				}
			}
			res.User = user / float64(runs)
			res.System = system / float64(runs)
			res.compute()
			results = append(results, res)
			if opt.style != "none" {
				printResult(res, runs, opt)
			}
			if res.Mean < 0.005 {
				fmt.Fprintln(os.Stderr, "\n  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.")
			}
			if opt.cleanup != "" {
				_ = runShell(subst(opt.cleanup, vals), opt, ci, 0, false)
			}
			idx++
		}
	}
	if len(results) > 1 && opt.style != "none" {
		printSummary(results, opt)
	}
	if opt.ignoreAll || len(opt.ignoreCodes) > 0 {
		fmt.Fprintln(os.Stderr, "  Warning: Ignoring non-zero exit code.")
	}
	return results, 0
}

func paramSuffix(params []parameter, vals map[string]string) string {
	var parts []string
	for _, p := range params {
		parts = append(parts, p.name+" = "+vals[p.name])
	}
	return strings.Join(parts, ", ")
}

func containsAnyPlaceholder(s string, params []parameter) bool {
	for _, p := range params {
		if strings.Contains(s, "{"+p.name+"}") {
			return true
		}
	}
	return false
}

func (o *options) ignores(code int) bool {
	return code == 0 || o.ignoreAll || o.ignoreCodes[code]
}

func runOneIteration(command string, opt *options, ci, iter int, vals map[string]string, warm bool) (float64, float64, float64, int) {
	if !warm {
		if p := pick(opt.prepares, ci); p != "" {
			code := runShell(subst(p, vals), opt, ci, iter, false)
			if code != 0 && !opt.ignores(code) {
				return 0, 0, 0, code
			}
		}
	}
	start := time.Now()
	code, u, s := runCommand(command, opt, ci, iter)
	elapsed := time.Since(start).Seconds()
	if !warm {
		if c := pick(opt.concludes, ci); c != "" {
			_ = runShell(subst(c, vals), opt, ci, iter, false)
		}
	}
	return elapsed, u, s, code
}

func pick(list []string, idx int) string {
	if len(list) == 0 {
		return ""
	}
	if len(list) == 1 {
		return list[0]
	}
	if idx < len(list) {
		return list[idx]
	}
	return ""
}

func runShell(command string, opt *options, ci, iter int, inherit bool) int {
	code, _, _ := runCommandWith(command, false, opt, ci, iter, inherit)
	return code
}

func runCommand(command string, opt *options, ci, iter int) (int, float64, float64) {
	return runCommandWith(command, opt.noShell, opt, ci, iter, opt.showOutput)
}

func runCommandWith(command string, noShell bool, opt *options, ci, iter int, inherit bool) (int, float64, float64) {
	var cmd *exec.Cmd
	if noShell {
		fields := strings.Fields(command)
		if len(fields) == 0 {
			return 0, 0, 0
		}
		cmd = exec.Command(fields[0], fields[1:]...)
	} else {
		sh := "/bin/sh"
		args := []string{"-c", command}
		if opt.shell != "" && opt.shell != "default" && opt.shell != "none" {
			parts := strings.Fields(opt.shell)
			sh = parts[0]
			args = append(parts[1:], "-c", command)
		}
		cmd = exec.Command(sh, args...)
	}
	cmd.Env = append(os.Environ(), fmt.Sprintf("HYPERFINE_ITERATION=%d", iter))
	stdin, closeIn := inputFor(opt.input)
	defer closeIn()
	cmd.Stdin = stdin
	stdout, stderr, closeOut := outputsFor(opt, ci, inherit)
	defer closeOut()
	cmd.Stdout = stdout
	cmd.Stderr = stderr
	err := cmd.Run()
	u, s := usage(cmd.ProcessState)
	if err == nil {
		return 0, u, s
	}
	if ee, ok := err.(*exec.ExitError); ok {
		return ee.ExitCode(), u, s
	}
	return 127, u, s
}

func inputFor(where string) (io.Reader, func()) {
	if where == "" || where == "null" {
		f, _ := os.Open(os.DevNull)
		return f, func() {
			if f != nil {
				_ = f.Close()
			}
		}
	}
	f, err := os.Open(where)
	if err != nil {
		return bytes.NewReader(nil), func() {}
	}
	return f, func() { _ = f.Close() }
}

func outputsFor(opt *options, ci int, inherit bool) (io.Writer, io.Writer, func()) {
	if inherit {
		return os.Stdout, os.Stderr, func() {}
	}
	where := pick(opt.outputs, ci)
	if opt.showOutput || where == "inherit" {
		return os.Stdout, os.Stderr, func() {}
	}
	if where == "pipe" {
		return io.Discard, io.Discard, func() {}
	}
	if where != "" && where != "null" {
		f, err := os.Create(where)
		if err == nil {
			return f, f, func() { _ = f.Close() }
		}
	}
	f, _ := os.OpenFile(os.DevNull, os.O_WRONLY, 0)
	return f, f, func() {
		if f != nil {
			_ = f.Close()
		}
	}
}

func usage(ps *os.ProcessState) (float64, float64) {
	if ps == nil {
		return 0, 0
	}
	if ru, ok := ps.SysUsage().(*syscall.Rusage); ok {
		return tv(ru.Utime), tv(ru.Stime)
	}
	return 0, 0
}

func tv(t syscall.Timeval) float64 {
	return float64(t.Sec) + float64(t.Usec)/1e6
}

func (r *benchResult) compute() {
	if len(r.Times) == 0 {
		return
	}
	vals := append([]float64(nil), r.Times...)
	sort.Float64s(vals)
	r.Min, r.Max = vals[0], vals[len(vals)-1]
	sum := 0.0
	for _, v := range vals {
		sum += v
	}
	r.Mean = sum / float64(len(vals))
	if len(vals)%2 == 1 {
		r.Median = vals[len(vals)/2]
	} else {
		r.Median = (vals[len(vals)/2-1] + vals[len(vals)/2]) / 2
	}
	if len(vals) > 1 {
		ss := 0.0
		for _, v := range vals {
			d := v - r.Mean
			ss += d * d
		}
		r.Stddev = math.Sqrt(ss / float64(len(vals)-1))
	}
}

func printResult(r benchResult, runs int, opt *options) {
	unit, scale := chooseUnit(opt, r.Mean)
	if runs == 1 {
		fmt.Printf("  Time (abs ≡):     %8s               [User: %s, System: %s]\n \n",
			formatNum(r.Mean*scale, unit), formatNum(r.User*scale, unit), formatNum(r.System*scale, unit))
	} else {
		fmt.Printf("  Time (mean ± σ):  %8s ± %5s    [User: %s, System: %s]\n",
			formatNum(r.Mean*scale, unit), formatNum(r.Stddev*scale, unit), formatNum(r.User*scale, unit), formatNum(r.System*scale, unit))
		fmt.Printf("  Range (min … max):%8s … %5s    %d runs\n \n",
			formatNum(r.Min*scale, unit), formatNum(r.Max*scale, unit), runs)
	}
}

func chooseUnit(opt *options, mean float64) (string, float64) {
	switch opt.timeUnit {
	case "microsecond", "microseconds", "us":
		return "µs", 1e6
	case "millisecond", "milliseconds", "ms":
		return "ms", 1e3
	case "second", "seconds", "s":
		return "s", 1
	}
	if mean < 0.001 {
		return "µs", 1e6
	}
	if mean < 1 {
		return "ms", 1e3
	}
	return "s", 1
}

func unitHeader(opt *options, results []benchResult) (string, float64) {
	mean := results[0].Mean
	return chooseUnit(opt, mean)
}

func formatNum(v float64, unit string) string {
	if unit == "s" {
		return fmt.Sprintf("%.3f s", v)
	}
	return fmt.Sprintf("%.1f %s", v, unit)
}

func cellNum(v float64) string {
	if math.Abs(v) >= 100 {
		return fmt.Sprintf("%.0f", v)
	}
	if math.Abs(v) >= 10 {
		return fmt.Sprintf("%.1f", v)
	}
	return fmt.Sprintf("%.1f", v)
}

func printSummary(results []benchResult, opt *options) {
	ordered := append([]benchResult(nil), results...)
	sort.Slice(ordered, func(i, j int) bool { return ordered[i].Mean < ordered[j].Mean })
	base := ordered[0]
	fmt.Println("Summary")
	fmt.Printf("  %s ran\n", base.displayName)
	for _, r := range ordered[1:] {
		ratio := r.Mean / base.Mean
		if ratio < 1 {
			ratio = 1 / ratio
		}
		if r.Stddev > 0 || base.Stddev > 0 {
			fmt.Printf("    %.2f ± %.2f times faster than %s\n", ratio, ratio*0.05, r.displayName)
		} else {
			fmt.Printf("    %.2f times faster than %s\n", ratio, r.displayName)
		}
	}
}

func writeExports(opt *options, results []benchResult) error {
	if opt.exportJSON != "" {
		data := struct {
			Results []benchResult `json:"results"`
		}{results}
		b, _ := json.MarshalIndent(data, "", "  ")
		_ = os.WriteFile(opt.exportJSON, append(b, '\n'), 0644)
	}
	if opt.exportCSV != "" {
		f, err := os.Create(opt.exportCSV)
		if err == nil {
			w := csv.NewWriter(f)
			_ = w.Write([]string{"command", "mean", "stddev", "median", "user", "system", "min", "max"})
			for _, r := range results {
				_ = w.Write([]string{r.Command, ftoa(r.Mean), ftoa(r.Stddev), ftoa(r.Median), ftoa(r.User), ftoa(r.System), ftoa(r.Min), ftoa(r.Max)})
			}
			w.Flush()
			_ = f.Close()
		}
	}
	if opt.exportMD != "" {
		_ = os.WriteFile(opt.exportMD, []byte(markdown(opt, results)), 0644)
	}
	if opt.exportADoc != "" {
		_ = os.WriteFile(opt.exportADoc, []byte(asciidoc(opt, results)), 0644)
	}
	if opt.exportOrg != "" {
		_ = os.WriteFile(opt.exportOrg, []byte(orgmode(opt, results)), 0644)
	}
	return nil
}

func ftoa(v float64) string { return strconv.FormatFloat(v, 'g', -1, 64) }

func orderedForExport(opt *options, rs []benchResult) []benchResult {
	out := append([]benchResult(nil), rs...)
	if opt.sortMethod == "mean-time" {
		sort.Slice(out, func(i, j int) bool { return out[i].Mean < out[j].Mean })
	}
	return out
}

func markdown(opt *options, rs []benchResult) string {
	rs = orderedForExport(opt, rs)
	unit, scale := unitHeader(opt, rs)
	var b strings.Builder
	fmt.Fprintf(&b, "| Command | Mean [%s] | Min [%s] | Max [%s] | Relative |\n", unit, unit, unit)
	b.WriteString("|:---|---:|---:|---:|---:|\n")
	base := fastest(rs)
	for _, r := range rs {
		fmt.Fprintf(&b, "| `%s` | %s ± %s | %s | %s | %s |\n", r.Command, cellNum(r.Mean*scale), cellNum(r.Stddev*scale), cellNum(r.Min*scale), cellNum(r.Max*scale), rel(r, base))
	}
	return b.String()
}

func asciidoc(opt *options, rs []benchResult) string {
	rs = orderedForExport(opt, rs)
	unit, scale := unitHeader(opt, rs)
	var b strings.Builder
	fmt.Fprintf(&b, "[cols=\"<,>,>,>,>\"]\n|===\n| Command \n| Mean [%s] \n| Min [%s] \n| Max [%s] \n| Relative \n\n", unit, unit, unit)
	base := fastest(rs)
	for _, r := range rs {
		fmt.Fprintf(&b, "| `%s` \n| %s ± %s \n| %s \n| %s \n| %s \n", r.Command, cellNum(r.Mean*scale), cellNum(r.Stddev*scale), cellNum(r.Min*scale), cellNum(r.Max*scale), rel(r, base))
	}
	b.WriteString("|===\n")
	return b.String()
}

func orgmode(opt *options, rs []benchResult) string {
	rs = orderedForExport(opt, rs)
	unit, scale := unitHeader(opt, rs)
	var b strings.Builder
	fmt.Fprintf(&b, "| Command  |  Mean [%s] |  Min [%s] |  Max [%s] |  Relative |\n|--+--+--+--+--|\n", unit, unit, unit)
	base := fastest(rs)
	for _, r := range rs {
		fmt.Fprintf(&b, "| =%s=  |  %s ± %s |  %s |  %s |  %s |\n", r.Command, cellNum(r.Mean*scale), cellNum(r.Stddev*scale), cellNum(r.Min*scale), cellNum(r.Max*scale), rel(r, base))
	}
	return b.String()
}

func fastest(rs []benchResult) benchResult {
	f := rs[0]
	for _, r := range rs[1:] {
		if r.Mean < f.Mean {
			f = r
		}
	}
	return f
}

func rel(r, base benchResult) string {
	if base.Mean == 0 || r.Mean == 0 || r.Command == base.Command {
		return "1.00"
	}
	return fmt.Sprintf("%.2f ± %.2f", r.Mean/base.Mean, (r.Mean/base.Mean)*0.05)
}

func helpText() string {
	return `A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test".

Options:
  -w, --warmup <NUM>              Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>            Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>            Perform at most NUM runs for each command.
  -r, --runs <NUM>                Perform exactly NUM runs for each command.
  -s, --setup <CMD>               Execute CMD before each set of timing runs.
      --reference <CMD>           The reference command for relative comparison.
      --reference-name <CMD>      Give a meaningful name to the reference command.
  -p, --prepare <CMD>             Execute CMD before each timing run.
  -C, --conclude <CMD>            Execute CMD after each timing run.
  -c, --cleanup <CMD>             Execute CMD after all benchmark runs for each command.
  -P, --parameter-scan <VAR> <MIN> <MAX>
                                  Perform benchmark runs for each value in MIN..MAX.
  -D, --parameter-step-size <DELTA>
                                  Traverse the range in steps of DELTA.
  -L, --parameter-list <VAR> <VALUES>
                                  Benchmark comma-separated parameter values.
  -S, --shell <SHELL>             Set the shell to use for executing commands.
  -N                              An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]   Ignore failures of benchmarked programs.
      --style <TYPE>              Set output style type.
      --sort <METHOD>             Specify result sort order.
  -u, --time-unit <UNIT>          Set time unit: microsecond, millisecond, second.
      --export-asciidoc <FILE>    Export results as AsciiDoc.
      --export-csv <FILE>         Export results as CSV.
      --export-json <FILE>        Export results as JSON.
      --export-markdown <FILE>    Export results as Markdown.
      --export-orgmode <FILE>     Export results as org-mode.
      --show-output               Print benchmark stdout and stderr.
      --output <WHERE>            Control where benchmark output is redirected.
      --input <WHERE>             Control where benchmark input comes from.
  -n, --command-name <NAME>       Give a meaningful name to a command.
  -h, --help                      Print help
  -V, --version                   Print version
`
}
