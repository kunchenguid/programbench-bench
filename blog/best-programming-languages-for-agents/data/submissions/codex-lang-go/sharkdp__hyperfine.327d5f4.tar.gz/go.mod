module hyperfineclone

go 1.21
