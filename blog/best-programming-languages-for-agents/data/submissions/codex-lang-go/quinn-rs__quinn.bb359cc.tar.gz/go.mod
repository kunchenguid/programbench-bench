module programbench/quinnperf

go 1.21
