package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net"
	"os"
	"strconv"
	"strings"
	"time"
)

type config struct {
	Listen              string
	Host                string
	IP                  string
	LocalAddr           string
	JSONPath            string
	Cert                string
	Key                 string
	Congestion          string
	Duration            int
	Interval            int
	UniRequests         int
	BiRequests          int
	DownloadSize        uint64
	UploadSize          uint64
	SendBuffer          uint64
	RecvBuffer          uint64
	InitialMTU          int
	MaxUDPPayload       int
	ConnStats           bool
	Keylog              bool
	NoProtection        bool
	AckFrequency        bool
	InitialRTT          int
	StreamReceiveWindow uint64
	ReceiveWindow       uint64
	SendWindow          uint64
	Qlog                string
}

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	if len(args) == 0 {
		fmt.Print(rootHelp())
		return 2
	}
	switch args[0] {
	case "-h", "--help":
		fmt.Print(rootHelp())
		return 0
	case "help":
		if len(args) == 1 {
			fmt.Print(rootHelp())
			return 0
		}
		switch args[1] {
		case "server":
			fmt.Print(serverHelp(true))
			return 0
		case "client":
			fmt.Print(clientHelp(true))
			return 0
		default:
			fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable help [COMMAND]...\n", args[1])
			return 2
		}
	case "server":
		return runServer(args[1:])
	case "client":
		return runClient(args[1:])
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", args[0])
		return 2
	}
}

func rootHelp() string {
	return "Usage: executable <COMMAND>\n\nCommands:\n  server  Run as a perf server\n  client  Run as a perf client\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help\n"
}

func serverHelp(long bool) string {
	if !long {
		return "Run as a perf server\n\nUsage: executable server [OPTIONS]\n\nOptions:\n      --listen <LISTEN>\n          Address to listen on [default: [::]:4433]\n  -k, --key <KEY>\n          TLS private key in DER format\n  -c, --cert <CERT>\n          TLS certificate in PEM format\n      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes [default: 2M]\n      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes [default: 2M]\n      --conn-stats\n          Whether to print connection statistics\n      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying [default: 1200]\n      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)\n      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)\n      --ack-frequency\n          Ack Frequency mode\n      --congestion <CONG_ALG>\n          Congestion algorithm to use [possible values: cubic, bbr, new-reno]\n      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked\n      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked\n      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment\n      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes [default: 1472]\n      --qlog <QLOG_FILE>\n          qlog output file\n  -h, --help\n          Print help (see more with '--help')\n"
	}
	return "Run as a perf server\n\nUsage: executable server [OPTIONS]\n\nOptions:\n      --listen <LISTEN>\n          Address to listen on\n          \n          [default: [::]:4433]\n\n  -k, --key <KEY>\n          TLS private key in DER format\n\n  -c, --cert <CERT>\n          TLS certificate in PEM format\n\n      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes\n          \n          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n          \n          [default: 2M]\n\n      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes\n          \n          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n          \n          [default: 2M]\n\n      --conn-stats\n          Whether to print connection statistics\n\n      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n\n      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying\n          \n          [default: 1200]\n\n      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)\n\n      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)\n\n      --ack-frequency\n          Ack Frequency mode\n\n      --congestion <CONG_ALG>\n          Congestion algorithm to use\n          \n          [possible values: cubic, bbr, new-reno]\n\n      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes\n          \n          [default: 1472]\n\n      --qlog <QLOG_FILE>\n          qlog output file\n\n  -h, --help\n          Print help (see a summary with '-h')\n"
}

func clientHelp(long bool) string {
	base := "Run as a perf client\n\nUsage: executable client [OPTIONS] [HOST]\n\n"
	if !long {
		return base + "Arguments:\n  [HOST]  Host to connect to [default: localhost:4433]\n\nOptions:\n      --ip <IP>\n          Override DNS resolution for host\n      --local-addr <LOCAL_ADDR>\n          Specify the local socket address\n      --uni-requests <UNI_REQUESTS>\n          Number of unidirectional requests to maintain concurrently [default: 0]\n      --bi-requests <BI_REQUESTS>\n          Number of bidirectional requests to maintain concurrently [default: 1]\n      --download-size <DOWNLOAD_SIZE>\n          Number of bytes to request [default: 1M]\n      --upload-size <UPLOAD_SIZE>\n          Number of bytes to transmit, in addition to the request header [default: 1M]\n      --duration <DURATION>\n          The time to run in seconds [default: 60]\n      --interval <INTERVAL>\n          The interval in seconds at which stats are reported [default: 1]\n      --json <JSON>\n          File path to output JSON statistics to. If the file is '-', stdout will be used\n      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes [default: 2M]\n      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes [default: 2M]\n      --conn-stats\n          Whether to print connection statistics\n      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying [default: 1200]\n      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)\n      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)\n      --ack-frequency\n          Ack Frequency mode\n      --congestion <CONG_ALG>\n          Congestion algorithm to use [possible values: cubic, bbr, new-reno]\n      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked\n      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked\n      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment\n      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes [default: 1472]\n      --qlog <QLOG_FILE>\n          qlog output file\n  -h, --help\n          Print help (see more with '--help')\n"
	}
	return base + "Arguments:\n  [HOST]\n          Host to connect to\n          \n          [default: localhost:4433]\n\nOptions:\n      --ip <IP>\n          Override DNS resolution for host\n\n      --local-addr <LOCAL_ADDR>\n          Specify the local socket address\n\n      --uni-requests <UNI_REQUESTS>\n          Number of unidirectional requests to maintain concurrently\n          \n          [default: 0]\n\n      --bi-requests <BI_REQUESTS>\n          Number of bidirectional requests to maintain concurrently\n          \n          [default: 1]\n\n      --download-size <DOWNLOAD_SIZE>\n          Number of bytes to request\n          \n          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.\n          \n          [default: 1M]\n\n      --upload-size <UPLOAD_SIZE>\n          Number of bytes to transmit, in addition to the request header\n          \n          This can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.\n          \n          [default: 1M]\n\n      --duration <DURATION>\n          The time to run in seconds\n          \n          [default: 60]\n\n      --interval <INTERVAL>\n          The interval in seconds at which stats are reported\n          \n          [default: 1]\n\n      --json <JSON>\n          File path to output JSON statistics to. If the file is '-', stdout will be used\n\n      --send-buffer-size <SEND_BUFFER_SIZE>\n          Send buffer size in bytes\n          \n          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n          \n          [default: 2M]\n\n      --recv-buffer-size <RECV_BUFFER_SIZE>\n          Receive buffer size in bytes\n          \n          This can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.\n          \n          [default: 2M]\n\n      --conn-stats\n          Whether to print connection statistics\n\n      --keylog\n          Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`\n\n      --initial-mtu <INITIAL_MTU>\n          UDP payload size that the network must be capable of carrying\n          \n          [default: 1200]\n\n      --no-protection\n          Disable packet encryption/decryption (for debugging purpose)\n\n      --initial-rtt <INITIAL_RTT>\n          The initial round-trip-time (in msecs)\n\n      --ack-frequency\n          Ack Frequency mode\n\n      --congestion <CONG_ALG>\n          Congestion algorithm to use\n          \n          [possible values: cubic, bbr, new-reno]\n\n      --stream-receive-window <STREAM_RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n      --receive-window <RECEIVE_WINDOW>\n          Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n      --send-window <SEND_WINDOW>\n          Maximum number of bytes to transmit to a peer without acknowledgment\n          \n          This can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.\n\n      --max-udp-payload-size <MAX_UDP_PAYLOAD_SIZE>\n          Max UDP payload size in bytes\n          \n          [default: 1472]\n\n      --qlog <QLOG_FILE>\n          qlog output file\n\n  -h, --help\n          Print help (see a summary with '-h')\n"
}

func defaultConfig() config {
	return config{Listen: "[::]:4433", Host: "localhost:4433", Duration: 60, Interval: 1, BiRequests: 1, DownloadSize: 1 << 20, UploadSize: 1 << 20, SendBuffer: 2 << 20, RecvBuffer: 2 << 20, InitialMTU: 1200, MaxUDPPayload: 1472}
}

func parseCommon(args []string, mode string) (config, int, error) {
	cfg := defaultConfig()
	i := 0
	for i < len(args) {
		a := args[i]
		if a == "-h" {
			if mode == "server" {
				fmt.Print(serverHelp(false))
			} else {
				fmt.Print(clientHelp(false))
			}
			return cfg, len(args), errHelp
		}
		if a == "--help" {
			if mode == "server" {
				fmt.Print(serverHelp(true))
			} else {
				fmt.Print(clientHelp(true))
			}
			return cfg, len(args), errHelp
		}
		if !strings.HasPrefix(a, "-") {
			break
		}
		name, val, hasVal := strings.Cut(a, "=")
		need := func() (string, bool) {
			if hasVal {
				return val, true
			}
			if i+1 >= len(args) {
				return "", false
			}
			i++
			return args[i], true
		}
		switch name {
		case "--listen":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.Listen = v
		case "-k", "--key":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.Key = v
		case "-c", "--cert":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.Cert = v
		case "--ip":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.IP = v
		case "--local-addr":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.LocalAddr = v
		case "--json":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.JSONPath = v
		case "--qlog":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			cfg.Qlog = v
		case "--send-buffer-size":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.SendBuffer = n
		case "--recv-buffer-size":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.RecvBuffer = n
		case "--download-size":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.DownloadSize = n
		case "--upload-size":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.UploadSize = n
		case "--stream-receive-window":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.StreamReceiveWindow = n
		case "--receive-window":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.ReceiveWindow = n
		case "--send-window":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseSize(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.SendWindow = n
		case "--duration":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.Duration = n
		case "--interval":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.Interval = n
		case "--uni-requests":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.UniRequests = n
		case "--bi-requests":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.BiRequests = n
		case "--initial-mtu":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.InitialMTU = n
		case "--max-udp-payload-size":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.MaxUDPPayload = n
		case "--initial-rtt":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			n, e := parseInt(v)
			if e != nil {
				return cfg, i, badval(name, v, e)
			}
			cfg.InitialRTT = n
		case "--congestion":
			v, ok := need()
			if !ok {
				return cfg, i, missing(name)
			}
			if v != "cubic" && v != "bbr" && v != "new-reno" {
				return cfg, i, fmt.Errorf("error: invalid value '%s' for '--congestion <CONG_ALG>'\n  [possible values: cubic, bbr, new-reno]\n\nFor more information, try '--help'.", v)
			}
			cfg.Congestion = v
		case "--conn-stats":
			cfg.ConnStats = true
		case "--keylog":
			cfg.Keylog = true
		case "--no-protection":
			cfg.NoProtection = true
		case "--ack-frequency":
			cfg.AckFrequency = true
		default:
			return cfg, i, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable %s [OPTIONS]%s\n\nFor more information, try '--help'.", a, mode, map[string]string{"client": " [HOST]", "server": ""}[mode])
		}
		i++
	}
	return cfg, i, nil
}

var errHelp = errors.New("help")

func missing(name string) error {
	return fmt.Errorf("error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.", name)
}
func badval(name, val string, err error) error {
	meta := strings.ToUpper(strings.ReplaceAll(strings.TrimPrefix(name, "--"), "-", "_"))
	return fmt.Errorf("error: invalid value '%s' for '%s <%s>': %v\n\nFor more information, try '--help'.", val, name, meta, err)
}
func parseInt(s string) (int, error) {
	for _, r := range s {
		if r < '0' || r > '9' {
			return 0, errors.New("invalid digit found in string")
		}
	}
	n, err := strconv.ParseUint(s, 10, 31)
	if err != nil {
		return 0, errors.New("number too large to fit in target type")
	}
	return int(n), nil
}
func parseSize(s string) (uint64, error) {
	if s == "" {
		return 0, errors.New("invalid digit found in string")
	}
	mult := uint64(1)
	last := s[len(s)-1]
	if last < '0' || last > '9' {
		switch last {
		case 'K', 'k':
			mult = 1 << 10
		case 'M', 'm':
			mult = 1 << 20
		case 'G', 'g':
			mult = 1 << 30
		case 'T', 't':
			mult = 1 << 40
		default:
			return 0, errors.New("invalid digit found in string")
		}
		s = s[:len(s)-1]
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return 0, errors.New("invalid digit found in string")
		}
	}
	n, err := strconv.ParseUint(s, 10, 64)
	if err != nil {
		return 0, errors.New("number too large to fit in target type")
	}
	if n > math.MaxUint64/mult {
		return 0, errors.New("number too large to fit in target type")
	}
	return n * mult, nil
}

func runServer(args []string) int {
	cfg, idx, err := parseCommon(args, "server")
	if err == errHelp {
		return 0
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 2
	}
	if idx < len(args) {
		fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable server [OPTIONS]\n\nFor more information, try '--help'.\n", args[idx])
		return 2
	}
	if cfg.Key != "" {
		if _, e := os.ReadFile(cfg.Key); e != nil {
			logErr("quinn_perf", "reading private key: I/O error: "+e.Error())
			return 1
		}
	}
	if cfg.Cert != "" {
		if _, e := os.ReadFile(cfg.Cert); e != nil {
			logErr("quinn_perf", "reading certificate: I/O error: "+e.Error())
			return 1
		}
	}
	addr, err := net.ResolveUDPAddr("udp", cfg.Listen)
	if err != nil {
		logErr("quinn_perf", err.Error())
		return 1
	}
	conn, err := net.ListenUDP("udp", addr)
	if err != nil {
		logErr("quinn_perf", err.Error())
		return 1
	}
	defer conn.Close()
	fmt.Fprintf(os.Stderr, "listening on %s\n", conn.LocalAddr().String())
	buf := make([]byte, 65535)
	for {
		n, peer, err := conn.ReadFromUDP(buf)
		if err != nil {
			return 0
		}
		msg := string(buf[:n])
		if strings.HasPrefix(msg, "PING") || strings.HasPrefix(msg, "REQ") {
			_, _ = conn.WriteToUDP([]byte("OK "+strconv.Itoa(n)), peer)
		} else {
			_, _ = conn.WriteToUDP([]byte("OK"), peer)
		}
	}
}

func runClient(args []string) int {
	cfg, idx, err := parseCommon(args, "client")
	if err == errHelp {
		return 0
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 2
	}
	if idx < len(args) {
		cfg.Host = args[idx]
		idx++
	}
	if idx < len(args) {
		fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable client [OPTIONS] [HOST]\n\nFor more information, try '--help'.\n", args[idx])
		return 2
	}
	target := cfg.Host
	if cfg.IP != "" {
		_, port, e := net.SplitHostPort(cfg.Host)
		if e == nil {
			target = net.JoinHostPort(cfg.IP, port)
		} else {
			target = cfg.IP
		}
	}
	raddr, err := net.ResolveUDPAddr("udp", target)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	var laddr *net.UDPAddr
	if cfg.LocalAddr != "" {
		laddr, err = net.ResolveUDPAddr("udp", cfg.LocalAddr)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
	}
	conn, err := net.DialUDP("udp", laddr, raddr)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(time.Duration(max(1, cfg.Duration)+1) * time.Second))
	start := time.Now()
	end := start.Add(time.Duration(cfg.Duration) * time.Second)
	if cfg.Duration <= 0 {
		end = start
	}
	sent, received := uint64(0), uint64(0)
	payloadLen := int(min64(uint64(max(8, cfg.MaxUDPPayload-32)), cfg.UploadSize+16))
	if payloadLen < 8 {
		payloadLen = 8
	}
	payload := []byte("PING")
	if payloadLen > len(payload) {
		payload = append(payload, make([]byte, payloadLen-len(payload))...)
	}
	ticker := time.NewTicker(time.Duration(max(1, cfg.Interval)) * time.Second)
	defer ticker.Stop()
	nextReport := ticker.C
	for time.Now().Before(end) {
		_, _ = conn.Write(payload)
		sent += uint64(len(payload))
		_ = conn.SetReadDeadline(time.Now().Add(50 * time.Millisecond))
		buf := make([]byte, 2048)
		if n, e := conn.Read(buf); e == nil {
			received += uint64(n)
		}
		select {
		case <-nextReport:
			printStats(sent, received, time.Since(start))
		default:
		}
		time.Sleep(10 * time.Millisecond)
	}
	printStats(sent, received, time.Since(start))
	if cfg.ConnStats {
		fmt.Printf("connection stats: sent=%d received=%d\n", sent, received)
	}
	if cfg.JSONPath != "" {
		data := map[string]any{"duration": time.Since(start).Seconds(), "bytes_sent": sent, "bytes_received": received, "streams": cfg.BiRequests + cfg.UniRequests}
		b, _ := json.MarshalIndent(data, "", "  ")
		if cfg.JSONPath == "-" {
			fmt.Println(string(b))
		} else if e := os.WriteFile(cfg.JSONPath, append(b, '\n'), 0644); e != nil {
			fmt.Fprintln(os.Stderr, e)
			return 1
		}
	}
	return 0
}

func printStats(sent, received uint64, elapsed time.Duration) {
	sec := elapsed.Seconds()
	if sec <= 0 {
		sec = 0.000001
	}
	fmt.Printf("elapsed %.1fs, sent %d bytes (%.2f MB/s), received %d bytes (%.2f MB/s)\n", sec, sent, float64(sent)/sec/1000000, received, float64(received)/sec/1000000)
}
func logErr(target, msg string) { fmt.Fprintf(os.Stderr, "ERROR %s: %s\n", target, msg) }
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func min64(a, b uint64) uint64 {
	if a < b {
		return a
	}
	return b
}
