module pb-mdbook

go 1.21
