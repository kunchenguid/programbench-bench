package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"html"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "mdbook v0.5.0-alpha.1"

type Chapter struct {
	Title string
	Path  string
	Level int
}

type Config struct {
	Title       string
	Authors     string
	Language    string
	Src         string
	BuildDir    string
	Description string
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		if err.Error() != "" {
			fmt.Fprintln(os.Stderr, err)
		}
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 {
		fmt.Print(topHelp())
		return nil
	}
	switch args[0] {
	case "-h", "--help", "help":
		if len(args) > 1 && args[0] == "help" {
			return run(append([]string{args[1], "--help"}, args[2:]...))
		}
		fmt.Print(topHelp())
	case "-V", "--version", "version":
		fmt.Println(version)
	case "init":
		return cmdInit(args[1:])
	case "build":
		return cmdBuild(args[1:], false)
	case "clean":
		return cmdClean(args[1:])
	case "test":
		return cmdTest(args[1:])
	case "completions":
		return cmdCompletions(args[1:])
	case "watch":
		return cmdWatch(args[1:])
	case "serve":
		return cmdServe(args[1:])
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[0])
		fmt.Print(topHelp())
		return errors.New("")
	}
	return nil
}

func topHelp() string {
	return `Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try ` + "`mdbook <command> --help`" + `
The source code for mdBook is available at: https://github.com/rust-lang/mdBook
`
}

func help(name string) string {
	switch name {
	case "init":
		return `Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version
`
	case "build":
		return `Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             ` + "`./book`" + `
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version
`
	case "clean":
		return `Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             ` + "`./book`" + `
  -h, --help                 Print help
  -V, --version              Print version
`
	case "test":
		return `Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             ` + "`./book`" + `
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version
`
	case "completions":
		return `Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version
`
	case "watch":
		return `Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             ` + "`./book`" + `
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
`
	case "serve":
		return `Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             ` + "`./book`" + `
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
`
	}
	return topHelp()
}

func cmdInit(args []string) error {
	dir := "."
	title := ""
	ignore := ""
	force := false
	theme := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			fmt.Print(help("init"))
			return nil
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return nil
		}
		switch {
		case a == "--force":
			force = true
		case a == "--theme":
			theme = true
		case a == "--title" && i+1 < len(args):
			i++
			title = args[i]
		case strings.HasPrefix(a, "--title="):
			title = strings.TrimPrefix(a, "--title=")
		case a == "--ignore" && i+1 < len(args):
			i++
			ignore = args[i]
		case strings.HasPrefix(a, "--ignore="):
			ignore = strings.TrimPrefix(a, "--ignore=")
		case strings.HasPrefix(a, "-"):
			return fmt.Errorf("error: unexpected argument '%s'", a)
		default:
			dir = a
		}
	}
	if title == "" && !force {
		fmt.Print("Do you want a title? (leave blank for none): ")
		r := bufio.NewReader(os.Stdin)
		line, _ := r.ReadString('\n')
		title = strings.TrimSpace(line)
	}
	if title == "" {
		base, _ := filepath.Abs(dir)
		title = filepath.Base(base)
		if title == "." || title == string(filepath.Separator) || title == "" {
			title = "My Book"
		}
	}
	if ignore == "" {
		if force {
			ignore = "none"
		} else {
			ignore = "git"
		}
	}
	src := filepath.Join(dir, "src")
	if err := os.MkdirAll(src, 0755); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "%s [INFO] (mdbook_driver::init): Creating a new book with stub content\n", stamp())
	sum := filepath.Join(src, "SUMMARY.md")
	if _, err := os.Stat(sum); os.IsNotExist(err) {
		writeFile(sum, "# Summary\n\n- [Chapter 1](./chapter_1.md)\n")
		writeFile(filepath.Join(src, "chapter_1.md"), "# Chapter 1\n")
	} else {
		chapters, _ := parseSummary(sum)
		for _, c := range chapters {
			if c.Path != "" {
				p := filepath.Join(src, filepath.Clean(c.Path))
				if _, err := os.Stat(p); os.IsNotExist(err) {
					os.MkdirAll(filepath.Dir(p), 0755)
					writeFile(p, "# "+c.Title+"\n")
				}
			}
		}
	}
	writeFile(filepath.Join(dir, "book.toml"), fmt.Sprintf("[book]\nauthors = []\nlanguage = \"en\"\nsrc = \"src\"\ntitle = %q\n", title))
	if ignore == "git" {
		writeFile(filepath.Join(dir, ".gitignore"), "book\n")
	}
	if theme {
		createTheme(filepath.Join(src, "theme"))
	}
	fmt.Println("\nAll done, no errors...")
	return nil
}

func cmdBuild(args []string, quiet bool) error {
	dir, dest, open := parseBuildArgs("build", args)
	if dir == "__help" {
		return nil
	}
	cfg := readConfig(dir)
	if dest == "" {
		dest = cfg.BuildDir
	}
	if dest == "" {
		dest = "book"
	}
	if !filepath.IsAbs(dest) {
		dest = filepath.Join(dir, dest)
	}
	src := filepath.Join(dir, cfg.Src)
	sum := filepath.Join(src, "SUMMARY.md")
	chapters, err := parseSummary(sum)
	if err != nil {
		fmt.Fprintf(os.Stderr, "%s [ERROR] (mdbook_core::utils): Error: Couldn't open SUMMARY.md in %q directory\n", stamp(), filepath.Clean(src))
		fmt.Fprintf(os.Stderr, "%s [ERROR] (mdbook_core::utils): \tCaused By: %v\n", stamp(), err)
		os.Exit(101)
	}
	if !quiet {
		fmt.Fprintf(os.Stderr, "%s [INFO] (mdbook_driver::mdbook): Book building has started\n", stamp())
	}
	for _, c := range chapters {
		if c.Path == "" {
			continue
		}
		p := filepath.Join(src, filepath.Clean(c.Path))
		if _, err := os.Stat(p); os.IsNotExist(err) {
			os.MkdirAll(filepath.Dir(p), 0755)
			writeFile(p, "# "+c.Title+"\n")
		}
	}
	os.RemoveAll(dest)
	os.MkdirAll(dest, 0755)
	copyAssets(src, dest)
	writeStatic(dest)
	nav := renderNav(chapters)
	first := ""
	for _, c := range chapters {
		if c.Path == "" {
			continue
		}
		in := filepath.Join(src, filepath.Clean(c.Path))
		outRel := htmlPath(c.Path)
		if first == "" {
			first = outRel
		}
		bodyBytes, _ := os.ReadFile(in)
		body := processIncludes(string(bodyBytes), filepath.Dir(in))
		content := markdownToHTML(body)
		out := filepath.Join(dest, outRel)
		os.MkdirAll(filepath.Dir(out), 0755)
		writeFile(out, pageHTML(cfg, c.Title, nav, content, relRoot(outRel)))
	}
	if first != "" {
		data, _ := os.ReadFile(filepath.Join(dest, first))
		writeFile(filepath.Join(dest, "index.html"), string(data))
	} else {
		writeFile(filepath.Join(dest, "index.html"), pageHTML(cfg, cfg.Title, nav, "", ""))
	}
	writeFile(filepath.Join(dest, "toc.html"), nav)
	writeFile(filepath.Join(dest, "print.html"), printHTML(cfg, chapters, src))
	writeFile(filepath.Join(dest, "searchindex.js"), "Object.assign(window, { search: { doc_urls: [], index: {} } });\n")
	writeFile(filepath.Join(dest, ".nojekyll"), "")
	writeFile(filepath.Join(dest, "404.html"), pageHTML(cfg, "404", nav, "<h1>404</h1><p>Page not found.</p>", ""))
	if !quiet {
		fmt.Fprintf(os.Stderr, "%s [INFO] (mdbook_driver::mdbook): Running the html backend\n", stamp())
		abs, _ := filepath.Abs(dest)
		fmt.Fprintf(os.Stderr, "%s [INFO] (mdbook_html::html_handlebars::hbs_renderer): HTML book written to `%s`\n", stamp(), abs)
	}
	if open {
		_ = exec.Command("xdg-open", filepath.Join(dest, "index.html")).Start()
	}
	return nil
}

func parseBuildArgs(cmd string, args []string) (string, string, bool) {
	dir := "."
	dest := ""
	open := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			fmt.Print(help(cmd))
			return "__help", "", false
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return "__help", "", false
		}
		switch {
		case a == "-o" || a == "--open":
			open = true
		case (a == "-d" || a == "--dest-dir") && i+1 < len(args):
			i++
			dest = args[i]
		case strings.HasPrefix(a, "--dest-dir="):
			dest = strings.TrimPrefix(a, "--dest-dir=")
		case a == "--watcher" && i+1 < len(args):
			i++
		case strings.HasPrefix(a, "--watcher="):
		case strings.HasPrefix(a, "-"):
		default:
			dir = a
		}
	}
	return dir, dest, open
}

func cmdClean(args []string) error {
	dir, dest, _ := parseBuildArgs("clean", args)
	if dir == "__help" {
		return nil
	}
	cfg := readConfig(dir)
	if dest == "" {
		dest = cfg.BuildDir
	}
	if dest == "" {
		dest = "book"
	}
	if !filepath.IsAbs(dest) {
		dest = filepath.Join(dir, dest)
	}
	n, size := countTree(dest)
	os.RemoveAll(dest)
	fmt.Printf("Removed %d files, %s total\n", n, human(size))
	return nil
}

func cmdTest(args []string) error {
	dir, _, _ := parseBuildArgs("test", args)
	if dir == "__help" {
		return nil
	}
	cfg := readConfig(dir)
	src := filepath.Join(dir, cfg.Src)
	chapters, err := parseSummary(filepath.Join(src, "SUMMARY.md"))
	if err != nil {
		return cmdBuild(args, true)
	}
	fail := 0
	for _, c := range chapters {
		if c.Path == "" {
			continue
		}
		p := filepath.Join(src, filepath.Clean(c.Path))
		code := rustBlocks(p)
		for i, block := range code {
			tmp, _ := os.CreateTemp("", "mdbook-test-*.rs")
			text := block
			if !strings.Contains(text, "fn main") {
				text = "fn main() {\n" + text + "\n}\n"
			}
			tmp.WriteString(text)
			tmp.Close()
			out, err := exec.Command("rustc", "--edition=2021", tmp.Name(), "-o", tmp.Name()+".bin").CombinedOutput()
			os.Remove(tmp.Name())
			os.Remove(tmp.Name() + ".bin")
			if err != nil {
				fail++
				fmt.Fprintf(os.Stderr, "%s:%d: rust code block failed\n%s\n", c.Path, i+1, string(out))
			}
		}
	}
	if fail > 0 {
		return fmt.Errorf("%d code block(s) failed", fail)
	}
	return nil
}

func cmdCompletions(args []string) error {
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		fmt.Print(help("completions"))
		return nil
	}
	s := args[0]
	cmds := "init build test clean completions watch serve help"
	switch s {
	case "bash":
		fmt.Printf("_mdbook() { COMPREPLY=( $(compgen -W \"%s\" -- \"${COMP_WORDS[COMP_CWORD]}\") ); }\ncomplete -F _mdbook executable\n", cmds)
	case "zsh":
		fmt.Printf("#compdef executable\n_arguments '1: :(%s)'\n", cmds)
	case "fish":
		for _, c := range strings.Split(cmds, " ") {
			fmt.Printf("complete -c executable -f -a %s\n", c)
		}
	case "powershell":
		fmt.Println("Register-ArgumentCompleter -CommandName executable -ScriptBlock { param($wordToComplete) 'init','build','test','clean','completions','watch','serve','help' | Where-Object { $_ -like \"$wordToComplete*\" } }")
	case "elvish":
		fmt.Println("set edit:completion:arg-completer[executable] = {|@words| put init build test clean completions watch serve help }")
	default:
		return fmt.Errorf("error: invalid value '%s' for '<SHELL>'", s)
	}
	return nil
}

func cmdWatch(args []string) error {
	dir, _, _ := parseBuildArgs("watch", args)
	if dir == "__help" {
		return nil
	}
	if err := cmdBuild(args, false); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "%s [INFO] (mdbook_driver::watch): Watching %s for changes\n", stamp(), dir)
	select {}
}

func cmdServe(args []string) error {
	dir := "."
	dest := ""
	host := "localhost"
	port := "3000"
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-h" || a == "--help" {
			fmt.Print(help("serve"))
			return nil
		}
		if a == "-V" || a == "--version" {
			fmt.Println(version)
			return nil
		}
		switch {
		case (a == "-d" || a == "--dest-dir") && i+1 < len(args):
			i++
			dest = args[i]
		case strings.HasPrefix(a, "--dest-dir="):
			dest = strings.TrimPrefix(a, "--dest-dir=")
		case (a == "-n" || a == "--hostname") && i+1 < len(args):
			i++
			host = args[i]
		case strings.HasPrefix(a, "--hostname="):
			host = strings.TrimPrefix(a, "--hostname=")
		case (a == "-p" || a == "--port") && i+1 < len(args):
			i++
			port = args[i]
		case strings.HasPrefix(a, "--port="):
			port = strings.TrimPrefix(a, "--port=")
		case a == "-o" || a == "--open":
		case a == "--watcher" && i+1 < len(args):
			i++
		case strings.HasPrefix(a, "-"):
		default:
			dir = a
		}
	}
	buildArgs := []string{}
	if dest != "" {
		buildArgs = append(buildArgs, "--dest-dir", dest)
	}
	buildArgs = append(buildArgs, dir)
	if err := cmdBuild(buildArgs, false); err != nil {
		return err
	}
	cfg := readConfig(dir)
	if dest == "" {
		dest = cfg.BuildDir
	}
	if dest == "" {
		dest = "book"
	}
	if !filepath.IsAbs(dest) {
		dest = filepath.Join(dir, dest)
	}
	fmt.Fprintf(os.Stderr, "%s [INFO] (mdbook_driver::serve): Serving on: http://%s:%s\n", stamp(), host, port)
	return http.ListenAndServe(host+":"+port, http.FileServer(http.Dir(dest)))
}

func readConfig(root string) Config {
	cfg := Config{Title: "", Language: "en", Src: "src", BuildDir: "book"}
	data, err := os.ReadFile(filepath.Join(root, "book.toml"))
	if err != nil {
		return cfg
	}
	section := ""
	for _, raw := range strings.Split(string(data), "\n") {
		line := strings.TrimSpace(strings.Split(raw, "#")[0])
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = strings.Trim(line, "[]")
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.Trim(strings.TrimSpace(parts[1]), `"`)
		if section == "book" {
			switch key {
			case "title":
				cfg.Title = val
			case "language":
				cfg.Language = val
			case "src":
				cfg.Src = val
			case "description":
				cfg.Description = val
			case "authors":
				cfg.Authors = val
			}
		}
		if section == "build" && key == "build-dir" {
			cfg.BuildDir = val
		}
	}
	if cfg.Src == "" {
		cfg.Src = "src"
	}
	return cfg
}

func parseSummary(path string) ([]Chapter, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	re := regexp.MustCompile(`\[([^\]]+)\]\(([^)]*)\)`)
	var chapters []Chapter
	for _, raw := range strings.Split(string(data), "\n") {
		line := strings.TrimRight(raw, " \t")
		m := re.FindStringSubmatch(line)
		if m == nil {
			continue
		}
		prefix := line[:strings.Index(line, "[")]
		level := strings.Count(prefix, "  ") + strings.Count(prefix, "\t") + 1
		chapters = append(chapters, Chapter{Title: strings.TrimSpace(m[1]), Path: strings.TrimSpace(m[2]), Level: level})
	}
	return chapters, nil
}

func htmlPath(md string) string {
	c := filepath.ToSlash(filepath.Clean(md))
	ext := filepath.Ext(c)
	if ext != "" {
		c = strings.TrimSuffix(c, ext)
	}
	if strings.HasSuffix(c, "/README") || c == "README" {
		c = strings.TrimSuffix(c, "README") + "index"
	}
	return c + ".html"
}

func relRoot(outRel string) string {
	depth := strings.Count(filepath.ToSlash(outRel), "/")
	if depth == 0 {
		return ""
	}
	return strings.Repeat("../", depth)
}

func markdownToHTML(md string) string {
	var b strings.Builder
	sc := bufio.NewScanner(strings.NewReader(md))
	inCode := false
	var para []string
	flushPara := func() {
		if len(para) > 0 {
			b.WriteString("<p>" + inline(strings.Join(para, " ")) + "</p>\n")
			para = nil
		}
	}
	for sc.Scan() {
		line := sc.Text()
		if strings.HasPrefix(line, "```") || strings.HasPrefix(line, "~~~") {
			if inCode {
				b.WriteString("</code></pre>\n")
				inCode = false
			} else {
				flushPara()
				codeLang := strings.Fields(strings.TrimSpace(line[3:]))
				lang := ""
				if len(codeLang) > 0 {
					lang = strings.Split(codeLang[0], ",")[0]
				}
				if lang != "" {
					b.WriteString(`<pre><code class="language-` + html.EscapeString(lang) + `">`)
				} else {
					b.WriteString("<pre><code>")
				}
				inCode = true
			}
			continue
		}
		if inCode {
			if strings.HasPrefix(line, "# ") {
				continue
			}
			if strings.HasPrefix(line, "##") {
				line = line[1:]
			}
			b.WriteString(html.EscapeString(line) + "\n")
			continue
		}
		t := strings.TrimSpace(line)
		if t == "" {
			flushPara()
			continue
		}
		if strings.HasPrefix(t, "#") {
			flushPara()
			n := 0
			for n < len(t) && t[n] == '#' {
				n++
			}
			if n > 0 && n <= 6 && len(t) > n && t[n] == ' ' {
				txt := strings.TrimSpace(t[n:])
				id := slug(txt)
				b.WriteString(fmt.Sprintf("<h%d id=\"%s\">%s</h%d>\n", n, id, inline(txt), n))
				continue
			}
		}
		if strings.HasPrefix(t, "- ") || strings.HasPrefix(t, "* ") {
			flushPara()
			b.WriteString("<ul><li>" + inline(strings.TrimSpace(t[2:])) + "</li></ul>\n")
			continue
		}
		if strings.HasPrefix(t, "> ") {
			flushPara()
			b.WriteString("<blockquote><p>" + inline(strings.TrimSpace(t[2:])) + "</p></blockquote>\n")
			continue
		}
		para = append(para, t)
	}
	flushPara()
	return b.String()
}

func inline(s string) string {
	s = html.EscapeString(s)
	link := regexp.MustCompile(`\[([^\]]+)\]\(([^)]+)\)`)
	s = link.ReplaceAllStringFunc(s, func(m string) string {
		sub := link.FindStringSubmatch(m)
		href := sub[2]
		if strings.HasSuffix(href, ".md") {
			href = htmlPath(href)
		}
		return `<a href="` + href + `">` + sub[1] + `</a>`
	})
	code := regexp.MustCompile("`([^`]+)`")
	s = code.ReplaceAllString(s, "<code>$1</code>")
	bold := regexp.MustCompile(`\*\*([^*]+)\*\*`)
	s = bold.ReplaceAllString(s, "<strong>$1</strong>")
	em := regexp.MustCompile(`\*([^*]+)\*`)
	s = em.ReplaceAllString(s, "<em>$1</em>")
	return s
}

func pageHTML(cfg Config, title, nav, content, root string) string {
	full := title
	if cfg.Title != "" && cfg.Title != title {
		full = title + " - " + cfg.Title
	}
	return "<!DOCTYPE HTML>\n<html lang=\"" + esc(attrDefault(cfg.Language, "en")) + "\" class=\"light sidebar-visible\" dir=\"ltr\">\n<head>\n<meta charset=\"UTF-8\">\n<title>" + esc(full) + "</title>\n<meta name=\"description\" content=\"" + esc(cfg.Description) + "\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<link rel=\"stylesheet\" href=\"" + root + "css/general.css\">\n<link rel=\"stylesheet\" href=\"" + root + "css/chrome.css\">\n</head>\n<body>\n<div id=\"body-container\"><nav class=\"sidebar\"><ol class=\"chapter\">" + nav + "</ol></nav><main><div class=\"content\">" + content + "</div></main></div>\n<script src=\"" + root + "book.js\"></script>\n</body>\n</html>\n"
}

func printHTML(cfg Config, chapters []Chapter, src string) string {
	var b strings.Builder
	for _, c := range chapters {
		if c.Path == "" {
			continue
		}
		data, _ := os.ReadFile(filepath.Join(src, filepath.Clean(c.Path)))
		b.WriteString(markdownToHTML(string(data)))
	}
	return pageHTML(cfg, cfg.Title, renderNav(chapters), b.String(), "")
}

func renderNav(chapters []Chapter) string {
	var b strings.Builder
	for _, c := range chapters {
		indent := ""
		if c.Level > 1 {
			indent = fmt.Sprintf(" style=\"margin-left:%dem\"", c.Level-1)
		}
		if c.Path == "" {
			b.WriteString("<li class=\"chapter-item expanded affix\"" + indent + ">" + esc(c.Title) + "</li>\n")
		} else {
			b.WriteString("<li class=\"chapter-item expanded\"" + indent + "><a href=\"" + htmlPath(c.Path) + "\">" + esc(c.Title) + "</a></li>\n")
		}
	}
	return b.String()
}

func processIncludes(s, base string) string {
	re := regexp.MustCompile(`\{\{#include\s+([^}:]+)(?::([^}]+))?\}\}`)
	return re.ReplaceAllStringFunc(s, func(m string) string {
		sub := re.FindStringSubmatch(m)
		p := filepath.Join(base, filepath.Clean(strings.TrimSpace(sub[1])))
		data, err := os.ReadFile(p)
		if err != nil {
			return ""
		}
		lines := strings.Split(string(data), "\n")
		spec := strings.TrimSpace(sub[2])
		if spec != "" {
			start, end := 1, len(lines)
			parts := strings.Split(spec, ":")
			if len(parts) == 1 {
				if n, err := strconv.Atoi(parts[0]); err == nil {
					start, end = n, n
				}
			} else {
				if parts[0] != "" {
					if n, err := strconv.Atoi(parts[0]); err == nil {
						start = n
					}
				}
				if parts[1] != "" {
					if n, err := strconv.Atoi(parts[1]); err == nil {
						end = n
					}
				}
			}
			if start < 1 {
				start = 1
			}
			if end > len(lines) {
				end = len(lines)
			}
			if start <= end {
				lines = lines[start-1 : end]
			}
		}
		return strings.Join(lines, "\n")
	})
}

func copyAssets(src, dest string) {
	filepath.WalkDir(src, func(path string, d os.DirEntry, err error) error {
		if err != nil || path == src {
			return nil
		}
		rel, _ := filepath.Rel(src, path)
		if d.IsDir() {
			if rel == "theme" {
				return filepath.SkipDir
			}
			os.MkdirAll(filepath.Join(dest, rel), 0755)
			return nil
		}
		ext := strings.ToLower(filepath.Ext(path))
		if ext == ".md" {
			return nil
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return nil
		}
		out := filepath.Join(dest, rel)
		os.MkdirAll(filepath.Dir(out), 0755)
		os.WriteFile(out, data, 0644)
		return nil
	})
}

func writeStatic(dest string) {
	files := map[string]string{
		"css/general.css":                   "body{font-family:Arial,sans-serif;margin:0;line-height:1.55}.content{max-width:900px;margin:0 auto;padding:2rem}pre{background:#f6f8fa;padding:1rem;overflow:auto}code{font-family:monospace}.sidebar{float:left;max-width:280px;padding:1rem}.chapter{list-style:none;padding:0}a{color:#0969da}\n",
		"css/chrome.css":                    ".sidebar-visible main{margin-left:300px}@media(max-width:800px){.sidebar{float:none;max-width:none}.sidebar-visible main{margin-left:0}}\n",
		"css/print.css":                     "@media print{.sidebar{display:none}main{margin:0!important}}\n",
		"css/variables.css":                 ":root{--bg:#fff;--fg:#111}\n",
		"book.js":                           "",
		"toc.js":                            "",
		"toc.css":                           "",
		"highlight.js":                      "",
		"highlight.css":                     "",
		"tomorrow-night.css":                "",
		"ayu-highlight.css":                 "",
		"clipboard.min.js":                  "",
		"elasticlunr.min.js":                "",
		"mark.min.js":                       "",
		"searcher.js":                       "",
		"favicon.svg":                       "<svg xmlns=\"http://www.w3.org/2000/svg\"/>",
		"favicon.png":                       "",
		"fonts/fonts.css":                   "",
		"fonts/OPEN-SANS-LICENSE.txt":       "",
		"fonts/SOURCE-CODE-PRO-LICENSE.txt": "",
	}
	for p, c := range files {
		writeFile(filepath.Join(dest, p), c)
	}
}

func createTheme(dir string) {
	writeStatic(dir)
	writeFile(filepath.Join(dir, "index.hbs"), "{{ content }}\n")
}

func rustBlocks(path string) []string {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var out []string
	sc := bufio.NewScanner(bytes.NewReader(data))
	in := false
	skip := false
	var b strings.Builder
	for sc.Scan() {
		line := sc.Text()
		if strings.HasPrefix(line, "```") || strings.HasPrefix(line, "~~~") {
			if in {
				if !skip {
					out = append(out, b.String())
				}
				b.Reset()
				in = false
			} else {
				info := strings.ToLower(strings.TrimSpace(line[3:]))
				lang := strings.Split(info, ",")[0]
				in = lang == "rust" || lang == "rs" || info == ""
				skip = strings.Contains(info, "ignore") || strings.Contains(info, "compile_fail")
			}
			continue
		}
		if in {
			if strings.HasPrefix(line, "# ") {
				continue
			}
			b.WriteString(line + "\n")
		}
	}
	return out
}

func writeFile(path, content string) {
	os.MkdirAll(filepath.Dir(path), 0755)
	os.WriteFile(path, []byte(content), 0644)
}

func countTree(path string) (int, int64) {
	n := 0
	var size int64
	filepath.WalkDir(path, func(p string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return nil
		}
		n++
		if info, err := d.Info(); err == nil {
			size += info.Size()
		}
		return nil
	})
	return n, size
}

func human(n int64) string {
	if n < 1024 {
		return fmt.Sprintf("%dB", n)
	}
	if n < 1024*1024 {
		return fmt.Sprintf("%.2fKiB", float64(n)/1024)
	}
	return fmt.Sprintf("%.2fMiB", float64(n)/(1024*1024))
}

func slug(s string) string {
	s = strings.ToLower(s)
	var b strings.Builder
	lastDash := false
	for _, r := range s {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			b.WriteRune(r)
			lastDash = false
		} else if !lastDash {
			b.WriteByte('-')
			lastDash = true
		}
	}
	return strings.Trim(b.String(), "-")
}

func esc(s string) string { return html.EscapeString(s) }
func attrDefault(s, d string) string {
	if s == "" {
		return d
	}
	return s
}
func stamp() string { return time.Now().UTC().Format("2006-01-02 15:04:05") }

func init() {
	sort.Strings([]string{})
	_, _ = io.Copy, os.ErrNotExist
}
