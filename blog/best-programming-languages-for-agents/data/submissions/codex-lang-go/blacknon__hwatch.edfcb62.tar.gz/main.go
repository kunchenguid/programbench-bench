package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"time"
)

const version = "hwatch 0.3.19"

const helpText = `A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use ` + "`t`" + ` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the ` + "`-x`" + ` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during ` + "`line`" + ` diff and ` + "`word`" + ` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set ` + "`0`" + ` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
`

type config struct {
	batch        bool
	direct       bool
	interval     time.Duration
	logfile      string
	shell        string
	output       string
	differences  string
	aftercommand string
	command      []string
	lineNumber   bool
	reverse      bool
}

type record struct {
	Timestamp string `json:"timestamp"`
	Command   string `json:"command"`
	Status    bool   `json:"status"`
	Output    string `json:"output"`
	Stdout    string `json:"stdout"`
	Stderr    string `json:"stderr"`
}

func main() {
	cfg, action, err := parse(os.Args[1:])
	if err != nil {
		fmt.Fprint(os.Stderr, err.Error())
		os.Exit(2)
	}
	switch action {
	case "help":
		fmt.Print(helpText)
		return
	case "version":
		fmt.Println(version)
		return
	}
	if len(cfg.command) == 0 {
		fmt.Fprint(os.Stderr, "error: command not specified and logfile is empty.\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try '--help'.\n")
		os.Exit(2)
	}
	if cfg.batch {
		runBatch(cfg)
		return
	}
	runBatch(cfg)
}

func parse(args []string) (config, string, error) {
	cfg := config{interval: 2 * time.Second, shell: "sh -c", output: "output", differences: "none"}
	args = prependEnv(args)
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			return cfg, "help", nil
		case "-V", "--version":
			return cfg, "version", nil
		case "-b", "--batch":
			cfg.batch = true
		case "-x", "--exec":
			cfg.direct = true
		case "-B", "--beep", "--border", "--with-scrollbar", "--mouse", "-c", "--color", "-C", "--compress", "-t", "--no-title", "--enable-summary-char", "--no-help-banner", "--no-summary", "-O", "--diff-output-only", "--precise":
		case "-r", "--reverse":
			cfg.reverse = true
		case "-N", "--line-number":
			cfg.lineNumber = true
		case "-n", "--interval":
			i++
			if i >= len(args) {
				return cfg, "", fmt.Errorf("error: a value is required for '--interval <interval>' but none was supplied\n\nFor more information, try '--help'.\n")
			}
			v := strings.ReplaceAll(args[i], ",", ".")
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				return cfg, "", fmt.Errorf("error: invalid value '%s' for '--interval <interval>': invalid float literal\n\nFor more information, try '--help'.\n", args[i])
			}
			if f < 0.001 {
				f = 0.001
			}
			cfg.interval = time.Duration(f * float64(time.Second))
		case "-s", "--shell":
			i++
			if i >= len(args) {
				return cfg, "", fmt.Errorf("error: a value is required for '--shell <shell_command>' but none was supplied\n\nFor more information, try '--help'.\n")
			}
			cfg.shell = args[i]
		case "-A", "--aftercommand":
			i++
			if i >= len(args) {
				return cfg, "", fmt.Errorf("error: a value is required for '--aftercommand <after_command>' but none was supplied\n\nFor more information, try '--help'.\n")
			}
			cfg.aftercommand = args[i]
		case "-K", "--keymap", "-L", "--limit", "--tab-size":
			i++
			if i >= len(args) {
				return cfg, "", fmt.Errorf("error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.\n", a)
			}
		case "-l", "--logfile":
			if i+1 < len(args) && !looksLikeOption(args[i+1]) {
				i++
				cfg.logfile = args[i]
			} else {
				cfg.logfile = "hwatch.log"
			}
		case "-d", "--differences":
			val := "watch"
			if i+1 < len(args) && !looksLikeOption(args[i+1]) {
				i++
				val = args[i]
			}
			if !oneOf(val, "none", "watch", "line", "word") {
				return cfg, "", fmt.Errorf("error: invalid value '%s' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]\n\nFor more information, try '--help'.\n", val)
			}
			cfg.differences = val
		case "-o", "--output":
			val := "output"
			if i+1 < len(args) && !looksLikeOption(args[i+1]) {
				i++
				val = args[i]
			}
			if !oneOf(val, "output", "stdout", "stderr") {
				return cfg, "", fmt.Errorf("error: invalid value '%s' for '--output [<output>]'\n  [possible values: output, stdout, stderr]\n\nFor more information, try '--help'.\n", val)
			}
			cfg.output = val
		default:
			cfg.command = append([]string{}, args[i:]...)
			return cfg, "", nil
		}
	}
	return cfg, "", nil
}

func prependEnv(args []string) []string {
	env := strings.TrimSpace(os.Getenv("HWATCH"))
	if env == "" {
		return args
	}
	parts := strings.Fields(env)
	out := make([]string, 0, len(parts)+len(args))
	out = append(out, parts...)
	out = append(out, args...)
	return out
}

func looksLikeOption(s string) bool {
	return strings.HasPrefix(s, "-")
}

func oneOf(v string, vals ...string) bool {
	for _, x := range vals {
		if v == x {
			return true
		}
	}
	return false
}

func runBatch(cfg config) {
	var last string
	first := true
	for {
		now := time.Now()
		stdout, stderr, status := runCommand(cfg)
		out := stdout + stderr
		display := out
		if cfg.output == "stdout" {
			display = stdout
		} else if cfg.output == "stderr" {
			display = stderr
		}
		if cfg.reverse {
			display = reverseLines(display)
		}
		if cfg.lineNumber {
			display = addLineNumbers(display)
		}
		writeHeader(now)
		io.WriteString(os.Stdout, display)
		fmt.Println()
		if cfg.logfile != "" && (first || out != last) {
			appendLog(cfg, now, stdout, stderr, status)
		}
		if cfg.aftercommand != "" && !first && out != last {
			runAfter(cfg.aftercommand, cfg, now, stdout, stderr, status)
		}
		first = false
		last = out
		time.Sleep(cfg.interval)
	}
}

func writeHeader(t time.Time) {
	fmt.Printf("\x1b[38;5;240m=====[%s]=========================\x1b[0m\n", t.Format("2006-01-02 15:04:05.000"))
}

func runCommand(cfg config) (string, string, bool) {
	var cmd *exec.Cmd
	if cfg.direct {
		cmd = exec.Command(cfg.command[0], cfg.command[1:]...)
	} else {
		command := strings.Join(cfg.command, " ")
		parts := strings.Fields(cfg.shell)
		if strings.Contains(cfg.shell, "{COMMAND}") {
			replaced := strings.ReplaceAll(cfg.shell, "{COMMAND}", command)
			parts = strings.Fields(replaced)
			cmd = exec.Command(parts[0], parts[1:]...)
		} else if len(parts) >= 2 {
			cmd = exec.Command(parts[0], append(parts[1:], command)...)
		} else if len(parts) == 1 {
			cmd = exec.Command(parts[0], command)
		} else {
			cmd = exec.Command("sh", "-c", command)
		}
	}
	var outBuf, errBuf bytes.Buffer
	cmd.Stdout = &outBuf
	cmd.Stderr = &errBuf
	err := cmd.Run()
	return outBuf.String(), errBuf.String(), err == nil
}

func appendLog(cfg config, t time.Time, stdout, stderr string, status bool) {
	f, err := os.OpenFile(cfg.logfile, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	rec := record{
		Timestamp: t.Format("2006-01-02 15:04:05.000"),
		Command:   strings.Join(cfg.command, " "),
		Status:    status,
		Output:    stdout + stderr,
		Stdout:    stdout,
		Stderr:    stderr,
	}
	b, _ := json.Marshal(rec)
	f.Write(b)
	f.Write([]byte("\n"))
}

func runAfter(after string, cfg config, t time.Time, stdout, stderr string, status bool) {
	rec := record{Timestamp: t.Format("2006-01-02 15:04:05.000"), Command: strings.Join(cfg.command, " "), Status: status, Output: stdout + stderr, Stdout: stdout, Stderr: stderr}
	b, _ := json.Marshal(rec)
	cmd := exec.Command("sh", "-c", after)
	cmd.Env = append(os.Environ(), "HWATCH_DATA="+string(b))
	_ = cmd.Run()
}

func reverseLines(s string) string {
	lines := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
	for i, j := 0, len(lines)-1; i < j; i, j = i+1, j-1 {
		lines[i], lines[j] = lines[j], lines[i]
	}
	if len(lines) == 1 && lines[0] == "" {
		return ""
	}
	return strings.Join(lines, "\n") + "\n"
}

func addLineNumbers(s string) string {
	if s == "" {
		return s
	}
	lines := strings.Split(strings.TrimSuffix(s, "\n"), "\n")
	for i := range lines {
		lines[i] = fmt.Sprintf("%6d  %s", i+1, lines[i])
	}
	return strings.Join(lines, "\n") + "\n"
}

var _ = errors.New
