module hwatch-reimpl

go 1.21
