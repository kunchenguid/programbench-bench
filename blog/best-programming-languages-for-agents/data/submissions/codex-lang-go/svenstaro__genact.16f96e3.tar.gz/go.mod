module genact-reimplementation

go 1.21
