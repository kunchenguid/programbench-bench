package main

import (
	"fmt"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"
)

var modules = []string{
	"ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
	"cryptomining", "docker_build", "docker_image_rm", "download", "julia",
	"kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
	"terraform", "uv", "weblog", "wpt",
}

var moduleSet = func() map[string]bool {
	m := map[string]bool{}
	for _, v := range modules {
		m[v] = true
	}
	return m
}()

type opts struct {
	listModules    bool
	printManpage   bool
	version        bool
	help           bool
	inhibit        bool
	modules        []string
	speed          float64
	instant        int
	exitAfterMods  int
	exitAfterTime  time.Duration
	completion     string
	completionSeen bool
}

func main() {
	rand.Seed(42)
	o, ok := parse(os.Args[1:])
	if !ok {
		os.Exit(2)
	}
	switch {
	case o.help:
		printHelp()
	case o.version:
		fmt.Println("genact 1.5.1")
	case o.listModules:
		fmt.Println("Available modules:")
		for _, m := range modules {
			fmt.Printf("  %s\n", m)
		}
	case o.printManpage:
		printManpage()
	case o.completionSeen:
		printCompletion(o.completion)
	default:
		run(o)
	}
}

func parse(args []string) (opts, bool) {
	o := opts{speed: 1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		need := func(name string) (string, bool) {
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", name)
				return "", false
			}
			i++
			return args[i], true
		}
		switch a {
		case "-h", "--help":
			o.help = true
		case "-V", "--version":
			o.version = true
		case "-l", "--list-modules":
			o.listModules = true
		case "--print-manpage":
			o.printManpage = true
		case "--inhibit":
			o.inhibit = true
		case "-m", "--modules":
			v, ok := need("--modules")
			if !ok {
				return o, false
			}
			if !moduleSet[v] {
				invalidModule(v)
				return o, false
			}
			o.modules = append(o.modules, v)
		case "-s", "--speed-factor":
			v, ok := need("--speed-factor")
			if !ok {
				return o, false
			}
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--speed-factor <SPEED_FACTOR>': invalid float literal\n\nFor more information, try '--help'.\n", v)
				return o, false
			}
			o.speed = f
		case "-i", "--instant-print-lines":
			v, ok := need("--instant-print-lines")
			if !ok {
				return o, false
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--instant-print-lines <INSTANT_PRINT_LINES>': invalid digit found in string\n\nFor more information, try '--help'.\n", v)
				return o, false
			}
			o.instant = n
		case "--exit-after-modules":
			v, ok := need("--exit-after-modules")
			if !ok {
				return o, false
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--exit-after-modules <EXIT_AFTER_MODULES>': invalid digit found in string\n\nFor more information, try '--help'.\n", v)
				return o, false
			}
			o.exitAfterMods = n
		case "--exit-after-time":
			v, ok := need("--exit-after-time")
			if !ok {
				return o, false
			}
			d, err := parseDuration(v)
			if err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--exit-after-time <EXIT_AFTER_TIME>': %s\n\nFor more information, try '--help'.\n", v, err.Error())
				return o, false
			}
			o.exitAfterTime = d
		case "--print-completions":
			v, ok := need("--print-completions")
			if !ok {
				return o, false
			}
			if !contains([]string{"bash", "elvish", "fish", "powershell", "zsh"}, v) {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--print-completions <shell>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", v)
				return o, false
			}
			o.completion = v
			o.completionSeen = true
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", a)
			} else {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", a)
			}
			return o, false
		}
	}
	return o, true
}

func parseDuration(s string) (time.Duration, error) {
	if s == "" || s[0] < '0' || s[0] > '9' {
		return 0, fmt.Errorf("expected number at 0")
	}
	var total time.Duration
	for len(s) > 0 {
		j := 0
		for j < len(s) && s[j] >= '0' && s[j] <= '9' {
			j++
		}
		if j == 0 {
			return 0, fmt.Errorf("expected number at 0")
		}
		n, _ := strconv.Atoi(s[:j])
		s = s[j:]
		unit := ""
		for len(s) > 0 && (s[0] < '0' || s[0] > '9') {
			unit += s[:1]
			s = s[1:]
			if unit == "h" || unit == "min" || unit == "s" || unit == "ms" {
				break
			}
		}
		switch unit {
		case "h":
			total += time.Duration(n) * time.Hour
		case "min":
			total += time.Duration(n) * time.Minute
		case "s", "":
			total += time.Duration(n) * time.Second
		case "ms":
			total += time.Duration(n) * time.Millisecond
		default:
			return 0, fmt.Errorf("unknown unit")
		}
	}
	return total, nil
}

func invalidModule(v string) {
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--modules <MODULES>'\n  [possible values: %s]\n", v, strings.Join(modules, ", "))
	if v == "cargo,cc" {
		fmt.Fprintln(os.Stderr, "\n  tip: a similar value exists: 'cargo'")
	} else if v == "nope" {
		fmt.Fprintln(os.Stderr, "\n  tip: a similar value exists: 'composer'")
	}
	fmt.Fprintln(os.Stderr, "\nFor more information, try '--help'.")
}

func printHelp() {
	fmt.Print(`A nonsense activity generator

Usage: executable [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version
`)
}

func printManpage() {
	fmt.Print(`.ie \n(.g .ds Aq \(aq
.el .ds Aq '
.TH genact 1  "genact 1.5.1" 
.SH NAME
genact \- A nonsense activity generator
.SH SYNOPSIS
\fBgenact\fR [\fB\-l\fR|\fB\-\-list\-modules\fR] [\fB\-m\fR|\fB\-\-modules\fR] [\fB\-s\fR|\fB\-\-speed\-factor\fR] [\fB\-i\fR|\fB\-\-instant\-print\-lines\fR] [\fB\-\-inhibit\fR] [\fB\-\-exit\-after\-time\fR] [\fB\-\-exit\-after\-modules\fR] [\fB\-\-print\-completions\fR] [\fB\-\-print\-manpage\fR] [\fB\-h\fR|\fB\-\-help\fR] [\fB\-V\fR|\fB\-\-version\fR] 
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\fB\-l\fR, \fB\-\-list\-modules\fR
List available modules
.TP
\fB\-m\fR, \fB\-\-modules\fR \fI<MODULES>\fR
Run only these modules
.br

.br
\fIPossible values:\fR
.RS 14
`)
	for _, m := range modules {
		fmt.Printf(".IP \\(bu 2\n%s\n", m)
	}
	fmt.Print(`.RE
.TP
\fB\-s\fR, \fB\-\-speed\-factor\fR \fI<SPEED_FACTOR>\fR [default: 1]
Global speed factor
.TP
\fB\-i\fR, \fB\-\-instant\-print\-lines\fR \fI<INSTANT_PRINT_LINES>\fR [default: 0]
Instantly print this many lines
.TP
\fB\-\-inhibit\fR
Keep the computer awake and the display on while genact is running
.TP
\fB\-\-exit\-after\-time\fR \fI<EXIT_AFTER_TIME>\fR
Exit after running for this long (format example: 2h10min)
.TP
\fB\-\-exit\-after\-modules\fR \fI<EXIT_AFTER_MODULES>\fR
Exit after running this many modules
.TP
\fB\-\-print\-completions\fR \fI<shell>\fR
Generate completion file for a shell
.br

.br
\fIPossible values:\fR
.RS 14
.IP \(bu 2
bash
.IP \(bu 2
elvish
.IP \(bu 2
fish
.IP \(bu 2
powershell
.IP \(bu 2
zsh
.RE
.TP
\fB\-\-print\-manpage\fR
Generate man page
.TP
\fB\-h\fR, \fB\-\-help\fR
Print help
.TP
\fB\-V\fR, \fB\-\-version\fR
Print version
.SH VERSION
v1.5.1
.SH AUTHORS
Sven\-Hendrik Haase <svenstaro@gmail.com>
`)
}

func printCompletion(shell string) {
	words := strings.Join(modules, " ")
	switch shell {
	case "bash":
		fmt.Printf(`_genact() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    case "${prev}" in
        --modules|-m)
            COMPREPLY=($(compgen -W "%s" -- "${cur}")); return 0 ;;
        --print-completions)
            COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "${cur}")); return 0 ;;
    esac
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}
complete -F _genact genact
`, words)
	case "fish":
		fmt.Println("complete -c genact -s l -l list-modules -d 'List available modules'")
		for _, m := range modules {
			fmt.Printf("complete -c genact -s m -l modules -a %s\n", m)
		}
	case "zsh":
		fmt.Printf("#compdef genact\n_arguments '--modules[%s]' '--list-modules' '--help' '--version'\n", words)
	case "elvish":
		fmt.Println("edit:completion:arg-completer[genact] = {|@words| put --list-modules --modules --help --version }")
	case "powershell":
		fmt.Println("Register-ArgumentCompleter -Native -CommandName genact -ScriptBlock { param($wordToComplete) '--list-modules','--modules','--help','--version' }")
	}
}

func run(o opts) {
	selected := o.modules
	if len(selected) == 0 {
		selected = append([]string{}, modules...)
	}
	limit := len(selected)
	if o.exitAfterMods > 0 && o.exitAfterMods < limit {
		limit = o.exitAfterMods
	}
	deadline := time.Time{}
	if o.exitAfterTime > 0 {
		deadline = time.Now().Add(o.exitAfterTime)
	}
	lines := 30
	if o.instant > lines {
		lines = o.instant
	}
	if o.exitAfterTime > 0 && lines > 60 {
		lines = 60
	}
	for i := 0; i < limit; i++ {
		if !deadline.IsZero() && time.Now().After(deadline) {
			return
		}
		emitModule(selected[i], lines, o.speed)
	}
}

func emitModule(name string, lines int, speed float64) {
	switch name {
	case "ansible":
		for i := 0; i < lines; i++ {
			hosts := []string{"web01", "db02", "cache03", "lb01"}
			tasks := []string{"Gathering Facts", "Install packages", "Template configuration", "Restart service"}
			fmt.Printf("TASK [%s] *********************************************************\n%s | SUCCESS => {\"changed\": %v}\n", tasks[i%len(tasks)], hosts[i%len(hosts)], i%3 == 0)
		}
	case "bootlog":
		s := []string{"CPU0: Thermal monitoring enabled (TM1)", "ACPI: SSDT 0x00000000ACDE2000 0009CB", "DMAR-IR: Enabled IRQ remapping in xapic mode", "random: fast init done", "smp: Bringing up secondary CPUs ...", "CPU2 is up"}
		repeat(s, lines)
	case "botnet":
		total := 2251
		for i := 0; i < lines; i++ {
			fmt.Printf("\rEstablishing connections: %4d/%d", i, total)
		}
		fmt.Println()
	case "bruteforce":
		for i := 0; i < lines; i++ {
			fmt.Printf("Trying password for root@192.168.%d.%d: %s ... failed\n", i%255, (i*17)%255, randString(10))
		}
	case "cargo":
		verbs := []string{"Downloading", "Compiling", "Checking", "Building"}
		crates := []string{"serde", "tokio", "clap", "rand", "regex", "futures", "openssl-sys"}
		for i := 0; i < lines; i++ {
			fmt.Printf("   %s %s v%d.%d.%d\n", verbs[i%len(verbs)], crates[i%len(crates)], i%3, i%12, i%9)
		}
	case "cc":
		for i := 0; i < lines; i++ {
			fmt.Printf("gcc -c -O2 -Wall -Iinclude -Isrc -o build/%s.o src/%s.c\n", fileStem(i), fileStem(i))
		}
	case "composer":
		fmt.Println("Loading composer repositories with package information")
		fmt.Println("Updating dependencies (including require-dev)")
		pkgs := []string{"symfony/polyfill-mbstring", "phpunit/php-code-coverage", "doctrine/annotations", "guzzlehttp/promises"}
		for i := 0; i < lines; i++ {
			fmt.Printf("  - Installing %s (%d.%d.%d): Loading from cache\n", pkgs[i%len(pkgs)], i%10, i%20, i%30)
		}
	case "cryptomining":
		for i := 0; i < lines; i++ {
			fmt.Printf("  m  %s|cryptominer  Speed  %.2f Mh/s    gpu/0 %.2f gpu/1 %.2f   [A%d+0:R0+0:F0] Time: 00:%02d\n", time.Now().Format("15:04:05"), 54+rand.Float64()*3, 27+rand.Float64(), 27+rand.Float64(), i/20, i%60)
		}
	case "docker_build":
		for i := 0; i < lines/2; i++ {
			fmt.Printf("\rSending build context to Docker daemon  %.2fMB", float64(i)*18.37)
		}
		fmt.Println()
		for i := 1; i <= lines/2; i++ {
			fmt.Printf("Step %d/84 : RUN %s\n ---> Using cache ---> %012x\n", i, []string{"cargo run", "rkhunter --check", "mkinitcpio -P"}[i%3], rand.Int63())
		}
	case "docker_image_rm":
		for i := 0; i < lines; i++ {
			if i%12 == 0 {
				fmt.Printf("Untagged: python:%d.04\n", 16+i%8)
			} else {
				fmt.Printf("Deleted: sha256:%064x\n", rand.Uint64())
			}
		}
	case "download":
		for i := 0; i < lines; i++ {
			fmt.Printf("file-%03d.iso  %3d%% [%s%s] %.1f MiB/s\n", i, (i*7)%101, strings.Repeat("=", i%20), strings.Repeat(" ", 20-i%20), 2+rand.Float64()*20)
		}
	case "julia":
		fmt.Println("               _")
		fmt.Println("   _       _ _(_) _     |  Documentation: https://docs.julialang.org")
		fmt.Println("  (_)     | (_) (_)    |  Type \"?\" for help, \"]?\" for Pkg help.")
		fmt.Println("   _ _   _| |_  __ _   |  Version 1.7.3 (2022-05-06)")
		for i := 0; i < lines; i++ {
			fmt.Printf("   Installed %-28s v0.%d.%d\n", juliaPkg(i), i%10, i%7)
		}
	case "kernel_compile":
		kinds := []string{"CC", "CHK", "AR", "LDS", "UPD", "WRAP"}
		for i := 0; i < lines; i++ {
			fmt.Printf("  %-7s %s/%s.o\n", kinds[i%len(kinds)], kernelDir(i), fileStem(i))
		}
	case "memdump":
		for i := 0; i < lines; i++ {
			fmt.Printf("%08x  %s  |%s|\n", i*16, hexBytes(16), randString(16))
		}
	case "mkinitcpio":
		steps := []string{"Starting build: 6.8.7-arch1-1", "Running build hook: [base]", "Running build hook: [udev]", "Generating module dependencies", "Creating gzip-compressed initcpio image"}
		repeat(steps, lines)
	case "rkhunter":
		checks := []string{"Checking system commands", "Checking for rootkits", "Checking network ports", "Checking local host", "Performing filesystem checks"}
		for i := 0; i < lines; i++ {
			fmt.Printf("[ Rootkit Hunter version 1.4.6 ] %s... [ OK ]\n", checks[i%len(checks)])
		}
	case "simcity":
		events := []string{"Residential demand is increasing", "Building road segment", "Power plant efficiency at 92%", "Traffic congestion reported", "Zone developed"}
		repeat(events, lines)
	case "terraform":
		actions := []string{"aws_instance.web: Refreshing state", "aws_vpc.main: Creating...", "aws_subnet.public: Still creating...", "aws_security_group.app: Creation complete", "Apply complete! Resources: 3 added, 0 changed, 0 destroyed."}
		repeat(actions, lines)
	case "uv":
		pkgs := []string{"anyio", "fastapi", "pydantic-core", "ruff", "starlette", "uvloop"}
		for i := 0; i < lines; i++ {
			fmt.Printf("Resolved %d packages in %dms\nPrepared %s==%d.%d.%d\n", 50+i, 20+i*3, pkgs[i%len(pkgs)], i%3, i%10, i%20)
		}
	case "weblog":
		methods := []string{"GET", "POST", "PUT", "DELETE"}
		paths := []string{"/", "/api/v1/users", "/wp-login.php", "/assets/app.js", "/health"}
		for i := 0; i < lines; i++ {
			fmt.Printf("10.0.%d.%d - - [%s] \"%s %s HTTP/1.1\" %d %d\n", i%255, (i*31)%255, time.Now().Format("02/Jan/2006:15:04:05 -0700"), methods[i%len(methods)], paths[i%len(paths)], []int{200, 301, 404, 500}[i%4], 200+rand.Intn(8000))
		}
	case "wpt":
		for i := 0; i < lines; i++ {
			fmt.Printf("Running test %d of %d: %s ... %s\n", i+1, lines, []string{"First View", "Repeat View", "Lighthouse", "SpeedIndex"}[i%4], []string{"OK", "pending", "complete"}[i%3])
		}
	}
	if speed > 0 && speed < 100 && lines < 100 {
		time.Sleep(time.Duration(20/speed) * time.Millisecond)
	}
}

func repeat(lines []string, n int) {
	for i := 0; i < n; i++ {
		fmt.Println(lines[i%len(lines)])
	}
}

func randString(n int) string {
	const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	var b strings.Builder
	for i := 0; i < n; i++ {
		b.WriteByte(chars[rand.Intn(len(chars))])
	}
	return b.String()
}

func fileStem(i int) string {
	names := []string{"main", "buffer", "parser", "net", "scheduler", "crypto", "device", "memory", "trace", "driver"}
	return names[i%len(names)]
}

func kernelDir(i int) string {
	dirs := []string{"net/netfilter", "drivers/scsi", "crypto", "arch/arm64/kernel", "drivers/gpu/drm", "sound/core"}
	return dirs[i%len(dirs)]
}

func juliaPkg(i int) string {
	pkgs := []string{"OptimizedEinsum", "SpeedyWeather", "MMTF", "NamedArrays", "CrystalNets", "ImageInpainting"}
	return pkgs[i%len(pkgs)]
}

func hexBytes(n int) string {
	parts := make([]string, n)
	for i := range parts {
		parts[i] = fmt.Sprintf("%02x", rand.Intn(256))
	}
	return strings.Join(parts, " ")
}

func contains(xs []string, x string) bool {
	for _, v := range xs {
		if v == x {
			return true
		}
	}
	return false
}
