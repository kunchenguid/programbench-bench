module tinyccshim

go 1.21
