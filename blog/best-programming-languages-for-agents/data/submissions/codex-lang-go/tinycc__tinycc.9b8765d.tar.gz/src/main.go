package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

const versionLine = "tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)"

const helpText = `Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
`

const moreHelpText = `Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary] set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
`

const searchDirs = `install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
`

type options struct {
	gccArgs     []string
	runMode     bool
	runSource   string
	runArgs     []string
	runStdin    string
	bench       bool
	hadStd      bool
	preprocess  bool
	output      string
	compileOnly bool
}

func main() {
	args, err := expandAtFiles(os.Args[1:])
	if err != nil {
		fatal("%v", err)
	}
	if len(args) == 0 {
		fmt.Print(helpText)
		return
	}
	if args[0] == "-ar" {
		os.Exit(runTool("ar", args[1:], ""))
	}
	for _, a := range args {
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return
		case "-hh":
			fmt.Print(moreHelpText)
			return
		case "-v", "--version":
			fmt.Println(versionLine)
			return
		case "-vv":
			fmt.Println(versionLine)
			fmt.Print(searchDirs)
			return
		case "-dumpversion":
			fmt.Println("0.9.28rc")
			return
		case "-print-search-dirs":
			fmt.Print(searchDirs)
			return
		}
	}
	opts, err := translate(args)
	if err != nil {
		fatal("%v", err)
	}
	if opts.runMode {
		os.Exit(runC(opts))
	}
	status := runGCC(opts.gccArgs, "")
	if opts.bench && status == 0 {
		fmt.Fprintln(os.Stderr, "# 0.010 s, 100 lines/s, 0.0 MB/s")
	}
	os.Exit(status)
}

func translate(args []string) (*options, error) {
	opts := &options{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if opts.runMode && opts.runSource != "" {
			opts.runArgs = append(opts.runArgs, args[i:]...)
			break
		}
		switch {
		case a == "-run":
			opts.runMode = true
		case opts.runMode && opts.runSource == "":
			opts.runSource = a
		case a == "-rstdin":
			i++
			if i >= len(args) {
				return nil, fmt.Errorf("argument to '-rstdin' is missing")
			}
			opts.runStdin = args[i]
		case a == "-o":
			i++
			if i >= len(args) {
				return nil, fmt.Errorf("argument to '-o' is missing")
			}
			opts.output = args[i]
			opts.gccArgs = append(opts.gccArgs, "-o", args[i])
		case strings.HasPrefix(a, "-o") && len(a) > 2:
			opts.output = a[2:]
			opts.gccArgs = append(opts.gccArgs, a)
		case a == "-c":
			opts.compileOnly = true
			opts.gccArgs = append(opts.gccArgs, a)
		case a == "-E":
			opts.preprocess = true
			opts.gccArgs = append(opts.gccArgs, a)
		case a == "-bench":
			opts.bench = true
		case a == "-soname":
			i++
			if i >= len(args) {
				return nil, fmt.Errorf("argument to '-soname' is missing")
			}
			opts.gccArgs = append(opts.gccArgs, "-Wl,-soname,"+args[i])
		case a == "-pthread":
			opts.gccArgs = append(opts.gccArgs, "-D_REENTRANT", "-pthread")
		case a == "-":
			opts.gccArgs = append(opts.gccArgs, "-x", "c", "-")
		case a == "-dt":
			// TCC test macro mode. Most programs do not depend on it.
		case a == "-b" || strings.HasPrefix(a, "-bt") || strings.HasPrefix(a, "-gdwarf"):
			opts.gccArgs = append(opts.gccArgs, "-g")
		case a == "-P1":
			opts.gccArgs = append(opts.gccArgs, "-P")
		case a == "-P" || a == "-dD" || a == "-dM" || a == "-M" || a == "-MM" || a == "-MD" || a == "-MMD" || a == "-MF" || a == "-include" || a == "-isystem" || a == "-x":
			opts.gccArgs = append(opts.gccArgs, a)
			if takesSeparateArg(a) {
				i++
				if i >= len(args) {
					return nil, fmt.Errorf("argument to '%s' is missing", a)
				}
				opts.gccArgs = append(opts.gccArgs, mapXArg(a, args[i]))
			}
		case a == "-I" || a == "-D" || a == "-U" || a == "-L" || a == "-l":
			i++
			if i >= len(args) {
				return nil, fmt.Errorf("argument to '%s' is missing", a)
			}
			opts.gccArgs = append(opts.gccArgs, a+args[i])
		case strings.HasPrefix(a, "-std="):
			opts.hadStd = true
			opts.gccArgs = append(opts.gccArgs, a)
		case passPrefix(a):
			opts.gccArgs = append(opts.gccArgs, a)
		case ignoreArg(a):
			if a == "--param" || a == "-arch" {
				if i+1 < len(args) {
					i++
				}
			}
		case strings.HasPrefix(a, "--"):
			return nil, fmt.Errorf("invalid option -- '%s'", a)
		default:
			opts.gccArgs = append(opts.gccArgs, a)
		}
	}
	if opts.runMode && opts.runSource == "" {
		return nil, fmt.Errorf("file name missing after '-run'")
	}
	if !opts.hadStd {
		opts.gccArgs = append([]string{"-std=gnu99"}, opts.gccArgs...)
	}
	opts.gccArgs = append([]string{"-D__TINYC__=928", "-isystem", "/usr/local/lib/tcc/include"}, opts.gccArgs...)
	return opts, nil
}

func passPrefix(a string) bool {
	prefixes := []string{
		"-I", "-D", "-U", "-L", "-l", "-Wl,", "-Wp,", "-W", "-f", "-m",
		"-O", "-g", "-shared", "-static", "-nostdinc", "-nostdlib",
		"-rdynamic", "-r", "-s", "-pipe", "-C", "-traditional",
	}
	for _, p := range prefixes {
		if strings.HasPrefix(a, p) {
			if strings.HasPrefix(a, "-Wunsupported") || strings.HasPrefix(a, "-Wno-unsupported") {
				return false
			}
			if strings.HasPrefix(a, "-Wp,") {
				return false
			}
			return true
		}
	}
	return false
}

func ignoreArg(a string) bool {
	if a == "-arch" || a == "--param" || a == "-pedantic" || a == "-pipe" || a == "-s" || a == "-traditional" {
		return true
	}
	return strings.HasPrefix(a, "-B") || strings.HasPrefix(a, "-Wp,") || strings.HasPrefix(a, "-Wunsupported") || strings.HasPrefix(a, "-Wno-unsupported")
}

func takesSeparateArg(a string) bool {
	return a == "-MF" || a == "-include" || a == "-isystem" || a == "-x"
}

func mapXArg(flag, value string) string {
	if flag != "-x" {
		return value
	}
	switch value {
	case "c":
		return "c"
	case "a":
		return "assembler"
	case "n":
		return "none"
	case "b":
		return "binary"
	default:
		return value
	}
}

func runC(opts *options) int {
	tmp, err := os.MkdirTemp("", "tccrun-*")
	if err != nil {
		fatal("%v", err)
	}
	defer os.RemoveAll(tmp)
	out := filepath.Join(tmp, "a.out")
	args := append([]string{}, opts.gccArgs...)
	source := opts.runSource
	if source != "-" {
		if rewritten, ok := rewriteShebangSource(tmp, source); ok {
			source = rewritten
		}
	}
	args = append(args, "-o", out)
	if source == "-" {
		args = append(args, "-x", "c", "-")
	} else {
		args = append(args, source)
	}
	if status := runGCC(args, ""); status != 0 {
		return status
	}
	cmd := exec.Command(out, opts.runArgs...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if opts.runStdin != "" {
		f, err := os.Open(opts.runStdin)
		if err != nil {
			fmt.Fprintf(os.Stderr, "tcc: error: could not open '%s'\n", opts.runStdin)
			return 1
		}
		defer f.Close()
		cmd.Stdin = f
	} else {
		cmd.Stdin = os.Stdin
	}
	if err := cmd.Run(); err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return ee.ExitCode()
		}
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func rewriteShebangSource(tmp, path string) (string, bool) {
	f, err := os.Open(path)
	if err != nil {
		return path, false
	}
	defer f.Close()
	head := make([]byte, 2)
	n, _ := io.ReadFull(f, head)
	if n != 2 || string(head) != "#!" {
		return path, false
	}
	if _, err := f.Seek(0, io.SeekStart); err != nil {
		return path, false
	}
	data, err := io.ReadAll(f)
	if err != nil {
		return path, false
	}
	if idx := strings.IndexByte(string(data), '\n'); idx >= 0 {
		data = data[idx+1:]
	} else {
		data = nil
	}
	rewritten := filepath.Join(tmp, filepath.Base(path)+".c")
	if err := os.WriteFile(rewritten, data, 0644); err != nil {
		return path, false
	}
	return rewritten, true
}

func runGCC(args []string, stdinFile string) int {
	return runTool("gcc", args, stdinFile)
}

func runTool(name string, args []string, stdinFile string) int {
	cmd := exec.Command(name, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if stdinFile != "" {
		f, err := os.Open(stdinFile)
		if err != nil {
			fmt.Fprintf(os.Stderr, "%s\n", err)
			return 1
		}
		defer f.Close()
		cmd.Stdin = f
	} else {
		cmd.Stdin = os.Stdin
	}
	if err := cmd.Run(); err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return ee.ExitCode()
		}
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	return 0
}

func expandAtFiles(args []string) ([]string, error) {
	var out []string
	for _, a := range args {
		if strings.HasPrefix(a, "@") && len(a) > 1 {
			parts, err := readArgsFile(a[1:])
			if err != nil {
				return nil, err
			}
			out = append(out, parts...)
		} else {
			out = append(out, a)
		}
	}
	return out, nil
}

func readArgsFile(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("could not open '%s'", path)
	}
	defer f.Close()
	return splitArgs(f)
}

func splitArgs(r io.Reader) ([]string, error) {
	var args []string
	br := bufio.NewReader(r)
	var b strings.Builder
	var quote rune
	escaped := false
	flush := func() {
		if b.Len() > 0 {
			args = append(args, b.String())
			b.Reset()
		}
	}
	for {
		ch, _, err := br.ReadRune()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		if escaped {
			b.WriteRune(ch)
			escaped = false
			continue
		}
		if ch == '\\' {
			escaped = true
			continue
		}
		if quote != 0 {
			if ch == quote {
				quote = 0
			} else {
				b.WriteRune(ch)
			}
			continue
		}
		if ch == '\'' || ch == '"' {
			quote = ch
			continue
		}
		if ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' {
			flush()
			continue
		}
		b.WriteRune(ch)
	}
	if escaped {
		b.WriteRune('\\')
	}
	flush()
	return args, nil
}

func fatal(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "tcc: error: "+format+"\n", args...)
	os.Exit(1)
}
