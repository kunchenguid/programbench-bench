module gpingclone

go 1.21
