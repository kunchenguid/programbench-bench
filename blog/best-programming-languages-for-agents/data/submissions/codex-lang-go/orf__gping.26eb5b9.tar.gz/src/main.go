package main

import (
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

type options struct {
	cmd              bool
	watchInterval    float64
	watchSet         bool
	buffer           int
	ipv4             bool
	ipv6             bool
	iface            string
	simple           bool
	verticalMargin   int
	horizontalMargin int
	colors           []string
	clear            bool
	pingArgs         []string
	positionals      []string
}

var colorNames = map[string]bool{
	"black": true, "red": true, "green": true, "yellow": true, "blue": true, "magenta": true,
	"cyan": true, "gray": true, "dark-gray": true, "light-red": true, "light-green": true,
	"light-yellow": true, "light-blue": true, "light-magenta": true, "light-cyan": true, "white": true,
}

var hexColor = regexp.MustCompile(`^#[0-9A-Fa-f]{6}$`)

func prog() string {
	p := filepath.Base(os.Args[0])
	if p == "" {
		return "executable"
	}
	return p
}

func main() {
	opts, exit := parse(os.Args[1:])
	if exit >= 0 {
		os.Exit(exit)
	}
	if len(opts.positionals) == 0 {
		fmt.Fprintln(os.Stderr, "Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.")
		os.Exit(1)
	}
	for _, c := range opts.colors {
		if !validColor(c) {
			fmt.Fprintf(os.Stderr, "Error: Invalid color code: `%s`\n\nCaused by:\n    Failed to parse Colors\n", c)
			os.Exit(1)
		}
	}
	if opts.cmd {
		if !isTerminal(os.Stdout) {
			fmt.Fprintln(os.Stderr, "Error: No such device or address (os error 6)")
			os.Exit(1)
		}
		runCommands(opts)
		return
	}
	if _, err := exec.LookPath("ping"); err != nil {
		fmt.Fprintln(os.Stderr, "Error: Could not detect ping. Stderr: []")
		fmt.Fprintln(os.Stderr, "Stdout: []")
		os.Exit(1)
	}
	if err := resolveHosts(opts); err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(1)
	}
	if !isTerminal(os.Stdout) {
		fmt.Fprintln(os.Stderr, "Error: No such device or address (os error 6)")
		os.Exit(1)
	}
	runPingLoop(opts)
}

func parse(args []string) (options, int) {
	opts := options{buffer: 30, verticalMargin: 1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opts.positionals = append(opts.positionals, args[i+1:]...)
			break
		}
		if a == "--cmd" {
			opts.cmd = true
			continue
		}
		if a == "-4" {
			if opts.ipv6 {
				clapErr("the argument '-4' cannot be used with '-6'", "executable -4 [HOSTS_OR_COMMANDS]...")
				return opts, 2
			}
			opts.ipv4 = true
			continue
		}
		if a == "-6" {
			if opts.ipv4 {
				clapErr("the argument '-4' cannot be used with '-6'", "executable -4 [HOSTS_OR_COMMANDS]...")
				return opts, 2
			}
			opts.ipv6 = true
			continue
		}
		if a == "-s" || a == "--simple-graphics" {
			opts.simple = true
			continue
		}
		if a == "--clear" {
			opts.clear = true
			continue
		}
		if a == "-h" || a == "--help" {
			printHelp()
			return opts, 0
		}
		if a == "-V" || a == "--version" {
			printVersion()
			return opts, 0
		}
		if strings.HasPrefix(a, "--help=") {
			v := strings.TrimPrefix(a, "--help=")
			clapErr(fmt.Sprintf("unexpected value '%s' for '--help' found; no more were expected", v), "executable --help [HOSTS_OR_COMMANDS]...")
			return opts, 2
		}
		if strings.HasPrefix(a, "--version=") {
			v := strings.TrimPrefix(a, "--version=")
			clapErr(fmt.Sprintf("unexpected value '%s' for '--version' found; no more were expected", v), "executable --version [HOSTS_OR_COMMANDS]...")
			return opts, 2
		}
		if a == "--ping-args" {
			opts.pingArgs = append(opts.pingArgs, args[i+1:]...)
			break
		}
		if a == "--watch-interval" || a == "-n" || strings.HasPrefix(a, "--watch-interval=") || strings.HasPrefix(a, "-n=") {
			val, ok := flagValue(a, args, &i, "--watch-interval", "WATCH_INTERVAL")
			if !ok {
				return opts, 2
			}
			f, err := strconv.ParseFloat(val, 64)
			if err != nil {
				clapErr(fmt.Sprintf("invalid value '%s' for '--watch-interval <WATCH_INTERVAL>': invalid float literal", val), "")
				return opts, 2
			}
			opts.watchInterval = f
			opts.watchSet = true
			continue
		}
		if a == "--buffer" || a == "-b" || strings.HasPrefix(a, "--buffer=") || strings.HasPrefix(a, "-b=") {
			val, ok := flagValue(a, args, &i, "--buffer", "BUFFER")
			if !ok {
				return opts, 2
			}
			n, err := strconv.Atoi(val)
			if err != nil {
				clapErr(fmt.Sprintf("invalid value '%s' for '--buffer <BUFFER>': invalid digit found in string", val), "")
				return opts, 2
			}
			opts.buffer = n
			continue
		}
		if a == "--vertical-margin" || strings.HasPrefix(a, "--vertical-margin=") {
			val, ok := flagValue(a, args, &i, "--vertical-margin", "VERTICAL_MARGIN")
			if !ok {
				return opts, 2
			}
			n, err := strconv.Atoi(val)
			if err != nil {
				clapErr(fmt.Sprintf("invalid value '%s' for '--vertical-margin <VERTICAL_MARGIN>': invalid digit found in string", val), "")
				return opts, 2
			}
			opts.verticalMargin = n
			continue
		}
		if a == "--horizontal-margin" || strings.HasPrefix(a, "--horizontal-margin=") {
			val, ok := flagValue(a, args, &i, "--horizontal-margin", "HORIZONTAL_MARGIN")
			if !ok {
				return opts, 2
			}
			n, err := strconv.Atoi(val)
			if err != nil {
				clapErr(fmt.Sprintf("invalid value '%s' for '--horizontal-margin <HORIZONTAL_MARGIN>': invalid digit found in string", val), "")
				return opts, 2
			}
			opts.horizontalMargin = n
			continue
		}
		if a == "--interface" || a == "-i" || strings.HasPrefix(a, "--interface=") || strings.HasPrefix(a, "-i=") {
			val, ok := flagValue(a, args, &i, "--interface", "INTERFACE")
			if !ok {
				return opts, 2
			}
			opts.iface = val
			continue
		}
		if a == "--color" || a == "-c" || strings.HasPrefix(a, "--color=") || strings.HasPrefix(a, "-c=") {
			val, ok := flagValue(a, args, &i, "--color", "color")
			if !ok {
				return opts, 2
			}
			for _, part := range strings.Split(val, ",") {
				if part != "" {
					opts.colors = append(opts.colors, part)
				}
			}
			continue
		}
		if strings.HasPrefix(a, "-") {
			if looksNegativeNumber(a) {
				clapUnexpected(a)
			} else {
				clapUnexpected(a)
			}
			return opts, 2
		}
		opts.positionals = append(opts.positionals, a)
	}
	if !opts.watchSet {
		if opts.cmd {
			opts.watchInterval = 0.5
		} else {
			opts.watchInterval = 0.2
		}
	}
	return opts, -1
}

func flagValue(a string, args []string, i *int, long, metav string) (string, bool) {
	if eq := strings.IndexByte(a, '='); eq >= 0 {
		return a[eq+1:], true
	}
	if *i+1 >= len(args) {
		clapErr(fmt.Sprintf("a value is required for '%s <%s>' but none was supplied", long, metav), "")
		return "", false
	}
	*i++
	return args[*i], true
}

func clapUnexpected(arg string) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n", arg)
	fmt.Fprintf(os.Stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg)
	fmt.Fprintln(os.Stderr, "Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...")
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
}

func clapErr(msg, usage string) {
	fmt.Fprintf(os.Stderr, "error: %s\n\n", msg)
	if usage != "" {
		fmt.Fprintf(os.Stderr, "Usage: %s\n\n", usage)
	}
	fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
}

func looksNegativeNumber(s string) bool {
	_, err := strconv.ParseFloat(s, 64)
	return err == nil && strings.HasPrefix(s, "-")
}

func validColor(c string) bool { return colorNames[c] || hexColor.MatchString(c) }

func isTerminal(f *os.File) bool {
	st, err := f.Stat()
	if err != nil {
		return false
	}
	return (st.Mode() & os.ModeCharDevice) != 0
}

func resolveHosts(opts options) error {
	for _, h := range opts.positionals {
		host := expandCloud(h)
		if ip := net.ParseIP(host); ip != nil {
			continue
		}
		if _, err := net.LookupHost(host); err != nil {
			return fmt.Errorf("Error: Resolving %s\n\nCaused by:\n    %s", host, err.Error())
		}
	}
	return nil
}

func expandCloud(s string) string {
	if strings.HasPrefix(s, "aws:") {
		region := strings.TrimPrefix(s, "aws:")
		return "ec2." + region + ".amazonaws.com"
	}
	return s
}

func runCommands(opts options) {
	interval := time.Duration(opts.watchInterval * float64(time.Second))
	if interval <= 0 {
		interval = 500 * time.Millisecond
	}
	for {
		fmt.Print("\033[H\033[2J")
		fmt.Println("gping")
		for _, c := range opts.positionals {
			start := time.Now()
			err := exec.Command("sh", "-c", c).Run()
			d := time.Since(start)
			status := "ok"
			if err != nil {
				status = "error"
			}
			bar := strings.Repeat(ifThen(opts.simple, ".", "⣿"), min(60, max(1, int(d.Milliseconds()/10)+1)))
			fmt.Printf("%s %7.2fms %s %s\n", c, float64(d.Microseconds())/1000, status, bar)
		}
		time.Sleep(interval)
	}
}

func runPingLoop(opts options) {
	interval := time.Duration(opts.watchInterval * float64(time.Second))
	if interval <= 0 {
		interval = 200 * time.Millisecond
	}
	for {
		fmt.Print("\033[H\033[2J")
		fmt.Println("gping")
		for _, h := range opts.positionals {
			fmt.Printf("%s waiting for ping data\n", h)
		}
		time.Sleep(interval)
	}
}

func ifThen(cond bool, a, b string) string {
	if cond {
		return a
	}
	return b
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func printVersion() {
	fmt.Println("gping 1.20.1")
	fmt.Println("commit_hash: d67d2aeb")
	fmt.Println("build_time: 2026-04-17 19:59:37 +00:00")
	fmt.Println("build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu")
}

func printHelp() {
	fmt.Printf(`Ping, but with a graph.

Usage: %s [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to `+"`ping`"+`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
`, prog())
}
