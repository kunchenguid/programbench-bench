package main

import (
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

const version = "v1.13.0"

const helpText = `
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode
`

type options struct {
	icons      bool
	dirOnly    bool
	hideHidden bool
	preview    bool
	border     bool
	fuzzy      bool
	path       string
}

type item struct {
	name  string
	isDir bool
	mode  fs.FileMode
	size  int64
	mod   time.Time
}

func ioctl(fd uintptr, req uintptr, arg uintptr) error {
	_, _, errno := syscall.Syscall(syscall.SYS_IOCTL, fd, req, arg)
	if errno != 0 {
		return errno
	}
	return nil
}

func makeRaw(fd uintptr) (*syscall.Termios, error) {
	var old syscall.Termios
	if err := ioctl(fd, syscall.TCGETS, uintptr(unsafe.Pointer(&old))); err != nil {
		return nil, err
	}
	raw := old
	raw.Iflag &^= syscall.BRKINT | syscall.ICRNL | syscall.INPCK | syscall.ISTRIP | syscall.IXON
	raw.Oflag &^= syscall.OPOST
	raw.Cflag |= syscall.CS8
	raw.Lflag &^= syscall.ECHO | syscall.ICANON | syscall.IEXTEN | syscall.ISIG
	raw.Cc[syscall.VMIN] = 1
	raw.Cc[syscall.VTIME] = 0
	if err := ioctl(fd, syscall.TCSETS, uintptr(unsafe.Pointer(&raw))); err != nil {
		return nil, err
	}
	return &old, nil
}

func restore(fd uintptr, old *syscall.Termios) {
	if old != nil {
		_ = ioctl(fd, syscall.TCSETS, uintptr(unsafe.Pointer(old)))
	}
}

func parseArgs(args []string) options {
	opt := options{path: "."}
	for _, a := range args {
		switch a {
		case "--help", "-h":
			fmt.Print(helpText)
			os.Exit(1)
		case "--version", "-v":
			fmt.Println(version)
			os.Exit(0)
		case "--icons":
			opt.icons = true
		case "--dir-only":
			opt.dirOnly = true
		case "--hide-hidden":
			opt.hideHidden = true
		case "--preview":
			opt.preview = true
		case "--with-border":
			opt.border = true
		case "--fuzzy":
			opt.fuzzy = true
		default:
			if opt.path == "." {
				opt.path = a
			}
		}
	}
	return opt
}

func readItems(path string, opt options) ([]item, error) {
	entries, err := os.ReadDir(path)
	if err != nil {
		return nil, err
	}
	out := make([]item, 0, len(entries))
	for _, e := range entries {
		name := e.Name()
		if opt.hideHidden && strings.HasPrefix(name, ".") {
			continue
		}
		info, _ := e.Info()
		isDir := e.IsDir()
		if opt.dirOnly && !isDir {
			continue
		}
		it := item{name: name, isDir: isDir}
		if info != nil {
			it.mode = info.Mode()
			it.size = info.Size()
			it.mod = info.ModTime()
		}
		out = append(out, it)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].name < out[j].name })
	return out, nil
}

func iconFor(it item) string {
	if it.isDir {
		return ""
	}
	switch strings.ToLower(filepath.Ext(it.name)) {
	case ".md", ".markdown", ".mdx":
		return ""
	case ".go":
		return ""
	case ".js", ".mjs":
		return ""
	case ".json":
		return ""
	case ".html", ".htm":
		return ""
	case ".css", ".less":
		return ""
	case ".py":
		return ""
	case ".sh", ".bash", ".zsh":
		return ""
	case ".png", ".jpg", ".jpeg", ".gif", ".webp":
		return ""
	case ".yml", ".yaml", ".toml", ".conf", ".ini":
		return ""
	case ".rs":
		return ""
	case ".c":
		return ""
	case ".cc", ".cpp", ".cxx":
		return ""
	case ".h", ".hpp":
		return ""
	default:
		return ""
	}
}

func cleanPath(p string) string {
	if abs, err := filepath.Abs(p); err == nil {
		return filepath.Clean(abs)
	}
	return filepath.Clean(p)
}

func displayName(it item, icons bool) string {
	n := it.name
	if it.isDir {
		n += "/"
	}
	if icons {
		n = iconFor(it) + " " + n
	}
	return n
}

func printLine(w io.Writer, s string) {
	fmt.Fprintf(w, "\r%s\x1b[K\n", s)
}

func render(w io.Writer, path string, opt options, cursor int, readErr error, items []item) int {
	lines := 1
	printLine(w, path)
	if readErr != nil {
		msg := readErr.Error()
		width := len([]rune(msg)) + 2
		printLine(w, "╭"+strings.Repeat("─", width)+"╮")
		printLine(w, "│ "+msg+" │")
		printLine(w, "╰"+strings.Repeat("─", width)+"╯")
		fmt.Fprint(w, "\x1b[80D")
		return 4
	}
	max := len(items)
	if max > 22 {
		max = 22
	}
	for i := 0; i < max; i++ {
		_ = cursor
		printLine(w, displayName(items[i], opt.icons))
		lines++
	}
	if opt.preview && cursor >= 0 && cursor < len(items) && !items[cursor].isDir {
		full := filepath.Join(path, items[cursor].name)
		if b, err := os.ReadFile(full); err == nil {
			fmt.Fprint(w, "\n")
			lines++
			for i, line := range strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n") {
				if i >= 10 {
					break
				}
				printLine(w, line)
				lines++
			}
		}
	}
	fmt.Fprint(w, "\x1b[80D")
	return lines
}

func clearLines(w io.Writer, n int) {
	if n <= 0 {
		return
	}
	fmt.Fprintf(w, "\x1b[%dA", n-1)
	for i := 0; i < n; i++ {
		fmt.Fprint(w, "\r\x1b[2K")
		if i < n-1 {
			fmt.Fprint(w, "\n")
		}
	}
	fmt.Fprintf(w, "\x1b[%dA\r", n-1)
}

func openEditor(path string) {
	editor := os.Getenv("WALK_EDITOR")
	if editor == "" {
		editor = os.Getenv("EDITOR")
	}
	if editor == "" {
		return
	}
	parts := strings.Fields(editor)
	if len(parts) == 0 {
		return
	}
	cmd := exec.Command(parts[0], append(parts[1:], path)...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	_ = cmd.Run()
}

func main() {
	opt := parseArgs(os.Args[1:])
	tty, err := os.OpenFile("/dev/tty", os.O_RDWR, 0)
	if err != nil {
		panic("could not open a new TTY: " + err.Error())
	}
	defer tty.Close()
	fd := tty.Fd()
	old, _ := makeRaw(fd)
	defer restore(fd, old)

	fmt.Fprint(tty, "\x1b]11;?\x1b\\\x1b[6n")
	fmt.Fprint(tty, "\x1b[?25l\x1b[?2004h")
	defer fmt.Fprint(tty, "\x1b[?2004l\x1b[?25h\x1b[?1002l\x1b[?1003l\x1b[?1006l")

	path := cleanPath(opt.path)
	cursor := 0
	items, readErr := readItems(path, opt)
	lines := render(tty, path, opt, cursor, readErr, items)
	buf := make([]byte, 32)

	for {
		n, err := tty.Read(buf)
		if err != nil || n == 0 {
			break
		}
		handled := false
		for i := 0; i < n; i++ {
			c := buf[i]
			if c == 3 {
				clearLines(tty, lines)
				fmt.Fprintln(tty)
				return
			}
			if c == 'q' || c == 27 {
				clearLines(tty, lines)
				out := path
				if readErr == nil && cursor >= 0 && cursor < len(items) && items[cursor].isDir {
					out = filepath.Join(path, items[cursor].name)
				}
				fmt.Fprintln(tty, out)
				return
			}
			if c == 27 && i+2 < n && buf[i+1] == '[' {
				switch buf[i+2] {
				case 'A':
					if cursor > 0 {
						cursor--
					}
				case 'B':
					if cursor < len(items)-1 {
						cursor++
					}
				}
				i += 2
				handled = true
				continue
			}
			switch c {
			case 'j', 'l':
				if cursor < len(items)-1 {
					cursor++
				}
				handled = true
			case 'k', 'h':
				if cursor > 0 {
					cursor--
				}
				handled = true
			case 127:
				path = filepath.Dir(path)
				cursor = 0
				items, readErr = readItems(path, opt)
				handled = true
			case '.', ' ':
				if c == '.' {
					opt.hideHidden = !opt.hideHidden
					cursor = 0
					items, readErr = readItems(path, opt)
				} else {
					opt.preview = !opt.preview
				}
				handled = true
			case '\r', '\n':
				if readErr == nil && cursor >= 0 && cursor < len(items) {
					full := filepath.Join(path, items[cursor].name)
					if items[cursor].isDir {
						path = cleanPath(full)
						cursor = 0
						items, readErr = readItems(path, opt)
					} else {
						openEditor(full)
					}
				}
				handled = true
			}
		}
		if handled {
			clearLines(tty, lines)
			lines = render(tty, path, opt, cursor, readErr, items)
		}
	}
}
