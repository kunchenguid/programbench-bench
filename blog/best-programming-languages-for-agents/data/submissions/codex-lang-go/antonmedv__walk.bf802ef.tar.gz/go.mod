module walkclone

go 1.21
