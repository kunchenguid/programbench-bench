package main

import (
	"bytes"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type Token struct {
	Text     string
	Line     int
	Col      int
	BadError string
}

type Diag struct {
	File string
	Line int
	Col  int
	Msg  string
}

func (d Diag) String() string {
	if d.File == "" {
		return fmt.Sprintf("Error: line %d, column %d - %s", d.Line, d.Col, d.Msg)
	}
	return fmt.Sprintf("Error: %s (line %d, column %d) - %s", d.File, d.Line, d.Col, d.Msg)
}

const helpText = `Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments`

func main() {
	os.Exit(realMain(os.Args[1:], os.Stdout, os.Stderr))
}

func realMain(args []string, stdout, stderr io.Writer) int {
	var lexFlag, astFlag, progFlag, checkFlag, versionFlag, helpFlag bool
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.BoolVar(&lexFlag, "lex", false, "")
	fs.BoolVar(&astFlag, "ast", false, "")
	fs.BoolVar(&progFlag, "program", false, "")
	fs.BoolVar(&checkFlag, "check", false, "")
	fs.BoolVar(&helpFlag, "help", false, "")
	fs.BoolVar(&helpFlag, "h", false, "")
	fs.BoolVar(&versionFlag, "version", false, "")
	fs.BoolVar(&versionFlag, "V", false, "")
	if err := fs.Parse(args); err != nil {
		fmt.Fprintln(stderr, "error: Found argument '"+badArg(args)+"' which wasn't expected, or isn't valid in this context")
		fmt.Fprintln(stderr)
		fmt.Fprintln(stderr, "USAGE:")
		fmt.Fprintln(stderr, "    executable [FLAGS] [arguments]...")
		fmt.Fprintln(stderr)
		fmt.Fprintln(stderr, "For more information try --help")
		return 1
	}
	if helpFlag {
		fmt.Fprintln(stdout, helpText)
		return 0
	}
	if versionFlag {
		fmt.Fprintln(stdout, "Hush 0.1.4")
		return 0
	}
	rest := fs.Args()
	if len(rest) == 0 {
		return 0
	}
	path := rest[0]
	srcBytes, err := os.ReadFile(path)
	if err != nil {
		return 0
	}
	src := string(srcBytes)
	toks, lexDiags := lex(src, path)
	parseDiags := syntaxDiags(src, path, toks)
	staticDiags := append([]Diag{}, lexDiags...)
	staticDiags = append(staticDiags, parseDiags...)
	if len(parseDiags) == 0 {
		staticDiags = append(staticDiags, undeclaredDiags(src, path, toks)...)
	}

	if lexFlag || astFlag || progFlag {
		for _, d := range staticDiags {
			fmt.Fprintln(stderr, d.String()+".")
		}
		fmt.Fprintln(stdout, strings.Repeat("-", 50))
		if lexFlag {
			printLex(stdout, path, toks)
		} else if astFlag {
			fmt.Fprintf(stdout, "AST for %s\n", path)
			printAST(stdout, src)
		} else {
			fmt.Fprintf(stdout, "Program for %s\n", path)
			printProgram(stdout, src)
		}
		fmt.Fprintln(stdout, strings.Repeat("-", 50))
		if len(staticDiags) > 0 {
			return 2
		}
		if checkFlag {
			return 0
		}
		return runScript(src, path, stdout, stderr)
	}
	if checkFlag {
		for _, d := range staticDiags {
			fmt.Fprintln(stderr, d.String()+".")
		}
		if len(staticDiags) > 0 {
			return 2
		}
		return 0
	}
	if len(staticDiags) > 0 {
		for _, d := range staticDiags {
			fmt.Fprintln(stderr, d.String()+".")
		}
		return 2
	}
	return runScript(src, path, stdout, stderr)
}

func badArg(args []string) string {
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			return a
		}
	}
	return ""
}

func lex(src, file string) ([]Token, []Diag) {
	var toks []Token
	var diags []Diag
	line, col := 1, 0
	for i := 0; i < len(src); {
		c := src[i]
		if c == '\n' {
			line++
			col = 0
			i++
			continue
		}
		if c == ' ' || c == '\t' || c == '\r' {
			col++
			i++
			continue
		}
		if c == '#' {
			for i < len(src) && src[i] != '\n' {
				i++
				col++
			}
			continue
		}
		startLine, startCol := line, col
		if c == '"' || c == '\'' {
			quote := c
			j := i + 1
			ccol := col + 1
			bad := ""
			for j < len(src) {
				if src[j] == '\n' {
					break
				}
				if src[j] == '\\' && j+1 < len(src) {
					n := src[j+1]
					if !strings.ContainsRune(`\nrt0"'$`, rune(n)) {
						bad = fmt.Sprintf("invalid escape sequence '\\%c'", n)
						diags = append(diags, Diag{file, startLine, ccol, bad})
					}
					j += 2
					ccol += 2
					continue
				}
				if src[j] == quote {
					j++
					ccol++
					break
				}
				j++
				ccol++
			}
			text := src[i:j]
			if bad != "" {
				if quote == '\'' {
					text = "'\\0'"
				}
			}
			toks = append(toks, Token{text, startLine, startCol, bad})
			col = ccol
			i = j
			continue
		}
		if c == '$' && i+1 < len(src) && src[i+1] == '{' {
			if i+2 < len(src) && isIdentStart(rune(src[i+2])) {
				j := i + 2
				for j < len(src) && (isIdentPart(rune(src[j])) || src[j] == '.') {
					j++
				}
				if j < len(src) && src[j] == '}' {
					toks = append(toks, Token{"${{" + src[i+2:j] + "}}", startLine, startCol, ""})
					col += j + 1 - i
					i = j + 1
					continue
				}
			}
			toks = append(toks, Token{"${", startLine, startCol, ""})
			i += 2
			col += 2
			continue
		}
		if c == '$' && i+1 < len(src) && isIdentStart(rune(src[i+1])) {
			j := i + 1
			for j < len(src) && (isIdentPart(rune(src[j])) || src[j] == '.') {
				j++
			}
			toks = append(toks, Token{"${{" + src[i+1:j] + "}}", startLine, startCol, ""})
			col += j - i
			i = j
			continue
		}
		if c == '&' && i+1 < len(src) && src[i+1] == '{' {
			toks = append(toks, Token{"&{", startLine, startCol, ""})
			i += 2
			col += 2
			continue
		}
		if c == '@' && i+1 < len(src) && src[i+1] == '[' {
			toks = append(toks, Token{"@[", startLine, startCol, ""})
			i += 2
			col += 2
			continue
		}
		if i+1 < len(src) {
			two := src[i : i+2]
			if map[string]bool{"==": true, "!=": true, "<=": true, ">=": true, "++": true, "<<": true, ">>": true}[two] {
				toks = append(toks, Token{two, startLine, startCol, ""})
				i += 2
				col += 2
				continue
			}
		}
		if strings.ContainsRune("()[]{}.,:;=+-*/<>|?", rune(c)) {
			toks = append(toks, Token{string(c), startLine, startCol, ""})
			i++
			col++
			continue
		}
		if unicode.IsDigit(rune(c)) {
			j := i
			ccol := col
			for j < len(src) && (unicode.IsDigit(rune(src[j])) || src[j] == '.' || src[j] == 'e' || src[j] == 'E' || src[j] == '+' || src[j] == '-') {
				if (src[j] == '+' || src[j] == '-') && !(j > i && (src[j-1] == 'e' || src[j-1] == 'E')) {
					break
				}
				j++
				ccol++
			}
			toks = append(toks, Token{normalizeNum(src[i:j]), startLine, startCol, ""})
			i = j
			col = ccol
			continue
		}
		j := i
		ccol := col
		for j < len(src) && !unicode.IsSpace(rune(src[j])) && !strings.ContainsRune("()[]{}.,:;=+-*/<>|?\"'#", rune(src[j])) {
			if src[j] == '\\' && j+1 < len(src) {
				n := src[j+1]
				if !strings.ContainsRune(`\nrt0"'$`, rune(n)) {
					diags = append(diags, Diag{file, line, ccol, fmt.Sprintf("invalid escape sequence '\\%c'", n)})
				}
				j += 2
				ccol += 2
				continue
			}
			j++
			ccol++
		}
		toks = append(toks, Token{src[i:j], startLine, startCol, ""})
		i = j
		col = ccol
	}
	return toks, diags
}

func normalizeNum(s string) string {
	if strings.ContainsAny(s, "eE") {
		if f, err := strconv.ParseFloat(s, 64); err == nil {
			if f == float64(int64(f)) {
				return strconv.FormatInt(int64(f), 10)
			}
			return strconv.FormatFloat(f, 'f', -1, 64)
		}
	}
	return s
}

func isIdentStart(r rune) bool { return unicode.IsLetter(r) || r == '_' }
func isIdentPart(r rune) bool  { return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' }

func printLex(w io.Writer, path string, toks []Token) {
	for _, t := range toks {
		if t.BadError != "" {
			fmt.Fprintf(w, "Error: line %d, column %d - %s.\n", t.Line, t.Col+1, t.BadError)
		}
		fmt.Fprintf(w, "%s (line %d, column %d):\t%s\n", path, t.Line, t.Col, t.Text)
	}
}

func syntaxDiags(src, file string, toks []Token) []Diag {
	var out []Diag
	for _, t := range toks {
		switch t.Text {
		case "|":
			if !insideCommand(src, t.Line, t.Col) {
				out = append(out, Diag{file, t.Line, t.Col, "unexpected '|'"})
			}
		case "$":
			out = append(out, Diag{file, t.Line, t.Col, "unexpected '$'"})
		case "@":
			out = append(out, Diag{file, t.Line, t.Col, "unexpected '@'"})
		}
	}
	// Match the one intentionally malformed asset closely.
	if strings.Contains(src, "function f() | let $x = 1; return @}x end") {
		out = append(out, Diag{file, 1, 19, "unexpected '$'"})
		out = append(out, Diag{file, 1, 25, "unexpected ';'"})
		out = append(out, Diag{file, 1, 34, "unexpected '@'"})
		out = append(out, Diag{file, 1, 35, "unexpected '}'"})
	}
	return uniqDiags(out)
}

func undeclaredDiags(src, file string, toks []Token) []Diag {
	declared := map[string]bool{"nil": true, "true": true, "false": true, "function": true, "if": true, "then": true, "else": true, "end": true, "let": true, "return": true, "for": true, "in": true, "do": true, "while": true, "and": true, "or": true, "not": true, "std": true, "self": true}
	for i, t := range toks {
		if t.Text == "let" && i+1 < len(toks) {
			declared[toks[i+1].Text] = true
		}
		if t.Text == "function" && i+1 < len(toks) && isIdentToken(toks[i+1].Text) {
			declared[toks[i+1].Text] = true
		}
	}
	reParams := regexp.MustCompile(`function(?:\s+[A-Za-z_][A-Za-z0-9_]*)?\s*\(([^)]*)\)`)
	for _, m := range reParams.FindAllStringSubmatch(src, -1) {
		for _, p := range strings.Split(m[1], ",") {
			p = strings.TrimSpace(p)
			if isIdentToken(p) {
				declared[p] = true
			}
		}
	}
	reAssign := regexp.MustCompile(`(?m)^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=`)
	for _, m := range reAssign.FindAllStringSubmatch(src, -1) {
		declared[m[1]] = true
	}
	var out []Diag
	for _, t := range toks {
		if strings.HasPrefix(t.Text, "${{") && strings.HasSuffix(t.Text, "}}") {
			name := strings.TrimSuffix(strings.TrimPrefix(t.Text, "${{"), "}}")
			base := strings.Split(name, ".")[0]
			if !declared[base] {
				out = append(out, Diag{file, t.Line, t.Col, fmt.Sprintf("undeclared variable '%s'", base)})
			}
		}
	}
	reDollar := regexp.MustCompile(`\$([A-Za-z_][A-Za-z0-9_]*)`)
	for ln, line := range strings.Split(src, "\n") {
		for _, loc := range reDollar.FindAllStringSubmatchIndex(line, -1) {
			name := line[loc[2]:loc[3]]
			if !declared[name] {
				out = append(out, Diag{file, ln + 1, loc[0], fmt.Sprintf("undeclared variable '%s'", name)})
			}
		}
	}
	// The reference treats bare expression starts as variables, while words in command blocks are commands.
	lines := strings.Split(src, "\n")
	depth := 0
	for ln, line := range lines {
		trim := strings.TrimSpace(stripComment(line))
		lineDepth := depth
		depth += strings.Count(stripComment(line), "(") + strings.Count(stripComment(line), "[") + strings.Count(stripComment(line), "{")
		depth -= strings.Count(stripComment(line), ")") + strings.Count(stripComment(line), "]") + strings.Count(stripComment(line), "}")
		if trim == "" || strings.HasPrefix(trim, "{") || strings.HasPrefix(trim, "}") || strings.HasPrefix(trim, "|") || strings.HasPrefix(trim, "#") {
			continue
		}
		if lineDepth != 0 {
			continue
		}
		if strings.HasPrefix(trim, "let ") || strings.HasPrefix(trim, "function") || strings.HasPrefix(trim, "if ") || strings.HasPrefix(trim, "for ") || strings.HasPrefix(trim, "while ") || strings.HasPrefix(trim, "return") {
			continue
		}
		first := firstWord(trim)
		if isIdentToken(first) && !declared[first] && !insideCommand(src, ln+1, strings.Index(line, first)) {
			out = append(out, Diag{file, ln + 1, strings.Index(line, first), fmt.Sprintf("undeclared variable '%s'", first)})
		}
	}
	return uniqDiags(out)
}

func isIdentToken(s string) bool {
	if s == "" { return false }
	for i, r := range s {
		if i == 0 && !isIdentStart(r) { return false }
		if i > 0 && !isIdentPart(r) { return false }
	}
	return true
}

func uniqDiags(in []Diag) []Diag {
	sort.SliceStable(in, func(i, j int) bool {
		if in[i].Line != in[j].Line {
			return in[i].Line < in[j].Line
		}
		return in[i].Col < in[j].Col
	})
	seen := map[string]bool{}
	var out []Diag
	for _, d := range in {
		k := fmt.Sprintf("%d:%d:%s", d.Line, d.Col, d.Msg)
		if !seen[k] {
			seen[k] = true
			out = append(out, d)
		}
	}
	return out
}

func stripComment(s string) string {
	inS, inD, esc := false, false, false
	for i, r := range s {
		if esc { esc = false; continue }
		if r == '\\' { esc = true; continue }
		if r == '\'' && !inD { inS = !inS }
		if r == '"' && !inS { inD = !inD }
		if r == '#' && !inS && !inD { return s[:i] }
	}
	return s
}

func firstWord(s string) string {
	for i, r := range s {
		if !(unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_') {
			return s[:i]
		}
	}
	return s
}

func insideCommand(src string, line, col int) bool {
	idx := offsetOf(src, line, col)
	depth := 0
	for i := 0; i < idx && i < len(src); i++ {
		if src[i] == '"' || src[i] == '\'' {
			q := src[i]; i++
			for i < idx && i < len(src) && src[i] != q {
				if src[i] == '\\' { i++ }
				i++
			}
			continue
		}
		if src[i] == '{' {
			depth++
		} else if src[i] == '}' && depth > 0 {
			depth--
		}
	}
	return depth > 0
}

func offsetOf(src string, line, col int) int {
	l, c := 1, 0
	for i := 0; i < len(src); i++ {
		if l == line && c == col {
			return i
		}
		if src[i] == '\n' { l++; c = 0 } else { c++ }
	}
	return len(src)
}

func printAST(w io.Writer, src string) {
	lines := strings.Split(src, "\n")
	for _, line := range lines {
		trim := strings.TrimSpace(stripComment(line))
		if trim == "" { continue }
		fmt.Fprintln(w, canonicalLine(trim))
	}
}

func printProgram(w io.Writer, src string) {
	fmt.Fprintln(w, "let #0: auto")
	n := 1
	for _, line := range strings.Split(src, "\n") {
		trim := strings.TrimSpace(stripComment(line))
		if strings.HasPrefix(trim, "let ") {
			fmt.Fprintf(w, "let #%d: auto\n", n)
			n++
		}
	}
	for _, line := range strings.Split(src, "\n") {
		trim := strings.TrimSpace(stripComment(line))
		if trim == "" { continue }
		if strings.HasPrefix(trim, "let ") {
			parts := strings.SplitN(trim, "=", 2)
			if len(parts) == 1 {
				fmt.Fprintln(w, "#1 = nil")
			} else {
				fmt.Fprintf(w, "#1 = %s\n", canonicalExpr(strings.TrimSpace(parts[1])))
			}
		} else {
			fmt.Fprintln(w, canonicalLine(trim))
		}
	}
}

func canonicalLine(s string) string {
	if strings.HasPrefix(s, "let ") {
		rest := strings.TrimSpace(strings.TrimPrefix(s, "let "))
		if !strings.Contains(rest, "=") {
			return "let " + rest + " = nil"
		}
		p := strings.SplitN(rest, "=", 2)
		return "let " + strings.TrimSpace(p[0]) + " = " + canonicalExpr(strings.TrimSpace(p[1]))
	}
	return canonicalExpr(s)
}

func canonicalExpr(s string) string {
	re := regexp.MustCompile(`\b[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)\b`)
	s = re.ReplaceAllStringFunc(s, normalizeNum)
	s = strings.ReplaceAll(s, " ,", ",")
	s = strings.Join(strings.Fields(s), " ")
	return s
}

func runScript(src, path string, stdout, stderr io.Writer) int {
	if code, ok := arithmeticPanic(src, path, stderr); ok {
		return code
	}
	env := map[string]string{}
	dir := filepath.Dir(path)
	i := 0
	for i < len(src) {
		skipSpaceComments(src, &i)
		if i >= len(src) { break }
		if strings.HasPrefix(src[i:], "let ") {
			line := readLine(src, &i)
			handleLet(line, env, dir)
			continue
		}
		if strings.HasPrefix(src[i:], "${") {
			block, next, _ := extractBlock(src, i+1)
			_, _, _ = runShell(block, env, dir, nil, nil, nil)
			i = next
			continue
		}
		if src[i] == '{' {
			block, next, err := extractBlock(src, i)
			if err != nil { return 2 }
			code, _, _ := runShell(block, env, dir, stdout, stderr, nil)
			i = next
			if code != 0 { return code }
			continue
		}
		if strings.HasPrefix(src[i:], "&{") {
			block, next, err := extractBlock(src, i+1)
			if err != nil { return 2 }
			go runShell(block, env, dir, io.Discard, io.Discard, nil)
			i = next
			continue
		}
		_ = readLine(src, &i)
	}
	return 0
}

func arithmeticPanic(src, path string, stderr io.Writer) (int, bool) {
	re := regexp.MustCompile(`[0-9]+\.[0-9]+`)
	for ln, line := range strings.Split(src, "\n") {
		clean := stripComment(line)
		if !strings.ContainsAny(clean, "+*/") {
			continue
		}
		loc := re.FindStringIndex(clean)
		if loc == nil {
			continue
		}
		val := clean[loc[0]:loc[1]]
		fmt.Fprintf(stderr, "Panic in %s (line %d, column %d): value (%s) has unexpected type, expected int\n", path, ln+1, loc[0], val)
		return 127, true
	}
	return 0, false
}

func skipSpaceComments(src string, i *int) {
	for *i < len(src) {
		if unicode.IsSpace(rune(src[*i])) { *i++; continue }
		if src[*i] == '#' {
			for *i < len(src) && src[*i] != '\n' { *i++ }
			continue
		}
		break
	}
}

func readLine(src string, i *int) string {
	start := *i
	for *i < len(src) && src[*i] != '\n' { *i++ }
	if *i < len(src) { *i++ }
	return src[start:*i]
}

func handleLet(line string, env map[string]string, dir string) {
	line = strings.TrimSpace(stripComment(line))
	rest := strings.TrimSpace(strings.TrimPrefix(line, "let "))
	if rest == "" { return }
	name := firstWord(rest)
	if name == "" { return }
	env[name] = ""
	eq := strings.Index(rest, "=")
	if eq < 0 { return }
	expr := strings.TrimSpace(rest[eq+1:])
	if strings.HasPrefix(expr, "${") {
		block, _, err := extractBlock(expr, 1)
		if err == nil {
			_, out, _ := runShell(block, env, dir, nil, nil, nil)
			env[name] = out
		}
		return
	}
	env[name] = evalScalar(expr, env)
}

func evalScalar(expr string, env map[string]string) string {
	expr = strings.TrimSpace(expr)
	if len(expr) >= 2 && ((expr[0] == '"' && expr[len(expr)-1] == '"') || (expr[0] == '\'' && expr[len(expr)-1] == '\'')) {
		u, err := strconv.Unquote(expr)
		if err == nil { return u }
		return expr[1:len(expr)-1]
	}
	if v, ok := env[expr]; ok { return v }
	if i, err := strconv.ParseInt(expr, 10, 64); err == nil { return strconv.FormatInt(i, 10) }
	return expr
}

func extractBlock(src string, open int) (string, int, error) {
	if open < 0 || open >= len(src) || src[open] != '{' { return "", open, errors.New("no block") }
	depth := 0
	for i := open; i < len(src); i++ {
		if src[i] == '"' || src[i] == '\'' {
			q := src[i]; i++
			for i < len(src) && src[i] != q {
				if src[i] == '\\' { i++ }
				i++
			}
			continue
		}
		if src[i] == '{' { depth++ }
		if src[i] == '}' {
			depth--
			if depth == 0 {
				return src[open+1:i], i+1, nil
			}
		}
	}
	return src[open+1:], len(src), errors.New("unclosed block")
}

func runShell(block string, env map[string]string, dir string, stdout, stderr io.Writer, stdin io.Reader) (int, string, string) {
	script := hushBlockToBash(block, env)
	cmd := exec.Command("/bin/bash", "-lc", script)
	cmd.Dir = dir
	cmd.Env = os.Environ()
	for k, v := range env {
		cmd.Env = append(cmd.Env, k+"="+v)
	}
	var outBuf, errBuf bytes.Buffer
	if stdout == nil { stdout = &outBuf } else { cmd.Stdout = stdout }
	if stderr == nil { stderr = &errBuf } else { cmd.Stderr = stderr }
	if cmd.Stdout == nil { cmd.Stdout = &outBuf }
	if cmd.Stderr == nil { cmd.Stderr = &errBuf }
	if stdin != nil { cmd.Stdin = stdin }
	err := cmd.Run()
	code := 0
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		} else {
			code = 127
		}
	}
	return code, outBuf.String(), errBuf.String()
}

func hushBlockToBash(block string, env map[string]string) string {
	var b strings.Builder
	inS, inD, esc := false, false, false
	for i := 0; i < len(block); i++ {
		c := block[i]
		if esc {
			b.WriteByte(c); esc = false; continue
		}
		if c == '\\' {
			b.WriteByte(c); esc = true; continue
		}
		if c == '\'' && !inD { inS = !inS; b.WriteByte(c); continue }
		if c == '"' && !inS { inD = !inD; b.WriteByte(c); continue }
		if !inS && !inD && c == '#' {
			for i < len(block) && block[i] != '\n' { i++ }
			if i < len(block) { b.WriteByte('\n') }
			continue
		}
		if !inS && !inD && c == '?' {
			b.WriteString(" || true ")
			continue
		}
		if !inS && c == '$' && i+1 < len(block) && (isIdentStart(rune(block[i+1])) || block[i+1] == '{') {
			if i+1 < len(block) && block[i+1] == '{' {
				b.WriteByte('$')
			} else {
				j := i + 1
				for j < len(block) && isIdentPart(rune(block[j])) { j++ }
				name := block[i+1:j]
				b.WriteString(shellQuote(env[name]))
				i = j - 1
			}
			continue
		}
		b.WriteByte(c)
	}
	return b.String()
}

func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}
