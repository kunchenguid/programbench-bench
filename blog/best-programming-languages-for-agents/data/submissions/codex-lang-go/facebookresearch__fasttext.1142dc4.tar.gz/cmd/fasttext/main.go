package main

import (
	"bufio"
	"crypto/sha1"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type Model struct {
	Magic      string                    `json:"magic"`
	Model      string                    `json:"model"`
	Dim        int                       `json:"dim"`
	Label      string                    `json:"label"`
	Args       map[string]string         `json:"args"`
	Labels     []string                  `json:"labels,omitempty"`
	Vocab      map[string]int            `json:"vocab"`
	LabelCount map[string]int            `json:"label_count,omitempty"`
	WordLabel  map[string]map[string]int `json:"word_label,omitempty"`
	LabelWords map[string]int            `json:"label_words,omitempty"`
	Vectors    map[string][]float64      `json:"vectors,omitempty"`
}

type optionSpec struct {
	def string
}

var commands = []struct{ name, desc string }{
	{"supervised", "train a supervised classifier"},
	{"quantize", "quantize a model to reduce the memory usage"},
	{"test", "evaluate a supervised classifier"},
	{"test-label", "print labels with precision and recall scores"},
	{"predict", "predict most likely labels"},
	{"predict-prob", "predict most likely labels with probabilities"},
	{"skipgram", "train a skipgram model"},
	{"cbow", "train a cbow model"},
	{"print-word-vectors", "print word vectors given a trained model"},
	{"print-sentence-vectors", "print sentence vectors given a trained model"},
	{"print-ngrams", "print ngrams given a trained model and word"},
	{"nn", "query for nearest neighbors"},
	{"analogies", "query for analogies"},
	{"dump", "dump arguments,dictionary,input/output vectors"},
}

func main() {
	if len(os.Args) < 2 || os.Args[1] == "--help" || os.Args[1] == "-h" {
		printMainUsage()
		return
	}
	cmd := os.Args[1]
	args := os.Args[2:]
	switch cmd {
	case "supervised", "skipgram", "cbow":
		train(cmd, args)
	case "quantize":
		quantize(args)
	case "test":
		usageIf(len(args) < 2, "test")
		test(args, false)
	case "test-label":
		usageIf(len(args) < 2, "test-label")
		test(args, true)
	case "predict":
		usageIf(len(args) < 2, "predict")
		predict(args, false)
	case "predict-prob":
		usageIf(len(args) < 2, "predict")
		predict(args, true)
	case "print-word-vectors":
		usageIf(len(args) != 1, "print-word-vectors")
		printWordVectors(args[0])
	case "print-sentence-vectors":
		usageIf(len(args) != 1, "print-sentence-vectors")
		printSentenceVectors(args[0])
	case "print-ngrams":
		usageIf(len(args) != 2, "print-ngrams")
		printNgrams(args[0], args[1])
	case "nn":
		usageIf(len(args) < 1, "nn")
		nn(args)
	case "analogies":
		usageIf(len(args) < 1, "analogies")
		analogies(args)
	case "dump":
		usageIf(len(args) != 2, "dump")
		dump(args[0], args[1])
	default:
		printMainUsage()
	}
}

func printMainUsage() {
	fmt.Println("usage: fasttext <command> <args>")
	fmt.Println()
	fmt.Println("The commands supported by fasttext are:")
	fmt.Println()
	for _, c := range commands {
		fmt.Printf("  %-23s %s\n", c.name, c.desc)
	}
}

func usageIf(cond bool, name string) {
	if cond {
		printUsage(name)
		os.Exit(0)
	}
}

func printUsage(name string) {
	switch name {
	case "test":
		fmt.Println("usage: fasttext test <model> <test-data> [<k>] [<th>]\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <test-data>  test data filename (if -, read from stdin)")
		fmt.Println("  <k>          (optional; 1 by default) predict top k labels")
		fmt.Println("  <th>         (optional; 0.0 by default) probability threshold")
	case "test-label":
		fmt.Println("usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <test-data>  test data filename")
		fmt.Println("  <k>          (optional; 1 by default) predict top k labels")
		fmt.Println("  <th>         (optional; 0.0 by default) probability threshold")
	case "predict":
		fmt.Println("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <test-data>  test data filename (if -, read from stdin)")
		fmt.Println("  <k>          (optional; 1 by default) predict top k labels")
		fmt.Println("  <th>         (optional; 0.0 by default) probability threshold")
	case "print-word-vectors":
		fmt.Println("usage: fasttext print-word-vectors <model>\n")
		fmt.Println("  <model>      model filename")
	case "print-sentence-vectors":
		fmt.Println("usage: fasttext print-sentence-vectors <model>\n")
		fmt.Println("  <model>      model filename")
	case "print-ngrams":
		fmt.Println("usage: fasttext print-ngrams <model> <word>\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <word>       word to print")
	case "nn":
		fmt.Println("usage: fasttext nn <model> <k>\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <k>          (optional; 10 by default) predict top k labels")
	case "analogies":
		fmt.Println("usage: fasttext analogies <model> <k>\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <k>          (optional; 10 by default) predict top k labels")
	case "dump":
		fmt.Println("usage: fasttext dump <model> <option>\n")
		fmt.Println("  <model>      model filename")
		fmt.Println("  <option>     option from args,dict,input,output")
	}
}

func train(kind string, argv []string) {
	args, errMsg := parseTrainArgs(kind, argv)
	if errMsg != "" {
		fmt.Println(errMsg)
		fmt.Println()
		printTrainHelp(kind, args)
		return
	}
	input, output := args["-input"], args["-output"]
	if input == "" || output == "" {
		fmt.Println("Empty input or output path.")
		fmt.Println()
		printTrainHelp(kind, args)
		return
	}
	dim := atoi(args["-dim"], 100)
	labelPrefix := args["-label"]
	if labelPrefix == "" {
		labelPrefix = "__label__"
	}
	var m *Model
	var err error
	if kind == "supervised" {
		m, err = trainSupervised(input, labelPrefix, dim, args)
	} else {
		m, err = trainVectors(input, kind, dim, args)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := saveModel(output+".bin", m); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if kind != "supervised" {
		if err := saveVec(output+".vec", m); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
}

func quantize(argv []string) {
	args, errMsg := parseTrainArgs("quantize", argv)
	if errMsg != "" || args["-input"] == "" || args["-output"] == "" {
		if errMsg != "" {
			fmt.Println(errMsg)
		} else {
			fmt.Println("usage: fasttext quantize <args>")
		}
		fmt.Println()
		printTrainHelp("quantize", args)
		return
	}
	m, err := loadModel(args["-input"])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	m.Args = args
	if err := saveModel(args["-output"]+".ftz", m); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parseTrainArgs(kind string, argv []string) (map[string]string, string) {
	args := defaultArgs(kind)
	valid := map[string]bool{}
	for k := range args {
		valid[k] = true
	}
	for i := 0; i < len(argv); i++ {
		a := argv[i]
		if !strings.HasPrefix(a, "-") || !valid[a] {
			return args, "Unknown argument: " + a
		}
		if i+1 >= len(argv) || strings.HasPrefix(argv[i+1], "-") {
			return args, a + " is missing an argument"
		}
		args[a] = argv[i+1]
		i++
	}
	return args, ""
}

func defaultArgs(kind string) map[string]string {
	supervised := kind == "supervised"
	minCount, minn, maxn, lr, loss := "5", "3", "6", "0.05", "ns"
	if supervised {
		minCount, minn, maxn, lr, loss = "1", "0", "0", "0.1", "softmax"
	}
	return map[string]string{
		"-input": "", "-output": "", "-verbose": "2", "-minCount": minCount,
		"-minCountLabel": "0", "-wordNgrams": "1", "-bucket": "2000000",
		"-minn": minn, "-maxn": maxn, "-t": "0.0001", "-label": "__label__",
		"-lr": lr, "-lrUpdateRate": "100", "-dim": "100", "-ws": "5",
		"-epoch": "5", "-neg": "5", "-loss": loss, "-thread": "12",
		"-pretrainedVectors": "", "-saveOutput": "false", "-seed": "0",
		"-autotune-validation": "", "-autotune-metric": "f1",
		"-autotune-predictions": "1", "-autotune-duration": "300",
		"-autotune-modelsize": "", "-cutoff": "0", "-retrain": "false",
		"-qnorm": "false", "-qout": "false", "-dsub": "2",
	}
}

func printTrainHelp(kind string, args map[string]string) {
	if args == nil {
		args = defaultArgs(kind)
	}
	fmt.Println("The following arguments are mandatory:")
	fmt.Println("  -input              training file path")
	fmt.Println("  -output             output file path")
	fmt.Println()
	fmt.Println("The following arguments are optional:")
	fmt.Printf("  -verbose            verbosity level [%s]\n", args["-verbose"])
	fmt.Println()
	fmt.Println("The following arguments for the dictionary are optional:")
	fmt.Printf("  -minCount           minimal number of word occurences [%s]\n", args["-minCount"])
	fmt.Printf("  -minCountLabel      minimal number of label occurences [%s]\n", args["-minCountLabel"])
	fmt.Printf("  -wordNgrams         max length of word ngram [%s]\n", args["-wordNgrams"])
	fmt.Printf("  -bucket             number of buckets [%s]\n", args["-bucket"])
	fmt.Printf("  -minn               min length of char ngram [%s]\n", args["-minn"])
	fmt.Printf("  -maxn               max length of char ngram [%s]\n", args["-maxn"])
	fmt.Printf("  -t                  sampling threshold [%s]\n", args["-t"])
	fmt.Printf("  -label              labels prefix [%s]\n", args["-label"])
	fmt.Println()
	fmt.Println("The following arguments for training are optional:")
	fmt.Printf("  -lr                 learning rate [%s]\n", args["-lr"])
	fmt.Printf("  -lrUpdateRate       change the rate of updates for the learning rate [%s]\n", args["-lrUpdateRate"])
	fmt.Printf("  -dim                size of word vectors [%s]\n", args["-dim"])
	fmt.Printf("  -ws                 size of the context window [%s]\n", args["-ws"])
	fmt.Printf("  -epoch              number of epochs [%s]\n", args["-epoch"])
	fmt.Printf("  -neg                number of negatives sampled [%s]\n", args["-neg"])
	fmt.Printf("  -loss               loss function {ns, hs, softmax, one-vs-all} [%s]\n", args["-loss"])
	fmt.Printf("  -thread             number of threads (set to 1 to ensure reproducible results) [%s]\n", args["-thread"])
	fmt.Printf("  -pretrainedVectors  pretrained word vectors for supervised learning [%s]\n", args["-pretrainedVectors"])
	fmt.Printf("  -saveOutput         whether output params should be saved [%s]\n", args["-saveOutput"])
	fmt.Printf("  -seed               random generator seed  [%s]\n", args["-seed"])
	fmt.Println()
	fmt.Println("The following arguments are for autotune:")
	fmt.Println("  -autotune-validation            validation file to be used for evaluation")
	fmt.Printf("  -autotune-metric                metric objective {f1, f1:labelname} [%s]\n", args["-autotune-metric"])
	fmt.Printf("  -autotune-predictions           number of predictions used for evaluation  [%s]\n", args["-autotune-predictions"])
	fmt.Printf("  -autotune-duration              maximum duration in seconds [%s]\n", args["-autotune-duration"])
	fmt.Printf("  -autotune-modelsize             constraint model file size [%s] (empty = do not quantize)\n", args["-autotune-modelsize"])
	fmt.Println()
	fmt.Println("The following arguments for quantization are optional:")
	fmt.Printf("  -cutoff             number of words and ngrams to retain [%s]\n", args["-cutoff"])
	fmt.Printf("  -retrain            whether embeddings are finetuned if a cutoff is applied [%s]\n", args["-retrain"])
	fmt.Printf("  -qnorm              whether the norm is quantized separately [%s]\n", args["-qnorm"])
	fmt.Printf("  -qout               whether the classifier is quantized [%s]\n", args["-qout"])
	fmt.Printf("  -dsub               size of each sub-vector [%s]\n", args["-dsub"])
}

func trainSupervised(path, labelPrefix string, dim int, args map[string]string) (*Model, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	m := &Model{Magic: "fasttext-clone-v1", Model: "supervised", Dim: dim, Label: labelPrefix, Args: args, Vocab: map[string]int{}, LabelCount: map[string]int{}, WordLabel: map[string]map[string]int{}, LabelWords: map[string]int{}}
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024), 1024*1024*16)
	for sc.Scan() {
		labels, words := splitLabeled(sc.Text(), labelPrefix)
		for _, l := range labels {
			if _, ok := m.LabelCount[l]; !ok {
				m.Labels = append(m.Labels, l)
			}
			m.LabelCount[l]++
			for _, w := range words {
				m.Vocab[w]++
				if m.WordLabel[w] == nil {
					m.WordLabel[w] = map[string]int{}
				}
				m.WordLabel[w][l]++
				m.LabelWords[l]++
			}
		}
	}
	sort.Strings(m.Labels)
	return m, sc.Err()
}

func trainVectors(path, kind string, dim int, args map[string]string) (*Model, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	counts := map[string]int{}
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1024), 1024*1024*16)
	for sc.Scan() {
		for _, w := range tokenize(sc.Text()) {
			counts[w]++
		}
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	minCount := atoi(args["-minCount"], 5)
	m := &Model{Magic: "fasttext-clone-v1", Model: kind, Dim: dim, Label: args["-label"], Args: args, Vocab: map[string]int{}, Vectors: map[string][]float64{}}
	for w, c := range counts {
		if c >= minCount {
			m.Vocab[w] = c
			m.Vectors[w] = vectorFor(w, dim)
		}
	}
	return m, nil
}

func splitLabeled(line, prefix string) ([]string, []string) {
	var labels, words []string
	for _, tok := range strings.Fields(line) {
		if strings.HasPrefix(tok, prefix) {
			labels = append(labels, tok)
		} else {
			words = append(words, normalize(tok))
		}
	}
	return labels, filterEmpty(words)
}

func tokenize(line string) []string {
	fs := strings.FieldsFunc(line, func(r rune) bool {
		return unicode.IsSpace(r)
	})
	out := make([]string, 0, len(fs))
	for _, f := range fs {
		if n := normalize(f); n != "" {
			out = append(out, n)
		}
	}
	return out
}

func normalize(s string) string {
	return strings.ToLower(strings.TrimFunc(s, func(r rune) bool {
		return unicode.IsPunct(r) || unicode.IsSymbol(r)
	}))
}

func filterEmpty(in []string) []string {
	out := in[:0]
	for _, s := range in {
		if s != "" {
			out = append(out, s)
		}
	}
	return out
}

type pred struct {
	label string
	score float64
	prob  float64
}

func (m *Model) predictions(line string, k int, th float64) []pred {
	if len(m.Labels) == 0 {
		return nil
	}
	_, words := splitLabeled(line, m.Label)
	vocabSize := float64(len(m.Vocab) + 1)
	totalDocs := 0
	for _, c := range m.LabelCount {
		totalDocs += c
	}
	raw := make([]pred, 0, len(m.Labels))
	maxScore := math.Inf(-1)
	for _, l := range m.Labels {
		score := math.Log(float64(m.LabelCount[l]+1) / float64(totalDocs+len(m.Labels)))
		den := float64(m.LabelWords[l]) + vocabSize
		for _, w := range words {
			c := 0
			if m.WordLabel[w] != nil {
				c = m.WordLabel[w][l]
			}
			score += math.Log(float64(c+1) / den)
		}
		raw = append(raw, pred{label: l, score: score})
		if score > maxScore {
			maxScore = score
		}
	}
	sum := 0.0
	for i := range raw {
		raw[i].prob = math.Exp(raw[i].score - maxScore)
		sum += raw[i].prob
	}
	for i := range raw {
		raw[i].prob /= sum
	}
	sort.Slice(raw, func(i, j int) bool {
		if math.Abs(raw[i].prob-raw[j].prob) > 1e-15 {
			return raw[i].prob > raw[j].prob
		}
		return raw[i].label < raw[j].label
	})
	out := raw[:0]
	for _, p := range raw {
		if p.prob >= th {
			out = append(out, p)
			if len(out) == k {
				break
			}
		}
	}
	return out
}

func predict(argv []string, withProb bool) {
	m, err := loadModel(argv[0])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	k := 1
	if len(argv) > 2 {
		k = atoi(argv[2], 1)
	}
	th := 0.0
	if len(argv) > 3 {
		th, _ = strconv.ParseFloat(argv[3], 64)
	}
	r, closeFn, err := openInput(argv[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer closeFn()
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 1024), 1024*1024*16)
	for sc.Scan() {
		ps := m.predictions(sc.Text(), k, th)
		parts := make([]string, 0, len(ps)*2)
		for _, p := range ps {
			parts = append(parts, p.label)
			if withProb {
				parts = append(parts, fmtProb(p.prob))
			}
		}
		fmt.Println(strings.Join(parts, " "))
	}
}

func test(argv []string, perLabel bool) {
	m, err := loadModel(argv[0])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	k := 1
	if len(argv) > 2 {
		k = atoi(argv[2], 1)
	}
	th := 0.0
	if len(argv) > 3 {
		th, _ = strconv.ParseFloat(argv[3], 64)
	}
	r, closeFn, err := openInput(argv[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	defer closeFn()
	n, correct, examples := 0, 0, 0
	labelStats := map[string][3]int{}
	sc := bufio.NewScanner(r)
	sc.Buffer(make([]byte, 1024), 1024*1024*16)
	for sc.Scan() {
		trueLabels, _ := splitLabeled(sc.Text(), m.Label)
		if len(trueLabels) == 0 {
			continue
		}
		examples++
		ps := m.predictions(sc.Text(), k, th)
		predSet := map[string]bool{}
		for _, p := range ps {
			predSet[p.label] = true
			n++
		}
		trueSet := map[string]bool{}
		for _, l := range trueLabels {
			trueSet[l] = true
		}
		for _, p := range ps {
			st := labelStats[p.label]
			if trueSet[p.label] {
				correct++
				st[0]++
			} else {
				st[1]++
			}
			labelStats[p.label] = st
		}
		for _, l := range trueLabels {
			if !predSet[l] {
				st := labelStats[l]
				st[2]++
				labelStats[l] = st
			}
		}
	}
	if perLabel {
		labels := append([]string(nil), m.Labels...)
		sort.Strings(labels)
		for _, l := range labels {
			st := labelStats[l]
			p := ratio(st[0], st[0]+st[1])
			r := ratio(st[0], st[0]+st[2])
			fmt.Printf("%s P@%d %.3f R@%d %.3f F1 %.3f\n", l, k, p, k, r, f1(p, r))
		}
		return
	}
	fmt.Printf("N\t%d\n", examples)
	fmt.Printf("P@%d\t%.3g\n", k, ratio(correct, n))
	fmt.Printf("R@%d\t%.3g\n", k, ratio(correct, examples))
}

func printWordVectors(path string) {
	m := mustLoad(path)
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		for _, w := range strings.Fields(sc.Text()) {
			fmt.Printf("%s %s\n", w, formatVector(m.getVector(w)))
		}
	}
}

func printSentenceVectors(path string) {
	m := mustLoad(path)
	sc := bufio.NewScanner(os.Stdin)
	for sc.Scan() {
		words := tokenize(sc.Text())
		vec := make([]float64, m.Dim)
		for _, w := range words {
			add(vec, m.getVector(w))
		}
		if len(words) > 0 {
			scale(vec, 1/float64(len(words)))
		}
		fmt.Println(formatVector(vec))
	}
}

func printNgrams(path, word string) {
	m := mustLoad(path)
	fmt.Println(word)
	minn, maxn := atoi(m.Args["-minn"], 3), atoi(m.Args["-maxn"], 6)
	if minn <= 0 || maxn < minn {
		return
	}
	w := "<" + word + ">"
	rs := []rune(w)
	for n := minn; n <= maxn; n++ {
		for i := 0; i+n <= len(rs); i++ {
			fmt.Println(string(rs[i : i+n]))
		}
	}
}

func nn(argv []string) {
	m := mustLoad(argv[0])
	k := 10
	if len(argv) > 1 {
		k = atoi(argv[1], 10)
	}
	sc := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("Query word? ")
		if !sc.Scan() {
			break
		}
		for _, p := range nearest(m, vectorFor(strings.TrimSpace(sc.Text()), m.Dim), k, "") {
			fmt.Printf("%s %.6f\n", p.label, p.prob)
		}
	}
}

func analogies(argv []string) {
	m := mustLoad(argv[0])
	k := 10
	if len(argv) > 1 {
		k = atoi(argv[1], 10)
	}
	sc := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("Query triplet (A - B + C)? ")
		if !sc.Scan() {
			break
		}
		fs := strings.Fields(sc.Text())
		if len(fs) < 3 {
			continue
		}
		v := append([]float64(nil), m.getVector(fs[1])...)
		sub(v, m.getVector(fs[0]))
		add(v, m.getVector(fs[2]))
		for _, p := range nearest(m, v, k, "") {
			fmt.Printf("%s %.6f\n", p.label, p.prob)
		}
	}
}

func dump(path, opt string) {
	m := mustLoad(path)
	switch opt {
	case "args":
		keys := make([]string, 0, len(m.Args))
		for k := range m.Args {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			fmt.Printf("%s %s\n", strings.TrimPrefix(k, "-"), m.Args[k])
		}
	case "dict":
		words := sortedVocab(m)
		for _, w := range words {
			fmt.Printf("%s %d\n", w, m.Vocab[w])
		}
		for _, l := range m.Labels {
			fmt.Printf("%s %d\n", l, m.LabelCount[l])
		}
	case "input", "output":
		words := sortedVocab(m)
		for _, w := range words {
			fmt.Printf("%s %s\n", w, formatVector(m.getVector(w)))
		}
	default:
		fmt.Fprintln(os.Stderr, "Unknown dump option")
		os.Exit(1)
	}
}

func saveModel(path string, m *Model) error {
	b, err := json.MarshalIndent(m, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0644)
}

func loadModel(path string) (*Model, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("%s cannot be opened for loading!", path)
	}
	var m Model
	if err := json.Unmarshal(b, &m); err != nil || m.Magic != "fasttext-clone-v1" {
		return nil, fmt.Errorf("%s has wrong file format!", path)
	}
	if m.Dim <= 0 {
		m.Dim = 100
	}
	if m.Label == "" {
		m.Label = "__label__"
	}
	return &m, nil
}

func mustLoad(path string) *Model {
	m, err := loadModel(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	return m
}

func saveVec(path string, m *Model) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	words := sortedVocab(m)
	fmt.Fprintf(f, "%d %d\n", len(words), m.Dim)
	for _, w := range words {
		fmt.Fprintf(f, "%s %s\n", w, formatVector(m.getVector(w)))
	}
	return nil
}

func openInput(path string) (io.Reader, func(), error) {
	if path == "-" {
		return os.Stdin, func() {}, nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, func() {}, err
	}
	return f, func() { _ = f.Close() }, nil
}

func (m *Model) getVector(word string) []float64 {
	if m.Vectors != nil {
		if v, ok := m.Vectors[word]; ok {
			return v
		}
	}
	return vectorFor(word, m.Dim)
}

func vectorFor(word string, dim int) []float64 {
	v := make([]float64, dim)
	for i := 0; i < dim; i++ {
		h := sha1.Sum([]byte(fmt.Sprintf("%s#%d", word, i)))
		u := binary.BigEndian.Uint64(h[:8])
		v[i] = (float64(u%2000000)/1000000.0 - 1.0) / float64(max(1, dim))
	}
	return v
}

func nearest(m *Model, target []float64, k int, skip string) []pred {
	var out []pred
	for _, w := range sortedVocab(m) {
		if w == skip {
			continue
		}
		out = append(out, pred{label: w, prob: cosine(target, m.getVector(w))})
	}
	sort.Slice(out, func(i, j int) bool {
		if math.Abs(out[i].prob-out[j].prob) > 1e-15 {
			return out[i].prob > out[j].prob
		}
		return out[i].label < out[j].label
	})
	if len(out) > k {
		out = out[:k]
	}
	return out
}

func sortedVocab(m *Model) []string {
	words := make([]string, 0, len(m.Vocab))
	for w := range m.Vocab {
		words = append(words, w)
	}
	sort.Strings(words)
	return words
}

func formatVector(v []float64) string {
	parts := make([]string, len(v))
	for i, x := range v {
		parts[i] = fmt.Sprintf("%.6f", x)
	}
	return strings.Join(parts, " ")
}

func fmtProb(x float64) string {
	return strconv.FormatFloat(x, 'g', 6, 64)
}

func add(a, b []float64) {
	for i := range a {
		if i < len(b) {
			a[i] += b[i]
		}
	}
}

func sub(a, b []float64) {
	for i := range a {
		if i < len(b) {
			a[i] -= b[i]
		}
	}
}

func scale(a []float64, f float64) {
	for i := range a {
		a[i] *= f
	}
}

func cosine(a, b []float64) float64 {
	dot, na, nb := 0.0, 0.0, 0.0
	for i := range a {
		if i < len(b) {
			dot += a[i] * b[i]
			nb += b[i] * b[i]
		}
		na += a[i] * a[i]
	}
	if na == 0 || nb == 0 {
		return 0
	}
	return dot / math.Sqrt(na*nb)
}

func ratio(a, b int) float64 {
	if b == 0 {
		return 0
	}
	return float64(a) / float64(b)
}

func f1(p, r float64) float64 {
	if p+r == 0 {
		return 0
	}
	return 2 * p * r / (p + r)
}

func atoi(s string, def int) int {
	i, err := strconv.Atoi(s)
	if err != nil {
		return def
	}
	return i
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
