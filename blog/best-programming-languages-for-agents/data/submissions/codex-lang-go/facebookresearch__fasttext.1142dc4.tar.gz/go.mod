module fasttextclone

go 1.21
