package main

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/jpeg"
	_ "image/png"
	"io"
	"math"
	"net/url"
	"os"
	"strconv"
	"strings"
)

const versionText = "jp2a 1.0.8\nCopyright 2006-2016 Christian Stigen Larsen\nDistributed under the GNU General Public License (GPL) v2.\n"

const helpText = `jp2a 1.0.8
Copyright 2006-2016 Christian Stigen Larsen
Distributed under the GNU General Public License (GPL) v2.

Usage: jp2a [ options ] [ file(s) | URL(s) ]

Convert files or URLs from JPEG format to ASCII.

OPTIONS
  -                 Read images from standard input.
      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145
  -b, --border      Print a border around the output image.
      --chars=...   Select character palette used to paint the image.
                    Leftmost character corresponds to black pixel, right-
                    most to white.  Minimum two characters must be specified.
      --clear       Clears screen before drawing each output image.
      --colors      Use ANSI colors in output.
  -d, --debug       Print additional debug information.
      --fill        When used with --color and/or --html, color each character's
                    background color.
  -x, --flipx       Flip image in X direction.
  -y, --flipy       Flip image in Y direction.
  -f, --term-fit    Use the largest image dimension that fits in your terminal
                    display with correct aspect ratio.
      --term-height Use terminal display height.
      --term-width  Use terminal display width.
  -z, --term-zoom   Use terminal display dimension for output.
      --grayscale   Convert image to grayscale when using --html or --colors
      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866
      --height=N    Set output height, calculate width from aspect ratio.
  -h, --help        Print program help.
      --html        Produce strict XHTML 1.0 output.
      --html-fill   Same as --fill (will be phased out)
      --html-fontsize=N   Set fontsize to N pt, default is 4.
      --html-no-bold      Do not use bold characters with HTML output
      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.
      --html-title=...  Set HTML output title
  -i, --invert      Invert output image.  Use if your display has a dark
                    background.
      --background=dark   These are just mnemonics whether to use --invert
      --background=light  or not.  If your console has light characters on
                    a dark background, use --background=dark.
      --output=...  Write output to file.
      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.
      --size=WxH    Set output width and height.
  -v, --verbose     Verbose output.
  -V, --version     Print program version.
      --width=N     Set output width, calculate height from ratio.

  The default mode is ` + "`" + `jp2a --term-fit --background=dark'.
  See the man-page for jp2a for more detailed help text.

Project homepage on https://github.com/cslarsen/jp2a
Report bugs to <csl@csl.name>
`

type opts struct {
	width, height                int
	haveW, haveH                 bool
	chars                        string
	invert, border, flipx, flipy bool
	html, htmlRaw, htmlNoBold    bool
	htmlFontSize                 int
	htmlTitle                    string
	colors, fill, grayscale      bool
	output                       string
	verbose, clear               bool
	red, green, blue             float64
	files                        []string
}

func main() {
	o := opts{chars: "   ...',;:clodxkO0KXNWM", htmlFontSize: 4, htmlTitle: "Created with jp2a", output: "-", red: 0.2989, green: 0.5866, blue: 0.1145}
	if err := parseArgs(os.Args[1:], &o); err != nil {
		fmt.Fprintln(os.Stderr, err)
		fmt.Fprintln(os.Stderr)
		fmt.Fprint(os.Stderr, helpText)
		os.Exit(1)
	}
	if len(o.chars) < 2 {
		fmt.Fprintln(os.Stderr, "Environment variable TERM not set.")
		os.Exit(1)
	}
	if len(o.files) == 0 {
		if !o.haveW && !o.haveH {
			fmt.Fprintln(os.Stderr, "Environment variable TERM not set.")
			os.Exit(1)
		}
		o.files = []string{"-"}
	}
	var out io.Writer = os.Stdout
	if o.output != "" && o.output != "-" {
		f, err := os.Create(o.output)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		defer f.Close()
		out = f
	}
	if o.html && !o.htmlRaw {
		writeHTMLHeader(out, o)
	}
	exit := 0
	for i, name := range o.files {
		if o.clear {
			if i == 0 {
				fmt.Fprint(out, "\033[H\033[J")
			} else {
				fmt.Fprint(out, "\033[H\033[J")
			}
		}
		if err := process(out, name, o); err != nil {
			fmt.Fprintln(os.Stderr, err)
			exit = 1
		}
	}
	if o.html && !o.htmlRaw {
		writeHTMLFooter(out)
	}
	os.Exit(exit)
}

func parseArgs(args []string, o *opts) error {
	for _, a := range args {
		switch {
		case a == "-h" || a == "--help":
			fmt.Print(helpText)
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Print(versionText)
			os.Exit(0)
		case a == "-b" || a == "--border":
			o.border = true
		case a == "-i" || a == "--invert":
			o.invert = true
		case a == "-x" || a == "--flipx":
			o.flipx = true
		case a == "-y" || a == "--flipy":
			o.flipy = true
		case a == "--colors" || a == "--color":
			o.colors = true
		case a == "--html":
			o.html = true
		case a == "--html-raw":
			o.htmlRaw = true
		case a == "--html-no-bold":
			o.htmlNoBold = true
		case a == "--fill" || a == "--html-fill":
			o.fill = true
		case a == "--grayscale":
			o.grayscale = true
		case a == "-v" || a == "--verbose":
			o.verbose = true
		case a == "-d" || a == "--debug":
		case a == "--clear":
			o.clear = true
		case a == "-f" || a == "--term-fit" || a == "--term-width" || a == "--term-height" || a == "-z" || a == "--term-zoom":
		case a == "--background=dark":
			o.invert = true
		case a == "--background=light":
			o.invert = false
		case strings.HasPrefix(a, "--chars="):
			o.chars = strings.TrimPrefix(a, "--chars=")
		case strings.HasPrefix(a, "--width="):
			n, err := atoiOpt(a[8:])
			if err != nil {
				return err
			}
			o.width = n
			o.haveW = true
		case strings.HasPrefix(a, "--height="):
			n, err := atoiOpt(a[9:])
			if err != nil {
				return err
			}
			o.height = n
			o.haveH = true
		case strings.HasPrefix(a, "--size="):
			parts := strings.Split(strings.TrimPrefix(a, "--size="), "x")
			if len(parts) != 2 {
				return fmt.Errorf("Invalid size")
			}
			w, e1 := atoiOpt(parts[0])
			h, e2 := atoiOpt(parts[1])
			if e1 != nil || e2 != nil {
				return fmt.Errorf("Invalid size")
			}
			o.width = w
			o.height = h
			o.haveW = true
			o.haveH = true
		case strings.HasPrefix(a, "--output="):
			o.output = strings.TrimPrefix(a, "--output=")
		case strings.HasPrefix(a, "--html-fontsize="):
			n, err := atoiOpt(strings.TrimPrefix(a, "--html-fontsize="))
			if err != nil {
				return err
			}
			o.htmlFontSize = n
		case strings.HasPrefix(a, "--html-title="):
			o.htmlTitle = strings.TrimPrefix(a, "--html-title=")
		case strings.HasPrefix(a, "--red="):
			v, err := strconv.ParseFloat(strings.TrimPrefix(a, "--red="), 64)
			if err != nil {
				return err
			}
			o.red = v
		case strings.HasPrefix(a, "--green="):
			v, err := strconv.ParseFloat(strings.TrimPrefix(a, "--green="), 64)
			if err != nil {
				return err
			}
			o.green = v
		case strings.HasPrefix(a, "--blue="):
			v, err := strconv.ParseFloat(strings.TrimPrefix(a, "--blue="), 64)
			if err != nil {
				return err
			}
			o.blue = v
		case a == "-":
			o.files = append(o.files, a)
		case strings.HasPrefix(a, "-"):
			return fmt.Errorf("Unknown option %s", a)
		default:
			o.files = append(o.files, a)
		}
	}
	return nil
}

func atoiOpt(s string) (int, error) {
	n, err := strconv.Atoi(s)
	if err != nil || n < 1 {
		return 0, fmt.Errorf("Invalid value")
	}
	return n, nil
}

func process(out io.Writer, name string, o opts) error {
	var data []byte
	var err error
	if name == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else if u, e := url.Parse(name); e == nil && u.Scheme != "" && u.Scheme != "file" {
		return fmt.Errorf("Could not download %s", name)
	} else if u != nil && u.Scheme == "file" {
		data, err = os.ReadFile(u.Path)
	} else {
		data, err = os.ReadFile(name)
	}
	if err != nil {
		return err
	}
	img, err := jpeg.Decode(bytes.NewReader(data))
	if err != nil {
		img, _, err = image.Decode(bytes.NewReader(data))
	}
	if err != nil {
		return fmt.Errorf("%s: %v", name, err)
	}
	b := img.Bounds()
	sw, sh := b.Dx(), b.Dy()
	ow, oh := o.width, o.height
	if o.haveW && !o.haveH {
		oh = int(float64(ow) * float64(sh) / float64(sw) / 2.0)
	}
	if o.haveH && !o.haveW {
		ow = int(float64(oh) * float64(sw) / float64(sh) * 2.0)
	}
	if !o.haveW && !o.haveH {
		return fmt.Errorf("Environment variable TERM not set.")
	}
	if ow < 1 {
		ow = 1
	}
	if oh < 1 {
		oh = 1
	}
	if o.verbose {
		fmt.Fprintf(os.Stderr, "File: %s\nSource width: %d\nSource height: %d\nSource color components: %d\nOutput width: %d\nOutput height: %d\nOutput palette (%d chars): '%s'\n", name, sw, sh, components(img), ow, oh, len(o.chars), o.chars)
	}
	if o.border && !o.html {
		fmt.Fprint(out, "+", strings.Repeat("-", ow), "+\n")
	}
	for y := 0; y < oh; y++ {
		if o.border && !o.html {
			fmt.Fprint(out, "|")
		}
		for x := 0; x < ow; x++ {
			r, g, bv := avgCell(img, b, sw, sh, ow, oh, x, y, o.flipx, o.flipy)
			lum := o.red*float64(r) + o.green*float64(g) + o.blue*float64(bv)
			idx := int(lum * float64(len(o.chars)) / 256.0)
			if idx < 0 {
				idx = 0
			}
			if idx >= len(o.chars) {
				idx = len(o.chars) - 1
			}
			if o.invert {
				idx = len(o.chars) - 1 - idx
			}
			ch := o.chars[idx]
			if o.html {
				writeHTMLChar(out, ch, r, g, bv, o)
			} else if o.colors {
				writeANSIChar(out, ch, r, g, bv, o.grayscale)
			} else {
				fmt.Fprintf(out, "%c", ch)
			}
		}
		if o.border && !o.html {
			fmt.Fprint(out, "|")
		}
		if o.html {
			fmt.Fprint(out, "<br/>")
		} else {
			fmt.Fprint(out, "\n")
		}
	}
	if o.border && !o.html {
		fmt.Fprint(out, "+", strings.Repeat("-", ow), "+\n")
	}
	return nil
}

func rgb8(c color.Color) (int, int, int) {
	r, g, b, _ := c.RGBA()
	return int(r >> 8), int(g >> 8), int(b >> 8)
}
func avgCell(img image.Image, b image.Rectangle, sw, sh, ow, oh, x, y int, flipx, flipy bool) (int, int, int) {
	x0 := int(float64(x) * float64(sw) / float64(ow))
	x1 := int(float64(x+1) * float64(sw) / float64(ow))
	if x1 <= x0 {
		x1 = x0 + 1
	}
	if x1 > sw {
		x1 = sw
	}
	y0 := int(float64(y) * float64(sh) / float64(oh))
	y1 := int(float64(y+1) * float64(sh) / float64(oh))
	if y1 <= y0 {
		y1 = y0 + 1
	}
	if y1 > sh {
		y1 = sh
	}
	var rs, gs, bs, n int
	for yy := y0; yy < y1; yy++ {
		sy := yy
		if flipy {
			sy = sh - 1 - yy
		}
		for xx := x0; xx < x1; xx++ {
			sx := xx
			if flipx {
				sx = sw - 1 - xx
			}
			r, g, bv := rgb8(img.At(b.Min.X+sx, b.Min.Y+sy))
			rs += r
			gs += g
			bs += bv
			n++
		}
	}
	if n == 0 {
		return 0, 0, 0
	}
	return rs / n, gs / n, bs / n
}
func components(img image.Image) int {
	if img.ColorModel() == color.GrayModel {
		return 1
	}
	return 3
}

func writeANSIChar(out io.Writer, ch byte, r, g, b int, gray bool) {
	if gray {
		y := int(0.2989*float64(r) + 0.5866*float64(g) + 0.1145*float64(b))
		r = y
		g = y
		b = y
	}
	code := ansiCode(r, g, b)
	if code == 0 {
		fmt.Fprintf(out, "%c", ch)
	} else {
		fmt.Fprintf(out, "\033[%dm%c\033[0m", code, ch)
	}
}
func ansiCode(r, g, b int) int {
	bright := max3(r, g, b) > 192
	rr, gg, bb := r > 128, g > 128, b > 128
	code := 30
	if rr {
		code += 1
	}
	if gg {
		code += 2
	}
	if bb {
		code += 4
	}
	if bright {
		code += 60
	}
	return code
}
func max3(a, b, c int) int {
	if b > a {
		a = b
	}
	if c > a {
		a = c
	}
	return a
}

func writeHTMLChar(out io.Writer, ch byte, r, g, b int, o opts) {
	if o.grayscale {
		y := int(math.Round(0.2989*float64(r) + 0.5866*float64(g) + 0.1145*float64(b)))
		r = y
		g = y
		b = y
	}
	if o.fill {
		fr := int(float64(r)*0.77 - 51)
		fg := int(float64(g)*0.77 - 51)
		fb := int(float64(b)*0.77 - 51)
		if fr < 0 {
			fr = 0
		}
		if fg < 0 {
			fg = 0
		}
		if fb < 0 {
			fb = 0
		}
		fmt.Fprintf(out, "<span style='color:#%02x%02x%02x; background-color:#%02x%02x%02x;'>%s</span>", fr, fg, fb, r, g, b, htmlChar(ch))
	} else if o.colors {
		fmt.Fprintf(out, "<span style='color:#%02x%02x%02x;'>%s</span>", r, g, b, htmlChar(ch))
	} else {
		fmt.Fprint(out, htmlChar(ch))
	}
}
func htmlChar(ch byte) string {
	switch ch {
	case '&':
		return "&amp;"
	case '<':
		return "&lt;"
	case '>':
		return "&gt;"
	case ' ':
		return "&nbsp;"
	default:
		return string([]byte{ch})
	}
}
func esc(s string) string {
	return strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", "\"", "&quot;").Replace(s)
}
func writeHTMLHeader(out io.Writer, o opts) {
	bold := "font-weight:bold;"
	if o.htmlNoBold {
		bold = ""
	}
	fmt.Fprintf(out, "<?xml version='1.0' encoding='ISO-8859-1'?>\n<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'\n  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n<html xmlns='http://www.w3.org/1999/xhtml'>\n<head>\n<meta http-equiv='Content-Type' content='text/html; charset=ISO-8859-1' />\n<title>%s</title>\n<style type='text/css'>\nbody { background-color:white; color:black; }\n.ascii { font-family: Courier, monospace; font-size:%dpt; %s line-height:%dpt; }\n</style>\n</head>\n<body>\n<div class='ascii'>\n", esc(o.htmlTitle), o.htmlFontSize, bold, o.htmlFontSize)
}
func writeHTMLFooter(out io.Writer) { fmt.Fprint(out, "</div>\n</body>\n</html>\n") }
