package main

import (
	"encoding/csv"
	"errors"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
)

type config struct {
	noHeaders   bool
	number      bool
	delimiter   rune
	style       string
	padding     int
	indent      int
	sniff       int
	headerAlign string
	bodyAlign   string
	file        string
}

type border struct {
	left, mid, right string
	top              [3]string
	header           [3]string
	row              [3]string
	bottom           [3]string
	hasOuter         bool
	headerLine       bool
	rowLines         bool
}

func main() {
	cfg, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(2)
	}
	if err := run(cfg); err != nil {
		fmt.Fprintf(os.Stderr, "csview: %v\n", err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (config, bool) {
	cfg := config{delimiter: ',', style: "sharp", padding: 1, sniff: 1000, headerAlign: "center", bodyAlign: "left"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "--") && strings.Contains(a, "=") {
			parts := strings.SplitN(a, "=", 2)
			a = parts[0]
			if isValueOpt(a) {
				if !setOpt(&cfg, a, parts[1]) {
					return cfg, false
				}
				continue
			}
		}
		switch a {
		case "-h", "--help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("csview 1.3.4")
			os.Exit(0)
		case "-H", "--no-headers":
			cfg.noHeaders = true
		case "-n", "--number":
			cfg.number = true
		case "-t", "--tsv":
			cfg.delimiter = '\t'
		case "-P", "--disable-pager":
		case "-d", "--delimiter", "-s", "--style", "-p", "--padding", "-i", "--indent", "--sniff", "--header-align", "--body-align":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", a)
				return cfg, false
			}
			i++
			val := args[i]
			if !setOpt(&cfg, a, val) {
				return cfg, false
			}
		default:
			if strings.HasPrefix(a, "--") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n", a, a, a)
				return cfg, false
			}
			if strings.HasPrefix(a, "-") && len(a) > 1 {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n", a)
				return cfg, false
			}
			if cfg.file != "" {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n", a)
				return cfg, false
			}
			cfg.file = a
		}
	}
	return cfg, true
}

func isValueOpt(opt string) bool {
	switch opt {
	case "--delimiter", "--style", "--padding", "--indent", "--sniff", "--header-align", "--body-align":
		return true
	default:
		return false
	}
}

func setOpt(cfg *config, opt, val string) bool {
	switch opt {
	case "-d", "--delimiter":
		rs := []rune(val)
		if len(rs) != 1 {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--delimiter <DELIMITER>': too many characters in string\n\nFor more information, try '--help'.\n", val)
			return false
		}
		cfg.delimiter = rs[0]
	case "-s", "--style":
		switch val {
		case "none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid":
			cfg.style = val
		default:
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]\n\nFor more information, try '--help'.\n", val)
			return false
		}
	case "-p", "--padding":
		n, err := strconv.Atoi(val)
		if err != nil || n < 0 {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--padding <PADDING>'\n\nFor more information, try '--help'.\n", val)
			return false
		}
		cfg.padding = n
	case "-i", "--indent":
		n, err := strconv.Atoi(val)
		if err != nil || n < 0 {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--indent <INDENT>'\n\nFor more information, try '--help'.\n", val)
			return false
		}
		cfg.indent = n
	case "--sniff":
		n, err := strconv.Atoi(val)
		if err != nil || n < 0 {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--sniff <LIMIT>'\n\nFor more information, try '--help'.\n", val)
			return false
		}
		cfg.sniff = n
	case "--header-align":
		if !validAlign(val) {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--header-align <HEADER_ALIGN>'\n  [possible values: left, center, right]\n\nFor more information, try '--help'.\n", val)
			return false
		}
		cfg.headerAlign = val
	case "--body-align":
		if !validAlign(val) {
			fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--body-align <BODY_ALIGN>'\n  [possible values: left, center, right]\n\nFor more information, try '--help'.\n", val)
			return false
		}
		cfg.bodyAlign = val
	}
	return true
}

func validAlign(s string) bool { return s == "left" || s == "center" || s == "right" }

func printHelp() {
	fmt.Print(`A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version
`)
}

func run(cfg config) error {
	var in io.Reader = os.Stdin
	if cfg.file != "" {
		f, err := os.Open(cfg.file)
		if err != nil {
			return err
		}
		defer f.Close()
		in = f
	}
	r := csv.NewReader(in)
	r.Comma = cfg.delimiter
	r.FieldsPerRecord = 0
	rows, err := r.ReadAll()
	if err != nil {
		return fmt.Errorf("CSV error: %w", err)
	}
	if len(rows) == 0 {
		rows = [][]string{{}}
		cfg.noHeaders = true
	}
	if cfg.number {
		rows = addNumbers(rows, !cfg.noHeaders)
	}
	widths := columnWidths(rows, cfg)
	render(rows, widths, cfg)
	return nil
}

func addNumbers(rows [][]string, hasHeader bool) [][]string {
	out := make([][]string, len(rows))
	for i, row := range rows {
		nr := make([]string, 0, len(row)+1)
		if i == 0 && hasHeader {
			nr = append(nr, "#")
		} else {
			offset := 0
			if hasHeader {
				offset = 1
			}
			nr = append(nr, strconv.Itoa(i+1-offset))
		}
		nr = append(nr, row...)
		out[i] = nr
	}
	return out
}

func columnWidths(rows [][]string, cfg config) []int {
	cols := 0
	for _, r := range rows {
		if len(r) > cols {
			cols = len(r)
		}
	}
	widths := make([]int, cols)
	limit := len(rows)
	if cfg.sniff > 0 {
		headerRows := 0
		if !cfg.noHeaders && len(rows) > 0 {
			headerRows = 1
		}
		max := headerRows + cfg.sniff
		if max < limit {
			limit = max
		}
	}
	for i := 0; i < limit; i++ {
		for c := 0; c < cols; c++ {
			val := ""
			if c < len(rows[i]) {
				val = rows[i][c]
			}
			for _, line := range strings.Split(val, "\n") {
				if w := displayWidth(line); w > widths[c] {
					widths[c] = w
				}
			}
		}
	}
	return widths
}

func render(rows [][]string, widths []int, cfg config) {
	b := style(cfg.style)
	indent := strings.Repeat(" ", cfg.indent)
	if cfg.style == "ascii2" || cfg.style == "none" {
		renderPlain(rows, widths, cfg, indent)
		return
	}
	if b.hasOuter {
		fmt.Println(indent + rule(widths, cfg.padding, b.top))
	}
	for i, row := range rows {
		align := cfg.bodyAlign
		if i == 0 && !cfg.noHeaders {
			align = cfg.headerAlign
		}
		printRow(row, widths, cfg.padding, align, cfg, b, indent)
		if i == 0 && !cfg.noHeaders && b.headerLine {
			fmt.Println(indent + rule(widths, cfg.padding, b.header))
		} else if cfg.style == "grid" && i < len(rows)-1 {
			fmt.Println(indent + rule(widths, cfg.padding, b.row))
		}
	}
	if b.hasOuter {
		fmt.Println(indent + rule(widths, cfg.padding, b.bottom))
	}
}

func renderPlain(rows [][]string, widths []int, cfg config, indent string) {
	for i, row := range rows {
		align := cfg.bodyAlign
		if i == 0 && !cfg.noHeaders {
			align = cfg.headerAlign
		}
		line := plainRow(row, widths, cfg.padding, align, cfg.style == "ascii2")
		fmt.Println(indent + line)
		if i == 0 && !cfg.noHeaders && cfg.style == "ascii2" {
			fmt.Println(indent + ascii2Rule(widths, cfg.padding))
		}
	}
}

func style(s string) border {
	switch s {
	case "ascii":
		return border{left: "|", mid: "|", right: "|", top: [3]string{"+", "-", "+"}, header: [3]string{"+", "-", "+"}, bottom: [3]string{"+", "-", "+"}, hasOuter: true, headerLine: true}
	case "markdown":
		return border{left: "|", mid: "|", right: "|", header: [3]string{"|", "-", "|"}, headerLine: true}
	case "rounded":
		return border{left: "│", mid: "│", right: "│", top: [3]string{"╭", "─", "╮"}, header: [3]string{"├", "─", "┤"}, bottom: [3]string{"╰", "─", "╯"}, hasOuter: true, headerLine: true}
	case "reinforced":
		return border{left: "│", mid: "│", right: "│", top: [3]string{"┏", "─", "┓"}, header: [3]string{"├", "─", "┤"}, bottom: [3]string{"┗", "─", "┛"}, hasOuter: true, headerLine: true}
	case "grid":
		return border{left: "│", mid: "│", right: "│", top: [3]string{"┌", "─", "┐"}, header: [3]string{"├", "─", "┤"}, row: [3]string{"├", "─", "┤"}, bottom: [3]string{"└", "─", "┘"}, hasOuter: true, headerLine: true, rowLines: true}
	default:
		return border{left: "│", mid: "│", right: "│", top: [3]string{"┌", "─", "┐"}, header: [3]string{"├", "─", "┤"}, bottom: [3]string{"└", "─", "┘"}, hasOuter: true, headerLine: true}
	}
}

func rule(widths []int, padding int, parts [3]string) string {
	if len(widths) == 0 {
		return parts[0] + parts[2]
	}
	sep := junction(parts[0], parts[2])
	var sb strings.Builder
	sb.WriteString(parts[0])
	for i, w := range widths {
		if i > 0 {
			sb.WriteString(sep)
		}
		sb.WriteString(strings.Repeat(parts[1], w+padding*2))
	}
	sb.WriteString(parts[2])
	return sb.String()
}

func junction(left, right string) string {
	switch {
	case left == "┌" || left == "╭" || left == "┏":
		return "┬"
	case left == "└" || left == "╰" || left == "┗":
		return "┴"
	case left == "+":
		return "+"
	case left == "|":
		return "|"
	default:
		return "┼"
	}
}

func printRow(row []string, widths []int, padding int, align string, cfg config, b border, indent string) {
	lines := splitCells(row, len(widths))
	for _, cells := range lines {
		var sb strings.Builder
		sb.WriteString(indent)
		sb.WriteString(b.left)
		for c, w := range widths {
			if c > 0 {
				sb.WriteString(b.mid)
			}
			sb.WriteString(formatCell(cells[c], w, padding, align))
		}
		sb.WriteString(b.right)
		fmt.Println(sb.String())
	}
}

func plainRow(row []string, widths []int, padding int, align string, ascii2 bool) string {
	lines := splitCells(row, len(widths))
	cells := lines[0]
	var sb strings.Builder
	for c, w := range widths {
		if c > 0 {
			if ascii2 {
				sb.WriteString("|")
			}
		}
		sb.WriteString(formatCell(cells[c], w, padding, align))
	}
	if ascii2 {
		return " " + sb.String() + " "
	}
	return sb.String()
}

func ascii2Rule(widths []int, padding int) string {
	var sb strings.Builder
	for c, w := range widths {
		if c > 0 {
			sb.WriteString("+")
		}
		sb.WriteString(strings.Repeat("-", w+padding*2))
	}
	return " " + sb.String() + " "
}

func splitCells(row []string, cols int) [][]string {
	height := 1
	parts := make([][]string, cols)
	for c := 0; c < cols; c++ {
		if c < len(row) {
			parts[c] = strings.Split(row[c], "\n")
		} else {
			parts[c] = []string{""}
		}
		if len(parts[c]) > height {
			height = len(parts[c])
		}
	}
	out := make([][]string, height)
	for i := 0; i < height; i++ {
		out[i] = make([]string, cols)
		for c := 0; c < cols; c++ {
			if i < len(parts[c]) {
				out[i][c] = parts[c][i]
			}
		}
	}
	return out
}

func formatCell(s string, width, padding int, align string) string {
	s = truncateWidth(s, width)
	w := displayWidth(s)
	rem := width - w
	left, right := 0, 0
	switch align {
	case "right":
		left = rem
	case "center":
		left = rem / 2
		right = rem - left
	default:
		right = rem
	}
	return strings.Repeat(" ", padding+left) + s + strings.Repeat(" ", padding+right)
}

func truncateWidth(s string, max int) string {
	if max <= 0 {
		return ""
	}
	var sb strings.Builder
	w := 0
	for _, r := range s {
		rw := runeWidth(r)
		if w+rw > max {
			break
		}
		sb.WriteRune(r)
		w += rw
	}
	return sb.String()
}

func displayWidth(s string) int {
	w := 0
	for _, r := range s {
		w += runeWidth(r)
	}
	return w
}

func runeWidth(r rune) int {
	if r == 0 || r < 32 || (r >= 0x7f && r < 0xa0) {
		return 0
	}
	if (r >= 0x300 && r <= 0x36f) || (r >= 0x1ab0 && r <= 0x1aff) || (r >= 0x1dc0 && r <= 0x1dff) || (r >= 0xfe20 && r <= 0xfe2f) {
		return 0
	}
	if (r >= 0x1100 && r <= 0x115f) || (r >= 0x2329 && r <= 0x232a) ||
		(r >= 0x2e80 && r <= 0xa4cf) || (r >= 0xac00 && r <= 0xd7a3) ||
		(r >= 0xf900 && r <= 0xfaff) || (r >= 0xfe10 && r <= 0xfe19) ||
		(r >= 0xfe30 && r <= 0xfe6f) || (r >= 0xff00 && r <= 0xff60) ||
		(r >= 0xffe0 && r <= 0xffe6) || (r >= 0x1f000 && r <= 0x1faff) {
		return 2
	}
	return 1
}

var _ = errors.New
