module csview-reimpl

go 1.21
