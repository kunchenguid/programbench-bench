package main

import (
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "0.1.8"

type options struct {
	inputs      []string
	emitABI     bool
	emitHashes  bool
	outDir      string
	pretty      bool
	prettyErr   bool
	errFormat   string
	helpLong    bool
	helpShort   bool
	version     bool
	zhelp       bool
	stopAfter   string
	evmVersion  string
	color       string
	diagnostics string
	noWarnings  bool
	verbose     bool
}

type contract struct {
	source string
	name   string
	body   string
	items  []abiItem
}

type abiItem struct {
	Type            string     `json:"type"`
	Name            string     `json:"name,omitempty"`
	Inputs          []abiParam `json:"inputs,omitempty"`
	Outputs         []abiParam `json:"outputs,omitempty"`
	StateMutability string     `json:"stateMutability,omitempty"`
	Anonymous       *bool      `json:"anonymous,omitempty"`
}

type abiParam struct {
	Name         string `json:"name"`
	Type         string `json:"type"`
	Indexed      *bool  `json:"indexed,omitempty"`
	InternalType string `json:"internalType"`
}

func (a abiItem) MarshalJSON() ([]byte, error) {
	var b bytes.Buffer
	b.WriteByte('{')
	writeField := func(name string, v any, first *bool) {
		if !*first { b.WriteByte(',') }
		*first = false
		nb, _ := json.Marshal(name)
		vb, _ := json.Marshal(v)
		b.Write(nb); b.WriteByte(':'); b.Write(vb)
	}
	first := true
	writeField("type", a.Type, &first)
	if a.Name != "" { writeField("name", a.Name, &first) }
	switch a.Type {
	case "constructor", "error", "event", "function":
		if a.Inputs == nil { a.Inputs = []abiParam{} }
		writeField("inputs", a.Inputs, &first)
	}
	if a.Type == "function" {
		if a.Outputs == nil { a.Outputs = []abiParam{} }
		writeField("outputs", a.Outputs, &first)
	}
	if a.StateMutability != "" { writeField("stateMutability", a.StateMutability, &first) }
	if a.Anonymous != nil { writeField("anonymous", *a.Anonymous, &first) }
	b.WriteByte('}')
	return b.Bytes(), nil
}

func main() {
	opts, code := parseArgs(os.Args[1:])
	if code != 0 {
		os.Exit(code)
	}
	if opts.helpShort || opts.helpLong {
		printHelp(opts.helpLong)
		return
	}
	if opts.version {
		fmt.Println("solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)")
		return
	}
	if opts.zhelp {
		printZHelp()
		os.Exit(1)
	}
	contracts, err := readAndParse(opts)
	if err != nil {
		emitError(opts, err.Error())
		os.Exit(1)
	}
	if opts.stopAfter != "" && !opts.emitABI && !opts.emitHashes {
		return
	}
	if !opts.emitABI && !opts.emitHashes {
		return
	}
	out := buildOutput(contracts, opts)
	var b []byte
	raw, _ := out.MarshalJSON()
	if opts.pretty {
		var buf bytes.Buffer
		json.Indent(&buf, raw, "", "  ")
		b = buf.Bytes()
		b = append(b, '\n')
	} else {
		b = raw
	}
	if opts.outDir != "" {
		if err := os.MkdirAll(opts.outDir, 0755); err != nil {
			emitError(opts, err.Error())
			os.Exit(1)
		}
		if err := os.WriteFile(filepath.Join(opts.outDir, "combined.json"), b, 0644); err != nil {
			emitError(opts, err.Error())
			os.Exit(1)
		}
		return
	}
	os.Stdout.Write(b)
}

func parseArgs(args []string) (options, int) {
	o := options{evmVersion: "prague", color: "auto", errFormat: "human"}
	evms := map[string]bool{"homestead": true, "tangerineWhistle": true, "spuriousDragon": true, "byzantium": true, "constantinople": true, "petersburg": true, "istanbul": true, "berlin": true, "london": true, "paris": true, "shanghai": true, "cancun": true, "prague": true, "osaka": true}
	stops := map[string]bool{"parsing": true, "lowering": true, "analysis": true}
	colors := map[string]bool{"auto": true, "always": true, "never": true}
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func(name string) (string, bool) {
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", name)
				return "", false
			}
			i++
			return args[i], true
		}
		switch {
		case a == "-h":
			o.helpShort = true
		case a == "--help":
			o.helpLong = true
		case a == "-V" || a == "--version":
			o.version = true
		case a == "-v" || a == "--verbose":
			o.verbose = true
		case a == "--pretty-json":
			o.pretty = true
		case a == "--pretty-json-err":
			o.prettyErr = true
		case a == "--no-warnings":
			o.noWarnings = true
		case a == "-Zhelp":
			o.zhelp = true
		case a == "-Z":
			v, ok := next("-Z")
			if !ok { return o, 2 }
			if v == "help" { o.zhelp = true }
		case strings.HasPrefix(a, "-Z"):
			if strings.TrimPrefix(a, "-Z") == "help" { o.zhelp = true }
		case a == "-j" || a == "--threads" || a == "--jobs":
			v, ok := next(a); if !ok { return o, 2 }
			if _, err := strconv.Atoi(v); err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--threads <THREADS>': invalid digit found in string\n\nFor more information, try '--help'.\n", v)
				return o, 2
			}
		case strings.HasPrefix(a, "--threads="):
			v := strings.TrimPrefix(a, "--threads=")
			if _, err := strconv.Atoi(v); err != nil {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--threads <THREADS>': invalid digit found in string\n\nFor more information, try '--help'.\n", v)
				return o, 2
			}
		case a == "--evm-version":
			v, ok := next(a); if !ok { return o, 2 }
			if !evms[v] { invalidValue(v, "--evm-version <EVM_VERSION>", "homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka"); return o, 2 }
			o.evmVersion = v
		case strings.HasPrefix(a, "--evm-version="):
			v := strings.TrimPrefix(a, "--evm-version=")
			if !evms[v] { invalidValue(v, "--evm-version <EVM_VERSION>", "homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka"); return o, 2 }
			o.evmVersion = v
		case a == "--stop-after":
			v, ok := next(a); if !ok { return o, 2 }
			if !stops[v] { invalidValue(v, "--stop-after <STOP_AFTER>", "parsing, lowering, analysis"); return o, 2 }
			o.stopAfter = v
		case a == "--out-dir":
			v, ok := next(a); if !ok { return o, 2 }; o.outDir = v
		case a == "--emit":
			v, ok := next(a); if !ok { return o, 2 }
			if !parseEmit(&o, v) { return o, 2 }
		case strings.HasPrefix(a, "--emit="):
			if !parseEmit(&o, strings.TrimPrefix(a, "--emit=")) { return o, 2 }
		case a == "--base-path" || a == "-I" || a == "--include-path" || a == "--allow-paths" || a == "--diagnostic-width" || a == "--error-format-human":
			if _, ok := next(a); !ok { return o, 2 }
		case a == "--error-format":
			v, ok := next(a); if !ok { return o, 2 }
			if v != "human" && v != "json" && v != "rustc-json" { invalidValue(v, "--error-format <ERROR_FORMAT>", "human, json, rustc-json"); return o, 2 }
			o.errFormat = v
		case a == "--color":
			v, ok := next(a); if !ok { return o, 2 }
			if !colors[v] { invalidValue(v, "--color <COLOR>", "auto, always, never"); return o, 2 }
			o.color = v
		case strings.HasPrefix(a, "-") && a != "-":
			fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n", a, a, a)
			return o, 2
		default:
			o.inputs = append(o.inputs, a)
		}
	}
	return o, 0
}

func parseEmit(o *options, v string) bool {
	for _, p := range strings.Split(v, ",") {
		switch strings.TrimSpace(p) {
		case "abi":
			o.emitABI = true
		case "hashes":
			o.emitHashes = true
		default:
			invalidValue(p, "--emit <EMIT>", "abi, hashes")
			return false
		}
	}
	return true
}

func invalidValue(v, flag, possible string) {
	fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '%s'\n  [possible values: %s]\n\nFor more information, try '--help'.\n", v, flag, possible)
}

func readAndParse(o options) ([]contract, error) {
	var all []contract
	inputs := o.inputs
	if len(inputs) == 0 {
		return all, nil
	}
	for _, in := range inputs {
		if strings.Contains(in, "=") && !fileExists(in) {
			continue
		}
		name := in
		var data []byte
		var err error
		if in == "-" {
			data, err = io.ReadAll(os.Stdin)
			name = "<stdin>"
		} else {
			data, err = os.ReadFile(in)
			if err != nil {
				return nil, fmt.Errorf("file %s not found", in)
			}
			if !filepath.IsAbs(in) {
				name = filepath.Clean(in)
				if strings.HasPrefix(name, "./") { name = strings.TrimPrefix(name, "./") }
			}
		}
		cs := parseContracts(name, string(data))
		all = append(all, cs...)
	}
	sort.SliceStable(all, func(i, j int) bool {
		ki := all[i].source + ":" + all[i].name
		kj := all[j].source + ":" + all[j].name
		return ki < kj
	})
	return all, nil
}

func fileExists(p string) bool { _, err := os.Stat(p); return err == nil }

func parseContracts(source, src string) []contract {
	clean := stripComments(src)
	re := regexp.MustCompile(`\b(contract|interface|library)\s+([A-Za-z_][A-Za-z0-9_]*)[^{;]*\{`)
	matches := re.FindAllStringSubmatchIndex(clean, -1)
	var out []contract
	for _, m := range matches {
		name := clean[m[4]:m[5]]
		open := m[1] - 1
		close := matchingBrace(clean, open)
		if close < 0 { continue }
		body := clean[open+1 : close]
		c := contract{source: source, name: name, body: body}
		c.items = parseItems(body)
		out = append(out, c)
	}
	return out
}

func stripComments(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); {
		if i+1 < len(s) && s[i] == '/' && s[i+1] == '/' {
			for i < len(s) && s[i] != '\n' { b.WriteByte(' '); i++ }
		} else if i+1 < len(s) && s[i] == '/' && s[i+1] == '*' {
			b.WriteString("  "); i += 2
			for i+1 < len(s) && !(s[i] == '*' && s[i+1] == '/') {
				if s[i] == '\n' { b.WriteByte('\n') } else { b.WriteByte(' ') }
				i++
			}
			if i+1 < len(s) { b.WriteString("  "); i += 2 }
		} else {
			b.WriteByte(s[i]); i++
		}
	}
	return b.String()
}

func matchingBrace(s string, open int) int {
	depth := 0
	for i := open; i < len(s); i++ {
		switch s[i] {
		case '{':
			depth++
		case '}':
			depth--
			if depth == 0 { return i }
		case '"', '\'':
			q := s[i]; i++
			for i < len(s) && s[i] != q {
				if s[i] == '\\' { i++ }
				i++
			}
		}
	}
	return -1
}

func parseItems(body string) []abiItem {
	var items []abiItem
	i := 0
	for i < len(body) {
		for i < len(body) && unicode.IsSpace(rune(body[i])) { i++ }
		if i >= len(body) { break }
		start := i
		end := nextTopDeclEnd(body, i)
		if end <= start { break }
		decl := strings.TrimSpace(body[start:end])
		items = append(items, parseDecl(decl)...)
		i = end
		if i < len(body) && (body[i] == ';' || body[i] == '}') { i++ }
	}
	sort.SliceStable(items, func(i, j int) bool {
		ri, rj := rank(items[i].Type), rank(items[j].Type)
		if ri != rj { return ri < rj }
		if items[i].Name != items[j].Name { return items[i].Name < items[j].Name }
		return signature(items[i]) < signature(items[j])
	})
	return items
}

func rank(t string) int {
	switch t {
	case "constructor": return 0
	case "error": return 1
	case "event": return 2
	case "fallback": return 3
	case "receive": return 4
	case "function": return 5
	default: return 9
	}
}

func nextTopDeclEnd(s string, start int) int {
	depthP, depthB, depthC := 0, 0, 0
	for i := start; i < len(s); i++ {
		switch s[i] {
		case '(':
			depthP++
		case ')':
			if depthP > 0 { depthP-- }
		case '[':
			depthB++
		case ']':
			if depthB > 0 { depthB-- }
		case '{':
			if depthP == 0 && depthB == 0 && depthC == 0 {
				return matchingBrace(s, i)
			}
			depthC++
		case '}':
			if depthC > 0 { depthC-- }
		case ';':
			if depthP == 0 && depthB == 0 && depthC == 0 { return i }
		}
	}
	return len(s)
}

func parseDecl(d string) []abiItem {
	if strings.HasPrefix(d, "constructor") {
		params, rest := paramsAfterKeyword(d, "constructor")
		return []abiItem{{Type: "constructor", Inputs: parseParams(params, false), StateMutability: mutability(rest, "nonpayable")}}
	}
	if strings.HasPrefix(d, "function ") {
		name, params, rest, ok := parseNamedCallable(d, "function")
		if !ok || !isExternallyVisible(rest) { return nil }
		item := abiItem{Type: "function", Name: name, Inputs: parseParams(params, false), Outputs: parseReturns(rest), StateMutability: mutability(rest, "nonpayable")}
		return []abiItem{item}
	}
	if strings.HasPrefix(d, "event ") {
		name, params, rest, ok := parseNamedCallable(d, "event")
		if !ok { return nil }
		anon := strings.Contains(rest, "anonymous")
		return []abiItem{{Type: "event", Name: name, Inputs: parseParams(params, true), Anonymous: &anon}}
	}
	if strings.HasPrefix(d, "error ") {
		name, params, _, ok := parseNamedCallable(d, "error")
		if !ok { return nil }
		return []abiItem{{Type: "error", Name: name, Inputs: parseParams(params, false)}}
	}
	if strings.HasPrefix(d, "fallback") {
		_, rest := paramsAfterKeyword(d, "fallback")
		return []abiItem{{Type: "fallback", StateMutability: mutability(rest, "nonpayable")}}
	}
	if strings.HasPrefix(d, "receive") {
		_, rest := paramsAfterKeyword(d, "receive")
		return []abiItem{{Type: "receive", StateMutability: mutability(rest, "payable")}}
	}
	if strings.Contains(d, " public ") || strings.HasSuffix(d, " public") || strings.Contains(d, " public=") {
		return publicVarGetter(d)
	}
	return nil
}

func paramsAfterKeyword(d, kw string) (string, string) {
	p := strings.Index(d[len(kw):], "(")
	if p < 0 { return "", "" }
	p += len(kw)
	q := matchParen(d, p)
	if q < 0 { return "", d[p+1:] }
	return d[p+1:q], d[q+1:]
}

func parseNamedCallable(d, kw string) (string, string, string, bool) {
	s := strings.TrimSpace(d[len(kw):])
	i := 0
	for i < len(s) && (unicode.IsLetter(rune(s[i])) || unicode.IsDigit(rune(s[i])) || s[i] == '_') { i++ }
	if i == 0 { return "", "", "", false }
	name := s[:i]
	rest := strings.TrimSpace(s[i:])
	if !strings.HasPrefix(rest, "(") { return "", "", "", false }
	q := matchParen(rest, 0)
	if q < 0 { return "", "", "", false }
	return name, rest[1:q], rest[q+1:], true
}

func matchParen(s string, open int) int {
	d := 0
	for i := open; i < len(s); i++ {
		if s[i] == '(' { d++ }
		if s[i] == ')' {
			d--
			if d == 0 { return i }
		}
	}
	return -1
}

func isExternallyVisible(rest string) bool {
	if strings.Contains(rest, " private") || strings.Contains(rest, " internal") { return false }
	return true
}

func mutability(rest, def string) string {
	for _, m := range []string{"pure", "view", "payable"} {
		if strings.Contains(rest, " "+m) || strings.HasPrefix(strings.TrimSpace(rest), m) { return m }
	}
	return def
}

func parseReturns(rest string) []abiParam {
	idx := strings.Index(rest, "returns")
	if idx < 0 { return []abiParam{} }
	p := strings.Index(rest[idx:], "(")
	if p < 0 { return []abiParam{} }
	p += idx
	q := matchParen(rest, p)
	if q < 0 { return []abiParam{} }
	return parseParams(rest[p+1:q], false)
}

func parseParams(s string, event bool) []abiParam {
	parts := splitTop(s, ',')
	var out []abiParam
	for _, raw := range parts {
		raw = strings.TrimSpace(raw)
		if raw == "" { continue }
		toks := strings.Fields(raw)
		indexed := false
		filtered := make([]string, 0, len(toks))
		for _, t := range toks {
			switch t {
			case "memory", "calldata", "storage":
			case "indexed":
				indexed = true
			default:
				filtered = append(filtered, t)
			}
		}
		if len(filtered) == 0 { continue }
		name := ""
		typTokens := filtered
		last := filtered[len(filtered)-1]
		if isIdent(last) && !isTypeWord(last) && len(filtered) > 1 {
			name = last
			typTokens = filtered[:len(filtered)-1]
		}
		internal := normalizeType(strings.Join(typTokens, " "))
		typ := canonicalType(internal)
		p := abiParam{Name: name, Type: typ, InternalType: internal}
		if event {
			v := indexed
			p.Indexed = &v
		}
		out = append(out, p)
	}
	return out
}

func splitTop(s string, sep byte) []string {
	var out []string
	start, dp, db := 0, 0, 0
	for i := 0; i < len(s); i++ {
		switch s[i] {
		case '(':
			dp++
		case ')':
			if dp > 0 { dp-- }
		case '[':
			db++
		case ']':
			if db > 0 { db-- }
		case sep:
			if dp == 0 && db == 0 {
				out = append(out, s[start:i]); start = i+1
			}
		}
	}
	out = append(out, s[start:])
	return out
}

func isIdent(s string) bool {
	if s == "" { return false }
	for i, r := range s {
		if i == 0 && !(unicode.IsLetter(r) || r == '_') { return false }
		if i > 0 && !(unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_') { return false }
	}
	return true
}

func isTypeWord(s string) bool {
	if strings.HasPrefix(s, "uint") || strings.HasPrefix(s, "int") || strings.HasPrefix(s, "bytes") { return true }
	switch s {
	case "address", "bool", "string", "byte", "fixed", "ufixed":
		return true
	}
	return false
}

func normalizeType(t string) string {
	t = strings.Join(strings.Fields(t), " ")
	t = strings.ReplaceAll(t, "address payable", "address")
	if t == "uint" { return "uint256" }
	if t == "int" { return "int256" }
	if t == "byte" { return "bytes1" }
	return t
}

func canonicalType(t string) string {
	t = normalizeType(t)
	if strings.HasPrefix(t, "contract ") { t = strings.TrimSpace(strings.TrimPrefix(t, "contract ")) }
	if strings.HasPrefix(t, "enum ") { t = strings.TrimSpace(strings.TrimPrefix(t, "enum ")) }
	if strings.Contains(t, " ") {
		fs := strings.Fields(t)
		t = fs[len(fs)-1]
	}
	return t
}

func publicVarGetter(d string) []abiItem {
	d = strings.TrimSpace(strings.TrimSuffix(d, ";"))
	if eq := strings.Index(d, "="); eq >= 0 { d = strings.TrimSpace(d[:eq]) }
	toks := strings.Fields(d)
	if len(toks) < 3 { return nil }
	vis := -1
	for i, t := range toks { if t == "public" { vis = i; break } }
	if vis <= 0 { return nil }
	name := toks[len(toks)-1]
	if name == "constant" || name == "immutable" || name == "override" { return nil }
	typeTokens := toks[:vis]
	if len(typeTokens) == 0 { return nil }
	internal := normalizeType(strings.Join(typeTokens, " "))
	return []abiItem{{Type: "function", Name: name, Inputs: []abiParam{}, Outputs: []abiParam{{Name: "", Type: canonicalType(internal), InternalType: internal}}, StateMutability: "view"}}
}

func buildOutput(cs []contract, o options) orderedOutput {
	oo := orderedOutput{Contracts: make([]contractOutput, 0, len(cs)), Version: version}
	for _, c := range cs {
		co := contractOutput{Key: c.source + ":" + c.name}
		if o.emitABI {
			co.ABI = c.items
			if co.ABI == nil { co.ABI = []abiItem{} }
			co.HasABI = true
		}
		if o.emitHashes {
			co.Hashes = map[string]string{}
			for _, it := range c.items {
				if it.Type == "function" {
					sig := signature(it)
					co.Hashes[sig] = selector(sig)
				}
			}
			co.HasHashes = true
		}
		oo.Contracts = append(oo.Contracts, co)
	}
	return oo
}

type orderedOutput struct {
	Contracts []contractOutput
	Version   string
}
type contractOutput struct {
	Key       string
	ABI       []abiItem
	HasABI    bool
	Hashes    map[string]string
	HasHashes bool
}

func (o orderedOutput) MarshalJSON() ([]byte, error) {
	var b bytes.Buffer
	b.WriteString(`{"contracts":{`)
	for i, c := range o.Contracts {
		if i > 0 { b.WriteByte(',') }
		b.WriteString(strconv.Quote(c.Key)); b.WriteByte(':')
		b.WriteByte('{')
		first := true
		if c.HasABI {
			b.WriteString(`"abi":`)
			ab, _ := json.Marshal(c.ABI); b.Write(ab); first = false
		}
		if c.HasHashes {
			if !first { b.WriteByte(',') }
			b.WriteString(`"hashes":`)
			keys := make([]string, 0, len(c.Hashes))
			for k := range c.Hashes { keys = append(keys, k) }
			sort.Strings(keys)
			b.WriteByte('{')
			for j, k := range keys {
				if j > 0 { b.WriteByte(',') }
				jk, _ := json.Marshal(k); jv, _ := json.Marshal(c.Hashes[k])
				b.Write(jk); b.WriteByte(':'); b.Write(jv)
			}
			b.WriteByte('}')
		}
		b.WriteByte('}')
	}
	b.WriteString(`},"version":"` + o.Version + `"}`)
	return b.Bytes(), nil
}

func signature(it abiItem) string {
	types := make([]string, len(it.Inputs))
	for i, p := range it.Inputs { types[i] = p.Type }
	return it.Name + "(" + strings.Join(types, ",") + ")"
}

func selector(sig string) string {
	h := keccak256([]byte(sig))
	return hex.EncodeToString(h[:4])
}

func emitError(o options, msg string) {
	if o.errFormat == "json" || o.errFormat == "rustc-json" {
		fmt.Fprintf(os.Stderr, `{"sourceLocation":null,"secondarySourceLocations":[],"type":"Exception","component":"general","severity":"error","errorCode":null,"message":%q,"formattedMessage":%q}`+"\n", msg, "error: "+msg+"\n\n")
		return
	}
	fmt.Fprintf(os.Stderr, "error: %s\n\nerror: aborting due to 1 previous error\n\n", msg)
}

func printHelp(long bool) {
	if !long {
		fmt.Print(`Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
`)
		return
	}
	fmt.Print(`Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Files to compile, or import remappings.
          
          '-' specifies standard input.

Options:
  -j, --threads <THREADS>
          Number of threads to use. Zero specifies the number of logical cores
          
          [default: 4]
          [aliases: --jobs]

      --evm-version <EVM_VERSION>
          EVM version
          
          [default: prague]
          [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]

      --stop-after <STOP_AFTER>
          Stop execution after the given compiler stage
          
          [possible values: parsing, lowering, analysis]

      --out-dir <OUT_DIR>
          Directory to write output files

      --emit <EMIT>
          Comma separated list of types of output for the compiler to emit
          
          [possible values: abi, hashes]

  -Z <FLAG>
          Unstable flags. WARNING: these are completely unstable, and may change at any time.
          
          See '-Zhelp' for more details.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`)
}

func printZHelp() {
	fmt.Print(`error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.
          
          This is enabled by default on debug builds.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.
          
          Valid kinds are 'ast' and 'hir'.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'.
`)
}

// Minimal Keccak-256 implementation for Ethereum selectors.
func keccak256(data []byte) []byte {
	var a [25]uint64
	const rate = 136
	for len(data) >= rate {
		for i := 0; i < rate/8; i++ { a[i] ^= binary.LittleEndian.Uint64(data[i*8:]) }
		keccakF(&a)
		data = data[rate:]
	}
	var block [rate]byte
	copy(block[:], data)
	block[len(data)] = 0x01
	block[rate-1] ^= 0x80
	for i := 0; i < rate/8; i++ { a[i] ^= binary.LittleEndian.Uint64(block[i*8:]) }
	keccakF(&a)
	out := make([]byte, 32)
	for i := 0; i < 4; i++ { binary.LittleEndian.PutUint64(out[i*8:], a[i]) }
	return out
}

func keccakF(a *[25]uint64) {
	rc := [24]uint64{0x0000000000000001,0x0000000000008082,0x800000000000808a,0x8000000080008000,0x000000000000808b,0x0000000080000001,0x8000000080008081,0x8000000000008009,0x000000000000008a,0x0000000000000088,0x0000000080008009,0x000000008000000a,0x000000008000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x000000000000800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008}
	rot := [25]uint{0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14}
	pi := [25]int{0,10,20,5,15,16,1,11,21,6,7,17,2,12,22,23,8,18,3,13,14,24,9,19,4}
	for round := 0; round < 24; round++ {
		var c, d [5]uint64
		for x := 0; x < 5; x++ { c[x] = a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20] }
		for x := 0; x < 5; x++ { d[x] = c[(x+4)%5] ^ bitsRotateLeft64(c[(x+1)%5], 1) }
		for x := 0; x < 5; x++ { for y := 0; y < 5; y++ { a[x+5*y] ^= d[x] } }
		var b [25]uint64
		for i := 0; i < 25; i++ { b[pi[i]] = bitsRotateLeft64(a[i], rot[i]) }
		for y := 0; y < 5; y++ {
			for x := 0; x < 5; x++ { a[x+5*y] = b[x+5*y] ^ ((^b[((x+1)%5)+5*y]) & b[((x+2)%5)+5*y]) }
		}
		a[0] ^= rc[round]
	}
}

func bitsRotateLeft64(x uint64, k uint) uint64 {
	if k == 0 { return x }
	return (x << k) | (x >> (64 - k))
}
