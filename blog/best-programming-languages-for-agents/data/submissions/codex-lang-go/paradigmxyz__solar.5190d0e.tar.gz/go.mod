module solarclone

go 1.21
