module calcurse-reimpl

go 1.21
