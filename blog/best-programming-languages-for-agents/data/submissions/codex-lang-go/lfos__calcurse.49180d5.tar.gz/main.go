package main

import (
	"bufio"
	"crypto/sha1"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type ItemType int

const (
	TypeApt ItemType = iota
	TypeEvent
	TypeTodo
)

type Item struct {
	Type      ItemType
	Start     time.Time
	End       time.Time
	Days      int
	Recur     string
	Note      string
	Summary   string
	Priority  int
	Completed bool
	Raw       string
}

type Opts struct {
	datadir, calfile string
	inputFmt         int
	outputFmt        string
	mode             string
	importFile       string
	exportFmt        string
	from, to         string
	days             string
	dayArg           string
	rangeArg         string
	startArg         string
	todoArg          string
	search           string
	limit            int
	filterType       string
	filterPattern    string
	filterPriority   string
	filterCompleted  *bool
	formatApt        string
	formatEvent      string
	formatTodo       string
	quiet            bool
	readOnly         bool
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if opts.inputFmt == 0 {
		opts.inputFmt = 1
	}
	if opts.outputFmt == "" {
		opts.outputFmt = "%m/%d/%y"
	}
	if opts.datadir == "" {
		opts.datadir = defaultDataDir()
	}
	if opts.calfile == "" {
		opts.calfile = filepath.Join(opts.datadir, "apts")
	}

	switch opts.mode {
	case "help", "":
		printHelp()
	case "version":
		fmt.Println("calcurse 4.8.2 -- text-based organizer")
		fmt.Println()
		fmt.Println("Copyright (c) 2004-2023 calcurse Development Team.")
		fmt.Println("This is free software; see the source for copying conditions.")
	case "status":
		fmt.Println("calcurse is not running")
	case "gc":
		ensureDirs(opts.datadir)
	case "daemon":
		fmt.Fprintln(os.Stderr, "daemon mode is not available in this reimplementation")
		os.Exit(1)
	case "import":
		if err := importICal(opts); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	case "export":
		items := loadItems(opts)
		printICal(items)
	case "grep":
		items := applyFilters(loadItems(opts), opts)
		printRaw(items, opts)
	case "purge":
		items := applyFilters(loadItems(opts), opts)
		remove := map[string]bool{}
		for _, it := range items {
			remove[it.Raw] = true
		}
		all := loadItems(opts)
		var keep []Item
		for _, it := range all {
			if !remove[it.Raw] {
				keep = append(keep, it)
			}
		}
		saveItems(opts, keep)
	case "query":
		items := applyFilters(loadItems(opts), opts)
		printQuery(items, opts)
	}
}

func parseArgs(args []string) (Opts, error) {
	o := Opts{limit: -1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("%s requires an argument", a)
			}
			i++
			return args[i], nil
		}
		switch {
		case a == "-h" || a == "--help":
			o.mode = "help"
		case a == "-v" || a == "--version":
			o.mode = "version"
		case a == "--status":
			o.mode = "status"
		case a == "-g" || a == "--gc":
			o.mode = "gc"
		case a == "--daemon":
			o.mode = "daemon"
		case a == "-Q" || a == "--query":
			o.mode = "query"
		case a == "-G" || a == "--grep":
			o.mode = "grep"
		case a == "-P" || a == "--purge" || a == "-F" || a == "--filter":
			o.mode = "purge"
		case a == "-a" || a == "--appointment":
			o.mode = "query"
			o.filterType = "cal"
		case a == "-n" || a == "--next":
			o.mode = "query"
			o.filterType = "apt"
			o.days = "1"
			o.limit = 1
		case a == "-D" || a == "--datadir":
			v, e := next(); if e != nil { return o, e }; o.datadir = v
		case a == "-C" || a == "--confdir":
			_, e := next(); if e != nil { return o, e }
		case a == "-c" || a == "--calendar":
			v, e := next(); if e != nil { return o, e }; o.calfile = v
		case a == "-i" || a == "--import":
			v, e := next(); if e != nil { return o, e }; o.mode = "import"; o.importFile = v
		case a == "-q" || a == "--quiet":
			o.quiet = true
		case a == "--read-only":
			o.readOnly = true
		case a == "--from":
			v, e := next(); if e != nil { return o, e }; o.from = v
		case a == "--to":
			v, e := next(); if e != nil { return o, e }; o.to = v
		case a == "--days":
			v, e := next(); if e != nil { return o, e }; o.days = v
		case a == "--input-datefmt":
			v, e := next(); if e != nil { return o, e }; n, _ := strconv.Atoi(v); o.inputFmt = n
		case a == "--output-datefmt":
			v, e := next(); if e != nil { return o, e }; o.outputFmt = v
		case a == "-l" || a == "--limit":
			v, e := next(); if e != nil { return o, e }; o.limit, _ = strconv.Atoi(v)
		case a == "-S" || a == "--search" || a == "--filter-pattern":
			v, e := next(); if e != nil { return o, e }; o.search = v; o.filterPattern = v
		case a == "--filter-type":
			v, e := next(); if e != nil { return o, e }; o.filterType = v
		case a == "--filter-priority":
			v, e := next(); if e != nil { return o, e }; o.filterPriority = v
		case a == "--filter-completed":
			b := true; o.filterCompleted = &b
		case a == "--filter-uncompleted":
			b := false; o.filterCompleted = &b
		case a == "--format-apt" || a == "--format-recur-apt":
			v, e := next(); if e != nil { return o, e }; o.formatApt = v
		case a == "--format-event" || a == "--format-recur-event":
			v, e := next(); if e != nil { return o, e }; o.formatEvent = v
		case a == "--format-todo":
			v, e := next(); if e != nil { return o, e }; o.formatTodo = v
		case strings.HasPrefix(a, "-d") && a != "-D":
			o.mode = "query"; o.filterType = "cal"
			if a == "-d" || a == "--day" {
				v, e := next(); if e != nil { return o, e }; o.dayArg = v
			} else {
				o.dayArg = strings.TrimPrefix(a, "-d")
			}
		case strings.HasPrefix(a, "-r") || strings.HasPrefix(a, "--range"):
			o.mode = "query"; o.filterType = "cal"
			o.rangeArg = "1"
			if a == "-r" {
				if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") { i++; o.rangeArg = args[i] }
			} else if strings.HasPrefix(a, "-r") {
				o.rangeArg = strings.TrimPrefix(a, "-r")
			} else if strings.Contains(a, "=") {
				o.rangeArg = strings.SplitN(a, "=", 2)[1]
			}
			o.days = o.rangeArg
		case strings.HasPrefix(a, "-s") || strings.HasPrefix(a, "--startday"):
			o.mode = "query"; o.filterType = "cal"; o.startArg = "today"
			if a == "-s" {
				if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") { i++; o.startArg = args[i] }
			} else if strings.HasPrefix(a, "-s") {
				o.startArg = strings.TrimPrefix(a, "-s")
			} else if strings.Contains(a, "=") {
				o.startArg = strings.SplitN(a, "=", 2)[1]
			}
			o.from = o.startArg
		case strings.HasPrefix(a, "-t") || strings.HasPrefix(a, "--todo"):
			o.mode = "query"; o.filterType = "todo"
			if a == "-t" {
				if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") { i++; o.todoArg = args[i] }
			} else if strings.HasPrefix(a, "-t") {
				o.todoArg = strings.TrimPrefix(a, "-t")
			} else if strings.Contains(a, "=") {
				o.todoArg = strings.SplitN(a, "=", 2)[1]
			}
			if o.todoArg != "" {
				o.filterPriority = o.todoArg
				if o.todoArg == "0" { b := true; o.filterCompleted = &b } else { b := false; o.filterCompleted = &b }
			} else {
				b := false; o.filterCompleted = &b
			}
		case strings.HasPrefix(a, "-x") || strings.HasPrefix(a, "--export"):
			o.mode = "export"; o.exportFmt = "ical"
		default:
			if a == "--export-uid" || a == "--dump-imported" || strings.HasPrefix(a, "--filter-") {
				if strings.Contains(a, "range") || strings.Contains(a, "from") || strings.Contains(a, "to") || strings.Contains(a, "before") || strings.Contains(a, "after") || strings.Contains(a, "hash") {
					if i+1 < len(args) { i++ }
				}
				continue
			}
		}
	}
	if o.dayArg != "" {
		if _, err := strconv.Atoi(o.dayArg); err == nil {
			o.days = o.dayArg
		} else {
			o.from = o.dayArg
		}
	}
	return o, nil
}

func printHelp() {
	fmt.Print(`Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.
`)
}

func defaultDataDir() string {
	home, _ := os.UserHomeDir()
	if _, err := os.Stat(filepath.Join(home, ".calcurse")); err == nil {
		return filepath.Join(home, ".calcurse")
	}
	if x := os.Getenv("XDG_DATA_HOME"); x != "" {
		return filepath.Join(x, "calcurse")
	}
	return filepath.Join(home, ".local", "share", "calcurse")
}

func ensureDirs(dir string) {
	os.MkdirAll(filepath.Join(dir, "notes"), 0755)
	os.MkdirAll(filepath.Join(dir, "hooks"), 0755)
}

func loadItems(o Opts) []Item {
	var items []Item
	if b, err := os.ReadFile(filepath.Join(o.datadir, "todo")); err == nil {
		sc := bufio.NewScanner(strings.NewReader(string(b)))
		for sc.Scan() {
			line := strings.TrimRight(sc.Text(), "\r")
			if strings.TrimSpace(line) == "" { continue }
			it := parseTodoLine(line)
			items = append(items, it)
		}
	}
	if b, err := os.ReadFile(o.calfile); err == nil {
		sc := bufio.NewScanner(strings.NewReader(string(b)))
		for sc.Scan() {
			line := strings.TrimRight(sc.Text(), "\r")
			if strings.TrimSpace(line) == "" { continue }
			if it, ok := parseAptLine(line); ok {
				items = append(items, it)
			}
		}
	}
	return items
}

func parseTodoLine(line string) Item {
	it := Item{Type: TypeTodo, Priority: 0, Raw: line}
	re := regexp.MustCompile(`^\[(-?\d+)\]\s*(.*)$`)
	if m := re.FindStringSubmatch(line); m != nil {
		p, _ := strconv.Atoi(m[1])
		if p < 0 { it.Completed = true; p = -p }
		it.Priority = p
		it.Summary = m[2]
	} else {
		it.Summary = line
	}
	return it
}

func parseAptLine(line string) (Item, bool) {
	raw := line
	dateRe := `(\d{1,2})/(\d{1,2})/(\d{4})`
	if strings.Contains(line, " @ ") {
		re := regexp.MustCompile(`^` + dateRe + ` @ (\d{1,2}):(\d{2}) -> ` + dateRe + ` @ (\d{1,2}):(\d{2})(?: \{([^}]*)\})?(?: >[0-9a-f]+)?\|(.*)$`)
		m := re.FindStringSubmatch(line)
		if m == nil { return Item{}, false }
		start := makeTime(m[3], m[1], m[2], m[4], m[5])
		end := makeTime(m[8], m[6], m[7], m[9], m[10])
		return Item{Type: TypeApt, Start: start, End: end, Recur: m[11], Summary: m[12], Raw: raw}, true
	}
	re := regexp.MustCompile(`^` + dateRe + ` \[(\d+)\](?: \{([^}]*)\})?(?: >[0-9a-f]+)? (.*)$`)
	m := re.FindStringSubmatch(line)
	if m == nil { return Item{}, false }
	days, _ := strconv.Atoi(m[4])
	start := makeDate(m[3], m[1], m[2])
	end := start.AddDate(0, 0, days)
	recur := m[5]
	recurFields := strings.Fields(recur)
	if len(recurFields) > 0 && strings.HasSuffix(recurFields[0], "D") && strings.Contains(recur, " -> ") {
		if len(recurFields) >= 3 {
			if e, err := parseUSDate(recurFields[2]); err == nil && !e.Before(start) {
				end = e.AddDate(0, 0, 1)
				days = int(end.Sub(start).Hours() / 24)
				recur = ""
			}
		}
	}
	return Item{Type: TypeEvent, Start: start, End: end, Days: days, Recur: recur, Summary: m[6], Raw: raw}, true
}

func makeDate(y, mo, d string) time.Time {
	yy, _ := strconv.Atoi(y); mm, _ := strconv.Atoi(mo); dd, _ := strconv.Atoi(d)
	return time.Date(yy, time.Month(mm), dd, 0, 0, 0, 0, time.Local)
}

func makeTime(y, mo, d, h, mi string) time.Time {
	t := makeDate(y, mo, d)
	hh, _ := strconv.Atoi(h); mn, _ := strconv.Atoi(mi)
	return time.Date(t.Year(), t.Month(), t.Day(), hh, mn, 0, 0, time.Local)
}

func saveItems(o Opts, items []Item) {
	if o.readOnly { return }
	ensureDirs(o.datadir)
	var todos, apts []string
	for _, it := range items {
		if it.Type == TypeTodo { todos = append(todos, it.Raw) } else { apts = append(apts, it.Raw) }
	}
	os.WriteFile(filepath.Join(o.datadir, "todo"), []byte(strings.Join(todos, "\n")+"\n"), 0644)
	os.WriteFile(o.calfile, []byte(strings.Join(apts, "\n")+"\n"), 0644)
}

func applyFilters(items []Item, o Opts) []Item {
	var out []Item
	var re *regexp.Regexp
	if o.filterPattern != "" {
		re, _ = regexp.Compile(o.filterPattern)
	}
	allowed := typeSet(o.filterType)
	for _, it := range items {
		if allowed != nil && !allowed[it.Type] { continue }
		if re != nil && !re.MatchString(it.Summary) { continue }
		if o.filterPriority != "" && it.Type == TypeTodo {
			p, _ := strconv.Atoi(o.filterPriority)
			if p != 0 && it.Priority != p { continue }
		}
		if o.filterCompleted != nil && it.Type == TypeTodo && it.Completed != *o.filterCompleted { continue }
		out = append(out, it)
	}
	return out
}

func typeSet(s string) map[ItemType]bool {
	if s == "" { return nil }
	m := map[ItemType]bool{}
	for _, p := range strings.Split(s, ",") {
		switch strings.TrimSpace(p) {
		case "cal":
			m[TypeApt], m[TypeEvent] = true, true
		case "apt", "recur-apt":
			m[TypeApt] = true
		case "event", "recur-event":
			m[TypeEvent] = true
		case "todo":
			m[TypeTodo] = true
		case "recur":
			m[TypeApt], m[TypeEvent] = true, true
		}
	}
	return m
}

func parseDateArg(s string, fmtNo int) (time.Time, error) {
	now := time.Now()
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	sl := strings.ToLower(s)
	switch sl {
	case "", "today", "now":
		return today, nil
	case "tomorrow":
		return today.AddDate(0, 0, 1), nil
	case "yesterday":
		return today.AddDate(0, 0, -1), nil
	}
	wds := map[string]time.Weekday{"sun": time.Sunday, "sunday": time.Sunday, "mon": time.Monday, "monday": time.Monday, "tue": time.Tuesday, "tuesday": time.Tuesday, "wed": time.Wednesday, "wednesday": time.Wednesday, "thu": time.Thursday, "thursday": time.Thursday, "fri": time.Friday, "friday": time.Friday, "sat": time.Saturday, "saturday": time.Saturday}
	if wd, ok := wds[sl]; ok {
		delta := (int(wd) - int(today.Weekday()) + 7) % 7
		return today.AddDate(0, 0, delta), nil
	}
	part := strings.Fields(s)[0]
	var layouts []string
	switch fmtNo {
	case 2:
		layouts = []string{"02/01/2006", "2/1/2006", "02/01/06", "2/1/06"}
	case 3:
		layouts = []string{"2006/01/02", "2006/1/2"}
	case 4:
		layouts = []string{"2006-01-02", "2006-1-2"}
	default:
		layouts = []string{"01/02/2006", "1/2/2006", "01/02/06", "1/2/06"}
	}
	for _, l := range layouts {
		if t, err := time.ParseInLocation(l, part, time.Local); err == nil {
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("invalid date: %s", s)
}

func queryRange(o Opts) (time.Time, time.Time) {
	from, err := parseDateArg(o.from, o.inputFmt)
	if err != nil { from, _ = parseDateArg("today", o.inputFmt) }
	to := from
	if o.to != "" {
		if t, err := parseDateArg(o.to, o.inputFmt); err == nil { to = t }
	} else if o.days != "" {
		n, _ := strconv.Atoi(o.days)
		if n == 0 { n = 1 }
		if n > 0 { to = from.AddDate(0, 0, n-1) } else { to = from; from = from.AddDate(0, 0, n+1) }
	}
	return dateOnly(from), dateOnly(to)
}

func printQuery(items []Item, o Opts) {
	from, to := queryRange(o)
	var todos, cals []Item
	for _, it := range items {
		if it.Type == TypeTodo { todos = append(todos, it) } else { cals = append(cals, it) }
	}
	count := 0
	if typeSet(o.filterType) == nil || typeSet(o.filterType)[TypeTodo] {
		if len(todos) > 0 {
			fmt.Println("to do:")
			for _, it := range todos {
				if o.limit >= 0 && count >= o.limit { break }
				if o.formatTodo != "" {
					fmt.Print(formatItem(o.formatTodo, it))
				} else {
					fmt.Printf("%d. %s\n", it.Priority, it.Summary)
				}
				count++
			}
			fmt.Println()
		}
	}
	if typeSet(o.filterType) != nil && !typeSet(o.filterType)[TypeApt] && !typeSet(o.filterType)[TypeEvent] { return }
	var dayBlocks []string
	for d := from; !d.After(to); d = d.AddDate(0, 0, 1) {
		var dayItems []Item
		for _, it := range cals {
			if occursOn(it, d) {
				dayItems = append(dayItems, it)
			}
		}
		if len(dayItems) == 0 { continue }
		sort.SliceStable(dayItems, func(i, j int) bool {
			if dayItems[i].Type != dayItems[j].Type { return dayItems[i].Type == TypeEvent }
			if dayItems[i].Type == TypeEvent && !dateOnly(dayItems[i].Start).Equal(dateOnly(dayItems[j].Start)) {
				ai := dateOnly(dayItems[i].Start).Equal(d)
				aj := dateOnly(dayItems[j].Start).Equal(d)
				if ai != aj { return ai }
			}
			return dayItems[i].Start.Before(dayItems[j].Start)
		})
		var b strings.Builder
		fmt.Fprintf(&b, "%s:\n", strftime(d, o.outputFmt))
		for _, it := range dayItems {
			if o.limit >= 0 && count >= o.limit { return }
			if it.Type == TypeEvent {
				if o.formatEvent != "" { b.WriteString(formatItem(o.formatEvent, it)) } else { fmt.Fprintf(&b, " * %s\n", it.Summary) }
			} else {
				if o.formatApt != "" { b.WriteString(formatItem(o.formatApt, it)) } else { fmt.Fprintf(&b, " - %s -> %s\n\t%s\n", displayStart(it, d), displayEnd(it, d), it.Summary) }
			}
			count++
		}
		dayBlocks = append(dayBlocks, strings.TrimRight(b.String(), "\n"))
	}
	if len(dayBlocks) > 0 {
		fmt.Print(strings.Join(dayBlocks, "\n\n"))
		fmt.Println()
	}
}

func occursOn(it Item, d time.Time) bool {
	d = dateOnly(d)
	if it.Recur != "" {
		return recurOccurs(it, d)
	}
	if it.Type == TypeEvent {
		return !d.Before(dateOnly(it.Start)) && d.Before(dateOnly(it.End))
	}
	return !d.Before(dateOnly(it.Start)) && !d.After(dateOnly(it.End))
}

func recurOccurs(it Item, d time.Time) bool {
	start := dateOnly(it.Start)
	if d.Before(start) { return false }
	until := time.Date(2100, 1, 1, 0, 0, 0, 0, time.Local)
	step := 1
	unit := "D"
	fields := strings.Fields(it.Recur)
	if len(fields) >= 1 {
		p := fields[0]
		if len(p) > 1 {
			step, _ = strconv.Atoi(p[:len(p)-1])
			unit = p[len(p)-1:]
		}
	}
	if len(fields) >= 3 && fields[1] == "->" {
		if u, err := parseUSDate(fields[2]); err == nil { until = u }
	}
	if d.After(until) { return false }
	for _, f := range fields {
		if strings.HasPrefix(f, "!") {
			if ex, err := parseUSDate(strings.TrimPrefix(f, "!")); err == nil && dateOnly(ex).Equal(d) { return false }
		}
	}
	switch unit {
	case "D":
		return int(d.Sub(start).Hours()/24)%max(1, step) == 0
	case "W":
		return int(d.Sub(start).Hours()/24)%(7*max(1, step)) == 0
	case "M":
		months := (d.Year()-start.Year())*12 + int(d.Month()-start.Month())
		return months >= 0 && months%max(1, step) == 0 && d.Day() == start.Day()
	case "Y":
		return d.Month() == start.Month() && d.Day() == start.Day() && (d.Year()-start.Year())%max(1, step) == 0
	}
	return false
}

func parseUSDate(s string) (time.Time, error) {
	return time.ParseInLocation("01/02/2006", s, time.Local)
}

func dateOnly(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, time.Local)
}

func displayStart(it Item, d time.Time) string {
	if it.Recur != "" { return it.Start.Format("15:04") }
	if dateOnly(it.Start).Before(dateOnly(d)) { return "..:.." }
	return it.Start.Format("15:04")
}

func displayEnd(it Item, d time.Time) string {
	if it.Recur != "" { return it.End.Format("15:04") }
	if dateOnly(it.End).After(dateOnly(d)) { return "..:.." }
	return it.End.Format("15:04")
}

func printRaw(items []Item, o Opts) {
	count := 0
	for _, it := range items {
		if o.limit >= 0 && count >= o.limit { break }
		switch it.Type {
		case TypeTodo:
			if o.formatTodo != "" { fmt.Print(formatItem(o.formatTodo, it)) } else { fmt.Println(it.Raw) }
		case TypeEvent:
			if o.formatEvent != "" { fmt.Print(formatItem(o.formatEvent, it)) } else { fmt.Println(it.Raw) }
		case TypeApt:
			if o.formatApt != "" { fmt.Print(formatItem(o.formatApt, it)) } else { fmt.Println(it.Raw) }
		}
		count++
	}
}

func formatItem(f string, it Item) string {
	if f == "%(raw)" { return it.Raw + "\n" }
	if strings.Contains(f, "%(hash)") {
		h := sha1.Sum([]byte(it.Raw))
		f = strings.ReplaceAll(f, "%(hash)", hex.EncodeToString(h[:]))
	}
	f = strings.ReplaceAll(f, `\n`, "\n")
	f = strings.ReplaceAll(f, `\t`, "\t")
	f = strings.ReplaceAll(f, "%m", it.Summary)
	f = strings.ReplaceAll(f, "%p", strconv.Itoa(it.Priority))
	f = strings.ReplaceAll(f, "%S", it.Start.Format("15:04"))
	f = strings.ReplaceAll(f, "%E", it.End.Format("15:04"))
	f = strings.ReplaceAll(f, "%s", strconv.FormatInt(it.Start.Unix(), 10))
	f = strings.ReplaceAll(f, "%e", strconv.FormatInt(it.End.Unix(), 10))
	f = strings.ReplaceAll(f, "%d", strconv.Itoa(int(it.End.Sub(it.Start).Seconds())))
	f = strings.ReplaceAll(f, "%n", it.Note)
	f = strings.ReplaceAll(f, "%N", "")
	return f
}

func strftime(t time.Time, f string) string {
	r := f
	repls := map[string]string{"%Y": "2006", "%y": "06", "%m": "01", "%d": "02", "%e": "_2", "%H": "15", "%M": "04", "%S": "05", "%F": "2006-01-02"}
	for k, v := range repls { r = strings.ReplaceAll(r, k, t.Format(v)) }
	return r
}

func importICal(o Opts) error {
	b, err := os.ReadFile(o.importFile)
	if err != nil { return err }
	text := strings.ReplaceAll(string(b), "\r\n", "\n")
	lines := unfold(strings.Split(text, "\n"))
	var items []Item
	var skipped int
	for i := 0; i < len(lines); i++ {
		line := strings.TrimRight(lines[i], "\r")
		if line == "BEGIN:VEVENT" || line == "BEGIN:VTODO" {
			kind := line
			var block []string
			for i++; i < len(lines); i++ {
				if (kind == "BEGIN:VEVENT" && lines[i] == "END:VEVENT") || (kind == "BEGIN:VTODO" && lines[i] == "END:VTODO") { break }
				block = append(block, lines[i])
			}
			it, ok := parseICalBlock(kind, block)
			if ok { items = append(items, it) } else { skipped++ }
		}
	}
	if !o.readOnly {
		existing := loadItems(o)
		items = append(existing, items...)
		saveSorted(o, items)
	}
	if !o.quiet {
		apps, events, todos := 0, 0, 0
		for _, it := range items {
			if it.Type == TypeTodo { todos++ } else if it.Type == TypeEvent { events++ } else { apps++ }
		}
		fmt.Printf("Import process report: %04d lines read\n", len(strings.Split(text, "\n"))-1)
		fmt.Printf("%d %s / %d %s / %d %s / %d skipped\n", apps, plural(apps, "app", "apps"), events, plural(events, "event", "events"), todos, plural(todos, "todo", "todos"), skipped)
	}
	return nil
}

func unfold(lines []string) []string {
	var out []string
	for _, l := range lines {
		if (strings.HasPrefix(l, " ") || strings.HasPrefix(l, "\t")) && len(out) > 0 {
			out[len(out)-1] += strings.TrimLeft(l, " \t")
		} else {
			out = append(out, strings.TrimRight(l, "\r"))
		}
	}
	return out
}

func parseICalBlock(kind string, lines []string) (Item, bool) {
	props := map[string][]string{}
	for _, l := range lines {
		k, v, ok := splitProp(l)
		if !ok { continue }
		props[k] = append(props[k], v)
	}
	if kind == "BEGIN:VTODO" {
		p := 0
		if len(props["PRIORITY"]) > 0 { p, _ = strconv.Atoi(props["PRIORITY"][0]) }
		if p < 0 || p > 9 { return Item{}, false }
		if p == 0 { p = 9 }
		sum := first(props["SUMMARY"])
		raw := fmt.Sprintf("[%d] %s", p, unescape(sum))
		return Item{Type: TypeTodo, Priority: p, Summary: unescape(sum), Raw: raw}, true
	}
	startStr := first(props["DTSTART"])
	if startStr == "" { return Item{}, false }
	allDay := len(startStr) == 8
	start, ok := parseICalTime(startStr)
	if !ok { return Item{}, false }
	sum := unescape(first(props["SUMMARY"]))
	end := start
	if len(props["DTEND"]) > 0 {
		if e, ok := parseICalTime(props["DTEND"][0]); ok { end = e }
	} else if len(props["DURATION"]) > 0 {
		end = start.Add(parseDuration(props["DURATION"][0]))
	} else if allDay {
		end = start.AddDate(0, 0, 1)
	} else {
		end = start
	}
	it := Item{Type: TypeApt, Start: start, End: end, Summary: sum}
	if allDay {
		it.Type = TypeEvent
		it.Days = int(dateOnly(end).Sub(dateOnly(start)).Hours()/24)
		if it.Days <= 0 { it.Days = 1; it.End = start.AddDate(0, 0, 1) }
	}
	if len(props["RRULE"]) > 0 {
		it.Recur = convertRRule(props["RRULE"][0], start, props["EXDATE"])
	}
	it.Raw = rawLine(it)
	return it, true
}

func splitProp(l string) (string, string, bool) {
	idx := strings.Index(l, ":")
	if idx < 0 { return "", "", false }
	name := l[:idx]
	if semi := strings.Index(name, ";"); semi >= 0 { name = name[:semi] }
	return strings.ToUpper(name), l[idx+1:], true
}

func first(v []string) string {
	if len(v) == 0 { return "" }
	return v[0]
}

func parseICalTime(s string) (time.Time, bool) {
	s = strings.TrimSuffix(s, "Z")
	layouts := []string{"20060102T150405", "20060102T1504", "20060102"}
	for _, l := range layouts {
		if t, err := time.ParseInLocation(l, s, time.Local); err == nil { return t, true }
	}
	return time.Time{}, false
}

func parseDuration(s string) time.Duration {
	re := regexp.MustCompile(`P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?`)
	m := re.FindStringSubmatch(s)
	if m == nil { return 0 }
	val := func(i int) int { n, _ := strconv.Atoi(m[i]); return n }
	return time.Duration(val(1))*24*time.Hour + time.Duration(val(2))*time.Hour + time.Duration(val(3))*time.Minute + time.Duration(val(4))*time.Second
}

func convertRRule(rr string, start time.Time, ex []string) string {
	parts := map[string]string{}
	for _, p := range strings.Split(rr, ";") {
		kv := strings.SplitN(p, "=", 2)
		if len(kv) == 2 { parts[kv[0]] = kv[1] }
	}
	step := parts["INTERVAL"]
	if step == "" { step = "1" }
	unit := map[string]string{"DAILY": "D", "WEEKLY": "W", "MONTHLY": "M", "YEARLY": "Y"}[parts["FREQ"]]
	if unit == "" { unit = "D" }
	until := start.AddDate(10, 0, 0)
	if parts["UNTIL"] != "" {
		if t, ok := parseICalTime(parts["UNTIL"]); ok { until = t }
	} else if parts["COUNT"] != "" {
		c, _ := strconv.Atoi(parts["COUNT"])
		if c <= 0 { c = 1 }
		switch unit {
		case "D": until = start.AddDate(0, 0, (c-1)*atoi(step))
		case "W": until = start.AddDate(0, 0, 7*(c-1)*atoi(step))
		case "M": until = start.AddDate(0, (c-1)*atoi(step), 0)
		case "Y": until = start.AddDate((c-1)*atoi(step), 0, 0)
		}
	}
	out := fmt.Sprintf("%s%s -> %s", step, unit, until.Format("01/02/2006"))
	for _, exl := range ex {
		for _, e := range strings.Split(exl, ",") {
			if t, ok := parseICalTime(e); ok { out += " !" + t.Format("01/02/2006") }
		}
	}
	return out
}

func atoi(s string) int { n, _ := strconv.Atoi(s); if n == 0 { return 1 }; return n }

func unescape(s string) string {
	s = strings.ReplaceAll(s, `\n`, "\n")
	s = strings.ReplaceAll(s, `\,`, ",")
	s = strings.ReplaceAll(s, `\;`, ";")
	s = strings.ReplaceAll(s, `\\`, `\`)
	return s
}

func escape(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, "\n", `\n`)
	s = strings.ReplaceAll(s, ",", `\,`)
	s = strings.ReplaceAll(s, ";", `\;`)
	return s
}

func rawLine(it Item) string {
	if it.Type == TypeTodo {
		p := it.Priority
		if it.Completed { p = -p }
		return fmt.Sprintf("[%d] %s", p, it.Summary)
	}
	if it.Type == TypeEvent {
		if it.Days > 1 {
			h := sha1.Sum([]byte(it.Summary))
			return fmt.Sprintf("%s [1] {%dD -> %s} >%s %s", it.Start.Format("01/02/2006"), it.Days-1, it.End.AddDate(0, 0, -1).Format("01/02/2006"), hex.EncodeToString(h[:]), it.Summary)
		}
		return fmt.Sprintf("%s [%d] %s", it.Start.Format("01/02/2006"), max(1, it.Days), it.Summary)
	}
	line := fmt.Sprintf("%s @ %s -> %s @ %s", it.Start.Format("01/02/2006"), it.Start.Format("15:04"), it.End.Format("01/02/2006"), it.End.Format("15:04"))
	if it.Recur != "" { line += " {" + it.Recur + "}" }
	return line + "|" + it.Summary
}

func saveSorted(o Opts, items []Item) {
	sort.SliceStable(items, func(i, j int) bool {
		a, b := items[i], items[j]
		if a.Type == TypeTodo && b.Type != TypeTodo { return true }
		if a.Type != TypeTodo && b.Type == TypeTodo { return false }
		if !a.Start.Equal(b.Start) { return a.Start.Before(b.Start) }
		if !a.End.Equal(b.End) { return a.End.Before(b.End) }
		return a.Summary < b.Summary
	})
	saveItems(o, items)
}

func printICal(items []Item) {
	fmt.Println("BEGIN:VCALENDAR")
	fmt.Println("VERSION:2.0")
	fmt.Println("PRODID:-//calcurse//NONSGML v4.8.2//EN")
	for _, it := range items {
		switch it.Type {
		case TypeTodo:
			fmt.Println("BEGIN:VTODO")
			fmt.Printf("PRIORITY:%d\n", it.Priority)
			fmt.Printf("SUMMARY:%s\n", escape(it.Summary))
			fmt.Println("END:VTODO")
		case TypeEvent:
			fmt.Println("BEGIN:VEVENT")
			fmt.Printf("DTSTART;VALUE=DATE:%s\n", it.Start.Format("20060102"))
			fmt.Printf("DTEND;VALUE=DATE:%s\n", it.End.Format("20060102"))
			fmt.Printf("SUMMARY:%s\n", escape(it.Summary))
			fmt.Println("END:VEVENT")
		case TypeApt:
			fmt.Println("BEGIN:VEVENT")
			fmt.Printf("DTSTART:%s\n", it.Start.Format("20060102T150405"))
			d := int(it.End.Sub(it.Start).Seconds())
			fmt.Printf("DURATION:P%dDT%dH%dM%dS\n", d/86400, (d%86400)/3600, (d%3600)/60, d%60)
			fmt.Printf("SUMMARY:%s\n", escape(it.Summary))
			fmt.Println("END:VEVENT")
		}
	}
	fmt.Println("END:VCALENDAR")
}

func max(a, b int) int {
	if a > b { return a }
	return b
}

func plural(n int, one, many string) string {
	if n == 1 { return one }
	return many
}
