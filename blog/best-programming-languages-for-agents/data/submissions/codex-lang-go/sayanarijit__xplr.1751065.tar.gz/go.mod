module xplr-reimpl

go 1.21
