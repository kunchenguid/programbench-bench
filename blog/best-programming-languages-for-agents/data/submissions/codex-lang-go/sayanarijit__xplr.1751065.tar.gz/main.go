package main

import (
    "bufio"
    "encoding/json"
    "fmt"
    "io"
    "os"
    "path/filepath"
    "strconv"
    "strings"
)

const version = "xplr 1.1.0"

const helpText = `xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with ` + "`" + `PrintResultAndQuit` + "`" + `
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\0)
      --write0                 Prints paths separated using the null character (\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    "$HOME/.config/xplr/init.lua")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is ` + "`" + `.` + "`" + `)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
`

var variants = []string{"ExplorePwd", "ExplorePwdAsync", "ExploreParentsAsync", "TryCompletePath", "ClearScreen", "Refresh", "FocusNext", "FocusNextSelection", "FocusNextByRelativeIndex", "FocusNextByRelativeIndexFromInput", "FocusPrevious", "FocusPreviousSelection", "FocusPreviousByRelativeIndex", "FocusPreviousByRelativeIndexFromInput", "FocusFirst", "FocusLast", "FocusPath", "FocusPathFromInput", "FocusByIndex", "FocusByIndexFromInput", "FocusByFileName", "ScrollUp", "ScrollDown", "ScrollUpHalf", "ScrollDownHalf", "ChangeDirectory", "Enter", "Back", "LastVisitedPath", "NextVisitedPath", "PreviousVisitedDeepBranch", "NextVisitedDeepBranch", "FollowSymlink", "SetVroot", "UnsetVroot", "ToggleVroot", "ResetVroot", "SetInputPrompt", "UpdateInputBuffer", "UpdateInputBufferFromKey", "BufferInput", "BufferInputFromKey", "SetInputBuffer", "RemoveInputBufferLastCharacter", "RemoveInputBufferLastWord", "ResetInputBuffer", "SwitchMode", "SwitchModeKeepingInputBuffer", "SwitchModeBuiltin", "SwitchModeBuiltinKeepingInputBuffer", "SwitchModeCustom", "SwitchModeCustomKeepingInputBuffer", "PopMode", "PopModeKeepingInputBuffer", "SwitchLayout", "SwitchLayoutBuiltin", "SwitchLayoutCustom", "Call", "Call0", "CallSilently", "CallSilently0", "BashExec", "BashExec0", "BashExecSilently", "BashExecSilently0", "CallLua", "CallLuaSilently", "LuaEval", "LuaEvalSilently", "Select", "SelectAll", "SelectPath", "UnSelect", "UnSelectAll", "UnSelectPath", "ToggleSelection", "ToggleSelectAll", "ToggleSelectionByPath", "ClearSelection", "AddNodeFilter", "RemoveNodeFilter", "ToggleNodeFilter", "AddNodeFilterFromInput", "RemoveNodeFilterFromInput", "RemoveLastNodeFilter", "ResetNodeFilters", "ClearNodeFilters", "AddNodeSorter", "RemoveNodeSorter", "ReverseNodeSorter", "ToggleNodeSorter", "ReverseNodeSorters", "RemoveLastNodeSorter", "ResetNodeSorters", "ClearNodeSorters", "Search", "SearchFromInput", "SearchFuzzy", "SearchFuzzyFromInput", "SearchFuzzyUnordered", "SearchFuzzyUnorderedFromInput", "SearchRegex", "SearchRegexFromInput", "SearchRegexUnordered", "SearchRegexUnorderedFromInput", "ToggleSearchAlgorithm", "EnableSearchOrder", "DisableSearchOrder", "ToggleSearchOrder", "AcceptSearch", "CancelSearch", "EnableMouse", "DisableMouse", "ToggleMouse", "StartFifo", "StopFifo", "ToggleFifo", "LogInfo", "LogSuccess", "LogWarning", "LogError", "Debug", "Quit", "PrintPwdAndQuit", "PrintFocusPathAndQuit", "PrintSelectionAndQuit", "PrintResultAndQuit", "PrintAppStateAndQuit", "Terminate"}

func main() { os.Exit(run(os.Args[1:])) }

func run(args []string) int {
    if len(args) == 1 && (args[0] == "--help" || args[0] == "-h") {
        fmt.Print(helpText)
        return 0
    }
    if len(args) == 1 && (args[0] == "--version" || args[0] == "-V") {
        fmt.Println(version)
        return 0
    }

    read0, write0 := false, false
    readStdin := false
    forceFocus := false
    printPwdAsResult := false
    readOnly := false
    var positionals []string
    var onLoad []string

    for i := 0; i < len(args); i++ {
        a := args[i]
        switch a {
        case "--":
            positionals = append(positionals, args[i+1:]...)
            i = len(args)
        case "-":
            readStdin = true
        case "-0", "--null":
            read0, write0 = true, true
        case "--read0":
            read0 = true
        case "--write0":
            write0 = true
        case "--force-focus":
            forceFocus = true
        case "--print-pwd-as-result":
            printPwdAsResult = true
        case "--read-only":
            readOnly = true
        case "-h", "--help":
            fmt.Print(helpText)
            return 0
        case "-V", "--version":
            fmt.Println(version)
            return 0
        case "-m", "--pipe-msg-in", "-M", "--print-msg-in":
            if i+1 >= len(args) {
                fmt.Fprintf(os.Stderr, "error: usage: xplr %s FORMAT [ARGUMENT]...\n", a)
                return 1
            }
            code := handleMsg(a == "-M" || a == "--print-msg-in", args[i+1], args[i+2:])
            return code
        case "-c", "--config":
            if i+1 >= len(args) { return errUsage("xplr -c PATH") }
            i++
            if !exists(args[i]) { return errPath(args[i]) }
        case "-C", "--extra-config":
            if i+1 >= len(args) { continue }
            i++
            if !exists(args[i]) { return errPath(args[i]) }
        case "--vroot":
            if i+1 >= len(args) { return errUsage("xplr --vroot PATH") }
            i++
            if !exists(args[i]) { return errPath(args[i]) }
        case "--on-load":
            if i+1 >= len(args) { continue }
            i++
            onLoad = append(onLoad, args[i])
        default:
            if strings.HasPrefix(a, "--") || (strings.HasPrefix(a, "-") && a != "-") {
                fmt.Fprintf(os.Stderr, "error: invalid argument: %q, try `-- %q` or `--help`\n", a, a)
                return 1
            }
            positionals = append(positionals, a)
        }
    }

    _ = forceFocus
    _ = readOnly
    if readStdin {
        data, _ := io.ReadAll(os.Stdin)
        parts := splitInput(data, read0)
        positionals = append(positionals, parts...)
    }
    for _, p := range positionals {
        if p == "" { continue }
        if !exists(p) { return errPath(p) }
    }
    _ = printPwdAsResult
    if isTerminal(os.Stdin) && len(onLoad) > 0 {
        return runOnLoad(onLoad, positionals, write0)
    }
    sep := "\n"
    if write0 { sep = "\x00" }
    _ = sep
    fmt.Fprintln(os.Stderr, "error: No such device or address (os error 6)")
    return 1
}

func exists(p string) bool { _, err := os.Stat(p); return err == nil }
func errUsage(s string) int { fmt.Fprintf(os.Stderr, "error: usage: %s\n", s); return 1 }
func errPath(p string) int { abs, _ := filepath.Abs(p); fmt.Fprintf(os.Stderr, "error: path doesn't exist: %s\n", abs); return 1 }

func splitInput(data []byte, nul bool) []string {
    sep := byte('\n')
    if nul { sep = 0 }
    var out []string
    start := 0
    for i, b := range data {
        if b == sep {
            if i > start { out = append(out, string(data[start:i])) }
            start = i + 1
        }
    }
    if start < len(data) { out = append(out, string(data[start:])) }
    return out
}

func isTerminal(f *os.File) bool {
    st, err := f.Stat()
    return err == nil && (st.Mode()&os.ModeCharDevice) != 0
}

func runOnLoad(msgs, positionals []string, write0 bool) int {
    sep := "\n"
    if write0 { sep = "\x00" }
    cwd, _ := os.Getwd()
    focus := defaultFocus(cwd, positionals)
    for _, msg := range msgs {
        switch strings.TrimSpace(msg) {
        case "Quit":
            return 0
        case "PrintPwdAndQuit":
            fmt.Print(cwd, sep)
            return 0
        case "PrintFocusPathAndQuit", "PrintResultAndQuit":
            fmt.Print(focus, sep)
            return 0
        case "PrintSelectionAndQuit":
            for i, p := range positionals[1:] {
                if i > 0 { fmt.Print(sep) }
                abs, _ := filepath.Abs(p)
                fmt.Print(abs)
            }
            if len(positionals) > 1 { fmt.Print(sep) }
            return 0
        }
    }
    return 0
}

func defaultFocus(cwd string, positionals []string) string {
    if len(positionals) > 0 {
        abs, _ := filepath.Abs(positionals[0])
        info, err := os.Stat(abs)
        if err == nil && !info.IsDir() { return abs }
        return abs
    }
    entries, err := os.ReadDir(cwd)
    if err == nil {
        for _, e := range entries {
            if strings.HasPrefix(e.Name(), ".") { continue }
            if e.IsDir() { return filepath.Join(cwd, e.Name()) }
        }
        for _, e := range entries {
            if strings.HasPrefix(e.Name(), ".") { continue }
            return filepath.Join(cwd, e.Name())
        }
    }
    return cwd
}

func handleMsg(printOnly bool, format string, vals []string) int {
    rendered, errText, ok := render(format, vals)
    if !ok { fmt.Fprintln(os.Stderr, errText); return 1 }
    js, ok, errText := yamlishToJSON(rendered)
    if !ok { fmt.Fprintln(os.Stderr, errText); return 1 }
    if printOnly {
        fmt.Print(js)
    } else if pipe := os.Getenv("XPLR_PIPE_MSG_IN"); pipe != "" {
        f, err := os.OpenFile(pipe, os.O_WRONLY|os.O_APPEND, 0)
        if err != nil { return 0 }
        defer f.Close()
        w := bufio.NewWriter(f)
        w.WriteString(js)
        w.WriteByte('\n')
        w.Flush()
    }
    return 0
}

func render(format string, vals []string) (string, string, bool) {
    var b strings.Builder
    idx := 0
    for i := 0; i < len(format); i++ {
        if format[i] != '%' { b.WriteByte(format[i]); continue }
        if i+1 >= len(format) { b.WriteByte('%'); continue }
        i++
        switch format[i] {
        case '%':
            b.WriteByte('%')
        case 's':
            if idx >= len(vals) { return "", "error: xplr -m: not enough positional values", false }
            b.WriteString(vals[idx]); idx++
        case 'q':
            if idx >= len(vals) { return "", "error: xplr -m: not enough positional values", false }
            b.WriteString(strconv.Quote(vals[idx])); idx++
        default:
            b.WriteByte('%'); b.WriteByte(format[i])
        }
    }
    if idx < len(vals) { return "", "error: xplr -m: too many positional values, not enough positional placeholders", false }
    return b.String(), "", true
}

func yamlishToJSON(s string) (string, bool, string) {
    s = strings.TrimSpace(s)
    if s == "" { return "", false, yamlErr("", 1) }
    if strings.HasPrefix(s, "{") || strings.HasPrefix(s, "[") || strings.HasPrefix(s, "\"") {
        var v any
        if json.Unmarshal([]byte(s), &v) == nil {
            b, _ := json.Marshal(v)
            return string(b), true, ""
        }
    }
    colon := strings.IndexByte(s, ':')
    if colon < 0 || (colon+1 < len(s) && s[colon+1] != ' ' && s[colon+1] != '\t') {
        if isVariant(s) { b, _ := json.Marshal(s); return string(b), true, "" }
        return "", false, unknownVariant(s, 1, len(s)+2)
    }
    key := strings.TrimSpace(s[:colon])
    val := strings.TrimSpace(s[colon+1:])
    if !isVariant(key) { return "", false, unknownVariant(key, 1, len(key)+1) }
    if val == "" { b, _ := json.Marshal(map[string]any{key: nil}); return string(b), true, "" }
    var v any
    if strings.HasPrefix(val, "\"") {
        if err := json.Unmarshal([]byte(val), &v); err != nil { return "", false, yamlErr(s, strings.Index(s, val)+1) }
    } else if val == "true" || val == "false" {
        v = val == "true"
    } else if n, err := strconv.Atoi(val); err == nil {
        v = n
    } else {
        v = val
    }
    b, _ := json.Marshal(map[string]any{key: v})
    return string(b), true, ""
}

func isVariant(s string) bool { for _, v := range variants { if s == v { return true } }; return false }
func unknownVariant(v string, line, col int) string { return fmt.Sprintf("error: unknown variant `%s`, expected one of `%s` at line %d column %d", v, strings.Join(variants, "`, `"), line, col) }
func yamlErr(_ string, col int) string { return fmt.Sprintf("error: xplr -m: yaml: found character that cannot start any token at line 1 column %d, while scanning for the next token", col) }
