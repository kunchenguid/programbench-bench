package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const version = "pueue 4.0.4"

var commands = []string{"add", "remove", "switch", "stash", "enqueue", "start", "restart", "pause", "kill", "send", "edit", "env", "group", "status", "log", "follow", "wait", "clean", "reset", "shutdown", "parallel", "completions", "help"}

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		daemonError()
	}
	args = stripGlobal(args)
	if len(args) == 0 {
		daemonError()
	}
	if args[0] == "-V" || args[0] == "--version" {
		fmt.Println(version)
		return
	}
	if args[0] == "-h" {
		fmt.Print(rootShortHelp())
		return
	}
	if args[0] == "--help" {
		fmt.Print(rootLongHelp())
		return
	}
	if strings.HasPrefix(args[0], "-") {
		cliError("unexpected argument '" + args[0] + "' found\n\nUsage: executable [OPTIONS] [COMMAND]")
	}

	switch args[0] {
	case "help":
		if len(args) == 1 {
			fmt.Print(rootLongHelp())
			return
		}
		printHelp(args[1:])
	case "completions":
		handleCompletions(args[1:])
	case "env":
		handleEnv(args[1:])
	case "group":
		handleGroup(args[1:])
	default:
		handleCommand(args[0], args[1:])
	}
}

func stripGlobal(args []string) []string {
	out := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-v" || a == "-vv" || a == "-vvv" || a == "--verbose" {
			continue
		}
		if a == "--color" || a == "-c" || a == "--config" || a == "-p" || a == "--profile" {
			if i+1 < len(args) {
				i++
			}
			continue
		}
		if strings.HasPrefix(a, "--color=") || strings.HasPrefix(a, "--config=") || strings.HasPrefix(a, "--profile=") {
			continue
		}
		out = append(out, a)
	}
	return out
}

func printHelp(args []string) {
	if len(args) == 0 {
		fmt.Print(rootLongHelp())
		return
	}
	switch args[0] {
	case "env":
		if len(args) > 1 {
			if args[1] == "set" {
				fmt.Print(envSetHelp())
				return
			}
			if args[1] == "unset" {
				fmt.Print(envUnsetHelp())
				return
			}
		}
		fmt.Print(envHelp())
	case "group":
		if len(args) > 1 {
			if args[1] == "add" {
				fmt.Print(groupAddHelp())
				return
			}
			if args[1] == "remove" {
				fmt.Print(groupRemoveHelp())
				return
			}
		}
		fmt.Print(groupHelp())
	default:
		if h, ok := helpTexts[args[0]]; ok {
			fmt.Print(h)
			return
		}
		cliError("unrecognized subcommand '" + args[0] + "'\n\nUsage: executable [OPTIONS] [COMMAND]")
	}
}

func handleCommand(cmd string, rest []string) {
	if _, ok := helpTexts[cmd]; !ok {
		cliError("unrecognized subcommand '" + cmd + "'\n\nUsage: executable [OPTIONS] [COMMAND]")
	}
	for _, a := range rest {
		if a == "-h" || a == "--help" {
			fmt.Print(helpTexts[cmd])
			return
		}
	}
	switch cmd {
	case "add":
		if len(nonOptions(rest)) == 0 {
			missing("<COMMAND>...", "executable add <COMMAND>...")
		}
	case "remove":
		if len(nonOptions(rest)) == 0 {
			missing("<TASK_IDS>...", "executable remove <TASK_IDS>...")
		}
	case "switch":
		n := len(nonOptions(rest))
		if n < 2 {
			if n == 0 {
				missing("<TASK_ID_1>\n  <TASK_ID_2>", "executable switch <TASK_ID_1> <TASK_ID_2>")
			}
			missing("<TASK_ID_2>", "executable switch <TASK_ID_1> <TASK_ID_2>")
		}
	case "send":
		n := len(nonOptions(rest))
		if n < 2 {
			if n == 0 {
				missing("<TASK_ID>\n  <INPUT>", "executable send <TASK_ID> <INPUT>")
			}
			missing("<INPUT>", "executable send <TASK_ID> <INPUT>")
		}
	case "parallel":
		ns := nonOptions(rest)
		if len(ns) > 0 {
			if _, err := strconv.ParseUint(ns[0], 10, 64); err != nil {
				cliError("invalid value '" + ns[0] + "' for '[PARALLEL_TASKS]': invalid digit found in string")
			}
		}
	}
	daemonError()
}

func handleEnv(rest []string) {
	if len(rest) == 0 {
		fmt.Print(envHelp())
		os.Exit(2)
	}
	if rest[0] == "-h" || rest[0] == "--help" {
		fmt.Print(envHelp())
		return
	}
	if rest[0] == "help" {
		printHelp(append([]string{"env"}, rest[1:]...))
		return
	}
	switch rest[0] {
	case "set":
		for _, a := range rest[1:] {
			if a == "-h" || a == "--help" {
				fmt.Print(envSetHelp())
				return
			}
		}
		n := len(nonOptions(rest[1:]))
		if n < 3 {
			miss := "<TASK_ID>\n  <KEY>\n  <VALUE>"
			if n == 1 {
				miss = "<KEY>\n  <VALUE>"
			} else if n == 2 {
				miss = "<VALUE>"
			}
			missing(miss, "executable env set <TASK_ID> <KEY> <VALUE>")
		}
	case "unset":
		for _, a := range rest[1:] {
			if a == "-h" || a == "--help" {
				fmt.Print(envUnsetHelp())
				return
			}
		}
		n := len(nonOptions(rest[1:]))
		if n < 2 {
			miss := "<TASK_ID>\n  <KEY>"
			if n == 1 {
				miss = "<KEY>"
			}
			missing(miss, "executable env unset <TASK_ID> <KEY>")
		}
	default:
		cliError("unrecognized subcommand '" + rest[0] + "'\n\nUsage: executable env <COMMAND>")
	}
	daemonError()
}

func handleGroup(rest []string) {
	if len(rest) == 0 {
		daemonError()
	}
	if rest[0] == "-h" || rest[0] == "--help" {
		fmt.Print(groupHelp())
		return
	}
	if rest[0] == "help" {
		printHelp(append([]string{"group"}, rest[1:]...))
		return
	}
	switch rest[0] {
	case "add":
		for _, a := range rest[1:] {
			if a == "-h" || a == "--help" {
				fmt.Print(groupAddHelp())
				return
			}
		}
		if len(nonOptions(rest[1:])) == 0 {
			missing("<NAME>", "executable group add <NAME>")
		}
	case "remove":
		for _, a := range rest[1:] {
			if a == "-h" || a == "--help" {
				fmt.Print(groupRemoveHelp())
				return
			}
		}
		if len(nonOptions(rest[1:])) == 0 {
			missing("<NAME>", "executable group remove <NAME>")
		}
	default:
		daemonError()
	}
	daemonError()
}

func handleCompletions(rest []string) {
	for _, a := range rest {
		if a == "-h" || a == "--help" {
			fmt.Print(completionsHelp())
			return
		}
	}
	ns := nonOptions(rest)
	if len(ns) == 0 {
		missing("<SHELL>", "executable completions <SHELL> [OUTPUT_DIRECTORY]")
	}
	valid := map[string]bool{"bash": true, "elvish": true, "fish": true, "power-shell": true, "zsh": true, "nushell": true}
	if !valid[ns[0]] {
		msg := "invalid value '" + ns[0] + "' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]"
		if ns[0] == "bad" {
			msg += "\n\n  tip: a similar value exists: 'bash'"
		}
		cliError(msg)
	}
	content := completionFor(ns[0])
	if len(ns) > 1 {
		name := "pueue"
		if ns[0] == "fish" {
			name = "pueue.fish"
		}
		if ns[0] == "bash" {
			name = "pueue.bash"
		}
		_ = os.WriteFile(filepath.Join(ns[1], name), []byte(content), 0644)
		return
	}
	fmt.Print(content)
}

func nonOptions(args []string) []string {
	var out []string
	skip := map[string]bool{"-w": true, "--working-directory": true, "-d": true, "--delay": true, "-g": true, "--group": true, "-a": false, "--after": true, "-o": true, "--priority": true, "-l": true, "--label": true, "-s": false, "--signal": true, "--status": true, "--groups": true, "-p": true, "--parallel": true, "--color": true, "-c": true, "--config": true}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if strings.HasPrefix(a, "-") {
			if skip[a] && i+1 < len(args) {
				i++
			}
			continue
		}
		out = append(out, a)
	}
	return out
}

func missing(what, usage string) {
	fmt.Fprintf(os.Stderr, "error: the following required arguments were not provided:\n  %s\n\nUsage: %s\n\nFor more information, try '--help'.\n", what, usage)
	os.Exit(2)
}

func cliError(msg string) {
	fmt.Fprintf(os.Stderr, "error: %s\n\nFor more information, try '--help'.\n", msg)
	os.Exit(2)
}

func daemonError() {
	fmt.Fprint(os.Stderr, "Error: \n   0: \x1b[91mCouldn't find a configuration file. Did you start the daemon yet?\x1b[0m\n\nLocation:\n   \x1b[35mpueue/src/bin/pueue.rs\x1b[0m:\x1b[35m61\x1b[0m\n\nBacktrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\nRun with RUST_BACKTRACE=full to include source snippets.\n")
	os.Exit(1)
}

func rootShortHelp() string {
	return `Interact with the Pueue daemon

Use the ` + "`--help`" + ` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version
`
}

func rootLongHelp() string {
	return strings.Replace(rootShortHelp(), "  -v, --verbose...         Verbose mode (-v, -vv, -vvv)\n      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty\n                           [default: auto] [possible values: auto, never, always]\n  -c, --config <CONFIG>    If provided, Pueue only uses this config file\n  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file\n  -h, --help               Print help (see more with '--help')", `  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')`, 1)
}

var helpTexts = map[string]string{
	"add": `Enqueue a task for execution.

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory
  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
  -i, --immediate
          Immediately start the task
      --follow
          Immediately follow a task, if it's started with --immediate
  -s, --stashed
          Create the task in Stashed state.
  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted formats
  -g, --group <GROUP>
          Assign the task to a group.
  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.
  -o, --priority <PRIORITY>
          Start this task with a higher priority.
  -l, --label <LABEL>
          Add some information for yourself.
  -p, --print-task-id
          Only return the task id instead of a text.
  -h, --help
          Print help (see a summary with '-h')
`,
	"remove":      "Remove tasks from the list. Running or paused tasks need to be killed first\n\nUsage: executable remove <TASK_IDS>...\n\nArguments:\n  <TASK_IDS>...  The task ids to be removed\n\nOptions:\n  -h, --help  Print help\n",
	"switch":      "Switches the queue position of two commands.\n\nOnly works on queued and stashed commands.\n\nUsage: executable switch <TASK_ID_1> <TASK_ID_2>\n\nArguments:\n  <TASK_ID_1>\n          The first task id\n\n  <TASK_ID_2>\n          The second task id\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"stash":       "Stash a task. Stashed tasks won't be automatically started.\n\nUsage: executable stash [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Stash these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Stash all queued tasks in a group\n  -a, --all\n          Stash all queued tasks across all groups\n  -d, --delay <delay>\n          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"enqueue":     "Enqueue stashed tasks. They'll be handled normally afterwards.\n\nEnqueues all stashed task in the default group if no arguments are given.\n\nUsage: executable enqueue [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Enqueue these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Enqueue all stashed tasks in a group\n  -a, --all\n          Enqueue all stashed tasks across all groups\n  -d, --delay <delay>\n          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"start":       "Resume operation of specific tasks or groups of tasks.\n\nUsage: executable start [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be force-started\n\nOptions:\n  -g, --group <GROUP>\n          Resume a specific group and all paused tasks in it.\n  -a, --all\n          Resume all groups!\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"restart":     "Restart failed or successful task(s).\n\nUsage: executable restart [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Restart these specific tasks\n\nOptions:\n  -a, --all-failed\n          Restart all failed tasks across all groups.\n  -g, --failed-in-group <FAILED_IN_GROUP>\n          Like `--all-failed`, but only restart tasks failed tasks of a specific group\n  -k, --immediate\n          Immediately start the tasks, no matter how many open slots there are.\n  -s, --stashed\n          Set the restarted task to a \"Stashed\" state.\n  -i, --in-place\n          Restart the task by reusing the already existing tasks.\n      --not-in-place\n          Restart the task by creating a new identical tasks.\n  -e, --edit\n          Edit the task before restarting\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"pause":       "Either pause running tasks or specific groups of tasks.\n\nUsage: executable pause [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Pause these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Pause a specific group\n  -a, --all\n          Pause all groups!\n  -w, --wait\n          Pause the specified groups, but let already running tasks finish by themselves\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"kill":        "Kill specific running tasks or whole task groups.\n\nKills all tasks of the default group when no ids or a specific group are provided.\n\nUsage: executable kill [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          Kill these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          Kill all running tasks in a group. This also pauses the group\n  -a, --all\n          Kill all running tasks across ALL groups. This also pauses all groups\n  -s, --signal <SIGNAL>\n          Send a UNIX signal instead of simply killing the process.\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"send":        "Send something to a task. Useful for sending confirmations such as 'y\\n'\n\nUsage: executable send <TASK_ID> <INPUT>\n\nArguments:\n  <TASK_ID>  The id of the task\n  <INPUT>    The input that should be sent to the process\n\nOptions:\n  -h, --help  Print help\n",
	"edit":        "Adjust editable properties of a task.\n\nOnly stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your\n$EDITOR to edit the tasks.\n\nUsage: executable edit [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          The ids of all tasks that should be edited\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"status":      "Display the current status of all tasks\n\nUsage: executable status [OPTIONS] [QUERY]...\n\nArguments:\n  [QUERY]...\n          Users can specify a custom query to filter for specific values, order by a column or limit the amount of tasks listed.\n\nOptions:\n  -j, --json\n          Print the current state as json to stdout. This does not include the output of tasks. Use `log -j` if you want everything\n  -g, --group <GROUP>\n          Only show tasks of a specific group\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"log":         "Display the log output of finished tasks.\n\nOnly the last few lines will be shown by default. If you want to follow the output of a task, please\nuse the \\\"follow\\\" subcommand.\n\nUsage: executable log [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          View the task output of these specific tasks\n\nOptions:\n  -g, --group <GROUP>\n          View the outputs of this specific group's tasks\n  -a, --all\n          Show the logs of all groups' tasks\n  -j, --json\n          Print the resulting tasks and output as json.\n  -l, --lines <LINES>\n          Only print the last X lines of each task's output.\n  -f, --full\n          Show the whole output\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"follow":      "Follow the output of a currently running task. This command works like \"tail -f\"\n\nUsage: executable follow [OPTIONS] [TASK_ID]\n\nArguments:\n  [TASK_ID]\n          The id of the task you want to watch.\n\nOptions:\n  -l, --lines <LINES>\n          Only print the last X lines of the output before following\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"wait":        "Wait until tasks are finished.\n\nBy default, this will wait for all tasks in the default group to finish.\n\nUsage: executable wait [OPTIONS] [TASK_IDS]...\n\nArguments:\n  [TASK_IDS]...\n          This allows you to wait for specific tasks to finish\n\nOptions:\n  -g, --group <GROUP>\n          Wait for all tasks in a specific group\n  -a, --all\n          Wait for all tasks across all groups and the default group\n  -q, --quiet\n          Don't show any log output while waiting\n  -s, --status <STATUS>\n          Wait for tasks to reach a specific task status\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"clean":       "Remove all finished tasks from the list\n\nUsage: executable clean [OPTIONS]\n\nOptions:\n  -s, --successful-only  Only clean tasks that finished successfully\n  -g, --group <GROUP>    Only clean tasks of a specific group\n  -h, --help             Print help\n",
	"reset":       "Kill all tasks, clean up afterwards and reset EVERYTHING!\n\nUsage: executable reset [OPTIONS]\n\nOptions:\n  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset\n  -f, --force            Don't ask for any confirmation\n  -h, --help             Print help\n",
	"shutdown":    "Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager\n\nUsage: executable shutdown\n\nOptions:\n  -h, --help  Print help\n",
	"parallel":    "Set the amount of allowed parallel tasks\n\nBy default, adjusts the amount of the default group.\n\nNo tasks will be stopped, if this is lowered. This limit is only considered when tasks are\nscheduled.\n\nUsage: executable parallel [OPTIONS] [PARALLEL_TASKS]\n\nArguments:\n  [PARALLEL_TASKS]\n          The amount of allowed parallel tasks.\n\nOptions:\n  -g, --group <group>\n          Set the amount for a specific group\n  -h, --help\n          Print help (see a summary with '-h')\n",
	"completions": completionsHelp(),
}

func envHelp() string {
	return "Use this to add or remove environment variables from tasks\n\nUsage: executable env <COMMAND>\n\nCommands:\n  set    Set a variable for a specific task's environment\n  unset  Remove a specific variable from a task's environment\n  help   Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help\n"
}
func envSetHelp() string {
	return "Set a variable for a specific task's environment\n\nUsage: executable env set <TASK_ID> <KEY> <VALUE>\n\nArguments:\n  <TASK_ID>  The id of the task for which the variable should be set\n  <KEY>      The name of the environment variable to set\n  <VALUE>    The value of the environment variable to set\n\nOptions:\n  -h, --help  Print help\n"
}
func envUnsetHelp() string {
	return "Remove a specific variable from a task's environment\n\nUsage: executable env unset <TASK_ID> <KEY>\n\nArguments:\n  <TASK_ID>  The id of the task for which the variable should be set\n  <KEY>      The name of the environment variable to set\n\nOptions:\n  -h, --help  Print help\n"
}
func groupHelp() string {
	return "Use this to add or remove groups.\n\nBy default, this will simply display all known groups.\n\nUsage: executable group [OPTIONS] [COMMAND]\n\nCommands:\n  add     Add a group by name\n  remove  Remove a group by name. This will move all tasks in this group to the default group!\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -j, --json\n          Print the list of groups as json\n\n  -h, --help\n          Print help (see a summary with '-h')\n"
}
func groupAddHelp() string {
	return "Add a group by name\n\nUsage: executable group add [OPTIONS] <NAME>\n\nArguments:\n  <NAME>\n          \n\nOptions:\n  -p, --parallel <PARALLEL>\n          Set the amount of parallel tasks this group can have.\n          \n          Setting this to 0 means an unlimited amount of parallel tasks.\n\n  -h, --help\n          Print help (see a summary with '-h')\n"
}
func groupRemoveHelp() string {
	return "Remove a group by name. This will move all tasks in this group to the default group!\n\nUsage: executable group remove <NAME>\n\nArguments:\n  <NAME>  \n\nOptions:\n  -h, --help  Print help\n"
}
func completionsHelp() string {
	return "Generates shell completion files.\n\nThis can be ignored during normal operations.\n\nUsage: executable completions <SHELL> [OUTPUT_DIRECTORY]\n\nArguments:\n  <SHELL>\n          The target shell\n          \n          [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\n  [OUTPUT_DIRECTORY]\n          The output directory to which the file should be written\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n"
}

func completionFor(shell string) string {
	switch shell {
	case "bash":
		return "_pueue() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd=\"pueue\"\n    opts=\"add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions help -h --help -V --version\"\n    COMPREPLY=( $(compgen -W \"${opts}\" -- \"${COMP_WORDS[COMP_CWORD]}\") )\n}\ncomplete -F _pueue -o bashdefault -o default pueue\n"
	case "fish":
		return "complete -c pueue -f -a 'add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions help'\n"
	case "zsh":
		return "#compdef pueue\n_arguments '*:: :->pueue'\n"
	case "elvish":
		return "edit:completion:arg-completer[pueue] = {|@words| }\n"
	case "power-shell":
		return "Register-ArgumentCompleter -Native -CommandName 'pueue' -ScriptBlock {}\n"
	case "nushell":
		return "extern \"pueue\" []\n"
	}
	return ""
}
