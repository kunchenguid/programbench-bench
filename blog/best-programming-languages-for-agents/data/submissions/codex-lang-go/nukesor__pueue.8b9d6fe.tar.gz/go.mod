module pueue-reimplementation

go 1.21
