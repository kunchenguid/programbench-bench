module cleanroom-lz4

go 1.21
