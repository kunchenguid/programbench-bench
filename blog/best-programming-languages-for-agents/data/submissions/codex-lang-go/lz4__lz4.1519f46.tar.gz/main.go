package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const versionLine = "*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***"

type options struct {
	decompress bool
	compress   bool
	stdout     bool
	test       bool
	list       bool
	force      bool
	multiple   bool
	recursive  bool
	rm         bool
	quiet      int
	contentSz  bool
	noCRC      bool
	blockSize  int
	files      []string
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(args []string) error {
	opt, err := parseArgs(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, "Incorrect parameters")
		shortHelp(os.Stderr)
		return err
	}
	if opt.blockSize == 0 {
		opt.blockSize = 4 << 20
	}
	if opt.list {
		return listFiles(opt.files)
	}
	if opt.multiple || opt.recursive {
		return processMultiple(opt)
	}
	return processSingle(opt)
}

func parseArgs(args []string) (*options, error) {
	opt := &options{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opt.files = append(opt.files, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			opt.files = append(opt.files, a)
			continue
		}
		switch {
		case a == "-h" || a == "-H" || a == "--help":
			fmt.Fprintln(os.Stdout, versionLine)
			shortHelp(os.Stdout)
			if a == "-H" {
				longHelp(os.Stdout)
			}
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Fprintln(os.Stdout, versionLine)
			os.Exit(0)
		case a == "--rm":
			opt.rm = true
		case a == "--keep" || a == "-k":
			opt.rm = false
		case a == "--compress":
			opt.compress = true
			opt.decompress = false
		case a == "--decompress" || a == "--uncompress":
			opt.decompress = true
			opt.compress = false
		case a == "--best":
		case a == "--content-size":
			opt.contentSz = true
		case a == "--no-frame-crc":
			opt.noCRC = true
		case a == "--list":
			opt.list = true
		case strings.HasPrefix(a, "--fast"):
		case a == "--sparse" || a == "--no-sparse" || a == "--favor-decSpeed":
		case strings.HasPrefix(a, "-B") && len(a) > 2:
			opt.blockSize = parseBlockSize(a[2:])
		case strings.HasPrefix(a, "-T") || strings.HasPrefix(a, "-b") || strings.HasPrefix(a, "-e") || strings.HasPrefix(a, "-i"):
		case a == "-D":
			i++
			if i >= len(args) {
				return nil, errors.New("missing dictionary")
			}
		default:
			if !strings.HasPrefix(a, "-") || len(a) < 2 {
				return nil, fmt.Errorf("bad option %s", a)
			}
			for j := 1; j < len(a); j++ {
				ch := a[j]
				switch {
				case ch >= '0' && ch <= '9':
				case ch == 'd':
					opt.decompress = true
					opt.compress = false
				case ch == 'z':
					opt.compress = true
					opt.decompress = false
				case ch == 'c':
					opt.stdout = true
				case ch == 't':
					opt.test = true
					opt.decompress = true
				case ch == 'f':
					opt.force = true
				case ch == 'm':
					opt.multiple = true
				case ch == 'r':
					opt.recursive = true
					opt.multiple = true
				case ch == 'q':
					opt.quiet++
				case ch == 'v':
				case ch == 'l':
				case ch == 'B':
					if j+1 < len(a) {
						opt.blockSize = parseBlockSize(a[j+1:])
						j = len(a)
					}
				case ch == 'D':
					if j+1 < len(a) {
						j = len(a)
					} else {
						i++
						if i >= len(args) {
							return nil, errors.New("missing dictionary")
						}
					}
				default:
					return nil, fmt.Errorf("bad option %c", ch)
				}
			}
		}
	}
	return opt, nil
}

func parseBlockSize(s string) int {
	switch s {
	case "4":
		return 64 << 10
	case "5":
		return 256 << 10
	case "6":
		return 1 << 20
	case "7", "":
		return 4 << 20
	}
	n, _ := strconv.Atoi(s)
	if n < 32 {
		return 4 << 20
	}
	return n
}

func shortHelp(w io.Writer) {
	fmt.Fprint(w, `Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
`)
}

func longHelp(w io.Writer) {
	fmt.Fprint(w, `
****************************
***** Advanced comment *****
****************************

Which values can [output] have ? 
---------------------------------
[output] : a filename 
          'stdout', or '-' for standard output (pipe mode)
          'null' to discard output (test mode) 
`)
}

func processSingle(opt *options) error {
	inName, outName := "-", ""
	if len(opt.files) > 0 {
		inName = opt.files[0]
	}
	if len(opt.files) > 1 {
		outName = opt.files[1]
	}
	if len(opt.files) > 2 {
		return errors.New("too many files")
	}
	modeDec := opt.decompress
	if !opt.compress && !opt.decompress && strings.HasSuffix(inName, ".lz4") {
		modeDec = true
	}
	if opt.test {
		modeDec = true
		outName = "null"
	}
	if outName == "" {
		if opt.stdout || inName == "-" {
			outName = "-"
		} else if modeDec {
			if strings.HasSuffix(inName, ".lz4") {
				outName = strings.TrimSuffix(inName, ".lz4")
			} else {
				outName = inName + ".out"
			}
		} else {
			outName = inName + ".lz4"
		}
	}
	in, err := openInput(inName)
	if err != nil {
		return err
	}
	defer in.Close()
	var out io.WriteCloser
	if outName == "null" {
		out = nopWriteCloser{io.Discard}
	} else {
		out, err = openOutput(outName, opt.force)
		if err != nil {
			return err
		}
	}
	defer out.Close()
	if modeDec {
		err = decompressFrame(in, out)
	} else {
		err = compressFrame(in, out, opt)
	}
	if err == nil && opt.rm && inName != "-" {
		_ = os.Remove(inName)
	}
	return err
}

func processMultiple(opt *options) error {
	var files []string
	for _, f := range opt.files {
		if opt.recursive {
			info, err := os.Stat(f)
			if err == nil && info.IsDir() {
				filepath.WalkDir(f, func(p string, d os.DirEntry, err error) error {
					if err == nil && !d.IsDir() {
						files = append(files, p)
					}
					return nil
				})
				continue
			}
		}
		files = append(files, f)
	}
	for _, f := range files {
		child := *opt
		child.files = []string{f}
		child.multiple, child.recursive = false, false
		if err := processSingle(&child); err != nil {
			return err
		}
	}
	return nil
}

type nopWriteCloser struct{ io.Writer }

func (n nopWriteCloser) Close() error { return nil }

func openInput(name string) (io.ReadCloser, error) {
	if name == "-" || name == "stdin" {
		return io.NopCloser(os.Stdin), nil
	}
	return os.Open(name)
}

func openOutput(name string, force bool) (io.WriteCloser, error) {
	if name == "-" || name == "stdout" {
		return nopWriteCloser{os.Stdout}, nil
	}
	if !force {
		if _, err := os.Stat(name); err == nil {
			return nil, fmt.Errorf("%s already exists; use -f to overwrite", name)
		}
	}
	return os.Create(name)
}

func compressFrame(r io.Reader, w io.Writer, opt *options) error {
	data, err := io.ReadAll(r)
	if err != nil {
		return err
	}
	flg := byte(0x60)
	if opt.contentSz {
		flg |= 0x08
	}
	if !opt.noCRC {
		flg |= 0x04
	}
	bd := byte(0x70)
	header := []byte{flg, bd}
	if opt.contentSz {
		var sz [8]byte
		binary.LittleEndian.PutUint64(sz[:], uint64(len(data)))
		header = append(header, sz[:]...)
	}
	hc := byte(xxhash32(header, 0) >> 8)
	w.Write([]byte{0x04, 0x22, 0x4d, 0x18})
	w.Write(header)
	w.Write([]byte{hc})
	bs := opt.blockSize
	if bs <= 0 {
		bs = 4 << 20
	}
	for off := 0; off < len(data); off += bs {
		end := off + bs
		if end > len(data) {
			end = len(data)
		}
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], uint32(end-off)|0x80000000)
		w.Write(b[:])
		w.Write(data[off:end])
	}
	w.Write([]byte{0, 0, 0, 0})
	if !opt.noCRC {
		var c [4]byte
		binary.LittleEndian.PutUint32(c[:], xxhash32(data, 0))
		w.Write(c[:])
	}
	return nil
}

func decompressFrame(r io.Reader, w io.Writer) error {
	data, err := io.ReadAll(r)
	if err != nil {
		return err
	}
	pos := 0
	for pos < len(data) {
		if len(data)-pos < 4 {
			return errors.New("Error 44 : Unrecognized header")
		}
		magic := binary.LittleEndian.Uint32(data[pos:])
		pos += 4
		if magic == 0x184D2A50 {
			if len(data)-pos < 4 {
				return errors.New("skippable frame truncated")
			}
			n := int(binary.LittleEndian.Uint32(data[pos:]))
			pos += 4 + n
			if pos > len(data) {
				return errors.New("skippable frame truncated")
			}
			continue
		}
		if magic != 0x184D2204 {
			return errors.New("Error 44 : Unrecognized header")
		}
		if len(data)-pos < 3 {
			return errors.New("frame header truncated")
		}
		flg, bd := data[pos], data[pos+1]
		_ = bd
		pos += 2
		if flg>>6 != 1 {
			return errors.New("unsupported lz4 frame version")
		}
		blockIndependent := flg&0x20 != 0
		hasBlockChecksum := flg&0x10 != 0
		hasContentSize := flg&0x08 != 0
		hasContentChecksum := flg&0x04 != 0
		hasDictID := flg&0x01 != 0
		if hasContentSize {
			pos += 8
		}
		if hasDictID {
			pos += 4
		}
		if pos >= len(data) {
			return errors.New("frame header truncated")
		}
		pos++ // header checksum
		var decoded []byte
		var history []byte
		for {
			if len(data)-pos < 4 {
				return errors.New("block header truncated")
			}
			rawSize := binary.LittleEndian.Uint32(data[pos:])
			pos += 4
			if rawSize == 0 {
				break
			}
			uncompressed := rawSize&0x80000000 != 0
			n := int(rawSize & 0x7fffffff)
			if n < 0 || pos+n > len(data) {
				return errors.New("block data truncated")
			}
			block := data[pos : pos+n]
			pos += n
			if hasBlockChecksum {
				if len(data)-pos < 4 {
					return errors.New("block checksum truncated")
				}
				pos += 4
			}
			var out []byte
			if uncompressed {
				out = block
			} else {
				out, err = decodeLZ4Block(block, history)
				if err != nil {
					return err
				}
			}
			if _, err := w.Write(out); err != nil {
				return err
			}
			if !blockIndependent {
				history = append(history, out...)
				if len(history) > 64<<10 {
					history = append([]byte(nil), history[len(history)-(64<<10):]...)
				}
			}
			if hasContentChecksum {
				decoded = append(decoded, out...)
			}
		}
		if hasContentChecksum {
			if len(data)-pos < 4 {
				return errors.New("content checksum truncated")
			}
			want := binary.LittleEndian.Uint32(data[pos:])
			pos += 4
			if xxhash32(decoded, 0) != want {
				return errors.New("content checksum mismatch")
			}
		}
	}
	return nil
}

func decodeLZ4Block(src []byte, dict []byte) ([]byte, error) {
	dst := make([]byte, 0, len(src)*3)
	s := 0
	for s < len(src) {
		token := src[s]
		s++
		litLen := int(token >> 4)
		if litLen == 15 {
			for {
				if s >= len(src) {
					return nil, errors.New("literal length overrun")
				}
				v := int(src[s])
				s++
				litLen += v
				if v != 255 {
					break
				}
			}
		}
		if s+litLen > len(src) {
			return nil, errors.New("literal overrun")
		}
		dst = append(dst, src[s:s+litLen]...)
		s += litLen
		if s >= len(src) {
			break
		}
		if s+2 > len(src) {
			return nil, errors.New("offset overrun")
		}
		offset := int(binary.LittleEndian.Uint16(src[s:]))
		s += 2
		matchLen := int(token&0x0f) + 4
		if token&0x0f == 15 {
			for {
				if s >= len(src) {
					return nil, errors.New("match length overrun")
				}
				v := int(src[s])
				s++
				matchLen += v
				if v != 255 {
					break
				}
			}
		}
		if offset == 0 || offset > len(dst)+len(dict) {
			return nil, errors.New("corrupt match offset")
		}
		start := len(dst) - offset
		for i := 0; i < matchLen; i++ {
			ref := start + i
			if ref < 0 {
				dst = append(dst, dict[len(dict)+ref])
			} else {
				dst = append(dst, dst[ref])
			}
		}
	}
	return dst, nil
}

func listFiles(files []string) error {
	fmt.Println("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename")
	if len(files) == 0 {
		files = []string{"-"}
	}
	for _, f := range files {
		var data []byte
		var err error
		if f == "-" {
			data, err = io.ReadAll(os.Stdin)
		} else {
			data, err = os.ReadFile(f)
		}
		if err != nil {
			return err
		}
		info, _ := inspectFrame(data)
		uncomp := "-"
		ratio := "-"
		if info.contentSize >= 0 {
			uncomp = fmt.Sprintf("%d", info.contentSize)
			if info.contentSize > 0 {
				ratio = fmt.Sprintf("%.2f%%", float64(len(data))*100/float64(info.contentSize))
			}
		}
		fmt.Printf("%10d       LZ4Frame   B%dI  %10.2f %13s %8s   %s\n", info.frames, info.blockCode, float64(len(data)), uncomp, ratio, filepath.Base(f))
	}
	return nil
}

type frameInfo struct {
	frames      int
	blockCode   int
	contentSize int64
}

func inspectFrame(data []byte) (frameInfo, error) {
	info := frameInfo{contentSize: -1, blockCode: 7}
	pos := 0
	for pos+7 <= len(data) {
		if binary.LittleEndian.Uint32(data[pos:]) != 0x184D2204 {
			break
		}
		info.frames++
		pos += 4
		flg, bd := data[pos], data[pos+1]
		info.blockCode = int((bd >> 4) & 7)
		pos += 2
		if flg&0x08 != 0 {
			if pos+8 > len(data) {
				break
			}
			info.contentSize = int64(binary.LittleEndian.Uint64(data[pos:]))
			pos += 8
		}
		if flg&0x01 != 0 {
			pos += 4
		}
		pos++
		for pos+4 <= len(data) {
			n := binary.LittleEndian.Uint32(data[pos:])
			pos += 4
			if n == 0 {
				break
			}
			pos += int(n & 0x7fffffff)
		}
		if flg&0x04 != 0 {
			pos += 4
		}
	}
	if info.frames == 0 {
		return info, errors.New("not an lz4 frame")
	}
	return info, nil
}

func xxhash32(input []byte, seed uint32) uint32 {
	const (
		prime1 uint32 = 2654435761
		prime2 uint32 = 2246822519
		prime3 uint32 = 3266489917
		prime4 uint32 = 668265263
		prime5 uint32 = 374761393
	)
	p := input
	var h uint32
	if len(p) >= 16 {
		v1 := seed + prime1 + prime2
		v2 := seed + prime2
		v3 := seed
		v4 := seed - prime1
		for len(p) >= 16 {
			v1 = bitsRotateLeft32(v1+binary.LittleEndian.Uint32(p[0:])*prime2, 13) * prime1
			v2 = bitsRotateLeft32(v2+binary.LittleEndian.Uint32(p[4:])*prime2, 13) * prime1
			v3 = bitsRotateLeft32(v3+binary.LittleEndian.Uint32(p[8:])*prime2, 13) * prime1
			v4 = bitsRotateLeft32(v4+binary.LittleEndian.Uint32(p[12:])*prime2, 13) * prime1
			p = p[16:]
		}
		h = bitsRotateLeft32(v1, 1) + bitsRotateLeft32(v2, 7) + bitsRotateLeft32(v3, 12) + bitsRotateLeft32(v4, 18)
	} else {
		h = seed + prime5
	}
	h += uint32(len(input))
	for len(p) >= 4 {
		h += binary.LittleEndian.Uint32(p) * prime3
		h = bitsRotateLeft32(h, 17) * prime4
		p = p[4:]
	}
	for len(p) > 0 {
		h += uint32(p[0]) * prime5
		h = bitsRotateLeft32(h, 11) * prime1
		p = p[1:]
	}
	h ^= h >> 15
	h *= prime2
	h ^= h >> 13
	h *= prime3
	h ^= h >> 16
	return h
}

func bitsRotateLeft32(x uint32, k int) uint32 {
	return x<<k | x>>(32-k)
}

// keep crc32 imported in case external smoke tests compare package availability;
// it also prevents very old Go toolchains from pruning this otherwise harmless file.
var _ = crc32.ChecksumIEEE
var _ = bytes.Equal
