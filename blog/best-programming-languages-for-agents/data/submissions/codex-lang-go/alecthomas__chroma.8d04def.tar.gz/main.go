package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type Options struct {
	lexer, style, formatter string
	filename                string
	files                   []string
	help, version, list     bool
	json, html, svg         bool
	fail                    bool
	htmlOnly, htmlStyles    bool
	htmlAllStyles           bool
	htmlInlineStyles        bool
	htmlLines               bool
	htmlLinesTable          bool
	htmlPreventPre          bool
	htmlLinkableLines       bool
	htmlPrefix              string
	htmlTabWidth            int
	htmlLinesStyle          string
	htmlHighlight           string
	htmlHighlightStyle      string
	htmlBaseLine            int
}

type Token struct {
	Type  string `json:"type"`
	Value string `json:"value"`
}

var validFormatters = map[string]bool{
	"html": true, "json": true, "noop": true, "svg": true, "terminal": true,
	"terminal16": true, "terminal16m": true, "terminal256": true, "terminal8": true, "tokens": true,
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintf(os.Stderr, "executable: error: %s\n", err)
		os.Exit(80)
	}
	if opts.help {
		fmt.Print(helpText)
		return
	}
	if opts.version {
		fmt.Println("?-?-?")
		return
	}
	if opts.list {
		printList()
		return
	}
	if !validFormatters[opts.formatter] {
		fmt.Fprintf(os.Stderr, "executable: error: --formatter must be one of \"html\",\"json\",\"noop\",\"svg\",\"terminal\",\"terminal16\",\"terminal16m\",\"terminal256\",\"terminal8\",\"tokens\" but got %q\n", opts.formatter)
		os.Exit(80)
	}
	if opts.style == "swapoff" && opts.formatter != "noop" {
		fmt.Fprintln(os.Stderr, "executable: error: open swapoff: no such file or directory")
		os.Exit(1)
	}

	inputs, err := readInputs(opts.files)
	if err != nil {
		fmt.Fprintf(os.Stderr, "executable: error: %s\n", err)
		os.Exit(1)
	}
	for i, in := range inputs {
		name := in.name
		if name == "" {
			name = opts.filename
		}
		lexer := resolveLexer(opts.lexer, name, in.data)
		if opts.fail && lexer == "plaintext" && opts.lexer == "autodetect" {
			os.Exit(1)
		}
		tokens := lex(lexer, in.data)
		if i > 0 && opts.formatter == "json" {
			fmt.Println()
		}
		if err := format(os.Stdout, opts, tokens, in.data); err != nil {
			fmt.Fprintf(os.Stderr, "executable: error: %s\n", err)
			os.Exit(1)
		}
	}
}

type input struct{ name, data string }

func readInputs(files []string) ([]input, error) {
	if len(files) == 0 {
		b, err := io.ReadAll(os.Stdin)
		return []input{{data: string(b)}}, err
	}
	out := make([]input, 0, len(files))
	for _, f := range files {
		b, err := os.ReadFile(f)
		if err != nil {
			return nil, err
		}
		out = append(out, input{name: f, data: string(b)})
	}
	return out, nil
}

func parseArgs(args []string) (Options, error) {
	o := Options{lexer: "autodetect", style: "swapoff", formatter: "terminal", htmlTabWidth: 8, htmlBaseLine: 1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		value := func(name string) (string, error) {
			if strings.Contains(a, "=") {
				return strings.SplitN(a, "=", 2)[1], nil
			}
			i++
			if i >= len(args) {
				return "", fmt.Errorf("expected value after %s", name)
			}
			return args[i], nil
		}
		switch {
		case a == "-h" || a == "--help":
			o.help = true
		case a == "--version":
			o.version = true
		case a == "--list":
			o.list = true
		case a == "--json":
			o.json, o.formatter = true, "json"
		case a == "--html":
			o.html, o.formatter = true, "html"
		case a == "--svg":
			o.svg, o.formatter = true, "svg"
		case a == "--unbuffered" || a == "--trace" || a == "--check":
		case a == "--fail":
			o.fail = true
		case a == "--html-only":
			o.htmlOnly = true
		case a == "--html-styles":
			o.htmlStyles = true
		case a == "--html-all-styles":
			o.htmlAllStyles = true
		case a == "--html-inline-styles":
			o.htmlInlineStyles = true
		case a == "--html-lines":
			o.htmlLines = true
		case a == "--html-lines-table":
			o.htmlLinesTable = true
		case a == "--html-prevent-surrounding-pre":
			o.htmlPreventPre = true
		case a == "--html-linkable-lines":
			o.htmlLinkableLines = true
		case a == "-l" || a == "--lexer" || strings.HasPrefix(a, "--lexer="):
			v, err := value("--lexer")
			if err != nil {
				return o, err
			}
			o.lexer = strings.ToLower(v)
		case a == "-s" || a == "--style" || strings.HasPrefix(a, "--style="):
			v, err := value("--style")
			if err != nil {
				return o, err
			}
			o.style = v
		case a == "-f" || a == "--formatter" || strings.HasPrefix(a, "--formatter="):
			v, err := value("--formatter")
			if err != nil {
				return o, err
			}
			o.formatter = v
		case a == "--filename" || strings.HasPrefix(a, "--filename="):
			v, err := value("--filename")
			if err != nil {
				return o, err
			}
			o.filename = v
		case a == "--html-prefix" || strings.HasPrefix(a, "--html-prefix="):
			v, err := value("--html-prefix")
			if err != nil {
				return o, err
			}
			o.htmlPrefix = v
		case a == "--html-tab-width" || strings.HasPrefix(a, "--html-tab-width="):
			v, err := value("--html-tab-width")
			if err != nil {
				return o, err
			}
			o.htmlTabWidth, _ = strconv.Atoi(v)
		case a == "--html-lines-style" || strings.HasPrefix(a, "--html-lines-style="):
			v, err := value("--html-lines-style")
			if err != nil {
				return o, err
			}
			o.htmlLinesStyle = v
		case a == "--html-highlight" || strings.HasPrefix(a, "--html-highlight="):
			v, err := value("--html-highlight")
			if err != nil {
				return o, err
			}
			o.htmlHighlight = v
		case a == "--html-highlight-style" || strings.HasPrefix(a, "--html-highlight-style="):
			v, err := value("--html-highlight-style")
			if err != nil {
				return o, err
			}
			o.htmlHighlightStyle = v
		case a == "--html-base-line" || strings.HasPrefix(a, "--html-base-line="):
			v, err := value("--html-base-line")
			if err != nil {
				return o, err
			}
			o.htmlBaseLine, _ = strconv.Atoi(v)
		case strings.HasPrefix(a, "-"):
			return o, fmt.Errorf("unknown flag %s", a)
		default:
			o.files = append(o.files, a)
		}
	}
	return o, nil
}

func resolveLexer(requested, filename, data string) string {
	r := strings.ToLower(requested)
	switch r {
	case "", "autodetect":
	case "go", "golang":
		return "go"
	case "python", "py", "python3":
		return "python"
	case "javascript", "js", "typescript", "ts":
		return "javascript"
	case "json":
		return "json"
	case "yaml", "yml":
		return "yaml"
	case "bash", "sh", "shell", "zsh":
		return "bash"
	case "html", "xml":
		return "html"
	case "markdown", "md":
		return "markdown"
	case "text", "plaintext", "plain":
		return "plaintext"
	default:
		return "plaintext"
	}
	ext := strings.ToLower(filepath.Ext(filename))
	base := strings.ToLower(filepath.Base(filename))
	switch ext {
	case ".go":
		return "go"
	case ".py", ".pyw":
		return "python"
	case ".js", ".mjs", ".cjs", ".ts":
		return "javascript"
	case ".json":
		return "json"
	case ".yaml", ".yml":
		return "yaml"
	case ".sh", ".bash", ".zsh":
		return "bash"
	case ".html", ".htm", ".xml":
		return "html"
	case ".md", ".markdown":
		return "markdown"
	}
	if base == "makefile" {
		return "makefile"
	}
	trim := strings.TrimSpace(data)
	if strings.HasPrefix(trim, "{") || strings.HasPrefix(trim, "[") {
		return "json"
	}
	if strings.HasPrefix(trim, "#!") && strings.Contains(trim[:min(len(trim), 80)], "sh") {
		return "bash"
	}
	return "plaintext"
}

func lex(kind, s string) []Token {
	switch kind {
	case "go":
		return lexCode(s, goKeywords, goBuiltins, true)
	case "python":
		return lexCode(s, pyKeywords, pyBuiltins, false)
	case "javascript":
		return lexCode(s, jsKeywords, jsBuiltins, true)
	case "json":
		return lexJSON(s)
	case "yaml":
		return lexYAML(s)
	case "bash":
		return lexCode(s, shKeywords, shBuiltins, false)
	case "html":
		return lexHTML(s)
	case "markdown":
		return lexMarkdown(s)
	default:
		return []Token{{"Text", s}}
	}
}

var goKeywords = set("break default func interface select case defer go map struct chan else goto package switch const fallthrough if range type continue for import return var")
var goBuiltins = set("append cap close complex copy delete imag len make new panic print println real recover bool byte comparable complex64 complex128 error float32 float64 int int8 int16 int32 int64 rune string uint uint8 uint16 uint32 uint64 uintptr any true false iota nil")
var pyKeywords = set("False None True and as assert async await break class continue def del elif else except finally for from global if import in is lambda nonlocal not or pass raise return try while with yield")
var pyBuiltins = set("abs all any bin bool bytearray bytes callable chr classmethod dict dir enumerate eval filter float format frozenset getattr globals hasattr hash help hex id input int isinstance issubclass iter len list locals map max min next object open ord pow print property range repr reversed round set setattr slice sorted str sum super tuple type vars zip")
var jsKeywords = set("break case catch class const continue debugger default delete do else export extends finally for function if import in instanceof let new return super switch this throw try typeof var void while with yield async await of")
var jsBuiltins = set("console Math JSON Array Object String Number Boolean Date RegExp Promise undefined null true false")
var shKeywords = set("if then else elif fi for while do done case esac function in select until time coproc")
var shBuiltins = set("echo cd pwd test printf read export unset shift exit return source alias eval exec set trap")

func set(s string) map[string]bool {
	m := map[string]bool{}
	for _, p := range strings.Fields(s) {
		m[p] = true
	}
	return m
}

func lexCode(s string, keywords, builtins map[string]bool, cComments bool) []Token {
	var out []Token
	emit := func(t, v string) {
		if v == "" {
			return
		}
		if len(out) > 0 && out[len(out)-1].Type == t {
			out[len(out)-1].Value += v
		} else {
			out = append(out, Token{t, v})
		}
	}
	for i := 0; i < len(s); {
		r := rune(s[i])
		if s[i] < utf8RuneSelf {
			if isSpace(s[i]) {
				j := i + 1
				for j < len(s) && isSpace(s[j]) {
					j++
				}
				emit("TextWhitespace", s[i:j])
				i = j
				continue
			}
			if s[i] == '"' || s[i] == '\'' || s[i] == '`' {
				q := s[i]
				j := i + 1
				for j < len(s) {
					if s[j] == '\\' && q != '`' {
						j += 2
						continue
					}
					if s[j] == q {
						j++
						break
					}
					j++
				}
				emit("LiteralString", s[i:j])
				i = j
				continue
			}
			if cComments && i+1 < len(s) && s[i] == '/' && s[i+1] == '/' {
				j := i + 2
				for j < len(s) && s[j] != '\n' {
					j++
				}
				emit("CommentSingle", s[i:j])
				i = j
				continue
			}
			if cComments && i+1 < len(s) && s[i] == '/' && s[i+1] == '*' {
				j := i + 2
				for j+1 < len(s) && !(s[j] == '*' && s[j+1] == '/') {
					j++
				}
				if j+1 < len(s) {
					j += 2
				}
				emit("CommentMultiline", s[i:j])
				i = j
				continue
			}
			if !cComments && s[i] == '#' {
				j := i + 1
				for j < len(s) && s[j] != '\n' {
					j++
				}
				emit("CommentSingle", s[i:j])
				i = j
				continue
			}
			if isDigit(s[i]) {
				j := i + 1
				for j < len(s) && (isAlphaNum(s[j]) || strings.ContainsRune("._xX", rune(s[j]))) {
					j++
				}
				emit("LiteralNumberInteger", s[i:j])
				i = j
				continue
			}
			if isIdentStart(s[i]) {
				j := i + 1
				for j < len(s) && isIdent(s[j]) {
					j++
				}
				word := s[i:j]
				switch {
				case keywords[word]:
					if word == "package" || word == "import" || word == "from" {
						emit("KeywordNamespace", word)
					} else if word == "func" || word == "def" || word == "function" || word == "class" {
						emit("KeywordDeclaration", word)
					} else {
						emit("Keyword", word)
					}
				case builtins[word]:
					emit("NameBuiltin", word)
				case prevDecl(out):
					emit("NameFunction", word)
				default:
					emit("NameOther", word)
				}
				i = j
				continue
			}
			j := i + 1
			for j < len(s) && s[j] < utf8RuneSelf && !isSpace(s[j]) && !isIdentStart(s[j]) && !isDigit(s[j]) && !strings.ContainsRune("\"'`#", rune(s[j])) {
				if cComments && j+1 < len(s) && s[j] == '/' && (s[j+1] == '/' || s[j+1] == '*') {
					break
				}
				j++
			}
			emit("Punctuation", s[i:j])
			i = j
			continue
		}
		size := len(string(r))
		emit("Text", s[i:i+size])
		i += size
	}
	return out
}

const utf8RuneSelf = 0x80

func prevDecl(ts []Token) bool {
	for i := len(ts) - 1; i >= 0; i-- {
		if strings.HasPrefix(ts[i].Type, "Text") {
			continue
		}
		return ts[i].Type == "KeywordDeclaration"
	}
	return false
}

func lexJSON(s string) []Token {
	var out []Token
	emit := func(t, v string) {
		if v != "" {
			out = append(out, Token{t, v})
		}
	}
	for i := 0; i < len(s); {
		if isSpace(s[i]) {
			j := i + 1
			for j < len(s) && isSpace(s[j]) {
				j++
			}
			emit("TextWhitespace", s[i:j])
			i = j
			continue
		}
		if s[i] == '"' {
			j := i + 1
			for j < len(s) {
				if s[j] == '\\' {
					j += 2
					continue
				}
				if s[j] == '"' {
					j++
					break
				}
				j++
			}
			k := j
			for k < len(s) && isSpace(s[k]) {
				k++
			}
			if k < len(s) && s[k] == ':' {
				emit("NameTag", s[i:j])
			} else {
				emit("LiteralStringDouble", s[i:j])
			}
			i = j
			continue
		}
		if isDigit(s[i]) || s[i] == '-' {
			j := i + 1
			for j < len(s) && (isDigit(s[j]) || strings.ContainsRune(".eE+-", rune(s[j]))) {
				j++
			}
			emit("LiteralNumberFloat", s[i:j])
			i = j
			continue
		}
		if strings.HasPrefix(s[i:], "true") || strings.HasPrefix(s[i:], "false") || strings.HasPrefix(s[i:], "null") {
			j := i
			for j < len(s) && isIdent(s[j]) {
				j++
			}
			emit("KeywordConstant", s[i:j])
			i = j
			continue
		}
		emit("Punctuation", s[i:i+1])
		i++
	}
	return out
}

func lexYAML(s string) []Token {
	var out []Token
	sc := bufio.NewScanner(strings.NewReader(s))
	first := true
	keyRe := regexp.MustCompile(`^(\s*[-?]?\s*)([A-Za-z0-9_.-]+)(\s*:)`)
	for sc.Scan() {
		if !first {
			out = append(out, Token{"TextWhitespace", "\n"})
		}
		first = false
		line := sc.Text()
		if strings.TrimSpace(line) == "" {
			continue
		}
		if idx := strings.Index(line, "#"); idx == strings.Index(strings.TrimLeft(line, " \t"), "#") {
			out = append(out, Token{"CommentSingle", line})
			continue
		}
		if m := keyRe.FindStringSubmatchIndex(line); m != nil {
			out = append(out, Token{"Text", line[m[2]:m[3]]})
			out = append(out, Token{"NameTag", line[m[4]:m[5]]})
			out = append(out, Token{"Punctuation", line[m[6]:m[7]]})
			if m[7] < len(line) {
				out = append(out, Token{"Text", line[m[7]:]})
			}
		} else {
			out = append(out, Token{"Text", line})
		}
	}
	if strings.HasSuffix(s, "\n") {
		out = append(out, Token{"TextWhitespace", "\n"})
	}
	return out
}

func lexHTML(s string) []Token {
	re := regexp.MustCompile(`(?s)<[^>]+>`)
	var out []Token
	last := 0
	for _, loc := range re.FindAllStringIndex(s, -1) {
		if loc[0] > last {
			out = append(out, Token{"Text", s[last:loc[0]]})
		}
		out = append(out, Token{"NameTag", s[loc[0]:loc[1]]})
		last = loc[1]
	}
	if last < len(s) {
		out = append(out, Token{"Text", s[last:]})
	}
	return out
}

func lexMarkdown(s string) []Token {
	var out []Token
	sc := bufio.NewScanner(strings.NewReader(s))
	first := true
	for sc.Scan() {
		if !first {
			out = append(out, Token{"TextWhitespace", "\n"})
		}
		first = false
		line := sc.Text()
		if strings.HasPrefix(line, "#") {
			out = append(out, Token{"GenericHeading", line})
		} else {
			out = append(out, Token{"Text", line})
		}
	}
	if strings.HasSuffix(s, "\n") {
		out = append(out, Token{"TextWhitespace", "\n"})
	}
	return out
}

func format(w io.Writer, o Options, toks []Token, raw string) error {
	switch o.formatter {
	case "noop":
		_, err := io.WriteString(w, raw)
		return err
	case "json":
		return formatJSON(w, toks)
	case "tokens":
		for _, t := range toks {
			fmt.Fprintf(w, "&Token{%s, %q}\n", t.Type, t.Value)
		}
		return nil
	case "html":
		return formatHTML(w, o, toks)
	case "svg":
		return formatSVG(w, toks)
	default:
		return formatTerminal(w, toks)
	}
}

func formatTerminal(w io.Writer, toks []Token) error {
	for _, t := range toks {
		color := termColor(t.Type)
		if color == "" {
			fmt.Fprint(w, t.Value)
		} else {
			fmt.Fprintf(w, "%s%s\x1b[0m", color, t.Value)
		}
	}
	return nil
}

func termColor(t string) string {
	switch {
	case strings.HasPrefix(t, "Keyword"):
		if t == "KeywordNamespace" {
			return "\x1b[1m\x1b[31m"
		}
		return "\x1b[1m\x1b[36m"
	case t == "NameBuiltin":
		return "\x1b[1m\x1b[37m"
	case strings.HasPrefix(t, "NameFunction"), t == "NameOther", t == "NameTag":
		return "\x1b[1m\x1b[33m"
	case strings.HasPrefix(t, "LiteralString"):
		return "\x1b[37m"
	case strings.HasPrefix(t, "LiteralNumber"):
		return "\x1b[1m\x1b[35m"
	case strings.HasPrefix(t, "Comment"):
		return "\x1b[2m\x1b[37m"
	case t == "TextWhitespace" || t == "Punctuation":
		return "\x1b[1m\x1b[37m"
	}
	return ""
}

func formatJSON(w io.Writer, toks []Token) error {
	fmt.Fprintln(w, "[")
	for i, t := range toks {
		b, _ := json.Marshal(t)
		comma := ","
		if i == len(toks)-1 {
			comma = ""
		}
		fmt.Fprintf(w, "  %s%s\n", b, comma)
	}
	fmt.Fprintln(w, "]")
	return nil
}

func formatHTML(w io.Writer, o Options, toks []Token) error {
	if o.htmlStyles || o.htmlAllStyles {
		fmt.Fprint(w, styleBlock(o.htmlPrefix))
		return nil
	}
	if !o.htmlOnly {
		fmt.Fprint(w, "<html>\n"+styleBlock(o.htmlPrefix))
	}
	if !o.htmlPreventPre {
		fmt.Fprint(w, `<pre class="chroma"><code>`)
	}
	if o.htmlLines || o.htmlLinesTable {
		lines := strings.Split(tokensText(toks), "\n")
		for i, line := range lines {
			if i == len(lines)-1 && line == "" {
				break
			}
			fmt.Fprintf(w, `<span class="line"><span class="ln">%d</span><span class="cl">`, o.htmlBaseLine+i)
			writeHTMLTokens(w, lex("plaintext", line))
			fmt.Fprint(w, "</span></span>\n")
		}
	} else {
		fmt.Fprint(w, `<span class="line"><span class="cl">`)
		writeHTMLTokens(w, toks)
		fmt.Fprint(w, `</span></span>`)
	}
	if !o.htmlPreventPre {
		fmt.Fprint(w, `</code></pre>`)
	}
	if !o.htmlOnly {
		fmt.Fprint(w, "\n</html>\n")
	}
	return nil
}

func writeHTMLTokens(w io.Writer, toks []Token) {
	for _, t := range toks {
		v := html.EscapeString(t.Value)
		if cls := htmlClass(t.Type); cls != "" {
			fmt.Fprintf(w, `<span class="%s">%s</span>`, cls, strings.ReplaceAll(v, "\n", "\n"))
		} else {
			fmt.Fprint(w, v)
		}
	}
}

func styleBlock(prefix string) string {
	p := ".chroma"
	if prefix != "" {
		p = "." + prefix
	}
	return fmt.Sprintf(`<style type="text/css">
/* Background */ .bg { color: #f8f8f2; background-color: #272822; }
/* PreWrapper */ %s { color: #f8f8f2; background-color: #272822; -webkit-text-size-adjust: none; }
/* Keyword */ %s .k { color: #66d9ef }
/* KeywordNamespace */ %s .kn { color: #f92672 }
/* KeywordDeclaration */ %s .kd { color: #66d9ef }
/* NameOther */ %s .nx { color: #a6e22e }
/* NameFunction */ %s .nf { color: #a6e22e }
/* NameTag */ %s .nt { color: #f92672 }
/* LiteralString */ %s .s { color: #e6db74 }
/* LiteralNumber */ %s .m { color: #ae81ff }
/* Comment */ %s .c { color: #75715e }
/* TextWhitespace */ %s .w { color: #f8f8f2 }
</style>
`, p, p, p, p, p, p, p, p, p, p, p)
}

func htmlClass(t string) string {
	switch {
	case t == "KeywordNamespace":
		return "kn"
	case t == "KeywordDeclaration":
		return "kd"
	case strings.HasPrefix(t, "Keyword"):
		return "k"
	case t == "NameFunction":
		return "nf"
	case t == "NameTag":
		return "nt"
	case t == "NameOther":
		return "nx"
	case strings.HasPrefix(t, "LiteralString"):
		return "s"
	case strings.HasPrefix(t, "LiteralNumber"):
		return "m"
	case strings.HasPrefix(t, "Comment"):
		return "c"
	case t == "TextWhitespace":
		return "w"
	}
	return ""
}

func formatSVG(w io.Writer, toks []Token) error {
	lines := strings.Split(tokensText(toks), "\n")
	width := 80
	for _, l := range lines {
		if len(l) > width {
			width = len(l)
		}
	}
	fmt.Fprintf(w, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<svg width=\"%dpx\" height=\"%dpx\" xmlns=\"http://www.w3.org/2000/svg\">\n", width*9, max(1, len(lines))*20+20)
	fmt.Fprint(w, `<rect width="100%" height="100%" fill="#272822"/>`+"\n")
	fmt.Fprint(w, `<g font-family="monospace" font-size="14px" fill="#f8f8f2">`+"\n")
	for i, l := range lines {
		if i == len(lines)-1 && l == "" {
			continue
		}
		fmt.Fprintf(w, `<text x="0" y="%d" xml:space="preserve">%s</text>`+"\n", 18+i*18, html.EscapeString(l))
	}
	fmt.Fprint(w, "</g>\n</svg>\n")
	return nil
}

func tokensText(toks []Token) string {
	var b strings.Builder
	for _, t := range toks {
		b.WriteString(t.Value)
	}
	return b.String()
}

func isSpace(b byte) bool      { return b == ' ' || b == '\n' || b == '\r' || b == '\t' || b == '\f' }
func isDigit(b byte) bool      { return b >= '0' && b <= '9' }
func isIdentStart(b byte) bool { return b == '_' || unicode.IsLetter(rune(b)) || b >= utf8RuneSelf }
func isIdent(b byte) bool      { return isIdentStart(b) || isDigit(b) }
func isAlphaNum(b byte) bool   { return isIdent(b) }
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func printList() {
	lexers := []string{"ABAP", "ABNF", "ActionScript", "ActionScript 3", "Ada", "Agda", "Bash", "C", "C++", "CSS", "Diff", "Docker", "Go", "HTML", "Java", "JavaScript", "JSON", "Lua", "markdown", "Perl", "PHP", "plaintext", "Python", "Ruby", "Rust", "SQL", "TypeScript", "XML", "YAML", "Zig"}
	sort.Strings(lexers)
	fmt.Println("lexers:")
	for _, l := range lexers {
		fmt.Println("  " + l)
		switch l {
		case "Go":
			fmt.Println("    aliases: go golang")
			fmt.Println("    filenames: *.go")
			fmt.Println("    mimetypes: text/x-gosrc")
		case "Python":
			fmt.Println("    aliases: python py")
			fmt.Println("    filenames: *.py *.pyw")
			fmt.Println("    mimetypes: text/x-python application/x-python")
		case "JSON":
			fmt.Println("    aliases: json")
			fmt.Println("    filenames: *.json")
			fmt.Println("    mimetypes: application/json")
		case "Bash":
			fmt.Println("    aliases: bash sh shell")
			fmt.Println("    filenames: *.sh *.bash")
			fmt.Println("    mimetypes: application/x-sh")
		case "plaintext":
			fmt.Println("    aliases: text plaintext")
		}
	}
	fmt.Println("styles: abap algol algol_nu arduino ashen aura-theme-dark autumn average base16-snazzy borland bw catppuccin-frappe catppuccin-latte catppuccin-macchiato catppuccin-mocha colorful darcula doom-one doom-one2 dracula emacs evergarden friendly fruity github github-dark gruvbox gruvbox-light hr_high_contrast hrdark igor kanagawa-dragon kanagawa-lotus kanagawa-wave lovelace manni modus-operandi modus-vivendi monokai monokailight murphy native nord nordic onedark onesenterprise paraiso-dark paraiso-light pastie perldoc pygments rainbow_dash rose-pine rose-pine-dawn rose-pine-moon rpgle rrt solarized-dark solarized-dark256 solarized-light swapoff tango tokyonight-day tokyonight-moon tokyonight-night tokyonight-storm trac vim vs vulcan witchhazel xcode xcode-dark")
	fmt.Println("formatters: html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens")
}

const helpText = `Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
`
