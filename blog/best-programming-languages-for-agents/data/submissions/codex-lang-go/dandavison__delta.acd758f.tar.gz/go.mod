module delta-reimplementation

go 1.21
