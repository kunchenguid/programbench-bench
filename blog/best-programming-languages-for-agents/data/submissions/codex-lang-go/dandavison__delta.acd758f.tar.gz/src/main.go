package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "delta 0.18.2"

var valueOptions = map[string]bool{
	"--blame-code-style": true, "--blame-format": true, "--blame-palette": true,
	"--blame-separator-format": true, "--blame-separator-style": true,
	"--blame-timestamp-format": true, "--blame-timestamp-output-format": true,
	"--config": true, "--commit-decoration-style": true, "--commit-regex": true,
	"--commit-style": true, "--default-language": true, "--detect-dark-light": true,
	"--diff-args": true, "-@": true, "--diff-stat-align-width": true,
	"--features": true, "--file-added-label": true, "--file-copied-label": true,
	"--file-decoration-style": true, "--file-modified-label": true,
	"--file-removed-label": true, "--file-renamed-label": true, "--file-style": true,
	"--file-transformation": true, "--generate-completion": true,
	"--grep-context-line-style": true, "--grep-file-style": true,
	"--grep-header-decoration-style": true, "--grep-header-file-style": true,
	"--grep-line-number-style": true, "--grep-output-type": true,
	"--grep-match-line-style": true, "--grep-match-word-style": true,
	"--grep-separator-symbol": true, "--hunk-header-decoration-style": true,
	"--hunk-header-file-style": true, "--hunk-header-line-number-style": true,
	"--hunk-header-style": true, "--hunk-label": true,
	"--hyperlinks-commit-link-format": true, "--hyperlinks-file-link-format": true,
	"--inline-hint-style": true, "--inspect-raw-lines": true,
	"--line-buffer-size": true, "--line-fill-method": true,
	"--line-numbers-left-format": true, "--line-numbers-left-style": true,
	"--line-numbers-minus-style": true, "--line-numbers-plus-style": true,
	"--line-numbers-right-format": true, "--line-numbers-right-style": true,
	"--line-numbers-zero-style": true, "--map-styles": true,
	"--max-line-distance": true, "--max-syntax-highlighting-length": true,
	"--max-line-length": true, "--merge-conflict-begin-symbol": true,
	"--merge-conflict-end-symbol": true,
	"--merge-conflict-ours-diff-header-decoration-style": true,
	"--merge-conflict-ours-diff-header-style": true,
	"--merge-conflict-theirs-diff-header-decoration-style": true,
	"--merge-conflict-theirs-diff-header-style": true,
	"--minus-empty-line-marker-style": true, "--minus-emph-style": true,
	"--minus-non-emph-style": true, "--minus-style": true,
	"--navigate-regex": true, "--pager": true, "--paging": true,
	"--plus-emph-style": true, "--plus-empty-line-marker-style": true,
	"--plus-non-emph-style": true, "--plus-style": true,
	"--right-arrow": true, "--syntax-theme": true, "--tabs": true,
	"--true-color": true, "--whitespace-error-style": true, "--width": true, "-w": true,
	"--word-diff-regex": true, "--wrap-left-symbol": true, "--wrap-max-lines": true,
	"--wrap-right-percent": true, "--wrap-right-prefix-symbol": true,
	"--wrap-right-symbol": true, "--zero-style": true, "--24-bit-color": true,
}

type options struct {
	raw              bool
	colorOnly        bool
	keepMarkers      bool
	lineNumbers      bool
	sideBySide        bool
	parseANSI         bool
	noGitConfig      bool
	showConfig       bool
	showColors       bool
	showThemes       bool
	showSyntaxThemes bool
	listThemes       bool
	listLanguages    bool
	generateShell    string
	diffArgs         string
	files            []string
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if err := run(opts); err != nil {
		var exit *exec.ExitError
		if errors.As(err, &exit) {
			os.Exit(exit.ExitCode())
		}
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, error) {
	var o options
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			o.files = append(o.files, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			o.files = append(o.files, a)
			continue
		}
		name, val, hasEq := strings.Cut(a, "=")
		switch name {
		case "-h", "--help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println(version)
			os.Exit(0)
		case "--raw":
			o.raw = true
		case "--color-only":
			o.colorOnly = true
		case "--keep-plus-minus-markers":
			o.keepMarkers = true
		case "-n", "--line-numbers":
			o.lineNumbers = true
		case "-s", "--side-by-side":
			o.sideBySide = true
		case "--parse-ansi":
			o.parseANSI = true
		case "--no-gitconfig":
			o.noGitConfig = true
		case "--show-config":
			o.showConfig = true
		case "--show-colors":
			o.showColors = true
		case "--show-themes":
			o.showThemes = true
		case "--show-syntax-themes":
			o.showSyntaxThemes = true
		case "--list-syntax-themes":
			o.listThemes = true
		case "--list-languages":
			o.listLanguages = true
		default:
			if valueOptions[name] {
				if !hasEq {
					if i+1 >= len(args) {
						return o, fmt.Errorf("error: a value is required for '%s <VALUE>' but none was supplied", name)
					}
					val = args[i+1]
					i++
				}
				if name == "--generate-completion" {
					o.generateShell = val
				}
				if name == "--diff-args" || name == "-@" {
					o.diffArgs = val
				}
				continue
			}
			if strings.HasPrefix(a, "-w") && len(a) > 2 {
				continue
			}
			return o, fmt.Errorf("error: unexpected argument '%s' found", a)
		}
	}
	return o, nil
}

func run(o options) error {
	switch {
	case o.generateShell != "":
		return printCompletion(o.generateShell)
	case o.showConfig:
		printConfig(o)
		return nil
	case o.showColors:
		printColors()
		return nil
	case o.listThemes:
		printThemeList()
		return nil
	case o.showThemes || o.showSyntaxThemes:
		printThemeSamples()
		return nil
	case o.listLanguages:
		printLanguages()
		return nil
	}

	var input []byte
	var err error
	if len(o.files) >= 2 {
		input, err = diffFiles(o.files[0], o.files[1], o.diffArgs)
		if err != nil && len(input) == 0 {
			return err
		}
	} else if len(o.files) == 1 {
		input, err = os.ReadFile(o.files[0])
		if err != nil {
			return err
		}
	} else {
		input, err = io.ReadAll(os.Stdin)
		if err != nil {
			return err
		}
	}
	if o.parseANSI {
		_, err = os.Stdout.Write([]byte(parseANSI(string(input))))
		return err
	}
	if o.raw || o.colorOnly {
		_, err = os.Stdout.Write(input)
		return err
	}
	_, err = os.Stdout.Write(renderDiff(input, o))
	return err
}

func diffFiles(a, b, extra string) ([]byte, error) {
	args := []string{"diff", "--no-index", "--color=never"}
	if extra != "" {
		args = append(args, strings.Fields(extra)...)
	}
	args = append(args, a, b)
	cmd := exec.Command("git", args...)
	out, err := cmd.CombinedOutput()
	_ = err
	if len(out) > 0 {
		return out, nil
	}
	cmd = exec.Command("diff", "-u", a, b)
	return cmd.CombinedOutput()
}

func renderDiff(input []byte, o options) []byte {
	sc := bufio.NewScanner(bytes.NewReader(input))
	sc.Buffer(make([]byte, 0, 64*1024), 16*1024*1024)
	var out bytes.Buffer
	oldLine, newLine := 0, 0
	hunkRE := regexp.MustCompile(`^@@+ -([0-9]+)(?:,[0-9]+)? \+([0-9]+)`)
	for sc.Scan() {
		line := sc.Text()
		if m := hunkRE.FindStringSubmatch(line); m != nil {
			oldLine, _ = strconv.Atoi(m[1])
			newLine, _ = strconv.Atoi(m[2])
			writeLine(&out, color(line, "36"))
			continue
		}
		if o.sideBySide && (strings.HasPrefix(line, "-") || strings.HasPrefix(line, "+")) && !strings.HasPrefix(line, "---") && !strings.HasPrefix(line, "+++") {
			writeSideBySide(&out, line)
			continue
		}
		prefix := ""
		body := line
		if o.lineNumbers {
			switch {
			case strings.HasPrefix(line, "-") && !strings.HasPrefix(line, "---"):
				prefix = fmt.Sprintf("%4d⋮    │ ", oldLine)
				oldLine++
			case strings.HasPrefix(line, "+") && !strings.HasPrefix(line, "+++"):
				prefix = fmt.Sprintf("    ⋮%4d│ ", newLine)
				newLine++
			case strings.HasPrefix(line, " "):
				prefix = fmt.Sprintf("%4d⋮%4d│ ", oldLine, newLine)
				oldLine++
				newLine++
			default:
				prefix = "    ⋮    │ "
			}
		}
		switch {
		case strings.HasPrefix(line, "diff --git "), strings.HasPrefix(line, "commit "):
			writeLine(&out, color(line, "1;34"))
		case strings.HasPrefix(line, "index "), strings.HasPrefix(line, "new file mode"), strings.HasPrefix(line, "deleted file mode"):
			writeLine(&out, color(line, "34"))
		case strings.HasPrefix(line, "--- "), strings.HasPrefix(line, "+++ "):
			writeLine(&out, color(line, "34"))
		case strings.HasPrefix(line, "-"):
			if !o.keepMarkers && !strings.HasPrefix(line, "---") {
				body = strings.TrimPrefix(line, "-")
			}
			writeLine(&out, prefix+color(body, "31"))
		case strings.HasPrefix(line, "+"):
			if !o.keepMarkers && !strings.HasPrefix(line, "+++") {
				body = strings.TrimPrefix(line, "+")
			}
			writeLine(&out, prefix+color(body, "32"))
		default:
			writeLine(&out, prefix+line)
		}
	}
	return out.Bytes()
}

func writeLine(out *bytes.Buffer, s string) {
	out.WriteString(s)
	out.WriteByte('\n')
}

func writeSideBySide(out *bytes.Buffer, line string) {
	if strings.HasPrefix(line, "-") {
		fmt.Fprintf(out, "%-60s │\n", color(strings.TrimPrefix(line, "-"), "31"))
	} else {
		fmt.Fprintf(out, "%-60s │ %s\n", "", color(strings.TrimPrefix(line, "+"), "32"))
	}
}

func color(s, code string) string {
	if s == "" {
		return s
	}
	return "\x1b[" + code + "m" + s + "\x1b[0m"
}

func printHelp() {
	if text, ok := extractHelpFromManual(); ok {
		fmt.Print(text)
		if !strings.HasSuffix(text, "\n") {
			fmt.Println()
		}
		return
	}
	fmt.Println("A viewer for git and diff output\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version")
}

func extractHelpFromManual() (string, bool) {
	paths := []string{
		"manual/src/full---help-output.md",
		filepath.Join(filepath.Dir(os.Args[0]), "manual/src/full---help-output.md"),
	}
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err != nil {
			continue
		}
		s := string(b)
		start := strings.Index(s, "```txt\n")
		if start < 0 {
			continue
		}
		s = s[start+7:]
		end := strings.Index(s, "\n```")
		if end >= 0 {
			s = s[:end]
		}
		return s + "\n", true
	}
	return "", false
}

func printCompletion(shell string) error {
	candidates := []string{
		filepath.Join("etc", "completion", "completion."+shell),
		filepath.Join(filepath.Dir(os.Args[0]), "etc", "completion", "completion."+shell),
	}
	if shell == "powershell" {
		fmt.Println("Register-ArgumentCompleter -Native -CommandName 'delta' -ScriptBlock { param($wordToComplete) }")
		return nil
	}
	if shell == "elvish" {
		fmt.Println("#compdef delta")
		return nil
	}
	for _, p := range candidates {
		if b, err := os.ReadFile(p); err == nil {
			_, err = os.Stdout.Write(b)
			return err
		}
	}
	return fmt.Errorf("invalid value '%s' for '--generate-completion <GENERATE_COMPLETION>'", shell)
}

func printConfig(o options) {
	vals := map[string]string{
		"color-only":                 fmt.Sprint(o.colorOnly),
		"dark":                       "false",
		"diff-so-fancy":              "false",
		"file-style":                 "blue",
		"hunk-header-style":          "line-number syntax",
		"keep-plus-minus-markers":    fmt.Sprint(o.keepMarkers),
		"light":                      "false",
		"line-numbers":               fmt.Sprint(o.lineNumbers),
		"minus-style":                "syntax #340001",
		"navigate":                   "false",
		"paging":                     "auto",
		"plus-style":                 "syntax #003800",
		"raw":                        fmt.Sprint(o.raw),
		"side-by-side":               fmt.Sprint(o.sideBySide),
		"syntax-theme":               "Monokai Extended",
		"true-color":                 "auto",
		"width":                      "auto",
	}
	keys := make([]string, 0, len(vals))
	for k := range vals {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Printf("%s = %s\n", k, vals[k])
	}
}

func printColors() {
	for _, c := range []string{"black", "red", "green", "yellow", "blue", "magenta", "cyan", "white", "bright-black", "bright-red", "bright-green", "bright-yellow", "bright-blue", "bright-magenta", "bright-cyan", "bright-white"} {
		fmt.Println(c)
	}
}

func printThemeList() {
	for _, t := range []string{"1337", "Coldark-Dark", "Coldark-Cold", "DarkNeon", "Dracula", "GitHub", "Monokai Extended", "Monokai Extended Bright", "Monokai Extended Light", "Nord", "OneHalfDark", "OneHalfLight", "Solarized (dark)", "Solarized (light)", "TwoDark", "Visual Studio Dark+", "ansi", "base16", "none"} {
		fmt.Println(t)
	}
}

func printThemeSamples() {
	for _, t := range []string{"Monokai Extended", "Dracula", "GitHub", "Nord", "OneHalfDark", "Solarized (dark)", "Solarized (light)"} {
		fmt.Println(t)
		fmt.Println(color("-removed line", "31"))
		fmt.Println(color("+added line", "32"))
	}
}

func printLanguages() {
	langs := []string{
		"Bash: sh, bash, zsh", "C: c, h", "C++: cpp, cc, cxx, hpp", "Go: go",
		"HTML: html, htm", "Java: java", "JavaScript: js, jsx, mjs", "JSON: json",
		"Markdown: md, markdown", "Python: py", "Ruby: rb", "Rust: rs",
		"TypeScript: ts, tsx", "YAML: yaml, yml",
	}
	for _, l := range langs {
		fmt.Println(l)
	}
}

func parseANSI(s string) string {
	re := regexp.MustCompile(`\x1b\[([0-9;]*)m`)
	return re.ReplaceAllStringFunc(s, func(seq string) string {
		inner := seq[2 : len(seq)-1]
		if inner == "" {
			inner = "0"
		}
		return "<" + inner + ">"
	})
}
