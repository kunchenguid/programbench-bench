module deadnix-reimpl

go 1.21
