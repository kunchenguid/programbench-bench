package main

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"unicode"
)

type opts struct {
	noLambdaArg     bool
	noLambdaPattern bool
	noUnderscore    bool
	warnUnderscore  bool
	quiet           bool
	edit            bool
	hidden          bool
	fail            bool
	output          string
	excludes        []string
	paths           []string
}

type tok struct {
	typ       string
	val       string
	start     int
	end       int
	line      int
	col       int
	skipAfter bool
}

type result struct {
	Column    int    `json:"column"`
	EndColumn int    `json:"endColumn"`
	Line      int    `json:"line"`
	Message   string `json:"message"`
	Name      string `json:"-"`
	Start     int    `json:"-"`
	End       int    `json:"-"`
	Kind      string `json:"-"`
}

type fileReport struct {
	File    string   `json:"file"`
	Results []result `json:"results"`
}

type binding struct {
	name string
	tok  tok
	kind string
	skip bool
}

func main() {
	o, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if len(o.paths) == 0 {
		o.paths = []string{"."}
	}
	files, err := collectFiles(o)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	sort.Strings(files)
	var reports []fileReport
	found := false
	for _, f := range files {
		data, err := os.ReadFile(f)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error reading file %s: %v\n", f, err)
			continue
		}
		res := analyze(f, string(data), o)
		if len(res) > 0 {
			found = true
			if o.edit {
				edited := applyEdits(string(data), res)
				_ = os.WriteFile(f, []byte(edited), 0644)
			}
			reports = append(reports, fileReport{File: f, Results: res})
		}
	}
	if !o.quiet && !o.edit {
		if o.output == "json" {
			for _, r := range reports {
				b, _ := json.Marshal(r)
				fmt.Println(string(b))
			}
		} else {
			for i, r := range reports {
				if i > 0 {
					fmt.Println()
				}
				printHuman(r)
			}
		}
	}
	if found && o.fail {
		os.Exit(1)
	}
}

func parseArgs(args []string) (opts, error) {
	o := opts{output: "human-readable"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("deadnix 1.3.1")
			os.Exit(0)
		case "-l", "--no-lambda-arg":
			o.noLambdaArg = true
		case "-L", "--no-lambda-pattern-names":
			o.noLambdaPattern = true
		case "-_", "--no-underscore":
			o.noUnderscore = true
		case "-W", "--warn-used-underscore":
			o.warnUnderscore = true
		case "-q", "--quiet":
			o.quiet = true
		case "-e", "--edit":
			o.edit = true
		case "-h", "--hidden":
			o.hidden = true
		case "-f", "--fail":
			o.fail = true
		case "-o", "--output-format":
			if i+1 >= len(args) {
				return o, fmt.Errorf("error: a value is required for '--output-format <OUTPUT_FORMAT>'")
			}
			i++
			if args[i] != "human-readable" && args[i] != "json" {
				return o, fmt.Errorf("error: invalid value '%s' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human-readable, json]\n\nFor more information, try '--help'.", args[i])
			}
			o.output = args[i]
		case "--exclude":
			for i+1 < len(args) && args[i+1] != "--" && !strings.HasPrefix(args[i+1], "-") {
				i++
				o.excludes = append(o.excludes, args[i])
			}
		case "--":
			for i+1 < len(args) {
				i++
				o.paths = append(o.paths, args[i])
			}
		default:
			if strings.HasPrefix(a, "-") {
				return o, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE_PATHS]...\n\nFor more information, try '--help'.", a)
			}
			o.paths = append(o.paths, a)
		}
	}
	return o, nil
}

func printHelp() {
	fmt.Print(`Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version
`)
}

func collectFiles(o opts) ([]string, error) {
	var out []string
	for _, p := range o.paths {
		info, err := os.Stat(p)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error stating file %s: %v\n", p, err)
			continue
		}
		if info.IsDir() {
			filepath.WalkDir(p, func(path string, d fs.DirEntry, err error) error {
				if err != nil {
					return nil
				}
				base := filepath.Base(path)
				if d.IsDir() {
					if path != p && strings.HasPrefix(base, ".") && !o.hidden {
						return filepath.SkipDir
					}
					return nil
				}
				if strings.HasPrefix(base, ".") && !o.hidden {
					return nil
				}
				if strings.HasSuffix(base, ".nix") && !excluded(path, o.excludes) {
					out = append(out, path)
				}
				return nil
			})
		} else if strings.HasSuffix(p, ".nix") && !excluded(p, o.excludes) {
			out = append(out, p)
		}
	}
	return out, nil
}

func excluded(path string, excludes []string) bool {
	for _, e := range excludes {
		if path == e || filepath.Clean(path) == filepath.Clean(e) || strings.Contains(path, e) {
			return true
		}
	}
	return false
}

func lex(src string) []tok {
	var out []tok
	line, col := 1, 1
	skipNext := false
	for i := 0; i < len(src); {
		r := rune(src[i])
		if src[i] == '\n' {
			i++; line++; col = 1; continue
		}
		if unicode.IsSpace(r) {
			i++; col++; continue
		}
		if src[i] == '#' {
			j := i
			for j < len(src) && src[j] != '\n' { j++ }
			if strings.Contains(src[i:j], "deadnix: skip") {
				skipNext = true
			}
			col += j - i
			i = j
			continue
		}
		if i+1 < len(src) && src[i:i+2] == "/*" {
			j := i+2
			for j+1 < len(src) && src[j:j+2] != "*/" {
				if src[j] == '\n' { line++; col = 1; j++ } else { col++; j++ }
			}
			if j+1 < len(src) { j += 2; col += 2 }
			i = j
			continue
		}
		start, l, c := i, line, col
		if src[i] == '"' {
			i++; col++
			for i < len(src) {
				if src[i] == '\\' && i+1 < len(src) { i += 2; col += 2; continue }
				if i+1 < len(src) && src[i:i+2] == "${" {
					i += 2; col += 2
					for i < len(src) && src[i] != '}' {
						il, ic, istart := line, col, i
						if isIdentStart(rune(src[i])) {
							j := i+1
							for j < len(src) && isIdentPart(rune(src[j])) { j++ }
							out = append(out, tok{typ:"ident", val:src[i:j], start:i, end:j, line:il, col:ic})
							col += j - i; i = j; continue
						}
						_ = istart
						if src[i] == '\n' { line++; col = 1; i++ } else { i++; col++ }
					}
					if i < len(src) { i++; col++ }
					continue
				}
				if src[i] == '"' { i++; col++; break }
				if src[i] == '\n' { line++; col = 1; i++ } else { i++; col++ }
			}
			out = append(out, tok{typ:"string", val:src[start:i], start:start, end:i, line:l, col:c})
			continue
		}
		if i+1 < len(src) && src[i:i+2] == "''" {
			i += 2; col += 2
			for i+1 < len(src) && src[i:i+2] != "''" {
				if src[i] == '\n' { line++; col = 1; i++ } else { i++; col++ }
			}
			if i+1 < len(src) { i += 2; col += 2 }
			out = append(out, tok{typ:"string", val:src[start:i], start:start, end:i, line:l, col:c})
			continue
		}
		if isIdentStart(r) {
			j := i+1
			cc := col+1
			for j < len(src) && isIdentPart(rune(src[j])) { j++; cc++ }
			val := src[i:j]
			t := tok{typ:"ident", val:val, start:i, end:j, line:l, col:c, skipAfter:skipNext}
			switch val {
			case "let","in","inherit","rec","with","assert","or","if","then","else":
				t.typ = val
			}
			out = append(out, t)
			skipNext = false
			i, col = j, cc
			continue
		}
		if i+2 <= len(src) && (strings.HasPrefix(src[i:], "...")) {
			out = append(out, tok{typ:"...", val:"...", start:i, end:i+3, line:l, col:c})
			i += 3; col += 3; continue
		}
		ch := string(src[i])
		out = append(out, tok{typ:ch, val:ch, start:i, end:i+1, line:l, col:c})
		i++; col++
	}
	return out
}

func isIdentStart(r rune) bool {
	return unicode.IsLetter(r) || r == '_' || r == '\''
}
func isIdentPart(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '\'' || r == '-'
}

func analyze(path, src string, o opts) []result {
	toks := lex(src)
	var res []result
	res = append(res, analyzeLets(toks, o)...)
	res = append(res, analyzeLambdas(toks, o)...)
	if o.warnUnderscore {
		res = append(res, analyzeUsedUnderscore(toks)...)
	}
	sort.SliceStable(res, func(i, j int) bool {
		if res[i].Line != res[j].Line { return res[i].Line < res[j].Line }
		return res[i].Column < res[j].Column
	})
	return res
}

func analyzeLets(toks []tok, o opts) []result {
	var res []result
	for i := 0; i < len(toks); i++ {
		if toks[i].typ != "let" { continue }
		inIdx := findLetIn(toks, i)
		if inIdx < 0 { continue }
		endIdx := findExprEnd(toks, inIdx+1)
		binds := collectLetBindings(toks, i+1, inIdx)
		usage := map[string]int{}
		countUsages(toks, i+1, inIdx, usage, true)
		countUsages(toks, inIdx+1, endIdx, usage, false)
		for _, b := range binds {
			if b.skip || (o.noUnderscore && strings.HasPrefix(b.name, "_")) {
				continue
			}
			if usage[b.name] == 0 {
				res = append(res, mkres(b.tok, "Unused let binding: "+b.name, b.name, "let"))
			}
		}
	}
	return res
}

func findLetIn(toks []tok, start int) int {
	depth := 0
	for i := start+1; i < len(toks); i++ {
		switch toks[i].typ {
		case "{","[","(":
			depth++
		case "}","]",")":
			if depth > 0 { depth-- }
		case "let":
			if depth == 0 {
				j := findLetIn(toks, i)
				if j > i { i = j }
			}
		case "in":
			if depth == 0 { return i }
		}
	}
	return -1
}

func findExprEnd(toks []tok, start int) int {
	depth := 0
	for i := start; i < len(toks); i++ {
		switch toks[i].typ {
		case "{","[","(":
			depth++
		case "}","]",")":
			if depth == 0 { return i }
			depth--
		case ";":
			if depth == 0 { return i }
		}
	}
	return len(toks)
}

func collectLetBindings(toks []tok, start, end int) []binding {
	var binds []binding
	depth := 0
	for i := start; i < end; i++ {
		t := toks[i]
		switch t.typ {
		case "{","[","(":
			depth++
		case "}","]",")":
			if depth > 0 { depth-- }
		}
		if depth != 0 { continue }
		if t.typ == "inherit" {
			j := i+1
			if j < end && toks[j].typ == "(" {
				d := 1; j++
				for j < end && d > 0 {
					if toks[j].typ == "(" { d++ }
					if toks[j].typ == ")" { d-- }
					j++
				}
			}
			for ; j < end && toks[j].typ != ";"; j++ {
				if toks[j].typ == "ident" {
					binds = append(binds, binding{name:toks[j].val, tok:toks[j], kind:"let", skip:toks[j].skipAfter})
				}
			}
			i = j
			continue
		}
		if t.typ == "ident" && i+1 < end {
			j := i+1
			for j < end && toks[j].typ == "." {
				j += 2
			}
			if j < end && toks[j].typ == "=" {
				binds = append(binds, binding{name:t.val, tok:t, kind:"let", skip:t.skipAfter})
			}
		}
	}
	return binds
}

func countUsages(toks []tok, start, end int, usage map[string]int, inLetHeader bool) {
	depth := 0
	for i := start; i < end; i++ {
		if toks[i].typ == "let" {
			if in := findLetIn(toks, i); in > i {
				i = findExprEnd(toks, in+1) - 1
				continue
			}
		}
		if inLetHeader && depth == 0 {
			if toks[i].typ == "inherit" {
				for i < end && toks[i].typ != ";" { i++ }
				continue
			}
			if toks[i].typ == "ident" {
				j := i+1
				for j < end && toks[j].typ == "." { j += 2 }
				if j < end && toks[j].typ == "=" {
					i = j
					continue
				}
			}
		}
		switch toks[i].typ {
		case "{","[","(":
			depth++
		case "}","]",")":
			if depth > 0 { depth-- }
		}
		if toks[i].typ == "ident" {
			if i > 0 && toks[i-1].typ == "." {
				continue
			}
			if i+1 < end && toks[i+1].typ == ":" {
				continue
			}
			if i+1 < end && toks[i+1].typ == "=" && depth > 0 {
				continue
			}
			usage[toks[i].val]++
		}
	}
}

func analyzeLambdas(toks []tok, o opts) []result {
	var res []result
	for i := 0; i < len(toks); i++ {
		if toks[i].typ == "ident" && i+1 < len(toks) && toks[i+1].typ == ":" {
			if i > 0 && (toks[i-1].typ == "@" || toks[i-1].typ == "}") {
				continue
			}
			if !o.noLambdaArg && !strings.HasPrefix(toks[i].val, "_") {
				end := findLambdaBodyEnd(toks, i+2)
				if !identUsed(toks, i+2, end, toks[i].val) {
					res = append(res, mkres(toks[i], "Unused lambda argument: "+toks[i].val, toks[i].val, "lambda"))
				}
			}
			continue
		}
		if toks[i].typ == "{" {
			if i > 0 && toks[i-1].typ == "@" {
				continue
			}
			close := findClose(toks, i, "{", "}")
			if close > i && close+1 < len(toks) && toks[close+1].typ == ":" {
				res = append(res, checkPattern(toks, i, close, close+2, o)...)
			}
			if close > i && close+2 < len(toks) && toks[close+1].typ == "@" && toks[close+2].typ == "ident" && close+3 < len(toks) && toks[close+3].typ == ":" {
				res = append(res, checkPattern(toks, i, close, close+4, o)...)
					if !o.noLambdaPattern && !identUsedExcept(toks, i+1, findLambdaBodyEnd(toks, close+4), toks[close+2].val, close+2) {
					res = append(res, mkres(toks[close+2], "Unused lambda pattern: "+toks[close+2].val, toks[close+2].val, "pattern"))
				}
			}
		}
		if toks[i].typ == "ident" && i+1 < len(toks) && toks[i+1].typ == "@" && i+2 < len(toks) && toks[i+2].typ == "{" {
			close := findClose(toks, i+2, "{", "}")
			if close > i && close+1 < len(toks) && toks[close+1].typ == ":" {
				bodyStart := close+2
					if !o.noLambdaPattern && !identUsedExcept(toks, i+2, findLambdaBodyEnd(toks, bodyStart), toks[i].val, i) {
					res = append(res, mkres(toks[i], "Unused lambda pattern: "+toks[i].val, toks[i].val, "pattern"))
				}
				res = append(res, checkPattern(toks, i+2, close, bodyStart, o)...)
			}
		}
	}
	return res
}

func checkPattern(toks []tok, open, close, bodyStart int, o opts) []result {
	if o.noLambdaPattern { return nil }
	end := findLambdaBodyEnd(toks, bodyStart)
	var res []result
	depth := 0
	for i := open+1; i < close; i++ {
		switch toks[i].typ {
		case "{","[","(":
			depth++
		case "}","]",")":
			if depth > 0 { depth-- }
		}
		if depth == 0 && toks[i].typ == "ident" {
			if i > open+1 && toks[i-1].typ != "," {
				continue
			}
			name := toks[i].val
				if strings.HasPrefix(name, "_") || identUsedExcept(toks, open+1, end, name, i) {
				continue
			}
			res = append(res, mkres(toks[i], "Unused lambda pattern: "+name, name, "pattern"))
		}
	}
	return res
}

func findLambdaBodyEnd(toks []tok, start int) int {
	if start < len(toks) && toks[start].typ == "let" {
		in := findLetIn(toks, start)
		if in >= 0 {
			return findExprEnd(toks, in+1)
		}
	}
	return findExprEnd(toks, start)
}

func findClose(toks []tok, start int, open, close string) int {
	d := 0
	for i := start; i < len(toks); i++ {
		if toks[i].typ == open { d++ }
		if toks[i].typ == close {
			d--
			if d == 0 { return i }
		}
	}
	return -1
}

func identUsed(toks []tok, start, end int, name string) bool {
	for i := start; i < end && i < len(toks); i++ {
		if toks[i].typ == "ident" && toks[i].val == name {
			if i > 0 && toks[i-1].typ == "." { continue }
			return true
		}
	}
	return false
}

func identUsedExcept(toks []tok, start, end int, name string, except int) bool {
	for i := start; i < end && i < len(toks); i++ {
		if i == except {
			continue
		}
		if toks[i].typ == "ident" && toks[i].val == name {
			if i > 0 && toks[i-1].typ == "." { continue }
			return true
		}
	}
	return false
}

func analyzeUsedUnderscore(toks []tok) []result {
	decl := map[string]bool{}
	for _, b := range collectLetBindings(toks, 0, len(toks)) {
		if strings.HasPrefix(b.name, "_") { decl[b.name] = true }
	}
	var res []result
	for _, t := range toks {
		if t.typ == "ident" && strings.HasPrefix(t.val, "_") && decl[t.val] {
			res = append(res, mkres(t, "Used underscored binding: "+t.val, t.val, "underscore"))
		}
	}
	return res
}

func mkres(t tok, msg, name, kind string) result {
	return result{Column:t.col, EndColumn:t.col + len([]rune(t.val)), Line:t.line, Message:msg, Name:name, Start:t.start, End:t.end, Kind:kind}
}

func printHuman(r fileReport) {
	if len(r.Results) == 0 { return }
	fmt.Println("Warning: Unused declarations were found.")
	first := r.Results[0]
	fmt.Printf("   ╭─[%s:%d:%d]\n", r.File, first.Line, first.Column)
	lines := readLines(r.File)
	lastLine := 0
	for _, x := range r.Results {
		if x.Line != lastLine {
			if x.Line-1 >= 0 && x.Line-1 < len(lines) {
				fmt.Printf("%2d │%s\n", x.Line, lines[x.Line-1])
			}
			lastLine = x.Line
		}
		spaces := strings.Repeat(" ", max(0, x.Column-1))
		width := max(1, x.EndColumn-x.Column)
		fmt.Printf("   │%s╰%s %s\n", spaces, strings.Repeat("─", min(5, width+1)), x.Message)
	}
}

func readLines(path string) []string {
	b, err := os.ReadFile(path)
	if err != nil { return nil }
	return strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
}

func applyEdits(src string, res []result) string {
	// Remove whole-line unused let bindings where practical; rename lambda arguments by prefixing "_".
	lines := strings.SplitAfter(src, "\n")
	removeLine := map[int]bool{}
	var inserts []result
	for _, r := range res {
		if r.Kind == "let" {
			removeLine[r.Line] = true
		} else if (r.Kind == "lambda" || r.Kind == "pattern") && !strings.HasPrefix(r.Name, "_") {
			inserts = append(inserts, r)
		}
	}
	var rebuilt strings.Builder
	offsets := make([]int, len(lines)+1)
	pos := 0
	for i, l := range lines {
		offsets[i+1] = pos
		pos += len(l)
		if !removeLine[i+1] { rebuilt.WriteString(l) }
	}
	out := rebuilt.String()
	sort.Slice(inserts, func(i, j int) bool { return inserts[i].Start > inserts[j].Start })
	for _, r := range inserts {
		if r.Start >= 0 && r.Start <= len(out) {
			out = out[:r.Start] + "_" + out[r.Start:]
		}
	}
	return out
}

func min(a,b int) int { if a < b { return a }; return b }
func max(a,b int) int { if a > b { return a }; return b }
