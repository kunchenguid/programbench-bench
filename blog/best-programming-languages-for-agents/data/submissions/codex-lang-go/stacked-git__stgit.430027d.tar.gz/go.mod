module stgclone

go 1.21
