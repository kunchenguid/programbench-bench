package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

const versionText = `Stacked Git 2.5.5
Copyright (C) 2005-2025 StGit authors
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
SPDX-License-Identifier: GPL-2.0-only`

type Patch struct {
	Name    string `json:"name"`
	Commit  string `json:"commit"`
	Message string `json:"message"`
}

type State struct {
	Branch    string  `json:"branch"`
	Base      string  `json:"base"`
	Applied   []Patch `json:"applied"`
	Unapplied []Patch `json:"unapplied"`
	Hidden    []Patch `json:"hidden"`
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		var ee exitError
		if errors.As(err, &ee) {
			os.Exit(ee.Code)
		}
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
}

type exitError struct{ Code int }

func (e exitError) Error() string { return "" }

func run(args []string) error {
	var cwd string
	filtered := []string{}
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-C":
			if i+1 >= len(args) {
				return usageErr("error: a value is required for '-C <path>'")
			}
			if filepath.IsAbs(args[i+1]) || cwd == "" {
				cwd = args[i+1]
			} else {
				cwd = filepath.Join(cwd, args[i+1])
			}
			i++
		case "--color":
			i++
		default:
			if strings.HasPrefix(args[i], "--color=") {
				continue
			}
			filtered = append(filtered, args[i])
		}
	}
	if cwd != "" {
		if err := os.Chdir(cwd); err != nil {
			return err
		}
	}
	args = filtered
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		printMainHelp()
		return nil
	}
	if args[0] == "--version" {
		printVersion(false)
		return nil
	}
	cmd, rest := args[0], args[1:]
	if len(rest) > 0 && (rest[0] == "-h" || rest[0] == "--help") {
		printHelp(cmd)
		return nil
	}
	switch cmd {
	case "version":
		short := hasFlag(rest, "-s", "--short")
		printVersion(short)
	case "help":
		if len(rest) == 0 {
			printMainHelp()
		} else if len(rest) == 1 {
			printHelp(rest[0])
		} else {
			return usageErr("error: unrecognized subcommand '" + rest[0] + "'")
		}
	case "init":
		return cmdInit(rest)
	case "new":
		return cmdNew(rest)
	case "series":
		return cmdSeries(rest)
	case "top":
		return cmdTop()
	case "next":
		return cmdNext()
	case "prev":
		return cmdPrev()
	case "pop":
		return cmdPop(rest)
	case "push":
		return cmdPush(rest)
	case "refresh":
		return cmdRefresh(rest)
	case "delete":
		return cmdDelete(rest)
	case "rename":
		return cmdRename(rest)
	case "files":
		return cmdFiles(rest)
	case "id":
		return cmdID(rest)
	case "name":
		return cmdName(rest)
	case "show":
		return cmdShow(rest)
	case "diff":
		return cmdDiff(rest)
	case "branch":
		return cmdBranch(rest)
	case "status", "add", "rm", "mv", "resolved":
		return gitAlias(cmd, rest)
	default:
		return usageErr("error: unrecognized subcommand '" + cmd + "'")
	}
	return nil
}

func usageErr(msg string) error {
	fmt.Fprintln(os.Stderr, msg)
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr, "Usage: stg [OPTIONS] <command> [...]")
	fmt.Fprintln(os.Stderr, "       stg [OPTIONS] <-h|--help>")
	fmt.Fprintln(os.Stderr, "       stg --version")
	fmt.Fprintln(os.Stderr)
	fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
	return exitError{2}
}

func printVersion(short bool) {
	if short {
		fmt.Println("Stacked Git 2.5.5")
		return
	}
	fmt.Println(versionText)
	out, _ := gitOut("version")
	if strings.TrimSpace(out) != "" {
		fmt.Print(out)
	}
}

func printMainHelp() {
	fmt.Println(`Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  edit     Edit a patch
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch

Stack inspection commands:
  next    Print the name of the next patch
  prev    Print the name of the previous patch
  series  Display the patch series
  top     Print the name of the top patch

Stack manipulation commands:
  branch  Branch operations: switch, list, create, rename, delete, ...
  delete  Delete patches
  init    Initialize a StGit stack on a branch
  pop     Pop (unapply) one or more applied patches
  push    Push (apply) one or more unapplied patches

Administration commands:
  version  Print version information and exit

Aliases:
  add       Alias for shell command ` + "`git add`" + `
  mv        Alias for shell command ` + "`git mv`" + `
  resolved  Alias for shell command ` + "`git add`" + `
  rm        Alias for shell command ` + "`git rm`" + `
  status    Alias for shell command ` + "`git status -s`" + `

Help:
  help  Print this message or the help of the given subcommand(s)

Options:
      --version
          Print version information

  -C <path>
          Run as if stg was started in '<path>' instead of the current working directory.

      --color <when>
          Specify when to colorize the output.

  -h, --help
          Print help (see a summary with '-h')`)
}

func printHelp(cmd string) {
	switch cmd {
	case "new":
		fmt.Println("Create a new, empty patch on the current stack.\n\nUsage: stg new [OPTIONS] [patchname] [-- <path>...]\n\nOptions:\n  -n, --name <name>\n  -r, --refresh\n  -i, --index\n  -m, --message <message>\n  -f, --file <path>\n  -h, --help")
	case "series":
		fmt.Println("Display the patch series\n\nUsage: stg series [OPTIONS]\n\nOptions:\n  -a, --all\n  -A, --applied\n  -U, --unapplied\n  -H, --hidden\n  -c, --count\n  -s, --short[=<n>]\n  -h, --help")
	case "top", "next", "prev", "init", "pop", "push", "refresh", "delete", "rename", "files", "id", "name", "show", "diff", "branch", "version":
		fmt.Printf("%s\n\nUsage: stg %s [OPTIONS]\n\nOptions:\n  -h, --help\n", shortDesc(cmd), cmd)
	default:
		printMainHelp()
	}
}

func shortDesc(cmd string) string {
	m := map[string]string{"top": "Print the name of the top patch.", "next": "Print the name of the next patch.", "prev": "Print the name of the previous patch.", "init": "Initialize a StGit stack on a branch.", "pop": "Pop (unapply) one or more applied patches.", "push": "Push one or more unapplied patches from the series onto the stack.", "refresh": "Include the latest work tree and index changes in the current patch.", "delete": "Delete patches", "rename": "Rename a patch.", "files": "Show the files modified by a patch.", "id": "Print the hash (object id) of a StGit revision.", "name": "Print the patch name of a StGit revision.", "show": "Show the commit log and diff corresponding to the given patches.", "diff": "Show the diff.", "branch": "Create, clone, switch, rename, or delete StGit-enabled branches.", "version": "Print version information and exit"}
	return m[cmd]
}

func gitAlias(cmd string, args []string) error {
	g := cmd
	if cmd == "status" {
		args = append([]string{"status", "-s"}, args...)
		return gitRun(args...)
	}
	if cmd == "resolved" {
		g = "add"
	}
	return gitRun(append([]string{g}, args...)...)
}

func cmdInit(args []string) error {
	st, err := loadOrInit()
	if err != nil {
		return err
	}
	return saveState(st)
}

func cmdNew(args []string) error {
	var name, msg, file string
	refresh := false
	paths := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--":
			paths = append(paths, args[i+1:]...)
			i = len(args)
		case a == "-r" || a == "--refresh" || a == "-i" || a == "--index":
			refresh = true
		case a == "-m" || a == "--message":
			i++
			if i < len(args) {
				msg = args[i]
			}
		case strings.HasPrefix(a, "--message="):
			msg = strings.TrimPrefix(a, "--message=")
		case a == "-f" || a == "--file":
			i++
			if i < len(args) {
				file = args[i]
			}
		case a == "-n" || a == "--name":
			i++
			if i < len(args) {
				name = args[i]
			}
		case strings.HasPrefix(a, "--name="):
			name = strings.TrimPrefix(a, "--name=")
		case strings.HasPrefix(a, "-"):
		default:
			if name == "" {
				name = strings.TrimPrefix(a, `\`)
			} else {
				paths = append(paths, a)
				refresh = true
			}
		}
	}
	if file != "" {
		b, err := readMessageFile(file)
		if err != nil {
			return err
		}
		msg = string(b)
	}
	if msg == "" {
		msg = name
	}
	if name == "" {
		name = patchNameFromMsg(msg)
	}
	if name == "" {
		return usageErr("error: patch name or message is required")
	}
	st, err := loadOrInit()
	if err != nil {
		return err
	}
	if findPatch(st, name) >= 0 {
		return fail("error: patch `%s` already exists", name)
	}
	if refresh {
		if len(paths) == 0 {
			if err := gitRunQuiet("add", "-A"); err != nil {
				return err
			}
		} else {
			if err := gitRunQuiet(append([]string{"add", "-A", "--"}, paths...)...); err != nil {
				return err
			}
		}
	}
	if err := gitRunQuiet("commit", "--allow-empty", "-m", msg); err != nil {
		return err
	}
	sha, _ := head()
	st.Applied = append(st.Applied, Patch{Name: name, Commit: sha, Message: firstLine(msg)})
	if err := saveState(st); err != nil {
		return err
	}
	fmt.Printf("> %s (new)\n", name)
	return nil
}

func cmdSeries(args []string) error {
	st, err := loadState()
	if err != nil {
		return nil
	}
	count := hasFlag(args, "-c", "--count")
	appliedOnly, unappliedOnly, hiddenOnly := hasFlag(args, "-A", "--applied"), hasFlag(args, "-U", "--unapplied"), hasFlag(args, "-H", "--hidden")
	all := hasFlag(args, "-a", "--all")
	lines := []string{}
	if (!unappliedOnly && !hiddenOnly) || appliedOnly || all {
		for i, p := range st.Applied {
			prefix := "+"
			if i == len(st.Applied)-1 {
				prefix = ">"
			}
			lines = append(lines, prefix+" "+p.Name)
		}
	}
	if (!appliedOnly && !hiddenOnly) || unappliedOnly || all {
		for _, p := range st.Unapplied {
			lines = append(lines, "- "+p.Name)
		}
	}
	if hiddenOnly || all {
		for _, p := range st.Hidden {
			lines = append(lines, "! "+p.Name)
		}
	}
	if count {
		fmt.Println(len(lines))
		return nil
	}
	for _, l := range lines {
		fmt.Println(l)
	}
	return nil
}

func cmdTop() error {
	st, err := loadState()
	if err != nil || len(st.Applied) == 0 {
		return fail("error: no patches applied")
	}
	fmt.Println(st.Applied[len(st.Applied)-1].Name)
	return nil
}
func cmdNext() error {
	st, err := loadState()
	if err != nil || len(st.Unapplied) == 0 {
		return fail("error: no unapplied patches")
	}
	fmt.Println(st.Unapplied[0].Name)
	return nil
}
func cmdPrev() error {
	st, err := loadState()
	if err != nil || len(st.Applied) < 2 {
		return fail("error: not enough patches applied")
	}
	fmt.Println(st.Applied[len(st.Applied)-2].Name)
	return nil
}

func cmdPop(args []string) error {
	st, err := loadState()
	if err != nil {
		return fail("error: no patches applied")
	}
	n := 1
	if hasFlag(args, "-a", "--all") {
		n = len(st.Applied)
	}
	if v, ok := flagValue(args, "-n", "--number"); ok {
		if x, e := strconv.Atoi(v); e == nil {
			if x < 0 {
				n = len(st.Applied) + x
			} else {
				n = x
			}
		}
	}
	if n < 0 {
		n = 0
	}
	if n > len(st.Applied) {
		n = len(st.Applied)
	}
	if n == 0 || len(st.Applied) == 0 {
		return fail("error: no patches applied")
	}
	for i := 0; i < n; i++ {
		p := st.Applied[len(st.Applied)-1]
		if err := gitRunQuiet("reset", "--hard", "HEAD^"); err != nil {
			return err
		}
		st.Applied = st.Applied[:len(st.Applied)-1]
		st.Unapplied = append([]Patch{p}, st.Unapplied...)
		fmt.Printf("- %s\n", p.Name)
	}
	return saveState(st)
}

func cmdPush(args []string) error {
	st, err := loadState()
	if err != nil {
		return fail("error: no unapplied patches")
	}
	n := 1
	if hasFlag(args, "-a", "--all") {
		n = len(st.Unapplied)
	}
	if v, ok := flagValue(args, "-n", "--number"); ok {
		if x, e := strconv.Atoi(v); e == nil {
			if x < 0 {
				n = len(st.Unapplied) + x
			} else {
				n = x
			}
		}
	}
	if n < 0 {
		n = 0
	}
	if n > len(st.Unapplied) {
		n = len(st.Unapplied)
	}
	if n == 0 || len(st.Unapplied) == 0 {
		return fail("error: no unapplied patches")
	}
	for i := 0; i < n; i++ {
		p := st.Unapplied[0]
		if hasFlag(args, "--noapply") {
		} else if err := gitRunQuiet("cherry-pick", p.Commit); err != nil {
			return err
		}
		sha, _ := head()
		p.Commit = sha
		st.Unapplied = st.Unapplied[1:]
		st.Applied = append(st.Applied, p)
		fmt.Printf("> %s\n", p.Name)
	}
	return saveState(st)
}

func cmdRefresh(args []string) error {
	st, err := loadState()
	if err != nil || len(st.Applied) == 0 {
		return fail("error: no patches applied")
	}
	msg := ""
	paths := []string{}
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-m", "--message":
			i++
			if i < len(args) {
				msg = args[i]
			}
		case "--":
			paths = append(paths, args[i+1:]...)
			i = len(args)
		default:
			if !strings.HasPrefix(args[i], "-") {
				paths = append(paths, args[i])
			}
		}
	}
	if len(paths) == 0 {
		if err := gitRunQuiet("add", "-A"); err != nil {
			return err
		}
	} else {
		if err := gitRunQuiet(append([]string{"add", "-A", "--"}, paths...)...); err != nil {
			return err
		}
	}
	top := &st.Applied[len(st.Applied)-1]
	if msg == "" {
		if err := gitRunQuiet("commit", "--amend", "--allow-empty", "--no-edit"); err != nil {
			return err
		}
	} else {
		if err := gitRunQuiet("commit", "--amend", "--allow-empty", "-m", msg); err != nil {
			return err
		}
		top.Message = firstLine(msg)
	}
	sha, _ := head()
	top.Commit = sha
	if err := saveState(st); err != nil {
		return err
	}
	fmt.Printf("> %s\n", top.Name)
	return nil
}

func cmdDelete(args []string) error {
	st, err := loadState()
	if err != nil {
		return nil
	}
	if hasFlag(args, "-a", "--all") {
		st.Applied, st.Unapplied, st.Hidden = nil, nil, nil
		return saveState(st)
	}
	names := positional(args)
	if hasFlag(args, "-t", "--top") || len(names) == 0 {
		if len(st.Applied) == 0 {
			return fail("error: no patches applied")
		}
		p := st.Applied[len(st.Applied)-1]
		if !hasFlag(args, "--spill") {
			if err := gitRunQuiet("reset", "--hard", "HEAD^"); err != nil {
				return err
			}
		} else {
			_ = gitRunQuiet("reset", "--soft", "HEAD^")
		}
		st.Applied = st.Applied[:len(st.Applied)-1]
		fmt.Printf("# %s\n", p.Name)
		return saveState(st)
	}
	for _, name := range names {
		st = removeNamed(st, name)
	}
	return saveState(st)
}

func cmdRename(args []string) error {
	st, err := loadState()
	if err != nil {
		return err
	}
	pos := positional(args)
	if len(pos) == 0 {
		return usageErr("error: missing patch name")
	}
	old, new := "", ""
	if len(pos) == 1 {
		if len(st.Applied) == 0 {
			return fail("error: no patches applied")
		}
		old, new = st.Applied[len(st.Applied)-1].Name, pos[0]
	} else {
		old, new = pos[0], pos[1]
	}
	for i := range st.Applied {
		if st.Applied[i].Name == old {
			st.Applied[i].Name = new
			return saveState(st)
		}
	}
	for i := range st.Unapplied {
		if st.Unapplied[i].Name == old {
			st.Unapplied[i].Name = new
			return saveState(st)
		}
	}
	return fail("error: patch `%s` not found", old)
}

func cmdFiles(args []string) error {
	rev := "HEAD"
	bare, stat := hasFlag(args, "--bare"), hasFlag(args, "-s", "--stat")
	for _, p := range positional(args) {
		rev = resolveRevision(p)
		break
	}
	if stat {
		return gitRun("diff", "--stat", rev+"^", rev)
	}
	out, err := gitOut("diff-tree", "--no-commit-id", "--name-status", "-r", rev)
	if err != nil {
		return err
	}
	if bare {
		for _, line := range strings.Split(strings.TrimRight(out, "\n"), "\n") {
			f := strings.Fields(line)
			if len(f) > 1 {
				fmt.Println(f[len(f)-1])
			}
		}
		return nil
	}
	fmt.Print(out)
	return nil
}

func cmdID(args []string) error {
	rev := "HEAD"
	for _, p := range positional(args) {
		rev = resolveRevision(p)
		break
	}
	sha, err := gitOut("rev-parse", rev)
	if err != nil {
		return err
	}
	fmt.Print(sha)
	return nil
}
func cmdName(args []string) error {
	st, err := loadState()
	if err != nil {
		return err
	}
	rev := "HEAD"
	for _, p := range positional(args) {
		rev = p
		break
	}
	if rev == "HEAD" {
		if len(st.Applied) == 0 {
			return fail("error: no patches applied")
		}
		fmt.Println(st.Applied[len(st.Applied)-1].Name)
		return nil
	}
	if i := findPatch(st, rev); i >= 0 {
		fmt.Println(patchByIndex(st, i).Name)
		return nil
	}
	sha, _ := gitOut("rev-parse", rev)
	sha = strings.TrimSpace(sha)
	for _, p := range append(st.Applied, st.Unapplied...) {
		if strings.HasPrefix(p.Commit, sha) || strings.HasPrefix(sha, p.Commit) {
			fmt.Println(p.Name)
			return nil
		}
	}
	return fail("error: cannot find patch for `%s`", rev)
}
func cmdShow(args []string) error {
	gargs := []string{"show"}
	for _, a := range args {
		if a == "-s" || a == "--stat" {
			gargs = append(gargs, "--stat")
			continue
		}
		if strings.HasPrefix(a, "-") {
			continue
		}
		gargs = append(gargs, resolveRevision(a))
	}
	return gitRun(gargs...)
}
func cmdDiff(args []string) error {
	stat := hasFlag(args, "-s", "--stat")
	if r, ok := flagValue(args, "-r", "--range"); ok {
		parts := strings.SplitN(r, "..", 2)
		a, b := "HEAD", ""
		if len(parts) == 1 {
			a = resolveRevision(parts[0]) + "^"
			b = resolveRevision(parts[0])
		} else {
			a = resolveRevision(parts[0])
			b = resolveRevision(parts[1])
		}
		g := []string{"diff"}
		if stat {
			g = append(g, "--stat")
		}
		return gitRun(append(g, a, b)...)
	}
	g := []string{"diff"}
	if stat {
		g = append(g, "--stat")
	}
	for _, p := range positional(args) {
		g = append(g, "--", p)
	}
	return gitRun(g...)
}

func cmdBranch(args []string) error {
	if len(args) == 0 {
		out, err := gitOut("branch", "--show-current")
		if err != nil {
			return err
		}
		fmt.Print(out)
		return nil
	}
	if hasFlag(args, "-l", "--list") {
		return gitRun("branch")
	}
	if hasFlag(args, "-c", "--create") {
		pos := positional(args)
		if len(pos) == 0 {
			return usageErr("error: missing branch")
		}
		if len(pos) > 1 {
			return gitRun("checkout", "-b", pos[0], pos[1])
		}
		return gitRun("checkout", "-b", pos[0])
	}
	if hasFlag(args, "-r", "--rename") {
		pos := positional(args)
		return gitRun(append([]string{"branch", "-m"}, pos...)...)
	}
	if hasFlag(args, "-D", "--delete") {
		pos := positional(args)
		return gitRun(append([]string{"branch", "-D"}, pos...)...)
	}
	pos := positional(args)
	if len(pos) > 0 {
		return gitRun("checkout", pos[0])
	}
	return nil
}

func loadOrInit() (*State, error) {
	if st, err := loadState(); err == nil {
		return st, nil
	}
	br, err := currentBranch()
	if err != nil {
		return nil, err
	}
	h, err := head()
	if err != nil {
		return nil, err
	}
	return &State{Branch: br, Base: h}, nil
}
func loadState() (*State, error) {
	path, err := statePath()
	if err != nil {
		return nil, err
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var st State
	if err := json.Unmarshal(b, &st); err != nil {
		return nil, err
	}
	return &st, nil
}
func saveState(st *State) error {
	path, err := statePath()
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		return err
	}
	b, _ := json.MarshalIndent(st, "", "  ")
	return os.WriteFile(path, b, 0644)
}
func statePath() (string, error) {
	gd, err := gitOut("rev-parse", "--git-dir")
	if err != nil {
		return "", err
	}
	br, err := currentBranch()
	if err != nil {
		return "", err
	}
	clean := strings.NewReplacer("/", "_", "\\", "_").Replace(strings.TrimSpace(br))
	return filepath.Join(strings.TrimSpace(gd), "stg-go", clean+".json"), nil
}
func currentBranch() (string, error) {
	out, err := gitOut("branch", "--show-current")
	return strings.TrimSpace(out), err
}
func head() (string, error) {
	out, err := gitOut("rev-parse", "HEAD")
	return strings.TrimSpace(out), err
}

func gitRun(args ...string) error {
	c := exec.Command("git", args...)
	c.Stdin, c.Stdout, c.Stderr = os.Stdin, os.Stdout, os.Stderr
	return c.Run()
}
func gitRunQuiet(args ...string) error {
	c := exec.Command("git", args...)
	c.Stdin = os.Stdin
	c.Stderr = os.Stderr
	return c.Run()
}
func gitOut(args ...string) (string, error) {
	c := exec.Command("git", args...)
	var b bytes.Buffer
	c.Stdout = &b
	c.Stderr = os.Stderr
	err := c.Run()
	return b.String(), err
}

func fail(format string, args ...interface{}) error {
	fmt.Fprintf(os.Stderr, format+"\n", args...)
	return exitError{2}
}
func hasFlag(args []string, shorts ...string) bool {
	for _, a := range args {
		for _, s := range shorts {
			if a == s || strings.HasPrefix(a, s+"=") {
				return true
			}
		}
	}
	return false
}
func flagValue(args []string, names ...string) (string, bool) {
	for i, a := range args {
		for _, n := range names {
			if a == n && i+1 < len(args) {
				return args[i+1], true
			}
			if strings.HasPrefix(a, n+"=") {
				return strings.TrimPrefix(a, n+"="), true
			}
		}
	}
	return "", false
}
func positional(args []string) []string {
	out := []string{}
	skip := false
	valueFlags := map[string]bool{"-m": true, "--message": true, "-f": true, "--file": true, "-n": true, "--number": true, "--name": true, "-b": true, "--branch": true, "-r": true, "--range": true, "-O": true, "--diff-opt": true}
	for i, a := range args {
		if skip {
			skip = false
			continue
		}
		if a == "--" {
			out = append(out, args[i+1:]...)
			break
		}
		if valueFlags[a] {
			skip = true
			continue
		}
		if strings.HasPrefix(a, "-") {
			continue
		}
		out = append(out, strings.TrimPrefix(a, `\`))
	}
	return out
}
func patchNameFromMsg(msg string) string {
	s := strings.ToLower(firstLine(msg))
	re := regexp.MustCompile(`[^a-z0-9._-]+`)
	s = strings.Trim(re.ReplaceAllString(s, "-"), "-.")
	if s == "" {
		s = "patch"
	}
	return s
}
func firstLine(s string) string {
	s = strings.TrimSpace(s)
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}
func readMessageFile(path string) ([]byte, error) {
	if path == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(path)
}
func findPatch(st *State, name string) int {
	idx := 0
	for _, p := range st.Applied {
		if p.Name == name {
			return idx
		}
		idx++
	}
	for _, p := range st.Unapplied {
		if p.Name == name {
			return idx
		}
		idx++
	}
	for _, p := range st.Hidden {
		if p.Name == name {
			return idx
		}
		idx++
	}
	return -1
}
func patchByIndex(st *State, idx int) Patch {
	all := append(append([]Patch{}, st.Applied...), st.Unapplied...)
	all = append(all, st.Hidden...)
	return all[idx]
}
func resolveRevision(r string) string {
	if r == "" {
		return "HEAD"
	}
	if r == "{base}" {
		if st, err := loadState(); err == nil {
			return st.Base
		}
	}
	if st, err := loadState(); err == nil {
		name := r
		if i := strings.LastIndex(name, ":"); i >= 0 {
			name = name[i+1:]
		}
		if strings.HasSuffix(name, "^") {
			base := strings.TrimSuffix(name, "^")
			if i := findPatch(st, base); i >= 0 {
				return patchByIndex(st, i).Commit + "^"
			}
		}
		if i := findPatch(st, name); i >= 0 {
			return patchByIndex(st, i).Commit
		}
	}
	return r
}
func removeNamed(st *State, name string) *State {
	filter := func(in []Patch) []Patch {
		out := in[:0]
		for _, p := range in {
			if p.Name != name {
				out = append(out, p)
			}
		}
		return out
	}
	st.Applied = filter(st.Applied)
	st.Unapplied = filter(st.Unapplied)
	st.Hidden = filter(st.Hidden)
	return st
}
