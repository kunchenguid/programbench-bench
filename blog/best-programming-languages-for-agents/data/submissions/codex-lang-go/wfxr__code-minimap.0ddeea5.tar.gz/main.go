package main

import (
	"bytes"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
	"unicode/utf8"
)

const helpText = `A high performance code minimap generator

Usage: executable [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
`

const completionHelp = `Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
`

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	hscale, vscale := 1.0, 1.0
	padding := 0
	encoding := "utf8-lossy"
	file := ""

	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return 0
		case "--version":
			fmt.Println("code-minimap 0.6.8")
			return 0
		case "help":
			if i+1 < len(args) && args[i+1] == "completion" {
				fmt.Print(completionHelp)
			} else {
				fmt.Print(helpText)
			}
			return 0
		case "completion":
			if i+1 >= len(args) || args[i+1] == "-h" || args[i+1] == "--help" {
				fmt.Print(completionHelp)
				return 0
			}
			return emitCompletion(args[i+1])
		case "-H", "--horizontal-scale":
			val, ok := nextValue(args, &i, a)
			if !ok {
				return 2
			}
			f, err := strconv.ParseFloat(val, 64)
			if err != nil {
				argError(fmt.Sprintf("invalid value '%s' for '--horizontal-scale <HSCALE>'", val))
				return 2
			}
			hscale = f
		case "-V", "--vertical-scale":
			val, ok := nextValue(args, &i, a)
			if !ok {
				return 2
			}
			f, err := strconv.ParseFloat(val, 64)
			if err != nil {
				argError(fmt.Sprintf("invalid value '%s' for '--vertical-scale <VSCALE>'", val))
				return 2
			}
			vscale = f
		case "--padding":
			val, ok := nextValue(args, &i, a)
			if !ok {
				return 2
			}
			n, err := strconv.Atoi(val)
			if err != nil || n < 0 {
				unexpected(val)
				return 2
			}
			padding = n
		case "--encoding":
			val, ok := nextValue(args, &i, a)
			if !ok {
				return 2
			}
			if val != "utf8-lossy" && val != "utf8" {
				fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '--encoding <ENCODING>'\n  [possible values: utf8-lossy, utf8]\n\nFor more information, try '--help'.\n", val)
				return 2
			}
			encoding = val
		default:
			if strings.HasPrefix(a, "-") {
				unexpected(a)
				return 2
			}
			if file == "" {
				file = a
			} else {
				unexpected(a)
				return 2
			}
		}
	}

	var data []byte
	var err error
	if file == "" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(file)
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "code-minimap: %s\n", err)
		return 1
	}
	if encoding == "utf8" && !utf8.Valid(data) {
		fmt.Fprintln(os.Stderr, "code-minimap: stream did not contain valid UTF-8")
		return 1
	}
	if encoding == "utf8-lossy" && !utf8.Valid(data) {
		data = []byte(strings.ToValidUTF8(string(data), "\uFFFD"))
	}
	out := render(data, hscale, vscale, padding)
	os.Stdout.Write(out)
	return 0
}

func nextValue(args []string, i *int, opt string) (string, bool) {
	if *i+1 >= len(args) {
		fmt.Fprintf(os.Stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n", opt)
		return "", false
	}
	*i = *i + 1
	return args[*i], true
}

func argError(msg string) {
	fmt.Fprintf(os.Stderr, "error: %s\n\nFor more information, try '--help'.\n", msg)
}

func unexpected(a string) {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n", a)
}

func emitCompletion(shell string) int {
	switch shell {
	case "bash":
		fmt.Print("_code-minimap() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n}\ncomplete -F _code-minimap -o bashdefault -o default code-minimap\n")
	case "zsh":
		fmt.Print("#compdef code-minimap\n\n_code-minimap() {\n    _arguments '*::arg:->args'\n}\n")
	case "fish":
		fmt.Print("# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.\nfunction __fish_code_minimap_global_optspecs\n\tstring join \\n H/horizontal-scale= V/vertical-scale= padding= encoding= version h/help\nend\n")
	case "elvish":
		fmt.Print("\nuse builtin;\nuse str;\n\nset edit:completion:arg-completer[code-minimap] = {|@words| }\n")
	case "powershell":
		fmt.Print("using namespace System.Management.Automation\nusing namespace System.Management.Automation.Language\n\nRegister-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock {\n}\n")
	default:
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", shell)
		return 2
	}
	return 0
}

func render(data []byte, hscale, vscale float64, padding int) []byte {
	lines := bytes.Split(data, []byte{'\n'})
	if len(lines) > 0 && len(lines[len(lines)-1]) == 0 {
		lines = lines[:len(lines)-1]
	}
	if len(lines) == 0 {
		return nil
	}

	scaledRows := scaleRows(len(lines), vscale)
	maxCols := 0
	rowBits := make([][]bool, scaledRows)
	vy := vscale
	if vy < 0 {
		vy = 0
	}
	if vy > 1 {
		vy = 1
	}
	for sy, line := range lines {
		y := int(math.Floor(float64(sy) * vy))
		if y >= scaledRows {
			y = scaledRows - 1
		}
		bits := scaleLine(line, hscale)
		if len(bits) > len(rowBits[y]) {
			merged := make([]bool, len(bits))
			copy(merged, rowBits[y])
			rowBits[y] = merged
		}
		for x, bit := range bits {
			rowBits[y][x] = rowBits[y][x] || bit
		}
	}
	for y := range rowBits {
		if len(rowBits[y]) > maxCols {
			maxCols = len(rowBits[y])
		}
	}

	contentCellsW := int(math.Ceil(float64(maxCols) / 2.0))
	cellsW := contentCellsW
	if cellsW < padding {
		cellsW = padding
	}
	cellsH := int(math.Ceil(float64(scaledRows) / 4.0))
	if cellsH == 0 {
		return nil
	}

	var out bytes.Buffer
	dotBits := [4][2]rune{{0x01, 0x08}, {0x02, 0x10}, {0x04, 0x20}, {0x40, 0x80}}
	for cy := 0; cy < cellsH; cy++ {
		for cx := 0; cx < cellsW; cx++ {
			if cx >= contentCellsW {
				out.WriteByte(' ')
				continue
			}
			var mask rune
			for dy := 0; dy < 4; dy++ {
				y := cy*4 + dy
				if y >= scaledRows {
					continue
				}
				for dx := 0; dx < 2; dx++ {
					x := cx*2 + dx
					if x < len(rowBits[y]) && rowBits[y][x] {
						mask |= dotBits[dy][dx]
					}
				}
			}
			out.WriteRune(0x2800 + mask)
		}
		out.WriteByte('\n')
	}
	return out.Bytes()
}

func scaleRows(n int, v float64) int {
	if v < 0 {
		v = 0
	}
	if v > 1 {
		v = 1
	}
	rows := int(math.Ceil(float64(n) * v))
	if rows < 1 {
		rows = 1
	}
	return rows
}

func scaleLine(line []byte, h float64) []bool {
	if h < 0 {
		h = 0
	}
	first, last := -1, -1
	for i, b := range line {
		if !isIgnored(b) {
			if first == -1 {
				first = i
			}
			last = i
		}
	}
	effectiveLen := len(line)
	if last >= 0 {
		effectiveLen = last + 1
	}
	w := int(math.Floor(float64(effectiveLen) * h))
	if w <= 0 {
		return nil
	}
	bits := make([]bool, w)
	for x := 0; x < w; x++ {
		start := int(math.Floor(float64(x) * float64(effectiveLen) / float64(w)))
		end := int(math.Ceil(float64(x+1) * float64(effectiveLen) / float64(w)))
		if end <= start {
			end = start + 1
		}
		if end > effectiveLen {
			end = effectiveLen
		}
		for src := start; src < end; src++ {
			if first >= 0 && src >= first && src <= last {
				bits[x] = true
				break
			}
		}
		if first >= 0 && w > effectiveLen {
			src := sourceIndex(x, w, effectiveLen)
			if src >= first && src <= last {
				bits[x] = true
			}
		}
		if first < 0 {
			bits[x] = false
		}
		if bits[x] {
			bits[x] = true
		}
	}
	return bits
}

func sourceIndex(dst, dstN, srcN int) int {
	if srcN <= 1 || dstN <= 1 {
		return 0
	}
	idx := int(math.Floor((float64(dst)+0.5)*float64(srcN)/float64(dstN) - 0.5))
	if idx < 0 {
		return 0
	}
	if idx >= srcN {
		return srcN - 1
	}
	return idx
}

func isIgnored(b byte) bool {
	switch b {
	case ' ', '\t', '\r', '\v', '\f':
		return true
	default:
		return false
	}
}
