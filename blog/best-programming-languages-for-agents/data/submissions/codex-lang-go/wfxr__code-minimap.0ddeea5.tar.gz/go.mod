module code-minimap-reimpl

go 1.21
