package main

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

type options struct {
	after, before int
	contextSet    bool
	ackmate       bool
	allTypes      bool
	allText       bool
	unrestricted  bool
	hidden        bool
	follow        bool
	norecurse     bool
	ignoreCase    bool
	caseSensitive bool
	smartCase     bool
	literal       bool
	word          bool
	invert        bool
	count         bool
	filesWith     bool
	filesWithout  bool
	onlyMatching  bool
	vimgrep       bool
	column        bool
	heading       bool
	noHeading     bool
	breaks        bool
	noBreaks      bool
	filename      *bool
	numbers       *bool
	passthrough   bool
	nullSep       bool
	stats         bool
	statsOnly     bool
	silent        bool
	searchBinary  bool
	searchZip     bool
	printAllFiles bool
	maxCount      int
	depth         int
	width         int
	fileRegex     string
	filenamePat   string
	ignorePats    []string
	pathIgnore    string
	typeFilters   []string
	color         bool
	colorPath     string
	colorLine     string
	colorMatch    string
}

var typeMap = map[string][]string{
	"actionscript": {".as", ".mxml"}, "ada": {".ada", ".adb", ".ads"}, "asciidoc": {".adoc", ".ad", ".asc", ".asciidoc"},
	"apl": {".apl"}, "asm": {".asm", ".s"}, "asp": {".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"},
	"aspx": {".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"}, "batch": {".bat", ".cmd"}, "bazel": {".bazel"},
	"bitbake": {".bb", ".bbappend", ".bbclass", ".inc"}, "cc": {".c", ".h", ".xs"}, "cfmx": {".cfc", ".cfm", ".cfml"},
	"chpl": {".chpl"}, "clojure": {".clj", ".cljs", ".cljc", ".cljx", ".edn"}, "coffee": {".coffee", ".cjsx"},
	"config": {".config"}, "coq": {".coq", ".g", ".v"}, "cpp": {".cpp", ".cc", ".C", ".cxx", ".m", ".hpp", ".hh", ".h", ".H", ".hxx", ".tpp"},
	"crystal": {".cr", ".ecr"}, "csharp": {".cs"}, "cshtml": {".cshtml"}, "css": {".css"}, "cython": {".pyx", ".pxd", ".pxi"},
	"delphi": {".pas", ".int", ".dfm", ".nfm", ".dof", ".dpk", ".dpr", ".dproj", ".groupproj", ".bdsgroup", ".bdsproj"},
	"dlang": {".d", ".di"}, "dot": {".dot", ".gv"}, "dts": {".dts", ".dtsi"}, "ebuild": {".ebuild", ".eclass"},
	"elisp": {".el"}, "elixir": {".ex", ".eex", ".exs"}, "elm": {".elm"}, "erlang": {".erl", ".hrl"}, "factor": {".factor"},
	"fortran": {".f", ".F", ".f77", ".f90", ".F90", ".f95", ".f03", ".for", ".ftn", ".fpp", ".FPP"}, "fsharp": {".fs", ".fsi", ".fsx"},
	"gettext": {".po", ".pot", ".mo"}, "glsl": {".vert", ".tesc", ".tese", ".geom", ".frag", ".comp"}, "go": {".go"}, "gradle": {".gradle"},
	"groovy": {".groovy", ".gtmpl", ".gpp", ".grunit", ".gradle"}, "haml": {".haml"}, "handlebars": {".hbs"}, "haskell": {".hs", ".hsig", ".lhs"},
	"haxe": {".hx"}, "hh": {".h"}, "html": {".htm", ".html", ".shtml", ".xhtml"}, "idris": {".idr", ".ipkg", ".lidr"}, "ini": {".ini"},
	"ipython": {".ipynb"}, "isabelle": {".thy"}, "j": {".ijs"}, "jade": {".jade"}, "java": {".java", ".properties"}, "jinja2": {".j2"},
	"js": {".es6", ".js", ".jsx", ".vue"}, "json": {".json"}, "jsp": {".jsp", ".jspx", ".jhtm", ".jhtml", ".jspf", ".tag", ".tagf"},
	"julia": {".jl"}, "kotlin": {".kt"}, "less": {".less"}, "liquid": {".liquid"}, "lisp": {".lisp", ".lsp"}, "log": {".log"}, "lua": {".lua"},
	"m4": {".m4"}, "make": {".Makefiles", ".mk", ".mak"}, "mako": {".mako"}, "markdown": {".markdown", ".mdown", ".mdwn", ".mkdn", ".mkd", ".md"},
	"mason": {".mas", ".mhtml", ".mpl", ".mtxt"}, "matlab": {".m"}, "mathematica": {".m", ".wl"}, "md": {".markdown", ".mdown", ".mdwn", ".mkdn", ".mkd", ".md"},
	"mercury": {".m", ".moo"}, "naccess": {".asa", ".rsa"}, "nim": {".nim"}, "nix": {".nix"}, "objc": {".m", ".h"}, "objcpp": {".mm", ".h"},
	"ocaml": {".ml", ".mli", ".mll", ".mly"}, "octave": {".m"}, "org": {".org"}, "parrot": {".pir", ".pasm", ".pmc", ".ops", ".pod", ".pg", ".tg"},
	"pdb": {".pdb"}, "perl": {".pl", ".pm", ".pm6", ".pod", ".t"}, "php": {".php", ".phpt", ".php3", ".php4", ".php5", ".phtml"},
	"pike": {".pike", ".pmod"}, "plist": {".plist"}, "plone": {".pt", ".cpt", ".metadata", ".cpy", ".py", ".xml", ".zcml"}, "powershell": {".ps1"},
	"proto": {".proto"}, "ps1": {".ps1"}, "pug": {".pug"}, "puppet": {".pp"}, "python": {".py"}, "qml": {".qml"}, "racket": {".rkt", ".ss", ".scm"},
	"rake": {".Rakefile"}, "razor": {".cshtml"}, "restructuredtext": {".rst"}, "rs": {".rs"}, "r": {".r", ".R", ".Rmd", ".Rnw", ".Rtex", ".Rrst"},
	"rdoc": {".rdoc"}, "ruby": {".rb", ".rhtml", ".rjs", ".rxml", ".erb", ".rake", ".spec"}, "rust": {".rs"}, "salt": {".sls"}, "sass": {".sass", ".scss"},
	"scala": {".scala"}, "scheme": {".scm", ".ss"}, "shell": {".sh", ".bash", ".csh", ".tcsh", ".ksh", ".zsh", ".fish"}, "smalltalk": {".st"},
	"sml": {".sml", ".fun", ".mlb", ".sig"}, "sql": {".sql", ".ctl"}, "stata": {".do", ".ado"}, "stylus": {".styl"}, "swift": {".swift"},
	"tcl": {".tcl", ".itcl", ".itk"}, "terraform": {".tf", ".tfvars"}, "tex": {".tex", ".cls", ".sty"}, "thrift": {".thrift"}, "tla": {".tla"},
	"tt": {".tt", ".tt2", ".ttml"}, "toml": {".toml"}, "ts": {".ts", ".tsx"}, "twig": {".twig"}, "vala": {".vala", ".vapi"},
	"vb": {".bas", ".cls", ".frm", ".ctl", ".vb", ".resx"}, "velocity": {".vm", ".vtl", ".vsl"}, "verilog": {".v", ".vh", ".sv", ".svh"},
	"vhdl": {".vhd", ".vhdl"}, "vim": {".vim"}, "vue": {".vue"}, "wix": {".wxi", ".wxs"}, "wsdl": {".wsdl"}, "wadl": {".wadl"},
	"xml": {".xml", ".dtd", ".xsl", ".xslt", ".xsd", ".ent", ".tld", ".plist", ".wsdl"}, "yaml": {".yaml", ".yml"}, "zeek": {".zeek", ".bro", ".bif"}, "zephir": {".zep"},
}

type lineMatch struct {
	lineNo int
	text   string
	ranges [][2]int
}

type fileResult struct {
	path    string
	lines   []string
	matches []lineMatch
	binary  bool
	err     error
}

func boolPtr(v bool) *bool { return &v }

func main() {
	opt := defaultOptions()
	args, err := parseArgs(os.Args[1:], &opt)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if len(args) == 0 {
		printHelp()
		return
	}
	if opt.filenamePat != "" {
		runFilenameSearch(opt, args)
		return
	}
	opt.ignorePats = append(opt.ignorePats, loadIgnorePatterns(opt, args[1:])...)
	pattern := args[0]
	paths := args[1:]
	if len(paths) == 0 {
		paths = []string{"."}
	}
	matcher, err := makeMatcher(pattern, opt)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERR: %s\n", err)
		os.Exit(2)
	}
	var results []fileResult
	filesScanned := 0
	if stat, _ := os.Stdin.Stat(); stat != nil && (stat.Mode()&os.ModeCharDevice) == 0 && len(os.Args) > 1 && len(args) == 1 {
		res := searchReader("", os.Stdin, matcher, opt)
		results = append(results, res)
		filesScanned = 1
	} else {
		files := collectFiles(paths, opt)
		for _, f := range files {
			res := searchFile(f, matcher, opt)
			if res.err != nil {
				if !opt.silent {
					fmt.Fprintf(os.Stderr, "ERR: %s: %v\n", f, res.err)
				}
				continue
			}
			filesScanned++
			if len(res.matches) > 0 || opt.filesWithout || opt.printAllFiles {
				results = append(results, res)
			}
		}
	}
	printResults(results, opt, len(paths) != 1 || isDir(paths[0]))
	if opt.stats || opt.statsOnly {
		fmt.Fprintf(os.Stderr, "%d files searched\n", filesScanned)
	}
	if successful(results, opt) {
		os.Exit(0)
	}
	os.Exit(1)
}

func defaultOptions() options {
	return options{smartCase: true, breaks: true, maxCount: 10000, depth: 25, colorPath: "1;32", colorLine: "1;33", colorMatch: "30;43"}
}

func parseArgs(argv []string, opt *options) ([]string, error) {
	var out []string
	stop := false
	for i := 0; i < len(argv); i++ {
		a := argv[i]
		if stop || a == "-" || !strings.HasPrefix(a, "-") || a == "-" {
			out = append(out, a)
			continue
		}
		if a == "--" {
			stop = true
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasVal := strings.Cut(a[2:], "=")
			if exts, ok := typeMap[name]; ok {
				_ = exts
				opt.typeFilters = append(opt.typeFilters, name)
				continue
			}
			switch name {
			case "help":
				printHelp(); os.Exit(0)
			case "version":
				printVersion(); os.Exit(0)
			case "list-file-types":
				printFileTypes(); os.Exit(0)
			case "ackmate":
				opt.ackmate = true
			case "all-types":
				opt.allTypes = true
			case "all-text":
				opt.allText = true
			case "unrestricted":
				opt.unrestricted = true; opt.hidden = true; opt.searchBinary = true; opt.allTypes = true
			case "hidden":
				opt.hidden = true
			case "follow":
				opt.follow = true
			case "nofollow":
				opt.follow = false
			case "recurse":
				opt.norecurse = false
			case "norecurse":
				opt.norecurse = true
			case "ignore-case":
				opt.ignoreCase = true; opt.caseSensitive = false
			case "case-sensitive":
				opt.caseSensitive = true; opt.ignoreCase = false; opt.smartCase = false
			case "smart-case":
				opt.smartCase = true
			case "literal", "fixed-strings":
				opt.literal = true
			case "word-regexp":
				opt.word = true
			case "invert-match":
				opt.invert = true
			case "count":
				opt.count = true
			case "files-with-matches":
				opt.filesWith = true
			case "files-without-matches":
				opt.filesWithout = true
			case "only-matching":
				opt.onlyMatching = true
			case "vimgrep":
				opt.vimgrep = true
			case "column":
				opt.column = true
			case "heading":
				opt.heading = true; opt.noHeading = false
			case "noheading":
				opt.noHeading = true; opt.heading = false
			case "break":
				opt.breaks = true; opt.noBreaks = false
			case "nobreak":
				opt.noBreaks = true; opt.breaks = false
			case "group":
				opt.heading = true; opt.breaks = true
			case "nogroup":
				opt.noHeading = true; opt.noBreaks = true
			case "filename":
				opt.filename = boolPtr(true)
			case "nofilename":
				opt.filename = boolPtr(false)
			case "numbers":
				opt.numbers = boolPtr(true)
			case "nonumbers":
				opt.numbers = boolPtr(false)
			case "passthrough", "passthru":
				opt.passthrough = true
			case "null", "print0":
				opt.nullSep = true
			case "stats":
				opt.stats = true
			case "stats-only":
				opt.stats = true; opt.statsOnly = true
			case "silent":
				opt.silent = true
			case "search-binary":
				opt.searchBinary = true
			case "search-zip":
				opt.searchZip = true
			case "print-all-files":
				opt.printAllFiles = true
			case "color":
				opt.color = true
			case "nocolor":
				opt.color = false
			case "after", "before", "context":
				if !hasVal {
					if i+1 < len(argv) && isInteger(argv[i+1]) {
						i++; val = argv[i]
					} else {
						val = "2"
					}
				}
				setLongValue(name, val, opt)
			case "depth", "max-count", "width", "file-search-regex", "ignore", "ignore-dir", "path-to-ignore", "color-line-number", "color-match", "color-path", "workers", "pager":
				if !hasVal {
					if i+1 >= len(argv) {
						return nil, fmt.Errorf("Option --%s requires an argument.", name)
					}
					i++; val = argv[i]
				}
				setLongValue(name, val, opt)
			case "affinity", "noaffinity", "mmap", "nommap", "multiline", "nomultiline", "one-device", "parallel", "nopager":
			default:
				return nil, fmt.Errorf("Unknown option: --%s", name)
			}
			continue
		}
		if strings.HasPrefix(a, "-") {
			if err := parseShort(a[1:], argv, &i, opt); err != nil {
				return nil, err
			}
		}
	}
	return out, nil
}

func parseShort(s string, argv []string, i *int, opt *options) error {
	for pos := 0; pos < len(s); pos++ {
		ch := s[pos]
		rest := s[pos+1:]
		need := func(name string) (string, error) {
			if rest != "" {
				pos = len(s)
				return rest, nil
			}
			if *i+1 >= len(argv) {
				return "", fmt.Errorf("Option -%c requires an argument.", ch)
			}
			*i++
			pos = len(s)
			return argv[*i], nil
		}
		switch ch {
		case 'A':
			v, err := optionalNum(rest, argv, i, 2); if err != nil { return err }; opt.after = v; pos = len(s)
		case 'B':
			v, err := optionalNum(rest, argv, i, 2); if err != nil { return err }; opt.before = v; pos = len(s)
		case 'C':
			v, err := optionalNum(rest, argv, i, 2); if err != nil { return err }; opt.before = v; opt.after = v; opt.contextSet = true; pos = len(s)
		case 'a':
			opt.allTypes = true
		case 'c':
			opt.count = true
		case 'D':
		case 'f':
			opt.follow = true
		case 'F', 'Q':
			opt.literal = true
		case 'G':
			v, err := need("G"); if err != nil { return err }; opt.fileRegex = v
		case 'g':
			v, err := need("g"); if err != nil { return err }; opt.filenamePat = v
		case 'H':
			opt.heading = true
		case 'i':
			opt.ignoreCase = true; opt.caseSensitive = false
		case 'l':
			opt.filesWith = true
		case 'L':
			opt.filesWithout = true
		case 'm':
			v, err := need("m"); if err != nil { return err }; opt.maxCount, _ = strconv.Atoi(v)
		case 'n':
			opt.norecurse = true
		case 'o':
			opt.onlyMatching = true
		case 'p':
			v, err := need("p"); if err != nil { return err }; opt.pathIgnore = v
		case 'r':
			opt.norecurse = false
		case 's':
			opt.caseSensitive = true; opt.ignoreCase = false; opt.smartCase = false
		case 'S':
			opt.smartCase = true
		case 't':
			opt.allText = true
		case 'u':
			opt.unrestricted = true; opt.hidden = true; opt.searchBinary = true; opt.allTypes = true
		case 'U':
			// Handled approximately by not loading VCS ignores separately.
		case 'v':
			opt.invert = true
		case 'V':
			printVersion(); os.Exit(0)
		case 'w':
			opt.word = true
		case 'W':
			v, err := need("W"); if err != nil { return err }; opt.width, _ = strconv.Atoi(v)
		case 'z':
			opt.searchZip = true
		case '0':
			opt.nullSep = true
		default:
			return fmt.Errorf("Unknown option: -%c", ch)
		}
	}
	return nil
}

func optionalNum(rest string, argv []string, i *int, def int) (int, error) {
	if rest != "" {
		v, err := strconv.Atoi(rest)
		return v, err
	}
	if *i+1 < len(argv) && isInteger(argv[*i+1]) {
		*i++
		v, _ := strconv.Atoi(argv[*i])
		return v, nil
	}
	return def, nil
}

func isInteger(s string) bool {
	if s == "" { return false }
	for _, r := range s {
		if !unicode.IsDigit(r) { return false }
	}
	return true
}

func setLongValue(name, val string, opt *options) {
	switch name {
	case "after":
		opt.after, _ = strconv.Atoi(val)
	case "before":
		opt.before, _ = strconv.Atoi(val)
	case "context":
		n, _ := strconv.Atoi(val); opt.before = n; opt.after = n; opt.contextSet = true
	case "depth":
		opt.depth, _ = strconv.Atoi(val)
	case "max-count":
		opt.maxCount, _ = strconv.Atoi(val)
	case "width":
		opt.width, _ = strconv.Atoi(val)
	case "file-search-regex":
		opt.fileRegex = val
	case "ignore", "ignore-dir":
		opt.ignorePats = append(opt.ignorePats, val)
	case "path-to-ignore":
		opt.pathIgnore = val
	case "color-line-number":
		opt.colorLine = val
	case "color-match":
		opt.colorMatch = val
	case "color-path":
		opt.colorPath = val
	}
}

type matcher struct {
	re      *regexp.Regexp
	lit     string
	lower   bool
	literal bool
	word    bool
	invert  bool
}

func makeMatcher(pat string, opt options) (matcher, error) {
	ignoreCase := opt.ignoreCase || (opt.smartCase && !opt.caseSensitive && !hasUpper(pat))
	m := matcher{literal: opt.literal, word: opt.word, invert: opt.invert, lower: ignoreCase}
	if opt.literal {
		if ignoreCase { m.lit = strings.ToLower(pat) } else { m.lit = pat }
		return m, nil
	}
	exp := pat
	if opt.word {
		exp = `\b(?:` + exp + `)\b`
	}
	if ignoreCase {
		exp = "(?i)" + exp
	}
	re, err := regexp.Compile(exp)
	m.re = re
	return m, err
}

func hasUpper(s string) bool {
	for _, r := range s {
		if unicode.IsUpper(r) { return true }
	}
	return false
}

func (m matcher) findAll(line string) [][2]int {
	var out [][2]int
	if m.literal {
		hay := line
		needle := m.lit
		if m.lower { hay = strings.ToLower(line) }
		start := 0
		for {
			idx := strings.Index(hay[start:], needle)
			if idx < 0 { break }
			a := start + idx; b := a + len(needle)
			if !m.word || (wordBoundary(line, a) && wordBoundary(line, b)) {
				out = append(out, [2]int{a, b})
			}
			if b <= start { start++ } else { start = b }
		}
	} else {
		locs := m.re.FindAllStringIndex(line, -1)
		for _, l := range locs {
			out = append(out, [2]int{l[0], l[1]})
		}
	}
	if m.invert {
		if len(out) == 0 {
			return [][2]int{{0, 0}}
		}
		return nil
	}
	return out
}

func wordBoundary(s string, idx int) bool {
	if idx <= 0 || idx >= len(s) { return true }
	return !isWord(rune(s[idx-1])) || !isWord(rune(s[idx]))
}

func isWord(r rune) bool { return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' }

func collectFiles(paths []string, opt options) []string {
	var files []string
	for _, root := range paths {
		info, err := os.Lstat(root)
		if err != nil {
			if !opt.silent { fmt.Fprintf(os.Stderr, "ERR: %s: %v\n", root, err) }
			continue
		}
		if !info.IsDir() {
			if shouldUseFile(root, opt) { files = append(files, root) }
			continue
		}
		baseDepth := strings.Count(filepath.Clean(root), string(os.PathSeparator))
		filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				if !opt.silent { fmt.Fprintf(os.Stderr, "ERR: %s: %v\n", path, err) }
				return nil
			}
			if path == root { return nil }
			name := d.Name()
			depth := strings.Count(filepath.Clean(path), string(os.PathSeparator)) - baseDepth
			if d.IsDir() {
				if opt.norecurse || (opt.depth >= 0 && depth > opt.depth) || shouldSkipName(name, true, opt) {
					return filepath.SkipDir
				}
				return nil
			}
			if shouldUseFile(path, opt) {
				files = append(files, path)
			}
			return nil
		})
	}
	sort.Strings(files)
	return files
}

func loadIgnorePatterns(opt options, paths []string) []string {
	if opt.unrestricted || opt.allTypes {
		return nil
	}
	var pats []string
	addFile := func(path string) {
		b, err := os.ReadFile(path)
		if err != nil {
			return
		}
		for _, line := range strings.Split(string(b), "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			line = strings.TrimPrefix(line, "/")
			pats = append(pats, line)
		}
	}
	if opt.pathIgnore != "" {
		addFile(opt.pathIgnore)
	}
	if home, err := os.UserHomeDir(); err == nil {
		addFile(filepath.Join(home, ".agignore"))
	}
	if len(paths) == 0 {
		paths = []string{"."}
	}
	seen := map[string]bool{}
	for _, p := range paths {
		root := p
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			root = filepath.Dir(p)
		}
		filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if d.IsDir() {
				name := d.Name()
				if name == ".git" || name == ".hg" || name == ".svn" || (!opt.hidden && strings.HasPrefix(name, ".") && path != root) {
					return filepath.SkipDir
				}
				return nil
			}
			name := d.Name()
			if name == ".ignore" || name == ".gitignore" || name == ".hgignore" {
				if !seen[path] {
					seen[path] = true
					addFile(path)
				}
			}
			return nil
		})
	}
	return pats
}

func shouldSkipName(name string, dir bool, opt options) bool {
	if name == "." || name == ".." { return false }
	if !opt.hidden && strings.HasPrefix(name, ".") { return true }
	if !opt.unrestricted {
		switch name {
		case ".git", ".hg", ".svn", "CVS", "node_modules", "vendor", "bower_components":
			return true
		}
	}
	for _, p := range opt.ignorePats {
		if ignoreMatch(name, p) { return true }
	}
	return false
}

func shouldUseFile(path string, opt options) bool {
	name := filepath.Base(path)
	if shouldSkipName(name, false, opt) { return false }
	if opt.fileRegex != "" {
		re, err := regexp.Compile(opt.fileRegex)
		if err == nil && !re.MatchString(path) { return false }
	}
	if len(opt.typeFilters) > 0 {
		ok := false
		for _, t := range opt.typeFilters {
			for _, ext := range typeMap[t] {
				if strings.HasSuffix(name, ext) || strings.EqualFold(filepath.Ext(name), ext) {
					ok = true; break
				}
			}
			if ok { break }
		}
		if !ok { return false }
	}
	if !opt.unrestricted {
		for _, p := range opt.ignorePats {
			if ignoreMatch(name, p) || ignoreMatch(path, p) { return false }
		}
	}
	return true
}

func ignoreMatch(name, pat string) bool {
	if pat == "" { return false }
	if ok, _ := filepath.Match(pat, name); ok { return true }
	return name == pat || strings.Contains(name, pat)
}

func searchFile(path string, m matcher, opt options) fileResult {
	f, err := os.Open(path)
	if err != nil { return fileResult{path: path, err: err} }
	defer f.Close()
	var r io.Reader = f
	if opt.searchZip && strings.HasSuffix(path, ".gz") {
		gz, err := gzip.NewReader(f)
		if err == nil { defer gz.Close(); r = gz }
	}
	res := searchReader(path, r, m, opt)
	if res.binary && !opt.searchBinary && !opt.unrestricted {
		res.matches = nil
	}
	return res
}

func searchReader(path string, r io.Reader, m matcher, opt options) fileResult {
	data, err := io.ReadAll(r)
	if err != nil { return fileResult{path: path, err: err} }
	binary := bytes.IndexByte(data, 0) >= 0
	text := strings.ReplaceAll(string(data), "\r\n", "\n")
	parts := strings.Split(text, "\n")
	if len(parts) > 0 && parts[len(parts)-1] == "" {
		parts = parts[:len(parts)-1]
	}
	res := fileResult{path: path, lines: parts, binary: binary}
	count := 0
	for i, line := range parts {
		ranges := m.findAll(line)
		if len(ranges) > 0 {
			res.matches = append(res.matches, lineMatch{lineNo: i + 1, text: line, ranges: ranges})
			count += len(ranges)
			if opt.maxCount > 0 && count >= opt.maxCount { break }
		}
	}
	return res
}

func printResults(results []fileResult, opt options, multiple bool) {
	if opt.statsOnly { return }
	for ri, res := range results {
		matchCount := 0
		for _, lm := range res.matches { matchCount += len(lm.ranges) }
		has := matchCount > 0
		if opt.filesWithout {
			if !has { printName(res.path, opt) }
			continue
		}
		if opt.filesWith {
			if has { printName(res.path, opt) }
			continue
		}
		if opt.count {
			if has || opt.printAllFiles {
				if showFilename(opt, multiple) && res.path != "" { fmt.Printf("%s:%d\n", res.path, matchCount) } else { fmt.Printf("%d\n", matchCount) }
			}
			continue
		}
		if opt.printAllFiles && opt.heading && res.path != "" && !has {
			fmt.Println(res.path)
			continue
		}
		if !has && !opt.passthrough { continue }
		heading := opt.heading && !opt.noHeading && res.path != ""
		if heading {
			if ri > 0 && opt.breaks && !opt.noBreaks { fmt.Println() }
			fmt.Println(res.path)
		}
		printFileMatches(res, opt, multiple, heading)
	}
}

func printFileMatches(res fileResult, opt options, multiple, heading bool) {
	if opt.passthrough && res.path == "" {
		for idx, line := range res.lines {
			prefix := ""
			if opt.numbers != nil && *opt.numbers { prefix = fmt.Sprintf("%d:", idx+1) }
			fmt.Println(prefix + limitWidth(line, opt.width))
		}
		return
	}
	printed := map[int]bool{}
	matchByLine := map[int]lineMatch{}
	for _, m := range res.matches {
		matchByLine[m.lineNo] = m
	}
	for mi, lm := range res.matches {
		if opt.before > 0 || opt.after > 0 {
			start := lm.lineNo - opt.before
			if start < 1 { start = 1 }
			end := lm.lineNo + opt.after
			if end > len(res.lines) { end = len(res.lines) }
			for n := start; n <= end; n++ {
				if printed[n] { continue }
				printed[n] = true
				matchedLine, isMatch := matchByLine[n]
				sep := ":"
				if !isMatch { sep = "-" }
				ranges := [][2]int(nil)
				if isMatch { ranges = matchedLine.ranges }
				printLine(res.path, n, res.lines[n-1], ranges, opt, multiple, heading, sep)
			}
			continue
		}
		if opt.vimgrep {
			for _, rg := range lm.ranges {
				printLine(res.path, lm.lineNo, lm.text, [][2]int{rg}, opt, multiple, heading, ":")
			}
		} else if opt.onlyMatching {
			_ = mi
			for _, rg := range lm.ranges {
				part := lm.text[rg[0]:rg[1]]
				printLine(res.path, lm.lineNo, part, [][2]int{{0, len(part)}}, opt, multiple, heading, ":")
			}
		} else {
			printLine(res.path, lm.lineNo, lm.text, lm.ranges, opt, multiple, heading, ":")
		}
	}
}

func printLine(path string, lineNo int, text string, ranges [][2]int, opt options, multiple, heading bool, sep string) {
	text = limitWidth(text, opt.width)
	prefix := ""
	showFile := showFilename(opt, multiple) && !heading && path != ""
	showNums := showNumbers(opt, path)
	if opt.ackmate {
		fmt.Printf(":%d;%d %s\n", lineNo, firstColumn(ranges), text)
		return
	}
	if showFile { prefix += path + ":" }
	if showNums { prefix += fmt.Sprintf("%d%s", lineNo, sep) }
	if opt.column || opt.vimgrep {
		prefix += fmt.Sprintf("%d:", firstColumn(ranges))
	}
	fmt.Println(prefix + text)
}

func showFilename(opt options, multiple bool) bool {
	if opt.filename != nil && !*opt.filename { return false }
	return multiple
}

func showNumbers(opt options, path string) bool {
	if opt.numbers != nil { return *opt.numbers }
	if opt.filename != nil && !*opt.filename { return false }
	return path != ""
}

func firstColumn(ranges [][2]int) int {
	if len(ranges) == 0 { return 1 }
	return ranges[0][0] + 1
}

func limitWidth(s string, w int) string {
	if w > 0 && len(s) > w { return s[:w] }
	return s
}

func printName(path string, opt options) {
	if opt.nullSep { fmt.Print(path + "\x00") } else { fmt.Println(path) }
}

func successful(results []fileResult, opt options) bool {
	if opt.filesWithout {
		for _, r := range results {
			if len(r.matches) == 0 {
				return true
			}
		}
		return false
	}
	for _, r := range results {
		if len(r.matches) > 0 { return true }
	}
	return false
}

func isDir(path string) bool {
	st, err := os.Stat(path)
	return err == nil && st.IsDir()
}

func runFilenameSearch(opt options, args []string) {
	paths := args
	if len(paths) == 0 { paths = []string{"."} }
	opt.ignorePats = append(opt.ignorePats, loadIgnorePatterns(opt, paths)...)
	re, err := regexp.Compile(opt.filenamePat)
	if err != nil {
		fmt.Fprintf(os.Stderr, "ERR: %s\n", err)
		os.Exit(2)
	}
	files := collectFiles(paths, opt)
	found := false
	for _, f := range files {
		if re.MatchString(f) || re.MatchString(filepath.Base(f)) {
			printName(f, opt); found = true
		}
	}
	if found { os.Exit(0) }
	os.Exit(1)
}

func printHelp() {
	fmt.Print(`Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
  -c --count              Only print the number of matches in each file.
     --[no]color          Print color codes in results
     --column             Print column numbers in results
     --[no]filename       Print file names
  -H --[no]heading        Print file names before each file's matches
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
  -l --files-with-matches Only print filenames that contain matches
  -L --files-without-matches
  -o --only-matching      Prints only the matching part of the lines
     --stats              Print stats
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
  -0 --null --print0      Separate filenames with null

Search Options:
  -a --all-types          Search all files
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
  -m --max-count NUM      Skip the rest of a file after NUM matches
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Enabled by default
  -t --all-text           Search all text files
  -u --unrestricted       Search all files
  -v --invert-match
  -w --word-regexp        Only match whole words
  -z --search-zip         Search compressed files

For a list of supported file types run:
  ag --list-file-types
`)
}

func printVersion() {
	fmt.Print("ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib\n")
}

func printFileTypes() {
	fmt.Println("The following file types are supported:")
	keys := make([]string, 0, len(typeMap))
	for k := range typeMap { keys = append(keys, k) }
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Printf("  --%s\n      %s\n\n", k, strings.Join(typeMap[k], "  "))
	}
}

func init() {
	// Load simple ignore patterns from the current tree when possible.
	if len(os.Args) == 0 {
		bufio.NewReader(os.Stdin)
	}
}
