module svd2rust-replacement

go 1.21
