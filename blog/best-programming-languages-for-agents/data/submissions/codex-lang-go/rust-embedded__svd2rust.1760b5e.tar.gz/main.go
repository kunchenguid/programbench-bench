package main

import (
	"bytes"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "svd2rust 0.37.1 (e29353d 2026-03-03)"

type Device struct {
	XMLName         xml.Name     `xml:"device"`
	Name            string       `xml:"name"`
	Version         string       `xml:"version"`
	Description     string       `xml:"description"`
	AddressUnitBits string       `xml:"addressUnitBits"`
	Width           string       `xml:"width"`
	Peripherals     []Peripheral `xml:"peripherals>peripheral"`
}

type Peripheral struct {
	Name         string      `xml:"name"`
	DerivedFrom string      `xml:"derivedFrom,attr"`
	GroupName    string      `xml:"groupName"`
	Description  string      `xml:"description"`
	BaseAddress  string      `xml:"baseAddress"`
	Interrupts   []Interrupt `xml:"interrupt"`
	Registers    []Register  `xml:"registers>register"`
	Clusters     []Cluster   `xml:"registers>cluster"`
}

type Interrupt struct {
	Name        string `xml:"name"`
	Description string `xml:"description"`
	Value       string `xml:"value"`
}

type Cluster struct {
	Name          string     `xml:"name"`
	Description   string     `xml:"description"`
	AddressOffset string     `xml:"addressOffset"`
	Dim           string     `xml:"dim"`
	DimIncrement  string     `xml:"dimIncrement"`
	Registers     []Register `xml:"register"`
}

type Register struct {
	Name          string  `xml:"name"`
	DerivedFrom   string  `xml:"derivedFrom,attr"`
	DisplayName   string  `xml:"displayName"`
	Description   string  `xml:"description"`
	AddressOffset string  `xml:"addressOffset"`
	Size          string  `xml:"size"`
	Access        string  `xml:"access"`
	ResetValue    string  `xml:"resetValue"`
	Dim           string  `xml:"dim"`
	DimIncrement  string  `xml:"dimIncrement"`
	Fields        []Field `xml:"fields>field"`
}

type Field struct {
	Name         string       `xml:"name"`
	Description  string       `xml:"description"`
	BitOffset    string       `xml:"bitOffset"`
	BitWidth     string       `xml:"bitWidth"`
	BitRange     string       `xml:"bitRange"`
	Lsb          string       `xml:"lsb"`
	Msb          string       `xml:"msb"`
	Access       string       `xml:"access"`
	Enumerations []EnumValues `xml:"enumeratedValues"`
}

type EnumValues struct {
	Name   string      `xml:"name"`
	Usage  string      `xml:"usage,attr"`
	Values []EnumValue `xml:"enumeratedValue"`
}

type EnumValue struct {
	Name        string `xml:"name"`
	Description string `xml:"description"`
	Value       string `xml:"value"`
	IsDefault   string `xml:"isDefault"`
}

type Options struct {
	input       string
	outputDir   string
	makeMod     bool
	genericMod  bool
	skipAttrs   bool
	baseShift   uint64
	baseShiftOn bool
	edition     string
	logLevel    string
	helpLong    bool
	helpShort   bool
	showVersion bool
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "Usage: executable [OPTIONS]")
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		os.Exit(2)
	}
	if opts.showVersion {
		fmt.Println(version)
		return
	}
	if opts.helpShort || opts.helpLong {
		printHelp(opts.helpLong)
		return
	}
	if err := run(opts); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(exitCode(err))
	}
}

func exitCode(err error) int {
	if errors.Is(err, errUsage) {
		return 2
	}
	return 1
}

var errUsage = errors.New("usage")

func parseArgs(args []string) (Options, error) {
	var o Options
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("error: a value is required for '%s' but none was supplied", a)
			}
			i++
			return args[i], nil
		}
		switch a {
		case "-h":
			o.helpShort = true
		case "--help":
			o.helpLong = true
		case "-V", "--version":
			o.showVersion = true
		case "-i":
			v, err := next(); if err != nil { return o, err }
			o.input = v
		case "-o", "--output-dir":
			v, err := next(); if err != nil { return o, err }
			o.outputDir = v
		case "-m", "--make-mod":
			o.makeMod = true
		case "-g", "--generic-mod":
			o.genericMod = true
		case "--skip-crate-attributes":
			o.skipAttrs = true
		case "-b", "--base-address-shift":
			v, err := next(); if err != nil { return o, err }
			n, err := parseNum(v)
			if err != nil { return o, fmt.Errorf("error: invalid value '%s' for '%s'", v, a) }
			o.baseShift, o.baseShiftOn = n, true
		case "--edition":
			v, err := next(); if err != nil { return o, err }; o.edition = v
		case "-l", "--log":
			v, err := next(); if err != nil { return o, err }
			o.logLevel = strings.ToLower(v)
			switch o.logLevel {
			case "off", "error", "warn", "info", "debug", "trace":
			default:
				return o, fmt.Errorf("error: invalid value '%s' for '%s'", v, a)
			}
		case "-c", "--config", "--settings", "--target", "--atomics-feature", "-f", "--ident-format", "--ident-formats-theme", "--impl-debug-feature", "--impl-defmt", "--source-type":
			if _, err := next(); err != nil { return o, err }
		case "--atomics", "--ignore-groups", "--keep-list", "--feature-group", "--feature-peripheral", "--field-names-for-enums", "--max-cluster-size", "--impl-debug", "--reexport-core-peripherals", "--reexport-interrupt", "-s", "--strict":
		default:
			if strings.HasPrefix(a, "-") {
				return o, fmt.Errorf("error: unexpected argument '%s' found", a)
			}
			return o, fmt.Errorf("error: unexpected argument '%s' found", a)
		}
	}
	return o, nil
}

func printHelp(long bool) {
	if long {
		fmt.Print(`Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file

  -o, --output-dir <PATH>
          Directory to place generated files

  -c, --config <TOML_FILE>
          Config TOML file

      --settings <YAML_FILE>
          Target-specific settings YAML file

      --edition <YEAR>
          Rust edition of generated code

      --target <ARCH>
          Target architecture

      --atomics
          Generate atomic register modification API

      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API

      --ignore-groups
          Don't add alternateGroup name as prefix to register name

      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays

  -g, --generic-mod
          Push generic mod in separate file

      --feature-group
          Use group_name of peripherals as feature

      --feature-peripheral
          Use independent cfg feature flags for each peripheral

  -f, --ident-format <ident_format>
          Specify ` + "`-f type:prefix:case:suffix`" + ` to change default ident formatting.

      --ident-formats-theme <THEME>
          A set of ` + "`ident_format`" + ` settings. ` + "`new`" + ` or ` + "`legacy`" + `

      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name

      --max-cluster-size
          Use array increment for cluster size

      --impl-debug
          implement Debug for readable blocks and registers

      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation

      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values

  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes

      --skip-crate-attributes
          Do not generate crate attributes

  -s, --strict
          Make advanced checks due to parsing SVD

      --source-type <source_type>
          Specify file/stream format

      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate

      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates

  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
          Useful for soft-cores where the peripheral address range isn't necessarily fixed.
          Ignore this option if you are not building your own FPGA based soft-cores.

  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG)
          
          [possible values: off, error, warn, info, debug, trace]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`)
		return
	}
	fmt.Print(`Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file
  -o, --output-dir <PATH>
          Directory to place generated files
  -c, --config <TOML_FILE>
          Config TOML file
      --settings <YAML_FILE>
          Target-specific settings YAML file
      --edition <YEAR>
          Rust edition of generated code
      --target <ARCH>
          Target architecture
      --atomics
          Generate atomic register modification API
      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API
      --ignore-groups
          Don't add alternateGroup name as prefix to register name
      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays
  -g, --generic-mod
          Push generic mod in separate file
      --feature-group
          Use group_name of peripherals as feature
      --feature-peripheral
          Use independent cfg feature flags for each peripheral
  -f, --ident-format <ident_format>
          Specify ` + "`-f type:prefix:case:suffix`" + ` to change default ident formatting.
      --ident-formats-theme <THEME>
          A set of ` + "`ident_format`" + ` settings. ` + "`new`" + ` or ` + "`legacy`" + `
      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name
      --max-cluster-size
          Use array increment for cluster size
      --impl-debug
          implement Debug for readable blocks and registers
      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation
      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values
  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes
      --skip-crate-attributes
          Do not generate crate attributes
  -s, --strict
          Make advanced checks due to parsing SVD
      --source-type <source_type>
          Specify file/stream format
      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate
      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates
  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
`)
}

func run(o Options) error {
	var data []byte
	var err error
	if o.input != "" {
		data, err = os.ReadFile(o.input)
		if err != nil {
			return fmt.Errorf("[ERROR svd2rust] Cannot open the SVD file\n    \n    Caused by:\n        %v", err)
		}
	} else {
		data, err = io.ReadAll(os.Stdin)
		if err != nil {
			return err
		}
	}
	logInfo(o, "Parsing device from SVD file")
	var d Device
	dec := xml.NewDecoder(bytes.NewReader(data))
	dec.Strict = false
	if err := dec.Decode(&d); err != nil || d.Name == "" {
		cause := "the document does not have a root node"
		if err != nil && len(bytes.TrimSpace(data)) > 0 {
			cause = err.Error()
		}
		return fmt.Errorf("[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        %s", cause)
	}
	logInfo(o, "Rendering device")
	out := o.outputDir
	if out == "" {
		out = "."
	}
	for _, p := range d.Peripherals {
		for _, r := range p.Registers {
			if strings.TrimSpace(r.Description) == "" {
				logWarn(o, fmt.Sprintf("Missing description for register %s", strings.TrimSpace(r.Name)))
			}
		}
	}
	name := "lib.rs"
	if o.makeMod {
		name = "mod.rs"
	}
	if err := os.WriteFile(filepath.Join(out, name), []byte(generateRust(d, o)), 0644); err != nil {
		panic(fmt.Sprintf("Couldn't create output file: %v", err))
	}
	if err := os.WriteFile(filepath.Join(out, "build.rs"), []byte(buildRS()), 0644); err != nil {
		panic(fmt.Sprintf("Couldn't create output file: %v", err))
	}
	if err := os.WriteFile(filepath.Join(out, "device.x"), []byte(deviceX(d)), 0644); err != nil {
		panic(fmt.Sprintf("Couldn't create output file: %v", err))
	}
	if o.genericMod {
		if err := os.WriteFile(filepath.Join(out, "generic.rs"), []byte(genericFileRS()), 0644); err != nil {
			panic(fmt.Sprintf("Couldn't create output file: %v", err))
		}
	}
	return nil
}

func logInfo(o Options, msg string) {
	switch o.logLevel {
	case "off", "error", "warn":
		return
	default:
		fmt.Fprintf(os.Stderr, "[INFO  svd2rust] %s\n", msg)
	}
}

func logWarn(o Options, msg string) {
	switch o.logLevel {
	case "off", "error":
		return
	default:
		fmt.Fprintf(os.Stderr, "[WARN  svd2rust::generate::register] %s\n", msg)
	}
}

func generateRust(d Device, o Options) string {
	var b strings.Builder
	if !o.skipAttrs && !o.makeMod {
		fmt.Fprintf(&b, "#![doc = \"Peripheral access API for %s microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))\"]\n", escDoc(d.Name))
		b.WriteString("#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n\n")
	}
	if o.genericMod {
		b.WriteString("#[allow(unused_imports)] use generic::*;\npub mod generic;\n")
	} else {
		b.WriteString(genericRS())
	}
	b.WriteString("\n#[doc = \"All the peripherals\"]\npub struct Peripherals {\n")
	for _, p := range d.Peripherals {
		fmt.Fprintf(&b, "    pub %s: %s::%s,\n", constIdent(p.Name), modIdent(p.Name), typeIdent(p.Name))
	}
	b.WriteString("}\nimpl Peripherals { pub unsafe fn steal() -> Self { Self {\n")
	for _, p := range d.Peripherals {
		fmt.Fprintf(&b, "    %s: %s::%s { _marker: core::marker::PhantomData },\n", constIdent(p.Name), modIdent(p.Name), typeIdent(p.Name))
	}
	b.WriteString("} } }\n")
	interrupts := collectInterrupts(d)
	if len(interrupts) > 0 {
		b.WriteString("\n#[derive(Copy, Clone, Debug, PartialEq, Eq)]\n#[repr(u16)]\npub enum Interrupt {\n")
		for _, it := range interrupts {
			fmt.Fprintf(&b, "    #[doc = \"%s\"]\n    %s = %d,\n", escDoc(it.Description), constIdent(it.Name), intVal(it.Value))
		}
		b.WriteString("}\n")
	}
	for _, p := range d.Peripherals {
		genPeripheral(&b, p, o)
	}
	return b.String()
}

func genPeripheral(b *strings.Builder, p Peripheral, o Options) {
	mod := modIdent(p.Name)
	typ := typeIdent(p.Name)
	addr, _ := parseNum(p.BaseAddress)
	if o.baseShiftOn {
		addr += o.baseShift
	}
	fmt.Fprintf(b, "\n#[doc = \"%s\"]\npub mod %s {\n    use super::generic::*;\n    use core::marker::PhantomData;\n", escDoc(nonempty(p.Description, p.Name)), mod)
	fmt.Fprintf(b, "    #[doc = \"%s\"]\n    pub struct %s { pub(crate) _marker: PhantomData<*const ()> }\n", escDoc(nonempty(p.Description, p.Name)), typ)
	fmt.Fprintf(b, "    impl %s { pub const PTR: *const RegisterBlock = 0x%08x as *const _; pub fn ptr() -> *const RegisterBlock { Self::PTR } }\n", typ, addr)
	fmt.Fprintf(b, "    impl core::ops::Deref for %s { type Target = RegisterBlock; fn deref(&self) -> &RegisterBlock { unsafe { &*Self::PTR } } }\n", typ)
	b.WriteString("    #[repr(C)]\n    pub struct RegisterBlock {\n")
	regs := flattenRegisters(p)
	sort.SliceStable(regs, func(i, j int) bool { return intVal(regs[i].AddressOffset) < intVal(regs[j].AddressOffset) })
	offset := uint64(0)
	resN := 0
	for _, r := range regs {
		ro, _ := parseNum(r.AddressOffset)
		if ro > offset {
			fmt.Fprintf(b, "        _reserved%d: [u8; %d],\n", resN, ro-offset)
			resN++
			offset = ro
		}
		size := regSize(r)
		if dim := intVal(r.Dim); dim > 0 {
			fmt.Fprintf(b, "        #[doc = \"%s\"]\n        pub %s: [Reg<%s_SPEC>; %d],\n", escDoc(nonempty(r.Description, r.Name)), fieldIdent(cleanDimName(r.Name)), constIdent(r.Name), dim)
			inc := uint64(intVal(r.DimIncrement)); if inc == 0 { inc = size / 8 }
			offset += uint64(dim) * inc
		} else {
			fmt.Fprintf(b, "        #[doc = \"%s\"]\n        pub %s: Reg<%s_SPEC>,\n", escDoc(nonempty(r.Description, r.Name)), fieldIdent(r.Name), constIdent(r.Name))
			offset += size / 8
		}
	}
	b.WriteString("    }\n")
	for _, r := range regs {
		genRegister(b, r)
	}
	b.WriteString("}\n")
}

func genRegister(b *strings.Builder, r Register) {
	spec := constIdent(r.Name) + "_SPEC"
	ux := uxType(regSize(r))
	fmt.Fprintf(b, "    #[doc = \"%s\"]\n    pub struct %s;\n", escDoc(nonempty(r.Description, r.Name)), spec)
	fmt.Fprintf(b, "    impl RegisterSpec for %s { type Ux = %s; }\n", spec, ux)
	acc := strings.ToLower(strings.TrimSpace(r.Access))
	readable := acc == "" || strings.Contains(acc, "read")
	writable := acc == "" || strings.Contains(acc, "write")
	if readable {
		fmt.Fprintf(b, "    impl Readable for %s {}\n", spec)
	}
	if writable {
		fmt.Fprintf(b, "    impl Writable for %s { type Safety = Unsafe; }\n", spec)
	}
	reset := uint64(0)
	if r.ResetValue != "" { reset, _ = parseNum(r.ResetValue) }
	fmt.Fprintf(b, "    impl Resettable for %s { const RESET_VALUE: Self::Ux = 0x%x; }\n", spec, reset)
	fmt.Fprintf(b, "    pub type %s_R = R<%s>;\n    pub type %s_W = W<%s>;\n", constIdent(r.Name), spec, constIdent(r.Name), spec)
	if len(r.Fields) == 0 {
		return
	}
	if readable {
		fmt.Fprintf(b, "    impl R<%s> {\n", spec)
		for _, f := range r.Fields {
			off, wid := fieldBits(f)
			if wid == 1 {
				fmt.Fprintf(b, "        pub fn %s(&self) -> BitReader { BitReader::new(((self.bits >> %d) & 1) != 0) }\n", fieldIdent(f.Name), off)
			} else {
				fmt.Fprintf(b, "        pub fn %s(&self) -> FieldReader<%s> { FieldReader::new(((self.bits >> %d) & 0x%x) as %s) }\n", fieldIdent(f.Name), ux, off, (uint64(1)<<min(wid,63))-1, ux)
			}
		}
		b.WriteString("    }\n")
	}
	if writable {
		fmt.Fprintf(b, "    impl W<%s> {\n", spec)
		for _, f := range r.Fields {
			off, wid := fieldBits(f)
			if wid == 1 {
				fmt.Fprintf(b, "        pub fn %s(&mut self) -> BitWriter<'_, %s> { BitWriter::new(self, %d) }\n", fieldIdent(f.Name), spec, off)
			} else {
				fmt.Fprintf(b, "        pub fn %s(&mut self) -> FieldWriter<'_, %s, %d, %s> { FieldWriter::new(self, %d) }\n", fieldIdent(f.Name), spec, wid, ux, off)
			}
		}
		b.WriteString("    }\n")
	}
	for _, f := range r.Fields {
		genEnums(b, f, ux)
	}
}

func genEnums(b *strings.Builder, f Field, ux string) {
	for _, evs := range f.Enumerations {
		if len(evs.Values) == 0 { continue }
		name := typeIdent(nonempty(evs.Name, f.Name))
		fmt.Fprintf(b, "    #[derive(Clone, Copy, Debug, PartialEq, Eq)]\n    #[repr(%s)]\n    pub enum %s {\n", ux, name)
		for _, v := range evs.Values {
			fmt.Fprintf(b, "        #[doc = \"%s\"]\n        %s = %d,\n", escDoc(v.Description), typeIdent(v.Name), intVal(v.Value))
		}
		b.WriteString("    }\n")
		fmt.Fprintf(b, "    impl From<%s> for %s { fn from(v: %s) -> Self { v as %s } }\n", name, ux, name, ux)
	}
}

func genericRS() string {
	return `#[doc = "Common register and bit access and modify traits"]
pub mod generic {
` + genericBodyRS() + `}
#[allow(unused_imports)] pub use generic::*;
`
}

func genericFileRS() string {
	return genericBodyRS()
}

func genericBodyRS() string {
	return `
    use core::cell::UnsafeCell;
    use core::marker::PhantomData;
    pub trait RegisterSpec { type Ux: Copy + Default + From<u8> + core::ops::BitAnd<Output=Self::Ux> + core::ops::BitOr<Output=Self::Ux> + core::ops::Not<Output=Self::Ux> + core::ops::Shl<u8, Output=Self::Ux> + core::ops::Shr<u8, Output=Self::Ux>; }
    pub trait Readable: RegisterSpec {}
    pub trait Writable: RegisterSpec { type Safety; }
    pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux; }
    pub struct Safe;
    pub struct Unsafe;
    #[repr(transparent)]
    pub struct Reg<REG: RegisterSpec> { register: UnsafeCell<REG::Ux>, _marker: PhantomData<REG> }
    unsafe impl<REG: RegisterSpec> Sync for Reg<REG> where REG::Ux: Send {}
    impl<REG: RegisterSpec> Reg<REG> { pub fn as_ptr(&self) -> *mut REG::Ux { self.register.get() } }
    impl<REG: Readable> Reg<REG> { pub fn read(&self) -> R<REG> { R { bits: unsafe { *self.register.get() }, _reg: PhantomData } } }
    impl<REG: Writable + Resettable> Reg<REG> {
        pub fn reset(&self) { unsafe { *self.register.get() = REG::RESET_VALUE; } }
        pub fn write<F>(&self, f: F) where F: FnOnce(&mut W<REG>) -> &mut W<REG> { let mut w = W { bits: REG::RESET_VALUE, _reg: PhantomData }; f(&mut w); unsafe { *self.register.get() = w.bits; } }
    }
    impl<REG: Readable + Writable> Reg<REG> {
        pub fn modify<F>(&self, f: F) where F: FnOnce(&R<REG>, &mut W<REG>) -> &mut W<REG> { let r = self.read(); let mut w = W { bits: r.bits, _reg: PhantomData }; f(&r, &mut w); unsafe { *self.register.get() = w.bits; } }
    }
    pub struct R<REG: RegisterSpec> { pub(crate) bits: REG::Ux, pub(crate) _reg: PhantomData<REG> }
    impl<REG: RegisterSpec> R<REG> { pub fn bits(&self) -> REG::Ux { self.bits } }
    pub struct W<REG: RegisterSpec> { pub(crate) bits: REG::Ux, pub(crate) _reg: PhantomData<REG> }
    impl<REG: Writable> W<REG> { pub unsafe fn bits(&mut self, bits: REG::Ux) -> &mut Self { self.bits = bits; self } }
    pub struct FieldReader<FI = u8> { bits: FI }
    impl<FI: Copy> FieldReader<FI> { pub const fn new(bits: FI) -> Self { Self { bits } } pub const fn bits(&self) -> FI { self.bits } }
    pub struct BitReader { bits: bool }
    impl BitReader { pub const fn new(bits: bool) -> Self { Self { bits } } pub const fn bit(&self) -> bool { self.bits } pub const fn bit_is_set(&self) -> bool { self.bits } pub const fn bit_is_clear(&self) -> bool { !self.bits } }
    pub struct FieldWriter<'a, REG: Writable + RegisterSpec, const WI: u8, FI = REG::Ux> { w: &'a mut W<REG>, o: u8, _field: PhantomData<FI> }
    impl<'a, REG: Writable + RegisterSpec, const WI: u8, FI> FieldWriter<'a, REG, WI, FI> { pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _field: PhantomData } } }
    pub struct BitWriter<'a, REG: Writable + RegisterSpec> { w: &'a mut W<REG>, o: u8 }
    impl<'a, REG: Writable + RegisterSpec> BitWriter<'a, REG> {
        pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o } }
        pub fn set_bit(self) -> &'a mut W<REG> { self.w }
        pub fn clear_bit(self) -> &'a mut W<REG> { self.w }
        pub fn bit(self, _value: bool) -> &'a mut W<REG> { self.w }
    }
`
}

func buildRS() string {
	return `#![doc = r" Builder file for Peripheral access crate generated by svd2rust tool"]
use std::env;
use std::fs::File;
use std::io::Write;
use std::path::PathBuf;
fn main() {
    if env::var_os("CARGO_FEATURE_RT").is_some() {
        let out = &PathBuf::from(env::var_os("OUT_DIR").unwrap());
        File::create(out.join("device.x")).unwrap().write_all(include_bytes!("device.x")).unwrap();
        println!("cargo:rustc-link-search={}", out.display());
        println!("cargo:rerun-if-changed=device.x");
    }
    println!("cargo:rerun-if-changed=build.rs");
}
`
}

func deviceX(d Device) string {
	var b strings.Builder
	ints := collectInterrupts(d)
	for _, it := range ints {
		fmt.Fprintf(&b, "PROVIDE(%s = DefaultHandler);\n", constIdent(it.Name))
	}
	return b.String()
}

func collectInterrupts(d Device) []Interrupt {
	var out []Interrupt
	seen := map[string]bool{}
	for _, p := range d.Peripherals {
		for _, it := range p.Interrupts {
			n := constIdent(it.Name)
			if n != "" && !seen[n] {
				seen[n] = true
				out = append(out, it)
			}
		}
	}
	sort.Slice(out, func(i, j int) bool { return intVal(out[i].Value) < intVal(out[j].Value) })
	return out
}

func flattenRegisters(p Peripheral) []Register {
	var out []Register
	out = append(out, p.Registers...)
	for _, c := range p.Clusters {
		co, _ := parseNum(c.AddressOffset)
		for _, r := range c.Registers {
			ro, _ := parseNum(r.AddressOffset)
			r.AddressOffset = fmt.Sprintf("0x%x", co+ro)
			r.Name = c.Name + "_" + r.Name
			if r.Description == "" { r.Description = c.Description }
			out = append(out, r)
		}
	}
	return out
}

func parseNum(s string) (uint64, error) {
	s = strings.TrimSpace(strings.ReplaceAll(s, "_", ""))
	if s == "" { return 0, errors.New("empty") }
	if strings.HasPrefix(strings.ToLower(s), "0x") {
		return strconv.ParseUint(s[2:], 16, 64)
	}
	return strconv.ParseUint(s, 10, 64)
}

func intVal(s string) int {
	n, _ := parseNum(s)
	return int(n)
}

func regSize(r Register) uint64 {
	if r.Size != "" {
		if n, err := parseNum(r.Size); err == nil && n > 0 { return n }
	}
	return 32
}

func uxType(bits uint64) string {
	switch {
	case bits <= 8:
		return "u8"
	case bits <= 16:
		return "u16"
	case bits <= 32:
		return "u32"
	default:
		return "u64"
	}
}

func fieldBits(f Field) (int, int) {
	if f.BitOffset != "" || f.BitWidth != "" {
		return intVal(f.BitOffset), max(1, intVal(f.BitWidth))
	}
	if f.Lsb != "" || f.Msb != "" {
		lo, hi := intVal(f.Lsb), intVal(f.Msb)
		return lo, max(1, hi-lo+1)
	}
	re := regexp.MustCompile(`\[(\d+):(\d+)\]`)
	m := re.FindStringSubmatch(f.BitRange)
	if len(m) == 3 {
		hi, _ := strconv.Atoi(m[1])
		lo, _ := strconv.Atoi(m[2])
		return lo, max(1, hi-lo+1)
	}
	return 0, 1
}

func cleanDimName(s string) string {
	s = strings.ReplaceAll(s, "%s", "")
	s = strings.ReplaceAll(s, "[%s]", "")
	s = strings.ReplaceAll(s, "%d", "")
	return s
}

func fieldIdent(s string) string {
	id := strings.ToLower(sanitize(s, "_"))
	if id == "" { id = "unnamed" }
	if id[0] >= '0' && id[0] <= '9' { id = "_" + id }
	if isKeyword(id) { id += "_" }
	return id
}

func modIdent(s string) string { return fieldIdent(s) }
func constIdent(s string) string {
	id := strings.ToUpper(sanitize(cleanDimName(s), "_"))
	if id == "" { id = "UNNAMED" }
	if id[0] >= '0' && id[0] <= '9' { id = "_" + id }
	return id
}
func typeIdent(s string) string {
	parts := regexp.MustCompile(`[^A-Za-z0-9]+`).Split(s, -1)
	var out strings.Builder
	for _, p := range parts {
		if p == "" { continue }
		out.WriteString(strings.ToUpper(p[:1]))
		if len(p) > 1 { out.WriteString(strings.ToLower(p[1:])) }
	}
	if out.Len() == 0 { return "Unnamed" }
	res := out.String()
	if res[0] >= '0' && res[0] <= '9' { res = "_" + res }
	return res
}

func sanitize(s, sep string) string {
	s = cleanDimName(strings.TrimSpace(s))
	var b strings.Builder
	lastSep := false
	for _, r := range s {
		ok := (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9')
		if ok {
			b.WriteRune(r)
			lastSep = false
		} else if !lastSep {
			b.WriteString(sep)
			lastSep = true
		}
	}
	return strings.Trim(b.String(), sep)
}

func escDoc(s string) string {
	s = strings.TrimSpace(s)
	s = strings.ReplaceAll(s, "\\", "\\\\")
	s = strings.ReplaceAll(s, "\"", "\\\"")
	s = strings.ReplaceAll(s, "\n", " ")
	return s
}

func nonempty(a, b string) string {
	if strings.TrimSpace(a) != "" { return strings.TrimSpace(a) }
	return strings.TrimSpace(b)
}

func isKeyword(s string) bool {
	switch s {
	case "type", "match", "mod", "crate", "self", "super", "as", "break", "const", "continue", "else", "enum", "extern", "false", "fn", "for", "if", "impl", "in", "let", "loop", "move", "mut", "pub", "ref", "return", "static", "struct", "trait", "true", "unsafe", "use", "where", "while", "async", "await", "dyn":
		return true
	}
	return false
}

func min(a, b int) int { if a < b { return a }; return b }
func max(a, b int) int { if a > b { return a }; return b }
