module tui-journal-reimpl

go 1.21
