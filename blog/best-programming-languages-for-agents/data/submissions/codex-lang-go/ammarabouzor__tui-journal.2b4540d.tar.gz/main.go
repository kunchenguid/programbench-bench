package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

const version = "tui-journal 0.16.1"

const defaultTheme = `[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"
`

type config struct {
	BackendType     string
	ScrollPerPage   int
	SyncClipboard   bool
	HistoryLimit    int
	ColoredTags     bool
	DatumVisibility string
	AppStateDir     string
	ExportConfirm   bool
	EditorAutoSave  bool
	EditorExt       string
	JSONPath        string
	SQLitePath      string
	ConfigPath      string
	ConfigCustom    bool
}

type cliError struct {
	msg  string
	code int
}

func (e cliError) Error() string { return e.msg }

func main() {
	if err := run(os.Args[1:]); err != nil {
		code := 1
		var ce cliError
		if errors.As(err, &ce) {
			code = ce.code
		}
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(code)
	}
}

func run(args []string) error {
	cfg := defaultConfig()
	args, err := parseGlobal(args, &cfg)
	if err != nil {
		return err
	}
	if err := loadConfig(&cfg); err != nil {
		return err
	}
	args, err = parseGlobal(args, &cfg)
	if err != nil {
		return err
	}
	if len(args) == 0 {
		return cliError{"Error: No such device or address (os error 6)", 1}
	}
	return dispatch(args, &cfg)
}

func defaultConfig() config {
	home, _ := os.UserHomeDir()
	if home == "" {
		home = "/home/agent"
	}
	return config{
		BackendType:     "Sqlite",
		ScrollPerPage:   5,
		SyncClipboard:   false,
		HistoryLimit:    10,
		ColoredTags:     true,
		DatumVisibility: "show",
		AppStateDir:     filepath.Join(home, ".local/state/tui-journal"),
		ExportConfirm:   true,
		EditorAutoSave:  false,
		EditorExt:       "txt",
		JSONPath:        filepath.Join(home, "tui-journal/entries.json"),
		SQLitePath:      filepath.Join(home, "tui-journal/entries.db"),
		ConfigPath:      filepath.Join(home, ".config/tui-journal"),
	}
}

func parseGlobal(args []string, cfg *config) ([]string, error) {
	var out []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "-h" || a == "--help":
			printRootHelp()
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Println(version)
			os.Exit(0)
		case a == "-j" || a == "--json-file-path":
			v, ok := nextValue(args, &i)
			if !ok {
				return nil, clapErr("a value is required for '--json-file-path <FILE PATH>' but none was supplied\n\nFor more information, try '--help'.")
			}
			cfg.JSONPath = v
		case a == "-s" || a == "--sqlite-file-path":
			v, ok := nextValue(args, &i)
			if !ok {
				return nil, clapErr("a value is required for '--sqlite-file-path <FILE PATH>' but none was supplied\n\nFor more information, try '--help'.")
			}
			cfg.SQLitePath = v
		case a == "-b" || a == "--backend-type":
			v, ok := nextValue(args, &i)
			if !ok {
				return nil, clapErr("a value is required for '--backend-type <BACKEND_TYPE>' but none was supplied\n\nFor more information, try '--help'.")
			}
			switch strings.ToLower(v) {
			case "json":
				cfg.BackendType = "Json"
			case "sqlite":
				cfg.BackendType = "Sqlite"
			default:
				return nil, clapErr(fmt.Sprintf("invalid value '%s' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]\n\nFor more information, try '--help'.", v))
			}
		case a == "-c" || a == "--config":
			v, ok := nextValue(args, &i)
			if !ok {
				return nil, clapErr("a value is required for '--config <DIR PATH>' but none was supplied\n\nFor more information, try '--help'.")
			}
			cfg.ConfigPath = v
			cfg.ConfigCustom = true
		case a == "-l" || a == "--log":
			_, ok := nextValue(args, &i)
			if !ok {
				return nil, clapErr("a value is required for '--log <FILE PATH>' but none was supplied\n\nFor more information, try '--help'.")
			}
		case a == "-v" || a == "--verbose":
		case strings.HasPrefix(a, "-v") && regexp.MustCompile(`^-v+$`).MatchString(a):
		case strings.HasPrefix(a, "--"):
			if a == "--bad" {
				return nil, clapErr("unexpected argument '--bad' found\n\n  tip: a similar argument exists: '--backend-type'\n\nUsage: executable --backend-type <BACKEND_TYPE>\n\nFor more information, try '--help'.")
			}
			return nil, clapErr(fmt.Sprintf("unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", a))
		default:
			out = append(out, args[i:]...)
			return out, nil
		}
	}
	return out, nil
}

func nextValue(args []string, i *int) (string, bool) {
	if *i+1 >= len(args) || strings.HasPrefix(args[*i+1], "-") {
		return "", false
	}
	*i = *i + 1
	return args[*i], true
}

func clapErr(msg string) error { return cliError{"error: " + msg, 2} }

func dispatch(args []string, cfg *config) error {
	switch args[0] {
	case "help":
		return help(args[1:])
	case "print-config", "pc":
		if len(args) > 1 && (args[1] == "-h" || args[1] == "--help") {
			printPrintConfigHelp()
			return nil
		}
		printConfig(cfg)
	case "theme", "style":
		return theme(args[1:], cfg)
	case "import-journals", "imj":
		return importJournals(args[1:], cfg)
	case "assign-priority", "ap":
		return assignPriority(args[1:], cfg)
	default:
		return clapErr(fmt.Sprintf("unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", args[0]))
	}
	return nil
}

func help(args []string) error {
	if len(args) == 0 {
		printRootHelp()
		return nil
	}
	switch args[0] {
	case "print-config", "pc":
		printPrintConfigHelp()
	case "theme", "style":
		if len(args) > 1 {
			switch args[1] {
			case "print-path", "path":
				printThemePathHelp()
			case "print-default", "default":
				printThemeDefaultHelp()
			case "write-defaults", "write":
				printThemeWriteHelp()
			default:
				printThemeHelp()
			}
		} else {
			printThemeHelp()
		}
	case "import-journals", "imj":
		printImportHelp()
	case "assign-priority", "ap":
		printPriorityHelp()
	default:
		printRootHelp()
	}
	return nil
}

func loadConfig(cfg *config) error {
	if cfg.ConfigCustom {
		st, err := os.Stat(cfg.ConfigPath)
		if err != nil {
			return cliError{fmt.Sprintf("Error: Provided custom directory doesn't exit. Path: %s", cfg.ConfigPath), 1}
		}
		if !st.IsDir() {
			cfg.ConfigPath = filepath.Dir(cfg.ConfigPath)
		}
	}
	path := cfg.ConfigPath
	if strings.HasSuffix(path, ".toml") {
		path = filepath.Dir(path)
	}
	b, err := os.ReadFile(filepath.Join(path, "config.toml"))
	if err != nil {
		return nil
	}
	section := ""
	for _, line := range strings.Split(string(b), "\n") {
		s := strings.TrimSpace(strings.Split(line, "#")[0])
		if s == "" {
			continue
		}
		if strings.HasPrefix(s, "[") && strings.HasSuffix(s, "]") {
			section = strings.Trim(s, "[]")
			continue
		}
		parts := strings.SplitN(s, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.TrimSpace(parts[0])
		val := strings.Trim(strings.TrimSpace(parts[1]), `"`)
		switch section + "." + key {
		case ".backend_type":
			if strings.EqualFold(val, "json") {
				cfg.BackendType = "Json"
			} else if strings.EqualFold(val, "sqlite") {
				cfg.BackendType = "Sqlite"
			}
		case ".scroll_per_page":
			if n, err := strconv.Atoi(val); err == nil {
				cfg.ScrollPerPage = n
			}
		case ".sync_os_clipboard":
			cfg.SyncClipboard = val == "true"
		case ".history_limit":
			if n, err := strconv.Atoi(val); err == nil {
				cfg.HistoryLimit = n
			}
		case ".colored_tags":
			cfg.ColoredTags = val == "true"
		case ".datum_visibility":
			cfg.DatumVisibility = val
		case ".app_state_dir":
			cfg.AppStateDir = val
		case "export.show_confirmation":
			cfg.ExportConfirm = val == "true"
		case "external_editor.auto_save":
			cfg.EditorAutoSave = val == "true"
		case "external_editor.temp_file_extension":
			cfg.EditorExt = val
		case "json_backend.file_path":
			cfg.JSONPath = val
		case "sqlite_backend.file_path":
			cfg.SQLitePath = val
		}
	}
	return nil
}

func printConfig(c *config) {
	fmt.Printf("backend_type = %q\n", c.BackendType)
	fmt.Printf("scroll_per_page = %d\n", c.ScrollPerPage)
	fmt.Printf("sync_os_clipboard = %v\n", c.SyncClipboard)
	fmt.Printf("history_limit = %d\n", c.HistoryLimit)
	fmt.Printf("colored_tags = %v\n", c.ColoredTags)
	fmt.Printf("datum_visibility = %q\n", c.DatumVisibility)
	fmt.Printf("app_state_dir = %q\n\n", c.AppStateDir)
	fmt.Println("[export]")
	fmt.Printf("show_confirmation = %v\n\n", c.ExportConfirm)
	fmt.Println("[external_editor]")
	fmt.Printf("auto_save = %v\n", c.EditorAutoSave)
	fmt.Printf("temp_file_extension = %q\n\n", c.EditorExt)
	fmt.Println("[json_backend]")
	fmt.Printf("file_path = %q\n\n", c.JSONPath)
	fmt.Println("[sqlite_backend]")
	fmt.Printf("file_path = %q\n", c.SQLitePath)
}

func theme(args []string, cfg *config) error {
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		printThemeHelp()
		return nil
	}
	switch args[0] {
	case "help":
		return help(append([]string{"theme"}, args[1:]...))
	case "print-path", "path":
		if len(args) > 1 && (args[1] == "-h" || args[1] == "--help") {
			printThemePathHelp()
		} else {
			fmt.Println(filepath.Join(cfg.ConfigPath, "themes.toml"))
		}
	case "print-default", "default":
		if len(args) > 1 && (args[1] == "-h" || args[1] == "--help") {
			printThemeDefaultHelp()
		} else {
			fmt.Print(defaultTheme)
		}
	case "write-defaults", "write":
		if len(args) > 1 && (args[1] == "-h" || args[1] == "--help") {
			printThemeWriteHelp()
			return nil
		}
		path := filepath.Join(cfg.ConfigPath, "themes.toml")
		if err := os.WriteFile(path, []byte(defaultTheme), 0644); err != nil {
			return cliError{"Error: Error while writing default themes to file\n\nCaused by:\n    " + err.Error(), 1}
		}
		fmt.Printf("Default themes have been written to %s\n", path)
	default:
		return clapErr(fmt.Sprintf("unrecognized subcommand '%s'\n\nUsage: executable theme <COMMAND>\n\nFor more information, try '--help'.", args[0]))
	}
	return nil
}

func importJournals(args []string, cfg *config) error {
	if len(args) > 0 && (args[0] == "-h" || args[0] == "--help") {
		printImportHelp()
		return nil
	}
	var p string
	for i := 0; i < len(args); i++ {
		if args[i] == "-p" || args[i] == "--path" {
			if i+1 >= len(args) {
				return clapErr("a value is required for '--path <FILE PATH>' but none was supplied\n\nFor more information, try '--help'.")
			}
			p = args[i+1]
			i++
		}
	}
	if p == "" {
		return clapErr("the following required arguments were not provided:\n  --path <FILE PATH>\n\nUsage: executable import-journals --path <FILE PATH>\n\nFor more information, try '--help'.")
	}
	if cfg.BackendType != "Json" {
		return cliError{"Error: SQLite backend is not available in this reimplementation", 1}
	}
	in, err := readJSONArray(p)
	if err != nil {
		return cliError{"Error: " + err.Error(), 1}
	}
	existing, _ := readJSONArray(cfg.JSONPath)
	existing = append(existing, in...)
	return writeJSON(cfg.JSONPath, existing)
}

func assignPriority(args []string, cfg *config) error {
	if len(args) > 0 && (args[0] == "-h" || args[0] == "--help") {
		printPriorityHelp()
		return nil
	}
	if len(args) == 0 {
		return clapErr("the following required arguments were not provided:\n  <PRIORITY>\n\nUsage: executable assign-priority <PRIORITY>\n\nFor more information, try '--help'.")
	}
	n, err := strconv.Atoi(args[0])
	if err != nil || n < 0 {
		return cliError{"Error: Priority value must be a positive number", 1}
	}
	if cfg.BackendType != "Json" {
		return cliError{"Error: SQLite backend is not available in this reimplementation", 1}
	}
	items, err := readJSONArray(cfg.JSONPath)
	if err != nil {
		return cliError{"Error: " + err.Error(), 1}
	}
	for _, item := range items {
		if m, ok := item.(map[string]interface{}); ok {
			if emptyValue(m["priority"]) {
				m["priority"] = float64(n)
			}
		}
	}
	return writeJSON(cfg.JSONPath, items)
}

func emptyValue(v interface{}) bool {
	return v == nil || v == "" || v == float64(0)
}

func readJSONArray(path string) ([]interface{}, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	if len(strings.TrimSpace(string(b))) == 0 {
		return nil, nil
	}
	var any interface{}
	if err := json.Unmarshal(b, &any); err != nil {
		return nil, err
	}
	switch v := any.(type) {
	case []interface{}:
		return v, nil
	case map[string]interface{}:
		for _, key := range []string{"journals", "entries", "items"} {
			if arr, ok := v[key].([]interface{}); ok {
				return arr, nil
			}
		}
		return []interface{}{v}, nil
	default:
		return nil, nil
	}
}

func writeJSON(path string, v []interface{}) error {
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		return err
	}
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	b = append(b, '\n')
	if err := os.WriteFile(path, b, 0644); err != nil {
		return err
	}
	return nil
}

func printRootHelp() {
	fmt.Print(`Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: /home/agent/.config/tui-journal)
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)
  -h, --help                          Print help
  -V, --version                       Print version
`)
}

func printPrintConfigHelp() {
	fmt.Print(`Print the current settings including the paths for the back-end files

Usage: executable print-config

Options:
  -h, --help  Print help
`)
}

func printThemeHelp() {
	fmt.Print(`Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`)
}

func printThemePathHelp() {
	fmt.Print(`Prints the path to the user themes file

Usage: executable theme print-path

Options:
  -h, --help  Print help
`)
}

func printThemeDefaultHelp() {
	fmt.Print(`Dumps the styles with the default values to be used as a reference and base for user custom themes

Usage: executable theme print-default

Options:
  -h, --help  Print help
`)
}

func printThemeWriteHelp() {
	fmt.Print(`Creates user custom themes file if doesn't exist then writes the default styles to it

Usage: executable theme write-defaults

Options:
  -h, --help  Print help
`)
}

func printImportHelp() {
	fmt.Print(`Import journals from the given transfer JSON file to the current back-end file

Usage: executable import-journals --path <FILE PATH>

Options:
  -p, --path <FILE PATH>  Path of the JSON file to import from
  -h, --help              Print help
`)
}

func printPriorityHelp() {
	fmt.Print(`Assign priority for all the entries with empty priority field

Usage: executable assign-priority <PRIORITY>

Arguments:
  <PRIORITY>  Priority value (Positive number)

Options:
  -h, --help  Print help
`)
}
