package main

import (
	"bytes"
	"errors"
	"flag"
	"fmt"
	stdhtml "html"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type NodeType int

const (
	DocumentNode NodeType = iota
	ElementNode
	TextNode
)

type Attr struct {
	Key string
	Val string
}

type Node struct {
	Type        NodeType
	Data        string
	Attr        []Attr
	Parent      *Node
	FirstChild  *Node
	LastChild   *Node
	NextSibling *Node
}

func (n *Node) AppendChild(c *Node) {
	c.Parent = n
	if n.LastChild != nil {
		n.LastChild.NextSibling = c
	} else {
		n.FirstChild = c
	}
	n.LastChild = c
}

func (n *Node) RemoveChild(c *Node) {
	var prev *Node
	for x := n.FirstChild; x != nil; x = x.NextSibling {
		if x == c {
			if prev == nil {
				n.FirstChild = x.NextSibling
			} else {
				prev.NextSibling = x.NextSibling
			}
			if n.LastChild == x {
				n.LastChild = prev
			}
			x.Parent = nil
			x.NextSibling = nil
			return
		}
		prev = x
	}
}

type options struct {
	input          string
	output         string
	overwrite      bool
	domain         string
	include        string
	exclude        string
	strong         string
	table          bool
	strike         bool
	tablePadding   string
	tableHeader    bool
	tableNewline   string
	tablePresent   bool
	tableSkipEmpty bool
	tableSpan      string
}

type renderer struct {
	opt       options
	base      *url.URL
	listStack []listCtx
}

type listCtx struct {
	ordered bool
	index   int
}

func main() {
	opt, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "error:", err)
		fmt.Fprintln(os.Stderr)
		if strings.Contains(err.Error(), "unknown arguments") {
			fmt.Fprintln(os.Stderr, "Here is how you can use the CLI:")
			fmt.Fprintln(os.Stderr)
			fmt.Fprintln(os.Stderr, `    echo "<strong>important</strong>" | html2markdown`)
			fmt.Fprintln(os.Stderr)
		}
		os.Exit(1)
	}
	if showHelp {
		printHelp()
		return
	}
	if showVersion {
		fmt.Println("html2markdown")
		fmt.Println()
		fmt.Println("GitVersion:  dev")
		fmt.Println("GitCommit:   none")
		fmt.Println("BuildDate:   unknown")
		return
	}
	if opt.strong == "" {
		opt.strong = "**"
	}
	if opt.tablePadding == "" {
		opt.tablePadding = "aligned"
	}
	if opt.tableNewline == "" {
		opt.tableNewline = "skip"
	}
	if opt.tableSpan == "" {
		opt.tableSpan = "empty"
	}
	if err := run(opt); err != nil {
		fmt.Fprintln(os.Stderr)
		fmt.Fprintln(os.Stderr, "error:", err)
		fmt.Fprintln(os.Stderr)
		os.Exit(1)
	}
}

var showHelp bool
var showVersion bool

func parseArgs(args []string) (options, error) {
	var opt options
	fs := flag.NewFlagSet("html2markdown", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.BoolVar(&showVersion, "v", false, "")
	fs.BoolVar(&showVersion, "version", false, "")
	fs.BoolVar(&showHelp, "help", false, "")
	fs.StringVar(&opt.input, "input", "", "")
	fs.StringVar(&opt.output, "output", "", "")
	fs.BoolVar(&opt.overwrite, "output-overwrite", false, "")
	fs.StringVar(&opt.domain, "domain", "", "")
	fs.StringVar(&opt.include, "include-selector", "", "")
	fs.StringVar(&opt.exclude, "exclude-selector", "", "")
	fs.StringVar(&opt.strong, "opt-strong-delimiter", "**", "")
	fs.BoolVar(&opt.table, "plugin-table", false, "")
	fs.BoolVar(&opt.strike, "plugin-strikethrough", false, "")
	fs.StringVar(&opt.tablePadding, "opt-table-cell-padding-behavior", "aligned", "")
	fs.BoolVar(&opt.tableHeader, "opt-table-header-promotion", false, "")
	fs.StringVar(&opt.tableNewline, "opt-table-newline-behavior", "skip", "")
	fs.BoolVar(&opt.tablePresent, "opt-table-presentation-tables", false, "")
	fs.BoolVar(&opt.tableSkipEmpty, "opt-table-skip-empty-rows", false, "")
	fs.StringVar(&opt.tableSpan, "opt-table-span-cell-behavior", "empty", "")
	if err := fs.Parse(args); err != nil {
		msg := err.Error()
		if strings.HasPrefix(msg, "flag provided but not defined: -") {
			name := strings.TrimPrefix(msg, "flag provided but not defined: -")
			return opt, fmt.Errorf("unknown flag: --%s", strings.TrimLeft(name, "-"))
		}
		return opt, err
	}
	if fs.NArg() > 0 {
		return opt, fmt.Errorf("unknown arguments: %s", strings.Join(fs.Args(), " "))
	}
	if opt.strong != "**" && opt.strong != "__" {
		return opt, errors.New(`invalid value for --opt-strong-delimiter. Use "**" or "__"`)
	}
	return opt, nil
}

func run(opt options) error {
	if opt.domain != "" {
		u, err := url.Parse(opt.domain)
		if err == nil {
			r := renderer{opt: opt, base: u}
			_ = r
		}
	}
	inputs, err := inputFiles(opt.input)
	if err != nil {
		return err
	}
	if len(inputs) == 0 {
		b, err := io.ReadAll(os.Stdin)
		if err != nil {
			return err
		}
		out := convert(string(b), opt)
		if opt.output != "" {
			return writeOutput(opt.output, out, opt.overwrite)
		}
		fmt.Print(out)
		return nil
	}
	if len(inputs) > 1 || isDir(opt.input) {
		if opt.output == "" || !isDir(opt.output) {
			return errors.New("if --input is a directory or glob pattern, --output must be a directory")
		}
		for _, p := range inputs {
			b, err := os.ReadFile(p)
			if err != nil {
				return err
			}
			name := strings.TrimSuffix(filepath.Base(p), filepath.Ext(p)) + ".md"
			if err := writeOutput(filepath.Join(opt.output, name), convert(string(b), opt), opt.overwrite); err != nil {
				return err
			}
		}
		return nil
	}
	b, err := os.ReadFile(inputs[0])
	if err != nil {
		return err
	}
	out := convert(string(b), opt)
	if opt.output != "" {
		return writeOutput(opt.output, out, opt.overwrite)
	}
	fmt.Print(out)
	return nil
}

func inputFiles(path string) ([]string, error) {
	if path == "" {
		return nil, nil
	}
	if hasGlob(path) {
		m, err := filepath.Glob(path)
		if err != nil {
			return nil, err
		}
		sort.Strings(m)
		return m, nil
	}
	st, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if st.IsDir() {
		var out []string
		err := filepath.WalkDir(path, func(p string, d os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if !d.IsDir() {
				out = append(out, p)
			}
			return nil
		})
		sort.Strings(out)
		return out, err
	}
	return []string{path}, nil
}

func hasGlob(s string) bool { return strings.ContainsAny(s, "*?[") }
func isDir(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

func writeOutput(path, content string, overwrite bool) error {
	if !overwrite {
		if _, err := os.Stat(path); err == nil {
			return fmt.Errorf("output path %q already exists. Use --output-overwrite to replace existing files", path)
		}
	}
	return os.WriteFile(path, []byte(content), 0644)
}

func convert(src string, opt options) string {
	doc, err := parseHTML(src)
	if err != nil {
		return strings.TrimSpace(stripTags(src))
	}
	if opt.exclude != "" {
		removeMatches(doc, opt.exclude)
	}
	nodes := []*Node{doc}
	if opt.include != "" {
		nodes = findMatches(doc, opt.include)
	}
	var base *url.URL
	if opt.domain != "" {
		base, _ = url.Parse(opt.domain)
	}
	r := &renderer{opt: opt, base: base}
	var parts []string
	for _, n := range nodes {
		parts = append(parts, r.renderNode(n, blockCtx{}))
	}
	return cleanOutput(strings.Join(parts, "\n\n"))
}

type blockCtx struct {
	pre        bool
	blockquote int
}

func (r *renderer) renderChildren(n *Node, ctx blockCtx) string {
	var parts []string
	for c := n.FirstChild; c != nil; c = c.NextSibling {
		parts = append(parts, r.renderNode(c, ctx))
	}
	return joinFlow(parts)
}

func (r *renderer) renderNode(n *Node, ctx blockCtx) string {
	if n.Type == TextNode {
		if ctx.pre {
			return stdhtml.UnescapeString(n.Data)
		}
		return escapeMarkdown(collapseSpace(stdhtml.UnescapeString(n.Data)))
	}
	if n.Type == DocumentNode {
		return blockJoin(r.childBlocks(n, ctx))
	}
	if n.Type != ElementNode {
		return r.renderChildren(n, ctx)
	}
	tag := strings.ToLower(n.Data)
	switch tag {
	case "script", "style", "noscript", "template", "head", "meta", "link", "title":
		return ""
	case "html", "body", "main", "article", "section", "div", "header", "footer", "nav", "aside":
		return blockJoin(r.childBlocks(n, ctx))
	case "p":
		return strings.TrimSpace(r.renderChildren(n, ctx))
	case "br":
		return "  \n"
	case "hr":
		return "* * *"
	case "h1", "h2", "h3", "h4", "h5", "h6":
		level := int(tag[1] - '0')
		return strings.Repeat("#", level) + " " + strings.TrimSpace(r.renderChildren(n, ctx))
	case "strong", "b":
		x := strings.TrimSpace(r.renderChildren(n, ctx))
		return r.opt.strong + x + r.opt.strong
	case "em", "i":
		x := strings.TrimSpace(r.renderChildren(n, ctx))
		return "*" + x + "*"
	case "code":
		if parentTag(n) == "pre" {
			return textContent(n)
		}
		x := textContent(n)
		ticks := "`"
		if strings.Contains(x, "`") {
			ticks = "``"
		}
		return ticks + x + ticks
	case "pre":
		x := r.renderChildren(n, blockCtx{pre: true, blockquote: ctx.blockquote})
		x = strings.Trim(x, "\n")
		return "```\n" + x + "\n```"
	case "a":
		label := strings.TrimSpace(r.renderChildren(n, ctx))
		href := r.absURL(attr(n, "href"))
		if href == "" {
			return label
		}
		if label == "" {
			label = href
		}
		return "[" + label + "](" + href + ")"
	case "img":
		alt := escapeMarkdown(attr(n, "alt"))
		src := r.absURL(attr(n, "src"))
		return "![" + alt + "](" + src + ")"
	case "ul":
		return r.renderList(n, false, ctx)
	case "ol":
		return r.renderList(n, true, ctx)
	case "li":
		return strings.TrimSpace(blockJoin(r.childBlocks(n, ctx)))
	case "blockquote":
		x := blockJoin(r.childBlocks(n, blockCtx{blockquote: ctx.blockquote + 1}))
		lines := strings.Split(strings.TrimSpace(x), "\n")
		for i, l := range lines {
			if strings.TrimSpace(l) == "" {
				lines[i] = ">"
			} else {
				lines[i] = "> " + l
			}
		}
		return strings.Join(lines, "\n")
	case "del", "s", "strike":
		x := r.renderChildren(n, ctx)
		if r.opt.strike {
			return "~~" + strings.TrimSpace(x) + "~~"
		}
		return x
	case "table":
		if r.opt.table {
			return r.renderTable(n, ctx)
		}
		return r.renderChildren(n, ctx)
	case "thead", "tbody", "tfoot", "tr", "th", "td":
		return r.renderChildren(n, ctx)
	default:
		return r.renderChildren(n, ctx)
	}
}

func (r *renderer) childBlocks(n *Node, ctx blockCtx) []string {
	var out []string
	var inline []string
	flush := func() {
		s := strings.TrimSpace(joinFlow(inline))
		if s != "" {
			out = append(out, s)
		}
		inline = nil
	}
	for c := n.FirstChild; c != nil; c = c.NextSibling {
		if c.Type == ElementNode && isBlockTag(strings.ToLower(c.Data)) {
			flush()
			s := strings.TrimSpace(r.renderNode(c, ctx))
			if s != "" {
				out = append(out, s)
			}
		} else {
			inline = append(inline, r.renderNode(c, ctx))
		}
	}
	flush()
	return out
}

func isBlockTag(tag string) bool {
	switch tag {
	case "address", "article", "aside", "blockquote", "div", "dl", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section", "table", "ul":
		return true
	default:
		return false
	}
}

func (r *renderer) renderList(n *Node, ordered bool, ctx blockCtx) string {
	r.listStack = append(r.listStack, listCtx{ordered: ordered})
	defer func() { r.listStack = r.listStack[:len(r.listStack)-1] }()
	var lines []string
	idx := 1
	for c := n.FirstChild; c != nil; c = c.NextSibling {
		if c.Type != ElementNode || strings.ToLower(c.Data) != "li" {
			continue
		}
		body := strings.TrimSpace(blockJoin(r.childBlocks(c, ctx)))
		prefix := "- "
		if ordered {
			prefix = fmt.Sprintf("%d. ", idx)
		}
		idx++
		parts := strings.Split(body, "\n")
		if len(parts) == 0 {
			lines = append(lines, strings.TrimSpace(prefix))
			continue
		}
		lines = append(lines, prefix+parts[0])
		indent := strings.Repeat(" ", len([]rune(prefix)))
		for _, p := range parts[1:] {
			if strings.TrimSpace(p) == "" {
				lines = append(lines, indent)
			} else {
				lines = append(lines, indent+p)
			}
		}
	}
	return strings.Join(lines, "\n")
}

func (r *renderer) renderTable(n *Node, ctx blockCtx) string {
	var rows [][]string
	var walk func(*Node)
	walk = func(x *Node) {
		if x.Type == ElementNode && strings.ToLower(x.Data) == "tr" {
			var row []string
			for c := x.FirstChild; c != nil; c = c.NextSibling {
				if c.Type == ElementNode {
					t := strings.ToLower(c.Data)
					if t == "td" || t == "th" {
						cell := strings.TrimSpace(r.renderChildren(c, ctx))
						cell = strings.ReplaceAll(cell, "\n", " ")
						row = append(row, cell)
					}
				}
			}
			if !(r.opt.tableSkipEmpty && allEmpty(row)) {
				rows = append(rows, row)
			}
			return
		}
		for c := x.FirstChild; c != nil; c = c.NextSibling {
			walk(c)
		}
	}
	walk(n)
	if len(rows) == 0 {
		return ""
	}
	cols := 0
	for _, row := range rows {
		if len(row) > cols {
			cols = len(row)
		}
	}
	for i := range rows {
		for len(rows[i]) < cols {
			rows[i] = append(rows[i], "")
		}
	}
	widths := make([]int, cols)
	for _, row := range rows {
		for i, c := range row {
			if l := len([]rune(c)); l > widths[i] {
				widths[i] = l
			}
		}
	}
	var out []string
	out = append(out, r.tableRow(rows[0], widths))
	var sep []string
	for _, w := range widths {
		sep = append(sep, strings.Repeat("-", w+2))
	}
	out = append(out, r.tableRow(sep, widths))
	for _, row := range rows[1:] {
		out = append(out, r.tableRow(row, widths))
	}
	return strings.Join(out, "\n")
}

func (r *renderer) tableRow(row []string, widths []int) string {
	if r.opt.tablePadding == "none" {
		return "|" + strings.Join(row, "|") + "|"
	}
	allDash := true
	for _, c := range row {
		if !isDashCell(c) {
			allDash = false
			break
		}
	}
	if allDash {
		return "|" + strings.Join(row, "|") + "|"
	}
	var cells []string
	for i, c := range row {
		if isDashCell(c) {
			cells = append(cells, strings.Repeat("-", widths[i]))
		} else {
			cells = append(cells, c+strings.Repeat(" ", widths[i]-len([]rune(c))))
		}
	}
	return "| " + strings.Join(cells, " | ") + " |"
}

func isDashCell(s string) bool {
	return s != "" && strings.Trim(s, "-") == ""
}
func allEmpty(row []string) bool {
	for _, c := range row {
		if strings.TrimSpace(c) != "" {
			return false
		}
	}
	return true
}

func (r *renderer) absURL(s string) string {
	if s == "" || r.base == nil {
		return s
	}
	u, err := url.Parse(s)
	if err != nil || u.IsAbs() || strings.HasPrefix(s, "#") || strings.HasPrefix(s, "mailto:") {
		return s
	}
	return r.base.ResolveReference(u).String()
}

func joinFlow(parts []string) string {
	var b strings.Builder
	for _, p := range parts {
		if p == "" {
			continue
		}
		if b.Len() > 0 && needsSpace(b.String(), p) {
			b.WriteByte(' ')
		}
		b.WriteString(p)
	}
	return b.String()
}

func needsSpace(left, right string) bool {
	if strings.HasSuffix(left, "\n") || strings.HasPrefix(right, "\n") || strings.HasPrefix(right, "  \n") {
		return false
	}
	l := lastRune(left)
	r := firstRune(right)
	if l == 0 || r == 0 {
		return false
	}
	if unicode.IsSpace(l) || unicode.IsSpace(r) {
		return false
	}
	if strings.ContainsRune(".,;:!?)]}", r) || strings.ContainsRune("([", l) {
		return false
	}
	if strings.HasPrefix(right, "![") {
		return false
	}
	return true
}

func firstRune(s string) rune {
	for _, r := range s {
		return r
	}
	return 0
}
func lastRune(s string) rune {
	var out rune
	for _, r := range s {
		out = r
	}
	return out
}

func blockJoin(parts []string) string {
	var clean []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			clean = append(clean, p)
		}
	}
	return strings.Join(clean, "\n\n")
}

func cleanOutput(s string) string {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	reBlank := regexp.MustCompile(`\n{3,}`)
	s = reBlank.ReplaceAllString(s, "\n\n")
	return strings.Trim(s, " \t\r\n")
}

func collapseSpace(s string) string {
	var b strings.Builder
	last := false
	for _, r := range s {
		if r == '\u00a0' {
			if last {
				continue
			}
			b.WriteRune(r)
			last = true
			continue
		}
		if unicode.IsSpace(r) {
			if !last {
				b.WriteByte(' ')
				last = true
			}
		} else {
			b.WriteRune(r)
			last = false
		}
	}
	return b.String()
}

func escapeMarkdown(s string) string {
	if s == "" {
		return ""
	}
	repl := strings.NewReplacer(`\`, `\\`)
	s = repl.Replace(s)
	var b strings.Builder
	for i, r := range s {
		switch r {
		case '*', '_', '`':
			b.WriteByte('\\')
		case '[', ']':
			b.WriteByte('\\')
		case '<', '>':
			b.WriteByte('\\')
		}
		if (r == '#' || r == '-' || r == '+' || r == '=') && (i == 0 || s[i-1] == '\n') {
			b.WriteByte('\\')
		}
		b.WriteRune(r)
	}
	return b.String()
}

func attr(n *Node, key string) string {
	for _, a := range n.Attr {
		if strings.EqualFold(a.Key, key) {
			return a.Val
		}
	}
	return ""
}

func parentTag(n *Node) string {
	if n.Parent != nil && n.Parent.Type == ElementNode {
		return strings.ToLower(n.Parent.Data)
	}
	return ""
}

func textContent(n *Node) string {
	var b bytes.Buffer
	var walk func(*Node)
	walk = func(x *Node) {
		if x.Type == TextNode {
			b.WriteString(stdhtml.UnescapeString(x.Data))
		}
		for c := x.FirstChild; c != nil; c = c.NextSibling {
			walk(c)
		}
	}
	walk(n)
	return b.String()
}

func stripTags(s string) string {
	re := regexp.MustCompile(`<[^>]+>`)
	return re.ReplaceAllString(s, "")
}

func parseHTML(src string) (*Node, error) {
	root := &Node{Type: DocumentNode, Data: "#document"}
	stack := []*Node{root}
	for i := 0; i < len(src); {
		if src[i] != '<' {
			j := strings.IndexByte(src[i:], '<')
			if j < 0 {
				j = len(src)
			} else {
				j += i
			}
			if j > i {
				stack[len(stack)-1].AppendChild(&Node{Type: TextNode, Data: src[i:j]})
			}
			i = j
			continue
		}
		if strings.HasPrefix(src[i:], "<!--") {
			if j := strings.Index(src[i+4:], "-->"); j >= 0 {
				i += 4 + j + 3
			} else {
				break
			}
			continue
		}
		j := strings.IndexByte(src[i:], '>')
		if j < 0 {
			stack[len(stack)-1].AppendChild(&Node{Type: TextNode, Data: src[i:]})
			break
		}
		raw := strings.TrimSpace(src[i+1 : i+j])
		i += j + 1
		if raw == "" || strings.HasPrefix(raw, "!") || strings.HasPrefix(raw, "?") {
			continue
		}
		if strings.HasPrefix(raw, "/") {
			name := strings.ToLower(strings.Fields(strings.TrimSpace(raw[1:]))[0])
			for k := len(stack) - 1; k > 0; k-- {
				if stack[k].Data == name {
					stack = stack[:k]
					break
				}
			}
			continue
		}
		selfClose := strings.HasSuffix(raw, "/")
		if selfClose {
			raw = strings.TrimSpace(strings.TrimSuffix(raw, "/"))
		}
		name, attrs := parseTag(raw)
		if name == "" {
			continue
		}
		n := &Node{Type: ElementNode, Data: name, Attr: attrs}
		stack[len(stack)-1].AppendChild(n)
		if !selfClose && !isVoidTag(name) {
			stack = append(stack, n)
		}
	}
	return root, nil
}

func parseTag(raw string) (string, []Attr) {
	raw = strings.TrimSpace(raw)
	i := 0
	for i < len(raw) && !unicode.IsSpace(rune(raw[i])) {
		i++
	}
	name := strings.ToLower(raw[:i])
	var attrs []Attr
	for i < len(raw) {
		for i < len(raw) && unicode.IsSpace(rune(raw[i])) {
			i++
		}
		if i >= len(raw) {
			break
		}
		start := i
		for i < len(raw) && raw[i] != '=' && !unicode.IsSpace(rune(raw[i])) {
			i++
		}
		key := strings.ToLower(raw[start:i])
		for i < len(raw) && unicode.IsSpace(rune(raw[i])) {
			i++
		}
		val := ""
		if i < len(raw) && raw[i] == '=' {
			i++
			for i < len(raw) && unicode.IsSpace(rune(raw[i])) {
				i++
			}
			if i < len(raw) && (raw[i] == '"' || raw[i] == '\'') {
				quote := raw[i]
				i++
				start = i
				for i < len(raw) && raw[i] != quote {
					i++
				}
				val = raw[start:i]
				if i < len(raw) {
					i++
				}
			} else {
				start = i
				for i < len(raw) && !unicode.IsSpace(rune(raw[i])) {
					i++
				}
				val = raw[start:i]
			}
		}
		if key != "" {
			attrs = append(attrs, Attr{Key: key, Val: stdhtml.UnescapeString(val)})
		}
	}
	return name, attrs
}

func isVoidTag(name string) bool {
	switch name {
	case "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr":
		return true
	default:
		return false
	}
}

func removeMatches(n *Node, selector string) {
	for c := n.FirstChild; c != nil; {
		next := c.NextSibling
		if matches(c, selector) {
			n.RemoveChild(c)
		} else {
			removeMatches(c, selector)
		}
		c = next
	}
}

func findMatches(n *Node, selector string) []*Node {
	var out []*Node
	var walk func(*Node)
	walk = func(x *Node) {
		if matches(x, selector) {
			out = append(out, x)
			return
		}
		for c := x.FirstChild; c != nil; c = c.NextSibling {
			walk(c)
		}
	}
	walk(n)
	return out
}

func matches(n *Node, selector string) bool {
	if n.Type != ElementNode {
		return false
	}
	selector = strings.TrimSpace(selector)
	if selector == "" {
		return false
	}
	if strings.HasPrefix(selector, "#") {
		return attr(n, "id") == selector[1:]
	}
	if strings.HasPrefix(selector, ".") {
		want := selector[1:]
		for _, c := range strings.Fields(attr(n, "class")) {
			if c == want {
				return true
			}
		}
		return false
	}
	if strings.Contains(selector, "[") && strings.HasSuffix(selector, "]") {
		tag := selector[:strings.Index(selector, "[")]
		cond := strings.TrimSuffix(selector[strings.Index(selector, "[")+1:], "]")
		if tag != "" && !strings.EqualFold(n.Data, tag) {
			return false
		}
		if strings.Contains(cond, "=") {
			parts := strings.SplitN(cond, "=", 2)
			val := strings.Trim(parts[1], `"'`)
			return attr(n, parts[0]) == val
		}
		return attr(n, cond) != ""
	}
	return strings.EqualFold(n.Data, selector)
}

func printHelp() {
	fmt.Print(`
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Basics

By default the "Commonmark" Plugin will be enabled. You can customize the options,
for example changing the appearance of bold with --opt-strong-delimiter="__"

Other Plugins can also be enabled. For example "GitHub Flavored Markdown" (GFM)
extends Commonmark with more features.

## Relative / Absolute Links

Use --domain="https://example.com" to convert *relative* links to *absolute* links.
The same also works for images.

## Escaping

Some characters have a special meaning in markdown. The library escapes these — if necessary.
See the documentation for more info.

## Security

Once you convert this markdown *back* to HTML you need to be careful of malicious content. 
Use a HTML sanitizer before displaying the HTML in the browser!


## Examples

    echo "<strong>important</strong>" | html2markdown

    curl --no-progress-meter http://example.com | html2markdown


    html2markdown --input file.html --output file.md

    html2markdown --input "src/*.html" --output "dist/"


## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    If --input is a directory or glob pattern, --output must be a directory.



    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        Make bold text. Should <strong> be indicated by two asterisks or two underscores?
        "**" or "__" (default: "**")

    --opt-table-cell-padding-behavior
        [for --plugin-table] whether cells in the tables should include extra padding for visual continuity: "aligned", "minimal", or "none"

    --opt-table-header-promotion
        [for --plugin-table] first row should be treated as a header

    --opt-table-newline-behavior
        [for --plugin-table] how tables containing newlines should be handled: "skip" or "preserve"

    --opt-table-presentation-tables
        [for --plugin-table] whether tables with role="presentation" should be converted

    --opt-table-skip-empty-rows
        [for --plugin-table] omit empty rows from the output

    --opt-table-span-cell-behavior
        [for --plugin-table] how colspan/rowspan should be rendered: "empty" or "mirror"

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table



For more information visit the documentation:
https://github.com/Johanneskaufmann/html-to-markdown
`)
}
