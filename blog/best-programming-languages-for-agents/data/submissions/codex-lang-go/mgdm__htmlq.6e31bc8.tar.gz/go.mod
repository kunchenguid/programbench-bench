module htmlq-reimpl

go 1.21

require (
	github.com/andybalholm/cascadia v1.3.3
	golang.org/x/net v0.33.0
)

replace golang.org/x/net => ./xnet
