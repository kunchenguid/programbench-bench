package main

import (
	"bytes"
	"fmt"
	"io"
	"net/url"
	"os"
	"sort"
	"strings"

	"github.com/andybalholm/cascadia"
	"golang.org/x/net/html"
)

type config struct {
	text             bool
	pretty           bool
	ignoreWhitespace bool
	detectBase        bool
	attribute        string
	base             string
	filename         string
	output           string
	removeSelectors  []string
	selectors        []string
}

func main() {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := run(cfg); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (config, error) {
	cfg := config{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			printHelp()
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("htmlq 0.4.0")
			os.Exit(0)
		case "-t", "--text":
			cfg.text = true
		case "-p", "--pretty":
			cfg.pretty = true
		case "-w", "--ignore-whitespace":
			cfg.ignoreWhitespace = true
		case "-B", "--detect-base":
			cfg.detectBase = true
		case "-a", "--attribute":
			i++
			if i >= len(args) { return cfg, fmt.Errorf("error: The argument '%s <attribute>' requires a value but none was supplied", a) }
			cfg.attribute = args[i]
		case "-b", "--base":
			i++
			if i >= len(args) { return cfg, fmt.Errorf("error: The argument '%s <base>' requires a value but none was supplied", a) }
			cfg.base = args[i]
		case "-f", "--filename":
			i++
			if i >= len(args) { return cfg, fmt.Errorf("error: The argument '%s <FILE>' requires a value but none was supplied", a) }
			cfg.filename = args[i]
		case "-o", "--output":
			i++
			if i >= len(args) { return cfg, fmt.Errorf("error: The argument '%s <FILE>' requires a value but none was supplied", a) }
			cfg.output = args[i]
		case "-r", "--remove-nodes":
			for i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				cfg.removeSelectors = append(cfg.removeSelectors, args[i])
			}
		case "--":
			cfg.selectors = append(cfg.selectors, args[i+1:]...)
			i = len(args)
		default:
			if strings.HasPrefix(a, "--attribute=") { cfg.attribute = strings.TrimPrefix(a, "--attribute="); continue }
			if strings.HasPrefix(a, "--base=") { cfg.base = strings.TrimPrefix(a, "--base="); continue }
			if strings.HasPrefix(a, "--filename=") { cfg.filename = strings.TrimPrefix(a, "--filename="); continue }
			if strings.HasPrefix(a, "--output=") { cfg.output = strings.TrimPrefix(a, "--output="); continue }
			if strings.HasPrefix(a, "-") { return cfg, fmt.Errorf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFor more information try --help", a) }
			cfg.selectors = append(cfg.selectors, a)
		}
	}
	if len(cfg.selectors) == 0 {
		cfg.selectors = []string{"html"}
	}
	return cfg, nil
}

func printHelp() {
	fmt.Print(`htmlq 0.4.0
Michael Maclean <michael@mgdm.net>
Runs CSS selectors on HTML

USAGE:
    executable [FLAGS] [OPTIONS] [--] [selector]...

FLAGS:
    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to
                               the value of --base, if supplied
    -h, --help                 Prints help information
    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace
    -p, --pretty               Pretty-print the serialised output
    -t, --text                 Output only the contents of text nodes inside selected elements
    -V, --version              Prints version information

OPTIONS:
    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements
    -b, --base <base>                   Use this URL as the base for links
    -f, --filename <FILE>               The input file. Defaults to stdin
    -o, --output <FILE>                 The output file. Defaults to stdout
    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple
                                        times

ARGS:
    <selector>...    The CSS expression to select [default: html]
`)
}

func run(cfg config) error {
	var r io.Reader = os.Stdin
	if cfg.filename != "" {
		f, err := os.Open(cfg.filename)
		if err != nil { return fmt.Errorf("should have opened input file: %v", err) }
		defer f.Close()
		r = f
	}
	doc, err := html.Parse(r)
	if err != nil { return err }

	for _, rs := range cfg.removeSelectors {
		m, err := cascadia.ParseGroup(rs)
		if err != nil { return fmt.Errorf("Failed to parse CSS selector: %v", err) }
		for _, n := range cascadia.QueryAll(doc, m) { detach(n) }
	}

	base := activeBase(cfg, doc)
	nodes, err := selectNodes(doc, cfg.selectors)
	if err != nil { return err }

	var out bytes.Buffer
	for _, n := range nodes {
		if cfg.attribute != "" {
			if v, ok := attr(n, cfg.attribute); ok {
				if cfg.attribute == "href" && base != nil {
					if u, err := url.Parse(v); err == nil {
						v = base.ResolveReference(u).String()
					}
				}
				out.WriteString(v)
				out.WriteByte('\n')
			}
			continue
		}
		if cfg.text {
			if cfg.ignoreWhitespace { writeTextLines(&out, n) } else { writeTextConcat(&out, n); out.WriteByte('\n') }
			continue
		}
		if cfg.pretty { renderPretty(&out, n, 0); if out.Len() == 0 || out.Bytes()[out.Len()-1] != '\n' { out.WriteByte('\n') } } else { renderCompact(&out, n); out.WriteByte('\n') }
	}

	if cfg.output != "" {
		return os.WriteFile(cfg.output, out.Bytes(), 0644)
	}
	_, err = os.Stdout.Write(out.Bytes())
	return err
}

func selectNodes(doc *html.Node, selectors []string) ([]*html.Node, error) {
	expr := strings.Join(selectors, " ")
	m, err := cascadia.ParseGroup(expr)
	if err != nil { return nil, fmt.Errorf("Failed to parse CSS selector: %v", err) }
	return cascadia.QueryAll(doc, m), nil
}

func activeBase(cfg config, doc *html.Node) *url.URL {
	candidate := cfg.base
	if cfg.detectBase {
		if bases, err := selectNodes(doc, []string{"base[href]"}); err == nil && len(bases) > 0 {
			if v, ok := attr(bases[0], "href"); ok && isAbsURL(v) { candidate = v }
		}
	}
	if !isAbsURL(candidate) { return nil }
	u, err := url.Parse(candidate)
	if err != nil || !u.IsAbs() { return nil }
	return u
}

func isAbsURL(s string) bool { u, err := url.Parse(s); return err == nil && u.IsAbs() }

func attr(n *html.Node, key string) (string, bool) {
	for _, a := range n.Attr { if a.Key == key { return a.Val, true } }
	return "", false
}

func detach(n *html.Node) {
	if n.Parent == nil { return }
	n.Parent.RemoveChild(n)
}

func renderCompact(w io.Writer, n *html.Node) {
	clone := cloneSorted(n)
	_ = html.Render(w, clone)
}

func cloneSorted(n *html.Node) *html.Node {
	c := &html.Node{Type:n.Type, DataAtom:n.DataAtom, Data:n.Data, Namespace:n.Namespace}
	c.Attr = append([]html.Attribute(nil), n.Attr...)
	sort.Slice(c.Attr, func(i, j int) bool { return c.Attr[i].Key < c.Attr[j].Key })
	for ch := n.FirstChild; ch != nil; ch = ch.NextSibling { c.AppendChild(cloneSorted(ch)) }
	return c
}

func writeTextConcat(w io.Writer, n *html.Node) {
	if n.Type == html.TextNode { io.WriteString(w, n.Data) }
	for c := n.FirstChild; c != nil; c = c.NextSibling { writeTextConcat(w, c) }
}

func writeTextLines(w io.Writer, n *html.Node) {
	if n.Type == html.TextNode && strings.TrimSpace(n.Data) != "" { io.WriteString(w, n.Data); io.WriteString(w, "\n") }
	for c := n.FirstChild; c != nil; c = c.NextSibling { writeTextLines(w, c) }
}

func renderPretty(w io.Writer, n *html.Node, depth int) {
	if n.Type == html.TextNode {
		if strings.TrimSpace(n.Data) == "" { return }
		fmt.Fprintf(w, "%s%s\n", strings.Repeat("  ", depth), n.Data)
		return
	}
	if n.Type != html.ElementNode {
		renderCompact(w, n)
		return
	}
	indent := strings.Repeat("  ", depth)
	fmt.Fprintf(w, "%s<%s", indent, n.Data)
	attrs := append([]html.Attribute(nil), n.Attr...)
	sort.Slice(attrs, func(i,j int) bool { return attrs[i].Key < attrs[j].Key })
	for _, a := range attrs { fmt.Fprintf(w, " %s=\"%s\"", a.Key, html.EscapeString(a.Val)) }
	if isVoid(n.Data) { fmt.Fprint(w, ">\n"); return }
	fmt.Fprint(w, ">")
	if n.FirstChild == nil { fmt.Fprintf(w, "</%s>\n", n.Data); return }
	fmt.Fprint(w, "\n")
	for c := n.FirstChild; c != nil; c = c.NextSibling { renderPretty(w, c, depth+1) }
	fmt.Fprintf(w, "%s</%s>\n", indent, n.Data)
}

func isVoid(tag string) bool {
	switch tag { case "area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr": return true }
	return false
}
