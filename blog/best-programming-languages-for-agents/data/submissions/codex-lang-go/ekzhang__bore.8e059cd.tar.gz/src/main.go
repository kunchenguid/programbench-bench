package main

import (
	"bufio"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

const controlPort = 7835
const version = "bore-cli 0.6.0"

var errHelp = errors.New("help")

type tunnel struct {
	port     int
	secret   string
	listener net.Listener
	control  net.Conn
	pending  map[string]chan net.Conn
	mu       sync.Mutex
}

type serverState struct {
	minPort     int
	maxPort     int
	secret      string
	bindAddr    string
	bindTunnels string
	tunnels     map[int]*tunnel
	mu          sync.Mutex
}

func main() {
	if len(os.Args) < 2 {
		printRootHelp()
		return
	}
	switch os.Args[1] {
	case "-h", "--help", "help":
		if len(os.Args) >= 3 {
			switch os.Args[2] {
			case "local":
				printLocalHelp()
			case "server":
				printServerHelp()
			default:
				printRootHelp()
			}
		} else {
			printRootHelp()
		}
	case "-V", "--version":
		fmt.Println(version)
	case "local":
		if err := runLocal(os.Args[2:]); err != nil {
			if errors.Is(err, errHelp) {
				return
			}
			if strings.HasPrefix(err.Error(), "error:") {
				fmt.Fprintln(os.Stderr, err)
			} else {
				fmt.Fprintln(os.Stderr, "Error:", err)
			}
			os.Exit(1)
		}
	case "server":
		if err := runServer(os.Args[2:]); err != nil {
			if errors.Is(err, errHelp) {
				return
			}
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", os.Args[1])
		os.Exit(2)
	}
}

func printRootHelp() {
	fmt.Println(`A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version`)
}

func printLocalHelp() {
	fmt.Println(`Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help`)
}

func printServerHelp() {
	fmt.Println(`Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help`)
}

func envDefault(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func runLocal(args []string) error {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			printLocalHelp()
			return errHelp
		}
	}
	fs := flag.NewFlagSet("local", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	localHost := fs.String("local-host", "localhost", "")
	fs.StringVar(localHost, "l", "localhost", "")
	to := fs.String("to", envDefault("BORE_SERVER", ""), "")
	fs.StringVar(to, "t", envDefault("BORE_SERVER", ""), "")
	port := fs.Int("port", 0, "")
	fs.IntVar(port, "p", 0, "")
	secret := fs.String("secret", envDefault("BORE_SECRET", ""), "")
	fs.StringVar(secret, "s", envDefault("BORE_SECRET", ""), "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	rest := fs.Args()
	localPort := envDefault("BORE_LOCAL_PORT", "")
	if len(rest) > 0 {
		localPort = rest[0]
	}
	if *to == "" {
		return errors.New("error: the following required arguments were not provided:\n  --to <TO>\n\nUsage: executable local --to <TO> <LOCAL_PORT>\n\nFor more information, try '--help'.")
	}
	if localPort == "" {
		return errors.New("error: the following required arguments were not provided:\n  <LOCAL_PORT>")
	}
	if _, err := strconv.Atoi(localPort); err != nil {
		return fmt.Errorf("invalid value '%s' for '<LOCAL_PORT>'", localPort)
	}
	serverAddr := *to
	if !strings.Contains(serverAddr, ":") {
		serverAddr = fmt.Sprintf("%s:%d", serverAddr, controlPort)
	}
	ctrl, err := net.Dial("tcp", serverAddr)
	if err != nil {
		return fmt.Errorf("could not connect to %s\n\nCaused by:\n    %v", serverAddr, err)
	}
	defer ctrl.Close()
	fmt.Fprintf(ctrl, "LOCAL %s %d %s\n", enc(*secret), *port, localPort)
	rd := bufio.NewReader(ctrl)
	line, err := rd.ReadString('\n')
	if err != nil {
		return err
	}
	fields := strings.Fields(line)
	if len(fields) < 2 || fields[0] != "OK" {
		return errors.New(strings.TrimSpace(line))
	}
	remotePort, _ := strconv.Atoi(fields[1])
	info("bore_cli::client", fmt.Sprintf("connected to server remote_port=%d", remotePort))
	info("bore_cli::client", fmt.Sprintf("listening at %s:%d", hostForDisplay(*to), remotePort))
	for {
		line, err := rd.ReadString('\n')
		if err != nil {
			return nil
		}
		f := strings.Fields(line)
		if len(f) == 2 && f[0] == "CONNECT" {
			id := f[1]
			go handleLocalData(serverAddr, *secret, remotePort, id, net.JoinHostPort(*localHost, localPort))
		}
	}
}

func handleLocalData(serverAddr, secret string, remotePort int, id, target string) {
	local, err := net.Dial("tcp", target)
	if err != nil {
		return
	}
	srv, err := net.Dial("tcp", serverAddr)
	if err != nil {
		local.Close()
		return
	}
	fmt.Fprintf(srv, "DATA %s %d %s\n", enc(secret), remotePort, id)
	go copyClose(local, srv)
	go copyClose(srv, local)
}

func runServer(args []string) error {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			printServerHelp()
			return errHelp
		}
	}
	fs := flag.NewFlagSet("server", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	minPort := fs.Int("min-port", atoiDefault(envDefault("BORE_MIN_PORT", "1024"), 1024), "")
	maxPort := fs.Int("max-port", atoiDefault(envDefault("BORE_MAX_PORT", "65535"), 65535), "")
	secret := fs.String("secret", envDefault("BORE_SECRET", ""), "")
	fs.StringVar(secret, "s", envDefault("BORE_SECRET", ""), "")
	bindAddr := fs.String("bind-addr", "0.0.0.0", "")
	bindTunnels := fs.String("bind-tunnels", "", "")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if *bindTunnels == "" {
		*bindTunnels = *bindAddr
	}
	st := &serverState{*minPort, *maxPort, *secret, *bindAddr, *bindTunnels, make(map[int]*tunnel), sync.Mutex{}}
	ln, err := net.Listen("tcp", net.JoinHostPort(*bindAddr, strconv.Itoa(controlPort)))
	if err != nil {
		return err
	}
	info("bore_cli::server", fmt.Sprintf("server listening addr=%s", *bindAddr))
	for {
		c, err := ln.Accept()
		if err != nil {
			continue
		}
		go st.handleControl(c)
	}
}

func (st *serverState) handleControl(c net.Conn) {
	br := bufio.NewReader(c)
	line, err := br.ReadString('\n')
	if err != nil {
		c.Close()
		return
	}
	f := strings.Fields(line)
	if len(f) == 0 {
		c.Close()
		return
	}
	switch f[0] {
	case "LOCAL":
		if len(f) < 4 {
			fmt.Fprintln(c, "ERR bad request")
			c.Close()
			return
		}
		secret := dec(f[1])
		req, _ := strconv.Atoi(f[2])
		if st.secret != "" && secret != st.secret {
			fmt.Fprintln(c, "ERR unauthorized")
			c.Close()
			return
		}
		t, err := st.newTunnel(req, secret, c)
		if err != nil {
			fmt.Fprintln(c, "ERR "+err.Error())
			c.Close()
			return
		}
		fmt.Fprintf(c, "OK %d\n", t.port)
		info("bore_cli::server", fmt.Sprintf("new client host=%s port=%d", st.bindTunnels, t.port))
		select {}
	case "DATA":
		if len(f) < 4 {
			c.Close()
			return
		}
		secret := dec(f[1])
		port, _ := strconv.Atoi(f[2])
		id := f[3]
		st.mu.Lock()
		t := st.tunnels[port]
		st.mu.Unlock()
		if t == nil || (t.secret != "" && t.secret != secret) {
			c.Close()
			return
		}
		t.mu.Lock()
		ch := t.pending[id]
		delete(t.pending, id)
		t.mu.Unlock()
		if ch == nil {
			c.Close()
			return
		}
		ch <- c
	default:
		c.Close()
	}
}

func (st *serverState) newTunnel(req int, secret string, control net.Conn) (*tunnel, error) {
	ports := []int{}
	if req != 0 {
		ports = append(ports, req)
	} else {
		for p := st.minPort; p <= st.maxPort; p++ {
			ports = append(ports, p)
		}
	}
	var ln net.Listener
	var port int
	var err error
	for _, p := range ports {
		if p < st.minPort || p > st.maxPort {
			return nil, fmt.Errorf("port %d not in allowed range", p)
		}
		ln, err = net.Listen("tcp", net.JoinHostPort(st.bindTunnels, strconv.Itoa(p)))
		if err == nil {
			port = p
			break
		}
	}
	if ln == nil {
		if err != nil {
			return nil, err
		}
		return nil, errors.New("no available ports")
	}
	t := &tunnel{port: port, secret: secret, listener: ln, control: control, pending: make(map[string]chan net.Conn)}
	st.mu.Lock()
	st.tunnels[port] = t
	st.mu.Unlock()
	go t.acceptLoop()
	return t, nil
}

func (t *tunnel) acceptLoop() {
	var n uint64
	for {
		remote, err := t.listener.Accept()
		if err != nil {
			return
		}
		n++
		id := fmt.Sprintf("%d-%d", time.Now().UnixNano(), n)
		ch := make(chan net.Conn, 1)
		t.mu.Lock()
		t.pending[id] = ch
		t.mu.Unlock()
		fmt.Fprintf(t.control, "CONNECT %s\n", id)
		go func() {
			select {
			case data := <-ch:
				go copyClose(remote, data)
				go copyClose(data, remote)
			case <-time.After(10 * time.Second):
				remote.Close()
				t.mu.Lock()
				delete(t.pending, id)
				t.mu.Unlock()
			}
		}()
	}
}

func copyClose(dst net.Conn, src net.Conn) { io.Copy(dst, src); dst.Close(); src.Close() }
func enc(s string) string {
	if s == "" {
		return "-"
	}
	return strings.NewReplacer("%", "%25", " ", "%20", "\n", "").Replace(s)
}
func dec(s string) string {
	if s == "-" {
		return ""
	}
	r := strings.NewReplacer("%20", " ", "%25", "%")
	return r.Replace(s)
}
func atoiDefault(s string, d int) int {
	if v, err := strconv.Atoi(s); err == nil {
		return v
	}
	return d
}
func hostForDisplay(s string) string {
	if h, _, err := net.SplitHostPort(s); err == nil {
		return h
	}
	return s
}
func info(target, msg string) {
	fmt.Fprintf(os.Stderr, "%s  INFO %s: %s\n", time.Now().UTC().Format(time.RFC3339), target, msg)
}
