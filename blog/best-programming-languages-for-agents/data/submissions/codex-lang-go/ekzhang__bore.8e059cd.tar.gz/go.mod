module boreclone

go 1.21
