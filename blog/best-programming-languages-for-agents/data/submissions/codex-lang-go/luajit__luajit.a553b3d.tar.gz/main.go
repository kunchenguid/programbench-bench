package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"
	"strings"
	"unicode"
)

const versionLine = "LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/"

type Value interface{}
type Native func(*Interp, []Value) ([]Value, error)
type UserFunc struct {
	params []string
	body   []Stmt
	env    *Env
}

type Table struct {
	arr map[interface{}]Value
}
type Iterator struct {
	table *Table
	keys  []Value
	pos   int
}

func NewTable() *Table { return &Table{arr: map[interface{}]Value{}} }
func (t *Table) Get(k Value) Value {
	if n, ok := k.(float64); ok && math.Trunc(n) == n {
		if v, ok := t.arr[int(n)]; ok {
			return v
		}
	}
	return t.arr[key(k)]
}
func (t *Table) Set(k, v Value) {
	if v == nil {
		delete(t.arr, key(k))
		return
	}
	t.arr[key(k)] = v
}
func key(v Value) interface{} {
	if n, ok := v.(float64); ok && math.Trunc(n) == n {
		return int(n)
	}
	return v
}
func (t *Table) Len() int {
	n := 0
	for {
		if _, ok := t.arr[n+1]; ok {
			n++
		} else {
			return n
		}
	}
}
func tableKeys(t *Table) []Value {
	keys := []Value{}
	if t == nil { return keys }
	for k := range t.arr {
		switch x := k.(type) {
		case int: keys = append(keys, float64(x))
		case string: keys = append(keys, x)
		default: keys = append(keys, x)
		}
	}
	return keys
}

type Env struct {
	parent *Env
	vars   map[string]Value
}

func NewEnv(p *Env) *Env { return &Env{parent: p, vars: map[string]Value{}} }
func (e *Env) Get(name string) Value {
	for x := e; x != nil; x = x.parent {
		if v, ok := x.vars[name]; ok {
			return v
		}
	}
	return nil
}
func (e *Env) Set(name string, v Value) {
	for x := e; x != nil; x = x.parent {
		if _, ok := x.vars[name]; ok {
			x.vars[name] = v
			return
		}
	}
	root := e
	for root.parent != nil {
		root = root.parent
	}
	root.vars[name] = v
}
func (e *Env) Local(name string, v Value) { e.vars[name] = v }

type Interp struct {
	global *Env
	stdout io.Writer
	stderr io.Writer
	prog   string
}

func NewInterp(prog string, args []string) *Interp {
	in := &Interp{global: NewEnv(nil), stdout: os.Stdout, stderr: os.Stderr, prog: prog}
	in.install(args)
	return in
}

func (in *Interp) install(args []string) {
	g := in.global
	g.Local("_VERSION", "Lua 5.1")
	jit := NewTable()
	jit.Set("version", "LuaJIT 2.1.1772570160")
	jit.Set("version_num", float64(20100))
	jit.Set("os", "Linux")
	jit.Set("arch", "x64")
	g.Local("jit", jit)
	argt := NewTable()
	for i, a := range args {
		argt.Set(float64(i), a)
	}
	g.Local("arg", argt)
	g.Local("print", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		for i, x := range xs {
			if i > 0 {
				fmt.Fprint(in.stdout, "\t")
			}
			fmt.Fprint(in.stdout, luaString(x))
		}
		fmt.Fprint(in.stdout, "\n")
		return nil, nil
	}))
	g.Local("tostring", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs) == 0 {
			return []Value{"nil"}, nil
		}
		return []Value{luaString(xs[0])}, nil
	}))
	g.Local("tonumber", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs) == 0 {
			return []Value{nil}, nil
		}
		switch v := xs[0].(type) {
		case float64:
			return []Value{v}, nil
		case string:
			n, err := strconv.ParseFloat(strings.TrimSpace(v), 64)
			if err != nil {
				return []Value{nil}, nil
			}
			return []Value{n}, nil
		}
		return []Value{nil}, nil
	}))
	g.Local("type", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs) == 0 || xs[0] == nil {
			return []Value{"nil"}, nil
		}
		switch xs[0].(type) {
		case float64:
			return []Value{"number"}, nil
		case string:
			return []Value{"string"}, nil
		case bool:
			return []Value{"boolean"}, nil
		case *Table:
			return []Value{"table"}, nil
		case Native, *UserFunc:
			return []Value{"function"}, nil
		default:
			return []Value{"userdata"}, nil
		}
	}))
	g.Local("assert", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs) == 0 || !truth(xs[0]) {
			msg := "assertion failed!"
			if len(xs) > 1 {
				msg = luaString(xs[1])
			}
			return nil, errors.New(msg)
		}
		return xs, nil
	}))
	g.Local("error", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs) == 0 {
			return nil, errors.New("")
		}
		return nil, errors.New(luaString(xs[0]))
	}))
	g.Local("require", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs) == 0 {
			return nil, errors.New("bad argument #1 to 'require' (string expected, got no value)")
		}
		name := luaString(xs[0])
		if v := g.Get(name); v != nil {
			return []Value{v}, nil
		}
		return []Value{true}, nil
	}))
	g.Local("pairs", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		return []Value{&Iterator{table: first(xs).(*Table), keys: tableKeys(first(xs).(*Table))}}, nil
	}))
	g.Local("ipairs", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		t, _ := first(xs).(*Table)
		keys := []Value{}
		if t != nil {
			for i := 1; i <= t.Len(); i++ { keys = append(keys, float64(i)) }
		}
		return []Value{&Iterator{table: t, keys: keys}}, nil
	}))
	mathT := NewTable()
	mathT.Set("pi", math.Pi); mathT.Set("huge", math.Inf(1))
	mathT.Set("abs", Native(num1(math.Abs))); mathT.Set("floor", Native(num1(math.Floor)))
	mathT.Set("ceil", Native(num1(math.Ceil))); mathT.Set("sqrt", Native(num1(math.Sqrt)))
	mathT.Set("sin", Native(num1(math.Sin))); mathT.Set("cos", Native(num1(math.Cos)))
	mathT.Set("max", Native(func(_ *Interp, xs []Value) ([]Value, error) { m := toNum(xs[0]); for _, x := range xs[1:] { if n := toNum(x); n > m { m = n } }; return []Value{m}, nil }))
	mathT.Set("min", Native(func(_ *Interp, xs []Value) ([]Value, error) { m := toNum(xs[0]); for _, x := range xs[1:] { if n := toNum(x); n < m { m = n } }; return []Value{m}, nil }))
	g.Local("math", mathT)
	stringT := NewTable()
	stringT.Set("len", Native(func(_ *Interp, xs []Value) ([]Value, error) { return []Value{float64(len(luaString(first(xs))))}, nil }))
	stringT.Set("upper", Native(func(_ *Interp, xs []Value) ([]Value, error) { return []Value{strings.ToUpper(luaString(first(xs)))}, nil }))
	stringT.Set("lower", Native(func(_ *Interp, xs []Value) ([]Value, error) { return []Value{strings.ToLower(luaString(first(xs)))}, nil }))
	stringT.Set("format", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs)==0 { return []Value{""}, nil }
		format := luaString(xs[0])
		vals := []interface{}{}
		for _, x := range xs[1:] {
			if n,ok:=x.(float64); ok { vals=append(vals,n) } else { vals=append(vals,luaString(x)) }
		}
		return []Value{fmt.Sprintf(format, vals...)}, nil
	}))
	stringT.Set("sub", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		s := luaString(first(xs)); i, j := int(toNum(at(xs, 1))), len(s)
		if len(xs) > 2 { j = int(toNum(xs[2])) }
		if i < 0 { i = len(s)+i+1 }; if j < 0 { j = len(s)+j+1 }
		if i < 1 { i = 1 }; if j > len(s) { j = len(s) }; if j < i { return []Value{""}, nil }
		return []Value{s[i-1:j]}, nil
	}))
	g.Local("string", stringT)
	ioT := NewTable()
	ioT.Set("write", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		for _, x := range xs { fmt.Fprint(in.stdout, luaString(x)) }
		return []Value{true}, nil
	}))
	ioT.Set("read", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		b, _ := io.ReadAll(os.Stdin)
		return []Value{string(b)}, nil
	}))
	g.Local("io", ioT)
	osT := NewTable()
	osT.Set("exit", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		code := 0
		if len(xs)>0 { code = int(toNum(xs[0])) }
		os.Exit(code)
		return nil, nil
	}))
	osT.Set("clock", Native(func(_ *Interp, xs []Value) ([]Value, error) { return []Value{float64(0)}, nil }))
	g.Local("os", osT)
	g.Local("dofile", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		if len(xs)==0 { return nil, errors.New("bad argument #1 to 'dofile' (string expected, got no value)") }
		b, err := os.ReadFile(luaString(xs[0])); if err != nil { return nil, err }
		return nil, in.Run(string(b), luaString(xs[0]))
	}))
	g.Local("loadstring", Native(func(_ *Interp, xs []Value) ([]Value, error) {
		src := luaString(first(xs)); p:=NewParser(src); body,err:=p.Parse(); if err!=nil { return []Value{nil,err.Error()}, nil }
		return []Value{&UserFunc{body:body, env:g}}, nil
	}))
	tableT := NewTable()
	tableT.Set("insert", Native(func(_ *Interp, xs []Value) ([]Value, error) { if t, ok := first(xs).(*Table); ok && len(xs) > 1 { t.Set(float64(t.Len()+1), xs[1]) }; return nil, nil }))
	g.Local("table", tableT)
}

func num1(f func(float64) float64) func(*Interp, []Value) ([]Value, error) {
	return func(_ *Interp, xs []Value) ([]Value, error) { return []Value{f(toNum(first(xs)))}, nil }
}
func first(xs []Value) Value { if len(xs) == 0 { return nil }; return xs[0] }
func at(xs []Value, i int) Value { if i >= len(xs) { return nil }; return xs[i] }

func (in *Interp) Run(src, name string) error {
	p := NewParser(src)
	stmts, err := p.Parse()
	if err != nil {
		return err
	}
	_, err = execBlock(in, in.global, stmts)
	return err
}

type token struct{ typ, lit string }
type Lexer struct{ s string; i int; toks []token }
var keywords = map[string]bool{"and":true,"break":true,"do":true,"else":true,"elseif":true,"end":true,"false":true,"for":true,"function":true,"if":true,"in":true,"local":true,"nil":true,"not":true,"or":true,"repeat":true,"return":true,"then":true,"true":true,"until":true,"while":true}

func lex(s string) ([]token, error) {
	l := &Lexer{s:s}
	for l.i < len(l.s) {
		r := rune(l.s[l.i])
		if unicode.IsSpace(r) { l.i++; continue }
		if strings.HasPrefix(l.s[l.i:], "--") {
			for l.i < len(l.s) && l.s[l.i] != '\n' { l.i++ }
			continue
		}
		if isAlpha(r) || r == '_' {
			j := l.i+1
			for j < len(l.s) && (isAlpha(rune(l.s[j])) || isDigit(rune(l.s[j])) || l.s[j]=='_') { j++ }
			w := l.s[l.i:j]; typ := "ident"; if keywords[w] { typ = w }
			l.toks = append(l.toks, token{typ,w}); l.i=j; continue
		}
		if isDigit(r) || (r=='.' && l.i+1<len(l.s) && isDigit(rune(l.s[l.i+1]))) {
			j := l.i
			if strings.HasPrefix(l.s[j:], "0x") || strings.HasPrefix(l.s[j:], "0X") {
				j += 2; for j < len(l.s) && (isDigit(rune(l.s[j])) || strings.ContainsRune("abcdefABCDEF", rune(l.s[j]))) { j++ }
			} else {
				for j < len(l.s) && (isDigit(rune(l.s[j])) || strings.ContainsRune(".eE+-", rune(l.s[j]))) {
					if (l.s[j]=='+' || l.s[j]=='-') && j > l.i && l.s[j-1] != 'e' && l.s[j-1] != 'E' { break }
					j++
				}
			}
			l.toks = append(l.toks, token{"number", l.s[l.i:j]}); l.i=j; continue
		}
		if r == '"' || r == '\'' {
			q := byte(r); l.i++; var b strings.Builder
			for l.i < len(l.s) && l.s[l.i] != q {
				if l.s[l.i] == '\\' && l.i+1 < len(l.s) {
					l.i++; c := l.s[l.i]
					switch c { case 'n': b.WriteByte('\n'); case 't': b.WriteByte('\t'); case 'r': b.WriteByte('\r'); default: b.WriteByte(c) }
					l.i++; continue
				}
				b.WriteByte(l.s[l.i]); l.i++
			}
			if l.i >= len(l.s) { return nil, errors.New("unfinished string") }
			l.i++; l.toks = append(l.toks, token{"string", b.String()}); continue
		}
		two := ""; if l.i+1 < len(l.s) { two = l.s[l.i:l.i+2] }
		if two == "==" || two == "~=" || two == "<=" || two == ">=" || two == ".." {
			l.toks = append(l.toks, token{two,two}); l.i+=2; continue
		}
		l.toks = append(l.toks, token{string(l.s[l.i]), string(l.s[l.i])}); l.i++
	}
	l.toks = append(l.toks, token{"eof",""})
	return l.toks, nil
}
func isAlpha(r rune) bool { return unicode.IsLetter(r) }
func isDigit(r rune) bool { return r >= '0' && r <= '9' }

type Stmt interface{ stmt() }
type Expr interface{ expr() }
type AssignStmt struct{ lhs []Expr; rhs []Expr; local []string }; func (*AssignStmt) stmt(){}
type CallStmt struct{ call *CallExpr }; func (*CallStmt) stmt(){}
type ForStmt struct{ name string; start,end,step Expr; body []Stmt }; func (*ForStmt) stmt(){}
type ForInStmt struct{ names []string; iter Expr; body []Stmt }; func (*ForInStmt) stmt(){}
type WhileStmt struct{ cond Expr; body []Stmt }; func (*WhileStmt) stmt(){}
type IfStmt struct{ cond Expr; thenB, elseB []Stmt }; func (*IfStmt) stmt(){}
type ReturnStmt struct{ vals []Expr }; func (*ReturnStmt) stmt(){}
type BreakStmt struct{}; func (*BreakStmt) stmt(){}
type DoStmt struct{ body []Stmt }; func (*DoStmt) stmt(){}
type FuncStmt struct{ name Expr; params []string; body []Stmt; localName string }; func (*FuncStmt) stmt(){}
type NameExpr struct{ name string }; func (*NameExpr) expr(){}
type LitExpr struct{ v Value }; func (*LitExpr) expr(){}
type UnaryExpr struct{ op string; x Expr }; func (*UnaryExpr) expr(){}
type BinaryExpr struct{ op string; a,b Expr }; func (*BinaryExpr) expr(){}
type IndexExpr struct{ obj,key Expr }; func (*IndexExpr) expr(){}
type CallExpr struct{ fn Expr; args []Expr }; func (*CallExpr) expr(){}
type TableExpr struct{ vals []Expr; keys []Expr }; func (*TableExpr) expr(){}
type FuncExpr struct{ params []string; body []Stmt }; func (*FuncExpr) expr(){}

type Parser struct{ toks []token; pos int }
func NewParser(s string) *Parser { t, _ := lex(s); return &Parser{toks:t} }
func (p *Parser) peek() token { return p.toks[p.pos] }
func (p *Parser) match(ts ...string) bool { for _, t := range ts { if p.peek().typ == t { p.pos++; return true } }; return false }
func (p *Parser) expect(t string) error { if !p.match(t) { return fmt.Errorf("syntax error near '%s'", p.peek().lit) }; return nil }
func (p *Parser) Parse() ([]Stmt,error) { return p.block("eof") }
func (p *Parser) block(ends ...string) ([]Stmt,error) {
	var out []Stmt
	for {
		for p.match(";") {}
		for _, e := range ends { if p.peek().typ == e { return out,nil } }
		if p.peek().typ == "eof" { return out,nil }
		s, err := p.statement(); if err != nil { return nil,err }
		out = append(out,s)
	}
}
func (p *Parser) statement() (Stmt,error) {
	switch p.peek().typ {
	case "local":
		p.pos++
		if p.match("function") {
			name := p.peek().lit
			if err:=p.expect("ident"); err!=nil { return nil,err }
			params, body, err := p.funcBody()
			if err!=nil { return nil,err }
			return &FuncStmt{localName:name, params:params, body:body}, nil
		}
		names := []string{}
		for { if p.peek().typ!="ident" { return nil, fmt.Errorf("syntax error near '%s'", p.peek().lit) }; names=append(names,p.peek().lit); p.pos++; if !p.match(",") { break } }
		var rhs []Expr; if p.match("=") { rhs = p.exprList() }
		return &AssignStmt{local:names,rhs:rhs}, nil
	case "function":
		p.pos++
		var name Expr = &NameExpr{p.peek().lit}
		if err:=p.expect("ident"); err!=nil { return nil,err }
		for p.match(".") {
			k:=p.peek().lit
			if err:=p.expect("ident"); err!=nil { return nil,err }
			name=&IndexExpr{name,&LitExpr{k}}
		}
		params, body, err := p.funcBody()
		if err!=nil { return nil,err }
		return &FuncStmt{name:name, params:params, body:body}, nil
	case "for":
		p.pos++; names := []string{p.peek().lit}; if err:=p.expect("ident"); err!=nil { return nil,err }
		for p.match(",") { names=append(names,p.peek().lit); if err:=p.expect("ident"); err!=nil { return nil,err } }
		if p.match("in") {
			iter:=p.expr(0); p.expect("do"); body,err:=p.block("end"); if err!=nil { return nil,err }; p.expect("end")
			return &ForInStmt{names:names,iter:iter,body:body},nil
		}
		name := names[0]; if err:=p.expect("="); err!=nil { return nil,err }
		start:=p.expr(0); p.expect(","); end:=p.expr(0); var step Expr=&LitExpr{float64(1)}; if p.match(",") { step=p.expr(0) }
		p.expect("do"); body,err:=p.block("end"); if err!=nil { return nil,err }; p.expect("end")
		return &ForStmt{name:name,start:start,end:end,step:step,body:body},nil
	case "while":
		p.pos++; c:=p.expr(0); p.expect("do"); b,err:=p.block("end"); if err!=nil { return nil,err }; p.expect("end"); return &WhileStmt{cond:c,body:b},nil
	case "if":
		p.pos++; c:=p.expr(0); p.expect("then"); tb,err:=p.block("else","end"); if err!=nil { return nil,err }; var eb []Stmt; if p.match("else") { eb,err=p.block("end"); if err!=nil { return nil,err } }; p.expect("end"); return &IfStmt{cond:c,thenB:tb,elseB:eb},nil
	case "return":
		p.pos++; var xs []Expr; if p.peek().typ!="end" && p.peek().typ!="eof" { xs=p.exprList() }; return &ReturnStmt{xs},nil
	case "break":
		p.pos++; return &BreakStmt{},nil
	case "do":
		p.pos++; b,err:=p.block("end"); if err!=nil { return nil,err }; p.expect("end"); return &DoStmt{b},nil
	}
	e := p.prefix()
	if c, ok := e.(*CallExpr); ok { return &CallStmt{c}, nil }
	lhs := []Expr{e}
	for p.match(",") { lhs = append(lhs, p.prefix()) }
	if err:=p.expect("="); err!=nil { return nil,err }
	return &AssignStmt{lhs:lhs,rhs:p.exprList()}, nil
}
func (p *Parser) funcBody() ([]string, []Stmt, error) {
	if err:=p.expect("("); err!=nil { return nil,nil,err }
	params:=[]string{}
	if !p.match(")") {
		for {
			if p.peek().typ=="..." { p.pos++; break }
			params=append(params,p.peek().lit)
			if err:=p.expect("ident"); err!=nil { return nil,nil,err }
			if !p.match(",") { break }
		}
		if err:=p.expect(")"); err!=nil { return nil,nil,err }
	}
	body,err:=p.block("end"); if err!=nil { return nil,nil,err }
	if err:=p.expect("end"); err!=nil { return nil,nil,err }
	return params,body,nil
}
func (p *Parser) exprList() []Expr { xs:=[]Expr{p.expr(0)}; for p.match(",") { xs=append(xs,p.expr(0)) }; return xs }
var prec = map[string]int{"or":1,"and":2,"==":3,"~=":3,"<":3,">":3,"<=":3,">=":3,"..":4,"+":5,"-":5,"*":6,"/":6,"%":6}
func (p *Parser) expr(min int) Expr {
	var left Expr
	if p.match("-", "not", "#") { op:=p.toks[p.pos-1].typ; left=&UnaryExpr{op,p.expr(7)} } else { left=p.primary() }
	for {
		op:=p.peek().typ; pr:=prec[op]; if pr < min || pr==0 { break }
		p.pos++; next:=pr+1; if op==".." { next=pr }
		left=&BinaryExpr{op,left,p.expr(next)}
	}
	return left
}
func (p *Parser) primary() Expr {
	switch p.peek().typ {
	case "number":
		l:=p.peek().lit; p.pos++; if strings.HasPrefix(l,"0x")||strings.HasPrefix(l,"0X") { n,_:=strconv.ParseInt(l[2:],16,64); return &LitExpr{float64(n)} }; n,_:=strconv.ParseFloat(l,64); return &LitExpr{n}
	case "string": v:=p.peek().lit; p.pos++; return &LitExpr{v}
	case "nil": p.pos++; return &LitExpr{nil}
	case "true": p.pos++; return &LitExpr{true}
	case "false": p.pos++; return &LitExpr{false}
		case "{":
			p.pos++; t:=&TableExpr{}; idx:=0
		for !p.match("}") {
			var k Expr
			if p.match("[") { k=p.expr(0); p.expect("]"); p.expect("=") } else if p.peek().typ=="ident" && p.toks[p.pos+1].typ=="=" { k=&LitExpr{p.peek().lit}; p.pos++; p.expect("=") } else { idx++; k=&LitExpr{float64(idx)} }
			t.keys=append(t.keys,k); t.vals=append(t.vals,p.expr(0)); p.match(",",";")
			}
			return t
		case "function":
			p.pos++
			params, body, err := p.funcBody()
			if err != nil { return &LitExpr{nil} }
			return &FuncExpr{params:params, body:body}
	case "(":
		p.pos++; e:=p.expr(0); p.expect(")"); return p.suffix(e)
	default:
		return p.prefix()
	}
}
func (p *Parser) prefix() Expr {
	var e Expr
	if p.match("(") { e=p.expr(0); p.expect(")") } else { name:=p.peek().lit; p.expect("ident"); e=&NameExpr{name} }
	return p.suffix(e)
}
func (p *Parser) suffix(e Expr) Expr {
	for {
		if p.match(".") { k:=p.peek().lit; p.expect("ident"); e=&IndexExpr{e,&LitExpr{k}}; continue }
		if p.match("[") { k:=p.expr(0); p.expect("]"); e=&IndexExpr{e,k}; continue }
		if p.match(":") {
			self := e
			k:=p.peek().lit; p.expect("ident")
			fn := &IndexExpr{self,&LitExpr{k}}
			if p.match("(") { var as []Expr; if !p.match(")") { as=p.exprList(); p.expect(")") }; e=&CallExpr{fn,append([]Expr{self},as...)} } else { e=fn }
			continue
		}
		if p.match("(") { var as []Expr; if !p.match(")") { as=p.exprList(); p.expect(")") }; e=&CallExpr{e,as}; continue }
		if p.peek().typ=="string" { s:=p.peek().lit; p.pos++; e=&CallExpr{e,[]Expr{&LitExpr{s}}}; continue }
		break
	}
	return e
}

type flow struct{ kind string; vals []Value }
func execBlock(in *Interp, env *Env, ss []Stmt) (*flow,error) {
	for _, s := range ss {
		f,err:=execStmt(in,env,s); if err!=nil || f!=nil { return f,err }
	}
	return nil,nil
}
func execStmt(in *Interp, env *Env, s Stmt) (*flow,error) {
	switch st:=s.(type) {
	case *AssignStmt:
		vals:=evalList(in,env,st.rhs)
		if st.local!=nil { for i,n:=range st.local { env.Local(n, valAt(vals,i)) }; return nil,nil }
		for i,l:=range st.lhs { setLValue(in,env,l,valAt(vals,i)) }
	case *CallStmt:
		_,err:=eval(in,env,st.call); return nil,err
	case *ForStmt:
		start,end,step:=toNum(must(eval(in,env,st.start))),toNum(must(eval(in,env,st.end))),toNum(must(eval(in,env,st.step)))
		for i:=start; (step>=0 && i<=end) || (step<0 && i>=end); i+=step {
			env.Local(st.name,i); f,err:=execBlock(in,env,st.body); if err!=nil { return nil,err }; if f!=nil { if f.kind=="break" { break }; return f,nil }
		}
	case *ForInStmt:
		iv,err:=eval(in,env,st.iter); if err!=nil { return nil,err }
		if it,ok:=iv.(*Iterator); ok {
			for it.pos < len(it.keys) {
				k:=it.keys[it.pos]; it.pos++
				vals:=[]Value{k,nil}
				if it.table!=nil { vals[1]=it.table.Get(k) }
				for i,n:=range st.names { env.Local(n,valAt(vals,i)) }
				f,err:=execBlock(in,env,st.body); if err!=nil { return nil,err }; if f!=nil { if f.kind=="break" { break }; return f,nil }
			}
		}
	case *WhileStmt:
		for truth(must(eval(in,env,st.cond))) { f,err:=execBlock(in,env,st.body); if err!=nil { return nil,err }; if f!=nil { if f.kind=="break" { break }; return f,nil } }
	case *IfStmt:
		if truth(must(eval(in,env,st.cond))) { return execBlock(in,NewEnv(env),st.thenB) }; return execBlock(in,NewEnv(env),st.elseB)
	case *ReturnStmt:
		return &flow{"return",evalList(in,env,st.vals)},nil
	case *BreakStmt:
		return &flow{kind:"break"},nil
	case *DoStmt:
		return execBlock(in,NewEnv(env),st.body)
	case *FuncStmt:
		fn := &UserFunc{params:st.params, body:st.body, env:env}
		if st.localName != "" { env.Local(st.localName, fn) } else { setLValue(in,env,st.name,fn) }
	}
	return nil,nil
}
func must(v Value,e error) Value { return v }
func valAt(xs []Value,i int) Value { if i>=len(xs){return nil}; return xs[i] }
func evalList(in *Interp, env *Env, es []Expr) []Value { out:=[]Value{}; for _,e:=range es { v,err:=eval(in,env,e); if err!=nil { return append(out,nil) }; out=append(out,v) }; return out }
func setLValue(in *Interp, env *Env, e Expr, v Value) {
	switch x:=e.(type) {
	case *NameExpr: env.Set(x.name,v)
	case *IndexExpr: if t,ok:=must(eval(in,env,x.obj)).(*Table); ok { t.Set(must(eval(in,env,x.key)),v) }
	}
}
func eval(in *Interp, env *Env, e Expr) (Value,error) {
	switch x:=e.(type) {
	case *NameExpr: return env.Get(x.name),nil
	case *LitExpr: return x.v,nil
	case *UnaryExpr:
		v,err:=eval(in,env,x.x); if err!=nil { return nil,err }
		switch x.op { case "-": return -toNum(v),nil; case "not": return !truth(v),nil; case "#": if s,ok:=v.(string); ok { return float64(len(s)),nil }; if t,ok:=v.(*Table); ok { return float64(t.Len()),nil } }
	case *BinaryExpr:
		if x.op=="and" { a,_:=eval(in,env,x.a); if !truth(a) { return a,nil }; return eval(in,env,x.b) }
		if x.op=="or" { a,_:=eval(in,env,x.a); if truth(a) { return a,nil }; return eval(in,env,x.b) }
		a,err:=eval(in,env,x.a); if err!=nil { return nil,err }; b,err:=eval(in,env,x.b); if err!=nil { return nil,err }
		switch x.op {
		case "+": return toNum(a)+toNum(b),nil; case "-": return toNum(a)-toNum(b),nil; case "*": return toNum(a)*toNum(b),nil
		case "/": return toNum(a)/toNum(b),nil; case "%": return math.Mod(toNum(a),toNum(b)),nil; case "..": return luaString(a)+luaString(b),nil
		case "==": return equal(a,b),nil; case "~=": return !equal(a,b),nil; case "<": return cmp(a,b)<0,nil; case ">": return cmp(a,b)>0,nil; case "<=": return cmp(a,b)<=0,nil; case ">=": return cmp(a,b)>=0,nil
		}
	case *IndexExpr:
		o,err:=eval(in,env,x.obj); if err!=nil { return nil,err }; k,err:=eval(in,env,x.key); if err!=nil { return nil,err }
		if t,ok:=o.(*Table); ok { return t.Get(k),nil }
		if _,ok:=o.(string); ok { if st,ok:=env.Get("string").(*Table); ok { return st.Get(k),nil } }
		return nil,nil
	case *CallExpr:
		fn,err:=eval(in,env,x.fn); if err!=nil { return nil,err }; args:=evalList(in,env,x.args)
		if f,ok:=fn.(Native); ok { vs,err:=f(in,args); if len(vs)==0 { return nil,err }; return vs[0],err }
		if f,ok:=fn.(*UserFunc); ok {
			callEnv:=NewEnv(f.env)
			for i,p:=range f.params { callEnv.Local(p,valAt(args,i)) }
			fl,err:=execBlock(in,callEnv,f.body); if err!=nil { return nil,err }
			if fl!=nil && len(fl.vals)>0 { return fl.vals[0],nil }
			return nil,nil
		}
		return nil,fmt.Errorf("attempt to call a %s value", typeName(fn))
	case *TableExpr:
		t:=NewTable(); for i,kx:=range x.keys { k,_:=eval(in,env,kx); v,_:=eval(in,env,x.vals[i]); t.Set(k,v) }; return t,nil
	case *FuncExpr:
		return &UserFunc{params:x.params, body:x.body, env:env}, nil
	}
	return nil,nil
}
func truth(v Value) bool { if v==nil { return false }; if b,ok:=v.(bool); ok { return b }; return true }
func equal(a,b Value) bool { switch x:=a.(type){case float64: return x==toNum(b); case string: y,ok:=b.(string); return ok&&x==y; case bool: y,ok:=b.(bool); return ok&&x==y; default: return a==b} }
func cmp(a,b Value) int { if as,aok:=a.(string); aok { bs:=luaString(b); return strings.Compare(as,bs) }; an,bn:=toNum(a),toNum(b); if an<bn{return -1}; if an>bn{return 1}; return 0 }
func toNum(v Value) float64 { switch x:=v.(type){case float64:return x; case int:return float64(x); case string:n,_:=strconv.ParseFloat(strings.TrimSpace(x),64); return n; default:return 0} }
func luaString(v Value) string {
	switch x:=v.(type) {
	case nil: return "nil"
	case string: return x
	case bool: if x { return "true" }; return "false"
	case float64:
		if math.IsInf(x,1) { return "inf" }; if math.IsInf(x,-1) { return "-inf" }
		if math.Trunc(x)==x { return strconv.FormatInt(int64(x),10) }
		return strconv.FormatFloat(x,'g',-1,64)
	case *Table: return "table: 0x1"
	case Native, *UserFunc: return "function: 0x1"
	default: return fmt.Sprint(x)
	}
}
func typeName(v Value) string { if v==nil { return "nil" }; switch v.(type){case float64:return "number"; case string:return "string"; case bool:return "boolean"; case *Table:return "table"; case Native,*UserFunc:return "function"}; return "userdata" }

func usage(w io.Writer, prog string) {
	fmt.Fprintf(w, "usage: %s [options]... [script [args]...].\nAvailable options are:\n  -e chunk  Execute string 'chunk'.\n  -l name   Require library 'name'.\n  -b ...    Save or list bytecode.\n  -j cmd    Perform LuaJIT control command.\n  -O[opt]   Control LuaJIT optimizations.\n  -i        Enter interactive mode after executing 'script'.\n  -v        Show version information.\n  -E        Ignore environment variables.\n  --        Stop handling options.\n  -         Execute stdin and stop handling options.\n", prog)
}

func main() {
	prog := os.Args[0]
	args := os.Args[1:]
	chunks := []string{}
	libs := []string{}
	interactive := false
	showV := false
	var script string
	var scriptArgs []string
	for i:=0;i<len(args);i++ {
		a:=args[i]
		if a=="--" { if i+1<len(args){ script=args[i+1]; scriptArgs=args[i+2:] }; break }
		if a=="-" { b,_:=io.ReadAll(os.Stdin); chunks=append(chunks,string(b)); scriptArgs=args[i+1:]; break }
		if !strings.HasPrefix(a,"-") || a=="-" { script=a; scriptArgs=args[i+1:]; break }
		switch {
		case a=="--help": usage(os.Stdout,prog); return
		case a=="-v": showV=true
		case a=="-i": interactive=true
		case a=="-E": // ignored
		case a=="-e":
			if i+1>=len(args){ fmt.Fprintf(os.Stderr,"%s: '-e' needs argument\n",prog); os.Exit(1)}; i++; chunks=append(chunks,args[i])
		case strings.HasPrefix(a,"-e") && len(a)>2:
			chunks=append(chunks,a[2:])
		case a=="-l":
			if i+1>=len(args){ fmt.Fprintf(os.Stderr,"%s: '-l' needs argument\n",prog); os.Exit(1)}; i++; libs=append(libs,args[i])
		case strings.HasPrefix(a,"-l") && len(a)>2:
			libs=append(libs,a[2:])
		case strings.HasPrefix(a,"-j"):
			fmt.Fprintf(os.Stderr,"%s: unknown luaJIT command or jit.* modules not installed\n",prog); os.Exit(1)
		case strings.HasPrefix(a,"-O"):
			if len(a)>2 && a[2:]=="help" { fmt.Fprintf(os.Stderr,"%s: unknown or malformed optimization flag 'help'\n",prog); os.Exit(1) }
		case a=="-b" || strings.HasPrefix(a,"-b"):
			fmt.Fprintf(os.Stderr,"%s: unknown luaJIT command or jit.* modules not installed\n",prog); os.Exit(1)
		default:
			usage(os.Stderr,prog); os.Exit(1)
		}
	}
	if showV { fmt.Fprintln(os.Stdout, versionLine) }
	arg0 := script
	if arg0=="" && len(scriptArgs)>0 { arg0=scriptArgs[0] }
	fullArgs := append([]string{arg0}, scriptArgs...)
	in := NewInterp(prog, fullArgs)
	for _, l := range libs { if _,err:=eval(in,in.global,&CallExpr{&NameExpr{"require"},[]Expr{&LitExpr{l}}}); err!=nil { fail(prog,err) } }
	for _, c := range chunks { if err:=in.Run(c,"=(command line)"); err!=nil { fail(prog,err) } }
	if script!="" {
		b,err:=os.ReadFile(script); if err!=nil { fmt.Fprintf(os.Stderr,"%s: cannot open %s: %s\n",prog,script,err.Error()); os.Exit(1) }
		if err:=in.Run(string(b),script); err!=nil { fail(prog,err) }
	} else if len(chunks)==0 && !showV {
		interactive = true
	}
	if interactive {
		if len(chunks)==0 && script=="" { fmt.Fprintln(os.Stdout, versionLine) }
		repl(in)
	}
}
func fail(prog string, err error) { fmt.Fprintf(os.Stderr,"%s: %s\n", prog, err.Error()); os.Exit(1) }
func repl(in *Interp) {
	sc := bufio.NewScanner(os.Stdin)
	for {
		fmt.Fprint(os.Stdout, "> ")
		if !sc.Scan() { break }
		line := sc.Text()
		if strings.HasPrefix(strings.TrimSpace(line), "=") { line = "print(" + strings.TrimSpace(line)[1:] + ")" }
		if err:=in.Run(line,"stdin"); err!=nil { fmt.Fprintln(os.Stderr, err.Error()) }
	}
}
