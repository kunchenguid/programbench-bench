package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
)

const version = "0.21.1"

type Options struct {
	jsonInput   bool
	jsonOutput  bool
	bytesFormat string
	dedupe      bool
	topDown     bool
	alignRight  bool
	quantity    string
	maxDepth    int
	minRatio    float64
	noSort      bool
	silent      bool
	progress    bool
	omitDetails bool
	omitSummary bool
	totalWidth  int
	treeWidth   int
	barWidth    int
	files       []string
}

type Node struct {
	Name     string  `json:"name"`
	Size     int64   `json:"size"`
	Children []*Node `json:"children"`
	path     string
	key      inodeKey
	base     int64
}

type JSONDoc struct {
	SchemaVersion string  `json:"schema-version"`
	PDU           string  `json:"pdu"`
	Unit          string  `json:"unit"`
	Tree          *Node   `json:"tree"`
	Shared        *Shared `json:"shared,omitempty"`
}

type Shared struct {
	Details []SharedDetail `json:"details,omitempty"`
	Summary *SharedSummary `json:"summary,omitempty"`
}

type SharedDetail struct {
	Ino   uint64   `json:"ino"`
	Size  int64    `json:"size"`
	Links uint64   `json:"links"`
	Paths []string `json:"paths"`
}

type SharedSummary struct {
	Inodes              int   `json:"inodes"`
	ExclusiveInodes     int   `json:"exclusive_inodes"`
	AllLinks            int   `json:"all_links"`
	DetectedLinks       int   `json:"detected_links"`
	ExclusiveLinks      int   `json:"exclusive_links"`
	SharedSize          int64 `json:"shared_size"`
	ExclusiveSharedSize int64 `json:"exclusive_shared_size"`
}

type inodeKey struct {
	Dev uint64
	Ino uint64
}
type seenInfo struct {
	size    int64
	links   uint64
	paths   []string
	counted bool
}

func defaultOptions() Options {
	return Options{bytesFormat: "metric", quantity: "block-size", maxDepth: 10, minRatio: 0.01, totalWidth: 120, treeWidth: 0, barWidth: 0}
}

func help(long bool) string {
	if !long {
		return "Summarize disk usage of the set of files, recursively for directories.\n\nUsage: executable [OPTIONS] [FILES]...\n\nArguments:\n  [FILES]...  List of files and/or directories\n\nOptions:\n      --json-input\n          Read JSON data from stdin\n      --json-output\n          Print JSON data instead of an ASCII chart\n  -b, --bytes-format <BYTES_FORMAT>\n          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]\n  -H, --deduplicate-hardlinks\n          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]\n      --top-down\n          Print the tree top-down instead of bottom-up\n      --align-right\n          Set the root of the bars to the right\n  -q, --quantity <QUANTITY>\n          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]\n  -d, --max-depth <MAX_DEPTH>\n          Maximum depth to display the data. Could be either \"inf\" or a positive integer [default: 10] [aliases: --depth]\n  -w, --total-width <TOTAL_WIDTH>\n          Width of the visualization [aliases: --width]\n      --column-width <TREE_WIDTH> <BAR_WIDTH>\n          Maximum widths of the tree column and width of the bar column\n  -m, --min-ratio <MIN_RATIO>\n          Minimal size proportion required to appear [default: 0.01]\n      --no-sort\n          Do not sort the branches in the tree\n  -s, --silent-errors\n          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]\n  -p, --progress\n          Report progress being made at the expense of performance\n      --threads <THREADS>\n          Set the maximum number of threads to spawn. Could be either \"auto\", \"max\", or a positive integer [default: auto]\n      --omit-json-shared-details\n          Do not output `.shared.details` in the JSON output\n      --omit-json-shared-summary\n          Do not output `.shared.summary` in the JSON output\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n"
	}
	return "Summarize disk usage of the set of files, recursively for directories.\n\nCopyright: Apache-2.0 © 2021 Hoàng Văn Khải <https://github.com/KSXGitHub/>\nSponsor: https://github.com/sponsors/KSXGitHub\n\nUsage: executable [OPTIONS] [FILES]...\n\nArguments:\n  [FILES]...\n          List of files and/or directories\n\nOptions:\n      --json-input\n          Read JSON data from stdin\n\n      --json-output\n          Print JSON data instead of an ASCII chart\n\n  -b, --bytes-format <BYTES_FORMAT>\n          How to display the numbers of bytes\n\n          Possible values:\n          - plain:  Display plain number of bytes without units\n          - metric: Use metric scale, i.e. 1K = 1000B, 1M = 1000K, and so on\n          - binary: Use binary scale, i.e. 1K = 1024B, 1M = 1024K, and so on\n          \n          [default: metric]\n\n  -H, --deduplicate-hardlinks\n          Detect and subtract the sizes of hardlinks from their parent directory totals\n          \n          [aliases: --detect-links, --dedupe-links]\n\n      --top-down\n          Print the tree top-down instead of bottom-up\n\n      --align-right\n          Set the root of the bars to the right\n\n  -q, --quantity <QUANTITY>\n          Aspect of the files/directories to be measured\n\n          Possible values:\n          - apparent-size: Measure apparent sizes\n          - block-size:    Measure block sizes (block-count * 512B)\n          - block-count:   Count numbers of blocks\n          \n          [default: block-size]\n\n  -d, --max-depth <MAX_DEPTH>\n          Maximum depth to display the data. Could be either \"inf\" or a positive integer\n          \n          [default: 10]\n          [aliases: --depth]\n\n  -w, --total-width <TOTAL_WIDTH>\n          Width of the visualization\n          \n          [aliases: --width]\n\n      --column-width <TREE_WIDTH> <BAR_WIDTH>\n          Maximum widths of the tree column and width of the bar column\n\n  -m, --min-ratio <MIN_RATIO>\n          Minimal size proportion required to appear\n          \n          [default: 0.01]\n\n      --no-sort\n          Do not sort the branches in the tree\n\n  -s, --silent-errors\n          Prevent filesystem error messages from appearing in stderr\n          \n          [aliases: --no-errors]\n\n  -p, --progress\n          Report progress being made at the expense of performance\n\n      --threads <THREADS>\n          Set the maximum number of threads to spawn. Could be either \"auto\", \"max\", or a positive integer\n          \n          [default: auto]\n\n      --omit-json-shared-details\n          Do not output `.shared.details` in the JSON output\n\n      --omit-json-shared-summary\n          Do not output `.shared.summary` in the JSON output\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nExamples:\n    Show disk usage chart of current working directory\n    $ pdu\n\n    Show disk usage chart of a single file or directory\n    $ pdu path/to/file/or/directory\n\n    Compare disk usages of multiple files and/or directories\n    $ pdu file.txt dir/\n\n    Show chart in apparent sizes instead of block sizes\n    $ pdu --quantity=apparent-size\n\n    Detect and subtract the sizes of hardlinks from their parent nodes\n    $ pdu --deduplicate-hardlinks\n\n    Show sizes in plain numbers instead of metric units\n    $ pdu --bytes-format=plain\n\n    Show sizes in base 2¹⁰ units (binary) instead of base 10³ units (metric)\n    $ pdu --bytes-format=binary\n\n    Show disk usage chart of all entries regardless of size\n    $ pdu --min-ratio=0\n\n    Only show disk usage chart of entries whose size is at least 5% of total\n    $ pdu --min-ratio=0.05\n\n    Show disk usage data as JSON instead of chart\n    $ pdu --min-ratio=0 --max-depth=inf --json-output | jq\n\n    Visualize existing JSON representation of disk usage data\n    $ pdu --json-input < disk-usage.json\n"
}

func parseArgs(args []string) (Options, bool, error) {
	opt := defaultOptions()
	for i := 0; i < len(args); i++ {
		a := args[i]
		val := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("a value is required for '%s'", a)
			}
			i++
			return args[i], nil
		}
		switch {
		case a == "-h":
			fmt.Print(help(false))
			return opt, true, nil
		case a == "--help":
			fmt.Print(help(true))
			return opt, true, nil
		case a == "-V" || a == "--version":
			fmt.Println("pdu " + version)
			return opt, true, nil
		case a == "--json-input":
			opt.jsonInput = true
		case a == "--json-output":
			opt.jsonOutput = true
		case a == "-H" || a == "--deduplicate-hardlinks" || a == "--detect-links" || a == "--dedupe-links":
			opt.dedupe = true
		case a == "--top-down":
			opt.topDown = true
		case a == "--align-right":
			opt.alignRight = true
		case a == "--no-sort":
			opt.noSort = true
		case a == "-s" || a == "--silent-errors" || a == "--no-errors":
			opt.silent = true
		case a == "-p" || a == "--progress":
			opt.progress = true
		case a == "--omit-json-shared-details":
			opt.omitDetails = true
		case a == "--omit-json-shared-summary":
			opt.omitSummary = true
		case a == "-b" || a == "--bytes-format":
			v, e := val()
			if e != nil {
				return opt, false, e
			}
			opt.bytesFormat = v
		case strings.HasPrefix(a, "--bytes-format="):
			opt.bytesFormat = strings.TrimPrefix(a, "--bytes-format=")
		case a == "-q" || a == "--quantity":
			v, e := val()
			if e != nil {
				return opt, false, e
			}
			opt.quantity = v
		case strings.HasPrefix(a, "--quantity="):
			opt.quantity = strings.TrimPrefix(a, "--quantity=")
		case a == "-d" || a == "--max-depth" || a == "--depth":
			v, e := val()
			if e != nil {
				return opt, false, e
			}
			if err := parseDepth(v, &opt); err != nil {
				return opt, false, err
			}
		case strings.HasPrefix(a, "--max-depth="):
			if err := parseDepth(strings.TrimPrefix(a, "--max-depth="), &opt); err != nil {
				return opt, false, err
			}
		case strings.HasPrefix(a, "--depth="):
			if err := parseDepth(strings.TrimPrefix(a, "--depth="), &opt); err != nil {
				return opt, false, err
			}
		case a == "-m" || a == "--min-ratio":
			v, e := val()
			if e != nil {
				return opt, false, e
			}
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				return opt, false, err
			}
			opt.minRatio = f
		case strings.HasPrefix(a, "--min-ratio="):
			f, err := strconv.ParseFloat(strings.TrimPrefix(a, "--min-ratio="), 64)
			if err != nil {
				return opt, false, err
			}
			opt.minRatio = f
		case a == "-w" || a == "--total-width" || a == "--width":
			v, e := val()
			if e != nil {
				return opt, false, e
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return opt, false, err
			}
			opt.totalWidth = n
		case strings.HasPrefix(a, "--total-width="):
			n, err := strconv.Atoi(strings.TrimPrefix(a, "--total-width="))
			if err != nil {
				return opt, false, err
			}
			opt.totalWidth = n
		case strings.HasPrefix(a, "--width="):
			n, err := strconv.Atoi(strings.TrimPrefix(a, "--width="))
			if err != nil {
				return opt, false, err
			}
			opt.totalWidth = n
		case a == "--column-width":
			v, e := val()
			if e != nil {
				return opt, false, e
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return opt, false, err
			}
			opt.treeWidth = n
			v, e = val()
			if e != nil {
				return opt, false, e
			}
			n, err = strconv.Atoi(v)
			if err != nil {
				return opt, false, err
			}
			opt.barWidth = n
		case a == "--threads":
			_, e := val()
			if e != nil {
				return opt, false, e
			}
		case strings.HasPrefix(a, "--threads="):
		case strings.HasPrefix(a, "-"):
			return opt, false, fmt.Errorf("unexpected argument '%s' found", a)
		default:
			opt.files = append(opt.files, a)
		}
	}
	if opt.omitDetails && !opt.dedupe {
		return opt, false, errors.New("the following required arguments were not provided:\n  --deduplicate-hardlinks")
	}
	if opt.omitSummary && !opt.dedupe {
		return opt, false, errors.New("the following required arguments were not provided:\n  --deduplicate-hardlinks")
	}
	if opt.bytesFormat != "plain" && opt.bytesFormat != "metric" && opt.bytesFormat != "binary" {
		return opt, false, fmt.Errorf("invalid value '%s' for '--bytes-format <BYTES_FORMAT>'", opt.bytesFormat)
	}
	if opt.quantity != "apparent-size" && opt.quantity != "block-size" && opt.quantity != "block-count" {
		return opt, false, fmt.Errorf("invalid value '%s' for '--quantity <QUANTITY>'", opt.quantity)
	}
	if len(opt.files) == 0 {
		opt.files = []string{"."}
	}
	return opt, false, nil
}

func parseDepth(s string, opt *Options) error {
	if s == "inf" {
		opt.maxDepth = 1 << 30
		return nil
	}
	n, err := strconv.Atoi(s)
	if err != nil {
		return err
	}
	opt.maxDepth = n
	return nil
}

func usageErr(err error) {
	fmt.Fprintf(os.Stderr, "error: %v\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'.\n", err)
}

func main() {
	opt, done, err := parseArgs(os.Args[1:])
	if done {
		return
	}
	if err != nil {
		usageErr(err)
		os.Exit(2)
	}
	var doc JSONDoc
	if opt.jsonInput {
		data, err := io.ReadAll(os.Stdin)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if err := json.Unmarshal(data, &doc); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		if doc.Tree == nil {
			fmt.Fprintln(os.Stderr, "missing tree")
			os.Exit(1)
		}
		prune(doc.Tree, doc.Tree.Size, 0, opt)
	} else {
		seen := map[inodeKey]*seenInfo{}
		roots := make([]*Node, 0, len(opt.files))
		for _, p := range opt.files {
			if n := scan(p, opt, seen); n != nil {
				roots = append(roots, n)
			}
		}
		var root *Node
		if len(roots) == 1 {
			root = roots[0]
		} else {
			root = &Node{Name: "(total)", Children: roots}
			for _, c := range roots {
				root.Size += c.Size
			}
		}
		if !opt.noSort {
			sortTree(root)
		}
		prune(root, root.Size, 0, opt)
		unit := "bytes"
		if opt.quantity == "block-count" {
			unit = "blocks"
		}
		doc = JSONDoc{SchemaVersion: "2024-11-02", PDU: version, Unit: unit, Tree: root}
		if opt.dedupe {
			doc.Shared = makeShared(seen, opt)
		}
	}
	if opt.jsonOutput {
		b, _ := json.Marshal(doc)
		fmt.Println(string(b))
		return
	}
	render(doc.Tree, opt)
	if opt.dedupe && doc.Shared != nil && doc.Shared.Summary != nil {
		printShared(doc.Shared.Summary)
	}
}

func scan(path string, opt Options, seen map[inodeKey]*seenInfo) *Node {
	info, err := os.Lstat(path)
	if err != nil {
		if !opt.silent {
			fmt.Fprintf(os.Stderr, "[error] symlink_metadata %q: %v\n", path, err)
		}
		return &Node{Name: path, Size: 0, Children: []*Node{}}
	}
	st := info.Sys().(*syscall.Stat_t)
	base := measure(st, opt)
	key := inodeKey{Dev: uint64(st.Dev), Ino: uint64(st.Ino)}
	name := path
	if strings.TrimRight(path, "/") != "." {
		name = filepath.Base(strings.TrimRight(path, "/"))
		if filepath.IsAbs(path) {
			name = path
		}
	}
	n := &Node{Name: name, path: path, key: key, base: base, Size: base, Children: []*Node{}}
	isHard := st.Nlink > 1 && !info.IsDir()
	if isHard {
		si := seen[key]
		if si == nil {
			si = &seenInfo{size: base, links: uint64(st.Nlink)}
			seen[key] = si
		}
		si.paths = append(si.paths, path)
		if opt.dedupe && si.counted {
			n.Size = base
		} else {
			si.counted = true
		}
	}
	if info.IsDir() {
		entries, err := os.ReadDir(path)
		if err != nil {
			if !opt.silent {
				fmt.Fprintf(os.Stderr, "[error] read_dir %q: %v\n", path, err)
			}
			return n
		}
		sum := base
		for _, e := range entries {
			child := scan(filepath.Join(path, e.Name()), opt, seen)
			if child != nil {
				child.Name = e.Name()
				n.Children = append(n.Children, child)
				if opt.dedupe && childIsDuplicateRoot(child, seen) {
				}
				sum += effectiveSize(child, opt, seen)
			}
		}
		n.Size = sum
	}
	return n
}

func childIsDuplicateRoot(n *Node, seen map[inodeKey]*seenInfo) bool { return false }
func effectiveSize(n *Node, opt Options, seen map[inodeKey]*seenInfo) int64 {
	if !opt.dedupe {
		return n.Size
	}
	if len(n.Children) == 0 {
		if si := seen[n.key]; si != nil && len(si.paths) > 1 {
			return 0
		}
		return n.Size
	}
	return n.Size
}

func measure(st *syscall.Stat_t, opt Options) int64 {
	switch opt.quantity {
	case "apparent-size":
		return st.Size
	case "block-count":
		return st.Blocks
	default:
		return st.Blocks * 512
	}
}

func sortTree(n *Node) {
	sort.SliceStable(n.Children, func(i, j int) bool {
		if n.Children[i].Size == n.Children[j].Size {
			return n.Children[i].Name > n.Children[j].Name
		}
		return n.Children[i].Size > n.Children[j].Size
	})
	for _, c := range n.Children {
		sortTree(c)
	}
}

func prune(n *Node, total int64, depth int, opt Options) {
	kept := n.Children[:0]
	for _, c := range n.Children {
		if depth+1 < opt.maxDepth && (total == 0 || float64(c.Size)/float64(total) >= opt.minRatio) {
			prune(c, total, depth+1, opt)
			kept = append(kept, c)
		}
	}
	n.Children = kept
}

func makeShared(seen map[inodeKey]*seenInfo, opt Options) *Shared {
	s := &Shared{}
	sum := &SharedSummary{}
	for k, si := range seen {
		if len(si.paths) > 1 {
			sort.Strings(si.paths)
			d := SharedDetail{Ino: k.Ino, Size: si.size, Links: si.links, Paths: si.paths}
			s.Details = append(s.Details, d)
			sum.Inodes++
			sum.ExclusiveInodes++
			sum.AllLinks += int(si.links)
			sum.DetectedLinks += len(si.paths)
			sum.ExclusiveLinks += len(si.paths)
			sum.SharedSize += si.size
			sum.ExclusiveSharedSize += si.size
		}
	}
	sort.Slice(s.Details, func(i, j int) bool { return s.Details[i].Ino < s.Details[j].Ino })
	if !opt.omitSummary {
		s.Summary = sum
	}
	if opt.omitDetails {
		s.Details = nil
	}
	if opt.omitDetails && opt.omitSummary {
		return nil
	}
	return s
}

func render(root *Node, opt Options) {
	lines := []*Node{}
	var walk func(*Node)
	walk = func(n *Node) {
		if opt.topDown {
			lines = append(lines, n)
		}
		for _, c := range n.Children {
			walk(c)
		}
		if !opt.topDown {
			lines = append(lines, n)
		}
	}
	walk(root)
	maxSize := 0
	maxName := 0
	for _, n := range lines {
		fs := formatSize(n.Size, opt)
		if len(fs) > maxSize {
			maxSize = len(fs)
		}
		if len(n.Name) > maxName {
			maxName = len(n.Name)
		}
	}
	if opt.treeWidth > 0 && maxName > opt.treeWidth {
		maxName = opt.treeWidth
	}
	barw := 60
	if opt.barWidth > 0 {
		barw = opt.barWidth
	} else if opt.totalWidth > 40 {
		barw = opt.totalWidth - maxSize - maxName - 12
		if barw < 10 {
			barw = 10
		}
		if barw > 119 {
			barw = 119
		}
	}
	for _, n := range lines {
		ratio := 0.0
		if root.Size > 0 {
			ratio = float64(n.Size) / float64(root.Size)
		}
		pct := int(math.Round(ratio * 100))
		filled := int(math.Round(ratio * float64(barw)))
		if filled < 0 {
			filled = 0
		}
		if filled > barw {
			filled = barw
		}
		bar := strings.Repeat("█", filled) + strings.Repeat("░", barw-filled)
		name := n.Name
		if len(name) > maxName {
			name = name[:maxName]
		}
		fmt.Printf("%*s ┌──%-*s│%s│%3d%%\n", maxSize, formatSize(n.Size, opt), maxName, name, bar, pct)
	}
}

func formatSize(v int64, opt Options) string {
	if opt.bytesFormat == "plain" || opt.quantity == "block-count" {
		return strconv.FormatInt(v, 10)
	}
	base := 1000.0
	if opt.bytesFormat == "binary" {
		base = 1024
	}
	units := []string{"", "K", "M", "G", "T", "P"}
	x := float64(v)
	u := 0
	for x >= base && u < len(units)-1 {
		x /= base
		u++
	}
	if u == 0 {
		return strconv.FormatInt(v, 10)
	}
	return fmt.Sprintf("%.1f%s", x, units[u])
}

func printShared(s *SharedSummary) {
	if s.Inodes == 0 {
		fmt.Println("No hardlinks detected")
		return
	}
	fmt.Println("Hardlinks detected! No files have links outside this tree")
	fmt.Printf("* Number of shared inodes: %d\n", s.Inodes)
	fmt.Printf("* Total number of links: %d\n", s.AllLinks)
	fmt.Printf("* Total shared size: %d\n", s.SharedSize)
}

func init() { _ = bufio.ErrInvalidUnreadByte }
