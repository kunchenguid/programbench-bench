module pdu-reimpl

go 1.21
