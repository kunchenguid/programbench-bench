package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/printer"
	"go/token"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type options struct {
	all, exported, named, noSub, parallel, write, inputs, useCmp, ai      bool
	only, excl, template, templateDir, templateParams, templateParamsFile string
	aiEndpoint, aiModel                                                   string
	aiMin, aiMax                                                          int
}

type param struct {
	name     string
	typ      string
	variadic bool
}

type result struct {
	name  string
	typ   string
	isErr bool
}

type fnInfo struct {
	name, testName                            string
	params                                    []param
	results                                   []result
	recvName, recvType, recvBase, recvDisplay string
	isMethod, generic                         bool
	typeArgs                                  []string
}

func main() {
	var opt options
	flag.BoolVar(&opt.ai, "ai", false, "generate test cases using AI (requires Ollama)")
	flag.StringVar(&opt.aiEndpoint, "ai-endpoint", "http://localhost:11434", "Ollama API endpoint")
	flag.IntVar(&opt.aiMax, "ai-max-cases", 10, "maximum number of test cases to generate with AI")
	flag.IntVar(&opt.aiMin, "ai-min-cases", 3, "minimum number of test cases to generate with AI")
	flag.StringVar(&opt.aiModel, "ai-model", "qwen2.5-coder:0.5b", "AI model to use for test generation")
	flag.BoolVar(&opt.all, "all", false, "generate tests for all functions and methods")
	flag.StringVar(&opt.excl, "excl", "", "regexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all")
	flag.BoolVar(&opt.exported, "exported", false, "generate tests for exported functions and methods. Takes precedence over -only and -all")
	flag.BoolVar(&opt.inputs, "i", false, "print test inputs in error messages")
	flag.BoolVar(&opt.named, "named", false, "switch table tests from using slice to map (with test name for the key)")
	flag.BoolVar(&opt.noSub, "nosubtests", false, "disable generating tests using the Go 1.7 subtests feature")
	flag.StringVar(&opt.only, "only", "", "regexp. generate tests for functions and methods that match only. Takes precedence over -all")
	flag.BoolVar(&opt.parallel, "parallel", false, "enable generating parallel subtests using the Go 1.7 feature")
	flag.StringVar(&opt.template, "template", "", "optional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE")
	flag.StringVar(&opt.templateDir, "template_dir", "", "optional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR")
	flag.StringVar(&opt.templateParams, "template_params", "", "read external parameters to template by json with stdin")
	flag.StringVar(&opt.templateParamsFile, "template_params_file", "", "read external parameters to template by json with file")
	flag.BoolVar(&opt.useCmp, "use_go_cmp", false, "use cmp.Equal (google/go-cmp) instead of reflect.DeepEqual")
	version := flag.Bool("version", false, "print version information and exit")
	flag.BoolVar(&opt.write, "w", false, "write output to (test) files instead of stdout")
	flag.Parse()
	if *version {
		fmt.Println("gotests v0.0.0-20260303205902-f3b63d74369a")
		fmt.Println("Go version: go1.24.5")
		fmt.Println("Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f")
		fmt.Println("Build time: 2026-03-03T20:59:02Z")
		return
	}
	if opt.excl == "" && opt.only == "" && !opt.exported && !opt.all {
		fmt.Println("Please specify either the -only, -excl, -exported, or -all flag")
		return
	}
	var onlyRe, exclRe *regexp.Regexp
	var err error
	if opt.only != "" {
		onlyRe, err = regexp.Compile(opt.only)
		if err != nil {
			fmt.Printf("Invalid -only regex: %v\n", err)
			return
		}
	}
	if opt.excl != "" {
		exclRe, err = regexp.Compile(opt.excl)
		if err != nil {
			fmt.Printf("Invalid -excl regex: %v\n", err)
			return
		}
	}
	paths := expandPaths(flag.Args())
	for _, p := range paths {
		if strings.HasSuffix(p, "_test.go") {
			continue
		}
		out, names, err := generateFile(p, opt, onlyRe, exclRe)
		if err != nil {
			fmt.Println(err)
			continue
		}
		if len(names) == 0 {
			fmt.Printf("No tests generated for %s\n", p)
			continue
		}
		for _, n := range names {
			fmt.Printf("Generated %s\n", n)
		}
		if opt.write {
			testPath := strings.TrimSuffix(p, ".go") + "_test.go"
			_ = os.WriteFile(testPath, out, 0644)
		} else {
			os.Stdout.Write(out)
		}
	}
}

func expandPaths(args []string) []string {
	if len(args) == 0 {
		return nil
	}
	var out []string
	for _, a := range args {
		if strings.HasSuffix(a, "/...") {
			root := strings.TrimSuffix(a, "/...")
			if root == "" {
				root = "."
			}
			filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
				if err != nil || !d.IsDir() {
					return nil
				}
				files, _ := filepath.Glob(filepath.Join(path, "*.go"))
				for _, f := range files {
					if !strings.HasSuffix(f, "_test.go") {
						out = append(out, f)
					}
				}
				return nil
			})
			continue
		}
		if st, err := os.Stat(a); err == nil && st.IsDir() {
			files, _ := filepath.Glob(filepath.Join(a, "*.go"))
			sort.Strings(files)
			for _, f := range files {
				if !strings.HasSuffix(f, "_test.go") {
					out = append(out, f)
				}
			}
			continue
		}
		m, _ := filepath.Glob(a)
		if len(m) == 0 {
			out = append(out, a)
		} else {
			sort.Strings(m)
			out = append(out, m...)
		}
	}
	return out
}

func generateFile(path string, opt options, onlyRe, exclRe *regexp.Regexp) ([]byte, []string, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		return nil, nil, err
	}
	var fns []fnInfo
	for _, d := range file.Decls {
		fd, ok := d.(*ast.FuncDecl)
		if !ok || fd.Body == nil {
			continue
		}
		if !selectFunc(fd.Name.Name, opt, onlyRe, exclRe) {
			continue
		}
		info := makeInfo(fset, fd)
		fns = append(fns, info)
	}
	if len(fns) == 0 {
		return nil, nil, nil
	}
	needReflect, needCmp := false, false
	var body strings.Builder
	var names []string
	for _, fn := range fns {
		names = append(names, fn.testName)
		s, ref := genTest(fn, opt)
		if ref {
			if opt.useCmp {
				needCmp = true
			} else {
				needReflect = true
			}
		}
		body.WriteString(s)
		body.WriteByte('\n')
	}
	var src strings.Builder
	src.WriteString("package " + file.Name.Name + "\n\n")
	if needCmp {
		src.WriteString("import (\n\t\"testing\"\n\n\t\"github.com/google/go-cmp/cmp\"\n)\n\n")
	} else if needReflect {
		src.WriteString("import (\n\t\"reflect\"\n\t\"testing\"\n)\n\n")
	} else {
		src.WriteString("import \"testing\"\n\n")
	}
	src.WriteString(body.String())
	formatted, err := format.Source([]byte(src.String()))
	if err != nil {
		return []byte(src.String()), names, nil
	}
	return formatted, names, nil
}

func selectFunc(name string, opt options, onlyRe, exclRe *regexp.Regexp) bool {
	if opt.excl != "" {
		return !exclRe.MatchString(name)
	}
	if opt.exported {
		return ast.IsExported(name)
	}
	if opt.only != "" {
		return onlyRe.MatchString(name)
	}
	return opt.all
}

func makeInfo(fset *token.FileSet, fd *ast.FuncDecl) fnInfo {
	tmap := map[string]string{}
	var typeArgs []string
	if fd.Type.TypeParams != nil {
		for _, field := range fd.Type.TypeParams.List {
			con := exprString(fset, field.Type)
			ct := concrete(con)
			for _, n := range field.Names {
				tmap[n.Name] = ct
				typeArgs = append(typeArgs, ct)
			}
		}
	}
	info := fnInfo{name: fd.Name.Name, generic: len(typeArgs) > 0, typeArgs: typeArgs}
	info.testName = "Test" + fd.Name.Name
	if len(fd.Name.Name) > 0 && unicode.IsLower(rune(fd.Name.Name[0])) {
		info.testName = "Test_" + fd.Name.Name
	}
	if fd.Recv != nil && len(fd.Recv.List) > 0 {
		info.isMethod = true
		r := fd.Recv.List[0]
		raw := exprString(fset, r.Type)
		base := recvBase(raw)
		rt := replaceType(raw, tmap)
		info.recvType = rt
		info.recvBase = recvBase(rt)
		info.recvDisplay = strings.TrimPrefix(raw, "*")
		info.testName = "Test" + base + "_" + fd.Name.Name
		if len(r.Names) > 0 && r.Names[0].Name != "_" {
			info.recvName = r.Names[0].Name
		} else {
			info.recvName = strings.ToLower(base[:1])
		}
		if fd.Type.TypeParams == nil {
			// Receiver may declare type params, e.g. *Box[T].
			for _, tv := range findTypeParams(raw) {
				tmap[tv] = "int"
				info.generic = true
			}
			info.recvType = replaceType(raw, tmap)
			info.recvBase = recvBase(info.recvType)
		}
	}
	info.params = paramsFrom(fset, fd.Type.Params, tmap)
	info.results = resultsFrom(fset, fd.Type.Results, tmap)
	return info
}

func paramsFrom(fset *token.FileSet, fl *ast.FieldList, tmap map[string]string) []param {
	var out []param
	if fl == nil {
		return out
	}
	idx := 0
	for _, f := range fl.List {
		typ := exprString(fset, f.Type)
		variadic := strings.HasPrefix(typ, "...")
		if variadic {
			typ = "[]" + strings.TrimPrefix(typ, "...")
		}
		typ = replaceType(typ, tmap)
		if len(f.Names) == 0 {
			out = append(out, param{name: fmt.Sprintf("in%d", idx), typ: typ, variadic: variadic})
			idx++
			continue
		}
		for _, n := range f.Names {
			name := n.Name
			if name == "_" {
				name = fmt.Sprintf("in%d", idx)
			}
			out = append(out, param{name: name, typ: typ, variadic: variadic})
			idx++
		}
	}
	return out
}

func resultsFrom(fset *token.FileSet, fl *ast.FieldList, tmap map[string]string) []result {
	var out []result
	if fl == nil {
		return out
	}
	idx := 0
	for _, f := range fl.List {
		typ := replaceType(exprString(fset, f.Type), tmap)
		count := len(f.Names)
		if count == 0 {
			count = 1
		}
		for i := 0; i < count; i++ {
			name := ""
			if len(f.Names) > 0 {
				name = f.Names[i].Name
			}
			if name == "" || name == "_" {
				if idx == 0 {
					name = "want"
				} else {
					name = fmt.Sprintf("want%d", idx)
				}
			} else {
				name = "want" + strings.ToUpper(name[:1]) + name[1:]
			}
			out = append(out, result{name: name, typ: typ, isErr: typ == "error"})
			idx++
		}
	}
	return out
}

func genTest(fn fnInfo, opt options) (string, bool) {
	var b strings.Builder
	usesDeep := false
	fmt.Fprintf(&b, "func %s(t *testing.T) {\n", fn.testName)
	if opt.parallel {
		b.WriteString("\tt.Parallel()\n")
	}
	if len(fn.params) > 0 {
		b.WriteString("\ttype args struct {\n")
		for _, p := range fn.params {
			fmt.Fprintf(&b, "\t\t%s %s\n", p.name, p.typ)
		}
		b.WriteString("\t}\n")
	}
	if opt.named {
		b.WriteString("\ttests := map[string]struct {\n")
	} else {
		b.WriteString("\ttests := []struct {\n\t\tname string\n")
	}
	if fn.isMethod {
		fmt.Fprintf(&b, "\t\t%s %s\n", fn.recvName, fn.recvType)
	}
	if len(fn.params) > 0 {
		b.WriteString("\t\targs args\n")
	}
	for _, r := range fn.results {
		if r.isErr {
			b.WriteString("\t\twantErr bool\n")
		} else {
			fmt.Fprintf(&b, "\t\t%s %s\n", r.name, r.typ)
		}
	}
	b.WriteString("\t}{\n\t\t// TODO: Add test cases.\n\t}\n")
	if opt.named {
		b.WriteString("\tfor name, tt := range tests {\n")
	} else if opt.noSub && len(fn.results) == 0 && !fn.isMethod && len(fn.params) == 0 {
		b.WriteString("\tfor range tests {\n")
	} else {
		b.WriteString("\tfor _, tt := range tests {\n")
	}
	if !opt.noSub {
		runName := "tt.name"
		if opt.named {
			runName = "name"
		}
		fmt.Fprintf(&b, "\t\tt.Run(%s, func(t *testing.T) {\n", runName)
		if opt.parallel {
			b.WriteString("\t\t\tt.Parallel()\n")
		}
	}
	indent := "\t\t"
	if !opt.noSub {
		indent = "\t\t\t"
	}
	if fn.isMethod {
		construct := fn.recvType
		if strings.HasPrefix(construct, "*") {
			construct = "&" + strings.TrimPrefix(construct, "*")
		}
		fmt.Fprintf(&b, "%s%s := %s{}\n", indent, fn.recvName, construct)
	}
	call := fn.name + typeArgString(fn.typeArgs) + "(" + argList(fn.params) + ")"
	display := fn.name + "()"
	if fn.isMethod {
		call = fn.recvName + "." + fn.name + "(" + argList(fn.params) + ")"
		display = fn.recvDisplay + "." + fn.name + "()"
	}
	if len(fn.results) == 0 {
		fmt.Fprintf(&b, "%s%s\n", indent, call)
	} else if onlyErr(fn.results) {
		label, inargs := labelWithInputs(display, fn, opt)
		fmt.Fprintf(&b, "%sif err := %s; (err != nil) != tt.wantErr {\n", indent, call)
		fmt.Fprintf(&b, "%s\tt.Errorf(\"%s error = %%v, wantErr %%v\"%s, err, tt.wantErr)\n%s}\n", indent, label, argPrefix(inargs), indent)
	} else {
		nonErr := nonErrResults(fn.results)
		errLast := len(fn.results) > 0 && fn.results[len(fn.results)-1].isErr
		lhs := gotNames(fn.results)
		fmt.Fprintf(&b, "%s%s := %s\n", indent, strings.Join(lhs, ", "), call)
		if errLast {
			fmt.Fprintf(&b, "%sif (err != nil) != tt.wantErr {\n", indent)
			fun := "Fatalf"
			if opt.noSub {
				fun = "Errorf"
			}
			label, inargs := labelWithInputs(display, fn, opt)
			fmt.Fprintf(&b, "%s\tt.%s(\"%s error = %%v, wantErr %%v\"%s, err, tt.wantErr)\n", indent, fun, label, argPrefix(inargs))
			if opt.noSub {
				fmt.Fprintf(&b, "%s\tcontinue\n", indent)
			}
			fmt.Fprintf(&b, "%s}\n%sif tt.wantErr {\n%s\treturn\n%s}\n", indent, indent, indent, indent)
		}
		for i, r := range nonErr {
			got := gotNameForResult(r, i)
			if needsDeep(r.typ, fn.generic) {
				usesDeep = true
				if opt.useCmp {
					fmt.Fprintf(&b, "%sif !cmp.Equal(tt.%s, %s) {\n", indent, r.name, got)
					label, inargs := resultLabel(display, fn, i, opt)
					fmt.Fprintf(&b, "%s\tt.Errorf(\"%s = %%v, want %%v\\ndiff=%%s\"%s, %s, tt.%s, cmp.Diff(tt.%s, %s))\n%s}\n", indent, label, argPrefix(inargs), got, r.name, r.name, got, indent)
				} else {
					fmt.Fprintf(&b, "%sif !reflect.DeepEqual(%s, tt.%s) {\n", indent, got, r.name)
					label, inargs := resultLabel(display, fn, i, opt)
					fmt.Fprintf(&b, "%s\tt.Errorf(\"%s = %%v, want %%v\"%s, %s, tt.%s)\n%s}\n", indent, label, argPrefix(inargs), got, r.name, indent)
				}
			} else {
				fmt.Fprintf(&b, "%sif %s != tt.%s {\n", indent, got, r.name)
				label, inargs := resultLabel(display, fn, i, opt)
				fmt.Fprintf(&b, "%s\tt.Errorf(\"%s = %%v, want %%v\"%s, %s, tt.%s)\n%s}\n", indent, label, argPrefix(inargs), got, r.name, indent)
			}
		}
	}
	if !opt.noSub {
		b.WriteString("\t\t})\n")
	}
	b.WriteString("\t}\n}\n")
	return b.String(), usesDeep
}

func exprString(fset *token.FileSet, e ast.Expr) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, fset, e)
	return b.String()
}
func recvBase(s string) string {
	s = strings.TrimPrefix(s, "*")
	if i := strings.Index(s, "["); i >= 0 {
		return s[:i]
	}
	return s
}
func findTypeParams(s string) []string {
	i := strings.Index(s, "[")
	j := strings.LastIndex(s, "]")
	if i < 0 || j < i {
		return nil
	}
	parts := strings.Split(s[i+1:j], ",")
	var out []string
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}
func concrete(c string) string {
	c = strings.TrimSpace(c)
	c = strings.TrimPrefix(c, "~")
	if c == "any" || c == "interface{}" {
		return "int"
	}
	if c == "comparable" {
		return "string"
	}
	if strings.Contains(c, "|") {
		return strings.TrimSpace(strings.TrimPrefix(strings.Split(c, "|")[0], "~"))
	}
	return "int"
}
func replaceType(s string, m map[string]string) string {
	for k, v := range m {
		re := regexp.MustCompile(`\b` + regexp.QuoteMeta(k) + `\b`)
		s = re.ReplaceAllString(s, v)
	}
	return s
}
func typeArgString(args []string) string {
	if len(args) == 0 {
		return ""
	}
	return "[" + strings.Join(args, ", ") + "]"
}
func argList(ps []param) string {
	var a []string
	for _, p := range ps {
		v := "tt.args." + p.name
		if p.variadic {
			v += "..."
		}
		a = append(a, v)
	}
	return strings.Join(a, ", ")
}
func onlyErr(rs []result) bool { return len(rs) == 1 && rs[0].isErr }
func nonErrResults(rs []result) []result {
	var o []result
	for _, r := range rs {
		if !r.isErr {
			o = append(o, r)
		}
	}
	return o
}
func gotNames(rs []result) []string {
	var o []string
	ni := 0
	for _, r := range rs {
		if r.isErr {
			o = append(o, "err")
		} else {
			if strings.HasPrefix(r.name, "want") && len(r.name) > 4 && r.name[4] >= 'A' && r.name[4] <= 'Z' {
				o = append(o, "got"+r.name[4:])
			} else if ni == 0 {
				o = append(o, "got")
			} else {
				o = append(o, fmt.Sprintf("got%d", ni))
			}
			ni++
		}
	}
	return o
}
func gotNameForResult(r result, idx int) string {
	if strings.HasPrefix(r.name, "want") && len(r.name) > 4 && r.name[4] >= 'A' && r.name[4] <= 'Z' {
		return "got" + r.name[4:]
	}
	if idx == 0 {
		return "got"
	}
	return fmt.Sprintf("got%d", idx)
}
func needsDeep(t string, generic bool) bool {
	if generic {
		return true
	}
	for _, p := range []string{"[]", "map[", "chan ", "func(", "interface{", "struct{", "["} {
		if strings.Contains(t, p) || strings.HasPrefix(t, p) {
			return true
		}
	}
	return false
}
func inputSig(fn fnInfo) (string, []string) {
	if len(fn.params) == 0 {
		return "", nil
	}
	var fs, as []string
	for _, p := range fn.params {
		fs = append(fs, "%v")
		as = append(as, "tt.args."+p.name)
	}
	return "(" + strings.Join(fs, ", ") + ")", as
}
func labelWithInputs(base string, fn fnInfo, opt options) (string, []string) {
	if opt.inputs {
		f, args := inputSig(fn)
		if f != "" {
			return strings.TrimSuffix(base, "()") + f, args
		}
	}
	return base, nil
}
func resultLabel(base string, fn fnInfo, idx int, opt options) (string, []string) {
	name, args := labelWithInputs(base, fn, opt)
	if len(nonErrResults(fn.results)) > 1 && idx > 0 {
		return name + " got" + fmt.Sprint(idx), args
	}
	if len(nonErrResults(fn.results)) > 1 && idx == 0 {
		return name + " got", args
	}
	return name, args
}
func argPrefix(args []string) string {
	if len(args) == 0 {
		return ""
	}
	return ", " + strings.Join(args, ", ")
}
