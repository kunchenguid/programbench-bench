module amber-reimplementation

go 1.21
