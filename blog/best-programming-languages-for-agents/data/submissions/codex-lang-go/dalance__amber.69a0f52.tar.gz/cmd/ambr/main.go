package main

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const helpText = `ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
`

type config struct {
	regex, column, row, binary, statistics, skipped  bool
	interactive, recursive, symlink, color, file     bool
	skipVCS, skipGitignore, fixedOrder, parentIgnore bool
	keyFromFile, repFromFile, verbose, preserveTime  bool
	maxThreads, binCheckBytes                        int
	keyword, replacement                             string
	paths                                            []string
}

type ignoreRule struct {
	base, pat string
	dirOnly   bool
	neg       bool
}
type matchSpan struct {
	start, end int
	repl       []byte
}

func defaultConfig() config {
	return config{interactive: true, recursive: true, symlink: true, color: true, file: true, skipVCS: true, skipGitignore: true, fixedOrder: true, parentIgnore: true, maxThreads: 4, binCheckBytes: 256}
}

func main() {
	cfg := defaultConfig()
	loadConfig(&cfg)
	if err := parseArgs(&cfg, os.Args[1:]); err != nil {
		if err == errHelp {
			fmt.Print(helpText)
			return
		}
		if err == errVersion {
			fmt.Println("ambr 0.6.0")
			return
		}
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(1)
	}
	if cfg.keyFromFile {
		b, err := os.ReadFile(cfg.keyword)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		cfg.keyword = string(b)
	}
	if cfg.repFromFile {
		b, err := os.ReadFile(cfg.replacement)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		cfg.replacement = string(b)
	}
	if len(cfg.paths) == 0 {
		cfg.paths = []string{"."}
	}
	start := time.Now()
	changed, err := run(cfg)
	if cfg.statistics {
		printStats(cfg, start)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if !changed {
		os.Exit(1)
	}
}

var errHelp = errors.New("help")
var errVersion = errors.New("version")

func parseArgs(cfg *config, args []string) error {
	pos := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			return errHelp
		case "-V", "--version":
			return errVersion
		case "-r", "--regex":
			cfg.regex = true
		case "--key-from-file":
			cfg.keyFromFile = true
		case "--rep-from-file":
			cfg.repFromFile = true
		case "--verbose":
			cfg.verbose = true
		case "--column":
			cfg.column = true
		case "--row":
			cfg.row = true
		case "--binary":
			cfg.binary = true
		case "--statistics":
			cfg.statistics = true
		case "--skipped":
			cfg.skipped = true
		case "--preserve-time":
			cfg.preserveTime = true
		case "--no-interactive":
			cfg.interactive = false
		case "--no-recursive":
			cfg.recursive = false
		case "--no-symlink":
			cfg.symlink = false
		case "--no-color":
			cfg.color = false
		case "--no-file":
			cfg.file = false
		case "--no-skip-vcs":
			cfg.skipVCS = false
		case "--no-skip-gitignore":
			cfg.skipGitignore = false
		case "--no-fixed-order":
			cfg.fixedOrder = false
		case "--no-parent-ignore":
			cfg.parentIgnore = false
		case "--tbm", "--sse":
		case "--max-threads", "--size-per-thread", "--bin-check-bytes", "--mmap-bytes":
			if i+1 >= len(args) {
				return fmt.Errorf("error: The argument '%s' requires a value but none was supplied", a)
			}
			if a == "--max-threads" {
				cfg.maxThreads = atoiDefault(args[i+1], cfg.maxThreads)
			}
			if a == "--bin-check-bytes" {
				cfg.binCheckBytes = atoiDefault(args[i+1], cfg.binCheckBytes)
			}
			i++
		default:
			if strings.HasPrefix(a, "--max-threads=") {
				cfg.maxThreads = atoiDefault(strings.TrimPrefix(a, "--max-threads="), cfg.maxThreads)
				continue
			}
			if strings.HasPrefix(a, "--bin-check-bytes=") {
				cfg.binCheckBytes = atoiDefault(strings.TrimPrefix(a, "--bin-check-bytes="), cfg.binCheckBytes)
				continue
			}
			if strings.HasPrefix(a, "--size-per-thread=") || strings.HasPrefix(a, "--mmap-bytes=") {
				continue
			}
			if strings.HasPrefix(a, "-") {
				return fmt.Errorf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\nFor more information try --help", a)
			}
			pos = append(pos, a)
		}
	}
	if len(pos) < 2 {
		missing := "<KEYWORD>\n    <REPLACEMENT>"
		if len(pos) == 1 {
			missing = "<REPLACEMENT>"
		}
		return fmt.Errorf("error: The following required arguments were not provided:\n    %s\n\nUSAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>\n\nFor more information try --help", missing)
	}
	cfg.keyword, cfg.replacement = pos[0], pos[1]
	cfg.paths = pos[2:]
	return nil
}

func atoiDefault(s string, d int) int {
	n, err := strconv.Atoi(s)
	if err != nil {
		return d
	}
	return n
}

func loadConfig(cfg *config) {
	paths := []string{}
	if h, err := os.UserHomeDir(); err == nil {
		paths = append(paths, filepath.Join(h, ".ambr.toml"), filepath.Join(h, ".config", "amber", "ambr.toml"))
	}
	paths = append(paths, "/etc/amber/ambr.toml")
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err != nil {
			continue
		}
		for _, line := range strings.Split(string(b), "\n") {
			line = strings.TrimSpace(strings.Split(line, "#")[0])
			if line == "" || !strings.Contains(line, "=") {
				continue
			}
			parts := strings.SplitN(line, "=", 2)
			k := strings.TrimSpace(parts[0])
			v := strings.Trim(strings.TrimSpace(parts[1]), "\"'")
			val := v == "true"
			switch k {
			case "regex":
				cfg.regex = val
			case "column":
				cfg.column = val
			case "row":
				cfg.row = val
			case "binary":
				cfg.binary = val
			case "statistics":
				cfg.statistics = val
			case "skipped":
				cfg.skipped = val
			case "interactive":
				cfg.interactive = val
			case "recursive":
				cfg.recursive = val
			case "symlink":
				cfg.symlink = val
			case "color":
				cfg.color = val
			case "file":
				cfg.file = val
			case "skip_vcs":
				cfg.skipVCS = val
			case "skip_gitignore":
				cfg.skipGitignore = val
			case "fixed_order":
				cfg.fixedOrder = val
			case "parent_ignore":
				cfg.parentIgnore = val
			}
		}
		break
	}
}

func run(cfg config) (bool, error) {
	files := collectFiles(cfg)
	if cfg.fixedOrder {
		sort.Strings(files)
	}
	var re *regexp.Regexp
	if cfg.regex {
		rr, err := regexp.Compile(cfg.keyword)
		if err != nil {
			return false, nil
		}
		re = rr
	}
	reader := bufio.NewReader(os.Stdin)
	any := false
	all := !cfg.interactive
	for _, p := range files {
		ch, err := processFile(p, cfg, re, reader, &all)
		if err != nil && cfg.verbose {
			fmt.Fprintln(os.Stderr, err)
		}
		if ch {
			any = true
		}
	}
	return any, nil
}

func collectFiles(cfg config) []string {
	var out []string
	for _, root := range cfg.paths {
		inherited := parentIgnoreRules(root, cfg)
		info, err := os.Lstat(root)
		if err != nil {
			if cfg.skipped {
				fmt.Println(root)
			}
			continue
		}
		if info.Mode()&os.ModeSymlink != 0 && cfg.symlink {
			if st, err := os.Stat(root); err == nil {
				info = st
			}
		}
		if !info.IsDir() {
			if !ignored(root, false, inherited) {
				out = append(out, root)
			} else if cfg.skipped {
				fmt.Println(root)
			}
			continue
		}
		walkDir(root, cfg, &out, inherited)
	}
	return out
}

func parentIgnoreRules(root string, cfg config) []ignoreRule {
	if !cfg.skipGitignore || !cfg.parentIgnore {
		return nil
	}
	dir := root
	if info, err := os.Lstat(root); err == nil && !info.IsDir() {
		dir = filepath.Dir(root)
	}
	var chain []string
	for {
		parent := filepath.Dir(dir)
		if parent == dir {
			break
		}
		chain = append(chain, parent)
		if parent == "." || parent == string(filepath.Separator) {
			break
		}
		dir = parent
	}
	var rules []ignoreRule
	for i := len(chain) - 1; i >= 0; i-- {
		base := chain[i]
		rules = append(rules, readIgnore(filepath.Join(base, ".gitignore"), base)...)
		rules = append(rules, readIgnore(filepath.Join(base, ".ignore"), base)...)
	}
	return rules
}

func walkDir(dir string, cfg config, out *[]string, inherited []ignoreRule) {
	rules := append([]ignoreRule{}, inherited...)
	if cfg.skipGitignore {
		rules = append(rules, readIgnore(filepath.Join(dir, ".gitignore"), dir)...)
		rules = append(rules, readIgnore(filepath.Join(dir, ".ignore"), dir)...)
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		if cfg.skipped {
			fmt.Println(dir)
		}
		return
	}
	for _, e := range entries {
		name := e.Name()
		p := filepath.Join(dir, name)
		if cfg.skipVCS && e.IsDir() && (name == ".git" || name == ".hg" || name == ".svn" || name == ".bzr") {
			if cfg.skipped {
				fmt.Println(p)
			}
			continue
		}
		if ignored(p, e.IsDir(), rules) {
			if cfg.skipped {
				fmt.Println(p)
			}
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		if info.Mode()&os.ModeSymlink != 0 {
			if !cfg.symlink {
				if cfg.skipped {
					fmt.Println(p)
				}
				continue
			}
			st, err := os.Stat(p)
			if err != nil {
				continue
			}
			if st.IsDir() {
				if cfg.recursive {
					walkDir(p, cfg, out, rules)
				}
			} else {
				*out = append(*out, p)
			}
			continue
		}
		if e.IsDir() {
			if cfg.recursive {
				walkDir(p, cfg, out, rules)
			}
			continue
		}
		if info.Mode().IsRegular() {
			*out = append(*out, p)
		}
	}
}

func readIgnore(path, base string) []ignoreRule {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var rs []ignoreRule
	for _, line := range strings.Split(string(b), "\n") {
		s := strings.TrimSpace(line)
		if s == "" || strings.HasPrefix(s, "#") {
			continue
		}
		neg := false
		if strings.HasPrefix(s, "!") {
			neg = true
			s = s[1:]
		}
		dirOnly := strings.HasSuffix(s, "/")
		s = strings.Trim(s, "/")
		rs = append(rs, ignoreRule{base: base, pat: s, dirOnly: dirOnly, neg: neg})
	}
	return rs
}

func ignored(path string, isDir bool, rules []ignoreRule) bool {
	res := false
	for _, r := range rules {
		if r.dirOnly && !isDir {
			continue
		}
		rel, err := filepath.Rel(r.base, path)
		if err != nil {
			continue
		}
		rel = filepath.ToSlash(rel)
		name := filepath.Base(path)
		pat := filepath.ToSlash(r.pat)
		m := false
		if strings.Contains(pat, "/") {
			m, _ = filepath.Match(pat, rel)
		} else {
			m, _ = filepath.Match(pat, name)
			if !m && strings.HasSuffix(rel, "/"+pat) {
				m = true
			}
		}
		if m {
			res = !r.neg
		}
	}
	return res
}

func processFile(path string, cfg config, re *regexp.Regexp, reader *bufio.Reader, all *bool) (bool, error) {
	info, err := os.Stat(path)
	if err != nil {
		return false, err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return false, err
	}
	if !cfg.binary && isBinary(data, cfg.binCheckBytes) {
		if cfg.skipped {
			fmt.Println(path)
		}
		return false, nil
	}
	var spans []matchSpan
	if cfg.regex {
		idxs := re.FindAllSubmatchIndex(data, -1)
		for _, idx := range idxs {
			if idx[0] == idx[1] {
				continue
			}
			spans = append(spans, matchSpan{start: idx[0], end: idx[1], repl: re.Expand(nil, []byte(cfg.replacement), data, idx)})
		}
	} else {
		key := []byte(cfg.keyword)
		if len(key) == 0 {
			return false, nil
		}
		off := 0
		for {
			i := bytes.Index(data[off:], key)
			if i < 0 {
				break
			}
			s := off + i
			spans = append(spans, matchSpan{start: s, end: s + len(key), repl: []byte(cfg.replacement)})
			off = s + len(key)
		}
	}
	if len(spans) == 0 {
		return false, nil
	}
	chosen := make([]bool, len(spans))
	if *all {
		for i := range chosen {
			chosen[i] = true
		}
	} else {
		stop := false
		for i, sp := range spans {
			if stop {
				break
			}
			printPrompt(path, data, sp, cfg)
			ans, _ := reader.ReadString('\n')
			ans = strings.ToLower(strings.TrimSpace(ans))
			switch ans {
			case "a", "all":
				*all = true
				for j := i; j < len(chosen); j++ {
					chosen[j] = true
				}
				stop = true
			case "q", "quit":
				stop = true
			case "n", "no":
			default:
				chosen[i] = true
			}
		}
	}
	return apply(path, data, spans, chosen, cfg, info)
}

func isBinary(b []byte, n int) bool {
	if n <= 0 || n > len(b) {
		n = len(b)
	}
	return bytes.IndexByte(b[:n], 0) >= 0
}

func printPrompt(path string, data []byte, sp matchSpan, cfg config) {
	if cfg.file {
		fmt.Print(path, ": ")
	}
	ls := bytes.LastIndexByte(data[:sp.start], '\n') + 1
	leRel := bytes.IndexByte(data[sp.end:], '\n')
	le := len(data)
	if leRel >= 0 {
		le = sp.end + leRel
	}
	old := string(data[ls:le])
	line := append([]byte{}, data[ls:sp.start]...)
	line = append(line, sp.repl...)
	line = append(line, data[sp.end:le]...)
	fmt.Println(old)
	fmt.Println("    -> " + string(line))
	fmt.Print("Replace keyword? [Y]es/[n]o/[a]ll/[q]uit: ")
}

func apply(path string, data []byte, spans []matchSpan, chosen []bool, cfg config, info fs.FileInfo) (bool, error) {
	var buf bytes.Buffer
	last := 0
	changed := false
	for i, sp := range spans {
		if chosen[i] {
			buf.Write(data[last:sp.start])
			buf.Write(sp.repl)
			last = sp.end
			changed = true
		}
	}
	if !changed {
		return false, nil
	}
	buf.Write(data[last:])
	if err := os.WriteFile(path, buf.Bytes(), info.Mode().Perm()); err != nil {
		return false, err
	}
	if cfg.preserveTime {
		_ = os.Chtimes(path, info.ModTime(), info.ModTime())
	}
	return true, nil
}

func printStats(cfg config, start time.Time) {
	d := time.Since(start)
	io.WriteString(os.Stdout, "\nStatistics\n")
	fmt.Fprintf(os.Stdout, "  Max threads: %d\n\n", cfg.maxThreads)
	io.WriteString(os.Stdout, "  Consumed time ( busy / total )\n")
	fmt.Fprintf(os.Stdout, "    Find     : 0s / %s\n", d)
	fmt.Fprintf(os.Stdout, "    Replace  : 0s / %s\n", d)
}
