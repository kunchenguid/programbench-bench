package main

import (
	"bufio"
	"fmt"
	"math"
	"math/rand"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Color struct {
	R, G, B float64
	A       float64
}

var names = map[string]Color{
	"black": {0, 0, 0, 1}, "silver": {192, 192, 192, 1}, "gray": {128, 128, 128, 1}, "grey": {128, 128, 128, 1},
	"white": {255, 255, 255, 1}, "maroon": {128, 0, 0, 1}, "red": {255, 0, 0, 1}, "purple": {128, 0, 128, 1},
	"fuchsia": {255, 0, 255, 1}, "magenta": {255, 0, 255, 1}, "green": {0, 128, 0, 1}, "lime": {0, 255, 0, 1},
	"olive": {128, 128, 0, 1}, "yellow": {255, 255, 0, 1}, "navy": {0, 0, 128, 1}, "blue": {0, 0, 255, 1},
	"teal": {0, 128, 128, 1}, "aqua": {0, 255, 255, 1}, "cyan": {0, 255, 255, 1}, "orange": {255, 165, 0, 1},
	"aliceblue": {240, 248, 255, 1}, "antiquewhite": {250, 235, 215, 1}, "aquamarine": {127, 255, 212, 1}, "azure": {240, 255, 255, 1},
	"beige": {245, 245, 220, 1}, "bisque": {255, 228, 196, 1}, "blanchedalmond": {255, 235, 205, 1}, "blueviolet": {138, 43, 226, 1},
	"brown": {165, 42, 42, 1}, "burlywood": {222, 184, 135, 1}, "cadetblue": {95, 158, 160, 1}, "chartreuse": {127, 255, 0, 1},
	"chocolate": {210, 105, 30, 1}, "coral": {255, 127, 80, 1}, "cornflowerblue": {100, 149, 237, 1}, "cornsilk": {255, 248, 220, 1},
	"crimson": {220, 20, 60, 1}, "darkblue": {0, 0, 139, 1}, "darkcyan": {0, 139, 139, 1}, "darkgoldenrod": {184, 134, 11, 1},
	"darkgray": {169, 169, 169, 1}, "darkgrey": {169, 169, 169, 1}, "darkgreen": {0, 100, 0, 1}, "darkkhaki": {189, 183, 107, 1},
	"darkmagenta": {139, 0, 139, 1}, "darkolivegreen": {85, 107, 47, 1}, "darkorange": {255, 140, 0, 1}, "darkorchid": {153, 50, 204, 1},
	"darkred": {139, 0, 0, 1}, "darksalmon": {233, 150, 122, 1}, "darkseagreen": {143, 188, 143, 1}, "darkslateblue": {72, 61, 139, 1},
	"darkslategray": {47, 79, 79, 1}, "darkslategrey": {47, 79, 79, 1}, "darkturquoise": {0, 206, 209, 1}, "darkviolet": {148, 0, 211, 1},
	"deeppink": {255, 20, 147, 1}, "deepskyblue": {0, 191, 255, 1}, "dimgray": {105, 105, 105, 1}, "dimgrey": {105, 105, 105, 1},
	"dodgerblue": {30, 144, 255, 1}, "firebrick": {178, 34, 34, 1}, "floralwhite": {255, 250, 240, 1}, "forestgreen": {34, 139, 34, 1},
	"gainsboro": {220, 220, 220, 1}, "ghostwhite": {248, 248, 255, 1}, "gold": {255, 215, 0, 1}, "goldenrod": {218, 165, 32, 1},
	"greenyellow": {173, 255, 47, 1}, "honeydew": {240, 255, 240, 1}, "hotpink": {255, 105, 180, 1}, "indianred": {205, 92, 92, 1},
	"indigo": {75, 0, 130, 1}, "ivory": {255, 255, 240, 1}, "khaki": {240, 230, 140, 1}, "lavender": {230, 230, 250, 1},
	"lavenderblush": {255, 240, 245, 1}, "lawngreen": {124, 252, 0, 1}, "lemonchiffon": {255, 250, 205, 1}, "lightblue": {173, 216, 230, 1},
	"lightcoral": {240, 128, 128, 1}, "lightcyan": {224, 255, 255, 1}, "lightgoldenrodyellow": {250, 250, 210, 1}, "lightgray": {211, 211, 211, 1},
	"lightgrey": {211, 211, 211, 1}, "lightgreen": {144, 238, 144, 1}, "lightpink": {255, 182, 193, 1}, "lightsalmon": {255, 160, 122, 1},
	"lightseagreen": {32, 178, 170, 1}, "lightskyblue": {135, 206, 250, 1}, "lightslategray": {119, 136, 153, 1}, "lightslategrey": {119, 136, 153, 1},
	"lightsteelblue": {176, 196, 222, 1}, "lightyellow": {255, 255, 224, 1}, "limegreen": {50, 205, 50, 1}, "linen": {250, 240, 230, 1},
	"mediumaquamarine": {102, 205, 170, 1}, "mediumblue": {0, 0, 205, 1}, "mediumorchid": {186, 85, 211, 1}, "mediumpurple": {147, 112, 219, 1},
	"mediumseagreen": {60, 179, 113, 1}, "mediumslateblue": {123, 104, 238, 1}, "mediumspringgreen": {0, 250, 154, 1}, "mediumturquoise": {72, 209, 204, 1},
	"mediumvioletred": {199, 21, 133, 1}, "midnightblue": {25, 25, 112, 1}, "mintcream": {245, 255, 250, 1}, "mistyrose": {255, 228, 225, 1},
	"moccasin": {255, 228, 181, 1}, "navajowhite": {255, 222, 173, 1}, "oldlace": {253, 245, 230, 1}, "olivedrab": {107, 142, 35, 1},
	"orangered": {255, 69, 0, 1}, "orchid": {218, 112, 214, 1}, "palegoldenrod": {238, 232, 170, 1}, "palegreen": {152, 251, 152, 1},
	"paleturquoise": {175, 238, 238, 1}, "palevioletred": {219, 112, 147, 1}, "papayawhip": {255, 239, 213, 1}, "peachpuff": {255, 218, 185, 1},
	"peru": {205, 133, 63, 1}, "pink": {255, 192, 203, 1}, "plum": {221, 160, 221, 1}, "powderblue": {176, 224, 230, 1},
	"rebeccapurple": {102, 51, 153, 1}, "rosybrown": {188, 143, 143, 1}, "royalblue": {65, 105, 225, 1}, "saddlebrown": {139, 69, 19, 1},
	"salmon": {250, 128, 114, 1}, "sandybrown": {244, 164, 96, 1}, "seagreen": {46, 139, 87, 1}, "seashell": {255, 245, 238, 1},
	"sienna": {160, 82, 45, 1}, "skyblue": {135, 206, 235, 1}, "slateblue": {106, 90, 205, 1}, "slategray": {112, 128, 144, 1},
	"slategrey": {112, 128, 144, 1}, "snow": {255, 250, 250, 1}, "springgreen": {0, 255, 127, 1}, "steelblue": {70, 130, 180, 1},
	"tan": {210, 180, 140, 1}, "thistle": {216, 191, 216, 1}, "tomato": {255, 99, 71, 1}, "turquoise": {64, 224, 208, 1},
	"violet": {238, 130, 238, 1}, "wheat": {245, 222, 179, 1}, "whitesmoke": {245, 245, 245, 1}, "yellowgreen": {154, 205, 50, 1},
}

func main() {
	args := stripGlobal(os.Args[1:])
	if len(args) == 0 || args[0] == "-h" || args[0] == "--help" {
		help()
		return
	}
	if args[0] == "-V" || args[0] == "--version" {
		fmt.Println("pastel 0.11.0")
		return
	}
	cmd := args[0]
	args = args[1:]
	switch cmd {
	case "format":
		cmdFormat(args)
	case "lighten", "darken", "saturate", "desaturate", "rotate":
		cmdAdjust(cmd, args)
	case "complement":
		applyColors(args, func(c Color) string { h, s, l := rgbToHsl(c); return formatHSL(h+180, s, l, c.A, false) })
	case "gray":
		v := mustFloat(arg(args, 0, "0"))
		fmt.Println(formatHSL(0, 0, clamp(v, 0, 1), 1, false))
	case "to-gray":
		applyColors(args, func(c Color) string {
			y := luminance(c)
			g := linearToSrgb(y) * 255
			h, s, l := rgbToHsl(Color{g, g, g, c.A})
			return formatHSL(h, s, l, c.A, false)
		})
	case "textcolor":
		applyColors(args, func(c Color) string {
			if luminance(c) > 0.179 {
				return formatHSL(0, 0, 0, 1, false)
			}
			return formatHSL(0, 0, 1, 1, false)
		})
	case "mix":
		cmdMix(args)
	case "gradient":
		cmdGradient(args)
	case "sort-by":
		cmdSort(args)
	case "list":
		cmdList(args)
	case "random", "distinct":
		cmdRandom(args)
	case "paint":
		cmdPaint(args)
	case "colorblind":
		cmdColorblind(args)
	case "color", "colorcheck":
		if cmd == "colorcheck" {
			colorcheck()
		} else {
			applyColors(args, func(c Color) string { return colorInfo(c) })
		}
	case "set":
		cmdSet(args)
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n", cmd)
		os.Exit(2)
	}
}

func stripGlobal(args []string) []string {
	out := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-f" || a == "--force-color" {
			continue
		}
		if a == "-m" || a == "--color-mode" || a == "--color-picker" {
			i++
			continue
		}
		if strings.HasPrefix(a, "--color-mode=") || strings.HasPrefix(a, "--color-picker=") {
			continue
		}
		out = append(out, a)
	}
	return out
}

func help() {
	fmt.Println("A command-line tool to generate, analyze, convert and manipulate colors")
	fmt.Println()
	fmt.Println("Usage: executable [OPTIONS] <COMMAND>")
	fmt.Println()
	fmt.Println("Commands:")
	for _, c := range []string{"color", "colorblind", "colorcheck", "complement", "darken", "desaturate", "distinct", "format", "gradient", "gray", "help", "lighten", "list", "mix", "paint", "random", "rotate", "saturate", "set", "sort-by", "textcolor", "to-gray"} {
		fmt.Printf("  %s\n", c)
	}
}

func parseColor(s string) (Color, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return Color{}, fmt.Errorf("empty color")
	}
	if c, ok := names[strings.ToLower(strings.ReplaceAll(s, " ", ""))]; ok {
		return c, nil
	}
	if strings.HasPrefix(s, "#") {
		s = s[1:]
	}
	if matched, _ := regexp.MatchString(`^[0-9a-fA-F]{3}$`, s); matched {
		r, _ := strconv.ParseInt(strings.Repeat(s[0:1], 2), 16, 64)
		g, _ := strconv.ParseInt(strings.Repeat(s[1:2], 2), 16, 64)
		b, _ := strconv.ParseInt(strings.Repeat(s[2:3], 2), 16, 64)
		return Color{float64(r), float64(g), float64(b), 1}, nil
	}
	if matched, _ := regexp.MatchString(`^[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$`, s); matched {
		r, _ := strconv.ParseInt(s[0:2], 16, 64)
		g, _ := strconv.ParseInt(s[2:4], 16, 64)
		b, _ := strconv.ParseInt(s[4:6], 16, 64)
		a := 1.0
		if len(s) == 8 {
			ai, _ := strconv.ParseInt(s[6:8], 16, 64)
			a = float64(ai) / 255
		}
		return Color{float64(r), float64(g), float64(b), a}, nil
	}
	ls := strings.ToLower(s)
	if strings.HasPrefix(ls, "rgb") {
		nums := numbers(s)
		if len(nums) >= 3 {
			a := 1.0
			if len(nums) >= 4 {
				a = alphaValue(nums[3])
			}
			return Color{channel(nums[0]), channel(nums[1]), channel(nums[2]), a}, nil
		}
	}
	if strings.HasPrefix(ls, "hsl") {
		nums := numbers(s)
		if len(nums) >= 3 {
			a := 1.0
			if len(nums) >= 4 {
				a = alphaValue(nums[3])
			}
			return hslToRgb(nums[0], percent(nums[1]), percent(nums[2]), a), nil
		}
	}
	if strings.HasPrefix(ls, "hsv") {
		nums := numbers(s)
		if len(nums) >= 3 {
			return hsvToRgb(nums[0], percent(nums[1]), percent(nums[2]), 1), nil
		}
	}
	if strings.HasPrefix(ls, "gray") || strings.HasPrefix(ls, "grey") {
		nums := numbers(s)
		if len(nums) >= 1 {
			v := percent(nums[0]) * 255
			return Color{v, v, v, 1}, nil
		}
	}
	nums := numbers(s)
	if len(nums) >= 3 {
		return Color{channel(nums[0]), channel(nums[1]), channel(nums[2]), 1}, nil
	}
	return Color{}, fmt.Errorf("Could not parse color '%s'", s)
}

func numbers(s string) []float64 {
	re := regexp.MustCompile(`[-+]?[0-9]*\.?[0-9]+%?`)
	var out []float64
	for _, m := range re.FindAllString(s, -1) {
		v, _ := strconv.ParseFloat(strings.TrimSuffix(m, "%"), 64)
		if strings.HasSuffix(m, "%") {
			v = v / 100
		}
		out = append(out, v)
	}
	return out
}

func channel(v float64) float64 {
	if v <= 1 {
		return clamp(v, 0, 1) * 255
	}
	return clamp(v, 0, 255)
}
func percent(v float64) float64 {
	if v > 1 {
		return clamp(v/100, 0, 1)
	}
	return clamp(v, 0, 1)
}
func alphaValue(v float64) float64 {
	if v > 1 {
		return clamp(v/100, 0, 1)
	}
	return clamp(v, 0, 1)
}

func colorArgs(args []string) []Color {
	if len(args) == 0 {
		var xs []string
		sc := bufio.NewScanner(os.Stdin)
		for sc.Scan() {
			t := strings.TrimSpace(sc.Text())
			if t != "" {
				xs = append(xs, t)
			}
		}
		args = xs
	}
	var out []Color
	for _, a := range args {
		if a == "-" {
			sc := bufio.NewScanner(os.Stdin)
			for sc.Scan() {
				if c, err := parseColor(sc.Text()); err == nil {
					out = append(out, c)
				}
			}
			continue
		}
		c, err := parseColor(a)
		if err != nil {
			fmt.Fprintln(os.Stderr, "error:", err)
			os.Exit(1)
		}
		out = append(out, c)
	}
	return out
}

func applyColors(args []string, f func(Color) string) {
	for _, c := range colorArgs(args) {
		fmt.Println(f(c))
	}
}

func cmdFormat(args []string) {
	typ := "hex"
	if len(args) > 0 && !looksColor(args[0]) {
		typ = args[0]
		args = args[1:]
	}
	applyColors(args, func(c Color) string { return formatColor(c, typ) })
}

func looksColor(s string) bool {
	if _, ok := names[strings.ToLower(s)]; ok || strings.HasPrefix(s, "#") || strings.Contains(s, "(") {
		return true
	}
	if ok, _ := regexp.MatchString(`^[0-9a-fA-F]{3}([0-9a-fA-F]{3})?([0-9a-fA-F]{2})?$`, s); ok {
		return true
	}
	return strings.Contains(s, ",")
}

func formatColor(c Color, typ string) string {
	h, s, l := rgbToHsl(c)
	switch strings.ToLower(typ) {
	case "hex":
		if c.A < 0.999 {
			return fmt.Sprintf("#%02x%02x%02x%02x", ir(c.R), ir(c.G), ir(c.B), ir(c.A*255))
		}
		return fmt.Sprintf("#%02x%02x%02x", ir(c.R), ir(c.G), ir(c.B))
	case "rgb":
		if c.A < 0.999 {
			return fmt.Sprintf("rgba(%d, %d, %d, %.3g)", ir(c.R), ir(c.G), ir(c.B), c.A)
		}
		return fmt.Sprintf("rgb(%d, %d, %d)", ir(c.R), ir(c.G), ir(c.B))
	case "rgb-r":
		return fmt.Sprintf("%d", ir(c.R))
	case "rgb-g":
		return fmt.Sprintf("%d", ir(c.G))
	case "rgb-b":
		return fmt.Sprintf("%d", ir(c.B))
	case "rgb-float":
		if c.A < 0.999 {
			return fmt.Sprintf("rgba(%.3f, %.3f, %.3f, %.3f)", c.R/255, c.G/255, c.B/255, c.A)
		}
		return fmt.Sprintf("rgb(%.3f, %.3f, %.3f)", c.R/255, c.G/255, c.B/255)
	case "hsl":
		return formatHSL(h, s, l, c.A, true)
	case "hsl-hue":
		return fmt.Sprintf("%.0f", normHue(h))
	case "hsl-saturation":
		return fmt.Sprintf("%.4f", s)
	case "hsl-lightness":
		return fmt.Sprintf("%.4f", l)
	case "hsv":
		hh, ss, vv := rgbToHsv(c)
		return fmt.Sprintf("hsv(%.0f, %.1f%%, %.1f%%)", normHue(hh), ss*100, vv*100)
	case "hsv-hue":
		hh, _, _ := rgbToHsv(c)
		return fmt.Sprintf("%.0f", normHue(hh))
	case "hsv-saturation":
		_, ss, _ := rgbToHsv(c)
		return fmt.Sprintf("%.3f", ss)
	case "hsv-value":
		_, _, vv := rgbToHsv(c)
		return fmt.Sprintf("%.3f", vv)
	case "cmyk":
		k := 1 - max3(c.R, c.G, c.B)/255
		if k >= 0.999999 {
			return "cmyk(0, 0, 0, 100)"
		}
		cy := (1 - c.R/255 - k) / (1 - k)
		m := (1 - c.G/255 - k) / (1 - k)
		y := (1 - c.B/255 - k) / (1 - k)
		return fmt.Sprintf("cmyk(%.0f, %.0f, %.0f, %.0f)", cy*100, m*100, y*100, k*100)
	case "luminance":
		return fmt.Sprintf("%.3f", luminance(c))
	case "brightness":
		return fmt.Sprintf("%.3f", (0.299*c.R+0.587*c.G+0.114*c.B)/255)
	case "name":
		return nearestName(c)
	case "lab", "lab-a", "lab-b", "lch", "lch-lightness", "lch-chroma", "lch-hue":
		L, a, b := lab(c)
		ch := math.Hypot(a, b)
		hu := normHue(math.Atan2(b, a) * 180 / math.Pi)
		if typ == "lab-a" {
			return fmt.Sprintf("%.0f", a)
		}
		if typ == "lab-b" {
			return fmt.Sprintf("%.0f", b)
		}
		if typ == "lch-lightness" {
			return fmt.Sprintf("%.0f", L)
		}
		if typ == "lch-chroma" {
			return fmt.Sprintf("%.0f", ch)
		}
		if typ == "lch-hue" {
			return fmt.Sprintf("%.0f", hu)
		}
		if strings.HasPrefix(typ, "lch") {
			return fmt.Sprintf("LCh(%.0f, %.0f, %.0f)", L, ch, hu)
		}
		return fmt.Sprintf("Lab(%.0f, %.0f, %.0f)", L, a, b)
	case "oklab", "oklab-l", "oklab-a", "oklab-b", "oklch", "oklch-lightness", "oklch-chroma", "oklch-hue":
		L, a, b := oklab(c)
		ch := math.Hypot(a, b)
		hu := normHue(math.Atan2(b, a) * 180 / math.Pi)
		if typ == "oklab-l" || typ == "oklch-lightness" {
			return fmt.Sprintf("%.4f", L)
		}
		if typ == "oklab-a" {
			return fmt.Sprintf("%.4f", a)
		}
		if typ == "oklab-b" {
			return fmt.Sprintf("%.4f", b)
		}
		if typ == "oklch-chroma" {
			return fmt.Sprintf("%.4f", ch)
		}
		if typ == "oklch-hue" {
			return fmt.Sprintf("%.4f", hu)
		}
		if strings.HasPrefix(typ, "oklch") {
			return fmt.Sprintf("OkLCh(%.4f, %.4f, %.4f)", L, ch, hu)
		}
		return fmt.Sprintf("OkLab(%.4f, %.4f, %.4f)", L, a, b)
	case "ansi-8bit":
		return fmt.Sprintf("\033[38;5;%dm", ansi256(c))
	case "ansi-24bit":
		return fmt.Sprintf("\033[38;2;%d;%d;%dm", ir(c.R), ir(c.G), ir(c.B))
	case "ansi-8bit-value":
		return fmt.Sprintf("%d", ansi256(c))
	case "ansi-8bit-escapecode":
		return fmt.Sprintf("\\033[38;5;%dm", ansi256(c))
	case "ansi-24bit-escapecode":
		return fmt.Sprintf("\\033[38;2;%d;%d;%dm", ir(c.R), ir(c.G), ir(c.B))
	default:
		return fmt.Sprintf("#%02x%02x%02x", ir(c.R), ir(c.G), ir(c.B))
	}
}

func cmdAdjust(cmd string, args []string) {
	if len(args) < 1 {
		os.Exit(2)
	}
	amount := mustFloat(args[0])
	args = args[1:]
	applyColors(args, func(c Color) string {
		h, s, l := rgbToHsl(c)
		switch cmd {
		case "lighten":
			l += amount
		case "darken":
			l -= amount
		case "saturate":
			s += amount
		case "desaturate":
			s -= amount
		case "rotate":
			h += amount
		}
		return formatHSL(h, clamp(s, 0, 1), clamp(l, 0, 1), c.A, false)
	})
}

func cmdMix(args []string) {
	space := "Lab"
	f := 0.5
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-s" || a == "--colorspace" {
			i++
			space = args[i]
		} else if strings.HasPrefix(a, "--colorspace=") {
			space = strings.SplitN(a, "=", 2)[1]
		} else if a == "-f" || a == "--fraction" {
			i++
			f = mustFloat(args[i])
		} else if strings.HasPrefix(a, "--fraction=") {
			f = mustFloat(strings.SplitN(a, "=", 2)[1])
		} else {
			rest = append(rest, a)
		}
	}
	if len(rest) < 1 {
		os.Exit(2)
	}
	base, _ := parseColor(rest[0])
	others := colorArgs(rest[1:])
	for _, c := range others {
		fmt.Println(formatHSLColor(interp(base, c, f, space)))
	}
}

func cmdGradient(args []string) {
	n := 10
	space := "Lab"
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-n" || a == "--number" {
			i++
			n = int(mustFloat(args[i]))
		} else if strings.HasPrefix(a, "--number=") {
			n = int(mustFloat(strings.SplitN(a, "=", 2)[1]))
		} else if a == "-s" || a == "--colorspace" {
			i++
			space = args[i]
		} else if strings.HasPrefix(a, "--colorspace=") {
			space = strings.SplitN(a, "=", 2)[1]
		} else {
			rest = append(rest, a)
		}
	}
	cols := colorArgs(rest)
	if len(cols) == 0 {
		os.Exit(2)
	}
	if len(cols) == 1 || n <= 1 {
		fmt.Println(formatHSLColor(cols[0]))
		return
	}
	for i := 0; i < n; i++ {
		t := float64(i) / float64(n-1) * float64(len(cols)-1)
		j := int(math.Min(float64(len(cols)-2), math.Floor(t)))
		fmt.Println(formatHSLColor(interp(cols[j], cols[j+1], t-float64(j), space)))
	}
}

func interp(a, b Color, t float64, space string) Color {
	t = clamp(t, 0, 1)
	if strings.EqualFold(space, "hsl") {
		ha, sa, la := rgbToHsl(a)
		hb, sb, lb := rgbToHsl(b)
		d := hb - ha
		if d > 180 {
			d -= 360
		}
		if d < -180 {
			d += 360
		}
		return hslToRgb(ha+d*t, sa+(sb-sa)*t, la+(lb-la)*t, a.A+(b.A-a.A)*t)
	}
	if strings.EqualFold(space, "lab") {
		l1, a1, b1 := lab(a)
		l2, a2, b2 := lab(b)
		return labToRGB(l1+(l2-l1)*t, a1+(a2-a1)*t, b1+(b2-b1)*t, a.A+(b.A-a.A)*t)
	}
	if strings.EqualFold(space, "oklab") {
		l1, a1, b1 := oklab(a)
		l2, a2, b2 := oklab(b)
		return oklabToRGB(l1+(l2-l1)*t, a1+(a2-a1)*t, b1+(b2-b1)*t, a.A+(b.A-a.A)*t)
	}
	return Color{float64(ir(a.R + (b.R-a.R)*t)), float64(ir(a.G + (b.G-a.G)*t)), float64(ir(a.B + (b.B-a.B)*t)), a.A + (b.A-a.A)*t}
}

func cmdSort(args []string) {
	order := "hue"
	rev := false
	uniq := false
	var rest []string
	for _, a := range args {
		if a == "-r" || a == "--reverse" {
			rev = true
		} else if a == "-u" || a == "--unique" {
			uniq = true
		} else if !looksColor(a) && order == "hue" {
			order = a
		} else {
			rest = append(rest, a)
		}
	}
	cols := colorArgs(rest)
	sort.SliceStable(cols, func(i, j int) bool {
		vi, vj := sortVal(cols[i], order), sortVal(cols[j], order)
		if rev {
			return vi > vj
		}
		return vi < vj
	})
	seen := map[string]bool{}
	for _, c := range cols {
		k := formatColor(c, "hex")
		if uniq && seen[k] {
			continue
		}
		seen[k] = true
		fmt.Println(formatHSLColor(c))
	}
}

func sortVal(c Color, order string) float64 {
	h, _, _ := rgbToHsl(c)
	switch order {
	case "brightness":
		return (0.299*c.R + 0.587*c.G + 0.114*c.B) / 255
	case "luminance":
		return luminance(c)
	case "chroma":
		_, a, b := lab(c)
		return math.Hypot(a, b)
	default:
		return h
	}
}

func cmdSet(args []string) {
	if len(args) < 2 {
		os.Exit(2)
	}
	prop := args[0]
	val := mustFloat(args[1])
	applyColors(args[2:], func(c Color) string {
		h, s, l := rgbToHsl(c)
		switch prop {
		case "red":
			c.R = channel(val)
		case "green":
			c.G = channel(val)
		case "blue":
			c.B = channel(val)
		case "alpha":
			c.A = alphaValue(val)
		case "hue", "hsl-hue":
			h = val
			c = hslToRgb(h, s, l, c.A)
		case "hsl-saturation":
			s = percent(val)
			c = hslToRgb(h, s, l, c.A)
		case "lightness", "hsl-lightness":
			l = percent(val)
			c = hslToRgb(h, s, l, c.A)
		}
		return formatHSLColor(c)
	})
}

func cmdList(args []string) {
	keys := make([]string, 0, len(names))
	seen := map[string]bool{}
	for k := range names {
		if strings.Contains(k, "grey") {
			continue
		}
		if !seen[k] {
			keys = append(keys, k)
			seen[k] = true
		}
	}
	sort.Slice(keys, func(i, j int) bool { return sortVal(names[keys[i]], "hue") < sortVal(names[keys[j]], "hue") })
	for _, k := range keys {
		fmt.Println(k)
	}
}

func cmdRandom(args []string) {
	n := 10
	for i := 0; i < len(args); i++ {
		if args[i] == "-n" || args[i] == "--number" {
			i++
			n = int(mustFloat(args[i]))
		} else if strings.HasPrefix(args[i], "--number=") {
			n = int(mustFloat(strings.SplitN(args[i], "=", 2)[1]))
		}
	}
	rand.Seed(time.Now().UnixNano())
	for i := 0; i < n; i++ {
		h := rand.Float64() * 360
		s := 0.55 + rand.Float64()*0.35
		l := 0.35 + rand.Float64()*0.35
		fmt.Println(formatHSL(h, s, l, 1, false))
	}
}

func cmdPaint(args []string) {
	bg := ""
	bold, italic, under, nonew := false, false, false, false
	var rest []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-o", "--on":
			i++
			bg = args[i]
		case "-b", "--bold":
			bold = true
		case "-i", "--italic":
			italic = true
		case "-u", "--underline":
			under = true
		case "-n", "--no-newline":
			nonew = true
		default:
			rest = append(rest, args[i])
		}
	}
	if len(rest) < 1 {
		os.Exit(2)
	}
	fg, _ := parseColor(rest[0])
	text := strings.Join(rest[1:], " ")
	if text == "" {
		b, _ := os.ReadFile("/dev/stdin")
		text = string(b)
	}
	var codes []string
	if bold {
		codes = append(codes, "1")
	}
	if italic {
		codes = append(codes, "3")
	}
	if under {
		codes = append(codes, "4")
	}
	codes = append(codes, fmt.Sprintf("38;2;%d;%d;%d", ir(fg.R), ir(fg.G), ir(fg.B)))
	if bg != "" {
		bc, _ := parseColor(bg)
		codes = append(codes, fmt.Sprintf("48;2;%d;%d;%d", ir(bc.R), ir(bc.G), ir(bc.B)))
	}
	fmt.Print("\033[" + strings.Join(codes, ";") + "m" + text + "\033[0m")
	if !nonew {
		fmt.Println()
	}
}

func cmdColorblind(args []string) {
	if len(args) < 1 {
		os.Exit(2)
	}
	typ := args[0]
	applyColors(args[1:], func(c Color) string {
		r, g, b := c.R/255, c.G/255, c.B/255
		var nr, ng, nb float64
		switch typ {
		case "prot":
			nr = 0.567*r + 0.433*g
			ng = 0.558*r + 0.442*g
			nb = 0.242*g + 0.758*b
		case "deuter":
			nr = 0.625*r + 0.375*g
			ng = 0.7*r + 0.3*g
			nb = 0.3*g + 0.7*b
		default:
			nr = 0.95*r + 0.05*g
			ng = 0.433*g + 0.567*b
			nb = 0.475*g + 0.525*b
		}
		return formatHSLColor(Color{nr * 255, ng * 255, nb * 255, c.A})
	})
}

func colorInfo(c Color) string {
	return strings.Join([]string{formatColor(c, "hex"), formatColor(c, "rgb"), formatColor(c, "hsl"), formatColor(c, "lab"), formatColor(c, "lch")}, "\n")
}

func colorcheck() {
	fmt.Print("\033[48;2;73;39;50m  \033[48;2;16;51;30m  \033[48;2;29;54;90m  \033[0m\n")
}

func rgbToHsl(c Color) (float64, float64, float64) {
	r, g, b := c.R/255, c.G/255, c.B/255
	maxv, minv := max3(c.R, c.G, c.B)/255, min3(c.R, c.G, c.B)/255
	l := (maxv + minv) / 2
	if maxv == minv {
		return 0, 0, l
	}
	d := maxv - minv
	s := d / (1 - math.Abs(2*l-1))
	var h float64
	switch maxv {
	case r:
		h = math.Mod((g-b)/d, 6)
	case g:
		h = (b-r)/d + 2
	default:
		h = (r-g)/d + 4
	}
	return normHue(h * 60), s, l
}

func hslToRgb(h, s, l, a float64) Color {
	h = normHue(h)
	c := (1 - math.Abs(2*l-1)) * s
	x := c * (1 - math.Abs(math.Mod(h/60, 2)-1))
	m := l - c/2
	var r, g, b float64
	switch {
	case h < 60:
		r, g, b = c, x, 0
	case h < 120:
		r, g, b = x, c, 0
	case h < 180:
		r, g, b = 0, c, x
	case h < 240:
		r, g, b = 0, x, c
	case h < 300:
		r, g, b = x, 0, c
	default:
		r, g, b = c, 0, x
	}
	return Color{(r + m) * 255, (g + m) * 255, (b + m) * 255, a}
}

func rgbToHsv(c Color) (float64, float64, float64) {
	r, g, b := c.R/255, c.G/255, c.B/255
	mx := math.Max(r, math.Max(g, b))
	mn := math.Min(r, math.Min(g, b))
	d := mx - mn
	h := 0.0
	if d != 0 {
		if mx == r {
			h = 60 * math.Mod((g-b)/d, 6)
		} else if mx == g {
			h = 60 * ((b-r)/d + 2)
		} else {
			h = 60 * ((r-g)/d + 4)
		}
	}
	s := 0.0
	if mx != 0 {
		s = d / mx
	}
	return normHue(h), s, mx
}
func hsvToRgb(h, s, v, a float64) Color {
	return hslToRgb(h, s*v/(1-math.Abs(2*(v-v*s/2)-1)+1e-12), v-v*s/2, a)
}

func formatHSLColor(c Color) string {
	c.R, c.G, c.B = float64(ir(c.R)), float64(ir(c.G)), float64(ir(c.B))
	h, s, l := rgbToHsl(c)
	return formatHSL(h, s, l, c.A, false)
}
func formatHSL(h, s, l, a float64, spaces bool) string {
	sep := ","
	if spaces {
		sep = ", "
	}
	if a < 0.999 {
		return fmt.Sprintf("hsla(%.0f%s%.1f%%%s%.1f%%%s%.3g)", normHue(h), sep, clamp(s, 0, 1)*100, sep, clamp(l, 0, 1)*100, sep, a)
	}
	return fmt.Sprintf("hsl(%.0f%s%.1f%%%s%.1f%%)", normHue(h), sep, clamp(s, 0, 1)*100, sep, clamp(l, 0, 1)*100)
}

func luminance(c Color) float64 {
	return 0.2126*srgbToLinear(c.R/255) + 0.7152*srgbToLinear(c.G/255) + 0.0722*srgbToLinear(c.B/255)
}
func srgbToLinear(v float64) float64 {
	if v <= 0.04045 {
		return v / 12.92
	}
	return math.Pow((v+0.055)/1.055, 2.4)
}
func linearToSrgb(v float64) float64 {
	if v <= 0.0031308 {
		return 12.92 * v
	}
	return 1.055*math.Pow(v, 1/2.4) - 0.055
}

func lab(c Color) (float64, float64, float64) {
	r, g, b := srgbToLinear(c.R/255), srgbToLinear(c.G/255), srgbToLinear(c.B/255)
	x := r*0.4124564 + g*0.3575761 + b*0.1804375
	y := r*0.2126729 + g*0.7151522 + b*0.0721750
	z := r*0.0193339 + g*0.1191920 + b*0.9503041
	x /= 0.95047
	z /= 1.08883
	f := func(t float64) float64 {
		if t > 0.008856 {
			return math.Cbrt(t)
		}
		return 7.787*t + 16.0/116
	}
	fx, fy, fz := f(x), f(y), f(z)
	return 116*fy - 16, 500 * (fx - fy), 200 * (fy - fz)
}

func labToRGB(L, a, b, alpha float64) Color {
	fy := (L + 16) / 116
	fx := fy + a/500
	fz := fy - b/200
	finv := func(t float64) float64 {
		t3 := t * t * t
		if t3 > 0.008856 {
			return t3
		}
		return (t - 16.0/116) / 7.787
	}
	x := 0.95047 * finv(fx)
	y := finv(fy)
	z := 1.08883 * finv(fz)
	r := 3.2404542*x - 1.5371385*y - 0.4985314*z
	g := -0.9692660*x + 1.8760108*y + 0.0415560*z
	bl := 0.0556434*x - 0.2040259*y + 1.0572252*z
	return Color{clamp(linearToSrgb(r)*255, 0, 255), clamp(linearToSrgb(g)*255, 0, 255), clamp(linearToSrgb(bl)*255, 0, 255), alpha}
}

func oklab(c Color) (float64, float64, float64) {
	r, g, b := srgbToLinear(c.R/255), srgbToLinear(c.G/255), srgbToLinear(c.B/255)
	l := math.Cbrt(0.4122214708*r + 0.5363325363*g + 0.0514459929*b)
	m := math.Cbrt(0.2119034982*r + 0.6806995451*g + 0.1073969566*b)
	s := math.Cbrt(0.0883024619*r + 0.2817188376*g + 0.6299787005*b)
	return 0.2104542553*l + 0.7936177850*m - 0.0040720468*s, 1.9779984951*l - 2.4285922050*m + 0.4505937099*s, 0.0259040371*l + 0.7827717662*m - 0.8086757660*s
}

func oklabToRGB(L, a, b, alpha float64) Color {
	l := L + 0.3963377774*a + 0.2158037573*b
	m := L - 0.1055613458*a - 0.0638541728*b
	s := L - 0.0894841775*a - 1.2914855480*b
	l, m, s = l*l*l, m*m*m, s*s*s
	r := +4.0767416621*l - 3.3077115913*m + 0.2309699292*s
	g := -1.2684380046*l + 2.6097574011*m - 0.3413193965*s
	bl := -0.0041960863*l - 0.7034186147*m + 1.7076147010*s
	return Color{clamp(linearToSrgb(r)*255, 0, 255), clamp(linearToSrgb(g)*255, 0, 255), clamp(linearToSrgb(bl)*255, 0, 255), alpha}
}

func nearestName(c Color) string {
	best := ""
	bd := math.MaxFloat64
	for n, v := range names {
		d := sq(c.R-v.R) + sq(c.G-v.G) + sq(c.B-v.B)
		if d < bd {
			bd = d
			best = n
		}
	}
	return best
}
func ansi256(c Color) int {
	best := 0
	bd := math.MaxFloat64
	l1, a1, b1 := lab(c)
	for i := 0; i < 256; i++ {
		p := ansiPalette(i)
		l2, a2, b2 := lab(p)
		d := sq(l1-l2) + sq(a1-a2) + sq(b1-b2)
		if d < bd {
			best, bd = i, d
		}
	}
	return best
}

func ansiPalette(i int) Color {
	base := []Color{{0, 0, 0, 1}, {128, 0, 0, 1}, {0, 128, 0, 1}, {128, 128, 0, 1}, {0, 0, 128, 1}, {128, 0, 128, 1}, {0, 128, 128, 1}, {192, 192, 192, 1}, {128, 128, 128, 1}, {255, 0, 0, 1}, {0, 255, 0, 1}, {255, 255, 0, 1}, {0, 0, 255, 1}, {255, 0, 255, 1}, {0, 255, 255, 1}, {255, 255, 255, 1}}
	if i < 16 {
		return base[i]
	}
	if i >= 232 {
		v := float64(8 + (i-232)*10)
		return Color{v, v, v, 1}
	}
	j := i - 16
	levels := []float64{0, 95, 135, 175, 215, 255}
	return Color{levels[j/36], levels[(j/6)%6], levels[j%6], 1}
}

func arg(args []string, i int, def string) string {
	if i < len(args) {
		return args[i]
	}
	return def
}
func mustFloat(s string) float64 {
	v, err := strconv.ParseFloat(s, 64)
	if err != nil {
		os.Exit(2)
	}
	return v
}
func ir(v float64) int { return int(math.Round(clamp(v, 0, 255))) }
func clamp(v, a, b float64) float64 {
	if v < a {
		return a
	}
	if v > b {
		return b
	}
	return v
}
func normHue(h float64) float64 {
	h = math.Mod(h, 360)
	if h < 0 {
		h += 360
	}
	if math.Abs(h-360) < 1e-9 {
		return 0
	}
	return h
}
func max3(a, b, c float64) float64 { return math.Max(a, math.Max(b, c)) }
func min3(a, b, c float64) float64 { return math.Min(a, math.Min(b, c)) }
func sq(v float64) float64         { return v * v }
