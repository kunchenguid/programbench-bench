module zoxide-reimpl

go 1.21
