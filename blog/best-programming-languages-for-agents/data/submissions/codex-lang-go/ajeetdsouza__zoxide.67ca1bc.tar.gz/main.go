package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "0.9.9"

type Entry struct {
	Path string  `json:"path"`
	Rank float64 `json:"rank"`
	Time int64   `json:"time"`
}

type DB struct {
	Entries []Entry `json:"entries"`
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		printMainHelp(stdout)
		return 0
	}
	switch args[0] {
	case "-h", "--help":
		printMainHelp(stdout)
		return 0
	case "-V", "--version":
		fmt.Fprintln(stdout, "zoxide "+version)
		return 0
	case "add":
		return cmdAdd(args[1:], stdout, stderr)
	case "remove":
		return cmdRemove(args[1:], stdout, stderr)
	case "query":
		return cmdQuery(args[1:], stdout, stderr)
	case "import":
		return cmdImport(args[1:], stdout, stderr)
	case "init":
		return cmdInit(args[1:], stdout, stderr)
	case "edit":
		return cmdEdit(args[1:], stdout, stderr)
	default:
		fmt.Fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n", args[0])
		return 2
	}
}

func dataDir() string {
	if v := os.Getenv("_ZO_DATA_DIR"); v != "" {
		return v
	}
	if v := os.Getenv("XDG_DATA_HOME"); v != "" {
		return filepath.Join(v, "zoxide")
	}
	if h := os.Getenv("HOME"); h != "" {
		return filepath.Join(h, ".local", "share", "zoxide")
	}
	return "."
}

func dbPath() string { return filepath.Join(dataDir(), "db.zo") }

func loadDB() DB {
	b, err := os.ReadFile(dbPath())
	if err != nil {
		return DB{}
	}
	var db DB
	if json.Unmarshal(b, &db) == nil {
		return db
	}
	return DB{}
}

func saveDB(db DB) error {
	if err := os.MkdirAll(dataDir(), 0755); err != nil {
		return err
	}
	b, err := json.MarshalIndent(db, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(dbPath(), b, 0644)
}

func cleanPath(p string) (string, error) {
	if strings.HasPrefix(p, "~") {
		if h := os.Getenv("HOME"); h != "" {
			if p == "~" {
				p = h
			} else if strings.HasPrefix(p, "~/") {
				p = filepath.Join(h, p[2:])
			}
		}
	}
	abs, err := filepath.Abs(p)
	if err != nil {
		return "", err
	}
	if os.Getenv("_ZO_RESOLVE_SYMLINKS") == "1" {
		if r, err := filepath.EvalSymlinks(abs); err == nil {
			abs = r
		}
	}
	return filepath.Clean(abs), nil
}

func excluded(p string) bool {
	ex := os.Getenv("_ZO_EXCLUDE_DIRS")
	if ex == "" {
		ex = os.Getenv("HOME")
	}
	for _, pat := range filepath.SplitList(ex) {
		if pat == "" {
			continue
		}
		if pat == p {
			return true
		}
		if ok, _ := filepath.Match(pat, p); ok {
			return true
		}
	}
	return false
}

func cmdAdd(args []string, stdout, stderr io.Writer) int {
	if hasHelpVersion("zoxide-add", args, stdout) {
		return 0
	}
	score := 1.0
	var paths []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			paths = append(paths, args[i+1:]...)
			break
		}
		if a == "-s" || a == "--score" {
			if i+1 >= len(args) {
				fmt.Fprintf(stderr, "error: a value is required for '%s <SCORE>'\n", a)
				return 2
			}
			f, err := strconv.ParseFloat(args[i+1], 64)
			if err != nil {
				fmt.Fprintf(stderr, "error: invalid value '%s' for '%s <SCORE>': invalid float literal\n", args[i+1], a)
				return 2
			}
			score = f
			i++
			continue
		}
		paths = append(paths, a)
	}
	if len(paths) == 0 {
		fmt.Fprintln(stderr, "error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.")
		return 2
	}
	db := loadDB()
	now := time.Now().Unix()
	for _, p0 := range paths {
		p, err := cleanPath(p0)
		if err != nil {
			fmt.Fprintf(stderr, "zoxide: %v\n", err)
			return 1
		}
		st, err := os.Stat(p)
		if err != nil || !st.IsDir() {
			fmt.Fprintf(stderr, "zoxide: not a directory: %s\n", p0)
			return 1
		}
		if excluded(p) {
			continue
		}
		found := false
		for i := range db.Entries {
			if db.Entries[i].Path == p {
				db.Entries[i].Rank += score
				db.Entries[i].Time = now
				found = true
				break
			}
		}
		if !found {
			db.Entries = append(db.Entries, Entry{Path: p, Rank: score, Time: now})
		}
	}
	ageDB(&db)
	if err := saveDB(db); err != nil {
		fmt.Fprintf(stderr, "zoxide: %v\n", err)
		return 1
	}
	return 0
}

func ageDB(db *DB) {
	maxAge := 10000.0
	if v := os.Getenv("_ZO_MAXAGE"); v != "" {
		if f, err := strconv.ParseFloat(v, 64); err == nil && f > 0 {
			maxAge = f
		}
	}
	total := 0.0
	for _, e := range db.Entries {
		total += e.Rank
	}
	if total <= maxAge {
		return
	}
	scale := maxAge * 0.9 / total
	for i := range db.Entries {
		db.Entries[i].Rank *= scale
	}
}

func cmdRemove(args []string, stdout, stderr io.Writer) int {
	if hasHelpVersion("zoxide-remove", args, stdout) {
		return 0
	}
	var paths []string
	for i, a := range args {
		if a == "--" {
			paths = append(paths, args[i+1:]...)
			break
		}
		paths = append(paths, a)
	}
	if len(paths) == 0 {
		return 0
	}
	remove := map[string]bool{}
	for _, p0 := range paths {
		p, _ := cleanPath(p0)
		remove[p] = true
	}
	db := loadDB()
	out := db.Entries[:0]
	for _, e := range db.Entries {
		if !remove[e.Path] {
			out = append(out, e)
		}
	}
	db.Entries = out
	if err := saveDB(db); err != nil {
		fmt.Fprintf(stderr, "zoxide: %v\n", err)
		return 1
	}
	return 0
}

type qopts struct {
	all, interactive, list, score bool
	exclude, base                 string
	keywords                      []string
}

func cmdQuery(args []string, stdout, stderr io.Writer) int {
	if hasHelpVersion("zoxide-query", args, stdout) {
		return 0
	}
	var o qopts
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			o.keywords = append(o.keywords, args[i+1:]...)
			break
		}
		switch a {
		case "-a", "--all":
			o.all = true
		case "-i", "--interactive":
			o.interactive = true
		case "-l", "--list":
			o.list = true
		case "-s", "--score":
			o.score = true
		case "--exclude", "--base-dir":
			if i+1 >= len(args) {
				fmt.Fprintf(stderr, "error: a value is required for '%s <path>'\n", a)
				return 2
			}
			p, _ := cleanPath(args[i+1])
			if a == "--exclude" {
				o.exclude = p
			} else {
				o.base = p
			}
			i++
		default:
			o.keywords = append(o.keywords, a)
		}
	}
	matches := findMatches(loadDB(), o)
	if o.interactive {
		return interactive(matches, stdout, stderr)
	}
	if o.list {
		for _, m := range matches {
			if o.score {
				fmt.Fprintf(stdout, "%6.1f %s\n", frecency(m), m.Path)
			} else {
				fmt.Fprintln(stdout, m.Path)
			}
		}
		return 0
	}
	if len(matches) == 0 {
		fmt.Fprintln(stderr, "zoxide: no match found")
		return 1
	}
	fmt.Fprintln(stdout, matches[0].Path)
	return 0
}

func findMatches(db DB, o qopts) []Entry {
	var out []Entry
	for _, e := range db.Entries {
		if o.exclude != "" && e.Path == o.exclude {
			continue
		}
		if o.base != "" && !pathWithin(e.Path, o.base) {
			continue
		}
		if !o.all {
			if st, err := os.Stat(e.Path); err != nil || !st.IsDir() {
				continue
			}
		}
		if matchPath(e.Path, o.keywords) {
			out = append(out, e)
		}
	}
	sort.SliceStable(out, func(i, j int) bool {
		fi, fj := frecency(out[i]), frecency(out[j])
		if math.Abs(fi-fj) > 1e-9 {
			return fi > fj
		}
		if out[i].Time != out[j].Time {
			return out[i].Time > out[j].Time
		}
		return out[i].Path > out[j].Path
	})
	return out
}

func pathWithin(p, base string) bool {
	if p == base {
		return true
	}
	rel, err := filepath.Rel(base, p)
	return err == nil && rel != ".." && !strings.HasPrefix(rel, "../")
}

func matchPath(p string, keys []string) bool {
	if len(keys) == 0 {
		return true
	}
	lp := strings.ToLower(p)
	for _, k := range keys {
		k = strings.ToLower(k)
		if k == "" {
			continue
		}
		if strings.HasSuffix(k, "/") {
			prefix := strings.TrimSuffix(k, "/")
			ok := false
			for _, part := range strings.Split(lp, "/") {
				if strings.HasPrefix(part, prefix) {
					ok = true
					break
				}
			}
			if !ok {
				return false
			}
			continue
		}
		if k == "/" {
			continue
		}
		if !strings.Contains(lp, k) {
			return false
		}
	}
	return true
}

func frecency(e Entry) float64 {
	age := time.Now().Unix() - e.Time
	mul := 0.25
	switch {
	case age < 3600:
		mul = 4
	case age < 86400:
		mul = 2
	case age < 604800:
		mul = 0.5
	}
	return e.Rank * mul
}

func interactive(matches []Entry, stdout, stderr io.Writer) int {
	if len(matches) == 0 {
		fmt.Fprintln(stderr, "zoxide: no match found")
		return 1
	}
	cmd := exec.Command("fzf")
	var lines []string
	for _, e := range matches {
		lines = append(lines, e.Path)
	}
	cmd.Stdin = strings.NewReader(strings.Join(lines, "\n") + "\n")
	if os.Getenv("_ZO_FZF_OPTS") != "" {
		cmd.Args = append(cmd.Args, strings.Fields(os.Getenv("_ZO_FZF_OPTS"))...)
	}
	b, err := cmd.Output()
	if err != nil {
		fmt.Fprintln(stderr, "zoxide: fzf returned an unknown error")
		return 1
	}
	fmt.Fprint(stdout, string(b))
	return 0
}

func cmdImport(args []string, stdout, stderr io.Writer) int {
	if hasHelpVersion("zoxide-import", args, stdout) {
		return 0
	}
	from := ""
	merge := false
	var path string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--merge":
			merge = true
		case a == "--from":
			if i+1 >= len(args) {
				fmt.Fprintln(stderr, "error: a value is required for '--from <FROM>'")
				return 2
			}
			from = args[i+1]
			i++
		case strings.HasPrefix(a, "--from="):
			from = strings.TrimPrefix(a, "--from=")
		default:
			path = a
		}
	}
	if from == "" || path == "" {
		fmt.Fprintln(stderr, "error: the following required arguments were not provided:\n  --from <FROM>\n  <PATH>\n\nUsage: executable import --from <FROM> <PATH>\n\nFor more information, try '--help'.")
		return 2
	}
	entries, err := parseImport(from, path)
	if err != nil {
		fmt.Fprintln(stderr, "zoxide: import error")
		fmt.Fprintln(stderr)
		fmt.Fprintln(stderr, "Caused by:")
		fmt.Fprintf(stderr, "    0: %v\n", err)
		return 1
	}
	db := DB{}
	if merge {
		db = loadDB()
	}
	for _, e := range entries {
		addEntry(&db, e)
	}
	if err := saveDB(db); err != nil {
		fmt.Fprintf(stderr, "zoxide: %v\n", err)
		return 1
	}
	return 0
}

func parseImport(from, path string) ([]Entry, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	now := time.Now().Unix()
	var entries []Entry
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var p string
		var rank float64
		var ts int64 = now
		switch from {
		case "z":
			parts := strings.Split(line, "|")
			if len(parts) < 2 {
				return nil, errors.New("invalid entry")
			}
			p = parts[0]
			var err error
			rank, err = strconv.ParseFloat(parts[1], 64)
			if err != nil {
				return nil, fmt.Errorf("invalid rank: %s", p)
			}
			if len(parts) > 2 {
				if t, err := strconv.ParseInt(parts[2], 10, 64); err == nil {
					ts = t
				}
			}
		case "autojump":
			fields := strings.Fields(line)
			if len(fields) < 2 {
				return nil, errors.New("invalid entry")
			}
			r, err := strconv.ParseFloat(fields[0], 64)
			if err == nil {
				rank = r
				p = strings.Join(fields[1:], " ")
			} else {
				rank, err = strconv.ParseFloat(fields[len(fields)-1], 64)
				if err != nil {
					return nil, fmt.Errorf("invalid rank: %s", fields[0])
				}
				p = strings.Join(fields[:len(fields)-1], " ")
			}
		default:
			return nil, fmt.Errorf("invalid value '%s' for '--from <FROM>'", from)
		}
		cp, err := cleanPath(p)
		if err != nil {
			return nil, err
		}
		if st, err := os.Stat(cp); err == nil && st.IsDir() {
			entries = append(entries, Entry{Path: cp, Rank: rank, Time: ts})
		}
	}
	return entries, sc.Err()
}

func addEntry(db *DB, e Entry) {
	for i := range db.Entries {
		if db.Entries[i].Path == e.Path {
			db.Entries[i].Rank += e.Rank
			if e.Time > db.Entries[i].Time {
				db.Entries[i].Time = e.Time
			}
			return
		}
	}
	db.Entries = append(db.Entries, e)
}

func cmdEdit(args []string, stdout, stderr io.Writer) int {
	if hasHelpVersion("zoxide-edit", args, stdout) {
		return 0
	}
	return interactive(findMatches(loadDB(), qopts{list: true}), stdout, stderr)
}

func cmdInit(args []string, stdout, stderr io.Writer) int {
	if hasHelpVersion("zoxide-init", args, stdout) {
		return 0
	}
	cmdName := "z"
	hook := "pwd"
	noCmd := false
	var shell string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--no-cmd":
			noCmd = true
		case a == "--cmd" || a == "--hook":
			if i+1 >= len(args) {
				fmt.Fprintf(stderr, "error: a value is required for '%s'\n", a)
				return 2
			}
			if a == "--cmd" {
				cmdName = args[i+1]
			} else {
				hook = args[i+1]
			}
			i++
		case strings.HasPrefix(a, "--cmd="):
			cmdName = strings.TrimPrefix(a, "--cmd=")
		case strings.HasPrefix(a, "--hook="):
			hook = strings.TrimPrefix(a, "--hook=")
		default:
			shell = a
		}
	}
	if shell == "" {
		fmt.Fprintln(stderr, "error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable init <SHELL>\n\nFor more information, try '--help'.")
		return 2
	}
	if !contains([]string{"bash", "elvish", "fish", "nushell", "posix", "powershell", "tcsh", "xonsh", "zsh"}, shell) {
		fmt.Fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n", shell)
		return 2
	}
	printInit(stdout, shell, cmdName, hook, noCmd)
	return 0
}

func printInit(w io.Writer, shell, cmdName, hook string, noCmd bool) {
	switch shell {
	case "fish":
		fmt.Fprintln(w, "# =============================================================================")
		fmt.Fprintln(w, "function __zoxide_pwd\n    builtin pwd -L\nend")
		fmt.Fprintln(w, "function __zoxide_z\n    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)\n    and cd $result\nend")
		if !noCmd {
			fmt.Fprintf(w, "alias %s=__zoxide_z\nalias %si=__zoxide_zi\n", cmdName, cmdName)
		}
	case "powershell":
		fmt.Fprintln(w, "# =============================================================================")
		fmt.Fprintln(w, "function global:__zoxide_pwd { (Get-Location).ProviderPath }")
		fmt.Fprintln(w, "function global:__zoxide_z { $result = zoxide query --exclude (__zoxide_pwd) -- $args; if ($?) { Set-Location $result } }")
		if !noCmd {
			fmt.Fprintf(w, "Set-Alias -Name %s -Value __zoxide_z\nSet-Alias -Name %si -Value __zoxide_zi\n", cmdName, cmdName)
		}
	case "nushell":
		fmt.Fprintln(w, "# Code generated by zoxide. DO NOT EDIT.")
		fmt.Fprintln(w, "def --env --wrapped __zoxide_z [...rest: string] { cd (^zoxide query --exclude $env.PWD -- ...$rest | str trim -r -c \"\\n\") }")
		if !noCmd {
			fmt.Fprintf(w, "alias %s = __zoxide_z\nalias %si = __zoxide_zi\n", cmdName, cmdName)
		}
	case "tcsh":
		fmt.Fprintln(w, "# =============================================================================")
		fmt.Fprintln(w, "alias __zoxide_hook 'zoxide add -- \"`pwd -L`\"'")
		if !noCmd {
			fmt.Fprintf(w, "alias %s __zoxide_z\nalias %si __zoxide_zi\n", cmdName, cmdName)
		}
	case "xonsh":
		fmt.Fprintln(w, "# pylint: disable=missing-module-docstring")
		fmt.Fprintln(w, "def __zoxide_z(args):\n    import subprocess, os\n    p = subprocess.check_output(['zoxide','query','--exclude',os.getcwd(),'--'] + args).decode().strip()\n    __xonsh__.builtins.cd([p])")
	case "elvish":
		fmt.Fprintln(w, "use builtin\nuse path")
		fmt.Fprintln(w, "fn __zoxide_z {|@rest| var path = (zoxide query --exclude $pwd -- $@rest); builtin:cd $path }")
		if !noCmd {
			fmt.Fprintf(w, "edit:add-var %s~ $__zoxide_z~\nedit:add-var %si~ $__zoxide_zi~\n", cmdName, cmdName)
		}
	default:
		if shell == "posix" {
			fmt.Fprintln(w, "# shellcheck shell=sh")
		} else {
			fmt.Fprintln(w, "# shellcheck shell=bash")
		}
		fmt.Fprintln(w, "\n# =============================================================================")
		fmt.Fprintln(w, "#\n# Utility functions for zoxide.\n#")
		if shell == "zsh" || shell == "bash" {
			fmt.Fprintln(w, "function __zoxide_pwd() {\n    \\builtin pwd -L\n}")
			fmt.Fprintln(w, "function __zoxide_cd() {\n    \\builtin cd -- \"$@\"\n}")
			if hook != "none" {
				fmt.Fprintln(w, "function __zoxide_hook() {\n    \\command zoxide add -- \"$(__zoxide_pwd)\"\n}")
			}
			fmt.Fprintln(w, "function __zoxide_z() {\n    if [[ \"$#\" -eq 0 ]]; then __zoxide_cd ~; else result=\"$(\\command zoxide query --exclude \"$(__zoxide_pwd)\" -- \"$@\")\" && __zoxide_cd \"$result\"; fi\n}")
		} else {
			fmt.Fprintln(w, "__zoxide_pwd() {\n    \\command pwd -L\n}")
			fmt.Fprintln(w, "__zoxide_z() {\n    __zoxide_result=\"$(\\command zoxide query --exclude \"$(__zoxide_pwd || \\command true)\" -- \"$@\")\" && \\command cd \"$__zoxide_result\"\n}")
		}
		if !noCmd {
			fmt.Fprintf(w, "\n%s() {\n    __zoxide_z \"$@\"\n}\n\n%si() {\n    __zoxide_zi \"$@\"\n}\n", cmdName, cmdName)
		}
	}
}

func contains(xs []string, x string) bool {
	for _, v := range xs {
		if v == x {
			return true
		}
	}
	return false
}

func hasHelpVersion(name string, args []string, stdout io.Writer) bool {
	for _, a := range args {
		if a == "-h" || a == "--help" {
			switch name {
			case "zoxide-add":
				printAddHelp(stdout)
			case "zoxide-remove":
				printRemoveHelp(stdout)
			case "zoxide-query":
				printQueryHelp(stdout)
			case "zoxide-import":
				printImportHelp(stdout)
			case "zoxide-init":
				printInitHelp(stdout)
			case "zoxide-edit":
				printEditHelp(stdout)
			}
			return true
		}
		if a == "-V" || a == "--version" {
			fmt.Fprintln(stdout, name+" "+version)
			return true
		}
	}
	return false
}

func header(w io.Writer, name, desc string) {
	fmt.Fprintf(w, "%s %s\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\n%s\n\n", name, version, desc)
}

func envHelp(w io.Writer) {
	fmt.Fprintln(w, "Environment variables:")
	fmt.Fprintln(w, "  _ZO_DATA_DIR          Path for zoxide data files")
	fmt.Fprintln(w, "  _ZO_ECHO              Print the matched directory before navigating to it when set to 1")
	fmt.Fprintln(w, "  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded")
	fmt.Fprintln(w, "  _ZO_FZF_OPTS          Custom flags to pass to fzf")
	fmt.Fprintln(w, "  _ZO_MAXAGE            Maximum total age after which entries start getting deleted")
	fmt.Fprintln(w, "  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths")
}

func printMainHelp(w io.Writer) {
	header(w, "zoxide", "A smarter cd command for your terminal")
	fmt.Fprintln(w, "Usage:\n  executable <COMMAND>\n\nCommands:\n  add     Add a new directory or increment its rank\n  edit    Edit the database\n  import  Import entries from another application\n  init    Generate shell configuration\n  query   Search for a directory in the database\n  remove  Remove a directory from the database\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n")
	envHelp(w)
}

func printAddHelp(w io.Writer) {
	header(w, "zoxide-add", "Add a new directory or increment its rank")
	fmt.Fprintln(w, "Usage:\n  executable add [OPTIONS] <PATHS>...\n\nArguments:\n  <PATHS>...  \n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't\n  -h, --help           Print help\n  -V, --version        Print version\n")
	envHelp(w)
}
func printRemoveHelp(w io.Writer) {
	header(w, "zoxide-remove", "Remove a directory from the database")
	fmt.Fprintln(w, "Usage:\n  executable remove [PATHS]...\n\nArguments:\n  [PATHS]...  \n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n")
	envHelp(w)
}
func printQueryHelp(w io.Writer) {
	header(w, "zoxide-query", "Search for a directory in the database")
	fmt.Fprintln(w, "Usage:\n  executable query [OPTIONS] [KEYWORDS]...\n\nArguments:\n  [KEYWORDS]...  \n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory\n  -h, --help             Print help\n  -V, --version          Print version\n")
	envHelp(w)
}
func printImportHelp(w io.Writer) {
	header(w, "zoxide-import", "Import entries from another application")
	fmt.Fprintln(w, "Usage:\n  executable import [OPTIONS] --from <FROM> <PATH>\n\nArguments:\n  <PATH>  \n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database\n  -h, --help         Print help\n  -V, --version      Print version\n")
	envHelp(w)
}
func printInitHelp(w io.Writer) {
	header(w, "zoxide-init", "Generate shell configuration")
	fmt.Fprintln(w, "Usage:\n  executable init [OPTIONS] <SHELL>\n\nArguments:\n  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]\n  -h, --help         Print help\n  -V, --version      Print version\n")
	envHelp(w)
}
func printEditHelp(w io.Writer) {
	header(w, "zoxide-edit", "Edit the database")
	fmt.Fprintln(w, "Usage:\n  executable edit\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n")
	envHelp(w)
}
