package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/base64"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"math/rand"
	"mime/multipart"
	"net"
	"net/http"
	"net/http/httptrace"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const helpText = `Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger ` + "`-c`" + `. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. ` + "`oha`" + ` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with ` + "`-w`" + ` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. ` + "`-w`" + ` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version
`

type options struct {
	n int64; c int; p int; duration time.Duration; wait bool; qps float64
	burstDelay time.Duration; burstRate int; randRegex bool; urlsFromFile bool; maxRepeat int; dumpURLs int
	noTUI bool; method string; headers []string; proxyHeaders []string; timeout time.Duration; connectTimeout time.Duration
	accept string; bodyString string; bodyPath string; bodyPathLines string; forms []string; contentType string
	auth string; proxy string; httpVersion string; host string; redirects int; disableKeepalive bool; insecure bool
	output string; outputFormat string; timeUnit string; debug bool; unixSocket string
	target string
}

type result struct {
	start, dns, dial, respDelay, dur float64
	bytes int64
	status int
	err string
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil { fmt.Fprint(os.Stderr, err.Error()); os.Exit(2) }
	if opts == nil { return }
	if opts.dumpURLs > 0 {
		for i := 0; i < opts.dumpURLs; i++ { fmt.Println(genRegexURL(opts.target, opts.maxRepeat)) }
		return
	}
	if opts.debug { if err := debugRequest(*opts); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }; return }
	res, elapsed := run(*opts)
	if opts.outputFormat == "quiet" { return }
	var out io.Writer = os.Stdout
	if opts.output != "" {
		f, e := os.Create(opts.output); if e != nil { fmt.Fprintln(os.Stderr, e); os.Exit(1) }
		defer f.Close(); out = f
	}
	switch opts.outputFormat {
	case "json": writeJSON(out, res, elapsed)
	case "csv": writeCSV(out, res)
	default: writeText(out, res, elapsed, opts.timeUnit)
	}
}

func parseArgs(args []string) (*options, error) {
	args = expandEquals(args)
	o := &options{n:200,c:50,p:1,maxRepeat:4,burstRate:1,method:"GET",connectTimeout:5*time.Second,redirects:10,outputFormat:"text"}
	need := func(i *int, name string) (string, error) { *i++; if *i >= len(args) { return "", fmt.Errorf("error: a value is required for '%s <...>' but none was supplied\n\nFor more information, try '--help'.\n", name) }; return args[*i], nil }
	for i:=0;i<len(args);i++ {
		a:=args[i]
		switch a {
		case "-h","--help": fmt.Print(helpText); return nil,nil
		case "-V","--version": fmt.Println("oha 1.12.1"); return nil,nil
		case "-n": v,e:=need(&i,"-n"); if e!=nil{return nil,e}; n,e:=parseCount(v); if e!=nil{return nil,fmt.Errorf("error: invalid value '%s' for '-n <N_REQUESTS>': invalid digit found in string\n\nFor more information, try '--help'.\n",v)}; o.n=n
		case "-c": v,e:=need(&i,"-c"); if e!=nil{return nil,e}; o.c,_=strconv.Atoi(v); if o.c<1{o.c=1}
		case "-p": v,e:=need(&i,"-p"); if e!=nil{return nil,e}; o.p,_=strconv.Atoi(v); if o.p<1{o.p=1}
		case "-z": v,e:=need(&i,"-z"); if e!=nil{return nil,e}; o.duration, _=time.ParseDuration(v)
		case "-w","--wait-ongoing-requests-after-deadline": o.wait=true
		case "-q": v,e:=need(&i,"-q"); if e!=nil{return nil,e}; o.qps,_=strconv.ParseFloat(v,64)
		case "--burst-delay": v,e:=need(&i,"--burst-delay"); if e!=nil{return nil,e}; o.burstDelay,_=time.ParseDuration(v)
		case "--burst-rate": v,e:=need(&i,"--burst-rate"); if e!=nil{return nil,e}; o.burstRate,_=strconv.Atoi(v); if o.burstRate<1{o.burstRate=1}
		case "--rand-regex-url": o.randRegex=true
		case "--urls-from-file": o.urlsFromFile=true
		case "--max-repeat": v,e:=need(&i,"--max-repeat"); if e!=nil{return nil,e}; o.maxRepeat,_=strconv.Atoi(v)
		case "--dump-urls": v,e:=need(&i,"--dump-urls"); if e!=nil{return nil,e}; o.dumpURLs,_=strconv.Atoi(v)
		case "--latency-correction","--no-color","--proxy-http2","--http2","--disable-compression","--no-pre-lookup","--ipv6","--ipv4","--stats-success-breakdown": // accepted no-op
		case "--no-tui": o.noTUI=true
		case "--fps","--proxy-http-version","--http-version","--cacert","--cert","--key","--connect-to","--db-url","--aws-session","--aws-sigv4": _,e:=need(&i,a); if e!=nil{return nil,e}
		case "-m","--method": v,e:=need(&i,a); if e!=nil{return nil,e}; o.method=v
		case "-H": v,e:=need(&i,"-H"); if e!=nil{return nil,e}; if !strings.Contains(v,":"){return nil,fmt.Errorf("error: invalid value '%s' for '-H <HEADERS>': Parse header\n\nFor more information, try '--help'.\n",v)}; o.headers=append(o.headers,v)
		case "--proxy-header": v,e:=need(&i,a); if e!=nil{return nil,e}; o.proxyHeaders=append(o.proxyHeaders,v)
		case "-t": v,e:=need(&i,"-t"); if e!=nil{return nil,e}; o.timeout,_=time.ParseDuration(v)
		case "--connect-timeout": v,e:=need(&i,a); if e!=nil{return nil,e}; o.connectTimeout,_=time.ParseDuration(v)
		case "-A": v,e:=need(&i,"-A"); if e!=nil{return nil,e}; o.accept=v
		case "-d": v,e:=need(&i,"-d"); if e!=nil{return nil,e}; o.bodyString=v
		case "-D": v,e:=need(&i,"-D"); if e!=nil{return nil,e}; o.bodyPath=v
		case "-Z": v,e:=need(&i,"-Z"); if e!=nil{return nil,e}; o.bodyPathLines=v
		case "-F","--form": v,e:=need(&i,a); if e!=nil{return nil,e}; o.forms=append(o.forms,v)
		case "-T": v,e:=need(&i,"-T"); if e!=nil{return nil,e}; o.contentType=v
		case "-a": v,e:=need(&i,"-a"); if e!=nil{return nil,e}; o.auth=v
		case "-x": v,e:=need(&i,"-x"); if e!=nil{return nil,e}; o.proxy=v
		case "--host": v,e:=need(&i,a); if e!=nil{return nil,e}; o.host=v
		case "-r","--redirect": v,e:=need(&i,a); if e!=nil{return nil,e}; o.redirects,_=strconv.Atoi(v)
		case "--disable-keepalive": o.disableKeepalive=true
		case "--insecure": o.insecure=true
		case "--unix-socket": v,e:=need(&i,a); if e!=nil{return nil,e}; o.unixSocket=v
		case "-o","--output": v,e:=need(&i,a); if e!=nil{return nil,e}; o.output=v
		case "--output-format": v,e:=need(&i,a); if e!=nil{return nil,e}; if v!="text"&&v!="json"&&v!="csv"&&v!="quiet"{return nil,fmt.Errorf("error: invalid value '%s' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]\n\nFor more information, try '--help'.\n",v)}; o.outputFormat=v
		case "-u","--time-unit": v,e:=need(&i,a); if e!=nil{return nil,e}; o.timeUnit=v
		case "--debug": o.debug=true
		default:
			if strings.HasPrefix(a,"--") { return nil, fmt.Errorf("error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", a) }
			if strings.HasPrefix(a,"-") { return nil, fmt.Errorf("error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", a) }
			if o.target=="" { o.target=a } else { return nil, fmt.Errorf("error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", a) }
		}
	}
	if o.target=="" { fmt.Print(helpText); return nil, fmt.Errorf("") }
	return o,nil
}

func expandEquals(args []string) []string {
	var out []string
	for _, a := range args {
		if strings.HasPrefix(a, "--") && strings.Contains(a, "=") {
			p := strings.SplitN(a, "=", 2)
			out = append(out, p[0], p[1])
		} else {
			out = append(out, a)
		}
	}
	return out
}

func parseCount(s string)(int64,error){ mult:=int64(1); x:=strings.ToLower(s); if strings.HasSuffix(x,"k"){mult=1000; x=strings.TrimSuffix(x,"k")} else if strings.HasSuffix(x,"m"){mult=1000000; x=strings.TrimSuffix(x,"m")}; n,e:=strconv.ParseInt(x,10,64); return n*mult,e }

func run(o options)([]result,time.Duration){
	urls:=loadURLs(o)
	client:=makeClient(o)
	workers:=o.c*o.p; if workers<1{workers=1}
	ctx:=context.Background(); cancel:=func(){}
	if o.duration>0 { ctx,cancel=context.WithTimeout(ctx,o.duration); defer cancel() }
	start:=time.Now(); jobs:=make(chan int); results:=make(chan result, workers); var idx int64
	var wg sync.WaitGroup
	for w:=0;w<workers;w++{ wg.Add(1); go func(){ defer wg.Done(); for range jobs { u:=urls[int(atomic.AddInt64(&idx,1)-1)%len(urls)]; if o.randRegex{u=genRegexURL(u,o.maxRepeat)}; results<-one(ctx,client,o,u,start) } }() }
	go func(){ defer close(jobs); sent:=int64(0); burst:=0
		var tick <-chan time.Time; if o.qps>0 { t:=time.NewTicker(time.Duration(float64(time.Second)/o.qps)); defer t.Stop(); tick=t.C }
		for (o.duration>0 || sent<o.n) {
			select{case <-ctx.Done(): return; default:}
			if tick!=nil { <-tick } else if o.burstDelay>0 && burst>=o.burstRate { time.Sleep(o.burstDelay); burst=0 }
			select{case jobs<-int(sent): sent++; burst++; case <-ctx.Done(): return}
		}
	}()
	go func(){ wg.Wait(); close(results) }()
	var out []result
	for r:= range results { out=append(out,r) }
	return out,time.Since(start)
}

func loadURLs(o options)[]string{
	if !o.urlsFromFile { return []string{o.target} }
	b,e:=os.ReadFile(o.target); if e!=nil { return []string{o.target} }
	var urls []string
	for _,l:=range strings.Split(string(b),"\n"){ l=strings.TrimSpace(l); if l!=""{urls=append(urls,l)} }
	if len(urls)==0{return []string{o.target}}
	return urls
}

func makeClient(o options)*http.Client{
	dialer:=&net.Dialer{Timeout:o.connectTimeout}
	tr:=&http.Transport{DialContext:dialer.DialContext,DisableKeepAlives:o.disableKeepalive,TLSClientConfig:&tls.Config{InsecureSkipVerify:o.insecure}}
	if o.unixSocket!="" { tr.DialContext=func(ctx context.Context,network,addr string)(net.Conn,error){ return dialer.DialContext(ctx,"unix",o.unixSocket)} }
	if o.proxy!="" { if pu,e:=url.Parse(o.proxy); e==nil { tr.Proxy=http.ProxyURL(pu) } }
	c:=&http.Client{Transport:tr}
	if o.timeout>0 { c.Timeout=o.timeout }
	c.CheckRedirect=func(req *http.Request, via []*http.Request) error { if len(via)>=o.redirects { return http.ErrUseLastResponse }; return nil }
	return c
}

func one(ctx context.Context, client *http.Client, o options, u string, base time.Time) result{
	body,ct:=bodyFor(o)
	req,e:=http.NewRequestWithContext(ctx,o.method,u,bytes.NewReader(body)); if e!=nil {return result{start:time.Since(base).Seconds(),err:e.Error()}}
	req.Header.Set("User-Agent","oha/1.12.1")
	if o.accept!=""{req.Header.Set("Accept",o.accept)}
	if ct!=""{req.Header.Set("Content-Type",ct)} else if o.contentType!=""{req.Header.Set("Content-Type",o.contentType)}
	if o.auth!=""{req.Header.Set("Authorization","Basic "+base64.StdEncoding.EncodeToString([]byte(o.auth)))}
	if o.host!=""{req.Host=o.host}
	for _,h:=range o.headers{ parts:=strings.SplitN(h,":",2); req.Header.Set(strings.TrimSpace(parts[0]),strings.TrimSpace(parts[1]))}
	var dnsStart, connStart, gotConn, wrote, first time.Time
	trace:=&httptrace.ClientTrace{
		DNSStart: func(httptrace.DNSStartInfo){dnsStart=time.Now()},
		DNSDone: func(httptrace.DNSDoneInfo){ if !dnsStart.IsZero(){ } },
		ConnectStart: func(_, _ string){ if connStart.IsZero(){connStart=time.Now()} },
		GotConn: func(httptrace.GotConnInfo){gotConn=time.Now()},
		WroteRequest: func(httptrace.WroteRequestInfo){wrote=time.Now()},
		GotFirstResponseByte: func(){first=time.Now()},
	}
	req=req.WithContext(httptrace.WithClientTrace(req.Context(),trace))
	st:=time.Now(); resp,e:=client.Do(req); dur:=time.Since(st)
	r:=result{start:st.Sub(base).Seconds(),dur:dur.Seconds()}
	if !dnsStart.IsZero() && !gotConn.IsZero(){ r.dial=gotConn.Sub(dnsStart).Seconds(); r.dns=r.dial/3 }
	if !first.IsZero(){ if wrote.IsZero(){r.respDelay=first.Sub(st).Seconds()}else{r.respDelay=first.Sub(wrote).Seconds()} }
	if e!=nil { r.err=cleanErr(e); return r }
	defer resp.Body.Close(); n,_:=io.Copy(io.Discard, resp.Body)
	r.bytes=n; r.status=resp.StatusCode; return r
}

func bodyFor(o options)([]byte,string){
	if len(o.forms)>0 { var b bytes.Buffer; mw:=multipart.NewWriter(&b); for _,f:=range o.forms{ if strings.Contains(f,"=@"){p:=strings.SplitN(f,"=@",2); data,_:=os.ReadFile(p[1]); fw,_:=mw.CreateFormFile(p[0],filepath.Base(p[1])); fw.Write(data)}else{p:=strings.SplitN(f,"=",2); val:=""; if len(p)>1{val=p[1]}; mw.WriteField(p[0],val)} }; mw.Close(); return b.Bytes(),mw.FormDataContentType() }
	if o.bodyPath!=""{b,_:=os.ReadFile(o.bodyPath); return b,o.contentType}
	if o.bodyPathLines!=""{b,_:=os.ReadFile(o.bodyPathLines); lines:=strings.Split(strings.TrimRight(string(b),"\n"),"\n"); if len(lines)>0{return []byte(lines[rand.Intn(len(lines))]),o.contentType}}
	return []byte(o.bodyString),o.contentType
}

func cleanErr(e error)string{ s:=e.Error(); if i:=strings.LastIndex(s,": "); i>=0 { tail:=s[i+2:]; if strings.Contains(tail,"connection refused"){return "Connection refused (os error 111)"} }; return s }

func writeCSV(w io.Writer, res []result){ cw:=csv.NewWriter(w); cw.Write([]string{"request-start","DNS","DNS+dialup","Response-delay","request-duration","bytes","status"}); for _,r:=range res{ st:=""; if r.status!=0{st=strconv.Itoa(r.status)}; cw.Write([]string{ff(r.start),ff(r.dns),ff(r.dial),ff(r.respDelay),ff(r.dur),strconv.FormatInt(r.bytes,10),st})}; cw.Flush() }
func ff(f float64)string{ if f==0{return "0"}; return strconv.FormatFloat(f,'f',9,64) }

func successes(res []result)[]result{ var s []result; for _,r:=range res{ if r.err==""{s=append(s,r)} }; return s }
func durations(res []result)[]float64{ s:=successes(res); ds:=make([]float64,len(s)); for i,r:=range s{ds[i]=r.dur}; sort.Float64s(ds); return ds }
func pct(ds []float64,p float64)*float64{ if len(ds)==0{return nil}; idx:=int(math.Ceil(p*float64(len(ds))))-1; if idx<0{idx=0}; if idx>=len(ds){idx=len(ds)-1}; v:=ds[idx]; return &v }
func avg(ds []float64)*float64{ if len(ds)==0{return nil}; var sum float64; for _,d:=range ds{sum+=d}; v:=sum/float64(len(ds)); return &v }
func minmax(ds []float64)(*float64,*float64){ if len(ds)==0{return nil,nil}; return &ds[0],&ds[len(ds)-1] }
func sumBytes(res []result)int64{ var n int64; for _,r:=range successes(res){n+=r.bytes}; return n }

func writeJSON(w io.Writer,res []result,elapsed time.Duration){
	ds:=durations(res); av:=avg(ds); mn,mx:=minmax(ds); total:=elapsed.Seconds(); bytes:=sumBytes(res); count:=len(successes(res))
	status:=map[string]int{}; errs:=map[string]int{}; for _,r:=range res{ if r.err!=""{errs[r.err]++}else{status[strconv.Itoa(r.status)]++} }
	h:=map[string]int{}; if len(ds)==0{h["NaN"]=0}else{for _,d:=range ds{h[strconv.FormatFloat(d,'g',-1,64)]++}}
	obj:=map[string]any{"summary":map[string]any{"successRate":float64(count)/math.Max(1,float64(len(res))),"total":total,"slowest":num(mx),"fastest":num(mn),"average":num(av),"requestsPerSec":float64(len(res))/math.Max(total,1e-9),"totalData":bytes,"sizePerRequest":numFloat(div(float64(bytes),float64(count))),"sizePerSec":float64(bytes)/math.Max(total,1e-9)},"responseTimeHistogram":h,"latencyPercentiles":percentObj(ds),"rps":map[string]any{"mean":nil,"stddev":nil,"max":nil,"min":nil,"percentiles":percentObj(nil)},"details":map[string]any{"DNSDialup":detail(res,func(r result)float64{return r.dial}),"DNSLookup":detail(res,func(r result)float64{return r.dns})},"statusCodeDistribution":status,"errorDistribution":errs}
	enc:=json.NewEncoder(w); enc.SetIndent("","  "); enc.Encode(obj)
}
func num(p *float64)any{ if p==nil{return nil}; return *p }
func numFloat(f float64)any{ if math.IsNaN(f)||math.IsInf(f,0){return nil}; return f }
func div(a,b float64)float64{ if b==0{return math.NaN()}; return a/b}
func percentObj(ds []float64)map[string]any{ return map[string]any{"p10":num(pct(ds,.10)),"p25":num(pct(ds,.25)),"p50":num(pct(ds,.50)),"p75":num(pct(ds,.75)),"p90":num(pct(ds,.90)),"p95":num(pct(ds,.95)),"p99":num(pct(ds,.99)),"p99.9":num(pct(ds,.999)),"p99.99":num(pct(ds,.9999))} }
func detail(res []result, f func(result)float64)map[string]any{ var ds []float64; for _,r:=range successes(res){v:=f(r); if v>0{ds=append(ds,v)}}; sort.Float64s(ds); av:=avg(ds); mn,mx:=minmax(ds); return map[string]any{"average":num(av),"fastest":num(mn),"slowest":num(mx)} }

func writeText(w io.Writer,res []result,elapsed time.Duration,unit string){
	ds:=durations(res); av:=avg(ds); mn,mx:=minmax(ds); bytes:=sumBytes(res); count:=len(successes(res)); total:=elapsed.Seconds()
	fmt.Fprintln(w,"Summary:")
	fmt.Fprintf(w,"  Success rate:\t%.2f%%\n",100*float64(count)/math.Max(1,float64(len(res))))
	fmt.Fprintf(w,"  Total:\t%s\n",fmtTime(total,unit))
	fmt.Fprintf(w,"  Slowest:\t%s\n",fmtPtr(mx,unit,"-inf ns"))
	fmt.Fprintf(w,"  Fastest:\t%s\n",fmtPtr(mn,unit,"inf ns"))
	fmt.Fprintf(w,"  Average:\t%s\n",fmtPtr(av,unit,"NaN ns"))
	fmt.Fprintf(w,"  Requests/sec:\t%.4f\n\n",float64(len(res))/math.Max(total,1e-9))
	fmt.Fprintf(w,"  Total data:\t%s\n",fmtBytes(bytes))
	if count==0{fmt.Fprintln(w,"  Size/request:\tNaN")}else{fmt.Fprintf(w,"  Size/request:\t%s\n",fmtBytes(bytes/int64(count)))}
	fmt.Fprintf(w,"  Size/sec:\t%s\n\n",fmtBytes(int64(float64(bytes)/math.Max(total,1e-9))))
	fmt.Fprintln(w,"Response time histogram:")
	if len(ds)==0{ for i:=0;i<11;i++{fmt.Fprintln(w,"    NaN ns [0] |")} } else { hist(w,ds,unit) }
	fmt.Fprintln(w,"\nResponse time distribution:")
	for _,p:=range []float64{.10,.25,.50,.75,.90,.95,.99,.999,.9999}{ label:=fmt.Sprintf("%.2f%%",p*100); if p>=.999{label=fmt.Sprintf("%.2f%%",p*100)}; fmt.Fprintf(w,"  %s in %s\n",label,fmtPtr(pct(ds,p),unit,"NaN ns")) }
	fmt.Fprintln(w,"\n\nDetails (average, fastest, slowest):")
	writeDetailText(w,"DNS+dialup",res,func(r result)float64{return r.dial},unit); writeDetailText(w,"DNS-lookup",res,func(r result)float64{return r.dns},unit)
	status:=map[int]int{}; errs:=map[string]int{}; for _,r:=range res{if r.err!=""{errs[r.err]++}else{status[r.status]++}}
	fmt.Fprintln(w,"\nStatus code distribution:"); keys:=make([]int,0,len(status)); for k:=range status{keys=append(keys,k)}; sort.Ints(keys); for _,k:=range keys{fmt.Fprintf(w,"  [%d] %d responses\n",k,status[k])}
	if len(errs)>0{fmt.Fprintln(w,"\nError distribution:"); sk:=make([]string,0,len(errs)); for k:=range errs{sk=append(sk,k)}; sort.Strings(sk); for _,k:=range sk{fmt.Fprintf(w,"  [%d] %s\n",errs[k],k)}}
}
func hist(w io.Writer,ds []float64,unit string){ mn:=ds[0]; mx:=ds[len(ds)-1]; step:=(mx-mn)/10; if step==0{step=1e-9}; bins:=make([]int,11); for _,d:=range ds{idx:=int(math.Floor((d-mn)/step)); if idx<0{idx=0}; if idx>10{idx=10}; bins[idx]++}; max:=1; for _,b:=range bins{if b>max{max=b}}; for i,b:=range bins{v:=mn+float64(i)*step; bar:=strings.Repeat("■", int(math.Round(32*float64(b)/float64(max)))); fmt.Fprintf(w,"  %8s [%d] |%s\n",strings.TrimSpace(fmtTime(v,unit)),b,bar)}}
func writeDetailText(w io.Writer,name string,res []result,f func(result)float64,unit string){ var ds []float64; for _,r:=range successes(res){if v:=f(r); v>0{ds=append(ds,v)}}; sort.Float64s(ds); av:=avg(ds); mn,mx:=minmax(ds); fmt.Fprintf(w,"  %s:\t%s, %s, %s\n",name,fmtPtr(av,unit,"NaN ns"),fmtPtr(mn,unit,"inf ns"),fmtPtr(mx,unit,"-inf ns"))}
func fmtPtr(p *float64,unit,fallback string)string{ if p==nil{return fallback}; return fmtTime(*p,unit)}
func fmtTime(sec float64,unit string)string{ mult:=1.0; suf:="s"; switch unit{case "ns":mult=1e9;suf="ns";case "us":mult=1e6;suf="us";case "ms":mult=1e3;suf="ms";case "s":mult=1;suf="s";case "m":mult=1.0/60;suf="m";case "h":mult=1.0/3600;suf="h";default: if sec<1e-6{mult=1e9;suf="ns"}else if sec<1e-3{mult=1e6;suf="us"}else if sec<1{mult=1e3;suf="ms"}else{mult=1;suf="s"}}; return fmt.Sprintf("%.4f %s",sec*mult,suf)}
func fmtBytes(n int64)string{ if n<1024{return fmt.Sprintf("%d B",n)}; if n<1024*1024{return fmt.Sprintf("%.2f KiB",float64(n)/1024)}; return fmt.Sprintf("%.2f MiB",float64(n)/(1024*1024))}

func debugRequest(o options)error{
	client:=makeClient(o); body,ct:=bodyFor(o); req,e:=http.NewRequest(o.method,o.target,bytes.NewReader(body)); if e!=nil{return e}
	req.Header.Set("User-Agent","oha/1.12.1"); if o.accept!=""{req.Header.Set("Accept",o.accept)}; if ct!=""{req.Header.Set("Content-Type",ct)}
	for _,h:=range o.headers{p:=strings.SplitN(h,":",2); req.Header.Set(strings.TrimSpace(p[0]),strings.TrimSpace(p[1]))}
	if o.host!=""{req.Host=o.host}
	displayHost := req.Host
	if displayHost == "" { displayHost = req.URL.Host }
	fmt.Printf("Request {\n    method: %s,\n    uri: %s,\n    version: HTTP/1.1,\n    headers: {\n",req.Method,req.URL.RequestURI())
	for k,v:=range req.Header{fmt.Printf("        \"%s\": \"%s\",\n",strings.ToLower(k),strings.Join(v,", "))}
	fmt.Printf("        \"host\": \"%s\",\n",displayHost)
	fmt.Printf("    },\n    body: Full {\n        data: Some(\n            b%q,\n        ),\n    },\n}\n",string(body))
	resp,e:=client.Do(req); if e!=nil{return e}; defer resp.Body.Close(); rb,_:=io.ReadAll(resp.Body)
	fmt.Printf("Response {\n    status: %d,\n    version: %s,\n    headers: {\n",resp.StatusCode,resp.Proto)
	for k,v:=range resp.Header{fmt.Printf("        \"%s\": \"%s\",\n",strings.ToLower(k),strings.Join(v,", "))}
	fmt.Printf("    },\n    body: b%q,\n}\n",string(rb)); return nil
}

func genRegexURL(s string,max int)string{
	var b strings.Builder
	for i:=0;i<len(s);i++{ if s[i]=='[' { j:=strings.IndexByte(s[i:],']'); if j>0{ cls:=s[i+1:i+j]; b.WriteByte(randClass(cls)); i+=j; continue } }; b.WriteByte(s[i]) }
	return b.String()
}
func randClass(cls string)byte{ if cls=="0-9"{return byte('0'+rand.Intn(10))}; if cls=="a-z"{return byte('a'+rand.Intn(26))}; if cls=="A-Z"{return byte('A'+rand.Intn(26))}; if strings.Contains(cls,"-"){p:=strings.SplitN(cls,"-",2); if len(p[0])>0&&len(p[1])>0{return p[0][0]+byte(rand.Intn(int(p[1][0]-p[0][0]+1)))}}; if cls!=""{return cls[rand.Intn(len(cls))]}; return 'x' }

var _ = errors.New
