package main

import (
	"archive/zip"
	"bufio"
	"bytes"
	"compress/flate"
	"compress/gzip"
	"compress/zlib"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type options struct {
	decompress bool
	stdout     bool
	keep       bool
	force      bool
	test       bool
	list       bool
	quiet      bool
	recursive  bool
	verbose    int
	zlib       bool
	zip        bool
	noName     bool
	name       bool
	noTime     bool
	modTime    bool
	level      int
	suffix     string
	comment    string
	alias      string
	files      []string
}

const helpText = `Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files
`

const licenseText = `pigz 2.8
Copyright (C) 2007-2023 Mark Adler
Subject to the terms of the zlib license.
No warranty is provided or implied.
`

func main() {
	prog := filepath.Base(os.Args[0])
	opt := options{level: flate.DefaultCompression, suffix: ".gz", name: true, modTime: true, alias: "-"}
	if strings.Contains(prog, "unpigz") {
		opt.decompress = true
	}
	args := append(splitEnv(os.Getenv("GZIP")), splitEnv(os.Getenv("PIGZ"))...)
	args = append(args, os.Args[1:]...)
	code, quit := parseArgs(args, &opt, prog)
	if quit {
		os.Exit(code)
	}
	if len(opt.files) == 0 {
		opt.files = []string{"-"}
		opt.stdout = true
	}
	if opt.test || opt.list {
		opt.decompress = true
	}
	if opt.stdout {
		opt.keep = true
	}
	files := expandFiles(opt.files, &opt, prog)
	status := 0
	if opt.list {
		status = listFiles(files, &opt, prog)
	} else {
		for _, name := range files {
			var err error
			if opt.decompress {
				err = decompressFile(name, &opt, prog)
			} else {
				err = compressFile(name, &opt, prog)
			}
			if err != nil {
				status = 1
				msg(prog, &opt, "%v", err)
			}
		}
	}
	os.Exit(status)
}

func splitEnv(s string) []string {
	if s == "" {
		return nil
	}
	return strings.Fields(s)
}

func parseArgs(args []string, opt *options, prog string) (int, bool) {
	stop := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if stop || a == "-" || !strings.HasPrefix(a, "-") {
			opt.files = append(opt.files, a)
			continue
		}
		if a == "--" {
			stop = true
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a[2:], "=")
			need := func() string {
				if has {
					return val
				}
				if i+1 >= len(args) {
					abort(prog, "missing parameter after --%s", name)
				}
				i++
				return args[i]
			}
			switch name {
			case "help":
				fmt.Print(helpText)
				return 0, true
			case "license":
				fmt.Print(licenseText)
				return 0, true
			case "version":
				version(opt)
				return 0, true
			case "fast":
				opt.level = flate.BestSpeed
			case "best":
				opt.level = flate.BestCompression
			case "alias":
				opt.alias = need()
			case "blocksize", "processes", "iterations", "maxsplits":
				_ = need()
			case "stdout", "to-stdout":
				opt.stdout = true
			case "comment":
				opt.comment = need()
			case "decompress", "uncompress":
				opt.decompress = true
			case "force":
				opt.force = true
			case "first", "huffman", "independent", "oneblock", "rsyncable", "rle", "synchronous":
			case "keep":
				opt.keep = true
			case "zip":
				opt.zip = true
			case "list":
				opt.list = true
			case "no-time":
				opt.modTime = false
			case "time":
				opt.modTime = true
			case "no-name":
				opt.name = false
				opt.modTime = false
				opt.noName = true
			case "name":
				opt.name = true
				opt.modTime = true
			case "quiet", "silent":
				opt.quiet = true
			case "recursive":
				opt.recursive = true
			case "suffix":
				opt.suffix = need()
			case "test":
				opt.test = true
			case "verbose":
				opt.verbose++
			case "zlib":
				opt.zlib = true
			default:
				abort(prog, "invalid option: --%s", name)
			}
			continue
		}
		for j := 1; j < len(a); j++ {
			ch := a[j]
			param := func() string {
				if j+1 < len(a) {
					v := a[j+1:]
					j = len(a)
					return v
				}
				if i+1 >= len(args) {
					abort(prog, "missing parameter after -%c", ch)
				}
				i++
				return args[i]
			}
			switch {
			case ch >= '0' && ch <= '9':
				if ch == '1' && j+1 < len(a) && a[j+1] == '1' {
					opt.level = flate.BestCompression
					j++
				} else if ch == '0' {
					opt.level = flate.NoCompression
				} else {
					opt.level = int(ch - '0')
				}
			default:
				switch ch {
				case 'A':
					opt.alias = param()
				case 'b', 'p', 'I', 'J':
					_ = param()
				case 'c':
					opt.stdout = true
				case 'C':
					opt.comment = param()
				case 'd':
					opt.decompress = true
				case 'f':
					opt.force = true
				case 'F', 'H', 'i', 'O', 'R', 'U', 'Y':
				case 'h':
					fmt.Print(helpText)
					return 0, true
				case 'k':
					opt.keep = true
				case 'K':
					opt.zip = true
				case 'l':
					opt.list = true
				case 'L':
					fmt.Print(licenseText)
					return 0, true
				case 'm':
					opt.modTime = false
				case 'M':
					opt.modTime = true
				case 'n':
					opt.name = false
					opt.modTime = false
				case 'N':
					opt.name = true
					opt.modTime = true
				case 'q':
					opt.quiet = true
				case 'r':
					opt.recursive = true
				case 'S':
					opt.suffix = param()
				case 't':
					opt.test = true
				case 'v':
					opt.verbose++
				case 'V':
					version(opt)
					return 0, true
				case 'z':
					opt.zlib = true
				default:
					abort(prog, "invalid option: -%c", ch)
				}
			}
		}
	}
	return 0, false
}

func abort(prog, format string, args ...any) {
	fmt.Fprintf(os.Stderr, "%s: abort: %s\n", prog, fmt.Sprintf(format, args...))
	os.Exit(22)
}

func version(opt *options) {
	if opt.verbose > 0 {
		fmt.Println("pigz 2.8")
		fmt.Println("zlib 1.2.13")
	} else {
		fmt.Println("pigz 2.8")
	}
}

func expandFiles(files []string, opt *options, prog string) []string {
	var out []string
	for _, name := range files {
		if name == "-" {
			out = append(out, name)
			continue
		}
		info, err := os.Stat(name)
		if err != nil {
			out = append(out, name)
			continue
		}
		if info.IsDir() {
			if !opt.recursive {
				msg(prog, opt, "skipping: %s is a directory", name)
				continue
			}
			filepath.WalkDir(name, func(path string, d fs.DirEntry, err error) error {
				if err == nil && !d.IsDir() {
					out = append(out, path)
				}
				return nil
			})
			continue
		}
		out = append(out, name)
	}
	return out
}

func compressFile(name string, opt *options, prog string) error {
	var in io.ReadCloser
	var info os.FileInfo
	var err error
	if name == "-" {
		in = io.NopCloser(os.Stdin)
	} else {
		linfo, lerr := os.Lstat(name)
		if lerr == nil && linfo.Mode()&os.ModeSymlink != 0 && !opt.force {
			return fmt.Errorf("skipping: %s is a symbolic link", name)
		}
		if !opt.force && hasCompressedSuffix(name, opt) {
			msg(prog, opt, "skipping: %s ends with %s", name, suffixFor(opt))
			return nil
		}
		info, err = os.Stat(name)
		if err != nil {
			return err
		}
		if st, ok := info.Sys().(*syscall.Stat_t); ok && st.Nlink > 1 && !opt.force {
			return fmt.Errorf("skipping: %s has %d other link%s", name, st.Nlink-1, plural(uint64(st.Nlink-1)))
		}
		in, err = os.Open(name)
		if err != nil {
			return err
		}
	}
	defer in.Close()

	var out io.WriteCloser
	outName := ""
	if opt.stdout || name == "-" {
		out = nopWriteCloser{os.Stdout}
	} else {
		outName = name + suffixFor(opt)
		if exists(outName) && !opt.force {
			return fmt.Errorf("skipping: %s exists", outName)
		}
		out, err = os.Create(outName)
		if err != nil {
			return err
		}
	}
	ok := false
	defer func() {
		out.Close()
		if !ok && outName != "" {
			os.Remove(outName)
		}
	}()
	if opt.zip {
		err = writeZip(in, out, name, info, opt)
	} else if opt.zlib {
		err = writeZlib(in, out, opt)
	} else {
		err = writeGzip(in, out, name, info, opt)
	}
	if err != nil {
		return err
	}
	ok = true
	if outName != "" && info != nil {
		os.Chmod(outName, info.Mode())
		if opt.modTime {
			os.Chtimes(outName, info.ModTime(), info.ModTime())
		}
		if !opt.keep {
			os.Remove(name)
		}
	}
	return nil
}

func writeGzip(in io.Reader, out io.Writer, name string, info os.FileInfo, opt *options) error {
	lvl := opt.level
	if lvl > flate.BestCompression {
		lvl = flate.BestCompression
	}
	w, err := gzip.NewWriterLevel(out, lvl)
	if err != nil {
		return err
	}
	if opt.name && name != "-" {
		w.Name = filepath.Base(name)
	}
	if opt.modTime && info != nil {
		w.ModTime = info.ModTime()
	}
	if opt.comment != "" {
		w.Comment = opt.comment
	}
	_, err = io.Copy(w, in)
	if cerr := w.Close(); err == nil {
		err = cerr
	}
	return err
}

func writeZlib(in io.Reader, out io.Writer, opt *options) error {
	lvl := opt.level
	if lvl > flate.BestCompression {
		lvl = flate.BestCompression
	}
	w, err := zlib.NewWriterLevel(out, lvl)
	if err != nil {
		return err
	}
	_, err = io.Copy(w, in)
	if cerr := w.Close(); err == nil {
		err = cerr
	}
	return err
}

func writeZip(in io.Reader, out io.Writer, name string, info os.FileInfo, opt *options) error {
	zw := zip.NewWriter(out)
	entry := filepath.Base(name)
	if name == "-" {
		entry = opt.alias
	}
	h := &zip.FileHeader{Name: entry, Method: zip.Deflate, Comment: opt.comment}
	if info != nil && opt.modTime {
		h.SetModTime(info.ModTime())
	}
	w, err := zw.CreateHeader(h)
	if err != nil {
		return err
	}
	_, err = io.Copy(w, in)
	if cerr := zw.Close(); err == nil {
		err = cerr
	}
	return err
}

func decompressFile(name string, opt *options, prog string) error {
	var in io.ReadCloser
	var err error
	var info os.FileInfo
	if name == "-" {
		in = io.NopCloser(os.Stdin)
	} else {
		info, _ = os.Stat(name)
		in, err = os.Open(name)
		if err != nil {
			return err
		}
	}
	defer in.Close()
	data, err := io.ReadAll(in)
	if err != nil {
		return err
	}
	if opt.test {
		_, _, _, err = decompressBytes(data, "")
		return err
	}
	outName := ""
	if !opt.stdout && name != "-" {
		outName = outputName(name, data, opt)
		if outName == "" {
			return fmt.Errorf("unknown suffix -- ignored")
		}
		if exists(outName) && !opt.force {
			return fmt.Errorf("skipping: %s exists", outName)
		}
	}
	plain, hdrName, hdrTime, err := decompressBytes(data, outName)
	if err != nil {
		return err
	}
	if opt.name && hdrName != "" && !opt.stdout && name != "-" {
		outName = hdrName
		if exists(outName) && !opt.force {
			return fmt.Errorf("skipping: %s exists", outName)
		}
	}
	if opt.stdout || name == "-" {
		_, err = os.Stdout.Write(plain)
		return err
	}
	if err = os.WriteFile(outName, plain, 0666); err != nil {
		return err
	}
	if info != nil {
		os.Chmod(outName, info.Mode())
	}
	if opt.modTime {
		when := hdrTime
		if when.IsZero() && info != nil {
			when = info.ModTime()
		}
		if !when.IsZero() {
			os.Chtimes(outName, when, when)
		}
	}
	if !opt.keep {
		os.Remove(name)
	}
	return nil
}

func decompressBytes(data []byte, preferred string) ([]byte, string, time.Time, error) {
	if len(data) >= 4 && bytes.Equal(data[:4], []byte{'P', 'K', 3, 4}) {
		zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
		if err != nil {
			return nil, "", time.Time{}, err
		}
		var out bytes.Buffer
		var nm string
		var mt time.Time
		for _, f := range zr.File {
			if f.FileInfo().IsDir() {
				continue
			}
			rc, err := f.Open()
			if err != nil {
				return nil, "", time.Time{}, err
			}
			_, err = io.Copy(&out, rc)
			rc.Close()
			nm = f.Name
			mt = f.Modified
			return out.Bytes(), nm, mt, err
		}
		return out.Bytes(), nm, mt, nil
	}
	if len(data) >= 2 && data[0] == 0x1f && data[1] == 0x8b {
		gr, err := gzip.NewReader(bytes.NewReader(data))
		if err != nil {
			return nil, "", time.Time{}, err
		}
		var out bytes.Buffer
		_, err = io.Copy(&out, gr)
		name, mt := gr.Name, gr.ModTime
		if cerr := gr.Close(); err == nil {
			err = cerr
		}
		return out.Bytes(), name, mt, err
	}
	zr, err := zlib.NewReader(bytes.NewReader(data))
	if err != nil {
		return nil, "", time.Time{}, err
	}
	var out bytes.Buffer
	_, err = io.Copy(&out, zr)
	if cerr := zr.Close(); err == nil {
		err = cerr
	}
	return out.Bytes(), "", time.Time{}, err
}

func outputName(name string, data []byte, opt *options) string {
	if strings.HasSuffix(name, ".tgz") {
		return strings.TrimSuffix(name, ".tgz") + ".tar"
	}
	if strings.HasSuffix(name, ".taz") {
		return strings.TrimSuffix(name, ".taz") + ".tar"
	}
	for _, suf := range []string{opt.suffix, ".gz", ".zz", ".zip", ".z"} {
		if suf != "" && strings.HasSuffix(name, suf) {
			return strings.TrimSuffix(name, suf)
		}
	}
	return ""
}

func listFiles(files []string, opt *options, prog string) int {
	if opt.verbose > 0 {
		fmt.Println("method    check    timestamp    compressed   original reduced  name")
	} else {
		fmt.Println("compressed   original reduced  name")
	}
	status := 0
	var totalC, totalU uint64
	for _, name := range files {
		data, err := readNamed(name)
		if err != nil {
			msg(prog, opt, "%v", err)
			status = 1
			continue
		}
		ent, err := listEntry(name, data)
		if err != nil {
			msg(prog, opt, "%v", err)
			status = 1
			continue
		}
		totalC += ent.comp
		totalU += ent.orig
		printList(ent, opt)
	}
	if len(files) > 1 {
		ent := listEnt{name: "(totals)", comp: totalC, orig: totalU}
		printList(ent, opt)
	}
	return status
}

type listEnt struct {
	name       string
	method     string
	check      uint32
	comp, orig uint64
	mod        time.Time
}

func listEntry(name string, data []byte) (listEnt, error) {
	ent := listEnt{name: name, comp: uint64(len(data)), method: "gzip"}
	if len(data) >= 2 && data[0] == 0x1f && data[1] == 0x8b {
		h, off, err := parseGzipHeader(data)
		if err != nil {
			return ent, err
		}
		if h.name != "" {
			ent.name = h.name
		}
		ent.mod = h.mod
		if len(data) >= 8 {
			ent.check = binary.LittleEndian.Uint32(data[len(data)-8:])
			ent.orig = uint64(binary.LittleEndian.Uint32(data[len(data)-4:]))
			ent.comp = uint64(len(data) - off - 8)
		}
		return ent, nil
	}
	if len(data) >= 4 && bytes.Equal(data[:4], []byte{'P', 'K', 3, 4}) {
		zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
		if err != nil {
			return ent, err
		}
		for _, f := range zr.File {
			if f.FileInfo().IsDir() {
				continue
			}
			return listEnt{name: f.Name, method: "zip", check: f.CRC32, comp: uint64(f.CompressedSize64), orig: uint64(f.UncompressedSize64), mod: f.Modified}, nil
		}
		return ent, nil
	}
	plain, _, _, err := decompressBytes(data, "")
	if err != nil {
		return ent, err
	}
	ent.method = "zlib"
	ent.orig = uint64(len(plain))
	ent.check = crc32.ChecksumIEEE(plain)
	return ent, nil
}

type gzHead struct {
	name string
	mod  time.Time
}

func parseGzipHeader(data []byte) (gzHead, int, error) {
	var h gzHead
	if len(data) < 10 {
		return h, 0, io.ErrUnexpectedEOF
	}
	if data[0] != 0x1f || data[1] != 0x8b {
		return h, 0, errors.New("not gzip")
	}
	flags := data[3]
	mt := binary.LittleEndian.Uint32(data[4:8])
	if mt != 0 {
		h.mod = time.Unix(int64(mt), 0)
	}
	i := 10
	if flags&4 != 0 {
		if i+2 > len(data) {
			return h, i, io.ErrUnexpectedEOF
		}
		xlen := int(binary.LittleEndian.Uint16(data[i:]))
		i += 2 + xlen
	}
	if flags&8 != 0 {
		start := i
		for i < len(data) && data[i] != 0 {
			i++
		}
		if i >= len(data) {
			return h, i, io.ErrUnexpectedEOF
		}
		h.name = string(data[start:i])
		i++
	}
	if flags&16 != 0 {
		for i < len(data) && data[i] != 0 {
			i++
		}
		if i >= len(data) {
			return h, i, io.ErrUnexpectedEOF
		}
		i++
	}
	if flags&2 != 0 {
		i += 2
	}
	return h, i, nil
}

func printList(e listEnt, opt *options) {
	red := "  0.0%"
	if e.orig > 0 {
		pct := 100 - (float64(e.comp)*100)/float64(e.orig)
		red = fmt.Sprintf("%5.1f%%", pct)
	}
	if opt.verbose > 0 {
		ts := ""
		if !e.mod.IsZero() {
			ts = e.mod.Format("Jan _2 15:04")
		}
		fmt.Printf("%-6s %08x  %-12s %10d %10d %7s  %s\n", e.method+" 8", e.check, ts, e.comp, e.orig, red, e.name)
	} else {
		fmt.Printf("%10d %10d %7s  %s\n", e.comp, e.orig, red, e.name)
	}
}

func readNamed(name string) ([]byte, error) {
	if name == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(name)
}

func hasCompressedSuffix(name string, opt *options) bool {
	return strings.HasSuffix(name, suffixFor(opt)) || strings.HasSuffix(name, ".gz") || strings.HasSuffix(name, ".zz") || strings.HasSuffix(name, ".zip")
}

func suffixFor(opt *options) string {
	if opt.zip {
		return ".zip"
	}
	if opt.zlib {
		return ".zz"
	}
	return opt.suffix
}

func exists(name string) bool {
	_, err := os.Stat(name)
	return err == nil
}

func msg(prog string, opt *options, format string, args ...any) {
	if opt.quiet {
		return
	}
	fmt.Fprintf(os.Stderr, "%s: %s\n", prog, fmt.Sprintf(format, args...))
}

func plural(n uint64) string {
	if n == 1 {
		return ""
	}
	return "s"
}

type nopWriteCloser struct{ io.Writer }

func (n nopWriteCloser) Close() error { return nil }

func init() {
	_ = runtime.NumCPU()
	_ = strconv.IntSize
	_ = bufio.ErrInvalidUnreadByte
}
