module cleanpigz

go 1.21
