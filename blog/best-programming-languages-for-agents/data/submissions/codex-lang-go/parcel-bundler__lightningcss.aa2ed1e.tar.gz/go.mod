module lightningclone

go 1.21
