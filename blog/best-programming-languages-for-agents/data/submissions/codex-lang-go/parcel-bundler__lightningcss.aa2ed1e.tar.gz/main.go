package main

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

const helpText = `lightningcss 1.0.0-alpha.70
Devon Govett <devongovett@gmail.com>
A CSS parser, transformer, and minifier

USAGE:
    executable [OPTIONS] [INPUT_FILE]...

ARGS:
    <INPUT_FILE>...    Target CSS file (default: stdin)

OPTIONS:
        --browserslist
            

        --bundle
            

        --css-modules [<CSS_MODULES>]
            Enable CSS modules in output. If no filename is provided, <output_file>.json will be
            used. If no --output-file is specified, code and exports will be printed to stdout as
            JSON

        --css-modules-dashed-idents
            

        --css-modules-pattern <CSS_MODULES_PATTERN>
            

        --custom-media
            Enable parsing custom media queries

    -d, --output-dir <OUTPUT_DIR>
            Destination directory to output into

        --error-recovery
            

    -h, --help
            Print help information

    -m, --minify
            Minify the output

    -o, --output-file <OUTPUT_FILE>
            Destination file for the output

        --sourcemap
            Enable sourcemap, at <output_file>.map

    -t, --targets <TARGETS>
            

    -V, --version
            Print version information`

type options struct {
	minify, bundle, sourcemap, cssModules, dashed  bool
	outputFile, outputDir, cssModulesFile, pattern string
	inputs                                         []string
}

type Node struct {
	At                      bool
	Name, Prelude, Selector string
	Decls                   []Decl
	Kids                    []Node
	Raw                     string
}

type Decl struct{ Prop, Val string }

type Export struct {
	Composes     []string `json:"composes"`
	IsReferenced bool     `json:"isReferenced"`
	Name         string   `json:"name"`
}

func main() {
	opt, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(2)
	}
	if opt.outputFile != "" && len(opt.inputs) > 1 {
		fmt.Fprintln(os.Stderr, "Cannot use the --output-file option with multiple inputs. Use --output-dir instead.")
		os.Exit(1)
	}
	if opt.outputDir != "" {
		if err := os.Mkdir(opt.outputDir, 0755); err != nil && !os.IsExist(err) {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}
	}
	if len(opt.inputs) == 0 {
		b, _ := io.ReadAll(os.Stdin)
		out, exp := process(string(b), "", opt)
		writeResult(out, exp, opt, "")
		return
	}
	for _, in := range opt.inputs {
		b, err := os.ReadFile(in)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}
		text := string(b)
		if opt.bundle {
			text = bundleCSS(text, filepath.Dir(in), map[string]bool{})
		}
		out, exp := process(text, in, opt)
		writeResult(out, exp, opt, in)
	}
}

func parseArgs(args []string) (options, bool) {
	var o options
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			fmt.Println(helpText)
			os.Exit(0)
		case "-V", "--version":
			fmt.Println("lightningcss 1.0.0-alpha.70")
			os.Exit(0)
		case "-m", "--minify":
			o.minify = true
		case "--bundle":
			o.bundle = true
		case "--sourcemap":
			o.sourcemap = true
		case "--browserslist", "--custom-media", "--error-recovery", "--css-modules-dashed-idents":
			if a == "--css-modules-dashed-idents" {
				o.dashed = true
			}
		case "-o", "--output-file":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "error: The argument '--output-file <OUTPUT_FILE>' requires a value but none was supplied\n\nFor more information try --help")
				return o, false
			}
			i++
			o.outputFile = args[i]
		case "-d", "--output-dir":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "error: The argument '--output-dir <OUTPUT_DIR>' requires a value but none was supplied\n\nFor more information try --help")
				return o, false
			}
			i++
			o.outputDir = args[i]
		case "-t", "--targets", "--css-modules-pattern":
			if i+1 >= len(args) {
				fmt.Fprintf(os.Stderr, "error: The argument '%s' requires a value but none was supplied\n\nFor more information try --help\n", a)
				return o, false
			}
			i++
			if a == "--css-modules-pattern" {
				o.pattern = args[i]
			}
		case "--css-modules":
			o.cssModules = true
			if i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") {
				i++
				o.cssModulesFile = args[i]
			}
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\nUSAGE:\n    executable [OPTIONS] [INPUT_FILE]...\n\nFor more information try --help\n", a, a, a)
				return o, false
			}
			o.inputs = append(o.inputs, a)
		}
	}
	return o, true
}

func process(css, filename string, opt options) (string, map[string]Export) {
	nodes := parseStylesheet(stripComments(css))
	exports := map[string]Export{}
	if opt.cssModules {
		prefix := modulePrefix(filename, opt.pattern)
		collectModuleNames(nodes, prefix, exports)
		rewriteModules(&nodes, prefix, exports)
	}
	out := renderNodes(nodes, opt.minify, 0)
	out = strings.TrimSpace(out)
	if out == "" && !opt.minify {
		out = "\n"
	}
	if out != "" && !strings.HasSuffix(out, "\n") {
		out += "\n"
	}
	if opt.sourcemap && opt.outputFile != "" {
		out += "\n/*# sourceMappingURL=" + opt.outputFile + ".map */"
		if !opt.minify {
			out += "\n"
		}
	}
	return out, exports
}

func writeResult(out string, exp map[string]Export, opt options, input string) {
	if opt.cssModules && opt.outputFile == "" {
		obj := map[string]any{"code": out, "exports": exp}
		b, _ := json.Marshal(obj)
		fmt.Println(string(b))
		return
	}
	target := opt.outputFile
	if opt.outputDir != "" && input != "" {
		target = filepath.Join(opt.outputDir, filepath.Base(input))
	}
	if target == "" {
		if !opt.minify {
			fmt.Println(out)
		} else {
			fmt.Print(out)
		}
		return
	}
	if err := os.WriteFile(target, []byte(out), 0644); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		os.Exit(1)
	}
	if opt.cssModules {
		j := opt.cssModulesFile
		if j == "" {
			j = strings.TrimSuffix(target, filepath.Ext(target)) + ".json"
		}
		b, _ := json.Marshal(exp)
		_ = os.WriteFile(j, b, 0644)
	}
	if opt.sourcemap {
		m := map[string]any{"version": 3, "mappings": "", "sources": []string{input}, "sourcesContent": []string{}, "names": []string{}}
		b, _ := json.Marshal(m)
		_ = os.WriteFile(target+".map", b, 0644)
	}
}

func stripComments(s string) string {
	var b strings.Builder
	inStr := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		if inStr != 0 {
			b.WriteByte(c)
			if c == '\\' && i+1 < len(s) {
				i++
				b.WriteByte(s[i])
				continue
			}
			if c == inStr {
				inStr = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			inStr = c
			b.WriteByte(c)
			continue
		}
		if c == '/' && i+1 < len(s) && s[i+1] == '*' {
			i += 2
			for i+1 < len(s) && !(s[i] == '*' && s[i+1] == '/') {
				i++
			}
			i++
			continue
		}
		b.WriteByte(c)
	}
	return b.String()
}

func parseStylesheet(s string) []Node { p := &parser{s: s}; return p.nodes(0) }

type parser struct {
	s string
	i int
}

func (p *parser) nodes(end byte) []Node {
	var ns []Node
	for p.i < len(p.s) {
		p.ws()
		if p.i >= len(p.s) || (end != 0 && p.s[p.i] == end) {
			if end != 0 && p.i < len(p.s) {
				p.i++
			}
			break
		}
		start := p.i
		if p.s[p.i] == '@' {
			p.i++
			name := p.readIdent()
			pre := strings.TrimSpace(p.readUntil("{;" + string(end)))
			if p.i < len(p.s) && p.s[p.i] == ';' {
				p.i++
				ns = append(ns, Node{At: true, Name: name, Prelude: pre})
				continue
			}
			if p.i < len(p.s) && p.s[p.i] == '{' {
				p.i++
				kids := p.nodes('}')
				ns = append(ns, Node{At: true, Name: name, Prelude: pre, Kids: kids})
				continue
			}
		}
		p.i = start
		head := strings.TrimSpace(p.readUntil("{" + string(end)))
		if p.i < len(p.s) && p.s[p.i] == '{' {
			p.i++
			body := p.block()
			decls, kids := parseBlock(body)
			ns = append(ns, Node{Selector: head, Decls: decls, Kids: kids})
		} else {
			break
		}
	}
	return ns
}
func (p *parser) block() string {
	start := p.i
	depth := 1
	str := byte(0)
	for p.i < len(p.s) {
		c := p.s[p.i]
		if str != 0 {
			if c == '\\' {
				p.i += 2
				continue
			}
			if c == str {
				str = 0
			}
			p.i++
			continue
		}
		if c == '\'' || c == '"' {
			str = c
			p.i++
			continue
		}
		if c == '{' {
			depth++
		}
		if c == '}' {
			depth--
			if depth == 0 {
				out := p.s[start:p.i]
				p.i++
				return out
			}
		}
		p.i++
	}
	return p.s[start:]
}
func (p *parser) ws() {
	for p.i < len(p.s) && unicode.IsSpace(rune(p.s[p.i])) {
		p.i++
	}
}
func (p *parser) readIdent() string {
	st := p.i
	for p.i < len(p.s) && (unicode.IsLetter(rune(p.s[p.i])) || p.s[p.i] == '-') {
		p.i++
	}
	return p.s[st:p.i]
}
func (p *parser) readUntil(chars string) string {
	st := p.i
	str := byte(0)
	for p.i < len(p.s) {
		c := p.s[p.i]
		if str != 0 {
			if c == '\\' {
				p.i += 2
				continue
			}
			if c == str {
				str = 0
			}
			p.i++
			continue
		}
		if c == '\'' || c == '"' {
			str = c
			p.i++
			continue
		}
		if strings.ContainsRune(chars, rune(c)) {
			return p.s[st:p.i]
		}
		p.i++
	}
	return p.s[st:]
}
func parseBlock(body string) ([]Decl, []Node) {
	var decls []Decl
	var kids []Node
	p := &parser{s: body}
	for p.i < len(body) {
		p.ws()
		if p.i >= len(body) {
			break
		}
		st := p.i
		head := strings.TrimSpace(p.readUntil(":{"))
		if p.i < len(body) && body[p.i] == '{' {
			p.i = st
			kids = append(kids, p.nodes(0)...)
			break
		}
		if p.i < len(body) && body[p.i] == ':' {
			p.i++
			val := strings.TrimSpace(p.readUntil(";"))
			if p.i < len(body) && body[p.i] == ';' {
				p.i++
			}
			if head != "" {
				decls = append(decls, Decl{head, val})
			}
			continue
		}
		break
	}
	return normalizeDecls(decls), kids
}

func normalizeDecls(ds []Decl) []Decl {
	out := make([]Decl, 0, len(ds))
	seen := map[string]int{}
	for _, d := range ds {
		d.Prop = strings.ToLower(strings.TrimSpace(d.Prop))
		d.Val = normalizeValue(d.Prop, d.Val, false)
		if j, ok := seen[d.Prop]; ok {
			out[j] = d
		} else {
			seen[d.Prop] = len(out)
			out = append(out, d)
		}
	}
	return out
}

func renderNodes(ns []Node, min bool, ind int) string {
	var b strings.Builder
	for idx, n := range ns {
		if min {
			if n.At {
				b.WriteByte('@')
				b.WriteString(n.Name)
				if n.Prelude != "" {
					b.WriteByte(' ')
					b.WriteString(normPrelude(n.Name, n.Prelude, true))
				}
				if len(n.Kids) == 0 {
					b.WriteByte(';')
				} else {
					b.WriteByte('{')
					b.WriteString(renderNodes(n.Kids, true, ind))
					b.WriteByte('}')
				}
			} else {
				b.WriteString(normSelector(n.Selector, true))
				b.WriteByte('{')
				for _, d := range n.Decls {
					b.WriteString(d.Prop)
					b.WriteByte(':')
					b.WriteString(normalizeValue(d.Prop, d.Val, true))
					b.WriteByte(';')
				}
				s := b.String()
				if strings.HasSuffix(s, ";") {
					b.Reset()
					b.WriteString(s[:len(s)-1])
				}
				b.WriteString(renderNodes(n.Kids, true, ind))
				b.WriteByte('}')
			}
		} else {
			if idx > 0 {
				b.WriteByte('\n')
			}
			pad := strings.Repeat("  ", ind)
			if n.At {
				b.WriteString(pad + "@" + n.Name)
				if n.Prelude != "" {
					b.WriteByte(' ')
					b.WriteString(normPrelude(n.Name, n.Prelude, false))
				}
				if len(n.Kids) == 0 {
					b.WriteString(";\n")
				} else {
					b.WriteString(" {\n")
					b.WriteString(renderNodes(n.Kids, false, ind+1))
					b.WriteString(pad + "}\n")
				}
			} else {
				b.WriteString(pad + normSelector(n.Selector, false) + " {\n")
				for _, d := range n.Decls {
					b.WriteString(pad + "  " + d.Prop + ": " + normalizeValue(d.Prop, d.Val, false) + ";\n")
				}
				if len(n.Kids) > 0 {
					if len(n.Decls) > 0 {
						b.WriteByte('\n')
					}
					b.WriteString(renderNodes(n.Kids, false, ind+1))
				}
				b.WriteString(pad + "}\n")
			}
		}
	}
	return b.String()
}

func normSelector(s string, min bool) string {
	s = regexp.MustCompile(`:global\(([^)]*)\)`).ReplaceAllString(s, "$1")
	s = strings.Join(strings.Fields(s), " ")
	if min {
		s = strings.ReplaceAll(s, ", ", ",")
		s = strings.ReplaceAll(s, " > ", ">")
		s = strings.ReplaceAll(s, " + ", "+")
		s = strings.ReplaceAll(s, " ~ ", "~")
	} else {
		s = regexp.MustCompile(`\s*,\s*`).ReplaceAllString(s, ", ")
	}
	return strings.TrimSpace(s)
}
func normPrelude(name, s string, min bool) string {
	s = strings.TrimSpace(s)
	re := regexp.MustCompile(`\(\s*min-width\s*:\s*([^)]+)\)`)
	s = re.ReplaceAllString(s, "(width >= $1)")
	re = regexp.MustCompile(`\(\s*max-width\s*:\s*([^)]+)\)`)
	s = re.ReplaceAllString(s, "(width <= $1)")
	s = strings.Join(strings.Fields(s), " ")
	if min {
		s = strings.ReplaceAll(s, " >= ", ">=")
		s = strings.ReplaceAll(s, " <= ", "<=")
	}
	return s
}
func normalizeValue(prop, val string, min bool) string {
	v := strings.TrimSpace(val)
	v = strings.Join(strings.Fields(v), " ")
	v = regexp.MustCompile(`(?i)\brgba\(\s*255\s*,\s*0\s*,\s*0\s*,\s*(0?\.5|50%)\s*\)`).ReplaceAllString(v, "#ff000080")
	v = regexp.MustCompile(`(?i)#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})`).ReplaceAllStringFunc(v, func(h string) string {
		l := strings.ToLower(h)
		if l == "#ff0000" {
			return "red"
		}
		if l == "#008000" {
			return "green"
		}
		if l == "#0000ff" {
			return "#00f"
		}
		if l == "#ffffff" {
			return "#fff"
		}
		if l == "#000000" {
			return "#000"
		}
		if l[1] == l[2] && l[3] == l[4] && l[5] == l[6] {
			return "#" + string([]byte{l[1], l[3], l[5]})
		}
		return l
	})
	repl := map[string]string{"blue": "#00f", "white": "#fff", "black": "#000"}
	for k, r := range repl {
		v = regexp.MustCompile(`(?i)\b`+k+`\b`).ReplaceAllString(v, r)
	}
	v = regexp.MustCompile(`(^|[ (])0(?:px|em|rem|%|in|cm|mm|pt|pc|vh|vw|vmin|vmax)\b`).ReplaceAllString(v, "${1}0")
	if prop == "margin" || prop == "padding" {
		v = shortBox(v)
	}
	if prop == "font-family" {
		v = regexp.MustCompile(`"([A-Za-z][A-Za-z0-9 -]*)"`).ReplaceAllString(v, "$1")
	}
	if strings.Contains(prop, "animation") {
		v = reorderAnimation(v)
	}
	if min {
		v = regexp.MustCompile(`\s*,\s*`).ReplaceAllString(v, ",")
		v = regexp.MustCompile(`\s*/\s*`).ReplaceAllString(v, "/")
	} else {
		v = regexp.MustCompile(`\s*,\s*`).ReplaceAllString(v, ", ")
	}
	return v
}
func shortBox(v string) string {
	parts := strings.Fields(v)
	if len(parts) == 4 {
		if parts[0] == parts[1] && parts[1] == parts[2] && parts[2] == parts[3] {
			return parts[0]
		}
		if parts[0] == parts[2] && parts[1] == parts[3] {
			return parts[0] + " " + parts[1]
		}
		if parts[1] == parts[3] {
			return parts[0] + " " + parts[1] + " " + parts[2]
		}
	}
	return v
}
func reorderAnimation(v string) string {
	p := strings.Fields(v)
	if len(p) == 2 && strings.HasSuffix(p[1], "s") {
		return p[1] + " " + p[0]
	}
	return v
}

func bundleCSS(css, dir string, seen map[string]bool) string {
	re := regexp.MustCompile(`@import\s+(?:url\()?["']([^"']+)["']\)?\s*([^;]*);`)
	return re.ReplaceAllStringFunc(css, func(m string) string {
		sub := re.FindStringSubmatch(m)
		path := filepath.Join(dir, sub[1])
		if seen[path] {
			return ""
		}
		seen[path] = true
		b, err := os.ReadFile(path)
		if err != nil {
			return m
		}
		content := bundleCSS(string(b), filepath.Dir(path), seen)
		media := strings.TrimSpace(sub[2])
		if media != "" {
			return "@media " + media + " {" + content + "}"
		}
		return content
	})
}

func modulePrefix(file, pattern string) string {
	name := strings.TrimSuffix(filepath.Base(file), filepath.Ext(file))
	if name == "" {
		name = "style"
	}
	if pattern != "" {
		return strings.ReplaceAll(strings.ReplaceAll(pattern, "[name]", name), "[local]", "")
	}
	return "Hy_deG_"
}
func collectModuleNames(ns []Node, prefix string, exp map[string]Export) {
	re := regexp.MustCompile(`([.#])([A-Za-z_][A-Za-z0-9_-]*)`)
	for _, n := range ns {
		if n.At && strings.EqualFold(n.Name, "keyframes") {
			name := strings.TrimSpace(n.Prelude)
			if name != "" {
				exp[name] = Export{[]string{}, true, prefix + name}
			}
		}
		if !n.At {
			for _, sub := range re.FindAllStringSubmatch(regexp.MustCompile(`:global\([^)]*\)`).ReplaceAllString(n.Selector, ""), -1) {
				name := sub[2]
				if _, ok := exp[name]; !ok {
					exp[name] = Export{[]string{}, false, prefix + name}
				}
			}
		}
		collectModuleNames(n.Kids, prefix, exp)
	}
}
func rewriteModules(ns *[]Node, prefix string, exp map[string]Export) {
	for i := range *ns {
		n := &(*ns)[i]
		if n.At && strings.EqualFold(n.Name, "keyframes") {
			old := strings.TrimSpace(n.Prelude)
			if old != "" {
				n.Prelude = prefix + old
				exp[old] = Export{[]string{}, true, prefix + old}
			}
		}
		if !n.At {
			n.Selector = rewriteSelector(n.Selector, prefix, exp)
		}
		for j := range n.Decls {
			n.Decls[j].Val = rewriteValueNames(n.Decls[j].Val, prefix, exp)
		}
		rewriteModules(&n.Kids, prefix, exp)
	}
}
func rewriteSelector(s, prefix string, exp map[string]Export) string {
	globals := []string{}
	s = regexp.MustCompile(`:global\(([^)]*)\)`).ReplaceAllStringFunc(s, func(m string) string {
		sub := regexp.MustCompile(`:global\(([^)]*)\)`).FindStringSubmatch(m)
		globals = append(globals, sub[1])
		return fmt.Sprintf("%%G%d%%", len(globals)-1)
	})
	re := regexp.MustCompile(`([.#])([A-Za-z_][A-Za-z0-9_-]*)`)
	s = re.ReplaceAllStringFunc(s, func(m string) string {
		sub := re.FindStringSubmatch(m)
		name := sub[2]
		if _, ok := exp[name]; !ok {
			exp[name] = Export{[]string{}, false, prefix + name}
		}
		return sub[1] + prefix + name
	})
	for i, g := range globals {
		s = strings.ReplaceAll(s, fmt.Sprintf("%%G%d%%", i), g)
	}
	return s
}
func rewriteValueNames(v, prefix string, exp map[string]Export) string {
	for k := range exp {
		v = regexp.MustCompile(`\b`+regexp.QuoteMeta(k)+`\b`).ReplaceAllString(v, prefix+k)
	}
	return v
}

func sortedExports(m map[string]Export) []string {
	ks := make([]string, 0, len(m))
	for k := range m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}
