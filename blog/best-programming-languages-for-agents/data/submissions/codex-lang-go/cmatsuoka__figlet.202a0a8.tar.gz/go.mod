module figlet-reimplementation

go 1.21
