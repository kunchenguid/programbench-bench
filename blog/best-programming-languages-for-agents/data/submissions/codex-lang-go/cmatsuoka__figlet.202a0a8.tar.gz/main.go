package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"unicode/utf8"
)

const usage = "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n              [ -C controlfile ] [ -I infocode ] [ message ]"

type Font struct {
	Hardblank  rune
	Height     int
	OldLayout  int
	FullLayout int
	Direction  int
	Glyphs     map[rune][]string
}

type Options struct {
	fontDir   string
	fontName  string
	width     int
	justify   int
	direction int
	spacing   int
	layout    int
	info      *int
	version   bool
	paragraph bool
	control   []string
}

func main() {
	opts, msg, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(1)
	}
	if opts.version || opts.info != nil {
		printInfo(opts)
		return
	}
	input := strings.Join(msg, " ")
	if len(msg) == 0 {
		b, _ := io.ReadAll(os.Stdin)
		input = string(b)
	} else {
		parts := make([]string, len(msg))
		for i, a := range msg {
			parts[i] = a
		}
		input = strings.Join(parts, " ")
	}
	if opts.paragraph {
		input = paragraphize(input)
	}
	font, err := loadFont(opts.fontDir, opts.fontName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "executable: %s: Unable to open font file\n", opts.fontName)
		os.Exit(1)
	}
	for _, c := range opts.control {
		applyControl(font, opts.fontDir, c)
	}
	if opts.direction == 0 {
		opts.direction = font.Direction
	}
	mode, layout := effectiveSpacing(opts, font)
	blocks := renderText(font, input, mode, layout, opts.width, opts.justify, opts.direction)
	for _, line := range blocks {
		fmt.Println(line)
	}
}

func defaults() Options {
	return Options{fontDir: "/usr/local/share/figlet", fontName: "standard", width: 80, justify: -1, direction: -1, spacing: -99, layout: -999}
}

func parseArgs(args []string) (Options, []string, bool) {
	o := defaults()
	var msg []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			msg = append(msg, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			msg = append(msg, args[i:]...)
			break
		}
		for j := 1; j < len(a); j++ {
			ch := a[j]
			need := func() string {
				if j+1 < len(a) {
					v := a[j+1:]
					j = len(a)
					return v
				}
				i++
				if i >= len(args) {
					return ""
				}
				return args[i]
			}
			switch ch {
			case 'f':
				o.fontName = stripFontSuffix(need())
			case 'd':
				o.fontDir = need()
			case 'w':
				if v, err := strconv.Atoi(need()); err == nil {
					o.width = v
				}
			case 'm':
				if v, err := strconv.Atoi(need()); err == nil {
					o.layout = v
				}
			case 'I':
				v, err := strconv.Atoi(need())
				if err == nil {
					o.info = &v
				}
			case 'C':
				o.control = append(o.control, stripControlSuffix(need()))
			case 'c':
				o.justify = 1
			case 'l':
				o.justify = 0
			case 'r':
				o.justify = 2
			case 'x':
				o.justify = -1
			case 'L':
				o.direction = 0
			case 'R':
				o.direction = 1
			case 'X':
				o.direction = -1
			case 's':
				o.spacing = 2
			case 'S':
				o.spacing = 3
			case 'k':
				o.spacing = 1
			case 'W':
				o.spacing = 0
			case 'o':
				o.spacing = 4
			case 'n':
				o.paragraph = false
			case 'p':
				o.paragraph = true
			case 't':
				o.width = 80
			case 'v':
				o.version = true
			case 'D':
				o.control = append(o.control, "646-de")
			case 'E', 'N':
				if ch == 'N' {
					o.control = nil
				}
			default:
				fmt.Fprintf(os.Stderr, "./executable: invalid option -- '%c'\n%s\n", ch, usage)
				return o, nil, false
			}
		}
	}
	return o, msg, true
}

func printInfo(o Options) {
	code := 0
	if o.info != nil {
		code = *o.info
	}
	if o.version || code == 0 {
		fmt.Println("FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,")
		fmt.Println("Christiaan Keet and Claudio Matsuoka")
		fmt.Println("Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012")
		fmt.Println()
		fmt.Println("FIGlet, along with the various FIGlet fonts and documentation, may be")
		fmt.Println("freely copied and distributed.")
		fmt.Println()
		fmt.Println("If you use FIGlet, please send an e-mail message to <info@figlet.org>.")
		fmt.Println()
		fmt.Println("The latest version of FIGlet is available from the web site,")
		fmt.Println("\thttp://www.figlet.org/")
		fmt.Println()
		fmt.Println(usage)
		return
	}
	switch code {
	case 1:
		fmt.Println("20205")
	case 2:
		fmt.Println(o.fontDir)
	case 3:
		fmt.Println(o.fontName)
	case 4:
		fmt.Println(o.width)
	case 5:
		fmt.Println("flf2 tlf2")
	}
}

func stripFontSuffix(s string) string {
	return strings.TrimSuffix(strings.TrimSuffix(s, ".flf"), ".tlf")
}
func stripControlSuffix(s string) string { return strings.TrimSuffix(s, ".flc") }

func loadFont(dir, name string) (*Font, error) {
	paths := []string{}
	add := func(p string) { paths = append(paths, p, p+".flf", p+".tlf") }
	if filepath.IsAbs(name) || strings.ContainsRune(name, os.PathSeparator) {
		add(name)
	} else {
		add(filepath.Join(dir, name))
		add(name)
		add(filepath.Join("fonts", name))
	}
	var data []byte
	var err error
	for _, p := range paths {
		data, err = os.ReadFile(p)
		if err == nil {
			return parseFont(string(data))
		}
	}
	return nil, err
}

func parseFont(data string) (*Font, error) {
	sc := bufio.NewScanner(strings.NewReader(data))
	sc.Buffer(make([]byte, 1024), 1024*1024)
	if !sc.Scan() {
		return nil, fmt.Errorf("empty")
	}
	header := strings.Fields(sc.Text())
	if len(header) < 6 || !strings.HasPrefix(header[0], "flf2a") {
		return nil, fmt.Errorf("bad header")
	}
	hb, _ := utf8.DecodeRuneInString(header[0][5:])
	height, _ := strconv.Atoi(header[1])
	old, _ := strconv.Atoi(header[4])
	comments := 0
	if len(header) > 5 {
		comments, _ = strconv.Atoi(header[5])
	}
	dir := 0
	if len(header) > 6 {
		dir, _ = strconv.Atoi(header[6])
	}
	full := old
	if len(header) > 7 {
		full, _ = strconv.Atoi(header[7])
	}
	for i := 0; i < comments && sc.Scan(); i++ {
	}
	f := &Font{Hardblank: hb, Height: height, OldLayout: old, FullLayout: full, Direction: dir, Glyphs: map[rune][]string{}}
	for r := rune(32); r <= 126; r++ {
		g := make([]string, height)
		for i := 0; i < height && sc.Scan(); i++ {
			g[i] = trimEndmark(sc.Text())
		}
		f.Glyphs[r] = g
	}
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		codeFields := strings.Fields(line)
		if len(codeFields) == 0 {
			continue
		}
		code, err := strconv.Atoi(codeFields[0])
		if err != nil {
			continue
		}
		g := make([]string, height)
		for i := 0; i < height && sc.Scan(); i++ {
			g[i] = trimEndmark(sc.Text())
		}
		f.Glyphs[rune(code)] = g
	}
	return f, nil
}

func trimEndmark(s string) string {
	s = strings.TrimRight(s, "\r\n")
	r := []rune(s)
	if len(r) == 0 {
		return s
	}
	end := r[len(r)-1]
	for len(r) > 0 && r[len(r)-1] == end {
		r = r[:len(r)-1]
	}
	return string(r)
}

func effectiveSpacing(o Options, f *Font) (int, int) {
	if o.layout != -999 {
		switch o.layout {
		case -1:
			return 0, 0
		case 0:
			return 1, 0
		case -2:
			return 2, f.FullLayout
		default:
			return 2, o.layout
		}
	}
	if o.spacing >= 0 {
		if o.spacing == 3 {
			return 2, f.FullLayout
		}
		if o.spacing == 2 {
			if f.FullLayout < 0 {
				return 0, 0
			}
			if f.FullLayout == 0 {
				return 1, 0
			}
			return 2, f.FullLayout
		}
		return o.spacing, f.FullLayout
	}
	if f.FullLayout < 0 {
		return 0, 0
	}
	if f.FullLayout == 0 {
		return 1, 0
	}
	return 2, f.FullLayout
}

func renderText(f *Font, text string, spacing, layout, width, justify, direction int) []string {
	text = strings.ReplaceAll(text, "\r\n", "\n")
	lines := strings.Split(text, "\n")
	var out []string
	for _, line := range lines {
		if direction == 1 {
			line = reverseRunes(line)
		}
		segs := renderLineWrapped(f, line, spacing, layout, width)
		for _, seg := range segs {
			for _, s := range seg {
				s = strings.ReplaceAll(s, string(f.Hardblank), " ")
				out = append(out, justifyLine(s, width, justify, direction))
			}
		}
	}
	return out
}

func renderLineWrapped(f *Font, line string, spacing, layout, width int) [][]string {
	cur := blank(f.Height)
	var blocks [][]string
	for _, r := range line {
		g := f.Glyphs[r]
		if g == nil {
			g = f.Glyphs['?']
		}
		next := appendGlyph(cur, g, spacing, layout, f.Hardblank)
		if width > 1 && visibleWidth(next) > width && visibleWidth(cur) > 0 {
			blocks = append(blocks, cur)
			cur = appendGlyph(blank(f.Height), g, spacing, layout, f.Hardblank)
		} else {
			cur = next
		}
	}
	blocks = append(blocks, cur)
	return blocks
}

func blank(h int) []string { a := make([]string, h); return a }
func visibleWidth(lines []string) int {
	m := 0
	for _, s := range lines {
		if len([]rune(s)) > m {
			m = len([]rune(s))
		}
	}
	return m
}

func appendGlyph(left, right []string, spacing, layout int, hb rune) []string {
	if visibleWidth(left) == 0 {
		cp := make([]string, len(right))
		copy(cp, right)
		return cp
	}
	over := 0
	if spacing != 0 {
		max := glyphWidth(right)
		lw := visibleWidth(left)
		if lw < max {
			max = lw
		}
		for n := max; n >= 0; n-- {
			if canOverlap(left, right, n, spacing, layout, hb) {
				over = n
				break
			}
		}
		if spacing == 4 && over < glyphWidth(right) && glyphWidth(right) > 1 {
			over++
		}
	}
	out := make([]string, len(left))
	for i := range left {
		l := []rune(left[i])
		r := []rune(right[i])
		if over > len(r) {
			over = len(r)
		}
		base := append([]rune{}, l...)
		start := len(base) - over
		if start < 0 {
			start = 0
		}
		for j := 0; j < over && j < len(r); j++ {
			pos := start + j
			if pos >= len(base) {
				base = append(base, r[j])
				continue
			}
			base[pos] = merge(base[pos], r[j], layout, hb)
		}
		if over < len(r) {
			base = append(base, r[over:]...)
		}
		out[i] = string(base)
	}
	return out
}

func glyphWidth(g []string) int { return visibleWidth(g) }

func canOverlap(l, r []string, n, spacing, layout int, hb rune) bool {
	if n == 0 {
		return true
	}
	for i := range l {
		lr := []rune(l[i])
		rr := []rune(r[i])
		collisions := 0
		for j := 0; j < n && j < len(rr); j++ {
			pos := len(lr) - n + j
			if pos < 0 || pos >= len(lr) {
				continue
			}
			a, b := lr[pos], rr[j]
			if a == ' ' || b == ' ' {
				continue
			}
			collisions++
			if collisions > 1 {
				return false
			}
			if spacing == 1 {
				return false
			}
			if merge(a, b, layout, hb) == 0 {
				return false
			}
		}
	}
	return true
}

func merge(a, b rune, layout int, hb rune) rune {
	if a == ' ' {
		return b
	}
	if b == ' ' {
		return a
	}
	if a == hb && b == hb && layout&32 != 0 {
		return hb
	}
	if layout&1 != 0 && a == b && a != hb {
		return a
	}
	if layout&2 != 0 {
		h := "|/\\[]{}()<>"
		if a == '_' && strings.ContainsRune(h, b) {
			return b
		}
		if b == '_' && strings.ContainsRune(h, a) {
			return a
		}
	}
	if layout&4 != 0 {
		order := map[rune]int{'|': 1, '/': 2, '\\': 2, '[': 3, ']': 3, '{': 4, '}': 4, '(': 5, ')': 5, '<': 6, '>': 6}
		oa, oka := order[a]
		ob, okb := order[b]
		if oka && okb && oa != ob {
			if oa > ob {
				return a
			}
			return b
		}
	}
	if layout&8 != 0 {
		if (a == '[' && b == ']') || (a == ']' && b == '[') || (a == '{' && b == '}') || (a == '}' && b == '{') || (a == '(' && b == ')') || (a == ')' && b == '(') {
			return '|'
		}
	}
	if layout&16 != 0 {
		if a == '/' && b == '\\' {
			return '|'
		}
		if a == '\\' && b == '/' {
			return 'Y'
		}
		if a == '>' && b == '<' {
			return 'X'
		}
	}
	return 0
}

func justifyLine(s string, width, justify, direction int) string {
	if justify < 0 {
		if direction == 1 {
			justify = 2
		} else {
			justify = 0
		}
	}
	pad := width - len([]rune(s))
	if pad <= 0 {
		return s
	}
	switch justify {
	case 1:
		return strings.Repeat(" ", pad/2) + s
	case 2:
		return strings.Repeat(" ", pad) + s
	default:
		return s
	}
}

func reverseRunes(s string) string {
	r := []rune(s)
	for i, j := 0, len(r)-1; i < j; i, j = i+1, j-1 {
		r[i], r[j] = r[j], r[i]
	}
	return string(r)
}

func paragraphize(s string) string {
	var b strings.Builder
	r := []rune(s)
	for i, ch := range r {
		if ch == '\n' && i > 0 && r[i-1] != '\n' && i+1 < len(r) && r[i+1] != ' ' {
			b.WriteRune(' ')
		} else {
			b.WriteRune(ch)
		}
	}
	return b.String()
}

func applyControl(f *Font, dir, name string) {
	// The common built-in use is -D, which maps German ISO 646 punctuation.
	if name == "646-de" {
		m := map[rune]rune{'[': 196, '\\': 214, ']': 220, '{': 228, '|': 246, '}': 252, '~': 223}
		for from, to := range m {
			if g := f.Glyphs[to]; g != nil {
				f.Glyphs[from] = g
			}
		}
	}
}
