module fselect-reimpl

go 1.21
