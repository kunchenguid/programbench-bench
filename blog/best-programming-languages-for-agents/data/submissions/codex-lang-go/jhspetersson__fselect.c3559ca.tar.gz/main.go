package main

import (
	"bufio"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"hash"
	"html"
	"io"
	"math"
	"math/rand"
	"os"
	"os/user"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type query struct {
	cols       []string
	roots      []root
	where      []tok
	order      []orderSpec
	limit      int
	offset     int
	format     string
	original   string
	groupCols  []string
	suppressIO bool
}

type root struct {
	path               string
	minDepth, maxDepth int
	follow             bool
}

type fileRow struct {
	root  string
	abs   string
	rel   string
	info  os.FileInfo
	lstat os.FileInfo
	err   error
}

type orderSpec struct {
	expr string
	desc bool
}
type tok struct{ s string }

var currentQuery *query

func main() {
	args := os.Args[1:]
	noColor := false
	noErrors := false
	filtered := make([]string, 0, len(args))
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch strings.ToLower(a) {
		case "--help", "-h", "/?", "/h":
			printHelp(noColor)
			return
		case "--nocolor", "--no-color", "/nocolor":
			noColor = true
		case "--no-errors":
			noErrors = true
		case "--config", "-c", "/config":
			i++
		case "--interactive", "-i", "/i":
			repl()
			return
		default:
			filtered = append(filtered, a)
		}
	}
	_ = noColor
	if len(filtered) == 0 {
		printHelp(true)
		return
	}
	qstr := strings.Join(filtered, " ")
	q, err := parseQuery(qstr)
	if err != nil {
		if !noErrors {
			fmt.Fprintln(os.Stderr, err)
		}
		os.Exit(2)
	}
	q.suppressIO = noErrors
	currentQuery = q
	rows := collect(q)
	if isAggregateList(q.cols) {
		printRows(q, []map[string]string{aggregateRow(q.cols, rows)})
		return
	}
	if len(q.groupCols) > 0 {
		rows = groupRows(q, rows)
	}
	if len(q.order) > 0 {
		sort.SliceStable(rows, func(i, j int) bool {
			for _, o := range q.order {
				a, b := evalExpr(o.expr, rows[i]), evalExpr(o.expr, rows[j])
				c := compareVals(a, b)
				if c != 0 {
					if o.desc {
						return c > 0
					}
					return c < 0
				}
			}
			return false
		})
	}
	start := q.offset
	if start > len(rows) {
		start = len(rows)
	}
	end := len(rows)
	if q.limit >= 0 && start+q.limit < end {
		end = start + q.limit
	}
	out := make([]map[string]string, 0, end-start)
	for _, r := range rows[start:end] {
		m := map[string]string{}
		for _, c := range q.cols {
			m[columnTitle(c)] = evalExpr(c, r)
		}
		out = append(out, m)
	}
	printRows(q, out)
}

func printHelp(noColor bool) {
	if noColor {
		fmt.Println("fselect 0.10.0")
	} else {
		fmt.Println("fselect \033[33m0.10.0\033[0m")
	}
	fmt.Println("Find files with SQL-like queries.")
	fmt.Println("https://github.com/jhspetersson/fselect")
	fmt.Println()
	fmt.Println("Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]")
}

func repl() {
	sc := bufio.NewScanner(os.Stdin)
	for {
		fmt.Print("> ")
		if !sc.Scan() {
			return
		}
		line := strings.TrimSpace(sc.Text())
		if line == "quit" || line == "exit" {
			return
		}
		if strings.HasPrefix(line, "cd ") {
			_ = os.Chdir(strings.TrimSpace(line[3:]))
			continue
		}
		if line == "pwd" {
			wd, _ := os.Getwd()
			fmt.Println(wd)
			continue
		}
		if line == "" {
			continue
		}
		os.Args = []string{os.Args[0], line}
		main()
	}
}

func parseQuery(s string) (*query, error) {
	q := &query{limit: -1, format: "tabs", original: s}
	tokens := lex(s)
	if len(tokens) > 0 && eq(tokens[0].s, "select") {
		tokens = tokens[1:]
	}
	idx := findClause(tokens, 0, "from", "where", "group", "order", "limit", "offset", "into")
	colToks := tokens
	if idx >= 0 {
		colToks = tokens[:idx]
	}
	q.cols = splitExprs(joinToks(colToks))
	if len(q.cols) == 0 {
		return nil, fmt.Errorf("No columns selected")
	}
	pos := len(colToks)
	if pos < len(tokens) && eq(tokens[pos].s, "from") {
		pos++
		next := findClause(tokens, pos, "where", "group", "order", "limit", "offset", "into")
		end := len(tokens)
		if next >= 0 {
			end = next
		}
		q.roots = parseRoots(tokens[pos:end])
		pos = end
	}
	if len(q.roots) == 0 {
		q.roots = []root{{path: ".", maxDepth: -1}}
	}
	for pos < len(tokens) {
		switch strings.ToLower(tokens[pos].s) {
		case "where":
			pos++
			next := findClause(tokens, pos, "group", "order", "limit", "offset", "into")
			end := len(tokens)
			if next >= 0 {
				end = next
			}
			q.where = tokens[pos:end]
			pos = end
		case "group":
			pos++
			if pos < len(tokens) && eq(tokens[pos].s, "by") {
				pos++
			}
			next := findClause(tokens, pos, "order", "limit", "offset", "into")
			end := len(tokens)
			if next >= 0 {
				end = next
			}
			q.groupCols = splitExprs(joinToks(tokens[pos:end]))
			pos = end
		case "order":
			pos++
			if pos < len(tokens) && eq(tokens[pos].s, "by") {
				pos++
			}
			next := findClause(tokens, pos, "limit", "offset", "into")
			end := len(tokens)
			if next >= 0 {
				end = next
			}
			q.order = parseOrder(splitExprs(joinToks(tokens[pos:end])))
			pos = end
		case "limit":
			pos++
			if pos < len(tokens) {
				q.limit = atoi(tokens[pos].s)
				pos++
			}
		case "offset":
			pos++
			if pos < len(tokens) {
				q.offset = atoi(tokens[pos].s)
				pos++
			}
		case "into":
			pos++
			if pos < len(tokens) {
				q.format = strings.ToLower(tokens[pos].s)
				pos++
			}
		default:
			pos++
		}
	}
	return q, nil
}

func parseRoots(ts []tok) []root {
	parts := splitExprs(joinToks(ts))
	roots := []root{}
	for _, p := range parts {
		t := lex(p)
		if len(t) == 0 {
			continue
		}
		r := root{path: t[0].s, maxDepth: -1}
		for i := 1; i < len(t); i++ {
			switch strings.ToLower(t[i].s) {
			case "mindepth":
				if i+1 < len(t) {
					r.minDepth = atoi(t[i+1].s)
					i++
				}
			case "maxdepth", "depth":
				if i+1 < len(t) {
					r.maxDepth = atoi(t[i+1].s)
					i++
				}
			case "symlinks", "sym":
				r.follow = true
			}
		}
		roots = append(roots, r)
	}
	return roots
}

func parseOrder(parts []string) []orderSpec {
	out := []orderSpec{}
	for _, p := range parts {
		t := lex(p)
		if len(t) == 0 {
			continue
		}
		desc := false
		if eq(t[len(t)-1].s, "desc") || eq(t[len(t)-1].s, "asc") {
			desc = eq(t[len(t)-1].s, "desc")
			t = t[:len(t)-1]
		}
		ex := joinToks(t)
		if n, err := strconv.Atoi(ex); err == nil && currentQuery != nil && n > 0 && n <= len(currentQuery.cols) {
			ex = currentQuery.cols[n-1]
		}
		out = append(out, orderSpec{ex, desc})
	}
	return out
}

func lex(s string) []tok {
	var out []tok
	for i := 0; i < len(s); {
		c := s[i]
		if c == ' ' || c == '\t' || c == '\n' || c == '\r' {
			i++
			continue
		}
		if c == '\'' || c == '"' || c == '`' {
			q := c
			j := i + 1
			var b strings.Builder
			for j < len(s) && s[j] != q {
				if s[j] == '\\' && j+1 < len(s) {
					j++
				}
				b.WriteByte(s[j])
				j++
			}
			out = append(out, tok{b.String()})
			if j < len(s) {
				j++
			}
			i = j
			continue
		}
		if strings.ContainsRune(",(){}", rune(c)) {
			out = append(out, tok{string(c)})
			i++
			continue
		}
		if i+2 < len(s) && (s[i:i+3] == "===" || s[i:i+3] == "!==") {
			out = append(out, tok{s[i : i+3]})
			i += 3
			continue
		}
		if i+1 < len(s) {
			op := s[i : i+2]
			if op == "!=" || op == "<>" || op == ">=" || op == "<=" || op == "==" || op == "=~" || op == "~=" {
				out = append(out, tok{op})
				i += 2
				continue
			}
			if op == "!~" {
				out = append(out, tok{"!=~"})
				i += 2
				continue
			}
		}
		if strings.ContainsRune("=<>+-", rune(c)) {
			out = append(out, tok{string(c)})
			i++
			continue
		}
		j := i
		for j < len(s) && !strings.ContainsRune(" \t\r\n,(){}=<>+-\"'`", rune(s[j])) {
			j++
		}
		out = append(out, tok{s[i:j]})
		i = j
	}
	return out
}

func findClause(ts []tok, start int, names ...string) int {
	depth := 0
	for i := start; i < len(ts); i++ {
		s := strings.ToLower(ts[i].s)
		if s == "(" || s == "{" {
			depth++
		} else if s == ")" || s == "}" {
			depth--
		}
		if depth == 0 {
			for _, n := range names {
				if s == n {
					return i
				}
			}
		}
	}
	return -1
}

func splitExprs(s string) []string {
	ts := lex(s)
	var out []string
	start := 0
	depth := 0
	for i, t := range ts {
		if t.s == "(" || t.s == "{" {
			depth++
		} else if t.s == ")" || t.s == "}" {
			depth--
		}
		if depth == 0 && t.s == "," {
			part := strings.TrimSpace(joinToks(ts[start:i]))
			if part != "" {
				out = append(out, part)
			}
			start = i + 1
		}
	}
	part := strings.TrimSpace(joinToks(ts[start:]))
	if part != "" {
		out = append(out, part)
	}
	return out
}

func joinToks(ts []tok) string {
	var b strings.Builder
	prev := ""
	for _, t := range ts {
		s := t.s
		if b.Len() > 0 && s != "," && s != ")" && s != "}" && prev != "(" && prev != "{" {
			b.WriteByte(' ')
		}
		b.WriteString(s)
		prev = s
	}
	return b.String()
}

func collect(q *query) []fileRow {
	var rows []fileRow
	for _, rt := range q.roots {
		base, err := filepath.Abs(rt.path)
		if err != nil {
			continue
		}
		if _, err := os.Lstat(base); err != nil {
			if !q.suppressIO {
				fmt.Fprintf(os.Stderr, "%s: could not canonicalize path: %v\n", rt.path, err)
			}
			continue
		}
		queue := []string{base}
		for len(queue) > 0 {
			dir := queue[0]
			queue = queue[1:]
			f, err := os.Open(dir)
			if err != nil {
				if !q.suppressIO {
					fmt.Fprintln(os.Stderr, err)
				}
				continue
			}
			infos, err := f.Readdir(-1)
			f.Close()
			if err != nil {
				continue
			}
			for _, inf := range infos {
				abs := filepath.Join(dir, inf.Name())
				rel, _ := filepath.Rel(base, abs)
				rel = filepath.ToSlash(rel)
				depth := pathDepth(rel)
				lst := inf
				stat := inf
				if inf.Mode()&os.ModeSymlink != 0 && rt.follow {
					if st, e := os.Stat(abs); e == nil {
						stat = st
					}
				}
				r := fileRow{root: base, abs: abs, rel: rel, info: stat, lstat: lst}
				if depth >= max(1, rt.minDepth) && (len(q.where) == 0 || evalWhere(q.where, r)) {
					rows = append(rows, r)
				}
				if stat.IsDir() && (rt.maxDepth < 0 || depth < rt.maxDepth) {
					if inf.Mode()&os.ModeSymlink == 0 || rt.follow {
						queue = append(queue, abs)
					}
				}
			}
		}
	}
	return rows
}

func pathDepth(rel string) int {
	if rel == "." || rel == "" {
		return 0
	}
	return len(strings.Split(rel, "/"))
}

func evalWhere(ts []tok, r fileRow) bool { p := &parser{ts: ts, row: r}; return p.parseOr() }

type parser struct {
	ts  []tok
	pos int
	row fileRow
}

func (p *parser) peek() string {
	if p.pos >= len(p.ts) {
		return ""
	}
	return p.ts[p.pos].s
}
func (p *parser) eat(s string) bool {
	if eq(p.peek(), s) {
		p.pos++
		return true
	}
	return false
}
func (p *parser) parseOr() bool {
	v := p.parseAnd()
	for eq(p.peek(), "or") {
		p.pos++
		v = p.parseAnd() || v
	}
	return v
}
func (p *parser) parseAnd() bool {
	v := p.parseNot()
	for eq(p.peek(), "and") {
		p.pos++
		v = p.parseNot() && v
	}
	return v
}
func (p *parser) parseNot() bool {
	if eq(p.peek(), "not") {
		p.pos++
		return !p.parseNot()
	}
	return p.parsePrim()
}
func (p *parser) parsePrim() bool {
	if p.eat("(") || p.eat("{") {
		v := p.parseOr()
		if p.peek() == ")" || p.peek() == "}" {
			p.pos++
		}
		return v
	}
	left := p.readValueUntilOp()
	if left == "" {
		return false
	}
	if p.pos >= len(p.ts) || eq(p.peek(), "and") || eq(p.peek(), "or") || p.peek() == ")" || p.peek() == "}" {
		return truth(evalExpr(left, p.row))
	}
	op := strings.ToLower(p.peek())
	p.pos++
	if op == "not" && eq(p.peek(), "in") {
		op = "not in"
		p.pos++
	}
	if op == "between" {
		a := p.readValueUntil("and")
		if eq(p.peek(), "and") {
			p.pos++
		}
		b := p.readValueUntilStop()
		x := evalExpr(left, p.row)
		return compareVals(x, evalExpr(a, p.row)) >= 0 && compareVals(x, evalExpr(b, p.row)) <= 0
	}
	if op == "in" || op == "not in" {
		if p.peek() == "(" || p.peek() == "{" {
			p.pos++
		}
		vals := []string{}
		for p.pos < len(p.ts) && p.peek() != ")" && p.peek() != "}" {
			if p.peek() == "," {
				p.pos++
				continue
			}
			vals = append(vals, evalExpr(p.readValueUntil(",", ")", "}"), p.row))
		}
		if p.peek() == ")" || p.peek() == "}" {
			p.pos++
		}
		x := evalExpr(left, p.row)
		found := false
		for _, v := range vals {
			if compareVals(x, v) == 0 {
				found = true
			}
		}
		if op == "not in" {
			return !found
		}
		return found
	}
	right := p.readValueUntilStop()
	return compareOp(evalExpr(left, p.row), op, evalExpr(right, p.row))
}
func (p *parser) readValueUntil(stops ...string) string {
	start := p.pos
	depth := 0
	for p.pos < len(p.ts) {
		s := p.peek()
		low := strings.ToLower(s)
		if s == "(" || s == "{" {
			depth++
		} else if s == ")" || s == "}" {
			if depth == 0 {
				break
			}
			depth--
		}
		if depth == 0 {
			for _, st := range stops {
				if low == strings.ToLower(st) || s == st {
					return joinToks(p.ts[start:p.pos])
				}
			}
		}
		p.pos++
	}
	return joinToks(p.ts[start:p.pos])
}
func (p *parser) readValueUntilStop() string { return p.readValueUntil("and", "or", ")", "}") }
func (p *parser) readValueUntilOp() string {
	start := p.pos
	depth := 0
	for p.pos < len(p.ts) {
		s := p.peek()
		low := strings.ToLower(s)
		if s == "(" || s == "{" {
			depth++
		} else if s == ")" || s == "}" {
			if depth == 0 {
				break
			}
			depth--
		}
		if depth == 0 && (isOp(low) || low == "and" || low == "or") {
			break
		}
		p.pos++
	}
	return joinToks(p.ts[start:p.pos])
}
func isOp(s string) bool {
	switch s {
	case "=", "==", "eq", "!=", "<>", "ne", "===", "eeq", "!==", "ene", ">", "gt", ">=", "gte", "ge", "<", "lt", "<=", "lte", "le", "=~", "~=", "regexp", "rx", "!=~", "!~=", "notrx", "like", "notlike", "between", "in":
		return true
	}
	return false
}

func compareOp(a, op, b string) bool {
	switch strings.ToLower(op) {
	case "=", "==", "eq":
		return matchGlobOrEqual(a, b)
	case "!=", "<>", "ne":
		return !matchGlobOrEqual(a, b)
	case "===", "eeq":
		return a == b
	case "!==", "ene":
		return a != b
	case ">", "gt":
		return compareVals(a, b) > 0
	case ">=", "gte", "ge":
		return compareVals(a, b) >= 0
	case "<", "lt":
		return compareVals(a, b) < 0
	case "<=", "lte", "le":
		return compareVals(a, b) <= 0
	case "=~", "~=", "regexp", "rx":
		ok, _ := regexp.MatchString(b, a)
		return ok
	case "!=~", "!~=", "notrx":
		ok, _ := regexp.MatchString(b, a)
		return !ok
	case "like":
		return likeMatch(a, b)
	case "notlike":
		return !likeMatch(a, b)
	}
	return false
}

func evalExpr(expr string, r fileRow) string {
	expr = strings.TrimSpace(expr)
	if expr == "" {
		return ""
	}
	if (strings.HasPrefix(expr, "'") && strings.HasSuffix(expr, "'")) || (strings.HasPrefix(expr, "\"") && strings.HasSuffix(expr, "\"")) {
		return expr[1 : len(expr)-1]
	}
	if v, ok := evalFunction(expr, r); ok {
		return v
	}
	if v, ok := evalArithmetic(expr, r); ok {
		return v
	}
	return fieldValue(expr, r)
}

func evalFunction(expr string, r fileRow) (string, bool) {
	i := strings.IndexAny(expr, "({")
	if i < 0 {
		switch strings.ToLower(expr) {
		case "current_date", "cur_date", "curdate":
			return time.Now().Format("2006-01-02"), true
		case "current_time", "cur_time", "curtime":
			return time.Now().Format("15:04:05"), true
		case "current_timestamp", "now":
			return time.Now().Format("2006-01-02 15:04:05"), true
		case "pi":
			return fmt.Sprint(math.Pi), true
		}
		return "", false
	}
	name := strings.ToLower(strings.TrimSpace(expr[:i]))
	close := ')'
	if expr[i] == '{' {
		close = '}'
	}
	if !strings.HasSuffix(expr, string(close)) {
		return "", false
	}
	args := splitExprs(expr[i+1 : len(expr)-1])
	arg := func(n int) string {
		if n >= len(args) {
			return ""
		}
		return evalExpr(args[n], r)
	}
	switch name {
	case "lower", "lowercase", "lcase":
		return strings.ToLower(arg(0)), true
	case "upper", "uppercase", "ucase":
		return strings.ToUpper(arg(0)), true
	case "initcap":
		return strings.Title(strings.ToLower(arg(0))), true
	case "length", "len":
		return strconv.Itoa(len(arg(0))), true
	case "to_base64", "base64":
		return base64.StdEncoding.EncodeToString([]byte(arg(0))), true
	case "from_base64":
		b, _ := base64.StdEncoding.DecodeString(arg(0))
		return string(b), true
	case "concat":
		var b strings.Builder
		for i := range args {
			b.WriteString(arg(i))
		}
		return b.String(), true
	case "concat_ws":
		sep := arg(0)
		vals := []string{}
		for i := 1; i < len(args); i++ {
			vals = append(vals, arg(i))
		}
		return strings.Join(vals, sep), true
	case "substr", "substring":
		s := arg(0)
		start := atoi(arg(1))
		ln := len(s)
		if len(args) > 2 {
			ln = atoi(arg(2))
		}
		if start < 1 {
			start = 1
		}
		st := start - 1
		if st > len(s) {
			return "", true
		}
		en := st + ln
		if en > len(s) {
			en = len(s)
		}
		return s[st:en], true
	case "replace":
		return strings.ReplaceAll(arg(0), arg(1), arg(2)), true
	case "trim":
		return strings.TrimSpace(arg(0)), true
	case "ltrim":
		return strings.TrimLeft(arg(0), " \t\r\n"), true
	case "rtrim":
		return strings.TrimRight(arg(0), " \t\r\n"), true
	case "locate", "position":
		return strconv.Itoa(strings.Index(arg(1), arg(0)) + 1), true
	case "abs":
		f := toFloat(arg(0))
		return num(fabs(f)), true
	case "sqrt":
		return num(math.Sqrt(toFloat(arg(0)))), true
	case "floor":
		return num(math.Floor(toFloat(arg(0)))), true
	case "ceil", "ceiling":
		return num(math.Ceil(toFloat(arg(0)))), true
	case "round":
		return num(math.Round(toFloat(arg(0)))), true
	case "pow", "power":
		return num(math.Pow(toFloat(arg(0)), toFloat(arg(1)))), true
	case "ln":
		return num(math.Log(toFloat(arg(0)))), true
	case "log":
		return num(math.Log(toFloat(arg(0))) / math.Log(toFloat(arg(1)))), true
	case "exp":
		return num(math.Exp(toFloat(arg(0)))), true
	case "hex":
		n := int64(toFloat(arg(0)))
		return fmt.Sprintf("%X", n), true
	case "bin":
		n := int64(toFloat(arg(0)))
		return strconv.FormatInt(n, 2), true
	case "oct":
		n := int64(toFloat(arg(0)))
		return strconv.FormatInt(n, 8), true
	case "least":
		m := arg(0)
		for i := 1; i < len(args); i++ {
			if compareVals(arg(i), m) < 0 {
				m = arg(i)
			}
		}
		return m, true
	case "greatest":
		m := arg(0)
		for i := 1; i < len(args); i++ {
			if compareVals(arg(i), m) > 0 {
				m = arg(i)
			}
		}
		return m, true
	case "rand", "random":
		if len(args) > 1 {
			a, b := toFloat(arg(0)), toFloat(arg(1))
			return num(a + rand.Float64()*(b-a)), true
		}
		return num(rand.Float64() * toFloat(arg(0))), true
	case "year":
		return datePart(arg(0), "year"), true
	case "month":
		return datePart(arg(0), "month"), true
	case "day":
		return datePart(arg(0), "day"), true
	case "dayofweek", "dow":
		return datePart(arg(0), "dow"), true
	case "dayname":
		return datePart(arg(0), "dayname"), true
	case "dayofyear", "doy":
		return datePart(arg(0), "doy"), true
	}
	return "", false
}

func evalArithmetic(expr string, r fileRow) (string, bool) {
	ts := lex(expr)
	has := false
	for _, t := range ts {
		if strings.Contains("+-*/%", t.s) {
			has = true
		}
	}
	if !has {
		return "", false
	}
	p := &arith{ts: ts, row: r}
	v := p.expr()
	return num(v), true
}

type arith struct {
	ts  []tok
	pos int
	row fileRow
}

func (a *arith) peek() string {
	if a.pos >= len(a.ts) {
		return ""
	}
	return a.ts[a.pos].s
}
func (a *arith) expr() float64 {
	v := a.term()
	for a.peek() == "+" || a.peek() == "-" || eq(a.peek(), "plus") || eq(a.peek(), "minus") {
		op := a.peek()
		a.pos++
		w := a.term()
		if op == "+" || eq(op, "plus") {
			v += w
		} else {
			v -= w
		}
	}
	return v
}
func (a *arith) term() float64 {
	v := a.factor()
	for a.peek() == "*" || a.peek() == "/" || a.peek() == "%" || eq(a.peek(), "mul") || eq(a.peek(), "div") || eq(a.peek(), "mod") {
		op := a.peek()
		a.pos++
		w := a.factor()
		if op == "*" || eq(op, "mul") {
			v *= w
		} else if op == "%" || eq(op, "mod") {
			v = math.Mod(v, w)
		} else if w != 0 {
			v /= w
		}
	}
	return v
}
func (a *arith) factor() float64 {
	if a.peek() == "(" {
		a.pos++
		v := a.expr()
		if a.peek() == ")" {
			a.pos++
		}
		return v
	}
	start := a.pos
	for a.pos < len(a.ts) && !strings.Contains("+-*/%()", a.peek()) {
		a.pos++
	}
	return toFloat(evalExpr(joinToks(a.ts[start:a.pos]), a.row))
}

func fieldValue(name string, r fileRow) string {
	key := strings.ToLower(strings.TrimSpace(name))
	key = strings.TrimPrefix(key, ".")
	switch key {
	case "*":
		return "*"
	case "name":
		return filepath.Base(r.rel)
	case "filename", "fname":
		b := filepath.Base(r.rel)
		e := extPart(b)
		return strings.TrimSuffix(b, e)
	case "ext", "extension":
		e := extPart(filepath.Base(r.rel))
		if e == "" {
			return ""
		}
		return strings.TrimPrefix(e, ".")
	case "path":
		return r.rel
	case "abspath":
		return r.abs
	case "dir", "directory", "dirname":
		d := filepath.ToSlash(filepath.Dir(r.rel))
		if d == "." {
			return ""
		}
		return d
	case "absdir":
		return filepath.Dir(r.abs)
	case "size":
		return strconv.FormatInt(r.info.Size(), 10)
	case "fsize", "hsize":
		return humanSize(r.info.Size())
	case "modified":
		return r.info.ModTime().Format("2006-01-02 15:04:05")
	case "mtime":
		return strconv.FormatInt(r.info.ModTime().Unix(), 10)
	case "accessed", "created":
		return unixTime(r, "a").Format("2006-01-02 15:04:05")
	case "atime":
		return strconv.FormatInt(unixTime(r, "a").Unix(), 10)
	case "ctime":
		return strconv.FormatInt(unixTime(r, "c").Unix(), 10)
	case "is_dir":
		return bools(r.info.IsDir())
	case "is_file":
		return bools(r.info.Mode().IsRegular())
	case "is_symlink":
		return bools(r.lstat.Mode()&os.ModeSymlink != 0)
	case "is_pipe", "is_fifo":
		return bools(r.info.Mode()&os.ModeNamedPipe != 0)
	case "is_char", "is_character":
		return bools(r.info.Mode()&os.ModeCharDevice != 0)
	case "is_block":
		return bools(r.info.Mode()&os.ModeDevice != 0 && r.info.Mode()&os.ModeCharDevice == 0)
	case "is_socket":
		return bools(r.info.Mode()&os.ModeSocket != 0)
	case "is_hidden":
		return bools(strings.HasPrefix(filepath.Base(r.rel), "."))
	case "is_empty":
		return bools(isEmpty(r))
	case "is_shebang":
		return bools(hasPrefixFile(r.abs, "#!"))
	case "mode":
		return modeString(r.lstat.Mode())
	case "uid":
		st := statT(r)
		return strconv.Itoa(int(st.Uid))
	case "gid":
		st := statT(r)
		return strconv.Itoa(int(st.Gid))
	case "user":
		st := statT(r)
		u, _ := user.LookupId(strconv.Itoa(int(st.Uid)))
		if u != nil {
			return u.Username
		}
		return strconv.Itoa(int(st.Uid))
	case "group":
		st := statT(r)
		g, _ := user.LookupGroupId(strconv.Itoa(int(st.Gid)))
		if g != nil {
			return g.Name
		}
		return strconv.Itoa(int(st.Gid))
	case "device":
		st := statT(r)
		return strconv.FormatUint(uint64(st.Dev), 10)
	case "rdev":
		st := statT(r)
		return strconv.FormatUint(uint64(st.Rdev), 10)
	case "inode":
		st := statT(r)
		return strconv.FormatUint(uint64(st.Ino), 10)
	case "blocks":
		st := statT(r)
		return strconv.FormatInt(st.Blocks*2, 10)
	case "hardlinks":
		st := statT(r)
		return strconv.FormatUint(uint64(st.Nlink), 10)
	case "user_read":
		return perm(r, 0400)
	case "user_write":
		return perm(r, 0200)
	case "user_exec":
		return perm(r, 0100)
	case "user_all", "user_rwx":
		return bools(hasPerm(r, 0700))
	case "group_read":
		return perm(r, 0040)
	case "group_write":
		return perm(r, 0020)
	case "group_exec":
		return perm(r, 0010)
	case "group_all", "group_rwx":
		return bools(hasPerm(r, 0070))
	case "other_read":
		return perm(r, 0004)
	case "other_write":
		return perm(r, 0002)
	case "other_exec":
		return perm(r, 0001)
	case "other_all", "other_rwx":
		return bools(hasPerm(r, 0007))
	case "suid", "is_suid":
		return bools(r.info.Mode()&os.ModeSetuid != 0)
	case "sgid", "is_sgid":
		return bools(r.info.Mode()&os.ModeSetgid != 0)
	case "sticky", "is_sticky":
		return bools(r.info.Mode()&os.ModeSticky != 0)
	case "line_count":
		if !r.info.Mode().IsRegular() {
			return ""
		}
		return strconv.Itoa(lineCount(r.abs))
	case "is_binary":
		return bools(isBinary(r.abs))
	case "is_text":
		return bools(!isBinary(r.abs) && r.info.Mode().IsRegular())
	case "mime":
		return mimeType(r)
	case "is_archive":
		return bools(inExt(r, archiveExt))
	case "is_audio":
		return bools(inExt(r, audioExt))
	case "is_book":
		return bools(inExt(r, bookExt))
	case "is_doc":
		return bools(inExt(r, docExt))
	case "is_font":
		return bools(inExt(r, fontExt))
	case "is_image":
		return bools(inExt(r, imageExt))
	case "is_source":
		return bools(inExt(r, sourceExt))
	case "is_video":
		return bools(inExt(r, videoExt))
	case "sha1":
		return digest(r, sha1.New())
	case "sha2_256", "sha256":
		return digest(r, sha256.New())
	case "sha2_512", "sha512":
		return digest(r, sha512.New())
	case "width", "height", "duration", "mp3_bitrate", "bitrate", "mp3_freq", "freq", "mp3_title", "title", "mp3_artist", "artist", "mp3_album", "album", "mp3_year", "mp3_genre", "genre":
		return ""
	}
	return strings.Trim(name, "'\"`")
}

func printRows(q *query, rows []map[string]string) {
	cols := make([]string, len(q.cols))
	for i, c := range q.cols {
		cols[i] = columnTitle(c)
	}
	switch q.format {
	case "csv":
		w := csv.NewWriter(os.Stdout)
		for _, m := range rows {
			rec := []string{}
			for _, c := range cols {
				rec = append(rec, m[c])
			}
			_ = w.Write(rec)
		}
		w.Flush()
	case "json":
		arr := []map[string]string{}
		for _, m := range rows {
			obj := map[string]string{}
			for _, c := range cols {
				obj[columnJSON(c)] = m[c]
			}
			arr = append(arr, obj)
		}
		b, _ := json.Marshal(arr)
		fmt.Print(string(b))
	case "lines":
		for _, m := range rows {
			for _, c := range cols {
				fmt.Println(m[c])
			}
		}
	case "list":
		for _, m := range rows {
			for _, c := range cols {
				fmt.Print(m[c])
				fmt.Print("\x00")
			}
		}
	case "html":
		fmt.Printf("<html><head><title>%s</title></head><body><table><tr><th colspan=\"%d\">%s</th></tr>", html.EscapeString(q.original), len(cols), html.EscapeString(q.original))
		for _, m := range rows {
			fmt.Print("<tr>")
			for _, c := range cols {
				fmt.Printf("<td>%s</td>", html.EscapeString(m[c]))
			}
			fmt.Print("</tr>")
		}
		fmt.Print("</table></body></html>")
	default:
		for _, m := range rows {
			rec := []string{}
			for _, c := range cols {
				rec = append(rec, m[c])
			}
			fmt.Println(strings.Join(rec, "\t"))
		}
	}
}

func isAggregateList(cols []string) bool {
	for _, c := range cols {
		if isAgg(c) {
			return true
		}
	}
	return false
}
func normCall(c string) string {
	return strings.ReplaceAll(strings.ToLower(strings.TrimSpace(c)), " ", "")
}
func isAgg(c string) bool {
	l := normCall(c)
	return strings.HasPrefix(l, "count(") || strings.HasPrefix(l, "sum(") || strings.HasPrefix(l, "min(") || strings.HasPrefix(l, "max(") || strings.HasPrefix(l, "avg(") || strings.HasPrefix(l, "stddev") || strings.HasPrefix(l, "var_") || strings.HasPrefix(l, "variance(")
}
func aggregateRow(cols []string, rows []fileRow) map[string]string {
	m := map[string]string{}
	for _, c := range cols {
		l := normCall(c)
		inner := "*"
		if i := strings.Index(strings.TrimSpace(c), "("); i >= 0 && strings.HasSuffix(strings.TrimSpace(c), ")") {
			cc := strings.TrimSpace(c)
			inner = strings.TrimSpace(cc[i+1 : len(cc)-1])
		}
		vals := []float64{}
		for _, r := range rows {
			vals = append(vals, toFloat(evalExpr(inner, r)))
		}
		var v string
		switch {
		case strings.HasPrefix(l, "count("):
			v = strconv.Itoa(len(rows))
		case strings.HasPrefix(l, "sum("):
			s := 0.0
			for _, x := range vals {
				s += x
			}
			v = num(s)
		case strings.HasPrefix(l, "min("):
			if len(vals) == 0 {
				v = ""
			} else {
				mn := vals[0]
				for _, x := range vals {
					if x < mn {
						mn = x
					}
				}
				v = num(mn)
			}
		case strings.HasPrefix(l, "max("):
			if len(vals) == 0 {
				v = ""
			} else {
				mx := vals[0]
				for _, x := range vals {
					if x > mx {
						mx = x
					}
				}
				v = num(mx)
			}
		case strings.HasPrefix(l, "avg("):
			s := 0.0
			for _, x := range vals {
				s += x
			}
			if len(vals) > 0 {
				v = num(math.Floor(s / float64(len(vals))))
			}
		default:
			v = ""
		}
		m[columnTitle(c)] = v
	}
	return m
}

func groupRows(q *query, rows []fileRow) []fileRow {
	seen := map[string]bool{}
	out := []fileRow{}
	for _, r := range rows {
		parts := []string{}
		for _, g := range q.groupCols {
			parts = append(parts, evalExpr(g, r))
		}
		k := strings.Join(parts, "\x00")
		if !seen[k] {
			seen[k] = true
			out = append(out, r)
		}
	}
	return out
}

func columnTitle(c string) string { return strings.TrimSpace(c) }
func columnJSON(c string) string {
	c = strings.TrimSpace(c)
	if strings.ContainsAny(c, "({ +-*/%") {
		return c
	}
	return strings.Title(strings.ToLower(c))
}
func eq(a, b string) bool { return strings.EqualFold(a, b) }
func atoi(s string) int   { n, _ := strconv.Atoi(strings.TrimSpace(s)); return n }
func toFloat(s string) float64 {
	s = strings.TrimSpace(s)
	if n, ok := parseSize(s); ok {
		return float64(n)
	}
	f, _ := strconv.ParseFloat(s, 64)
	return f
}
func num(f float64) string {
	if math.IsNaN(f) || math.IsInf(f, 0) {
		return ""
	}
	if math.Abs(f-math.Round(f)) < 1e-9 {
		return strconv.FormatInt(int64(math.Round(f)), 10)
	}
	return strconv.FormatFloat(f, 'f', -1, 64)
}
func fabs(f float64) float64 {
	if f < 0 {
		return -f
	}
	return f
}
func bools(b bool) string {
	if b {
		return "true"
	}
	return "false"
}
func truth(s string) bool {
	return eq(s, "true") || s == "1" || (!eq(s, "false") && s != "0" && s != "")
}
func compareVals(a, b string) int {
	af, ae := strconv.ParseFloat(a, 64)
	bf, be := strconv.ParseFloat(b, 64)
	if ae == nil && be == nil {
		if af < bf {
			return -1
		}
		if af > bf {
			return 1
		}
		return 0
	}
	if a < b {
		return -1
	}
	if a > b {
		return 1
	}
	return 0
}
func matchGlobOrEqual(a, b string) bool {
	if strings.ContainsAny(b, "*?[]") {
		ok, _ := filepath.Match(b, a)
		return ok
	}
	return a == b
}
func likeMatch(a, p string) bool {
	var b strings.Builder
	b.WriteString("^")
	for _, r := range p {
		switch r {
		case '%':
			b.WriteString(".*")
		case '_':
			b.WriteByte('.')
		default:
			b.WriteString(regexp.QuoteMeta(string(r)))
		}
	}
	b.WriteString("$")
	ok, _ := regexp.MatchString(b.String(), a)
	return ok
}
func parseSize(s string) (int64, bool) {
	re := regexp.MustCompile(`(?i)^([0-9]+)([kmgt]i?b?|kb|mb|gb|tb)?$`)
	m := re.FindStringSubmatch(strings.TrimSpace(s))
	if m == nil {
		return 0, false
	}
	n, _ := strconv.ParseInt(m[1], 10, 64)
	mult := int64(1)
	switch strings.ToLower(m[2]) {
	case "k", "kib":
		mult = 1024
	case "kb":
		mult = 1000
	case "m", "mib":
		mult = 1024 * 1024
	case "mb":
		mult = 1000 * 1000
	case "g", "gib":
		mult = 1024 * 1024 * 1024
	case "gb":
		mult = 1000 * 1000 * 1000
	case "t", "tib":
		mult = 1024 * 1024 * 1024 * 1024
	case "tb":
		mult = 1000 * 1000 * 1000 * 1000
	}
	return n * mult, true
}
func extPart(base string) string {
	if strings.HasPrefix(base, ".") && strings.Count(base, ".") == 1 {
		return ""
	}
	return filepath.Ext(base)
}

func statT(r fileRow) *syscall.Stat_t {
	if st, ok := r.lstat.Sys().(*syscall.Stat_t); ok {
		return st
	}
	return &syscall.Stat_t{}
}
func unixTime(r fileRow, which string) time.Time {
	st := statT(r)
	if which == "c" {
		return time.Unix(st.Ctim.Sec, st.Ctim.Nsec)
	}
	return time.Unix(st.Atim.Sec, st.Atim.Nsec)
}
func modeString(m os.FileMode) string {
	s := m.String()
	if len(s) == 10 {
		return s
	}
	perms := "----------"
	if m.IsDir() {
		perms = "d" + perms[1:]
	} else if m&os.ModeSymlink != 0 {
		perms = "l" + perms[1:]
	}
	bits := []struct {
		b os.FileMode
		i int
		c byte
	}{{0400, 1, 'r'}, {0200, 2, 'w'}, {0100, 3, 'x'}, {0040, 4, 'r'}, {0020, 5, 'w'}, {0010, 6, 'x'}, {0004, 7, 'r'}, {0002, 8, 'w'}, {0001, 9, 'x'}}
	bs := []byte(perms)
	for _, x := range bits {
		if m&x.b != 0 {
			bs[x.i] = x.c
		}
	}
	return string(bs)
}
func hasPerm(r fileRow, p os.FileMode) bool { return r.info.Mode().Perm()&p == p }
func perm(r fileRow, p os.FileMode) string  { return bools(r.info.Mode().Perm()&p != 0) }
func isEmpty(r fileRow) bool {
	if r.info.IsDir() {
		f, e := os.Open(r.abs)
		if e != nil {
			return false
		}
		defer f.Close()
		_, e = f.Readdirnames(1)
		return e == io.EOF
	}
	return r.info.Size() == 0
}
func hasPrefixFile(p, prefix string) bool {
	f, e := os.Open(p)
	if e != nil {
		return false
	}
	defer f.Close()
	b := make([]byte, len(prefix))
	n, _ := f.Read(b)
	return n == len(prefix) && string(b) == prefix
}
func lineCount(p string) int {
	f, e := os.Open(p)
	if e != nil {
		return 0
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	n := 0
	for sc.Scan() {
		n++
	}
	return n
}
func isBinary(p string) bool {
	f, e := os.Open(p)
	if e != nil {
		return false
	}
	defer f.Close()
	b := make([]byte, 8000)
	n, _ := f.Read(b)
	for _, c := range b[:n] {
		if c == 0 {
			return true
		}
	}
	return false
}
func digest(r fileRow, h hash.Hash) string {
	if !r.info.Mode().IsRegular() {
		return ""
	}
	f, e := os.Open(r.abs)
	if e != nil {
		return ""
	}
	defer f.Close()
	_, _ = io.Copy(h, f)
	return hex.EncodeToString(h.Sum(nil))
}
func humanSize(n int64) string {
	units := []string{"B", "K", "M", "G", "T"}
	f := float64(n)
	i := 0
	for f >= 1024 && i < len(units)-1 {
		f /= 1024
		i++
	}
	if i == 0 {
		return fmt.Sprintf("%dB", n)
	}
	if f == math.Trunc(f) {
		return fmt.Sprintf("%.0f%s", f, units[i])
	}
	return fmt.Sprintf("%.1f%s", f, units[i])
}
func datePart(s, part string) string {
	layouts := []string{"2006-01-02 15:04:05", "2006-01-02"}
	var t time.Time
	var e error
	for _, l := range layouts {
		t, e = time.ParseInLocation(l, s, time.Local)
		if e == nil {
			break
		}
	}
	if e != nil {
		return ""
	}
	switch part {
	case "year":
		return strconv.Itoa(t.Year())
	case "month":
		return strconv.Itoa(int(t.Month()))
	case "day":
		return strconv.Itoa(t.Day())
	case "dow":
		return strconv.Itoa(int(t.Weekday()) + 1)
	case "dayname":
		return t.Weekday().String()
	case "doy":
		return strconv.Itoa(t.YearDay())
	}
	return ""
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

var archiveExt = map[string]bool{".7z": true, ".bz2": true, ".bzip2": true, ".gz": true, ".gzip": true, ".lz": true, ".rar": true, ".tar": true, ".xz": true, ".zip": true}
var audioExt = map[string]bool{".aac": true, ".aiff": true, ".amr": true, ".flac": true, ".gsm": true, ".m4a": true, ".m4b": true, ".m4p": true, ".mp3": true, ".ogg": true, ".wav": true, ".wma": true}
var bookExt = map[string]bool{".azw3": true, ".chm": true, ".djv": true, ".djvu": true, ".epub": true, ".fb2": true, ".mobi": true, ".pdf": true}
var docExt = map[string]bool{".accdb": true, ".doc": true, ".docm": true, ".docx": true, ".dot": true, ".dotm": true, ".dotx": true, ".mdb": true, ".odp": true, ".ods": true, ".odt": true, ".pdf": true, ".potm": true, ".potx": true, ".ppt": true, ".pptm": true, ".pptx": true, ".rtf": true, ".xlm": true, ".xls": true, ".xlsm": true, ".xlsx": true, ".xlt": true, ".xltm": true, ".xltx": true, ".xps": true}
var fontExt = map[string]bool{".eot": true, ".fon": true, ".otc": true, ".otf": true, ".ttc": true, ".ttf": true, ".woff": true, ".woff2": true}
var imageExt = map[string]bool{".bmp": true, ".exr": true, ".gif": true, ".heic": true, ".jpeg": true, ".jpg": true, ".jxl": true, ".png": true, ".psb": true, ".psd": true, ".svg": true, ".tga": true, ".tiff": true, ".webp": true}
var sourceExt = map[string]bool{".asm": true, ".awk": true, ".bas": true, ".c": true, ".cc": true, ".ceylon": true, ".clj": true, ".coffee": true, ".cpp": true, ".cs": true, ".d": true, ".dart": true, ".elm": true, ".erl": true, ".go": true, ".gradle": true, ".groovy": true, ".h": true, ".hh": true, ".hpp": true, ".java": true, ".jl": true, ".js": true, ".jsp": true, ".jsx": true, ".kt": true, ".kts": true, ".lua": true, ".nim": true, ".pas": true, ".php": true, ".pl": true, ".pm": true, ".py": true, ".rb": true, ".rs": true, ".scala": true, ".sol": true, ".swift": true, ".tcl": true, ".ts": true, ".tsx": true, ".vala": true, ".vb": true, ".zig": true}
var videoExt = map[string]bool{".3gp": true, ".avi": true, ".flv": true, ".m4p": true, ".m4v": true, ".mkv": true, ".mov": true, ".mp4": true, ".mpeg": true, ".mpg": true, ".webm": true, ".wmv": true}

func inExt(r fileRow, set map[string]bool) bool { return set[strings.ToLower(filepath.Ext(r.rel))] }
func mimeType(r fileRow) string {
	e := strings.ToLower(filepath.Ext(r.rel))
	switch e {
	case ".txt", ".md", ".go", ".rs", ".c", ".h", ".py", ".js", ".json", ".toml", ".yaml", ".yml":
		return "text/plain"
	case ".jpg", ".jpeg":
		return "image/jpeg"
	case ".png":
		return "image/png"
	case ".gif":
		return "image/gif"
	case ".pdf":
		return "application/pdf"
	case ".zip":
		return "application/zip"
	}
	if r.info.IsDir() {
		return "inode/directory"
	}
	return "application/octet-stream"
}
