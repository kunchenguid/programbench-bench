module pandoc-reimpl

go 1.21
