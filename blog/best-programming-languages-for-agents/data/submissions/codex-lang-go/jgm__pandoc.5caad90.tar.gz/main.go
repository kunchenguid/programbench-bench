package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"html"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const versionText = `pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or fitness for a particular purpose.
`

var inputFormats = []string{"asciidoc", "biblatex", "bibtex", "bits", "commonmark", "commonmark_x", "creole", "csljson", "csv", "djot", "docbook", "docx", "dokuwiki", "endnotexml", "epub", "fb2", "gfm", "haddock", "html", "ipynb", "jats", "jira", "json", "latex", "man", "markdown", "markdown_github", "markdown_mmd", "markdown_phpextra", "markdown_strict", "mdoc", "mediawiki", "muse", "native", "odt", "opml", "org", "pod", "pptx", "ris", "rst", "rtf", "t2t", "textile", "tikiwiki", "tsv", "twiki", "typst", "vimwiki", "xlsx", "xml"}
var outputFormats = []string{"ansi", "asciidoc", "asciidoc_legacy", "asciidoctor", "bbcode", "bbcode_fluxbb", "bbcode_hubzilla", "bbcode_phpbb", "bbcode_steam", "bbcode_xenforo", "beamer", "biblatex", "bibtex", "chunkedhtml", "commonmark", "commonmark_x", "context", "csljson", "djot", "docbook", "docbook4", "docbook5", "docx", "dokuwiki", "dzslides", "epub", "epub2", "epub3", "fb2", "gfm", "haddock", "html", "html4", "html5", "icml", "ipynb", "jats", "jats_archiving", "jats_articleauthoring", "jats_publishing", "jira", "json", "latex", "man", "markdown", "markdown_github", "markdown_mmd", "markdown_phpextra", "markdown_strict", "markua", "mediawiki", "ms", "muse", "native", "odt", "opendocument", "opml", "org", "pdf", "plain", "pptx", "revealjs", "rst", "rtf", "s5", "slideous", "slidy", "tei", "texinfo", "textile", "typst", "vimdoc", "xml", "xwiki", "zimwiki"}

type Options struct {
	from, to, output string
	standalone       bool
	toc              bool
	numberSections   bool
	metadata         map[string]string
	vars             map[string]string
	files            []string
}

type Block struct {
	Kind  string
	Level int
	Text  string
	Info  string
	Items []string
}

type Document struct {
	Meta   map[string]string
	Blocks []Block
}

func main() {
	opts, action, code := parseArgs(os.Args[1:])
	if code != 0 {
		os.Exit(code)
	}
	switch action {
	case "help":
		fmt.Print(helpText())
		return
	case "version":
		fmt.Print(versionText)
		return
	case "list-input-formats":
		printLines(inputFormats)
		return
	case "list-output-formats":
		printLines(outputFormats)
		return
	case "list-extensions":
		printLines(markdownExtensions())
		return
	case "list-highlight-styles":
		printLines([]string{"pygments", "tango", "espresso", "zenburn", "kate", "monochrome", "breezedark", "haddock"})
		return
	case "list-highlight-languages":
		printLines([]string{"abc", "actionscript", "ada", "agda", "apache", "asn1", "asp", "ats", "awk", "bash", "bibtex", "boo", "c", "changelog", "clojure", "cmake", "coffee", "coldfusion", "comments", "commonlisp", "cpp", "css", "diff", "go", "haskell", "html", "java", "javascript", "json", "lua", "markdown", "python", "rust", "xml", "yaml"})
		return
	case "print-default-template":
		fmt.Print("$body$\n")
		return
	}
	if opts.from == "" {
		opts.from = inferInput(opts.files)
	}
	if opts.to == "" {
		opts.to = inferOutput(opts.output)
	}
	if !contains(inputFormats, baseFormat(opts.from)) {
		fmt.Fprintf(os.Stderr, "Unknown input format %s\n", opts.from)
		os.Exit(21)
	}
	if !contains(outputFormats, baseFormat(opts.to)) {
		fmt.Fprintf(os.Stderr, "Unknown output format %s\n", opts.to)
		os.Exit(22)
	}
	content, err := readInputs(opts.files)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	doc := readDocument(content, opts.from)
	for k, v := range opts.metadata {
		doc.Meta[k] = v
	}
	out := renderDocument(doc, opts)
	if opts.output != "" {
		if err := os.WriteFile(opts.output, []byte(out), 0644); err != nil {
			fmt.Fprintf(os.Stderr, "executable: %s: %v\n", opts.output, err)
			os.Exit(1)
		}
		return
	}
	fmt.Print(out)
}

func parseArgs(args []string) (Options, string, int) {
	opts := Options{metadata: map[string]string{}, vars: map[string]string{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opts.files = append(opts.files, args[i+1:]...)
			break
		}
		if a == "-h" || a == "--help" {
			return opts, "help", 0
		}
		if a == "-v" || a == "--version" {
			return opts, "version", 0
		}
		if a == "--list-input-formats" || a == "--list-readers" {
			return opts, "list-input-formats", 0
		}
		if a == "--list-output-formats" || a == "--list-writers" {
			return opts, "list-output-formats", 0
		}
		if strings.HasPrefix(a, "--list-extensions") {
			return opts, "list-extensions", 0
		}
		if a == "--list-highlight-styles" {
			return opts, "list-highlight-styles", 0
		}
		if a == "--list-highlight-languages" {
			return opts, "list-highlight-languages", 0
		}
		if a == "--bash-completion" {
			return opts, "", 0
		}
		if a == "-s" || a == "--standalone" || a == "-s=true" || a == "--standalone=true" {
			opts.standalone = true
			continue
		}
		if a == "-s=false" || a == "--standalone=false" {
			opts.standalone = false
			continue
		}
		if a == "-N" || a == "--number-sections" || a == "-N=true" || a == "--number-sections=true" {
			opts.numberSections = true
			continue
		}
		if a == "--toc" || a == "--table-of-contents" || a == "--toc=true" || a == "--table-of-contents=true" {
			opts.toc = true
			continue
		}
		if strings.HasPrefix(a, "--from=") || strings.HasPrefix(a, "--read=") {
			opts.from = afterEq(a)
			continue
		}
		if strings.HasPrefix(a, "--to=") || strings.HasPrefix(a, "--write=") {
			opts.to = afterEq(a)
			continue
		}
		if strings.HasPrefix(a, "--output=") {
			opts.output = afterEq(a)
			continue
		}
		if strings.HasPrefix(a, "--metadata=") {
			addKV(opts.metadata, afterEq(a))
			continue
		}
		if strings.HasPrefix(a, "--variable=") {
			addKV(opts.vars, afterEq(a))
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) > 2 && (a[1] == 'f' || a[1] == 'r' || a[1] == 't' || a[1] == 'w' || a[1] == 'o') {
			switch a[1] {
			case 'f', 'r':
				opts.from = a[2:]
			case 't', 'w':
				opts.to = a[2:]
			case 'o':
				opts.output = a[2:]
			}
			continue
		}
		if a == "-f" || a == "-r" || a == "--from" || a == "--read" {
			i++
			if i < len(args) {
				opts.from = args[i]
			}
			continue
		}
		if a == "-t" || a == "-w" || a == "--to" || a == "--write" {
			i++
			if i < len(args) {
				opts.to = args[i]
			}
			continue
		}
		if a == "-o" || a == "--output" {
			i++
			if i < len(args) {
				opts.output = args[i]
			}
			continue
		}
		if a == "-M" || a == "--metadata" || a == "-V" || a == "--variable" || a == "--variable-json" {
			i++
			if i < len(args) {
				if a == "-M" || a == "--metadata" {
					addKV(opts.metadata, args[i])
				} else {
					addKV(opts.vars, args[i])
				}
			}
			continue
		}
		if a == "-D" || a == "--print-default-template" {
			return opts, "print-default-template", 0
		}
		if strings.HasPrefix(a, "-D") && len(a) > 2 {
			return opts, "print-default-template", 0
		}
		if strings.HasPrefix(a, "--") {
			name := a
			valInline := strings.Contains(a, "=")
			if valInline {
				name = strings.SplitN(a, "=", 2)[0]
			}
			if optionNeedsValue(name) && !valInline {
				i++
			}
			if knownIgnoredLong(name) {
				continue
			}
			fmt.Fprintf(os.Stderr, "Unknown option %s.\nTry executable --help for more information.\n", a)
			return opts, "", 6
		}
		if strings.HasPrefix(a, "-") && len(a) > 1 {
			if strings.ContainsAny(a[1:], "HCFLABcTdip") {
				if len(a) == 2 && strings.ContainsAny(a[1:], "HFLABcTd") {
					i++
				}
				continue
			}
			fmt.Fprintf(os.Stderr, "Unknown option %s.\nTry executable --help for more information.\n", a)
			return opts, "", 6
		}
		opts.files = append(opts.files, a)
	}
	return opts, "", 0
}

func optionNeedsValue(name string) bool {
	withValue := map[string]bool{"--data-dir": true, "--metadata-file": true, "--defaults": true, "--template": true, "--wrap": true, "--toc-depth": true, "--number-offset": true, "--top-level-division": true, "--extract-media": true, "--resource-path": true, "--include-in-header": true, "--include-before-body": true, "--include-after-body": true, "--highlight-style": true, "--syntax-definition": true, "--syntax-highlighting": true, "--dpi": true, "--eol": true, "--columns": true, "--tab-stop": true, "--pdf-engine": true, "--pdf-engine-opt": true, "--reference-doc": true, "--request-header": true, "--abbreviations": true, "--indented-code-classes": true, "--default-image-extension": true, "--filter": true, "--lua-filter": true, "--shift-heading-level-by": true, "--base-header-level": true, "--track-changes": true, "--reference-location": true, "--figure-caption-position": true, "--table-caption-position": true, "--markdown-headings": true, "--slide-level": true, "--email-obfuscation": true, "--id-prefix": true, "--title-prefix": true, "--css": true, "--epub-subdirectory": true, "--epub-cover-image": true, "--epub-metadata": true, "--epub-embed-font": true, "--split-level": true, "--chunk-template": true, "--epub-chapter-level": true, "--ipynb-output": true, "--bibliography": true, "--csl": true, "--citation-abbreviations": true, "--log": true, "--print-default-data-file": true, "--print-highlight-style": true}
	return withValue[name]
}

func knownIgnoredLong(name string) bool {
	ignored := map[string]bool{"--file-scope": true, "--sandbox": true, "--ascii": true, "--lof": true, "--list-of-figures": true, "--lot": true, "--list-of-tables": true, "--no-highlight": true, "--preserve-tabs": true, "--self-contained": true, "--embed-resources": true, "--link-images": true, "--no-check-certificate": true, "--strip-comments": true, "--reference-links": true, "--list-tables": true, "--listings": true, "--incremental": true, "--section-divs": true, "--html-q-tags": true, "--epub-title-page": true, "--citeproc": true, "--natbib": true, "--biblatex": true, "--mathml": true, "--webtex": true, "--mathjax": true, "--katex": true, "--gladtex": true, "--trace": true, "--dump-args": true, "--ignore-args": true, "--verbose": true, "--quiet": true, "--fail-if-warnings": true}
	return ignored[name] || optionNeedsValue(name)
}

func readInputs(files []string) (string, error) {
	if len(files) == 0 {
		b, _ := io.ReadAll(os.Stdin)
		return string(b), nil
	}
	var parts []string
	for _, f := range files {
		if f == "-" {
			b, _ := io.ReadAll(os.Stdin)
			parts = append(parts, string(b))
			continue
		}
		b, err := os.ReadFile(f)
		if err != nil {
			if filepath.Ext(f) == "" {
				fmt.Fprintln(os.Stderr, "[WARNING] Could not deduce format from file extension \n  Defaulting to markdown")
			}
			return "", fmt.Errorf("executable: %s: withBinaryFile: does not exist (No such file or directory)", f)
		}
		parts = append(parts, string(b))
	}
	return strings.Join(parts, "\n"), nil
}

func readDocument(s, from string) Document {
	base := baseFormat(from)
	if base == "html" || base == "html4" || base == "html5" {
		s = htmlToMarkdown(s)
	}
	if base == "json" {
		return readPandocJSON(s)
	}
	return parseMarkdown(s)
}

func parseMarkdown(s string) Document {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	doc := Document{Meta: map[string]string{}}
	lines := strings.Split(s, "\n")
	i := 0
	if len(lines) > 0 && strings.TrimSpace(lines[0]) == "---" {
		i = 1
		for i < len(lines) && strings.TrimSpace(lines[i]) != "---" && strings.TrimSpace(lines[i]) != "..." {
			line := strings.TrimSpace(lines[i])
			if p := strings.Index(line, ":"); p >= 0 {
				doc.Meta[strings.TrimSpace(line[:p])] = strings.TrimSpace(line[p+1:])
			}
			i++
		}
		if i < len(lines) {
			i++
		}
	}
	for i < len(lines) {
		line := lines[i]
		trim := strings.TrimSpace(line)
		if trim == "" {
			i++
			continue
		}
		if strings.HasPrefix(trim, "```") || strings.HasPrefix(trim, "~~~") {
			fence := trim[:3]
			info := strings.TrimSpace(trim[3:])
			var body []string
			i++
			for i < len(lines) && !strings.HasPrefix(strings.TrimSpace(lines[i]), fence) {
				body = append(body, lines[i])
				i++
			}
			if i < len(lines) {
				i++
			}
			doc.Blocks = append(doc.Blocks, Block{Kind: "code", Info: info, Text: strings.Join(body, "\n")})
			continue
		}
		if strings.HasPrefix(trim, "#") {
			level := 0
			for level < len(trim) && trim[level] == '#' {
				level++
			}
			if level <= 6 && level < len(trim) && unicode.IsSpace(rune(trim[level])) {
				text := strings.TrimSpace(trim[level:])
				text = strings.TrimSpace(strings.TrimSuffix(text, "#"))
				doc.Blocks = append(doc.Blocks, Block{Kind: "heading", Level: level, Text: text})
				i++
				continue
			}
		}
		if i+1 < len(lines) {
			next := strings.TrimSpace(lines[i+1])
			if allRunes(next, '=') || allRunes(next, '-') {
				lvl := 1
				if strings.HasPrefix(next, "-") {
					lvl = 2
				}
				doc.Blocks = append(doc.Blocks, Block{Kind: "heading", Level: lvl, Text: trim})
				i += 2
				continue
			}
		}
		if trim == "---" || trim == "***" || trim == "___" {
			doc.Blocks = append(doc.Blocks, Block{Kind: "hr"})
			i++
			continue
		}
		if isUList(trim) {
			var items []string
			for i < len(lines) && isUList(strings.TrimSpace(lines[i])) {
				items = append(items, strings.TrimSpace(lines[i])[2:])
				i++
			}
			doc.Blocks = append(doc.Blocks, Block{Kind: "ul", Items: items})
			continue
		}
		if ok, item := isOList(trim); ok {
			var items []string
			items = append(items, item)
			i++
			for i < len(lines) {
				if ok, item := isOList(strings.TrimSpace(lines[i])); ok {
					items = append(items, item)
					i++
				} else {
					break
				}
			}
			doc.Blocks = append(doc.Blocks, Block{Kind: "ol", Items: items})
			continue
		}
		if strings.HasPrefix(trim, ">") {
			var qs []string
			for i < len(lines) && strings.HasPrefix(strings.TrimSpace(lines[i]), ">") {
				qs = append(qs, strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(lines[i]), ">")))
				i++
			}
			doc.Blocks = append(doc.Blocks, Block{Kind: "quote", Text: strings.Join(qs, "\n")})
			continue
		}
		if strings.HasPrefix(line, "    ") || strings.HasPrefix(line, "\t") {
			var body []string
			for i < len(lines) && (strings.HasPrefix(lines[i], "    ") || strings.HasPrefix(lines[i], "\t") || strings.TrimSpace(lines[i]) == "") {
				body = append(body, strings.TrimPrefix(strings.TrimPrefix(lines[i], "    "), "\t"))
				i++
			}
			doc.Blocks = append(doc.Blocks, Block{Kind: "code", Text: strings.TrimRight(strings.Join(body, "\n"), "\n")})
			continue
		}
		var para []string
		for i < len(lines) && strings.TrimSpace(lines[i]) != "" {
			t := strings.TrimSpace(lines[i])
			if startsBlock(t) && len(para) > 0 {
				break
			}
			para = append(para, t)
			i++
		}
		doc.Blocks = append(doc.Blocks, Block{Kind: "para", Text: strings.Join(para, " ")})
	}
	return doc
}

func renderDocument(doc Document, opts Options) string {
	switch baseFormat(opts.to) {
	case "plain", "ansi":
		return renderPlain(doc)
	case "markdown", "markdown_strict", "markdown_mmd", "markdown_phpextra", "markdown_github", "gfm", "commonmark", "commonmark_x":
		return renderMarkdown(doc)
	case "json":
		return renderJSON(doc)
	case "native":
		return renderNative(doc)
	case "latex", "beamer":
		return renderLatex(doc)
	case "rst":
		return renderRST(doc)
	case "html", "html4", "html5", "chunkedhtml", "revealjs", "s5", "slidy", "slideous", "dzslides":
		body := renderHTMLBlocks(doc, opts)
		if opts.standalone {
			title := doc.Meta["title"]
			if title == "" {
				title = "-"
			}
			return "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=yes\" />\n  <title>" + html.EscapeString(title) + "</title>\n</head>\n<body>\n" + body + "</body>\n</html>\n"
		}
		return body
	case "docbook", "docbook4", "docbook5", "xml", "jats", "tei":
		return "<article>\n" + renderXMLBlocks(doc) + "</article>\n"
	default:
		return renderMarkdown(doc)
	}
}

func renderHTMLBlocks(doc Document, opts Options) string {
	var b strings.Builder
	if opts.toc {
		b.WriteString("<nav id=\"TOC\" role=\"doc-toc\">\n<ul>\n")
		for _, bl := range doc.Blocks {
			if bl.Kind == "heading" {
				id := headingID(bl.Text)
				fmt.Fprintf(&b, "<li><a href=\"#%s\">%s</a></li>\n", id, html.EscapeString(stripInlines(bl.Text)))
			}
		}
		b.WriteString("</ul>\n</nav>\n")
	}
	num := make([]int, 7)
	for _, bl := range doc.Blocks {
		switch bl.Kind {
		case "heading":
			text := bl.Text
			if opts.numberSections {
				num[bl.Level]++
				for j := bl.Level + 1; j < len(num); j++ {
					num[j] = 0
				}
				var parts []string
				for j := 1; j <= bl.Level; j++ {
					if num[j] > 0 {
						parts = append(parts, strconv.Itoa(num[j]))
					}
				}
				text = strings.Join(parts, ".") + " " + text
			}
			attrs := headingAttrs(bl.Text)
			fmt.Fprintf(&b, "<h%d%s>%s</h%d>\n", bl.Level, attrs, renderInlines(text), bl.Level)
		case "para":
			fmt.Fprintf(&b, "<p>%s</p>\n", renderInlines(bl.Text))
		case "ul":
			b.WriteString("<ul>\n")
			for _, it := range bl.Items {
				fmt.Fprintf(&b, "<li>%s</li>\n", renderInlines(it))
			}
			b.WriteString("</ul>\n")
		case "ol":
			b.WriteString("<ol type=\"1\">\n")
			for _, it := range bl.Items {
				fmt.Fprintf(&b, "<li>%s</li>\n", renderInlines(it))
			}
			b.WriteString("</ol>\n")
		case "quote":
			fmt.Fprintf(&b, "<blockquote>\n<p>%s</p>\n</blockquote>\n", renderInlines(strings.ReplaceAll(bl.Text, "\n", " ")))
		case "code":
			code := html.EscapeString(bl.Text)
			if bl.Info != "" {
				cls := strings.Fields(bl.Info)[0]
				fmt.Fprintf(&b, "<div class=\"sourceCode\"><pre class=\"sourceCode %s\"><code class=\"sourceCode %s\">%s</code></pre></div>\n", html.EscapeString(cls), html.EscapeString(cls), code)
			} else {
				fmt.Fprintf(&b, "<pre><code>%s</code></pre>\n", code)
			}
		case "hr":
			b.WriteString("<hr />\n")
		}
	}
	return b.String()
}

func renderPlain(doc Document) string {
	var b strings.Builder
	for idx, bl := range doc.Blocks {
		if idx > 0 {
			b.WriteString("\n")
		}
		switch bl.Kind {
		case "heading", "para":
			b.WriteString(stripInlines(bl.Text))
			b.WriteString("\n")
		case "ul":
			for _, it := range bl.Items {
				b.WriteString("- ")
				b.WriteString(stripInlines(it))
				b.WriteString("\n")
			}
		case "ol":
			for i, it := range bl.Items {
				fmt.Fprintf(&b, "%d.  %s\n", i+1, stripInlines(it))
			}
		case "quote":
			for _, l := range strings.Split(stripInlines(bl.Text), "\n") {
				b.WriteString("  ")
				b.WriteString(l)
				b.WriteString("\n")
			}
		case "code":
			b.WriteString(bl.Text)
			b.WriteString("\n")
		}
	}
	return b.String()
}

func renderMarkdown(doc Document) string {
	var b strings.Builder
	for i, bl := range doc.Blocks {
		if i > 0 {
			b.WriteString("\n")
		}
		switch bl.Kind {
		case "heading":
			b.WriteString(strings.Repeat("#", bl.Level) + " " + cleanHeadingText(bl.Text) + "\n")
		case "para":
			b.WriteString(bl.Text + "\n")
		case "ul":
			for _, it := range bl.Items {
				b.WriteString("- " + it + "\n")
			}
		case "ol":
			for i, it := range bl.Items {
				fmt.Fprintf(&b, "%d.  %s\n", i+1, it)
			}
		case "quote":
			for _, l := range strings.Split(bl.Text, "\n") {
				b.WriteString("> " + l + "\n")
			}
		case "code":
			fence := "```"
			b.WriteString(fence + bl.Info + "\n" + bl.Text + "\n" + fence + "\n")
		case "hr":
			b.WriteString("---\n")
		}
	}
	return b.String()
}

func renderLatex(doc Document) string {
	var b strings.Builder
	cmds := []string{"section", "subsection", "subsubsection", "paragraph", "subparagraph", "subparagraph"}
	for _, bl := range doc.Blocks {
		switch bl.Kind {
		case "heading":
			level := bl.Level
			if level < 1 || level > len(cmds) {
				level = 1
			}
			fmt.Fprintf(&b, "\\%s{%s}\n\n", cmds[level-1], escapeLatex(stripInlines(bl.Text)))
		case "para":
			b.WriteString(escapeLatex(stripInlines(bl.Text)) + "\n\n")
		case "ul":
			b.WriteString("\\begin{itemize}\n")
			for _, it := range bl.Items {
				b.WriteString("\\item " + escapeLatex(stripInlines(it)) + "\n")
			}
			b.WriteString("\\end{itemize}\n\n")
		case "ol":
			b.WriteString("\\begin{enumerate}\n")
			for _, it := range bl.Items {
				b.WriteString("\\item " + escapeLatex(stripInlines(it)) + "\n")
			}
			b.WriteString("\\end{enumerate}\n\n")
		case "code":
			b.WriteString("\\begin{verbatim}\n" + bl.Text + "\n\\end{verbatim}\n\n")
		}
	}
	return b.String()
}

func renderRST(doc Document) string {
	var b strings.Builder
	under := []string{"=", "-", "~", "^", "\"", "'"}
	for _, bl := range doc.Blocks {
		switch bl.Kind {
		case "heading":
			txt := stripInlines(bl.Text)
			b.WriteString(txt + "\n" + strings.Repeat(under[min(bl.Level-1, len(under)-1)], len(txt)) + "\n\n")
		case "para":
			b.WriteString(stripInlines(bl.Text) + "\n\n")
		case "ul":
			for _, it := range bl.Items {
				b.WriteString("* " + stripInlines(it) + "\n")
			}
			b.WriteString("\n")
		case "ol":
			for i, it := range bl.Items {
				fmt.Fprintf(&b, "%d. %s\n", i+1, stripInlines(it))
			}
			b.WriteString("\n")
		}
	}
	return b.String()
}

func renderXMLBlocks(doc Document) string {
	var b strings.Builder
	for _, bl := range doc.Blocks {
		switch bl.Kind {
		case "heading":
			fmt.Fprintf(&b, "<section><title>%s</title></section>\n", html.EscapeString(stripInlines(bl.Text)))
		case "para":
			fmt.Fprintf(&b, "<para>%s</para>\n", html.EscapeString(stripInlines(bl.Text)))
		}
	}
	return b.String()
}

func renderJSON(doc Document) string {
	var blocks []any
	for _, bl := range doc.Blocks {
		switch bl.Kind {
		case "heading":
			blocks = append(blocks, map[string]any{"t": "Header", "c": []any{bl.Level, []any{headingID(bl.Text), []any{}, []any{}}, inlinesJSON(stripInlines(bl.Text))}})
		case "para":
			blocks = append(blocks, map[string]any{"t": "Para", "c": inlinesJSON(stripInlines(bl.Text))})
		case "ul":
			var items []any
			for _, it := range bl.Items {
				items = append(items, []any{map[string]any{"t": "Plain", "c": inlinesJSON(stripInlines(it))}})
			}
			blocks = append(blocks, map[string]any{"t": "BulletList", "c": items})
		case "ol":
			var items []any
			for _, it := range bl.Items {
				items = append(items, []any{map[string]any{"t": "Plain", "c": inlinesJSON(stripInlines(it))}})
			}
			blocks = append(blocks, map[string]any{"t": "OrderedList", "c": []any{[]any{1, map[string]any{"t": "Decimal"}, map[string]any{"t": "Period"}}, items}})
		case "code":
			blocks = append(blocks, map[string]any{"t": "CodeBlock", "c": []any{[]any{"", []any{}, []any{}}, bl.Text}})
		}
	}
	meta := map[string]any{}
	for k, v := range doc.Meta {
		meta[k] = map[string]any{"t": "MetaInlines", "c": inlinesJSON(v)}
	}
	obj := map[string]any{"pandoc-api-version": []int{1, 23, 1, 1}, "meta": meta, "blocks": blocks}
	b, _ := json.Marshal(obj)
	return string(b) + "\n"
}

func renderNative(doc Document) string {
	if len(doc.Blocks) == 0 {
		return "[]\n"
	}
	var parts []string
	for _, bl := range doc.Blocks {
		switch bl.Kind {
		case "heading":
			parts = append(parts, fmt.Sprintf("Header %d ( %q , [] , [] ) [ Str %q ]", bl.Level, headingID(bl.Text), stripInlines(bl.Text)))
		case "para":
			parts = append(parts, "Para [ Str "+strconv.Quote(stripInlines(bl.Text))+" ]")
		case "ul":
			var its []string
			for _, it := range bl.Items {
				its = append(its, "[ Plain [ Str "+strconv.Quote(stripInlines(it))+" ] ]")
			}
			parts = append(parts, "BulletList [ "+strings.Join(its, " , ")+" ]")
		case "ol":
			parts = append(parts, "OrderedList ( 1 , Decimal , Period ) []")
		}
	}
	return "[ " + strings.Join(parts, "\n, ") + "\n]\n"
}

func renderInlines(s string) string {
	s = cleanHeadingText(s)
	esc := html.EscapeString(s)
	repls := []struct{ re, to string }{
		{"!\\[([^\\]]*)\\]\\(([^)]+)\\)", `<img src="$2" alt="$1" />`},
		{"\\[([^\\]]+)\\]\\(([^)]+)\\)", `<a href="$2">$1</a>`},
		{"`([^`]+)`", `<code>$1</code>`},
		{"\\*\\*([^*]+)\\*\\*", `<strong>$1</strong>`},
		{"__([^_]+)__", `<strong>$1</strong>`},
		{"\\*([^*]+)\\*", `<em>$1</em>`},
		{"_([^_]+)_", `<em>$1</em>`},
	}
	for _, r := range repls {
		esc = regexp.MustCompile(r.re).ReplaceAllString(esc, r.to)
	}
	return esc
}

func stripInlines(s string) string {
	s = cleanHeadingText(s)
	s = regexp.MustCompile(`!\[([^\]]*)\]\([^)]+\)`).ReplaceAllString(s, "$1")
	s = regexp.MustCompile(`\[([^\]]+)\]\([^)]+\)`).ReplaceAllString(s, "$1")
	s = regexp.MustCompile("`([^`]+)`").ReplaceAllString(s, "$1")
	s = strings.ReplaceAll(s, "**", "")
	s = strings.ReplaceAll(s, "__", "")
	s = strings.ReplaceAll(s, "*", "")
	s = strings.ReplaceAll(s, "_", "")
	return html.UnescapeString(s)
}

func htmlToMarkdown(s string) string {
	s = regexp.MustCompile(`(?is)<h([1-6])[^>]*>(.*?)</h[1-6]>`).ReplaceAllStringFunc(s, func(m string) string {
		re := regexp.MustCompile(`(?is)<h([1-6])[^>]*>(.*?)</h[1-6]>`)
		sub := re.FindStringSubmatch(m)
		lvl, _ := strconv.Atoi(sub[1])
		return "\n" + strings.Repeat("#", lvl) + " " + stripTags(sub[2]) + "\n\n"
	})
	s = regexp.MustCompile(`(?is)<li[^>]*>(.*?)</li>`).ReplaceAllString(s, "- $1\n")
	s = regexp.MustCompile(`(?is)<p[^>]*>(.*?)</p>`).ReplaceAllString(s, "$1\n\n")
	s = regexp.MustCompile(`(?is)<br\s*/?>`).ReplaceAllString(s, "\n")
	s = regexp.MustCompile(`(?is)<strong[^>]*>(.*?)</strong>|<b[^>]*>(.*?)</b>`).ReplaceAllString(s, "**$1$2**")
	s = regexp.MustCompile(`(?is)<em[^>]*>(.*?)</em>|<i[^>]*>(.*?)</i>`).ReplaceAllString(s, "*$1$2*")
	s = regexp.MustCompile(`(?is)<code[^>]*>(.*?)</code>`).ReplaceAllString(s, "`$1`")
	s = regexp.MustCompile(`(?is)<a[^>]*href=["']?([^"'> ]+)["']?[^>]*>(.*?)</a>`).ReplaceAllString(s, "[$2]($1)")
	return stripTags(s)
}

func stripTags(s string) string {
	s = regexp.MustCompile(`(?is)<[^>]+>`).ReplaceAllString(s, "")
	return html.UnescapeString(s)
}

func readPandocJSON(s string) Document {
	doc := Document{Meta: map[string]string{}}
	var obj map[string]any
	if json.Unmarshal([]byte(s), &obj) != nil {
		return doc
	}
	blocks, _ := obj["blocks"].([]any)
	for _, x := range blocks {
		m, _ := x.(map[string]any)
		t, _ := m["t"].(string)
		c := m["c"]
		switch t {
		case "Para", "Plain":
			doc.Blocks = append(doc.Blocks, Block{Kind: "para", Text: jsonInlineText(c)})
		case "Header":
			arr, _ := c.([]any)
			lvl := 1
			if len(arr) > 0 {
				lvl = int(toFloat(arr[0]))
			}
			txt := ""
			if len(arr) > 2 {
				txt = jsonInlineText(arr[2])
			}
			doc.Blocks = append(doc.Blocks, Block{Kind: "heading", Level: lvl, Text: txt})
		}
	}
	return doc
}

func jsonInlineText(v any) string {
	arr, ok := v.([]any)
	if !ok {
		return ""
	}
	var parts []string
	for _, it := range arr {
		m, _ := it.(map[string]any)
		t, _ := m["t"].(string)
		switch t {
		case "Str":
			parts = append(parts, fmt.Sprint(m["c"]))
		case "Space", "SoftBreak", "LineBreak":
			parts = append(parts, " ")
		}
	}
	return strings.Join(parts, "")
}

func inlinesJSON(s string) []any {
	words := strings.Fields(s)
	var out []any
	for i, w := range words {
		if i > 0 {
			out = append(out, map[string]any{"t": "Space"})
		}
		out = append(out, map[string]any{"t": "Str", "c": w})
	}
	return out
}

func headingAttrs(s string) string {
	id := headingID(s)
	classes := headingClasses(s)
	var attrs []string
	if len(classes) > 0 {
		attrs = append(attrs, `class="`+html.EscapeString(strings.Join(classes, " "))+`"`)
	}
	attrs = append(attrs, `id="`+html.EscapeString(id)+`"`)
	return " " + strings.Join(attrs, " ")
}

func headingID(s string) string {
	if id := explicitID(s); id != "" {
		return id
	}
	s = strings.ToLower(stripInlines(s))
	var out []rune
	lastDash := false
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '-' {
			out = append(out, r)
			lastDash = false
		} else if unicode.IsSpace(r) && !lastDash && len(out) > 0 {
			out = append(out, '-')
			lastDash = true
		}
	}
	return strings.Trim(string(out), "-")
}

func explicitID(s string) string {
	m := regexp.MustCompile(`\{[^}]*#([A-Za-z0-9_:-]+)[^}]*\}\s*$`).FindStringSubmatch(s)
	if len(m) > 1 {
		return m[1]
	}
	return ""
}

func headingClasses(s string) []string {
	m := regexp.MustCompile(`\{([^}]*)\}\s*$`).FindStringSubmatch(s)
	if len(m) < 2 {
		return nil
	}
	var cls []string
	for _, f := range strings.Fields(m[1]) {
		if strings.HasPrefix(f, ".") {
			cls = append(cls, strings.TrimPrefix(f, "."))
		}
	}
	return cls
}

func cleanHeadingText(s string) string {
	return strings.TrimSpace(regexp.MustCompile(`\s*\{[^}]*\}\s*$`).ReplaceAllString(s, ""))
}

func inferInput(files []string) string {
	if len(files) == 1 && files[0] != "-" {
		switch strings.ToLower(filepath.Ext(files[0])) {
		case ".html", ".htm":
			return "html"
		case ".json":
			return "json"
		case ".rst":
			return "rst"
		case ".tex", ".latex":
			return "latex"
		}
	}
	return "markdown"
}

func inferOutput(output string) string {
	switch strings.ToLower(filepath.Ext(output)) {
	case ".html", ".htm":
		return "html"
	case ".txt":
		return "plain"
	case ".json":
		return "json"
	case ".tex":
		return "latex"
	case ".rst":
		return "rst"
	default:
		return "html"
	}
}

func helpText() string {
	return `executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
  -o FILE               --output=FILE
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]
  -s[true|false]        --standalone[=true|false]
  -V KEY[:VALUE]        --variable=KEY[:VALUE]
                        --toc[=true|false], --table-of-contents[=true|false]
  -N[true|false]        --number-sections[=true|false]
                        --list-input-formats
                        --list-output-formats
                        --list-extensions[=FORMAT]
                        --list-highlight-languages
                        --list-highlight-styles
  -D FORMAT             --print-default-template=FORMAT
  -v                    --version
  -h                    --help
`
}

func markdownExtensions() []string {
	return []string{"-abbreviations", "-alerts", "+all_symbols_escapable", "-angle_brackets_escapable", "-ascii_identifiers", "+auto_identifiers", "-autolink_bare_uris", "+backtick_code_blocks", "+blank_before_blockquote", "+blank_before_header", "+bracketed_spans", "+citations", "+definition_lists", "-east_asian_line_breaks", "-emoji", "+escaped_line_breaks", "+example_lists", "+fancy_lists", "+fenced_code_attributes", "+fenced_code_blocks", "+fenced_divs", "+footnotes", "-four_space_rule", "-gfm_auto_identifiers", "+grid_tables", "-gutenberg", "-hard_line_breaks", "+header_attributes", "+implicit_figures", "+implicit_header_references", "+inline_code_attributes", "+inline_notes", "+intraword_underscores", "+latex_macros", "+line_blocks", "+link_attributes", "-lists_without_preceding_blankline", "-literate_haskell", "+native_divs", "+native_spans", "+pipe_tables", "+raw_attribute", "+raw_html", "+raw_tex", "+shortcut_reference_links", "+simple_tables", "+smart", "+yaml_metadata_block"}
}

func afterEq(s string) string { return strings.SplitN(s, "=", 2)[1] }
func printLines(xs []string) {
	for _, x := range xs {
		fmt.Println(x)
	}
}
func contains(xs []string, s string) bool {
	for _, x := range xs {
		if x == s {
			return true
		}
	}
	return false
}
func baseFormat(s string) string {
	s = strings.Split(s, "+")[0]
	s = strings.Split(s, "-")[0]
	return s
}
func addKV(m map[string]string, s string) {
	if p := strings.Index(s, ":"); p >= 0 {
		m[s[:p]] = strings.TrimPrefix(s[p+1:], " ")
	} else if p := strings.Index(s, "="); p >= 0 {
		m[s[:p]] = s[p+1:]
	} else {
		m[s] = "true"
	}
}
func allRunes(s string, r rune) bool {
	if len(s) < 2 {
		return false
	}
	for _, c := range s {
		if c != r {
			return false
		}
	}
	return true
}
func isUList(s string) bool {
	return len(s) > 2 && (strings.HasPrefix(s, "- ") || strings.HasPrefix(s, "* ") || strings.HasPrefix(s, "+ "))
}
func isOList(s string) (bool, string) {
	i := 0
	for i < len(s) && s[i] >= '0' && s[i] <= '9' {
		i++
	}
	if i > 0 && i+1 < len(s) && (s[i] == '.' || s[i] == ')') && s[i+1] == ' ' {
		return true, strings.TrimSpace(s[i+1:])
	}
	return false, ""
}
func startsBlock(s string) bool {
	if s == "" || strings.HasPrefix(s, "#") || strings.HasPrefix(s, "```") || strings.HasPrefix(s, "~~~") || strings.HasPrefix(s, ">") || isUList(s) {
		return true
	}
	ok, _ := isOList(s)
	return ok
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func escapeLatex(s string) string {
	r := strings.NewReplacer(`\`, `\textbackslash{}`, "&", `\&`, "%", `\%`, "$", `\$`, "#", `\#`, "_", `\_`, "{", `\{`, "}", `\}`, "~", `\textasciitilde{}`, "^", `\textasciicircum{}`)
	return r.Replace(s)
}
func toFloat(v any) float64 {
	switch x := v.(type) {
	case float64:
		return x
	case int:
		return float64(x)
	default:
		return 0
	}
}

func init() {
	sort.Strings(inputFormats)
	sort.Strings(outputFormats)
	_ = bufio.ErrFinalToken
}
