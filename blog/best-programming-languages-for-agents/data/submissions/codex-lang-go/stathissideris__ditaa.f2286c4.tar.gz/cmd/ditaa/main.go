package main

import (
	"bytes"
	"fmt"
	"html"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const helpText = `usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]
       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]
       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]
 -A,--no-antialias              Turns anti-aliasing off.
 -b,--background <BACKGROUND>   The background colour of the image. The
                                format should be a six-digit hexadecimal
                                number (as in HTML, FF0000 for red). Pass
                                an eight-digit hex to define transparency.
                                This is overridden by --transparent.
 -d,--debug                     Renders the debug grid over the resulting
                                image.
 -E,--no-separation             Prevents the separation of common edges of
                                shapes.
 -e,--encoding <ENCODING>       The encoding of the input file.
 -h,--html                      In this case the input is an HTML file.
                                The contents of the <pre
                                class="textdiagram"> tags are rendered as
                                diagrams and saved in the images directory
                                and a new HTML file is produced with the
                                appropriate <img> tags.
    --help                      Prints usage help.
 -o,--overwrite                 If the filename of the destination image
                                already exists, an alternative name is
                                chosen. If the overwrite option is
                                selected, the image file is instead
                                overwriten.
 -r,--round-corners             Causes all corners to be rendered as round
                                corners.
 -S,--no-shadows                Turns off the drop-shadow effect.
 -s,--scale <SCALE>             A natural number that determines the size
                                of the rendered image. The units are
                                fractions of the default size (2.5 renders
                                1.5 times bigger than the default).
    --svg                       Write an SVG image as destination file.
    --svg-font-url <FONT>       SVG font URL.
 -T,--transparent               Causes the diagram to be rendered on a
                                transparent background. Overrides
                                --background.
 -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces
                                but it is possible to change that using
                                this option. It is not advisable to use
                                tabs in your diagrams.
 -v,--verbose                   Makes ditaa more verbose.
 -W,--fixed-slope               Makes sides of parallelograms and
                                trapezoids fixed slope instead of fixed
                                width.`

type options struct {
	in, out      string
	svg, html    bool
	overwrite    bool
	noShadows    bool
	transparent  bool
	debug        bool
	round        bool
	scale        float64
	tabs         int
	background   string
	svgFontURL   string
	seenOptions  []string
}

type rect struct{ x1, y1, x2, y2 int; fill string }
type segment struct{ x1, y1, x2, y2 int; dashed bool }
type textRun struct{ x, y int; text string }

func main() {
	start := time.Now()
	opt, code := parseArgs(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}
	if opt.html {
		err := renderHTML(opt, start)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	err := runOne(opt, start)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func parseArgs(args []string) (options, int) {
	opt := options{scale: 1, tabs: 8, background: "ffffff"}
	if len(args) == 0 {
		fmt.Println(helpText)
		return opt, 0
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--help":
			fmt.Println(helpText)
			return opt, 0
		case "-A", "--no-antialias":
			opt.seenOptions = append(opt.seenOptions, "no-antialias")
		case "-d", "--debug":
			opt.debug = true; opt.seenOptions = append(opt.seenOptions, "debug")
		case "-E", "--no-separation":
			opt.seenOptions = append(opt.seenOptions, "no-separation")
		case "-h", "--html":
			opt.html = true; opt.seenOptions = append(opt.seenOptions, "html")
		case "-o", "--overwrite":
			opt.overwrite = true; opt.seenOptions = append(opt.seenOptions, "overwrite")
		case "-r", "--round-corners":
			opt.round = true; opt.seenOptions = append(opt.seenOptions, "round-corners")
		case "-S", "--no-shadows":
			opt.noShadows = true; opt.seenOptions = append(opt.seenOptions, "no-shadows")
		case "--svg":
			opt.svg = true; opt.seenOptions = append(opt.seenOptions, "svg")
		case "-T", "--transparent":
			opt.transparent = true; opt.seenOptions = append(opt.seenOptions, "transparent")
		case "-v", "--verbose":
			opt.seenOptions = append(opt.seenOptions, "verbose")
		case "-W", "--fixed-slope":
			opt.seenOptions = append(opt.seenOptions, "fixed-slope")
		case "-b", "--background", "-e", "--encoding", "-s", "--scale", "-t", "--tabs", "--svg-font-url":
			if i+1 >= len(args) {
				fmt.Printf("Missing argument for option: %s\n%s\n", a, helpText)
				return opt, 2
			}
			v := args[i+1]; i++
			switch a {
			case "-b", "--background":
				opt.background = v; opt.seenOptions = append(opt.seenOptions, "background = "+v)
			case "-s", "--scale":
				f, _ := strconv.ParseFloat(v, 64); if f > 0 { opt.scale = f }
				opt.seenOptions = append(opt.seenOptions, "scale = "+trimFloat(opt.scale))
			case "-t", "--tabs":
				n, _ := strconv.Atoi(v); if n > 0 { opt.tabs = n }
				opt.seenOptions = append(opt.seenOptions, "tabs = "+strconv.Itoa(opt.tabs))
			case "--svg-font-url":
				opt.svgFontURL = v; opt.seenOptions = append(opt.seenOptions, "svg-font-url = "+v)
			default:
				opt.seenOptions = append(opt.seenOptions, strings.TrimLeft(a, "-")+" = "+v)
			}
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Printf("Unrecognized option: %s\n%s\n", a, helpText)
				return opt, 2
			}
			if opt.in == "" { opt.in = a } else if opt.out == "" { opt.out = a } else {
				fmt.Printf("Unrecognized option: %s\n%s\n", a, helpText)
				return opt, 2
			}
		}
	}
	if opt.in == "" {
		fmt.Println(helpText)
		return opt, 0
	}
	if opt.out == "" {
		ext := ".png"; if opt.svg { ext = ".svg" }
		opt.out = strings.TrimSuffix(opt.in, filepath.Ext(opt.in)) + ext
	}
	return opt, -1
}

func runOne(opt options, start time.Time) error {
	data, err := os.ReadFile(opt.in)
	if err != nil { return err }
	if err := renderToFile(string(data), opt.out, opt); err != nil { return err }
	printStatus(opt, start)
	return nil
}

func printStatus(opt options, start time.Time) {
	fmt.Println()
	fmt.Println("ditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris")
	fmt.Println()
	fmt.Println("Running with options:")
	for _, s := range opt.seenOptions { fmt.Println(s) }
	fmt.Println("Reading file: " + opt.in)
	fmt.Println("Rendering to file: " + opt.out)
	fmt.Printf("Done in %dsec\n", int(time.Since(start).Seconds()+0.5))
}

func renderToFile(src, out string, opt options) error {
	src = expandTabs(strings.ReplaceAll(src, "\r\n", "\n"), opt.tabs)
	if opt.svg || strings.EqualFold(filepath.Ext(out), ".svg") {
		return os.WriteFile(out, []byte(renderSVG(src, opt)), 0644)
	}
	img := renderPNG(src, opt)
	f, err := os.Create(out)
	if err != nil { return err }
	defer f.Close()
	return png.Encode(f, img)
}

func expandTabs(s string, tab int) string {
	var b strings.Builder
	col := 0
	for _, r := range s {
		if r == '\n' { b.WriteRune(r); col = 0; continue }
		if r == '\t' {
			n := tab - col%tab
			b.WriteString(strings.Repeat(" ", n)); col += n
		} else { b.WriteRune(r); col++ }
	}
	return b.String()
}

func analyze(src string) ([]string, int, int, []rect, []segment, []textRun) {
	lines := strings.Split(strings.TrimRight(src, "\n"), "\n")
	w := 0
	for _, l := range lines { if len(l) > w { w = len(l) } }
	for i := range lines { if len(lines[i]) < w { lines[i] += strings.Repeat(" ", w-len(lines[i])) } }
	h := len(lines)
	rects := findRects(lines, w, h)
	covered := map[[2]int]bool{}
	for _, r := range rects {
		for x := r.x1; x <= r.x2; x++ { covered[[2]int{x,r.y1}] = true; covered[[2]int{x,r.y2}] = true }
		for y := r.y1; y <= r.y2; y++ { covered[[2]int{r.x1,y}] = true; covered[[2]int{r.x2,y}] = true }
	}
	var segs []segment
	used := map[[2]int]bool{}
	for y, l := range lines {
		x := 0
		for x < w {
			if strings.ContainsRune("-=:+<>*+", rune(l[x])) && isHChar(l[x]) && !covered[[2]int{x,y}] {
				x0 := x; dashed := false
				for x < w && isHChar(l[x]) && !covered[[2]int{x,y}] { if l[x]=='=' { dashed=true }; used[[2]int{x,y}]=true; x++ }
				if x-x0 > 1 { segs = append(segs, segment{x0,y,x-1,y,dashed}) }
			}
			x++
		}
	}
	for x := 0; x < w; x++ {
		y := 0
		for y < h {
			if isVChar(lines[y][x]) && !covered[[2]int{x,y}] {
				y0 := y; dashed := false
				for y < h && isVChar(lines[y][x]) && !covered[[2]int{x,y}] { if lines[y][x]==':' { dashed=true }; used[[2]int{x,y}]=true; y++ }
				if y-y0 > 1 { segs = append(segs, segment{x,y0,x,y-1,dashed}) }
			}
			y++
		}
	}
	for y,l := range lines {
		x := 0
		for x < w {
			if isTextChar(l[x]) && !covered[[2]int{x,y}] && !used[[2]int{x,y}] {
				x0 := x
				var b strings.Builder
				for x < w && isTextChar(l[x]) && !covered[[2]int{x,y}] && !used[[2]int{x,y}] {
					b.WriteByte(l[x]); x++
				}
				txt := cleanText(b.String())
				if strings.TrimSpace(txt) != "" {
					lead := len(b.String()) - len(strings.TrimLeft(b.String(), " "))
					segs := strings.FieldsFunc(txt, func(r rune) bool { return r == 0 })
					if len(segs) > 0 { _ = segs }
					runs := splitText(txt)
					off := 0
					for _, rt := range runs {
						if rt != "" { text := strings.TrimRight(rt, " "); if text != "" { segsText := text; _ = segsText; } }
						if strings.TrimSpace(rt) != "" { break }
						off += len(rt)
					}
					t := strings.TrimSpace(strings.Join(runs, " "))
					if t != "" { _ = lead; segs2 := textRun{x0+lead,y,t}; _=segs2; }
					for _, tr := range textRunsFrom(x0, y, b.String()) { if tr.text != "" { textRuns = append(textRuns, tr) } }
				}
			} else { x++ }
		}
	}
	return lines, w, h, rects, segs, textRuns
}

var textRuns []textRun

func findRects(lines []string, w, h int) []rect {
	var rs []rect
	for y1 := 0; y1 < h; y1++ {
		for x1 := 0; x1 < w; x1++ {
			if !isCorner(lines[y1][x1]) { continue }
			for x2 := x1+2; x2 < w; x2++ {
				if !isCorner(lines[y1][x2]) || !hClear(lines[y1], x1, x2) { continue }
				for y2 := y1+2; y2 < h; y2++ {
					if isCorner(lines[y2][x1]) && isCorner(lines[y2][x2]) && hClear(lines[y2], x1, x2) && vClear(lines, x1, y1, y2) && vClear(lines, x2, y1, y2) {
						rs = append(rs, rect{x1,y1,x2,y2,detectFill(lines,x1,y1,x2,y2)})
						goto nextx
					}
				}
			}
		nextx:
		}
	}
	return rs
}

func hClear(s string, x1,x2 int) bool { for x:=x1+1; x<x2; x++ { if s[x] != '-' && s[x] != '=' { return false } }; return true }
func vClear(lines []string, x,y1,y2 int) bool { for y:=y1+1; y<y2; y++ { if lines[y][x] != '|' && lines[y][x] != ':' { return false } }; return true }
func isCorner(c byte) bool { return c=='+' || c=='/' || c=='\\' }
func isHChar(c byte) bool { return c=='-' || c=='=' || c=='+' || c=='<' || c=='>' || c=='*' }
func isVChar(c byte) bool { return c=='|' || c==':' || c=='+' || c=='^' || c=='v' || c=='*' }
func isTextChar(c byte) bool { return c >= 32 && !strings.ContainsRune("+-=|:/\\<>^v*", rune(c)) }

func detectFill(lines []string, x1,y1,x2,y2 int) string {
	m := map[string]string{"RED":"#ffcccc","GRE":"#ccffcc","BLU":"#ccccff","PNK":"#ffccff","YEL":"#ffffcc","BLK":"#cccccc"}
	for y:=y1+1; y<y2; y++ {
		part := lines[y][x1+1:x2]
		if i := strings.Index(part, "c"); i >= 0 && i+4 <= len(part) {
			code := strings.ToUpper(part[i+1:i+4])
			if v, ok := m[code]; ok { return v }
		}
	}
	return "white"
}

func cleanText(s string) string {
	repls := []string{"{d}","{s}","{o}","{mo}","{c}","{tr}","{io}","cRED","cGRE","cBLU","cPNK","cYEL","cBLK"}
	for _, r := range repls { s = strings.ReplaceAll(s, r, " ") }
	return s
}

func splitText(s string) []string { return []string{s} }

func textRunsFrom(x0,y int,s string) []textRun {
	var out []textRun
	s = cleanText(s)
	i := 0
	for i < len(s) {
		for i < len(s) && s[i] == ' ' { i++ }
		st := i
		for i < len(s) && s[i] != ' ' { i++ }
		for i < len(s) && s[i] == ' ' { i++ }
		if st < i {
			t := strings.TrimSpace(s[st:i])
			if t != "" { out = append(out, textRun{x0+st,y,t}) }
		}
	}
	return out
}

func dims(w,h int, scale float64) (int,int) {
	return int(math.Round(float64(w*10+40)*scale)), int(math.Round(float64(h*14+56)*scale))
}

func sx(c int, scale float64) float64 { return (25 + float64(c)*10) * scale }
func sy(r int, scale float64) float64 { return (35 + float64(r)*14) * scale }

func renderSVG(src string, opt options) string {
	textRuns = nil
	_, w,h, rects, segs, trs := analyze(src)
	W,H := dims(w,h,opt.scale)
	var b strings.Builder
	b.WriteString("<?xml version='1.0' encoding='UTF-8' standalone='no'?>\n")
	fmt.Fprintf(&b, "<svg \n    xmlns='http://www.w3.org/2000/svg'\n    width='%d'\n    height='%d'\n    shape-rendering='geometricPrecision'\n    version='1.0'>\n", W,H)
	b.WriteString("  <defs>\n")
	if opt.svgFontURL != "" { fmt.Fprintf(&b, "    <style type='text/css'>\n      @font-face {\n        font-family: Custom;\n        src: url('%s');\n      }\n    </style>\n", html.EscapeString(opt.svgFontURL)) }
	b.WriteString("    <filter id='f2' x='0' y='0' width='200%' height='200%'>\n      <feOffset result='offOut' in='SourceGraphic' dx='5' dy='5' />\n      <feGaussianBlur result='blurOut' in='offOut' stdDeviation='3' />\n      <feBlend in='SourceGraphic' in2='blurOut' mode='normal' />\n    </filter>\n  </defs>\n")
	b.WriteString("  <g stroke-width='1' stroke-linecap='square' stroke-linejoin='round'>\n")
	if !opt.transparent { fmt.Fprintf(&b, "    <rect x='0' y='0' width='%d' height='%d' style='fill: #%s'/>\n", W,H,normHex(opt.background)[:6]) }
	for _, r := range rects {
		d := fmt.Sprintf("M%.1f %.1f L%.1f %.1f L%.1f %.1f L%.1f %.1f z", sx(r.x1,opt.scale),sy(r.y1,opt.scale),sx(r.x1,opt.scale),sy(r.y2,opt.scale),sx(r.x2,opt.scale),sy(r.y2,opt.scale),sx(r.x2,opt.scale),sy(r.y1,opt.scale))
		if !opt.noShadows { fmt.Fprintf(&b, "    <path stroke='gray' fill='gray' filter='url(#f2)' d='%s' />\n", d) }
		fmt.Fprintf(&b, "    <path stroke='#000000' stroke-width='%.1f' stroke-linecap='round' stroke-linejoin='round' fill='%s' d='%s' />\n", opt.scale, r.fill, d)
	}
	for _, s := range segs {
		dash := ""; if s.dashed { dash = " stroke-dasharray='7,7'" }
		fmt.Fprintf(&b, "    <line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='#000000' stroke-width='%.1f'%s />\n", sx(s.x1,opt.scale), sy(s.y1,opt.scale), sx(s.x2,opt.scale), sy(s.y2,opt.scale), opt.scale, dash)
	}
	font := "Courier"; if opt.svgFontURL != "" { font = "Custom" }
	for _, t := range trs {
		fmt.Fprintf(&b, "    <text x='%d' y='%d' font-family='%s' font-size='%d' stroke='none' fill='#000000' ><![CDATA[%s]]></text>\n", int((25+float64(t.x)*10-3)*opt.scale), int((35+float64(t.y)*14+5)*opt.scale), font, int(15*opt.scale), strings.ReplaceAll(t.text, "]]>", "]]]]><![CDATA[>"))
	}
	if opt.debug {
		for x:=0; x<w; x++ { fmt.Fprintf(&b, "    <line x1='%.1f' y1='0' x2='%.1f' y2='%d' stroke='#dddddd' stroke-width='0.5' />\n", sx(x,opt.scale), sx(x,opt.scale), H) }
	}
	b.WriteString("  </g>\n</svg>\n")
	return b.String()
}

func renderPNG(src string, opt options) image.Image {
	textRuns = nil
	_, w,h, rects, segs, trs := analyze(src)
	W,H := dims(w,h,opt.scale)
	img := image.NewRGBA(image.Rect(0,0,W,H))
	bg := parseColor(opt.background, color.RGBA{255,255,255,255}); if opt.transparent { bg = color.RGBA{0,0,0,0} }
	draw.Draw(img,img.Bounds(),&image.Uniform{bg},image.Point{},draw.Src)
	for _, r := range rects {
		x1,y1,x2,y2 := int(sx(r.x1,opt.scale)), int(sy(r.y1,opt.scale)), int(sx(r.x2,opt.scale)), int(sy(r.y2,opt.scale))
		fill := color.RGBA{255,255,255,255}; if r.fill != "white" { fill = parseColor(strings.TrimPrefix(r.fill,"#"), fill) }
		fillRect(img,x1,y1,x2,y2,fill)
		drawLine(img,x1,y1,x2,y1,color.Black); drawLine(img,x2,y1,x2,y2,color.Black); drawLine(img,x2,y2,x1,y2,color.Black); drawLine(img,x1,y2,x1,y1,color.Black)
	}
	for _, s := range segs { drawLine(img,int(sx(s.x1,opt.scale)),int(sy(s.y1,opt.scale)),int(sx(s.x2,opt.scale)),int(sy(s.y2,opt.scale)),color.Black) }
	for _, t := range trs { drawString(img,int((25+float64(t.x)*10-3)*opt.scale),int((35+float64(t.y)*14-2)*opt.scale),t.text,color.Black,int(math.Max(1,opt.scale))) }
	return img
}

func fillRect(img *image.RGBA,x1,y1,x2,y2 int,c color.Color) { if x1>x2 {x1,x2=x2,x1}; if y1>y2 {y1,y2=y2,y1}; draw.Draw(img,image.Rect(x1,y1,x2+1,y2+1),&image.Uniform{c},image.Point{},draw.Src) }
func drawLine(img *image.RGBA,x0,y0,x1,y1 int,c color.Color) {
	dx := abs(x1-x0); sxn := -1; if x0<x1 { sxn=1 }; dy := -abs(y1-y0); syn := -1; if y0<y1 { syn=1 }; err := dx+dy
	for { if image.Pt(x0,y0).In(img.Bounds()) { img.Set(x0,y0,c) }; if x0==x1 && y0==y1 { break }; e2:=2*err; if e2>=dy { err+=dy; x0+=sxn }; if e2<=dx { err+=dx; y0+=syn } }
}
func abs(n int) int { if n<0 { return -n }; return n }

var tinyFont = map[rune][]string{
	'A':{"01110","10001","10001","11111","10001","10001","10001"}, 'B':{"11110","10001","10001","11110","10001","10001","11110"}, 'C':{"01111","10000","10000","10000","10000","10000","01111"}, 'D':{"11110","10001","10001","10001","10001","10001","11110"}, 'E':{"11111","10000","10000","11110","10000","10000","11111"}, 'F':{"11111","10000","10000","11110","10000","10000","10000"}, 'G':{"01111","10000","10000","10011","10001","10001","01111"}, 'H':{"10001","10001","10001","11111","10001","10001","10001"}, 'I':{"11111","00100","00100","00100","00100","00100","11111"}, 'J':{"00111","00010","00010","00010","10010","10010","01100"}, 'K':{"10001","10010","10100","11000","10100","10010","10001"}, 'L':{"10000","10000","10000","10000","10000","10000","11111"}, 'M':{"10001","11011","10101","10101","10001","10001","10001"}, 'N':{"10001","11001","10101","10011","10001","10001","10001"}, 'O':{"01110","10001","10001","10001","10001","10001","01110"}, 'P':{"11110","10001","10001","11110","10000","10000","10000"}, 'Q':{"01110","10001","10001","10001","10101","10010","01101"}, 'R':{"11110","10001","10001","11110","10100","10010","10001"}, 'S':{"01111","10000","10000","01110","00001","00001","11110"}, 'T':{"11111","00100","00100","00100","00100","00100","00100"}, 'U':{"10001","10001","10001","10001","10001","10001","01110"}, 'V':{"10001","10001","10001","10001","10001","01010","00100"}, 'W':{"10001","10001","10001","10101","10101","10101","01010"}, 'X':{"10001","10001","01010","00100","01010","10001","10001"}, 'Y':{"10001","10001","01010","00100","00100","00100","00100"}, 'Z':{"11111","00001","00010","00100","01000","10000","11111"},
	'0':{"01110","10001","10011","10101","11001","10001","01110"}, '1':{"00100","01100","00100","00100","00100","00100","01110"}, '2':{"01110","10001","00001","00010","00100","01000","11111"}, '3':{"11110","00001","00001","01110","00001","00001","11110"}, '4':{"00010","00110","01010","10010","11111","00010","00010"}, '5':{"11111","10000","10000","11110","00001","00001","11110"}, '6':{"01110","10000","10000","11110","10001","10001","01110"}, '7':{"11111","00001","00010","00100","01000","01000","01000"}, '8':{"01110","10001","10001","01110","10001","10001","01110"}, '9':{"01110","10001","10001","01111","00001","00001","01110"},
}

func drawString(img *image.RGBA,x,y int,s string,c color.Color,scale int) {
	for _, r := range s {
		drawChar(img,x,y,r,c,scale)
		x += 6*scale
	}
}
func drawChar(img *image.RGBA,x,y int,r rune,c color.Color,scale int) {
	if r >= 'a' && r <= 'z' { r = r - 'a' + 'A' }
	pat, ok := tinyFont[r]; if !ok { if r!=' ' { pat = []string{"00000","00000","00000","00000","00000","00000","11111"} } else { return } }
	for yy,row := range pat { for xx,ch := range row { if ch=='1' { fillRect(img,x+xx*scale,y+yy*scale,x+(xx+1)*scale-1,y+(yy+1)*scale-1,c) } } }
}

func normHex(s string) string { s = strings.TrimPrefix(strings.TrimSpace(s),"#"); if len(s)<6 { return "ffffff" }; return s }
func parseColor(s string, def color.RGBA) color.RGBA {
	s = normHex(s)
	n, err := strconv.ParseUint(s[:6],16,32); if err != nil { return def }
	a := uint8(255); if len(s) >= 8 { v,_ := strconv.ParseUint(s[6:8],16,8); a = uint8(v) }
	return color.RGBA{uint8(n>>16),uint8(n>>8),uint8(n),a}
}
func trimFloat(f float64) string { if f == math.Trunc(f) { return strconv.Itoa(int(f)) }; return strconv.FormatFloat(f,'f',-1,64) }

func renderHTML(opt options, start time.Time) error {
	data, err := os.ReadFile(opt.in); if err != nil { return err }
	dir := filepath.Dir(opt.in)
	imgDir := filepath.Join(dir, "images")
	if err := os.MkdirAll(imgDir,0755); err != nil { return err }
	re := regexp.MustCompile(`(?is)<pre([^>]*)class=["'][^"']*textdiagram[^"']*["']([^>]*)>(.*?)</pre>`)
	count := 0
	outHTML := re.ReplaceAllStringFunc(string(data), func(m string) string {
		count++
		sub := re.FindStringSubmatch(m)
		attrs := sub[1]+sub[2]
		id := ""
		idre := regexp.MustCompile(`(?i)id=["']([^"']+)["']`)
		if mm := idre.FindStringSubmatch(attrs); len(mm)>1 { id = mm[1] }
		if id == "" { id = fmt.Sprintf("ditaa_diagram_%d", count) }
		ext := ".png"; if opt.svg { ext = ".svg" }
		name := id + ext
		imgPath := filepath.Join(imgDir,name)
		diag := html.UnescapeString(sub[3])
		localOpt := opt; localOpt.out = imgPath
		if opt.overwrite || !exists(imgPath) { _ = renderToFile(diag,imgPath,localOpt) }
		return fmt.Sprintf(`<img src="images/%s" />`, html.EscapeString(name))
	})
	if opt.out == "" { opt.out = strings.TrimSuffix(opt.in, filepath.Ext(opt.in)) + "_processed.html" }
	if err := os.WriteFile(opt.out, []byte(outHTML),0644); err != nil { return err }
	printStatus(opt,start)
	return nil
}
func exists(p string) bool { _,err := os.Stat(p); return err == nil }

func init() { _ = bytes.MinRead }
