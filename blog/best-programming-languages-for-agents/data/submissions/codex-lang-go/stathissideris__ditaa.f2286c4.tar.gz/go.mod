module ditaa-reimpl

go 1.21
