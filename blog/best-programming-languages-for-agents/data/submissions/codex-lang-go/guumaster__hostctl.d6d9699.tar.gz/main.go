package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const banner = `##################################################################
# Content under this line is handled by hostctl. DO NOT EDIT.
##################################################################`

type Entry struct {
	Profile string
	Status  string
	IP      string
	Host    string
}

type Profile struct {
	Name    string
	Status  string
	Entries []Entry
}

type State struct {
	DefaultRaw []string
	Default    []Entry
	Profiles   []Profile
}

type Config struct {
	hostFile string
	out      string
	quiet    bool
	cols     []string
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	cfg := Config{hostFile: "/etc/hosts", out: "table", cols: nil}
	var rest []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--host-file" && i+1 < len(args):
			i++
			cfg.hostFile = args[i]
		case strings.HasPrefix(a, "--host-file="):
			cfg.hostFile = strings.TrimPrefix(a, "--host-file=")
		case (a == "-o" || a == "--out") && i+1 < len(args):
			i++
			cfg.out = args[i]
		case strings.HasPrefix(a, "--out="):
			cfg.out = strings.TrimPrefix(a, "--out=")
		case a == "--raw":
			cfg.out = "raw"
		case a == "-q" || a == "--quiet":
			cfg.quiet = true
		case a == "--no-color":
		case (a == "-c" || a == "--column") && i+1 < len(args):
			i++
			cfg.cols = splitCSV(args[i])
		case strings.HasPrefix(a, "--column="):
			cfg.cols = splitCSV(strings.TrimPrefix(a, "--column="))
		case a == "-v" || a == "--version":
			fmt.Println("hostctl version dev")
			return 0
		case a == "-h" || a == "--help":
			printRootHelp()
			return 0
		case strings.HasPrefix(a, "-"):
			return errf("unknown flag: %s", a)
		default:
			rest = append(rest, args[i:]...)
			i = len(args)
		}
	}
	if len(rest) == 0 {
		printRootHelp()
		return 0
	}
	cmd := rest[0]
	if helpAt(rest) >= 0 {
		if len(rest) > 1 && (rest[1] == "domains" || rest[1] == "domain") {
			printHelp("domains", nil)
		} else {
			printHelp(cmd, rest[1:])
		}
		return 0
	}
	switch cmd {
	case "help":
		if len(rest) > 1 {
			printHelp(rest[1], rest[2:])
		} else {
			printRootHelp()
		}
		return 0
	case "status":
		return withState(cfg, func(s State) int { printRows(cfg, filterStatus(s, rest[1:])); return 0 })
	case "list":
		return cmdList(cfg, rest[1:])
	case "add":
		return cmdAdd(cfg, rest[1:], false)
	case "replace":
		return cmdAdd(cfg, rest[1:], true)
	case "enable":
		return setStatus(cfg, rest[1:], "on")
	case "disable":
		return setStatus(cfg, rest[1:], "off")
	case "toggle":
		return toggle(cfg, rest[1:])
	case "remove", "rm":
		return cmdRemove(cfg, rest[1:])
	case "backup":
		return backup(cfg, rest[1:])
	case "restore":
		return restore(cfg, rest[1:])
	case "sync":
		return errf("Docker sync is not available")
	default:
		return errf("unknown command %q for \"hostctl\"", cmd)
	}
}

func info(cfg Config) {
	if !cfg.quiet && cfg.out != "json" {
		fmt.Printf("[ℹ] Using hosts file: %s\n\n", cfg.hostFile)
	}
}

func errf(f string, a ...any) int {
	fmt.Printf("[✖] error: "+f+"\n", a...)
	return 1
}

func withState(cfg Config, fn func(State) int) int {
	info(cfg)
	s, err := readState(cfg.hostFile)
	if err != nil {
		return errf("%v", err)
	}
	return fn(s)
}

func readState(path string) (State, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return State{}, err
	}
	lines := strings.Split(strings.ReplaceAll(string(b), "\r\n", "\n"), "\n")
	st := State{}
	inManaged := false
	var cur *Profile
	for _, line := range lines {
		t := strings.TrimSpace(line)
		if strings.HasPrefix(t, "# Content under this line is handled by hostctl") {
			inManaged = true
			continue
		}
		if !inManaged {
			if t != "" || len(st.DefaultRaw) > 0 {
				st.DefaultRaw = append(st.DefaultRaw, line)
			}
			if e, ok := parseHostLine(line, "default"); ok {
				st.Default = append(st.Default, e)
			}
			continue
		}
		if strings.HasPrefix(t, "# profile.") {
			parts := strings.Fields(t)
			if len(parts) >= 3 {
				status := strings.TrimPrefix(parts[1], "profile.")
				st.Profiles = append(st.Profiles, Profile{Name: parts[2], Status: status})
				cur = &st.Profiles[len(st.Profiles)-1]
			}
			continue
		}
		if t == "# end" {
			cur = nil
			continue
		}
		if cur != nil {
			line2 := line
			if cur.Status == "off" {
				line2 = strings.TrimSpace(line2)
				line2 = strings.TrimPrefix(line2, "#")
				line2 = strings.TrimSpace(line2)
			}
			if e, ok := parseHostLine(line2, cur.Name); ok {
				e.Status = cur.Status
				cur.Entries = append(cur.Entries, e)
			}
		}
	}
	return st, nil
}

func parseHostLine(line, profile string) (Entry, bool) {
	status := "on"
	t := strings.TrimSpace(line)
	if t == "" {
		return Entry{}, false
	}
	if strings.HasPrefix(t, "#") {
		status = "off"
		t = strings.TrimSpace(strings.TrimPrefix(t, "#"))
	}
	if i := strings.Index(t, "#"); i >= 0 {
		t = strings.TrimSpace(t[:i])
	}
	f := strings.Fields(t)
	if len(f) < 2 {
		return Entry{}, false
	}
	if !strings.ContainsAny(f[0], ".:") {
		return Entry{}, false
	}
	return Entry{Profile: profile, Status: status, IP: f[0], Host: f[1]}, true
}

func writeState(path string, st State) error {
	var b strings.Builder
	if len(st.DefaultRaw) > 0 {
		for _, line := range st.DefaultRaw {
			b.WriteString(line)
			b.WriteByte('\n')
		}
	} else {
		for _, e := range st.Default {
			if e.Status == "off" {
				b.WriteString("# ")
			}
			b.WriteString(e.IP + " " + e.Host + "\n")
		}
	}
	if !strings.HasSuffix(b.String(), "\n\n") {
		b.WriteString("\n")
	}
	b.WriteString(banner + "\n")
	for i, p := range st.Profiles {
		b.WriteString("\n# profile." + p.Status + " " + p.Name + "\n")
		for _, e := range p.Entries {
			prefix := ""
			if p.Status == "off" {
				prefix = "# "
			}
			b.WriteString(prefix + e.IP + " " + e.Host + "\n")
		}
		b.WriteString("# end\n")
		if i != len(st.Profiles)-1 {
			b.WriteString("\n")
		}
	}
	return os.WriteFile(path, []byte(b.String()), 0644)
}

func allEntries(st State) []Entry {
	out := append([]Entry{}, st.Default...)
	for _, p := range st.Profiles {
		for _, e := range p.Entries {
			e.Status = p.Status
			out = append(out, e)
		}
	}
	return out
}

func filterStatus(st State, names []string) []Entry {
	set := make(map[string]bool)
	for _, n := range names {
		if !strings.HasPrefix(n, "-") {
			set[n] = true
		}
	}
	var out []Entry
	for _, p := range st.Profiles {
		if len(set) == 0 || set[p.Name] {
			out = append(out, Entry{Profile: p.Name, Status: p.Status})
		}
	}
	return out
}

func cmdList(cfg Config, args []string) int {
	mode := ""
	var names []string
	if len(args) > 0 && (args[0] == "enabled" || args[0] == "on" || args[0] == "disabled" || args[0] == "off") {
		mode = args[0]
		args = args[1:]
	}
	for _, a := range args {
		if !strings.HasPrefix(a, "-") {
			names = append(names, a)
		}
	}
	return withState(cfg, func(st State) int {
		rows := allEntries(st)
		var out []Entry
		for _, e := range rows {
			if mode == "enabled" || mode == "on" {
				if e.Status != "on" || e.Profile == "default" {
					continue
				}
			}
			if mode == "disabled" || mode == "off" {
				if e.Status != "off" || e.Profile == "default" {
					continue
				}
			}
			if len(names) > 0 && !contains(names, e.Profile) {
				continue
			}
			out = append(out, e)
		}
		printRows(cfg, out)
		return 0
	})
}

func cmdAdd(cfg Config, args []string, replace bool) int {
	if len(args) > 0 && (args[0] == "domains" || args[0] == "domain") {
		return addDomains(cfg, args[1:])
	}
	if len(args) == 0 {
		return errf("missing profile name")
	}
	name := args[0]
	from := ""
	for i := 1; i < len(args); i++ {
		if (args[i] == "-f" || args[i] == "--from") && i+1 < len(args) {
			i++
			from = args[i]
		} else if strings.HasPrefix(args[i], "--from=") {
			from = strings.TrimPrefix(args[i], "--from=")
		}
	}
	info(cfg)
	entries, err := readEntriesFile(from, name)
	if err != nil {
		return errf("%v", err)
	}
	st, err := readState(cfg.hostFile)
	if err != nil {
		return errf("%v", err)
	}
	idx := profileIndex(st, name)
	if idx < 0 {
		st.Profiles = append(st.Profiles, Profile{Name: name, Status: "on", Entries: entries})
	} else if replace {
		st.Profiles[idx].Entries = entries
	} else {
		st.Profiles[idx].Entries = append(st.Profiles[idx].Entries, entries...)
	}
	if err := writeState(cfg.hostFile, st); err != nil {
		return errf("%v", err)
	}
	printRows(cfg, entriesWithStatus(name, "on", entries))
	if !replace {
		fmt.Println()
	}
	return 0
}

func readEntriesFile(path, profile string) ([]Entry, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var out []Entry
	for _, line := range strings.Split(string(b), "\n") {
		if i := strings.Index(line, "#"); i >= 0 {
			line = line[:i]
		}
		f := strings.Fields(line)
		if len(f) < 2 {
			continue
		}
		for _, h := range f[1:] {
			out = append(out, Entry{Profile: profile, Status: "on", IP: f[0], Host: h})
		}
	}
	return out, nil
}

func addDomains(cfg Config, args []string) int {
	if len(args) == 0 {
		return errf("missing profile name")
	}
	name := args[0]
	ip := "127.0.0.1"
	var doms []string
	for i := 1; i < len(args); i++ {
		if args[i] == "--ip" && i+1 < len(args) {
			i++
			ip = args[i]
			continue
		}
		if strings.HasPrefix(args[i], "--ip=") {
			ip = strings.TrimPrefix(args[i], "--ip=")
			continue
		}
		if !strings.HasPrefix(args[i], "-") {
			doms = append(doms, args[i])
		}
	}
	info(cfg)
	st, err := readState(cfg.hostFile)
	if err != nil {
		return errf("%v", err)
	}
	var ents []Entry
	for _, d := range doms {
		ents = append(ents, Entry{Profile: name, Status: "on", IP: ip, Host: d})
	}
	idx := profileIndex(st, name)
	if idx < 0 {
		st.Profiles = append(st.Profiles, Profile{Name: name, Status: "on", Entries: ents})
	} else {
		st.Profiles[idx].Entries = append(st.Profiles[idx].Entries, ents...)
	}
	if err := writeState(cfg.hostFile, st); err != nil {
		return errf("%v", err)
	}
	if !cfg.quiet && cfg.out != "json" {
		fmt.Printf("[✔] Domains '%s' added.\n\n", strings.Join(doms, ", "))
	}
	printRows(cfg, ents)
	fmt.Println()
	return 0
}

func setStatus(cfg Config, args []string, status string) int {
	all, only := false, false
	var names []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--all":
			all = true
		case "--only":
			only = true
		case "-w", "--wait":
			i++
		default:
			if !strings.HasPrefix(args[i], "-") {
				names = append(names, args[i])
			}
		}
	}
	if !all && len(names) == 0 {
		return errf("missing profile name")
	}
	return withState(cfg, func(st State) int {
		var rows []Entry
		if all {
			for i := range st.Profiles {
				st.Profiles[i].Status = status
				rows = append(rows, entriesWithStatus(st.Profiles[i].Name, status, st.Profiles[i].Entries)...)
			}
		} else {
			for _, n := range names {
				idx := profileIndex(st, n)
				if idx < 0 {
					return errf("unknown profile name")
				}
				st.Profiles[idx].Status = status
				rows = append(rows, entriesWithStatus(n, status, st.Profiles[idx].Entries)...)
			}
			if only {
				other := "off"
				if status == "off" {
					other = "on"
				}
				for i := range st.Profiles {
					if !contains(names, st.Profiles[i].Name) {
						st.Profiles[i].Status = other
					}
				}
			}
		}
		if err := writeState(cfg.hostFile, st); err != nil {
			return errf("%v", err)
		}
		printRows(cfg, rows)
		fmt.Println()
		return 0
	})
}

func toggle(cfg Config, args []string) int {
	var names []string
	for _, a := range args {
		if !strings.HasPrefix(a, "-") {
			names = append(names, a)
		}
	}
	if len(names) == 0 {
		return errf("missing profile name")
	}
	return withState(cfg, func(st State) int {
		var rows []Entry
		for _, n := range names {
			idx := profileIndex(st, n)
			if idx < 0 {
				return errf("unknown profile name")
			}
			if st.Profiles[idx].Status == "on" {
				st.Profiles[idx].Status = "off"
			} else {
				st.Profiles[idx].Status = "on"
			}
			rows = append(rows, entriesWithStatus(n, st.Profiles[idx].Status, st.Profiles[idx].Entries)...)
		}
		if err := writeState(cfg.hostFile, st); err != nil {
			return errf("%v", err)
		}
		printRows(cfg, rows)
		fmt.Println()
		return 0
	})
}

func cmdRemove(cfg Config, args []string) int {
	if len(args) > 0 && (args[0] == "domains" || args[0] == "domain") {
		return removeDomains(cfg, args[1:])
	}
	all := false
	var names []string
	for _, a := range args {
		if a == "--all" {
			all = true
		} else if !strings.HasPrefix(a, "-") {
			names = append(names, a)
		}
	}
	if !all && len(names) == 0 {
		return errf("missing profile name")
	}
	return withState(cfg, func(st State) int {
		if all {
			names = nil
			for _, p := range st.Profiles {
				names = append(names, p.Name)
			}
			st.Profiles = nil
		} else {
			var kept []Profile
			for _, p := range st.Profiles {
				if !contains(names, p.Name) {
					kept = append(kept, p)
				}
			}
			st.Profiles = kept
		}
		if err := writeState(cfg.hostFile, st); err != nil {
			return errf("%v", err)
		}
		if !cfg.quiet && cfg.out != "json" {
			fmt.Printf("[✔] Profile(s) '%s' removed.\n\n\n", strings.Join(names, ", "))
		}
		return 0
	})
}

func removeDomains(cfg Config, args []string) int {
	if len(args) == 0 {
		return errf("missing profile name")
	}
	name := args[0]
	doms := args[1:]
	return withState(cfg, func(st State) int {
		idx := profileIndex(st, name)
		if idx < 0 {
			return errf("unknown profile name")
		}
		var kept []Entry
		for _, e := range st.Profiles[idx].Entries {
			if !contains(doms, e.Host) {
				kept = append(kept, e)
			}
		}
		st.Profiles[idx].Entries = kept
		if err := writeState(cfg.hostFile, st); err != nil {
			return errf("%v", err)
		}
		if !cfg.quiet && cfg.out != "json" {
			fmt.Printf("[✔] Domains '%s' removed.\n\n", strings.Join(doms, ", "))
		}
		printRows(cfg, entriesWithStatus(name, st.Profiles[idx].Status, kept))
		return 0
	})
}

func backup(cfg Config, args []string) int {
	path := "/workspace"
	for i := 0; i < len(args); i++ {
		if args[i] == "--path" && i+1 < len(args) {
			i++
			path = args[i]
		} else if strings.HasPrefix(args[i], "--path=") {
			path = strings.TrimPrefix(args[i], "--path=")
		}
	}
	info(cfg)
	b, err := os.ReadFile(cfg.hostFile)
	if err != nil {
		return errf("%v", err)
	}
	dst := filepath.Join(path, filepath.Base(cfg.hostFile)+"."+time.Now().Format("20060102"))
	if err := os.WriteFile(dst, b, 0644); err != nil {
		return errf("%v", err)
	}
	if !cfg.quiet {
		fmt.Printf("[✔] Backup '%s' created.\n", dst)
	}
	return 0
}

func restore(cfg Config, args []string) int {
	from := ""
	for i := 0; i < len(args); i++ {
		if args[i] == "--from" && i+1 < len(args) {
			i++
			from = args[i]
		} else if strings.HasPrefix(args[i], "--from=") {
			from = strings.TrimPrefix(args[i], "--from=")
		}
	}
	info(cfg)
	b, err := os.ReadFile(from)
	if err != nil {
		return errf("%v", err)
	}
	if err := os.WriteFile(cfg.hostFile, b, 0644); err != nil {
		return errf("%v", err)
	}
	if !cfg.quiet {
		fmt.Printf("[✔] File '%s' restored.\n", from)
	}
	return 0
}

func printRows(cfg Config, rows []Entry) {
	cols := cfg.cols
	if cols == nil {
		cols = []string{"profile", "status", "ip", "domain"}
		if len(rows) > 0 && rows[0].IP == "" && rows[0].Host == "" {
			cols = []string{"profile", "status"}
		}
	}
	if cfg.quiet {
		return
	}
	switch cfg.out {
	case "json":
		if len(rows) == 0 {
			fmt.Print("null")
			return
		}
		type jr struct{ Profile, Status, IP, Host string }
		var j []jr
		for _, r := range rows {
			j = append(j, jr{r.Profile, r.Status, r.IP, r.Host})
		}
		b, _ := json.Marshal(j)
		fmt.Print(string(b))
	case "raw":
		printRaw(cols, rows)
	case "markdown":
		printMarkdown(cols, rows)
	default:
		printTable(cols, rows)
	}
}

func rowVals(cols []string, e Entry) []string {
	vals := make([]string, len(cols))
	for i, c := range cols {
		switch strings.ToLower(c) {
		case "profile":
			vals[i] = e.Profile
		case "status":
			vals[i] = e.Status
		case "ip":
			vals[i] = e.IP
		case "domain", "host":
			vals[i] = e.Host
		default:
			vals[i] = ""
		}
	}
	return vals
}

func headers(cols []string) []string {
	h := make([]string, len(cols))
	for i, c := range cols {
		if strings.ToLower(c) == "host" {
			c = "domain"
		}
		h[i] = strings.ToUpper(c)
	}
	return h
}

func widths(cols []string, rows []Entry) []int {
	h := headers(cols)
	w := make([]int, len(cols))
	for i := range cols {
		w[i] = len(h[i])
	}
	for _, r := range rows {
		for i, v := range rowVals(cols, r) {
			if len(v) > w[i] {
				w[i] = len(v)
			}
		}
	}
	return w
}

func printTable(cols []string, rows []Entry) {
	if len(rows) == 0 {
		return
	}
	w := widths(cols, rows)
	sep := tableSep(w)
	fmt.Println(sep)
	printTableRow(headers(cols), w)
	fmt.Println(sep)
	last := rows[0].Profile
	for i, r := range rows {
		if i > 0 && r.Profile != last {
			fmt.Println(sep)
			last = r.Profile
		}
		printTableRow(rowVals(cols, r), w)
	}
	fmt.Println(sep)
}

func tableSep(w []int) string {
	var b strings.Builder
	b.WriteByte('+')
	for _, x := range w {
		b.WriteString(strings.Repeat("-", x+2))
		b.WriteByte('+')
	}
	return b.String()
}
func printTableRow(vals []string, w []int) {
	fmt.Print("|")
	for i, v := range vals {
		fmt.Printf(" %-*s |", w[i], v)
	}
	fmt.Println()
}

func printRaw(cols []string, rows []Entry) {
	h := headers(cols)
	w := widths(cols, rows)
	for i, x := range h {
		fmt.Printf("%-*s\t", w[i], x)
	}
	fmt.Println()
	for _, r := range rows {
		for i, v := range rowVals(cols, r) {
			fmt.Printf("%-*s\t", w[i], v)
		}
		fmt.Println()
	}
}

func printMarkdown(cols []string, rows []Entry) {
	if len(rows) == 0 {
		return
	}
	w := widths(cols, rows)
	printMDRow(headers(cols), w)
	printMDSep(w)
	last := rows[0].Profile
	for i, r := range rows {
		if i > 0 && r.Profile != last {
			printMDSep(w)
			last = r.Profile
		}
		printMDRow(rowVals(cols, r), w)
	}
}
func printMDRow(vals []string, w []int) {
	fmt.Print("|")
	for i, v := range vals {
		fmt.Printf(" %-*s |", w[i], v)
	}
	fmt.Println()
}
func printMDSep(w []int) {
	fmt.Print("|")
	for _, x := range w {
		fmt.Print(strings.Repeat("-", x+2) + "|")
	}
	fmt.Println()
}

func entriesWithStatus(name, status string, es []Entry) []Entry {
	out := make([]Entry, len(es))
	for i, e := range es {
		e.Profile = name
		e.Status = status
		out[i] = e
	}
	return out
}
func profileIndex(st State, name string) int {
	for i, p := range st.Profiles {
		if p.Name == name {
			return i
		}
	}
	return -1
}
func contains(xs []string, x string) bool {
	for _, y := range xs {
		if y == x {
			return true
		}
	}
	return false
}
func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, strings.ToLower(p))
		}
	}
	return out
}

func helpAt(args []string) int {
	for i, a := range args {
		if a == "--help" || a == "-h" {
			return i
		}
	}
	return -1
}

func printRootHelp() {
	fmt.Println(`hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  help        Help about any command
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.

Flags:
  -c, --column strings     Column names to show on lists. comma separated
  -h, --help               help for hostctl
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -v, --version            version for hostctl

Use "hostctl [command] --help" for more information about a command.`)
}

func printHelp(cmd string, sub []string) {
	_ = sub
	text := map[string]string{
		"add":     "Reads from a file and set content to a profile in your hosts file.\n\nUsage:\n  hostctl add [profiles] [flags]",
		"replace": "Reads from a file and set content to a profile in your hosts file.\n\nUsage:\n  hostctl replace [profile] [flags]",
		"list":    "Shows a detailed list of profiles on your hosts file with name, ip and host name.\n\nUsage:\n  hostctl list [profiles] [flags]",
		"status":  "Shows a list of unique profile names on your hosts file with its status.\n\nUsage:\n  hostctl status [profiles] [flags]",
		"enable":  "Enables an existing profile.\n\nUsage:\n  hostctl enable [profiles] [flags]",
		"disable": "Disable a profile from your hosts file without removing it.\n\nUsage:\n  hostctl disable [profiles] [flags]",
		"remove":  "Completely remove a profile content from your hosts file.\n\nUsage:\n  hostctl remove [profiles] [flags]",
		"backup":  "Creates a backup copy of your hosts file with the date in .YYYYMMDD\nas extension.\n\nUsage:\n  hostctl backup [flags]",
		"restore": "Reads from a file and replace the content of your hosts file.\n\nUsage:\n  hostctl restore [flags]",
		"toggle":  "Alternates between on/off status of an existing profile.\n\nUsage:\n  hostctl toggle [flags]",
		"sync":    "Reads IPs and names from some local system and sync it with a profile in your hosts file.\n\nUsage:\n  hostctl sync [command]",
	}
	if v, ok := text[cmd]; ok {
		fmt.Println(v)
		return
	}
	if cmd == "domains" {
		fmt.Println("Set content in your hosts file.\n\nUsage:\n  hostctl add domains [profile] [domains] [flags]")
		return
	}
	printRootHelp()
}

func init() { sort.Strings(nil) }
