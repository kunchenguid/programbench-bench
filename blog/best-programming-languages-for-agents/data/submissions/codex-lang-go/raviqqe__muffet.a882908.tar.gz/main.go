package main

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

const version = "2.11.1"

type config struct {
	accepted      ranges
	bufferSize    int
	maxBody       int64
	timeout       int
	format        string
	verbose       bool
	ignoreFrag    bool
	onePage       bool
	skipTLS       bool
	followSitemap bool
	maxRedirects  int
	headers       []string
	includes      []*regexp.Regexp
	excludes      []*regexp.Regexp
	url           string
}

type ranges [][2]int

type pageResult struct {
	URL   string       `json:"url" xml:"-"`
	Links []linkResult `json:"links" xml:"-"`
}

type linkResult struct {
	URL    string `json:"url" xml:"-"`
	Status int    `json:"status,omitempty" xml:"-"`
	Error  string `json:"error,omitempty" xml:"-"`
}

type crawler struct {
	cfg     config
	client  *http.Client
	root    *url.URL
	seen    map[string]bool
	results []pageResult
	failed  bool
}

func main() {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if cfg.url == "" {
		return
	}
	root, err := url.Parse(cfg.url)
	if err != nil || root.Scheme == "" || root.Host == "" {
		fmt.Fprintln(os.Stderr, "failed to fetch root page: unsupported protocol \"\". http and https are supported")
		os.Exit(1)
	}
	if root.Scheme != "http" && root.Scheme != "https" {
		fmt.Fprintf(os.Stderr, "failed to fetch root page: unsupported protocol %q. http and https are supported\n", root.Scheme)
		os.Exit(1)
	}
	c := newCrawler(cfg, root)
	if ok := c.crawl(root.String(), true); !ok {
		os.Exit(1)
	}
	c.emit()
	if c.failed {
		os.Exit(1)
	}
}

func parseArgs(args []string) (config, error) {
	cfg := config{accepted: ranges{{200, 300}}, bufferSize: 4096, maxBody: 10000000, timeout: 10, format: "text", maxRedirects: 64}
	for i := 0; i < len(args); i++ {
		a := args[i]
		val := ""
		hasVal := false
		if strings.HasPrefix(a, "--") {
			name := strings.TrimPrefix(a, "--")
			if p := strings.IndexByte(name, '='); p >= 0 {
				val, hasVal, name = name[p+1:], true, name[:p]
			}
			switch name {
			case "help":
				printHelp()
				return cfg, nil
			case "version":
				fmt.Println(version)
				return cfg, nil
			case "json":
				cfg.format = "json"
			case "junit":
				cfg.format = "junit"
			case "experimental-verbose-json":
				cfg.format = "json"
				cfg.verbose = true
			case "verbose":
				cfg.verbose = true
			case "ignore-fragments":
				cfg.ignoreFrag = true
			case "one-page-only":
				cfg.onePage = true
			case "skip-tls-verification":
				cfg.skipTLS = true
			case "follow-sitemap-xml":
				cfg.followSitemap = true
			case "follow-robots-txt", "dns-resolver", "proxy", "rate-limit", "max-retries", "max-connections", "max-connections-per-host":
				if needsValue(name) && !hasVal {
					i++
				}
			case "format":
				if !hasVal {
					i++
					if i >= len(args) {
						return cfg, fmt.Errorf("expected argument for flag `%s'", a)
					}
					val = args[i]
				}
				if val != "text" && val != "json" && val != "junit" {
					return cfg, fmt.Errorf("Invalid value `%s' for option `--format'. Allowed values are: text, json or junit", val)
				}
				cfg.format = val
			case "accepted-status-codes":
				if !hasVal {
					i++
					if i >= len(args) {
						return cfg, fmt.Errorf("expected argument for flag `%s'", a)
					}
					val = args[i]
				}
				r, err := parseRanges(val)
				if err != nil {
					return cfg, err
				}
				cfg.accepted = r
			case "buffer-size":
				n, err := parseIntValue(name, a, val, hasVal, &i, args)
				if err != nil {
					return cfg, err
				}
				cfg.bufferSize = n
			case "max-response-body-size":
				n, err := parseIntValue(name, a, val, hasVal, &i, args)
				if err != nil {
					return cfg, err
				}
				cfg.maxBody = int64(n)
			case "max-redirections":
				n, err := parseIntValue(name, a, val, hasVal, &i, args)
				if err != nil {
					return cfg, err
				}
				cfg.maxRedirects = n
			case "timeout":
				n, err := parseIntValue(name, a, val, hasVal, &i, args)
				if err != nil {
					return cfg, err
				}
				cfg.timeout = n
			case "header":
				if !hasVal {
					i++
					if i >= len(args) {
						return cfg, fmt.Errorf("expected argument for flag `%s'", a)
					}
					val = args[i]
				}
				cfg.headers = append(cfg.headers, val)
			case "include", "exclude":
				if !hasVal {
					i++
					if i >= len(args) {
						return cfg, fmt.Errorf("expected argument for flag `%s'", a)
					}
					val = args[i]
				}
				re, err := regexp.Compile(val)
				if err != nil {
					return cfg, err
				}
				if name == "include" {
					cfg.includes = append(cfg.includes, re)
				} else {
					cfg.excludes = append(cfg.excludes, re)
				}
			case "color":
				if !hasVal {
					i++
				}
			default:
				return cfg, fmt.Errorf("unknown flag `%s'", name)
			}
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) > 1 {
			switch a {
			case "-h":
				printHelp()
				return cfg, nil
			case "-v":
				cfg.verbose = true
			case "-f":
				cfg.ignoreFrag = true
			case "-b", "-c", "-r", "-t":
				i++
				if i >= len(args) {
					return cfg, fmt.Errorf("expected argument for flag `%s'", a)
				}
				n, err := strconv.Atoi(args[i])
				if err != nil {
					return cfg, fmt.Errorf("invalid argument for flag `%s, --%s' (expected int): %v", a, shortLong(a), err)
				}
				switch a {
				case "-b":
					cfg.bufferSize = n
				case "-r":
					cfg.maxRedirects = n
				case "-t":
					cfg.timeout = n
				}
			case "-e", "-i":
				i++
				if i >= len(args) {
					return cfg, fmt.Errorf("expected argument for flag `%s'", a)
				}
				re, err := regexp.Compile(args[i])
				if err != nil {
					return cfg, err
				}
				if a == "-i" {
					cfg.includes = append(cfg.includes, re)
				} else {
					cfg.excludes = append(cfg.excludes, re)
				}
			default:
				return cfg, fmt.Errorf("unknown flag `%s'", strings.TrimPrefix(a, "-"))
			}
			continue
		}
		if cfg.url != "" {
			return cfg, fmt.Errorf("invalid number of arguments")
		}
		cfg.url = a
	}
	if cfg.url == "" {
		return cfg, fmt.Errorf("invalid number of arguments")
	}
	return cfg, nil
}

func needsValue(s string) bool {
	switch s {
	case "dns-resolver", "proxy", "rate-limit", "max-retries", "max-connections", "max-connections-per-host":
		return true
	}
	return false
}

func shortLong(s string) string {
	switch s {
	case "-b":
		return "buffer-size"
	case "-c":
		return "max-connections"
	case "-r":
		return "max-redirections"
	case "-t":
		return "timeout"
	}
	return ""
}

func parseIntValue(name, flag, val string, has bool, idx *int, args []string) (int, error) {
	if !has {
		*idx++
		if *idx >= len(args) {
			return 0, fmt.Errorf("expected argument for flag `%s'", flag)
		}
		val = args[*idx]
	}
	n, err := strconv.Atoi(val)
	if err != nil {
		return 0, fmt.Errorf("invalid argument for flag `--%s' (expected int): %v", name, err)
	}
	return n, nil
}

func parseRanges(s string) (ranges, error) {
	var out ranges
	for _, part := range strings.Split(s, ",") {
		part = strings.TrimSpace(part)
		if strings.Contains(part, "..") {
			x := strings.SplitN(part, "..", 2)
			a, e1 := strconv.Atoi(x[0])
			b, e2 := strconv.Atoi(x[1])
			if e1 != nil || e2 != nil {
				return nil, fmt.Errorf("invalid status code range: %s", part)
			}
			out = append(out, [2]int{a, b})
		} else {
			a, err := strconv.Atoi(part)
			if err != nil {
				return nil, fmt.Errorf("invalid status code range: %s", part)
			}
			out = append(out, [2]int{a, a + 1})
		}
	}
	return out, nil
}

func (r ranges) ok(code int) bool {
	for _, x := range r {
		if code >= x[0] && code < x[1] {
			return true
		}
	}
	return false
}

func newCrawler(cfg config, root *url.URL) *crawler {
	tr := &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: cfg.skipTLS}, DialContext: (&net.Dialer{Timeout: time.Duration(cfg.timeout) * time.Second}).DialContext}
	client := &http.Client{Transport: tr, Timeout: time.Duration(cfg.timeout) * time.Second}
	client.CheckRedirect = func(req *http.Request, via []*http.Request) error {
		if len(via) >= cfg.maxRedirects {
			return http.ErrUseLastResponse
		}
		return nil
	}
	return &crawler{cfg: cfg, client: client, root: root, seen: map[string]bool{}}
}

func (c *crawler) crawl(raw string, root bool) bool {
	if c.seen[raw] {
		return true
	}
	c.seen[raw] = true
	resp, body, err := c.fetch(raw)
	if err != nil {
		if root {
			fmt.Fprintf(os.Stderr, "failed to fetch root page: %s\n", err)
		}
		return false
	}
	if root && !c.cfg.accepted.ok(resp.StatusCode) {
		fmt.Fprintf(os.Stderr, "failed to fetch root page: %d\n", resp.StatusCode)
		return false
	}
	ct := resp.Header.Get("Content-Type")
	if !strings.Contains(strings.ToLower(ct), "html") && !bytes.Contains(bytes.ToLower(body[:min(len(body), 512)]), []byte("<html")) {
		c.results = append(c.results, pageResult{URL: raw})
		return true
	}
	links := extractLinks(string(body), resp.Request.URL)
	pr := pageResult{URL: raw}
	var toCrawl []string
	for _, l := range links {
		if !c.allowedByRegex(l) {
			continue
		}
		lr := c.checkLink(l, body, resp.Request.URL)
		if lr.Error != "" {
			c.failed = true
		}
		pr.Links = append(pr.Links, lr)
		if !c.cfg.onePage && lr.Error == "" && sameHost(c.root, mustParse(l)) && shouldCrawl(l) && !c.seen[stripFragment(l)] {
			toCrawl = append(toCrawl, stripFragment(l))
		}
	}
	sortLinks(pr.Links)
	c.results = append(c.results, pr)
	sort.Strings(toCrawl)
	for _, u := range toCrawl {
		c.crawl(u, false)
	}
	return true
}

func (c *crawler) fetch(raw string) (*http.Response, []byte, error) {
	req, err := http.NewRequest("GET", raw, nil)
	if err != nil {
		return nil, nil, err
	}
	req.Header.Set("User-Agent", "Muffet")
	for _, h := range c.cfg.headers {
		if p := strings.IndexByte(h, ':'); p >= 0 {
			req.Header.Set(strings.TrimSpace(h[:p]), strings.TrimSpace(h[p+1:]))
		}
	}
	resp, err := c.client.Do(req)
	if err != nil {
		return nil, nil, cleanErr(err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(resp.Body, c.cfg.maxBody))
	return resp, body, nil
}

func cleanErr(err error) error {
	s := err.Error()
	s = strings.ReplaceAll(s, "Get \"", "")
	if p := strings.Index(s, "\": "); p >= 0 {
		s = s[p+3:]
	}
	if strings.HasPrefix(s, "dial tcp ") {
		addr := strings.TrimPrefix(s, "dial tcp ")
		if p := strings.Index(addr, ": "); p >= 0 {
			addr = addr[:p]
			s = "error when dialing " + addr + ": " + s
		}
	}
	return fmt.Errorf("%s", s)
}

var attrRe = regexp.MustCompile(`(?is)\b(?:href|src|action|poster)\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)`)

func extractLinks(html string, base *url.URL) []string {
	seen := map[string]bool{}
	var links []string
	for _, m := range attrRe.FindAllStringSubmatch(html, -1) {
		v := strings.Trim(m[1], `"'`)
		if v == "" || strings.HasPrefix(v, "mailto:") || strings.HasPrefix(v, "tel:") || strings.HasPrefix(v, "javascript:") || strings.HasPrefix(v, "data:") {
			continue
		}
		u, err := url.Parse(v)
		if err != nil {
			continue
		}
		abs := base.ResolveReference(u).String()
		if !seen[abs] {
			seen[abs] = true
			links = append(links, abs)
		}
	}
	return links
}

func (c *crawler) checkLink(raw string, page []byte, base *url.URL) linkResult {
	u := mustParse(raw)
	if u == nil {
		return linkResult{URL: raw, Error: "invalid URL"}
	}
	if c.cfg.ignoreFrag {
		u.Fragment = ""
		raw = u.String()
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return linkResult{URL: raw, Error: fmt.Sprintf("unsupported protocol %q. http and https are supported", u.Scheme)}
	}
	if u.Fragment != "" && sameNoFragment(u, base) {
		if !hasFragment(page, u.Fragment) {
			return linkResult{URL: raw, Error: "id #" + u.Fragment + " not found"}
		}
	}
	checkURL := *u
	checkURL.Fragment = ""
	resp, _, err := c.fetch(checkURL.String())
	if err != nil {
		return linkResult{URL: raw, Error: err.Error()}
	}
	if !c.cfg.accepted.ok(resp.StatusCode) {
		return linkResult{URL: raw, Error: strconv.Itoa(resp.StatusCode), Status: resp.StatusCode}
	}
	return linkResult{URL: raw, Status: resp.StatusCode}
}

func hasFragment(body []byte, id string) bool {
	q := regexp.QuoteMeta(id)
	re := regexp.MustCompile(`(?is)\b(?:id|name)\s*=\s*["']?` + q + `["'\s>]`)
	return re.Find(body) != nil
}

func (c *crawler) allowedByRegex(u string) bool {
	for _, re := range c.cfg.includes {
		if !re.MatchString(u) {
			return false
		}
	}
	for _, re := range c.cfg.excludes {
		if re.MatchString(u) {
			return false
		}
	}
	return true
}

func sameHost(a, b *url.URL) bool {
	return b != nil && strings.EqualFold(a.Host, b.Host) && a.Scheme == b.Scheme
}
func sameNoFragment(a, b *url.URL) bool {
	x, y := *a, *b
	x.Fragment, y.Fragment = "", ""
	return x.String() == y.String()
}
func stripFragment(s string) string {
	u := mustParse(s)
	if u == nil {
		return s
	}
	u.Fragment = ""
	return u.String()
}
func shouldCrawl(s string) bool {
	u := mustParse(s)
	return u != nil && (u.Path == "" || strings.HasSuffix(u.Path, "/") || !strings.Contains(pathBase(u.Path), "."))
}
func pathBase(s string) string {
	i := strings.LastIndexByte(s, '/')
	if i >= 0 {
		return s[i+1:]
	}
	return s
}
func mustParse(s string) *url.URL {
	u, err := url.Parse(s)
	if err != nil {
		return nil
	}
	return u
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func sortLinks(xs []linkResult) {
	sort.Slice(xs, func(i, j int) bool {
		if (xs[i].Error == "") != (xs[j].Error == "") {
			return xs[i].Error == ""
		}
		if xs[i].Error != xs[j].Error {
			return xs[i].Error < xs[j].Error
		}
		return xs[i].URL < xs[j].URL
	})
}

func (c *crawler) emit() {
	switch c.cfg.format {
	case "json":
		out := c.results
		if !c.cfg.verbose {
			var f []pageResult
			for _, p := range out {
				var links []linkResult
				for _, l := range p.Links {
					if l.Error != "" {
						links = append(links, linkResult{URL: l.URL, Error: l.Error})
					}
				}
				if len(links) > 0 {
					f = append(f, pageResult{URL: p.URL, Links: links})
				}
			}
			out = f
		}
		b, _ := json.Marshal(out)
		fmt.Println(string(b))
	case "junit":
		emitJUnit(c.results)
	default:
		for _, p := range c.results {
			links := p.Links
			if !c.cfg.verbose {
				links = nil
				for _, l := range p.Links {
					if l.Error != "" {
						links = append(links, l)
					}
				}
			}
			if len(links) == 0 && !c.cfg.verbose {
				continue
			}
			fmt.Println(p.URL)
			for _, l := range links {
				if l.Error != "" {
					fmt.Printf("\t%s\t%s\n", l.Error, l.URL)
				} else {
					fmt.Printf("\t%d\t%s\n", l.Status, l.URL)
				}
			}
		}
	}
}

type testsuites struct {
	XMLName xml.Name    `xml:"testsuites"`
	Suites  []testsuite `xml:"testsuite"`
}
type testsuite struct {
	Name     string     `xml:"name,attr"`
	Tests    int        `xml:"tests,attr"`
	Failures int        `xml:"failures,attr"`
	Skipped  int        `xml:"skipped,attr"`
	Cases    []testcase `xml:"testcase"`
}
type testcase struct {
	Name    string   `xml:"name,attr"`
	Class   string   `xml:"classname,attr"`
	Failure *failure `xml:"failure,omitempty"`
}
type failure struct {
	Message string `xml:"message,attr"`
}

func emitJUnit(pages []pageResult) {
	var ts testsuites
	for _, p := range pages {
		s := testsuite{Name: p.URL, Tests: len(p.Links)}
		for _, l := range p.Links {
			tc := testcase{Name: l.URL, Class: p.URL}
			if l.Error != "" {
				s.Failures++
				tc.Failure = &failure{Message: l.Error}
			}
			s.Cases = append(s.Cases, tc)
		}
		ts.Suites = append(ts.Suites, s)
	}
	b, _ := xml.MarshalIndent(ts, "", "  ")
	fmt.Println(xml.Header + string(b))
}

func printHelp() {
	fmt.Println(`Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version`)
}
