module muffet-reimpl

go 1.21
