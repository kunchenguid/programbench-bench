package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type Node struct {
	Name, Fn, Desc, Long, Version string
	Aliases                      []string
	Opts                         []*Opt
	Args                         []*Arg
	Envs                         []*Env
	Children                     []*Node
	Parent                       *Node `json:"-"`
	DefaultSub                   bool
}

type Opt struct {
	ID, Long, Short, Desc, Default, Env string
	Flag, Required, Multi, Delim       bool
	Terminated, Assigned, Prefixed     bool
	Notations, Choices                 []string
	SkipChoice                         bool
	Min, Max                           int
	Seen                               int
	Values                             []string
}

type Arg struct {
	ID, Desc, Notation, Default, Env string
	Required, Multi, Delim, Term     bool
	Choices                          []string
	SkipChoice                       bool
	Values                           []string
}

type Env struct {
	Name, Desc, Default string
	Required           bool
	Choices            []string
}

type Meta struct {
	CombineShorts bool
	Inherit       bool
	Dotenv        bool
	Symbols       []*Arg
}

type Model struct {
	Root *Node
	Meta Meta
	File string
}

type tag struct{ kind, rest string }

func main() {
	if len(os.Args) == 1 {
		runArgcfile(os.Args[1:])
		return
	}
	switch os.Args[1] {
	case "--argc-help":
		fmt.Print(argcHelp())
	case "--argc-version":
		fmt.Println("argc 1.23.0")
	case "--argc-shell-path":
		fmt.Println("/usr/bin/bash")
	case "--argc-script-path":
		if p := findArgcfile(); p != "" {
			fmt.Println(p)
		} else {
			fmt.Fprintln(os.Stderr, "Argcfile not found.")
			os.Exit(1)
		}
	case "--argc-eval":
		if len(os.Args) < 3 {
			fmt.Fprintln(os.Stderr, "error: missing <FILE>")
			os.Exit(1)
		}
		m, err := parseFile(os.Args[2])
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		fmt.Print(eval(m, os.Args[3:]))
	case "--argc-run":
		if len(os.Args) < 3 {
			os.Exit(1)
		}
		runScript(os.Args[2], os.Args[3:])
	case "--argc-export":
		if len(os.Args) < 3 {
			os.Exit(1)
		}
		m, err := parseFile(os.Args[2])
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		out, _ := json.MarshalIndent(exportNode(m.Root), "", "  ")
		fmt.Println(string(out))
	case "--argc-compgen":
		if len(os.Args) < 5 {
			return
		}
		m, err := parseFile(os.Args[3])
		if err == nil {
			compgen(m, os.Args[4:])
		}
	case "--argc-completions":
		fmt.Println("# argc completion support")
		fmt.Println("# call: argc --argc-compgen <shell> <file> <args>")
	case "--argc-mangen":
		if len(os.Args) >= 4 {
			mangen(os.Args[2], os.Args[3])
		}
	case "--argc-build":
		if len(os.Args) >= 3 {
			buildCopy(os.Args[2], pickOut(os.Args[2], os.Args[3:]))
		}
	case "--argc-create":
		create(os.Args[2:])
	case "--argc-parallel":
		parallel(os.Args[2:])
	default:
		runArgcfile(os.Args[1:])
	}
}

func argcHelp() string {
	return "A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n\n" +
		"USAGE:\n" +
		"    argc --argc-eval <FILE> <ARGS~>            Use `eval \"$(argc --argc-eval \"$0\" \"$@\")\"`\n" +
		"    argc --argc-create <RECIPES~>              Create a boilerplate argcfile\n" +
		"    argc --argc-run <FILE> <ARGS~>             Run an argc-based script\n" +
		"    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency\n" +
		"    argc --argc-mangen <FILE> <OUTDIR>        Generate man pages\n" +
		"    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts\n" +
		"    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates\n" +
		"    argc --argc-export <FILE>                  Export command line definitions as json\n" +
		"    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel\n" +
		"    argc --argc-script-path                    Print current argcfile path\n" +
		"    argc --argc-shell-path                     Print current shell path\n" +
		"    argc --argc-help                           Print help information\n" +
		"    argc --argc-version                        Print version information\n"
}

func parseFile(path string) (*Model, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	root := &Node{Name: baseName(path)}
	m := &Model{Root: root, File: path}
	var pending []tag
	var target *Node = root
	reFn := regexp.MustCompile(`^\s*([A-Za-z0-9_:+-]+)\s*\(\s*\)\s*\{?`)
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		t, ok := parseTag(line)
		if ok {
			pending = append(pending, t)
			continue
		}
		if strings.HasPrefix(strings.TrimSpace(line), "#") && len(pending) > 0 {
			txt := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(line), "#"))
			if !strings.HasPrefix(txt, "@") {
				pending = append(pending, tag{kind: "long", rest: txt})
				continue
			}
		}
		if ms := reFn.FindStringSubmatch(line); ms != nil {
			fn := ms[1]
			hasCmd := false
			for _, p := range pending {
				if p.kind == "cmd" {
					hasCmd = true
				}
			}
			if hasCmd {
				target = ensureCommand(root, fn)
				target.Fn = fn
				applyTags(m, target, pending)
			} else if fn == "main" {
				root.Fn = "main"
				applyTags(m, root, pending)
			}
			pending = nil
			target = root
			continue
		}
		if strings.TrimSpace(line) == "" {
			hasCmd := false
			for _, p := range pending {
				if p.kind == "cmd" {
					hasCmd = true
				}
			}
			if !hasCmd {
				applyTags(m, target, pending)
				pending = nil
			}
			continue
		}
		if !strings.HasPrefix(strings.TrimSpace(line), "#") {
			applyTags(m, target, pending)
			pending = nil
		}
	}
	applyTags(m, root, pending)
	addBuiltins(root)
	return m, nil
}

func parseTag(line string) (tag, bool) {
	s := strings.TrimSpace(line)
	if !strings.HasPrefix(s, "#") {
		return tag{}, false
	}
	s = strings.TrimSpace(strings.TrimPrefix(s, "#"))
	if strings.HasPrefix(s, "@") {
		s = strings.TrimPrefix(s, "@")
		parts := strings.Fields(s)
		if len(parts) == 0 {
			return tag{}, false
		}
		rest := strings.TrimSpace(strings.TrimPrefix(s, parts[0]))
		return tag{parts[0], rest}, true
	}
	return tag{}, false
}

func applyTags(m *Model, n *Node, tags []tag) {
	var lastDesc *string
	for _, t := range tags {
		switch t.kind {
		case "describe":
			n.Desc = t.rest
			lastDesc = &n.Long
		case "long":
			if lastDesc != nil {
				if *lastDesc != "" {
					*lastDesc += "\n"
				}
				*lastDesc += t.rest
			}
		case "cmd":
			if t.rest != "" {
				n.Desc = t.rest
			}
			lastDesc = &n.Long
		case "alias":
			n.Aliases = append(n.Aliases, strings.Fields(t.rest)...)
		case "flag":
			o := parseOpt(t.rest, true)
			n.Opts = append(n.Opts, o)
			lastDesc = &o.Desc
		case "option":
			o := parseOpt(t.rest, false)
			n.Opts = append(n.Opts, o)
			lastDesc = &o.Desc
		case "arg":
			a := parseArg(t.rest)
			n.Args = append(n.Args, a)
			lastDesc = &a.Desc
		case "env":
			n.Envs = append(n.Envs, parseEnv(t.rest))
		case "meta":
			fs := strings.Fields(t.rest)
			if len(fs) == 0 {
				continue
			}
			switch fs[0] {
			case "combine-shorts":
				m.Meta.CombineShorts = true
			case "inherit-flag-options":
				m.Meta.Inherit = true
			case "dotenv":
				m.Meta.Dotenv = true
			case "version":
				if len(fs) > 1 {
					n.Version = fs[1]
				}
			case "default-subcommand":
				n.DefaultSub = true
			case "symbol":
				if len(fs) > 1 {
					m.Meta.Symbols = append(m.Meta.Symbols, parseArg(fs[1]))
				}
			}
		}
	}
	if n != nil && n != m.Root {
		addHyphenAlias(n)
	}
}

func parseOpt(rest string, flag bool) *Opt {
	toks := shellFields(rest)
	o := &Opt{Flag: flag, Min: 1, Max: 1}
	i := 0
	for i < len(toks) {
		t := toks[i]
		if isNameTok(t) {
			name, assigned := strings.CutSuffix(t, ":")
			if assigned {
				o.Assigned = true
			}
			name = stripSpec(name, o)
			if strings.HasPrefix(name, "--") || strings.HasPrefix(name, "+") && len(name) > 2 {
				o.Long = name
			} else if strings.HasPrefix(name, "-") || strings.HasPrefix(name, "+") {
				if o.Short == "" {
					o.Short = name
				} else {
					o.Long = name
				}
			}
			i++
			continue
		}
		if strings.HasPrefix(t, "<") && strings.HasSuffix(t, ">") {
			nt := strings.Trim(t, "<>")
			min, max := notationRange(nt)
			o.Notations = append(o.Notations, strings.TrimRight(nt, "*+?"))
			if max > o.Max {
				o.Max = max
			}
			if min > o.Min {
				o.Min = min
			}
			i++
			continue
		}
		break
	}
	if o.Flag {
		o.Min, o.Max = 0, 0
	}
	o.Desc = strings.Join(toks[i:], " ")
	o.ID = ident(firstNonempty(o.Long, o.Short))
	if len(o.Notations) == 0 && !o.Flag {
		o.Notations = []string{strings.ToUpper(o.ID)}
	}
	if o.Multi && !o.Flag {
		o.Max = 9999
	}
	return o
}

func parseArg(rest string) *Arg {
	toks := shellFields(rest)
	a := &Arg{}
	if len(toks) == 0 {
		return a
	}
	spec := toks[0]
	a.ID = ident(stripArgSpec(spec, a))
	a.Notation = strings.ToUpper(a.ID)
	i := 1
	if i < len(toks) && strings.HasPrefix(toks[i], "<") {
		a.Notation = strings.Trim(toks[i], "<>")
		i++
	}
	a.Desc = strings.Join(toks[i:], " ")
	if strings.Contains(spec, "!") || strings.Contains(spec, "+") {
		a.Required = true
	}
	if strings.Contains(spec, "*") || strings.Contains(spec, "+") || strings.Contains(spec, "~") || strings.Contains(spec, "...") {
		a.Multi = true
	}
	if strings.Contains(spec, ",") {
		a.Delim = true
	}
	if strings.Contains(spec, "~") {
		a.Term = true
	}
	return a
}

func parseEnv(rest string) *Env {
	toks := shellFields(rest)
	e := &Env{}
	if len(toks) == 0 {
		return e
	}
	spec := toks[0]
	e.Required = strings.Contains(spec, "!")
	if idx := strings.Index(spec, "="); idx >= 0 {
		e.Default = strings.Trim(spec[idx+1:], "`")
		spec = spec[:idx]
	}
	if idx := strings.Index(spec, "["); idx >= 0 {
		e.Choices = strings.Split(strings.Trim(spec[idx+1:strings.Index(spec, "]")], "="), "|")
		spec = spec[:idx]
	}
	e.Name = strings.TrimRight(spec, "!")
	e.Desc = strings.Join(toks[1:], " ")
	return e
}

func stripSpec(s string, o *Opt) string {
	if strings.Contains(s, "[") {
		inside := s[strings.Index(s, "[")+1 : strings.LastIndex(s, "]")]
		if strings.HasPrefix(inside, "?") {
			o.SkipChoice = true
			inside = strings.TrimPrefix(inside, "?")
		}
		if strings.HasPrefix(inside, "=") {
			inside = strings.TrimPrefix(inside, "=")
			o.Default = strings.Split(inside, "|")[0]
		}
		if strings.HasPrefix(inside, "`") && strings.HasSuffix(inside, "`") {
			o.Choices = []string{"`" + strings.Trim(inside, "`") + "`"}
		} else {
			o.Choices = strings.Split(inside, "|")
		}
		s = s[:strings.Index(s, "[")]
	}
	if strings.Contains(s, "=") {
		p := strings.SplitN(s, "=", 2)
		s, o.Default = p[0], strings.Trim(p[1], "`")
	}
	for {
		if strings.HasSuffix(s, "!") {
			o.Required = true; s = strings.TrimSuffix(s, "!")
		} else if strings.HasSuffix(s, "*") {
			o.Multi = true; s = strings.TrimSuffix(s, "*")
		} else if strings.HasSuffix(s, "+") {
			o.Multi = true; o.Required = true; s = strings.TrimSuffix(s, "+")
		} else if strings.HasSuffix(s, ",") {
			o.Delim = true; s = strings.TrimSuffix(s, ",")
		} else if strings.HasSuffix(s, "~") {
			o.Terminated = true; s = strings.TrimSuffix(s, "~")
		} else {
			break
		}
	}
	if strings.Contains(s, "*") {
		o.Prefixed = true
		s = strings.ReplaceAll(s, "*", "")
	}
	return s
}

func stripArgSpec(s string, a *Arg) string {
	if strings.Contains(s, "[") && strings.Contains(s, "]") {
		inside := s[strings.Index(s, "[")+1 : strings.LastIndex(s, "]")]
		if strings.HasPrefix(inside, "?") {
			a.SkipChoice = true
			inside = strings.TrimPrefix(inside, "?")
		}
		if strings.HasPrefix(inside, "=") {
			inside = strings.TrimPrefix(inside, "=")
			a.Default = strings.Split(inside, "|")[0]
		}
		if strings.HasPrefix(inside, "`") && strings.HasSuffix(inside, "`") {
			a.Choices = []string{"`" + strings.Trim(inside, "`") + "`"}
		} else {
			a.Choices = strings.Split(inside, "|")
		}
		s = s[:strings.Index(s, "[")]
	}
	if strings.Contains(s, "=") {
		p := strings.SplitN(s, "=", 2)
		s, a.Default = p[0], strings.Trim(p[1], "`")
	}
	return strings.TrimRight(strings.ReplaceAll(s, "...", "*"), "!*+~,")
}

func eval(m *Model, args []string) string {
	root := cloneTree(m.Root)
	loadDotenv(m)
	origArgs := append([]string{}, args...)
	node := root
	consumedCmds := []string{root.Name}
	prefixArgs := []string{}
	for len(args) > 0 {
		if c := findChild(node, args[0]); c != nil {
			node = c
			consumedCmds = append(consumedCmds, c.Name)
			args = args[1:]
		} else if node == root && m.Meta.Inherit && isOptToken(args[0]) {
			name := args[0]
			if n, _, ok := strings.Cut(name, "="); ok {
				name = n
			}
			if o := findOpt(root.Opts, name); o != nil {
				prefixArgs = append(prefixArgs, args[0])
				if !o.Flag && !strings.Contains(args[0], "=") && len(args) > 1 {
					args = args[1:]
					prefixArgs = append(prefixArgs, args[0])
				}
				args = args[1:]
			} else {
				break
			}
		} else {
			break
		}
	}
	if node == root {
		for _, c := range root.Children {
			if c.DefaultSub {
				node = c
				consumedCmds = append(consumedCmds, c.Name)
				break
			}
		}
	}
	for _, e := range append(root.Envs, node.Envs...) {
		if e.Default != "" && os.Getenv(e.Name) == "" {
			os.Setenv(e.Name, evalDefault(m.File, e.Default))
		}
		if e.Required && os.Getenv(e.Name) == "" {
			return emitMsg(fmt.Sprintf("error: the following required environment variables were not provided:\n  %s", e.Name), 1)
		}
	}
	if has(args, "--help") || has(args, "-h") {
		return emitMsg(helpText(root, node), 0)
	}
	if has(args, "--version") || has(args, "-V") {
		v := firstNonempty(node.Version, root.Version)
		if v == "" {
			v = root.Name + " 0.0.0"
		}
		return emitMsg(v, 0)
	}
	if len(node.Children) > 0 {
		if len(args) == 0 {
			return emitMsg(helpText(root, node), 0)
		}
		names := childNames(node)
		return emitMsg(fmt.Sprintf("error: `%s` requires a subcommand but '%s' is not one of them\n  [subcommands: %s]", pathName(consumedCmds), args[0], strings.Join(names, ", ")), 1)
	}
	if len(prefixArgs) > 0 {
		args = append(prefixArgs, args...)
	}
	opts := effectiveOpts(root, node, m.Meta.Inherit)
	pos, err := parseArgs(m, node, opts, args)
	if err != "" {
		return emitMsg(err, 1)
	}
	missing := []string{}
	for _, o := range opts {
		if o.Default != "" && len(o.Values) == 0 && !o.Flag {
			o.Values = []string{evalDefault(m.File, o.Default)}
		}
		if o.Required && o.Seen == 0 && len(o.Values) == 0 {
			missing = append(missing, "  "+optUsage(o))
		}
	}
	for _, a := range node.Args {
		if a.Default != "" && len(a.Values) == 0 {
			a.Values = []string{evalDefault(m.File, a.Default)}
		}
		if a.Required && len(a.Values) == 0 {
			missing = append(missing, "  "+argUsage(a))
		}
	}
	if len(missing) > 0 {
		return emitMsg("error: the following required arguments were not provided:\n"+strings.Join(missing, "\n"), 1)
	}
	lines := []string{}
	for _, o := range opts {
		if o.Flag {
			if o.Seen > 0 {
				lines = append(lines, fmt.Sprintf("argc_%s=%d", o.ID, o.Seen))
			}
		} else if o.Multi {
			lines = append(lines, fmt.Sprintf("argc_%s=( %s )", o.ID, shellJoin(o.Values)))
		} else if len(o.Values) > 0 {
			lines = append(lines, fmt.Sprintf("argc_%s=%s", o.ID, shellQuote(o.Values[len(o.Values)-1])))
		}
	}
	for _, a := range node.Args {
		if a.Multi {
			lines = append(lines, fmt.Sprintf("argc_%s=( %s )", a.ID, shellJoin(a.Values)))
		} else if len(a.Values) > 0 {
			lines = append(lines, fmt.Sprintf("argc_%s=%s", a.ID, shellQuote(a.Values[0])))
		}
	}
	fn := node.Fn
	if fn == "" {
		fn = "main"
	}
	all := append([]string{root.Name}, origArgs...)
	body := append([]string{}, lines...)
	body = append(body, fmt.Sprintf("argc__args=( %s )", shellJoin(all)))
	body = append(body, fmt.Sprintf("argc__fn=%s", shellQuote(fn)))
	body = append(body, fmt.Sprintf("argc__positionals=( %s )", shellJoin(pos)))
	body = append(body, fmt.Sprintf("%s %s", fn, shellJoin(pos)))
	return strings.Join(body, "\n") + "\n"
}

func parseArgs(m *Model, n *Node, opts []*Opt, argv []string) ([]string, string) {
	pos := []string{}
	stop := false
	for i := 0; i < len(argv); i++ {
		x := argv[i]
		if x == "--" {
			stop = true
			continue
		}
		if !stop && isOptToken(x) {
			name, val, hasVal := strings.Cut(x, "=")
			o := findOpt(opts, name)
			if o == nil && m.Meta.CombineShorts && strings.HasPrefix(x, "-") && !strings.HasPrefix(x, "--") && len(x) > 2 {
				for _, r := range x[1:] {
					oo := findOpt(opts, "-"+string(r))
					if oo == nil || !oo.Flag {
						return nil, fmt.Sprintf("error: unexpected argument '%s' found", x)
					}
					oo.Seen++
				}
				continue
			}
			if o == nil {
				return nil, fmt.Sprintf("error: unexpected argument '%s' found", x)
			}
			o.Seen++
			if o.Flag {
				continue
			}
			vals := []string{}
			if hasVal {
				vals = append(vals, val)
			}
			need := o.Min
			for len(vals) < need && i+1 < len(argv) {
				i++
				vals = append(vals, argv[i])
			}
			for o.Max > len(vals) && i+1 < len(argv) && !isOptToken(argv[i+1]) {
				i++
				vals = append(vals, argv[i])
				if o.Max != 9999 {
					break
				}
			}
			if len(vals) < need {
				return nil, fmt.Sprintf("error: a value is required for '%s %s' but none was supplied", name, strings.Join(o.Notations, " "))
			}
			addVals := splitDelim(vals, o.Delim)
			if err := checkChoices(m.File, o.Choices, o.SkipChoice, addVals); err != "" {
				return nil, err
			}
			o.Values = append(o.Values, addVals...)
			if o.Terminated {
				for i+1 < len(argv) {
					i++; o.Values = append(o.Values, argv[i])
				}
			}
		} else {
			pos = append(pos, x)
		}
	}
	j := 0
	for _, a := range n.Args {
		if a.Multi || a.Term {
			a.Values = append(a.Values, splitDelim(pos[j:], a.Delim)...)
			j = len(pos)
		} else if j < len(pos) {
			a.Values = []string{pos[j]}
			j++
		}
		if err := checkChoices(m.File, a.Choices, a.SkipChoice, a.Values); err != "" {
			return nil, err
		}
	}
	if j < len(pos) && len(n.Args) > 0 {
		return nil, fmt.Sprintf("error: unexpected argument '%s' found", pos[j])
	}
	return pos, ""
}

func helpText(root, n *Node) string {
	parts := []string{}
	if n.Desc != "" {
		parts = append(parts, n.Desc)
	}
	if n.Long != "" {
		parts = append(parts, n.Long)
	}
	usage := "USAGE: " + usageLine(root, n)
	parts = append(parts, usage)
	if len(n.Args) > 0 {
		lines := []string{"ARGS:"}
		for _, a := range n.Args {
			lines = append(lines, fmt.Sprintf("  %-10s %s", argUsage(a), a.Desc))
		}
		parts = append(parts, strings.Join(lines, "\n"))
	}
	if len(n.Opts) > 0 && len(n.Children) == 0 {
		lines := []string{"OPTIONS:"}
		for _, o := range n.Opts {
			lines = append(lines, fmt.Sprintf("  %-22s %s", optNames(o), descOpt(o)))
		}
		parts = append(parts, strings.Join(lines, "\n"))
	}
	if len(n.Children) > 0 {
		lines := []string{"COMMANDS:"}
		w := 0
		for _, c := range n.Children {
			if len(c.Name) > w {
				w = len(c.Name)
			}
		}
		for _, c := range n.Children {
			d := c.Desc
			if len(c.Aliases) > 0 {
				if d != "" {
					d += " "
				}
				d += "[aliases: " + strings.Join(c.Aliases, ", ") + "]"
			}
			lines = append(lines, fmt.Sprintf("  %-*s  %s", w, c.Name, d))
		}
		parts = append(parts, strings.Join(lines, "\n"))
	}
	return strings.Join(parts, "\n\n")
}

func usageLine(root, n *Node) string {
	path := []string{}
	for x := n; x != nil; x = x.Parent {
		path = append([]string{x.Name}, path...)
	}
	if len(path) == 0 || path[0] != root.Name {
		path = append([]string{root.Name}, path...)
	}
	s := strings.Join(path, " ")
	if len(n.Children) > 0 {
		return s + " <COMMAND>"
	}
	if len(n.Opts) > 0 {
		s += " [OPTIONS]"
	}
	for _, a := range n.Args {
		s += " " + argUsage(a)
	}
	return s
}

func emitMsg(msg string, code int) string {
	return fmt.Sprintf("command cat >&2 <<-'EOF' \n%s\nEOF\nexit %d\n", msg, code)
}

func ensureCommand(root *Node, fn string) *Node {
	parts := strings.Split(fn, "::")
	cur := root
	for _, p := range parts {
		name := p
		var child *Node
		for _, c := range cur.Children {
			if c.Name == name {
				child = c
				break
			}
		}
		if child == nil {
			child = &Node{Name: name, Parent: cur}
			cur.Children = append(cur.Children, child)
		}
		cur = child
	}
	return cur
}

func addBuiltins(n *Node) {
	if len(n.Children) > 0 {
		n.Opts = append(n.Opts, &Opt{ID: "help", Long: "--help", Short: "-h", Flag: true}, &Opt{ID: "version", Long: "--version", Short: "-V", Flag: true})
		for _, c := range n.Children {
			addBuiltins(c)
		}
	} else {
		hasH := false
		for _, o := range n.Opts {
			if o.ID == "help" {
				hasH = true
			}
		}
		if !hasH {
			n.Opts = append(n.Opts, &Opt{ID: "help", Long: "--help", Short: "-h", Flag: true, Desc: "Print help"})
		}
	}
}

func addHyphenAlias(n *Node) {
	h := strings.ReplaceAll(n.Name, "_", "-")
	if h != n.Name && !contains(n.Aliases, h) {
		n.Aliases = append([]string{h}, n.Aliases...)
	}
}

func shellFields(s string) []string {
	var out []string
	var b strings.Builder
	in := rune(0)
	for _, r := range s {
		if in != 0 {
			b.WriteRune(r)
			if r == in {
				in = 0
			}
			continue
		}
		if r == '\'' || r == '"' || r == '`' {
			in = r
			b.WriteRune(r)
		} else if r == ' ' || r == '\t' {
			if b.Len() > 0 {
				out = append(out, b.String()); b.Reset()
			}
		} else {
			b.WriteRune(r)
		}
	}
	if b.Len() > 0 {
		out = append(out, b.String())
	}
	return out
}

func isNameTok(t string) bool {
	return strings.HasPrefix(t, "-") || strings.HasPrefix(t, "+")
}
func isOptToken(t string) bool { return isNameTok(t) && t != "-" }

func notationRange(s string) (int, int) {
	if strings.HasSuffix(s, "*") {
		return 0, 9999
	}
	if strings.HasSuffix(s, "+") {
		return 1, 9999
	}
	if strings.HasSuffix(s, "?") {
		return 0, 1
	}
	return 1, 1
}

func ident(s string) string {
	s = strings.TrimLeft(s, "-+")
	for _, ch := range []string{"-", ".", ":"} {
		s = strings.ReplaceAll(s, ch, "_")
	}
	return strings.ToLower(s)
}

func baseName(path string) string {
	b := filepath.Base(path)
	ext := filepath.Ext(b)
	if ext != "" {
		b = strings.TrimSuffix(b, ext)
	}
	return b
}

func firstNonempty(xs ...string) string {
	for _, x := range xs {
		if x != "" {
			return x
		}
	}
	return ""
}

func findChild(n *Node, name string) *Node {
	for _, c := range n.Children {
		if c.Name == name || contains(c.Aliases, name) {
			return c
		}
	}
	return nil
}

func findOpt(opts []*Opt, name string) *Opt {
	for _, o := range opts {
		if o.Long == name || o.Short == name || (o.Prefixed && strings.HasPrefix(name, strings.TrimRight(o.Long, "-+"))) {
			return o
		}
	}
	return nil
}

func contains(xs []string, x string) bool {
	for _, y := range xs {
		if x == y {
			return true
		}
	}
	return false
}

func has(xs []string, x string) bool { return contains(xs, x) }

func childNames(n *Node) []string {
	var out []string
	for _, c := range n.Children {
		out = append(out, c.Name)
		out = append(out, c.Aliases...)
	}
	return out
}

func pathName(parts []string) string { return strings.Join(parts, " ") }

func effectiveOpts(root, n *Node, inherit bool) []*Opt {
	if inherit && n != root {
		return append(cloneOpts(root.Opts), cloneOpts(n.Opts)...)
	}
	return cloneOpts(n.Opts)
}

func cloneOpts(in []*Opt) []*Opt {
	out := make([]*Opt, len(in))
	for i, o := range in {
		c := *o
		c.Values = nil
		out[i] = &c
	}
	return out
}

func cloneTree(n *Node) *Node {
	c := *n
	c.Opts = cloneOpts(n.Opts)
	c.Args = make([]*Arg, len(n.Args))
	for i, a := range n.Args {
		aa := *a; aa.Values = nil; c.Args[i] = &aa
	}
	c.Children = make([]*Node, len(n.Children))
	for i, ch := range n.Children {
		c.Children[i] = cloneTree(ch); c.Children[i].Parent = &c
	}
	return &c
}

func optUsage(o *Opt) string {
	n := firstNonempty(o.Long, o.Short)
	if o.Flag {
		return n
	}
	if len(o.Notations) > 0 {
		return n + " <" + strings.Join(o.Notations, "> <") + ">" + map[bool]string{true: "...", false: ""}[o.Multi]
	}
	return n + " <" + strings.ToUpper(o.ID) + ">"
}

func optNames(o *Opt) string {
	names := []string{}
	if o.Short != "" {
		names = append(names, o.Short)
	}
	if o.Long != "" {
		names = append(names, o.Long)
	}
	s := strings.Join(names, ", ")
	if !o.Flag {
		if o.Multi {
			s += " [" + strings.ToUpper(o.ID) + "]..."
		} else if len(o.Notations) > 0 {
			s += " <" + strings.Join(o.Notations, "> <") + ">"
		} else {
			s += " <" + strings.ToUpper(o.ID) + ">"
		}
	}
	return s
}

func descOpt(o *Opt) string {
	if o.Desc != "" {
		return o.Desc
	}
	if o.ID == "help" {
		return "Print help"
	}
	if o.ID == "version" {
		return "Print version"
	}
	return ""
}

func argUsage(a *Arg) string {
	n := a.Notation
	if n == "" {
		n = strings.ToUpper(a.ID)
	}
	if a.Multi {
		n += "..."
	}
	if a.Required {
		return "<" + n + ">"
	}
	return "[" + n + "]"
}

func splitDelim(vals []string, delim bool) []string {
	if !delim {
		return vals
	}
	var out []string
	for _, v := range vals {
		for _, p := range strings.Split(v, ",") {
			if p != "" {
				out = append(out, p)
			}
		}
	}
	return out
}

func checkChoices(file string, choices []string, skip bool, vals []string) string {
	if skip || len(choices) == 0 || len(vals) == 0 {
		return ""
	}
	chs := choices
	if len(chs) == 1 && strings.HasPrefix(chs[0], "`") {
		chs = strings.Fields(evalDefault(file, strings.Trim(chs[0], "`")))
	}
	for _, v := range vals {
		if !contains(chs, v) {
			return fmt.Sprintf("error: invalid value '%s'", v)
		}
	}
	return ""
}

func evalDefault(file, expr string) string {
	if expr == "" {
		return ""
	}
	if strings.ContainsAny(expr, " \t\n") {
		return expr
	}
	cmd := exec.Command("bash", "-lc", "source "+strconv.Quote(file)+" >/dev/null 2>&1 || true; "+expr)
	out, err := cmd.Output()
	if err == nil && len(out) > 0 {
		return strings.TrimSpace(string(out))
	}
	return expr
}

func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	if regexp.MustCompile(`^[A-Za-z0-9_./:@%+=,-]+$`).MatchString(s) {
		return s
	}
	return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'"
}

func shellJoin(xs []string) string {
	out := make([]string, len(xs))
	for i, x := range xs {
		out[i] = shellQuote(x)
	}
	return strings.Join(out, " ")
}

func compgen(m *Model, args []string) {
	n := m.Root
	if len(args) > 0 {
		args = args[1:]
	}
	prefix := ""
	if len(args) > 0 {
		prefix = args[len(args)-1]
		args = args[:len(args)-1]
	}
	for _, a := range args {
		if c := findChild(n, a); c != nil {
			n = c
		}
	}
	var lines []string
	if strings.HasPrefix(prefix, "-") || prefix == "" && len(n.Children) == 0 {
		for _, o := range n.Opts {
			if o.Long != "" && strings.HasPrefix(o.Long, prefix) {
				lines = append(lines, o.Long+" ("+descOpt(o)+")")
			}
		}
	} else {
		for _, c := range n.Children {
			if strings.HasPrefix(c.Name, prefix) {
				lines = append(lines, c.Name+" ("+c.Desc+")")
			}
		}
		if strings.HasPrefix("help", prefix) {
			lines = append(lines, "help (Show help for a command)")
		}
	}
	fmt.Println(strings.Join(lines, "\n"))
}

func exportNode(n *Node) map[string]any {
	type eo struct {
		ID, LongName, ShortName, Describe string `json:",omitempty"`
		Flag                             bool
	}
	m := map[string]any{"name": n.Name, "describe": nullable(n.Desc), "aliases": n.Aliases, "command_fn": nullable(n.Fn)}
	var opts []map[string]any
	for _, o := range n.Opts {
		opts = append(opts, map[string]any{"id": o.ID, "long_name": nullable(o.Long), "short_name": nullable(o.Short), "describe": o.Desc, "flag": o.Flag})
	}
	m["flag_options"] = opts
	var args []map[string]any
	for _, a := range n.Args {
		args = append(args, map[string]any{"id": a.ID, "describe": a.Desc, "notation": a.Notation, "required": a.Required, "multiple": a.Multi})
	}
	m["positionals"] = args
	var subs []map[string]any
	for _, c := range n.Children {
		subs = append(subs, exportNode(c))
	}
	m["subcommands"] = subs
	return m
}

func nullable(s string) any {
	if s == "" {
		return nil
	}
	return s
}

func loadDotenv(m *Model) {
	if !m.Meta.Dotenv {
		return
	}
	b, err := os.ReadFile(".env")
	if err != nil {
		return
	}
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "=") {
			continue
		}
		p := strings.SplitN(line, "=", 2)
		if os.Getenv(p[0]) == "" {
			os.Setenv(p[0], strings.Trim(p[1], `"'`))
		}
	}
}

func runScript(file string, args []string) {
	tmp, _ := os.MkdirTemp("", "argc-path-")
	if tmp != "" {
		self, _ := filepath.Abs(os.Args[0])
		_ = os.Symlink(self, filepath.Join(tmp, "argc"))
		defer os.RemoveAll(tmp)
	}
	cmd := exec.Command("bash", append([]string{file}, args...)...)
	cmd.Stdout, cmd.Stderr, cmd.Stdin = os.Stdout, os.Stderr, os.Stdin
	path := filepath.Dir(os.Args[0]) + ":" + os.Getenv("PATH")
	if tmp != "" {
		path = tmp + ":" + path
	}
	cmd.Env = append(os.Environ(), "PATH="+path)
	_ = cmd.Run()
}

func findArgcfile() string {
	dir, _ := os.Getwd()
	for {
		for _, n := range []string{"Argcfile.sh", "Argcfile"} {
			p := filepath.Join(dir, n)
			if _, err := os.Stat(p); err == nil {
				return p
			}
		}
		nd := filepath.Dir(dir)
		if nd == dir {
			return ""
		}
		dir = nd
	}
}

func runArgcfile(args []string) {
	p := findArgcfile()
	if p == "" {
		fmt.Fprintln(os.Stderr, "Argcfile not found, try `argc --argc-help` for help.")
		os.Exit(1)
	}
	m, err := parseFile(p)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Print(eval(m, args))
}

func mangen(file, outdir string) {
	m, err := parseFile(file)
	if err != nil {
		os.Exit(1)
	}
	os.MkdirAll(outdir, 0755)
	name := m.Root.Name + ".1"
	body := ".TH " + strings.ToUpper(m.Root.Name) + " 1\n.SH NAME\n" + m.Root.Name + " - " + m.Root.Desc + "\n.SH SYNOPSIS\n" + usageLine(m.Root, m.Root) + "\n"
	os.WriteFile(filepath.Join(outdir, name), []byte(body), 0644)
}

func buildCopy(file, out string) {
	b, err := os.ReadFile(file)
	if err != nil {
		os.Exit(1)
	}
	if st, err := os.Stat(out); err == nil && st.IsDir() {
		out = filepath.Join(out, filepath.Base(file))
	}
	os.WriteFile(out, b, 0755)
}

func pickOut(file string, args []string) string {
	if len(args) > 0 {
		return args[0]
	}
	return strings.TrimSuffix(file, filepath.Ext(file)) + "-standalone.sh"
}

func create(recipes []string) {
	for _, r := range recipes {
		fmt.Printf("# @cmd\n%s() {\n    :\n}\n\n", strings.ReplaceAll(r, "-", "_"))
	}
}

func parallel(args []string) {
	if len(args) < 2 {
		return
	}
	file := args[0]
	var cmds [][]string
	cur := []string{}
	for _, a := range args[1:] {
		if a == ":::" {
			if len(cur) > 0 {
				cmds = append(cmds, cur)
			}
			cur = nil
		} else {
			cur = append(cur, a)
		}
	}
	if len(cur) > 0 {
		cmds = append(cmds, cur)
	}
	for _, c := range cmds {
		cmd := exec.Command("bash", append([]string{"-lc", "source " + strconv.Quote(file) + "; " + strings.Join(c, " ")})...)
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		_ = cmd.Run()
	}
}

func sortStrings(xs []string) []string { sort.Strings(xs); return xs }
