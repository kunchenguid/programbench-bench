module argcclone

go 1.21
