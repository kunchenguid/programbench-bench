module programbench-gdu

go 1.21
