package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type options struct {
	nonInteractive bool
	noProgress     bool
	summarize      bool
	apparent       bool
	si             bool
	kib            bool
	noPrefix       bool
	reverse        bool
	noHidden       bool
	followSymlink  bool
	showDisks      bool
	version        bool
	help           bool
	writeConfig    bool
	collapse       bool
	depth          int
	top            int
	outputFile     string
	inputFile      string
	logFile        string
	configFile     string
	db             string
	storage        string
	ignoreDirs     []string
	ignorePatterns []string
	ignoreFrom     string
	includeTypes   []string
	excludeTypes   []string
	since          string
	until          string
	minAge         string
	maxAge         string
}

type node struct {
	Name     string
	Path     string
	IsDir    bool
	IsLink   bool
	Empty    bool
	Err      bool
	AppSize  int64
	DiskSize int64
	ModTime  time.Time
	Children []*node
	Count    int
}

func main() {
	opts, args, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	if opts.help {
		printHelp()
		return
	}
	if opts.version {
		printVersion()
		return
	}
	if opts.showDisks {
		printDisks(opts)
		return
	}
	if opts.writeConfig {
		path := opts.configFile
		if path == "" {
			path = filepath.Join(homeDir(), ".gdu.yaml")
		}
		_ = os.WriteFile(path, []byte("no-color: false\n"), 0644)
		return
	}

	var root *node
	if opts.inputFile != "" {
		root, err = readJSON(opts.inputFile)
	} else {
		target := "."
		if len(args) > 0 {
			target = args[0]
		}
		root, err = scanRoot(target, opts)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	if opts.outputFile != "" {
		if err := writeJSON(opts.outputFile, root); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
	}
	if opts.summarize {
		printLine(' ', sizeOf(root, opts), displayName(root, true), opts)
		return
	}
	if opts.depth > 0 {
		printDepth(root, opts)
		return
	}
	if opts.top > 0 {
		printTop(root, opts)
		return
	}
	printChildren(root, opts)
}

func parseArgs(in []string) (options, []string, error) {
	o := options{depth: 0, ignoreDirs: []string{"/proc", "/dev", "/sys", "/run"}, logFile: "/dev/null", storage: "memory"}
	var args []string
	boolLong := map[string]func(){
		"archive-browsing": func() {}, "collapse-path": func() { o.collapse = true },
		"enable-profiling": func() {}, "follow-symlinks": func() { o.followSymlink = true },
		"help": func() { o.help = true }, "mouse": func() {}, "no-color": func() {},
		"no-cross": func() {}, "no-delete": func() {}, "no-hidden": func() { o.noHidden = true },
		"no-prefix": func() { o.noPrefix = true }, "no-progress": func() { o.noProgress = true },
		"no-spawn-shell": func() {}, "no-unicode": func() {}, "non-interactive": func() { o.nonInteractive = true },
		"read-from-storage": func() {}, "reverse-sort": func() { o.reverse = true },
		"sequential": func() {}, "show-annexed-size": func() {}, "show-apparent-size": func() { o.apparent = true },
		"show-disks": func() { o.showDisks = true }, "show-in-kib": func() { o.kib = true },
		"show-item-count": func() {}, "show-mtime": func() {}, "show-relative-size": func() {},
		"shared": func() {}, "si": func() { o.si = true }, "summarize": func() { o.summarize = true },
		"use-git-ignore": func() {}, "version": func() { o.version = true }, "write-config": func() { o.writeConfig = true },
	}
	strLong := map[string]func(string) error{
		"config-file":         func(v string) error { o.configFile = v; return nil },
		"db":                  func(v string) error { o.db = v; return nil },
		"depth":               func(v string) error { n, e := strconv.Atoi(v); o.depth = n; return e },
		"exclude-type":        func(v string) error { o.excludeTypes = splitCSV(v); return nil },
		"ignore-dirs":         func(v string) error { o.ignoreDirs = splitCSV(v); return nil },
		"ignore-dirs-pattern": func(v string) error { o.ignorePatterns = splitCSV(v); return nil },
		"ignore-from":         func(v string) error { o.ignoreFrom = v; return nil },
		"input-file":          func(v string) error { o.inputFile = v; return nil },
		"log-file":            func(v string) error { o.logFile = v; return nil },
		"max-age":             func(v string) error { o.maxAge = v; return nil },
		"max-cores":           func(v string) error { return nil },
		"min-age":             func(v string) error { o.minAge = v; return nil },
		"output-file":         func(v string) error { o.outputFile = v; return nil },
		"since":               func(v string) error { o.since = v; return nil },
		"storage":             func(v string) error { o.storage = v; return nil },
		"style":               func(v string) error { return nil },
		"top":                 func(v string) error { n, e := strconv.Atoi(v); o.top = n; return e },
		"type":                func(v string) error { o.includeTypes = splitCSV(v); return nil },
		"until":               func(v string) error { o.until = v; return nil },
	}
	shortBool := map[rune]func(){
		'L': func() { o.followSymlink = true }, 'h': func() { o.help = true },
		'c': func() {}, 'x': func() {}, 'H': func() { o.noHidden = true },
		'p': func() { o.noProgress = true }, 'u': func() {}, 'n': func() { o.nonInteractive = true },
		'r': func() {}, 'A': func() {}, 'a': func() { o.apparent = true }, 'd': func() { o.showDisks = true },
		'k': func() { o.kib = true }, 'C': func() {}, 'M': func() {}, 'B': func() {}, 'S': func() {},
		's': func() { o.summarize = true }, 'g': func() {}, 'v': func() { o.version = true },
	}
	shortStr := map[rune]func(string) error{
		'D': func(v string) error { o.db = v; return nil }, 'E': func(v string) error { o.excludeTypes = splitCSV(v); return nil },
		'i': func(v string) error { o.ignoreDirs = splitCSV(v); return nil }, 'I': func(v string) error { o.ignorePatterns = splitCSV(v); return nil },
		'X': func(v string) error { o.ignoreFrom = v; return nil }, 'f': func(v string) error { o.inputFile = v; return nil },
		'l': func(v string) error { o.logFile = v; return nil }, 'm': func(v string) error { return nil },
		'o': func(v string) error { o.outputFile = v; return nil }, 't': func(v string) error { n, e := strconv.Atoi(v); o.top = n; return e },
		'T': func(v string) error { o.includeTypes = splitCSV(v); return nil },
	}
	for i := 0; i < len(in); i++ {
		a := in[i]
		if a == "--" {
			args = append(args, in[i+1:]...)
			break
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a[2:], "=")
			if f, ok := boolLong[name]; ok {
				if has {
					return o, args, fmt.Errorf("unknown flag: --%s", name)
				}
				f()
				continue
			}
			if f, ok := strLong[name]; ok {
				if !has {
					i++
					if i >= len(in) {
						return o, args, fmt.Errorf("flag needs an argument: --%s", name)
					}
					val = in[i]
				}
				if err := f(val); err != nil {
					return o, args, err
				}
				continue
			}
			return o, args, fmt.Errorf("unknown flag: --%s", name)
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			rs := []rune(a[1:])
			for j := 0; j < len(rs); j++ {
				ch := rs[j]
				if f, ok := shortBool[ch]; ok {
					f()
					continue
				}
				if f, ok := shortStr[ch]; ok {
					var val string
					if j+1 < len(rs) {
						val = string(rs[j+1:])
						j = len(rs)
					} else {
						i++
						if i >= len(in) {
							return o, args, fmt.Errorf("flag needs an argument: -%c", ch)
						}
						val = in[i]
					}
					if err := f(val); err != nil {
						return o, args, err
					}
					break
				}
				return o, args, fmt.Errorf("unknown shorthand flag: '%c' in -%c", ch, ch)
			}
			continue
		}
		args = append(args, a)
	}
	return o, args, nil
}

func scanRoot(path string, o options) (*node, error) {
	if o.ignoreFrom != "" {
		data, err := os.ReadFile(o.ignoreFrom)
		if err != nil {
			return nil, err
		}
		sc := bufio.NewScanner(strings.NewReader(string(data)))
		for sc.Scan() {
			s := strings.TrimSpace(sc.Text())
			if s != "" && !strings.HasPrefix(s, "#") {
				o.ignorePatterns = append(o.ignorePatterns, s)
			}
		}
	}
	abs, _ := filepath.Abs(path)
	info, err := os.Lstat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("stat %s: no such file or directory", path)
		}
		return nil, err
	}
	return scan(path, abs, info, o, true)
}

func scan(path, abs string, info fs.FileInfo, o options, isRoot bool) (*node, error) {
	if !isRoot && shouldIgnore(path, abs, info, o) {
		return nil, nil
	}
	if !isRoot && !info.IsDir() && !typeOK(info.Name(), o) {
		return nil, nil
	}
	if !isRoot && !info.IsDir() && !mtimeOK(info.ModTime(), o) {
		return nil, nil
	}
	n := &node{Name: info.Name(), Path: abs, IsDir: info.IsDir(), ModTime: info.ModTime(), AppSize: info.Size(), DiskSize: diskUsage(info), Count: 1}
	mode := info.Mode()
	if mode&os.ModeSymlink != 0 {
		n.IsLink = true
		if o.followSymlink {
			if st, err := os.Stat(path); err == nil && !st.IsDir() {
				n.AppSize = st.Size()
				n.DiskSize = diskUsage(st)
			}
		} else {
			n.DiskSize = 0
		}
	}
	if !info.IsDir() {
		return n, nil
	}
	entries, err := os.ReadDir(path)
	if err != nil {
		n.Err = true
		return n, nil
	}
	for _, de := range entries {
		ci, err := os.Lstat(filepath.Join(path, de.Name()))
		if err != nil {
			n.Err = true
			continue
		}
		child, err := scan(filepath.Join(path, de.Name()), filepath.Join(abs, de.Name()), ci, o, false)
		if err == nil && child != nil {
			n.Children = append(n.Children, child)
			n.AppSize += child.AppSize
			n.DiskSize += child.DiskSize
			n.Count += child.Count
			if child.ModTime.After(n.ModTime) {
				n.ModTime = child.ModTime
			}
		}
	}
	n.Empty = len(n.Children) == 0
	sortChildren(n.Children, o)
	return n, nil
}

func shouldIgnore(path, abs string, info fs.FileInfo, o options) bool {
	name := info.Name()
	if o.noHidden && strings.HasPrefix(name, ".") {
		return true
	}
	for _, d := range o.ignoreDirs {
		if d == "" {
			continue
		}
		if filepath.IsAbs(d) {
			if abs == filepath.Clean(d) || strings.HasPrefix(abs, filepath.Clean(d)+string(os.PathSeparator)) {
				return true
			}
		} else if path == d || strings.HasPrefix(path, d+string(os.PathSeparator)) || name == d {
			return true
		}
	}
	for _, p := range o.ignorePatterns {
		if p == "" {
			continue
		}
		if re, err := regexp.Compile(p); err == nil {
			if re.MatchString(abs) || re.MatchString(path) {
				return true
			}
		} else if ok, _ := filepath.Match(p, name); ok {
			return true
		}
	}
	return false
}

func typeOK(name string, o options) bool {
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(name)), ".")
	base := strings.ToLower(name)
	if len(o.includeTypes) > 0 && !containsType(ext, base, o.includeTypes) {
		return false
	}
	if len(o.excludeTypes) > 0 && containsType(ext, base, o.excludeTypes) {
		return false
	}
	return true
}

func containsType(ext, base string, list []string) bool {
	for _, t := range list {
		t = strings.TrimPrefix(strings.ToLower(strings.TrimSpace(t)), ".")
		if t != "" && (t == ext || t == base) {
			return true
		}
	}
	return false
}

func mtimeOK(t time.Time, o options) bool {
	now := time.Now()
	if o.since != "" {
		if st, dateOnly, err := parseWhen(o.since); err == nil {
			if dateOnly {
				y, m, d := t.Date()
				tt := time.Date(y, m, d, 0, 0, 0, 0, st.Location())
				if tt.Before(st) {
					return false
				}
			} else if t.Before(st) {
				return false
			}
		}
	}
	if o.until != "" {
		if ut, dateOnly, err := parseWhen(o.until); err == nil {
			if dateOnly {
				ut = ut.Add(24*time.Hour - time.Nanosecond)
			}
			if t.After(ut) {
				return false
			}
		}
	}
	if o.minAge != "" {
		if d, err := parseDuration(o.minAge); err == nil && now.Sub(t) < d {
			return false
		}
	}
	if o.maxAge != "" {
		if d, err := parseDuration(o.maxAge); err == nil && now.Sub(t) > d {
			return false
		}
	}
	return true
}

func parseWhen(s string) (time.Time, bool, error) {
	if len(s) == 10 && s[4] == '-' && s[7] == '-' {
		t, err := time.ParseInLocation("2006-01-02", s, time.Local)
		return t, true, err
	}
	t, err := time.Parse(time.RFC3339, s)
	return t, false, err
}

func parseDuration(s string) (time.Duration, error) {
	re := regexp.MustCompile(`(?i)(\d+)(y|mo|w|d|h|m|s)`)
	matches := re.FindAllStringSubmatch(s, -1)
	if len(matches) == 0 {
		return time.ParseDuration(s)
	}
	var total time.Duration
	for _, m := range matches {
		n, _ := strconv.Atoi(m[1])
		switch strings.ToLower(m[2]) {
		case "y":
			total += time.Duration(n) * 365 * 24 * time.Hour
		case "mo":
			total += time.Duration(n) * 30 * 24 * time.Hour
		case "w":
			total += time.Duration(n) * 7 * 24 * time.Hour
		case "d":
			total += time.Duration(n) * 24 * time.Hour
		case "h":
			total += time.Duration(n) * time.Hour
		case "m":
			total += time.Duration(n) * time.Minute
		case "s":
			total += time.Duration(n) * time.Second
		}
	}
	return total, nil
}

func diskUsage(info fs.FileInfo) int64 {
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		return st.Blocks * 512
	}
	return info.Size()
}

func sortChildren(ch []*node, o options) {
	sort.SliceStable(ch, func(i, j int) bool {
		ri, rj := sortRank(ch[i]), sortRank(ch[j])
		if ri != rj {
			return ri < rj
		}
		if sizeOf(ch[i], o) == sizeOf(ch[j], o) {
			if ch[i].IsDir != ch[j].IsDir {
				return ch[i].IsDir
			}
			return strings.ToLower(ch[i].Name) > strings.ToLower(ch[j].Name)
		}
		return sizeOf(ch[i], o) > sizeOf(ch[j], o)
	})
	if o.reverse {
		for i, j := 0, len(ch)-1; i < j; i, j = i+1, j-1 {
			ch[i], ch[j] = ch[j], ch[i]
		}
	}
}

func sortRank(n *node) int {
	if n.IsLink {
		return 2
	}
	if strings.HasPrefix(n.Name, ".") {
		return 1
	}
	return 0
}

func sizeOf(n *node, o options) int64 {
	if o.apparent {
		return n.AppSize
	}
	return n.DiskSize
}

func printChildren(root *node, o options) {
	for _, c := range root.Children {
		printLine(flag(c), sizeOf(c, o), childName(c), o)
	}
}

func printDepth(root *node, o options) {
	var walk func(*node, int)
	walk = func(n *node, d int) {
		printLine(' ', sizeOf(n, o), n.Path, o)
		if d >= o.depth {
			return
		}
		for _, c := range n.Children {
			walk(c, d+1)
		}
	}
	walk(root, 0)
}

func printTop(root *node, o options) {
	var all []*node
	var walk func(*node)
	walk = func(n *node) {
		if !n.IsDir {
			all = append(all, n)
		}
		for _, c := range n.Children {
			walk(c)
		}
	}
	walk(root)
	sort.SliceStable(all, func(i, j int) bool {
		if sizeOf(all[i], o) == sizeOf(all[j], o) {
			return all[i].Path < all[j].Path
		}
		return sizeOf(all[i], o) > sizeOf(all[j], o)
	})
	limit := o.top
	if limit > len(all) {
		limit = len(all)
	}
	for i := 0; i < limit; i++ {
		printLine(' ', sizeOf(all[i], o), all[i].Path, o)
	}
}

func flag(n *node) rune {
	if n.Err {
		return '!'
	}
	if n.IsLink {
		return '@'
	}
	if n.IsDir && n.Empty {
		return 'e'
	}
	return ' '
}

func childName(n *node) string {
	if n.IsDir {
		return "/" + n.Name
	}
	return n.Name
}

func displayName(n *node, summary bool) string {
	if summary {
		if n.Name != "" && n.Name != "." && n.Name != string(os.PathSeparator) {
			return n.Name
		}
	}
	return n.Path
}

func printLine(f rune, sz int64, name string, o options) {
	if o.noPrefix {
		fmt.Printf("%c%10d %s\n", f, sz, name)
		return
	}
	fmt.Printf("%c%10s %s\n", f, formatSize(sz, o), name)
}

func formatSize(n int64, o options) string {
	if o.kib {
		div := 1024.0
		if o.si {
			div = 1000.0
		}
		unit := "KiB"
		if o.si {
			unit = "kB"
		}
		return fmt.Sprintf("%.1f %s", float64(n)/div, unit)
	}
	base := 1024.0
	units := []string{"B", "KiB", "MiB", "GiB", "TiB", "PiB"}
	if o.si {
		base = 1000
		units = []string{"B", "kB", "MB", "GB", "TB", "PB"}
	}
	v := float64(n)
	idx := 0
	for math.Abs(v) >= base && idx < len(units)-1 {
		v /= base
		idx++
	}
	if idx == 0 {
		return fmt.Sprintf("%d %s", n, units[idx])
	}
	return fmt.Sprintf("%.1f %s", v, units[idx])
}

func splitCSV(s string) []string {
	if s == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func printVersion() {
	fmt.Println("Version:\t dev")
	fmt.Println("Built time:\t Fri Apr 17 19:59:35 UTC 2026")
	fmt.Println("Built user:\t root")
}

func printHelp() {
	cores := 1
	if n := os.Getenv("GOMAXPROCS"); n != "" {
		if v, err := strconv.Atoi(n); err == nil {
			cores = v
		}
	} else {
		cores = 14
	}
	fmt.Println(`Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")`)
	fmt.Printf("  -m, --max-cores int                 Set max cores that Gdu will use. %d cores available (default %d)\n", cores, cores)
	fmt.Println(`      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file (default is $HOME/.gdu.yaml)`)
}

func printDisks(o options) {
	fmt.Println("   Device      Size      Used      Free Used% Mount point")
	data, err := os.ReadFile("/proc/mounts")
	if err != nil {
		return
	}
	seen := map[string]bool{}
	sc := bufio.NewScanner(strings.NewReader(string(data)))
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) < 2 || !strings.HasPrefix(fields[0], "/dev/") {
			continue
		}
		key := fields[0] + " " + fields[1]
		if seen[key] {
			continue
		}
		seen[key] = true
		var st syscall.Statfs_t
		if syscall.Statfs(fields[1], &st) != nil {
			continue
		}
		total := int64(st.Blocks) * int64(st.Bsize)
		free := int64(st.Bavail) * int64(st.Bsize)
		used := total - free
		pct := 0
		if total > 0 {
			pct = int(float64(used) * 100 / float64(total))
		}
		fmt.Printf("%-8s %9s %9s %9s %4d%% %s\n", fields[0], formatSize(total, o), formatSize(used, o), formatSize(free, o), pct, fields[1])
	}
}

func writeJSON(path string, root *node) error {
	doc := []any{1, 2, map[string]any{"progname": "gdu", "progver": "dev", "timestamp": time.Now().Unix()}, encodeNode(root, true)}
	b, err := json.Marshal(doc)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0644)
}

func encodeNode(n *node, root bool) any {
	m := map[string]any{"name": n.Name, "mtime": n.ModTime.Unix()}
	if root {
		m["name"] = n.Path
	}
	if n.AppSize != 0 {
		m["asize"] = n.AppSize
	}
	if n.DiskSize != 0 {
		m["dsize"] = n.DiskSize
	}
	if n.IsLink {
		m["notreg"] = true
	}
	arr := []any{m}
	for _, c := range n.Children {
		arr = append(arr, encodeNode(c, false))
	}
	return arr
}

func readJSON(path string) (*node, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var raw any
	if err := json.Unmarshal(b, &raw); err != nil {
		return nil, err
	}
	arr, ok := raw.([]any)
	if !ok || len(arr) < 4 {
		return nil, errors.New("invalid JSON format")
	}
	return decodeNode(arr[3], "", true)
}

func decodeNode(v any, parent string, root bool) (*node, error) {
	arr, ok := v.([]any)
	if !ok || len(arr) == 0 {
		return nil, errors.New("invalid node")
	}
	m, ok := arr[0].(map[string]any)
	if !ok {
		return nil, errors.New("invalid node metadata")
	}
	name, _ := m["name"].(string)
	p := name
	if !root && parent != "" {
		p = filepath.Join(parent, name)
	}
	n := &node{Name: name, Path: p, IsDir: len(arr) > 1}
	if root {
		n.Name = filepath.Base(name)
		n.Path = name
	}
	if f, ok := m["asize"].(float64); ok {
		n.AppSize = int64(f)
	}
	if f, ok := m["dsize"].(float64); ok {
		n.DiskSize = int64(f)
	}
	if f, ok := m["mtime"].(float64); ok {
		n.ModTime = time.Unix(int64(f), 0)
	}
	if b, ok := m["notreg"].(bool); ok && b {
		n.IsLink = true
	}
	for _, cv := range arr[1:] {
		c, err := decodeNode(cv, n.Path, false)
		if err != nil {
			return nil, err
		}
		n.Children = append(n.Children, c)
	}
	n.Empty = n.IsDir && len(n.Children) == 0
	return n, nil
}

func homeDir() string {
	if h, err := os.UserHomeDir(); err == nil {
		return h
	}
	return "."
}
