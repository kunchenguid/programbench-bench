package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"
)

const zeroTime = "0001-01-01T00:00:00Z"

type Task struct {
	UUID     string   `json:"uuid"`
	Status   string   `json:"status"`
	ID       int      `json:"id"`
	Summary  string   `json:"summary"`
	Notes    string   `json:"notes"`
	Tags     []string `json:"tags"`
	Project  string   `json:"project"`
	Priority string   `json:"priority"`
	Created  string   `json:"created"`
	Resolved string   `json:"resolved"`
	Due      string   `json:"due"`
	Path     string   `json:"-"`
}

type idState struct {
	Next int            `json:"next"`
	IDs  map[string]int `json:"ids"`
}

type parsedArgs struct {
	IDs           []int
	Cmd           string
	Rest          []string
	IgnoreContext bool
}

func main() {
	repo, err := ensureRepo()
	if err != nil {
		die(err.Error())
	}
	args := os.Args[1:]
	if len(args) == 1 && (args[0] == "--help" || args[0] == "help") {
		printHelp()
		return
	}
	if len(args) > 0 && args[0] == "help" {
		if len(args) > 1 {
			printCmdHelp(args[1])
		} else {
			printHelp()
		}
		return
	}
	if len(args) == 1 && args[0] == "version" {
		fmt.Println("Version: Unknown")
		fmt.Println("Git commit: Unknown")
		fmt.Println("Build date: Unknown")
		return
	}
	pa := parseCLI(args)
	if pa.Cmd == "" {
		pa.Cmd = "next"
	}
	if err := run(repo, pa); err != nil {
		die(err.Error())
	}
}

func run(repo string, pa parsedArgs) error {
	switch pa.Cmd {
	case "add", "template", "log":
		return addTask(repo, pa.Cmd, pa.Rest, pa.IgnoreContext)
	case "next", "show-open", "show-active", "show-paused", "show-resolved", "show-templates", "show-unorganised":
		return show(repo, pa)
	case "start":
		return setStatus(repo, pa, "active", "Started")
	case "stop":
		return setStatus(repo, pa, "paused", "Stopped")
	case "done":
		return setStatus(repo, pa, "resolved", "Resolved")
	case "remove":
		return removeTasks(repo, pa)
	case "modify":
		return modifyTasks(repo, pa)
	case "context":
		return contextCmd(repo, pa.Rest)
	case "show-tags", "tags":
		return showTags(repo, pa)
	case "show-projects", "projects":
		return showProjects(repo, pa)
	case "git":
		return gitPassthrough(repo, pa.Rest)
	case "sync":
		if err := gitPassthrough(repo, []string{"pull"}); err != nil {
			return err
		}
		return gitPassthrough(repo, []string{"push"})
	case "undo":
		n := "1"
		if len(pa.Rest) > 0 {
			n = pa.Rest[0]
		}
		return gitPassthrough(repo, []string{"reset", "--hard", "HEAD~" + n})
	case "bash-completion", "zsh-completion", "fish-completion", "powershell-completion":
		fmt.Println("# dstask completion placeholder")
		return nil
	case "note", "edit", "open":
		return noteEditOpen(repo, pa)
	default:
		if isInt(pa.Cmd) {
			id, _ := strconv.Atoi(pa.Cmd)
			pa.IDs = append([]int{id}, pa.IDs...)
			pa.Cmd = "next"
			return show(repo, pa)
		}
		return fmt.Errorf("unknown command: %s", pa.Cmd)
	}
}

func parseCLI(args []string) parsedArgs {
	var pa parsedArgs
	commands := map[string]bool{
		"next": true, "add": true, "template": true, "log": true, "start": true, "note": true,
		"stop": true, "done": true, "context": true, "modify": true, "edit": true, "undo": true,
		"sync": true, "open": true, "git": true, "remove": true, "show-projects": true,
		"show-tags": true, "show-active": true, "show-paused": true, "show-open": true,
		"show-resolved": true, "show-templates": true, "show-unorganised": true,
		"bash-completion": true, "fish-completion": true, "zsh-completion": true,
		"powershell-completion": true, "tags": true, "projects": true,
	}
	for i, a := range args {
		if a == "--" {
			pa.IgnoreContext = true
			continue
		}
		if commands[a] && pa.Cmd == "" {
			pa.Cmd = a
			pa.Rest = append(pa.Rest, args[i+1:]...)
			return cleanDashes(pa)
		}
		if pa.Cmd == "" && isInt(a) {
			id, _ := strconv.Atoi(a)
			pa.IDs = append(pa.IDs, id)
			continue
		}
		if pa.Cmd == "" && strings.Contains(a, ",") {
			allNum := true
			for _, p := range strings.Split(a, ",") {
				if !isInt(p) {
					allNum = false
				}
			}
			if allNum {
				for _, p := range strings.Split(a, ",") {
					id, _ := strconv.Atoi(p)
					pa.IDs = append(pa.IDs, id)
				}
				continue
			}
		}
		if pa.Cmd == "" {
			pa.Cmd = a
			pa.Rest = append(pa.Rest, args[i+1:]...)
			return cleanDashes(pa)
		}
	}
	return cleanDashes(pa)
}

func cleanDashes(pa parsedArgs) parsedArgs {
	out := pa.Rest[:0]
	for _, a := range pa.Rest {
		if a == "--" {
			pa.IgnoreContext = true
		} else {
			out = append(out, a)
		}
	}
	pa.Rest = out
	return pa
}

func ensureRepo() (string, error) {
	repo := os.Getenv("DSTASK_GIT_REPO")
	if repo == "" {
		home, _ := os.UserHomeDir()
		repo = filepath.Join(home, ".dstask")
	}
	if err := os.MkdirAll(repo, 0755); err != nil {
		return "", err
	}
	if _, err := os.Stat(filepath.Join(repo, ".git")); os.IsNotExist(err) {
		cmd := exec.Command("git", "-C", repo, "init")
		cmd.Stdout, cmd.Stderr = os.Stdout, os.Stderr
		_ = cmd.Run()
		fmt.Println()
		fmt.Println("Add a remote repository with:")
		fmt.Println()
		fmt.Println("\tdstask git remote add origin <repo>")
		fmt.Println()
	}
	for _, d := range []string{"pending", "active", "paused", "resolved", "template"} {
		_ = os.MkdirAll(filepath.Join(repo, d), 0755)
	}
	_ = os.MkdirAll(filepath.Join(repo, ".git", "dstask-go"), 0755)
	return repo, nil
}

func addTask(repo, kind string, words []string, ignoreCtx bool) error {
	if len(words) == 0 {
		if kind == "template" {
			return errors.New("task description or template required")
		}
		return errors.New("task description required")
	}
	t := Task{UUID: newUUID(), Status: "pending", Priority: "P2", Created: time.Now().UTC().Format(time.RFC3339Nano), Resolved: zeroTime, Due: zeroTime, Tags: []string{}}
	if kind == "template" {
		t.Status = "template"
	}
	if kind == "log" {
		t.Status = "resolved"
		t.Resolved = time.Now().UTC().Format(time.RFC3339Nano)
	}
	if !ignoreCtx {
		applyContext(repo, &t)
	}
	if err := parseWords(&t, words, true); err != nil {
		return err
	}
	if strings.TrimSpace(t.Summary) == "" {
		return errors.New("task description required")
	}
	st := loadIDs(repo)
	t.ID = st.Next
	if t.ID <= 0 {
		t.ID = 1
	}
	st.Next = t.ID + 1
	st.IDs[t.UUID] = t.ID
	if err := saveTask(repo, &t); err != nil {
		return err
	}
	saveIDs(repo, st)
	verb := "Added"
	if kind == "template" {
		verb = "Created Template"
	}
	if kind == "log" {
		verb = "Logged"
	}
	fmt.Printf("\n%s %d: %s\n", verb, t.ID, t.Summary)
	commit(repo, fmt.Sprintf("%s %d: %s", verb, t.ID, t.Summary))
	return nil
}

func parseWords(t *Task, words []string, allowSlash bool) error {
	var summary, notes []string
	inNote := false
	for _, w := range words {
		if allowSlash && w == "/" {
			inNote = true
			continue
		}
		if inNote {
			notes = append(notes, w)
			continue
		}
		switch {
		case strings.HasPrefix(w, "+") && len(w) > 1:
			addTag(t, w[1:])
		case strings.HasPrefix(w, "-") && len(w) > 1:
			removeTag(t, w[1:])
		case strings.HasPrefix(w, "project:"):
			t.Project = strings.TrimPrefix(w, "project:")
		case strings.HasPrefix(w, "due:"):
			d, ok := parseDate(strings.TrimPrefix(w, "due:"))
			if ok {
				t.Due = d
			} else {
				return fmt.Errorf("Invalid due date format: %s\nExpected format: YYYY-MM-DD, MM-DD or DD, relative date like 'next-monday', 'today', etc.", strings.TrimPrefix(w, "due:"))
			}
		case isPriority(w):
			t.Priority = strings.ToUpper(w)
		default:
			summary = append(summary, w)
		}
	}
	if len(summary) > 0 {
		t.Summary = strings.Join(summary, " ")
	}
	if len(notes) > 0 {
		t.Notes = strings.Join(notes, " ")
	}
	sort.Strings(t.Tags)
	return nil
}

func parseDate(s string) (string, bool) {
	now := time.Now()
	if s == "today" {
		return dateOnly(now), true
	}
	if s == "tomorrow" {
		return dateOnly(now.AddDate(0, 0, 1)), true
	}
	layouts := []string{"2006-01-02", "01-02", "02"}
	for _, l := range layouts {
		if tm, err := time.Parse(l, s); err == nil {
			y := now.Year()
			m := tm.Month()
			d := tm.Day()
			if l == "2006-01-02" {
				y = tm.Year()
			}
			if l == "02" {
				m = now.Month()
			}
			return time.Date(y, m, d, 0, 0, 0, 0, time.UTC).Format(time.RFC3339), true
		}
	}
	return zeroTime, false
}

func dateOnly(t time.Time) string {
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, time.UTC).Format(time.RFC3339)
}

func show(repo string, pa parsedArgs) error {
	tasks := loadTasks(repo)
	status := map[string]string{"show-active": "active", "show-paused": "paused", "show-resolved": "resolved", "show-templates": "template"}[pa.Cmd]
	out := []Task{}
	for _, t := range tasks {
		if len(pa.IDs) > 0 && !containsID(pa.IDs, t.ID) {
			continue
		}
		if status != "" && t.Status != status {
			continue
		}
		if (pa.Cmd == "next" || pa.Cmd == "show-open" || pa.Cmd == "") && (t.Status == "resolved" || t.Status == "template") {
			continue
		}
		if pa.Cmd == "show-unorganised" && (len(t.Tags) > 0 || t.Project != "" || t.Status == "resolved") {
			continue
		}
		if !pa.IgnoreContext && len(pa.IDs) == 0 && !matchContext(repo, t) {
			continue
		}
		if !matchFilters(t, pa.Rest) {
			continue
		}
		if t.Status == "resolved" {
			t.ID = 0
		}
		out = append(out, t)
	}
	sortTasks(out)
	return printJSON(out)
}

func matchFilters(t Task, filters []string) bool {
	for _, f := range filters {
		switch {
		case strings.HasPrefix(f, "+"):
			if !hasTag(t, f[1:]) {
				return false
			}
		case strings.HasPrefix(f, "-"):
			if hasTag(t, f[1:]) {
				return false
			}
		case strings.HasPrefix(f, "project:"):
			if t.Project != strings.TrimPrefix(f, "project:") {
				return false
			}
		case isPriority(f):
			if t.Priority != strings.ToUpper(f) {
				return false
			}
		default:
			q := strings.ToLower(f)
			if !strings.Contains(strings.ToLower(t.Summary), q) && !strings.Contains(strings.ToLower(t.Notes), q) {
				return false
			}
		}
	}
	return true
}

func setStatus(repo string, pa parsedArgs, status, verb string) error {
	targets := selectTasks(repo, pa)
	if len(targets) == 0 {
		return errors.New("No tasks found")
	}
	for _, t := range targets {
		old := t.Path
		t.Status = status
		if status == "resolved" {
			t.Resolved = time.Now().UTC().Format(time.RFC3339Nano)
		}
		_ = os.Remove(old)
		if err := saveTask(repo, &t); err != nil {
			return err
		}
		fmt.Printf("\n%s %d: %s\n", verb, t.ID, t.Summary)
		commit(repo, fmt.Sprintf("%s %d: %s", verb, t.ID, t.Summary))
	}
	return nil
}

func removeTasks(repo string, pa parsedArgs) error {
	targets := selectTasks(repo, pa)
	if len(targets) == 0 {
		return errors.New("No tasks found")
	}
	for _, t := range targets {
		fmt.Printf("%d: %s\n\nRemoved: %d: %s\n", t.ID, t.Summary, t.ID, t.Summary)
		_ = os.Remove(t.Path)
		commit(repo, fmt.Sprintf("Removed: %d: %s", t.ID, t.Summary))
	}
	return nil
}

func modifyTasks(repo string, pa parsedArgs) error {
	targets := selectTasks(repo, pa)
	if len(targets) == 0 {
		return errors.New("No tasks found")
	}
	for _, t := range targets {
		if err := parseWords(&t, pa.Rest, true); err != nil {
			return err
		}
		if err := saveTask(repo, &t); err != nil {
			return err
		}
		fmt.Printf("\nModified %d: %s\n", t.ID, t.Summary)
		commit(repo, fmt.Sprintf("Modified %d: %s", t.ID, t.Summary))
	}
	return nil
}

func noteEditOpen(repo string, pa parsedArgs) error {
	targets := selectTasks(repo, pa)
	if len(targets) == 0 {
		return errors.New("No tasks found")
	}
	if pa.Cmd == "note" && len(pa.Rest) > 0 {
		for _, t := range targets {
			if t.Notes == "" {
				t.Notes = strings.Join(pa.Rest, " ")
			} else {
				t.Notes += "\n" + strings.Join(pa.Rest, " ")
			}
			if err := saveTask(repo, &t); err != nil {
				return err
			}
			fmt.Printf("\nNoted %d: %s\n", t.ID, t.Summary)
		}
		return nil
	}
	for _, t := range targets {
		printJSON([]Task{t})
	}
	return nil
}

func selectTasks(repo string, pa parsedArgs) []Task {
	tasks := loadTasks(repo)
	out := []Task{}
	for _, t := range tasks {
		if len(pa.IDs) > 0 {
			if containsID(pa.IDs, t.ID) {
				out = append(out, t)
			}
			continue
		}
		if t.Status != "resolved" && matchFilters(t, pa.Rest) && (pa.IgnoreContext || matchContext(repo, t)) {
			out = append(out, t)
		}
	}
	sortTasks(out)
	return out
}

func contextCmd(repo string, args []string) error {
	path := filepath.Join(repo, ".git", "dstask-go", "context")
	if len(args) == 0 {
		b, _ := os.ReadFile(path)
		fmt.Println(strings.TrimSpace(string(b)))
		return nil
	}
	if len(args) == 1 && (args[0] == "none" || args[0] == "--") {
		_ = os.Remove(path)
		return nil
	}
	for _, a := range args {
		if !strings.HasPrefix(a, "+") && !strings.HasPrefix(a, "-") && !strings.HasPrefix(a, "project:") && !isPriority(a) {
			return errors.New("context cannot contain text")
		}
	}
	return os.WriteFile(path, []byte(strings.Join(args, " ")), 0644)
}

func applyContext(repo string, t *Task) {
	b, _ := os.ReadFile(filepath.Join(repo, ".git", "dstask-go", "context"))
	for _, f := range strings.Fields(string(b)) {
		if strings.HasPrefix(f, "+") {
			addTag(t, f[1:])
		} else if strings.HasPrefix(f, "project:") {
			t.Project = strings.TrimPrefix(f, "project:")
		} else if isPriority(f) {
			t.Priority = strings.ToUpper(f)
		}
	}
}

func matchContext(repo string, t Task) bool {
	b, _ := os.ReadFile(filepath.Join(repo, ".git", "dstask-go", "context"))
	return matchFilters(t, strings.Fields(string(b)))
}

func showTags(repo string, pa parsedArgs) error {
	seen := map[string]bool{}
	for _, t := range loadTasks(repo) {
		if t.Status == "resolved" || (!pa.IgnoreContext && !matchContext(repo, t)) {
			continue
		}
		for _, tag := range t.Tags {
			seen[tag] = true
		}
	}
	var tags []string
	for tag := range seen {
		tags = append(tags, tag)
	}
	sort.Strings(tags)
	for _, tag := range tags {
		fmt.Println(tag)
	}
	return nil
}

type Project struct {
	Name          string `json:"name"`
	TaskCount     int    `json:"taskCount"`
	ResolvedCount int    `json:"resolvedCount"`
	Active        bool   `json:"active"`
	Created       string `json:"created"`
	Resolved      string `json:"resolved"`
	Priority      string `json:"priority"`
}

func showProjects(repo string, pa parsedArgs) error {
	m := map[string]*Project{}
	for _, t := range loadTasks(repo) {
		if t.Project == "" || (!pa.IgnoreContext && !matchContext(repo, t)) {
			continue
		}
		p := m[t.Project]
		if p == nil {
			p = &Project{Name: t.Project, Created: t.Created, Resolved: zeroTime, Priority: t.Priority}
			m[t.Project] = p
		}
		p.TaskCount++
		if t.Status == "resolved" {
			p.ResolvedCount++
			p.Resolved = t.Resolved
		}
		if t.Status == "active" {
			p.Active = true
		}
		if prioRank(t.Priority) < prioRank(p.Priority) {
			p.Priority = t.Priority
		}
		if t.Created < p.Created {
			p.Created = t.Created
		}
	}
	out := []Project{}
	for _, p := range m {
		out = append(out, *p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return printJSON(out)
}

func gitPassthrough(repo string, args []string) error {
	cmd := exec.Command("git", append([]string{"-C", repo}, args...)...)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := cmd.Run(); err != nil {
		return errors.New("Failed to run git cmd.")
	}
	return nil
}

func commit(repo, msg string) {
	_ = exec.Command("git", "-C", repo, "add", "-A").Run()
	cmd := exec.Command("git", "-C", repo, "commit", "-m", msg)
	out, err := cmd.CombinedOutput()
	if len(out) > 0 {
		fmt.Print(string(out))
	}
	if err != nil {
		// The reference reports commit failures, but keeping the data written is more useful.
		return
	}
}

func loadTasks(repo string) []Task {
	tasks := []Task{}
	statuses := map[string]string{"pending": "pending", "active": "active", "paused": "paused", "resolved": "resolved", "template": "template", "templates": "template"}
	for dir, st := range statuses {
		files, _ := filepath.Glob(filepath.Join(repo, dir, "*.yml"))
		for _, f := range files {
			t, err := readTask(f, st)
			if err == nil {
				tasks = append(tasks, t)
			}
		}
	}
	ids := loadIDs(repo)
	changed := false
	for i := range tasks {
		if ids.IDs[tasks[i].UUID] == 0 && tasks[i].Status != "resolved" {
			ids.IDs[tasks[i].UUID] = ids.Next
			tasks[i].ID = ids.Next
			ids.Next++
			changed = true
		} else {
			tasks[i].ID = ids.IDs[tasks[i].UUID]
		}
	}
	if changed {
		saveIDs(repo, ids)
	}
	return tasks
}

func readTask(path, status string) (Task, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Task{}, err
	}
	t := Task{UUID: strings.TrimSuffix(filepath.Base(path), ".yml"), Status: status, Priority: "P2", Resolved: zeroTime, Due: zeroTime, Path: path, Tags: []string{}}
	lines := strings.Split(string(b), "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(lines[i])
		if line == "" {
			continue
		}
		if line == "tags:" {
			for i+1 < len(lines) && strings.HasPrefix(strings.TrimSpace(lines[i+1]), "- ") {
				i++
				t.Tags = append(t.Tags, unquote(strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(lines[i]), "- "))))
			}
			continue
		}
		k, v, ok := strings.Cut(line, ":")
		if !ok {
			continue
		}
		v = strings.TrimSpace(v)
		switch k {
		case "summary":
			t.Summary = unquote(v)
		case "notes":
			t.Notes = unquote(v)
		case "project":
			t.Project = unquote(v)
		case "priority":
			t.Priority = unquote(v)
		case "created":
			t.Created = unquote(v)
		case "resolved":
			t.Resolved = unquote(v)
		case "due":
			t.Due = unquote(v)
		}
	}
	if t.Created == "" {
		t.Created = time.Now().UTC().Format(time.RFC3339Nano)
	}
	return t, nil
}

func saveTask(repo string, t *Task) error {
	dir := t.Status
	if dir == "template" {
		dir = "template"
	}
	if dir == "" {
		dir = "pending"
	}
	if err := os.MkdirAll(filepath.Join(repo, dir), 0755); err != nil {
		return err
	}
	t.Path = filepath.Join(repo, dir, t.UUID+".yml")
	var sb strings.Builder
	fmt.Fprintf(&sb, "summary: %s\n", yamlScalar(t.Summary))
	fmt.Fprintf(&sb, "notes: %s\n", yamlScalar(t.Notes))
	sb.WriteString("tags:\n")
	for _, tag := range t.Tags {
		fmt.Fprintf(&sb, "- %s\n", yamlScalar(tag))
	}
	fmt.Fprintf(&sb, "project: %s\n", yamlScalar(t.Project))
	fmt.Fprintf(&sb, "priority: %s\n", t.Priority)
	sb.WriteString("delegatedto: \"\"\nsubtasks: []\ndependencies: []\n")
	fmt.Fprintf(&sb, "created: %s\nresolved: %s\ndue: %s\n", t.Created, t.Resolved, t.Due)
	return os.WriteFile(t.Path, []byte(sb.String()), 0644)
}

func loadIDs(repo string) idState {
	st := idState{Next: 1, IDs: map[string]int{}}
	b, err := os.ReadFile(filepath.Join(repo, ".git", "dstask-go", "ids.json"))
	if err == nil {
		_ = json.Unmarshal(b, &st)
	}
	if st.Next <= 0 {
		st.Next = 1
	}
	if st.IDs == nil {
		st.IDs = map[string]int{}
	}
	return st
}

func saveIDs(repo string, st idState) {
	b, _ := json.MarshalIndent(st, "", "  ")
	_ = os.MkdirAll(filepath.Join(repo, ".git", "dstask-go"), 0755)
	_ = os.WriteFile(filepath.Join(repo, ".git", "dstask-go", "ids.json"), b, 0644)
}

func printJSON(v any) error {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	fmt.Println(string(b))
	return nil
}

func sortTasks(tasks []Task) {
	sort.SliceStable(tasks, func(i, j int) bool {
		if prioRank(tasks[i].Priority) != prioRank(tasks[j].Priority) {
			return prioRank(tasks[i].Priority) < prioRank(tasks[j].Priority)
		}
		if tasks[i].Created != tasks[j].Created {
			return tasks[i].Created < tasks[j].Created
		}
		return tasks[i].UUID < tasks[j].UUID
	})
}

func prioRank(p string) int {
	switch strings.ToUpper(p) {
	case "P0":
		return 0
	case "P1":
		return 1
	case "P2", "":
		return 2
	case "P3":
		return 3
	default:
		return 2
	}
}

func addTag(t *Task, tag string) {
	if tag == "" || hasTag(*t, tag) {
		return
	}
	t.Tags = append(t.Tags, tag)
}

func removeTag(t *Task, tag string) {
	var out []string
	for _, x := range t.Tags {
		if x != tag {
			out = append(out, x)
		}
	}
	t.Tags = out
}

func hasTag(t Task, tag string) bool {
	for _, x := range t.Tags {
		if x == tag {
			return true
		}
	}
	return false
}

func containsID(ids []int, id int) bool {
	for _, x := range ids {
		if x == id {
			return true
		}
	}
	return false
}

func isPriority(s string) bool {
	s = strings.ToUpper(s)
	return s == "P0" || s == "P1" || s == "P2" || s == "P3"
}

func isInt(s string) bool {
	_, err := strconv.Atoi(s)
	return err == nil
}

func newUUID() string {
	var b [16]byte
	if _, err := rand.Read(b[:]); err != nil {
		return fmt.Sprintf("%d", time.Now().UnixNano())
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	h := hex.EncodeToString(b[:])
	return h[0:8] + "-" + h[8:12] + "-" + h[12:16] + "-" + h[16:20] + "-" + h[20:32]
}

func yamlScalar(s string) string {
	if s == "" {
		return "\"\""
	}
	if strings.ContainsAny(s, ":#\n\"'[]{}") || strings.HasPrefix(s, " ") || strings.HasSuffix(s, " ") {
		return strconv.Quote(s)
	}
	return s
}

func unquote(s string) string {
	if s == "\"\"" {
		return ""
	}
	if len(s) >= 2 && s[0] == '"' && s[len(s)-1] == '"' {
		if q, err := strconv.Unquote(s); err == nil {
			return q
		}
	}
	return s
}

func die(msg string) {
	fmt.Fprintln(os.Stderr, msg)
	os.Exit(1)
}

func printHelp() {
	fmt.Println(`Usage: dstask [id...] <cmd> [task summary/filter]

Where [task summary] is text with tags/project/priority specified. Tags are
specified with + (or - for filtering) eg: +work. The project is specified with
a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
(low), P2 (default) to P1 (high) and P0 (critical). Text can also be specified
for a substring search of description and notes.

Cmd and IDs can be swapped, multiple IDs can be specified for batch
operations.

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
edit              : Edit task with text editor
undo              : Undo last n commits
sync              : Pull then push to git repository, automatic merge commit.
open              : Open all URLs found in summary/annotations
git               : Pass a command to git in the repository. Used for push/pull.
remove            : Remove a task (use to remove tasks added by mistake)
show-projects     : List projects with completion status
show-tags         : List tags in use
show-active       : Show tasks that have been started
show-paused       : Show tasks that have been started then stopped
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
show-templates    : Show task templates
show-unorganised  : Show untagged tasks with no projects (global context)
bash-completion   : Print bash completion script to stdout
fish-completion   : Print fish completion script to stdout
zsh-completion    : Print zsh completion script to stdout
help              : Get help on any command or show this message
version           : Show dstask version information`)
}

func printCmdHelp(cmd string) {
	switch cmd {
	case "undo":
		fmt.Println(`Usage: dstask undo
Usage: dstask undo <n>

Undo the last <n> commits on the repository. Default is 1.`)
	default:
		fmt.Printf("Usage: dstask %s\n", cmd)
	}
}
