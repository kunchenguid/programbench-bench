module mini-jq

go 1.21
