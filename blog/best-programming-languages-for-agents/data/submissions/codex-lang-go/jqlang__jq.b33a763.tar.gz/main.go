package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

type J interface{}
type Pair struct {
	K string
	V J
}
type OMap []Pair

type Config struct {
	nullInput, rawInput, slurp bool
	compact, rawOut, joinOut   bool
	ascii, sortKeys            bool
	indent                     string
	exitStatus                 bool
	vars                       map[string]J
	args                       []J
}

func main() {
	cfg := Config{indent: "  ", vars: map[string]J{}}
	filter, files, err := parseArgs(os.Args[1:], &cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, "jq:", err)
		os.Exit(2)
	}
	if filter == "" {
		filter = "."
	}
	if filter == "__help__" {
		printHelp()
		return
	}
	if filter == "__version__" {
		fmt.Println("jq-build-2b77eb1")
		return
	}
	if filter == "__build__" {
		fmt.Println("--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local")
		return
	}
	cfg.vars["ARGS"] = map[string]J{"positional": cfg.args, "named": cfg.vars}
	ast, err := NewParser(filter).Parse()
	if err != nil {
		fmt.Fprintf(os.Stderr, "jq: error: %v\n", err)
		os.Exit(3)
	}
	inputs, err := readInputs(files, cfg)
	if err != nil {
		fmt.Fprintln(os.Stderr, "jq:", err)
		os.Exit(2)
	}
	if cfg.slurp {
		if cfg.rawInput {
			var ss []string
			for _, v := range inputs {
				ss = append(ss, toString(v))
			}
			inputs = []J{ss}
		} else {
			inputs = []J{inputs}
		}
	}
	if cfg.nullInput {
		inputs = []J{nil}
	}
	anyOut, lastTruthy := false, false
	for _, in := range inputs {
		outs, err := ast.Eval(in, &cfg)
		if err != nil {
			fmt.Fprintf(os.Stderr, "jq: error: %v\n", err)
			os.Exit(5)
		}
		for _, out := range outs {
			anyOut = true
			lastTruthy = truthy(out)
			writeOutput(os.Stdout, out, cfg)
		}
	}
	if cfg.exitStatus {
		if !anyOut {
			os.Exit(4)
		}
		if !lastTruthy {
			os.Exit(1)
		}
	}
}

func parseArgs(args []string, cfg *Config) (string, []string, error) {
	var filter string
	var files []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--help":
			return "__help__", nil, nil
		case "-V", "--version":
			return "__version__", nil, nil
		case "--build-configuration":
			return "__build__", nil, nil
		case "-n", "--null-input":
			cfg.nullInput = true
		case "-R", "--raw-input":
			cfg.rawInput = true
		case "-s", "--slurp":
			cfg.slurp = true
		case "-c", "--compact-output":
			cfg.compact = true
		case "-r", "--raw-output":
			cfg.rawOut = true
		case "--raw-output0":
			cfg.rawOut, cfg.joinOut = true, true
		case "-j", "--join-output":
			cfg.rawOut, cfg.joinOut = true, true
		case "-a", "--ascii-output":
			cfg.ascii = true
		case "-S", "--sort-keys":
			cfg.sortKeys = true
		case "--tab":
			cfg.indent = "\t"
		case "--indent":
			i++
			if i >= len(args) {
				return "", nil, errors.New("--indent needs an argument")
			}
			n, _ := strconv.Atoi(args[i])
			if n < 0 {
				n = 0
			}
			if n > 7 {
				n = 7
			}
			cfg.indent = strings.Repeat(" ", n)
		case "-e", "--exit-status", "--unbuffered", "-M", "--monochrome-output", "-C", "--color-output":
			if a == "-e" || a == "--exit-status" {
				cfg.exitStatus = true
			}
		case "--arg":
			if i+2 >= len(args) {
				return "", nil, errors.New("--arg needs two arguments")
			}
			cfg.vars[args[i+1]] = args[i+2]
			i += 2
		case "--argjson":
			if i+2 >= len(args) {
				return "", nil, errors.New("--argjson needs two arguments")
			}
			var v J
			if err := json.Unmarshal([]byte(args[i+2]), &v); err != nil {
				return "", nil, err
			}
			cfg.vars[args[i+1]] = v
			i += 2
		case "--rawfile":
			if i+2 >= len(args) {
				return "", nil, errors.New("--rawfile needs two arguments")
			}
			b, err := os.ReadFile(args[i+2])
			if err != nil {
				return "", nil, err
			}
			cfg.vars[args[i+1]] = string(b)
			i += 2
		case "--slurpfile":
			if i+2 >= len(args) {
				return "", nil, errors.New("--slurpfile needs two arguments")
			}
			vals, err := readJSONFile(args[i+2])
			if err != nil {
				return "", nil, err
			}
			cfg.vars[args[i+1]] = vals
			i += 2
		case "-f", "--from-file":
			i++
			if i >= len(args) {
				return "", nil, errors.New("-f needs a file")
			}
			b, err := os.ReadFile(args[i])
			if err != nil {
				return "", nil, err
			}
			filter = string(b)
		case "--args":
			if filter == "" && i+1 < len(args) {
				filter = args[i+1]
				i++
			}
			for i+1 < len(args) {
				cfg.args = append(cfg.args, args[i+1])
				i++
			}
		case "--jsonargs":
			if filter == "" && i+1 < len(args) {
				filter = args[i+1]
				i++
			}
			for i+1 < len(args) {
				var v J
				if err := json.Unmarshal([]byte(args[i+1]), &v); err != nil {
					return "", nil, err
				}
				cfg.args = append(cfg.args, v)
				i++
			}
		case "--":
			for i+1 < len(args) {
				if filter == "" {
					filter = args[i+1]
				} else {
					files = append(files, args[i+1])
				}
				i++
			}
		default:
			if strings.HasPrefix(a, "-") && a != "-" {
				// Compact short options like -cr.
				if strings.HasPrefix(a, "-") && !strings.HasPrefix(a, "--") && len(a) > 2 {
					for _, ch := range a[1:] {
						switch ch {
						case 'c':
							cfg.compact = true
						case 'r':
							cfg.rawOut = true
						case 'j':
							cfg.rawOut, cfg.joinOut = true, true
						case 'n':
							cfg.nullInput = true
						case 'R':
							cfg.rawInput = true
						case 's':
							cfg.slurp = true
						case 'S':
							cfg.sortKeys = true
						case 'a':
							cfg.ascii = true
						default:
							return "", nil, fmt.Errorf("unknown option %s", a)
						}
					}
				} else if a == "-" {
					files = append(files, a)
				} else {
					return "", nil, fmt.Errorf("unknown option %s", a)
				}
			} else if filter == "" {
				filter = a
			} else {
				files = append(files, a)
			}
		}
	}
	return filter, files, nil
}

func printHelp() {
	fmt.Print(`jq - commandline JSON processor [version build-2b77eb1]

Usage:	jq [options] <jq filter> [file...]
	jq [options] --args <jq filter> [strings...]
	jq [options] --jsonargs <jq filter> [JSON_TEXTS...]

jq is a tool for processing JSON inputs, applying the given filter to
its JSON text inputs and producing the filter's results as JSON on
standard output.

Command options:
  -n, --null-input          use null as the single input value;
  -R, --raw-input           read each line as string instead of JSON;
  -s, --slurp               read all inputs into an array and use it as
                            the single input value;
  -c, --compact-output      compact instead of pretty-printed output;
  -r, --raw-output          output strings without escapes and quotes;
  -j, --join-output         implies -r and output without newline after
                            each output;
  -a, --ascii-output        output strings by only ASCII characters
                            using escape sequences;
  -S, --sort-keys           sort keys of each object on output;
  -f, --from-file           load the filter from a file;
      --arg name value      set $name to the string value;
      --argjson name value  set $name to the JSON value;
      --args                consume remaining arguments as positional
                            string values;
      --jsonargs            consume remaining arguments as positional
                            JSON values;
  -e, --exit-status         set exit status code based on the output;
  -V, --version             show the version;
  -h, --help                show the help;
`)
}

func readInputs(files []string, cfg Config) ([]J, error) {
	if len(files) == 0 {
		files = []string{"-"}
	}
	var out []J
	for _, f := range files {
		var r io.Reader
		if f == "-" {
			r = os.Stdin
		} else {
			fh, err := os.Open(f)
			if err != nil {
				return nil, err
			}
			defer fh.Close()
			r = fh
		}
		if cfg.rawInput {
			sc := bufio.NewScanner(r)
			for sc.Scan() {
				out = append(out, sc.Text())
			}
			if err := sc.Err(); err != nil {
				return nil, err
			}
		} else {
			dec := json.NewDecoder(r)
			dec.UseNumber()
			for {
				v, err := readOrdered(dec)
				if err == io.EOF {
					break
				}
				if err != nil {
					return nil, err
				}
				out = append(out, v)
			}
		}
	}
	return out, nil
}

func readJSONFile(path string) ([]J, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	dec := json.NewDecoder(f)
	dec.UseNumber()
	var vals []J
	for {
		v, err := readOrdered(dec)
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		vals = append(vals, v)
	}
	return vals, nil
}

func writeOutput(w io.Writer, v J, cfg Config) {
	if cfg.rawOut {
		if s, ok := v.(string); ok {
			fmt.Fprint(w, s)
		} else {
			fmt.Fprint(w, encodeJSON(v, cfg))
		}
	} else {
		fmt.Fprint(w, encodeJSON(v, cfg))
	}
	if !cfg.joinOut {
		fmt.Fprint(w, "\n")
	}
}

func encodeJSON(v J, cfg Config) string {
	s := marshalJ(v, cfg, 0)
	if cfg.ascii {
		return asciiEscape(s)
	}
	return s
}

func normalize(v J, sortKeys bool) J {
	switch x := v.(type) {
	case []J:
		a := make([]J, len(x))
		for i, e := range x {
			a[i] = normalize(e, sortKeys)
		}
		return a
	case []any:
		a := make([]J, len(x))
		for i, e := range x {
			a[i] = normalize(e, sortKeys)
		}
		return a
	case map[string]J:
		m := map[string]J{}
		for k, e := range x {
			m[k] = normalize(e, sortKeys)
		}
		return m
	case map[string]any:
		m := map[string]J{}
		for k, e := range x {
			m[k] = normalize(e, sortKeys)
		}
		return m
	case OMap:
		r := make(OMap, len(x))
		copy(r, x)
		if sortKeys {
			sort.SliceStable(r, func(i, j int) bool { return r[i].K < r[j].K })
		}
		for i := range r {
			r[i].V = normalize(r[i].V, sortKeys)
		}
		return r
	default:
		return v
	}
}

func readOrdered(dec *json.Decoder) (J, error) {
	t, err := dec.Token()
	if err != nil {
		return nil, err
	}
	switch x := t.(type) {
	case json.Delim:
		if x == '{' {
			var obj OMap
			for dec.More() {
				kt, err := dec.Token()
				if err != nil {
					return nil, err
				}
				v, err := readOrdered(dec)
				if err != nil {
					return nil, err
				}
				obj = append(obj, Pair{kt.(string), v})
			}
			_, err := dec.Token()
			return obj, err
		}
		if x == '[' {
			var arr []J
			for dec.More() {
				v, err := readOrdered(dec)
				if err != nil {
					return nil, err
				}
				arr = append(arr, v)
			}
			_, err := dec.Token()
			return arr, err
		}
	case json.Number:
		f, _ := x.Float64()
		return f, nil
	}
	return t, nil
}

func marshalJ(v J, cfg Config, level int) string {
	v = normalize(v, cfg.sortKeys)
	if cfg.compact {
		return marshalCompact(v)
	}
	return marshalPretty(v, cfg, level)
}

func marshalCompact(v J) string {
	switch x := v.(type) {
	case nil:
		return "null"
	case bool:
		if x {
			return "true"
		}
		return "false"
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	case int:
		return strconv.Itoa(x)
	case string:
		return strconv.Quote(x)
	case []J:
		parts := make([]string, len(x))
		for i, e := range x {
			parts[i] = marshalCompact(e)
		}
		return "[" + strings.Join(parts, ",") + "]"
	case []any:
		parts := make([]string, len(x))
		for i, e := range x {
			parts[i] = marshalCompact(e)
		}
		return "[" + strings.Join(parts, ",") + "]"
	case OMap:
		parts := make([]string, len(x))
		for i, p := range x {
			parts[i] = strconv.Quote(p.K) + ":" + marshalCompact(p.V)
		}
		return "{" + strings.Join(parts, ",") + "}"
	case map[string]J:
		ks := make([]string, 0, len(x))
		for k := range x {
			ks = append(ks, k)
		}
		sort.Strings(ks)
		parts := make([]string, len(ks))
		for i, k := range ks {
			parts[i] = strconv.Quote(k) + ":" + marshalCompact(x[k])
		}
		return "{" + strings.Join(parts, ",") + "}"
	case map[string]any:
		ks := make([]string, 0, len(x))
		for k := range x {
			ks = append(ks, k)
		}
		sort.Strings(ks)
		parts := make([]string, len(ks))
		for i, k := range ks {
			parts[i] = strconv.Quote(k) + ":" + marshalCompact(x[k])
		}
		return "{" + strings.Join(parts, ",") + "}"
	default:
		b, _ := json.Marshal(x)
		return string(b)
	}
}

func marshalPretty(v J, cfg Config, level int) string {
	ind := func(n int) string { return strings.Repeat(cfg.indent, n) }
	switch x := normalize(v, cfg.sortKeys).(type) {
	case []J:
		if len(x) == 0 {
			return "[]"
		}
		parts := make([]string, len(x))
		for i, e := range x {
			parts[i] = ind(level+1) + marshalPretty(e, cfg, level+1)
		}
		return "[\n" + strings.Join(parts, ",\n") + "\n" + ind(level) + "]"
	case []any:
		if len(x) == 0 {
			return "[]"
		}
		parts := make([]string, len(x))
		for i, e := range x {
			parts[i] = ind(level+1) + marshalPretty(e, cfg, level+1)
		}
		return "[\n" + strings.Join(parts, ",\n") + "\n" + ind(level) + "]"
	case OMap:
		if len(x) == 0 {
			return "{}"
		}
		parts := make([]string, len(x))
		for i, p := range x {
			parts[i] = ind(level+1) + strconv.Quote(p.K) + ": " + marshalPretty(p.V, cfg, level+1)
		}
		return "{\n" + strings.Join(parts, ",\n") + "\n" + ind(level) + "}"
	case map[string]J:
		ks := make([]string, 0, len(x))
		for k := range x {
			ks = append(ks, k)
		}
		sort.Strings(ks)
		om := make(OMap, len(ks))
		for i, k := range ks {
			om[i] = Pair{k, x[k]}
		}
		return marshalPretty(om, cfg, level)
	case map[string]any:
		ks := make([]string, 0, len(x))
		for k := range x {
			ks = append(ks, k)
		}
		sort.Strings(ks)
		om := make(OMap, len(ks))
		for i, k := range ks {
			om[i] = Pair{k, x[k]}
		}
		return marshalPretty(om, cfg, level)
	default:
		return marshalCompact(x)
	}
}

func asciiEscape(s string) string {
	var b strings.Builder
	for _, r := range s {
		if r < 128 {
			b.WriteRune(r)
		} else if r <= 0xffff {
			fmt.Fprintf(&b, "\\u%04x", r)
		} else {
			r -= 0x10000
			hi := 0xd800 + (r >> 10)
			lo := 0xdc00 + (r & 0x3ff)
			fmt.Fprintf(&b, "\\u%04x\\u%04x", hi, lo)
		}
	}
	return b.String()
}

type Node interface{ Eval(J, *Config) ([]J, error) }
type Lit struct{ v J }

func (n Lit) Eval(in J, c *Config) ([]J, error) { return []J{n.v}, nil }

type Id struct{}

func (Id) Eval(in J, c *Config) ([]J, error) { return []J{in}, nil }

type Empty struct{}

func (Empty) Eval(in J, c *Config) ([]J, error) { return nil, nil }

type Var struct{ name string }

func (n Var) Eval(in J, c *Config) ([]J, error) {
	if v, ok := c.vars[n.name]; ok {
		return []J{v}, nil
	}
	return []J{nil}, nil
}

type Pipe struct{ a, b Node }

func (n Pipe) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.a.Eval(in, c)
	if err != nil {
		return nil, err
	}
	var out []J
	for _, x := range xs {
		ys, err := n.b.Eval(x, c)
		if err != nil {
			return nil, err
		}
		out = append(out, ys...)
	}
	return out, nil
}

type Comma struct{ a, b Node }

func (n Comma) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.a.Eval(in, c)
	if err != nil {
		return nil, err
	}
	ys, err := n.b.Eval(in, c)
	if err != nil {
		return nil, err
	}
	return append(xs, ys...), nil
}

type Field struct {
	base Node
	name string
	opt  bool
}

func (n Field) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.base.Eval(in, c)
	if err != nil {
		return nil, err
	}
	var out []J
	for _, x := range xs {
		if m, ok := asMap(x); ok {
			out = append(out, m[n.name])
		} else if x == nil || n.opt {
			out = append(out, nil)
		} else {
			return nil, fmt.Errorf("cannot index %s with string %q", typeName(x), n.name)
		}
	}
	return out, nil
}

type Index struct {
	base, idx Node
	iter      bool
	opt       bool
}

func (n Index) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.base.Eval(in, c)
	if err != nil {
		return nil, err
	}
	var out []J
	for _, x := range xs {
		if n.iter {
			switch a := x.(type) {
			case []any:
				for _, e := range a {
					out = append(out, e)
				}
			case []J:
				out = append(out, a...)
			case map[string]any:
				m := map[string]J{}
				for k, v := range a {
					m[k] = v
				}
				keys := keysOf(m, true)
				for _, k := range keys {
					out = append(out, m[k.(string)])
				}
			case nil:
			default:
				if !n.opt {
					return nil, fmt.Errorf("cannot iterate over %s", typeName(x))
				}
			}
			continue
		}
		is, err := n.idx.Eval(in, c)
		if err != nil {
			return nil, err
		}
		for _, iv := range is {
			out = append(out, getIndex(x, iv))
		}
	}
	return out, nil
}

type Slice struct {
	base       Node
	start, end *int
}

func (n Slice) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.base.Eval(in, c)
	if err != nil {
		return nil, err
	}
	var out []J
	for _, x := range xs {
		out = append(out, sliceVal(x, n.start, n.end))
	}
	return out, nil
}

type Arr struct{ expr Node }

func (n Arr) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.expr.Eval(in, c)
	if err != nil {
		return nil, err
	}
	return []J{xs}, nil
}

type ObjPair struct {
	key     string
	keyExpr Node
	val     Node
}
type Obj struct{ pairs []ObjPair }

func (n Obj) Eval(in J, c *Config) ([]J, error) {
	var res OMap
	for _, p := range n.pairs {
		k := p.key
		if p.keyExpr != nil {
			ks, err := p.keyExpr.Eval(in, c)
			if err != nil {
				return nil, err
			}
			if len(ks) > 0 {
				k = toString(ks[0])
			}
		}
		vs, err := p.val.Eval(in, c)
		if err != nil {
			return nil, err
		}
		if len(vs) == 0 {
			continue
		}
		replaced := false
		for i := range res {
			if res[i].K == k {
				res[i].V = vs[0]
				replaced = true
			}
		}
		if !replaced {
			res = append(res, Pair{k, vs[0]})
		}
	}
	return []J{res}, nil
}

type Bin struct {
	op   string
	a, b Node
}

func (n Bin) Eval(in J, c *Config) ([]J, error) {
	as, err := n.a.Eval(in, c)
	if err != nil {
		return nil, err
	}
	bs, err := n.b.Eval(in, c)
	if err != nil {
		return nil, err
	}
	var out []J
	for _, x := range as {
		for _, y := range bs {
			out = append(out, binary(n.op, x, y))
		}
	}
	return out, nil
}

type Unary struct {
	op string
	x  Node
}

func (n Unary) Eval(in J, c *Config) ([]J, error) {
	xs, err := n.x.Eval(in, c)
	if err != nil {
		return nil, err
	}
	for i, x := range xs {
		if n.op == "not" {
			xs[i] = !truthy(x)
		} else if n.op == "-" {
			xs[i] = -num(x)
		}
	}
	return xs, nil
}

type Call struct {
	name string
	args []Node
}

func (n Call) Eval(in J, c *Config) ([]J, error) { return callBuiltin(n.name, n.args, in, c) }

func callBuiltin(name string, args []Node, in J, c *Config) ([]J, error) {
	eval1 := func(arg Node) (J, error) {
		xs, err := arg.Eval(in, c)
		if err != nil {
			return nil, err
		}
		if len(xs) == 0 {
			return nil, nil
		}
		return xs[0], nil
	}
	switch name {
	case "empty":
		return nil, nil
	case "length":
		return []J{length(in)}, nil
	case "type":
		return []J{typeName(in)}, nil
	case "keys", "keys_unsorted":
		if m, ok := asMap(in); ok {
			return []J{keysOf(m, name == "keys")}, nil
		}
		if a, ok := asArr(in); ok {
			r := make([]J, len(a))
			for i := range a {
				r[i] = float64(i)
			}
			return []J{r}, nil
		}
		return []J{[]J{}}, nil
	case "has":
		v, err := eval1(args[0])
		if err != nil {
			return nil, err
		}
		return []J{hasVal(in, v)}, nil
	case "map":
		if len(args) < 1 {
			return nil, nil
		}
		a, _ := asArr(in)
		var r []J
		for _, e := range a {
			ys, err := args[0].Eval(e, c)
			if err != nil {
				return nil, err
			}
			r = append(r, ys...)
		}
		return []J{r}, nil
	case "select":
		if len(args) < 1 {
			return []J{in}, nil
		}
		ys, err := args[0].Eval(in, c)
		if err != nil {
			return nil, err
		}
		for _, y := range ys {
			if truthy(y) {
				return []J{in}, nil
			}
		}
		return nil, nil
	case "not":
		return []J{!truthy(in)}, nil
	case "tostring":
		return []J{toJSONishString(in)}, nil
	case "tonumber":
		if s, ok := in.(string); ok {
			f, err := strconv.ParseFloat(s, 64)
			if err != nil {
				return nil, err
			}
			return []J{f}, nil
		}
		return []J{num(in)}, nil
	case "add":
		a, _ := asArr(in)
		if len(a) == 0 {
			return []J{nil}, nil
		}
		acc := a[0]
		for _, e := range a[1:] {
			acc = binary("+", acc, e)
		}
		return []J{acc}, nil
	case "reverse":
		a, ok := asArr(in)
		if ok {
			r := append([]J{}, a...)
			for i, j := 0, len(r)-1; i < j; i, j = i+1, j-1 {
				r[i], r[j] = r[j], r[i]
			}
			return []J{r}, nil
		}
		s := toString(in)
		rr := []rune(s)
		for i, j := 0, len(rr)-1; i < j; i, j = i+1, j-1 {
			rr[i], rr[j] = rr[j], rr[i]
		}
		return []J{string(rr)}, nil
	case "sort", "unique":
		a, _ := asArr(in)
		r := append([]J{}, a...)
		sort.Slice(r, func(i, j int) bool { return compare(r[i], r[j]) < 0 })
		if name == "unique" {
			u := []J{}
			for _, e := range r {
				if len(u) == 0 || compare(u[len(u)-1], e) != 0 {
					u = append(u, e)
				}
			}
			r = u
		}
		return []J{r}, nil
	case "contains":
		v, err := eval1(args[0])
		if err != nil {
			return nil, err
		}
		return []J{contains(in, v)}, nil
	case "startswith":
		v, err := eval1(args[0])
		if err != nil {
			return nil, err
		}
		return []J{strings.HasPrefix(toString(in), toString(v))}, nil
	case "endswith":
		v, err := eval1(args[0])
		if err != nil {
			return nil, err
		}
		return []J{strings.HasSuffix(toString(in), toString(v))}, nil
	case "split":
		v, err := eval1(args[0])
		if err != nil {
			return nil, err
		}
		parts := strings.Split(toString(in), toString(v))
		r := make([]J, len(parts))
		for i, p := range parts {
			r[i] = p
		}
		return []J{r}, nil
	case "join":
		v := ""
		if len(args) > 0 {
			x, err := eval1(args[0])
			if err != nil {
				return nil, err
			}
			v = toString(x)
		}
		a, _ := asArr(in)
		ss := make([]string, len(a))
		for i, e := range a {
			ss[i] = toString(e)
		}
		return []J{strings.Join(ss, v)}, nil
	case "ascii_downcase":
		return []J{strings.ToLower(toString(in))}, nil
	case "ascii_upcase":
		return []J{strings.ToUpper(toString(in))}, nil
	case "floor":
		return []J{math.Floor(num(in))}, nil
	case "sqrt":
		return []J{math.Sqrt(num(in))}, nil
	case "abs":
		return []J{math.Abs(num(in))}, nil
	case "min", "max":
		a, _ := asArr(in)
		if len(a) == 0 {
			return []J{nil}, nil
		}
		best := a[0]
		for _, e := range a[1:] {
			cmp := compare(e, best)
			if (name == "min" && cmp < 0) || (name == "max" && cmp > 0) {
				best = e
			}
		}
		return []J{best}, nil
	case "first":
		if a, ok := asArr(in); ok {
			if len(a) == 0 {
				return []J{nil}, nil
			}
			return []J{a[0]}, nil
		}
		return []J{in}, nil
	case "last":
		if a, ok := asArr(in); ok {
			if len(a) == 0 {
				return []J{nil}, nil
			}
			return []J{a[len(a)-1]}, nil
		}
		return []J{in}, nil
	case "range":
		var start, end, step float64
		if len(args) == 1 {
			start = 0
			v, err := eval1(args[0])
			if err != nil {
				return nil, err
			}
			end = num(v)
			step = 1
		} else if len(args) >= 2 {
			v, err := eval1(args[0])
			if err != nil {
				return nil, err
			}
			start = num(v)
			v, err = eval1(args[1])
			if err != nil {
				return nil, err
			}
			end = num(v)
			step = 1
			if len(args) >= 3 {
				v, err = eval1(args[2])
				if err != nil {
					return nil, err
				}
				step = num(v)
			}
		} else {
			return nil, nil
		}
		if step == 0 {
			return nil, nil
		}
		var out []J
		if step > 0 {
			for x := start; x < end; x += step {
				out = append(out, x)
			}
		} else {
			for x := start; x > end; x += step {
				out = append(out, x)
			}
		}
		return out, nil
	default:
		return nil, fmt.Errorf("%s is not defined", name)
	}
}

type Tok struct{ typ, val string }
type Lexer struct {
	s string
	i int
}

func (l *Lexer) next() Tok {
	for l.i < len(l.s) && unicode.IsSpace(rune(l.s[l.i])) {
		l.i++
	}
	if l.i >= len(l.s) {
		return Tok{"eof", ""}
	}
	c := l.s[l.i]
	if strings.ContainsRune(".,|:()[]{}", rune(c)) {
		l.i++
		return Tok{string(c), string(c)}
	}
	if strings.ContainsRune("+-*/%<>=", rune(c)) {
		start := l.i
		l.i++
		if l.i < len(l.s) && l.s[l.i] == '=' {
			l.i++
		}
		return Tok{"op", l.s[start:l.i]}
	}
	if c == '!' {
		start := l.i
		l.i++
		if l.i < len(l.s) && l.s[l.i] == '=' {
			l.i++
		}
		return Tok{"op", l.s[start:l.i]}
	}
	if c == '?' {
		l.i++
		return Tok{"?", "?"}
	}
	if c == '$' {
		l.i++
		st := l.i
		for l.i < len(l.s) && isIdent(l.s[l.i]) {
			l.i++
		}
		return Tok{"var", l.s[st:l.i]}
	}
	if c == '"' {
		st := l.i
		l.i++
		esc := false
		for l.i < len(l.s) {
			ch := l.s[l.i]
			l.i++
			if esc {
				esc = false
				continue
			}
			if ch == '\\' {
				esc = true
				continue
			}
			if ch == '"' {
				break
			}
		}
		var v string
		json.Unmarshal([]byte(l.s[st:l.i]), &v)
		return Tok{"str", v}
	}
	if c == '-' || c >= '0' && c <= '9' {
		st := l.i
		l.i++
		for l.i < len(l.s) && strings.ContainsRune("0123456789.eE+-", rune(l.s[l.i])) {
			if (l.s[l.i] == '+' || l.s[l.i] == '-') && !(l.s[l.i-1] == 'e' || l.s[l.i-1] == 'E') {
				break
			}
			l.i++
		}
		return Tok{"num", l.s[st:l.i]}
	}
	if isIdentStart(c) {
		st := l.i
		l.i++
		for l.i < len(l.s) && isIdent(l.s[l.i]) {
			l.i++
		}
		return Tok{"id", l.s[st:l.i]}
	}
	l.i++
	return Tok{string(c), string(c)}
}
func isIdentStart(c byte) bool { return c == '_' || unicode.IsLetter(rune(c)) }
func isIdent(c byte) bool      { return c == '_' || unicode.IsLetter(rune(c)) || unicode.IsDigit(rune(c)) }

type Parser struct {
	toks []Tok
	i    int
}

func NewParser(s string) *Parser {
	l := Lexer{s: s}
	var ts []Tok
	for {
		t := l.next()
		ts = append(ts, t)
		if t.typ == "eof" {
			break
		}
	}
	return &Parser{toks: ts}
}
func (p *Parser) peek() Tok { return p.toks[p.i] }
func (p *Parser) pop() Tok {
	t := p.toks[p.i]
	if p.i < len(p.toks)-1 {
		p.i++
	}
	return t
}
func (p *Parser) eat(t string) bool {
	if p.peek().typ == t || p.peek().val == t {
		p.pop()
		return true
	}
	return false
}
func (p *Parser) Parse() (Node, error) {
	n, err := p.parseComma()
	if err != nil {
		return nil, err
	}
	return n, nil
}
func (p *Parser) parseComma() (Node, error) {
	n, err := p.parsePipe()
	if err != nil {
		return nil, err
	}
	for p.eat(",") {
		r, err := p.parsePipe()
		if err != nil {
			return nil, err
		}
		n = Comma{n, r}
	}
	return n, nil
}
func (p *Parser) parsePipe() (Node, error) {
	n, err := p.parseOr()
	if err != nil {
		return nil, err
	}
	for p.eat("|") {
		r, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		n = Pipe{n, r}
	}
	return n, nil
}
func (p *Parser) parseOr() (Node, error) {
	n, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for p.peek().typ == "id" && p.peek().val == "or" {
		p.pop()
		r, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		n = Bin{"or", n, r}
	}
	return n, nil
}
func (p *Parser) parseAnd() (Node, error) {
	n, err := p.parseCmp()
	if err != nil {
		return nil, err
	}
	for p.peek().typ == "id" && p.peek().val == "and" {
		p.pop()
		r, err := p.parseCmp()
		if err != nil {
			return nil, err
		}
		n = Bin{"and", n, r}
	}
	return n, nil
}
func (p *Parser) parseCmp() (Node, error) {
	n, err := p.parseAdd()
	if err != nil {
		return nil, err
	}
	for p.peek().typ == "op" && strings.Contains(" == != < > <= >= ", " "+p.peek().val+" ") {
		op := p.pop().val
		r, err := p.parseAdd()
		if err != nil {
			return nil, err
		}
		n = Bin{op, n, r}
	}
	return n, nil
}
func (p *Parser) parseAdd() (Node, error) {
	n, err := p.parseMul()
	if err != nil {
		return nil, err
	}
	for p.peek().typ == "op" && (p.peek().val == "+" || p.peek().val == "-") {
		op := p.pop().val
		r, err := p.parseMul()
		if err != nil {
			return nil, err
		}
		n = Bin{op, n, r}
	}
	return n, nil
}
func (p *Parser) parseMul() (Node, error) {
	n, err := p.parsePost()
	if err != nil {
		return nil, err
	}
	for p.peek().typ == "op" && (p.peek().val == "*" || p.peek().val == "/" || p.peek().val == "%") {
		op := p.pop().val
		r, err := p.parsePost()
		if err != nil {
			return nil, err
		}
		n = Bin{op, n, r}
	}
	return n, nil
}
func (p *Parser) parsePost() (Node, error) {
	n, err := p.parseUnary()
	if err != nil {
		return nil, err
	}
	for {
		if p.eat(".") {
			if p.peek().typ == "id" {
				n = Field{n, p.pop().val, false}
			} else if p.peek().typ == "str" {
				n = Field{n, p.pop().val, false}
			} else {
				p.i--
				break
			}
		} else if p.eat("[") {
			if p.eat("]") {
				n = Index{base: n, iter: true}
			} else {
				if p.peek().typ == "num" {
					st := atoi(p.pop().val)
					if p.eat(":") {
						var en *int
						if p.peek().typ == "num" {
							v := atoi(p.pop().val)
							en = &v
						}
						if !p.eat("]") {
							return nil, errors.New("expected ]")
						}
						n = Slice{n, &st, en}
					} else {
						if !p.eat("]") {
							return nil, errors.New("expected ]")
						}
						n = Index{base: n, idx: Lit{float64(st)}}
					}
				} else if p.eat(":") {
					var en *int
					if p.peek().typ == "num" {
						v := atoi(p.pop().val)
						en = &v
					}
					if !p.eat("]") {
						return nil, errors.New("expected ]")
					}
					n = Slice{n, nil, en}
				} else {
					idx, err := p.parseComma()
					if err != nil {
						return nil, err
					}
					if !p.eat("]") {
						return nil, errors.New("expected ]")
					}
					n = Index{base: n, idx: idx}
				}
			}
		} else if p.eat("?") { /* tolerate optional */
		} else {
			break
		}
	}
	return n, nil
}
func (p *Parser) parseUnary() (Node, error) {
	if p.peek().typ == "id" && p.peek().val == "not" {
		p.pop()
		x, err := p.parseUnary()
		return Unary{"not", x}, err
	}
	if p.peek().typ == "op" && p.peek().val == "-" {
		p.pop()
		x, err := p.parseUnary()
		return Unary{"-", x}, err
	}
	return p.parsePrimary()
}
func (p *Parser) parsePrimary() (Node, error) {
	t := p.pop()
	switch t.typ {
	case ".":
		if p.peek().typ == "id" || p.peek().typ == "str" {
			return Field{Id{}, p.pop().val, false}, nil
		}
		return Id{}, nil
	case "num":
		f, _ := strconv.ParseFloat(t.val, 64)
		return Lit{f}, nil
	case "str":
		return Lit{t.val}, nil
	case "var":
		return Var{t.val}, nil
	case "id":
		switch t.val {
		case "true":
			return Lit{true}, nil
		case "false":
			return Lit{false}, nil
		case "null":
			return Lit{nil}, nil
		}
		if p.eat("(") {
			var args []Node
			if !p.eat(")") {
				for {
					a, err := p.parseComma()
					if err != nil {
						return nil, err
					}
					args = append(args, a)
					if p.eat(")") {
						break
					}
					if !p.eat(";") && !p.eat(",") {
						return nil, errors.New("expected , or )")
					}
				}
			}
			return Call{t.val, args}, nil
		}
		return Call{t.val, nil}, nil
	case "(":
		n, err := p.parseComma()
		if err != nil {
			return nil, err
		}
		if !p.eat(")") {
			return nil, errors.New("expected )")
		}
		return n, nil
	case "[":
		if p.eat("]") {
			return Lit{[]J{}}, nil
		}
		n, err := p.parseComma()
		if err != nil {
			return nil, err
		}
		if !p.eat("]") {
			return nil, errors.New("expected ]")
		}
		return Arr{n}, nil
	case "{":
		var pairs []ObjPair
		if p.eat("}") {
			return Obj{pairs}, nil
		}
		for {
			var key string
			var keyExpr Node
			var val Node
			if p.eat("(") {
				k, err := p.parseComma()
				if err != nil {
					return nil, err
				}
				keyExpr = k
				if !p.eat(")") {
					return nil, errors.New("expected )")
				}
			} else {
				kt := p.pop()
				if kt.typ != "id" && kt.typ != "str" {
					return nil, errors.New("expected object key")
				}
				key = kt.val
			}
			if p.eat(":") {
				v, err := p.parsePipe()
				if err != nil {
					return nil, err
				}
				val = v
			} else {
				val = Field{Id{}, key, false}
			}
			pairs = append(pairs, ObjPair{key, keyExpr, val})
			if p.eat("}") {
				break
			}
			if !p.eat(",") {
				return nil, errors.New("expected , or }")
			}
		}
		return Obj{pairs}, nil
	default:
		return nil, fmt.Errorf("unexpected token %s", t.val)
	}
}
func atoi(s string) int { v, _ := strconv.Atoi(s); return v }

func asMap(v J) (map[string]J, bool) {
	switch m := v.(type) {
	case OMap:
		r := map[string]J{}
		for _, p := range m {
			r[p.K] = p.V
		}
		return r, true
	case map[string]any:
		r := map[string]J{}
		for k, v := range m {
			r[k] = v
		}
		return r, true
	case map[string]J:
		return m, true
	}
	return nil, false
}
func asArr(v J) ([]J, bool) {
	switch a := v.(type) {
	case []any:
		r := make([]J, len(a))
		for i, e := range a {
			r[i] = e
		}
		return r, true
	case []J:
		return a, true
	}
	return nil, false
}
func keysOf(m map[string]J, sorted bool) []J {
	ks := make([]string, 0, len(m))
	for k := range m {
		ks = append(ks, k)
	}
	if sorted {
		sort.Strings(ks)
	}
	r := make([]J, len(ks))
	for i, k := range ks {
		r[i] = k
	}
	return r
}
func getIndex(v, idx J) J {
	if s, ok := idx.(string); ok {
		if m, ok := asMap(v); ok {
			return m[s]
		}
		return nil
	}
	i := int(num(idx))
	if a, ok := asArr(v); ok {
		if i < 0 {
			i = len(a) + i
		}
		if i >= 0 && i < len(a) {
			return a[i]
		}
		return nil
	}
	if s, ok := v.(string); ok {
		rr := []rune(s)
		if i < 0 {
			i = len(rr) + i
		}
		if i >= 0 && i < len(rr) {
			return string(rr[i])
		}
	}
	return nil
}
func sliceVal(v J, st, en *int) J {
	a, ok := asArr(v)
	if ok {
		l := len(a)
		s := 0
		e := l
		if st != nil {
			s = *st
		}
		if en != nil {
			e = *en
		}
		if s < 0 {
			s = l + s
		}
		if e < 0 {
			e = l + e
		}
		if s < 0 {
			s = 0
		}
		if e > l {
			e = l
		}
		if e < s {
			e = s
		}
		return a[s:e]
	}
	if str, ok := v.(string); ok {
		rr := []rune(str)
		l := len(rr)
		s := 0
		e := l
		if st != nil {
			s = *st
		}
		if en != nil {
			e = *en
		}
		if s < 0 {
			s = l + s
		}
		if e < 0 {
			e = l + e
		}
		if s < 0 {
			s = 0
		}
		if e > l {
			e = l
		}
		if e < s {
			e = s
		}
		return string(rr[s:e])
	}
	return nil
}
func binary(op string, a, b J) J {
	switch op {
	case "and":
		return truthy(a) && truthy(b)
	case "or":
		return truthy(a) || truthy(b)
	case "==":
		return compare(a, b) == 0
	case "!=":
		return compare(a, b) != 0
	case "<":
		return compare(a, b) < 0
	case ">":
		return compare(a, b) > 0
	case "<=":
		return compare(a, b) <= 0
	case ">=":
		return compare(a, b) >= 0
	case "+":
		return plus(a, b)
	case "-":
		return num(a) - num(b)
	case "*":
		return times(a, b)
	case "/":
		if s, ok := a.(string); ok {
			sep := toString(b)
			parts := strings.Split(s, sep)
			r := make([]J, len(parts))
			for i, p := range parts {
				r[i] = p
			}
			return r
		}
		return num(a) / num(b)
	case "%":
		return math.Mod(num(a), num(b))
	}
	return nil
}
func plus(a, b J) J {
	if a == nil {
		return b
	}
	if b == nil {
		return a
	}
	if sa, ok := a.(string); ok {
		return sa + toString(b)
	}
	if sb, ok := b.(string); ok {
		return toString(a) + sb
	}
	if aa, ok := asArr(a); ok {
		bb, _ := asArr(b)
		return append(aa, bb...)
	}
	if ma, ok := asMap(a); ok {
		mb, _ := asMap(b)
		var r OMap
		if oa, ok := a.(OMap); ok {
			r = append(r, oa...)
		} else {
			keys := make([]string, 0, len(ma))
			for k := range ma {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, k := range keys {
				r = append(r, Pair{k, ma[k]})
			}
		}
		for k, v := range mb {
			found := false
			for i := range r {
				if r[i].K == k {
					r[i].V = v
					found = true
				}
			}
			if !found {
				r = append(r, Pair{k, v})
			}
		}
		return r
	}
	return num(a) + num(b)
}
func times(a, b J) J {
	if s, ok := a.(string); ok {
		n := int(num(b))
		if n < 0 {
			n = 0
		}
		return strings.Repeat(s, n)
	}
	if s, ok := b.(string); ok {
		n := int(num(a))
		if n < 0 {
			n = 0
		}
		return strings.Repeat(s, n)
	}
	return num(a) * num(b)
}
func num(v J) float64 {
	switch x := v.(type) {
	case float64:
		return x
	case int:
		return float64(x)
	case bool:
		if x {
			return 1
		}
		return 0
	case string:
		f, _ := strconv.ParseFloat(x, 64)
		return f
	}
	return 0
}
func truthy(v J) bool {
	if v == nil {
		return false
	}
	if b, ok := v.(bool); ok {
		return b
	}
	return true
}
func typeName(v J) string {
	switch v.(type) {
	case nil:
		return "null"
	case bool:
		return "boolean"
	case float64, int:
		return "number"
	case string:
		return "string"
	case []any, []J:
		return "array"
	case map[string]any, map[string]J:
		return "object"
	case OMap:
		return "object"
	}
	return "unknown"
}
func length(v J) J {
	switch x := v.(type) {
	case nil:
		return float64(0)
	case string:
		return float64(utf8.RuneCountInString(x))
	case float64:
		return math.Abs(x)
	case []any:
		return float64(len(x))
	case []J:
		return float64(len(x))
	case map[string]any:
		return float64(len(x))
	case map[string]J:
		return float64(len(x))
	case OMap:
		return float64(len(x))
	}
	return float64(0)
}
func toString(v J) string {
	if v == nil {
		return ""
	}
	if s, ok := v.(string); ok {
		return s
	}
	if f, ok := v.(float64); ok {
		return strconv.FormatFloat(f, 'f', -1, 64)
	}
	if b, ok := v.(bool); ok {
		if b {
			return "true"
		}
		return "false"
	}
	return toJSONishString(v)
}
func toJSONishString(v J) string {
	if s, ok := v.(string); ok {
		return s
	}
	return marshalCompact(v)
}
func hasVal(v, k J) bool {
	if m, ok := asMap(v); ok {
		_, yes := m[toString(k)]
		return yes
	}
	if a, ok := asArr(v); ok {
		i := int(num(k))
		return i >= 0 && i < len(a)
	}
	return false
}
func contains(a, b J) bool {
	if sa, ok := a.(string); ok {
		return strings.Contains(sa, toString(b))
	}
	if aa, ok := asArr(a); ok {
		for _, be := range mustArr(b) {
			found := false
			for _, ae := range aa {
				if compare(ae, be) == 0 {
					found = true
				}
			}
			if !found {
				return false
			}
		}
		return true
	}
	if ma, ok := asMap(a); ok {
		mb, _ := asMap(b)
		for k, bv := range mb {
			if !contains(ma[k], bv) && compare(ma[k], bv) != 0 {
				return false
			}
		}
		return true
	}
	return compare(a, b) == 0
}
func mustArr(v J) []J { a, _ := asArr(v); return a }
func compare(a, b J) int {
	ta, tb := typeRank(a), typeRank(b)
	if ta != tb {
		return ta - tb
	}
	switch ax := a.(type) {
	case nil:
		return 0
	case bool:
		bx := b.(bool)
		if ax == bx {
			return 0
		}
		if !ax {
			return -1
		}
		return 1
	case float64:
		d := ax - num(b)
		if d < 0 {
			return -1
		}
		if d > 0 {
			return 1
		}
		return 0
	case string:
		return strings.Compare(ax, toString(b))
	default:
		aj := toJSONishString(a)
		bj := toJSONishString(b)
		return strings.Compare(aj, bj)
	}
}
func typeRank(v J) int {
	switch v.(type) {
	case nil:
		return 0
	case bool:
		return 1
	case float64, int:
		return 2
	case string:
		return 3
	case []any, []J:
		return 4
	case map[string]any, map[string]J:
		return 5
	case OMap:
		return 5
	}
	return 6
}

func _unused() { _, _ = bytes.Buffer{}, utf8.RuneError }
