package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/md5"
	crand "crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"math"
	"net"
	"net/url"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
)

type multiFlag []string

func (m *multiFlag) String() string     { return strings.Join(*m, ",") }
func (m *multiFlag) Set(s string) error { *m = append(*m, s); return nil }

type options struct {
	in, out, inputDir, outputDir, outputMap, chmod, left, right, missing                    string
	files, templates, datasources, contexts, plugins, includes, excludes, excludeProcessing multiFlag
	version, verbose, help, execPipe, experimental                                          bool
}

type engine struct {
	datasources map[string]string
	cache       map[string]any
	stdin       []byte
	funcs       template.FuncMap
	plugins     map[string]string
}

func main() {
	opt := parseFlags()
	if opt.help {
		usage()
		return
	}
	if opt.version {
		fmt.Fprintln(os.Stdout, "gomplate version 0.0.0")
		return
	}
	e := &engine{datasources: map[string]string{}, cache: map[string]any{}, plugins: map[string]string{}}
	for _, p := range opt.datasources {
		k, v, err := splitKV(p)
		fatalIf(err)
		e.datasources[k] = v
	}
	for _, p := range opt.contexts {
		k, v, err := splitKV(p)
		fatalIf(err)
		e.datasources["@ctx:"+k] = v
	}
	for _, p := range opt.plugins {
		k, v, err := splitKV(p)
		fatalIf(err)
		e.plugins[k] = v
	}
	e.funcs = e.makeFuncs()
	root := map[string]any{"Env": envMap()}
	for _, p := range opt.contexts {
		k, _, _ := splitKV(p)
		val, err := e.datasource(k)
		fatalIf(err)
		if k == "." {
			root = normalizeRoot(val)
		} else {
			root[k] = val
		}
	}
	if opt.inputDir != "" {
		fatalIf(e.processDir(opt, root))
		return
	}
	var input string
	if opt.in != "" {
		input = opt.in
	} else {
		b, err := readInputs(opt.files)
		fatalIf(err)
		e.stdin = b
		input = string(b)
	}
	for _, tf := range opt.templates {
		b, err := os.ReadFile(tf)
		fatalIf(err)
		input += "\n" + string(b)
	}
	out, err := e.render("input", input, root, opt)
	fatalIf(err)
	if opt.out != "" && opt.out != "-" {
		fatalIf(os.WriteFile(opt.out, []byte(out), 0644))
		maybeChmod(opt.out, opt.chmod)
		return
	}
	fmt.Fprint(os.Stdout, out)
}

func parseFlags() options {
	var o options
	o.left = getenvDefault("GOMPLATE_LEFT_DELIM", "{{")
	o.right = getenvDefault("GOMPLATE_RIGHT_DELIM", "}}")
	o.missing = "error"
	o.outputDir = "."
	fs := flag.NewFlagSet(os.Args[0], flag.ExitOnError)
	fs.Var(&o.datasources, "d", "")
	fs.Var(&o.datasources, "datasource", "")
	var headers multiFlag
	fs.Var(&headers, "H", "")
	fs.Var(&headers, "datasource-header", "")
	fs.Var(&o.contexts, "c", "")
	fs.Var(&o.contexts, "context", "")
	fs.Var(&o.plugins, "plugin", "")
	fs.Var(&o.files, "f", "")
	fs.Var(&o.files, "file", "")
	fs.StringVar(&o.in, "i", "", "")
	fs.StringVar(&o.in, "in", "", "")
	fs.StringVar(&o.inputDir, "input-dir", "", "")
	fs.Var(&o.excludes, "exclude", "")
	fs.Var(&o.excludeProcessing, "exclude-processing", "")
	fs.Var(&o.includes, "include", "")
	fs.StringVar(&o.out, "o", "", "")
	fs.StringVar(&o.out, "out", "", "")
	fs.Var(&o.templates, "t", "")
	fs.Var(&o.templates, "template", "")
	fs.StringVar(&o.outputDir, "output-dir", ".", "")
	fs.StringVar(&o.outputMap, "output-map", "", "")
	fs.StringVar(&o.chmod, "chmod", "", "")
	fs.BoolVar(&o.execPipe, "exec-pipe", false, "")
	fs.StringVar(&o.left, "left-delim", o.left, "")
	fs.StringVar(&o.right, "right-delim", o.right, "")
	fs.StringVar(&o.missing, "missing-key", "error", "")
	fs.BoolVar(&o.experimental, "experimental", false, "")
	fs.BoolVar(&o.verbose, "V", false, "")
	fs.BoolVar(&o.verbose, "verbose", false, "")
	var config string
	fs.StringVar(&config, "config", ".gomplate.yaml", "")
	fs.BoolVar(&o.help, "h", false, "")
	fs.BoolVar(&o.help, "help", false, "")
	fs.BoolVar(&o.version, "v", false, "")
	fs.BoolVar(&o.version, "version", false, "")
	_ = fs.Parse(os.Args[1:])
	if len(o.files) == 0 && o.in == "" && o.inputDir == "" {
		o.files = multiFlag{"-"}
	}
	return o
}

func usage() {
	fmt.Print(`Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias . to set the root context.
  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
  -i, --in string                    Template string to process (alternative to --file and --input-dir)
  -o, --out file                     output file name. Omit to use standard output. (default [-])
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate
`)
}

func (e *engine) render(name, text string, data any, o options) (string, error) {
	miss := o.missing
	if miss == "default" || miss == "invalid" {
		miss = "invalid"
	}
	t := template.New(name).Funcs(e.funcs).Option("missingkey="+miss).Delims(o.left, o.right)
	_, err := t.Parse(text)
	if err != nil {
		return "", err
	}
	var b bytes.Buffer
	err = t.Execute(&b, data)
	return b.String(), err
}

func (e *engine) processDir(o options, root any) error {
	return filepath.WalkDir(o.inputDir, func(p string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		rel, _ := filepath.Rel(o.inputDir, p)
		if !matchInclude(rel, o.includes, o.excludes) {
			return nil
		}
		outp := filepath.Join(o.outputDir, rel)
		if o.outputMap != "" {
			s, err := e.render("output-map", o.outputMap, map[string]any{"in": p, "rel": rel, "ctx": root}, o)
			if err == nil && s != "" {
				outp = s
			}
		}
		os.MkdirAll(filepath.Dir(outp), 0755)
		copyOnly := matchesAny(rel, o.excludeProcessing)
		if copyOnly {
			b, err := os.ReadFile(p)
			if err != nil {
				return err
			}
			return os.WriteFile(outp, b, 0644)
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		r, err := e.render(p, string(b), root, o)
		if err != nil {
			return err
		}
		err = os.WriteFile(outp, []byte(r), 0644)
		maybeChmod(outp, o.chmod)
		return err
	})
}

func (e *engine) makeFuncs() template.FuncMap {
	f := template.FuncMap{}
	mathNS := MathNS{}
	envNS := EnvNS{}
	strNS := StringsNS{}
	collNS := CollNS{}
	dataNS := DataNS{}
	fileNS := FileNS{}
	pathNS := PathNS{}
	fpNS := FilepathNS{}
	reNS := RegexpNS{}
	b64NS := Base64NS{}
	timeNS := TimeNS{}
	netNS := NetNS{}
	convNS := ConvNS{}
	cryptoNS := CryptoNS{}
	randomNS := RandomNS{}
	uuidNS := UUIDNS{}
	testNS := TestNS{}
	f["math"] = func() MathNS { return mathNS }
	f["env"] = func() EnvNS { return envNS }
	f["strings"] = func() StringsNS { return strNS }
	f["coll"] = func() CollNS { return collNS }
	f["data"] = func() DataNS { return dataNS }
	f["file"] = func() FileNS { return fileNS }
	f["path"] = func() PathNS { return pathNS }
	f["filepath"] = func() FilepathNS { return fpNS }
	f["regexp"] = func() RegexpNS { return reNS }
	f["base64"] = func() Base64NS { return b64NS }
	f["time"] = func() TimeNS { return timeNS }
	f["net"] = func() NetNS { return netNS }
	f["conv"] = func() ConvNS { return convNS }
	f["crypto"] = func() CryptoNS { return cryptoNS }
	f["random"] = func() RandomNS { return randomNS }
	f["uuid"] = func() UUIDNS { return uuidNS }
	f["test"] = func() TestNS { return testNS }
	f["add"] = mathNS.Add
	f["sub"] = mathNS.Sub
	f["mul"] = mathNS.Mul
	f["div"] = mathNS.Div
	f["mod"] = mathNS.Mod
	f["rem"] = mathNS.Rem
	f["seq"] = mathNS.Seq
	f["getenv"] = envNS.Getenv
	f["indent"] = strNS.Indent
	f["join"] = strNS.Join
	f["split"] = strNS.Split
	f["replace"] = strNS.Replace
	f["trim"] = strings.TrimSpace
	f["contains"] = strings.Contains
	f["hasPrefix"] = strings.HasPrefix
	f["hasSuffix"] = strings.HasSuffix
	f["dict"] = collNS.Dict
	f["slice"] = collNS.Slice
	f["list"] = collNS.Slice
	f["has"] = collNS.Has
	f["append"] = collNS.Append
	f["keys"] = collNS.Keys
	f["json"] = dataNS.JSON
	f["toJSON"] = dataNS.ToJSON
	f["toJSONPretty"] = dataNS.ToJSONPretty
	f["toYAML"] = dataNS.ToYAML
	f["csv"] = dataNS.CSV
	f["default"] = convNS.Default
	f["bool"] = convNS.Bool
	f["atoi"] = convNS.Atoi
	f["toString"] = convNS.ToString
	f["toStrings"] = convNS.ToStrings
	f["ds"] = e.datasourceFunc
	f["datasource"] = e.datasourceFunc
	f["datasourceExists"] = func(name string) bool { _, ok := e.datasources[name]; return ok }
	f["datasourceReachable"] = func(name string) bool { _, err := e.datasource(name); return err == nil }
	f["listDatasources"] = func() []string {
		keys := []string{}
		for k := range e.datasources {
			if !strings.HasPrefix(k, "@ctx:") {
				keys = append(keys, k)
			}
		}
		sort.Strings(keys)
		return keys
	}
	f["defineDatasource"] = func(name, src string) string { e.datasources[name] = src; delete(e.cache, name); return "" }
	f["include"] = func(name string) (string, error) { v, err := e.readSource(name); return string(v), err }
	for name, path := range e.plugins {
		n, p := name, path
		f[n] = func(args ...any) (string, error) {
			ss := []string{}
			for _, a := range args {
				ss = append(ss, toString(a))
			}
			cmd := exec.Command(p, ss...)
			out, err := cmd.Output()
			return string(out), err
		}
	}
	return f
}

// namespaces
type MathNS struct{}

func (MathNS) Add(v ...any) any {
	fl := false
	var fi float64
	var ii int64
	for _, x := range v {
		if isFloatLike(x) {
			fl = true
		}
		fi += toFloat(x)
		ii += toInt(x)
	}
	if fl {
		return cleanFloat(fi)
	}
	return ii
}
func (MathNS) Sub(a any, b ...any) any {
	fl := isFloatLike(a)
	fi := toFloat(a)
	ii := toInt(a)
	for _, x := range b {
		if isFloatLike(x) {
			fl = true
		}
		fi -= toFloat(x)
		ii -= toInt(x)
	}
	if fl {
		return cleanFloat(fi)
	}
	return ii
}
func (MathNS) Mul(v ...any) any {
	fl := false
	fi := 1.0
	ii := int64(1)
	for _, x := range v {
		if isFloatLike(x) {
			fl = true
		}
		fi *= toFloat(x)
		ii *= toInt(x)
	}
	if fl {
		return cleanFloat(fi)
	}
	return ii
}
func (MathNS) Div(a, b any) (float64, error) {
	d := toFloat(b)
	if d == 0 {
		return 0, errors.New("division by zero")
	}
	return toFloat(a) / d, nil
}
func (MathNS) Mod(a, b any) (int64, error) {
	d := toInt(b)
	if d == 0 {
		return 0, errors.New("modulo by zero")
	}
	return toInt(a) % d, nil
}
func (m MathNS) Rem(a, b any) (int64, error) { return m.Mod(a, b) }
func (MathNS) Abs(a any) any {
	if isFloatLike(a) {
		return math.Abs(toFloat(a))
	}
	i := toInt(a)
	if i < 0 {
		i = -i
	}
	return i
}
func (MathNS) Ceil(a any) float64  { return math.Ceil(toFloat(a)) }
func (MathNS) Floor(a any) float64 { return math.Floor(toFloat(a)) }
func (MathNS) Round(a any) float64 { return math.Round(toFloat(a)) }
func (MathNS) Max(v ...any) any {
	if len(v) == 0 {
		return 0
	}
	fl := false
	m := toFloat(v[0])
	mi := toInt(v[0])
	for _, x := range v {
		if isFloatLike(x) {
			fl = true
		}
		if toFloat(x) > m {
			m = toFloat(x)
		}
		if toInt(x) > mi {
			mi = toInt(x)
		}
	}
	if fl {
		return cleanFloat(m)
	}
	return mi
}
func (MathNS) Min(v ...any) any {
	if len(v) == 0 {
		return 0
	}
	fl := false
	m := toFloat(v[0])
	mi := toInt(v[0])
	for _, x := range v {
		if isFloatLike(x) {
			fl = true
		}
		if toFloat(x) < m {
			m = toFloat(x)
		}
		if toInt(x) < mi {
			mi = toInt(x)
		}
	}
	if fl {
		return cleanFloat(m)
	}
	return mi
}
func (MathNS) Pow(a, b any) float64 { return math.Pow(toFloat(a), toFloat(b)) }
func (MathNS) Seq(start, end, step any) []int64 {
	s, e, st := toInt(start), toInt(end), toInt(step)
	if st == 0 {
		return []int64{}
	}
	if e < s && st > 0 {
		st = -st
	}
	if e > s && st < 0 {
		st = -st
	}
	e -= (e - s) % st
	out := []int64{s}
	for out[len(out)-1] != e {
		out = append(out, out[len(out)-1]+st)
	}
	return out
}
func (MathNS) IsInt(a any) bool {
	_, err := strconv.ParseInt(toString(a), 0, 64)
	return err == nil && !strings.ContainsAny(toString(a), ".eE")
}
func (m MathNS) IsNum(a any) bool { return m.IsInt(a) || m.IsFloat(a) }
func (MathNS) IsFloat(a any) bool {
	s := toString(a)
	if _, ok := a.(float64); ok {
		return true
	}
	if _, ok := a.(float32); ok {
		return true
	}
	_, err := strconv.ParseFloat(s, 64)
	return err == nil && (strings.ContainsAny(s, ".eE") || s == "NaN" || strings.Contains(s, "Inf"))
}

type EnvNS struct{}

func (EnvNS) Getenv(k string, def ...string) string {
	if v, ok := os.LookupEnv(k); ok {
		return v
	}
	if p, ok := os.LookupEnv(k + "_FILE"); ok {
		b, err := os.ReadFile(p)
		if err == nil {
			return strings.TrimRight(string(b), "\r\n")
		}
	}
	if len(def) > 0 {
		return def[0]
	}
	return ""
}
func (EnvNS) Env() map[string]string { return envMap() }
func (EnvNS) HasEnv(k string) bool   { _, ok := os.LookupEnv(k); return ok }
func (e EnvNS) ExpandEnv(s string) string {
	return os.Expand(s, func(k string) string { return e.Getenv(k) })
}

type StringsNS struct{}

func (StringsNS) Contains(substr, input string) bool  { return strings.Contains(input, substr) }
func (StringsNS) HasPrefix(prefix, input string) bool { return strings.HasPrefix(input, prefix) }
func (StringsNS) HasSuffix(suffix, input string) bool { return strings.HasSuffix(input, suffix) }
func (StringsNS) Trim(input string, cut ...string) string {
	if len(cut) > 0 {
		return strings.Trim(input, cut[0])
	}
	return strings.TrimSpace(input)
}
func (StringsNS) TrimSpace(input string) string          { return strings.TrimSpace(input) }
func (StringsNS) TrimLeft(cut, input string) string      { return strings.TrimLeft(input, cut) }
func (StringsNS) TrimRight(cut, input string) string     { return strings.TrimRight(input, cut) }
func (StringsNS) TrimPrefix(prefix, input string) string { return strings.TrimPrefix(input, prefix) }
func (StringsNS) TrimSuffix(suffix, input string) string { return strings.TrimSuffix(input, suffix) }
func (StringsNS) ToUpper(s string) string                { return strings.ToUpper(s) }
func (StringsNS) ToLower(s string) string                { return strings.ToLower(s) }
func (StringsNS) Title(s string) string                  { return strings.Title(s) }
func (StringsNS) Split(sep, input string) []string       { return strings.Split(input, sep) }
func (StringsNS) SplitN(sep string, n any, input string) []string {
	return strings.SplitN(input, sep, int(toInt(n)))
}
func (StringsNS) Join(list any, sep string) string      { return joinAny(list, sep) }
func (StringsNS) Replace(old, new, input string) string { return strings.ReplaceAll(input, old, new) }
func (StringsNS) ReplaceAll(old, new, input string) string {
	return strings.ReplaceAll(input, old, new)
}
func (StringsNS) Repeat(count any, input string) string {
	return strings.Repeat(input, int(toInt(count)))
}
func (StringsNS) Quote(s string) string      { return strconv.Quote(s) }
func (StringsNS) Squote(s string) string     { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
func (StringsNS) ShellQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
func (StringsNS) Slug(s string) string {
	s = strings.ToLower(s)
	r := regexp.MustCompile(`[^a-z0-9]+`).ReplaceAllString(s, "-")
	return strings.Trim(r, "-")
}
func (StringsNS) CamelCase(s string) string {
	parts := words(s)
	for i := range parts {
		parts[i] = strings.Title(parts[i])
	}
	return strings.Join(parts, "")
}
func (StringsNS) SnakeCase(s string) string { return strings.Join(words(strings.ToLower(s)), "_") }
func (StringsNS) KebabCase(s string) string { return strings.Join(words(strings.ToLower(s)), "-") }
func (StringsNS) RuneCount(s string) int    { return len([]rune(s)) }
func (StringsNS) WordWrap(width any, s string) string {
	w := int(toInt(width))
	if w <= 0 {
		return s
	}
	var out, line []string
	n := 0
	for _, word := range strings.Fields(s) {
		if n > 0 && n+1+len(word) > w {
			out = append(out, strings.Join(line, " "))
			line = nil
			n = 0
		}
		line = append(line, word)
		if n == 0 {
			n = len(word)
		} else {
			n += 1 + len(word)
		}
	}
	if len(line) > 0 {
		out = append(out, strings.Join(line, " "))
	}
	return strings.Join(out, "\n")
}
func (StringsNS) Indent(args ...any) (string, error) {
	width := 1
	ind := " "
	input := ""
	if len(args) == 1 {
		input = toString(args[0])
	} else if len(args) == 2 {
		if isNumber(args[0]) {
			width = int(toInt(args[0]))
		} else {
			ind = toString(args[0])
		}
		input = toString(args[1])
	} else if len(args) >= 3 {
		width = int(toInt(args[0]))
		ind = toString(args[1])
		input = toString(args[2])
	}
	if width < 1 || strings.Contains(ind, "\n") {
		return "", errors.New("invalid indent")
	}
	prefix := strings.Repeat(ind, width)
	lines := strings.Split(input, "\n")
	for i := range lines {
		if lines[i] != "" {
			lines[i] = prefix + lines[i]
		}
	}
	return strings.Join(lines, "\n"), nil
}
func (StringsNS) SkipLines(skip any, in string) string {
	n := int(toInt(skip))
	for i := 0; i < n; i++ {
		idx := strings.IndexByte(in, '\n')
		if idx < 0 {
			return ""
		}
		in = in[idx+1:]
	}
	return in
}
func (StringsNS) Trunc(width any, s string) string {
	w := int(toInt(width))
	r := []rune(s)
	if len(r) <= abs(w) {
		return s
	}
	if w < 0 {
		return string(r[len(r)+w:])
	}
	return string(r[:w])
}
func (StringsNS) Abbrev(args ...any) string {
	off := 0
	width := 0
	s := ""
	if len(args) == 2 {
		width = int(toInt(args[0]))
		s = toString(args[1])
	} else if len(args) >= 3 {
		off = int(toInt(args[0]))
		width = int(toInt(args[1]))
		s = toString(args[2])
	}
	r := []rune(s)
	if len(r) <= width {
		return s
	}
	if width <= 3 {
		return string(r[:width])
	}
	if off >= 4 && off < len(r) {
		start := off
		if start+width-6 > len(r) {
			start = max(0, len(r)-width+3)
		}
		end := min(len(r), start+width-6)
		return "..." + string(r[start:end]) + "..."
	}
	return string(r[:width-3]) + "..."
}

type CollNS struct{}

func (CollNS) Slice(v ...any) []any { return v }
func (CollNS) Dict(v ...any) (map[string]any, error) {
	m := map[string]any{}
	for i := 0; i < len(v); i += 2 {
		if i+1 >= len(v) {
			return nil, errors.New("dict expects even arguments")
		}
		m[toString(v[i])] = v[i+1]
	}
	return m, nil
}
func (CollNS) Has(needle any, hay any) bool {
	rv := reflect.ValueOf(hay)
	switch rv.Kind() {
	case reflect.Slice, reflect.Array:
		for i := 0; i < rv.Len(); i++ {
			if reflect.DeepEqual(rv.Index(i).Interface(), needle) || toString(rv.Index(i).Interface()) == toString(needle) {
				return true
			}
		}
	case reflect.Map:
		return rv.MapIndex(reflect.ValueOf(needle)).IsValid()
	}
	return false
}
func (CollNS) Append(list any, v ...any) []any  { out := toSlice(list); return append(out, v...) }
func (CollNS) Prepend(list any, v ...any) []any { return append(v, toSlice(list)...) }
func (CollNS) GoSlice(v ...any) []any           { return v }
func (CollNS) Index(list any, idx any) any {
	rv := reflect.ValueOf(list)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		i := int(toInt(idx))
		if i >= 0 && i < rv.Len() {
			return rv.Index(i).Interface()
		}
	}
	return nil
}
func (CollNS) Keys(m any) []string {
	out := []string{}
	rv := reflect.ValueOf(m)
	if rv.Kind() == reflect.Map {
		for _, k := range rv.MapKeys() {
			out = append(out, toString(k.Interface()))
		}
		sort.Strings(out)
	}
	return out
}
func (CollNS) Values(m any) []any {
	out := []any{}
	rv := reflect.ValueOf(m)
	if rv.Kind() == reflect.Map {
		for _, k := range rv.MapKeys() {
			out = append(out, rv.MapIndex(k).Interface())
		}
	}
	return out
}
func (CollNS) Merge(ms ...any) map[string]any {
	out := map[string]any{}
	for _, m := range ms {
		for k, v := range toMap(m) {
			out[k] = v
		}
	}
	return out
}
func (CollNS) Uniq(list any) []any {
	out := []any{}
	seen := map[string]bool{}
	for _, v := range toSlice(list) {
		k := fmt.Sprintf("%#v", v)
		if !seen[k] {
			seen[k] = true
			out = append(out, v)
		}
	}
	return out
}
func (CollNS) Reverse(list any) []any {
	out := toSlice(list)
	for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
		out[i], out[j] = out[j], out[i]
	}
	return out
}
func (CollNS) Sort(list any) []string {
	out := []string{}
	for _, v := range toSlice(list) {
		out = append(out, toString(v))
	}
	sort.Strings(out)
	return out
}
func (CollNS) Flatten(list any) []any {
	out := []any{}
	var walk func(any)
	walk = func(v any) {
		rv := reflect.ValueOf(v)
		if rv.IsValid() && (rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array) {
			for i := 0; i < rv.Len(); i++ {
				walk(rv.Index(i).Interface())
			}
			return
		}
		out = append(out, v)
	}
	walk(list)
	return out
}
func (CollNS) Pick(m any, keys ...any) map[string]any {
	src := toMap(m)
	out := map[string]any{}
	for _, k := range keys {
		if v, ok := src[toString(k)]; ok {
			out[toString(k)] = v
		}
	}
	return out
}
func (CollNS) Omit(m any, keys ...any) map[string]any {
	out := toMap(m)
	for _, k := range keys {
		delete(out, toString(k))
	}
	return out
}
func (CollNS) Set(m any, key string, val any) map[string]any {
	out := toMap(m)
	out[key] = val
	return out
}
func (CollNS) Unset(m any, key string) map[string]any {
	out := toMap(m)
	delete(out, key)
	return out
}

type DataNS struct{}

func (DataNS) JSON(s string) (any, error) {
	var v any
	err := json.Unmarshal([]byte(s), &v)
	return v, err
}
func (DataNS) JSONArray(s string) (any, error) {
	var v []any
	err := json.Unmarshal([]byte(s), &v)
	return v, err
}
func (DataNS) ToJSON(v any) (string, error) { b, err := json.Marshal(v); return string(b), err }
func (DataNS) ToJSONPretty(args ...any) (string, error) {
	indent := "  "
	v := any(nil)
	if len(args) == 1 {
		v = args[0]
	} else if len(args) >= 2 {
		indent = toString(args[0])
		v = args[1]
	}
	b, err := json.MarshalIndent(v, "", indent)
	return string(b), err
}
func (DataNS) YAML(s string) (any, error)      { return parseSimpleYAML(s), nil }
func (DataNS) YAMLArray(s string) (any, error) { return parseSimpleYAML(s), nil }
func (DataNS) TOML(s string) (any, error)      { return parseTOML(s), nil }
func (DataNS) ToYAML(v any) (string, error)    { return toYAML(v, 0), nil }
func (DataNS) CSV(s string) ([][]string, error) {
	r := csv.NewReader(strings.NewReader(s))
	return r.ReadAll()
}
func (DataNS) ToCSV(v any) (string, error) {
	rows := [][]string{}
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Slice {
		for i := 0; i < rv.Len(); i++ {
			row := []string{}
			rr := reflect.ValueOf(rv.Index(i).Interface())
			if rr.Kind() == reflect.Slice {
				for j := 0; j < rr.Len(); j++ {
					row = append(row, toString(rr.Index(j).Interface()))
				}
			} else {
				row = []string{toString(rv.Index(i).Interface())}
			}
			rows = append(rows, row)
		}
	}
	var b bytes.Buffer
	w := csv.NewWriter(&b)
	err := w.WriteAll(rows)
	return b.String(), err
}

type FileNS struct{}

func (FileNS) Read(p string) (string, error)      { b, err := os.ReadFile(p); return string(b), err }
func (FileNS) Exists(p string) bool               { _, err := os.Stat(p); return err == nil }
func (FileNS) Stat(p string) (os.FileInfo, error) { return os.Stat(p) }
func (FileNS) IsDir(p string) bool                { st, err := os.Stat(p); return err == nil && st.IsDir() }
func (FileNS) ReadDir(p string) ([]string, error) {
	ents, err := os.ReadDir(p)
	if err != nil {
		return nil, err
	}
	out := []string{}
	for _, e := range ents {
		out = append(out, e.Name())
	}
	return out, nil
}
func (FileNS) Write(p, s string) (string, error) { return "", os.WriteFile(p, []byte(s), 0644) }

type PathNS struct{}

func (PathNS) Base(s string) string                     { return path.Base(s) }
func (PathNS) Dir(s string) string                      { return path.Dir(s) }
func (PathNS) Ext(s string) string                      { return path.Ext(s) }
func (PathNS) Clean(s string) string                    { return path.Clean(s) }
func (PathNS) Join(v ...string) string                  { return path.Join(v...) }
func (PathNS) IsAbs(s string) bool                      { return path.IsAbs(s) }
func (PathNS) Match(pattern, name string) (bool, error) { return path.Match(pattern, name) }
func (PathNS) Split(s string) []string                  { d, b := path.Split(s); return []string{d, b} }

type FilepathNS struct{}

func (FilepathNS) Base(s string) string                     { return filepath.Base(s) }
func (FilepathNS) Dir(s string) string                      { return filepath.Dir(s) }
func (FilepathNS) Ext(s string) string                      { return filepath.Ext(s) }
func (FilepathNS) Clean(s string) string                    { return filepath.Clean(s) }
func (FilepathNS) Join(v ...string) string                  { return filepath.Join(v...) }
func (FilepathNS) Abs(s string) (string, error)             { return filepath.Abs(s) }
func (FilepathNS) Glob(s string) ([]string, error)          { return filepath.Glob(s) }
func (FilepathNS) FromSlash(s string) string                { return filepath.FromSlash(s) }
func (FilepathNS) ToSlash(s string) string                  { return filepath.ToSlash(s) }
func (FilepathNS) IsAbs(s string) bool                      { return filepath.IsAbs(s) }
func (FilepathNS) Match(pattern, name string) (bool, error) { return filepath.Match(pattern, name) }
func (FilepathNS) Rel(base, target string) (string, error)  { return filepath.Rel(base, target) }
func (FilepathNS) VolumeName(s string) string               { return filepath.VolumeName(s) }

type RegexpNS struct{}

func (RegexpNS) Match(expr, s string) (bool, error) { return regexp.MatchString(expr, s) }
func (RegexpNS) Replace(expr, repl, s string) (string, error) {
	r, err := regexp.Compile(expr)
	if err != nil {
		return "", err
	}
	return r.ReplaceAllString(s, repl), nil
}
func (RegexpNS) Find(expr, s string) (string, error) {
	r, err := regexp.Compile(expr)
	if err != nil {
		return "", err
	}
	return r.FindString(s), nil
}
func (RegexpNS) FindAll(expr, s string) ([]string, error) {
	r, err := regexp.Compile(expr)
	if err != nil {
		return nil, err
	}
	return r.FindAllString(s, -1), nil
}
func (RegexpNS) Split(expr, s string) ([]string, error) {
	r, err := regexp.Compile(expr)
	if err != nil {
		return nil, err
	}
	return r.Split(s, -1), nil
}
func (RegexpNS) QuoteMeta(s string) string { return regexp.QuoteMeta(s) }
func (RegexpNS) ReplaceLiteral(expr, repl, s string) (string, error) {
	r, err := regexp.Compile(expr)
	if err != nil {
		return "", err
	}
	return r.ReplaceAllLiteralString(s, repl), nil
}

type Base64NS struct{}

func (Base64NS) Encode(s string) string { return base64.StdEncoding.EncodeToString([]byte(s)) }
func (Base64NS) Decode(s string) (string, error) {
	b, err := base64.StdEncoding.DecodeString(s)
	return string(b), err
}
func (Base64NS) URLEncode(s string) string { return base64.URLEncoding.EncodeToString([]byte(s)) }
func (Base64NS) URLDecode(s string) (string, error) {
	b, err := base64.URLEncoding.DecodeString(s)
	return string(b), err
}
func (Base64NS) DecodeBytes(s string) ([]byte, error) { return base64.StdEncoding.DecodeString(s) }

type ConvNS struct{}

func (ConvNS) Bool(v any) bool { b, _ := strconv.ParseBool(toString(v)); return b }
func (ConvNS) Default(def, v any) any {
	if v == nil || v == "" || v == false || v == 0 {
		return def
	}
	return v
}
func (ConvNS) Join(list any, sep string) string { return joinAny(list, sep) }
func (ConvNS) URL(s string) (*url.URL, error)   { return url.Parse(s) }
func (ConvNS) ParseInt(s string, base, bitSize any) (int64, error) {
	return strconv.ParseInt(s, int(toInt(base)), int(toInt(bitSize)))
}
func (ConvNS) ParseUint(s string, base, bitSize any) (uint64, error) {
	return strconv.ParseUint(s, int(toInt(base)), int(toInt(bitSize)))
}
func (ConvNS) ParseFloat(s string, bitSize any) (float64, error) {
	return strconv.ParseFloat(s, int(toInt(bitSize)))
}
func (ConvNS) Atoi(s string) (int, error) { return strconv.Atoi(s) }
func (ConvNS) ToBool(v any) bool          { return ConvNS{}.Bool(v) }
func (ConvNS) ToInt64(v any) int64        { return toInt(v) }
func (ConvNS) ToInt(v any) int            { return int(toInt(v)) }
func (ConvNS) ToFloat64(v any) float64    { return toFloat(v) }
func (ConvNS) ToString(v any) string      { return toString(v) }
func (ConvNS) ToStrings(v any) []string {
	out := []string{}
	for _, x := range toSlice(v) {
		out = append(out, toString(x))
	}
	if len(out) == 0 && v != nil {
		out = append(out, toString(v))
	}
	return out
}
func (ConvNS) ToInts(v any) []int {
	out := []int{}
	for _, x := range toSlice(v) {
		out = append(out, int(toInt(x)))
	}
	return out
}
func (ConvNS) ToInt64s(v any) []int64 {
	out := []int64{}
	for _, x := range toSlice(v) {
		out = append(out, toInt(x))
	}
	return out
}
func (ConvNS) ToFloat64s(v any) []float64 {
	out := []float64{}
	for _, x := range toSlice(v) {
		out = append(out, toFloat(x))
	}
	return out
}
func (ConvNS) ToBools(v any) []bool {
	out := []bool{}
	for _, x := range toSlice(v) {
		out = append(out, ConvNS{}.Bool(x))
	}
	return out
}

type CryptoNS struct{}

func (CryptoNS) SHA1(s string) string { h := sha1.Sum([]byte(s)); return hex.EncodeToString(h[:]) }
func (CryptoNS) SHA256(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}
func (CryptoNS) SHA512(s string) string {
	h := sha512.Sum512([]byte(s))
	return hex.EncodeToString(h[:])
}
func (CryptoNS) SHA384(s string) string {
	h := sha512.Sum384([]byte(s))
	return hex.EncodeToString(h[:])
}
func (CryptoNS) SHA224(s string) string {
	h := sha256.Sum224([]byte(s))
	return hex.EncodeToString(h[:])
}
func (CryptoNS) SHA512_224(s string) string {
	h := sha512.Sum512_224([]byte(s))
	return hex.EncodeToString(h[:])
}
func (CryptoNS) SHA512_256(s string) string {
	h := sha512.Sum512_256([]byte(s))
	return hex.EncodeToString(h[:])
}
func (CryptoNS) MD5(s string) string         { h := md5.Sum([]byte(s)); return hex.EncodeToString(h[:]) }
func (CryptoNS) SHA1Bytes(b []byte) string   { h := sha1.Sum(b); return hex.EncodeToString(h[:]) }
func (CryptoNS) SHA256Bytes(b []byte) string { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }

type RandomNS struct{}

func (RandomNS) String(n any, chars ...string) string {
	alphabet := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	if len(chars) > 0 && chars[0] != "" {
		alphabet = chars[0]
	}
	b := make([]byte, int(toInt(n)))
	rb := make([]byte, len(b))
	_, _ = crand.Read(rb)
	for i := range b {
		b[i] = alphabet[int(rb[i])%len(alphabet)]
	}
	return string(b)
}
func (r RandomNS) Alpha(n any) string {
	return r.String(n, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
}
func (r RandomNS) AlphaNum(n any) string { return r.String(n) }
func (r RandomNS) ASCII(n any) string {
	return r.String(n, " !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")
}
func (RandomNS) Number(minv, maxv any) int64 {
	min, max := toInt(minv), toInt(maxv)
	if max <= min {
		return min
	}
	var b [8]byte
	_, _ = crand.Read(b[:])
	n := int64(0)
	for _, x := range b[:] {
		n = (n << 8) + int64(x)
	}
	if n < 0 {
		n = -n
	}
	return min + n%(max-min+1)
}
func (RandomNS) Float() float64 { return float64(time.Now().UnixNano()%1000000) / 1000000 }
func (RandomNS) Item(list any) any {
	s := toSlice(list)
	if len(s) == 0 {
		return nil
	}
	return s[time.Now().Nanosecond()%len(s)]
}

type UUIDNS struct{}

func (UUIDNS) Nil() string { return "00000000-0000-0000-0000-000000000000" }
func (UUIDNS) V4() string {
	b := make([]byte, 16)
	_, _ = crand.Read(b)
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}
func (u UUIDNS) V1() string { return u.V4() }

type TestNS struct{}

func (TestNS) Assert(cond bool, msg ...string) (string, error) {
	if !cond {
		if len(msg) > 0 {
			return "", errors.New(msg[0])
		}
		return "", errors.New("assertion failed")
	}
	return "", nil
}
func (TestNS) Fail(msg string) (string, error) { return "", errors.New(msg) }
func (TestNS) Kind(v any) string {
	if v == nil {
		return "invalid"
	}
	return reflect.TypeOf(v).Kind().String()
}
func (t TestNS) IsKind(k string, v any) bool { return t.Kind(v) == k }
func (TestNS) Required(msg string, v any) (any, error) {
	if v == nil || v == "" {
		return nil, errors.New(msg)
	}
	return v, nil
}
func (TestNS) Ternary(cond bool, a, b any) any {
	if cond {
		return a
	}
	return b
}

type TimeNS struct{}

func (TimeNS) Now() time.Time                                { return time.Now() }
func (TimeNS) Parse(layout, value string) (time.Time, error) { return time.Parse(layout, value) }
func (TimeNS) Format(layout string, t any) string {
	if tt, ok := t.(time.Time); ok {
		return tt.Format(layout)
	}
	return toString(t)
}
func (TimeNS) Unix(sec any) time.Time { return time.Unix(toInt(sec), 0) }

type NetNS struct{}

func (NetNS) LookupIP(name string) (string, error) {
	ips, err := NetNS{}.LookupIPs(name)
	if err != nil || len(ips) == 0 {
		return "", err
	}
	return ips[0], nil
}
func (NetNS) LookupIPs(name string) ([]string, error) {
	addrs, err := net.DefaultResolver.LookupIPAddr(context.Background(), name)
	if err != nil {
		return nil, err
	}
	out := []string{}
	seen := map[string]bool{}
	for _, a := range addrs {
		if a.IP.To4() != nil {
			s := a.IP.String()
			if !seen[s] {
				seen[s] = true
				out = append(out, s)
			}
		}
	}
	return out, nil
}
func (NetNS) LookupCNAME(name string) (string, error) { return net.LookupCNAME(name) }
func (NetNS) LookupTXT(name string) ([]string, error) { return net.LookupTXT(name) }
func (NetNS) LookupSRVs(name string) ([]*net.SRV, error) {
	_, a, err := net.LookupSRV("", "", name)
	return a, err
}
func (NetNS) LookupSRV(name string) (*net.SRV, error) {
	a, err := NetNS{}.LookupSRVs(name)
	if err != nil || len(a) == 0 {
		return nil, err
	}
	return a[0], nil
}

func (e *engine) datasourceFunc(args ...any) (any, error) {
	if len(args) == 0 {
		return nil, errors.New("datasource name required")
	}
	name := toString(args[0])
	if len(args) > 1 {
		name = name + toString(args[1])
	}
	return e.datasource(name)
}
func (e *engine) datasource(name string) (any, error) {
	key := name
	if strings.HasPrefix(name, "@ctx:") {
		key = strings.TrimPrefix(name, "@ctx:")
	}
	if v, ok := e.cache[key]; ok {
		return v, nil
	}
	src, ok := e.datasources[key]
	if !ok {
		src = name
	}
	b, err := e.readSource(src)
	if err != nil {
		return nil, err
	}
	val := parseByName(src, b)
	e.cache[key] = val
	return val, nil
}
func (e *engine) readSource(src string) ([]byte, error) {
	if src == "-" || src == "stdin:" || src == "stdin:///" {
		if e.stdin != nil {
			return e.stdin, nil
		}
		return io.ReadAll(os.Stdin)
	}
	if strings.HasPrefix(src, "env://") || src == "env:" {
		return []byte(mustJSON(envMap())), nil
	}
	if u, err := url.Parse(src); err == nil && u.Scheme != "" {
		if u.Scheme == "file" {
			return os.ReadFile(u.Path)
		}
		if u.Scheme == "stdin" {
			return io.ReadAll(os.Stdin)
		}
	}
	return os.ReadFile(src)
}

// helpers
func splitKV(s string) (string, string, error) {
	i := strings.Index(s, "=")
	if i < 0 {
		return "", "", fmt.Errorf("invalid key=value: %s", s)
	}
	return s[:i], s[i+1:], nil
}
func fatalIf(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}
func getenvDefault(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}
func envMap() map[string]string {
	m := map[string]string{}
	for _, e := range os.Environ() {
		p := strings.SplitN(e, "=", 2)
		m[p[0]] = p[1]
	}
	return m
}
func normalizeRoot(v any) map[string]any {
	m := toMap(v)
	if len(m) > 0 {
		return m
	}
	return map[string]any{"Value": v, "Env": envMap()}
}
func readInputs(files []string) ([]byte, error) {
	var out bytes.Buffer
	for _, f := range files {
		var b []byte
		var err error
		if f == "-" {
			b, err = io.ReadAll(os.Stdin)
		} else {
			b, err = os.ReadFile(f)
		}
		if err != nil {
			return nil, err
		}
		out.Write(b)
	}
	return out.Bytes(), nil
}
func maybeChmod(p, m string) {
	if m == "" {
		return
	}
	u, err := strconv.ParseUint(m, 8, 32)
	if err == nil {
		_ = os.Chmod(p, os.FileMode(u))
	}
}
func matchInclude(rel string, inc, exc []string) bool {
	if len(inc) > 0 && !matchesAny(rel, inc) {
		return false
	}
	if matchesAny(rel, exc) {
		return false
	}
	return true
}
func matchesAny(rel string, pats []string) bool {
	for _, p := range pats {
		if ok, _ := filepath.Match(p, filepath.Base(rel)); ok {
			return true
		}
		if ok, _ := filepath.Match(p, rel); ok {
			return true
		}
	}
	return false
}
func toString(v any) string {
	if v == nil {
		return ""
	}
	switch x := v.(type) {
	case string:
		return x
	case []byte:
		return string(x)
	default:
		return fmt.Sprint(x)
	}
}
func isNumber(v any) bool {
	switch v.(type) {
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64, float32, float64:
		return true
	}
	_, err := strconv.ParseFloat(toString(v), 64)
	return err == nil
}
func toFloat(v any) float64 {
	switch x := v.(type) {
	case int:
		return float64(x)
	case int64:
		return float64(x)
	case int32:
		return float64(x)
	case uint:
		return float64(x)
	case uint64:
		return float64(x)
	case float64:
		return x
	case float32:
		return float64(x)
	}
	s := toString(v)
	if strings.HasPrefix(s, "0x") || strings.HasPrefix(s, "0X") || regexp.MustCompile(`^0[0-7]+$`).MatchString(s) {
		i, _ := strconv.ParseInt(s, 0, 64)
		return float64(i)
	}
	f, _ := strconv.ParseFloat(s, 64)
	return f
}
func toInt(v any) int64 {
	switch x := v.(type) {
	case int:
		return int64(x)
	case int64:
		return x
	case int32:
		return int64(x)
	case uint:
		return int64(x)
	case uint64:
		return int64(x)
	case float64:
		return int64(x)
	case float32:
		return int64(x)
	}
	if i, err := strconv.ParseInt(toString(v), 0, 64); err == nil {
		return i
	}
	f, _ := strconv.ParseFloat(toString(v), 64)
	return int64(f)
}
func isFloatLike(v any) bool {
	switch v.(type) {
	case float32, float64:
		return true
	}
	s := toString(v)
	return strings.ContainsAny(s, ".eE") || s == "NaN" || strings.Contains(s, "Inf")
}
func cleanFloat(f float64) any { return f }
func abs(i int) int {
	if i < 0 {
		return -i
	}
	return i
}
func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
func joinAny(list any, sep string) string {
	ss := []string{}
	rv := reflect.ValueOf(list)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		for i := 0; i < rv.Len(); i++ {
			ss = append(ss, toString(rv.Index(i).Interface()))
		}
	} else {
		ss = []string{toString(list)}
	}
	return strings.Join(ss, sep)
}
func words(s string) []string {
	raw := regexp.MustCompile(`[A-Za-z0-9]+`).FindAllString(s, -1)
	out := []string{}
	for _, w := range raw {
		if w != "" {
			out = append(out, strings.ToLower(w))
		}
	}
	return out
}
func toSlice(v any) []any {
	out := []any{}
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		for i := 0; i < rv.Len(); i++ {
			out = append(out, rv.Index(i).Interface())
		}
	}
	return out
}
func toMap(v any) map[string]any {
	if m, ok := v.(map[string]any); ok {
		return m
	}
	out := map[string]any{}
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Map {
		for _, k := range rv.MapKeys() {
			out[toString(k.Interface())] = rv.MapIndex(k).Interface()
		}
	}
	return out
}
func mustJSON(v any) string { b, _ := json.Marshal(v); return string(b) }
func parseByName(name string, b []byte) any {
	s := string(b)
	q := name
	if u, err := url.Parse(name); err == nil {
		q = u.Path
		if typ := u.Query().Get("type"); strings.Contains(typ, "json") {
			q += ".json"
		} else if strings.Contains(typ, "yaml") {
			q += ".yaml"
		} else if strings.Contains(typ, "csv") {
			q += ".csv"
		}
	}
	ext := strings.ToLower(filepath.Ext(q))
	switch ext {
	case ".json":
		var v any
		if json.Unmarshal(b, &v) == nil {
			return v
		}
	case ".yaml", ".yml":
		return parseSimpleYAML(s)
	case ".toml":
		return parseTOML(s)
	case ".csv":
		r := csv.NewReader(strings.NewReader(s))
		rows, _ := r.ReadAll()
		return rows
	case ".env":
		return parseEnv(s)
	}
	var v any
	if json.Unmarshal(b, &v) == nil {
		return v
	}
	return s
}
func parseEnv(s string) map[string]string {
	m := map[string]string{}
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.TrimPrefix(line, "export ")
		p := strings.SplitN(line, "=", 2)
		if len(p) == 2 {
			m[strings.TrimSpace(p[0])] = strings.Trim(strings.TrimSpace(p[1]), "\"'")
		}
	}
	return m
}
func parseSimpleYAML(s string) any {
	lines := strings.Split(s, "\n")
	for _, line := range lines {
		t := strings.TrimSpace(line)
		if t == "" || strings.HasPrefix(t, "#") {
			continue
		}
		if strings.HasPrefix(t, "-") {
			arr := []any{}
			for _, l := range lines {
				l = strings.TrimSpace(l)
				if strings.HasPrefix(l, "-") {
					arr = append(arr, parseScalar(strings.TrimSpace(strings.TrimPrefix(l, "-"))))
				}
			}
			return arr
		}
		break
	}
	root := map[string]any{}
	type frame struct {
		indent int
		m      map[string]any
	}
	stack := []frame{{-1, root}}
	for _, line := range lines {
		if strings.TrimSpace(line) == "" || strings.HasPrefix(strings.TrimSpace(line), "#") {
			continue
		}
		indent := len(line) - len(strings.TrimLeft(line, " "))
		for len(stack) > 1 && indent <= stack[len(stack)-1].indent {
			stack = stack[:len(stack)-1]
		}
		p := strings.SplitN(strings.TrimSpace(line), ":", 2)
		if len(p) != 2 {
			continue
		}
		key := strings.TrimSpace(p[0])
		val := strings.TrimSpace(p[1])
		parent := stack[len(stack)-1].m
		if val == "" {
			child := map[string]any{}
			parent[key] = child
			stack = append(stack, frame{indent, child})
		} else {
			parent[key] = parseScalar(val)
		}
	}
	return root
}
func parseTOML(s string) any {
	root := map[string]any{}
	cur := root
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			cur = root
			for _, part := range strings.Split(strings.Trim(line, "[]"), ".") {
				if _, ok := cur[part]; !ok {
					cur[part] = map[string]any{}
				}
				cur, _ = cur[part].(map[string]any)
			}
			continue
		}
		p := strings.SplitN(line, "=", 2)
		if len(p) == 2 {
			cur[strings.TrimSpace(p[0])] = parseScalar(strings.TrimSpace(p[1]))
		}
	}
	return root
}
func parseScalar(s string) any {
	s = strings.Trim(s, "\"'")
	if s == "true" {
		return true
	}
	if s == "false" {
		return false
	}
	if i, err := strconv.ParseInt(s, 10, 64); err == nil {
		return i
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil {
		return f
	}
	return s
}
func toYAML(v any, ind int) string {
	pad := strings.Repeat(" ", ind)
	switch x := v.(type) {
	case map[string]any:
		keys := []string{}
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		var b strings.Builder
		for _, k := range keys {
			val := x[k]
			if reflect.ValueOf(val).Kind() == reflect.Map {
				fmt.Fprintf(&b, "%s%s:\n%s", pad, k, toYAML(val, ind+2))
			} else {
				fmt.Fprintf(&b, "%s%s: %v\n", pad, k, val)
			}
		}
		return b.String()
	case []any:
		var b strings.Builder
		for _, v := range x {
			fmt.Fprintf(&b, "%s- %v\n", pad, v)
		}
		return b.String()
	default:
		return fmt.Sprintf("%s%v\n", pad, v)
	}
}

var _ = sha1.Sum
var _ = sha256.Sum256
var _ = hex.EncodeToString
