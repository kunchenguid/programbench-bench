package main

import (
	"encoding/binary"
	"math/bits"
)

const (
	blockLen = 64
	chunkLen = 1024

	flagChunkStart        uint32 = 1
	flagChunkEnd          uint32 = 2
	flagParent            uint32 = 4
	flagRoot              uint32 = 8
	flagKeyedHash         uint32 = 16
	flagDeriveKeyContext  uint32 = 32
	flagDeriveKeyMaterial uint32 = 64
)

var iv = [8]uint32{
	0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
	0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
}

var msgPerm = [16]uint8{2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8}

type blake3Output struct {
	cv       [8]uint32
	block    [16]uint32
	counter  uint64
	blockLen uint32
	flags    uint32
}

func wordsFromBytes(b []byte) [16]uint32 {
	var out [16]uint32
	for i := 0; i < len(b); i += 4 {
		var tmp [4]byte
		n := copy(tmp[:], b[i:])
		if n > 0 {
			out[i/4] = binary.LittleEndian.Uint32(tmp[:])
		}
	}
	return out
}

func bytesFromWords(words [16]uint32) [64]byte {
	var out [64]byte
	for i, w := range words {
		binary.LittleEndian.PutUint32(out[i*4:], w)
	}
	return out
}

func g(s *[16]uint32, a, b, c, d int, mx, my uint32) {
	s[a] = s[a] + s[b] + mx
	s[d] = bits.RotateLeft32(s[d]^s[a], -16)
	s[c] += s[d]
	s[b] = bits.RotateLeft32(s[b]^s[c], -12)
	s[a] = s[a] + s[b] + my
	s[d] = bits.RotateLeft32(s[d]^s[a], -8)
	s[c] += s[d]
	s[b] = bits.RotateLeft32(s[b]^s[c], -7)
}

func round(s *[16]uint32, m [16]uint32) {
	g(s, 0, 4, 8, 12, m[0], m[1])
	g(s, 1, 5, 9, 13, m[2], m[3])
	g(s, 2, 6, 10, 14, m[4], m[5])
	g(s, 3, 7, 11, 15, m[6], m[7])
	g(s, 0, 5, 10, 15, m[8], m[9])
	g(s, 1, 6, 11, 12, m[10], m[11])
	g(s, 2, 7, 8, 13, m[12], m[13])
	g(s, 3, 4, 9, 14, m[14], m[15])
}

func permute(m [16]uint32) [16]uint32 {
	var p [16]uint32
	for i := range p {
		p[i] = m[msgPerm[i]]
	}
	return p
}

func compress(cv [8]uint32, block [16]uint32, counter uint64, blen uint32, flags uint32) [16]uint32 {
	var s [16]uint32
	copy(s[0:8], cv[:])
	copy(s[8:12], iv[0:4])
	s[12] = uint32(counter)
	s[13] = uint32(counter >> 32)
	s[14] = blen
	s[15] = flags
	m := block
	for i := 0; i < 7; i++ {
		round(&s, m)
		m = permute(m)
	}
	var out [16]uint32
	for i := 0; i < 8; i++ {
		out[i] = s[i] ^ s[i+8]
		out[i+8] = s[i+8] ^ cv[i]
	}
	return out
}

func chainingValue(out blake3Output) [8]uint32 {
	words := compress(out.cv, out.block, out.counter, out.blockLen, out.flags)
	var cv [8]uint32
	copy(cv[:], words[:8])
	return cv
}

func parentOutput(left, right [8]uint32, key [8]uint32, flags uint32) blake3Output {
	var block [16]uint32
	copy(block[0:8], left[:])
	copy(block[8:16], right[:])
	return blake3Output{cv: key, block: block, blockLen: blockLen, flags: flags | flagParent}
}

func parentCV(left, right [8]uint32, key [8]uint32, flags uint32) [8]uint32 {
	return chainingValue(parentOutput(left, right, key, flags))
}

func leftLen(n int) int {
	p := 1
	for p*2 < n {
		p *= 2
	}
	return p
}

func subtreeCV(cvs [][8]uint32, key [8]uint32, flags uint32) [8]uint32 {
	if len(cvs) == 1 {
		return cvs[0]
	}
	split := leftLen(len(cvs))
	return parentCV(subtreeCV(cvs[:split], key, flags), subtreeCV(cvs[split:], key, flags), key, flags)
}

func chunkOutput(chunk []byte, counter uint64, key [8]uint32, flags uint32) blake3Output {
	cv := key
	if len(chunk) == 0 {
		return blake3Output{cv: cv, counter: counter, blockLen: 0, flags: flags | flagChunkStart | flagChunkEnd}
	}
	for offset := 0; offset < len(chunk); offset += blockLen {
		end := offset + blockLen
		if end > len(chunk) {
			end = len(chunk)
		}
		block := wordsFromBytes(chunk[offset:end])
		blen := uint32(end - offset)
		bflags := flags
		if offset == 0 {
			bflags |= flagChunkStart
		}
		if end == len(chunk) {
			bflags |= flagChunkEnd
			return blake3Output{cv: cv, block: block, counter: counter, blockLen: blen, flags: bflags}
		}
		words := compress(cv, block, counter, blen, bflags)
		copy(cv[:], words[:8])
	}
	panic("unreachable")
}

func rootBytes(out blake3Output, seek uint64, length int) []byte {
	res := make([]byte, 0, length)
	blockCounter := seek / 64
	skip := int(seek % 64)
	for len(res) < length {
		words := compress(out.cv, out.block, blockCounter, out.blockLen, out.flags|flagRoot)
		block := bytesFromWords(words)
		part := block[skip:]
		need := length - len(res)
		if len(part) > need {
			part = part[:need]
		}
		res = append(res, part...)
		blockCounter++
		skip = 0
	}
	return res
}

func keyWords(key []byte) [8]uint32 {
	var out [8]uint32
	for i := range out {
		out[i] = binary.LittleEndian.Uint32(key[i*4:])
	}
	return out
}

func hashWithKey(data []byte, key [8]uint32, flags uint32, seek uint64, outLen int) []byte {
	if len(data) <= chunkLen {
		out := chunkOutput(data, 0, key, flags)
		return rootBytes(out, seek, outLen)
	}
	chunks := (len(data) + chunkLen - 1) / chunkLen
	cvs := make([][8]uint32, chunks)
	for i := 0; i < chunks; i++ {
		start := i * chunkLen
		end := start + chunkLen
		if end > len(data) {
			end = len(data)
		}
		cvs[i] = chainingValue(chunkOutput(data[start:end], uint64(i), key, flags))
	}
	split := leftLen(len(cvs))
	out := parentOutput(subtreeCV(cvs[:split], key, flags), subtreeCV(cvs[split:], key, flags), key, flags)
	return rootBytes(out, seek, outLen)
}

func blake3Hash(data []byte, seek uint64, outLen int) []byte {
	return hashWithKey(data, iv, 0, seek, outLen)
}

func blake3Keyed(data, key []byte, seek uint64, outLen int) []byte {
	return hashWithKey(data, keyWords(key), flagKeyedHash, seek, outLen)
}

func blake3DeriveKey(context string, material []byte, seek uint64, outLen int) []byte {
	contextKey := hashWithKey([]byte(context), iv, flagDeriveKeyContext, 0, 32)
	return hashWithKey(material, keyWords(contextKey), flagDeriveKeyMaterial, seek, outLen)
}
