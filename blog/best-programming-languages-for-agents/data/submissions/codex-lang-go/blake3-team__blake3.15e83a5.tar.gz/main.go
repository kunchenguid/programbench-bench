package main

import (
	"bufio"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
)

type options struct {
	keyed     bool
	derive    string
	hasDerive bool
	length    int
	lengthSet bool
	seek      uint64
	noNames   bool
	raw       bool
	tag       bool
	check     bool
	quiet     bool
	files     []string
}

const helpLong = `Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...
          Files to hash, or checkfiles to check
          
          When no file is given, or when - is given, read standard input.

Options:
      --keyed
          Use the keyed mode, reading the 32-byte key from stdin

      --derive-key <CONTEXT>
          Use the key derivation mode, with the given context string
          
          Cannot be used with --keyed.

  -l, --length <LEN>
          The number of output bytes, before hex encoding
          
          [default: 32]

      --seek <SEEK>
          The starting output byte offset, before hex encoding
          
          [default: 0]

      --num-threads <NUM>
          The maximum number of threads to use
          
          By default, this is the number of logical cores. If this flag is omitted, or if its value
          is 0, RAYON_NUM_THREADS is also respected.

      --no-mmap
          Disable memory mapping
          
          Currently this also disables multithreading.

      --no-names
          Omit filenames in the output

      --raw
          Write raw output bytes to stdout, rather than hex
          
          --no-names is implied. In this case, only a single input is allowed.

      --tag
          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]

  -c, --check
          Read BLAKE3 sums from the [FILE]s and check them

      --quiet
          Skip printing OK for each checked file
          
          Must be used with --check.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`

const helpShort = `Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...  Files to hash, or checkfiles to check

Options:
      --keyed                 Use the keyed mode, reading the 32-byte key from stdin
      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string
  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]
      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]
      --num-threads <NUM>     The maximum number of threads to use
      --no-mmap               Disable memory mapping
      --no-names              Omit filenames in the output
      --raw                   Write raw output bytes to stdout, rather than hex
      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]
  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them
      --quiet                 Skip printing OK for each checked file
  -h, --help                  Print help (see more with '--help')
  -V, --version               Print version
`

func parseArgs(args []string) (options, error) {
	o := options{length: 32}
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch {
		case a == "--":
			o.files = append(o.files, args[i+1:]...)
			return o, nil
		case a == "--keyed":
			o.keyed = true
		case a == "--derive-key":
			i++
			if i >= len(args) {
				return o, errors.New("a value is required for '--derive-key <CONTEXT>' but none was supplied")
			}
			o.derive, o.hasDerive = args[i], true
		case strings.HasPrefix(a, "--derive-key="):
			o.derive, o.hasDerive = strings.TrimPrefix(a, "--derive-key="), true
		case a == "-l" || a == "--length":
			i++
			if i >= len(args) {
				return o, errors.New("a value is required for '--length <LEN>' but none was supplied")
			}
			n, err := strconv.Atoi(args[i])
			if err != nil || n < 0 {
				return o, fmt.Errorf("invalid value '%s' for '--length <LEN>': invalid digit found in string", args[i])
			}
			o.length = n
			o.lengthSet = true
		case strings.HasPrefix(a, "--length="):
			s := strings.TrimPrefix(a, "--length=")
			n, err := strconv.Atoi(s)
			if err != nil || n < 0 {
				return o, fmt.Errorf("invalid value '%s' for '--length <LEN>': invalid digit found in string", s)
			}
			o.length = n
			o.lengthSet = true
		case a == "--seek":
			i++
			if i >= len(args) {
				return o, errors.New("a value is required for '--seek <SEEK>' but none was supplied")
			}
			n, err := strconv.ParseUint(args[i], 10, 64)
			if err != nil {
				return o, fmt.Errorf("invalid value '%s' for '--seek <SEEK>': invalid digit found in string", args[i])
			}
			o.seek = n
		case strings.HasPrefix(a, "--seek="):
			s := strings.TrimPrefix(a, "--seek=")
			n, err := strconv.ParseUint(s, 10, 64)
			if err != nil {
				return o, fmt.Errorf("invalid value '%s' for '--seek <SEEK>': invalid digit found in string", s)
			}
			o.seek = n
		case a == "--num-threads":
			i++
			if i >= len(args) {
				return o, errors.New("a value is required for '--num-threads <NUM>' but none was supplied")
			}
		case strings.HasPrefix(a, "--num-threads="):
		case a == "--no-mmap":
		case a == "--no-names":
			o.noNames = true
		case a == "--raw":
			o.raw, o.noNames = true, true
		case a == "--tag":
			o.tag = true
		case a == "-c" || a == "--check":
			o.check = true
		case a == "--quiet":
			o.quiet = true
		case a == "-h":
			fmt.Print(helpShort)
			os.Exit(0)
		case a == "--help":
			fmt.Print(helpLong)
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Println("b3sum 1.8.4")
			os.Exit(0)
		case strings.HasPrefix(a, "-") && a != "-":
			return o, fmt.Errorf("unexpected argument '%s' found", a)
		default:
			o.files = append(o.files, a)
		}
	}
	if o.keyed && o.hasDerive {
		return o, errors.New("the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'")
	}
	if o.quiet && !o.check {
		return o, errors.New("the argument '--quiet' requires '--check'")
	}
	if o.check && o.keyed {
		return o, errors.New("the argument '--check' cannot be used with '--keyed'")
	}
	if o.check && o.hasDerive {
		return o, errors.New("the argument '--check' cannot be used with '--derive-key <CONTEXT>'")
	}
	if o.check && o.lengthSet {
		return o, errors.New("the argument '--check' cannot be used with '--length <LEN>'")
	}
	if o.check && o.raw {
		return o, errors.New("the argument '--check' cannot be used with '--raw'")
	}
	if o.check && o.noNames {
		return o, errors.New("the argument '--check' cannot be used with '--no-names'")
	}
	if o.check && o.tag {
		return o, errors.New("the argument '--check' cannot be used with '--tag'")
	}
	if o.raw && len(o.files) > 1 {
		return o, errors.New("The --raw flag may only be used with a single input.")
	}
	return o, nil
}

func digest(data []byte, key []byte, o options) []byte {
	if o.keyed {
		return blake3Keyed(data, key, o.seek, o.length)
	}
	if o.hasDerive {
		return blake3DeriveKey(o.derive, data, o.seek, o.length)
	}
	return blake3Hash(data, o.seek, o.length)
}

func readAllInput(name string) ([]byte, error) {
	if name == "-" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(name)
}

func formatFileErr(err error) string {
	if errors.Is(err, os.ErrNotExist) {
		return "No such file or directory (os error 2)"
	}
	if errors.Is(err, os.ErrPermission) {
		return "Permission denied (os error 13)"
	}
	if pe, ok := err.(*os.PathError); ok {
		if errno, ok := pe.Err.(syscall.Errno); ok {
			return fmt.Sprintf("%s (os error %d)", pe.Err.Error(), errno)
		}
	}
	return err.Error()
}

func printDigest(name string, sum []byte, o options) {
	if o.raw {
		os.Stdout.Write(sum)
		return
	}
	h := hex.EncodeToString(sum)
	if o.noNames {
		fmt.Println(h)
	} else if o.tag {
		fmt.Printf("BLAKE3 (%s) = %s\n", name, h)
	} else {
		fmt.Printf("%s  %s\n", h, name)
	}
}

func runHash(o options) int {
	var key []byte
	if o.keyed {
		var err error
		key = make([]byte, 32)
		_, err = io.ReadFull(os.Stdin, key)
		if err != nil {
			fmt.Fprintln(os.Stderr, "b3sum: Failed to read 32-byte key from stdin")
			return 1
		}
	}
	files := o.files
	if len(files) == 0 {
		files = []string{"-"}
	}
	status := 0
	for _, f := range files {
		data, err := readAllInput(f)
		if err != nil {
			fmt.Fprintf(os.Stderr, "b3sum: %s: %s\n", f, formatFileErr(err))
			status = 1
			continue
		}
		printDigest(f, digest(data, key, o), o)
	}
	return status
}

func parseCheckLine(line string) (hash, name string, ok bool) {
	line = strings.TrimRight(line, "\r\n")
	if strings.HasPrefix(line, "BLAKE3 (") {
		idx := strings.LastIndex(line, ") = ")
		if idx > len("BLAKE3 (") {
			return line[idx+4:], line[len("BLAKE3 ("):idx], true
		}
	}
	if len(line) >= 3 && strings.Contains(line, "  ") {
		parts := strings.SplitN(line, "  ", 2)
		return strings.TrimSpace(parts[0]), strings.TrimPrefix(parts[1], "*"), true
	}
	return "", "", false
}

func runCheck(o options) int {
	files := o.files
	if len(files) == 0 {
		files = []string{"-"}
	}
	status := 0
	failures := 0
	for _, cf := range files {
		var r io.Reader
		var fh *os.File
		if cf == "-" {
			r = os.Stdin
		} else {
			var err error
			fh, err = os.Open(cf)
			if err != nil {
				fmt.Fprintf(os.Stderr, "Error: %s\n", formatFileErr(err))
				status = 1
				continue
			}
			r = fh
		}
		sc := bufio.NewScanner(r)
		for sc.Scan() {
			want, name, ok := parseCheckLine(sc.Text())
			if !ok || want == "" {
				fmt.Fprintf(os.Stderr, "b3sum: %s: improperly formatted BLAKE3 checksum line\n", cf)
				status = 1
				continue
			}
			if len(want) != 64 {
				fmt.Fprintln(os.Stderr, "b3sum: Invalid hash length")
				failures++
				status = 1
				continue
			}
			if _, err := hex.DecodeString(want); err != nil {
				fmt.Fprintln(os.Stderr, "b3sum: Invalid hash")
				failures++
				status = 1
				continue
			}
			data, err := os.ReadFile(name)
			if err != nil {
				fmt.Fprintf(os.Stderr, "b3sum: %s: %s\n", name, formatFileErr(err))
				fmt.Printf("%s: FAILED open or read\n", name)
				failures++
				status = 1
				continue
			}
			got := hex.EncodeToString(digest(data, nil, o))
			if strings.EqualFold(got[:min(len(got), len(want))], want) && len(got) == len(want) {
				if !o.quiet {
					fmt.Printf("%s: OK\n", name)
				}
			} else {
				fmt.Printf("%s: FAILED\n", name)
				failures++
				status = 1
			}
		}
		if err := sc.Err(); err != nil {
			fmt.Fprintf(os.Stderr, "b3sum: %s: %s\n", cf, err)
			status = 1
		}
		if fh != nil {
			fh.Close()
		}
	}
	if failures > 0 {
		word := "checksums"
		if failures == 1 {
			word = "checksum"
		}
		fmt.Fprintf(os.Stderr, "b3sum: WARNING: %d computed %s did NOT match\n", failures, word)
	}
	return status
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func main() {
	_ = filepath.Separator
	o, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %s\n\nFor more information, try '--help'.\n", err)
		os.Exit(2)
	}
	if o.check {
		os.Exit(runCheck(o))
	}
	os.Exit(runHash(o))
}
