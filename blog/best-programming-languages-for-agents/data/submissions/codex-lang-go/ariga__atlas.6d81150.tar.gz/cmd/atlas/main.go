package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

func main() {
	if err := run(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		rootHelp()
		return nil
	}
	switch args[0] {
	case "help":
		if len(args) == 1 {
			rootHelp()
			return nil
		}
		return run(append(args[1:], "--help"))
	case "version":
		fmt.Println("atlas unofficial version - development")
		fmt.Println("https://github.com/ariga/atlas/releases/latest")
		fmt.Println("To download an official version, visit: https://atlasgo.io/getting-started#installation")
		return nil
	case "license":
		fmt.Println("LICENSE")
		fmt.Println("Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.")
		return nil
	case "schema":
		return schema(args[1:])
	case "migrate":
		return migrate(args[1:])
	case "completion":
		return completion(args[1:])
	default:
		return fmt.Errorf("unknown command %q for \"atlas\"\nRun 'atlas --help' for usage.\nYou're running the community build of Atlas, which may differ from the official version.\nIf this error persists, try installing the official version as a troubleshooting step:\n\n  curl -sSf https://atlasgo.sh | sh\n\nMore installation options: https://atlasgo.io/docs#installation", args[0])
	}
}

func rootHelp() {
	fmt.Println(`Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command.`)
}

func schema(args []string) error {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" || !known(args[0], []string{"apply", "clean", "diff", "fmt", "inspect"}) {
		schemaHelp()
		return nil
	}
	switch args[0] {
	case "fmt":
		if hasHelp(args[1:]) {
			schemaFmtHelp()
			return nil
		}
		return schemaFmt(args[1:])
	case "inspect":
		if hasHelp(args[1:]) {
			schemaInspectHelp()
			return nil
		}
		if !hasFlag(args[1:], "url", "u") {
			return errors.New(`required flag(s) "url" not set`)
		}
		u := flagValue(args[1:], "url", "u")
		return unsupportedURL(u)
	case "apply":
		if hasHelp(args[1:]) {
			schemaApplyHelp()
			return nil
		}
		if !hasFlag(args[1:], "url", "u") {
			return errors.New(`required flag(s) "url" not set`)
		}
		return unsupportedURL(flagValue(args[1:], "url", "u"))
	case "diff":
		if hasHelp(args[1:]) {
			schemaDiffHelp()
			return nil
		}
		return errors.New(`required flag(s) "from", "to" not set`)
	case "clean":
		if hasHelp(args[1:]) {
			schemaCleanHelp()
			return nil
		}
		if !hasFlag(args[1:], "url", "u") {
			return errors.New(`required flag(s) "url" not set`)
		}
		return unsupportedURL(flagValue(args[1:], "url", "u"))
	}
	return nil
}

func migrate(args []string) error {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		migrateHelp()
		return nil
	}
	switch args[0] {
	case "new":
		if hasHelp(args[1:]) {
			migrateNewHelp()
			return nil
		}
		return migrateNew(args[1:])
	case "hash":
		if hasHelp(args[1:]) {
			migrateHashHelp()
			return nil
		}
		return writeSum(dirFlag(args[1:]))
	case "validate":
		if hasHelp(args[1:]) {
			migrateValidateHelp()
			return nil
		}
		return validate(dirFlag(args[1:]))
	case "status", "apply":
		if hasHelp(args[1:]) {
			if args[0] == "status" {
				migrateStatusHelp()
			} else {
				migrateApplyHelp()
			}
			return nil
		}
		if _, err := os.Stat(dirFlag(args[1:])); err != nil {
			return fmt.Errorf("sql/migrate: %v", err)
		}
		if args[0] == "status" && !hasFlag(args[1:], "url", "u") {
			return errors.New(`required flag(s) "url" not set`)
		}
		return nil
	case "diff":
		if hasHelp(args[1:]) {
			migrateDiffHelp()
			return nil
		}
		return errors.New(`required flag(s) "dev-url" not set`)
	case "lint":
		if hasHelp(args[1:]) {
			migrateLintHelp()
			return nil
		}
		return errors.New(`required flag(s) "dev-url" not set`)
	case "import", "set":
		return nil
	default:
		migrateHelp()
		return nil
	}
}

func schemaFmt(paths []string) error {
	if len(paths) == 0 {
		paths = []string{"."}
	}
	var files []string
	for _, p := range paths {
		if strings.HasPrefix(p, "-") {
			continue
		}
		st, err := os.Stat(p)
		if err != nil {
			return err
		}
		if st.IsDir() {
			filepath.WalkDir(p, func(path string, d fs.DirEntry, err error) error {
				if err == nil && !d.IsDir() && strings.HasSuffix(path, ".hcl") {
					files = append(files, path)
				}
				return nil
			})
		} else {
			files = append(files, p)
		}
	}
	sort.Strings(files)
	for _, f := range files {
		b, err := os.ReadFile(f)
		if err != nil {
			return err
		}
		out := formatHCL(string(b))
		if out != string(b) {
			if err := os.WriteFile(f, []byte(out), 0644); err != nil {
				return err
			}
			fmt.Println(f)
		}
	}
	return nil
}

var (
	blockRE = regexp.MustCompile(`^(\s*)([A-Za-z0-9_]+)\s*(?:"([^"]+)")?\s*\{\s*$`)
	attrRE  = regexp.MustCompile(`^(\s*)([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$`)
)

func formatHCL(s string) string {
	var out []string
	indent := 0
	sc := bufio.NewScanner(strings.NewReader(s))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			if len(out) > 0 && out[len(out)-1] != "" {
				out = append(out, "")
			}
			continue
		}
		if line == "}" {
			if indent > 0 {
				indent--
			}
			out = append(out, strings.Repeat("  ", indent)+"}")
			continue
		}
		if m := blockRE.FindStringSubmatch(line); m != nil {
			if m[3] != "" {
				out = append(out, strings.Repeat("  ", indent)+m[2]+` "`+m[3]+`" {`)
			} else {
				out = append(out, strings.Repeat("  ", indent)+m[2]+" {")
			}
			indent++
			continue
		}
		if m := attrRE.FindStringSubmatch(line); m != nil {
			out = append(out, strings.Repeat("  ", indent)+m[2]+" = "+m[3])
			continue
		}
		out = append(out, strings.Repeat("  ", indent)+line)
	}
	return strings.TrimRight(strings.Join(out, "\n"), "\n") + "\n"
}

func migrateNew(args []string) error {
	dir := dirFlag(args)
	name := "migration"
	for _, a := range args {
		if strings.HasPrefix(a, "-") || strings.HasPrefix(a, "file://") || a == dir {
			continue
		}
		if !strings.Contains(a, "=") {
			name = sanitize(a)
		}
	}
	if err := os.MkdirAll(dir, 0755); err != nil {
		return err
	}
	fn := time.Now().UTC().Format("20060102150405") + "_" + name + ".sql"
	return os.WriteFile(filepath.Join(dir, fn), nil, 0644)
}

func writeSum(dir string) error {
	if _, err := os.Stat(dir); err != nil {
		return fmt.Errorf("sql/migrate: %v", err)
	}
	text, err := sumText(dir)
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(dir, "atlas.sum"), []byte(text), 0644)
}

func validate(dir string) error {
	if _, err := os.Stat(filepath.Join(dir, "atlas.sum")); err != nil {
		fmt.Fprintln(os.Stderr, "You have a checksum error in your migration directory.")
		fmt.Fprintln(os.Stderr, "Please check your migration files and run 'atlas migrate hash' to re-hash the contents")
		fmt.Fprintln(os.Stderr)
		return errors.New("checksum file not found")
	}
	want, err := os.ReadFile(filepath.Join(dir, "atlas.sum"))
	if err != nil {
		return err
	}
	got, err := sumText(dir)
	if err != nil {
		return err
	}
	if strings.TrimSpace(string(want)) != strings.TrimSpace(got) {
		fmt.Fprintln(os.Stderr, "You have a checksum error in your migration directory.")
		fmt.Fprintln(os.Stderr, "Please check your migration files and run 'atlas migrate hash' to re-hash the contents")
		fmt.Fprintln(os.Stderr)
		return errors.New("checksum mismatch")
	}
	return nil
}

func sumText(dir string) (string, error) {
	ents, err := os.ReadDir(dir)
	if err != nil {
		return "", err
	}
	var lines []string
	for _, e := range ents {
		n := e.Name()
		if e.IsDir() || n == "atlas.sum" || !strings.HasSuffix(n, ".sql") {
			continue
		}
		b, err := os.ReadFile(filepath.Join(dir, n))
		if err != nil {
			return "", err
		}
		lines = append(lines, n+" h1:"+hash(b))
	}
	sort.Strings(lines)
	root := hash([]byte(strings.Join(lines, "\n") + "\n"))
	return "h1:" + root + "\n" + strings.Join(lines, "\n") + "\n", nil
}

func hash(b []byte) string {
	h := sha256.Sum256(b)
	return base64.StdEncoding.EncodeToString(h[:])
}

func sanitize(s string) string {
	s = strings.ToLower(s)
	var b strings.Builder
	last := false
	for _, r := range s {
		ok := (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9')
		if ok {
			b.WriteRune(r)
			last = false
		} else if !last {
			b.WriteByte('_')
			last = true
		}
	}
	return strings.Trim(b.String(), "_")
}

func dirFlag(args []string) string {
	v := flagValue(args, "dir", "")
	if v == "" {
		v = "migrations"
	}
	return strings.TrimPrefix(v, "file://")
}

func unsupportedURL(u string) error {
	if strings.HasPrefix(u, "sqlite://file:") {
		return errors.New(`invalid port ":test.db" after host`)
	}
	if i := strings.Index(u, "://"); i > 0 {
		d := u[:i]
		switch d {
		case "mysql", "mariadb", "postgres", "postgresql", "sqlite", "file", "docker":
			return nil
		default:
			return fmt.Errorf(`sql/sqlclient: unknown driver %q. See: https://atlasgo.io/url`, d)
		}
	}
	return nil
}

func hasHelp(args []string) bool {
	for _, a := range args {
		if a == "--help" || a == "-h" {
			return true
		}
	}
	return false
}

func hasFlag(args []string, long, short string) bool { return flagValue(args, long, short) != "" }

func flagValue(args []string, long, short string) string {
	for i, a := range args {
		if strings.HasPrefix(a, "--"+long+"=") {
			return strings.TrimPrefix(a, "--"+long+"=")
		}
		if a == "--"+long && i+1 < len(args) {
			return args[i+1]
		}
		if short != "" {
			if strings.HasPrefix(a, "-"+short+"=") {
				return strings.TrimPrefix(a, "-"+short+"=")
			}
			if a == "-"+short && i+1 < len(args) {
				return args[i+1]
			}
		}
	}
	return ""
}

func known(s string, xs []string) bool {
	for _, x := range xs {
		if s == x {
			return true
		}
	}
	return false
}

func schemaHelp() { fmt.Println(`The ` + "`atlas schema`" + ` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command.`) }

func migrateHelp() { fmt.Println(`'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command.`) }

func schemaFmtHelp() { fmt.Println(`'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`) }

func schemaInspectHelp() { fmt.Println(`'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax.

Usage:
  atlas schema inspect [flags]

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])`) }

func schemaApplyHelp() { fmt.Println(`'atlas schema apply' plans and executes a database migration to bring a given
database to the state described in the provided Atlas schema.

Usage:
  atlas schema apply [flags]

Flags:
  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dry-run                 print SQL without executing it
      --auto-approve            apply changes without prompting for approval
  -h, --help                    help for apply`) }

func schemaDiffHelp() { fmt.Println(`'atlas schema diff' reads the state of two given schema definitions, 
calculates the difference in their schemas, and prints a plan of SQL statements.

Usage:
  atlas schema diff [flags]

Flags:
  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -h, --help              help for diff`) }

func schemaCleanHelp() { fmt.Println(`'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.

Usage:
  atlas schema clean [flags]

Flags:
  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dry-run         print SQL without executing it
      --auto-approve    apply changes without prompting for approval
  -h, --help            help for clean`) }

func migrateNewHelp() { fmt.Println(`'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new`) }

func migrateHashHelp() { fmt.Println(`'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash`) }

func migrateValidateHelp() { fmt.Println(`'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the
atlas.sum file.

Usage:
  atlas migrate validate [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for validate`) }

func migrateStatusHelp() { fmt.Println(`'atlas migrate status' reports information about the current status of a connected database compared to the migration directory.

Usage:
  atlas migrate status [flags]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
  -h, --help                      help for status`) }

func migrateApplyHelp() { fmt.Println(`'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.

Usage:
  atlas migrate apply [flags] [amount]

Flags:
  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dir string                select migration directory using URL format (default "file://migrations")
      --dry-run                   print SQL without executing it
  -h, --help                      help for apply`) }

func migrateDiffHelp() { fmt.Println(`The 'atlas migrate diff' command uses the dev-database to calculate the current state of the migration directory.

Usage:
  atlas migrate diff [flags] [name]

Flags:
      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format
      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string              select migration directory using URL format (default "file://migrations")
  -h, --help                    help for diff`) }

func migrateLintHelp() { fmt.Println(`Run analysis on the migration directory

Usage:
  atlas migrate lint [flags]

Flags:
      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format
      --dir string          select migration directory using URL format (default "file://migrations")
      --latest uint         run analysis on the latest N migration files
  -h, --help                help for lint`) }

func completion(args []string) error {
	if len(args) == 0 || hasHelp(args) {
		fmt.Println(`Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Use "atlas completion [command] --help" for more information about a command.`)
		return nil
	}
	fmt.Printf("# %s completion for atlas is not available in this reimplementation\n", args[0])
	return nil
}
