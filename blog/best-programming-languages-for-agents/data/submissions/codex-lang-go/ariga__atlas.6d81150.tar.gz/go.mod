module atlasclone

go 1.21
