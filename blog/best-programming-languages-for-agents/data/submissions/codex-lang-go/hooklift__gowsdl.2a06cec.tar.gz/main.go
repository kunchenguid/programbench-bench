package main

import (
	"bytes"
	"encoding/xml"
	"flag"
	"fmt"
	"go/format"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"unicode"
)

type Node struct {
	Name     xml.Name
	Attrs    []xml.Attr
	Children []*Node
	Text     string
}

func parseXML(r io.Reader) (*Node, error) {
	dec := xml.NewDecoder(r)
	root := &Node{Name: xml.Name{Local: "#doc"}}
	stack := []*Node{root}
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		switch t := tok.(type) {
		case xml.StartElement:
			n := &Node{Name: t.Name, Attrs: append([]xml.Attr(nil), t.Attr...)}
			p := stack[len(stack)-1]
			p.Children = append(p.Children, n)
			stack = append(stack, n)
		case xml.EndElement:
			if len(stack) > 1 {
				stack = stack[:len(stack)-1]
			}
		case xml.CharData:
			if len(stack) > 0 {
				stack[len(stack)-1].Text += string(t)
			}
		}
	}
	if len(root.Children) > 0 {
		return root.Children[0], nil
	}
	return root, nil
}

func (n *Node) attr(name string) string {
	for _, a := range n.Attrs {
		if a.Name.Local == name {
			return a.Value
		}
	}
	return ""
}
func (n *Node) kids(local string) []*Node {
	var out []*Node
	for _, c := range n.Children {
		if c.Name.Local == local {
			out = append(out, c)
		}
	}
	return out
}
func (n *Node) first(local string) *Node {
	for _, c := range n.Children {
		if c.Name.Local == local {
			return c
		}
	}
	return nil
}
func (n *Node) doc() string {
	if a := n.first("annotation"); a != nil {
		if d := a.first("documentation"); d != nil {
			return strings.Join(strings.Fields(d.Text), " ")
		}
	}
	return ""
}
func walk(n *Node, local string, out *[]*Node) {
	if n.Name.Local == local {
		*out = append(*out, n)
	}
	for _, c := range n.Children {
		walk(c, local, out)
	}
}

type Field struct {
	XMLName, GoName, GoType, Doc string
	Array, Attr, CharData        bool
	NS                           string
	Omit                         bool
}
type TypeDef struct {
	Name     string
	Fields   []Field
	IsEnum   bool
	EnumVals []EnumVal
	Base     string
	DateTime bool
}
type EnumVal struct{ Value, Doc string }
type Element struct {
	Name, Type, Doc string
	Fields          []Field
	EnumVals        []EnumVal
	DateTime        bool
}
type Operation struct{ Name, Input, Output, Action string }
type PortType struct {
	Name string
	Ops  []Operation
}
type Model struct {
	TargetNS string
	Types    map[string]*TypeDef
	Elements map[string]*Element
	Messages map[string]string
	Ports    []PortType
}

func main() {
	out := flag.String("o", "myservice.go", "File where the generated code will be saved")
	pkg := flag.String("p", "myservice", "Package under which code will be generated")
	dir := flag.String("d", "./", "Directory under which package directory will be created")
	insecure := flag.Bool("i", false, "Skips TLS Verification")
	ver := flag.Bool("v", false, "Shows gowsdl version")
	public := flag.Bool("make-public", true, "Make the generated types public/exported")
	_ = insecure
	flag.Usage = func() {
		fmt.Fprintf(flag.CommandLine.Output(), "Usage: %s [options] myservice.wsdl\n", os.Args[0])
		flag.PrintDefaults()
	}
	flag.Parse()
	if *ver {
		fmt.Println("🍀  v0.5.0")
		return
	}
	if flag.NArg() < 1 {
		flag.Usage()
		return
	}
	input := flag.Arg(0)
	abs, _ := filepath.Abs(input)
	fmt.Printf("🍀  Reading file %s\n", abs)
	data, err := readInput(input)
	if err != nil {
		fmt.Printf("🍀  %v\n", err)
		os.Exit(1)
	}
	root, err := parseXML(bytes.NewReader(data))
	if err != nil {
		fmt.Printf("🍀  %v\n", err)
		os.Exit(1)
	}
	m := &Model{TargetNS: root.attr("targetNamespace"), Types: map[string]*TypeDef{}, Elements: map[string]*Element{}, Messages: map[string]string{}}
	baseDir := filepath.Dir(input)
	parseRoot(root, m, baseDir, map[string]bool{})
	parseWSDL(root, m)
	destDir := filepath.Join(*dir, *pkg)
	if err := os.MkdirAll(destDir, 0755); err != nil {
		fmt.Printf("🍀  %v\n", err)
		os.Exit(1)
	}
	client := generateClient(m, *pkg, *public)
	clientPath := filepath.Join(destDir, *out)
	if err := os.WriteFile(clientPath, []byte(client), 0644); err != nil {
		fmt.Printf("🍀  %v\n", err)
		os.Exit(1)
	}
	server := generateServer(*pkg, data)
	_ = os.WriteFile(filepath.Join(destDir, "server"+*out), []byte(server), 0644)
	fmt.Println("🍀  Done 👍")
}

func readInput(s string) ([]byte, error) {
	if strings.HasPrefix(s, "http://") || strings.HasPrefix(s, "https://") {
		resp, err := http.Get(s)
		if err != nil {
			return nil, err
		}
		defer resp.Body.Close()
		return io.ReadAll(resp.Body)
	}
	return os.ReadFile(s)
}

func parseRoot(root *Node, m *Model, baseDir string, seen map[string]bool) {
	for _, t := range root.kids("types") {
		for _, c := range t.Children {
			if c.Name.Local == "schema" {
				parseSchema(c, m, baseDir, seen)
			}
		}
	}
	var schemas []*Node
	walk(root, "schema", &schemas)
	for _, s := range schemas {
		parseSchema(s, m, baseDir, seen)
	}
}

func parseSchema(s *Node, m *Model, baseDir string, seen map[string]bool) {
	if ns := s.attr("targetNamespace"); ns != "" && m.TargetNS == "" {
		m.TargetNS = ns
	}
	for _, imp := range append(s.kids("import"), s.kids("include")...) {
		loc := imp.attr("schemaLocation")
		if loc != "" && !strings.HasPrefix(loc, "http") {
			p := filepath.Join(baseDir, loc)
			if !seen[p] {
				seen[p] = true
				if b, err := os.ReadFile(p); err == nil {
					if r, err := parseXML(bytes.NewReader(b)); err == nil {
						parseSchema(r, m, filepath.Dir(p), seen)
					}
				}
			}
		}
	}
	for _, st := range s.kids("simpleType") {
		if name := st.attr("name"); name != "" {
			m.Types[name] = parseSimpleType(name, st)
		}
	}
	for _, ct := range s.kids("complexType") {
		if name := ct.attr("name"); name != "" {
			m.Types[name] = parseComplexType(name, ct, m)
		}
	}
	for _, el := range s.kids("element") {
		parseElement(el, m)
	}
	for _, at := range s.kids("attribute") {
		if name := at.attr("name"); name != "" {
			if st := at.first("simpleType"); st != nil {
				m.Types[name] = parseSimpleType(name, st)
			}
		}
	}
}

func parseSimpleType(name string, st *Node) *TypeDef {
	td := &TypeDef{Name: name, Base: "string"}
	if r := st.first("restriction"); r != nil {
		td.Base = baseLocal(r.attr("base"))
		for _, e := range r.kids("enumeration") {
			td.IsEnum = true
			td.EnumVals = append(td.EnumVals, EnumVal{Value: e.attr("value"), Doc: e.doc()})
		}
	}
	if td.Base == "dateTime" {
		td.DateTime = true
	}
	return td
}

func parseElement(el *Node, m *Model) {
	name := el.attr("name")
	if name == "" {
		return
	}
	e := &Element{Name: name, Type: baseLocal(el.attr("type")), Doc: el.doc()}
	if e.Type == "dateTime" {
		e.DateTime = true
	}
	if st := el.first("simpleType"); st != nil {
		td := parseSimpleType(name, st)
		e.EnumVals = td.EnumVals
		e.DateTime = td.DateTime
		e.Type = td.Base
	}
	if ct := el.first("complexType"); ct != nil {
		td := parseComplexType(name, ct, m)
		e.Fields = td.Fields
	}
	m.Elements[name] = e
}

func parseComplexType(name string, ct *Node, m *Model) *TypeDef {
	td := &TypeDef{Name: name}
	if cc := ct.first("complexContent"); cc != nil {
		if ext := cc.first("extension"); ext != nil {
			base := baseLocal(ext.attr("base"))
			if bt := m.Types[base]; bt != nil {
				td.Fields = append(td.Fields, bt.Fields...)
			}
			collectFields(ext, td, m)
		}
	}
	if sc := ct.first("simpleContent"); sc != nil {
		td.Fields = append(td.Fields, Field{GoName: "Value", GoType: "string", CharData: true})
		if ext := sc.first("extension"); ext != nil {
			collectAttrs(ext, td, m)
		}
	}
	collectFields(ct, td, m)
	collectAttrs(ct, td, m)
	return td
}
func collectFields(n *Node, td *TypeDef, m *Model) {
	for _, seqn := range []*Node{n.first("sequence"), n.first("all"), n.first("choice")} {
		if seqn == nil {
			continue
		}
		for _, el := range seqn.kids("element") {
			f := fieldFromElement(el, m)
			td.Fields = append(td.Fields, f)
		}
	}
}
func collectAttrs(n *Node, td *TypeDef, m *Model) {
	for _, at := range n.kids("attribute") {
		name := at.attr("name")
		if name == "" {
			name = baseLocal(at.attr("ref"))
		}
		if name == "" {
			continue
		}
		typ := baseLocal(at.attr("type"))
		if typ == "" {
			typ = "string"
		}
		td.Fields = append(td.Fields, Field{XMLName: name, GoName: exportName(name), GoType: goType(typ, false, false), Attr: true, NS: m.TargetNS, Omit: true})
	}
}
func fieldFromElement(el *Node, m *Model) Field {
	name := el.attr("name")
	typ := baseLocal(el.attr("type"))
	if typ == "" {
		if st := el.first("simpleType"); st != nil {
			td := parseSimpleType(name, st)
			if td.IsEnum || td.DateTime {
				typ = name
				m.Types[name] = td
			} else {
				typ = td.Base
			}
		} else {
			typ = name
			if ct := el.first("complexType"); ct != nil {
				td := parseComplexType(name, ct, m)
				typ = name
				m.Types[name] = td
			}
		}
	}
	arr := el.attr("maxOccurs") == "unbounded" || (el.attr("maxOccurs") != "" && el.attr("maxOccurs") != "1")
	return Field{XMLName: name, GoName: exportName(name), GoType: goType(typ, arr, false), Doc: el.doc(), Array: arr, Omit: el.attr("minOccurs") == "0" || el.attr("nillable") == "true"}
}

func parseWSDL(root *Node, m *Model) {
	for _, msg := range root.kids("message") {
		name := msg.attr("name")
		if p := msg.first("part"); p != nil {
			elem := baseLocal(p.attr("element"))
			if elem == "" {
				elem = baseLocal(p.attr("type"))
			}
			m.Messages[name] = elem
		} else if name != "" {
			fmt.Printf("🍀  [WARN] %s message doesn't have any parts, ignoring message...\n", name)
		}
	}
	actions := map[string]string{}
	for _, b := range root.kids("binding") {
		for _, op := range b.kids("operation") {
			if so := op.first("operation"); so != nil {
				actions[op.attr("name")] = so.attr("soapAction")
			}
		}
	}
	for _, pt := range root.kids("portType") {
		p := PortType{Name: pt.attr("name")}
		for _, op := range pt.kids("operation") {
			o := Operation{Name: op.attr("name")}
			if in := op.first("input"); in != nil {
				o.Input = m.Messages[baseLocal(in.attr("message"))]
			}
			if out := op.first("output"); out != nil {
				o.Output = m.Messages[baseLocal(out.attr("message"))]
			}
			o.Action = actions[o.Name]
			if o.Action == "" {
				o.Action = "''"
			}
			if o.Input != "" && o.Output != "" {
				p.Ops = append(p.Ops, o)
			}
		}
		if len(p.Ops) > 0 {
			m.Ports = append(m.Ports, p)
		}
	}
}

func generateClient(m *Model, pkg string, pub bool) string {
	var b strings.Builder
	b.WriteString("// Code generated by gowsdl DO NOT EDIT.\n\npackage " + pkg + "\n\n")
	b.WriteString("import (\n\t\"context\"\n\t\"encoding/xml\"\n\t\"github.com/hooklift/gowsdl/soap\"\n\t\"time\"\n)\n\n")
	b.WriteString("// against \"unused imports\"\nvar _ time.Time\nvar _ xml.Name\n\n")
	b.WriteString("type AnyType struct {\n\tInnerXML string `xml:\",innerxml\"`\n}\n\ntype AnyURI string\n\ntype NCName string\n\n")
	keys := make([]string, 0, len(m.Types))
	for k := range m.Types {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	// Prefer schema order for elements, then named types alphabetically is acceptable.
	for _, name := range keys {
		td := m.Types[name]
		if td.IsEnum {
			emitEnum(&b, name, td.EnumVals, pub)
		}
	}
	elNames := make([]string, 0, len(m.Elements))
	for k := range m.Elements {
		elNames = append(elNames, k)
	}
	sort.Strings(elNames)
	for _, name := range elNames {
		e := m.Elements[name]
		if len(e.EnumVals) > 0 {
			emitEnum(&b, name, e.EnumVals, pub)
		} else if e.DateTime {
			emitDateAlias(&b, name, pub)
		} else if len(e.Fields) > 0 || e.Type == "" || isOperationElement(name, m) {
			emitStruct(&b, name, e.Fields, m.TargetNS, pub)
		}
	}
	for _, name := range keys {
		td := m.Types[name]
		if td.IsEnum {
			continue
		}
		if td.DateTime {
			emitDateAlias(&b, name, pub)
		} else {
			emitStruct(&b, name, td.Fields, "", pub)
		}
	}
	for _, p := range m.Ports {
		emitService(&b, p, pub)
	}
	if out, err := format.Source([]byte(b.String())); err == nil {
		return string(out)
	}
	return b.String()
}

func isOperationElement(name string, m *Model) bool {
	for _, p := range m.Ports {
		for _, o := range p.Ops {
			if o.Input == name || o.Output == name {
				return true
			}
		}
	}
	return false
}
func emitStruct(b *strings.Builder, name string, fields []Field, ns string, pub bool) {
	tn := typeName(name, pub)
	b.WriteString("type " + tn + " struct {\n")
	if ns != "" {
		fmt.Fprintf(b, "\tXMLName xml.Name `xml:\"%s %s\"`\n", ns, name)
	}
	for _, f := range fields {
		b.WriteString("\n")
		if f.Doc != "" {
			b.WriteString("\t// " + f.Doc + "\n")
		}
		if f.CharData {
			fmt.Fprintf(b, "\tValue string `xml:\",chardata\" json:\"-,\"`\n")
			continue
		}
		tag := f.XMLName
		if f.Attr {
			tag = f.NS + " " + f.XMLName + ",attr"
		}
		if f.Omit {
			tag += ",omitempty"
		}
		json := f.XMLName
		if f.Omit {
			json += ",omitempty"
		}
		fmt.Fprintf(b, "\t%s %s `xml:\"%s\" json:\"%s\"`\n", fieldName(f.GoName, pub), typeForOutput(f.GoType, pub), tag, json)
	}
	b.WriteString("}\n\n")
}
func emitEnum(b *strings.Builder, name string, vals []EnumVal, pub bool) {
	tn := typeName(name, pub)
	b.WriteString("type " + tn + " string\n\nconst (\n")
	for _, v := range vals {
		if v.Doc != "" {
			b.WriteString("\n\t// " + v.Doc + "\n")
		}
		fmt.Fprintf(b, "\t%s %s = %q\n\n", constName(tn, v.Value, pub), tn, v.Value)
	}
	b.WriteString(")\n\n")
}
func emitDateAlias(b *strings.Builder, name string, pub bool) {
	tn := typeName(name, pub)
	fmt.Fprintf(b, "type %s soap.XSDDateTime\n\nfunc (xdt %s) MarshalXML(e *xml.Encoder, start xml.StartElement) error {\n\treturn soap.XSDDateTime(xdt).MarshalXML(e, start)\n}\n\nfunc (xdt *%s) UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {\n\treturn (*soap.XSDDateTime)(xdt).UnmarshalXML(d, start)\n}\n\n", tn, tn, tn)
}
func emitService(b *strings.Builder, p PortType, pub bool) {
	in := typeName(p.Name, true)
	impl := lowerFirst(in)
	fmt.Fprintf(b, "type %s interface {\n", in)
	for _, o := range p.Ops {
		fmt.Fprintf(b, "\t%s(request *%s) (*%s, error)\n\n\t%sContext(ctx context.Context, request *%s) (*%s, error)\n\n", exportName(o.Name), typeName(o.Input, pub), typeName(o.Output, pub), exportName(o.Name), typeName(o.Input, pub), typeName(o.Output, pub))
	}
	b.WriteString("}\n\n")
	fmt.Fprintf(b, "type %s struct {\n\tclient *soap.Client\n}\n\n", impl)
	fmt.Fprintf(b, "func New%s(client *soap.Client) %s {\n\treturn &%s{client: client}\n}\n\n", in, in, impl)
	for _, o := range p.Ops {
		mn := exportName(o.Name)
		fmt.Fprintf(b, "func (service *%s) %sContext(ctx context.Context, request *%s) (*%s, error) {\n\tresponse := new(%s)\n\terr := service.client.CallContext(ctx, %q, request, response)\n\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n", impl, mn, typeName(o.Input, pub), typeName(o.Output, pub), typeName(o.Output, pub), o.Action)
		fmt.Fprintf(b, "func (service *%s) %s(request *%s) (*%s, error) {\n\treturn service.%sContext(context.Background(), request)\n}\n\n", impl, mn, typeName(o.Input, pub), typeName(o.Output, pub), mn)
	}
}

func generateServer(pkg string, wsdl []byte) string {
	s := fmt.Sprintf("// Code generated by gowsdl DO NOT EDIT.\n\npackage %s\n\nvar wsdl = `%s`\n", pkg, strings.ReplaceAll(string(wsdl), "`", "`+\"`\"+`"))
	if out, err := format.Source([]byte(s)); err == nil {
		return string(out)
	}
	return s
}

func baseLocal(s string) string {
	if i := strings.LastIndex(s, ":"); i >= 0 {
		return s[i+1:]
	}
	return s
}
func goType(t string, arr bool, attr bool) string {
	base := map[string]string{"string": "string", "normalizedString": "string", "token": "string", "int": "int", "integer": "int", "long": "int64", "short": "int", "byte": "byte", "unsignedInt": "uint", "unsignedLong": "uint64", "boolean": "bool", "bool": "bool", "decimal": "float64", "double": "float64", "float": "float32", "dateTime": "soap.XSDDateTime", "date": "soap.XSDDateTime", "time": "soap.XSDDateTime", "anyType": "AnyType", "anyURI": "AnyURI", "NCName": "NCName"}
	gt := base[t]
	if gt == "" {
		gt = exportName(t)
	}
	if arr {
		return "[]" + gt
	}
	if isBuiltinPtr(gt) {
		return gt
	}
	if strings.HasPrefix(gt, "soap.") {
		return "*" + gt
	}
	if _, ok := base[t]; !ok {
		return "*" + gt
	}
	return gt
}
func isBuiltinPtr(s string) bool { return strings.HasPrefix(s, "[]") }
func typeForOutput(t string, pub bool) string {
	if pub {
		return t
	} // lower custom identifiers after pointers/slices
	prefix := ""
	rest := t
	for strings.HasPrefix(rest, "*") || strings.HasPrefix(rest, "[]") {
		if strings.HasPrefix(rest, "*") {
			prefix += "*"
			rest = rest[1:]
		} else {
			prefix += "[]"
			rest = rest[2:]
		}
	}
	if strings.Contains(rest, ".") || isPrimitive(rest) {
		return prefix + rest
	}
	return prefix + lowerFirst(rest)
}
func isPrimitive(s string) bool {
	switch s {
	case "string", "int", "int64", "uint", "uint64", "bool", "float64", "float32", "byte", "AnyType", "AnyURI", "NCName":
		return true
	}
	return false
}
func typeName(s string, pub bool) string {
	if pub {
		return exportName(s)
	}
	return lowerFirst(exportName(s))
}
func fieldName(s string, pub bool) string {
	if s == "" {
		return s
	}
	if pub {
		return exportName(s)
	}
	return lowerFirst(exportName(s))
}

var wordRe = regexp.MustCompile(`[A-Za-z0-9]+`)

func exportName(s string) string {
	parts := wordRe.FindAllString(s, -1)
	if len(parts) == 0 {
		return "X"
	}
	for i, p := range parts {
		if p == "" {
			continue
		}
		parts[i] = strings.ToUpper(p[:1]) + p[1:]
	}
	out := strings.Join(parts, "")
	if out == "Return" {
		out = "Return_"
	}
	if r := []rune(out)[0]; unicode.IsDigit(r) {
		out = "N" + out
	}
	return out
}
func lowerFirst(s string) string {
	if s == "" {
		return s
	}
	r := []rune(s)
	r[0] = unicode.ToLower(r[0])
	return string(r)
}
func constName(tn, val string, pub bool) string {
	n := tn + exportName(val)
	if pub {
		return n
	}
	return lowerFirst(n)
}
