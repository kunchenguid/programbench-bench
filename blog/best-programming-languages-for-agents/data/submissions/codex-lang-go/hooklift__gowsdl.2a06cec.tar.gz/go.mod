module pb/gowsdlreimpl

go 1.21
