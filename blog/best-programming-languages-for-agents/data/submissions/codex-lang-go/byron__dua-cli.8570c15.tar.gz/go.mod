module dua_reimpl

go 1.21
