package main

import (
	"errors"
	"fmt"
	"io/fs"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
)

const version = "2.32.2"
const green = "\x1b[32m"
const cyan = "\x1b[36m"
const reset = "\x1b[39m"

type config struct {
	threads    int
	format     string
	apparent   bool
	countHard  bool
	stayFS     bool
	ignoreDirs []string
	logFile    string
}

type row struct {
	size  int64
	path  string
	isDir bool
	errs  int
	order int
}
type stats struct {
	entries  int
	smallest int64
	largest  int64
	have     bool
}

type seenKey struct {
	dev uint64
	ino uint64
}

func main() {
	cfg := config{threads: 0, format: "binary", ignoreDirs: []string{"/proc", "/dev", "/sys", "/run"}}
	args := os.Args[1:]
	if len(args) == 0 {
		runDefault(cfg, nil)
		return
	}
	if args[0] == "--version" || args[0] == "-V" {
		fmt.Println("dua " + version)
		return
	}
	if args[0] == "--help" || args[0] == "-h" {
		printHelp("executable")
		return
	}

	var err error
	args, err = parseGlobal(args, &cfg)
	if err != nil {
		fmt.Fprint(os.Stderr, err.Error())
		os.Exit(2)
	}
	if len(args) == 0 {
		runDefault(cfg, nil)
		return
	}
	switch args[0] {
	case "aggregate", "a":
		runAggregate(cfg, args[1:])
	case "interactive", "i":
		runInteractive(args[1:])
	case "completions":
		runCompletions(args[1:])
	case "help":
		if len(args) > 1 {
			switch args[1] {
			case "aggregate", "a":
				printAggregateHelp()
			case "interactive", "i":
				printInteractiveHelp()
			case "completions":
				printCompletionsHelp()
			default:
				printHelp("executable")
			}
		} else {
			printHelp("executable")
		}
	default:
		runDefault(cfg, args)
	}
}

func parseGlobal(args []string, cfg *config) ([]string, error) {
	out := []string{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			out = append(out, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			out = append(out, args[i:]...)
			break
		}
		val := func(name string) (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("error: a value is required for '%s <FORMAT>' but none was supplied\n", name)
			}
			i++
			return args[i], nil
		}
		switch a {
		case "-t", "--threads":
			v, e := val(a)
			if e != nil {
				return nil, e
			}
			n, _ := strconv.Atoi(v)
			cfg.threads = n
		case "-f", "--format":
			v, e := val(a)
			if e != nil {
				return nil, e
			}
			if !validFormat(v) {
				return nil, invalidFormat(v)
			}
			cfg.format = v
		case "-A", "--apparent-size":
			cfg.apparent = true
		case "-l", "--count-hard-links":
			cfg.countHard = true
		case "-x", "--stay-on-filesystem":
			cfg.stayFS = true
		case "-i", "--ignore-dirs":
			v, e := val(a)
			if e != nil {
				return nil, e
			}
			cfg.ignoreDirs = append(cfg.ignoreDirs, v)
		case "--log-file":
			v, e := val(a)
			if e != nil {
				return nil, e
			}
			cfg.logFile = v
		case "--help", "-h":
			printHelp("executable")
			os.Exit(0)
		case "--version", "-V":
			fmt.Println("dua " + version)
			os.Exit(0)
		default:
			return nil, fmt.Errorf("error: unexpected argument '%s' found\n\nUsage: executable [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nFor more information, try '--help'.\n", a)
		}
	}
	return out, nil
}

func validFormat(f string) bool {
	switch f {
	case "metric", "binary", "bytes", "gb", "gib", "mb", "mib":
		return true
	}
	return false
}
func invalidFormat(v string) error {
	return fmt.Errorf("error: invalid value '%s' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\nFor more information, try '--help'.\n", v)
}

func parseAggOptions(args []string) (statsFlag, noSort, noTotal bool, inputs []string) {
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "--":
			inputs = append(inputs, args[i+1:]...)
			return
		case "--stats":
			statsFlag = true
		case "--no-sort":
			noSort = true
		case "--no-total":
			noTotal = true
		case "--help", "-h":
			printAggregateHelp()
			os.Exit(0)
		default:
			if strings.HasPrefix(a, "-") {
				fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable aggregate [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n", a, a, a)
				os.Exit(2)
			}
			inputs = append(inputs, a)
		}
	}
	return
}

func runAggregate(cfg config, args []string) {
	stFlag, noSort, noTotal, inputs := parseAggOptions(args)
	if len(inputs) <= 1 {
		runDefaultWithStats(cfg, inputs, stFlag)
		return
	}
	var st stats
	rows := make([]row, 0, len(inputs))
	errs := 0
	for i, p := range inputs {
		seen := map[seenKey]bool{}
		r := measurePath(p, cfg, seen, &st, true)
		r.order = i
		rows = append(rows, r)
		errs += r.errs
	}
	if !noSort {
		sort.SliceStable(rows, func(i, j int) bool { return rows[i].size < rows[j].size })
	}
	total := int64(0)
	terr := 0
	for _, r := range rows {
		printRow(r, cfg)
		total += r.size
		terr += r.errs
	}
	if len(rows) > 1 && !noTotal {
		printRow(row{size: total, path: "total", errs: terr}, cfg)
	}
	if stFlag {
		if !st.have {
			st.smallest = 0
			st.largest = 0
		}
		fmt.Fprintf(os.Stderr, "Statistics { entries_traversed: %d, smallest_file_in_bytes: %d, largest_file_in_bytes: %d }\n", st.entries, st.smallest, st.largest)
	}
	if errs > 0 {
		os.Exit(1)
	}
}

func runDefault(cfg config, inputs []string) {
	runDefaultWithStats(cfg, inputs, false)
}

func runDefaultWithStats(cfg config, inputs []string, stFlag bool) {
	seen := map[seenKey]bool{}
	var st stats
	rows := []row{}
	if len(inputs) == 0 {
		inputs = cwdEntries()
	}
	if len(inputs) == 1 {
		if info, err := os.Lstat(inputs[0]); err == nil && info.IsDir() {
			ents, err := os.ReadDir(inputs[0])
			if err == nil {
				for i, e := range ents {
					if e.Type()&os.ModeSymlink != 0 {
						continue
					}
					p := filepath.Join(inputs[0], e.Name())
					r := measurePath(p, cfg, seen, &st, false)
					r.path = e.Name()
					r.order = i
					rows = append(rows, r)
				}
			} else {
				rows = append(rows, row{path: inputs[0], isDir: true, errs: 1})
			}
		} else {
			for i, p := range inputs {
				r := measurePath(p, cfg, seen, &st, false)
				r.order = i
				rows = append(rows, r)
			}
		}
	} else {
		for i, p := range inputs {
			r := measurePath(p, cfg, seen, &st, false)
			r.order = i
			rows = append(rows, r)
		}
	}
	sort.SliceStable(rows, func(i, j int) bool { return rows[i].size < rows[j].size })
	total := int64(0)
	errs := 0
	for _, r := range rows {
		printRow(r, cfg)
		total += r.size
		errs += r.errs
	}
	if len(rows) > 1 {
		printRow(row{size: total, path: "total", errs: errs}, cfg)
	}
	if stFlag {
		if !st.have {
			st.smallest = 0
			st.largest = 0
		}
		fmt.Fprintf(os.Stderr, "Statistics { entries_traversed: %d, smallest_file_in_bytes: %d, largest_file_in_bytes: %d }\n", st.entries, st.smallest, st.largest)
	}
	if errs > 0 {
		os.Exit(1)
	}
}

func cwdEntries() []string {
	ents, _ := os.ReadDir(".")
	out := []string{}
	for _, e := range ents {
		if e.Type()&os.ModeSymlink != 0 {
			continue
		}
		out = append(out, e.Name())
	}
	return out
}

func measurePath(path string, cfg config, seen map[seenKey]bool, st *stats, root bool) row {
	info, err := os.Lstat(path)
	if err != nil {
		return row{path: path, isDir: true, errs: 1}
	}
	if info.Mode()&os.ModeSymlink != 0 {
		return row{path: path, isDir: false}
	}
	isDir := info.IsDir()
	rootDev := devOf(info)
	total := int64(0)
	errs := 0
	add := func(p string, info fs.FileInfo) {
		sz := entrySize(info, cfg)
		if !cfg.countHard && !info.IsDir() {
			if k, ok := keyOf(info); ok {
				if seen[k] {
					sz = 0
				} else {
					seen[k] = true
				}
			}
		}
		total += sz
		st.add(sz)
	}
	if !isDir {
		add(path, info)
		return row{size: total, path: path, isDir: false}
	}
	err = filepath.WalkDir(path, func(p string, d fs.DirEntry, e error) error {
		if e != nil {
			errs++
			return nil
		}
		inf, er := d.Info()
		if er != nil {
			errs++
			return nil
		}
		if p != path && d.Type()&os.ModeSymlink != 0 {
			return filepath.SkipDir
		}
		if p != path && d.IsDir() {
			ap, _ := filepath.Abs(p)
			for _, ig := range cfg.ignoreDirs {
				if ap == ig {
					return filepath.SkipDir
				}
			}
			if cfg.stayFS && devOf(inf) != rootDev {
				return filepath.SkipDir
			}
		}
		add(p, inf)
		return nil
	})
	if err != nil {
		errs++
	}
	_ = root
	return row{size: total, path: path, isDir: true, errs: errs}
}

func (s *stats) add(v int64) {
	s.entries++
	if !s.have || v < s.smallest {
		s.smallest = v
	}
	if !s.have || v > s.largest {
		s.largest = v
	}
	s.have = true
}
func entrySize(info fs.FileInfo, cfg config) int64 {
	if cfg.apparent {
		return info.Size()
	}
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		return st.Blocks * 512
	}
	return info.Size()
}
func keyOf(info fs.FileInfo) (seenKey, bool) {
	st, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return seenKey{}, false
	}
	return seenKey{uint64(st.Dev), uint64(st.Ino)}, true
}
func devOf(info fs.FileInfo) uint64 {
	st, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return 0
	}
	return uint64(st.Dev)
}

func printRow(r row, cfg config) {
	name := r.path
	if r.isDir && name != "total" {
		name = cyan + name + reset
	}
	suffix := ""
	if r.errs > 0 {
		suffix = fmt.Sprintf("  <%d IO Error>", r.errs)
	}
	fmt.Printf("%s%s%s %s%s\n", green, formatSize(r.size, cfg.format), reset, name, suffix)
}

func formatSize(n int64, f string) string {
	switch f {
	case "bytes":
		return fmt.Sprintf("%10d b", n)
	case "metric":
		return human(float64(n), 1000, []string{" B", "KB", "MB", "GB", "TB"}, false)
	case "gb":
		return fmt.Sprintf("%7.2f GB", float64(n)/1e9)
	case "gib":
		return fmt.Sprintf("%6.2f GiB", float64(n)/(1<<30))
	case "mb":
		return fmt.Sprintf("%8.2f MB", float64(n)/1e6)
	case "mib":
		return fmt.Sprintf("%7.2f MiB", float64(n)/(1<<20))
	default:
		return human(float64(n), 1024, []string{" B", "KiB", "MiB", "GiB", "TiB"}, true)
	}
}
func human(v float64, base float64, units []string, bin bool) string {
	idx := 0
	for math.Abs(v) > base && idx < len(units)-1 {
		v /= base
		idx++
	}
	if idx == 0 {
		return fmt.Sprintf("%7.0f   B", v)
	}
	return fmt.Sprintf("%7.2f %s", v, units[idx])
}

func runInteractive(args []string) {
	for _, a := range args {
		if a == "--help" || a == "-h" {
			printInteractiveHelp()
			return
		}
	}
	fmt.Fprintln(os.Stderr, "Error: launch interactive mode failed: no terminal available")
	os.Exit(1)
}
func runCompletions(args []string) {
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		printCompletionsHelp()
		return
	}
	shells := map[string]bool{"bash": true, "elvish": true, "fish": true, "powershell": true, "zsh": true}
	if !shells[args[0]] {
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n", args[0])
		os.Exit(2)
	}
	fmt.Printf("# completion script for dua (%s)\n", args[0])
}

func printHelp(prog string) {
	_ = errors.New
	fmt.Print(`A tool to learn about disk usage, fast!

Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...

Commands:
  interactive  Launch the terminal user interface [aliases: i]
  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Arguments:
  [INPUT]...
          One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -t, --threads <THREADS>
          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread
          
          [default: 0]

  -f, --format <FORMAT>
          The format with which to print byte counts
          
          [default: binary]
          [possible values: metric, binary, bytes, gb, gib, mb, mib]

  -A, --apparent-size
          Display apparent size instead of disk usage

  -l, --count-hard-links
          Count hard-linked files each time they are seen

  -x, --stay-on-filesystem
          If set, we will not cross filesystems or traverse mount points

  -i, --ignore-dirs <IGNORE_DIRS>
          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.
          
          Hence, they will only be ignored if they are eventually reached as part of the traversal.
          
          [default: /proc /dev /sys /run]

      --log-file <LOG_FILE>
          Write a log file with debug information, including panics

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
`)
}
func printAggregateHelp() {
	fmt.Print(`Aggregate the consumed space of one or more directories or files

Usage: executable aggregate [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
      --stats     If set, print additional statistics about the file traversal to stderr
      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending
      --no-total  If set, no total column will be computed for multiple inputs
  -h, --help      Print help
`)
}
func printInteractiveHelp() {
	fmt.Print(`Launch the terminal user interface

Usage: executable interactive [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory

Options:
  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems
  -h, --help            Print help
`)
}
func printCompletionsHelp() {
	fmt.Print(`Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help  Print help
`)
}
