package main

/*
#cgo LDFLAGS: -ldl
#include <dlfcn.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

typedef size_t (*max_size_fn)(size_t);
typedef int (*compress_fn)(int, int, int, size_t, const uint8_t*, size_t*, uint8_t*);
typedef void* (*dec_create_fn)(void*, void*, void*);
typedef void (*dec_destroy_fn)(void*);
typedef int (*dec_stream_fn)(void*, size_t*, const uint8_t**, size_t*, uint8_t**, size_t*);

static void *enc_h, *dec_h;
static max_size_fn p_max_size;
static compress_fn p_compress;
static dec_create_fn p_dec_create;
static dec_destroy_fn p_dec_destroy;
static dec_stream_fn p_dec_stream;

static int load_brotli(char **err) {
  if (p_compress && p_dec_stream) return 1;
  enc_h = dlopen("libbrotlienc.so.1", RTLD_LAZY);
  dec_h = dlopen("libbrotlidec.so.1", RTLD_LAZY);
  if (!enc_h || !dec_h) { *err = dlerror(); return 0; }
  p_max_size = (max_size_fn)dlsym(enc_h, "BrotliEncoderMaxCompressedSize");
  p_compress = (compress_fn)dlsym(enc_h, "BrotliEncoderCompress");
  p_dec_create = (dec_create_fn)dlsym(dec_h, "BrotliDecoderCreateInstance");
  p_dec_destroy = (dec_destroy_fn)dlsym(dec_h, "BrotliDecoderDestroyInstance");
  p_dec_stream = (dec_stream_fn)dlsym(dec_h, "BrotliDecoderDecompressStream");
  if (!p_max_size || !p_compress || !p_dec_create || !p_dec_destroy || !p_dec_stream) {
    *err = dlerror();
    return 0;
  }
  return 1;
}

static size_t br_max_size(size_t n) { return p_max_size(n); }
static int br_compress(int q, int w, size_t in_size, const uint8_t *in, size_t *out_size, uint8_t *out) {
  return p_compress(q, w, 0, in_size, in, out_size, out);
}
static void* br_dec_create() { return p_dec_create(0, 0, 0); }
static void br_dec_destroy(void *s) { p_dec_destroy(s); }
static int br_dec_stream(void *s, size_t *avail_in, const uint8_t **next_in, size_t *avail_out, uint8_t **next_out, size_t *total_out) {
  return p_dec_stream(s, avail_in, next_in, avail_out, next_out, total_out);
}

static int br_decompress_all(const uint8_t *input, size_t input_size, int concat, uint8_t **output, size_t *output_size) {
  size_t cap = 65536;
  size_t len = 0;
  uint8_t *buf = (uint8_t*)malloc(cap);
  if (!buf) return -2;
  const uint8_t *next_in = input;
  size_t avail_in = input_size;
  while (1) {
    void *state = p_dec_create(0, 0, 0);
    if (!state) { free(buf); return -2; }
    while (1) {
      if (cap - len < 65536) {
        size_t ncap = cap * 2;
        uint8_t *nbuf = (uint8_t*)realloc(buf, ncap);
        if (!nbuf) { p_dec_destroy(state); free(buf); return -2; }
        buf = nbuf;
        cap = ncap;
      }
      uint8_t *next_out = buf + len;
      size_t avail_out = cap - len;
      size_t total_out = 0;
      int res = p_dec_stream(state, &avail_in, &next_in, &avail_out, &next_out, &total_out);
      len = cap - avail_out;
      if (res == 1) {
        p_dec_destroy(state);
        if (avail_in == 0) {
          *output = buf;
          *output_size = len;
          return 0;
        }
        if (!concat) { free(buf); return -1; }
        break;
      }
      if (res == 3) continue;
      p_dec_destroy(state);
      free(buf);
      return -1;
    }
  }
}
*/
import "C"

import (
	"errors"
	"fmt"
	"unsafe"
)

func initBrotli() error {
	var cerr *C.char
	if C.load_brotli(&cerr) == 0 {
		if cerr != nil {
			return errors.New(C.GoString(cerr))
		}
		return errors.New("could not load brotli shared libraries")
	}
	return nil
}

func compressBrotli(input []byte, quality, lgwin int) ([]byte, error) {
	if err := initBrotli(); err != nil {
		return nil, err
	}
	if lgwin == -1 {
		lgwin = 24
	}
	max := C.br_max_size(C.size_t(len(input)))
	if max == 0 {
		max = C.size_t(len(input) + 1024)
	}
	out := make([]byte, int(max))
	var inPtr *C.uint8_t
	if len(input) > 0 {
		inPtr = (*C.uint8_t)(unsafe.Pointer(&input[0]))
	}
	outSize := max
	ok := C.br_compress(C.int(quality), C.int(lgwin), C.size_t(len(input)), inPtr, &outSize, (*C.uint8_t)(unsafe.Pointer(&out[0])))
	if ok == 0 {
		return nil, errors.New("compression failed")
	}
	return out[:int(outSize)], nil
}

func decompressBrotli(input []byte, concatenated bool) ([]byte, error) {
	if err := initBrotli(); err != nil {
		return nil, err
	}
	var inPtr *C.uint8_t
	if len(input) > 0 {
		inPtr = (*C.uint8_t)(unsafe.Pointer(&input[0]))
	}
	var outPtr *C.uint8_t
	var outSize C.size_t
	concat := C.int(0)
	if concatenated {
		concat = 1
	}
	rc := C.br_decompress_all(inPtr, C.size_t(len(input)), concat, &outPtr, &outSize)
	if rc != 0 {
		return nil, errors.New("corrupt input")
	}
	defer C.free(unsafe.Pointer(outPtr))
	return C.GoBytes(unsafe.Pointer(outPtr), C.int(outSize)), nil
}

func brotliSelfCheck() error {
	out, err := compressBrotli([]byte("x"), 1, 22)
	if err != nil {
		return err
	}
	plain, err := decompressBrotli(out, false)
	if err != nil {
		return err
	}
	if string(plain) != "x" {
		return fmt.Errorf("brotli roundtrip mismatch")
	}
	return nil
}
