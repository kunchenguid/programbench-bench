module programbench/brotli

go 1.21
