package main

import (
	"encoding/base64"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const helpText = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
`

type options struct {
	decompress   bool
	stdout       bool
	force        bool
	remove       bool
	test         bool
	noCopyStat   bool
	verbose      int
	quality      int
	lgwin        int
	concat       bool
	suffix       string
	output       string
	squash       bool
	files        []string
	commentGiven bool
}

func main() {
	code := run(os.Args[1:])
	os.Exit(code)
}

func run(args []string) int {
	opt, exit, err := parseArgs(args)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		fmt.Fprint(os.Stderr, helpText)
		return 1
	}
	if exit {
		return 0
	}
	if opt.test {
		opt.decompress = true
		opt.stdout = true
	}
	if len(opt.files) == 0 {
		opt.files = []string{"-"}
	}
	if opt.output != "" && len(opt.files) != 1 {
		fmt.Fprintln(os.Stderr, "argument --output is invalid with multiple input files")
		return 1
	}
	status := 0
	for _, name := range opt.files {
		if err := processOne(opt, name); err != nil {
			fmt.Fprintln(os.Stderr, err)
			status = 1
		}
	}
	return status
}

func parseArgs(args []string) (options, bool, error) {
	opt := options{quality: 11, lgwin: -1, suffix: ".br"}
	needValue := func(i *int, rest, what string) (string, error) {
		if rest != "" {
			return rest, nil
		}
		*i++
		if *i >= len(args) {
			return "", fmt.Errorf("expected parameter for argument %s", what)
		}
		return args[*i], nil
	}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			opt.files = append(opt.files, args[i+1:]...)
			break
		}
		if a == "-" || !strings.HasPrefix(a, "-") {
			opt.files = append(opt.files, a)
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a[2:], "=")
			switch name {
			case "stdout":
				opt.stdout = true
			case "decompress":
				opt.decompress = true
			case "force":
				opt.force = true
			case "help":
				fmt.Print(helpText)
				return opt, true, nil
			case "rm":
				opt.remove = true
			case "keep":
				opt.remove = false
			case "no-copy-stat":
				opt.noCopyStat = true
			case "test":
				opt.test = true
			case "verbose":
				opt.verbose++
			case "concatenated":
				opt.concat = true
			case "best":
				opt.quality = 11
			case "squash":
				opt.squash = true
			case "version":
				fmt.Println("brotli 1.2.0")
				return opt, true, nil
			case "output", "quality", "lgwin", "large_window", "comment", "dictionary", "suffix":
				if !has {
					return opt, false, fmt.Errorf("must pass the parameter as --%s=value", name)
				}
				if err := setLongValue(&opt, name, val); err != nil {
					return opt, false, err
				}
			default:
				if !has {
					return opt, false, fmt.Errorf("must pass the parameter as --%s=value", name)
				}
				return opt, false, fmt.Errorf("unrecognized option [--%s]", name)
			}
			continue
		}
		shorts := a[1:]
		for j := 0; j < len(shorts); j++ {
			ch := shorts[j]
			rest := shorts[j+1:]
			switch {
			case ch >= '0' && ch <= '9':
				opt.quality = int(ch - '0')
			case ch == 'c':
				opt.stdout = true
			case ch == 'd':
				opt.decompress = true
			case ch == 'f':
				opt.force = true
			case ch == 'h':
				fmt.Print(helpText)
				return opt, true, nil
			case ch == 'j':
				opt.remove = true
			case ch == 'k':
				opt.remove = false
			case ch == 'n':
				opt.noCopyStat = true
			case ch == 't':
				opt.test = true
			case ch == 'v':
				opt.verbose++
			case ch == 'K':
				opt.concat = true
			case ch == 'Z':
				opt.quality = 11
			case ch == 's':
				opt.squash = true
			case strings.ContainsRune("oqwCDS", rune(ch)):
				val, err := needValue(&i, rest, "-"+string(ch))
				if err != nil {
					return opt, false, err
				}
				if err := setShortValue(&opt, ch, val); err != nil {
					return opt, false, err
				}
				j = len(shorts)
			case ch == 'V':
				fmt.Println("brotli 1.2.0")
				return opt, true, nil
			default:
				return opt, false, fmt.Errorf("unrecognized option [-%c]", ch)
			}
		}
	}
	return opt, false, nil
}

func setLongValue(opt *options, name, val string) error {
	switch name {
	case "output":
		opt.output = val
	case "quality":
		q, err := strconv.Atoi(val)
		if err != nil || q < 0 || q > 11 {
			return fmt.Errorf("error parsing quality value [%s]", val)
		}
		opt.quality = q
	case "lgwin", "large_window":
		w, err := strconv.Atoi(val)
		max := 24
		if name == "large_window" {
			max = 30
		}
		if err != nil || !(w == 0 || (w >= 10 && w <= max)) {
			return fmt.Errorf("error parsing lgwin value [%s]", val)
		}
		opt.lgwin = w
	case "comment":
		b, err := base64.StdEncoding.DecodeString(val)
		if err != nil || len(b) > 80 {
			return fmt.Errorf("error parsing comment value [%s]", val)
		}
		opt.commentGiven = true
	case "dictionary":
		if _, err := os.ReadFile(val); err != nil {
			return fmt.Errorf("failed to open dictionary [%s]: %v", val, err)
		}
	case "suffix":
		opt.suffix = val
	}
	return nil
}

func setShortValue(opt *options, ch byte, val string) error {
	switch ch {
	case 'o':
		return setLongValue(opt, "output", val)
	case 'q':
		return setLongValue(opt, "quality", val)
	case 'w':
		return setLongValue(opt, "lgwin", val)
	case 'C':
		return setLongValue(opt, "comment", val)
	case 'D':
		return setLongValue(opt, "dictionary", val)
	case 'S':
		return setLongValue(opt, "suffix", val)
	}
	return nil
}

func processOne(opt options, name string) error {
	in, info, err := readInput(name)
	if err != nil {
		return err
	}
	var out []byte
	if opt.decompress {
		out, err = decompressBrotli(in, opt.concat)
		if err != nil {
			if name == "-" {
				return fmt.Errorf("corrupt input [con]")
			}
			return fmt.Errorf("corrupt input [%s]", name)
		}
	} else {
		out, err = compressBrotli(in, opt.quality, opt.lgwin)
		if err != nil {
			return fmt.Errorf("failed to compress [%s]: %v", displayName(name), err)
		}
	}
	if opt.test {
		if opt.verbose > 0 && name != "-" {
			fmt.Fprintf(os.Stderr, "%s: OK\n", name)
		}
		return nil
	}
	if opt.stdout || name == "-" {
		_, err = os.Stdout.Write(out)
		return err
	}
	outName, err := outputName(opt, name)
	if err != nil {
		return err
	}
	if !opt.force {
		if _, err := os.Stat(outName); err == nil {
			return fmt.Errorf("failed to open output file [%s]: File exists", outName)
		}
	}
	if opt.squash && !opt.decompress && len(out) >= len(in) {
		_ = os.Remove(outName)
		return nil
	}
	if err := os.WriteFile(outName, out, 0666); err != nil {
		return fmt.Errorf("failed to write output file [%s]: %v", outName, err)
	}
	if !opt.noCopyStat && info != nil {
		_ = os.Chmod(outName, info.Mode().Perm())
	}
	if opt.remove {
		_ = os.Remove(name)
	}
	return nil
}

func readInput(name string) ([]byte, os.FileInfo, error) {
	if name == "-" {
		b, err := io.ReadAll(os.Stdin)
		return b, nil, err
	}
	info, err := os.Stat(name)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to open input file [%s]: %v", name, err)
	}
	if info.IsDir() {
		return nil, nil, fmt.Errorf("failed to open input file [%s]: Is a directory", name)
	}
	b, err := os.ReadFile(name)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to open input file [%s]: %v", name, err)
	}
	return b, info, nil
}

func outputName(opt options, input string) (string, error) {
	if opt.output != "" {
		return opt.output, nil
	}
	if opt.decompress {
		if opt.suffix != "" && strings.HasSuffix(input, opt.suffix) {
			return strings.TrimSuffix(input, opt.suffix), nil
		}
		if ext := filepath.Ext(input); ext == ".br" && opt.suffix == ".br" {
			return strings.TrimSuffix(input, ".br"), nil
		}
		return "", fmt.Errorf("empty output file name [%s]", input)
	}
	return input + opt.suffix, nil
}

func displayName(name string) string {
	if name == "-" {
		return "con"
	}
	return name
}
