package main

import (
	"bytes"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const helpText = `Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
`

type options struct {
	decompress   bool
	test         bool
	stdout       bool
	force        bool
	remove       bool
	noCopyStat   bool
	verbose      int
	concatenated bool
	squash       bool
	output       string
	suffix       string
	comment      []byte
	dictionary   string
	files        []string
}

func main() {
	os.Exit(run(os.Args))
}

func run(args []string) int {
	opts, err := parseArgs(args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if opts == nil {
		return 0
	}
	if opts.suffix == "" {
		opts.suffix = ".br"
	}
	if opts.test {
		opts.decompress = true
		opts.stdout = true
	}
	if opts.output != "" && len(inputList(opts.files)) != 1 {
		fmt.Fprintln(os.Stderr, "the --output option is allowed only with a single input file")
		return 1
	}
	if opts.dictionary != "" {
		if _, err := os.ReadFile(opts.dictionary); err != nil {
			fmt.Fprintf(os.Stderr, "failed to open dictionary [%s]: %v\n", opts.dictionary, err)
			return 1
		}
	}
	files := inputList(opts.files)
	ok := true
	for _, name := range files {
		if err := processOne(opts, name); err != nil {
			fmt.Fprintln(os.Stderr, err)
			ok = false
		}
	}
	if !ok {
		return 1
	}
	return 0
}

func inputList(files []string) []string {
	if len(files) == 0 {
		return []string{"-"}
	}
	return files
}

func parseArgs(args []string) (*options, error) {
	o := &options{suffix: ".br"}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			o.files = append(o.files, args[i+1:]...)
			break
		}
		if a == "" || a == "-" || !strings.HasPrefix(a, "-") {
			o.files = append(o.files, a)
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasVal := strings.Cut(a[2:], "=")
			need := func() (string, error) {
				if hasVal {
					return val, nil
				}
				i++
				if i >= len(args) {
					return "", fmt.Errorf("option --%s requires an argument", name)
				}
				return args[i], nil
			}
			switch name {
			case "stdout":
				o.stdout = true
			case "decompress":
				o.decompress = true
			case "force":
				o.force = true
			case "help":
				fmt.Print(helpText)
				return nil, nil
			case "rm":
				o.remove = true
			case "keep":
				o.remove = false
			case "squash":
				o.squash = true
			case "no-copy-stat":
				o.noCopyStat = true
			case "test":
				o.test = true
			case "verbose":
				o.verbose++
			case "concatenated":
				o.concatenated = true
			case "version":
				fmt.Println("brotli 1.2.0")
				return nil, nil
			case "best":
			case "quality", "lgwin", "large_window", "output", "suffix", "comment", "dictionary":
				v, err := need()
				if err != nil {
					return nil, err
				}
				if err := setValue(o, name, v); err != nil {
					return nil, err
				}
			default:
				return nil, fmt.Errorf("unknown option: --%s", name)
			}
			continue
		}
		for j := 1; j < len(a); j++ {
			ch := a[j]
			takeRest := func() (string, error) {
				if j+1 < len(a) {
					v := a[j+1:]
					j = len(a)
					return v, nil
				}
				i++
				if i >= len(args) {
					return "", fmt.Errorf("option -%c requires an argument", ch)
				}
				return args[i], nil
			}
			switch ch {
			case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9':
			case 'c':
				o.stdout = true
			case 'd':
				o.decompress = true
			case 'f':
				o.force = true
			case 'h':
				fmt.Print(helpText)
				return nil, nil
			case 'j':
				o.remove = true
			case 'k':
				o.remove = false
			case 's':
				o.squash = true
			case 'n':
				o.noCopyStat = true
			case 't':
				o.test = true
			case 'v':
				o.verbose++
			case 'K':
				o.concatenated = true
			case 'V':
				fmt.Println("brotli 1.2.0")
				return nil, nil
			case 'Z':
			case 'q', 'w', 'o', 'S', 'C', 'D':
				v, err := takeRest()
				if err != nil {
					return nil, err
				}
				long := map[byte]string{'q': "quality", 'w': "lgwin", 'o': "output", 'S': "suffix", 'C': "comment", 'D': "dictionary"}[ch]
				if err := setValue(o, long, v); err != nil {
					return nil, err
				}
			default:
				return nil, fmt.Errorf("unknown option: -%c", ch)
			}
		}
	}
	return o, nil
}

func setValue(o *options, name, value string) error {
	switch name {
	case "quality":
		n, err := strconv.Atoi(value)
		if err != nil || n < 0 || n > 11 {
			return fmt.Errorf("invalid quality value: %s", value)
		}
	case "lgwin":
		n, err := strconv.Atoi(value)
		if err != nil || !(n == 0 || (n >= 10 && n <= 24)) {
			return fmt.Errorf("invalid lgwin value: %s", value)
		}
	case "large_window":
		n, err := strconv.Atoi(value)
		if err != nil || n < 0 || n > 30 {
			return fmt.Errorf("invalid large_window value: %s", value)
		}
	case "output":
		o.output = value
	case "suffix":
		o.suffix = value
	case "comment":
		b, err := base64.StdEncoding.DecodeString(value)
		if err != nil {
			return fmt.Errorf("invalid comment: %v", err)
		}
		if len(b) > 80 {
			return errors.New("comment is too long")
		}
		o.comment = b
	case "dictionary":
		o.dictionary = value
	}
	return nil
}

func processOne(o *options, name string) error {
	var in *os.File
	var err error
	if name == "-" {
		in = os.Stdin
	} else {
		in, err = os.Open(name)
		if err != nil {
			return fmt.Errorf("failed to open input file [%s]: %v", name, err)
		}
		defer in.Close()
	}
	var data bytes.Buffer
	if o.decompress {
		err = decodeBrotli(in, &data, o.concatenated)
	} else {
		err = encodeStoredBrotli(in, &data)
	}
	if err != nil {
		return fmt.Errorf("%s: %v", displayName(name), err)
	}
	if o.test {
		return nil
	}
	if o.stdout || name == "-" && o.output == "" {
		_, err = os.Stdout.Write(data.Bytes())
		return err
	}
	outName := o.output
	if outName == "" {
		if o.decompress {
			if !strings.HasSuffix(name, o.suffix) {
				return fmt.Errorf("input file [%s] does not have suffix [%s]", name, o.suffix)
			}
			outName = strings.TrimSuffix(name, o.suffix)
			if outName == "" {
				outName = name + ".out"
			}
		} else {
			outName = name + o.suffix
		}
	}
	if !o.force {
		if _, err := os.Stat(outName); err == nil {
			return fmt.Errorf("output file [%s] already exists", outName)
		}
	}
	mode := os.FileMode(0644)
	if name != "-" && !o.noCopyStat {
		if st, err := os.Stat(name); err == nil {
			mode = st.Mode() & 0777
		}
	}
	if err := os.WriteFile(outName, data.Bytes(), mode); err != nil {
		return fmt.Errorf("failed to write output file [%s]: %v", outName, err)
	}
	if o.squash && name != "-" {
		if src, err1 := os.Stat(name); err1 == nil {
			if dst, err2 := os.Stat(outName); err2 == nil && dst.Size() > src.Size() {
				_ = os.Remove(outName)
			}
		}
	}
	if o.remove && name != "-" {
		_ = os.Remove(name)
	}
	return nil
}

func displayName(name string) string {
	if name == "-" {
		return "stdin"
	}
	return filepath.Clean(name)
}

func encodeStoredBrotli(r io.Reader, w io.Writer) error {
	buf := make([]byte, 65536)
	wrote := false
	first := true
	for {
		n, er := io.ReadFull(r, buf)
		if er == io.EOF {
			break
		}
		if er == io.ErrUnexpectedEOF {
			er = nil
		}
		if n > 0 {
			if err := writeStoredBlock(w, buf[:n], first); err != nil {
				return err
			}
			wrote = true
			first = false
		}
		if er != nil {
			return er
		}
		if n < len(buf) {
			break
		}
	}
	if !wrote {
		_, err := w.Write([]byte{0x33})
		return err
	}
	_, err := w.Write([]byte{0x03})
	return err
}

func writeStoredBlock(w io.Writer, data []byte, first bool) error {
	if len(data) == 0 || len(data) > 65536 {
		return errors.New("internal stored block size error")
	}
	var v uint32
	if first {
		v = uint32((len(data)-1)<<7) | 3 | (1 << 23)
	} else {
		v = uint32((len(data)-1)<<3) | (1 << 19)
	}
	hdr := []byte{byte(v), byte(v >> 8), byte(v >> 16)}
	if _, err := w.Write(hdr); err != nil {
		return err
	}
	_, err := w.Write(data)
	return err
}

func decodeBrotli(r io.Reader, w io.Writer, concatenated bool) error {
	all, err := io.ReadAll(r)
	if err != nil {
		return err
	}
	off := 0
	decodedAny := false
	for {
		n, err := decodeOneStored(all[off:], w)
		if err != nil {
			return err
		}
		decodedAny = true
		off += n
		if off == len(all) {
			return nil
		}
		if !concatenated {
			rest := bytes.TrimSpace(all[off:])
			if len(rest) == 0 {
				return nil
			}
			if decodedAny {
				return errors.New("corrupt input: trailing data")
			}
		}
	}
}

func decodeOneStored(in []byte, w io.Writer) (int, error) {
	if len(in) == 0 {
		return 0, errors.New("corrupt input: unexpected end of stream")
	}
	if in[0] == 0x33 {
		return 1, nil
	}
	off := 0
	for {
		if off > 0 && off < len(in) && in[off] == 0x03 {
			return off + 1, nil
		}
		if off+3 > len(in) {
			return 0, errors.New("corrupt input: incomplete meta-block header")
		}
		v := uint32(in[off]) | uint32(in[off+1])<<8 | uint32(in[off+2])<<16
		var n int
		if off == 0 && v&0x7f == 3 && v&(1<<23) != 0 {
			n = int((v>>7)&0xffff) + 1
		} else if off > 0 && v&7 == 0 && v&(1<<19) != 0 {
			n = int((v>>3)&0xffff) + 1
		} else {
			return 0, errors.New("unsupported brotli stream: compressed meta-blocks are not implemented")
		}
		off += 3
		if off+n > len(in) {
			return 0, errors.New("corrupt input: incomplete meta-block")
		}
		if _, err := w.Write(in[off : off+n]); err != nil {
			return 0, err
		}
		off += n
	}
}
