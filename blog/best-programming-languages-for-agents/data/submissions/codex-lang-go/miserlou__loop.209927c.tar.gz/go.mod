module loop-reimpl

go 1.21
