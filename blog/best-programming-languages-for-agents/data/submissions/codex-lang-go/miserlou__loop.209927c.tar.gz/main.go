package main

import (
	"bufio"
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const helpText = `loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing ` + "`" + `loop` + "`" + ` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
`

type config struct {
	onlyLast, readStdin, summary, errDuration        bool
	untilChanges, untilFail, untilSame, untilSuccess bool
	every, forDuration                               time.Duration
	hasDuration                                      bool
	untilTime                                        time.Time
	hasUntilTime                                     bool
	num                                              float64
	hasNum                                           bool
	countBy, offset                                  float64
	decimalCount                                     bool
	forList                                          []string
	untilContains                                    string
	hasContains                                      bool
	untilError                                       int
	hasUntilError                                    bool
	untilMatch                                       string
	re                                               *regexp.Regexp
	cmd                                              []string
}

type optErr struct{ msg string }

func (e optErr) Error() string { return e.msg }

func main() {
	cfg, stop, err := parse(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(1)
	}
	if stop {
		return
	}
	if len(cfg.cmd) == 0 {
		fmt.Println("No command supplied, exiting.")
		return
	}
	if cfg.readStdin {
		cfg.forList = readLines(os.Stdin)
	}
	code := run(cfg)
	os.Exit(code)
}

func parse(args []string) (config, bool, error) {
	cfg := config{every: time.Microsecond, countBy: 1}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			cfg.cmd = append(cfg.cmd, args[i+1:]...)
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			cfg.cmd = append(cfg.cmd, args[i:]...)
			break
		}
		inline := ""
		if strings.HasPrefix(a, "--") {
			if eq := strings.IndexByte(a, '='); eq >= 0 {
				inline = a[eq+1:]
				a = a[:eq]
			}
		}
		switch a {
		case "-h", "--help":
			fmt.Print(helpText)
			return cfg, true, nil
		case "-V", "--version":
			fmt.Println("loop 0.6.1")
			return cfg, true, nil
		case "-D", "--error-duration":
			cfg.errDuration = true
		case "-l", "--only-last":
			cfg.onlyLast = true
		case "-i", "--stdin":
			cfg.readStdin = true
		case "--summary":
			cfg.summary = true
		case "-C", "--until-changes":
			cfg.untilChanges = true
		case "-f", "--until-fail":
			cfg.untilFail = true
		case "-S", "--until-same":
			cfg.untilSame = true
		case "-s", "--until-success":
			cfg.untilSuccess = true
		case "-b", "--count-by":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				return cfg, false, invalid("count-by", "count_by", err.Error())
			}
			cfg.countBy = f
			if strings.Contains(v, ".") {
				cfg.decimalCount = true
			}
		case "-o", "--offset":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				return cfg, false, invalid("offset", "offset", err.Error())
			}
			cfg.offset = f
			if strings.Contains(v, ".") {
				cfg.decimalCount = true
			}
		case "-n", "--num":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				return cfg, false, invalid("num", "num", "invalid float literal")
			}
			cfg.num, cfg.hasNum = f, true
		case "-e", "--every":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			d, err := parseDuration(v)
			if err != nil {
				return cfg, false, invalid("every", "every", err.Error())
			}
			cfg.every = d
		case "-d", "--for-duration":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			d, err := parseDuration(v)
			if err != nil {
				return cfg, false, invalid("for-duration", "for_duration", err.Error())
			}
			cfg.forDuration, cfg.hasDuration = d, true
		case "--for":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			cfg.forList = strings.Split(v, ",")
		case "-c", "--until-contains":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			cfg.untilContains, cfg.hasContains = v, true
		case "-r", "--until-error":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			n, err := strconv.Atoi(v)
			if err != nil {
				return cfg, false, invalid("until-error", "until_error", err.Error())
			}
			cfg.untilError, cfg.hasUntilError = n, true
		case "-m", "--until-match":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			re, err := regexp.Compile(v)
			if err != nil {
				return cfg, false, invalid("until-match", "until_match", err.Error())
			}
			cfg.untilMatch, cfg.re = v, re
		case "-t", "--until-time":
			v, ok := optionValue(args, &i, a, inline)
			if !ok {
				return cfg, false, missing(a)
			}
			t, err := time.ParseInLocation("2006-01-02 15:04:05", v, time.UTC)
			if err != nil {
				return cfg, false, invalid("until-time", "until_time", err.Error())
			}
			cfg.untilTime, cfg.hasUntilTime = t, true
		default:
			return cfg, false, optErr{fmt.Sprintf("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help", a)}
		}
	}
	return cfg, false, nil
}

func optionValue(args []string, i *int, opt, inline string) (string, bool) {
	if inline != "" || strings.Contains(opt, "=") {
		return inline, true
	}
	return nextVal(args, i, opt)
}

func nextVal(args []string, i *int, opt string) (string, bool) {
	if *i+1 >= len(args) {
		return "", false
	}
	*i++
	return args[*i], true
}
func missing(opt string) error {
	return optErr{fmt.Sprintf("error: The argument '%s' requires a value but none was supplied", opt)}
}
func invalid(long, name, why string) error {
	return optErr{fmt.Sprintf("error: Invalid value for '--%s <%s>': %s", long, name, why)}
}

func parseDuration(s string) (time.Duration, error) {
	if s == "" || (s[0] < '0' || s[0] > '9') {
		return 0, fmt.Errorf("expected number at 0")
	}
	re := regexp.MustCompile(`(\d+(?:\.\d+)?)(h|ms|us|µs|m|s)`)
	pos := 0
	var total time.Duration
	for pos < len(s) {
		loc := re.FindStringSubmatchIndex(s[pos:])
		if loc == nil || loc[0] != 0 {
			return 0, fmt.Errorf("expected number at %d", pos)
		}
		num := s[pos+loc[2] : pos+loc[3]]
		unit := s[pos+loc[4] : pos+loc[5]]
		f, _ := strconv.ParseFloat(num, 64)
		var mult time.Duration
		switch unit {
		case "h":
			mult = time.Hour
		case "m":
			mult = time.Minute
		case "s":
			mult = time.Second
		case "ms":
			mult = time.Millisecond
		case "us", "µs":
			mult = time.Microsecond
		}
		total += time.Duration(f * float64(mult))
		pos += loc[1]
	}
	return total, nil
}

func readLines(r io.Reader) []string {
	var out []string
	sc := bufio.NewScanner(r)
	for sc.Scan() {
		out = append(out, sc.Text())
	}
	return out
}

func run(cfg config) int {
	command := strings.Join(cfg.cmd, " ")
	start := time.Now().UTC()
	successes, runs := 0, 0
	failures := []int{}
	var lastOut []byte
	var prev []byte
	exitCode := 0
	max := int(^uint(0) >> 1)
	if cfg.hasNum {
		max = int(cfg.num)
	}
	if !cfg.hasNum && len(cfg.forList) > 0 {
		max = len(cfg.forList)
	}

	for runs < max {
		if cfg.hasDuration && time.Since(start) >= cfg.forDuration {
			exitCode = 124
			break
		}
		if cfg.hasUntilTime && time.Now().UTC().After(cfg.untilTime) {
			break
		}
		count := cfg.offset + float64(runs)*cfg.countBy
		item := ""
		if len(cfg.forList) > 0 {
			idx := runs
			if idx >= len(cfg.forList) {
				idx = len(cfg.forList) - 1
			}
			item = cfg.forList[idx]
		}
		out, status := execCommandWithEnv(command, formatCount(count, cfg.decimalCount), item)
		runs++
		if status == 0 {
			successes++
		} else {
			failures = append(failures, status)
		}
		lastOut = out
		shouldPrint := !cfg.onlyLast
		if shouldPrint {
			os.Stdout.Write(out)
		}

		stop := false
		if cfg.untilSuccess && status == 0 {
			stop = true
		}
		if cfg.untilFail && status != 0 {
			stop = true
		}
		if cfg.hasUntilError && status == cfg.untilError {
			stop = true
		}
		if cfg.hasContains && strings.Contains(string(out), cfg.untilContains) {
			stop = true
		}
		if cfg.re != nil && cfg.re.Match(out) {
			stop = true
		}
		if cfg.untilChanges && prev != nil && !bytes.Equal(out, prev) {
			stop = true
		}
		if cfg.untilSame && prev != nil && bytes.Equal(out, prev) {
			stop = true
		}
		prev = append([]byte(nil), out...)
		if stop {
			break
		}
		if cfg.every > 0 {
			time.Sleep(cfg.every)
		}
	}
	if cfg.onlyLast && len(lastOut) > 0 {
		os.Stdout.Write(lastOut)
	}
	if cfg.summary {
		fmt.Printf("Total runs:\t%d\n", runs)
		fmt.Printf("Successes:\t%d\n", successes)
		fmt.Printf("Failures:\t%d", len(failures))
		if len(failures) > 0 {
			parts := make([]string, len(failures))
			for i, v := range failures {
				parts[i] = strconv.Itoa(v)
			}
			fmt.Printf(" (%s)", strings.Join(parts, ", "))
		}
		fmt.Println()
	}
	if cfg.errDuration && exitCode == 124 {
		return 124
	}
	return 0
}

func execCommandWithEnv(command, count, item string) ([]byte, int) {
	cmd := exec.Command("sh", "-c", command)
	cmd.Env = append(os.Environ(), "COUNT="+count, "ITEM="+item)
	out, err := cmd.CombinedOutput()
	if err == nil {
		return out, 0
	}
	if ee, ok := err.(*exec.ExitError); ok {
		return out, ee.ExitCode()
	}
	return out, 1
}

func formatCount(f float64, decimal bool) string {
	if decimal {
		return fmt.Sprintf("%.1f", f)
	}
	if f == float64(int64(f)) {
		return fmt.Sprintf("%d", int64(f))
	}
	return strconv.FormatFloat(f, 'f', -1, 64)
}
