package main

import (
    "bufio"
    "bytes"
    "encoding/csv"
    "encoding/json"
    "errors"
    "fmt"
    "io"
    "os"
    "os/exec"
    "sort"
    "strconv"
    "strings"
    "text/tabwriter"
    "time"

    "github.com/spf13/cobra"
)

type Secret struct {
    Value string            `json:"value"`
    Version int             `json:"version"`
    User string             `json:"user"`
    Modified string         `json:"modified"`
    Tags map[string]string  `json:"tags,omitempty"`
    History []History       `json:"history,omitempty"`
}

type History struct { Version int `json:"version"`; Value string `json:"value"`; User string `json:"user"`; Modified string `json:"modified"` }

type Store map[string]map[string]*Secret

var backend, s3bucket, kmsAlias, retryMode string
var retries int
var verbose bool

const nullErr = "Not implemented for Null Store"

func main() {
    root := rootCmd()
    if err := root.Execute(); err != nil { os.Exit(1) }
}

func rootCmd() *cobra.Command {
    cmd := &cobra.Command{Use:"chamber", Short:"CLI for storing secrets", SilenceUsage:true, SilenceErrors:false, Run: func(cmd *cobra.Command,args []string){ cmd.Help() }}
    cmd.DisableFlagsInUseLine = true
    cmd.PersistentFlags().StringVarP(&backend,"backend","b", envDefault("CHAMBER_SECRET_BACKEND","ssm"), "Backend to use; AKA $CHAMBER_SECRET_BACKEND\n\tnull: no-op\n\tssm: SSM Parameter Store\n\tsecretsmanager: Secrets Manager\n\ts3: S3; requires --backend-s3-bucket\n\ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys).")
    cmd.PersistentFlags().StringVar(&s3bucket,"backend-s3-bucket", envDefault("CHAMBER_S3_BUCKET",""), "bucket for S3 backend; AKA $CHAMBER_S3_BUCKET")
    cmd.PersistentFlags().StringVar(&kmsAlias,"kms-key-alias", envDefault("CHAMBER_KMS_KEY_ALIAS","alias/parameter_store_key"), "KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend.")
    cmd.PersistentFlags().IntVarP(&retries,"retries","r", envInt("CHAMBER_RETRIES",10), "For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES")
    cmd.PersistentFlags().StringVar(&retryMode,"retry-mode", envDefault("CHAMBER_RETRY_MODE","standard"), "For SSM, the model used to retry requests\n standard\n adaptive")
    cmd.PersistentFlags().BoolVar(&verbose,"verbose", false, "Print more information to STDERR")
    cmd.AddCommand(deleteCmd(), envCmd(), execCmd(), exportCmd(), findCmd(), historyCmd(), importCmd(), listCmd(), listServicesCmd(), readCmd(), tagCmd(), versionCmd(), writeCmd())
    return cmd
}

func envDefault(k,d string) string { if v:=os.Getenv(k); v!="" { return v }; return d }
func envInt(k string,d int) int { if v:=os.Getenv(k); v!="" { if n,e:=strconv.Atoi(v); e==nil { return n } }; return d }
func isNull() bool { return backend == "null" }
func fail(prefix string, err error) error { return fmt.Errorf("%s: %s", prefix, err.Error()) }

func storePath() string { if p:=os.Getenv("CHAMBER_STORE_FILE"); p!="" { return p }; return ".chamber_store.json" }
func loadStore() Store { b,err:=os.ReadFile(storePath()); if err!=nil { return Store{} }; var s Store; if json.Unmarshal(b,&s)!=nil || s==nil { return Store{} }; return s }
func saveStore(s Store) error { b,_:=json.MarshalIndent(s,"","  "); return os.WriteFile(storePath(), b, 0644) }
func normKey(k string) string { k=strings.TrimSpace(k); k=strings.ReplaceAll(k,"-","_"); k=strings.ReplaceAll(k,".","_"); return strings.ToLower(k) }
func envName(k string, preserve bool) string { n:=strings.ReplaceAll(k,"-","_"); n=strings.ReplaceAll(n,".","_"); if !preserve { n=strings.ToUpper(n) }; return n }
func currentUser() string { if u:=os.Getenv("USER"); u!="" { return u }; return "agent" }

func readCmd() *cobra.Command { var quiet bool; var ver int
    c:=&cobra.Command{Use:"read <service> <key>", Short:"Read a specific secret from the parameter store", Args:cobra.ExactArgs(2), RunE: func(cmd *cobra.Command,args []string) error { if isNull(){return fail("Failed to read", errors.New(nullErr))}; s:=loadStore(); sec:=getSecret(s,args[0],normKey(args[1])); if sec==nil { return fail("Failed to read", fmt.Errorf("secret not found"))}; val:=sec.Value; if ver>0 { for _,h:= range sec.History { if h.Version==ver { val=h.Value; break } } }; if quiet { fmt.Fprintln(cmd.OutOrStdout(), val) } else { fmt.Fprintf(cmd.OutOrStdout(), "%s\n", val) }; return nil }}
    c.Flags().BoolVarP(&quiet,"quiet","q",false,"Only print the secret"); c.Flags().IntVarP(&ver,"version","v",-1,"The version number of the secret. Defaults to latest."); return c }

func writeCmd() *cobra.Command { var single, skip bool; tags:=map[string]string{}
    c:=&cobra.Command{Use:"write <service> <key> [--] <value|->", Short:"write a secret", Args:cobra.ExactArgs(3), RunE: func(cmd *cobra.Command,args []string) error { if isNull(){return errors.New("Write is not implemented for Null Store")}; val:=args[2]; if val=="-" { b,_:=io.ReadAll(os.Stdin); val=string(b); if single { val=strings.TrimRight(val,"\r\n") } }; s:=loadStore(); if s[args[0]]==nil { s[args[0]]=map[string]*Secret{} }; key:=normKey(args[1]); old:=s[args[0]][key]; if skip && old!=nil && old.Value==val { return nil }; now:=time.Now().UTC().Format(time.RFC3339); sec:=&Secret{Value:val,Version:1,User:currentUser(),Modified:now,Tags:map[string]string{}}; if old!=nil { sec.Version=old.Version+1; sec.History=append(old.History, History{Version:old.Version,Value:old.Value,User:old.User,Modified:old.Modified}); sec.Tags=old.Tags }; for k,v:= range tags { sec.Tags[k]=v }; s[args[0]][key]=sec; return saveStore(s) }}
    c.Flags().BoolVarP(&single,"singleline","s",false,"Insert single line parameter (end with \\n)"); c.Flags().BoolVar(&skip,"skip-unchanged",false,"Skip writing secret if value is unchanged"); c.Flags().StringToStringVarP(&tags,"tags","t",map[string]string{},"Add tags to the secret; new secrets only"); return c }

func deleteCmd() *cobra.Command { var exact bool; c:=&cobra.Command{Use:"delete <service> <key>", Short:"Delete a secret, including all versions", Args:cobra.ExactArgs(2), RunE: func(cmd *cobra.Command,args []string) error { if isNull(){return errors.New(nullErr)}; s:=loadStore(); key:=args[1]; if !exact { key=normKey(key) }; if s[args[0]]!=nil { delete(s[args[0]],key) }; return saveStore(s) }}; c.Flags().BoolVar(&exact,"exact-key",false,"Prevent normalization of the provided key in order to delete any keys that match the exact provided casing."); return c }

func listCmd() *cobra.Command { var expand, byTime, byUser, byVer bool; c:=&cobra.Command{Use:"list <service>", Short:"List the secrets set for a service", Args:cobra.ExactArgs(1), RunE: func(cmd *cobra.Command,args []string) error { s:=loadStore(); if isNull(){s=Store{}}; rows:=secretsFor(s,args[0]); sort.Slice(rows, func(i,j int)bool{ if byTime {return rows[i].Modified<rows[j].Modified}; if byUser {return rows[i].User<rows[j].User}; if byVer {return rows[i].Version<rows[j].Version}; return rows[i].Name<rows[j].Name }); tw:=tabwriter.NewWriter(cmd.OutOrStdout(),0,0,2,' ',0); if expand { fmt.Fprintln(tw,"Key\tValue\tVersion\tLastModified\tUser") } else { fmt.Fprintln(tw,"Key\tVersion\t\tLastModified\tUser") }; for _,r:= range rows { if expand { fmt.Fprintf(tw,"%s\t%s\t%d\t%s\t%s\n",r.Name,r.Value,r.Version,r.Modified,r.User) } else { fmt.Fprintf(tw,"%s\t%d\t\t%s\t%s\n",r.Name,r.Version,r.Modified,r.User) } }; tw.Flush(); return nil }}; c.Flags().BoolVarP(&expand,"expand","e",false,"Expand parameter list with values"); c.Flags().BoolVarP(&byTime,"time","t",false,"Sort by modified time"); c.Flags().BoolVarP(&byUser,"user","u",false,"Sort by user"); c.Flags().BoolVarP(&byVer,"version","v",false,"Sort by version"); return c }

type row struct{ Name string; *Secret }
func secretsFor(s Store, svc string) []row { var out []row; for k,v:= range s[svc] { out=append(out,row{k,v}) }; return out }
func getSecret(s Store, svc,key string)*Secret{ if s[svc]==nil {return nil}; return s[svc][key] }

func envCmd() *cobra.Command { var preserve, esc bool; c:=&cobra.Command{Use:"env <service>", Short:"Print the secrets from the parameter store in a format to export as environment variables", Args:cobra.ExactArgs(1), RunE: func(cmd *cobra.Command,args []string) error { s:=loadStore(); if isNull(){s=Store{}}; for _,r:= range secretsFor(s,args[0]) { val:=r.Value; if esc { val=strconv.Quote(val); fmt.Fprintf(cmd.OutOrStdout(), "export %s=%s\n", envName(r.Name,preserve), val) } else { fmt.Fprintf(cmd.OutOrStdout(), "export %s=%q\n", envName(r.Name,preserve), val) } }; return nil }}; c.Flags().BoolVarP(&preserve,"preserve-case","p",false,"preserve variable name case"); c.Flags().BoolVarP(&esc,"escape-strings","e",false,"escape special characters in values"); return c }

func exportCmd() *cobra.Command { var format,outfile string; c:=&cobra.Command{Use:"export <service...>", Short:"Exports parameters in the specified format", Args:cobra.MinimumNArgs(1), RunE: func(cmd *cobra.Command,args []string) error { data:=map[string]string{}; s:=loadStore(); if isNull(){s=Store{}}; for _,svc:= range args { for _,r:= range secretsFor(s,svc) { data[r.Name]=r.Value } }; b,err:=renderExport(format,data); if err!=nil { return err }; if outfile!="" { return os.WriteFile(outfile,b,0644) }; _,err=cmd.OutOrStdout().Write(b); return err }}; c.Flags().StringVarP(&format,"format","f","json","Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars)"); c.Flags().StringVarP(&outfile,"output-file","o","","Output file (default is standard output)"); return c }
func renderExport(f string,m map[string]string)([]byte,error){ keys:=make([]string,0,len(m)); for k:=range m{keys=append(keys,k)}; sort.Strings(keys); var b bytes.Buffer; switch f { case "json": enc:=json.NewEncoder(&b); enc.SetIndent("","  "); if len(m)==0 { b.WriteString("{}\n") } else { enc.Encode(m) }; case "yaml": for _,k:= range keys { fmt.Fprintf(&b,"%s: %q\n",k,m[k]) }; case "java-properties","dotenv": for _,k:= range keys { fmt.Fprintf(&b,"%s=%s\n",k,m[k]) }; case "tfvars": for _,k:= range keys { fmt.Fprintf(&b,"%s = %q\n",k,m[k]) }; case "csv","tsv": sep:=','; if f=="tsv"{sep='\t'}; w:=csv.NewWriter(&b); w.Comma=sep; for _,k:=range keys{ w.Write([]string{k,m[k]})}; w.Flush(); default: return nil,fmt.Errorf("invalid output format: %s",f)}; return b.Bytes(),nil }

func importCmd() *cobra.Command { var normalize bool; c:=&cobra.Command{Use:"import <service> <file|->", Short:"import secrets from json or yaml", Args:cobra.ExactArgs(2), RunE: func(cmd *cobra.Command,args []string) error { var b []byte; var err error; if args[1]=="-" { b,err=io.ReadAll(os.Stdin) } else { b,err=os.ReadFile(args[1]) }; if err!=nil { return err }; vals:=parseImport(b); s:=loadStore(); if s[args[0]]==nil { s[args[0]]=map[string]*Secret{} }; now:=time.Now().UTC().Format(time.RFC3339); for k,v:= range vals { key:=k; if normalize { key=normKey(k) }; old:=s[args[0]][key]; ver:=1; hist:=[]History{}; if old!=nil { ver=old.Version+1; hist=append(old.History, History{Version:old.Version,Value:old.Value,User:old.User,Modified:old.Modified})}; s[args[0]][key]=&Secret{Value:v,Version:ver,User:currentUser(),Modified:now,History:hist,Tags:map[string]string{}} }; return saveStore(s) }}; c.Flags().BoolVar(&normalize,"normalize-keys",false,"Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source."); return c }
func parseImport(b []byte) map[string]string { m:=map[string]string{}; var raw map[string]interface{}; if json.Unmarshal(b,&raw)==nil { for k,v:= range raw { m[k]=fmt.Sprint(v) }; return m }; sc:=bufio.NewScanner(bytes.NewReader(b)); for sc.Scan(){ line:=strings.TrimSpace(sc.Text()); if line==""||strings.HasPrefix(line,"#"){continue}; if i:=strings.Index(line,":"); i>=0 { k:=strings.TrimSpace(line[:i]); v:=strings.Trim(strings.TrimSpace(line[i+1:]),"'\""); m[k]=v } }; return m }

func findCmd()*cobra.Command{ var byVal bool; c:=&cobra.Command{Use:"find <secret name>", Short:"Find the given secret across all services", Args:cobra.ExactArgs(1), RunE: func(cmd *cobra.Command,args []string) error { tw:=tabwriter.NewWriter(cmd.OutOrStdout(),0,0,2,' ',0); fmt.Fprintln(tw,"Service"); s:=loadStore(); if isNull(){s=Store{}}; var services []string; for svc,items:= range s { for k,v:=range items { if (!byVal && strings.Contains(k,args[0])) || (byVal && strings.Contains(v.Value,args[0])) { services=append(services,svc); break } } }; sort.Strings(services); for _,svc:=range services{fmt.Fprintln(tw,svc)}; tw.Flush(); return nil }}; c.Flags().BoolVarP(&byVal,"by-value","v",false,"Find parameters by value"); return c }
func historyCmd()*cobra.Command{ return &cobra.Command{Use:"history <service> <key>", Short:"View the history of a secret", Args:cobra.ExactArgs(2), RunE: func(cmd *cobra.Command,args []string) error { tw:=tabwriter.NewWriter(cmd.OutOrStdout(),0,0,2,' ',0); fmt.Fprintln(tw,"Event\tVersion\t\tDate\tUser"); s:=loadStore(); if isNull(){s=Store{}}; if sec:=getSecret(s,args[0],normKey(args[1])); sec!=nil { for _,h:=range sec.History { fmt.Fprintf(tw,"%s\t%d\t\t%s\t%s\n","PutParameter",h.Version,h.Modified,h.User)}; fmt.Fprintf(tw,"%s\t%d\t\t%s\t%s\n","PutParameter",sec.Version,sec.Modified,sec.User)}; tw.Flush(); return nil }} }
func listServicesCmd()*cobra.Command{ var include bool; c:=&cobra.Command{Use:"list-services <service>", Short:"List services", RunE: func(cmd *cobra.Command,args []string) error { tw:=tabwriter.NewWriter(cmd.OutOrStdout(),0,0,2,' ',0); if include { fmt.Fprintln(tw,"Service\tKey") } else { fmt.Fprintln(tw,"Service") }; s:=loadStore(); if isNull(){s=Store{}}; var svcs []string; for svc:=range s{svcs=append(svcs,svc)}; sort.Strings(svcs); for _,svc:= range svcs { if include { for _,r:= range secretsFor(s,svc){ fmt.Fprintf(tw,"%s\t%s\n",svc,r.Name)} } else { fmt.Fprintln(tw,svc) } }; tw.Flush(); return nil }}; c.Flags().BoolVarP(&include,"secrets","s",false,"Include secret names in the list"); return c }

func execCmd()*cobra.Command{ var pristine, strict bool; var strictVal string; c:=&cobra.Command{Use:"exec <service...> -- <command> [<arg...>]", Short:"Executes a command with secrets loaded into the environment", Args:cobra.MinimumNArgs(2), RunE: func(cmd *cobra.Command,args []string) error { idx:=len(args)-1; for i,a:=range args{ if a=="--"{idx=i;break} }; services:=args[:idx]; command:=args[idx:]; if len(command)>0 && command[0]=="--"{command=command[1:]}; if len(command)==0 { return fmt.Errorf("requires command")}; env:=[]string{}; if !pristine { env=os.Environ() }; secrets:=map[string]string{}; s:=loadStore(); for _,svc:= range services { for _,r:= range secretsFor(s,svc){ secrets[envName(r.Name,false)]=r.Value } }; if strict { want:=map[string]bool{}; for _,e:= range os.Environ(){ parts:=strings.SplitN(e,"=",2); if len(parts)==2 && parts[1]==strictVal { want[parts[0]]=true } }; for k:= range want { if _,ok:=secrets[k]; !ok { return fmt.Errorf("%s unfilled env var %s", os.Args[0], k) } }; for k,v:= range secrets { if want[k] { env=append(env,k+"="+v) } } } else { for k,v:= range secrets { env=append(env,k+"="+v) } }; ec:=exec.Command(command[0],command[1:]...); ec.Stdout=os.Stdout; ec.Stderr=os.Stderr; ec.Stdin=os.Stdin; ec.Env=env; return ec.Run() }}; c.Flags().BoolVar(&pristine,"pristine",false,"only use variables retrieved from the backend; do not inherit existing environment variables"); c.Flags().BoolVar(&strict,"strict",false,"enable strict mode:\nonly inject secrets for which there is a corresponding env var with value\n<strict-value>, and fail if there are any env vars with that value missing\nfrom secrets"); c.Flags().StringVar(&strictVal,"strict-value","chamberme","value to expect in --strict mode"); return c }

func tagCmd()*cobra.Command{ c:=&cobra.Command{Use:"tag", Short:"work with tags on secrets"}; c.AddCommand(tagRead(),tagWrite(),tagDelete()); return c }
func tagRead()*cobra.Command{ return &cobra.Command{Use:"read <service> <key>", Short:"Read tags for a specific secret", Args:cobra.ExactArgs(2), RunE: func(cmd *cobra.Command,args []string) error { if isNull(){return fail("Failed to read tags",errors.New(nullErr))}; sec:=getSecret(loadStore(),args[0],normKey(args[1])); if sec!=nil { for k,v:= range sec.Tags { fmt.Fprintf(cmd.OutOrStdout(),"%s=%s\n",k,v) } }; return nil }} }
func tagWrite()*cobra.Command{ return &cobra.Command{Use:"write <service> <key> <tags>", Short:"Write tags for a specific secret", Args:cobra.MinimumNArgs(3), RunE: func(cmd *cobra.Command,args []string) error { if isNull(){return fail("Failed to write tags",errors.New(nullErr))}; s:=loadStore(); sec:=getSecret(s,args[0],normKey(args[1])); if sec==nil { return fmt.Errorf("secret not found")}; if sec.Tags==nil { sec.Tags=map[string]string{} }; for _,p:= range args[2:] { kv:=strings.SplitN(p,"=",2); if len(kv)==2 { sec.Tags[kv[0]]=kv[1] } }; return saveStore(s) }} }
func tagDelete()*cobra.Command{ return &cobra.Command{Use:"delete <service> <key> <tags>", Short:"Delete tags for a specific secret", Args:cobra.MinimumNArgs(3), RunE: func(cmd *cobra.Command,args []string) error { if isNull(){return fail("Failed to delete tags",errors.New(nullErr))}; s:=loadStore(); if sec:=getSecret(s,args[0],normKey(args[1])); sec!=nil { for _,k:=range args[2:] { delete(sec.Tags,k) } }; return saveStore(s) }} }
func versionCmd()*cobra.Command{ return &cobra.Command{Use:"version", Short:"print version", Run: func(cmd *cobra.Command,args []string){ cmd.Root().Help() }} }
