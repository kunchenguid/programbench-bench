module programbench/samtools

go 1.21
