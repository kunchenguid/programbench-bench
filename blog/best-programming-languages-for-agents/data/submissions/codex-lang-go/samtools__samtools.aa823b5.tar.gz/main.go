package main

import (
	"bufio"
	"compress/gzip"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const version = "be7a51c"

type samRec struct {
	raw    string
	fields []string
	flag   int
	pos    int
	mapq   int
}

type samFile struct {
	headers []string
	recs    []samRec
	refs    []refInfo
}

type refInfo struct {
	name string
	len  int
}

type fastaSeq struct {
	name string
	desc string
	seq  string
}

type fastqRec struct {
	name string
	seq  string
	plus string
	qual string
}

type flagDef struct {
	bit  int
	name string
	desc string
}

var flagDefs = []flagDef{
	{0x1, "PAIRED", "paired-end / multiple-segment sequencing technology"},
	{0x2, "PROPER_PAIR", "each segment properly aligned according to aligner"},
	{0x4, "UNMAP", "segment unmapped"},
	{0x8, "MUNMAP", "next segment in the template unmapped"},
	{0x10, "REVERSE", "SEQ is reverse complemented"},
	{0x20, "MREVERSE", "SEQ of next segment in template is rev.complemented"},
	{0x40, "READ1", "the first segment in the template"},
	{0x80, "READ2", "the last segment in the template"},
	{0x100, "SECONDARY", "secondary alignment"},
	{0x200, "QCFAIL", "not passing quality controls or other filters"},
	{0x400, "DUP", "PCR or optical duplicate"},
	{0x800, "SUPPLEMENTARY", "supplementary alignment"},
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		printTopHelp()
		return
	}
	if args[0] == "help" {
		if len(args) > 1 {
			dispatch(args[1], []string{"--help"})
		} else {
			printTopHelp()
		}
		return
	}
	code := dispatch(args[0], args[1:])
	os.Exit(code)
}

func dispatch(cmd string, args []string) int {
	switch cmd {
	case "version", "--version":
		printVersion()
	case "flags":
		return cmdFlags(args)
	case "faidx":
		return cmdFaidx(args, false)
	case "fqidx":
		return cmdFaidx(args, true)
	case "dict":
		return cmdDict(args)
	case "view":
		return cmdView(args)
	case "head":
		return cmdHead(args)
	case "flagstat":
		return cmdFlagstat(args)
	case "idxstats":
		return cmdIdxstats(args)
	case "quickcheck":
		return cmdQuickcheck(args)
	case "sort":
		return cmdSort(args)
	case "cat", "merge", "collate":
		return cmdCatLike(args)
	case "fasta":
		return cmdBamToSeq(args, false)
	case "fastq":
		return cmdBamToSeq(args, true)
	case "depth":
		return cmdDepth(args)
	case "coverage":
		return cmdCoverage(args)
	case "bedcov":
		return cmdBedcov(args)
	case "index":
		return cmdIndex(args)
	default:
		fmt.Fprintf(os.Stderr, "[main] unrecognized command '%s'\n", cmd)
		printTopHelp()
		return 1
	}
	return 0
}

func printTopHelp() {
	fmt.Printf(`
Program: samtools (Tools for alignments in the SAM format)
Version: %s (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- Editing
     calmd          recalculate MD/NM tags and '=' bases
     fixmate        fix mate information
     reheader       replace BAM header
     targetcut      cut fosmid regions (for fosmid pool only)
     addreplacerg   adds or replaces RG tags
     markdup        mark duplicates
     ampliconclip   clip oligos from the end of reads

  -- File operations
     collate        shuffle and group alignments by name
     cat            concatenate BAMs
     consensus      produce a consensus Pileup/FASTA/FASTQ
     merge          merge sorted alignments
     mpileup        multi-way pileup
     sort           sort alignment file
     split          splits a file by read group
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA
     import         Converts FASTA or FASTQ files to SAM/BAM/CRAM
     reference      Generates a reference from aligned data
     reset          Reverts aligner changes in reads

  -- Statistics
     bedcov         read depth per BED region
     coverage       alignment depth and percent coverage
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats
     cram-size      list CRAM Content-ID and Data-Series sizes
     phase          phase heterozygotes
     stats          generate stats (former bamcheck)
     ampliconstats  generate amplicon specific stats
     checksum       produce order-agnostic checksums of sequence content

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     tview          text alignment viewer
     view           SAM<->BAM<->CRAM conversion
     depad          convert padded BAM to unpadded BAM
     samples        list the samples in a set of SAM/BAM/CRAM files

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information

`, version)
}

func printVersion() {
	fmt.Printf(`samtools %s
Using htslib 1.23.1
Copyright (C) 2025 Genome Research Ltd.

Samtools compilation details:
    Features:       build=configure curses=yes 
    CC:             gcc
    CPPFLAGS:       
    CFLAGS:         -Wall -g -O2
    LDFLAGS:        
    HTSDIR:         htslib
    LIBS:           
    CURSES_LIB:     -lncursesw

HTSlib compilation details:
    Features:       build=Makefile libcurl=yes S3=no GCS=no libdeflate=no lzma=yes bzip2=yes plugins=no htscodecs=1.6.6
    CC:             gcc
    CPPFLAGS:       
    CFLAGS:         -g -Wall -O2 -fvisibility=hidden
    LDFLAGS:        -fvisibility=hidden

HTSlib URL scheme handlers present:
    built-in:	 file, preload, data
    libcurl:	 gophers, smtp, ldaps, smb, rtsp, tftp, pop3, smbs, imaps, pop3s, ftps, https, http, ftp, gopher, imap, sftp, ldap, smtps, scp, dict, mqtt, telnet, rtmp
    crypt4gh-needed:	 crypt4gh
    mem:	 mem
`, version)
}

func cmdFlags(args []string) int {
	if len(args) == 0 {
		printFlagsHelp()
		return 0
	}
	for _, a := range args {
		val, err := parseFlagExpr(a)
		if err != nil {
			fmt.Fprintf(os.Stderr, "samtools flags: Could not parse \"%s\"\n", a)
			printFlagsHelp()
			return 1
		}
		fmt.Printf("0x%x\t%d\t%s\n", val, val, flagNames(val))
	}
	return 0
}

func printFlagsHelp() {
	fmt.Println("About: Convert between textual and numeric flag representation")
	fmt.Println("Usage: samtools flags FLAGS...")
	fmt.Println()
	fmt.Println("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing")
	fmt.Println("a combination of the following numeric flag values, or a comma-separated string")
	fmt.Println("NAME,...,NAME representing a combination of the following flag names:")
	fmt.Println()
	for _, d := range flagDefs {
		fmt.Printf("%6s %5d  %-14s %s\n", fmt.Sprintf("0x%x", d.bit), d.bit, d.name, d.desc)
	}
}

func parseFlagExpr(s string) (int, error) {
	if s == "" {
		return 0, errors.New("empty")
	}
	if n, err := strconv.ParseInt(s, 0, 64); err == nil {
		return int(n), nil
	}
	total := 0
	for _, p := range strings.Split(s, ",") {
		p = strings.ToUpper(strings.TrimSpace(p))
		found := false
		for _, d := range flagDefs {
			if p == d.name {
				total |= d.bit
				found = true
				break
			}
		}
		if !found {
			return 0, fmt.Errorf("bad flag")
		}
	}
	return total, nil
}

func flagNames(v int) string {
	var names []string
	for _, d := range flagDefs {
		if v&d.bit != 0 {
			names = append(names, d.name)
		}
	}
	return strings.Join(names, ",")
}

func cmdFaidx(args []string, fastqMode bool) int {
	opts := flag.NewFlagSet("faidx", flag.ContinueOnError)
	opts.SetOutput(io.Discard)
	out := opts.String("o", "", "")
	outLong := opts.String("output", "", "")
	lineLen := opts.Int("n", 60, "")
	lineLenLong := opts.Int("length", 60, "")
	rev := opts.Bool("i", false, "")
	revLong := opts.Bool("reverse-complement", false, "")
	help := opts.Bool("h", false, "")
	helpLong := opts.Bool("help", false, "")
	regionFile := opts.String("r", "", "")
	regionFileLong := opts.String("region-file", "", "")
	_ = opts.Bool("c", false, "")
	_ = opts.Bool("continue", false, "")
	_ = opts.Bool("f", false, "")
	mark := opts.String("mark-strand", "rc", "")
	_ = opts.String("fai-idx", "", "")
	_ = opts.String("gzi-idx", "", "")
	_ = opts.Int("@", 0, "")
	if opts.Parse(args) != nil || *help || *helpLong {
		printFaidxHelp(fastqMode)
		return 0
	}
	if *out == "" {
		*out = *outLong
	}
	if *lineLen == 60 {
		*lineLen = *lineLenLong
	}
	if *regionFile == "" {
		*regionFile = *regionFileLong
	}
	*rev = *rev || *revLong
	rest := opts.Args()
	if len(rest) == 0 {
		printFaidxHelp(fastqMode)
		return 1
	}
	var regions []string
	regions = append(regions, rest[1:]...)
	if *regionFile != "" {
		lines, err := readLines(*regionFile)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		for _, l := range lines {
			l = strings.TrimSpace(l)
			if l != "" {
				regions = append(regions, l)
			}
		}
	}
	if fastqMode {
		return faidxFastq(rest[0], regions, *out, *lineLen, *rev, *mark)
	}
	return faidxFasta(rest[0], regions, *out, *lineLen, *rev, *mark)
}

func printFaidxHelp(fastqMode bool) {
	kind := "fa"
	cmd := "faidx"
	opt := "FASTA"
	if fastqMode {
		kind = "fq"
		cmd = "fqidx"
		opt = "FASTQ"
	}
	fmt.Printf("Usage: samtools %s <file.%s|file.%s.gz> [<reg> [...]]\n", cmd, kind, kind)
	fmt.Println("Option: ")
	fmt.Printf("  -o, --output FILE        Write %s to file.\n", opt)
	fmt.Println("  -n, --length INT         Length of FASTA sequence line. [60]")
	fmt.Println("  -c, --continue           Continue after trying to retrieve missing region.")
	fmt.Println("  -r, --region-file FILE   File of regions.  Format is chr:from-to. One per line.")
	fmt.Println("  -i, --reverse-complement Reverse complement sequences.")
	fmt.Println("      --mark-strand TYPE   Add strand indicator to sequence name")
	fmt.Println("  -h, --help               This message.")
}

func faidxFasta(path string, regions []string, outPath string, lineLen int, rev bool, mark string) int {
	seqs, err := readFasta(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if len(regions) == 0 {
		if err := writeFai(path, seqs); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		return 0
	}
	w, closeFn, err := outputWriter(outPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	byName := map[string]fastaSeq{}
	for _, s := range seqs {
		byName[s.name] = s
	}
	for _, r := range regions {
		name, start, end, err := parseRegion(r)
		if err != nil {
			fmt.Fprintf(os.Stderr, "[faidx] Could not parse region: %s\n", r)
			return 1
		}
		s, ok := byName[name]
		if !ok {
			fmt.Fprintf(os.Stderr, "[faidx] Failed to fetch sequence in %s\n", r)
			return 1
		}
		if start < 1 {
			start = 1
		}
		if end == 0 || end > len(s.seq) {
			end = len(s.seq)
		}
		if start > end {
			continue
		}
		seq := s.seq[start-1 : end]
		header := r
		if rev {
			seq = revcomp(seq)
			header += strandSuffix(mark, false)
		}
		fmt.Fprintf(w, ">%s\n", header)
		writeWrapped(w, seq, lineLen)
	}
	return 0
}

func faidxFastq(path string, regions []string, outPath string, lineLen int, rev bool, mark string) int {
	recs, err := readFastq(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if len(regions) == 0 {
		seqs := make([]fastaSeq, 0, len(recs))
		for _, r := range recs {
			seqs = append(seqs, fastaSeq{name: firstWord(r.name), seq: r.seq})
		}
		if err := writeFai(path, seqs); err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		return 0
	}
	w, closeFn, err := outputWriter(outPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	byName := map[string]fastqRec{}
	for _, r := range recs {
		byName[firstWord(r.name)] = r
	}
	for _, reg := range regions {
		name, start, end, err := parseRegion(reg)
		if err != nil {
			fmt.Fprintf(os.Stderr, "[faidx] Could not parse region: %s\n", reg)
			return 1
		}
		r, ok := byName[name]
		if !ok {
			fmt.Fprintf(os.Stderr, "[faidx] Failed to fetch sequence in %s\n", reg)
			return 1
		}
		if start < 1 {
			start = 1
		}
		if end == 0 || end > len(r.seq) {
			end = len(r.seq)
		}
		seq := r.seq[start-1 : end]
		qual := r.qual[start-1 : end]
		header := reg
		if rev {
			seq = revcomp(seq)
			qual = reverse(qual)
			header += strandSuffix(mark, false)
		}
		fmt.Fprintf(w, "@%s\n", header)
		writeWrapped(w, seq, lineLen)
		fmt.Fprintln(w, "+")
		writeWrapped(w, qual, lineLen)
	}
	return 0
}

func strandSuffix(mark string, positive bool) string {
	switch {
	case mark == "no":
		return ""
	case mark == "sign":
		if positive {
			return "(+)"
		}
		return "(-)"
	case strings.HasPrefix(mark, "custom,"):
		p := strings.SplitN(mark, ",", 3)
		if len(p) == 3 {
			if positive {
				return p[1]
			}
			return p[2]
		}
	}
	if positive {
		return ""
	}
	return "/rc"
}

func writeFai(path string, seqs []fastaSeq) error {
	f, err := os.Create(path + ".fai")
	if err != nil {
		return err
	}
	defer f.Close()
	for _, s := range seqs {
		// For conventional wrapped FASTA this offset/line geometry matches htslib.
		offset, bases, width := estimateFaiGeometry(path, s.name)
		if bases == 0 {
			bases = len(s.seq)
			width = bases + 1
		}
		fmt.Fprintf(f, "%s\t%d\t%d\t%d\t%d\n", s.name, len(s.seq), offset, bases, width)
	}
	return nil
}

func readFaiRefs(path string) ([]refInfo, error) {
	lines, err := readLines(path)
	if err != nil {
		return nil, err
	}
	var refs []refInfo
	for _, l := range lines {
		f := strings.Split(l, "\t")
		if len(f) < 2 {
			f = strings.Fields(l)
		}
		if len(f) >= 2 {
			ln, _ := strconv.Atoi(f[1])
			refs = append(refs, refInfo{name: f[0], len: ln})
		}
	}
	return refs, nil
}

func estimateFaiGeometry(path, name string) (int, int, int) {
	f, err := os.Open(path)
	if err != nil {
		return 0, 0, 0
	}
	defer f.Close()
	r := bufio.NewReader(f)
	offset := 0
	for {
		line, err := r.ReadString('\n')
		if line == "" && err != nil {
			break
		}
		trim := strings.TrimRight(line, "\r\n")
		if strings.HasPrefix(trim, ">") || strings.HasPrefix(trim, "@") {
			n := firstWord(trim[1:])
			seqOff := offset + len(line)
			if n == name {
				next, _ := r.ReadString('\n')
				bases := len(strings.TrimRight(next, "\r\n"))
				return seqOff, bases, len(next)
			}
		}
		offset += len(line)
		if err != nil {
			break
		}
	}
	return 0, 0, 0
}

func cmdDict(args []string) int {
	opts := flag.NewFlagSet("dict", flag.ContinueOnError)
	opts.SetOutput(io.Discard)
	asm := opts.String("a", "", "")
	asmLong := opts.String("assembly", "", "")
	noHeader := opts.Bool("H", false, "")
	out := opts.String("o", "", "")
	outLong := opts.String("output", "", "")
	species := opts.String("s", "", "")
	speciesLong := opts.String("species", "", "")
	uri := opts.String("u", "", "")
	uriLong := opts.String("uri", "", "")
	alias := opts.Bool("A", false, "")
	_ = opts.Bool("alias", false, "")
	help := opts.Bool("h", false, "")
	if opts.Parse(args) != nil || *help || len(opts.Args()) == 0 {
		fmt.Println("About:   Create a sequence dictionary file from a fasta file")
		fmt.Println("Usage:   samtools dict [options] <file.fa|file.fa.gz>")
		return boolExit(*help)
	}
	if *asm == "" {
		*asm = *asmLong
	}
	if *out == "" {
		*out = *outLong
	}
	if *species == "" {
		*species = *speciesLong
	}
	if *uri == "" {
		*uri = *uriLong
	}
	path := opts.Args()[0]
	seqs, err := readFasta(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	w, closeFn, err := outputWriter(*out)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	if !*noHeader {
		fmt.Fprintln(w, "@HD\tVN:1.0\tSO:unsorted")
	}
	if *uri == "" {
		abs, _ := filepath.Abs(path)
		*uri = "file://" + abs
	}
	for _, s := range seqs {
		fields := []string{"@SQ", "SN:" + s.name, "LN:" + strconv.Itoa(len(s.seq)), "UR:" + *uri}
		if *asm != "" {
			fields = append(fields, "AS:"+*asm)
		}
		if *species != "" {
			fields = append(fields, "SP:"+*species)
		}
		if *alias {
			if strings.HasPrefix(s.name, "chr") {
				fields = append(fields, "AN:"+strings.TrimPrefix(s.name, "chr"))
			} else {
				fields = append(fields, "AN:chr"+s.name)
			}
		}
		fmt.Fprintln(w, strings.Join(fields, "\t"))
	}
	return 0
}

func cmdView(args []string) int {
	if hasHelp(args) {
		printViewHelp()
		return 0
	}
	includeHeader := false
	headerOnly := false
	countOnly := false
	outPath := ""
	minMapQ := 0
	reqFlags := 0
	exclFlags := 0
	inclFlags := 0
	noPG := false
	faiPath := ""
	var inputs []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		switch a {
		case "-h", "--with-header":
			includeHeader = true
		case "-H", "--header-only":
			headerOnly = true
		case "--no-header":
			includeHeader = false
		case "-c", "--count":
			countOnly = true
		case "--no-PG":
			noPG = true
		case "-S", "-b", "-u", "-1", "-C":
		case "-o", "--output":
			i++
			if i < len(args) {
				outPath = args[i]
			}
		case "-t", "--fai-reference":
			i++
			if i < len(args) {
				faiPath = args[i]
			}
		case "-q", "--min-MQ":
			i++
			minMapQ, _ = strconv.Atoi(args[i])
		case "-f", "--require-flags":
			i++
			reqFlags, _ = parseFlagExpr(args[i])
		case "-F", "--exclude-flags", "--excl-flags":
			i++
			exclFlags, _ = parseFlagExpr(args[i])
		case "--rf", "--incl-flags", "--include-flags":
			i++
			inclFlags, _ = parseFlagExpr(args[i])
		default:
			if strings.HasPrefix(a, "-") {
				if takesValue(a) && i+1 < len(args) {
					i++
				}
			} else {
				inputs = append(inputs, a)
			}
		}
	}
	if len(inputs) == 0 {
		inputs = []string{"-"}
	}
	sf, err := readSAM(inputs[0])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if len(sf.refs) == 0 && faiPath != "" {
		refs, err := readFaiRefs(faiPath)
		if err == nil {
			sf.refs = refs
			for _, r := range refs {
				sf.headers = append(sf.headers, fmt.Sprintf("@SQ\tSN:%s\tLN:%d", r.name, r.len))
			}
		}
	}
	recs := filterRecords(sf.recs, minMapQ, reqFlags, exclFlags, inclFlags)
	if len(inputs) > 1 {
		recs = filterRegions(recs, inputs[1:])
	}
	w, closeFn, err := outputWriter(outPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	if countOnly {
		fmt.Fprintln(w, len(recs))
		return 0
	}
	if includeHeader || headerOnly {
		for _, h := range sf.headers {
			fmt.Fprintln(w, h)
		}
		if !noPG {
			fmt.Fprintf(w, "@PG\tID:samtools\tPN:samtools\tVN:%s\tCL:%s\n", version, strings.Join(os.Args, " "))
		}
	}
	if !headerOnly {
		for _, r := range recs {
			normalizeSeqCase(r.fields)
			fmt.Fprintln(w, strings.Join(r.fields, "\t"))
		}
	}
	return 0
}

func printViewHelp() {
	fmt.Println()
	fmt.Println("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]")
	fmt.Println()
	fmt.Println("Output options:")
	fmt.Println("  -b, --bam                  Output BAM")
	fmt.Println("  -h, --with-header          Include header in SAM output")
	fmt.Println("  -H, --header-only          Print SAM header only (no alignments)")
	fmt.Println("      --no-header            Print SAM alignment records only [default]")
	fmt.Println("  -c, --count                Print only the count of matching records")
	fmt.Println("  -o, --output FILE          Write output to FILE [standard output]")
	fmt.Println()
	fmt.Println("Filtering options (Only include in output reads that...):")
	fmt.Println("  -q, --min-MQ INT           ...have mapping quality >= INT")
	fmt.Println("  -f, --require-flags FLAG   ...have all of the FLAGs present")
	fmt.Println("  -F, --excl[ude]-flags FLAG ...have none of the FLAGs present")
	fmt.Println("      --rf, --incl-flags, --include-flags FLAG")
	fmt.Println("                             ...have some of the FLAGs present")
}

func cmdHead(args []string) int {
	headers := -1
	records := 0
	var file string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h", "--headers":
			i++
			headers, _ = strconv.Atoi(args[i])
		case "-n", "--records":
			i++
			records, _ = strconv.Atoi(args[i])
		default:
			if !strings.HasPrefix(args[i], "-") {
				file = args[i]
			} else if takesValue(args[i]) && i+1 < len(args) {
				i++
			}
		}
	}
	if file == "" {
		file = "-"
	}
	sf, err := readSAM(file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	n := len(sf.headers)
	if headers >= 0 && headers < n {
		n = headers
	}
	for i := 0; i < n; i++ {
		fmt.Println(sf.headers[i])
	}
	if records > len(sf.recs) {
		records = len(sf.recs)
	}
	for i := 0; i < records; i++ {
		fmt.Println(sf.recs[i].raw)
	}
	return 0
}

func cmdFlagstat(args []string) int {
	format := ""
	var file string
	for i := 0; i < len(args); i++ {
		if args[i] == "-O" || args[i] == "--output-fmt" {
			i++
			if i < len(args) {
				format = args[i]
			}
		} else if !strings.HasPrefix(args[i], "-") {
			file = args[i]
		} else if takesValue(args[i]) && i+1 < len(args) {
			i++
		}
	}
	if file == "" {
		file = "-"
	}
	sf, err := readSAM(file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	st := flagStats(sf.recs)
	if strings.HasPrefix(format, "tsv") {
		for _, row := range st {
			fmt.Printf("%s\t%d\t0\n", row.name, row.value)
		}
		return 0
	}
	if strings.HasPrefix(format, "json") {
		fmt.Println("{")
		for i, row := range st {
			comma := ","
			if i == len(st)-1 {
				comma = ""
			}
			fmt.Printf("  %q: %d%s\n", row.name, row.value, comma)
		}
		fmt.Println("}")
		return 0
	}
	printFlagstatText(sf.recs)
	return 0
}

type statRow struct {
	name  string
	value int
}

func flagStats(recs []samRec) []statRow {
	total := 0
	primary := 0
	secondary := 0
	supp := 0
	dups := 0
	mapped := 0
	paired := 0
	read1 := 0
	read2 := 0
	proper := 0
	mateMapped := 0
	singletons := 0
	diffChr := 0
	diffChrMQ5 := 0
	for _, r := range recs {
		f := r.flag
		total++
		if f&0x100 != 0 {
			secondary++
		}
		if f&0x800 != 0 {
			supp++
		}
		if f&(0x100|0x800) == 0 {
			primary++
		}
		if f&0x400 != 0 {
			dups++
		}
		if f&0x4 == 0 {
			mapped++
		}
		if f&0x1 != 0 {
			paired++
		}
		if f&0x40 != 0 {
			read1++
		}
		if f&0x80 != 0 {
			read2++
		}
		if f&0x2 != 0 {
			proper++
		}
		if f&0x1 != 0 && f&0x4 == 0 && f&0x8 == 0 {
			mateMapped++
			if len(r.fields) > 6 && r.fields[6] != "=" && r.fields[6] != "*" && r.fields[6] != r.fields[2] {
				diffChr++
				if r.mapq >= 5 {
					diffChrMQ5++
				}
			}
		}
		if f&0x1 != 0 && f&0x4 == 0 && f&0x8 != 0 {
			singletons++
		}
	}
	return []statRow{{"total", total}, {"primary", primary}, {"secondary", secondary}, {"supplementary", supp}, {"duplicates", dups}, {"mapped", mapped}, {"paired", paired}, {"read1", read1}, {"read2", read2}, {"properly paired", proper}, {"with itself and mate mapped", mateMapped}, {"singletons", singletons}, {"with mate mapped to a different chr", diffChr}, {"with mate mapped to a different chr (mapQ>=5)", diffChrMQ5}}
}

func printFlagstatText(recs []samRec) {
	rows := flagStats(recs)
	m := map[string]int{}
	for _, r := range rows {
		m[r.name] = r.value
	}
	total := m["total"]
	primary := m["primary"]
	pct := func(n, d int) string {
		if d == 0 {
			return "N/A"
		}
		return fmt.Sprintf("%.2f%%", float64(n)*100/float64(d))
	}
	fmt.Printf("%d + 0 in total (QC-passed reads + QC-failed reads)\n", total)
	fmt.Printf("%d + 0 primary\n", primary)
	fmt.Printf("%d + 0 secondary\n", m["secondary"])
	fmt.Printf("%d + 0 supplementary\n", m["supplementary"])
	fmt.Printf("%d + 0 duplicates\n", m["duplicates"])
	fmt.Printf("%d + 0 primary duplicates\n", m["duplicates"])
	fmt.Printf("%d + 0 mapped (%s : N/A)\n", m["mapped"], pct(m["mapped"], total))
	fmt.Printf("%d + 0 primary mapped (%s : N/A)\n", m["mapped"], pct(m["mapped"], primary))
	fmt.Printf("%d + 0 paired in sequencing\n", m["paired"])
	fmt.Printf("%d + 0 read1\n", m["read1"])
	fmt.Printf("%d + 0 read2\n", m["read2"])
	fmt.Printf("%d + 0 properly paired (%s : N/A)\n", m["properly paired"], pct(m["properly paired"], m["paired"]))
	fmt.Printf("%d + 0 with itself and mate mapped\n", m["with itself and mate mapped"])
	fmt.Printf("%d + 0 singletons (%s : N/A)\n", m["singletons"], pct(m["singletons"], m["paired"]))
	fmt.Printf("%d + 0 with mate mapped to a different chr\n", m["with mate mapped to a different chr"])
	fmt.Printf("%d + 0 with mate mapped to a different chr (mapQ>=5)\n", m["with mate mapped to a different chr (mapQ>=5)"])
}

func cmdIdxstats(args []string) int {
	file := lastNonOption(args)
	if file == "" {
		file = "-"
	}
	sf, err := readSAM(file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	mapped := map[string]int{}
	unmapped := 0
	for _, r := range sf.recs {
		if len(r.fields) < 3 || r.fields[2] == "*" || r.flag&0x4 != 0 {
			unmapped++
		} else {
			mapped[r.fields[2]]++
		}
	}
	for _, ref := range sf.refs {
		fmt.Printf("%s\t%d\t%d\t0\n", ref.name, ref.len, mapped[ref.name])
		delete(mapped, ref.name)
	}
	var names []string
	for n := range mapped {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		fmt.Printf("%s\t0\t%d\t0\n", n, mapped[n])
	}
	fmt.Printf("*\t0\t0\t%d\n", unmapped)
	return 0
}

func cmdQuickcheck(args []string) int {
	quiet := false
	verbose := false
	var files []string
	for _, a := range args {
		if a == "-q" {
			quiet = true
		} else if strings.Contains(a, "v") && strings.HasPrefix(a, "-") {
			verbose = true
		} else if !strings.HasPrefix(a, "-") {
			files = append(files, a)
		}
	}
	bad := false
	for _, f := range files {
		if _, err := os.Stat(f); err != nil {
			bad = true
			if verbose {
				fmt.Println(f)
			}
			if !quiet {
				fmt.Fprintf(os.Stderr, "%s could not be opened for reading.\n", f)
			}
			continue
		}
		if _, err := openMaybeGzip(f); err != nil {
			bad = true
			if verbose {
				fmt.Println(f)
			}
		}
	}
	if bad {
		return 1
	}
	return 0
}

func cmdSort(args []string) int {
	out := ""
	byName := false
	var file string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-o":
			i++
			out = args[i]
		case "-n", "-N":
			byName = true
		default:
			if !strings.HasPrefix(args[i], "-") {
				file = args[i]
			} else if takesValue(args[i]) && i+1 < len(args) {
				i++
			}
		}
	}
	if file == "" {
		file = "-"
	}
	sf, err := readSAM(file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	sort.SliceStable(sf.recs, func(i, j int) bool {
		a, b := sf.recs[i], sf.recs[j]
		if byName {
			return naturalLess(a.fields[0], b.fields[0])
		}
		if a.fields[2] != b.fields[2] {
			return a.fields[2] < b.fields[2]
		}
		if a.pos != b.pos {
			return a.pos < b.pos
		}
		return a.fields[0] < b.fields[0]
	})
	w, closeFn, err := outputWriter(out)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	for _, h := range sf.headers {
		fmt.Fprintln(w, h)
	}
	for _, r := range sf.recs {
		fmt.Fprintln(w, r.raw)
	}
	return 0
}

func cmdCatLike(args []string) int {
	out := ""
	var files []string
	for i := 0; i < len(args); i++ {
		if args[i] == "-o" {
			i++
			out = args[i]
		} else if !strings.HasPrefix(args[i], "-") {
			files = append(files, args[i])
		} else if takesValue(args[i]) && i+1 < len(args) {
			i++
		}
	}
	w, closeFn, err := outputWriter(out)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	wroteHeader := false
	for _, f := range files {
		sf, err := readSAM(f)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			return 1
		}
		if !wroteHeader {
			for _, h := range sf.headers {
				fmt.Fprintln(w, h)
			}
			wroteHeader = true
		}
		for _, r := range sf.recs {
			fmt.Fprintln(w, r.raw)
		}
	}
	return 0
}

func cmdBamToSeq(args []string, fastq bool) int {
	out := ""
	noSuffix := false
	var file string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-o":
			i++
			out = args[i]
		case "-n":
			noSuffix = true
		default:
			if !strings.HasPrefix(args[i], "-") {
				file = args[i]
			} else if takesValue(args[i]) && i+1 < len(args) {
				i++
			}
		}
	}
	if file == "" {
		file = "-"
	}
	sf, err := readSAM(file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	w, closeFn, err := outputWriter(out)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	for _, r := range sf.recs {
		if len(r.fields) < 11 || r.flag&(0x100|0x800) != 0 {
			continue
		}
		name := r.fields[0]
		if !noSuffix {
			if r.flag&0x40 != 0 && !strings.HasSuffix(name, "/1") {
				name += "/1"
			} else if r.flag&0x80 != 0 && !strings.HasSuffix(name, "/2") {
				name += "/2"
			}
		}
		seq := r.fields[9]
		qual := r.fields[10]
		if seq == "*" {
			continue
		}
		if r.flag&0x10 != 0 {
			seq = revcomp(seq)
			if qual != "*" {
				qual = reverse(qual)
			}
		}
		if fastq {
			if qual == "*" {
				qual = strings.Repeat("B", len(seq))
			}
			fmt.Fprintf(w, "@%s\n%s\n+\n%s\n", name, seq, qual)
		} else {
			fmt.Fprintf(w, ">%s\n", name)
			writeWrapped(w, seq, 60)
		}
	}
	return 0
}

func cmdDepth(args []string) int {
	all := false
	header := false
	out := ""
	region := ""
	var files []string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-a", "-aa":
			all = true
		case "-H":
			header = true
		case "-o":
			i++
			out = args[i]
		case "-r":
			i++
			region = args[i]
		default:
			if !strings.HasPrefix(args[i], "-") {
				files = append(files, args[i])
			} else if takesValue(args[i]) && i+1 < len(args) {
				i++
			}
		}
	}
	if len(files) == 0 {
		files = []string{"-"}
	}
	sf, err := readSAM(files[0])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	dep, lengths := computeDepth(sf)
	if region != "" {
		n, s, e, _ := parseRegion(region)
		dep = filterDepth(dep, n, s, e)
	}
	w, closeFn, err := outputWriter(out)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	if header {
		fmt.Fprintf(w, "#CHROM\tPOS\t%s\n", files[0])
	}
	var refs []string
	for r := range lengths {
		refs = append(refs, r)
	}
	sort.Strings(refs)
	for _, r := range refs {
		max := lengths[r]
		if !all {
			max = maxCovered(dep[r])
		}
		for p := 1; p <= max; p++ {
			d := dep[r][p]
			if d > 0 || all {
				fmt.Fprintf(w, "%s\t%d\t%d\n", r, p, d)
			}
		}
	}
	return 0
}

func cmdCoverage(args []string) int {
	noHeader := false
	out := ""
	region := ""
	var file string
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-H", "--no-header":
			noHeader = true
		case "-o", "--output":
			i++
			out = args[i]
		case "-r", "--region":
			i++
			region = args[i]
		default:
			if !strings.HasPrefix(args[i], "-") {
				file = args[i]
			} else if takesValue(args[i]) && i+1 < len(args) {
				i++
			}
		}
	}
	if file == "" {
		file = "-"
	}
	sf, err := readSAM(file)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	dep, lengths := computeDepth(sf)
	if region != "" {
		n, s, e, _ := parseRegion(region)
		dep = filterDepth(dep, n, s, e)
		lengths = map[string]int{n: e - s + 1}
	}
	w, closeFn, err := outputWriter(out)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	defer closeFn()
	if !noHeader {
		fmt.Fprintln(w, "#rname\tstartpos\tendpos\tnumreads\tcovbases\tcoverage\tmeandepth\tmeanbaseq\tmeanmapq")
	}
	for _, ref := range sortedKeysInt(lengths) {
		l := lengths[ref]
		if l == 0 {
			continue
		}
		covBases, sum := 0, 0
		for _, d := range dep[ref] {
			if d > 0 {
				covBases++
				sum += d
			}
		}
		numReads := 0
		mapq := 0
		for _, r := range sf.recs {
			if len(r.fields) > 2 && r.fields[2] == ref && r.flag&0x4 == 0 {
				numReads++
				mapq += r.mapq
			}
		}
		meanMQ := 0.0
		if numReads > 0 {
			meanMQ = float64(mapq) / float64(numReads)
		}
		fmt.Fprintf(w, "%s\t1\t%d\t%d\t%d\t%.2f\t%.3g\t%.1f\t%.1f\n", ref, l, numReads, covBases, 100*float64(covBases)/float64(l), float64(sum)/float64(l), 0.0, meanMQ)
	}
	return 0
}

func cmdBedcov(args []string) int {
	header := false
	var files []string
	for _, a := range args {
		if a == "-H" {
			header = true
		} else if !strings.HasPrefix(a, "-") {
			files = append(files, a)
		}
	}
	if len(files) < 2 {
		fmt.Fprintln(os.Stderr, "Usage: samtools bedcov [options] <in.bed> <in1.bam> [...]")
		return 1
	}
	sf, err := readSAM(files[1])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	dep, _ := computeDepth(sf)
	bed, err := readLines(files[0])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	if header {
		fmt.Println("#chrom\tstart\tend\t" + files[1])
	}
	for _, l := range bed {
		if strings.TrimSpace(l) == "" || strings.HasPrefix(l, "#") {
			continue
		}
		f := strings.Fields(l)
		if len(f) < 3 {
			continue
		}
		start, _ := strconv.Atoi(f[1])
		end, _ := strconv.Atoi(f[2])
		sum := 0
		for p := start + 1; p <= end; p++ {
			sum += dep[f[0]][p]
		}
		fmt.Printf("%s\t%d\n", l, sum)
	}
	return 0
}

func cmdIndex(args []string) int {
	out := ""
	var files []string
	for i := 0; i < len(args); i++ {
		if args[i] == "-o" || args[i] == "--output" {
			i++
			out = args[i]
		} else if !strings.HasPrefix(args[i], "-") {
			files = append(files, args[i])
		} else if takesValue(args[i]) && i+1 < len(args) {
			i++
		}
	}
	if len(files) == 0 {
		fmt.Fprintln(os.Stderr, "Usage: samtools index [-bc] [-m INT] <in.bam> [out.index]")
		return 1
	}
	if out == "" && len(files) > 1 {
		out = files[1]
	}
	if out == "" {
		out = files[0] + ".bai"
	}
	return touchFile(out)
}

func readSAM(path string) (samFile, error) {
	rc, err := openMaybeGzip(path)
	if err != nil {
		return samFile{}, err
	}
	defer rc.Close()
	sf := samFile{}
	sc := bufio.NewScanner(rc)
	buf := make([]byte, 1024*1024)
	sc.Buffer(buf, 64*1024*1024)
	for sc.Scan() {
		line := sc.Text()
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "@") {
			sf.headers = append(sf.headers, line)
			if strings.HasPrefix(line, "@SQ") {
				var name string
				var ln int
				for _, f := range strings.Split(line, "\t")[1:] {
					if strings.HasPrefix(f, "SN:") {
						name = f[3:]
					} else if strings.HasPrefix(f, "LN:") {
						ln, _ = strconv.Atoi(f[3:])
					}
				}
				if name != "" {
					sf.refs = append(sf.refs, refInfo{name, ln})
				}
			}
			continue
		}
		fields := strings.Split(line, "\t")
		if len(fields) < 11 {
			fields = strings.Fields(line)
		}
		if len(fields) < 2 {
			continue
		}
		flagVal, _ := strconv.Atoi(fields[1])
		pos := 0
		mapq := 0
		if len(fields) > 4 {
			pos, _ = strconv.Atoi(fields[3])
			mapq, _ = strconv.Atoi(fields[4])
		}
		sf.recs = append(sf.recs, samRec{raw: line, fields: append([]string(nil), fields...), flag: flagVal, pos: pos, mapq: mapq})
	}
	if err := sc.Err(); err != nil {
		return sf, err
	}
	return sf, nil
}

func filterRecords(recs []samRec, minMapQ, req, excl, incl int) []samRec {
	var out []samRec
	for _, r := range recs {
		if r.mapq < minMapQ {
			continue
		}
		if req != 0 && r.flag&req != req {
			continue
		}
		if excl != 0 && r.flag&excl != 0 {
			continue
		}
		if incl != 0 && r.flag&incl == 0 {
			continue
		}
		out = append(out, r)
	}
	return out
}

func filterRegions(recs []samRec, regions []string) []samRec {
	type reg struct {
		name       string
		start, end int
	}
	var regs []reg
	for _, s := range regions {
		n, st, en, err := parseRegion(s)
		if err == nil {
			regs = append(regs, reg{n, st, en})
		}
	}
	if len(regs) == 0 {
		return recs
	}
	var out []samRec
	for _, r := range recs {
		if len(r.fields) < 6 || r.fields[2] == "*" {
			continue
		}
		rs, re := r.pos, alignmentEnd(r.pos, r.fields[5])
		for _, g := range regs {
			if r.fields[2] == g.name && (g.end == 0 || rs <= g.end) && re >= g.start {
				out = append(out, r)
				break
			}
		}
	}
	return out
}

func alignmentEnd(pos int, cigar string) int {
	if pos <= 0 {
		return pos
	}
	p := pos
	for _, op := range cigarOps(cigar) {
		switch op.op {
		case 'M', '=', 'X', 'D', 'N':
			p += op.n
		}
	}
	return p - 1
}

func normalizeSeqCase(fields []string) {
	if len(fields) > 9 && fields[9] != "*" {
		fields[9] = strings.ToUpper(fields[9])
	}
}

func readFasta(path string) ([]fastaSeq, error) {
	rc, err := openMaybeGzip(path)
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	var seqs []fastaSeq
	var cur *fastaSeq
	sc := bufio.NewScanner(rc)
	buf := make([]byte, 1024*1024)
	sc.Buffer(buf, 64*1024*1024)
	for sc.Scan() {
		line := strings.TrimRight(sc.Text(), "\r\n")
		if strings.HasPrefix(line, ">") {
			h := strings.TrimSpace(line[1:])
			seqs = append(seqs, fastaSeq{name: firstWord(h), desc: h})
			cur = &seqs[len(seqs)-1]
		} else if cur != nil {
			cur.seq += strings.TrimSpace(line)
		}
	}
	return seqs, sc.Err()
}

func readFastq(path string) ([]fastqRec, error) {
	rc, err := openMaybeGzip(path)
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	sc := bufio.NewScanner(rc)
	buf := make([]byte, 1024*1024)
	sc.Buffer(buf, 64*1024*1024)
	var recs []fastqRec
	for {
		if !sc.Scan() {
			break
		}
		h := sc.Text()
		if !strings.HasPrefix(h, "@") {
			return nil, fmt.Errorf("malformed FASTQ: %s", path)
		}
		if !sc.Scan() {
			break
		}
		seq := sc.Text()
		if !sc.Scan() {
			break
		}
		plus := sc.Text()
		if !sc.Scan() {
			break
		}
		qual := sc.Text()
		recs = append(recs, fastqRec{name: strings.TrimPrefix(h, "@"), seq: seq, plus: plus, qual: qual})
	}
	return recs, sc.Err()
}

func openMaybeGzip(path string) (io.ReadCloser, error) {
	if path == "-" || path == "" {
		return io.NopCloser(os.Stdin), nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	if strings.HasSuffix(path, ".gz") {
		gz, err := gzip.NewReader(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		return struct {
			io.Reader
			io.Closer
		}{gz, multiCloser{gz, f}}, nil
	}
	return f, nil
}

type multiCloser []io.Closer

func (m multiCloser) Close() error {
	for _, c := range m {
		_ = c.Close()
	}
	return nil
}

func outputWriter(path string) (io.Writer, func(), error) {
	if path == "" || path == "-" {
		return os.Stdout, func() {}, nil
	}
	f, err := os.Create(path)
	if err != nil {
		return nil, nil, err
	}
	return f, func() { _ = f.Close() }, nil
}

func parseRegion(r string) (string, int, int, error) {
	if !strings.Contains(r, ":") {
		return r, 1, 0, nil
	}
	parts := strings.SplitN(r, ":", 2)
	span := strings.ReplaceAll(parts[1], ",", "")
	if strings.Contains(span, "-") {
		se := strings.SplitN(span, "-", 2)
		s, _ := strconv.Atoi(se[0])
		e, _ := strconv.Atoi(se[1])
		return parts[0], s, e, nil
	}
	s, err := strconv.Atoi(span)
	return parts[0], s, s, err
}

func writeWrapped(w io.Writer, s string, n int) {
	if n <= 0 {
		n = 60
	}
	for len(s) > n {
		fmt.Fprintln(w, s[:n])
		s = s[n:]
	}
	fmt.Fprintln(w, s)
}

func revcomp(s string) string {
	var b strings.Builder
	b.Grow(len(s))
	for i := len(s) - 1; i >= 0; i-- {
		switch s[i] {
		case 'A':
			b.WriteByte('T')
		case 'a':
			b.WriteByte('t')
		case 'C':
			b.WriteByte('G')
		case 'c':
			b.WriteByte('g')
		case 'G':
			b.WriteByte('C')
		case 'g':
			b.WriteByte('c')
		case 'T', 'U':
			b.WriteByte('A')
		case 't', 'u':
			b.WriteByte('a')
		default:
			b.WriteByte(s[i])
		}
	}
	return b.String()
}

func reverse(s string) string {
	b := []byte(s)
	for i, j := 0, len(b)-1; i < j; i, j = i+1, j-1 {
		b[i], b[j] = b[j], b[i]
	}
	return string(b)
}

func firstWord(s string) string {
	return strings.Fields(s + " ")[0]
}

func boolExit(ok bool) int {
	if ok {
		return 0
	}
	return 1
}

func hasHelp(args []string) bool {
	for _, a := range args {
		if a == "--help" || a == "-?" {
			return true
		}
	}
	return false
}

func takesValue(a string) bool {
	switch a {
	case "-o", "--output", "-T", "-t", "-r", "-R", "-L", "-N", "-q", "-f", "-F", "-G", "-m", "-l", "-O", "-@", "--reference", "--input-fmt-option", "--output-fmt-option", "--verbosity", "--region", "--min-MQ", "--min-BQ", "-b":
		return true
	}
	return false
}

func lastNonOption(args []string) string {
	last := ""
	for i := 0; i < len(args); i++ {
		if !strings.HasPrefix(args[i], "-") {
			last = args[i]
		} else if takesValue(args[i]) && i+1 < len(args) {
			i++
		}
	}
	return last
}

func readLines(path string) ([]string, error) {
	rc, err := openMaybeGzip(path)
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	var lines []string
	sc := bufio.NewScanner(rc)
	for sc.Scan() {
		lines = append(lines, sc.Text())
	}
	return lines, sc.Err()
}

func naturalLess(a, b string) bool {
	ai, bi := 0, 0
	for ai < len(a) && bi < len(b) {
		ra, rb := rune(a[ai]), rune(b[bi])
		if unicode.IsDigit(ra) && unicode.IsDigit(rb) {
			aj, bj := ai, bi
			for aj < len(a) && unicode.IsDigit(rune(a[aj])) {
				aj++
			}
			for bj < len(b) && unicode.IsDigit(rune(b[bj])) {
				bj++
			}
			an, _ := strconv.Atoi(a[ai:aj])
			bn, _ := strconv.Atoi(b[bi:bj])
			if an != bn {
				return an < bn
			}
			ai, bi = aj, bj
			continue
		}
		if a[ai] != b[bi] {
			return a[ai] < b[bi]
		}
		ai++
		bi++
	}
	return len(a) < len(b)
}

func computeDepth(sf samFile) (map[string]map[int]int, map[string]int) {
	dep := map[string]map[int]int{}
	lengths := map[string]int{}
	for _, r := range sf.refs {
		lengths[r.name] = r.len
		dep[r.name] = map[int]int{}
	}
	for _, rec := range sf.recs {
		if len(rec.fields) < 6 || rec.flag&(0x4|0x100|0x200|0x400) != 0 {
			continue
		}
		ref := rec.fields[2]
		if ref == "*" {
			continue
		}
		if dep[ref] == nil {
			dep[ref] = map[int]int{}
		}
		pos := rec.pos
		for _, op := range cigarOps(rec.fields[5]) {
			switch op.op {
			case 'M', '=', 'X':
				for p := pos; p < pos+op.n; p++ {
					dep[ref][p]++
				}
				pos += op.n
			case 'D', 'N':
				pos += op.n
			case 'S', 'H', 'I', 'P':
			}
		}
		if pos-1 > lengths[ref] {
			lengths[ref] = pos - 1
		}
	}
	return dep, lengths
}

type cigOp struct {
	n  int
	op byte
}

func cigarOps(c string) []cigOp {
	var ops []cigOp
	n := 0
	for i := 0; i < len(c); i++ {
		if c[i] >= '0' && c[i] <= '9' {
			n = n*10 + int(c[i]-'0')
		} else {
			ops = append(ops, cigOp{n, c[i]})
			n = 0
		}
	}
	return ops
}

func filterDepth(dep map[string]map[int]int, name string, start, end int) map[string]map[int]int {
	out := map[string]map[int]int{name: {}}
	for p, d := range dep[name] {
		if p >= start && (end == 0 || p <= end) {
			out[name][p] = d
		}
	}
	return out
}

func maxCovered(m map[int]int) int {
	max := 0
	for p, d := range m {
		if d > 0 && p > max {
			max = p
		}
	}
	return max
}

func sortedKeysInt(m map[string]int) []string {
	var keys []string
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}

func touchFile(path string) int {
	f, err := os.Create(path)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		return 1
	}
	_ = f.Close()
	return 0
}
