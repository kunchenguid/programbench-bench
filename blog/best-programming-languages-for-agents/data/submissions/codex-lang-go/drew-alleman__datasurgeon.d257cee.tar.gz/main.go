package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

type options struct {
	file, add, update, remove, directory, drop, filter, output string
	list, clean, ignore, line, thorough, display, suppress, hide, timing bool
	email, phone, hash, ip, ipv6, mac, cc, url, files, bitcoin, aws, google, dns, social bool
}

type extractor struct { name string; re *regexp.Regexp }

type hit struct { kind, value, file string; line int }

const pluginPath = "/home/agent/.DataSurgeon/plugins.json"

var errHelp = fmt.Errorf("help")
var errVersion = fmt.Errorf("version")

func main() {
	start := time.Now()
	helpMode := false
	ignoreMode := false
	for _, a := range os.Args[1:] {
		if a == "-h" || a == "--help" || a == "-V" || a == "--version" { helpMode = true }
		if a == "--ignore" { ignoreMode = true }
	}
	if helpMode || !ignoreMode { fmt.Fprintf(os.Stderr, "Failed to open plugins.json file. PLUGIN_PATH: %s\n", pluginPath) }
	opt, err := parseArgs(os.Args[1:])
	if err == errHelp || err == errVersion { return }
	if err != nil { os.Exit(2) }

	if opt.list {
		if !opt.ignore { fmt.Fprintf(os.Stderr, "Failed to open plugins.json file. PLUGIN_PATH: %s\n", pluginPath) }
		fmt.Printf("No plugins found. Plugin File: %s\n", pluginPath)
		return
	}
	if opt.add != "" {
		if !opt.ignore { fmt.Fprintf(os.Stderr, "[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base\n") }
		return
	}
	if opt.remove != "" || opt.update != "" { return }

	var out io.Writer = os.Stdout
	var f *os.File
	if opt.output != "" {
		var e error
		f, e = os.Create(opt.output); if e != nil { if !opt.ignore { fmt.Fprintln(os.Stderr, e) }; os.Exit(1) }
		defer f.Close(); out = f
		fmt.Fprintln(out, "content_type, data")
	}

	exts := buildExtractors(opt)
	if len(exts)==0 { exts = defaultExtractors() }

	if opt.directory != "" {
		filepath.WalkDir(opt.directory, func(path string, d os.DirEntry, e error) error {
			if e != nil { if !opt.ignore { fmt.Fprintln(os.Stderr, e) }; return nil }
			if d.IsDir() { return nil }
			processFile(path, opt, exts, out)
			return nil
		})
	} else if opt.file != "" {
		processFile(opt.file, opt, exts, out)
	} else {
		if !opt.suppress { fmt.Fprintln(os.Stdout, "[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)") }
		processReader(os.Stdin, "", opt, exts, out)
	}
	if opt.timing { fmt.Fprintf(os.Stderr, "Time elapsed: %s\n", time.Since(start)) }
}

func parseArgs(args []string) (options, error) {
	var o options
	fs := flag.NewFlagSet("executable", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.StringVar(&o.file,"f","",""); fs.StringVar(&o.file,"file","","")
	fs.StringVar(&o.add,"add","",""); fs.StringVar(&o.update,"update","",""); fs.StringVar(&o.remove,"remove","","")
	fs.BoolVar(&o.list,"list",false,""); fs.BoolVar(&o.clean,"C",false,""); fs.BoolVar(&o.clean,"clean",false,"")
	fs.StringVar(&o.directory,"directory","",""); fs.BoolVar(&o.ignore,"ignore",false,"")
	fs.BoolVar(&o.line,"l",false,""); fs.BoolVar(&o.line,"line",false,"")
	fs.BoolVar(&o.thorough,"T",false,""); fs.BoolVar(&o.thorough,"thorough",false,"")
	fs.BoolVar(&o.display,"D",false,""); fs.BoolVar(&o.display,"display",false,"")
	fs.BoolVar(&o.suppress,"S",false,""); fs.BoolVar(&o.suppress,"suppress",false,"")
	fs.StringVar(&o.drop,"drop","",""); fs.StringVar(&o.filter,"filter","","")
	fs.BoolVar(&o.hide,"X",false,""); fs.BoolVar(&o.hide,"hide",false,"")
	fs.StringVar(&o.output,"o","",""); fs.StringVar(&o.output,"output","","")
	fs.BoolVar(&o.timing,"t",false,""); fs.BoolVar(&o.timing,"time",false,"")
	fs.BoolVar(&o.email,"e",false,""); fs.BoolVar(&o.email,"email",false,"")
	fs.BoolVar(&o.phone,"p",false,""); fs.BoolVar(&o.phone,"phone",false,"")
	fs.BoolVar(&o.hash,"H",false,""); fs.BoolVar(&o.hash,"hash",false,"")
	fs.BoolVar(&o.ip,"i",false,""); fs.BoolVar(&o.ip,"ip-addr",false,"")
	fs.BoolVar(&o.ipv6,"6",false,""); fs.BoolVar(&o.ipv6,"ipv6-addr",false,"")
	fs.BoolVar(&o.mac,"m",false,""); fs.BoolVar(&o.mac,"mac-addr",false,"")
	fs.BoolVar(&o.cc,"c",false,""); fs.BoolVar(&o.cc,"credit-card",false,"")
	fs.BoolVar(&o.url,"u",false,""); fs.BoolVar(&o.url,"url",false,"")
	fs.BoolVar(&o.files,"F",false,""); fs.BoolVar(&o.files,"files",false,"")
	fs.BoolVar(&o.bitcoin,"b",false,""); fs.BoolVar(&o.bitcoin,"bitcoin",false,"")
	fs.BoolVar(&o.aws,"a",false,""); fs.BoolVar(&o.aws,"aws",false,"")
	fs.BoolVar(&o.google,"g",false,""); fs.BoolVar(&o.google,"google",false,"")
	fs.BoolVar(&o.dns,"d",false,""); fs.BoolVar(&o.dns,"dns",false,"")
	fs.BoolVar(&o.social,"s",false,""); fs.BoolVar(&o.social,"social",false,"")
	fs.Bool("h",false,""); fs.Bool("help",false,""); fs.Bool("V",false,""); fs.Bool("version",false,"")
	for _, a := range args { if a=="-h"||a=="--help" { printHelp(); return o, errHelp }; if a=="-V"||a=="--version" { fmt.Println("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8"); return o, errVersion } }
	if err:=fs.Parse(args); err!=nil { fmt.Fprintf(os.Stderr,"error: %v\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n",err); return o,err }
	return o,nil
}

func printHelp(){
fmt.Print(`Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use `+"`"+`ds --update all`+"`"+` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version
`)
}

func rx(s string)*regexp.Regexp{return regexp.MustCompile(s)}
func defaultExtractors() []extractor { return []extractor{} }
func buildExtractors(o options) []extractor{
	if !o.clean {
		all := []struct{on bool; e extractor}{
			{o.email, extractor{"email", rx(`[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}`)}},
			{o.phone, extractor{"phone", rx(`\b(?:\+?1[ .-]?)?(?:\(?\d{3}\)?[ .-]?\d{3}[ .-]?\d{4})\b`)}},
			{o.hash, extractor{"hashes", rx(`(?i)\b(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{56}|[a-f0-9]{64}|[a-f0-9]{96}|[a-f0-9]{128})\b`)}},
			{o.ip, extractor{"ip_address", rx(`\b(?:\d{1,3}\.){3}\d{1,3}\b`)}},
			{o.ipv6, extractor{"ipv6_address", rx(`(?i)\b(?:[0-9a-f]{1,4}:){2,7}[0-9a-f]{0,4}\b|::1\b`)}},
			{o.mac, extractor{"mac_address", rx(`(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b`)}},
			{o.cc, extractor{"credit_card", rx(`\b(?:\d[ -]*?){13,19}\b`)}},
			{o.url, extractor{"url", rx(`(?i)\b(?:https?://|ftp://|www\.)[^\s<>'"]+`)}},
			{o.files, extractor{"files", rx(`(?i)\b[\w./\\-]+\.(?:txt|csv|json|xml|html?|php|asp|aspx|jsp|js|css|png|jpe?g|gif|pdf|docx?|xlsx?|pptx?|zip|tar|gz|tgz|rar|7z|exe|dll|so|conf|log|db|sqlite|bak|yml|yaml|md)\b|/(?:[\w.\-]+/)*[\w.\-]+`)}},
			{o.bitcoin, extractor{"bitcoin_wallet", rx(`\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|\bbc1[ac-hj-np-z02-9]{11,71}\b`)}},
			{o.aws, extractor{"aws_key", rx(`\b(?:AKIA|ASIA)[A-Z0-9]{16}\b`)}},
			{o.google, extractor{"google_api", rx(`\b[0-9a-f]{40}\b`)}},
			{o.dns, extractor{"dns", rx(`(?i)\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\b`)}},
			{o.social, extractor{"social_security", rx(`\b\d{3}-\d{2}-\d{4}\b`)}},
		}
		var out []extractor
		for _, it := range all { if it.on { out=append(out,it.e) } }
		return out
	}
	all := []struct{on bool; e extractor}{
		{o.hash, extractor{"hashes", rx(`(?i)\b(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{56}|[a-f0-9]{64}|[a-f0-9]{96}|[a-f0-9]{128})\b`)}},
		{o.ipv6, extractor{"ipv6_address", rx(`(?i)\b(?:[0-9a-f]{1,4}:){2,7}[0-9a-f]{0,4}\b|::1\b`)}},
		{o.ip, extractor{"ip_address", rx(`\b(?:\d{1,3}\.){3}\d{1,3}\b`)}},
		{o.mac, extractor{"mac_address", rx(`(?i)\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\b`)}},
		{o.cc, extractor{"credit_card", rx(`\b(?:\d[ -]*?){13,19}\b`)}},
		{o.url, extractor{"url", rx(`(?i)\b(?:https?://|ftp://|www\.)[^\s<>'"]+`)}},
		{o.email, extractor{"email", rx(`[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}`)}},
		{o.phone, extractor{"phone", rx(`\b(?:\+?1[ .-]?)?(?:\(?\d{3}\)?[ .-]?\d{3}[ .-]?\d{4})\b`)}},
		{o.aws, extractor{"aws_key", rx(`\b(?:AKIA|ASIA)[A-Z0-9]{16}\b`)}},
		{o.google, extractor{"google_api", rx(`\b[0-9a-f]{40}\b`)}},
		{o.social, extractor{"social_security", rx(`\b\d{3}-\d{2}-\d{4}\b`)}},
		{o.bitcoin, extractor{"bitcoin_wallet", rx(`\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|\bbc1[ac-hj-np-z02-9]{11,71}\b`)}},
		{o.dns, extractor{"dns", rx(`(?i)\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}\b`)}},
		{o.files, extractor{"files", rx(`(?i)\b[\w./\\-]+\.(?:txt|csv|json|xml|html?|php|asp|aspx|jsp|js|css|png|jpe?g|gif|pdf|docx?|xlsx?|pptx?|zip|tar|gz|tgz|rar|7z|exe|dll|so|conf|log|db|sqlite|bak|yml|yaml|md)\b|/(?:[\w.\-]+/)*[\w.\-]+`)}},
	}
	var out []extractor
	for _, it := range all { if it.on { out=append(out,it.e) } }
	return out
}

func processFile(path string,o options, ex []extractor, out io.Writer){
	f,e:=os.Open(path); if e!=nil { if !o.ignore { fmt.Fprintln(os.Stderr,e) }; return }
	defer f.Close(); processReader(f,path,o,ex,out)
}
func processReader(r io.Reader, file string, o options, ex []extractor, out io.Writer){
	var filter, drop *regexp.Regexp
	if o.filter!="" { filter=rx(o.filter) }; if o.drop!="" { drop=rx(o.drop) }
	s:=bufio.NewScanner(r); buf:=make([]byte,1024); s.Buffer(buf,1024*1024*20)
	ln:=0
	for s.Scan(){ ln++; line:=s.Text(); if filter!=nil && !filter.MatchString(line){continue}
		var hits []hit
		for _, e := range ex { vals:=e.re.FindAllString(line,-1); if len(vals)==0 {continue}
			if !o.clean { hits=append(hits, hit{e.name,line,file,ln}); break }
			seen:=map[string]bool{}
			for _, v:= range vals { if drop!=nil && drop.MatchString(v){continue}; if seen[v]{continue}; seen[v]=true; hits=append(hits, hit{e.name,v,file,ln}); if !o.thorough {break} }
			if len(hits)>0 && !o.thorough {break}
		}
		if o.thorough { sort.SliceStable(hits, func(i,j int)bool{return strings.Index(line,hits[i].value)<strings.Index(line,hits[j].value)}) }
		for _, h := range hits { printHit(out,h,o) }
	}
}
func printHit(w io.Writer,h hit,o options){
	if o.output!="" { fmt.Fprintf(w,"%s, %s\n",h.kind,h.value); return }
	prefix := h.kind
	if o.hide { prefix="" }
	if o.display { if prefix!="" { prefix += ", " }; prefix += "file: "+h.file }
	if prefix!="" {
		sep := ": "; if o.line || o.display { sep = " " ; if !o.display && o.line { sep = ", " } }
		fmt.Fprint(w,prefix,sep,h.value)
	} else { fmt.Fprint(w,h.value) }
	if o.line { fmt.Fprintf(w,", line: %d",h.line) }
	fmt.Fprintln(w)
}
