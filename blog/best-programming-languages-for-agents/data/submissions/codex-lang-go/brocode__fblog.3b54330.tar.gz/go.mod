module fblogclone

go 1.21
