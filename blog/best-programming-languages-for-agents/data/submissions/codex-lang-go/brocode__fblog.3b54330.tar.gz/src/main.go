package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

const (
	reset   = "\x1b[0m"
	bold    = "\x1b[1m"
	dim     = "\x1b[2m"
	red     = "\x1b[31m"
	green   = "\x1b[32m"
	yellow  = "\x1b[33m"
	blue    = "\x1b[34m"
	magenta = "\x1b[35m"
	cyan    = "\x1b[36m"
	gray    = "\x1b[38;2;150;150;150m"
	orange  = "\x1b[38;2;255;135;22m"
)

type options struct {
	input                  string
	add                    []string
	excl                   []string
	msgKeys                []string
	timeKeys               []string
	levelKeys              []string
	mapLevel               map[string]string
	dumpAll                bool
	prefix                 bool
	filter                 string
	noImplicitFilterReturn bool
	mainFmt                string
	addFmt                 string
	substitute             bool
	contextKey             string
	placeholderFmt         string
	configFile             string
	printLua               bool
}

type entry struct {
	raw       map[string]interface{}
	prefix    string
	message   interface{}
	timestamp interface{}
	level     interface{}
	fmsg      string
	ftime     string
	flevel    string
}

func main() {
	opt, ok := parseArgs(os.Args[1:])
	if !ok {
		os.Exit(2)
	}
	if opt.printLua {
		return
	}
	if opt.configFile != "" {
		loadConfig(opt.configFile, opt)
	}
	loadDefaultConfig(opt)

	var r io.Reader = os.Stdin
	if opt.input != "" && opt.input != "-" {
		f, err := os.Open(opt.input)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
			os.Exit(1)
		}
		defer f.Close()
		r = f
	}
	process(r, opt)
}

func loadDefaultConfig(o *options) {
	if len(o.msgKeys) == 0 {
		o.msgKeys = []string{"short_message", "msg", "message"}
	}
	if len(o.timeKeys) == 0 {
		o.timeKeys = []string{"timestamp", "time", "@timestamp"}
	}
	if len(o.levelKeys) == 0 {
		o.levelKeys = []string{"level", "severity", "log.level", "loglevel"}
	}
	if o.mapLevel == nil {
		o.mapLevel = map[string]string{}
	}
	if o.contextKey == "" {
		o.contextKey = "context"
	}
	if o.placeholderFmt == "" {
		o.placeholderFmt = "{key}"
	}
}

func parseArgs(args []string) (*options, bool) {
	o := &options{input: "-", mapLevel: map[string]string{}}
	for i := 0; i < len(args); i++ {
		a := args[i]
		need := func() string {
			if i+1 >= len(args) {
				usageErr(fmt.Sprintf("a value is required for '%s'", a))
				os.Exit(2)
			}
			i++
			return args[i]
		}
		switch a {
		case "-h", "--help":
			printHelp()
			return o, false
		case "-V", "--version":
			fmt.Println("fblog 4.17.0")
			return o, false
		case "-a", "--additional-value":
			o.add = append(o.add, need())
		case "--config-file":
			o.configFile = need()
		case "-m", "--message-key":
			o.msgKeys = append(o.msgKeys, need())
		case "-t", "--time-key":
			o.timeKeys = append(o.timeKeys, need())
		case "-l", "--level-key":
			o.levelKeys = append(o.levelKeys, need())
		case "--map-level":
			p := strings.SplitN(need(), "=", 2)
			if len(p) == 2 {
				o.mapLevel[p[0]] = p[1]
			}
		case "-d", "--dump-all":
			o.dumpAll = true
		case "-x", "--excluded-value":
			o.excl = append(o.excl, need())
			o.dumpAll = true
		case "-p", "--with-prefix":
			o.prefix = true
		case "-f", "--filter":
			o.filter = need()
		case "--no-implicit-filter-return-statement":
			o.noImplicitFilterReturn = true
		case "--main-line-format":
			o.mainFmt = need()
		case "--additional-value-format":
			o.addFmt = need()
		case "-s", "--substitute":
			o.substitute = true
		case "-c", "--context-key":
			o.contextKey = need()
		case "-F", "--placeholder-format":
			o.placeholderFmt = need()
		case "--print-lua":
			o.printLua = true
		default:
			if strings.HasPrefix(a, "-") {
				usageErr(fmt.Sprintf("unexpected argument '%s' found", a))
				return o, false
			}
			if o.input != "-" {
				usageErr(fmt.Sprintf("unexpected argument '%s' found", a))
				return o, false
			}
			o.input = a
		}
	}
	return o, true
}

func usageErr(msg string) {
	fmt.Fprintf(os.Stderr, "error: %s\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.\n", msg)
}

func printHelp() {
	fmt.Print(`json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to ` + "`" + `fblog_message` + "`" + `.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to ` + "`" + `fblog_timestamp` + "`" + `.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to ` + "`" + `fblog_level` + "`" + `.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. ` + "`" + `message ~= nil and string.find(message, "text.*") ~= nil` + "`" + `
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with ` + "`" + `fblog_` + "`" + `.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word ` + "`" + `key` + "`" + `. Example: [[key]] or ${key}.
  -h, --help
          Print help
  -V, --version
          Print version
`)
}

func process(r io.Reader, o *options) {
	br := bufio.NewReader(r)
	for {
		b, err := br.ReadBytes('\n')
		if len(b) > 0 {
			b = bytes.TrimRight(b, "\r\n")
			if !utf8.Valid(b) {
				fmt.Println("\x1b[1;31m??? >" + reset + " Could not read line: stream did not contain valid UTF-8")
				continue
			}
			handleLine(string(b), o)
		}
		if err == io.EOF {
			break
		}
		if err != nil {
			break
		}
	}
}

func handleLine(line string, o *options) {
	parseLine := line
	pref := ""
	if o.prefix {
		if idx := strings.Index(line, "{"); idx >= 0 {
			pref = strings.TrimRight(line[:idx], " ")
			parseLine = line[idx:]
		}
	}
	var m map[string]interface{}
	dec := json.NewDecoder(strings.NewReader(parseLine))
	dec.UseNumber()
	if err := dec.Decode(&m); err != nil {
		fmt.Println("\x1b[1;38;2;255;135;22m??? >" + reset + " " + line)
		return
	}
	e := buildEntry(m, pref, o)
	if !passesFilter(e, o.filter) {
		return
	}
	if o.substitute {
		e.fmsg = substitute(e, m, o)
	}
	printMain(e, o)
	printAdditional(e, o)
}

func buildEntry(m map[string]interface{}, pref string, o *options) entry {
	e := entry{raw: m, prefix: pref, flevel: "UNKNOWN"}
	for _, k := range o.msgKeys {
		if v, ok := getPath(m, k); ok {
			e.message = v
			e.fmsg = plain(v)
			break
		}
	}
	if e.fmsg == "" {
		b, _ := json.Marshal(m)
		e.fmsg = string(b)
	}
	for _, k := range o.timeKeys {
		if v, ok := getPath(m, k); ok {
			e.timestamp = v
			e.ftime = formatTime(v)
			break
		}
	}
	for _, k := range o.levelKeys {
		if v, ok := getPath(m, k); ok {
			e.level = v
			e.flevel = strings.ToUpper(plain(v))
			break
		}
	}
	if to, ok := o.mapLevel[plain(e.level)]; ok {
		e.flevel = strings.ToUpper(to)
	}
	return e
}

func getPath(m map[string]interface{}, path string) (interface{}, bool) {
	if v, ok := m[path]; ok {
		return v, true
	}
	cur := interface{}(m)
	parts := strings.Split(path, ".")
	for _, p := range parts {
		mm, ok := cur.(map[string]interface{})
		if !ok {
			return nil, false
		}
		cur, ok = mm[p]
		if !ok {
			return nil, false
		}
	}
	return cur, true
}

func formatTime(v interface{}) string {
	switch x := v.(type) {
	case json.Number:
		n, _ := x.Int64()
		if n > 1000000000000 {
			return time.UnixMilli(n).UTC().Format("2006-01-02T15:04:05")
		}
		return x.String()
	case float64:
		if x > 1000000000000 {
			return time.UnixMilli(int64(x)).UTC().Format("2006-01-02T15:04:05")
		}
		return fmt.Sprint(x)
	case string:
		if n, err := strconv.ParseInt(x, 10, 64); err == nil && n > 1000000000000 {
			return time.UnixMilli(n).UTC().Format("2006-01-02T15:04:05")
		}
		if len(x) > 19 {
			return x[:19]
		}
		return x
	default:
		s := plain(v)
		if len(s) > 19 {
			return s[:19]
		}
		return s
	}
}

func fixed(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	if len(s) < n {
		return strings.Repeat(" ", n-len(s)) + s
	}
	return s
}
func mainTime(s string) string { return bold + fixed(s, 19) + reset }
func levelColorCode(l string) string {
	u := strings.ToUpper(l)
	if u == "ERROR" || u == "ERR" || u == "50" || u == "60" {
		return "\x1b[1;31m"
	}
	if u == "WARN" || u == "30" {
		return "\x1b[1;33m"
	}
	if u == "INFO" || u == "20" {
		return "\x1b[1;32m"
	}
	if u == "DEBUG" || u == "10" {
		return "\x1b[1;34m"
	}
	return "\x1b[1;35m"
}
func mainLevel(l string) string { return levelColorCode(l) + fixed(strings.ToUpper(l), 5) + reset }

func printMain(e entry, o *options) {
	if o.mainFmt != "" {
		fmt.Println(renderTemplate(o.mainFmt, e, "", ""))
		return
	}
	p := ""
	if e.prefix != "" {
		p = " " + bold + cyan + e.prefix + reset + reset
	}
	fmt.Printf("%s %s:%s %s\n", mainTime(e.ftime), mainLevel(e.flevel), p, e.fmsg)
}

func printAdditional(e entry, o *options) {
	vals := map[string]string{}
	if o.dumpAll {
		flatten("", e.raw, vals)
	}
	for _, a := range o.add {
		if v, ok := getAdd(e.raw, a); ok {
			flatten(a, v, vals)
		}
	}
	excl := map[string]bool{}
	for _, x := range o.excl {
		excl[x] = true
	}
	keys := make([]string, 0, len(vals))
	for k := range vals {
		if !excl[k] {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		if o.addFmt != "" {
			fmt.Println(renderTemplate(o.addFmt, e, k, vals[k]))
			continue
		}
		fmt.Printf("%s%s%s: %s\n", bold+gray, fixed(k, 25), reset+reset, vals[k])
	}
}

func getAdd(m map[string]interface{}, path string) (interface{}, bool) {
	path = strings.ReplaceAll(path, " > ", ".")
	path = strings.TrimSpace(path)
	return getPath(m, path)
}

func flatten(prefix string, v interface{}, out map[string]string) {
	switch x := v.(type) {
	case map[string]interface{}:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			np := k
			if prefix != "" {
				np = prefix + " > " + k
			}
			flatten(np, x[k], out)
		}
	case []interface{}:
		for i, it := range x {
			np := fmt.Sprintf("%s[%d]", prefix, i)
			flatten(np, it, out)
		}
	default:
		if prefix != "" {
			out[prefix] = valueString(x)
		}
	}
}

func valueString(v interface{}) string {
	switch x := v.(type) {
	case string:
		return x
	case json.Number:
		return x.String()
	case nil:
		return "null"
	default:
		b, _ := json.Marshal(x)
		return string(b)
	}
}
func plain(v interface{}) string {
	if v == nil {
		return ""
	}
	switch x := v.(type) {
	case string:
		return x
	case json.Number:
		return x.String()
	default:
		return valueString(x)
	}
}

func renderTemplate(t string, e entry, key, value string) string {
	repl := map[string]string{"{{fblog_message}}": strconv.Quote(e.fmsg), "{{fblog_timestamp}}": strconv.Quote(e.ftime), "{{fblog_level}}": strconv.Quote(e.flevel), "{{key}}": key, "{{value}}": value}
	if strings.Contains(t, "{{key}}") || strings.Contains(t, "{{value}}") {
		repl["{{key}}"] = key
		repl["{{value}}"] = value
	}
	s := t
	for k, v := range repl {
		s = strings.ReplaceAll(s, k, v)
	}
	return strconv.Quote(strings.Trim(s, "\""))
}

func passesFilter(e entry, f string) bool {
	f = strings.TrimSpace(f)
	if f == "" {
		return true
	}
	f = strings.TrimPrefix(f, "return ")
	parts := strings.Split(f, " and ")
	for _, p := range parts {
		if !evalCond(strings.TrimSpace(p), e) {
			return false
		}
	}
	return true
}

func evalCond(c string, e entry) bool {
	c = strings.TrimSpace(c)
	if strings.Contains(c, "string.find") {
		start := strings.Index(c, "string.find(")
		if start >= 0 {
			inside := c[start+12:]
			end := strings.Index(inside, ")")
			if end >= 0 {
				args := strings.SplitN(inside[:end], ",", 2)
				if len(args) == 2 {
					pat := strings.Trim(strings.TrimSpace(args[1]), "\"")
					return strings.Contains(e.fmsg, strings.TrimSuffix(pat, ".*"))
				}
			}
		}
	}
	ops := []string{"~=", "==", "!=", ">=", "<=", ">", "<"}
	for _, op := range ops {
		if idx := strings.Index(c, op); idx >= 0 {
			left := strings.TrimSpace(c[:idx])
			right := strings.Trim(strings.TrimSpace(c[idx+len(op):]), "\"")
			lv := varVal(left, e)
			return compare(lv, right, op)
		}
	}
	return true
}
func varVal(k string, e entry) string {
	switch k {
	case "message":
		return e.fmsg
	case "level":
		return plain(e.level)
	case "time", "timestamp":
		return e.ftime
	default:
		if v, ok := getPath(e.raw, k); ok {
			return plain(v)
		}
		return ""
	}
}
func compare(a, b, op string) bool {
	af, ae := strconv.ParseFloat(a, 64)
	bf, be := strconv.ParseFloat(b, 64)
	if ae == nil && be == nil && !math.IsNaN(af) {
		switch op {
		case "==":
			return af == bf
		case "!=", "~=":
			return af != bf
		case ">":
			return af > bf
		case "<":
			return af < bf
		case ">=":
			return af >= bf
		case "<=":
			return af <= bf
		}
	}
	switch op {
	case "==":
		return a == b
	case "!=", "~=":
		return a != b
	case ">":
		return a > b
	case "<":
		return a < b
	case ">=":
		return a >= b
	case "<=":
		return a <= b
	}
	return true
}

func substitute(e entry, m map[string]interface{}, o *options) string {
	ctx, ok := getPath(m, o.contextKey)
	if !ok {
		return e.fmsg
	}
	msg := e.fmsg
	switch c := ctx.(type) {
	case map[string]interface{}:
		for k, v := range c {
			ph := strings.ReplaceAll(o.placeholderFmt, "key", k)
			msg = strings.ReplaceAll(msg, ph, styled(v))
		}
	case []interface{}:
		for i, v := range c {
			ph := strings.ReplaceAll(o.placeholderFmt, "key", strconv.Itoa(i))
			msg = strings.ReplaceAll(msg, ph, styled(v))
		}
	}
	return msg
}

func styled(v interface{}) string {
	switch x := v.(type) {
	case bool:
		if x {
			return bold + green + "true" + reset
		}
		return bold + red + "false" + reset
	case string:
		return bold + yellow + x + reset
	case json.Number:
		return bold + cyan + x.String() + reset
	case float64:
		return bold + cyan + fmt.Sprint(x) + reset
	case []interface{}:
		parts := []string{}
		for _, it := range x {
			parts = append(parts, styled(it))
		}
		return dim + "[" + reset + strings.Join(parts, dim+", "+reset) + dim + "]" + reset
	case map[string]interface{}:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		parts := []string{}
		for _, k := range keys {
			parts = append(parts, magenta+k+reset+dim+": "+reset+styled(x[k]))
		}
		return dim + "{" + reset + strings.Join(parts, dim+", "+reset) + dim + "}" + reset
	default:
		return valueString(x)
	}
}

func loadConfig(path string, o *options) {
	b, err := os.ReadFile(path)
	if err != nil {
		return
	}
	lines := strings.Split(string(b), "\n")
	inMap := false
	for _, ln := range lines {
		ln = strings.TrimSpace(ln)
		if ln == "" || strings.HasPrefix(ln, "#") {
			continue
		}
		if ln == "[level_map]" {
			inMap = true
			continue
		}
		if strings.HasPrefix(ln, "[") {
			inMap = false
			continue
		}
		if inMap {
			p := strings.SplitN(ln, "=", 2)
			if len(p) == 2 {
				o.mapLevel[trimQ(p[0])] = trimQ(p[1])
			}
			continue
		}
		p := strings.SplitN(ln, "=", 2)
		if len(p) != 2 {
			continue
		}
		k := strings.TrimSpace(p[0])
		v := strings.TrimSpace(p[1])
		switch k {
		case "message_keys":
			o.msgKeys = parseArr(v)
		case "time_keys":
			o.timeKeys = parseArr(v)
		case "level_keys":
			o.levelKeys = parseArr(v)
		case "main_line_format":
			o.mainFmt = trimQ(v)
		case "additional_value_format":
			o.addFmt = trimQ(v)
		}
	}
}
func trimQ(s string) string { return strings.Trim(strings.TrimSpace(s), "\"") }
func parseArr(s string) []string {
	s = strings.Trim(s, "[] ")
	if s == "" {
		return nil
	}
	ps := strings.Split(s, ",")
	out := []string{}
	for _, p := range ps {
		out = append(out, trimQ(p))
	}
	return out
}
