module ttyclock

go 1.21
