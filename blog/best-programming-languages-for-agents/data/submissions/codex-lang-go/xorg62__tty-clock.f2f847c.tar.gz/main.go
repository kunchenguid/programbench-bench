package main

import (
	"bufio"
	"fmt"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const usageText = `usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
    -s            Show seconds                                   
    -S            Screensaver mode                               
    -x            Show box                                       
    -c            Set the clock at the center of the terminal    
    -C [0-7]      Set the clock color                            
    -b            Use bold colors                                
    -t            Set the hour in 12h format                     
    -u            Use UTC time                                   
    -T tty        Display the clock on the specified terminal    
    -r            Do rebound the clock                           
    -f format     Set the date format                            
    -n            Don't quit on keypress                         
    -v            Show tty-clock version                         
    -i            Show some info about tty-clock                 
    -h            Show this page                                 
    -D            Hide date                                      
    -B            Enable blinking colon                          
    -d delay      Set the delay between two redraws of the clock. Default 1s. 
    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.
`

var digit = map[rune][]string{
	'0': {" ###### ", "##    ##", "##    ##", "##    ##", " ###### "},
	'1': {"   ##   ", " ####   ", "   ##   ", "   ##   ", " ###### "},
	'2': {" ###### ", "      ##", " ###### ", "##      ", "########"},
	'3': {"####### ", "      ##", " ###### ", "      ##", "####### "},
	'4': {"##   ## ", "##   ## ", "########", "     ## ", "     ## "},
	'5': {"########", "##      ", "####### ", "      ##", "####### "},
	'6': {" ###### ", "##      ", "####### ", "##    ##", " ###### "},
	'7': {"########", "     ## ", "    ##  ", "   ##   ", "   ##   "},
	'8': {" ###### ", "##    ##", " ###### ", "##    ##", " ###### "},
	'9': {" ###### ", "##    ##", " #######", "      ##", " ###### "},
	':': {"  ", "##", "  ", "##", "  "},
	' ': {"  ", "  ", "  ", "  ", "  "},
}

type config struct {
	seconds     bool
	screensaver bool
	box         bool
	center      bool
	color       int
	bold        bool
	twelve      bool
	utc         bool
	tty         string
	rebound     bool
	dateFormat  string
	noQuit      bool
	hideDate    bool
	blink       bool
	delay       int
	nsDelay     int
}

func main() {
	cfg := config{color: 2, dateFormat: "%F", delay: 1}
	if !parseArgs(&cfg, os.Args[1:]) {
		return
	}
	if cfg.tty != "" {
		f, err := os.OpenFile(cfg.tty, os.O_WRONLY, 0)
		if err != nil {
			fmt.Fprintf(os.Stderr, "tty-clock: error: couldn't open %s\n", cfg.tty)
			os.Exit(1)
		}
		defer f.Close()
		os.Stdout = f
	}
	runClock(cfg)
}

func parseArgs(cfg *config, args []string) bool {
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "--" {
			continue
		}
		if !strings.HasPrefix(arg, "-") || arg == "-" {
			continue
		}
		for p := 1; p < len(arg); p++ {
			ch := arg[p]
			need := func() (string, bool) {
				if p+1 < len(arg) {
					v := arg[p+1:]
					p = len(arg)
					return v, true
				}
				if i+1 >= len(args) {
					fmt.Fprintf(os.Stderr, "%s: option requires an argument -- '%c'\n", os.Args[0], ch)
					fmt.Print(usageText)
					return "", false
				}
				i++
				return args[i], true
			}
			switch ch {
			case 's':
				cfg.seconds = true
			case 'S':
				cfg.screensaver = true
			case 'x':
				cfg.box = true
			case 'c':
				cfg.center = true
			case 'C':
				v, ok := need()
				if !ok {
					return false
				}
				n, _ := strconv.Atoi(v)
				if n >= 0 && n <= 7 {
					cfg.color = n
				}
			case 'b':
				cfg.bold = true
			case 't':
				cfg.twelve = true
			case 'u':
				cfg.utc = true
			case 'T':
				v, ok := need()
				if !ok {
					return false
				}
				cfg.tty = v
			case 'r':
				cfg.rebound = true
			case 'f':
				v, ok := need()
				if !ok {
					return false
				}
				cfg.dateFormat = v
			case 'n':
				cfg.noQuit = true
			case 'v':
				fmt.Println("TTY-Clock 2 © devel version")
				return false
			case 'i':
				fmt.Println("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)")
				return false
			case 'h':
				fmt.Print(usageText)
				return false
			case 'D':
				cfg.hideDate = true
			case 'B':
				cfg.blink = true
			case 'd':
				v, ok := need()
				if !ok {
					return false
				}
				n, _ := strconv.Atoi(v)
				cfg.delay = n
			case 'a':
				v, ok := need()
				if !ok {
					return false
				}
				n, _ := strconv.Atoi(v)
				cfg.nsDelay = n
			default:
				fmt.Fprintf(os.Stderr, "%s: invalid option -- '%c'\n", os.Args[0], ch)
				fmt.Print(usageText)
				return false
			}
		}
	}
	return true
}

func runClock(cfg config) {
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGTERM)
	key := make(chan byte, 1)
	go readKeys(key)

	fmt.Print("\033[?1049h\033[?25l\033[H\033[2J")
	defer fmt.Print("\033[0m\033[?25h\033[?1049l")

	x, y, dx, dy := 1, 1, 1, 1
	interval := time.Duration(cfg.delay)*time.Second + time.Duration(cfg.nsDelay)
	if interval <= 0 {
		interval = 100 * time.Millisecond
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		now := time.Now()
		if cfg.utc {
			now = now.UTC()
		}
		draw(cfg, now, x, y)
		select {
		case <-done:
			return
		case b := <-key:
			if !cfg.noQuit && (cfg.screensaver || b == 'q' || b == 'Q') {
				return
			}
			handleKey(&cfg, b)
		case <-ticker.C:
			if cfg.rebound || cfg.screensaver {
				x += dx
				y += dy
				if x <= 1 || x >= 40 {
					dx = -dx
				}
				if y <= 1 || y >= 12 {
					dy = -dy
				}
			}
		}
	}
}

func readKeys(ch chan<- byte) {
	r := bufio.NewReader(os.Stdin)
	for {
		b, err := r.ReadByte()
		if err != nil {
			return
		}
		ch <- b
	}
}

func handleKey(cfg *config, b byte) {
	if b >= '0' && b <= '7' {
		cfg.color = int(b - '0')
		return
	}
	switch b {
	case 'b', 'B':
		cfg.bold = !cfg.bold
	case 'x', 'X':
		cfg.box = !cfg.box
	case 'c', 'C':
		cfg.center = !cfg.center
	case 'r', 'R':
		cfg.rebound = !cfg.rebound
	case 's', 'S':
		cfg.seconds = !cfg.seconds
	case 't', 'T':
		cfg.twelve = !cfg.twelve
	}
}

func draw(cfg config, now time.Time, x, y int) {
	timeFmt := "15:04"
	if cfg.seconds {
		timeFmt = "15:04:05"
	}
	if cfg.twelve {
		timeFmt = "03:04"
		if cfg.seconds {
			timeFmt = "03:04:05"
		}
	}
	text := now.Format(timeFmt)
	lines := render(text)
	date := strftime(now, cfg.dateFormat)
	width := len(lines[0])
	if len(date) > width {
		width = len(date)
	}
	if cfg.center {
		cols, rows := termSize()
		x = max(1, (cols-width)/2)
		y = max(1, (rows-len(lines)-1)/2)
	}
	fmt.Print("\033[H\033[2J")
	if cfg.box {
		boxWidth := width + 4
		move(y, x)
		fmt.Print("+" + strings.Repeat("-", boxWidth-2) + "+")
		for i := 0; i < len(lines)+dateRows(cfg); i++ {
			move(y+1+i, x)
			fmt.Print("|" + strings.Repeat(" ", boxWidth-2) + "|")
		}
		move(y+len(lines)+dateRows(cfg)+1, x)
		fmt.Print("+" + strings.Repeat("-", boxWidth-2) + "+")
		x += 2
		y++
	}
	attr := 30 + cfg.color
	if cfg.bold {
		fmt.Printf("\033[1;%dm", attr)
	} else {
		fmt.Printf("\033[%dm", attr)
	}
	if cfg.blink {
		fmt.Print("\033[5m")
	}
	for i, line := range lines {
		move(y+i, x)
		fmt.Print(line)
	}
	fmt.Print("\033[0m")
	if !cfg.hideDate {
		move(y+len(lines)+1, x+max(0, (width-len(date))/2))
		fmt.Printf("\033[%dm%s\033[0m", attr, date)
	}
}

func render(s string) []string {
	out := []string{"", "", "", "", ""}
	for _, r := range s {
		part, ok := digit[r]
		if !ok {
			part = digit[' ']
		}
		for i := range out {
			out[i] += part[i] + " "
		}
	}
	return out
}

func move(r, c int) {
	fmt.Printf("\033[%d;%dH", max(1, r), max(1, c))
}

func termSize() (int, int) {
	return 80, 24
}

func dateRows(cfg config) int {
	if cfg.hideDate {
		return 0
	}
	return 2
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func strftime(t time.Time, f string) string {
	var b strings.Builder
	for i := 0; i < len(f); i++ {
		if f[i] != '%' || i+1 == len(f) {
			b.WriteByte(f[i])
			continue
		}
		i++
		switch f[i] {
		case 'Y':
			b.WriteString(t.Format("2006"))
		case 'y':
			b.WriteString(t.Format("06"))
		case 'm':
			b.WriteString(t.Format("01"))
		case 'd':
			b.WriteString(t.Format("02"))
		case 'H':
			b.WriteString(t.Format("15"))
		case 'I':
			b.WriteString(t.Format("03"))
		case 'M':
			b.WriteString(t.Format("04"))
		case 'S':
			b.WriteString(t.Format("05"))
		case 'F':
			b.WriteString(t.Format("2006-01-02"))
		case 'T':
			b.WriteString(t.Format("15:04:05"))
		case 'R':
			b.WriteString(t.Format("15:04"))
		case 'a':
			b.WriteString(t.Format("Mon"))
		case 'A':
			b.WriteString(t.Format("Monday"))
		case 'b', 'h':
			b.WriteString(t.Format("Jan"))
		case 'B':
			b.WriteString(t.Format("January"))
		case 'p':
			b.WriteString(t.Format("PM"))
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case '%':
			b.WriteByte('%')
		default:
			b.WriteByte('%')
			b.WriteByte(f[i])
		}
	}
	return b.String()
}
