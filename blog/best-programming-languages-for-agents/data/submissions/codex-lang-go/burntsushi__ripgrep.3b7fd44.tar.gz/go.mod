module cleanrg

go 1.21
