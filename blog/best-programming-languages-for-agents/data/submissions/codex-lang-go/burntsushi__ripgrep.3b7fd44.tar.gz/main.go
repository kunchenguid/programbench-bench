package main

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"
)

const version = "ripgrep 14.1.1 (rev 719e15af5e)"

type options struct {
	patterns          []string
	patternFiles      []string
	paths             []string
	ignoreCase        bool
	caseSensitive     bool
	smartCase         bool
	fixed             bool
	invert            bool
	lineRegexp        bool
	wordRegexp        bool
	lineNumber        bool
	noLineNumber      bool
	withFilename      bool
	noFilename        bool
	count             bool
	countMatches      bool
	filesWithMatches  bool
	filesWithoutMatch bool
	quiet             bool
	files             bool
	typeList          bool
	hidden            bool
	noIgnore          bool
	text              bool
	binary            bool
	null              bool
	onlyMatching      bool
	column            bool
	vimgrep           bool
	json              bool
	passthru          bool
	trim              bool
	includeZero       bool
	follow            bool
	after             int
	before            int
	maxCount          int
	maxDepth          int
	sortBy            string
	sortReverse       bool
	globs             []globRule
	typeInclude       []string
	typeExclude       []string
	replace           *string
	unrestricted      int
}

type globRule struct {
	pat     string
	include bool
}

type compiled struct {
	re       *regexp.Regexp
	literals []string
	opt      *options
	matchAll bool
}

type match struct {
	start int
	end   int
}

type result struct {
	hadMatch bool
	err      error
}

func main() {
	opt, code := parseArgs(os.Args[1:])
	if code >= 0 {
		os.Exit(code)
	}
	if opt.unrestricted >= 1 {
		opt.noIgnore = true
	}
	if opt.unrestricted >= 2 {
		opt.hidden = true
	}
	if opt.unrestricted >= 3 {
		opt.binary = true
		opt.text = true
	}
	if opt.files {
		if err := printFiles(opt); err != nil {
			fmt.Fprintf(os.Stderr, "rg: %v\n", err)
			os.Exit(2)
		}
		os.Exit(0)
	}
	if opt.typeList {
		printTypeList()
		os.Exit(0)
	}
	if len(opt.patternFiles) > 0 {
		for _, pf := range opt.patternFiles {
			lines, err := readPatternFile(pf)
			if err != nil {
				fmt.Fprintf(os.Stderr, "rg: %v\n", err)
				os.Exit(2)
			}
			opt.patterns = append(opt.patterns, lines...)
		}
	}
	if len(opt.patterns) == 0 {
		fmt.Fprintln(os.Stderr, "rg: ripgrep requires at least one pattern to execute a search")
		os.Exit(2)
	}
	comp, err := compilePatterns(opt)
	if err != nil {
		fmt.Fprintf(os.Stderr, "rg: regex parse error:\n    (?:%s)\nerror: %v\n", strings.Join(opt.patterns, "|"), err)
		os.Exit(2)
	}
	had, hadErr := runSearch(comp)
	if hadErr {
		os.Exit(2)
	}
	if had {
		os.Exit(0)
	}
	os.Exit(1)
}

func parseArgs(args []string) (*options, int) {
	opt := &options{after: -1, before: -1, maxCount: -1, maxDepth: -1}
	patternMode := false
	for i := 0; i < len(args); i++ {
		a := args[i]
		if patternMode {
			opt.paths = append(opt.paths, a)
			continue
		}
		if a == "--" {
			patternMode = true
			continue
		}
		if a == "--help" {
			printLongHelp()
			return opt, 0
		}
		if a == "-h" {
			printShortHelp()
			return opt, 0
		}
		if a == "--version" || a == "-V" {
			fmt.Println(version)
			fmt.Println()
			fmt.Println("features:-pcre2")
			fmt.Println("simd(compile):+SSE2,-SSSE3,-AVX2")
			fmt.Println("simd(runtime):+SSE2,+SSSE3,+AVX2")
			fmt.Println()
			fmt.Println("PCRE2 is not available in this build of ripgrep.")
			return opt, 0
		}
		if a == "--pcre2-version" {
			fmt.Fprintln(os.Stderr, "PCRE2 is not available in this build of ripgrep.")
			return opt, 1
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasVal := strings.Cut(a, "=")
			need := func() string {
				if hasVal {
					return val
				}
				i++
				if i >= len(args) {
					return ""
				}
				return args[i]
			}
			switch name {
			case "--regexp":
				opt.patterns = append(opt.patterns, need())
			case "--file":
				opt.patternFiles = append(opt.patternFiles, need())
			case "--ignore-case":
				opt.ignoreCase = true
			case "--case-sensitive":
				opt.caseSensitive = true
			case "--smart-case":
				opt.smartCase = true
			case "--fixed-strings":
				opt.fixed = true
			case "--invert-match":
				opt.invert = true
			case "--line-regexp":
				opt.lineRegexp = true
			case "--word-regexp":
				opt.wordRegexp = true
			case "--line-number":
				opt.lineNumber = true
			case "--no-line-number":
				opt.noLineNumber = true
			case "--with-filename":
				opt.withFilename = true
			case "--no-filename":
				opt.noFilename = true
			case "--count":
				opt.count = true
			case "--count-matches":
				opt.countMatches = true
			case "--files-with-matches":
				opt.filesWithMatches = true
			case "--files-without-match":
				opt.filesWithoutMatch = true
			case "--quiet":
				opt.quiet = true
			case "--files":
				opt.files = true
			case "--type-list":
				opt.typeList = true
			case "--hidden":
				opt.hidden = true
			case "--no-ignore", "--no-ignore-vcs", "--no-ignore-dot", "--no-ignore-parent", "--no-require-git":
				opt.noIgnore = true
			case "--text":
				opt.text = true
			case "--binary":
				opt.binary = true
			case "--null":
				opt.null = true
			case "--only-matching":
				opt.onlyMatching = true
			case "--column":
				opt.column = true
			case "--vimgrep":
				opt.vimgrep = true
			case "--json":
				opt.json = true
			case "--passthru", "--passthrough":
				opt.passthru = true
			case "--trim":
				opt.trim = true
			case "--include-zero":
				opt.includeZero = true
			case "--follow":
				opt.follow = true
			case "--after-context":
				opt.after = atoi(need(), 0)
			case "--before-context":
				opt.before = atoi(need(), 0)
			case "--context":
				n := atoi(need(), 0); opt.after = n; opt.before = n
			case "--max-count":
				opt.maxCount = atoi(need(), -1)
			case "--max-depth":
				opt.maxDepth = atoi(need(), -1)
			case "--sort":
				opt.sortBy = need()
			case "--sortr":
				opt.sortBy = need(); opt.sortReverse = true
			case "--sort-files":
				opt.sortBy = "path"
			case "--glob":
				addGlob(opt, need())
			case "--iglob":
				addGlob(opt, need())
			case "--type":
				opt.typeInclude = append(opt.typeInclude, need())
			case "--type-not":
				opt.typeExclude = append(opt.typeExclude, need())
			case "--replace":
				s := need(); opt.replace = &s
			case "--generate":
				kind := need()
				if kind == "man" {
					printLongHelp()
				}
				return opt, 0
			default:
				if flagTakesValue(name) && !hasVal {
					_ = need()
				}
			}
			continue
		}
		if strings.HasPrefix(a, "-") && a != "-" {
			if consumeShort(opt, args, &i, a) {
				continue
			}
		}
		if len(opt.patterns) == 0 {
			opt.patterns = append(opt.patterns, a)
		} else {
			opt.paths = append(opt.paths, a)
		}
	}
	if opt.files && len(opt.patterns) > 0 {
		opt.paths = append(opt.patterns, opt.paths...)
		opt.patterns = nil
	}
	return opt, -1
}

func consumeShort(opt *options, args []string, i *int, a string) bool {
	s := a[1:]
	next := func(rest string) string {
		if rest != "" {
			return rest
		}
		*i++
		if *i >= len(args) {
			return ""
		}
		return args[*i]
	}
	for j := 0; j < len(s); j++ {
		c := s[j]
		rest := s[j+1:]
		switch c {
		case 'e':
			opt.patterns = append(opt.patterns, next(rest)); return true
		case 'f':
			opt.patternFiles = append(opt.patternFiles, next(rest)); return true
		case 'i':
			opt.ignoreCase = true
		case 's':
			opt.caseSensitive = true
		case 'S':
			opt.smartCase = true
		case 'F':
			opt.fixed = true
		case 'v':
			opt.invert = true
		case 'x':
			opt.lineRegexp = true
		case 'w':
			opt.wordRegexp = true
		case 'n':
			opt.lineNumber = true
		case 'N':
			opt.noLineNumber = true
		case 'H':
			opt.withFilename = true
		case 'I':
			opt.noFilename = true
		case 'c':
			opt.count = true
		case 'l':
			opt.filesWithMatches = true
		case 'q':
			opt.quiet = true
		case '0':
			opt.null = true
		case 'o':
			opt.onlyMatching = true
		case '.':
			opt.hidden = true
		case 'u':
			opt.unrestricted++
		case 'a':
			opt.text = true
		case 'L':
			opt.follow = true
		case 'A':
			opt.after = atoi(next(rest), 0); return true
		case 'B':
			opt.before = atoi(next(rest), 0); return true
		case 'C':
			n := atoi(next(rest), 0); opt.after = n; opt.before = n; return true
		case 'm':
			opt.maxCount = atoi(next(rest), -1); return true
		case 'd':
			opt.maxDepth = atoi(next(rest), -1); return true
		case 'g':
			addGlob(opt, next(rest)); return true
		case 't':
			opt.typeInclude = append(opt.typeInclude, next(rest)); return true
		case 'T':
			opt.typeExclude = append(opt.typeExclude, next(rest)); return true
		case 'r':
			v := next(rest); opt.replace = &v; return true
		case 'p':
			opt.lineNumber = true
		case 'P', 'U', 'z':
		default:
			return false
		}
	}
	return true
}

func flagTakesValue(name string) bool {
	for _, n := range []string{"--pre", "--pre-glob", "--encoding", "--engine", "--dfa-size-limit", "--regex-size-limit", "--threads", "--max-filesize", "--ignore-file", "--type-add", "--type-clear", "--color", "--colors", "--max-columns", "--path-separator", "--context-separator", "--field-context-separator", "--field-match-separator", "--hyperlink-format", "--hostname-bin"} {
		if name == n {
			return true
		}
	}
	return false
}

func atoi(s string, def int) int {
	n, err := strconv.Atoi(s)
	if err != nil {
		return def
	}
	return n
}

func addGlob(opt *options, g string) {
	if strings.HasPrefix(g, "!") {
		opt.globs = append(opt.globs, globRule{pat: g[1:], include: false})
	} else {
		opt.globs = append(opt.globs, globRule{pat: g, include: true})
	}
}

func readPatternFile(path string) ([]string, error) {
	var data []byte
	var err error
	if path == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(path)
	}
	if err != nil {
		return nil, err
	}
	parts := strings.Split(strings.ReplaceAll(string(data), "\r\n", "\n"), "\n")
	if len(parts) > 0 && parts[len(parts)-1] == "" {
		parts = parts[:len(parts)-1]
	}
	return parts, nil
}

func compilePatterns(opt *options) (*compiled, error) {
	pats := make([]string, len(opt.patterns))
	copy(pats, opt.patterns)
	matchAll := false
	for _, p := range pats {
		if p == "" {
			matchAll = true
		}
	}
	useIgnore := opt.ignoreCase
	if opt.smartCase && !opt.caseSensitive {
		useIgnore = true
		for _, p := range pats {
			for _, r := range p {
				if unicode.IsUpper(r) {
					useIgnore = false
					break
				}
			}
		}
	}
	if opt.caseSensitive {
		useIgnore = false
	}
	if opt.fixed {
		for i := range pats {
			pats[i] = regexp.QuoteMeta(pats[i])
		}
	}
	for i := range pats {
		if opt.wordRegexp {
			pats[i] = `\b(?:` + pats[i] + `)\b`
		}
		if opt.lineRegexp {
			pats[i] = `^(?:` + pats[i] + `)$`
		}
	}
	expr := strings.Join(pats, "|")
	if useIgnore {
		expr = "(?i:" + expr + ")"
	}
	re, err := regexp.Compile(expr)
	if err != nil {
		return nil, err
	}
	lits := []string(nil)
	if opt.fixed {
		lits = opt.patterns
	}
	return &compiled{re: re, literals: lits, opt: opt, matchAll: matchAll}, nil
}

func runSearch(comp *compiled) (bool, bool) {
	opt := comp.opt
	if len(opt.paths) == 0 && stdinHasData() {
		res := searchReader(comp, "-", os.Stdin, false, false)
		return res.hadMatch, res.err != nil
	}
	paths := opt.paths
	displayRoots := opt.paths
	if len(paths) == 0 {
		paths = []string{"."}
		displayRoots = nil
	}
	files, err := collectFiles(paths, opt)
	if err != nil {
		fmt.Fprintf(os.Stderr, "rg: %v\n", err)
		return false, true
	}
	if opt.sortBy == "path" || opt.sortBy == "" {
		if opt.sortBy == "path" {
			sort.Strings(files)
		}
	}
	if opt.sortReverse {
		for i, j := 0, len(files)-1; i < j; i, j = i+1, j-1 {
			files[i], files[j] = files[j], files[i]
		}
	}
	multi := shouldShowFilename(paths, files, opt)
	had := false
	hadErr := false
	for _, f := range files {
		var file *os.File
		var err error
		if f == "-" {
			file = os.Stdin
		} else {
			file, err = os.Open(f)
		}
		if err != nil {
			if !opt.quiet {
				fmt.Fprintf(os.Stderr, "%s: %v\n", f, err)
			}
			hadErr = true
			continue
		}
		res := searchReader(comp, displayForPaths(f, displayRoots), file, multi, true)
		if f != "-" {
			_ = file.Close()
		}
		if res.err != nil {
			hadErr = true
		}
		if res.hadMatch {
			had = true
			if opt.quiet {
				return true, false
			}
		}
	}
	if opt.json {
		printJSON("summary", map[string]any{"stats": map[string]any{}})
	}
	return had, hadErr
}

func stdinHasData() bool {
	st, err := os.Stdin.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) == 0
}

func shouldShowFilename(paths, files []string, opt *options) bool {
	if opt.noFilename {
		return false
	}
	if opt.withFilename || opt.vimgrep {
		return true
	}
	if len(paths) == 0 {
		return true
	}
	if len(paths) > 1 || len(files) > 1 {
		return true
	}
	if len(paths) == 1 {
		if st, err := os.Stat(paths[0]); err == nil && st.IsDir() {
			return true
		}
	}
	return false
}

func searchReader(comp *compiled, path string, r io.Reader, showFile bool, namedFile bool) result {
	opt := comp.opt
	if opt.json && namedFile {
		printJSON("begin", map[string]any{"path": dataObj(path)})
	}
	br := bufio.NewReader(r)
	var beforeRing []lineRec
	var afterLeft int
	var countLines, countMatches, printedMatches int
	var lineNo int
	var byteOff int
	had := false
	for {
		raw, err := br.ReadBytes('\n')
		if len(raw) > 0 {
			lineNo++
			lineStart := byteOff
			byteOff += len(raw)
			line := strings.TrimSuffix(strings.TrimSuffix(string(raw), "\n"), "\r")
			if !opt.text && !opt.binary && bytes.IndexByte(raw, 0) >= 0 {
				return result{hadMatch: false}
			}
			ms := lineMatches(comp, line)
			matched := len(ms) > 0
			if opt.invert {
				matched = !matched
				if matched {
					ms = []match{{0, len(line)}}
				}
			}
			if opt.passthru || matched {
				if matched {
					had = true
					countLines++
					countMatches += len(ms)
				}
				if opt.quiet && matched {
					return result{hadMatch: true}
				}
				if matched && opt.maxCount >= 0 && printedMatches >= opt.maxCount {
					continue
				}
				if matched {
					printedMatches++
				}
				if !opt.count && !opt.countMatches && !opt.filesWithMatches && !opt.filesWithoutMatch {
					if matched && opt.before > 0 {
						for _, rec := range beforeRing {
							printLine(opt, path, showFile, rec.no, rec.text, nil, false, rec.off)
						}
						beforeRing = nil
					}
					printLine(opt, path, showFile, lineNo, line, ms, matched, lineStart)
					if matched && opt.after > 0 {
						afterLeft = opt.after
					}
				}
			} else if afterLeft > 0 && !opt.count && !opt.countMatches && !opt.filesWithMatches && !opt.filesWithoutMatch {
				printLine(opt, path, showFile, lineNo, line, nil, false, lineStart)
				afterLeft--
			}
			if opt.before > 0 && !matched {
				beforeRing = append(beforeRing, lineRec{lineNo, line, lineStart})
				if len(beforeRing) > opt.before {
					beforeRing = beforeRing[1:]
				}
			}
			if matched && opt.maxCount >= 0 && printedMatches >= opt.maxCount {
				break
			}
		}
		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}
			return result{hadMatch: had, err: err}
		}
	}
	if opt.count || opt.countMatches {
		n := countLines
		if opt.countMatches || opt.onlyMatching {
			n = countMatches
		}
		if n > 0 || opt.includeZero {
			prefixPath(opt, path, showFile)
			fmt.Println(n)
		}
	}
	if opt.filesWithMatches && had {
		printPath(opt, path)
	}
	if opt.filesWithoutMatch && !had {
		printPath(opt, path)
	}
	if opt.json && namedFile && had {
		printJSON("end", map[string]any{"path": dataObj(path), "stats": map[string]any{}})
	}
	return result{hadMatch: had}
}

type lineRec struct {
	no   int
	text string
	off  int
}

func lineMatches(comp *compiled, line string) []match {
	if comp.matchAll {
		return []match{{0, len(line)}}
	}
	locs := comp.re.FindAllStringIndex(line, -1)
	ms := make([]match, 0, len(locs))
	for _, loc := range locs {
		if loc[0] == loc[1] {
			continue
		}
		ms = append(ms, match{loc[0], loc[1]})
	}
	return ms
}

func printLine(opt *options, path string, showFile bool, lineNo int, line string, ms []match, matched bool, byteOff int) {
	if opt.trim {
		line = strings.TrimLeft(line, " \t\r\n")
	}
	if opt.json && matched {
		subs := []map[string]any{}
		for _, m := range ms {
			subs = append(subs, map[string]any{"match": dataObj(line[m.start:m.end]), "start": m.start, "end": m.end})
		}
		printJSON("match", map[string]any{"path": dataObj(path), "lines": dataObj(line + "\n"), "line_number": lineNo, "absolute_offset": byteOff, "submatches": subs})
		return
	}
	if opt.onlyMatching && matched {
		for _, m := range ms {
			out := line[m.start:m.end]
			if opt.replace != nil {
				out = expandReplace(*opt.replace, line, ms, m)
			}
			printPrefix(opt, path, showFile, lineNo, m.start+1)
			fmt.Println(out)
		}
		return
	}
	if opt.replace != nil && matched {
		line = compReplace(line, ms, *opt.replace)
	}
	if opt.vimgrep && matched {
		for _, m := range ms {
			fmt.Printf("%s:%d:%d:%s\n", path, lineNo, m.start+1, line)
		}
		return
	}
	printPrefix(opt, path, showFile, lineNo, firstCol(ms))
	fmt.Println(line)
}

func firstCol(ms []match) int {
	if len(ms) == 0 {
		return 0
	}
	return ms[0].start + 1
}

func printPrefix(opt *options, path string, showFile bool, lineNo, col int) {
	if showFile {
		fmt.Print(path, ":")
	}
	if opt.lineNumber && !opt.noLineNumber {
		fmt.Print(lineNo, ":")
	}
	if opt.column {
		if col <= 0 {
			col = 1
		}
		fmt.Print(col, ":")
	}
}

func prefixPath(opt *options, path string, showFile bool) {
	if showFile {
		fmt.Print(path, ":")
	}
}

func printPath(opt *options, path string) {
	if opt.null {
		fmt.Print(path, "\x00")
	} else {
		fmt.Println(path)
	}
}

func compReplace(line string, ms []match, repl string) string {
	var b strings.Builder
	last := 0
	for _, m := range ms {
		b.WriteString(line[last:m.start])
		b.WriteString(expandReplace(repl, line, ms, m))
		last = m.end
	}
	b.WriteString(line[last:])
	return b.String()
}

func expandReplace(repl, line string, all []match, cur match) string {
	repl = strings.ReplaceAll(repl, "$$", "\x00")
	repl = strings.ReplaceAll(repl, "$0", line[cur.start:cur.end])
	repl = strings.ReplaceAll(repl, "${0}", line[cur.start:cur.end])
	return strings.ReplaceAll(repl, "\x00", "$")
}

func collectFiles(paths []string, opt *options) ([]string, error) {
	var out []string
	ignore := loadIgnores(paths, opt)
	for _, p := range paths {
		if p == "-" {
			out = append(out, p)
			continue
		}
		st, err := os.Stat(p)
		if err != nil {
			return out, err
		}
		if !st.IsDir() {
			if includeFile(p, opt, ignore, true, 0) {
				out = append(out, p)
			}
			continue
		}
		root := p
		err = filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if path == root {
				return nil
			}
			relDepth := depth(root, path)
			name := d.Name()
			if d.IsDir() {
				if opt.maxDepth >= 0 && relDepth > opt.maxDepth {
					return filepath.SkipDir
				}
				if !opt.hidden && strings.HasPrefix(name, ".") {
					return filepath.SkipDir
				}
				if !opt.noIgnore && ignore.ignored(path, true) {
					return filepath.SkipDir
				}
				return nil
			}
			if includeFile(path, opt, ignore, false, relDepth) {
				out = append(out, path)
			}
			return nil
		})
		if err != nil {
			return out, err
		}
	}
	return out, nil
}

func depth(root, path string) int {
	rel, err := filepath.Rel(root, path)
	if err != nil || rel == "." {
		return 0
	}
	return strings.Count(rel, string(os.PathSeparator)) + 1
}

func includeFile(path string, opt *options, ig ignoreSet, explicit bool, dep int) bool {
	base := filepath.Base(path)
	if !explicit && !opt.hidden && strings.HasPrefix(base, ".") {
		return false
	}
	if !explicit && opt.maxDepth >= 0 && dep > opt.maxDepth {
		return false
	}
	if !explicit && !opt.noIgnore && ig.ignored(path, false) {
		return false
	}
	if len(opt.globs) > 0 && !matchGlobRules(path, opt.globs) {
		return false
	}
	if len(opt.typeInclude) > 0 {
		ok := false
		for _, t := range opt.typeInclude {
			if typeMatch(path, t) {
				ok = true
			}
		}
		if !ok {
			return false
		}
	}
	for _, t := range opt.typeExclude {
		if typeMatch(path, t) {
			return false
		}
	}
	return true
}

type ignoreSet []string

func loadIgnores(paths []string, opt *options) ignoreSet {
	if opt.noIgnore {
		return nil
	}
	seen := map[string]bool{}
	var dirs []string
	for _, p := range paths {
		d := p
		if st, err := os.Stat(p); err == nil && !st.IsDir() {
			d = filepath.Dir(p)
		}
		for {
			if !seen[d] {
				seen[d] = true
				dirs = append(dirs, d)
			}
			parent := filepath.Dir(d)
			if parent == d {
				break
			}
			if _, err := os.Stat(filepath.Join(d, ".git")); err == nil {
				break
			}
			d = parent
		}
	}
	var pats []string
	for _, d := range dirs {
		for _, name := range []string{".rgignore", ".ignore", ".gitignore"} {
			data, err := os.ReadFile(filepath.Join(d, name))
			if err != nil {
				continue
			}
			for _, line := range strings.Split(string(data), "\n") {
				line = strings.TrimSpace(line)
				if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
					continue
				}
				pats = append(pats, line)
			}
		}
	}
	return ignoreSet(pats)
}

func (ig ignoreSet) ignored(path string, isDir bool) bool {
	slash := filepath.ToSlash(path)
	base := filepath.Base(path)
	for _, pat := range ig {
		p := strings.TrimSuffix(pat, "/")
		if strings.Contains(p, "/") {
			if globMatch(p, slash) || strings.HasSuffix(slash, "/"+p) {
				return true
			}
		} else if globMatch(p, base) || p == base {
			return true
		}
	}
	return false
}

func matchGlobRules(path string, rules []globRule) bool {
	included := false
	hasInclude := false
	s := filepath.ToSlash(path)
	base := filepath.Base(path)
	for _, r := range rules {
		if r.include {
			hasInclude = true
		}
		if globMatch(r.pat, s) || globMatch(r.pat, base) {
			included = r.include
		}
	}
	if hasInclude {
		return included
	}
	return !included
}

func globMatch(pat, s string) bool {
	pat = filepath.ToSlash(pat)
	if ok, _ := filepath.Match(pat, s); ok {
		return true
	}
	if !strings.Contains(pat, "/") {
		if ok, _ := filepath.Match(pat, filepath.Base(s)); ok {
			return true
		}
	}
	if strings.HasPrefix(pat, "*.") && strings.HasSuffix(s, pat[1:]) {
		return true
	}
	return false
}

func typeMatch(path, typ string) bool {
	typ = strings.TrimPrefix(typ, "-")
	ext := strings.ToLower(filepath.Ext(path))
	base := strings.ToLower(filepath.Base(path))
	switch typ {
	case "go":
		return ext == ".go"
	case "rust", "rs":
		return ext == ".rs"
	case "py", "python":
		return ext == ".py"
	case "js", "javascript":
		return ext == ".js" || ext == ".jsx" || ext == ".mjs" || ext == ".cjs"
	case "ts", "typescript":
		return ext == ".ts" || ext == ".tsx"
	case "c":
		return ext == ".c" || ext == ".h"
	case "cpp", "cc":
		return ext == ".cc" || ext == ".cpp" || ext == ".cxx" || ext == ".hpp" || ext == ".hh"
	case "md", "markdown":
		return ext == ".md" || ext == ".markdown"
	case "json":
		return ext == ".json"
	case "toml":
		return ext == ".toml" || base == "cargo.lock"
	case "sh", "shell":
		return ext == ".sh" || ext == ".bash" || ext == ".zsh"
	case "html":
		return ext == ".html" || ext == ".htm"
	case "css":
		return ext == ".css"
	case "txt", "text":
		return ext == ".txt" || ext == ".text"
	default:
		return strings.TrimPrefix(ext, ".") == typ
	}
}

func printFiles(opt *options) error {
	paths := opt.paths
	displayRoots := opt.paths
	if len(paths) == 0 {
		paths = []string{"."}
		displayRoots = nil
	}
	files, err := collectFiles(paths, opt)
	if err != nil {
		return err
	}
	if opt.sortBy == "path" {
		sort.Strings(files)
	}
	for _, f := range files {
		printPath(opt, displayForPaths(f, displayRoots))
	}
	return nil
}

func displayForPaths(p string, roots []string) string {
	d := displayPath(p)
	for _, r := range roots {
		if (r == "." || r == "./") && !strings.HasPrefix(d, "./") && !strings.HasPrefix(d, "../") && !filepath.IsAbs(d) {
			return "./" + d
		}
	}
	return d
}

func displayPath(p string) string {
	if strings.HasPrefix(p, "./") || strings.HasPrefix(p, "../") || filepath.IsAbs(p) {
		return filepath.ToSlash(p)
	}
	return filepath.ToSlash(p)
}

func dataObj(s string) map[string]string {
	if utf8.ValidString(s) {
		return map[string]string{"text": s}
	}
	return map[string]string{"bytes": base64.StdEncoding.EncodeToString([]byte(s))}
}

func printJSON(typ string, obj map[string]any) {
	obj["type"] = typ
	b, _ := json.Marshal(obj)
	fmt.Println(string(b))
}

func printTypeList() {
	lines := []string{
		"ada: *.adb, *.ads",
		"agda: *.agda, *.lagda",
		"asm: *.S, *.asm, *.s",
		"c: *.[chH], *.[chH].in",
		"cpp: *.C, *.cc, *.cpp, *.cxx, *.h, *.hpp",
		"go: *.go",
		"html: *.htm, *.html",
		"json: *.json",
		"markdown: *.markdown, *.md, *.mdown, *.mkdn",
		"python: *.py, *.pyi",
		"rust: *.rs",
		"shell: *.bash, *.sh, *.zsh",
		"toml: *.toml, Cargo.lock",
		"typescript: *.ts, *.tsx",
	}
	sort.Strings(lines)
	for _, l := range lines {
		fmt.Println(l)
	}
}

func printShortHelp() {
	fmt.Println(version)
	fmt.Println("Andrew Gallant <jamslam@gmail.com>")
	fmt.Println()
	fmt.Println("ripgrep (rg) recursively searches the current directory for lines matching")
	fmt.Println("a regex pattern. By default, ripgrep will respect gitignore rules and")
	fmt.Println("automatically skip hidden files/directories and binary files.")
	fmt.Println()
	fmt.Println("USAGE:")
	fmt.Println("  rg [OPTIONS] PATTERN [PATH ...]")
	fmt.Println()
	fmt.Println("SEARCH OPTIONS:")
	fmt.Println("  -i, --ignore-case               Case insensitive search.")
	fmt.Println("  -F, --fixed-strings             Treat all patterns as literals.")
	fmt.Println("  -v, --invert-match              Invert matching.")
	fmt.Println("  -w, --word-regexp               Show matches surrounded by word boundaries.")
	fmt.Println()
	fmt.Println("OUTPUT OPTIONS:")
	fmt.Println("  -n, --line-number               Show line numbers.")
	fmt.Println("  -H, --with-filename             Print the file path with each matching line.")
	fmt.Println("  -I, --no-filename               Never print the path with each matching line.")
	fmt.Println("  -o, --only-matching             Print only matched parts of a line.")
	fmt.Println()
	fmt.Println("OUTPUT MODES:")
	fmt.Println("  -c, --count                     Show count of matching lines for each file.")
	fmt.Println("  -l, --files-with-matches        Print the paths with at least one match.")
	fmt.Println("  --files                         Print each file that would be searched.")
	fmt.Println("  -V, --version                   Print ripgrep's version.")
}

func printLongHelp() {
	printShortHelp()
	fmt.Println()
	fmt.Println("Use -h for short descriptions and --help for more details.")
}

var _ = time.Now
