package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const version = "RustOwl v1.0.0-rc.1"
const nightly = "nightly-2025-06-20-x86_64-unknown-linux-gnu"

func main() {
	os.Exit(run(os.Args[1:]))
}

func run(args []string) int {
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, version)
		fmt.Fprintln(os.Stderr, "This is an LSP server. You can use --help flag to show help.")
		return 0
	}

	for len(args) > 0 {
		switch args[0] {
		case "-V", "--version":
			fmt.Fprintln(os.Stdout, version)
			return 0
		case "-q", "--quiet":
			args = args[1:]
			continue
		case "-qq", "-qqq":
			args = args[1:]
			continue
		case "--stdio":
			return stdio()
		case "-h", "--help":
			printRootHelp(os.Stdout)
			return 0
		}
		break
	}
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, version)
		fmt.Fprintln(os.Stderr, "This is an LSP server. You can use --help flag to show help.")
		return 0
	}

	switch args[0] {
	case "help":
		return help(args[1:])
	case "check":
		return check(args[1:])
	case "clean":
		return clean(args[1:])
	case "toolchain":
		return toolchain(args[1:])
	case "completions":
		return completions(args[1:])
	default:
		if strings.HasPrefix(args[0], "-") {
			return errUnexpected(args[0], "executable [OPTIONS] [COMMAND]", "")
		}
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[0])
		fmt.Fprintln(os.Stderr, "Usage: executable [OPTIONS] [COMMAND]\n")
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return 2
	}
}

func help(args []string) int {
	if len(args) == 0 {
		printRootHelp(os.Stdout)
		return 0
	}
	switch args[0] {
	case "check":
		printCheckHelp(os.Stdout)
	case "clean":
		printCleanHelp(os.Stdout)
	case "toolchain":
		printToolchainHelp(os.Stdout)
	case "completions":
		printCompletionsLongHelp(os.Stdout)
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[0])
		fmt.Fprintln(os.Stderr, "Usage: executable help [COMMAND]...")
		return 2
	}
	return 0
}

func check(args []string) int {
	path := ""
	afterDash := false
	for len(args) > 0 {
		a := args[0]
		args = args[1:]
		if !afterDash && a == "--" {
			afterDash = true
			continue
		}
		if !afterDash {
			switch a {
			case "-h", "--help":
				printCheckHelp(os.Stdout)
				return 0
			case "--all-targets", "--all-features":
				continue
			}
			if strings.HasPrefix(a, "-") {
				return errUnexpectedWithTip(a, "executable check [OPTIONS] [path]", fmt.Sprintf("  tip: to pass '%s' as a value, use '-- %s'\n\n", a, a))
			}
		}
		if path != "" {
			return errUnexpected(a, "executable check [OPTIONS] [path]", "")
		}
		path = a
	}
	if path == "" {
		path = "."
	}
	fmt.Fprintf(os.Stderr, "WARN  [rustowl::lsp::analyze] Invalid analysis target: %s\n", path)
	fmt.Fprintln(os.Stderr, "ERROR [rustowl] Analyze failed")
	return 1
}

func clean(args []string) int {
	if len(args) > 0 {
		if args[0] == "-h" || args[0] == "--help" {
			printCleanHelp(os.Stdout)
			return 0
		}
		return errUnexpected(args[0], "executable clean", "")
	}
	return 0
}

func toolchain(args []string) int {
	if len(args) == 0 {
		printToolchainHelp(os.Stdout)
		return 0
	}
	switch args[0] {
	case "-h", "--help":
		printToolchainHelp(os.Stdout)
		return 0
	case "help":
		if len(args) == 1 {
			printToolchainHelp(os.Stdout)
		} else if args[1] == "install" {
			printInstallHelp(os.Stdout)
		} else if args[1] == "uninstall" {
			printUninstallHelp(os.Stdout)
		} else {
			fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[1])
			fmt.Fprintln(os.Stderr, "Usage: executable toolchain help [COMMAND]...")
			return 2
		}
		return 0
	case "install":
		return install(args[1:])
	case "uninstall":
		return uninstall(args[1:])
	default:
		fmt.Fprintf(os.Stderr, "error: unrecognized subcommand '%s'\n\n", args[0])
		fmt.Fprintln(os.Stderr, "Usage: executable toolchain [COMMAND]\n")
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return 2
	}
}

func install(args []string) int {
	base := filepath.Join(os.Getenv("HOME"), ".rustowl")
	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "-h", "--help":
			printInstallHelp(os.Stdout)
			return 0
		case "--skip-rustowl-toolchain":
			continue
		case "--path":
			if i+1 >= len(args) {
				fmt.Fprintln(os.Stderr, "error: a value is required for '--path <path>' but none was supplied\n")
				fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
				return 2
			}
			i++
			base = args[i]
		default:
			if strings.HasPrefix(args[i], "-") {
				return errUnexpected(args[i], "executable toolchain install [OPTIONS]", "")
			}
			return errUnexpected(args[i], "executable toolchain install [OPTIONS]", "")
		}
	}
	_ = os.MkdirAll(filepath.Join(base, "sysroot", nightly), 0755)
	fmt.Fprintln(os.Stderr, "INFO  [rustowl::toolchain] start installing Rust toolchain...")
	fmt.Fprintf(os.Stderr, "ERROR [rustowl::toolchain] failed to download tarball\n")
	return 1
}

func uninstall(args []string) int {
	if len(args) > 0 {
		if args[0] == "-h" || args[0] == "--help" {
			printUninstallHelp(os.Stdout)
			return 0
		}
		return errUnexpected(args[0], "executable toolchain uninstall", "")
	}
	base := filepath.Join(os.Getenv("HOME"), ".rustowl", "sysroot", nightly)
	_ = os.RemoveAll(base)
	fmt.Fprintf(os.Stderr, "INFO  [rustowl::toolchain] remove sysroot: %s\n", base)
	return 0
}

func completions(args []string) int {
	if len(args) == 0 {
		fmt.Fprintln(os.Stderr, "error: the following required arguments were not provided:")
		fmt.Fprintln(os.Stderr, "  <SHELL>\n")
		fmt.Fprintln(os.Stderr, "Usage: executable completions <SHELL>\n")
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return 2
	}
	if args[0] == "-h" {
		printCompletionsShortHelp(os.Stdout)
		return 0
	}
	if args[0] == "--help" {
		printCompletionsLongHelp(os.Stdout)
		return 0
	}
	if len(args) > 1 {
		return errUnexpected(args[1], "executable completions <SHELL>", "")
	}
	switch args[0] {
	case "bash":
		fmt.Print(bashCompletion)
	case "zsh":
		fmt.Print(zshCompletion)
	case "fish":
		fmt.Print(fishCompletion)
	case "powershell":
		fmt.Print(powerCompletion)
	case "elvish":
		fmt.Print(elvishCompletion)
	case "nushell":
		fmt.Print(nushellCompletion)
	default:
		fmt.Fprintf(os.Stderr, "error: invalid value '%s' for '<SHELL>'\n", args[0])
		fmt.Fprintln(os.Stderr, "  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n")
		fmt.Fprintln(os.Stderr, "  tip: a similar value exists: 'bash'\n")
		fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
		return 2
	}
	return 0
}

func stdio() int {
	b, _ := io.ReadAll(os.Stdin)
	if len(strings.TrimSpace(string(b))) == 0 {
		return 0
	}
	req := strings.TrimSpace(string(b))
	hasHeader := strings.HasPrefix(req, "Content-Length:")
	if hasHeader {
		parts := strings.SplitN(req, "\r\n\r\n", 2)
		if len(parts) == 2 {
			req = parts[1]
		}
	}
	if !hasHeader {
		writeRPC(`{"jsonrpc":"2.0","error":{"code":-32700,"message":"Parse error"},"id":null}`)
		return 0
	}
	var js any
	if json.Unmarshal([]byte(req), &js) != nil {
		writeRPC(`{"jsonrpc":"2.0","error":{"code":-32700,"message":"Parse error"},"id":null}`)
		return 0
	}
	writeRPC(`{"jsonrpc":"2.0","error":{"code":-32600,"message":"Invalid Request"},"id":null}`)
	return 0
}

func writeRPC(s string) {
	w := bufio.NewWriter(os.Stdout)
	fmt.Fprintf(w, "Content-Length: %d\r\n\r\n%s", len(s), s)
	_ = w.Flush()
}

func errUnexpected(arg, usage, extra string) int {
	return errUnexpectedWithTip(arg, usage, extra)
}

func errUnexpectedWithTip(arg, usage, extra string) int {
	fmt.Fprintf(os.Stderr, "error: unexpected argument '%s' found\n\n", arg)
	if extra != "" {
		fmt.Fprint(os.Stderr, extra)
	}
	fmt.Fprintf(os.Stderr, "Usage: %s\n\n", usage)
	fmt.Fprintln(os.Stderr, "For more information, try '--help'.")
	return 2
}

func printRootHelp(w io.Writer) {
	fmt.Fprint(w, `Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help
`)
}

func printCheckHelp(w io.Writer) {
	fmt.Fprint(w, `Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help
`)
}

func printCleanHelp(w io.Writer) {
	fmt.Fprint(w, `Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help
`)
}

func printToolchainHelp(w io.Writer) {
	fmt.Fprint(w, `Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
`)
}

func printInstallHelp(w io.Writer) {
	fmt.Fprint(w, `Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help
`)
}

func printUninstallHelp(w io.Writer) {
	fmt.Fprint(w, `Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help
`)
}

func printCompletionsShortHelp(w io.Writer) {
	fmt.Fprint(w, `Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, powershell, zsh, nushell]

Options:
  -h, --help  Print help (see more with '--help')
`)
}

func printCompletionsLongHelp(w io.Writer) {
	fmt.Fprint(w, `Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `+"`SHell`"+` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `+"`SHell`"+` (fish)
          - powershell: `+"`PowerShell`"+`
          - zsh:        Z `+"`SHell`"+` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')
`)
}

const bashCompletion = `_rustowl() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-V --version -q --quiet --stdio -h --help check clean toolchain completions help"
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}

complete -F _rustowl -o bashdefault -o default rustowl
`

const zshCompletion = `#compdef rustowl

_rustowl() {
    local -a commands
    commands=(check:'Check availability' clean:'Remove artifacts from the target directory' toolchain:'Install or uninstall the toolchain' completions:'Generate shell completions' help:'Print this message or the help of the given subcommand(s)')
    _describe 'command' commands
}

_rustowl "$@"
`

const fishCompletion = `# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rustowl_global_optspecs
	string join \n V/version q/quiet stdio h/help
end

complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -s h -l help -d 'Print help'
complete -c rustowl -f -a "check" -d 'Check availability'
complete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -f -a "completions" -d 'Generate shell completions'
complete -c rustowl -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rustowl -n "__fish_seen_subcommand_from check" -l all-targets -d 'Run the check for all targets instead of current only'
complete -c rustowl -n "__fish_seen_subcommand_from check" -l all-features -d 'Run the check for all features instead of the current active ones only'
`

const powerCompletion = `
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    [CompletionResult]::new('check', 'check', [CompletionResultType]::ParameterValue, 'Check availability')
    [CompletionResult]::new('clean', 'clean', [CompletionResultType]::ParameterValue, 'Remove artifacts from the target directory')
    [CompletionResult]::new('toolchain', 'toolchain', [CompletionResultType]::ParameterValue, 'Install or uninstall the toolchain')
    [CompletionResult]::new('completions', 'completions', [CompletionResultType]::ParameterValue, 'Generate shell completions')
}
`

const elvishCompletion = `
use builtin;
use str;

set edit:completion:arg-completer[rustowl] = {|@words|
    edit:complex-candidate check &display='check          Check availability'
    edit:complex-candidate clean &display='clean          Remove artifacts from the target directory'
    edit:complex-candidate toolchain &display='toolchain      Install or uninstall the toolchain'
    edit:complex-candidate completions &display='completions    Generate shell completions'
}
`

const nushellCompletion = `module completions {

  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]

  # Check availability
  export extern "rustowl check" [
    --all-targets             # Run the check for all targets instead of current only
    --all-features            # Run the check for all features instead of the current active ones only
    --help(-h)                # Print help
    path?: path               # The path of a file or directory to check availability
  ]
}
`
