module rustowl-reimplementation

go 1.21
