module eureka

go 1.21
