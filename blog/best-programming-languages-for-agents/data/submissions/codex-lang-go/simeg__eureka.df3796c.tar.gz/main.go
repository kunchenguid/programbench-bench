package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

const version = "2.0.0"

type config struct {
	Repo string `json:"repo"`
}

func main() {
	code := run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	os.Exit(code)
}

func run(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	switch {
	case len(args) == 0:
		c, err := loadConfig()
		if err != nil {
			if isNotExist(err) {
				firstSetup(stdin, stdout, stderr)
				return 0
			}
			printErr(stderr, err)
			return 0
		}
		capture(c.Repo, stdin, stdout, stderr)
		return 0
	case len(args) == 1 && (args[0] == "--help" || args[0] == "-h"):
		fmt.Fprint(stdout, helpText())
		return 0
	case len(args) == 1 && (args[0] == "--version" || args[0] == "-V"):
		fmt.Fprintf(stdout, "eureka %s\n", version)
		return 0
	case len(args) == 1 && (args[0] == "--clear-config"):
		if err := os.Remove(configPath()); err != nil {
			printErr(stderr, err)
		}
		return 0
	case len(args) == 1 && (args[0] == "--view" || args[0] == "-v"):
		c, err := loadConfig()
		if err != nil {
			printErr(stderr, err)
			return 0
		}
		view(c.Repo, stderr)
		return 0
	default:
		arg := ""
		if len(args) > 0 {
			arg = args[0]
		}
		fmt.Fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", arg)
		return 2
	}
}

func helpText() string {
	return `Input and store your ideas without leaving the terminal

Usage: executable [OPTIONS]

Options:
      --clear-config  Clear your stored configuration
  -v, --view          View ideas with your $PAGER env variable. If unset use less
  -h, --help          Print help
  -V, --version       Print version
`
}

func firstSetup(stdin io.Reader, stdout, stderr io.Writer) {
	fmt.Fprint(stdout, "\033[0m\033[33m############################################################\n")
	fmt.Fprint(stdout, "####                  First Time Setup                  ####\n")
	fmt.Fprint(stdout, "############################################################\n\n")
	fmt.Fprint(stdout, "This tool requires you to have a repository with a README.md\n")
	fmt.Fprint(stdout, "in the root folder. The markdown file is where your ideas\n")
	fmt.Fprint(stdout, "will be stored.\n\n")
	fmt.Fprint(stdout, "Once first time setup has completed, simply run Eureka again\n")
	fmt.Fprint(stdout, "to begin writing down ideas.\n        \n\033[0m")

	sc := bufio.NewScanner(stdin)
	for {
		fmt.Fprint(stdout, "\033[0m\033[1m\033[32mAbsolute path to your idea repo\n\033[0m> ")
		if !sc.Scan() {
			continue
		}
		path := strings.TrimSpace(sc.Text())
		if !filepath.IsAbs(path) {
			fmt.Fprint(stdout, "\033[0m\033[31mPath must be absolute\n\033[0m")
			continue
		}
		if err := saveConfig(config{Repo: path}); err != nil {
			printErr(stderr, err)
			return
		}
		fmt.Fprintln(stdout, "First time setup complete. Happy ideation!")
		return
	}
}

func capture(repo string, stdin io.Reader, stdout, stderr io.Writer) {
	fmt.Fprint(stdout, "\033[0m\033[1m\033[32m>> Idea summary\n\033[0m> ")
	reader := bufio.NewReader(stdin)
	summary, _ := reader.ReadString('\n')
	summary = strings.TrimRight(summary, "\r\n")
	if summary == "" {
		for {
			fmt.Fprint(stdout, "\033[0m\033[1m\033[32m>> Idea summary\n\033[0m> ")
			line, _ := reader.ReadString('\n')
			summary = strings.TrimRight(line, "\r\n")
			if summary != "" {
				break
			}
			if line == "" {
				continue
			}
		}
	}

	readme := filepath.Join(repo, "README.md")
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = "vim"
	}
	if err := runInteractive(editor, []string{readme}); err != nil {
		printErr(stderr, err)
		return
	}

	fmt.Fprintln(stdout, "Adding and committing your new idea to main..")
	if err := git(repo, "add", "README.md"); err != nil {
		printErr(stderr, err)
		return
	}
	// The reference creates a commit even when the editor leaves README.md unchanged.
	if err := git(repo, "commit", "--allow-empty", "-m", summary); err != nil {
		printErr(stderr, err)
		return
	}
	fmt.Fprintln(stdout, "Added and committed!")
	fmt.Fprintln(stdout, "Pushing your new idea..")
	if err := git(repo, "remote", "get-url", "origin"); err != nil {
		printErr(stderr, errors.New("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)"))
		return
	}
	if err := git(repo, "push", "origin", "main"); err != nil {
		printErr(stderr, err)
		return
	}
}

func view(repo string, stderr io.Writer) {
	pager := os.Getenv("PAGER")
	if pager == "" {
		pager = "less"
	}
	if err := runInteractive(pager, []string{filepath.Join(repo, "README.md")}); err != nil {
		printErr(stderr, err)
	}
}

func runInteractive(name string, args []string) error {
	cmd := exec.Command(name, args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func git(repo string, args ...string) error {
	all := append([]string{"-C", repo}, args...)
	cmd := exec.Command("git", all...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		msg := strings.TrimSpace(string(out))
		if msg == "" {
			msg = err.Error()
		}
		return errors.New(msg)
	}
	return nil
}

func loadConfig() (config, error) {
	var c config
	b, err := os.ReadFile(configPath())
	if err != nil {
		return c, err
	}
	err = json.Unmarshal(b, &c)
	return c, err
}

func saveConfig(c config) error {
	path := configPath()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	b, err := json.Marshal(c)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

func configPath() string {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		home = "."
	}
	return filepath.Join(home, ".config", "eureka", "config.json")
}

func isNotExist(err error) bool {
	return errors.Is(err, os.ErrNotExist)
}

func printErr(w io.Writer, err error) {
	if err == nil {
		return
	}
	if isNotExist(err) {
		fmt.Fprintln(w, " ERROR eureka > No such file or directory (os error 2)")
		return
	}
	fmt.Fprintf(w, " ERROR eureka > %s\n", err.Error())
}
