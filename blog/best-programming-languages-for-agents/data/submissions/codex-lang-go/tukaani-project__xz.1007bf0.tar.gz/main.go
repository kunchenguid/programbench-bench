package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"hash/crc32"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const versionText = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"

type config struct {
	mode         string
	keep         bool
	force        bool
	stdout       bool
	quiet        int
	verbose      int
	preset       uint32
	extreme      bool
	suffix       string
	format       string
	check        byte
	ignoreCheck  bool
	singleStream bool
	robot        bool
	filesFrom    []string
	nullFiles    bool
	noWarn       bool
	args         []string
}

func main() {
	os.Exit(run(os.Args))
}

func run(argv []string) int {
	cfg := config{mode: "compress", preset: 6, suffix: ".xz", format: "auto", check: 4}
	if base := filepath.Base(argv[0]); base == "unxz" {
		cfg.mode = "decompress"
	} else if base == "xzcat" {
		cfg.mode, cfg.stdout = "decompress", true
	} else if base == "lzma" {
		cfg.format = "lzma"
	} else if base == "unlzma" {
		cfg.mode, cfg.format = "decompress", "lzma"
	} else if base == "lzcat" {
		cfg.mode, cfg.format, cfg.stdout = "decompress", "lzma", true
	}

	if code, done := parseArgs(argv[1:], &cfg); done {
		return code
	}
	if len(cfg.args) == 0 && len(cfg.filesFrom) == 0 {
		cfg.args = []string{"-"}
	}
	if cfg.stdout {
		cfg.keep = true
	}
	status := 0
	for _, list := range cfg.filesFrom {
		names, err := readNameList(list, cfg.nullFiles)
		if err != nil {
			xzerr(cfg, "%s: %v\n", displayName(list), err)
			status = maxStatus(status, 1)
			continue
		}
		cfg.args = append(cfg.args, names...)
	}
	for _, name := range cfg.args {
		if err := process(name, cfg); err != nil {
			var w warning
			if errors.As(err, &w) {
				xzwarn(cfg, "%s\n", w.Error())
				status = maxStatus(status, 2)
			} else {
				xzerr(cfg, "%s\n", err.Error())
				status = maxStatus(status, 1)
			}
		}
	}
	if cfg.noWarn && status == 2 {
		return 0
	}
	return status
}

type warning struct{ s string }
func (w warning) Error() string { return w.s }

func parseArgs(args []string, cfg *config) (int, bool) {
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			cfg.args = append(cfg.args, args[i+1:]...)
			break
		}
		if a == "-" || !strings.HasPrefix(a, "-") {
			cfg.args = append(cfg.args, a)
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, has := strings.Cut(a[2:], "=")
			need := func() string {
				if has { return val }
				if i+1 < len(args) { i++; return args[i] }
				xzerr(*cfg, "%s: Option requires an argument\n", a)
				return ""
			}
			switch name {
			case "compress": cfg.mode = "compress"
			case "decompress", "uncompress": cfg.mode = "decompress"
			case "test": cfg.mode = "test"
			case "list": cfg.mode = "list"
			case "keep": cfg.keep = true
			case "force": cfg.force = true
			case "stdout", "to-stdout": cfg.stdout = true
			case "quiet": cfg.quiet++
			case "verbose": cfg.verbose++
			case "extreme": cfg.extreme = true
			case "robot": cfg.robot = true
			case "no-warn": cfg.noWarn = true
			case "single-stream": cfg.singleStream = true
			case "ignore-check": cfg.ignoreCheck = true
			case "no-sync", "no-sparse":
			case "help": shortHelp(); return 0, true
			case "long-help": longHelp(); return 0, true
			case "version": fmt.Print(versionText); return 0, true
			case "info-memory": infoMemory(); return 0, true
			case "filters-help": filtersHelp(); return 0, true
			case "suffix": cfg.suffix = need()
			case "format":
				v := need(); if !oneOf(v, "auto", "xz", "lzma", "lzip", "raw") { xzerr(*cfg, "%s: Unknown file format type\n", v); return 1, true }; cfg.format = v
			case "check":
				v := need(); c, ok := parseCheck(v); if !ok { xzerr(*cfg, "%s: Unsupported integrity check type\n", v); return 1, true }; cfg.check = c
			case "threads":
				v := need()
				if !isDecimal(v) { xzerr(*cfg, "%s: Value is not a non-negative decimal integer\n", v); return 1, true }
			case "block-size", "block-list", "flush-timeout", "memlimit-compress", "memlimit-decompress", "memlimit-mt-decompress", "memlimit", "filters", "filters1", "filters2", "filters3", "filters4", "filters5", "filters6", "filters7", "filters8", "filters9", "lzma1", "lzma2", "x86", "arm", "armthumb", "arm64", "powerpc", "ia64", "sparc", "riscv", "delta":
				if !has && optionNeedsValue(name) { _ = need() }
			case "files":
				if has { cfg.filesFrom = append(cfg.filesFrom, val) } else { cfg.filesFrom = append(cfg.filesFrom, "-") }
				cfg.nullFiles = false
			case "files0":
				if has { cfg.filesFrom = append(cfg.filesFrom, val) } else { cfg.filesFrom = append(cfg.filesFrom, "-") }
				cfg.nullFiles = true
			default:
				xzerr(*cfg, "unrecognized option '--%s'\n", name)
				xzerr(*cfg, "Try '%s --help' for more information.\n", os.Args[0])
				return 1, true
			}
			continue
		}
		for j := 1; j < len(a); j++ {
			ch := a[j]
			switch ch {
			case 'z': cfg.mode = "compress"
			case 'd': cfg.mode = "decompress"
			case 't': cfg.mode = "test"
			case 'l': cfg.mode = "list"
			case 'k': cfg.keep = true
			case 'f': cfg.force = true
			case 'c': cfg.stdout = true
			case 'q': cfg.quiet++
			case 'v': cfg.verbose++
			case 'e': cfg.extreme = true
			case 'h': shortHelp(); return 0, true
			case 'H': longHelp(); return 0, true
			case 'V': fmt.Print(versionText); return 0, true
			case 'Q': cfg.noWarn = true
			case '0','1','2','3','4','5','6','7','8','9': cfg.preset = uint32(ch - '0')
			case 'T','S','F','C','M':
				var val string
				if j+1 < len(a) { val = a[j+1:]; j = len(a) } else if i+1 < len(args) { i++; val = args[i] } else { xzerr(*cfg, "%s: Option requires an argument\n", string(ch)); return 1, true }
				switch ch {
				case 'S': cfg.suffix = val
				case 'F': if !oneOf(val, "auto", "xz", "lzma", "lzip", "raw") { xzerr(*cfg, "%s: Unknown file format type\n", val); return 1, true }; cfg.format = val
				case 'C': c, ok := parseCheck(val); if !ok { xzerr(*cfg, "%s: Unsupported integrity check type\n", val); return 1, true }; cfg.check = c
				case 'T':
					if !isDecimal(val) { xzerr(*cfg, "%s: Value is not a non-negative decimal integer\n", val); return 1, true }
				case 'M':
				}
			default:
				xzerr(*cfg, "Invalid option '-%c'\n", ch)
				return 1, true
			}
		}
	}
	if cfg.extreme {
		cfg.preset |= 1 << 31
	}
	return 0, false
}

func optionNeedsValue(name string) bool {
	switch name {
	case "lzma1", "lzma2", "x86", "arm", "armthumb", "arm64", "powerpc", "ia64", "sparc", "riscv", "delta":
		return false
	}
	return true
}

func process(name string, cfg config) error {
	switch cfg.mode {
	case "compress":
		return compressFile(name, cfg)
	case "decompress":
		return decompressFile(name, cfg, false)
	case "test":
		return decompressFile(name, cfg, true)
	case "list":
		return listFile(name, cfg)
	}
	return nil
}

func compressFile(name string, cfg config) error {
	in, err := readInput(name)
	if err != nil { return err }
	out, err := xzCompress(in, cfg.preset, cfg.check)
	if err != nil { return fmt.Errorf("%s: %v", displayName(name), err) }
	if cfg.stdout || name == "-" {
		_, err = os.Stdout.Write(out)
		return err
	}
	if strings.HasSuffix(name, cfg.suffix) {
		return warning{fmt.Sprintf("%s: File already has '%s' suffix, skipping", name, cfg.suffix)}
	}
	outname := name + cfg.suffix
	if err := writeOutput(outname, out, cfg.force); err != nil { return err }
	if !cfg.keep { _ = os.Remove(name) }
	return nil
}

func decompressFile(name string, cfg config, test bool) error {
	in, err := readInput(name)
	if err != nil { return err }
	out, err := xzDecompress(in, cfg.ignoreCheck, cfg.singleStream)
	if err != nil { return fmt.Errorf("%s: %v", displayName(name), err) }
	if test { return nil }
	if cfg.stdout || name == "-" {
		_, err = os.Stdout.Write(out)
		return err
	}
	outname := ""
	if strings.HasSuffix(name, cfg.suffix) {
		outname = strings.TrimSuffix(name, cfg.suffix)
	} else if strings.HasSuffix(name, ".txz") {
		outname = strings.TrimSuffix(name, ".txz") + ".tar"
	} else {
		return warning{fmt.Sprintf("%s: Filename has an unknown suffix, skipping", name)}
	}
	if err := writeOutput(outname, out, cfg.force); err != nil { return err }
	if !cfg.keep { _ = os.Remove(name) }
	return nil
}

func listFile(name string, cfg config) error {
	if name == "-" { return fmt.Errorf("--list does not support reading from standard input") }
	in, err := os.ReadFile(name)
	if err != nil { return err }
	out, err := xzDecompress(in, cfg.ignoreCheck, false)
	if err != nil { return fmt.Errorf("%s: %v", name, err) }
	if cfg.robot {
		fmt.Printf("name\t%s\nfile\t1\t1\t%d\t%d\t0\tCRC64\t0\n", name, len(in), len(out))
		return nil
	}
	fmt.Println("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename")
	ratio := "---"
	if len(out) > 0 {
		ratio = fmt.Sprintf("%.3f", float64(len(in))/float64(len(out)))
	}
	fmt.Printf("%5d %7d %10s %12s %6s  %-6s  %s\n", 1, 1, humanBytes(len(in)), humanBytes(len(out)), ratio, "CRC64", name)
	return nil
}

func readInput(name string) ([]byte, error) {
	if name == "-" { return io.ReadAll(os.Stdin) }
	return os.ReadFile(name)
}

func writeOutput(name string, data []byte, force bool) error {
	if !force {
		if _, err := os.Stat(name); err == nil {
			return fmt.Errorf("%s: File exists", name)
		}
	}
	return os.WriteFile(name, data, 0644)
}

func xzCompress(in []byte, preset uint32, check byte) ([]byte, error) {
	if check != 0 && check != 1 && check != 4 {
		check = 4
	}
	lz := encodeLZMA2Plain(in)
	header := []byte{0xFD, '7', 'z', 'X', 'Z', 0x00, 0x00, check}
	header = appendCRC32(header, header[6:8])

	blockHeader := buildBlockHeader(uint64(len(lz)), uint64(len(in)))
	block := append([]byte{}, blockHeader...)
	block = append(block, lz...)
	checkSize := 0
	switch check {
	case 1:
		checkSize = 4
	case 4:
		checkSize = 8
	}
	for len(block)%4 != 0 {
		block = append(block, 0)
	}
	unpadded := len(blockHeader) + len(lz) + checkSize
	switch check {
	case 1:
		block = appendCRC32(block, in)
	case 4:
		block = appendUint64LE(block, crc64xz(in))
	}

	index := []byte{0x00}
	index = appendVLI(index, 1)
	index = appendVLI(index, uint64(unpadded))
	index = appendVLI(index, uint64(len(in)))
	for len(index)%4 != 0 {
		index = append(index, 0)
	}
	index = appendCRC32(index, index)

	footerBody := make([]byte, 6)
	backward := uint32(len(index)/4 - 1)
	binary.LittleEndian.PutUint32(footerBody[0:4], backward)
	footerBody[4], footerBody[5] = 0, check
	footer := appendCRC32(nil, footerBody)
	footer = append(footer, footerBody...)
	footer = append(footer, 'Y', 'Z')

	out := append(header, block...)
	out = append(out, index...)
	out = append(out, footer...)
	return out, nil
}

func encodeLZMA2Plain(in []byte) []byte {
	var out []byte
	first := true
	for len(in) > 0 {
		n := len(in)
		if n > 65536 {
			n = 65536
		}
		if first {
			out = append(out, 0x01)
			first = false
		} else {
			out = append(out, 0x02)
		}
		v := n - 1
		out = append(out, byte(v>>8), byte(v))
		out = append(out, in[:n]...)
		in = in[n:]
	}
	out = append(out, 0x00)
	return out
}

func buildBlockHeader(comp, uncomp uint64) []byte {
	h := []byte{0, 0xC0} // one filter, compressed and uncompressed sizes present
	h = appendVLI(h, comp)
	h = appendVLI(h, uncomp)
	h = appendVLI(h, 0x21) // LZMA2
	h = appendVLI(h, 1)
	h = append(h, 22) // 8 MiB dictionary property
	for (len(h)+4)%4 != 0 {
		h = append(h, 0)
	}
	h[0] = byte((len(h)+4)/4 - 1)
	return appendCRC32(h, h)
}

func xzDecompress(in []byte, ignore, single bool) ([]byte, error) {
	_ = single
	if len(in) < 32 || !bytes.Equal(in[:6], []byte{0xFD, '7', 'z', 'X', 'Z', 0x00}) {
		return nil, errors.New("File format not recognized")
	}
	pos := 12
	check := in[7]
	var out []byte
	for {
		if pos >= len(in) {
			return nil, errors.New("Unexpected end of input")
		}
		if in[pos] == 0x00 {
			break
		}
		if pos+4 > len(in) {
			return nil, errors.New("Unexpected end of input")
		}
		hs := (int(in[pos]) + 1) * 4
		if pos+hs > len(in) || crc32.ChecksumIEEE(in[pos:pos+hs-4]) != binary.LittleEndian.Uint32(in[pos+hs-4:pos+hs]) {
			return nil, errors.New("Compressed data is corrupt")
		}
		p := pos + 2
		flags := in[pos+1]
		if flags&0x03 != 0 || flags&0x3C != 0 {
			return nil, errors.New("Unsupported options")
		}
		var compSize, uncompSize uint64
		var err error
		if flags&0x40 != 0 {
			compSize, p, err = readVLI(in, p, pos+hs-4); if err != nil { return nil, err }
		}
		if flags&0x80 != 0 {
			uncompSize, p, err = readVLI(in, p, pos+hs-4); if err != nil { return nil, err }
		}
		fid, np, err := readVLI(in, p, pos+hs-4); if err != nil { return nil, err }
		p = np
		propsLen, np, err := readVLI(in, p, pos+hs-4); if err != nil { return nil, err }
		p = np + int(propsLen)
		if fid != 0x21 || p > pos+hs-4 {
			return nil, errors.New("Unsupported options")
		}
		dataStart := pos + hs
		if compSize == 0 {
			return nil, errors.New("Unsupported options")
		}
		dataEnd := dataStart + int(compSize)
		if dataEnd > len(in) {
			return nil, errors.New("Unexpected end of input")
		}
		chunk, err := decodeLZMA2Plain(in[dataStart:dataEnd])
		if err != nil {
			return nil, err
		}
		if uncompSize != 0 && uint64(len(chunk)) != uncompSize {
			return nil, errors.New("Compressed data is corrupt")
		}
		out = append(out, chunk...)
		pos = dataEnd
		for pos%4 != 0 {
			if pos >= len(in) || in[pos] != 0 { return nil, errors.New("Compressed data is corrupt") }
			pos++
		}
		switch check {
		case 0:
		case 1:
			if pos+4 > len(in) { return nil, errors.New("Unexpected end of input") }
			if !ignore && crc32.ChecksumIEEE(chunk) != binary.LittleEndian.Uint32(in[pos:pos+4]) { return nil, errors.New("Compressed data is corrupt") }
			pos += 4
		case 4:
			if pos+8 > len(in) { return nil, errors.New("Unexpected end of input") }
			if !ignore && crc64xz(chunk) != binary.LittleEndian.Uint64(in[pos:pos+8]) { return nil, errors.New("Compressed data is corrupt") }
			pos += 8
		default:
			return nil, errors.New("Unsupported options")
		}
		for pos%4 != 0 {
			pos++
		}
	}
	return out, nil
}

func decodeLZMA2Plain(b []byte) ([]byte, error) {
	var out []byte
	pos := 0
	for {
		if pos >= len(b) { return nil, errors.New("Unexpected end of input") }
		c := b[pos]; pos++
		if c == 0 { return out, nil }
		if c != 0x01 && c != 0x02 {
			return nil, errors.New("Unsupported options")
		}
		if pos+2 > len(b) { return nil, errors.New("Unexpected end of input") }
		n := int(b[pos])<<8 | int(b[pos+1]); pos += 2; n++
		if pos+n > len(b) { return nil, errors.New("Unexpected end of input") }
		out = append(out, b[pos:pos+n]...)
		pos += n
	}
}

func readNameList(file string, nul bool) ([]string, error) {
	var b []byte
	var err error
	if file == "-" { b, err = io.ReadAll(os.Stdin) } else { b, err = os.ReadFile(file) }
	if err != nil { return nil, err }
	sep := byte('\n'); if nul { sep = 0 }
	parts := bytes.Split(b, []byte{sep})
	var out []string
	for _, p := range parts {
		if len(p) > 0 { out = append(out, string(p)) }
	}
	return out, nil
}

func parseCheck(v string) (byte, bool) {
	switch v {
	case "none": return 0, true
	case "crc32": return 1, true
	case "crc64": return 4, true
	case "sha256": return 10, true
	}
	return 0, false
}

func appendCRC32(dst, data []byte) []byte {
	var b [4]byte
	binary.LittleEndian.PutUint32(b[:], crc32.ChecksumIEEE(data))
	return append(dst, b[:]...)
}

func appendUint64LE(dst []byte, v uint64) []byte {
	var b [8]byte
	binary.LittleEndian.PutUint64(b[:], v)
	return append(dst, b[:]...)
}

func appendVLI(dst []byte, v uint64) []byte {
	for {
		c := byte(v & 0x7F)
		v >>= 7
		if v != 0 {
			c |= 0x80
		}
		dst = append(dst, c)
		if v == 0 {
			return dst
		}
	}
}

func readVLI(b []byte, pos, end int) (uint64, int, error) {
	var v uint64
	shift := uint(0)
	for pos < end {
		c := b[pos]
		pos++
		v |= uint64(c&0x7F) << shift
		if c&0x80 == 0 {
			return v, pos, nil
		}
		shift += 7
		if shift >= 63 {
			return 0, pos, errors.New("Compressed data is corrupt")
		}
	}
	return 0, pos, errors.New("Unexpected end of input")
}

var crc64Table = makeCRC64Table()

func makeCRC64Table() [256]uint64 {
	const poly = uint64(0xC96C5795D7870F42)
	var t [256]uint64
	for i := range t {
		r := uint64(i)
		for j := 0; j < 8; j++ {
			if r&1 != 0 {
				r = (r >> 1) ^ poly
			} else {
				r >>= 1
			}
		}
		t[i] = r
	}
	return t
}

func crc64xz(b []byte) uint64 {
	crc := ^uint64(0)
	for _, x := range b {
		crc = crc64Table[byte(crc)^x] ^ (crc >> 8)
	}
	return ^crc
}

func oneOf(v string, opts ...string) bool {
	for _, o := range opts { if v == o { return true } }
	return false
}

func isDecimal(v string) bool {
	if v == "" { return false }
	for _, r := range v {
		if r < '0' || r > '9' { return false }
	}
	return true
}

func maxStatus(a, b int) int {
	if a == 1 || b == 1 { return 1 }
	if a > b { return a }
	return b
}

func displayName(n string) string {
	if n == "-" { return "(stdin)" }
	return n
}

func xzerr(cfg config, f string, args ...any) {
	if cfg.quiet >= 2 { return }
	fmt.Fprintf(os.Stderr, "%s: ", os.Args[0])
	fmt.Fprintf(os.Stderr, f, args...)
}

func xzwarn(cfg config, f string, args ...any) {
	if cfg.quiet >= 1 { return }
	fmt.Fprintf(os.Stderr, "%s: ", os.Args[0])
	fmt.Fprintf(os.Stderr, f, args...)
}

func humanBytes(n int) string {
	if n < 10000 { return fmt.Sprintf("%d B", n) }
	units := []string{"KiB", "MiB", "GiB"}
	f := float64(n)
	for _, u := range units {
		f /= 1024
		if f < 10000 { return fmt.Sprintf("%.1f %s", f, u) }
	}
	return strconv.Itoa(n) + " B"
}

func shortHelp() {
	fmt.Printf(`Usage: %s [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
`, os.Args[0])
}

func longHelp() { shortHelp() }

func filtersHelp() {
	fmt.Print(`Filter chains are set using the --filters=FILTERS or --filters1=FILTERS ...
--filters9=FILTERS options. Each filter in the chain can be separated by
spaces or '--'. Alternatively a preset <0-9>[e] can be specified instead of
a filter chain.

The supported filters and their options are:
lzma2:preset=<0-9[e]>,dict=<4KiB-1536MiB>,lc=<0-4>,lp=<0-4>,pb=<0-4>,mode=<fast|normal>,nice=<2-273>,mf=<hc3|hc4|bt2|bt3|bt4>,depth=<0-4294967295>
x86:start=<0-4294967295>
arm:start=<0-4294967295>
armthumb:start=<0-4294967295>
arm64:start=<0-4294967295>
riscv:start=<0-4294967295>
powerpc:start=<0-4294967295>
ia64:start=<0-4294967295>
sparc:start=<0-4294967295>
delta:dist=<1-256>
`)
}

func infoMemory() {
	fmt.Print(`Hardware information:
  Amount of physical memory (RAM):  32045 MiB (33601298432 B)
  Number of processor threads:      12

Memory usage limits:
  Compression:                      Disabled
  Decompression:                    Disabled
  Multi-threaded decompression:     8012 MiB (8400324608 B)
  Default for -T0:                  8012 MiB (8400324608 B)
`)
}
