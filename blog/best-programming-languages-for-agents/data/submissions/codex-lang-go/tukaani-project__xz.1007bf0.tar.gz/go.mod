module reimpl

go 1.21
