package main

import (
    "fmt"
    "os"
    "strings"
)

const version = "2027.0-dev-20260414-24ac8ab-unknown"
const sha = "24ac8abecd15814143951f211394c29bdfc42e13"

var commands = []struct{ name, desc string }{
    {"anaeig", "Analyze eigenvectors/normal modes"}, {"analyze", "Analyze data sets"}, {"angle", "Calculate distributions and correlations for angles and dihedrals"},
    {"awh", "Extract data from an accelerated weight histogram (AWH) run"}, {"bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"},
    {"bundle", "Analyze bundles of axes, e.g., helices"}, {"check", "Check and compare files"}, {"chi", "Calculate everything you want to know about chi and other dihedrals"},
    {"cluster", "Cluster structures"}, {"clustsize", "Calculate size distributions of atomic clusters"}, {"confrms", "Fit two structures and calculates the RMSD"},
    {"convert-tpr", "Make a modified run-input file"}, {"convert-trj", "Converts between different trajectory types"}, {"covar", "Calculate and diagonalize the covariance matrix"},
    {"current", "Calculate dielectric constants and current autocorrelation function"}, {"density", "Calculate the density of the system"}, {"densmap", "Calculate 2D planar or axial-radial density maps"},
    {"densorder", "Calculate surface fluctuations"}, {"dielectric", "Calculate frequency dependent dielectric constants"}, {"dipoles", "Compute the total dipole plus fluctuations"},
    {"disre", "Analyze distance restraints"}, {"distance", "Calculate distances between pairs of positions"}, {"dos", "Analyze density of states and properties based on that"},
    {"dssp", "Calculate protein secondary structure via DSSP algorithm"}, {"dump", "Make binary files human readable"}, {"dyecoupl", "Extract dye dynamics from trajectories"},
    {"editconf", "Convert and manipulates structure files"}, {"eneconv", "Convert energy files"}, {"enemat", "Extract an energy matrix from an energy file"},
    {"energy", "Writes energies to xvg files and display averages"}, {"extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"},
    {"filter", "Frequency filter trajectories, useful for making smooth movies"}, {"freevolume", "Calculate free volume"}, {"gangle", "Calculate angles"},
    {"genconf", "Multiply a conformation in 'random' orientations"}, {"genion", "Generate monoatomic ions on energetically favorable positions"},
    {"genrestr", "Generate position restraints or distance restraints for index groups"}, {"grompp", "Make a run input file"}, {"gyrate", "Calculate radius of gyration of a molecule"},
    {"gyrate-legacy", "Calculate the radius of gyration"}, {"h2order", "Compute the orientation of water molecules"}, {"hbond", "Compute and analyze hydrogen bonds."},
    {"hbond-legacy", "Compute and analyze hydrogen bonds"}, {"helix", "Calculate basic properties of alpha helices"}, {"helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"},
    {"help", "Print help information"}, {"hydorder", "Compute tetrahedrality parameters around a given atom"}, {"insert-molecules", "Insert molecules into existing vacancies"},
    {"lie", "Estimate free energy from linear combinations"}, {"make_edi", "Generate input files for essential dynamics sampling"}, {"make_ndx", "Make index files"},
    {"mdmat", "Calculate residue contact maps"}, {"mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"}, {"mindist", "Calculate the minimum distance between two groups"},
    {"mk_angndx", "Generate index files for 'gmx angle'"}, {"msd", "Compute mean squared displacements"}, {"nmeig", "Diagonalize the Hessian for normal mode analysis"},
    {"nmens", "Generate an ensemble of structures from the normal modes"}, {"nmr", "Analyze nuclear magnetic resonance properties from an energy file"},
    {"nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"}, {"nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."},
    {"order", "Compute the order parameter per atom for carbon tails"}, {"pairdist", "Calculate pairwise distances between groups of positions"},
    {"pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"}, {"pme_error", "Estimate the error of using PME with a given input file"},
    {"polystat", "Calculate static properties of polymers"}, {"potential", "Calculate the electrostatic potential across the box"}, {"principal", "Calculate principal axes of inertia for a group of atoms"},
    {"rama", "Compute Ramachandran plots"}, {"rdf", "Calculate radial distribution functions"}, {"report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."},
    {"rms", "Calculate RMSDs with a reference structure and RMSD matrices"}, {"rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"}, {"rmsf", "Calculate atomic fluctuations"},
    {"rotacf", "Calculate the rotational correlation function for molecules"}, {"rotmat", "Plot the rotation matrix for fitting to a reference structure"}, {"saltbr", "Compute salt bridges"},
    {"sans-legacy", "Compute small angle neutron scattering spectra"}, {"sasa", "Compute solvent accessible surface area"}, {"saxs-legacy", "Compute small angle X-ray scattering spectra"},
    {"scattering", "Calculate small angle scattering profiles for SANS or SAXS"}, {"select", "Print general information about selections"},
    {"sham", "Compute free energies or other histograms from histograms"}, {"sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"},
    {"solvate", "Solvate a system"}, {"sorient", "Analyze solvent orientation around solutes"}, {"spatial", "Calculate the spatial distribution function"},
    {"spol", "Analyze solvent dipole orientation and polarization around solutes"}, {"tcaf", "Calculate viscosities of liquids"},
    {"traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"}, {"trajectory", "Print coordinates, velocities, and/or forces for selections"},
    {"trjcat", "Concatenate trajectory files"}, {"trjconv", "Convert and manipulates trajectory files"}, {"trjorder", "Order molecules according to their distance to a group"},
    {"tune_pme", "Time mdrun as a function of PME ranks to optimize settings"}, {"vanhove", "Compute Van Hove displacement and correlation functions"},
    {"velacc", "Calculate velocity autocorrelation functions"}, {"wham", "Perform weighted histogram analysis after umbrella sampling"}, {"wheel", "Plot helical wheels"},
    {"x2top", "Generate a primitive topology from coordinates"}, {"xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"},
}

func main() {
    args := os.Args[1:]
    quiet := false
    copyright := false
    showHelp := false
    showVersion := false
    i := 0
    for i < len(args) {
        a := args[i]
        if a == "-quiet" || a == "--quiet" { quiet = true; i++; continue }
        if a == "-noquiet" { quiet = false; i++; continue }
        if a == "-h" { showHelp = true; i++; continue }
        if a == "-noh" { i++; continue }
        if a == "-version" || a == "--version" { showVersion = true; i++; continue }
        if a == "-copyright" { copyright = true; i++; continue }
        if a == "-nice" && i+1 < len(args) { i += 2; continue }
        if a == "-backup" || a == "-nobackup" { i++; continue }
        break
    }
    rest := args[i:]
    if !quiet { banner(commandTitle(rest), args) }
    if copyright { printCopyright() }
    if showVersion { printVersion(); return }
    if len(rest) == 0 || showHelp { printGlobalHelp(); if !quiet { quote() }; return }
    if rest[0] == "--help" { invalidOption("executable", "--help"); os.Exit(1) }
    if rest[0] == "help" { handleHelp(rest[1:]); if !quiet { quote() }; return }
    cmd := rest[0]
    if !known(cmd) { unknownCommand(cmd); os.Exit(1) }
    for _, a := range rest[1:] { if a == "--help" { invalidOption("gmx "+cmd, "--help"); os.Exit(1) } }
    if has(rest[1:], "-h") { printCommandHelp(cmd); if !quiet { quote() }; return }
    runCommand(cmd, rest[1:])
}

func known(c string) bool { for _, x := range commands { if x.name == c { return true } }; return false }
func desc(c string) string { for _, x := range commands { if x.name == c { return x.desc } }; return "" }
func has(xs []string, s string) bool { for _, x := range xs { if x == s { return true } }; return false }

func commandTitle(rest []string) string {
    if len(rest) > 0 && rest[0] == "help" { return "gmx help" }
    if len(rest) > 0 && known(rest[0]) { return "gmx " + rest[0] }
    return "executable"
}

func banner(title string, args []string) {
    wd, _ := os.Getwd()
    fmt.Printf("       :-) GROMACS - %s, %s (-:\n\n", title, version)
    fmt.Printf("Executable:   %s\nData prefix:  /usr/local/gromacs\nWorking dir:  %s\nCommand line:\n  executable", wd+"/./executable", wd)
    for _, a := range args { fmt.Printf(" %s", a) }
    fmt.Print("\n\n")
}

func quote() { fmt.Print("\nGROMACS reminds you: \"You're Insignificant\" (Tricky)\n\n") }

func printGlobalHelp() { fmt.Print(`SYNOPSIS

gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]
    [-[no]backup]

OPTIONS

Other options:

 -[no]h                     (no)
           Print help and quit
 -[no]quiet                 (no)
           Do not print common startup info or quotes
 -[no]version               (no)
           Print extended version information and quit
 -[no]copyright             (no)
           Print copyright information on startup
 -nice   <int>              (19)
           Set the nicelevel (default depends on command)
 -[no]backup                (yes)
           Write backups if output files exist

Additional help is available on the following topics:
    commands    List of available commands
    selections  Selection syntax and usage
To access the help, use 'gmx help <topic>'.
For help on a command, use 'gmx help <command>'.
`) }

func printVersion() { fmt.Printf(`GROMACS version:     %s
GIT SHA1 hash:       %s
Branched from:       unknown
Precision:           mixed
Memory model:        64 bit
MPI library:         thread_mpi
MPI version:         built in
OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)
GPU support:         disabled
SIMD instructions:   None
CPU FFT library:     fftw-3.3.10
GPU FFT library:     none
Multi-GPU FFT:       none
RDTSCP:              enabled
TNG support:         enabled
Hwloc support:       disabled
Tracing support:     disabled
Colvars support:     enabled (version 2025-10-13)
CP2K support:        disabled
Torch support:       disabled
Plumed support:      enabled
C compiler:          /usr/bin/cc GNU 11.4.0
C++ compiler:        /usr/bin/c++ GNU 11.4.0
BLAS library:        Internal
LAPACK library:      Internal

`, version, sha) }

func printCopyright() { fmt.Print(`Copyright 1991-2027 The GROMACS Authors.
GROMACS is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.

                         Current GROMACS contributors:
       Mark Abraham           Andrey Alekseenko           Brian Andrews
        Paul Bauer              Cathrine Bergh              Hugh Bird
      Eliane Briand               Ania Brown                Yiqi Chen
                           Berk Hess and Erik Lindahl

`) }

func handleHelp(args []string) {
    if len(args) == 0 { printGlobalHelp(); return }
    switch args[0] {
    case "commands": printCommands()
    case "selections": printSelections()
    default:
        if known(args[0]) { printCommandHelp(args[0]) } else { fmt.Printf("No help available for '%s'\n", args[0]) }
    }
}

func printCommands() {
    fmt.Print("LIST OF AVAILABLE COMMANDS\n\nUsage: gmx [<options>] <command> [<args>]\n\nAvailable commands:\n")
    for _, c := range commands { fmt.Printf("    %-20s %s\n", c.name, c.desc) }
    fmt.Print("For help on a command, use 'gmx help <command>'.\n")
}

func printSelections() { fmt.Print(`SELECTION SYNTAX AND USAGE

Selections are used to select atoms/molecules/residues for analysis. In
contrast to traditional index files, selections can be dynamic, i.e., select
different atoms for different trajectory frames. The GROMACS manual contains a
short introductory section to selections in the Analysis chapter, including
suggestions on how to get familiar with selections if you are new to the
concept. The subtopics listed below provide more details on the technical and
syntactic aspects of selections.

Available subtopics:
    arithmetic   Arithmetic expressions in selections
    cmdline      Specifying selections from command line
    evaluation   Selection evaluation and optimization
    examples     Selection examples
    keywords     Selection keywords
    limitations  Selection limitations
    positions    Specifying positions in selections
    syntax       Selection syntax
`) }

func printCommandHelp(cmd string) {
    switch cmd { case "mdrun": printMdrunHelp(); case "grompp": printGromppHelp(); default: printGenericHelp(cmd) }
}

func printMdrunHelp() { fmt.Print(`SYNOPSIS

gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]
          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]
          [-multidir [<dir> [...]]] [-awh [<.xvg>]] [-plumed [<.dat>]]
          [-membed [<.dat>]] [-mp [<.top>]] [-mn [<.ndx>]]
          [-o [<.trr/.cpt/...>]] [-x [<.xtc/.tng>]] [-cpo [<.cpt>]]
          [-c [<.gro/.g96/...>]] [-e [<.edr>]] [-g [<.log>]] [-dhdl [<.xvg>]]
          [-deffnm <string>] [-nt <int>] [-ntmpi <int>] [-ntomp <int>]
          [-[no]v] [-[no]reprod] [-cpt <real>] [-[no]append] [-nsteps <int>]

DESCRIPTION

gmx mdrun is the main computational chemistry engine within GROMACS. It
performs Molecular Dynamics simulations, Energy Minimization, test particle
insertion or recalculation of energies. The mdrun program reads the run input
file (-s) and produces trajectory, structure, energy and log files.

OPTIONS

Options to specify input files:

 -s      [<.tpr>]           (topol.tpr)
           Portable xdr run input file
 -cpi    [<.cpt>]           (state.cpt)      (Opt.)
           Checkpoint file

Options to specify output files:

 -o      [<.trr/.cpt/...>]  (traj.trr)
           Full precision trajectory: trr cpt tng h5md
 -x      [<.xtc/.tng>]      (traj_comp.xtc)  (Opt.)
           Compressed trajectory (tng format or portable xdr format)
 -c      [<.gro/.g96/...>]  (confout.gro)
           Structure file: gro g96 pdb brk ent esp
 -e      [<.edr>]           (ener.edr)
           Energy file
 -g      [<.log>]           (md.log)
           Log file

Other options:

 -deffnm <string>
           Set the default filename for all file options
 -nt     <int>              (0)
           Total number of threads to start (0 is guess)
 -[no]v                     (no)
           Be loud and noisy
 -nsteps <int>              (-2)
           Run this number of steps (-1 means infinite, -2 means use mdp option)
`) }

func printGromppHelp() { fmt.Print(`SYNOPSIS

gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]
           [-n [<.ndx>]] [-p [<.top>]] [-t [<.trr/.cpt/...>]] [-e [<.edr>]]
           [-po [<.mdp>]] [-pp [<.top>]] [-o [<.tpr>]] [-[no]v]
           [-time <real>] [-[no]rmvsbds] [-maxwarn <int>] [-[no]zero]
           [-[no]renum]

DESCRIPTION

gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks
the validity of the file, expands the topology from a molecular description to
an atomic description, and produces a portable binary run input file for mdrun.

OPTIONS

Options to specify input files:

 -f      [<.mdp>]           (grompp.mdp)
           grompp input file with MD parameters
 -c      [<.gro/.g96/...>]  (conf.gro)
           Structure file: gro g96 pdb brk ent esp tpr
 -p      [<.top>]           (topol.top)
           Topology file

Options to specify output files:

 -po     [<.mdp>]           (mdout.mdp)
           grompp input file with MD parameters
 -pp     [<.top>]           (processed.top)  (Opt.)
           Topology file
 -o      [<.tpr>]           (topol.tpr)
           Portable xdr run input file

Other options:

 -[no]v                     (no)
           Be loud and noisy
 -maxwarn <int>             (0)
           Number of allowed warnings during input processing
`) }

func printGenericHelp(cmd string) {
    fmt.Printf("SYNOPSIS\n\ngmx %s [<options>]\n\nDESCRIPTION\n\ngmx %s: %s.\n\nOPTIONS\n\nOther options:\n\n -[no]h                     (no)\n           Print help and quit\n", cmd, cmd, desc(cmd))
}

func runCommand(cmd string, args []string) {
    switch cmd {
    case "mdrun":
        if !optionHasValue(args, "-s") && !existsAny("topol", []string{".tpr"}) { missingFile("gmx mdrun", "s", "topol", []string{".tpr"}); os.Exit(1) }
        fmt.Println("This GROMACS-compatible cleanroom executable provides command-line help and validation only.")
    case "grompp":
        if !optionHasValue(args, "-f") && !existsAny("grompp", []string{".mdp"}) { missingFile("gmx grompp", "f", "grompp", []string{".mdp"}); os.Exit(1) }
        out := valueAfter(args, "-o", "topol.tpr"); _ = os.WriteFile(out, []byte("cleanroom grompp placeholder\n"), 0644); fmt.Printf("Generated %s\n", out)
    default:
        fmt.Printf("GROMACS command '%s' is recognized. This cleanroom implementation supports help and basic argument validation.\n", cmd)
    }
}

func optionHasValue(args []string, opt string) bool { for i,a := range args { if a == opt && i+1 < len(args) && !strings.HasPrefix(args[i+1], "-") { return true } }; return false }
func valueAfter(args []string, opt, def string) string { for i,a := range args { if a == opt && i+1 < len(args) { return args[i+1] } }; return def }
func existsAny(base string, exts []string) bool { for _, e := range exts { if _, err := os.Stat(base+e); err == nil { return true } }; return false }

func invalidOption(program, opt string) {
    fmt.Printf(`-------------------------------------------------------
Program:     %s, version %s
Source file: src/gromacs/commandline/cmdlineparser.cpp (line 271)
Function:    void gmx::CommandLineParser::parse(int*, char**)

Error in user input:
Invalid command-line options
    Unknown command-line option %s

For more information and tips for troubleshooting, please check the GROMACS
website at https://manual.gromacs.org/current/user-guide/run-time-errors.html
-------------------------------------------------------
`, program, version, opt)
}

func unknownCommand(cmd string) { fmt.Printf(`-------------------------------------------------------
Program:     executable, version %s
Source file: src/gromacs/commandline/cmdlinemodulemanager.cpp (line 389)
Function:    gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)

Error in user input:
'%s' is not a GROMACS command.

For more information and tips for troubleshooting, please check the GROMACS
website at https://manual.gromacs.org/current/user-guide/run-time-errors.html
-------------------------------------------------------
`, version, cmd) }

func missingFile(program, opt, base string, exts []string) { fmt.Printf(`-------------------------------------------------------
Program:     %s, version %s
Source file: src/gromacs/options/options.cpp (line 184)
Function:    void gmx::internal::OptionSectionImpl::finish()

Error in user input:
Invalid input values
  In option %s
    Required option was not provided, and the default file '%s' does not
    exist or is not accessible.
    The following extensions were tried to complete the file name:
`, program, version, opt, base); for _, e := range exts { fmt.Printf("      %s\n", e) }; fmt.Print(`
For more information and tips for troubleshooting, please check the GROMACS
website at https://manual.gromacs.org/current/user-guide/run-time-errors.html
-------------------------------------------------------
`) }
