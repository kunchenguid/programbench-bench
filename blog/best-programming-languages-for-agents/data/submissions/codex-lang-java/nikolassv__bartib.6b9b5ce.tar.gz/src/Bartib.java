import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.regex.*;

public class Bartib {
    static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    static final DateTimeFormatter D = DateTimeFormatter.ISO_LOCAL_DATE;
    static final DateTimeFormatter T = DateTimeFormatter.ofPattern("HH:mm");
    static final String BOLD = "\u001b[1m", UNDER = "\u001b[4m", DIM = "\u001b[2m", IT = "\u001b[3m", RESET = "\u001b[0m";

    static class Activity {
        LocalDateTime start;
        LocalDateTime stop;
        String project;
        String desc;
        int line;
        String raw;
        boolean running() { return stop == null; }
        long minutes(LocalDateTime now) { return Duration.between(start, running() ? now : stop).toMinutes(); }
        String line() {
            if (running()) return DT.format(start) + " | " + project + " | " + desc;
            return DT.format(start) + " - " + DT.format(stop) + " | " + project + " | " + desc;
        }
    }

    static class ParseResult {
        List<Activity> acts = new ArrayList<>();
        List<String> errors = new ArrayList<>();
    }

    static class Opts {
        String file;
        String cmd;
        List<String> rest = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            int rc = new Bartib().run(args);
            if (rc != 0) System.exit(rc);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (has(args, "--version") || has(args, "-V")) { System.out.println("bartib 1.1.0"); return 0; }
        Opts opts = parseTop(args);
        if (args.length == 0 || opts.cmd == null && (has(args, "--help") || has(args, "-h"))) { helpTop(); return 0; }
        if (opts.cmd == null) { helpTop(); return 0; }
        if (opts.cmd.equals("help")) {
            if (opts.rest.isEmpty()) helpTop(); else helpCmd(opts.rest.get(0));
            return 0;
        }
        if (opts.rest.contains("--help") || opts.rest.contains("-h")) { helpCmd(opts.cmd); return 0; }
        if (opts.file == null || opts.file.isEmpty()) {
            System.err.println("Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable");
            return 1;
        }
        switch (opts.cmd) {
            case "start": return start(opts);
            case "stop": return stop(opts, false);
            case "cancel": return cancel(opts);
            case "change": return change(opts);
            case "continue": return cont(opts);
            case "current": return current(opts);
            case "last": return last(opts, false, null);
            case "projects": return projects(opts);
            case "list": return list(opts);
            case "report": return report(opts);
            case "status": return status(opts);
            case "check": return check(opts);
            case "sanity": System.out.println("No unusual activities."); return 0;
            case "search": return search(opts);
            case "edit": return edit(opts);
            default:
                System.err.println("error: Found argument '" + opts.cmd + "' which wasn't expected, or isn't valid in this context\n");
                System.err.println("USAGE:\n    executable [OPTIONS] <SUBCOMMAND>\n\nFor more information try --help");
                return 1;
        }
    }

    Opts parseTop(String[] args) {
        Opts o = new Opts();
        o.file = System.getenv("BARTIB_FILE");
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-f") || a.equals("--file")) {
                if (i + 1 < args.length) o.file = args[++i];
            } else if (o.cmd == null && !a.startsWith("-")) {
                o.cmd = a;
            } else {
                o.rest.add(a);
            }
        }
        return o;
    }

    Map<String,String> options(List<String> rest) {
        Map<String,String> m = new LinkedHashMap<>();
        for (int i=0;i<rest.size();i++) {
            String a=rest.get(i);
            if (a.startsWith("--")) {
                String k=a.substring(2);
                if (needsValue(k) && i+1<rest.size()) m.put(k, rest.get(++i)); else m.put(k, "true");
            } else if (a.startsWith("-") && a.length()>1) {
                String k=shortName(a.substring(1));
                if (needsValue(k) && i+1<rest.size()) m.put(k, rest.get(++i)); else m.put(k, "true");
            }
        }
        return m;
    }
    boolean needsValue(String k) { return Set.of("description","project","time","date","from","to","number","round","editor","d","p","t","n","e").contains(k); }
    String shortName(String s) {
        return switch(s) { case "d" -> "description"; case "p" -> "project"; case "t" -> "time"; case "n" -> "number"; case "e" -> "editor"; default -> s; };
    }
    boolean has(String[] a, String v) { for (String x:a) if (x.equals(v)) return true; return false; }

    ParseResult read(String file, boolean warn) throws IOException {
        ParseResult pr = new ParseResult();
        Path p = Paths.get(file);
        if (!Files.exists(p)) throw new IOException("Could not read from file: " + file + "\n\nCaused by:\n    No such file or directory (os error 2)");
        List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
        for (int i=0;i<lines.size();i++) {
            String line = lines.get(i);
            if (line.trim().isEmpty()) continue;
            Activity a = parseLine(line, i+1);
            if (a == null) pr.errors.add(line + "\n  -> could not parse activity (Line: " + (i+1) + ")");
            else pr.acts.add(a);
        }
        if (warn && !pr.errors.isEmpty()) {
            for (String e: pr.errors) {
                String[] parts = e.split("Line: ");
                String n = parts.length>1 ? parts[1].replace(")","") : "?";
                System.err.println("Warning: Ignoring line " + n + ". Please see `bartib check` for further information");
            }
        }
        return pr;
    }

    Activity parseLine(String line, int n) {
        Pattern finished = Pattern.compile("^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}) - (\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}) \\| (.*) \\| (.*)$");
        Pattern running = Pattern.compile("^(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}) \\| (.*) \\| (.*)$");
        try {
            Matcher m = finished.matcher(line);
            Activity a = new Activity(); a.line=n; a.raw=line;
            if (m.matches()) {
                a.start=LocalDateTime.parse(m.group(1), DT); a.stop=LocalDateTime.parse(m.group(2), DT);
                a.project=m.group(3); a.desc=m.group(4); return a;
            }
            m = running.matcher(line);
            if (m.matches()) {
                a.start=LocalDateTime.parse(m.group(1), DT); a.project=m.group(2); a.desc=m.group(3); return a;
            }
        } catch (DateTimeParseException ignored) {}
        return null;
    }

    void write(String file, List<Activity> acts) throws IOException {
        Path p = Paths.get(file);
        Path parent = p.getParent();
        if (parent != null) Files.createDirectories(parent);
        List<String> lines = new ArrayList<>();
        for (Activity a: acts) lines.add(a.line());
        Files.write(p, lines, StandardCharsets.UTF_8);
    }

    int start(Opts opts) throws Exception {
        Map<String,String> o = options(opts.rest);
        String d=o.get("description"), p=o.get("project");
        if (d==null || p==null) {
            System.err.println("error: The following required arguments were not provided:");
            if (d==null) System.err.println("    --description <DESCRIPTION>");
            if (p==null) System.err.println("    --project <PROJECT>");
            System.err.println("\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n\nFor more information try --help");
            return 1;
        }
        List<Activity> acts = safeRead(opts.file);
        LocalDateTime st = parseTime(o.get("time"));
        stopRunningAt(acts, st);
        Activity a=new Activity(); a.start=st; a.project=p; a.desc=d; acts.add(a);
        write(opts.file, acts);
        System.out.println("Started activity: \""+d+"\" ("+p+") at "+DT.format(st));
        return 0;
    }

    List<Activity> safeRead(String file) throws IOException {
        Path p=Paths.get(file);
        if (!Files.exists(p)) return new ArrayList<>();
        return read(file, false).acts;
    }

    LocalDateTime parseTime(String s) {
        LocalDate today = LocalDate.now();
        if (s == null) return LocalDateTime.now().withSecond(0).withNano(0);
        try {
            LocalTime t = LocalTime.parse(s, T);
            return LocalDateTime.of(today, t);
        } catch (Exception e) {
            System.err.println("Can not parse \""+s+"\" as time. Argument for -t/--time is ignored (input contains invalid characters)");
            return LocalDateTime.now().withSecond(0).withNano(0);
        }
    }

    void stopRunningAt(List<Activity> acts, LocalDateTime at) {
        for (Activity a: acts) if (a.running()) a.stop = at;
    }

    int stop(Opts opts, boolean silent) throws Exception {
        Map<String,String> o=options(opts.rest);
        List<Activity> acts=safeRead(opts.file);
        LocalDateTime at=parseTime(o.get("time"));
        for (Activity a: acts) if (a.running()) {
            a.stop=at;
            if (!silent) System.out.println("Stopped activity: \""+a.desc+"\" ("+a.project+") started at "+DT.format(a.start)+" ("+fmt(a.minutes(at))+")");
        }
        write(opts.file, acts);
        return 0;
    }

    int cancel(Opts opts) throws Exception {
        List<Activity> acts=safeRead(opts.file);
        List<Activity> keep=new ArrayList<>();
        for (Activity a: acts) {
            if (a.running()) System.out.println("Canceled activity: \""+a.desc+"\" ("+a.project+") started at "+DT.format(a.start));
            else keep.add(a);
        }
        write(opts.file, keep);
        return 0;
    }

    int change(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        List<Activity> acts=safeRead(opts.file);
        LocalDateTime at=parseTime(o.get("time"));
        stopRunningAt(acts, at);
        String d=o.get("description"), p=o.get("project");
        if (d != null || p != null) {
            Activity prev = latestFinished(acts);
            Activity a=new Activity(); a.start=at; a.desc=d!=null?d:(prev==null?"":prev.desc); a.project=p!=null?p:(prev==null?"":prev.project);
            acts.add(a);
            System.out.println("Changed activity: \""+a.desc+"\" ("+a.project+") started at "+DT.format(at));
        }
        write(opts.file, acts); return 0;
    }

    Activity latestFinished(List<Activity> acts) {
        for (int i=acts.size()-1;i>=0;i--) if (!acts.get(i).running()) return acts.get(i);
        return null;
    }

    int cont(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        int num=0;
        for (String r: opts.rest) if (!r.startsWith("-") && r.matches("\\d+")) num=Integer.parseInt(r);
        List<Activity> acts=safeRead(opts.file);
        LocalDateTime at=parseTime(o.get("time"));
        stopRunningAt(acts, at);
        List<Activity> uniq = recentUnique(acts);
        if (num >= uniq.size()) return 0;
        Activity src=uniq.get(num);
        Activity a=new Activity(); a.start=at; a.desc=o.getOrDefault("description", src.desc); a.project=o.getOrDefault("project", src.project);
        acts.add(a); write(opts.file, acts);
        System.out.println("Started activity: \""+a.desc+"\" ("+a.project+") at "+DT.format(at));
        return 0;
    }

    List<Activity> recentUnique(List<Activity> acts) {
        List<Activity> out=new ArrayList<>(); Set<String> seen=new HashSet<>();
        for (int i=acts.size()-1;i>=0;i--) {
            Activity a=acts.get(i); String k=a.desc+"\0"+a.project;
            if (seen.add(k)) out.add(a);
        }
        return out;
    }

    int current(Opts opts) throws Exception {
        ParseResult pr=read(opts.file, true);
        System.out.println();
        System.out.println(UNDER+"Started At      "+RESET+" "+UNDER+"Description"+RESET+" "+UNDER+"Project"+RESET+" "+UNDER+"Duration"+RESET+" ");
        LocalDateTime now=LocalDateTime.now().withSecond(0).withNano(0);
        for (Activity a: pr.acts) if (a.running())
            System.out.printf("%s %-11s %-7s %-8s %n", DT.format(a.start), a.desc, a.project, fmt(a.minutes(now)));
        System.out.println();
        return 0;
    }

    int last(Opts opts, boolean search, String term) throws Exception {
        Map<String,String> o=options(opts.rest); int n=Integer.parseInt(o.getOrDefault("number","10"));
        ParseResult pr=read(opts.file, true);
        List<Activity> uniq=recentUnique(pr.acts);
        System.out.println();
        System.out.println(UNDER+" # "+RESET+" "+UNDER+"Description"+RESET+" "+UNDER+"Project"+RESET+" ");
        int printed=0;
        for (int i=0;i<uniq.size() && printed<n;i++) {
            Activity a=uniq.get(i);
            if (search && term != null) {
                String low=term.toLowerCase(Locale.ROOT);
                if (!a.desc.toLowerCase(Locale.ROOT).contains(low) && !a.project.toLowerCase(Locale.ROOT).contains(low)) continue;
            }
            System.out.printf("[%d] %-11s %-7s %n", i, a.desc, a.project);
            printed++;
        }
        System.out.println();
        return 0;
    }

    int projects(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        ParseResult pr=read(opts.file, true);
        TreeSet<String> ps=new TreeSet<>();
        for (Activity a: pr.acts) if (!o.containsKey("current") || a.running()) ps.add(a.project);
        for (String p: ps) System.out.println(o.containsKey("no-quotes") ? p : "\""+p+"\"");
        return 0;
    }

    int list(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        ParseResult pr=read(opts.file, true);
        List<Activity> acts=filter(pr.acts, o, false);
        int n=o.containsKey("number") ? Integer.parseInt(o.get("number")) : acts.size();
        if (acts.size()>n) acts=acts.subList(acts.size()-n, acts.size());
        int round=roundMinutes(o.get("round"));
        if (o.containsKey("no_grouping")) {
            System.out.println();
            System.out.println(UNDER+"Started         "+RESET+" "+UNDER+"Stopped"+RESET+" "+UNDER+"Description"+RESET+" "+UNDER+"Project"+RESET+" "+UNDER+"Duration"+RESET+" ");
            for (Activity a: acts) printAct(a, round, true);
            System.out.println();
        } else {
            System.out.println();
            System.out.println(UNDER+"Started"+RESET+" "+UNDER+"Stopped"+RESET+" "+UNDER+"Description"+RESET+" "+UNDER+"Project"+RESET+" "+UNDER+"Duration"+RESET+" ");
            LocalDate cur=null; long day=0; List<Activity> bucket=new ArrayList<>();
            for (Activity a: acts) {
                if (cur==null) cur=a.start.toLocalDate();
                if (!a.start.toLocalDate().equals(cur)) { printBucket(cur,bucket,round); bucket.clear(); cur=a.start.toLocalDate(); }
                bucket.add(a);
            }
            if (cur!=null) printBucket(cur,bucket,round);
        }
        return 0;
    }

    void printBucket(LocalDate d, List<Activity> b, int round) {
        long sum=0; for(Activity a:b) sum+=roundedMinutes(a, round);
        System.out.println();
        System.out.println(BOLD+d+"\t"+fmt(sum)+RESET);
        for(Activity a:b) printAct(a, round, false);
    }

    void printAct(Activity a, int round, boolean withDate) {
        LocalDateTime s=round(a.start, round), e=round(a.stop, round);
        long m=Duration.between(s,e).toMinutes();
        if (withDate) System.out.printf("%s %s   %-11s %-7s %-8s %n", DT.format(s), T.format(e), a.desc, a.project, fmt(m));
        else System.out.printf("%s   %s   %-11s %-7s %-8s %n", T.format(s), T.format(e), a.desc, a.project, fmt(m));
    }

    int report(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        ParseResult pr=read(opts.file, true);
        List<Activity> acts=filter(pr.acts, o, false);
        int round=roundMinutes(o.get("round"));
        TreeMap<String,TreeMap<String,Long>> map=new TreeMap<>(); long total=0;
        for(Activity a:acts) {
            long m=roundedMinutes(a, round); total+=m;
            map.computeIfAbsent(a.project,k->new TreeMap<>()).merge(a.desc,m,Long::sum);
        }
        System.out.println();
        for (var pe: map.entrySet()) {
            long ps=pe.getValue().values().stream().mapToLong(Long::longValue).sum();
            System.out.println(BOLD+pe.getKey()+dots(pe.getKey(), fmt(ps))+" "+fmt(ps)+RESET);
            for (var de: pe.getValue().entrySet()) System.out.println("    "+de.getKey()+dots(de.getKey(), fmt(de.getValue()))+" "+fmt(de.getValue()));
            System.out.println();
        }
        System.out.println(BOLD+"Total"+dots("Total", fmt(total))+" "+fmt(total)+RESET);
        System.out.println();
        return 0;
    }

    String dots(String left, String right) {
        int n=Math.max(0, 12-left.length()-right.length());
        return ".".repeat(n);
    }

    int status(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        ParseResult pr=read(opts.file, true);
        String proj=o.getOrDefault("project", "ALL");
        System.out.print(DIM+"\n ======="+RESET+IT+" Status for "+RESET+BOLD+proj+RESET+IT+" projects "+RESET+DIM+" ======= \n"+RESET);
        LocalDateTime now=LocalDateTime.now().withSecond(0).withNano(0);
        Optional<Activity> run=pr.acts.stream().filter(Activity::running).filter(a->proj.equals("ALL")||a.project.equals(proj)).reduce((a,b)->b);
        System.out.println(DIM+IT+"\n  NOW: "+RESET+BOLD+(run.isPresent()?run.get().desc+" ("+run.get().project+")": " NO Activity")+"\n"+RESET);
        LocalDate today=LocalDate.now();
        System.out.println(IT+" "+RESET+DIM+IT+" Today......................... "+RESET+BOLD+fmt(sum(pr.acts, today, today, proj))+RESET+IT);
        LocalDate mon=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        System.out.println(RESET+IT+" "+RESET+DIM+IT+" Current week.................. "+RESET+BOLD+fmt(sum(pr.acts, mon, today, proj))+RESET+IT);
        LocalDate first=today.withDayOfMonth(1);
        System.out.println(RESET+IT+" "+RESET+DIM+IT+" Current month................. "+RESET+BOLD+fmt(sum(pr.acts, first, today, proj))+RESET+IT+"\n"+RESET);
        return 0;
    }

    long sum(List<Activity> acts, LocalDate from, LocalDate to, String proj) {
        long s=0; for(Activity a:acts) if(!a.running() && (proj.equals("ALL")||a.project.equals(proj))) {
            LocalDate d=a.start.toLocalDate(); if(!d.isBefore(from)&&!d.isAfter(to)) s+=a.minutes(LocalDateTime.now());
        } return s;
    }

    int check(Opts opts) throws Exception {
        ParseResult pr=read(opts.file, false);
        if (pr.errors.isEmpty()) System.out.println("No parsing errors.");
        else {
            System.out.println("Found "+pr.errors.size()+" line(s) with parsing errors\n");
            for(String e: pr.errors) System.out.println(e);
        }
        return 0;
    }

    int search(Opts opts) throws Exception {
        String term="";
        for (String r: opts.rest) if (!r.startsWith("-")) { term=r; break; }
        return last(opts, true, term);
    }

    int edit(Opts opts) throws Exception {
        Map<String,String> o=options(opts.rest);
        String ed=o.getOrDefault("editor", System.getenv("EDITOR"));
        if (ed==null || ed.isEmpty()) return 0;
        new ProcessBuilder(ed, opts.file).inheritIO().start().waitFor();
        return 0;
    }

    List<Activity> filter(List<Activity> acts, Map<String,String> o, boolean includeRunning) {
        LocalDate from=null,to=null,today=LocalDate.now();
        if (o.containsKey("today")) from=to=today;
        if (o.containsKey("yesterday")) from=to=today.minusDays(1);
        if (o.containsKey("date")) from=to=LocalDate.parse(o.get("date"));
        if (o.containsKey("current_week")) { from=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)); to=today; }
        if (o.containsKey("last_week")) { LocalDate mon=today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).minusWeeks(1); from=mon; to=mon.plusDays(6); }
        if (o.containsKey("from")) from=LocalDate.parse(o.get("from"));
        if (o.containsKey("to")) to=LocalDate.parse(o.get("to"));
        String project=o.get("project");
        List<Activity> out=new ArrayList<>();
        for(Activity a: acts) {
            if (a.running() && !includeRunning) continue;
            if (project!=null && !project.equals(a.project)) continue;
            LocalDate d=a.start.toLocalDate();
            if (from!=null && d.isBefore(from)) continue;
            if (to!=null && d.isAfter(to)) continue;
            out.add(a);
        }
        return out;
    }

    int roundMinutes(String r) {
        if (r==null) return 0;
        try {
            if (r.endsWith("h")) return Integer.parseInt(r.substring(0,r.length()-1))*60;
            if (r.endsWith("m")) return Integer.parseInt(r.substring(0,r.length()-1));
            return Integer.parseInt(r);
        } catch(Exception e) { return 0; }
    }
    LocalDateTime round(LocalDateTime dt, int q) {
        if (dt==null || q<=0) return dt;
        long mins=dt.toLocalDate().atStartOfDay().until(dt, java.time.temporal.ChronoUnit.MINUTES);
        long rounded=Math.round(mins/(double)q)*q;
        return dt.toLocalDate().atStartOfDay().plusMinutes(rounded);
    }
    long roundedMinutes(Activity a, int q) { return Duration.between(round(a.start,q), round(a.stop,q)).toMinutes(); }

    String fmt(long mins) {
        long h=mins/60, m=Math.abs(mins%60);
        if (h==0) return String.format("%dm", m);
        return String.format("%dh %02dm", h, m);
    }

    void helpTop() {
        System.out.println("bartib 1.1.0\nNikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>\nA simple timetracker\n\nUSAGE:\n    executable [OPTIONS] <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]\n\nSUBCOMMANDS:\n    cancel      cancels all currently running activities\n    change      changes the current activity\n    check       checks file and reports parsing errors\n    continue    continues a previous activity\n    current     lists all currently running activities\n    edit        opens the activity log in an editor\n    help        Prints this message or the help of the given subcommand(s)\n    last        displays the descriptions and projects of recent activities\n    list        list recent activities\n    projects    list all projects\n    report      reports duration of tracked activities\n    sanity      checks sanity of bartib log\n    search      search for existing descriptions and projects\n    start       starts a new activity\n    status      shows current status and time reports for today, current week, and current month\n    stop        stops all currently running activities\n\nTo get help for a specific subcommand, run `bartib [SUBCOMMAND] --help`.\nTo get started, view the `start` help with `bartib start --help`");
    }

    void helpCmd(String c) {
        switch(c) {
            case "start" -> System.out.println("executable-start \nstarts a new activity\n\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)");
            case "stop" -> System.out.println("executable-stop \nstops all currently running activities\n\nUSAGE:\n    executable stop [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -t, --time <TIME>    the time for changing the activity status (HH:MM)");
            case "cancel" -> System.out.println("executable-cancel \ncancels all currently running activities\n\nUSAGE:\n    executable cancel\n\nFLAGS:\n    -h, --help    Prints help information");
            case "change" -> System.out.println("executable-change \nchanges the current activity\n\nUSAGE:\n    executable change [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)");
            case "continue" -> System.out.println("executable-continue \ncontinues a previous activity\n\nUSAGE:\n    executable continue [OPTIONS] [NUMBER]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)\n\nARGS:\n    <NUMBER>    the number of the activity to continue (see subcommand `last`) [default: 0]");
            case "list" -> System.out.println("executable-list \nlist recent activities\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --no_grouping     do not group activities by date in list\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -n, --number <NUMBER>      maximum number of activities to display\n    -p, --project <PROJECT>    do list activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or\n                               hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)");
            case "report" -> System.out.println("executable-report \nreports duration of tracked activities\n\nUSAGE:\n    executable report [FLAGS] [OPTIONS]\n\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -p, --project <PROJECT>    do report activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or\n                               hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)");
            case "projects" -> System.out.println("executable-projects \nlist all projects\n\nUSAGE:\n    executable projects [FLAGS]\n\nFLAGS:\n    -c, --current      prints currently running projects only\n    -h, --help         Prints help information\n    -n, --no-quotes    prints projects without quotes");
            case "current" -> System.out.println("executable-current \nlists all currently running activities\n\nUSAGE:\n    executable current\n\nFLAGS:\n    -h, --help    Prints help information");
            case "last" -> System.out.println("executable-last \ndisplays the descriptions and projects of recent activities\n\nUSAGE:\n    executable last [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -n, --number <NUMBER>    maximum number of lines to display [default: 10]");
            case "search" -> System.out.println("executable-search \nsearch for existing descriptions and projects\n\nUSAGE:\n    executable search <SEARCH_TERM>\n\nFLAGS:\n    -h, --help    Prints help information\n\nARGS:\n    <SEARCH_TERM>    the search term [default: '']");
            case "status" -> System.out.println("executable-status \nshows current status and time reports for today, current week, and current month\n\nUSAGE:\n    executable status [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -p, --project <PROJECT>    show status for this project only");
            case "check" -> System.out.println("executable-check \nchecks file and reports parsing errors\n\nUSAGE:\n    executable check\n\nFLAGS:\n    -h, --help    Prints help information");
            case "sanity" -> System.out.println("executable-sanity \nchecks sanity of bartib log\n\nUSAGE:\n    executable sanity\n\nFLAGS:\n    -h, --help    Prints help information");
            case "edit" -> System.out.println("executable-edit \nopens the activity log in an editor\n\nUSAGE:\n    executable edit [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -e <editor>        the command to start your preferred text editor [env: EDITOR=]");
            default -> helpTop();
        }
    }
}
