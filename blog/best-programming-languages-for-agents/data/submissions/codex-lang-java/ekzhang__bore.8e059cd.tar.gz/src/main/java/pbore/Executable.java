package pbore;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.Base64;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class Executable {
    static final int CONTROL_PORT = 7835;
    static final String VERSION = "bore-cli 0.6.0";

    public static void main(String[] args) {
        try {
            int code = new Executable().run(args);
            if (code != 0) System.exit(code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            Throwable c = e.getCause();
            if (c != null) {
                System.err.println();
                System.err.println("Caused by:");
                System.err.println("    " + c.getMessage());
            }
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0) { printTopHelp(); return 0; }
        String a0 = args[0];
        if (a0.equals("--help") || a0.equals("-h")) { printTopHelp(); return 0; }
        if (a0.equals("--version") || a0.equals("-V")) { System.out.println(VERSION); return 0; }
        if (a0.equals("help")) {
            if (args.length > 1 && args[1].equals("local")) printLocalHelp();
            else if (args.length > 1 && args[1].equals("server")) printServerHelp();
            else printTopHelp();
            return 0;
        }
        if (a0.equals("server")) return server(Arrays.copyOfRange(args, 1, args.length));
        if (a0.equals("local")) return local(Arrays.copyOfRange(args, 1, args.length));
        System.err.println("error: unrecognized subcommand '" + a0 + "'\n");
        System.err.println("Usage: executable <COMMAND>\n");
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    void printTopHelp() {
        System.out.println("A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.\n");
        System.out.println("Usage: executable <COMMAND>\n");
        System.out.println("Commands:");
        System.out.println("  local   Starts a local proxy to the remote server");
        System.out.println("  server  Runs the remote proxy server");
        System.out.println("  help    Print this message or the help of the given subcommand(s)\n");
        System.out.println("Options:");
        System.out.println("  -h, --help     Print help");
        System.out.println("  -V, --version  Print version");
    }

    void printLocalHelp() {
        System.out.println("Starts a local proxy to the remote server\n");
        System.out.println("Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>\n");
        System.out.println("Arguments:");
        System.out.println("  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]\n");
        System.out.println("Options:");
        System.out.println("  -l, --local-host <HOST>  The local host to expose [default: localhost]");
        System.out.println("  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]");
        System.out.println("  -p, --port <PORT>        Optional port on the remote server to select [default: 0]");
        System.out.println("  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]");
        System.out.println("  -h, --help               Print help");
    }

    void printServerHelp() {
        System.out.println("Runs the remote proxy server\n");
        System.out.println("Usage: executable server [OPTIONS]\n");
        System.out.println("Options:");
        System.out.println("      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]");
        System.out.println("      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]");
        System.out.println("  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]");
        System.out.println("      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]");
        System.out.println("      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr");
        System.out.println("  -h, --help                         Print help");
    }

    int server(String[] args) throws Exception {
        int minPort = envInt("BORE_MIN_PORT", 1024);
        int maxPort = envInt("BORE_MAX_PORT", 65535);
        String secret = getenv("BORE_SECRET", null);
        String bindAddr = "0.0.0.0";
        String bindTunnels = null;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("--help")) { printServerHelp(); return 0; }
            if (a.equals("--min-port")) minPort = parseIntArg(args, ++i, a);
            else if (a.equals("--max-port")) maxPort = parseIntArg(args, ++i, a);
            else if (a.equals("-s") || a.equals("--secret")) secret = needArg(args, ++i, a);
            else if (a.equals("--bind-addr")) bindAddr = needArg(args, ++i, a);
            else if (a.equals("--bind-tunnels")) bindTunnels = needArg(args, ++i, a);
            else return unexpected(a, "server");
        }
        if (minPort > maxPort) return err("port range is empty");
        if (bindTunnels == null) bindTunnels = bindAddr;
        TunnelServer ts = new TunnelServer(bindAddr, bindTunnels, minPort, maxPort, secret);
        ts.run();
        return 0;
    }

    int local(String[] args) throws Exception {
        String localHost = "localhost";
        String to = getenv("BORE_SERVER", null);
        String secret = getenv("BORE_SECRET", "");
        int remotePort = 0;
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("--help")) { printLocalHelp(); return 0; }
            if (a.equals("-l") || a.equals("--local-host")) localHost = needArg(args, ++i, a);
            else if (a.equals("-t") || a.equals("--to")) to = needArg(args, ++i, a);
            else if (a.equals("-p") || a.equals("--port")) remotePort = parseIntArg(args, ++i, a);
            else if (a.equals("-s") || a.equals("--secret")) secret = needArg(args, ++i, a);
            else if (a.startsWith("-")) return unexpected(a, "local");
            else pos.add(a);
        }
        if (to == null || pos.isEmpty()) {
            System.err.println("error: the following required arguments were not provided:");
            if (to == null) System.err.println("  --to <TO>");
            if (pos.isEmpty()) System.err.println("  <LOCAL_PORT>");
            System.err.println("\nUsage: executable local --to <TO> <LOCAL_PORT>\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        int localPort = Integer.parseInt(pos.get(0));
        new TunnelClient(localHost, localPort, to, remotePort, secret == null ? "" : secret).run();
        return 0;
    }

    int unexpected(String a, String cmd) {
        System.err.println("error: unexpected argument '" + a + "' found\n");
        System.err.println("Usage: executable " + cmd + (cmd.equals("local") ? " --to <TO> <LOCAL_PORT>" : " [OPTIONS]") + "\n");
        System.err.println("For more information, try '--help'.");
        return 2;
    }
    int err(String msg) { System.err.println("error: " + msg + "\n"); System.err.println("Usage: bore-cli <COMMAND>\n"); System.err.println("For more information, try '--help'."); return 2; }
    static String getenv(String k, String d) { String v = System.getenv(k); return (v == null || v.isEmpty()) ? d : v; }
    static int envInt(String k, int d) { String v = System.getenv(k); return (v == null || v.isEmpty()) ? d : Integer.parseInt(v); }
    static String needArg(String[] args, int i, String opt) { if (i >= args.length) throw new IllegalArgumentException("missing value for " + opt); return args[i]; }
    static int parseIntArg(String[] args, int i, String opt) { return Integer.parseInt(needArg(args, i, opt)); }
    static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    static String unb64(String s) { return new String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8); }
    static void log(String msg) { System.err.println(msg); }

    static class TunnelServer {
        final String bindAddr, bindTunnels, secret; final int minPort, maxPort;
        final ConcurrentMap<String, Session> sessions = new ConcurrentHashMap<>();
        TunnelServer(String bindAddr, String bindTunnels, int minPort, int maxPort, String secret) { this.bindAddr=bindAddr; this.bindTunnels=bindTunnels; this.minPort=minPort; this.maxPort=maxPort; this.secret=secret == null ? "" : secret; }
        void run() throws Exception {
            try (ServerSocket control = new ServerSocket()) {
                control.setReuseAddress(true);
                control.bind(new InetSocketAddress(InetAddress.getByName(bindAddr), CONTROL_PORT));
                log("server listening addr=" + bindAddr);
                while (true) {
                    Socket s = control.accept();
                    Thread t = new Thread(() -> handle(s), "control"); t.setDaemon(false); t.start();
                }
            }
        }
        void handle(Socket s) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String line = br.readLine();
                if (line == null) { s.close(); return; }
                String[] p = line.split(" ");
                if (p.length >= 1 && p[0].equals("HELLO")) handleHello(s, p);
                else if (p.length >= 3 && p[0].equals("DATA")) handleData(s, p[1], Integer.parseInt(p[2]));
                else s.close();
            } catch (Exception e) { try { s.close(); } catch (IOException ignored) {} }
        }
        void handleHello(Socket s, String[] p) throws Exception {
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true);
            if (p.length < 3 || !"1".equals(p[1])) { pw.println("ERR bad protocol"); s.close(); return; }
            int requested = Integer.parseInt(p[2]);
            String got = p.length >= 4 ? unb64(p[3]) : "";
            if (!secret.isEmpty() && !secret.equals(got)) { pw.println("ERR authentication failed"); s.close(); return; }
            ServerSocket tunnel = openTunnel(requested);
            String token = UUID.randomUUID().toString();
            Session session = new Session(token, tunnel, pw);
            sessions.put(token, session);
            pw.println("OK " + tunnel.getLocalPort() + " " + token);
            log("new client host=" + bindTunnels + " port=" + tunnel.getLocalPort());
            Thread acceptor = new Thread(() -> acceptTunnels(session), "tunnel-accept"); acceptor.setDaemon(true); acceptor.start();
            try { while (s.getInputStream().read() != -1) {} } catch (IOException ignored) {}
            session.close(); sessions.remove(token);
        }
        ServerSocket openTunnel(int requested) throws IOException {
            InetAddress addr = InetAddress.getByName(bindTunnels);
            if (requested != 0) {
                if (requested < minPort || requested > maxPort) throw new IOException("requested port is outside allowed range");
                ServerSocket ss = new ServerSocket(); ss.setReuseAddress(true); ss.bind(new InetSocketAddress(addr, requested)); return ss;
            }
            for (int p = minPort; p <= maxPort; p++) {
                try { ServerSocket ss = new ServerSocket(); ss.setReuseAddress(true); ss.bind(new InetSocketAddress(addr, p)); return ss; } catch (IOException ignored) {}
            }
            throw new IOException("no available ports");
        }
        void acceptTunnels(Session session) {
            while (!session.closed) {
                try {
                    Socket remote = session.tunnel.accept();
                    int id = session.nextId.getAndIncrement();
                    session.pending.put(id, remote);
                    synchronized (session.writer) { session.writer.println("NEW " + id); }
                } catch (IOException e) { break; }
            }
        }
        void handleData(Socket data, String token, int id) throws Exception {
            Session session = sessions.get(token);
            if (session == null) { data.close(); return; }
            Socket remote = null;
            for (int i = 0; i < 100 && remote == null; i++) { remote = session.pending.remove(id); if (remote == null) Thread.sleep(10); }
            if (remote == null) { data.close(); return; }
            pipeBoth(remote, data);
        }
    }

    static class Session {
        final String token; final ServerSocket tunnel; final PrintWriter writer; final AtomicInteger nextId = new AtomicInteger(1); final ConcurrentMap<Integer, Socket> pending = new ConcurrentHashMap<>(); volatile boolean closed;
        Session(String token, ServerSocket tunnel, PrintWriter writer) { this.token=token; this.tunnel=tunnel; this.writer=writer; }
        void close() { closed = true; try { tunnel.close(); } catch(IOException ignored){} for (Socket s : pending.values()) try { s.close(); } catch(IOException ignored){} }
    }

    static class TunnelClient {
        final String localHost, serverHost, secret; final int localPort, remotePort;
        TunnelClient(String localHost, int localPort, String serverHost, int remotePort, String secret) { this.localHost=localHost; this.localPort=localPort; this.serverHost=serverHost; this.remotePort=remotePort; this.secret=secret; }
        void run() throws Exception {
            Socket control;
            try { control = new Socket(); control.connect(new InetSocketAddress(serverHost, CONTROL_PORT), 5000); }
            catch (IOException e) { throw new Exception("could not connect to " + serverHost + ":" + CONTROL_PORT, e); }
            PrintWriter pw = new PrintWriter(new OutputStreamWriter(control.getOutputStream(), StandardCharsets.UTF_8), true);
            BufferedReader br = new BufferedReader(new InputStreamReader(control.getInputStream(), StandardCharsets.UTF_8));
            pw.println("HELLO 1 " + remotePort + " " + b64(secret));
            String resp = br.readLine();
            if (resp == null) throw new IOException("server closed connection");
            if (!resp.startsWith("OK ")) throw new IOException(resp.startsWith("ERR ") ? resp.substring(4) : resp);
            String[] parts = resp.split(" ");
            int assigned = Integer.parseInt(parts[1]); String token = parts[2];
            log("connected to server remote_port=" + assigned);
            log("listening at " + serverHost + ":" + assigned);
            while (true) {
                String line = br.readLine();
                if (line == null) break;
                String[] p = line.split(" ");
                if (p.length == 2 && p[0].equals("NEW")) {
                    int id = Integer.parseInt(p[1]);
                    Thread t = new Thread(() -> handleConnection(token, id), "forward"); t.setDaemon(true); t.start();
                }
            }
        }
        void handleConnection(String token, int id) {
            try {
                Socket data = new Socket(); data.connect(new InetSocketAddress(serverHost, CONTROL_PORT), 5000);
                PrintWriter pw = new PrintWriter(new OutputStreamWriter(data.getOutputStream(), StandardCharsets.UTF_8), true);
                pw.println("DATA " + token + " " + id);
                Socket local = new Socket(); local.connect(new InetSocketAddress(localHost, localPort), 5000);
                pipeBoth(local, data);
            } catch (IOException e) { }
        }
    }

    static void pipeBoth(Socket a, Socket b) throws IOException {
        Thread t1 = new Thread(() -> copy(a, b), "pipe-a");
        Thread t2 = new Thread(() -> copy(b, a), "pipe-b");
        t1.start(); t2.start();
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            try { a.close(); } catch (IOException ignored) { }
            try { b.close(); } catch (IOException ignored) { }
        }
    }
    static void copy(Socket inSock, Socket outSock) {
        try {
            InputStream in = inSock.getInputStream(); OutputStream out = outSock.getOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) != -1) { out.write(buf, 0, n); out.flush(); }
        } catch (IOException ignored) { }
        try { outSock.shutdownOutput(); } catch (IOException ignored) { }
    }
}
