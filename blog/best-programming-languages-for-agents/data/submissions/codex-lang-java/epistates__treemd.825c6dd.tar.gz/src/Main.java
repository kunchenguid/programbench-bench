import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Heading {
        int level, line;
        String text, raw;
        Heading parent;
        List<Heading> children = new ArrayList<>();
        int startIndex, endIndex;
    }
    static class CodeBlock {
        String lang, content;
        int startLine, endLine;
    }
    static class Link {
        String text, url;
    }
    static class Doc {
        List<String> lines = new ArrayList<>();
        List<Heading> headings = new ArrayList<>();
        List<Heading> roots = new ArrayList<>();
        List<CodeBlock> codes = new ArrayList<>();
        List<Link> links = new ArrayList<>();
    }

    public static void main(String[] args) throws Exception {
        int status = run(args);
        if (status != 0) System.exit(status);
    }

    static int run(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("at-line")) return atLine(args);
        boolean list = false, tree = false, count = false, setup = false, qhelp = false;
        String filter = null, section = null, query = null, output = "plain", qout = "plain";
        Integer level = null;
        List<String> files = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(); return 0;
                case "-V": case "--version": System.out.println("treemd 0.5.7"); return 0;
                case "-l": case "--list": list = true; break;
                case "--tree": tree = true; break;
                case "--count": count = true; break;
                case "--setup-completions": setup = true; break;
                case "--query-help": qhelp = true; break;
                case "--filter": filter = need(args, ++i, a); break;
                case "-L": case "--level": level = Integer.parseInt(need(args, ++i, a)); break;
                case "-o": case "--output": output = need(args, ++i, a); break;
                case "-s": case "--section": section = need(args, ++i, a); break;
                case "-q": case "--query": query = need(args, ++i, a); break;
                case "--query-output": qout = need(args, ++i, a); break;
                case "--theme": case "--color-mode": i++; break;
                case "--no-images": case "--images": break;
                default:
                    if (a.equals("-")) { files.add(a); break; }
                    if (a.startsWith("-")) {
                        System.err.println("error: unexpected argument '" + a + "' found\n");
                        System.err.println("  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n");
                        System.err.println("Usage: executable [OPTIONS] [FILE]... [COMMAND]\n\nFor more information, try '--help'.");
                        return 2;
                    }
                    files.add(a);
            }
        }
        if (qhelp) { printQueryHelp(); return 0; }
        if (setup) { System.out.println("Shell completion setup is not available in this build."); return 0; }
        Doc doc = readDoc(files);
        parse(doc);
        if (query != null) { query(doc, query, qout); return 0; }
        if (section != null) return section(doc, section);
        if (count) { count(doc); return 0; }
        if (tree && "json".equals(output)) { printDocumentJson(doc); return 0; }
        if (tree || "tree".equals(output)) { printTree(doc, filter); return 0; }
        if (list || files.size() > 0) {
            List<Heading> hs = filtered(doc, filter, level);
            if ("json".equals(output)) printHeadingsJson(hs);
            else for (Heading h : hs) System.out.println(h.raw);
            return 0;
        }
        printHelp();
        return 0;
    }

    static String need(String[] args, int i, String flag) {
        if (i >= args.length) throw new IllegalArgumentException("missing value for " + flag);
        return args[i];
    }

    static Doc readDoc(List<String> files) throws IOException {
        Doc d = new Doc();
        if (files.isEmpty() || files.contains("-")) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) d.lines.add(line);
            if (!d.lines.isEmpty() || files.isEmpty()) return d;
        }
        for (String f : files) {
            Path p = Paths.get(f);
            if (Files.isDirectory(p)) continue;
            d.lines.addAll(Files.readAllLines(p, StandardCharsets.UTF_8));
        }
        return d;
    }

    static void parse(Doc d) {
        Pattern linkPat = Pattern.compile("!?\\[([^\\]]*)\\]\\(([^)\\s]+)(?:\\s+\"[^\"]*\")?\\)");
        Deque<Heading> stack = new ArrayDeque<>();
        boolean inCode = false;
        CodeBlock cur = null;
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < d.lines.size(); i++) {
            String line = d.lines.get(i);
            if (line.startsWith("```")) {
                if (!inCode) {
                    inCode = true;
                    cur = new CodeBlock();
                    cur.lang = line.substring(3).trim();
                    cur.startLine = 1;
                    code.setLength(0);
                } else {
                    inCode = false;
                    cur.content = trimTrailingNewline(code.toString());
                    cur.endLine = Math.max(1, cur.startLine + cur.content.split("\\R", -1).length - 1);
                    d.codes.add(cur);
                }
                continue;
            }
            if (inCode) {
                code.append(line).append('\n');
                continue;
            }
            Heading h = heading(line, i + 1);
            if (h != null) {
                h.startIndex = i;
                while (!stack.isEmpty() && stack.peek().level >= h.level) stack.pop();
                if (stack.isEmpty()) d.roots.add(h);
                else { h.parent = stack.peek(); stack.peek().children.add(h); }
                stack.push(h);
                d.headings.add(h);
            }
            Matcher m = linkPat.matcher(line);
            while (m.find()) {
                if (m.group(0).startsWith("!")) continue;
                Link l = new Link();
                l.text = m.group(1);
                l.url = m.group(2);
                d.links.add(l);
            }
        }
        for (int i = 0; i < d.headings.size(); i++) {
            Heading h = d.headings.get(i);
            int end = d.lines.size();
            for (int j = i + 1; j < d.headings.size(); j++) {
                if (d.headings.get(j).level <= h.level) { end = d.headings.get(j).startIndex; break; }
            }
            h.endIndex = end;
        }
    }

    static Heading heading(String line, int lineNo) {
        int pos = 0;
        while (pos < line.length() && pos < 3 && line.charAt(pos) == ' ') pos++;
        int j = pos;
        while (j < line.length() && line.charAt(j) == '#') j++;
        int n = j - pos;
        if (n < 1 || n > 6) return null;
        if (j < line.length() && !Character.isWhitespace(line.charAt(j))) return null;
        String text = line.substring(j).trim().replaceFirst("\\s+#+\\s*$", "");
        Heading h = new Heading();
        h.level = n; h.line = lineNo; h.text = text; h.raw = "#".repeat(n) + (text.isEmpty() ? "" : " " + text);
        return h;
    }

    static List<Heading> filtered(Doc d, String filter, Integer level) {
        List<Heading> out = new ArrayList<>();
        for (Heading h : d.headings) {
            if (level != null && h.level != level) continue;
            if (filter != null && !h.text.toLowerCase(Locale.ROOT).contains(filter.toLowerCase(Locale.ROOT))) continue;
            out.add(h);
        }
        return out;
    }

    static void printTree(Doc d, String filter) {
        for (int i = 0; i < d.roots.size(); i++) printNode(d.roots.get(i), "", i == d.roots.size() - 1);
    }
    static void printNode(Heading h, String prefix, boolean last) {
        System.out.println(prefix + (last ? "└──" : "├──") + h.raw);
        String np = prefix + (last ? "   " : "│  ");
        for (int i = 0; i < h.children.size(); i++) printNode(h.children.get(i), np, i == h.children.size() - 1);
    }

    static void count(Doc d) {
        int[] c = new int[7];
        for (Heading h : d.headings) c[h.level]++;
        System.out.println("Heading counts:");
        for (int i = 1; i <= 6; i++) if (c[i] > 0) System.out.println("  " + "#".repeat(i) + ": " + c[i]);
        System.out.println();
        System.out.println("Total: " + d.headings.size());
    }

    static int section(Doc d, String name) {
        for (Heading h : d.headings) {
            if (h.text.equalsIgnoreCase(name)) {
                for (int i = h.startIndex; i < h.endIndex; i++) System.out.println(d.lines.get(i));
                return 0;
            }
        }
        System.err.println("Section '" + name + "' not found");
        return 1;
    }

    static int atLine(String[] args) throws IOException {
        if (args.length != 2 || args[1].equals("-h") || args[1].equals("--help")) {
            System.out.println("Show heading at specific line number\n\nUsage: executable at-line <LINE>");
            return args.length == 2 ? 0 : 2;
        }
        int line = Integer.parseInt(args[1]);
        Doc d = readDoc(Collections.emptyList());
        parse(d);
        Heading best = null;
        for (Heading h : d.headings) if (h.line <= line) best = h; else break;
        if (best != null) System.out.println(best.raw);
        return 0;
    }

    static void query(Doc d, String expr, String outFmt) {
        expr = expr.trim();
        boolean asText = expr.matches(".*\\|\\s*text\\s*$");
        boolean asUrl = expr.matches(".*\\|\\s*(url|href)\\s*$");
        boolean asLang = expr.matches(".*\\|\\s*lang\\s*$");
        boolean asCount = expr.matches(".*\\|\\s*(count|length|len|size)\\s*$");
        String base = expr.replaceFirst("\\|.*$", "").trim();
        if (base.startsWith("[") && base.endsWith("]")) base = base.substring(1, base.length() - 1).trim();
        List<Object> items = select(d, base);
        items = applyQueryFunctions(items, expr);
        if (asCount) { System.out.println(items.size()); return; }
        if (expr.matches(".*\\|\\s*stats\\s*$")) {
            System.out.println("headings: " + d.headings.size());
            System.out.println("words: " + wordCount(d));
            System.out.println("code_blocks: " + d.codes.size());
            System.out.println("links: " + d.links.size());
            return;
        }
        if (expr.matches(".*\\|\\s*levels\\s*$")) {
            int[] c = new int[7];
            for (Heading h : d.headings) c[h.level]++;
            for (int i = 1; i <= 6; i++) if (c[i] > 0) System.out.println(i + ": " + c[i]);
            return;
        }
        if ("json".equals(outFmt) || "jsonp".equals(outFmt) || "json-pretty".equals(outFmt)) {
            if (base.equals(".")) System.out.println("{\"type\":\"document\",\"heading_count\":" + d.headings.size() + ",\"word_count\":" + wordCount(d) + "}");
            else printJsonItems(items);
            return;
        }
        for (Object o : items) {
            if (o instanceof Heading) {
                Heading h = (Heading)o;
                if (asText) System.out.println(h.text);
                else System.out.println(h.raw);
            } else if (o instanceof CodeBlock) {
                CodeBlock c = (CodeBlock)o;
                if (asLang) System.out.println(c.lang);
                else System.out.println("```" + c.lang + "\n" + c.content + "\n```");
            } else if (o instanceof Link) {
                Link l = (Link)o;
                if (asUrl) System.out.println(l.url);
                else System.out.println("[" + l.text + "](" + l.url + ")");
            }
        }
    }

    static List<Object> applyQueryFunctions(List<Object> in, String expr) {
        List<Object> out = new ArrayList<>(in);
        Matcher contains = Pattern.compile("contains\\([\"']([^\"']+)[\"']\\)").matcher(expr);
        if (contains.find()) {
            String s = contains.group(1).toLowerCase(Locale.ROOT);
            out.removeIf(o -> !displayText(o).toLowerCase(Locale.ROOT).contains(s));
        }
        Matcher starts = Pattern.compile("startswith\\([\"']([^\"']+)[\"']\\)").matcher(expr);
        if (starts.find()) {
            String s = starts.group(1).toLowerCase(Locale.ROOT);
            out.removeIf(o -> !displayText(o).toLowerCase(Locale.ROOT).startsWith(s));
        }
        Matcher ends = Pattern.compile("endswith\\([\"']([^\"']+)[\"']\\)").matcher(expr);
        if (ends.find()) {
            String s = ends.group(1).toLowerCase(Locale.ROOT);
            out.removeIf(o -> !displayText(o).toLowerCase(Locale.ROOT).endsWith(s));
        }
        if (expr.matches(".*\\|\\s*(reverse)\\s*$")) Collections.reverse(out);
        Matcher lim = Pattern.compile("(?:limit|take)\\((\\d+)\\)").matcher(expr);
        if (lim.find()) out = new ArrayList<>(out.subList(0, Math.min(out.size(), Integer.parseInt(lim.group(1)))));
        Matcher skip = Pattern.compile("(?:skip|drop)\\((\\d+)\\)").matcher(expr);
        if (skip.find()) out = new ArrayList<>(out.subList(Math.min(out.size(), Integer.parseInt(skip.group(1))), out.size()));
        Matcher nth = Pattern.compile("nth\\((-?\\d+)\\)").matcher(expr);
        if (nth.find()) {
            int n = Integer.parseInt(nth.group(1));
            if (n < 0) n = out.size() + n;
            out = (n >= 0 && n < out.size()) ? new ArrayList<>(List.of(out.get(n))) : new ArrayList<>();
        }
        if (expr.matches(".*\\|\\s*(first|head)\\s*$")) out = out.isEmpty() ? new ArrayList<>() : new ArrayList<>(List.of(out.get(0)));
        if (expr.matches(".*\\|\\s*last\\s*$")) out = out.isEmpty() ? new ArrayList<>() : new ArrayList<>(List.of(out.get(out.size() - 1)));
        if (expr.matches(".*\\|\\s*sort\\s*$")) out.sort(Comparator.comparing(Main::displayText));
        return out;
    }

    static String displayText(Object o) {
        if (o instanceof Heading) return ((Heading)o).text;
        if (o instanceof CodeBlock) return ((CodeBlock)o).content;
        if (o instanceof Link) return ((Link)o).text;
        return String.valueOf(o);
    }

    static List<Object> select(Doc d, String base) {
        List<Object> out = new ArrayList<>();
        Matcher hm = Pattern.compile("\\.h(?:eading)?([1-6])?(?:\\[([^\\]]+)\\])?").matcher(base);
        if (base.equals(".") || base.isEmpty()) { out.add("document"); return out; }
        if (hm.find()) {
            Integer lvl = hm.group(1) == null ? null : Integer.parseInt(hm.group(1));
            String filt = hm.group(2);
            for (Heading h : d.headings) {
                if (lvl != null && h.level != lvl) continue;
                if (filt != null && !isIndexFilter(filt) && !matchFilter(h.text, filt)) continue;
                out.add(h);
            }
            if (filt != null && isIndexFilter(filt)) out = applyIndex(out, filt);
        } else if (base.startsWith(".code")) {
            String lang = bracket(base);
            for (CodeBlock c : d.codes) if (lang == null || c.lang.equalsIgnoreCase(lang)) out.add(c);
        } else if (base.startsWith(".link") || base.startsWith(".a")) {
            String f = bracket(base);
            for (Link l : d.links) {
                if ("external".equalsIgnoreCase(f) && !(l.url.startsWith("http://") || l.url.startsWith("https://"))) continue;
                out.add(l);
            }
        }
        return out;
    }

    static boolean matchFilter(String text, String f) {
        f = f.trim();
        if ((f.startsWith("\"") && f.endsWith("\"")) || (f.startsWith("'") && f.endsWith("'"))) {
            return text.equals(f.substring(1, f.length() - 1));
        }
        if (f.matches("-?\\d+(:-?\\d*)?")) return true;
        return text.toLowerCase(Locale.ROOT).contains(f.toLowerCase(Locale.ROOT));
    }
    static boolean isIndexFilter(String f) { return f.trim().matches("-?\\d+|(-?\\d*)?:(-?\\d*)?"); }
    static List<Object> applyIndex(List<Object> in, String f) {
        f = f.trim();
        if (!f.contains(":")) {
            int n = Integer.parseInt(f);
            if (n < 0) n = in.size() + n;
            return (n >= 0 && n < in.size()) ? new ArrayList<>(List.of(in.get(n))) : new ArrayList<>();
        }
        String[] p = f.split(":", -1);
        int a = p[0].isEmpty() ? 0 : Integer.parseInt(p[0]);
        int b = p.length < 2 || p[1].isEmpty() ? in.size() : Integer.parseInt(p[1]);
        if (a < 0) a = in.size() + a;
        if (b < 0) b = in.size() + b;
        a = Math.max(0, Math.min(a, in.size()));
        b = Math.max(a, Math.min(b, in.size()));
        return new ArrayList<>(in.subList(a, b));
    }
    static String bracket(String s) {
        int a = s.indexOf('['), b = s.indexOf(']', a + 1);
        return a >= 0 && b > a ? s.substring(a + 1, b).replace("\"", "").replace("'", "").trim() : null;
    }

    static void printHeadingsJson(List<Heading> hs) {
        System.out.println("[");
        for (int i = 0; i < hs.size(); i++) {
            Heading h = hs.get(i);
            System.out.print("  {\n    \"level\": " + h.level + ",\n    \"text\": \"" + esc(h.text) + "\"\n  }");
            System.out.println(i + 1 == hs.size() ? "" : ",");
        }
        System.out.println("]");
    }
    static void printDocumentJson(Doc d) {
        System.out.println("{");
        System.out.println("  \"document\": {");
        System.out.println("    \"metadata\": {");
        System.out.println("      \"source\": null,");
        System.out.println("      \"headingCount\": " + d.headings.size() + ",");
        int max = 0;
        for (Heading h : d.headings) max = Math.max(max, h.level);
        System.out.println("      \"maxDepth\": " + max + ",");
        System.out.println("      \"wordCount\": " + wordCount(d));
        System.out.println("    },");
        System.out.println("    \"sections\": [");
        for (int i = 0; i < d.roots.size(); i++) {
            printSectionJson(d, d.roots.get(i), "      ");
            System.out.println(i + 1 == d.roots.size() ? "" : ",");
        }
        System.out.println("    ]");
        System.out.println("  }");
        System.out.println("}");
    }
    static void printSectionJson(Doc d, Heading h, String ind) {
        System.out.println(ind + "{");
        System.out.println(ind + "  \"id\": \"" + esc(slug(h.text)) + "\",");
        System.out.println(ind + "  \"level\": " + h.level + ",");
        System.out.println(ind + "  \"title\": \"" + esc(h.text) + "\",");
        System.out.println(ind + "  \"slug\": \"" + esc(slug(h.text)) + "\",");
        System.out.println(ind + "  \"position\": {");
        System.out.println(ind + "    \"line\": " + (h.line + 1) + ",");
        System.out.println(ind + "    \"offset\": 0");
        System.out.println(ind + "  },");
        System.out.println(ind + "  \"content\": {");
        System.out.println(ind + "    \"raw\": \"" + esc(sectionContent(d, h)) + "\",");
        System.out.println(ind + "    \"blocks\": []");
        System.out.println(ind + "  },");
        System.out.println(ind + "  \"children\": [");
        for (int i = 0; i < h.children.size(); i++) {
            printSectionJson(d, h.children.get(i), ind + "    ");
            System.out.println(i + 1 == h.children.size() ? "" : ",");
        }
        System.out.println(ind + "  ]");
        System.out.print(ind + "}");
    }
    static String sectionContent(Doc d, Heading h) {
        int end = d.lines.size();
        for (Heading x : d.headings) if (x.startIndex > h.startIndex) { end = x.startIndex; break; }
        List<String> part = new ArrayList<>();
        for (int i = h.startIndex + 1; i < end; i++) part.add(d.lines.get(i));
        while (!part.isEmpty() && part.get(0).trim().isEmpty()) part.remove(0);
        while (!part.isEmpty() && part.get(part.size() - 1).trim().isEmpty()) part.remove(part.size() - 1);
        return String.join("\n", part);
    }
    static String slug(String s) {
        String r = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-|-$", "");
        return r.isEmpty() ? "section" : r;
    }
    static void printJsonItems(List<Object> items) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) sb.append(',');
            Object o = items.get(i);
            if (o instanceof Heading) {
                Heading h = (Heading)o;
                sb.append("{\"type\":\"heading\",\"level\":").append(h.level).append(",\"text\":\"").append(esc(h.text)).append("\",\"line\":").append(h.line).append('}');
            } else if (o instanceof CodeBlock) {
                CodeBlock c = (CodeBlock)o;
                sb.append("{\"type\":\"code\",\"language\":\"").append(esc(c.lang)).append("\",\"content\":\"").append(esc(c.content)).append("\",\"start_line\":").append(c.startLine).append(",\"end_line\":").append(c.endLine).append('}');
            } else if (o instanceof Link) {
                Link l = (Link)o;
                String type = l.url.startsWith("http://") || l.url.startsWith("https://") ? "external" : "relative";
                sb.append("{\"type\":\"link\",\"text\":\"").append(esc(l.text)).append("\",\"url\":\"").append(esc(l.url)).append("\",\"link_type\":\"").append(type).append("\"}");
            }
        }
        sb.append(']');
        System.out.println(sb);
    }

    static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }
    static String trimTrailingNewline(String s) { return s.endsWith("\n") ? s.substring(0, s.length() - 1) : s; }
    static int wordCount(Doc d) {
        int n = 0;
        for (String l : d.lines) for (String w : l.trim().split("\\s+")) if (!w.isEmpty()) n++;
        return n;
    }

    static void printHelp() {
        System.out.println("treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.\n");
        System.out.println("Usage: executable [OPTIONS] [FILE]... [COMMAND]\n");
        System.out.println("Commands:\n  at-line  Show heading at specific line number\n  help     Print this message or the help of the given subcommand(s)\n");
        System.out.println("Options:\n  -l, --list                 List all headings in the document (non-interactive)\n      --tree                 Show heading tree structure\n      --filter <PATTERN>     Filter headings by text pattern\n  -L, --level <LEVEL>        Show only headings at specific level (1-6)\n  -o, --output <OUTPUT>      Output format: plain, json, tree\n  -s, --section <HEADING>    Extract specific section by heading name\n      --count                Count headings by level\n  -q, --query <EXPR>         Query expression for selecting document elements\n      --query-help           Show query language documentation and examples\n  -h, --help                 Print help\n  -V, --version              Print version");
    }
    static void printQueryHelp() {
        System.out.println("treemd Query Language (tql)\n");
        System.out.println("ELEMENT SELECTORS\n    .h, .heading    All headings (any level)\n    .h1 - .h6       Headings by level\n    .code           All code blocks\n    .code[rust]     Code blocks by language\n    .link, .a       All links\n");
        System.out.println("PIPES\n    .h2 | text          Get heading text (strips ##)\n    [.h2] | count       Count all h2s\n    .code | lang        Get code block languages\n    .link | url         Get link URLs");
    }
}
