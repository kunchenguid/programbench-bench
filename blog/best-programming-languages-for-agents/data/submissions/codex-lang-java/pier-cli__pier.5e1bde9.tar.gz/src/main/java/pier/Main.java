package pier;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    static final String VERSION = "0.1.6";

    static class Script {
        String alias;
        String command = "";
        String description = "";
        List<String> tags = new ArrayList<>();

        Script copy(String alias) {
            Script s = new Script();
            s.alias = alias;
            s.command = command;
            s.description = description;
            s.tags = new ArrayList<>(tags);
            return s;
        }
    }

    static class Config {
        Path path;
        LinkedHashMap<String, Script> scripts = new LinkedHashMap<>();
    }

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (PierError e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] argv) throws Exception {
        List<String> args = new ArrayList<>(Arrays.asList(argv));
        if (args.isEmpty() || has(args, "-h") || has(args, "--help")) {
            if (args.size() >= 2 && "help".equals(args.get(0))) return help(args.subList(1, args.size()));
            printMainHelp();
            return 0;
        }
        if (has(args, "-V") || has(args, "--version")) {
            System.out.println("pier " + VERSION);
            return 0;
        }

        Path explicitConfig = null;
        for (int i = 0; i < args.size();) {
            String a = args.get(i);
            if ("-v".equals(a) || "--verbose".equals(a)) {
                args.remove(i);
            } else if ("-c".equals(a) || "--config-file".equals(a)) {
                if (i + 1 >= args.size()) throw new PierError("The argument '--config-file <path>' requires a value but none was supplied");
                explicitConfig = Paths.get(args.get(i + 1));
                args.remove(i + 1);
                args.remove(i);
            } else {
                break;
            }
        }
        if (args.isEmpty()) {
            printMainHelp();
            return 0;
        }

        String cmd = normalize(args.get(0));
        if ("help".equals(cmd)) return help(args.subList(1, args.size()));
        if ("config-init".equals(cmd)) return configInit(explicitConfig);

        Config cfg = loadConfig(explicitConfig);
        switch (cmd) {
            case "add": return add(cfg, args.subList(1, args.size()));
            case "list": return list(cfg, args.subList(1, args.size()));
            case "show": return show(cfg, req(args, 1, "show <alias>"));
            case "run": return runScript(cfg, req(args, 1, "run <alias>"), args.subList(Math.min(2, args.size()), args.size()));
            case "copy": return copy(cfg, args);
            case "move": return move(cfg, args);
            case "remove": return remove(cfg, req(args, 1, "remove <alias>"));
            case "edit": return edit(cfg, req(args, 1, "edit <alias>"));
            default:
                return runScript(cfg, args.get(0), args.subList(1, args.size()));
        }
    }

    String normalize(String s) {
        switch (s) {
            case "init": return "config-init";
            case "ls": return "list";
            case "cp": return "copy";
            case "mv":
            case "rename": return "move";
            case "rm": return "remove";
            default: return s;
        }
    }

    int configInit(Path explicit) throws IOException {
        Path p = explicit != null ? explicit : defaultInitPath();
        if (Files.exists(p)) throw new PierError("Cannot initialize config at " + p + ", file already exists.");
        if (p.getParent() != null) Files.createDirectories(p.getParent());
        String content = "[scripts.hello-pier]\ncommand = 'echo Hello, Pier!'\ndescription = 'This is an example command.'\n\n[default]\n";
        Files.writeString(p, content, StandardCharsets.UTF_8);
        System.out.println("Added hello-pier");
        return 0;
    }

    Path defaultInitPath() {
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        Path local = cwd.resolve("pier.toml");
        if (Files.exists(local)) return local;
        String xdg = System.getenv("XDG_CONFIG_HOME");
        if (xdg != null && !xdg.isEmpty()) return Paths.get(xdg).resolve("pier/config.toml");
        String home = System.getenv("HOME");
        return Paths.get(home == null ? "." : home).resolve(".pier.toml");
    }

    Config loadConfig(Path explicit) throws IOException {
        Path p = explicit != null ? explicit : findConfig();
        if (p == null) throw new PierError("No default config file found. See help for more info.");
        if (!Files.exists(p)) throw new PierError("Unable to read config from file " + p + ": No such file or directory (os error 2) ");
        Config c = new Config();
        c.path = p;
        parseConfig(c, Files.readString(p, StandardCharsets.UTF_8));
        return c;
    }

    Path findConfig() {
        String env = System.getenv("PIER_CONFIG_PATH");
        if (env != null && !env.isEmpty()) return Paths.get(env);
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        for (Path p : List.of(cwd.resolve("pier.toml"))) if (Files.exists(p)) return p;
        String xdg = System.getenv("XDG_CONFIG_HOME");
        if (xdg != null && !xdg.isEmpty()) {
            for (Path p : List.of(Paths.get(xdg).resolve("pier/config.toml"), Paths.get(xdg).resolve("pier/config"), Paths.get(xdg).resolve("pier.toml"))) {
                if (Files.exists(p)) return p;
            }
        }
        String home = System.getenv("HOME");
        if (home != null && !home.isEmpty()) {
            for (Path p : List.of(Paths.get(home).resolve(".pier.toml"), Paths.get(home).resolve(".pier"))) if (Files.exists(p)) return p;
        }
        return null;
    }

    void parseConfig(Config cfg, String text) {
        Script cur = null;
        boolean inArray = false;
        List<String> arr = new ArrayList<>();
        for (String raw : text.split("\\R")) {
            String line = stripComment(raw).trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) {
                inArray = false;
                String sec = line.substring(1, line.length() - 1).trim();
                if (sec.startsWith("scripts.")) {
                    String alias = sec.substring(8);
                    cur = new Script();
                    cur.alias = alias;
                    cfg.scripts.put(alias, cur);
                } else cur = null;
                continue;
            }
            if (cur == null) continue;
            if (inArray) {
                if (line.startsWith("]")) {
                    cur.tags = arr;
                    inArray = false;
                } else {
                    String v = line.replace(",", "").trim();
                    if (!v.isEmpty()) arr.add(unquote(v));
                }
                continue;
            }
            int eq = line.indexOf('=');
            if (eq < 0) continue;
            String key = line.substring(0, eq).trim();
            String val = line.substring(eq + 1).trim();
            if ("command".equals(key)) cur.command = unquote(val);
            else if ("description".equals(key)) cur.description = unquote(val);
            else if ("tags".equals(key)) {
                arr = new ArrayList<>();
                if (val.startsWith("[") && val.endsWith("]")) {
                    String inner = val.substring(1, val.length() - 1).trim();
                    if (!inner.isEmpty()) for (String part : splitCsv(inner)) arr.add(unquote(part.trim()));
                    cur.tags = arr;
                } else if (val.startsWith("[")) {
                    inArray = true;
                }
            }
        }
    }

    String stripComment(String s) {
        boolean sq = false, dq = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\'' && !dq) sq = !sq;
            else if (ch == '"' && !sq) dq = !dq;
            else if (ch == '#' && !sq && !dq) return s.substring(0, i);
        }
        return s;
    }

    List<String> splitCsv(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        boolean sq = false, dq = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\'' && !dq) sq = !sq;
            else if (ch == '"' && !sq) dq = !dq;
            if (ch == ',' && !sq && !dq) {
                out.add(b.toString());
                b.setLength(0);
            } else b.append(ch);
        }
        out.add(b.toString());
        return out;
    }

    String unquote(String v) {
        v = v.trim();
        if (v.length() >= 2 && ((v.charAt(0) == '\'' && v.charAt(v.length() - 1) == '\'') || (v.charAt(0) == '"' && v.charAt(v.length() - 1) == '"'))) {
            v = v.substring(1, v.length() - 1);
        }
        return v.replace("\\\"", "\"").replace("\\n", "\n").replace("\\'", "'");
    }

    int add(Config cfg, List<String> args) throws IOException, InterruptedException {
        String alias = null, desc = null, command = null;
        List<String> tags = new ArrayList<>();
        boolean force = false, afterDashDash = false;
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (!afterDashDash && "--".equals(a)) { afterDashDash = true; continue; }
            if (!afterDashDash && ("-f".equals(a) || "--force".equals(a))) force = true;
            else if (!afterDashDash && ("-a".equals(a) || "--alias".equals(a))) alias = value(args, ++i, "alias");
            else if (!afterDashDash && ("-d".equals(a) || "--description".equals(a))) desc = value(args, ++i, "description");
            else if (!afterDashDash && ("-t".equals(a) || "--tag".equals(a))) tags.add(value(args, ++i, "tag"));
            else if (command == null) command = a;
            else throw new PierError("Found argument '" + a + "' which wasn't expected, or isn't valid in this context");
        }
        if (alias == null) throw new PierError("The following required arguments were not provided:\n    --alias <alias>\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help");
        if (command == null) command = readEditor();
        if (cfg.scripts.containsKey(alias) && !force) throw new PierError("AliasAlreadyExists: A script already exists by alias " + alias);
        Script s = new Script();
        s.alias = alias;
        s.command = command;
        if (desc != null) s.description = desc;
        s.tags = tags;
        cfg.scripts.put(alias, s);
        save(cfg);
        System.out.println("Added " + alias);
        return 0;
    }

    String readEditor() throws IOException, InterruptedException {
        String editor = System.getenv().getOrDefault("EDITOR", "vi");
        Path tmp = Files.createTempFile("pier", ".sh");
        Process p = new ProcessBuilder(editor, tmp.toString()).inheritIO().start();
        int code = p.waitFor();
        if (code != 0) throw new PierError("EditorError: Failed when trying to get input from editor Failed to open `" + editor + "` as a text editor or editor was terminated with errors.");
        return Files.readString(tmp, StandardCharsets.UTF_8);
    }

    int list(Config cfg, List<String> args) {
        boolean aliases = false, full = false;
        int width = -1;
        List<String> filterTags = new ArrayList<>();
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if ("-q".equals(a) || "--list_aliases".equals(a)) aliases = true;
            else if ("-l".equals(a) || "--cmd_full".equals(a)) full = true;
            else if ("-c".equals(a) || "--cmd_width".equals(a) || "--cmd-width".equals(a)) width = Integer.parseInt(value(args, ++i, "cmd-width"));
            else if ("-t".equals(a) || "--tag".equals(a)) filterTags.add(value(args, ++i, "tag"));
        }
        List<Script> rows = filtered(cfg, filterTags);
        if (cfg.scripts.isEmpty()) throw new PierError("No scripts exist. Would you like to add a new script?");
        if (aliases) {
            for (Script s : rows) System.out.println(s.alias);
            return 0;
        }
        if (!full && width > -1) {
            for (Script s : rows) if (s.command.length() > width) s.command = s.command.substring(0, width);
        }
        printTable(rows);
        return 0;
    }

    List<Script> filtered(Config cfg, List<String> tags) {
        if (tags.isEmpty()) return new ArrayList<>(cfg.scripts.values());
        List<Script> out = new ArrayList<>();
        for (Script s : cfg.scripts.values()) {
            boolean ok = true;
            for (String t : tags) if (!s.tags.contains(t)) ok = false;
            if (ok) out.add(s);
        }
        return out;
    }

    void printTable(List<Script> rows) {
        int a = "Alias".length(), t = "Tags".length(), c = "Command".length(), d = "Description".length();
        List<String[]> vals = new ArrayList<>();
        for (Script s : rows) {
            String tags = String.join(",", s.tags);
            String[] r = {s.alias, tags, s.command, s.description == null ? "" : s.description};
            vals.add(r);
            a = Math.max(a, r[0].length()); t = Math.max(t, r[1].length()); c = Math.max(c, r[2].length()); d = Math.max(d, r[3].length());
        }
        int total = a + t + c + d + 13;
        line(total);
        row(new String[]{"Alias", "Tags", "Command", "Description"}, a, t, c, d);
        line(total);
        for (String[] r : vals) row(r, a, t, c, d);
        line(total);
    }

    void line(int n) { System.out.println("≖".repeat(Math.max(0, n))); }
    void row(String[] r, int a, int t, int c, int d) {
        System.out.printf("⋮ %-" + a + "s ⋮ %-" + t + "s ⋮ %-" + c + "s ⋮ %-" + d + "s ⋮%n", r[0], r[1], r[2], r[3]);
    }

    int show(Config cfg, String alias) {
        Script s = get(cfg, alias);
        System.out.println(s.command);
        return 0;
    }

    int runScript(Config cfg, String alias, List<String> args) throws IOException, InterruptedException {
        Script s = get(cfg, alias);
        List<String> cmd = new ArrayList<>();
        cmd.add("bash");
        cmd.add("-c");
        cmd.add(s.command);
        cmd.add(alias);
        cmd.addAll(args);
        Process p = new ProcessBuilder(cmd).inheritIO().start();
        return p.waitFor();
    }

    int copy(Config cfg, List<String> args) throws IOException {
        if (args.size() < 3) throw new PierError("The following required arguments were not provided");
        Script from = get(cfg, args.get(1));
        cfg.scripts.put(args.get(2), from.copy(args.get(2)));
        save(cfg);
        System.out.println("Copy from alias " + args.get(1) + " to new alias " + args.get(2));
        return 0;
    }

    int move(Config cfg, List<String> args) throws IOException {
        boolean force = args.contains("-f") || args.contains("--force");
        List<String> pos = new ArrayList<>();
        for (int i = 1; i < args.size(); i++) if (!args.get(i).startsWith("-")) pos.add(args.get(i));
        if (pos.size() < 2) throw new PierError("The following required arguments were not provided");
        Script from = get(cfg, pos.get(0));
        if (cfg.scripts.containsKey(pos.get(1)) && !force) throw new PierError("AliasAlreadyExists: A script already exists by alias " + pos.get(1));
        cfg.scripts.remove(pos.get(0));
        cfg.scripts.put(pos.get(1), from.copy(pos.get(1)));
        save(cfg);
        System.out.println("Move from alias " + pos.get(0) + " to new alias " + pos.get(1));
        return 0;
    }

    int remove(Config cfg, String alias) throws IOException {
        if (cfg.scripts.isEmpty()) throw new PierError("No scripts exist. Would you like to add a new script?");
        get(cfg, alias);
        cfg.scripts.remove(alias);
        save(cfg);
        System.out.println("Removed " + alias);
        return 0;
    }

    int edit(Config cfg, String alias) throws IOException, InterruptedException {
        Script s = get(cfg, alias);
        Path tmp = Files.createTempFile("pier-edit", ".sh");
        Files.writeString(tmp, s.command, StandardCharsets.UTF_8);
        String editor = System.getenv().getOrDefault("EDITOR", "vi");
        Process p = new ProcessBuilder(editor, tmp.toString()).inheritIO().start();
        int code = p.waitFor();
        if (code != 0) throw new PierError("EditorError: Failed when trying to get input from editor Failed to open `" + editor + "` as a text editor or editor was terminated with errors.");
        s.command = Files.readString(tmp, StandardCharsets.UTF_8);
        save(cfg);
        System.out.println("Edited " + alias);
        return 0;
    }

    Script get(Config cfg, String alias) {
        Script s = cfg.scripts.get(alias);
        if (s == null) throw new PierError("AliasNotFound: No script found by alias " + alias);
        return s;
    }

    void save(Config cfg) throws IOException {
        StringBuilder b = new StringBuilder();
        for (Script s : cfg.scripts.values()) {
            b.append("[scripts.").append(s.alias).append("]\n");
            b.append("command = '").append(escape(s.command)).append("'\n");
            if (s.description != null && !s.description.isEmpty()) b.append("description = '").append(escape(s.description)).append("'\n");
            if (!s.tags.isEmpty()) {
                if (s.tags.size() == 1) b.append("tags = ['").append(escape(s.tags.get(0))).append("']\n");
                else {
                    b.append("tags = [\n");
                    for (String t : s.tags) b.append("    '").append(escape(t)).append("',\n");
                    b.append("]\n");
                }
            }
            b.append("\n");
        }
        b.append("[default]\n");
        Files.writeString(cfg.path, b.toString(), StandardCharsets.UTF_8);
    }

    String escape(String s) { return s.replace("'", "\\'"); }
    boolean has(List<String> args, String v) { return args.contains(v); }
    String value(List<String> args, int i, String name) {
        if (i >= args.size()) throw new PierError("The argument '" + name + "' requires a value but none was supplied");
        return args.get(i);
    }
    String req(List<String> args, int i, String usage) {
        if (i >= args.size()) throw new PierError("The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable " + usage + "\n\nFor more information try --help");
        return args.get(i);
    }

    int help(List<String> sub) {
        if (sub.isEmpty()) printMainHelp();
        else printSubHelp(normalize(sub.get(0)));
        return 0;
    }

    void printMainHelp() {
        System.out.println("pier " + VERSION);
        System.out.println("Benjamin Scholtz, Isak Johansson");
        System.out.println("A simple script management CLI\n");
        System.out.println("USAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n");
        System.out.println("FLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n    -v, --verbose    The level of verbosity\n");
        System.out.println("OPTIONS:\n    -c, --config-file <path>    Sets a custom config file. [env: PIER_CONFIG_PATH=]\n");
        System.out.println("SUBCOMMANDS:\n    add            Add a new script to config.\n    config-init    alias: init - Add a config file.\n    copy           alias: cp - Copy existing alias to the new one\n    edit           Edit a script matching alias.\n    help           Prints this message or the help of the given subcommand(s)\n    list           alias: ls - List scripts\n    move           alias: mv, rename - Move/rename existing alias to the new one\n    remove         alias: rm - Remove a script matching alias.\n    run            Run a script matching alias.\n    show           Show a script matching alias.");
    }

    void printSubHelp(String s) {
        switch (s) {
            case "add":
                System.out.println("executable-add " + VERSION + "\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]");
                break;
            case "list":
                System.out.println("executable-list " + VERSION + "\nalias: ls - List scripts\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]");
                break;
            case "run":
                System.out.println("executable-run " + VERSION + "\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...");
                break;
            case "show":
                System.out.println("executable-show " + VERSION + "\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>");
                break;
            default:
                System.out.println("executable-" + s + " " + VERSION);
        }
    }

    static class PierError extends RuntimeException {
        PierError(String msg) { super(msg); }
    }
}
