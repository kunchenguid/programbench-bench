import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Opts {
        String filter = null, query = "";
        boolean printQuery, read0, print0, sort = true, tac, ignoreCase = false, caseSet = false, smartCase = true;
        boolean select1, exit0, disabled, exact, extended = true, literal;
        int tail = -1;
        String delimiter = null, nth = null, withNth = null, acceptNth = null, scheme = "default";
        List<String> tiebreak = new ArrayList<>(List.of("length"));
    }
    static class Item {
        String original, searchable;
        int index, score, begin, end;
        Item(String o, int i) { original=o; index=i; searchable=o; }
    }
    public static void main(String[] argv) throws Exception {
        Opts o = new Opts();
        List<String> args = new ArrayList<>();
        String optsFile = System.getenv("FZF_DEFAULT_OPTS_FILE");
        if (optsFile != null && !optsFile.isEmpty()) {
            try { args.addAll(shellSplit(Files.readString(Path.of(optsFile)))); } catch (IOException ignored) {}
        }
        String env = System.getenv("FZF_DEFAULT_OPTS");
        if (env != null && !env.isEmpty()) args.addAll(shellSplit(env));
        args.addAll(Arrays.asList(argv));
        try { parse(args, o); } catch (IllegalArgumentException e) { System.err.println(prefix(args, argv) + e.getMessage()); System.exit(2); }
        if (o.scheme.equals("path") && o.tiebreak.equals(List.of("length"))) o.tiebreak = new ArrayList<>(List.of("pathname","length"));
        if (o.scheme.equals("history") && o.tiebreak.equals(List.of("length"))) o.tiebreak = new ArrayList<>(List.of("index"));
        boolean filterMode = o.filter != null;
        if (o.filter == null && (o.select1 || o.exit0)) o.filter = o.query;
        if (o.filter == null) { System.err.println("inappropriate ioctl for device"); System.exit(2); }
        byte[] data = System.in.readAllBytes();
        List<String> input = splitInput(data, o.read0);
        if (o.tail >= 0 && input.size() > o.tail) input = new ArrayList<>(input.subList(input.size()-o.tail, input.size()));
        if (o.tac) Collections.reverse(input);
        List<Item> matches = new ArrayList<>();
        for (int i=0;i<input.size();i++) {
            Item it = new Item(input.get(i), i);
            it.searchable = transform(it.original, o.withNth, o.delimiter, i);
            String scope = o.nth != null ? transform(it.searchable, o.nth, o.delimiter, i) : it.searchable;
            Match m = matchesQuery(scope, o.filter, o);
            if (m.ok) { it.score=m.score; it.begin=m.begin; it.end=m.end; matches.add(it); }
        }
        if (o.sort && !o.filter.isEmpty() && !o.disabled) matches.sort((a,b)->compareItems(a,b,o));
        if (!filterMode) {
            if (o.exit0 && matches.isEmpty()) System.exit(1);
            if (o.select1 && matches.size() == 1) {
                String s = o.acceptNth != null ? transform(matches.get(0).original, o.acceptNth, o.delimiter, matches.get(0).index) : matches.get(0).original;
                if (o.printQuery) write(System.out, o.filter + (o.print0 ? "\0" : "\n"));
                write(System.out, s + (o.print0 ? "\0" : "\n"));
                System.exit(0);
            }
            System.err.println("inappropriate ioctl for device");
            System.exit(2);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        String sep = o.print0 ? "\0" : "\n";
        if (o.printQuery) write(out, o.filter + sep);
        for (Item it: matches) {
            String s = o.acceptNth != null ? transform(it.original, o.acceptNth, o.delimiter, it.index) : it.original;
            write(out, s + sep);
        }
        System.out.write(out.toByteArray());
        if (matches.isEmpty()) System.exit(1);
    }
    static String prefix(List<String> all, String[] argv) { return all.size() > argv.length ? "$FZF_DEFAULT_OPTS: " : ""; }
    static void parse(List<String> args, Opts o) throws Exception {
        for (int i=0;i<args.size();i++) {
            String a=args.get(i);
            if (a.equals("--help")) { printResource("help.txt", fallbackHelp()); System.exit(0); }
            if (a.equals("--version")) { System.out.println("0.68.0 (5676da4a)"); System.exit(0); }
            if (a.equals("--man")) { printResource("fzf-man-head.txt", fallbackHelp()); System.exit(0); }
            if (a.equals("--bash") || a.equals("--zsh") || a.equals("--fish")) { System.out.println("# fzf shell integration is not available in this build"); System.exit(0); }
            if (a.equals("-f") || a.equals("--filter")) o.filter = need(args, ++i, "query string required");
            else if (a.startsWith("--filter=")) o.filter = a.substring(9);
            else if (a.equals("-q") || a.equals("--query")) o.query = need(args, ++i, "query string required");
            else if (a.startsWith("--query=")) o.query = a.substring(8);
            else if (a.equals("--print-query")) o.printQuery = true;
            else if (a.equals("--read0")) o.read0 = true; else if (a.equals("--print0")) o.print0 = true;
            else if (a.equals("+s") || a.equals("--no-sort")) o.sort = false; else if (a.equals("--tac")) o.tac = true;
            else if (a.equals("-i") || a.equals("--ignore-case")) { o.ignoreCase=true; o.caseSet=true; }
            else if (a.equals("+i") || a.equals("--no-ignore-case")) { o.ignoreCase=false; o.caseSet=true; o.smartCase=false; }
            else if (a.equals("--smart-case")) { o.smartCase=true; o.caseSet=false; }
            else if (a.equals("-e") || a.equals("--exact")) o.exact = true;
            else if (a.equals("+x") || a.equals("--no-extended")) o.extended = false;
            else if (a.equals("--literal")) o.literal = true;
            else if (a.equals("-1") || a.equals("--select-1")) o.select1=true; else if (a.equals("-0") || a.equals("--exit-0")) o.exit0=true;
            else if (a.equals("--disabled")) o.disabled=true;
            else if (a.equals("-n") || a.equals("--nth")) { o.nth=need(args,++i,"nth expression required"); validateExpr(o.nth); }
            else if (a.startsWith("--nth=")) { o.nth=a.substring(6); validateExpr(o.nth); }
            else if (a.equals("--with-nth")) { o.withNth=need(args,++i,"with-nth expression required"); }
            else if (a.startsWith("--with-nth=")) o.withNth=a.substring(11);
            else if (a.equals("--accept-nth")) { o.acceptNth=need(args,++i,"accept-nth expression required"); }
            else if (a.startsWith("--accept-nth=")) o.acceptNth=a.substring(13);
            else if (a.equals("-d") || a.equals("--delimiter")) o.delimiter=need(args,++i,"delimiter required");
            else if (a.startsWith("--delimiter=")) o.delimiter=a.substring(12);
            else if (a.equals("--tail")) o.tail=parseInt(need(args,++i,"tail size required"), "invalid tail size: ");
            else if (a.startsWith("--tail=")) o.tail=parseInt(a.substring(7), "invalid tail size: ");
            else if (a.startsWith("--scheme=")) { o.scheme=a.substring(9); if(!List.of("default","path","history").contains(o.scheme)) throw new IllegalArgumentException("invalid scoring scheme: "+o.scheme+" (expected: default|path|history)"); }
            else if (a.startsWith("--tiebreak=")) { o.tiebreak = new ArrayList<>(); for(String c:a.substring(11).split(",")){ if(!List.of("length","chunk","pathname","begin","end","index").contains(c)) throw new IllegalArgumentException("invalid sort criterion: "+c); o.tiebreak.add(c);} }
            else if (a.equals("--ansi")||a.equals("--sync")||a.equals("--multi")||a.equals("-m")||a.equals("--no-color")||a.equals("--no-bold")||a.equals("--height")||a.equals("--preview")||a.equals("--bind")||a.equals("--expect")||a.equals("--header")||a.equals("--header-lines")||a.equals("--layout")||a.equals("--border")||a.equals("--prompt")||a.equals("--color")||a.equals("--tmux")||a.equals("--style")) { if (needsValue(a) && i+1<args.size() && !args.get(i+1).startsWith("-")) i++; }
            else if (a.startsWith("--ansi")||a.startsWith("--sync")||a.startsWith("--multi")||a.startsWith("--height")||a.startsWith("--preview")||a.startsWith("--bind")||a.startsWith("--expect")||a.startsWith("--header")||a.startsWith("--layout")||a.startsWith("--border")||a.startsWith("--prompt")||a.startsWith("--color")||a.startsWith("--tmux")||a.startsWith("--style")||a.startsWith("--margin")||a.startsWith("--padding")||a.startsWith("--info")||a.startsWith("--pointer")||a.startsWith("--marker")||a.startsWith("--walker")||a.startsWith("--history")||a.startsWith("--preview-window")) {}
            else throw new IllegalArgumentException("unknown option: "+a);
        }
    }
    static boolean needsValue(String a){return Set.of("--height","--preview","--bind","--expect","--header","--header-lines","--layout","--prompt","--color","--tmux","--style").contains(a);}    
    static String need(List<String> a,int i,String msg){ if(i>=a.size()) throw new IllegalArgumentException(msg); return a.get(i); }
    static int parseInt(String s,String p){ try{return Integer.parseInt(s);}catch(Exception e){throw new IllegalArgumentException(p+s);} }
    static void validateExpr(String e){ for(String part:e.split(",")){ String p=part.trim(); if(p.equals("0")) throw new IllegalArgumentException("invalid format: 0"); }}
    static class Match { boolean ok; int score, begin=999999, end=-1; Match(boolean ok){this.ok=ok;} }
    static Match matchesQuery(String text, String query, Opts o) {
        if (o.disabled || query.isEmpty()) { Match m=new Match(true); m.score=0; m.begin=0; m.end=0; return m; }
        boolean ic = o.caseSet ? o.ignoreCase : !(o.smartCase && hasUpper(query));
        Match best = new Match(false);
        for (String group : splitOrGroups(query, o.extended)) {
            List<String> terms = splitTerms(group);
            Match total = new Match(true); total.score=0;
            for (String term: terms) {
                if (term.isEmpty()) continue;
                boolean inv=false; if (o.extended && term.startsWith("!") && term.length()>1) { inv=true; term=term.substring(1); }
                Match m = matchTerm(text, term, o, ic);
                if (inv) m.ok = !m.ok;
                if (!m.ok) { total.ok = false; break; }
                total.score += m.score; total.begin=Math.min(total.begin,m.begin); total.end=Math.max(total.end,m.end);
            }
            if (total.ok && (!best.ok || total.score > best.score)) best = total;
        }
        return best;
    }
    static Match matchTerm(String text, String term, Opts o, boolean ic) {
        String t = norm(text,o.literal), q = norm(term,o.literal);
        String tl = ic ? t.toLowerCase(Locale.ROOT) : t, ql = ic ? q.toLowerCase(Locale.ROOT) : q;
        boolean quoted = o.extended && ql.startsWith("'"); if (quoted) ql=ql.substring(1);
        if (o.extended && ql.startsWith("^") && ql.length()>1) { String x=ql.substring(1); Match m=new Match(tl.startsWith(x)); m.begin=0; m.end=x.length(); m.score=m.ok?10000-x.length():0; return m; }
        if (o.extended && ql.endsWith("$") && ql.length()>1) { String x=ql.substring(0,ql.length()-1); Match m=new Match(tl.endsWith(x)); m.begin=tl.length()-x.length(); m.end=tl.length(); m.score=m.ok?9000-x.length():0; return m; }
        if (o.exact || quoted) { int pos=tl.indexOf(ql); Match m=new Match(pos>=0); m.begin=pos; m.end=pos+ql.length(); m.score=m.ok?8000 - pos*4 - (tl.length()-ql.length()):0; return m; }
        return fuzzy(tl, ql);
    }
    static Match fuzzy(String text, String q) {
        int pos=0, first=-1,last=-1,gaps=0,score=0,consec=0;
        for(int i=0;i<q.length();i++) { char c=q.charAt(i); int found=-1; for(int j=pos;j<text.length();j++) if(text.charAt(j)==c){found=j;break;} if(found<0)return new Match(false); if(first<0)first=found; if(found==pos) consec++; else { gaps += found-pos; consec=1; } score += 100 + consec*15; if(found==0 || isSep(text.charAt(found-1))) score += 60; last=found; pos=found+1; }
        Match m=new Match(true); m.begin=first; m.end=last+1; m.score=score*10 - first*12 - gaps*5 - text.length(); if(first==0)m.score+=500; return m;
    }
    static int compareItems(Item a, Item b, Opts o){ int c=Integer.compare(b.score,a.score); if(c!=0)return c; for(String tb:o.tiebreak){ switch(tb){ case "length": c=Integer.compare(a.searchable.length(),b.searchable.length()); break; case "begin": c=Integer.compare(a.begin,b.begin); break; case "end": c=Integer.compare(b.end,a.end); break; case "pathname": c=Integer.compare(pathRank(a),pathRank(b)); break; case "index": c=Integer.compare(a.index,b.index); break; default: c=0;} if(c!=0)return c;} return Integer.compare(a.index,b.index); }
    static int pathRank(Item i){ int s=Math.max(i.original.lastIndexOf('/'), i.original.lastIndexOf('\\')); return i.begin>=s?0:1; }
    static boolean isSep(char c){ return Character.isWhitespace(c)||"/_-. ,:;".indexOf(c)>=0; }
    static boolean hasUpper(String s){ for(char c:s.toCharArray()) if(Character.isUpperCase(c)) return true; return false; }
    static String norm(String s, boolean lit){ if(lit)return s; String n=Normalizer.normalize(s, Normalizer.Form.NFD); return n.replaceAll("\\p{M}",""); }
    static List<String> splitTerms(String q){ List<String> r=new ArrayList<>(); StringBuilder b=new StringBuilder(); boolean esc=false; for(char c:q.toCharArray()){ if(esc){b.append(c);esc=false;} else if(c=='\\')esc=true; else if(Character.isWhitespace(c)){ if(b.length()>0){r.add(b.toString());b.setLength(0);} } else b.append(c);} if(b.length()>0)r.add(b.toString()); return r; }
    static List<String> splitOrGroups(String q, boolean extended){ if(!extended)return List.of(q); List<String> r=new ArrayList<>(); StringBuilder b=new StringBuilder(); boolean esc=false; for(char c:q.toCharArray()){ if(esc){b.append(c);esc=false;} else if(c=='\\'){b.append(c);esc=true;} else if(c=='|'){r.add(b.toString());b.setLength(0);} else b.append(c);} r.add(b.toString()); return r; }
    static List<String> splitInput(byte[] data, boolean nul){ List<String> r=new ArrayList<>(); int start=0; byte sep=(byte)(nul?0:'\n'); for(int i=0;i<data.length;i++) if(data[i]==sep){ r.add(new String(data,start,i-start,StandardCharsets.UTF_8)); start=i+1;} if(start<data.length) r.add(new String(data,start,data.length-start,StandardCharsets.UTF_8)); return r; }
    static String transform(String line, String expr, String delim, int idx){ if(expr==null) return line; if(expr.contains("{")) return template(line,expr,delim,idx); StringBuilder sb=new StringBuilder(); for(String p:expr.split(",")) sb.append(select(line,p.trim(),delim)); return stripLastDelim(sb.toString(),delim); }
    static String template(String line,String tpl,String delim,int idx){ Matcher m=Pattern.compile("\\{([^}]+)\\}").matcher(tpl); StringBuffer sb=new StringBuffer(); while(m.find()){ String key=m.group(1); String val=key.equals("n")?String.valueOf(idx):stripLastDelim(select(line,key,delim),delim); m.appendReplacement(sb, Matcher.quoteReplacement(val)); } m.appendTail(sb); return sb.toString(); }
    static String select(String line,String e,String delim){ List<String> fs=fields(line,delim); if(e.isEmpty())return""; if(e.contains("..")){ String[] p=e.split("\\.\\.",-1); int a=p[0].isEmpty()?1:Integer.parseInt(p[0]); int b=p.length<2||p[1].isEmpty()?fs.size():Integer.parseInt(p[1]); if(a<0)a=fs.size()+a+1; if(b<0)b=fs.size()+b+1; a=Math.max(1,a); b=Math.min(fs.size(),b); StringBuilder s=new StringBuilder(); for(int i=a;i<=b;i++)s.append(fs.get(i-1)); return s.toString(); } int n=Integer.parseInt(e); if(n<0)n=fs.size()+n+1; return n>=1&&n<=fs.size()?fs.get(n-1):""; }
    static List<String> fields(String line,String delim){ List<String> r=new ArrayList<>(); if(delim==null){ Matcher m=Pattern.compile("\\S+\\s*").matcher(line); while(m.find()) r.add(m.group()); return r.isEmpty()?List.of(""):r; } Pattern p=Pattern.compile(delim); int start=0; Matcher m=p.matcher(line); while(m.find()){ r.add(line.substring(start,m.end())); start=m.end(); } r.add(line.substring(start)); return r; }
    static String stripLastDelim(String s,String delim){ if(delim==null) return s.replaceFirst("\\s+$",""); try { Matcher m=Pattern.compile(delim+"$").matcher(s); return m.replaceFirst(""); } catch(Exception e){ return s; } }
    static List<String> shellSplit(String s){ List<String> r=new ArrayList<>(); StringBuilder b=new StringBuilder(); char quote=0; boolean esc=false; for(char c:s.toCharArray()){ if(esc){b.append(c);esc=false;} else if(c=='\\')esc=true; else if(quote!=0){ if(c==quote)quote=0; else b.append(c);} else if(c=='\''||c=='\"')quote=c; else if(Character.isWhitespace(c)){ if(b.length()>0){r.add(b.toString());b.setLength(0);} } else b.append(c);} if(b.length()>0)r.add(b.toString()); return r; }
    static void write(OutputStream out,String s)throws IOException{ out.write(s.getBytes(StandardCharsets.UTF_8)); }
    static void printResource(String name,String fb)throws IOException{ InputStream in=Main.class.getResourceAsStream("/"+name); if(in==null){System.out.print(fb);return;} System.out.write(in.readAllBytes()); }
    static String fallbackHelp(){return "fzf is an interactive filter program for any kind of list.\n\nUsage: fzf [options]\n";}
}
