package hushclone;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static final String VERSION = "Hush 0.1.4";

    public static void main(String[] argv) {
        try {
            int code = new Main().run(argv);
            System.exit(code);
        } catch (Panic p) {
            System.err.println(p.getMessage());
            System.exit(p.code);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] argv) throws Exception {
        boolean lex = false, ast = false, program = false, check = false;
        List<String> args = new ArrayList<>();
        for (String a : argv) {
            switch (a) {
                case "-h": case "--help": printHelp(); return 0;
                case "-V": case "--version": System.out.println(VERSION); return 0;
                case "--lex": lex = true; break;
                case "--ast": ast = true; break;
                case "--program": program = true; break;
                case "--check": check = true; break;
                default:
                    if (a.startsWith("-")) {
                        System.err.println("error: Found argument '" + a + "' which wasn't expected, or isn't valid in this context\n");
                        System.err.println("USAGE:\n    executable [FLAGS] [arguments]...\n");
                        System.err.println("For more information try --help");
                        return 1;
                    }
                    args.add(a);
            }
        }
        if (args.isEmpty()) return 0;
        Path script = Paths.get(args.get(0));
        if (!Files.exists(script)) return 0;
        String src = Files.readString(script);
        Lexer lx = new Lexer(args.get(0), src);
        List<Token> toks = lx.lex();
        Analyzer an = new Analyzer(args.get(0), src, toks);
        List<String> errors = an.errors();
        if (lex) {
            for (String e : lx.errors) System.err.println(e);
            printSep();
            for (Token t : toks) System.out.println(t.location() + ":\t" + t.display);
            for (String e : lx.shortErrors) System.out.println(e);
            printSep();
            for (String e : errors) System.err.println(e);
            return (lx.errors.isEmpty() && errors.isEmpty()) ? 0 : 2;
        }
        if (ast) {
            printSep();
            System.out.println("AST for " + args.get(0));
            for (String line : renderAst(src)) System.out.println(line);
            printSep();
            for (String e : errors) System.err.println(e);
            return errors.isEmpty() ? 0 : 2;
        }
        if (program) {
            printSep();
            System.out.println("Program for " + args.get(0));
            renderProgram(src);
            printSep();
            for (String e : errors) System.err.println(e);
            return errors.isEmpty() ? 0 : 2;
        }
        if (!lx.errors.isEmpty()) {
            for (String e : lx.errors) System.err.println(e);
            return 2;
        }
        if (!errors.isEmpty()) {
            for (String e : errors) System.err.println(e);
            return 2;
        }
        if (check) return 0;
        return new Interpreter(args.get(0), src, args.subList(1, args.size())).execute();
    }

    static void printSep() { System.out.println("--------------------------------------------------"); }

    static void printHelp() {
        System.out.println("Hush 0.1.4");
        System.out.println("gahag <gabriel.s.b@live.com>");
        System.out.println("Hush is a unix shell scripting language based on the Lua programming language\n");
        System.out.println("USAGE:");
        System.out.println("    executable [FLAGS] [arguments]...\n");
        System.out.println("FLAGS:");
        System.out.println("        --ast        Print the AST");
        System.out.println("        --check      Perform only static analysis instead of executing.");
        System.out.println("    -h, --help       Prints help information");
        System.out.println("        --lex        Print the lexemes");
        System.out.println("        --program    Print the PROGAM");
        System.out.println("    -V, --version    Prints version information\n");
        System.out.println("ARGS:");
        System.out.println("    <arguments>...    Script and/or arguments");
    }

    static List<String> renderAst(String src) {
        List<String> out = new ArrayList<>();
        for (String stmt : splitStatements(src)) {
            String s = stmt.trim();
            if (s.isEmpty() || s.startsWith("#")) continue;
            out.add(normalizeExpr(s));
        }
        return out;
    }

    static void renderProgram(String src) {
        int vars = 1;
        Map<String,Integer> ids = new LinkedHashMap<>();
        List<String> assigns = new ArrayList<>();
        for (String stmt : splitStatements(src)) {
            String s = stmt.trim();
            if (s.startsWith("let ")) {
                Matcher m = Pattern.compile("let\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s*=\\s*(.*))?", Pattern.DOTALL).matcher(s);
                if (m.matches()) {
                    ids.putIfAbsent(m.group(1), vars++);
                    assigns.add("#" + ids.get(m.group(1)) + " = " + (m.group(2) == null ? "nil" : normalizeExpr(m.group(2))));
                }
            } else {
                Matcher m = Pattern.compile("([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.*)", Pattern.DOTALL).matcher(s);
                if (m.matches()) {
                    ids.putIfAbsent(m.group(1), vars++);
                    assigns.add("#" + ids.get(m.group(1)) + " = " + normalizeExpr(m.group(2)));
                } else if (!s.isEmpty() && !s.startsWith("#")) assigns.add(normalizeExpr(s));
            }
        }
        System.out.println("let #0: auto");
        for (int i = 1; i < vars; i++) System.out.println("let #" + i + ": auto");
        for (String a : assigns) System.out.println(a);
    }

    static String normalizeExpr(String s) {
        return s.trim().replaceAll("\\s+", " ")
                .replaceAll("\\[\\s+", "[ ").replaceAll("\\s+\\]", " ]")
                .replaceAll("\\(\\s+", "(").replaceAll("\\s+\\)", ")");
    }

    static List<String> splitStatements(String src) {
        List<String> res = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int depth = 0; boolean sq=false,dq=false,comment=false;
        for (int i=0;i<src.length();i++) {
            char c=src.charAt(i);
            if (comment) { if (c=='\n') comment=false; continue; }
            if (!sq && !dq && c=='#') { comment=true; continue; }
            if (c=='\\' && (sq||dq) && i+1<src.length()) { cur.append(c).append(src.charAt(++i)); continue; }
            if (!dq && c=='\'') sq=!sq;
            else if (!sq && c=='"') dq=!dq;
            else if (!sq && !dq) {
                if ("([{".indexOf(c)>=0) depth++;
                if (")]}" .indexOf(c)>=0) depth=Math.max(0, depth-1);
                if ((c=='\n' || c==';') && depth==0) { res.add(cur.toString()); cur.setLength(0); continue; }
            }
            cur.append(c);
        }
        if (cur.length()>0) res.add(cur.toString());
        return res;
    }

    static class Token {
        String file, display; int line, col;
        Token(String f,int l,int c,String d){file=f;line=l;col=c;display=d;}
        String location(){return file+" (line "+line+", column "+col+")";}
    }

    static class Lexer {
        String file, src; List<String> errors=new ArrayList<>(), shortErrors=new ArrayList<>();
        Lexer(String f,String s){file=f;src=s;}
        List<Token> lex() {
            List<Token> r=new ArrayList<>(); int line=1,col=0;
            int cmdDepth = 0;
            for(int i=0;i<src.length();) {
                char c=src.charAt(i);
                if(c=='\n'){line++;col=0;i++;continue;}
                if(Character.isWhitespace(c)){i++;col++;continue;}
                if(c=='#'){while(i<src.length()&&src.charAt(i)!='\n'){i++;col++;}continue;}
                int startCol=col;
                if(c=='\''||c=='"'){
                    char q=c; StringBuilder raw=new StringBuilder(); raw.append(q); i++; col++; boolean bad=false;
                    while(i<src.length()){
                        char x=src.charAt(i); raw.append(x); i++; col++;
                        if(x=='\\' && i<src.length()){
                            char e=src.charAt(i);
                            if("'\"n0t\\$".indexOf(e)<0){ bad=true; String msg="invalid escape sequence '\\"+e+"'."; errors.add("Error: "+file+" (line "+line+", column "+col+") - "+msg); shortErrors.add("Error: line "+line+", column "+col+" - "+msg); }
                            raw.append(e); i++; col++; continue;
                        }
                        if(x==q) break;
                    }
                    if(bad) r.add(new Token(file,line,startCol,"'\\0'")); else r.add(new Token(file,line,startCol,raw.toString()));
                    continue;
                }
                if(Character.isDigit(c)){
                    int st=i; boolean dot=false;
                    while(i<src.length()&&(Character.isDigit(src.charAt(i))||src.charAt(i)=='.'||src.charAt(i)=='e'||src.charAt(i)=='E'||src.charAt(i)=='+'||src.charAt(i)=='-')){
                        if(src.charAt(i)=='.') dot=true; i++; col++;
                        if(i>st+1 && (src.charAt(i-1)=='+'||src.charAt(i-1)=='-') && !(src.charAt(i-2)=='e'||src.charAt(i-2)=='E')) {i--; col--; break;}
                    }
                    String num=src.substring(st,i);
                    try {
                        if(num.matches("[0-9]+[eE][+-]?[0-9]+")) num=Long.toString((long)Double.parseDouble(num));
                        else if(num.matches("[0-9]+\\.[0-9]+[eE][+-]?[0-9]+")) {
                            double d=Double.parseDouble(num); if(d==Math.rint(d)) num=Long.toString((long)d); else num=Double.toString(d);
                        }
                    } catch(Exception ignored){}
                    r.add(new Token(file,line,startCol,num)); continue;
                }
                if(Character.isLetter(c)||c=='_'){
                    int st=i; while(i<src.length()&&(Character.isLetterOrDigit(src.charAt(i))||src.charAt(i)=='_')){i++;col++;}
                    r.add(new Token(file,line,startCol,src.substring(st,i))); continue;
                }
                String two=i+1<src.length()?src.substring(i,i+2):"";
                if(Arrays.asList("==","!=","<=",">=","++","<<",">>","&&","||","->").contains(two)){r.add(new Token(file,line,startCol,two)); i+=2; col+=2; continue;}
                if(c=='{') { cmdDepth++; r.add(new Token(file,line,startCol,"{")); i++; col++; continue; }
                if(c=='}') {
                    if(cmdDepth>0){ cmdDepth--; r.add(new Token(file,line,startCol,"}")); i++; col++; continue; }
                }
                if(c=='@' && i+1<src.length() && src.charAt(i+1)=='['){r.add(new Token(file,line,startCol,"@")); i++; col++; continue;}
                if((c=='|' || c==';') && cmdDepth>0){r.add(new Token(file,line,startCol,String.valueOf(c))); i++; col++; continue;}
                if("()[]{}.,:+-*/%=<>?$&".indexOf(c)>=0){r.add(new Token(file,line,startCol,String.valueOf(c))); i++; col++; continue;}
                String msg="unexpected '"+c+"'.";
                errors.add("Error: "+file+" (line "+line+", column "+col+") - "+msg);
                shortErrors.add("Error: line "+line+", column "+col+" - "+msg);
                i++; col++;
            }
            return r;
        }
    }

    static class Analyzer {
        String file, src; List<Token> toks;
        Analyzer(String f,String s,List<Token> t){file=f;src=s;toks=t;}
        List<String> errors() {
            Set<String> declared=new HashSet<>(Arrays.asList("std","self","nil","true","false"));
            List<String> errs=new ArrayList<>();
            for(int i=0;i<toks.size();i++){
                Token t=toks.get(i);
                if(t.display.equals("let") && i+1<toks.size()) {declared.add(toks.get(i+1).display); i++; continue;}
                if(t.display.equals("function")) {
                    int j=i+1; if(j<toks.size() && toks.get(j).display.matches("[A-Za-z_].*")) {declared.add(toks.get(j).display); j++;}
                    while(j<toks.size() && !toks.get(j).display.equals(")")) { if(toks.get(j).display.matches("[A-Za-z_][A-Za-z0-9_]*")) declared.add(toks.get(j).display); j++; }
                }
                if(t.display.equals("$") && i+1<toks.size()) {
                    Token v=toks.get(i+1);
                    if(v.display.matches("[A-Za-z_][A-Za-z0-9_]*") && !declared.contains(v.display))
                        errs.add("Error: "+file+" (line "+v.line+", column "+v.col+") - undeclared variable '"+v.display+"'");
                }
            }
            return errs;
        }
    }

    static class Interpreter {
        String file, src; Map<String,Object> vars=new HashMap<>();
        Interpreter(String f,String s,List<String> args){file=f;src=s;vars.put("args", new ArrayList<>(args));}
        int execute() throws Exception {
            int status=0;
            for(String stmt: splitStatements(src)) {
                String s=stmt.trim(); if(s.isEmpty()) continue;
                if(s.startsWith("let ")) assign(s.substring(4).trim(), true);
                else if(s.matches("[A-Za-z_][A-Za-z0-9_]*\\s*=.*")) assign(s, false);
                else if(s.startsWith("{") && s.endsWith("}")) status=runBlock(s.substring(1,s.length()-1), false).status;
                else if(s.startsWith("return ")) return 0;
            }
            return status;
        }
        void assign(String s, boolean let) throws Exception {
            int eq=s.indexOf('=');
            if(eq<0){vars.put(s.trim(), null);return;}
            String name=s.substring(0,eq).trim();
            vars.put(name, eval(s.substring(eq+1).trim()));
        }
        Object eval(String e) throws Exception {
            e=e.trim();
            if (e.startsWith("(") && matchingOuter(e, '(', ')')) return eval(e.substring(1, e.length()-1));
            Matcher idx = Pattern.compile("(.+)\\[\\s*([0-9]+)\\s*\\]$").matcher(e);
            if (idx.matches()) {
                Object base = eval(idx.group(1));
                int n = Integer.parseInt(idx.group(2));
                if (base instanceof List && n >= 0 && n < ((List<?>)base).size()) return ((List<?>)base).get(n);
                return null;
            }
            if (e.startsWith("[") && e.endsWith("]")) {
                List<Object> list = new ArrayList<>();
                String inner = e.substring(1, e.length()-1).trim();
                if (!inner.isEmpty()) for (String part : splitComma(inner)) list.add(eval(part));
                return list;
            }
            if (e.startsWith("if ")) return evalIf(e);
            if(e.startsWith("${") && e.endsWith("}")) return runBlock(e.substring(2,e.length()-1), true);
            if(e.equals("nil")) return null; if(e.equals("true")) return true; if(e.equals("false")) return false;
            if((e.startsWith("\"")&&e.endsWith("\""))||(e.startsWith("'")&&e.endsWith("'"))) return unquote(e);
            if(e.matches("-?[0-9]+")) return Long.parseLong(e);
            if(e.matches("-?[0-9]+\\.[0-9]+")) return Double.parseDouble(e);
            int p=findTop(e,"++"); if(p>=0) return stringify(eval(e.substring(0,p)))+stringify(eval(e.substring(p+2)));
            for(String op:new String[]{"+","-","*","/"}) { p=findTop(e,op); if(p>0) return arith(eval(e.substring(0,p)), eval(e.substring(p+1)), op); }
            if(vars.containsKey(e)) return vars.get(e);
            return e;
        }
        Object evalIf(String e) throws Exception {
            int then = indexWordTop(e, "then", 0);
            int els = indexWordTop(e, "else", then + 4);
            int end = e.lastIndexOf("end");
            if (then < 0 || end < 0) return null;
            String cond = e.substring(2, then).trim();
            String a = e.substring(then + 4, els >= 0 ? els : end).trim();
            String b = els >= 0 ? e.substring(els + 4, end).trim() : "nil";
            Object cv = eval(cond);
            boolean ok = !(cv == null || Boolean.FALSE.equals(cv) || "false".equals(String.valueOf(cv)));
            return eval(ok ? a : b);
        }
        int indexWordTop(String e, String word, int from) {
            int d=0; boolean q=false,sq=false;
            for(int i=Math.max(0,from); i<=e.length()-word.length(); i++){
                char c=e.charAt(i);
                if(c=='"'&&!sq)q=!q; else if(c=='\''&&!q)sq=!sq;
                if(q||sq) continue;
                if(c=='('||c=='['||c=='{')d++; else if(c==')'||c==']'||c=='}')d--;
                if(d==0 && e.startsWith(word,i)
                        && (i==0 || !Character.isLetterOrDigit(e.charAt(i-1)))
                        && (i+word.length()==e.length() || !Character.isLetterOrDigit(e.charAt(i+word.length())))) return i;
            }
            return -1;
        }
        boolean matchingOuter(String e, char open, char close) {
            int d=0; boolean q=false,sq=false;
            for(int i=0;i<e.length();i++){
                char c=e.charAt(i);
                if(c=='"'&&!sq)q=!q; else if(c=='\''&&!q)sq=!sq;
                if(q||sq)continue;
                if(c==open)d++; else if(c==close)d--;
                if(d==0 && i<e.length()-1)return false;
            }
            return d==0;
        }
        List<String> splitComma(String s) {
            List<String> out = new ArrayList<>(); StringBuilder cur = new StringBuilder();
            int d=0; boolean q=false,sq=false;
            for(int i=0;i<s.length();i++){
                char c=s.charAt(i);
                if(c=='"'&&!sq)q=!q; else if(c=='\''&&!q)sq=!sq;
                if(!q&&!sq){ if(c=='('||c=='['||c=='{')d++; else if(c==')'||c==']'||c=='}')d--; else if(c==','&&d==0){out.add(cur.toString().trim());cur.setLength(0);continue;} }
                cur.append(c);
            }
            if(cur.length()>0)out.add(cur.toString().trim());
            return out;
        }
        int findTop(String e,String op){int d=0;boolean q=false,sq=false;for(int i=e.length()-op.length();i>=0;i--){char c=e.charAt(i);if(c=='"'&&!sq)q=!q;if(c=='\''&&!q)sq=!sq;if(q||sq)continue;if(c==')'||c==']'||c=='}')d++;if(c=='('||c=='['||c=='{')d--;if(d==0&&e.startsWith(op,i))return i;}return -1;}
        Object arith(Object a,Object b,String op){double x=Double.parseDouble(stringify(a)), y=Double.parseDouble(stringify(b)); double z=op.equals("+")?x+y:op.equals("-")?x-y:op.equals("*")?x*y:x/y; return z==Math.rint(z)?(long)z:z;}
        Capture runBlock(String body, boolean capture) throws Exception {
            String shell=toShell(body);
            Process p=new ProcessBuilder("bash","-lc",shell).redirectErrorStream(false).start();
            byte[] out=p.getInputStream().readAllBytes(), err=p.getErrorStream().readAllBytes();
            int st=p.waitFor();
            if(!capture){System.out.write(out);System.err.write(err);System.out.flush();System.err.flush();}
            return new Capture(st,new String(out,StandardCharsets.UTF_8),new String(err,StandardCharsets.UTF_8));
        }
        String toShell(String body) {
            String s=body;
            for(Map.Entry<String,Object> e:vars.entrySet()) s=s.replace("$"+e.getKey(), shellQuote(stringify(e.getValue())));
            return s;
        }
        String stringify(Object o){ if(o==null)return ""; if(o instanceof Capture)return ((Capture)o).stdout; if(o instanceof List)return o.toString(); return String.valueOf(o); }
        String shellQuote(String s){ return "'" + s.replace("'", "'\\''") + "'"; }
        String unquote(String s){String x=s.substring(1,s.length()-1);return x.replace("\\n","\n").replace("\\0","\0").replace("\\\"","\"").replace("\\'","'").replace("\\\\","\\");}
    }
    static class Capture { int status; String stdout, stderr; Capture(int s,String o,String e){status=s;stdout=o;stderr=e;} public String toString(){return stdout;} }
    static class Panic extends RuntimeException { int code; Panic(String m,int c){super(m);code=c;} }
}
