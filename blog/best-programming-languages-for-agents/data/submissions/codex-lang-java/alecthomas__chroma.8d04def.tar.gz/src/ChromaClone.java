import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class ChromaClone {
    static class Opt {
        List<String> files = new ArrayList<>();
        String lexer = "autodetect", style = "swapoff", formatter = "terminal", filename = null;
        boolean help, version, list, json, html, svg, check, fail, trace, unbuffered;
        boolean htmlOnly, htmlStyles, htmlAllStyles, htmlInline, htmlLines, htmlLinesTable, htmlPreventPre, htmlLinkable;
        int htmlTabWidth = 8, htmlBaseLine = 1;
        String htmlPrefix = "", htmlLinesStyle = "", htmlHighlight = "", htmlHighlightStyle = "";
    }

    static class Tok {
        String type, value, cls;
        Tok(String t, String v, String c) { type=t; value=v; cls=c; }
    }

    static final Set<String> JAVA_KD = set("abstract","assert","boolean","break","byte","case","catch","char","class","const","continue","default","do","double","else","enum","extends","final","finally","float","for","goto","if","implements","import","instanceof","int","interface","long","native","new","package","private","protected","public","return","short","static","strictfp","super","switch","synchronized","this","throw","throws","transient","try","void","volatile","while");
    static final Set<String> PY_K = set("False","None","True","and","as","assert","async","await","break","class","continue","def","del","elif","else","except","finally","for","from","global","if","import","in","is","lambda","nonlocal","not","or","pass","raise","return","try","while","with","yield");
    static final Set<String> JS_K = set("break","case","catch","class","const","continue","debugger","default","delete","do","else","export","extends","finally","for","function","if","import","in","instanceof","let","new","return","super","switch","this","throw","try","typeof","var","void","while","with","yield","async","await","of");
    static final Set<String> GO_K = set("break","default","func","interface","select","case","defer","go","map","struct","chan","else","goto","package","switch","const","fallthrough","if","range","type","continue","for","import","return","var");

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (CliError e) {
            System.err.println("executable: error: " + e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("executable: error: " + e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        Opt o = parse(args);
        if (o.help) { System.out.print(help()); return 0; }
        if (o.version) { System.out.println("?-?-?"); return 0; }
        if (o.list) { printList(); return 0; }
        if (o.json) o.formatter = "json";
        if (o.html) o.formatter = "html";
        if (o.svg) o.formatter = "svg";
        if (o.check && "swapoff".equals(o.style)) throw new CliError("open swapoff: no such file or directory", 1);

        if (o.files.isEmpty()) {
            String input = readAll(System.in);
            String lx = chooseLexer(o, o.filename, input);
            if (o.fail && "plaintext".equals(lx)) return 1;
            if ("swapoff".equals(o.style)) throw new CliError("open swapoff: no such file or directory", 1);
            if (o.check) return 0;
            output(o, lx, input);
            return 0;
        }
        for (String f : o.files) {
            Path p = Paths.get(f);
            if (!Files.exists(p)) throw new CliError("[<files> ...]: stat " + p.toAbsolutePath() + ": no such file or directory", 80);
            String input = Files.readString(p);
            String lx = chooseLexer(o, f, input);
            if (o.fail && "plaintext".equals(lx)) return 1;
            if ("swapoff".equals(o.style)) throw new CliError("open swapoff: no such file or directory", 1);
            if (!o.check) output(o, lx, input);
        }
        return 0;
    }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("-h")||a.equals("--help")) o.help=true;
            else if (a.equals("--version")) o.version=true;
            else if (a.equals("--list")) o.list=true;
            else if (a.equals("--json")) o.json=true;
            else if (a.equals("--html")) o.html=true;
            else if (a.equals("--svg")) o.svg=true;
            else if (a.equals("--check")) o.check=true;
            else if (a.equals("--fail")) o.fail=true;
            else if (a.equals("--trace")) o.trace=true;
            else if (a.equals("--unbuffered")) o.unbuffered=true;
            else if (a.equals("--html-only")) o.htmlOnly=true;
            else if (a.equals("--html-styles")) o.htmlStyles=true;
            else if (a.equals("--html-all-styles")) o.htmlAllStyles=true;
            else if (a.equals("--html-inline-styles")) o.htmlInline=true;
            else if (a.equals("--html-lines")) o.htmlLines=true;
            else if (a.equals("--html-lines-table")) { o.htmlLinesTable=true; o.htmlLines=true; }
            else if (a.equals("--html-prevent-surrounding-pre")) o.htmlPreventPre=true;
            else if (a.equals("--html-linkable-lines")) o.htmlLinkable=true;
            else if (a.equals("-l") || a.equals("--lexer")) o.lexer = need(args, ++i, a);
            else if (a.startsWith("--lexer=")) o.lexer = a.substring(8);
            else if (a.equals("-s") || a.equals("--style")) o.style = need(args, ++i, a);
            else if (a.startsWith("--style=")) o.style = a.substring(8);
            else if (a.equals("-f") || a.equals("--formatter")) o.formatter = need(args, ++i, a);
            else if (a.startsWith("--formatter=")) o.formatter = a.substring(12);
            else if (a.startsWith("--filename=")) o.filename = a.substring(11);
            else if (a.equals("--filename")) o.filename = need(args, ++i, a);
            else if (a.startsWith("--html-prefix=")) o.htmlPrefix = a.substring(14);
            else if (a.startsWith("--html-tab-width=")) o.htmlTabWidth = intVal(a.substring(17), "html-tab-width");
            else if (a.startsWith("--html-base-line=")) o.htmlBaseLine = intVal(a.substring(17), "html-base-line");
            else if (a.startsWith("--html-lines-style=")) o.htmlLinesStyle = a.substring(19);
            else if (a.startsWith("--html-highlight=")) o.htmlHighlight = a.substring(17);
            else if (a.startsWith("--html-highlight-style=")) o.htmlHighlightStyle = a.substring(23);
            else if (a.startsWith("-")) throw new CliError("unknown flag " + a, 1);
            else o.files.add(a);
        }
        return o;
    }

    static void output(Opt o, String lx, String input) throws IOException {
        List<Tok> toks = lex(lx, input);
        switch (o.formatter.toLowerCase(Locale.ROOT)) {
            case "noop": System.out.print(input); break;
            case "tokens": for (Tok t:toks) System.out.println("&Token{"+t.type+", "+quoteGo(t.value)+"}"); break;
            case "json": json(toks); break;
            case "html": html(o, toks); break;
            case "svg": svg(toks); break;
            case "terminal256": terminal(toks, true); break;
            case "terminal":
            default: terminal(toks, false); break;
        }
    }

    static List<Tok> lex(String lx, String s) {
        if (lx.equals("python") || lx.equals("py")) return lexCode(s, PY_K, "python");
        if (lx.equals("java")) return lexCode(s, JAVA_KD, "java");
        if (lx.equals("javascript") || lx.equals("js") || lx.equals("typescript") || lx.equals("ts")) return lexCode(s, JS_K, "js");
        if (lx.equals("go") || lx.equals("golang")) return lexCode(s, GO_K, "go");
        if (lx.equals("json")) return lexJson(s);
        if (lx.equals("markdown") || lx.equals("md")) return lexMarkdown(s);
        if (lx.equals("bash") || lx.equals("shell") || lx.equals("sh")) return lexCode(s, set("if","then","else","fi","for","in","do","done","case","esac","while","function","echo","export","local","return"), "sh");
        return Collections.singletonList(new Tok("Text", s, ""));
    }

    static List<Tok> lexCode(String s, Set<String> kws, String lang) {
        ArrayList<Tok> out = new ArrayList<>();
        int i=0; boolean expectFunc=false, expectClass=false;
        while (i<s.length()) {
            char c=s.charAt(i);
            if (Character.isWhitespace(c)) { int j=i+1; while(j<s.length()&&Character.isWhitespace(s.charAt(j)))j++; out.add(new Tok(s.substring(i,j).contains("\n")?"Text":"TextWhitespace", s.substring(i,j), "")); i=j; }
            else if (c=='/' && i+1<s.length() && s.charAt(i+1)=='/') { int j=lineEnd(s,i); out.add(new Tok("CommentSingle", s.substring(i,j), "c1")); i=j; }
            else if (c=='#' && (lang.equals("python")||lang.equals("sh"))) { int j=lineEnd(s,i); out.add(new Tok("CommentSingle", s.substring(i,j), "c1")); i=j; }
            else if ((c=='/'&&i+1<s.length()&&s.charAt(i+1)=='*')) { int j=s.indexOf("*/",i+2); j=j<0?s.length():j+2; out.add(new Tok("CommentMultiline", s.substring(i,j), "cm")); i=j; }
            else if (c=='"' || c=='\'' || c=='`') { int j=stringEnd(s,i,c); out.add(new Tok("LiteralString", s.substring(i,j), "s")); i=j; }
            else if (Character.isDigit(c)) { int j=i+1; while(j<s.length()&&(Character.isDigit(s.charAt(j))||s.charAt(j)=='.'||Character.isLetter(s.charAt(j))))j++; out.add(new Tok("LiteralNumberInteger", s.substring(i,j), "mi")); i=j; }
            else if (isIdentStart(c)) {
                int j=i+1; while(j<s.length()&&isIdent(s.charAt(j)))j++;
                String w=s.substring(i,j);
                int k = j; while (k<s.length() && Character.isWhitespace(s.charAt(k))) k++;
                boolean callLike = k<s.length() && s.charAt(k)=='(';
                if (expectFunc || callLike) { out.add(new Tok("NameFunction", w, "nf")); expectFunc=false; }
                else if (expectClass) { out.add(new Tok("NameClass", w, "nc")); expectClass=false; }
                else if (kws.contains(w)) {
                    String type = (w.equals("class")||w.equals("public")||w.equals("static")||w.equals("void")||w.equals("private")||w.equals("protected")||w.equals("final")||w.equals("int")||w.equals("boolean")||w.equals("String")) ? "KeywordDeclaration" : "Keyword";
                    out.add(new Tok(type, w, "k"));
                    if (w.equals("def")||w.equals("function")||w.equals("func")) expectFunc=true;
                    if (w.equals("class")) expectClass=true;
                } else out.add(new Tok("Name", w, "n"));
                i=j;
            } else {
                int j=i+1; while(j<s.length()&&!Character.isWhitespace(s.charAt(j))&&!Character.isDigit(s.charAt(j))&&!isIdentStart(s.charAt(j))&&"\"'`#".indexOf(s.charAt(j))<0) j++;
                String v=s.substring(i,j);
                String type = v.matches("[+\\-*/%=!<>|&~^]+") ? "Operator" : "Punctuation";
                out.add(new Tok(type, v, type.equals("Operator")?"o":"p")); i=j;
            }
        }
        return out;
    }

    static List<Tok> lexJson(String s) {
        ArrayList<Tok> out = new ArrayList<>(); int i=0;
        while(i<s.length()) {
            char c=s.charAt(i);
            if(Character.isWhitespace(c)){int j=i+1;while(j<s.length()&&Character.isWhitespace(s.charAt(j)))j++;out.add(new Tok("TextWhitespace",s.substring(i,j),""));i=j;}
            else if(c=='"'){int j=stringEnd(s,i,c);out.add(new Tok("LiteralStringDouble",s.substring(i,j),"s2"));i=j;}
            else if(Character.isDigit(c)||c=='-'){int j=i+1;while(j<s.length()&&"0123456789.eE+-".indexOf(s.charAt(j))>=0)j++;out.add(new Tok("LiteralNumber",s.substring(i,j),"m"));i=j;}
            else if(s.startsWith("true",i)||s.startsWith("false",i)||s.startsWith("null",i)){int j=i+(s.startsWith("true",i)||s.startsWith("null",i)?4:5);out.add(new Tok("KeywordConstant",s.substring(i,j),"kc"));i=j;}
            else {out.add(new Tok("Punctuation",String.valueOf(c),"p"));i++;}
        }
        return out;
    }

    static List<Tok> lexMarkdown(String s) {
        ArrayList<Tok> out = new ArrayList<>();
        for (String part : s.split("(?<=\\n)", -1)) {
            if (part.startsWith("#")) out.add(new Tok("GenericHeading", part, "gh"));
            else out.add(new Tok("Text", part, ""));
        }
        return out;
    }

    static void terminal(List<Tok> toks, boolean x256) {
        for (Tok t:toks) {
            if (t.value.isEmpty()) continue;
            String code = x256 ? ansi256(t.cls) : ansi16(t.cls);
            if (code.isEmpty()) System.out.print(t.value); else System.out.print(code + t.value + "\u001b[0m");
        }
    }
    static String ansi16(String c) {
        if (c.equals("k")) return "\u001b[1m\u001b[36m";
        if (c.equals("nf")||c.equals("nc")) return "\u001b[1m\u001b[33m";
        if (c.equals("s")||c.equals("s2")) return "\u001b[32m";
        if (c.equals("mi")||c.equals("m")) return "\u001b[33m";
        if (c.equals("o")) return "\u001b[1m\u001b[31m";
        if (c.startsWith("c")) return "\u001b[90m";
        return "\u001b[1m\u001b[37m";
    }
    static String ansi256(String c) {
        if (c.equals("k")) return "\u001b[38;5;81m";
        if (c.equals("nf")||c.equals("nc")) return "\u001b[38;5;148m";
        if (c.equals("s")||c.equals("s2")) return "\u001b[38;5;186m";
        if (c.equals("mi")||c.equals("m")) return "\u001b[38;5;141m";
        if (c.equals("o")) return "\u001b[38;5;197m";
        if (c.startsWith("c")) return "\u001b[38;5;245m";
        return "\u001b[38;5;231m";
    }

    static void json(List<Tok> toks) {
        System.out.println("[");
        for (int i=0;i<toks.size();i++) {
            Tok t=toks.get(i);
            System.out.print("  {\"type\":\""+escJson(t.type)+"\",\"value\":\""+escJson(t.value)+"\"}");
            System.out.println(i+1<toks.size()?",":"");
        }
        System.out.println("]");
    }

    static void html(Opt o, List<Tok> toks) {
        if (!o.htmlOnly) {
            System.out.println("<html>");
            printCss();
            System.out.println("<body>");
        } else if (o.htmlStyles || o.htmlAllStyles) {
            printCss();
        }
        if (o.htmlPreventPre) System.out.print("<code>");
        else System.out.print("<pre class=\""+o.htmlPrefix+"chroma\"><code>");
        List<List<Tok>> lines = splitLines(toks);
        for (int i=0;i<lines.size();i++) {
            System.out.print("<span class=\"line\">");
            if (o.htmlLines) {
                int n=o.htmlBaseLine+i;
                String ln = String.valueOf(n);
                if (o.htmlLinkable) System.out.print("<a class=\"lnlinks\" href=\"#"+n+"\" id=\""+n+"\"><span class=\"ln\">"+ln+"</span></a>");
                else System.out.print("<span class=\"ln\">"+ln+"</span>");
            }
            System.out.print("<span class=\"cl\">");
            for (Tok t: lines.get(i)) printHtmlTok(o, t);
            System.out.print("</span></span>");
        }
        if (o.htmlPreventPre) System.out.print("</code>"); else System.out.print("</code></pre>");
        if (!o.htmlOnly) System.out.println("</body>\n</html>");
    }

    static void printHtmlTok(Opt o, Tok t) {
        String v=htmlEsc(t.value);
        if (t.cls.isEmpty()) System.out.print(v);
        else if (o.htmlInline) System.out.print("<span style=\""+styleFor(t.cls)+"\">"+v+"</span>");
        else System.out.print("<span class=\""+t.cls+"\">"+v+"</span>");
    }
    static void printCss() {
        System.out.println("<style type=\"text/css\">");
        System.out.println("/* Background */ .bg { color: #f8f8f2; background-color: #272822; }");
        System.out.println("/* PreWrapper */ .chroma { color: #f8f8f2; background-color: #272822; -webkit-text-size-adjust: none; }");
        System.out.println("/* Line */ .chroma .line { display: flex; }");
        System.out.println("/* Keyword */ .chroma .k { color: #66d9ef }");
        System.out.println("/* NameClass */ .chroma .nc { color: #a6e22e }");
        System.out.println("/* NameFunction */ .chroma .nf { color: #a6e22e }");
        System.out.println("/* Operator */ .chroma .o { color: #f92672 }");
        System.out.println("/* LiteralNumberInteger */ .chroma .mi { color: #ae81ff }");
        System.out.println("/* LiteralString */ .chroma .s { color: #e6db74 }");
        System.out.println("/* Comment */ .chroma .c1, .chroma .cm { color: #75715e }");
        System.out.println("</style>");
    }
    static String styleFor(String c) {
        if (c.equals("k")) return "color:#66d9ef";
        if (c.equals("nf")||c.equals("nc")) return "color:#a6e22e";
        if (c.equals("o")) return "color:#f92672";
        if (c.equals("mi")||c.equals("m")) return "color:#ae81ff";
        if (c.startsWith("s")) return "color:#e6db74";
        if (c.startsWith("c")) return "color:#75715e";
        return "";
    }

    static void svg(List<Tok> toks) {
        String text = htmlEsc(joinValues(toks));
        System.out.println("<svg xmlns=\"http://www.w3.org/2000/svg\"><text x=\"0\" y=\"15\">"+text+"</text></svg>");
    }

    static String chooseLexer(Opt o, String name, String input) {
        if (o.lexer != null && !o.lexer.equals("autodetect")) return normLexer(o.lexer);
        String n = name==null?"":name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".java")) return "java";
        if (n.endsWith(".py")||n.endsWith(".pyw")) return "python";
        if (n.endsWith(".js")||n.endsWith(".mjs")||n.endsWith(".jsx")) return "javascript";
        if (n.endsWith(".ts")||n.endsWith(".tsx")) return "typescript";
        if (n.endsWith(".go")) return "go";
        if (n.endsWith(".json")) return "json";
        if (n.endsWith(".md")||n.endsWith(".markdown")) return "markdown";
        if (n.endsWith(".sh")||n.endsWith(".bash")||n.endsWith(".zsh")) return "bash";
        String t=input.trim();
        if (t.startsWith("{")||t.startsWith("[")) return "json";
        if (t.startsWith("#!") && t.contains("python")) return "python";
        return "plaintext";
    }
    static String normLexer(String l) {
        l=l.toLowerCase(Locale.ROOT);
        if (l.equals("py")) return "python";
        if (l.equals("js")) return "javascript";
        if (l.equals("md")) return "markdown";
        if (l.equals("sh")||l.equals("shell")) return "bash";
        return l;
    }

    static void printList() {
        String[][] lex = {{"ABAP","abap","*.abap *.ABAP","text/x-abap"},{"Bash","bash sh shell","*.sh *.bash","application/x-sh text/x-sh"},{"C","c","*.c *.h","text/x-csrc"},{"C++","cpp c++","*.cpp *.hpp *.cc","text/x-c++src"},{"CSS","css","*.css","text/css"},{"Go","go golang","*.go","text/x-gosrc"},{"HTML","html","*.html *.htm","text/html"},{"Java","java","*.java","text/x-java"},{"JavaScript","js javascript","*.js *.mjs","application/javascript"},{"JSON","json","*.json","application/json"},{"markdown","md markdown","*.md *.markdown","text/x-markdown"},{"Python","python py","*.py *.pyw","text/x-python"},{"Ruby","ruby rb","*.rb","text/x-ruby"},{"Rust","rust rs","*.rs","text/x-rust"},{"XML","xml","*.xml","text/xml"},{"YAML","yaml yml","*.yaml *.yml","text/x-yaml"}};
        System.out.println("lexers:");
        for (String[] x:lex) { System.out.println("  "+x[0]); System.out.println("    aliases: "+x[1]); System.out.println("    filenames: "+x[2]); System.out.println("    mimetypes: "+x[3]); }
        System.out.println("styles:");
        for (String s: Arrays.asList("abap","algol","api","autumn","borland","bw","colorful","dracula","emacs","friendly","github","hrdark","igor","lovelace","monokai","monokailight","murphy","native","paraiso-dark","paraiso-light","pastie","perldoc","pygments","rainbow_dash","rrt","solarized-dark","solarized-dark256","solarized-light","swapoff","tango","trac","vim","vs","xcode")) System.out.println("  "+s);
        System.out.println("formatters:");
        for (String f: Arrays.asList("html","json","noop","svg","terminal","terminal16m","terminal256","tokens")) System.out.println("  "+f);
    }

    static String help() {
        return "Usage: executable [<files> ...] [flags]\n\n"+
        "Chroma is a general purpose syntax highlighting library and corresponding\ncommand, for Go.\n\n"+
        "Arguments:\n  [<files> ...]    Files to highlight.\n\n"+
        "Flags:\n  -h, --help               Show context-sensitive help.\n      --version            Show version.\n      --list               List lexers, styles and formatters.\n      --unbuffered         Do not buffer output.\n      --trace              Trace lexer states as they are traversed.\n      --check              Do not format, check for tokenisation errors instead.\n      --filename=STRING    Filename to use for selecting a lexer when reading\n                           from stdin.\n      --fail               Exit silently with status 1 if no specific lexer was\n                           found.\n\n"+
        "Select lexer and style:\n  -l, --lexer=\"autodetect\"    Lexer to use when formatting or path to an XML\n                              file to load.\n  -s, --style=\"swapoff\"       Style to use for formatting or path to an XML file\n                              to load.\n\n"+
        "Output format:\n  -f, --formatter=\"terminal\"    Formatter to use.\n      --json                    Convenience flag to use JSON formatter.\n      --html                    Convenience flag to use HTML formatter.\n      --svg                     Convenience flag to use SVG formatter.\n\n"+
        "HTML formatter options:\n  --html-prefix=PREFIX             HTML CSS class prefix.\n  --html-styles                    Output HTML CSS styles.\n  --html-all-styles                Output all HTML CSS styles, including\n                                   redundant ones.\n  --html-only                      Output HTML fragment.\n  --html-inline-styles             Output HTML with inline styles (no classes).\n  --html-tab-width=8               Set the HTML tab width.\n  --html-lines                     Include line numbers in output.\n  --html-lines-table               Split line numbers and code in a HTML table\n  --html-lines-style=STRING        Style for line numbers.\n  --html-highlight=N[:M][,...]     Highlight these lines.\n  --html-highlight-style=STRING    Style used for highlighting lines.\n  --html-base-line=1               Base line number.\n  --html-prevent-surrounding-pre\n                                   Prevent the surrounding pre tag.\n  --html-linkable-lines            Make the line numbers linkable and be a link\n                                   to themselves.\n";
    }

    static List<List<Tok>> splitLines(List<Tok> toks) {
        ArrayList<List<Tok>> lines = new ArrayList<>(); lines.add(new ArrayList<>());
        for (Tok t:toks) {
            String[] parts=t.value.split("(?<=\\n)", -1);
            for (int i=0;i<parts.length;i++) {
                if (i>0) lines.add(new ArrayList<>());
                if (!parts[i].isEmpty()) lines.get(lines.size()-1).add(new Tok(t.type, parts[i], t.cls));
            }
        }
        if (lines.size()>1 && lines.get(lines.size()-1).isEmpty()) lines.remove(lines.size()-1);
        return lines;
    }
    static String readAll(InputStream in) throws IOException { return new String(in.readAllBytes(), StandardCharsets.UTF_8); }
    static Set<String> set(String... s) { return new HashSet<>(Arrays.asList(s)); }
    static String need(String[] a, int i, String flag) throws CliError { if (i>=a.length) throw new CliError(flag+" must have a value",1); return a[i]; }
    static int intVal(String s, String flag) throws CliError { try { return Integer.parseInt(s); } catch(Exception e){ throw new CliError("invalid value "+s+" for "+flag,1);} }
    static int lineEnd(String s,int i){int j=s.indexOf('\n',i);return j<0?s.length():j;}
    static int stringEnd(String s,int i,char q){int j=i+1;while(j<s.length()){char c=s.charAt(j++);if(c=='\\'&&j<s.length())j++;else if(c==q)break;}return j;}
    static boolean isIdentStart(char c){return Character.isLetter(c)||c=='_'||c=='$';}
    static boolean isIdent(char c){return Character.isLetterOrDigit(c)||c=='_'||c=='$';}
    static String quoteGo(String s){return "\""+s.replace("\\","\\\\").replace("\n","\\n").replace("\t","\\t").replace("\"","\\\"")+"\"";}
    static String escJson(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t");}
    static String htmlEsc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&#34;");}
    static String joinValues(List<Tok> toks){StringBuilder b=new StringBuilder();for(Tok t:toks)b.append(t.value);return b.toString();}

    static class CliError extends Exception { int code; CliError(String m,int c){super(m);code=c;} }
}
