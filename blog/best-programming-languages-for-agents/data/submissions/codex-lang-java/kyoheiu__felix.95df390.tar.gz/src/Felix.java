import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Felix {
    private static final String INVALID_HELP = "`fx -h` shows help.";

    public static void main(String[] args) {
        try {
            int code = new Felix().run(args);
            if (code != 0) System.exit(code);
        } catch (Throwable t) {
            System.err.println("Error: " + (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage()));
        }
    }

    private int run(String[] args) throws Exception {
        if (args.length > 2) {
            printHelp();
            return 0;
        }
        if (args.length == 2) {
            if (isLog(args[0])) {
                Path p = validatePath(args[1]);
                if (p == null) return 0;
                createLog();
                return launch(p);
            }
            printHelp();
            return 0;
        }
        if (args.length == 1) {
            String a = args[0];
            if (isHelp(a)) {
                printHelp();
                return 0;
            }
            if ("--init".equals(a)) {
                printInit();
                return 0;
            }
            if (isLog(a)) {
                createLog();
                return launch(Paths.get(".").toAbsolutePath().normalize());
            }
            Path p = validatePath(a);
            if (p == null) return 0;
            return launch(p);
        }
        return launch(Paths.get(".").toAbsolutePath().normalize());
    }

    private boolean isHelp(String a) { return "-h".equals(a) || "--help".equals(a); }
    private boolean isLog(String a) { return "-l".equals(a) || "--log".equals(a); }

    private Path validatePath(String arg) {
        Path p = Paths.get(arg);
        if (!Files.exists(p)) {
            System.err.println("Invalid path: " + arg);
            System.err.println(INVALID_HELP);
            return null;
        }
        if (!Files.isDirectory(p)) {
            System.err.println("Path should be directory.");
            System.err.println(INVALID_HELP);
            return null;
        }
        return p.toAbsolutePath().normalize();
    }

    private void printHelp() throws IOException {
        try (InputStream in = Felix.class.getResourceAsStream("/help.txt")) {
            if (in != null) {
                in.transferTo(System.out);
                return;
            }
        }
        System.out.print("# felix v2.16.1\nA simple TUI file manager with vim-like keymapping.\n");
    }

    private void printInit() {
        System.out.print("# To be eval'ed in the calling shell\n" +
                "  eval \"$(\n" +
                "    if [ -n \"$XDG_RUNTIME_DIR\" ]; then\n" +
                "      runtime_dir=\"$XDG_RUNTIME_DIR/felix\"\n" +
                "    elif [ -n \"$TMPDIR\" ]; then\n" +
                "      runtime_dir=\"$TMPDIR/felix\"\n" +
                "    else\n" +
                "      runtime_dir=/tmp/felix\n" +
                "    fi\n\n" +
                "    mkdir -p \"$runtime_dir\"\n\n" +
                "    # Clean up leftover LWD files\n" +
                "    find \"$runtime_dir\" -type f -and -mmin +1 -delete\n\n" +
                "    cat << EOF\n" +
                "fx() {\n" +
                "  local RUNTIME_DIR=\"$runtime_dir\"\n" +
                "  SHELL_PID=\\$\\$ command fx \"\\$@\"\n\n" +
                "  if [ -f \"\\$RUNTIME_DIR/\\$\\$\" ]; then\n" +
                "    cd \"\\$(cat \"\\$RUNTIME_DIR/\\$\\$\")\"\n" +
                "    rm \"\\$RUNTIME_DIR/\\$\\$\"\n" +
                "  fi\n" +
                "}\n" +
                "EOF\n" +
                "  )\"\n");
    }

    private void createLog() {
        try {
            Path dir = dataHome().resolve("felix").resolve("log");
            Files.createDirectories(dir);
            // The real application also prepares the trash directory when starting.
            Files.createDirectories(dataHome().resolve("felix").resolve("Trash"));
            Path config = configHome().resolve("felix");
            Files.createDirectories(config);
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss"));
            Path file = dir.resolve(stamp + ".log");
            String line = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + " [INFO] ===START===\n";
            Files.writeString(file, line, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
        } catch (IOException ignored) {
        }
    }

    private Path dataHome() {
        String xdg = System.getenv("XDG_DATA_HOME");
        if (xdg != null && !xdg.isEmpty()) return Paths.get(xdg);
        String home = System.getenv().getOrDefault("HOME", ".");
        return Paths.get(home, ".local", "share");
    }

    private Path configHome() {
        String xdg = System.getenv("XDG_CONFIG_HOME");
        if (xdg != null && !xdg.isEmpty()) return Paths.get(xdg);
        String home = System.getenv().getOrDefault("HOME", ".");
        return Paths.get(home, ".config");
    }

    private int launch(Path dir) throws Exception {
        int[] size = terminalSize();
        if (size == null) {
            System.err.println("Error: Cannot detect terminal size");
            return 0;
        }
        if (size[0] < 10 || size[1] < 40) {
            System.out.print("Error: Too small window size\r\n");
            return 0;
        }
        interactive(dir, size[0], size[1]);
        return 0;
    }

    private int[] terminalSize() {
        try {
            Process p = new ProcessBuilder("bash", "-lc", "stty size < /dev/tty").redirectErrorStream(true).start();
            String s = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            p.waitFor();
            String[] parts = s.split("\\s+");
            if (parts.length >= 2) return new int[]{Integer.parseInt(parts[0]), Integer.parseInt(parts[1])};
        } catch (Exception ignored) {
        }
        return null;
    }

    private void interactive(Path dir, int rows, int cols) throws Exception {
        boolean raw = setRaw(true);
        try {
            render(dir, rows, cols, 0);
            InputStream in = System.in;
            StringBuilder command = new StringBuilder();
            boolean colon = false;
            int b;
            while ((b = in.read()) != -1) {
                char c = (char) b;
                if (c == 3 || c == 4 || c == 'q') break;
                if (c == 'Z') {
                    int n = in.read();
                    if (n == 'Z' || n == 'Q') break;
                }
                if (c == ':') {
                    colon = true;
                    command.setLength(0);
                    status(":" , rows);
                    continue;
                }
                if (colon) {
                    if (c == '\r' || c == '\n') {
                        String cmd = command.toString().trim();
                        if (cmd.equals("q") || cmd.equals("quit")) break;
                        if (cmd.equals("h") || cmd.equals("help")) {
                            clear();
                            printHelp();
                            break;
                        }
                        colon = false;
                        render(dir, rows, cols, 0);
                    } else if (c == 27) {
                        colon = false;
                        render(dir, rows, cols, 0);
                    } else if (c == 127 || c == 8) {
                        if (command.length() > 0) command.setLength(command.length() - 1);
                        status(":" + command, rows);
                    } else if (!Character.isISOControl(c)) {
                        command.append(c);
                        status(":" + command, rows);
                    }
                }
            }
        } finally {
            if (raw) setRaw(false);
            System.out.print("\033[?25h\033[?1049l");
            System.out.flush();
        }
    }

    private boolean setRaw(boolean raw) {
        try {
            String cmd = raw ? "stty raw -echo < /dev/tty" : "stty sane < /dev/tty";
            Process p = new ProcessBuilder("bash", "-lc", cmd).start();
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void clear() {
        System.out.print("\033[?25l\033[?1049h\033[2J\033[1;1H");
    }

    private void render(Path dir, int rows, int cols, int selected) throws IOException {
        clear();
        System.out.print("\033[38;5;6m " + dir + "\033[0m");
        List<Path> entries = listEntries(dir);
        int line = 3;
        for (int i = 0; i < entries.size() && line < rows; i++, line++) {
            Path p = entries.get(i);
            String name = p.getFileName().toString();
            if (Files.isDirectory(p)) name += "/";
            if (i == selected) System.out.print("\033[" + line + ";1H>");
            System.out.print("\033[" + line + ";3H");
            if (Files.isDirectory(p)) System.out.print("\033[38;5;14m");
            else if (Files.isExecutable(p)) System.out.print("\033[38;5;1m");
            else System.out.print("\033[38;5;15m");
            System.out.print(trim(name, Math.max(10, cols - 4)) + "\033[0m");
        }
        String mode = entries.isEmpty() ? " 0/0" : " 1/" + entries.size();
        status(mode, rows);
    }

    private void status(String text, int rows) {
        System.out.print("\033[" + rows + ";1H\033[2K\033[7m" + text + "\033[0m");
        System.out.flush();
    }

    private String trim(String s, int max) {
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(0, max - 1)) + "~";
    }

    private List<Path> listEntries(Path dir) throws IOException {
        List<Path> dirs = new ArrayList<>();
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p : ds) {
                String n = p.getFileName().toString();
                if (n.startsWith(".")) continue;
                if (Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) dirs.add(p); else files.add(p);
            }
        }
        Comparator<Path> cmp = Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT));
        dirs.sort(cmp); files.sort(cmp);
        dirs.addAll(files);
        return dirs;
    }
}
