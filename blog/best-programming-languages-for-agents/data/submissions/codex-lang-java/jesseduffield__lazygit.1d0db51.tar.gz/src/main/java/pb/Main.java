package pb;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Main {
    private static final String VERSION =
            "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1";

    private static final Set<String> VALID_PANELS = new HashSet<>(Arrays.asList("status", "branch", "log", "stash"));
    private static final Set<String> SCREEN_MODES = new HashSet<>(Arrays.asList("normal", "half", "full"));

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (Exception e) {
            System.err.println(timestamp() + " " + e.getMessage());
            System.exit(1);
        }
    }

    private int run(String[] args) throws Exception {
        Options options = parse(args);
        if (options.parseError != null) {
            printHelp(System.err);
            System.err.println();
            System.err.println(options.parseError);
            return 2;
        }

        if (options.help) {
            printHelp(System.out);
            return 0;
        }
        if (options.version) {
            System.out.println(VERSION);
            return 0;
        }
        if (options.printConfigDir) {
            System.out.println(options.configDir != null ? options.configDir : defaultConfigDir());
            return 0;
        }
        if (options.printConfig) {
            printResource("default_config.yml");
            return 0;
        }
        if (options.logs) {
            String logPath = System.getProperty("user.home") + "/.local/state/lazygit/development.log";
            System.out.println("Tailing log file " + logPath);
            System.out.println();
            if (!Files.exists(Path.of(logPath))) {
                System.err.println(timestamp() + " Log file does not exist. Run `lazygit --debug` first to create the log file");
                return 1;
            }
            Files.lines(Path.of(logPath)).forEach(System.out::println);
            return 0;
        }

        if (options.gitArg != null && !VALID_PANELS.contains(options.gitArg)) {
            System.err.println(timestamp() + " Invalid git arg value: '" + options.gitArg
                    + "'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.");
            return 1;
        }

        Path repoPath = options.path != null ? Path.of(options.path) : Path.of("").toAbsolutePath();
        if (options.path != null && !isGitRepository(repoPath)) {
            System.err.println(timestamp() + " " + options.path + " is not a valid git repository.");
            return 1;
        }
        if (System.console() == null) {
            printTerminalError();
            return 1;
        }

        System.out.println("lazygit");
        System.out.println("A terminal UI is not implemented in this cleanroom reimplementation.");
        return 0;
    }

    private Options parse(String[] args) {
        Options options = new Options();
        List<String> positionals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            String valueFromEquals = null;
            String flag = arg;
            int eq = arg.indexOf('=');
            if (arg.startsWith("-") && eq >= 0) {
                flag = arg.substring(0, eq);
                valueFromEquals = arg.substring(eq + 1);
            }

            switch (flag) {
                case "-h":
                case "--help":
                    options.help = true;
                    break;
                case "-v":
                case "--version":
                    options.version = true;
                    break;
                case "-c":
                case "--config":
                    options.printConfig = true;
                    break;
                case "-cd":
                case "--print-config-dir":
                    options.printConfigDir = true;
                    break;
                case "-l":
                case "--logs":
                    options.logs = true;
                    break;
                case "-d":
                case "--debug":
                case "--profile":
                    break;
                case "-p":
                case "--path":
                case "-f":
                case "--filter":
                case "-ucd":
                case "--use-config-dir":
                case "-w":
                case "--work-tree":
                case "-g":
                case "--git-dir":
                case "-ucf":
                case "--use-config-file":
                case "-sm":
                case "--screen-mode": {
                    String value = valueFromEquals;
                    if (value == null) {
                        if (i + 1 >= args.length) {
                            options.parseError = "Expected a following arg for flag " + flag.replaceFirst("^-+", "") + ", but it did not exist.";
                            return options;
                        }
                        value = args[++i];
                    }
                    if (flag.equals("-p") || flag.equals("--path")) {
                        options.path = value;
                    } else if (flag.equals("-ucd") || flag.equals("--use-config-dir")) {
                        options.configDir = value;
                    } else if (flag.equals("-sm") || flag.equals("--screen-mode")) {
                        options.screenMode = value;
                    } else if (flag.equals("-w") || flag.equals("--work-tree")) {
                        options.workTree = value;
                    } else if (flag.equals("-g") || flag.equals("--git-dir")) {
                        options.gitDir = value;
                    }
                    break;
                }
                default:
                    if (arg.startsWith("-")) {
                        options.parseError = "Expected a following arg for flag " + flag.replaceFirst("^-+", "") + ", but it did not exist.";
                        return options;
                    }
                    positionals.add(arg);
                    break;
            }
        }

        if (options.screenMode != null && !SCREEN_MODES.contains(options.screenMode)) {
            // The reference falls through to startup and reports the terminal error first in non-tty use.
        }
        if (!positionals.isEmpty()) {
            options.gitArg = positionals.get(0);
        }
        return options;
    }

    private static boolean isGitRepository(Path path) {
        if (Files.isDirectory(path.resolve(".git"))) {
            return true;
        }
        try {
            Process process = new ProcessBuilder("git", "-C", path.toString(), "rev-parse", "--git-dir")
                    .redirectError(ProcessBuilder.Redirect.DISCARD)
                    .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                    .start();
            return process.waitFor() == 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static void printHelp(java.io.PrintStream out) {
        out.print(
                "executable\n" +
                "\n" +
                "  Usage:\n" +
                "    executable [git-arg]\n" +
                "\n" +
                "  Positional Variables: \n" +
                "    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.\n" +
                "  Flags: \n" +
                "    -h --help               Displays help with available flag, subcommand, and positional value parameters.\n" +
                "    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)\n" +
                "    -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted\n" +
                "    -v --version            Print the current version\n" +
                "    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)\n" +
                "    -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)\n" +
                "       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.\n" +
                "    -c --config             Print the default config\n" +
                "    -cd --print-config-dir   Print the config directory\n" +
                "    -ucd --use-config-dir     override default config directory with provided directory\n" +
                "    -w --work-tree          equivalent of the --work-tree git argument\n" +
                "    -g --git-dir            equivalent of the --git-dir git argument\n" +
                "    -ucf --use-config-file    Comma separated list to custom config file(s)\n" +
                "    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'\n" +
                "\n");
    }

    private static void printTerminalError() {
        System.err.println(timestamp() + " An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues");
        System.err.println();
        System.err.println("*fmt.wrapError terminal entry not found: term not set");
        System.err.println("/workspace/pkg/app/app.go:55 (0xc91c3f)");
        System.err.println("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)");
        System.err.println("/workspace/main.go:23 (0xc95258)");
    }

    private static String defaultConfigDir() {
        String home = System.getProperty("user.home");
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (os.contains("mac")) {
            return home + "/Library/Application Support/lazygit";
        }
        if (os.contains("win")) {
            String local = System.getenv("LOCALAPPDATA");
            return (local == null || local.isEmpty() ? home : local) + "\\lazygit";
        }
        return home + "/.config/lazygit";
    }

    private static void printResource(String name) throws IOException {
        try (InputStream in = Main.class.getClassLoader().getResourceAsStream(name)) {
            if (in == null) {
                throw new IOException("missing resource " + name);
            }
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            }
        }
    }

    private static String timestamp() {
        return OffsetDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
    }

    private static final class Options {
        boolean help;
        boolean version;
        boolean printConfig;
        boolean printConfigDir;
        boolean logs;
        String path;
        String configDir;
        String screenMode;
        String workTree;
        String gitDir;
        String gitArg;
        String parseError;
    }
}
