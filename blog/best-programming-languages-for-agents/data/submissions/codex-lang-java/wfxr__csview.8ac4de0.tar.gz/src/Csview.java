import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Csview {
    static final String VERSION = "csview 1.3.4";

    static class Options {
        boolean noHeaders = false;
        boolean number = false;
        char delimiter = ',';
        String style = "sharp";
        int padding = 1;
        int indent = 0;
        int sniff = 1000;
        String headerAlign = "center";
        String bodyAlign = "left";
        String file = null;
    }

    static class CsvException extends Exception {
        final int record;
        final int line;
        final int bytePos;
        final int got;
        final int expected;
        CsvException(int record, int line, int bytePos, int got, int expected) {
            this.record = record;
            this.line = line;
            this.bytePos = bytePos;
            this.got = got;
            this.expected = expected;
        }
        public String getMessage() {
            return "CSV error: record " + record + " (line: " + line + ", byte: " + bytePos
                    + "): found record with " + got + " fields, but the previous record has "
                    + expected + " fields";
        }
    }

    static class Style {
        String topLeft, topMid, topRight, midLeft, midMid, midRight, botLeft, botMid, botRight;
        String horiz, vert;
        boolean top, bottom, headerSep, rowSep, markdown, ascii2, none;
    }

    public static void main(String[] args) {
        Options opt;
        try {
            opt = parseArgs(args);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.err.println();
            System.err.println("For more information, try '--help'.");
            System.exit(2);
            return;
        }
        if (opt == null) return;

        try {
            List<List<String>> records = readCsv(opt);
            render(records, opt);
        } catch (IOException e) {
            System.err.println("csview: " + e.getMessage());
            System.exit(1);
        } catch (CsvException e) {
            System.err.println("csview: " + e.getMessage());
            System.exit(1);
        }
    }

    static Options parseArgs(String[] args) {
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            String attached = null;
            int eq = a.indexOf('=');
            if (a.startsWith("--") && eq > 0) {
                attached = a.substring(eq + 1);
                a = a.substring(0, eq);
            }
            switch (a) {
                case "-h":
                case "--help":
                    printHelp();
                    return null;
                case "-V":
                case "--version":
                    System.out.println(VERSION);
                    return null;
                case "-H":
                case "--no-headers":
                    opt.noHeaders = true;
                    break;
                case "-n":
                case "--number":
                    opt.number = true;
                    break;
                case "-t":
                case "--tsv":
                    opt.delimiter = '\t';
                    break;
                case "-P":
                case "--disable-pager":
                    break;
                case "-d":
                case "--delimiter":
                    String d = attached != null ? attached : value(args, ++i, a);
                    if (d.codePointCount(0, d.length()) > 1) {
                        throw new IllegalArgumentException("error: invalid value '" + d
                                + "' for '--delimiter <DELIMITER>': too many characters in string");
                    }
                    opt.delimiter = d.isEmpty() ? '\0' : d.charAt(0);
                    break;
                case "-s":
                case "--style":
                    opt.style = attached != null ? attached : value(args, ++i, a);
                    if (!Arrays.asList("none", "ascii", "ascii2", "sharp", "rounded",
                            "reinforced", "markdown", "grid").contains(opt.style)) {
                        throw new IllegalArgumentException("error: invalid value '" + opt.style
                                + "' for '--style <STYLE>'\n  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]");
                    }
                    break;
                case "-p":
                case "--padding":
                    opt.padding = parseInt(attached != null ? attached : value(args, ++i, a), "padding");
                    break;
                case "-i":
                case "--indent":
                    opt.indent = parseInt(attached != null ? attached : value(args, ++i, a), "indent");
                    break;
                case "--sniff":
                    opt.sniff = parseInt(attached != null ? attached : value(args, ++i, a), "sniff");
                    break;
                case "--header-align":
                    opt.headerAlign = parseAlign(attached != null ? attached : value(args, ++i, a), "header-align");
                    break;
                case "--body-align":
                    opt.bodyAlign = parseAlign(attached != null ? attached : value(args, ++i, a), "body-align");
                    break;
                default:
                    if (a.startsWith("--")) throw new IllegalArgumentException("error: unexpected argument '" + a + "' found");
                    if (opt.file == null) opt.file = a;
                    else throw new IllegalArgumentException("error: unexpected argument '" + a + "' found");
            }
        }
        return opt;
    }

    static String value(String[] args, int idx, String flag) {
        if (idx >= args.length) throw new IllegalArgumentException("error: a value is required for '" + flag + " <" + flag.toUpperCase() + ">' but none was supplied");
        return args[idx];
    }

    static int parseInt(String s, String name) {
        try {
            int v = Integer.parseInt(s);
            if (v < 0) throw new NumberFormatException();
            return v;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("error: invalid value '" + s + "' for '--" + name + " <" + name.toUpperCase().replace('-', '_') + ">': invalid digit found in string");
        }
    }

    static String parseAlign(String s, String flag) {
        if (s.equals("left") || s.equals("center") || s.equals("right")) return s;
        String arg = flag.equals("header-align") ? "HEADER_ALIGN" : "BODY_ALIGN";
        throw new IllegalArgumentException("error: invalid value '" + s + "' for '--" + flag + " <" + arg + ">'\n  [possible values: left, center, right]");
    }

    static void printHelp() {
        System.out.println("A high performance csv viewer with cjk/emoji support.");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [FILE]");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [FILE]");
        System.out.println("          File to view");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -H, --no-headers");
        System.out.println("          Specify that the input has no header row");
        System.out.println("  -n, --number");
        System.out.println("          Prepend a column of line numbers to the table");
        System.out.println("  -t, --tsv");
        System.out.println("          Use '\\t' as delimiter for tsv");
        System.out.println("  -d, --delimiter <DELIMITER>");
        System.out.println("          Specify the field delimiter [default: ,]");
        System.out.println("  -s, --style <STYLE>");
        System.out.println("          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,");
        System.out.println("          rounded, reinforced, markdown, grid]");
        System.out.println("  -p, --padding <PADDING>");
        System.out.println("          Specify padding for table cell [default: 1]");
        System.out.println("  -i, --indent <INDENT>");
        System.out.println("          Specify global indent for table [default: 0]");
        System.out.println("      --sniff <LIMIT>");
        System.out.println("          Limit column widths sniffing to the specified number of rows. Specify \"0\" to cancel limit");
        System.out.println("          [default: 1000]");
        System.out.println("      --header-align <HEADER_ALIGN>");
        System.out.println("          Specify the alignment of the table header [default: center] [possible values: left,");
        System.out.println("          center, right]");
        System.out.println("      --body-align <BODY_ALIGN>");
        System.out.println("          Specify the alignment of the table body [default: left] [possible values: left, center,");
        System.out.println("          right]");
        System.out.println("  -P, --disable-pager");
        System.out.println("          Disable pager");
        System.out.println("  -h, --help");
        System.out.println("          Print help");
        System.out.println("  -V, --version");
        System.out.println("          Print version");
    }

    static List<List<String>> readCsv(Options opt) throws IOException, CsvException {
        InputStream in;
        if (opt.file == null) in = System.in;
        else in = new FileInputStream(opt.file);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            int ch;
            while ((ch = br.read()) != -1) sb.append((char) ch);
        }
        return parseCsv(sb.toString(), opt.delimiter);
    }

    static List<List<String>> parseCsv(String text, char delimiter) throws CsvException {
        List<List<String>> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false, inQuotes = false, sawAny = false, fieldQuoted = false;
        int line = 1, bytePos = 0, rec = 0, expected = -1, rowStartByte = 0, rowStartLine = 1;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            bytePos += utf8Len(c);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                        bytePos += 1;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field.append(c);
                    if (c == '\n') line++;
                }
                continue;
            }
            if (!quoted && field.length() == 0 && c == '"') {
                quoted = true;
                fieldQuoted = true;
                inQuotes = true;
                sawAny = true;
            } else if (c == delimiter) {
                row.add(field.toString());
                field.setLength(0);
                quoted = false;
                fieldQuoted = false;
                sawAny = true;
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') {
                    i++;
                    bytePos += 1;
                }
                if (sawAny || field.length() > 0 || fieldQuoted || !row.isEmpty()) {
                    row.add(field.toString());
                    if (!(row.size() == 1 && row.get(0).isEmpty())) {
                        if (expected >= 0 && row.size() != expected) {
                            throw new CsvException(rec, rowStartLine, rowStartByte, row.size(), expected);
                        }
                        expected = row.size();
                        rows.add(row);
                        rec++;
                    }
                }
                row = new ArrayList<>();
                field.setLength(0);
                quoted = false;
                fieldQuoted = false;
                sawAny = false;
                line++;
                rowStartLine = line;
                rowStartByte = bytePos;
            } else {
                field.append(c);
                quoted = true;
                sawAny = true;
            }
        }
        if (inQuotes || sawAny || field.length() > 0 || fieldQuoted || !row.isEmpty()) {
            row.add(field.toString());
            if (!(row.size() == 1 && row.get(0).isEmpty())) {
                if (expected >= 0 && row.size() != expected) throw new CsvException(rec, rowStartLine, rowStartByte, row.size(), expected);
                rows.add(row);
            }
        }
        return rows;
    }

    static int utf8Len(char c) {
        if (c < 0x80) return 1;
        if (c < 0x800) return 2;
        return 3;
    }

    static void render(List<List<String>> input, Options opt) {
        boolean hasHeader = !opt.noHeaders;
        List<String> header = null;
        List<List<String>> body = new ArrayList<>();
        if (input.isEmpty()) {
            if (hasHeader) header = new ArrayList<>();
        } else if (hasHeader) {
            header = new ArrayList<>(input.get(0));
            body.addAll(input.subList(1, input.size()));
        } else {
            body.addAll(input);
        }
        if (opt.number) {
            if (hasHeader) {
                if (header == null) header = new ArrayList<>();
                header.add(0, "#");
            }
            for (int i = 0; i < body.size(); i++) body.get(i).add(0, Integer.toString(i + 1));
        }
        int cols = 0;
        if (header != null) cols = Math.max(cols, header.size());
        for (List<String> r : body) cols = Math.max(cols, r.size());
        int[] widths = new int[cols];
        if (header != null) {
            for (int c = 0; c < cols; c++) widths[c] = Math.max(widths[c], displayWidth(get(header, c)));
        }
        int limit = opt.sniff == 0 ? body.size() : Math.min(opt.sniff, body.size());
        for (int r = 0; r < limit; r++) {
            List<String> row = body.get(r);
            for (int c = 0; c < cols; c++) widths[c] = Math.max(widths[c], displayWidth(get(row, c)));
        }

        Style st = style(opt.style);
        List<String> lines = new ArrayList<>();
        if (st.none) {
            if (header != null) lines.add(rowLine(header, widths, opt.headerAlign, opt, st));
            for (List<String> row : body) lines.add(rowLine(row, widths, opt.bodyAlign, opt, st));
        } else if (st.ascii2) {
            if (header != null) {
                lines.add(rowLine(header, widths, opt.headerAlign, opt, st));
                lines.add(borderLine(widths, opt, st, "mid"));
            }
            for (List<String> row : body) lines.add(rowLine(row, widths, opt.bodyAlign, opt, st));
        } else if (st.markdown) {
            if (header != null) {
                lines.add(rowLine(header, widths, opt.headerAlign, opt, st));
                lines.add(borderLine(widths, opt, st, "mid"));
            }
            for (List<String> row : body) lines.add(rowLine(row, widths, opt.bodyAlign, opt, st));
        } else {
            if (st.top) lines.add(borderLine(widths, opt, st, "top"));
            if (header != null) {
                lines.add(rowLine(header, widths, opt.headerAlign, opt, st));
                if (st.headerSep && !body.isEmpty()) lines.add(borderLine(widths, opt, st, "mid"));
            }
            for (int i = 0; i < body.size(); i++) {
                lines.add(rowLine(body.get(i), widths, opt.bodyAlign, opt, st));
                if (st.rowSep && i < body.size() - 1) lines.add(borderLine(widths, opt, st, "mid"));
            }
            if (st.bottom) lines.add(borderLine(widths, opt, st, "bottom"));
        }
        String indent = repeat(" ", opt.indent);
        for (String line : lines) System.out.println(indent + line);
    }

    static String get(List<String> row, int idx) {
        return idx < row.size() ? row.get(idx) : "";
    }

    static String rowLine(List<String> row, int[] widths, String align, Options opt, Style st) {
        List<String> cells = new ArrayList<>();
        for (int c = 0; c < widths.length; c++) {
            String s = truncate(get(row, c), widths[c]);
            cells.add(repeat(" ", opt.padding) + align(s, widths[c], align) + repeat(" ", opt.padding));
        }
        if (st.none) return String.join("", cells);
        if (st.ascii2) return " " + String.join("|", cells) + " ";
        return st.vert + String.join(st.vert, cells) + st.vert;
    }

    static String borderLine(int[] widths, Options opt, Style st, String which) {
        List<String> parts = new ArrayList<>();
        for (int w : widths) parts.add(repeat(st.horiz, w + opt.padding * 2));
        if (st.ascii2) return " " + String.join("+", parts) + " ";
        if (st.markdown) return "|" + String.join("|", parts) + "|";
        if (which.equals("top")) return st.topLeft + String.join(st.topMid, parts) + st.topRight;
        if (which.equals("bottom")) return st.botLeft + String.join(st.botMid, parts) + st.botRight;
        return st.midLeft + String.join(st.midMid, parts) + st.midRight;
    }

    static Style style(String name) {
        Style s = new Style();
        s.horiz = "─";
        s.vert = "│";
        s.top = true; s.bottom = true; s.headerSep = true;
        s.topLeft = "┌"; s.topMid = "┬"; s.topRight = "┐";
        s.midLeft = "├"; s.midMid = "┼"; s.midRight = "┤";
        s.botLeft = "└"; s.botMid = "┴"; s.botRight = "┘";
        if (name.equals("ascii")) {
            s.horiz = "-"; s.vert = "|";
            s.topLeft = s.topMid = s.topRight = "+";
            s.midLeft = s.midMid = s.midRight = "+";
            s.botLeft = s.botMid = s.botRight = "+";
        } else if (name.equals("ascii2")) {
            s.ascii2 = true; s.top = false; s.bottom = false; s.horiz = "-"; s.vert = "|";
        } else if (name.equals("rounded")) {
            s.topLeft = "╭"; s.topRight = "╮"; s.botLeft = "╰"; s.botRight = "╯";
        } else if (name.equals("reinforced")) {
            s.topLeft = "┏"; s.topRight = "┓"; s.botLeft = "┗"; s.botRight = "┛";
        } else if (name.equals("markdown")) {
            s.markdown = true; s.top = false; s.bottom = false; s.horiz = "-"; s.vert = "|";
        } else if (name.equals("grid")) {
            s.rowSep = true;
        } else if (name.equals("none")) {
            s.none = true; s.top = false; s.bottom = false; s.headerSep = false;
        }
        return s;
    }

    static String align(String s, int width, String align) {
        int w = displayWidth(s);
        int extra = Math.max(0, width - w);
        if (align.equals("right")) return repeat(" ", extra) + s;
        if (align.equals("center")) return repeat(" ", extra / 2) + s + repeat(" ", extra - extra / 2);
        return s + repeat(" ", extra);
    }

    static String truncate(String s, int max) {
        StringBuilder out = new StringBuilder();
        int w = 0;
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            int cw = charWidth(cp);
            if (w + cw > max) break;
            out.appendCodePoint(cp);
            w += cw;
            i += Character.charCount(cp);
        }
        return out.toString();
    }

    static int displayWidth(String s) {
        int w = 0;
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            w += charWidth(cp);
            i += Character.charCount(cp);
        }
        return w;
    }

    static int charWidth(int cp) {
        int type = Character.getType(cp);
        if (type == Character.NON_SPACING_MARK || type == Character.ENCLOSING_MARK || type == Character.COMBINING_SPACING_MARK) return 0;
        if (cp == 0) return 0;
        if (cp < 32 || (cp >= 0x7f && cp < 0xa0)) return 0;
        if ((cp >= 0x1100 && cp <= 0x115f) || cp == 0x2329 || cp == 0x232a ||
            (cp >= 0x2e80 && cp <= 0xa4cf) || (cp >= 0xac00 && cp <= 0xd7a3) ||
            (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xfe10 && cp <= 0xfe19) ||
            (cp >= 0xfe30 && cp <= 0xfe6f) || (cp >= 0xff00 && cp <= 0xff60) ||
            (cp >= 0xffe0 && cp <= 0xffe6) || (cp >= 0x1f300 && cp <= 0x1faff)) return 2;
        return 1;
    }

    static String repeat(String s, int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) b.append(s);
        return b.toString();
    }
}
