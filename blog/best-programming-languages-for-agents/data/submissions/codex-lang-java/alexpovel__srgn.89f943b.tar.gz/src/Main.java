import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class LangScope {
        String lang, kind;
        LangScope(String l, String k) { lang = l; kind = k; }
    }
    static class Opt {
        boolean upper, lower, title, normalize, german, symbols, delete, squeeze, invert, literal, failAny, failNone, failNoFiles, dryRun, sorted;
        boolean germanNaive, germanPreferOriginal, joinScopes;
        String glob, stdinDetection = "auto", stdoutDetection = "auto";
        String scope = null, replacement = null;
        List<LangScope> langs = new ArrayList<>();
    }
    static class Range implements Comparable<Range> {
        int s, e;
        Range(int s, int e) { this.s = Math.max(0, s); this.e = Math.max(this.s, e); }
        public int compareTo(Range o) { return s != o.s ? s - o.s : e - o.e; }
    }
    static class Piece {
        int s, e; String line;
        Piece(int s, int e, String line) { this.s=s; this.e=e; this.line=line; }
    }

    public static void main(String[] args) throws Exception {
        Opt opt;
        try { opt = parse(args); }
        catch (IllegalArgumentException ex) { System.err.println(ex.getMessage()); return; }
        applyEnv(opt);
        if (opt.delete && opt.scope == null) {
            System.err.println("error: the following required arguments were not provided:\n  <SCOPE>\n\nUsage: executable --delete <SCOPE> [-- <REPLACEMENT>]\n\nFor more information, try '--help'.");
            return;
        }
        if (opt.literal && opt.scope == null) {
            System.err.println("error: The following required argument was not provided: scope\n\nUsage: srgn [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n\nFor more information, try '--help'.");
            return;
        }
        if (opt.scope == null) opt.scope = ".*";
        if (opt.glob != null) processGlob(opt);
        else {
            byte[] bytes = System.in.readAllBytes();
            String input = new String(bytes, StandardCharsets.UTF_8);
            String out = processText(input, "(stdin)", opt);
            if (out != null) System.out.print(out);
        }
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        boolean afterDash = false;
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            if (afterDash) { o.replacement = a; afterDash = false; continue; }
            if (a.equals("--")) { afterDash = true; continue; }
            if (a.startsWith("--") && a.length() > 2) {
                String name=a.substring(2), val=null;
                int eq=name.indexOf('=');
                if (eq>=0) { val=name.substring(eq+1); name=name.substring(0,eq); }
                switch (name) {
                    case "help": printHelp(false); System.exit(0); break;
                    case "version": System.out.println("srgn 0.14.1"); System.exit(0); break;
                    case "completions": if (val==null && i+1<args.length) i++; System.exit(0); break;
                    case "upper": o.upper=true; break; case "lower": o.lower=true; break; case "titlecase": o.title=true; break;
                    case "normalize": o.normalize=true; break; case "german": o.german=true; break; case "symbols": o.symbols=true; break;
                    case "delete": o.delete=true; break; case "squeeze": case "squeeze-repeats": o.squeeze=true; break;
                    case "invert": o.invert=true; break; case "literal-string": o.literal=true; break;
                    case "fail-any": o.failAny=true; break; case "fail-none": o.failNone=true; break; case "fail-no-files": o.failNoFiles=true; break;
                    case "dry-run": o.dryRun=true; break; case "hidden": case "gitignored": break; case "sorted": o.sorted=true; break;
                    case "join-language-scopes": o.joinScopes=true; break;
                    case "german-naive": o.germanNaive=true; break; case "german-prefer-original": o.germanPreferOriginal=true; break;
                    case "glob": if (val==null) val = next(args, ++i, "--glob"); o.glob=val; break;
                    case "stdin-detection": if (val==null) val = next(args, ++i, name); o.stdinDetection=val; break;
                    case "stdout-detection": if (val==null) val = next(args, ++i, name); o.stdoutDetection=val; break;
                    case "threads": if (val==null && i+1<args.length) i++; break;
                    case "verbose": break;
                    case "python": case "py": case "rust": case "rs": case "go": case "typescript": case "ts": case "c": case "csharp": case "cs": case "hcl":
                        if (val==null) val = next(args, ++i, name);
                        o.langs.add(new LangScope(canonLang(name), val)); break;
                    default:
                        if (name.endsWith("-query")) { if (val==null && i+1<args.length) i++; }
                        else if (name.endsWith("-query-file")) { if (val==null && i+1<args.length) i++; }
                        else throw new IllegalArgumentException("error: unexpected argument '--"+name+"' found\n\nUsage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n\nFor more information, try '--help'.");
                }
            } else if (a.startsWith("-") && a.length() > 1 && !a.equals("-")) {
                for (int j=1;j<a.length();j++) {
                    char c=a.charAt(j);
                    switch(c) {
                        case 'h': printHelp(true); System.exit(0); break; case 'V': System.out.println("srgn 0.14.1"); System.exit(0); break;
                        case 'u': o.upper=true; break; case 'l': o.lower=true; break; case 't': o.title=true; break; case 'n': o.normalize=true; break;
                        case 'g': o.german=true; break; case 'S': o.symbols=true; break; case 'd': o.delete=true; break; case 's': o.squeeze=true; break;
                        case 'i': o.invert=true; break; case 'L': o.literal=true; break; case 'j': o.joinScopes=true; break;
                        case 'H': break; case 'v': break;
                        case 'G':
                            String rest = a.substring(j+1);
                            o.glob = rest.isEmpty() ? next(args, ++i, "-G") : rest;
                            j = a.length(); break;
                        default: throw new IllegalArgumentException("error: unexpected argument '-"+c+"' found");
                    }
                }
            } else {
                if (o.scope == null) o.scope = a; else o.replacement = a;
            }
        }
        return o;
    }

    static String next(String[] args, int i, String name) {
        if (i >= args.length) throw new IllegalArgumentException("error: a value is required for '"+name+"'");
        return args[i];
    }
    static String canonLang(String s) {
        if (s.equals("py")) return "python"; if (s.equals("rs")) return "rust"; if (s.equals("ts")) return "typescript"; if (s.equals("cs")) return "csharp"; return s;
    }
    static void applyEnv(Opt o) {
        Map<String,String> e=System.getenv();
        if (e.containsKey("UPPER")) o.upper=true; if (e.containsKey("LOWER")) o.lower=true; if (e.containsKey("TITLECASE")) o.title=true;
        if (e.containsKey("NORMALIZE")) o.normalize=true; if (e.containsKey("GERMAN")) o.german=true; if (e.containsKey("SQUEEZE")) o.squeeze=true;
        if (e.containsKey("INVERT")) o.invert=true; if (e.containsKey("LITERAL_STRING")) o.literal=true; if (e.containsKey("REPLACE")) o.replacement=e.get("REPLACE");
    }

    static void printHelp(boolean shortHelp) {
        System.out.println("A grep-like tool which understands source code syntax and allows for manipulation in\naddition to search\n");
        System.out.println("Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n");
        System.out.println("Options:\n  -h, --help     Print help\n  -V, --version  Print version\n");
        System.out.println("Composable Actions:\n  -u, --upper\n  -l, --lower\n  -t, --titlecase\n  -n, --normalize\n  -g, --german\n  -S, --symbols\n  [REPLACEMENT]\n");
        System.out.println("Standalone Actions:\n  -d, --delete\n  -s, --squeeze\n");
        System.out.println("Options (global):\n  -G, --glob <GLOB>\n      --dry-run\n  -i, --invert\n  -L, --literal-string\n      --fail-any\n      --fail-none\n      --sorted\n");
        System.out.println("Language scopes:\n      --python <PYTHON>\n      --rust <RUST>\n      --go <GO>\n      --typescript <TYPESCRIPT>\n      --c <C>\n      --csharp <CSHARP>\n      --hcl <HCL>");
    }

    static void processGlob(Opt opt) throws Exception {
        List<Path> files = globFiles(opt.glob);
        if (opt.sorted) Collections.sort(files);
        if (files.isEmpty() && opt.failNoFiles) System.err.println("Error: No files found");
        for (Path p: files) {
            String input = Files.readString(p);
            String out = processText(input, p.toString(), opt);
            if (hasActions(opt)) {
                if (!input.equals(out)) {
                    System.out.println(p.toString());
                    if (opt.dryRun) printDiff(p.toString(), input, out); else Files.writeString(p, out);
                }
            } else if (!opt.langs.isEmpty() && out != null && !out.isEmpty()) {
                System.out.print(out);
            }
        }
    }
    static List<Path> globFiles(String glob) throws IOException {
        Path cwd=Paths.get("").toAbsolutePath().normalize();
        final PathMatcher m = FileSystems.getDefault().getPathMatcher("glob:"+glob);
        List<Path> r=new ArrayList<>();
        try (var s=Files.walk(cwd)) {
            s.filter(Files::isRegularFile).forEach(p -> {
                Path rel=cwd.relativize(p);
                if (m.matches(rel) || m.matches(p.getFileName())) r.add(rel);
            });
        }
        return r;
    }
    static void printDiff(String name, String a, String b) {
        System.out.println("--- " + name);
        System.out.println("+++ " + name);
        System.out.print(b);
    }

    static boolean hasActions(Opt o) {
        return o.replacement!=null || o.upper||o.lower||o.title||o.normalize||o.german||o.symbols||o.delete||o.squeeze;
    }
    static String processText(String input, String name, Opt o) {
        Pattern pat;
        try { pat = compileScope(o); }
        catch (PatternSyntaxException ex) {
            System.err.println("Error: Failed building regex\n\nCaused by:\n    Invalid regex: " + ex.getMessage());
            return "";
        }
        List<Range> base = languageRanges(input, o);
        List<Range> matches = o.squeeze ? regexMatchesRaw(input, base, pat) : regexMatches(input, base, pat);
        if (o.failAny && !matches.isEmpty()) System.err.println("Error: Error applying: Some input was in scope");
        if (o.failNone && matches.isEmpty()) System.err.println("Error: Error applying: No input was in scope");
        if (!hasActions(o)) {
            if (!o.langs.isEmpty()) return searchOutput(input, name, matches);
            System.err.println("[ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.");
            return input;
        }
        if (o.delete) return replaceRanges(input, matches, "");
        if (o.squeeze) return squeeze(input, matches);
        String cur=input;
        if (o.replacement!=null) cur = replaceByRegex(cur, languageRanges(cur,o), pat, o.replacement);
        ActionChain chain = new ActionChain(o);
        if (chain.any()) cur = transformByRegex(cur, languageRanges(cur,o), pat, chain);
        return cur;
    }
    static Pattern compileScope(Opt o) {
        String s = o.literal ? Pattern.quote(o.scope) : o.scope;
        return Pattern.compile(s, Pattern.MULTILINE | Pattern.UNICODE_CASE);
    }
    static List<Range> regexMatches(String text, List<Range> allowed, Pattern pat) {
        return merge(regexMatchesRaw(text, allowed, pat));
    }
    static List<Range> regexMatchesRaw(String text, List<Range> allowed, Pattern pat) {
        List<Range> r=new ArrayList<>();
        for (Range a: allowed) {
            Matcher m=pat.matcher(text);
            m.region(a.s, a.e);
            while (m.find()) {
                if (m.end()==m.start()) { if (m.end() < a.e) continue; else break; }
                r.add(new Range(m.start(), m.end()));
            }
        }
        return r;
    }
    static String replaceByRegex(String text, List<Range> allowed, Pattern pat, String repl) {
        StringBuilder out=new StringBuilder(); int pos=0;
        for (Range a: allowed) {
            out.append(text, pos, a.s);
            String sub=text.substring(a.s,a.e);
            Matcher m=pat.matcher(sub);
            StringBuffer sb=new StringBuffer();
            while(m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(expand(repl,m)));
            m.appendTail(sb);
            out.append(sb);
            pos=a.e;
        }
        out.append(text.substring(pos));
        return out.toString();
    }
    static String expand(String repl, Matcher m) {
        StringBuilder b=new StringBuilder();
        for (int i=0;i<repl.length();i++) {
            char c=repl.charAt(i);
            if (c=='$' && i+1<repl.length()) {
                int j=i+1;
                if (Character.isDigit(repl.charAt(j))) {
                    while(j<repl.length() && Character.isDigit(repl.charAt(j))) j++;
                    try { String g=m.group(Integer.parseInt(repl.substring(i+1,j))); if(g!=null)b.append(g); } catch(Exception ignored){}
                    i=j-1; continue;
                } else if (Character.isLetter(repl.charAt(j)) || repl.charAt(j)=='_') {
                    while(j<repl.length() && (Character.isLetterOrDigit(repl.charAt(j)) || repl.charAt(j)=='_')) j++;
                    try { String g=m.group(repl.substring(i+1,j)); if(g!=null)b.append(g); } catch(Exception ignored){}
                    i=j-1; continue;
                }
            }
            b.append(c);
        }
        return b.toString();
    }
    static String transformByRegex(String text, List<Range> allowed, Pattern pat, ActionChain chain) {
        StringBuilder out=new StringBuilder(); int pos=0;
        for (Range a: allowed) {
            out.append(text, pos, a.s);
            Matcher m=pat.matcher(text); m.region(a.s,a.e);
            int lp=a.s;
            while(m.find()) {
                if (m.end()==m.start()) continue;
                out.append(text, lp, m.start());
                out.append(chain.apply(text.substring(m.start(), m.end())));
                lp=m.end();
            }
            out.append(text, lp, a.e);
            pos=a.e;
        }
        out.append(text.substring(pos));
        return out.toString();
    }
    static String replaceRanges(String text, List<Range> ranges, String repl) {
        StringBuilder b=new StringBuilder(); int p=0;
        for(Range r: ranges){ b.append(text,p,r.s).append(repl); p=r.e; }
        b.append(text.substring(p)); return b.toString();
    }
    static String squeeze(String text, List<Range> ranges) {
        if (ranges.isEmpty()) return text;
        StringBuilder b=new StringBuilder(); int p=0; String last=null;
        for(Range r: ranges) {
            String cur=text.substring(r.s,r.e);
            b.append(text,p,r.s);
            if (!cur.equals(last) || (p!=r.s)) b.append(cur);
            last=cur; p=r.e;
        }
        b.append(text.substring(p)); return b.toString();
    }

    static class ActionChain {
        Opt o; ActionChain(Opt o){this.o=o;}
        boolean any(){return o.upper||o.lower||o.title||o.normalize||o.german||o.symbols;}
        String apply(String s){
            if(o.german) s=german(s,o.germanNaive,o.germanPreferOriginal);
            if(o.symbols) s=symbols(s,o.invert);
            if(o.upper) s=s.toUpperCase(Locale.ROOT);
            if(o.lower) s=s.toLowerCase(Locale.ROOT);
            if(o.title) s=title(s);
            if(o.normalize) s=stripMarks(s);
            return s;
        }
    }
    static String title(String s) {
        StringBuilder b=new StringBuilder(); boolean start=true;
        for(int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if(Character.isLetter(c)) { b.append(start ? String.valueOf(c).toUpperCase(Locale.ROOT) : String.valueOf(c).toLowerCase(Locale.ROOT)); start=false; }
            else { b.append(c); start = c != '\'' && !Character.isDigit(c); }
        }
        return b.toString();
    }
    static String stripMarks(String s) {
        return Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
    }
    static String symbols(String s, boolean inv) {
        String[][] map={{"!=", "≠"},{"->","→"},{"<-","←"},{"<=","≤"},{">=","≥"},{"=>","⇒"},{"--","–"},{"...","…"},{"+-","±"},{"::","∷"},{"&&","∧"},{"||","∨"},{"!","¬"}};
        for(String[] kv: map) s=s.replace(inv?kv[1]:kv[0], inv?kv[0]:kv[1]);
        return s;
    }
    static String german(String s, boolean naive, boolean preferOrig) {
        if (naive) return s.replace("Ae","Ä").replace("Oe","Ö").replace("Ue","Ü").replace("ae","ä").replace("oe","ö").replace("ue","ü").replace("ss","ß");
        Map<String,String> dict=new LinkedHashMap<>();
        dict.put("Abenteuergruesse","Abenteuergrüße"); dict.put("Bruecken","Brücken"); dict.put("Strasse","Straße");
        dict.put("Busse", preferOrig ? "Busse" : "Buße"); dict.put("Gruesse","Grüße"); dict.put("gruesse","grüße");
        dict.put("Fueße","Füße"); dict.put("Fuesse","Füße"); dict.put("gross","groß"); dict.put("Grosse","Große");
        for (var e: dict.entrySet()) s=s.replace(e.getKey(), e.getValue());
        return s;
    }

    static List<Range> languageRanges(String text, Opt o) {
        if (o.langs.isEmpty()) return List.of(new Range(0,text.length()));
        List<Range> cur = null;
        for (LangScope ls: o.langs) {
            List<Range> one = scopeFor(text, ls.lang, ls.kind);
            if (cur==null) cur=one;
            else cur = o.joinScopes ? mergeUnion(cur, one) : intersect(cur, one);
        }
        return cur==null ? List.of(new Range(0,text.length())) : merge(cur);
    }
    static List<Range> scopeFor(String t, String lang, String kind) {
        String k = kind.contains("~") ? kind.substring(0, kind.indexOf('~')) : kind;
        String filter = kind.contains("~") ? kind.substring(kind.indexOf('~')+1) : null;
        if (k.contains("comment")) return comments(t, lang);
        if (k.contains("string")) return strings(t);
        if (k.equals("imports") && lang.equals("python")) return pythonImports(t);
        if (k.equals("imports")||k.equals("uses")||k.equals("usings")||k.equals("includes")) return lineRegex(t, importPattern(lang), 0);
        if (k.equals("function-names")) return regexRanges(t, "\\bdef\\s+([A-Za-z_][A-Za-z0-9_]*)", 1);
        if (k.equals("function-calls")) return regexRanges(t, "\\b([A-Za-z_][A-Za-z0-9_]*)\\s*\\(", 1);
        if (k.equals("identifiers")||k.equals("identifier")||k.equals("variable-identifiers")||k.equals("type-identifier")) return regexRanges(t, "\\b[A-Za-z_][A-Za-z0-9_]*\\b", 0);
        if (k.equals("class")||k.equals("def")||k.equals("async-def")||k.equals("methods")||k.equals("with")||k.equals("try")||k.equals("lambda")) return pythonBlocks(t,k);
        if (lang.equals("rust")) return rustScopes(t,k,filter);
        if (lang.equals("go")) return goScopes(t,k,filter);
        if (lang.equals("typescript")||lang.equals("csharp")||lang.equals("c")||lang.equals("hcl")) return genericLineScopes(t,k,filter);
        return List.of(new Range(0,t.length()));
    }
    static String importPattern(String lang) {
        if (lang.equals("python")) return "^\\s*(import|from)\\b.*$";
        if (lang.equals("rust")) return "^\\s*use\\b.*;";
        if (lang.equals("go")) return "^\\s*import\\b.*$";
        if (lang.equals("c")||lang.equals("csharp")) return "^\\s*(#\\s*include|using)\\b.*$";
        return "^\\s*(import|use|using)\\b.*$";
    }
    static List<Range> pythonImports(String t) {
        List<Range> r=new ArrayList<>();
        Matcher m=Pattern.compile("(?m)^\\s*import\\s+([^\\n]+)$").matcher(t);
        while(m.find()) {
            String body=m.group(1); int off=m.start(1);
            Matcher n=Pattern.compile("[A-Za-z_][A-Za-z0-9_.]*").matcher(body);
            while(n.find()) if(!n.group().equals("as")) r.add(new Range(off+n.start(), off+n.end()));
        }
        m=Pattern.compile("(?m)^\\s*from\\s+([A-Za-z_][A-Za-z0-9_.]*)\\s+import\\b.*$").matcher(t);
        while(m.find()) r.add(new Range(m.start(1), m.end(1)));
        return r;
    }
    static List<Range> comments(String t, String lang) {
        List<Range> r=new ArrayList<>();
        String line = (lang.equals("python")||lang.equals("hcl")) ? "#" : "//";
        Matcher lm=Pattern.compile(Pattern.quote(line)+".*").matcher(t); while(lm.find()) r.add(new Range(lm.start(), lm.end()));
        Matcher bm=Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL).matcher(t); while(bm.find()) r.add(new Range(bm.start(), bm.end()));
        return merge(r);
    }
    static List<Range> strings(String t) {
        List<Range> r=new ArrayList<>();
        Matcher m=Pattern.compile("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'|`[^`]*`", Pattern.DOTALL).matcher(t);
        while(m.find()) r.add(new Range(m.start(), m.end()));
        return r;
    }
    static List<Range> lineRegex(String t, String re, int group) {
        List<Range> r=new ArrayList<>(); Matcher m=Pattern.compile(re, Pattern.MULTILINE).matcher(t);
        while(m.find()) r.add(new Range(m.start(group), m.end(group)));
        return r;
    }
    static List<Range> regexRanges(String t, String re, int group) {
        List<Range> r=new ArrayList<>(); Matcher m=Pattern.compile(re, Pattern.MULTILINE|Pattern.DOTALL).matcher(t);
        while(m.find()) r.add(new Range(m.start(group), m.end(group)));
        return r;
    }
    static List<Range> pythonBlocks(String t, String k) {
        if (k.equals("lambda")) return regexRanges(t, "lambda\\b[^\\n]*", 0);
        String re;
        if (k.equals("class")) re="^\\s*class\\s+.*(?::|$)(?:\\n(?:\\s+\\S.*|\\s*#.*|\\s*$))*";
        else if (k.equals("async-def")) re="^\\s*async\\s+def\\s+.*(?::|$)(?:\\n(?:\\s+\\S.*|\\s*#.*|\\s*$))*";
        else if (k.equals("with")) re="^\\s*with\\s+.*(?::|$)(?:\\n(?:\\s+\\S.*|\\s*$))*";
        else if (k.equals("try")) re="^\\s*(try|except|finally)\\b.*(?::|$)(?:\\n(?:\\s+\\S.*|\\s*$))*";
        else re="^\\s*def\\s+.*(?::|$)(?:\\n(?:\\s+\\S.*|\\s*#.*|\\s*$))*";
        return regexRanges(t,re,0);
    }
    static List<Range> rustScopes(String t, String k, String f) {
        String word = switch(k) {
            case "struct","priv-struct","pub-struct","pub-crate-struct","pub-self-struct","pub-super-struct" -> "struct";
            case "enum","priv-enum","pub-enum","enum-variant" -> "enum";
            case "trait" -> "trait"; case "impl","impl-type","impl-trait" -> "impl";
            case "mod","mod-tests" -> "mod"; case "attribute" -> "#\\[[^\\n]*\\]";
            case "unsafe" -> "unsafe"; case "closure" -> "\\|[^\\n|]*\\|";
            default -> k.contains("fn") ? "fn" : (k.equals("type-def") ? "(struct|enum|union)" : "\\b[A-Za-z_][A-Za-z0-9_]*\\b");
        };
        if (word.startsWith("#") || word.startsWith("\\|") || word.equals("unsafe")) return regexRanges(t, word, 0);
        return blockAfterKeyword(t, word, f);
    }
    static List<Range> goScopes(String t, String k, String f) {
        if (k.equals("struct")||k.equals("interface")||k.equals("func")||k.equals("method")||k.equals("free-func")||k.equals("init-func")) return blockAfterKeyword(t, k.equals("func")||k.contains("func")||k.equals("method")?"func":k, f);
        if (k.equals("const")||k.equals("var")||k.equals("type-def")||k.equals("type-alias")) return lineRegex(t, "^\\s*(const|var|type)\\b.*$", 0);
        if (k.equals("defer")||k.equals("select")||k.equals("switch")||k.equals("goto")) return lineRegex(t, "^\\s*"+k+"\\b.*$", 0);
        if (k.equals("struct-tags")) return regexRanges(t, "`[^`]*`", 0);
        return regexRanges(t, "\\b[A-Za-z_][A-Za-z0-9_]*\\b", 0);
    }
    static List<Range> genericLineScopes(String t, String k, String f) {
        String kw = k.replace("-def","").replace("-decl","").replace("async-","").replace("sync-","");
        if (kw.equals("comments")) return comments(t,"c");
        if (kw.equals("strings")) return strings(t);
        if (kw.equals("variable-declaration")||kw.equals("var-decl")) kw="(let|const|var)";
        return lineRegex(t, "^\\s*.*\\b"+kw+"\\b.*$", 0);
    }
    static List<Range> blockAfterKeyword(String t, String kw, String filter) {
        List<Range> r=new ArrayList<>();
        Pattern p=Pattern.compile("\\b"+kw+"\\b[^\\n{;]*(\\{|;)?", Pattern.MULTILINE);
        Matcher m=p.matcher(t);
        Pattern fp = filter==null?null:Pattern.compile(filter);
        while(m.find()) {
            String head=t.substring(m.start(), m.end());
            if (fp!=null && !fp.matcher(head).find()) continue;
            int end=m.end();
            if (m.group(1)!=null && m.group(1).equals("{")) end=findBrace(t,m.end()-1);
            else { int nl=t.indexOf('\n',m.end()); if(nl>=0) end=nl; }
            r.add(new Range(m.start(), end));
        }
        return r;
    }
    static int findBrace(String t, int open) {
        int d=0; for(int i=open;i<t.length();i++){ char c=t.charAt(i); if(c=='{')d++; else if(c=='}' && --d==0)return i+1; } return t.length();
    }
    static List<Range> mergeUnion(List<Range>a,List<Range>b){List<Range>x=new ArrayList<>(a);x.addAll(b);return merge(x);}
    static List<Range> merge(List<Range> r) {
        if(r.isEmpty()) return r; Collections.sort(r); List<Range> o=new ArrayList<>(); Range c=r.get(0);
        for(int i=1;i<r.size();i++){Range n=r.get(i); if(n.s<=c.e){c.e=Math.max(c.e,n.e);} else {o.add(c); c=n;}} o.add(c); return o;
    }
    static List<Range> intersect(List<Range>a,List<Range>b){
        List<Range> r=new ArrayList<>(); for(Range x:a) for(Range y:b){int s=Math.max(x.s,y.s), e=Math.min(x.e,y.e); if(s<e)r.add(new Range(s,e));} return merge(r);
    }
    static String searchOutput(String text, String name, List<Range> matches) {
        if (matches.isEmpty()) return "";
        Map<Integer,List<Piece>> byLine=new LinkedHashMap<>();
        int[] lineStart=lineStarts(text);
        for(Range r: matches) {
            int line=lineOf(lineStart,r.s);
            int start=lineStart[line-1], end=text.indexOf('\n',start); if(end<0)end=text.length();
            byLine.computeIfAbsent(line,k->new ArrayList<>()).add(new Piece(r.s-start,r.e-start,text.substring(start,end)));
        }
        StringBuilder b=new StringBuilder();
        for(var e: byLine.entrySet()) {
            List<Piece> ps=e.getValue();
            b.append(name).append(":").append(e.getKey()).append(":");
            for(int i=0;i<ps.size();i++){ if(i>0)b.append(";"); b.append(ps.get(i).s).append("-").append(ps.get(i).e); }
            b.append(":").append(ps.get(0).line).append("\n");
        }
        return b.toString();
    }
    static int[] lineStarts(String t){ArrayList<Integer>a=new ArrayList<>();a.add(0);for(int i=0;i<t.length();i++)if(t.charAt(i)=='\n')a.add(i+1);return a.stream().mapToInt(Integer::intValue).toArray();}
    static int lineOf(int[] starts,int pos){int lo=0,hi=starts.length-1;while(lo<=hi){int mid=(lo+hi)>>>1;if(starts[mid]<=pos)lo=mid+1;else hi=mid-1;}return hi+1;}
}
