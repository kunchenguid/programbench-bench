package melody;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Main {
    public static void main(String[] args) {
        try {
            new Main().run(args);
        } catch (MelodyException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(65);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(65);
        }
    }

    private void run(String[] args) throws IOException {
        String inputPath = null;
        String outputPath = null;
        String test = null;
        String testFile = null;
        boolean repl = false;

        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            switch (arg) {
                case "-h":
                case "--help":
                    printHelp();
                    return;
                case "-V":
                case "--version":
                    System.out.println("melody_cli 0.20.0");
                    return;
                case "-n":
                case "--no-color":
                    break;
                case "-r":
                case "--repl":
                    repl = true;
                    break;
                case "-o":
                case "--output":
                    outputPath = requireValue(args, ++i, arg);
                    break;
                case "-t":
                case "--test":
                    test = requireValue(args, ++i, arg);
                    break;
                case "-f":
                case "--test-file":
                    testFile = requireValue(args, ++i, arg);
                    break;
                case "--generate-completions":
                    requireValue(args, ++i, arg);
                    printCompletions();
                    return;
                default:
                    if (arg.startsWith("-") && !arg.equals("-")) {
                        throw new MelodyException("unexpected argument '" + arg + "'");
                    }
                    inputPath = arg;
            }
        }

        if (repl) {
            System.out.println("Melody REPL is not available in this reimplementation.");
            return;
        }

        String source = readInput(inputPath);
        String regex = new Parser(source).parse();

        if (outputPath != null) {
            Files.writeString(Path.of(outputPath), regex, StandardCharsets.UTF_8);
        }

        if (testFile != null) {
            test = Files.readString(Path.of(testFile), StandardCharsets.UTF_8);
        }
        if (test != null) {
            boolean matched;
            try {
                matched = Pattern.compile(regex).matcher(test).find();
            } catch (PatternSyntaxException e) {
                throw new MelodyException(e.getDescription());
            }
            System.out.println("'" + test + "' " + (matched ? "matched" : "did not match"));
        } else if (outputPath == null) {
            System.out.println(regex);
        }
    }

    private static String requireValue(String[] args, int i, String opt) {
        if (i >= args.length) {
            throw new MelodyException("a value is required for '" + opt + "'");
        }
        return args[i];
    }

    private static String readInput(String inputPath) throws IOException {
        if (inputPath == null || inputPath.equals("-")) {
            return new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        }
        Path path = Path.of(inputPath);
        if (!Files.exists(path)) {
            throw new MelodyException("unable read file at path " + inputPath);
        }
        return Files.readString(path, StandardCharsets.UTF_8);
    }

    private static void printHelp() {
        System.out.println("A CLI wrapping the Melody language compiler\n");
        System.out.println("Usage: executable [OPTIONS] [INPUT_FILE_PATH]\n");
        System.out.println("Arguments:");
        System.out.println("  [INPUT_FILE_PATH]  Read from a file");
        System.out.println("                     Use '-' and or pipe input to read from stdin\n");
        System.out.println("Options:");
        System.out.println("  -o, --output <OUTPUT_FILE_PATH>           Write to a file");
        System.out.println("  -n, --no-color                            Print output with no color");
        System.out.println("  -r, --repl                                Start the Melody REPL");
        System.out.println("      --generate-completions <completions>  Outputs completions for the selected shell");
        System.out.println("                                            To use, write the output to the appropriate location for your shell");
        System.out.println("  -t, --test <test>                         Test the compiled regex against a string");
        System.out.println("  -f, --test-file <test-file>               Test the compiled regex against the contents of a file");
        System.out.println("  -h, --help                                Print help");
        System.out.println("  -V, --version                             Print version");
    }

    private static void printCompletions() {
        System.out.println("_melody() {");
        System.out.println("    COMPREPLY=( $(compgen -W \"-o -n -r -t -f -h -V --output --no-color --repl --generate-completions --test --test-file --help --version\" -- \"${COMP_WORDS[COMP_CWORD]}\") )");
        System.out.println("}");
        System.out.println("complete -F _melody melody");
    }

    static final class Parser {
        private final String src;
        private int pos;
        private final Map<String, String> variables = new HashMap<>();

        Parser(String src) {
            this.src = src;
        }

        String parse() {
            String result = parseSequence('\0');
            skipIgnored();
            if (!eof()) {
                error("expected root");
            }
            return result;
        }

        private String parseSequence(char terminator) {
            StringBuilder out = new StringBuilder();
            while (true) {
                skipIgnored();
                if (eof()) {
                    if (terminator != '\0') {
                        error("expected '" + terminator + "'");
                    }
                    break;
                }
                if (terminator != '\0' && peek() == terminator) {
                    pos++;
                    break;
                }
                out.append(parseStatement());
                skipIgnored();
                if (!eof() && peek() == ';') {
                    pos++;
                }
            }
            return out.toString();
        }

        private String parseStatement() {
            skipIgnored();
            int save = pos;
            String ident = tryIdentifier();
            if (ident != null) {
                skipIgnored();
                if (peekIs('=')) {
                    pos++;
                    String value = parseExpr();
                    variables.put(ident, value);
                    return "";
                }
                pos = save;
            }
            return parseExpr();
        }

        private String parseExpr() {
            skipIgnored();
            Quantifier q = parseQuantifier();
            if (q != null) {
                String inner = parseExpr();
                return applyQuantifier(inner, q);
            }
            if (consumeWord("not")) {
                skipIgnored();
                if (consumeWord("ahead")) {
                    return "(?!" + parseBlock() + ")";
                }
                if (consumeWord("behind")) {
                    return "(?<!" + parseBlock() + ")";
                }
                if (peekIs('<')) {
                    return negateSymbol(parseSymbolName());
                }
                return "[^" + parseExpr() + "]";
            }
            if (consumeWord("range")) {
                String first = parseRangeEndpoint();
                skipIgnored();
                consumeWord("to");
                String second = parseRangeEndpoint();
                return "[" + first + "-" + second + "]";
            }
            if (consumeWord("match")) {
                return "(?:" + parseBlock() + ")";
            }
            if (consumeWord("either")) {
                return "(?:" + String.join("|", parseAlternatives()) + ")";
            }
            if (consumeWord("capture")) {
                String name = null;
                skipIgnored();
                int save = pos;
                if (consumeWord("as")) {
                    skipIgnored();
                    String maybe = tryIdentifier();
                    if (maybe != null) {
                        name = "as " + maybe;
                    }
                } else {
                    String maybe = tryIdentifier();
                    if (maybe != null) {
                        name = maybe;
                    }
                }
                if (name == null) {
                    pos = save;
                }
                String inner = parseBlock();
                return name == null ? "(" + inner + ")" : "(?<" + name + ">" + inner + ")";
            }
            if (consumeWord("ahead")) {
                return "(?=" + parseBlock() + ")";
            }
            if (consumeWord("behind")) {
                return "(?<=" + parseBlock() + ")";
            }
            if (consumeWord("raw")) {
                return parseRaw();
            }
            if (peekIs('`')) {
                return parseRaw();
            }
            if (peekIs('"')) {
                return parseLiteral();
            }
            if (peekIs('<')) {
                return symbolRegex(parseSymbolName());
            }
            String id = tryIdentifier();
            if (id != null && variables.containsKey(id)) {
                return variables.get(id);
            }
            error("expected root");
            return "";
        }

        private List<String> parseAlternatives() {
            skipIgnored();
            expect('{');
            List<String> items = new ArrayList<>();
            while (true) {
                skipIgnored();
                if (peekIs('}')) {
                    pos++;
                    break;
                }
                items.add(parseStatement());
                skipIgnored();
                if (peekIs(';')) {
                    pos++;
                }
            }
            return items;
        }

        private String parseBlock() {
            skipIgnored();
            expect('{');
            return parseSequence('}');
        }

        private Quantifier parseQuantifier() {
            skipIgnored();
            int save = pos;
            if (consumeWord("some")) {
                skipIgnored();
                if (consumeWord("of")) return new Quantifier("+");
            }
            pos = save;
            if (consumeWord("any")) {
                skipIgnored();
                if (consumeWord("of")) return new Quantifier("*");
            }
            pos = save;
            if (consumeWord("option")) {
                skipIgnored();
                if (consumeWord("of")) return new Quantifier("?");
            }
            pos = save;
            Integer first = tryNumber();
            if (first != null) {
                skipIgnored();
                Integer second = null;
                if (consumeWord("to")) {
                    skipIgnored();
                    second = tryNumber();
                    if (second == null) {
                        pos = save;
                        return null;
                    }
                    skipIgnored();
                }
                if (consumeWord("of")) {
                    return second == null
                        ? new Quantifier("{" + first + "}")
                        : new Quantifier("{" + first + "," + second + "}");
                }
            }
            pos = save;
            return null;
        }

        private static String applyQuantifier(String inner, Quantifier q) {
            if (isSingleAtom(inner)) {
                return inner + q.suffix;
            }
            return "(?:" + inner + ")" + q.suffix;
        }

        private static boolean isSingleAtom(String regex) {
            if (regex.length() == 1) return true;
            if (regex.startsWith("\\") && regex.length() == 2) return true;
            if (regex.startsWith("[") && regex.endsWith("]")) return true;
            if (regex.startsWith("(") && regex.endsWith(")")) return true;
            return false;
        }

        private String parseLiteral() {
            expect('"');
            StringBuilder raw = new StringBuilder();
            while (!eof()) {
                char c = src.charAt(pos++);
                if (c == '"') break;
                if (c == '\\' && !eof()) {
                    char n = src.charAt(pos++);
                    switch (n) {
                        case 'n': raw.append('\n'); break;
                        case 'r': raw.append('\r'); break;
                        case 't': raw.append('\t'); break;
                        case '\\': raw.append('\\'); break;
                        case '"': raw.append('"'); break;
                        default: raw.append(n); break;
                    }
                } else {
                    raw.append(c);
                }
            }
            return escapeRegex(raw.toString());
        }

        private String parseRaw() {
            skipIgnored();
            char quote = peekIs('`') ? '`' : '"';
            expect(quote);
            int start = pos;
            while (!eof() && src.charAt(pos) != quote) pos++;
            if (eof()) error("expected '" + quote + "'");
            String out = src.substring(start, pos);
            pos++;
            return out;
        }

        private String parseRangeEndpoint() {
            skipIgnored();
            String value;
            if (peekIs('"')) {
                expect('"');
                if (eof()) error("expected range endpoint");
                char c = src.charAt(pos++);
                value = escapeClass(c);
                while (!eof() && src.charAt(pos) != '"') pos++;
                expect('"');
            } else if (peekIs('<')) {
                String sym = symbolRegex(parseSymbolName());
                value = sym.length() == 1 ? escapeClass(sym.charAt(0)) : sym;
            } else {
                error("expected range endpoint");
                return "";
            }
            return value;
        }

        private String parseSymbolName() {
            expect('<');
            int start = pos;
            while (!eof() && src.charAt(pos) != '>') pos++;
            if (eof()) error("expected '>'");
            String name = src.substring(start, pos).trim();
            pos++;
            return name;
        }

        private static String symbolRegex(String name) {
            switch (name) {
                case "char": return ".";
                case "space": return " ";
                case "whitespace": return "\\s";
                case "digit": return "\\d";
                case "word": return "\\w";
                case "newline": return "\\n";
                case "tab": return "\\t";
                case "return": return "\\r";
                case "boundary": return "\\b";
                case "backspace": return "[\\b]";
                case "null": return "\\0";
                case "alphabetic": return "[a-zA-Z]";
                case "alphanumeric": return "[a-zA-Z0-9]";
                case "vertical": return "\\v";
                case "end": return "$";
                case "start": return "^";
                default:
                    if (name.length() == 3 && name.charAt(1) == '-') {
                        return "[" + escapeClass(name.charAt(0)) + "-" + escapeClass(name.charAt(2)) + "]";
                    }
                    throw new MelodyException("usage of an unrecognized symbol");
            }
        }

        private static String negateSymbol(String name) {
            switch (name) {
                case "digit": return "\\D";
                case "word": return "\\W";
                case "whitespace": return "\\S";
                case "space": return "[^ ]";
                case "char": return "[^.]";
                default:
                    String r = symbolRegex(name);
                    if (r.startsWith("[") && r.endsWith("]")) {
                        return "[^" + r.substring(1, r.length() - 1) + "]";
                    }
                    return "(?!" + r + ").";
            }
        }

        private static String escapeRegex(String s) {
            String specials = "\\.[]{}()*+-?^$|";
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (specials.indexOf(c) >= 0) out.append('\\');
                out.append(c);
            }
            return out.toString();
        }

        private static String escapeClass(char c) {
            return c == '\\' || c == ']' || c == '^' ? "\\" + c : Character.toString(c);
        }

        private void skipIgnored() {
            while (!eof()) {
                char c = src.charAt(pos);
                if (Character.isWhitespace(c)) {
                    pos++;
                    continue;
                }
                if (c == '/' && pos + 1 < src.length() && src.charAt(pos + 1) == '/') {
                    pos += 2;
                    while (!eof() && src.charAt(pos) != '\n') pos++;
                    continue;
                }
                break;
            }
        }

        private boolean consumeWord(String word) {
            skipIgnored();
            int end = pos + word.length();
            if (end <= src.length() && src.substring(pos, end).equals(word)
                && (end == src.length() || !isIdentifierPart(src.charAt(end)))) {
                pos = end;
                return true;
            }
            return false;
        }

        private String tryIdentifier() {
            skipIgnored();
            if (eof() || !isIdentifierStart(src.charAt(pos))) return null;
            int start = pos++;
            while (!eof() && isIdentifierPart(src.charAt(pos))) pos++;
            return src.substring(start, pos);
        }

        private Integer tryNumber() {
            skipIgnored();
            int start = pos;
            while (!eof() && Character.isDigit(src.charAt(pos))) pos++;
            if (start == pos) return null;
            return Integer.parseInt(src.substring(start, pos));
        }

        private static boolean isIdentifierStart(char c) {
            return Character.isLetter(c) || c == '_';
        }

        private static boolean isIdentifierPart(char c) {
            return Character.isLetterOrDigit(c) || c == '_' || c == '-';
        }

        private boolean peekIs(char c) {
            skipIgnored();
            return !eof() && src.charAt(pos) == c;
        }

        private char peek() {
            return src.charAt(pos);
        }

        private void expect(char c) {
            skipIgnored();
            if (eof() || src.charAt(pos) != c) error("expected '" + c + "'");
            pos++;
        }

        private boolean eof() {
            return pos >= src.length();
        }

        private void error(String msg) {
            throw new MelodyException(msg);
        }
    }

    static final class Quantifier {
        final String suffix;
        Quantifier(String suffix) {
            this.suffix = suffix;
        }
    }

    static final class MelodyException extends RuntimeException {
        MelodyException(String message) {
            super(message);
        }
    }
}
