package com.programbench.xcp;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public final class Main {
    private static final String VERSION = "xcp 0.24.3";

    private final Options opt = new Options();

    public static void main(String[] args) {
        int status = new Main().run(args);
        if (status != 0) {
            System.exit(status);
        }
    }

    private int run(String[] args) {
        try {
            parse(args);
            if (opt.help) {
                printHelp(opt.longHelp);
                return 0;
            }
            if (opt.version) {
                System.out.println(VERSION);
                return 0;
            }
            validate();
            execute();
            return 0;
        } catch (UsageException e) {
            if (e.clapStyle) {
                System.err.println(e.getMessage());
                System.err.println();
                System.err.println("For more information, try '--help'.");
                return 2;
            }
            System.err.println("Error: " + e.getMessage());
            return e.status;
        } catch (CopyException e) {
            if (opt.verbose > 0) {
                System.err.println(timePrefix() + " [ERROR] Received error: " + e.getMessage());
            }
            System.err.println("Error: " + e.getMessage());
            return 1;
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return 1;
        }
    }

    private void parse(String[] args) throws UsageException {
        boolean endOptions = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (endOptions || !a.startsWith("-") || a.equals("-")) {
                opt.paths.add(a);
                continue;
            }
            if (a.equals("--")) {
                endOptions = true;
                continue;
            }
            switch (a) {
                case "-h" -> { opt.help = true; opt.longHelp = false; }
                case "--help" -> { opt.help = true; opt.longHelp = true; }
                case "-V", "--version" -> opt.version = true;
                case "-r", "--recursive" -> opt.recursive = true;
                case "-L", "--dereference" -> opt.dereference = true;
                case "-n", "--no-clobber" -> opt.noClobber = true;
                case "-f", "--force" -> opt.force = true;
                case "--gitignore" -> opt.gitignore = true;
                case "-g", "--glob" -> opt.glob = true;
                case "--no-progress" -> opt.noProgress = true;
                case "--no-perms" -> opt.noPerms = true;
                case "--no-timestamps" -> opt.noTimestamps = true;
                case "-o", "--ownership" -> opt.ownership = true;
                case "-T", "--no-target-directory" -> opt.noTargetDirectory = true;
                case "--fsync" -> opt.fsync = true;
                case "-v", "--verbose" -> opt.verbose++;
                case "-w", "--workers" -> opt.workers = readValue(args, ++i, a);
                case "--block-size" -> opt.blockSize = readValue(args, ++i, a);
                case "--driver" -> opt.driver = readValue(args, ++i, a);
                case "--reflink" -> opt.reflink = readValue(args, ++i, a);
                case "--backup" -> opt.backup = readValue(args, ++i, a);
                case "--target-directory" -> opt.targetDirectory = readValue(args, ++i, a);
                default -> {
                    if (a.startsWith("-v") && a.chars().allMatch(ch -> ch == '-' || ch == 'v')) {
                        opt.verbose += a.length() - 1;
                    } else if (a.startsWith("--workers=")) {
                        opt.workers = a.substring(10);
                    } else if (a.startsWith("--block-size=")) {
                        opt.blockSize = a.substring(13);
                    } else if (a.startsWith("--driver=")) {
                        opt.driver = a.substring(9);
                    } else if (a.startsWith("--reflink=")) {
                        opt.reflink = a.substring(10);
                    } else if (a.startsWith("--backup=")) {
                        opt.backup = a.substring(9);
                    } else if (a.startsWith("--target-directory=")) {
                        opt.targetDirectory = a.substring(19);
                    } else {
                        throw new UsageException("error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] [PATHS]...", 2, true);
                    }
                }
            }
        }
    }

    private static String readValue(String[] args, int index, String opt) throws UsageException {
        if (index >= args.length) {
            throw new UsageException("error: a value is required for '" + opt + " <" + optName(opt) + ">' but none was supplied", 2, true);
        }
        return args[index];
    }

    private static String optName(String opt) {
        return opt.replaceFirst("^-+", "").replace('-', '_').toUpperCase();
    }

    private void validate() throws UsageException, IOException {
        if (opt.help || opt.version) return;
        if (opt.force && opt.noClobber) {
            throw new UsageException("Invalid arguments: --force and --noclobber cannot be set at the same time.", 1, false);
        }
        validateWorkers();
        validateBlockSize();
        if (!opt.driver.equals("parfile") && !opt.driver.equals("file-parallel") && !opt.driver.equals("parblock")) {
            throw new UsageException("error: invalid value '" + opt.driver + "' for '--driver <DRIVER>': Unknown driver: " + opt.driver, 2, true);
        }
        if (!Set.of("auto", "always", "never").contains(opt.reflink)) {
            throw new UsageException("error: invalid value '" + opt.reflink + "' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': " + opt.reflink, 2, true);
        }
        if (!Set.of("none", "off", "numbered", "auto").contains(opt.backup)) {
            throw new UsageException("error: invalid value '" + opt.backup + "' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': " + opt.backup, 2, true);
        }
        if (opt.glob) {
            opt.paths = expandGlobs(opt.paths);
        }
        if (opt.targetDirectory != null) {
            opt.paths.add(opt.targetDirectory);
        }
        if (opt.paths.size() < 2) {
            throw new UsageException("Invalid arguments: Insufficient arguments", 1, false);
        }
    }

    private void validateWorkers() throws UsageException {
        try {
            Integer.parseInt(opt.workers);
        } catch (NumberFormatException e) {
            throw new UsageException("error: invalid value '" + opt.workers + "' for '--workers <WORKERS>': invalid digit found in string", 2, true);
        }
    }

    private void validateBlockSize() throws UsageException {
        String s = opt.blockSize.trim();
        if (!s.matches("[0-9]+([KMGTP]B?|[kmgpt]b?|B|b)?")) {
            throw new UsageException("error: invalid value '" + opt.blockSize + "' for '--block-size <BLOCK_SIZE>': could not interpret string as byte size", 2, true);
        }
    }

    private List<String> expandGlobs(List<String> input) throws IOException {
        List<String> out = new ArrayList<>();
        for (String s : input) {
            if (!hasGlob(s)) {
                out.add(s);
                continue;
            }
            Path p = Paths.get(s);
            Path dir = p.getParent();
            if (dir == null) dir = Paths.get(".");
            String pat = p.getFileName().toString();
            Pattern regex = globPattern(pat);
            List<String> matches = new ArrayList<>();
            if (Files.isDirectory(dir)) {
                try (var stream = Files.list(dir)) {
                    stream.filter(x -> regex.matcher(x.getFileName().toString()).matches())
                            .forEach(x -> matches.add(x.toString()));
                }
            }
            if (matches.isEmpty()) out.add(s); else out.addAll(matches);
        }
        return out;
    }

    private static boolean hasGlob(String s) {
        return s.indexOf('*') >= 0 || s.indexOf('?') >= 0 || s.indexOf('[') >= 0;
    }

    private static Pattern globPattern(String glob) {
        StringBuilder sb = new StringBuilder("^");
        for (int i = 0; i < glob.length(); i++) {
            char c = glob.charAt(i);
            switch (c) {
                case '*' -> sb.append(".*");
                case '?' -> sb.append('.');
                case '.', '(', ')', '+', '|', '^', '$', '@', '%', '{', '}', '\\' -> sb.append('\\').append(c);
                default -> sb.append(c);
            }
        }
        sb.append('$');
        return Pattern.compile(sb.toString());
    }

    private void execute() throws IOException, CopyException {
        int n = opt.paths.size();
        List<Path> sources = new ArrayList<>();
        for (int i = 0; i < n - 1; i++) sources.add(Paths.get(opt.paths.get(i)));
        Path dest = Paths.get(opt.paths.get(n - 1));

        for (Path src : sources) {
            if (!exists(src)) {
                throw new CopyException("Invalid source: No source files found.");
            }
        }
        if (sources.size() > 1 && !Files.isDirectory(dest)) {
            throw new CopyException("Invalid destination: Multiple sources and destination is not a directory.");
        }

        for (Path src : sources) {
            Path target = determineTarget(src, dest, sources.size());
            copySource(src, target);
        }
    }

    private boolean exists(Path p) {
        return opt.dereference ? Files.exists(p) : Files.exists(p, LinkOption.NOFOLLOW_LINKS);
    }

    private Path determineTarget(Path src, Path dest, int sourceCount) {
        if (opt.noTargetDirectory) return dest;
        if (sourceCount > 1 || Files.isDirectory(dest)) {
            Path name = src.getFileName();
            return name == null ? dest : dest.resolve(name);
        }
        return dest;
    }

    private void copySource(Path src, Path target) throws IOException, CopyException {
        BasicFileAttributes attrs = Files.readAttributes(src, BasicFileAttributes.class,
                opt.dereference ? new LinkOption[]{} : new LinkOption[]{LinkOption.NOFOLLOW_LINKS});
        if (attrs.isDirectory()) {
            if (!opt.recursive) {
                throw new CopyException("Invalid source: Source is directory and --recursive not specified.");
            }
            copyDirectory(src, target);
        } else if (attrs.isSymbolicLink() && !opt.dereference) {
            copySymlink(src, target);
        } else {
            copyFile(src, target);
        }
    }

    private void copyDirectory(Path src, Path target) throws IOException, CopyException {
        final List<Pattern> ignores = opt.gitignore ? readGitignore(src) : List.of();
        Files.walkFileTree(src, opt.dereference ? Set.of(java.nio.file.FileVisitOption.FOLLOW_LINKS) : Set.of(), Integer.MAX_VALUE,
                new SimpleFileVisitor<>() {
                    @Override
                    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                        Path rel = src.relativize(dir);
                        if (!rel.toString().isEmpty() && isIgnored(rel, ignores)) return FileVisitResult.SKIP_SUBTREE;
                        Path dst = rel.toString().isEmpty() ? target : target.resolve(rel);
                        createDirectory(dst, dir);
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        Path rel = src.relativize(file);
                        if (isIgnored(rel, ignores)) return FileVisitResult.CONTINUE;
                        try {
                            if (Files.isSymbolicLink(file) && !opt.dereference) copySymlink(file, target.resolve(rel));
                            else copyFile(file, target.resolve(rel));
                        } catch (CopyException e) {
                            throw new WrappedCopyException(e);
                        }
                        return FileVisitResult.CONTINUE;
                    }
                });
        if (!opt.noTimestamps) {
            try { Files.setLastModifiedTime(target, Files.getLastModifiedTime(src, LinkOption.NOFOLLOW_LINKS)); } catch (Exception ignored) {}
        }
        if (!opt.noPerms) copyPerms(src, target);
    }

    private void createDirectory(Path dst, Path src) throws IOException {
        if (Files.exists(dst, LinkOption.NOFOLLOW_LINKS) && !Files.isDirectory(dst, LinkOption.NOFOLLOW_LINKS)) {
            if (opt.noClobber) throw new FileAlreadyExistsException(dst.toString());
            backupIfNeeded(dst);
            Files.delete(dst);
        }
        if (!Files.exists(dst, LinkOption.NOFOLLOW_LINKS)) Files.createDirectories(dst);
        if (!opt.noPerms) copyPerms(src, dst);
    }

    private void copyFile(Path src, Path target) throws IOException, CopyException {
        if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) {
            if (opt.noClobber) {
                throw new CopyException("Destination Exists: Destination file exists and --no-clobber is set., " + target);
            }
            backupIfNeeded(target);
        } else if (target.getParent() != null) {
            Files.createDirectories(target.getParent());
        }
        List<StandardCopyOption> opts = new ArrayList<>();
        opts.add(StandardCopyOption.REPLACE_EXISTING);
        if (!opt.noTimestamps) opts.add(StandardCopyOption.COPY_ATTRIBUTES);
        Files.copy(src, target, opts.toArray(StandardCopyOption[]::new));
        if (!opt.noPerms) copyPerms(src, target);
        if (opt.noTimestamps) {
            try { Files.setLastModifiedTime(target, FileTime.fromMillis(System.currentTimeMillis())); } catch (Exception ignored) {}
        }
    }

    private void copySymlink(Path src, Path target) throws IOException, CopyException {
        if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) {
            if (opt.noClobber) {
                throw new CopyException("Destination Exists: Destination file exists and --no-clobber is set., " + target);
            }
            backupIfNeeded(target);
            Files.delete(target);
        } else if (target.getParent() != null) {
            Files.createDirectories(target.getParent());
        }
        Files.createSymbolicLink(target, Files.readSymbolicLink(src));
    }

    private void backupIfNeeded(Path target) throws IOException {
        if (opt.backup.equals("none") || opt.backup.equals("off")) return;
        boolean doBackup = opt.backup.equals("numbered") || hasExistingBackup(target);
        if (!doBackup) return;
        int i = 1;
        Path bak;
        do {
            bak = target.resolveSibling(target.getFileName() + ".~" + i + "~");
            i++;
        } while (Files.exists(bak, LinkOption.NOFOLLOW_LINKS));
        Files.move(target, bak);
    }

    private boolean hasExistingBackup(Path target) {
        Path dir = target.getParent();
        if (dir == null) dir = Paths.get(".");
        String prefix = target.getFileName() + ".~";
        try (var stream = Files.list(dir)) {
            return stream.anyMatch(p -> {
                String n = p.getFileName().toString();
                return n.startsWith(prefix) && n.endsWith("~");
            });
        } catch (IOException e) {
            return false;
        }
    }

    private void copyPerms(Path src, Path dst) {
        try {
            Set<PosixFilePermission> perms = Files.getPosixFilePermissions(src, LinkOption.NOFOLLOW_LINKS);
            Files.setPosixFilePermissions(dst, perms);
        } catch (Exception ignored) {
        }
    }

    private List<Pattern> readGitignore(Path root) {
        Path gi = root.resolve(".gitignore");
        if (!Files.isRegularFile(gi)) return List.of();
        List<Pattern> pats = new ArrayList<>();
        try {
            for (String raw : Files.readAllLines(gi)) {
                String s = raw.trim();
                if (s.isEmpty() || s.startsWith("#") || s.startsWith("!")) continue;
                if (s.startsWith("/")) s = s.substring(1);
                pats.add(globPattern(s));
            }
        } catch (IOException ignored) {
        }
        return pats;
    }

    private boolean isIgnored(Path rel, List<Pattern> ignores) {
        if (ignores.isEmpty()) return false;
        String unix = rel.toString().replace('\\', '/');
        String name = rel.getFileName() == null ? unix : rel.getFileName().toString();
        for (Pattern p : ignores) {
            if (p.matcher(unix).matches() || p.matcher(name).matches()) return true;
        }
        return false;
    }

    private static String timePrefix() {
        java.time.LocalTime t = java.time.LocalTime.now();
        return "%02d:%02d:%02d".formatted(t.getHour(), t.getMinute(), t.getSecond());
    }

    private static void printHelp(boolean verbose) {
        if (verbose) {
            System.out.println("""
A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.
          
          Source and destination files, or multiple source(s) to a directory.

Options:
  -v, --verbose...
          Verbosity.
          
          Can be specified multiple times to increase logging.

  -r, --recursive
          Copy directories recursively

  -L, --dereference
          Dereference symlinks in source

  -w, --workers <WORKERS>
          Number of parallel workers.
          
          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
          
          [default: 4]

      --block-size <BLOCK_SIZE>
          Block size for operations.
          
          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
          
          [default: 1MB]

  -n, --no-clobber
          Do not overwrite an existing file

  -f, --force
          Force (compatability only)
          
          Overwrite files; this is the default behaviour, this flag is for compatibility with `cp` only. See `--no-clobber` for the inverse flag. Using this in conjunction with `--no-clobber` will cause an error.

      --gitignore
          Use .gitignore if present.
          
          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

  -g, --glob
          Expand file patterns.
          
          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

      --no-progress
          Disable progress bar

      --no-perms
          Do not copy the file permissions

      --no-timestamps
          Do not copy the file timestamps

  -o, --ownership
          Copy ownership.
          
          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.

      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.
          
          Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.
          
          [default: parfile]

  -T, --no-target-directory
          Target should not be a directory.
          
          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.

      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target

      --fsync
          Sync each file to disk after writing

      --reflink <REFLINK>
          Reflink options.
          
          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.
          
          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.
          
          [default: auto]

      --backup <BACKUP>
          Backup options
          
          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of `cp` numbered backups (e.g. `file.txt.~123~`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.
          
          [default: none]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version""");
        } else {
            System.out.println("""
A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version""");
        }
    }

    private static final class Options {
        boolean help, longHelp, version, recursive, dereference, noClobber, force, gitignore, glob;
        boolean noProgress, noPerms, noTimestamps, ownership, noTargetDirectory, fsync;
        int verbose;
        String workers = "4";
        String blockSize = "1MB";
        String driver = "parfile";
        String reflink = "auto";
        String backup = "none";
        String targetDirectory;
        List<String> paths = new ArrayList<>();
    }

    private static class UsageException extends Exception {
        final int status;
        final boolean clapStyle;
        UsageException(String msg, int status, boolean clapStyle) {
            super(msg);
            this.status = status;
            this.clapStyle = clapStyle;
        }
    }

    private static class CopyException extends Exception {
        CopyException(String msg) { super(msg); }
    }

    private static class WrappedCopyException extends IOException {
        WrappedCopyException(CopyException cause) { super(cause); }
    }
}
