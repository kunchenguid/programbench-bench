package org.programbench.tigclone;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class TigClone {
    private static final String VERSION = "2.6.0-g87c9c25";
    private static final String NCURSES_VERSION = "6.3.20211021";

    private static final String HELP = "tig " + VERSION + " \n" +
            "\n" +
            "Usage: tig        [options] [revs] [--] [paths]\n" +
            "   or: tig log    [options] [revs] [--] [paths]\n" +
            "   or: tig show   [options] [revs] [--] [paths]\n" +
            "   or: tig reflog [options] [revs]\n" +
            "   or: tig blame  [options] [rev] [--] path\n" +
            "   or: tig grep   [options] [pattern]\n" +
            "   or: tig refs   [options]\n" +
            "   or: tig stash  [options]\n" +
            "   or: tig status\n" +
            "   or: tig <      [git command output]\n" +
            "\n" +
            "Options:\n" +
            "  +<number>       Select line <number> in the first view\n" +
            "  -v, --version   Show version and exit\n" +
            "  -h, --help      Show help message and exit\n" +
            "  -C <path>       Start in <path>\n";

    private TigClone() {
    }

    public static void main(String[] argv) {
        int code = run(argv);
        if (code != 0) {
            System.exit(code);
        }
    }

    private static int run(String[] argv) {
        List<String> args = new ArrayList<>(Arrays.asList(argv));

        for (int i = 0; i < args.size(); i++) {
            String arg = args.get(i);
            if ("-C".equals(arg)) {
                if (i + 1 < args.size()) {
                    File dir = new File(args.get(i + 1));
                    if (!dir.isDirectory()) {
                        System.err.println("tig: Failed to change directory to " + args.get(i + 1));
                        return 1;
                    }
                    args.remove(i + 1);
                    args.remove(i);
                    i--;
                }
            } else if (arg.startsWith("-C") && arg.length() > 2) {
                File dir = new File(arg.substring(2));
                if (!dir.isDirectory()) {
                    System.err.println("tig: Failed to change directory to " + arg.substring(2));
                    return 1;
                }
                args.remove(i);
                i--;
            }
        }

        for (String arg : args) {
            if ("-h".equals(arg) || "--help".equals(arg)) {
                System.out.print(HELP);
                return 0;
            }
            if ("-v".equals(arg) || "--version".equals(arg)) {
                printVersion();
                return 0;
            }
        }

        if (looksLikeBadRevision(args)) {
            System.err.println("tig: No revisions match the given arguments.");
            return 1;
        }

        System.err.println("tig: Failed to open tty for input");
        return 1;
    }

    private static void printVersion() {
        System.out.println("tig version " + VERSION);
        System.out.println("ncursesw version " + NCURSES_VERSION);
    }

    private static boolean looksLikeBadRevision(List<String> args) {
        if (args.isEmpty()) {
            return false;
        }
        String first = args.get(0);
        if (("status".equals(first) || "refs".equals(first) || "stash".equals(first)) && args.size() > 1) {
            return true;
        }
        if ("help".equals(first) || "version".equals(first)) {
            return true;
        }
        return false;
    }
}
