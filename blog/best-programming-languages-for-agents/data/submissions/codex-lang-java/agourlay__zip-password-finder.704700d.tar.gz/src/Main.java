import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.function.Predicate;
import java.util.zip.CRC32;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class Main {
    static class Options {
        String inputFile;
        String dict;
        String charset = "lud";
        String charsetFile;
        int minLen = 1;
        int maxLen = 10;
        int fileNumber = 0;
        String startingPassword;
    }

    static class Entry {
        int flags, method, modTime, crc, compSize, uncompSize;
        String name;
        byte[] extra, data;
        int aesStrength = 0, aesMethod = -1;
        boolean encrypted() { return (flags & 1) != 0; }
    }

    public static void main(String[] args) {
        long start = System.nanoTime();
        try {
            Options o = parse(args);
            if (o == null) return;
            validate(o);
            List<Entry> entries = readEntries(Paths.get(o.inputFile));
            if (o.fileNumber < 0 || o.fileNumber >= entries.size()) {
                System.out.println("CLI argument error - \"'fileNumber' must be a valid file number in the zip archive\"");
                return;
            }
            Entry e = entries.get(o.fileNumber);
            Predicate<String> test = p -> checkPassword(e, p);
            String found = null;
            if (o.dict != null) {
                try (BufferedReader br = Files.newBufferedReader(Paths.get(o.dict), StandardCharsets.UTF_8)) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        if (test.test(line)) { found = line; break; }
                    }
                }
            } else {
                String chars = charset(o);
                found = brute(chars, o.minLen, o.maxLen, o.startingPassword, test);
            }
            printElapsed(start);
            if (found == null) System.out.println("Password not found");
            else System.out.println("Password found:" + found);
        } catch (CliError ce) {
            System.out.println("CLI argument error - \"" + ce.getMessage() + "\"");
        } catch (NumberFormatException ne) {
            // parse() prints clap-like messages for numeric errors.
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    static Options parse(String[] args) {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": help(); return null;
                case "-V": case "--version": System.out.println("zip-password-finder 0.10.3"); return null;
                case "-i": case "--inputFile": o.inputFile = need(args, ++i, a); break;
                case "-w": case "--workers": parseInt(need(args, ++i, a), "workers"); break;
                case "-p": case "--passwordDictionary": o.dict = need(args, ++i, a); break;
                case "-c": case "--charset": o.charset = need(args, ++i, a); break;
                case "--charsetFile": o.charsetFile = need(args, ++i, a); break;
                case "--minPasswordLen": o.minLen = parseInt(need(args, ++i, a), "minPasswordLen"); break;
                case "--maxPasswordLen": o.maxLen = parseInt(need(args, ++i, a), "maxPasswordLen"); break;
                case "--fileNumber": o.fileNumber = parseInt(need(args, ++i, a), "fileNumber"); break;
                case "-s": case "--startingPassword": o.startingPassword = need(args, ++i, a); break;
                default:
                    System.err.println("error: unexpected argument '" + a + "' found\n");
                    System.err.println("Usage: executable [OPTIONS] --inputFile <inputFile>\n");
                    System.err.println("For more information, try '--help'.");
                    return null;
            }
        }
        if (o.inputFile == null) {
            System.err.println("error: the following required arguments were not provided:");
            System.err.println("  --inputFile <inputFile>\n");
            System.err.println("Usage: executable --inputFile <inputFile>\n");
            System.err.println("For more information, try '--help'.");
            return null;
        }
        return o;
    }

    static String need(String[] args, int i, String opt) {
        if (i >= args.length) throw new RuntimeException("missing value for " + opt);
        return args[i];
    }

    static int parseInt(String s, String name) {
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) {
            System.err.println("error: invalid value '" + s + "' for '--" + name + " <" + name + ">': invalid digit found in string\n");
            System.err.println("For more information, try '--help'.");
            throw e;
        }
    }

    static void validate(Options o) throws CliError, IOException {
        if (!Files.exists(Paths.get(o.inputFile))) throw new CliError("'inputFile' does not exist");
        if (o.dict != null && !Files.exists(Paths.get(o.dict))) throw new CliError("'passwordDictionary' does not exist");
        if (o.charsetFile != null && !Files.exists(Paths.get(o.charsetFile))) throw new CliError("'charsetFile' does not exist");
        if (o.maxLen < o.minLen) throw new CliError("'maxPasswordLen' must be equal or greater than 'minPasswordLen'");
        if (o.charsetFile == null) charset(o);
    }

    static class CliError extends Exception { CliError(String m) { super(m); } }

    static void help() {
        System.out.println("Find the password of protected ZIP files\n");
        System.out.println("Usage: executable [OPTIONS] --inputFile <inputFile>\n");
        System.out.println("Options:");
        System.out.println("  -i, --inputFile <inputFile>                    path to zip input file");
        System.out.println("  -w, --workers <workers>                        number of workers");
        System.out.println("  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file");
        System.out.println("  -c, --charset <charset>                        charset to use to generate password [default: lud]");
        System.out.println("      --charsetFile <charsetFile>                path to a charset file");
        System.out.println("      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]");
        System.out.println("      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]");
        System.out.println("      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]");
        System.out.println("  -s, --startingPassword <startingPassword>      password to start from");
        System.out.println("  -h, --help                                     Print help");
        System.out.println("  -V, --version                                  Print version");
    }

    static String charset(Options o) throws CliError, IOException {
        if (o.charsetFile != null) return Files.readString(Paths.get(o.charsetFile));
        StringBuilder sb = new StringBuilder();
        for (char c : o.charset.toCharArray()) {
            switch (c) {
                case 'l': sb.append("abcdefghijklmnopqrstuvwxyz"); break;
                case 'u': sb.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ"); break;
                case 'd': sb.append("0123456789"); break;
                case 'h': sb.append("0123456789abcdef"); break;
                case 'H': sb.append("0123456789ABCDEF"); break;
                case 's': sb.append(" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"); break;
                default: throw new CliError("Unknown charset option '" + c + "'");
            }
        }
        return sb.toString();
    }

    static String brute(String chars, int min, int max, String start, Predicate<String> test) {
        if (chars.isEmpty()) return null;
        boolean skipping = start != null;
        for (int len = min; len <= max; len++) {
            long total = 1;
            for (int i = 0; i < len; i++) {
                if (total > Long.MAX_VALUE / chars.length()) { total = Long.MAX_VALUE; break; }
                total *= chars.length();
            }
            int[] idx = new int[len];
            for (long n = 0; n < total; n++) {
                StringBuilder sb = new StringBuilder(len);
                for (int j = 0; j < len; j++) sb.append(chars.charAt(idx[j]));
                String p = sb.toString();
                if (skipping) {
                    if (!p.equals(start)) { inc(idx, chars.length()); continue; }
                    skipping = false;
                }
                if (test.test(p)) return p;
                inc(idx, chars.length());
            }
        }
        return null;
    }

    static void inc(int[] idx, int base) {
        for (int p = idx.length - 1; p >= 0; p--) {
            if (++idx[p] < base) return;
            idx[p] = 0;
        }
    }

    static List<Entry> readEntries(Path path) throws IOException {
        byte[] b = Files.readAllBytes(path);
        List<Entry> out = new ArrayList<>();
        int p = 0;
        while (p + 30 <= b.length && get32(b, p) == 0x04034b50L) {
            Entry e = new Entry();
            e.flags = get16(b, p + 6);
            e.method = get16(b, p + 8);
            e.modTime = get16(b, p + 10);
            e.crc = (int)get32(b, p + 14);
            e.compSize = (int)get32(b, p + 18);
            e.uncompSize = (int)get32(b, p + 22);
            int nlen = get16(b, p + 26), xlen = get16(b, p + 28);
            int q = p + 30;
            e.name = new String(b, q, nlen, StandardCharsets.UTF_8); q += nlen;
            e.extra = Arrays.copyOfRange(b, q, q + xlen); q += xlen;
            parseAes(e);
            if (e.compSize < 0 || q + e.compSize > b.length) break;
            e.data = Arrays.copyOfRange(b, q, q + e.compSize);
            out.add(e);
            p = q + e.compSize;
            if ((e.flags & 8) != 0) {
                int sig = (p + 4 <= b.length && get32(b, p) == 0x08074b50L) ? 4 : 0;
                p += sig + 12;
            }
        }
        return out;
    }

    static void parseAes(Entry e) {
        for (int p = 0; p + 4 <= e.extra.length;) {
            int id = get16(e.extra, p), len = get16(e.extra, p + 2); p += 4;
            if (p + len > e.extra.length) break;
            if (id == 0x9901 && len >= 7) {
                e.aesStrength = e.extra[p + 4] & 0xff;
                e.aesMethod = get16(e.extra, p + 5);
            }
            p += len;
        }
    }

    static boolean checkPassword(Entry e, String password) {
        try {
            if (!e.encrypted()) return password.isEmpty();
            if (e.method == 99 || e.aesStrength != 0) return checkAes(e, password);
            return checkZipCrypto(e, password);
        } catch (Exception ex) { return false; }
    }

    static boolean checkZipCrypto(Entry e, String password) throws Exception {
        if (e.data.length < 12) return false;
        ZipKeys k = new ZipKeys(password.getBytes(StandardCharsets.UTF_8));
        byte[] head = new byte[12];
        for (int i = 0; i < 12; i++) head[i] = (byte)(e.data[i] ^ k.decryptByteUpdate(e.data[i]));
        int check = ((e.flags & 8) != 0) ? ((e.modTime >>> 8) & 0xff) : ((e.crc >>> 24) & 0xff);
        if ((head[11] & 0xff) != check) return false;
        byte[] c = Arrays.copyOfRange(e.data, 12, e.data.length);
        byte[] plainComp = new byte[c.length];
        for (int i = 0; i < c.length; i++) plainComp[i] = (byte)(c[i] ^ k.decryptByteUpdate(c[i]));
        byte[] plain = uncompress(plainComp, e.method, e.uncompSize);
        CRC32 crc = new CRC32(); crc.update(plain);
        return (int)crc.getValue() == e.crc;
    }

    static boolean checkAes(Entry e, String password) throws Exception {
        int keyLen = e.aesStrength == 1 ? 16 : e.aesStrength == 2 ? 24 : 32;
        int saltLen = e.aesStrength == 1 ? 8 : e.aesStrength == 2 ? 12 : 16;
        if (e.data.length < saltLen + 12) return false;
        byte[] salt = Arrays.copyOfRange(e.data, 0, saltLen);
        byte[] verifier = Arrays.copyOfRange(e.data, saltLen, saltLen + 2);
        int encStart = saltLen + 2, encEnd = e.data.length - 10;
        byte[] enc = Arrays.copyOfRange(e.data, encStart, encEnd);
        byte[] auth = Arrays.copyOfRange(e.data, encEnd, e.data.length);
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 1000, (2 * keyLen + 2) * 8);
        byte[] keymat = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).getEncoded();
        if (keymat[2 * keyLen] != verifier[0] || keymat[2 * keyLen + 1] != verifier[1]) return false;
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(Arrays.copyOfRange(keymat, keyLen, 2 * keyLen), "HmacSHA1"));
        byte[] got = Arrays.copyOf(mac.doFinal(enc), 10);
        if (!Arrays.equals(got, auth)) return false;
        byte[] comp = aesCtr(enc, Arrays.copyOfRange(keymat, 0, keyLen));
        byte[] plain = uncompress(comp, e.aesMethod, e.uncompSize);
        if (e.crc != 0) { CRC32 crc = new CRC32(); crc.update(plain); return (int)crc.getValue() == e.crc; }
        return true;
    }

    static byte[] aesCtr(byte[] in, byte[] key) throws Exception {
        Cipher aes = Cipher.getInstance("AES/ECB/NoPadding");
        aes.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"));
        byte[] out = new byte[in.length];
        long ctr = 1; int pos = 0;
        while (pos < in.length) {
            byte[] block = new byte[16];
            long x = ctr++;
            for (int i = 0; i < 8; i++) { block[i] = (byte)(x & 0xff); x >>>= 8; }
            byte[] ks = aes.doFinal(block);
            for (int i = 0; i < 16 && pos < in.length; i++, pos++) out[pos] = (byte)(in[pos] ^ ks[i]);
        }
        return out;
    }

    static byte[] uncompress(byte[] comp, int method, int expected) throws IOException, DataFormatException {
        if (method == 0) return comp;
        if (method != 8) return comp;
        Inflater inf = new Inflater(true);
        inf.setInput(comp);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(expected > 0 ? expected : comp.length * 2);
        byte[] buf = new byte[4096];
        while (!inf.finished()) {
            int n = inf.inflate(buf);
            if (n == 0) {
                if (inf.needsInput()) break;
                throw new DataFormatException("inflate stalled");
            }
            bos.write(buf, 0, n);
        }
        return bos.toByteArray();
    }

    static class ZipKeys {
        long k0 = 0x12345678L, k1 = 0x23456789L, k2 = 0x34567890L;
        ZipKeys(byte[] pwd) { for (byte b : pwd) update(b & 0xff); }
        int decryptByteUpdate(byte cipher) {
            int t = (int)((k2 | 2) & 0xffff);
            int key = ((t * (t ^ 1)) >>> 8) & 0xff;
            int plain = (cipher & 0xff) ^ key;
            update(plain);
            return key;
        }
        void update(int b) {
            k0 = crc32(k0, b);
            k1 = (k1 + (k0 & 0xff)) & 0xffffffffL;
            k1 = (k1 * 134775813L + 1) & 0xffffffffL;
            k2 = crc32(k2, (int)(k1 >>> 24));
        }
    }

    static final long[] CRCT = new long[256];
    static { for (int n = 0; n < 256; n++) { long c = n; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xedb88320L ^ (c >>> 1) : c >>> 1; CRCT[n] = c; } }
    static long crc32(long old, int b) { return ((old >>> 8) ^ CRCT[(int)((old ^ b) & 0xff)]) & 0xffffffffL; }
    static int get16(byte[] b, int p) { return (b[p] & 255) | ((b[p+1] & 255) << 8); }
    static long get32(byte[] b, int p) { return (get16(b,p) | ((long)get16(b,p+2) << 16)) & 0xffffffffL; }

    static void printElapsed(long start) {
        long ns = System.nanoTime() - start;
        long ms = ns / 1_000_000; ns %= 1_000_000;
        long us = ns / 1_000; ns %= 1_000;
        System.out.println("Time elapsed: " + ms + "ms " + us + "us " + ns + "ns");
    }
}
