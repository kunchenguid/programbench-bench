import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

public class SkeemaClone {
    static final String VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z";
    static final Set<String> COMMANDS = new LinkedHashSet<>(Arrays.asList(
            "add-environment", "diff", "format", "help", "init", "lint", "pull", "push", "version"));
    static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] raw) {
        List<String> args = new ArrayList<>(Arrays.asList(raw));
        boolean debug = false;
        try {
            Parsed parsed = parseGlobal(args);
            args = parsed.args;
            debug = parsed.debug;
            if (parsed.version) {
                System.out.println(VERSION);
                finish(0, debug);
            }
            if (parsed.helpCommand != null) {
                printHelp(parsed.helpCommand);
                finish(0, debug);
            }
            if (args.isEmpty()) {
                printMainHelp();
                finish(0, debug);
            }
            String cmd = args.remove(0);
            if ("help".equals(cmd)) {
                if (args.isEmpty()) printMainHelp();
                else if ("version".equals(args.get(0))) System.out.println(VERSION);
                else if (COMMANDS.contains(args.get(0))) printHelp(args.get(0));
                else die("Unknown command \"" + args.get(0) + "\"", 2, debug);
                finish(0, debug);
            }
            if (!COMMANDS.contains(cmd)) die("Unknown command \"" + cmd + "\"", 78, debug);
            if (containsHelp(args)) {
                printHelp(cmd);
                finish(0, debug);
            }
            validateOptions(args, debug);
            switch (cmd) {
                case "version":
                    requireMax(cmd, args, 0, debug);
                    System.out.println(VERSION);
                    finish(0, debug);
                    break;
                case "add-environment":
                    finish(addEnvironment(args, debug), debug);
                    break;
                case "init":
                    finish(init(args, debug), debug);
                    break;
                case "lint":
                case "format":
                    finish(lintOrFormat(cmd, args), debug);
                    break;
                case "pull":
                    finish(pull(args), debug);
                    break;
                case "diff":
                case "push":
                    requireMax(cmd, positional(args), 1, debug);
                    finish(0, debug);
                    break;
                default:
                    finish(0, debug);
            }
        } catch (Exit e) {
            System.exit(e.code);
        } catch (Exception e) {
            log("ERROR", e.getMessage() == null ? e.toString() : e.getMessage());
            if (debug) log("DEBUG", "Exit code 1");
            System.exit(1);
        }
    }

    static Parsed parseGlobal(List<String> in) {
        Parsed p = new Parsed();
        for (int i = 0; i < in.size(); i++) {
            String a = in.get(i);
            if ("--debug".equals(a)) { p.debug = true; continue; }
            if ("--version".equals(a)) { p.version = true; continue; }
            if (a.equals("-?") || a.equals("--help")) {
                if (i + 1 < in.size() && COMMANDS.contains(in.get(i + 1))) p.helpCommand = in.get(++i);
                else p.helpCommand = "";
                continue;
            }
            if (a.startsWith("--help=")) { p.helpCommand = a.substring(7); continue; }
            if (isGlobalValueOption(a)) {
                if (!a.contains("=") && i + 1 < in.size()) i++;
                continue;
            }
            if (isGlobalFlag(a)) continue;
            if (a.startsWith("--") && in.stream().noneMatch(COMMANDS::contains)) {
                dieNow("CLI: Unknown option \"" + a.substring(2) + "\"", 78);
            }
            p.args.add(a);
        }
        if (p.helpCommand != null && p.helpCommand.isEmpty()) p.helpCommand = null;
        return p;
    }

    static boolean isGlobalValueOption(String a) {
        String n = a.contains("=") ? a.substring(0, a.indexOf('=')) : a;
        return Arrays.asList("-o", "--connect-options", "-H", "--host-wrapper", "--ignore-func",
                "--ignore-proc", "--ignore-schema", "--ignore-table", "-p", "--password",
                "--ssl-mode", "-u", "--user").contains(n);
    }

    static boolean isGlobalFlag(String a) {
        return Arrays.asList("--my-cnf", "--skip-my-cnf").contains(a);
    }

    static boolean containsHelp(List<String> args) {
        for (String a : args) if (a.equals("-?") || a.equals("--help") || a.startsWith("--help=")) return true;
        return false;
    }

    static List<String> positional(List<String> args) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (a.startsWith("-")) {
                if (takesValue(a) && !a.contains("=") && i + 1 < args.size()) i++;
            } else out.add(a);
        }
        return out;
    }

    static boolean takesValue(String a) {
        String n = a.contains("=") ? a.substring(0, a.indexOf('=')) : a;
        return !Arrays.asList("--debug", "--version", "--allow-unsafe", "--dry-run", "--foreign-key-checks",
                "--brief", "-q", "--first-only", "-1", "--skip-write", "--write", "--skip-format", "--format",
                "--skip-lint", "--lint", "--include-auto-inc", "--strip-partitioning", "--update-partitioning").contains(n);
    }

    static void validateOptions(List<String> args, boolean debug) {
        Set<String> known = new HashSet<>(Arrays.asList(
                "-d", "--dir", "-h", "--host", "-P", "--port", "-S", "--socket", "--schema",
                "--include-auto-inc", "--strip-partitioning", "--update-partitioning",
                "--format", "--skip-format", "--new-schemas", "--skip-new-schemas",
                "--docker-cleanup", "-t", "--temp-schema", "--temp-schema-binlog",
                "--temp-schema-mode", "--temp-schema-threads", "-w", "--workspace", "--flavor",
                "-x", "--alter-wrapper", "--alter-wrapper-min-size", "-X", "--ddl-wrapper",
                "--alter-algorithm", "--alter-lock", "--alter-validate-virtual", "--compare-metadata",
                "--exact-match", "--lax-column-order", "--lax-comments", "--partitioning",
                "--allow-auto-inc", "--allow-charset", "--allow-compression", "--allow-definer",
                "--allow-engine", "--allow-pk-type", "--lint", "--skip-lint", "--lint-auto-inc",
                "--lint-charset", "--lint-compression", "--lint-definer", "--lint-display-width",
                "--lint-dupe-index", "--lint-engine", "--lint-fk-parent", "--lint-has-enum",
                "--lint-has-fk", "--lint-has-float", "--lint-has-routine", "--lint-has-time",
                "--lint-name-case", "--lint-pk", "--lint-pk-type", "--lint-reserved-word",
                "--lint-zero-date", "--allow-unsafe", "--safe-below-size", "--verify", "--skip-verify",
                "-q", "--brief", "-c", "--concurrent-servers", "-1", "--first-only",
                "--dry-run", "--foreign-key-checks", "--write", "--skip-write"));
        for (String a : args) {
            if (!a.startsWith("-")) continue;
            String n = a.contains("=") ? a.substring(0, a.indexOf('=')) : a;
            if (!known.contains(n) && !isGlobalValueOption(n) && !isGlobalFlag(n)) {
                String clean = n.replaceFirst("^-+", "");
                die("CLI: Unknown option \"" + clean + "\"", 78, debug);
            }
        }
    }

    static int addEnvironment(List<String> args, boolean debug) throws IOException {
        Map<String, String> opts = opts(args);
        List<String> pos = positional(args);
        if (pos.isEmpty()) die("Too few positional args supplied on command line; command add-environment requires at least 1 args", 78, debug);
        requireMax("add-environment", pos, 1, debug);
        String env = pos.get(0);
        String host = opts.get("host");
        if (host == null) die("`skeema add-environment` requires --host to be supplied on command-line", 78, debug);
        Path dir = Paths.get(opts.getOrDefault("dir", ".")).toAbsolutePath().normalize();
        Path cfg = dir.resolve(".skeema");
        if (!Files.exists(cfg)) die("No .skeema file found in " + dir, 78, debug);
        String content = Files.readString(cfg);
        if (Pattern.compile("(?m)^\\[" + Pattern.quote(env) + "\\]\\s*$").matcher(content).find())
            die("Environment [" + env + "] already exists in " + cfg, 78, debug);
        StringBuilder add = new StringBuilder();
        if (!content.endsWith("\n")) add.append("\n");
        add.append("\n[").append(env).append("]\n");
        add.append("host=").append(host).append("\n");
        if ("localhost".equals(host) && opts.containsKey("socket")) add.append("socket=").append(opts.get("socket")).append("\n");
        else add.append("port=").append(opts.getOrDefault("port", "3306")).append("\n");
        Files.writeString(cfg, content + add, StandardCharsets.UTF_8);
        log("WARN", "Unable to automatically determine database server's vendor/version. To set manually, use the \"flavor\" option in " + cfg);
        log("INFO", "Added environment [" + env + "] to " + cfg);
        return 0;
    }

    static int init(List<String> args, boolean debug) throws IOException {
        Map<String, String> opts = opts(args);
        List<String> pos = positional(args);
        requireMax("init", pos, 1, debug);
        String host = opts.get("host");
        if (host == null) die("Option --host must be supplied on the command-line", 78, debug);
        String env = pos.isEmpty() ? "production" : pos.get(0);
        Path dir = Paths.get(opts.getOrDefault("dir", host)).toAbsolutePath().normalize();
        Files.createDirectories(dir);
        Path cfg = dir.resolve(".skeema");
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(env).append("]\n");
        sb.append("host=").append(host).append("\n");
        if ("localhost".equals(host) && opts.containsKey("socket")) sb.append("socket=").append(opts.get("socket")).append("\n");
        else sb.append("port=").append(opts.getOrDefault("port", "3306")).append("\n");
        Files.writeString(cfg, sb.toString(), StandardCharsets.UTF_8);
        log("WARN", "Unable to connect to " + host + ":3306: dial tcp: connection refused");
        return 1;
    }

    static int lintOrFormat(String cmd, List<String> args) throws IOException {
        boolean check = cmd.equals("format") && args.stream().anyMatch(a -> a.equals("--skip-write"));
        String verb = cmd.equals("lint") ? "Linting" : (check ? "Checking format of" : "Reformatting");
        Path root = Paths.get("").toAbsolutePath().normalize();
        log("INFO", verb + " " + root);
        List<Path> sqlDirs = sqlDirs(root);
        boolean fatal = false;
        for (Path d : sqlDirs) {
            if (!d.equals(root)) log("INFO", verb + " " + d);
            Config c = findConfig(d);
            if (!c.hasHost && !c.hasFlavor) {
                if (cmd.equals("lint"))
                    log("ERROR", "Skipping directory " + root.relativize(d) + " due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"");
                else
                    log("ERROR", "Skipping " + d + ": This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment \"production\"");
                fatal = true;
            } else if (usesDocker(args, c)) {
                log("ERROR", cmd.equals("lint") ? "Skipping directory " + root.relativize(d) + " due to error: unable to find `docker` command-line client among directories in PATH" :
                        "Skipping " + d + ": unable to find `docker` command-line client among directories in PATH");
                if (cmd.equals("lint")) {
                    log("ERROR", "Skeema v1.11+ no longer includes a built-in Docker client. If you are using workspace=docker while also running `skeema` itself in a container, be sure to put a Linux `docker` client CLI binary in the container as well.");
                    log("ERROR", "For more information, see https://github.com/skeema/skeema/issues/186#issuecomment-1648483625");
                }
                fatal = true;
            }
        }
        if (fatal && cmd.equals("lint")) log("ERROR", "Skipped 1 operation due to fatal errors");
        if (!fatal && cmd.equals("lint")) runSimpleLint(root);
        return fatal ? (usesDocker(args, new Config()) ? 2 : 78) : 0;
    }

    static int pull(List<String> args) throws IOException {
        Path root = Paths.get("").toAbsolutePath().normalize();
        Config c = findConfig(root);
        if (c.hasHost) {
            String target = c.host.equals("localhost") ? "localhost:/tmp/mysql.sock" : c.host + ":3306";
            log("WARN", "Skipping " + root + ": Unable to connect to " + target + " for " + root + ": dial unix /tmp/mysql.sock: connect: no such file or directory");
            return 1;
        }
        return 0;
    }

    static void runSimpleLint(Path root) throws IOException {
        for (Path f : sqlFiles(root)) {
            String s = Files.readString(f).toLowerCase(Locale.ROOT);
            if (s.contains("create table") && !s.contains("primary key")) {
                log("WARN", root.relativize(f) + ": Table lacks a primary key");
            }
        }
    }

    static List<Path> sqlDirs(Path root) throws IOException {
        Set<Path> dirs = new TreeSet<>();
        for (Path f : sqlFiles(root)) dirs.add(f.getParent());
        return new ArrayList<>(dirs);
    }

    static List<Path> sqlFiles(Path root) throws IOException {
        if (!Files.exists(root)) return Collections.emptyList();
        List<Path> files = new ArrayList<>();
        try (var st = Files.walk(root)) {
            st.filter(p -> Files.isRegularFile(p) && p.getFileName().toString().endsWith(".sql"))
                    .forEach(files::add);
        }
        files.sort(Comparator.naturalOrder());
        return files;
    }

    static Config findConfig(Path dir) throws IOException {
        Path p = dir;
        while (p != null) {
            Path cfg = p.resolve(".skeema");
            if (Files.exists(cfg)) {
                String s = Files.readString(cfg);
                Config c = new Config();
                c.hasHost = Pattern.compile("(?m)^\\s*host\\s*=").matcher(s).find();
                c.hasFlavor = Pattern.compile("(?m)^\\s*flavor\\s*=").matcher(s).find();
                c.hasDocker = Pattern.compile("(?m)^\\s*workspace\\s*=\\s*docker\\s*$").matcher(s).find();
                var m = Pattern.compile("(?m)^\\s*host\\s*=\\s*([^\\s#]+)").matcher(s);
                c.host = m.find() ? m.group(1) : "localhost";
                return c;
            }
            p = p.getParent();
        }
        return new Config();
    }

    static boolean usesDocker(List<String> args, Config c) {
        for (String a : args) if (a.equals("--workspace=docker")) return true;
        return c.hasDocker;
    }

    static Map<String, String> opts(List<String> args) {
        Map<String, String> m = new HashMap<>();
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (!a.startsWith("-")) continue;
            String name = a, val = null;
            int eq = a.indexOf('=');
            if (eq > 0) { name = a.substring(0, eq); val = a.substring(eq + 1); }
            else if (takesValue(a) && i + 1 < args.size()) val = args.get(++i);
            name = name.replaceFirst("^-+", "");
            if (name.length() == 1) {
                if (name.equals("d")) name = "dir";
                else if (name.equals("h")) name = "host";
                else if (name.equals("P")) name = "port";
                else if (name.equals("S")) name = "socket";
            }
            if (val != null) m.put(name, val);
        }
        return m;
    }

    static void requireMax(String cmd, List<String> pos, int max, boolean debug) {
        if (pos.size() > max) die("Extra command-line arg \"" + pos.get(max) + "\" supplied; command " + cmd + " takes a max of " + max + " args", 78, debug);
    }

    static void log(String level, String msg) {
        System.err.println(LocalDateTime.now().format(TS) + " [" + level + "] " + (level.length() == 4 ? " " : "") + msg);
    }

    static void die(String msg, int code, boolean debug) {
        log("ERROR", msg);
        throw new Exit(code);
    }

    static void dieNow(String msg, int code) {
        log("ERROR", msg);
        throw new Exit(code);
    }

    static void finish(int code, boolean debug) {
        if (debug) log("DEBUG", "Exit code " + code + (code == 0 ? " (SUCCESS)" : ""));
        throw new Exit(code);
    }

    static void printHelp(String cmd) {
        if ("".equals(cmd) || cmd == null) { printMainHelp(); return; }
        switch (cmd) {
            case "init": System.out.print(INIT_HELP); break;
            case "pull": System.out.print(PULL_HELP); break;
            case "diff": System.out.print(DIFF_HELP); break;
            case "push": System.out.print(PUSH_HELP); break;
            case "lint": System.out.print(LINT_HELP); break;
            case "format": System.out.print(FORMAT_HELP); break;
            case "add-environment": System.out.print(ADD_HELP); break;
            case "version": System.out.print(VERSION_HELP); break;
            default: dieNow("Unknown command \"" + cmd + "\"", 2);
        }
    }

    static void printMainHelp() { System.out.print(MAIN_HELP); }

    static class Parsed { List<String> args = new ArrayList<>(); boolean debug, version; String helpCommand; }
    static class Config { boolean hasHost, hasFlavor, hasDocker; String host = "localhost"; }
    static class Exit extends RuntimeException { final int code; Exit(int c) { code = c; } }

    static final String GLOBAL = "\nGlobal Options:\n" +
            "  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server\n" +
            "      --debug                  Enable debug logging\n" +
            "  -?, --help[=value]           Display usage information for the specified command\n" +
            "  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars\n" +
            "      --ignore-func value      Ignore functions that match regex\n" +
            "      --ignore-proc value      Ignore stored procedures that match regex\n" +
            "      --ignore-schema value    Ignore schemas that match regex\n" +
            "      --ignore-table value     Ignore tables that match regex\n" +
            "      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)\n" +
            "  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default \"$MYSQL_PWD\")\n" +
            "      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: \"disabled\", \"preferred\", \"required\")\n" +
            "  -u, --user value             Username to connect to database host (default \"root\")\n" +
            "      --version                Display program version\n";

    static final String MAIN_HELP = "\nUsage:  skeema [<options>] <command>\n\n" +
            "Skeema is a declarative schema management system for MySQL and MariaDB. It\n" +
            "allows you to export a database schema to the filesystem, and apply online\n" +
            "schema changes by modifying CREATE statements in .sql files.\n\n" +
            "Commands:\n" +
            "      add-environment  Add a new named environment to an existing host directory\n" +
            "      diff             Compare a DB server's schemas to the filesystem\n" +
            "      format           Normalize format of filesystem representation of database objects\n" +
            "      help             Display usage information\n" +
            "      init             Save a DB server's schemas to the filesystem\n" +
            "      lint             Check for problems in filesystem representation of database objects\n" +
            "      pull             Update the filesystem representation of schemas\n" +
            "      push             Alter objects on DBs to reflect the filesystem representation\n" +
            "      version          Display program version\n" +
            GLOBAL + "\nComplete documentation for this command suite is available online:\nhttps://www.skeema.io/docs/commands\n\n";

    static final String VERSION_HELP = "\nUsage:  skeema version [<options>]\n\nDisplay program version\n" + GLOBAL +
            "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/version\n\n";
    static final String INIT_HELP = "\nUsage:  skeema init [<options>] [<environment>]\n\nCreates a filesystem representation of the schemas on a database server.\n\nInit Options:\n" +
            "  -d, --dir value              Subdir name to use for this host's schemas (default \"<hostname>\")\n" +
            "  -h, --host value             Database hostname or IP address\n" +
            "      --include-auto-inc       Include starting auto-inc values in table files\n" +
            "  -P, --port value             Port to use for database host (default \"3306\")\n" +
            "      --schema value           Only import the one specified schema; skip creation of subdirs for each schema\n" +
            "  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default \"/tmp/mysql.sock\")\n" +
            "      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem\n" + GLOBAL +
            "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/init\n\n";
    static final String WORKSPACE = "\nWorkspace Options:\n      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: \"none\", \"stop\", \"destroy\") (default \"none\")\n  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default \"_skeema_tmp\")\n      --temp-schema-binlog value   Controls whether temp schema DDL operations are replicated (valid values: \"on\", \"off\", \"auto\") (default \"auto\")\n      --temp-schema-mode value     Tunes workspace load with workspace=temp-schema (default \"regular\")\n      --temp-schema-threads value  Deprecated manner of controlling workspace load with workspace=temp-schema (default \"5\")\n  -w, --workspace value            Specifies where to run intermediate operations (valid values: \"temp-schema\", \"docker\") (default \"temp-schema\")\n";
    static final String PULL_HELP = "\nUsage:  skeema pull [<options>] [<environment>]\n\nUpdates the existing filesystem representation of the schemas on a DB server.\n\nPull Options:\n" +
            "      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n" +
            "      --include-auto-inc           Include starting auto-inc values in new table files, and update in existing files\n" +
            "      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)\n" +
            "      --strip-partitioning         Omit PARTITION BY clause when writing partitioned tables to filesystem\n" + WORKSPACE + GLOBAL +
            "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/pull\n\n";
    static final String DIFF_HELP = "\nUsage:  skeema diff [<options>] [<environment>]\n\nCompares the schemas on database server(s) to the corresponding filesystem representation of them.\n\nExternal Tool Options:\n  -x, --alter-wrapper value           Output ALTER TABLEs as shell commands rather than just raw DDL; see manual for template vars\n  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)\n\nSQL Generation Options:\n      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs\n      --exact-match                   Follow *.sql table definitions exactly\n\nLinter Rule Options:\n      --[skip-]lint                   Check modified objects for problems before proceeding (enabled by default; disable with --skip-lint)\n      --lint-pk value                 Flag tables that lack a primary key (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n\nSafety Options:\n      --allow-unsafe                  Permit generating ALTER or DROP operations that are potentially destructive\n      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)\n\nSharding Options:\n  -q, --brief                         Don't output DDL to STDOUT; instead output list of database servers with at least one difference\n" + WORKSPACE + GLOBAL + "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/diff\n\n";
    static final String PUSH_HELP = DIFF_HELP.replace("skeema diff", "skeema push").replace("Compare", "Alter").replace("commands/diff", "commands/push") +
            "";
    static final String LINT_HELP = "\nUsage:  skeema lint [<options>] [<environment>]\n\nChecks for problems in filesystem representation of database objects.\n\nFormat Options:\n      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n\nLinter Rule Options:\n      --lint-pk value              Flag tables that lack a primary key (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n      --lint-engine value          Only allow storage engines listed in --allow-engine (valid values: \"ignore\", \"warning\", \"error\") (default \"warning\")\n" + WORKSPACE + GLOBAL + "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/lint\n\n";
    static final String FORMAT_HELP = "\nUsage:  skeema format [<options>] [<environment>]\n\nReformats the filesystem representation of database objects to match the canonical format shown in SHOW CREATE.\n\nFormat Options:\n      --strip-partitioning         Remove PARTITION BY clauses from *.sql files\n      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)\n" + WORKSPACE + GLOBAL + "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/format\n\n";
    static final String ADD_HELP = "\nUsage:  skeema add-environment [<options>] <environment>\n\nModifies the .skeema file in an existing host directory to add a new named environment.\n\nAdd-Environment Options:\n  -d, --dir value              Base dir for this host's schemas (default \".\")\n  -h, --host value             Database hostname or IP address\n  -P, --port value             Port to use for database host (default \"3306\")\n  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default \"/tmp/mysql.sock\")\n" + GLOBAL + "\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/add-environment\n\n";
}
