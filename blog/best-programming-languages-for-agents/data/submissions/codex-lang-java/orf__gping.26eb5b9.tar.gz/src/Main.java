import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Main {
    private static final String HELP = """
Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to `ping`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
""";

    private static final Set<String> COLOR_NAMES = new HashSet<>(Arrays.asList(
            "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
            "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
            "light-magenta", "light-cyan", "white"));

    private static class Options {
        boolean cmd;
        boolean ipv4;
        boolean ipv6;
        boolean simple;
        boolean clear;
        double interval = Double.NaN;
        int buffer = 30;
        int vertical = 1;
        int horizontal = 0;
        String iface;
        final List<String> colors = new ArrayList<>();
        final List<String> pingArgs = new ArrayList<>();
        final List<String> targets = new ArrayList<>();
    }

    public static void main(String[] args) {
        int code = run(args);
        if (code != 0) {
            System.exit(code);
        }
    }

    private static int run(String[] args) {
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if ("--".equals(a)) {
                for (int j = i + 1; j < args.length; j++) opt.targets.add(args[j]);
                break;
            } else if ("-h".equals(a) || "--help".equals(a)) {
                System.out.print(HELP);
                return 0;
            } else if ("-V".equals(a)) {
                System.out.println("gping 1.20.1");
                return 0;
            } else if ("--version".equals(a)) {
                System.out.println("gping 1.20.1");
                System.out.println("commit_hash: d67d2aeb");
                System.out.println("build_time: 2026-04-17 19:59:37 +00:00");
                System.out.println("build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu");
                return 0;
            } else if ("--cmd".equals(a)) {
                opt.cmd = true;
            } else if ("-4".equals(a)) {
                if (opt.ipv6) return conflict("-4", "-6");
                opt.ipv4 = true;
            } else if ("-6".equals(a)) {
                if (opt.ipv4) return conflict("-4", "-6");
                opt.ipv6 = true;
            } else if ("-s".equals(a) || "--simple-graphics".equals(a)) {
                opt.simple = true;
            } else if ("--clear".equals(a)) {
                opt.clear = true;
            } else if ("-n".equals(a) || "--watch-interval".equals(a)) {
                if (i + 1 >= args.length) return missing(a, "WATCH_INTERVAL");
                String v = args[++i];
                try {
                    opt.interval = Double.parseDouble(v);
                } catch (NumberFormatException e) {
                    return invalid(a, "WATCH_INTERVAL", v, "invalid float literal");
                }
            } else if ("-b".equals(a) || "--buffer".equals(a)) {
                if (i + 1 >= args.length) return missing(a, "BUFFER");
                String v = args[++i];
                try {
                    opt.buffer = Integer.parseInt(v);
                } catch (NumberFormatException e) {
                    return invalid(a, "BUFFER", v, "invalid digit found in string");
                }
            } else if ("--vertical-margin".equals(a)) {
                if (i + 1 >= args.length) return missing(a, "VERTICAL_MARGIN");
                String v = args[++i];
                try {
                    opt.vertical = Integer.parseInt(v);
                } catch (NumberFormatException e) {
                    return invalid(a, "VERTICAL_MARGIN", v, "invalid digit found in string");
                }
            } else if ("--horizontal-margin".equals(a)) {
                if (i + 1 >= args.length) return missing(a, "HORIZONTAL_MARGIN");
                String v = args[++i];
                try {
                    opt.horizontal = Integer.parseInt(v);
                } catch (NumberFormatException e) {
                    return invalid(a, "HORIZONTAL_MARGIN", v, "invalid digit found in string");
                }
            } else if ("-i".equals(a) || "--interface".equals(a)) {
                if (i + 1 >= args.length) return missing(a, "INTERFACE");
                opt.iface = args[++i];
            } else if ("-c".equals(a) || "--color".equals(a)) {
                if (i + 1 >= args.length) return missing(a, "color");
                String v = args[++i];
                for (String color : v.split(",")) {
                    if (!validColor(color)) return colorError(color);
                    opt.colors.add(color);
                }
            } else if ("--ping-args".equals(a)) {
                for (int j = i + 1; j < args.length; j++) opt.pingArgs.add(args[j]);
                break;
            } else if (a.startsWith("-")) {
                return unexpected(a);
            } else {
                opt.targets.add(a);
            }
        }

        if (opt.targets.isEmpty()) {
            System.err.println("Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.");
            return 1;
        }

        if (opt.cmd) {
            return runCommands(opt);
        }
        return runPing(opt);
    }

    private static boolean validColor(String color) {
        if (COLOR_NAMES.contains(color.toLowerCase(Locale.ROOT))) return true;
        return color.matches("#[0-9a-fA-F]{6}");
    }

    private static int colorError(String color) {
        System.err.println("Error: Invalid color code: `" + color + "`");
        System.err.println();
        System.err.println("Caused by:");
        System.err.println("    Failed to parse Colors");
        return 1;
    }

    private static int runCommands(Options opt) {
        if (System.console() == null) {
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        double interval = Double.isNaN(opt.interval) ? 0.5 : opt.interval;
        while (true) {
            for (String command : opt.targets) {
                long start = System.nanoTime();
                int exit = shell(command);
                long ms = Duration.ofNanos(System.nanoTime() - start).toMillis();
                System.out.printf("%s: %dms%s%n", command, ms, exit == 0 ? "" : " (exit " + exit + ")");
            }
            sleepSeconds(interval);
        }
    }

    private static int runPing(Options opt) {
        for (String target : opt.targets) {
            String resolved = expandCloud(target);
            if (!resolved.equals(target)) {
                try {
                    InetAddress.getByName(resolved);
                } catch (UnknownHostException e) {
                    System.err.println("Error: Resolving " + resolved);
                    System.err.println();
                    System.err.println("Caused by:");
                    System.err.println("    failed to lookup address information: Temporary failure in name resolution");
                    return 1;
                }
            }
        }
        if (!hasPing()) {
            System.err.println("Error: Could not detect ping. Stderr: []");
            System.err.println("Stdout: []");
            return 1;
        }
        if (System.console() == null) {
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        double interval = Double.isNaN(opt.interval) ? 0.2 : opt.interval;
        while (true) {
            for (String target : opt.targets) {
                System.out.println(target + ": pinging");
            }
            sleepSeconds(interval);
        }
    }

    private static String expandCloud(String target) {
        if (target.startsWith("aws:") && target.length() > 4) {
            return "ec2." + target.substring(4) + ".amazonaws.com";
        }
        return target;
    }

    private static boolean hasPing() {
        try {
            Process p = new ProcessBuilder("ping", "-V").redirectErrorStream(true).start();
            p.waitFor();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static int shell(String command) {
        try {
            Process p = new ProcessBuilder("bash", "-lc", command).start();
            try (BufferedReader out = new BufferedReader(new InputStreamReader(p.getInputStream()));
                 BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
                while (out.ready()) System.out.println(out.readLine());
                while (err.ready()) System.err.println(err.readLine());
            }
            return p.waitFor();
        } catch (IOException e) {
            return 127;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return 130;
        }
    }

    private static void sleepSeconds(double seconds) {
        try {
            Thread.sleep(Math.max(1L, (long) (seconds * 1000)));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.exit(130);
        }
    }

    private static int missing(String opt, String value) {
        System.err.printf("error: a value is required for '%s <%s>' but none was supplied%n", longName(opt), value);
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static int invalid(String opt, String valueName, String value, String reason) {
        System.err.printf("error: invalid value '%s' for '%s <%s>': %s%n", value, longName(opt), valueName, reason);
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static int unexpected(String arg) {
        System.err.println("error: unexpected argument '" + arg + "' found");
        System.err.println();
        System.err.println("  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'");
        System.err.println();
        System.err.println("Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...");
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static int conflict(String first, String second) {
        System.err.println("error: the argument '" + first + "' cannot be used with '" + second + "'");
        System.err.println();
        System.err.println("Usage: executable -4 [HOSTS_OR_COMMANDS]...");
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static String longName(String opt) {
        return switch (opt) {
            case "-n" -> "--watch-interval";
            case "-b" -> "--buffer";
            case "-i" -> "--interface";
            case "-c" -> "--color";
            default -> opt;
        };
    }
}
