import org.yaml.snakeyaml.Yaml;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Yj {
    static final String HELP = "Usage: ./executable [-][ytjcrneikhv]\n\n" +
            "Convert between YAML, TOML, JSON, and HCL.\n" +
            "Preserves map order.\n\n" +
            "-x[x]  Convert using stdin. Valid options:\n" +
            "          -yj, -y = YAML to JSON (default)\n" +
            "          -yy     = YAML to YAML\n" +
            "          -yt     = YAML to TOML\n" +
            "          -yc     = YAML to HCL\n" +
            "          -tj, -t = TOML to JSON\n" +
            "          -ty     = TOML to YAML\n" +
            "          -tt     = TOML to TOML\n" +
            "          -tc     = TOML to HCL\n" +
            "          -jj     = JSON to JSON\n" +
            "          -jy, -r = JSON to YAML\n" +
            "          -jt     = JSON to TOML\n" +
            "          -jc     = JSON to HCL\n" +
            "          -cy     = HCL to YAML\n" +
            "          -ct     = HCL to TOML\n" +
            "          -cj, -c = HCL to JSON\n" +
            "          -cc     = HCL to HCL\n" +
            "-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)\n" +
            "-e     Escape HTML (JSON out only)\n" +
            "-i     Indent output (JSON or TOML out only)\n" +
            "-k     Attempt to parse keys as objects or numeric types (YAML out only)\n" +
            "-h     Show this help message\n" +
            "-v     Show version";

    public static void main(String[] args) throws Exception {
        String flags = "";
        for (String a : args) {
            if (a.startsWith("-")) flags += a.substring(1);
            else flags += a;
        }
        if (flags.contains("v") && flags.length() == 1) {
            System.out.println("v0.0.0");
            return;
        }
        if (flags.contains("h") && flags.length() == 1) {
            System.out.println(HELP);
            return;
        }
        String allowed = "ytjcrneik";
        StringBuilder bad = new StringBuilder();
        for (char c : flags.toCharArray()) {
            if (allowed.indexOf(c) < 0) {
                if (bad.length() > 0) bad.append(' ');
                bad.append(c);
            }
        }
        if (bad.length() > 0 || flags.contains("h") || flags.contains("v")) {
            System.out.println(HELP + "\n\nError: invalid flags specified: " + (bad.length() == 0 ? flags : bad));
            System.exit(1);
        }

        boolean indent = flags.indexOf('i') >= 0;
        boolean html = flags.indexOf('e') >= 0;
        String modes = flags.replaceAll("[rneik]", "");
        char in = 'y', out = 'j';
        if (modes.equals("r")) { in = 'j'; out = 'y'; }
        else if (modes.equals("c")) { in = 'c'; out = 'j'; }
        else if (modes.equals("t")) { in = 't'; out = 'j'; }
        else if (modes.length() == 1) { in = modes.charAt(0); out = modes.charAt(0) == 'y' ? 'j' : modes.charAt(0); }
        else if (modes.length() >= 2) { in = modes.charAt(0); out = modes.charAt(1); }

        String input = readAll();
        Object value;
        try {
            if (in == 'j') value = new JsonParser(input).parse();
            else if (in == 't') value = parseToml(input);
            else if (in == 'c') value = parseHcl(input);
            else value = normalize(new Yaml().load(input));
            if (value == null) value = new LinkedHashMap<String, Object>();
            String result;
            if (out == 'j') result = toJson(value, indent, html);
            else if (out == 'y') result = toYaml(value);
            else if (out == 't') result = toToml(value, indent);
            else result = toHcl(value, 0);
            System.out.print(result);
            if (!result.endsWith("\n") && out != 'h') System.out.println();
        } catch (Exception ex) {
            System.err.println("Error: " + ex.getMessage());
            System.exit(1);
        }
    }

    static String readAll() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        return sb.toString();
    }

    static Object normalize(Object o) {
        if (o instanceof Map<?, ?> m) {
            LinkedHashMap<String, Object> r = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : m.entrySet()) r.put(String.valueOf(e.getKey()), normalize(e.getValue()));
            return r;
        }
        if (o instanceof List<?> l) {
            ArrayList<Object> r = new ArrayList<>();
            for (Object x : l) r.add(normalize(x));
            return r;
        }
        return o;
    }

    static Object parseToml(String s) {
        LinkedHashMap<String, Object> root = new LinkedHashMap<>();
        Map<String, Object> cur = root;
        for (String raw : s.split("\\R")) {
            String line = stripComment(raw).trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) {
                String name = line.substring(1, line.length() - 1).trim();
                cur = ensureMap(root, name);
            } else {
                int eq = findTop(line, '=');
                if (eq >= 0) putPath(cur, unquote(line.substring(0, eq).trim()), parseValue(line.substring(eq + 1).trim()));
            }
        }
        return root;
    }

    static Object parseHcl(String s) {
        return new HclParser(s).parseObject(false);
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> ensureMap(Map<String, Object> root, String path) {
        Map<String, Object> cur = root;
        for (String part : path.split("\\.")) {
            part = unquote(part.trim());
            Object next = cur.get(part);
            if (!(next instanceof Map)) {
                next = new LinkedHashMap<String, Object>();
                cur.put(part, next);
            }
            cur = (Map<String, Object>) next;
        }
        return cur;
    }

    static void putPath(Map<String, Object> map, String key, Object value) {
        String[] parts = key.split("\\.");
        Map<String, Object> cur = map;
        for (int i = 0; i < parts.length - 1; i++) cur = ensureMap(cur, parts[i]);
        cur.put(unquote(parts[parts.length - 1].trim()), value);
    }

    static String stripComment(String s) {
        boolean q = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' && (i == 0 || s.charAt(i - 1) != '\\')) q = !q;
            if (!q && c == '#') return s.substring(0, i);
        }
        return s;
    }

    static Object parseValue(String v) {
        v = v.trim();
        if (v.isEmpty()) return null;
        if (v.startsWith("\"") || v.startsWith("'")) return parseString(v);
        if (v.startsWith("[")) return parseArray(v);
        if (v.startsWith("{")) return new HclParser(v).parseObject(true);
        if (v.equals("true")) return Boolean.TRUE;
        if (v.equals("false")) return Boolean.FALSE;
        if (v.equals("null")) return null;
        try {
            String n = v.replace("_", "");
            if (n.matches("[-+]?\\d+")) return Long.parseLong(n);
            if (n.matches("[-+]?(\\d+\\.\\d*|\\d*\\.\\d+|\\d+)[eE][-+]?\\d+|[-+]?\\d*\\.\\d+")) return new BigDecimal(n);
        } catch (Exception ignored) {}
        return v;
    }

    static List<Object> parseArray(String v) {
        ArrayList<Object> list = new ArrayList<>();
        String inner = v.substring(1, v.lastIndexOf(']'));
        for (String p : splitTop(inner, ',')) if (!p.trim().isEmpty()) list.add(parseValue(p));
        return list;
    }

    static String parseString(String v) {
        char q = v.charAt(0);
        int end = v.length() - 1;
        if (v.charAt(end) == q) v = v.substring(1, end); else v = v.substring(1);
        if (q == '\'') return v;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if (c == '\\' && i + 1 < v.length()) {
                char n = v.charAt(++i);
                if (n == 'n') sb.append('\n');
                else if (n == 't') sb.append('\t');
                else if (n == 'r') sb.append('\r');
                else sb.append(n);
            } else sb.append(c);
        }
        return sb.toString();
    }

    static int findTop(String s, char target) {
        int d = 0; boolean q = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' && (i == 0 || s.charAt(i - 1) != '\\')) q = !q;
            else if (!q && (c == '[' || c == '{')) d++;
            else if (!q && (c == ']' || c == '}')) d--;
            else if (!q && d == 0 && c == target) return i;
        }
        return -1;
    }

    static List<String> splitTop(String s, char sep) {
        ArrayList<String> out = new ArrayList<>();
        int start = 0, d = 0; boolean q = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"' && (i == 0 || s.charAt(i - 1) != '\\')) q = !q;
            else if (!q && (c == '[' || c == '{')) d++;
            else if (!q && (c == ']' || c == '}')) d--;
            else if (!q && d == 0 && c == sep) {
                out.add(s.substring(start, i));
                start = i + 1;
            }
        }
        out.add(s.substring(start));
        return out;
    }

    static String unquote(String s) {
        s = s.trim();
        if ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'"))) return parseString(s);
        return s;
    }

    static String toJson(Object o, boolean pretty, boolean html) {
        StringBuilder sb = new StringBuilder();
        writeJson(sb, o, pretty, html, 0);
        return sb.toString();
    }

    static void writeJson(StringBuilder sb, Object o, boolean pretty, boolean html, int level) {
        if (o == null) sb.append("null");
        else if (o instanceof Map<?, ?> m) {
            sb.append('{');
            int i = 0;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (i++ > 0) sb.append(',');
                if (pretty) sb.append('\n').append("  ".repeat(level + 1));
                writeJsonString(sb, String.valueOf(e.getKey()), html);
                sb.append(pretty ? ": " : ":");
                writeJson(sb, e.getValue(), pretty, html, level + 1);
            }
            if (pretty && !m.isEmpty()) sb.append('\n').append("  ".repeat(level));
            sb.append('}');
        } else if (o instanceof List<?> l) {
            sb.append('[');
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(',');
                if (pretty) sb.append('\n').append("  ".repeat(level + 1));
                writeJson(sb, l.get(i), pretty, html, level + 1);
            }
            if (pretty && !l.isEmpty()) sb.append('\n').append("  ".repeat(level));
            sb.append(']');
        } else if (o instanceof Number || o instanceof Boolean) sb.append(num(o));
        else writeJsonString(sb, String.valueOf(o), html);
    }

    static void writeJsonString(StringBuilder sb, String s, boolean html) {
        sb.append('"');
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') sb.append('\\').append(c);
            else if (c == '\n') sb.append("\\n");
            else if (c == '\r') sb.append("\\r");
            else if (c == '\t') sb.append("\\t");
            else if (html && (c == '<' || c == '>' || c == '&')) sb.append(String.format("\\u%04x", (int)c));
            else if (c < 32) sb.append(String.format("\\u%04x", (int)c));
            else sb.append(c);
        }
        sb.append('"');
    }

    static String toYaml(Object o) {
        StringBuilder sb = new StringBuilder();
        writeYaml(sb, o, 0, false);
        return sb.toString();
    }

    static void writeYaml(StringBuilder sb, Object o, int level, boolean listItem) {
        String ind = "  ".repeat(level);
        if (o instanceof Map<?, ?> m) {
            for (Map.Entry<?, ?> e : m.entrySet()) {
                sb.append(ind).append(yamlKey(String.valueOf(e.getKey()))).append(":");
                Object v = e.getValue();
                if (v instanceof Map<?, ?> || v instanceof List<?>) {
                    sb.append('\n');
                    writeYaml(sb, v, level + 1, false);
                } else sb.append(' ').append(yamlScalar(v)).append('\n');
            }
        } else if (o instanceof List<?> l) {
            for (Object v : l) {
                sb.append(ind).append("- ");
                if (v instanceof Map<?, ?> || v instanceof List<?>) {
                    if (v instanceof Map<?, ?> mm && !mm.isEmpty()) {
                        Map.Entry<?, ?> first = mm.entrySet().iterator().next();
                        sb.append(yamlKey(String.valueOf(first.getKey()))).append(":");
                        Object fv = first.getValue();
                        if (fv instanceof Map<?, ?> || fv instanceof List<?>) {
                            sb.append('\n');
                            writeYaml(sb, fv, level + 2, false);
                        } else sb.append(' ').append(yamlScalar(fv)).append('\n');
                        LinkedHashMap<Object,Object> rest = new LinkedHashMap<>(mm);
                        rest.remove(first.getKey());
                        writeYaml(sb, rest, level + 1, false);
                    } else {
                        sb.append('\n');
                        writeYaml(sb, v, level + 1, false);
                    }
                } else sb.append(yamlScalar(v)).append('\n');
            }
        } else if (!listItem) sb.append(ind).append(yamlScalar(o)).append('\n');
    }

    static String yamlKey(String s) {
        return s.matches("[A-Za-z0-9_-]+") ? s : quote(s);
    }

    static String yamlScalar(Object o) {
        if (o == null) return "null";
        if (o instanceof Number || o instanceof Boolean) return num(o);
        String s = String.valueOf(o);
        if (s.isEmpty() || s.matches(".*[:#\\[\\]{},&*?|-].*") || s.equals("true") || s.equals("false") || s.equals("null")) return quote(s);
        return s;
    }

    static String toToml(Object o, boolean indent) {
        if (!(o instanceof Map<?, ?> m)) return tomlVal(o) + "\n";
        StringBuilder sb = new StringBuilder();
        writeTomlTable(sb, "", m, indent);
        return sb.toString();
    }

    static void writeTomlTable(StringBuilder sb, String prefix, Map<?, ?> m, boolean indent) {
        for (Map.Entry<?, ?> e : m.entrySet()) {
            Object v = e.getValue();
            if (!(v instanceof Map<?, ?>) && v != null) sb.append(indent && !prefix.isEmpty() ? "  " : "").append(e.getKey()).append(" = ").append(tomlVal(v)).append('\n');
        }
        for (Map.Entry<?, ?> e : m.entrySet()) {
            if (e.getValue() instanceof Map<?, ?> child) {
                if (sb.length() > 0 && sb.charAt(sb.length() - 1) == '\n') sb.append('\n');
                String name = prefix.isEmpty() ? String.valueOf(e.getKey()) : prefix + "." + e.getKey();
                sb.append('[').append(name).append("]\n");
                writeTomlTable(sb, name, child, indent);
            }
        }
    }

    static String tomlVal(Object v) {
        if (v == null) return "\"\"";
        if (v instanceof Number || v instanceof Boolean) return num(v);
        if (v instanceof List<?> l) {
            ArrayList<String> xs = new ArrayList<>();
            for (Object x : l) xs.add(tomlVal(x));
            return "[" + String.join(", ", xs) + "]";
        }
        if (v instanceof Map<?, ?> m) {
            ArrayList<String> xs = new ArrayList<>();
            for (Map.Entry<?, ?> e : m.entrySet()) xs.add(e.getKey() + " = " + tomlVal(e.getValue()));
            return "{ " + String.join(", ", xs) + " }";
        }
        return quote(String.valueOf(v));
    }

    static String toHcl(Object o, int level) {
        StringBuilder sb = new StringBuilder();
        if (o instanceof Map<?, ?> m) {
            int i = 0;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (i++ > 0) sb.append("\n\n");
                sb.append("  ".repeat(level)).append(quote(String.valueOf(e.getKey()))).append(" = ");
                Object v = e.getValue();
                if (v instanceof Map<?, ?>) sb.append("{\n").append(toHcl(v, level + 1)).append("\n").append("  ".repeat(level)).append("}");
                else sb.append(hclVal(v));
            }
        } else sb.append(hclVal(o));
        return sb.toString();
    }

    static String hclVal(Object v) {
        if (v == null) return "";
        if (v instanceof Number || v instanceof Boolean) return num(v);
        if (v instanceof List<?> l) {
            ArrayList<String> xs = new ArrayList<>();
            for (Object x : l) xs.add(hclVal(x));
            return "[" + String.join(", ", xs) + "]";
        }
        if (v instanceof Map<?, ?>) return "{\n" + toHcl(v, 1) + "\n}";
        return quote(String.valueOf(v));
    }

    static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') sb.append('\\').append(c);
            else if (c == '\n') sb.append("\\n");
            else if (c == '\t') sb.append("\\t");
            else sb.append(c);
        }
        return sb.append('"').toString();
    }

    static String num(Object o) {
        if (o instanceof BigDecimal bd) return bd.stripTrailingZeros().toPlainString();
        if (o instanceof Double d) return d == Math.rint(d) ? Long.toString(d.longValue()) : BigDecimal.valueOf(d).stripTrailingZeros().toPlainString();
        if (o instanceof Float f) return f == Math.rint(f) ? Long.toString(f.longValue()) : BigDecimal.valueOf(f.doubleValue()).stripTrailingZeros().toPlainString();
        return String.valueOf(o);
    }

    static class JsonParser {
        final String s; int p;
        JsonParser(String s) { this.s = s; }
        Object parse() { skip(); Object v = val(); skip(); return v; }
        Object val() {
            skip(); char c = p < s.length() ? s.charAt(p) : 0;
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (c == '"') return str();
            if (s.startsWith("true", p)) { p += 4; return true; }
            if (s.startsWith("false", p)) { p += 5; return false; }
            if (s.startsWith("null", p)) { p += 4; return null; }
            return number();
        }
        Map<String,Object> obj() {
            LinkedHashMap<String,Object> m = new LinkedHashMap<>(); p++; skip();
            while (p < s.length() && s.charAt(p) != '}') {
                String k = str(); skip(); p++; Object v = val(); m.put(k, v); skip();
                if (p < s.length() && s.charAt(p) == ',') { p++; skip(); }
            }
            if (p < s.length()) p++;
            return m;
        }
        List<Object> arr() {
            ArrayList<Object> a = new ArrayList<>(); p++; skip();
            while (p < s.length() && s.charAt(p) != ']') {
                a.add(val()); skip();
                if (p < s.length() && s.charAt(p) == ',') { p++; skip(); }
            }
            if (p < s.length()) p++;
            return a;
        }
        String str() {
            StringBuilder b = new StringBuilder(); p++;
            while (p < s.length()) {
                char c = s.charAt(p++);
                if (c == '"') break;
                if (c == '\\' && p < s.length()) {
                    char n = s.charAt(p++);
                    if (n == 'n') b.append('\n'); else if (n == 'r') b.append('\r'); else if (n == 't') b.append('\t');
                    else if (n == 'b') b.append('\b'); else if (n == 'f') b.append('\f');
                    else if (n == 'u' && p + 4 <= s.length()) { b.append((char)Integer.parseInt(s.substring(p, p + 4), 16)); p += 4; }
                    else b.append(n);
                } else b.append(c);
            }
            return b.toString();
        }
        Object number() {
            int st = p;
            while (p < s.length() && "-+0123456789.eE".indexOf(s.charAt(p)) >= 0) p++;
            String n = s.substring(st, p);
            if (n.contains(".") || n.contains("e") || n.contains("E")) return new BigDecimal(n);
            return Long.parseLong(n);
        }
        void skip() { while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++; }
    }

    static class HclParser {
        final String s; int p;
        HclParser(String s) { this.s = s; }
        Map<String,Object> parseObject(boolean braced) {
            LinkedHashMap<String,Object> m = new LinkedHashMap<>();
            if (braced) { skip(); if (peek() == '{') p++; }
            while (p < s.length()) {
                skip();
                if (p >= s.length() || peek() == '}') { if (p < s.length()) p++; break; }
                String key = key(); skip();
                if (peek() == '=') { p++; m.put(key, value()); }
                else if (peek() == '{') m.put(key, parseObject(true));
                else break;
                skip();
                if (peek() == ',') p++;
            }
            return m;
        }
        String key() {
            skip();
            if (peek() == '"') {
                JsonParser jp = new JsonParser(s.substring(p));
                String r = jp.str();
                p += jp.p;
                return r;
            }
            int st = p;
            while (p < s.length() && !Character.isWhitespace(peek()) && peek() != '=' && peek() != '{') p++;
            return s.substring(st, p);
        }
        Object value() {
            skip(); int st = p; char c = peek();
            if (c == '"') { JsonParser jp = new JsonParser(s.substring(p)); String r = jp.str(); p += jp.p; return r; }
            if (c == '[') { int end = matching('[', ']'); String v = s.substring(p, end + 1); p = end + 1; return parseArray(v); }
            if (c == '{') return parseObject(true);
            while (p < s.length() && peek() != '\n' && peek() != ',' && peek() != '}') p++;
            return parseValue(s.substring(st, p).trim());
        }
        int matching(char open, char close) {
            int d = 0; boolean q = false;
            for (int i = p; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '"' && (i == 0 || s.charAt(i - 1) != '\\')) q = !q;
                if (!q && c == open) d++;
                if (!q && c == close && --d == 0) return i;
            }
            return s.length() - 1;
        }
        char peek() { return p < s.length() ? s.charAt(p) : 0; }
        void skip() {
            while (p < s.length()) {
                while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++;
                if (p < s.length() && s.charAt(p) == '#') while (p < s.length() && s.charAt(p) != '\n') p++;
                else break;
            }
        }
    }
}
