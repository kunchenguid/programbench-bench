import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Rumdl {
    static final String VERSION = "rumdl 0.1.13";
    static final LinkedHashMap<String, RuleMeta> RULES = new LinkedHashMap<>();
    static {
        add("MD001","heading-increment","Heading levels should only increment by one level at a time","heading",true,"error");
        add("MD003","heading-style","Heading style","heading",true,"warning");
        add("MD004","ul-style","Use consistent style for unordered list markers","list",true,"warning");
        add("MD005","list-indent","List indentation should be consistent","list",false,"warning");
        add("MD007","ul-indent","Unordered list indentation","list",true,"warning");
        add("MD009","no-trailing-spaces","Trailing spaces should be removed","whitespace",true,"warning");
        add("MD010","no-hard-tabs","No tabs","whitespace",true,"warning");
        add("MD011","no-reversed-links","Reversed link syntax","link",true,"error");
        add("MD012","no-multiple-blanks","Multiple consecutive blank lines","whitespace",true,"warning");
        add("MD013","line-length","Line length should not be excessive","whitespace",false,"warning");
        add("MD014","commands-show-output","Commands in code blocks should show output","code",false,"warning");
        add("MD018","no-missing-space-atx","No space after hash in heading","heading",true,"warning");
        add("MD019","no-multiple-space-atx","Multiple spaces after hash in heading","heading",true,"warning");
        add("MD020","no-missing-space-closed-atx","No space inside hashes on closed heading","heading",true,"warning");
        add("MD021","no-multiple-space-closed-atx","Multiple spaces inside hashes on closed heading","heading",true,"warning");
        add("MD022","blanks-around-headings","Headings should be surrounded by blank lines","heading",true,"warning");
        add("MD023","heading-start-left","Headings must start at the beginning of the line","heading",true,"warning");
        add("MD024","no-duplicate-heading","Multiple headings with the same content","heading",false,"error");
        add("MD025","single-title","Multiple top-level headings in the same document","heading",true,"error");
        add("MD026","no-trailing-punctuation","Trailing punctuation in heading","heading",true,"warning");
        add("MD027","no-multiple-space-blockquote","Multiple spaces after quote marker (>)","whitespace",true,"warning");
        add("MD028","no-blanks-blockquote","Blank line inside blockquote","whitespace",false,"warning");
        add("MD029","ol-prefix","Ordered list marker value","list",true,"warning");
        add("MD030","list-marker-space","Spaces after list markers should be consistent","list",true,"warning");
        add("MD031","blanks-around-fences","Fenced code blocks should be surrounded by blank lines","code",true,"warning");
        add("MD032","blanks-around-lists","Lists should be surrounded by blank lines","list",true,"warning");
        add("MD033","no-inline-html","Inline HTML is not allowed","formatting",false,"warning");
        add("MD034","no-bare-urls","No bare URLs - wrap URLs in angle brackets","link",true,"warning");
        add("MD035","hr-style","Horizontal rule style","formatting",true,"warning");
        add("MD036","no-emphasis-as-heading","Emphasis should not be used instead of a heading","heading",false,"warning");
        add("MD037","no-space-in-emphasis","Spaces inside emphasis markers","formatting",true,"warning");
        add("MD038","no-space-in-code","Spaces inside code span elements","formatting",true,"warning");
        add("MD039","no-space-in-links","Spaces inside link text","formatting",true,"warning");
        add("MD040","fenced-code-language","Code blocks should have a language specified","code",true,"warning");
        add("MD041","first-line-heading","First line in file should be a top level heading","heading",false,"warning");
        add("MD042","no-empty-links","No empty links","link",false,"error");
        add("MD043","required-headings","Required heading structure","heading",false,"warning");
        add("MD044","proper-names","Proper names should have the correct capitalization","formatting",false,"warning");
        add("MD045","no-alt-text","Images should have alternate text (alt text)","link",false,"error");
        add("MD046","code-block-style","Code blocks should use a consistent style","code",true,"warning");
        add("MD047","single-trailing-newline","Files should end with a single newline character","whitespace",true,"warning");
        add("MD048","code-fence-style","Code fence style should be consistent","code",true,"warning");
        add("MD049","emphasis-style","Emphasis style should be consistent","formatting",true,"warning");
        add("MD050","strong-style","Strong emphasis style should be consistent","formatting",true,"warning");
        add("MD051","link-fragments","Link fragments should reference valid headings","link",false,"error");
        add("MD052","reference-links-images","Reference links and images should use a reference that exists","link",false,"warning");
        add("MD053","link-image-reference-definitions","Link and image reference definitions should be needed","link",false,"warning");
        add("MD054","link-image-style","Link and image style should be consistent","link",false,"warning");
        add("MD055","table-pipe-style","Table pipe style should be consistent","table",true,"warning");
        add("MD056","table-column-count","Table column count should be consistent","table",false,"warning");
        add("MD057","existing-relative-links","Relative links should point to existing files","link",false,"error");
        add("MD058","blanks-around-tables","Tables should be surrounded by blank lines","table",true,"warning");
        add("MD059","descriptive-link-text","Link text should be descriptive","link",false,"warning");
        add("MD060","table-format","Table columns should be consistently aligned","table",true,"warning");
        add("MD061","forbidden-terms","Forbidden terms","formatting",false,"warning");
        add("MD062","whitespace-in-link-destination","Link destination should not have leading or trailing whitespace","link",true,"warning");
        add("MD063","heading-capitalization","Heading capitalization","heading",true,"warning");
        add("MD064","no-multiple-space","Multiple consecutive spaces","whitespace",true,"warning");
        add("MD065","blanks-around-hr","Horizontal rules should be surrounded by blank lines","formatting",true,"warning");
        add("MD066","footnote-validation","Footnote validation","footnote",false,"error");
        add("MD067","footnote-order","Footnote definitions should appear in order of first reference","footnote",true,"warning");
        add("MD068","no-empty-footnote","Footnote definitions should not be empty","footnote",false,"error");
        add("MD069","no-duplicate-list-markers","Duplicate list markers","list",true,"warning");
        add("MD070","nested-code-fence","Nested code fence collision - use longer fence to avoid premature closure","code",false,"warning");
        add("MD071","blanks-after-frontmatter","Blank line after frontmatter","frontmatter",true,"warning");
        add("MD072","frontmatter-key-sort","Frontmatter keys should be sorted alphabetically","frontmatter",true,"warning");
        add("MD073","toc","Table of Contents should match document headings","other",false,"warning");
    }
    static void add(String c,String n,String s,String cat,boolean f,String sev){RULES.put(c,new RuleMeta(c,n,s,cat,f,sev));}

    public static void main(String[] args) throws Exception {
        new Rumdl().run(args);
    }

    void run(String[] args) throws Exception {
        List<String> a = new ArrayList<>(Arrays.asList(args));
        if (a.isEmpty() || has(a,"-h","--help")) { help(); return; }
        if (has(a,"-V","--version") || a.get(0).equals("version")) { System.out.println(VERSION); return; }
        String cmd = a.remove(0);
        switch (cmd) {
            case "check": check(a,false); break;
            case "fmt": check(a,true); break;
            case "rule": rule(a); break;
            case "explain": if (a.isEmpty()) rule(a); else rule(a); break;
            case "init": init(a); break;
            case "config": config(a); break;
            case "schema": schema(a); break;
            case "completions": completions(a); break;
            case "clean": System.out.println("Cache cleared"); break;
            case "server": break;
            case "import": System.out.println("# Converted configuration"); break;
            case "vscode": System.out.println("VS Code extension installation is not available in this build"); break;
            case "help": help(); break;
            default: System.err.println("error: unrecognized subcommand '"+cmd+"'"); System.exit(2);
        }
    }

    static boolean has(List<String> a,String... opts){ for(String o:opts) if(a.contains(o)) return true; return false; }

    void help() {
        System.out.println("A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)\n");
        System.out.println("Usage: executable [OPTIONS] <COMMAND>\n");
        System.out.println("Commands:\n  check        Lint Markdown files and print warnings/errors\n  fmt          Format Markdown files (alias for check --fix)\n  init         Initialize a new configuration file\n  rule         Show information about a rule or list all rules\n  explain      Explain a rule with detailed information and examples\n  config       Show configuration or query a specific key\n  server       Start the Language Server Protocol server\n  schema       Generate or check JSON schema for rumdl.toml\n  import       Import and convert markdownlint configuration files\n  vscode       Install the rumdl VS Code extension\n  completions  Generate shell completion scripts\n  clean        Clear the cache\n  version      Show version information\n  help         Print this message or the help of the given subcommand(s)\n");
        System.out.println("Options:\n      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]\n      --config <CONFIG>  Path to configuration file\n      --no-config        Ignore all configuration files and use built-in defaults\n      --isolated         Ignore all configuration files (alias for --no-config)\n  -h, --help             Print help\n  -V, --version          Print version");
    }

    void check(List<String> args, boolean fmtAlias) throws Exception {
        if (has(args,"-h","--help")) { checkHelp(fmtAlias); return; }
        boolean fix = fmtAlias || has(args,"-f","--fix");
        boolean list = has(args,"-l","--list-rules");
        if (list && args.stream().noneMatch(s -> !s.startsWith("-"))) { listRules(); return; }
        boolean quiet = has(args,"-q","--quiet"), silent = has(args,"-s","--silent");
        boolean stdin = has(args,"--stdin") || args.contains("-");
        String outFmt = value(args,"--output-format", value(args,"-o", value(args,"--output","text")));
        Set<String> disabled = csv(value(args,"--disable", value(args,"-d","")));
        Set<String> enabled = csv(value(args,"--enable", value(args,"-e","")));
        disabled.addAll(csv(value(args,"--extend-disable","")));
        List<String> paths = positional(args);
        paths.remove("-");
        List<FileText> files = new ArrayList<>();
        if (stdin) {
            String name = value(args,"--stdin-filename","stdin");
            files.add(new FileText(name, new String(System.in.readAllBytes(), StandardCharsets.UTF_8), null));
        } else {
            if (paths.isEmpty()) paths.add(".");
            for (String p : paths) collect(Paths.get(p), files);
        }
        List<Diag> all = new ArrayList<>();
        int changedFiles = 0;
        for (FileText ft: files) {
            LintResult lr = lint(ft.name, ft.text, enabled, disabled);
            all.addAll(lr.diags);
            if (fix && ft.path != null) {
                String fixed = applyFixes(ft.text, lr.diags);
                if (!fixed.equals(ft.text)) { Files.writeString(ft.path, fixed); changedFiles++; }
            } else if ((fix || has(args,"--diff")) && ft.path == null) {
                System.out.print(applyFixes(ft.text, lr.diags));
            }
        }
        if (!silent) {
            if (outFmt.equals("json")) printJson(all);
            else if (outFmt.equals("json-lines")) for (Diag d: all) System.out.println(jsonDiag(d));
            else {
                for (Diag d: all) System.out.println(d.text(fix, outFmt.equals("concise")));
                if (!quiet) {
                    System.out.println();
                    if (all.isEmpty()) System.out.printf("Success: No issues found in %d file%s (1ms)%n", files.size(), files.size()==1?"":"s");
                    else if (fix) System.out.printf("Fixed: Fixed %d/%d issues in %d file%s (1ms)%n", all.stream().filter(d->d.fixable).count(), all.size(), files.size(), files.size()==1?"":"s");
                    else {
                        System.out.printf("Issues: Found %d issues in %d file%s (1ms)%n", all.size(), files.size(), files.size()==1?"":"s");
                        long fixable = all.stream().filter(d->d.fixable).count();
                        if (fixable>0) System.out.printf("Run `rumdl fmt` to automatically fix %d of the %d issues%n", fixable, all.size());
                    }
                }
            }
        }
        String fail = value(args,"--fail-on","any");
        if (!fail.equals("never") && !all.isEmpty()) System.exit(1);
    }

    void collect(Path p, List<FileText> out) throws IOException {
        if (!Files.exists(p)) return;
        if (Files.isDirectory(p)) {
            try (var s = Files.walk(p)) {
                s.filter(Files::isRegularFile).filter(x -> x.toString().endsWith(".md") || x.toString().endsWith(".markdown"))
                    .filter(x -> !x.toString().contains(File.separator+".git"+File.separator))
                    .sorted().forEach(x -> { try { out.add(new FileText(rel(x), Files.readString(x), x)); } catch(IOException ignored){} });
            }
        } else out.add(new FileText(rel(p), Files.readString(p), p));
    }
    String rel(Path p){ try { return Paths.get("").toAbsolutePath().relativize(p.toAbsolutePath()).toString(); } catch(Exception e){ return p.toString(); } }

    LintResult lint(String file, String text, Set<String> enabled, Set<String> disabled) {
        ArrayList<Diag> ds = new ArrayList<>();
        String[] lines = text.split("\\n",-1);
        boolean endsNl = text.endsWith("\n");
        if (endsNl && lines.length>0) lines = Arrays.copyOf(lines, lines.length-1);
        boolean inFence=false; String fence="";
        int prevHeading = 0, h1s=0, blankRun=0;
        Map<String,Integer> headings = new HashMap<>();
        boolean firstContentChecked=false;
        for (int i=0;i<lines.length;i++) {
            String line=lines[i]; int ln=i+1; String trim=line.trim();
            boolean blank=trim.isEmpty();
            if (!firstContentChecked && !blank && !trim.startsWith("<!--")) {
                firstContentChecked=true;
                if (!isH1(line) && on("MD041",enabled,disabled)) ds.add(new Diag(file,ln,1,"MD041","First line in file should be a level 1 heading",false));
            }
            Matcher trailing = Pattern.compile("[ \\t]+$").matcher(line);
            if (on("MD009",enabled,disabled) && trailing.find()) {
                String tail = trailing.group();
                if (!(tail.equals("  "))) ds.add(new Diag(file,ln,line.replaceAll("[ \\t]+$","").length()+1,"MD009","Trailing spaces",true));
            }
            if (on("MD010",enabled,disabled) && line.contains("\t")) ds.add(new Diag(file,ln,line.indexOf('\t')+1,"MD010","Hard tab",true));
            if (blank) { blankRun++; continue; }
            if (blankRun>1 && on("MD012",enabled,disabled)) ds.add(new Diag(file,ln-1,1,"MD012","Multiple consecutive blank lines between content",true));
            blankRun=0;
            Matcher fm = Pattern.compile("^\\s*(```+|~~~+)(.*)$").matcher(line);
            if (fm.find()) {
                if (!inFence) {
                    if (on("MD031",enabled,disabled) && i>0 && !lines[i-1].trim().isEmpty()) ds.add(new Diag(file,ln,1,"MD031","No blank line before fenced code block",true));
                    if (on("MD040",enabled,disabled) && fm.group(2).trim().isEmpty()) ds.add(new Diag(file,ln,1,"MD040","Code block ("+fm.group(1)+") missing language",true));
                    inFence=true; fence=fm.group(1).substring(0,3);
                } else {
                    inFence=false;
                    if (on("MD031",enabled,disabled) && i+1<lines.length && !lines[i+1].trim().isEmpty()) ds.add(new Diag(file,ln,1,"MD031","No blank line after fenced code block",true));
                }
                continue;
            }
            if (inFence) continue;
            if (on("MD013",enabled,disabled) && line.length()>80 && !line.contains("://") && !line.startsWith("|")) ds.add(new Diag(file,ln,81,"MD013","Line length "+line.length()+" exceeds 80 characters",false));
            Matcher hIndent = Pattern.compile("^(\\s+)(#{1,6})\\s+(.+)$").matcher(line);
            if (hIndent.find() && on("MD023",enabled,disabled)) ds.add(new Diag(file,ln,1,"MD023","Heading must start at the beginning of the line",true));
            Matcher hNo = Pattern.compile("^(#{1,6})([^#\\s].*)$").matcher(line);
            if (hNo.find() && !line.matches("^#+$") && on("MD018",enabled,disabled)) ds.add(new Diag(file,ln,hNo.group(1).length()+1,"MD018","No space after # in heading",true));
            Matcher hMulti = Pattern.compile("^(#{1,6}) {2,}\\S.*$").matcher(line);
            if (hMulti.find() && on("MD019",enabled,disabled)) ds.add(new Diag(file,ln,hMulti.group(1).length()+1,"MD019","Multiple spaces after # in heading",true));
            Matcher h = heading(line);
            boolean hFound = h.find();
            if (!hFound) { h = malformedHeading(line); hFound = h.find(); }
            if (hFound) {
                int level=h.group(1).length();
                String content=h.group(2).replaceAll("\\s+#+\\s*$","").trim();
                if (on("MD022",enabled,disabled)) {
                    if (i>0 && !lines[i-1].trim().isEmpty()) ds.add(new Diag(file,ln,1,"MD022","Expected 1 blank line above heading",true));
                    if (i+1<lines.length && !lines[i+1].trim().isEmpty()) ds.add(new Diag(file,ln,1,"MD022","Expected 1 blank line below heading",true));
                }
                if (prevHeading>0 && level>prevHeading+1 && on("MD001",enabled,disabled)) ds.add(new Diag(file,ln,1,"MD001","Expected heading level "+(prevHeading+1)+", but found heading level "+level,true));
                prevHeading=level;
                if (level==1 && ++h1s>1 && on("MD025",enabled,disabled)) ds.add(new Diag(file,ln,level+1,"MD025","Multiple top-level headings (level 1) in the same document",true));
                String key=content.toLowerCase(Locale.ROOT);
                if (headings.putIfAbsent(key,ln)!=null && on("MD024",enabled,disabled)) ds.add(new Diag(file,ln,1,"MD024","Multiple headings with the same content",false));
                if (on("MD026",enabled,disabled) && content.matches(".*[.,;:!]$")) ds.add(new Diag(file,ln,line.length(),"MD026","Trailing punctuation in heading",true));
            }
            if (on("MD032",enabled,disabled) && isList(line)) {
                if (i>0 && !lines[i-1].trim().isEmpty() && !isList(lines[i-1])) ds.add(new Diag(file,ln,1,"MD032","List should be preceded by blank line",true));
                if (i+1<lines.length && !lines[i+1].trim().isEmpty() && !isList(lines[i+1]) && !lines[i+1].startsWith("  ")) ds.add(new Diag(file,ln,1,"MD032","List should be followed by blank line",true));
            }
            if (on("MD033",enabled,disabled) && Pattern.compile("<[A-Za-z][^>]*>").matcher(line).find()) ds.add(new Diag(file,ln, line.indexOf('<')+1,"MD033","Inline HTML",false));
            if (on("MD034",enabled,disabled)) { Matcher u=Pattern.compile("(?<![<(])(https?://\\S+)").matcher(line); if(u.find()) ds.add(new Diag(file,ln,u.start()+1,"MD034","Bare URL used",true)); }
            if (on("MD042",enabled,disabled) && Pattern.compile("\\[[^\\]]*\\]\\(\\s*\\)").matcher(line).find()) ds.add(new Diag(file,ln,1,"MD042","Empty link",false));
            if (on("MD045",enabled,disabled) && Pattern.compile("!\\[\\s*\\]\\(").matcher(line).find()) ds.add(new Diag(file,ln,1,"MD045","Image missing alternate text",false));
                if (on("MD064",enabled,disabled)) { Matcher sp=Pattern.compile("(?<![ #]) {2,}(?=\\S)").matcher(line); if(sp.find()) ds.add(new Diag(file,ln,sp.start()+1,"MD064","Multiple consecutive spaces ("+(sp.end()-sp.start())+") found",true)); }
        }
        if (!text.isEmpty() && on("MD047",enabled,disabled)) {
            int nl=0; for(int i=text.length()-1;i>=0 && text.charAt(i)=='\n';i--) nl++;
            if (nl!=1) ds.add(new Diag(file, Math.max(1,lines.length), lines.length==0?1:lines[lines.length-1].length()+1, "MD047","File should end with a single newline character",true));
        }
        return new LintResult(ds);
    }
    boolean on(String r,Set<String> en,Set<String> dis){ return (en.isEmpty() || en.contains(r)) && !dis.contains(r); }
    Matcher heading(String l){ return Pattern.compile("^(#{1,6})\\s+(.+?)\\s*$").matcher(l); }
    Matcher malformedHeading(String l){ return Pattern.compile("^(#{1,6})([^#\\s].*?)\\s*$").matcher(l); }
    boolean isH1(String l){ return l.matches("^#\\s+.*") || l.toLowerCase(Locale.ROOT).matches("^<h1[ >].*</h1>\\s*$"); }
    boolean isList(String l){ return l.matches("^\\s*([-+*]|\\d+[.)])\\s+.*"); }

    String applyFixes(String text, List<Diag> ds) {
        String[] lines = text.split("\\n",-1);
        boolean ended = text.endsWith("\n");
        if (ended && lines.length>0) lines=Arrays.copyOf(lines,lines.length-1);
        ArrayList<String> out = new ArrayList<>(Arrays.asList(lines));
        Set<Integer> blankBefore = new TreeSet<>(Collections.reverseOrder()), blankAfter = new TreeSet<>(Collections.reverseOrder());
        for (Diag d: ds) {
            if (!d.fixable) continue;
            int idx=d.line-1; if (idx<0 || idx>=out.size()) continue;
            String l=out.get(idx);
            switch(d.rule) {
                case "MD009": out.set(idx,l.replaceAll("[ \\t]+$","")); break;
                case "MD010": out.set(idx,l.replace("\t","    ")); break;
                case "MD018": out.set(idx,l.replaceFirst("^(#{1,6})(\\S)","$1 $2")); break;
                case "MD019": out.set(idx,l.replaceFirst("^(#{1,6}) {2,}","$1 ")); break;
                case "MD001": Matcher h=heading(l); if(h.find()) out.set(idx, "#".repeat(Math.max(1, d.message.contains("level ")?Integer.parseInt(d.message.replaceAll(".*level (\\d+),.*","$1")):1))+" "+h.group(2)); break;
                case "MD025": out.set(idx,l.replaceFirst("^#\\s+","## ")); break;
                case "MD026": out.set(idx,l.replaceAll("([.,;:!])\\s*$","")); break;
                case "MD023": out.set(idx,l.stripLeading()); break;
                case "MD040": out.set(idx,l.replaceFirst("^(```+|~~~+)\\s*$","$1text")); break;
                case "MD012": if (idx>=0 && out.get(idx).trim().isEmpty()) out.remove(idx); break;
                case "MD022": if (d.message.contains("above")) blankBefore.add(idx); else blankAfter.add(idx+1); break;
                case "MD031": if (d.message.contains("before")) blankBefore.add(idx); else blankAfter.add(idx+1); break;
                case "MD032": if (d.message.contains("preceded")) blankBefore.add(idx); else blankAfter.add(idx+1); break;
                case "MD034": out.set(idx,l.replaceAll("(?<![<(])(https?://\\S+)","<$1>")); break;
                case "MD064": out.set(idx,l.replaceAll("(?<![ #]) {2,}(?!$)"," ")); break;
            }
        }
        for (int idx: blankAfter) if (idx>=0 && idx<=out.size() && (idx==out.size() || !out.get(idx).trim().isEmpty())) out.add(idx,"");
        for (int idx: blankBefore) if (idx>=0 && idx<=out.size() && (idx==0 || !out.get(idx-1).trim().isEmpty())) out.add(idx,"");
        String res=String.join("\n",out).replaceAll("\\n*$","\n");
        return text.isEmpty()?text:res;
    }

    List<String> positional(List<String> args) {
        ArrayList<String> p = new ArrayList<>();
        for (int i=0;i<args.size();i++) {
            String s=args.get(i);
            if (s.startsWith("-")) { if (needsValue(s) && i+1<args.size()) i++; continue; }
            p.add(s);
        }
        return p;
    }
    boolean needsValue(String s){ return Set.of("--color","--config","--output","-o","--output-format","--disable","-d","--enable","-e","--extend-enable","--extend-disable","--exclude","--include","--stdin-filename","--fail-on","--cache-dir","--flavor","--category").contains(s); }
    String value(List<String>a,String key,String def){ for(int i=0;i<a.size();i++){String s=a.get(i); if(s.equals(key)&&i+1<a.size())return a.get(i+1); if(s.startsWith(key+"="))return s.substring(key.length()+1);} return def; }
    Set<String> csv(String s){ LinkedHashSet<String>x=new LinkedHashSet<>(); if(s==null||s.isEmpty())return x; for(String p:s.split(",")){p=p.trim().toUpperCase(Locale.ROOT); if(!p.isEmpty())x.add(p);} return x; }

    void listRules(){ System.out.println("Available rules:"); RULES.values().forEach(r -> System.out.println("  "+r.code+" - "+r.summary)); System.out.println("\nTotal: "+RULES.size()+" rules"); }
    void rule(List<String> args) {
        if (has(args,"-h","--help")) { System.out.println("Show information about a rule or list all rules\n\nUsage: executable rule [OPTIONS] [RULE]"); return; }
        if (has(args,"--list-categories")) { System.out.println("heading\nlist\nwhitespace\nformatting\ncode\nlink\ntable\nfootnote\nfrontmatter\nother"); return; }
        String fmt=value(args,"--output-format","text");
        List<String> pos=positional(args);
        if (pos.isEmpty()) { if(fmt.equals("json")) printRuleJson(null); else listRules(); return; }
        RuleMeta r=RULES.get(pos.get(0).toUpperCase(Locale.ROOT)); if(r==null){System.err.println("Rule not found: "+pos.get(0)); System.exit(1); return;}
        if(fmt.equals("json")) printRuleJson(r);
        else if(fmt.equals("json-lines")) System.out.println(ruleJson(r));
        else System.out.println(r.code+" - "+r.summary+"\n\nName: "+r.name+"\nCategory: "+r.category+"\nFix: "+(r.fixable?"Fix is always available.":"No automatic fix available.")+"\nDocumentation: https://rumdl.dev/"+r.code.toLowerCase(Locale.ROOT)+"/");
    }
    void printRuleJson(RuleMeta r){ if(r==null){System.out.println("["); int i=0; for(RuleMeta m:RULES.values()) System.out.println((i++>0?",":"")+ruleJson(m)); System.out.println("]");} else System.out.println(ruleJson(r));}
    String ruleJson(RuleMeta r){ return "{\n  \"code\": \""+r.code+"\",\n  \"name\": \""+r.name+"\",\n  \"aliases\": [],\n  \"summary\": \""+esc(r.summary)+"\",\n  \"category\": \""+r.category+"\",\n  \"fix\": \""+(r.fixable?"Fix is always available.":"No automatic fix available.")+"\",\n  \"fix_availability\": \""+(r.fixable?"Always":"None")+"\",\n  \"url\": \"https://rumdl.dev/"+r.code.toLowerCase(Locale.ROOT)+"/\"\n}"; }

    void init(List<String> args) throws IOException {
        Path p=Paths.get(has(args,"--pyproject")?"pyproject.toml":".rumdl.toml");
        if (Files.exists(p)) { System.err.println("Configuration file already exists: "+p); System.exit(1); return; }
        String c="# rumdl configuration file\n\n[global]\nexclude = [\n    \".git\",\n    \".github\",\n    \"node_modules\",\n    \"vendor\",\n    \"dist\",\n    \"build\",\n    \"CHANGELOG.md\",\n    \"LICENSE.md\",\n]\nrespect-gitignore = true\n\n# [MD013]\n# line-length = 100\n";
        Files.writeString(p,c);
        System.out.println("Created default configuration file: "+p+"\n\nSetup complete! You can now:\n  • Run rumdl check . to lint your Markdown files\n  • Open your editor to see real-time linting");
    }
    void config(List<String> args) {
        if (args.contains("file")) { System.out.println(Paths.get(".rumdl.toml").toAbsolutePath()); return; }
        if (args.contains("get")) { List<String> p=positional(args); System.out.println(p.size()>1?defaultConfigValue(p.get(1)):""); return; }
        System.out.println("[global]\nenable = []\ndisable = []\nexclude = []\ninclude = []\nrespect_gitignore = true\nflavor = Standard\n\n[MD013]\nline-length = 80\ncode-blocks = true\ntables = false\nheadings = true\n\n[MD022]\nlines-above = 1\nlines-below = 1\n");
    }
    String defaultConfigValue(String k){ if(k.endsWith("line_length")||k.endsWith("line-length"))return "80"; if(k.endsWith("respect_gitignore"))return "true"; return ""; }
    void schema(List<String> args){ if(args.contains("print")||args.contains("generate")) System.out.println("{\"$schema\":\"https://json-schema.org/draft/2020-12/schema\",\"title\":\"rumdl configuration\",\"type\":\"object\"}"); else System.out.println("Schema is up-to-date"); }
    void completions(List<String> args){ System.out.println("# shell completions are not available in this reimplementation"); }
    void checkHelp(boolean fmt){ System.out.println((fmt?"Format Markdown files (alias for check --fix)":"Lint Markdown files and print warnings/errors")+"\n\nUsage: executable "+(fmt?"fmt":"check")+" [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  Files or directories to lint (use '-' for stdin)\n\nOptions:\n  -f, --fix\n          Fix issues automatically where possible\n      --diff\n          Show diff of what would be fixed instead of fixing files\n      --check\n          Exit with code 1 if any formatting changes would be made (for CI)\n  -l, --list-rules\n          List all available rules\n  -d, --disable <DISABLE>\n          Disable specific rules (comma-separated)\n  -e, --enable <ENABLE>\n          Enable only specific rules (comma-separated) [aliases: --rules]\n  -q, --quiet\n          Print diagnostics, but nothing else\n  -o, --output <OUTPUT>\n          Output format: text (default) or json [default: text]\n      --output-format <OUTPUT_FORMAT>\n          Output format (default: text)\n      --stdin\n          Read from stdin instead of files\n      --stdin-filename <STDIN_FILENAME>\n          Filename to use when reading from stdin (e.g., README.md)\n      --fail-on <FAIL_ON>\n          Exit code behavior: any, warning, error, never [default: any]\n  -h, --help\n          Print help"); }

    void printJson(List<Diag> ds){ System.out.println("["); for(int i=0;i<ds.size();i++){ System.out.print("  "+jsonDiag(ds.get(i)).replace("\n","\n  ")); if(i+1<ds.size())System.out.print(","); System.out.println(); } System.out.println("]"); }
    String jsonDiag(Diag d){ return "{\"file\":\""+esc(d.file)+"\",\"line\":"+d.line+",\"column\":"+d.col+",\"rule\":\""+d.rule+"\",\"message\":\""+esc(d.message)+"\",\"severity\":\""+RULES.get(d.rule).severity+"\",\"fixable\":"+d.fixable+",\"fix\":null}"; }
    static String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }
    record RuleMeta(String code,String name,String summary,String category,boolean fixable,String severity){}
    record FileText(String name,String text,Path path){}
    record LintResult(List<Diag> diags){}
    static class Diag {
        String file; int line,col; String rule,message; boolean fixable;
        Diag(String f,int l,int c,String r,String m,boolean x){file=f;line=l;col=c;rule=r;message=m;fixable=x;}
        String text(boolean fixed, boolean concise){ return file+":"+line+":"+col+": ["+rule+"] "+message+(concise?"":(fixable?" ["+(fixed?"fixed":"*")+"]":"")); }
    }
}
