import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Statix {
    static final String VERSION = "statix 0.5.8";
    static final LinkedHashMap<String, String> LINTS = new LinkedHashMap<>();
    static final Map<String, String> TITLES = new HashMap<>();
    static final Map<String, String> EXPLAIN = new HashMap<>();
    static {
        add("W01","bool_comparison","Unnecessary comparison with boolean","## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n\n## Example\nInstead of checking the value of `x`:\n\n```nix\nif x == true then 0 else 1\n```\n\nUse `x` directly:\n\n```nix\nif x then 0 else 1\n```");
        add("W02","empty_let_in","Useless let-in expression","## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\nThese are probably remnants from debugging or editing expressions.\n\n## Example\n\n```nix\nlet in pkgs.statix\n```\n\nPreserve only the body of the `let-in` expression:\n\n```nix\npkgs.statix\n```");
        add("W03","manual_inherit","Assignment instead of inherit","## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into\nthe current scope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  a = 2;\nin\n  { a = a; b = 3; }\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  a = 2;\nin\n  { inherit a; b = 3; }\n```");
        add("W04","manual_inherit_from","Assignment instead of inherit from","## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into\nscope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  mtl = pkgs.haskellPackages.mtl;\nin\n  null\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  inherit (pkgs.haskellPackages) mtl;\nin\n  null\n```");
        add("W05","legacy_let_syntax","Found legacy let syntax","## What it does\nChecks for legacy-let syntax that was never formalized.\n\n## Why is this bad?\nThis syntax construct is undocumented, refrain from using it.");
        add("W06","collapsible_let_in","These let-in expressions are collapsible","## What it does\nChecks for `let-in` expressions whose body is another `let-in`\nexpression.\n\n## Why is this bad?\nUnnecessary code, the `let-in` expressions can be merged.");
        add("W07","eta_reduction","This function expression is eta reducible","## What it does\nChecks for eta-reducible functions, i.e.: converts lambda\nexpressions into free standing functions where applicable.\n\n## Why is this bad?\nOftentimes, eta-reduction results in code that is more natural\nto read.");
        add("W08","useless_parens","These parentheses can be omitted","## What it does\nChecks for unnecessary parentheses.\n\n## Why is this bad?\nUnnecessarily parenthesized code is hard to read.");
        add("W10","empty_pattern","Found empty pattern in function argument","## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.\n\n## Why is this bad?\nThe intention with empty patterns is not instantly obvious. Prefer\nan underscore identifier instead, to indicate that the argument\nis being ignored.");
        add("W11","redundant_pattern_bind","Found redundant pattern bind in function argument","## What it does\nChecks for binds of the form `inputs @ { ... }` in function\narguments.\n\n## Why is this bad?\nThe variadic pattern here is redundant, as it does not capture\nanything.");
        add("W12","unquoted_uri","Found unquoted URI expression","## What it does\nChecks for URI expressions that are not quoted.\n\n## Why is this bad?\nThe Nix language has a special syntax for URLs even though quoted\nstrings can also be used to represent them.");
        add("W14","empty_inherit","Found empty inherit statement","## What it does\nChecks for empty inherit statements.\n\n## Why is this bad?\nUseless code, probably the result of a refactor.\n\n## Example\n\n```nix\ninherit;\n```\n\nRemove it altogether.");
        add("W17","deprecated_to_path","Found usage of deprecated builtin toPath","## What it does\nChecks for usage of the `toPath` function.\n\n## Why is this bad?\n`toPath` is deprecated.");
        add("W18","bool_simplification","This boolean expression can be simplified","## What it does\nChecks for boolean expressions that can be simplified.\n\n## Why is this bad?\nComplex booleans affect readibility.");
        add("W19","useless_has_attr","This `if` expression can be simplified with `or`","## What it does\nChecks for expressions that use the \"has attribute\" operator: `?`,\nwhere the `or` operator would suffice.\n\n## Why is this bad?\nThe `or` operator is more readable.");
        add("W20","repeated_keys","Found repeated keys","## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using\nan attribute set instead.\n\n## Why is this bad?\nAvoiding repetetion helps improve readibility.");
        add("W23","empty_list_concat","Unnecessary concatenation with empty list","## What it does\nChecks for concatenations to empty lists\n\n## Why is this bad?\nConcatenation with the empty list is a no-op.");
    }
    static void add(String c,String n,String t,String e){LINTS.put(c,n);TITLES.put(c,t);EXPLAIN.put(c,e);}

    static class Opt {
        String cmd, target = ".";
        boolean stdin, dry;
        String format = "stderr";
        String config = ".";
        List<String> ignore = new ArrayList<>();
        Set<String> disabled = new HashSet<>();
    }
    static class Diag {
        String code, path, msg, lineText; int line, col;
        Diag(String code,String path,int line,int col,String msg,String lineText){this.code=code;this.path=path;this.line=line;this.col=col;this.msg=msg;this.lineText=lineText;}
    }

    public static void main(String[] args) throws Exception {
        int rc = run(args);
        System.exit(rc);
    }

    static int run(String[] args) throws Exception {
        if (args.length == 0 || has(args,"--help") || has(args,"-h")) {
            if (args.length > 0 && !args[0].startsWith("-")) return subHelp(args[0]);
            help(); return 0;
        }
        if (has(args,"--version") || has(args,"-V")) { System.out.println(VERSION); return 0; }
        String cmd = args[0];
        if (cmd.equals("help")) { help(); return 0; }
        if (cmd.equals("list")) { for (var e:LINTS.entrySet()) System.out.println(e.getKey()+" "+e.getValue()); return 0; }
        if (cmd.equals("dump")) { System.out.println("disabled = []\nignore = ['.direnv']\n"); return 0; }
        if (cmd.equals("explain")) return explain(args);
        if (cmd.equals("check") || cmd.equals("fix") || cmd.equals("single")) return checkFix(parse(cmd, Arrays.copyOfRange(args,1,args.length)));
        System.err.println("error: The subcommand '"+cmd+"' wasn't recognized\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help");
        return 2;
    }

    static boolean has(String[] a,String x){ for(String s:a) if(s.equals(x)) return true; return false; }

    static Opt parse(String cmd, String[] args) {
        Opt o = new Opt(); o.cmd = cmd;
        for (int i=0;i<args.length;i++) {
            String s=args[i];
            if (s.equals("-s")||s.equals("--stdin")) o.stdin=true;
            else if (s.equals("-d")||s.equals("--dry-run")) o.dry=true;
            else if ((s.equals("-o")||s.equals("--format")) && i+1<args.length) o.format=args[++i];
            else if ((s.equals("-i")||s.equals("--ignore")) && i+1<args.length) o.ignore.add(args[++i]);
            else if ((s.equals("-c")||s.equals("--config")) && i+1<args.length) o.config=args[++i];
            else if ((s.equals("-p")||s.equals("--position")) && i+1<args.length) i++;
            else if (s.equals("--") && i+1<args.length) o.target=args[++i];
            else if (!s.startsWith("-")) o.target=s;
        }
        return o;
    }

    static int explain(String[] args) {
        if (args.length < 2) { System.err.println("error: The following required arguments were not provided:\n    <TARGET>"); return 2; }
        String t=args[1].toUpperCase(Locale.ROOT);
        if (!t.matches("W?\\d+")) { System.out.println("syntax error"); return 0; }
        int n=Integer.parseInt(t.replace("W",""));
        String key=String.format("W%02d", n);
        if (EXPLAIN.containsKey(key)) System.out.println(EXPLAIN.get(key));
        else System.out.println("explain error: lint with code `"+n+"` not found");
        return 0;
    }

    static int checkFix(Opt o) throws Exception {
        if (!o.format.equals("stderr") && !o.format.equals("errfmt")) {
            System.err.println("error: Invalid value for '--format <FORMAT>': statix was not compiled with the `json` feature flag\n\nFor more information try --help");
            return 2;
        }
        loadConfig(o);
        if (o.stdin) {
            String text = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
            return processOne(o, "<stdin>", text, null);
        }
        List<Path> files = files(Path.of(o.target), o.ignore);
        if (files == null) { System.err.println("config error: path error: file not found: "+o.target); return 0; }
        int any=0;
        for (Path p: files) {
            String text = Files.readString(p);
            int rc = processOne(o, p.toString(), text, p);
            if (rc != 0) any = rc;
        }
        return o.cmd.equals("check") ? any : 0;
    }

    static List<Path> files(Path p, List<String> ignores) throws IOException {
        if (!Files.exists(p)) return null;
        List<Path> out = new ArrayList<>();
        if (Files.isRegularFile(p)) out.add(p);
        else try (var st = Files.walk(p)) {
            st.filter(Files::isRegularFile).filter(x -> x.toString().endsWith(".nix")).forEach(x -> {
                String s=x.toString();
                for(String ig: ignores) if(s.contains(ig.replace("*",""))) return;
                out.add(x);
            });
        }
        Collections.sort(out);
        return out;
    }

    static int processOne(Opt o, String path, String text, Path real) throws IOException {
        List<Diag> ds = analyze(path, text);
        ds.removeIf(d -> o.disabled.contains(d.code.toLowerCase(Locale.ROOT)) || o.disabled.contains(LINTS.getOrDefault(d.code,"")));
        if (o.cmd.equals("check")) {
            if (o.format.equals("errfmt")) for (Diag d: ds) System.out.println(errfmt(d));
            else for (Diag d: ds) System.out.print(pretty(d));
            return ds.isEmpty()?0:1;
        }
        String fixed = fix(text);
        if (o.stdin && !o.dry) { System.out.print(fixed); return 0; }
        if (o.dry) {
            if (!fixed.equals(text)) System.out.print(diff(path, text, fixed));
        } else if (real != null && !fixed.equals(text)) Files.writeString(real, fixed);
        return 0;
    }

    static void loadConfig(Opt o) {
        Path p = Path.of(o.config);
        if (Files.isDirectory(p)) p = p.resolve("statix.toml");
        if (!Files.exists(p)) return;
        try {
            String t = Files.readString(p);
            Matcher d = Pattern.compile("disabled\\s*=\\s*\\[([^]]*)]", Pattern.DOTALL).matcher(t);
            if (d.find()) for (String x : d.group(1).split(",")) {
                String v = x.trim().replace("\"","").replace("'","");
                if (!v.isEmpty()) {
                    o.disabled.add(v.toLowerCase(Locale.ROOT));
                    if (v.matches("W?\\d+")) o.disabled.add(String.format("w%02d", Integer.parseInt(v.replaceAll("[Ww]",""))));
                }
            }
            Matcher ig = Pattern.compile("ignore\\s*=\\s*\\[([^]]*)]", Pattern.DOTALL).matcher(t);
            if (ig.find()) for (String x : ig.group(1).split(",")) {
                String v = x.trim().replace("\"","").replace("'","");
                if (!v.isEmpty()) o.ignore.add(v);
            }
        } catch (IOException ignored) {}
    }

    static List<Diag> analyze(String path, String text) {
        List<Diag> out = new ArrayList<>();
        if (unbalanced(text)) { out.add(new Diag("E00",path,1,1,"Unexpected end of file", firstLine(text))); return out; }
        String[] lines = text.split("\n", -1);
        Map<String,List<Diag>> keys = new LinkedHashMap<>();
        for (int i=0;i<lines.length;i++) {
            String l=lines[i]; int ln=i+1;
            find(out,path,ln,l,"W03","\\b([A-Za-z_][\\w'-]*)\\s*=\\s*\\1\\s*;","This assignment is better written with `inherit`");
            find(out,path,ln,l,"W04","\\b([A-Za-z_][\\w'-]*)\\s*=\\s*([A-Za-z_][\\w'-]*)\\.\\1\\s*;","This assignment is better written with `inherit`");
            Matcher m=Pattern.compile("([^\\s;(){}]+)\\s*(==|!=)\\s*(true|false)").matcher(l);
            while(m.find()) out.add(new Diag("W01",path,ln,m.start()+1,"Comparing `"+m.group(1)+"` with boolean literal `"+m.group(3)+"`",l));
            find(out,path,ln,l,"W02","\\blet\\s+in\\b","This let-in expression has no entries");
            Matcher cm=Pattern.compile("\\blet\\b.*?\\bin\\s+let\\b").matcher(l);
            if(cm.find()){out.add(new Diag("W06",path,ln,cm.start()+1,"This `let in` expression contains a nested `let in` expression",l)); out.add(new Diag("W06",path,ln,cm.end()-2,"This `let in` expression is nested",l));}
            Matcher eta=Pattern.compile("\\(([A-Za-z_][\\w'-]*)\\s*:\\s*([A-Za-z_][\\w'-.]*)\\s+\\1\\)").matcher(l);
            while(eta.find()) out.add(new Diag("W07",path,ln,eta.start()+1,"Found eta-reduction: `"+eta.group(2)+"`",l));
            Matcher par=Pattern.compile("=\\s*\\(([^()]+)\\)\\s*;").matcher(l);
            while(par.find()) out.add(new Diag("W08",path,ln,par.start(1),"Useless parentheses around value in binding",l));
            if (!l.matches(".*\\b[A-Za-z_][\\w'-]*\\s*@\\s*\\{\\s*\\.\\.\\.\\s*}\\s*:.*"))
                find(out,path,ln,l,"W10","\\{\\s*\\.\\.\\.\\s*}\\s*:","This pattern is empty, use `_` instead");
            Matcher rb=Pattern.compile("\\b([A-Za-z_][\\w'-]*)\\s*@\\s*\\{\\s*\\.\\.\\.\\s*}\\s*:").matcher(l);
            while(rb.find()) out.add(new Diag("W11",path,ln,rb.start()+1,"This pattern bind is redundant, use `"+rb.group(1)+"` instead",l));
            Matcher uri=Pattern.compile("(?<![\"])(\\b[A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+#~:-]+)").matcher(l);
            while(uri.find()) if(!uri.group(1).startsWith("http://") || true) out.add(new Diag("W12",path,ln,uri.start()+1,"Consider quoting this URI expression",l));
            find(out,path,ln,l,"W14","\\binherit\\s*;","Remove this empty `inherit` statement");
            find(out,path,ln,l,"W17","\\bbuiltins\\.toPath\\b","`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more");
            find(out,path,ln,l,"W18","!\\s*\\([^)]*\\s*==\\s*[^)]*\\)","Try `!=` instead of `!(... == ...)`");
            Matcher has=Pattern.compile("if\\s+([A-Za-z_][\\w'-]*)\\s*\\?\\s*([A-Za-z_][\\w'-]*)\\s+then\\s+\\1\\.\\2\\s+else\\s+([^;]+)").matcher(l);
            while(has.find()) out.add(new Diag("W19",path,ln,has.start()+1,"Consider using `"+has.group(1)+"."+has.group(2)+" or ("+has.group(3).trim()+")` instead of this `if` expression",l));
            find(out,path,ln,l,"W23","\\[\\s*]\\s*\\+\\+","Concatenation with the empty list, `[]`, is a no-op");
            find(out,path,ln,l,"W23","\\+\\+\\s*\\[\\s*]","Concatenation with the empty list, `[]`, is a no-op");
            Matcher km=Pattern.compile("^\\s*([A-Za-z_][\\w'-]*)\\.([A-Za-z_][\\w'-]*)\\s*=").matcher(l);
            if(km.find()) keys.computeIfAbsent(km.group(1),k->new ArrayList<>()).add(new Diag("W20",path,ln,km.start(1)+1,"",l));
        }
        for (var e:keys.entrySet()) if(e.getValue().size()>=3) {
            List<Diag> v=e.getValue();
            v.get(0).msg="The key `"+e.getKey()+"` is first assigned here ...";
            v.get(1).msg="... repeated here ...";
            v.get(2).msg="... and here. Try `"+e.getKey()+" = { a=...; b=...; c=...; }` instead.";
            out.add(v.get(0)); out.add(v.get(1)); out.add(v.get(2));
        }
        out.sort(Comparator.<Diag>comparingInt(d->d.line).thenComparingInt(d->d.col).thenComparing(d->d.code));
        return out;
    }

    static void find(List<Diag> out,String path,int ln,String l,String code,String re,String msg){
        Matcher m=Pattern.compile(re).matcher(l);
        while(m.find()) out.add(new Diag(code,path,ln,m.start()+1,msg,l));
    }
    static boolean unbalanced(String s){ int b=0,c=0; for(char ch:s.toCharArray()){ if(ch=='{')b++; if(ch=='}')b--; if(ch=='(')c++; if(ch==')')c--; } return b>0||c>0; }
    static String firstLine(String s){ int n=s.indexOf('\n'); return n<0?s:s.substring(0,n); }
    static String errfmt(Diag d){ return d.path+">"+d.line+":"+d.col+":"+(d.code.startsWith("E")?"E:0":"W:"+Integer.parseInt(d.code.substring(1)))+":"+d.msg; }
    static String pretty(Diag d) {
        return "["+d.code+"] Warning: "+TITLES.getOrDefault(d.code,"Syntax error")+"\n   ,-["+d.path+":"+d.line+":"+d.col+"]\n   |\n "+d.line+" | "+d.lineText+"\n   = "+d.msg+"\n---'\n";
    }

    static String fix(String s) {
        String r=s;
        r=r.replaceAll("\\b([A-Za-z_][\\w'-]*)\\s*=\\s*\\1\\s*;","inherit $1;");
        r=r.replaceAll("\\b([A-Za-z_][\\w'-]*)\\s*=\\s*([A-Za-z_][\\w'-]*)\\.\\1\\s*;","inherit ($2) $1;");
        r=r.replaceAll("([^\\s;(){}]+)\\s*==\\s*true","$1");
        r=r.replaceAll("([^\\s;(){}]+)\\s*!=\\s*false","$1");
        r=r.replaceAll("([^\\s;(){}]+)\\s*==\\s*false","!$1");
        r=r.replaceAll("([^\\s;(){}]+)\\s*!=\\s*true","!$1");
        r=r.replaceAll("\\blet\\s+in\\s+","");
        r=r.replaceAll("\\blet\\s+([^;]+;\\s*)in\\s+let\\s+","let $1 ");
        r=r.replaceAll("\\(([A-Za-z_][\\w'-]*)\\s*:\\s*([A-Za-z_][\\w'-.]*)\\s+\\1\\)","$2");
        r=r.replaceAll("=\\s*\\(([^()]+)\\)\\s*;","= $1;");
        r=r.replaceAll("\\b([A-Za-z_][\\w'-]*)\\s*@\\s*\\{\\s*\\.\\.\\.\\s*}\\s*:","$1:");
        r=r.replaceAll("\\{\\s*\\.\\.\\.\\s*}\\s*:","_:");
        r=r.replaceAll("(?<![\"])(\\b[A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+#~:-]+)","\"$1\"");
        r=r.replaceAll("(?m)^[ \\t]*inherit\\s*;[ \\t]*\\n?","");
        r=r.replaceAll("!\\s*\\(\\s*([^()]+?)\\s*==\\s*([^()]+?)\\s*\\)","$1 != $2");
        r=r.replaceAll("if\\s+([A-Za-z_][\\w'-]*)\\s*\\?\\s*([A-Za-z_][\\w'-]*)\\s+then\\s+\\1\\.\\2\\s+else\\s+([^;\\n]+)","$1.$2 or ($3)");
        r=r.replaceAll("\\[\\s*]\\s*\\+\\+\\s*","");
        r=r.replaceAll("\\s*\\+\\+\\s*\\[\\s*]","");
        return r;
    }

    static String diff(String path, String a, String b) {
        String[] old=a.split("\n",-1), neu=b.split("\n",-1);
        if(old.length>0 && old[old.length-1].isEmpty()) old=Arrays.copyOf(old,old.length-1);
        if(neu.length>0 && neu[neu.length-1].isEmpty()) neu=Arrays.copyOf(neu,neu.length-1);
        StringBuilder sb=new StringBuilder();
        sb.append("--- ").append(path).append("\n+++ ").append(path).append(" [fixed]\n");
        sb.append("@@ -1,").append(Math.max(1,old.length)).append(" +1,").append(Math.max(1,neu.length)).append(" @@\n");
        for(String l:old) sb.append("-").append(l).append("\n");
        if(!a.endsWith("\n")) sb.append("\\ No newline at end of file\n");
        for(String l:neu) sb.append("+").append(l).append("\n");
        if(!b.endsWith("\n")) sb.append("\\ No newline at end of file\n");
        return sb.toString();
    }

    static void help() {
        System.out.println(VERSION+"\n\nAkshay <nerdy@peppe.rs>\n\nLints and suggestions for the Nix programming language\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nOPTIONS:\n    -h, --help       Print help information\n    -V, --version    Print version information\n\nSUBCOMMANDS:\n    check      Lints and suggestions for the nix programming language\n    dump       Dump a sample config to stdout\n    explain    Print detailed explanation for a lint warning\n    fix        Find and fix issues raised by statix-check\n    help       Print this message or the help of the given subcommand(s)\n    list       List all available lints\n    single     Fix exactly one issue at provided position");
    }
    static int subHelp(String s) {
        if (s.equals("check")) System.out.println("executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run check on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files");
        else if (s.equals("fix")) System.out.println("executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run fix on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run               Do not fix files in place, display a diff instead\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files");
        else if (s.equals("single")) System.out.println("executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]\n\nARGS:\n    <TARGET>    File to run single-fix on\n\nOPTIONS:\n    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run                Do not fix files in place, display a diff instead\n    -h, --help                   Print help information\n    -p, --position <POSITION>    Position to attempt a fix at\n    -s, --stdin                  Enable \"streaming\" mode, accept file on stdin, output diagnostics\n                                 on stdout");
        else if (s.equals("dump")) System.out.println("executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information");
        else if (s.equals("explain")) System.out.println("executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information");
        else if (s.equals("list")) System.out.println("executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information");
        else help();
        return 0;
    }
}
