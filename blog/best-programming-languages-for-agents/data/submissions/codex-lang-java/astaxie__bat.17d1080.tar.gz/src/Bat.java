import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.*;

public class Bat {
    static final String VERSION = "0.1.0";
    static final String HELP = "bat is a Go implemented CLI cURL-like tool for humans.\n\n" +
            "Usage:\n\n\tbat [flags] [METHOD] URL [ITEM [ITEM]]\n\n" +
            "flags:\n" +
            "  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument\n" +
            "  -b, -bench=false            Sends bench requests to URL\n" +
            "  -b.N=1000                   Number of requests to run\n" +
            "  -b.C=100                    Number of requests to run concurrently\n" +
            "  -body=\"\"                    Send RAW data as body\n" +
            "  -f, -form=false             Submitting the data as a form\n" +
            "  -j, -json=true              Send the data in a JSON object\n" +
            "  -p, -pretty=true            Print Json Pretty Format\n" +
            "  -i, -insecure=false         Allow connections to SSL sites without certs\n" +
            "  -proxy=PROXY_URL            Proxy with host and port\n" +
            "  -print=\"A\"                  String specifying what the output should contain, default will print all information\n" +
            "         \"H\" request headers\n" +
            "         \"B\" request body\n" +
            "         \"h\" response headers\n" +
            "         \"b\" response body\n" +
            "  -v, -version=true           Show Version Number\n\n" +
            "METHOD:\n  bat defaults to either GET (if there is no request data) or POST (with request data).\n\n" +
            "URL:\n  The only information needed to perform a request is a URL. The default scheme is http://,\n" +
            "  which can be omitted from the argument; example.org works just fine.\n\n" +
            "ITEM:\n  Can be any of:\n" +
            "    Query string   key=value\n" +
            "    Header         key:value\n" +
            "    Post data      key=value\n" +
            "    File upload    key@/path/file\n\n" +
            "Example:\n\n\tbat beego.me\n\n" +
            "more help information please refer to https://github.com/astaxie/bat\n";

    static class Opts {
        String auth, body = "", proxy = null, print = "A";
        boolean form = false, pretty = true, insecure = false, bench = false, version = false;
        int benchN = 1000, benchC = 100;
        List<String> args = new ArrayList<>();
    }
    static class ReqSpec {
        String method, url, body = "";
        Map<String,String> headers = new LinkedHashMap<>();
    }

    public static void main(String[] argv) {
        try {
            Opts o = parse(argv);
            if (o.version) { System.out.println("Version: " + VERSION); System.exit(2); }
            if (o.args.isEmpty()) { System.out.print(HELP + "\n"); System.exit(2); }
            ReqSpec r = buildSpec(o);
            if (o.bench) bench(o, r); else {
                Response resp = execute(o, r);
                printResponse(o, resp);
            }
        } catch (FlagException e) {
            System.err.println(e.getMessage());
            System.out.print(HELP + "\n");
            System.exit(2);
        } catch (Exception e) {
            logError(e);
            System.exit(1);
        }
    }

    static class FlagException extends Exception { FlagException(String m){super(m);} }

    static Opts parse(String[] argv) throws FlagException {
        Opts o = new Opts();
        for (int i=0;i<argv.length;i++) {
            String a = argv[i];
            if (!a.startsWith("-") || a.equals("-")) { o.args.add(a); continue; }
            String raw = a.startsWith("--") ? a.substring(2) : a.substring(1);
            String name, val = null;
            int eq = raw.indexOf('=');
            if (eq >= 0) { name = raw.substring(0, eq); val = raw.substring(eq+1); }
            else name = raw;
            switch (name) {
                case "h": case "help": System.out.print(HELP + "\n"); System.exit(2); break;
                case "v": case "version": o.version = boolVal(val, true); break;
                case "a": case "auth": if (val == null) val = next(argv, ++i, name); o.auth = val; break;
                case "f": case "form": o.form = boolVal(val, true); break;
                case "p": case "pretty": o.pretty = boolVal(val, true); break;
                case "i": case "insecure": o.insecure = boolVal(val, true); break;
                case "b": case "bench": o.bench = boolVal(val, true); break;
                case "b.N": if (val == null) val = next(argv, ++i, name); o.benchN = Integer.parseInt(val); break;
                case "b.C": if (val == null) val = next(argv, ++i, name); o.benchC = Integer.parseInt(val); break;
                case "body": if (val == null) val = next(argv, ++i, name); o.body = val; break;
                case "json": boolVal(val, true); break;
                case "proxy": if (val == null) val = next(argv, ++i, name); o.proxy = val; break;
                case "print": if (val == null) val = next(argv, ++i, name); o.print = val; break;
                case "download": boolVal(val, true); break;
                default: throw new FlagException("flag provided but not defined: -" + name);
            }
        }
        return o;
    }
    static String next(String[] a, int i, String n) throws FlagException { if (i>=a.length) throw new FlagException("flag needs an argument: -"+n); return a[i]; }
    static boolean boolVal(String v, boolean def) { if (v == null) return def; return v.equalsIgnoreCase("true") || v.equals("1"); }

    static ReqSpec buildSpec(Opts o) throws Exception {
        int idx = 0; String method = null;
        if (!o.args.isEmpty() && o.args.get(0).matches("[A-Z]+")) method = o.args.get(idx++);
        if (idx >= o.args.size()) throw new Exception("missing URL");
        String url = o.args.get(idx++);
        List<String> items = o.args.subList(idx, o.args.size());
        if (method == null) method = (!items.isEmpty() || !o.body.isEmpty()) ? "POST" : "GET";
        ReqSpec r = new ReqSpec(); r.method = titleMethod(method); r.headers.put("Accept", "application/json"); r.headers.put("User-Agent", "bat/0.1.0"); r.headers.put("Accept-Encoding", "gzip, deflate");
        if (o.auth != null) r.headers.put("Authorization", "Basic " + Base64.getEncoder().encodeToString(o.auth.getBytes(StandardCharsets.UTF_8)));
        Map<String,String> data = new TreeMap<>();
        Map<String,String> query = new LinkedHashMap<>();
        for (String it: items) {
            int colon = it.indexOf(':'); int eq = it.indexOf('='); int at = it.indexOf('@');
            if (colon >= 0 && (eq < 0 || colon < eq)) { r.headers.put(it.substring(0, colon), it.substring(colon+1)); }
            else if (at > 0 && (eq < 0 || at < eq)) { /* original ignores file uploads in observed modes */ }
            else if (eq >= 0) {
                String k = it.substring(0, eq), v = it.substring(eq+1);
                if (r.method.equals("GET")) query.put(k, v); else data.put(k, v);
            }
        }
        r.url = normalizeUrl(url);
        if (!query.isEmpty()) r.url = appendQuery(r.url, query);
        if (!o.body.isEmpty()) r.body = o.body;
        else if (!data.isEmpty()) {
            if (o.form) { r.body = formEncode(data); r.headers.put("Content-Type", "application/x-www-form-urlencoded"); }
            else { r.body = jsonEncode(data) + "\n"; r.headers.put("Content-Type", "application/json"); }
        }
        return r;
    }
    static String titleMethod(String m){ return m.substring(0,1).toUpperCase()+m.substring(1).toLowerCase(); }
    static String normalizeUrl(String u){ return u.contains("://") ? u : "http://" + u; }
    static String appendQuery(String u, Map<String,String> q) throws Exception { String sep = u.contains("?") ? "&" : "?"; StringBuilder sb = new StringBuilder(u).append(sep); boolean first=true; for(var e:q.entrySet()){ if(!first)sb.append('&'); first=false; sb.append(enc(e.getKey())).append('=').append(enc(e.getValue())); } return sb.toString(); }
    static String enc(String s) throws Exception { return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20"); }
    static String formEncode(Map<String,String> m) throws Exception { StringBuilder sb=new StringBuilder(); boolean f=true; for(var e:m.entrySet()){ if(!f)sb.append('&'); f=false; sb.append(enc(e.getKey())).append('=').append(enc(e.getValue())); } return sb.toString(); }
    static String jsonEncode(Map<String,String> m){ StringBuilder sb=new StringBuilder("{"); boolean f=true; for(var e:m.entrySet()){ if(!f)sb.append(','); f=false; sb.append(jsonStr(e.getKey())).append(':').append(jsonStr(e.getValue())); } return sb.append('}').toString(); }
    static String jsonStr(String s){ StringBuilder b=new StringBuilder("\""); for(char c:s.toCharArray()){ switch(c){case '\\':b.append("\\\\");break;case '"':b.append("\\\"");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default: if(c<32)b.append(String.format("\\u%04x",(int)c)); else b.append(c);} } return b.append('"').toString(); }

    static class Response { int code; Map<String,List<String>> headers; byte[] body; }
    static Response execute(Opts o, ReqSpec r) throws Exception {
        URL url = URI.create(r.url).toURL();
        URLConnection raw;
        if (o.proxy != null && !o.proxy.isEmpty()) {
            URI pu = URI.create(normalizeUrl(o.proxy));
            raw = url.openConnection(new Proxy(Proxy.Type.HTTP, new InetSocketAddress(pu.getHost(), pu.getPort())));
        } else raw = url.openConnection();
        if (o.insecure && raw instanceof HttpsURLConnection) {
            ((HttpsURLConnection) raw).setSSLSocketFactory(insecureContext().getSocketFactory());
            ((HttpsURLConnection) raw).setHostnameVerifier((h, sess) -> true);
        }
        HttpURLConnection c = (HttpURLConnection) raw;
        c.setInstanceFollowRedirects(true);
        c.setConnectTimeout(30000);
        c.setReadTimeout(60000);
        c.setRequestMethod(r.method.toUpperCase());
        for (var e : r.headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        if (!r.body.isEmpty()) {
            c.setDoOutput(true);
            byte[] out = r.body.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(out.length);
            try (OutputStream os = c.getOutputStream()) { os.write(out); }
        }
        Response resp = new Response();
        resp.code = c.getResponseCode();
        resp.headers = new LinkedHashMap<>();
        for (var e : c.getHeaderFields().entrySet()) if (e.getKey() != null) resp.headers.put(e.getKey().toLowerCase(Locale.ROOT), e.getValue());
        InputStream is;
        try { is = c.getInputStream(); } catch (IOException ex) { is = c.getErrorStream(); }
        byte[] body = is == null ? new byte[0] : is.readAllBytes();
        resp.body = decodeBody(resp.headers, body);
        c.disconnect();
        return resp;
    }
    static byte[] decodeBody(Map<String,List<String>> h, byte[] b) throws IOException { String ce=h.getOrDefault("content-encoding", List.of("")).stream().findFirst().orElse(""); if(ce.toLowerCase().contains("gzip")){try(GZIPInputStream g=new GZIPInputStream(new ByteArrayInputStream(b))){return g.readAllBytes();}} return b; }
    static SSLContext insecureContext() throws Exception { TrustManager[] t={new X509TrustManager(){public void checkClientTrusted(X509Certificate[] c,String a){} public void checkServerTrusted(X509Certificate[] c,String a){} public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}}}; SSLContext sc=SSLContext.getInstance("TLS"); sc.init(null,t,new SecureRandom()); return sc; }

    static void printResponse(Opts o, Response resp) {
        String s = new String(resp.body, StandardCharsets.UTF_8);
        if (o.pretty) s = prettyJsonOrOriginal(s);
        System.out.println();
        System.out.print(s);
    }
    static void logError(Exception e) { System.err.println(new java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSSSSS").format(new Date()) + " bat.go:215: can't get the url " + e.getMessage()); }

    static void bench(Opts o, ReqSpec r) throws Exception {
        int n=Math.max(0,o.benchN), c=Math.max(1,o.benchC); ExecutorService ex=Executors.newFixedThreadPool(c); List<Future<long[]>> fs=new ArrayList<>(); long start=System.nanoTime();
        for(int i=0;i<n;i++) fs.add(ex.submit(()->{long a=System.nanoTime(); Response resp=execute(o,r); long d=System.nanoTime()-a; return new long[]{d, resp.code, resp.body.length};}));
        Map<Long,Integer> codes=new TreeMap<>(); long totalBytes=0, slow=0, fast=Long.MAX_VALUE; List<Long> durs=new ArrayList<>();
        for(Future<long[]> f:fs){ long[] x=f.get(); durs.add(x[0]); slow=Math.max(slow,x[0]); fast=Math.min(fast,x[0]); totalBytes+=x[2]; codes.put(x[1],codes.getOrDefault(x[1],0)+1); }
        ex.shutdown(); long total=System.nanoTime()-start; if(n==0) fast=0; double ts=total/1e9;
        System.out.println(); System.out.println("Summary:");
        System.out.printf(Locale.US,"  Total:\t%.4f secs.%n",ts); System.out.printf(Locale.US,"  Slowest:\t%.4f secs.%n",slow/1e9); System.out.printf(Locale.US,"  Fastest:\t%.4f secs.%n",fast/1e9); System.out.printf(Locale.US,"  Average:\t%.4f secs.%n",n==0?0:(durs.stream().mapToDouble(x->x/1e9).sum()/n)); System.out.printf(Locale.US,"  Requests/sec:\t%.4f%n",n/(ts==0?1:ts)); System.out.println("  Total Data Received:\t"+totalBytes+" bytes."); System.out.println("  Response Size per Request:\t"+(n==0?0:totalBytes/n)+" bytes.");
        System.out.println(); System.out.println("Status code distribution:"); for(var e:codes.entrySet()) System.out.println("  ["+e.getKey()+"]\t"+e.getValue()+" responses");
    }

    static String prettyJsonOrOriginal(String s){ try { Parser p=new Parser(s); Object v=p.parse(); p.skip(); if(p.i!=p.s.length()) return s; StringBuilder b=new StringBuilder(); writeJson(v,b,0); return b.toString(); } catch(Exception e){ return s; } }
    static void writeJson(Object v,StringBuilder b,int ind){ if(v instanceof Map){ b.append("{\n"); int i=0,sz=((Map<?,?>)v).size(); for(var e:((Map<?,?>)v).entrySet()){ spaces(b,ind+2); b.append(jsonStr((String)e.getKey())).append(": "); writeJson(e.getValue(),b,ind+2); if(++i<sz)b.append(','); b.append('\n'); } spaces(b,ind); b.append('}'); } else if(v instanceof List){ b.append("[\n"); List<?> l=(List<?>)v; for(int i=0;i<l.size();i++){ spaces(b,ind+2); writeJson(l.get(i),b,ind+2); if(i+1<l.size())b.append(','); b.append('\n'); } spaces(b,ind); b.append(']'); } else if(v instanceof String) b.append(jsonStr((String)v)); else b.append(String.valueOf(v)); }
    static void spaces(StringBuilder b,int n){ for(int i=0;i<n;i++)b.append(' '); }
    static class Parser{ String s; int i; Parser(String s){this.s=s.trim();} void skip(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;} Object parse(){skip(); char c=s.charAt(i); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='"')return str(); if(s.startsWith("true",i)){i+=4;return true;} if(s.startsWith("false",i)){i+=5;return false;} if(s.startsWith("null",i)){i+=4;return null;} return num();} Object obj(){i++; Map<String,Object> m=new LinkedHashMap<>(); skip(); if(s.charAt(i)=='}'){i++;return m;} while(true){skip(); String k=str(); skip(); i++; Object v=parse(); m.put(k,v); skip(); if(s.charAt(i)=='}'){i++;return m;} i++;}} Object arr(){i++; List<Object> l=new ArrayList<>(); skip(); if(s.charAt(i)==']'){i++;return l;} while(true){l.add(parse()); skip(); if(s.charAt(i)==']'){i++;return l;} i++;}} String str(){StringBuilder b=new StringBuilder(); i++; while(true){char c=s.charAt(i++); if(c=='"')return b.toString(); if(c=='\\'){char e=s.charAt(i++); switch(e){case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'u':b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;break;default:b.append(e);} } else b.append(c);} } Object num(){int st=i; while(i<s.length()&&"-+0123456789.eE".indexOf(s.charAt(i))>=0)i++; return s.substring(st,i);}}
}
