import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.*;

public class ReviveClone {
    static final String VERSION = "a75b67b";
    static final String COMMIT = "a75b67b73b9edb91dfc9f302dd108fa9d3ea5b05";
    static final List<String> DEFAULT_RULES = Arrays.asList(
            "blank-imports", "context-as-argument", "dot-imports", "error-return",
            "error-strings", "error-naming", "exported", "if-return",
            "increment-decrement", "var-declaration", "var-naming",
            "package-comments", "range", "receiver-naming", "time-naming",
            "unexported-return", "indent-error-flow", "errorf", "empty-block",
            "superfluous-else", "unused-parameter", "unreachable-code",
            "redefines-builtin-id");

    static class Options {
        String config = null;
        String formatter = "default";
        boolean setExitStatus = false;
        int maxOpenFiles = 0;
        List<String> excludes = new ArrayList<>();
        List<String> packages = new ArrayList<>();
    }

    static class Config {
        String severity = "warning";
        double confidence = 0.8;
        int errorCode = 0;
        int warningCode = 0;
        Set<String> rules = new LinkedHashSet<>();
    }

    static class Pos {
        String file;
        int line, col, offset, endOffset, endLine, endCol;
    }

    static class Failure {
        String severity, msg, rule, category;
        double confidence;
        Pos pos;
    }

    static class Source {
        Path path;
        String display;
        String text;
        String[] lines;
        int[] offsets;
    }

    public static void main(String[] args) {
        int code = new ReviveClone().run(args);
        System.exit(code);
    }

    int run(String[] args) {
        Options opt = new Options();
        try {
            if (!parseArgs(args, opt)) return 0;
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            printHelp(System.err);
            return 2;
        }

        Config cfg;
        try {
            cfg = loadConfig(opt.config);
        } catch (IOException e) {
            System.out.println("cannot read the config file: " + e.getMessage());
            return 1;
        }

        if (cfg.rules.contains("var-naming")) {
            System.out.println("initializing revive - getting lint rules: cannot configure rule: \"var-naming\": load std packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: ");
            return 1;
        }

        List<Path> files;
        try {
            files = collectFiles(opt.packages, opt.excludes);
        } catch (IOException e) {
            System.out.println(e.getMessage());
            return 1;
        }

        List<Failure> all = new ArrayList<>();
        for (Path p : files) {
            try {
                Source s = readSource(p);
                all.addAll(lint(s, cfg));
            } catch (IOException ignored) {
            }
        }
        print(all, opt.formatter);
        if (opt.setExitStatus && !all.isEmpty()) return 1;
        if (!all.isEmpty()) return cfg.warningCode;
        return 0;
    }

    boolean parseArgs(String[] args, Options opt) {
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-h") || a.equals("-help")) {
                printHelp(System.out);
                return false;
            } else if (a.equals("-version") || a.equals("--version")) {
                System.out.println("Version:\t" + VERSION);
                System.out.println("Commit:\t\t" + COMMIT);
                System.out.println("Built\t\t2026-04-17 19:59 UTC by build.sh");
                return false;
            } else if (a.equals("-set_exit_status")) {
                opt.setExitStatus = true;
            } else if (a.startsWith("-config=")) {
                opt.config = a.substring(8);
            } else if (a.equals("-config")) {
                if (++i >= args.length) throw new IllegalArgumentException("flag needs an argument: -config");
                opt.config = args[i];
            } else if (a.startsWith("-formatter=")) {
                opt.formatter = a.substring(11);
            } else if (a.equals("-formatter")) {
                if (++i >= args.length) throw new IllegalArgumentException("flag needs an argument: -formatter");
                opt.formatter = args[i];
            } else if (a.startsWith("-exclude=")) {
                opt.excludes.add(a.substring(9));
            } else if (a.equals("-exclude")) {
                if (++i >= args.length) throw new IllegalArgumentException("flag needs an argument: -exclude");
                opt.excludes.add(args[i]);
            } else if (a.startsWith("-max_open_files=")) {
                opt.maxOpenFiles = parseInt(a.substring(16), "-max_open_files");
            } else if (a.equals("-max_open_files")) {
                if (++i >= args.length) throw new IllegalArgumentException("flag needs an argument: -max_open_files");
                opt.maxOpenFiles = parseInt(args[i], "-max_open_files");
            } else if (a.startsWith("-")) {
                throw new IllegalArgumentException("flag provided but not defined: " + a);
            } else {
                opt.packages.add(a);
            }
        }
        if (opt.packages.isEmpty()) opt.packages.add(".");
        return true;
    }

    int parseInt(String v, String name) {
        try { return Integer.parseInt(v); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("invalid value \"" + v + "\" for flag " + name + ": parse error"); }
    }

    void printHelp(PrintStream out) {
        out.println();
        out.println(" _ __ _____   _(_)__  _____");
        out.println("| '__/ _ \\ \\ / / \\ \\ / / _ \\");
        out.println("| | |  __/\\ V /| |\\ V /  __/");
        out.println("|_|  \\___| \\_/ |_| \\_/ \\___|");
        out.println();
        out.println("Example:");
        out.println("  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...");
        out.println();
        out.println("Usage of ./executable:");
        out.println("  -config string");
        out.println("    \tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)");
        out.println("  -exclude value");
        out.println("    \tlist of globs which specify files to be excluded (i.e. -exclude foo/...)");
        out.println("  -formatter string");
        out.println("    \tformatter to be used for the output (i.e. -formatter stylish)");
        out.println("  -max_open_files int");
        out.println("    \tmaximum number of open files at the same time");
        out.println("  -set_exit_status");
        out.println("    \tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config");
        out.println("  -version");
        out.println("    \tget revive version");
    }

    Config loadConfig(String path) throws IOException {
        Config c = new Config();
        Path p = null;
        if (path != null && !path.isEmpty()) p = Paths.get(path);
        else {
            String xdg = System.getenv("XDG_CONFIG_HOME");
            if (xdg != null && Files.exists(Paths.get(xdg, "revive.toml"))) p = Paths.get(xdg, "revive.toml");
            else {
                String home = System.getenv("HOME");
                if (home != null && Files.exists(Paths.get(home, "revive.toml"))) p = Paths.get(home, "revive.toml");
            }
        }
        if (p == null) {
            c.rules.addAll(DEFAULT_RULES);
            return c;
        }
        String currentRule = null;
        for (String raw : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            String line = stripComment(raw).trim();
            if (line.isEmpty()) continue;
            Matcher rm = Pattern.compile("\\[rule\\.([^\\]]+)\\]").matcher(line);
            if (rm.find()) {
                currentRule = rm.group(1).trim();
                c.rules.add(currentRule);
                continue;
            }
            if (line.startsWith("severity")) c.severity = unquote(value(line));
            else if (line.startsWith("confidence")) {
                try { c.confidence = Double.parseDouble(value(line)); } catch (Exception ignored) {}
            } else if (line.startsWith("errorCode")) c.errorCode = parseTomlInt(value(line), 0);
            else if (line.startsWith("warningCode")) c.warningCode = parseTomlInt(value(line), 0);
            else if (currentRule != null && line.toLowerCase(Locale.ROOT).startsWith("disabled") && value(line).equalsIgnoreCase("true")) {
                c.rules.remove(currentRule);
            }
        }
        return c;
    }

    String stripComment(String s) {
        boolean in = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '"' && (i == 0 || s.charAt(i - 1) != '\\')) in = !in;
            if (ch == '#' && !in) return s.substring(0, i);
        }
        return s;
    }
    String value(String line) {
        int idx = line.indexOf('=');
        return idx >= 0 ? line.substring(idx + 1).trim() : "";
    }
    String unquote(String v) {
        v = v.trim();
        if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) return v.substring(1, v.length() - 1);
        return v;
    }
    int parseTomlInt(String v, int d) {
        try { return Integer.parseInt(v.trim()); } catch (Exception e) { return d; }
    }

    List<Path> collectFiles(List<String> args, List<String> excludes) throws IOException {
        LinkedHashSet<Path> out = new LinkedHashSet<>();
        for (String a : args) {
            String clean = a;
            boolean recursive = false;
            if (clean.endsWith("/...")) {
                recursive = true;
                clean = clean.substring(0, clean.length() - 4);
                if (clean.isEmpty()) clean = ".";
            }
            Path p = Paths.get(clean);
            if (Files.isRegularFile(p) && p.toString().endsWith(".go")) out.add(p.normalize());
            else if (Files.isDirectory(p)) {
                if (recursive) {
                    Files.walkFileTree(p, new SimpleFileVisitor<Path>() {
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                            if (file.toString().endsWith(".go")) out.add(file.normalize());
                            return FileVisitResult.CONTINUE;
                        }
                    });
                } else {
                    try (DirectoryStream<Path> ds = Files.newDirectoryStream(p, "*.go")) {
                        for (Path f : ds) out.add(f.normalize());
                    }
                }
            }
        }
        List<Path> files = new ArrayList<>();
        for (Path p : out) if (!excluded(p, excludes)) files.add(p);
        files.sort(Comparator.comparing(Path::toString));
        return files;
    }

    boolean excluded(Path p, List<String> excludes) {
        String s = p.toString().replace('\\', '/');
        for (String e : excludes) {
            String x = e.replace('\\', '/');
            if (x.endsWith("/...")) {
                String pref = x.substring(0, x.length() - 4);
                if (s.startsWith(pref)) return true;
            } else if (s.equals(x) || s.endsWith("/" + x)) return true;
            else {
                String regex = x.replace(".", "\\.").replace("*", "[^/]*");
                if (s.matches(regex)) return true;
            }
        }
        return false;
    }

    Source readSource(Path p) throws IOException {
        Source s = new Source();
        s.path = p;
        s.display = p.toString().replace('\\', '/');
        s.text = Files.readString(p, StandardCharsets.UTF_8);
        s.lines = s.text.split("\\R", -1);
        s.offsets = new int[s.lines.length];
        int off = 0;
        for (int i = 0; i < s.lines.length; i++) {
            s.offsets[i] = off;
            off += s.lines[i].length() + 1;
        }
        return s;
    }

    List<Failure> lint(Source s, Config c) {
        List<Failure> fs = new ArrayList<>();
        if (c.rules.contains("package-comments")) packageComments(s, c, fs);
        if (c.rules.contains("exported")) exported(s, c, fs);
        if (c.rules.contains("error-strings")) errorStrings(s, c, fs);
        if (c.rules.contains("increment-decrement")) incDec(s, c, fs);
        if (c.rules.contains("var-declaration")) varDecl(s, c, fs);
        if (c.rules.contains("indent-error-flow")) indentErrorFlow(s, c, fs);
        if (c.rules.contains("superfluous-else")) superfluousElse(s, c, fs);
        if (c.rules.contains("unreachable-code")) unreachable(s, c, fs);
        if (c.rules.contains("empty-block")) emptyBlock(s, c, fs);
        if (c.rules.contains("error-naming")) errorNaming(s, c, fs);
        if (c.rules.contains("dot-imports") || c.rules.contains("blank-imports")) imports(s, c, fs);
        if (c.rules.contains("if-return")) ifReturn(s, c, fs);
        return fs;
    }

    void packageComments(Source s, Config c, List<Failure> fs) {
        for (int i = 0; i < s.lines.length; i++) {
            String t = s.lines[i].trim();
            if (t.isEmpty() || t.startsWith("//go:") || t.startsWith("/*")) continue;
            if (t.startsWith("package ")) {
                boolean ok = i > 0 && s.lines[i - 1].trim().startsWith("// Package ");
                if (!ok) add(fs, s, c, "package-comments", "comments", "should have a package comment", i + 1, 1, 1, 1);
                return;
            }
        }
    }

    void exported(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("^\\s*(func|type|var|const)\\s+(?:\\([^)]*\\)\\s*)?([A-Z][A-Za-z0-9_]*)");
        for (int i = 0; i < s.lines.length; i++) {
            Matcher m = p.matcher(s.lines[i]);
            if (m.find()) {
                String kind = m.group(1), name = m.group(2);
                if (name.equals("main")) continue;
                if (!hasDoc(s, i, name)) {
                    String word = kind.equals("func") ? "function" : kind;
                    add(fs, s, c, "exported", "comments", "exported " + word + " " + name + " should have comment or be unexported", i + 1, firstNonWs(s.lines[i]), 1, 1);
                }
            }
        }
    }

    boolean hasDoc(Source s, int line, String name) {
        int j = line - 1;
        while (j >= 0 && s.lines[j].trim().isEmpty()) j--;
        if (j < 0) return false;
        String t = s.lines[j].trim();
        return t.startsWith("// " + name + " ") || t.equals("// " + name) || t.startsWith("/* " + name + " ") || t.startsWith("/** " + name + " ");
    }

    void errorStrings(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("(errors\\.New|fmt\\.Errorf)\\s*\\(\\s*\"((?:\\\\.|[^\"])*)\"");
        for (int i = 0; i < s.lines.length; i++) {
            Matcher m = p.matcher(s.lines[i]);
            while (m.find()) {
                String str = m.group(2);
                if (!str.isEmpty()) {
                    char first = str.charAt(0), last = str.charAt(str.length() - 1);
                    if (Character.isUpperCase(first) || ".:!?\n".indexOf(last) >= 0) {
                        add(fs, s, c, "error-strings", "errors", "error strings should not be capitalized or end with punctuation or a newline", i + 1, m.start(2), 0.8, 1);
                    }
                }
            }
        }
    }

    void incDec(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("\\b([A-Za-z_][A-Za-z0-9_]*)\\s*([+\\-])=\\s*1\\b");
        for (int i = 0; i < s.lines.length; i++) {
            Matcher m = p.matcher(s.lines[i]);
            while (m.find()) add(fs, s, c, "increment-decrement", "unary-op", "should replace " + m.group(1) + " " + m.group(2) + "= 1 with " + m.group(1) + m.group(2) + m.group(2), i + 1, m.start() + 1, 0.8, 1);
        }
    }

    void varDecl(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("\\bvar\\s+([A-Za-z_][A-Za-z0-9_]*)\\s+(string|int|bool|float64|float32|byte|rune)\\s*=");
        for (int i = 0; i < s.lines.length; i++) {
            Matcher m = p.matcher(s.lines[i]);
            while (m.find()) add(fs, s, c, "var-declaration", "type-inference", "should omit type " + m.group(2) + " from declaration of var " + m.group(1) + "; it will be inferred from the right-hand side", i + 1, m.start(2) + 1, 0.8, 1);
        }
    }

    void indentErrorFlow(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("}\\s*else\\s*\\{");
        for (int i = 1; i < s.lines.length; i++) {
            if (p.matcher(s.lines[i]).find() && s.lines[i - 1].trim().startsWith("return"))
                add(fs, s, c, "indent-error-flow", "", "if block ends with a return statement, so drop this else and outdent its block", i + 1, Math.max(1, s.lines[i].indexOf("else") + 1), 1, 1);
        }
    }

    void superfluousElse(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("}\\s*else\\s*\\{");
        for (int i = 1; i < s.lines.length; i++) {
            if (!c.rules.contains("indent-error-flow") && p.matcher(s.lines[i]).find() && (s.lines[i - 1].trim().startsWith("return") || s.lines[i - 1].trim().startsWith("break") || s.lines[i - 1].trim().startsWith("continue")))
                add(fs, s, c, "superfluous-else", "logic", "if block ends with a return statement, so drop this else and outdent its block", i + 1, Math.max(1, s.lines[i].indexOf("else") + 1), 1, 1);
        }
    }

    void unreachable(Source s, Config c, List<Failure> fs) {
        for (int i = 0; i < s.lines.length; i++) {
            String t = s.lines[i].trim();
            if (t.matches("^(return|panic\\(|break\\b|continue\\b).*")) {
                for (int j = i + 1; j < s.lines.length; j++) {
                    String u = s.lines[j].trim();
                    if (u.isEmpty() || u.startsWith("//")) continue;
                    if (!u.startsWith("}")) add(fs, s, c, "unreachable-code", "logic", "unreachable code after this statement", i + 1, firstNonWs(s.lines[i]), 1, 1);
                    break;
                }
            }
        }
    }

    void emptyBlock(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("\\{\\s*}");
        for (int i = 0; i < s.lines.length; i++) {
            Matcher m = p.matcher(s.lines[i]);
            if (m.find() && !s.lines[i].contains("struct{}") && !s.lines[i].matches("^\\s*func\\b.*\\{\\s*}\\s*$"))
                add(fs, s, c, "empty-block", "logic", "this block is empty, you can remove it", i + 1, m.start() + 1, 0.8, 1);
        }
    }

    void errorNaming(Source s, Config c, List<Failure> fs) {
        Pattern p = Pattern.compile("\\bvar\\s+([A-Z][A-Za-z0-9_]*)\\s*=\\s*errors\\.New");
        for (int i = 0; i < s.lines.length; i++) {
            Matcher m = p.matcher(s.lines[i]);
            if (m.find() && !m.group(1).startsWith("Err"))
                add(fs, s, c, "error-naming", "naming", "error var " + m.group(1) + " should have name of the form ErrFoo", i + 1, m.start(1) + 1, 0.8, 1);
        }
    }

    void imports(Source s, Config c, List<Failure> fs) {
        for (int i = 0; i < s.lines.length; i++) {
            String t = s.lines[i].trim();
            if (t.startsWith(". ") && c.rules.contains("dot-imports"))
                add(fs, s, c, "dot-imports", "imports", "should not use dot imports", i + 1, firstNonWs(s.lines[i]), 0.8, 1);
            if (t.startsWith("_ ") && c.rules.contains("blank-imports"))
                add(fs, s, c, "blank-imports", "imports", "a blank import should be only in a main or test package, or have a comment justifying it", i + 1, firstNonWs(s.lines[i]), 0.8, 1);
        }
    }

    void ifReturn(Source s, Config c, List<Failure> fs) {
        for (int i = 0; i + 2 < s.lines.length; i++) {
            if (s.lines[i].trim().startsWith("if ") && s.lines[i + 1].trim().startsWith("return true") && s.lines[i + 2].trim().startsWith("return false"))
                add(fs, s, c, "if-return", "logic", "redundant if ...; err != nil check, just return error instead.", i + 1, firstNonWs(s.lines[i]), 0.8, 1);
        }
    }

    int count(String s, char ch) {
        int n = 0; for (int i = 0; i < s.length(); i++) if (s.charAt(i) == ch) n++; return n;
    }
    int firstNonWs(String s) {
        for (int i = 0; i < s.length(); i++) if (!Character.isWhitespace(s.charAt(i))) return i + 1;
        return 1;
    }

    void add(List<Failure> fs, Source s, Config c, String rule, String cat, String msg, int line, int col, double conf, int len) {
        Failure f = new Failure();
        f.severity = c.severity;
        f.msg = msg;
        f.rule = rule;
        f.category = cat;
        f.confidence = conf;
        f.pos = new Pos();
        f.pos.file = s.display;
        f.pos.line = Math.max(1, line);
        f.pos.col = Math.max(1, col);
        int lidx = Math.min(s.lines.length - 1, Math.max(0, f.pos.line - 1));
        f.pos.offset = s.offsets[lidx] + f.pos.col - 1;
        f.pos.endLine = f.pos.line;
        f.pos.endCol = Math.min(s.lines[lidx].length() + 1, f.pos.col + Math.max(1, len));
        f.pos.endOffset = s.offsets[lidx] + f.pos.endCol - 1;
        fs.add(f);
    }

    void print(List<Failure> fs, String fmt) {
        switch (fmt) {
            case "json": printJson(fs); break;
            case "ndjson": for (Failure f : fs) System.out.println(jsonFailure(f)); break;
            case "plain": for (Failure f : fs) System.out.printf("%s:%d:%d: %s https://revive.run/r#%s%n", f.pos.file, f.pos.line, f.pos.col, f.msg, f.rule); if (!fs.isEmpty()) System.out.println(); break;
            case "unix": for (Failure f : fs) System.out.printf("%s:%d:%d: [%s] %s%n", f.pos.file, f.pos.line, f.pos.col, f.rule, f.msg); if (!fs.isEmpty()) System.out.println(); break;
            case "friendly": printFriendly(fs); break;
            case "stylish": printStylish(fs); break;
            case "checkstyle": printCheckstyle(fs); break;
            case "sarif": printSarif(fs); break;
            default: for (Failure f : fs) System.out.printf("%s:%d:%d: %s%n", f.pos.file, f.pos.line, f.pos.col, f.msg);
        }
    }

    void printJson(List<Failure> fs) {
        System.out.print("[");
        for (int i = 0; i < fs.size(); i++) {
            if (i > 0) System.out.print(",");
            System.out.print(jsonFailure(fs.get(i)));
        }
        System.out.println("]");
    }
    String jsonFailure(Failure f) {
        return "{\"Severity\":\"" + esc(f.severity) + "\",\"Failure\":\"" + esc(f.msg) + "\",\"RuleName\":\"" + esc(f.rule) + "\",\"Category\":\"" + esc(f.category) + "\",\"Position\":{\"Start\":{\"Filename\":\"" + esc(f.pos.file) + "\",\"Offset\":" + f.pos.offset + ",\"Line\":" + f.pos.line + ",\"Column\":" + f.pos.col + "},\"End\":{\"Filename\":\"" + esc(f.pos.file) + "\",\"Offset\":" + f.pos.endOffset + ",\"Line\":" + f.pos.endLine + ",\"Column\":" + f.pos.endCol + "}},\"Confidence\":" + conf(f.confidence) + ",\"ReplacementLine\":\"\"}";
    }
    String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
    String xml(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
    }
    String conf(double d) { return d == Math.rint(d) ? String.valueOf((int)d) : String.valueOf(d); }

    void printFriendly(List<Failure> fs) {
        for (Failure f : fs) {
            System.out.printf("  ⚠  https://revive.run/r#%s  %s%n  %s:%d:%d%n%n", f.rule, f.msg, f.pos.file, f.pos.line, f.pos.col);
        }
        if (!fs.isEmpty()) {
            System.out.printf("⚠ %d problems (0 errors, %d warnings)%n%nWarnings:%n", fs.size(), fs.size());
            Map<String,Integer> counts = new LinkedHashMap<>();
            for (Failure f : fs) counts.put(f.rule, counts.getOrDefault(f.rule, 0) + 1);
            for (Map.Entry<String,Integer> e : counts.entrySet()) System.out.printf("  %d  %s%n", e.getValue(), e.getKey());
            System.out.println();
        }
    }
    void printStylish(List<Failure> fs) {
        Map<String,List<Failure>> by = new LinkedHashMap<>();
        for (Failure f : fs) by.computeIfAbsent(f.pos.file, k -> new ArrayList<>()).add(f);
        for (Map.Entry<String,List<Failure>> e : by.entrySet()) {
            System.out.println(e.getKey());
            for (Failure f : e.getValue()) System.out.printf("  (%d, %d)  https://revive.run/r#%-20s %s%n", f.pos.line, f.pos.col, f.rule, f.msg);
            System.out.println();
        }
        if (!fs.isEmpty()) System.out.printf("%n ✖ %d problems (0 errors) (%d warnings)%n", fs.size(), fs.size());
    }
    void printCheckstyle(List<Failure> fs) {
        System.out.println("<?xml version='1.0' encoding='UTF-8'?>");
        System.out.println("<checkstyle version=\"5.0\">");
        Map<String,List<Failure>> by = new LinkedHashMap<>();
        for (Failure f : fs) by.computeIfAbsent(f.pos.file, k -> new ArrayList<>()).add(f);
        for (Map.Entry<String,List<Failure>> e : by.entrySet()) {
            System.out.println("    <file name=\"" + xml(e.getKey()) + "\">");
            for (Failure f : e.getValue()) System.out.printf("      <error line=\"%d\" column=\"%d\" message=\"%s (confidence %s)\" severity=\"%s\" source=\"revive/%s\"/>%n", f.pos.line, f.pos.col, xml(f.msg), conf(f.confidence), xml(f.severity), xml(f.rule));
            System.out.println("    </file>");
        }
        System.out.println("</checkstyle>");
    }
    void printSarif(List<Failure> fs) {
        System.out.println("{");
        System.out.println("  \"runs\": [");
        System.out.println("    {");
        System.out.println("      \"results\": [");
        for (int i = 0; i < fs.size(); i++) {
            Failure f = fs.get(i);
            System.out.println("        {\"level\":\"" + esc(f.severity) + "\",\"locations\":[{\"physicalLocation\":{\"artifactLocation\":{\"uri\":\"" + esc(f.pos.file) + "\"},\"region\":{\"startColumn\":" + f.pos.col + ",\"startLine\":" + f.pos.line + "}}}],\"message\":{\"text\":\"" + esc(f.msg) + "\"},\"ruleId\":\"" + esc(f.rule) + "\"}" + (i + 1 < fs.size() ? "," : ""));
        }
        System.out.println("      ],");
        System.out.println("      \"tool\": {\"driver\": {\"informationUri\": \"https://revive.run\", \"name\": \"revive\", \"rules\": []}}");
        System.out.println("    }");
        System.out.println("  ],");
        System.out.println("  \"version\": \"2.1.0\"");
        System.out.println("}");
    }
}
