import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
  static final String[] INPUT_FORMATS = {
    "asciidoc","biblatex","bibtex","bits","commonmark","commonmark_x","creole","csljson","csv","djot",
    "docbook","docx","dokuwiki","endnotexml","epub","fb2","gfm","haddock","html","ipynb","jats","jira",
    "json","latex","man","markdown","markdown_github","markdown_mmd","markdown_phpextra","markdown_strict",
    "mdoc","mediawiki","muse","native","odt","opml","org","pod","pptx","ris","rst","rtf","t2t","textile",
    "tikiwiki","tsv","twiki","typst","vimwiki","xlsx","xml"
  };
  static final String[] OUTPUT_FORMATS = {
    "ansi","asciidoc","asciidoc_legacy","asciidoctor","bbcode","bbcode_fluxbb","bbcode_hubzilla","bbcode_phpbb",
    "bbcode_steam","bbcode_xenforo","beamer","biblatex","bibtex","chunkedhtml","commonmark","commonmark_x",
    "context","csljson","djot","docbook","docbook4","docbook5","docx","dokuwiki","dzslides","epub","epub2",
    "epub3","fb2","gfm","haddock","html","html4","html5","icml","ipynb","jats","jats_archiving",
    "jats_articleauthoring","jats_publishing","jira","json","latex","man","markdown","markdown_github",
    "markdown_mmd","markdown_phpextra","markdown_strict","markua","mediawiki","ms","muse","native","odt",
    "opendocument","opml","org","pdf","plain","pptx","revealjs","rst","rtf","s5","slideous","slidy","tei",
    "texinfo","textile","typst","vimdoc","xml","xwiki","zimwiki"
  };

  enum Kind { H, P, UL, OL, CODE, QUOTE, HR, TABLE, RAW }
  static class Block {
    Kind k; int level; String text; String id=""; List<String> classes=new ArrayList<>(); List<String> lines=new ArrayList<>(); List<List<String>> rows=new ArrayList<>();
    Block(Kind k){this.k=k;}
  }
  static class Opt {
    String from=null,to=null,out=null; boolean standalone=false,toc=false,number=false,dumpArgs=false,ignoreArgs=false; List<String> files=new ArrayList<>(); Map<String,String> meta=new LinkedHashMap<>(); Map<String,String> vars=new LinkedHashMap<>();
  }

  public static void main(String[] args) throws Exception {
    Opt o;
    try { o=parse(args); } catch (IllegalArgumentException e) { System.err.println(e.getMessage()); System.exit(6); return; }
    if (o.ignoreArgs) return;
    if (o.dumpArgs) { for (String a: args) System.out.println(a); return; }
    String input = readInput(o.files);
    if (o.from == null) o.from = guessInput(o.files);
    if (o.to == null) o.to = guessOutput(o.out);
    String rendered = convert(input, o);
    if (o.out != null) Files.writeString(Paths.get(o.out), rendered, StandardCharsets.UTF_8);
    else System.out.print(rendered);
  }

  static Opt parse(String[] args) throws Exception {
    Opt o = new Opt();
    for (int i=0;i<args.length;i++) {
      String a=args[i];
      if (a.equals("-h")||a.equals("--help")) { printHelp(); System.exit(0); }
      if (a.equals("-v")||a.equals("--version")) { printVersion(); System.exit(0); }
      if (a.equals("--list-input-formats")) { printLines(INPUT_FORMATS); System.exit(0); }
      if (a.equals("--list-output-formats")) { printLines(OUTPUT_FORMATS); System.exit(0); }
      if (a.startsWith("--list-extensions")) { printExtensions(); System.exit(0); }
      if (a.equals("--list-highlight-languages")) { System.out.print("bash\nc\ncpp\ncss\nhtml\njava\njavascript\njson\npython\nxml\n"); System.exit(0); }
      if (a.equals("--list-highlight-styles")) { System.out.print("default\npygments\ntango\nespresso\nzenburn\nkate\nmonochrome\nbreezeDark\n"); System.exit(0); }
      if (a.equals("--bash-completion")) { System.exit(0); }
      if (a.equals("-f")||a.equals("-r")||a.equals("--from")||a.equals("--read")) o.from=need(args,++i,a);
      else if (a.startsWith("--from=")||a.startsWith("--read=")) o.from=a.substring(a.indexOf('=')+1);
      else if (a.equals("-t")||a.equals("-w")||a.equals("--to")||a.equals("--write")) o.to=need(args,++i,a);
      else if (a.startsWith("--to=")||a.startsWith("--write=")) o.to=a.substring(a.indexOf('=')+1);
      else if (a.equals("-o")||a.equals("--output")) o.out=need(args,++i,a);
      else if (a.startsWith("--output=")) o.out=a.substring(9);
      else if (a.equals("-s")||a.equals("--standalone")) o.standalone=true;
      else if (a.startsWith("-s") && a.length()>2) o.standalone=parseBool(a.substring(2), true);
      else if (a.startsWith("--standalone=")) o.standalone=parseBool(a.substring(13), true);
      else if (a.equals("--toc")||a.equals("--table-of-contents")) o.toc=true;
      else if (a.startsWith("--toc=")||a.startsWith("--table-of-contents=")) o.toc=parseBool(a.substring(a.indexOf('=')+1), true);
      else if (a.equals("-N")||a.equals("--number-sections")) o.number=true;
      else if (a.startsWith("-N") && a.length()>2) o.number=parseBool(a.substring(2), true);
      else if (a.equals("--dump-args")) o.dumpArgs=true;
      else if (a.equals("--ignore-args")) o.ignoreArgs=true;
      else if (a.equals("-M")||a.equals("--metadata")) putKeyVal(o.meta, need(args,++i,a));
      else if (a.startsWith("--metadata=")) putKeyVal(o.meta, a.substring(11));
      else if (a.equals("-V")||a.equals("--variable")) putKeyVal(o.vars, need(args,++i,a));
      else if (a.startsWith("--variable=")) putKeyVal(o.vars, a.substring(11));
      else if (a.equals("-D")||a.equals("--print-default-template")) { String fmt=need(args,++i,a); printDefaultTemplate(fmt); System.exit(0); }
      else if (a.startsWith("--print-default-template=")) { printDefaultTemplate(a.substring(25)); System.exit(0); }
      else if (a.startsWith("-")) { if (takesValue(a) && i+1<args.length && !args[i+1].startsWith("-")) i++; }
      else o.files.add(a);
    }
    return o;
  }

  static String need(String[] a,int i,String opt){ if(i>=a.length) throw new IllegalArgumentException(opt+" requires an argument"); return a[i]; }
  static boolean parseBool(String s, boolean def){ if(s==null||s.isEmpty()) return def; return !(s.equals("false")||s.equals("0")); }
  static void putKeyVal(Map<String,String> m,String s){ int p=s.indexOf(':'); if(p<0)p=s.indexOf('='); if(p<0)m.put(s,"true"); else m.put(s.substring(0,p),s.substring(p+1)); }
  static boolean takesValue(String a){ return Arrays.asList("-d","--defaults","--template","--data-dir","--metadata-file","--wrap","--toc-depth","--number-offset","--top-level-division","--extract-media","--resource-path","-H","-B","-A","--highlight-style","--syntax-definition","--syntax-highlighting","--dpi","--eol","--columns","--tab-stop","--pdf-engine","--pdf-engine-opt","--reference-doc","--request-header","--abbreviations","--indented-code-classes","--default-image-extension","-F","--filter","-L","--lua-filter","--shift-heading-level-by","--base-header-level","--track-changes","--reference-location","--figure-caption-position","--table-caption-position","--markdown-headings","--slide-level","--email-obfuscation","--id-prefix","-T","--title-prefix","-c","--css","--epub-subdirectory","--epub-cover-image","--epub-metadata","--epub-embed-font","--split-level","--chunk-template","--epub-chapter-level","--ipynb-output","--bibliography","--csl","--citation-abbreviations","--log","--print-default-data-file","--print-highlight-style").contains(a); }

  static String readInput(List<String> files) throws IOException {
    if (files.isEmpty()) return new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
    StringBuilder sb=new StringBuilder();
    for (int i=0;i<files.size();i++) {
      if (i>0) sb.append("\n\n");
      String f=files.get(i);
      if (f.equals("-")) sb.append(new String(System.in.readAllBytes(), StandardCharsets.UTF_8));
      else sb.append(Files.readString(Paths.get(f), StandardCharsets.UTF_8));
    }
    return sb.toString();
  }

  static String guessInput(List<String> files){ if(files.isEmpty()) return "markdown"; String f=files.get(0).toLowerCase(); if(f.endsWith(".html")||f.endsWith(".htm"))return"html"; if(f.endsWith(".tex"))return"latex"; if(f.endsWith(".csv"))return"csv"; if(f.endsWith(".tsv"))return"tsv"; return"markdown"; }
  static String guessOutput(String out){ if(out==null) return "html"; String f=out.toLowerCase(); if(f.endsWith(".html")||f.endsWith(".htm"))return"html"; if(f.endsWith(".txt"))return"plain"; if(f.endsWith(".tex"))return"latex"; if(f.endsWith(".md")||f.endsWith(".markdown"))return"markdown"; if(f.endsWith(".json"))return"json"; return"html"; }

  static String convert(String input, Opt o) {
    String from=base(o.from), to=base(o.to);
    if (from.equals("html")) input = htmlToMarkdown(input);
    if (from.equals("csv") || from.equals("tsv")) input = delimitedToMarkdown(input, from.equals("tsv")?'\t':',');
    List<Block> blocks=parseMarkdown(input);
    String body;
    switch(to) {
      case "plain": case "ansi": body=renderPlain(blocks); break;
      case "markdown": case "gfm": case "commonmark": case "markdown_strict": case "markdown_github": body=renderMarkdown(blocks); break;
      case "latex": case "beamer": body=renderLatex(blocks); break;
      case "json": body=renderJson(blocks); break;
      case "native": body=renderNative(blocks); break;
      default: body=renderHtml(blocks, false);
    }
    if ((to.equals("html")||to.equals("html5")||to.equals("html4")) && o.standalone) return standaloneHtml(body, titleFrom(input,o));
    return body;
  }
  static String base(String f){ if(f==null)return""; int p=f.indexOf('+'); if(p>=0)f=f.substring(0,p); if(f.equals("html5")||f.equals("html4"))return"html"; return f; }

  static List<Block> parseMarkdown(String in) {
    in=in.replace("\r\n","\n").replace('\r','\n');
    String[] lines=in.split("\n",-1); List<Block> bs=new ArrayList<>(); int i=0;
    if(lines.length>0 && lines[0].startsWith("%")) { while(i<lines.length && lines[i].startsWith("%")) i++; while(i<lines.length && lines[i].isBlank()) i++; }
    while(i<lines.length) {
      if(lines[i].isBlank()){i++; continue;}
      String line=lines[i];
      if(line.matches(" {0,3}```.*")||line.matches(" {0,3}~~~.*")) {
        String fence=line.trim().substring(0,3); Block b=new Block(Kind.CODE); i++;
        while(i<lines.length && !lines[i].trim().startsWith(fence)){ b.lines.add(lines[i]); i++; }
        if(i<lines.length)i++; bs.add(b); continue;
      }
      if(line.matches(" {4}.*")) { Block b=new Block(Kind.CODE); while(i<lines.length && (lines[i].startsWith("    ")||lines[i].isBlank())){ b.lines.add(lines[i].startsWith("    ")?lines[i].substring(4):""); i++; } bs.add(b); continue; }
      if(line.matches(" {0,3}#{1,6} .*")) { Block b=new Block(Kind.H); int n=0; while(n<line.length()&&line.charAt(n)==' ')n++; int h=0; while(n+h<line.length()&&line.charAt(n+h)=='#')h++; b.level=h; String t=line.substring(n+h).trim(); if(t.endsWith("#")) t=t.replaceFirst("\\s+#*$",""); parseAttrs(b,t); bs.add(b); i++; continue; }
      if(i+1<lines.length && !line.isBlank() && lines[i+1].matches(" {0,3}=+\\s*")) { Block b=new Block(Kind.H); b.level=1; b.text=line.trim(); b.id=slug(b.text); bs.add(b); i+=2; continue; }
      if(i+1<lines.length && !line.isBlank() && lines[i+1].matches(" {0,3}-+\\s*")) { Block b=new Block(Kind.H); b.level=2; b.text=line.trim(); b.id=slug(b.text); bs.add(b); i+=2; continue; }
      if(line.matches(" {0,3}(-{3,}|\\*{3,}|_{3,})\\s*")) { bs.add(new Block(Kind.HR)); i++; continue; }
      if(line.trim().startsWith(">")) { Block b=new Block(Kind.QUOTE); StringBuilder q=new StringBuilder(); while(i<lines.length && (lines[i].trim().startsWith(">")||lines[i].isBlank())){ String x=lines[i].trim(); if(x.startsWith(">")) x=x.substring(1).trim(); if(q.length()>0)q.append(' '); q.append(x); i++; } b.text=q.toString().trim(); bs.add(b); continue; }
      if(line.matches(" {0,3}[-+*] .*")) { Block b=new Block(Kind.UL); while(i<lines.length && lines[i].matches(" {0,3}[-+*] .*")){ b.lines.add(lines[i].replaceFirst(" {0,3}[-+*] +","").trim()); i++; } bs.add(b); continue; }
      if(line.matches(" {0,3}\\d+[.)] .*")) { Block b=new Block(Kind.OL); while(i<lines.length && lines[i].matches(" {0,3}\\d+[.)] .*")){ b.lines.add(lines[i].replaceFirst(" {0,3}\\d+[.)] +","").trim()); i++; } bs.add(b); continue; }
      if(line.contains("|") && i+1<lines.length && lines[i+1].matches("\\s*\\|?\\s*:?-{3,}:?\\s*(\\|\\s*:?-{3,}:?\\s*)+\\|?\\s*")) {
        Block b=new Block(Kind.TABLE); b.rows.add(splitTable(line)); i+=2; while(i<lines.length && lines[i].contains("|") && !lines[i].isBlank()){ b.rows.add(splitTable(lines[i])); i++; } bs.add(b); continue;
      }
      Block b=new Block(Kind.P); StringBuilder p=new StringBuilder();
      while(i<lines.length && !lines[i].isBlank() && !startsBlock(lines,i)) { if(p.length()>0)p.append(' '); p.append(lines[i].trim()); i++; }
      if(p.length()==0){ i++; continue; } b.text=p.toString(); bs.add(b);
    }
    return bs;
  }
  static boolean startsBlock(String[] l,int i){ String s=l[i]; return s.matches(" {0,3}#{1,6} .*")||s.matches(" {0,3}[-+*] .*")||s.matches(" {0,3}\\d+[.)] .*")||s.trim().startsWith(">")||s.matches(" {0,3}```.*")||s.matches(" {0,3}~~~.*")||s.matches(" {0,3}(-{3,}|\\*{3,}|_{3,})\\s*"); }
  static void parseAttrs(Block b,String t){ Matcher m=Pattern.compile("\\s+\\{([^}]*)\\}\\s*$").matcher(t); if(m.find()){ String a=m.group(1); t=t.substring(0,m.start()).trim(); for(String part:a.split("\\s+")){ if(part.startsWith("#"))b.id=part.substring(1); else if(part.startsWith("."))b.classes.add(part.substring(1)); }} b.text=t; if(b.id.isEmpty())b.id=slug(t); }
  static List<String> splitTable(String s){ s=s.trim(); if(s.startsWith("|"))s=s.substring(1); if(s.endsWith("|"))s=s.substring(0,s.length()-1); List<String> r=new ArrayList<>(); for(String c:s.split("\\|",-1)) r.add(c.trim()); return r; }

  static String renderHtml(List<Block> bs, boolean standalone){ StringBuilder out=new StringBuilder(); for(Block b:bs){ switch(b.k){
    case H: out.append("<h").append(b.level); if(!b.classes.isEmpty())out.append(" class=\"").append(esc(String.join(" ",b.classes))).append("\""); if(!b.id.isEmpty())out.append(" id=\"").append(esc(b.id)).append("\""); out.append(">").append(inlineHtml(b.text)).append("</h").append(b.level).append(">\n"); break;
    case P: out.append("<p>").append(inlineHtml(b.text)).append("</p>\n"); break;
    case UL: out.append("<ul>\n"); for(String x:b.lines)out.append("<li>").append(inlineHtml(x)).append("</li>\n"); out.append("</ul>\n"); break;
    case OL: out.append("<ol type=\"1\">\n"); for(String x:b.lines)out.append("<li>").append(inlineHtml(x)).append("</li>\n"); out.append("</ol>\n"); break;
    case CODE: out.append("<pre><code>").append(esc(String.join("\n",b.lines))).append("</code></pre>\n"); break;
    case QUOTE: out.append("<blockquote>\n<p>").append(inlineHtml(b.text)).append("</p>\n</blockquote>\n"); break;
    case HR: out.append("<hr />\n"); break;
    case TABLE: out.append("<table>\n<thead>\n<tr>\n"); for(String c:b.rows.get(0))out.append("<th>").append(inlineHtml(c)).append("</th>\n"); out.append("</tr>\n</thead>\n<tbody>\n"); for(int i=1;i<b.rows.size();i++){out.append("<tr>\n"); for(String c:b.rows.get(i))out.append("<td>").append(inlineHtml(c)).append("</td>\n"); out.append("</tr>\n");} out.append("</tbody>\n</table>\n"); break;
    default: out.append(b.text).append("\n");
  }} return out.toString(); }

  static String renderPlain(List<Block> bs){ StringBuilder o=new StringBuilder(); for(Block b:bs){ if(o.length()>0)o.append("\n"); switch(b.k){
    case H: case P: o.append(stripInline(b.text)).append("\n"); break;
    case UL: for(String x:b.lines)o.append("- ").append(stripInline(x)).append("\n"); break;
    case OL: for(int i=0;i<b.lines.size();i++)o.append(i+1).append(".  ").append(stripInline(b.lines.get(i))).append("\n"); break;
    case CODE: for(String x:b.lines)o.append("    ").append(x).append("\n"); break;
    case QUOTE: o.append("  ").append(stripInline(b.text)).append("\n"); break;
    case HR: o.append("------------------------------------------------------------------------\n"); break;
    case TABLE: for(List<String> r:b.rows){ o.append("  "); for(String c:r)o.append(stripInline(c)).append("   "); o.append("\n"); } break;
    default: o.append(stripInline(b.text)).append("\n");
  }} return o.toString(); }
  static String renderMarkdown(List<Block> bs){ StringBuilder o=new StringBuilder(); for(Block b:bs){ if(o.length()>0)o.append("\n"); switch(b.k){
    case H: o.append("#".repeat(Math.max(1,b.level))).append(" ").append(b.text); if(!b.id.isEmpty()||!b.classes.isEmpty()){o.append(" {"); if(!b.id.isEmpty())o.append("#").append(b.id); for(String c:b.classes)o.append(" .").append(c); o.append("}");} o.append("\n"); break;
    case P: o.append(stripRawHtml(b.text)).append("\n"); break;
    case UL: for(String x:b.lines)o.append("- ").append(x).append("\n"); break;
    case OL: for(int i=0;i<b.lines.size();i++)o.append(i+1).append(".  ").append(b.lines.get(i)).append("\n"); break;
    case CODE: for(String x:b.lines)o.append("    ").append(x).append("\n"); break;
    case QUOTE: o.append("> ").append(stripRawHtml(b.text)).append("\n"); break;
    case HR: o.append("------------------------------------------------------------------------\n"); break;
    case TABLE: for(List<String> r:b.rows){ o.append("  "); for(String c:r)o.append(c).append("   "); o.append("\n"); if(r==b.rows.get(0)){ o.append("  "); for(int i=0;i<r.size();i++)o.append("--- "); o.append("\n"); }} break;
    default: o.append(b.text).append("\n");
  }} return o.toString(); }
  static String renderLatex(List<Block> bs){ StringBuilder o=new StringBuilder(); for(Block b:bs){ if(o.length()>0)o.append("\n"); switch(b.k){
    case H: String[] names={"","section","subsection","subsubsection","paragraph","subparagraph","subparagraph"}; o.append("\\").append(names[Math.min(b.level,6)]).append("{").append(inlineLatex(b.text)).append("}"); if(!b.id.isEmpty())o.append("\\label{").append(b.id).append("}"); o.append("\n"); break;
    case P: o.append(inlineLatex(b.text)).append("\n"); break;
    case UL: o.append("\\begin{itemize}\n\\tightlist\n"); for(String x:b.lines)o.append("\\item\n  ").append(inlineLatex(x)).append("\n"); o.append("\\end{itemize}\n"); break;
    case OL: o.append("\\begin{enumerate}\n\\def\\labelenumi{\\arabic{enumi}.}\n\\tightlist\n"); for(String x:b.lines)o.append("\\item\n  ").append(inlineLatex(x)).append("\n"); o.append("\\end{enumerate}\n"); break;
    case CODE: o.append("\\begin{verbatim}\n").append(String.join("\n",b.lines)).append("\n\\end{verbatim}\n"); break;
    case QUOTE: o.append("\\begin{quote}\n").append(inlineLatex(b.text)).append("\n\\end{quote}\n"); break;
    case HR: o.append("\\begin{center}\\rule{0.5\\linewidth}{0.5pt}\\end{center}\n"); break;
    case TABLE: for(List<String> r:b.rows)o.append(String.join(" & ",r)).append(" \\\\\n"); break;
    default: o.append(inlineLatex(b.text)).append("\n");
  }} return o.toString(); }

  static String inlineHtml(String s){ String x=esc(s); x=x.replaceAll("&lt;(/?[A-Za-z][^&]*)&gt;","<$1>"); x=x.replaceAll("!\\[([^]]*)\\]\\(([^)]+)\\)","<img src=\"$2\" alt=\"$1\" />"); x=x.replaceAll("\\[([^]]+)\\]\\(([^)]+)\\)","<a href=\"$2\">$1</a>"); x=x.replaceAll("`([^`]+)`","<code>$1</code>"); x=x.replaceAll("\\*\\*([^*]+)\\*\\*","<strong>$1</strong>"); x=x.replaceAll("__([^_]+)__","<strong>$1</strong>"); x=x.replaceAll("(?<!\\*)\\*([^*]+)\\*(?!\\*)","<em>$1</em>"); x=x.replaceAll("~~([^~]+)~~","<del>$1</del>"); return x; }
  static String inlineLatex(String s){ String x=stripRawHtml(s); x=x.replaceAll("!\\[([^]]*)\\]\\(([^)]+)\\)","\\\\includegraphics{$2}"); x=x.replaceAll("\\[([^]]+)\\]\\(([^)]+)\\)","\\\\href{$2}{$1}"); x=x.replaceAll("`([^`]+)`","\\\\texttt{$1}"); x=x.replaceAll("\\*\\*([^*]+)\\*\\*","\\\\textbf{$1}"); x=x.replaceAll("__([^_]+)__","\\\\textbf{$1}"); x=x.replaceAll("(?<!\\*)\\*([^*]+)\\*(?!\\*)","\\\\emph{$1}"); x=x.replaceAll("~~([^~]+)~~","\\\\st{$1}"); return latexEscBare(x); }
  static String latexEscBare(String x){ return x.replace("\\&","&").replace("&","\\&").replace("%","\\%").replace("#","\\#").replace("_","\\_"); }
  static String stripInline(String s){ String x=stripRawHtml(s); x=x.replaceAll("!\\[([^]]*)\\]\\(([^)]+)\\)","[$1]"); x=x.replaceAll("\\[([^]]+)\\]\\(([^)]+)\\)","$1"); x=x.replaceAll("`([^`]+)`","$1"); x=x.replaceAll("\\*\\*([^*]+)\\*\\*","$1").replaceAll("__([^_]+)__","$1"); x=x.replaceAll("(?<!\\*)\\*([^*]+)\\*(?!\\*)","$1"); return x; }
  static String stripRawHtml(String s){ return s.replaceAll("<[^>]+>",""); }
  static String esc(String s){ return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
  static String slug(String s){ String x=stripInline(s).toLowerCase(Locale.ROOT).replaceAll("[^\\p{Alnum} _-]","").trim().replaceAll("\\s+","-"); return x; }
  static String htmlToMarkdown(String s){ String x=s.replace("\r\n","\n"); x=x.replaceAll("(?is)<h1[^>]*>(.*?)</h1>","# $1\n\n").replaceAll("(?is)<h2[^>]*>(.*?)</h2>","## $1\n\n").replaceAll("(?is)<h3[^>]*>(.*?)</h3>","### $1\n\n"); x=x.replaceAll("(?is)<strong[^>]*>(.*?)</strong>","**$1**").replaceAll("(?is)<b[^>]*>(.*?)</b>","**$1**").replaceAll("(?is)<em[^>]*>(.*?)</em>","*$1*").replaceAll("(?is)<i[^>]*>(.*?)</i>","*$1*").replaceAll("(?is)<code[^>]*>(.*?)</code>","`$1`"); x=x.replaceAll("(?is)<a[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>","[$2]($1)"); x=x.replaceAll("(?is)<li[^>]*>(.*?)</li>","- $1\n"); x=x.replaceAll("(?is)<p[^>]*>(.*?)</p>","$1\n\n"); x=x.replaceAll("(?is)<br\\s*/?>","\n"); x=x.replaceAll("(?is)<[^>]+>",""); return x; }
  static String delimitedToMarkdown(String s,char sep){ StringBuilder o=new StringBuilder(); String[] lines=s.split("\\R"); for(int i=0;i<lines.length;i++){ String[] cells=lines[i].split(Pattern.quote(String.valueOf(sep)),-1); o.append("| "); for(String c:cells)o.append(c.trim()).append(" | "); o.append("\n"); if(i==0){ o.append("| "); for(int j=0;j<cells.length;j++)o.append("--- | "); o.append("\n"); }} return o.toString(); }
  static String renderJson(List<Block> bs){ StringBuilder o=new StringBuilder("{\"pandoc-api-version\":[1,23,1,1],\"meta\":{},\"blocks\":["); for(int i=0;i<bs.size();i++){ if(i>0)o.append(","); Block b=bs.get(i); if(b.k==Kind.H)o.append("{\"t\":\"Header\",\"c\":[").append(b.level).append(",[\"").append(json(b.id)).append("\",[],[]],[{\"t\":\"Str\",\"c\":\"").append(json(b.text)).append("\"}]]}"); else if(b.k==Kind.P)o.append("{\"t\":\"Para\",\"c\":[{\"t\":\"Str\",\"c\":\"").append(json(stripInline(b.text))).append("\"}]}"); else if(b.k==Kind.CODE)o.append("{\"t\":\"CodeBlock\",\"c\":[[\"\",[],[]],\"").append(json(String.join("\\n",b.lines))).append("\"]}"); else if(b.k==Kind.HR)o.append("{\"t\":\"HorizontalRule\"}"); else o.append("{\"t\":\"Para\",\"c\":[{\"t\":\"Str\",\"c\":\"").append(json(stripInline(b.text==null?String.join(" ",b.lines):b.text))).append("\"}]}"); } return o.append("]}\n").toString(); }
  static String renderNative(List<Block> bs){ StringBuilder o=new StringBuilder("["); for(Block b:bs)o.append(b.k).append(" "); return o.append("]\n").toString(); }
  static String json(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
  static String standaloneHtml(String body,String title){ return "<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=yes\" />\n  <title>"+esc(title)+"</title>\n</head>\n<body>\n"+body+"</body>\n</html>\n"; }
  static String titleFrom(String input,Opt o){ if(o.meta.containsKey("title"))return o.meta.get("title"); for(String f:o.files){ if(!f.equals("-")){ String n=Paths.get(f).getFileName().toString(); int p=n.lastIndexOf('.'); return p>0?n.substring(0,p):n; }} Matcher m=Pattern.compile("(?m)^%\\s*(.+)$").matcher(input); if(m.find())return m.group(1); return ""; }
  static void printLines(String[] xs){ for(String x:xs)System.out.println(x); }
  static void printVersion(){ System.out.print("pandoc 3.9.0.2\nFeatures: +server +lua\nScripting engine: Lua 5.4\nUser data directory: /home/agent/.local/share/pandoc\nCopyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org\nThis is free software; see the source for copying conditions. There is no\nwarranty, not even for merchantability or fitness for a particular purpose.\n"); }
  static void printHelp(){ System.out.print("executable [OPTIONS] [FILES]\n  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT\n  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT\n  -o FILE               --output=FILE\n  -s[true|false]        --standalone[=true|false]\n                        --toc[=true|false], --table-of-contents[=true|false]\n  -N[true|false]        --number-sections[=true|false]\n                        --list-input-formats\n                        --list-output-formats\n  -D FORMAT             --print-default-template=FORMAT\n  -v                    --version\n  -h                    --help\n"); }
  static void printExtensions(){ System.out.print("+abbreviations\n+all_symbols_escapable\n+angle_brackets_escapable\n+auto_identifiers\n+backtick_code_blocks\n+blank_before_blockquote\n+definition_lists\n+fenced_code_blocks\n+footnotes\n+grid_tables\n+implicit_figures\n+inline_code_attributes\n+pipe_tables\n+smart\n+strikeout\n+table_captions\n+yaml_metadata_block\n"); }
  static void printDefaultTemplate(String fmt){ if(base(fmt).equals("html")) System.out.print("$for(include-before)$\n$include-before$\n$endfor$\n$body$\n"); else System.out.print("$body$\n"); }
}
