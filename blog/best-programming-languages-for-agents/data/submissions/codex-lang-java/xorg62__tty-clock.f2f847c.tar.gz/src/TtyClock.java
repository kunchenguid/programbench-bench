import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.TextStyle;
import java.util.Locale;

public class TtyClock {
    private static final String ESC = "\033[";
    private static final String[] HELP = {
            "usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] ",
            "    -s            Show seconds                                   ",
            "    -S            Screensaver mode                               ",
            "    -x            Show box                                       ",
            "    -c            Set the clock at the center of the terminal    ",
            "    -C [0-7]      Set the clock color                            ",
            "    -b            Use bold colors                                ",
            "    -t            Set the hour in 12h format                     ",
            "    -u            Use UTC time                                   ",
            "    -T tty        Display the clock on the specified terminal    ",
            "    -r            Do rebound the clock                           ",
            "    -f format     Set the date format                            ",
            "    -n            Don't quit on keypress                         ",
            "    -v            Show tty-clock version                         ",
            "    -i            Show some info about tty-clock                 ",
            "    -h            Show this page                                 ",
            "    -D            Hide date                                      ",
            "    -B            Enable blinking colon                          ",
            "    -d delay      Set the delay between two redraws of the clock. Default 1s. ",
            "    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns."
    };

    private static final String[][] DIGITS = {
            {" #### ", "##  ##", "##  ##", "##  ##", " #### "},
            {"  ##  ", "####  ", "  ##  ", "  ##  ", "######"},
            {" #### ", "##  ##", "   ## ", "  ##  ", "######"},
            {" #### ", "    ##", "  ### ", "    ##", " #### "},
            {"##  ##", "##  ##", "######", "    ##", "    ##"},
            {"######", "##    ", "##### ", "    ##", "##### "},
            {" #### ", "##    ", "##### ", "##  ##", " #### "},
            {"######", "    ##", "   ## ", "  ##  ", "  ##  "},
            {" #### ", "##  ##", " #### ", "##  ##", " #### "},
            {" #### ", "##  ##", " #####", "    ##", " #### "}
    };

    private static class Options {
        boolean seconds;
        boolean screensaver;
        boolean box;
        boolean center;
        int color = 2;
        boolean bold;
        boolean twelve;
        boolean utc;
        boolean rebound;
        boolean noQuit;
        boolean hideDate;
        boolean blink;
        long delaySeconds = 1;
        long delayNanos = 0;
        String dateFormat = "%F";
    }

    public static void main(String[] args) throws Exception {
        Options opt = new Options();
        if (!parse(args, opt)) {
            return;
        }
        runClock(opt);
    }

    private static boolean parse(String[] args, Options opt) {
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (!arg.startsWith("-") || "-".equals(arg)) {
                continue;
            }
            if ("--help".equals(arg)) {
                System.err.println("./executable: invalid option -- '-'");
                usage();
                return false;
            }
            for (int j = 1; j < arg.length(); j++) {
                char c = arg.charAt(j);
                switch (c) {
                    case 's': opt.seconds = true; break;
                    case 'S': opt.screensaver = true; break;
                    case 'x': opt.box = true; break;
                    case 'c': opt.center = true; break;
                    case 'b': opt.bold = true; break;
                    case 't': opt.twelve = true; break;
                    case 'u': opt.utc = true; break;
                    case 'r': opt.rebound = true; break;
                    case 'n': opt.noQuit = true; break;
                    case 'D': opt.hideDate = true; break;
                    case 'B': opt.blink = true; break;
                    case 'v':
                        System.out.println("TTY-Clock 2 © devel version");
                        return false;
                    case 'i':
                        System.out.println("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)");
                        return false;
                    case 'h':
                        usage();
                        return false;
                    case 'C':
                    case 'T':
                    case 'f':
                    case 'd':
                    case 'a': {
                        String value;
                        if (j + 1 < arg.length()) {
                            value = arg.substring(j + 1);
                            j = arg.length();
                        } else {
                            if (i + 1 >= args.length) {
                                System.err.printf("./executable: option requires an argument -- '%c'%n", c);
                                usage();
                                return false;
                            }
                            value = args[++i];
                        }
                        if (c == 'C') {
                            opt.color = parseInt(value, 0);
                            if (opt.color < 0 || opt.color > 7) opt.color = 2;
                        } else if (c == 'T') {
                            if (!Files.exists(Path.of(value))) {
                                System.err.printf("tty-clock: error: couldn't stat '%s': No such file or directory.%n", value);
                                System.exit(1);
                            }
                        } else if (c == 'f') {
                            opt.dateFormat = value;
                        } else if (c == 'd') {
                            opt.delaySeconds = Math.max(0, parseLong(value, 1));
                        } else {
                            opt.delayNanos = Math.max(0, parseLong(value, 0));
                        }
                        j = arg.length();
                        break;
                    }
                    default:
                        System.err.printf("./executable: invalid option -- '%c'%n", c);
                        usage();
                        return false;
                }
            }
        }
        return true;
    }

    private static void usage() {
        for (String line : HELP) {
            System.out.println(line);
        }
    }

    private static int parseInt(String s, int fallback) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static long parseLong(String s, long fallback) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static void runClock(Options opt) throws Exception {
        int row = opt.center ? 7 : 2;
        int col = opt.center ? 12 : 2;
        int dy = 1;
        int dx = 1;
        long sleepMillis = opt.delaySeconds * 1000 + opt.delayNanos / 1_000_000;
        int sleepNanos = (int) (opt.delayNanos % 1_000_000);
        if (sleepMillis == 0 && sleepNanos == 0) {
            sleepMillis = 10;
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.print(ESC + "?25h" + ESC + "0m" + ESC + "?1049l");
            System.out.flush();
        }));
        System.out.print(ESC + "?1049h" + ESC + "?25l" + ESC + "H" + ESC + "2J");
        System.out.flush();

        int frame = 0;
        while (true) {
            LocalDateTime now = LocalDateTime.now(opt.utc ? ZoneId.of("UTC") : ZoneId.systemDefault());
            String time = timeString(now, opt);
            draw(row, col, time, now, opt, frame++);
            if (keyPressed()) {
                if (!opt.noQuit) {
                    break;
                }
                while (System.in.available() > 0) System.in.read();
            }
            if (opt.rebound && !opt.center) {
                row += dy;
                col += dx;
                int width = visualWidth(time);
                int height = opt.hideDate ? 5 : 7;
                if (row <= 1 || row + height >= 24) dy = -dy;
                if (col <= 1 || col + width >= 80) dx = -dx;
                row = Math.max(1, Math.min(row, 24 - height));
                col = Math.max(1, Math.min(col, 80 - width));
            }
            Thread.sleep(sleepMillis, sleepNanos);
        }
    }

    private static boolean keyPressed() throws IOException {
        return System.in.available() > 0;
    }

    private static String timeString(LocalDateTime now, Options opt) {
        int hour = now.getHour();
        if (opt.twelve) {
            hour %= 12;
            if (hour == 0) hour = 12;
        }
        if (opt.seconds) {
            return String.format(Locale.ROOT, "%02d:%02d:%02d", hour, now.getMinute(), now.getSecond());
        }
        return String.format(Locale.ROOT, "%02d:%02d", hour, now.getMinute());
    }

    private static void draw(int row, int col, String time, LocalDateTime now, Options opt, int frame) {
        int width = visualWidth(time);
        StringBuilder out = new StringBuilder();
        out.append(ESC).append("H").append(ESC).append("2J");
        if (opt.box) {
            drawBox(out, row - 1, col - 1, width + 2, opt.hideDate ? 7 : 9);
        }
        for (int line = 0; line < 5; line++) {
            out.append(cursor(row + line, col));
            for (int i = 0; i < time.length(); i++) {
                char ch = time.charAt(i);
                if (ch == ':') {
                    boolean show = !opt.blink || frame % 2 == 0;
                    out.append(show ? colon(line, opt) : "  ");
                } else {
                    out.append(renderDigit(ch - '0', line, opt));
                }
                out.append(' ');
            }
        }
        if (!opt.hideDate) {
            String date = strftime(opt.dateFormat, now);
            int dateCol = col + Math.max(0, (width - date.length()) / 2);
            out.append(cursor(row + 6, dateCol));
            out.append(fg(opt.color, opt.bold)).append(date).append(ESC).append("0m");
        }
        System.out.print(out);
        System.out.flush();
    }

    private static int visualWidth(String time) {
        int width = 0;
        for (int i = 0; i < time.length(); i++) {
            width += time.charAt(i) == ':' ? 2 : 6;
            width++;
        }
        return Math.max(0, width - 1);
    }

    private static String cursor(int r, int c) {
        return ESC + Math.max(1, r) + ";" + Math.max(1, c) + "H";
    }

    private static String renderDigit(int digit, int line, Options opt) {
        if (digit < 0 || digit > 9) return "      ";
        String pattern = DIGITS[digit][line];
        StringBuilder b = new StringBuilder();
        boolean on = false;
        for (int i = 0; i < pattern.length(); i++) {
            boolean next = pattern.charAt(i) == '#';
            if (next != on) {
                b.append(next ? bg(opt.color, opt.bold) : ESC + "0m");
                on = next;
            }
            b.append(' ');
        }
        if (on) b.append(ESC).append("0m");
        return b.toString();
    }

    private static String colon(int line, Options opt) {
        if (line == 1 || line == 3) {
            return bg(opt.color, opt.bold) + "  " + ESC + "0m";
        }
        return "  ";
    }

    private static String fg(int color, boolean bold) {
        return ESC + (bold ? "1;" : "") + (30 + color) + "m";
    }

    private static String bg(int color, boolean bold) {
        return ESC + (bold ? "1;" : "") + (40 + color) + "m";
    }

    private static void drawBox(StringBuilder out, int row, int col, int width, int height) {
        out.append(cursor(row, col)).append('+').append("-".repeat(Math.max(0, width - 2))).append('+');
        for (int r = 1; r < height - 1; r++) {
            out.append(cursor(row + r, col)).append('|');
            out.append(cursor(row + r, col + width - 1)).append('|');
        }
        out.append(cursor(row + height - 1, col)).append('+').append("-".repeat(Math.max(0, width - 2))).append('+');
    }

    private static String strftime(String fmt, LocalDateTime now) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < fmt.length(); i++) {
            char ch = fmt.charAt(i);
            if (ch != '%' || i + 1 >= fmt.length()) {
                b.append(ch);
                continue;
            }
            char code = fmt.charAt(++i);
            switch (code) {
                case 'F': b.append(String.format(Locale.ROOT, "%04d-%02d-%02d", now.getYear(), now.getMonthValue(), now.getDayOfMonth())); break;
                case 'Y': b.append(String.format(Locale.ROOT, "%04d", now.getYear())); break;
                case 'y': b.append(String.format(Locale.ROOT, "%02d", now.getYear() % 100)); break;
                case 'm': b.append(String.format(Locale.ROOT, "%02d", now.getMonthValue())); break;
                case 'd': b.append(String.format(Locale.ROOT, "%02d", now.getDayOfMonth())); break;
                case 'e': b.append(String.format(Locale.ROOT, "%2d", now.getDayOfMonth())); break;
                case 'H': b.append(String.format(Locale.ROOT, "%02d", now.getHour())); break;
                case 'I': {
                    int h = now.getHour() % 12;
                    if (h == 0) h = 12;
                    b.append(String.format(Locale.ROOT, "%02d", h));
                    break;
                }
                case 'M': b.append(String.format(Locale.ROOT, "%02d", now.getMinute())); break;
                case 'S': b.append(String.format(Locale.ROOT, "%02d", now.getSecond())); break;
                case 'p': b.append(now.getHour() < 12 ? "AM" : "PM"); break;
                case 'a': b.append(now.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ROOT)); break;
                case 'A': b.append(now.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ROOT)); break;
                case 'b':
                case 'h': b.append(now.getMonth().getDisplayName(TextStyle.SHORT, Locale.ROOT)); break;
                case 'B': b.append(now.getMonth().getDisplayName(TextStyle.FULL, Locale.ROOT)); break;
                case 'n': b.append('\n'); break;
                case 't': b.append('\t'); break;
                case '%': b.append('%'); break;
                default: b.append('%').append(code); break;
            }
        }
        return b.toString();
    }
}
