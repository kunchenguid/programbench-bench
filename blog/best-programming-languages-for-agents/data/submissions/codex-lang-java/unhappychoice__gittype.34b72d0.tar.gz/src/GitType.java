import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class GitType {
    private static final Set<String> COMMANDS = new HashSet<>(Arrays.asList(
            "history", "stats", "export", "cache", "repo", "trending", "help"));
    private static final Set<String> VALID_LANGS = new HashSet<>(Arrays.asList(
            "rust", "rs", "typescript", "ts", "javascript", "js", "python", "py",
            "ruby", "rb", "go", "swift", "kotlin", "kt", "java", "php",
            "csharp", "cs", "c#", "c", "cpp", "c++", "haskell", "hs", "dart",
            "scala", "sc", "zig", "clojure", "clj", "cljs"));

    public static void main(String[] args) {
        int code = new GitType().run(args);
        System.exit(code);
    }

    private int run(String[] args) {
        List<String> a = new ArrayList<>(Arrays.asList(args));
        if (a.contains("-V") || a.contains("--version")) {
            System.out.println("gittype 0.8.0");
            return 0;
        }
        if (a.contains("--help")) {
            return helpFor(a, true);
        }
        if (a.contains("-h")) {
            return helpFor(a, false);
        }
        if (a.isEmpty()) {
            return terminalError(args);
        }

        String first = a.get(0);
        if ("help".equals(first)) {
            if (a.size() == 1) {
                printLongRootHelp();
                return 0;
            }
            if (a.size() > 1 && a.get(1).startsWith("-")) {
                return error("unrecognized subcommand '" + a.get(1) + "'", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
            }
            return dispatchHelp(a.subList(1, a.size()), true);
        }

        if ("history".equals(first)) return planned("History command is not yet implemented", null, null);
        if ("stats".equals(first)) return planned("Stats command is not yet implemented", null, null);
        if ("export".equals(first)) return export(a.subList(1, a.size()));
        if ("cache".equals(first)) return cache(a.subList(1, a.size()));
        if ("repo".equals(first)) return repo(a.subList(1, a.size()));
        if ("trending".equals(first)) return trending(a.subList(1, a.size()), args);

        return rootOptionsOrGame(a, args);
    }

    private int rootOptionsOrGame(List<String> a, String[] original) {
        for (int i = 0; i < a.size(); i++) {
            String s = a.get(i);
            if ("--repo".equals(s)) {
                if (i + 1 >= a.size()) return missingValue("--repo <REPO>");
                i++;
            } else if ("--langs".equals(s)) {
                if (i + 1 >= a.size()) return missingValue("--langs <LANGS>");
                String bad = unsupportedLangs(a.get(++i));
                if (bad != null) {
                    System.out.println("❌ Unsupported language(s): " + bad);
                    System.out.println("💡 Supported languages:");
                    System.out.println("   rust, rs, typescript, ts, javascript, js");
                    System.out.println("   python, py, ruby, rb, go, swift");
                    System.out.println("   kotlin, kt, java, php, csharp, cs");
                    System.out.println("   c#, c, cpp, c++, haskell, hs");
                    System.out.println("   dart, scala, sc, zig, clojure, clj");
                    System.out.println("   cljs");
                    return 1;
                }
            } else if (s.startsWith("--")) {
                System.err.println("error: unexpected argument '" + s + "' found");
                System.err.println();
                System.err.println("  tip: to pass '" + s + "' as a value, use '-- " + s + "'");
                System.err.println();
                System.err.println("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
                System.err.println();
                System.err.println("For more information, try '--help'.");
                return 2;
            } else if (COMMANDS.contains(s)) {
                return error("unrecognized subcommand '" + s + "'", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
            }
        }
        return terminalError(original);
    }

    private int helpFor(List<String> a, boolean longHelp) {
        List<String> clean = new ArrayList<>();
        for (String s : a) if (!s.equals("-h") && !s.equals("--help")) clean.add(s);
        if (clean.isEmpty() || !COMMANDS.contains(clean.get(0)) || "help".equals(clean.get(0))) {
            if (longHelp) printLongRootHelp(); else printShortRootHelp();
            return 0;
        }
        return dispatchHelp(clean, longHelp);
    }

    private int dispatchHelp(List<String> path, boolean longHelp) {
        if (path.isEmpty()) {
            printLongRootHelp();
            return 0;
        }
        String cmd = path.get(0);
        if ("history".equals(cmd)) { printSimpleHelp("Show session history", "Usage: executable history"); return 0; }
        if ("stats".equals(cmd)) { printSimpleHelp("Show analytics", "Usage: executable stats"); return 0; }
        if ("export".equals(cmd)) { printExportHelp(); return 0; }
        if ("trending".equals(cmd)) { if (longHelp) printTrendingLongHelp(); else printTrendingShortHelp(); return 0; }
        if ("cache".equals(cmd)) {
            if (path.size() == 1) printCacheHelp();
            else if ("stats".equals(path.get(1))) printSimpleHelp("Show cache statistics", "Usage: executable cache stats");
            else if ("clear".equals(path.get(1))) printSimpleHelp("Clear all cached challenges", "Usage: executable cache clear");
            else if ("list".equals(path.get(1))) printSimpleHelp("List cached repository keys", "Usage: executable cache list");
            else return error("unrecognized subcommand '" + path.get(1) + "'", "Usage: executable cache <COMMAND>");
            return 0;
        }
        if ("repo".equals(cmd)) {
            if (path.size() == 1) printRepoHelp();
            else if ("list".equals(path.get(1))) printSimpleHelp("List all cached repositories", "Usage: executable repo list");
            else if ("clear".equals(path.get(1))) printRepoClearHelp();
            else if ("play".equals(path.get(1))) printSimpleHelp("Play a cached repository interactively", "Usage: executable repo play");
            else return error("unrecognized subcommand '" + path.get(1) + "'", "Usage: executable repo <COMMAND>");
            return 0;
        }
        return error("unrecognized subcommand '" + cmd + "'", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
    }

    private int export(List<String> args) {
        String format = "json";
        String output = null;
        for (int i = 0; i < args.size(); i++) {
            String s = args.get(i);
            if ("--format".equals(s)) {
                if (i + 1 >= args.size()) return missingValue("--format <FORMAT>");
                format = args.get(++i);
            } else if ("--output".equals(s)) {
                if (i + 1 >= args.size()) return missingValue("--output <OUTPUT>");
                output = args.get(++i);
            } else if (s.startsWith("-")) {
                return error("unexpected argument '" + s + "' found", "Usage: executable export [OPTIONS]");
            }
        }
        return planned("Export command is not yet implemented", "Requested format: " + format,
                output == null ? null : "Requested output: " + output);
    }

    private int cache(List<String> args) {
        if (args.isEmpty()) { printCacheHelp(); return 2; }
        String sub = args.get(0);
        if ("help".equals(sub)) { printCacheHelp(); return 0; }
        if (!Arrays.asList("stats", "clear", "list").contains(sub)) {
            return error("unrecognized subcommand '" + sub + "'", "Usage: executable cache <COMMAND>");
        }
        if (args.size() > 1) {
            if ("--help".equals(args.get(1)) || "-h".equals(args.get(1))) return dispatchHelp(Arrays.asList("cache", sub), true);
            return error("unexpected argument '" + args.get(1) + "' found", "Usage: executable cache " + sub);
        }
        if ("stats".equals(sub)) {
            System.out.println("Challenge Cache Statistics:");
            System.out.println("  Cached repositories: 0");
            System.out.println("  Total size: 0 bytes");
        } else if ("clear".equals(sub)) {
            System.out.println("Challenge cache cleared successfully.");
        } else {
            System.out.println("No cached challenges found.");
        }
        return 0;
    }

    private int repo(List<String> args) {
        if (args.isEmpty()) { printRepoHelp(); return 2; }
        String sub = args.get(0);
        if ("help".equals(sub)) { printRepoHelp(); return 0; }
        if (!Arrays.asList("list", "clear", "play").contains(sub)) {
            return error("unrecognized subcommand '" + sub + "'", "Usage: executable repo <COMMAND>");
        }
        if ("clear".equals(sub)) {
            for (int i = 1; i < args.size(); i++) {
                String s = args.get(i);
                if ("--help".equals(s) || "-h".equals(s)) { printRepoClearHelp(); return 0; }
                if (!"--force".equals(s)) return error("unexpected argument '" + s + "' found", "Usage: executable repo clear [OPTIONS]");
            }
            System.out.println("No cached repositories directory found.");
            return 0;
        }
        if (args.size() > 1 && ("--help".equals(args.get(1)) || "-h".equals(args.get(1)))) {
            return dispatchHelp(Arrays.asList("repo", sub), true);
        }
        return terminalError(new String[]{"executable", "repo", sub});
    }

    private int trending(List<String> args, String[] original) {
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.size(); i++) {
            String s = args.get(i);
            if ("--period".equals(s)) {
                if (i + 1 >= args.size()) return missingValue("--period <PERIOD>");
                i++;
            } else if (s.startsWith("-")) {
                return error("unexpected argument '" + s + "' found", "Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]");
            } else {
                pos.add(s);
            }
        }
        if (pos.size() >= 2 && !pos.get(1).contains("/")) {
            System.out.println("⚠️ Repository name must be in format 'owner/repo'");
            return 0;
        }
        return terminalError(original);
    }

    private int planned(String main, String extra1, String extra2) {
        System.out.println("❌ " + main);
        if (extra1 != null) System.out.println("💡 " + extra1);
        if (extra2 != null) System.out.println("💡 " + extra2);
        System.out.println("💡 This feature is planned for a future release");
        return 1;
    }

    private int terminalError(String[] args) {
        String name = "gittype_error_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".log";
        try {
            Files.writeString(Paths.get(name), "Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)\n");
        } catch (IOException ignored) {
        }
        System.out.println("💾 Error details written to: " + name);
        System.out.println("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)");
        return 1;
    }

    private int error(String message, String usage) {
        System.err.println("error: " + message);
        System.err.println();
        System.err.println(usage);
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private int missingValue(String opt) {
        System.err.println("error: a value is required for '" + opt + "' but none was supplied");
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private String unsupportedLangs(String value) {
        List<String> bad = new ArrayList<>();
        for (String raw : value.split(",")) {
            String v = raw.trim().toLowerCase(Locale.ROOT);
            if (!v.isEmpty() && !VALID_LANGS.contains(v)) bad.add(raw.trim());
        }
        return bad.isEmpty() ? null : String.join(", ", bad);
    }

    private void printLongRootHelp() {
        System.out.println("GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. ");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  gittype                           # Use current directory");
        System.out.println("  gittype /path/to/repo             # Use specific repository");
        System.out.println("  gittype --repo owner/repo         # Clone and use GitHub repository");
        System.out.println("  gittype --langs rust,python       # Filter by languages");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
        System.out.println();
        printCommands();
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [REPO_PATH]");
        System.out.println("          Repository path to extract code from");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --repo <REPO>");
        System.out.println("          GitHub repository URL or path to clone and play with. Supports formats:");
        System.out.println("            - owner/repo");
        System.out.println("            - https://github.com/owner/repo");
        System.out.println("            - git@github.com:owner/repo.git");
        System.out.println();
        System.out.println("      --langs <LANGS>");
        System.out.println("          Filter by programming languages (comma-separated). Supported languages:");
        System.out.println("            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig");
        System.out.println("            Example: --langs rust,python,typescript");
        System.out.println();
        System.out.println("  -h, --help");
        System.out.println("          Print help (see a summary with '-h')");
        System.out.println();
        System.out.println("  -V, --version");
        System.out.println("          Print version");
    }

    private void printShortRootHelp() {
        System.out.println("A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]");
        System.out.println();
        printCommands();
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [REPO_PATH]  Repository path to extract code from");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --repo <REPO>    GitHub repository URL or path to clone and play with");
        System.out.println("      --langs <LANGS>  Filter by programming languages (comma-separated)");
        System.out.println("  -h, --help           Print help (see more with '--help')");
        System.out.println("  -V, --version        Print version");
    }

    private void printCommands() {
        System.out.println("Commands:");
        System.out.println("  history   Show session history");
        System.out.println("  stats     Show analytics");
        System.out.println("  export    Export session data");
        System.out.println("  cache     Manage challenge cache");
        System.out.println("  repo      Manage repositories");
        System.out.println("  trending  Select and practice with trending repositories from GitHub");
        System.out.println("  help      Print this message or the help of the given subcommand(s)");
    }

    private void printSimpleHelp(String title, String usage) {
        System.out.println(title);
        System.out.println();
        System.out.println(usage);
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }

    private void printExportHelp() {
        System.out.println("Export session data");
        System.out.println();
        System.out.println("Usage: executable export [OPTIONS]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --format <FORMAT>  Export format [default: json]");
        System.out.println("      --output <OUTPUT>  Output file path");
        System.out.println("  -h, --help             Print help");
    }

    private void printCacheHelp() {
        System.out.println("Manage challenge cache");
        System.out.println();
        System.out.println("Usage: executable cache <COMMAND>");
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  stats  Show cache statistics");
        System.out.println("  clear  Clear all cached challenges");
        System.out.println("  list   List cached repository keys");
        System.out.println("  help   Print this message or the help of the given subcommand(s)");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }

    private void printRepoHelp() {
        System.out.println("Manage repositories");
        System.out.println();
        System.out.println("Usage: executable repo <COMMAND>");
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  list   List all cached repositories");
        System.out.println("  clear  Clear all cached repositories");
        System.out.println("  play   Play a cached repository interactively");
        System.out.println("  help   Print this message or the help of the given subcommand(s)");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }

    private void printRepoClearHelp() {
        System.out.println("Clear all cached repositories");
        System.out.println();
        System.out.println("Usage: executable repo clear [OPTIONS]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --force  Force clear without confirmation");
        System.out.println("  -h, --help   Print help");
    }

    private void printTrendingLongHelp() {
        System.out.println("Select and practice with trending repositories from GitHub");
        System.out.println();
        System.out.println("Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [LANGUAGE]");
        System.out.println("          Programming language to filter trending repositories.");
        System.out.println("          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig");
        System.out.println();
        System.out.println("  [REPO_NAME]");
        System.out.println("          Specific repository name to select from trending list");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --period <PERIOD>");
        System.out.println("          Time period for trending (daily, weekly, monthly)");
        System.out.println("          ");
        System.out.println("          [default: daily]");
        System.out.println();
        System.out.println("  -h, --help");
        System.out.println("          Print help (see a summary with '-h')");
    }

    private void printTrendingShortHelp() {
        System.out.println("Select and practice with trending repositories from GitHub");
        System.out.println();
        System.out.println("Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [LANGUAGE]   Programming language to filter trending repositories");
        System.out.println("  [REPO_NAME]  Specific repository name to select from trending list");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --period <PERIOD>  Time period for trending (daily, weekly, monthly) [default: daily]");
        System.out.println("  -h, --help             Print help (see more with '--help')");
    }
}
