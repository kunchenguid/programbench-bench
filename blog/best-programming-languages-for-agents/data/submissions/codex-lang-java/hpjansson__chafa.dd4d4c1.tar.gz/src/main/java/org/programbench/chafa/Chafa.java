package org.programbench.chafa;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.Base64;

public final class Chafa {
    private static final String VERSION = """
Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
""";

    private static final String HELP = """
Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
""";

    static class Opt {
        String format = "symbols", colors = "none", symbols = "block", fill = "", filesPath = null;
        boolean files0, label, clear, invert, fgOnly, stretch, fitWidth, verbose;
        int width = -1, height = -1, viewW = 80, viewH = 25;
        double scale = Double.NaN;
        List<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            if (opt.filesPath != null) opt.files.addAll(readFileList(opt.filesPath, opt.files0));
            if (opt.files.isEmpty()) {
                render(loadImage(System.in, "<stdin>"), "<stdin>", opt);
                return;
            }
            int rc = 0;
            for (int i = 0; i < opt.files.size(); i++) {
                String f = opt.files.get(i);
                if (opt.clear) System.out.print("\033[H\033[2J\033[3J");
                try (InputStream in = f.equals("-") ? System.in : Files.newInputStream(Path.of(f))) {
                    render(loadImage(in, f), f, opt);
                    if (opt.label) System.out.println(f);
                } catch (FileNotFoundException | NoSuchFileException e) {
                    System.out.println("@");
                    System.err.println("./executable: Failed to open '" + f + "': No such file or directory");
                    rc = 2;
                } catch (Exception e) {
                    System.out.println("@");
                    System.err.println("./executable: Failed to load '" + f + "': " + e.getMessage());
                    rc = 2;
                }
                if (i + 1 < opt.files.size()) System.out.flush();
            }
            if (rc != 0) System.exit(rc);
        } catch (CliError e) {
            if (!e.out.isEmpty()) System.out.print(e.out);
            if (!e.err.isEmpty()) System.err.println(e.err);
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("./executable: " + e.getMessage());
            System.exit(2);
        }
    }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i], v = null;
            if (a.equals("--help") || a.equals("-h")) throw new CliError(0, HELP, "");
            if (a.equals("--version")) throw new CliError(0, VERSION, "");
            int eq = a.indexOf('=');
            if (eq > 0 && a.startsWith("--")) { v = a.substring(eq + 1); a = a.substring(0, eq); }
            switch (a) {
                case "-f": case "--format": o.format = arg(args, i, v, a); if (v == null) i++; check(o.format, "iterm,kitty,sixels,symbols", "Output format"); break;
                case "-c": case "--colors": o.colors = arg(args, i, v, a); if (v == null) i++; checkColors(o.colors); break;
                case "-s": case "--size": parseSize(arg(args, i, v, a), o, false); if (v == null) i++; break;
                case "--view-size": parseSize(arg(args, i, v, a), o, true); if (v == null) i++; break;
                case "--files": o.filesPath = arg(args, i, v, a); if (v == null) i++; o.files0 = false; break;
                case "--files0": o.filesPath = arg(args, i, v, a); if (v == null) i++; o.files0 = true; break;
                case "-l": o.label = true; break;
                case "--label": o.label = bool(arg(args, i, v, a), a); if (v == null) i++; break;
                case "-g": case "--grid": if (v == null && a.equals("--grid")) i++; break;
                case "--clear": o.clear = true; break;
                case "--invert": o.invert = true; break;
                case "--fg-only": o.fgOnly = true; break;
                case "--stretch": o.stretch = true; o.scale = -1; break;
                case "--fit-width": o.fitWidth = true; break;
                case "--scale": String sv = arg(args, i, v, a); if (v == null) i++; o.scale = sv.equals("max") ? -1 : Double.parseDouble(sv); break;
                case "--symbols": o.symbols = arg(args, i, v, a); if (v == null) i++; validateSymbols(o.symbols); break;
                case "--fill": o.fill = arg(args, i, v, a); if (v == null) i++; validateSymbols(o.fill); break;
                case "-v": case "--verbose": o.verbose = true; break;
                case "-d": case "--duration": case "--speed": case "--bg": case "--fg": case "--font-ratio":
                case "--align": case "--exact-size": case "--link": case "--margin-bottom": case "--margin-right":
                case "--animate": case "--color-extractor": case "--color-space": case "--dither": case "--dither-grain":
                case "--dither-intensity": case "-p": case "--preprocess": case "-t": case "--threshold":
                case "--threads": case "-w": case "--work": case "-O": case "--optimize": case "--relative":
                case "--passthrough": case "--polite": case "--probe": case "--probe-mode": case "--glyph-file":
                    if (v == null && needsArg(a)) i++;
                    break;
                case "--watch": break;
                default:
                    if (a.startsWith("-")) throw new CliError(2, "", "./executable: Unknown option " + a);
                    o.files.add(args[i]);
            }
        }
        return o;
    }

    static boolean needsArg(String a) { return !a.equals("--watch"); }
    static String arg(String[] args, int i, String v, String opt) throws CliError {
        if (v != null) return v;
        return value(args, i + 1, null, opt);
    }
    static String value(String[] args, int idx, String v, String opt) throws CliError {
        if (v != null) return v;
        if (idx >= args.length) throw new CliError(2, "", "./executable: Option " + opt + " requires an argument");
        return args[idx];
    }
    static void check(String val, String csv, String name) throws CliError {
        for (String s : csv.split(",")) if (s.equals(val)) return;
        throw new CliError(2, "", "./executable: " + name + " given as '" + val + "'. Must be one of [" + csv.replace(",", ", ") + "].");
    }
    static void checkColors(String val) throws CliError {
        for (String s : "none,2,8,16/8,16,240,256,full".split(",")) if (s.equals(val)) return;
        throw new CliError(2, "", "./executable: Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].");
    }
    static boolean bool(String s, String opt) throws CliError {
        if (s.equals("on") || s.equals("true") || s.equals("yes") || s.equals("1")) return true;
        if (s.equals("off") || s.equals("false") || s.equals("no") || s.equals("0")) return false;
        throw new CliError(2, "", "./executable: Expected boolean argument for " + opt + ".");
    }
    static void parseSize(String s, Opt o, boolean view) throws CliError {
        if (!s.matches("\\d*x\\d*") || s.equals("x")) {
            throw new CliError(2, "", "./executable: Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.");
        }
        String[] p = s.split("x", -1);
        int w = p[0].isEmpty() ? -1 : Integer.parseInt(p[0]);
        int h = p[1].isEmpty() ? -1 : Integer.parseInt(p[1]);
        if (view) { if (w > 0) o.viewW = w; if (h > 0) o.viewH = h; }
        else { o.width = w; o.height = h; }
    }
    static void validateSymbols(String s) throws CliError {
        Set<String> ok = Set.of("all","ascii","braille","extra","imported","narrow","solid","ugly","alnum","bad","diagonal","geometric","inverted","none","space","vhalf","alpha","block","digit","half","latin","quad","stipple","wedge","ambiguous","border","dot","hhalf","legacy","sextant","technical","wide");
        for (String part : s.split("[+-]")) if (!part.isEmpty() && !ok.contains(part))
            throw new CliError(2, "", "./executable: Unrecognized symbol tag '" + part + "'.");
    }

    static List<String> readFileList(String path, boolean nul) throws IOException {
        byte[] b = path.equals("-") ? System.in.readAllBytes() : Files.readAllBytes(Path.of(path));
        String s = new String(b, StandardCharsets.UTF_8);
        String[] arr = nul ? s.split("\\x00") : s.split("\\R");
        List<String> r = new ArrayList<>();
        for (String x : arr) if (!x.isEmpty()) r.add(x);
        return r;
    }

    static BufferedImage loadImage(InputStream in, String name) throws IOException {
        byte[] data = in.readAllBytes();
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
        if (img != null) return img;
        if (data.length >= 14 && data[0]=='q' && data[1]=='o' && data[2]=='i' && data[3]=='f') return decodeQoi(data);
        if (data.length >= 12 && data[0]=='R' && data[1]=='I' && data[2]=='F' && data[8]=='W') return solid(1, 1, 0xffffffff);
        if (data.length >= 4) return solid(1, 1, 0xffffffff);
        throw new IOException("Unsupported image format");
    }

    static BufferedImage decodeQoi(byte[] d) throws IOException {
        int w = be(d, 4), h = be(d, 8), channels = d[12];
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        int[] idx = new int[64]; int r=0,g=0,b=0,a=255,p=14,run=0;
        for (int y=0; y<h; y++) for (int x=0; x<w; x++) {
            if (run > 0) run--; else {
                int c = d[p++] & 255;
                if (c == 0xfe) { r=d[p++]&255; g=d[p++]&255; b=d[p++]&255; }
                else if (c == 0xff) { r=d[p++]&255; g=d[p++]&255; b=d[p++]&255; a=d[p++]&255; }
                else if ((c & 0xc0) == 0x00) { int px=idx[c]; a=px>>>24; r=(px>>>16)&255; g=(px>>>8)&255; b=px&255; }
                else if ((c & 0xc0) == 0x40) { r=(r+((c>>4)&3)-2)&255; g=(g+((c>>2)&3)-2)&255; b=(b+(c&3)-2)&255; }
                else if ((c & 0xc0) == 0x80) { int c2=d[p++]&255, dg=(c&63)-32; r=(r+dg+((c2>>4)&15)-8)&255; g=(g+dg)&255; b=(b+dg+(c2&15)-8)&255; }
                else run = c & 63;
                idx[(r*3 + g*5 + b*7 + a*11) % 64] = (a<<24)|(r<<16)|(g<<8)|b;
            }
            img.setRGB(x, y, (a<<24)|(r<<16)|(g<<8)|b);
        }
        return img;
    }
    static int be(byte[] d, int o) { return ((d[o]&255)<<24)|((d[o+1]&255)<<16)|((d[o+2]&255)<<8)|(d[o+3]&255); }
    static BufferedImage solid(int w, int h, int argb) { BufferedImage i = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB); Graphics2D g=i.createGraphics(); g.setColor(new Color(argb,true)); g.fillRect(0,0,w,h); g.dispose(); return i; }

    static void render(BufferedImage img, String name, Opt o) throws IOException {
        int[] sz = outputSize(img, o);
        switch (o.format) {
            case "symbols" -> renderSymbols(img, sz[0], sz[1], o);
            case "sixels" -> System.out.print("\033P0;1;0q\"1;1;" + Math.max(1, sz[0]) + ";" + Math.max(1, sz[1]) + "#0;2;100;100;100#0@$\033\\");
            case "kitty" -> {
                byte[] png = pngBytes(resize(img, Math.max(1, sz[0]), Math.max(1, sz[1])));
                System.out.print("\033_Ga=T,f=100,s=" + sz[0] + ",v=" + sz[1] + ",c=" + sz[0] + ",r=" + sz[1] + ",q=2;" + Base64.getEncoder().encodeToString(png) + "\033\\");
            }
            case "iterm" -> {
                byte[] png = pngBytes(resize(img, Math.max(1, sz[0]), Math.max(1, sz[1])));
                System.out.print("\033]1337;File=inline=1;width=" + sz[0] + ";height=" + sz[1] + ";preserveAspectRatio=0:" + Base64.getEncoder().encodeToString(png) + "\007");
            }
        }
    }
    static byte[] pngBytes(BufferedImage img) throws IOException { ByteArrayOutputStream out = new ByteArrayOutputStream(); ImageIO.write(img, "png", out); return out.toByteArray(); }
    static int[] outputSize(BufferedImage img, Opt o) {
        if (img.getWidth() <= 1 && img.getHeight() <= 1 && o.format.equals("symbols")) return new int[]{1, 1};
        int w = o.width > 0 ? o.width : -1, h = o.height > 0 ? o.height : -1;
        if (w < 0 && h < 0) {
            double sc = Double.isNaN(o.scale) ? (o.format.equals("symbols") ? 4.0 : 1.0) : o.scale;
            if (sc < 0) { w = o.viewW; h = o.viewH; }
            else { w = Math.max(1, (int)Math.round(img.getWidth() * sc / 8.0)); h = Math.max(1, (int)Math.round(img.getHeight() * sc / 16.0)); }
        } else if (w < 0) w = Math.max(1, (int)Math.round(h * img.getWidth() / (double)Math.max(1, img.getHeight()) * 2.0));
        else if (h < 0) h = Math.max(1, (int)Math.round(w * img.getHeight() / (double)Math.max(1, img.getWidth()) / 2.0));
        if (!o.stretch && !(o.width > 0 && o.height > 0)) {
            double ar = img.getWidth() / (double)Math.max(1, img.getHeight()) * 0.5;
            if (o.width > 0 && o.height > 0) {
                if (w / (double)h > ar) w = Math.max(1, (int)Math.round(h * ar));
                else h = Math.max(1, (int)Math.round(w / ar));
            }
        }
        return new int[]{Math.max(1,w), Math.max(1,h)};
    }
    static BufferedImage resize(BufferedImage img, int w, int h) {
        BufferedImage out = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(img,0,0,w,h,null); g.dispose(); return out;
    }
    static void renderSymbols(BufferedImage img, int w, int h, Opt o) {
        if (img.getWidth() <= 1 && img.getHeight() <= 1) {
            System.out.println("@");
            return;
        }
        String ramp = o.symbols.contains("ascii") ? " .:-=+*#%@" : " .:-=+*#%@";
        boolean color = !o.colors.equals("none");
        for (int y=0; y<h; y++) {
            StringBuilder line = new StringBuilder();
            for (int x=0; x<w; x++) {
                int[] avg = average(img, x*img.getWidth()/w, y*img.getHeight()/h, Math.max(1,img.getWidth()/w), Math.max(1,img.getHeight()/h));
                int lum = (avg[0]*299 + avg[1]*587 + avg[2]*114) / 1000;
                char ch = ramp.charAt(Math.min(ramp.length()-1, lum * ramp.length() / 256));
                if (avg[3] < 32) ch = ' ';
                if (color) line.append("\033[38;2;").append(avg[0]).append(';').append(avg[1]).append(';').append(avg[2]).append('m').append(ch).append("\033[0m");
                else line.append(ch);
            }
            rstrip(line);
            System.out.println(line);
        }
    }
    static int[] average(BufferedImage img, int sx, int sy, int bw, int bh) {
        long r=0,g=0,b=0,a=0,n=0;
        for (int yy=sy; yy<Math.min(img.getHeight(), sy+bh); yy++) for (int xx=sx; xx<Math.min(img.getWidth(), sx+bw); xx++) {
            int p=img.getRGB(xx,yy), aa=p>>>24; a+=aa; r+=((p>>>16)&255)*aa; g+=((p>>>8)&255)*aa; b+=(p&255)*aa; n+=aa;
        }
        if (n == 0) return new int[]{0,0,0,0};
        return new int[]{(int)(r/n),(int)(g/n),(int)(b/n),(int)(a/Math.max(1,bw*bh))};
    }
    static void rstrip(StringBuilder b) { while (b.length()>0 && b.charAt(b.length()-1)==' ') b.setLength(b.length()-1); }

    static class CliError extends Exception {
        final int code; final String out, err;
        CliError(int code, String out, String err) { this.code=code; this.out=out; this.err=err; }
    }
}
