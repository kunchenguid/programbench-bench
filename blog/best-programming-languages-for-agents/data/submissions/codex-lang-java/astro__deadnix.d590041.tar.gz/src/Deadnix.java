import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.*;

public class Deadnix {
    static class Opt {
        boolean noLambdaArg, noLambdaPattern, noUnderscore, warnUsedUnderscore, quiet, edit, hidden, fail, json;
        List<String> paths = new ArrayList<>();
        List<String> excludes = new ArrayList<>();
    }
    static class Decl {
        String name, kind; int line, col, endCol, start, end; boolean skip, alias;
        Decl(String n, String k, int l, int c, int e, int s, int en, boolean sk) {
            name=n; kind=k; line=l; col=c; endCol=e; start=s; end=en; skip=sk;
        }
    }
    static class Res {
        String file, message; int line, col, endCol;
        Res(String f, Decl d, String msg) { file=f; line=d.line; col=d.col; endCol=d.endCol; message=msg; }
    }
    static final Set<String> KW = new HashSet<>(Arrays.asList(
        "let","in","inherit","with","rec","true","false","null","if","then","else","assert","or"));

    public static void main(String[] args) throws Exception {
        Opt opt = parse(args);
        if (opt.paths.isEmpty()) opt.paths.add(".");
        List<Path> files = collect(opt);
        boolean found = false;
        for (Path p: files) {
            List<Res> rs = analyze(p, displayName(p), opt);
            if (!rs.isEmpty()) found = true;
            if (!opt.quiet) {
                if (opt.json && !rs.isEmpty()) System.out.println(jsonFile(displayName(p), rs));
                else if (!rs.isEmpty()) printHuman(p, rs);
            }
            if (opt.edit && !rs.isEmpty()) editFile(p, rs);
        }
        if (found && opt.fail) System.exit(1);
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            switch(a) {
                case "--help": usage(); System.exit(0); break;
                case "-V": case "--version": System.out.println("deadnix 1.3.1"); System.exit(0); break;
                case "-l": case "--no-lambda-arg": o.noLambdaArg=true; break;
                case "-L": case "--no-lambda-pattern-names": o.noLambdaPattern=true; break;
                case "-_": case "--no-underscore": o.noUnderscore=true; break;
                case "-W": case "--warn-used-underscore": o.warnUsedUnderscore=true; break;
                case "-q": case "--quiet": o.quiet=true; break;
                case "-e": case "--edit": o.edit=true; break;
                case "-h": case "--hidden": o.hidden=true; break;
                case "-f": case "--fail": o.fail=true; break;
                case "-o": case "--output-format":
                    if (++i>=args.length) die("error: a value is required for '--output-format <OUTPUT_FORMAT>'",2);
                    if (args[i].equals("json")) o.json=true;
                    else if (!args[i].equals("human-readable")) die("error: invalid value '"+args[i]+"' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human-readable, json]\n\nFor more information, try '--help'.",2);
                    break;
                case "--exclude":
                    while (i+1<args.length && !args[i+1].equals("--") && !args[i+1].startsWith("-")) o.excludes.add(args[++i]);
                    break;
                case "--": while (++i<args.length) o.paths.add(args[i]); break;
                default:
                    if (a.startsWith("-") && a.length()>1) {
                        for (int j=1;j<a.length();j++) {
                            char c=a.charAt(j);
                            if (c=='q') o.quiet=true; else if (c=='e') o.edit=true; else if (c=='f') o.fail=true;
                            else if (c=='h') o.hidden=true; else if (c=='l') o.noLambdaArg=true; else if (c=='L') o.noLambdaPattern=true;
                            else die("error: unexpected argument '"+a+"'",2);
                        }
                    } else o.paths.add(a);
            }
        }
        return o;
    }
    static void die(String s,int code){System.err.println(s);System.exit(code);}
    static void usage() {
        System.out.println("Find dead code in .nix files\n\nUsage: executable [OPTIONS] [FILE_PATHS]...\n\nArguments:\n  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]\n\nOptions:\n  -l, --no-lambda-arg                  Don't check lambda parameter arguments\n  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)\n  -_, --no-underscore                  Don't check any bindings that start with a _\n  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'\n  -q, --quiet                          Don't print dead code report\n  -e, --edit                           Remove unused code and write to source file\n  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files\n      --help                           \n  -f, --fail                           Exit with 1 if unused code has been found\n  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]\n      --exclude <EXCLUDES>...          Files to exclude from analysis\n  -V, --version                        Print version");
    }

    static List<Path> collect(Opt o) throws IOException {
        List<Path> out = new ArrayList<>();
        for (String s: o.paths) {
            Path p=Paths.get(s);
            if (!Files.exists(p)) { System.err.println("Error stating file "+s+": No such file or directory (os error 2)"); continue; }
            if (Files.isRegularFile(p)) { if (isNix(p,o) && !excluded(p,o)) out.add(p); }
            else if (Files.isDirectory(p)) {
                Files.walkFileTree(p, new SimpleFileVisitor<Path>() {
                    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                        if (!o.hidden && !dir.equals(p) && dir.getFileName().toString().startsWith(".")) return FileVisitResult.SKIP_SUBTREE;
                        return excluded(dir,o) ? FileVisitResult.SKIP_SUBTREE : FileVisitResult.CONTINUE;
                    }
                    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                        if (isNix(file,o) && !excluded(file,o)) out.add(file);
                        return FileVisitResult.CONTINUE;
                    }
                });
            }
        }
        out.sort(Comparator.comparing(Path::toString));
        return out;
    }
    static boolean isNix(Path p, Opt o) { String n=p.getFileName().toString(); return n.endsWith(".nix") && (o.hidden || !n.startsWith(".")); }
    static boolean excluded(Path p, Opt o) { String x=p.toString(); for(String e:o.excludes) if(x.equals(e)||x.endsWith("/"+e)||x.contains(e)) return true; return false; }
    static String displayName(Path p){ String s=p.toString(); return s; }

    static List<Res> analyze(Path path, String file, Opt opt) throws IOException {
        String src = Files.readString(path);
        String clean = mask(src);
        List<Decl> decls = new ArrayList<>();
        boolean[] skipLine = skipLines(src);
        collectLetBindings(src, clean, decls, skipLine);
        if (!opt.noLambdaArg) collectSimpleLambdas(src, clean, decls, skipLine);
        if (!opt.noLambdaPattern) collectPatternLambdas(src, clean, decls, skipLine);
        Set<String> refs = identifiers(clean);
        List<Res> rs = new ArrayList<>();
        boolean[] declSpan = new boolean[clean.length()+1];
        for (Decl x: decls) for(int i=Math.max(0,x.start); i<Math.min(declSpan.length,x.end); i++) declSpan[i]=true;
        for (Decl d: decls) {
            if (d.skip) continue;
            if (opt.noUnderscore && d.name.startsWith("_")) continue;
            int searchFrom = d.alias ? lineStart(clean, d.start) : (d.kind.equals("lambda pattern") || d.kind.equals("lambda argument") ? lambdaBodyStart(clean, d.end) : 0);
            int count = countRefs(clean, d, declSpan, decls, searchFrom);
            boolean used = refs.contains(d.name) && count > 0;
            if (opt.warnUsedUnderscore && d.name.startsWith("_") && used) rs.add(new Res(file,d,"Used "+d.kind+": "+d.name));
            else if (!used) {
                if (d.kind.equals("lambda argument") && d.name.startsWith("_")) continue;
                rs.add(new Res(file,d,"Unused "+d.kind+": "+d.name));
            }
        }
        rs.sort(Comparator.<Res>comparingInt(r->r.line).thenComparingInt(r->r.col).thenComparing(r->r.message));
        return rs;
    }

    static String mask(String s) {
        StringBuilder b=new StringBuilder(s);
        boolean str=false;
        for(int i=0;i<b.length();i++){
            char c=b.charAt(i);
            if(!str && c=='#'){ while(i<b.length()&&b.charAt(i)!='\n') b.setCharAt(i++,' '); i--; continue; }
            if(c=='"' && (i==0||b.charAt(i-1)!='\\')) { str=!str; b.setCharAt(i,' '); continue; }
            if(str && c=='$' && i+1<b.length() && b.charAt(i+1)=='{') {
                b.setCharAt(i,' '); b.setCharAt(i+1,' '); i+=2; int depth=1;
                while(i<b.length() && depth>0) {
                    char x=b.charAt(i);
                    if(x=='{') depth++; else if(x=='}') { depth--; if(depth==0){ b.setCharAt(i,' '); break; } }
                    i++;
                }
                continue;
            }
            if(str && c!='\n') b.setCharAt(i,' ');
        }
        return b.toString();
    }
    static boolean[] skipLines(String src) {
        int lines = src.split("\n",-1).length+2; boolean[] s=new boolean[lines+2];
        String[] arr=src.split("\n",-1);
        for(int i=0;i<arr.length;i++) if(arr[i].contains("deadnix: skip") && i+2<s.length) s[i+2]=true;
        return s;
    }
    static void collectLetBindings(String src,String clean,List<Decl>d,boolean[]skip){
        String[] lines = clean.split("\n",-1);
        int off=0; boolean inLet=false; int letIndent=0;
        Pattern p=Pattern.compile("^([ \\t]*)([A-Za-z_][A-Za-z0-9_'-]*)(?:\\.[A-Za-z0-9_'-]+)*\\s*=");
        Pattern inh=Pattern.compile("^([ \\t]*)inherit\\s*\\([^)]*\\)\\s+([^;]+);");
        for(int i=0;i<lines.length;i++){
            String line=lines[i]; String tr=line.trim();
            if(tr.equals("let") || tr.startsWith("let ")) { inLet=true; letIndent=indent(line); }
            if(inLet) {
                if(tr.startsWith("in ") || tr.equals("in") || (indent(line)<=letIndent && tr.startsWith("in"))) inLet=false;
                else {
                    Matcher m=p.matcher(line);
                    if(m.find()){ int st=off+m.start(2); int ln=i+1; d.add(new Decl(m.group(2),"let binding",ln,colOf(src,st),colOf(src,st+m.group(2).length()),st,st+m.group(2).length(), ln<skip.length&&skip[ln])); }
                    Matcher im=inh.matcher(line);
                    if(im.find()){
                        String body=im.group(2); int base=off+im.start(2);
                        Matcher nm=Pattern.compile("[A-Za-z_][A-Za-z0-9_'-]*").matcher(body);
                        while(nm.find()){ String name=nm.group(); int st=base+nm.start(); int ln=i+1; d.add(new Decl(name,"let binding",ln,colOf(src,st),colOf(src,st+name.length()),st,st+name.length(),ln<skip.length&&skip[ln])); }
                    }
                }
            }
            off += line.length()+1;
        }
        Matcher inline=Pattern.compile("\\blet\\s+([A-Za-z_][A-Za-z0-9_'-]*)\\s*=").matcher(clean);
        while(inline.find()){
            int st=inline.start(1), ln=lineOf(src,st);
            Decl x=new Decl(inline.group(1),"let binding",ln,colOf(src,st),colOf(src,st+inline.group(1).length()),st,st+inline.group(1).length(),true);
            d.add(x);
        }
    }
    static int indent(String s){ int i=0; while(i<s.length()&&(s.charAt(i)==' '||s.charAt(i)=='\t')) i++; return i; }
    static void collectSimpleLambdas(String src,String clean,List<Decl>d,boolean[]skip){
        Matcher m=Pattern.compile("(?<![A-Za-z0-9_'-])([A-Za-z_][A-Za-z0-9_'-]*)\\s*:").matcher(clean);
        while(m.find()){
            int prev=prevNonWs(clean,m.start()-1);
            if(prev>=0 && clean.charAt(prev)=='}') continue;
            if(m.start(1)>0 && clean.charAt(m.start(1)-1)=='@') continue;
            String name=m.group(1); if(KW.contains(name)) continue;
            int line=lineOf(src,m.start(1));
            d.add(new Decl(name,"lambda argument",line,colOf(src,m.start(1)),colOf(src,m.end(1)),m.start(1),m.end(1),line<skip.length&&skip[line]));
        }
    }
    static void collectPatternLambdas(String src,String clean,List<Decl>d,boolean[]skip){
        Pattern pat=Pattern.compile("([A-Za-z_][A-Za-z0-9_'-]*)\\s*@\\s*\\{([^}]*)\\}\\s*:|\\{([^}]*)\\}\\s*@\\s*([A-Za-z_][A-Za-z0-9_'-]*)\\s*:|\\{([^}]*)\\}\\s*:");
        Matcher m=pat.matcher(clean);
        int pos=0;
        while(m.find(pos)){
            pos=m.end();
            if(m.group(1)!=null) addPatName(src, d, skip, m.start(1), m.group(1), true);
            if(m.group(4)!=null) addPatName(src, d, skip, m.start(4), m.group(4), true);
            String body = m.group(2)!=null?m.group(2):(m.group(3)!=null?m.group(3):m.group(5));
            int base = m.group(2)!=null?m.start(2):(m.group(3)!=null?m.start(3):m.start(5));
            if (body.contains("=") || body.contains(";")) { pos=m.start()+1; continue; }
            int partBase=0;
            for(String part: body.split(",")){
                Matcher nm=Pattern.compile("[A-Za-z_][A-Za-z0-9_'-]*").matcher(part);
                if(nm.find()){
                    String name=nm.group(); if(!name.equals("...")&&!KW.contains(name)) {
                        int st=base+partBase+nm.start();
                        addPatName(src,d,skip,st,name, false);
                    }
                }
                partBase += part.length()+1;
            }
        }
    }
    static void addPatName(String src,List<Decl>d,boolean[]skip,int st,String name, boolean alias){ int line=lineOf(src,st); Decl x=new Decl(name,"lambda pattern",line,colOf(src,st),colOf(src,st+name.length()),st,st+name.length(),line<skip.length&&skip[line]); x.alias=alias; d.add(x); }
    static int prevNonWs(String s,int i){ while(i>=0&&Character.isWhitespace(s.charAt(i)))i--; return i; }
    static int nextNonWs(String s,int i){ while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++; return i<s.length()?i:-1; }
    static Set<String> identifiers(String s){ Set<String> r=new HashSet<>(); Matcher m=Pattern.compile("[A-Za-z_][A-Za-z0-9_'-]*").matcher(s); while(m.find()) if(!KW.contains(m.group())) r.add(m.group()); return r; }
    static int lambdaBodyStart(String s, int after) {
        int c=s.indexOf(':', after);
        return c>=0 ? c+1 : after;
    }
    static int lineStart(String s,int pos){ int i=pos; while(i>0&&s.charAt(i-1)!='\n')i--; return i; }
    static int countRefs(String s,Decl d,boolean[] declSpan,List<Decl> decls,int from){
        String name=d.name;
        int c=0; Matcher m=Pattern.compile("(?<![A-Za-z0-9_'-])"+Pattern.quote(name)+"(?![A-Za-z0-9_'-])").matcher(s);
        while(m.find()) if(m.start()>=from && (m.start()>=declSpan.length || !declSpan[m.start()]) && !shadowedByLater(d, decls, m.start())) c++;
        return c;
    }
    static boolean shadowedByLater(Decl d,List<Decl>decls,int pos){ for(Decl x:decls) if(x!=d && x.name.equals(d.name) && x.start>d.start && x.start<pos) return true; return false; }
    static int lineOf(String s,int pos){ int l=1; for(int i=0;i<pos&&i<s.length();i++) if(s.charAt(i)=='\n') l++; return l; }
    static int colOf(String s,int pos){ int i=pos-1; while(i>=0&&s.charAt(i)!='\n') i--; return pos-i; }
    static String jsonFile(String file, List<Res> rs){
        StringBuilder b=new StringBuilder("{\"file\":\"").append(esc(file)).append("\",\"results\":[");
        for(int i=0;i<rs.size();i++){ Res r=rs.get(i); if(i>0)b.append(',');
            b.append("{\"column\":").append(r.col).append(",\"endColumn\":").append(r.endCol).append(",\"line\":").append(r.line).append(",\"message\":\"").append(esc(r.message)).append("\"}");
        }
        return b.append("]}").toString();
    }
    static String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }
    static void printHuman(Path p,List<Res>rs)throws IOException{
        System.out.println("Warning: Unused declarations were found.");
        List<String> lines=Files.readAllLines(p);
        for(Res r:rs){ String text=r.line<=lines.size()?lines.get(r.line-1):""; System.out.println("   ╭─["+r.file+":"+r.line+":"+r.col+"]"); System.out.printf("%2d │%s%n",r.line,text); System.out.println("   │"+" ".repeat(Math.max(0,r.col))+"╰─ "+r.message); }
    }
    static void editFile(Path p,List<Res>rs)throws IOException{
        List<String> lines=Files.readAllLines(p); Set<Integer> remove=new HashSet<>();
        for(Res r:rs) if(r.message.startsWith("Unused let binding")) remove.add(r.line);
        if(remove.isEmpty()) return;
        List<String> out=new ArrayList<>(); for(int i=0;i<lines.size();i++) if(!remove.contains(i+1)) out.add(lines.get(i));
        Files.write(p,out,StandardCharsets.UTF_8);
    }
}
