import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Dupl {
    static class Options {
        int threshold = 15;
        boolean files, html, plumbing, vendor, verbose, help;
        List<String> paths = new ArrayList<>();
    }

    static class Source {
        String path;
        String text;
        String[] lines;
        List<Token> tokens = new ArrayList<>();
    }

    static class Token {
        String kind;
        int line;
        Source source;
        int indexInSource;
        int global;
    }

    static class Occ {
        int start, endExclusive, startLine, endLine;
        Source source;
        String key() { return source.path + ":" + startLine + "-" + endLine; }
    }

    static class Group {
        String seq;
        int len;
        List<Occ> occs = new ArrayList<>();
    }

    static class Span {
        int start, end;
        Span(int s, int e) { start = s; end = e; }
    }

    static final String HELP = "Usage: dupl [flags] [paths]\n" +
            "\n" +
            "Paths:\n" +
            "  If the given path is a file, dupl will use it regardless of\n" +
            "  the file extension. If it is a directory, it will recursively\n" +
            "  search for *.go files in that directory.\n" +
            "\n" +
            "  If no path is given, dupl will recursively search for *.go\n" +
            "  files in the current directory.\n" +
            "\n" +
            "Flags:\n" +
            "  -files\n" +
            "\tread file names from stdin one at each line\n" +
            "  -html\n" +
            "\toutput the results as HTML, including duplicate code fragments\n" +
            "  -plumbing\n" +
            "\tplumbing (easy-to-parse) output for consumption by scripts or tools\n" +
            "  -t, -threshold size\n" +
            "\tminimum token sequence size as a clone (default 15)\n" +
            "  -vendor\n" +
            "\tcheck files in vendor directory\n" +
            "  -v, -verbose\n" +
            "\texplain what is being done\n" +
            "\n" +
            "Examples:\n" +
            "  dupl -t 100\n" +
            "\tSearch clones in the current directory of size at least\n" +
            "\t100 tokens.\n" +
            "  dupl $(find app/ -name '*_test.go')\n" +
            "\tSearch for clones in tests in the app directory.\n" +
            "  find app/ -name '*_test.go' |dupl -files\n" +
            "\tThe same as above.";

    public static void main(String[] args) {
        try {
            Options opt = parse(args);
            if (opt.help) {
                System.out.println(HELP);
                return;
            }
            List<String> files = collectFiles(opt);
            List<Token> all = new ArrayList<>();
            List<Source> sources = new ArrayList<>();
            for (String f : files) {
                try {
                    Source s = new Source();
                    s.path = normalizePath(f);
                    byte[] bytes = Files.readAllBytes(Paths.get(f));
                    s.text = new String(bytes, StandardCharsets.UTF_8);
                    s.lines = s.text.split("\\R", -1);
                    tokenize(s, all.size());
                    for (Token t : s.tokens) all.add(t);
                    sources.add(s);
                } catch (IOException e) {
                    logErr(e.getMessage());
                }
            }
            if (opt.verbose) vlog("Building suffix tree");
            if (opt.verbose) vlog("Searching for clones");
            List<Group> groups = findGroups(all, opt.threshold);
            if (opt.html) printHtml(groups);
            else if (opt.plumbing) printPlumbing(groups);
            else printDefault(groups);
        } catch (ArgError e) {
            System.err.println(e.getMessage());
            System.err.println(HELP);
        } catch (Exception e) {
            logErr(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    static class ArgError extends Exception { ArgError(String m) { super(m); } }

    static Options parse(String[] args) throws ArgError {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (!a.startsWith("-") || a.equals("-")) {
                o.paths.add(a);
            } else if (a.equals("-h") || a.equals("--help")) o.help = true;
            else if (a.equals("-files")) o.files = true;
            else if (a.equals("-html")) o.html = true;
            else if (a.equals("-plumbing")) o.plumbing = true;
            else if (a.equals("-vendor")) o.vendor = true;
            else if (a.equals("-v") || a.equals("-verbose")) o.verbose = true;
            else if (a.equals("-t") || a.equals("-threshold")) {
                if (++i >= args.length) throw new ArgError("flag needs an argument: " + a);
                try { o.threshold = Integer.parseInt(args[i]); }
                catch (NumberFormatException ex) {
                    throw new ArgError("invalid value \"" + args[i] + "\" for flag " + a + ": parse error");
                }
            } else if (a.startsWith("-t=") || a.startsWith("-threshold=")) {
                String name = a.startsWith("-t=") ? "-t" : "-threshold";
                String val = a.substring(a.indexOf('=') + 1);
                try { o.threshold = Integer.parseInt(val); }
                catch (NumberFormatException ex) {
                    throw new ArgError("invalid value \"" + val + "\" for flag " + name + ": parse error");
                }
            } else throw new ArgError("flag provided but not defined: " + a);
        }
        return o;
    }

    static List<String> collectFiles(Options opt) throws IOException {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (opt.files) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) if (!line.isEmpty()) out.add(line);
        }
        if (opt.paths.isEmpty() && !opt.files) opt.paths.add(".");
        for (String p : opt.paths) addPath(Paths.get(p), opt.vendor, out);
        return new ArrayList<>(out);
    }

    static void addPath(Path p, boolean vendor, LinkedHashSet<String> out) throws IOException {
        if (!Files.exists(p)) {
            logErr("lstat " + p + ": no such file or directory");
            return;
        }
        if (Files.isRegularFile(p)) {
            out.add(p.toString());
        } else if (Files.isDirectory(p)) {
            Files.walkFileTree(p, new SimpleFileVisitor<Path>() {
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!vendor && dir.getFileName() != null && dir.getFileName().toString().equals("vendor"))
                        return FileVisitResult.SKIP_SUBTREE;
                    return FileVisitResult.CONTINUE;
                }
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (file.getFileName().toString().endsWith(".go")) out.add(file.toString());
                    return FileVisitResult.CONTINUE;
                }
            });
        }
    }

    static String normalizePath(String p) {
        return p.replace(File.separatorChar, '/');
    }

    static void tokenize(Source s, int globalBase) {
        String x = s.text;
        int i = 0, line = 1, idx = 0;
        while (i < x.length()) {
            char c = x.charAt(i);
            if (Character.isWhitespace(c)) {
                if (c == '\n') line++;
                i++;
                continue;
            }
            if (c == '/' && i + 1 < x.length() && x.charAt(i + 1) == '/') {
                i += 2;
                while (i < x.length() && x.charAt(i) != '\n') i++;
                continue;
            }
            if (c == '/' && i + 1 < x.length() && x.charAt(i + 1) == '*') {
                i += 2;
                while (i + 1 < x.length() && !(x.charAt(i) == '*' && x.charAt(i + 1) == '/')) {
                    if (x.charAt(i) == '\n') line++;
                    i++;
                }
                i = Math.min(x.length(), i + 2);
                continue;
            }
            String kind;
            int startLine = line;
            if (Character.isLetter(c) || c == '_') {
                int j = i + 1;
                while (j < x.length()) {
                    char d = x.charAt(j);
                    if (Character.isLetterOrDigit(d) || d == '_') j++; else break;
                }
                String word = x.substring(i, j);
                kind = isKeyword(word) ? word : "IDENT";
                i = j;
            } else if (Character.isDigit(c)) {
                int j = i + 1;
                while (j < x.length()) {
                    char d = x.charAt(j);
                    if (Character.isLetterOrDigit(d) || d == '_' || d == '.' || d == '+' || d == '-') j++; else break;
                }
                kind = "LIT";
                i = j;
            } else if (c == '"' || c == '\'' || c == '`') {
                char q = c;
                i++;
                while (i < x.length()) {
                    char d = x.charAt(i++);
                    if (d == '\n') line++;
                    if (q != '`' && d == '\\' && i < x.length()) {
                        if (x.charAt(i) == '\n') line++;
                        i++;
                    } else if (d == q) break;
                }
                kind = "LIT";
            } else {
                String two = i + 1 < x.length() ? x.substring(i, i + 2) : "";
                String three = i + 2 < x.length() ? x.substring(i, i + 3) : "";
                if (three.equals("...") || three.equals("<<=") || three.equals(">>=") || three.equals("&^=")) {
                    kind = three; i += 3;
                } else if (Set.of(":=", "++", "--", "==", "!=", "<=", ">=", "&&", "||", "<<", ">>", "&^", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<-").contains(two)) {
                    kind = two; i += 2;
                } else {
                    kind = Character.toString(c); i++;
                }
            }
            Token t = new Token();
            t.kind = kind;
            t.line = startLine;
            t.source = s;
            t.indexInSource = idx++;
            t.global = globalBase + s.tokens.size();
            s.tokens.add(t);
        }
    }

    static boolean isKeyword(String w) {
        return switch (w) {
            case "break","default","func","interface","select","case","defer","go","map","struct",
                 "chan","else","goto","package","switch","const","fallthrough","if","range","type",
                 "continue","for","import","return","var" -> true;
            default -> false;
        };
    }

    static List<Group> findGroups(List<Token> toks, int threshold) {
        Map<String, Group> groups = new LinkedHashMap<>();
        LinkedHashSet<Source> seenSources = new LinkedHashSet<>();
        for (Token t : toks) seenSources.add(t.source);
        for (Source s : seenSources) {
            List<Span> spans = candidateSpans(s);
            for (Span sp : spans) {
                int len = sp.end - sp.start;
                if (len < threshold) continue;
                int globalStart = s.tokens.get(sp.start).global;
                String seq = seqKey(toks, globalStart, len);
                Group g = groups.computeIfAbsent(seq, z -> { Group ng = new Group(); ng.seq = z; ng.len = len; return ng; });
                addOcc(g, makeOcc(toks, globalStart, globalStart + len));
            }
        }
        List<Group> list = new ArrayList<>();
        for (Group g : groups.values()) if (g.occs.size() >= 2) list.add(g);
        for (Group g : list) g.occs.sort(Comparator.comparing((Occ o) -> o.source.path).thenComparingInt(o -> o.startLine).thenComparingInt(o -> o.endLine));
        list.sort(Comparator.comparingInt((Group g) -> g.len).thenComparingInt(Dupl::firstGlobal));
        return list;
    }

    static List<Span> candidateSpans(Source s) {
        ArrayList<Span> out = new ArrayList<>();
        if (!s.tokens.isEmpty()) out.add(new Span(0, s.tokens.size()));
        for (int i = 0; i < s.tokens.size(); i++) {
            String k = s.tokens.get(i).kind;
            if (k.equals("func") || k.equals("if") || k.equals("for") || k.equals("switch") || k.equals("select")) {
                int brace = findNext(s.tokens, i, "{");
                if (brace >= 0) {
                    int end = match(s.tokens, brace, "{", "}");
                    if (end > brace) out.add(new Span(i, end + 1));
                }
            } else if (k.equals("var") || k.equals("const") || k.equals("type") || k.equals("import")) {
                int paren = i + 1 < s.tokens.size() && s.tokens.get(i + 1).kind.equals("(") ? i + 1 : -1;
                if (paren >= 0) {
                    int end = match(s.tokens, paren, "(", ")");
                    if (end > paren) out.add(new Span(i, end + 1));
                }
            }
        }
        out.sort(Comparator.comparingInt((Span sp) -> sp.start).thenComparingInt(sp -> sp.end));
        ArrayList<Span> uniq = new ArrayList<>();
        for (Span sp : out) {
            boolean exists = false;
            for (Span u : uniq) if (u.start == sp.start && u.end == sp.end) { exists = true; break; }
            if (!exists) uniq.add(sp);
        }
        return uniq;
    }

    static int findNext(List<Token> toks, int start, String kind) {
        for (int i = start + 1; i < toks.size(); i++) if (toks.get(i).kind.equals(kind)) return i;
        return -1;
    }

    static int match(List<Token> toks, int open, String ok, String ck) {
        int depth = 0;
        for (int i = open; i < toks.size(); i++) {
            if (toks.get(i).kind.equals(ok)) depth++;
            else if (toks.get(i).kind.equals(ck) && --depth == 0) return i;
        }
        return -1;
    }

    static boolean sameSource(List<Token> t, int s, int e) {
        Source src = t.get(s).source;
        for (int i = s + 1; i < e; i++) if (t.get(i).source != src) return false;
        return true;
    }

    static boolean overlapSameSource(List<Token> t, int a1, int a2, int b1, int b2) {
        return t.get(a1).source == t.get(b1).source && a1 < b2 && b1 < a2;
    }

    static int[] extend(List<Token> t, int a, int b, int len) {
        int as = a, bs = b, ae = a + len, be = b + len;
        while (as > 0 && bs > 0 && t.get(as - 1).source == t.get(as).source && t.get(bs - 1).source == t.get(bs).source &&
                !overlapSameSource(t, as - 1, ae, bs - 1, be) && t.get(as - 1).kind.equals(t.get(bs - 1).kind)) {
            as--; bs--;
        }
        while (ae < t.size() && be < t.size() && t.get(ae).source == t.get(ae - 1).source && t.get(be).source == t.get(be - 1).source &&
                !overlapSameSource(t, as, ae + 1, bs, be + 1) && t.get(ae).kind.equals(t.get(be).kind)) {
            ae++; be++;
        }
        return new int[]{as, ae, bs, be};
    }

    static String seqKey(List<Token> t, int start, int len) {
        StringBuilder sb = new StringBuilder(len * 4);
        for (int i = 0; i < len; i++) sb.append(t.get(start + i).kind).append('\u0001');
        return sb.toString();
    }

    static Occ makeOcc(List<Token> t, int s, int e) {
        Occ o = new Occ();
        o.start = s;
        o.endExclusive = e;
        o.source = t.get(s).source;
        o.startLine = t.get(s).line;
        o.endLine = t.get(e - 1).line;
        return o;
    }

    static void addOcc(Group g, Occ o) {
        for (Occ x : g.occs) if (x.source == o.source && x.startLine == o.startLine && x.endLine == o.endLine) return;
        g.occs.add(o);
    }

    static int firstGlobal(Group g) {
        int m = Integer.MAX_VALUE;
        for (Occ o : g.occs) m = Math.min(m, o.start);
        return m;
    }

    static void printDefault(List<Group> groups) {
        for (Group g : groups) {
            System.out.println("found " + g.occs.size() + " clones:");
            for (Occ o : g.occs) System.out.println("  " + o.source.path + ":" + o.startLine + "," + o.endLine);
            System.out.println();
        }
        System.out.println("Found total " + groups.size() + " clone groups.");
    }

    static void printPlumbing(List<Group> groups) {
        for (Group g : groups) {
            for (int i = 0; i < g.occs.size(); i++) {
                Occ a = g.occs.get(i), b = g.occs.get((i + 1) % g.occs.size());
                System.out.println(a.source.path + ":" + a.startLine + "-" + a.endLine + ": duplicate of " +
                        b.source.path + ":" + b.startLine + "-" + b.endLine);
            }
        }
    }

    static void printHtml(List<Group> groups) {
        System.out.println("<!DOCTYPE html>");
        System.out.println("<meta charset=\"utf-8\"/>");
        System.out.println("<title>Duplicates</title>");
        System.out.println("<style>");
        System.out.println("\tpre {");
        System.out.println("\t\tbackground-color: #FFD;");
        System.out.println("\t\tborder: 1px solid #E2E2E2;");
        System.out.println("\t\tpadding: 1ex;");
        System.out.println("\t}");
        System.out.println("</style>");
        int n = 1;
        for (Group g : groups) {
            System.out.println("<h1>#" + (n++) + " found " + g.occs.size() + " clones</h1>");
            for (Occ o : g.occs) {
                System.out.println("<h2>" + esc(o.source.path) + ":" + o.startLine + "</h2>");
                System.out.println("<pre>" + esc(snippet(o)) + "</pre>");
            }
        }
    }

    static String snippet(Occ o) {
        StringBuilder sb = new StringBuilder();
        int max = Math.min(o.endLine, o.source.lines.length);
        for (int i = o.startLine; i <= max; i++) {
            if (i > o.startLine) sb.append('\n');
            sb.append(o.source.lines[i - 1]);
        }
        return sb.toString();
    }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    static void vlog(String msg) {
        String ts = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss").format(LocalDateTime.now());
        System.err.println(ts + " " + msg);
    }

    static void logErr(String msg) {
        String ts = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss").format(LocalDateTime.now());
        System.err.println(ts + " " + msg);
    }
}
