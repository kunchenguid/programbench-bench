import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Walk {
    private static final String VERSION = "v1.13.0";
    private static final String HELP = """

  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode

""";

    private boolean hideHidden;
    private boolean dirOnly;
    private boolean icons;
    private Path dir;
    private int selected;
    private int renderedLines;

    public static void main(String[] args) throws Exception {
        new Walk().run(args);
    }

    private void run(String[] args) throws Exception {
        for (String arg : args) {
            if ("--version".equals(arg) || "-v".equals(arg)) {
                System.out.println(VERSION);
                return;
            }
            if ("--help".equals(arg) || "-h".equals(arg)) {
                System.err.print(HELP);
                System.exit(1);
            }
        }

        Path start = Paths.get(System.getProperty("user.dir"));
        for (String arg : args) {
            switch (arg) {
                case "--hide-hidden" -> hideHidden = true;
                case "--dir-only" -> dirOnly = true;
                case "--icons" -> icons = true;
                case "--preview", "--with-border", "--fuzzy" -> {
                    // These alter the original TUI, but are not needed for core navigation.
                }
                default -> {
                    if (!arg.startsWith("-")) {
                        start = Paths.get(arg);
                    }
                }
            }
        }
        dir = normalizeStart(start);

        if (!hasTty()) {
            printNoTtyPanic();
            System.exit(2);
        }

        enableRawMode();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                disableRawMode();
                System.out.print("\033[?25h\033[?2004l\033[?1002l\033[?1003l\033[?1006l");
                System.out.flush();
            } catch (Exception ignored) {
            }
        }));

        System.out.print("\033]11;?\033\\\033[6n");
        render();
        try (InputStream in = new BufferedInputStream(new FileInputStream("/dev/tty"))) {
            while (true) {
                int ch = in.read();
                if (ch < 0) break;
                if (ch == 3) {
                    cleanup(false);
                    System.exit(1);
                } else if (ch == 'q' || ch == 27) {
                    // Treat a lone ESC as quit; escape sequences are handled below.
                    if (ch == 27 && in.available() > 0) {
                        handleEscape(in);
                    } else {
                        cleanup(true);
                        return;
                    }
                } else if (ch == 'j') {
                    move(1);
                } else if (ch == 'k') {
                    move(-1);
                } else if (ch == 'g') {
                    selected = 0;
                    render();
                } else if (ch == 'G') {
                    selected = Math.max(0, entries().size() - 1);
                    render();
                } else if (ch == '.' ) {
                    hideHidden = !hideHidden;
                    selected = 0;
                    render();
                } else if (ch == '\r' || ch == '\n') {
                    enter();
                } else if (ch == 127 || ch == 8) {
                    up();
                } else if (ch == '?') {
                    showHelpScreen();
                }
            }
        } finally {
            disableRawMode();
        }
    }

    private static Path normalizeStart(Path p) {
        try {
            if (!Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) {
                Path parent = p.toAbsolutePath().getParent();
                return parent == null ? Paths.get("/").toAbsolutePath().normalize() : parent.normalize();
            }
            return p.toAbsolutePath().normalize();
        } catch (Exception e) {
            return p.toAbsolutePath().normalize();
        }
    }

    private boolean hasTty() {
        try (InputStream ignored = new FileInputStream("/dev/tty")) {
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void printNoTtyPanic() {
        System.err.println("panic: could not open a new TTY: open /dev/tty: no such device or address");
        System.err.println();
        System.err.println("goroutine 1 [running]:");
        System.err.println("main.main()");
        System.err.println("\t/workspace/main.go:135 +0x87d");
    }

    private void enableRawMode() throws IOException, InterruptedException {
        new ProcessBuilder("sh", "-c", "stty raw -echo < /dev/tty").inheritIO().start().waitFor();
    }

    private void disableRawMode() throws IOException, InterruptedException {
        new ProcessBuilder("sh", "-c", "stty sane < /dev/tty").inheritIO().start().waitFor();
    }

    private void handleEscape(InputStream in) throws IOException {
        int a = in.read();
        if (a != '[') {
            cleanup(true);
            System.exit(0);
        }
        int b = in.read();
        switch (b) {
            case 'A' -> move(-1);
            case 'B' -> move(1);
            case 'H' -> {
                selected = 0;
                render();
            }
            case 'F' -> {
                selected = Math.max(0, entries().size() - 1);
                render();
            }
            case '1' -> {
                // Shift-arrow variants often arrive as CSI 1;2A/B/C/D.
                in.read();
                int mod = in.read();
                int key = in.read();
                if (mod == '2' && key == 'A') selected = 0;
                if (mod == '2' && key == 'B') selected = Math.max(0, entries().size() - 1);
                render();
            }
            case '3' -> {
                if (in.read() == '~') deleteSelected();
            }
            default -> {
            }
        }
    }

    private List<Path> entries() {
        List<Path> out = new ArrayList<>();
        try (var stream = Files.list(dir)) {
            stream.forEach(p -> {
                String name = p.getFileName().toString();
                if (hideHidden && name.startsWith(".")) return;
                if (dirOnly && !Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) return;
                out.add(p);
            });
        } catch (IOException ignored) {
        }
        out.sort(Comparator.comparing((Path p) -> p.getFileName().toString().toLowerCase())
                .thenComparing(p -> p.getFileName().toString()));
        if (selected >= out.size()) selected = Math.max(0, out.size() - 1);
        return out;
    }

    private void move(int delta) {
        int size = entries().size();
        if (size > 0) {
            selected = Math.max(0, Math.min(size - 1, selected + delta));
        }
        render();
    }

    private void enter() {
        List<Path> list = entries();
        if (list.isEmpty()) return;
        Path p = list.get(selected);
        if (Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) {
            dir = p.toAbsolutePath().normalize();
            selected = 0;
            render();
        }
    }

    private void up() {
        Path parent = dir.getParent();
        if (parent != null) {
            dir = parent.normalize();
            selected = 0;
            render();
        }
    }

    private void deleteSelected() {
        List<Path> list = entries();
        if (list.isEmpty()) return;
        Path p = list.get(selected);
        try {
            if (Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) {
                Files.delete(p);
            } else {
                Files.deleteIfExists(p);
            }
        } catch (IOException ignored) {
        }
        render();
    }

    private void render() {
        List<Path> list = entries();
        if (renderedLines > 0) {
            System.out.print("\033[" + renderedLines + "A");
        }
        System.out.print("\r" + dir + "\033[K\n");
        if (list.isEmpty()) {
            System.out.print("╭──────────╮\033[K\n│ No files │\033[K\n╰──────────╯\033[K\n");
            renderedLines = 4;
        } else {
            int width = 0;
            for (Path p : list) width = Math.max(width, displayName(p).length());
            for (Path p : list) {
                String name = displayName(p);
                System.out.print(pad(name, width) + "\033[K\n");
            }
            renderedLines = list.size() + 1;
        }
        System.out.print("\033[80D");
        System.out.flush();
    }

    private String displayName(Path p) {
        String name = p.getFileName().toString();
        if (Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) name += "/";
        if (icons) name = iconFor(p) + " " + name;
        return name;
    }

    private String iconFor(Path p) {
        if (Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) return "";
        String n = p.getFileName().toString().toLowerCase();
        if (n.endsWith(".md")) return "";
        if (n.endsWith(".java")) return "";
        if (Files.isExecutable(p)) return "";
        return "";
    }

    private static String pad(String s, int width) {
        return s + " ".repeat(Math.max(0, width - s.length()));
    }

    private void showHelpScreen() {
        if (renderedLines > 0) System.out.print("\033[" + renderedLines + "A");
        String[] lines = HELP.split("\n", -1);
        for (String line : lines) {
            System.out.print(line + "\033[K\n");
        }
        renderedLines = lines.length;
        System.out.print("\033[80D");
        System.out.flush();
    }

    private void cleanup(boolean printDir) {
        if (renderedLines > 0) {
            System.out.print("\033[" + renderedLines + "A");
            for (int i = 0; i < renderedLines; i++) System.out.print("\n");
        }
        System.out.print("\033[K\033[80D\033[2K\r\033[?2004l\033[?25h\033[?1002l\033[?1003l\033[?1006l");
        if (printDir) System.out.println(dir);
        System.out.flush();
    }
}
