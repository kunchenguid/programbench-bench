import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Row {
        String raw;
        LinkedHashMap<String,Object> fields = new LinkedHashMap<>();
        Row(String raw) { this.raw = raw; }
        Row copy() { Row r = new Row(raw); r.fields.putAll(fields); return r; }
    }

    public static void main(String[] args) throws Exception {
        String file = null, output = "legacy", query = null, aliasDir = null;
        boolean noAlias = false;
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("-h") || a.equals("--help")) { help(); return; }
            if (a.equals("-V") || a.equals("--version")) { System.out.println("ag 0.19.6"); return; }
            if ((a.equals("-f") || a.equals("--file")) && i+1<args.length) file=args[++i];
            else if ((a.equals("-o") || a.equals("--output")) && i+1<args.length) output=args[++i];
            else if ((a.equals("-m") || a.equals("--format")) && i+1<args.length) output="format="+args[++i];
            else if ((a.equals("-a") || a.equals("--alias-dir")) && i+1<args.length) { aliasDir=args[++i]; }
            else if (a.equals("--no-alias")) noAlias=true;
            else if (!a.startsWith("-") && query==null) query=a;
            else if (!a.startsWith("-")) query = (query==null ? a : query+" "+a);
        }
        if (query == null) query = "*";
        List<String> lines = new ArrayList<>();
        BufferedReader br = file == null ? new BufferedReader(new InputStreamReader(System.in))
                : Files.newBufferedReader(Paths.get(file));
        for (String s; (s=br.readLine())!=null;) lines.add(s);

        Map<String,String> aliases = noAlias ? Collections.emptyMap() : loadAliases(aliasDir);
        List<String> parts = expandAliases(splitTop(query, '|'), aliases);
        String filter = parts.isEmpty() ? "*" : parts.get(0).trim();
        List<Row> rows = new ArrayList<>();
        for (String line: lines) if (matchFilter(filter, line)) rows.add(new Row(line));
        boolean aggregate = false;
        for (int i=1;i<parts.size();i++) {
            String op = parts.get(i).trim();
            if (op.isEmpty()) continue;
            String low = op.toLowerCase(Locale.ROOT);
            if (low.equals("json") || low.startsWith("json ")) rows = opJson(rows, op);
            else if (low.equals("logfmt") || low.startsWith("logfmt ")) rows = opLogfmt(rows, op);
            else if (low.startsWith("parse regex ")) rows = opParseRegex(rows, op);
            else if (low.startsWith("parse ")) rows = opParse(rows, op);
            else if (low.startsWith("split")) rows = opSplit(rows, op);
            else if (low.startsWith("fields")) rows = opFields(rows, op);
            else if (low.startsWith("where ")) rows = opWhere(rows, op.substring(6).trim());
            else if (low.startsWith("limit ")) rows = opLimit(rows, Integer.parseInt(low.substring(6).trim()));
            else if (low.startsWith("sort by ")) rows = opSort(rows, op.substring(8).trim());
            else if (isAggregate(op)) { rows = opAggregate(rows, op); aggregate = true; }
            else if (low.contains(" as ")) rows = opAssign(rows, op);
        }
        render(rows, output, aggregate);
    }

    static void help() {
        System.out.println("Usage: executable [OPTIONS] [QUERY]\n");
        System.out.println("Arguments:\n  [QUERY]\n          The query\n");
        System.out.println("Options:\n  -f, --file <FILE>\n          Optionally reads from a file instead of Stdin\n");
        System.out.println("  -m, --format <FORMAT>\n          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output\n");
        System.out.println("  -o, --output <OUTPUT>\n          Set output format. Options: \n          - `json`,\n          - `logfmt`\n          - `format=<rust format string>` (eg. -o format='{src} => {dst}'\n          - `legacy` The original output format, auto aligning [k=v]\n");
        System.out.println("  -a, --alias-dir <ALIAS_DIR>\n          Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.\n");
        System.out.println("      --no-alias\n          Disables aliases\n");
        System.out.println("  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n");
        System.out.println("For more details + docs, see https://github.com/rcoh/angle-grinder");
    }

    static Map<String,String> loadAliases(String aliasDir) {
        LinkedHashMap<String,String> out = new LinkedHashMap<>();
        ArrayList<Path> dirs = new ArrayList<>();
        if (aliasDir != null) dirs.add(Paths.get(aliasDir));
        else {
            Path p = Paths.get("").toAbsolutePath();
            while (p != null) { dirs.add(p.resolve(".agrind-aliases")); p = p.getParent(); }
        }
        for (Path d: dirs) if (Files.isDirectory(d)) try (DirectoryStream<Path> ds = Files.newDirectoryStream(d)) {
            for (Path f: ds) if (Files.isRegularFile(f)) {
                String text = Files.readString(f);
                Matcher km = Pattern.compile("(?m)^\\s*keyword\\s*=\\s*\"([^\"]+)\"").matcher(text);
                Matcher tm = Pattern.compile("(?ms)^\\s*template\\s*=\\s*(?:\"\"\"(.*?)\"\"\"|\"(.*?)\")").matcher(text);
                if (km.find() && tm.find()) out.put(km.group(1).trim(), (tm.group(1)!=null?tm.group(1):tm.group(2)).trim());
            }
        } catch (IOException ignored) {}
        return out;
    }
    static List<String> expandAliases(List<String> parts, Map<String,String> aliases) {
        if (aliases.isEmpty()) return parts;
        ArrayList<String> out = new ArrayList<>();
        if (!parts.isEmpty()) out.add(parts.get(0));
        for (int i=1;i<parts.size();i++) {
            String op = parts.get(i).trim();
            String tmpl = aliases.get(op);
            if (tmpl == null) out.add(parts.get(i));
            else out.addAll(splitTop(tmpl, '|'));
        }
        return out;
    }

    static boolean isAggregate(String op) {
        String l=op.toLowerCase(Locale.ROOT).trim();
        return l.equals("count") || l.startsWith("count ") || l.startsWith("count(") ||
                l.startsWith("sum(")||l.startsWith("average(")||l.startsWith("avg(")||
                l.startsWith("min(")||l.startsWith("max(")||l.startsWith("p")||
                l.startsWith("pct")||l.startsWith("total(")||l.startsWith("count_distinct(");
    }

    static List<String> splitTop(String s, char sep) {
        ArrayList<String> out = new ArrayList<>();
        int par=0, br=0; char quote=0; boolean esc=false; int start=0;
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (esc) { esc=false; continue; }
            if (c=='\\') { esc=true; continue; }
            if (quote!=0) { if (c==quote) quote=0; continue; }
            if (c=='"' || c=='\'') { quote=c; continue; }
            if (c=='(') par++; else if(c==')') par=Math.max(0,par-1);
            else if(c=='[') br++; else if(c==']') br=Math.max(0,br-1);
            else if(c==sep && par==0 && br==0) { out.add(s.substring(start,i)); start=i+1; }
        }
        out.add(s.substring(start)); return out;
    }

    static boolean matchFilter(String f, String line) {
        f=f.trim(); if (f.isEmpty()||f.equals("*")) return true;
        return evalFilter(f, line);
    }
    static boolean evalFilter(String f, String line) {
        f=stripOuter(f.trim());
        List<String> ors=splitWordTop(f,"OR");
        if (ors.size()>1) { for(String p:ors) if(evalFilter(p,line)) return true; return false; }
        List<String> ands=splitWordTop(f,"AND");
        if (ands.size()>1) { for(String p:ands) if(!evalFilter(p,line)) return false; return true; }
        if (f.toUpperCase(Locale.ROOT).startsWith("NOT ")) return !evalFilter(f.substring(4),line);
        if ((f.startsWith("\"")&&f.endsWith("\"")) || (f.startsWith("'")&&f.endsWith("'"))) return line.contains(unquote(f));
        String pat = Pattern.quote(f).replace("*", "\\E.*\\Q");
        return Pattern.compile(pat, Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(line).find();
    }
    static String stripOuter(String s) {
        while (s.startsWith("(")&&s.endsWith(")")) {
            int d=0; boolean ok=true; char q=0;
            for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(q!=0){if(c==q)q=0;continue;} if(c=='"'||c=='\''){q=c;continue;} if(c=='(')d++; if(c==')')d--; if(d==0&&i<s.length()-1){ok=false;break;}}
            if(ok) s=s.substring(1,s.length()-1).trim(); else break;
        }
        return s;
    }
    static List<String> splitWordTop(String s, String word) {
        ArrayList<String> out=new ArrayList<>(); int par=0; char q=0; int st=0;
        for(int i=0;i<=s.length()-word.length();i++){ char c=s.charAt(i); if(q!=0){if(c==q)q=0;continue;} if(c=='"'||c=='\''){q=c;continue;} if(c=='(')par++; else if(c==')')par--; if(par==0 && s.regionMatches(true,i,word,0,word.length()) && (i==0||Character.isWhitespace(s.charAt(i-1))) && (i+word.length()==s.length()||Character.isWhitespace(s.charAt(i+word.length())))){ out.add(s.substring(st,i).trim()); st=i+word.length(); }}
        if(st==0) return Collections.singletonList(s); out.add(s.substring(st).trim()); return out;
    }

    static List<Row> opJson(List<Row> rows, String op) {
        String from=null; Matcher m=Pattern.compile("(?i)json\\s+from\\s+(.+)").matcher(op); if(m.find()) from=m.group(1).trim();
        ArrayList<Row> out=new ArrayList<>();
        for(Row r:rows){ Object src=from==null?r.raw:get(r,from); if(src==null) continue; try{ Object val=new Json(String.valueOf(src)).parse(); if(val instanceof Map){ Row nr=r.copy(); flattenInto(nr.fields,"",(Map<?,?>)val); out.add(nr);} }catch(Exception ignored){} }
        return out;
    }
    static void flattenInto(Map<String,Object> dest, String pref, Map<?,?> map) {
        for (Map.Entry<?,?> e: map.entrySet()) {
            String k = pref.isEmpty()?String.valueOf(e.getKey()):pref+"."+e.getKey();
            dest.put(k, e.getValue());
        }
    }
    static List<Row> opLogfmt(List<Row> rows, String op) {
        String from=null; Matcher m=Pattern.compile("(?i)logfmt\\s+from\\s+(.+)").matcher(op); if(m.find()) from=m.group(1).trim();
        ArrayList<Row> out=new ArrayList<>();
        for(Row r:rows){ Object src=from==null?r.raw:get(r,from); if(src==null) continue; LinkedHashMap<String,Object> vals=parseLogfmt(String.valueOf(src)); if(!vals.isEmpty()){ Row nr=r.copy(); nr.fields.putAll(vals); out.add(nr);} }
        return out;
    }
    static LinkedHashMap<String,Object> parseLogfmt(String s) {
        LinkedHashMap<String,Object> m=new LinkedHashMap<>(); int i=0,n=s.length();
        while(i<n){ while(i<n&&Character.isWhitespace(s.charAt(i)))i++; int ks=i; while(i<n&&s.charAt(i)!='='&&!Character.isWhitespace(s.charAt(i)))i++; if(i>=n||s.charAt(i)!='='){while(i<n&&!Character.isWhitespace(s.charAt(i)))i++; continue;} String k=s.substring(ks,i++); String v; if(i<n&&s.charAt(i)=='"'){i++; StringBuilder b=new StringBuilder(); while(i<n){char c=s.charAt(i++); if(c=='"')break; if(c=='\\'&&i<n)c=s.charAt(i++); b.append(c);} v=b.toString();} else {int vs=i; while(i<n&&!Character.isWhitespace(s.charAt(i)))i++; v=s.substring(vs,i);} m.put(k, convert(v)); }
        return m;
    }

    static List<Row> opParse(List<Row> rows, String op) {
        Matcher mm=Pattern.compile("(?i)^parse\\s+([\"']).*").matcher(op); if(!mm.find()) return rows;
        char q=op.trim().charAt(6); int start=op.indexOf(q)+1; int end=findQuote(op,start,q); if(end<0)return rows;
        String pat=op.substring(start,end); String rest=op.substring(end+1).trim();
        String from=null; Matcher fm=Pattern.compile("(?i)\\bfrom\\s+([^\\s]+)").matcher(rest); if(fm.find()) from=fm.group(1).trim();
        Matcher am=Pattern.compile("(?i)\\bas\\s+(.+?)(\\s+nodrop|\\s+noconvert|$)").matcher(rest); if(!am.find())return rows;
        List<String> names=new ArrayList<>(); for(String x:am.group(1).split(",")) names.add(x.trim());
        boolean nodrop=rest.toLowerCase(Locale.ROOT).contains("nodrop"), noconv=rest.toLowerCase(Locale.ROOT).contains("noconvert");
        Pattern re=Pattern.compile(patternToRegex(pat), Pattern.DOTALL);
        ArrayList<Row> out=new ArrayList<>();
        for(Row r:rows){ Object src=from==null?r.raw:get(r,from); Matcher m=re.matcher(src==null?"":String.valueOf(src)); if(m.find()){ Row nr=r.copy(); for(int i=0;i<names.size()&&i<m.groupCount();i++) nr.fields.put(names.get(i), noconv?m.group(i+1):convert(m.group(i+1))); out.add(nr);} else if(nodrop) out.add(r); }
        return out;
    }
    static String patternToRegex(String pat){ StringBuilder b=new StringBuilder("^"); int last=0; int stars=0; for(int i=0;i<pat.length();i++) if(pat.charAt(i)=='*'){ b.append(Pattern.quote(pat.substring(last,i)).replace("\\ ","\\s+")); stars++; b.append(stars==countStars(pat)?"(.*)":"(.*?)"); last=i+1;} b.append(Pattern.quote(pat.substring(last)).replace("\\ ","\\s+")).append("$"); return b.toString(); }
    static int countStars(String s){int c=0;for(char ch:s.toCharArray())if(ch=='*')c++;return c;}
    static int findQuote(String s,int start,char q){boolean esc=false;for(int i=start;i<s.length();i++){char c=s.charAt(i); if(esc){esc=false;continue;} if(c=='\\'){esc=true;continue;} if(c==q)return i;}return -1;}
    static List<Row> opParseRegex(List<Row> rows, String op) {
        char q=op.contains("\"")?'"':'\''; int st=op.indexOf(q)+1,en=findQuote(op,st,q); if(st<=0||en<0)return rows; String rx=op.substring(st,en), rest=op.substring(en+1);
        ArrayList<String> names=new ArrayList<>(); Matcher nm=Pattern.compile("\\(\\?P<([A-Za-z_][A-Za-z0-9_]*)>").matcher(rx); String javaRx=rx; while(nm.find())names.add(nm.group(1)); javaRx=javaRx.replaceAll("\\(\\?P<([A-Za-z_][A-Za-z0-9_]*)>","(?<$1>");
        String from=null; Matcher fm=Pattern.compile("(?i)\\bfrom\\s+([^\\s]+)").matcher(rest); if(fm.find())from=fm.group(1); boolean nodrop=rest.toLowerCase().contains("nodrop");
        Pattern p=Pattern.compile(javaRx); ArrayList<Row> out=new ArrayList<>();
        for(Row r:rows){Object src=from==null?r.raw:get(r,from); Matcher m=p.matcher(src==null?"":String.valueOf(src)); if(m.find()){Row nr=r.copy(); for(String name:names)nr.fields.put(name,convert(m.group(name))); out.add(nr);} else if(nodrop)out.add(r);}
        return out;
    }
    static List<Row> opSplit(List<Row> rows, String op) {
        String field=null, sep=",", as=null; Matcher fm=Pattern.compile("split\\s*\\(([^)]*)\\)",Pattern.CASE_INSENSITIVE).matcher(op); if(fm.find()) field=fm.group(1).trim();
        Matcher sm=Pattern.compile("(?i)\\bon\\s+([\"'])(.*?)\\1").matcher(op); if(sm.find()) sep=sm.group(2);
        Matcher am=Pattern.compile("(?i)\\bas\\s+([^\\s]+)").matcher(op); if(am.find()) as=am.group(1).trim(); if(as==null) as=field==null?"_split":field;
        ArrayList<Row> out=new ArrayList<>(); for(Row r:rows){Object src=field==null?r.raw:get(r,field); Row nr=r.copy(); nr.fields.put(as, Arrays.asList(String.valueOf(src==null?"":src).split(Pattern.quote(sep),-1))); out.add(nr);} return out;
    }
    static List<Row> opFields(List<Row> rows, String op) {
        String rest=op.replaceFirst("(?i)^fields\\s*","").trim(); boolean only=false;
        if(rest.startsWith("+")||rest.toLowerCase().startsWith("only")){only=true; rest=rest.replaceFirst("(?i)^(\\+|only)\\s*","");}
        else rest=rest.replaceFirst("(?i)^(except|-)\\s*","");
        Set<String> fs=new LinkedHashSet<>(); for(String x:rest.split(",")) if(!x.trim().isEmpty()) fs.add(x.trim());
        for(Row r:rows){ if(only) r.fields.keySet().removeIf(k->!fs.contains(k)); else r.fields.keySet().removeIf(fs::contains); } return rows;
    }
    static List<Row> opWhere(List<Row> rows, String expr){ ArrayList<Row> out=new ArrayList<>(); for(Row r:rows) if(truth(eval(expr,r))) out.add(r); return out; }
    static List<Row> opLimit(List<Row> rows, int n){ if(n>=0)return new ArrayList<>(rows.subList(0,Math.min(n,rows.size()))); int k=Math.min(-n,rows.size()); return new ArrayList<>(rows.subList(rows.size()-k,rows.size())); }
    static List<Row> opAssign(List<Row> rows, String op){ Matcher m=Pattern.compile("(?i)(.+)\\s+as\\s+([^\\s]+)$").matcher(op); if(!m.find())return rows; for(Row r:rows)r.fields.put(m.group(2),eval(m.group(1),r)); return rows; }

    static List<Row> opSort(List<Row> rows, String spec) {
        boolean desc=spec.toLowerCase(Locale.ROOT).endsWith(" desc"); boolean asc=spec.toLowerCase(Locale.ROOT).endsWith(" asc");
        if(desc||asc) spec=spec.substring(0,spec.lastIndexOf(' ')).trim();
        List<String> keys=splitTop(spec, ',');
        rows.sort((a,b)->{ for(String k:keys){ int c=cmp(eval(k.trim(),a),eval(k.trim(),b)); if(c!=0)return desc?-c:c;} return 0;});
        return rows;
    }
    static int cmp(Object a,Object b){ Double da=num(a),db=num(b); if(da!=null&&db!=null)return Double.compare(da,db); return String.valueOf(a).compareTo(String.valueOf(b)); }

    static List<Row> opAggregate(List<Row> rows, String op) {
        String agPart=op, byPart=""; int by=indexWordTop(op,"by"); if(by>=0){agPart=op.substring(0,by).trim(); byPart=op.substring(by+2).trim();}
        List<String> bys=byPart.isEmpty()?Collections.emptyList():splitTop(byPart, ',');
        List<String> ags=splitTop(agPart, ',');
        LinkedHashMap<String,Group> groups=new LinkedHashMap<>();
        for(Row r:rows){ ArrayList<Object> keyVals=new ArrayList<>(); StringBuilder ks=new StringBuilder(); for(String b:bys){Object v=eval(b.trim(),r); keyVals.add(v); ks.append("\u0001").append(String.valueOf(v));} groups.computeIfAbsent(ks.toString(),k->new Group(keyVals,ags)).add(r); }
        if(groups.isEmpty() && bys.isEmpty()) groups.put("", new Group(Collections.emptyList(),ags));
        ArrayList<Row> out=new ArrayList<>();
        for(Group g:groups.values()){ Row nr=new Row(""); for(int i=0;i<bys.size();i++) nr.fields.put(cleanName(bys.get(i).trim()), g.keys.get(i)); nr.fields.putAll(g.finish()); out.add(nr); }
        if (!bys.isEmpty()) out.sort((a,b)->{ for(String byExpr:bys){ String k=cleanName(byExpr.trim()); int c=cmp(a.fields.get(k), b.fields.get(k)); if(c!=0)return c; } return 0; });
        return out;
    }
    static int indexWordTop(String s,String w){ List<String> tmp=splitWordTop(s,w); return tmp.size()>1?tmp.get(0).length()+1:-1; }
    static class Group {
        List<Object> keys; List<Agg> ags=new ArrayList<>();
        Group(List<Object> k,List<String> specs){keys=k; for(String s:specs)ags.add(new Agg(s.trim()));}
        void add(Row r){for(Agg a:ags)a.add(r);}
        LinkedHashMap<String,Object> finish(){LinkedHashMap<String,Object> m=new LinkedHashMap<>(); for(Agg a:ags)m.put(a.name,a.value()); return m;}
    }
    static class Agg {
        String type,arg,name; int count=0; double sum=0,min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY; ArrayList<Double> vals=new ArrayList<>(); LinkedHashSet<String> distinct=new LinkedHashSet<>();
        Agg(String spec){ Matcher as=Pattern.compile("(?i)(.+?)\\s+as\\s+([^\\s]+)$").matcher(spec); if(as.find()){spec=as.group(1).trim();name=as.group(2);} String l=spec.toLowerCase(); if(l.equals("count")){type="count"; if(name==null)name="_count";} else {Matcher m=Pattern.compile("([A-Za-z0-9_]+)\\((.*)\\)").matcher(spec); if(m.find()){type=m.group(1).toLowerCase();arg=m.group(2).trim();} else {type=l.split("\\s+")[0];} if(type.equals("avg"))type="average"; if(type.startsWith("pct"))type="p"+type.substring(3); if(name==null) name= type.equals("sum")?"_sum":type.equals("average")?"_average":type.equals("min")?"_min":type.equals("max")?"_max":type.equals("count_distinct")?"_count_distinct":"_"+type;}}
        void add(Row r){ if(type.equals("count")){ if(arg==null||truth(eval(arg,r)))count++; return;} Object v=eval(arg,r); if(type.equals("count_distinct")){distinct.add(String.valueOf(v));return;} Double d=num(v); if(d==null)return; count++; sum+=d; min=Math.min(min,d); max=Math.max(max,d); vals.add(d); }
        Object value(){ if(type.equals("count"))return count; if(type.equals("sum"))return nice(sum); if(type.equals("average"))return count==0?null:sum/count; if(type.equals("min"))return count==0?null:nice(min); if(type.equals("max"))return count==0?null:nice(max); if(type.equals("count_distinct"))return distinct.size(); if(type.startsWith("p")){ if(vals.isEmpty())return null; Collections.sort(vals); double p=Double.parseDouble(type.substring(1)); int idx=(int)Math.ceil((p/100.0)*vals.size())-1; idx=Math.max(0,Math.min(idx,vals.size()-1)); return nice(vals.get(idx)); } if(type.equals("total"))return nice(sum); return count; }
    }

    static String cleanName(String s){ return s.replaceAll("[^A-Za-z0-9_.-]+","_"); }
    static Object nice(double d){ if(Math.rint(d)==d && d<=Long.MAX_VALUE && d>=Long.MIN_VALUE)return (long)d; return d; }
    static Object convert(String s){ if(s==null)return null; if(s.equalsIgnoreCase("true"))return true; if(s.equalsIgnoreCase("false"))return false; if(s.equalsIgnoreCase("null"))return null; try{ if(s.matches("[-+]?\\d+"))return Long.parseLong(s); if(s.matches("[-+]?(\\d+\\.\\d*|\\d*\\.\\d+)([eE][-+]?\\d+)?|[-+]?\\d+[eE][-+]?\\d+"))return Double.parseDouble(s);}catch(Exception ignored){} return s; }

    static Object get(Row r,String path){ path=path.trim(); if(path.equals("_raw")||path.equals("raw"))return r.raw; if((path.startsWith("\"")&&path.endsWith("\""))||(path.startsWith("'")&&path.endsWith("'")))return unquote(path); Object cur=r.fields.get(path); if(cur!=null||r.fields.containsKey(path))return cur; String[] ps=path.split("\\."); cur=r.fields.get(ps[0]); for(int i=1;i<ps.length&&cur!=null;i++){ if(cur instanceof Map)cur=((Map<?,?>)cur).get(ps[i]); else return r.fields.get(path);} return cur; }
    static String unquote(String s){ if(s.length()>=2&&(s.charAt(0)=='"'||s.charAt(0)=='\''))s=s.substring(1,s.length()-1); return s.replace("\\\"","\"").replace("\\'","'").replace("\\n","\n").replace("\\t","\t").replace("\\\\","\\"); }
    static boolean truth(Object v){ if(v==null)return false; if(v instanceof Boolean)return (Boolean)v; if(v instanceof Number)return ((Number)v).doubleValue()!=0; return !String.valueOf(v).isEmpty(); }
    static Double num(Object v){ if(v instanceof Number)return ((Number)v).doubleValue(); try{return Double.parseDouble(String.valueOf(v));}catch(Exception e){return null;} }

    static Object eval(String expr, Row r){ return new Expr(expr,r).parse(); }
    static class Expr {
        String s; int p=0; Row r; Expr(String s,Row r){this.s=s;this.r=r;}
        Object parse(){ return or(); }
        void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        boolean eat(String x){ws(); if(s.regionMatches(true,p,x,0,x.length())){p+=x.length();return true;} return false;}
        Object or(){Object a=and(); while(true){ if(eat("||")||eat("or")) a=truth(a)||truth(and()); else return a;}}
        Object and(){Object a=cmp(); while(true){ if(eat("&&")||eat("and")) a=truth(a)&&truth(cmp()); else return a;}}
        Object cmp(){Object a=add(); String[] ops={"==","!=","<>","<=",">=","<",">"}; while(true){ws(); String op=null; for(String o:ops)if(s.startsWith(o,p)){op=o;p+=o.length();break;} if(op==null)return a; Object b=add(); int c=Main.cmp(a,b); boolean eq=Objects.equals(String.valueOf(a),String.valueOf(b)) || (num(a)!=null&&num(b)!=null&&Double.compare(num(a),num(b))==0); a=op.equals("==")?eq:op.equals("!=")||op.equals("<>")?!eq:op.equals("<=")?c<=0:op.equals(">=")?c>=0:op.equals("<")?c<0:c>0; }}
        Object add(){Object a=mul(); while(true){ if(eat("+")){Object b=mul(); Double da=num(a),db=num(b); a=(da!=null&&db!=null)?nice(da+db):String.valueOf(a)+String.valueOf(b);} else if(eat("-")){Double da=num(a),db=num(mul()); a=(da==null||db==null)?null:nice(da-db);} else return a;}}
        Object mul(){Object a=unary(); while(true){ if(eat("*")){Double da=num(a),db=num(unary()); a=(da==null||db==null)?null:nice(da*db);} else if(eat("/")){Double da=num(a),db=num(unary()); a=(da==null||db==null||db==0)?null:da/db;} else return a;}}
        Object unary(){ if(eat("!"))return !truth(unary()); if(eat("-")){Double d=num(unary()); return d==null?null:nice(-d);} return prim(); }
        Object prim(){ ws(); if(p>=s.length())return null; char c=s.charAt(p); if(c=='('){p++; Object v=or(); eat(")"); return v;} if(c=='"'||c=='\''){int st=++p; StringBuilder b=new StringBuilder(); boolean esc=false; while(p<s.length()){char ch=s.charAt(p++); if(esc){b.append(ch=='n'?'\n':ch=='t'?'\t':ch);esc=false;} else if(ch=='\\')esc=true; else if(ch==c)break; else b.append(ch);} return b.toString();} int st=p; while(p<s.length()&&(Character.isLetterOrDigit(s.charAt(p))||"._[]".indexOf(s.charAt(p))>=0))p++; String id=s.substring(st,p); ws(); if(eat("(")){List<Object> args=new ArrayList<>(); if(!eat(")")){do{args.add(or());}while(eat(",")); eat(")");} return func(id,args);} if(id.matches("[-+]?\\d+(\\.\\d+)?"))return convert(id); if(id.equalsIgnoreCase("true")||id.equalsIgnoreCase("false")||id.equalsIgnoreCase("null"))return convert(id); return get(r,id); }
        Object func(String id,List<Object> a){ id=id.toLowerCase(); if(id.equals("if"))return truth(a.get(0))?a.get(1):a.get(2); if(id.equals("concat")){StringBuilder b=new StringBuilder(); for(Object x:a)b.append(x==null?"":x); return b.toString();} if(id.equals("contains"))return String.valueOf(a.get(0)).contains(String.valueOf(a.get(1))); if(id.equals("length"))return String.valueOf(a.get(0)).length(); if(id.equals("tolowercase"))return String.valueOf(a.get(0)).toLowerCase(); if(id.equals("touppercase"))return String.valueOf(a.get(0)).toUpperCase(); if(id.equals("isempty"))return a.get(0)==null||String.valueOf(a.get(0)).isEmpty(); if(id.equals("isblank"))return a.get(0)==null||String.valueOf(a.get(0)).trim().isEmpty(); if(id.equals("isnull"))return a.get(0)==null; if(id.equals("isnumeric"))return num(a.get(0))!=null; if(id.equals("num"))return num(a.get(0)); if(id.equals("parsehex"))return Long.parseLong(String.valueOf(a.get(0)),16); if(id.equals("substring")){String x=String.valueOf(a.get(0)); int st=num(a.get(1)).intValue(); int en=a.size()>2?num(a.get(2)).intValue():x.length(); return x.substring(Math.max(0,st),Math.min(x.length(),en));} if(id.equals("now"))return Instant.now().toString(); Double x=a.isEmpty()?null:num(a.get(0)); if(x==null)return null; switch(id){case"abs":return Math.abs(x);case"ceil":return Math.ceil(x);case"floor":return Math.floor(x);case"round":return Math.round(x);case"sqrt":return Math.sqrt(x);case"sin":return Math.sin(x);case"cos":return Math.cos(x);case"tan":return Math.tan(x);case"log":return Math.log(x);case"log10":return Math.log10(x);case"todegrees":return Math.toDegrees(x);case"toradians":return Math.toRadians(x);} return null; }
    }

    static void render(List<Row> rows,String out,boolean aggregate){
        if(out.equals("json")){ if(aggregate){System.out.println(json(rows.stream().map(r->r.fields).toList()));} else for(Row r:rows)System.out.println(json(sortedMap(r.fields))); return; }
        if(out.equals("logfmt")){ for(Row r:rows)System.out.println(logfmt(r.fields)); return; }
        if(out.startsWith("format=")){String f=out.substring(7); for(Row r:rows){String z=f; for(String k:r.fields.keySet())z=z.replace("{"+k+"}",String.valueOf(r.fields.get(k))); System.out.println(z);} return;}
        if(aggregate) renderTable(rows); else for(Row r:rows){ if(r.fields.isEmpty())System.out.println(r.raw); else {List<String> ks=new ArrayList<>(r.fields.keySet()); Collections.sort(ks); ArrayList<String> cells=new ArrayList<>(); for(String k:ks)cells.add("["+k+"="+val(r.fields.get(k))+"]"); System.out.println(String.join("        ",cells));}}
    }
    static void renderTable(List<Row> rows){ if(rows.isEmpty())return; List<String> cols=new ArrayList<>(rows.get(0).fields.keySet()); int[] w=new int[cols.size()]; for(int i=0;i<cols.size();i++)w[i]=cols.get(i).length(); for(Row r:rows)for(int i=0;i<cols.size();i++)w[i]=Math.max(w[i],fmtTable(r.fields.get(cols.get(i))).length()); StringBuilder h=new StringBuilder(); for(int i=0;i<cols.size();i++)h.append(pad(cols.get(i),w[i]+8)); System.out.println(rtrim(h.toString())); int len=0; for(int x:w)len+=x+8; System.out.println("-".repeat(Math.max(14,len-1))); for(Row r:rows){StringBuilder b=new StringBuilder(); for(int i=0;i<cols.size();i++)b.append(pad(fmtTable(r.fields.get(cols.get(i))),w[i]+8)); System.out.println(rtrim(b.toString()));}}
    static String fmtTable(Object v){ if(v instanceof Double||v instanceof Float){double d=((Number)v).doubleValue(); if(Math.rint(d)==d)return String.valueOf((long)d); return String.format(Locale.ROOT,"%.2f",d);} return val(v); }
    static String pad(String s,int n){return s+" ".repeat(Math.max(0,n-s.length()));}
    static String rtrim(String s){return s.replaceFirst("\\s+$","");}
    static String val(Object v){ if(v==null)return "null"; if(v instanceof List<?> l){ArrayList<String> a=new ArrayList<>(); for(Object x:l)a.add(val(x)); return "["+String.join(", ",a)+"]";} return String.valueOf(v); }
    static String logfmt(Map<String,Object> m){List<String> ks=new ArrayList<>(m.keySet()); Collections.sort(ks); ArrayList<String> out=new ArrayList<>(); for(String k:ks){String v=val(m.get(k)); if(v.contains(" ")||v.contains("\""))v="\""+v.replace("\\","\\\\").replace("\"","\\\"")+"\""; out.add(k+"="+v);} return String.join(" ",out);}
    static Map<String,Object> sortedMap(Map<String,Object> in){ LinkedHashMap<String,Object> m=new LinkedHashMap<>(); List<String> ks=new ArrayList<>(in.keySet()); Collections.sort(ks); for(String k:ks)m.put(k,in.get(k)); return m; }
    static String json(Object o){ if(o==null)return"null"; if(o instanceof String)return"\""+((String)o).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\t","\\t")+"\""; if(o instanceof Number){ if(o instanceof Double||o instanceof Float){double d=((Number)o).doubleValue(); if(Math.rint(d)==d)return String.valueOf((long)d);} return String.valueOf(o);} if(o instanceof Boolean)return String.valueOf(o); if(o instanceof Map<?,?> m){StringBuilder b=new StringBuilder("{"); boolean first=true; for(Object k:m.keySet()){ if(!first)b.append(","); first=false; b.append(json(String.valueOf(k))).append(":").append(json(m.get(k)));} return b.append("}").toString();} if(o instanceof Iterable<?> it){StringBuilder b=new StringBuilder("["); boolean first=true; for(Object x:it){if(!first)b.append(","); first=false; b.append(json(x));} return b.append("]").toString();} return json(String.valueOf(o));}

    static class Json {
        String s; int p=0; Json(String s){this.s=s.trim();}
        Object parse(){ws(); return val();}
        void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
        Object val(){ws(); char c=s.charAt(p); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='"')return str(); if(s.startsWith("true",p)){p+=4;return true;} if(s.startsWith("false",p)){p+=5;return false;} if(s.startsWith("null",p)){p+=4;return null;} return numv();}
        Map<String,Object> obj(){LinkedHashMap<String,Object> m=new LinkedHashMap<>(); p++; ws(); if(s.charAt(p)=='}'){p++;return m;} do{String k=str(); ws(); p++; Object v=val(); m.put(k,v); ws();}while(s.charAt(p++)==','); return m;}
        List<Object> arr(){ArrayList<Object> a=new ArrayList<>(); p++; ws(); if(s.charAt(p)==']'){p++;return a;} do{a.add(val()); ws();}while(s.charAt(p++)==','); return a;}
        String str(){StringBuilder b=new StringBuilder(); p++; while(p<s.length()){char c=s.charAt(p++); if(c=='"')break; if(c=='\\'){char e=s.charAt(p++); if(e=='n')b.append('\n'); else if(e=='t')b.append('\t'); else if(e=='r')b.append('\r'); else if(e=='b')b.append('\b'); else if(e=='f')b.append('\f'); else if(e=='u'){b.append((char)Integer.parseInt(s.substring(p,p+4),16)); p+=4;} else b.append(e);} else b.append(c);} return b.toString();}
        Object numv(){int st=p; while(p<s.length()&&"-+.0123456789eE".indexOf(s.charAt(p))>=0)p++; return convert(s.substring(st,p));}
    }
}
