import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Delta {
    static final String ESC = "\u001b[";
    static final String RESET = ESC + "0m";
    static final String BLUE = ESC + "34m";
    static final String RED = ESC + "31m";
    static final String GREEN = ESC + "32m";
    static final String CYAN = ESC + "36m";
    static final String BOLD = ESC + "1m";
    static final String MINUS_BG = ESC + "48;5;52m";
    static final String PLUS_BG = ESC + "48;5;22m";
    static final String SYNTAX = ESC + "38;5;231m";

    static class Opts {
        boolean raw, colorOnly, keepMarkers, lineNumbers, sideBySide, hyperlinks, parseAnsi;
        boolean noColor;
        int width = 80;
        String pager = "";
        List<String> files = new ArrayList<>();
    }

    static final Set<String> VALUE_OPTIONS = new HashSet<>(Arrays.asList(
            "--blame-code-style","--blame-format","--blame-palette","--blame-separator-format",
            "--blame-separator-style","--blame-timestamp-format","--blame-timestamp-output-format",
            "--config","--commit-decoration-style","--commit-regex","--commit-style",
            "--default-language","--detect-dark-light","--diff-args","-@","--diff-stat-align-width",
            "--features","--file-added-label","--file-copied-label","--file-decoration-style",
            "--file-modified-label","--file-removed-label","--file-renamed-label","--file-style",
            "--file-transformation","--generate-completion","--grep-context-line-style",
            "--grep-file-style","--grep-header-decoration-style","--grep-header-file-style",
            "--grep-line-number-style","--grep-output-type","--grep-match-line-style",
            "--grep-match-word-style","--grep-separator-symbol","--hunk-header-decoration-style",
            "--hunk-header-file-style","--hunk-header-line-number-style","--hunk-header-style",
            "--hunk-label","--hyperlinks-commit-link-format","--hyperlinks-file-link-format",
            "--inline-hint-style","--inspect-raw-lines","--line-buffer-size","--line-fill-method",
            "--line-numbers-left-format","--line-numbers-left-style","--line-numbers-minus-style",
            "--line-numbers-plus-style","--line-numbers-right-format","--line-numbers-right-style",
            "--line-numbers-zero-style","--map-styles","--max-line-distance",
            "--max-syntax-highlighting-length","--max-line-length","--merge-conflict-begin-symbol",
            "--merge-conflict-end-symbol","--merge-conflict-ours-diff-header-decoration-style",
            "--merge-conflict-ours-diff-header-style","--merge-conflict-theirs-diff-header-decoration-style",
            "--merge-conflict-theirs-diff-header-style","--minus-empty-line-marker-style",
            "--minus-emph-style","--minus-non-emph-style","--minus-style","--navigate-regex",
            "--pager","--paging","--plus-emph-style","--plus-empty-line-marker-style",
            "--plus-non-emph-style","--plus-style","--right-arrow","--syntax-theme",
            "--tabs","--true-color","--whitespace-error-style","--width","--word-diff-regex",
            "--wrap-left-symbol","--wrap-max-lines","--wrap-right-percent",
            "--wrap-right-prefix-symbol","--wrap-right-symbol","--zero-style","--24-bit-color"
    ));

    public static void main(String[] args) throws Exception {
        Opts opts = new Opts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-h")) { printHelp(); return; }
            if (a.equals("--version") || a.equals("-V")) { System.out.println("delta 0.18.2"); return; }
            if (a.equals("--list-syntax-themes")) { printThemes(); return; }
            if (a.equals("--list-languages")) { printLanguages(); return; }
            if (a.equals("--show-config")) { printConfig(); return; }
            if (a.equals("--show-colors")) { printColors(); return; }
            if (a.equals("--show-themes") || a.equals("--show-syntax-themes")) { showSyntaxThemes(); return; }
            if (a.equals("--generate-completion")) { if (i + 1 < args.length) i++; printCompletion(); return; }
            if (a.startsWith("--generate-completion=")) { printCompletion(); return; }
            if (a.equals("--raw")) opts.raw = true;
            else if (a.equals("--color-only")) opts.colorOnly = true;
            else if (a.equals("--keep-plus-minus-markers")) opts.keepMarkers = true;
            else if (a.equals("--line-numbers") || a.equals("-n")) opts.lineNumbers = true;
            else if (a.equals("--side-by-side")) opts.sideBySide = true;
            else if (a.equals("--hyperlinks")) opts.hyperlinks = true;
            else if (a.equals("--parse-ansi")) opts.parseAnsi = true;
            else if (a.equals("--no-gitconfig") || a.equals("--dark") || a.equals("--light")
                    || a.equals("--diff-highlight") || a.equals("--diff-so-fancy")
                    || a.equals("--navigate") || a.equals("--relative-paths")) {
                // accepted no-op
            } else if (a.startsWith("--width=")) opts.width = parseInt(a.substring(8), 80);
            else if (a.equals("--width") && i + 1 < args.length) opts.width = parseInt(args[++i], 80);
            else if (a.startsWith("--paging=") || a.startsWith("--pager=") || a.startsWith("--syntax-theme=")) {
                // accepted no-op
            } else if (VALUE_OPTIONS.contains(a)) {
                if (i + 1 < args.length) i++;
            } else if (a.startsWith("--") && a.contains("=")) {
                // Unknown value-style delta options are ignored for compatibility.
            } else if (a.startsWith("-") && !a.equals("-")) {
                // Unknown switches are ignored; delta has a very large option surface.
            } else {
                opts.files.add(a);
            }
        }

        List<String> lines;
        if (opts.files.size() >= 2) lines = runDiff(opts.files.get(0), opts.files.get(1));
        else lines = readStdin();

        if (opts.parseAnsi) {
            for (String line : lines) System.out.println(visibleAnsi(line));
            return;
        }
        render(lines, opts);
    }

    static List<String> runDiff(String a, String b) throws Exception {
        List<String> cmd = Arrays.asList("git", "diff", "--no-index", "--no-color", a, b);
        Process p;
        try {
            p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        } catch (IOException e) {
            p = new ProcessBuilder(Arrays.asList("diff", "-u", a, b)).redirectErrorStream(true).start();
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        p.getInputStream().transferTo(out);
        p.waitFor();
        return Arrays.asList(out.toString(StandardCharsets.UTF_8).split("\\R", -1));
    }

    static List<String> readStdin() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        List<String> lines = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) lines.add(line);
        return lines;
    }

    static void render(List<String> lines, Opts opts) {
        if (lines.size() == 1 && lines.get(0).isEmpty()) return;
        if (opts.raw || opts.colorOnly) {
            for (String line : lines) {
                if (line.isEmpty() && lines.indexOf(line) == lines.size() - 1) continue;
                System.out.println(colorRaw(line));
            }
            return;
        }
        int oldNo = 0, newNo = 0;
        String minusFile = null, plusFile = null;
        boolean inDiff = false;
        for (String line : lines) {
            if (line.startsWith("diff --git ")) {
                String[] p = line.split(" ");
                if (p.length >= 4) {
                    minusFile = stripPrefix(p[2], "a/");
                    plusFile = stripPrefix(p[3], "b/");
                    printFileHeader(displayPath(minusFile, plusFile), opts.width);
                    inDiff = true;
                }
                continue;
            }
            if (line.startsWith("--- ")) { minusFile = cleanFileName(line.substring(4)); continue; }
            if (line.startsWith("+++ ")) {
                plusFile = cleanFileName(line.substring(4));
                if (!inDiff) printFileHeader(displayPath(minusFile, plusFile), opts.width);
                inDiff = true;
                continue;
            }
            if (line.startsWith("@@")) {
                int[] nums = parseHunk(line);
                oldNo = nums[0]; newNo = nums[1];
                printHunk(line);
                continue;
            }
            if (line.startsWith("index ") || line.startsWith("new file ") || line.startsWith("deleted file ")
                    || line.startsWith("similarity index ") || line.startsWith("rename from ") || line.startsWith("rename to ")) {
                continue;
            }
            if (line.startsWith("-") && !line.startsWith("---")) {
                printContent(line.substring(1), '-', oldNo, 0, opts);
                oldNo++;
            } else if (line.startsWith("+") && !line.startsWith("+++")) {
                printContent(line.substring(1), '+', 0, newNo, opts);
                newNo++;
            } else if (line.startsWith(" ")) {
                printContent(line.substring(1), ' ', oldNo, newNo, opts);
                oldNo++; newNo++;
            } else if (!line.isEmpty()) {
                System.out.println(line);
            }
        }
    }

    static void printContent(String text, char kind, int oldNo, int newNo, Opts opts) {
        if (opts.sideBySide) {
            int half = Math.max(20, (opts.width - 7) / 2);
            if (kind == '-') System.out.printf("%s%-" + half + "s%s │ %-" + half + "s%n", MINUS_BG, truncate(text, half), RESET, "");
            else if (kind == '+') System.out.printf("%-" + half + "s │ %s%-" + half + "s%s%n", "", PLUS_BG, truncate(text, half), RESET);
            else System.out.printf("%-" + half + "s │ %-" + half + "s%n", truncate(text, half), truncate(text, half));
            return;
        }
        String prefix = "";
        if (opts.lineNumbers) prefix = String.format("%4s ⋮%4s │", oldNo == 0 ? "" : oldNo, newNo == 0 ? "" : newNo);
        if (kind == '-') System.out.println(prefix + MINUS_BG + (opts.keepMarkers ? "-" : "") + text + RESET);
        else if (kind == '+') System.out.println(prefix + PLUS_BG + (opts.keepMarkers ? "+" : "") + text + RESET);
        else System.out.println(prefix + SYNTAX + text + RESET);
    }

    static String colorRaw(String line) {
        if (line.startsWith("@@")) return CYAN + line + RESET;
        if (line.startsWith("diff --git") || line.startsWith("index ") || line.startsWith("--- ") || line.startsWith("+++ "))
            return BOLD + line + RESET;
        if (line.startsWith("-") && !line.startsWith("---")) return RED + line + RESET;
        if (line.startsWith("+") && !line.startsWith("+++")) return GREEN + line + RESET;
        return line;
    }

    static void printFileHeader(String path, int width) {
        System.out.println();
        System.out.println(BLUE + path + RESET);
        int n = Math.max(3, Math.min(Math.max(width, path.length()), 120));
        System.out.println(BLUE + "─".repeat(n) + RESET);
        System.out.println();
    }

    static void printHunk(String line) {
        Matcher m = Pattern.compile("@@\\s+[-+]([^\\s]+)\\s+[-+]([^\\s]+)\\s+@@(.*)").matcher(line);
        String label = m.find() && !m.group(3).trim().isEmpty() ? m.group(3).trim() : line;
        System.out.println(BLUE + "───┐" + RESET);
        System.out.println(BLUE + label + RESET);
        System.out.println(BLUE + "───┘" + RESET);
    }

    static int[] parseHunk(String line) {
        Matcher m = Pattern.compile("@@ -(\\d+)(?:,\\d+)? \\+(\\d+)(?:,\\d+)? @@").matcher(line);
        if (m.find()) return new int[]{parseInt(m.group(1), 0), parseInt(m.group(2), 0)};
        return new int[]{0,0};
    }

    static String displayPath(String a, String b) {
        if (a == null) return b == null ? "" : b;
        if (b == null || a.equals(b)) return a;
        return a + " ⟶   " + b;
    }

    static String cleanFileName(String s) {
        int tab = s.indexOf('\t');
        if (tab >= 0) s = s.substring(0, tab);
        if (s.startsWith("a/") || s.startsWith("b/")) s = s.substring(2);
        return s;
    }

    static String stripPrefix(String s, String p) { return s.startsWith(p) ? s.substring(p.length()) : s; }
    static int parseInt(String s, int d) { try { return Integer.parseInt(s.replaceAll("[^0-9].*$", "")); } catch(Exception e) { return d; } }
    static String truncate(String s, int n) { return s.length() <= n ? s : s.substring(0, Math.max(0, n - 1)) + "…"; }
    static String visibleAnsi(String s) { return s.replace("\u001b", "␛"); }

    static void printHelp() throws IOException {
        Path p = Paths.get("help.txt");
        if (Files.exists(p)) {
            System.out.print(Files.readString(p));
        } else {
            System.out.println("A viewer for git and diff output\n\nUsage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]");
        }
    }

    static void printThemes() {
        String[] themes = {"dark\t1337","dark\tColdark-Cold","dark\tColdark-Dark","dark\tDarkNeon","dark\tDracula",
                "dark\tMonokai Extended","dark\tMonokai Extended Bright","dark\tMonokai Extended Origin",
                "dark\tNord","dark\tOneHalfDark","dark\tSolarized (dark)","dark\tSublime Snazzy",
                "dark\tTwoDark","dark\tVisual Studio Dark+","dark\tansi","dark\tbase16","dark\tbase16-256",
                "dark\tgruvbox-dark","dark\tzenburn","light\tGitHub","light\tMonokai Extended Light",
                "light\tOneHalfLight","light\tSolarized (light)","light\tgruvbox-light"};
        for (String t : themes) System.out.println(t);
    }

    static void printLanguages() {
        String[] langs = {
                "ActionScript              \u001b[32mas\u001b[0m",
                "Ada                       \u001b[32madb\u001b[0m, \u001b[32mads\u001b[0m, \u001b[32mgpr\u001b[0m",
                "Apache Conf               \u001b[32menvvars\u001b[0m, \u001b[32mhtaccess\u001b[0m, \u001b[32mHTACCESS\u001b[0m",
                "Bourne Again Shell (bash) \u001b[32msh\u001b[0m, \u001b[32mbash\u001b[0m, \u001b[32mzsh\u001b[0m",
                "C                         \u001b[32mc\u001b[0m, \u001b[32mh\u001b[0m",
                "C++                       \u001b[32mcpp\u001b[0m, \u001b[32mcc\u001b[0m, \u001b[32mcxx\u001b[0m",
                "Diff                      \u001b[32mdiff\u001b[0m, \u001b[32mpatch\u001b[0m",
                "Java                      \u001b[32mjava\u001b[0m",
                "JavaScript                \u001b[32mjs\u001b[0m, \u001b[32mmjs\u001b[0m",
                "JSON                      \u001b[32mjson\u001b[0m",
                "Markdown                  \u001b[32mmd\u001b[0m, \u001b[32mmarkdown\u001b[0m",
                "Python                    \u001b[32mpy\u001b[0m, \u001b[32mpy3\u001b[0m",
                "Rust                      \u001b[32mrs\u001b[0m",
                "TypeScript                \u001b[32mts\u001b[0m, \u001b[32mtsx\u001b[0m",
                "YAML                      \u001b[32myml\u001b[0m, \u001b[32myaml\u001b[0m"
        };
        for (String l : langs) System.out.println(l);
    }

    static void printConfig() {
        System.out.println("    commit-style                  = raw");
        System.out.println("    file-style                    = " + BLUE + "blue" + RESET);
        System.out.println("    hunk-header-style             = syntax");
        System.out.println("    minus-style                   = " + MINUS_BG + "normal 52" + RESET);
        System.out.println("    plus-style                    = " + PLUS_BG + "syntax 22" + RESET);
        System.out.println("    true-color                    = false");
        System.out.println("    keep-plus-minus-markers       = false");
        System.out.println("    line-numbers                  = false");
        System.out.println("    navigate                      = false");
        System.out.println("    pager                         = none");
        System.out.println("    paging                        = auto");
        System.out.println("    side-by-side                  = false");
        System.out.println("    syntax-theme                  = Monokai Extended");
        System.out.println("    width                         = 80");
    }

    static void printColors() {
        String[] colors = {"Black","Red","Green","Yellow","Blue","Purple","Cyan","White"};
        for (String c : colors) {
            System.out.println();
            System.out.println(BOLD + c + RESET);
            System.out.println("export function color(): string { return \"" + c.toLowerCase(Locale.ROOT) + "\" }");
            System.out.println("export function hex(): string { return \"none\" }");
        }
    }

    static void showSyntaxThemes() {
        for (String t : Arrays.asList("1337","Coldark-Cold","Dracula","Monokai Extended","GitHub")) {
            System.out.println();
            System.out.println("Syntax theme: " + BOLD + t + RESET);
            System.out.println();
            System.out.println(BLUE + "example.rs" + RESET);
            System.out.println(BLUE + "──────────" + RESET);
            System.out.println(MINUS_BG + "// Output the square of a number." + RESET);
            System.out.println(PLUS_BG + "fn print_cube(num: f64) {" + RESET);
        }
    }

    static void printCompletion() {
        System.out.println("# completion script generated by delta");
        System.out.println("complete -W '--help --version --line-numbers --side-by-side --raw --color-only' delta");
    }
}
