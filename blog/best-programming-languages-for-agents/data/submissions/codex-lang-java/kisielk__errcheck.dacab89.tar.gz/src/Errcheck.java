import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Errcheck {
    static class Opts {
        boolean abspath, asserts, blank, excludeOnly, ignoreGenerated, ignoreTests, verbose, help;
        String exclude, mod;
        List<String> tags = new ArrayList<>();
        List<String> args = new ArrayList<>();
        Map<String, List<Pattern>> ignore = new HashMap<>();
        Set<String> ignorePkgs = new HashSet<>();
    }

    static class FuncInfo {
        String pkg, recv, name, full;
        List<String> returns = new ArrayList<>();
        boolean returnsError;
    }

    static class Issue implements Comparable<Issue> {
        Path file; int line, col; String expr;
        public int compareTo(Issue o) {
            int c = file.toString().compareTo(o.file.toString());
            if (c != 0) return c;
            if (line != o.line) return Integer.compare(line, o.line);
            return Integer.compare(col, o.col);
        }
    }

    static final Set<String> DEFAULT_IGNORE_PKGS = new HashSet<>(Arrays.asList("fmt"));
    static final Set<String> DEFAULT_EXCLUDES = new HashSet<>(Arrays.asList(
            "bytes.Buffer.Write", "bytes.Buffer.WriteByte", "bytes.Buffer.WriteRune", "bytes.Buffer.WriteString",
            "strings.Builder.Write", "strings.Builder.WriteByte", "strings.Builder.WriteRune", "strings.Builder.WriteString",
            "hash.Hash.Write", "hash.Hash32.Write", "hash.Hash64.Write"));

    static final Set<String> ERROR_FUNCS = new HashSet<>(Arrays.asList(
            "os.Open", "os.OpenFile", "os.Create", "os.ReadFile", "os.WriteFile", "os.Remove", "os.RemoveAll",
            "os.Rename", "os.Mkdir", "os.MkdirAll", "os.Chdir", "os.Chmod", "os.Chown", "os.Truncate",
            "io.Copy", "io.CopyN", "io.ReadAll", "io.ReadFull", "io.WriteString", "io.Pipe",
            "ioutil.ReadFile", "ioutil.WriteFile", "ioutil.ReadAll", "ioutil.TempFile", "ioutil.TempDir",
            "net.Dial", "net.Listen", "net.ResolveTCPAddr", "net.ResolveUDPAddr", "net/http.Get",
            "net/http.Post", "net/http.PostForm", "net/http.ListenAndServe", "net/http.ListenAndServeTLS",
            "encoding/json.Marshal", "encoding/json.Unmarshal", "encoding/xml.Marshal", "encoding/xml.Unmarshal",
            "strconv.Atoi", "strconv.ParseInt", "strconv.ParseUint", "strconv.ParseFloat", "strconv.ParseBool",
            "regexp.Compile", "regexp.MatchString", "time.Parse", "time.LoadLocation",
            "database/sql.Open", "context.WithCancelCause"));
    static final Set<String> ERROR_METHODS = new HashSet<>(Arrays.asList(
            "Close", "Read", "ReadFrom", "ReadString", "ReadBytes", "Write", "WriteTo", "WriteString",
            "Flush", "Sync", "Seek", "Truncate", "Chmod", "Chown", "Encode", "Decode",
            "Commit", "Rollback", "Ping", "Exec", "Query", "QueryRow", "Scan", "Err"));

    public static void main(String[] argv) {
        try {
            Opts opts = parse(argv);
            if (opts.help) {
                usage(System.err);
                System.exit(2);
            }
            int code = run(opts);
            System.exit(code);
        } catch (FlagError e) {
            System.err.println(e.getMessage());
            usage(System.err);
            System.exit(2);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(2);
        }
    }

    static int run(Opts opts) throws Exception {
        if (opts.args.isEmpty()) opts.args.add(".");
        Set<String> excludes = new HashSet<>();
        if (!opts.excludeOnly) excludes.addAll(DEFAULT_EXCLUDES);
        if (opts.exclude != null) readExcludes(Paths.get(opts.exclude), excludes);

        List<Path> files = collectFiles(opts.args, opts);
        Map<String, FuncInfo> funcs = collectFunctions(files);
        List<Issue> issues = new ArrayList<>();
        for (Path p : files) scanFile(p, opts, excludes, funcs, issues);
        Collections.sort(issues);
        for (Issue i : issues) {
            Path shown = opts.abspath ? i.file.toAbsolutePath().normalize() : relativize(i.file);
            System.out.printf("%s:%d:%d:\t%s%n", shown, i.line, i.col, i.expr.trim());
        }
        return issues.isEmpty() ? 0 : 1;
    }

    static Path relativize(Path p) {
        Path abs = p.toAbsolutePath().normalize();
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        try { return cwd.relativize(abs); } catch (Exception e) { return p; }
    }

    static class FlagError extends Exception { FlagError(String s) { super(s); } }

    static Opts parse(String[] argv) throws FlagError {
        Opts o = new Opts();
        for (int i = 0; i < argv.length; i++) {
            String a = argv[i];
            if (!a.startsWith("-") || a.equals("-")) { o.args.add(a); continue; }
            String name = a, val = null;
            int eq = a.indexOf('=');
            if (eq >= 0) { name = a.substring(0, eq); val = a.substring(eq + 1); }
            switch (name) {
                case "-h": case "-help": case "--help": o.help = true; break;
                case "-abspath": o.abspath = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-asserts": o.asserts = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-blank": o.blank = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-excludeonly": o.excludeOnly = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-ignoregenerated": o.ignoreGenerated = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-ignoretests": o.ignoreTests = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-verbose": o.verbose = boolFlag(argv, i, val); if (val == null && nextBool(argv, i)) i++; break;
                case "-exclude": o.exclude = stringVal(argv, ++i, val, name); if (val != null) i--; break;
                case "-mod": o.mod = stringVal(argv, ++i, val, name); if (val != null) i--; break;
                case "-tags": parseTags(o, stringVal(argv, ++i, val, name)); if (val != null) i--; break;
                case "-ignore": parseIgnore(o, stringVal(argv, ++i, val, name)); if (val != null) i--; break;
                case "-ignorepkg": parseIgnorePkg(o, stringVal(argv, ++i, val, name)); if (val != null) i--; break;
                default: throw new FlagError("flag provided but not defined: " + (name.startsWith("--") ? "-" + name.substring(2) : name));
            }
        }
        if (!o.ignore.containsKey("fmt") && !o.ignorePkgs.contains("fmt")) o.ignorePkgs.addAll(DEFAULT_IGNORE_PKGS);
        return o;
    }

    static boolean nextBool(String[] a, int i) {
        return i + 1 < a.length && ("true".equals(a[i+1]) || "false".equals(a[i+1]));
    }
    static boolean boolFlag(String[] a, int i, String v) throws FlagError {
        if (v == null) {
            if (nextBool(a, i)) return Boolean.parseBoolean(a[i+1]);
            return true;
        }
        if ("true".equals(v) || "false".equals(v)) return Boolean.parseBoolean(v);
        throw new FlagError("invalid boolean value " + v);
    }
    static String stringVal(String[] a, int i, String v, String name) throws FlagError {
        if (v != null) return v;
        if (i >= a.length) throw new FlagError("flag needs an argument: " + name);
        return a[i];
    }
    static void parseTags(Opts o, String s) {
        for (String t : s.split("[,\\s]+")) if (!t.isEmpty()) o.tags.add(t);
    }
    static void parseIgnorePkg(Opts o, String s) {
        for (String p : s.split(",")) if (!p.trim().isEmpty()) o.ignorePkgs.add(p.trim());
    }
    static void parseIgnore(Opts o, String s) throws FlagError {
        if (s == null || s.isEmpty()) return;
        for (String part : s.split(",")) {
            if (part.isEmpty()) continue;
            String pkg = "", rx = part;
            int idx = part.indexOf(':');
            if (idx >= 0) { pkg = part.substring(0, idx); rx = part.substring(idx + 1); }
            try { o.ignore.computeIfAbsent(pkg, k -> new ArrayList<>()).add(Pattern.compile(rx)); }
            catch (PatternSyntaxException e) { throw new FlagError("invalid regexp " + rx + ": " + e.getMessage()); }
        }
    }

    static void usage(PrintStream ps) {
        ps.println("Usage of ./executable:");
        ps.println("  -abspath");
        ps.println("    \tprint absolute paths to files");
        ps.println("  -asserts");
        ps.println("    \tif true, check for ignored type assertion results");
        ps.println("  -blank");
        ps.println("    \tif true, check for errors assigned to blank identifier");
        ps.println("  -exclude string");
        ps.println("    \tPath to a file containing a list of functions to exclude from checking");
        ps.println("  -excludeonly");
        ps.println("    \tUse only excludes from -exclude file");
        ps.println("  -ignore value");
        ps.println("    \t[deprecated] comma-separated list of pairs of the form pkg:regex");
        ps.println("    \t            the regex is used to ignore names within pkg.");
        ps.println("  -ignoregenerated");
        ps.println("    \tif true, checking of files with generated code is disabled");
        ps.println("  -ignorepkg string");
        ps.println("    \tcomma-separated list of package paths to ignore");
        ps.println("  -ignoretests");
        ps.println("    \tif true, checking of _test.go files is disabled");
        ps.println("  -mod string");
        ps.println("    \tmodule download mode to use: readonly or vendor. See 'go help modules' for more.");
        ps.println("  -tags value");
        ps.println("    \tcomma or space-separated list of build tags to include");
        ps.println("  -verbose");
        ps.println("    \tproduce more verbose logging");
    }

    static void readExcludes(Path p, Set<String> out) throws IOException {
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            String s = line.trim();
            if (s.isEmpty() || s.startsWith("//")) continue;
            out.add(s);
        }
    }

    static List<Path> collectFiles(List<String> args, Opts opts) throws IOException {
        LinkedHashSet<Path> out = new LinkedHashSet<>();
        for (String a : args) {
            if (a.equals("all")) a = "./...";
            if (a.endsWith("/...")) {
                Path base = Paths.get(a.substring(0, a.length() - 4));
                if (base.toString().isEmpty()) base = Paths.get(".");
                walk(base, out, opts);
            } else {
                Path p = Paths.get(a);
                if (Files.isRegularFile(p) && p.toString().endsWith(".go")) addFile(p, out, opts);
                else if (Files.isDirectory(p)) {
                    try (DirectoryStream<Path> ds = Files.newDirectoryStream(p, "*.go")) {
                        for (Path f : ds) addFile(f, out, opts);
                    }
                }
            }
        }
        return new ArrayList<>(out);
    }
    static void walk(Path base, Set<Path> out, Opts opts) throws IOException {
        if (!Files.exists(base)) return;
        try (var s = Files.walk(base)) {
            s.filter(Files::isRegularFile).filter(p -> p.toString().endsWith(".go")).forEach(p -> {
                try { addFile(p, out, opts); } catch (IOException ignored) {}
            });
        }
    }
    static void addFile(Path p, Set<Path> out, Opts opts) throws IOException {
        String n = p.getFileName().toString();
        if (opts.ignoreTests && n.endsWith("_test.go")) return;
        if (opts.ignoreGenerated && isGenerated(p)) return;
        if (buildIgnored(p, opts.tags)) return;
        out.add(p.normalize());
    }
    static boolean isGenerated(Path p) throws IOException {
        int lim = 20, c = 0;
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            if (++c > lim) break;
            String l = line.toLowerCase(Locale.ROOT);
            if (l.contains("code generated") && l.contains("do not edit")) return true;
        }
        return false;
    }
    static boolean buildIgnored(Path p, List<String> tags) throws IOException {
        Set<String> tagSet = new HashSet<>(tags);
        int c = 0;
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            String t = line.trim();
            if (++c > 30 || (!t.startsWith("//") && !t.isEmpty())) break;
            if (t.startsWith("//go:build")) {
                String expr = t.substring("//go:build".length()).trim();
                if (expr.contains("ignore")) return true;
                Matcher m = Pattern.compile("[A-Za-z0-9_]+").matcher(expr);
                boolean hasKnown = false, hasTag = false;
                while (m.find()) {
                    String x = m.group();
                    if (Arrays.asList("linux","darwin","windows","unix","cgo").contains(x)) { hasKnown = true; continue; }
                    hasTag = true;
                    if (tagSet.contains(x)) return false;
                }
                if (hasTag && !hasKnown) return true;
            }
        }
        return false;
    }

    static Map<String, FuncInfo> collectFunctions(List<Path> files) throws IOException {
        Map<String, FuncInfo> m = new HashMap<>();
        Pattern pat = Pattern.compile("\\bfunc\\s*(?:\\(([^)]*)\\)\\s*)?([A-Za-z_]\\w*)\\s*\\(([^)]*)\\)\\s*([^\\{\\n]*)");
        for (Path p : files) {
            String pkg = packageName(p);
            String text = stripComments(read(p));
            Matcher mm = pat.matcher(text);
            while (mm.find()) {
                FuncInfo f = new FuncInfo();
                f.pkg = pkg; f.recv = receiverType(mm.group(1)); f.name = mm.group(2);
                String ret = mm.group(4).trim();
                f.returnsError = returnsError(ret);
                f.full = f.recv == null ? pkg + "." + f.name : "(" + pkg + "." + f.recv + ")." + f.name;
                m.put(f.name, f);
                m.put(f.full, f);
                if (f.recv != null) m.put(f.recv + "." + f.name, f);
            }
        }
        return m;
    }
    static String receiverType(String r) {
        if (r == null) return null;
        String[] parts = r.trim().split("\\s+");
        if (parts.length == 0) return null;
        String t = parts[parts.length - 1].replace("*", "").trim();
        int dot = t.lastIndexOf('.');
        return dot >= 0 ? t.substring(dot + 1) : t;
    }
    static boolean returnsError(String ret) {
        ret = ret.trim();
        if (ret.isEmpty()) return false;
        if (ret.equals("error") || ret.endsWith(" error")) return true;
        if (ret.startsWith("(") && ret.endsWith(")")) ret = ret.substring(1, ret.length() - 1);
        return Pattern.compile("(^|[,\\s])error($|[,\\s])").matcher(ret).find();
    }
    static String packageName(Path p) throws IOException {
        Matcher m = Pattern.compile("^\\s*package\\s+(\\w+)").matcher(read(p));
        return m.find() ? m.group(1) : "";
    }

    static void scanFile(Path p, Opts opts, Set<String> excludes, Map<String, FuncInfo> funcs, List<Issue> issues) throws IOException {
        String src = read(p);
        Map<String,String> imports = parseImports(src);
        String scrub = stripStrings(stripComments(src));
        String[] lines = src.split("\\R", -1);
        String[] cleanLines = scrub.split("\\R", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String clean = i < cleanLines.length ? cleanLines[i] : line;
            if (clean.trim().isEmpty()) continue;
            if (clean.trim().startsWith("func ")) continue;
            if (isHandledContext(clean)) {
                if (opts.blank && clean.contains("_")) checkBlank(p, i + 1, line, clean, imports, funcs, excludes, opts, issues);
                continue;
            }
            if (opts.asserts) checkAssert(p, i + 1, line, clean, issues);
            List<String> calls = topCalls(clean);
            for (String c : calls) {
                String resolved = resolveCall(c, imports);
                if (isErrorCall(c, resolved, funcs) && !ignored(c, resolved, imports, funcs, excludes, opts)) {
                    Issue is = new Issue();
                    is.file = p; is.line = i + 1; is.col = Math.max(1, line.indexOf(c) + 1); is.expr = displayExpr(line, c);
                    issues.add(is);
                }
            }
        }
    }

    static void checkBlank(Path p, int lineNo, String line, String clean, Map<String,String> imports, Map<String,FuncInfo> funcs, Set<String> excludes, Opts opts, List<Issue> issues) {
        if (!clean.contains(":=") && !clean.contains("=")) return;
        String[] sp = clean.split(":=|=", 2);
        if (sp.length < 2 || !Arrays.asList(sp[0].split(",")).stream().anyMatch(s -> s.trim().equals("_"))) return;
        for (String c : topCalls(sp[1])) {
            String r = resolveCall(c, imports);
            if (isErrorCall(c, r, funcs) && !ignored(c, r, imports, funcs, excludes, opts)) {
                Issue is = new Issue();
                is.file = p; is.line = lineNo; is.col = Math.max(1, line.indexOf("_") + 1); is.expr = line.trim();
                issues.add(is);
                return;
            }
        }
    }
    static void checkAssert(Path p, int lineNo, String line, String clean, List<Issue> issues) {
        if (!clean.contains(".(")) return;
        if (clean.contains(":=") || clean.contains("=") || clean.trim().startsWith("case ")) return;
        Issue is = new Issue(); is.file = p; is.line = lineNo; is.col = Math.max(1, clean.indexOf(".(") + 1); is.expr = line.trim(); issues.add(is);
    }

    static boolean isHandledContext(String s) {
        String t = s.trim();
        return t.startsWith("if ") || t.startsWith("for ") || t.startsWith("switch ") || t.startsWith("return ") ||
                t.startsWith("go ") || t.startsWith("defer ") || t.contains(":=") || assignLine(t);
    }
    static boolean assignLine(String t) {
        return t.matches(".*(^|[^=!<>])=([^=].*)") && !t.startsWith("var ");
    }

    static List<String> topCalls(String s) {
        List<String> r = new ArrayList<>();
        Matcher m = Pattern.compile("([A-Za-z_]\\w*(?:\\.[A-Za-z_]\\w*)?)\\s*\\(").matcher(s);
        while (m.find()) {
            String n = m.group(1);
            if (Arrays.asList("if","for","switch","return","func","make","new","append","len","cap","copy","delete","panic","recover","println","print").contains(n)) continue;
            r.add(n);
        }
        return r;
    }
    static String resolveCall(String c, Map<String,String> imports) {
        int dot = c.indexOf('.');
        if (dot < 0) return c;
        String base = c.substring(0, dot);
        String rest = c.substring(dot + 1);
        String imp = imports.get(base);
        return imp == null ? c : imp + "." + rest;
    }
    static boolean isErrorCall(String c, String resolved, Map<String,FuncInfo> funcs) {
        if (ERROR_FUNCS.contains(resolved) || ERROR_FUNCS.contains(c)) return true;
        int dot = c.lastIndexOf('.');
        if (dot >= 0 && ERROR_METHODS.contains(c.substring(dot + 1))) return true;
        FuncInfo f = funcs.get(c);
        if (f != null && f.returnsError) return true;
        f = funcs.get(resolved);
        return f != null && f.returnsError;
    }
    static boolean ignored(String c, String resolved, Map<String,String> imports, Map<String,FuncInfo> funcs, Set<String> excludes, Opts opts) {
        if (excludes.contains(resolved) || excludes.contains(c)) return true;
        FuncInfo fi = funcs.get(c);
        if (fi != null && excludes.contains(fi.full)) return true;
        int dot = resolved.lastIndexOf('.');
        String pkg = dot >= 0 ? resolved.substring(0, dot) : "";
        String name = dot >= 0 ? resolved.substring(dot + 1) : resolved;
        if (opts.ignorePkgs.contains(pkg)) return true;
        if (opts.ignorePkgs.contains(c.contains(".") ? c.substring(0, c.indexOf('.')) : "")) return true;
        for (String key : Arrays.asList(pkg, "", c.contains(".") ? c.substring(0, c.indexOf('.')) : "")) {
            for (Pattern p : opts.ignore.getOrDefault(key, Collections.emptyList())) if (p.matcher(name).find() || p.matcher(c).find()) return true;
        }
        return false;
    }
    static String displayExpr(String line, String call) {
        int i = line.indexOf(call);
        if (i < 0) return line.trim();
        return line.substring(i).trim();
    }

    static Map<String,String> parseImports(String src) {
        Map<String,String> m = new HashMap<>();
        Matcher block = Pattern.compile("import\\s*\\((.*?)\\)", Pattern.DOTALL).matcher(src);
        while (block.find()) parseImportLines(block.group(1), m);
        Matcher one = Pattern.compile("import\\s+(?:([A-Za-z_]\\w*)\\s+)?\"([^\"]+)\"").matcher(src);
        while (one.find()) addImport(m, one.group(1), one.group(2));
        return m;
    }
    static void parseImportLines(String b, Map<String,String> m) {
        Matcher x = Pattern.compile("(?:^|\\n)\\s*(?:(\\w+)\\s+)?\"([^\"]+)\"").matcher(b);
        while (x.find()) addImport(m, x.group(1), x.group(2));
    }
    static void addImport(Map<String,String> m, String alias, String path) {
        if ("_".equals(alias) || ".".equals(alias)) return;
        String name = alias != null ? alias : path.substring(path.lastIndexOf('/') + 1);
        m.put(name, path);
    }

    static String read(Path p) throws IOException { return Files.readString(p, StandardCharsets.UTF_8); }
    static String stripComments(String s) {
        s = s.replaceAll("(?s)/\\*.*?\\*/", "");
        return s.replaceAll("(?m)//.*$", "");
    }
    static String stripStrings(String s) {
        return s.replaceAll("(?s)`.*?`", "\"\"").replaceAll("\"(?:\\\\.|[^\"\\\\])*\"", "\"\"");
    }
}
