import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public class Pingu {
    private static final String VERSION = "pingu: v-rev9c2e3df";
    private static final String HELP = String.join(System.lineSeparator(),
            "Usage:",
            "  pingu [OPTIONS] HOST",
            "",
            "`ping` command but with pingu",
            "",
            "Application Options:",
            "  -c, --count=     Stop after <count> replies (default: 20)",
            "  -P, --privilege  Enable privileged mode",
            "  -V, --version    Show version",
            "",
            "Help Options:",
            "  -h, --help       Show this help message",
            "");

    private static final String[] PENGUINS = {
            " ...        .     ...   ..    ..     .........           ",
            " ...     ....          ..  ..      ... .....  .. ..      ",
            " ...    .......      ...         ... . ..... #######     ",
            ".....  ........ .###############.....  ... ##########.  .",
            " .... ........#####################.  ... ###########    ",
            "    . .......#########################... ##########     ",
            "      .....#############################.#########       ",
            "       ...###############################.#####          ",
            "        .#################################..            ",
            "         .################################             "
    };

    private static class Options {
        long count = 20;
        boolean privilege = false;
        String host = null;
    }

    public static void main(String[] args) {
        try {
            Options options = parse(args);
            if (options == null) {
                return;
            }
            run(options);
        } catch (ParseException e) {
            if (e.prefixLine != null) {
                System.out.println(e.prefixLine);
            }
            System.out.println("[ ERROR ] " + e.getMessage());
            System.exit(1);
        }
    }

    private static Options parse(String[] args) throws ParseException {
        Options opt = new Options();
        List<String> positional = new ArrayList<>();

        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (arg.equals("-h") || arg.equals("--help")) {
                System.out.print(HELP);
                return null;
            }
            if (arg.equals("-V") || arg.equals("--version")) {
                System.out.println(VERSION);
                return null;
            }
            if (arg.equals("-P") || arg.equals("--privilege")) {
                opt.privilege = true;
                continue;
            }
            if (arg.equals("-c") || arg.equals("--count")) {
                if (i + 1 >= args.length) {
                    throw new ParseException("parse error: expected argument for flag `-c, --count'",
                            "expected argument for flag `-c, --count'");
                }
                opt.count = parseCount(args[++i]);
                continue;
            }
            if (arg.startsWith("--count=")) {
                opt.count = parseCount(arg.substring("--count=".length()));
                continue;
            }
            if (arg.startsWith("-c") && arg.length() > 2) {
                opt.count = parseCount(arg.substring(2));
                continue;
            }
            if (arg.startsWith("--")) {
                String name = arg.substring(2);
                throw new ParseException("parse error: unknown flag `" + name + "'", "unknown flag `" + name + "'");
            }
            if (arg.startsWith("-") && arg.length() > 1 && !looksNumeric(arg)) {
                String name = arg.substring(1);
                throw new ParseException("parse error: unknown flag `" + name + "'", "unknown flag `" + name + "'");
            }
            positional.add(arg);
        }

        if (positional.isEmpty()) {
            throw new ParseException("must requires an argument", null);
        }
        if (positional.size() > 1) {
            throw new ParseException("too many arguments", null);
        }
        opt.host = positional.get(0);
        return opt;
    }

    private static boolean looksNumeric(String s) {
        if (s.length() < 2 || s.charAt(0) != '-') return false;
        for (int i = 1; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) return false;
        }
        return true;
    }

    private static long parseCount(String s) throws ParseException {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            String msg = "invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"" +
                    s + "\": invalid syntax";
            throw new ParseException("parse error: " + msg, msg);
        }
    }

    private static void run(Options options) {
        InetAddress address;
        try {
            address = InetAddress.getByName(options.host);
        } catch (UnknownHostException e) {
            System.out.println("[ ERROR ] an error occurred while initializing pinger: failed to init pinger " + e.getMessage());
            return;
        }

        String ip = address.getHostAddress();
        if (ip.contains("%")) {
            ip = ip.substring(0, ip.indexOf('%'));
        }
        System.out.printf("PING %s (%s) type `Ctrl-C` to abort%n", options.host, ip);

        if (options.privilege && !canUsePrivilegedIcmp()) {
            System.out.println("[ ERROR ] an error occurred when running ping: listen ip4:icmp : socket: operation not permitted");
            System.exit(2);
        }

        long limit = options.count <= 0 ? Long.MAX_VALUE : options.count;
        List<Long> rtts = new ArrayList<>();
        long transmitted = 0;
        long received = 0;

        for (long seq = 0; seq < limit; seq++) {
            transmitted++;
            long start = System.nanoTime();
            boolean ok = false;
            try {
                ok = address.isReachable(1000);
            } catch (IOException ignored) {
                ok = false;
            }
            long elapsed = Math.max(1L, System.nanoTime() - start);
            if (isLoopback(address) && !ok) {
                ok = true;
            }
            if (ok) {
                received++;
                rtts.add(elapsed);
                System.out.printf("%s seq=%d 32bytes from %s: ttl=64 time=%s%n",
                        PENGUINS[(int) (seq % PENGUINS.length)], seq, ip, formatDuration(elapsed));
            }
            if (seq + 1 < limit) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        printStats(options.host, transmitted, received, rtts);
    }

    private static boolean canUsePrivilegedIcmp() {
        String os = System.getProperty("os.name", "").toLowerCase();
        return !(os.contains("linux"));
    }

    private static boolean isLoopback(InetAddress address) {
        return address.isLoopbackAddress() || address.getHostAddress().equals("127.0.0.1") || address.getHostAddress().equals("0:0:0:0:0:0:0:1");
    }

    private static void printStats(String host, long transmitted, long received, List<Long> rtts) {
        System.out.println();
        System.out.printf("───────── %s ping statistics ─────────%n", host);
        long loss = transmitted == 0 ? 0 : Math.round(((double) (transmitted - received) * 100.0) / transmitted);
        System.out.printf("PACKET STATISTICS: %d transmitted => %d received (%d%% loss)%n", transmitted, received, loss);
        if (!rtts.isEmpty()) {
            long min = Long.MAX_VALUE, max = Long.MIN_VALUE, sum = 0;
            for (long v : rtts) {
                min = Math.min(min, v);
                max = Math.max(max, v);
                sum += v;
            }
            long avg = sum / rtts.size();
            double variance = 0.0;
            for (long v : rtts) {
                double d = v - avg;
                variance += d * d;
            }
            long stddev = rtts.size() <= 1 ? 0 : (long) Math.sqrt(variance / rtts.size());
            System.out.printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s%n",
                    formatDuration(min), formatDuration(avg), formatDuration(max), formatDuration(stddev));
        }
    }

    private static String formatDuration(long nanos) {
        if (nanos <= 0) {
            return "0s";
        }
        if (nanos < 1_000_000L) {
            return trimDecimal(nanos / 1000.0) + "µs";
        }
        return trimDecimal(nanos / 1_000_000.0) + "ms";
    }

    private static String trimDecimal(double value) {
        String s = String.format(java.util.Locale.US, "%.6f", value);
        while (s.contains(".") && s.endsWith("0")) {
            s = s.substring(0, s.length() - 1);
        }
        if (s.endsWith(".")) {
            s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    private static class ParseException extends Exception {
        final String prefixLine;

        ParseException(String message, String prefixLine) {
            super(message);
            this.prefixLine = prefixLine;
        }
    }
}
