import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Xsv {
    static class Opt {
        char delim = ',';
        char outDelim = ',';
        char quote = '"';
        Character escape = null;
        boolean noHeaders, quoteAlways, crlf, noQuoting;
        String input, output;
        List<String> pos = new ArrayList<>();
        Map<String,String> vals = new HashMap<>();
        Set<String> flags = new HashSet<>();
    }
    static class Csv {
        List<List<String>> rows = new ArrayList<>();
    }
    interface Cmd { void run(Opt o) throws Exception; }

    static final String HELP = "Usage:\n" +
        "    xsv <command> [<args>...]\n" +
        "    xsv [options]\n\n" +
        "Options:\n" +
        "    --list        List all commands available.\n" +
        "    -h, --help    Display this message\n" +
        "    <command> -h  Display the command help message\n" +
        "    --version     Print version info and exit\n\n" +
        "Commands:\n" +
        "    cat         Concatenate by row or column\n" +
        "    count       Count records\n" +
        "    fixlengths  Makes all records have same length\n" +
        "    flatten     Show one field per line\n" +
        "    fmt         Format CSV output (change field delimiter)\n" +
        "    frequency   Show frequency tables\n" +
        "    headers     Show header names\n" +
        "    help        Show this usage message.\n" +
        "    index       Create CSV index for faster access\n" +
        "    input       Read CSV data with special quoting rules\n" +
        "    join        Join CSV files\n" +
        "    partition   Partition CSV data based on a column value\n" +
        "    sample      Randomly sample CSV data\n" +
        "    reverse     Reverse rows of CSV data\n" +
        "    search      Search CSV data with regexes\n" +
        "    select      Select columns from CSV\n" +
        "    slice       Slice records from CSV\n" +
        "    sort        Sort CSV data\n" +
        "    split       Split CSV data into many files\n" +
        "    stats       Compute basic statistics\n" +
        "    table       Align CSV data into columns\n";

    public static void main(String[] args) {
        try {
            if (args.length == 0 || eq(args[0], "-h", "--help") || args[0].equals("help")) { System.out.print(HELP); return; }
            if (args[0].equals("--version")) { System.out.println("0.13.0"); return; }
            if (args[0].equals("--list")) { System.out.print(HELP.substring(HELP.indexOf("Commands:")).replace("Commands:", "Installed commands:")); return; }
            String cmd = args[0];
            if (args.length > 1 && eq(args[1], "-h", "--help")) { System.out.print(help(cmd)); return; }
            Opt o = parse(cmd, Arrays.copyOfRange(args, 1, args.length));
            Map<String,Cmd> cmds = commands();
            Cmd c = cmds.get(cmd);
            if (c == null) die("Unrecognized command: " + cmd);
            c.run(o);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static Map<String,Cmd> commands() {
        Map<String,Cmd> m = new HashMap<>();
        m.put("count", Xsv::count);
        m.put("headers", Xsv::headers);
        m.put("fmt", Xsv::fmt);
        m.put("input", Xsv::fmt);
        m.put("select", Xsv::select);
        m.put("slice", Xsv::slice);
        m.put("sort", Xsv::sort);
        m.put("reverse", Xsv::reverse);
        m.put("fixlengths", Xsv::fixlengths);
        m.put("flatten", Xsv::flatten);
        m.put("table", Xsv::table);
        m.put("frequency", Xsv::frequency);
        m.put("stats", Xsv::stats);
        m.put("search", Xsv::search);
        m.put("cat", Xsv::cat);
        m.put("join", Xsv::join);
        m.put("sample", Xsv::sample);
        m.put("split", Xsv::split);
        m.put("partition", Xsv::partition);
        m.put("index", Xsv::index);
        return m;
    }

    static Opt parse(String cmd, String[] a) {
        Opt o = new Opt();
        for (int i=0;i<a.length;i++) {
            String s=a[i];
            if (s.equals("--")) { while (++i<a.length) o.pos.add(a[i]); break; }
            if (s.equals("-n")||s.equals("--no-headers")) o.noHeaders=true;
            else if (s.equals("-h")||s.equals("--help")) o.flags.add("help");
            else if (s.equals("-o")||s.equals("--output")) o.output=a[++i];
            else if (s.equals("-d")||s.equals("--delimiter")) o.delim=one(a[++i]);
            else if (s.equals("-t")||s.equals("--out-delimiter")) o.outDelim=one(a[++i]);
            else if (s.equals("--quote")) o.quote=one(a[++i]);
            else if (s.equals("--escape")) o.escape=one(a[++i]);
            else if (s.equals("--quote-always")) o.quoteAlways=true;
            else if (s.equals("--crlf")) o.crlf=true;
            else if (s.equals("--ascii")) { o.outDelim=0x1f; o.vals.put("recordTerm", "\u001e"); }
            else if (s.equals("--no-quoting")) o.noQuoting=true;
            else if (s.startsWith("--") && needsValue(cmd, s)) o.vals.put(s, a[++i]);
            else if (s.startsWith("-") && s.length()==2 && shortNeedsValue(cmd, s)) o.vals.put(s, a[++i]);
            else if (s.startsWith("-") && s.length()==2 && "NRaiv".indexOf(s.charAt(1))>=0) o.flags.add(s);
            else if (s.startsWith("--")) o.flags.add(s);
            else o.pos.add(s);
        }
        if (!o.pos.isEmpty()) o.input = o.pos.get(o.pos.size()-1);
        return o;
    }
    static boolean needsValue(String cmd, String s) {
        if (cmd.equals("cat") && s.equals("--pad")) return false;
        return Arrays.asList("--select","--start","--end","--len","--index","--length","--condense","--separator","--limit","--jobs","--seed","--size","--width","--pad","--filename","--prefix-length").contains(s);
    }
    static boolean shortNeedsValue(String cmd, String s) {
        if (cmd.equals("cat") && s.equals("-p")) return false;
        return Arrays.asList("-s","-e","-l","-i","-w","-p","-c","-j").contains(s);
    }
    static char one(String s) { if (s.equals("\\t")) return '\t'; return s.charAt(0); }
    static boolean eq(String s, String... xs) { for (String x: xs) if (s.equals(x)) return true; return false; }
    static void die(String s) { throw new RuntimeException(s); }

    static Reader reader(String path) throws IOException {
        if (path == null || path.equals("-")) return new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        return Files.newBufferedReader(Paths.get(path), StandardCharsets.UTF_8);
    }
    static Csv read(Opt o, String path) throws IOException {
        Csv c = new Csv();
        try (Reader r = reader(path)) {
            List<String> rec = new ArrayList<>();
            StringBuilder f = new StringBuilder();
            boolean inq=false, any=false;
            int x;
            while ((x=r.read())!=-1) {
                char ch=(char)x; any=true;
                if (!o.noQuoting && inq) {
                    if (ch==o.quote) {
                        r.mark(1); int n=r.read();
                        if (n==o.quote && o.escape==null) f.append(o.quote);
                        else { inq=false; if (n!=-1) r.reset(); }
                    } else if (o.escape!=null && ch==o.escape) {
                        int n=r.read(); if (n!=-1) f.append((char)n);
                    } else f.append(ch);
                } else {
                    if (!o.noQuoting && ch==o.quote && f.length()==0) inq=true;
                    else if (ch==o.delim) { rec.add(f.toString()); f.setLength(0); }
                    else if (ch=='\n') { rec.add(stripCR(f)); f.setLength(0); c.rows.add(rec); rec=new ArrayList<>(); }
                    else f.append(ch);
                }
            }
            if (any && (f.length()>0 || !rec.isEmpty())) { rec.add(stripCR(f)); c.rows.add(rec); }
        }
        return c;
    }
    static String stripCR(StringBuilder b) {
        int n=b.length(); if (n>0 && b.charAt(n-1)=='\r') return b.substring(0,n-1); return b.toString();
    }
    static PrintWriter out(Opt o) throws IOException {
        if (o.output == null) return new PrintWriter(new OutputStreamWriter(System.out, StandardCharsets.UTF_8), true);
        return new PrintWriter(Files.newBufferedWriter(Paths.get(o.output), StandardCharsets.UTF_8));
    }
    static void writeRows(Opt o, List<List<String>> rows) throws IOException {
        try (PrintWriter w = out(o)) { for (List<String> r: rows) writeRow(o,w,r); }
    }
    static void writeRow(Opt o, PrintWriter w, List<String> r) {
        for (int i=0;i<r.size();i++) {
            if (i>0) w.print(o.outDelim);
            String s=r.get(i)==null?"":r.get(i);
            boolean q=o.quoteAlways || s.indexOf(o.outDelim)>=0 || s.indexOf('\n')>=0 || s.indexOf('\r')>=0 || s.indexOf(o.quote)>=0;
            if (q) {
                w.print(o.quote);
                for (int j=0;j<s.length();j++) {
                    char ch=s.charAt(j);
                    if (ch==o.quote) { if (o.escape!=null) w.print(o.escape); else w.print(o.quote); }
                    w.print(ch);
                }
                w.print(o.quote);
            } else w.print(s);
        }
        String rt=o.vals.get("recordTerm");
        if (rt!=null) w.print(rt); else if (o.crlf) w.print("\r\n"); else w.print("\n");
    }

    static void count(Opt o) throws Exception {
        Csv c=read(o,o.input); int n=c.rows.size(); if (!o.noHeaders && n>0) n--; System.out.println(Math.max(0,n));
    }
    static void headers(Opt o) throws Exception {
        if (o.pos.isEmpty()) o.pos.add(null);
        List<Set<String>> sets=new ArrayList<>(); List<String> first=null;
        for (String p:o.pos) { Csv csv=read(o,p); List<String> h=csv.rows.isEmpty()?new ArrayList<>():csv.rows.get(0); if(first==null)first=h; sets.add(new LinkedHashSet<>(h)); }
        PrintWriter w=out(o);
        if (o.flags.contains("--intersect")) {
            LinkedHashSet<String> inter=new LinkedHashSet<>(first==null?Collections.emptyList():first);
            for(Set<String>s:sets) inter.retainAll(s);
            for(String h:inter) w.println(h);
        } else if (o.flags.contains("-j")||o.flags.contains("--just-names")||o.pos.size()>1) for(String h:first) w.println(h);
        else for(int i=0;i<first.size();i++) w.printf("%d   %s%n", i+1, first.get(i));
        w.flush();
    }
    static void fmt(Opt o) throws Exception { writeRows(o, read(o,o.input).rows); }
    static void select(Opt o) throws Exception {
        String sel=o.pos.get(0); String path=o.pos.size()>1?o.pos.get(1):null; Csv c=read(o,path);
        List<Integer> idx = selection(sel, c.rows.isEmpty()?Collections.emptyList():c.rows.get(0), o.noHeaders, maxCols(c.rows));
        List<List<String>> out=new ArrayList<>(); for(List<String> r:c.rows) out.add(project(r,idx)); writeRows(o,out);
    }
    static void slice(Opt o) throws Exception {
        Csv c=read(o,o.input); List<List<String>> out=new ArrayList<>(); int off=0; if(!o.noHeaders&&!c.rows.isEmpty()){out.add(c.rows.get(0));off=1;}
        int size=c.rows.size()-off, s=num(o,"-s","--start",0), e=num(o,"-e","--end",size);
        if (has(o,"-i","--index")) { s=num(o,"-i","--index",0); e=s+1; }
        if (has(o,"-l","--len")) e=s+num(o,"-l","--len",0);
        for(int i=Math.max(0,s); i<Math.min(size,e); i++) out.add(c.rows.get(off+i)); writeRows(o,out);
    }
    static void sort(Opt o) throws Exception {
        Csv c=read(o,o.input); String header=null; if(!o.noHeaders&&!c.rows.isEmpty()) header=String.join("\u0000",c.rows.remove(0));
        List<Integer> idx=has(o,"-s","--select")?selection(val(o,"-s","--select"), header==null?Collections.emptyList():Arrays.asList(header.split("\u0000",-1)), o.noHeaders, maxCols(c.rows)):null;
        c.rows.sort((a,b)->cmpRows(a,b,idx,o.flags.contains("-N")||o.flags.contains("--numeric")));
        if(o.flags.contains("-R")||o.flags.contains("--reverse")) Collections.reverse(c.rows);
        if(header!=null)c.rows.add(0,Arrays.asList(header.split("\u0000",-1))); writeRows(o,c.rows);
    }
    static int cmpRows(List<String>a,List<String>b,List<Integer>idx,boolean num){ List<Integer> is=idx; if(is==null){is=new ArrayList<>(); for(int i=0;i<Math.max(a.size(),b.size());i++)is.add(i);}
        for(int i:is){ String x=get(a,i), y=get(b,i); int c=num?Double.compare(parseD(x),parseD(y)):x.compareTo(y); if(c!=0)return c;} return 0; }
    static double parseD(String s){ try{return Double.parseDouble(s.trim());}catch(Exception e){return 0;}}
    static void reverse(Opt o) throws Exception { Csv c=read(o,o.input); int from=(!o.noHeaders&&!c.rows.isEmpty())?1:0; Collections.reverse(c.rows.subList(from,c.rows.size())); writeRows(o,c.rows); }
    static void fixlengths(Opt o) throws Exception { Csv c=read(o,o.input); int n=has(o,"-l","--length")?num(o,"-l","--length",1):maxCols(c.rows); for(List<String>r:c.rows){while(r.size()<n)r.add(""); while(r.size()>n)r.remove(r.size()-1);} writeRows(o,c.rows); }
    static void flatten(Opt o) throws Exception {
        Csv c=read(o,o.input); List<String> h; int start=0; if(!o.noHeaders&&!c.rows.isEmpty()){h=c.rows.get(0);start=1;}else{int n=maxCols(c.rows);h=new ArrayList<>();for(int i=1;i<=n;i++)h.add(String.valueOf(i));}
        int cond=has(o,"-c","--condense")?num(o,"-c","--condense",0):-1; String sep=o.vals.getOrDefault("--separator", o.vals.getOrDefault("-s","#"));
        PrintWriter w=out(o); for(int ri=start;ri<c.rows.size();ri++){List<String>r=c.rows.get(ri); for(int i=0;i<Math.max(h.size(),r.size());i++){String v=get(r,i); if(cond>=0&&v.length()>cond)v=v.substring(0,Math.min(cond,v.length())); w.printf("%s   %s%n", i<h.size()?h.get(i):String.valueOf(i+1), v);} if(!sep.isEmpty())w.println(sep);} w.flush();
    }
    static void table(Opt o) throws Exception {
        Csv c=read(o,o.input); int width=num(o,"-w","--width",2), pad=num(o,"-p","--pad",2), cond=has(o,"-c","--condense")?num(o,"-c","--condense",0):-1; int cols=maxCols(c.rows); int[] wids=new int[cols];
        for(List<String>r:c.rows)for(int i=0;i<cols;i++){String v=get(r,i); if(cond>=0&&v.length()>cond)v=v.substring(0,Math.min(cond,v.length())); wids[i]=Math.max(wids[i],Math.max(width,v.length()));}
        PrintWriter out=out(o); String spaces=" ".repeat(Math.max(0,pad)); for(List<String>r:c.rows){for(int i=0;i<cols;i++){if(i>0)out.print(spaces); String v=get(r,i); if(cond>=0&&v.length()>cond)v=v.substring(0,Math.min(cond,v.length())); out.print(padRight(v,wids[i]));} out.println();} out.flush();
    }
    static void frequency(Opt o) throws Exception {
        Csv c=read(o,o.input); List<String> h; int start=0; if(!o.noHeaders&&!c.rows.isEmpty()){h=c.rows.get(0);start=1;}else{int n=maxCols(c.rows);h=new ArrayList<>();for(int i=1;i<=n;i++)h.add(String.valueOf(i));}
        List<Integer> idx=has(o,"-s","--select")?selection(val(o,"-s","--select"),h,o.noHeaders,h.size()):range(h.size()); int lim=num(o,"-l","--limit",10); List<List<String>> rows=new ArrayList<>(); rows.add(Arrays.asList("field","value","count"));
        for(int ci:idx){Map<String,Integer> m=new HashMap<>(); for(int r=start;r<c.rows.size();r++){String v=get(c.rows.get(r),ci); if((o.flags.contains("--no-nulls"))&&v.isEmpty())continue; m.put(v,m.getOrDefault(v,0)+1);} List<Map.Entry<String,Integer>> es=new ArrayList<>(m.entrySet()); es.sort((a,b)->{int cmp=o.flags.contains("-a")||o.flags.contains("--asc")?Integer.compare(a.getValue(),b.getValue()):Integer.compare(b.getValue(),a.getValue()); return cmp!=0?cmp:b.getKey().compareTo(a.getKey());}); int n=lim==0?es.size():Math.min(lim,es.size()); for(int i=0;i<n;i++)rows.add(Arrays.asList(h.get(ci),es.get(i).getKey(),String.valueOf(es.get(i).getValue()))); }
        writeRows(o,rows);
    }
    static void stats(Opt o) throws Exception {
        Csv c=read(o,o.input); List<String> h; int start=0; if(!o.noHeaders&&!c.rows.isEmpty()){h=c.rows.get(0);start=1;}else{int n=maxCols(c.rows);h=new ArrayList<>();for(int i=1;i<=n;i++)h.add(String.valueOf(i));}
        List<Integer> idx=has(o,"-s","--select")?selection(val(o,"-s","--select"),h,o.noHeaders,h.size()):range(h.size()); boolean everything=o.flags.contains("--everything"); List<String> head=new ArrayList<>(Arrays.asList("field","type","sum","min","max","min_length","max_length","mean","stddev")); if(everything||o.flags.contains("--median"))head.add("median"); if(everything||o.flags.contains("--mode"))head.add("mode"); if(everything||o.flags.contains("--cardinality"))head.add("cardinality");
        List<List<String>> rows=new ArrayList<>(); rows.add(head);
        for(int ci:idx){List<String> vals=new ArrayList<>(); for(int r=start;r<c.rows.size();r++)vals.add(get(c.rows.get(r),ci)); rows.add(statRow(h.get(ci),vals,head,o.flags.contains("--nulls")));} writeRows(o,rows);
    }
    static List<String> statRow(String name,List<String> vals,List<String> head,boolean nulls){ List<Double> nums=new ArrayList<>(); double sum=0; int minl=Integer.MAX_VALUE,maxl=0; String min=null,max=null; Map<String,Integer> freq=new HashMap<>(); boolean allInt=true, allNum=true; for(String s:vals){minl=Math.min(minl,s.length());maxl=Math.max(maxl,s.length()); if(min==null||s.compareTo(min)<0)min=s; if(max==null||s.compareTo(max)>0)max=s; freq.put(s,freq.getOrDefault(s,0)+1); if(s.isEmpty()&&!nulls)continue; try{double d=Double.parseDouble(s); nums.add(d); sum+=d; if(d!=Math.rint(d))allInt=false;}catch(Exception e){allNum=false;}} int n=nums.size(); double mean=n==0?Double.NaN:sum/n; double var=0; for(double d:nums)var+=(d-mean)*(d-mean); double sd=n==0?Double.NaN:Math.sqrt(var/n); String type=allNum?(allInt?"Integer":"Float"):"Unicode"; List<String> r=new ArrayList<>(Arrays.asList(name,type,allNum?fmtNum(sum):"",min==null?"":min,max==null?"":max,String.valueOf(minl==Integer.MAX_VALUE?0:minl),String.valueOf(maxl),allNum?fmtNum(mean):"",allNum?fmtNum(sd):"")); Collections.sort(nums); for(int i=9;i<head.size();i++){String col=head.get(i); if(col.equals("median"))r.add(n==0?"":fmtNum(n%2==1?nums.get(n/2):(nums.get(n/2-1)+nums.get(n/2))/2)); else if(col.equals("mode"))r.add(freq.entrySet().stream().max((a,b)->a.getValue().equals(b.getValue())?b.getKey().compareTo(a.getKey()):Integer.compare(a.getValue(),b.getValue())).map(Map.Entry::getKey).orElse("")); else if(col.equals("cardinality"))r.add(String.valueOf(freq.size()));} return r; }
    static void search(Opt o) throws Exception { String re=o.pos.get(0), path=o.pos.size()>1?o.pos.get(1):null; int fl=o.flags.contains("-i")||o.flags.contains("--ignore-case")?Pattern.CASE_INSENSITIVE:0; Pattern p=Pattern.compile(re,fl); Csv c=read(o,path); List<String> h=c.rows.isEmpty()?Collections.emptyList():c.rows.get(0); List<Integer> idx=has(o,"-s","--select")?selection(val(o,"-s","--select"),h,o.noHeaders,maxCols(c.rows)):null; List<List<String>> rows=new ArrayList<>(); int start=0; if(!o.noHeaders&&!c.rows.isEmpty()){rows.add(c.rows.get(0));start=1;} for(int r=start;r<c.rows.size();r++){boolean m=false; List<String> row=c.rows.get(r); List<Integer> is=idx==null?range(row.size()):idx; for(int i:is)if(p.matcher(get(row,i)).find()){m=true;break;} if(o.flags.contains("-v")||o.flags.contains("--invert-match"))m=!m; if(m)rows.add(row);} writeRows(o,rows); }
    static void cat(Opt o) throws Exception { if(o.pos.isEmpty())die("expected mode"); String mode=o.pos.get(0); List<String> files=o.pos.subList(1,o.pos.size()); if(mode.equals("rows")){List<List<String>> out=new ArrayList<>(); for(int fi=0;fi<files.size();fi++){Csv c=read(o,files.get(fi)); int st=(!o.noHeaders&&fi>0&&!c.rows.isEmpty())?1:0; for(int i=st;i<c.rows.size();i++)out.add(c.rows.get(i));} writeRows(o,out);} else {List<Csv> cs=new ArrayList<>(); for(String f:files)cs.add(read(o,f)); int rows=o.flags.contains("-p")||o.flags.contains("--pad")?cs.stream().mapToInt(c->c.rows.size()).max().orElse(0):cs.stream().mapToInt(c->c.rows.size()).min().orElse(0); List<List<String>> out=new ArrayList<>(); for(int r=0;r<rows;r++){List<String> row=new ArrayList<>(); for(Csv c:cs) if(r<c.rows.size())row.addAll(c.rows.get(r)); else for(int i=0;i<maxCols(c.rows);i++)row.add(""); out.add(row);} writeRows(o,out);} }
    static void join(Opt o) throws Exception { boolean cross=o.flags.contains("--cross"); String c1=o.pos.get(0), f1=o.pos.get(1), c2=o.pos.get(2), f2=o.pos.get(3); Csv a=read(o,f1), b=read(o,f2); List<String> ha=a.rows.isEmpty()?Collections.emptyList():a.rows.get(0), hb=b.rows.isEmpty()?Collections.emptyList():b.rows.get(0); int s1=o.noHeaders?0:1,s2=o.noHeaders?0:1; List<Integer> ia=selection(c1,ha,o.noHeaders,maxCols(a.rows)), ib=selection(c2,hb,o.noHeaders,maxCols(b.rows)); List<List<String>> out=new ArrayList<>(); if(!o.noHeaders&&!a.rows.isEmpty()&&!b.rows.isEmpty()){List<String> h=new ArrayList<>(ha);h.addAll(hb);out.add(h);} Set<Integer> matchedB=new HashSet<>(); for(int i=s1;i<a.rows.size();i++){boolean any=false; for(int j=s2;j<b.rows.size();j++){if(cross||key(a.rows.get(i),ia,o).equals(key(b.rows.get(j),ib,o))){List<String> r=new ArrayList<>(a.rows.get(i));r.addAll(b.rows.get(j));out.add(r);any=true;matchedB.add(j);}} if(!any&&(o.flags.contains("--left")||o.flags.contains("--full"))){List<String> r=new ArrayList<>(a.rows.get(i)); for(int k=0;k<maxCols(b.rows);k++)r.add(""); out.add(r);}} if(o.flags.contains("--right")||o.flags.contains("--full"))for(int j=s2;j<b.rows.size();j++)if(!matchedB.contains(j)){List<String> r=new ArrayList<>(); for(int k=0;k<maxCols(a.rows);k++)r.add(""); r.addAll(b.rows.get(j)); out.add(r);} writeRows(o,out); }
    static void sample(Opt o) throws Exception { int n=Integer.parseInt(o.pos.get(0)); String path=o.pos.size()>1?o.pos.get(1):null; Csv c=read(o,path); List<List<String>> rows=new ArrayList<>(); int st=0; if(!o.noHeaders&&!c.rows.isEmpty()){rows.add(c.rows.get(0));st=1;} List<List<String>> pool=new ArrayList<>(c.rows.subList(st,c.rows.size())); Random rnd=new Random(has(o,"--seed","--seed")?Long.parseLong(val(o,"--seed","--seed")):System.nanoTime()); Collections.shuffle(pool,rnd); rows.addAll(pool.subList(0,Math.min(n,pool.size()))); writeRows(o,rows); }
    static void split(Opt o) throws Exception { String dir=o.pos.get(0), path=o.pos.size()>1?o.pos.get(1):null; Files.createDirectories(Paths.get(dir)); Csv c=read(o,path); int size=num(o,"-s","--size",500), st=o.noHeaders?0:1, idx=0; List<String> h=!o.noHeaders&&!c.rows.isEmpty()?c.rows.get(0):null; String templ=o.vals.getOrDefault("--filename","{}.csv"); for(int i=st;i<c.rows.size();i+=size){List<List<String>> part=new ArrayList<>(); if(h!=null)part.add(h); part.addAll(c.rows.subList(i,Math.min(c.rows.size(),i+size))); Opt oo=o; oo.output=Paths.get(dir,templ.replace("{}",String.valueOf(idx))).toString(); writeRows(oo,part); idx+=size;} }
    static void partition(Opt o) throws Exception { String col=o.pos.get(0), dir=o.pos.get(1), path=o.pos.size()>2?o.pos.get(2):null; Files.createDirectories(Paths.get(dir)); Csv c=read(o,path); List<String> h=c.rows.isEmpty()?Collections.emptyList():c.rows.get(0); int ci=selection(col,h,o.noHeaders,maxCols(c.rows)).get(0), st=o.noHeaders?0:1; Map<String,List<List<String>>> m=new LinkedHashMap<>(); for(int i=st;i<c.rows.size();i++){String k=safe(get(c.rows.get(i),ci)); m.computeIfAbsent(k,x->{List<List<String>> l=new ArrayList<>(); if(!o.noHeaders&&!c.rows.isEmpty())l.add(o.flags.contains("--drop")?drop(c.rows.get(0),ci):c.rows.get(0)); return l;}).add(o.flags.contains("--drop")?drop(c.rows.get(i),ci):c.rows.get(i));} String templ=o.vals.getOrDefault("--filename","{}.csv"); for(Map.Entry<String,List<List<String>>>e:m.entrySet()){Opt oo=o; oo.output=Paths.get(dir,templ.replace("{}",e.getKey())).toString(); writeRows(oo,e.getValue());} }
    static void index(Opt o) throws Exception { String in=o.pos.get(0); String out=o.output!=null?o.output:in+".idx"; long n=Files.size(Paths.get(in)); Files.write(Paths.get(out), ("xsv-index\n"+n+"\n").getBytes(StandardCharsets.UTF_8)); }

    static String key(List<String> r,List<Integer>idx,Opt o){List<String>ks=new ArrayList<>();for(int i:idx){String s=get(r,i).trim(); if(s.isEmpty()&&!o.flags.contains("--nulls"))return "\u0001"+UUID.randomUUID(); if(o.flags.contains("--no-case"))s=s.toLowerCase(Locale.ROOT); ks.add(s);}return String.join("\u0000",ks);}
    static List<Integer> selection(String spec,List<String> header,boolean noHeaders,int max){ boolean inv=spec.startsWith("!"); if(inv)spec=spec.substring(1); List<Integer> out=new ArrayList<>(); for(String p:splitSpec(spec)){ if(p.isEmpty())continue; int dash=findDash(p); if(dash>=0){String a=p.substring(0,dash),b=p.substring(dash+1); int s=a.isEmpty()?1:col(a,header,noHeaders,max)+1, e=b.isEmpty()?max:col(b,header,noHeaders,max)+1; if(s<=e)for(int i=s;i<=e;i++)out.add(i-1); else for(int i=s;i>=e;i--)out.add(i-1);} else out.add(col(p,header,noHeaders,max)); } if(inv){Set<Integer>s=new HashSet<>(out); out=new ArrayList<>(); for(int i=0;i<max;i++)if(!s.contains(i))out.add(i);} return out; }
    static List<String> splitSpec(String s){List<String>r=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i); if(c=='"'){q=!q;continue;} if(c==','&&!q){r.add(b.toString());b.setLength(0);}else b.append(c);}r.add(b.toString());return r;}
    static int findDash(String p){ if(p.equals("-"))return -1; boolean q=false; for(int i=0;i<p.length();i++){char c=p.charAt(i); if(c=='"')q=!q; else if(c=='-'&&!q)return i;} return -1; }
    static int col(String s,List<String> h,boolean no,int max){ s=s.trim(); Matcher m=Pattern.compile("^(.*)\\[(\\d+)\\]$").matcher(s); int occ=1; if(m.matches()){s=m.group(1);occ=Integer.parseInt(m.group(2));} if(s.matches("\\d+"))return Math.max(0,Integer.parseInt(s)-1); int seen=0; for(int i=0;i<h.size();i++)if(h.get(i).equals(s)&&++seen==occ)return i; die("Column not found: "+s); return 0; }
    static List<String> project(List<String> r,List<Integer>idx){List<String>o=new ArrayList<>();for(int i:idx)o.add(get(r,i));return o;}
    static List<String> drop(List<String> r,int ci){List<String>o=new ArrayList<>(r); if(ci<o.size())o.remove(ci); return o;}
    static String get(List<String> r,int i){return i>=0&&i<r.size()?r.get(i):"";}
    static int maxCols(List<List<String>> rs){int m=0;for(List<String>r:rs)m=Math.max(m,r.size());return Math.max(1,m);}
    static List<Integer> range(int n){List<Integer>r=new ArrayList<>();for(int i=0;i<n;i++)r.add(i);return r;}
    static boolean has(Opt o,String a,String b){return o.vals.containsKey(a)||o.vals.containsKey(b)||o.flags.contains(a)||o.flags.contains(b);}
    static String val(Opt o,String a,String b){return o.vals.containsKey(a)?o.vals.get(a):o.vals.get(b);}
    static int num(Opt o,String a,String b,int d){String v=val(o,a,b);return v==null?d:Integer.parseInt(v);}
    static String padRight(String s,int n){return s+" ".repeat(Math.max(0,n-s.length()));}
    static String fmtNum(double d){ if(Double.isNaN(d))return ""; if(Math.abs(d-Math.rint(d))<1e-9)return String.valueOf((long)Math.rint(d)); String s=String.format(Locale.ROOT,"%.6f",d); return s.replaceAll("0+$","").replaceAll("\\.$","");}
    static String safe(String s){s=s.replaceAll("[^A-Za-z0-9._-]+","_"); return s.isEmpty()?"_":s;}
    static String help(String cmd) { return HELP; }
}
