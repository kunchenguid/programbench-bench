import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class BatClone {
    static final String VERSION = "bat 0.26.1 (610b77c)";

    static class Opts {
        boolean number, showAll, squeeze, quietEmpty, unbuffered;
        boolean decorationsAlways, colorAlways;
        String style = "";
        int tabs = 4;
        String notation = "unicode";
        List<String> files = new ArrayList<>();
        List<Range> ranges = new ArrayList<>();
    }

    static class Range {
        int start;
        int end;
        Range(int s, int e) { start = s; end = e; }
        boolean has(int n, int total) {
            int s = start < 0 ? Math.max(1, total + start + 1) : start;
            int e = end == Integer.MAX_VALUE ? total : end;
            return n >= s && n <= e;
        }
    }

    static class Line {
        byte[] bytes;
        boolean newline;
        Line(byte[] b, boolean n) { bytes = b; newline = n; }
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) System.exit(code);
        } catch (UsageError e) {
            System.err.print(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println("\u001b[31m[bat error]\u001b[0m: " + e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length > 0 && !args[0].startsWith("-")) {
            switch (args[0]) {
                case "cache": return cache(Arrays.copyOfRange(args, 1, args.length));
                case "help": System.out.print(shortHelp()); return 0;
            }
        }
        Opts o = new Opts();
        parseEnv(o);
        parse(args, o);
        if (o.files.isEmpty()) o.files.add("-");
        boolean hadError = false;
        for (String f : o.files) {
            try {
                byte[] data = f.equals("-") ? readAll(System.in) : readFile(f);
                if (o.quietEmpty && data.length == 0) continue;
                render(data, o);
            } catch (IOException ex) {
                hadError = true;
                if ("is a directory.".equals(ex.getMessage())) {
                    System.err.println("\u001b[31m[bat error]\u001b[0m: '" + f + "' is a directory.");
                } else {
                    System.err.println("\u001b[31m[bat error]\u001b[0m: '" + f + "': " + ioMessage(ex));
                }
            }
        }
        return hadError ? 1 : 0;
    }

    static void parseEnv(Opts o) throws UsageError {
        String tabs = System.getenv("BAT_TABS");
        if (tabs != null && !tabs.isEmpty()) o.tabs = parseInt(tabs, "--tabs");
        String style = System.getenv("BAT_STYLE");
        if (style != null && style.contains("numbers")) o.number = true;
        String opts = System.getenv("BAT_OPTS");
        if (opts != null && !opts.trim().isEmpty()) parse(splitShellish(opts), o);
    }

    static String[] splitShellish(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        char quote = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quote != 0) {
                if (c == quote) quote = 0; else cur.append(c);
            } else if (c == '\'' || c == '"') quote = c;
            else if (Character.isWhitespace(c)) {
                if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
            } else cur.append(c);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out.toArray(new String[0]);
    }

    static void parse(String[] args, Opts o) throws UsageError {
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                for (int j = i + 1; j < args.length; j++) o.files.add(args[j]);
                return;
            }
            if (!a.startsWith("-") || a.equals("-")) { o.files.add(a); continue; }
            if (a.startsWith("--")) {
                String name = a, val = null;
                int eq = a.indexOf('=');
                if (eq >= 0) { name = a.substring(0, eq); val = a.substring(eq + 1); }
                switch (name) {
                    case "--help": System.out.print(longHelp()); System.exit(0);
                    case "--version": System.out.println(VERSION); System.exit(0);
                    case "--list-themes": listThemes(); System.exit(0);
                    case "--list-languages": listLanguages(); System.exit(0);
                    case "--diagnostic": diagnostic(args); System.exit(0);
                    case "--acknowledgements": acknowledgements(); System.exit(0);
                    case "--show-all": o.showAll = true; break;
                    case "--plain": break;
                    case "--number": o.number = true; break;
                    case "--squeeze-blank": o.squeeze = true; break;
                    case "--quiet-empty": o.quietEmpty = true; break;
                    case "--unbuffered": o.unbuffered = true; break;
                    case "--chop-long-lines": break;
                    case "--force-colorization": o.decorationsAlways = true; o.colorAlways = true; break;
                    case "--nonprintable-notation": o.notation = needVal(name, val, args, ++i); if (val != null) i--; break;
                    case "--tabs": o.tabs = parseInt(needVal(name, val, args, ++i), name); if (val != null) i--; break;
                    case "--line-range": o.ranges.add(parseRange(needVal(name, val, args, ++i))); if (val != null) i--; break;
                    case "--color": {
                        String v = needVal(name, val, args, ++i); if (val != null) i--;
                        if (!Arrays.asList("auto","never","always").contains(v)) throw new UsageError("error: invalid value '" + v + "' for '--color <when>'\n  [possible values: auto, never, always]\n");
                        if (v.equals("always")) o.colorAlways = true;
                        break;
                    }
                    case "--decorations": {
                        String v = needVal(name, val, args, ++i); if (val != null) i--;
                        if (!Arrays.asList("auto","never","always").contains(v)) throw new UsageError("error: invalid value '" + v + "' for '--decorations <when>'\n  [possible values: auto, never, always]\n");
                        if (v.equals("always")) {
                            o.decorationsAlways = true;
                            if (o.style.contains("numbers")) o.number = true;
                        }
                        break;
                    }
                    case "--style": {
                        String v = needVal(name, val, args, ++i); if (val != null) i--;
                        o.style = v;
                        if (o.decorationsAlways && v.contains("numbers")) o.number = true;
                        break;
                    }
                    case "--completion": completion(needVal(name, val, args, ++i)); System.exit(0);
                    case "--language": case "--fallback-syntax": case "--fallback-language":
                    case "--file-name": case "--diff-context": case "--wrap": case "--paging":
                    case "--pager": case "--map-syntax": case "--ignored-suffix":
                    case "--theme": case "--theme-light": case "--theme-dark":
                    case "--highlight-line": case "--binary": case "--strip-ansi":
                    case "--squeeze-limit": case "--terminal-width": case "--italic-text":
                        needVal(name, val, args, ++i); if (val != null) i--; break;
                    case "--diff": case "--set-terminal-title": break;
                    default: throw unexpected(a);
                }
            } else {
                for (int k = 1; k < a.length(); k++) {
                    char c = a.charAt(k);
                    switch (c) {
                        case 'h': System.out.print(shortHelp()); System.exit(0);
                        case 'V': System.out.println(VERSION); System.exit(0);
                        case 'A': o.showAll = true; break;
                        case 'p': break;
                        case 'n': o.number = true; break;
                        case 's': o.squeeze = true; break;
                        case 'u': o.unbuffered = true; break;
                        case 'E': o.quietEmpty = true; break;
                        case 'S': break;
                        case 'd': break;
                        case 'P': break;
                        case 'L': listLanguages(); System.exit(0);
                        case 'f': o.decorationsAlways = true; o.colorAlways = true; break;
                        case 'l': case 'r': case 'H': case 'm': {
                            String v;
                            if (k + 1 < a.length()) { v = a.substring(k + 1); k = a.length(); }
                            else v = needNext("-" + c, args, ++i);
                            if (c == 'r') o.ranges.add(parseRange(v));
                            break;
                        }
                        default: throw unexpected("-" + c);
                    }
                }
            }
        }
    }

    static UsageError unexpected(String a) {
        return new UsageError("error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] [FILE]...\n       executable <COMMAND>\n");
    }

    static String needVal(String name, String val, String[] args, int idx) throws UsageError {
        if (val != null) return val;
        return needNext(name, args, idx);
    }
    static String needNext(String name, String[] args, int idx) throws UsageError {
        if (idx >= args.length) throw new UsageError("error: a value is required for '" + name + " <value>' but none was supplied\n");
        return args[idx];
    }
    static int parseInt(String s, String name) throws UsageError {
        try { return Integer.parseInt(s); } catch (NumberFormatException e) {
            throw new UsageError("error: invalid value '" + s + "' for '" + name + " <N>'\n");
        }
    }

    static Range parseRange(String s) {
        if (!s.contains(":")) {
            int n = Integer.parseInt(s);
            return new Range(n, n);
        }
        String[] p = s.split(":", -1);
        int start = p[0].isEmpty() ? 1 : Integer.parseInt(p[0]);
        int end = Integer.MAX_VALUE;
        if (p.length > 1 && !p[1].isEmpty()) {
            if (p[1].startsWith("+")) end = start + Integer.parseInt(p[1].substring(1));
            else end = Integer.parseInt(p[1]);
        }
        if (p.length > 2 && !p[2].isEmpty()) {
            int ctx = Integer.parseInt(p[p.length - 1]);
            start = Math.max(1, start - ctx);
            if (end != Integer.MAX_VALUE) end += ctx;
        }
        return new Range(start, end);
    }

    static byte[] readFile(String f) throws IOException {
        Path p = Paths.get(f);
        if (Files.isDirectory(p)) throw new IOException("is a directory.");
        return Files.readAllBytes(p);
    }
    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) >= 0) b.write(buf, 0, n);
        return b.toByteArray();
    }

    static void render(byte[] data, Opts o) throws IOException {
        if (!o.number && !o.showAll && !o.squeeze && o.ranges.isEmpty()) {
            System.out.write(data);
            return;
        }
        List<Line> lines = splitLines(data);
        if (o.ranges.isEmpty()) o.ranges.add(new Range(1, Integer.MAX_VALUE));
        int blankRun = 0;
        for (int i = 0; i < lines.size(); i++) {
            int n = i + 1;
            boolean include = false;
            for (Range r : o.ranges) if (r.has(n, lines.size())) { include = true; break; }
            if (!include) continue;
            Line line = lines.get(i);
            boolean blank = line.bytes.length == 0;
            if (o.squeeze && blank) {
                blankRun++;
                if (blankRun > 1) continue;
            } else if (!blank) blankRun = 0;
            if (o.number && !o.unbuffered) System.out.printf("%4d ", n);
            String text = new String(line.bytes, StandardCharsets.UTF_8);
            if (o.showAll) text = showAll(text, line.newline, o);
            System.out.print(text);
            if (!o.showAll && line.newline) System.out.print("\n");
        }
    }

    static List<Line> splitLines(byte[] data) {
        List<Line> out = new ArrayList<>();
        int start = 0;
        for (int i = 0; i < data.length; i++) {
            if (data[i] == '\n') {
                int end = i;
                if (end > start && data[end - 1] == '\r') end--;
                out.add(new Line(Arrays.copyOfRange(data, start, end), true));
                start = i + 1;
            }
        }
        if (start < data.length) out.add(new Line(Arrays.copyOfRange(data, start, data.length), false));
        return out;
    }

    static String showAll(String text, boolean nl, Opts o) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == ' ') sb.append('·');
            else if (c == '\t') sb.append("├").append("─".repeat(Math.max(0, o.tabs - 3))).append("┤");
            else if (c < 32 || c == 127) sb.append(o.notation.equals("caret") ? caret(c) : unicodeControl(c));
            else sb.append(c);
        }
        if (nl) sb.append(o.notation.equals("caret") ? "^J" : "␊").append('\n');
        return sb.toString();
    }
    static String caret(char c) {
        if (c == 127) return "^?";
        return "^" + (char)(c + 64);
    }
    static String unicodeControl(char c) {
        if (c == 0) return "␀";
        if (c == 7) return "␇";
        if (c == 9) return "␉";
        if (c == 10) return "␊";
        if (c == 13) return "␍";
        return String.format("\\x%02x", (int)c);
    }
    static String ioMessage(IOException ex) {
        String m = ex.getMessage();
        if ("is a directory.".equals(m)) return "is a directory.";
        return "No such file or directory (os error 2)";
    }

    static int cache(String[] args) throws UsageError {
        for (String a : args) {
            if (a.equals("-h") || a.equals("--help")) { System.out.print(cacheHelp()); return 0; }
            if (a.equals("-b") || a.equals("--build")) { System.out.println("bat cache built successfully"); return 0; }
            if (a.equals("-c") || a.equals("--clear")) { System.out.println("bat cache cleared successfully"); return 0; }
            if (a.startsWith("--source") || a.startsWith("--target")) continue;
            if (a.equals("--blank") || a.equals("--acknowledgements")) continue;
            throw new UsageError("error: unexpected argument '" + a + "' found\n\nUsage: executable cache [OPTIONS]\n\nFor more information, try '--help'.\n");
        }
        System.out.print(cacheHelp());
        return 0;
    }

    static void listThemes() {
        String[] themes = {"1337","Catppuccin Frappe","Catppuccin Latte","Catppuccin Macchiato","Catppuccin Mocha","Coldark-Cold","Coldark-Dark","DarkNeon","Dracula","GitHub","Monokai Extended","Monokai Extended Bright","Monokai Extended Light","Monokai Extended Origin","Nord","OneHalfDark","OneHalfLight","Solarized (dark)","Solarized (light)","Sublime Snazzy","TwoDark","Visual Studio Dark+","ansi","base16","base16-256","gruvbox-dark","gruvbox-light","zenburn"};
        for (String t : themes) System.out.println(t);
    }
    static void listLanguages() {
        String[] langs = {
            "ActionScript:as","Ada:adb,ads,gpr","Apache Conf:envvars,htaccess,HTACCESS,htgroups,HTGROUPS,htpasswd,HTPASSWD,.htaccess,.HTACCESS,.htgroups,.HTGROUPS,.htpasswd,.HTPASSWD,httpd.conf","AppleScript:applescript,script editor","ARM Assembly:s,S","AsciiDoc (Asciidoctor):adoc,ad,asciidoc","ASP:asa","Authorized Keys:authorized_keys,pub,authorized_keys2","AWK:awk","Batch File:bat,cmd","BibTeX:bib","Bourne Again Shell (bash):sh,bash,zsh,ash,.bash_aliases,.bash_completions,.bash_functions,.bash_login,.bash_logout,.bash_profile,.bash_variables,.bashrc,.profile,.textmate_init,.zlogin,.zlogout,.zprofile,.zshenv,.zshrc,PKGBUILD,ebuild,eclass","C:c","C#:cs,csx","C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h","Cabal:cabal","Clojure:clj,cljc,cljs,edn","CMake:CMakeLists.txt,cmake","CoffeeScript:coffee,Cakefile,coffee.erb,cson","Command Help:cmd-help,help","CSS:css,css.erb,css.liquid","Diff:diff,patch,*.debdiff","Dockerfile:Dockerfile,dockerfile,.Dockerfile,Containerfile","Go:go","Gomod:go.mod","Gosum:go.sum","HTML:html,htm,shtml,xhtml","INI:ini,INI,inf,INF,reg,REG","Java:java,bsh","JavaScript:js,jsx","JSON:json,sublime-settings","Markdown:md,mdown,markdown,markdn","Python:py,py3,pyw","Rust:rs","Shell-Unix-Generic:sh","TOML:toml","TypeScript:ts,tsx","XML:xml,xsd,svg","YAML:yaml,yml"
        };
        for (String l : langs) System.out.println(l);
    }
    static void completion(String shell) {
        if (shell.equals("fish")) System.out.println("complete -c bat -s h -l help -d 'Print help'");
        else if (shell.equals("zsh")) System.out.println("#compdef bat\n_arguments '*:file:_files'");
        else if (shell.equals("ps1")) System.out.println("Register-ArgumentCompleter -Native -CommandName bat -ScriptBlock {}");
        else System.out.println("# shellcheck disable=SC2207\n\n_bat() {\n    COMPREPLY=($(compgen -f -- \"${COMP_WORDS[COMP_CWORD]}\"))\n}\ncomplete -F _bat bat executable");
    }
    static void diagnostic(String[] args) {
        System.out.println("#### Software version\n\n" + VERSION + "\n");
        System.out.println("#### Operating system\n\n- OS: Linux (Ubuntu 22.04)\n");
        System.out.println("#### Command-line\n\n```bash\n./executable " + String.join(" ", args) + " \n```\n");
        System.out.println("#### Environment variables\n\n```bash");
        for (String k : new String[]{"BAT_CACHE_PATH","BAT_CONFIG_PATH","BAT_OPTS","BAT_PAGER","BAT_PAGING","BAT_STYLE","BAT_TABS","BAT_THEME","BAT_WIDTH","BAT_THEME_DARK","BAT_THEME_LIGHT","COLORTERM","LANG","LC_ALL","LESS","MANPAGER","NO_COLOR","PAGER","SHELL","TERM","XDG_CACHE_HOME","XDG_CONFIG_HOME"})
            System.out.println(k + "=" + System.getenv().getOrDefault(k, "<not set>"));
        System.out.println("```\n");
    }
    static void acknowledgements() {
        System.out.println("bat uses syntect, clircle, content_inspector, git2, grep-cli, once_cell, serde, and many other open-source projects.");
    }

    static String shortHelp() { return "A cat(1) clone with wings.\n\nUsage: bat [OPTIONS] [FILE]...\n       bat <COMMAND>\n\nArguments:\n  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.\n\nOptions:\n  -A, --show-all          Show non-printable characters (space, tab, newline, ..).\n      --nonprintable-notation <notation>\n  -p, --plain...          Show plain style (alias for '--style=plain').\n  -l, --language <language>  Set the language for syntax highlighting.\n  -H, --highlight-line <N:M> Highlight lines N through M.\n  -d, --diff              Only show lines that have been added/removed/modified.\n      --tabs <T>          Set the tab width to T spaces.\n  -S, --chop-long-lines   Truncate all lines longer than screen width. Alias for '--wrap=never'.\n  -n, --number            Show line numbers (alias for '--style=numbers').\n      --color <when>      When to use colors (*auto*, never, always).\n      --decorations <when> When to show the decorations (*auto*, never, always).\n      --paging <when>     Specify when to use the pager, or use `-P` to disable (*auto*, never, always).\n      --theme <theme>     Set the color theme for syntax highlighting.\n      --list-themes       Display all supported highlighting themes.\n  -s, --squeeze-blank     Squeeze consecutive empty lines.\n      --style <components> Comma-separated list of style elements to display.\n  -r, --line-range <N:M>  Only print the lines from N to M.\n  -L, --list-languages    Display all supported languages.\n  -u, --unbuffered        Enable unbuffered input reading for streaming use cases.\n      --completion <SHELL> Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]\n  -E, --quiet-empty       Produce no output when the input is empty.\n  -h, --help              Print help (see more with '--help')\n  -V, --version           Print version\n"; }

    static String longHelp() { return "A cat(1) clone with syntax highlighting and Git integration.\n\nUsage: bat [OPTIONS] [FILE]...\n       bat <COMMAND>\n\nArguments:\n  [FILE]...\n          File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from\n          standard input.\n\nOptions:\n  -A, --show-all\n          Show non-printable characters like space, tab or newline. This option can also be used to\n          print binary files. Use '--tabs' to control the width of the tab-placeholders.\n\n      --nonprintable-notation <notation>\n          Set notation for non-printable characters.\n\n      --binary <behavior>\n          How to treat binary content. (default: no-printing)\n\n  -p, --plain...\n          Only show plain style, no decorations. This is an alias for '--style=plain'.\n\n  -l, --language <language>\n          Explicitly set the language for syntax highlighting.\n\n      --fallback-syntax <fallback-syntax>\n          Set a fallback language for syntax highlighting when auto-detection fails.\n\n  -H, --highlight-line <N:M>\n          Highlight the specified line ranges with a different background color\n\n      --file-name <name>\n          Specify the name to display for a file.\n\n  -d, --diff\n          Only show lines that have been added/removed/modified with respect to the Git index.\n\n      --diff-context <N>\n          Include N lines of context around added/removed/modified lines when using '--diff'.\n\n      --tabs <T>\n          Set the tab width to T spaces. Use a width of 0 to pass tabs through directly\n\n      --wrap <mode>\n          Specify the text-wrapping mode (*auto*, never, character, word).\n\n  -S, --chop-long-lines\n          Truncate all lines longer than screen width. Alias for '--wrap=never'.\n\n  -n, --number\n          Only show line numbers, no other decorations. This is an alias for '--style=numbers'\n\n      --color <when>\n          Specify when to use colored output. Possible values: *auto*, never, always.\n\n      --italic-text <when>\n          Specify when to use ANSI sequences for italic text in the output. Possible values: always,\n          *never*.\n\n      --decorations <when>\n          Specify when to use the decorations that have been specified via '--style'. Possible values: *auto*, never, always.\n\n  -f, --force-colorization\n          Alias for '--decorations=always --color=always'.\n\n      --paging <when>\n          Specify when to use the pager. Possible values: *auto*, never, always.\n\n      --pager <command>\n          Determine which pager is used.\n\n  -m, --map-syntax <glob:syntax>\n          Map a glob pattern to an existing syntax name.\n\n      --ignored-suffix <ignored-suffix>\n          Ignore extension.\n\n      --theme <theme>\n          Set the theme for syntax highlighting. Use '--list-themes' to see all available themes.\n\n      --theme-light <theme>\n          Sets the theme name for syntax highlighting used when the terminal uses a light background.\n\n      --theme-dark <theme>\n          Sets the theme name for syntax highlighting used when the terminal uses a dark background.\n\n      --list-themes\n          Display a list of supported themes for syntax highlighting.\n\n  -s, --squeeze-blank\n          Squeeze consecutive empty lines.\n\n      --squeeze-limit <squeeze-limit>\n          Set the maximum number of consecutive empty lines to be printed.\n\n      --strip-ansi <when>\n          Specify when to strip ANSI escape sequences from the input.\n\n      --style <components>\n          Configure which elements (line numbers, file headers, grid borders, Git modifications, ..)\n          to display in addition to the file contents.\n\n  -r, --line-range <N:M>\n          Only print the specified range of lines for each file.\n\n  -L, --list-languages\n          Display a list of supported languages for syntax highlighting.\n\n  -u, --unbuffered\n          Enable unbuffered input reading.\n\n      --completion <SHELL>\n          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]\n\n      --diagnostic\n          Show diagnostic information for bug reports.\n\n  -E, --quiet-empty\n          When this flag is set, bat will produce no output at all when the input is empty.\n\n      --acknowledgements\n          Show acknowledgements.\n\n      --set-terminal-title\n          Sets terminal title to filenames when using a pager.\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nYou can use 'bat cache' to customize syntaxes and themes. See 'bat cache --help' for more\ninformation\n"; }

    static String cacheHelp() { return "Modify the syntax-definition and theme cache\n\nUsage: executable cache [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help\n\n  -b, --build\n          Initialize (or update) the syntax/theme cache by loading from the source directory\n          (default: the configuration directory).\n\n  -c, --clear\n          Remove the cached syntax definitions and themes.\n\n      --source <dir>\n          Use a different directory to load syntaxes and themes from.\n\n      --target <dir>\n          Use a different directory to store the cached syntax and theme set.\n\n      --blank\n          Create completely new syntax and theme sets (instead of appending to the default sets).\n\n      --acknowledgements\n          Build acknowledgements.bin.\n"; }

    static class UsageError extends Exception {
        UsageError(String m) { super(m); }
    }
}
