package elfcat;

import java.io.IOException;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public final class ElfCat {
    private static final String VERSION = "0.1.10";

    public static void main(String[] args) {
        if (args.length == 1 && (args[0].equals("--help") || args[0].equals("-h"))) {
            usage();
            return;
        }
        if (args.length == 1 && args[0].equals("--version")) {
            System.out.println("elfcat " + VERSION);
            return;
        }
        if (args.length != 1) {
            usage();
            System.exit(1);
        }

        Path input = Paths.get(args[0]);
        byte[] data;
        try {
            data = Files.readAllBytes(input);
        } catch (IOException e) {
            System.err.println("Failed to read file \"" + args[0] + "\": " + e.getMessage());
            System.exit(1);
            return;
        }

        Elf elf;
        try {
            elf = Elf.parse(input, data);
        } catch (ElfException e) {
            System.err.println("Failed to parse ELF: " + e.getMessage());
            System.exit(1);
            return;
        }

        String base = input.getFileName() == null ? args[0] : input.getFileName().toString();
        Path output = Paths.get(base + ".html");
        try {
            Files.writeString(output, Html.render(elf));
        } catch (IOException e) {
            System.err.println("Failed to write file \"" + output + "\": " + e.getMessage());
            System.exit(1);
        }
    }

    private static void usage() {
        System.out.println("Usage: elfcat <filename>");
        System.out.println("Writes <filename>.html to CWD.");
    }

    static final class ElfException extends Exception {
        ElfException(String message) {
            super(message);
        }
    }

    static final class Elf {
        final Path path;
        final byte[] bytes;
        final boolean is64;
        final ByteOrder order;
        final int abi;
        final int type;
        final int machine;
        final long entry;
        final long phoff;
        final long shoff;
        final int ehsize;
        final int phentsize;
        final int phnum;
        final int shentsize;
        final int shnum;
        final int shstrndx;
        final List<ProgramHeader> programs;
        final List<SectionHeader> sections;

        private Elf(Path path, byte[] bytes, boolean is64, ByteOrder order, int abi, int type,
                    int machine, long entry, long phoff, long shoff, int ehsize, int phentsize,
                    int phnum, int shentsize, int shnum, int shstrndx,
                    List<ProgramHeader> programs, List<SectionHeader> sections) {
            this.path = path;
            this.bytes = bytes;
            this.is64 = is64;
            this.order = order;
            this.abi = abi;
            this.type = type;
            this.machine = machine;
            this.entry = entry;
            this.phoff = phoff;
            this.shoff = shoff;
            this.ehsize = ehsize;
            this.phentsize = phentsize;
            this.phnum = phnum;
            this.shentsize = shentsize;
            this.shnum = shnum;
            this.shstrndx = shstrndx;
            this.programs = programs;
            this.sections = sections;
        }

        static Elf parse(Path path, byte[] b) throws ElfException {
            if (b.length < 16) throw new ElfException("file is smaller than ELF header's e_ident");
            if ((b[0] & 0xff) != 0x7f || b[1] != 'E' || b[2] != 'L' || b[3] != 'F') {
                throw new ElfException("Invalid magic");
            }
            int cls = b[4] & 0xff;
            if (cls != 1 && cls != 2) throw new ElfException("Unknown bitness: " + cls);
            int enc = b[5] & 0xff;
            if (enc != 1 && enc != 2) throw new ElfException("Unknown endianness: " + enc);
            boolean is64 = cls == 2;
            int headerSize = is64 ? 64 : 52;
            if (b.length < headerSize) throw new ElfException("file is smaller than ELF file header");
            ByteOrder order = enc == 1 ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN;
            Reader r = new Reader(b, order);

            int type = r.u16(16);
            int machine = r.u16(18);
            long entry;
            long phoff;
            long shoff;
            int ehsize;
            int phentsize;
            int phnum;
            int shentsize;
            int shnum;
            int shstrndx;
            if (is64) {
                entry = r.u64(24);
                phoff = r.u64(32);
                shoff = r.u64(40);
                ehsize = r.u16(52);
                phentsize = r.u16(54);
                phnum = r.u16(56);
                shentsize = r.u16(58);
                shnum = r.u16(60);
                shstrndx = r.u16(62);
            } else {
                entry = r.u32(24);
                phoff = r.u32(28);
                shoff = r.u32(32);
                ehsize = r.u16(40);
                phentsize = r.u16(42);
                phnum = r.u16(44);
                shentsize = r.u16(46);
                shnum = r.u16(48);
                shstrndx = r.u16(50);
            }

            List<ProgramHeader> ph = new ArrayList<>();
            for (int i = 0; i < phnum; i++) {
                long off = phoff + (long) i * phentsize;
                if (off < 0 || off + phentsize > b.length) break;
                if (is64) {
                    long typev = r.u32(off);
                    long flags = r.u32(off + 4);
                    ph.add(new ProgramHeader(i, typev, flags, r.u64(off + 8), r.u64(off + 16),
                            r.u64(off + 24), r.u64(off + 32), r.u64(off + 40), r.u64(off + 48)));
                } else {
                    long typev = r.u32(off);
                    long flags = r.u32(off + 24);
                    ph.add(new ProgramHeader(i, typev, flags, r.u32(off + 4), r.u32(off + 8),
                            r.u32(off + 12), r.u32(off + 16), r.u32(off + 20), r.u32(off + 28)));
                }
            }

            List<SectionHeader> sh = new ArrayList<>();
            for (int i = 0; i < shnum; i++) {
                long off = shoff + (long) i * shentsize;
                if (off < 0 || off + shentsize > b.length) break;
                SectionHeader s;
                if (is64) {
                    s = new SectionHeader(i, r.u32(off), r.u32(off + 4), r.u64(off + 8),
                            r.u64(off + 16), r.u64(off + 24), r.u64(off + 32), r.u32(off + 40),
                            r.u32(off + 44), r.u64(off + 48), r.u64(off + 56), "");
                } else {
                    s = new SectionHeader(i, r.u32(off), r.u32(off + 4), r.u32(off + 8),
                            r.u32(off + 12), r.u32(off + 16), r.u32(off + 20), r.u32(off + 24),
                            r.u32(off + 28), r.u32(off + 32), r.u32(off + 36), "");
                }
                sh.add(s);
            }
            if (shstrndx >= 0 && shstrndx < sh.size()) {
                SectionHeader names = sh.get(shstrndx);
                for (int i = 0; i < sh.size(); i++) {
                    SectionHeader s = sh.get(i);
                    sh.set(i, s.withName(readString(b, names.offset + s.nameOffset, names.offset + names.size)));
                }
            }
            return new Elf(path, b, is64, order, b[7] & 0xff, type, machine, entry, phoff, shoff,
                    ehsize, phentsize, phnum, shentsize, shnum, shstrndx, ph, sh);
        }

        private static String readString(byte[] b, long start, long limit) {
            if (start < 0 || start >= b.length) return "";
            int p = (int) start;
            int end = (int) Math.min(Math.min(limit, b.length), Integer.MAX_VALUE);
            StringBuilder sb = new StringBuilder();
            while (p < end && b[p] != 0) {
                int c = b[p++] & 0xff;
                if (c >= 32 && c < 127) sb.append((char) c);
                else sb.append('.');
            }
            return sb.toString();
        }
    }

    static final class ProgramHeader {
        final int index;
        final long type, flags, offset, vaddr, paddr, filesz, memsz, align;
        ProgramHeader(int index, long type, long flags, long offset, long vaddr, long paddr,
                      long filesz, long memsz, long align) {
            this.index = index;
            this.type = type;
            this.flags = flags;
            this.offset = offset;
            this.vaddr = vaddr;
            this.paddr = paddr;
            this.filesz = filesz;
            this.memsz = memsz;
            this.align = align;
        }
    }

    static final class SectionHeader {
        final int index;
        final long nameOffset, type, flags, addr, offset, size, link, info, addralign, entsize;
        final String name;
        SectionHeader(int index, long nameOffset, long type, long flags, long addr, long offset,
                      long size, long link, long info, long addralign, long entsize, String name) {
            this.index = index;
            this.nameOffset = nameOffset;
            this.type = type;
            this.flags = flags;
            this.addr = addr;
            this.offset = offset;
            this.size = size;
            this.link = link;
            this.info = info;
            this.addralign = addralign;
            this.entsize = entsize;
            this.name = name;
        }
        SectionHeader withName(String n) {
            return new SectionHeader(index, nameOffset, type, flags, addr, offset, size, link, info, addralign, entsize, n);
        }
    }

    static final class Reader {
        final byte[] b;
        final boolean le;
        Reader(byte[] b, ByteOrder order) {
            this.b = b;
            this.le = order == ByteOrder.LITTLE_ENDIAN;
        }
        int u16(long off) {
            int o = (int) off;
            if (le) return (b[o] & 0xff) | ((b[o + 1] & 0xff) << 8);
            return ((b[o] & 0xff) << 8) | (b[o + 1] & 0xff);
        }
        long u32(long off) {
            int o = (int) off;
            long v = 0;
            if (le) {
                for (int i = 3; i >= 0; i--) v = (v << 8) | (b[o + i] & 0xffL);
            } else {
                for (int i = 0; i < 4; i++) v = (v << 8) | (b[o + i] & 0xffL);
            }
            return v;
        }
        long u64(long off) {
            int o = (int) off;
            long v = 0;
            if (le) {
                for (int i = 7; i >= 0; i--) v = (v << 8) | (b[o + i] & 0xffL);
            } else {
                for (int i = 0; i < 8; i++) v = (v << 8) | (b[o + i] & 0xffL);
            }
            return v;
        }
    }

    static final class Html {
        static String render(Elf e) {
            String fileName = e.path.getFileName() == null ? e.path.toString() : e.path.getFileName().toString();
            StringBuilder out = new StringBuilder(Math.max(8192, e.bytes.length * 5));
            out.append("<!doctype html>\n<html>\n  <head>\n");
            out.append("    <meta charset='utf-8'>\n    <meta name='viewport' content='width=900, initial-scale=1'>\n");
            out.append("    <title>").append(esc(fileName)).append("</title>\n");
            out.append("    <style>\n");
            out.append("html{font-family:monospace}body{margin:1em}#rightmenu{float:right;text-align:right}.textbutton{color:#222;background:none;border:0}.number{color:#049}.dump{white-space:pre}.offset{color:#777}.ascii{color:#555}.ehdr{background:#fdd}.phdr{background:#dfd}.shdr{background:#ddf}.section{background:#ffd}.segment{outline:1px solid #9c9}.itable{display:inline-table;vertical-align:top;margin:.5em 1em .5em 0;border-collapse:collapse}.itable td,.itable th{border:1px solid #ddd;padding:.15em .4em}.fileinfo td{padding:.1em .5em}.legend_rect{display:inline-block;width:3em;height:1em;border:1px solid #999}.ident{background:#fcc}.ehdrbox{background:#fdd}.phdrbox{background:#dfd}.shdrbox{background:#ddf}.segmentbox{background:#efe}.sectionbox{background:#ffd}\n");
            out.append("    </style>\n  </head>\n  <body>\n");
            out.append("    <div id='rightmenu'><a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a><br><button class='textbutton' id='settings_toggle'>Settings</button><br><button class='textbutton' id='help_toggle'>Help</button></div>\n");
            out.append("    <div id='help'><p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted.</p><ul>");
            out.append("<li><span class='legend_rect ident'></span>ELF Identification</li><li><span class='legend_rect ehdrbox'></span>ELF Header</li><li><span class='legend_rect phdrbox'></span>Program Header</li><li><span class='legend_rect shdrbox'></span>Section Header</li><li><span class='legend_rect segmentbox'></span>Segment</li><li><span class='legend_rect sectionbox'></span>Section</li></ul></div>\n");
            out.append("    <table class='fileinfo'>\n");
            row(out, "fileinfo_file_name", "File name:", esc(fileName));
            row(out, "fileinfo_file_size", "File size:", esc(size(e.bytes.length)));
            row(out, "fileinfo_class", "Object class:", e.is64 ? "64-bit" : "32-bit");
            row(out, "fileinfo_data", "Data encoding:", e.order == ByteOrder.LITTLE_ENDIAN ? "Little endian" : "Big endian");
            row(out, "fileinfo_abi", "ABI:", esc(abi(e.abi)));
            row(out, "fileinfo_e_type", "Type:", esc(etype(e.type)));
            row(out, "fileinfo_e_machine", "Architecture:", esc(machine(e.machine)));
            row(out, "fileinfo_e_entry", "Entrypoint:", num(e.entry));
            row(out, "fileinfo_ph", "Program headers:", "<span title='0x" + Long.toHexString(e.phnum) + "' class='number fileinfo_e_phnum'>" + e.phnum + "</span> * <span title='0x" + Integer.toHexString(e.phentsize) + "' class='number fileinfo_e_phentsize'>" + e.phentsize + "</span> @ <span title='0x" + Long.toHexString(e.phoff) + "' class='number fileinfo_e_phoff'>" + e.phoff + "</span>");
            row(out, "fileinfo_sh", "Section headers:", "<span title='0x" + Long.toHexString(e.shnum) + "' class='number fileinfo_e_shnum'>" + e.shnum + "</span> * <span title='0x" + Integer.toHexString(e.shentsize) + "' class='number fileinfo_e_shentsize'>" + e.shentsize + "</span> @ <span title='0x" + Long.toHexString(e.shoff) + "' class='number fileinfo_e_shoff'>" + e.shoff + "</span>");
            out.append("    </table>\n");

            out.append("    <h2>Hexdump</h2>\n    <div id='bytes' class='dump'>");
            dump(out, e.bytes);
            out.append("</div>\n");
            out.append("    <h2>Program headers</h2>\n");
            for (ProgramHeader p : e.programs) programTable(out, p);
            out.append("    <h2>Section headers</h2>\n");
            for (SectionHeader s : e.sections) sectionHeaderTable(out, s);
            out.append("    <h2>Sections</h2>\n");
            for (SectionHeader s : e.sections) sectionSummary(out, s, e.bytes);
            out.append("  </body>\n</html>\n");
            return out.toString();
        }

        private static void row(StringBuilder out, String cls, String k, String v) {
            out.append("      <tr class='").append(cls).append("'> <td>").append(k).append("</td> <td>").append(v).append("</td> </tr>\n");
        }

        private static void programTable(StringBuilder out, ProgramHeader p) {
            out.append("      <table class='conceal itable' id='info_phdr").append(p.index).append("'>\n");
            out.append("        <th colspan='2' class='phdr_itable'>Program header</th>\n");
            row(out, "", "Type:", esc(ptype(p.type)));
            row(out, "", "Flags:", esc(pflags(p.flags)));
            row(out, "", "Offset in file:", num(p.offset));
            row(out, "", "Size in file:", numSize(p.filesz));
            row(out, "", "Vaddr in memory:", num(p.vaddr));
            row(out, "", "Size in memory:", numSize(p.memsz));
            row(out, "", "Alignment:", num(p.align));
            out.append("      </table>\n");
            out.append("      <table class='conceal itable' id='info_segment").append(p.index).append("'>\n");
            out.append("        <th colspan='2' class='segment_itable'>Segment</th>\n");
            row(out, "", "Type:", esc(ptype(p.type)));
            row(out, "", "Size in file:", numSize(p.filesz));
            row(out, "", "Size in memory:", numSize(p.memsz));
            out.append("      </table>\n");
        }

        private static void sectionHeaderTable(StringBuilder out, SectionHeader s) {
            out.append("      <table class='conceal itable' id='info_shdr").append(s.index).append("'>\n");
            out.append("        <th colspan='2' class='shdr_itable'>Section header</th>\n");
            row(out, "", "Index:", Integer.toString(s.index));
            row(out, "", "Name:", esc(s.name));
            row(out, "", "Type:", esc(stype(s.type)));
            row(out, "", "Flags:", esc(sflags(s.flags)));
            row(out, "", "Vaddr in memory:", num(s.addr));
            row(out, "", "Offset in file:", num(s.offset));
            row(out, "", "Size in file:", numSize(s.size));
            row(out, "", "Linked section:", Long.toString(s.link));
            row(out, "", "Extra info:", num(s.info));
            row(out, "", "Alignment:", num(s.addralign));
            row(out, "", "Size of entries:", numSize(s.entsize));
            out.append("      </table>\n");
        }

        private static void sectionSummary(StringBuilder out, SectionHeader s, byte[] b) {
            out.append("      <table class='conceal itable' id='info_section").append(s.index).append("'>\n");
            out.append("        <th colspan='2' class='section_itable'>Section</th>\n");
            row(out, "", "Name:", esc(s.name));
            row(out, "", "Type:", esc(stype(s.type)));
            row(out, "", "Size:", numSize(s.size));
            if (s.type == 3 && s.offset >= 0 && s.offset < b.length && s.size > 0) {
                out.append("        <tr><td></td><td><div>");
                long end = Math.min(b.length, s.offset + Math.min(s.size, 4096));
                int start = (int) s.offset;
                int p = start;
                int shown = 0;
                while (p < end) {
                    String str = readZ(b, p, (int) end);
                    if (!str.isEmpty()) {
                        out.append(esc(str)).append("<br>");
                        shown++;
                    }
                    while (p < end && b[p] != 0) p++;
                    p++;
                    if (shown > 200) break;
                }
                out.append("</div></td></tr>\n");
            }
            out.append("      </table>\n");
        }

        private static String readZ(byte[] b, int p, int end) {
            StringBuilder sb = new StringBuilder();
            while (p < end && b[p] != 0) {
                int c = b[p++] & 0xff;
                if (c >= 32 && c < 127) sb.append((char) c);
            }
            return sb.toString();
        }

        private static void dump(StringBuilder out, byte[] b) {
            for (int i = 0; i < b.length; i += 16) {
                out.append("<span class='offset'>").append(Long.toHexString(i)).append("</span>  ");
                StringBuilder asc = new StringBuilder();
                for (int j = 0; j < 16; j++) {
                    int p = i + j;
                    if (p < b.length) {
                        int v = b[p] & 0xff;
                        out.append(hex2(v)).append(' ');
                        asc.append(v >= 32 && v < 127 ? (char) v : '.');
                    } else {
                        out.append("   ");
                        asc.append(' ');
                    }
                    if (j == 7) out.append(' ');
                }
                out.append(" <span class='ascii'>").append(esc(asc.toString())).append("</span>\n");
            }
        }

        private static String hex2(int v) {
            char[] h = "0123456789abcdef".toCharArray();
            return "" + h[(v >>> 4) & 15] + h[v & 15];
        }

        private static String num(long v) {
            return "<span class='number' title='" + Long.toUnsignedString(v) + "'>0x" + Long.toHexString(v) + "</span>";
        }
        private static String numSize(long v) {
            return "<span class='number' title='0x" + Long.toHexString(v) + "'>" + esc(size(v)) + "</span>";
        }
        private static String size(long n) {
            if (n >= 1024) return n + " (" + human(n) + ")";
            return Long.toString(n);
        }
        private static String human(long n) {
            String[] u = {"B", "KiB", "MiB", "GiB"};
            double d = n;
            int i = 0;
            while (d >= 1024 && i < u.length - 1) {
                d /= 1024.0;
                i++;
            }
            if (i == 0) return n + " B";
            return String.format(java.util.Locale.ROOT, "%.1f %s", d, u[i]);
        }
        private static String esc(String s) {
            return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
        }
        private static String abi(int v) {
            return switch (v) {
                case 0 -> "SysV";
                case 1 -> "HP-UX";
                case 2 -> "NetBSD";
                case 3 -> "Linux";
                case 6 -> "Solaris";
                case 7 -> "AIX";
                case 8 -> "IRIX";
                case 9 -> "FreeBSD";
                case 12 -> "OpenBSD";
                default -> "Unknown: " + v;
            };
        }
        private static String etype(int v) {
            return switch (v) {
                case 0 -> "No file type (NONE)";
                case 1 -> "Relocatable file (REL)";
                case 2 -> "Executable file (EXEC)";
                case 3 -> "Shared object file (DYN)";
                case 4 -> "Core file (CORE)";
                default -> "Unknown: " + v;
            };
        }
        private static String machine(int v) {
            return switch (v) {
                case 3 -> "x86";
                case 8 -> "MIPS";
                case 20 -> "PowerPC";
                case 40 -> "ARM";
                case 50 -> "IA-64";
                case 62 -> "x86-64";
                case 183 -> "AArch64";
                case 243 -> "RISC-V";
                default -> "Unknown: " + v;
            };
        }
        private static String ptype(long v) {
            if (v == 0) return "NULL";
            if (v == 1) return "LOAD";
            if (v == 2) return "DYNAMIC";
            if (v == 3) return "INTERP";
            if (v == 4) return "NOTE";
            if (v == 5) return "SHLIB";
            if (v == 6) return "PHDR";
            if (v == 7) return "TLS";
            if (v == 0x6474e550L) return "GNU_EH_FRAME (OS-specific)";
            if (v == 0x6474e551L) return "GNU_STACK (OS-specific)";
            if (v == 0x6474e552L) return "GNU_RELRO (OS-specific)";
            if (v >= 0x60000000L && v <= 0x6fffffffL) return "Unknown: " + v;
            return "Unknown: " + v;
        }
        private static String pflags(long f) {
            StringBuilder s = new StringBuilder();
            if ((f & 4) != 0) s.append('R');
            if ((f & 2) != 0) s.append('W');
            if ((f & 1) != 0) s.append('X');
            return s.length() == 0 ? "0" : s.toString();
        }
        private static String stype(long v) {
            if (v == 0) return "NULL";
            if (v == 1) return "PROGBITS";
            if (v == 2) return "SYMTAB";
            if (v == 3) return "STRTAB";
            if (v == 4) return "RELA";
            if (v == 5) return "HASH";
            if (v == 6) return "DYNAMIC";
            if (v == 7) return "NOTE";
            if (v == 8) return "NOBITS";
            if (v == 9) return "REL";
            if (v == 10) return "SHLIB";
            if (v == 11) return "DYNSYM";
            if (v == 14) return "INIT_ARRAY";
            if (v == 15) return "FINI_ARRAY";
            if (v == 0x6ffffff6L) return "GNU_HASH (OS-specific)";
            if (v == 0x6ffffffeL) return "VER_NEED (OS-specific)";
            if (v == 0x6fffffffL) return "VER_SYM (OS-specific)";
            if (v >= 0x60000000L && v <= 0x6fffffffL) return "HIOS";
            return "Unknown: " + v;
        }
        private static String sflags(long f) {
            StringBuilder s = new StringBuilder();
            if ((f & 1) != 0) s.append('W');
            if ((f & 2) != 0) s.append('A');
            if ((f & 4) != 0) s.append('X');
            if ((f & 0x10) != 0) s.append('M');
            if ((f & 0x20) != 0) s.append('S');
            if ((f & 0x40) != 0) s.append('I');
            if ((f & 0x80) != 0) s.append('L');
            if ((f & 0x100) != 0) s.append('O');
            if ((f & 0x200) != 0) s.append('G');
            if ((f & 0x400) != 0) s.append('T');
            return s.length() == 0 ? "0" : s.toString();
        }
    }
}
