import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Eureka {
    private static final String RESET = "\u001b[0m";
    private static final String GREEN_BOLD = "\u001b[0m\u001b[1m\u001b[32m";
    private static final String YELLOW = "\u001b[0m\u001b[33m";

    public static void main(String[] args) {
        try {
            int code = new Eureka().run(args);
            System.exit(code);
        } catch (Exception e) {
            System.err.println(" ERROR eureka > " + e.getMessage());
            System.exit(0);
        }
    }

    private int run(String[] args) throws Exception {
        if (args.length == 0) {
            capture();
            return 0;
        }
        if (args.length == 1) {
            switch (args[0]) {
                case "-h":
                case "--help":
                    printHelp();
                    return 0;
                case "-V":
                case "--version":
                    System.out.println("eureka 2.0.0");
                    return 0;
                case "-v":
                case "--view":
                    view();
                    return 0;
                case "--clear-config":
                    clearConfig();
                    return 0;
                default:
                    unexpected(args[0]);
                    return 2;
            }
        }
        unexpected(args[0]);
        return 2;
    }

    private void printHelp() {
        System.out.println("Input and store your ideas without leaving the terminal");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --clear-config  Clear your stored configuration");
        System.out.println("  -v, --view          View ideas with your $PAGER env variable. If unset use less");
        System.out.println("  -h, --help          Print help");
        System.out.println("  -V, --version       Print version");
    }

    private void unexpected(String arg) {
        System.err.println("error: unexpected argument '" + arg + "' found");
        System.err.println();
        System.err.println("Usage: executable [OPTIONS]");
        System.err.println();
        System.err.println("For more information, try '--help'.");
    }

    private void capture() throws Exception {
        Path config = configPath();
        if (!Files.exists(config)) {
            firstTimeSetup(config);
            return;
        }

        String repo = readRepo(config);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String summary;
        do {
            System.out.print(GREEN_BOLD + ">> Idea summary\n" + RESET + "> ");
            System.out.flush();
            summary = reader.readLine();
            if (summary == null) {
                summary = "";
            }
        } while (summary.trim().isEmpty());

        Path readme = Paths.get(repo).resolve("README.md");
        runEditor(readme);
        System.out.println("Adding and committing your new idea to main..");
        runGit(Paths.get(repo), "checkout", "-B", "main");
        runGit(Paths.get(repo), "add", "README.md");
        runGit(Paths.get(repo), "commit", "-m", summary);
        System.out.println("Added and committed!");
        System.out.println("Pushing your new idea..");
        pushMain(Paths.get(repo));
    }

    private void firstTimeSetup(Path config) throws IOException {
        System.out.print(YELLOW);
        System.out.println("############################################################");
        System.out.println("####                  First Time Setup                  ####");
        System.out.println("############################################################");
        System.out.println();
        System.out.println("This tool requires you to have a repository with a README.md");
        System.out.println("in the root folder. The markdown file is where your ideas");
        System.out.println("will be stored.");
        System.out.println();
        System.out.println("Once first time setup has completed, simply run Eureka again");
        System.out.println("to begin writing down ideas.");
        System.out.println("        ");
        System.out.print(RESET);

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String repo;
        do {
            System.out.print(GREEN_BOLD + "Absolute path to your idea repo\n" + RESET + "> ");
            System.out.flush();
            repo = reader.readLine();
            if (repo == null) {
                repo = "";
            }
        } while (repo.trim().isEmpty());

        Files.createDirectories(config.getParent());
        Files.writeString(config, "{\"repo\":\"" + escapeJson(repo.trim()) + "\"}", StandardCharsets.UTF_8);
        System.out.println("First time setup complete. Happy ideation!");
    }

    private void view() throws Exception {
        String repo = readRepo(configPath());
        String pager = getenvOrDefault("PAGER", "less");
        List<String> cmd = shellWords(pager);
        cmd.add(Paths.get(repo).resolve("README.md").toString());
        runCommand(null, cmd, true);
    }

    private void clearConfig() throws IOException {
        Files.delete(configPath());
    }

    private Path configPath() {
        String xdg = System.getenv("XDG_CONFIG_HOME");
        if (xdg != null && !xdg.isEmpty()) {
            return Paths.get(xdg).resolve("eureka").resolve("config.json");
        }
        String home = System.getenv("HOME");
        if (home == null || home.isEmpty()) {
            home = System.getProperty("user.home");
        }
        return Paths.get(home).resolve(".config").resolve("eureka").resolve("config.json");
    }

    private String readRepo(Path config) throws IOException {
        String text = Files.readString(config, StandardCharsets.UTF_8).trim();
        int key = text.indexOf("\"repo\"");
        if (key < 0) {
            throw new IOException("missing field `repo`");
        }
        int colon = text.indexOf(':', key);
        int start = text.indexOf('"', colon + 1);
        int end = start + 1;
        boolean esc = false;
        while (end < text.length()) {
            char c = text.charAt(end);
            if (c == '"' && !esc) {
                break;
            }
            esc = c == '\\' && !esc;
            if (c != '\\') {
                esc = false;
            }
            end++;
        }
        return unescapeJson(text.substring(start + 1, end));
    }

    private void runEditor(Path file) throws Exception {
        List<String> cmd = shellWords(getenvOrDefault("EDITOR", "vi"));
        cmd.add(file.toString());
        runCommand(null, cmd, false);
    }

    private void runGit(Path dir, String... args) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add("git");
        for (String arg : args) {
            cmd.add(arg);
        }
        runCommand(dir, cmd, false);
    }

    private void pushMain(Path dir) throws Exception {
        try {
            runGit(dir, "remote", "get-url", "origin");
        } catch (Exception e) {
            throw new IOException("remote 'origin' does not exist; class=Config (7); code=NotFound (-3)");
        }
        runGit(dir, "push", "origin", "main");
    }

    private void runCommand(Path dir, List<String> cmd, boolean inheritOut) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        if (dir != null) {
            pb.directory(dir.toFile());
        }
        defaultEnv(pb.environment(), "GIT_AUTHOR_NAME", "eureka");
        defaultEnv(pb.environment(), "GIT_AUTHOR_EMAIL", "eureka@example.local");
        defaultEnv(pb.environment(), "GIT_COMMITTER_NAME", "eureka");
        defaultEnv(pb.environment(), "GIT_COMMITTER_EMAIL", "eureka@example.local");
        if (inheritOut) {
            pb.inheritIO();
        } else {
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
            pb.redirectError(ProcessBuilder.Redirect.PIPE);
        }
        Process p = pb.start();
        String err = "";
        if (!inheritOut) {
            err = new String(p.getErrorStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        }
        int code = p.waitFor();
        if (code != 0) {
            if (err.isEmpty()) {
                err = cmd.get(0) + " exited with status " + code;
            }
            throw new IOException(err);
        }
    }

    private String getenvOrDefault(String key, String fallback) {
        Map<String, String> env = System.getenv();
        String value = env.get(key);
        return value == null || value.isEmpty() ? fallback : value;
    }

    private void defaultEnv(Map<String, String> env, String key, String value) {
        String current = env.get(key);
        if (current == null || current.isEmpty()) {
            env.put(key, value);
        }
    }

    private List<String> shellWords(String value) {
        List<String> words = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        char quote = 0;
        boolean esc = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (esc) {
                current.append(c);
                esc = false;
            } else if (c == '\\') {
                esc = true;
            } else if (quote != 0) {
                if (c == quote) {
                    quote = 0;
                } else {
                    current.append(c);
                }
            } else if (c == '\'' || c == '"') {
                quote = c;
            } else if (Character.isWhitespace(c)) {
                if (current.length() > 0) {
                    words.add(current.toString());
                    current.setLength(0);
                }
            } else {
                current.append(c);
            }
        }
        if (current.length() > 0) {
            words.add(current.toString());
        }
        if (words.isEmpty()) {
            words.add(value);
        }
        return words;
    }

    private String escapeJson(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String unescapeJson(String s) {
        StringBuilder out = new StringBuilder();
        boolean esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc) {
                out.append(c);
                esc = false;
            } else if (c == '\\') {
                esc = true;
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }
}
