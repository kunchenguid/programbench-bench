package tparse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class Main {
    static final String HELP = """
Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.""";

    public static void main(String[] args) {
        Options opt;
        try {
            opt = Options.parse(args);
        } catch (FlagException e) {
            System.err.println(e.getMessage());
            System.err.println(HELP);
            System.exit(2);
            return;
        }
        if (opt.help) {
            System.out.println(HELP);
            return;
        }
        if (opt.version) {
            System.out.println("tparse version: (devel)");
            return;
        }
        try {
            List<String> lines = readLines(opt);
            ParseResult result = parse(lines, opt);
            if (result.eventCount == 0) {
                System.err.println("no parsable events: Make sure to run go test with -json flag");
                System.exit(1);
                return;
            }
            Renderer.render(result, opt);
            System.exit(result.hasFailure() ? 1 : 0);
        } catch (IOException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    static List<String> readLines(Options opt) throws IOException {
        if (opt.file != null) {
            if (!Files.exists(Path.of(opt.file))) {
                throw new IOException("open " + opt.file + ": no such file or directory");
            }
            return Files.readAllLines(Path.of(opt.file), StandardCharsets.UTF_8);
        }
        List<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) out.add(line);
        }
        return out;
    }

    static ParseResult parse(List<String> lines, Options opt) throws IOException {
        ParseResult r = new ParseResult();
        if (opt.followOutput != null) Files.write(Path.of(opt.followOutput), lines, StandardCharsets.UTF_8);
        for (String line : lines) {
            if (line.trim().isEmpty()) continue;
            Map<String, String> ev = Json.flatObject(line);
            if (ev == null || !ev.containsKey("Action")) continue;
            r.eventCount++;
            String action = ev.getOrDefault("Action", "");
            String pkgName = opt.trimPath == null ? ev.getOrDefault("Package", "") : trim(ev.getOrDefault("Package", ""), opt.trimPath);
            String testName = ev.getOrDefault("Test", "");
            String output = ev.getOrDefault("Output", "");
            double elapsed = parseDouble(ev.get("Elapsed"));
            PackageInfo pkg = r.packages.computeIfAbsent(pkgName, PackageInfo::new);
            if ("output".equals(action)) {
                if (opt.follow || opt.followOutput != null) {
                    String prefix = opt.includeTimestamp && ev.containsKey("Time") ? ev.get("Time") + " " : "";
                    System.out.print(prefix + output);
                }
                if (output.contains("coverage:")) {
                    String s = output.substring(output.indexOf("coverage:") + 9).trim();
                    int pct = s.indexOf('%');
                    if (pct >= 0) pkg.cover = s.substring(0, pct + 1).trim();
                }
                if (output.contains("[no test files]") || output.contains("[no tests to run]")) {
                    pkg.noTests = true;
                    pkg.noTestText = output.contains("[no tests to run]") ? "[no tests to run]" : "[no test files]";
                }
                if (!testName.isEmpty() && isFailureRelated(output)) {
                    pkg.failureOutput.computeIfAbsent(testName, k -> new StringBuilder()).append(output);
                }
                continue;
            }
            if ("pass".equals(action) || "fail".equals(action) || "skip".equals(action)) {
                if (testName.isEmpty()) {
                    pkg.status = action.toUpperCase(Locale.ROOT);
                    pkg.elapsed = elapsed;
                    if (opt.progress && !pkg.noTests) {
                        System.out.printf("[%s]\t%9s\t%s%n", pkg.status, fmtPkgElapsed(elapsed), pkg.name);
                    }
                } else {
                    TestInfo t = new TestInfo(action.toUpperCase(Locale.ROOT), elapsed, testName, pkg.name);
                    pkg.tests.put(testName, t);
                    if ("pass".equals(action)) pkg.pass++;
                    if ("fail".equals(action)) pkg.fail++;
                    if ("skip".equals(action)) pkg.skip++;
                }
            }
        }
        for (PackageInfo p : r.packages.values()) {
            if (p.status.isEmpty() && p.fail > 0) p.status = "FAIL";
            if (p.status.isEmpty() && p.pass > 0) p.status = "PASS";
            if (p.status.isEmpty() && p.skip > 0) p.status = "";
        }
        return r;
    }

    static boolean isFailureRelated(String s) {
        String t = s.trim();
        return !(t.startsWith("===") || t.startsWith("--- PASS:") || t.startsWith("--- SKIP:") || t.startsWith("PASS") || t.startsWith("ok "));
    }

    static String trim(String pkg, String prefix) {
        if (prefix == null || prefix.isEmpty()) return pkg;
        if (pkg.startsWith(prefix)) {
            String s = pkg.substring(prefix.length());
            while (s.startsWith("/") || s.startsWith("\\")) s = s.substring(1);
            return s;
        }
        return pkg;
    }

    static double parseDouble(String s) {
        if (s == null || s.isEmpty()) return 0.0;
        try { return Double.parseDouble(s); } catch (NumberFormatException e) { return 0.0; }
    }

    static String fmtTestElapsed(double d) { return String.format(Locale.ROOT, "%.2f", d); }
    static String fmtPkgElapsed(double d) { return String.format(Locale.ROOT, "%.2fs", d); }
}

class Options {
    boolean help, version, all, pass, skip, noTests, smallscreen, nocolor, follow, includeTimestamp, progress;
    int slow = 0;
    String sort = "name", format = "basic", file, followOutput, compare, trimPath;

    static Options parse(String[] args) throws FlagException {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            String val = null;
            int eq = a.indexOf('=');
            if (eq > 0) { val = a.substring(eq + 1); a = a.substring(0, eq); }
            switch (a) {
                case "-h", "--help" -> o.help = true;
                case "-v", "--version" -> o.version = true;
                case "-all" -> o.all = true;
                case "-pass" -> o.pass = true;
                case "-skip" -> o.skip = true;
                case "-notests" -> o.noTests = true;
                case "-smallscreen" -> o.smallscreen = true;
                case "-nocolor" -> o.nocolor = true;
                case "-follow" -> o.follow = true;
                case "-include-timestamp" -> o.includeTimestamp = true;
                case "-progress" -> o.progress = true;
                case "-slow" -> o.slow = Integer.parseInt(value(args, ++i, val, a));
                case "-sort" -> o.sort = value(args, ++i, val, a);
                case "-format" -> o.format = value(args, ++i, val, a);
                case "-file" -> o.file = value(args, ++i, val, a);
                case "-follow-output" -> o.followOutput = value(args, ++i, val, a);
                case "-compare" -> o.compare = value(args, ++i, val, a);
                case "-trimpath" -> o.trimPath = value(args, ++i, val, a);
                default -> throw new FlagException("flag provided but not defined: " + a);
            }
            if (val != null) i--;
        }
        return o;
    }

    static String value(String[] args, int idx, String val, String flag) throws FlagException {
        if (val != null) return val;
        if (idx >= args.length) throw new FlagException("flag needs an argument: " + flag);
        return args[idx];
    }
}

class FlagException extends Exception {
    FlagException(String m) { super(m); }
}

class ParseResult {
    int eventCount;
    LinkedHashMap<String, PackageInfo> packages = new LinkedHashMap<>();
    boolean hasFailure() { return packages.values().stream().anyMatch(p -> "FAIL".equals(p.status) || p.fail > 0); }
}

class PackageInfo {
    final String name;
    String status = "";
    double elapsed = 0.0;
    int pass, fail, skip;
    String cover = "--";
    boolean noTests;
    String noTestText = "[no test files]";
    LinkedHashMap<String, TestInfo> tests = new LinkedHashMap<>();
    Map<String, StringBuilder> failureOutput = new LinkedHashMap<>();
    PackageInfo(String name) { this.name = name; }
}

class TestInfo {
    final String status, name, pkg;
    final double elapsed;
    TestInfo(String status, double elapsed, String name, String pkg) {
        this.status = status; this.elapsed = elapsed; this.name = name; this.pkg = pkg;
    }
}
