package tparse;

import java.util.LinkedHashMap;
import java.util.Map;

final class Json {
    private Json() {}

    static Map<String, String> flatObject(String s) {
        Parser p = new Parser(s);
        return p.parse();
    }

    static class Parser {
        final String s;
        int i;
        Parser(String s) { this.s = s; }

        Map<String, String> parse() {
            skip();
            if (!eat('{')) return null;
            Map<String, String> m = new LinkedHashMap<>();
            skip();
            while (i < s.length() && s.charAt(i) != '}') {
                String k = string();
                if (k == null) return null;
                skip();
                if (!eat(':')) return null;
                skip();
                String v = value();
                m.put(k, v == null ? "" : v);
                skip();
                if (!eat(',')) break;
                skip();
            }
            return m;
        }

        String value() {
            skip();
            if (i >= s.length()) return "";
            char c = s.charAt(i);
            if (c == '"') return string();
            int start = i;
            while (i < s.length() && ",}".indexOf(s.charAt(i)) < 0) i++;
            return s.substring(start, i).trim();
        }

        String string() {
            if (!eat('"')) return null;
            StringBuilder b = new StringBuilder();
            while (i < s.length()) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\' && i < s.length()) {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n' -> b.append('\n');
                        case 'r' -> b.append('\r');
                        case 't' -> b.append('\t');
                        case 'b' -> b.append('\b');
                        case 'f' -> b.append('\f');
                        case '"', '\\', '/' -> b.append(e);
                        case 'u' -> {
                            if (i + 4 <= s.length()) {
                                try {
                                    b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                                    i += 4;
                                } catch (NumberFormatException ex) {
                                    b.append("\\u");
                                }
                            }
                        }
                        default -> b.append(e);
                    }
                } else {
                    b.append(c);
                }
            }
            return b.toString();
        }

        boolean eat(char c) {
            if (i < s.length() && s.charAt(i) == c) {
                i++;
                return true;
            }
            return false;
        }

        void skip() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }
    }
}
