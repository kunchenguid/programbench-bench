package tparse;

import java.util.List;

final class Table {
    private Table() {}

    static void print(List<String[]> rows, boolean plain) {
        int cols = rows.get(0).length;
        int[] w = widths(rows, cols);
        if (plain) {
            for (int r = 0; r < rows.size(); r++) {
                if (r == 1) blank(w);
                row(rows.get(r), w, " ", " ", " ", false);
            }
            return;
        }
        border(w, '╭', '┬', '╮', '─');
        row(rows.get(0), w, "│", "│", "│", true);
        border(w, '├', '┼', '┤', '─');
        for (int i = 1; i < rows.size(); i++) row(rows.get(i), w, "│", "│", "│", true);
        border(w, '╰', '┴', '╯', '─');
    }

    static void markdown(List<String[]> rows) {
        int cols = rows.get(0).length;
        int[] w = widths(rows, cols);
        mdrow(rows.get(0), w);
        mdsep(w);
        for (int i = 1; i < rows.size(); i++) mdrow(rows.get(i), w);
    }

    static int[] widths(List<String[]> rows, int cols) {
        int[] w = new int[cols];
        for (String[] row : rows) {
            for (int c = 0; c < cols; c++) {
                String s = c < row.length && row[c] != null ? row[c] : "";
                for (String part : s.split("\\n", -1)) w[c] = Math.max(w[c], part.length());
            }
        }
        return w;
    }

    static void border(int[] w, char l, char mid, char r, char fill) {
        StringBuilder b = new StringBuilder().append(l);
        for (int i = 0; i < w.length; i++) {
            b.append(String.valueOf(fill).repeat(w[i] + 2));
            b.append(i == w.length - 1 ? r : mid);
        }
        System.out.println(b);
    }

    static void row(String[] cells, int[] w, String l, String sep, String r, boolean bars) {
        int height = 1;
        for (String c : cells) if (c != null) height = Math.max(height, c.split("\\n", -1).length);
        for (int line = 0; line < height; line++) {
            StringBuilder b = new StringBuilder();
            b.append(l);
            for (int i = 0; i < w.length; i++) {
                String cell = i < cells.length && cells[i] != null ? cells[i] : "";
                String[] parts = cell.split("\\n", -1);
                String part = line < parts.length ? parts[line] : "";
                b.append(' ').append(center(part, w[i])).append(' ');
                b.append(i == w.length - 1 ? r : sep);
            }
            System.out.println(b);
        }
    }

    static void blank(int[] w) {
        StringBuilder b = new StringBuilder(" ");
        for (int i = 0; i < w.length; i++) {
            b.append(" ".repeat(w[i] + 2));
            if (i < w.length - 1) b.append(' ');
        }
        System.out.println(b);
    }

    static void mdrow(String[] cells, int[] w) {
        StringBuilder b = new StringBuilder("|");
        for (int i = 0; i < w.length; i++) {
            String s = i < cells.length && cells[i] != null ? cells[i] : "";
            b.append(' ').append(center(s, w[i])).append(' ').append('|');
        }
        System.out.println(b);
    }

    static void mdsep(int[] w) {
        StringBuilder b = new StringBuilder("|");
        for (int width : w) {
            b.append("-".repeat(Math.max(3, width + 2))).append("|");
        }
        System.out.println(b);
    }

    static String center(String s, int w) {
        int pad = Math.max(0, w - s.length());
        int left = pad / 2;
        int right = pad - left;
        return " ".repeat(left) + s + " ".repeat(right);
    }
}
