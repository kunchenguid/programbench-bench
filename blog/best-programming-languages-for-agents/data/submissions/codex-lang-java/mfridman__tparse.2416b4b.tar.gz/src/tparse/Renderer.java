package tparse;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

final class Renderer {
    private Renderer() {}

    static void render(ParseResult r, Options opt) {
        List<PackageInfo> pkgs = new ArrayList<>(r.packages.values());
        if (opt.all || opt.pass || opt.skip) {
            List<TestInfo> tests = collectTests(pkgs, opt);
            if (!tests.isEmpty()) renderTestTable(tests, opt);
        }
        for (PackageInfo p : pkgs) {
            if (p.fail > 0 || "FAIL".equals(p.status)) renderFailure(p, opt);
        }
        List<PackageInfo> summaries = pkgs.stream()
                .filter(p -> !p.noTests || opt.noTests || p.pass + p.fail + p.skip > 0)
                .toList();
        if (!summaries.isEmpty()) renderPackageTable(summaries, opt);
    }

    static List<TestInfo> collectTests(List<PackageInfo> pkgs, Options opt) {
        List<TestInfo> out = new ArrayList<>();
        for (PackageInfo p : pkgs) {
            for (TestInfo t : p.tests.values()) {
                if ("FAIL".equals(t.status) || (opt.all && ("PASS".equals(t.status) || "SKIP".equals(t.status)))
                        || (opt.pass && "PASS".equals(t.status)) || (opt.skip && "SKIP".equals(t.status))) {
                    out.add(t);
                }
            }
        }
        if ("elapsed".equals(opt.sort)) out.sort(Comparator.comparingDouble((TestInfo t) -> t.elapsed).reversed());
        else out.sort(Comparator.comparingInt(Renderer::statusRank).thenComparing(t -> t.name).thenComparing(t -> t.pkg));
        if (opt.slow > 0 && out.size() > opt.slow) return new ArrayList<>(out.subList(0, opt.slow));
        return out;
    }

    static void renderFailure(PackageInfo p, Options opt) {
        if ("markdown".equals(opt.format)) {
            System.out.println("## FAIL • " + p.name);
            System.out.println();
            System.out.println("```");
            System.out.println();
            System.out.println();
            printFailureText(p);
            System.out.println("```");
            System.out.println();
            return;
        }
        String title = "   FAIL  package: " + p.name + "   ";
        int w = title.length();
        System.out.println("┏" + "━".repeat(w) + "┓");
        System.out.println("┃" + title + "┃");
        System.out.println("┗" + "━".repeat(w) + "┛");
        System.out.println();
        System.out.println();
        System.out.println();
        printFailureText(p);
    }

    static void printFailureText(PackageInfo p) {
        boolean any = false;
        for (StringBuilder b : p.failureOutput.values()) {
            String s = b.toString();
            if (!s.isEmpty()) {
                System.out.print(s);
                if (!s.endsWith("\n")) System.out.println();
                any = true;
            }
        }
        if (!any) System.out.println();
        System.out.println();
    }

    static void renderTestTable(List<TestInfo> tests, Options opt) {
        if ("markdown".equals(opt.format)) {
            String cur = null;
            List<TestInfo> bucket = new ArrayList<>();
            for (TestInfo t : tests) {
                if (cur == null) cur = t.pkg;
                if (!cur.equals(t.pkg)) {
                    renderMarkdownPackageTests(cur, bucket);
                    bucket.clear();
                    cur = t.pkg;
                }
                bucket.add(t);
            }
            if (cur != null) renderMarkdownPackageTests(cur, bucket);
            return;
        }
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"Status", "Elapsed", "Test", "Package"});
        for (TestInfo t : tests) rows.add(new String[]{padStatus(t.status), Main.fmtTestElapsed(t.elapsed), small(t.name, opt), t.pkg});
        Table.print(rows, "plain".equals(opt.format));
    }

    static void renderMarkdownPackageTests(String pkg, List<TestInfo> tests) {
        int pass = 0, skip = 0, fail = 0;
        for (TestInfo t : tests) {
            if ("PASS".equals(t.status)) pass++;
            if ("SKIP".equals(t.status)) skip++;
            if ("FAIL".equals(t.status)) fail++;
        }
        System.out.println("## 📦 Package **`" + pkg + "`**");
        System.out.println();
        System.out.printf("Tests: ✓ %d passed | %d skipped | %d failed%n%n", pass, skip, fail);
        System.out.println("<details>");
        System.out.println();
        System.out.println("<summary>Click for test summary</summary>");
        System.out.println();
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"Status", "Elapsed", "Test"});
        for (TestInfo t : tests) rows.add(new String[]{padStatus(t.status), Main.fmtTestElapsed(t.elapsed), t.name});
        Table.markdown(rows);
        System.out.println("</details>");
        System.out.println();
        System.out.println();
    }

    static void renderPackageTable(List<PackageInfo> pkgs, Options opt) {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"});
        for (PackageInfo p : pkgs) {
            if (p.noTests && opt.noTests && p.pass + p.fail + p.skip == 0) {
                rows.add(new String[]{"NOTEST", Main.fmtPkgElapsed(p.elapsed), p.name, "--", "--", "--", "--"});
                rows.add(new String[]{"", "", p.noTestText, "", "", "", ""});
            } else {
                rows.add(new String[]{padStatus(p.status), Main.fmtPkgElapsed(p.elapsed), p.name, p.cover,
                        String.valueOf(p.pass), String.valueOf(p.fail), String.valueOf(p.skip)});
            }
        }
        if ("markdown".equals(opt.format)) Table.markdown(rows);
        else Table.print(rows, "plain".equals(opt.format));
    }

    static String padStatus(String s) {
        if (s == null) return "";
        return switch (s) {
            case "PASS" -> " PASS ";
            case "FAIL" -> " FAIL ";
            case "SKIP" -> " SKIP ";
            default -> s;
        };
    }

    static int statusRank(TestInfo t) {
        return switch (t.status) {
            case "PASS" -> 0;
            case "SKIP" -> 1;
            case "FAIL" -> 2;
            default -> 3;
        };
    }

    static String small(String s, Options opt) {
        return opt.smallscreen ? s.replace("/", "\n") : s;
    }
}
