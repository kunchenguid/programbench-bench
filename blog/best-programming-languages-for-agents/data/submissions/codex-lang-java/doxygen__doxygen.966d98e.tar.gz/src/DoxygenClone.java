import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.*;

public class DoxygenClone {
    static final String VERSION = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)";
    static String prog = "doxygen";

    public static void main(String[] args) throws Exception {
        String ep = System.getenv("DOXYGEN_PROG");
        prog = ep != null && !ep.isEmpty() ? ep : new File(System.getProperty("sun.java.command", "executable").split(" ")[0]).getName();
        if (prog.endsWith(".jar")) prog = "./executable";
        int code = new DoxygenClone().run(args);
        if (code != 0) System.exit(code);
    }

    int run(String[] args) throws Exception {
        List<String> a = new ArrayList<>(Arrays.asList(args));
        boolean strip = a.remove("-s");
        boolean quietArg = a.remove("-q");
        if (a.isEmpty()) {
            Path d = Paths.get("Doxyfile");
            if (!Files.exists(d)) { System.out.println("error: Doxyfile not found and no input file specified!"); usage(); return 1; }
            return generate("Doxyfile", quietArg);
        }
        String first = a.get(0);
        switch (first) {
            case "-h": case "-?": case "--help": usage(); return 0;
            case "-v": case "--version": System.out.println(VERSION); return 0;
            case "-V": System.out.println(VERSION); System.out.println("    with sqlite3 3.42.0."); return 0;
            case "-d": debugHelp(); return 0;
            case "-g": return writeTemplate(a.size() > 1 ? a.get(1) : "Doxyfile", strip);
            case "-u": return updateConfig(a.size() > 1 ? a.get(1) : "Doxyfile", strip);
            case "-l": return writeResource(a.size() > 1 ? a.get(1) : "DoxygenLayout.xml", "layout.xml");
            case "-w": return writeStyle(a);
            case "-e": return writeExt(a);
            case "-f": return writeList(a);
            case "-x": return diffConfig(a.size() > 1 ? a.get(1) : "Doxyfile");
            case "-x_noenv": return diffConfig(a.size() > 1 ? a.get(1) : "Doxyfile");
            default:
                if (first.startsWith("-")) { System.out.println("error: Unknown option \"" + first + "\""); usage(); return 1; }
                return generate(first, quietArg);
        }
    }

    static void usage() {
        System.out.println("Doxygen version " + VERSION);
        System.out.println("Copyright Dimitri van Heesch 1997-2025\n");
        System.out.println("You can use Doxygen in a number of ways:\n");
        System.out.println("1) Use Doxygen to generate a template configuration file*:");
        System.out.println("    " + prog + " [-s] -g [configName]\n");
        System.out.println("2) Use Doxygen to update an old configuration file*:");
        System.out.println("    " + prog + " [-s] -u [configName]\n");
        System.out.println("3) Use Doxygen to generate documentation using an existing configuration file*:");
        System.out.println("    " + prog + " [configName]\n");
        System.out.println("4) Use Doxygen to generate a template file controlling the layout of the");
        System.out.println("   generated documentation:");
        System.out.println("    " + prog + " -l [layoutFileName]\n");
        System.out.println("    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.");
        System.out.println("    If - is used for layoutFileName Doxygen will write to standard output.\n");
        System.out.println("5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.");
        System.out.println("    RTF:        " + prog + " -w rtf styleSheetFile");
        System.out.println("    HTML:       " + prog + " -w html headerFile footerFile styleSheetFile [configFile]");
        System.out.println("    LaTeX:      " + prog + " -w latex headerFile footerFile styleSheetFile [configFile]\n");
        System.out.println("6) Use Doxygen to generate a rtf extensions file");
        System.out.println("    " + prog + " -e rtf extensionsFile\n");
        System.out.println("    If - is used for extensionsFile Doxygen will write to standard output.\n");
        System.out.println("7) Use Doxygen to compare the used configuration file with the template configuration file");
        System.out.println("    " + prog + " -x [configFile]\n");
        System.out.println("   Use Doxygen to compare the used configuration file with the template configuration file");
        System.out.println("   without replacing the environment variables or CMake type replacement variables");
        System.out.println("    " + prog + " -x_noenv [configFile]\n");
        System.out.println("8) Use Doxygen to show a list of built-in emojis.");
        System.out.println("    " + prog + " -f emoji outputFileName\n");
        System.out.println("    If - is used for outputFileName Doxygen will write to standard output.\n");
        System.out.println("*) If -s is specified the comments of the configuration items in the config file will be omitted.");
        System.out.println("   If configName is omitted 'Doxyfile' will be used as a default.");
        System.out.println("   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.\n");
        System.out.println("If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.\n");
        System.out.println("-v print version string, -V print extended version information");
        System.out.println("-h,-? prints usage help information");
        System.out.println(prog + " -d prints additional usage flags for debugging purposes");
    }

    static void debugHelp() {
        System.out.println("Developer parameters:");
        System.out.println("  -m          dump symbol map");
        System.out.println("  -b          making messages output unbuffered");
        System.out.println("  -c <file>   process input file as a comment block and produce HTML output");
        System.out.println("  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):");
        for (String s: Arrays.asList("alias","cite","commentcnv","commentscan","entries","extcmd","filteroutput","formula","fortranfixed2free","layout","lex","lex:code","lex:commentcnv","lex:commentscan","lex:configimpl","lex:constexp","lex:declinfo","lex:defargs","lex:doctokenizer","lex:fortrancode","lex:fortranscanner","lex:lexcode","lex:lexscanner","lex:pre","lex:pycode","lex:pyscanner","lex:scanner","lex:sqlcode","lex:vhdlcode","lex:xml","lex:xmlcode","markdown","nolineno","plantuml","preprocessor","printtree","qhp","rtf","sections","stderr","tag","time")) System.out.println("\t"+s);
    }

    int writeTemplate(String name, boolean strip) throws IOException {
        String text = res(strip ? "Doxyfile.short" : "Doxyfile.full");
        if ("-".equals(name)) System.out.print(text); else {
            Files.writeString(Paths.get(name), text, StandardCharsets.UTF_8);
            System.out.println("\n\nConfiguration file '" + name + "' created.\n");
            System.out.println("Now edit the configuration file and enter\n");
            System.out.println("  doxygen" + ("Doxyfile".equals(name) ? "" : " " + name) + "\n");
            System.out.println("to generate the documentation for your project\n");
        }
        return 0;
    }

    int updateConfig(String name, boolean strip) throws IOException {
        Config old = Files.exists(Paths.get(name)) ? parseConfig(Paths.get(name)) : new Config();
        String base = res(strip ? "Doxyfile.short" : "Doxyfile.full");
        for (Map.Entry<String,String> e : old.values.entrySet()) base = replaceTag(base, e.getKey(), e.getValue());
        Files.writeString(Paths.get(name), base, StandardCharsets.UTF_8);
        System.out.println("\n\nConfiguration file '" + name + "' updated.\n");
        return 0;
    }

    int diffConfig(String name) throws IOException {
        Config c = parseConfig(Paths.get(name));
        Config def = parseConfigString(res("Doxyfile.short"));
        System.out.println("# Difference with default Doxyfile " + VERSION);
        for (Map.Entry<String,String> e : c.values.entrySet()) {
            String d = def.values.get(e.getKey());
            if (d == null) System.out.println("warning: ignoring unsupported tag '"+e.getKey()+"'");
            else if (!norm(d).equals(norm(e.getValue()))) System.out.printf("%-23s= %s%n", e.getKey(), e.getValue());
        }
        return 0;
    }

    int writeResource(String name, String resource) throws IOException { String t=res(resource); if ("-".equals(name)) System.out.print(t); else Files.writeString(Paths.get(name), t); return 0; }
    int writeStyle(List<String> a) throws IOException {
        if (a.size()<2) { System.out.println("error: option \"-w\" does not have enough arguments"); return 1; }
        String kind=a.get(1).toLowerCase(Locale.ROOT);
        if (kind.equals("html")) { if (a.size()<5) { System.out.println("error: option \"-w html\" does not have enough arguments"); return 1; } writeResource(a.get(2),"header.html"); writeResource(a.get(3),"footer.html"); writeResource(a.get(4),"doxygen.css"); return 0; }
        if (kind.equals("latex")) { if (a.size()<5) { System.out.println("error: option \"-w latex\" does not have enough arguments"); return 1; } writeResource(a.get(2),"latex_header.tex"); writeResource(a.get(3),"latex_footer.tex"); writeResource(a.get(4),"latex_style.sty"); return 0; }
        if (kind.equals("rtf")) { if (a.size()<3) { System.out.println("error: option \"-w rtf\" does not have enough arguments"); return 1; } return writeResource(a.get(2),"rtf.style"); }
        System.out.println("error: option \"-w\" has invalid format specifier."); return 1;
    }
    int writeExt(List<String> a) throws IOException { if (a.size()<3) { System.out.println("error: option \"-e\" does not have enough arguments"); return 1; } if (!"rtf".equalsIgnoreCase(a.get(1))) { System.out.println("error: option \"-e\" has invalid format specifier."); return 1; } return writeResource(a.get(2),"rtf_extensions.txt"); }
    int writeList(List<String> a) throws IOException { if (a.size()<3) { System.out.println("error: option \"-f\" does not have enough arguments"); return 1; } if (!"emoji".equalsIgnoreCase(a.get(1))) { System.out.println("error: option \"-f\" has invalid list specifier."); return 1; } return writeResource(a.get(2),"emoji.txt"); }

    int generate(String configName, boolean quietArg) throws Exception {
        Path cfgPath = "-".equals(configName) ? null : Paths.get(configName);
        if (cfgPath != null && !Files.exists(cfgPath)) { System.out.println("error: configuration file " + configName + " not found!"); return 1; }
        Config c = cfgPath == null ? parseConfigString(new String(System.in.readAllBytes(), StandardCharsets.UTF_8)) : parseConfig(cfgPath);
        if (quietArg) c.values.put("QUIET", "YES");
        boolean quiet = yes(c.get("QUIET", "NO"));
        if (!quiet) System.out.println("Doxygen version used: " + VERSION);
        Path out = Paths.get(unquote(c.get("OUTPUT_DIRECTORY", "")));
        if (out.toString().isEmpty()) out = Paths.get(".");
        List<Path> inputs = collectInputs(c);
        List<Item> items = scan(itemsFiles(inputs));
        String project = unquote(c.get("PROJECT_NAME", "My Project"));
        if (project.isEmpty()) project = "My Project";
        if (yes(c.get("GENERATE_HTML", "YES"))) writeHtml(out.resolve(c.get("HTML_OUTPUT", "html").trim().isEmpty()?"html":unquote(c.get("HTML_OUTPUT","html"))), project, inputs, items, c);
        if (yes(c.get("GENERATE_LATEX", "YES"))) writeLatex(out.resolve(unquote(c.get("LATEX_OUTPUT", "latex"))), project, inputs, items);
        if (yes(c.get("GENERATE_MAN", "NO"))) writeMan(out.resolve(unquote(c.get("MAN_OUTPUT", "man"))), project, items);
        if (!quiet) System.out.println("finished...");
        return 0;
    }

    List<Path> collectInputs(Config c) throws IOException {
        String input = c.get("INPUT", "").trim();
        List<Path> roots = splitWords(input).stream().map(Paths::get).collect(Collectors.toList());
        if (roots.isEmpty()) roots.add(Paths.get("."));
        boolean recursive = yes(c.get("RECURSIVE", "NO"));
        List<Path> files = new ArrayList<>();
        for (Path r: roots) {
            if (!Files.exists(r)) continue;
            if (Files.isRegularFile(r)) files.add(r);
            else if (Files.isDirectory(r)) {
                Stream<Path> st = recursive ? Files.walk(r) : Files.list(r);
                try (st) { st.filter(Files::isRegularFile).filter(this::isSource).forEach(files::add); }
            }
        }
        return files.stream().distinct().sorted().collect(Collectors.toList());
    }
    List<Path> itemsFiles(List<Path> x) { return x; }
    boolean isSource(Path p) { String n=p.getFileName().toString().toLowerCase(Locale.ROOT); return n.matches(".*\\.(c|cc|cpp|cxx|h|hh|hpp|java|py|md|markdown|d|cs|php|idl|f90|f|vhdl?)$"); }

    List<Item> scan(List<Path> files) throws IOException {
        List<Item> out = new ArrayList<>();
        Pattern cls = Pattern.compile("\\b(class|struct|interface|enum)\\s+([A-Za-z_][A-Za-z0-9_]*)");
        Pattern fun = Pattern.compile("(?:^|[;{}\\s])([A-Za-z_][A-Za-z0-9_:<>\\*\\&\\s]+?)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*\\(([^;{}]*)\\)\\s*(?:const\\s*)?(?:[;{])");
        for (Path f: files) {
            String text = Files.readString(f, StandardCharsets.UTF_8);
            Matcher m = Pattern.compile("(?s)(/\\*\\*.*?\\*/|///.*?(?:\\R|$)|##.*?(?:\\R|$))?([^/\n#]*?(?:class|struct|interface|enum)\\s+[A-Za-z_][A-Za-z0-9_]*[^;{]*[;{])").matcher(text);
            while(m.find()) { Matcher cm=cls.matcher(m.group(2)); if(cm.find()) out.add(new Item(cm.group(1), cm.group(2), f, docBefore(text, m.start(2)))); }
            Matcher fm = Pattern.compile("(?s)(/\\*\\*.*?\\*/|///.*?(?:\\R|$))?([^;{}#\n]*?\\b[A-Za-z_][A-Za-z0-9_:<>\\*\\&\\s]+\\s+[A-Za-z_][A-Za-z0-9_]*\\s*\\([^;{}]*\\)\\s*(?:const\\s*)?[;{])").matcher(text);
            while(fm.find()) { Matcher x=fun.matcher(fm.group(2)); if(x.find() && !Set.of("if","for","while","switch","catch").contains(x.group(2))) out.add(new Item("function", x.group(2), f, docBefore(text, fm.start(2)))); }
        }
        return out;
    }

    void writeHtml(Path dir, String project, List<Path> files, List<Item> items, Config c) throws IOException {
        Files.createDirectories(dir.resolve("search"));
        Files.writeString(dir.resolve("doxygen.css"), res("doxygen.css"));
        Files.writeString(dir.resolve("tabs.css"), "body{font-family:Arial,sans-serif;margin:0} #titlearea{border-bottom:1px solid #ccc;padding:12px} .contents{padding:16px} .memitem{margin:8px 0}\n");
        Files.writeString(dir.resolve("dynsections.js"), ""); Files.writeString(dir.resolve("clipboard.js"), ""); Files.writeString(dir.resolve("search/search.js"), ""); Files.writeString(dir.resolve("search/searchdata.js"), "var indexSectionsWithContent={};\n"); Files.writeString(dir.resolve("search/search.css"), "");
        writePage(dir.resolve("index.html"), project, "Main Page", "<div class='contents'><h1>"+esc(project)+" Documentation</h1><p>Generated by Doxygen "+esc(VERSION)+".</p></div>");
        String fileRows = files.stream().map(p -> "<tr><td class='entry'><a class='el' href='"+fileHtml(p)+"'>"+esc(p.getFileName().toString())+"</a></td><td class='desc'></td></tr>").collect(Collectors.joining("\n"));
        writePage(dir.resolve("files.html"), project, "File List", "<div class='contents'><h2>File List</h2><table>"+fileRows+"</table></div>");
        List<Item> classes = items.stream().filter(i->!i.kind.equals("function")).collect(Collectors.toList());
        String clsRows = classes.stream().map(i -> "<tr><td class='entry'><a class='el' href='"+itemHtml(i)+"'>"+esc(i.name)+"</a></td><td class='desc'>"+esc(i.brief())+"</td></tr>").collect(Collectors.joining("\n"));
        writePage(dir.resolve("annotated.html"), project, "Class List", "<div class='contents'><h2>Class List</h2><table>"+clsRows+"</table></div>");
        Files.writeString(dir.resolve("classes.html"), Files.readString(dir.resolve("annotated.html")));
        String funs = items.stream().filter(i->i.kind.equals("function")).map(i->"<li>"+esc(i.name)+"() : <a class='el' href='"+fileHtml(i.file)+"'>"+esc(i.file.getFileName().toString())+"</a></li>").collect(Collectors.joining("\n"));
        writePage(dir.resolve("globals.html"), project, "File Members", "<div class='contents'><h2>File Members</h2><ul>"+funs+"</ul></div>");
        Files.writeString(dir.resolve("globals_func.html"), Files.readString(dir.resolve("globals.html")));
        for (Path f: files) {
            List<Item> its = items.stream().filter(i->i.file.equals(f)).collect(Collectors.toList());
            String body = "<div class='contents'><div class='headertitle'><div class='title'>"+esc(f.getFileName().toString())+" File Reference</div></div>";
            body += "<h2>Functions</h2>" + its.stream().filter(i->i.kind.equals("function")).map(i->"<div class='memitem'><b>"+esc(i.name)+"()</b><p>"+esc(i.doc)+"</p></div>").collect(Collectors.joining());
            body += "<h2>Classes</h2>" + its.stream().filter(i->!i.kind.equals("function")).map(i->"<div class='memitem'><a class='el' href='"+itemHtml(i)+"'>"+esc(i.name)+"</a><p>"+esc(i.doc)+"</p></div>").collect(Collectors.joining()) + "</div>";
            writePage(dir.resolve(fileHtml(f)), project, f.getFileName()+" File Reference", body);
        }
        for (Item i: classes) writePage(dir.resolve(itemHtml(i)), project, i.name + " " + cap(i.kind) + " Reference", "<div class='contents'><div class='headertitle'><div class='title'>"+esc(i.name)+" "+cap(i.kind)+" Reference</div></div><p>"+esc(i.doc)+"</p></div>");
        Files.writeString(dir.resolve("menudata.js"), "var menudata={children:[{text:'Main Page',url:'index.html'},{text:'Files',url:'files.html'}]};\n");
        Files.writeString(dir.resolve("menu.js"), "function initMenu(){}\n");
        Files.writeString(dir.resolve("navtreedata.js"), "var NAVTREE=[['"+js(project)+"','index.html',[]]];\n");
        Files.writeString(dir.resolve("navtree.js"), ""); Files.writeString(dir.resolve("navtree.css"), "");
    }
    void writePage(Path p, String project, String title, String body) throws IOException {
        String html = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en-US\"><head><meta http-equiv=\"Content-Type\" content=\"text/xhtml;charset=UTF-8\"/><meta name=\"generator\" content=\"Doxygen 1.17.0\"/><title>"+esc(project)+": "+esc(title)+"</title><link href=\"tabs.css\" rel=\"stylesheet\" type=\"text/css\"/><link href=\"doxygen.css\" rel=\"stylesheet\" type=\"text/css\" /></head><body><div id=\"top\"><div id=\"titlearea\"><div id=\"projectname\">"+esc(project)+"</div></div></div>"+body+"<hr class=\"footer\"/><address class=\"footer\"><small>Generated by Doxygen "+esc(VERSION)+"</small></address></body></html>\n";
        Files.writeString(p, html, StandardCharsets.UTF_8);
    }
    void writeLatex(Path dir, String project, List<Path> files, List<Item> items) throws IOException { Files.createDirectories(dir); Files.writeString(dir.resolve("refman.tex"), "\\documentclass{article}\n\\begin{document}\n\\title{"+tex(project)+"}\\maketitle\n" + items.stream().map(i->"\\section{"+tex(i.name)+"}\n"+tex(i.doc)+"\n").collect(Collectors.joining()) + "\\end{document}\n"); }
    void writeMan(Path dir, String project, List<Item> items) throws IOException { Files.createDirectories(dir); Files.writeString(dir.resolve(project.replaceAll("\\s+","_")+".3"), ".TH \""+project.toUpperCase(Locale.ROOT)+"\" 3\n.SH NAME\n"+project+" - generated documentation\n"); }

    static class Config { LinkedHashMap<String,String> values = new LinkedHashMap<>(); String get(String k,String d){ return values.getOrDefault(k,d); } }
    static Config parseConfig(Path p) throws IOException { return parseConfigString(Files.readString(p, StandardCharsets.UTF_8)); }
    static Config parseConfigString(String text) {
        Config c = new Config(); String pending="";
        for (String raw: text.split("\\R", -1)) {
            String line = raw.replaceFirst("\\s+#.*$", "");
            if (line.trim().isEmpty() || line.trim().startsWith("#")) continue;
            if (!pending.isEmpty()) line = pending + " " + line.trim();
            if (line.trim().endsWith("\\\\")) { pending = line.trim().substring(0,line.trim().length()-1); continue; } else pending="";
            Matcher m = Pattern.compile("^\\s*([A-Za-z0-9_]+)\\s*(?:\\+?=)\\s*(.*)$").matcher(line);
            if (m.find()) c.values.put(m.group(1), m.group(2).trim());
        }
        return c;
    }
    static String replaceTag(String text, String key, String val) { return text.replaceFirst("(?m)^"+Pattern.quote(key)+"\\s*=.*$", String.format("%-23s= %s", key, val.replace("\\","\\\\").replace("$","\\$"))); }
    static String res(String name) throws IOException { Path p=Paths.get("resources", name); if (Files.exists(p)) return Files.readString(p, StandardCharsets.UTF_8); try(InputStream in=DoxygenClone.class.getResourceAsStream("/resources/"+name)){ if(in==null)return""; return new String(in.readAllBytes(),StandardCharsets.UTF_8);} }
    static boolean yes(String s){ return s!=null && (s.trim().equalsIgnoreCase("YES") || s.trim().equalsIgnoreCase("TRUE")); }
    static String unquote(String s){ s=s.trim(); if(s.length()>=2 && s.startsWith("\"") && s.endsWith("\"")) return s.substring(1,s.length()-1); return s; }
    static String norm(String s){ return unquote(s).trim().replaceAll("\\s+"," "); }
    static List<String> splitWords(String s){ List<String> r=new ArrayList<>(); Matcher m=Pattern.compile("\"([^\"]*)\"|(\\S+)").matcher(s); while(m.find()) r.add(m.group(1)!=null?m.group(1):m.group(2)); return r; }
    static String docBefore(String text, int pos){
        String pre=text.substring(0, Math.max(0,pos));
        Matcher m=Pattern.compile("(?s)/\\*\\*.*?\\*/|(?m)^\\s*///.*$|(?m)^\\s*##.*$").matcher(pre);
        String last=null;
        int end=-1;
        while(m.find()) { last=m.group(); end=m.end(); }
        if (last==null || !pre.substring(end).trim().isEmpty()) return "";
        return cleanDoc(last);
    }
    static String cleanDoc(String s){ if(s==null)return""; return s.replaceAll("(?s)^/\\*\\*|\\*/$","").replaceAll("(?m)^\\s*\\* ?","").replaceAll("(?m)^\\s*/// ?","").replaceAll("(?m)^\\s*## ?","").replaceAll("\\\\[a-zA-Z]+","").trim(); }
    static String esc(Object o){ return String.valueOf(o).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
    static String js(String s){ return s.replace("\\","\\\\").replace("'","\\'"); }
    static String tex(String s){ return s.replace("\\","\\textbackslash{}").replace("_","\\_").replace("&","\\&").replace("%","\\%").replace("#","\\#"); }
    static String cap(String s){ return s.isEmpty()?s:Character.toUpperCase(s.charAt(0))+s.substring(1); }
    static String fileHtml(Path p){
        String n=p.getFileName().toString();
        int dot=n.lastIndexOf('.');
        if (dot>0 && dot<n.length()-1) return n.substring(0,dot).replaceAll("[^A-Za-z0-9_]","_") + "_8" + n.substring(dot+1).replaceAll("[^A-Za-z0-9_]","_") + ".html";
        return n.replaceAll("[^A-Za-z0-9_]","_") + ".html";
    }
    static String itemHtml(Item i){ return (i.kind.equals("struct")?"struct":i.kind.equals("class")?"class":i.kind) + i.name + ".html"; }
    static class Item { String kind,name,doc; Path file; Item(String k,String n,Path f,String d){kind=k;name=n;file=f;doc=d==null?"":d;} String brief(){ int i=doc.indexOf('.'); return i>=0?doc.substring(0,i+1):doc; } }
}
