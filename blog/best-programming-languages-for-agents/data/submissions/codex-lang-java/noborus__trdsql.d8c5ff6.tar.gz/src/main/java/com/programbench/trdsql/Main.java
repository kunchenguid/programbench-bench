package com.programbench.trdsql;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Opt {
        boolean help, version, ih, oh, ig = true, oaq, crlf, inum;
        String outFmt = "csv", inFmt = "", id = ",", od = ",", oq = "\"", qFile, tFile, outFile, ijq, inull, onull = "";
        String analyzeFile; boolean analyzeOnly;
        int skip = 0, limitRows = 0;
        List<String> rest = new ArrayList<>();
    }
    static class Table {
        List<String> cols = new ArrayList<>();
        List<Map<String,String>> rows = new ArrayList<>();
    }
    static class Expr {
        String raw, alias;
        Expr(String r) { raw = r.trim(); alias = defaultAlias(raw); }
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt.help) { help(); return; }
            if (opt.version) { System.out.println("trdsql version devel"); return; }
            if (opt.analyzeFile != null) {
                Table t = readTable(opt.analyzeFile, opt, null);
                String q = "SELECT " + String.join(",", t.cols) + " FROM " + opt.analyzeFile + ";";
                System.out.println(q);
                return;
            }
            String sql;
            if (opt.qFile != null) sql = Files.readString(Path.of(opt.qFile));
            else if (opt.tFile != null) sql = "select * from " + opt.tFile;
            else if (!opt.rest.isEmpty()) sql = String.join(" ", opt.rest);
            else { help(); return; }
            Result result = execute(sql.trim(), opt);
            String output = format(result, opt);
            if (opt.outFile != null) Files.writeString(Path.of(opt.outFile), output, StandardCharsets.UTF_8);
            else System.out.print(output);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i=0; i<args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-help": case "--help": o.help = true; break;
                case "-version": case "--version": o.version = true; break;
                case "-ih": o.ih = true; break;
                case "-oh": o.oh = true; break;
                case "-ig": o.ig = true; break;
                case "-icsv": o.inFmt = "csv"; break;
                case "-iltsv": o.inFmt = "ltsv"; break;
                case "-ijson": o.inFmt = "json"; break;
                case "-itext": o.inFmt = "text"; break;
                case "-oat": o.outFmt = "at"; break;
                case "-ocsv": o.outFmt = "csv"; break;
                case "-ojson": o.outFmt = "json"; break;
                case "-ojsonl": o.outFmt = "jsonl"; break;
                case "-oltsv": o.outFmt = "ltsv"; break;
                case "-omd": o.outFmt = "md"; break;
                case "-oraw": o.outFmt = "raw"; break;
                case "-otbln": o.outFmt = "tbln"; break;
                case "-ovf": o.outFmt = "vf"; break;
                case "-oyaml": o.outFmt = "yaml"; break;
                case "-oaq": o.oaq = true; break;
                case "-ocrlf": o.crlf = true; break;
                case "-inum": o.inum = true; break;
                case "-dblist": System.out.println("driver\tdsn"); System.exit(0); break;
                case "-debug": case "-out-without-guess": break;
                case "-q": o.qFile = need(args, ++i, a); break;
                case "-t": o.tFile = need(args, ++i, a); break;
                case "-id": o.id = need(args, ++i, a); break;
                case "-od": o.od = need(args, ++i, a); break;
                case "-oq": o.oq = need(args, ++i, a); break;
                case "-out": o.outFile = need(args, ++i, a); break;
                case "-ijq": o.ijq = need(args, ++i, a); break;
                case "-inull": o.inull = need(args, ++i, a); break;
                case "-onull": o.onull = need(args, ++i, a); break;
                case "-is": o.skip = Integer.parseInt(need(args, ++i, a)); break;
                case "-ilr": o.limitRows = Integer.parseInt(need(args, ++i, a)); break;
                case "-a": o.analyzeFile = need(args, ++i, a); break;
                case "-A": o.analyzeFile = need(args, ++i, a); o.analyzeOnly = true; break;
                case "-ir": case "-driver": case "-dsn": case "-db": case "-config": case "-oz":
                    if (i + 1 < args.length) i++;
                    break;
                default:
                    if (a.startsWith("-o") && a.length() > 2) o.outFmt = a.substring(2);
                    else o.rest.add(a);
            }
        }
        return o;
    }
    static String need(String[] a, int i, String flag) { if (i >= a.length) throw new IllegalArgumentException("flag needs an argument: " + flag); return a[i]; }

    static void help() {
        System.out.println("trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.\n");
        System.out.println("Usage\n\ttrdsql [OPTIONS] [SQL(SELECT...)]\n");
        System.out.println("Options:\n  -help               display usage information.\n  -q string           read query from the specified file.\n  -t string           read table name from the specified file.\n  -version            display version information.");
        System.out.println("\nInput Formats:\n  -icsv               CSV format for input.\n  -ijson              JSON format for input.\n  -iltsv              LTSV format for input.");
        System.out.println("\nOutput Formats:\n  -ocsv               CSV format for output.\n  -ojson              JSON format for output.\n  -ojsonl             JSON lines format for output.\n  -oltsv              LTSV format for output.\n  -omd                Markdown format for output.");
    }

    static class Result { List<String> cols; List<List<String>> rows; Result(List<String> c, List<List<String>> r){cols=c;rows=r;} }

    static Result execute(String sql, Opt opt) throws IOException {
        sql = sql.replaceAll(";\\s*$", "");
        int sqlLimit = -1;
        String orderBy = null;
        Matcher lm = Pattern.compile("(?is)\\s+limit\\s+(\\d+)\\s*$").matcher(sql);
        if (lm.find()) {
            sqlLimit = Integer.parseInt(lm.group(1));
            sql = sql.substring(0, lm.start()).trim();
        }
        Matcher om = Pattern.compile("(?is)\\s+order\\s+by\\s+(.+?)\\s*$").matcher(sql);
        if (om.find()) {
            orderBy = om.group(1).trim();
            sql = sql.substring(0, om.start()).trim();
        }
        Matcher m = Pattern.compile("(?is)^\\s*select\\s+(.*?)\\s+from\\s+(.+?)\\s*(?:where\\s+(.+))?\\s*$").matcher(sql);
        if (!m.find()) throw new IllegalArgumentException("unsupported query");
        String select = m.group(1).trim(), source = stripQuote(m.group(2).trim());
        String where = m.group(3) == null ? null : m.group(3).trim();
        String jq = null;
        int idx = source.indexOf("::");
        if (idx >= 0) { jq = source.substring(idx + 2); source = source.substring(0, idx); }
        if (opt.ijq != null) jq = opt.ijq;
        Table t = readTable(source, opt, jq);
        List<Expr> exprs = parseExprs(select);
        boolean aggregate = exprs.stream().anyMatch(e -> isAggregate(e.raw));
        List<String> outCols = new ArrayList<>();
        for (Expr e: exprs) outCols.add(e.alias);
        List<List<String>> out = new ArrayList<>();
        List<Map<String,String>> filtered = new ArrayList<>();
        for (Map<String,String> r: t.rows) if (where == null || evalWhere(where, r)) filtered.add(r);
        if (orderBy != null) {
            String ob = orderBy.replaceAll("(?is)\\s+asc$", "").trim();
            boolean desc = ob.toLowerCase(Locale.ROOT).endsWith(" desc");
            if (desc) ob = ob.replaceAll("(?is)\\s+desc$", "").trim();
            final String key = ob;
            final boolean reverse = desc;
            filtered.sort((a,b) -> reverse ? compare(evalExpr(key,b), evalExpr(key,a)) : compare(evalExpr(key,a), evalExpr(key,b)));
        }
        if (aggregate) {
            List<String> row = new ArrayList<>();
            for (Expr e: exprs) row.add(evalAggregate(e.raw, filtered));
            out.add(row);
        } else {
            int n = 0;
            if (select.equals("*")) outCols = new ArrayList<>(t.cols);
            for (Map<String,String> r: filtered) {
                if (sqlLimit >= 0 && n >= sqlLimit) break;
                List<String> row = new ArrayList<>();
                if (select.equals("*")) {
                    for (String c: t.cols) row.add(nvl(r.get(c)));
                } else for (Expr e: exprs) row.add(evalExpr(e.raw, r));
                out.add(row); n++;
            }
        }
        return new Result(outCols, out);
    }

    static List<Expr> parseExprs(String s) {
        if (s.trim().equals("*")) return new ArrayList<>(List.of(new Expr("*")));
        List<Expr> list = new ArrayList<>();
        for (String p: splitTop(s, ',')) {
            Matcher ma = Pattern.compile("(?is)^(.*?)\\s+as\\s+([A-Za-z_][\\w]*)$").matcher(p.trim());
            Expr e;
            if (ma.find()) { e = new Expr(ma.group(1)); e.alias = ma.group(2); }
            else e = new Expr(p);
            list.add(e);
        }
        return list;
    }
    static String defaultAlias(String raw) {
        raw = raw.trim();
        Matcher m = Pattern.compile("(?is)^([A-Za-z_][\\w]*)$").matcher(raw);
        return m.find() ? raw : raw.replaceAll("\\s+", "");
    }
    static boolean isAggregate(String r) { return r.toLowerCase(Locale.ROOT).matches("(count|sum|avg|min|max)\\s*\\(.*\\)"); }
    static String evalAggregate(String raw, List<Map<String,String>> rows) {
        Matcher m = Pattern.compile("(?is)^(count|sum|avg|min|max)\\s*\\((.*?)\\)$").matcher(raw.trim());
        if (!m.find()) return "";
        String fn = m.group(1).toLowerCase(Locale.ROOT), col = m.group(2).trim();
        if (fn.equals("count")) return String.valueOf(rows.size());
        double sum = 0; int cnt = 0; String best = null;
        for (Map<String,String> r: rows) {
            String v = evalExpr(col, r);
            if (v.isEmpty()) continue;
            if (fn.equals("min") && (best == null || compare(v, best) < 0)) best = v;
            if (fn.equals("max") && (best == null || compare(v, best) > 0)) best = v;
            try { sum += Double.parseDouble(v); cnt++; } catch (Exception ignored) {}
        }
        if (fn.equals("sum")) return trimNum(sum);
        if (fn.equals("avg")) return cnt == 0 ? "" : trimNum(sum / cnt);
        return best == null ? "" : best;
    }
    static int compare(String a, String b) { try { return Double.compare(Double.parseDouble(a), Double.parseDouble(b)); } catch(Exception e){ return a.compareTo(b); } }

    static boolean evalWhere(String w, Map<String,String> r) {
        Matcher m = Pattern.compile("(?is)^(.+?)\\s*(=|!=|<>|>=|<=|>|<|(?i:like))\\s*(.+)$").matcher(w.trim());
        if (!m.find()) return true;
        String l = evalExpr(m.group(1).trim(), r), op = m.group(2).toLowerCase(Locale.ROOT), rr = evalExpr(m.group(3).trim(), r);
        int c = compare(l, rr);
        switch (op) {
            case "=": return l.equals(rr);
            case "!=": case "<>": return !l.equals(rr);
            case ">": return c > 0;
            case "<": return c < 0;
            case ">=": return c >= 0;
            case "<=": return c <= 0;
            case "like": return l.matches(rr.replace("%", ".*").replace("_", "."));
        }
        return true;
    }
    static String evalExpr(String e, Map<String,String> r) {
        e = e.trim();
        if (e.equals("*")) return "";
        List<String> parts = splitConcat(e);
        if (parts.size() > 1) { StringBuilder sb = new StringBuilder(); for (String p: parts) sb.append(evalExpr(p, r)); return sb.toString(); }
        if ((e.startsWith("'") && e.endsWith("'")) || (e.startsWith("\"") && e.endsWith("\""))) return e.substring(1, e.length()-1);
        if (r.containsKey(e)) return nvl(r.get(e));
        return e;
    }

    static Table readTable(String src, Opt opt, String jq) throws IOException {
        String text = src.equals("-") ? new String(System.in.readAllBytes(), StandardCharsets.UTF_8) : Files.readString(Path.of(src), StandardCharsets.UTF_8);
        String fmt = opt.inFmt;
        if (fmt.isEmpty()) {
            String low = src.toLowerCase(Locale.ROOT);
            if (low.endsWith(".ltsv")) fmt = "ltsv"; else if (low.endsWith(".json") || low.endsWith(".jsonl")) fmt = "json"; else fmt = "csv";
        }
        Table t;
        if (fmt.equals("ltsv")) t = readLtsv(text, opt);
        else if (fmt.equals("json")) t = readJson(text, jq, opt);
        else t = readCsv(text, opt);
        if (opt.inum) {
            t.cols.add(0, "rowid");
            int i=1; for (Map<String,String> r: t.rows) r.put("rowid", String.valueOf(i++));
        }
        return t;
    }
    static Table readCsv(String text, Opt opt) {
        Table t = new Table(); List<List<String>> recs = parseCsv(text, opt.id.charAt(0));
        int start = Math.min(opt.skip, recs.size());
        if (opt.ih && start < recs.size()) { t.cols.addAll(recs.get(start)); start++; }
        else if (!recs.isEmpty()) for (int i=0; i<recs.get(0).size(); i++) t.cols.add("c"+(i+1));
        int lim = 0;
        for (int i=start; i<recs.size(); i++) {
            if (opt.limitRows > 0 && lim >= opt.limitRows) break;
            Map<String,String> r = new LinkedHashMap<>();
            List<String> row = recs.get(i);
            for (int c=0; c<t.cols.size(); c++) r.put(t.cols.get(c), c < row.size() ? nullIn(row.get(c), opt) : "");
            t.rows.add(r); lim++;
        }
        return t;
    }
    static Table readLtsv(String text, Opt opt) {
        Table t = new Table(); int lim = 0;
        for (String line: text.split("\\R")) {
            if (line.isEmpty()) continue;
            if (opt.limitRows > 0 && lim >= opt.limitRows) break;
            Map<String,String> r = new LinkedHashMap<>();
            for (String f: line.split("\\t")) {
                int p = f.indexOf(':'); if (p < 0) continue;
                String k = f.substring(0,p), v = nullIn(f.substring(p+1), opt);
                if (!t.cols.contains(k)) t.cols.add(k); r.put(k, v);
            }
            t.rows.add(r); lim++;
        }
        return t;
    }
    static Table readJson(String text, String jq, Opt opt) {
        Object val = new Json(text).parse();
        if (jq != null && !jq.isEmpty()) val = applyJq(val, jq);
        List<?> arr = val instanceof List ? (List<?>)val : (val instanceof Map ? List.of(val) : List.of());
        Table t = new Table(); int lim = 0;
        for (Object o: arr) {
            if (opt.limitRows > 0 && lim >= opt.limitRows) break;
            if (!(o instanceof Map)) continue;
            Map<?,?> m = (Map<?,?>)o; Map<String,String> r = new LinkedHashMap<>();
            for (Map.Entry<?,?> e: m.entrySet()) {
                String k = String.valueOf(e.getKey());
                if (!t.cols.contains(k)) t.cols.add(k);
                r.put(k, e.getValue() == null ? "" : String.valueOf(e.getValue()));
            }
            t.rows.add(r); lim++;
        }
        return t;
    }
    static Object applyJq(Object v, String jq) {
        String s = jq.trim(); if (s.startsWith(".")) s = s.substring(1);
        for (String part: s.split("\\.")) {
            if (part.isEmpty()) continue;
            part = part.replaceAll("\\[\\]$", "");
            if (v instanceof Map) v = ((Map<?,?>)v).get(part);
        }
        return v;
    }

    static String format(Result r, Opt o) {
        String nl = o.crlf ? "\r\n" : "\n";
        switch (o.outFmt) {
            case "json": return json(r, nl);
            case "jsonl": { StringBuilder sb = new StringBuilder(); for (List<String> row: r.rows) sb.append(jsonObj(r.cols,row,false)).append(nl); return sb.toString(); }
            case "ltsv": { StringBuilder sb = new StringBuilder(); for (List<String> row: r.rows) { for (int i=0;i<r.cols.size();i++){ if(i>0)sb.append('\t'); sb.append(r.cols.get(i)).append(':').append(val(row,i,o)); } sb.append(nl);} return sb.toString(); }
            case "md": return table(r, nl, false);
            case "at": return table(r, nl, true);
            case "vf": { StringBuilder sb=new StringBuilder(); int n=1; for(List<String> row:r.rows){ sb.append("-[ RECORD ").append(n++).append(" ]").append(nl); for(int i=0;i<r.cols.size();i++) sb.append(r.cols.get(i)).append(" | ").append(val(row,i,o)).append(nl);} return sb.toString(); }
            case "yaml": { StringBuilder sb=new StringBuilder(); for(List<String> row:r.rows){ sb.append("-"); for(int i=0;i<r.cols.size();i++) sb.append(i==0?" ":"\n  ").append(r.cols.get(i)).append(": ").append(val(row,i,o)); sb.append(nl);} return sb.toString(); }
            default: return csv(r, o, nl);
        }
    }
    static String csv(Result r, Opt o, String nl) {
        StringBuilder sb = new StringBuilder();
        if (o.oh) { writeCsvRow(sb, r.cols, o); sb.append(nl); }
        for (List<String> row: r.rows) { List<String> vals = new ArrayList<>(); for (int i=0;i<r.cols.size();i++) vals.add(val(row,i,o)); writeCsvRow(sb, vals, o); sb.append(nl); }
        return sb.toString();
    }
    static void writeCsvRow(StringBuilder sb, List<String> vals, Opt o) {
        for (int i=0;i<vals.size();i++) {
            if (i>0) sb.append(o.od);
            String v = vals.get(i) == null ? "" : vals.get(i);
            boolean q = o.oaq || v.contains(o.od) || v.contains("\n") || v.contains("\r") || v.contains(o.oq);
            if (q) sb.append(o.oq).append(v.replace(o.oq, o.oq+o.oq)).append(o.oq); else sb.append(v);
        }
    }
    static String json(Result r, String nl) {
        StringBuilder sb = new StringBuilder("["); if (!r.rows.isEmpty()) sb.append(nl);
        for (int i=0;i<r.rows.size();i++) { sb.append("  ").append(jsonObj(r.cols,r.rows.get(i),true)); if (i+1<r.rows.size()) sb.append(","); sb.append(nl); }
        return sb.append("]").append(nl).toString();
    }
    static String jsonObj(List<String> cols, List<String> row, boolean pretty) {
        StringBuilder sb = new StringBuilder("{");
        for (int i=0;i<cols.size();i++) {
            if (i>0) sb.append(",");
            if (pretty) sb.append("\n    ");
            sb.append('"').append(esc(cols.get(i))).append("\": ");
            if (!pretty) { sb.setLength(sb.length()-1); }
            sb.append('"').append(esc(i<row.size()?row.get(i):"")).append('"');
        }
        if (pretty && !cols.isEmpty()) sb.append("\n  ");
        return sb.append("}").toString();
    }
    static String table(Result r, String nl, boolean ascii) {
        List<String> cols = r.cols; List<Integer> w = new ArrayList<>();
        for (int i=0;i<cols.size();i++){ int mx=cols.get(i).length(); for(List<String> row:r.rows) mx=Math.max(mx,(i<row.size()?row.get(i):"").length()); w.add(mx); }
        StringBuilder sb = new StringBuilder();
        if (ascii) sb.append(border(w)).append(nl);
        sb.append(rowLine(cols,w)).append(nl);
        sb.append(sepLine(w, ascii)).append(nl);
        for (List<String> row:r.rows) sb.append(rowLine(row,w)).append(nl);
        if (ascii) sb.append(border(w)).append(nl);
        return sb.toString();
    }
    static String rowLine(List<String> vals, List<Integer> w){ StringBuilder sb=new StringBuilder("|"); for(int i=0;i<w.size();i++){ String v=i<vals.size()?vals.get(i):""; sb.append(' ').append(pad(v,w.get(i))).append(" |"); } return sb.toString(); }
    static String sepLine(List<Integer> w, boolean ascii){ if(ascii)return border(w); StringBuilder sb=new StringBuilder("|"); for(int x:w) sb.append("-".repeat(x+2)).append("|"); return sb.toString(); }
    static String border(List<Integer> w){ StringBuilder sb=new StringBuilder("+"); for(int x:w) sb.append("-".repeat(x+2)).append("+"); return sb.toString(); }
    static String pad(String s,int w){ return s + " ".repeat(Math.max(0,w-s.length())); }
    static String val(List<String> row, int i, Opt o){ String v=i<row.size()?row.get(i):""; return v==null?o.onull:v; }
    static String nullIn(String v, Opt o){ return o.inull != null && o.inull.equals(v) ? null : v; }
    static String nvl(String s){ return s == null ? "" : s; }
    static String esc(String s){ return nvl(s).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
    static String stripQuote(String s){ if((s.startsWith("'")&&s.endsWith("'"))||(s.startsWith("\"")&&s.endsWith("\"")))return s.substring(1,s.length()-1); return s; }
    static String trimNum(double d){ if (Math.rint(d)==d) return String.valueOf((long)d); return String.valueOf(d); }

    static List<List<String>> parseCsv(String text, char delim) {
        List<List<String>> rows = new ArrayList<>(); List<String> row = new ArrayList<>(); StringBuilder f = new StringBuilder(); boolean q=false;
        for (int i=0;i<text.length();i++) {
            char c=text.charAt(i);
            if(q){ if(c=='"'){ if(i+1<text.length()&&text.charAt(i+1)=='"'){f.append('"');i++;} else q=false; } else f.append(c); }
            else if(c=='"') q=true; else if(c==delim){ row.add(f.toString()); f.setLength(0); }
            else if(c=='\n'){ row.add(f.toString()); f.setLength(0); rows.add(row); row=new ArrayList<>(); }
            else if(c!='\r') f.append(c);
        }
        if(f.length()>0 || !row.isEmpty()){ row.add(f.toString()); rows.add(row); }
        return rows;
    }
    static List<String> splitTop(String s, char delim) {
        List<String> out=new ArrayList<>(); StringBuilder b=new StringBuilder(); int par=0; boolean q=false; char qc=0;
        for(char c:s.toCharArray()){ if(q){ b.append(c); if(c==qc)q=false; } else if(c=='\''||c=='"'){q=true;qc=c;b.append(c);} else if(c=='('){par++;b.append(c);} else if(c==')'){par--;b.append(c);} else if(c==delim&&par==0){out.add(b.toString());b.setLength(0);} else b.append(c); }
        out.add(b.toString()); return out;
    }
    static List<String> splitConcat(String s) {
        List<String> out=new ArrayList<>(); StringBuilder b=new StringBuilder(); boolean q=false; char qc=0;
        for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(q){b.append(c); if(c==qc)q=false;} else if(c=='\''||c=='"'){q=true;qc=c;b.append(c);} else if(c=='|'&&i+1<s.length()&&s.charAt(i+1)=='|'){out.add(b.toString());b.setLength(0);i++;} else b.append(c); }
        out.add(b.toString()); return out;
    }

    static class Json {
        final String s; int p=0; Json(String s){this.s=s.trim();}
        Object parse(){ skip(); Object v = value(); skip(); if (p < s.length()) { List<Object> lines = new ArrayList<>(); p = 0; while (p < s.length()) { skip(); if (p<s.length()) lines.add(value()); skip(); } return lines; } return v; }
        Object value(){ skip(); if(p>=s.length())return null; char c=s.charAt(p); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='"')return str(); if(c=='t'&&s.startsWith("true",p)){p+=4;return "true";} if(c=='f'&&s.startsWith("false",p)){p+=5;return "false";} if(c=='n'&&s.startsWith("null",p)){p+=4;return null;} return num(); }
        Map<String,Object> obj(){ p++; Map<String,Object> m=new LinkedHashMap<>(); skip(); while(p<s.length()&&s.charAt(p)!='}'){ String k=str(); skip(); if(p<s.length()&&s.charAt(p)==':')p++; Object v=value(); m.put(k,v); skip(); if(p<s.length()&&s.charAt(p)==','){p++;skip();} } if(p<s.length())p++; return m; }
        List<Object> arr(){ p++; List<Object> a=new ArrayList<>(); skip(); while(p<s.length()&&s.charAt(p)!=']'){ a.add(value()); skip(); if(p<s.length()&&s.charAt(p)==','){p++;skip();} } if(p<s.length())p++; return a; }
        String str(){ StringBuilder b=new StringBuilder(); p++; while(p<s.length()){ char c=s.charAt(p++); if(c=='"')break; if(c=='\\'&&p<s.length()){ char e=s.charAt(p++); if(e=='n')b.append('\n'); else if(e=='t')b.append('\t'); else if(e=='r')b.append('\r'); else b.append(e); } else b.append(c); } return b.toString(); }
        String num(){ int st=p; while(p<s.length() && "-+.0123456789eE".indexOf(s.charAt(p))>=0) p++; return s.substring(st,p); }
        void skip(){ while(p<s.length() && Character.isWhitespace(s.charAt(p))) p++; }
    }
}
