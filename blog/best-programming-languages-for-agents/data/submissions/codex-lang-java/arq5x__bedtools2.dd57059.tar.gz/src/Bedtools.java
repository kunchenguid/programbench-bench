import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

public class Bedtools {
    static final String VERSION = "b2e3657";
    static class Rec {
        String chrom, raw; int start, end, idx; String[] f;
        Rec(String line, int idx) {
            raw = line; this.idx = idx; f = line.split("\t", -1);
            if (f.length < 3) f = line.trim().split("\\s+", -1);
            chrom = f[0]; start = Integer.parseInt(f[1]); end = Integer.parseInt(f[2]);
        }
        int len(){ return Math.max(0, end-start); }
        String strand(){ return f.length >= 6 ? f[5] : "."; }
        String name(){ return f.length >= 4 ? f[3] : ""; }
        String withCoords(int s,int e){
            String[] c = f.clone(); c[1]=String.valueOf(s); c[2]=String.valueOf(e);
            return join(c);
        }
    }
    static class DBRec { Rec r; int db; DBRec(Rec r,int db){this.r=r;this.db=db;} }
    static class Opt {
        Map<String,List<String>> vals=new HashMap<>(); Set<String> flags=new HashSet<>(); List<String> rest=new ArrayList<>();
        boolean has(String k){return flags.contains(k)||vals.containsKey(k);}
        String val(String k,String d){List<String> v=vals.get(k);return v==null||v.isEmpty()?d:v.get(0);}
        List<String> vals(String k){return vals.getOrDefault(k, Collections.emptyList());}
    }

    public static void main(String[] args) throws Exception {
        if (args.length==0 || args[0].equals("--help") || args[0].equals("-h")) { help(); return; }
        if (args[0].equals("--version")) { System.out.println("bedtools v"+VERSION); return; }
        if (args[0].equals("--contact")) { System.out.println("Please see https://github.com/arq5x/bedtools2/issues"); return; }
        String c=args[0]; String[] sub=Arrays.copyOfRange(args,1,args.length);
        if (sub.length==0 || Arrays.asList(sub).contains("-h") || Arrays.asList(sub).contains("--help")) { subHelp(c); return; }
        try {
            switch(c){
                case "intersect": case "intersectBed": intersect(sub); break;
                case "merge": case "mergeBed": merge(sub); break;
                case "sort": case "sortBed": sortcmd(sub); break;
                case "complement": case "complementBed": complement(sub); break;
                case "subtract": case "subtractBed": subtract(sub); break;
                case "coverage": case "coverageBed": coverage(sub); break;
                case "closest": case "closestBed": closest(sub); break;
                case "window": case "windowBed": window(sub); break;
                case "slop": case "slopBed": slop(sub,false); break;
                case "flank": case "flankBed": slop(sub,true); break;
                case "genomecov": case "genomeCoverageBed": genomecov(sub); break;
                case "makewindows": makewindows(sub); break;
                case "jaccard": jaccard(sub); break;
                case "groupby": case "groupBy": groupby(sub); break;
                case "map": case "mapBed": mapcmd(sub); break;
                default: help(); System.exit(1);
            }
        } catch (IllegalArgumentException ex) {
            System.err.println("***** ERROR: "+ex.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] a, Set<String> takes, Set<String> multi){
        Opt o=new Opt();
        for(int i=0;i<a.length;i++){
            String x=a[i];
            if(x.startsWith("-")){
                if(takes.contains(x)){
                    if(i+1>=a.length) throw new IllegalArgumentException("Option "+x+" requires a value.");
                    List<String> vs=o.vals.computeIfAbsent(x,k->new ArrayList<>());
                    if(multi.contains(x)){
                        while(i+1<a.length && !a[i+1].startsWith("-")) vs.add(a[++i]);
                    } else vs.add(a[++i]);
                } else o.flags.add(x);
            } else o.rest.add(x);
        }
        return o;
    }
    static List<String> lines(String path) throws IOException {
        InputStream in;
        if(path==null||path.equals("-")||path.equals("stdin")) in=System.in;
        else in=Files.newInputStream(Paths.get(path));
        if(path!=null && path.endsWith(".gz")) in=new GZIPInputStream(in);
        BufferedReader br=new BufferedReader(new InputStreamReader(in));
        List<String> out=new ArrayList<>(); String s;
        while((s=br.readLine())!=null) if(!s.isEmpty()) out.add(s);
        return out;
    }
    static List<Rec> readRecs(String path) throws IOException {
        List<Rec> rs=new ArrayList<>(); int idx=0;
        for(String s: lines(path)){
            if(s.startsWith("#")||s.startsWith("track")||s.startsWith("browser")) continue;
            try { rs.add(new Rec(s, idx++)); } catch(Exception ignored) {}
        }
        return rs;
    }
    static LinkedHashMap<String,Integer> genome(String path) throws IOException {
        LinkedHashMap<String,Integer> g=new LinkedHashMap<>();
        for(String s: lines(path)){
            if(s.startsWith("#")||s.trim().isEmpty()) continue;
            String[] f=s.split("\\s+"); if(f.length>=2) g.put(f[0], Integer.parseInt(f[1]));
        }
        return g;
    }
    static String join(String[] a){return String.join("\t", a);}
    static String join(List<String> a){return String.join("\t", a);}
    static int ov(Rec a, Rec b){ if(!a.chrom.equals(b.chrom)) return 0; return Math.max(0, Math.min(a.end,b.end)-Math.max(a.start,b.start)); }
    static boolean strandOK(Rec a, Rec b, boolean same, boolean opp){
        if(!same&&!opp) return true; String as=a.strand(), bs=b.strand();
        if(as.equals(".")||bs.equals(".")) return false;
        return same ? as.equals(bs) : !as.equals(bs);
    }
    static boolean pass(Rec a, Rec b, double f, double F, boolean recip, boolean either, boolean same, boolean opp){
        int o=ov(a,b); if(o<=0 || !strandOK(a,b,same,opp)) return false;
        boolean pa = ((double)o / Math.max(1,a.len())) + 1e-12 >= f;
        boolean pb = ((double)o / Math.max(1,b.len())) + 1e-12 >= (recip ? f : F);
        return either ? (pa || pb) : (pa && pb);
    }
    static String nullB(int n){ String[] x=new String[Math.max(3,n)]; x[0]="."; x[1]="-1"; x[2]="-1"; for(int i=3;i<x.length;i++) x[i]=(i==4?"-1":"."); return join(x); }
    static void printHeader(String path) throws IOException { for(String s: lines(path)) { if(s.startsWith("#")||s.startsWith("track")||s.startsWith("browser")) System.out.println(s); else break; } }

    static void intersect(String[] args) throws Exception {
        Set<String> takes=set("-a","-b","-f","-F","-names","-g","-iobuf"); Set<String> multi=set("-b","-names");
        Opt o=parse(args,takes,multi); String af=o.val("-a",null); if(af==null) throw new IllegalArgumentException("-a is required");
        List<String> bfs=o.vals("-b"); if(bfs.isEmpty()) throw new IllegalArgumentException("-b is required");
        if(o.has("-header")) printHeader(af);
        List<Rec> A=readRecs(af); List<List<Rec>> Bs=new ArrayList<>(); int maxB=3;
        for(String b:bfs){List<Rec> br=readRecs(b); for(Rec r:br) maxB=Math.max(maxB,r.f.length); Bs.add(br);}
        boolean wa=o.has("-wa"), wb=o.has("-wb"), wo=o.has("-wo"), wao=o.has("-wao"), loj=o.has("-loj"), u=o.has("-u"), c=o.has("-c"), C=o.has("-C"), v=o.has("-v");
        double ff=Double.parseDouble(o.val("-f","1e-9")), FF=Double.parseDouble(o.val("-F","1e-9"));
        boolean same=o.has("-s"), opp=o.has("-S"), recip=o.has("-r"), either=o.has("-e");
        List<String> names=o.vals("-names");
        for(Rec a:A){
            int total=0; List<String> outs=new ArrayList<>(); int dbi=0;
            for(List<Rec> B:Bs){ int cnt=0; for(Rec b:B) if(pass(a,b,ff,FF,recip,either,same,opp)){
                cnt++; total++; if(!(u||c||C||v)){
                    String pre = (Bs.size()>1 && (wb||wo||wao||loj)) ? ((names.size()>dbi?names.get(dbi):String.valueOf(dbi+1))+"\t") : "";
                    int olen=ov(a,b);
                    if(wo||wao) outs.add(a.raw+"\t"+pre+b.raw+"\t"+olen);
                    else if(loj) outs.add(a.raw+"\t"+pre+b.raw);
                    else if(wa&&wb) outs.add(a.raw+"\t"+pre+b.raw);
                    else if(wa) outs.add(a.raw);
                    else if(wb) outs.add(pre+b.raw);
                    else outs.add(a.withCoords(Math.max(a.start,b.start), Math.min(a.end,b.end)));
                }
            }
                if(C) System.out.println(a.raw+"\t"+(Bs.size()>1?(names.size()>dbi?names.get(dbi):dbi+1)+"\t":"")+cnt);
                dbi++;
            }
            if(c) System.out.println(a.raw+"\t"+total);
            else if(u && total>0) System.out.println(a.raw);
            else if(v && total==0) System.out.println(a.raw);
            else if((wao||loj) && total==0) System.out.println(a.raw+"\t"+nullB(maxB)+(wao?"\t0":""));
            else for(String s:outs) System.out.println(s);
        }
    }

    static void merge(String[] args) throws Exception {
        Opt o=parse(args,set("-i","-d","-c","-o","-delim","-S","-prec","-iobuf"),set());
        List<Rec> rs=readRecs(o.val("-i",null)); if(rs.isEmpty()) return;
        int d=Integer.parseInt(o.val("-d","0")); boolean strand=o.has("-s"); String only=o.val("-S",null);
        List<Integer> cols=parseInts(o.val("-c","")); List<String> ops=parseOps(o.val("-o","sum"), cols.size());
        String delim=o.val("-delim",",");
        Rec first=null,last=null; List<Rec> group=new ArrayList<>();
        for(Rec r:rs){
            if(only!=null && !r.strand().equals(only)) continue;
            if(first==null){first=last=r; group.add(r); continue;}
            boolean can=r.chrom.equals(first.chrom) && r.start<=last.end+d && (!strand || r.strand().equals(first.strand()));
            if(!can){ emitMerge(first.chrom, first.start, last.end, group, cols, ops, delim); first=r; group.clear(); }
            last=r; if(r.end>last.end) last=r; group.add(r);
            if(r.end>last.end) last=r;
        }
        if(first!=null) emitMerge(first.chrom, first.start, group.stream().mapToInt(x->x.end).max().orElse(first.end), group, cols, ops, delim);
    }
    static void emitMerge(String chr,int st,int en,List<Rec> g,List<Integer> cols,List<String> ops,String delim){
        List<String> out=new ArrayList<>(Arrays.asList(chr,""+st,""+en));
        for(int i=0;i<cols.size();i++) out.add(agg(vals(g,cols.get(i)), ops.get(i), delim));
        System.out.println(join(out));
    }

    static void sortcmd(String[] args) throws Exception {
        Opt o=parse(args,set("-i","-g","-faidx"),set()); List<Rec> rs=readRecs(o.val("-i", o.rest.isEmpty()?null:o.rest.get(0)));
        Map<String,Integer> ord=new HashMap<>(); String gf=o.val("-g",o.val("-faidx",null)); if(gf!=null){int i=0; for(String k:genome(gf).keySet()) ord.put(k,i++);}
        Comparator<Rec> cmp=Comparator.comparingInt((Rec r)->ord.getOrDefault(r.chrom, Integer.MAX_VALUE)).thenComparing(r->r.chrom).thenComparingInt(r->r.start).thenComparingInt(r->r.end);
        if(o.has("-sizeA")) cmp=Comparator.comparingInt(Rec::len);
        if(o.has("-sizeD")) cmp=Comparator.comparingInt(Rec::len).reversed();
        if(o.has("-chrThenSizeA")) cmp=Comparator.comparing((Rec r)->r.chrom).thenComparingInt(Rec::len);
        if(o.has("-chrThenSizeD")) cmp=Comparator.comparing((Rec r)->r.chrom).thenComparing(Comparator.comparingInt(Rec::len).reversed());
        rs.sort(cmp); for(Rec r:rs) System.out.println(r.raw);
    }
    static void complement(String[] args) throws Exception {
        Opt o=parse(args,set("-i","-g"),set()); List<Rec> rs=readRecs(o.val("-i",null)); LinkedHashMap<String,Integer> g=genome(o.val("-g",null));
        Map<String,List<Rec>> by=byChr(rs); for(String chr:g.keySet()){ if(o.has("-L")&&!by.containsKey(chr)) continue; int pos=0; List<Rec> l=by.getOrDefault(chr,new ArrayList<>()); l.sort(Comparator.comparingInt(r->r.start));
            for(Rec r:l){ if(r.start>pos) System.out.println(chr+"\t"+pos+"\t"+r.start); pos=Math.max(pos,r.end); } if(pos<g.get(chr)) System.out.println(chr+"\t"+pos+"\t"+g.get(chr)); }
    }
    static void subtract(String[] args) throws Exception {
        Opt o=parse(args,set("-a","-b","-f","-F","-g","-iobuf"),set("-b")); List<Rec>A=readRecs(o.val("-a",null)); List<Rec>B=new ArrayList<>(); for(String b:o.vals("-b")) B.addAll(readRecs(b));
        double ff=Double.parseDouble(o.val("-f","1e-9")), FF=Double.parseDouble(o.val("-F","1e-9")); boolean same=o.has("-s"),opp=o.has("-S"),recip=o.has("-r"),either=o.has("-e");
        for(Rec a:A){ List<int[]> seg=new ArrayList<>(); seg.add(new int[]{a.start,a.end}); int sum=0; boolean any=false;
            for(Rec b:B) if(pass(a,b,ff,FF,recip,either,same,opp)){ any=true; sum+=ov(a,b); List<int[]> ns=new ArrayList<>(); for(int[] s:seg){int x=Math.max(s[0],b.start), y=Math.min(s[1],b.end); if(x<=s[0]&&y>=s[1]){} else if(x<y){ if(s[0]<x)ns.add(new int[]{s[0],x}); if(y<s[1])ns.add(new int[]{y,s[1]}); } else ns.add(s);} seg=ns; }
            if(o.has("-A")&&any) continue; if(o.has("-N")&&((double)sum/Math.max(1,a.len())>=ff)) continue;
            for(int[] s:seg) if(s[0]<s[1]) System.out.println(a.withCoords(s[0],s[1]));
        }
    }
    static void coverage(String[] args) throws Exception {
        Opt o=parse(args,set("-a","-b","-f","-F","-g","-iobuf"),set("-b")); List<Rec>A=readRecs(o.val("-a",null)); List<Rec>B=new ArrayList<>(); for(String b:o.vals("-b")) B.addAll(readRecs(b));
        double ff=Double.parseDouble(o.val("-f","1e-9")), FF=Double.parseDouble(o.val("-F","1e-9")); boolean same=o.has("-s"),opp=o.has("-S");
        for(Rec a:A){ int[] depth=new int[a.len()]; int cnt=0; for(Rec b:B) if(pass(a,b,ff,FF,o.has("-r"),o.has("-e"),same,opp)){cnt++; for(int i=Math.max(a.start,b.start);i<Math.min(a.end,b.end);i++) depth[i-a.start]++; }
            if(o.has("-counts")) {System.out.println(a.raw+"\t"+cnt); continue;}
            if(o.has("-d")) { for(int i=0;i<depth.length;i++) System.out.println(a.raw+"\t"+(i+1)+"\t"+depth[i]); continue; }
            int cov=0,sum=0; for(int x:depth){if(x>0)cov++; sum+=x;} if(o.has("-mean")) System.out.println(a.raw+"\t"+fmt7((double)sum/Math.max(1,a.len()))); else System.out.println(a.raw+"\t"+cnt+"\t"+cov+"\t"+a.len()+"\t"+fmt7((double)cov/Math.max(1,a.len())));
        }
    }
    static void closest(String[] args) throws Exception {
        Opt o=parse(args,set("-a","-b","-k","-t","-D","-names","-iobuf"),set("-b","-names")); List<Rec>A=readRecs(o.val("-a",null)); List<Rec>B=new ArrayList<>(); for(String b:o.vals("-b")) B.addAll(readRecs(b));
        int k=Integer.parseInt(o.val("-k","1")); String tie=o.val("-t","all"); boolean dist=o.has("-d")||o.has("-D");
        int maxB=B.stream().mapToInt(r->r.f.length).max().orElse(3);
        for(Rec a:A){ List<Rec> cand=new ArrayList<>(); int best=Integer.MAX_VALUE; for(Rec b:B){ if(!a.chrom.equals(b.chrom)) continue; int d=distance(a,b); if(o.has("-io")&&d==0) continue; if(d<best){best=d; cand.clear();} if(d==best)cand.add(b); }
            if(cand.isEmpty()){ System.out.println(a.raw+"\t"+nullB(maxB)+(dist?"\t-1":"")); continue; }
            if(tie.equals("first")&&cand.size()>1) cand=cand.subList(0,1); else if(tie.equals("last")&&cand.size()>1) cand=cand.subList(cand.size()-1,cand.size());
            int n=0; for(Rec b:cand){ if(n++>=k && !tie.equals("all")) break; System.out.println(a.raw+"\t"+b.raw+(dist?"\t"+distance(a,b):"")); }
        }
    }
    static int distance(Rec a,Rec b){ int o=ov(a,b); if(o>0) return 0; if(a.end<=b.start) return b.start-a.end+1; return a.start-b.end+1; }
    static void window(String[] args) throws Exception {
        Opt o=parse(args,set("-a","-b","-w","-l","-r"),set()); List<Rec>A=readRecs(o.val("-a",null)),B=readRecs(o.val("-b",null));
        int w=Integer.parseInt(o.val("-w","1000")), l=Integer.parseInt(o.val("-l",""+w)), rr=Integer.parseInt(o.val("-r",""+w));
        for(Rec a:A){ int cnt=0; List<String> outs=new ArrayList<>(); Rec win=new Rec(a.chrom+"\t"+Math.max(0,a.start-l)+"\t"+(a.end+rr),0); for(Rec b:B) if(ov(win,b)>0){cnt++; outs.add(a.raw+"\t"+b.raw);}
            if(o.has("-c")) System.out.println(a.raw+"\t"+cnt); else if(o.has("-u")){if(cnt>0)System.out.println(a.raw);} else if(o.has("-v")){if(cnt==0)System.out.println(a.raw);} else for(String s:outs)System.out.println(s);
        }
    }
    static void slop(String[] args, boolean flank) throws Exception {
        Opt o=parse(args,set("-i","-g","-b","-l","-r"),set()); List<Rec>rs=readRecs(o.val("-i",null)); Map<String,Integer>g=genome(o.val("-g",null));
        double bv=Double.parseDouble(o.val("-b","0")), lv=Double.parseDouble(o.val("-l",""+bv)), rv=Double.parseDouble(o.val("-r",""+bv)); boolean pct=o.has("-pct"), str=o.has("-s");
        for(Rec r:rs){ int len=r.len(); int l=(int)Math.floor(pct?lv*len:lv), rr=(int)Math.floor(pct?rv*len:rv); if(str&&r.strand().equals("-")){int t=l;l=rr;rr=t;} int max=g.getOrDefault(r.chrom,Integer.MAX_VALUE);
            if(flank){ int s1=Math.max(0,r.start-l), e1=Math.max(0,r.start); int s2=Math.min(max,r.end), e2=Math.min(max,r.end+rr); if(s1<e1)System.out.println(r.withCoords(s1,e1)); if(s2<e2)System.out.println(r.withCoords(s2,e2));}
            else System.out.println(r.withCoords(Math.max(0,r.start-l), Math.min(max,r.end+rr)));
        }
    }
    static void genomecov(String[] args) throws Exception {
        Opt o=parse(args,set("-i","-g","-strand","-scale","-max","-trackopts"),set()); List<Rec>rs=readRecs(o.val("-i",null)); LinkedHashMap<String,Integer>g=genome(o.val("-g",null)); double scale=Double.parseDouble(o.val("-scale","1"));
        if(o.has("-trackline")) System.out.println("track type=bedGraph"+(o.has("-trackopts")?" "+o.val("-trackopts",""):""));
        Map<String,int[]> dep=new LinkedHashMap<>(); for(String chr:g.keySet()) dep.put(chr,new int[g.get(chr)]);
        String strand=o.val("-strand",null); for(Rec r:rs){ if(strand!=null&&!r.strand().equals(strand))continue; int[] d=dep.get(r.chrom); if(d==null)continue; for(int i=Math.max(0,r.start);i<Math.min(d.length,r.end);i++)d[i]++; }
        if(o.has("-bg")||o.has("-bga")) { boolean all=o.has("-bga"); for(String chr:dep.keySet()) emitBg(chr,dep.get(chr),scale,all); return; }
        if(o.has("-d")||o.has("-dz")) { boolean dz=o.has("-dz"); for(String chr:dep.keySet()){int[] d=dep.get(chr); for(int i=0;i<d.length;i++) if(!dz||d[i]>0) System.out.println(chr+"\t"+(dz?i:i+1)+"\t"+fmt(scale*d[i]));} return; }
        TreeMap<Integer,Long> total=new TreeMap<>(); long glen=0; for(String chr:dep.keySet()){ TreeMap<Integer,Long> h=hist(dep.get(chr)); long len=dep.get(chr).length; glen+=len; for(Map.Entry<Integer,Long>e:h.entrySet()){total.merge(e.getKey(),e.getValue(),Long::sum); System.out.println(chr+"\t"+e.getKey()+"\t"+e.getValue()+"\t"+len+"\t"+fmt((double)e.getValue()/len));}} for(Map.Entry<Integer,Long>e:total.entrySet())System.out.println("genome\t"+e.getKey()+"\t"+e.getValue()+"\t"+glen+"\t"+fmt((double)e.getValue()/glen));
    }
    static void emitBg(String chr,int[] d,double scale,boolean all){ int i=0; while(i<d.length){int v=d[i], s=i; while(i<d.length&&d[i]==v)i++; if(v>0||all)System.out.println(chr+"\t"+s+"\t"+i+"\t"+fmt(v*scale));}}
    static TreeMap<Integer,Long> hist(int[] d){TreeMap<Integer,Long>h=new TreeMap<>(); for(int x:d)h.merge(x,1L,Long::sum); return h;}
    static void makewindows(String[] args) throws Exception {
        Opt o=parse(args,set("-g","-w","-s","-n"),set()); int w=Integer.parseInt(o.val("-w","0")); for(Map.Entry<String,Integer>e:genome(o.val("-g",null)).entrySet()){ for(int st=0;st<e.getValue();st+=w) System.out.println(e.getKey()+"\t"+st+"\t"+Math.min(e.getValue(),st+w)); }
    }
    static void jaccard(String[] args) throws Exception {
        Opt o=parse(args,set("-a","-b"),set()); List<Rec>A=mergeList(readRecs(o.val("-a",null))), B=mergeList(readRecs(o.val("-b",null))); long la=totalLen(A), lb=totalLen(B), inter=0; int ni=0; for(Rec a:A)for(Rec b:B){int x=ov(a,b); if(x>0){inter+=x;ni++;}} long uni=la+lb-inter; System.out.println("intersection\tunion-intersection\tjaccard\tn_intersections"); System.out.println(inter+"\t"+uni+"\t"+fmt(uni==0?0:(double)inter/uni)+"\t"+ni);
    }
    static void groupby(String[] args) throws Exception {
        Opt o=parse(args,set("-i","-g","-grp","-c","-opCols","-o","-ops","-delim","-prec"),set()); List<String> ls=lines(o.val("-i",null)); List<Integer> gs=parseInts(o.val("-g",o.val("-grp","1,2,3"))); List<Integer> cs=parseInts(o.val("-c",o.val("-opCols",""))); List<String> ops=parseOps(o.val("-o",o.val("-ops","sum")),cs.size()); String delim=o.val("-delim",",");
        String cur=null; List<String[]> group=new ArrayList<>(); for(String line:ls){String[] f=line.split("\\s+"); String key=key(f,gs,o.has("-ignorecase")); if(cur!=null&&!key.equals(cur)){emitGroup(group,gs,cs,ops,delim,o.has("-full")); group.clear();} cur=key; group.add(f);} if(!group.isEmpty())emitGroup(group,gs,cs,ops,delim,o.has("-full"));
    }
    static void mapcmd(String[] args) throws Exception {
        Opt o=parse(args,set("-a","-b","-c","-o","-delim","-f","-F"),set()); List<Rec>A=readRecs(o.val("-a",null)),B=readRecs(o.val("-b",null)); List<Integer> cs=parseInts(o.val("-c","5")); List<String> ops=parseOps(o.val("-o","sum"),cs.size()); String delim=o.val("-delim",",");
        for(Rec a:A){List<String> out=new ArrayList<>(); out.add(a.raw); List<Rec> hits=new ArrayList<>(); for(Rec b:B)if(pass(a,b,Double.parseDouble(o.val("-f","1e-9")),Double.parseDouble(o.val("-F","1e-9")),o.has("-r"),o.has("-e"),o.has("-s"),o.has("-S")))hits.add(b); for(int i=0;i<cs.size();i++){String x=agg(vals(hits,cs.get(i)),ops.get(i),delim); out.add(x.isEmpty()?".":x);} System.out.println(join(out));}
    }
    static void emitGroup(List<String[]> g,List<Integer> gs,List<Integer> cs,List<String> ops,String delim,boolean full){List<String> out=new ArrayList<>(); if(full)out.addAll(Arrays.asList(g.get(0))); else for(int c:gs)out.add(g.get(0)[c-1]); for(int i=0;i<cs.size();i++){List<String> v=new ArrayList<>(); for(String[] f:g) if(cs.get(i)-1<f.length)v.add(f[cs.get(i)-1]); out.add(agg(v,ops.get(i),delim));} System.out.println(join(out));}
    static String key(String[] f,List<Integer> gs,boolean ic){List<String> k=new ArrayList<>(); for(int c:gs){String v=f[c-1]; k.add(ic?v.toLowerCase():v);} return join(k);}
    static List<String> vals(List<Rec> rs,int col){List<String> v=new ArrayList<>(); for(Rec r:rs) if(col-1<r.f.length)v.add(r.f[col-1]); return v;}
    static String agg(List<String> v,String op,String delim){ if(v.isEmpty()) return op.equals("count")?"0":"."; switch(op){
        case "count": return ""+v.size(); case "count_distinct": return ""+new LinkedHashSet<>(v).size(); case "collapse": return String.join(delim,v); case "concat": return String.join("",v); case "distinct": return String.join(delim,new LinkedHashSet<>(v)); case "first": return v.get(0); case "last": return v.get(v.size()-1);
        case "min": return fmt(nums(v).stream().mapToDouble(x->x).min().orElse(0)); case "max": return fmt(nums(v).stream().mapToDouble(x->x).max().orElse(0)); case "mean": return fmt(nums(v).stream().mapToDouble(x->x).average().orElse(0)); case "median": {List<Double> n=nums(v); Collections.sort(n); return fmt(n.get(n.size()/2));}
        default: return fmt(nums(v).stream().mapToDouble(x->x).sum());}}
    static List<Double> nums(List<String> v){List<Double> n=new ArrayList<>(); for(String s:v)try{n.add(Double.parseDouble(s));}catch(Exception e){} if(n.isEmpty())n.add(0.0); return n;}
    static List<Integer> parseInts(String s){List<Integer> r=new ArrayList<>(); if(s==null||s.isEmpty())return r; for(String x:s.split(","))r.add(Integer.parseInt(x)); return r;}
    static List<String> parseOps(String s,int n){List<String> r=new ArrayList<>(Arrays.asList(s.split(","))); if(n==0)return r; if(r.size()==1)while(r.size()<n)r.add(r.get(0)); return r;}
    static Map<String,List<Rec>> byChr(List<Rec> rs){Map<String,List<Rec>> m=new HashMap<>(); for(Rec r:rs)m.computeIfAbsent(r.chrom,k->new ArrayList<>()).add(r); return m;}
    static List<Rec> mergeList(List<Rec> rs){rs.sort(Comparator.comparing((Rec r)->r.chrom).thenComparingInt(r->r.start)); List<Rec> out=new ArrayList<>(); for(Rec r:rs){ if(out.isEmpty()||!out.get(out.size()-1).chrom.equals(r.chrom)||r.start>out.get(out.size()-1).end)out.add(new Rec(r.chrom+"\t"+r.start+"\t"+r.end,0)); else out.get(out.size()-1).end=Math.max(out.get(out.size()-1).end,r.end);} return out;}
    static long totalLen(List<Rec> rs){long x=0; for(Rec r:rs)x+=r.len(); return x;}
    static String fmt7(double d){return String.format(Locale.US,"%.7f",d);}
    static String fmt(double d){ if(Math.abs(d-Math.rint(d))<1e-9)return ""+(long)Math.rint(d); String s=String.format(Locale.US,"%.6g",d); if(!s.contains("e")&&!s.contains("E")) s=s.replaceAll("0+$","").replaceAll("\\.$",""); return s;}
    static Set<String> set(String...x){return new HashSet<>(Arrays.asList(x));}
    static void help(){ System.out.println("bedtools is a powerful toolset for genome arithmetic.\n\nVersion:   "+VERSION+"\nUsage:     bedtools <subcommand> [options]\n\nThe bedtools sub-commands include:\n    intersect window closest coverage map genomecov merge complement subtract slop flank sort makewindows groupby jaccard\n\n[ General help ]\n    --help        Print this help menu.\n    --version     What version of bedtools are you using?."); }
    static void subHelp(String c){ System.out.println("Tool:    bedtools "+c+"\nVersion: "+VERSION+"\nUsage:   bedtools "+c+" [OPTIONS]\n\nCommon options use BED/GFF/VCF text intervals with chromosome, start, and end columns."); }
}
