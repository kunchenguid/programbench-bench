import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;
import java.util.zip.GZIPInputStream;

public class Rhit {
    static final Pattern LOG = Pattern.compile("^(\\S+) \\S+ \\S+ \\[([^:]+):(\\d{2}:\\d{2}:\\d{2}) ([^\\]]+)\\] \"([^\"]*)\" (\\S+) (\\S+) \"([^\"]*)\".*$");
    static final Map<String, Integer> MONTHS = Map.ofEntries(
        Map.entry("Jan",1), Map.entry("Feb",2), Map.entry("Mar",3), Map.entry("Apr",4),
        Map.entry("May",5), Map.entry("Jun",6), Map.entry("Jul",7), Map.entry("Aug",8),
        Map.entry("Sep",9), Map.entry("Oct",10), Map.entry("Nov",11), Map.entry("Dec",12));
    static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy/MM/dd");
    static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm:ss");

    static class Hit {
        String raw, ip, method, path, status, referer;
        long bytes;
        LocalDate date;
        LocalTime time;
    }

    static class Opt {
        String output = "tables", key = "hits", fields = null;
        int length = 1;
        boolean all, noNameCheck, silent, changes;
        String dateFilter, timeFilter, ipFilter, methodFilter, pathFilter, refFilter, statusFilter;
        List<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt opt = parseArgs(args);
            List<Path> files = findFiles(opt);
            List<Hit> hits = new ArrayList<>();
            for (Path p : files) readFile(p, hits);
            hits.sort(Comparator.comparing((Hit h) -> h.date).thenComparing(h -> h.time).thenComparing(h -> h.raw));
            List<Hit> filtered = new ArrayList<>();
            for (Hit h : hits) if (matches(h, opt)) filtered.add(h);
            if (!opt.silent) {
                String target = opt.files.isEmpty() ? "/var/log/nginx/access.log" : String.join(", ", opt.files);
                System.out.printf("I've read %d file%s in \"%s\"%n", files.size(), files.size() == 1 ? "" : "s", target);
            }
            switch (normOutput(opt.output)) {
                case "raw" -> printRaw(filtered);
                case "csv" -> printCsv(filtered);
                case "json" -> printJson(filtered);
                default -> printTables(filtered, opt);
            }
        } catch (UserExit e) {
            System.out.print(e.text);
            System.exit(e.code);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class UserExit extends RuntimeException {
        final int code; final String text;
        UserExit(int code, String text) { this.code = code; this.text = text; }
    }

    static Opt parseArgs(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help")) throw new UserExit(0, help());
            if (a.equals("--version")) throw new UserExit(0, "rhit 2.0.4\n");
            if (a.equals("--all") || a.equals("-a")) o.all = true;
            else if (a.equals("--changes") || a.equals("-c")) o.changes = true;
            else if (a.equals("--no-name-check")) o.noNameCheck = true;
            else if (a.equals("--silent-load")) o.silent = true;
            else if (a.equals("--color")) i++;
            else if (a.startsWith("--color=")) {}
            else if (a.equals("-o") || a.equals("--output")) o.output = need(args, ++i, a);
            else if (a.startsWith("--output=")) o.output = a.substring(9);
            else if (a.equals("-k") || a.equals("--key")) o.key = need(args, ++i, a);
            else if (a.equals("-l") || a.equals("--length")) o.length = Integer.parseInt(need(args, ++i, a));
            else if (a.equals("-f") || a.equals("--fields") || a.equals("--field")) o.fields = need(args, ++i, a);
            else if (a.equals("-d") || a.equals("--date")) o.dateFilter = need(args, ++i, a);
            else if (a.equals("-t") || a.equals("--time")) o.timeFilter = need(args, ++i, a);
            else if (a.equals("-i") || a.equals("--ip")) o.ipFilter = need(args, ++i, a);
            else if (a.equals("-m") || a.equals("--method")) o.methodFilter = need(args, ++i, a);
            else if (a.equals("-p") || a.equals("--path")) o.pathFilter = need(args, ++i, a);
            else if (a.equals("-r") || a.equals("--referer") || a.equals("--referrer")) o.refFilter = need(args, ++i, a);
            else if (a.equals("-s") || a.equals("--status")) o.statusFilter = need(args, ++i, a);
            else if (a.startsWith("-") && a.length() > 1) throw new RuntimeException("Unknown argument: " + a);
            else o.files.add(a);
        }
        return o;
    }

    static String need(String[] args, int i, String opt) {
        if (i >= args.length) throw new RuntimeException("Missing value for " + opt);
        return args[i];
    }

    static String help() {
        return """
rhit 2.0.4

Rhit analyzes your nginx logs.

Usage: rhit [options] [FILES]

Options:
    --help                 Print help information
    --version              Print the version
    --color <auto|yes|no>  Whether to have styles and colors
 -k --key <hits|bytes>     Key used in sorting and histogram
 -l --length <0..6>        Detail level, impacts table lengths
 -f --fields <FIELDS>      Comma separated list of hit fields to display
 -c --changes              Add tables with more/less popular entries
 -d --date <DATE>          Filter dates on a day or range
 -i --ip <IP>              IP address filter, negatable with !
 -m --method <METHOD>      HTTP method filter
 -p --path <PATH>          Pattern for path filtering
 -r --referer <REFERER>    Referer filter
 -s --status <STATUS>      Status or status range filter
 -t --time <TIME>          Time of day filter
 -a --all                  Show all paths, including resources
    --no-name-check        Try to open all files
 -o --output <OUTPUT>      tables, raw, csv, or json
    --silent-load          Don't print loading information
""";
    }

    static List<Path> findFiles(Opt o) throws IOException {
        List<Path> out = new ArrayList<>();
        if (o.files.isEmpty()) {
            Path p = Paths.get("/var/log/nginx/access.log");
            if (Files.isRegularFile(p)) out.add(p);
            return out;
        }
        for (String s : o.files) {
            Path p = Paths.get(s);
            if (Files.isDirectory(p)) {
                try (var stream = Files.walk(p)) {
                    stream.filter(Files::isRegularFile)
                        .filter(x -> o.noNameCheck || looksLikeLog(x))
                        .sorted()
                        .forEach(out::add);
                }
            } else if (Files.isRegularFile(p)) out.add(p);
        }
        return out;
    }

    static boolean looksLikeLog(Path p) {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        return n.contains("access") || n.endsWith(".log") || n.endsWith(".log.gz");
    }

    static void readFile(Path p, List<Hit> hits) throws IOException {
        InputStream in = Files.newInputStream(p);
        if (p.getFileName().toString().endsWith(".gz")) in = new GZIPInputStream(in);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                Hit h = parse(line);
                if (h != null) hits.add(h);
            }
        }
    }

    static Hit parse(String line) {
        Matcher m = LOG.matcher(line);
        if (!m.matches()) return null;
        Hit h = new Hit();
        h.raw = line;
        h.ip = m.group(1);
        String[] d = m.group(2).split("/");
        Integer mon = MONTHS.get(d[1]);
        if (mon == null) return null;
        h.date = LocalDate.of(Integer.parseInt(d[2]), mon, Integer.parseInt(d[0]));
        h.time = LocalTime.parse(m.group(3), TIME);
        String req = m.group(5);
        String[] parts = req.split("\\s+");
        if (parts.length >= 3 && parts[parts.length - 1].startsWith("HTTP/")) {
            h.method = parts[0];
            h.path = parts[1];
        } else {
            h.method = "none";
            h.path = req;
        }
        h.status = m.group(6);
        h.bytes = parseBytes(m.group(7));
        h.referer = m.group(8);
        return h;
    }

    static long parseBytes(String s) {
        try { return s.equals("-") ? 0 : Long.parseLong(s); } catch (Exception e) { return 0; }
    }

    static boolean matches(Hit h, Opt o) {
        return matchDate(h, o.dateFilter) && matchTime(h, o.timeFilter)
            && matchRegex(h.ip, o.ipFilter) && matchMethod(h.method, o.methodFilter)
            && matchExpr(h.path, o.pathFilter) && matchExpr(h.referer, o.refFilter)
            && matchStatus(h.status, o.statusFilter);
    }

    static boolean matchRegex(String value, String filter) {
        if (filter == null) return true;
        boolean neg = filter.startsWith("!");
        String f = neg ? filter.substring(1) : filter;
        boolean ok = Pattern.compile(f, Pattern.CASE_INSENSITIVE).matcher(value).find();
        return neg ? !ok : ok;
    }

    static boolean matchMethod(String value, String filter) {
        if (filter == null) return true;
        boolean neg = filter.startsWith("!");
        String f = neg ? filter.substring(1) : filter;
        boolean ok = value.equalsIgnoreCase(f);
        if (f.equalsIgnoreCase("other")) ok = !Set.of("GET","POST","HEAD","PUT","DELETE","OPTIONS","PATCH","CONNECT","TRACE","none").contains(value.toUpperCase(Locale.ROOT));
        return neg ? !ok : ok;
    }

    static boolean matchExpr(String value, String filter) {
        if (filter == null) return true;
        String expr = filter.trim();
        if (expr.contains(",")) {
            for (String part : expr.split(",")) if (!matchRegex(value, part.trim())) return false;
            return true;
        }
        return matchRegex(value, expr);
    }

    static boolean matchStatus(String status, String filter) {
        if (filter == null) return true;
        int s;
        try { s = Integer.parseInt(status); } catch (Exception e) { return false; }
        boolean anyPositive = false, positiveMatch = false;
        for (String raw : filter.split(",")) {
            String tok = raw.trim();
            if (tok.isEmpty()) continue;
            boolean neg = tok.startsWith("!");
            if (neg) tok = tok.substring(1);
            boolean ok = statusToken(s, tok);
            if (neg && ok) return false;
            if (!neg) { anyPositive = true; positiveMatch |= ok; }
        }
        return anyPositive ? positiveMatch : true;
    }

    static boolean statusToken(int s, String tok) {
        if (tok.matches("\\dxx")) return s / 100 == tok.charAt(0) - '0';
        if (tok.matches("\\d{3}-\\d{3}")) {
            String[] p = tok.split("-");
            int a = Integer.parseInt(p[0]), b = Integer.parseInt(p[1]);
            return s >= a && s <= b;
        }
        return s == Integer.parseInt(tok);
    }

    static boolean matchDate(Hit h, String f) {
        if (f == null) return true;
        boolean neg = f.startsWith("!");
        if (neg) f = f.substring(1);
        boolean ok;
        if (f.startsWith(">") || f.startsWith("<")) {
            boolean gt = f.charAt(0) == '>';
            LocalDateTime bound = parseDateTime(f.substring(1), gt, h.date.getYear());
            LocalDateTime val = LocalDateTime.of(h.date, h.time);
            ok = gt ? val.isAfter(bound) : val.isBefore(bound);
        } else if (f.contains("-")) {
            String[] p = f.split("-", 2);
            LocalDateTime a = parseDateTime(p[0], false, h.date.getYear()), b = parseDateTime(p[1], true, h.date.getYear());
            LocalDateTime val = LocalDateTime.of(h.date, h.time);
            ok = !val.isBefore(a) && !val.isAfter(b);
        } else {
            ok = matchDatePrefix(h.date, f);
        }
        return neg ? !ok : ok;
    }

    static LocalDateTime parseDateTime(String s, boolean end, int defaultYear) {
        String[] parts = s.split("T", 2);
        String[] d = parts[0].split("/");
        int y, m, day;
        if (d.length > 0 && d[0].length() == 4) {
            y = Integer.parseInt(d[0]);
            m = d.length > 1 ? Integer.parseInt(d[1]) : (end ? 12 : 1);
            day = d.length > 2 ? Integer.parseInt(d[2]) : (end ? YearMonth.of(y, m).lengthOfMonth() : 1);
        } else {
            y = defaultYear;
            m = d.length > 0 && !d[0].isEmpty() ? Integer.parseInt(d[0]) : (end ? 12 : 1);
            day = d.length > 1 ? Integer.parseInt(d[1]) : (end ? YearMonth.of(y, m).lengthOfMonth() : 1);
        }
        LocalTime t = end ? LocalTime.of(23,59,59) : LocalTime.MIDNIGHT;
        if (parts.length > 1) t = parseTimeBound(parts[1], end);
        return LocalDateTime.of(LocalDate.of(y,m,day), t);
    }

    static boolean matchDatePrefix(LocalDate date, String s) {
        String[] p = s.split("/");
        if (p.length == 1) {
            int v = Integer.parseInt(p[0]);
            return p[0].length() == 4 ? date.getYear() == v : date.getMonthValue() == v;
        }
        if (p[0].length() == 4) {
            int y = Integer.parseInt(p[0]), m = Integer.parseInt(p[1]);
            if (date.getYear() != y || date.getMonthValue() != m) return false;
            return p.length < 3 || date.getDayOfMonth() == Integer.parseInt(p[2]);
        }
        return date.getMonthValue() == Integer.parseInt(p[0]) && date.getDayOfMonth() == Integer.parseInt(p[1]);
    }

    static boolean matchTime(Hit h, String f) {
        if (f == null) return true;
        boolean neg = f.startsWith("!");
        if (neg) f = f.substring(1);
        boolean ok;
        if (f.startsWith(">") || f.startsWith("<")) {
            boolean gt = f.charAt(0) == '>';
            LocalTime b = parseTimeBound(f.substring(1), gt);
            ok = gt ? h.time.isAfter(b) : h.time.isBefore(b);
        } else if (f.contains("-")) {
            String[] p = f.split("-", 2);
            LocalTime a = parseTimeBound(p[0], false), b = parseTimeBound(p[1], true);
            ok = !h.time.isBefore(a) && !h.time.isAfter(b);
        } else ok = h.time.toString().startsWith(f);
        return neg ? !ok : ok;
    }

    static LocalTime parseTimeBound(String s, boolean end) {
        String[] p = s.split(":");
        int h = Integer.parseInt(p[0]);
        int m = p.length > 1 ? Integer.parseInt(p[1]) : (end ? 59 : 0);
        int sec = p.length > 2 ? Integer.parseInt(p[2]) : (end ? 59 : 0);
        return LocalTime.of(h, m, sec);
    }

    static String normOutput(String s) {
        s = s.toLowerCase(Locale.ROOT);
        if (s.startsWith("r")) return "raw";
        if (s.startsWith("c")) return "csv";
        if (s.startsWith("j")) return "json";
        return "tables";
    }

    static void printRaw(List<Hit> hits) {
        for (Hit h : hits) System.out.println(h.raw);
    }

    static void printCsv(List<Hit> hits) {
        System.out.println("date,time,remote address,method,path,status,bytes sent,referer");
        for (Hit h : hits) {
            System.out.printf("%s,%s,%s,%s,%s,%s,%d,%s%n",
                h.date.format(DATE), h.time.format(TIME), csvBare(h.ip), csvBare(h.method),
                csv(h.path), csvBare(h.status), h.bytes, csv(h.referer));
        }
    }

    static String csvBare(String s) { return s.contains(",") || s.contains("\"") ? csv(s) : s; }
    static String csv(String s) { return "\"" + s.replace("\"", "\"\"") + "\""; }

    static void printJson(List<Hit> hits) {
        System.out.println("[");
        for (int i = 0; i < hits.size(); i++) {
            Hit h = hits.get(i);
            System.out.println("  {");
            System.out.printf("    \"date\": \"%s\",%n", h.date.format(DATE));
            System.out.printf("    \"time\": \"%s\",%n", h.time.format(TIME));
            System.out.printf("    \"remote_addr\": \"%s\",%n", esc(h.ip));
            System.out.printf("    \"method\": \"%s\",%n", esc(h.method));
            System.out.printf("    \"path\": \"%s\",%n", esc(h.path));
            System.out.printf("    \"status\": \"%s\",%n", esc(h.status));
            System.out.printf("    \"bytes_sent\": %d,%n", h.bytes);
            System.out.printf("    \"referer\": \"%s\"%n", esc(h.referer));
            System.out.print("  }");
            if (i + 1 < hits.size()) System.out.print(",");
            System.out.println();
        }
        System.out.println("]");
    }

    static String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    static void printTables(List<Hit> hits, Opt o) {
        if (hits.isEmpty()) {
            System.out.println("0 hits");
            return;
        }
        long bytes = hits.stream().mapToLong(h -> h.bytes).sum();
        LocalDate min = hits.stream().map(h -> h.date).min(LocalDate::compareTo).orElse(null);
        LocalDate max = hits.stream().map(h -> h.date).max(LocalDate::compareTo).orElse(null);
        System.out.printf("%d hits and %d from %s to %s%n", hits.size(), bytes, min.format(DATE), max.format(DATE));
        for (String f : fields(o.fields)) {
            switch (f) {
                case "date" -> table(hits, "date", h -> h.date.format(DATE), false, o);
                case "time" -> table(hits, "time", h -> String.format("%02d:00", h.time.getHour()), false, o);
                case "method" -> table(hits, "HTTP methods", h -> h.method, false, o);
                case "status" -> table(hits, "HTTP status codes", h -> h.status, false, o);
                case "ip" -> table(hits, "remote addresses", h -> h.ip, false, o);
                case "ref" -> table(hits, "referrers", h -> h.referer, true, o);
                case "path" -> table(hits, "paths", h -> h.path, !o.all, o);
            }
        }
    }

    interface KeyFn { String get(Hit h); }

    static void table(List<Hit> hits, String title, KeyFn fn, boolean skipEmptyOrResource, Opt o) {
        Map<String, long[]> m = new HashMap<>();
        for (Hit h : hits) {
            String k = fn.get(h);
            if (skipEmptyOrResource) {
                if (k.equals("-")) continue;
                if (title.equals("paths") && isResource(k)) continue;
            }
            long[] a = m.computeIfAbsent(k, x -> new long[2]);
            a[0]++; a[1] += h.bytes;
        }
        if (m.isEmpty()) return;
        System.out.printf("%d %s. %n", m.size(), title);
        List<Map.Entry<String,long[]>> rows = new ArrayList<>(m.entrySet());
        rows.sort((a,b) -> {
            int c = Long.compare(metric(b.getValue(), o), metric(a.getValue(), o));
            if (c != 0) return c;
            c = Long.compare(b.getValue()[1], a.getValue()[1]);
            if (c != 0) return c;
            return a.getKey().compareTo(b.getKey());
        });
        int limit = Math.min(rows.size(), Math.max(5, 5 + o.length * 5));
        System.out.println("#\t" + singular(title) + "\thits\t%\tbytes");
        for (int i = 0; i < limit; i++) {
            var e = rows.get(i);
            double pct = 100.0 * e.getValue()[0] / hits.size();
            System.out.printf("%d\t%s\t%d\t%.1f%%\t%d%n", i+1, e.getKey(), e.getValue()[0], pct, e.getValue()[1]);
        }
    }

    static long metric(long[] a, Opt o) { return o.key.toLowerCase(Locale.ROOT).startsWith("b") ? a[1] : a[0]; }
    static String singular(String s) { return s.equals("paths") ? "path" : s.equals("referrers") ? "referrer" : s; }
    static boolean isResource(String p) {
        String x = p.toLowerCase(Locale.ROOT);
        return x.matches(".*\\.(css|js|png|jpg|jpeg|gif|svg|ico|webp|woff|woff2|ttf|map)(\\?.*)?$");
    }

    static List<String> fields(String spec) {
        List<String> def = new ArrayList<>(List.of("date", "status", "ref", "path"));
        if (spec == null) return def;
        List<String> cur = spec.startsWith("+") || spec.startsWith("-") ? def : new ArrayList<>();
        Matcher m = Pattern.compile("([+-]?)([A-Za-z]+)").matcher(spec.replace(",", "+"));
        while (m.find()) {
            String op = m.group(1), name = fieldName(m.group(2));
            if (name.equals("all")) {
                List<String> all = List.of("date","time","method","status","ip","ref","path");
                if (op.equals("-")) cur.clear(); else cur = new ArrayList<>(all);
                continue;
            }
            cur.remove(name);
            if (!op.equals("-")) cur.add(name);
        }
        return cur;
    }

    static String fieldName(String s) {
        s = s.toLowerCase(Locale.ROOT);
        return switch (s) {
            case "d", "date" -> "date";
            case "t", "time" -> "time";
            case "m", "method" -> "method";
            case "s", "status" -> "status";
            case "i", "ip" -> "ip";
            case "r", "ref", "referer", "referrer" -> "ref";
            case "p", "path", "paths" -> "path";
            case "a", "all" -> "all";
            default -> s;
        };
    }
}
