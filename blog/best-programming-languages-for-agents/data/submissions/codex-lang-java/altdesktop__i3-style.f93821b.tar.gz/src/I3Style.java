import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class I3Style {
    static final String VERSION = "i3-style 1.0";
    static class Theme {
        String name, desc;
        LinkedHashMap<String,String[]> bar = new LinkedHashMap<>();
        LinkedHashMap<String,String[]> win = new LinkedHashMap<>();
        Theme(String n, String d) { name=n; desc=d; }
        Theme b(String k, String... v){ bar.put(k,v); return this; }
        Theme w(String k, String... v){ win.put(k,v); return this; }
    }
    static final LinkedHashMap<String,Theme> THEMES = new LinkedHashMap<>();
    static {
        add(theme("slate","Slate theme by Jody Ribton <jody@ribton.me>","#586e75","#002b36","#aea79f","#586e75 #586e75 #ffffff","#073642 #073642 #ffffff","#002b36 #002b36 #aea79f","#77216f #77216f #ffffff","#586e75 #586e75 #fdf6e3 #268bd2","#073642 #073642 #93a1a1 #002b36","#002b36 #002b36 #586e75 #002b36","#dc322f #dc322f #fdf6e3 #dc322f"));
        add(theme("alphare","A beige theme by Alphare","#000000","#FDF6E3","#002B36","#000000 #268BD2 #FFFFFF","#333333 #222222 #FFFFFF","#333333 #222222 #888888","#2F343A #900000 #FFFFFF","#000000 #FDF6E3 #002B36 #000000","#000000 #5F676A #FDF6E3 #484E50","#000000 #000000 #FDF6E3 #000000","#000000 #DC322F #FDF6E3 #DC322F"));
        add(theme("ubuntu","Ubuntu theme by lasers","#333333","#2c001e","#aea79f","#dd4814 #dd4814 #ffffff","#902a07 #902a07 #aea79f","#902a07 #902a07 #aea79f","#77216f #77216f #ffffff","#dd4814 #dd4814 #ffffff #902a07","#5e2750 #5e2750 #aea79f #5e2750","#5e2750 #5e2750 #aea79f #5e2750","#77216f #77216f #ffffff #efb73e"));
        add(theme("flat-gray","flat gray based theme",null,"#333333","#AAAAAA","#282828 #282828 #FFFFFF",null,"#333333 #333333 #AAAAAA",null,"#000000 #000000 #FFFFFF #000000","#333333 #333333 #FFFFFF #000000","#333333 #333333 #FFFFFF #333333",null));
        add(theme("purple","Purple theme by AAlakkad <http://aalakkad.me>","#AAAAAA","#222133","#FFFFFF","#664477 #664477 #cccccc","#DCCD69 #DCCD69 #181715","#222133 #222133 #AAAAAA","#CE4045 #CE4045 #FFFFFF","#664477 #664477 #cccccc #e7d8b1","#e7d8b1 #e7d8b1 #181715 #A074C4","#222133 #222133 #AAAAAA #A074C4","#CE4045 #CE4045 #e7d8b1 #DCCD69"));
        add(theme("archlinux","Archlinux theme by okraits <http://okraits.de>","#666666","#222222","#dddddd","#0088CC #0088CC #ffffff","#333333 #333333 #ffffff","#333333 #333333 #888888","#2f343a #900000 #ffffff","#0088CC #0088CC #ffffff #dddddd","#333333 #333333 #888888 #292d2e","#333333 #333333 #888888 #292d2e","#2f343a #900000 #ffffff #900000"));
        add(theme("default","Default theme for i3wm <http://i3wm.org>","#666666","#000000","#ffffff","#4c7899 #285577 #ffffff","#333333 #5f676a #ffffff","#333333 #222222 #888888","#2f343a #900000 #ffffff","#4c7899 #285577 #ffffff #2e9ef4","#333333 #5f676a #ffffff #484e50","#333333 #222222 #888888 #292d2e","#2f343a #900000 #ffffff #900000"));
        add(theme("debian","Debian theme by lasers","#444444","#222222","#666666","#d70a53 #d70a53 #ffffff","#333333 #333333 #888888","#333333 #333333 #888888","#eb709b #eb709b #ffffff","#d70a53 #d70a53 #ffffff #8c0333","#333333 #333333 #888888 #333333","#333333 #333333 #888888 #333333","#eb709b #eb709b #ffffff #eb709b"));
        add(theme("oceanic-next","Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)","#65737E","#1B2B34","#D8DEE9","#6699CC #6699CC #1B2B34","#5FB3B3 #5FB3B3 #1B2B34","#343D46 #343D46 #D8DEE9","#EC5f67 #EC5f67 #1B2B34","#6699CC #6699CC #1B2B34 #6699CC","#5FB3B3 #5FB3B3 #D8DEE9 #A7ADBA","#343D46 #343D46 #D8DEE9 #343D46","#EC5f67 #EC5f67 #1B2B34 #EC5f67"));
        add(theme("base16-tomorrow","Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)","#969896","#1d1f21","#c5c8c6","#81a2be #81a2be #1d1f21","#373b41 #373b41 #ffffff","#282a2e #282a2e #969896","#cc6666 #cc6666 #ffffff","#81a2be #81a2be #1d1f21 #282a2e","#373b41 #373b41 #969896 #282a2e","#282a2e #282a2e #969896 #282a2e","#373b41 #cc6666 #ffffff #cc6666"));
        add(theme("okraits","A simple theme by okraits <http://okraits.de>","#666666","#333333","#bbbbbb","#888888 #dddddd #222222","#333333 #555555 #bbbbbb","#333333 #555555 #bbbbbb","#2f343a #900000 #ffffff","#888888 #dddddd #222222 #2e9ef4","#333333 #555555 #bbbbbb #484e50","#333333 #333333 #888888 #292d2e","#2f343a #900000 #ffffff #900000"));
        add(theme("icelines","icelines theme by mbfraga","#7d7d7d","#141414","#00b0ef","#00b0ef #141414 #00b0ef","#141414 #141414 #00b0ef","#141414 #141414 #7d7d7d","#ff7066 #141414 #ff7066","#00b0ef #00b0ef #141414 #ff7066","#141414 #141414 #00b0ef #472b2a","#141414 #141414 #7d7d7d #141414","#ff7066 #ff7066 #141414 #ff7066"));
        add(theme("solarized","Solarized theme by lasers","#dc322f","#002b36","#268bd2","#fdf6e3 #859900 #fdf6e3","#fdf6e3 #6c71c4 #fdf6e3","#586e75 #93a1a1 #002b36","#d33682 #d33682 #fdf6e3","#859900 #859900 #fdf6e3 #6c71c4","#073642 #073642 #eee8d5 #6c71c4","#073642 #073642 #93a1a1 #586e75","#d33682 #d33682 #fdf6e3 #dc322f"));
        add(theme("deep-purple","Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>","#666666","#000000","#ffffff","#551a8b #551a8b #ffffff","#333333 #5f676a #ffffff","#000000 #000000 #888888","#2f343a #900000 #ffffff","#3b1261 #3b1261 #ffffff #662b9c","#333333 #5f676a #ffffff #484e50","#222222 #222222 #888888 #292d2e","#2f343a #900000 #ffffff #900000"));
        add(theme("tomorrow-night-80s","Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>","#515151","#2d2d2d","#cccccc","#99cc99 #99cc99 #000000","#333333 #333333 #ffffff","#2d2d2d #2d2d2d #999999","#f2777a #f2777a #ffffff","#99cc99 #99cc99 #000000 #2d2d2d","#393939 #393939 #888888 #292d2e","#2d2d2d #2d2d2d #999999 #292d2e","#2f343a #900000 #ffffff #900000"));
        add(theme("seti","seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui","#AAAAAA","#1f2326","#FFFFFF","#9FCA56 #9FCA56 #151718","#DCCD69 #DCCD69 #151718","#1f2326 #1f2326 #AAAAAA","#CE4045 #CE4045 #FFFFFF","#4F99D3 #4F99D3 #151718 #9FCA56","#9FCA56 #9FCA56 #151718 #A074C4","#1f2326 #1f2326 #AAAAAA #A074C4","#CE4045 #CE4045 #FFFFFF #DCCD69"));
        add(theme("lime","Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>","#888888","#333333","#FFFFFF","#4E9C00 #4E9C00 #FFFFFF","#333333 #333333 #FFFFFF","#333333 #333333 #888888","#C20000 #C20000 #FFFFFF","#4E9C00 #4E9C00 #FFFFFF #FFFFFF","#1B3600 #1B3600 #888888 #FFFFFF","#333333 #333333 #888888 #FFFFFF","#C20000 #C20000 #FFFFFF #FFFFFF"));
        add(theme("gruvbox","Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>","#928374","#282828","#ebdbb2","#689d6a #689d6a #282828","#1d2021 #1d2021 #928374","#32302f #32302f #928374","#cc241d #cc241d #ebdbb2","#689d6a #689d6a #282828 #282828","#1d2021 #1d2021 #928374 #282828","#32302f #32302f #928374 #282828","#cc241d #cc241d #ebdbb2 #282828"));
        add(theme("mate","Theme for blending i3 into MATE","#ffffff","#3c3b37","#ffffff","#526532 #526532 #ffffff","#aea79f #aea79f #3c3b37","#3c3b37 #3c3b37 #aea79f","#FF0000 #FF0000 #ffffff","#526532 #526532 #ffffff #a4cb64","#aea79f #aea79f #3c3b37 #aea79f","#3c3b37 #3c3b37 #aea79f #3c3b37","#FF0000 #FF0000 #ffffff #FF0000"));
    }
    static Theme theme(String n,String d,String sep,String bg,String status,String foc,String act,String inact,String urg,String wf,String wfi,String wu,String wurg){
        Theme t=new Theme(n,d); if(sep!=null)t.b("separator",sep); if(bg!=null)t.b("background",bg); if(status!=null)t.b("statusline",status);
        if(foc!=null)t.b("focused_workspace",foc.split(" ")); if(act!=null)t.b("active_workspace",act.split(" ")); if(inact!=null)t.b("inactive_workspace",inact.split(" ")); if(urg!=null)t.b("urgent_workspace",urg.split(" "));
        if(wf!=null)t.w("focused",wf.split(" ")); if(wfi!=null)t.w("focused_inactive",wfi.split(" ")); if(wu!=null)t.w("unfocused",wu.split(" ")); if(wurg!=null)t.w("urgent",wurg.split(" ")); return t;
    }
    static void add(Theme t){THEMES.put(t.name,t);}
    public static void main(String[] args) {
        try { run(args); } catch (Exit e) { System.exit(e.code); } catch (Exception e) { System.err.println(e.getMessage()==null?e.toString():e.getMessage()); System.exit(1); }
    }
    static class Exit extends RuntimeException { int code; Exit(int c){code=c;} }
    static void run(String[] args) throws Exception {
        boolean list=false, save=false, reload=false; String config=null, output=null, toTheme=null, themeArg=null;
        for(int i=0;i<args.length;i++){
            String a=args[i];
            switch(a){
                case "-h": case "--help": help(); return;
                case "-V": case "--version": System.out.println(VERSION); return;
                case "-l": case "--list-all": list=true; break;
                case "-s": case "--save": save=true; break;
                case "-r": case "--reload": reload=true; break;
                case "-c": case "--config": config=need(args,++i,a); break;
                case "-o": case "--output": output=need(args,++i,a); break;
                case "-t": case "--to-theme": toTheme=need(args,++i,a); break;
                default:
                    if(a.startsWith("-")) { System.err.println("error: Found argument '"+a+"' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFor more information try --help"); throw new Exit(1); }
                    if(themeArg==null) themeArg=a; else { System.err.println("error: Found argument '"+a+"' which wasn't expected, or isn't valid in this context"); throw new Exit(1); }
            }
        }
        if(list){ listThemes(); return; }
        if(toTheme!=null){ validate(toTheme); System.out.print(toTheme(Files.readString(Path.of(toTheme)))); return; }
        if(themeArg==null){ System.out.println("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes."); return; }
        Path cfg = findConfig(config);
        if(cfg==null){ System.err.println("Could not find i3 config"); throw new Exit(1); }
        Theme t = loadTheme(themeArg);
        String result = apply(Files.readString(cfg), t);
        if(save) output=cfg.toString();
        if(output!=null){ validate(cfg.toString()); backupMsg(cfg.toString()); Files.writeString(Path.of(output), result); }
        else System.out.print(result);
        if(reload) runCmd("i3-msg","reload");
    }
    static String need(String[] a,int i,String opt){ if(i>=a.length){System.err.println("error: The argument '"+opt+"' requires a value but none was supplied"); throw new Exit(1);} return a[i];}
    static void help(){ System.out.println(VERSION+"\nMake your i3 config a bit more stylish\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFLAGS:\n    -h, --help        Prints help information\n    -l, --list-all    Print a list of all available themes\n    -r, --reload      Apply the theme by reloading the config\n    -s, --save        Set the output file to the path of the input file\n    -V, --version     Prints version information\n\nOPTIONS:\n    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.\n    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>\n    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others\n                             [default: ]\n\nARGS:\n    <theme>    The theme to use");}
    static void listThemes(){ System.out.println("Available themes:\n"); for(Theme t:THEMES.values()) System.out.printf("  %-18s - %s%n",t.name,t.desc); }
    static Path findConfig(String c){ if(c!=null) return Files.exists(Path.of(c))?Path.of(c):null; String h=System.getProperty("user.home"); for(String p:List.of(h+"/.config/i3/config",h+"/.i3/config")) if(Files.exists(Path.of(p))) return Path.of(p); return null; }
    static Theme loadTheme(String a) throws IOException { if(THEMES.containsKey(a)) return THEMES.get(a); Path p=Path.of(a); if(Files.exists(p)) return parseTheme(Files.readString(p)); System.err.println("Could not find theme "+a); throw new Exit(1); }
    static String apply(String in, Theme t){
        List<String> lines=new ArrayList<>(Arrays.asList(in.split("\\R",-1))); if(!lines.isEmpty()&&lines.get(lines.size()-1).isEmpty()) lines.remove(lines.size()-1);
        for(int i=0;i<lines.size();){ String tr=lines.get(i).trim(); if(tr.startsWith("client.")){String k=tr.split("\\s+")[0].substring(7); if(t.win.containsKey(k)){lines.set(i,"client."+k+" "+join(t.win.get(k))); t.win.remove(k); i++;} else if(List.of("focused","focused_inactive","unfocused","urgent").contains(k)){lines.remove(i);} else i++;} else i++; }
        int barStart=-1,barEnd=-1; for(int i=0;i<lines.size();i++) if(lines.get(i).trim().startsWith("bar")&&lines.get(i).contains("{")){barStart=i;barEnd=findBlock(lines,i);break;}
        if(barStart>=0){
            int cStart=-1,cEnd=-1; for(int i=barStart+1;i<barEnd;i++) if(lines.get(i).trim().startsWith("colors")&&lines.get(i).contains("{")){cStart=i;cEnd=findBlock(lines,i);break;}
            if(cStart>=0){ for(int i=cEnd;i>=cStart;i--) lines.remove(i); lines.addAll(cStart,colorBlock(t, "  ", false)); }
            else lines.addAll(barEnd,colorBlock(t, "  ", true));
        }
        for(Map.Entry<String,String[]> e:t.win.entrySet()) lines.add("client."+e.getKey()+" "+join(e.getValue()));
        return String.join("\n",lines)+"\n";
    }
    static int findBlock(List<String> l,int s){ int d=0; for(int i=s;i<l.size();i++){ for(char c:l.get(i).toCharArray()){ if(c=='{')d++; else if(c=='}')d--; } if(i>s&&d<=0)return i;} return l.size()-1; }
    static List<String> colorBlock(Theme t,String ind,boolean trailing){ List<String> o=new ArrayList<>(); o.add(ind+"colors {"); for(Map.Entry<String,String[]> e:t.bar.entrySet()) o.add(ind+"  "+e.getKey()+" "+join(e.getValue())+(trailing&&e.getValue().length==3?" ":"")); o.add(ind+"}"); return o; }
    static String join(String[] a){ return String.join(" ",a); }
    static void validate(String cfg){ try{ if(runCmd("i3","-C","-c",cfg)!=0) badVal(cfg); } catch(Exception e){ badVal(cfg); } }
    static void badVal(String cfg){ System.err.println("Could not validate config.\nUse `i3 -C -c "+cfg+"` to see validation errors."); throw new Exit(1); }
    static int runCmd(String... c) throws Exception { Process p=new ProcessBuilder(c).inheritIO().start(); return p.waitFor(); }
    static void backupMsg(String cfg){ System.out.println("saving config at "+cfg+" to /tmp/i3-style/"+(new Random().nextInt(899999999)+100000000)+"/config-input"); }
    static Theme parseTheme(String s){
        Map<String,String> colors=new HashMap<>(); Theme t=new Theme("custom",""); String section="", group="";
        for(String raw:s.split("\\R")){ String line=raw.split("#",2)[0]; if(line.trim().isEmpty()||line.trim().equals("---"))continue; int ind=raw.indexOf(raw.trim()); String tr=line.trim(); if(!tr.contains(":"))continue; String[] kv=tr.split(":",2); String k=kv[0].trim(), v=kv[1].trim();
            if(ind==0){ section=k; group=""; continue; } if(section.equals("colors")&&ind==2) colors.put(k,strip(v)); else if((section.equals("window_colors")||section.equals("bar_colors"))&&ind==2){ group=k; if(!v.isEmpty()) putTheme(t,section,group,"",resolve(v,colors)); }
            else if(ind>=4&&!group.isEmpty()) putTheme(t,section,group,k,resolve(v,colors));
        } return t;
    }
    static String strip(String v){ v=v.trim(); if((v.startsWith("\"")&&v.endsWith("\""))||(v.startsWith("'")&&v.endsWith("'"))) return v.substring(1,v.length()-1); return v; }
    static String resolve(String v,Map<String,String> c){ v=strip(v); return c.getOrDefault(v,v); }
    static void putTheme(Theme t,String sec,String group,String key,String val){
        if(sec.equals("bar_colors")){
            if(List.of("background","statusline","separator").contains(group)) t.b(group,val);
            else { String[] cur=t.bar.getOrDefault(group,new String[]{"","",""}); int idx=key.equals("border")?0:key.equals("background")?1:2; cur[idx]=val; t.bar.put(group,cur); }
        } else if(sec.equals("window_colors")) { String[] cur=t.win.getOrDefault(group,new String[]{"","","",""}); int idx=key.equals("border")?0:key.equals("background")?1:key.equals("text")?2:3; cur[idx]=val; t.win.put(group,cur); }
    }
    static String toTheme(String cfg){
        LinkedHashMap<String,String> vals=new LinkedHashMap<>(); StringBuilder w=new StringBuilder("---\nmeta:\n  description: AUTOMATICALLY GENERATED THEME\ncolors:\n");
        Matcher m=Pattern.compile("#[0-9A-Fa-f]{6}").matcher(cfg); int n=0; while(m.find()){String v=m.group().toUpperCase(); if(!vals.containsKey(v)) vals.put(v,"color"+(++n));}
        for(Map.Entry<String,String> e:vals.entrySet()) w.append("  ").append(e.getValue()).append(": \"").append(e.getKey()).append("\"\n");
        w.append("window_colors:\n"); for(String k:List.of("focused","focused_inactive","unfocused","urgent")) appendClient(w,cfg,k,vals);
        w.append("bar_colors:\n"); appendBar(w,cfg,"background",vals); appendBar(w,cfg,"statusline",vals); appendBar(w,cfg,"separator",vals); for(String k:List.of("focused_workspace","urgent_workspace")) appendBarGroup(w,cfg,k,vals);
        return w.toString();
    }
    static String name(LinkedHashMap<String,String> vals,String c){return vals.getOrDefault(c.toUpperCase(),c);}
    static void appendClient(StringBuilder w,String cfg,String k,LinkedHashMap<String,String> vals){ Matcher m=Pattern.compile("(?m)^\\s*client\\."+k+"\\s+(#[0-9A-Fa-f]{6})\\s+(#[0-9A-Fa-f]{6})\\s+(#[0-9A-Fa-f]{6})\\s+(#[0-9A-Fa-f]{6})").matcher(cfg); if(m.find()) w.append("  ").append(k).append(":\n    border: ").append(name(vals,m.group(1))).append("\n    background: ").append(name(vals,m.group(2))).append("\n    text: ").append(name(vals,m.group(3))).append("\n    indicator: ").append(name(vals,m.group(4))).append("\n");}
    static void appendBar(StringBuilder w,String cfg,String k,LinkedHashMap<String,String> vals){ Matcher m=Pattern.compile("(?m)^\\s*"+k+"\\s+(#[0-9A-Fa-f]{6})").matcher(cfg); if(m.find()) w.append("  ").append(k).append(": ").append(name(vals,m.group(1))).append("\n");}
    static void appendBarGroup(StringBuilder w,String cfg,String k,LinkedHashMap<String,String> vals){ Matcher m=Pattern.compile("(?m)^\\s*"+k+"\\s+(#[0-9A-Fa-f]{6})\\s+(#[0-9A-Fa-f]{6})\\s+(#[0-9A-Fa-f]{6})").matcher(cfg); if(m.find()) w.append("  ").append(k).append(":\n    border: ").append(name(vals,m.group(1))).append("\n    background: ").append(name(vals,m.group(2))).append("\n    text: ").append(name(vals,m.group(3))).append("\n");}
}
