import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Sloth {
    static final String ESC = "\u001b[";

    static class Vec {
        double x, y, z;
        Vec(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
    }

    static class Face {
        int[] idx;
        int r = 255, g = 255, b = 0;
        Face(int[] idx) { this.idx = idx; }
    }

    static class Model {
        List<Vec> vertices = new ArrayList<>();
        List<Face> faces = new ArrayList<>();
    }

    static class Options {
        boolean help, version, mono, image, web;
        int width = -1, height = -1, frames = 1;
        double yaw, pitch, roll;
        List<String> inputs = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Options o = parse(args);
            if (o.help) { printHelp(o.image); return; }
            if (o.version) { System.out.println("Sloth 0.1"); return; }
            if (o.inputs.isEmpty()) {
                System.err.println("error: The following required arguments were not provided:");
                System.err.println("    <input filename(s)>...");
                System.err.println();
                System.err.println("USAGE:");
                System.err.println("    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]");
                System.err.println();
                System.err.println("For more information try --help");
                System.exit(1);
            }
            if (o.image && o.width < 0) {
                System.err.println("error: The following required arguments were not provided:");
                System.err.println("    -w <width>");
                System.err.println();
                System.err.println("USAGE:");
                System.err.println("    executable image -h <height> -w <width>");
                System.err.println();
                System.err.println("For more information try --help");
                System.exit(1);
            }
            if (o.width < 0) o.width = readEnvInt("COLUMNS", 80);
            if (o.height < 0) o.height = Math.max(1, o.width / 2);

            Model model = new Model();
            for (String in : o.inputs) merge(model, load(Paths.get(in)));

            if (o.web) {
                System.out.println("let frames = [");
                for (int i = 0; i < Math.max(0, o.frames); i++) {
                    double rot = o.yaw + (Math.PI * 2.0 * i / Math.max(1, o.frames));
                    String frame = render(model, o.width, o.height, rot, o.pitch, o.roll, o.mono, true);
                    System.out.print("`");
                    System.out.print(frame.replace("`", "\\`"));
                    System.out.print("`");
                    if (i + 1 < o.frames) System.out.print(",");
                    System.out.println();
                }
                System.out.println("];");
            } else {
                System.out.print(render(model, o.width, o.height, o.yaw, o.pitch, o.roll, o.mono, false));
            }
        } catch (NumberFormatException e) {
            System.err.println("Error: ParseIntError { kind: InvalidDigit }");
            System.exit(1);
        } catch (Exception e) {
            System.err.println("thread 'main' panicked at src/inputs.rs:126:39:");
            System.err.println("called `Result::unwrap()` on an `Err` value: \"" + e.getMessage() + "\"");
            System.exit(101);
        }
    }

    static Options parse(String[] args) {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "--help": o.help = true; break;
                case "-h":
                    if (o.image && i + 1 < args.length && !args[i + 1].startsWith("-")) {
                        o.height = Integer.parseInt(next(args, ++i, "-h"));
                    } else {
                        o.help = true;
                    }
                    break;
                case "--version": case "-V": o.version = true; break;
                case "-b": o.mono = true; break;
                case "help": o.help = true; break;
                case "image": o.image = true; break;
                case "-w": o.width = Integer.parseInt(next(args, ++i, "-w")); break;
                case "--webify": case "-j": o.web = true; o.image = true; o.frames = Integer.parseInt(next(args, ++i, a)); break;
                case "-x": case "--yaw": o.yaw = Double.parseDouble(next(args, ++i, a)); break;
                case "-y": case "--pitch": o.pitch = Double.parseDouble(next(args, ++i, a)); break;
                case "-z": case "--roll": o.roll = Double.parseDouble(next(args, ++i, a)); break;
                default:
                    if (a.startsWith("--")) {
                        System.err.println("error: Found argument '" + a + "' which wasn't expected, or isn't valid in this context");
                        System.err.println();
                        System.err.println("USAGE:");
                        System.err.println("    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]");
                        System.err.println();
                        System.err.println("For more information try --help");
                        System.exit(1);
                    }
                    o.inputs.add(a);
            }
        }
        return o;
    }

    static String next(String[] args, int i, String opt) {
        if (i >= args.length) throw new IllegalArgumentException("missing value for " + opt);
        return args[i];
    }

    static void printHelp(boolean image) {
        if (image) {
            System.out.println("executable-image ");
            System.out.println("Mitchell Hynes <mitchell.hynes@ecumene.xyz>");
            System.out.println("Generates a colorless terminal output as lines of text");
            System.out.println();
            System.out.println("USAGE:");
            System.out.println("    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>");
            System.out.println();
            System.out.println("FLAGS:");
            System.out.println("        --help       Prints help information");
            System.out.println("    -b               Flags the rasterizer to render without color");
            System.out.println("    -V, --version    Prints version information");
            System.out.println();
            System.out.println("OPTIONS:");
            System.out.println("    -j, --webify <frame count>    Generates a portable JS based render of your object for the web");
            System.out.println("    -h <height>                   Sets the height of the image to generate");
            System.out.println("    -w <width>                    Sets the width of the image to generate");
            System.out.println("    -x, --yaw <x>                 Sets the object's static X rotation (in radians)");
            System.out.println("    -y, --pitch <y>               Sets the object's static Y rotation (in radians)");
            System.out.println("    -z, --roll <z>                Sets the object's static Z rotation (in radians)");
        } else {
            System.out.println("Sloth 0.1");
            System.out.println("Mitchell Hynes. <mshynes@mun.ca>");
            System.out.println("A toy for rendering 3D objects in the command line");
            System.out.println();
            System.out.println("USAGE:");
            System.out.println("    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]");
            System.out.println();
            System.out.println("FLAGS:");
            System.out.println("    -h, --help       Prints help information");
            System.out.println("    -b               Flags the rasterizer to render without color");
            System.out.println("    -V, --version    Prints version information");
            System.out.println();
            System.out.println("OPTIONS:");
            System.out.println("    -x, --yaw <x>      Sets the object's static X rotation (in radians)");
            System.out.println("    -y, --pitch <y>    Sets the object's static Y rotation (in radians)");
            System.out.println("    -z, --roll <z>     Sets the object's static Z rotation (in radians)");
            System.out.println();
            System.out.println("ARGS:");
            System.out.println("    <input filename(s)>...    Sets the input file to render");
            System.out.println();
            System.out.println("SUBCOMMANDS:");
            System.out.println("    help     Prints this message or the help of the given subcommand(s)");
            System.out.println("    image    Generates a colorless terminal output as lines of text");
        }
    }

    static int readEnvInt(String k, int d) {
        try { return Integer.parseInt(System.getenv().getOrDefault(k, "" + d)); }
        catch (Exception e) { return d; }
    }

    static void merge(Model a, Model b) {
        int off = a.vertices.size();
        a.vertices.addAll(b.vertices);
        for (Face f : b.faces) {
            int[] ni = new int[f.idx.length];
            for (int i = 0; i < ni.length; i++) ni[i] = f.idx[i] + off;
            Face nf = new Face(ni); nf.r = f.r; nf.g = f.g; nf.b = f.b;
            a.faces.add(nf);
        }
    }

    static Model load(Path p) throws IOException {
        String name = p.toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(".stl")) return loadStl(p);
        return loadObj(p);
    }

    static Model loadObj(Path p) throws IOException {
        if (!Files.exists(p)) throw new IOException("filename: [" + p + "] couldn't load, tobj couldnt load/parse OBJ. open file failed");
        Model m = new Model();
        Map<String, int[]> materials = new HashMap<>();
        int[] cur = {255, 255, 0};
        Path dir = p.getParent();
        if (dir == null) dir = Paths.get(".");
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            line = line.trim();
            if (line.startsWith("mtllib ")) {
                Path mt = dir.resolve(line.substring(7).trim());
                if (!Files.exists(mt)) throw new IOException("Expected to have materials.: OpenFileFailed");
                readMtl(mt, materials);
            } else if (line.startsWith("usemtl ")) {
                cur = materials.getOrDefault(line.substring(7).trim(), cur);
            } else if (line.startsWith("v ")) {
                String[] t = line.split("\\s+");
                if (t.length >= 4) m.vertices.add(new Vec(Double.parseDouble(t[1]), Double.parseDouble(t[2]), Double.parseDouble(t[3])));
            } else if (line.startsWith("f ")) {
                String[] t = line.split("\\s+");
                if (t.length >= 4) {
                    int[] ids = new int[t.length - 1];
                    for (int i = 1; i < t.length; i++) {
                        String s = t[i].split("/")[0];
                        int id = Integer.parseInt(s);
                        ids[i - 1] = id < 0 ? m.vertices.size() + id : id - 1;
                    }
                    for (int i = 1; i + 1 < ids.length; i++) {
                        Face f = new Face(new int[]{ids[0], ids[i], ids[i + 1]});
                        f.r = cur[0]; f.g = cur[1]; f.b = cur[2];
                        m.faces.add(f);
                    }
                }
            }
        }
        return m;
    }

    static void readMtl(Path p, Map<String, int[]> mats) throws IOException {
        String cur = null;
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            line = line.trim();
            if (line.startsWith("newmtl ")) cur = line.substring(7).trim();
            else if (cur != null && line.startsWith("Kd ")) {
                String[] t = line.split("\\s+");
                if (t.length >= 4) mats.put(cur, new int[]{
                    clamp((int)Math.round(Double.parseDouble(t[1]) * 255)),
                    clamp((int)Math.round(Double.parseDouble(t[2]) * 255)),
                    clamp((int)Math.round(Double.parseDouble(t[3]) * 255))});
            }
        }
    }

    static Model loadStl(Path p) throws IOException {
        if (!Files.exists(p)) throw new IOException("filename: [" + p + "] couldn't load");
        Model m = new Model();
        List<Vec> tri = new ArrayList<>(3);
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            line = line.trim();
            if (line.startsWith("vertex ")) {
                String[] t = line.split("\\s+");
                tri.add(new Vec(Double.parseDouble(t[1]), Double.parseDouble(t[2]), Double.parseDouble(t[3])));
                if (tri.size() == 3) {
                    int off = m.vertices.size();
                    m.vertices.addAll(tri);
                    m.faces.add(new Face(new int[]{off, off + 1, off + 2}));
                    tri.clear();
                }
            }
        }
        return m;
    }

    static String render(Model m, int w, int hOpt, double yaw, double pitch, double roll, boolean mono, boolean html) {
        int h = Math.max(1, hOpt / 2);
        int outW = Math.max(1, w + 2);
        char[][] pix = new char[h][outW];
        double[][] zbuf = new double[h][outW];
        int[][] cr = new int[h][outW], cg = new int[h][outW], cb = new int[h][outW];
        for (int y = 0; y < h; y++) {
            Arrays.fill(pix[y], ' ');
            Arrays.fill(zbuf[y], -1e99);
        }
        if (!m.vertices.isEmpty()) {
            List<Vec> tv = new ArrayList<>(m.vertices.size());
            double minX=1e99,minY=1e99,maxX=-1e99,maxY=-1e99;
            for (Vec v : m.vertices) {
                Vec r = rotate(v, yaw, pitch, roll);
                tv.add(r);
                minX = Math.min(minX, r.x); maxX = Math.max(maxX, r.x);
                minY = Math.min(minY, r.y); maxY = Math.max(maxY, r.y);
            }
            double sx = (outW - 3) / Math.max(1e-9, maxX - minX);
            double sy = (h - 1) / Math.max(1e-9, maxY - minY);
            double scale = Math.max(0.1, Math.min(sx, sy) * 0.88);
            double cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
            for (Face f : m.faces) {
                Vec a = tv.get(f.idx[0]), b = tv.get(f.idx[1]), c = tv.get(f.idx[2]);
                double nx = (b.y-a.y)*(c.z-a.z) - (b.z-a.z)*(c.y-a.y);
                double ny = (b.z-a.z)*(c.x-a.x) - (b.x-a.x)*(c.z-a.z);
                double nz = (b.x-a.x)*(c.y-a.y) - (b.y-a.y)*(c.x-a.x);
                double light = Math.max(0.15, Math.min(1.0, (nz + ny * .35 + nx * .15) / Math.sqrt(nx*nx+ny*ny+nz*nz + 1e-12)));
                char ch = light > .72 ? '#' : light > .42 ? '*' : '-';
                fillTri(pix, zbuf, cr, cg, cb, project(a,cx,cy,scale,outW,h), project(b,cx,cy,scale,outW,h), project(c,cx,cy,scale,outW,h),
                        ch, f.r, f.g, f.b, light, mono);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < outW; x++) {
                int r = pix[y][x] == ' ' ? 0 : cr[y][x], g = pix[y][x] == ' ' ? 0 : cg[y][x], b = pix[y][x] == ' ' ? 0 : cb[y][x];
                if (html) sb.append("<span style=\"color:rgb(").append(r).append(',').append(g).append(',').append(b).append(")\">").append(pix[y][x]);
                else sb.append(ESC).append("48;2;25;25;25m").append(ESC).append("38;2;").append(r).append(';').append(g).append(';').append(b).append('m')
                       .append(pix[y][x]).append(ESC).append("49m").append(ESC).append("39m");
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    static Vec rotate(Vec v, double ax, double ay, double az) {
        double x=v.x,y=v.y,z=v.z;
        double c=Math.cos(ax),s=Math.sin(ax); double ny=y*c-z*s,nz=y*s+z*c; y=ny; z=nz;
        c=Math.cos(ay);s=Math.sin(ay); double nx=x*c+z*s; nz=-x*s+z*c; x=nx; z=nz;
        c=Math.cos(az);s=Math.sin(az); nx=x*c-y*s; ny=x*s+y*c; x=nx; y=ny;
        return new Vec(x,y,z);
    }

    static double[] project(Vec v, double cx, double cy, double scale, int w, int h) {
        return new double[]{(v.x-cx)*scale + (w-1)/2.0, (h-1)/2.0 - (v.y-cy)*scale, v.z};
    }

    static void fillTri(char[][] pix, double[][] zbuf, int[][] cr, int[][] cg, int[][] cb,
                        double[] a, double[] b, double[] c, char ch, int r, int g, int bl, double light, boolean mono) {
        int h = pix.length, w = pix[0].length;
        int minX = Math.max(0, (int)Math.floor(Math.min(a[0], Math.min(b[0], c[0]))));
        int maxX = Math.min(w-1, (int)Math.ceil(Math.max(a[0], Math.max(b[0], c[0]))));
        int minY = Math.max(0, (int)Math.floor(Math.min(a[1], Math.min(b[1], c[1]))));
        int maxY = Math.min(h-1, (int)Math.ceil(Math.max(a[1], Math.max(b[1], c[1]))));
        double area = edge(a,b,c[0],c[1]);
        if (Math.abs(area) < 1e-9) return;
        for (int y = minY; y <= maxY; y++) for (int x = minX; x <= maxX; x++) {
            double px=x+.5, py=y+.5;
            double w0=edge(b,c,px,py)/area, w1=edge(c,a,px,py)/area, w2=edge(a,b,px,py)/area;
            if (w0 >= -1e-6 && w1 >= -1e-6 && w2 >= -1e-6) {
                double z = w0*a[2] + w1*b[2] + w2*c[2];
                if (z > zbuf[y][x]) {
                    zbuf[y][x] = z; pix[y][x] = ch;
                    cr[y][x] = mono ? 255 : clamp((int)(r * light));
                    cg[y][x] = mono ? 255 : clamp((int)(g * light));
                    cb[y][x] = mono ? 255 : clamp((int)(bl * light));
                }
            }
        }
    }

    static double edge(double[] a, double[] b, double x, double y) {
        return (x-a[0])*(b[1]-a[1]) - (y-a[1])*(b[0]-a[0]);
    }

    static int clamp(int v) { return Math.max(0, Math.min(255, v)); }
}
