import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Solar {
    static final String VERSION = "0.1.8";
    static final String LONG_VERSION = "solar Version: 0.1.8\nCommit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5\nBuild Timestamp: 2026-04-17T19:59:51.519973035Z\nBuild Features: mimalloc,tracing\nBuild Profile: release";
    static final Set<String> EMITS = new LinkedHashSet<>(Arrays.asList("abi", "hashes"));

    public static void main(String[] args) {
        try {
            int code = new Solar().run(args);
            System.exit(code);
        } catch (Exit e) {
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        Opt opt = parse(args);
        if (opt.helpLong) { System.out.print(helpLong()); return 0; }
        if (opt.helpShort) { System.out.print(helpShort()); return 0; }
        if (opt.versionLong) { System.out.println(LONG_VERSION); return 0; }
        if (opt.versionShort) { System.out.println("solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)"); return 0; }
        if (opt.zhelp) { System.out.print(zhelp()); return 0; }
        if (opt.inputs.isEmpty()) {
            if (opt.emit.isEmpty()) {
                System.out.print(helpShort());
                return 2;
            }
            System.err.println("error: no files found\n  │\n  ╰ note: if you wish to use the standard input, please specify `-` explicitly\n\nerror: aborting due to 1 previous error\n");
            return 1;
        }
        if (opt.emit.isEmpty() || opt.stopAfter != null) return 0;

        LinkedHashMap<String, Contract> contracts = new LinkedHashMap<>();
        LinkedHashSet<Path> visited = new LinkedHashSet<>();
        for (String in : opt.inputs) {
            if (in.contains("=") && !Files.exists(Paths.get(in))) continue;
            String text, label;
            if (in.equals("-")) {
                text = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
                label = "<stdin>";
            } else {
                Path p = Paths.get(in);
                if (!Files.exists(p)) {
                    errorHuman("file " + in + " not found");
                    return 1;
                }
                text = Files.readString(p);
                label = in;
            }
            if (!balanced(text)) {
                emitSyntax(opt, label, text);
                return 1;
            }
            if (in.equals("-")) {
                for (Contract c : parseContracts(label, text)) contracts.put(label + ":" + c.name, c);
            } else {
                processFile(Paths.get(in), in, contracts, visited);
            }
        }
        applyInheritance(contracts);
        String json = json(contracts, opt.emit, opt.prettyJson, 0);
        if (opt.outDir != null) {
            Path out = Paths.get(opt.outDir).resolve("combined.json");
            try {
                Files.writeString(out, json + (opt.prettyJson ? "\n" : ""), StandardCharsets.UTF_8);
            } catch (IOException e) {
                System.err.println("error: failed to write to output: " + e.getMessage());
                System.err.println("\nerror: aborting due to 1 previous error\n");
                return 1;
            }
        } else {
            System.out.print(json);
        }
        return 0;
    }

    Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "--help": o.helpLong = true; break;
                case "-h": o.helpShort = true; break;
                case "--version": o.versionLong = true; break;
                case "-V": o.versionShort = true; break;
                case "--pretty-json": o.prettyJson = true; break;
                case "--pretty-json-err": o.prettyJsonErr = true; break;
                case "--no-warnings": case "-v": case "--verbose": break;
                case "-Z":
                    String z = need(args, ++i, "-Z <FLAG>");
                    if (z.equals("help")) o.zhelp = true;
                    break;
                case "-Zhelp": o.zhelp = true; break;
                case "--emit":
                    for (String e : need(args, ++i, "--emit <EMIT>").split(",")) {
                        if (!EMITS.contains(e)) usageErr("invalid value '" + e + "' for '--emit <EMIT>'\n  [possible values: abi, hashes]");
                        o.emit.add(e);
                    }
                    break;
                case "--out-dir": o.outDir = need(args, ++i, "--out-dir <OUT_DIR>"); break;
                case "--stop-after":
                    o.stopAfter = need(args, ++i, "--stop-after <STOP_AFTER>");
                    if (!Arrays.asList("parsing","lowering","analysis").contains(o.stopAfter))
                        usageErr("invalid value '" + o.stopAfter + "' for '--stop-after <STOP_AFTER>'\n  [possible values: parsing, lowering, analysis]");
                    break;
                case "-j": case "--threads": case "--jobs":
                    String n = need(args, ++i, "--threads <THREADS>");
                    try { Integer.parseUnsignedInt(n); } catch (Exception e) { usageErr("invalid value '" + n + "' for '--threads <THREADS>': invalid digit found in string"); }
                    break;
                case "--evm-version":
                    String evm = need(args, ++i, "--evm-version <EVM_VERSION>");
                    if (!Arrays.asList("homestead","tangerineWhistle","spuriousDragon","byzantium","constantinople","petersburg","istanbul","berlin","london","paris","shanghai","cancun","prague","osaka").contains(evm))
                        usageErr("invalid value '" + evm + "' for '--evm-version <EVM_VERSION>'");
                    break;
                case "--color": case "--error-format": case "--error-format-human": case "--diagnostic-width": case "--base-path": case "-I": case "--include-path": case "--allow-paths":
                    String v = need(args, ++i, a + " <VALUE>");
                    if (a.equals("--error-format")) o.errorFormat = v;
                    break;
                default:
                    if (a.startsWith("--emit=")) { args = splice(args, i, "--emit", a.substring(7)); i--; }
                    else if (a.startsWith("-Z")) { if (a.equals("-Zhelp")) o.zhelp = true; }
                    else if (a.startsWith("-") && !a.equals("-")) usageErr("unexpected argument '" + a + "' found");
                    else o.inputs.add(a);
            }
        }
        return o;
    }

    static String[] splice(String[] args, int idx, String a, String b) {
        String[] r = new String[args.length + 1];
        System.arraycopy(args, 0, r, 0, idx); r[idx]=a; r[idx+1]=b;
        System.arraycopy(args, idx+1, r, idx+2, args.length-idx-1); return r;
    }
    static String need(String[] args, int i, String what) { if (i >= args.length) usageErr("a value is required for '" + what + "'"); return args[i]; }
    static void usageErr(String s) { System.err.println("error: " + s + "\n\nFor more information, try '--help'."); throw new Exit(2); }
    static void errorHuman(String s) { System.err.println("error: " + s + "\n\nerror: aborting due to 1 previous error\n"); }

    static List<Contract> parseContracts(String file, String src) {
        String clean = stripComments(src);
        ArrayList<Contract> out = new ArrayList<>();
        Matcher m = Pattern.compile("\\b(contract|interface|library)\\s+([A-Za-z_$][A-Za-z0-9_$]*)([^\\{;]*)\\{").matcher(clean);
        while (m.find()) {
            int open = clean.indexOf('{', m.end()-1), close = match(clean, open);
            if (close < 0) continue;
            Contract c = new Contract(m.group(2));
            String extra = m.group(3);
            Matcher is = Pattern.compile("\\bis\\s+([^\\{]+)").matcher(extra);
            if (is.find()) for (String b : is.group(1).split(",")) {
                String bn = b.trim().split("\\s+")[0];
                if (bn.matches("[A-Za-z_$][A-Za-z0-9_$]*")) c.bases.add(bn);
            }
            parseBody(c, clean.substring(open + 1, close));
            c.sort();
            out.add(c);
            m.region(close + 1, clean.length());
        }
        return out;
    }

    static void processFile(Path p, String label, LinkedHashMap<String, Contract> contracts, Set<Path> visited) throws IOException {
        Path real = p.toAbsolutePath().normalize();
        if (!visited.add(real)) return;
        String text = Files.readString(p);
        Matcher im = Pattern.compile("\\bimport\\s+(?:[^\"';]*from\\s+)?[\"']([^\"']+)[\"']\\s*;").matcher(stripComments(text));
        while (im.find()) {
            Path q = p.toAbsolutePath().getParent().resolve(im.group(1)).normalize();
            if (Files.exists(q)) processFile(q, q.toString(), contracts, visited);
        }
        for (Contract c : parseContracts(label, text)) contracts.put(label + ":" + c.name, c);
    }

    static void applyInheritance(LinkedHashMap<String, Contract> contracts) {
        HashMap<String, Contract> byName = new HashMap<>();
        for (Contract c: contracts.values()) byName.put(c.name, c);
        for (Contract c: contracts.values()) {
            ArrayList<AbiEntry> inherited = new ArrayList<>();
            HashSet<String> seen = new HashSet<>();
            for (AbiEntry e: c.entries) seen.add(sigKey(e));
            for (String b: c.bases) {
                Contract bc = byName.get(b);
                if (bc == null) continue;
                for (AbiEntry e: bc.entries) {
                    if (e.type.equals("constructor")) continue;
                    String k = sigKey(e);
                    if (seen.add(k)) inherited.add(e);
                }
            }
            if (!inherited.isEmpty()) {
                inherited.addAll(c.entries);
                c.entries = inherited;
                c.sort();
            }
        }
    }
    static String sigKey(AbiEntry e) { return e.type + ":" + (e.name == null ? "" : e.name) + ":" + joinTypes(e.inputs); }

    static void parseBody(Contract c, String body) {
        List<String> items = topItems(body);
        for (String item : items) {
            String t = item.trim();
            if (t.isEmpty()) continue;
            if (t.startsWith("function ")) parseFunction(c, t);
            else if (t.startsWith("constructor")) parseConstructor(c, t);
            else if (t.startsWith("event ")) parseEvent(c, t);
            else if (t.startsWith("error ")) parseError(c, t);
            else if (t.startsWith("receive(") || t.startsWith("receive (")) parseReceive(c, t);
            else if (t.startsWith("fallback(") || t.startsWith("fallback (")) parseFallback(c, t);
            else parseVariable(c, t);
        }
    }

    static void parseFunction(Contract c, String t) {
        Matcher m = Pattern.compile("^function\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\((.*?)\\)(.*)$", Pattern.DOTALL).matcher(t);
        if (!m.find()) return;
        String tail = beforeBody(m.group(3));
        if (tail.matches("(?s).*\\b(private|internal)\\b.*")) return;
        AbiEntry e = new AbiEntry("function"); e.name = m.group(1);
        e.inputs = params(m.group(2), false);
        Matcher r = Pattern.compile("\\breturns\\s*\\((.*?)\\)", Pattern.DOTALL).matcher(tail);
        e.outputs = r.find() ? params(r.group(1), false) : new ArrayList<>();
        e.state = state(tail);
        c.entries.add(e);
    }

    static void parseConstructor(Contract c, String t) {
        Matcher m = Pattern.compile("^constructor\\s*\\((.*?)\\)(.*)$", Pattern.DOTALL).matcher(t);
        if (!m.find()) return;
        AbiEntry e = new AbiEntry("constructor");
        e.inputs = params(m.group(1), false);
        e.state = beforeBody(m.group(2)).contains("payable") ? "payable" : "nonpayable";
        c.entries.add(e);
    }
    static void parseEvent(Contract c, String t) {
        Matcher m = Pattern.compile("^event\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\((.*?)\\)(.*)$", Pattern.DOTALL).matcher(t);
        if (!m.find()) return;
        AbiEntry e = new AbiEntry("event"); e.name = m.group(1); e.inputs = params(m.group(2), true); e.anonymous = m.group(3).contains("anonymous"); c.entries.add(e);
    }
    static void parseError(Contract c, String t) {
        Matcher m = Pattern.compile("^error\\s+([A-Za-z_$][A-Za-z0-9_$]*)\\s*\\((.*?)\\)", Pattern.DOTALL).matcher(t);
        if (!m.find()) return;
        AbiEntry e = new AbiEntry("error"); e.name = m.group(1); e.inputs = params(m.group(2), false); c.entries.add(e);
    }
    static void parseReceive(Contract c, String t) {
        AbiEntry e = new AbiEntry("receive"); e.state = "payable"; e.inputs = new ArrayList<>(); e.outputs = new ArrayList<>(); c.entries.add(e);
    }
    static void parseFallback(Contract c, String t) {
        AbiEntry e = new AbiEntry("fallback"); e.state = t.contains("payable") ? "payable" : "nonpayable"; e.inputs = new ArrayList<>(); e.outputs = new ArrayList<>(); c.entries.add(e);
    }
    static void parseVariable(Contract c, String t) {
        String head = beforeBody(t).replace(";", " ").trim();
        if (!head.matches("(?s).*\\bpublic\\b.*") || head.matches("(?s).*\\b(function|modifier|struct|enum|using)\\b.*")) return;
        List<String> toks = new ArrayList<>(Arrays.asList(head.split("\\s+")));
        if (toks.size() < 2) return;
        String name = toks.get(toks.size() - 1);
        if (name.contains("=")) name = name.substring(0, name.indexOf('='));
        if (!name.matches("[A-Za-z_$][A-Za-z0-9_$]*")) return;
        StringBuilder type = new StringBuilder();
        for (String tok : toks) {
            if (tok.equals("public") || tok.equals("private") || tok.equals("internal") || tok.equals("external") || tok.equals("constant") || tok.equals("immutable") || tok.equals("override") || tok.equals(name)) continue;
            if (type.length() > 0) type.append(' ');
            type.append(tok);
        }
        AbiEntry e = new AbiEntry("function"); e.name = name; e.inputs = new ArrayList<>(); e.outputs = new ArrayList<>(); getter(type.toString(), e.inputs, e.outputs); e.state = "view"; c.entries.add(e);
    }

    static void getter(String typ, List<Param> ins, List<Param> outs) {
        typ = normInternal(typ);
        while (typ.startsWith("mapping")) {
            int open = typ.indexOf('('), close = matchParen(typ, open);
            if (open < 0 || close < 0) break;
            String inside = typ.substring(open + 1, close);
            int arrow = inside.indexOf("=>");
            if (arrow < 0) break;
            Param key = param("", inside.substring(0, arrow).trim(), false); key.indexed = null; ins.add(key);
            typ = inside.substring(arrow + 2).trim() + typ.substring(close + 1).trim();
        }
        while (typ.matches("(?s).*\\[[^\\]]*\\]$")) {
            Param idx = param("", "uint256", false); idx.indexed = null; ins.add(idx);
            typ = typ.replaceFirst("\\[[^\\]]*\\]$", "");
        }
        Param out = param("", typ, false); out.indexed = null; outs.add(out);
    }
    static int matchParen(String s, int open) { int d=0; for(int i=open;i<s.length();i++){char c=s.charAt(i); if(c=='(')d++; else if(c==')'&&--d==0)return i;} return -1; }

    static List<Param> params(String s, boolean event) {
        ArrayList<Param> ps = new ArrayList<>();
        for (String part : splitTop(s, ',')) {
            part = part.trim();
            if (part.isEmpty()) continue;
            boolean indexed = part.matches("(?s).*\\bindexed\\b.*");
            part = part.replaceAll("\\b(indexed|memory|calldata|storage)\\b", " ").replaceAll("\\s+", " ").trim();
            String[] toks = part.split("\\s+");
            String name = "";
            if (toks.length > 1 && toks[toks.length-1].matches("[A-Za-z_$][A-Za-z0-9_$]*") && !isTypeWord(toks[toks.length-1])) {
                name = toks[toks.length-1];
                part = part.substring(0, part.lastIndexOf(name)).trim();
            }
            Param p = param(name, part, indexed); if (!event) p.indexed = null; ps.add(p);
        }
        return ps;
    }
    static Param param(String name, String internal, boolean indexed) {
        Param p = new Param(); p.name = name; p.internalType = normInternal(internal); p.type = abiType(p.internalType); p.indexed = indexed; return p;
    }
    static boolean isTypeWord(String s) { return Arrays.asList("uint","int","bool","address","string","bytes","byte","payable").contains(s) || s.matches("u?int\\d*|bytes\\d+"); }
    static String normInternal(String s) { return s.trim().replaceAll("\\s+", " ").replace("uint ", "uint256 ").replaceAll("^uint$", "uint256").replaceAll("^int$", "int256"); }
    static String abiType(String s) {
        s = normInternal(s).replace(" payable", "");
        if (s.startsWith("uint[")) s = "uint256" + s.substring(4);
        if (s.startsWith("int[")) s = "int256" + s.substring(3);
        return s;
    }
    static String state(String s) {
        if (s.matches("(?s).*\\bpayable\\b.*")) return "payable";
        if (s.matches("(?s).*\\bpure\\b.*")) return "pure";
        if (s.matches("(?s).*\\bview\\b.*")) return "view";
        return "nonpayable";
    }
    static String beforeBody(String s) { int b = s.indexOf('{'); return b >= 0 ? s.substring(0, b) : s; }

    static String json(LinkedHashMap<String, Contract> contracts, LinkedHashSet<String> emits, boolean pretty, int level) {
        J j = new J(pretty);
        j.objStart();
        j.comma(0);
        j.key("contracts"); j.objStart();
        int ci = 0;
        for (Map.Entry<String, Contract> me : contracts.entrySet()) {
            j.comma(ci++); j.key(me.getKey()); j.objStart();
            int ei = 0;
            if (emits.contains("abi")) { j.comma(ei++); j.key("abi"); abiArray(j, me.getValue().entries); }
            if (emits.contains("hashes")) { j.comma(ei++); j.key("hashes"); hashes(j, me.getValue().entries); }
            j.objEnd();
        }
        j.objEnd();
        j.comma(1); j.key("version"); j.str(VERSION);
        j.objEnd();
        return j.s.toString();
    }
    static void abiArray(J j, List<AbiEntry> es) {
        j.arrStart();
        for (int i=0;i<es.size();i++) { j.comma(i); abiEntry(j, es.get(i)); }
        j.arrEnd();
    }
    static void abiEntry(J j, AbiEntry e) {
        j.objStart(); int n=0;
        j.comma(n++); j.key("type"); j.str(e.type);
        if (e.name != null) { j.comma(n++); j.key("name"); j.str(e.name); }
        if (!e.type.equals("fallback") && !e.type.equals("receive")) { j.comma(n++); j.key("inputs"); paramsJson(j, e.inputs); }
        if (e.type.equals("function")) { j.comma(n++); j.key("outputs"); paramsJson(j, e.outputs); }
        if (e.type.equals("constructor") || e.type.equals("function") || e.type.equals("fallback") || e.type.equals("receive")) { j.comma(n++); j.key("stateMutability"); j.str(e.state); }
        if (e.type.equals("event")) { j.comma(n++); j.key("anonymous"); j.bool(e.anonymous); }
        j.objEnd();
    }
    static void paramsJson(J j, List<Param> ps) {
        j.arrStart();
        for (int i=0;i<ps.size();i++) {
            Param p=ps.get(i); j.comma(i); j.objStart(); int n=0;
            j.comma(n++); j.key("name"); j.str(p.name);
            j.comma(n++); j.key("type"); j.str(p.type);
            if (p.indexed != null) { j.comma(n++); j.key("indexed"); j.bool(p.indexed); }
            j.comma(n++); j.key("internalType"); j.str(p.internalType);
            j.objEnd();
        }
        j.arrEnd();
    }
    static void hashes(J j, List<AbiEntry> es) {
        TreeMap<String,String> map = new TreeMap<>();
        for (AbiEntry e: es) if (e.type.equals("function")) {
            String sig = e.name + "(" + joinTypes(e.inputs) + ")";
            map.put(sig, Keccak.hex4(sig));
        }
        j.objStart(); int i=0;
        for (Map.Entry<String,String> e: map.entrySet()) { j.comma(i++); j.key(e.getKey()); j.str(e.getValue()); }
        j.objEnd();
    }
    static String joinTypes(List<Param> ps) { ArrayList<String> a = new ArrayList<>(); for (Param p: ps) a.add(p.type); return String.join(",", a); }

    static String stripComments(String s) { return s.replaceAll("(?s)/\\*.*?\\*/", "").replaceAll("(?m)//.*$", ""); }
    static boolean balanced(String s) { int d=0; for(char c: stripStrings(s).toCharArray()){ if(c=='{')d++; else if(c=='}')d--; if(d<0)return false;} return d==0; }
    static String stripStrings(String s) { return s.replaceAll("\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*'", "\"\""); }
    static int match(String s, int open) { int d=0; for(int i=open;i<s.length();i++){ char c=s.charAt(i); if(c=='{')d++; else if(c=='}' && --d==0)return i; } return -1; }
    static List<String> topItems(String b) {
        ArrayList<String> r = new ArrayList<>(); int start=0, dPar=0,dBr=0,dCur=0;
        for (int i=0;i<b.length();i++) {
            char c=b.charAt(i);
            if(c=='(')dPar++; else if(c==')')dPar--; else if(c=='[')dBr++; else if(c==']')dBr--;
            else if(c=='{')dCur++; else if(c=='}')dCur--;
            if(dPar==0&&dBr==0&&((c==';'&&dCur==0)||(c=='}'&&dCur==0))) { r.add(b.substring(start,i+1)); start=i+1; }
        }
        return r;
    }
    static List<String> splitTop(String s, char sep) {
        ArrayList<String> r = new ArrayList<>(); int st=0, p=0,b=0;
        for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(c=='(')p++; else if(c==')')p--; else if(c=='[')b++; else if(c==']')b--; else if(c==sep&&p==0&&b==0){r.add(s.substring(st,i));st=i+1;}}
        r.add(s.substring(st)); return r;
    }
    static void emitSyntax(Opt o, String file, String text) {
        if ("json".equals(o.errorFormat)) {
            System.out.println("{\"sourceLocation\":{\"file\":\""+esc(file)+"\",\"start\":" + Math.max(0,text.length()-1) + ",\"end\":" + text.length() + "},\"secondarySourceLocations\":[{\"file\":\""+esc(file)+"\",\"start\":0,\"end\":0,\"message\":\"for a full list of valid contract items, see <https://docs.soliditylang.org/en/latest/grammar.html#a4.SolidityParser.contractBodyElement>\"}],\"type\":\"Exception\",\"component\":\"general\",\"severity\":\"error\",\"errorCode\":null,\"message\":\"expected contract item (function, variable, struct, or modifier definition), found `<eof>`\",\"formattedMessage\":\"error: expected contract item (function, variable, struct, or modifier definition), found `<eof>`\\n\\n\"}");
            System.out.println("{\"sourceLocation\":null,\"secondarySourceLocations\":[],\"type\":\"Exception\",\"component\":\"general\",\"severity\":\"error\",\"errorCode\":null,\"message\":\"aborting due to 1 previous error\",\"formattedMessage\":\"error: aborting due to 1 previous error\\n\\n\"}");
        } else {
            System.err.println("error: expected contract item (function, variable, struct, or modifier definition), found `<eof>`");
            System.err.println("\nerror: aborting due to 1 previous error\n");
        }
    }
    static String esc(String s) { return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }

    static String helpShort() { return "Blazingly fast Solidity compiler\n\nUsage: executable [OPTIONS] [INPUT]...\n\nArguments:\n  [INPUT]...  Files to compile, or import remappings\n\nOptions:\n  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]\n      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]\n      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]\n      --out-dir <OUT_DIR>          Directory to write output files\n      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]\n  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time\n  -h, --help                       Print help (see more with '--help')\n  -V, --version                    Print version\n\nInput options:\n      --base-path <BASE_PATH>        Use the given path as the root of the source tree\n  -I, --include-path <INCLUDE_PATH>  Directory to search for files\n      --allow-paths <ALLOW_PATHS>    Allow a given path for imports\n\nDisplay options:\n      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]\n  -v, --verbose                      Use verbose output\n      --pretty-json                  Pretty-print JSON output\n      --pretty-json-err              Pretty-print error JSON output\n      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]\n      --error-format-human <VALUE>   Human-readable error message style [default: unicode] [possible values: ascii, unicode, short]\n      --diagnostic-width <WIDTH>     Terminal width for error message formatting\n      --no-warnings                  Whether to disable warnings\n"; }
    static String helpLong() { return helpShort().replace("Print help (see more with '--help')", "Print help (see a summary with '-h')").replace("[INPUT]...  Files to compile, or import remappings", "[INPUT]...\n          Files to compile, or import remappings.\n          \n          `-` specifies standard input.\n          \n          Import remappings are specified as `[context:]prefix=path`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>."); }
    static String zhelp() { return "error: List of all unstable flags.\nWARNING: these are completely unstable, and may change at any time!\n\nOptions:\n      -Zui-testing\n          Enables UI testing mode\n\n      -Ztrack-diagnostics\n          Prints a note for every diagnostic that is emitted with the creation and emission location.\n          \n          This is enabled by default on debug builds.\n\n      -Zparse-yul\n          Enables parsing Yul files for testing\n\n      -Zno-resolve-imports\n          Disables import resolution\n\n      -Zdump=<KIND[=PATHS...]>\n          Print additional information about the compiler's internal state.\n          \n          Valid kinds are `ast` and `hir`.\n\n      -Zast-stats\n          Print AST stats\n\n      -Zspan-visitor\n          Run the span visitor after parsing\n\n      -Zprint-max-storage-sizes\n          Print contracts' max storage sizes\n\n      -Ztypeck\n          Type check the program. WIP\n\n      -Zhelp\n          Print help\n\nUsage: solar [OPTIONS] [INPUT]...\n\nFor more information, try '--help'.\n"; }

    static class Opt { boolean helpLong,helpShort,versionLong,versionShort,zhelp,prettyJson,prettyJsonErr; String outDir,stopAfter,errorFormat="human"; ArrayList<String> inputs=new ArrayList<>(); LinkedHashSet<String> emit=new LinkedHashSet<>(); }
    static class Exit extends RuntimeException { int code; Exit(int c){code=c;} }
    static class Contract { String name; ArrayList<String> bases=new ArrayList<>(); ArrayList<AbiEntry> entries=new ArrayList<>(); Contract(String n){name=n;} void sort(){ entries.sort(Comparator.comparingInt((AbiEntry e)->rank(e.type)).thenComparing(e->e.name==null?"":e.name)); } }
    static int rank(String t){ return switch(t){ case "constructor"->0; case "error"->1; case "event"->2; case "fallback"->3; case "function"->4; case "receive"->5; default->9;}; }
    static class AbiEntry { String type,name,state="nonpayable"; boolean anonymous=false; List<Param> inputs=new ArrayList<>(), outputs=new ArrayList<>(); AbiEntry(String t){type=t;} }
    static class Param { String name,type,internalType; Boolean indexed; }

    static class J {
        StringBuilder s=new StringBuilder(); boolean p; int d=0;
        ArrayDeque<Integer> counts = new ArrayDeque<>();
        J(boolean p){this.p=p;} void nl(){ if(p){s.append('\n'); for(int i=0;i<d;i++)s.append("  ");} }
        void comma(int i){ if(i>0)s.append(','); if(p)nl(); if(!counts.isEmpty()) counts.push(counts.pop()+1); }
        void objStart(){s.append('{'); d++; counts.push(0);} void objEnd(){int c=counts.pop(); d--; if(p && c>0)nl(); s.append('}');}
        void arrStart(){s.append('['); d++; counts.push(0);} void arrEnd(){int c=counts.pop(); d--; if(p && c>0)nl(); s.append(']');}
        void key(String k){str(k); s.append(p?": ":":");} void str(String v){s.append('"').append(esc(v)).append('"');} void bool(boolean b){s.append(b);}
    }
}
