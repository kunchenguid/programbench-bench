import java.nio.charset.StandardCharsets;

public class Keccak {
    private static final long[] RC = {
        0x0000000000000001L,0x0000000000008082L,0x800000000000808aL,0x8000000080008000L,
        0x000000000000808bL,0x0000000080000001L,0x8000000080008081L,0x8000000000008009L,
        0x000000000000008aL,0x0000000000000088L,0x0000000080008009L,0x000000008000000aL,
        0x000000008000808bL,0x800000000000008bL,0x8000000000008089L,0x8000000000008003L,
        0x8000000000008002L,0x8000000000000080L,0x000000000000800aL,0x800000008000000aL,
        0x8000000080008081L,0x8000000000008080L,0x0000000080000001L,0x8000000080008008L
    };
    private static final int[] R = {
        0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14
    };

    public static String hex4(String s) {
        byte[] h = digest(s.getBytes(StandardCharsets.UTF_8), 32);
        StringBuilder out = new StringBuilder();
        for (int i=0;i<4;i++) out.append(String.format("%02x", h[i] & 0xff));
        return out.toString();
    }

    public static byte[] digest(byte[] msg, int outLen) {
        int rate = 136; // Keccak-256
        long[] st = new long[25];
        int off = 0;
        while (msg.length - off >= rate) {
            absorb(st, msg, off, rate);
            keccakf(st);
            off += rate;
        }
        byte[] block = new byte[rate];
        System.arraycopy(msg, off, block, 0, msg.length - off);
        block[msg.length - off] = 0x01;
        block[rate - 1] |= (byte)0x80;
        absorb(st, block, 0, rate);
        keccakf(st);
        byte[] out = new byte[outLen];
        int pos = 0;
        while (pos < outLen) {
            for (int i=0;i<rate && pos<outLen;i++) out[pos++] = (byte)((st[i/8] >>> (8*(i%8))) & 0xff);
            if (pos < outLen) keccakf(st);
        }
        return out;
    }

    private static void absorb(long[] st, byte[] b, int off, int len) {
        for (int i=0;i<len/8;i++) st[i] ^= le(b, off + i*8);
    }
    private static long le(byte[] b, int off) {
        long v=0; for(int i=0;i<8;i++) v |= (long)(b[off+i]&0xff) << (8*i); return v;
    }
    private static long rot(long x, int n) { return (x << n) | (x >>> (64-n)); }

    private static void keccakf(long[] a) {
        long[] b = new long[25], c = new long[5], d = new long[5];
        for (int round=0; round<24; round++) {
            for (int x=0;x<5;x++) c[x]=a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20];
            for (int x=0;x<5;x++) d[x]=c[(x+4)%5]^rot(c[(x+1)%5],1);
            for (int x=0;x<5;x++) for (int y=0;y<5;y++) a[x+5*y]^=d[x];
            for (int x=0;x<5;x++) for (int y=0;y<5;y++) {
                int idx=x+5*y;
                int nx=y, ny=(2*x+3*y)%5;
                b[nx+5*ny]=rot(a[idx], R[idx]);
            }
            for (int x=0;x<5;x++) for (int y=0;y<5;y++)
                a[x+5*y]=b[x+5*y]^((~b[((x+1)%5)+5*y])&b[((x+2)%5)+5*y]);
            a[0]^=RC[round];
        }
    }
}
