package com.programbench.flamelens;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Main {
    private static final String HELP = """
Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
""";

    private Main() {
    }

    public static void main(String[] args) {
        int status = run(args);
        if (status != 0) {
            System.exit(status);
        }
    }

    private static int run(String[] args) {
        boolean sorted = false;
        boolean echo = false;
        boolean debug = false;
        String filename = null;
        boolean positionalOnly = false;

        for (String arg : args) {
            if (!positionalOnly && "--".equals(arg)) {
                positionalOnly = true;
                continue;
            }
            if (!positionalOnly && arg.startsWith("-")) {
                switch (arg) {
                    case "-h":
                    case "--help":
                        System.out.print(HELP);
                        return 0;
                    case "-V":
                    case "--version":
                        System.out.println("flamelens 0.3.1");
                        return 0;
                    case "--sorted":
                        sorted = true;
                        continue;
                    case "--echo":
                        echo = true;
                        continue;
                    case "--debug":
                        debug = true;
                        continue;
                    default:
                        printUnexpectedArgument(arg, true);
                        return 2;
                }
            }
            if (filename == null) {
                filename = arg;
            } else {
                printUnexpectedArgument(arg, false);
                return 2;
            }
        }

        String data;
        if (filename != null) {
            try {
                data = readFile(filename);
            } catch (IOException e) {
                printReadPanic(e);
                return 101;
            }
        } else {
            try {
                data = readAll(System.in);
            } catch (IOException e) {
                System.err.println("Error: " + osError(e));
                return 1;
            }
        }

        if (echo) {
            System.out.print(data);
        }

        if (System.console() == null) {
            System.err.println("Error: Os { code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }");
            return 1;
        }

        try {
            Viewer viewer = new Viewer(parse(data, sorted), debug, sorted);
            viewer.run();
            return 0;
        } catch (IOException e) {
            System.err.println("Error: " + osError(e));
            return 1;
        }
    }

    private static void printUnexpectedArgument(String arg, boolean optionLike) {
        System.err.println("error: unexpected argument '" + arg + "' found");
        System.err.println();
        if (optionLike) {
            System.err.println("  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'");
            System.err.println();
        }
        System.err.println("Usage: executable [OPTIONS] [FILENAME]");
        System.err.println();
        System.err.println("For more information, try '--help'.");
    }

    private static String readFile(String filename) throws IOException {
        try (InputStream in = new FileInputStream(new File(filename))) {
            return readAll(in);
        }
    }

    private static String readAll(InputStream input) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = input.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        return out.toString(StandardCharsets.UTF_8);
    }

    private static void printReadPanic(IOException e) {
        System.err.println();
        System.err.println("thread 'main' (" + ProcessHandle.current().pid() + ") panicked at src/main.rs:44:47:");
        System.err.println("Could not read file: " + osError(e));
        System.err.println("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace");
    }

    private static String osError(IOException e) {
        String message = e.getMessage();
        if (message == null) {
            message = "Input/output error";
        }
        if (message.contains("No such file or directory")) {
            return "Os { code: 2, kind: NotFound, message: \"No such file or directory\" }";
        }
        return "Os { code: 5, kind: Uncategorized, message: \"" + message.replace("\"", "\\\"") + "\" }";
    }

    private static Profile parse(String data, boolean sorted) {
        Frame root = new Frame("(root)", null);
        long total = 0;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new java.io.ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) {
                    continue;
                }
                int split = line.lastIndexOf(' ');
                if (split <= 0 || split == line.length() - 1) {
                    continue;
                }
                long value;
                try {
                    value = Long.parseLong(line.substring(split + 1).trim());
                } catch (NumberFormatException ignored) {
                    continue;
                }
                if (value < 0) {
                    continue;
                }
                total += value;
                Frame cur = root;
                String[] names = line.substring(0, split).split(";");
                for (String name : names) {
                    if (name.isEmpty()) {
                        continue;
                    }
                    cur = cur.child(name);
                    cur.value += value;
                }
            }
        } catch (IOException ignored) {
            // ByteArrayInputStream-backed reader cannot fail in normal operation.
        }
        root.value = total;
        List<Frame> flattened = new ArrayList<>();
        flatten(root, flattened, 0, sorted);
        return new Profile(root, flattened);
    }

    private static void flatten(Frame frame, List<Frame> out, int depth, boolean sorted) {
        frame.depth = depth;
        if (frame.parent != null) {
            out.add(frame);
        }
        List<Frame> children = new ArrayList<>(frame.children.values());
        if (sorted) {
            children.sort(Comparator.comparingLong((Frame f) -> f.value).reversed().thenComparing(f -> f.name));
        }
        for (Frame child : children) {
            flatten(child, out, depth + 1, sorted);
        }
    }

    private static final class Frame {
        final String name;
        final Frame parent;
        final Map<String, Frame> children = new HashMap<>();
        long value;
        int depth;

        Frame(String name, Frame parent) {
            this.name = name;
            this.parent = parent;
        }

        Frame child(String childName) {
            return children.computeIfAbsent(childName, n -> new Frame(n, this));
        }
    }

    private record Profile(Frame root, List<Frame> frames) {
    }

    private static final class Viewer {
        private final Profile profile;
        private final boolean debug;
        private final boolean sorted;
        private int cursor = 0;
        private int offset = 0;

        Viewer(Profile profile, boolean debug, boolean sorted) {
            this.profile = profile;
            this.debug = debug;
            this.sorted = sorted;
        }

        void run() throws IOException {
            Terminal.enter();
            try {
                draw();
                while (true) {
                    int ch = System.in.read();
                    if (ch < 0 || ch == 'q' || ch == 3) {
                        break;
                    }
                    handle(ch);
                    draw();
                }
            } finally {
                Terminal.leave();
            }
        }

        private void handle(int ch) {
            int max = Math.max(0, profile.frames.size() - 1);
            if (ch == 'j' || ch == 'l' || ch == 'n') {
                cursor = Math.min(max, cursor + 1);
            } else if (ch == 'k' || ch == 'h' || ch == 'N') {
                cursor = Math.max(0, cursor - 1);
            } else if (ch == 'g') {
                cursor = 0;
            } else if (ch == 'G') {
                cursor = max;
            } else if (ch == 'f') {
                cursor = Math.min(max, cursor + 10);
            } else if (ch == 'b') {
                cursor = Math.max(0, cursor - 10);
            } else if (ch == 27) {
                try {
                    while (System.in.available() > 0) {
                        System.in.read();
                    }
                } catch (IOException ignored) {
                }
            }
            if (cursor < offset) {
                offset = cursor;
            } else if (cursor >= offset + 20) {
                offset = cursor - 19;
            }
        }

        private void draw() {
            StringBuilder sb = new StringBuilder();
            sb.append("\033[2J\033[H");
            sb.append("flamelens");
            if (sorted) {
                sb.append(" --sorted");
            }
            sb.append("    q: quit  arrows/hjkl: navigate\n");
            long total = Math.max(1, profile.root.value);
            sb.append("Total: ").append(profile.root.value).append(" samples");
            if (debug) {
                sb.append("    frames: ").append(profile.frames.size());
            }
            sb.append("\n\n");
            if (profile.frames.isEmpty()) {
                sb.append("No folded stack samples loaded.\n");
            } else {
                int end = Math.min(profile.frames.size(), offset + 20);
                for (int i = offset; i < end; i++) {
                    Frame f = profile.frames.get(i);
                    int width = (int) Math.max(1, Math.min(40, (f.value * 40) / total));
                    sb.append(i == cursor ? "> " : "  ");
                    sb.append(" ".repeat(Math.max(0, (f.depth - 1) * 2)));
                    sb.append(f.name).append(" ");
                    sb.append("[").append("#".repeat(width)).append(" ".repeat(40 - width)).append("] ");
                    sb.append(f.value).append('\n');
                }
            }
            System.out.print(sb);
            System.out.flush();
        }
    }

    private static final class Terminal {
        static void enter() throws IOException {
            runShell("stty raw -echo < /dev/tty");
            System.out.print("\033[?1049h\033[?25l");
            System.out.flush();
        }

        static void leave() throws IOException {
            System.out.print("\033[?1049l\033[?1006l\033[?1015l\033[?1003l\033[?1002l\033[?1000l\033[?25h");
            System.out.flush();
            runShell("stty sane < /dev/tty");
        }

        private static void runShell(String command) throws IOException {
            try {
                Process process = new ProcessBuilder("bash", "-lc", command)
                        .redirectError(ProcessBuilder.Redirect.DISCARD)
                        .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                        .start();
                try {
                    process.waitFor();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IOException(e);
                }
            } catch (IOException ignored) {
                // A best-effort terminal mode change is enough; the viewer still works without it.
            }
        }
    }
}
