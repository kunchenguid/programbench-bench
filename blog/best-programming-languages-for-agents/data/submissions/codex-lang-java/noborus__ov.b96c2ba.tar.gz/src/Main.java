import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {
    private static final String VERSION = "ov version dev rev:HEAD\n";

    private static final String HELP = """
ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
""";

    private static final String HELP_KEY = """
ov is a feature rich pager
 Key                            Action

\tGeneral
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

\tMoving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right
 [ctrl+left]                    * scroll left half screen
 [ctrl+right]                   * scroll right half screen
 [alt+left]                     * scroll left specified width
 [alt+right]                    * scroll right specified width
 [shift+Home]                   * go to beginning of line
 [shift+End]                    * go to end of line
 [g]                            * go to line(input number or `.n` or `n%` allowed)
 [,]                            * go to mark number(input number allowed)

\tSidebar
 [alt+h]                        * show/hide help in sidebar
 [alt+m]                        * show mark list in sidebar
 [alt+l]                        * show document list in sidebar
 [shift+Up]                     * scroll up in sidebar
 [shift+Down]                   * scroll down in sidebar
 [shift+Left]                   * scroll left in sidebar
 [shift+Right]                  * scroll right in sidebar

\tMove document
 []]                            * next document
 [[]                            * previous document
 [ctrl+k]                       * close current document
 [K]                            * close all filtered documents

\tMark position
 [m]                            * mark current position
 [M]                            * remove mark current position
 [ctrl+delete]                  * remove all mark
 [>]                            * move to next marked position
 [<]                            * move to previous marked position
 [*]                            * mark by pattern mode

\tSearch
 [/]                            * forward search mode
 [?]                            * backward search mode
 [n]                            * repeat forward search
 [N]                            * repeat backward search
 [&]                            * filter search mode

\tChange display
 [w], [W]                       * wrap/nowrap toggle
 [c]                            * column mode toggle
 [alt+o]                        * column width toggle
 [ctrl+r]                       * column rainbow toggle
 [C]                            * alternate rows of style toggle
 [G]                            * line number toggle
 [ctrl+e]                       * original decoration toggle(plain)
 [alt+f]                        * align columns
 [alt+r]                        * raw output
 [alt+shift+F9]                 * ruler toggle

\tInput
 [Up]                           * previous candidate
 [Down]                         * next candidate
 [ctrl+c]                       * copy to clipboard
 [ctrl+v]                       * paste from clipboard

""";

    private static final String[] FLAGS = {
            "--align", "--alternate-rows", "--caption", "--case-sensitive", "--column-delimiter",
            "--column-mode", "--column-rainbow", "--column-width", "--completion", "--config",
            "--converter", "--debug", "--disable-column-cycle", "--disable-mouse", "--exec",
            "--exit-write", "--exit-write-after", "--exit-write-before", "--filter", "--follow-all",
            "--follow-mode", "--follow-name", "--follow-section", "--force-screen", "--header",
            "--header-column", "--help", "--help-key", "--hide-other-section", "--hscroll-width",
            "--incsearch", "--jump-target", "--line-number", "--list-view-modes", "--memory-limit",
            "--memory-limit-file", "--multi-color", "--non-match-filter", "--notify-eof", "--pattern",
            "--plain", "--quit-if-one-screen", "--raw", "--regexp-search", "--ruler",
            "--section-delimiter", "--section-header", "--section-header-num", "--section-start",
            "--set-terminal-title", "--skip-extract", "--skip-lines", "--smart-case-sensitive",
            "--status-line", "--tab-width", "--version", "--vertical-header", "--view-mode",
            "--watch", "--wrap"
    };

    private static final Map<Character, String> SHORT = new HashMap<>();
    private static final Set<String> NEEDS_VALUE = new HashSet<>();
    private static final Set<String> OPTIONAL_BOOL = Set.of("--incsearch", "--status-line", "--wrap");
    private static final Set<String> INT_FLAGS = Set.of("--exit-write-after", "--exit-write-before",
            "--header", "--header-column", "--memory-limit", "--memory-limit-file", "--notify-eof",
            "--ruler", "--section-header-num", "--section-start", "--skip-lines", "--tab-width",
            "--vertical-header");

    static {
        SHORT.put('l', "--align");
        SHORT.put('C', "--alternate-rows");
        SHORT.put('i', "--case-sensitive");
        SHORT.put('d', "--column-delimiter");
        SHORT.put('c', "--column-mode");
        SHORT.put('e', "--exec");
        SHORT.put('X', "--exit-write");
        SHORT.put('a', "--exit-write-after");
        SHORT.put('b', "--exit-write-before");
        SHORT.put('A', "--follow-all");
        SHORT.put('f', "--follow-mode");
        SHORT.put('H', "--header");
        SHORT.put('Y', "--header-column");
        SHORT.put('h', "--help");
        SHORT.put('j', "--jump-target");
        SHORT.put('n', "--line-number");
        SHORT.put('M', "--multi-color");
        SHORT.put('p', "--plain");
        SHORT.put('F', "--quit-if-one-screen");
        SHORT.put('r', "--raw");
        SHORT.put('x', "--tab-width");
        SHORT.put('v', "--version");
        SHORT.put('y', "--vertical-header");
        SHORT.put('m', "--view-mode");
        SHORT.put('T', "--watch");
        SHORT.put('w', "--wrap");

        String[] valueFlags = {"--caption", "--column-delimiter", "--completion", "--config", "--converter",
                "--exit-write-after", "--exit-write-before", "--filter", "--header", "--header-column",
                "--hscroll-width", "--jump-target", "--memory-limit", "--memory-limit-file", "--multi-color",
                "--non-match-filter", "--notify-eof", "--pattern", "--ruler", "--section-delimiter",
                "--section-header-num", "--section-start", "--skip-lines", "--tab-width",
                "--vertical-header", "--view-mode", "--watch"};
        for (String f : valueFlags) NEEDS_VALUE.add(f);
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) System.exit(code);
        } catch (BrokenPipe ignored) {
            System.exit(141);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static int run(String[] args) throws Exception {
        if (args.length > 0 && (args[0].equals("__complete") || args[0].equals("__completeNoDesc"))) {
            complete(args[0].equals("__completeNoDesc"));
            return 0;
        }

        List<String> files = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                for (int j = i + 1; j < args.length; j++) files.add(args[j]);
                break;
            } else if (a.startsWith("--")) {
                String name = a;
                String value = null;
                int eq = a.indexOf('=');
                if (eq >= 0) {
                    name = a.substring(0, eq);
                    value = a.substring(eq + 1);
                }
                if (!isLongFlag(name)) return error("unknown flag: " + name);
                if (name.equals("--help")) {
                    System.out.print(HELP);
                    return 0;
                }
                if (name.equals("--version")) {
                    System.out.print(VERSION);
                    return 0;
                }
                if (name.equals("--help-key")) {
                    System.out.print(HELP_KEY);
                    return 0;
                }
                if (name.equals("--list-view-modes")) {
                    System.out.println("general");
                    return 0;
                }
                if (name.equals("--completion")) {
                    if (value == null) {
                        if (i + 1 >= args.length) return error("flag needs an argument: --completion");
                        value = args[++i];
                    }
                    return completionScript(value);
                }
                if (NEEDS_VALUE.contains(name)) {
                    if (value == null) {
                        if (i + 1 >= args.length) return error("flag needs an argument: " + name);
                        value = args[++i];
                    }
                    validateValue(name, value, longDisplay(name));
                } else if (OPTIONAL_BOOL.contains(name)) {
                    if (value != null && !(value.equals("true") || value.equals("false"))) {
                        return error("invalid argument \"" + value + "\" for \"" + longDisplay(name) + "\" flag: strconv.ParseBool: parsing \"" + value + "\": invalid syntax");
                    }
                }
            } else if (a.startsWith("-") && a.length() > 1) {
                if (a.length() > 2 && !a.substring(2).startsWith("=")) {
                    for (int k = 1; k < a.length(); k++) {
                        String lf = SHORT.get(a.charAt(k));
                        if (lf == null) return error("unknown shorthand flag: '" + a.charAt(k) + "' in " + a);
                        if (NEEDS_VALUE.contains(lf) || OPTIONAL_BOOL.contains(lf)) {
                            return error("flag needs an argument: '" + a.charAt(k) + "' in " + a);
                        }
                        if (lf.equals("--help")) { System.out.print(HELP); return 0; }
                        if (lf.equals("--version")) { System.out.print(VERSION); return 0; }
                    }
                } else {
                    char c = a.charAt(1);
                    String lf = SHORT.get(c);
                    if (lf == null) return error("unknown shorthand flag: '" + c + "' in " + a);
                    String value = null;
                    int eq = a.indexOf('=');
                    if (eq >= 0) value = a.substring(eq + 1);
                    if (lf.equals("--help")) { System.out.print(HELP); return 0; }
                    if (lf.equals("--version")) { System.out.print(VERSION); return 0; }
                    if (NEEDS_VALUE.contains(lf)) {
                        if (value == null) {
                            if (i + 1 >= args.length) return error("flag needs an argument: '" + c + "' in -" + c);
                            value = args[++i];
                        }
                        validateValue(lf, value, shortDisplay(c, lf));
                    } else if (OPTIONAL_BOOL.contains(lf) && value != null && !(value.equals("true") || value.equals("false"))) {
                        return error("invalid argument \"" + value + "\" for \"" + shortDisplay(c, lf) + "\" flag: strconv.ParseBool: parsing \"" + value + "\": invalid syntax");
                    }
                }
            } else {
                files.add(a);
            }
        }

        if (files.isEmpty()) {
            copy(System.in, System.out);
        } else {
            copyFile(files.get(0));
        }
        return 0;
    }

    private static boolean isLongFlag(String s) {
        for (String f : FLAGS) if (f.equals(s)) return true;
        return false;
    }

    private static void validateValue(String flag, String value, String display) throws Exception {
        if (INT_FLAGS.contains(flag)) {
            try {
                Long.parseLong(value);
            } catch (NumberFormatException e) {
                returnParseError(value, display);
            }
        }
    }

    private static void returnParseError(String value, String display) throws Exception {
        throw new Exception("invalid argument \"" + value + "\" for \"" + display + "\" flag: strconv.ParseInt: parsing \"" + value + "\": invalid syntax");
    }

    private static String longDisplay(String flag) {
        return switch (flag) {
            case "--tab-width" -> "-x, --tab-width";
            case "--header" -> "-H, --header";
            case "--view-mode" -> "-m, --view-mode";
            case "--watch" -> "-T, --watch";
            default -> flag;
        };
    }

    private static String shortDisplay(char c, String longFlag) {
        return "-" + c + ", " + longFlag;
    }

    private static int error(String msg) {
        System.err.println("Error: " + msg);
        return 1;
    }

    private static void copyFile(String file) throws Exception {
        Path p = Path.of(file);
        if (!Files.exists(p)) {
            throw new Exception("open " + file + ": no such file or directory");
        }
        try (InputStream in = new BufferedInputStream(Files.newInputStream(p))) {
            copy(in, System.out);
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[8192];
        int n;
        try {
            while ((n = in.read(buf)) >= 0) {
                out.write(buf, 0, n);
            }
            out.flush();
        } catch (IOException e) {
            throw new BrokenPipe();
        }
    }

    private static void complete(boolean noDesc) {
        String[][] desc = {
                {"--align", "align the output columns for better readability"},
                {"--alternate-rows", "alternately change the line color"},
                {"--caption", "custom caption"},
                {"--case-sensitive", "case-sensitive in search"},
                {"--column-delimiter", "column delimiter `character`"},
                {"--column-mode", "column mode"},
                {"--column-rainbow", "column mode to rainbow"},
                {"--column-width", "column mode for width"},
                {"--completion", "generate completion script [bash|zsh|fish|powershell]"},
                {"--config", "config `file` (default is $XDG_CONFIG_HOME/ov/config.yaml)"},
                {"--converter", "converter [es|raw|align]"},
                {"--debug", "debug mode"},
                {"--disable-column-cycle", "disable column cycling"},
                {"--disable-mouse", "disable mouse support"},
                {"--exec", "command execution result instead of file"},
                {"--exit-write", "output the current screen when exiting"},
                {"--exit-write-after", "number after the current lines when exiting"},
                {"--exit-write-before", "number before the current lines when exiting"},
                {"--filter", "filter search pattern"},
                {"--follow-all", "follow multiple files and show the most recently updated one"},
                {"--follow-mode", "monitor file and display new content as it is written"},
                {"--follow-name", "follow mode to monitor by file name"},
                {"--follow-section", "section-by-section follow mode"},
                {"--force-screen", "display screen even when redirecting output"},
                {"--header", "number of header lines to be displayed constantly"},
                {"--header-column", "number of columns to display as a vertical header"},
                {"--help", "help for ov"},
                {"--help-key", "display key bind information"},
                {"--hide-other-section", "hide other section"},
                {"--hscroll-width", "width to scroll horizontally `[int|int%|.int]`"},
                {"--incsearch", "incremental search"},
                {"--jump-target", "jump target `[int|int%|.int|'section']`"},
                {"--line-number", "line number mode"},
                {"--list-view-modes", "list available view modes defined in the configuration file"},
                {"--memory-limit", "number of chunks to limit in memory"},
                {"--memory-limit-file", "number of chunks to limit in memory for the file"},
                {"--multi-color", "comma separated words(regexp) to color .e.g. \"ERROR,WARNING\""},
                {"--non-match-filter", "filter non match search pattern"},
                {"--notify-eof", "notify at the end of the file"},
                {"--pattern", "search pattern"},
                {"--plain", "disable original decoration"},
                {"--quit-if-one-screen", "quit if the output fits on one screen"},
                {"--raw", "raw escape sequences without processing"},
                {"--regexp-search", "regular expression search"},
                {"--ruler", "display ruler (=0: none, =1: relative, =2: absolute)"},
                {"--section-delimiter", "`regexp` for section delimiter .e.g. \"^#\""},
                {"--section-header", "enable section-delimiter line as Header"},
                {"--section-header-num", "number of section header lines"},
                {"--section-start", "section start position"},
                {"--set-terminal-title", "set terminal title"},
                {"--skip-extract", "skip extracting compressed files"},
                {"--skip-lines", "skip the number of lines"},
                {"--smart-case-sensitive", "smart case-sensitive in search"},
                {"--status-line", "status line"},
                {"--tab-width", "tab stop width"},
                {"--version", "display version information"},
                {"--vertical-header", "number of characters to display as a vertical header"},
                {"--view-mode", "apply predefined settings for a specific mode"},
                {"--watch", "watch mode interval(`seconds`)"},
                {"--wrap", "wrap mode"}
        };
        for (String[] d : desc) {
            System.out.println(noDesc ? d[0] : d[0] + "\t" + d[1]);
        }
        System.out.println(":4");
    }

    private static int completionScript(String shell) {
        switch (shell) {
            case "bash" -> System.out.print("# bash completion for ov                                   -*- shell-script -*-\ncomplete -o default -F _ov ov\n");
            case "zsh" -> System.out.print("#compdef ov\ncompdef _ov ov\n\n# zsh completion for ov                                   -*- shell-script -*-\n");
            case "fish" -> System.out.print("# fish completion for ov                                   -*- shell-script -*-\ncomplete -c ov -f\n");
            case "powershell" -> System.out.print("# powershell completion for ov                                   -*- shell-script -*-\n");
            default -> {
                return error("requires one of the arguments bash/zsh/fish/powershell");
            }
        }
        return 0;
    }

    private static class BrokenPipe extends IOException {
    }
}
