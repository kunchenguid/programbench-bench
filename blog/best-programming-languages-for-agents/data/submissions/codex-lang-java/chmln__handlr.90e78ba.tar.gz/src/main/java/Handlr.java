import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Handlr {
    static final String VERSION = "handlr 0.6.4";

    static class Desktop {
        String id, name = "", exec = "";
        Set<String> mimes = new LinkedHashSet<>();
        boolean hidden = false;
    }

    static class Config {
        LinkedHashMap<String, List<String>> defaults = new LinkedHashMap<>();
        LinkedHashMap<String, List<String>> added = new LinkedHashMap<>();
    }

    public static void main(String[] args) {
        try {
            ensureConfig();
            int code = run(args);
            System.exit(code);
        } catch (UsageException e) {
            System.err.println(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length == 0 || eq(args[0], "-h", "--help")) {
            System.out.print(mainHelp());
            return args.length == 0 ? 2 : 0;
        }
        if (eq(args[0], "-V", "--version")) {
            System.out.println(VERSION);
            return 0;
        }
        String cmd = args[0];
        String[] rest = Arrays.copyOfRange(args, 1, args.length);
        if (rest.length > 0 && eq(rest[0], "-h", "--help")) {
            System.out.print(helpFor(cmd));
            return 0;
        }
        if (rest.length > 0 && eq(rest[0], "-V", "--version")) {
            System.out.println(VERSION);
            return 0;
        }
        switch (cmd) {
            case "get": return get(rest);
            case "set": return set(rest, true);
            case "add": return set(rest, false);
            case "unset": return unset(rest);
            case "list": return list(rest);
            case "launch": return launch(rest);
            case "open": return open(rest);
            default:
                throw new UsageException("error: Found argument '" + cmd + "' which wasn't expected, or isn't valid in this context\n\nIf you tried to supply `" + cmd + "` as a PATTERN use `-- " + cmd + "`\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help");
        }
    }

    static int get(String[] args) throws Exception {
        boolean json = false;
        List<String> pos = new ArrayList<>();
        for (String a : args) {
            if (a.equals("--json")) json = true;
            else if (a.startsWith("-")) throw badArg("get", a, "[FLAGS] <mime>");
            else pos.add(a);
        }
        if (pos.isEmpty()) throw missing("get", "<mime>", "[FLAGS] <mime>");
        if (pos.size() > 1) throw badArg("get", pos.get(1), "[FLAGS] <mime>");
        String mime = normalizeMime(pos.get(0));
        Handler h = findHandler(mime);
        if (h == null) return 1;
        if (json) {
            System.out.println("{\"handler\":\"" + js(h.id) + "\",\"name\":\"" + js(h.name) + "\",\"cmd\":\"" + js(cleanExec(h.exec)) + "\"}");
        } else {
            System.out.println(h.id);
        }
        return 0;
    }

    static int set(String[] args, boolean replace) throws Exception {
        if (args.length == 0) throw missing(replace ? "set" : "add", "<mime>", "<mime> <handler>");
        if (args.length == 1) throw missing(replace ? "set" : "add", "<handler>", "<mime> <handler>");
        if (args.length > 2) throw badArg(replace ? "set" : "add", args[2], "<mime> <handler>");
        String mime = normalizeMime(args[0]);
        String handler = args[1];
        Map<String, Desktop> apps = readDesktops();
        Desktop d = apps.get(handler);
        if (d == null) throw new UsageException("error: Invalid value for '<handler>': no handlers found for '" + handler + "'\n\nFor more information try --help");
        Config c = readConfig();
        if (replace) {
            c.defaults.put(mime, new ArrayList<>(Collections.singletonList(handler)));
        } else {
            List<String> list = c.defaults.computeIfAbsent(mime, k -> new ArrayList<>());
            list.remove(handler);
            list.add(handler);
        }
        writeConfig(c);
        return 0;
    }

    static int unset(String[] args) throws Exception {
        if (args.length == 0) throw missing("unset", "<mime>", "<mime>");
        if (args.length > 1) throw badArg("unset", args[1], "<mime>");
        String mime = normalizeMime(args[0]);
        Config c = readConfig();
        c.defaults.remove(mime);
        writeConfig(c);
        return 0;
    }

    static int list(String[] args) throws Exception {
        boolean all = false;
        for (String a : args) {
            if (a.equals("-a") || a.equals("--all")) all = true;
            else throw badArg("list", a, "[FLAGS]");
        }
        Config c = readConfig();
        Map<String, Desktop> apps = readDesktops();
        if (all) {
            System.out.println("Default Apps");
            printTable(c.defaults);
            System.out.println("System Apps");
            printTable(systemAssociations(apps));
        } else {
            printTable(c.defaults);
        }
        return 0;
    }

    static int launch(String[] args) throws Exception {
        if (args.length == 0) throw missing("launch", "<mime>", "<mime> [args]...");
        String mime = normalizeMime(args[0]);
        Handler h = findHandler(mime);
        if (h == null) return 1;
        List<String> extra = new ArrayList<>();
        for (int i = 1; i < args.length; i++) if (!args[i].equals("--")) extra.add(args[i]);
        return spawn(h.exec, h.name, extra);
    }

    static int open(String[] args) throws Exception {
        if (args.length == 0) throw missing("open", "<paths>...", "<paths>...");
        int status = 0;
        for (String p : args) {
            String mime = p.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*") ? "x-scheme-handler/" + p.substring(0, p.indexOf(':')) : normalizeMime(p);
            Handler h = findHandler(mime);
            if (h == null) status = 1;
            else status = Math.max(status, spawn(h.exec, h.name, Collections.singletonList(p)));
        }
        return status;
    }

    static class Handler { String id, name, exec; }

    static Handler findHandler(String mime) throws IOException {
        Config c = readConfig();
        Map<String, Desktop> apps = readDesktops();
        List<String> ids = c.defaults.get(mime);
        if (ids != null) for (String id : ids) if (apps.containsKey(id)) return handler(id, apps.get(id));
        int slash = mime.indexOf('/');
        if (slash > 0) {
            String wild = mime.substring(0, slash) + "/*";
            ids = c.defaults.get(wild);
            if (ids != null) for (String id : ids) if (apps.containsKey(id)) return handler(id, apps.get(id));
        }
        for (Desktop d : apps.values()) if (d.mimes.contains(mime)) return handler(d.id, d);
        return null;
    }

    static Handler handler(String id, Desktop d) {
        Handler h = new Handler();
        h.id = id; h.name = d.name; h.exec = d.exec;
        return h;
    }

    static LinkedHashMap<String, List<String>> systemAssociations(Map<String, Desktop> apps) {
        TreeMap<String, List<String>> sorted = new TreeMap<>();
        List<Desktop> ds = new ArrayList<>(apps.values());
        ds.sort(Comparator.comparing(d -> d.id));
        for (Desktop d : ds) for (String m : d.mimes) sorted.computeIfAbsent(m, k -> new ArrayList<>()).add(d.id);
        return new LinkedHashMap<>(sorted);
    }

    static Map<String, Desktop> readDesktops() throws IOException {
        LinkedHashMap<String, Desktop> out = new LinkedHashMap<>();
        List<Path> dirs = new ArrayList<>();
        String xdgData = getenv("XDG_DATA_HOME", home() + "/.local/share");
        dirs.add(Paths.get(xdgData, "applications"));
        for (String base : getenv("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")) dirs.add(Paths.get(base, "applications"));
        for (Path dir : dirs) {
            if (!Files.isDirectory(dir)) continue;
            try (var stream = Files.walk(dir)) {
                List<Path> files = new ArrayList<>();
                stream.filter(p -> p.toString().endsWith(".desktop")).forEach(files::add);
                files.sort(Comparator.comparing(Path::toString));
                for (Path p : files) {
                    Desktop d = parseDesktop(p, dir);
                    if (d != null && !out.containsKey(d.id)) out.put(d.id, d);
                }
            }
        }
        return out;
    }

    static Desktop parseDesktop(Path p, Path root) {
        try {
            Desktop d = new Desktop();
            d.id = root.relativize(p).toString().replace(File.separatorChar, '-');
            boolean in = false;
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                line = line.trim();
                if (line.equals("[Desktop Entry]")) { in = true; continue; }
                if (line.startsWith("[") && line.endsWith("]")) { in = false; continue; }
                if (!in || line.isEmpty() || line.startsWith("#") || !line.contains("=")) continue;
                int ix = line.indexOf('=');
                String k = line.substring(0, ix), v = line.substring(ix + 1);
                if (k.equals("Name")) d.name = v;
                else if (k.equals("Exec")) d.exec = v;
                else if (k.equals("Hidden") && v.equalsIgnoreCase("true")) d.hidden = true;
                else if (k.equals("MimeType")) for (String m : v.split(";")) if (!m.isEmpty()) d.mimes.add(m);
            }
            if (d.hidden || d.exec.isEmpty()) return null;
            return d;
        } catch (Exception e) { return null; }
    }

    static Config readConfig() throws IOException {
        Config c = new Config();
        Path p = mimeapps();
        if (!Files.exists(p)) return c;
        String section = "";
        for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
            line = line.trim();
            if (line.startsWith("[") && line.endsWith("]")) { section = line; continue; }
            if (line.isEmpty() || line.startsWith("#") || !line.contains("=")) continue;
            int ix = line.indexOf('=');
            String key = line.substring(0, ix), val = line.substring(ix + 1);
            List<String> ids = parseList(val);
            if (section.equals("[Default Applications]")) c.defaults.put(key, ids);
            else if (section.equals("[Added Associations]")) c.added.put(key, ids);
        }
        return c;
    }

    static List<String> parseList(String v) {
        ArrayList<String> l = new ArrayList<>();
        for (String s : v.split(";")) if (!s.isEmpty()) l.add(s);
        return l;
    }

    static void writeConfig(Config c) throws IOException {
        Files.createDirectories(mimeapps().getParent());
        StringBuilder sb = new StringBuilder();
        sb.append("[Added Associations]\n\n[Default Applications]\n");
        for (Map.Entry<String, List<String>> e : c.defaults.entrySet()) {
            if (e.getValue().isEmpty()) continue;
            sb.append(e.getKey()).append("=").append(String.join(";", e.getValue())).append(";\n");
        }
        Files.writeString(mimeapps(), sb.toString(), StandardCharsets.UTF_8);
    }

    static void ensureConfig() throws IOException {
        Path h = Paths.get(configHome(), "handlr");
        Files.createDirectories(h);
        Path toml = h.resolve("handlr.toml");
        if (!Files.exists(toml)) Files.writeString(toml, "enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n", StandardCharsets.UTF_8);
        Files.createDirectories(mimeapps().getParent());
        if (!Files.exists(mimeapps())) Files.writeString(mimeapps(), "", StandardCharsets.UTF_8);
    }

    static String normalizeMime(String in) throws UsageException {
        if (in.matches("^[A-Za-z0-9.+-]+/[A-Za-z0-9.+*-]+$")) return in;
        String name = in;
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        if (slash >= 0) name = name.substring(slash + 1);
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot < name.length() - 1) {
            String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
            String m = mimeByExt(ext);
            if (m != null) return m;
            throw new UsageException("error: Invalid value for '<mime>': could not figure out the mime type of '." + ext + "'\n\nFor more information try --help");
        }
        if (in.contains("/")) throw new UsageException("error: Invalid value for '<mime>': mime parse error: an invalid token was encountered, 2F at position 0\n\nFor more information try --help");
        throw new UsageException("error: Invalid value for '<mime>': mime parse error: a slash (/) was missing between the type and subtype\n\nFor more information try --help");
    }

    static String mimeByExt(String e) {
        return switch (e) {
            case "txt", "text", "log", "md", "rs", "c", "h", "java", "py", "sh", "csv" -> "text/plain";
            case "html", "htm" -> "text/html";
            case "json" -> "application/json";
            case "pdf" -> "application/pdf";
            case "png" -> "image/png";
            case "jpg", "jpeg" -> "image/jpeg";
            case "gif" -> "image/gif";
            case "svg" -> "image/svg+xml";
            case "mp3" -> "audio/mpeg";
            case "ogg" -> "audio/ogg";
            case "mp4" -> "video/mp4";
            default -> null;
        };
    }

    static int spawn(String exec, String name, List<String> args) {
        try {
            List<String> cmd = shellWords(expandExec(exec, name, args));
            if (cmd.isEmpty()) return 1;
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
            pb.redirectError(ProcessBuilder.Redirect.DISCARD);
            pb.start();
            return 0;
        } catch (Exception e) { return 1; }
    }

    static String expandExec(String exec, String name, List<String> args) {
        String joined = String.join(" ", args);
        return exec.replace("%f", joined).replace("%F", joined).replace("%u", joined).replace("%U", joined)
                .replace("%c", name).replace("%%", "%").replaceAll("%[ik]", "");
    }

    static String cleanExec(String exec) {
        String s = exec.replaceAll("\\s*%[fFuU]", "");
        return s.trim().replaceAll("\\s+", " ");
    }

    static List<String> shellWords(String s) {
        ArrayList<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean sq = false, dq = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\'' && !dq) { sq = !sq; continue; }
            if (ch == '"' && !sq) { dq = !dq; continue; }
            if (Character.isWhitespace(ch) && !sq && !dq) {
                if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
            } else cur.append(ch);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    static void printTable(Map<String, List<String>> map) {
        List<Map.Entry<String, List<String>>> rows = new ArrayList<>(map.entrySet());
        rows.removeIf(e -> e.getValue() == null || e.getValue().isEmpty());
        if (rows.isEmpty()) { System.out.println("┌──┐\n│  │\n└──┘"); return; }
        int w1 = 0, w2 = 0;
        for (var e : rows) { w1 = Math.max(w1, e.getKey().length()); w2 = Math.max(w2, String.join(", ", e.getValue()).length()); }
        System.out.println("┌" + rep("─", w1 + 2) + "┬" + rep("─", w2 + 2) + "┐");
        for (var e : rows) System.out.printf("│ %-" + w1 + "s │ %-" + w2 + "s │%n", e.getKey(), String.join(", ", e.getValue()));
        System.out.println("└" + rep("─", w1 + 2) + "┴" + rep("─", w2 + 2) + "┘");
    }

    static String rep(String s, int n) { return s.repeat(Math.max(0, n)); }
    static boolean eq(String s, String... xs) { for (String x : xs) if (s.equals(x)) return true; return false; }
    static String home() { return getenv("HOME", System.getProperty("user.home", ".")); }
    static String configHome() { return getenv("XDG_CONFIG_HOME", home() + "/.config"); }
    static Path mimeapps() { return Paths.get(configHome(), "mimeapps.list"); }
    static String getenv(String k, String d) { String v = System.getenv(k); return v == null || v.isEmpty() ? d : v; }
    static String js(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

    static UsageException missing(String cmd, String arg, String usage) {
        return new UsageException("error: The following required arguments were not provided:\n    " + arg + "\n\nUSAGE:\n    executable " + cmd + " " + usage + "\n\nFor more information try --help");
    }
    static UsageException badArg(String cmd, String arg, String usage) {
        return new UsageException("error: Found argument '" + arg + "' which wasn't expected, or isn't valid in this context\n\nIf you tried to supply `" + arg + "` as a PATTERN use `-- " + arg + "`\n\nUSAGE:\n    executable " + cmd + " " + usage + "\n\nFor more information try --help");
    }
    static class UsageException extends Exception { UsageException(String m) { super(m); } }

    static String mainHelp() {
        return VERSION + "\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    list      List default apps and the associated handlers\n    open      Open a path/URL with its default handler\n    set       Set the default handler for mime/extension\n    unset     Unset the default handler for mime/extension\n    launch    Launch the handler for specified extension/mime with optional arguments\n    get       Get handler for this mime/extension\n    add       Add a handler for given mime/extension Note that the first handler is the default\n";
    }
    static String helpFor(String cmd) {
        return switch (cmd) {
            case "get" -> "executable-get \nGet handler for this mime/extension\n\nUSAGE:\n    executable get [FLAGS] <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n        --json       \n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            case "set" -> "executable-set \nSet the default handler for mime/extension\n\nUSAGE:\n    executable set <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            case "add" -> "executable-add \nAdd a handler for given mime/extension Note that the first handler is the default\n\nUSAGE:\n    executable add <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            case "list" -> "executable-list \nList default apps and the associated handlers\n\nUSAGE:\n    executable list [FLAGS]\n\nFLAGS:\n    -a, --all        \n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            case "open" -> "executable-open \nOpen a path/URL with its default handler\n\nUSAGE:\n    executable open <paths>...\n\nARGS:\n    <paths>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            case "launch" -> "executable-launch \nLaunch the handler for specified extension/mime with optional arguments\n\nUSAGE:\n    executable launch <mime> [args]...\n\nARGS:\n    <mime>       \n    <args>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            case "unset" -> "executable-unset \nUnset the default handler for mime/extension\n\nUSAGE:\n    executable unset <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n";
            default -> mainHelp();
        };
    }
}
