import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;

public class Main {
    static final byte[] MAGIC = {(byte)0xFD, '7', 'z', 'X', 'Z', 0};
    static final byte[] FOOTER_MAGIC = {'Y', 'Z'};
    static final long[] CRC64 = makeCrc64();

    static class Opt {
        boolean compress, decompress, test, list, keep, force, stdout, verbose, robot, quiet;
        boolean version, help, longHelp, singleStream;
        String suffix = ".xz";
        int preset = 6;
        ArrayList<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o.help) { printHelp(false); return; }
            if (o.longHelp) { printHelp(true); return; }
            if (o.version) { System.out.print("xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n"); return; }
            if (!o.compress && !o.decompress && !o.test && !o.list) o.compress = true;
            if (o.files.isEmpty()) o.files.add("-");
            int status = 0;
            for (String f : o.files) {
                try {
                    if (o.list) listFile(f, o);
                    else if (o.test) processDecompress(f, o, OutputStream.nullOutputStream(), true);
                    else if (o.decompress) decompressFile(f, o);
                    else compressFile(f, o);
                } catch (Exception e) {
                    status = 1;
                    if (!o.quiet) System.err.println("./executable: " + e.getMessage());
                }
            }
            if (status != 0) System.exit(status);
        } catch (BadOption e) {
            System.err.println("./executable: " + e.getMessage());
            System.err.println("./executable: Try './executable --help' for more information.");
            System.exit(1);
        } catch (Exception e) {
            System.err.println("./executable: " + e.getMessage());
            System.exit(1);
        }
    }

    static class BadOption extends Exception { BadOption(String s) { super(s); } }

    static Opt parse(String[] args) throws Exception {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                while (++i < args.length) o.files.add(args[i]);
                break;
            } else if (a.startsWith("--")) {
                String name = a, val = null;
                int eq = a.indexOf('=');
                if (eq >= 0) { name = a.substring(0, eq); val = a.substring(eq + 1); }
                switch (name) {
                    case "--compress": o.compress = true; o.decompress = o.test = o.list = false; break;
                    case "--decompress": o.decompress = true; o.compress = o.test = o.list = false; break;
                    case "--test": o.test = true; o.compress = o.decompress = o.list = false; break;
                    case "--list": o.list = true; o.compress = o.decompress = o.test = false; break;
                    case "--keep": o.keep = true; break;
                    case "--force": o.force = true; break;
                    case "--stdout": o.stdout = true; o.keep = true; break;
                    case "--quiet": o.quiet = true; break;
                    case "--verbose": o.verbose = true; break;
                    case "--robot": o.robot = true; break;
                    case "--single-stream": o.singleStream = true; break;
                    case "--help": o.help = true; break;
                    case "--long-help": o.longHelp = true; break;
                    case "--version": o.version = true; break;
                    case "--suffix": o.suffix = needValue(args, ++i, val, name); break;
                    case "--threads": case "--format": case "--check": case "--memlimit":
                    case "--memlimit-compress": case "--memlimit-decompress":
                    case "--memlimit-mt-decompress": case "--block-size":
                    case "--block-list": case "--flush-timeout": case "--filters":
                    case "--filters1": case "--filters2": case "--filters3": case "--filters4":
                    case "--filters5": case "--filters6": case "--filters7": case "--filters8":
                    case "--filters9": case "--lzma1": case "--lzma2": case "--x86":
                    case "--arm": case "--armthumb": case "--arm64": case "--powerpc":
                    case "--ia64": case "--sparc": case "--riscv": case "--delta":
                        if (val == null && optionNeedsValue(name)) i++;
                        break;
                    case "--no-sync": case "--no-sparse": case "--ignore-check":
                    case "--no-adjust": case "--no-warn": break;
                    case "--info-memory":
                        System.out.print("Total amount of physical memory (RAM): 0 MiB\nMemory usage limits:\n  Compression:     0 MiB\n  Decompression:   0 MiB\n");
                        System.exit(0);
                    case "--filters-help":
                        System.out.print("Filter chains are accepted for compatibility, but this implementation uses LZMA2 stored chunks.\n");
                        System.exit(0);
                    default: throw new BadOption("unrecognized option '" + a + "'");
                }
            } else if (a.startsWith("-") && !a.equals("-")) {
                for (int j = 1; j < a.length(); j++) {
                    char c = a.charAt(j);
                    switch (c) {
                        case 'z': o.compress = true; o.decompress = o.test = o.list = false; break;
                        case 'd': o.decompress = true; o.compress = o.test = o.list = false; break;
                        case 't': o.test = true; o.compress = o.decompress = o.list = false; break;
                        case 'l': o.list = true; o.compress = o.decompress = o.test = false; break;
                        case 'k': o.keep = true; break;
                        case 'f': o.force = true; break;
                        case 'c': o.stdout = true; o.keep = true; break;
                        case 'q': o.quiet = true; break;
                        case 'v': o.verbose = true; break;
                        case 'h': o.help = true; break;
                        case 'H': o.longHelp = true; break;
                        case 'V': o.version = true; break;
                        case 'e': break;
                        case 'F': case 'C': case 'M': case 'S': case 'T':
                            if (j + 1 == a.length()) i++;
                            j = a.length();
                            break;
                        default:
                            if (c >= '0' && c <= '9') o.preset = c - '0';
                            else throw new BadOption("invalid option -- '" + c + "'");
                    }
                }
            } else {
                o.files.add(a);
            }
        }
        return o;
    }

    static boolean optionNeedsValue(String n) {
        return !(n.equals("--lzma1") || n.equals("--lzma2") || n.equals("--x86") || n.equals("--arm")
                || n.equals("--armthumb") || n.equals("--arm64") || n.equals("--powerpc")
                || n.equals("--ia64") || n.equals("--sparc") || n.equals("--riscv") || n.equals("--delta"));
    }

    static String needValue(String[] args, int i, String val, String name) throws BadOption {
        if (val != null) return val;
        if (i >= args.length) throw new BadOption("option '" + name + "' requires an argument");
        return args[i];
    }

    static void compressFile(String name, Opt o) throws Exception {
        InputStream in = name.equals("-") ? System.in : new BufferedInputStream(Files.newInputStream(Path.of(name)));
        if (o.stdout || name.equals("-")) {
            writeXz(in, System.out);
            if (!name.equals("-")) in.close();
            return;
        }
        Path src = Path.of(name), dst = Path.of(name + o.suffix);
        if (Files.exists(dst) && !o.force) throw new IOException(dst + ": File exists");
        try (InputStream fin = in; OutputStream out = new BufferedOutputStream(Files.newOutputStream(dst))) {
            writeXz(fin, out);
        }
        if (!o.keep) Files.delete(src);
    }

    static void decompressFile(String name, Opt o) throws Exception {
        if (o.stdout || name.equals("-")) {
            processDecompress(name, o, System.out, false);
            return;
        }
        Path src = Path.of(name);
        String outName = name.endsWith(o.suffix) ? name.substring(0, name.length() - o.suffix.length()) : name + ".out";
        Path dst = Path.of(outName);
        if (Files.exists(dst) && !o.force) throw new IOException(dst + ": File exists");
        try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(dst))) {
            processDecompress(name, o, out, false);
        }
        if (!o.keep) Files.delete(src);
    }

    static void processDecompress(String name, Opt o, OutputStream out, boolean testing) throws Exception {
        InputStream in = name.equals("-") ? System.in : new BufferedInputStream(Files.newInputStream(Path.of(name)));
        try (InputStream close = name.equals("-") ? null : in) {
            readXz(in, out);
        }
    }

    static void writeXz(InputStream in, OutputStream out) throws IOException {
        ByteArrayOutputStream raw = new ByteArrayOutputStream();
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) >= 0) raw.write(buf, 0, n);
        byte[] data = raw.toByteArray();

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        stream.write(MAGIC);
        byte[] flags = {0, 4}; // CRC64
        stream.write(flags);
        writeLe32(stream, crc32(flags));

        ByteArrayOutputStream lz = new ByteArrayOutputStream();
        int pos = 0;
        while (pos < data.length) {
            int chunk = Math.min(65536, data.length - pos);
            lz.write(pos == 0 ? 0x01 : 0x02);
            lz.write((chunk - 1) >>> 8);
            lz.write((chunk - 1) & 0xFF);
            lz.write(data, pos, chunk);
            pos += chunk;
        }
        lz.write(0);
        byte[] comp = lz.toByteArray();

        ByteArrayOutputStream header = new ByteArrayOutputStream();
        writeVar(header, comp.length);
        writeVar(header, data.length);
        header.write(0x21);
        header.write(1);
        header.write(22);
        int bodyLen = 2 + header.size();
        int pad = (4 - ((bodyLen + 4) % 4)) % 4;
        int headerSize = bodyLen + pad + 4;
        ByteArrayOutputStream blockHeader = new ByteArrayOutputStream();
        blockHeader.write(headerSize / 4 - 1);
        blockHeader.write(0xC0);
        blockHeader.write(header.toByteArray());
        for (int i = 0; i < pad; i++) blockHeader.write(0);
        byte[] bhNoCrc = blockHeader.toByteArray();
        writeLe32(blockHeader, crc32(bhNoCrc));
        stream.write(blockHeader.toByteArray());
        stream.write(comp);
        while ((stream.size() & 3) != 0) stream.write(0);
        writeLe64(stream, crc64(data));

        long unpadded = headerSize + comp.length + 8L;
        ByteArrayOutputStream index = new ByteArrayOutputStream();
        index.write(0);
        writeVar(index, 1);
        writeVar(index, unpadded);
        writeVar(index, data.length);
        while ((index.size() & 3) != 0) index.write(0);
        byte[] idx = index.toByteArray();
        stream.write(idx);
        writeLe32(stream, crc32(idx));

        ByteArrayOutputStream footer = new ByteArrayOutputStream();
        writeLe32(footer, (idx.length + 4) / 4 - 1);
        footer.write(flags);
        byte[] footNoCrc = footer.toByteArray();
        long fcrc = crc32(footNoCrc);
        writeLe32(stream, fcrc);
        stream.write(footNoCrc);
        stream.write(FOOTER_MAGIC);
        out.write(stream.toByteArray());
    }

    static void readXz(InputStream in, OutputStream out) throws IOException {
        byte[] all = in.readAllBytes();
        if (all.length < 32 || !starts(all, MAGIC)) throw new IOException("File format not recognized");
        int p = 12;
        while (p < all.length - 12) {
            int sizeByte = all[p] & 0xFF;
            if (sizeByte == 0) break;
            int hsize = (sizeByte + 1) * 4;
            if (p + hsize > all.length) throw new IOException("Compressed data is corrupt");
            int flags = all[p + 1] & 0xFF;
            int q = p + 2;
            long compSize = -1, uncompSize = -1;
            if ((flags & 0x40) != 0) { Var v = readVar(all, q); compSize = v.value; q = v.next; }
            if ((flags & 0x80) != 0) { Var v = readVar(all, q); uncompSize = v.value; q = v.next; }
            Var filter = readVar(all, q); q = filter.next;
            Var props = readVar(all, q); q = props.next + (int)props.value;
            if (filter.value != 0x21) throw new IOException("Unsupported filter chain");
            int dataStart = p + hsize;
            if (compSize < 0) throw new IOException("Unsupported .xz block without compressed size");
            if (dataStart + compSize > all.length) throw new IOException("Compressed data is corrupt");
            decodeLzma2Stored(all, dataStart, (int)compSize, out);
            p = dataStart + (int)compSize;
            while ((p & 3) != 0) p++;
            p += 8; // CRC64
        }
    }

    static void decodeLzma2Stored(byte[] b, int off, int len, OutputStream out) throws IOException {
        int p = off, end = off + len;
        while (p < end) {
            int c = b[p++] & 0xFF;
            if (c == 0) return;
            if (c == 1 || c == 2) {
                if (p + 2 > end) throw new IOException("Compressed data is corrupt");
                int size = (((b[p++] & 0xFF) << 8) | (b[p++] & 0xFF)) + 1;
                if (p + size > end) throw new IOException("Compressed data is corrupt");
                out.write(b, p, size);
                p += size;
            } else {
                throw new IOException("Unsupported compressed LZMA2 data");
            }
        }
    }

    static class Info { long streams, blocks, compressed, uncompressed; String check = "CRC64"; }

    static void listFile(String name, Opt o) throws Exception {
        if (name.equals("-")) throw new IOException("--list does not support reading from standard input");
        byte[] b = Files.readAllBytes(Path.of(name));
        Info info = parseIndexInfo(b);
        if (o.robot) {
            System.out.println("name\t" + name);
            System.out.printf(Locale.ROOT, "file\t%d\t%d\t%d\t%d\t%s\t%s\t0%n",
                    info.streams, info.blocks, info.compressed, info.uncompressed, ratio(info.compressed, info.uncompressed), info.check);
            System.out.printf(Locale.ROOT, "totals\t%d\t%d\t%d\t%d\t%s\t%s\t0\t1%n",
                    info.streams, info.blocks, info.compressed, info.uncompressed, ratio(info.compressed, info.uncompressed), info.check);
        } else if (o.verbose) {
            System.out.println(name + " (1/1)");
            System.out.printf("  Streams:           %d%n", info.streams);
            System.out.printf("  Blocks:            %d%n", info.blocks);
            System.out.printf("  Compressed size:   %s%n", human(info.compressed));
            System.out.printf("  Uncompressed size: %s%n", human(info.uncompressed));
            System.out.printf("  Ratio:             %s%n", ratio(info.compressed, info.uncompressed));
            System.out.printf("  Check:             %s%n", info.check);
            System.out.println("  Stream Padding:    0 B");
        } else {
            System.out.println("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename");
            System.out.printf(Locale.ROOT, "%5d %7d %10s %12s %6s  %-7s %s%n",
                    info.streams, info.blocks, human(info.compressed), human(info.uncompressed),
                    ratio(info.compressed, info.uncompressed), info.check, name);
        }
    }

    static Info parseIndexInfo(byte[] b) throws IOException {
        if (b.length < 32 || !starts(b, MAGIC)) throw new IOException("File format not recognized");
        long backward = getLe32(b, b.length - 8);
        int indexSize = (int)((backward + 1) * 4);
        int idxStart = b.length - 12 - indexSize;
        if (idxStart < 12 || b[idxStart] != 0) throw new IOException("Compressed data is corrupt");
        int p = idxStart + 1;
        Var count = readVar(b, p); p = count.next;
        long uncomp = 0;
        for (long i = 0; i < count.value; i++) {
            Var unpadded = readVar(b, p); p = unpadded.next;
            Var usize = readVar(b, p); p = usize.next;
            uncomp += usize.value;
        }
        Info info = new Info();
        info.streams = 1;
        info.blocks = count.value;
        info.compressed = b.length;
        info.uncompressed = uncomp;
        int check = b[7] & 0xFF;
        info.check = check == 0 ? "None" : check == 1 ? "CRC32" : check == 4 ? "CRC64" : check == 10 ? "SHA-256" : "Unknown";
        return info;
    }

    static String ratio(long c, long u) {
        if (u == 0) return "---";
        return String.format(Locale.ROOT, "%.3f", (double)c / (double)u);
    }
    static String human(long n) { return n + " B"; }

    static boolean starts(byte[] b, byte[] m) {
        if (b.length < m.length) return false;
        for (int i = 0; i < m.length; i++) if (b[i] != m[i]) return false;
        return true;
    }

    static class Var { long value; int next; Var(long v, int n) { value = v; next = n; } }
    static Var readVar(byte[] b, int p) throws IOException {
        long v = 0; int shift = 0;
        while (p < b.length) {
            int x = b[p++] & 0xFF;
            v |= (long)(x & 0x7F) << shift;
            if ((x & 0x80) == 0) return new Var(v, p);
            shift += 7;
            if (shift > 63) break;
        }
        throw new IOException("Compressed data is corrupt");
    }
    static void writeVar(OutputStream out, long v) throws IOException {
        while (v >= 0x80) { out.write((int)(v | 0x80) & 0xFF); v >>>= 7; }
        out.write((int)v);
    }
    static long crc32(byte[] b) {
        CRC32 c = new CRC32(); c.update(b); return c.getValue();
    }
    static void writeLe32(OutputStream o, long v) throws IOException {
        o.write((int)v); o.write((int)(v >>> 8)); o.write((int)(v >>> 16)); o.write((int)(v >>> 24));
    }
    static void writeLe64(OutputStream o, long v) throws IOException {
        for (int i = 0; i < 8; i++) o.write((int)(v >>> (8 * i)));
    }
    static long getLe32(byte[] b, int p) {
        return ((long)b[p] & 255) | (((long)b[p+1] & 255) << 8) | (((long)b[p+2] & 255) << 16) | (((long)b[p+3] & 255) << 24);
    }
    static long[] makeCrc64() {
        long[] t = new long[256];
        for (int i = 0; i < 256; i++) {
            long r = i;
            for (int j = 0; j < 8; j++) r = (r >>> 1) ^ ((r & 1) != 0 ? 0xC96C5795D7870F42L : 0);
            t[i] = r;
        }
        return t;
    }
    static long crc64(byte[] b) {
        long r = -1L;
        for (byte x : b) r = CRC64[((int)r ^ x) & 0xFF] ^ (r >>> 8);
        return ~r;
    }

    static void printHelp(boolean longHelp) {
        System.out.print("Usage: ./executable [OPTION]... [FILE]...\n" +
                "Compress or decompress FILEs in the .xz format.\n\n" +
                "Mandatory arguments to long options are mandatory for short options too.\n\n" +
                "  -z, --compress      force compression\n" +
                "  -d, --decompress    force decompression\n" +
                "  -t, --test          test compressed file integrity\n" +
                "  -l, --list          list information about .xz files\n" +
                "  -k, --keep          keep (don't delete) input files\n" +
                "  -f, --force         force overwrite of output file and (de)compress links\n" +
                "  -c, --stdout        write to standard output and don't delete input files\n" +
                "  -0 ... -9           compression preset; default is 6; take compressor *and*\n" +
                "                      decompressor memory usage into account before using 7-9!\n" +
                "  -e, --extreme       try to improve compression ratio by using more CPU time;\n" +
                "                      does not affect decompressor memory requirements\n" +
                "  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as\n" +
                "                      many threads as there are processor cores\n" +
                "  -q, --quiet         suppress warnings; specify twice to suppress errors too\n" +
                "  -v, --verbose       be verbose; specify twice for even more verbose\n" +
                "  -h, --help          display this short help and exit\n" +
                "  -H, --long-help     display the long help (lists also the advanced options)\n" +
                "  -V, --version       display the version number and exit\n\n" +
                "With no FILE, or when FILE is -, read standard input.\n\n" +
                "Report bugs to <xz@tukaani.org> (in English or Finnish).\n" +
                "XZ Utils home page: <https://tukaani.org/xz/>\n");
    }
}
