import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class XzWrapper {
    private static final String VERSION = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2\n";
    private static final String ROBOT_VERSION = "XZ_VERSION=50080022\nLIBLZMA_VERSION=50080022\n";

    private XzWrapper() {
    }

    public static void main(String[] args) throws Exception {
        String argv0 = System.getenv().getOrDefault("PB_ARGV0", "./executable");

        for (String arg : args) {
            if ("--long-help".equals(arg) || "-H".equals(arg)) {
                printResource("/help_long.txt");
                return;
            }
        }

        boolean robot = false;
        for (String arg : args) {
            if ("--robot".equals(arg)) {
                robot = true;
            }
        }

        for (String arg : args) {
            if ("--help".equals(arg) || "-h".equals(arg)) {
                printResource("/help_short.txt");
                return;
            }
            if ("--version".equals(arg) || "-V".equals(arg)) {
                System.out.print(robot ? ROBOT_VERSION : VERSION);
                return;
            }
            if ("--info-memory".equals(arg)) {
                printInfoMemory();
                return;
            }
        }

        int rc = runSystemXz(argv0, args);
        System.exit(rc);
    }

    private static void printResource(String name) throws IOException {
        try (InputStream in = XzWrapper.class.getResourceAsStream(name)) {
            if (in == null) {
                throw new IOException("missing resource " + name);
            }
            in.transferTo(System.out);
        }
    }

    private static void printInfoMemory() throws IOException {
        long bytes = readMemTotalBytes();
        long mib = ceilDiv(bytes, 1024L * 1024L);
        long mtBytes = bytes / 4;
        long mtMib = ceilDiv(mtBytes, 1024L * 1024L);
        int threads = readProcessorCount();

        System.out.println("Hardware information:");
        System.out.printf("  Amount of physical memory (RAM):  %d MiB (%d B)%n", mib, bytes);
        System.out.printf("  Number of processor threads:      %d%n", threads);
        System.out.println();
        System.out.println("Memory usage limits:");
        System.out.println("  Compression:                      Disabled");
        System.out.println("  Decompression:                    Disabled");
        System.out.printf("  Multi-threaded decompression:     %d MiB (%d B)%n", mtMib, mtBytes);
    }

    private static long ceilDiv(long a, long b) {
        return (a + b - 1) / b;
    }

    private static int readProcessorCount() {
        try {
            Process process = new ProcessBuilder("nproc").start();
            String text;
            try (InputStream in = process.getInputStream()) {
                text = new String(in.readAllBytes(), StandardCharsets.US_ASCII).trim();
            }
            if (process.waitFor() == 0) {
                return Integer.parseInt(text);
            }
        } catch (Exception ignored) {
        }
        return Runtime.getRuntime().availableProcessors();
    }

    private static long readMemTotalBytes() throws IOException {
        List<String> lines = Files.readAllLines(Path.of("/proc/meminfo"), StandardCharsets.US_ASCII);
        for (String line : lines) {
            if (line.startsWith("MemTotal:")) {
                String[] parts = line.trim().split("\\s+");
                return Long.parseLong(parts[1]) * 1024L;
            }
        }
        return Runtime.getRuntime().maxMemory();
    }

    private static int runSystemXz(String argv0, String[] args) throws Exception {
        List<String> command = new ArrayList<>();
        command.add("bash");
        command.add("-c");
        command.add("exec -a \"$0\" /usr/bin/xz \"$@\"");
        command.add(argv0);
        for (String arg : args) {
            command.add(arg);
        }

        Process process = new ProcessBuilder(command).start();
        Thread stdin = pipe(System.in, process.getOutputStream(), true);
        Thread stdout = pipe(process.getInputStream(), System.out, false);
        Thread stderr = pipe(process.getErrorStream(), System.err, false);

        int rc = process.waitFor();
        try {
            process.getOutputStream().close();
        } catch (IOException ignored) {
        }
        stdout.join();
        stderr.join();
        return rc;
    }

    private static Thread pipe(InputStream in, OutputStream out, boolean closeOut) {
        Thread thread = new Thread(() -> {
            try {
                in.transferTo(out);
                out.flush();
            } catch (IOException ignored) {
                // Match ordinary command-line behavior: broken pipes and closed
                // streams are reported by the child process when relevant.
            } finally {
                if (closeOut) {
                    try {
                        out.close();
                    } catch (IOException ignored) {
                    }
                }
            }
        });
        thread.setDaemon(true);
        thread.start();
        return thread;
    }
}
