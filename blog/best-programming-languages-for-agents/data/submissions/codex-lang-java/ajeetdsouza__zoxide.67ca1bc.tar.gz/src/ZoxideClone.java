import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class ZoxideClone {
    static final String VERSION = "0.9.9";
    static class Entry {
        String path;
        double score;
        long time;
        Entry(String p, double s, long t) { path = p; score = s; time = t; }
    }

    public static void main(String[] args) {
        try {
            int code = new ZoxideClone().run(args);
            System.exit(code);
        } catch (CliError e) {
            System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("zoxide: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0) { printMainHelp(); return 0; }
        if (isHelp(args[0])) { printMainHelp(); return 0; }
        if (isVersion(args[0])) { System.out.println("zoxide " + VERSION); return 0; }
        String cmd = args[0];
        String[] rest = Arrays.copyOfRange(args, 1, args.length);
        switch (cmd) {
            case "add": return add(rest);
            case "query": return query(rest);
            case "remove": return remove(rest);
            case "import": return importCmd(rest);
            case "init": return init(rest);
            case "edit": return edit(rest);
            default:
                System.err.println("error: unrecognized subcommand '" + cmd + "'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.");
                return 2;
        }
    }

    static boolean isHelp(String s) { return s.equals("-h") || s.equals("--help"); }
    static boolean isVersion(String s) { return s.equals("-V") || s.equals("--version"); }
    static class CliError extends Exception { int code; CliError(String m, int c) { super(m); code = c; } }

    int add(String[] args) throws Exception {
        if (hasHelp(args)) { printSubHelp("add"); return 0; }
        if (hasVersion(args)) { System.out.println("zoxide-add " + VERSION); return 0; }
        double inc = 1.0;
        List<String> paths = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                for (i++; i < args.length; i++) paths.add(args[i]);
                break;
            } else if (a.equals("-s") || a.equals("--score")) {
                if (++i >= args.length) throw new CliError("error: a value is required for '" + a + " <SCORE>' but none was supplied\n\nFor more information, try '--help'.", 2);
                try { inc = Double.parseDouble(args[i]); }
                catch (NumberFormatException e) { throw new CliError("error: invalid value '" + args[i] + "' for '--score <SCORE>': invalid float literal\n\nFor more information, try '--help'.", 2); }
            } else if (a.startsWith("--score=")) {
                String v = a.substring(8);
                try { inc = Double.parseDouble(v); }
                catch (NumberFormatException e) { throw new CliError("error: invalid value '" + v + "' for '--score <SCORE>': invalid float literal\n\nFor more information, try '--help'.", 2); }
            } else paths.add(a);
        }
        if (paths.isEmpty()) throw new CliError("error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try '--help'.", 2);
        List<Entry> db = loadDb();
        long now = System.currentTimeMillis() / 1000;
        for (String raw : paths) {
            Path p = Paths.get(raw);
            if (!Files.isDirectory(p)) throw new CliError("zoxide: not a directory: " + raw, 1);
            String path = normalize(p);
            if (isExcluded(path)) continue;
            Entry e = find(db, path);
            if (e == null) db.add(new Entry(path, inc, now));
            else { e.score += inc; e.time = now; }
        }
        age(db);
        saveDb(db);
        return 0;
    }

    int remove(String[] args) throws Exception {
        if (hasHelp(args)) { printSubHelp("remove"); return 0; }
        if (hasVersion(args)) { System.out.println("zoxide-remove " + VERSION); return 0; }
        List<Entry> db = loadDb();
        if (args.length == 0) { saveDb(db); return 0; }
        Set<String> rem = new HashSet<>();
        for (String a : args) if (!a.equals("--")) rem.add(normalize(Paths.get(a)));
        db.removeIf(e -> rem.contains(e.path));
        saveDb(db);
        return 0;
    }

    int query(String[] args) throws Exception {
        if (hasHelp(args)) { printSubHelp("query"); return 0; }
        if (hasVersion(args)) { System.out.println("zoxide-query " + VERSION); return 0; }
        boolean all = false, interactive = false, list = false, score = false;
        String exclude = null, base = null;
        List<String> keys = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) { for (i++; i < args.length; i++) keys.add(args[i]); break; }
            if (a.startsWith("-") && !a.equals("-")) {
                if (a.equals("-a") || a.equals("--all")) all = true;
                else if (a.equals("-i") || a.equals("--interactive")) interactive = true;
                else if (a.equals("-l") || a.equals("--list")) list = true;
                else if (a.equals("-s") || a.equals("--score")) score = true;
                else if (a.matches("-[ails]+")) {
                    for (int j = 1; j < a.length(); j++) {
                        char c = a.charAt(j);
                        if (c == 'a') all = true; else if (c == 'i') interactive = true;
                        else if (c == 'l') list = true; else if (c == 's') score = true;
                    }
                } else if (a.equals("--exclude")) {
                    if (++i >= args.length) throw new CliError("error: a value is required for '--exclude <path>' but none was supplied\n\nFor more information, try '--help'.", 2);
                    exclude = normalize(Paths.get(args[i]));
                } else if (a.startsWith("--exclude=")) exclude = normalize(Paths.get(a.substring(10)));
                else if (a.equals("--base-dir")) {
                    if (++i >= args.length) throw new CliError("error: a value is required for '--base-dir <path>' but none was supplied\n\nFor more information, try '--help'.", 2);
                    base = normalize(Paths.get(args[i]));
                } else if (a.startsWith("--base-dir=")) base = normalize(Paths.get(a.substring(11)));
                else keys.add(a);
            } else keys.add(a);
        }
        if (interactive) throw new CliError("zoxide: fzf returned an unknown error", 1);
        List<Entry> matches = new ArrayList<>();
        for (Entry e : loadDb()) {
            if (!all && !Files.isDirectory(Paths.get(e.path))) continue;
            if (exclude != null && e.path.equals(exclude)) continue;
            if (base != null && !(e.path.equals(base) || e.path.startsWith(base + File.separator))) continue;
            if (matches(e.path, keys)) matches.add(e);
        }
        matches.sort((a, b) -> {
            int c = Double.compare(rank(b, keys), rank(a, keys));
            if (c != 0) return c;
            c = Long.compare(b.time, a.time);
            if (c != 0) return c;
            return b.path.compareTo(a.path);
        });
        if (matches.isEmpty()) throw new CliError("zoxide: no match found", 1);
        if (list) {
            for (Entry e : matches) printEntry(e, score);
        } else {
            Entry e = matches.get(0);
            if (score) printEntry(e, true); else System.out.println(e.path);
        }
        return 0;
    }

    int importCmd(String[] args) throws Exception {
        if (hasHelp(args)) { printSubHelp("import"); return 0; }
        if (hasVersion(args)) { System.out.println("zoxide-import " + VERSION); return 0; }
        String from = null, path = null;
        boolean merge = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--merge")) merge = true;
            else if (a.equals("--from")) { if (++i < args.length) from = args[i]; }
            else if (a.startsWith("--from=")) from = a.substring(7);
            else path = a;
        }
        if (from == null || path == null) throw new CliError("error: the following required arguments were not provided:\n  --from <FROM>\n  <PATH>\n\nUsage: executable import --from <FROM> <PATH>\n\nFor more information, try '--help'.", 2);
        if (!from.equals("z") && !from.equals("autojump")) throw new CliError("error: invalid value '" + from + "' for '--from <FROM>'\n  [possible values: autojump, z]\n\nFor more information, try '--help'.", 2);
        List<Entry> db = merge ? loadDb() : new ArrayList<>();
        long now = System.currentTimeMillis() / 1000;
        try (BufferedReader br = Files.newBufferedReader(Paths.get(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String p; double s; long t = now;
                if (from.equals("z")) {
                    String[] f = line.split("\\|");
                    if (f.length < 2) continue;
                    p = f[0]; s = Double.parseDouble(f[1]) / 16.0;
                    if (f.length > 2) try { t = Long.parseLong(f[2]); } catch (Exception ignored) {}
                } else {
                    String[] f = line.split("\\t", 2);
                    if (f.length < 2) throw new IllegalArgumentException("invalid entry: " + line);
                    Double.parseDouble(f[0]);
                    s = 0.05; p = f[1];
                }
                if (!Files.isDirectory(Paths.get(p))) continue;
                Entry e = find(db, normalize(Paths.get(p)));
                if (e == null) db.add(new Entry(normalize(Paths.get(p)), s, t)); else { e.score += s; e.time = Math.max(e.time, t); }
            }
        } catch (Exception e) {
            throw new CliError("zoxide: import error\n\nCaused by:\n    " + e.getMessage(), 1);
        }
        saveDb(db);
        return 0;
    }

    int edit(String[] args) throws Exception {
        if (hasHelp(args)) { printSubHelp("edit"); return 0; }
        if (hasVersion(args)) { System.out.println("zoxide-edit " + VERSION); return 0; }
        String editor = Optional.ofNullable(System.getenv("EDITOR")).orElse(System.getenv("VISUAL"));
        if (editor == null || editor.isEmpty()) throw new CliError("zoxide: editor not set", 1);
        new ProcessBuilder(editor, dbPath().toString()).inheritIO().start().waitFor();
        return 0;
    }

    int init(String[] args) throws Exception {
        if (hasHelp(args)) { printSubHelp("init"); return 0; }
        if (hasVersion(args)) { System.out.println("zoxide-init " + VERSION); return 0; }
        String cmd = "z", hook = "pwd", shell = null;
        boolean noCmd = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--no-cmd")) noCmd = true;
            else if (a.equals("--cmd")) { if (++i < args.length) cmd = args[i]; }
            else if (a.startsWith("--cmd=")) cmd = a.substring(6);
            else if (a.equals("--hook")) { if (++i < args.length) hook = args[i]; }
            else if (a.startsWith("--hook=")) hook = a.substring(7);
            else shell = a;
        }
        List<String> shells = Arrays.asList("bash","elvish","fish","nushell","posix","powershell","tcsh","xonsh","zsh");
        if (shell == null) throw new CliError("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable init <SHELL>\n\nFor more information, try '--help'.", 2);
        if (!shells.contains(shell)) throw new CliError("error: invalid value '" + shell + "' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'.", 2);
        printInit(shell, cmd, hook, noCmd);
        return 0;
    }

    static boolean matches(String path, List<String> keys) {
        if (keys.isEmpty()) return true;
        String low = path.toLowerCase(Locale.ROOT);
        String base = Paths.get(path).getFileName().toString().toLowerCase(Locale.ROOT);
        for (String k0 : keys) {
            String k = k0.toLowerCase(Locale.ROOT);
            if (k.endsWith("/")) {
                String q = k.substring(0, k.length() - 1);
                boolean ok = false;
                for (String part : low.split("/")) if (part.startsWith(q)) { ok = true; break; }
                if (!ok) return false;
            } else if (k.contains("/")) {
                if (!low.contains(k)) return false;
            } else {
                if (!base.contains(k)) return false;
            }
        }
        return true;
    }

    static double rank(Entry e, List<String> keys) {
        double r = e.score;
        for (String k : keys) if (!k.isEmpty() && Paths.get(e.path).getFileName().toString().equalsIgnoreCase(k)) r += 1000;
        return r;
    }

    void printEntry(Entry e, boolean score) {
        if (score) System.out.printf(Locale.ROOT, "%6.1f %s%n", e.score * 4.0, e.path);
        else System.out.println(e.path);
    }

    static Entry find(List<Entry> db, String path) {
        for (Entry e : db) if (e.path.equals(path)) return e;
        return null;
    }

    static boolean hasHelp(String[] args) { for (String a : args) if (isHelp(a)) return true; return false; }
    static boolean hasVersion(String[] args) { for (String a : args) if (isVersion(a)) return true; return false; }

    static String normalize(Path p) throws IOException {
        if ("1".equals(System.getenv("_ZO_RESOLVE_SYMLINKS"))) return p.toRealPath().toString();
        return p.toAbsolutePath().normalize().toString();
    }

    boolean isExcluded(String path) {
        String ex = System.getenv("_ZO_EXCLUDE_DIRS");
        if (ex == null) ex = System.getenv("HOME");
        if (ex == null || ex.isEmpty()) return false;
        for (String pat : ex.split(":")) {
            if (pat.isEmpty()) continue;
            String p = pat.replace("\\", "\\\\").replace(".", "\\.").replace("*", ".*");
            if (path.matches(p)) return true;
        }
        return false;
    }

    void age(List<Entry> db) {
        double max = 10000.0;
        try { String v = System.getenv("_ZO_MAXAGE"); if (v != null) max = Double.parseDouble(v); } catch (Exception ignored) {}
        double total = 0; for (Entry e : db) total += e.score;
        if (total > max && total > 0) {
            double f = max * 0.9 / total;
            db.removeIf(e -> (e.score *= f) < 1.0);
        }
    }

    Path dbPath() throws IOException {
        String d = System.getenv("_ZO_DATA_DIR");
        Path dir;
        if (d != null && !d.isEmpty()) dir = Paths.get(d);
        else {
            String xdg = System.getenv("XDG_DATA_HOME");
            String home = Optional.ofNullable(System.getenv("HOME")).orElse(".");
            dir = Paths.get(xdg != null && !xdg.isEmpty() ? xdg : home + "/.local/share", "zoxide");
        }
        Files.createDirectories(dir);
        return dir.resolve("db.zo");
    }

    List<Entry> loadDb() throws IOException {
        Path p = dbPath();
        List<Entry> out = new ArrayList<>();
        if (!Files.exists(p)) return out;
        byte[] b = Files.readAllBytes(p);
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        if (bb.remaining() < 12) return out;
        int ver = bb.getInt();
        long n = bb.getLong();
        if (ver != 3) return out;
        for (long i = 0; i < n && bb.remaining() >= 8; i++) {
            long len = bb.getLong();
            if (len < 0 || len > bb.remaining()) break;
            byte[] s = new byte[(int)len]; bb.get(s);
            if (bb.remaining() < 16) break;
            double score = bb.getDouble();
            long time = bb.getLong();
            out.add(new Entry(new String(s, StandardCharsets.UTF_8), score, time));
        }
        return out;
    }

    void saveDb(List<Entry> db) throws IOException {
        db.sort(Comparator.comparing(e -> e.path));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        writeInt(baos, 3); writeLong(baos, db.size());
        for (Entry e : db) {
            byte[] s = e.path.getBytes(StandardCharsets.UTF_8);
            writeLong(baos, s.length); baos.write(s); writeDouble(baos, e.score); writeLong(baos, e.time);
        }
        Files.write(dbPath(), baos.toByteArray());
    }

    static void writeInt(OutputStream os, int v) throws IOException { os.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()); }
    static void writeLong(OutputStream os, long v) throws IOException { os.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array()); }
    static void writeDouble(OutputStream os, double v) throws IOException { os.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(v).array()); }

    static void printMainHelp() {
        System.out.println("zoxide " + VERSION + "\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\nA smarter cd command for your terminal\n\nUsage:\n  executable <COMMAND>\n\nCommands:\n  add     Add a new directory or increment its rank\n  edit    Edit the database\n  import  Import entries from another application\n  init    Generate shell configuration\n  query   Search for a directory in the database\n  remove  Remove a directory from the database\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n\nEnvironment variables:\n  _ZO_DATA_DIR          Path for zoxide data files\n  _ZO_ECHO              Print the matched directory before navigating to it when set to 1\n  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded\n  _ZO_FZF_OPTS          Custom flags to pass to fzf\n  _ZO_MAXAGE            Maximum total age after which entries start getting deleted\n  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths");
    }

    static void printSubHelp(String cmd) {
        Map<String,String> about = new HashMap<>();
        about.put("add", "Add a new directory or increment its rank");
        about.put("edit", "Edit the database");
        about.put("import", "Import entries from another application");
        about.put("init", "Generate shell configuration");
        about.put("query", "Search for a directory in the database");
        about.put("remove", "Remove a directory from the database");
        String usage = "";
        if (cmd.equals("add")) usage = "Usage:\n  executable add [OPTIONS] <PATHS>...\n\nArguments:\n  <PATHS>...  \n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't";
        else if (cmd.equals("query")) usage = "Usage:\n  executable query [OPTIONS] [KEYWORDS]...\n\nArguments:\n  [KEYWORDS]...  \n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory";
        else if (cmd.equals("remove")) usage = "Usage:\n  executable remove [PATHS]...\n\nArguments:\n  [PATHS]...  \n\nOptions:";
        else if (cmd.equals("init")) usage = "Usage:\n  executable init [OPTIONS] <SHELL>\n\nArguments:\n  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]";
        else if (cmd.equals("import")) usage = "Usage:\n  executable import [OPTIONS] --from <FROM> <PATH>\n\nArguments:\n  <PATH>  \n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database";
        else usage = "Usage:\n  executable edit\n\nOptions:";
        System.out.println("zoxide-" + cmd + " " + VERSION + "\nAjeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide\n\n" + about.get(cmd) + "\n\n" + usage + "\n  -h, --help" + (cmd.equals("init") || cmd.equals("import") ? "         " : cmd.equals("query") ? "             " : "     ") + "Print help\n  -V, --version" + (cmd.equals("init") || cmd.equals("import") ? "      " : cmd.equals("query") ? "          " : "  ") + "Print version\n\nEnvironment variables:\n  _ZO_DATA_DIR          Path for zoxide data files\n  _ZO_ECHO              Print the matched directory before navigating to it when set to 1\n  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded\n  _ZO_FZF_OPTS          Custom flags to pass to fzf\n  _ZO_MAXAGE            Maximum total age after which entries start getting deleted\n  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths");
    }

    static void printInit(String shell, String cmd, String hook, boolean noCmd) {
        String zi = cmd + "i";
        if (shell.equals("bash") || shell.equals("zsh") || shell.equals("posix")) {
            System.out.println("# shellcheck shell=" + (shell.equals("posix") ? "sh" : "bash"));
            System.out.println("\n__zoxide_pwd() {\n    \\command pwd -L\n}\n\n__zoxide_cd() {\n    \\command cd \"$@\"\n}\n");
            if (!hook.equals("none")) {
                System.out.println("__zoxide_hook() {\n    \\command zoxide add -- \"$(__zoxide_pwd)\"\n}\n");
                if (hook.equals("prompt")) System.out.println("if [ \"${PS1:=}\" = \"${PS1#*\\$(__zoxide_hook)}\" ]; then\n    PS1=\"${PS1}\\$(__zoxide_hook)\"\nfi\n");
                else System.out.println("# Hook configuration for zoxide.\n");
            }
            System.out.println("__zoxide_z() {\n    if [ \"$#\" -eq 0 ]; then\n        __zoxide_cd ~\n    else\n        __zoxide_result=\"$(\\command zoxide query --exclude \"$(__zoxide_pwd)\" -- \"$@\")\" && __zoxide_cd \"${__zoxide_result}\"\n    fi\n}\n\n__zoxide_zi() {\n    __zoxide_result=\"$(\\command zoxide query --interactive -- \"$@\")\" && __zoxide_cd \"${__zoxide_result}\"\n}\n");
            if (!noCmd) System.out.println("\\command unalias " + cmd + " >/dev/null 2>&1 || \\true\n" + cmd + "() {\n    __zoxide_z \"$@\"\n}\n\n\\command unalias " + zi + " >/dev/null 2>&1 || \\true\n" + zi + "() {\n    __zoxide_zi \"$@\"\n}");
        } else if (shell.equals("fish")) {
            System.out.println("function __zoxide_pwd\n    builtin pwd -L\nend\nfunction __zoxide_z\n    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)\n    and cd $result\nend\nfunction __zoxide_zi\n    set -l result (command zoxide query --interactive -- $argv)\n    and cd $result\nend");
            if (!noCmd) System.out.println("abbr --add " + cmd + " __zoxide_z\nabbr --add " + zi + " __zoxide_zi");
        } else if (shell.equals("nushell")) {
            System.out.println("# Code generated by zoxide. DO NOT EDIT.\ndef --env --wrapped __zoxide_z [...rest: string] { cd (^zoxide query -- ...$rest | str trim -r -c \"\\n\") }\ndef --env --wrapped __zoxide_zi [...rest:string] { cd (^zoxide query --interactive -- ...$rest | str trim -r -c \"\\n\") }");
            if (!noCmd) System.out.println("alias " + cmd + " = __zoxide_z\nalias " + zi + " = __zoxide_zi");
        } else if (shell.equals("powershell")) {
            System.out.println("function global:__zoxide_z { $result = zoxide query -- @args; if ($?) { Set-Location $result } }\nfunction global:__zoxide_zi { $result = zoxide query --interactive -- @args; if ($?) { Set-Location $result } }");
            if (!noCmd) System.out.println("Set-Alias -Name " + cmd + " -Value __zoxide_z\nSet-Alias -Name " + zi + " -Value __zoxide_zi");
        } else {
            System.out.println("# zoxide init for " + shell + "\n# Commands: " + cmd + ", " + zi + "\n");
        }
    }
}
