import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class XplrClone {
    private static final String VERSION = "xplr 1.1.0";
    private static final String HELP = String.join("\n",
            "xplr 1.1.0",
            "Arijit Basu <hi@arijitbasu.in>",
            "A hackable, minimal, fast TUI file explorer",
            "",
            "USAGE:",
            "    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...",
            "",
            "FLAGS:",
            "  -                            Reads new-line (\\n) separated paths from stdin",
            "  --                           Denotes the end of command-line flags and options",
            "      --force-focus            Focuses on the given <PATH>, even if it is a directory",
            "  -h, --help                   Prints help information",
            "  -m, --pipe-msg-in            Helps safely passing messages to the active xplr",
            "                                 session, use %%, %s and %q as the placeholders",
            "  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of",
            "                                 passing to the active xplr session",
            "      --print-pwd-as-result    Prints the present working directory when quitting",
            "                                 with `PrintResultAndQuit`",
            "      --read-only              Enables read-only mode (config.general.read_only)",
            "      --read0                  Reads paths separated using the null character (\\0)",
            "      --write0                 Prints paths separated using the null character (\\0)",
            "  -0  --null                   Combines --read0 and --write0",
            "  -V, --version                Prints version information",
            "",
            "OPTIONS:",
            "  -c, --config <PATH>             Specifies a custom config file (default is",
            "                                    \"$HOME/.config/xplr/init.lua\")",
            "  -C, --extra-config <PATH>...    Specifies extra config files to load",
            "      --on-load <MESSAGE>...      Sends messages when xplr loads",
            "      --vroot <PATH>              Treats the specified path as the virtual root",
            "",
            "ARGS:",
            "  <PATH>            Path to focus on, or enter if directory, (default is `.`)",
            "  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly");

    private static final String EXPECTED_VARIANTS =
            "ExplorePwd`, `ExplorePwdAsync`, `ExploreParentsAsync`, `TryCompletePath`, `ClearScreen`, `Refresh`, `FocusNext`, `FocusNextSelection`, `FocusNextByRelativeIndex`, `FocusNextByRelativeIndexFromInput`, `FocusPrevious`, `FocusPreviousSelection`, `FocusPreviousByRelativeIndex`, `FocusPreviousByRelativeIndexFromInput`, `FocusFirst`, `FocusLast`, `FocusPath`, `FocusPathFromInput`, `FocusByIndex`, `FocusByIndexFromInput`, `FocusByFileName`, `ScrollUp`, `ScrollDown`, `ScrollUpHalf`, `ScrollDownHalf`, `ChangeDirectory`, `Enter`, `Back`, `LastVisitedPath`, `NextVisitedPath`, `PreviousVisitedDeepBranch`, `NextVisitedDeepBranch`, `FollowSymlink`, `SetVroot`, `UnsetVroot`, `ToggleVroot`, `ResetVroot`, `SetInputPrompt`, `UpdateInputBuffer`, `UpdateInputBufferFromKey`, `BufferInput`, `BufferInputFromKey`, `SetInputBuffer`, `RemoveInputBufferLastCharacter`, `RemoveInputBufferLastWord`, `ResetInputBuffer`, `SwitchMode`, `SwitchModeKeepingInputBuffer`, `SwitchModeBuiltin`, `SwitchModeBuiltinKeepingInputBuffer`, `SwitchModeCustom`, `SwitchModeCustomKeepingInputBuffer`, `PopMode`, `PopModeKeepingInputBuffer`, `SwitchLayout`, `SwitchLayoutBuiltin`, `SwitchLayoutCustom`, `Call`, `Call0`, `CallSilently`, `CallSilently0`, `BashExec`, `BashExec0`, `BashExecSilently`, `BashExecSilently0`, `CallLua`, `CallLuaSilently`, `LuaEval`, `LuaEvalSilently`, `Select`, `SelectAll`, `SelectPath`, `UnSelect`, `UnSelectAll`, `UnSelectPath`, `ToggleSelection`, `ToggleSelectAll`, `ToggleSelectionByPath`, `ClearSelection`, `AddNodeFilter`, `RemoveNodeFilter`, `ToggleNodeFilter`, `AddNodeFilterFromInput`, `RemoveNodeFilterFromInput`, `RemoveLastNodeFilter`, `ResetNodeFilters`, `ClearNodeFilters`, `AddNodeSorter`, `RemoveNodeSorter`, `ReverseNodeSorter`, `ToggleNodeSorter`, `ReverseNodeSorters`, `RemoveLastNodeSorter`, `ResetNodeSorters`, `ClearNodeSorters`, `Search`, `SearchFromInput`, `SearchFuzzy`, `SearchFuzzyFromInput`, `SearchFuzzyUnordered`, `SearchFuzzyUnorderedFromInput`, `SearchRegex`, `SearchRegexFromInput`, `SearchRegexUnordered`, `SearchRegexUnorderedFromInput`, `ToggleSearchAlgorithm`, `EnableSearchOrder`, `DisableSearchOrder`, `ToggleSearchOrder`, `AcceptSearch`, `CancelSearch`, `EnableMouse`, `DisableMouse`, `ToggleMouse`, `StartFifo`, `StopFifo`, `ToggleFifo`, `LogInfo`, `LogSuccess`, `LogWarning`, `LogError`, `Debug`, `Quit`, `PrintPwdAndQuit`, `PrintFocusPathAndQuit`, `PrintSelectionAndQuit`, `PrintResultAndQuit`, `PrintAppStateAndQuit`, `Terminate`";

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static int run(String[] args) throws IOException {
        boolean read0 = false;
        boolean readStdin = false;
        boolean endFlags = false;
        List<String> paths = new ArrayList<>();

        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (!endFlags && "--".equals(arg)) {
                endFlags = true;
                continue;
            }
            if (!endFlags && "-".equals(arg)) {
                readStdin = true;
                continue;
            }
            if (!endFlags && ("-h".equals(arg) || "--help".equals(arg))) {
                System.out.println(HELP);
                return 0;
            }
            if (!endFlags && ("-V".equals(arg) || "--version".equals(arg))) {
                System.out.println(VERSION);
                return 0;
            }
            if (!endFlags && ("-M".equals(arg) || "--print-msg-in".equals(arg))) {
                return printMsg(args, i + 1);
            }
            if (!endFlags && ("-m".equals(arg) || "--pipe-msg-in".equals(arg))) {
                return pipeMsg(args, i + 1);
            }
            if (!endFlags && ("-0".equals(arg) || "--null".equals(arg))) {
                read0 = true;
                continue;
            }
            if (!endFlags && "--read0".equals(arg)) {
                read0 = true;
                continue;
            }
            if (!endFlags && ("--write0".equals(arg) || "--force-focus".equals(arg)
                    || "--print-pwd-as-result".equals(arg) || "--read-only".equals(arg))) {
                continue;
            }
            if (!endFlags && ("-c".equals(arg) || "--config".equals(arg) || "--vroot".equals(arg))) {
                if (i + 1 >= args.length) {
                    String opt = arg.equals("-c") ? "--config" : arg;
                    System.err.println("error: usage: xplr " + opt + " PATH");
                    return 1;
                }
                String value = args[++i];
                if (!Files.exists(resolve(value))) {
                    System.err.println("error: path doesn't exist: " + value);
                    return 1;
                }
                continue;
            }
            if (!endFlags && ("-C".equals(arg) || "--extra-config".equals(arg))) {
                if (i + 1 >= args.length) {
                    System.err.println("error: usage: xplr --extra-config PATH");
                    return 1;
                }
                String value = args[++i];
                if (!Files.exists(resolve(value))) {
                    System.err.println("error: path doesn't exist: " + value);
                    return 1;
                }
                continue;
            }
            if (!endFlags && "--on-load".equals(arg)) {
                if (i + 1 < args.length && !args[i + 1].startsWith("-")) {
                    i++;
                }
                continue;
            }
            if (!endFlags && arg.startsWith("-")) {
                System.err.println("error: invalid argument: \"" + arg + "\", try `-- \"" + arg + "\"` or `--help`");
                return 1;
            }
            paths.add(arg);
        }

        if (readStdin) {
            paths.addAll(readInputPaths(read0));
        }
        for (String p : paths) {
            Path path = resolve(p);
            if (!Files.exists(path)) {
                System.err.println("error: path doesn't exist: " + path);
                return 1;
            }
        }
        System.err.println("error: No such device or address (os error 6)");
        return 1;
    }

    private static Path resolve(String s) {
        Path p = Paths.get(s);
        if (!p.isAbsolute()) {
            p = Paths.get(System.getProperty("user.dir")).resolve(p);
        }
        return p.normalize();
    }

    private static List<String> readInputPaths(boolean nul) throws IOException {
        byte[] data = readAllBytes();
        List<String> out = new ArrayList<>();
        int start = 0;
        byte delim = (byte) (nul ? 0 : '\n');
        for (int i = 0; i < data.length; i++) {
            if (data[i] == delim) {
                if (i > start) out.add(new String(data, start, i - start, StandardCharsets.UTF_8));
                start = i + 1;
            }
        }
        if (start < data.length) {
            out.add(new String(data, start, data.length - start, StandardCharsets.UTF_8));
        }
        return out;
    }

    private static byte[] readAllBytes() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = System.in.read(buf)) != -1) {
            baos.write(buf, 0, n);
        }
        return baos.toByteArray();
    }

    private static int printMsg(String[] args, int start) {
        if (start >= args.length) {
            System.err.println("error: usage: xplr -M FORMAT [ARGUMENT]...");
            return 1;
        }
        FormatResult formatted = formatTemplate(args[start], args, start + 1);
        if (formatted.error != null) {
            System.err.println("error: xplr -m: " + formatted.error);
            return 1;
        }
        String json = toMessageJson(formatted.value);
        if (json.startsWith("error:")) {
            System.out.println(json);
        } else {
            System.out.print(json);
        }
        return 0;
    }

    private static int pipeMsg(String[] args, int start) throws IOException {
        if (start >= args.length) {
            System.err.println("error: usage: xplr -m FORMAT [ARGUMENT]...");
            return 1;
        }
        FormatResult formatted = formatTemplate(args[start], args, start + 1);
        if (formatted.error != null) {
            System.err.println("error: xplr -m: " + formatted.error);
            return 1;
        }
        String json = toMessageJson(formatted.value);
        if (json.startsWith("error:")) {
            System.out.println(json);
            return 0;
        }
        String pipe = System.getenv("XPLR_PIPE_MSG_IN");
        if (pipe == null || pipe.isEmpty() || !Files.exists(Paths.get(pipe))) {
            System.err.println("error: No such file or directory (os error 2)");
            return 1;
        }
        byte[] existing = Files.readAllBytes(Paths.get(pipe));
        if (existing.length == 0) {
            System.err.println("error: failed to detect delimmiter");
            return 1;
        }
        byte delim = existing[0] == 0 ? (byte) 0 : (byte) '\n';
        Files.write(Paths.get(pipe), (json + (delim == 0 ? "\0" : "\n")).getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.APPEND);
        return 0;
    }

    private static FormatResult formatTemplate(String template, String[] args, int argStart) {
        StringBuilder sb = new StringBuilder();
        int argIndex = argStart;
        for (int i = 0; i < template.length(); i++) {
            char c = template.charAt(i);
            if (c != '%') {
                sb.append(c);
                continue;
            }
            int col = i + 1;
            if (i + 1 >= template.length()) {
                return FormatResult.err("template ended with incomplete placeholder");
            }
            char n = template.charAt(++i);
            if (n == '%') {
                sb.append('%');
            } else if (n == 's' || n == 'q') {
                if (argIndex >= args.length) {
                    return FormatResult.err("placeholder missing value at column " + col);
                }
                if (n == 'q') {
                    sb.append('"').append(jsonEscape(args[argIndex])).append('"');
                } else {
                    sb.append(args[argIndex]);
                }
                argIndex++;
            } else {
                return FormatResult.err("invalid placeholder '%" + n + "' at column " + col
                        + ", use one of '%s' or '%q', or escape it using '%%'");
            }
        }
        if (argIndex < args.length) {
            return FormatResult.err("too many positional values, not enough positional placeholders");
        }
        return FormatResult.ok(sb.toString());
    }

    private static String toMessageJson(String yamlish) {
        String s = yamlish.trim();
        if (s.startsWith("{") && s.endsWith("}")) {
            s = s.substring(1, s.length() - 1).trim();
        }
        if (s.startsWith("-")) {
            return "error: expected value at line 1 column 1\n";
        }
        int colon = s.indexOf(':');
        if (colon < 0) {
            return "error: expected value at line 1 column 1\n";
        }
        String key = stripQuotes(s.substring(0, colon).trim());
        String value = s.substring(colon + 1).trim();
        if (!isKnownVariant(key)) {
            return "error: unknown variant `" + key + "`, expected one of `" + EXPECTED_VARIANTS + " at line 1 column 6\n";
        }
        if (value.startsWith("{") || value.startsWith("[") || "null".equals(value)) {
            return "{\"" + jsonEscape(key) + "\":" + value + "}";
        }
        if (value.startsWith("\"") && value.endsWith("\"") && value.length() >= 2) {
            return "{\"" + jsonEscape(key) + "\":" + value + "}";
        }
        if ("true".equals(value) || "false".equals(value)) {
            return "error: invalid type: boolean `" + value + "`, expected a string at line 1 column " + (colon + 3) + "\n";
        }
        if (value.matches("-?\\d+")) {
            return "error: invalid type: integer `" + value + "`, expected a string at line 1 column " + (colon + 3) + "\n";
        }
        if (value.contains("%")) {
            return "error: xplr -m: yaml: found character that cannot start any token at line 1 column " + (s.indexOf('%') + 1) + ", while scanning for the next token\n";
        }
        return "{\"" + jsonEscape(key) + "\":\"" + jsonEscape(value) + "\"}";
    }

    private static String stripQuotes(String s) {
        if ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'"))) {
            return s.substring(1, s.length() - 1);
        }
        return s;
    }

    private static boolean isKnownVariant(String key) {
        return EXPECTED_VARIANTS.contains("`" + key + "`") || EXPECTED_VARIANTS.startsWith(key + "`");
    }

    private static String jsonEscape(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                default:
                    if (c < 0x20) out.append(String.format("\\u%04x", (int)c));
                    else out.append(c);
            }
        }
        return out.toString();
    }

    private static class FormatResult {
        final String value;
        final String error;
        private FormatResult(String value, String error) {
            this.value = value;
            this.error = error;
        }
        static FormatResult ok(String value) { return new FormatResult(value, null); }
        static FormatResult err(String error) { return new FormatResult(null, error); }
    }
}
