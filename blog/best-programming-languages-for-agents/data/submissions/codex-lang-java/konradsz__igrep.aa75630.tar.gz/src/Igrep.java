import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Igrep {
    private static final String EDITORS = "vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh";
    private static final Set<String> EDITOR_SET = new HashSet<>(Arrays.asList(EDITORS.split(", ")));
    private static final Set<String> THEMES = Set.of("light", "dark");
    private static final Set<String> VIEWERS = Set.of("none", "vertical", "horizontal");
    private static final Set<String> SORTS = Set.of("path", "modified", "created", "accessed");
    private static final Set<String> TYPES = new HashSet<>();

    static {
        try (BufferedReader br = Files.newBufferedReader(Path.of("type-list.txt"), StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                int colon = line.indexOf(':');
                if (colon > 0) TYPES.add(line.substring(0, colon));
            }
        } catch (IOException ignored) {
        }
    }

    private static class Options {
        boolean typeList;
        boolean ignoreCase;
        boolean smartCase;
        boolean hidden;
        boolean follow;
        boolean word;
        boolean fixed;
        boolean multiline;
        final List<String> globs = new ArrayList<>();
        final List<String> types = new ArrayList<>();
        final List<String> typeNots = new ArrayList<>();
        String sort;
        boolean reverseSort;
        String pattern;
        final List<String> paths = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (Exit e) {
            System.exit(e.code);
        }
    }

    private static int run(String[] args) {
        for (String arg : args) {
            if (arg.equals("--help") || arg.equals("-h")) {
                System.out.print(helpText());
                return 0;
            }
            if (arg.equals("--version") || arg.equals("-V")) {
                System.out.println("igrep 1.3.0");
                return 0;
            }
        }

        Options opt = parse(args);
        if (opt.typeList) {
            if (opt.pattern != null) {
                clapErr("the argument '--type-list' cannot be used with '<PATTERN>'\n\nUsage: executable --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.");
            }
            printTypeList();
            return 0;
        }
        if (opt.pattern == null) {
            System.err.println("error: the following required arguments were not provided:");
            System.err.println("  --type-list");
            System.err.println("  <PATTERN>");
            System.err.println();
            System.err.println("Usage: executable --type-list <PATTERN> [PATHS]...");
            System.err.println();
            System.err.println("For more information, try '--help'.");
            return 2;
        }

        for (String type : opt.types) {
            if (!TYPES.contains(type)) {
                System.err.println("Error: unrecognized file type: " + type);
                return 1;
            }
        }
        for (String type : opt.typeNots) {
            if (!TYPES.contains(type)) {
                System.err.println("Error: unrecognized file type: " + type);
                return 1;
            }
        }

        if (System.console() == null) {
            System.err.println("Error: Resource temporarily unavailable (os error 11)");
            return 1;
        }
        return basicSearch(opt);
    }

    private static Options parse(String[] args) {
        Options opt = new Options();
        boolean positionalOnly = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (!positionalOnly && a.equals("--")) {
                positionalOnly = true;
                continue;
            }
            if (!positionalOnly && a.startsWith("-") && !a.equals("-")) {
                switch (a) {
                    case "--type-list" -> opt.typeList = true;
                    case "-i", "--ignore-case" -> opt.ignoreCase = true;
                    case "-S", "--smart-case" -> opt.smartCase = true;
                    case "-.", "--hidden" -> opt.hidden = true;
                    case "-L", "--follow" -> opt.follow = true;
                    case "-w", "--word-regexp" -> opt.word = true;
                    case "-F", "--fixed-strings" -> opt.fixed = true;
                    case "-U", "--multiline" -> opt.multiline = true;
                    case "-g", "--glob" -> opt.globs.add(requireValue(args, ++i, "--glob <GLOB>", null));
                    case "-t", "--type" -> opt.types.add(requireValue(args, ++i, "--type <TYPE_MATCHING>", null));
                    case "-T", "--type-not" -> opt.typeNots.add(requireValue(args, ++i, "--type-not <TYPE_NOT>", null));
                    case "--editor" -> validateEnum(requireValue(args, ++i, "--editor <EDITOR>", "  [possible values: " + EDITORS + "]"), "--editor <EDITOR>", EDITOR_SET);
                    case "--theme" -> validateEnum(requireValue(args, ++i, "--theme <THEME>", "  [possible values: light, dark]"), "--theme <THEME>", THEMES);
                    case "--context-viewer" -> validateEnum(requireValue(args, ++i, "--context-viewer <CONTEXT_VIEWER>", null), "--context-viewer <CONTEXT_VIEWER>", VIEWERS);
                    case "--sort" -> {
                        String v = requireValue(args, ++i, "--sort <SORT_BY>", null);
                        validateEnum(v, "--sort <SORT_BY>", SORTS);
                        opt.sort = v;
                    }
                    case "--sortr" -> {
                        String v = requireValue(args, ++i, "--sortr <SORT_BY_REVERSE>", null);
                        validateEnum(v, "--sortr <SORT_BY_REVERSE>", SORTS);
                        opt.sort = v;
                        opt.reverseSort = true;
                    }
                    case "--custom-command" -> validateCustom(requireValue(args, ++i, "--custom-command <CUSTOM_COMMAND>", null));
                    default -> clapErr("unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\nFor more information, try '--help'.");
                }
            } else if (opt.pattern == null) {
                opt.pattern = a;
            } else {
                opt.paths.add(a);
            }
        }
        return opt;
    }

    private static String requireValue(String[] args, int index, String name, String possible) {
        if (index >= args.length) {
            System.err.println("error: a value is required for '" + name + "' but none was supplied");
            if (possible != null) System.err.println(possible);
            System.err.println();
            System.err.println("For more information, try '--help'.");
            throw new Exit(2);
        }
        return args[index];
    }

    private static void validateEnum(String value, String name, Set<String> allowed) {
        if (!allowed.contains(value)) {
            System.err.println("error: invalid value '" + value + "' for '" + name + "'");
            if (name.contains("EDITOR")) System.err.println("  [possible values: " + EDITORS + "]");
            else if (name.contains("THEME")) System.err.println("  [possible values: light, dark]");
            else if (name.contains("CONTEXT")) System.err.println("  [possible values: none, vertical, horizontal]");
            else System.err.println("  [possible values: path, modified, created, accessed]");
            System.err.println();
            System.err.println("For more information, try '--help'.");
            throw new Exit(2);
        }
    }

    private static void validateCustom(String command) {
        if (!command.contains(" ")) {
            System.err.println("Error: Incorrect editor command: '" + command + "'");
            System.err.println();
            System.err.println("Caused by:");
            System.err.println("    Expected program and its arguments");
            throw new Exit(1);
        }
        if (count(command, "{file_name}") != 1) {
            System.err.println("Error: Incorrect editor command: '" + command + "'");
            System.err.println();
            System.err.println("Caused by:");
            System.err.println("    Expected one occurrence of '{file_name}'.");
            throw new Exit(1);
        }
        if (count(command, "{line_number}") != 1) {
            System.err.println("Error: Incorrect editor command: '" + command + "'");
            System.err.println();
            System.err.println("Caused by:");
            System.err.println("    Expected one occurrence of '{line_number}'.");
            throw new Exit(1);
        }
    }

    private static int count(String s, String sub) {
        int c = 0, p = 0;
        while ((p = s.indexOf(sub, p)) >= 0) {
            c++;
            p += sub.length();
        }
        return c;
    }

    private static void printTypeList() {
        try {
            Files.copy(Path.of("type-list.txt"), System.out);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            throw new Exit(1);
        }
    }

    private static int basicSearch(Options opt) {
        List<Path> roots = opt.paths.isEmpty() ? List.of(Path.of(".")) : opt.paths.stream().map(Path::of).toList();
        List<Path> files = new ArrayList<>();
        Set<FileVisitOption> visitOptions = opt.follow ? Set.of(FileVisitOption.FOLLOW_LINKS) : Set.of();
        for (Path root : roots) {
            try {
                if (Files.isRegularFile(root)) files.add(root);
                else if (Files.isDirectory(root)) {
                    Files.walkFileTree(root, visitOptions, Integer.MAX_VALUE, new SimpleFileVisitor<>() {
                        @Override
                        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                            if (!opt.hidden && isHiddenName(dir) && !dir.equals(root)) return FileVisitResult.SKIP_SUBTREE;
                            return FileVisitResult.CONTINUE;
                        }
                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                            if (Files.isRegularFile(file) && (opt.hidden || !isHiddenName(file))) files.add(file);
                            return FileVisitResult.CONTINUE;
                        }
                    });
                }
            } catch (IOException e) {
                System.err.println(root + ": " + e.getMessage());
            }
        }
        Comparator<Path> cmp = Comparator.comparing(Path::toString);
        files.sort(opt.reverseSort ? cmp.reversed() : cmp);
        Pattern pattern;
        try {
            String p = opt.fixed ? Pattern.quote(opt.pattern) : opt.pattern;
            if (opt.word) p = "\\b(?:" + p + ")\\b";
            int flags = 0;
            if (opt.ignoreCase || (opt.smartCase && opt.pattern.equals(opt.pattern.toLowerCase(Locale.ROOT)))) flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
            pattern = Pattern.compile(p, flags);
        } catch (PatternSyntaxException e) {
            System.err.println("Error: " + e.getMessage());
            return 1;
        }
        for (Path file : files) {
            try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                String line;
                int n = 0;
                while ((line = br.readLine()) != null) {
                    n++;
                    if (pattern.matcher(line).find()) {
                        System.out.println(file + ":" + n + ":" + line);
                    }
                }
            } catch (IOException ignored) {
            }
        }
        return 0;
    }

    private static boolean isHiddenName(Path path) {
        Path name = path.getFileName();
        return name != null && name.toString().startsWith(".");
    }

    private static void clapErr(String message) {
        System.err.println("error: " + message);
        throw new Exit(2);
    }

    private static String helpText() {
        return """
Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
""";
    }

    private static class Exit extends RuntimeException {
        final int code;
        Exit(int code) {
            this.code = code;
        }
    }
}
