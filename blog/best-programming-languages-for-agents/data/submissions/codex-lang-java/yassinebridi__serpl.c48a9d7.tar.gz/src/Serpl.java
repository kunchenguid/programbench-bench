import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public final class Serpl {
    private static final String ABOUT = "A simple terminal UI for search and replace, ala VS Code";
    private static final String USAGE = "Usage: executable [OPTIONS]";
    private static final String HELP = ABOUT + "\n\n" +
            USAGE + "\n\n" +
            "Options:\n" +
            "  -p, --project-root <PATH>  Path to the project root [default: .]\n" +
            "  -h, --help                 Print help\n" +
            "  -V, --version              Print version\n";

    private Serpl() {
    }

    public static void main(String[] args) {
        String projectRoot = ".";
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if ("--help".equals(arg) || "-h".equals(arg)) {
                System.out.print(HELP);
                return;
            }
            if ("--version".equals(arg) || "-V".equals(arg)) {
                printVersion();
                return;
            }
            if ("-p".equals(arg) || "--project-root".equals(arg)) {
                if (i + 1 >= args.length) {
                    valueRequired();
                    System.exit(2);
                }
                projectRoot = args[++i];
                continue;
            }
            if (arg.startsWith("--project-root=")) {
                projectRoot = arg.substring("--project-root=".length());
                continue;
            }
            if (arg.startsWith("-p=")) {
                projectRoot = arg.substring(3);
                continue;
            }
            unexpected(arg);
            System.exit(2);
        }

        runUi(projectRoot);
    }

    private static void printVersion() {
        String home = System.getenv("HOME");
        if (home == null || home.isEmpty()) {
            home = "";
        }
        System.out.println("serpl 0.3.4- (2026-04-20)");
        System.out.println();
        System.out.println("Authors: Yassine Bridi <ybridi@gmail.com>");
        System.out.println();
        System.out.println("Config directory: " + home + "/.config/serpl");
    }

    private static void valueRequired() {
        System.err.println("error: a value is required for '--project-root <PATH>' but none was supplied");
        System.err.println();
        System.err.println("For more information, try '--help'.");
    }

    private static void unexpected(String arg) {
        System.err.println("error: unexpected argument '" + arg + "' found");
        System.err.println();
        System.err.println(USAGE);
        System.err.println();
        System.err.println("For more information, try '--help'.");
    }

    private static void runUi(String projectRoot) {
        if (!hasTerminal()) {
            terminalError();
            System.exit(1);
        }

        Path root = Paths.get(projectRoot).toAbsolutePath().normalize();
        System.out.print("\033[?1049h\033[?25l\033[2J\033[H");
        draw(root);
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            while (true) {
                int ch = reader.read();
                if (ch == -1 || ch == 3 || ch == 4 || ch == 'q' || ch == 'Q') {
                    break;
                }
                if (ch == 18) {
                    draw(root);
                }
            }
        } catch (IOException ignored) {
        } finally {
            System.out.print("\033[?25h\033[?1049l");
            System.out.flush();
        }
    }

    private static boolean hasTerminal() {
        if (System.console() != null) {
            return true;
        }
        try {
            Process p = new ProcessBuilder("sh", "-c", "[ -t 0 ] && [ -t 1 ]").start();
            return p.waitFor() == 0;
        } catch (IOException e) {
            return false;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private static void terminalError() {
        System.err.println("serpl error: Something went wrong");
        System.err.println("Error: ");
        System.err.println("   0: \033[91mResource temporarily unavailable (os error 11)\033[0m");
    }

    private static void draw(Path root) {
        System.out.print("\033[2J\033[H");
        System.out.println("serpl");
        System.out.println();
        System.out.println("Search");
        System.out.println("Replace");
        System.out.println();
        System.out.println("Project root: " + root);
        System.out.println();
        System.out.println("Files");
        try {
            if (Files.isDirectory(root)) {
                Files.list(root).limit(12).forEach(path -> System.out.println("  " + path.getFileName()));
            }
        } catch (IOException e) {
            System.out.println("  " + e.getMessage());
        }
        System.out.println();
        System.out.println("Ctrl-d/Ctrl-c/q quit  Ctrl-r refresh");
        System.out.flush();
    }
}
