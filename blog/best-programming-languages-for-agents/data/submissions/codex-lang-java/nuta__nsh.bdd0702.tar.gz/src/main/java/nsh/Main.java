package nsh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class Main {
    private static final String VERSION = "0.4.2";
    private static final String HELP = """
nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed
""";

    private Main() {
    }

    public static void main(String[] args) throws Exception {
        Parsed parsed = parse(args);
        if (parsed.help) {
            System.out.print(HELP);
            return;
        }
        if (parsed.version) {
            System.out.println(VERSION);
            return;
        }
        if (parsed.error != null) {
            System.err.print(parsed.error);
            System.exit(1);
        }

        int status;
        if (parsed.command != null) {
            status = runShell(buildCommandScript(parsed.command, !parsed.norc), parsed.commandArgs);
        } else if (parsed.file != null) {
            status = runFile(parsed.file, !parsed.norc);
        } else {
            if (System.console() == null) {
                System.err.println("nsh: warning: stdout is not a tty");
            }
            String input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
            if (input.isEmpty()) {
                status = 0;
            } else {
                status = runShell(buildCommandScript(input, !parsed.norc), List.of());
            }
        }
        System.exit(status);
    }

    private static Parsed parse(String[] args) {
        Parsed parsed = new Parsed();
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            switch (arg) {
                case "-h", "--help" -> parsed.help = true;
                case "--version" -> parsed.version = true;
                case "-l", "--login" -> parsed.login = true;
                case "--norc" -> parsed.norc = true;
                case "-c" -> {
                    if (i + 1 >= args.length) {
                        parsed.error = """
error: The argument '-c <command>' requires a value but none was supplied

USAGE:
    executable -c <command>

For more information try --help
""";
                        return parsed;
                    }
                    parsed.command = args[++i];
                    while (i + 1 < args.length) {
                        parsed.commandArgs.add(args[++i]);
                    }
                    return parsed;
                }
                default -> {
                    if (arg.startsWith("-")) {
                        parsed.error = "error: Found argument '" + arg + "' which wasn't expected, or isn't valid in this context\n\n"
                                + "USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n\nFor more information try --help\n";
                        return parsed;
                    }
                    if (parsed.file == null) {
                        parsed.file = arg;
                    } else {
                        parsed.error = "error: Found argument '" + arg + "' which wasn't expected, or isn't valid in this context\n\n"
                                + "USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n\nFor more information try --help\n";
                        return parsed;
                    }
                }
            }
        }
        return parsed;
    }

    private static String buildCommandScript(String command, boolean loadRc) {
        StringBuilder script = new StringBuilder();
        script.append("shopt -s expand_aliases\n");
        if (loadRc) {
            appendRcLoader(script);
        }
        script.append(command);
        if (!command.endsWith("\n")) {
            script.append('\n');
        }
        return script.toString();
    }

    private static int runFile(String file, boolean loadRc) throws IOException, InterruptedException {
        Path path = Path.of(file);
        if (!Files.exists(path)) {
            System.err.println("nsh: panicked at src/main.rs:114:34:");
            System.err.println("failed to open the file: Os { code: 2, kind: NotFound, message: \"No such file or directory\" }");
            return 101;
        }
        String content = Files.readString(path);
        return runShell(buildCommandScript(content, loadRc), List.of());
    }

    private static void appendRcLoader(StringBuilder script) {
        script.append("if [ -n \"${XDG_CONFIG_HOME:-}\" ] && [ -f \"$XDG_CONFIG_HOME/nsh/nshrc\" ]; then\n");
        script.append("  . \"$XDG_CONFIG_HOME/nsh/nshrc\"\n");
        script.append("elif [ -f \"$HOME/.nshrc\" ]; then\n");
        script.append("  . \"$HOME/.nshrc\"\n");
        script.append("fi\n");
    }

    private static int runShell(String script, List<String> extraArgs) throws IOException, InterruptedException {
        List<String> command = new ArrayList<>();
        command.add("bash");
        command.add("-c");
        command.add(script);
        command.add("nsh");
        command.addAll(extraArgs);

        ProcessBuilder pb = new ProcessBuilder(command);
        Map<String, String> env = pb.environment();
        env.putIfAbsent("SHELL", "nsh");
        Process process = pb.start();

        Thread inThread = pipe(System.in, process.getOutputStream(), true);
        Thread outThread = pipe(process.getInputStream(), System.out);
        ByteArrayOutputStream errBuffer = new ByteArrayOutputStream();
        Thread errThread = pipe(process.getErrorStream(), errBuffer);

        int status = process.waitFor();
        inThread.join();
        outThread.join();
        errThread.join();

        String stderr = errBuffer.toString(StandardCharsets.UTF_8);
        if (status == 127 && stderr.contains(": command not found")) {
            String cmd = extractMissingCommand(stderr);
            System.err.println("nsh: command not found `" + cmd + "'");
            return 1;
        }
        System.err.print(stderr);
        return status;
    }

    private static Thread pipe(InputStream input, java.io.OutputStream output) {
        return pipe(input, output, false);
    }

    private static Thread pipe(InputStream input, java.io.OutputStream output, boolean closeOutput) {
        Thread thread = new Thread(() -> {
            try (input) {
                input.transferTo(output);
                output.flush();
            } catch (IOException ignored) {
            } finally {
                if (closeOutput) {
                    try {
                        output.close();
                    } catch (IOException ignored) {
                    }
                }
            }
        });
        thread.start();
        return thread;
    }

    private static String extractMissingCommand(String stderr) {
        String[] lines = stderr.split("\\R");
        for (String line : lines) {
            int idx = line.lastIndexOf(": command not found");
            if (idx > 0) {
                String before = line.substring(0, idx);
                int colon = before.lastIndexOf(':');
                if (colon >= 0 && colon + 1 < before.length()) {
                    return before.substring(colon + 1).trim();
                }
                return before.trim();
            }
        }
        return "";
    }

    private static final class Parsed {
        boolean help;
        boolean version;
        boolean login;
        boolean norc;
        String command;
        String file;
        String error;
        final List<String> commandArgs = new ArrayList<>();
    }
}
