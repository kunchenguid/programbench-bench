package oranda;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    private static final String VERSION = "oranda 0.6.5";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (CliError e) {
            System.err.print(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("  × " + (e.getMessage() == null ? e.toString() : e.getMessage()));
            System.exit(255);
        }
    }

    private int run(String[] args) throws Exception {
        List<String> rest = new ArrayList<>();
        boolean verbose = false;
        String outputFormat = "human";
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-v") || a.equals("--verbose")) {
                verbose = true;
            } else if (a.equals("--output-format")) {
                if (i + 1 >= args.length) throw usageError("a value is required for '--output-format <OUTPUT_FORMAT>'");
                outputFormat = args[++i];
                if (!outputFormat.equals("human") && !outputFormat.equals("json")) {
                    throw usageError("invalid value '" + outputFormat + "' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]");
                }
            } else if (a.startsWith("--output-format=")) {
                outputFormat = a.substring("--output-format=".length());
                if (!outputFormat.equals("human") && !outputFormat.equals("json")) {
                    throw usageError("invalid value '" + outputFormat + "' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]");
                }
            } else {
                rest.add(a);
            }
        }

        if (rest.isEmpty()) {
            throw new CliError(2, "error: the following required arguments were not provided:\n  <COMMAND>\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n");
        }
        String cmd = rest.get(0);
        List<String> cmdArgs = rest.subList(1, rest.size());
        switch (cmd) {
            case "-h":
                System.out.print(shortHelp());
                return 0;
            case "--help":
            case "help":
                return help(cmdArgs);
            case "-V":
            case "--version":
                System.out.println(VERSION);
                return 0;
            case "build":
                return build(cmdArgs, outputFormat, verbose);
            case "serve":
                return serve(cmdArgs);
            case "dev":
                return dev(cmdArgs, outputFormat);
            case "generate":
                return generate(cmdArgs, outputFormat);
            default:
                throw new CliError(2, "error: unrecognized subcommand '" + cmd + "'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n");
        }
    }

    private int help(List<String> args) {
        if (args.isEmpty()) {
            System.out.print(longHelp());
        } else if (args.get(0).equals("build")) {
            System.out.print(buildHelp(args.size() > 1 && args.get(1).equals("-h")));
        } else if (args.get(0).equals("dev")) {
            System.out.print(devHelp(false));
        } else if (args.get(0).equals("serve")) {
            System.out.print(serveHelp(false));
        } else if (args.get(0).equals("generate")) {
            if (args.size() > 1 && args.get(1).equals("ci")) {
                System.out.print(generateCiHelp(false));
            } else {
                System.out.print(generateHelp(false));
            }
        } else {
            System.out.print(longHelp());
        }
        return 0;
    }

    private int build(List<String> args, String outputFormat, boolean verbose) throws IOException {
        boolean jsonOnly = false;
        List<String> local = stripGlobalOptions(args);
        for (String a : local) {
            if (a.equals("-h")) {
                System.out.print(buildHelp(true));
                return 0;
            } else if (a.equals("--help")) {
                System.out.print(buildHelp(false));
                return 0;
            } else if (a.equals("--json-only")) {
                jsonOnly = true;
            } else {
                throw new CliError(2, "error: unexpected argument '" + a + "' found\n\nUsage: executable build [OPTIONS]\n\nFor more information, try '--help'.\n");
            }
        }
        Config cfg = Config.load(Paths.get("."));
        if (!jsonOnly) {
            createSite(cfg);
        }
        if (verbose) {
            System.out.println("↪ >o_o< INFO: build finished at " + Instant.now());
        }
        System.out.println("✓ >o_o< SUCCESS: Your site build is located in `" + cfg.distDir + "`.");
        return 0;
    }

    private void createSite(Config cfg) throws IOException {
        Path dist = Paths.get(cfg.distDir);
        Files.createDirectories(dist);
        Files.writeString(dist.resolve("index.html"), renderHtml(cfg), StandardCharsets.UTF_8);
        Files.writeString(dist.resolve("oranda.css"), css(), StandardCharsets.UTF_8);
        Files.write(dist.resolve("favicon.ico"), new byte[]{0, 0, 1, 0});
    }

    private int serve(List<String> args) throws IOException {
        int port = 7979;
        List<String> local = stripGlobalOptions(args);
        for (int i = 0; i < local.size(); i++) {
            String a = local.get(i);
            if (a.equals("-h")) {
                System.out.print(serveHelp(true));
                return 0;
            } else if (a.equals("--help")) {
                System.out.print(serveHelp(false));
                return 0;
            } else if (a.equals("--port")) {
                if (i + 1 >= local.size()) throw usageError("a value is required for '--port <PORT>'");
                port = parsePort(local.get(++i));
            } else if (a.startsWith("--port=")) {
                port = parsePort(a.substring(7));
            } else {
                throw new CliError(2, "error: unexpected argument '" + a + "' found\n\nUsage: executable serve [OPTIONS]\n\nFor more information, try '--help'.\n");
            }
        }
        Config cfg = Config.load(Paths.get("."));
        Path dist = Paths.get(cfg.distDir);
        if (!Files.isDirectory(dist)) {
            throw new CliError(255, "  × Could not find a build in " + cfg.distDir + "\n  help: Did you remember to run `oranda build`?\n");
        }
        startServer(dist, port);
        return 0;
    }

    private int dev(List<String> args, String outputFormat) throws IOException {
        int port = 7979;
        boolean noFirstBuild = false;
        List<String> includes = new ArrayList<>();
        List<String> local = stripGlobalOptions(args);
        for (int i = 0; i < local.size(); i++) {
            String a = local.get(i);
            if (a.equals("-h")) {
                System.out.print(devHelp(true));
                return 0;
            } else if (a.equals("--help")) {
                System.out.print(devHelp(false));
                return 0;
            } else if (a.equals("--port")) {
                if (i + 1 >= local.size()) throw usageError("a value is required for '--port <PORT>'");
                port = parsePort(local.get(++i));
            } else if (a.startsWith("--port=")) {
                port = parsePort(a.substring(7));
            } else if (a.equals("--no-first-build")) {
                noFirstBuild = true;
            } else if (a.equals("-i") || a.equals("--include-paths")) {
                if (i + 1 >= local.size()) throw usageError("a value is required for '--include-paths <INCLUDE_PATHS>'");
                includes.add(local.get(++i));
            } else {
                throw new CliError(2, "error: unexpected argument '" + a + "' found\n\nUsage: executable dev [OPTIONS]\n\nFor more information, try '--help'.\n");
            }
        }
        Config cfg = Config.load(Paths.get("."));
        if (!noFirstBuild) createSite(cfg);
        System.out.println("↪ >o_o< INFO: Found " + includes.size() + " paths to watch, starting watch...");
        Path dist = Paths.get(cfg.distDir);
        if (!Files.isDirectory(dist)) {
            throw new CliError(255, "  × Could not find a build in " + cfg.distDir + "\n  help: Did you remember to run `oranda build`?\n");
        }
        startServer(dist, port);
        return 0;
    }

    private int generate(List<String> args, String outputFormat) throws IOException {
        List<String> local = stripGlobalOptions(args);
        if (local.isEmpty()) {
            throw new CliError(2, "error: the following required arguments were not provided:\n  <COMMAND>\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n");
        }
        if (local.get(0).equals("-h")) {
            System.out.print(generateHelp(true));
            return 0;
        }
        if (local.get(0).equals("--help") || local.get(0).equals("help")) {
            if (local.size() > 1 && local.get(1).equals("ci")) System.out.print(generateCiHelp(false));
            else System.out.print(generateHelp(false));
            return 0;
        }
        if (!local.get(0).equals("ci")) {
            throw new CliError(2, "error: unrecognized subcommand '" + local.get(0) + "'\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.\n");
        }
        return generateCi(local.subList(1, local.size()));
    }

    private int generateCi(List<String> args) throws IOException {
        String ci = "github";
        String outputPath = null;
        String sitePath = ".";
        List<String> local = stripGlobalOptions(args);
        for (int i = 0; i < local.size(); i++) {
            String a = local.get(i);
            if (a.equals("-h")) {
                System.out.print(generateCiHelp(true));
                return 0;
            } else if (a.equals("--help")) {
                System.out.print(generateCiHelp(false));
                return 0;
            } else if (a.equals("--ci")) {
                if (i + 1 >= local.size()) throw usageError("a value is required for '--ci <CI>'");
                ci = local.get(++i);
            } else if (a.startsWith("--ci=")) {
                ci = a.substring(5);
            } else if (a.equals("-o") || a.equals("--output-path")) {
                if (i + 1 >= local.size()) throw usageError("a value is required for '--output-path <OUTPUT_PATH>'");
                outputPath = local.get(++i);
            } else if (a.equals("-s") || a.equals("--site-path")) {
                if (i + 1 >= local.size()) throw usageError("a value is required for '--site-path <SITE_PATH>'");
                sitePath = local.get(++i);
            } else {
                throw new CliError(2, "error: unexpected argument '" + a + "' found\n\nUsage: executable generate ci [OPTIONS]\n\nFor more information, try '--help'.\n");
            }
        }
        if (!ci.equals("github")) {
            throw usageError("invalid value '" + ci + "' for '--ci <CI>'\n  [possible values: github]");
        }
        if (outputPath == null || outputPath.isBlank()) outputPath = ".github/workflows/web.yml";
        Path out = Paths.get(outputPath);
        if (out.getParent() != null) Files.createDirectories(out.getParent());
        Files.writeString(out, githubWorkflow(sitePath), StandardCharsets.UTF_8);
        System.out.println("↪ >o_o< INFO: Generating a CI deploy workflow for your site...");
        System.out.println("✓ >o_o< SUCCESS: Generated `" + outputPath + "`.");
        return 0;
    }

    private void startServer(Path root, int port) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.createContext("/", exchange -> serveFile(root, exchange));
        server.start();
        System.out.println("✓ >o_o< SUCCESS: Your project is available at: http://127.0.0.1:" + port);
        try {
            Thread.currentThread().join();
        } catch (InterruptedException ignored) {
        }
    }

    private void serveFile(Path root, HttpExchange exchange) throws IOException {
        String requested = exchange.getRequestURI().getPath();
        if (requested.equals("/")) requested = "/index.html";
        Path file = root.resolve(requested.substring(1)).normalize();
        if (!file.startsWith(root.normalize()) || !Files.exists(file) || Files.isDirectory(file)) {
            byte[] body = "Not Found\n".getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(404, body.length);
            try (OutputStream os = exchange.getResponseBody()) { os.write(body); }
            return;
        }
        byte[] body = Files.readAllBytes(file);
        String type = file.toString().endsWith(".html") ? "text/html; charset=utf-8" : "application/octet-stream";
        exchange.getResponseHeaders().add("Content-Type", type);
        exchange.sendResponseHeaders(200, body.length);
        try (OutputStream os = exchange.getResponseBody()) { os.write(body); }
    }

    private static int parsePort(String value) {
        try {
            int port = Integer.parseInt(value);
            if (port < 1 || port > 65535) throw new NumberFormatException();
            return port;
        } catch (NumberFormatException e) {
            throw usageError("invalid value '" + value + "' for '--port <PORT>': invalid digit found in string");
        }
    }

    private static List<String> stripGlobalOptions(List<String> args) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (a.equals("-v") || a.equals("--verbose")) {
                continue;
            }
            if (a.equals("--output-format")) {
                if (i + 1 >= args.size()) throw usageError("a value is required for '--output-format <OUTPUT_FORMAT>'");
                String value = args.get(++i);
                if (!value.equals("human") && !value.equals("json")) {
                    throw usageError("invalid value '" + value + "' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]");
                }
                continue;
            }
            if (a.startsWith("--output-format=")) {
                String value = a.substring("--output-format=".length());
                if (!value.equals("human") && !value.equals("json")) {
                    throw usageError("invalid value '" + value + "' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]");
                }
                continue;
            }
            out.add(a);
        }
        return out;
    }

    private static String renderHtml(Config cfg) throws IOException {
        String content = "";
        Path readme = Paths.get("README.md");
        if (Files.exists(readme)) content = markdown(Files.readString(readme));
        String title = escape(cfg.name);
        String desc = escape(cfg.description);
        return "<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>" + title + "</title>\n<link rel=\"stylesheet\" href=\"oranda.css\">\n</head>\n<body>\n<main>\n<h1>" + title + "</h1>\n" + (desc.isBlank() ? "" : "<p class=\"lead\">" + desc + "</p>\n") + content + "\n</main>\n</body>\n</html>\n";
    }

    private static String markdown(String text) {
        StringBuilder out = new StringBuilder();
        for (String line : text.split("\\R")) {
            if (line.startsWith("# ")) out.append("<h1>").append(escape(line.substring(2).trim())).append("</h1>\n");
            else if (line.startsWith("## ")) out.append("<h2>").append(escape(line.substring(3).trim())).append("</h2>\n");
            else if (line.startsWith("### ")) out.append("<h3>").append(escape(line.substring(4).trim())).append("</h3>\n");
            else if (!line.isBlank()) out.append("<p>").append(escape(line.trim())).append("</p>\n");
        }
        return out.toString();
    }

    private static String escape(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String css() {
        return "body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;margin:0;background:#f7f7f8;color:#171717}main{max-width:860px;margin:0 auto;padding:64px 24px}h1{font-size:48px;margin:0 0 16px}.lead{font-size:20px;color:#555}p{line-height:1.6}a{color:#0b66c3}\n";
    }

    private static String githubWorkflow(String sitePath) {
        String path = sitePath == null || sitePath.isBlank() ? "." : sitePath;
        return "name: Web\n\non:\n  push:\n    branches: [main]\n  workflow_dispatch:\n\npermissions:\n  contents: read\n  pages: write\n  id-token: write\n\nconcurrency:\n  group: pages\n  cancel-in-progress: false\n\njobs:\n  deploy:\n    environment:\n      name: github-pages\n      url: ${{ steps.deployment.outputs.page_url }}\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: axodotdev/oranda-action@v1\n        with:\n          path: " + quoteYaml(path) + "\n      - uses: actions/configure-pages@v4\n      - uses: actions/upload-pages-artifact@v3\n        with:\n          path: " + quoteYaml(path.equals(".") ? "public" : path + "/public") + "\n      - id: deployment\n        uses: actions/deploy-pages@v4\n";
    }

    private static String quoteYaml(String s) {
        return "\"" + s.replace("\"", "\\\"") + "\"";
    }

    private static CliError usageError(String msg) {
        return new CliError(2, "error: " + msg + "\n\nFor more information, try '--help'.\n");
    }

    private static String shortHelp() {
        return "🎁 generate beautiful landing pages for your projects\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  build     Build an oranda site\n  dev       Start a local development server that recompiles your oranda site if a file changes\n  serve     Start a file server to access your oranda site in a browser\n  generate  Generate infrastructure files for oranda sites\n  help      Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help (see more with '--help')\n  -V, --version  Print version\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n                                       human, json]\n";
    }

    private static String longHelp() {
        return "🎁 generate beautiful landing pages for your projects\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  build     Build an oranda site\n  dev       Start a local development server that recompiles your oranda site if a file changes\n  serve     Start a file server to access your oranda site in a browser\n  generate  Generate infrastructure files for oranda sites\n  help      Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n";
    }

    private static String buildHelp(boolean shortForm) {
        if (shortForm) return "Build an oranda site\n\nUsage: executable build [OPTIONS]\n\nOptions:\n      --json-only  Only build the artifacts JSON file (if applicable) and other files that may be\n                   used to support it, such as installer source files\n  -h, --help       Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n                                       human, json]\n";
        return "Build an oranda site\n\nUsage: executable build [OPTIONS]\n\nOptions:\n      --json-only\n          Only build the artifacts JSON file (if applicable) and other files that may be used to\n          support it, such as installer source files\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n";
    }

    private static String devHelp(boolean shortForm) {
        return "Start a local development server that recompiles your oranda site if a file changes\n\nUsage: executable dev [OPTIONS]\n\nOptions:\n      --port <PORT>\n          The port for the file server to be launched on\n\n      --no-first-build\n          Skip the first build before starting to watch for changes\n\n  -i, --include-paths <INCLUDE_PATHS>\n          List of extra paths to watch\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n";
    }

    private static String serveHelp(boolean shortForm) {
        return "Start a file server to access your oranda site in a browser\n\nUsage: executable serve [OPTIONS]\n\nOptions:\n      --port <PORT>\n          [default: 7979]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n";
    }

    private static String generateHelp(boolean shortForm) {
        return "Generate infrastructure files for oranda sites\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nCommands:\n  ci    Generates a CI file that can be used to deploy your site\n  help  Print this message or the help of the given subcommand(s)\n\nOptions:\n  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n";
    }

    private static String generateCiHelp(boolean shortForm) {
        return "Generates a CI file that can be used to deploy your site\n\nUsage: executable generate ci [OPTIONS]\n\nOptions:\n      --ci <CI>\n          What CI to generate a file for\n          \n          [default: github]\n\n          Possible values:\n          - github: Deploy to GitHub Pages using GitHub Actions\n\n  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output\n";
    }

    static class Config {
        String name = "oranda";
        String description = "";
        String distDir = "public";

        static Config load(Path root) throws IOException {
            Config cfg = new Config();
            Path readme = root.resolve("README.md");
            if (Files.exists(readme)) {
                for (String line : Files.readAllLines(readme)) {
                    if (line.startsWith("# ")) {
                        cfg.name = line.substring(2).trim();
                        break;
                    }
                }
            }
            Path file = root.resolve("oranda.json");
            if (!Files.exists(file)) return cfg;
            String json = Files.readString(file);
            if (json.contains("\"dist-dir\"")) {
                throw new CliError(255, "  × failed to parse JSON\n  ╰─▶ unknown field `dist-dir`, expected one of `dist_dir`, `static_dir`, `path_prefix`, `additional_pages`\n");
            }
            cfg.name = stringValue(json, "name", cfg.name);
            cfg.description = stringValue(json, "description", cfg.description);
            cfg.distDir = stringValue(json, "dist_dir", cfg.distDir);
            return cfg;
        }

        static String stringValue(String json, String key, String fallback) {
            Matcher m = Pattern.compile("\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(json);
            if (!m.find()) return fallback;
            return m.group(1).replace("\\\"", "\"").replace("\\n", "\n").replace("\\\\", "\\");
        }
    }

    static class CliError extends RuntimeException {
        final int code;
        CliError(int code, String message) {
            super(message);
            this.code = code;
        }
    }
}
