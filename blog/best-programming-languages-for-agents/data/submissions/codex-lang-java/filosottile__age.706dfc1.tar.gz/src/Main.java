import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Base64;

public class Main {
    static final String VERSION = "v0.0.0-20260414014000-96fce988442d";
    static final byte[] INFO_X25519 = "age-encryption.org/v1/X25519".getBytes(StandardCharsets.US_ASCII);
    static final int CHUNK = 64 * 1024;
    static final SecureRandom RNG = new SecureRandom();

    public static void main(String[] args) {
        try {
            new Main().run(args);
        } catch (AgeError e) {
            System.err.println("age: error: " + e.getMessage());
            System.err.println("age: report unexpected or unhelpful errors at https://filippo.io/age/report");
            System.exit(1);
        } catch (Exception e) {
            System.err.println("age: error: " + e.getMessage());
            System.err.println("age: report unexpected or unhelpful errors at https://filippo.io/age/report");
            System.exit(1);
        }
    }

    void run(String[] args) throws Exception {
        List<String> recipients = new ArrayList<>(), recFiles = new ArrayList<>(), ids = new ArrayList<>(), positionals = new ArrayList<>();
        boolean decrypt = false, encryptExplicit = false, armor = false, passphrase = false, keygenY = false, pq = false;
        String output = null;
        String argv0 = System.getProperty("argv0", System.getenv("_"));
        boolean keygen = argv0 != null && argv0.endsWith("age-keygen");
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-h")) { usage(); return; }
            if (a.equals("--version") || a.equals("-version") || a.equals("-v")) { System.out.println(VERSION); return; }
            if (a.equals("-d") || a.equals("--decrypt")) decrypt = true;
            else if (a.equals("-e") || a.equals("--encrypt")) encryptExplicit = true;
            else if (a.equals("-a") || a.equals("--armor")) armor = true;
            else if (a.equals("-p") || a.equals("--passphrase")) passphrase = true;
            else if (a.equals("-pq")) { pq = true; keygen = true; }
            else if (a.equals("-y")) { keygenY = true; keygen = true; }
            else if (a.equals("-r") || a.equals("--recipient")) recipients.add(need(args, ++i, a));
            else if (a.startsWith("--recipient=")) recipients.add(a.substring(12));
            else if (a.equals("-R") || a.equals("--recipients-file")) recFiles.add(need(args, ++i, a));
            else if (a.startsWith("--recipients-file=")) recFiles.add(a.substring(18));
            else if (a.equals("-i") || a.equals("--identity")) ids.add(need(args, ++i, a));
            else if (a.startsWith("--identity=")) ids.add(a.substring(11));
            else if (a.equals("-o") || a.equals("--output")) output = need(args, ++i, a);
            else if (a.startsWith("--output=")) output = a.substring(9);
            else if (a.startsWith("-") && !a.equals("-")) throw new AgeError("unknown flag: " + a);
            else positionals.add(a);
        }
        if (keygen) { runKeygen(keygenY, pq, output, positionals); return; }
        if (positionals.size() > 1) throw new AgeError("too many arguments");
        byte[] input = readInput(positionals.isEmpty() ? null : positionals.get(0));
        if (decrypt) {
            List<byte[]> secrets = new ArrayList<>();
            for (String p : ids) secrets.addAll(readIdentities(p));
            byte[] plain = decrypt(input, secrets);
            writeOutput(output, plain);
        } else {
            if (passphrase) throw new AgeError("passphrase encryption is not supported by this reimplementation");
            if (!ids.isEmpty() && !encryptExplicit) throw new AgeError("-i/--identity can only be used with -e/--encrypt");
            List<byte[]> pubs = new ArrayList<>();
            for (String r : recipients) pubs.add(parseRecipient(r));
            for (String p : recFiles) for (String line : readLines(p)) pubs.add(parseRecipient(line));
            for (String p : ids) for (byte[] s : readIdentities(p)) pubs.add(X25519.scalarMultBase(s));
            if (pubs.isEmpty()) { usage(); return; }
            byte[] out = encrypt(input, pubs, armor);
            writeOutput(output, out);
        }
    }

    static String need(String[] args, int i, String flag) throws AgeError {
        if (i >= args.length) throw new AgeError("missing argument for " + flag);
        return args[i];
    }

    static void usage() {
        System.out.print("""
Usage:
    age [--encrypt] (-r RECIPIENT | -R PATH)... [--armor] [-o OUTPUT] [INPUT]
    age [--encrypt] --passphrase [--armor] [-o OUTPUT] [INPUT]
    age --decrypt [-i PATH]... [-o OUTPUT] [INPUT]

Options:
    -e, --encrypt               Encrypt the input to the output. Default if omitted.
    -d, --decrypt               Decrypt the input to the output.
    -o, --output OUTPUT         Write the result to the file at path OUTPUT.
    -a, --armor                 Encrypt to a PEM encoded format.
    -p, --passphrase            Encrypt with a passphrase.
    -r, --recipient RECIPIENT   Encrypt to the specified RECIPIENT. Can be repeated.
    -R, --recipients-file PATH  Encrypt to recipients listed at PATH. Can be repeated.
    -i, --identity PATH         Use the identity file at PATH. Can be repeated.

INPUT defaults to standard input, and OUTPUT defaults to standard output.
If OUTPUT exists, it will be overwritten.

RECIPIENT can be an age public key generated by age-keygen ("age1...")
or an SSH public key ("ssh-ed25519 AAAA...", "ssh-rsa AAAA...").
""");
    }

    void runKeygen(boolean y, boolean pq, String output, List<String> pos) throws Exception {
        if (pq) throw new AgeError("post-quantum keys are not supported by this reimplementation");
        if (y) {
            if (pos.size() > 1) throw new AgeError("too many arguments");
            List<byte[]> ids = readIdentities(pos.isEmpty() ? "-" : pos.get(0));
            StringBuilder sb = new StringBuilder();
            for (byte[] s : ids) sb.append(Bech32.encode("age", X25519.scalarMultBase(s))).append('\n');
            writeOutput(output, sb.toString().getBytes(StandardCharsets.UTF_8));
            return;
        }
        if (!pos.isEmpty()) throw new AgeError("too many arguments");
        byte[] s = new byte[32]; RNG.nextBytes(s);
        byte[] pub = X25519.scalarMultBase(s);
        String rec = Bech32.encode("age", pub);
        String sec = Bech32.encode("age-secret-key-", s).toUpperCase(Locale.ROOT);
        String body = "# created: " + OffsetDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) + "\n# public key: " + rec + "\n" + sec + "\n";
        writeOutput(output, body.getBytes(StandardCharsets.UTF_8), false);
        if (output != null) System.err.println("Public key: " + rec);
    }

    static byte[] encrypt(byte[] plaintext, List<byte[]> pubs, boolean armor) throws Exception {
        byte[] fileKey = new byte[16]; RNG.nextBytes(fileKey);
        StringBuilder h = new StringBuilder("age-encryption.org/v1\n");
        for (byte[] pub : pubs) {
            byte[] eph = new byte[32]; RNG.nextBytes(eph);
            byte[] ephPub = X25519.scalarMultBase(eph);
            byte[] shared = X25519.scalarMult(eph, pub);
            byte[] salt = concat(ephPub, pub);
            byte[] wrap = hkdf(shared, salt, INFO_X25519, 32);
            byte[] encKey = aead(true, wrap, new byte[12], fileKey, new byte[0]);
            h.append("-> X25519 ").append(b64(ephPub)).append('\n');
            h.append(b64(encKey)).append('\n');
        }
        String headerNoMac = h + "---";
        byte[] macKey = hkdf(fileKey, null, "header".getBytes(StandardCharsets.US_ASCII), 32);
        byte[] mac = hmac(macKey, headerNoMac.getBytes(StandardCharsets.US_ASCII));
        String header = headerNoMac + " " + b64(mac) + "\n";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(header.getBytes(StandardCharsets.US_ASCII));
        byte[] payloadKey = hkdf(fileKey, null, "payload".getBytes(StandardCharsets.US_ASCII), 32);
        int chunks = (plaintext.length + CHUNK - 1) / CHUNK;
        if (plaintext.length == 0) chunks = 1;
        for (int i = 0, off = 0; i < chunks; i++) {
            int n = Math.min(CHUNK, plaintext.length - off);
            if (n < 0) n = 0;
            byte[] nonce = streamNonce(i, i == chunks - 1);
            out.write(aead(true, payloadKey, nonce, Arrays.copyOfRange(plaintext, off, off + n), new byte[0]));
            off += n;
        }
        byte[] raw = out.toByteArray();
        return armor ? armor(raw).getBytes(StandardCharsets.US_ASCII) : raw;
    }

    static byte[] decrypt(byte[] input, List<byte[]> secrets) throws Exception {
        byte[] raw = dearmorIfNeeded(input);
        int p = 0;
        String magic = "age-encryption.org/v1\n";
        if (raw.length < magic.length() || !new String(raw, 0, magic.length(), StandardCharsets.US_ASCII).equals(magic))
            throw new AgeError("failed to read header: unexpected intro");
        p = magic.length();
        List<Stanza> stanzas = new ArrayList<>();
        int macLineStart = -1, bodyStart = -1;
        while (p < raw.length) {
            int nl = indexOf(raw, (byte)'\n', p);
            if (nl < 0) throw new AgeError("failed to read header");
            String line = new String(raw, p, nl - p, StandardCharsets.US_ASCII);
            if (line.startsWith("-> ")) {
                String[] parts = line.split(" ");
                if (parts.length < 3) throw new AgeError("malformed recipient stanza");
                int nl2 = indexOf(raw, (byte)'\n', nl + 1);
                if (nl2 < 0) throw new AgeError("failed to read header");
                String body = new String(raw, nl + 1, nl2 - nl - 1, StandardCharsets.US_ASCII);
                stanzas.add(new Stanza(parts[1], parts[2], body));
                p = nl2 + 1;
            } else if (line.startsWith("--- ")) {
                macLineStart = p;
                bodyStart = nl + 1;
                break;
            } else throw new AgeError("malformed header");
        }
        if (bodyStart < 0) throw new AgeError("failed to read header");
        byte[] fileKey = null;
        for (Stanza s : stanzas) {
            if (!s.type.equals("X25519")) continue;
            byte[] eph = Base64.getDecoder().decode(s.arg);
            byte[] enc = Base64.getDecoder().decode(s.body);
            for (byte[] sec : secrets) {
                byte[] pub = X25519.scalarMultBase(sec);
                byte[] shared = X25519.scalarMult(sec, eph);
                byte[] wrap = hkdf(shared, concat(eph, pub), INFO_X25519, 32);
                try {
                    fileKey = aead(false, wrap, new byte[12], enc, new byte[0]);
                    break;
                } catch (Exception ignored) {}
            }
            if (fileKey != null) break;
        }
        if (fileKey == null) throw new AgeError("no identity matched any of the recipients");
        byte[] macKey = hkdf(fileKey, null, "header".getBytes(StandardCharsets.US_ASCII), 32);
        byte[] want = hmac(macKey, Arrays.copyOfRange(raw, 0, macLineStart + 3));
        String macB64 = new String(raw, macLineStart + 4, bodyStart - macLineStart - 5, StandardCharsets.US_ASCII);
        if (!Arrays.equals(want, Base64.getDecoder().decode(macB64))) throw new AgeError("bad header MAC");
        byte[] payloadKey = hkdf(fileKey, null, "payload".getBytes(StandardCharsets.US_ASCII), 32);
        ByteArrayOutputStream plain = new ByteArrayOutputStream();
        int off = bodyStart, idx = 0;
        while (off < raw.length) {
            int remaining = raw.length - off;
            boolean last = remaining <= CHUNK + 16;
            int clen = last ? remaining : CHUNK + 16;
            byte[] chunk = Arrays.copyOfRange(raw, off, off + clen);
            plain.write(aead(false, payloadKey, streamNonce(idx, last), chunk, new byte[0]));
            off += clen; idx++;
            if (last && off != raw.length) throw new AgeError("trailing data");
        }
        return plain.toByteArray();
    }

    static byte[] streamNonce(int idx, boolean last) {
        byte[] n = new byte[12];
        long v = idx;
        for (int i = 10; i >= 3; i--) { n[i] = (byte)v; v >>>= 8; }
        n[11] = (byte)(last ? 1 : 0);
        return n;
    }

    static byte[] aead(boolean enc, byte[] key, byte[] nonce, byte[] in, byte[] aad) throws Exception {
        Cipher c = Cipher.getInstance("ChaCha20-Poly1305");
        c.init(enc ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, new SecretKeySpec(key, "ChaCha20"), new IvParameterSpec(nonce));
        if (aad.length > 0) c.updateAAD(aad);
        return c.doFinal(in);
    }

    static byte[] hkdf(byte[] ikm, byte[] salt, byte[] info, int len) throws Exception {
        if (salt == null) salt = new byte[32];
        byte[] prk = hmac(salt, ikm);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] t = new byte[0]; int c = 1;
        while (out.size() < len) {
            ByteArrayOutputStream msg = new ByteArrayOutputStream();
            msg.write(t); msg.write(info); msg.write(c++);
            t = hmac(prk, msg.toByteArray());
            out.write(t);
        }
        return Arrays.copyOf(out.toByteArray(), len);
    }
    static byte[] hmac(byte[] key, byte[] msg) throws Exception {
        Mac m = Mac.getInstance("HmacSHA256");
        m.init(new SecretKeySpec(key, "HmacSHA256"));
        return m.doFinal(msg);
    }
    static String b64(byte[] b) { return Base64.getEncoder().withoutPadding().encodeToString(b); }
    static byte[] concat(byte[] a, byte[] b) { byte[] c = Arrays.copyOf(a, a.length + b.length); System.arraycopy(b,0,c,a.length,b.length); return c; }
    static int indexOf(byte[] a, byte b, int s) { for (int i=s;i<a.length;i++) if (a[i]==b) return i; return -1; }

    static byte[] readInput(String path) throws IOException {
        if (path == null || path.equals("-")) return System.in.readAllBytes();
        return Files.readAllBytes(Path.of(path));
    }
    static void writeOutput(String path, byte[] data) throws IOException { writeOutput(path, data, true); }
    static void writeOutput(String path, byte[] data, boolean overwrite) throws IOException {
        if (path == null || path.equals("-")) System.out.write(data);
        else {
            OpenOption[] opts = overwrite ? new OpenOption[]{StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE}
                    : new OpenOption[]{StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE};
            Files.write(Path.of(path), data, opts);
        }
    }
    static List<String> readLines(String path) throws IOException {
        String s = path.equals("-") ? new String(System.in.readAllBytes(), StandardCharsets.UTF_8) : Files.readString(Path.of(path));
        List<String> out = new ArrayList<>();
        for (String l : s.split("\\R")) { l = l.trim(); if (!l.isEmpty() && !l.startsWith("#")) out.add(l); }
        return out;
    }
    static List<byte[]> readIdentities(String path) throws Exception {
        List<byte[]> out = new ArrayList<>();
        for (String l : readLines(path)) if (l.toUpperCase(Locale.ROOT).startsWith("AGE-SECRET-KEY-1")) out.add(parseIdentity(l));
        return out;
    }
    static byte[] parseRecipient(String s) throws Exception {
        s = s.trim();
        if (s.startsWith("age1") && !s.startsWith("age1pq1")) {
            byte[] b = Bech32.decode("age", s);
            if (b.length != 32) throw new AgeError("invalid recipient length");
            return b;
        }
        if (s.startsWith("ssh-")) throw new AgeError("ssh recipients are not supported by this reimplementation");
        throw new AgeError("unknown recipient type: \"" + s + "\"");
    }
    static byte[] parseIdentity(String s) throws Exception {
        byte[] b = Bech32.decode("age-secret-key-", s.toLowerCase(Locale.ROOT));
        if (b.length != 32) throw new AgeError("invalid identity length");
        return b;
    }
    static String armor(byte[] raw) {
        String b = Base64.getMimeEncoder(64, "\n".getBytes(StandardCharsets.US_ASCII)).encodeToString(raw);
        return "-----BEGIN AGE ENCRYPTED FILE-----\n" + b + "\n-----END AGE ENCRYPTED FILE-----\n";
    }
    static byte[] dearmorIfNeeded(byte[] in) {
        String s = new String(in, StandardCharsets.US_ASCII).trim();
        String begin = "-----BEGIN AGE ENCRYPTED FILE-----", end = "-----END AGE ENCRYPTED FILE-----";
        if (s.startsWith(begin)) {
            int e = s.indexOf(end);
            String body = s.substring(begin.length(), e).replaceAll("\\s+", "");
            return Base64.getDecoder().decode(body);
        }
        return in;
    }

    record Stanza(String type, String arg, String body) {}
    static class AgeError extends Exception { AgeError(String m) { super(m); } }

    static class Bech32 {
        static final String CH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
        static String encode(String hrp, byte[] data) {
            byte[] five = convert(data, 8, 5, true);
            int[] vals = new int[five.length + 6];
            for (int i=0;i<five.length;i++) vals[i]=five[i];
            int[] chk = checksum(hrp, vals);
            StringBuilder sb = new StringBuilder(hrp).append('1');
            for (byte b : five) sb.append(CH.charAt(b));
            for (int c : chk) sb.append(CH.charAt(c));
            return sb.toString();
        }
        static byte[] decode(String hrp, String s) throws AgeError {
            if (!s.equals(s.toLowerCase(Locale.ROOT)) && !s.equals(s.toUpperCase(Locale.ROOT))) throw new AgeError("mixed case bech32 string");
            s = s.toLowerCase(Locale.ROOT);
            int pos = s.lastIndexOf('1');
            if (pos < 1 || !s.substring(0,pos).equals(hrp)) throw new AgeError("invalid bech32 prefix");
            int[] vals = new int[s.length()-pos-1];
            for (int i=0;i<vals.length;i++) { int v=CH.indexOf(s.charAt(pos+1+i)); if (v<0) throw new AgeError("invalid bech32 character"); vals[i]=v; }
            if (!verify(hrp, vals)) throw new AgeError("invalid bech32 checksum");
            byte[] payload = new byte[vals.length-6];
            for (int i=0;i<payload.length;i++) payload[i]=(byte)vals[i];
            return convert(payload,5,8,false);
        }
        static byte[] convert(byte[] data, int from, int to, boolean pad) {
            int acc=0,bits=0,max=(1<<to)-1; ByteArrayOutputStream out = new ByteArrayOutputStream();
            for(byte value:data){ int v=value & 0xff; acc=(acc<<from)|v; bits+=from; while(bits>=to){ bits-=to; out.write((acc>>bits)&max); } }
            if(pad && bits>0) out.write((acc<<(to-bits))&max);
            return out.toByteArray();
        }
        static int polymod(int[] vals) {
            int chk=1; int[] gen={0x3b6a57b2,0x26508e6d,0x1ea119fa,0x3d4233dd,0x2a1462b3};
            for(int v:vals){ int top=chk>>>25; chk=(chk&0x1ffffff)<<5 ^ v; for(int i=0;i<5;i++) if(((top>>>i)&1)==1) chk^=gen[i]; }
            return chk;
        }
        static int[] expand(String hrp) {
            int[] out = new int[hrp.length()*2+1]; int p=0;
            for(char c:hrp.toCharArray()) out[p++]=c>>>5; out[p++]=0; for(char c:hrp.toCharArray()) out[p++]=c&31; return out;
        }
        static int[] checksum(String hrp, int[] vals) {
            int[] ex=expand(hrp), all=new int[ex.length+vals.length]; System.arraycopy(ex,0,all,0,ex.length); System.arraycopy(vals,0,all,ex.length,vals.length);
            int mod=polymod(all)^1; int[] ret=new int[6]; for(int i=0;i<6;i++) ret[i]=(mod>>(5*(5-i)))&31; return ret;
        }
        static boolean verify(String hrp, int[] vals) {
            int[] ex=expand(hrp), all=new int[ex.length+vals.length]; System.arraycopy(ex,0,all,0,ex.length); System.arraycopy(vals,0,all,ex.length,vals.length);
            return polymod(all)==1;
        }
    }

    static class X25519 {
        static final BigInteger P = BigInteger.ONE.shiftLeft(255).subtract(BigInteger.valueOf(19));
        static final BigInteger A24 = BigInteger.valueOf(121665);
        static final byte[] BASE = new byte[32];
        static { BASE[0] = 9; }
        static byte[] scalarMultBase(byte[] k) { return scalarMult(k, BASE); }
        static byte[] scalarMult(byte[] scalar, byte[] uBytes) {
            byte[] k = Arrays.copyOf(scalar, 32);
            k[0] &= 248; k[31] &= 127; k[31] |= 64;
            BigInteger x1 = leToInt(uBytes).mod(P);
            BigInteger x2=BigInteger.ONE,z2=BigInteger.ZERO,x3=x1,z3=BigInteger.ONE;
            int swap=0;
            for(int t=254;t>=0;t--){
                int kt=(k[t>>>3] >>> (t&7)) & 1; swap ^= kt;
                if(swap==1){ BigInteger tmp=x2;x2=x3;x3=tmp; tmp=z2;z2=z3;z3=tmp; }
                swap=kt;
                BigInteger A=x2.add(z2).mod(P), AA=A.multiply(A).mod(P);
                BigInteger B=x2.subtract(z2).mod(P), BB=B.multiply(B).mod(P);
                BigInteger E=AA.subtract(BB).mod(P);
                BigInteger C=x3.add(z3).mod(P), D=x3.subtract(z3).mod(P);
                BigInteger DA=D.multiply(A).mod(P), CB=C.multiply(B).mod(P);
                x3=DA.add(CB).mod(P).pow(2).mod(P);
                z3=x1.multiply(DA.subtract(CB).mod(P).pow(2).mod(P)).mod(P);
                x2=AA.multiply(BB).mod(P);
                z2=E.multiply(AA.add(A24.multiply(E)).mod(P)).mod(P);
            }
            if(swap==1){ BigInteger tmp=x2;x2=x3;x3=tmp; tmp=z2;z2=z3;z3=tmp; }
            return intToLe(x2.multiply(z2.modInverse(P)).mod(P));
        }
        static BigInteger leToInt(byte[] b) {
            byte[] rev = new byte[b.length+1];
            for(int i=0;i<b.length;i++) rev[i + 1]=b[b.length-1-i];
            return new BigInteger(1, rev);
        }
        static byte[] intToLe(BigInteger x) {
            byte[] be=x.toByteArray(), out=new byte[32];
            for(int i=0;i<32;i++){ int bi=be.length-1-i; out[i]=bi>=0?be[bi]:0; }
            return out;
        }
    }
}
