import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static final String VERSION = "peco version v0.5.11 (built with go1.25.0)";
    static final String HELP = "\n" +
"Usage: peco [options] [FILE]\n\n" +
"Options:\n" +
"  -h, --help            show this help message and exit\n" +
"  --query               initial value for query\n" +
"  --rcfile              path to the settings file\n" +
"  --version             print the version and exit\n" +
"  -b, --buffer-size     number of lines to keep in search buffer\n" +
"  --null                expect NUL (\\0) as separator for target/output\n" +
"  --initial-index       position of the initial index of the selection (0 base)\n" +
"  --initial-filter      specify the default filter\n" +
"  --prompt              specify the prompt string\n" +
"  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'\n" +
"  --select-1            select first item and immediately exit if the input contains only 1 item\n" +
"  --exit-0              exit immediately with status 1 if the input is empty\n" +
"  --select-all          select all items and immediately exit\n" +
"  --on-cancel           specify action on user cancel. 'success' or 'error'.\n" +
"                        default is 'success'. This may change in future versions\n" +
"  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.\n" +
"                        default is to use colors. This option is experimental\n" +
"  --exec                execute command instead of finishing/terminating peco.\n" +
"                        Please note that this command will receive selected line(s) from stdin,\n" +
"                        and will be executed via '/bin/sh -c' or 'cmd /c'\n" +
"  --print-query         print out the current query as first line of output\n" +
"  --ansi                enable ANSI color code support\n" +
"  --height              display height in lines or percentage (e.g. '10', '50%')\n";

    static class Opts {
        String query = "";
        String rcfile = null;
        int bufferSize = -1;
        boolean nul = false, select1 = false, exit0 = false, selectAll = false, printQuery = false;
        boolean help = false, version = false, ansi = false;
        String initialFilter = "IgnoreCase";
        String layout = "top-down";
        String onCancel = "success";
        String file = null;
    }

    public static void main(String[] args) {
        try {
            Opts o = parse(args);
            if (o.help) { System.out.print(HELP); return; }
            if (o.version) { System.out.println(VERSION); return; }
            applyConfig(o);
            validate(o);
            List<Item> items = readInput(o);
            if (o.exit0 && items.isEmpty()) System.exit(1);
            if (o.select1 && items.size() == 1) {
                finish(o, Collections.singletonList(items.get(0)));
                return;
            }
            if (o.selectAll && items.size() <= 1) {
                finish(o, items);
                return;
            }
            failScreen();
        } catch (PecoException e) {
            System.out.println(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static void finish(Opts o, List<Item> selected) {
        if (o.printQuery) System.out.println(o.query);
        for (Item it : selected) System.out.println(it.result);
    }

    static void failScreen() {
        String term = System.getenv("TERM");
        if (term == null || term.isEmpty())
            throw new PecoException("Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set");
        throw new PecoException("Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address");
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) { if (i + 1 < args.length && o.file == null) o.file = args[++i]; break; }
            if (a.equals("-h") || a.equals("--help")) o.help = true;
            else if (a.equals("--version")) o.version = true;
            else if (a.equals("--null")) o.nul = true;
            else if (a.equals("--select-1")) o.select1 = true;
            else if (a.equals("--exit-0")) o.exit0 = true;
            else if (a.equals("--select-all")) o.selectAll = true;
            else if (a.equals("--print-query")) o.printQuery = true;
            else if (a.equals("--ansi")) o.ansi = true;
            else if (a.equals("--query")) o.query = needArg(args, ++i, "--query");
            else if (a.startsWith("--query=")) o.query = a.substring(8);
            else if (a.equals("--rcfile")) o.rcfile = needArg(args, ++i, "--rcfile");
            else if (a.startsWith("--rcfile=")) o.rcfile = a.substring(9);
            else if (a.equals("--initial-index")) { needArg(args, ++i, "--initial-index"); }
            else if (a.startsWith("--initial-index=")) { }
            else if (a.equals("--initial-filter")) o.initialFilter = needArg(args, ++i, "--initial-filter");
            else if (a.startsWith("--initial-filter=")) o.initialFilter = a.substring(17);
            else if (a.equals("--prompt")) { needArg(args, ++i, "--prompt"); }
            else if (a.startsWith("--prompt=")) { }
            else if (a.equals("--layout")) o.layout = needArg(args, ++i, "--layout");
            else if (a.startsWith("--layout=")) o.layout = a.substring(9);
            else if (a.equals("--on-cancel")) o.onCancel = needArg(args, ++i, "--on-cancel");
            else if (a.startsWith("--on-cancel=")) o.onCancel = a.substring(12);
            else if (a.equals("--selection-prefix")) { needArg(args, ++i, "--selection-prefix"); }
            else if (a.startsWith("--selection-prefix=")) { }
            else if (a.equals("--exec")) { needArg(args, ++i, "--exec"); }
            else if (a.startsWith("--exec=")) { }
            else if (a.equals("--height")) { needArg(args, ++i, "--height"); }
            else if (a.startsWith("--height=")) { }
            else if (a.equals("-b") || a.equals("--buffer-size")) { o.bufferSize = parseIntArg(needArg(args, ++i, a), "-b, --buffer-size"); }
            else if (a.startsWith("--buffer-size=")) { o.bufferSize = parseIntArg(a.substring(14), "-b, --buffer-size"); }
            else if (a.startsWith("-b") && a.length() > 2) { o.bufferSize = parseIntArg(a.substring(2), "-b, --buffer-size"); }
            else if (a.startsWith("-")) parseError("unknown flag `" + a.replaceFirst("^-+", "") + "'");
            else if (o.file == null) o.file = a;
        }
        return o;
    }

    static String needArg(String[] args, int idx, String flag) {
        if (idx >= args.length) parseError("expected argument for flag `" + flag + "'");
        return args[idx];
    }

    static int parseIntArg(String s, String flag) {
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) {
            parseError("invalid argument for flag `" + flag + "' (expected int): strconv.ParseInt: parsing \"" + s + "\": invalid syntax");
            return -1;
        }
    }

    static void parseError(String msg) {
        throw new PecoException(msg + "\n" + HELP + "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: " + msg);
    }

    static void validate(Opts o) {
        Set<String> filters = new HashSet<>(Arrays.asList("IgnoreCase","CaseSensitive","SmartCase","IRegexp","Regexp","Fuzzy"));
        if (!filters.contains(o.initialFilter))
            throw new PecoException("Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found");
        if (!o.layout.equals("top-down") && !o.layout.equals("bottom-up") && !o.layout.equals("top-down-query-bottom"))
            throw new PecoException("Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '" + o.layout + "'");
        if (!o.onCancel.equals("success") && !o.onCancel.equals("error"))
            throw new PecoException("Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value \"" + o.onCancel + "\": must be \"success\" or \"error\"");
    }

    static void applyConfig(Opts o) throws IOException {
        if (o.rcfile != null) {
            Path p = Paths.get(o.rcfile);
            if (!Files.exists(p)) throw new PecoException("Error: failed to setup peco: failed to load config file: open " + o.rcfile + ": no such file or directory");
            String s = Files.readString(p);
            String on = extractString(s, "OnCancel"); if (on != null && o.onCancel.equals("success")) o.onCancel = on;
            String f = extractString(s, "InitialFilter"); if (f != null && o.initialFilter.equals("IgnoreCase")) o.initialFilter = f;
            if (extractBool(s, "ANSI")) o.ansi = true;
        }
    }
    static String extractString(String s, String key) {
        Matcher m = Pattern.compile("[\\\"']?"+Pattern.quote(key)+"[\\\"']?\\s*[:=]\\s*[\\\"']([^\\\"']*)[\\\"']").matcher(s);
        return m.find() ? m.group(1) : null;
    }
    static boolean extractBool(String s, String key) {
        Matcher m = Pattern.compile("[\\\"']?"+Pattern.quote(key)+"[\\\"']?\\s*[:=]\\s*(true|false)", Pattern.CASE_INSENSITIVE).matcher(s);
        return m.find() && m.group(1).equalsIgnoreCase("true");
    }

    static class Item { String display, result; Item(String d, String r) { display=d; result=r; } }

    static List<Item> readInput(Opts o) throws IOException {
        byte[] data;
        if (o.file != null) {
            try { data = Files.readAllBytes(Paths.get(o.file)); }
            catch (NoSuchFileException e) { throw new PecoException("Error: failed to setup input source: failed to open file for input: open " + o.file + ": no such file or directory"); }
        } else {
            data = System.in.readAllBytes();
        }
        String text = new String(data, StandardCharsets.UTF_8);
        List<Item> out = new ArrayList<>();
        int start = 0;
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                addLine(out, text.substring(start, i), o.nul);
                start = i + 1;
            }
        }
        if (start < text.length()) addLine(out, text.substring(start), o.nul);
        return out;
    }
    static void addLine(List<Item> out, String line, boolean nul) {
        if (line.endsWith("\r")) line = line.substring(0, line.length()-1);
        if (nul) {
            int p = line.indexOf('\0');
            if (p >= 0) out.add(new Item(line.substring(0,p), line.substring(p+1)));
            else out.add(new Item(line, line));
        } else out.add(new Item(line, line));
    }

    static class PecoException extends RuntimeException { PecoException(String s) { super(s); } }
}
