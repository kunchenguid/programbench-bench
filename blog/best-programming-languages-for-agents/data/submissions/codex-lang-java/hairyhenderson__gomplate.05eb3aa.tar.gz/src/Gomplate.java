import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.security.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Base64;
import java.util.regex.*;
import java.util.stream.*;

public class Gomplate {
  public static void main(String[] args) {
    try { new App().run(args); }
    catch (RenderException e) { System.err.println("{\"level\":\"ERROR\",\"msg\":\"\",\"err\":\"" + e.getMessage().replace("\"","\\\"") + "\"}"); System.exit(1); }
    catch (Exception e) { System.err.println("Error: " + e.getMessage()); System.exit(1); }
  }

  static class App {
    String in, out="-", file="-", inputDir=null, outputDir=".", left="{{", right="}}", missingKey="error";
    boolean verbose=false; List<String> includes=new ArrayList<>(), excludes=new ArrayList<>(), excludeProc=new ArrayList<>();
    Map<String,String> datasourceDefs=new LinkedHashMap<>(), contextDefs=new LinkedHashMap<>();
    Map<String,Object> datasources=new HashMap<>(), root=new LinkedHashMap<>();

    void run(String[] argv) throws Exception {
      parseArgs(argv);
      if (System.getenv("GOMPLATE_LEFT_DELIM")!=null && left.equals("{{")) left=System.getenv("GOMPLATE_LEFT_DELIM");
      if (System.getenv("GOMPLATE_RIGHT_DELIM")!=null && right.equals("}}")) right=System.getenv("GOMPLATE_RIGHT_DELIM");
      Map<String,Object> env=new LinkedHashMap<>(); env.putAll(System.getenv()); root.put("Env", env);
      for (var e: contextDefs.entrySet()) {
        Object v=loadSource(e.getValue());
        if (e.getKey().equals(".")) { if (v instanceof Map) root=(Map<String,Object>)v; else root.put("Value", v); }
        else root.put(e.getKey(), v);
      }
      if (inputDir != null) { processDir(); return; }
      String tmpl = in != null ? in : readInput(file);
      String rendered = new Engine(root, datasourceDefs, datasources, left, right, missingKey, file.equals("-")?"":file).render(tmpl);
      writeOutput(out, rendered, file);
    }

    void parseArgs(String[] a) {
      for (int i=0;i<a.length;i++) {
        String s=a[i], v=null; int eq=s.indexOf('=');
        if (s.startsWith("--") && eq>0) { v=s.substring(eq+1); s=s.substring(0,eq); }
        switch(s) {
          case "-h": case "--help": help(); System.exit(0);
          case "-v": case "-V": case "--version": if(!s.equals("-V")){System.out.println("gomplate version 0.0.0"); System.exit(0);} verbose=true; break;
          case "--verbose": verbose=true; break;
          case "-i": case "--in": in = v!=null?v:a[++i]; break;
          case "-f": case "--file": file = v!=null?v:a[++i]; break;
          case "-o": case "--out": out = v!=null?v:a[++i]; break;
          case "-d": case "--datasource": addDef(datasourceDefs, v!=null?v:a[++i]); break;
          case "-c": case "--context": addDef(contextDefs, v!=null?v:a[++i]); break;
          case "--input-dir": inputDir = v!=null?v:a[++i]; break;
          case "--output-dir": outputDir = v!=null?v:a[++i]; break;
          case "--include": includes.add(v!=null?v:a[++i]); break;
          case "--exclude": excludes.add(v!=null?v:a[++i]); break;
          case "--exclude-processing": excludeProc.add(v!=null?v:a[++i]); break;
          case "--left-delim": left = v!=null?v:a[++i]; break;
          case "--right-delim": right = v!=null?v:a[++i]; break;
          case "--missing-key": missingKey = v!=null?v:a[++i]; break;
          case "--config": if(v==null && i+1<a.length) i++; break;
          case "--chmod": if(v==null && i+1<a.length) i++; break;
          default: if (!s.startsWith("-")) file=s; break;
        }
      }
    }
    void addDef(Map<String,String> m, String spec) {
      int eq=spec.indexOf('=');
      if(eq<0) { Path p=Paths.get(spec); String n=p.getFileName().toString().replaceFirst("\\.[^.]*$",""); m.put(n,spec); }
      else m.put(spec.substring(0,eq), spec.substring(eq+1));
    }
    String readInput(String f) throws IOException { return f.equals("-") ? new String(System.in.readAllBytes(), StandardCharsets.UTF_8) : Files.readString(Paths.get(f)); }
    void writeOutput(String o, String data, String src) throws IOException {
      if (o.equals("-")) System.out.print(data);
      else { Path p=Paths.get(o); if(p.getParent()!=null) Files.createDirectories(p.getParent()); Files.writeString(p,data); }
    }
    void processDir() throws Exception {
      Path inRoot=Paths.get(inputDir), outRoot=Paths.get(outputDir); Files.createDirectories(outRoot);
      try (Stream<Path> st=Files.walk(inRoot)) {
        for (Path p: st.filter(Files::isRegularFile).toList()) {
          String rel=inRoot.relativize(p).toString(); if(skip(rel, excludes)) continue;
          Path dest=outRoot.resolve(rel); Files.createDirectories(dest.getParent());
          if(skip(rel, excludeProc) || (!includes.isEmpty() && !skip(rel, includes))) Files.copy(p,dest,StandardCopyOption.REPLACE_EXISTING);
          else Files.writeString(dest, new Engine(root,datasourceDefs,datasources,left,right,missingKey,p.toString()).render(Files.readString(p)));
        }
      }
    }
    boolean skip(String rel,List<String> pats){ for(String pat:pats) if(glob(pat,rel)) return true; return false; }
    boolean glob(String pat,String s){ String r=Pattern.quote(pat).replace("\\*\\*",".*").replace("\\*","[^/]*").replace("\\?","[^/]"); return s.matches(r); }
    void help() { System.out.println("Process text files with Go templates\n\nUsage:\n  gomplate [flags]\n\nFlags:\n  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.\n  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias `.` to set the root context.\n  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])\n  -i, --in string                    Template string to process (alternative to --file and --input-dir)\n  -o, --out file                     output file name. Omit to use standard output. (default [-])\n      --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)\n      --output-dir directory         directory to store the processed templates. Only used for --input-dir (default \".\")\n      --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default \"{{\")\n      --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default \"}}\")\n      --missing-key string           Control the behavior during execution if a map is indexed with a key that is not present in the map. (default \"error\")\n  -h, --help                         help for gomplate\n  -v, --version                      version for gomplate"); }
  }

  static class Engine {
    Map<String,Object> root; Map<String,String> defs; Map<String,Object> cache; String left,right,missingKey,path;
    Engine(Map<String,Object> r,Map<String,String>d,Map<String,Object>c,String l,String rr,String mk,String p){root=r;defs=d;cache=c;left=l;right=rr;missingKey=mk;path=p;}
    String render(String t){ return renderSection(t, new Ctx(root, root, new HashMap<>())); }
    String renderSection(String t, Ctx ctx) {
      StringBuilder out=new StringBuilder(); int pos=0;
      while(true){ int a=t.indexOf(left,pos); if(a<0){out.append(t.substring(pos));break;} int b=t.indexOf(right,a+left.length()); if(b<0){out.append(t.substring(pos));break;}
        boolean trimL=t.startsWith(left+"-",a); boolean trimR=b>0&&t.charAt(b-1)=='-'; String raw=t.substring(a+left.length()+(trimL?1:0), b-(trimR?1:0)).trim();
        out.append(t, pos, a);
        if(trimL) while(out.length()>0 && Character.isWhitespace(out.charAt(out.length()-1))) out.deleteCharAt(out.length()-1);
        if(raw.startsWith("range ")){ Block bl=findBlock(t,b+right.length(),"range"); String rex=raw.substring(6).trim(); String kVar=null,vVar=null; int asn=rex.indexOf(":="); if(asn>0){String lhs=rex.substring(0,asn).trim(); rex=rex.substring(asn+2).trim(); String[] vs=lhs.split(","); if(vs.length>1){kVar=vs[0].trim(); vVar=vs[1].trim();} else vVar=lhs;} Object val=eval(rex,ctx); int idx=0; if(val instanceof Map<?,?> m){ List<String> ks=m.keySet().stream().map(String::valueOf).sorted().toList(); for(String key:ks){Object item=m.get(key); Map<String,Object> vars=new HashMap<>(ctx.vars); if(kVar!=null)vars.put(kVar,key); if(vVar!=null)vars.put(vVar,item); out.append(renderSection(bl.body,new Ctx(ctx.root,item,vars))); idx++; }} else for(Object item:iter(val)){ Map<String,Object> vars=new HashMap<>(ctx.vars); if(kVar!=null)vars.put(kVar,(long)idx); if(vVar!=null)vars.put(vVar,item); out.append(renderSection(bl.body,new Ctx(ctx.root,item,vars))); idx++; } pos=bl.next; }
        else if(raw.startsWith("if ")){ Block bl=findBlock(t,b+right.length(),"if"); out.append(renderSection(truth(eval(raw.substring(3),ctx))?bl.body:bl.elseBody, new Ctx(ctx.root,ctx.dot,new HashMap<>(ctx.vars)))); pos=bl.next; }
        else if(raw.startsWith("with ")){ Block bl=findBlock(t,b+right.length(),"with"); Object val=eval(raw.substring(5),ctx); out.append(renderSection(truth(val)?bl.body:bl.elseBody, new Ctx(ctx.root,val,new HashMap<>(ctx.vars)))); pos=bl.next; }
        else if(raw.equals("else")||raw.equals("end")) { pos=b+right.length(); }
        else { Object val=execAction(raw,ctx); if(val!=NOOUT) out.append(str(val)); pos=b+right.length(); }
        if(trimR){ while(pos<t.length() && Character.isWhitespace(t.charAt(pos)) && t.charAt(pos)!='\n') pos++; if(pos<t.length()&&t.charAt(pos)=='\n') pos++; }
      }
      return out.toString();
    }
    Object execAction(String raw, Ctx ctx) {
      if(raw.startsWith("$") && (raw.contains(":=")||raw.contains("="))){
        int p=raw.contains(":=")?raw.indexOf(":="):raw.indexOf("="); String name=raw.substring(0,p).trim(); String ex=raw.substring(p+(raw.charAt(p)==':'?2:1)).trim(); ctx.vars.put(name, eval(ex,ctx)); return NOOUT;
      }
      if(raw.startsWith("/*")) return NOOUT;
      return eval(raw,ctx);
    }
    Block findBlock(String t,int start,String kind){ int depth=1,pos=start,elseA=-1,elseB=-1; while(depth>0){int a=t.indexOf(left,pos); if(a<0) throw err("unclosed "+kind); int b=t.indexOf(right,a+left.length()); String r=t.substring(a+left.length(),b).replaceAll("^-|-$","").trim(); if(r.startsWith(kind+" ")) depth++; else if(r.equals("end")) depth--; else if(r.equals("else")&&depth==1){elseA=a;elseB=b+right.length();} if(depth==0){String body=t.substring(start,elseA>=0?elseA:a); String eb=elseA>=0?t.substring(elseB,a):""; return new Block(body,eb,b+right.length());} pos=b+right.length(); } throw err("unclosed");}
    Object eval(String expr, Ctx ctx){ List<String> pipes=splitTop(expr,'|'); Object val=null; for(int i=0;i<pipes.size();i++){ String p=pipes.get(i).trim(); if(i==0) val=evalCmd(p,ctx,null); else val=evalCmd(p,ctx,val);} return val; }
    Object evalCmd(String cmd,Ctx ctx,Object pipe){ List<String> toks=tokenize(cmd); if(toks.isEmpty()) return ""; if(toks.size()==1 && pipe==null && !isFunc(toks.get(0))) return atom(toks.get(0),ctx);
      String fn=toks.get(0); List<Object> args=new ArrayList<>(); for(int i=1;i<toks.size();i++) args.add(atom(toks.get(i),ctx)); if(pipe!=null) args.add(pipe);
      if(!isFunc(fn) && toks.size()>1 && pipe==null) return atom(cmd,ctx);
      return call(fn,args,ctx);
    }
    Object atom(String s,Ctx ctx){ s=s.trim(); if(s.startsWith("(")){ int end=matchingParen(s); if(end>0){ Object base=eval(s.substring(1,end),ctx); return end==s.length()-1?base:access(base,s.substring(end+1),ctx); } }
      if((s.startsWith("\"")&&s.endsWith("\""))||(s.startsWith("`")&&s.endsWith("`"))) return unq(s); if(s.equals("true"))return true; if(s.equals("false"))return false; if(s.equals("nil"))return null;
      if(s.equals(".")) return ctx.dot; if(s.startsWith("$")) return access(ctx.vars.get(s.split("[.]",2)[0]), s.contains(".")?s.substring(s.indexOf('.')):"", ctx);
      if(s.startsWith(".")) return access(ctx.dot,s,ctx); if(s.matches("-?0x[0-9a-fA-F]+")) return Long.parseLong(s.replaceFirst("-?0x",""),16)*(s.startsWith("-")?-1:1);
      if(s.matches("-?\\d+")) return Long.parseLong(s); if(s.matches("-?(\\d+\\.\\d*|\\d*\\.\\d+|\\d+e[-+]?\\d+).*")) return Double.parseDouble(s);
      return s;
    }
    Object access(Object base,String path,Ctx ctx){ if(path==null||path.isEmpty()) return base; String p=path.startsWith(".")?path.substring(1):path; Object cur=base; for(String part:p.split("\\.")){ if(part.isEmpty())continue; cur=get(cur,part,ctx);} return cur; }
    Object get(Object cur,String key,Ctx ctx){ if(cur instanceof Map<?,?> m){ if(m.containsKey(key)) return m.get(key); if(missingKey.equals("error")) throw err("map has no entry for key \""+key+"\""); return NO_VALUE; } if(cur instanceof List<?> l) return l.get(Integer.parseInt(key)); return NO_VALUE; }
    Object call(String fn,List<Object> a,Ctx ctx) {
      fn=alias(fn);
      switch(fn){
        case "print": return a.stream().map(Gomplate::str).collect(Collectors.joining(""));
        case "printf": return sprintf(str(a.get(0)), a.subList(1,a.size()).toArray());
        case "eq": return cmp(a)==0; case "ne": return cmp(a)!=0; case "lt": return cmp(a)<0; case "le": return cmp(a)<=0; case "gt": return cmp(a)>0; case "ge": return cmp(a)>=0;
        case "not": return !truth(a.get(0)); case "and": for(Object x:a) if(!truth(x)) return x; return a.isEmpty()?false:a.get(a.size()-1); case "or": for(Object x:a) if(truth(x)) return x; return a.isEmpty()?false:a.get(a.size()-1);
        case "index": { Object cur=a.get(0); for(int i=1;i<a.size();i++) cur=get(cur,str(a.get(i)),ctx); return cur; }
        case "len": return (long)(a.get(0) instanceof Collection<?> c?c.size():a.get(0) instanceof Map<?,?> m?m.size():str(a.get(0)).length());
        case "env.Getenv": case "getenv": return getenv(str(a.get(0)), a.size()>1?str(a.get(1)):"");
        case "env.HasEnv": return System.getenv().containsKey(str(a.get(0)));
        case "env.Env": return System.getenv();
        case "env.ExpandEnv": return expandEnv(str(a.get(0)));
        case "math.Add": return add(a); case "math.Sub": return num(a.get(0))-num(a.get(1)); case "math.Mul": return mul(a); case "math.Div": return num(a.get(0))/num(a.get(1)); case "math.Mod": return (long)num(a.get(0))%(long)num(a.get(1));
        case "math.Abs": return Math.abs(num(a.get(0))); case "math.Ceil": return Math.ceil(num(a.get(0))); case "math.Floor": return Math.floor(num(a.get(0))); case "math.Round": return (double)Math.round(num(a.get(0)));
        case "math.Seq": return seq(a); case "math.IsInt": return isInt(a.get(0)); case "math.IsFloat": return !isInt(a.get(0)) && isNum(a.get(0)); case "math.IsNum": return isNum(a.get(0));
        case "coll.Slice": return new ArrayList<>(a); case "coll.Dict": return dict(a); case "coll.Has": return has(a.get(0),a.get(1)); case "coll.Keys": return keys(a); case "coll.Values": return values(a); case "coll.Append": { List<Object> l=list(a.subList(1,a.size())); l.add(a.get(0)); return l; } case "coll.Prepend": { List<Object> l=list(a.subList(1,a.size())); l.add(0,a.get(0)); return l; } case "coll.Reverse": { List<Object> l=list(a); Collections.reverse(l); return l; } case "coll.Uniq": return new ArrayList<>(new LinkedHashSet<>(list(a)));
        case "strings.ToUpper": return str(a.get(0)).toUpperCase(); case "strings.ToLower": return str(a.get(0)).toLowerCase(); case "strings.Title": return title(str(a.get(0))); case "strings.Contains": return str(a.get(1)).contains(str(a.get(0))); case "strings.HasPrefix": return str(a.get(1)).startsWith(str(a.get(0))); case "strings.HasSuffix": return str(a.get(1)).endsWith(str(a.get(0))); case "strings.TrimSpace": return str(a.get(0)).trim(); case "strings.Trim": return str(a.get(1)).replaceAll("^["+Pattern.quote(str(a.get(0)))+"]+|["+Pattern.quote(str(a.get(0)))+"]+$",""); case "strings.ReplaceAll": return str(a.get(2)).replace(str(a.get(0)),str(a.get(1))); case "strings.Split": return Arrays.asList(str(a.get(1)).split(Pattern.quote(str(a.get(0))),-1)); case "strings.Join": case "join": return join(a.get(0),str(a.get(1))); case "strings.Repeat": return str(a.get(1)).repeat((int)num(a.get(0))); case "strings.Quote": return "\""+str(a.get(0)).replace("\"","\\\"")+"\""; case "strings.Squote": return "'"+str(a.get(0)).replace("'","'\\''")+"'";
        case "conv.ToString": return str(a.get(0)); case "conv.ToInt": case "conv.ToInt64": return (long)num(a.get(0)); case "conv.ToFloat64": return num(a.get(0)); case "conv.ToBool": case "conv.Bool": return toBool(a.get(0)); case "conv.Default": case "default": return empty(a.get(1))?a.get(0):a.get(1); case "conv.Join": return join(a.get(0),str(a.get(1)));
        case "data.JSON": case "json": return new Json(str(a.get(0))).parse(); case "data.ToJSON": case "toJSON": return toJson(a.get(0),false,0); case "data.ToJSONPretty": case "toJSONPretty": return toJson(a.size()>1?a.get(1):a.get(0),true,0); case "data.YAML": return parseYaml(str(a.get(0))); case "data.CSV": return parseCsv(str(a.get(0)));
        case "datasource": case "ds": return ds(str(a.get(0)), a.size()>1?str(a.get(1)):null); case "include": return include(str(a.get(0)), a.size()>1?str(a.get(1)):null);
        case "base64.Encode": case "base64": return Base64.getEncoder().encodeToString(str(a.get(0)).getBytes(StandardCharsets.UTF_8)); case "base64.Decode": return new String(Base64.getDecoder().decode(str(a.get(0))),StandardCharsets.UTF_8);
        case "crypto.SHA1": return hash("SHA-1",str(a.get(0))); case "crypto.SHA256": return hash("SHA-256",str(a.get(0))); case "crypto.MD5": return hash("MD5",str(a.get(0)));
        case "regexp.Match": return Pattern.compile(str(a.get(0))).matcher(str(a.get(1))).find(); case "regexp.Replace": return str(a.get(2)).replaceAll(str(a.get(0)),str(a.get(1)));
        case "path.Base": case "filepath.Base": return Paths.get(str(a.get(0))).getFileName().toString(); case "path.Dir": case "filepath.Dir": { Path p=Paths.get(str(a.get(0))).getParent(); return p==null?".":p.toString(); } case "path.Ext": case "filepath.Ext": { String s=str(a.get(0)); int i=s.lastIndexOf('.'); return i<0?"":s.substring(i); } case "path.Join": case "filepath.Join": return a.stream().map(Gomplate::str).reduce("",(x,y)->x.isEmpty()?y:Paths.get(x,y).toString()).replace('\\','/'); case "path.IsAbs": case "filepath.IsAbs": return Paths.get(str(a.get(0))).isAbsolute();
        case "file.Read": return readFile(str(a.get(0))); case "file.Exists": return Files.exists(Paths.get(str(a.get(0)))); case "file.IsDir": return Files.isDirectory(Paths.get(str(a.get(0))));
        case "test.Required": case "required": if(empty(a.get(a.size()-1))) throw err(a.size()>1?str(a.get(0)):"can not render template: a required value was not set"); return a.get(a.size()-1); case "test.Ternary": case "ternary": return truth(a.get(2))?a.get(0):a.get(1);
        case "tmpl.Path": return path; case "tmpl.PathDir": return path==null||path.isEmpty()?"":Paths.get(path).getParent().toString();
        case "time.Now": return ZonedDateTime.now(); case "time.Unix": return Instant.ofEpochSecond((long)num(a.get(0))).atZone(ZoneId.systemDefault()); case "time.ZoneName": return ZoneId.systemDefault().toString(); case "time.ZoneOffset": return (long)ZonedDateTime.now().getOffset().getTotalSeconds();
      }
      throw err("function not defined: "+fn);
    }
    String alias(String f){ return switch(f){case "add"->"math.Add";case "sub"->"math.Sub";case "mul"->"math.Mul";case "div"->"math.Div";case "mod"->"math.Mod";case "slice"->"coll.Slice";case "dict"->"coll.Dict";case "has"->"coll.Has";default->f;};}
    boolean isFunc(String f){ f=alias(f); return Set.of("print","printf","eq","ne","lt","le","gt","ge","not","and","or","index","len","getenv","default","required","join","ds","datasource","include","json","toJSON","toJSONPretty","base64","ternary").contains(f)
      || f.startsWith("math.") || f.startsWith("env.") || f.startsWith("coll.") || f.startsWith("strings.") || f.startsWith("conv.") || f.startsWith("data.") || f.startsWith("base64.") || f.startsWith("crypto.") || f.startsWith("regexp.") || f.startsWith("path.") || f.startsWith("filepath.") || f.startsWith("file.") || f.startsWith("test.") || f.startsWith("tmpl.") || f.startsWith("time.");}
    Object ds(String alias,String sub){ try{ if(!cache.containsKey(alias)) cache.put(alias, loadSource(defs.get(alias))); return cache.get(alias);}catch(Exception e){throw err(e.getMessage());}}
    Object include(String alias,String sub){ try{return loadRaw(defs.get(alias));}catch(Exception e){throw err(e.getMessage());}}
    String readFile(String p){ try{return Files.readString(Paths.get(p));}catch(Exception e){throw err(e.getMessage());}}
    RenderException err(String m){ return new RenderException(m); }
    static final Object NOOUT=new Object(), NO_VALUE=new Object(){public String toString(){return "<no value>";}};
  }
  record Block(String body,String elseBody,int next){} record Ctx(Map<String,Object> root,Object dot,Map<String,Object> vars){}
  static class RenderException extends RuntimeException{RenderException(String m){super(m);}}

  static List<String> splitTop(String s,char sep){ List<String> r=new ArrayList<>(); int d=0; boolean q=false,bt=false; StringBuilder b=new StringBuilder(); for(int i=0;i<s.length();i++){char c=s.charAt(i); if(c=='"'&&!bt&&(i==0||s.charAt(i-1)!='\\'))q=!q; else if(c=='`'&&!q)bt=!bt; else if(!q&&!bt){if(c=='(')d++; else if(c==')')d--; else if(c==sep&&d==0){r.add(b.toString()); b.setLength(0); continue;}} b.append(c);} r.add(b.toString()); return r;}
  static List<String> tokenize(String s){ List<String> r=new ArrayList<>(); StringBuilder b=new StringBuilder(); int d=0; boolean q=false,bt=false; for(int i=0;i<s.length();i++){char c=s.charAt(i); if(c=='"'&&!bt&&(i==0||s.charAt(i-1)!='\\'))q=!q; else if(c=='`'&&!q)bt=!bt; if(!q&&!bt){if(c=='(')d++; if(c==')')d--; if(Character.isWhitespace(c)&&d==0){if(b.length()>0){r.add(b.toString());b.setLength(0);} continue;}} b.append(c);} if(b.length()>0)r.add(b.toString()); return r;}
  static boolean balanced(String s){int d=0;for(char c:s.toCharArray()){if(c=='(')d++;if(c==')')d--;}return d==0;}
  static int matchingParen(String s){int d=0;boolean q=false,bt=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'&&!bt&&(i==0||s.charAt(i-1)!='\\'))q=!q;else if(c=='`'&&!q)bt=!bt;if(!q&&!bt){if(c=='(')d++;if(c==')'&&--d==0)return i;}}return -1;}
  static String unq(String s){ if(s.startsWith("`"))return s.substring(1,s.length()-1); String x=s.substring(1,s.length()-1); return x.replace("\\n","\n").replace("\\t","\t").replace("\\\"","\"").replace("\\\\","\\");}
  static Iterable<?> iter(Object v){ if(v instanceof Iterable<?> i)return i; if(v instanceof Map<?,?> m)return m.entrySet(); if(v==null)return List.of(); return List.of(v);}
  static boolean truth(Object v){ return !(v==null||v==Engine.NO_VALUE||Boolean.FALSE.equals(v)||(v instanceof Number n&&n.doubleValue()==0)||"".equals(v)||(v instanceof Collection<?> c&&c.isEmpty())||(v instanceof Map<?,?> m&&m.isEmpty()));}
  static boolean empty(Object v){ return !truth(v); }
  static double num(Object o){ if(o instanceof Number n)return n.doubleValue(); String s=String.valueOf(o); if(s.equals("Inf")||s.equals("+Inf"))return Double.POSITIVE_INFINITY; if(s.equals("-Inf"))return Double.NEGATIVE_INFINITY; if(s.equals("NaN"))return Double.NaN; if(s.matches("-?0x[0-9a-fA-F]+"))return Long.parseLong(s.replaceFirst("-?0x",""),16)*(s.startsWith("-")?-1:1); if(s.matches("-?0[0-7]+")&&s.length()>1)return Long.parseLong(s,8); return Double.parseDouble(s);}
  static boolean isNum(Object o){try{num(o);return true;}catch(Exception e){return false;}} static boolean isInt(Object o){ if(o instanceof Integer||o instanceof Long)return true; String s=String.valueOf(o); return s.matches("-?(0x[0-9a-fA-F]+|0[0-7]+|\\d+)");}
  static Object add(List<Object>a){ boolean f=a.stream().anyMatch(x->!isInt(x)); double d=0; long l=0; for(Object x:a){d+=num(x);l+=(long)num(x);} return f?d:l;} static Object mul(List<Object>a){ boolean f=a.stream().anyMatch(x->!isInt(x)); double d=1; long l=1; for(Object x:a){d*=num(x);l*=(long)num(x);} return f?d:l;}
  static List<Long> seq(List<Object>a){ long start=a.size()==1?1:(long)num(a.get(0)), end=(long)num(a.get(a.size()==1?0:1)), step=a.size()>2?(long)num(a.get(2)):1; List<Long> r=new ArrayList<>(); if(step==0)return r; if(end<start&&step>0)step=-step; if(end>start&&step<0)step=-step; end-=(end-start)%step; for(long x=start;;x+=step){r.add(x); if(x==end)break;} return r;}
  static int cmp(List<Object>a){ Object x=a.get(0), y=a.get(1); if(isNum(x)&&isNum(y))return Double.compare(num(x),num(y)); return String.valueOf(x).compareTo(String.valueOf(y));}
  static Map<String,Object> dict(List<Object>a){ Map<String,Object> m=new LinkedHashMap<>(); for(int i=0;i<a.size();i+=2)m.put(String.valueOf(a.get(i)), i+1<a.size()?a.get(i+1):""); return m;}
  static boolean has(Object in,Object item){ if(in instanceof Map<?,?> m)return m.containsKey(String.valueOf(item)); if(in instanceof Collection<?> c)return c.contains(item)||c.contains(String.valueOf(item)); return String.valueOf(in).contains(String.valueOf(item));}
  static List<Object> list(Object v){ if(v instanceof Collection<?> c)return new ArrayList<>(c); return new ArrayList<>(List.of(v));}
  static List<Object> keys(List<Object>a){ List<Object> r=new ArrayList<>(); for(Object o:a) if(o instanceof Map<?,?> m){ List<String> k=m.keySet().stream().map(String::valueOf).sorted().toList(); r.addAll(k);} return r;}
  static List<Object> values(List<Object>a){ List<Object> r=new ArrayList<>(); for(Object o:a) if(o instanceof Map<?,?> m){ for(String k:m.keySet().stream().map(String::valueOf).sorted().toList()) r.add(m.get(k));} return r;}
  static String str(Object o){ if(o==null||o==Engine.NO_VALUE)return "<no value>"; if(o==Engine.NOOUT)return ""; if(o instanceof Double d){ if(d.isInfinite())return d>0?"+Inf":"-Inf"; if(d.isNaN())return "NaN"; if(d==Math.rint(d))return Long.toString(d.longValue()); } if(o instanceof Float f && f==Math.rint(f))return Long.toString(f.longValue()); if(o instanceof List<?> l)return "["+l.stream().map(Gomplate::str).collect(Collectors.joining(" "))+"]"; if(o instanceof Map<?,?> m)return "map["+m.entrySet().stream().map(e->e.getKey()+":"+str(e.getValue())).collect(Collectors.joining(" "))+"]"; return String.valueOf(o);}
  static String join(Object v,String sep){ Iterable<?> it=iter(v); List<String> s=new ArrayList<>(); for(Object x:it)s.add(str(x)); return String.join(sep,s);}
  static boolean toBool(Object o){ if(o instanceof Boolean b)return b; String s=String.valueOf(o).toLowerCase(); return s.equals("1")||s.equals("t")||s.equals("true")||s.equals("yes")||s.equals("y");}
  static String getenv(String k,String def){ String v=System.getenv(k); if(v!=null)return v; String f=System.getenv(k+"_FILE"); if(f!=null)try{return Files.readString(Paths.get(f)).trim();}catch(Exception e){} return def;}
  static String expandEnv(String s){ Matcher m=Pattern.compile("\\$\\{?([A-Za-z_][A-Za-z0-9_]*)}?").matcher(s); StringBuffer b=new StringBuffer(); while(m.find())m.appendReplacement(b,Matcher.quoteReplacement(getenv(m.group(1),""))); m.appendTail(b); return b.toString();}
  static String title(String s){ StringBuilder b=new StringBuilder(); boolean cap=true; for(char c:s.toCharArray()){b.append(cap?Character.toTitleCase(c):c); cap=Character.isWhitespace(c)||c=='-'||c=='_';} return b.toString();}
  static String sprintf(String fmt,Object[] args){ fmt=fmt.replace("%#v","%s").replace("%v","%s").replace("%T","%s"); Object[] aa=Arrays.stream(args).map(Gomplate::str).toArray(); return String.format(fmt,aa);}
  static String hash(String alg,String s){ try{ byte[] d=MessageDigest.getInstance(alg).digest(s.getBytes(StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); for(byte x:d)b.append(String.format("%02x",x)); return b.toString();}catch(Exception e){throw new RuntimeException(e);}}
  static String loadRaw(String src)throws IOException{ if(src==null)throw new IOException("undefined datasource"); if(src.startsWith("file://"))src=src.substring(7); int q=src.indexOf('?'); if(q>=0)src=src.substring(0,q); if(src.equals("-")||src.equals("stdin:"))return new String(System.in.readAllBytes(),StandardCharsets.UTF_8); return Files.readString(Paths.get(src));}
  static Object loadSource(String src)throws IOException{ String raw=loadRaw(src); String low=src.toLowerCase(); String clean=src.split("\\?")[0].toLowerCase(); if(low.contains("type=application/json")||clean.endsWith(".json"))return new Json(raw).parse(); if(low.contains("type=application/yaml")||clean.endsWith(".yaml")||clean.endsWith(".yml"))return parseYaml(raw); if(low.contains("type=application/x-env")||clean.endsWith(".env"))return parseEnv(raw); if(low.contains("type=text/csv")||clean.endsWith(".csv"))return parseCsv(raw); return raw;}
  static Map<String,Object> parseEnv(String s){ Map<String,Object> m=new LinkedHashMap<>(); for(String line:s.split("\\R")){line=line.trim(); if(line.isEmpty()||line.startsWith("#"))continue; line=line.replaceFirst("^export\\s+",""); int i=line.indexOf('='); if(i>0)m.put(line.substring(0,i).trim(), line.substring(i+1).trim().replaceAll("^['\"]|['\"]$",""));} return m;}
  static Object parseYaml(String s){
    Map<String,Object> root=new LinkedHashMap<>(); List<Map<String,Object>> maps=new ArrayList<>(); List<Integer> indents=new ArrayList<>(); maps.add(root); indents.add(0);
    for(String line:s.split("\\R")){
      if(line.trim().isEmpty()||line.trim().startsWith("#"))continue;
      int ind=0; while(ind<line.length()&&line.charAt(ind)==' ')ind++;
      String tr=line.trim(); if(tr.startsWith("- ")) continue;
      int i=tr.indexOf(':'); if(i<0) continue;
      while(indents.size()>1 && ind<indents.get(indents.size()-1)){ maps.remove(maps.size()-1); indents.remove(indents.size()-1); }
      Map<String,Object> cur=maps.get(maps.size()-1); String k=tr.substring(0,i).trim(); String v=tr.substring(i+1).trim();
      if(v.isEmpty()){ Map<String,Object> child=new LinkedHashMap<>(); cur.put(k,child); maps.add(child); indents.add(ind+2); }
      else cur.put(k, scalar(v));
    }
    return root;
  }
  static Object scalar(String v){ if(v.startsWith("\"")&&v.endsWith("\""))return unq(v); if(v.equals("true")||v.equals("false"))return Boolean.parseBoolean(v); if(v.matches("-?\\d+"))return Long.parseLong(v); if(v.matches("-?\\d+\\.\\d+"))return Double.parseDouble(v); return v;}
  static List<List<String>> parseCsv(String s){ List<List<String>> r=new ArrayList<>(); for(String line:s.split("\\R"))r.add(Arrays.asList(line.split(",",-1))); return r;}
  static String toJson(Object o,boolean pretty,int depth){ String ind=pretty?"  ".repeat(depth):"", sp=pretty?" ":""; if(o==null||o==Engine.NO_VALUE)return "null"; if(o instanceof Number||o instanceof Boolean)return String.valueOf(o); if(o instanceof Map<?,?> m){ String sep=pretty?",\n":","; return "{"+(pretty&&!m.isEmpty()?"\n":"")+m.entrySet().stream().map(e->(pretty?"  ".repeat(depth+1):"")+"\""+e.getKey()+"\":"+sp+toJson(e.getValue(),pretty,depth+1)).collect(Collectors.joining(sep))+(pretty&&!m.isEmpty()?"\n"+ind:"")+"}";} if(o instanceof Iterable<?> it){ List<String> xs=new ArrayList<>(); for(Object x:it)xs.add((pretty?"  ".repeat(depth+1):"")+toJson(x,pretty,depth+1)); return "["+(pretty&&!xs.isEmpty()?"\n":"")+String.join(pretty?",\n":",",xs)+(pretty&&!xs.isEmpty()?"\n"+ind:"")+"]";} return "\""+String.valueOf(o).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\"";}
  static class Json{ String s; int p=0; Json(String s){this.s=s;} Object parse(){ws(); Object v=val(); return v;} void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;} char ch(){return s.charAt(p);} Object val(){ws(); if(ch()=='{')return obj(); if(ch()=='[')return arr(); if(ch()=='"')return string(); if(s.startsWith("true",p)){p+=4;return true;} if(s.startsWith("false",p)){p+=5;return false;} if(s.startsWith("null",p)){p+=4;return null;} return number();} Object obj(){Map<String,Object> m=new LinkedHashMap<>();p++;ws();while(ch()!='}'){String k=string();ws();p++;Object v=val();m.put(k,v);ws();if(ch()==','){p++;ws();}}p++;return m;} Object arr(){List<Object> l=new ArrayList<>();p++;ws();while(ch()!=']'){l.add(val());ws();if(ch()==','){p++;ws();}}p++;return l;} String string(){StringBuilder b=new StringBuilder();p++;while(ch()!='"'){char c=s.charAt(p++); if(c=='\\'){char e=s.charAt(p++); b.append(e=='n'?'\n':e=='t'?'\t':e);} else b.append(c);}p++;return b.toString();} Object number(){int st=p;while(p<s.length()&&"-+.eE0123456789".indexOf(s.charAt(p))>=0)p++;String n=s.substring(st,p);return n.contains(".")||n.toLowerCase().contains("e")?Double.parseDouble(n):Long.parseLong(n);}}
}
