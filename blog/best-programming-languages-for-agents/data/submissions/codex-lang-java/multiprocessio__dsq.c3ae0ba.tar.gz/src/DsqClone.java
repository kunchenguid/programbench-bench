import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipFile;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

public class DsqClone {
    static final ObjectMapper JSON = new ObjectMapper();
    static final String HELP = """
dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq
""";

    static class Input {
        String name;
        String format;
        String text;
        byte[] data;
        List<Map<String,Object>> rows = new ArrayList<>();
        List<String> columns = new ArrayList<>();
        boolean jsonTyped;
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg == null || msg.isBlank()) msg = e.toString();
            if (msg.startsWith("[SQLITE_ERROR] SQL error or missing database ")) {
                int idx = msg.lastIndexOf('(');
                int end = msg.lastIndexOf(')');
                if (idx >= 0 && end > idx) msg = msg.substring(idx + 1, end);
            }
            System.err.println(msg);
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length > 0 && (args[0].equals("--help") || args[0].equals("-h"))) {
            System.out.print(HELP);
            return 0;
        }
        if (args.length > 0 && args[0].equals("--version")) {
            System.out.println("dsq latest");
            return 0;
        }

        boolean pretty = false, schema = false;
        String stdinFormat = null, queryFile = null;
        List<String> positionals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-p", "--pretty" -> pretty = true;
                case "--schema" -> schema = true;
                case "-C", "--cache", "-i", "--interactive" -> { }
                case "-s" -> {
                    if (++i >= args.length) return err("Must specify stdin mimetype.");
                    stdinFormat = args[i];
                }
                case "-f", "--file" -> {
                    if (++i >= args.length) return err("Must specify a SQL file.");
                    queryFile = args[i];
                }
                default -> positionals.add(a);
            }
        }

        List<Input> inputs = new ArrayList<>();
        String query = null;
        if (stdinFormat != null) {
            Input in = new Input();
            in.name = "-";
            in.format = stdinFormat;
            in.data = System.in.readAllBytes();
            inputs.add(in);
            if (!positionals.isEmpty()) query = positionals.get(0);
        } else {
            for (String p : positionals) {
                Path path = Paths.get(p);
                if (Files.exists(path) && !Files.isDirectory(path)) {
                    Input in = new Input();
                    in.name = p;
                    in.format = ext(p);
                    in.data = Files.readAllBytes(path);
                    inputs.add(in);
                } else {
                    query = p;
                    break;
                }
            }
        }
        if (queryFile != null) query = Files.readString(Paths.get(queryFile)).trim();
        if (inputs.isEmpty()) return err("No input files.");
        if (query == null || query.isBlank()) query = "select * from {}";

        for (Input in : inputs) parseInput(in);
        if (schema) {
            printSchema(inputs.get(0));
            return 0;
        }

        Class.forName("org.sqlite.JDBC");
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite::memory:")) {
            for (int i = 0; i < inputs.size(); i++) load(conn, "t" + i, inputs.get(i));
            query = rewriteQuery(query, inputs.size());
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(query)) {
                if (pretty) printPretty(rs);
                else printJson(rs);
            }
        }
        return 0;
    }

    static int err(String s) {
        System.err.println(s);
        return 1;
    }

    static String ext(String p) {
        int slash = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\'));
        int dot = p.lastIndexOf('.');
        return dot > slash ? p.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
    }

    static void parseInput(Input in) throws Exception {
        String fmt = in.format == null ? "" : in.format.toLowerCase(Locale.ROOT);
        if (in.text == null && in.data != null) in.text = new String(in.data, StandardCharsets.UTF_8);
        if (fmt.equals("json") || fmt.equals("ndjson") || fmt.equals("jsonl")) parseJson(in, fmt);
        else if (fmt.equals("tsv")) parseDelimited(in, '\t');
        else if (fmt.equals("logfmt")) parseLogfmt(in);
        else if (fmt.equals("xlsx")) parseXlsx(in);
        else if (fmt.equals("ods")) parseOds(in);
        else if (fmt.equals("csv") || fmt.isBlank() || fmt.equals("txt")) parseDelimited(in, ',');
        else throw new IOException("unsupported file format: " + fmt);
    }

    static void parseDelimited(Input in, char delim) throws IOException {
        List<List<String>> recs = readDelimited(in.text, delim);
        if (recs.isEmpty()) return;
        in.columns.addAll(makeUnique(recs.get(0)));
        for (int r = 1; r < recs.size(); r++) {
            List<String> vals = recs.get(r);
            if (vals.size() == 1 && vals.get(0).isEmpty() && r == recs.size() - 1) continue;
            Map<String,Object> row = new LinkedHashMap<>();
            for (int c = 0; c < in.columns.size(); c++) row.put(in.columns.get(c), c < vals.size() ? vals.get(c) : "");
            in.rows.add(row);
        }
    }

    static List<List<String>> readDelimited(String text, char delim) throws IOException {
        List<List<String>> out = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (q) {
                if (ch == '"') {
                    if (i + 1 < text.length() && text.charAt(i + 1) == '"') { cur.append('"'); i++; }
                    else q = false;
                } else cur.append(ch);
            } else {
                if (ch == '"') q = true;
                else if (ch == delim) { row.add(cur.toString()); cur.setLength(0); }
                else if (ch == '\n') { row.add(cur.toString()); out.add(row); row = new ArrayList<>(); cur.setLength(0); }
                else if (ch != '\r') cur.append(ch);
            }
        }
        if (!row.isEmpty() || cur.length() > 0) { row.add(cur.toString()); out.add(row); }
        return out;
    }

    static List<String> makeUnique(List<String> cols) {
        List<String> out = new ArrayList<>();
        Map<String,Integer> seen = new HashMap<>();
        for (int i = 0; i < cols.size(); i++) {
            String c = cols.get(i);
            if (c == null || c.isBlank()) c = "column" + (i + 1);
            int n = seen.getOrDefault(c, 0);
            seen.put(c, n + 1);
            out.add(n == 0 ? c : c + "_" + n);
        }
        return out;
    }

    static void parseJson(Input in, String fmt) throws Exception {
        in.jsonTyped = true;
        List<JsonNode> nodes = new ArrayList<>();
        if (fmt.equals("ndjson") || fmt.equals("jsonl")) {
            for (String line : in.text.split("\\R")) if (!line.isBlank()) nodes.add(JSON.readTree(line));
        } else {
            JsonNode root = JSON.readTree(in.text);
            if (root != null && root.isArray()) root.forEach(nodes::add);
            else if (root != null) nodes.add(root);
        }
        for (JsonNode n : nodes) {
            Map<String,Object> row = new LinkedHashMap<>();
            if (n.isObject()) {
                Iterator<Map.Entry<String,JsonNode>> it = n.fields();
                while (it.hasNext()) {
                    Map.Entry<String,JsonNode> e = it.next();
                    addCol(in, e.getKey());
                    row.put(e.getKey(), jsonValue(e.getValue()));
                }
            } else {
                addCol(in, "value");
                row.put("value", jsonValue(n));
            }
            in.rows.add(row);
        }
    }

    static Object jsonValue(JsonNode n) throws JsonProcessingException {
        if (n == null || n.isNull()) return null;
        if (n.isIntegralNumber()) return n.longValue();
        if (n.isFloatingPointNumber()) return n.doubleValue();
        if (n.isBoolean()) return n.booleanValue() ? 1 : 0;
        if (n.isTextual()) return n.textValue();
        return JSON.writeValueAsString(n);
    }

    static void parseLogfmt(Input in) {
        for (String line : in.text.split("\\R")) {
            if (line.isBlank()) continue;
            Map<String,Object> row = new LinkedHashMap<>();
            Matcher m = Pattern.compile("(\\w+)=((?:\"(?:\\\\.|[^\"])*\")|\\S+)").matcher(line);
            while (m.find()) {
                String key = m.group(1);
                String val = m.group(2);
                if (val.startsWith("\"") && val.endsWith("\"")) val = val.substring(1, val.length() - 1).replace("\\\"", "\"");
                addCol(in, key);
                row.put(key, val);
            }
            in.rows.add(row);
        }
    }

    static void parseXlsx(Input in) throws Exception {
        List<String> shared = new ArrayList<>();
        try (ZipFile z = new ZipFile(in.name)) {
            var ss = z.getEntry("xl/sharedStrings.xml");
            if (ss != null) {
                Document d = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(z.getInputStream(ss));
                NodeList sis = d.getElementsByTagName("si");
                for (int i = 0; i < sis.getLength(); i++) shared.add(textContent((Element) sis.item(i)));
            }
            String sheetPath = firstSheetPath(z);
            var se = z.getEntry(sheetPath);
            if (se == null) throw new IOException("unsupported xlsx: missing worksheet");
            Document d = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(z.getInputStream(se));
            NodeList rowNodes = d.getElementsByTagName("row");
            List<List<String>> rows = new ArrayList<>();
            for (int r = 0; r < rowNodes.getLength(); r++) {
                Element rowEl = (Element) rowNodes.item(r);
                NodeList cells = rowEl.getElementsByTagName("c");
                List<String> row = new ArrayList<>();
                for (int i = 0; i < cells.getLength(); i++) {
                    Element c = (Element) cells.item(i);
                    int idx = colIndex(c.getAttribute("r"));
                    while (row.size() <= idx) row.add("");
                    row.set(idx, cellValue(c, shared));
                }
                rows.add(row);
            }
            if (rows.isEmpty()) return;
            in.columns.addAll(makeUnique(rows.get(0)));
            for (int r = 1; r < rows.size(); r++) {
                Map<String,Object> row = new LinkedHashMap<>();
                for (int c = 0; c < in.columns.size(); c++) row.put(in.columns.get(c), c < rows.get(r).size() ? rows.get(r).get(c) : "");
                in.rows.add(row);
            }
        }
    }

    static String firstSheetPath(ZipFile z) {
        if (z.getEntry("xl/worksheets/sheet1.xml") != null) return "xl/worksheets/sheet1.xml";
        return z.stream().map(e -> e.getName())
                .filter(n -> n.startsWith("xl/worksheets/") && n.endsWith(".xml"))
                .findFirst().orElse("xl/worksheets/sheet1.xml");
    }

    static String cellValue(Element c, List<String> shared) {
        String t = c.getAttribute("t");
        if ("inlineStr".equals(t)) return textContent(c);
        NodeList vs = c.getElementsByTagName("v");
        if (vs.getLength() == 0) return "";
        String v = vs.item(0).getTextContent();
        if ("s".equals(t)) {
            try {
                int idx = Integer.parseInt(v);
                return idx >= 0 && idx < shared.size() ? shared.get(idx) : "";
            } catch (NumberFormatException ignored) {
                return "";
            }
        }
        if ("b".equals(t)) return "1".equals(v) ? "true" : "false";
        return v;
    }

    static String textContent(Element e) {
        StringBuilder b = new StringBuilder();
        NodeList ts = e.getElementsByTagName("t");
        for (int i = 0; i < ts.getLength(); i++) b.append(ts.item(i).getTextContent());
        return b.toString();
    }

    static int colIndex(String ref) {
        int n = 0;
        for (int i = 0; i < ref.length(); i++) {
            char ch = ref.charAt(i);
            if (ch < 'A' || ch > 'Z') break;
            n = n * 26 + (ch - 'A' + 1);
        }
        return Math.max(0, n - 1);
    }

    static void parseOds(Input in) throws Exception {
        try (ZipFile z = new ZipFile(in.name)) {
            var ce = z.getEntry("content.xml");
            if (ce == null) throw new IOException("unsupported ods: missing content.xml");
            Document d = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(z.getInputStream(ce));
            NodeList tables = d.getElementsByTagName("table:table");
            if (tables.getLength() == 0) return;
            Element table = (Element) tables.item(0);
            NodeList rowNodes = table.getElementsByTagName("table:table-row");
            List<List<String>> rows = new ArrayList<>();
            for (int r = 0; r < rowNodes.getLength(); r++) {
                Element rowEl = (Element) rowNodes.item(r);
                int rowRep = repeat(rowEl, "table:number-rows-repeated");
                List<String> row = new ArrayList<>();
                NodeList kids = rowEl.getChildNodes();
                for (int i = 0; i < kids.getLength(); i++) {
                    if (!(kids.item(i) instanceof Element cell)) continue;
                    String name = cell.getNodeName();
                    if (!name.equals("table:table-cell") && !name.equals("table:covered-table-cell")) continue;
                    int colRep = Math.min(repeat(cell, "table:number-columns-repeated"), 1000);
                    String val = name.equals("table:covered-table-cell") ? "" : odsCellValue(cell);
                    for (int c = 0; c < colRep; c++) row.add(val);
                }
                if (row.stream().anyMatch(s -> !s.isEmpty())) {
                    rows.add(row);
                    for (int rr = 1; rr < Math.min(rowRep, 1000); rr++) rows.add(new ArrayList<>(row));
                }
            }
            if (rows.isEmpty()) return;
            in.columns.addAll(makeUnique(rows.get(0)));
            for (int r = 1; r < rows.size(); r++) {
                Map<String,Object> row = new LinkedHashMap<>();
                for (int c = 0; c < in.columns.size(); c++) row.put(in.columns.get(c), c < rows.get(r).size() ? rows.get(r).get(c) : "");
                in.rows.add(row);
            }
        }
    }

    static int repeat(Element e, String attr) {
        String s = e.getAttribute(attr);
        if (s == null || s.isBlank()) return 1;
        try {
            return Math.max(1, Integer.parseInt(s));
        } catch (NumberFormatException ignored) {
            return 1;
        }
    }

    static String odsCellValue(Element cell) {
        String v = cell.getAttribute("office:string-value");
        if (!v.isEmpty()) return v;
        v = cell.getAttribute("office:value");
        if (!v.isEmpty()) return v;
        v = cell.getAttribute("office:date-value");
        if (!v.isEmpty()) return v;
        v = cell.getAttribute("office:boolean-value");
        if (!v.isEmpty()) return v;
        NodeList ps = cell.getElementsByTagName("text:p");
        if (ps.getLength() == 0) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < ps.getLength(); i++) {
            if (i > 0) b.append('\n');
            b.append(ps.item(i).getTextContent());
        }
        return b.toString();
    }

    static void addCol(Input in, String col) {
        if (!in.columns.contains(col)) in.columns.add(col);
    }

    static void load(Connection conn, String table, Input in) throws SQLException {
        try (Statement st = conn.createStatement()) {
            StringBuilder ddl = new StringBuilder("create table ").append(qi(table)).append(" (");
            for (int i = 0; i < in.columns.size(); i++) {
                if (i > 0) ddl.append(',');
                ddl.append(qi(in.columns.get(i)));
                if (!in.jsonTyped) ddl.append(" text");
            }
            ddl.append(')');
            st.execute(ddl.toString());
        }
        if (in.columns.isEmpty()) return;
        StringJoiner cols = new StringJoiner(",");
        StringJoiner qs = new StringJoiner(",");
        for (String c : in.columns) { cols.add(qi(c)); qs.add("?"); }
        try (PreparedStatement ps = conn.prepareStatement("insert into " + qi(table) + " (" + cols + ") values (" + qs + ")")) {
            for (Map<String,Object> row : in.rows) {
                for (int i = 0; i < in.columns.size(); i++) ps.setObject(i + 1, row.get(in.columns.get(i)));
                ps.executeUpdate();
            }
        }
    }

    static String rewriteQuery(String q, int n) {
        q = q.replace("{}", "{0}");
        for (int i = 0; i < n; i++) q = q.replace("{" + i + "}", "t" + i);
        return q;
    }

    static String qi(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    static void printJson(ResultSet rs) throws Exception {
        ResultSetMetaData md = rs.getMetaData();
        int cols = md.getColumnCount();
        System.out.print("[");
        boolean first = true;
        while (rs.next()) {
            if (!first) System.out.println(",");
            first = false;
            LinkedHashMap<String,Object> row = new LinkedHashMap<>();
            for (int i = 1; i <= cols; i++) row.put(md.getColumnLabel(i), rs.getObject(i));
            row.entrySet().removeIf(e -> e.getValue() == null);
            System.out.print(JSON.writeValueAsString(row));
        }
        System.out.println("]");
    }

    static void printPretty(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int n = md.getColumnCount();
        List<String> labels = new ArrayList<>();
        for (int i = 1; i <= n; i++) labels.add(md.getColumnLabel(i));
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < n; i++) order.add(i);
        order.sort(Comparator.comparing(labels::get));
        List<List<String>> rows = new ArrayList<>();
        while (rs.next()) {
            List<String> r = new ArrayList<>();
            for (int idx : order) {
                Object o = rs.getObject(idx + 1);
                r.add(o == null ? "null" : String.valueOf(o));
            }
            rows.add(r);
        }
        List<String> labs = new ArrayList<>();
        for (int idx : order) labs.add(labels.get(idx));
        int[] w = new int[n];
        for (int i = 0; i < n; i++) w[i] = labs.get(i).length();
        for (List<String> r : rows) for (int i = 0; i < n; i++) w[i] = Math.max(w[i], r.get(i).length());
        border(w);
        line(labs, w, false);
        border(w);
        for (List<String> r : rows) line(r, w, true);
        border(w);
        System.out.println("(" + rows.size() + (rows.size() == 1 ? " row)" : " rows)"));
    }

    static void border(int[] w) {
        StringBuilder b = new StringBuilder("+");
        for (int x : w) b.append("-".repeat(x + 2)).append("+");
        System.out.println(b);
    }

    static void line(List<String> vals, int[] w, boolean data) {
        StringBuilder b = new StringBuilder("|");
        for (int i = 0; i < vals.size(); i++) {
            String v = vals.get(i);
            boolean num = data && v.matches("-?\\d+(\\.\\d+)?");
            b.append(' ');
            if (num) b.append(" ".repeat(w[i] - v.length())).append(v);
            else if (!data) {
                int pad = w[i] - v.length();
                int left = pad / 2;
                int right = pad - left;
                b.append(" ".repeat(left)).append(v).append(" ".repeat(right));
            } else b.append(v).append(" ".repeat(w[i] - v.length()));
            b.append(" |");
        }
        System.out.println(b);
    }

    static void printSchema(Input in) throws Exception {
        Map<String,Object> root = new LinkedHashMap<>();
        root.put("kind", "array");
        Map<String,Object> arr = new LinkedHashMap<>();
        root.put("array", arr);
        arr.put("kind", "object");
        Map<String,Object> objWrap = new LinkedHashMap<>();
        arr.put("object", objWrap);
        for (String c : in.columns) objWrap.put(c, schemaFor(in, c));
        System.out.println(JSON.writerWithDefaultPrettyPrinter().writeValueAsString(root));
    }

    static Object schemaFor(Input in, String c) {
        boolean sawNull = false, sawString = false, sawNumber = false, sawBool = false;
        for (Map<String,Object> r : in.rows) {
            Object v = r.get(c);
            if (v == null) sawNull = true;
            else if (v instanceof Number) sawNumber = true;
            else if (v instanceof Boolean) sawBool = true;
            else sawString = true;
        }
        List<String> kinds = new ArrayList<>();
        if (sawString) kinds.add("string");
        if (sawNumber) kinds.add("number");
        if (sawBool) kinds.add("boolean");
        if (sawNull) kinds.add("null");
        if (kinds.size() <= 1) return scalar(kinds.isEmpty() ? "null" : kinds.get(0));
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("kind", "varied");
        List<Object> vars = new ArrayList<>();
        for (String k : kinds) vars.add(scalar(k));
        m.put("varied", vars);
        return m;
    }

    static Map<String,Object> scalar(String s) {
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("kind", "scalar");
        m.put("scalar", s);
        return m;
    }
}
