package dua;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class Dua {
    static final String GREEN = "\u001b[32m";
    static final String CYAN = "\u001b[36m";
    static final String RESET = "\u001b[39m";

    static class Config {
        String format = "binary";
        boolean apparent = false;
        boolean countHardLinks = false;
        boolean stayOnFilesystem = false;
        int threads = 0;
        List<Path> ignoreDirs = new ArrayList<>(Arrays.asList(Paths.get("/proc"), Paths.get("/dev"), Paths.get("/sys"), Paths.get("/run")));
    }

    static class Entry {
        Path path;
        String label;
        long size;
        boolean dir;
        boolean error;
        Entry(Path p, String l, long s, boolean d, boolean e) { path=p; label=l; size=s; dir=d; error=e; }
    }

    static class Stats {
        long entries = 0;
        long smallest = Long.MAX_VALUE;
        long largest = 0;
        int errors = 0;
        Set<Object> seenKeys = new HashSet<>();
        void add(long size) { entries++; smallest = Math.min(smallest, size); largest = Math.max(largest, size); }
    }

    public static void main(String[] args) {
        int code;
        try { code = run(args); }
        catch (Exception e) { System.err.println("error: " + e.getMessage()); code = 1; }
        if (code != 0) System.exit(code);
    }

    static int run(String[] args) throws IOException {
        Config cfg = new Config();
        List<String> rest = parseGlobal(args, cfg);
        if (rest == null) return 2;
        if (rest.isEmpty()) return aggregate(cfg, new ArrayList<>(), false, false, false);
        String cmd = rest.get(0);
        if (cmd.equals("--help") || cmd.equals("-h")) { printHelp(); return 0; }
        if (cmd.equals("--version") || cmd.equals("-V")) { System.out.println("dua 2.32.2"); return 0; }
        if (cmd.equals("help")) {
            if (rest.size() > 1 && (rest.get(1).equals("aggregate") || rest.get(1).equals("a"))) printAggregateHelp();
            else if (rest.size() > 1 && (rest.get(1).equals("interactive") || rest.get(1).equals("i"))) printInteractiveHelp();
            else if (rest.size() > 1 && rest.get(1).equals("completions")) printCompletionsHelp();
            else printHelp();
            return 0;
        }
        if (cmd.equals("aggregate") || cmd.equals("a")) return parseAggregate(cfg, rest.subList(1, rest.size()));
        if (cmd.equals("interactive") || cmd.equals("i")) {
            if (rest.size() > 1 && (rest.get(1).equals("--help") || rest.get(1).equals("-h"))) { printInteractiveHelp(); return 0; }
            System.err.println("Interactive mode is unavailable in this reimplementation. Use 'aggregate' instead.");
            return aggregate(cfg, rest.subList(1, rest.size()), false, false, false);
        }
        if (cmd.equals("completions")) return completions(rest.subList(1, rest.size()));
        if (cmd.startsWith("-")) return unexpected(cmd, "dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...");
        return aggregate(cfg, rest, false, false, false);
    }

    static List<String> parseGlobal(String[] args, Config cfg) {
        List<String> rest = new ArrayList<>();
        for (int i=0; i<args.length; i++) {
            String a = args[i];
            if (a.equals("--")) { for (int j=i+1;j<args.length;j++) rest.add(args[j]); break; }
            if (!rest.isEmpty()) { rest.add(a); continue; }
            switch (a) {
                case "-A": case "--apparent-size": cfg.apparent = true; break;
                case "-l": case "--count-hard-links": cfg.countHardLinks = true; break;
                case "-x": case "--stay-on-filesystem": cfg.stayOnFilesystem = true; break;
                case "-t": case "--threads":
                    if (i+1 >= args.length) return missingValue("--threads <THREADS>", null);
                    try { cfg.threads = Integer.parseInt(args[++i]); } catch(NumberFormatException e) { cfg.threads = 0; }
                    break;
                case "-f": case "--format":
                    if (i+1 >= args.length) return missingValue("--format <FORMAT>", "  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n");
                    cfg.format = args[++i];
                    if (!Arrays.asList("metric","binary","bytes","gb","gib","mb","mib").contains(cfg.format)) {
                        System.err.println("error: invalid value '" + cfg.format + "' for '--format <FORMAT>'");
                        System.err.println("  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n");
                        System.err.println("For more information, try '--help'.");
                        return null;
                    }
                    break;
                case "-i": case "--ignore-dirs":
                    if (i+1 >= args.length) return missingValue("--ignore-dirs <IGNORE_DIRS>", null);
                    cfg.ignoreDirs.add(Paths.get(args[++i]).toAbsolutePath().normalize());
                    break;
                case "--log-file":
                    if (i+1 >= args.length) return missingValue("--log-file <LOG_FILE>", null);
                    i++;
                    break;
                default:
                    rest.add(a);
            }
        }
        return rest;
    }

    static List<String> missingValue(String what, String extra) {
        System.err.println("error: a value is required for '" + what + "' but none was supplied");
        if (extra != null) System.err.print(extra + "\n");
        System.err.println("For more information, try '--help'.");
        return null;
    }

    static int parseAggregate(Config cfg, List<String> args) throws IOException {
        boolean stats=false, noSort=false, noTotal=false;
        List<String> inputs = new ArrayList<>();
        for (String a: args) {
            if (a.equals("--help") || a.equals("-h")) { printAggregateHelp(); return 0; }
            else if (a.equals("--stats")) stats=true;
            else if (a.equals("--no-sort")) noSort=true;
            else if (a.equals("--no-total")) noTotal=true;
            else if (a.startsWith("-")) return unexpected(a, "executable aggregate [OPTIONS] [INPUT]...");
            else inputs.add(a);
        }
        return aggregate(cfg, inputs, stats, noSort, noTotal);
    }

    static int aggregate(Config cfg, List<String> inputStrings, boolean printStats, boolean noSort, boolean noTotal) throws IOException {
        List<Path> roots = new ArrayList<>();
        boolean expandedSingleDir = false;
        if (inputStrings.isEmpty()) {
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(Paths.get("."))) {
                for (Path p: ds) roots.add(p.getFileName());
            }
            expandedSingleDir = true;
        } else if (inputStrings.size() == 1 && Files.isDirectory(Paths.get(inputStrings.get(0)), LinkOption.NOFOLLOW_LINKS)) {
            Path base = Paths.get(inputStrings.get(0));
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(base)) {
                for (Path p: ds) roots.add(p);
            }
            expandedSingleDir = true;
        } else {
            for (String s: inputStrings) roots.add(Paths.get(s));
        }
        Stats st = new Stats();
        List<Entry> entries = new ArrayList<>();
        for (Path p: roots) {
            boolean exists = Files.exists(p, LinkOption.NOFOLLOW_LINKS);
            if (!exists) {
                st.errors++;
                String label = expandedSingleDir ? fileName(p) : p.toString();
                entries.add(new Entry(p, label, 0, true, true));
                continue;
            }
            boolean explicitRoot = !expandedSingleDir;
            boolean symlink = Files.isSymbolicLink(p);
            if (symlink && !explicitRoot) {
                continue;
            }
            if (symlink) {
                boolean targetExists = Files.exists(p);
                if (!targetExists) st.errors++;
                String label = expandedSingleDir ? fileName(p) : p.toString();
                entries.add(new Entry(p, label, 0, false, !targetExists));
                continue;
            }
            boolean dir = Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS);
            long size = sizeOf(p, cfg, st, explicitRoot);
            String label = expandedSingleDir ? fileName(p) : p.toString();
            entries.add(new Entry(p, label, size, dir, false));
        }
        if (!noSort) {
            if (expandedSingleDir) {
                entries.sort(Comparator.comparingLong((Entry e) -> e.size).thenComparing(e -> e.label));
            } else {
                entries.sort(Comparator.comparingLong((Entry e) -> e.size));
            }
        }
        long total = 0;
        for (Entry e: entries) {
            total += e.size;
            printEntry(cfg, e);
        }
        if (!noTotal && entries.size() > 1) {
            printLine(formatSize(total, cfg.format), "total" + (st.errors > 0 ? "  <" + st.errors + " IO Error" + (st.errors == 1 ? "" : "s") + ">" : ""), false, false);
        }
        if (printStats) {
            long sm = st.smallest == Long.MAX_VALUE ? 0 : st.smallest;
            System.err.println("Statistics { entries_traversed: " + st.entries + ", smallest_file_in_bytes: " + sm + ", largest_file_in_bytes: " + st.largest + " }");
        }
        return st.errors > 0 ? 1 : 0;
    }

    static String fileName(Path p) {
        Path n = p.getFileName();
        return n == null ? p.toString() : n.toString();
    }

    static long sizeOf(Path p, Config cfg, Stats st, boolean isRoot) throws IOException {
        BasicFileAttributes attrs;
        try { attrs = Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); }
        catch (IOException e) { st.errors++; return 0; }
        if (attrs.isSymbolicLink()) {
            return 0;
        }
        if (!cfg.countHardLinks && attrs.isRegularFile()) {
            Object key = attrs.fileKey();
            if (key != null && !st.seenKeys.add(key)) return 0;
        }
        long self = cfg.apparent ? attrs.size() : diskUsage(p, attrs);
        if (!attrs.isDirectory()) { st.add(self); return self; }
        st.add(self);
        if (isIgnored(p, cfg, isRoot)) return self;
        long sum = self;
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(p)) {
            for (Path child: ds) sum += sizeOf(child, cfg, st, false);
        } catch (IOException e) { st.errors++; }
        return sum;
    }

    static boolean isIgnored(Path p, Config cfg, boolean isRoot) {
        if (isRoot) return false;
        Path abs = p.toAbsolutePath().normalize();
        for (Path ign: cfg.ignoreDirs) if (abs.equals(ign)) return true;
        return false;
    }

    static long diskUsage(Path p, BasicFileAttributes attrs) {
        try {
            Object blocks = Files.getAttribute(p, "unix:blocks", LinkOption.NOFOLLOW_LINKS);
            if (blocks instanceof Number) return ((Number)blocks).longValue() * 512L;
        } catch (Exception ignored) {}
        long s = attrs.size();
        if (s == 0 && attrs.isRegularFile()) return 0;
        long block = 4096;
        return ((s + block - 1) / block) * block;
    }

    static void printEntry(Config cfg, Entry e) {
        if (e.error) {
            System.out.println(GREEN + formatSize(e.size, cfg.format) + RESET + " " + CYAN + e.label + RESET + "  <1 IO Error>");
        } else {
            printLine(formatSize(e.size, cfg.format), e.label, e.dir, false);
        }
    }

    static void printLine(String size, String label, boolean cyan, boolean error) {
        String name = cyan ? CYAN + label + RESET : label;
        System.out.println(GREEN + size + RESET + " " + name);
    }

    static String formatSize(long bytes, String fmt) {
        switch(fmt) {
            case "bytes": return String.format(Locale.US, "%10d b", bytes);
            case "metric": return human(bytes, 1000, new String[]{"B","KB","MB","GB","TB"}, true, 10);
            case "binary": return human(bytes, 1024, new String[]{"B","KiB","MiB","GiB","TiB"}, false, 10);
            case "gb": return String.format(Locale.US, "%7.2f GB", bytes / 1_000_000_000.0);
            case "gib": return String.format(Locale.US, "%6.2f GiB", bytes / 1073741824.0);
            case "mb": return String.format(Locale.US, "%9.2f MB", bytes / 1_000_000.0);
            case "mib": return String.format(Locale.US, "%8.2f MiB", bytes / 1048576.0);
            default: return human(bytes, 1024, new String[]{"B","KiB","MiB","GiB","TiB"}, false, 10);
        }
    }

    static String human(long bytes, int base, String[] units, boolean metric, int width) {
        if (bytes == 0) return "      0   B";
        double v = bytes;
        int u = 0;
        while (u < units.length-1 && v > base) { v /= base; u++; }
        if (u == 0) return String.format(Locale.US, "%7d   B", bytes);
        return String.format(Locale.US, "%7.2f %s", v, units[u]);
    }

    static int completions(List<String> args) {
        if (args.isEmpty() || args.get(0).equals("--help") || args.get(0).equals("-h")) { printCompletionsHelp(); return 0; }
        String sh = args.get(0);
        if (!Arrays.asList("bash","elvish","fish","powershell","zsh").contains(sh)) {
            System.err.println("error: invalid value '" + sh + "' for '<SHELL>'");
            System.err.println("  [possible values: bash, elvish, fish, powershell, zsh]");
            return 2;
        }
        System.out.println("# completion script for dua (" + sh + ")");
        return 0;
    }

    static int unexpected(String arg, String usage) {
        System.err.println("error: unexpected argument '" + arg + "' found\n");
        System.err.println("  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'\n");
        System.err.println("Usage: " + usage + "\n");
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    static void printHelp() {
        System.out.println("A tool to learn about disk usage, fast!\n");
        System.out.println("Usage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n");
        System.out.println("Commands:");
        System.out.println("  interactive  Launch the terminal user interface [aliases: i]");
        System.out.println("  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]");
        System.out.println("  completions  Generate shell completions");
        System.out.println("  help         Print this message or the help of the given subcommand(s)\n");
        System.out.println("Arguments:\n  [INPUT]...\n          One or more input files or directories. If unset, we will use all entries in the current working directory\n");
        System.out.println("Options:");
        System.out.println("  -t, --threads <THREADS>\n          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread\n          \n          [default: 0]\n");
        System.out.println("  -f, --format <FORMAT>\n          The format with which to print byte counts\n          \n          [default: binary]\n          [possible values: metric, binary, bytes, gb, gib, mb, mib]\n");
        System.out.println("  -A, --apparent-size\n          Display apparent size instead of disk usage\n");
        System.out.println("  -l, --count-hard-links\n          Count hard-linked files each time they are seen\n");
        System.out.println("  -x, --stay-on-filesystem\n          If set, we will not cross filesystems or traverse mount points\n");
        System.out.println("  -i, --ignore-dirs <IGNORE_DIRS>\n          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.\n          \n          Hence, they will only be ignored if they are eventually reached as part of the traversal.\n          \n          [default: /proc /dev /sys /run]\n");
        System.out.println("      --log-file <LOG_FILE>\n          Write a log file with debug information, including panics\n");
        System.out.println("  -h, --help\n          Print help (see a summary with '-h')\n");
        System.out.println("  -V, --version\n          Print version");
    }

    static void printAggregateHelp() {
        System.out.println("Aggregate the consumed space of one or more directories or files\n");
        System.out.println("Usage: executable aggregate [OPTIONS] [INPUT]...\n");
        System.out.println("Arguments:\n  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory\n");
        System.out.println("Options:");
        System.out.println("      --stats     If set, print additional statistics about the file traversal to stderr");
        System.out.println("      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending");
        System.out.println("      --no-total  If set, no total column will be computed for multiple inputs");
        System.out.println("  -h, --help      Print help");
    }

    static void printInteractiveHelp() {
        System.out.println("Launch the terminal user interface\n");
        System.out.println("Usage: executable interactive [OPTIONS] [INPUT]...\n");
        System.out.println("Arguments:\n  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory\n");
        System.out.println("Options:");
        System.out.println("  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems");
        System.out.println("  -h, --help            Print help");
    }

    static void printCompletionsHelp() {
        System.out.println("Generate shell completions\n");
        System.out.println("Usage: executable completions <SHELL>\n");
        System.out.println("Arguments:");
        System.out.println("  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]\n");
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }
}
