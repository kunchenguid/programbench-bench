import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class Main {
    private static final String VERSION = "lnav 0.14.0-07efb63";

    public static void main(String[] args) {
        try {
            new Main().run(args);
        } catch (BrokenPipe ignored) {
        } catch (Exception e) {
            System.err.println("  error: " + e.getMessage());
        }
    }

    private void run(String[] args) throws IOException {
        Options opt = parse(args);
        if (opt.invalid != null) {
            error("invalid command-line arguments", opt.invalid);
            return;
        }
        if (opt.version) {
            System.out.println(VERSION);
            return;
        }
        if (opt.help) {
            printHelp();
            return;
        }
        if (opt.management) {
            printManagementError();
            return;
        }
        if (opt.update) {
            System.out.println("No formats from git repositories found, use 'lnav -i extra' to install third-party formats");
            return;
        }
        if (opt.installMode) {
            handleInstall(opt.paths);
            return;
        }
        if (opt.configCheck) {
            return;
        }
        if (opt.internalHelp && !opt.headless) {
            tuiError();
            return;
        }
        if (!opt.headless) {
            tuiError();
            return;
        }
        if (opt.commandFile != null) {
            List<String> lines = Files.exists(opt.commandFile)
                    ? Files.readAllLines(opt.commandFile, StandardCharsets.UTF_8)
                    : Collections.emptyList();
            for (String line : lines) {
                String trimmed = line.trim();
                if (!trimmed.isEmpty() && !trimmed.startsWith("#") && !":quit".equals(trimmed)) {
                    System.out.println("  error: unknown command: \u201c" + trimmed + "\u201d");
                    return;
                }
            }
        }
        if (opt.quiet) {
            return;
        }
        for (String shellCommand : opt.shellCommands) {
            runShellCommand(shellCommand);
        }
        List<Path> files = new ArrayList<>();
        for (String p : opt.paths) {
            collectPath(Paths.get(p), opt.recursive, files, new HashSet<>());
        }
        files.sort(Comparator.comparing(Path::toString));
        boolean wrote = false;
        for (Path file : files) {
            if (Files.isRegularFile(file)) {
                wrote |= printFile(file, opt);
            }
        }
        if (!wrote && opt.treatStdin) {
            printStdinWithTimestamps();
        }
    }

    private Options parse(String[] args) {
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h":
                case "--help":
                    opt.help = true;
                    break;
                case "-V":
                case "--version":
                    opt.version = true;
                    break;
                case "-H":
                    opt.internalHelp = true;
                    break;
                case "-n":
                    opt.headless = true;
                    break;
                case "-N":
                    opt.noDefault = true;
                    break;
                case "-q":
                    opt.quiet = true;
                    break;
                case "-r":
                    opt.recursive = true;
                    break;
                case "-R":
                    opt.rotated = true;
                    break;
                case "-t":
                    opt.treatStdin = true;
                    break;
                case "-W":
                    opt.warn = true;
                    break;
                case "-u":
                    opt.update = true;
                    break;
                case "-m":
                    opt.management = true;
                    break;
                case "-C":
                    opt.configCheck = true;
                    break;
                case "-i":
                    opt.installMode = true;
                    break;
                case "-I":
                case "-d":
                case "-c":
                    if (i + 1 >= args.length) {
                        opt.invalid = a + ": 1 required TEXT missing";
                        return opt;
                    }
                    i++;
                    break;
                case "-e":
                    if (i + 1 >= args.length) {
                        opt.invalid = a + ": 1 required TEXT missing";
                        return opt;
                    }
                    opt.shellCommands.add(args[++i]);
                    break;
                case "-f":
                    if (i + 1 >= args.length) {
                        opt.invalid = a + ": 1 required TEXT missing";
                        return opt;
                    }
                    opt.commandFile = Paths.get(args[++i]);
                    break;
                case "-S":
                case "--since":
                    if (i + 1 >= args.length) {
                        opt.invalid = "--since: 1 required TEXT missing";
                        return opt;
                    }
                    opt.since = parseTimeArg(args[++i]);
                    break;
                case "-U":
                case "--until":
                    if (i + 1 >= args.length) {
                        opt.invalid = "--until: 1 required TEXT missing";
                        return opt;
                    }
                    opt.until = parseTimeArg(args[++i], true);
                    break;
                default:
                    if (a.startsWith("--since=")) {
                        opt.since = parseTimeArg(a.substring("--since=".length()));
                        break;
                    }
                    if (a.startsWith("--until=")) {
                        opt.until = parseTimeArg(a.substring("--until=".length()), true);
                        break;
                    }
                    if (a.startsWith("--help=")) {
                        opt.help = true;
                        break;
                    }
                    if (a.startsWith("-")) {
                        opt.invalid = "The following argument was not expected: " + a;
                        return opt;
                    }
                    opt.paths.add(a);
                    break;
            }
        }
        return opt;
    }

    private static LocalDateTime parseTimeArg(String s) {
        return parseTimeArg(s, false);
    }

    private static LocalDateTime parseTimeArg(String s, boolean until) {
        String v = s.trim();
        try {
            return LocalDateTime.parse(v, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        } catch (DateTimeParseException ignored) {
        }
        try {
            return OffsetDateTime.parse(v).toLocalDateTime();
        } catch (DateTimeParseException ignored) {
        }
        try {
            LocalDate date = LocalDate.parse(v, DateTimeFormatter.ISO_LOCAL_DATE);
            return until ? date.atTime(23, 59, 59, 999_000_000) : date.atStartOfDay();
        } catch (DateTimeParseException ignored) {
        }
        try {
            DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ROOT);
            return LocalDateTime.parse(v, f);
        } catch (DateTimeParseException ignored) {
        }
        return null;
    }

    private void runShellCommand(String command) throws IOException {
        Process process = new ProcessBuilder("bash", "-lc", command)
                .redirectErrorStream(true)
                .start();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        }
        try {
            process.waitFor();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void collectPath(Path p, boolean recursive, List<Path> out, Set<Path> seen) throws IOException {
        if (!Files.exists(p)) {
            error("unable to open file: " + p, "No such file or directory");
            return;
        }
        Path real = p.toRealPath();
        if (!seen.add(real)) {
            return;
        }
        if (Files.isRegularFile(p)) {
            out.add(p);
        } else if (Files.isDirectory(p)) {
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(p)) {
                for (Path child : ds) {
                    if (Files.isRegularFile(child)) {
                        out.add(child);
                    } else if (recursive && Files.isDirectory(child)) {
                        collectPath(child, true, out, seen);
                    }
                }
            }
        }
    }

    private boolean printFile(Path file, Options opt) throws IOException {
        boolean wrote = false;
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            LocalDateTime ts = extractTimestamp(line);
            if (opt.since != null && ts != null && ts.isBefore(opt.since)) {
                continue;
            }
            if (opt.until != null && ts != null && ts.isAfter(opt.until)) {
                continue;
            }
            System.out.println(line);
            wrote = true;
        }
        return wrote;
    }

    private void printStdinWithTimestamps() throws IOException {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS", Locale.ROOT);
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(LocalDateTime.now(ZoneOffset.UTC).format(f) + " " + line);
            }
        }
    }

    private static LocalDateTime extractTimestamp(String line) {
        if (line.length() >= 19) {
            String s = line.substring(0, 19);
            try {
                return LocalDateTime.parse(s, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ROOT));
            } catch (DateTimeParseException ignored) {
            }
        }
        if (line.length() >= 10) {
            try {
                return LocalDate.parse(line.substring(0, 10), DateTimeFormatter.ISO_LOCAL_DATE).atStartOfDay();
            } catch (DateTimeParseException ignored) {
            }
        }
        return null;
    }

    private void handleInstall(List<String> paths) throws IOException {
        if (paths.isEmpty()) {
            return;
        }
        for (String p : paths) {
            Path path = Paths.get(p);
            if (!Files.exists(path)) {
                error("unable to open configuration file: " + p, "No such file or directory");
                continue;
            }
            String data = Files.readString(path, StandardCharsets.UTF_8).trim();
            if (!data.startsWith("{") && !data.startsWith("[")) {
                System.out.println("  error: unable to open configuration file: " + p);
                System.out.println(" reason: JSON parsing failed -- lexical error: invalid char in json text.");
                return;
            }
        }
    }

    private static void error(String err, String reason) {
        System.out.println("  error: " + err);
        System.out.println(" reason: " + reason);
    }

    private static void tuiError() {
        System.out.println("  error: unable to display interactive text UI");
        System.out.println(" reason: stdout is not a TTY");
        System.out.println(" = help: pass the -n option to run lnav in headless mode or don't redirect stdout");
    }

    private static void printManagementError() {
        System.out.println("  error: expecting an operation to perform");
        System.out.println(" = help: the available operations are:");
        System.out.println("          \u2022 apps: manage lnav apps");
        System.out.println("          \u2022 config: perform operations on the lnav configuration");
        System.out.println("          \u2022 format: perform operations on log file formats");
        System.out.println("          \u2022 piper: perform operations on piper storage");
        System.out.println("          \u2022 regex101: create and edit log message regular expressions using regex101.com");
        System.out.println("          \u2022 crash: manage crash logs");
    }

    private static void printHelp() {
        System.out.println("usage: ./executable [options] [logfile1 logfile2 ...]");
        System.out.println();
        System.out.println("A log file viewer for the terminal that indexes log messages to");
        System.out.println("make it easier to navigate through files quickly.");
        System.out.println();
        System.out.println("Key Bindings");
        System.out.println("  ?    View/leave the online help text.");
        System.out.println("  q    Quit the program.");
        System.out.println();
        System.out.println("Options");
        System.out.println("  -h         Print this message, then exit.");
        System.out.println("  -H         Display the internal help text.");
        System.out.println();
        System.out.println("  -I dir     An additional configuration directory.");
        System.out.println("  -W         Print warnings related to lnav's configuration.");
        System.out.println("  -u         Update formats installed from git repositories.");
        System.out.println("  -d file    Write debug messages to the given file.");
        System.out.println("  -V         Print version information.");
        System.out.println();
        System.out.println("  -S,--since Only index log content since this time.");
        System.out.println("  -U,--until Only index log content until this time.");
        System.out.println("  -r         Recursively load files from the given directory hierarchies.");
        System.out.println("  -R         Load older rotated log files as well.");
        System.out.println("  -c cmd     Execute a command after the files have been loaded.");
        System.out.println("  -f file    Execute the commands in the given file.");
        System.out.println("  -e cmd     Execute a shell command-line.");
        System.out.println("  -t         Treat data piped into standard in as a log file.");
        System.out.println("  -n         Run without the curses UI. (headless mode)");
        System.out.println("  -N         Do not open the default syslog file if no files are given.");
        System.out.println("  -q         Do not print informational messages.");
        System.out.println();
        System.out.println("Optional arguments");
        System.out.println("  logfileN   The log files, directories, or remote paths to view.");
        System.out.println("             If a directory is given, all of the files in the");
        System.out.println("             directory will be loaded.");
        System.out.println();
        System.out.println("Management-Mode Options");
        System.out.println("  -i         Install the given format files and exit.  Pass 'extra'");
        System.out.println("             to install the default set of third-party formats.");
        System.out.println("  -m         Switch to the management command-line mode.  This mode");
        System.out.println("             is used to work with lnav's configuration.");
        System.out.println();
        System.out.println("Examples");
        System.out.println(" \u2022 To load and follow the syslog file:");
        System.out.println("     $ lnav                                  ");
        System.out.println();
        System.out.println(" \u2022 To load all of the files in /var/log:");
        System.out.println("     $ lnav /var/log                         ");
        System.out.println();
        System.out.println(" \u2022 To watch the output of make:");
        System.out.println("     $ lnav -e 'make -j4'                    ");
        System.out.println();
        System.out.println("Paths");
        System.out.println(" \u2022 This binary:");
        System.out.println("    \ud83e\udded /workspace/executable");
        System.out.println(" \u2022 Format files are read from:");
        System.out.println("    \ud83d\udcc2 /etc/lnav");
        System.out.println("    \ud83d\udcc2 /usr/etc/lnav");
        System.out.println(" \u2022 Configuration, session, and format files are stored in:");
        System.out.println("    \ud83d\udcc2 /home/agent/.lnav");
        System.out.println();
        System.out.println(" \u2022 Local copies of remote files, files extracted from");
        System.out.println("   archives, execution output, and so on are stored in:");
        System.out.println("    \ud83d\udcc2 /tmp/lnav-user-1000-work");
        System.out.println();
        System.out.println("Documentation: https://docs.lnav.org");
        System.out.println("Contact");
        System.out.println("  \ud83d\udcac https://github.com/tstack/lnav/discussions");
        System.out.println("  \ud83d\udceb lnav@googlegroups.com");
        System.out.println("Version: " + VERSION);
    }

    private static class Options {
        boolean help;
        boolean version;
        boolean internalHelp;
        boolean headless;
        boolean noDefault;
        boolean quiet;
        boolean recursive;
        boolean rotated;
        boolean treatStdin;
        boolean warn;
        boolean update;
        boolean management;
        boolean installMode;
        boolean configCheck;
        Path commandFile;
        LocalDateTime since;
        LocalDateTime until;
        String invalid;
        List<String> paths = new ArrayList<>();
        List<String> shellCommands = new ArrayList<>();
    }

    private static class BrokenPipe extends RuntimeException {
    }
}
