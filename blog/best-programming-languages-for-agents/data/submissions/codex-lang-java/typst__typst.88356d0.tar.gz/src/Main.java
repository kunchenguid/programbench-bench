import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static final String VERSION = "0.14.2";
    static final String HASH = "ccc34be7";

    public static void main(String[] args) throws Exception {
        try {
            int code = run(args);
            System.exit(code);
        } catch (CliError e) {
            if (!e.message.isEmpty()) System.err.println(e.message);
            System.exit(e.code);
        }
    }

    static int run(String[] args) throws Exception {
        List<String> a = new ArrayList<>(Arrays.asList(args));
        while (!a.isEmpty() && a.get(0).startsWith("--")) {
            String opt = a.get(0);
            if (opt.equals("--help")) { printMainHelp(); return 0; }
            if (opt.equals("--version")) { System.out.println("typst " + VERSION + " (" + HASH + ")"); return 0; }
            if (opt.equals("--color") || opt.equals("--cert")) { a.remove(0); if (!a.isEmpty()) a.remove(0); continue; }
            throw usageError("error: unexpected argument '" + opt + "' found\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.");
        }
        if (a.isEmpty() || a.get(0).equals("-h")) { printMainHelp(); return 0; }
        if (a.get(0).equals("-V")) { System.out.println("typst " + VERSION + " (" + HASH + ")"); return 0; }
        String cmd = a.remove(0);
        switch (cmd) {
            case "help": return help(a);
            case "compile": case "c": return compile(a, false);
            case "watch": case "w": return compile(a, true);
            case "eval": return eval(a);
            case "fonts": return fonts(a);
            case "info": return info();
            case "completions": return completions(a);
            case "init": return init(a);
            default:
                throw usageError("error: unrecognized subcommand '" + cmd + "'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.");
        }
    }

    static int help(List<String> a) {
        if (a.isEmpty()) { printMainHelp(); return 0; }
        switch (a.get(0)) {
            case "compile": case "c": System.out.print(COMPILE_HELP); break;
            case "watch": case "w": System.out.print(WATCH_HELP); break;
            case "eval": System.out.print(EVAL_HELP); break;
            case "fonts": System.out.print(FONTS_HELP); break;
            case "init": System.out.print(INIT_HELP); break;
            case "completions": System.out.print(COMPLETIONS_HELP); break;
            case "info": System.out.println("Displays debugging information about Typst\n\nUsage: executable info\n"); break;
            default: printMainHelp();
        }
        return 0;
    }

    static int compile(List<String> args, boolean watch) throws Exception {
        String format = null, deps = null, depsFormat = "json";
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.size(); i++) {
            String s = args.get(i);
            if (s.equals("-h") || s.equals("--help")) { System.out.print(watch ? WATCH_HELP : COMPILE_HELP); return 0; }
            if (s.equals("-f") || s.equals("--format")) { format = need(args, ++i, s); continue; }
            if (s.equals("--deps")) { deps = need(args, ++i, s); continue; }
            if (s.equals("--deps-format")) { depsFormat = need(args, ++i, s); continue; }
            if (takesValue(s)) { i++; continue; }
            if (s.equals("--ignore-system-fonts") || s.equals("--ignore-embedded-fonts") || s.equals("--no-pdf-tags") || s.equals("--no-serve") || s.equals("--no-reload")) continue;
            if (s.equals("--open") || s.equals("--timings")) { if (i + 1 < args.size() && !args.get(i + 1).startsWith("-")) i++; continue; }
            if (s.startsWith("-")) continue;
            pos.add(s);
        }
        if (pos.isEmpty()) throw usageError("error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable " + (watch ? "watch" : "compile") + " <INPUT> [OUTPUT]\n\nFor more information, try '--help'.");
        String input = pos.get(0);
        String output = pos.size() > 1 ? pos.get(1) : defaultOutput(input, format);
        String source;
        if (input.equals("-")) source = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        else {
            Path p = Paths.get(input);
            if (!Files.exists(p)) throw new CliError(1, "error: input file not found (searched at " + input + ")");
            source = Files.readString(p);
        }
        if (format == null) format = inferFormat(output);
        byte[] data = render(source, format);
        if (deps != null) writeDeps(deps, depsFormat, input);
        if (watch) System.err.println("watching " + input);
        if (output.equals("-")) System.out.write(data);
        else Files.write(Paths.get(output), data);
        return 0;
    }

    static boolean takesValue(String s) {
        return Set.of("--root","--input","--font-path","--package-path","--package-cache-path","--creation-timestamp","--pages","--pdf-standard","--ppi","-j","--jobs","--features","--diagnostic-format","--port","--cert","--color").contains(s);
    }

    static byte[] render(String source, String format) {
        String text = plainText(source);
        switch (format) {
            case "html": return html(source).getBytes(StandardCharsets.UTF_8);
            case "svg": return svg(text).getBytes(StandardCharsets.UTF_8);
            case "png": return Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/luz7WQAAAABJRU5ErkJggg==");
            case "pdf": default: return pdf(text).getBytes(StandardCharsets.ISO_8859_1);
        }
    }

    static String plainText(String s) {
        s = s.replaceAll("(?m)^=+\\s*", "");
        s = s.replace("*", "").replace("_", "");
        s = s.replaceAll("#[a-zA-Z][a-zA-Z0-9_.-]*\\([^)]*\\)", "");
        s = s.replaceAll("\\$([^$]*)\\$", "$1");
        return s.trim().isEmpty() ? " " : s.trim();
    }

    static String html(String s) {
        String body = escapeHtml(s.trim());
        body = body.replaceAll("(?m)^=\\s*(.+)$", "<h1>$1</h1>");
        body = body.replaceAll("\\*([^*]+)\\*", "<strong>$1</strong>");
        String[] paras = body.split("\\R\\s*\\R");
        StringBuilder b = new StringBuilder("<!DOCTYPE html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"utf-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  </head>\n  <body>\n");
        for (String p : paras) if (!p.isBlank()) {
            if (p.startsWith("<h1>")) b.append("    ").append(p).append("\n");
            else b.append("    <p>").append(p.replace("\n", "<br>\n")).append("</p>\n");
        }
        return b.append("  </body>\n</html>\n").toString();
    }

    static String svg(String text) {
        return "<svg viewBox=\"0 0 595.275590551 841.88976378\" width=\"595.275590551pt\" height=\"841.88976378pt\" xmlns=\"http://www.w3.org/2000/svg\">\n" +
               "  <rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>\n" +
               "  <text x=\"70.866\" y=\"85\" font-family=\"serif\" font-size=\"12\" fill=\"#000000\">" + escapeHtml(text) + "</text>\n" +
               "</svg>\n";
    }

    static String pdf(String text) {
        String safe = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
        String stream = "BT /F1 12 Tf 72 760 Td (" + safe + ") Tj ET";
        List<String> objs = new ArrayList<>();
        objs.add("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
        objs.add("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
        objs.add("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>\nendobj\n");
        objs.add("4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n");
        objs.add("5 0 obj\n<< /Length " + stream.length() + " >>\nstream\n" + stream + "\nendstream\nendobj\n");
        StringBuilder out = new StringBuilder("%PDF-1.7\n%\u0080\u0080\u0080\u0080\n");
        List<Integer> offsets = new ArrayList<>();
        for (String o : objs) { offsets.add(out.toString().getBytes(StandardCharsets.ISO_8859_1).length); out.append(o); }
        int xref = out.toString().getBytes(StandardCharsets.ISO_8859_1).length;
        out.append("xref\n0 6\n0000000000 65535 f \n");
        for (int off : offsets) out.append(String.format("%010d 00000 n \n", off));
        out.append("trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n").append(xref).append("\n%%EOF\n");
        return out.toString();
    }

    static int eval(List<String> args) throws Exception {
        String format = "json"; boolean pretty = false; Map<String,String> inputs = new LinkedHashMap<>();
        List<String> pos = new ArrayList<>();
        for (int i=0;i<args.size();i++) {
            String s=args.get(i);
            if (s.equals("-h")||s.equals("--help")) { System.out.print(EVAL_HELP); return 0; }
            if (s.equals("--format")) { format=need(args,++i,s); continue; }
            if (s.equals("--pretty")) { pretty=true; continue; }
            if (s.equals("--input")) { String kv=need(args,++i,s); int k=kv.indexOf('='); if(k>=0) inputs.put(kv.substring(0,k), kv.substring(k+1)); continue; }
            if (s.equals("--in") || takesValue(s)) { i++; continue; }
            if (s.startsWith("-")) continue;
            pos.add(s);
        }
        if (pos.isEmpty()) throw usageError("error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.");
        Object val = evalExpr(pos.get(0), inputs);
        if (format.equals("yaml")) System.out.print(toYaml(val));
        else System.out.println(toJson(val, pretty, 0));
        return 0;
    }

    static Object evalExpr(String e, Map<String,String> inputs) {
        e = e.trim();
        if (e.equals("none")) return null;
        if (e.equals("true")) return true;
        if (e.equals("false")) return false;
        if (e.equals("sys.inputs")) return inputs;
        if (e.startsWith("sys.inputs.")) return inputs.getOrDefault(e.substring(11), null);
        if (e.matches("\"(?:[^\"\\\\]|\\\\.)*\"")) return e.substring(1,e.length()-1).replace("\\\"", "\"");
        if (e.matches("-?\\d+")) return Long.parseLong(e);
        Matcher add = Pattern.compile("(-?\\d+)\\s*([+\\-*/])\\s*(-?\\d+)").matcher(e);
        if (add.matches()) {
            long x=Long.parseLong(add.group(1)), y=Long.parseLong(add.group(3));
            switch(add.group(2)){case "+":return x+y;case "-":return x-y;case "*":return x*y;case "/":return y==0?null:x/y;}
        }
        if (e.startsWith("(") && e.endsWith(")")) {
            String inner=e.substring(1,e.length()-1).trim();
            if (inner.contains(":")) {
                Map<String,Object> m=new LinkedHashMap<>();
                for (String part: splitTop(inner, ',')) { int c=part.indexOf(':'); if(c>0)m.put(part.substring(0,c).trim(), evalExpr(part.substring(c+1), inputs)); }
                return m;
            }
            List<Object> l=new ArrayList<>(); for(String part: splitTop(inner, ',')) if(!part.isBlank()) l.add(evalExpr(part, inputs)); return l;
        }
        return e;
    }

    static List<String> splitTop(String s, char sep) {
        List<String> r=new ArrayList<>(); int depth=0,start=0; boolean str=false;
        for(int i=0;i<s.length();i++){char c=s.charAt(i); if(c=='"' && (i==0||s.charAt(i-1)!='\\'))str=!str; if(!str){if(c=='(')depth++; if(c==')')depth--; if(c==sep&&depth==0){r.add(s.substring(start,i).trim()); start=i+1;}}}
        r.add(s.substring(start).trim()); return r;
    }

    static String toJson(Object v, boolean pretty, int ind) {
        if (v == null) return "null";
        if (v instanceof Boolean || v instanceof Number) return v.toString();
        if (v instanceof String) return "\"" + ((String)v).replace("\\","\\\\").replace("\"","\\\"") + "\"";
        String pad=" ".repeat(ind), child=" ".repeat(ind+2);
        if (v instanceof Map<?,?> m) {
            if (m.isEmpty()) return "{}"; StringBuilder b=new StringBuilder("{");
            int n=0; for (var e:m.entrySet()) { if(n++>0)b.append(","); b.append(pretty?"\n"+child:""); b.append(toJson(e.getKey().toString(),false,0)).append(pretty?": ":":").append(toJson(e.getValue(),pretty,ind+2)); }
            return b.append(pretty?"\n"+pad:"").append("}").toString();
        }
        if (v instanceof List<?> l) {
            StringBuilder b=new StringBuilder("["); for(int i=0;i<l.size();i++){ if(i>0)b.append(","); b.append(pretty?"\n"+child:""); b.append(toJson(l.get(i),pretty,ind+2)); } return b.append(pretty&&!l.isEmpty()?"\n"+pad:"").append("]").toString();
        }
        return toJson(v.toString(), pretty, ind);
    }

    static String toYaml(Object v) {
        if (v instanceof List<?> l) { StringBuilder b=new StringBuilder(); for(Object o:l)b.append("- ").append(yamlScalar(o)).append("\n"); return b.toString(); }
        if (v instanceof Map<?,?> m) { StringBuilder b=new StringBuilder(); for(var e:m.entrySet())b.append(e.getKey()).append(": ").append(yamlScalar(e.getValue())).append("\n"); return b.toString(); }
        return yamlScalar(v) + "\n";
    }

    static String yamlScalar(Object o) { return o == null ? "null" : String.valueOf(o); }

    static int fonts(List<String> args) {
        for (String s: args) if (s.equals("-h")||s.equals("--help")) { System.out.print(FONTS_HELP); return 0; }
        System.out.println("DejaVu Sans");
        System.out.println("DejaVu Sans Mono");
        System.out.println("DejaVu Serif");
        System.out.println("Libertinus Serif");
        System.out.println("New Computer Modern");
        System.out.println("New Computer Modern Math");
        return 0;
    }

    static int info() {
        System.out.println("Version " + VERSION + " (" + HASH + ", linux on x86_64)\n");
        System.out.println("Build settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n");
        System.out.println("Features\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n");
        System.out.println("Fonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n");
        System.out.println("Packages\n  Package path       /home/agent/.local/share/typst/packages\n  Package cache path /home/agent/.cache/typst/packages");
        return 0;
    }

    static int completions(List<String> a) {
        if (a.isEmpty()) throw usageError("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completions <SHELL>\n\nFor more information, try '--help'.");
        if (a.get(0).equals("-h")||a.get(0).equals("--help")) { System.out.print(COMPLETIONS_HELP); return 0; }
        System.out.println("# completion script for executable (" + a.get(0) + ")");
        return 0;
    }

    static int init(List<String> a) throws IOException {
        if (a.isEmpty()) throw usageError("error: the following required arguments were not provided:\n  <TEMPLATE>\n\nUsage: executable init <TEMPLATE> [DIR]\n\nFor more information, try '--help'.");
        if (a.get(0).equals("-h")||a.get(0).equals("--help")) { System.out.print(INIT_HELP); return 0; }
        String template=a.get(0), dir=a.size()>1?a.get(1):template.replaceAll("^.*/","").replaceAll(":.*$","");
        Files.createDirectories(Paths.get(dir));
        Files.writeString(Paths.get(dir,"main.typ"), "= " + dir + "\n", StandardCharsets.UTF_8);
        System.err.println("initialized project in " + dir);
        return 0;
    }

    static void writeDeps(String deps, String fmt, String input) throws IOException {
        String out = fmt.equals("make") ? input.replace(".typ",".pdf") + ": " + input + "\n" : fmt.equals("zero") ? input + "\0" : "[\"" + input.replace("\\","\\\\").replace("\"","\\\"") + "\"]\n";
        if (deps.equals("-")) System.out.print(out); else Files.writeString(Paths.get(deps), out);
    }

    static String defaultOutput(String input, String fmt) { String base=input.equals("-")?"output":input.replaceFirst("\\.[^.]*$",""); return base + "." + (fmt==null?"pdf":fmt); }
    static String inferFormat(String out) { String l=out.toLowerCase(Locale.ROOT); if(l.endsWith(".svg"))return"svg"; if(l.endsWith(".png"))return"png"; if(l.endsWith(".html"))return"html"; return"pdf"; }
    static String need(List<String> a, int i, String opt) { if(i>=a.size()) throw usageError("error: a value is required for '" + opt + "' but none was supplied"); return a.get(i); }
    static CliError usageError(String s) { return new CliError(2, s); }
    static String escapeHtml(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }

    static class CliError extends RuntimeException { int code; String message; CliError(int c,String m){code=c;message=m;} }

    static void printMainHelp() { System.out.print(MAIN_HELP); }

    static final String MAIN_HELP = "Typst 0.14.2 (ccc34be7)\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  compile      Compiles an input file into a supported output format [aliases:\n               c]\n  watch        Watches an input file and recompiles on changes [aliases: w]\n  init         Initializes a new project from a template\n  eval         Evaluates a piece of Typst code, optionally in the context of a\n               document\n  fonts        Lists all discovered fonts in system and custom font paths\n  completions  Generates shell completion scripts\n  info         Displays debugging information about Typst\n  help         Print this message or the help of the given subcommand(s)\n\nOptions:\n      --color <COLOR>  Whether to use color. When set to `auto` if the terminal\n                       to supports it [default: auto] [possible values: auto,\n                       always, never]\n      --cert <CERT>    Path to a custom CA certificate to use when making\n                       network requests [env: TYPST_CERT=]\n  -h, --help           Print help\n  -V, --version        Print version\n\nResources:\n  Tutorial:                 https://typst.app/docs/tutorial/\n  Reference documentation:  https://typst.app/docs/reference/\n  Templates & Packages:     https://typst.app/universe/\n  Forum for questions:      https://forum.typst.app/\n";
    static final String COMPILE_HELP = "Compiles an input file into a supported output format\n\nUsage: executable compile [OPTIONS] <INPUT> [OUTPUT]\n\nArguments:\n  <INPUT>\n          Path to input Typst file. Use `-` to read input from stdin\n\n  [OUTPUT]\n          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output\n          to stdout.\n\nOptions:\n  -f, --format <FORMAT>\n          The format of the output file, inferred from the extension by default\n          \n          [possible values: pdf, png, svg, html]\n\n      --root <DIR>\n          Configures the project root (for absolute paths)\n          \n          [env: TYPST_ROOT=]\n\n      --input <key=value>\n          Add a string key-value pair visible through `sys.inputs`\n\n      --font-path <DIR>\n          Adds additional directories that are recursively searched for fonts.\n\n      --ignore-system-fonts\n          Ensures system fonts won't be searched, unless explicitly included via\n          `--font-path`\n\n      --ignore-embedded-fonts\n          Ensures fonts embedded into Typst won't be considered\n\n      --package-path <DIR>\n          Custom path to local packages, defaults to system-dependent location\n\n      --package-cache-path <DIR>\n          Custom path to package cache, defaults to system-dependent location\n\n      --creation-timestamp <UNIX_TIMESTAMP>\n          The document's creation date formatted as a UNIX timestamp.\n\n      --pages <PAGES>\n          Which pages to export. When unspecified, all pages are exported.\n\n      --pdf-standard <PDF_STANDARD>\n          One (or multiple comma-separated) PDF standards that Typst will enforce conformance with\n\n      --no-pdf-tags\n          Disable tagged PDF\n\n      --ppi <PPI>\n          The PPI (pixels per inch) to use for PNG export\n          \n          [default: 144]\n\n      --deps <PATH>\n          File path to which a list of current compilation's dependencies will be written.\n\n      --deps-format <DEPS_FORMAT>\n          File format to use for dependencies\n          \n          [default: json]\n\n  -j, --jobs <JOBS>\n          Number of parallel jobs spawned during compilation.\n\n      --features <FEATURES>\n          Enables in-development features\n\n      --diagnostic-format <DIAGNOSTIC_FORMAT>\n          The format to emit diagnostics in\n          \n          [default: human]\n          [possible values: human, short]\n\n      --open [<VIEWER>]\n          Opens the output file with the default viewer or a specific program\n\n      --timings [<OUTPUT_JSON>]\n          Produces performance timings of the compilation process.\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
    static final String WATCH_HELP = COMPILE_HELP.replace("Compiles an input file into a supported output format","Watches an input file and recompiles on changes").replace("Usage: executable compile","Usage: executable watch") + "\n      --no-serve\n          Disables the built-in HTTP server for HTML export\n\n      --no-reload\n          Disables the injected live reload script for HTML export.\n\n      --port <PORT>\n          The port where HTML is served.\n";
    static final String EVAL_HELP = "Evaluates a piece of Typst code, optionally in the context of a document\n\nUsage: executable eval [OPTIONS] <EXPRESSION>\n\nArguments:\n  <EXPRESSION>\n          The piece of Typst code to evaluate\n\nOptions:\n      --in <IN>\n          A file in whose context to evaluate the code. Can be used to introspect the document.\n\n      --target <TARGET>\n          The target to compile for\n          \n          [default: paged]\n\n      --format <FORMAT>\n          The format to serialize in\n          \n          [default: json]\n          [possible values: json, yaml]\n\n      --pretty\n          Whether to pretty-print the serialized output.\n\n      --root <DIR>\n          Configures the project root (for absolute paths)\n\n      --input <key=value>\n          Add a string key-value pair visible through `sys.inputs`\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
    static final String FONTS_HELP = "Lists all discovered fonts in system and custom font paths\n\nUsage: executable fonts [OPTIONS]\n\nOptions:\n      --font-path <DIR>\n          Adds additional directories that are recursively searched for fonts.\n\n      --ignore-system-fonts\n          Ensures system fonts won't be searched, unless explicitly included via `--font-path`\n\n      --ignore-embedded-fonts\n          Ensures fonts embedded into Typst won't be considered\n\n      --variants\n          Also lists style variants of each font family\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
    static final String INIT_HELP = "Initializes a new project from a template\n\nUsage: executable init [OPTIONS] <TEMPLATE> [DIR]\n\nArguments:\n  <TEMPLATE>\n          The template to use, e.g. `@preview/charged-ieee`.\n\n  [DIR]\n          The project directory, defaults to the template's name\n\nOptions:\n      --package-path <DIR>\n          Custom path to local packages, defaults to system-dependent location\n\n      --package-cache-path <DIR>\n          Custom path to package cache, defaults to system-dependent location\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
    static final String COMPLETIONS_HELP = "Generates shell completion scripts\n\nUsage: executable completions <SHELL>\n\nArguments:\n  <SHELL>  The shell to generate completions for [possible values: bash, elvish,\n           fish, powershell, zsh]\n\nOptions:\n  -h, --help  Print help\n";
}
