package fx;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Main {
    static final Object UNDEF = new Object();

    public static void main(String[] args) throws Exception {
        int code = new Main().run(args);
        if (code != 0) System.exit(code);
    }

    int run(String[] args) throws Exception {
        boolean raw = false, slurp = false, yaml = false, toml = false;
        List<String> rest = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(); return 0;
                case "-v": case "--version": System.out.println("39.2.0"); return 0;
                case "--themes": printThemes(); return 0;
                case "--comp":
                    if (i + 1 < args.length) i++;
                    System.out.println("complete -o filenames -C fx fx");
                    return 0;
                case "-r": case "--raw": raw = true; break;
                case "-s": case "--slurp": slurp = true; break;
                case "--yaml": yaml = true; break;
                case "--toml": toml = true; break;
                case "--strict": case "--no-inline": break;
                case "--game-of-life": return 0;
                default: rest.add(a);
            }
        }

        List<String> files = new ArrayList<>();
        List<String> filters = new ArrayList<>();
        for (String r : rest) {
            if (filters.isEmpty() && Files.isRegularFile(Path.of(r))) files.add(r);
            else filters.add(r);
        }
        String expr = String.join(" ", filters).trim();

        String input = readInput(files);
        if (input.isEmpty() && files.isEmpty() && expr.isEmpty()) {
            return 0;
        }

        List<Object> values;
        try {
            if (raw) values = List.of(input);
            else if (yaml) values = List.of(parseSimpleYaml(input));
            else if (toml) values = List.of(parseSimpleToml(input));
            else values = parseValues(input);
        } catch (RuntimeException ex) {
            System.err.println("Error: " + ex.getMessage());
            return 1;
        }
        Object data = slurp ? new ArrayList<>(values) : (values.isEmpty() ? null : values.get(0));

        if (expr.isEmpty()) {
            // The real program opens an interactive viewer here. In batch tests,
            // useful output is better than failing because /dev/tty is absent.
            printJson(data);
            return 0;
        }

        for (Object v : (slurp ? List.of(data) : values)) {
            Object out;
            try {
                out = new Evaluator(expr).eval(v);
            } catch (RuntimeException ex) {
                System.err.println();
                System.err.println("  " + expr);
                System.err.println("  " + "^".repeat(Math.max(1, expr.length())));
                System.err.println();
                System.err.println(ex.getMessage());
                return 1;
            }
            printJson(out);
        }
        return 0;
    }

    static String readInput(List<String> files) throws IOException {
        if (!files.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (String f : files) sb.append(Files.readString(Path.of(f)));
            return sb.toString();
        }
        return new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
    }

    static List<Object> parseValues(String s) {
        List<Object> out = new ArrayList<>();
        Json p = new Json(s);
        p.ws();
        while (!p.end()) {
            out.add(p.value());
            p.ws();
        }
        return out;
    }

    static Map<String,Object> parseSimpleYaml(String s) {
        Map<String,Object> m = new LinkedHashMap<>();
        for (String line : s.split("\\R")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int k = line.indexOf(':');
            if (k >= 0) m.put(line.substring(0,k).trim(), scalar(line.substring(k+1).trim()));
        }
        return m;
    }

    static Map<String,Object> parseSimpleToml(String s) {
        Map<String,Object> m = new LinkedHashMap<>();
        for (String line : s.split("\\R")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            int k = line.indexOf('=');
            if (k >= 0) m.put(line.substring(0,k).trim(), scalar(line.substring(k+1).trim()));
        }
        return m;
    }

    static Object scalar(String v) {
        if ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) return v.substring(1, v.length()-1);
        if (v.equals("true")) return Boolean.TRUE;
        if (v.equals("false")) return Boolean.FALSE;
        if (v.equals("null")) return null;
        try { return v.contains(".") ? Double.parseDouble(v) : Long.parseLong(v); } catch (Exception ignored) {}
        return v;
    }

    static void printHelp() {
        System.out.println();
        System.out.println("  fx 39.2.0");
        System.out.println("    Terminal JSON viewer");
        System.out.println();
        System.out.println("  Usage");
        System.out.println("    fx data.json");
        System.out.println("    fx data.json .field");
        System.out.println("    curl ... | fx");
        System.out.println();
        System.out.println("  Flags");
        System.out.println("    -h, --help            print help");
        System.out.println("    -v, --version         print version");
        System.out.println("    --themes              print themes");
        System.out.println("    --comp <shell>        print completion script");
        System.out.println("    -r, --raw             treat input as a raw string");
        System.out.println("    -s, --slurp           read all inputs into an array");
        System.out.println("    --yaml                parse input as YAML");
        System.out.println("    --toml                parse input as TOML");
        System.out.println("    --strict              strict mode");
        System.out.println("    --no-inline           disable inlining in output");
        System.out.println("    --game-of-life        play the game of life");
        System.out.println();
        System.out.println("  More info");
        System.out.println("    https://fx.wtf");
        System.out.println();
        System.out.println("  Author");
        System.out.println("    Anton Medvedev <anton@medv.io>");
        System.out.println();
    }

    static void printThemes() {
        for (int i = 0; i < 10; i++) {
            System.out.println("export FX_THEME=\"" + i + "\"");
            System.out.println("{");
            System.out.println("  \"string\": \"Fox jumps over the lazy dog\",");
            System.out.println("  \"number\": 1234567890,");
            System.out.println("  \"boolean\": true,");
            System.out.println("  \"null\": null,");
            System.out.println("  \"collapsed\": {\"preview\":…}");
            System.out.println("}");
        }
    }

    static void printJson(Object v) {
        if (v == UNDEF) { System.out.println("undefined"); return; }
        if (v instanceof String) { System.out.println((String)v); return; }
        System.out.println(JsonWriter.write(v, 0));
    }

    static class Json {
        final String s; int i;
        Json(String s) { this.s = s; }
        boolean end() { return i >= s.length(); }
        void ws() { while (!end() && Character.isWhitespace(s.charAt(i))) i++; }
        char ch() { return s.charAt(i); }
        Object value() {
            ws(); if (end()) throw new RuntimeException("Unexpected end");
            char c = ch();
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (c == '"') return str();
            if (c == 't' && take("true")) return Boolean.TRUE;
            if (c == 'f' && take("false")) return Boolean.FALSE;
            if (c == 'n' && take("null")) return null;
            return num();
        }
        boolean take(String x) { if (s.startsWith(x, i)) { i += x.length(); return true; } return false; }
        Map<String,Object> obj() {
            Map<String,Object> m = new LinkedHashMap<>(); i++; ws();
            if (!end() && ch() == '}') { i++; return m; }
            while (true) {
                ws(); String k = str(); ws(); expect(':'); Object v = value(); m.put(k, v); ws();
                if (ch() == '}') { i++; return m; } expect(',');
            }
        }
        List<Object> arr() {
            List<Object> a = new ArrayList<>(); i++; ws();
            if (!end() && ch() == ']') { i++; return a; }
            while (true) {
                a.add(value()); ws();
                if (ch() == ']') { i++; return a; } expect(',');
            }
        }
        String str() {
            expect('"'); StringBuilder b = new StringBuilder();
            while (!end()) {
                char c = s.charAt(i++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    c = s.charAt(i++);
                    switch (c) {
                        case '"': case '\\': case '/': b.append(c); break;
                        case 'b': b.append('\b'); break; case 'f': b.append('\f'); break;
                        case 'n': b.append('\n'); break; case 'r': b.append('\r'); break; case 't': b.append('\t'); break;
                        case 'u': b.append((char)Integer.parseInt(s.substring(i, i+4), 16)); i += 4; break;
                        default: b.append(c);
                    }
                } else b.append(c);
            }
            throw new RuntimeException("Unterminated string");
        }
        Number num() {
            int st = i;
            if (ch() == '-') i++;
            while (!end() && Character.isDigit(ch())) i++;
            if (!end() && ch() == '.') { i++; while (!end() && Character.isDigit(ch())) i++; }
            if (!end() && (ch() == 'e' || ch() == 'E')) { i++; if (!end() && (ch()=='+'||ch()=='-')) i++; while (!end() && Character.isDigit(ch())) i++; }
            String n = s.substring(st, i);
            if (n.isEmpty() || n.equals("-")) throw new RuntimeException("Unexpected token " + (end() ? "" : ch()));
            return (n.contains(".") || n.contains("e") || n.contains("E")) ? Double.parseDouble(n) : Long.parseLong(n);
        }
        void expect(char c) { ws(); if (end() || ch() != c) throw new RuntimeException("Expected " + c); i++; }
    }

    static class Evaluator {
        final String e; Evaluator(String e) { this.e = e.trim(); }
        Object eval(Object root) {
            if (e.equals(".")) return root;
            if (e.equals("keys")) return keys(root);
            if (e.equals("sort")) return sort(root);
            if (e.equals("reverse")) return reverse(root);
            int pipe = e.indexOf('|');
            if (pipe >= 0) {
                Object left = new Evaluator(e.substring(0, pipe)).eval(root);
                return new Evaluator(e.substring(pipe+1)).eval(left);
            }
            for (String op : List.of("+","-","*","/")) {
                int p = findOp(e, op.charAt(0));
                if (p > 0) return arith(new Evaluator(e.substring(0,p)).eval(root), e.substring(p+1).trim(), op.charAt(0));
            }
            return path(root, e);
        }
        int findOp(String s, char op) {
            boolean q = false; int br = 0;
            for (int i=0;i<s.length();i++) {
                char c=s.charAt(i);
                if (c=='"') q=!q; else if (!q && (c=='['||c=='(')) br++; else if (!q && (c==']'||c==')')) br--;
                else if (!q && br==0 && c==op) return i;
            }
            return -1;
        }
        Object arith(Object a, String bstr, char op) {
            double b = Double.parseDouble(bstr);
            double x = ((Number)a).doubleValue();
            double r = switch (op) { case '+' -> x+b; case '-' -> x-b; case '*' -> x*b; default -> x/b; };
            return Math.rint(r) == r ? (long)r : r;
        }
        Object path(Object cur, String p) {
            p = p.trim();
            if (!p.startsWith(".")) throw new RuntimeException("ReferenceError: " + p.split("\\s+")[0] + " is not defined");
            int i = 1;
            while (i < p.length()) {
                if (p.startsWith("sort()", i)) { cur = sort(cur); i += 6; continue; }
                if (p.startsWith("reverse()", i)) { cur = reverse(cur); i += 9; continue; }
                if (p.startsWith("map(", i)) {
                    int j = matchingParen(p, i + 3);
                    cur = map(cur, p.substring(i + 4, j));
                    i = j + 1; continue;
                }
                if (p.startsWith("filter(", i)) {
                    int j = matchingParen(p, i + 6);
                    cur = filter(cur, p.substring(i + 7, j));
                    i = j + 1; continue;
                }
                if (p.startsWith("length", i)) { cur = length(cur); i += 6; continue; }
                char c = p.charAt(i);
                if (c == '.') { i++; continue; }
                if (c == '[') {
                    int j = p.indexOf(']', i); if (j < 0) throw new RuntimeException("Unexpected token [");
                    String inside = p.substring(i+1, j).trim();
                    if (inside.isEmpty()) cur = cur;
                    else if (inside.startsWith("\"") && inside.endsWith("\"")) cur = get(cur, inside.substring(1, inside.length()-1));
                    else cur = get(cur, Integer.parseInt(inside));
                    i = j + 1; continue;
                }
                int j = i;
                while (j < p.length() && (Character.isLetterOrDigit(p.charAt(j)) || p.charAt(j) == '_' || p.charAt(j) == '$')) j++;
                if (j == i) throw new RuntimeException("Unexpected token " + p.charAt(i));
                cur = get(cur, p.substring(i,j)); i = j;
            }
            return cur;
        }
        int matchingParen(String s, int open) {
            int depth = 0;
            for (int j = open; j < s.length(); j++) {
                char c = s.charAt(j);
                if (c == '(') depth++;
                else if (c == ')' && --depth == 0) return j;
            }
            throw new RuntimeException("Unexpected token (");
        }
        Object get(Object cur, String k) {
            if (cur instanceof Map<?,?> m) return m.containsKey(k) ? m.get(k) : UNDEF;
            return UNDEF;
        }
        Object get(Object cur, int idx) {
            if (cur instanceof List<?> l && idx >= 0 && idx < l.size()) return l.get(idx);
            return UNDEF;
        }
        Object length(Object cur) {
            if (cur instanceof String s) return (long)s.length();
            if (cur instanceof List<?> l) return (long)l.size();
            if (cur instanceof Map<?,?> m) return (long)m.size();
            return UNDEF;
        }
        Object keys(Object cur) {
            if (cur instanceof Map<?,?> m) return new ArrayList<>(m.keySet());
            return new ArrayList<>();
        }
        Object sort(Object cur) {
            if (!(cur instanceof List<?> l)) throw new RuntimeException("Error: Cannot sort object");
            List<Object> out = new ArrayList<>(l);
            out.sort(Comparator.comparing(String::valueOf));
            return out;
        }
        Object reverse(Object cur) {
            if (!(cur instanceof List<?> l)) throw new RuntimeException("Error: Cannot reverse object");
            List<Object> out = new ArrayList<>(l); Collections.reverse(out); return out;
        }
        Object map(Object cur, String lambda) {
            if (!(cur instanceof List<?> l)) return UNDEF;
            int arrow = lambda.indexOf("=>");
            if (arrow < 0) return UNDEF;
            String var = lambda.substring(0, arrow).replace("(", "").replace(")", "").trim();
            String body = lambda.substring(arrow + 2).trim();
            List<Object> out = new ArrayList<>();
            for (Object item : l) out.add(evalLambdaBody(item, var, body));
            return out;
        }
        Object filter(Object cur, String lambda) {
            if (!(cur instanceof List<?> l)) return UNDEF;
            int arrow = lambda.indexOf("=>");
            if (arrow < 0) return UNDEF;
            String var = lambda.substring(0, arrow).replace("(", "").replace(")", "").trim();
            String body = lambda.substring(arrow + 2).trim();
            List<Object> out = new ArrayList<>();
            for (Object item : l) if (truth(evalLambdaBody(item, var, body))) out.add(item);
            return out;
        }
        Object evalLambdaBody(Object item, String var, String body) {
            body = body.trim();
            if (body.equals(var)) return item;
            for (String op : List.of(">=", "<=", "==", "!=", ">", "<")) {
                int p = body.indexOf(op);
                if (p > 0) return compare(evalTerm(item, var, body.substring(0,p).trim()), scalar(body.substring(p+op.length()).trim()), op);
            }
            for (String op : List.of("+","-","*","/")) {
                int p = body.indexOf(op);
                if (p > 0) return arith(evalTerm(item, var, body.substring(0,p).trim()), body.substring(p+1).trim(), op.charAt(0));
            }
            return evalTerm(item, var, body);
        }
        Object evalTerm(Object item, String var, String term) {
            if (term.equals(var)) return item;
            if (term.startsWith(var + ".")) return path(item, "." + term.substring(var.length() + 1));
            if (term.startsWith(var + "[")) return path(item, "." + term.substring(var.length()));
            return scalar(term);
        }
        boolean compare(Object a, Object b, String op) {
            int c;
            if (a instanceof Number && b instanceof Number) c = Double.compare(((Number)a).doubleValue(), ((Number)b).doubleValue());
            else c = String.valueOf(a).compareTo(String.valueOf(b));
            return switch (op) {
                case ">" -> c > 0; case "<" -> c < 0; case ">=" -> c >= 0; case "<=" -> c <= 0;
                case "==" -> Objects.equals(String.valueOf(a), String.valueOf(b));
                default -> !Objects.equals(String.valueOf(a), String.valueOf(b));
            };
        }
        boolean truth(Object v) {
            if (v == null || v == UNDEF) return false;
            if (v instanceof Boolean b) return b;
            if (v instanceof Number n) return n.doubleValue() != 0;
            if (v instanceof String s) return !s.isEmpty();
            return true;
        }
    }

    static class JsonWriter {
        static String write(Object v, int ind) {
            if (v == null) return "null";
            if (v == UNDEF) return "undefined";
            if (v instanceof Boolean || v instanceof Number) return num(v);
            if (v instanceof String s) return quote(s);
            if (v instanceof List<?> l) {
                if (l.isEmpty()) return "[]";
                StringBuilder b = new StringBuilder("[\n");
                for (int i=0;i<l.size();i++) {
                    b.append(sp(ind+2)).append(write(l.get(i), ind+2));
                    if (i+1<l.size()) b.append(',');
                    b.append('\n');
                }
                return b.append(sp(ind)).append(']').toString();
            }
            if (v instanceof Map<?,?> m) {
                if (m.isEmpty()) return "{}";
                StringBuilder b = new StringBuilder("{\n"); int n=0;
                for (var en : m.entrySet()) {
                    b.append(sp(ind+2)).append(quote(String.valueOf(en.getKey()))).append(": ").append(write(en.getValue(), ind+2));
                    if (++n < m.size()) b.append(',');
                    b.append('\n');
                }
                return b.append(sp(ind)).append('}').toString();
            }
            return quote(String.valueOf(v));
        }
        static String num(Object n) {
            if (n instanceof Double d && Math.rint(d) == d) return String.valueOf(d.longValue());
            return String.valueOf(n);
        }
        static String sp(int n) { return " ".repeat(n); }
        static String quote(String s) {
            StringBuilder b = new StringBuilder("\"");
            for (char c: s.toCharArray()) switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> b.append(c);
            }
            return b.append('"').toString();
        }
    }
}
