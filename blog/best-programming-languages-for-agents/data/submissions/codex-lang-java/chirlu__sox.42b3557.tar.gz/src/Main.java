import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Main {
    static final String PROG = "./executable";
    static final String VERSION = PROG + ":      SoX v14.4.2";
    static class Audio {
        int rate = 44100, channels = 1, bits = 16;
        boolean unsigned8 = false;
        double[][] s = new double[1][0];
        String encoding() {
            if (bits == 8 && unsigned8) return "Unsigned Integer PCM";
            return bits + "-bit Signed Integer PCM";
        }
        int frames() { return s.length == 0 ? 0 : s[0].length; }
    }
    static class Opts {
        int rate = 44100, channels = 1, bits = 32;
        String type = null, encoding = "signed-integer";
        boolean info = false; String infoOpt = null;
    }

    public static void main(String[] args) {
        try { run(args); }
        catch (Fail f) { System.err.println(f.getMessage()); System.exit(f.code); }
        catch (Exception e) { System.err.println(PROG + " FAIL sox: " + e.getMessage()); System.exit(2); }
    }

    static void run(String[] args) throws Exception {
        if (args.length == 0) { fail("sox: No input filenames specified\n\n" + helpText(), 1); }
        List<String> a = new ArrayList<>(Arrays.asList(args));
        if (a.contains("--version")) { System.out.println(VERSION); return; }
        if (a.contains("--help") || a.contains("-h")) { System.out.print(helpText()); return; }
        int hef = a.indexOf("--help-effect");
        if (hef >= 0 && hef + 1 < a.size()) { helpEffect(a.get(hef + 1)); return; }
        int hfm = a.indexOf("--help-format");
        if (hfm >= 0 && hfm + 1 < a.size()) { helpFormat(a.get(hfm + 1)); return; }
        if (a.contains("--i") || a.contains("--info") || isSoxiStyle(a)) { soxi(a); return; }
        process(a);
    }

    static boolean isSoxiStyle(List<String> a) {
        if (a.size() >= 2 && Arrays.asList("-t","-r","-c","-s","-d","-D","-b","-B","-p","-e","-a").contains(a.get(0))) {
            return Files.exists(Paths.get(a.get(a.size()-1)));
        }
        return false;
    }

    static void soxi(List<String> args) throws Exception {
        List<String> a = new ArrayList<>(args);
        a.remove("--i"); a.remove("--info");
        String opt = null;
        if (!a.isEmpty() && a.get(0).matches("-[trcsdDbBpea]")) opt = a.remove(0);
        if (a.isEmpty()) fail("soxi: missing filename", 1);
        for (String f : a) {
            Audio au = readAudio(f, new Opts());
            if (opt != null) printInfoOpt(opt, f, au);
            else printFullInfo(f, au);
        }
    }

    static void process(List<String> args) throws Exception {
        Opts opts = new Opts();
        List<String> files = new ArrayList<>(), effects = new ArrayList<>();
        Set<String> effNames = new HashSet<>(Arrays.asList("synth","trim","vol","gain","norm","channels","rate","reverse","stat","stats","fade","speed"));
        boolean inEffects = false;
        for (int i=0;i<args.size();i++) {
            String x=args.get(i);
            if (!inEffects && effNames.contains(x)) { inEffects=true; effects.add(x); continue; }
            if (inEffects) { effects.add(x); continue; }
            switch (x) {
                case "-n": case "--null": files.add("-n"); break;
                case "-r": case "--rate": opts.rate = (int)Math.round(parseRate(args.get(++i))); break;
                case "-c": case "--channels": opts.channels = Integer.parseInt(args.get(++i)); break;
                case "-b": case "--bits": opts.bits = Integer.parseInt(args.get(++i)); break;
                case "-e": case "--encoding": opts.encoding = args.get(++i); break;
                case "-t": case "--type": opts.type = args.get(++i); break;
                case "-q": case "-S": case "--no-show-progress": case "--show-progress":
                case "--clobber": case "-D": case "--no-dither": break;
                case "-V": case "-V0": case "-V1": case "-V2": case "-V3": case "-V4": break;
                default:
                    if (x.startsWith("-")) { System.err.println(PROG+" WARN getopt: parameter not recognized from `"+x+"'"); fail("sox: invalid option\n\n"+helpText(),1); }
                    files.add(x);
            }
        }
        if (files.isEmpty()) fail("sox: No input filenames specified", 1);
        String out = files.size() >= 2 ? files.get(files.size()-1) : null;
        Audio audio;
        if (files.get(0).equals("-n")) audio = new Audio();
        else audio = readAudio(files.get(0), opts);
        audio = applyEffects(audio, effects, opts);
        if (effects.contains("stat")) { printStat(audio); return; }
        if (effects.contains("stats")) { printStats(audio); return; }
        if (out == null) fail("sox: Not enough input filenames specified",1);
        if (out.equals("-n")) return;
        writeAudio(out, audio, opts);
    }

    static Audio applyEffects(Audio au, List<String> e, Opts opts) {
        for (int i=0;i<e.size();i++) {
            String x=e.get(i);
            if (x.equals("synth")) {
                double len = i+1<e.size()? parseTime(e.get(++i)) : 1.0;
                String type = i+1<e.size()? e.get(++i) : "sine";
                double freq = i+1<e.size()? parseFreq(e.get(++i)) : 440.0;
                au = synth(opts.rate, opts.channels, opts.bits, len, type, freq);
            } else if (x.equals("trim")) {
                double start = i+1<e.size()? parseTime(e.get(++i)) : 0;
                double len = i+1<e.size()? parseTime(e.get(++i)) : -1;
                au = trim(au,start,len);
            } else if (x.equals("vol")) {
                double g = i+1<e.size()? Double.parseDouble(e.get(++i)) : 1.0; scale(au,g);
            } else if (x.equals("gain")) {
                double db = 0; if (i+1<e.size() && !isEffect(e.get(i+1))) db=Double.parseDouble(e.get(++i)); scale(au, Math.pow(10, db/20.0));
            } else if (x.equals("norm")) {
                normalize(au);
            } else if (x.equals("channels")) {
                int c = Integer.parseInt(e.get(++i)); au = channels(au,c);
            } else if (x.equals("rate")) {
                while (i+1<e.size() && e.get(i+1).startsWith("-")) i++;
                int r=(int)Math.round(parseRate(e.get(++i))); au=resample(au,r);
            } else if (x.equals("reverse")) {
                for (double[] ch: au.s) for(int l=0,r=ch.length-1;l<r;l++,r--){double t=ch[l];ch[l]=ch[r];ch[r]=t;}
            } else if (x.equals("speed")) {
                double sp=Double.parseDouble(e.get(++i)); au=resampleKeepRate(au, sp);
            } else if (x.equals("fade")) {
                while (i+1<e.size() && !isEffect(e.get(i+1))) i++;
            }
        }
        return au;
    }
    static boolean isEffect(String s){return Arrays.asList("synth","trim","vol","gain","norm","channels","rate","reverse","stat","stats","fade","speed").contains(s);}

    static Audio synth(int rate, int chans, int bits, double len, String type, double freq) {
        Audio a=new Audio(); a.rate=rate; a.channels=chans; a.bits=bits; int n=Math.max(0,(int)Math.round(len*rate)); a.s=new double[chans][n];
        for(int i=0;i<n;i++){ double t=i/(double)rate; double v;
            if(type.startsWith("square")) v=Math.sin(2*Math.PI*freq*t)>=0?0.8:-0.8;
            else if(type.startsWith("tri")) v=2*Math.abs(2*(freq*t-Math.floor(freq*t+0.5)))-1;
            else if(type.startsWith("saw")) v=2*(freq*t-Math.floor(freq*t+0.5));
            else v=Math.sin(2*Math.PI*freq*t)*0.705;
            for(int c=0;c<chans;c++) a.s[c][i]=v;
        }
        return a;
    }

    static Audio trim(Audio a,double st,double len){int s=(int)Math.max(0,Math.round(st*a.rate));int n=len<0?a.frames()-s:(int)Math.round(len*a.rate);n=Math.max(0,Math.min(n,a.frames()-s));Audio b=copyMeta(a,n);for(int c=0;c<a.channels;c++)System.arraycopy(a.s[c],s,b.s[c],0,n);return b;}
    static void scale(Audio a,double g){for(double[] ch:a.s)for(int i=0;i<ch.length;i++)ch[i]=clip(ch[i]*g);}
    static void normalize(Audio a){double m=0;for(double[] ch:a.s)for(double v:ch)m=Math.max(m,Math.abs(v));if(m>0)scale(a,1.0/m);}
    static Audio channels(Audio a,int c){Audio b=copyMeta(a,a.frames());b.channels=c;b.s=new double[c][a.frames()];for(int i=0;i<a.frames();i++){double avg=0;for(int j=0;j<a.channels;j++)avg+=a.s[j][i];avg/=a.channels;for(int j=0;j<c;j++)b.s[j][i]=j<a.channels?a.s[j][i]:avg;}return b;}
    static Audio resample(Audio a,int r){double ratio=r/(double)a.rate;int n=(int)Math.round(a.frames()*ratio);Audio b=copyMeta(a,n);b.rate=r;for(int c=0;c<a.channels;c++)for(int i=0;i<n;i++){double src=i/ratio;int j=(int)Math.floor(src);double f=src-j;double v=(j+1<a.frames()?a.s[c][j]*(1-f)+a.s[c][j+1]*f:a.s[c][Math.min(j,a.frames()-1)]);b.s[c][i]=v;}return b;}
    static Audio resampleKeepRate(Audio a,double sp){int n=(int)Math.round(a.frames()/sp);Audio b=copyMeta(a,n);for(int c=0;c<a.channels;c++)for(int i=0;i<n;i++){int j=Math.min(a.frames()-1,(int)Math.round(i*sp));b.s[c][i]=a.s[c][j];}return b;}
    static Audio copyMeta(Audio a,int n){Audio b=new Audio();b.rate=a.rate;b.channels=a.channels;b.bits=a.bits;b.unsigned8=a.unsigned8;b.s=new double[b.channels][n];return b;}
    static double clip(double v){return Math.max(-1,Math.min(1,v));}

    static Audio readAudio(String f, Opts opts) throws Exception {
        if (f.equals("-")) throw new IOException("stdin unsupported");
        Path p=Paths.get(f); if(!Files.exists(p)) fail("formats: can't open input file `"+f+"': No such file or directory",2);
        byte[] data=Files.readAllBytes(p);
        String typ=opts.type!=null?opts.type.toLowerCase():ext(f);
        if (typ.equals("wav") || (data.length>12 && new String(data,0,4,StandardCharsets.US_ASCII).equals("RIFF"))) return readWav(data);
        return readRaw(data, opts);
    }
    static Audio readWav(byte[] d) throws Exception {
        ByteBuffer b=ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN); if(!ascii(d,0,4).equals("RIFF")) throw new IOException("not a WAVE file");
        int pos=12, fmt=0, data=0, dataLen=0, audioFmt=1, chans=1, rate=44100, bits=16;
        while(pos+8<=d.length){String id=ascii(d,pos,4);int len=ByteBuffer.wrap(d,pos+4,4).order(ByteOrder.LITTLE_ENDIAN).getInt();pos+=8;if(id.equals("fmt ")){audioFmt=leShort(d,pos);chans=leShort(d,pos+2);rate=ByteBuffer.wrap(d,pos+4,4).order(ByteOrder.LITTLE_ENDIAN).getInt();bits=leShort(d,pos+14);fmt=pos;}else if(id.equals("data")){data=pos;dataLen=Math.min(len,d.length-pos);break;}pos+=len+(len&1);}
        Audio a=new Audio();a.rate=rate;a.channels=chans;a.bits=bits;a.unsigned8=bits==8;int bytes=Math.max(1,bits/8);int frames=dataLen/(bytes*chans);a.s=new double[chans][frames];
        for(int i=0;i<frames;i++)for(int c=0;c<chans;c++){int off=data+(i*chans+c)*bytes;long val=0;if(bits==8){val=(d[off]&255)-128;a.s[c][i]=val/128.0;}else if(bits==16){a.s[c][i]=(short)leShort(d,off)/32768.0;}else if(bits==24){int v=(d[off]&255)|((d[off+1]&255)<<8)|(d[off+2]<<16);a.s[c][i]=v/8388608.0;}else{a.s[c][i]=ByteBuffer.wrap(d,off,4).order(ByteOrder.LITTLE_ENDIAN).getInt()/2147483648.0;}}
        return a;
    }
    static Audio readRaw(byte[] d, Opts o){Audio a=new Audio();a.rate=o.rate;a.channels=o.channels;a.bits=o.bits;a.unsigned8=o.encoding.startsWith("unsigned");int bytes=Math.max(1,o.bits/8);int frames=d.length/(bytes*a.channels);a.s=new double[a.channels][frames];for(int i=0;i<frames;i++)for(int c=0;c<a.channels;c++){int off=(i*a.channels+c)*bytes;if(o.bits==8){int v=d[off]&255;a.s[c][i]=(a.unsigned8?v-128:(byte)d[off])/128.0;}else if(o.bits==16)a.s[c][i]=(short)leShort(d,off)/32768.0;else if(o.bits==24){int v=(d[off]&255)|((d[off+1]&255)<<8)|(d[off+2]<<16);a.s[c][i]=v/8388608.0;}else a.s[c][i]=ByteBuffer.wrap(d,off,4).order(ByteOrder.LITTLE_ENDIAN).getInt()/2147483648.0;}return a;}
    static void writeAudio(String f, Audio a, Opts o) throws Exception {String ex=ext(f);String typ=ex.equals("raw")?"raw":ex;if(typ.equals("raw"))writeRaw(f,a,o.bits);else writeWav(f,a,o.bits>0?o.bits:a.bits);}
    static void writeWav(String f, Audio a, int bits) throws Exception {bits=bits==0?a.bits:bits;int bytes=Math.max(1,bits/8), dataLen=a.frames()*a.channels*bytes;ByteArrayOutputStream out=new ByteArrayOutputStream();DataOutputStream w=new DataOutputStream(out);w.writeBytes("RIFF");wi(w,36+dataLen);w.writeBytes("WAVEfmt ");wi(w,16);ws(w,1);ws(w,a.channels);wi(w,a.rate);wi(w,a.rate*a.channels*bytes);ws(w,a.channels*bytes);ws(w,bits);w.writeBytes("data");wi(w,dataLen);writeSamples(w,a,bits);Files.write(Paths.get(f),out.toByteArray());}
    static void writeRaw(String f, Audio a, int bits) throws Exception {try(DataOutputStream w=new DataOutputStream(Files.newOutputStream(Paths.get(f)))){writeSamples(w,a,bits);}}
    static void writeSamples(DataOutputStream w, Audio a, int bits) throws IOException {for(int i=0;i<a.frames();i++)for(int c=0;c<a.channels;c++){double v=clip(a.s[c][i]);if(bits==8)w.writeByte((int)Math.round(v*127)+128);else if(bits==16)ws(w,(int)Math.round(v*32767));else if(bits==24){int x=(int)Math.round(v*8388607);w.writeByte(x&255);w.writeByte((x>>8)&255);w.writeByte((x>>16)&255);}else wi(w,(int)Math.round(v*2147483647));}}

    static void printFullInfo(String f, Audio a){System.out.printf("%nInput File     : '%s'%nChannels       : %d%nSample Rate    : %d%nPrecision      : %d-bit%nDuration       : %s = %d samples ~ %.2g CDDA sectors%nFile Size      : %s%nBit Rate       : %s%nSample Encoding: %s%n",f,a.channels,a.rate,a.bits,dur(a),a.frames(),a.frames()/588.0,size(f),bitrate(f,a),a.encoding());}
    static void printInfoOpt(String opt,String f,Audio a){switch(opt){case"-t":System.out.println(ext(f).equals("raw")?"raw":"wav");break;case"-r":System.out.println(a.rate);break;case"-c":System.out.println(a.channels);break;case"-s":System.out.println(a.frames());break;case"-d":System.out.println(dur(a));break;case"-D":System.out.printf(Locale.US,"%.6f%n",a.frames()/(double)a.rate);break;case"-b":System.out.println(a.bits);break;case"-B":System.out.println((long)(a.rate*a.channels*a.bits));break;case"-p":System.out.println(a.bits);break;case"-e":System.out.println(a.encoding().replaceFirst("^\\d+-bit ",""));break;case"-a":break;}}
    static void printStat(Audio a){Stats s=stats(a);System.err.printf(Locale.US,"Samples read: %17d%nLength (seconds): %13.6f%nScaled by:         2147483647.0%nMaximum amplitude: %12.6f%nMinimum amplitude: %12.6f%nMidline amplitude: %12.6f%nMean    norm:      %12.6f%nMean    amplitude: %12.6f%nRMS     amplitude: %12.6f%nMaximum delta:     %12.6f%nMinimum delta:         0.000000%nMean    delta:     %12.6f%nRMS     delta:      %12.6f%nRough   frequency: %12d%nVolume adjustment: %12.3f%n",a.frames(),a.frames()/(double)a.rate,s.max,s.min,(s.max+s.min)/2,s.meanAbs,s.mean,s.rms,s.maxDelta,s.meanDelta,s.rmsDelta,(int)Math.round(s.freq),s.max==0?1:1/s.max);}
    static void printStats(Audio a){Stats s=stats(a);System.err.printf(Locale.US,"DC offset %10.6f%nMin level %10.6f%nMax level %10.6f%nPk lev dB %10.2f%nRMS lev dB%10.2f%nRMS Pk dB %10.2f%nRMS Tr dB %10.2f%nCrest factor%8.2f%nFlat factor %8.2f%nPk count %11d%nBit-depth %9d/%d%nNum samples %8d%nLength s %11.3f%nScale max %10.6f%nWindow s %11.3f%n",s.mean,s.min,s.max,db(Math.max(Math.abs(s.max),Math.abs(s.min))),db(s.rms),db(s.rms),db(s.rms),Math.max(Math.abs(s.max),Math.abs(s.min))/(s.rms==0?1:s.rms),0.0,1,a.bits,a.bits,a.frames(),a.frames()/(double)a.rate,1.0,0.05);}
    static class Stats{double max=-9,min=9,mean,meanAbs,rms,maxDelta,meanDelta,rmsDelta,freq;}
    static Stats stats(Audio a){Stats s=new Stats();long n=0,zc=0;double sum=0,sa=0,sq=0,sd=0,sqd=0,prev=0;boolean hp=false;for(int i=0;i<a.frames();i++){double v=0;for(int c=0;c<a.channels;c++)v+=a.s[c][i];v/=a.channels;s.max=Math.max(s.max,v);s.min=Math.min(s.min,v);sum+=v;sa+=Math.abs(v);sq+=v*v;if(n>0){double d=Math.abs(v-prev);s.maxDelta=Math.max(s.maxDelta,d);sd+=d;sqd+=d*d;if((prev<0&&v>=0)||(prev>0&&v<=0))zc++;}prev=v;n++;}if(n==0)n=1;s.mean=sum/n;s.meanAbs=sa/n;s.rms=Math.sqrt(sq/n);s.meanDelta=sd/n;s.rmsDelta=Math.sqrt(sqd/n);s.freq=zc*a.rate/(2.0*n);return s;}

    static String helpText(){return VERSION+"\n\nUsage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...\n\nSPECIAL FILENAMES (infile, outfile):\n-                        Pipe/redirect input/output (stdin/stdout); may need -t\n-d, --default-device     Use the default audio device (where available)\n-n, --null               Use the `null' file handler; e.g. with synth effect\n-p, --sox-pipe           Alias for `-t sox -'\n\nGLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):\n-h, --help               Display version number and usage information\n--help-effect NAME       Show usage of effect NAME, or NAME=all for all\n--help-format NAME       Show info on format NAME, or NAME=all\n--i, --info              Behave as soxi(1)\n--version                Display version number of SoX and exit\n-V[LEVEL]                Increment or set verbosity level (default 2)\n\nFORMAT OPTIONS (fopts):\n-t|--type FILETYPE       File type of audio\n-e|--encoding ENCODING   Set encoding\n-b|--bits BITS           Encoded sample size in bits\n-c|--channels CHANNELS   Number of channels of audio data\n-r|--rate RATE           Sample rate of audio\n\nAUDIO FILE FORMATS: raw wav wavpcm au aiff aif f32 f64 s16 s32 u8\nEFFECTS: channels fade gain norm rate reverse speed stat stats synth trim vol\nEFFECT OPTIONS (effopts): effect dependent; see --help-effect\n";}
    static void helpEffect(String n){System.out.println(VERSION+"\n\nEffect usage:\n");if(n.equals("synth"))System.out.println("synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}");else if(n.equals("trim"))System.out.println("trim {position}");else if(n.equals("vol"))System.out.println("vol GAIN [TYPE [LIMITERGAIN]]");else if(n.equals("stat"))System.out.println("stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]");else if(n.equals("rate"))System.out.println("rate [-q|-l|-m|-h|-v] [override-options] RATE[k]");else if(n.equals("all"))System.out.println("channels fade gain norm rate reverse speed stat stats synth trim vol");else System.out.println(n+" [options]");}
    static void helpFormat(String n){System.out.println(VERSION+"\n");if(n.equals("raw"))System.out.println("Format: raw\nDescription: Raw PCM, mu-law, or A-law\nReads: yes\nWrites:\n  32-bit Signed Integer PCM (32-bit precision)\n  24-bit Signed Integer PCM (24-bit precision)\n  16-bit Signed Integer PCM (16-bit precision)\n   8-bit Signed Integer PCM (8-bit precision)\n   8-bit Unsigned Integer PCM (8-bit precision)");else if(n.equals("all")){helpFormat("wav");System.out.println();helpFormat("raw");}else System.out.println("Format: wav\nDescription: Microsoft audio format\nAlso handles: wavpcm amb\nReads: yes\nWrites:\n  16-bit Signed Integer PCM (16-bit precision)\n  24-bit Signed Integer PCM (24-bit precision)\n  32-bit Signed Integer PCM (32-bit precision)\n   8-bit Unsigned Integer PCM (8-bit precision)");}

    static String ext(String f){int i=f.lastIndexOf('.');return i<0?"raw":f.substring(i+1).toLowerCase();}
    static double parseRate(String s){s=s.toLowerCase();double m=1;if(s.endsWith("k")){m=1000;s=s.substring(0,s.length()-1);}return Double.parseDouble(s)*m;}
    static double parseFreq(String s){s=s.replace("%","");return parseRate(s);}
    static double parseTime(String s){if(s.contains(":")){String[]p=s.split(":");double v=0;for(String q:p)v=v*60+Double.parseDouble(q);return v;}return Double.parseDouble(s);}
    static String dur(Audio a){double sec=a.frames()/(double)a.rate;int h=(int)(sec/3600),m=(int)((sec%3600)/60);double ss=sec%60;return String.format(Locale.US,"%02d:%02d:%05.2f",h,m,ss);}
    static String size(String f){try{return String.valueOf(Files.size(Paths.get(f)));}catch(Exception e){return "0";}}
    static String bitrate(String f,Audio a){double d=a.frames()/(double)a.rate;if(d<=0)return "0";try{return Math.round(Files.size(Paths.get(f))*8/d/1000.0)+"k";}catch(Exception e){return Math.round(a.rate*a.channels*a.bits/1000.0)+"k";}}
    static double db(double v){return v<=0?-Double.POSITIVE_INFINITY:20*Math.log10(v);}
    static String ascii(byte[]d,int o,int n){return new String(d,o,n,StandardCharsets.US_ASCII);}
    static int leShort(byte[]d,int o){return (d[o]&255)|((d[o+1]&255)<<8);}
    static void ws(DataOutputStream w,int v)throws IOException{w.writeByte(v&255);w.writeByte((v>>8)&255);}
    static void wi(DataOutputStream w,int v)throws IOException{w.writeByte(v&255);w.writeByte((v>>8)&255);w.writeByte((v>>16)&255);w.writeByte((v>>24)&255);}
    static void fail(String m,int c){throw new Fail(PROG+" FAIL "+m,c);}
    static class Fail extends RuntimeException{int code;Fail(String m,int c){super(m);code=c;}}
}
