package thokr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class Main {
    private static final String VERSION = "thokr 0.4.1";
    private static final String ABOUT = "sleek typing tui with visualized results and historical logging";
    private static final String[] COMMON = (
            "the be to of and a in that have i it for not on with he as you do at this but his by from " +
            "they we say her she or an will my one all would there their what so up out if about who get " +
            "which go me when make can like time no just him know take people into year your good some could " +
            "them see other than then now look only come its over think also back after use two how our work " +
            "first well way even new want because any these give day most us is are was were been has had did " +
            "more may find here thing long down great little own should around man world life still hand old " +
            "never last same another while might place house school again every small found thought went came"
    ).split(" ");
    private static final String[] SENTENCES = {
            "The quick brown fox jumps over the lazy dog.",
            "Typing practice is easier when the words stay simple.",
            "Small tools can make daily habits feel pleasant.",
            "A steady rhythm matters more than sudden speed.",
            "Clear feedback helps every session feel useful.",
            "Practice turns awkward motion into quiet confidence."
    };

    private Main() {}

    public static void main(String[] args) {
        try {
            Config config = parse(args);
            if (config.help) {
                System.out.print(helpText());
                return;
            }
            if (config.version) {
                System.out.println(VERSION);
                return;
            }
            if (!isTty()) {
                usageError("stdin must be a tty", true, "thokr [OPTIONS]");
                System.exit(2);
                return;
            }
            runTui(config);
        } catch (ArgError e) {
            usageError(e.getMessage(), e.showUsage, e.usage);
            System.exit(2);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static Config parse(String[] args) throws ArgError {
        Config c = new Config();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("--help")) {
                c.help = true;
            } else if (a.equals("-V") || a.equals("--version")) {
                c.version = true;
            } else if (a.equals("-w") || a.equals("--number-of-words")) {
                c.words = parseInt(value(args, ++i, a), "number-of-words", "NUMBER_OF_WORDS");
            } else if (a.startsWith("--number-of-words=")) {
                c.words = parseInt(a.substring(a.indexOf('=') + 1), "number-of-words", "NUMBER_OF_WORDS");
            } else if (a.equals("-s") || a.equals("--number-of-secs")) {
                c.seconds = parseInt(value(args, ++i, a), "number-of-secs", "NUMBER_OF_SECS");
            } else if (a.startsWith("--number-of-secs=")) {
                c.seconds = parseInt(a.substring(a.indexOf('=') + 1), "number-of-secs", "NUMBER_OF_SECS");
            } else if (a.equals("-f") || a.equals("--full-sentences")) {
                c.sentences = parseInt(value(args, ++i, a), "full-sentences", "NUMBER_OF_SENTENCES");
            } else if (a.startsWith("--full-sentences=")) {
                c.sentences = parseInt(a.substring(a.indexOf('=') + 1), "full-sentences", "NUMBER_OF_SENTENCES");
            } else if (a.equals("-p") || a.equals("--prompt")) {
                c.prompt = value(args, ++i, a);
            } else if (a.startsWith("--prompt=")) {
                c.prompt = a.substring(a.indexOf('=') + 1);
            } else if (a.equals("-l") || a.equals("--supported-language")) {
                c.language = language(value(args, ++i, a), usageFor(c, "--supported-language <SUPPORTED_LANGUAGE>"));
            } else if (a.startsWith("--supported-language=")) {
                c.language = language(a.substring(a.indexOf('=') + 1), usageFor(c, "--supported-language <SUPPORTED_LANGUAGE>"));
            } else if (a.startsWith("-")) {
                throw new ArgError("Found argument '" + a + "' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `" + a + "` as a value rather than a flag, use `-- " + a + "`", true, "executable [OPTIONS]");
            } else {
                throw new ArgError("Found argument '" + a + "' which wasn't expected, or isn't valid in this context", true, "executable [OPTIONS]");
            }
        }
        return c;
    }

    private static String value(String[] args, int idx, String opt) throws ArgError {
        if (idx >= args.length) {
            throw new ArgError("The argument '" + opt + " <VALUE>' requires a value but none was supplied", true, "executable [OPTIONS]");
        }
        if (args[idx].startsWith("-")) {
            throw new ArgError("Found argument '" + args[idx] + "' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `" + args[idx] + "` as a value rather than a flag, use `-- " + args[idx] + "`", true, "executable [OPTIONS]");
        }
        return args[idx];
    }

    private static int parseInt(String s, String name, String metavar) throws ArgError {
        try {
            if (s.startsWith("-")) throw new NumberFormatException("invalid digit found in string");
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new ArgError("Invalid value \"" + s + "\" for '--" + name + " <" + metavar + ">': invalid digit found in string", false, "");
        }
    }

    private static String language(String s, String usage) throws ArgError {
        if (s.equals("english") || s.equals("english1k") || s.equals("english10k")) return s;
        throw new ArgError("\"" + s + "\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'\n\t[possible values: english, english1k, english10k]", true, usage);
    }

    private static String usageFor(Config c, String tail) {
        List<String> parts = new ArrayList<>();
        if (c.prompt != null) parts.add("--prompt <PROMPT>");
        parts.add(tail);
        return "executable " + String.join(" ", parts);
    }

    private static void usageError(String msg, boolean usage, String usageLine) {
        System.err.println("error: " + msg);
        System.err.println();
        if (usage) {
            System.err.println("USAGE:");
            System.err.println("    " + usageLine);
            System.err.println();
        }
        System.err.println("For more information try --help");
    }

    private static String helpText() {
        return VERSION + "\n" + ABOUT + "\n\n" +
                "USAGE:\n" +
                "    executable [OPTIONS]\n\n" +
                "OPTIONS:\n" +
                "    -f, --full-sentences <NUMBER_OF_SENTENCES>\n" +
                "            number of sentences to use in test\n\n" +
                "    -h, --help\n" +
                "            Print help information\n\n" +
                "    -l, --supported-language <SUPPORTED_LANGUAGE>\n" +
                "            language to pull words from [default: english] [possible values: english, english1k,\n" +
                "            english10k]\n\n" +
                "    -p, --prompt <PROMPT>\n" +
                "            custom prompt to use\n\n" +
                "    -s, --number-of-secs <NUMBER_OF_SECS>\n" +
                "            number of seconds to run test\n\n" +
                "    -V, --version\n" +
                "            Print version information\n\n" +
                "    -w, --number-of-words <NUMBER_OF_WORDS>\n" +
                "            number of words to use in test [default: 15]\n";
    }

    private static boolean isTty() {
        return System.console() != null || runForStatus("test -t 0") == 0;
    }

    private static int runForStatus(String cmd) {
        try {
            return new ProcessBuilder("bash", "-lc", cmd).inheritIO().start().waitFor();
        } catch (Exception e) {
            return 1;
        }
    }

    private static String makePrompt(Config c) {
        if (c.prompt != null) return c.prompt;
        Random r = new Random();
        if (c.sentences != null) {
            int n = Math.max(1, c.sentences);
            List<String> out = new ArrayList<>();
            for (int i = 0; i < n; i++) out.add(SENTENCES[r.nextInt(SENTENCES.length)]);
            return String.join(" ", out);
        }
        int n = Math.max(1, c.words);
        List<String> out = new ArrayList<>();
        for (int i = 0; i < n; i++) out.add(COMMON[r.nextInt(COMMON.length)]);
        return String.join(" ", out);
    }

    private static void runTui(Config c) throws IOException {
        String prompt = makePrompt(c);
        raw(true);
        long start = 0L;
        StringBuilder typed = new StringBuilder();
        boolean done = false;
        try {
            System.out.print("\033[?1049h\033[2J\033[?25l");
            render(prompt, typed, 0, 100, false);
            while (!done) {
                int ch = System.in.read();
                if (ch < 0 || ch == 27 || ch == 3 || ch == 4) break;
                if (ch == 127 || ch == 8) {
                    if (typed.length() > 0) typed.setLength(typed.length() - 1);
                } else if (ch == '\r' || ch == '\n') {
                    if (typed.length() < prompt.length()) typed.append(' ');
                } else if (ch >= 32) {
                    if (start == 0L) start = System.nanoTime();
                    typed.append((char) ch);
                }
                double elapsed = start == 0L ? 0.0 : (System.nanoTime() - start) / 1_000_000_000.0;
                int acc = accuracy(prompt, typed);
                int wpm = elapsed <= 0 ? 0 : (int)Math.round((correctChars(prompt, typed) / 5.0) / (elapsed / 60.0));
                if ((c.seconds != null && elapsed >= c.seconds) || typed.length() >= prompt.length()) {
                    done = true;
                    render(prompt, typed, wpm, acc, true);
                    logResult(wpm, acc, elapsed, prompt);
                } else {
                    render(prompt, typed, wpm, acc, false);
                }
            }
            if (done) {
                while (true) {
                    int ch = System.in.read();
                    if (ch < 0 || ch == 27 || ch == 3 || ch == 4) break;
                    if (ch == 'r' || ch == 'R') {
                        typed.setLength(0);
                        start = 0L;
                        done = false;
                        runTui(c);
                        return;
                    }
                    if (ch == 'n' || ch == 'N') {
                        c.prompt = null;
                        runTui(c);
                        return;
                    }
                }
            }
        } finally {
            System.out.print("\033[?1049l\033[?25h");
            System.out.flush();
            raw(false);
        }
    }

    private static void render(String prompt, StringBuilder typed, int wpm, int acc, boolean done) {
        System.out.print("\033[H\033[2J");
        System.out.print("\033[3;6H\033[1m" + (done ? String.valueOf(wpm) : "0") + "\033[22m│wpm");
        System.out.print("\033[12;10H");
        for (int i = 0; i < prompt.length(); i++) {
            if (i < typed.length()) {
                System.out.print(typed.charAt(i) == prompt.charAt(i) ? "\033[38;5;2m" : "\033[38;5;1m");
                System.out.print(prompt.charAt(i));
                System.out.print("\033[39m");
            } else if (i == typed.length()) {
                System.out.print("\033[1m\033[4m\033[2m" + prompt.charAt(i) + "\033[24m\033[22m");
            } else {
                System.out.print(prompt.charAt(i));
            }
        }
        if (done) {
            System.out.print("\033[20;20H" + wpm + " wpm   " + acc + "% acc   0.00 sd");
            System.out.print("\033[22;6H\033[3m(r)etry / (n)ew / (esc)ape\033[23m");
        }
        System.out.print("\033[?25l");
        System.out.flush();
    }

    private static int correctChars(String prompt, StringBuilder typed) {
        int n = Math.min(prompt.length(), typed.length());
        int ok = 0;
        for (int i = 0; i < n; i++) if (prompt.charAt(i) == typed.charAt(i)) ok++;
        return ok;
    }

    private static int accuracy(String prompt, StringBuilder typed) {
        if (typed.length() == 0) return 100;
        return (int)Math.round(100.0 * correctChars(prompt, typed) / typed.length());
    }

    private static void logResult(int wpm, int acc, double elapsed, String prompt) {
        try {
            String home = System.getenv().getOrDefault("XDG_CONFIG_HOME", System.getProperty("user.home") + "/.config");
            Path dir = Path.of(home, "thokr");
            Files.createDirectories(dir);
            Path log = dir.resolve("log.csv");
            if (!Files.exists(log)) {
                Files.writeString(log, "timestamp,wpm,accuracy,seconds,prompt\n", StandardCharsets.UTF_8);
            }
            String line = String.format(Locale.ROOT, "%s,%d,%d,%.2f,\"%s\"%n", Instant.now(), wpm, acc, elapsed, prompt.replace("\"", "\"\""));
            Files.writeString(log, line, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
        } catch (Exception ignored) {
        }
    }

    private static void raw(boolean on) {
        String cmd = on ? "stty raw -echo < /dev/tty" : "stty sane < /dev/tty";
        try {
            new ProcessBuilder("bash", "-lc", cmd).start().waitFor();
        } catch (Exception ignored) {
        }
    }

    private static final class Config {
        boolean help;
        boolean version;
        int words = 15;
        Integer seconds;
        Integer sentences;
        String prompt;
        String language = "english";
    }

    private static final class ArgError extends Exception {
        final boolean showUsage;
        final String usage;
        ArgError(String message, boolean showUsage, String usage) {
            super(message);
            this.showUsage = showUsage;
            this.usage = usage;
        }
    }
}
