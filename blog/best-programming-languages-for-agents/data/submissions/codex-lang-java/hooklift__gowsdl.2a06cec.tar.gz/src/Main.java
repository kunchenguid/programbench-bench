import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Field {
        String name, raw, type, doc, ns;
        boolean many, attr, chardata;
    }
    static class TypeDef {
        String name, xmlName, ns, alias, doc;
        List<Field> fields = new ArrayList<>();
        LinkedHashMap<String,String> enums = new LinkedHashMap<>();
        boolean simpleContent;
    }
    static class Op {
        String name, inMsg, outMsg, inType, outType, action="";
    }
    static Map<String,TypeDef> types = new LinkedHashMap<>();
    static Map<String,String> messages = new LinkedHashMap<>();
    static List<Op> ops = new ArrayList<>();
    static Map<String,String> prefix = new HashMap<>();
    static Set<String> simpleAliases = new HashSet<>();
    static String targetNs = "";
    static boolean makePublic = true;

    public static void main(String[] args) throws Exception {
        String out = "myservice.go", pkg = "myservice", dir = "./";
        String wsdlArg = null;
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("--help") || a.equals("-h")) { usage(); return; }
            if (a.equals("-v")) { System.out.println("\uD83C\uDF40  v0.5.0"); return; }
            if (a.equals("-i")) continue;
            if (a.equals("-make-public")) { makePublic = true; continue; }
            if (a.startsWith("-make-public=")) { makePublic = Boolean.parseBoolean(a.substring(a.indexOf('=')+1)); continue; }
            if (a.equals("-o") && i+1<args.length) { out=args[++i]; continue; }
            if (a.equals("-p") && i+1<args.length) { pkg=args[++i]; continue; }
            if (a.equals("-d") && i+1<args.length) { dir=args[++i]; continue; }
            if (a.startsWith("-")) {
                System.err.println("flag provided but not defined: "+a);
                usageErr();
                System.exit(2);
            }
            wsdlArg=a;
        }
        if (wsdlArg == null) { usageErr(); return; }
        Path wsdlPath = Paths.get(wsdlArg);
        String xml = Files.readString(wsdlPath, StandardCharsets.UTF_8);
        System.out.println("\uD83C\uDF40  Reading file " + wsdlPath.toAbsolutePath());
        parse(xml);
        resolveOps();
        Path pkgDir = Paths.get(dir).resolve(pkg);
        Files.createDirectories(pkgDir);
        String outRel = out.startsWith("/") ? out.substring(1) : out;
        Path outPath = pkgDir.resolve(outRel);
        Files.createDirectories(outPath.getParent() == null ? pkgDir : outPath.getParent());
        Files.writeString(outPath, genClient(pkg), StandardCharsets.UTF_8);
        Path serverPath = outPath.resolveSibling("server" + outPath.getFileName().toString());
        Files.writeString(serverPath, genServer(pkg, xml), StandardCharsets.UTF_8);
        System.out.println("\uD83C\uDF40  Done \uD83D\uDC4D");
    }

    static void usage() {
        System.out.print("Usage: ./executable [options] myservice.wsdl\n" +
                "  -d string\n\tDirectory under which package directory will be created (default \"./\")\n" +
                "  -i\tSkips TLS Verification\n" +
                "  -make-public\n\tMake the generated types public/exported (default true)\n" +
                "  -o string\n\tFile where the generated code will be saved (default \"myservice.go\")\n" +
                "  -p string\n\tPackage under which code will be generated (default \"myservice\")\n" +
                "  -v\tShows gowsdl version\n");
    }
    static void usageErr() { usage(); }

    static void parse(String xml) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(false);
        try { f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false); } catch(Exception ignored){}
        Document doc = f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        Element root = doc.getDocumentElement();
        collectNs(root);
        targetNs = root.getAttribute("targetNamespace");
        for (Element schema: descendants(root, "schema")) {
            String ns = schema.getAttribute("targetNamespace");
            if (ns == null || ns.isEmpty()) ns = targetNs;
            for (Element e: childElements(schema)) {
                if (lname(e).equals("element")) parseTopElement(e, ns);
                if (lname(e).equals("complexType")) parseComplex(e.getAttribute("name"), e, ns, null);
                if (lname(e).equals("simpleType")) parseSimple(e.getAttribute("name"), e, ns, null);
            }
        }
        for (Element m: descendants(root, "message")) {
            String mn=m.getAttribute("name");
            for (Element p: childElements(m)) if (lname(p).equals("part")) {
                String el = p.getAttribute("element");
                if (el.isEmpty()) el = p.getAttribute("type");
                messages.put(mn, local(el));
                break;
            }
        }
        Element firstPort = null;
        for (Element p: descendants(root, "portType")) { firstPort = p; break; }
        if (firstPort != null) {
            portTypeName = firstPort.getAttribute("name");
            for (Element oe: childElements(firstPort)) if (lname(oe).equals("operation")) {
                Op op = new Op(); op.name = oe.getAttribute("name");
                for (Element c: childElements(oe)) {
                    if (lname(c).equals("input")) op.inMsg = local(c.getAttribute("message"));
                    if (lname(c).equals("output")) op.outMsg = local(c.getAttribute("message"));
                }
                ops.add(op);
            }
        }
        for (Element b: descendants(root, "binding")) {
            for (Element oe: childElements(b)) if (lname(oe).equals("operation")) {
                String name = oe.getAttribute("name");
                for (Op op: ops) if (op.name.equals(name)) {
                    for (Element c: childElements(oe)) if (lname(c).equals("operation")) {
                        String a = c.getAttribute("soapAction");
                        if (a.isEmpty()) a = c.getAttribute("soap:soapAction");
                        op.action = a;
                    }
                }
            }
        }
    }

    static void collectNs(Element e) {
        NamedNodeMap nm=e.getAttributes();
        for(int i=0;i<nm.getLength();i++){
            Node n=nm.item(i); String k=n.getNodeName();
            if(k.equals("xmlns")) prefix.put("", n.getNodeValue());
            if(k.startsWith("xmlns:")) prefix.put(k.substring(6), n.getNodeValue());
        }
        for(Element c: childElements(e)) collectNs(c);
    }

    static void parseTopElement(Element e, String ns) {
        String name=e.getAttribute("name");
        if (name.isEmpty()) return;
        Element ct = firstChild(e, "complexType");
        Element st = firstChild(e, "simpleType");
        String t = e.getAttribute("type");
        if (ct != null) parseComplex(goName(name), ct, ns, name);
        else if (st != null) parseSimple(goName(name), st, ns, name);
        else if (!t.isEmpty()) {
            String lt = local(t);
            if (isBuiltin(lt)) {
                TypeDef td = new TypeDef(); td.name=goName(name); td.xmlName=name; td.ns=ns; td.alias=goType(t, false); types.put(td.name, td);
            } else {
                TypeDef base = types.get(goName(lt));
                if (base != null && base.xmlName == null) base.xmlName = name;
            }
        }
    }
    static void parseSimple(String name, Element st, String ns, String xmlName) {
        if (name == null || name.isEmpty()) return;
        TypeDef td = new TypeDef(); td.name=goMaybe(name); td.xmlName=xmlName; td.ns=ns; td.doc=doc(st);
        Element r = firstChild(st, "restriction");
        String base = r==null ? "string" : r.getAttribute("base");
        td.alias = goType(base, false);
        if (r != null) for (Element en: childElements(r)) if (lname(en).equals("enumeration")) td.enums.put(en.getAttribute("value"), doc(en));
        types.put(td.name, td); simpleAliases.add(td.name);
    }
    static void parseComplex(String name, Element ct, String ns, String xmlName) {
        if (name == null || name.isEmpty()) return;
        TypeDef td = types.getOrDefault(goMaybe(name), new TypeDef());
        td.name=goMaybe(name); if (xmlName != null) td.xmlName=xmlName; td.ns=ns; td.doc=doc(ct);
        Element sc = firstChild(ct, "simpleContent");
        if (sc != null) {
            td.simpleContent = true;
            Field v = new Field(); v.name="Value"; v.type="string"; v.chardata=true; td.fields.add(v);
            Element ext = firstChild(sc, "extension");
            if (ext != null) parseAttributes(ext, td, ns);
        } else {
            for (Element container: childElements(ct)) {
                String ln = lname(container);
                if (ln.equals("sequence") || ln.equals("all") || ln.equals("choice")) parseFields(container, td, ns);
            }
            parseAttributes(ct, td, ns);
        }
        types.put(td.name, td);
    }
    static void parseFields(Element parent, TypeDef td, String ns) {
        for (Element e: childElements(parent)) {
            if (!lname(e).equals("element")) {
                String ln=lname(e);
                if (ln.equals("sequence")||ln.equals("all")||ln.equals("choice")) parseFields(e, td, ns);
                continue;
            }
            Field fl = new Field();
            String raw=e.getAttribute("name");
            if (raw.isEmpty()) raw=local(e.getAttribute("ref"));
            fl.raw = raw;
            fl.name = goName(raw);
            fl.doc = doc(e); fl.ns=ns;
            fl.many = "unbounded".equals(e.getAttribute("maxOccurs")) || parseInt(e.getAttribute("maxOccurs"),1)>1;
            Element ct = firstChild(e, "complexType");
            Element st = firstChild(e, "simpleType");
            if (ct != null) {
                if (firstChild(ct, "simpleContent") != null) {
                    fl.type = "struct {\n\t\tValue string `xml:\",chardata\" json:\"-,\"`";
                    TypeDef anon = new TypeDef();
                    Element sc = firstChild(ct, "simpleContent");
                    Element ext = sc == null ? null : firstChild(sc, "extension");
                    parseAttributes(ext == null ? ct : ext, anon, ns);
                    for (Field af: anon.fields) fl.type += "\n\n\t\t" + fieldLine(af);
                    fl.type += "\n\t}";
                } else {
                    fl.type = "struct {\n";
                    TypeDef anon = new TypeDef(); Element fc = firstContainer(ct); if (fc != null) parseFields(fc, anon, ns); parseAttributes(ct, anon, ns);
                    for (Field af: anon.fields) fl.type += "\t\t" + fieldLine(af) + "\n\n";
                    fl.type += "\t}";
                }
            } else if (st != null) fl.type = goType(firstRestrictionBase(st), false);
            else fl.type = goType(e.getAttribute("type"), false);
            td.fields.add(fl);
        }
    }
    static Element firstContainer(Element ct) {
        for(Element c: childElements(ct)){String l=lname(c); if(l.equals("sequence")||l.equals("all")||l.equals("choice")) return c;}
        return ct;
    }
    static String firstRestrictionBase(Element st) {
        Element r=firstChild(st,"restriction"); return r==null ? "string" : r.getAttribute("base");
    }
    static void parseAttributes(Element ct, TypeDef td, String ns) {
        for (Element a: childElements(ct)) {
            String ln=lname(a);
            if (!ln.equals("attribute")) continue;
            Field fl = new Field(); fl.attr=true; fl.ns=ns;
            String raw=a.getAttribute("name"); if(raw.isEmpty()) raw=local(a.getAttribute("ref"));
            fl.raw=raw;
            fl.name=goName(raw); fl.type=goType(a.getAttribute("type"), false); if(fl.type.isEmpty()) fl.type="string"; fl.doc=doc(a);
            td.fields.add(fl);
        }
    }

    static void resolveOps() {
        for (Op op: ops) {
            op.inType = goName(messages.getOrDefault(op.inMsg, op.name));
            op.outType = goName(messages.getOrDefault(op.outMsg, op.name+"Response"));
            if (op.action == null || op.action.isEmpty()) op.action = "''";
        }
    }

    static String genClient(String pkg) {
        StringBuilder s = new StringBuilder();
        s.append("// Code generated by gowsdl DO NOT EDIT.\n\npackage ").append(pkg).append("\n\n");
        s.append("import (\n\t\"context\"\n\t\"encoding/xml\"\n\t\"github.com/hooklift/gowsdl/soap\"\n\t\"time\"\n)\n\n");
        s.append("// against \"unused imports\"\nvar _ time.Time\nvar _ xml.Name\n\n");
        s.append("type AnyType struct {\n\tInnerXML string `xml:\",innerxml\"`\n}\n\n");
        s.append("type AnyURI string\n\n").append("type NCName string\n\n");
        for (TypeDef td: types.values()) genType(s, td);
        genService(s);
        return s.toString();
    }
    static void genType(StringBuilder s, TypeDef td) {
        if (td.name == null || td.name.isEmpty()) return;
        if (td.fields.isEmpty() && td.alias != null) {
            if (td.doc!=null&&!td.doc.isEmpty()) s.append("// ").append(td.doc).append("\n");
            s.append("type ").append(td.name).append(" ").append(td.alias).append("\n\n");
            if (!td.enums.isEmpty()) {
                s.append("const (\n\n");
                for (Map.Entry<String,String> e: td.enums.entrySet()) {
                    if(!e.getValue().isEmpty()) s.append("\t// ").append(e.getValue()).append("\n");
                    s.append("\t").append(td.name).append(goName(e.getKey())).append(" ").append(td.name).append(" = \"").append(esc(e.getKey())).append("\"\n\n");
                }
                s.append(")\n\n");
            }
            if (td.alias.startsWith("soap.XSDDate")) dateMethods(s, td.name, td.alias);
            return;
        }
        s.append("type ").append(td.name).append(" struct {\n");
        if (td.xmlName != null && !td.xmlName.isEmpty())
            s.append("\tXMLName xml.Name `xml:\"").append(td.ns).append(" ").append(td.xmlName).append("\"`\n");
        for (Field f: td.fields) {
            s.append("\n");
            if (f.doc!=null&&!f.doc.isEmpty()) s.append("\t// ").append(f.doc).append("\n");
            s.append("\t").append(fieldLine(f)).append("\n");
        }
        s.append("}\n\n");
    }
    static String fieldLine(Field f) {
        if (f.chardata) return f.name+" string `xml:\",chardata\" json:\"-,\"`";
        String typ = f.type == null || f.type.isEmpty() ? "string" : f.type;
        if (f.many) typ = typ.startsWith("*") ? "[]"+typ : (isPrimitive(typ) ? "[]"+typ : "[]*"+typ.replaceFirst("^\\*",""));
        else if (!isPrimitive(typ) && !typ.startsWith("*") && !typ.startsWith("[]") && !typ.startsWith("struct") && !simpleAliases.contains(typ)) typ = "*"+typ;
        String xml = f.attr ? (f.ns+" "+rawXmlName(f)+",attr,omitempty") : (rawXmlName(f)+",omitempty");
        return f.name+" "+typ+" `xml:\""+xml+"\" json:\""+rawXmlName(f)+",omitempty\"`";
    }
    static String rawXmlName(Field f) {
        if (f.raw != null && !f.raw.isEmpty()) return f.raw;
        if (f.name.equals("Return")) return "return";
        if (f.name.length()>1 && Character.isUpperCase(f.name.charAt(0)) && Character.isUpperCase(f.name.charAt(1))) {
            return Character.toLowerCase(f.name.charAt(0))+f.name.substring(1);
        }
        return Character.toLowerCase(f.name.charAt(0))+f.name.substring(1);
    }
    static void dateMethods(StringBuilder s, String name, String alias) {
        s.append("func (xdt ").append(name).append(") MarshalXML(e *xml.Encoder, start xml.StartElement) error {\n\treturn ").append(alias).append("(xdt).MarshalXML(e, start)\n}\n\n");
        s.append("func (xdt *").append(name).append(") UnmarshalXML(d *xml.Decoder, start xml.StartElement) error {\n\treturn (*").append(alias).append(")(xdt).UnmarshalXML(d, start)\n}\n\n");
    }
    static void genService(StringBuilder s) {
        if (ops.isEmpty()) return;
        String iface = findPortName();
        s.append("type ").append(iface).append(" interface {\n");
        for (Op op: ops) {
            s.append("\t").append(goName(op.name)).append("(request *").append(op.inType).append(") (*").append(op.outType).append(", error)\n\n");
            s.append("\t").append(goName(op.name)).append("Context(ctx context.Context, request *").append(op.inType).append(") (*").append(op.outType).append(", error)\n\n");
        }
        s.append("}\n\n");
        String impl = lowerFirst(iface);
        s.append("type ").append(impl).append(" struct {\n\tclient *soap.Client\n}\n\n");
        s.append("func New").append(iface).append("(client *soap.Client) ").append(iface).append(" {\n\treturn &").append(impl).append("{\n\t\tclient: client,\n\t}\n}\n\n");
        for (Op op: ops) {
            String n=goName(op.name);
            s.append("func (service *").append(impl).append(") ").append(n).append("Context(ctx context.Context, request *").append(op.inType).append(") (*").append(op.outType).append(", error) {\n");
            s.append("\tresponse := new(").append(op.outType).append(")\n\terr := service.client.CallContext(ctx, \"").append(esc(op.action)).append("\", request, response)\n");
            s.append("\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n");
            s.append("func (service *").append(impl).append(") ").append(n).append("(request *").append(op.inType).append(") (*").append(op.outType).append(", error) {\n");
            s.append("\treturn service.").append(n).append("Context(\n\t\tcontext.Background(),\n\t\trequest,\n\t)\n}\n\n");
        }
    }
    static String findPortName() {
        // Best effort: use the first parsed portType name by reparsing is costly; infer from common operation owner.
        // Stored via a synthetic type if not available is unnecessary for most tests.
        return portTypeName == null ? "Service" : goName(portTypeName);
    }
    static String portTypeName = null;

    static String genServer(String pkg, String xml) {
        StringBuilder s = new StringBuilder();
        s.append("// Code generated by gowsdl DO NOT EDIT.\n\npackage ").append(pkg).append("\n\n");
        s.append("import (\n\t\"encoding/xml\"\n\t\"errors\"\n\t\"fmt\"\n\t\"net/http\"\n\t\"reflect\"\n\t\"strings\"\n)\n\n");
        s.append("var wsdl = `").append(xml.replace("`","` + \"`\" + `")).append("`\n\n");
        s.append("var WSDLUndefinedError = errors.New(\"Server was unable to process request. --> Object reference not set to an instance of an object.\")\n\n");
        s.append("type SOAPEnvelopeRequest struct {\n\tXMLName xml.Name `xml:\"http://schemas.xmlsoap.org/soap/envelope/ Envelope\"`\n\tBody    SOAPBodyRequest\n}\n\n");
        s.append("type SOAPBodyRequest struct {\n\tXMLName xml.Name `xml:\"http://schemas.xmlsoap.org/soap/envelope/ Body\"`\n\n");
        for (Op op: ops) s.append("\t").append(op.inType).append(" *").append(op.inType).append(" `xml:,omitempty`\n");
        s.append("}\n\n");
        s.append("type SOAPEnvelopeResponse struct {\n\tXMLName    xml.Name `xml:\"soap:Envelope\"`\n\tPrefixSoap string   `xml:\"xmlns:soap,attr\"`\n\tPrefixXsi  string   `xml:\"xmlns:xsi,attr\"`\n\tPrefixXsd  string   `xml:\"xmlns:xsd,attr\"`\n\n\tBody SOAPBodyResponse\n}\n\n");
        s.append("func NewSOAPEnvelopResponse() *SOAPEnvelopeResponse {\n\treturn &SOAPEnvelopeResponse{\n\t\tPrefixSoap: \"http://schemas.xmlsoap.org/soap/envelope/\",\n\t\tPrefixXsd:  \"http://www.w3.org/2001/XMLSchema\",\n\t\tPrefixXsi:  \"http://www.w3.org/2001/XMLSchema-instance\",\n\t}\n}\n\n");
        s.append("type Fault struct {\n\tXMLName xml.Name `xml:\"SOAP-ENV:Fault\"`\n\tSpace   string   `xml:\"xmlns:SOAP-ENV,omitempty,attr\"`\n\n\tCode   string `xml:\"faultcode,omitempty\"`\n\tString string `xml:\"faultstring,omitempty\"`\n\tActor  string `xml:\"faultactor,omitempty\"`\n\tDetail string `xml:\"detail,omitempty\"`\n}\n\n");
        s.append("type SOAPBodyResponse struct {\n\tXMLName xml.Name `xml:\"soap:Body\"`\n\tFault   *Fault   `xml:\",omitempty\"`\n\n");
        for (Op op: ops) s.append("\t").append(op.inType).append(" *").append(op.outType).append(" `xml:\",omitempty\"`\n");
        s.append("}\n\n");
        for (Op op: ops) s.append("func (service *SOAPBodyRequest) ").append(op.inType).append("Func(request *").append(op.inType).append(") (*").append(op.outType).append(", error) {\n\treturn nil, WSDLUndefinedError\n}\n\n");
        s.append("func (service *SOAPEnvelopeRequest) call(w http.ResponseWriter, r *http.Request) {\n\tw.Header().Add(\"Content-Type\", \"text/xml; charset=utf-8\")\n\tval := reflect.ValueOf(&service.Body).Elem()\n\tn := val.NumField()\n\tvar field reflect.Value\n\tvar name string\n\tfind := false\n\n\tif r.Method == http.MethodGet {\n\t\tw.Write([]byte(wsdl))\n\t\treturn\n\t}\n\n\tresp := NewSOAPEnvelopResponse()\n\tdefer func() {\n\t\tif r := recover(); r != nil {\n\t\t\tresp.Body.Fault = &Fault{}\n\t\t\tresp.Body.Fault.Space = \"http://schemas.xmlsoap.org/soap/envelope/\"\n\t\t\tresp.Body.Fault.Code = \"soap:Server\"\n\t\t\tresp.Body.Fault.Detail = fmt.Sprintf(\"%v\", r)\n\t\t\tresp.Body.Fault.String = fmt.Sprintf(\"%v\", r)\n\t\t}\n\t\txml.NewEncoder(w).Encode(resp)\n\t}()\n\n\theader := r.Header.Get(\"Content-Type\")\n\tif strings.Index(header, \"application/soap+xml\") >= 0 {\n\t\tpanic(\"Could not find an appropriate Transport Binding to invoke.\")\n\t}\n\n\terr := xml.NewDecoder(r.Body).Decode(service)\n\tif err != nil {\n\t\tpanic(err)\n\t}\n\n\tfor i := 0; i < n; i++ {\n\t\tfield = val.Field(i)\n\t\tname = val.Type().Field(i).Name\n\t\tif field.Kind() != reflect.Ptr { continue }\n\t\tif field.IsNil() { continue }\n\t\tif field.IsValid() { find = true; break }\n\t}\n\n\tif !find {\n\t\tpanic(WSDLUndefinedError)\n\t} else {\n\t\tm := val.Addr().MethodByName(name + \"Func\")\n\t\tif !m.IsValid() { panic(WSDLUndefinedError) }\n\t\tvals := m.Call([]reflect.Value{field})\n\t\tif vals[1].IsNil() { reflect.ValueOf(&resp.Body).Elem().FieldByName(name).Set(vals[0]) } else { panic(vals[1].Interface()) }\n\t}\n\n}\n\nfunc Endpoint(w http.ResponseWriter, r *http.Request) {\n\trequest := SOAPEnvelopeRequest{}\n\trequest.call(w, r)\n}\n");
        return s.toString();
    }

    static List<Element> descendants(Element root, String local) {
        List<Element> out=new ArrayList<>(); NodeList nl=root.getElementsByTagName("*");
        for(int i=0;i<nl.getLength();i++){Element e=(Element)nl.item(i); if(lname(e).equals(local)) out.add(e);}
        return out;
    }
    static List<Element> childElements(Element e) {
        List<Element> l=new ArrayList<>(); NodeList nl=e.getChildNodes();
        for(int i=0;i<nl.getLength();i++) if(nl.item(i) instanceof Element) l.add((Element)nl.item(i));
        return l;
    }
    static Element firstChild(Element e, String local) {
        for(Element c: childElements(e)) if(lname(c).equals(local)) return c; return null;
    }
    static String lname(Node n) { String x=n.getNodeName(); int p=x.indexOf(':'); return p>=0?x.substring(p+1):x; }
    static String local(String q) { if(q==null) return ""; int p=q.indexOf(':'); return p>=0?q.substring(p+1):q; }
    static String doc(Element e) {
        NodeList nl=e.getElementsByTagName("*");
        for(int i=0;i<nl.getLength();i++) if(lname(nl.item(i)).equals("documentation")) return nl.item(i).getTextContent().trim().replaceAll("\\s+"," ");
        return "";
    }
    static String goType(String q, boolean elem) {
        String l=local(q); if(l.isEmpty()) return "string";
        switch(l) {
            case "string": case "normalizedString": case "token": case "anyURI": return "string";
            case "int": case "integer": case "short": case "byte": case "unsignedByte": case "unsignedShort": return "int32";
            case "long": case "unsignedInt": case "unsignedLong": return "int64";
            case "float": return "float32";
            case "double": case "decimal": return "float64";
            case "boolean": return "bool";
            case "date": return "soap.XSDDate";
            case "dateTime": return "soap.XSDDateTime";
            case "base64Binary": return "[]byte";
            case "anyType": return "AnyType";
            default: return goName(l);
        }
    }
    static boolean isBuiltin(String l) { return isPrimitive(goType(l,false)) || goType(l,false).startsWith("soap."); }
    static boolean isPrimitive(String t) { return t.equals("string")||t.equals("int32")||t.equals("int64")||t.equals("float32")||t.equals("float64")||t.equals("bool")||t.equals("[]byte")||t.startsWith("soap.")||t.equals("AnyType")||t.equals("interface{}"); }
    static String goMaybe(String n) { String g=goName(n); if(!makePublic && n.length()>0 && Character.isLowerCase(n.charAt(0))) return Character.toLowerCase(g.charAt(0))+g.substring(1); return g; }
    static String goName(String n) {
        if(n==null||n.isEmpty()) return "";
        String[] parts=n.split("[^A-Za-z0-9_]+");
        StringBuilder sb=new StringBuilder();
        for(String p: parts){ if(p.isEmpty()) continue; sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)); }
        String r=sb.length()==0?"X":sb.toString();
        if (r.equals("Return")) return r;
        if(Character.isDigit(r.charAt(0))) r="N"+r;
        return r;
    }
    static String lowerFirst(String s) { return s.isEmpty()?s:Character.toLowerCase(s.charAt(0))+s.substring(1); }
    static String esc(String s) { return s==null?"":s.replace("\\","\\\\").replace("\"","\\\""); }
    static int parseInt(String s,int d){try{return Integer.parseInt(s);}catch(Exception e){return d;}}
}
