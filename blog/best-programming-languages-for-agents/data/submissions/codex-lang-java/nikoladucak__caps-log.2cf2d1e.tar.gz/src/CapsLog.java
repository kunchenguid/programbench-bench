import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CapsLog {
    private static final String VERSION = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3";

    static class Options {
        String configPath;
        String logDirPath;
        String logNameFormat;
        boolean sundayStart;
        boolean firstLineSection;
        String password;
        boolean encrypt;
        boolean decrypt;
        boolean help;
    }

    public static void main(String[] args) {
        try {
            Options options = parseArgs(args);
            if (options.help) {
                printHelp();
                return;
            }
            loadConfig(options);
            applyDefaults(options);
            Path logDir = expandPath(options.logDirPath);
            Files.createDirectories(logDir);
            Files.createDirectories(logDir.resolve("scratchpads"));

            if (options.encrypt || options.decrypt) {
                applyCrypto(options, logDir);
                return;
            }

            handlePasswordForNormalOpen(options, logDir);
            showAnnualView(options, logDir);
        } catch (CapsException e) {
            System.out.println("Captain's log encountered an error: ");
            System.out.println(" " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.out.println("Captain's log encountered an error: ");
            System.out.println(" " + e.getMessage());
            System.exit(1);
        }
    }

    private static Options parseArgs(String[] args) throws CapsException {
        Options o = new Options();
        Map<String, String> seen = new HashMap<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h":
                case "--help":
                    ensureOnce(seen, "--help");
                    o.help = true;
                    break;
                case "-c":
                case "--config":
                    ensureOnce(seen, "--config");
                    o.configPath = requireArg(args, ++i, "--config");
                    break;
                case "--log-dir-path":
                    ensureOnce(seen, "--log-dir-path");
                    o.logDirPath = requireArg(args, ++i, "--log-dir-path");
                    break;
                case "--log-name-format":
                    ensureOnce(seen, "--log-name-format");
                    o.logNameFormat = requireArg(args, ++i, "--log-name-format");
                    break;
                case "--sunday-start":
                    ensureOnce(seen, "--sunday-start");
                    o.sundayStart = true;
                    break;
                case "--first-line-section":
                    ensureOnce(seen, "--first-line-section");
                    o.firstLineSection = true;
                    break;
                case "--password":
                    ensureOnce(seen, "--password");
                    o.password = requireArg(args, ++i, "--password");
                    break;
                case "--encrypt":
                    ensureOnce(seen, "--encrypt");
                    o.encrypt = true;
                    break;
                case "--decrypt":
                    ensureOnce(seen, "--decrypt");
                    o.decrypt = true;
                    break;
                default:
                    throw new CapsException("unrecognised option '" + a + "'");
            }
        }
        return o;
    }

    private static void ensureOnce(Map<String, String> seen, String key) throws CapsException {
        if (seen.containsKey(key)) {
            throw new CapsException("option '" + key + "' cannot be specified more than once");
        }
        seen.put(key, key);
    }

    private static String requireArg(String[] args, int index, String option) throws CapsException {
        if (index >= args.length || args[index].startsWith("-")) {
            throw new CapsException("the required argument for option '" + option + "' is missing");
        }
        return args[index];
    }

    private static void loadConfig(Options o) throws IOException, CapsException {
        String home = System.getenv().getOrDefault("HOME", System.getProperty("user.home"));
        Path cfg = expandPath(o.configPath == null ? home + "/.caps-log/config.ini" : o.configPath);
        if (!Files.exists(cfg)) {
            throw new CapsException("Failed to open file: " + cfg);
        }
        String section = "";
        int lineNo = 0;
        try (BufferedReader br = Files.newBufferedReader(cfg, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNo++;
                String trimmed = line.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith(";")) {
                    continue;
                }
                if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                    section = trimmed.substring(1, trimmed.length() - 1);
                    continue;
                }
                int eq = trimmed.indexOf('=');
                if (eq < 0) {
                    throw new CapsException("Failed to parse configuration file: <unspecified file>(" + lineNo + "): '=' character not found in line");
                }
                String key = trimmed.substring(0, eq).trim();
                String value = stripInlineComment(trimmed.substring(eq + 1).trim());
                if (!section.isEmpty()) {
                    continue;
                }
                switch (key) {
                    case "log-dir-path":
                        if (o.logDirPath == null) o.logDirPath = value;
                        break;
                    case "log-name-format":
                    case "log-filename-format":
                        if (o.logNameFormat == null) o.logNameFormat = value;
                        break;
                    case "sunday-start":
                        if (isTrue(value)) o.sundayStart = true;
                        break;
                    case "first-line-section":
                        if (isTrue(value)) o.firstLineSection = true;
                        break;
                    case "password":
                        if (o.password == null) o.password = value;
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private static String stripInlineComment(String value) {
        int idx = value.indexOf(" #");
        if (idx >= 0) return value.substring(0, idx).trim();
        return value;
    }

    private static boolean isTrue(String v) {
        return "true".equalsIgnoreCase(v) || "1".equals(v) || "yes".equalsIgnoreCase(v);
    }

    private static void applyDefaults(Options o) {
        String home = System.getenv().getOrDefault("HOME", System.getProperty("user.home"));
        if (o.logDirPath == null) o.logDirPath = home + "/.caps-log/day/";
        if (o.logNameFormat == null) o.logNameFormat = "d%y_%m_%d.md";
    }

    private static Path expandPath(String p) {
        if (p.startsWith("~/")) {
            String home = System.getenv().getOrDefault("HOME", System.getProperty("user.home"));
            return Paths.get(home + p.substring(1)).normalize();
        }
        return Paths.get(p).normalize();
    }

    private static void applyCrypto(Options o, Path logDir) throws Exception {
        if (o.encrypt && (o.password == null || o.password.isEmpty())) {
            throw new CapsException("Password must be provided when encrypting logs!");
        }
        if (o.decrypt && (o.password == null || o.password.isEmpty())) {
            throw new CapsException("Password must be provided when decrypting logs!");
        }
        Path marker = logDir.resolve(".cle");
        System.out.println("Applying crypto...");
        if (o.decrypt && !Files.exists(marker)) {
            throw new CapsException("Already applied");
        }
        if (o.encrypt && Files.exists(marker) && !o.decrypt) {
            throw new CapsException("Already applied");
        }
        if (o.decrypt && Files.exists(marker)) {
            if (!matchesMarker(marker, o.password)) {
                throw new CapsException("Invalid password provided!");
            }
            Files.delete(marker);
            return;
        }
        Files.write(marker, markerBytes(o.password));
    }

    private static void handlePasswordForNormalOpen(Options o, Path logDir) throws Exception {
        Path marker = logDir.resolve(".cle");
        if (Files.exists(marker)) {
            String password = o.password;
            if (password == null) {
                Console c = System.console();
                if (c != null) {
                    char[] chars = c.readPassword("Password: ");
                    password = chars == null ? "" : new String(chars);
                } else {
                    BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
                    password = br.readLine();
                }
            }
            if (!matchesMarker(marker, password == null ? "" : password)) {
                throw new CapsException("Invalid password provided!");
            }
        } else if (o.password != null) {
            throw new CapsException("Password provided for a non encrypted repository!");
        }
    }

    private static byte[] markerBytes(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update("caps-log".getBytes(StandardCharsets.UTF_8));
        md.update((byte) 0);
        md.update(password.getBytes(StandardCharsets.UTF_8));
        byte[] digest = md.digest();
        byte[] out = new byte[18];
        System.arraycopy(digest, 0, out, 0, out.length);
        return out;
    }

    private static boolean matchesMarker(Path marker, String password) throws Exception {
        byte[] got = Files.readAllBytes(marker);
        byte[] expected = markerBytes(password);
        if (got.length != expected.length) return false;
        int diff = 0;
        for (int i = 0; i < got.length; i++) diff |= got[i] ^ expected[i];
        return diff == 0;
    }

    private static void showAnnualView(Options o, Path logDir) throws IOException {
        LocalDate today = LocalDate.now();
        List<Path> logs = listRegularFiles(logDir);
        int count = countLogsForYear(logs, today.getYear());
        Set<String> sections = new LinkedHashSet<>();
        Set<String> tags = new LinkedHashSet<>();
        for (Path p : logs) {
            parseLogMetadata(p, sections, tags, o.firstLineSection);
        }

        System.out.print("\u0000\u001bP$q q\u001b\\\u001b[?1049h\u001b[?7l\u001b[?1000h\u001b[?1003h\u001b[?1015h\u001b[?1006h\u0000\r\u001b[2K");
        System.out.printf("       \u001b[1m\u001b[4mToday is: %02d. %02d. %04d.  | There are %d log entries for year %d.\u001b[22m\u001b[24m        %n",
                today.getDayOfMonth(), today.getMonthValue(), today.getYear(), count, today.getYear());
        System.out.println("╭Sections───────────╮╭Tags──────────────╮╭" + today.getYear() + "──────────────────╮");
        printMenuLine(sections.isEmpty() ? "<select none>" : sections.iterator().next(),
                tags.isEmpty() ? "<select none>" : tags.iterator().next(), true);
        int printed = 1;
        for (String s : sections) {
            if (printed++ == 1) continue;
            printMenuLine(s, "", false);
            if (printed > 12) break;
        }
        while (printed++ < 8) printMenuLine("", "", false);
        System.out.println("╰───────────────────╯╰──────────────────╯");
        System.out.printf("╭──────────────────────────────────────────────────────────────────────────────╮%n");
        System.out.printf("│                         log preview for %02d. %02d. %02d.                          │%n",
                today.getDayOfMonth(), today.getMonthValue(), today.getYear() % 100);
        System.out.printf("╰──────────────────────────────────────────────────────────────────────────────╯%n");
        System.out.flush();
        sleepLikeTui();
    }

    private static void printMenuLine(String section, String tag, boolean selected) {
        String left = selected ? "> " + section : section;
        String right = selected ? "> " + tag : tag;
        System.out.printf("│%-19.19s││%-18.18s││%n", left, right);
    }

    private static void sleepLikeTui() {
        try {
            while (true) {
                Thread.sleep(1000);
            }
        } catch (InterruptedException ignored) {
        }
    }

    private static List<Path> listRegularFiles(Path dir) throws IOException {
        List<Path> result = new ArrayList<>();
        if (!Files.isDirectory(dir)) return result;
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p : ds) {
                if (Files.isRegularFile(p) && !p.getFileName().toString().startsWith(".")) result.add(p);
            }
        }
        return result;
    }

    private static int countLogsForYear(List<Path> logs, int year) {
        int count = 0;
        String y2 = String.format("%02d", year % 100);
        String y4 = String.valueOf(year);
        Pattern p = Pattern.compile(".*(?:^|\\D)(" + Pattern.quote(y4) + "|" + Pattern.quote(y2) + ")(?:\\D|$).*");
        for (Path log : logs) {
            Matcher m = p.matcher(log.getFileName().toString());
            if (m.matches()) count++;
        }
        return count;
    }

    private static void parseLogMetadata(Path file, Set<String> sections, Set<String> tags, boolean firstLineSection) {
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            int lineNo = 0;
            for (String line : lines) {
                lineNo++;
                String t = line.trim();
                if (t.startsWith("#") && (lineNo != 1 || firstLineSection)) {
                    String name = t.replaceFirst("^#+", "").trim();
                    if (!name.isEmpty()) sections.add(name);
                } else if (t.startsWith("*")) {
                    String name = t.substring(1).trim();
                    int colon = name.indexOf(':');
                    if (colon >= 0) name = name.substring(0, colon).trim();
                    if (!name.isEmpty()) tags.add(name);
                }
            }
        } catch (IOException ignored) {
        }
    }

    private static void printHelp() {
        System.out.println("Captain's Log (caps-log)! A CLI journalig tool.");
        System.out.println("Version: " + VERSION);
        System.out.println("Allowed options:");
        System.out.println("  -h [ --help ]         show this message");
        System.out.println("  -c [ --config ] arg   override the default config file path ");
        System.out.println("                        (/home/agent/.caps-log/config.ini)");
        System.out.println("  --log-dir-path arg    path where log files are stored");
        System.out.println("  --log-name-format arg format in which log entry markdown files are saved");
        System.out.println("  --sunday-start        have the calendar display sunday as first day of the ");
        System.out.println("                        week");
        System.out.println("  --first-line-section  override the default behaviour of ignoring sections ");
        System.out.println("                        (lines starting with `#`) in the first line of a log ");
        System.out.println("                        entry file");
        System.out.println("  --password arg        password for encrypted log repositories or to be used ");
        System.out.println("                        with --encrypt/--decrypt");
        System.out.println("  --encrypt             apply encryption to all logs in log dir path (needs ");
        System.out.println("                        --password)");
        System.out.println("  --decrypt             apply decryption to all logs in log dir path (needs ");
        System.out.println("                        --password)");
    }

    static class CapsException extends Exception {
        CapsException(String message) {
            super(message);
        }
    }
}
