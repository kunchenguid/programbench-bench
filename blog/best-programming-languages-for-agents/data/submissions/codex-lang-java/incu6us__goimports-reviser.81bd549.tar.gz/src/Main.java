import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Opt {
        boolean applyGenerated, format, listDiff, recursive, rmUnused, separateNamed, setAlias, setExitStatus, useCache;
        String companyPrefixes = "", excludes = "", filePath = "", importsOrder = "std,general,company,project",
                local = "", output = "file", projectName = "";
        List<String> args = new ArrayList<>();
    }

    static class Imp {
        String alias = "";
        String path = "";
        String comment = "";
        String preComment = "";
        String group = "";
        boolean named;
        String line() {
            String p = path;
            String a = alias;
            if (!a.isEmpty()) return "\t" + a + " \"" + p + "\"" + comment;
            return "\t\"" + p + "\"" + comment;
        }
    }

    static final String VERSION = "3.0.0-20260303205914-9926ea38658f";

    public static void main(String[] argv) {
        Opt o = new Opt();
        try {
            parse(argv, o);
            if (has(argv, "-version-only")) { System.out.println(VERSION); return; }
            if (has(argv, "-version")) {
                System.out.println("version: " + VERSION);
                System.out.println("built with: go1.26.0");
                System.out.println("tag: v" + VERSION);
                System.out.println("commit: n/a");
                System.out.println("source: github.com/incu6us/goimports-reviser/v3");
                return;
            }
            List<Path> targets = collectTargets(o);
            if (targets.isEmpty()) {
                usage();
                log("no file(s) or directory(ies) specified on input");
                System.exit(1);
            }
            log("Paths: " + displayPaths(o.args.isEmpty() && !o.filePath.isEmpty() ? List.of(o.filePath) : o.args));
            boolean changedAny = false;
            for (Path p : targets) {
                log("Processing " + relativize(p));
                String project = o.projectName.isEmpty() ? inferProjectName(p) : o.projectName;
                if (project == null || project.isEmpty()) {
                    usage();
                    log("Could not determine project name for path " + relativize(p) + ": open go.mod: no such file or directory");
                    System.exit(1);
                }
                String original = Files.readString(p);
                String revised = revise(original, o, project);
                if (!isGenerated(original) || o.applyGenerated) revised = formatGo(revised);
                boolean changed = !original.equals(revised);
                changedAny |= changed;
                if (o.listDiff) {
                    if (changed) System.out.println(p.toAbsolutePath().normalize());
                    if (changed && o.output.equals("write")) Files.writeString(p, revised);
                } else if (o.output.equals("stdout")) {
                    System.out.print(revised);
                } else {
                    if (changed) Files.writeString(p, revised);
                }
            }
            if (o.setExitStatus && changedAny) System.exit(1);
        } catch (FlagException e) {
            System.err.println(e.getMessage());
            usage();
            System.exit(2);
        } catch (Exception e) {
            log(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static void parse(String[] argv, Opt o) throws FlagException {
        for (int i = 0; i < argv.length; i++) {
            String a = argv[i];
            if (!a.startsWith("-") || a.equals("-")) { o.args.add(a); continue; }
            switch (a) {
                case "-apply-to-generated-files": o.applyGenerated = true; break;
                case "-format": o.format = true; break;
                case "-list-diff": o.listDiff = true; break;
                case "-recursive": o.recursive = true; break;
                case "-rm-unused": o.rmUnused = true; break;
                case "-separate-named": o.separateNamed = true; break;
                case "-set-alias": o.setAlias = true; break;
                case "-set-exit-status": o.setExitStatus = true; break;
                case "-use-cache": o.useCache = true; break;
                case "-version": case "-version-only": break;
                case "-company-prefixes": o.companyPrefixes = val(argv, ++i, a); break;
                case "-excludes": o.excludes = val(argv, ++i, a); break;
                case "-file-path": o.filePath = val(argv, ++i, a); break;
                case "-imports-order": o.importsOrder = val(argv, ++i, a); break;
                case "-local": o.local = val(argv, ++i, a); break;
                case "-output": o.output = val(argv, ++i, a); break;
                case "-project-name": o.projectName = val(argv, ++i, a); break;
                case "-h": case "-help": case "--help": usage(); System.exit(0); break;
                default: throw new FlagException("flag provided but not defined: " + a);
            }
        }
        if (o.args.isEmpty() && !o.filePath.isEmpty()) o.args.add(o.filePath);
    }

    static boolean has(String[] a, String f) { for (String s : a) if (s.equals(f)) return true; return false; }
    static String val(String[] a, int i, String flag) throws FlagException {
        if (i >= a.length) throw new FlagException("flag needs an argument: " + flag);
        return a[i];
    }

    static List<Path> collectTargets(Opt o) throws IOException {
        List<Path> out = new ArrayList<>();
        for (String s : o.args) {
            if (s.equals("./...") || s.equals("...")) {
                walk(Paths.get("."), out, o);
            } else {
                Path p = Paths.get(s);
                if (Files.isDirectory(p)) {
                    if (o.recursive || s.endsWith("/...")) walk(s.endsWith("/...") ? Paths.get(s.substring(0, s.length()-4)) : p, out, o);
                    else try (DirectoryStream<Path> ds = Files.newDirectoryStream(p, "*.go")) {
                        for (Path f : ds) if (include(f, o)) out.add(f);
                    }
                } else if (s.endsWith("/...")) {
                    walk(Paths.get(s.substring(0, s.length()-4)), out, o);
                } else if (s.endsWith(".go") && include(p, o)) out.add(p);
            }
        }
        out.sort(Comparator.comparing(Path::toString));
        return out;
    }

    static void walk(Path root, List<Path> out, Opt o) throws IOException {
        Files.walkFileTree(root, new SimpleFileVisitor<>() {
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                String n = dir.getFileName() == null ? "" : dir.getFileName().toString();
                if (n.equals(".git") || n.equals("build")) return FileVisitResult.SKIP_SUBTREE;
                return include(dir, o) ? FileVisitResult.CONTINUE : FileVisitResult.SKIP_SUBTREE;
            }
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (file.toString().endsWith(".go") && include(file, o)) out.add(file);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    static boolean include(Path p, Opt o) {
        if (o.excludes.isEmpty()) return true;
        String s = p.toString().replace('\\', '/');
        for (String ex : o.excludes.split(",")) {
            ex = ex.trim(); if (ex.isEmpty()) continue;
            if (ex.endsWith("/") && s.contains(ex.substring(0, ex.length()-1) + "/")) return false;
            String re = ex.replace(".", "\\.").replace("*", ".*");
            if (s.matches(re) || s.matches(".*/" + re)) return false;
        }
        return true;
    }

    static String inferProjectName(Path file) throws IOException {
        Path p = Files.isDirectory(file) ? file : file.getParent();
        if (p == null) p = Paths.get(".");
        p = p.toAbsolutePath().normalize();
        while (p != null) {
            Path mod = p.resolve("go.mod");
            if (Files.exists(mod)) {
                for (String line : Files.readAllLines(mod)) {
                    line = line.trim();
                    if (line.startsWith("module ")) return line.substring(7).trim();
                }
            }
            p = p.getParent();
        }
        return null;
    }

    static boolean isGenerated(String s) {
        String t = s.stripLeading();
        return t.startsWith("// Code generated");
    }

    static String revise(String src, Opt o, String project) {
        if (isGenerated(src) && !o.applyGenerated) return src;
        Matcher m = Pattern.compile("(?ms)^import[ \\t]*(?:\\((.*?)\\)|((?:\\w+|[._])?[ \\t]*\"[^\"]+\"[ \\t]*(?://[^\\n]*)?))").matcher(src);
        if (!m.find()) return src;
        String body = m.group(1) != null ? m.group(1) : m.group(2);
        List<Imp> imports = parseImports(body);
        if (imports.isEmpty()) return src;
        if (o.setAlias) setAliases(imports);
        if (o.rmUnused) imports = removeUnused(imports, src.substring(m.end()));
        for (Imp im : imports) im.group = group(im, o, project);
        imports.sort((a,b) -> {
            int ga = groupRank(a.group, o), gb = groupRank(b.group, o);
            if (ga != gb) return Integer.compare(ga, gb);
            if (o.separateNamed && a.named != b.named) return a.named ? 1 : -1;
            return a.path.compareTo(b.path);
        });
        String block = buildBlock(imports, o);
        return src.substring(0, m.start()) + block + src.substring(m.end());
    }

    static List<Imp> parseImports(String body) {
        List<Imp> list = new ArrayList<>();
        String pending = "";
        for (String raw : body.split("\\R")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("//") || line.startsWith("/*")) { pending += (pending.isEmpty() ? "" : "\n") + "\t" + line; continue; }
            Matcher mm = Pattern.compile("^((?:\\w+|[._])\\s+)?\"([^\"]+)\"(\\s*//.*)?$").matcher(line);
            if (mm.find()) {
                Imp im = new Imp();
                im.alias = mm.group(1) == null ? "" : mm.group(1).trim();
                im.path = mm.group(2);
                im.comment = mm.group(3) == null ? "" : normalizeComment(mm.group(3));
                im.preComment = pending; pending = "";
                im.named = !im.alias.isEmpty() && !im.alias.equals("_") && !im.alias.equals(".");
                list.add(im);
            }
        }
        return list;
    }

    static String normalizeComment(String c) {
        if (c == null || c.isBlank()) return "";
        c = c.trim();
        return " " + c;
    }

    static void setAliases(List<Imp> list) {
        Pattern p = Pattern.compile("/v\\d+$");
        for (Imp im : list) {
            if (!im.alias.isEmpty()) continue;
            if (p.matcher(im.path).find()) {
                String x = im.path.replaceAll("/v\\d+$", "");
                int slash = x.lastIndexOf('/');
                im.alias = slash >= 0 ? x.substring(slash + 1).replace("-", "") : x;
                im.named = true;
            }
        }
    }

    static List<Imp> removeUnused(List<Imp> list, String code) {
        List<Imp> keep = new ArrayList<>();
        for (Imp im : list) {
            if (im.alias.equals("_") || im.alias.equals(".")) { keep.add(im); continue; }
            String name = im.alias.isEmpty() ? baseName(im.path) : im.alias;
            if (Pattern.compile("\\b" + Pattern.quote(name) + "\\b").matcher(code).find()) keep.add(im);
        }
        return keep.isEmpty() ? list : keep;
    }

    static String baseName(String p) {
        String b = p.substring(p.lastIndexOf('/') + 1);
        if (b.matches("v\\d+")) {
            String x = p.substring(0, p.lastIndexOf('/'));
            b = x.substring(x.lastIndexOf('/') + 1);
        }
        return b.replace("-", "");
    }

    static String group(Imp im, Opt o, String project) {
        if (im.alias.equals("_")) return "blanked";
        if (im.alias.equals(".")) return "dotted";
        if (!project.isEmpty() && (im.path.equals(project) || im.path.startsWith(project + "/"))) return "project";
        for (String c : o.companyPrefixes.split(",")) {
            c = c.trim();
            if (!c.isEmpty() && (im.path.equals(c) || im.path.startsWith(c + "/"))) return "company";
        }
        return isStd(im.path) ? "std" : "general";
    }

    static boolean isStd(String p) {
        if (p.contains(".")) return false;
        return !p.contains("/") || p.startsWith("crypto/") || p.startsWith("database/") || p.startsWith("encoding/") ||
                p.startsWith("go/") || p.startsWith("hash/") || p.startsWith("html/") || p.startsWith("image/") ||
                p.startsWith("internal/") || p.startsWith("math/") || p.startsWith("mime/") || p.startsWith("net/") ||
                p.startsWith("os/") || p.startsWith("path/") || p.startsWith("runtime/") || p.startsWith("sync/") ||
                p.startsWith("testing/") || p.startsWith("text/") || p.startsWith("unicode/");
    }

    static int groupRank(String g, Opt o) {
        String[] parts = o.importsOrder.split(",");
        for (int i = 0; i < parts.length; i++) if (parts[i].trim().equals(g)) return i;
        if (g.equals("company") && !o.importsOrder.contains("company")) return groupRank("general", o);
        return 100;
    }

    static String buildBlock(List<Imp> imports, Opt o) {
        if (imports.isEmpty()) return "";
        if (imports.size() == 1 && imports.get(0).preComment.isEmpty()) {
            Imp im = imports.get(0);
            String p = im.alias.isEmpty() ? "\"" + im.path + "\"" : im.alias + " \"" + im.path + "\"";
            return "import " + p + im.comment;
        }
        StringBuilder sb = new StringBuilder("import (\n");
        String prevGroup = null; Boolean prevNamed = null;
        for (int i = 0; i < imports.size(); i++) {
            Imp im = imports.get(i);
            boolean sep = i > 0 && (!Objects.equals(prevGroup, im.group) || (o.separateNamed && prevNamed != null && prevNamed != im.named));
            if (sep) sb.append("\n");
            if (!im.preComment.isEmpty()) sb.append(im.preComment).append("\n");
            sb.append(im.line()).append("\n");
            prevGroup = im.group; prevNamed = im.named;
        }
        sb.append(")");
        return sb.toString();
    }

    static String formatGo(String s) {
        s = s.replaceAll("(?m)^import (?!\\()([^\\n]+)\\n(?!\\n)", "import $1\n\n");
        s = s.replaceAll("\\)\\s*func\\s+", ")\n\nfunc ");
        s = s.replaceAll("(?m)^func ([^{\\n]+)\\{", "func $1 {");
        s = Pattern.compile("(?m)^(func [^\\n{}]*)\\{([^{}\\n]*)\\}$").matcher(s)
                .replaceAll(m -> m.group(1).trim() + " { " + m.group(2).trim() + " }");
        s = s.replaceAll("\\}\\s*func\\s+", "}\n\nfunc ");
        s = s.replaceAll(";\\s*([A-Za-z_][A-Za-z0-9_]*\\.)", "; $1");
        s = alignImportComments(s);
        return s.endsWith("\n") ? s : s + "\n";
    }

    static String alignImportComments(String s) {
        String[] lines = s.split("\\R", -1);
        boolean inImport = false;
        int groupStart = -1;
        for (int i = 0; i < lines.length; i++) {
            String t = lines[i].trim();
            if (t.equals("import (")) { inImport = true; groupStart = i + 1; continue; }
            if (inImport && t.equals(")")) { alignGroup(lines, groupStart, i); inImport = false; continue; }
            if (inImport && t.isEmpty()) { alignGroup(lines, groupStart, i); groupStart = i + 1; }
        }
        return String.join("\n", lines);
    }

    static void alignGroup(String[] lines, int from, int to) {
        int max = -1;
        for (int i = from; i < to; i++) {
            int idx = lines[i].indexOf(" //");
            if (idx > 0) max = Math.max(max, idx);
        }
        if (max < 0) return;
        for (int i = from; i < to; i++) {
            int idx = lines[i].indexOf(" //");
            if (idx > 0 && idx < max) {
                String left = lines[i].substring(0, idx).stripTrailing();
                String right = lines[i].substring(idx).stripLeading();
                lines[i] = left + " ".repeat(max - left.length() + 1) + right;
            }
        }
    }

    static String relativize(Path p) {
        Path abs = p.toAbsolutePath().normalize();
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        try { return cwd.relativize(abs).toString(); } catch (Exception e) { return p.toString(); }
    }

    static String displayPaths(List<String> a) { return a.toString(); }

    static void log(String msg) {
        System.err.println(java.time.LocalDate.now() + " " + java.time.LocalTime.now().withNano(0) + " " + msg);
    }

    static void usage() {
        System.err.println("Usage of ./executable:");
        System.err.println("  -apply-to-generated-files\n    \tApply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.");
        System.err.println("  -company-prefixes string\n    \tCompany package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.");
        System.err.println("  -excludes string\n    \tExclude files or dirs, example: '.git/,proto/*.go'.");
        System.err.println("  -file-path string\n    \tDeprecated. Put file name as an argument(last item) of command line.");
        System.err.println("  -format\n    \tOption will perform additional formatting. Optional parameter.");
        System.err.println("  -imports-order string\n    \tYour imports groups can be sorted in your way. \n    \tstd - std import group; \n    \tgeneral - libs for general purpose; \n    \tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); \n    \tproject - your local project dependencies;\n    \tblanked - imports with \"_\" alias;\n    \tdotted - imports with \".\" alias.\n    \tOptional parameter. (default \"std,general,company,project\")");
        System.err.println("  -list-diff\n    \tOption will list files whose formatting differs from goimports-reviser. Optional parameter.");
        System.err.println("  -local string\n    \tDeprecated");
        System.err.println("  -output string\n    \tCan be \"file\", \"write\" or \"stdout\". Whether to write the formatted content back to the file or to stdout. When \"write\" together with \"-list-diff\" will list the file name and write back to the file. Optional parameter. (default \"file\")");
        System.err.println("  -project-name string\n    \tYour project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.");
        System.err.println("  -recursive\n    \tApply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.");
        System.err.println("  -rm-unused\n    \tRemove unused imports. Optional parameter.");
        System.err.println("  -separate-named\n    \tOption will separate named imports from the rest of the imports, per group. Optional parameter.");
        System.err.println("  -set-alias\n    \tSet alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg \"github.com/go-pg/pg/v9\"'. Optional parameter.");
        System.err.println("  -set-exit-status\n    \tset the exit status to 1 if a change is needed/made. Optional parameter.");
        System.err.println("  -use-cache\n    \tUse cache to improve performance. Optional parameter.");
        System.err.println("  -version\n    \tShow version information");
        System.err.println("  -version-only\n    \tShow only the version string");
    }

    static class FlagException extends Exception { FlagException(String s) { super(s); } }
}
