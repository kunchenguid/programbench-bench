import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class FastTextClone {
    static final String MAGIC = "JFASTTEXT\t1";

    public static void main(String[] args) {
        try {
            if (args.length == 0 || args[0].equals("--help") || args[0].equals("-help")) {
                printMainUsage();
                System.exit(1);
            }
            String cmd = args[0];
            String[] rest = Arrays.copyOfRange(args, 1, args.length);
            switch (cmd) {
                case "supervised": train(rest, true); break;
                case "skipgram": trainVectors(rest, "skipgram"); break;
                case "cbow": trainVectors(rest, "cbow"); break;
                case "quantize": quantize(rest); break;
                case "predict": predict(rest, false); break;
                case "predict-prob": predict(rest, true); break;
                case "test": test(rest, false); break;
                case "test-label": test(rest, true); break;
                case "print-word-vectors": printWordVectors(rest); break;
                case "print-sentence-vectors": printSentenceVectors(rest); break;
                case "print-ngrams": printNgrams(rest); break;
                case "nn": nearest(rest); break;
                case "analogies": analogies(rest); break;
                case "dump": dump(rest); break;
                default:
                    printMainUsage();
                    System.exit(1);
            }
        } catch (Usage u) {
            System.out.print(u.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    static void printMainUsage() {
        System.out.print(
            "usage: fasttext <command> <args>\n\n" +
            "The commands supported by fasttext are:\n\n" +
            "  supervised              train a supervised classifier\n" +
            "  quantize                quantize a model to reduce the memory usage\n" +
            "  test                    evaluate a supervised classifier\n" +
            "  test-label              print labels with precision and recall scores\n" +
            "  predict                 predict most likely labels\n" +
            "  predict-prob            predict most likely labels with probabilities\n" +
            "  skipgram                train a skipgram model\n" +
            "  cbow                    train a cbow model\n" +
            "  print-word-vectors      print word vectors given a trained model\n" +
            "  print-sentence-vectors  print sentence vectors given a trained model\n" +
            "  print-ngrams            print ngrams given a trained model and word\n" +
            "  nn                      query for nearest neighbors\n" +
            "  analogies               query for analogies\n" +
            "  dump                    dump arguments,dictionary,input/output vectors\n\n");
    }

    static String trainHelp(boolean supervised, String prefix) {
        String minCount = supervised ? "1" : "5";
        String minn = supervised ? "0" : "3";
        String maxn = supervised ? "0" : "6";
        String lr = supervised ? "0.1" : "0.05";
        String loss = supervised ? "softmax" : "ns";
        return prefix +
            "\nThe following arguments are mandatory:\n" +
            "  -input              training file path\n" +
            "  -output             output file path\n\n" +
            "The following arguments are optional:\n" +
            "  -verbose            verbosity level [2]\n\n" +
            "The following arguments for the dictionary are optional:\n" +
            "  -minCount           minimal number of word occurences [" + minCount + "]\n" +
            "  -minCountLabel      minimal number of label occurences [0]\n" +
            "  -wordNgrams         max length of word ngram [1]\n" +
            "  -bucket             number of buckets [2000000]\n" +
            "  -minn               min length of char ngram [" + minn + "]\n" +
            "  -maxn               max length of char ngram [" + maxn + "]\n" +
            "  -t                  sampling threshold [0.0001]\n" +
            "  -label              labels prefix [__label__]\n\n" +
            "The following arguments for training are optional:\n" +
            "  -lr                 learning rate [" + lr + "]\n" +
            "  -lrUpdateRate       change the rate of updates for the learning rate [100]\n" +
            "  -dim                size of word vectors [100]\n" +
            "  -ws                 size of the context window [5]\n" +
            "  -epoch              number of epochs [5]\n" +
            "  -neg                number of negatives sampled [5]\n" +
            "  -loss               loss function {ns, hs, softmax, one-vs-all} [" + loss + "]\n" +
            "  -thread             number of threads (set to 1 to ensure reproducible results) [12]\n" +
            "  -pretrainedVectors  pretrained word vectors for supervised learning []\n" +
            "  -saveOutput         whether output params should be saved [false]\n" +
            "  -seed               random generator seed  [0]\n\n" +
            "The following arguments are for autotune:\n" +
            "  -autotune-validation            validation file to be used for evaluation\n" +
            "  -autotune-metric                metric objective {f1, f1:labelname} [f1]\n" +
            "  -autotune-predictions           number of predictions used for evaluation  [1]\n" +
            "  -autotune-duration              maximum duration in seconds [300]\n" +
            "  -autotune-modelsize             constraint model file size [] (empty = do not quantize)\n\n" +
            "The following arguments for quantization are optional:\n" +
            "  -cutoff             number of words and ngrams to retain [0]\n" +
            "  -retrain            whether embeddings are finetuned if a cutoff is applied [false]\n" +
            "  -qnorm              whether the norm is quantized separately [false]\n" +
            "  -qout               whether the classifier is quantized [false]\n" +
            "  -dsub               size of each sub-vector [2]\n";
    }

    static Map<String,String> parseOpts(String[] a, boolean supervised) {
        Set<String> valid = new HashSet<>(Arrays.asList("-input","-output","-verbose","-minCount","-minCountLabel","-wordNgrams","-bucket","-minn","-maxn","-t","-label","-lr","-lrUpdateRate","-dim","-ws","-epoch","-neg","-loss","-thread","-pretrainedVectors","-saveOutput","-seed","-autotune-validation","-autotune-metric","-autotune-predictions","-autotune-duration","-autotune-modelsize","-cutoff","-retrain","-qnorm","-qout","-dsub"));
        Map<String,String> m = new HashMap<>();
        for (int i = 0; i < a.length; i++) {
            String k = a[i];
            if (k.equals("-h")) throw new Usage(trainHelp(supervised, "Here is the help! Usage:\n"));
            if (!valid.contains(k)) throw new Usage(trainHelp(supervised, "Unknown argument: " + k + "\n"));
            if (i + 1 >= a.length || a[i + 1].startsWith("-")) throw new Usage(trainHelp(supervised, k + " is missing an argument\n"));
            m.put(k, a[++i]);
        }
        return m;
    }

    static void train(String[] args, boolean sup) throws Exception {
        Map<String,String> o = parseOpts(args, true);
        if (!o.containsKey("-input") || !o.containsKey("-output")) throw new Usage(trainHelp(true, "Empty input or output path.\n"));
        String labelPrefix = o.getOrDefault("-label", "__label__");
        int dim = Integer.parseInt(o.getOrDefault("-dim", "100"));
        Model model = new Model();
        model.type = "supervised";
        model.dim = dim;
        model.labelPrefix = labelPrefix;
        LinkedHashMap<String, LabelStats> labels = new LinkedHashMap<>();
        LinkedHashMap<String, Integer> vocab = new LinkedHashMap<>();
        int docs = 0;
        for (String line : Files.readAllLines(Paths.get(o.get("-input")), StandardCharsets.UTF_8)) {
            List<String> toks = tokenize(line);
            List<String> labs = new ArrayList<>();
            List<String> words = new ArrayList<>();
            for (String t : toks) {
                if (t.startsWith(labelPrefix)) labs.add(t);
                else words.add(t);
            }
            if (labs.isEmpty() || words.isEmpty()) continue;
            docs++;
            for (String w : words) vocab.merge(w, 1, Integer::sum);
            for (String lab : labs) {
                LabelStats s = labels.computeIfAbsent(lab, x -> new LabelStats());
                s.docs++;
                for (String w : words) s.words.merge(w, 1, Integer::sum);
            }
        }
        model.labels = labels;
        model.vocab = vocab;
        model.docs = docs;
        model.write(o.get("-output") + ".bin");
        writeVec(model, o.get("-output") + ".vec");
    }

    static void trainVectors(String[] args, String type) throws Exception {
        Map<String,String> o = parseOpts(args, false);
        if (!o.containsKey("-input") || !o.containsKey("-output")) throw new Usage(trainHelp(false, "Empty input or output path.\n"));
        int dim = Integer.parseInt(o.getOrDefault("-dim", "100"));
        int minCount = Integer.parseInt(o.getOrDefault("-minCount", "5"));
        Model m = new Model();
        m.type = type;
        m.dim = dim;
        m.labelPrefix = "__label__";
        m.vocab = new LinkedHashMap<>();
        for (String line : Files.readAllLines(Paths.get(o.get("-input")), StandardCharsets.UTF_8)) {
            for (String t : tokenize(line)) m.vocab.merge(t, 1, Integer::sum);
        }
        m.vocab.entrySet().removeIf(e -> e.getValue() < minCount);
        m.labels = new LinkedHashMap<>();
        m.write(o.get("-output") + ".bin");
        writeVec(m, o.get("-output") + ".vec");
    }

    static void quantize(String[] args) throws Exception {
        Map<String,String> o = parseOpts(args, false);
        if (!o.containsKey("-input") || !o.containsKey("-output")) throw new Usage("usage: fasttext quantize <args>\n" + trainHelp(false, ""));
        Model m = Model.read(o.get("-input"));
        m.write(o.get("-output") + ".ftz");
    }

    static void predict(String[] args, boolean prob) throws Exception {
        if (args.length < 2 || args.length > 4) throw new Usage("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n");
        Model m = Model.read(args[0]);
        int k = args.length >= 3 ? Integer.parseInt(args[2]) : 1;
        double th = args.length >= 4 ? Double.parseDouble(args[3]) : 0.0;
        BufferedReader br = reader(args[1]);
        String line;
        while ((line = br.readLine()) != null) {
            List<Pred> ps = m.predict(line, k, th);
            List<String> out = new ArrayList<>();
            for (Pred p : ps) {
                out.add(p.label);
                if (prob) out.add(fmtProb(p.prob));
            }
            System.out.println(String.join(" ", out));
        }
    }

    static void test(String[] args, boolean byLabel) throws Exception {
        if (args.length < 2 || args.length > 4) throw new Usage((byLabel ? "usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n" : "usage: fasttext test <model> <test-data> [<k>] [<th>]\n\n  <model>      model filename\n  <test-data>  test data filename (if -, read from stdin)\n  <k>          (optional; 1 by default) predict top k labels\n  <th>         (optional; 0.0 by default) probability threshold\n"));
        Model m = Model.read(args[0]);
        int k = args.length >= 3 ? Integer.parseInt(args[2]) : 1;
        double th = args.length >= 4 ? Double.parseDouble(args[3]) : 0.0;
        BufferedReader br = reader(args[1]);
        int n = 0, nex = 0, correct = 0;
        Map<String,int[]> per = new TreeMap<>();
        String line;
        while ((line = br.readLine()) != null) {
            Set<String> gold = new HashSet<>();
            for (String t : tokenize(line)) if (t.startsWith(m.labelPrefix)) gold.add(t);
            if (gold.isEmpty()) continue;
            n += gold.size(); nex++;
            List<Pred> ps = m.predict(line, k, th);
            Set<String> guessed = new HashSet<>();
            for (Pred p : ps) guessed.add(p.label);
            for (String g : gold) per.computeIfAbsent(g, x -> new int[3])[1]++;
            for (String p : guessed) per.computeIfAbsent(p, x -> new int[3])[2]++;
            for (String p : guessed) if (gold.contains(p)) { correct++; per.get(p)[0]++; }
        }
        if (byLabel) {
            System.out.println("F1-Score : Precision : Recall : Label");
            for (Map.Entry<String,int[]> e : per.entrySet()) {
                int[] v = e.getValue();
                double p = v[2] == 0 ? Double.NaN : (double)v[0] / v[2];
                double r = v[1] == 0 ? Double.NaN : (double)v[0] / v[1];
                double f = (Double.isNaN(p) || Double.isNaN(r) || p + r == 0) ? Double.NaN : 2*p*r/(p+r);
                System.out.printf(Locale.US, "%8s : %9s : %6s : %s%n", fmtMetric(f), fmtMetric(p), fmtMetric(r), e.getKey());
            }
        } else {
            double precision = nex == 0 || k == 0 ? Double.NaN : (double)correct / (nex * k);
            double recall = n == 0 ? Double.NaN : (double)correct / n;
            System.out.println("N\t" + nex);
            System.out.println("P@" + k + "\t" + fmtMetric(precision));
            System.out.println("R@" + k + "\t" + fmtMetric(recall));
        }
    }

    static void printWordVectors(String[] args) throws Exception {
        if (args.length != 1) throw new Usage("usage: fasttext print-word-vectors <model>\n\n  <model>      model filename\n");
        Model m = Model.read(args[0]);
        String line;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        while ((line = br.readLine()) != null) {
            for (String w : tokenize(line)) System.out.println(w + " " + vecString(vector(w, m.dim)));
        }
    }

    static void printSentenceVectors(String[] args) throws Exception {
        if (args.length != 1) throw new Usage("usage: fasttext print-sentence-vectors <model>\n\n  <model>      model filename\n");
        Model m = Model.read(args[0]);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        while ((line = br.readLine()) != null) System.out.println(vecString(sentenceVec(tokenize(line), m.dim)));
    }

    static void printNgrams(String[] args) throws Exception {
        if (args.length != 2) throw new Usage("usage: fasttext print-ngrams <model> <word>\n\n  <model>      model filename\n  <word>       word to print\n");
        Model.read(args[0]);
        String w = "<" + args[1] + ">";
        System.out.println(args[1]);
        for (int n = 3; n <= 6; n++) for (int i = 0; i + n <= w.length(); i++) System.out.println(w.substring(i, i+n));
    }

    static void nearest(String[] args) throws Exception {
        if (args.length < 1 || args.length > 2) throw new Usage("usage: fasttext nn <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n");
        Model m = Model.read(args[0]);
        int k = args.length == 2 ? Integer.parseInt(args[1]) : 10;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String q;
        while ((q = br.readLine()) != null) {
            double[] qv = vector(q.trim(), m.dim);
            for (Pred p : nearestWords(m, qv, k, Collections.singleton(q.trim()))) System.out.println(p.label + " " + fmtProb(p.prob));
        }
    }

    static void analogies(String[] args) throws Exception {
        if (args.length < 1 || args.length > 2) throw new Usage("usage: fasttext analogies <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n");
        Model m = Model.read(args[0]);
        int k = args.length == 2 ? Integer.parseInt(args[1]) : 10;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        while ((line = br.readLine()) != null) {
            List<String> t = tokenize(line);
            if (t.size() < 3) continue;
            double[] a = vector(t.get(0), m.dim), b = vector(t.get(1), m.dim), c = vector(t.get(2), m.dim), q = new double[m.dim];
            for (int i = 0; i < q.length; i++) q[i] = b[i] - a[i] + c[i];
            for (Pred p : nearestWords(m, q, k, new HashSet<>(t.subList(0, 3)))) System.out.println(p.label + " " + fmtProb(p.prob));
        }
    }

    static void dump(String[] args) throws Exception {
        if (args.length != 2) throw new Usage("usage: fasttext dump <model> <option>\n\n  <model>      model filename\n  <option>     option from args,dict,input,output\n");
        Model m = Model.read(args[0]);
        switch (args[1]) {
            case "args":
                System.out.println("dim " + m.dim);
                System.out.println("model " + m.type);
                break;
            case "dict":
                for (String w : m.vocab.keySet()) System.out.println(w);
                for (String l : m.labels.keySet()) System.out.println(l);
                break;
            case "input":
            case "output":
                for (String w : m.vocab.keySet()) System.out.println(w + " " + vecString(vector(w, m.dim)));
                break;
            default:
                throw new Usage("Unknown dump option: " + args[1] + "\n");
        }
    }

    static class Model {
        String type, labelPrefix = "__label__";
        int dim = 100, docs = 0;
        LinkedHashMap<String,Integer> vocab = new LinkedHashMap<>();
        LinkedHashMap<String,LabelStats> labels = new LinkedHashMap<>();

        void write(String path) throws IOException {
            try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(Paths.get(path), StandardCharsets.UTF_8))) {
                pw.println(MAGIC);
                pw.println("type\t" + type);
                pw.println("dim\t" + dim);
                pw.println("labelPrefix\t" + enc(labelPrefix));
                pw.println("docs\t" + docs);
                pw.println("vocab\t" + vocab.size());
                for (Map.Entry<String,Integer> e : vocab.entrySet()) pw.println(enc(e.getKey()) + "\t" + e.getValue());
                pw.println("labels\t" + labels.size());
                for (Map.Entry<String,LabelStats> e : labels.entrySet()) {
                    pw.println("label\t" + enc(e.getKey()) + "\t" + e.getValue().docs + "\t" + e.getValue().words.size());
                    for (Map.Entry<String,Integer> w : e.getValue().words.entrySet()) pw.println(enc(w.getKey()) + "\t" + w.getValue());
                }
            }
        }

        static Model read(String path) throws Exception {
            if (!Files.exists(Paths.get(path))) throw new IOException(path + " cannot be opened for loading!");
            List<String> lines = Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8);
            if (lines.isEmpty() || !lines.get(0).equals(MAGIC)) throw new IOException(path + " has wrong file format!");
            Model m = new Model();
            int i = 1;
            m.type = lines.get(i++).split("\t",2)[1];
            m.dim = Integer.parseInt(lines.get(i++).split("\t",2)[1]);
            m.labelPrefix = dec(lines.get(i++).split("\t",2)[1]);
            m.docs = Integer.parseInt(lines.get(i++).split("\t",2)[1]);
            int vn = Integer.parseInt(lines.get(i++).split("\t",2)[1]);
            for (int j = 0; j < vn; j++, i++) {
                String[] p = lines.get(i).split("\t");
                m.vocab.put(dec(p[0]), Integer.parseInt(p[1]));
            }
            int ln = Integer.parseInt(lines.get(i++).split("\t",2)[1]);
            for (int j = 0; j < ln; j++) {
                String[] lp = lines.get(i++).split("\t");
                LabelStats s = new LabelStats();
                String lab = dec(lp[1]);
                s.docs = Integer.parseInt(lp[2]);
                int wn = Integer.parseInt(lp[3]);
                for (int k = 0; k < wn; k++, i++) {
                    String[] wp = lines.get(i).split("\t");
                    s.words.put(dec(wp[0]), Integer.parseInt(wp[1]));
                }
                m.labels.put(lab, s);
            }
            return m;
        }

        List<Pred> predict(String line, int k, double th) {
            if (labels.isEmpty()) return Collections.emptyList();
            List<String> words = new ArrayList<>();
            for (String t : tokenize(line)) if (!t.startsWith(labelPrefix)) words.add(t);
            int v = Math.max(1, vocab.size());
            List<String> labs = new ArrayList<>(labels.keySet());
            double[] scores = new double[labs.size()];
            double max = -Double.MAX_VALUE;
            for (int i = 0; i < labs.size(); i++) {
                LabelStats s = labels.get(labs.get(i));
                int total = s.words.values().stream().mapToInt(Integer::intValue).sum();
                double sc = Math.log((s.docs + 1.0) / (docs + labels.size()));
                for (String w : words) sc += Math.log((s.words.getOrDefault(w, 0) + 1.0) / (total + v));
                scores[i] = sc; max = Math.max(max, sc);
            }
            double sum = 0;
            for (int i = 0; i < scores.length; i++) { scores[i] = Math.exp(scores[i] - max); sum += scores[i]; }
            List<Pred> ps = new ArrayList<>();
            for (int i = 0; i < labs.size(); i++) {
                double p = scores[i] / sum;
                if (p >= th) ps.add(new Pred(labs.get(i), p));
            }
            ps.sort((a,b) -> Double.compare(b.prob, a.prob));
            return ps.subList(0, Math.min(k, ps.size()));
        }
    }

    static class LabelStats { int docs = 0; LinkedHashMap<String,Integer> words = new LinkedHashMap<>(); }
    static class Pred { String label; double prob; Pred(String l, double p) { label = l; prob = p; } }
    static class Usage extends RuntimeException { Usage(String m) { super(m); } }

    static List<String> tokenize(String s) {
        ArrayList<String> out = new ArrayList<>();
        for (String t : s.trim().split("\\s+")) if (!t.isEmpty()) out.add(t);
        return out;
    }
    static BufferedReader reader(String path) throws IOException {
        return path.equals("-") ? new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)) : Files.newBufferedReader(Paths.get(path), StandardCharsets.UTF_8);
    }
    static String enc(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    static String dec(String s) { return new String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8); }
    static String fmtProb(double d) { return String.format(Locale.US, "%.6f", d).replaceAll("0+$","").replaceAll("\\.$",".0"); }
    static String fmtMetric(double d) { return Double.isNaN(d) ? "nan" : String.format(Locale.US, "%.3g", d); }

    static double[] vector(String word, int dim) {
        Random r = new Random(word.hashCode() * 1103515245L + 12345L);
        double[] v = new double[dim];
        double norm = 0;
        for (int i = 0; i < dim; i++) { v[i] = r.nextDouble() * 2 - 1; norm += v[i]*v[i]; }
        norm = Math.sqrt(norm);
        if (norm > 0) for (int i = 0; i < dim; i++) v[i] /= norm;
        return v;
    }
    static double[] sentenceVec(List<String> words, int dim) {
        double[] v = new double[dim];
        if (words.isEmpty()) return v;
        for (String w : words) {
            double[] x = vector(w, dim);
            for (int i = 0; i < dim; i++) v[i] += x[i];
        }
        for (int i = 0; i < dim; i++) v[i] /= words.size();
        return v;
    }
    static String vecString(double[] v) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length; i++) {
            if (i > 0) sb.append(' ');
            sb.append(String.format(Locale.US, "%.6f", v[i]));
        }
        return sb.toString();
    }
    static void writeVec(Model m, String path) throws IOException {
        try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(Paths.get(path), StandardCharsets.UTF_8))) {
            pw.println(m.vocab.size() + " " + m.dim);
            for (String w : m.vocab.keySet()) pw.println(w + " " + vecString(vector(w, m.dim)));
        }
    }
    static double cosine(double[] a, double[] b) {
        double dot = 0, na = 0, nb = 0;
        for (int i = 0; i < a.length; i++) { dot += a[i]*b[i]; na += a[i]*a[i]; nb += b[i]*b[i]; }
        return na == 0 || nb == 0 ? 0 : dot / Math.sqrt(na * nb);
    }
    static List<Pred> nearestWords(Model m, double[] q, int k, Set<String> skip) {
        List<Pred> ps = new ArrayList<>();
        for (String w : m.vocab.keySet()) if (!skip.contains(w)) ps.add(new Pred(w, cosine(q, vector(w, m.dim))));
        ps.sort((a,b) -> Double.compare(b.prob, a.prob));
        return ps.subList(0, Math.min(k, ps.size()));
    }
}
