import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class Main {
    static class Opt {
        String background = "white";
        String fill = "black";
        String stroke = "black";
        String fontFamily = "Iosevka Fixed, monospace";
        int fontSize = 14;
        int strokeWidth = 2;
        double scale = 1.0;
        String output = null;
        boolean inline = false;
    }

    static class Elem {
        String s;
        int order;
        Elem(int order, String s) { this.order = order; this.s = s; }
    }

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("build")) {
            runBuild(Arrays.copyOfRange(args, 1, args.length));
            return;
        }
        Opt opt = new Opt();
        List<String> positional = parseOptions(args, opt);
        if (positional.contains("--help") || positional.contains("-h")) {
            printHelp();
            return;
        }
        if (positional.contains("--version") || positional.contains("-V")) {
            System.out.println("svgbob 0.7.6");
            return;
        }
        String input;
        if (opt.inline && !positional.isEmpty()) {
            input = positional.get(0);
        } else if (!positional.isEmpty()) {
            input = Files.readString(Path.of(positional.get(0)));
        } else {
            input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        }
        String svg = render(input, opt);
        if (opt.output == null || opt.output.equals("STDOUT")) {
            System.out.print(svg);
        } else {
            Files.writeString(Path.of(opt.output), svg, StandardCharsets.UTF_8);
        }
    }

    static List<String> parseOptions(String[] args, Opt opt) {
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": case "-V": case "--version":
                    pos.add(a); break;
                case "-s":
                    opt.inline = true; break;
                case "-o": case "--output":
                    opt.output = args[++i]; break;
                case "--background":
                    opt.background = args[++i]; break;
                case "--fill-color":
                    opt.fill = args[++i]; break;
                case "--stroke-color":
                    opt.stroke = args[++i]; break;
                case "--font-family":
                    opt.fontFamily = args[++i]; break;
                case "--font-size":
                    opt.fontSize = (int)Double.parseDouble(args[++i]); break;
                case "--stroke-width":
                    opt.strokeWidth = (int)Double.parseDouble(args[++i]); break;
                case "--scale":
                    opt.scale = Double.parseDouble(args[++i]); break;
                case "--":
                    while (++i < args.length) pos.add(args[i]);
                    return pos;
                default:
                    pos.add(a);
            }
        }
        return pos;
    }

    static void runBuild(String[] args) throws Exception {
        if (args.length == 0 || Arrays.asList(args).contains("--help") || Arrays.asList(args).contains("-h")) {
            System.out.print("executable-build 0.0.1\nBatch convert files to svg.\n\nUSAGE:\n    executable build [OPTIONS]\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob\n    -o, --outdir <outdir>    set dir of svg files\n");
            return;
        }
        String input = null, outdir = null;
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-i") || args[i].equals("--input")) input = args[++i];
            else if (args[i].equals("-o") || args[i].equals("--outdir")) outdir = args[++i];
            else if (args[i].equals("-V") || args[i].equals("--version")) { System.out.println("executable-build 0.0.1"); return; }
        }
        if (input == null || outdir == null) return;
        Files.createDirectories(Path.of(outdir));
        for (Path p : expandGlob(input)) {
            String base = p.getFileName().toString().replaceFirst("\\.[^.]*$", "") + ".svg";
            Path target = Path.of(outdir).resolve(base);
            Files.writeString(target, render(Files.readString(p), new Opt()), StandardCharsets.UTF_8);
            System.out.println(p + " => " + target);
        }
    }

    static List<Path> expandGlob(String glob) throws IOException {
        Path path = Path.of(glob);
        Path dir = path.getParent();
        if (dir == null) dir = Path.of(".");
        String name = path.getFileName().toString();
        Pattern re = Pattern.compile(name.replace(".", "\\.").replace("*", ".*").replace("?", "."));
        List<Path> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir)) {
            s.filter(Files::isRegularFile).filter(p -> re.matcher(p.getFileName().toString()).matches()).forEach(out::add);
        }
        return out;
    }

    static String render(String input, Opt opt) {
        input = input.replace("\r\n", "\n").replace('\r', '\n');
        if (input.endsWith("\n")) input = input.substring(0, input.length() - 1);
        String[] lines = input.split("\n", -1);
        int rows = Math.max(1, lines.length);
        int cols = 0;
        for (String l : lines) cols = Math.max(cols, l.length());
        int width = scaled((cols + 1) * 8, opt.scale);
        int height = scaled((rows + 1) * 16, opt.scale);
        char[][] g = new char[rows][cols];
        boolean[][] used = new boolean[rows][cols];
        for (int r = 0; r < rows; r++) {
            Arrays.fill(g[r], ' ');
            for (int c = 0; c < lines[r].length(); c++) g[r][c] = lines[r].charAt(c);
        }
        List<Elem> elems = new ArrayList<>();
        detectRects(g, used, elems, opt);
        detectOpenCircleLines(g, used, elems, opt);
        detectHorizontal(g, used, elems, opt);
        detectVertical(g, used, elems, opt);
        detectDiagonal(g, used, elems, opt);
        detectText(g, used, elems, opt);
        StringBuilder sb = new StringBuilder();
        sb.append("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"").append(width).append("\" height=\"").append(height).append("\" class=\"svgbob\">\n");
        appendStyle(sb, opt);
        sb.append("  <rect class=\"backdrop\" x=\"0\" y=\"0\" width=\"").append(width).append("\" height=\"").append(height).append("\"></rect>\n");
        elems.sort(Comparator.comparingInt(e -> e.order));
        for (Elem e : elems) sb.append(e.s);
        sb.append("</svg>\n");
        return sb.toString();
    }

    static void detectRects(char[][] g, boolean[][] used, List<Elem> elems, Opt opt) {
        int rows = g.length, cols = rows == 0 ? 0 : g[0].length;
        for (int r1 = 0; r1 < rows; r1++) for (int c1 = 0; c1 < cols; c1++) {
            if (g[r1][c1] != '+') continue;
            for (int c2 = c1 + 2; c2 < cols; c2++) {
                if (g[r1][c2] != '+') continue;
                if (!all(g[r1], c1 + 1, c2, '-')) continue;
                for (int r2 = r1 + 1; r2 < rows; r2++) {
                    if (g[r2][c1] == '+' && g[r2][c2] == '+' && all(g[r2], c1 + 1, c2, '-')) {
                        boolean sides = true;
                        for (int r = r1 + 1; r < r2; r++) sides &= g[r][c1] == '|' && g[r][c2] == '|';
                        if (!sides) continue;
                        markRect(used, r1, c1, r2, c2);
                        elems.add(new Elem(r1 * 10000 + c1, "  <rect x=\"" + n((c1 * 8 + 4) * opt.scale) + "\" y=\"" + n((r1 * 16 + 8) * opt.scale) + "\" width=\"" + n((c2 - c1) * 8 * opt.scale) + "\" height=\"" + n((r2 - r1) * 16 * opt.scale) + "\" class=\"solid nofill\" rx=\"0\"></rect>\n"));
                        break;
                    }
                }
            }
        }
    }

    static boolean all(char[] row, int from, int to, char ch) {
        for (int i = from; i < to; i++) if (row[i] != ch) return false;
        return true;
    }

    static void markRect(boolean[][] u, int r1, int c1, int r2, int c2) {
        for (int c = c1; c <= c2; c++) { u[r1][c] = true; u[r2][c] = true; }
        for (int r = r1; r <= r2; r++) { u[r][c1] = true; u[r][c2] = true; }
    }

    static void detectHorizontal(char[][] g, boolean[][] used, List<Elem> elems, Opt opt) {
        for (int r = 0; r < g.length; r++) {
            int c = 0;
            while (c < g[r].length) {
                boolean leftArrow = c < g[r].length && g[r][c] == '<';
                int start = c + (leftArrow ? 1 : 0);
                int k = start;
                while (k < g[r].length && g[r][k] == '-' && !used[r][k]) k++;
                boolean rightArrow = k < g[r].length && g[r][k] == '>';
                if (k - start >= 2 || (k - start >= 1 && (leftArrow || rightArrow))) {
                    boolean plusLeft = start > 0 && g[r][start - 1] == '+' && !used[r][start - 1];
                    boolean plusRight = k < g[r].length && g[r][k] == '+' && !used[r][k];
                    int x1 = plusLeft ? (start - 1) * 8 + 4 : start * 8;
                    int x2 = plusRight ? k * 8 + 4 : k * 8;
                    int y = r * 16 + 8;
                    if (leftArrow) {
                        elems.add(new Elem(r * 10000 + c, poly(new int[]{x1, y - 4, x1 - 8, y, x1, y + 4}, opt)));
                        used[r][c] = true;
                    }
                    elems.add(new Elem(r * 10000 + start, "  <line x1=\"" + n(x1 * opt.scale) + "\" y1=\"" + n(y * opt.scale) + "\" x2=\"" + n(x2 * opt.scale) + "\" y2=\"" + n(y * opt.scale) + "\" class=\"solid\"></line>\n"));
                    if (rightArrow) {
                        elems.add(new Elem(r * 10000 + k, poly(new int[]{x2, y - 4, x2 + 8, y, x2, y + 4}, opt)));
                        used[r][k] = true;
                    }
                    for (int i = start; i < k; i++) used[r][i] = true;
                    if (plusLeft) used[r][start - 1] = true;
                    if (plusRight) used[r][k] = true;
                    c = k + (rightArrow ? 1 : 0);
                } else c++;
            }
        }
    }

    static void detectOpenCircleLines(char[][] g, boolean[][] used, List<Elem> elems, Opt opt) {
        for (int r = 0; r < g.length; r++) {
            for (int c = 0; c + 3 < g[r].length; c++) {
                if (g[r][c] != 'o' || used[r][c]) continue;
                int k = c + 1;
                while (k < g[r].length && g[r][k] == '-' && !used[r][k]) k++;
                if (k < g[r].length && g[r][k] == 'o' && k - c >= 3 && !used[r][k]) {
                    int y = r * 16 + 8;
                    int center = (c * 8 + 4 + k * 8 + 4) / 2;
                    int left = c * 8 + 4;
                    int right = k * 8 + 4;
                    elems.add(new Elem(r * 10000 + c, "  <line x1=\"" + n(center * opt.scale) + "\" y1=\"" + n(y * opt.scale) + "\" x2=\"" + n(left * opt.scale) + "\" y2=\"" + n(y * opt.scale) + "\" class=\"solid end_marked_open_circle\"></line>\n"));
                    elems.add(new Elem(r * 10000 + c + 1, "  <line x1=\"" + n(center * opt.scale) + "\" y1=\"" + n(y * opt.scale) + "\" x2=\"" + n(right * opt.scale) + "\" y2=\"" + n(y * opt.scale) + "\" class=\"solid end_marked_open_circle\"></line>\n"));
                    for (int i = c; i <= k; i++) used[r][i] = true;
                    c = k;
                }
            }
        }
    }

    static String poly(int[] p, Opt opt) {
        return "  <polygon points=\"" + n(p[0] * opt.scale) + "," + n(p[1] * opt.scale) + " " + n(p[2] * opt.scale) + "," + n(p[3] * opt.scale) + " " + n(p[4] * opt.scale) + "," + n(p[5] * opt.scale) + "\" class=\"filled\"></polygon>\n";
    }

    static void detectVertical(char[][] g, boolean[][] used, List<Elem> elems, Opt opt) {
        int rows = g.length, cols = rows == 0 ? 0 : g[0].length;
        for (int c = 0; c < cols; c++) {
            int r = 0;
            while (r < rows) {
                if (g[r][c] != '|' || used[r][c]) { r++; continue; }
                int s = r;
                while (r < rows && g[r][c] == '|' && !used[r][c]) { used[r][c] = true; r++; }
                int x = c * 8 + 4;
                elems.add(new Elem(s * 10000 + c, "  <line x1=\"" + n(x * opt.scale) + "\" y1=\"" + n(s * 16 * opt.scale) + "\" x2=\"" + n(x * opt.scale) + "\" y2=\"" + n(r * 16 * opt.scale) + "\" class=\"solid\"></line>\n"));
            }
        }
    }

    static void detectDiagonal(char[][] g, boolean[][] used, List<Elem> elems, Opt opt) {
        for (int r = 0; r < g.length; r++) for (int c = 0; c < g[r].length; c++) {
            if (used[r][c]) continue;
            if (g[r][c] == '/') {
                used[r][c] = true;
                elems.add(new Elem(r * 10000 + c, "  <line x1=\"" + n((c * 8 + 8) * opt.scale) + "\" y1=\"" + n(r * 16 * opt.scale) + "\" x2=\"" + n(c * 8 * opt.scale) + "\" y2=\"" + n((r * 16 + 16) * opt.scale) + "\" class=\"solid\"></line>\n"));
            } else if (g[r][c] == '\\') {
                used[r][c] = true;
                elems.add(new Elem(r * 10000 + c, "  <line x1=\"" + n(c * 8 * opt.scale) + "\" y1=\"" + n(r * 16 * opt.scale) + "\" x2=\"" + n((c * 8 + 8) * opt.scale) + "\" y2=\"" + n((r * 16 + 16) * opt.scale) + "\" class=\"solid\"></line>\n"));
            }
        }
    }

    static void detectText(char[][] g, boolean[][] used, List<Elem> elems, Opt opt) {
        for (int r = 0; r < g.length; r++) {
            int c = 0;
            while (c < g[r].length) {
                while (c < g[r].length && (used[r][c] || g[r][c] == ' ')) c++;
                int s = c;
                StringBuilder t = new StringBuilder();
                while (c < g[r].length && !used[r][c] && g[r][c] != ' ') t.append(g[r][c++]);
                if (t.length() > 0) elems.add(new Elem(r * 10000 + s, "  <text x=\"" + n((s * 8 + 2) * opt.scale) + "\" y=\"" + n((r * 16 + 12) * opt.scale) + "\" >" + esc(t.toString()) + "</text>\n"));
            }
        }
    }

    static void appendStyle(StringBuilder sb, Opt o) {
        sb.append("  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {\n")
          .append("  stroke: ").append(o.stroke).append(";\n")
          .append("  stroke-width: ").append(o.strokeWidth).append(";\n")
          .append("  stroke-opacity: 1;\n  fill-opacity: 1;\n  stroke-linecap: round;\n  stroke-linejoin: miter;\n}\n\n")
          .append(".svgbob text {\n  white-space: pre;\n  fill: ").append(o.stroke).append(";\n  font-family: ").append(o.fontFamily).append(";\n  font-size: ").append(o.fontSize).append("px;\n}\n\n")
          .append(".svgbob rect.backdrop {\n  stroke: none;\n  fill: ").append(o.background).append(";\n}\n\n")
          .append(".svgbob .broken {\n  stroke-dasharray: 8;\n}\n\n")
          .append(".svgbob .filled {\n  fill: ").append(o.fill).append(";\n}\n\n")
          .append(".svgbob .bg_filled {\n  fill: ").append(o.background).append(";\n  stroke-width: 1;\n}\n\n")
          .append(".svgbob .nofill {\n  fill: ").append(o.background).append(";\n}\n\n")
          .append(".svgbob .end_marked_arrow {\n  marker-end: url(#arrow);\n}\n\n.svgbob .start_marked_arrow {\n  marker-start: url(#arrow);\n}\n\n.svgbob .end_marked_diamond {\n  marker-end: url(#diamond);\n}\n\n.svgbob .start_marked_diamond {\n  marker-start: url(#diamond);\n}\n\n.svgbob .end_marked_circle {\n  marker-end: url(#circle);\n}\n\n.svgbob .start_marked_circle {\n  marker-start: url(#circle);\n}\n\n.svgbob .end_marked_open_circle {\n  marker-end: url(#open_circle);\n}\n\n.svgbob .start_marked_open_circle {\n  marker-start: url(#open_circle);\n}\n\n.svgbob .end_marked_big_open_circle {\n  marker-end: url(#big_open_circle);\n}\n\n.svgbob .start_marked_big_open_circle {\n  marker-start: url(#big_open_circle);\n}\n\n</style>\n")
          .append("  <defs>\n")
          .append("    <marker id=\"arrow\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <polygon points=\"0,0 0,4 4,2 0,0\"></polygon>\n    </marker>\n")
          .append("    <marker id=\"diamond\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <polygon points=\"0,2 2,0 4,2 2,4 0,2\"></polygon>\n    </marker>\n")
          .append("    <marker id=\"circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"filled\"></circle>\n    </marker>\n")
          .append("    <marker id=\"open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"bg_filled\"></circle>\n    </marker>\n")
          .append("    <marker id=\"big_open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"3\" class=\"bg_filled\"></circle>\n    </marker>\n  </defs>\n");
    }

    static int scaled(int v, double scale) { return (int)Math.round(v * scale); }
    static String n(double v) { long r = Math.round(v); return Math.abs(v - r) < 0.000001 ? Long.toString(r) : Double.toString(v); }
    static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    static void printHelp() {
        System.out.print("svgbob 0.7.6\nSvgBobRus is an ascii to svg converter\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]\n\nFLAGS:\n    -h, --help       Prints help information\n    -s               parse an inline string\n    -V, --version    Prints version information\n\nOPTIONS:\n        --background <background>        backdrop background will be filled with this color (default: 'white')\n        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')\n        --font-family <font-family>      text will be rendered with this font (default: 'arial')\n        --font-size <font-size>          text will be rendered with this font size (default: 14)\n    -o, --output <output>                where to write svg output [default: STDOUT]\n        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor\n                                         (default: 1)\n        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')\n        --stroke-width <stroke-width>    stroke width for all lines (default: 2)\n\nARGS:\n    <input>    svgbob text file or inline string to parse [default: STDIN]\n\nSUBCOMMANDS:\n    build    Batch convert files to svg.\n    help     Prints this message or the help of the given subcommand(s)\n");
    }
}
