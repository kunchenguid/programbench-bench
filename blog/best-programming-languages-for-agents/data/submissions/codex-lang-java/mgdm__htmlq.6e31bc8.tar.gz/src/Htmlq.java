import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Htmlq {
    static final Set<String> VOID = new HashSet<>(Arrays.asList("area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"));

    static class Node {
        String tag, text;
        Map<String,String> attrs = new TreeMap<>();
        List<Node> kids = new ArrayList<>();
        Node parent;
        Node(String tag) { this.tag = tag; }
        static Node text(String s) { Node n = new Node(null); n.text = s; return n; }
        boolean isText() { return tag == null; }
        void add(Node n) { n.parent = this; kids.add(n); }
    }

    static class Opt {
        boolean text, pretty, help, version, ignoreWs, detectBase;
        String attr, file, out, base;
        List<String> removes = new ArrayList<>(), selectors = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o.help) { System.out.print(help()); return; }
            if (o.version) { System.out.println("htmlq 0.4.0"); return; }
            String html = readAll(o.file);
            Node doc = parseHtml(html);
            String base = o.base;
            if (o.detectBase) {
                List<Node> bases = select(doc, "base");
                if (!bases.isEmpty() && bases.get(0).attrs.containsKey("href")) base = bases.get(0).attrs.get("href");
            }
            for (String r : o.removes) for (Node n : new ArrayList<>(select(doc, r))) remove(n);
            String selector = o.selectors.isEmpty() ? "html" : String.join(" ", o.selectors);
            List<Node> nodes = select(doc, selector);
            StringBuilder sb = new StringBuilder();
            if (o.text) {
                for (Node n : nodes) {
                    if (o.ignoreWs) {
                        for (String t : textPieces(n)) if (!t.trim().isEmpty()) sb.append(t).append('\n');
                    } else {
                        sb.append(textOf(n));
                    }
                }
                if (!o.ignoreWs && sb.length() > 0) sb.append('\n');
            } else if (o.attr != null) {
                for (Node n : nodes) if (!n.isText() && n.attrs.containsKey(o.attr)) {
                    String v = n.attrs.get(o.attr);
                    if (base != null && (o.attr.equals("href") || o.attr.equals("src"))) v = resolve(base, v);
                    sb.append(v).append('\n');
                }
            } else {
                for (Node n : nodes) {
                    if (o.pretty) serializePretty(n, sb, 0);
                    else serialize(n, sb);
                    sb.append('\n');
                }
            }
            if (o.out != null) Files.write(Paths.get(o.out), sb.toString().getBytes(StandardCharsets.UTF_8));
            else System.out.print(sb.toString());
        } catch (CliError e) {
            System.err.println(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class CliError extends Exception { CliError(String s) { super(s); } }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt(); boolean rest = false;
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            if (rest) { o.selectors.add(a); continue; }
            if (a.equals("--")) { rest = true; continue; }
            if (a.equals("-h") || a.equals("--help")) o.help = true;
            else if (a.equals("-V") || a.equals("--version")) o.version = true;
            else if (a.equals("-t") || a.equals("--text")) o.text = true;
            else if (a.equals("-p") || a.equals("--pretty")) o.pretty = true;
            else if (a.equals("-w") || a.equals("--ignore-whitespace")) o.ignoreWs = true;
            else if (a.equals("-B") || a.equals("--detect-base")) o.detectBase = true;
            else if (a.equals("-a") || a.equals("--attribute")) o.attr = need(args, ++i, a);
            else if (a.startsWith("--attribute=")) o.attr = a.substring(12);
            else if (a.equals("-b") || a.equals("--base")) o.base = need(args, ++i, a);
            else if (a.startsWith("--base=")) o.base = a.substring(7);
            else if (a.equals("-f") || a.equals("--filename")) o.file = need(args, ++i, a);
            else if (a.startsWith("--filename=")) o.file = a.substring(11);
            else if (a.equals("-o") || a.equals("--output")) o.out = need(args, ++i, a);
            else if (a.startsWith("--output=")) o.out = a.substring(9);
            else if (a.equals("-r") || a.equals("--remove-nodes")) {
                o.removes.add(need(args, ++i, a));
                while (i + 1 < args.length && !args[i + 1].startsWith("-")) o.removes.add(args[++i]);
            }
            else if (a.startsWith("--remove-nodes=")) o.removes.add(a.substring(15));
            else if (a.startsWith("-") && a.length() > 2 && !a.startsWith("--")) {
                for (int j=1;j<a.length();j++) {
                    char c = a.charAt(j);
                    if (c=='t') o.text = true; else if (c=='p') o.pretty = true; else if (c=='w') o.ignoreWs = true; else if (c=='B') o.detectBase = true;
                    else if (c=='h') o.help = true; else if (c=='V') o.version = true;
                    else throw new CliError("error: Found argument '" + a + "' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFor more information try --help");
                }
            } else if (a.startsWith("-")) throw new CliError("error: Found argument '" + a + "' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFor more information try --help");
            else o.selectors.add(a);
        }
        return o;
    }
    static String need(String[] a, int i, String opt) throws CliError { if (i >= a.length) throw new CliError("error: The argument '" + opt + "' requires a value"); return a[i]; }

    static String readAll(String file) throws IOException {
        InputStream in = file == null ? System.in : new FileInputStream(file);
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) >= 0) b.write(buf,0,n);
        if (file != null) in.close();
        return b.toString(StandardCharsets.UTF_8);
    }

    static Node parseHtml(String s) {
        Node root = new Node("#document"), html = new Node("html"), head = new Node("head"), body = new Node("body");
        root.add(html); html.add(head); html.add(body);
        Deque<Node> stack = new ArrayDeque<>(); stack.push(body);
        int i=0; boolean seenBody=false, inHead=false;
        while (i < s.length()) {
            int lt = s.indexOf('<', i);
            if (lt < 0) { addText(stack.peek(), s.substring(i)); break; }
            addText(stack.peek(), s.substring(i, lt));
            if (s.startsWith("<!--", lt)) { int e=s.indexOf("-->", lt+4); i=e<0?s.length():e+3; continue; }
            if (s.startsWith("<!", lt)) { int e=s.indexOf('>', lt+2); i=e<0?s.length():e+1; continue; }
            int gt = findGt(s, lt+1); if (gt < 0) break;
            String inside = s.substring(lt+1, gt).trim();
            if (inside.isEmpty()) { i=gt+1; continue; }
            if (inside.startsWith("/")) {
                String name = nameOf(inside.substring(1)).toLowerCase(Locale.ROOT);
                if (name.equals("head")) {
                    stack.clear(); stack.push(body); inHead = false; i = gt + 1; continue;
                }
                if (name.equals("body")) {
                    stack.clear(); stack.push(body); seenBody = true; inHead = false; i = gt + 1; continue;
                }
                while (stack.size()>1 && !stack.peek().tag.equals(name)) stack.pop();
                if (stack.size()>1) stack.pop();
            } else {
                boolean self = inside.endsWith("/");
                if (self) inside = inside.substring(0, inside.length()-1).trim();
                String name = nameOf(inside).toLowerCase(Locale.ROOT);
                if (name.equals("html")) { stack.clear(); stack.push(html); i=gt+1; continue; }
                if (name.equals("head")) { stack.clear(); stack.push(head); inHead=true; i=gt+1; continue; }
                if (name.equals("body")) { stack.clear(); stack.push(body); seenBody=true; inHead=false; i=gt+1; continue; }
                Node n = new Node(name); n.attrs.putAll(attrsOf(inside.substring(Math.min(name.length(), inside.length()))));
                Node parent = (inHead || name.equals("title") || name.equals("base") || name.equals("meta") || name.equals("link")) && !seenBody ? head : stack.peek();
                parent.add(n);
                if (!self && !VOID.contains(name)) {
                    stack.push(n);
                    if (name.equals("script") || name.equals("style")) {
                        String close = "</" + name;
                        int c = lower(s).indexOf(close, gt+1);
                        if (c >= 0) { addText(n, s.substring(gt+1, c)); int e=s.indexOf('>', c); i=e<0?s.length():e+1; stack.pop(); continue; }
                    }
                }
            }
            i=gt+1;
        }
        return root;
    }
    static String lower(String s) { return s.toLowerCase(Locale.ROOT); }
    static int findGt(String s, int p) { boolean q=false; char qc=0; for(int i=p;i<s.length();i++){char c=s.charAt(i); if(q){ if(c==qc)q=false; } else if(c=='"'||c=='\''){q=true;qc=c;} else if(c=='>')return i;} return -1; }
    static String nameOf(String s) { Matcher m=Pattern.compile("^\\s*([A-Za-z0-9:_-]+)").matcher(s); return m.find()?m.group(1):""; }
    static void addText(Node p, String t) { if (!t.isEmpty()) p.add(Node.text(decode(t))); }
    static Map<String,String> attrsOf(String s) {
        Map<String,String> m = new TreeMap<>(); int i=0;
        while (i<s.length()) {
            while (i<s.length() && Character.isWhitespace(s.charAt(i))) i++;
            int st=i; while (i<s.length() && !Character.isWhitespace(s.charAt(i)) && s.charAt(i)!='=') i++;
            if (st==i) break; String k=s.substring(st,i).toLowerCase(Locale.ROOT);
            while (i<s.length() && Character.isWhitespace(s.charAt(i))) i++;
            String v="";
            if (i<s.length() && s.charAt(i)=='=') {
                i++; while (i<s.length() && Character.isWhitespace(s.charAt(i))) i++;
                if (i<s.length() && (s.charAt(i)=='"' || s.charAt(i)=='\'')) { char q=s.charAt(i++); int stv=i; while(i<s.length()&&s.charAt(i)!=q)i++; v=s.substring(stv, Math.min(i,s.length())); if(i<s.length())i++; }
                else { int stv=i; while(i<s.length()&&!Character.isWhitespace(s.charAt(i)))i++; v=s.substring(stv,i); }
            }
            m.put(k, decode(v));
        }
        return m;
    }

    static List<Node> select(Node doc, String selector) {
        LinkedHashSet<Node> out = new LinkedHashSet<>();
        for (String group : splitTop(selector, ',')) {
            List<Token> toks = tokenize(group.trim()); if (toks.isEmpty()) continue;
            for (Node n : elements(doc)) if (matchesChain(n, toks, toks.size()-1)) out.add(n);
        }
        return new ArrayList<>(out);
    }
    static class Token { String comb=" "; Simple s; }
    static List<Token> tokenize(String sel) {
        List<String> parts = new ArrayList<>(); List<String> combs = new ArrayList<>(); StringBuilder b=new StringBuilder(); int br=0, par=0; char quote=0; String next=" ";
        for(int i=0;i<sel.length();i++){ char c=sel.charAt(i);
            if(quote!=0){b.append(c); if(c==quote)quote=0; continue;}
            if(c=='"'||c=='\''){quote=c; b.append(c); continue;} if(c=='[')br++; else if(c==']')br--; else if(c=='(')par++; else if(c==')')par--;
            if(br==0&&par==0&&(c=='>'||c=='+')){ if(b.toString().trim().length()>0){parts.add(b.toString().trim()); combs.add(next);} b.setLength(0); next=String.valueOf(c); while(i+1<sel.length()&&Character.isWhitespace(sel.charAt(i+1)))i++; }
            else if(br==0&&par==0&&Character.isWhitespace(c)){ if(b.toString().trim().length()>0){parts.add(b.toString().trim()); combs.add(next); b.setLength(0); next=" ";} while(i+1<sel.length()&&Character.isWhitespace(sel.charAt(i+1)))i++; }
            else b.append(c);
        }
        if(b.toString().trim().length()>0){parts.add(b.toString().trim()); combs.add(next);}
        List<Token> r=new ArrayList<>(); for(int i=0;i<parts.size();i++){Token t=new Token(); t.comb=combs.get(i); t.s=parseSimple(parts.get(i)); r.add(t);} return r;
    }
    static class Simple { String tag="*"; String id; List<String> classes=new ArrayList<>(); Map<String,String> attrs=new LinkedHashMap<>(); Set<String> exists=new HashSet<>(); String pseudo; int nth=-1; }
    static Simple parseSimple(String p) {
        Simple s=new Simple(); int i=0; Matcher tm=Pattern.compile("^([A-Za-z][A-Za-z0-9_-]*|\\*)").matcher(p); if(tm.find()){s.tag=tm.group(1).toLowerCase(Locale.ROOT); i=tm.end();}
        while(i<p.length()){ char c=p.charAt(i);
            if(c=='#'){int j=i+1; while(j<p.length()&&isName(p.charAt(j)))j++; s.id=p.substring(i+1,j); i=j;}
            else if(c=='.'){int j=i+1; while(j<p.length()&&isName(p.charAt(j)))j++; s.classes.add(p.substring(i+1,j)); i=j;}
            else if(c=='['){int j=p.indexOf(']',i); if(j<0)break; String a=p.substring(i+1,j).trim(); int eq=a.indexOf('='); if(eq>=0){String k=a.substring(0,eq).trim().toLowerCase(Locale.ROOT); String v=strip(a.substring(eq+1).trim()); s.attrs.put(k, decode(v));} else s.exists.add(a.toLowerCase(Locale.ROOT)); i=j+1;}
            else if(c==':'){ if(p.startsWith(":first-child",i)){s.pseudo="first"; i+=12;} else if(p.startsWith(":last-child",i)){s.pseudo="last"; i+=11;} else {Matcher m=Pattern.compile(":nth-child\\((\\d+)\\)").matcher(p.substring(i)); if(m.find()&&m.start()==0){s.pseudo="nth"; s.nth=Integer.parseInt(m.group(1)); i+=m.end();} else i=p.length();}}
            else i++;
        }
        return s;
    }
    static boolean isName(char c){return Character.isLetterOrDigit(c)||c=='_'||c=='-';}
    static String strip(String v){ if(v.length()>=2&&((v.charAt(0)=='"'&&v.charAt(v.length()-1)=='"')||(v.charAt(0)=='\''&&v.charAt(v.length()-1)=='\'')))return v.substring(1,v.length()-1); return v; }
    static boolean matchesChain(Node n, List<Token> t, int idx) {
        if (!matchSimple(n, t.get(idx).s)) return false; if (idx==0) return true;
        String c = t.get(idx).comb;
        if (c.equals(">")) return n.parent!=null && matchesChain(n.parent,t,idx-1);
        if (c.equals("+")) { Node p=prevElement(n); return p!=null && matchesChain(p,t,idx-1); }
        for (Node p=n.parent; p!=null; p=p.parent) if (matchesChain(p,t,idx-1)) return true;
        return false;
    }
    static boolean matchSimple(Node n, Simple s) {
        if (n.isText() || n.tag.startsWith("#")) return false;
        if (!s.tag.equals("*") && !n.tag.equals(s.tag)) return false;
        if (s.id!=null && !s.id.equals(n.attrs.get("id"))) return false;
        String cls=" "+n.attrs.getOrDefault("class","")+" "; for(String c:s.classes) if(!cls.contains(" "+c+" ")) return false;
        for(String k:s.exists) if(!n.attrs.containsKey(k)) return false;
        for(Map.Entry<String,String> e:s.attrs.entrySet()) if(!e.getValue().equals(n.attrs.get(e.getKey()))) return false;
        if ("first".equals(s.pseudo) && elementIndex(n)!=1) return false;
        if ("last".equals(s.pseudo) && !isLast(n)) return false;
        if ("nth".equals(s.pseudo) && elementIndex(n)!=s.nth) return false;
        return true;
    }
    static int elementIndex(Node n){int k=0; if(n.parent==null)return -1; for(Node c:n.parent.kids) if(!c.isText()){k++; if(c==n)return k;} return -1;}
    static boolean isLast(Node n){ if(n.parent==null)return false; Node last=null; for(Node c:n.parent.kids) if(!c.isText())last=c; return last==n; }
    static Node prevElement(Node n){ if(n.parent==null)return null; Node prev=null; for(Node c:n.parent.kids){ if(c==n)return prev; if(!c.isText())prev=c;} return null; }
    static List<Node> elements(Node n){ List<Node> r=new ArrayList<>(); walk(n,r); return r; }
    static void walk(Node n,List<Node> r){ if(!n.isText()) r.add(n); for(Node c:n.kids) walk(c,r); }
    static List<String> splitTop(String s,char sep){List<String> r=new ArrayList<>();StringBuilder b=new StringBuilder();int br=0,par=0;char q=0;for(char c:s.toCharArray()){if(q!=0){b.append(c);if(c==q)q=0;}else if(c=='"'||c=='\''){q=c;b.append(c);}else{if(c=='[')br++;else if(c==']')br--;else if(c=='(')par++;else if(c==')')par--;if(c==sep&&br==0&&par==0){r.add(b.toString());b.setLength(0);}else b.append(c);}}r.add(b.toString());return r;}
    static void remove(Node n){ if(n.parent!=null)n.parent.kids.remove(n); }

    static String textOf(Node n){ if(n.isText())return n.text; StringBuilder b=new StringBuilder(); for(Node c:n.kids)b.append(textOf(c)); return b.toString(); }
    static List<String> textPieces(Node n){ List<String> r=new ArrayList<>(); collectText(n,r); return r; }
    static void collectText(Node n,List<String> r){ if(n.isText())r.add(n.text); else for(Node c:n.kids)collectText(c,r); }

    static void serialize(Node n, StringBuilder b) {
        if (n.isText()) { b.append(escText(n.text)); return; }
        if (n.tag.equals("#document")) { for(Node c:n.kids)serialize(c,b); return; }
        b.append('<').append(n.tag); for(Map.Entry<String,String> e:n.attrs.entrySet()) b.append(' ').append(e.getKey()).append("=\"").append(escAttr(e.getValue())).append('"');
        b.append('>'); if(!VOID.contains(n.tag)){ for(Node c:n.kids)serialize(c,b); b.append("</").append(n.tag).append('>'); }
    }
    static void serializePretty(Node n,StringBuilder b,int d){ indent(b,d); if(n.isText()){b.append(escText(n.text));return;} b.append('<').append(n.tag); for(Map.Entry<String,String> e:n.attrs.entrySet())b.append(' ').append(e.getKey()).append("=\"").append(escAttr(e.getValue())).append('"'); b.append('>'); if(VOID.contains(n.tag))return; boolean elem=n.kids.stream().anyMatch(k->!k.isText()); if(elem){b.append('\n'); for(Node c:n.kids){serializePretty(c,b,d+2); b.append('\n');} indent(b,d);} else for(Node c:n.kids)serialize(c,b); b.append("</").append(n.tag).append('>');}
    static void indent(StringBuilder b,int d){ for(int i=0;i<d;i++)b.append(' '); }
    static String escText(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}
    static String escAttr(String s){return escText(s).replace("\"","&quot;");}
    static String decode(String s){
        String r = s.replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&#39;","'").replace("&apos;","'").replace("&nbsp;","\u00a0");
        Matcher m = Pattern.compile("&#(x[0-9A-Fa-f]+|\\d+);").matcher(r);
        StringBuffer b = new StringBuffer();
        while (m.find()) {
            try {
                int cp = m.group(1).startsWith("x") || m.group(1).startsWith("X") ? Integer.parseInt(m.group(1).substring(1),16) : Integer.parseInt(m.group(1));
                m.appendReplacement(b, Matcher.quoteReplacement(new String(Character.toChars(cp))));
            } catch (Exception e) {
                m.appendReplacement(b, Matcher.quoteReplacement(m.group(0)));
            }
        }
        m.appendTail(b);
        return b.toString();
    }
    static String resolve(String base,String v){ try { return URI.create(base).resolve(v).toString(); } catch(Exception e){ return v; } }

    static String help() {
        return "htmlq 0.4.0\nMichael Maclean <michael@mgdm.net>\nRuns CSS selectors on HTML\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [--] [selector]...\n\nFLAGS:\n    -B, --detect-base          Try to detect the base URL from the <base> tag in the document. If not found, default to\n                               the value of --base, if supplied\n    -h, --help                 Prints help information\n    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace\n    -p, --pretty               Pretty-print the serialised output\n    -t, --text                 Output only the contents of text nodes inside selected elements\n    -V, --version              Prints version information\n\nOPTIONS:\n    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements\n    -b, --base <base>                   Use this URL as the base for links\n    -f, --filename <FILE>               The input file. Defaults to stdin\n    -o, --output <FILE>                 The output file. Defaults to stdout\n    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple\n                                        times\n\nARGS:\n    <selector>...    The CSS expression to select [default: html]\n";
    }
}
