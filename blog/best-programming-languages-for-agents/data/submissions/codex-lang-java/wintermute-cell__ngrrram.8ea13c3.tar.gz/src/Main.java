import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class Main {
    private static final String HELP = String.join("\n",
            "Usage: executable [OPTIONS]",
            "",
            "Options:",
            "  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]",
            "  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]",
            "  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]",
            "  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]",
            "  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]",
            "  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]",
            "      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]",
            "      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]",
            "      --show-ortho        show keyboard in ortholinear format",
            "      --nokb              pass this flag to disable the keyboard layout display.",
            "      --cat               the most important flag. don't practice alone.",
            "  -h, --help              Print help");

    private static final String[] BI = ("th he in er an re on at en nd ti es or te of ed is it al ar st to nt ng se ha as ou io le ve co me de hi ri ro ic ne ea ra ce li ch ll be ma si om ur ca el ta la ns di fo ho pe ec pr no ct us ac ot il tr ly nc et ut ss so rs un lo wa ge ie wh ee wi em ad ol rt po we na ul ni ts mo ow pa im mi ai sh ir su id os iv ia am fi ci vi pl ig tu ev ld ry mp").split(" ");
    private static final String[] TRI = ("the and ing her hat his tha ere for ent ion ter was you ith ver all wit thi tio nde has nce edt tis oft sth men res are not tio eat oul est ati sta nto ant ons ive com int pro con ess rin tin ers ati ate ble der ome per man rea ill out ave hin ess ion ted ate ers whi ove din ive ure ome ack tra").split(" ");
    private static final String[] TETRA = ("that ther with tion here ould ight have hich whic this thin they atio ever from ough were hing ment ions nthe othe alls ting anda them ouldt tion thei tend ence fore ated ntin comp able cons inte ress tive ally pres ring ters cont ount ants ents").split(" ");
    private static final String[] WORDS = ("the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us").split(" ");

    public static void main(String[] args) {
        Config cfg;
        try {
            cfg = parse(args);
        } catch (Exit e) {
            if (!e.message.isEmpty()) {
                System.err.println(e.message);
            }
            System.exit(e.code);
            return;
        }
        if (cfg.help) {
            System.out.println(HELP);
            return;
        }
        try {
            run(cfg);
        } catch (Exit e) {
            if (!e.message.isEmpty()) {
                System.err.println(e.message);
            }
            System.exit(e.code);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static Config parse(String[] args) {
        Config c = new Config();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h":
                case "--help":
                    c.help = true;
                    break;
                case "-n":
                case "--n":
                    c.n = need(args, ++i, a, "<2|3|4|w|file>");
                    break;
                case "-t":
                case "--top":
                    c.top = parseInt(need(args, ++i, a, "<1-200>"), "--top <1-200>");
                    break;
                case "-c":
                case "--combi":
                    c.combi = parseInt(need(args, ++i, a, "<1-200>"), "--combi <1-200>");
                    break;
                case "-r":
                case "--rep":
                    c.rep = parseInt(need(args, ++i, a, "<number>"), "--rep <number>");
                    break;
                case "-w":
                case "--wpm":
                    c.wpm = parseInt(need(args, ++i, a, "<number>"), "--wpm <number>");
                    break;
                case "-a":
                case "--acc":
                    c.acc = parseInt(need(args, ++i, a, "<0-100>"), "--acc <0-100>");
                    break;
                case "--emu-in":
                    c.emuIn = need(args, ++i, a, "<layout>");
                    break;
                case "--emu-out":
                    c.emuOut = need(args, ++i, a, "<layout>");
                    break;
                case "--show-ortho":
                    c.showOrtho = true;
                    break;
                case "--nokb":
                    c.noKb = true;
                    break;
                case "--cat":
                    c.cat = true;
                    break;
                default:
                    throw new Exit(2, "error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.");
            }
        }
        if (c.help) {
            return c;
        }
        if (c.top < 1 || c.top > 200) throw new Exit(1, "Invalid argument for top. Use a number between 1 and 200.");
        if (c.combi < 1 || c.combi > 200) throw new Exit(1, "Invalid argument for combi. Use a number between 1 and 200.");
        if (c.acc < 0 || c.acc > 100) throw new Exit(1, "Invalid argument for acc. Use a number between 0 and 100.");
        if (c.emuIn.isEmpty() != c.emuOut.isEmpty()) throw new Exit(1, "You need to specify both emu_in and emu_out.");
        return c;
    }

    private static String need(String[] args, int idx, String flag, String valueName) {
        if (idx >= args.length || args[idx].startsWith("-")) {
            throw new Exit(2, "error: a value is required for '" + canonical(flag) + " " + valueName + "' but none was supplied\n\nFor more information, try '--help'.");
        }
        return args[idx];
    }

    private static String canonical(String flag) {
        Map<String, String> map = new HashMap<>();
        map.put("-n", "--n"); map.put("-t", "--top"); map.put("-c", "--combi");
        map.put("-r", "--rep"); map.put("-w", "--wpm"); map.put("-a", "--acc");
        return map.getOrDefault(flag, flag);
    }

    private static int parseInt(String v, String name) {
        try {
            if (v.startsWith("+")) v = v.substring(1);
            return Integer.parseInt(v);
        } catch (NumberFormatException e) {
            throw new Exit(2, "error: invalid value '" + v + "' for '" + name + "': invalid digit found in string\n\nFor more information, try '--help'.");
        }
    }

    private static void run(Config c) throws IOException {
        List<String> units = loadUnits(c.n);
        if (!c.emuIn.isEmpty()) {
            validateLayout(c.emuIn);
            validateLayout(c.emuOut);
            units = emulate(units, c.emuIn, c.emuOut);
        }
        int top = Math.min(c.top, units.size());
        units = new ArrayList<>(units.subList(0, top));
        List<String> lesson = createLesson(units, c.combi, c.rep);

        System.out.print("\033[?1049h\033[2J\033[?25l");
        printScreen(c, lesson);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        long start = 0L;
        int typed = 0;
        int correct = 0;
        String target = String.join(" ", lesson);
        while (typed < target.length()) {
            int ch = br.read();
            if (ch == -1 || ch == 3 || ch == 27) break;
            if (start == 0L && !Character.isWhitespace(ch)) start = System.nanoTime();
            char got = (char) ch;
            if (got == target.charAt(typed)) correct++;
            typed++;
        }
        double seconds = start == 0L ? 0.0 : Math.max(0.01, (System.nanoTime() - start) / 1_000_000_000.0);
        double wpm = seconds == 0.0 ? 0.0 : (correct / 5.0) / (seconds / 60.0);
        double acc = typed == 0 ? 0.0 : correct * 100.0 / typed;
        System.out.print("\033[?25h\033[?1049l");
        System.out.printf(Locale.US, "WPM: %.0f  ACC: %.0f%%%n", wpm, acc);
        if (wpm >= c.wpm && acc >= c.acc) {
            System.out.println("Success!");
        } else {
            System.out.println("Try again.");
        }
    }

    private static List<String> loadUnits(String n) throws IOException {
        switch (n) {
            case "2": return new ArrayList<>(Arrays.asList(BI));
            case "3": return new ArrayList<>(Arrays.asList(TRI));
            case "4": return new ArrayList<>(Arrays.asList(TETRA));
            case "w": return new ArrayList<>(Arrays.asList(WORDS));
            default:
                Path p = Path.of(n);
                if (!Files.exists(p)) throw new Exit(1, "File not found: " + n);
                String s = Files.readString(p);
                List<String> out = new ArrayList<>();
                for (String part : s.split("[,\\n\\r]+")) {
                    String t = part.trim();
                    if (!t.isEmpty()) out.add(t);
                }
                if (out.isEmpty()) out.add("the");
                return out;
        }
    }

    private static List<String> createLesson(List<String> units, int combi, int rep) {
        ArrayList<String> selected = new ArrayList<>(units);
        Collections.shuffle(selected, new Random());
        selected = new ArrayList<>(selected.subList(0, Math.min(combi, selected.size())));
        ArrayList<String> lesson = new ArrayList<>();
        for (int r = 0; r < Math.max(0, rep); r++) lesson.addAll(selected);
        Collections.shuffle(lesson, new Random());
        return lesson;
    }

    private static void printScreen(Config c, List<String> lesson) {
        System.out.println("ngrrram");
        if (c.cat) {
            System.out.println(" /\\_/\\\\");
            System.out.println("( o.o )");
            System.out.println(" > ^ <");
        }
        System.out.println();
        System.out.println(String.join(" ", lesson));
        System.out.println();
        System.out.println("wpm target: " + c.wpm + "    accuracy target: " + c.acc + "%");
        if (!c.noKb) printKeyboard(c.showOrtho);
        System.out.flush();
    }

    private static void printKeyboard(boolean ortho) {
        System.out.println();
        if (ortho) {
            System.out.println("q w e r t y u i o p");
            System.out.println("a s d f g h j k l ;");
            System.out.println("z x c v b n m , . /");
        } else {
            System.out.println("  q w e r t y u i o p");
            System.out.println("   a s d f g h j k l ;");
            System.out.println("    z x c v b n m , . /");
        }
    }

    private static void validateLayout(String name) {
        if (!layouts().containsKey(name)) throw new Exit(1, "Unknown layout: " + name);
    }

    private static List<String> emulate(List<String> units, String in, String out) {
        String a = layouts().get(in);
        String b = layouts().get(out);
        Map<Character, Character> map = new HashMap<>();
        for (int i = 0; i < Math.min(a.length(), b.length()); i++) map.put(b.charAt(i), a.charAt(i));
        ArrayList<String> result = new ArrayList<>();
        for (String u : units) {
            StringBuilder sb = new StringBuilder();
            for (char ch : u.toCharArray()) sb.append(map.getOrDefault(ch, ch));
            result.add(sb.toString());
        }
        return result;
    }

    private static Map<String, String> layouts() {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("qwerty", "qwertyuiopasdfghjkl;zxcvbnm,./");
        m.put("qwertz", "qwertzuiopasdfghjkl;yxcvbnm,./");
        m.put("azerty", "azertyuiopqsdfghjklmwxcvbn,;:");
        m.put("dvorak", "',.pyfgcrlaoeuidhtns;qjkxbmwvz");
        m.put("colemak", "qwfpgjluy;arstdhneiozxcvbkm,./");
        m.put("colemakdh", "qwfpbjluy;arstgmneiozxcdvkh,./");
        return m;
    }

    private static class Config {
        boolean help, showOrtho, noKb, cat;
        String n = "2", emuIn = "", emuOut = "";
        int top = 50, combi = 2, rep = 3, wpm = 40, acc = 94;
    }

    private static class Exit extends RuntimeException {
        final int code;
        final String message;
        Exit(int code, String message) {
            this.code = code;
            this.message = message;
        }
    }
}
