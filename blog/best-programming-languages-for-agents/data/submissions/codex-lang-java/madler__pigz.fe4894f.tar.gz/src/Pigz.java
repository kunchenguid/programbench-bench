import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

public class Pigz {
    static class Opt {
        boolean decompress, stdout, keep, force, test, list, verbose, quiet, recursive;
        boolean zlib, zip, noName, name = true, noTime, time = true;
        int level = Deflater.DEFAULT_COMPRESSION;
        String suffix = ".gz", comment, alias = "-";
        ArrayList<String> files = new ArrayList<>();
    }

    static final String HELP = """
Usage: pigz [options] [files ...]
  will compress files in place, adding the suffix '.gz'. If no files are
  specified, stdin will be compressed to stdout. pigz does what gzip does,
  but spreads the work over multiple processors and cores when compressing.

Options:
  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)
  --fast, --best       Compression levels 1 and 9 respectively
  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin
  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)
  -c, --stdout         Write all processed output to stdout (won't delete)
  -C, --comment ccc    Put comment ccc in the gzip or zip header
  -d, --decompress     Decompress the compressed input
  -f, --force          Force overwrite, compress .gz, links, and to terminal
  -F  --first          Do iterations first, before block split for -11
  -h, --help           Display a help screen and quit
  -H, --huffman        Use only Huffman coding for compression
  -i, --independent    Compress blocks independently for damage recovery
  -I, --iterations n   Number of iterations for -11 optimization
  -J, --maxsplits n    Maximum number of split blocks for -11
  -k, --keep           Do not delete original file after processing
  -K, --zip            Compress to PKWare zip (.zip) single entry format
  -l, --list           List the contents of the compressed input
  -L, --license        Display the pigz license and quit
  -m, --no-time        Do not store or restore mod time
  -M, --time           Store or restore mod time
  -n, --no-name        Do not store or restore file name or mod time
  -N, --name           Store or restore file name and mod time
  -O  --oneblock       Do not split into smaller blocks for -11
  -p, --processes n    Allow up to n compression threads (default is the
                       number of online processors, or 8 if unknown)
  -q, --quiet          Print no messages, even on error
  -r, --recursive      Process the contents of all subdirectories
  -R, --rsyncable      Input-determined block locations for rsync
  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)
  -t, --test           Test the integrity of the compressed input
  -U, --rle            Use run-length encoding for compression
  -v, --verbose        Provide more verbose output
  -V  --version        Show the version of pigz
  -Y  --synchronous    Force output file write to permanent storage
  -z, --zlib           Compress to zlib (.zz) instead of gzip format
  --                   All arguments after "--" are treated as files
""";

    static final String LICENSE = """
pigz 2.8
Copyright (C) 2007-2023 Mark Adler
Subject to the terms of the zlib license.
No warranty is provided or implied.
""";

    public static void main(String[] args) {
        try {
            String invoked = new File(System.getProperty("sun.java.command").split(" ")[0]).getName();
            ArrayList<String> all = new ArrayList<>();
            addEnv(all, "GZIP");
            addEnv(all, "PIGZ");
            all.addAll(Arrays.asList(args));
            Opt opt = parse(all.toArray(new String[0]));
            if (invoked.contains("unpigz")) opt.decompress = true;
            if (opt.list) opt.decompress = true;
            if (opt.test) opt.decompress = true;
            if (opt.files.isEmpty()) opt.stdout = true;
            if (opt.recursive) expandDirectories(opt);
            int status = run(opt);
            System.exit(status);
        } catch (HelpExit e) {
            System.out.print(e.text);
            System.exit(0);
        } catch (BadUsage e) {
            System.err.println("pigz: " + e.getMessage());
            System.exit(22);
        } catch (Exception e) {
            System.err.println("pigz: " + e.getMessage());
            System.exit(1);
        }
    }

    static void addEnv(ArrayList<String> out, String name) {
        String val = System.getenv(name);
        if (val == null || val.isBlank()) return;
        out.addAll(shellWords(val));
    }

    static ArrayList<String> shellWords(String s) {
        ArrayList<String> r = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        char quote = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (quote != 0) {
                if (c == quote) quote = 0;
                else b.append(c);
            } else if (c == '\'' || c == '"') quote = c;
            else if (Character.isWhitespace(c)) {
                if (b.length() > 0) { r.add(b.toString()); b.setLength(0); }
            } else b.append(c);
        }
        if (b.length() > 0) r.add(b.toString());
        return r;
    }

    static class HelpExit extends RuntimeException { String text; HelpExit(String t){text=t;} }
    static class BadUsage extends RuntimeException { BadUsage(String s){super(s);} }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        boolean filesOnly = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (filesOnly || !a.startsWith("-") || a.equals("-")) {
                o.files.add(a);
                continue;
            }
            if (a.equals("--")) { filesOnly = true; continue; }
            if (a.startsWith("--")) {
                String v = null, name = a;
                int eq = a.indexOf('=');
                if (eq >= 0) { name = a.substring(0, eq); v = a.substring(eq + 1); }
                switch (name) {
                    case "--help" -> throw new HelpExit(HELP);
                    case "--license" -> throw new HelpExit(LICENSE);
                    case "--version" -> throw new HelpExit("pigz 2.8\n");
                    case "--fast" -> o.level = 1;
                    case "--best" -> o.level = 9;
                    case "--stdout", "--to-stdout" -> o.stdout = true;
                    case "--decompress", "--uncompress" -> o.decompress = true;
                    case "--force" -> o.force = true;
                    case "--keep" -> o.keep = true;
                    case "--zip" -> o.zip = true;
                    case "--zlib" -> o.zlib = true;
                    case "--list" -> o.list = true;
                    case "--test" -> o.test = true;
                    case "--verbose" -> o.verbose = true;
                    case "--quiet", "--silent" -> o.quiet = true;
                    case "--recursive" -> o.recursive = true;
                    case "--no-name" -> { o.noName = true; o.name = false; o.noTime = true; o.time = false; }
                    case "--name" -> { o.name = true; o.time = true; o.noName = false; o.noTime = false; }
                    case "--no-time" -> { o.noTime = true; o.time = false; }
                    case "--time" -> { o.time = true; o.noTime = false; }
                    case "--alias" -> o.alias = need(args, ++i, name, v);
                    case "--comment" -> o.comment = need(args, ++i, name, v);
                    case "--suffix" -> o.suffix = need(args, ++i, name, v);
                    case "--blocksize", "--processes", "--iterations", "--maxsplits" -> { if (v == null) i++; }
                    case "--huffman", "--independent", "--rsyncable", "--rle", "--first", "--oneblock", "--synchronous" -> {}
                    default -> throw new BadUsage("abort: invalid option: " + a);
                }
                continue;
            }
            for (int j = 1; j < a.length(); j++) {
                char c = a.charAt(j);
                if (Character.isDigit(c)) {
                    if (c == '1' && j + 1 < a.length() && a.charAt(j + 1) == '1') { o.level = 9; j++; }
                    else o.level = c - '0';
                    continue;
                }
                switch (c) {
                    case 'h' -> throw new HelpExit(HELP);
                    case 'L' -> throw new HelpExit(LICENSE);
                    case 'V' -> throw new HelpExit("pigz 2.8\n");
                    case 'c' -> o.stdout = true;
                    case 'd' -> o.decompress = true;
                    case 'f' -> o.force = true;
                    case 'k' -> o.keep = true;
                    case 'K' -> o.zip = true;
                    case 'z' -> o.zlib = true;
                    case 'l' -> o.list = true;
                    case 't' -> o.test = true;
                    case 'v' -> o.verbose = true;
                    case 'q' -> o.quiet = true;
                    case 'r' -> o.recursive = true;
                    case 'n' -> { o.noName = true; o.name = false; o.noTime = true; o.time = false; }
                    case 'N' -> { o.name = true; o.time = true; o.noName = false; o.noTime = false; }
                    case 'm' -> { o.noTime = true; o.time = false; }
                    case 'M' -> { o.time = true; o.noTime = false; }
                    case 'H', 'i', 'R', 'U', 'F', 'O', 'Y' -> {}
                    case 'A', 'C', 'S', 'b', 'p', 'I', 'J' -> {
                        String val = j + 1 < a.length() ? a.substring(j + 1) : need(args, ++i, "-" + c, null);
                        if (c == 'A') o.alias = val;
                        else if (c == 'C') o.comment = val;
                        else if (c == 'S') o.suffix = val;
                        j = a.length();
                    }
                    default -> throw new BadUsage("abort: invalid option: -" + c);
                }
            }
        }
        return o;
    }

    static String need(String[] args, int idx, String opt, String inline) {
        if (inline != null) return inline;
        if (idx >= args.length) throw new BadUsage("option " + opt + " requires an argument");
        return args[idx];
    }

    static void expandDirectories(Opt o) throws IOException {
        ArrayList<String> expanded = new ArrayList<>();
        for (String f : o.files) {
            if (f.equals("-")) { expanded.add(f); continue; }
            Path p = Paths.get(f);
            if (Files.isDirectory(p)) {
                try (var s = Files.walk(p)) {
                    s.filter(Files::isRegularFile).forEach(x -> expanded.add(x.toString()));
                }
            } else expanded.add(f);
        }
        o.files = expanded;
    }

    static int run(Opt o) {
        int bad = 0;
        if (o.list) {
            if (o.verbose) System.out.println("method    check    timestamp    compressed   original reduced  name");
            else System.out.println("compressed   original reduced  name");
        }
        if (o.files.isEmpty()) {
            try { processStream(o, System.in, System.out, "-", 0); } catch (Exception e) { bad = error(o, e); }
            return bad;
        }
        for (String f : o.files) {
            try {
                if (f.equals("-")) processStream(o, System.in, System.out, "-", 0);
                else processFile(o, Paths.get(f));
            } catch (Exception e) {
                bad = error(o, e);
            }
        }
        return bad;
    }

    static int error(Opt o, Exception e) {
        if (!o.quiet) System.err.println("pigz: " + e.getMessage());
        return 1;
    }

    static void processFile(Opt o, Path in) throws IOException {
        if (Files.isDirectory(in)) {
            if (!o.quiet) System.err.println("pigz: skipping: " + in + " is a directory");
            return;
        }
        if (o.list) { listFile(o, in); return; }
        if (o.test) {
            try (InputStream is = Files.newInputStream(in)) { drain(openCompressedInput(is)); }
            return;
        }
        if (!o.decompress && !o.force && hasCompressedSuffix(in.getFileName().toString(), o)) {
            if (!o.quiet) System.err.println("pigz: skipping: " + in + " already has " + compressedSuffix(o) + " suffix");
            return;
        }
        if (o.stdout) {
            try (InputStream is = Files.newInputStream(in)) {
                processStream(o, is, System.out, in.getFileName().toString(), Files.getLastModifiedTime(in).toMillis());
            }
            return;
        }
        Path out = o.decompress ? outputDecompressName(in, o) : Paths.get(in.toString() + (o.zip ? ".zip" : o.zlib ? ".zz" : o.suffix));
        if (Files.exists(out) && !o.force) throw new IOException(out + " exists -- skipping");
        try (InputStream is = Files.newInputStream(in); OutputStream os = Files.newOutputStream(out)) {
            processStream(o, is, os, in.getFileName().toString(), Files.getLastModifiedTime(in).toMillis());
        } catch (IOException | RuntimeException e) {
            Files.deleteIfExists(out);
            throw e;
        }
        if (o.decompress) {
            try { Files.setLastModifiedTime(out, Files.getLastModifiedTime(in)); } catch (Exception ignored) {}
        } else if (o.time) {
            try { Files.setLastModifiedTime(out, Files.getLastModifiedTime(in)); } catch (Exception ignored) {}
        }
        if (!o.keep) Files.deleteIfExists(in);
        if (o.verbose && !o.quiet) System.err.println(in + " to " + out);
    }

    static boolean hasCompressedSuffix(String name, Opt o) {
        return name.endsWith(compressedSuffix(o));
    }

    static String compressedSuffix(Opt o) {
        if (o.zip) return ".zip";
        if (o.zlib) return ".zz";
        return o.suffix == null || o.suffix.isEmpty() ? ".gz" : o.suffix;
    }

    static Path outputDecompressName(Path in, Opt o) {
        String s = in.toString();
        String out;
        if (s.endsWith(".gz") || s.endsWith(".zz")) out = s.substring(0, s.length() - 3);
        else if (s.endsWith(".zip")) out = s.substring(0, s.length() - 4);
        else if (s.endsWith(".tgz") || s.endsWith(".taz")) out = s.substring(0, s.length() - 4) + ".tar";
        else if (o.suffix != null && !o.suffix.isEmpty() && s.endsWith(o.suffix)) out = s.substring(0, s.length() - o.suffix.length());
        else out = s + ".out";
        return Paths.get(out);
    }

    static void processStream(Opt o, InputStream is, OutputStream os, String name, long mtimeMillis) throws IOException {
        if (o.decompress) {
            try (InputStream cin = openCompressedInput(is)) { copy(cin, os); }
        } else if (o.zip) {
            ZipOutputStream zos = new ZipOutputStream(os);
            zos.setLevel(o.level);
            ZipEntry ze = new ZipEntry(name.equals("-") ? o.alias : name);
            if (o.time && mtimeMillis > 0) ze.setTime(mtimeMillis);
            if (o.comment != null) ze.setComment(o.comment);
            zos.putNextEntry(ze);
            copy(is, zos);
            zos.closeEntry();
            zos.finish();
        } else if (o.zlib) {
            Deflater def = new Deflater(o.level);
            DeflaterOutputStream dos = new DeflaterOutputStream(os, def, 8192, true);
            copy(is, dos);
            dos.finish();
            def.end();
        } else {
            gzip(is, os, o, name, mtimeMillis);
        }
        os.flush();
    }

    static void gzip(InputStream is, OutputStream os, Opt o, String name, long mtimeMillis) throws IOException {
        CRC32 crc = new CRC32();
        long size = 0;
        int flags = 0;
        boolean storeName = o.name && !name.equals("-");
        if (storeName) flags |= 8;
        if (o.comment != null) flags |= 16;
        os.write(new byte[]{0x1f, (byte)0x8b, 8, (byte)flags});
        int mt = o.time && mtimeMillis > 0 ? (int)(mtimeMillis / 1000) : 0;
        writeLeInt(os, mt);
        os.write(0);
        os.write(3);
        if (storeName) writeZ(os, baseNameNoGz(name));
        if (o.comment != null) writeZ(os, o.comment);
        Deflater def = new Deflater(o.level, true);
        byte[] in = new byte[8192], out = new byte[8192];
        while (true) {
            int n = is.read(in);
            if (n < 0) break;
            if (n == 0) continue;
            crc.update(in, 0, n);
            size += n;
            def.setInput(in, 0, n);
            while (!def.needsInput()) {
                int got = def.deflate(out);
                if (got > 0) os.write(out, 0, got);
            }
        }
        def.finish();
        while (!def.finished()) {
            int got = def.deflate(out);
            if (got > 0) os.write(out, 0, got);
        }
        def.end();
        writeLeInt(os, (int)crc.getValue());
        writeLeInt(os, (int)size);
    }

    static String baseNameNoGz(String name) {
        String n = new File(name).getName();
        if (n.endsWith(".gz")) n = n.substring(0, n.length() - 3);
        return n;
    }

    static void writeZ(OutputStream os, String s) throws IOException {
        os.write(s.getBytes(StandardCharsets.ISO_8859_1));
        os.write(0);
    }

    static void writeLeInt(OutputStream os, int v) throws IOException {
        os.write(v & 255); os.write((v >>> 8) & 255); os.write((v >>> 16) & 255); os.write((v >>> 24) & 255);
    }

    static InputStream openCompressedInput(InputStream raw) throws IOException {
        PushbackInputStream pb = new PushbackInputStream(new BufferedInputStream(raw), 4);
        byte[] h = new byte[4];
        int n = pb.read(h);
        if (n > 0) pb.unread(h, 0, n);
        if (n >= 2 && (h[0] & 255) == 0x1f && (h[1] & 255) == 0x8b) return new GZIPInputStream(pb);
        if (n >= 4 && (h[0] & 255) == 0x50 && (h[1] & 255) == 0x4b) {
            ZipInputStream zis = new ZipInputStream(pb);
            ZipEntry e = zis.getNextEntry();
            if (e == null) throw new ZipException("empty zip file");
            return zis;
        }
        return new InflaterInputStream(pb);
    }

    static void listFile(Opt o, Path p) throws IOException {
        byte[] data = Files.readAllBytes(p);
        long comp = data.length;
        long orig = -1;
        long crc = 0;
        String name = stripSuffix(p.getFileName().toString());
        long when = Files.getLastModifiedTime(p).toMillis();
        if (data.length >= 2 && (data[0]&255)==0x1f && (data[1]&255)==0x8b) {
            GzInfo gi = parseGzip(data);
            orig = gi.size;
            crc = gi.crc;
            if (gi.name != null && !gi.name.isEmpty()) name = gi.name;
            if (gi.mtime != 0) when = gi.mtime * 1000L;
            comp = Math.max(0, data.length - gi.header - 8);
        } else if (data.length >= 4 && (data[0]&255)==0x50 && (data[1]&255)==0x4b) {
            try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(data))) {
                ZipEntry e = zis.getNextEntry();
                if (e != null) {
                    name = e.getName();
                    CRC32 zcrc = new CRC32();
                    long count = 0;
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = zis.read(buf)) >= 0) {
                        if (n > 0) {
                            zcrc.update(buf, 0, n);
                            count += n;
                        }
                    }
                    orig = e.getSize() >= 0 ? e.getSize() : count;
                    crc = e.getCrc() >= 0 ? e.getCrc() : zcrc.getValue();
                    comp = e.getCompressedSize() >= 0 ? e.getCompressedSize() : Math.max(0, data.length - count);
                    if (e.getTime() > 0) when = e.getTime();
                }
            }
        } else {
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream is = new InflaterInputStream(new ByteArrayInputStream(data))) { copy(is, out); }
                orig = out.size();
            } catch (Exception ignored) {}
        }
        String red = orig >= 0 && orig != 0 ? String.format(Locale.ROOT, "%5.1f%%", 100.0 * (orig - comp) / orig) : " unk ";
        if (o.verbose) {
            String ts = new SimpleDateFormat("MMM dd HH:mm").format(new Date(when));
            System.out.printf(Locale.ROOT, "gzip 8  %08x  %s  %10d %10s %s  %s%n", crc, ts, comp, orig >= 0 ? Long.toString(orig) : "0?", red, name);
        } else {
            System.out.printf(Locale.ROOT, "%10d %10s %s  %s%n", comp, orig >= 0 ? Long.toString(orig) : "0?", red, name);
        }
    }

    static String stripSuffix(String s) {
        if (s.endsWith(".gz") || s.endsWith(".zz")) return s.substring(0, s.length() - 3);
        if (s.endsWith(".zip")) return s.substring(0, s.length() - 4);
        return s;
    }

    static class GzInfo { int header; long size, crc, mtime; String name; }

    static GzInfo parseGzip(byte[] d) {
        GzInfo g = new GzInfo();
        if (d.length < 18) return g;
        int flg = d[3] & 255;
        g.mtime = ((long)d[4]&255) | (((long)d[5]&255)<<8) | (((long)d[6]&255)<<16) | (((long)d[7]&255)<<24);
        int p = 10;
        if ((flg & 4) != 0 && p + 2 <= d.length) { int x = (d[p]&255) | ((d[p+1]&255)<<8); p += 2 + x; }
        if ((flg & 8) != 0) {
            int s = p;
            while (p < d.length && d[p] != 0) p++;
            g.name = new String(d, s, Math.max(0, p - s), StandardCharsets.ISO_8859_1);
            p++;
        }
        if ((flg & 16) != 0) while (p < d.length && d[p++] != 0) {}
        if ((flg & 2) != 0) p += 2;
        g.header = p;
        int n = d.length;
        g.crc = getLe(d, n - 8) & 0xffffffffL;
        g.size = getLe(d, n - 4) & 0xffffffffL;
        return g;
    }

    static int getLe(byte[] d, int p) {
        if (p < 0 || p + 4 > d.length) return 0;
        return (d[p]&255) | ((d[p+1]&255)<<8) | ((d[p+2]&255)<<16) | ((d[p+3]&255)<<24);
    }

    static void copy(InputStream is, OutputStream os) throws IOException {
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) >= 0) if (n > 0) os.write(buf, 0, n);
    }

    static void drain(InputStream is) throws IOException {
        byte[] buf = new byte[8192];
        while (is.read(buf) >= 0) {}
    }
}
