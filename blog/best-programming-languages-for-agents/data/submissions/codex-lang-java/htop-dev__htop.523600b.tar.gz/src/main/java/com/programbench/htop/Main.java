package com.programbench.htop;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class Main {
    private static final String VERSION = "htop 3.5.0-dev-878e0ce";
    private static final String COPYRIGHT =
            "(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.\n" +
            "Released under the GNU GPLv2+.";

    private static final String HELP =
            VERSION + "\n" +
            COPYRIGHT + "\n\n" +
            "-C --no-color                   Use a monochrome color scheme\n" +
            "-d --delay=DELAY                Set the delay between updates, in tenths of seconds\n" +
            "-F --filter=FILTER              Show only the commands matching the given filter\n" +
            "   --no-function-bar             Hide the function bar\n" +
            "-h --help                       Print this help screen\n" +
            "-H --highlight-changes[=DELAY]  Highlight new and old processes\n" +
            "-M --no-mouse                   Disable the mouse\n" +
            "   --no-meters                  Hide meters\n" +
            "-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates\n" +
            "-p --pid=PID[,PID,PID...]       Show only the given PIDs\n" +
            "   --readonly                   Disable all system and process changing features\n" +
            "-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)\n" +
            "-t --tree                       Show the tree view (can be combined with -s)\n" +
            "-u --user[=USERNAME]            Show only processes for a given user (or $USER)\n" +
            "-U --no-unicode                 Do not use unicode but plain ASCII\n" +
            "-V --version                    Print version info\n\n" +
            "Press F1 inside htop for online help.\n" +
            "See 'man htop' for more information.";

    private static final String SORT_HELP =
            "                PID Process/thread ID\n" +
            "            Command Command line (insert as last column only)\n" +
            "              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)\n" +
            "               PPID Parent process ID\n" +
            "               PGRP Process group ID\n" +
            "            SESSION Process's session ID\n" +
            "                TTY Controlling terminal\n" +
            "              TPGID Process ID of the fg process group of the controlling terminal\n" +
            "             MINFLT Number of minor faults which have not required loading a memory page from disk\n" +
            "            CMINFLT Children processes' minor faults\n" +
            "             MAJFLT Number of major faults which have required loading a memory page from disk\n" +
            "            CMAJFLT Children processes' major faults\n" +
            "              UTIME User CPU time - time the process spent executing in user mode\n" +
            "              STIME System CPU time - time the kernel spent running system calls for this process\n" +
            "             CUTIME Children processes' user CPU time\n" +
            "             CSTIME Children processes' system CPU time\n" +
            "           PRIORITY Kernel's internal priority for the process\n" +
            "               NICE Nice value (the higher the value, the more it lets other processes take priority)\n" +
            "          STARTTIME Time the process was started\n" +
            "          PROCESSOR Id of the CPU the process last executed on\n" +
            "             M_VIRT Total program size in virtual memory\n" +
            "         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage\n" +
            "            M_SHARE Size of the process's shared pages\n" +
            "              M_TRS Size of the .text segment of the process (CODE)\n" +
            "              M_DRS Size of the .data segment plus stack usage of the process (DATA)\n" +
            "              M_LRS The library size of the process (calculated from memory maps)\n" +
            "             ST_UID User ID of the process owner\n" +
            "        PERCENT_CPU Percentage of the CPU time the process used in the last sampling\n" +
            "        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size\n" +
            "               USER Username of the process owner (or user ID if name cannot be determined)\n" +
            "               TIME Total time the process has spent in user and system time\n" +
            "               NLWP Number of threads in the process\n" +
            "               TGID Thread group ID (i.e. process ID)\n" +
            "   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)\n" +
            "            ELAPSED Time since the process was started\n" +
            "    SCHEDULERPOLICY Current scheduling policy of the process\n" +
            "              RCHAR Number of bytes the process has read\n" +
            "              WCHAR Number of bytes the process has written\n" +
            "              SYSCR Number of read(2) syscalls for the process\n" +
            "              SYSCW Number of write(2) syscalls for the process\n" +
            "             RBYTES Bytes of read(2) I/O for the process\n" +
            "             WBYTES Bytes of write(2) I/O for the process\n" +
            "             CNCLWB Bytes of cancelled write(2) I/O\n" +
            "       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process\n" +
            "      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process\n" +
            "            IO_RATE Total I/O rate in bytes per second\n" +
            "             CGROUP Which cgroup the process is in\n" +
            "                OOM OOM (Out-of-Memory) killer score\n" +
            "        IO_PRIORITY I/O priority\n" +
            "              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it\n" +
            "             M_SWAP Size of the process's swapped pages\n" +
            "            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects\n" +
            "               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)\n" +
            "            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)\n" +
            "               COMM comm string of the process from /proc/[pid]/comm\n" +
            "                EXE Basename of exe of the process from /proc/[pid]/exe\n" +
            "                CWD The current working directory of the process\n" +
            "       AUTOGROUP_ID The autogroup identifier of the process\n" +
            "     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup\n" +
            "            CCGROUP Which cgroup the process is in (condensed to essentials)\n" +
            "          CONTAINER Name of the container the process is in (guessed by heuristics)\n" +
            "             M_PRIV The private memory size of the process - resident set size minus shared memory\n" +
            "           GPU_TIME Total GPU time\n" +
            "        GPU_PERCENT Percentage of the GPU time the process used in the last sampling\n" +
            "        ISCONTAINER Whether the process is running inside a child container";
    private static final Set<String> SORT_KEYS = Set.of(
            "PID", "COMMAND", "STATE", "PPID", "PGRP", "SESSION", "TTY", "TPGID", "MINFLT", "CMINFLT",
            "MAJFLT", "CMAJFLT", "UTIME", "STIME", "CUTIME", "CSTIME", "PRIORITY", "NICE", "STARTTIME",
            "PROCESSOR", "M_VIRT", "M_RESIDENT", "M_SHARE", "M_TRS", "M_DRS", "M_LRS", "ST_UID",
            "PERCENT_CPU", "PERCENT_MEM", "USER", "TIME", "NLWP", "TGID", "PERCENT_NORM_CPU",
            "ELAPSED", "SCHEDULERPOLICY", "RCHAR", "WCHAR", "SYSCR", "SYSCW", "RBYTES", "WBYTES",
            "CNCLWB", "IO_READ_RATE", "IO_WRITE_RATE", "IO_RATE", "CGROUP", "OOM", "IO_PRIORITY",
            "M_PSS", "M_SWAP", "M_PSSWP", "CTXT", "SECATTR", "COMM", "EXE", "CWD", "AUTOGROUP_ID",
            "AUTOGROUP_NICE", "CCGROUP", "CONTAINER", "M_PRIV", "GPU_TIME", "GPU_PERCENT", "ISCONTAINER");

    private Main() {}

    public static void main(String[] args) {
        String prog = System.getProperty("htop.argv0", "./executable");
        try {
            Config config = parse(args, prog);
            if (config.help) {
                System.out.println(HELP);
                return;
            }
            if (config.version) {
                System.out.println(VERSION);
                return;
            }
            if (config.sortHelp) {
                System.out.println(SORT_HELP);
                return;
            }
            runScreen(config);
        } catch (UsageException ex) {
            System.err.println(ex.getMessage());
            System.exit(1);
        }
    }

    private static Config parse(String[] args, String prog) throws UsageException {
        Config c = new Config();
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if ("--".equals(arg)) {
                if (i + 1 < args.length) throw new UsageException(prog + ": invalid option -- '" + args[i + 1] + "'");
                break;
            }
            if (arg.startsWith("--")) {
                String name = arg;
                String value = null;
                int eq = arg.indexOf('=');
                if (eq >= 0) {
                    name = arg.substring(0, eq);
                    value = arg.substring(eq + 1);
                }
                switch (name) {
                    case "--help" -> c.help = true;
                    case "--version" -> c.version = true;
                    case "--no-color", "--no-colour", "--no-function-bar", "--no-mouse", "--no-meters", "--readonly", "--tree", "--no-unicode" -> {}
                    case "--highlight-changes" -> {}
                    case "--delay", "--filter", "--pid", "--max-iterations", "--sort-key" -> {
                        if (value == null) {
                            if (i + 1 >= args.length) throw new UsageException(prog + ": option '" + name + "' requires an argument");
                            value = args[++i];
                        }
                        applyLong(c, name, value, prog);
                    }
                    case "--user" -> {
                        if (value == null) value = System.getenv().getOrDefault("USER", "");
                        c.user = value;
                    }
                    default -> throw new UsageException(prog + ": unrecognized option '" + arg + "'");
                }
            } else if (arg.startsWith("-") && arg.length() > 1) {
                for (int pos = 1; pos < arg.length(); pos++) {
                    char ch = arg.charAt(pos);
                    switch (ch) {
                        case 'h' -> c.help = true;
                        case 'V' -> c.version = true;
                        case 'C', 'M', 't', 'U' -> {}
                        case 'H' -> {
                            String rest = arg.substring(pos + 1);
                            if (!rest.isEmpty()) pos = arg.length();
                        }
                        case 'd', 'F', 'n', 'p', 's', 'u' -> {
                            String value;
                            if (pos + 1 < arg.length()) {
                                value = arg.substring(pos + 1);
                                pos = arg.length();
                            } else if (ch == 'u') {
                                value = System.getenv().getOrDefault("USER", "");
                            } else {
                                if (i + 1 >= args.length) throw new UsageException(prog + ": option requires an argument -- '" + ch + "'");
                                value = args[++i];
                            }
                            applyShort(c, ch, value, prog);
                        }
                        default -> throw new UsageException(prog + ": invalid option -- '" + ch + "'");
                    }
                }
            } else {
                throw new UsageException(prog + ": invalid option -- '" + arg + "'");
            }
        }
        return c;
    }

    private static void applyLong(Config c, String name, String value, String prog) throws UsageException {
        switch (name) {
            case "--delay" -> c.delayTenths = parseDelay(value);
            case "--filter" -> c.filter = value.toLowerCase(Locale.ROOT);
            case "--pid" -> c.pids = parsePids(value);
            case "--max-iterations" -> c.iterations = Math.max(1, parseInt(value, prog + ": invalid iteration count"));
            case "--sort-key" -> {
                setSortKey(c, value);
            }
            default -> {}
        }
    }

    private static void applyShort(Config c, char ch, String value, String prog) throws UsageException {
        switch (ch) {
            case 'd' -> c.delayTenths = parseDelay(value);
            case 'F' -> c.filter = value.toLowerCase(Locale.ROOT);
            case 'n' -> c.iterations = Math.max(1, parseInt(value, prog + ": invalid iteration count"));
            case 'p' -> c.pids = parsePids(value);
            case 's' -> {
                setSortKey(c, value);
            }
            case 'u' -> c.user = value;
            default -> {}
        }
    }

    private static int parseInt(String value, String msg) throws UsageException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            throw new UsageException(msg);
        }
    }

    private static int parseDelay(String value) throws UsageException {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ex) {
            throw new UsageException("Error: invalid delay value \"" + value + "\".");
        }
    }

    private static void setSortKey(Config c, String value) throws UsageException {
        if ("help".equalsIgnoreCase(value)) {
            c.sortHelp = true;
            c.sortKey = "PID";
            return;
        }
        String normalized = value.toUpperCase(Locale.ROOT);
        if (!SORT_KEYS.contains(normalized)) {
            throw new UsageException("Error: invalid column \"" + value + "\".");
        }
        c.sortKey = normalized;
    }

    private static Set<Long> parsePids(String value) throws UsageException {
        Set<Long> pids = new HashSet<>();
        for (String part : value.split(",")) {
            try {
                pids.add(Long.parseLong(part.trim()));
            } catch (NumberFormatException ex) {
                pids.add(0L);
            }
        }
        return pids;
    }

    private static void runScreen(Config config) throws UsageException {
        String term = System.getenv("TERM");
        if (term == null || term.isBlank() || "unknown".equals(term)) {
            throw new UsageException("Error opening terminal: unknown.");
        }
        int count = Math.max(1, config.iterations);
        for (int i = 0; i < count; i++) {
            printFrame(config);
            if (i + 1 < count) {
                try {
                    Thread.sleep(Math.max(1, Math.min(100, config.delayTenths)) * 100L);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    private static void printFrame(Config config) {
        List<Proc> procs = readProcesses(config);
        long totalMem = readMeminfo("MemTotal:");
        long freeMem = readMeminfo("MemAvailable:");
        long usedMem = Math.max(0, totalMem - freeMem);
        double load1 = 0, load5 = 0, load15 = 0;
        try {
            String[] parts = Files.readString(Path.of("/proc/loadavg")).trim().split("\\s+");
            load1 = Double.parseDouble(parts[0]);
            load5 = Double.parseDouble(parts[1]);
            load15 = Double.parseDouble(parts[2]);
        } catch (Exception ignored) {
        }
        System.out.printf("htop %s%n", VERSION.substring(5));
        System.out.printf("Tasks: %d, %d thr; %d running%n", procs.size(), procs.size(), procs.stream().filter(p -> "R".equals(p.state)).count());
        System.out.printf("Load average: %.2f %.2f %.2f%n", load1, load5, load15);
        System.out.printf("Mem: %s/%s%n", human(usedMem * 1024), human(totalMem * 1024));
        System.out.println("  PID USER       PRI  NI   VIRT    RES S  CPU% MEM%   TIME+  Command");
        int shown = 0;
        for (Proc p : procs) {
            if (shown++ >= 30) break;
            System.out.printf(Locale.ROOT, "%5d %-8s %3d %3d %6s %6s %s %5.1f %4.1f %8s %s%n",
                    p.pid, p.user, 20, 0, human(p.vsize), human(p.rss), p.state, 0.0, p.memPercent(totalMem), p.time, p.command);
        }
    }

    private static List<Proc> readProcesses(Config config) {
        List<Proc> out = new ArrayList<>();
        try (var paths = Files.list(Path.of("/proc"))) {
            paths.filter(p -> p.getFileName().toString().chars().allMatch(Character::isDigit)).forEach(p -> {
                Proc proc = readProc(p);
                if (proc == null) return;
                if (config.pids != null && !config.pids.contains(proc.pid)) return;
                if (config.filter != null && !proc.command.toLowerCase(Locale.ROOT).contains(config.filter)) return;
                if (config.user != null && !config.user.isBlank() && !proc.user.equals(config.user)) return;
                out.add(proc);
            });
        } catch (IOException ignored) {
        }
        Comparator<Proc> cmp = Comparator.comparingLong(p -> p.pid);
        if ("COMMAND".equals(config.sortKey) || "Command".equals(config.sortKey)) cmp = Comparator.comparing(p -> p.command);
        out.sort(cmp);
        return out;
    }

    private static Proc readProc(Path dir) {
        try {
            long pid = Long.parseLong(dir.getFileName().toString());
            String stat = Files.readString(dir.resolve("stat"), StandardCharsets.UTF_8);
            int close = stat.lastIndexOf(')');
            String comm = stat.substring(stat.indexOf('(') + 1, close);
            String[] parts = stat.substring(close + 2).split("\\s+");
            String state = parts[0];
            long utime = Long.parseLong(parts[11]);
            long stime = Long.parseLong(parts[12]);
            long vsize = Long.parseLong(parts[20]);
            long rssPages = Long.parseLong(parts[21]);
            long rss = rssPages * 4096L;
            String cmd = readCmdline(dir.resolve("cmdline"));
            if (cmd.isBlank()) cmd = comm;
            String user = readUid(dir.resolve("status"));
            return new Proc(pid, user, state, vsize, rss, formatTicks(utime + stime), cmd);
        } catch (Exception ex) {
            return null;
        }
    }

    private static String readCmdline(Path path) throws IOException {
        byte[] bytes = Files.readAllBytes(path);
        String s = new String(bytes, StandardCharsets.UTF_8).replace('\0', ' ').trim();
        return s;
    }

    private static String readUid(Path path) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("Uid:")) {
                    String uid = line.trim().split("\\s+")[1];
                    return userNameForUid(uid);
                }
            }
        }
        return "?";
    }

    private static String userNameForUid(String uid) {
        try (BufferedReader br = Files.newBufferedReader(Path.of("/etc/passwd"), StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length > 2 && parts[2].equals(uid)) return parts[0];
            }
        } catch (IOException ignored) {
        }
        return uid;
    }

    private static long readMeminfo(String key) {
        try (BufferedReader br = Files.newBufferedReader(Path.of("/proc/meminfo"), StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(key)) return Long.parseLong(line.replaceAll("[^0-9]", ""));
            }
        } catch (Exception ignored) {
        }
        return 0;
    }

    private static String human(long bytes) {
        if (bytes <= 0) return "0";
        String[] units = {"", "K", "M", "G", "T"};
        double n = bytes;
        int u = 0;
        while (n >= 1024 && u + 1 < units.length) {
            n /= 1024.0;
            u++;
        }
        if (u == 0) return Long.toString(bytes);
        if (n >= 10) return String.format(Locale.ROOT, "%.0f%s", n, units[u]);
        return String.format(Locale.ROOT, "%.1f%s", n, units[u]);
    }

    private static String formatTicks(long ticks) {
        long seconds = ticks / 100L;
        Duration d = Duration.ofSeconds(seconds);
        return String.format(Locale.ROOT, "%d:%02d.%02d", d.toMinutes(), d.toSecondsPart(), 0);
    }

    private static final class Config {
        boolean help;
        boolean version;
        boolean sortHelp;
        int iterations = 1;
        int delayTenths = 15;
        String filter;
        String sortKey = "PID";
        String user;
        Set<Long> pids;
    }

    private record Proc(long pid, String user, String state, long vsize, long rss, String time, String command) {
        double memPercent(long totalKb) {
            if (totalKb <= 0) return 0.0;
            return rss / (totalKb * 1024.0) * 100.0;
        }
    }

    private static final class UsageException extends Exception {
        UsageException(String message) {
            super(message);
        }
    }
}
