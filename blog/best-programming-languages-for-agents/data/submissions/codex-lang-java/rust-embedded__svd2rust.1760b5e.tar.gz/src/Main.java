import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Main {
    static final String VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)";

    static class Opt {
        String input, out = ".";
        boolean makeMod, skipAttrs, genericMod, featurePeripheral, featureGroup, implDebug;
        String target = "", edition = "2021", sourceType = "", log = "";
        long baseShift = 0;
    }

    static class Device {
        String name = "DEVICE", desc = "", width = "32";
        List<Peripheral> peripherals = new ArrayList<>();
        List<Interrupt> interrupts = new ArrayList<>();
    }
    static class Peripheral {
        String name, desc = "", group = "", base = "0";
        List<Register> registers = new ArrayList<>();
        List<Interrupt> interrupts = new ArrayList<>();
    }
    static class Register {
        String name, desc = "", access = "", reset = "0", size = "";
        long offset;
        List<Field> fields = new ArrayList<>();
    }
    static class Field {
        String name, desc = "", access = "";
        int bitOffset, bitWidth = 1;
        List<EnumVal> values = new ArrayList<>();
    }
    static class EnumVal { String name, desc = "", value = "0"; }
    static class Interrupt { String name, desc = ""; int value; }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            log("INFO", "svd2rust", "Parsing device from SVD file");
            Device d = readDevice(opt.input);
            log("INFO", "svd2rust", "Rendering device");
            render(d, opt);
        } catch (CliError e) {
            System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (FileNotFoundException | NoSuchFileException e) {
            log("ERROR", "svd2rust", "Cannot open the SVD file\n    \n    Caused by:\n        " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            log("ERROR", "svd2rust", "Error parsing SVD XML file\n    \n    Caused by:\n        " + e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": shortHelp(); return null;
                case "--help": longHelp(); return null;
                case "-V": case "--version": System.out.println(VERSION); return null;
                case "-i": o.input = need(args, ++i, a); break;
                case "-o": case "--output-dir": o.out = need(args, ++i, a); break;
                case "-c": case "--config": case "--settings": case "--atomics-feature":
                case "--impl-debug-feature": case "--impl-defmt": case "-f":
                case "--ident-format": case "--ident-formats-theme":
                    i++; break;
                case "--edition": o.edition = need(args, ++i, a); break;
                case "--target": o.target = need(args, ++i, a); break;
                case "--source-type": o.sourceType = need(args, ++i, a); break;
                case "-l": case "--log": o.log = need(args, ++i, a); break;
                case "-b": case "--base-address-shift": o.baseShift = parseNum(need(args, ++i, a)); break;
                case "-m": case "--make-mod": o.makeMod = true; break;
                case "--skip-crate-attributes": o.skipAttrs = true; break;
                case "-g": case "--generic-mod": o.genericMod = true; break;
                case "--feature-peripheral": o.featurePeripheral = true; break;
                case "--feature-group": o.featureGroup = true; break;
                case "--impl-debug": o.implDebug = true; break;
                case "--atomics": case "--ignore-groups": case "--keep-list":
                case "--field-names-for-enums": case "--max-cluster-size":
                case "-s": case "--strict": case "--reexport-core-peripherals":
                case "--reexport-interrupt": break;
                default:
                    if (a.startsWith("-")) throw new CliError("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", 2);
                    throw new CliError("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", 2);
            }
        }
        if (o.input == null) o.input = "";
        return o;
    }

    static String need(String[] a, int i, String opt) {
        if (i >= a.length) throw new CliError("error: a value is required for '" + opt + "' but none was supplied", 2);
        return a[i];
    }

    static void shortHelp() {
        System.out.println("Generate a Rust API from SVD files\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -i <FILE>\n          Input SVD file\n  -o, --output-dir <PATH>\n          Directory to place generated files\n  -c, --config <TOML_FILE>\n          Config TOML file\n      --settings <YAML_FILE>\n          Target-specific settings YAML file\n      --edition <YEAR>\n          Rust edition of generated code\n      --target <ARCH>\n          Target architecture\n      --atomics\n          Generate atomic register modification API\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version");
    }
    static void longHelp() {
        System.out.println("Generate a Rust API from SVD files\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -i <FILE>\n          Input SVD file\n\n  -o, --output-dir <PATH>\n          Directory to place generated files\n\n  -c, --config <TOML_FILE>\n          Config TOML file\n\n      --settings <YAML_FILE>\n          Target-specific settings YAML file\n\n      --edition <YEAR>\n          Rust edition of generated code\n\n      --target <ARCH>\n          Target architecture\n\n      --atomics\n          Generate atomic register modification API\n\n      --atomics-feature <FEATURE>\n          add feature gating for atomic register modification API\n\n      --ignore-groups\n          Don't add alternateGroup name as prefix to register name\n\n      --keep-list\n          Keep lists when generating code of dimElement, instead of trying to generate arrays\n\n  -g, --generic-mod\n          Push generic mod in separate file\n\n      --feature-group\n          Use group_name of peripherals as feature\n\n      --feature-peripheral\n          Use independent cfg feature flags for each peripheral\n\n  -f, --ident-format <ident_format>\n          Specify `-f type:prefix:case:suffix` to change default ident formatting.\n\n      --ident-formats-theme <THEME>\n          A set of `ident_format` settings. `new` or `legacy`\n\n      --field-names-for-enums\n          Use field name for enumerations even when enumeratedValues has a name\n\n      --max-cluster-size\n          Use array increment for cluster size\n\n      --impl-debug\n          implement Debug for readable blocks and registers\n\n      --impl-debug-feature <FEATURE>\n          Add feature gating for block and register debug implementation\n\n      --impl-defmt <FEATURE>\n          Add automatic defmt implementation for enumerated values\n\n  -m, --make-mod\n          Create mod.rs instead of lib.rs, without inner attributes\n\n      --skip-crate-attributes\n          Do not generate crate attributes\n\n  -s, --strict\n          Make advanced checks due to parsing SVD\n\n      --source-type <source_type>\n          Specify file/stream format\n\n      --reexport-core-peripherals\n          For Cortex-M target reexport peripherals from cortex-m crate\n\n      --reexport-interrupt\n          Reexport interrupt macro from cortex-m-rt like crates\n\n  -b, --base-address-shift <base_address_shift>\n          Add offset to all base addresses on all peripherals in the SVD file.\n\n  -l, --log <log_level>\n          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
    }

    static Device readDevice(String path) throws Exception {
        InputStream in = path.isEmpty() ? System.in : new FileInputStream(path);
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(false);
        try { f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false); } catch (Exception ignored) {}
        Document doc = f.newDocumentBuilder().parse(in);
        Element root = doc.getDocumentElement();
        Device d = new Device();
        d.name = text(root, "name", d.name);
        d.desc = text(root, "description", "");
        d.width = text(root, "width", "32");
        Element periphs = child(root, "peripherals");
        if (periphs != null) for (Element pe : children(periphs, "peripheral")) {
            Peripheral p = new Peripheral();
            p.name = text(pe, "name", "PERIPH");
            p.desc = text(pe, "description", p.name);
            p.group = text(pe, "groupName", "");
            p.base = text(pe, "baseAddress", "0");
            for (Element ie : children(pe, "interrupt")) {
                Interrupt it = new Interrupt();
                it.name = text(ie, "name", "INTERRUPT");
                it.desc = text(ie, "description", "");
                it.value = (int)parseNum(text(ie, "value", "0"));
                p.interrupts.add(it); d.interrupts.add(it);
            }
            Element regs = child(pe, "registers");
            if (regs != null) readRegisters(regs, p.registers, "");
            d.peripherals.add(p);
        }
        return d;
    }

    static void readRegisters(Element parent, List<Register> out, String prefix) {
        for (Element e : childElements(parent)) {
            String tag = clean(e.getTagName());
            if (tag.equals("register")) out.add(parseRegister(e, prefix));
            else if (tag.equals("cluster")) {
                String name = text(e, "name", "");
                Element regs = child(e, "registers");
                if (regs != null) readRegisters(regs, out, prefix + name + "_");
                else readRegisters(e, out, prefix + name + "_");
            }
        }
    }

    static Register parseRegister(Element e, String prefix) {
        Register r = new Register();
        r.name = prefix + text(e, "name", "REG");
        r.desc = text(e, "description", "");
        r.access = text(e, "access", "");
        r.size = text(e, "size", "");
        r.offset = parseNum(text(e, "addressOffset", "0"));
        r.reset = text(e, "resetValue", "0");
        Element fields = child(e, "fields");
        if (fields != null) for (Element fe : children(fields, "field")) {
            Field fld = new Field();
            fld.name = text(fe, "name", "FIELD");
            fld.desc = text(fe, "description", "");
            fld.access = text(fe, "access", "");
            if (child(fe, "bitOffset") != null) {
                fld.bitOffset = (int)parseNum(text(fe, "bitOffset", "0"));
                fld.bitWidth = (int)parseNum(text(fe, "bitWidth", "1"));
            } else if (child(fe, "lsb") != null) {
                int lsb = (int)parseNum(text(fe, "lsb", "0"));
                int msb = (int)parseNum(text(fe, "msb", "" + lsb));
                fld.bitOffset = lsb; fld.bitWidth = msb - lsb + 1;
            } else {
                String range = text(fe, "bitRange", "[0:0]").replace("[","").replace("]","");
                String[] parts = range.split(":");
                int msb = (int)parseNum(parts[0]), lsb = parts.length > 1 ? (int)parseNum(parts[1]) : msb;
                fld.bitOffset = lsb; fld.bitWidth = msb - lsb + 1;
            }
            Element evs = child(fe, "enumeratedValues");
            if (evs != null) for (Element ve : children(evs, "enumeratedValue")) {
                EnumVal v = new EnumVal();
                v.name = text(ve, "name", "VALUE");
                v.desc = text(ve, "description", "");
                v.value = text(ve, "value", "0");
                fld.values.add(v);
            }
            r.fields.add(fld);
        }
        return r;
    }

    static void render(Device d, Opt o) throws IOException {
        Path out = Paths.get(o.out);
        String rootName = o.makeMod ? "mod.rs" : "lib.rs";
        Files.writeString(out.resolve(rootName), generateLib(d, o), StandardCharsets.UTF_8);
        if (o.genericMod) Files.writeString(out.resolve("generic.rs"), genericRust(), StandardCharsets.UTF_8);
        Files.writeString(out.resolve("build.rs"), buildRs(), StandardCharsets.UTF_8);
        Files.writeString(out.resolve("device.x"), deviceX(d), StandardCharsets.UTF_8);
    }

    static String generateLib(Device d, Opt o) {
        StringBuilder s = new StringBuilder();
        if (!o.skipAttrs && !o.makeMod) {
            s.append("#![doc = \"Peripheral access API for ").append(esc(d.name)).append(" microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))\"]\n");
            s.append("#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n\n");
        }
        if (o.genericMod) s.append("pub mod generic;\npub use generic::*;\n\n");
        else s.append(genericRust()).append("\n");
        if (!d.interrupts.isEmpty()) renderInterrupts(s, d);
        for (Peripheral p : d.peripherals) renderPeripheral(s, p, o);
        s.append("#[allow(non_snake_case)]\npub struct Peripherals {\n");
        for (Peripheral p : d.peripherals) s.append("    #[doc = \"").append(esc(p.name)).append("\"] pub ").append(snake(p.name)).append(": ").append(pascal(p.name)).append(",\n");
        s.append("}\nstatic mut DEVICE_PERIPHERALS: bool = false;\nimpl Peripherals {\n    #[inline] pub fn take() -> Option<Self> { unsafe { if DEVICE_PERIPHERALS { None } else { Some(Self::steal()) } } }\n    #[doc = r\" Unchecked version of `Peripherals::take`.\"]\n    #[inline] pub unsafe fn steal() -> Self { DEVICE_PERIPHERALS = true; Self {");
        for (Peripheral p : d.peripherals) s.append(" ").append(snake(p.name)).append(": ").append(pascal(p.name)).append("::steal(),");
        s.append(" } }\n}\n");
        return s.toString();
    }

    static String genericRust() {
        return "use core::marker;\n" +
                "#[doc = \" Generic peripheral accessor\"] pub struct Periph<PER: PeripheralSpec> { _marker: marker::PhantomData<PER> }\n" +
                "pub trait PeripheralSpec { type RB; const ADDRESS: usize; const NAME: &'static str; }\n" +
                "unsafe impl<PER: PeripheralSpec> Send for Periph<PER> {}\n" +
                "impl<PER: PeripheralSpec> Periph<PER> { pub const PTR: *const PER::RB = PER::ADDRESS as *const _; #[inline(always)] pub const fn ptr() -> *const PER::RB { Self::PTR } pub unsafe fn steal() -> Self { Self { _marker: marker::PhantomData } } }\n" +
                "impl<PER: PeripheralSpec> core::ops::Deref for Periph<PER> { type Target = PER::RB; fn deref(&self) -> &Self::Target { unsafe { &*Self::PTR } } }\n" +
                "pub trait RegisterSpec { type Ux: Copy + From<u8> + core::fmt::Debug; }\n" +
                "pub trait Readable: RegisterSpec {}\n" +
                "pub trait Writable: RegisterSpec { type Safety; }\n" +
                "pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux; fn reset_value() -> Self::Ux { Self::RESET_VALUE } }\n" +
                "pub struct R<REG: RegisterSpec> { bits: REG::Ux }\n" +
                "impl<REG: RegisterSpec> R<REG> { pub const fn bits(&self) -> REG::Ux { self.bits } }\n" +
                "pub struct W<REG: RegisterSpec> { bits: REG::Ux }\n" +
                "impl<REG: Writable> W<REG> { pub unsafe fn bits(&mut self, bits: REG::Ux) -> &mut Self { self.bits = bits; self } }\n" +
                "pub struct FieldReader<FI = u8> { bits: FI }\n" +
                "impl<FI: Copy> FieldReader<FI> { pub const fn bits(&self) -> FI { self.bits } }\n" +
                "pub struct BitReader<FI = bool> { bits: bool, _p: marker::PhantomData<FI> }\n" +
                "impl<FI> BitReader<FI> { pub const fn bit(&self) -> bool { self.bits } pub const fn bit_is_clear(&self) -> bool { !self.bits } pub const fn bit_is_set(&self) -> bool { self.bits } }\n" +
                "pub struct FieldWriter<'a, REG: Writable, const WI: u8, FI = u8> { w: &'a mut W<REG>, o: u8, _p: marker::PhantomData<FI> }\n" +
                "pub struct BitWriter<'a, REG: Writable, FI = bool> { w: &'a mut W<REG>, o: u8, _p: marker::PhantomData<FI> }\n" +
                "impl<'a, REG: Writable, FI> BitWriter<'a, REG, FI> { pub fn set_bit(self) -> &'a mut W<REG> { self.w } pub fn clear_bit(self) -> &'a mut W<REG> { self.w } pub fn bit(self, _v: bool) -> &'a mut W<REG> { self.w } }\n" +
                "#[repr(transparent)] pub struct Reg<REG: RegisterSpec> { register: core::cell::UnsafeCell<REG::Ux> }\n" +
                "unsafe impl<REG: RegisterSpec> Sync for Reg<REG> {}\n" +
                "impl<REG: RegisterSpec> Reg<REG> { pub fn as_ptr(&self) -> *mut REG::Ux { self.register.get() } }\n" +
                "impl<REG: Readable> Reg<REG> { pub fn read(&self) -> R<REG> { R { bits: unsafe { *self.register.get() } } } }\n" +
                "impl<REG: Writable + Resettable> Reg<REG> { pub fn reset(&self) {} pub fn write<F>(&self, f: F) -> REG::Ux where F: FnOnce(&mut W<REG>) -> &mut W<REG> { let mut w = W { bits: REG::RESET_VALUE }; f(&mut w); w.bits } }\n" +
                "impl<REG: Readable + Writable> Reg<REG> { pub fn modify<F>(&self, f: F) -> REG::Ux where F: for<'w> FnOnce(&R<REG>, &'w mut W<REG>) -> &'w mut W<REG> { let r = self.read(); let mut w = W { bits: r.bits }; f(&r, &mut w); w.bits } }\n" +
                "pub struct Safe; pub struct Unsafe;\n";
    }

    static void renderPeripheral(StringBuilder s, Peripheral p, Opt o) {
        String P = pascal(p.name), mod = snake(p.name);
        long addr = parseNum(p.base) + o.baseShift;
        s.append("#[doc = \"").append(esc(empty(p.desc, p.name))).append("\"] pub type ").append(P).append(" = crate::Periph<").append(P).append("Spec>;\n");
        s.append("pub struct ").append(P).append("Spec;\nimpl crate::PeripheralSpec for ").append(P).append("Spec { type RB = ").append(mod).append("::RegisterBlock; const ADDRESS: usize = ").append(hex(addr)).append("; const NAME: &'static str = \"").append(P).append("\"; }\n");
        s.append("#[doc = \"").append(esc(p.name)).append("\"] pub mod ").append(mod).append(" {\n    use crate::*;\n    #[repr(C)]\n    #[doc = \"Register block\"]\n    pub struct RegisterBlock {\n");
        long cur = 0; int res = 0;
        for (Register r : p.registers) {
            if (r.offset > cur) { s.append("        _reserved").append(res++).append(": [u8; ").append(r.offset-cur).append("],\n"); cur = r.offset; }
            s.append("        pub ").append(snake(r.name)).append(": ").append(pascal(r.name)).append(",\n");
            cur += Math.max(1, parseNum(empty(r.size, "32")) / 8);
        }
        s.append("    }\n");
        for (Register r : p.registers) renderRegister(s, r);
        s.append("}\n");
    }

    static void renderRegister(StringBuilder s, Register r) {
        String R = pascal(r.name), mod = snake(r.name);
        boolean rd = readable(r), wr = writable(r);
        if (r.desc.isEmpty()) log("WARN", "svd2rust::generate::register", "Missing description for register " + r.name);
        s.append("    #[doc = \"").append(esc(r.name)).append(" (").append(rd && wr ? "rw" : rd ? "r" : wr ? "w" : "").append(") register accessor: ").append(esc(r.desc)).append("\"]\n");
        s.append("    #[doc(alias = \"").append(esc(r.name)).append("\")] pub type ").append(R).append(" = crate::Reg<").append(mod).append("::").append(R).append("Spec>;\n");
        s.append("    pub mod ").append(mod).append(" {\n        use crate::*;\n");
        if (rd) s.append("        #[doc = \"Register `").append(esc(r.name)).append("` reader\"] pub type R = crate::R<").append(R).append("Spec>;\n");
        if (wr) s.append("        #[doc = \"Register `").append(esc(r.name)).append("` writer\"] pub type W = crate::W<").append(R).append("Spec>;\n");
        for (Field f : r.fields) {
            String F = pascal(f.name);
            s.append("        #[doc = \"Field `").append(esc(f.name)).append("` reader - ").append(esc(f.desc)).append("\"] pub type ").append(F).append("R = crate::").append(f.bitWidth == 1 ? "BitReader" : "FieldReader").append(";\n");
            if (wr) s.append("        #[doc = \"Field `").append(esc(f.name)).append("` writer - ").append(esc(f.desc)).append("\"] pub type ").append(F).append("W<'a, REG> = crate::").append(f.bitWidth == 1 ? "BitWriter<'a, REG>" : "FieldWriter<'a, REG, " + f.bitWidth + ">").append(";\n");
            if (!f.values.isEmpty()) {
                s.append("        #[derive(Clone, Copy, Debug, PartialEq, Eq)] #[repr(u8)] pub enum ").append(F).append(" {");
                for (EnumVal v : f.values) s.append(" ").append(pascal(v.name)).append(" = ").append(parseNum(v.value)).append(",");
                s.append(" }\n");
            }
        }
        s.append("        pub struct ").append(R).append("Spec;\n        impl crate::RegisterSpec for ").append(R).append("Spec { type Ux = u").append(regSize(r)).append("; }\n");
        if (rd) s.append("        impl crate::Readable for ").append(R).append("Spec {}\n");
        if (wr) s.append("        impl crate::Writable for ").append(R).append("Spec { type Safety = crate::Unsafe; }\n");
        s.append("        #[doc = \"`reset()` method sets ").append(esc(r.name)).append(" to value ").append(hex(parseNum(r.reset))).append("\"] impl crate::Resettable for ").append(R).append("Spec { const RESET_VALUE: u").append(regSize(r)).append(" = ").append(hex(parseNum(r.reset))).append("; }\n");
        s.append("    }\n");
    }

    static void renderInterrupts(StringBuilder s, Device d) {
        int max = 0; for (Interrupt i : d.interrupts) max = Math.max(max, i.value);
        s.append("#[cfg(feature = \"rt\")] extern \"C\" {\n");
        for (Interrupt i : d.interrupts) s.append("    fn ").append(i.name).append("();\n");
        s.append("}\n#[repr(C)] pub union Vector { _handler: unsafe extern \"C\" fn(), _reserved: u32 }\n");
        s.append("#[cfg(feature = \"rt\")] #[link_section = \".vector_table.interrupts\"] #[no_mangle] pub static __INTERRUPTS: [Vector; ").append(max+1).append("] = [");
        Map<Integer,String> by = new HashMap<>(); for (Interrupt i : d.interrupts) by.put(i.value, i.name);
        for (int n=0;n<=max;n++) s.append(by.containsKey(n) ? "Vector { _handler: "+by.get(n)+" }," : "Vector { _reserved: 0 },");
        s.append("];\n#[repr(u16)] pub enum Interrupt {\n");
        for (Interrupt i : d.interrupts) s.append("    #[doc = \"").append(i.value).append(" - ").append(esc(i.desc)).append("\"] ").append(i.name).append(" = ").append(i.value).append(",\n");
        s.append("}\n");
    }

    static String buildRs() { return "#![doc = r\" Builder file for Peripheral access crate generated by svd2rust tool\"]\nuse std::{env,fs::File,io::Write,path::PathBuf};\nfn main(){ if env::var_os(\"CARGO_FEATURE_RT\").is_some(){ let out=&PathBuf::from(env::var_os(\"OUT_DIR\").unwrap()); File::create(out.join(\"device.x\")).unwrap().write_all(include_bytes!(\"device.x\")).unwrap(); println!(\"cargo:rustc-link-search={}\", out.display()); println!(\"cargo:rerun-if-changed=device.x\"); } println!(\"cargo:rerun-if-changed=build.rs\"); }\n"; }
    static String deviceX(Device d) { StringBuilder s = new StringBuilder(); for (Interrupt i : d.interrupts) s.append("PROVIDE(").append(i.name).append(" = DefaultHandler);\n"); if (s.length()==0) s.append("\n"); return s.toString(); }

    static boolean readable(Register r) { String a = r.access.toLowerCase(Locale.ROOT); return a.isEmpty() || a.contains("read"); }
    static boolean writable(Register r) { String a = r.access.toLowerCase(Locale.ROOT); return a.isEmpty() || a.contains("write"); }
    static int regSize(Register r) { long n = parseNum(empty(r.size, "32")); if (n <= 8) return 8; if (n <= 16) return 16; if (n <= 32) return 32; return 64; }

    static List<Element> children(Element e, String name) { List<Element> r = new ArrayList<>(); for (Element c : childElements(e)) if (clean(c.getTagName()).equals(name)) r.add(c); return r; }
    static List<Element> childElements(Element e) { List<Element> r = new ArrayList<>(); NodeList nl=e.getChildNodes(); for(int i=0;i<nl.getLength();i++) if(nl.item(i) instanceof Element) r.add((Element)nl.item(i)); return r; }
    static Element child(Element e, String name) { for (Element c : childElements(e)) if (clean(c.getTagName()).equals(name)) return c; return null; }
    static String text(Element e, String name, String def) { Element c = child(e, name); if (c == null) return def; String t = c.getTextContent(); return t == null || t.trim().isEmpty() ? def : t.trim(); }
    static String clean(String tag) { int i = tag.indexOf(':'); return i >= 0 ? tag.substring(i+1) : tag; }
    static long parseNum(String v) { if (v == null) return 0; String s=v.trim().replace("_",""); if (s.isEmpty()) return 0; if (s.equalsIgnoreCase("true")) return 1; if (s.equalsIgnoreCase("false")) return 0; if (s.startsWith("#")) s=s.substring(1); if (s.startsWith("0x")||s.startsWith("0X")) return Long.parseUnsignedLong(s.substring(2),16); if (s.startsWith("0b")||s.startsWith("0B")) return Long.parseUnsignedLong(s.substring(2),2); return Long.parseLong(s); }
    static String snake(String x) { return words(x).stream().map(String::toLowerCase).reduce((a,b)->a+"_"+b).orElse("x"); }
    static String pascal(String x) { StringBuilder s=new StringBuilder(); for(String w:words(x)){ if(w.isEmpty())continue; s.append(Character.toUpperCase(w.charAt(0))).append(w.length()>1?w.substring(1).toLowerCase(Locale.ROOT):""); } return s.length()==0?"X":s.toString(); }
    static List<String> words(String x) { String y=x.replaceAll("%s","").replaceAll("[^A-Za-z0-9]+"," ").trim(); if(y.isEmpty()) return List.of("x"); return Arrays.asList(y.split("\\s+")); }
    static String hex(long v) { if (v == 0) return "0"; String h=Long.toHexString(v); StringBuilder b=new StringBuilder("0x"); for(int i=0;i<h.length();i++){ if(i>0 && (h.length()-i)%4==0) b.append('_'); b.append(h.charAt(i)); } return b.toString(); }
    static String esc(String s) { return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n"); }
    static String empty(String s, String d) { return s == null || s.isEmpty() ? d : s; }
    static void log(String lvl, String target, String msg) { System.err.println("[" + lvl + "  " + target + "] " + msg); }
    static class CliError extends RuntimeException { int code; CliError(String m,int c){super(m);code=c;} }
}
