import java.io.*;
import java.nio.file.*;
import java.util.*;

public class RunKit {
    static final String[] LANGS = {"bash","c","cpp","crystal","csharp","dart","elixir","go","groovy","haskell","java","javascript","julia","kotlin","lua","nim","perl","php","python","r","ruby","rust","swift","typescript","zig"};
    static class Opt { String lang, file, code; boolean noDetect, help, version; List<String> pos = new ArrayList<>(); }

    public static void main(String[] args) throws Exception {
        Opt o;
        try { o = parse(args); } catch (ArgError e) { System.err.print(e.getMessage()); System.exit(2); return; }
        if (o.help) { printHelp(); return; }
        if (o.version) { printVersion(); return; }
        int rc = run(o);
        System.exit(rc);
    }

    static class ArgError extends Exception { ArgError(String m) { super(m); } }

    static Opt parse(String[] args) throws ArgError {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) { for (int j=i+1;j<args.length;j++) o.pos.add(args[j]); break; }
            switch (a) {
                case "-h": case "--help": o.help = true; break;
                case "-V": case "--version": o.version = true; break;
                case "--no-detect": o.noDetect = true; break;
                case "-l": case "--lang":
                    if (++i >= args.length) throw new ArgError("error: a value is required for '--lang <LANG>' but none was supplied\n\nFor more information, try '--help'.\n");
                    o.lang = args[i]; break;
                case "-f": case "--file":
                    if (++i >= args.length) throw new ArgError("error: a value is required for '--file <PATH>' but none was supplied\n\nFor more information, try '--help'.\n");
                    o.file = args[i]; break;
                case "-c": case "--code":
                    if (++i >= args.length) throw new ArgError("error: a value is required for '--code <CODE>' but none was supplied\n\nFor more information, try '--help'.\n");
                    o.code = args[i]; break;
                default:
                    if (a.startsWith("-")) throw new ArgError("error: unexpected argument '"+a+"' found\n\n  tip: to pass '"+a+"' as a value, use '-- "+a+"'\n\nUsage: executable [OPTIONS] [ARGS]...\n\nFor more information, try '--help'.\n");
                    o.pos.add(a);
            }
        }
        return o;
    }

    static int run(Opt o) throws Exception {
        if (o.code != null && !o.pos.isEmpty()) { System.err.println("Error: Unexpected positional arguments after specifying --code"); return 1; }
        if (o.file != null && !o.pos.isEmpty()) { System.err.println("Error: Unexpected positional arguments when --file is present"); return 1; }
        String lang = o.lang;
        String code = o.code;
        String file = o.file;
        if (code == null && file == null && !o.pos.isEmpty()) {
            if (o.pos.size() == 1) {
                String p = o.pos.get(0);
                if (Files.exists(Paths.get(p))) file = p; else { lang = p; code = ""; }
            } else if (o.pos.size() == 2) {
                lang = o.pos.get(0); code = o.pos.get(1);
            } else {
                return pythonUnavailable();
            }
        }
        if (lang == null) {
            if (o.noDetect) lang = "python";
            else if (file != null) lang = detectFile(file);
            else if (code != null) lang = detectCode(code);
            else lang = "python";
        }
        lang = normalize(lang);
        if (!isKnown(lang)) { System.err.println("Error: Unknown language '"+lang+"'. Available languages: "+String.join(", ", LANGS)); return 1; }
        switch (lang) {
            case "java": return runJava(code, file);
            case "bash": return runBash(code, file);
            case "c": return runC(code, file, false);
            case "cpp": return runC(code, file, true);
            case "python": return pythonUnavailable();
            case "go": System.err.println("Error: Go support requires the `go` executable. Install it from https://go.dev/dl/ and ensure it is on your PATH."); return 1;
            case "rust": System.err.println("Error: Rust support requires the `rustc` executable. Install it via Rustup and ensure it is on your PATH."); return 1;
            case "lua": System.err.println("Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH."); return 1;
            case "javascript": case "typescript": case "ruby": return 127;
            default: return 127;
        }
    }

    static String normalize(String s) {
        String l = s.toLowerCase(Locale.ROOT);
        if (l.equals("sh") || l.equals("shell")) return "bash";
        if (l.equals("js") || l.equals("node")) return "javascript";
        if (l.equals("ts")) return "typescript";
        if (l.equals("py")) return "python";
        if (l.equals("cc") || l.equals("cxx") || l.equals("c++")) return "cpp";
        return l;
    }
    static boolean isKnown(String l) { for (String s: LANGS) if (s.equals(l)) return true; return false; }
    static String detectFile(String f) {
        String n = f.toLowerCase(Locale.ROOT);
        if (n.endsWith(".java")) return "java";
        if (n.endsWith(".sh") || n.endsWith(".bash")) return "bash";
        if (n.endsWith(".c")) return "c";
        if (n.endsWith(".cpp") || n.endsWith(".cc") || n.endsWith(".cxx") || n.endsWith(".hpp")) return "cpp";
        if (n.endsWith(".py")) return "python";
        if (n.endsWith(".lua")) return "lua";
        if (n.endsWith(".js")) return "javascript";
        return "python";
    }
    static String detectCode(String c) {
        String t = c.trim();
        if (t.startsWith("#!") && t.contains("bash")) return "bash";
        if (t.startsWith("echo ") || t.startsWith("printf ")) return "bash";
        if (t.contains("#include") || t.matches("(?s).*\\bint\\s+main\\s*\\(.*")) return t.contains("iostream") || t.contains("std::") ? "cpp" : "c";
        if (t.startsWith("print(") || t.contains(" print(")) return "lua";
        if (t.contains("console.log")) return "javascript";
        return "python";
    }
    static int pythonUnavailable() { System.err.println("python is not available in the java-mandated arm"); return 127; }

    static int runJava(String code, String file) throws Exception {
        Path dir = Files.createTempDirectory("run-java");
        Path src;
        if (file != null) {
            Path in = Paths.get(file);
            src = dir.resolve(in.getFileName().toString());
            try { Files.copy(in, src, StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException e) { System.err.println("Error: failed to copy Java source from "+file+" to "+src); System.err.println("\nCaused by:\n    "+e.getMessage()); return 1; }
        } else {
            src = dir.resolve("Main.java");
            String text = code == null ? "" : code;
            if (!text.contains("class ") && !text.trim().startsWith("import ")) text = "public class Main {\n    public static void main(String[] args) throws Exception {\n        "+text+"\n    }\n}\n";
            Files.writeString(src, text);
        }
        int rc = exec(Arrays.asList("javac", src.toString()), dir);
        if (rc != 0) return rc;
        String main = "Main";
        if (file != null) main = classNameFromJavaFile(Paths.get(file));
        return exec(Arrays.asList("java", "-cp", dir.toString(), main), dir);
    }
    static String classNameFromJavaFile(Path p) { String n = p.getFileName().toString(); return n.endsWith(".java") ? n.substring(0, n.length()-5) : n; }

    static int runBash(String code, String file) throws Exception {
        if (file != null) return exec(Arrays.asList("bash", file), Paths.get("."));
        return exec(Arrays.asList("bash", "-c", code == null ? "" : code), Paths.get("."));
    }
    static int runC(String code, String file, boolean cpp) throws Exception {
        Path dir = Files.createTempDirectory(cpp ? "run-cpp" : "run-c");
        Path src = dir.resolve(cpp ? "main.cpp" : "main.c");
        if (file != null) Files.copy(Paths.get(file), src, StandardCopyOption.REPLACE_EXISTING); else Files.writeString(src, code == null ? "" : code);
        Path out = dir.resolve("a.out");
        List<String> cmd = new ArrayList<>(); cmd.add(cpp ? "g++" : "gcc"); cmd.add(src.toString()); cmd.add("-o"); cmd.add(out.toString());
        int rc = exec(cmd, dir); if (rc != 0) return rc;
        return exec(Arrays.asList(out.toString()), dir);
    }
    static int exec(List<String> cmd, Path cwd) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd); pb.directory(cwd.toFile()); pb.inheritIO();
        Process p = pb.start(); return p.waitFor();
    }

    static void printHelp() {
        System.out.print("Universal multi-language runner and REPL\n\n"+
            "Usage: executable [OPTIONS] [ARGS]...\n\n"+
            "Arguments:\n  [ARGS]...  Positional arguments (language, code, or file)\n\n"+
            "Options:\n  -V, --version      Print version information and exit\n  -l, --lang <LANG>  Explicitly choose the language to execute\n  -f, --file <PATH>  Execute code from the provided file path\n  -c, --code <CODE>  Execute the provided code snippet\n      --no-detect    Disable heuristic language detection\n  -h, --help         Print help\n");
    }
    static void printVersion() {
        System.out.print("run-kit 0.3.2\nUniversal multi-language runner and smart REPL\nauthor: Esubalew Chekol <esubalewchekol6@gmail.com>\nhomepage: https://esubalew.et\nrepository: https://github.com/Esubaalew/run\nlicense: Apache-2.0\ncommit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)\nbuilt: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]\nrustc: rustc 1.92.0 (ded5c06cf 2025-12-08)\n");
    }
}
