import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Pattern;

public class Gdu {
    static class Opt {
        boolean apparent, followLinks, noHidden, summarize, noPrefix, si, kib, reverse, showDisks, version, help;
        boolean outputJsonOnly;
        int depth = 0, top = 0;
        String outputFile, inputFile;
        List<String> includeTypes = new ArrayList<>(), excludeTypes = new ArrayList<>();
        List<Pattern> ignorePatterns = new ArrayList<>();
        List<String> paths = new ArrayList<>();
    }

    static class Node {
        Path path;
        String name;
        boolean dir, symlink, error, empty;
        long asize, dsize, mtime;
        List<Node> children = new ArrayList<>();
        long size(Opt o) { return o.apparent ? asize : dsize; }
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o.help) { help(); return; }
            if (o.version) { version(); return; }
            if (o.showDisks) { disks(); return; }
            if (o.inputFile != null) {
                Node n = JsonImport.parse(Files.readString(Path.of(o.inputFile)));
                print(n, o, o.depth > 0 || o.top > 0);
                return;
            }
            Path root = Path.of(o.paths.isEmpty() ? "." : o.paths.get(0));
            if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) {
                System.err.println("Error: stat " + root + ": no such file or directory");
                System.exit(1);
            }
            Node n = scan(root.toAbsolutePath().normalize(), o);
            if (o.outputFile != null) {
                Files.writeString(Path.of(o.outputFile), JsonExport.write(n), StandardCharsets.UTF_8);
                return;
            }
            print(n, o, o.depth > 0 || o.top > 0);
        } catch (BadUsage e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class BadUsage extends RuntimeException { BadUsage(String m) { super(m); } }

    static Opt parse(String[] args) throws IOException {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) { while (++i < args.length) o.paths.add(args[i]); break; }
            if (!a.startsWith("-") || a.equals("-")) { o.paths.add(a); continue; }
            if (a.startsWith("--")) {
                String key = a, val = null;
                int eq = a.indexOf('=');
                if (eq >= 0) { key = a.substring(0, eq); val = a.substring(eq + 1); }
                switch (key) {
                    case "--help": o.help = true; break;
                    case "--version": o.version = true; break;
                    case "--show-apparent-size": o.apparent = true; break;
                    case "--follow-symlinks": o.followLinks = true; break;
                    case "--no-hidden": o.noHidden = true; break;
                    case "--summarize": o.summarize = true; break;
                    case "--no-prefix": o.noPrefix = true; break;
                    case "--si": o.si = true; break;
                    case "--show-in-kib": o.kib = true; break;
                    case "--reverse-sort": o.reverse = true; break;
                    case "--show-disks": o.showDisks = true; break;
                    case "--no-progress": case "--non-interactive": case "--no-color": case "--no-unicode":
                    case "--mouse": case "--sequential": case "--no-cross": case "--no-delete":
                    case "--no-spawn-shell": case "--archive-browsing": case "--collapse-path":
                    case "--show-item-count": case "--show-mtime": case "--show-relative-size":
                    case "--show-annexed-size": case "--read-from-storage": case "--enable-profiling":
                    case "--use-git-ignore": break;
                    case "--write-config": writeConfig(); System.exit(0); break;
                    case "--depth": o.depth = Integer.parseInt(value(args, ++i, val, key)); break;
                    case "--top": o.top = Integer.parseInt(value(args, ++i, val, key)); break;
                    case "--output-file": o.outputFile = value(args, ++i, val, key); break;
                    case "--input-file": o.inputFile = value(args, ++i, val, key); break;
                    case "--type": addCsv(o.includeTypes, value(args, ++i, val, key)); break;
                    case "--exclude-type": addCsv(o.excludeTypes, value(args, ++i, val, key)); break;
                    case "--ignore-dirs-pattern": addPattern(o, value(args, ++i, val, key)); break;
                    case "--ignore-from": readPatterns(o, value(args, ++i, val, key)); break;
                    case "--config-file": case "--log-file": case "--max-cores": case "--ignore-dirs":
                    case "--db": case "--storage": case "--style": case "--since": case "--until":
                    case "--max-age": case "--min-age":
                        value(args, ++i, val, key); break;
                    default: throw new BadUsage("unknown flag: " + key);
                }
            } else {
                for (int j = 1; j < a.length(); j++) {
                    char c = a.charAt(j);
                    switch (c) {
                        case 'h': o.help = true; break;
                        case 'v': o.version = true; break;
                        case 'a': o.apparent = true; break;
                        case 'L': o.followLinks = true; break;
                        case 'H': o.noHidden = true; break;
                        case 's': o.summarize = true; break;
                        case 'k': o.kib = true; break;
                        case 'd': o.showDisks = true; break;
                        case 'p': case 'n': case 'c': case 'u': case 'x': case 'A':
                        case 'C': case 'M': case 'B': case 'S': case 'g': break;
                        case 'r': break;
                        case 'o': o.outputFile = restOrNext(a, args, i, j); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'f': o.inputFile = restOrNext(a, args, i, j); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 't': o.top = Integer.parseInt(restOrNext(a, args, i, j)); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'T': addCsv(o.includeTypes, restOrNext(a, args, i, j)); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'E': addCsv(o.excludeTypes, restOrNext(a, args, i, j)); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'I': addPattern(o, restOrNext(a, args, i, j)); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'X': readPatterns(o, restOrNext(a, args, i, j)); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'i': restOrNext(a, args, i, j); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        case 'D': case 'l': case 'm':
                            restOrNext(a, args, i, j); i += (j == a.length()-1 ? 1 : 0); j = a.length(); break;
                        default: throw new BadUsage("unknown shorthand flag: '" + c + "' in " + a);
                    }
                }
            }
        }
        return o;
    }

    static String value(String[] args, int idx, String val, String key) {
        if (val != null) return val;
        if (idx >= args.length) throw new BadUsage("flag needs an argument: " + key);
        return args[idx];
    }
    static String restOrNext(String a, String[] args, int i, int j) {
        if (j + 1 < a.length()) return a.substring(j + 1);
        if (i + 1 >= args.length) throw new BadUsage("flag needs an argument: " + a.charAt(j));
        return args[i + 1];
    }
    static void addCsv(List<String> list, String s) { for (String p: s.split(",")) if (!p.isEmpty()) list.add(p.toLowerCase()); }
    static void addPattern(Opt o, String s) { for (String p: s.split(",")) if (!p.isEmpty()) o.ignorePatterns.add(Pattern.compile(p)); }
    static void readPatterns(Opt o, String f) throws IOException { for (String l: Files.readAllLines(Path.of(f))) if (!l.isBlank()) o.ignorePatterns.add(Pattern.compile(l.trim())); }

    static Node scan(Path p, Opt o) {
        Node n = new Node();
        n.path = p; n.name = p.getFileName() == null ? p.toString() : p.getFileName().toString();
        try {
            BasicFileAttributes ba = Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
            n.symlink = ba.isSymbolicLink();
            n.dir = ba.isDirectory();
            Stat st = stat(p, false);
            n.asize = st.size; n.dsize = n.symlink && !o.followLinks ? 0 : st.blocks * 512L; n.mtime = st.mtime;
            if (n.symlink && o.followLinks) {
                try { Stat fs = stat(p, true); n.asize = fs.size; n.dsize = fs.blocks * 512L; } catch (Exception ignored) {}
            }
            if (n.dir) {
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(p)) {
                    for (Path c : ds) {
                        String nm = c.getFileName().toString();
                        if (o.noHidden && nm.startsWith(".")) continue;
                        if (ignored(c, o)) continue;
                        boolean isDir = Files.isDirectory(c, LinkOption.NOFOLLOW_LINKS);
                        if (!isDir && !typeAllowed(nm, o)) continue;
                        Node child = scan(c, o);
                        n.children.add(child);
                        n.asize += child.asize; n.dsize += child.dsize; n.mtime = Math.max(n.mtime, child.mtime);
                    }
                } catch (Exception e) { n.error = true; }
                n.empty = n.children.isEmpty();
            }
        } catch (Exception e) { n.error = true; }
        n.children.sort((a,b) -> {
            int r = Integer.compare(rank(a, o), rank(b, o));
            if (r == 0) r = Long.compare(b.size(o), a.size(o));
            if (r == 0) r = Integer.compare(category(a, o), category(b, o));
            if (r == 0) r = b.name.compareTo(a.name);
            return o.reverse ? -r : r;
        });
        return n;
    }

    static int rank(Node n, Opt o) {
        if (n.symlink && !o.followLinks) return 2;
        if (n.name.startsWith(".")) return 1;
        return 0;
    }

    static int category(Node n, Opt o) {
        if (n.symlink && !o.followLinks) return 3;
        if (n.name.startsWith(".")) return 2;
        if (n.dir) return 0;
        return 1;
    }

    static boolean ignored(Path p, Opt o) {
        String s = p.toString();
        for (Pattern pat : o.ignorePatterns) if (pat.matcher(s).find()) return true;
        return false;
    }
    static boolean typeAllowed(String name, Opt o) {
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot >= 0 && dot + 1 < name.length()) ext = name.substring(dot + 1).toLowerCase();
        if (!o.includeTypes.isEmpty() && !o.includeTypes.contains(ext)) return false;
        return !o.excludeTypes.contains(ext);
    }

    static class Stat { long blocks, size, mtime; }
    static Stat stat(Path p, boolean follow) throws IOException, InterruptedException {
        List<String> cmd = new ArrayList<>();
        cmd.add("stat"); if (!follow) cmd.add("-L".equals("") ? "" : "-c"); else cmd.add("-Lc");
        if (!follow) cmd.add("%b %s %Y"); else cmd.add("%b %s %Y");
        cmd.add(p.toString());
        cmd.removeIf(String::isEmpty);
        Process pr = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String out = new String(pr.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
        if (pr.waitFor() != 0) throw new IOException(out);
        String[] parts = out.split("\\s+");
        Stat s = new Stat(); s.blocks = Long.parseLong(parts[0]); s.size = Long.parseLong(parts[1]); s.mtime = Long.parseLong(parts[2]);
        return s;
    }

    static void print(Node root, Opt o, boolean full) {
        if (o.summarize) { line(root, o, root.name, false); return; }
        if (o.top > 0) {
            List<Node> all = new ArrayList<>(); collectFiles(root, all);
            all.sort((a,b)-> {
                int r = Long.compare(b.size(o), a.size(o));
                if (r == 0) r = b.path.toString().compareTo(a.path.toString());
                return r;
            });
            if (o.reverse) Collections.reverse(all);
            for (int i=0; i<Math.min(o.top, all.size()); i++) line(all.get(i), o, all.get(i).path.toString(), false);
            return;
        }
        if (o.depth > 0) { printDepth(root, o, 0); return; }
        for (Node c : root.children) line(c, o, displayName(c), true);
    }
    static void printDepth(Node n, Opt o, int level) {
        line(n, o, n.path.toString(), false);
        if (level >= o.depth) return;
        for (Node c : n.children) printDepth(c, o, level + 1);
    }
    static void collectFiles(Node n, List<Node> all) {
        if (!n.dir) all.add(n);
        for (Node c: n.children) collectFiles(c, all);
    }
    static String displayName(Node n) { return n.dir ? "/" + n.name : n.name; }
    static void line(Node n, Opt o, String name, boolean flag) {
        char f = ' ';
        if (flag) {
            if (n.error) f = '!';
            else if (n.symlink && !o.followLinks) f = '@';
            else if (n.dir && n.empty) f = 'e';
        }
        System.out.printf("%c%10s %s%n", f, fmt(n.size(o), o), name);
    }
    static String fmt(long b, Opt o) {
        if (o.noPrefix) return Long.toString(b);
        if (o.kib) return String.format(Locale.US, "%.1f %s", b / 1024.0, o.si ? "kB" : "KiB");
        double base = o.si ? 1000.0 : 1024.0;
        String[] u = o.si ? new String[]{"B","kB","MB","GB","TB","PB"} : new String[]{"B","KiB","MiB","GiB","TiB","PiB"};
        if (b == 0) return "0 B";
        double v = b; int i = 0;
        while (Math.abs(v) >= base && i < u.length - 1) { v /= base; i++; }
        return i == 0 ? String.format(Locale.US, "%d B", b) : String.format(Locale.US, "%.1f %s", v, u[i]);
    }

    static void help() {
        System.out.println("Pretty fast disk usage analyzer written in Go.\n\nGdu is intended primarily for SSD disks where it can fully utilize parallel processing.\nHowever HDDs work as well, but the performance gain is not so huge.\n\nUsage:\n  gdu [directory_to_scan] [flags]\n\nFlags:\n      --archive-browsing              Enable browsing of zip/jar archives\n      --collapse-path                 Collapse single-child directory chains\n      --config-file string            Read config from file (default is $HOME/.gdu.yaml)\n  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)\n      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)\n  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)\n  -L, --follow-symlinks               Follow symlinks for files\n  -h, --help                          help for gdu\n  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])\n  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)\n  -X, --ignore-from string            Read path patterns to ignore from file\n  -f, --input-file string             Import analysis from JSON file\n  -l, --log-file string               Path to a logfile (default \"/dev/null\")\n      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)\n      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)\n  -c, --no-color                      Do not use colorized output\n  -x, --no-cross                      Do not cross filesystem boundaries\n  -H, --no-hidden                     Ignore hidden directories (beginning with dot)\n      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode\n  -p, --no-progress                   Do not show progress in non-interactive mode\n  -u, --no-unicode                    Do not use Unicode symbols (for size bar)\n  -n, --non-interactive               Do not run in interactive mode\n  -o, --output-file string            Export all info into file as JSON\n  -r, --read-from-storage             Use existing database instead of re-scanning\n      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode\n      --sequential                    Use sequential scanning (intended for rotating HDDs)\n  -a, --show-apparent-size            Show apparent size\n  -d, --show-disks                    Show all mounted disks\n  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode\n  -C, --show-item-count               Show number of items in directory\n  -M, --show-mtime                    Show latest mtime of items in directory\n  -B, --show-relative-size            Show relative size\n      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)\n  -s, --summarize                     Show only a total in non-interactive mode\n  -t, --top int                       Show only top X largest files in non-interactive mode\n  -T, --type strings                  File types to include (e.g., --type yaml,json)\n      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD\n  -v, --version                       Print version\n      --write-config                  Write current configuration to file");
    }
    static void version() {
        System.out.println("Version:\t dev\nBuilt time:\t Fri Apr 17 19:59:35 UTC 2026\nBuilt user:\t root");
    }
    static void disks() throws IOException, InterruptedException {
        Process p = new ProcessBuilder("df", "-h").redirectErrorStream(true).start();
        System.out.println("   Device      Size      Used      Free Used% Mount point");
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String l; boolean first = true;
            while ((l = br.readLine()) != null) {
                if (first) { first = false; continue; }
                String[] s = l.trim().split("\\s+");
                if (s.length >= 6) System.out.printf("%9s %9s %9s %9s %5s %s%n", s[0], s[1], s[2], s[3], s[4], s[5]);
            }
        }
        p.waitFor();
    }
    static void writeConfig() throws IOException {
        String home = System.getenv().getOrDefault("HOME", ".");
        Path p = Path.of(home, ".gdu.yaml");
        Files.writeString(p, "no-color: false\nno-unicode: false\n");
    }

    static class JsonExport {
        static String write(Node n) {
            StringBuilder sb = new StringBuilder();
            sb.append("[1,2,{\"progname\":\"gdu\",\"progver\":\"dev\",\"timestamp\":").append(Instant.now().getEpochSecond()).append("},\n");
            node(sb, n); sb.append("]\n"); return sb.toString();
        }
        static void node(StringBuilder sb, Node n) {
            if (n.dir) {
                sb.append("[{\"name\":\"").append(esc(n.path.toString())).append("\",\"mtime\":").append(n.mtime).append("}");
                for (Node c: n.children) { sb.append(",\n"); nodeNamed(sb, c); }
                sb.append("\n]");
            } else nodeNamed(sb, n);
        }
        static void nodeNamed(StringBuilder sb, Node n) {
            if (n.dir) {
                sb.append("[{\"name\":\"").append(esc(n.name)).append("\",\"mtime\":").append(n.mtime).append("}");
                for (Node c: n.children) { sb.append(",\n"); nodeNamed(sb, c); }
                sb.append("\n]");
            } else {
                sb.append("{\"name\":\"").append(esc(n.name)).append("\",\"asize\":").append(n.asize);
                if (n.dsize > 0) sb.append(",\"dsize\":").append(n.dsize);
                sb.append(",\"mtime\":").append(n.mtime);
                if (n.symlink) sb.append(",\"notreg\":true");
                sb.append("}");
            }
        }
        static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
    }

    static class JsonImport {
        String s; int i;
        JsonImport(String s) { this.s = s; }
        static Node parse(String s) { JsonImport p = new JsonImport(s); p.skip(); p.expect('['); p.skipUntilArray(); return p.node(null); }
        void skipUntilArray() { int depth=0; while (i<s.length()) { char c=s.charAt(i++); if (c=='[') { i--; return; } } }
        Node node(Path parent) {
            skip(); Node n = new Node();
            if (peek() == '[') {
                expect('['); Map<String,Object> m = obj(); String name=(String)m.get("name");
                n.name = Path.of(name).getFileName()==null?name:Path.of(name).getFileName().toString(); n.path = parent==null?Path.of(name):(parent.resolve(name)); n.dir=true; n.mtime=longv(m,"mtime");
                while (true) { skip(); if (peek()==']') { i++; break; } expect(','); Node c=node(n.path); n.children.add(c); n.asize+=c.asize; n.dsize+=c.dsize; n.mtime=Math.max(n.mtime,c.mtime); }
                try { Stat st = stat(n.path, false); n.asize += st.size; n.dsize += st.blocks*512L; } catch(Exception e) {}
                n.empty=false; return n;
            } else {
                Map<String,Object> m = obj(); n.name=(String)m.get("name"); n.path=parent==null?Path.of(n.name):parent.resolve(n.name); n.asize=longv(m,"asize"); n.dsize=longv(m,"dsize"); n.mtime=longv(m,"mtime"); n.symlink=m.containsKey("notreg"); return n;
            }
        }
        Map<String,Object> obj() {
            Map<String,Object> m=new HashMap<>(); expect('{');
            while(true){ skip(); if(peek()=='}'){i++; break;} String k=str(); skip(); expect(':'); skip(); Object v; char c=peek(); if(c=='"') v=str(); else { int st=i; while(i<s.length() && " ,}\n\r\t]".indexOf(s.charAt(i))<0)i++; String raw=s.substring(st,i); v=raw.equals("true")?Boolean.TRUE:Long.parseLong(raw); } m.put(k,v); skip(); if(peek()==','){i++; continue;} if(peek()=='}'){i++; break;} }
            return m;
        }
        String str(){ expect('"'); StringBuilder b=new StringBuilder(); while(i<s.length()){ char c=s.charAt(i++); if(c=='"')break; if(c=='\\'&&i<s.length()) c=s.charAt(i++); b.append(c);} return b.toString(); }
        long longv(Map<String,Object> m,String k){ Object v=m.get(k); return v instanceof Number?((Number)v).longValue():0; }
        char peek(){ skip(); return i<s.length()?s.charAt(i):0; }
        void skip(){ while(i<s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        void expect(char c){ skip(); if(i>=s.length()||s.charAt(i)!=c) throw new BadUsage("invalid JSON input"); i++; }
    }
}
