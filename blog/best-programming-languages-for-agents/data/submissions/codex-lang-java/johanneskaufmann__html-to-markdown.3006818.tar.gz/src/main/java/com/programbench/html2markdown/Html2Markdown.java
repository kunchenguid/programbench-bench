package com.programbench.html2markdown;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Html2Markdown {
    static class Options {
        String input, output, domain;
        boolean overwrite, strike, table, headerPromotion, tablePresentation, skipEmptyRows;
        String strong = "**";
        String includeSelector, excludeSelector;
        String tablePadding = "minimal";
        String tableSpan = "empty";
    }

    static class Node {
        String tag;
        String text;
        Map<String,String> attrs = new LinkedHashMap<>();
        List<Node> children = new ArrayList<>();
        Node parent;
        Node(String tag) { this.tag = tag; }
        static Node text(String s) { Node n = new Node("#text"); n.text = s; return n; }
    }

    static final Set<String> VOID = new HashSet<>(Arrays.asList("area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"));
    static final Set<String> BLOCK = new HashSet<>(Arrays.asList("address","article","aside","blockquote","body","center","dd","details","dialog","div","dl","dt","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","head","header","hr","html","li","main","nav","ol","p","pre","section","table","tbody","td","tfoot","th","thead","tr","ul"));

    public static void main(String[] args) throws Exception {
        Options opt = parseArgs(args);
        if (opt == null) return;
        if (opt.input == null) {
            String html = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
            String md = convert(html, opt);
            System.out.print(md);
            if (!md.endsWith("\n") && !md.isEmpty()) System.out.println();
        } else {
            processInput(opt);
        }
    }

    static Options parseArgs(String[] args) {
        Options o = new Options();
        List<String> bad = new ArrayList<>();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("--help")) { printHelp(); return null; }
            if (a.equals("-v") || a.equals("--version")) { printVersion(); return null; }
            if (a.equals("--output-overwrite")) { o.overwrite=true; continue; }
            if (a.equals("--plugin-strikethrough")) { o.strike=true; continue; }
            if (a.equals("--plugin-table")) { o.table=true; continue; }
            if (a.equals("--opt-table-header-promotion")) { o.headerPromotion=true; continue; }
            if (a.equals("--opt-table-presentation-tables")) { o.tablePresentation=true; continue; }
            if (a.equals("--opt-table-skip-empty-rows")) { o.skipEmptyRows=true; continue; }
            String key=a, val=null;
            int eq=a.indexOf('=');
            if (eq>=0) { key=a.substring(0,eq); val=a.substring(eq+1); }
            if (Arrays.asList("--input","--output","--domain","--exclude-selector","--include-selector","--opt-strong-delimiter","--opt-table-cell-padding-behavior","--opt-table-newline-behavior","--opt-table-span-cell-behavior").contains(key)) {
                if (val==null) {
                    if (i+1>=args.length) { bad.add(a); continue; }
                    val=args[++i];
                }
                switch(key) {
                    case "--input": o.input=val; break;
                    case "--output": o.output=val; break;
                    case "--domain": o.domain=val; break;
                    case "--exclude-selector": o.excludeSelector=val; break;
                    case "--include-selector": o.includeSelector=val; break;
                    case "--opt-strong-delimiter": o.strong=val.equals("__")?"__":"**"; break;
                    case "--opt-table-cell-padding-behavior": o.tablePadding=val; break;
                    case "--opt-table-span-cell-behavior": o.tableSpan=val; break;
                    default: break;
                }
            } else bad.add(a);
        }
        if (!bad.isEmpty()) {
            System.err.println();
            System.err.println("error: unknown arguments: " + String.join(" ", bad));
            System.err.println();
            System.err.println("Here is how you can use the CLI:");
            System.err.println();
            System.err.println("    echo \"<strong>important</strong>\" | html2markdown");
            System.exit(1);
        }
        return o;
    }

    static void printVersion() {
        System.out.println("html2markdown");
        System.out.println();
        System.out.println("GitVersion:  dev");
        System.out.println("GitCommit:   none");
        System.out.println("BuildDate:   unknown");
    }

    static void printHelp() {
        System.out.println("\n# html2markdown - convert html to markdown [version dev]\n");
        System.out.println("Convert HTML to Markdown. Even works with entire websites!\n");
        System.out.println("## Flags\n");
        System.out.println("    -v, --version\n        show the version of html2markdown and exit\n");
        System.out.println("    --help\n");
        System.out.println("    --input PATH\n        Input file, directory, or glob pattern (instead of stdin)\n");
        System.out.println("    --output PATH\n        Output file or directory (instead of stdout)\n");
        System.out.println("    --output-overwrite\n        Replace existing files\n");
        System.out.println("    --domain\n        The url of the web page, used to convert relative links to absolute links.\n");
        System.out.println("    --exclude-selector\n        css query selector to exclude parts of the input\n");
        System.out.println("    --include-selector\n        css query selector to only include parts of the input\n");
        System.out.println("    --opt-strong-delimiter\n        \"**\" or \"__\" (default: \"**\")\n");
        System.out.println("    --plugin-strikethrough\n        enable the plugin ~~strikethrough~~\n");
        System.out.println("    --plugin-table\n        enable the plugin table\n");
    }

    static void processInput(Options o) throws Exception {
        List<Path> inputs = expandInputs(o.input);
        boolean multiple = inputs.size()>1 || Files.isDirectory(Paths.get(o.input));
        Path out = o.output==null?null:Paths.get(o.output);
        if (multiple && out!=null) Files.createDirectories(out);
        for (Path p: inputs) {
            String md = convert(Files.readString(p), o);
            if (out==null) {
                System.out.print(md); if (!md.endsWith("\n") && !md.isEmpty()) System.out.println();
            } else {
                Path dest = multiple || Files.isDirectory(out) ? out.resolve(stripExt(p.getFileName().toString()) + ".md") : out;
                if (Files.exists(dest) && !o.overwrite) throw new IOException("output file already exists: " + dest);
                Files.createDirectories(dest.toAbsolutePath().getParent());
                Files.writeString(dest, md.endsWith("\n")?md:md+"\n", StandardCharsets.UTF_8);
            }
        }
    }
    static String stripExt(String s){ int i=s.lastIndexOf('.'); return i>0?s.substring(0,i):s; }
    static List<Path> expandInputs(String in) throws IOException {
        Path p=Paths.get(in);
        List<Path> r=new ArrayList<>();
        if (Files.isDirectory(p)) { try (DirectoryStream<Path> ds=Files.newDirectoryStream(p)) { for(Path x:ds) if(Files.isRegularFile(x)) r.add(x); } }
        else if (in.contains("*") || in.contains("?") || in.contains("[")) {
            Path dir=p.getParent()==null?Paths.get("."):p.getParent(); String pat=p.getFileName().toString();
            try (DirectoryStream<Path> ds=Files.newDirectoryStream(dir, pat)) { for(Path x:ds) if(Files.isRegularFile(x)) r.add(x); }
        } else r.add(p);
        Collections.sort(r); return r;
    }

    static String convert(String html, Options o) {
        Node root = parse(html);
        if (o.excludeSelector != null) removeMatches(root, o.excludeSelector);
        if (o.includeSelector != null) {
            Node nr = new Node("root");
            for (Node n: findMatches(root, o.includeSelector)) nr.children.add(n);
            root = nr;
        }
        String s = renderChildrenBlock(root, o).trim();
        return s;
    }

    static Node parse(String html) {
        Node root = new Node("root"), cur = root;
        Pattern tok = Pattern.compile("(?is)<!--.*?-->|<!\\[CDATA\\[.*?]]>|<![^>]*>|<[^>]+>");
        Matcher m = tok.matcher(html); int pos=0;
        while (m.find()) {
            if (m.start()>pos) addText(cur, html.substring(pos,m.start()));
            String t=m.group(); pos=m.end();
            if (t.startsWith("<!--") || t.startsWith("<!")) continue;
            boolean close=t.matches("(?is)</.*");
            String inside=t.replaceAll("^<\\s*/?\\s*|/?>$", "").trim();
            if (inside.isEmpty()) continue;
            String name=inside.split("\\s+",2)[0].toLowerCase(Locale.ROOT);
            if (close) {
                Node x=cur; while (x.parent!=null && !x.tag.equals(name)) x=x.parent;
                if (x.parent!=null) cur=x.parent;
            } else {
                if ((name.equals("li") && cur.tag.equals("li")) ||
                    (name.equals("p") && cur.tag.equals("p")) ||
                    ((name.equals("td") || name.equals("th")) && (cur.tag.equals("td") || cur.tag.equals("th"))) ||
                    (name.equals("tr") && cur.tag.equals("tr"))) {
                    cur = cur.parent == null ? cur : cur.parent;
                }
                Node n=new Node(name); n.attrs=parseAttrs(inside.substring(Math.min(name.length(), inside.length()))); n.parent=cur; cur.children.add(n);
                if (!VOID.contains(name) && !t.endsWith("/>") && !Arrays.asList("meta","link").contains(name)) cur=n;
            }
        }
        if (pos<html.length()) addText(cur, html.substring(pos));
        return root;
    }
    static void addText(Node cur, String s){ if(!s.isEmpty()){ Node n=Node.text(decode(s)); n.parent=cur; cur.children.add(n);} }
    static Map<String,String> parseAttrs(String s) {
        Map<String,String> a=new LinkedHashMap<>();
        Matcher m=Pattern.compile("([A-Za-z_:][-A-Za-z0-9_:.]*)\\s*(=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s\"'>/]+)))?").matcher(s);
        while(m.find()) { String k=m.group(1).toLowerCase(Locale.ROOT); String v=m.group(4); if(v==null)v=m.group(5); if(v==null)v=m.group(6); if(v==null)v=""; a.put(k, decode(v)); }
        return a;
    }
    static String decode(String s) {
        StringBuilder out=new StringBuilder();
        for(int i=0;i<s.length();) {
            char c=s.charAt(i);
            if(c=='&') { int semi=s.indexOf(';',i+1); if(semi>0 && semi-i<12) { String e=s.substring(i+1,semi); String r=entity(e); if(r!=null){out.append(r); i=semi+1; continue;} } }
            out.append(c); i++;
        }
        return out.toString();
    }
    static String entity(String e){
        switch(e){case"amp":return"&";case"quot":return"\"";case"apos":return"'";case"nbsp":return"\u00a0";case"lt":return"&lt;";case"gt":return"&gt;";}
        try{ if(e.startsWith("#x")||e.startsWith("#X")) return new String(Character.toChars(Integer.parseInt(e.substring(2),16))); if(e.startsWith("#")) return new String(Character.toChars(Integer.parseInt(e.substring(1)))); }catch(Exception ignored){}
        return null;
    }

    static String renderChildrenBlock(Node n, Options o) {
        List<String> parts=new ArrayList<>();
        StringBuilder inline=new StringBuilder();
        for(Node c:n.children){
            if(!c.tag.equals("#text") && BLOCK.contains(c.tag)) {
                String in=squash(inline.toString()).trim();
                if(!in.isEmpty()) parts.add(in);
                inline.setLength(0);
                String r=renderBlock(c,o);
                if(!r.trim().isEmpty()) parts.add(r.trim());
            } else {
                inline.append(renderInline(c,o));
            }
        }
        String in=squash(inline.toString()).trim();
        if(!in.isEmpty()) parts.add(in);
        return String.join("\n\n", parts);
    }
    static String renderBlock(Node n, Options o) {
        if(n.tag.equals("#text")) return cleanText(n.text, true);
        if(n.tag.matches("h[1-6]")) return "#".repeat(n.tag.charAt(1)-'0') + " " + renderInlineChildren(n,o).trim();
        switch(n.tag) {
            case "p": return renderInlineChildren(n,o).trim();
            case "br": return "\u0007\n";
            case "hr": return "* * *";
            case "pre": return "```\n" + rawText(n).replaceAll("^\\n|\\n$", "") + "\n```";
            case "blockquote": return prefix(renderChildrenBlock(n,o), "> ");
            case "ul": return renderList(n,o,false,0).trim();
            case "ol": return renderList(n,o,true,0).trim();
            case "table": return o.table ? renderTable(n,o) : renderInlineChildren(n,o).trim();
            case "script": case "style": case "head": return "";
            case "html": case "body": case "div": case "section": case "article": case "main": case "nav": case "header": case "footer": return renderChildrenBlock(n,o);
            default: return BLOCK.contains(n.tag) ? renderChildrenBlock(n,o) : renderInline(n,o);
        }
    }
    static String renderInlineChildren(Node n, Options o){ StringBuilder sb=new StringBuilder(); for(Node c:n.children) sb.append(renderInline(c,o)); return squash(sb.toString()); }
    static String renderInline(Node n, Options o) {
        if(n.tag.equals("#text")) return cleanText(n.text, false);
        String inner=renderInlineChildren(n,o);
        switch(n.tag) {
            case "strong": case "b": return o.strong + inner.trim() + o.strong;
            case "em": case "i": return "*" + inner.trim() + "*";
            case "code": return "`" + rawText(n).trim().replace("`","\\`") + "`";
            case "br": return "\u0007\n";
            case "a": String href=n.attrs.getOrDefault("href",""); return "[" + inner.trim() + "](" + abs(href,o.domain) + ")";
            case "img": return "![" + escapeBrackets(n.attrs.getOrDefault("alt", "")) + "](" + abs(n.attrs.getOrDefault("src", ""), o.domain) + ")";
            case "del": case "s": case "strike": return o.strike ? "~~" + inner.trim() + "~~" : inner;
            case "span": return inner;
            default: if(BLOCK.contains(n.tag)) return "\n" + renderBlock(n,o) + "\n"; return inner;
        }
    }
    static String renderList(Node n, Options o, boolean ordered, int depth) {
        StringBuilder sb=new StringBuilder(); int idx=1;
        for(Node li:n.children) if(li.tag.equals("li")) {
            String marker=ordered ? (idx++) + ". " : "- ";
            String content=renderLi(li,o,depth).trim();
            String[] lines=content.split("\\R",-1);
            sb.append("  ".repeat(depth)).append(marker).append(lines.length>0?lines[0]:"").append("\n");
            for(int i=1;i<lines.length;i++) sb.append("  ".repeat(depth+1)).append(lines[i]).append("\n");
        }
        return sb.toString();
    }
    static String renderLi(Node li, Options o, int depth) {
        StringBuilder inline=new StringBuilder(); List<String> blocks=new ArrayList<>();
        for(Node c:li.children) {
            if(c.tag.equals("ul")) blocks.add(renderList(c,o,false,depth+1));
            else if(c.tag.equals("ol")) blocks.add(renderList(c,o,true,depth+1));
            else if(BLOCK.contains(c.tag) && !c.tag.equals("p")) blocks.add(renderBlock(c,o));
            else inline.append(renderInline(c,o));
        }
        String first=inline.toString().trim();
        if(blocks.isEmpty()) return first;
        return first + "\n\n" + String.join("\n", blocks).trim();
    }
    static String renderTable(Node table, Options o) {
        List<List<String>> rows=new ArrayList<>(); List<Boolean> header=new ArrayList<>();
        collectRows(table, rows, header, o);
        if(rows.isEmpty()) return "";
        int cols=0; for(List<String> r:rows) cols=Math.max(cols,r.size());
        boolean hasHead=header.contains(true) || o.headerPromotion; int headIndex=header.indexOf(true); if(headIndex<0) headIndex=0;
        List<String> out=new ArrayList<>();
        for(int ri=0;ri<rows.size();ri++) {
            if(o.skipEmptyRows && rows.get(ri).stream().allMatch(String::isBlank)) continue;
            out.add(tableRow(rows.get(ri), cols, o));
            if(hasHead && ri==headIndex) out.add(separator(cols));
        }
        return String.join("\n", out);
    }
    static void collectRows(Node n,List<List<String>> rows,List<Boolean> header,Options o){
        if(n.tag.equals("tr")) { List<String> r=new ArrayList<>(); boolean h=false; for(Node c:n.children) if(c.tag.equals("td")||c.tag.equals("th")){ h|=c.tag.equals("th"); r.add(renderInlineChildren(c,o).trim().replace('\n',' ')); } rows.add(r); header.add(h); }
        else for(Node c:n.children) collectRows(c,rows,header,o);
    }
    static String tableRow(List<String> r,int cols,Options o){ StringBuilder sb=new StringBuilder("|"); for(int i=0;i<cols;i++){ String c=i<r.size()?r.get(i):""; sb.append(' ').append(c).append(' ').append('|'); } return sb.toString(); }
    static String separator(int cols){ StringBuilder sb=new StringBuilder("|"); for(int i=0;i<cols;i++) sb.append("---|"); return sb.toString(); }

    static String rawText(Node n){ if(n.tag.equals("#text")) return n.text; StringBuilder sb=new StringBuilder(); for(Node c:n.children) sb.append(rawText(c)); return sb.toString(); }
    static String prefix(String s,String p){ String[] lines=s.split("\\R",-1); StringBuilder sb=new StringBuilder(); for(String l:lines){ if(sb.length()>0)sb.append('\n'); sb.append(l.isEmpty()?">":p+l); } return sb.toString(); }
    static String squash(String s){ return s.replaceAll("[\\t ]+", " ").replaceAll(" *\\n *", "\n").replace("\u0007\n", "  \n"); }
    static String cleanText(String s, boolean block){ String r=s.replace('\r',' ').replace('\n',' ').replaceAll("[\\t ]+", " "); return escapeMarkdown(r); }
    static String escapeMarkdown(String s){ return s.replace("\\","\\\\").replace("*","\\*").replace("_","\\_").replace("[","\\[").replace("]","\\]"); }
    static String escapeBrackets(String s){ return s.replace("[","\\[").replace("]","\\]"); }
    static String abs(String u, String domain) {
        if(domain==null || u==null || u.isEmpty() || u.matches("(?i)^[a-z][a-z0-9+.-]*:.*") || u.startsWith("#")) return u==null?"":u;
        try {
            java.net.URI base=new java.net.URI(domain);
            if(u.startsWith("//")) return base.getScheme()+":"+u;
            return base.resolve(u).toString();
        } catch(Exception e){ return u; }
    }

    static boolean matches(Node n,String sel){ if(n.tag.equals("#text")) return false; sel=sel.trim(); if(sel.startsWith(".")) return Arrays.asList(n.attrs.getOrDefault("class","").split("\\s+")).contains(sel.substring(1)); if(sel.startsWith("#")) return n.attrs.getOrDefault("id","").equals(sel.substring(1)); return n.tag.equalsIgnoreCase(sel); }
    static List<Node> findMatches(Node n,String sel){ List<Node> r=new ArrayList<>(); if(matches(n,sel)) r.add(n); for(Node c:n.children) r.addAll(findMatches(c,sel)); return r; }
    static void removeMatches(Node n,String sel){ Iterator<Node> it=n.children.iterator(); while(it.hasNext()){ Node c=it.next(); if(matches(c,sel)) it.remove(); else removeMatches(c,sel); } }
}
