import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class Jot {
    static final String BLUE = "\u001b[0;34m";
    static final String RED = "\u001b[0;31m";
    static final String RESET = "\u001b[0m";
    static Path home = Paths.get(System.getenv().getOrDefault("HOME", System.getProperty("user.home")));
    static Path vaultsFile = home.resolve(".local/share/jot/vaults");
    static Path configFile = home.resolve(".config/jot/config");

    public static void main(String[] args) {
        try {
            ensureConfig();
            if (args.length == 0 || args[0].equals("help") || args[0].equals("-h") || args[0].equals("--help")) {
                if (args.length >= 2) printHelp(canon(args[1]));
                else printMainHelp();
                return;
            }
            String cmd = canon(args[0]);
            if (args.length > 1 && (args[1].equals("-h") || args[1].equals("--help"))) {
                printHelp(cmd);
                return;
            }
            switch (cmd) {
                case "vault": vault(Arrays.copyOfRange(args, 1, args.length)); break;
                case "note": note(args); break;
                case "folder": folder(args); break;
                case "enter": require(args, 2, "<vault name>", "executable enter <vault name>"); enter(args[1]); break;
                case "open": require(args, 2, "<note name>", "executable open <note name>"); openNote(args[1]); break;
                case "opdir": opdir(); break;
                case "chdir": require(args, 2, "<folder path>", "executable chdir <folder path>"); chdir(args[1]); break;
                case "list": list(args.length > 1 ? args[1] : null); break;
                case "remove": require(args, 3, "<item type> <name>", "executable remove <item type> <name>"); remove(args[1], args[2]); break;
                case "rename": require(args, 4, "<item type> <name> <new name>", "executable rename <item type> <name> <new name>"); rename(args[1], args[2], args[3]); break;
                case "move": require(args, 4, "<item type> <name> <new location>", "executable move <item type> <name> <new location>"); move(args[1], args[2], args[3]); break;
                case "vmove": require(args, 4, "<item type> <name> <vault name>", "executable vmove <item type> <name> <vault name>"); vmove(args[1], args[2], args[3]); break;
                case "config": config(args); break;
                default:
                    System.err.println("error: Found argument '" + args[0] + "' which wasn't expected, or isn't valid in this context\n");
                    System.err.println("USAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help");
                    System.exit(2);
            }
        } catch (ArgError e) {
            System.err.print(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            err(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    static String canon(String c) {
        switch (c) {
            case "vl": return "vault"; case "nt": return "note"; case "fd": return "folder";
            case "en": return "enter"; case "op": return "open"; case "od": return "opdir";
            case "cd": return "chdir"; case "ls": return "list"; case "rm": return "remove";
            case "rn": return "rename"; case "mv": return "move"; case "vm": return "vmove";
            case "cf": return "config"; default: return c;
        }
    }

    static void ensureConfig() throws IOException {
        if (!Files.exists(configFile)) {
            Files.createDirectories(configFile.getParent());
            Files.writeString(configFile, "editor = 'nvim'\nconflict = true\n", StandardCharsets.UTF_8);
        }
        if (!Files.exists(vaultsFile)) {
            Files.createDirectories(vaultsFile.getParent());
            Files.writeString(vaultsFile, "[vaults]\n", StandardCharsets.UTF_8);
        }
    }

    static class State {
        String current = "";
        TreeMap<String,String> vaults = new TreeMap<>();
    }
    static State readState() throws IOException {
        State s = new State();
        if (!Files.exists(vaultsFile)) return s;
        for (String line : Files.readAllLines(vaultsFile)) {
            line = line.trim();
            if (line.startsWith("current")) s.current = val(line);
            else if (line.contains("=") && !line.startsWith("[") && !line.startsWith("current")) {
                int i = line.indexOf('=');
                s.vaults.put(line.substring(0, i).trim(), val(line));
            }
        }
        return s;
    }
    static void writeState(State s) throws IOException {
        Files.createDirectories(vaultsFile.getParent());
        StringBuilder b = new StringBuilder();
        if (s.current != null && !s.current.isEmpty()) b.append("current = '").append(s.current).append("'\n\n");
        b.append("[vaults]\n");
        for (var e : s.vaults.entrySet()) b.append(e.getKey()).append(" = '").append(e.getValue()).append("'\n");
        Files.writeString(vaultsFile, b.toString(), StandardCharsets.UTF_8);
    }
    static String val(String line) {
        String v = line.substring(line.indexOf('=') + 1).trim();
        if (v.startsWith("'") && v.endsWith("'")) v = v.substring(1, v.length() - 1);
        return v;
    }

    static class VaultData {
        String name, location, folder = "";
        Path root() { return Paths.get(location).resolve(name); }
        Path cwd() { return folder.isEmpty() ? root() : root().resolve(folder); }
    }
    static VaultData currentVault() throws IOException {
        State s = readState();
        if (s.current == null || s.current.isEmpty() || !s.vaults.containsKey(s.current)) return null;
        return readVault(s.current, s.vaults.get(s.current));
    }
    static VaultData readVault(String name, String loc) throws IOException {
        VaultData d = new VaultData(); d.name = name; d.location = loc;
        Path f = Paths.get(loc).resolve(name).resolve(".jot/data");
        if (Files.exists(f)) for (String line : Files.readAllLines(f)) {
            line = line.trim();
            if (line.startsWith("folder")) d.folder = val(line);
            else if (line.startsWith("location")) d.location = val(line);
            else if (line.startsWith("name")) d.name = val(line);
        }
        return d;
    }
    static void writeVault(VaultData d) throws IOException {
        Path p = d.root().resolve(".jot/data");
        Files.createDirectories(p.getParent());
        Files.writeString(p, "name = '" + d.name + "'\nlocation = '" + d.location + "'\nfolder = '" + d.folder + "'\nhistory = []\n", StandardCharsets.UTF_8);
    }

    static void vault(String[] a) throws Exception {
        State s = readState();
        if (a.length == 0) {
            for (String n : s.vaults.keySet()) System.out.println((n.equals(s.current) ? "👉 " + blue(n) : "   " + n));
            return;
        }
        if (a.length == 1 && a[0].equals("-l")) {
            for (var e : s.vaults.entrySet()) System.out.println((e.getKey().equals(s.current) ? "👉 " + blue(e.getKey()) : "   " + e.getKey()) + " \t " + e.getValue());
            return;
        }
        if (a.length < 2) throw new ArgError("error: The following required arguments were not provided:\n    <vault location>\n\nUSAGE:\n    jt vault <vault name> <vault location>\n\nFor more information try --help\n");
        String name = a[0], loc = a[1];
        if (!Paths.get(loc).isAbsolute()) { err("specified path isn't absolute"); return; }
        if (s.vaults.containsKey(name)) { err("vault " + name + " already exists"); return; }
        Path root = Paths.get(loc).resolve(name);
        Files.createDirectories(root.resolve(".jot"));
        s.vaults.put(name, loc);
        VaultData d = new VaultData(); d.name = name; d.location = loc; writeVault(d);
        writeState(s);
        System.out.println("vault " + blue(name) + " created");
    }

    static void enter(String name) throws Exception {
        State s = readState();
        if (!s.vaults.containsKey(name)) { err("vault " + name + " doesn't exist"); return; }
        s.current = name; writeState(s);
        VaultData d = readVault(name, s.vaults.get(name)); d.folder = ""; writeVault(d);
        System.out.println("entered " + blue(name));
    }

    static void note(String[] args) throws Exception {
        require(args, 2, "<note name>", "jt note\n    jt note [note name]");
        String name = args[1]; if (!validName(name)) { err("invalid name"); return; }
        VaultData v = needVault(); if (v == null) return;
        String base = name.endsWith(".md") ? name.substring(0, name.length()-3) : name;
        Path p = v.cwd().resolve(base + ".md");
        if (Files.exists(p)) { err("a note named " + name + " already exists in this location"); return; }
        Files.writeString(p, "", StandardCharsets.UTF_8);
        System.out.println("note " + blue(base) + " created");
    }
    static void folder(String[] args) throws Exception {
        require(args, 2, "<folder name>", "jt folder\n    jt folder [folder name]");
        String name = args[1]; if (!validName(name)) { err("invalid name"); return; }
        VaultData v = needVault(); if (v == null) return;
        Path p = v.cwd().resolve(name);
        if (Files.exists(p)) { err("a folder named " + name + " already exists in this location"); return; }
        Files.createDirectories(p);
        System.out.println("folder " + blue(name) + " created");
    }
    static boolean validName(String n) { return !(n.contains("/") || n.contains("\\") || n.equals(".") || n.equals("..") || n.isEmpty()); }
    static VaultData needVault() throws IOException { VaultData v = currentVault(); if (v == null) err("not inside a vault"); return v; }

    static void list(String type) throws Exception {
        if (type != null && !type.equals("note") && !type.equals("nt") && !type.equals("folder") && !type.equals("fd"))
            throw new ArgError("error: \"" + type + "\" isn't a valid value for '<item type>'\n\t[possible values: note, nt, folder, fd]\n\nFor more information try --help\n");
        VaultData v = needVault(); if (v == null) return;
        System.out.println(v.folder.isEmpty() ? v.name : v.name + " > " + v.folder.replace(File.separator, " > "));
        boolean notes = type == null || type.equals("note") || type.equals("nt");
        boolean dirs = type == null || type.equals("folder") || type.equals("fd");
        printTree(v.cwd(), "", notes, dirs, type == null);
    }
    static void printTree(Path dir, String prefix, boolean notes, boolean dirs, boolean hideJot) throws IOException {
        List<Path> items;
        try (Stream<Path> st = Files.list(dir)) {
            items = st.filter(p -> {
                String n = p.getFileName().toString();
                if (hideJot && n.equals(".jot")) return false;
                if (Files.isDirectory(p)) return dirs || hideJot;
                return notes && n.endsWith(".md");
            }).collect(Collectors.toList());
        }
        for (int i=0;i<items.size();i++) {
            Path p = items.get(i); boolean last = i == items.size()-1;
            String n = p.getFileName().toString();
            if (Files.isRegularFile(p) && n.endsWith(".md")) n = blue(n.substring(0, n.length()-3));
            System.out.println(prefix + (last ? "└── " : "├── ") + n);
            if (Files.isDirectory(p) && !p.getFileName().toString().equals(".jot")) printTree(p, prefix + (last ? "    " : "│   "), notes, dirs, hideJot);
        }
    }

    static String kind(String t) {
        if (t.equals("note") || t.equals("nt")) return "note";
        if (t.equals("folder") || t.equals("fd")) return "folder";
        if (t.equals("vault") || t.equals("vl")) return "vault";
        return "";
    }
    static Path itemPath(VaultData v, String k, String name) { return k.equals("note") ? v.cwd().resolve(stripMd(name)+".md") : v.cwd().resolve(name); }
    static String stripMd(String n) { return n.endsWith(".md") ? n.substring(0, n.length()-3) : n; }

    static void remove(String type, String name) throws Exception {
        String k = kind(type);
        if (k.equals("vault")) {
            State s = readState(); if (!s.vaults.containsKey(name)) { err("vault " + name + " not found"); return; }
            Path root = Paths.get(s.vaults.get(name)).resolve(name); deleteRecursive(root);
            s.vaults.remove(name); if (name.equals(s.current)) s.current = ""; writeState(s);
            System.out.println("vault " + blue(name) + " removed"); return;
        }
        VaultData v = needVault(); if (v == null) return;
        Path p = itemPath(v, k, name);
        if (k.isEmpty() || !Files.exists(p)) { err((k.isEmpty()?type:k) + " " + name + " not found"); return; }
        deleteRecursive(p);
        System.out.println(k + " " + blue(stripMd(name)) + " removed");
    }
    static void rename(String type, String name, String nn) throws Exception {
        String k = kind(type);
        if (k.equals("vault")) {
            State s = readState(); if (!s.vaults.containsKey(name)) { err("vault " + name + " not found"); return; }
            if (s.vaults.containsKey(nn)) { err("vault " + nn + " already exists"); return; }
            Path old = Paths.get(s.vaults.get(name)).resolve(name), neu = Paths.get(s.vaults.get(name)).resolve(nn);
            Files.move(old, neu); s.vaults.put(nn, s.vaults.remove(name)); if (name.equals(s.current)) s.current = nn; writeState(s);
            VaultData d = readVault(nn, s.vaults.get(nn)); d.name = nn; writeVault(d);
            System.out.println("vault " + blue(name) + " renamed to " + blue(nn)); return;
        }
        VaultData v = needVault(); if (v == null) return;
        Path p = itemPath(v, k, name), q = itemPath(v, k, nn);
        if (!Files.exists(p)) { err(k + " " + name + " not found"); return; }
        Files.move(p, q);
        System.out.println(k + " " + blue(stripMd(name)) + " renamed to " + blue(stripMd(nn)));
    }
    static void move(String type, String name, String dest) throws Exception {
        String k = kind(type);
        if (k.equals("vault")) { err("not implemented"); return; }
        VaultData v = needVault(); if (v == null) return;
        Path src = itemPath(v, k, name);
        if (!Files.exists(src)) { err(k + " " + name + " not found"); return; }
        Path d = resolveInVault(v, dest);
        if (d == null) { err("path crosses the bounds of vault"); return; }
        if (!Files.isDirectory(d)) { err("couldn't find the path specified"); return; }
        Files.move(src, d.resolve(src.getFileName()), StandardCopyOption.REPLACE_EXISTING);
        System.out.println(k + " " + blue(stripMd(name)) + " moved");
    }
    static void vmove(String type, String name, String vault) throws Exception {
        String k = kind(type);
        if (k.equals("vault") || k.isEmpty()) { err("invalid item type"); return; }
        VaultData v = needVault(); if (v == null) return;
        State s = readState(); if (!s.vaults.containsKey(vault)) { err("vault " + vault + " doesn't exist"); return; }
        Path src = itemPath(v, k, name); if (!Files.exists(src)) { err("no such file or directory (os error 2)"); return; }
        Path dst = Paths.get(s.vaults.get(vault)).resolve(vault).resolve(src.getFileName());
        Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING);
        System.out.println(k + " " + blue(stripMd(name)) + " moved to vault " + blue(vault));
    }
    static Path resolveInVault(VaultData v, String path) {
        Path base = v.cwd();
        Path p = Paths.get(path);
        if (p.isAbsolute()) {
            if (path.equals("/") || !p.normalize().startsWith(v.root().normalize())) return null;
            return p.normalize();
        }
        Path r = base.resolve(p).normalize();
        return r.startsWith(v.root().normalize()) ? r : null;
    }
    static void chdir(String path) throws Exception {
        VaultData v = needVault(); if (v == null) return;
        Path r = resolveInVault(v, path);
        if (r == null) { err("path crosses the bounds of vault"); return; }
        if (!Files.isDirectory(r)) { err("couldn't find the path specified"); return; }
        v.folder = v.root().relativize(r).toString();
        if (v.folder.equals(".")) v.folder = "";
        writeVault(v);
        System.out.println("folder changed");
    }
    static void openNote(String name) throws Exception {
        VaultData v = needVault(); if (v == null) return;
        Path p = itemPath(v, "note", name); if (!Files.exists(p)) { err("note " + name + " not found"); return; }
        runEditor(p.toString());
    }
    static void opdir() throws Exception { VaultData v = needVault(); if (v != null) runEditor(v.cwd().toString()); }
    static void runEditor(String target) throws Exception {
        String editor = readConfig().getOrDefault("editor", "nvim");
        new ProcessBuilder(editor, target).inheritIO().start().waitFor();
    }

    static Map<String,String> readConfig() throws IOException {
        ensureConfig();
        Map<String,String> m = new LinkedHashMap<>();
        for (String line : Files.readAllLines(configFile)) if (line.contains("=")) {
            int i=line.indexOf('='); m.put(line.substring(0,i).trim(), val(line));
        }
        return m;
    }
    static void writeConfig(Map<String,String> m) throws IOException {
        Files.createDirectories(configFile.getParent());
        Files.writeString(configFile, "editor = '" + m.getOrDefault("editor","nvim") + "'\nconflict = " + m.getOrDefault("conflict","true") + "\n", StandardCharsets.UTF_8);
    }
    static void config(String[] args) throws Exception {
        if (args.length == 1) { runEditor(configFile.toString()); return; }
        String key = args[1];
        if (!key.equals("editor") && !key.equals("conflict"))
            throw new ArgError("error: \"" + key + "\" isn't a valid value for '<config type>'\n\t[possible values: editor, conflict]\n\nFor more information try --help\n");
        Map<String,String> m = readConfig();
        if (args.length == 2) System.out.println(key + ": " + blue(m.getOrDefault(key, "")));
        else { m.put(key, args[2]); writeConfig(m); System.out.println("set " + blue(key) + " to " + blue(args[2])); }
    }

    static void deleteRecursive(Path p) throws IOException {
        if (!Files.exists(p)) return;
        try (Stream<Path> s = Files.walk(p)) {
            List<Path> all = s.sorted(Comparator.reverseOrder()).collect(Collectors.toList());
            for (Path x : all) Files.deleteIfExists(x);
        }
    }
    static void err(String s) { System.out.println(RED + "error" + RESET + ": " + s); }
    static String blue(String s) { return BLUE + s + RESET; }
    static void require(String[] args, int n, String missing, String usage) {
        if (args.length < n) throw new ArgError("error: The following required arguments were not provided:\n    " + missing + "\n\nUSAGE:\n    " + usage + "\n\nFor more information try --help\n");
    }
    static class ArgError extends RuntimeException { ArgError(String m) { super(m); } }

    static void printMainHelp() {
        System.out.print(BLUE + "________      _____ \n______(_)_______  /_\n_____  /_  __ \\  __/\n____  / / /_/ / /_  \n___  /  \\____/\\__/  \n/___/         ᵥ₀.₁.₂  \n" + RESET + "         \n\nusage: jt <command>\n\n" + BLUE + "commands:" + RESET + "\n\ncreate items\n    " + BLUE + "vault" + RESET + ", " + BLUE + "vl" + RESET + "       create a vault or list vaults\n    create items in current folder\n        " + BLUE + "note" + RESET + ", " + BLUE + "nt" + RESET + "        create a note \n        " + BLUE + "folder" + RESET + ", " + BLUE + "fd" + RESET + "      create a folder\n\ninteract with items\n    " + BLUE + "enter" + RESET + ", " + BLUE + "en" + RESET + "       enter a vault\n    " + BLUE + "open" + RESET + ", " + BLUE + "op" + RESET + "        open a note from current folder\n    " + BLUE + "opdir" + RESET + ", " + BLUE + "od" + RESET + "       open current folder in file explorer\n    " + BLUE + "chdir" + RESET + ", " + BLUE + "cd" + RESET + "       change folder within current vault\n    " + BLUE + "list" + RESET + ", " + BLUE + "ls" + RESET + "        list items in current folder\n\nperform fs operations on items\n    " + BLUE + "remove" + RESET + ", " + BLUE + "rm" + RESET + "      remove an item \n    " + BLUE + "rename" + RESET + ", " + BLUE + "rn" + RESET + "      rename an item \n    " + BLUE + "move" + RESET + ", " + BLUE + "mv" + RESET + "        move an item to a new location\n    " + BLUE + "vmove" + RESET + ", " + BLUE + "vm" + RESET + "       move an item to a different vault\n\nconfig\n    " + BLUE + "config" + RESET + ", " + BLUE + "cf" + RESET + "      display, set or open config\n\nget help \n    use " + BLUE + "help" + RESET + " or " + BLUE + "-h" + RESET + " and " + BLUE + "--help" + RESET + " flags along with a command to get corresponding help\n");
    }
    static void printHelp(String c) {
        String txt;
        switch (c) {
            case "vault": txt="executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information"; break;
            case "note": txt="executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "folder": txt="executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "enter": txt="executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "open": txt="executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "opdir": txt="executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "chdir": txt="executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "list": txt="executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "remove": txt="executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "rename": txt="executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "move": txt="executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "vmove": txt="executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            case "config": txt="executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information"; break;
            default: printMainHelp(); return;
        }
        System.out.println(txt);
    }
}
