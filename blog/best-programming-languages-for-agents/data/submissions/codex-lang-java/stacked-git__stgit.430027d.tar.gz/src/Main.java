import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Main {
    static Path cwd = Paths.get("").toAbsolutePath();
    static boolean color = false;

    static class Patch {
        String name, hash;
        boolean applied, hidden;
        Patch(String n, String h, boolean a, boolean hi) { name=n; hash=h; applied=a; hidden=hi; }
    }

    static class Result {
        int code; String out, err;
        Result(int c, String o, String e) { code=c; out=o; err=e; }
    }

    public static void main(String[] argv) throws Exception {
        List<String> args = new ArrayList<>(Arrays.asList(argv));
        for (int i = 0; i < args.size();) {
            String a = args.get(i);
            if (a.equals("-C") && i + 1 < args.size()) {
                Path p = Paths.get(args.get(i + 1));
                cwd = p.isAbsolute() ? p : cwd.resolve(p).normalize();
                args.subList(i, i + 2).clear();
            } else if (a.equals("--color") && i + 1 < args.size()) {
                color = args.get(i + 1).equals("always") || args.get(i + 1).equals("ansi");
                args.subList(i, i + 2).clear();
            } else if (a.startsWith("--color=")) {
                String v = a.substring(8);
                color = v.equals("always") || v.equals("ansi");
                args.remove(i);
            } else {
                i++;
            }
        }
        if (args.isEmpty() || args.get(0).equals("-h") || args.get(0).equals("--help")) {
            help();
            return;
        }
        if (args.get(0).equals("--version") || args.get(0).equals("version")) {
            if (args.contains("-s") || args.contains("--short")) System.out.println("2.5.5");
            else version();
            return;
        }
        String cmd = args.remove(0);
        try {
            switch (cmd) {
                case "help": if (args.isEmpty()) help(); else helpCommand(args.get(0)); break;
                case "add": gitInherit(prepend("add", args)); break;
                case "resolved": gitInherit(prepend("add", args)); break;
                case "rm": gitInherit(prepend("rm", args)); break;
                case "mv": gitInherit(prepend("mv", args)); break;
                case "status": gitInherit(prepend("status", prepend("-s", args))); break;
                case "init": cmdInit(args); break;
                case "branch": cmdBranch(args); break;
                case "new": cmdNew(args); break;
                case "refresh": cmdRefresh(args); break;
                case "rename": cmdRename(args); break;
                case "series": cmdSeries(args); break;
                case "top": cmdTop(args); break;
                case "next": cmdNext(args); break;
                case "prev": cmdPrev(args); break;
                case "pop": cmdPop(args); break;
                case "push": cmdPush(args); break;
                case "files": cmdFiles(args); break;
                case "show": cmdShow(args); break;
                case "diff": cmdDiff(args); break;
                case "id": cmdId(args); break;
                case "name": cmdName(args); break;
                case "delete": cmdDelete(args); break;
                case "clean": cmdClean(args); break;
                case "hide": cmdHide(args, true); break;
                case "unhide": cmdHide(args, false); break;
                case "pick": cmdPick(args); break;
                case "uncommit": cmdUncommit(args); break;
                case "commit": cmdCommit(args); break;
                case "log": cmdLog(args); break;
                case "completion": break;
                default:
                    System.err.println("error: unrecognized subcommand '" + cmd + "'");
                    System.err.println();
                    System.err.println("Usage: stg [OPTIONS] <command> [...]");
                    System.err.println("       stg [OPTIONS] <-h|--help>");
                    System.err.println("       stg --version");
                    System.exit(2);
            }
        } catch (StgError e) {
            System.err.println("error: " + e.getMessage());
            System.exit(e.code);
        }
    }

    static List<String> prepend(String s, List<String> xs) { ArrayList<String> r = new ArrayList<>(); r.add(s); r.addAll(xs); return r; }

    static void version() throws Exception {
        System.out.println("Stacked Git 2.5.5");
        System.out.println("Copyright (C) 2005-2025 StGit authors");
        System.out.println("This is free software: you are free to change and redistribute it.");
        System.out.println("There is NO WARRANTY, to the extent permitted by law.");
        System.out.println("SPDX-License-Identifier: GPL-2.0-only");
        Result g = git("version");
        System.out.print(g.out);
    }

    static void help() {
        System.out.println("Maintain a stack of patches on top of a Git branch.");
        System.out.println();
        System.out.println("Usage: stg [OPTIONS] <command> [...]");
        System.out.println("       stg [OPTIONS] <-h|--help>");
        System.out.println("       stg --version");
        System.out.println();
        System.out.println("Patch inspection commands:");
        System.out.println("  diff   Show a diff");
        System.out.println("  files  Show files modified by a patch");
        System.out.println("  id     Print git hash of a StGit revision");
        System.out.println("  log    Display or optionally clear the stack changelog");
        System.out.println("  name   Print patch name of a StGit revision");
        System.out.println("  show   Show patch commits");
        System.out.println();
        System.out.println("Patch manipulation commands:");
        System.out.println("  new      Create a new patch at top of the stack");
        System.out.println("  refresh  Incorporate worktree changes into current patch");
        System.out.println("  rename   Rename a patch");
        System.out.println();
        System.out.println("Stack inspection commands:");
        System.out.println("  next     Print the name of the next patch");
        System.out.println("  prev     Print the name of the previous patch");
        System.out.println("  series   Display the patch series");
        System.out.println("  top      Print the name of the top patch");
        System.out.println();
        System.out.println("Stack manipulation commands:");
        System.out.println("  branch    Branch operations: switch, list, create, rename, delete, ...");
        System.out.println("  clean     Delete empty patches from the series");
        System.out.println("  delete    Delete patches");
        System.out.println("  init      Initialize a StGit stack on a branch");
        System.out.println("  pop       Pop (unapply) one or more applied patches");
        System.out.println("  push      Push (apply) one or more unapplied patches");
        System.out.println();
        System.out.println("Administration commands:");
        System.out.println("  completion  Support for shell completions");
        System.out.println("  version     Print version information and exit");
        System.out.println();
        System.out.println("Aliases:");
        System.out.println("  add       Alias for shell command `git -C \"$GIT_PREFIX\" add`");
        System.out.println("  mv        Alias for shell command `git -C \"$GIT_PREFIX\" mv`");
        System.out.println("  resolved  Alias for shell command `git -C \"$GIT_PREFIX\" add`");
        System.out.println("  rm        Alias for shell command `git -C \"$GIT_PREFIX\" rm`");
        System.out.println("  status    Alias for shell command `git status -s`");
    }

    static void helpCommand(String c) {
        switch (c) {
            case "new": System.out.println("Create a new, empty patch on the current stack.\n\nUsage: stg new [OPTIONS] [patchname] [-- <path>...]\n\nOptions:\n  -n, --name <name>\n  -r, --refresh\n  -i, --index\n  -m, --message <message>\n  -h, --help"); break;
            case "series": System.out.println("Show all the patches in the series.\n\nUsage: stg series [OPTIONS] [patch]...\n\nOptions:\n  -a, --all\n  -A, --applied\n  -U, --unapplied\n  -H, --hidden\n  -c, --count\n  -d, --description\n  -i, --commit-id[=<length>]\n  -P, --no-prefix\n  -r, --reverse\n  -h, --help"); break;
            case "pop": System.out.println("Pop (unapply) one or more applied patches.\n\nUsage: stg pop [OPTIONS] [patch]...\n       stg pop [OPTIONS] --all\n       stg pop [OPTIONS] -n <number>"); break;
            case "push": System.out.println("Push one or more unapplied patches from the series onto the stack.\n\nUsage: stg push [OPTIONS] [patch]...\n       stg push [OPTIONS] -n <number>\n       stg push [OPTIONS] --all"); break;
            default: help();
        }
    }

    static void cmdInit(List<String> args) throws Exception {
        ensureGit();
        Path d = metaDir(branchFromArgs(args));
        Files.createDirectories(d);
        Path s = d.resolve("series");
        if (!Files.exists(s)) Files.writeString(s, "", StandardCharsets.UTF_8);
    }

    static void cmdBranch(List<String> args) throws Exception {
        ensureGit();
        if (args.isEmpty()) { System.out.println(branch()); return; }
        if (args.contains("-l") || args.contains("--list")) { gitInherit("branch"); return; }
        int ci = indexOfAny(args, "-c", "--create");
        if (ci >= 0) {
            String b = args.get(ci + 1);
            if (args.size() > ci + 2) gitCheck("checkout", "-b", b, args.get(ci + 2)); else gitCheck("checkout", "-b", b);
            cmdInit(List.of());
            return;
        }
        int ri = indexOfAny(args, "-r", "--rename");
        if (ri >= 0) { ArrayList<String> g=list("branch", args.subList(ri + 1, args.size())); g.add(1, "-m"); gitInherit(g); return; }
        int di = indexOfAny(args, "-D", "--delete");
        if (di >= 0) { ArrayList<String> g=list("branch", args.subList(di + 1, args.size())); g.add(1, "-D"); gitInherit(g); return; }
        if (!args.get(0).startsWith("-")) gitInherit("checkout", args.get(0));
    }

    static void cmdNew(List<String> args) throws Exception {
        ensureGit();
        String name = null, msg = null;
        boolean refresh = false, index = false;
        List<String> paths = new ArrayList<>();
        for (int i=0;i<args.size();i++) {
            String a=args.get(i);
            if (a.equals("--")) { paths.addAll(args.subList(i+1,args.size())); break; }
            else if (a.equals("-m") || a.equals("--message")) msg=args.get(++i);
            else if (a.equals("-n") || a.equals("--name")) name=args.get(++i);
            else if (a.equals("-r") || a.equals("--refresh")) refresh=true;
            else if (a.equals("-i") || a.equals("--index")) index=true;
            else if (a.equals("-h") || a.equals("--help")) { helpCommand("new"); return; }
            else if (!a.startsWith("-") && name==null) name=a;
            else if (!a.startsWith("-")) paths.add(a);
        }
        if (msg == null) msg = name != null ? name : "New patch";
        if (name == null) name = slug(msg);
        List<Patch> ps = load();
        for (Patch p: ps) if (p.name.equals(name)) throw new StgError("patch `" + name + "' already exists", 2);
        if (refresh || !paths.isEmpty()) {
            if (!index) {
                if (paths.isEmpty()) gitCheck("add", "-A");
                else gitCheck(list("add", paths));
            }
            gitCheck("commit", "--allow-empty", "-m", msg);
        } else {
            gitCheck("commit", "--allow-empty", "-m", msg);
        }
        String h = gitOut("rev-parse", "HEAD").trim();
        ps.add(new Patch(name, h, true, false));
        save(ps);
        System.out.println("> " + name + ((refresh || !paths.isEmpty()) ? "" : " (new)"));
    }

    static void cmdRefresh(List<String> args) throws Exception {
        ensureGit(); List<Patch> ps=load(); int ti=topIndex(ps); if (ti<0) throw new StgError("no patches applied",2);
        String msg=null; boolean index=false; List<String> paths=new ArrayList<>();
        for(int i=0;i<args.size();i++){String a=args.get(i); if(a.equals("-m")||a.equals("--message")) msg=args.get(++i); else if(a.equals("-i")||a.equals("--index")) index=true; else if(!a.startsWith("-")) paths.add(a);}
        if(!index){ if(paths.isEmpty()) gitCheck("add","-A"); else gitCheck(list("add", paths)); }
        if(msg==null) gitCheck("commit","--amend","--no-edit","--allow-empty"); else gitCheck("commit","--amend","--allow-empty","-m",msg);
        ps.get(ti).hash=gitOut("rev-parse","HEAD").trim(); save(ps);
        System.out.println("> " + ps.get(ti).name);
    }

    static void cmdRename(List<String> args) throws Exception {
        List<String> pos = new ArrayList<>();
        for (String a: args) if (!a.startsWith("-")) pos.add(a);
        List<Patch> ps = load();
        if (pos.isEmpty()) throw new StgError("missing new patch name", 2);
        String oldName, newName;
        if (pos.size() == 1) {
            int ti = topIndex(ps);
            if (ti < 0) throw new StgError("no patches applied", 2);
            oldName = ps.get(ti).name; newName = pos.get(0);
        } else {
            oldName = pos.get(0); newName = pos.get(1);
        }
        for (Patch p: ps) if (p.name.equals(newName)) throw new StgError("patch `" + newName + "' already exists", 2);
        for (Patch p: ps) if (p.name.equals(oldName)) { p.name = newName; save(ps); return; }
        throw new StgError("patch `" + oldName + "' does not exist", 2);
    }

    static void cmdSeries(List<String> args) throws Exception {
        ensureGit(); List<Patch> ps=load();
        boolean noPrefix=false,count=false,desc=false,rev=false, applied=false, unapplied=false, hidden=false, all=false, showBranch=false;
        Integer cid=null;
        for(String a:args){
            if(a.equals("-P")||a.equals("--no-prefix")) noPrefix=true; else if(a.equals("-c")||a.equals("--count")) count=true;
            else if(a.equals("-d")||a.equals("--description")) desc=true; else if(a.equals("-r")||a.equals("--reverse")) rev=true;
            else if(a.equals("-A")||a.equals("--applied")) applied=true; else if(a.equals("-U")||a.equals("--unapplied")) unapplied=true;
            else if(a.equals("-H")||a.equals("--hidden")) hidden=true; else if(a.equals("-a")||a.equals("--all")) all=true;
            else if(a.equals("--showbranch")) showBranch=true; else if(a.startsWith("-i")||a.startsWith("--commit-id")) cid=parseLen(a);
        }
        ArrayList<Patch> out=new ArrayList<>();
        for(Patch p:ps) if(all || (hidden&&p.hidden) || (applied&&p.applied) || (unapplied&&!p.applied&&!p.hidden) || (!applied&&!unapplied&&!hidden&&!p.hidden)) out.add(p);
        if(rev) Collections.reverse(out);
        if(count){System.out.println(out.size()); return;}
        int top=topIndex(ps);
        for(Patch p: out) {
            StringBuilder sb=new StringBuilder();
            if(!noPrefix) sb.append(p.hidden?'!':(ps.indexOf(p)==top?'>':(p.applied?'+':'-'))).append(' ');
            if(cid!=null){String h=p.hash; sb.append(h.substring(0, Math.min(cid, h.length()))).append(' ');}
            if(showBranch) sb.append(branch()).append(':');
            sb.append(p.name);
            if(desc) { String subj=gitOut("log","-1","--format=%s",p.hash).trim(); if(!subj.isEmpty()) sb.append(" # ").append(subj); }
            System.out.println(sb);
        }
    }

    static void cmdTop(List<String> args) throws Exception { List<Patch> ps=load(); int i=topIndex(ps); if(i<0) throw new StgError("no patches applied",2); System.out.println(ps.get(i).name); }
    static void cmdNext(List<String> args) throws Exception { for(Patch p:load()) if(!p.applied&&!p.hidden){System.out.println(p.name);return;} throw new StgError("no unapplied patches",2); }
    static void cmdPrev(List<String> args) throws Exception { List<Patch> ps=load(); int top=topIndex(ps); for(int i=top-1;i>=0;i--) if(ps.get(i).applied){System.out.println(ps.get(i).name);return;} throw new StgError("not enough patches applied",2); }

    static void cmdPop(List<String> args) throws Exception {
        List<Patch> ps=load(); int n=1; boolean all=args.contains("-a")||args.contains("--all");
        int ni=indexOfAny(args,"-n","--number"); if(ni>=0) n=Integer.parseInt(args.get(ni+1)); if(all) n=100000;
        for(int k=0;k<n;k++){int i=topIndex(ps); if(i<0){if(k==0) throw new StgError("no patches applied",2); break;} Patch p=ps.get(i); gitCheck("reset","--hard","HEAD^"); p.applied=false; save(ps); System.out.println("- "+p.name);}
    }

    static void cmdPush(List<String> args) throws Exception {
        List<Patch> ps=load(); int n=1; boolean all=args.contains("-a")||args.contains("--all");
        int ni=indexOfAny(args,"-n","--number"); if(ni>=0) n=Integer.parseInt(args.get(ni+1)); if(all) n=100000;
        for(int k=0;k<n;k++){Patch p=null; for(Patch q:ps) if(!q.applied&&!q.hidden){p=q;break;} if(p==null){if(k==0) throw new StgError("no unapplied patches",2); break;} gitCheck("cherry-pick",p.hash); p.hash=gitOut("rev-parse","HEAD").trim(); p.applied=true; save(ps); System.out.println("> "+p.name);}
    }

    static void cmdFiles(List<String> args) throws Exception {
        boolean stat=args.contains("-s")||args.contains("--stat"), bare=args.contains("--bare"); String rev=null;
        for(String a:args) if(!a.startsWith("-")) rev=a;
        String h=resolveRev(rev);
        if(stat) gitInherit("diff","--stat",h+"^",h);
        else {
            Result r=git("diff-tree","--no-commit-id","--name-status","-r",h);
            for(String line:r.out.split("\\R")) if(!line.isEmpty()) System.out.println(bare ? line.replaceFirst("^[A-Z]\\s+","") : line);
        }
    }

    static void cmdShow(List<String> args) throws Exception {
        ArrayList<String> g=new ArrayList<>(); g.add("show");
        boolean any=false;
        for(String a:args) {
            if(a.equals("-s")||a.equals("--stat")) g.add("--stat");
            else if(a.equals("--color")) {}
            else if(!a.startsWith("-")) { g.add(resolveRev(a)); any=true; }
        }
        if(!any) g.add(resolveRev(null));
        gitInherit(g);
    }

    static void cmdDiff(List<String> args) throws Exception {
        ArrayList<String> g=new ArrayList<>(); g.add("diff"); String range=null;
        for(int i=0;i<args.size();i++){String a=args.get(i); if(a.equals("-s")||a.equals("--stat")) g.add("--stat"); else if(a.equals("-r")||a.equals("--range")) range=args.get(++i); else if(!a.startsWith("-")) g.add(a);}
        if(range!=null){String[] parts=range.split("\\.\\.",-1); if(parts.length==2){g.add(1,resolveRev(parts[0])); g.add(2,resolveRev(parts[1]));}}
        gitInherit(g);
    }

    static void cmdId(List<String> args) throws Exception { String rev=null; for(String a:args) if(!a.startsWith("-")) rev=a; System.out.println(resolveRev(rev)); }
    static void cmdName(List<String> args) throws Exception { String rev=null; boolean sb=args.contains("--showbranch"); for(String a:args) if(!a.startsWith("-")) rev=a; String h=resolveRev(rev); for(Patch p:load()) if(p.hash.startsWith(h)||h.startsWith(p.hash)){System.out.println((sb?branch()+":":"")+p.name);return;} throw new StgError("no patch name for revision",2); }

    static void cmdDelete(List<String> args) throws Exception {
        List<Patch> ps=load(); if(args.contains("-t")||args.contains("--top")) { int i=topIndex(ps); if(i<0) throw new StgError("no patches applied",2); gitCheck("reset","--hard","HEAD^"); System.out.println("- "+ps.get(i).name); ps.remove(i); save(ps); return; }
        ArrayList<String> names=new ArrayList<>(); for(String a:args) if(!a.startsWith("-")) names.add(a);
        if(names.isEmpty() && (args.contains("-a")||args.contains("--all"))) { ps.clear(); save(ps); return; }
        for(String n:names) ps.removeIf(p -> p.name.equals(n)); save(ps);
    }

    static void cmdClean(List<String> args) throws Exception {
        List<Patch> ps=load(); Iterator<Patch> it=ps.iterator();
        while(it.hasNext()){Patch p=it.next(); Result r=git("diff","--quiet",p.hash+"^",p.hash); if(r.code==0){System.out.println("Deleting empty patch "+p.name); it.remove();}}
        save(ps);
    }

    static void cmdHide(List<String> args, boolean hide) throws Exception {
        List<Patch> ps = load();
        ArrayList<String> names = new ArrayList<>();
        for (String a: args) if (!a.startsWith("-")) names.add(a);
        if (names.isEmpty()) {
            int i = hide ? nextIndex(ps) : firstHiddenIndex(ps);
            if (i < 0) throw new StgError(hide ? "no unapplied patches" : "no hidden patches", 2);
            names.add(ps.get(i).name);
        }
        for (String n: names) {
            boolean found = false;
            for (Patch p: ps) if (p.name.equals(n)) { p.hidden = hide; found = true; System.out.println((hide ? "! " : "- ") + p.name); }
            if (!found) throw new StgError("patch `" + n + "' does not exist", 2);
        }
        save(ps);
    }

    static void cmdPick(List<String> args) throws Exception {
        String rev = null, name = null;
        for (int i=0;i<args.size();i++) {
            String a=args.get(i);
            if (a.equals("-n") || a.equals("--name")) name=args.get(++i);
            else if (!a.startsWith("-")) rev=a;
        }
        if (rev == null) throw new StgError("missing commit object", 2);
        String h = gitOut("rev-parse", rev).trim();
        if (name == null) name = slug(gitOut("log", "-1", "--format=%s", h).trim());
        List<Patch> ps=load();
        gitCheck("cherry-pick", h);
        String nh=gitOut("rev-parse","HEAD").trim();
        ps.add(new Patch(name, nh, true, false)); save(ps);
        System.out.println("> " + name);
    }

    static void cmdUncommit(List<String> args) throws Exception {
        int n = 1;
        int ni = indexOfAny(args, "-n", "--number");
        if (ni >= 0 && ni + 1 < args.size()) n = Integer.parseInt(args.get(ni + 1));
        List<Patch> ps = load();
        ArrayList<Patch> add = new ArrayList<>();
        for (int i=n-1; i>=0; i--) {
            String h = gitOut("rev-parse", "HEAD~" + i).trim();
            String subj = gitOut("log", "-1", "--format=%s", h).trim();
            add.add(new Patch(uniqueName(ps, add, slug(subj)), h, true, false));
        }
        ps.addAll(add); save(ps);
    }

    static void cmdCommit(List<String> args) throws Exception {
        List<Patch> ps = load();
        if (args.contains("-a") || args.contains("--all")) ps.removeIf(p -> p.applied);
        else {
            int i = topIndex(ps);
            if (i < 0) throw new StgError("no patches applied", 2);
            ps.remove(i);
        }
        save(ps);
    }

    static void cmdLog(List<String> args) throws Exception { gitInherit("log","--oneline","--decorate","--all","--max-count=30"); }

    static String resolveRev(String rev) throws Exception {
        List<Patch> ps=load();
        if(rev==null || rev.isEmpty()) { int i=topIndex(ps); return i>=0?ps.get(i).hash:gitOut("rev-parse","HEAD").trim(); }
        if(rev.equals("{base}")) return ps.isEmpty()?gitOut("rev-parse","HEAD").trim():gitOut("rev-parse",ps.get(0).hash+"^").trim();
        if(rev.endsWith("^")) { String b=resolveRev(rev.substring(0,rev.length()-1)); return gitOut("rev-parse",b+"^").trim(); }
        for(Patch p:ps) if(p.name.equals(rev)) return p.hash;
        return gitOut("rev-parse",rev).trim();
    }

    static int topIndex(List<Patch> ps){ for(int i=ps.size()-1;i>=0;i--) if(ps.get(i).applied&&!ps.get(i).hidden) return i; return -1; }
    static int nextIndex(List<Patch> ps){ for(int i=0;i<ps.size();i++) if(!ps.get(i).applied&&!ps.get(i).hidden) return i; return -1; }
    static int firstHiddenIndex(List<Patch> ps){ for(int i=0;i<ps.size();i++) if(ps.get(i).hidden) return i; return -1; }
    static String slug(String s){ String x=s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]+","-").replaceAll("^-+|-+$",""); return x.isEmpty()?"patch":x; }
    static String uniqueName(List<Patch> ps, List<Patch> extra, String base) {
        String n = base; int k = 2;
        while (true) {
            boolean hit = false;
            for (Patch p: ps) if (p.name.equals(n)) hit = true;
            for (Patch p: extra) if (p.name.equals(n)) hit = true;
            if (!hit) return n;
            n = base + "-" + k++;
        }
    }

    static List<Patch> load() throws Exception {
        ensureGit(); Path f=metaDir(branch()).resolve("series"); if(!Files.exists(f)) return new ArrayList<>();
        ArrayList<Patch> ps=new ArrayList<>();
        for(String l:Files.readAllLines(f)){ if(l.isBlank()) continue; String[] x=l.split("\t"); if(x.length>=4) ps.add(new Patch(x[0],x[1],x[2].equals("1"),x[3].equals("1"))); }
        return ps;
    }
    static void save(List<Patch> ps) throws Exception { Path d=metaDir(branch()); Files.createDirectories(d); StringBuilder sb=new StringBuilder(); for(Patch p:ps) sb.append(p.name).append('\t').append(p.hash).append('\t').append(p.applied?"1":"0").append('\t').append(p.hidden?"1":"0").append('\n'); Files.writeString(d.resolve("series"),sb.toString()); }
    static Path metaDir(String b) throws Exception { return gitDir().resolve("stg-java").resolve(b.replace('/','_')); }
    static Path gitDir() throws Exception { return cwd.resolve(gitOut("rev-parse","--git-dir").trim()).normalize(); }
    static void ensureGit() throws Exception { Result r=git("rev-parse","--git-dir"); if(r.code!=0) throw new StgError("not a git repository",2); }
    static String branch() throws Exception { return gitOut("branch","--show-current").trim(); }
    static String branchFromArgs(List<String> args) throws Exception { int i=indexOfAny(args,"-b","--branch"); return i>=0 && i+1<args.size()?args.get(i+1):branch(); }
    static int indexOfAny(List<String> xs,String...opts){ for(int i=0;i<xs.size();i++) for(String o:opts) if(xs.get(i).equals(o)) return i; return -1; }
    static Integer parseLen(String a){ int d=40; int eq=a.indexOf('='); if(eq>=0) try{d=Integer.parseInt(a.substring(eq+1));}catch(Exception ignored){} return d; }
    static ArrayList<String> list(String first,List<String> rest){ArrayList<String> r=new ArrayList<>();r.add(first);r.addAll(rest);return r;}

    static String gitOut(String... a) throws Exception { Result r=git(a); if(r.code!=0) throw new StgError(r.err.trim().isEmpty()?"git failed":r.err.trim(),2); return r.out; }
    static void gitCheck(String... a) throws Exception { Result r=git(a); if(r.code!=0) throw new StgError(r.err.trim().isEmpty()?"git failed":r.err.trim(),2); }
    static void gitCheck(List<String> a) throws Exception { Result r=git(a); if(r.code!=0) throw new StgError(r.err.trim().isEmpty()?"git failed":r.err.trim(),2); }
    static Result git(String... a) throws Exception { return git(Arrays.asList(a)); }
    static Result git(List<String> a) throws Exception {
        ArrayList<String> cmd=new ArrayList<>(); cmd.add("git"); cmd.addAll(a);
        ProcessBuilder pb=new ProcessBuilder(cmd); pb.directory(cwd.toFile());
        Process p=pb.start(); String out=new String(p.getInputStream().readAllBytes(),StandardCharsets.UTF_8); String err=new String(p.getErrorStream().readAllBytes(),StandardCharsets.UTF_8); int c=p.waitFor(); return new Result(c,out,err);
    }
    static void gitInherit(String... a) throws Exception { gitInherit(Arrays.asList(a)); }
    static void gitInherit(List<String> a) throws Exception {
        ArrayList<String> cmd=new ArrayList<>(); cmd.add("git"); cmd.addAll(a);
        Process p=new ProcessBuilder(cmd).directory(cwd.toFile()).inheritIO().start(); System.exit(p.waitFor());
    }
    static class StgError extends Exception { int code; StgError(String m,int c){super(m);code=c;} }
}
