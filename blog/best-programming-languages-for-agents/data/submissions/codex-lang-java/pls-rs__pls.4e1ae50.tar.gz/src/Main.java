import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static final String VERSION = "pls 0.0.1-beta.9";
    static final String ICON_DIR = "";
    static final String ICON_FILE = "";
    static final String ICON_LINK = "󰌹";
    static final String ICON_PIPE = "󰟥";
    static final String ICON_EXEC = "";
    static final String ICON_TARGET = "󰁔";
    static final String ICON_BAD_TARGET = "󱞣";

    enum Detail { dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks, btime, ctime, mtime, atime, git }
    static class Opt {
        boolean header=true, grid=false, down=false, icon=true, suffix=true, sym=true, collapse=true, align=true;
        String unit="binary";
        int imp=0;
        List<Detail> details = new ArrayList<>();
        Set<String> types = new LinkedHashSet<>(List.of("all"));
        List<String> excludes = new ArrayList<>(), only = new ArrayList<>();
        List<String> sorts = new ArrayList<>(List.of("cat","cname"));
        List<String> paths = new ArrayList<>();
    }
    static class Node {
        Path path; String display; String name; boolean isDir,isLink,isReg,isFifo,isSocket,isBlock,isChar,isExec; String target; boolean targetExists;
        long size, blocks, dev, ino, nlink, uid, gid; Set<PosixFilePermission> perms=EnumSet.noneOf(PosixFilePermission.class);
        String user="", group=""; FileTime mtime, atime, ctime, btime;
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt.paths.isEmpty()) opt.paths.add(".");
            run(opt);
        } catch (Help h) { System.out.print(h.longHelp ? longHelp() : shortHelp()); }
          catch (Version v) { System.out.println(VERSION); }
          catch (CliError e) { System.err.print(e.getMessage()); System.exit(2); }
          catch (Exception e) { System.err.println("error: " + e.getMessage()); System.exit(1); }
    }

    static class Help extends RuntimeException { boolean longHelp; Help(boolean l){longHelp=l;} }
    static class Version extends RuntimeException {}
    static class CliError extends Exception { CliError(String m){super(m);} }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("--")) { for (int j=i+1;j<args.length;j++) o.paths.add(args[j]); break; }
            if (a.equals("-h")) throw new Help(false);
            if (a.equals("--help")) throw new Help(true);
            if (a.equals("-V") || a.equals("--version")) throw new Version();
            if (a.startsWith("--")) {
                String name=a, val=null; int eq=a.indexOf('='); if(eq>0){name=a.substring(0,eq); val=a.substring(eq+1);} 
                switch(name){
                    case "--det": val=need(args,++i,val,name); addDetail(o,val); break;
                    case "--header": o.header=parseBool(need(args,++i,val,name),name); break;
                    case "--unit": o.unit=choice(need(args,++i,val,name),name,List.of("binary","decimal","none")); break;
                    case "--grid": o.grid=parseBool(need(args,++i,val,name),name); break;
                    case "--down": o.down=parseBool(need(args,++i,val,name),name); break;
                    case "--icon": o.icon=parseBool(need(args,++i,val,name),name); break;
                    case "--suffix": o.suffix=parseBool(need(args,++i,val,name),name); break;
                    case "--sym": o.sym=parseBool(need(args,++i,val,name),name); break;
                    case "--collapse": o.collapse=parseBool(need(args,++i,val,name),name); break;
                    case "--align": o.align=parseBool(need(args,++i,val,name),name); break;
                    case "--typ": addType(o,need(args,++i,val,name)); break;
                    case "--imp": o.imp=Integer.parseInt(need(args,++i,val,name)); break;
                    case "--exclude": o.excludes.add(need(args,++i,val,name)); break;
                    case "--only": o.only.add(need(args,++i,val,name)); break;
                    case "--sort": addSort(o,need(args,++i,val,name)); break;
                    default: throw unexpected(a);
                }
            } else if (a.startsWith("-") && a.length()>1) {
                if (a.length()>2) throw unexpected(a);
                String sw=a.substring(1); String val;
                switch(sw){
                    case "d": val=need(args,++i,null,a); addDetail(o,val); break;
                    case "H": o.header=parseBool(need(args,++i,null,a),a); break;
                    case "u": o.unit=choice(need(args,++i,null,a),a,List.of("binary","decimal","none")); break;
                    case "g": o.grid=parseBool(need(args,++i,null,a),a); break;
                    case "D": o.down=parseBool(need(args,++i,null,a),a); break;
                    case "i": o.icon=parseBool(need(args,++i,null,a),a); break;
                    case "S": o.suffix=parseBool(need(args,++i,null,a),a); break;
                    case "l": o.sym=parseBool(need(args,++i,null,a),a); break;
                    case "c": o.collapse=parseBool(need(args,++i,null,a),a); break;
                    case "a": o.align=parseBool(need(args,++i,null,a),a); break;
                    case "t": addType(o,need(args,++i,null,a)); break;
                    case "I": o.imp=Integer.parseInt(need(args,++i,null,a)); break;
                    case "e": o.excludes.add(need(args,++i,null,a)); break;
                    case "o": o.only.add(need(args,++i,null,a)); break;
                    case "s": addSort(o,need(args,++i,null,a)); break;
                    default: throw unexpected(a);
                }
            } else o.paths.add(a);
        }
        return o;
    }
    static String need(String[] args,int i,String val,String name) throws CliError { if(val!=null) return val; if(i>=args.length) throw new CliError("error: a value is required for '"+name+" <VALUE>'\n"); return args[i]; }
    static boolean parseBool(String s,String n) throws CliError { if(s.equals("true")) return true; if(s.equals("false")) return false; throw new CliError("error: invalid value '"+s+"' for '"+n+"'\n"); }
    static String choice(String s,String n,List<String> vals) throws CliError { if(vals.contains(s)) return s; throw new CliError("error: invalid value '"+s+"' for '"+n+"'\n"); }
    static CliError unexpected(String a){ return new CliError("error: unexpected argument '"+a+"' found\n\n  tip: to pass '"+a+"' as a value, use '-- "+a+"'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n"); }
    static void addDetail(Opt o,String v) throws CliError { if(v.equals("none")){o.details.clear();return;} if(v.equals("std")){o.details.clear(); for(String s:List.of("nlink","typ","perm","user","group","size","mtime")) o.details.add(Detail.valueOf(s)); return;} if(v.equals("all")){o.details.clear(); for(Detail d:Detail.values()) if(d!=Detail.git) o.details.add(d); return;} try{o.details.add(Detail.valueOf(v.replace('-','_')));}catch(Exception e){throw new CliError("error: invalid value '"+v+"' for '--det <DETAILS>'\n");} }
    static void addType(Opt o,String v) throws CliError { Set<String> ok=Set.of("dir","symlink","fifo","socket","block-device","char-device","file","none","all"); if(!ok.contains(v)) throw new CliError("error: invalid value '"+v+"' for '--typ <TYPES>'\n"); if(o.types.contains("all")) o.types.clear(); if(v.equals("none")) o.types.clear(); else o.types.add(v); }
    static void addSort(Opt o,String v){ if(o.sorts.equals(List.of("cat","cname"))) o.sorts.clear(); o.sorts.add(v); }

    static void run(Opt opt) throws IOException {
        List<Path> paths = new ArrayList<>(); for(String p: opt.paths) paths.add(Paths.get(p));
        if(paths.size()==1) { listPath(opt, paths.get(0), false); return; }
        List<Path> bad = new ArrayList<>(), files = new ArrayList<>(), dirs = new ArrayList<>();
        for(Path p: paths) if(!Files.exists(p, LinkOption.NOFOLLOW_LINKS)) bad.add(p); else if(Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) dirs.add(p); else files.add(p);
        for(Path p: bad) printError(p);
        if(!files.isEmpty()) { List<Node> ns=new ArrayList<>(); for(Path p:files) ns.add(node(p,p.toString())); printNodes(opt, filterSort(opt,ns)); }
        for(Path d:dirs) { if(!files.isEmpty()||!bad.isEmpty()||dirs.size()>1) System.out.println((files.isEmpty()&&bad.isEmpty()?"":"\n")+d+":"); listPath(opt,d,true); }
    }
    static void listPath(Opt opt, Path p, boolean headingDone) throws IOException {
        if(!Files.exists(p, LinkOption.NOFOLLOW_LINKS)) { printError(p); return; }
        if(!Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS)) { printNodes(opt, filterSort(opt,List.of(node(p,p.toString())))); return; }
        List<Node> ns=new ArrayList<>(); try(DirectoryStream<Path> ds=Files.newDirectoryStream(p)){ for(Path c: ds) ns.add(node(c,c.getFileName().toString())); }
        printNodes(opt, filterSort(opt,ns));
    }
    static void printError(Path p){ System.out.println(p+":"); System.out.println("\terror: No such file or directory (os error 2)"); }

    static Node node(Path p,String display) throws IOException {
        Node n=new Node(); n.path=p; n.display=display; n.name=p.getFileName()==null?display:p.getFileName().toString();
        n.isDir=Files.isDirectory(p, LinkOption.NOFOLLOW_LINKS); n.isLink=Files.isSymbolicLink(p); n.isReg=Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS);
        try { Object mode=Files.getAttribute(p,"unix:mode",LinkOption.NOFOLLOW_LINKS); int m=((Number)mode).intValue(); n.isFifo=(m&0170000)==0010000; n.isChar=(m&0170000)==0020000; n.isBlock=(m&0170000)==0060000; n.isSocket=(m&0170000)==0140000; } catch(Exception ignored){}
        try { PosixFileAttributes pa=Files.readAttributes(p,PosixFileAttributes.class,LinkOption.NOFOLLOW_LINKS); n.perms=pa.permissions(); n.user=pa.owner().getName(); n.group=pa.group().getName(); n.size=pa.size(); n.mtime=pa.lastModifiedTime(); n.atime=pa.lastAccessTime(); n.ctime=pa.creationTime(); n.btime=pa.creationTime(); } catch(Exception ignored){}
        try { n.dev=numAttr(p,"unix:dev"); n.ino=numAttr(p,"unix:ino"); n.nlink=numAttr(p,"unix:nlink"); n.uid=numAttr(p,"unix:uid"); n.gid=numAttr(p,"unix:gid"); n.blocks=numAttr(p,"unix:blocks"); } catch(Exception ignored){}
        n.isExec=n.perms.contains(PosixFilePermission.OWNER_EXECUTE)||n.perms.contains(PosixFilePermission.GROUP_EXECUTE)||n.perms.contains(PosixFilePermission.OTHERS_EXECUTE);
        if(n.isLink) { Path t=Files.readSymbolicLink(p); n.target=t.toString(); Path resolved=p.getParent()==null?t:p.getParent().resolve(t); n.targetExists=Files.exists(resolved); }
        return n;
    }
    static long numAttr(Path p,String a){ try{return ((Number)Files.getAttribute(p,a,LinkOption.NOFOLLOW_LINKS)).longValue();}catch(Exception e){return 0;} }

    static List<Node> filterSort(Opt o,List<Node> ns){
        List<Node> out=new ArrayList<>(); for(Node n:ns) if(typeOk(o,n)&&patOk(o,n)) out.add(n);
        Comparator<Node> cmp=null; for(String s:o.sorts){ if(s.equals("none")) continue; boolean rev=s.endsWith("_"); String k=rev?s.substring(0,s.length()-1):s; Comparator<Node> c=comp(k); if(rev)c=c.reversed(); cmp=cmp==null?c:cmp.thenComparing(c); }
        if(cmp==null) cmp=comp("cname"); out.sort(cmp); return out;
    }
    static boolean typeOk(Opt o,Node n){ if(o.types.contains("all")) return true; String t=typeName(n); return o.types.contains(t); }
    static boolean patOk(Opt o,Node n){ for(String e:o.excludes) if(match(e,n.name)) return false; if(!o.only.isEmpty()){ for(String p:o.only) if(match(p,n.name)) return true; return false; } return true; }
    static boolean match(String pat,String name){ String rx=Pattern.quote(pat).replace("*","\\E.*\\Q").replace("?","\\E.\\Q"); return Pattern.compile("^"+rx+"$").matcher(name).find(); }
    static Comparator<Node> comp(String k){ return switch(k){
        case "dev" -> Comparator.comparingLong(n->n.dev); case "ino", "inode" -> Comparator.comparingLong(n->n.ino); case "nlink", "nlinks" -> Comparator.comparingLong(n->n.nlink);
        case "typ" -> Comparator.comparing(Main::typeName); case "cat" -> Comparator.comparingInt(Main::cat); case "user" -> Comparator.comparing(n->n.user); case "uid" -> Comparator.comparingLong(n->n.uid);
        case "group" -> Comparator.comparing(n->n.group); case "gid" -> Comparator.comparingLong(n->n.gid); case "size" -> Comparator.comparingLong(n->n.size); case "blocks" -> Comparator.comparingLong(n->n.blocks);
        case "mtime" -> Comparator.comparing(n->n.mtime); case "atime" -> Comparator.comparing(n->n.atime); case "ctime", "btime" -> Comparator.comparing(n->n.ctime);
        case "name" -> Comparator.comparing(n->n.name); case "ext" -> Comparator.comparing(Main::ext).thenComparing(Main::cname); default -> Comparator.comparing(Main::cname);
    }; }
    static int cat(Node n){ return n.isDir ? 0 : 1; }
    static String cname(Node n){ String s=n.name.startsWith(".")?n.name.substring(1):n.name; return s.toLowerCase(Locale.ROOT); }
    static String ext(Node n){ int i=n.name.lastIndexOf('.'); return i<0?"":n.name.substring(i+1).toLowerCase(Locale.ROOT); }
    static String typeName(Node n){ if(n.isDir)return"dir"; if(n.isLink)return"symlink"; if(n.isFifo)return"fifo"; if(n.isSocket)return"socket"; if(n.isBlock)return"block-device"; if(n.isChar)return"char-device"; return"file"; }
    static char typeChar(Node n){ if(n.isDir)return'd'; if(n.isLink)return'l'; if(n.isFifo)return'p'; if(n.isSocket)return's'; if(n.isBlock)return'b'; if(n.isChar)return'c'; return'f'; }

    static void printNodes(Opt o,List<Node> ns){
        if(o.grid || o.details.isEmpty()) { for(Node n: ns) System.out.println(name(o,n)); return; }
        List<String[]> rows=new ArrayList<>(); String[] heads=new String[o.details.size()+1];
        for(int i=0;i<o.details.size();i++) heads[i]=head(o.details.get(i)); heads[o.details.size()]="Name";
        int[] w=new int[heads.length]; for(int i=0;i<w.length;i++) w[i]=heads[i].length();
        for(Node n:ns){ String[] r=new String[w.length]; for(int i=0;i<o.details.size();i++) { r[i]=detail(o,o.details.get(i),n); w[i]=Math.max(w[i],r[i].length()); } r[w.length-1]=name(o,n); w[w.length-1]=Math.max(w[w.length-1],r[w.length-1].length()); rows.add(r); }
        if(o.header) printRow(heads,w,true);
        for(String[] r:rows) printRow(r,w,false);
    }
    static void printRow(String[] r,int[] w,boolean header){ StringBuilder sb=new StringBuilder(); for(int i=0;i<r.length;i++){ boolean right=i<r.length-1 && isRightHeader(i,r.length,r); if(i>0) sb.append(' '); String s=r[i]; if(i==r.length-1) sb.append(s); else if(right) sb.append(" ".repeat(Math.max(0,w[i]-s.length()))).append(s); else sb.append(s).append(" ".repeat(Math.max(0,w[i]-s.length()))); } System.out.println(sb); }
    static boolean isRightHeader(int i,int len,String[] r){ String s=r[i]; return s.matches("[0-9.]+.*") || s.equals(""); }
    static String head(Detail d){ return switch(d){ case dev->"Dev"; case ino->"Inode"; case nlink->"Link#"; case typ->"T"; case perm->"Permissions"; case oct->"SUGO"; case user->"User"; case uid->"UID"; case group->"Group"; case gid->"GID"; case size->"Size"; case blocks->"Blocks"; case btime->"Created"; case ctime->"Changed"; case mtime->"Modified"; case atime->"Accessed"; default->"Git"; }; }
    static String detail(Opt o,Detail d,Node n){ return switch(d){ case dev->""+n.dev; case ino->""+n.ino; case nlink->""+n.nlink; case typ->""+typeChar(n); case perm->perm(n); case oct->oct(n); case user->n.user; case uid->""+n.uid; case group->n.group; case gid->""+n.gid; case size->n.isDir?"":size(n.size,o.unit); case blocks->""+n.blocks; case btime->time(n.btime); case ctime->time(n.ctime); case mtime->time(n.mtime); case atime->time(n.atime); default->""; }; }
    static String perm(Node n){ return tri(n,PosixFilePermission.OWNER_READ,PosixFilePermission.OWNER_WRITE,PosixFilePermission.OWNER_EXECUTE)+" "+tri(n,PosixFilePermission.GROUP_READ,PosixFilePermission.GROUP_WRITE,PosixFilePermission.GROUP_EXECUTE)+" "+tri(n,PosixFilePermission.OTHERS_READ,PosixFilePermission.OTHERS_WRITE,PosixFilePermission.OTHERS_EXECUTE); }
    static String tri(Node n,PosixFilePermission r,PosixFilePermission w,PosixFilePermission x){ return (n.perms.contains(r)?"r":"-")+(n.perms.contains(w)?"w":"-")+(n.perms.contains(x)?"x":"-"); }
    static String oct(Node n){ int v=0; for(PosixFilePermission p:n.perms) v += switch(p){case OWNER_READ->0400;case OWNER_WRITE->0200;case OWNER_EXECUTE->0100;case GROUP_READ->040;case GROUP_WRITE->020;case GROUP_EXECUTE->010;case OTHERS_READ->04;case OTHERS_WRITE->02;case OTHERS_EXECUTE->01;}; return String.format("%3o",v); }
    static String size(long b,String unit){ if(unit.equals("none")) return b+" B"; double base=unit.equals("decimal")?1000.0:1024.0; String[] u=unit.equals("decimal")?new String[]{"B","kB","MB","GB","TB"}:new String[]{"B","KiB","MiB","GiB","TiB"}; double v=b; int i=0; while(v>=base&&i<u.length-1){v/=base;i++;} return String.format(Locale.ROOT,"%.1f %s",v,u[i]); }
    static String time(FileTime ft){ if(ft==null)return""; String s = DateTimeFormatter.ofPattern("yyyy-MMM-dd hh:mma",Locale.ENGLISH).withZone(ZoneId.systemDefault()).format(ft.toInstant()); return s.replace("AM","am").replace("PM","pm"); }
    static String name(Opt o,Node n){ StringBuilder sb=new StringBuilder(); if(o.icon){ sb.append(icon(n)).append("  "); } else sb.append(' '); sb.append(n.display); if(o.suffix){ if(n.isDir) sb.append('/'); else if(n.isLink) sb.append('@'); else if(n.isFifo) sb.append('|'); else if(n.isSocket) sb.append('='); else if(n.isExec) sb.append('*'); } if(o.sym && n.isLink) sb.append(" ").append(n.targetExists?ICON_TARGET:ICON_BAD_TARGET).append(" ").append(n.target); return sb.toString(); }
    static String icon(Node n){ if(n.isDir)return ICON_DIR; if(n.isLink)return ICON_LINK; if(n.isFifo)return ICON_PIPE; if(n.isExec)return ICON_EXEC; if(n.name.endsWith(".txt"))return ICON_FILE; return "  "; }

    static String shortHelp(){ return "pls is a prettier and powerful ls(1) for the pros.\n\nUsage: executable [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]\n\nOptions:\n  -h, --help     Print help (see more with '--help')\n  -V, --version  Print version\n\nDetail view:\n  -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:\n                         dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,\n                         btime, ctime, mtime, atime, git, none, std, all]\n  -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,\n                         false]\n  -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible\n                         values: binary, decimal, none]\n\nGrid view:\n  -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,\n                     false]\n  -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]\n\nPresentation:\n  -i, --icon <ICON>          display icons next to node names [default: true] [possible values:\n                             true, false]\n  -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]\n                             [possible values: true, false]\n  -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]\n  -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:\n                             true] [possible values: true, false]\n  -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible\n                             values: true, false]\n\nFiltering:\n  -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible\n                           values: dir, symlink, fifo, socket, block-device, char-device, file,\n                           none, all]\n  -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]\n  -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output\n  -o, --only <ONLY>        the pattern of files to exclusively show in the output\n\nSorting:\n  -s, --sort <SORT_BASES>  the set of fields to sort by, trailing `_` reverses the direction\n                           [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,\n                           uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,\n                           ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,\n                           blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]\n"; }
    static String longHelp(){ return "pls is a prettier and powerful ls(1) for the pros.\n\nRead docs: https://pls.cli.rs/\nGet source: https://github.com/pls-rs/pls/\nSponsor: https://github.com/sponsors/dhruvkb/\n\nUsage: executable [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...\n          the paths to list, each of which may be a file or directory\n          \n          [default: .]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nDetail view:\n  -d, --det <DETAILS>\n          the data points to show about each node\n          \n          [default: none]\n          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,\n          btime, ctime, mtime, atime, git, none, std, all]\n\n  -H, --header <HEADER>\n          show headers above columnar data\n          \n          [default: true]\n          [possible values: true, false]\n\n  -u, --unit <UNIT>\n          the type of units to use for the node sizes\n          \n          [default: binary]\n          [possible values: binary, decimal, none]\n\nGrid view:\n  -g, --grid <GRID>\n          display node names in multiple columns\n          \n          [default: false]\n          [possible values: true, false]\n\n  -D, --down <DOWN>\n          display node names column-first\n          \n          [default: false]\n          [possible values: true, false]\n\nPresentation:\n  -i, --icon <ICON>\n          display icons next to node names\n          \n          [default: true]\n          [possible values: true, false]\n\n  -S, --suffix <SUFFIX>\n          display node type suffixes after the node name\n          \n          [default: true]\n          [possible values: true, false]\n\n  -l, --sym <SYM>\n          show symlink targets\n          \n          [default: true]\n          [possible values: true, false]\n\n  -c, --collapse <COLLAPSE>\n          show dependent nodes as children of their principal nodes\n          \n          [default: true]\n          [possible values: true, false]\n\n  -a, --align <ALIGN>\n          align items accounting for leading dots\n          \n          [default: true]\n          [possible values: true, false]\n\nFiltering:\n  -t, --typ <TYPES>\n          the set of node types to include in the output\n          \n          [default: all]\n          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]\n\n  -I, --imp <IMP>\n          the importance cutoff to dim or hide unimportant files\n          \n          [default: 0]\n\n  -e, --exclude <EXCLUDE>\n          the pattern of files to selectively hide from the output\n\n  -o, --only <ONLY>\n          the pattern of files to exclusively show in the output\n\nSorting:\n  -s, --sort <SORT_BASES>\n          the set of fields to sort by, trailing `_` reverses the direction\n          \n          [default: cat cname]\n          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,\n          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,\n          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]\n"; }
}
