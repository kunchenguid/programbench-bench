import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Hostctl {
    static final String MARK = "##################################################################";
    static final String NOTE = "# Content under this line is handled by hostctl. DO NOT EDIT.";
    static class Entry { String profile,status,ip,host; Entry(String p,String s,String i,String h){profile=p;status=s;ip=i;host=h;} }
    static class Profile { String name,status="on"; List<Entry> entries=new ArrayList<>(); Profile(String n){name=n;} }
    static class Hosts { List<String> base=new ArrayList<>(); LinkedHashMap<String,Profile> profiles=new LinkedHashMap<>(); }
    static class Opt {
        String hostFile="/etc/hosts", out="table", columns=null, from="", path="/workspace", ip="127.0.0.1";
        boolean quiet=false, raw=false, all=false, only=false, noColor=false, prefix=false;
        List<String> args=new ArrayList<>();
    }

    public static void main(String[] argv) {
        try { new Hostctl().run(argv); }
        catch (Exception e) { error(e.getMessage()==null?e.toString():e.getMessage()); System.exit(1); }
    }

    void run(String[] argv) throws Exception {
        Opt opt=parse(argv);
        if (opt.raw) opt.out="raw";
        if (opt.args.isEmpty() || isHelp(opt.args.get(0))) { helpRoot(); return; }
        if (opt.args.contains("--help") || opt.args.contains("-h")) { printHelp(opt.args); return; }
        if (opt.args.contains("--version") || opt.args.contains("-v")) { System.out.println("hostctl version dev"); return; }
        String cmd=opt.args.remove(0);
        switch(cmd) {
            case "help": if(opt.args.isEmpty()) helpRoot(); else printHelp(opt.args); return;
            case "add": add(opt); return;
            case "replace": replace(opt); return;
            case "remove": case "rm": remove(opt); return;
            case "enable": setStatus(opt,"on"); return;
            case "disable": setStatus(opt,"off"); return;
            case "toggle": toggle(opt); return;
            case "status": status(opt); return;
            case "list": list(opt); return;
            case "backup": backup(opt); return;
            case "restore": restore(opt); return;
            case "sync": sync(opt); return;
            default: error("unknown command \""+cmd+"\" for \"hostctl\""); System.exit(1);
        }
    }

    Opt parse(String[] argv) {
        Opt o=new Opt();
        for (int i=0;i<argv.length;i++) {
            String a=argv[i];
            if (a.equals("--host-file")) o.hostFile=argv[++i];
            else if (a.startsWith("--host-file=")) o.hostFile=a.substring(12);
            else if (a.equals("-o")||a.equals("--out")) o.out=argv[++i];
            else if (a.startsWith("--out=")) o.out=a.substring(6);
            else if (a.equals("-c")||a.equals("--column")) o.columns=argv[++i];
            else if (a.startsWith("--column=")) o.columns=a.substring(9);
            else if (a.equals("-f")||a.equals("--from")) o.from=argv[++i];
            else if (a.startsWith("--from=")) o.from=a.substring(7);
            else if (a.equals("--path")) o.path=argv[++i];
            else if (a.startsWith("--path=")) o.path=a.substring(7);
            else if (a.equals("--ip")) o.ip=argv[++i];
            else if (a.startsWith("--ip=")) o.ip=a.substring(5);
            else if (a.equals("-q")||a.equals("--quiet")) o.quiet=true;
            else if (a.equals("--raw")) o.raw=true;
            else if (a.equals("--all")) o.all=true;
            else if (a.equals("--only")) o.only=true;
            else if (a.equals("--no-color")) o.noColor=true;
            else if (a.equals("--prefix")) o.prefix=true;
            else if (a.equals("-w")||a.equals("--wait")||a.equals("-d")||a.equals("--domain")||a.equals("--network")||a.equals("--compose-file")||a.equals("--project-name")) i++;
            else o.args.add(a);
        }
        return o;
    }

    void add(Opt o) throws Exception {
        if (!o.args.isEmpty() && (o.args.get(0).equals("domains")||o.args.get(0).equals("domain"))) { o.args.remove(0); addDomains(o); return; }
        if (o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        String name=o.args.get(0);
        List<Entry> es=readEntriesFromFile(name,"on",o.from);
        Profile p=h.profiles.computeIfAbsent(name, Profile::new); p.status="on"; p.entries.addAll(es);
        write(o.hostFile,h);
        output(o, es);
    }

    void addDomains(Opt o) throws Exception {
        if (o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        String name=o.args.remove(0);
        if (o.args.isEmpty()) die("missing domains");
        Profile p=h.profiles.computeIfAbsent(name, Profile::new); p.status="on";
        List<Entry> added=new ArrayList<>();
        for (String d:o.args) { Entry e=new Entry(name,"on",o.ip,d); p.entries.add(e); added.add(e); }
        write(o.hostFile,h);
        if (!o.quiet) { System.out.println("[✔] Domains '"+String.join(", ", o.args)+"' added.\n"); output(o, rowsForProfile(p)); }
    }

    void replace(Opt o) throws Exception {
        if (o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        String name=o.args.get(0);
        Profile p=new Profile(name); p.status="on"; p.entries=readEntriesFromFile(name,"on",o.from);
        h.profiles.put(name,p);
        write(o.hostFile,h); output(o, rowsForProfile(p));
    }

    void remove(Opt o) throws Exception {
        if (!o.args.isEmpty() && (o.args.get(0).equals("domains")||o.args.get(0).equals("domain"))) { o.args.remove(0); removeDomains(o); return; }
        if (!o.all && o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        List<String> names = o.all ? new ArrayList<>(h.profiles.keySet()) : new ArrayList<>(o.args);
        for (String n:names) h.profiles.remove(n);
        write(o.hostFile,h);
        if(!o.quiet) System.out.println("[✔] Profile(s) '"+String.join(", ", names)+"' removed.\n");
    }

    void removeDomains(Opt o) throws Exception {
        if (o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        String name=o.args.remove(0); Profile p=h.profiles.get(name); if(p==null) die("unknown profile name");
        Set<String> ds=new LinkedHashSet<>(o.args); p.entries.removeIf(e -> ds.contains(e.host));
        write(o.hostFile,h);
        if(!o.quiet){ System.out.println("[✔] Domains '"+String.join(", ", o.args)+"' removed.\n"); output(o, rowsForProfile(p)); }
    }

    void setStatus(Opt o,String st) throws Exception {
        if (!o.all && o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        List<Profile> changed=new ArrayList<>();
        if (o.all) { for(Profile p:h.profiles.values()){p.status=st; changed.add(p);} }
        else {
            for(String n:o.args){ Profile p=h.profiles.get(n); if(p==null) die("unknown profile name"); p.status=st; changed.add(p); }
            if(o.only) for(Profile p:h.profiles.values()) if(!o.args.contains(p.name)) p.status=st.equals("on")?"off":"on";
        }
        write(o.hostFile,h);
        List<Entry> rows=new ArrayList<>(); for(Profile p:changed) rows.addAll(rowsForProfile(p)); output(o, rows.isEmpty()?listRows(h,null):rows);
    }

    void toggle(Opt o) throws Exception {
        if (o.args.isEmpty()) die("missing profile name");
        Hosts h=read(o.hostFile); info(o);
        List<Entry> rows=new ArrayList<>();
        for(String n:o.args){ Profile p=h.profiles.get(n); if(p==null) die("unknown profile name"); p.status=p.status.equals("on")?"off":"on"; rows.addAll(rowsForProfile(p)); }
        write(o.hostFile,h); output(o, rows);
    }

    void status(Opt o) throws Exception {
        Hosts h=read(o.hostFile); info(o);
        Set<String> filt=new LinkedHashSet<>(o.args);
        List<Entry> rows=new ArrayList<>();
        for(Profile p:h.profiles.values()) if(filt.isEmpty()||filt.contains(p.name)) rows.add(new Entry(p.name,p.status,"",""));
        output(o, rows);
    }

    void list(Opt o) throws Exception {
        String mode=null;
        if(!o.args.isEmpty() && (o.args.get(0).equals("enabled")||o.args.get(0).equals("on"))) {mode="on"; o.args.remove(0);}
        else if(!o.args.isEmpty() && (o.args.get(0).equals("disabled")||o.args.get(0).equals("off"))) {mode="off"; o.args.remove(0);}
        Hosts h=read(o.hostFile); info(o);
        output(o, listRows(h,mode,new LinkedHashSet<>(o.args)));
    }

    void backup(Opt o) throws Exception {
        Hosts h=read(o.hostFile); info(o);
        Path src=Paths.get(o.hostFile);
        String dest=o.path.equals("/workspace") ? o.hostFile+"."+LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
                : Paths.get(o.path, src.getFileName().toString()+"."+LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)).toString();
        Files.copy(src, Paths.get(dest), StandardCopyOption.REPLACE_EXISTING);
        if(!o.quiet) System.out.println("[✔] Backup '"+dest+"' created.\n");
        output(o, listRows(h,null));
    }

    void restore(Opt o) throws Exception {
        if(o.from.isEmpty()) die("missing file name");
        Files.copy(Paths.get(o.from), Paths.get(o.hostFile), StandardCopyOption.REPLACE_EXISTING);
        Hosts h=read(o.hostFile); info(o);
        if(!o.quiet) System.out.println("[✔] File '"+o.from+"' restored.\n");
        output(o, listRows(h,null));
    }

    void sync(Opt o) throws Exception {
        if(o.args.isEmpty()) { printHelp(Collections.singletonList("sync")); return; }
        if(o.args.get(0).startsWith("docker")) die("Cannot connect to the Docker daemon");
    }

    Hosts read(String file) throws IOException {
        Hosts h=new Hosts(); Path p=Paths.get(file);
        List<String> lines=Files.exists(p)?Files.readAllLines(p,StandardCharsets.UTF_8):new ArrayList<>();
        int i=0; while(i<lines.size() && !lines.get(i).equals(MARK)) h.base.add(lines.get(i++));
        while(i<lines.size()) {
            String line=lines.get(i++);
            if(line.startsWith("# profile.")) {
                String[] sp=line.substring(10).trim().split("\\s+",2);
                if(sp.length<2) continue;
                Profile pr=new Profile(sp[1]); pr.status=sp[0]; h.profiles.put(pr.name, pr);
                while(i<lines.size() && !lines.get(i).trim().equals("# end")) {
                    String l=lines.get(i++).trim(); if(l.isEmpty()) continue;
                    if(l.startsWith("#")) l=l.substring(1).trim();
                    addLineEntries(pr.entries, pr.name, pr.status, l);
                }
            }
        }
        return h;
    }

    void write(String file, Hosts h) throws IOException {
        List<String> out=new ArrayList<>(h.base);
        while(!out.isEmpty() && out.get(out.size()-1).isEmpty()) out.remove(out.size()-1);
        out.add(""); out.add(MARK); out.add(NOTE); out.add(MARK);
        for(Profile p:h.profiles.values()) {
            out.add(""); out.add("# profile."+p.status+" "+p.name);
            for(Entry e:p.entries) out.add((p.status.equals("off")?"# ":"")+e.ip+" "+e.host);
            out.add("# end");
        }
        Files.write(Paths.get(file), out, StandardCharsets.UTF_8);
    }

    List<Entry> readEntriesFromFile(String profile,String status,String file) throws IOException {
        List<Entry> es=new ArrayList<>();
        for(String l:Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8)) addLineEntries(es,profile,status,l.trim());
        return es;
    }
    void addLineEntries(List<Entry> es,String p,String s,String l) {
        if(l.isEmpty()||l.startsWith("#")) return;
        String[] parts=l.split("\\s+"); if(parts.length<2) return;
        for(int i=1;i<parts.length;i++) es.add(new Entry(p,s,parts[0],parts[i]));
    }
    List<Entry> rowsForProfile(Profile p){ List<Entry> r=new ArrayList<>(); for(Entry e:p.entries) r.add(new Entry(p.name,p.status,e.ip,e.host)); return r; }
    List<Entry> listRows(Hosts h,String mode) { return listRows(h, mode, Collections.emptySet()); }
    List<Entry> listRows(Hosts h,String mode,Set<String> filter) {
        List<Entry> r=new ArrayList<>();
        boolean wantDefault=filter.isEmpty()||filter.contains("default");
        if(wantDefault && (mode==null||mode.equals("on"))) for(String l:h.base) { String t=l.trim(); if(t.isEmpty()||t.startsWith("#")) continue; String[] sp=t.split("\\s+"); for(int i=1;i<sp.length;i++) r.add(new Entry("default","on",sp[0],sp[i])); }
        for(Profile p:h.profiles.values()) if((filter.isEmpty()||filter.contains(p.name)) && (mode==null||mode.equals(p.status))) r.addAll(rowsForProfile(p));
        return r;
    }

    void info(Opt o){ if(!o.quiet && !o.out.equals("json")) System.out.println("[ℹ] Using hosts file: "+o.hostFile+"\n"); }
    static void error(String m){ System.out.println("[✖] error: "+m); }
    static void die(String m){ throw new RuntimeException(m); }

    void output(Opt o,List<Entry> rows) {
        if(o.quiet) return;
        List<String> cols=columns(o, rows);
        if(o.out.equals("json")) { json(rows); return; }
        List<String[]> data=new ArrayList<>(); data.add(cols.toArray(new String[0]));
        for(Entry e:rows) data.add(values(e,cols));
        int[] w=widths(data);
        if(o.out.equals("raw")) raw(data,w);
        else if(o.out.equals("markdown")) markdown(data,w,rows,cols);
        else table(data,w,rows,cols);
    }
    List<String> columns(Opt o,List<Entry> rows) {
        if(o.columns!=null){ List<String> c=new ArrayList<>(); for(String s:o.columns.split(",")) c.add(normCol(s)); return c; }
        boolean statusOnly=true; for(Entry e:rows) if(!e.ip.isEmpty()||!e.host.isEmpty()) statusOnly=false;
        return statusOnly?Arrays.asList("PROFILE","STATUS"):Arrays.asList("PROFILE","STATUS","IP","DOMAIN");
    }
    String normCol(String s){ s=s.trim().toUpperCase(Locale.ROOT); if(s.equals("HOST")) return "DOMAIN"; return s; }
    String[] values(Entry e,List<String> cols){ String[] v=new String[cols.size()]; for(int i=0;i<cols.size();i++){ switch(cols.get(i)){case "PROFILE":v[i]=e.profile;break;case "STATUS":v[i]=e.status;break;case "IP":v[i]=e.ip;break;default:v[i]=e.host;}} return v; }
    int[] widths(List<String[]> data){ int n=data.get(0).length; int[] w=new int[n]; for(String[] r:data) for(int i=0;i<n;i++) w[i]=Math.max(w[i], r[i].length()); return w; }
    String pad(String s,int w){ return s+" ".repeat(Math.max(0,w-s.length())); }
    String center(String s,int w){ int d=w-s.length(), l=d/2, r=d-l; return " ".repeat(l)+s+" ".repeat(r); }
    void raw(List<String[]> data,int[] w){ for(String[] r:data){ for(int i=0;i<r.length;i++){ if(i>0) System.out.print("\t"); System.out.print(pad(r[i],w[i])); } System.out.println(); } }
    String border(int[] w){ StringBuilder b=new StringBuilder("+"); for(int x:w)b.append("-".repeat(x+2)).append("+"); return b.toString(); }
    void table(List<String[]> data,int[] w,List<Entry> rows,List<String> cols){
        String b=border(w); System.out.println(b); printRow(data.get(0),w,true); System.out.println(b);
        String last=null; for(int i=1;i<data.size();i++){ Entry e=rows.get(i-1); if(last!=null&&!last.equals(e.profile)) System.out.println(b); printRow(data.get(i),w,false); last=e.profile; }
        System.out.println(b);
    }
    void printRow(String[] r,int[] w,boolean head){ System.out.print("|"); for(int i=0;i<r.length;i++) System.out.print(" "+(head?center(r[i],w[i]):pad(r[i],w[i]))+" |"); System.out.println(); }
    void markdown(List<String[]> data,int[] w,List<Entry> rows,List<String> cols){
        printMd(data.get(0),w,true); System.out.print("|"); for(int x:w) System.out.print("-".repeat(x+2)+"|"); System.out.println();
        String last=null; for(int i=1;i<data.size();i++){ Entry e=rows.get(i-1); if(last!=null&&!last.equals(e.profile)){System.out.print("|"); for(int x:w) System.out.print("-".repeat(x+2)+"|"); System.out.println();} printMd(data.get(i),w,false); last=e.profile; }
    }
    void printMd(String[] r,int[] w,boolean head){ System.out.print("|"); for(int i=0;i<r.length;i++) System.out.print(" "+(head?center(r[i],w[i]):pad(r[i],w[i]))+" |"); System.out.println(); }
    void json(List<Entry> rows){ StringBuilder s=new StringBuilder("["); for(int i=0;i<rows.size();i++){ Entry e=rows.get(i); if(i>0)s.append(","); s.append("{\"Profile\":\"").append(esc(e.profile)).append("\",\"Status\":\"").append(e.status).append("\",\"IP\":\"").append(esc(e.ip)).append("\",\"Host\":\"").append(esc(e.host)).append("\"}"); } System.out.println(s.append("]")); }
    String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }

    boolean isHelp(String s){ return s.equals("-h")||s.equals("--help"); }
    void printHelp(List<String> args){ String c=args.isEmpty()?"":args.get(0), d=args.size()>1?args.get(1):""; if(c.equals("add")&&(d.equals("domains")||d.equals("domain"))) helpAddDomains(); else if((c.equals("remove")||c.equals("rm"))&&(d.equals("domains")||d.equals("domain"))) helpRemoveDomains(); else if(c.equals("add")) helpAdd(); else if(c.equals("remove")||c.equals("rm")) helpRemove(); else if(c.equals("list")&&(d.equals("enabled")||d.equals("on"))) helpListEnabled(); else if(c.equals("list")&&(d.equals("disabled")||d.equals("off"))) helpListDisabled(); else if(c.equals("list")) helpList(); else if(c.equals("backup")) helpBackup(); else if(c.equals("restore")) helpRestore(); else if(c.equals("sync")) helpSync(); else helpRoot(); }
    void helpRoot(){ System.out.println("\nhostctl is a CLI tool to manage your hosts file with ease.\nYou can have multiple profiles, enable/disable exactly what\nyou need each time with a simple interface.\n\nUsage:\n  hostctl [command]\n\nAvailable Commands:\n  add         Add content to a profile in your hosts file.\n  backup      Creates a backup copy of your hosts file\n  disable     Disable a profile from your hosts file.\n  enable      Enable a profile on your hosts file.\n  help        Help about any command\n  list        Shows a detailed list of profiles on your hosts file.\n  remove      Remove a profile from your hosts file.\n  replace     Replace content to a profile in your hosts file.\n  restore     Restore hosts file content from a backup file.\n  status      Shows a list of profile names and statuses on your hosts file.\n  sync        Sync some system IPs with a profile.\n  toggle      Change status of a profile on your hosts file.\n\nFlags:\n  -c, --column strings     Column names to show on lists. comma separated\n  -h, --help               help for hostctl\n      --host-file string   Hosts file path (default \"/etc/hosts\")\n      --no-color           force colorless output\n  -o, --out string         Output type (table|raw|markdown|json) (default \"table\")\n  -q, --quiet              Run command without output\n      --raw                Output without borders (same as -o raw)\n  -v, --version            version for hostctl\n\nUse \"hostctl [command] --help\" for more information about a command."); }
    void helpAdd(){ System.out.println("\nReads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add [profiles] [flags]\n  hostctl add [command]\n\nAvailable Commands:\n  domains     Add content in your hosts file.\n\nFlags:\n  -f, --from string     file to read\n  -h, --help            help for add\n  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)\n\nGlobal Flags:\n  -c, --column strings     Column names to show on lists. comma separated\n      --host-file string   Hosts file path (default \"/etc/hosts\")\n      --no-color           force colorless output\n  -o, --out string         Output type (table|raw|markdown|json) (default \"table\")\n  -q, --quiet              Run command without output\n      --raw                Output without borders (same as -o raw)\n\nUse \"hostctl add [command] --help\" for more information about a command."); }
    void helpAddDomains(){ System.out.println("\nSet content in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add domains [profile] [domains] [flags]\n\nAliases:\n  domains, domain [profile] [domains] [flags]\n\nFlags:\n  -h, --help        help for domains\n      --ip string   domains ip (default \"127.0.0.1\")"); }
    void helpRemove(){ System.out.println("\nCompletely remove a profile content from your hosts file.\nIt cannot be undone unless you have a backup and restore it.\n\nUsage:\n  hostctl remove [profiles] [flags]\n  hostctl remove [command]\n\nAliases:\n  remove, rm [profiles] [flags]\n\nAvailable Commands:\n  domains     Remove domains from your hosts file.\n\nFlags:\n      --all    Remove all profiles\n  -h, --help   help for remove\n\nGlobal Flags:\n  -c, --column strings     Column names to show on lists. comma separated\n      --host-file string   Hosts file path (default \"/etc/hosts\")\n      --no-color           force colorless output\n  -o, --out string         Output type (table|raw|markdown|json) (default \"table\")\n  -q, --quiet              Run command without output\n      --raw                Output without borders (same as -o raw)\n\nUse \"hostctl remove [command] --help\" for more information about a command."); }
    void helpRemoveDomains(){ System.out.println("\nCompletely remove domains from your hosts file.\nIt cannot be undone unless you have a backup and restore it.\n\nUsage:\n  hostctl remove domains [profile] [domains] [flags]\n\nAliases:\n  domains, domain [profile] [domains] [flags]\n\nFlags:\n  -h, --help   help for domains"); }
    void helpList(){ System.out.println("\nShows a detailed list of profiles on your hosts file with name, ip and host name.\nYou can filter by profile name.\n\nThe \"default\" profile is all the content that is not handled by hostctl tool.\n\nUsage:\n  hostctl list [profiles] [flags]\n  hostctl list [command]\n\nAvailable Commands:\n  disabled    Shows list of disabled profiles on your hosts file.\n  enabled     Shows list of enabled profiles on your hosts file.\n\nFlags:\n  -h, --help   help for list"); }
    void helpListEnabled(){ System.out.println("\nShows a detailed list of enabled profiles on your hosts file with name, ip and host name.\n\nUsage:\n  hostctl list enabled [flags]\n\nAliases:\n  enabled, on\n\nFlags:\n  -h, --help   help for enabled"); }
    void helpListDisabled(){ System.out.println("\nShows a detailed list of disabled profiles on your hosts file with name, ip and host name.\n\nUsage:\n  hostctl list disabled [flags]\n\nAliases:\n  disabled, off\n\nFlags:\n  -h, --help   help for disabled"); }
    void helpBackup(){ System.out.println("\nCreates a backup copy of your hosts file with the date in .YYYYMMDD\nas extension.\n\nUsage:\n  hostctl backup [flags]\n\nFlags:\n  -h, --help          help for backup\n      --path string   A path to save the backup (default \"/workspace\")"); }
    void helpRestore(){ System.out.println("\nReads from a file and replace the content of your hosts file.\n\nWARNING: the complete hosts file will be overwritten with the backup data.\n\nUsage:\n  hostctl restore [flags]\n\nFlags:\n      --from string   The file to restore from\n  -h, --help          help for restore"); }
    void helpSync(){ System.out.println("\nReads IPs and names from some local system and sync it with a profile in your hosts file.\n\nUsage:\n  hostctl sync [command]\n\nAvailable Commands:\n  docker         Sync your Docker containers IPs with a profile.\n  docker-compose Sync your docker-compose containers IPs with a profile."); }
}
