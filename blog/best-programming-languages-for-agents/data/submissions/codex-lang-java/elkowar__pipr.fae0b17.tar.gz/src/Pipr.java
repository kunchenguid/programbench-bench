import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Pipr {
    private static final String HELP = """
Usage: ./executable [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
""";

    private static final String CONFIG = """

#  ____  _
# |  _ \\(_)_ __  _ __       .________.
# | |_) | | '_ \\| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"
""";

    private static class Options {
        String defaultText = "";
        String outFile = null;
        String inFile = null;
        boolean configReference = false;
        boolean rawMode = false;
        boolean noIsolation = false;
    }

    public static void main(String[] args) {
        int status;
        try {
            status = run(args);
        } catch (KnownError e) {
            System.err.println(e.getMessage());
            status = 1;
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            status = 1;
        }
        if (status != 0) {
            System.exit(status);
        }
    }

    private static int run(String[] args) throws Exception {
        Options opt = parse(args);
        if (opt.configReference) {
            System.out.print(CONFIG + "\n");
            return 0;
        }
        String command = opt.defaultText;
        if (opt.inFile != null) {
            try {
                command = Files.readString(Path.of(opt.inFile), StandardCharsets.UTF_8);
            } catch (NoSuchFileException e) {
                throw new KnownError("Error: No such file or directory (os error 2)");
            }
            if (command.endsWith("\n")) {
                command = command.substring(0, command.length() - 1);
            }
            if (command.endsWith("\r")) {
                command = command.substring(0, command.length() - 1);
            }
        }
        if (!opt.noIsolation && !hasCommand("bwrap")) {
            System.err.println("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode");
            return 1;
        }
        if (System.console() == null) {
            System.err.print("\033[?1049h");
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        return interactive(command, opt);
    }

    private static Options parse(String[] args) throws KnownError {
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h", "--help" -> {
                    System.out.print(helpText());
                    System.exit(0);
                }
                case "-d", "--default" -> opt.defaultText = needArg(args, ++i, "default");
                case "-o", "--out-file" -> opt.outFile = needArg(args, ++i, "out-file");
                case "--in-file" -> opt.inFile = needArg(args, ++i, "in-file");
                case "--config-reference" -> opt.configReference = true;
                case "-r", "--raw-mode" -> opt.rawMode = true;
                case "--no-isolation" -> opt.noIsolation = true;
                default -> {
                    if (a.startsWith("--")) {
                        throw new KnownError("./executable: Unrecognized option: '" + a.substring(2) + "'");
                    }
                    if (a.startsWith("-") && a.length() > 1) {
                        throw new KnownError("./executable: Unrecognized option: '" + a.substring(1) + "'");
                    }
                    throw new KnownError("./executable: Unrecognized option: '" + a + "'");
                }
            }
        }
        return opt;
    }

    private static String helpText() {
        return HELP.replace("--config-reference\n", "--config-reference \n");
    }

    private static String needArg(String[] args, int index, String name) throws KnownError {
        if (index >= args.length) {
            throw new KnownError("./executable: Argument to option '" + name + "' missing");
        }
        return args[index];
    }

    private static int interactive(String initial, Options opt) throws Exception {
        String saved = stty("-g").trim();
        StringBuilder command = new StringBuilder(initial);
        String output = "";
        try {
            stty("raw -echo min 0 time 1");
            System.out.print("\033[?1049h");
            draw(command.toString(), output);
            while (true) {
                int ch = System.in.read();
                if (ch < 0 || ch == 3 || ch == 4 || ch == 27) {
                    finish(command.toString(), opt);
                    return 0;
                }
                if (ch == 13 || ch == 10) {
                    output = evaluate(command.toString());
                    draw(command.toString(), output);
                    continue;
                }
                if (ch == 127 || ch == 8) {
                    if (!command.isEmpty()) {
                        command.deleteCharAt(command.length() - 1);
                    }
                } else if (ch >= 32 || ch == 9) {
                    command.append((char) ch);
                }
                draw(command.toString(), output);
            }
        } finally {
            System.out.print("\033[?1049l");
            if (!saved.isBlank()) {
                stty(saved);
            } else {
                stty("sane");
            }
        }
    }

    private static void finish(String command, Options opt) throws IOException {
        String finalCommand = opt.rawMode ? command : command.replace('\n', ' ');
        if (opt.outFile != null) {
            Files.writeString(Path.of(opt.outFile), finalCommand, StandardCharsets.UTF_8);
        } else {
            System.out.print(finalCommand);
            if (!finalCommand.endsWith("\n")) {
                System.out.print("\n");
            }
        }
    }

    private static void draw(String command, String output) {
        int[] size = termSize();
        int rows = size[0] <= 0 ? 24 : size[0];
        int cols = size[1] <= 0 ? 80 : size[1];
        System.out.print("\033[2J\033[H");
        line("┌ Command [Autoeval] ", cols, '┐');
        for (String l : split(command)) {
            framed(l, cols);
        }
        line("└", cols, '┘');
        line("┌ Output [+] ", cols, '┐');
        List<String> outLines = split(output);
        int used = 4 + Math.max(1, split(command).size());
        int avail = Math.max(1, rows - used - 2);
        for (int i = 0; i < avail; i++) {
            framed(i < outLines.size() ? outLines.get(i) : "", cols);
        }
        line("└", cols, '┘');
        System.out.flush();
    }

    private static List<String> split(String s) {
        String[] parts = s.split("\\n", -1);
        List<String> list = new ArrayList<>();
        for (String p : parts) {
            list.add(p);
        }
        if (list.isEmpty()) {
            list.add("");
        }
        return list;
    }

    private static void line(String prefix, int cols, char end) {
        int dashes = Math.max(0, cols - prefix.length() - 1);
        System.out.print(prefix);
        System.out.print("─".repeat(dashes));
        System.out.print(end);
        System.out.print("\r\n");
    }

    private static void framed(String text, int cols) {
        int inner = Math.max(1, cols - 2);
        String clean = text.replace("\r", "");
        if (clean.length() > inner) {
            clean = clean.substring(0, inner);
        }
        System.out.print("│");
        System.out.print(clean);
        System.out.print(" ".repeat(Math.max(0, inner - clean.length())));
        System.out.print("│\r\n");
    }

    private static String evaluate(String command) {
        if (command.isBlank()) {
            return "";
        }
        try {
            Process p = new ProcessBuilder("bash", "-c", command).redirectErrorStream(true).start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = p.getInputStream()) {
                byte[] buf = new byte[4096];
                long end = System.currentTimeMillis() + 2000;
                while (System.currentTimeMillis() < end) {
                    while (in.available() > 0) {
                        int n = in.read(buf);
                        if (n < 0) break;
                        out.write(buf, 0, n);
                    }
                    try {
                        if (p.waitFor(25, java.util.concurrent.TimeUnit.MILLISECONDS)) {
                            break;
                        }
                    } catch (InterruptedException ignored) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                if (p.isAlive()) {
                    p.destroyForcibly();
                }
            }
            return out.toString(StandardCharsets.UTF_8);
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    private static int[] termSize() {
        try {
            String[] parts = stty("size").trim().split("\\s+");
            if (parts.length == 2) {
                return new int[]{Integer.parseInt(parts[0]), Integer.parseInt(parts[1])};
            }
        } catch (Exception ignored) {
        }
        return new int[]{24, 80};
    }

    private static String stty(String arg) throws IOException, InterruptedException {
        Process p = new ProcessBuilder("sh", "-c", "stty " + arg + " < /dev/tty").redirectErrorStream(true).start();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (InputStream in = p.getInputStream()) {
            in.transferTo(out);
        }
        p.waitFor();
        return out.toString(StandardCharsets.UTF_8);
    }

    private static boolean hasCommand(String name) {
        try {
            Process p = new ProcessBuilder("sh", "-c", "command -v " + name + " >/dev/null 2>&1").start();
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private static class KnownError extends Exception {
        KnownError(String message) {
            super(message);
        }
    }
}
