import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.PosixFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Fd {
    static class Opt {
        boolean hidden, noIgnore, caseSensitive, ignoreCase, glob, fixed, absolute, follow, fullPath, print0;
        boolean quiet, listDetails, prune, showErrors, regex = true;
        int maxDepth = Integer.MAX_VALUE, minDepth = 1, maxResults = Integer.MAX_VALUE, batchSize = 0;
        String color = "auto", hyperlink = "never", format = null, pathSep = "/";
        Path baseDir = Paths.get("").toAbsolutePath().normalize();
        List<String> patterns = new ArrayList<>();
        List<Path> roots = new ArrayList<>();
        List<String> exts = new ArrayList<>(), excludes = new ArrayList<>(), ignoreFiles = new ArrayList<>(), ignoreContain = new ArrayList<>();
        Set<Character> types = new HashSet<>();
        Long size = null; char sizeCmp = '=';
        Instant changedWithin = null, changedBefore = null;
        List<String> exec = null, execBatch = null;
        String stripCwd = "auto";
    }

    static class Entry {
        Path path, root; int depth; BasicFileAttributes attrs; boolean isSymlink, rootAbsolute;
        Entry(Path p, Path r, int d, BasicFileAttributes a, boolean l, boolean abs) { path=p; root=r; depth=d; attrs=a; isSymlink=l; rootAbsolute=abs; }
    }

    static final String HELP_SHORT = """
A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -d, --max-depth <depth>          Set maximum search depth (default: none)
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l), executable (x), empty (e)
  -e, --extension <ext>            Filter by file extension
  -S, --size <size>                Limit results based on the size of files
      --changed-within <date|dur>  Filter by file modification time (newer than)
      --changed-before <date|dur>  Filter by file modification time (older than)
      --format <fmt>               Print results according to template
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command with all search results at once
  -0, --print0                     Separate search results by the null character
  -q, --quiet                      Return 0 if there is at least one match
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
""";

    static final String HELP_LONG = HELP_SHORT + "\nBugs can be reported on GitHub: https://github.com/sharkdp/fd/issues\n";

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o == null) return;
            if (o.roots.isEmpty()) o.roots.add(Paths.get("."));
            List<Pattern> pats = compilePatterns(o);
            List<Entry> results = new ArrayList<>();
            for (Path r : o.roots) walk(o, r, results, pats);
            results.sort(Comparator.comparing(e -> outputPath(o, e, false)));
            if (o.maxResults != Integer.MAX_VALUE && results.size() > o.maxResults) results = new ArrayList<>(results.subList(0, o.maxResults));
            if (o.quiet) System.exit(results.isEmpty() ? 1 : 0);
            int status = 0;
            if (o.listDetails) {
                status = runBatch(commandWithDefault(List.of("ls","-l","-d"), results, o), results, o);
            } else if (o.exec != null) {
                for (Entry e : results) status = Math.max(status, runOne(commandForEntry(o.exec, e, o), o.baseDir));
            } else if (o.execBatch != null) {
                status = runBatch(commandWithDefault(o.execBatch, results, o), results, o);
            } else {
                for (Entry e : results) printEntry(o, e);
            }
            System.exit(status);
        } catch (UsageException e) {
            System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("[fd error]: " + e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) throws UsageException {
        Opt o = new Opt();
        boolean positionalOnly = false;
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (!positionalOnly && a.equals("--")) { positionalOnly=true; continue; }
            if (!positionalOnly && a.startsWith("-") && !a.equals("-")) {
                String val = null;
                int eq = a.indexOf('=');
                if (eq > 0) { val = a.substring(eq+1); a = a.substring(0, eq); }
                switch (a) {
                    case "-H": case "--hidden": o.hidden=true; break;
                    case "--no-hidden": o.hidden=false; break;
                    case "-I": case "--no-ignore": o.noIgnore=true; break;
                    case "--ignore": o.noIgnore=false; break;
                    case "-u": case "--unrestricted": o.hidden=true; o.noIgnore=true; break;
                    case "-s": case "--case-sensitive": o.caseSensitive=true; o.ignoreCase=false; break;
                    case "-i": case "--ignore-case": o.ignoreCase=true; o.caseSensitive=false; break;
                    case "-g": case "--glob": o.glob=true; o.regex=false; break;
                    case "--regex": o.glob=false; o.regex=true; break;
                    case "-F": case "--fixed-strings": o.fixed=true; break;
                    case "--and": { Val v=val(args,i,a,val); i=v.i; o.patterns.add(v.s); break; }
                    case "-a": case "--absolute-path": o.absolute=true; break;
                    case "--relative-path": o.absolute=false; break;
                    case "-l": case "--list-details": o.listDetails=true; break;
                    case "-L": case "--follow": o.follow=true; break;
                    case "--no-follow": o.follow=false; break;
                    case "-p": case "--full-path": o.fullPath=true; break;
                    case "-0": case "--print0": o.print0=true; break;
                    case "-q": case "--quiet": case "--has-results": o.quiet=true; break;
                    case "--show-errors": o.showErrors=true; break;
                    case "--prune": o.prune=true; break;
                    case "-1": o.maxResults=1; break;
                    case "-h": System.out.print(HELP_SHORT); return null;
                    case "--help": System.out.print(HELP_LONG); return null;
                    case "-V": case "--version": System.out.println("fd 10.3.0"); return null;
                    case "-d": case "--max-depth": { Val v=val(args,i,a,val); i=v.i; o.maxDepth = parseInt(v.s); break; }
                    case "--min-depth": { Val v=val(args,i,a,val); i=v.i; o.minDepth = parseInt(v.s); break; }
                    case "--exact-depth": { Val v=val(args,i,a,val); i=v.i; int d=parseInt(v.s); o.minDepth=d; o.maxDepth=d; break; }
                    case "-E": case "--exclude": { Val v=val(args,i,a,val); i=v.i; o.excludes.add(v.s); break; }
                    case "-e": case "--extension": { Val v=val(args,i,a,val); i=v.i; o.exts.add(stripDot(v.s).toLowerCase(Locale.ROOT)); break; }
                    case "-t": case "--type": { Val v=val(args,i,a,val); i=v.i; addType(o, v.s); break; }
                    case "-S": case "--size": { Val v=val(args,i,a,val); i=v.i; parseSize(o, v.s); break; }
                    case "--changed-within": case "--change-newer-than": case "--newer": case "--changed-after": { Val v=val(args,i,a,val); i=v.i; o.changedWithin=parseTime(v.s); break; }
                    case "--changed-before": case "--change-older-than": case "--older": { Val v=val(args,i,a,val); i=v.i; o.changedBefore=parseTime(v.s); break; }
                    case "--format": { Val v=val(args,i,a,val); i=v.i; o.format=v.s; break; }
                    case "--path-separator": { Val v=val(args,i,a,val); i=v.i; o.pathSep=v.s; break; }
                    case "-c": case "--color": { Val v=val(args,i,a,val); i=v.i; o.color=v.s; break; }
                    case "--hyperlink": o.hyperlink = val==null ? "auto" : val; break;
                    case "-j": case "--threads": { Val v=val(args,i,a,val); i=v.i; break; }
                    case "--max-results": { Val v=val(args,i,a,val); i=v.i; o.maxResults=parseInt(v.s); break; }
                    case "--batch-size": { Val v=val(args,i,a,val); i=v.i; o.batchSize=parseInt(v.s); break; }
                    case "-C": case "--base-directory": { Val v=val(args,i,a,val); i=v.i; o.baseDir=Paths.get(v.s).toAbsolutePath().normalize(); break; }
                    case "--search-path": { Val v=val(args,i,a,val); i=v.i; o.roots.add(Paths.get(v.s)); break; }
                    case "--ignore-file": { Val v=val(args,i,a,val); i=v.i; o.ignoreFiles.add(v.s); break; }
                    case "--ignore-contain": { Val v=val(args,i,a,val); i=v.i; o.ignoreContain.add(v.s); break; }
                    case "--strip-cwd-prefix": o.stripCwd = val==null ? "always" : val; if (val!=null) i--; break;
                    case "--no-ignore-vcs": case "--no-require-git": case "--require-git": case "--no-ignore-parent":
                    case "--one-file-system": case "--mount": case "--xdev": case "-o": case "--owner":
                        if (a.equals("-o") || a.equals("--owner")) { Val v=val(args,i,a,val); i=v.i; }
                        break;
                    case "-x": case "--exec": o.exec = rest(args, i+1); i=args.length; break;
                    case "-X": case "--exec-batch": o.execBatch = rest(args, i+1); i=args.length; break;
                    default:
                        if (a.startsWith("-t") && a.length()>2 && !a.startsWith("--")) {
                            addType(o, a.substring(2));
                        } else if (a.startsWith("-") && a.length()>2 && !a.startsWith("--")) {
                            for (int k=1;k<a.length();k++) parseShort(o, a.charAt(k));
                        } else throw new UsageException("error: unexpected argument '"+a+"' found\n\nFor more information, try '--help'.", 2);
                }
            } else {
                if (o.patterns.isEmpty()) o.patterns.add(a); else o.roots.add(Paths.get(a));
            }
        }
        if (o.patterns.isEmpty()) o.patterns.add("");
        return o;
    }

    static void parseShort(Opt o, char c) throws UsageException {
        switch(c) {
            case 'H': o.hidden=true; break; case 'I': o.noIgnore=true; break; case 'u': o.hidden=true; o.noIgnore=true; break;
            case 's': o.caseSensitive=true; o.ignoreCase=false; break; case 'i': o.ignoreCase=true; o.caseSensitive=false; break;
            case 'g': o.glob=true; o.regex=false; break; case 'F': o.fixed=true; break; case 'a': o.absolute=true; break;
            case 'l': o.listDetails=true; break; case 'L': o.follow=true; break; case 'p': o.fullPath=true; break; case '0': o.print0=true; break;
            case 'q': o.quiet=true; break; case '1': o.maxResults=1; break;
            default: throw new UsageException("error: unexpected argument '-"+c+"' found", 2);
        }
    }

    static void walk(Opt o, Path rootIn, List<Entry> out, List<Pattern> pats) {
        boolean rootAbs = rootIn.isAbsolute();
        Path root = o.baseDir.resolve(rootIn).normalize();
        List<IgnoreRule> custom = new ArrayList<>();
        if (!o.noIgnore) for (String f:o.ignoreFiles) custom.addAll(readIgnore(o.baseDir.resolve(f)));
        walkDir(o, root, root, 0, out, pats, custom, rootAbs);
    }

    static void walkDir(Opt o, Path dir, Path root, int depth, List<Entry> out, List<Pattern> pats, List<IgnoreRule> inherited, boolean rootAbs) {
        List<IgnoreRule> rules = new ArrayList<>(inherited);
        if (!o.noIgnore) {
            rules.addAll(readIgnore(dir.resolve(".ignore")));
            rules.addAll(readIgnore(dir.resolve(".fdignore")));
            rules.addAll(readIgnore(dir.resolve(".gitignore")));
        }
        List<Path> children = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p: ds) children.add(p);
        } catch (IOException e) { if (o.showErrors) System.err.println("[fd error]: " + e.getMessage()); return; }
        children.sort(Comparator.comparing(p -> p.getFileName().toString()));
        for (Path p: children) {
            String name = p.getFileName().toString();
            boolean symlink = Files.isSymbolicLink(p);
            BasicFileAttributes attrs;
            try { attrs = Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); }
            catch (IOException e) { if (o.showErrors) System.err.println("[fd error]: " + e.getMessage()); continue; }
            boolean isDir = attrs.isDirectory();
            int d = depth + 1;
            String rel = slash(root.relativize(p));
            if (!o.hidden && name.startsWith(".")) continue;
            if (!o.noIgnore && ignored(name, rel, isDir, rules)) continue;
            if (!o.ignoreContain.isEmpty() && isDir) {
                boolean contain=false; for(String n:o.ignoreContain) if(Files.exists(p.resolve(n))) contain=true;
                if (contain) continue;
            }
            if (excluded(o, name, rel, isDir)) continue;
            Entry e = new Entry(p, root, d, attrs, symlink, rootAbs);
            boolean matched = d >= o.minDepth && d <= o.maxDepth && matches(o, e, pats) && filters(o, e);
            if (matched) out.add(e);
            if (isDir && d < o.maxDepth && !(o.prune && matched)) walkDir(o, p, root, d, out, pats, rules, rootAbs);
            else if (symlink && o.follow && d < o.maxDepth) {
                try { if (Files.isDirectory(p)) walkDir(o, p, root, d, out, pats, rules, rootAbs); } catch (Exception ignored) {}
            }
        }
    }

    static boolean matches(Opt o, Entry e, List<Pattern> pats) {
        String text = o.fullPath ? slash(e.path.toAbsolutePath().normalize()) : e.path.getFileName().toString();
        for (Pattern p : pats) if (!p.matcher(text).find()) return false;
        return true;
    }

    static boolean filters(Opt o, Entry e) {
        if (!o.types.isEmpty()) {
            boolean hasX = o.types.contains('x'), hasE = o.types.contains('e');
            if (hasX && !(e.attrs.isRegularFile() && Files.isExecutable(e.path))) return false;
            if (hasE && !isEmpty(e)) return false;
            Set<Character> ordinary = new HashSet<>(o.types);
            ordinary.remove('x'); ordinary.remove('e');
            if (!ordinary.isEmpty()) {
                boolean ok=false;
                for (char t:ordinary) ok |= typeMatch(t,e);
                if (!ok) return false;
            } else if (hasX && !e.attrs.isRegularFile()) {
                return false;
            } else if (hasE && !(e.attrs.isRegularFile() || e.attrs.isDirectory())) {
                return false;
            }
        }
        if (!o.exts.isEmpty()) {
            String n=e.path.getFileName().toString(), ext="";
            int idx=n.lastIndexOf('.');
            if (idx>=0 && idx<n.length()-1) ext=n.substring(idx+1).toLowerCase(Locale.ROOT);
            if (!o.exts.contains(ext)) return false;
        }
        if (o.size != null) {
            if (!e.attrs.isRegularFile()) return false;
            long s=e.attrs.size();
            if (o.sizeCmp=='+' && s < o.size) return false;
            if (o.sizeCmp=='-' && s > o.size) return false;
            if (o.sizeCmp=='=' && s != o.size) return false;
        }
        Instant mod=e.attrs.lastModifiedTime().toInstant();
        if (o.changedWithin != null && !mod.isAfter(o.changedWithin)) return false;
        if (o.changedBefore != null && !mod.isBefore(o.changedBefore)) return false;
        return true;
    }

    static boolean typeMatch(char t, Entry e) {
        return switch(t) {
            case 'f' -> e.attrs.isRegularFile();
            case 'd' -> e.attrs.isDirectory();
            case 'l' -> e.isSymlink;
            case 'x' -> e.attrs.isRegularFile() && Files.isExecutable(e.path);
            case 'e' -> isEmpty(e);
            case 's','p','b','c' -> false;
            default -> false;
        };
    }

    static boolean isEmpty(Entry e) {
        try {
            if (e.attrs.isDirectory()) { try (DirectoryStream<Path> ds=Files.newDirectoryStream(e.path)) { return !ds.iterator().hasNext(); } }
            return e.attrs.isRegularFile() && e.attrs.size()==0;
        } catch(IOException ex) { return false; }
    }

    static List<Pattern> compilePatterns(Opt o) throws UsageException {
        boolean ci = o.ignoreCase || (!o.caseSensitive && o.patterns.stream().noneMatch(Fd::hasUpper));
        int flags = ci ? Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE : 0;
        List<Pattern> res = new ArrayList<>();
        for (String pat:o.patterns) {
            try {
                if (o.fixed) res.add(Pattern.compile(Pattern.quote(pat), flags));
                else if (o.glob) res.add(Pattern.compile(globRegex(pat), flags));
                else res.add(Pattern.compile(pat, flags));
            } catch (PatternSyntaxException e) {
                throw new UsageException("[fd error]: regex parse error:\n    "+pat+"\nerror: "+e.getDescription()+"\n\nNote: You can use the '--fixed-strings' option to search for a literal string instead of a regular expression. Alternatively, you can also use the '--glob' option to match on a glob pattern.",1);
            }
        }
        return res;
    }

    static String outputPath(Opt o, Entry e, boolean forExec) {
        String s;
        if (o.absolute) s = slash(e.path.toAbsolutePath().normalize());
        else if (e.rootAbsolute) s = slash(e.path.toAbsolutePath().normalize());
        else {
            Path rel = e.root.toAbsolutePath().normalize().relativize(e.path.toAbsolutePath().normalize());
            s = slash(rel);
            if (forExec || o.print0) {
                boolean strip = o.stripCwd.equals("always");
                boolean add = o.stripCwd.equals("never") || o.stripCwd.equals("auto");
                if (add && !s.startsWith("./") && !s.startsWith("../") && !s.startsWith("/")) s = "./" + s;
                if (strip && s.startsWith("./")) s = s.substring(2);
            }
        }
        if (e.attrs.isDirectory() && !s.endsWith("/")) s += "/";
        if (!o.pathSep.equals("/")) s = s.replace("/", o.pathSep);
        return s;
    }

    static void printEntry(Opt o, Entry e) {
        String s = o.format != null ? format(o.format, o, e) : outputPath(o,e,false);
        System.out.print(s);
        System.out.print(o.print0 ? "\0" : "\n");
    }

    static String format(String fmt, Opt o, Entry e) {
        String path=outputPath(o,e,false), base=e.path.getFileName().toString();
        if (e.attrs.isDirectory() && base.endsWith("/")) base=base.substring(0,base.length()-1);
        String parent=slash(e.root.relativize(e.path.getParent()==null?e.root:e.path.getParent()));
        String noext=noExt(path), baseno=noExt(base);
        return fmt.replace("{{","{").replace("}}","}")
                .replace("{//}", parent.isEmpty()?".":parent).replace("{/.}", baseno)
                .replace("{}", path).replace("{/}", base).replace("{.}", noext);
    }

    static List<String> commandForEntry(List<String> tmpl, Entry e, Opt o) {
        boolean has=false; List<String> r=new ArrayList<>();
        for(String a:tmpl){ if(a.contains("{")) has=true; r.add(repl(a,e,o)); }
        if(!has) r.add(outputPath(o,e,true));
        return r;
    }
    static List<String> commandWithDefault(List<String> cmd, List<Entry> entries, Opt o) {
        List<String> r=new ArrayList<>(); boolean has=false;
        for(String a:cmd){ if(a.contains("{")) has=true; r.add(a); }
        if(!has) { for(Entry e:entries) r.add(outputPath(o,e,true)); return r; }
        List<String> out=new ArrayList<>();
        for(String a:r) {
            if(a.equals("{}")) for(Entry e:entries) out.add(outputPath(o,e,true));
            else out.add(a);
        }
        return out;
    }
    static String repl(String a, Entry e, Opt o) {
        String path=outputPath(o,e,true), base=e.path.getFileName().toString();
        String parent=slash(e.path.getParent()==null?Paths.get("."):o.baseDir.relativize(e.path.getParent().toAbsolutePath().normalize()));
        return a.replace("{{","{").replace("}}","}").replace("{//}", parent).replace("{/.}", noExt(base)).replace("{}", path).replace("{/}", base).replace("{.}", noExt(path));
    }
    static int runBatch(List<String> cmd, List<Entry> entries, Opt o) {
        if (entries.isEmpty() && !o.listDetails) return 0;
        return runOne(cmd, o.baseDir);
    }
    static int runOne(List<String> cmd, Path cwd) {
        try {
            Process p=new ProcessBuilder(cmd).directory(cwd.toFile()).inheritIO().start();
            return p.waitFor();
        } catch(Exception e) { System.err.println("[fd error]: "+e.getMessage()); return 1; }
    }

    static class IgnoreRule { String pat; boolean neg, dirOnly; IgnoreRule(String p, boolean n, boolean d){pat=p;neg=n;dirOnly=d;} }
    static List<IgnoreRule> readIgnore(Path f) {
        List<IgnoreRule> r=new ArrayList<>();
        if(!Files.isRegularFile(f)) return r;
        try(BufferedReader br=Files.newBufferedReader(f)) {
            String line; while((line=br.readLine())!=null) {
                line=line.trim(); if(line.isEmpty()||line.startsWith("#")) continue;
                boolean neg=line.startsWith("!"); if(neg) line=line.substring(1);
                boolean dir=line.endsWith("/"); if(dir) line=line.substring(0,line.length()-1);
                r.add(new IgnoreRule(line,neg,dir));
            }
        } catch(IOException ignored) {}
        return r;
    }
    static boolean ignored(String name, String rel, boolean dir, List<IgnoreRule> rules) {
        boolean ign=false;
        for(IgnoreRule r: rules) {
            if(r.dirOnly && !dir) continue;
            if(globMatch(r.pat, name) || globMatch(r.pat, rel) || (!r.pat.contains("/") && rel.endsWith("/"+r.pat))) ign=!r.neg;
        }
        return ign;
    }
    static boolean excluded(Opt o, String name, String rel, boolean dir) {
        for(String p:o.excludes) if(globMatch(p,name)||globMatch(p,rel)|| (dir && globMatch(p, name+"/"))) return true;
        return false;
    }
    static boolean globMatch(String pat, String text) {
        return Pattern.compile(globRegex(pat)).matcher(text).matches();
    }
    static String globRegex(String g) {
        StringBuilder sb=new StringBuilder("^");
        for(int i=0;i<g.length();i++){
            char c=g.charAt(i);
            if(c=='*') { if(i+1<g.length()&&g.charAt(i+1)=='*'){ sb.append(".*"); i++; } else sb.append("[^/]*"); }
            else if(c=='?') sb.append("[^/]");
            else if(c=='[') { int j=g.indexOf(']',i+1); if(j>i){ sb.append(g, i, j+1); i=j; } else sb.append("\\["); }
            else { if("\\.^$+{}()|".indexOf(c)>=0) sb.append('\\'); sb.append(c); }
        }
        return sb.append("$").toString();
    }

    static class Val { String s; int i; Val(String s,int i){this.s=s;this.i=i;} }
    static Val val(String[] args, int i, String opt, String inline) throws UsageException {
        if (inline != null) return new Val(inline, i);
        int j = i + 1;
        if (j >= args.length) throw new UsageException("error: a value is required for '"+opt+"'",2);
        return new Val(args[j], j);
    }
    static List<String> rest(String[] args, int from){ return new ArrayList<>(Arrays.asList(args).subList(from,args.length)); }
    static int parseInt(String s){ return Integer.parseInt(s); }
    static String stripDot(String s){ return s.startsWith(".")?s.substring(1):s; }
    static boolean hasUpper(String s){ for(char c:s.toCharArray()) if(Character.isUpperCase(c)) return true; return false; }
    static String slash(Path p){ return slash(p.toString()); }
    static String slash(String s){ return s.replace('\\','/'); }
    static String noExt(String s){ int slash=s.lastIndexOf('/'), dot=s.lastIndexOf('.'); return dot>slash?s.substring(0,dot):s; }

    static void addType(Opt o, String t) {
        switch(t) {
            case "f": case "file": o.types.add('f'); break; case "d": case "dir": case "directory": o.types.add('d'); break;
            case "l": case "symlink": o.types.add('l'); break; case "x": case "executable": o.types.add('x'); break;
            case "e": case "empty": o.types.add('e'); break; case "s": case "socket": o.types.add('s'); break; case "p": case "pipe": o.types.add('p'); break;
            case "b": case "block-device": o.types.add('b'); break; case "c": case "char-device": o.types.add('c'); break;
        }
    }
    static void parseSize(Opt o, String s) {
        if(s.startsWith("+")||s.startsWith("-")) { o.sizeCmp=s.charAt(0); s=s.substring(1); }
        int i=0; while(i<s.length()&&Character.isDigit(s.charAt(i))) i++;
        long n=Long.parseLong(s.substring(0,i)); String u=s.substring(i).toLowerCase(Locale.ROOT);
        long mul=switch(u){case "k"->1000L; case "m"->1000_000L; case "g"->1000_000_000L; case "t"->1000_000_000_000L; case "ki"->1024L; case "mi"->1024L*1024; case "gi"->1024L*1024*1024; case "ti"->1024L*1024*1024*1024; default->1L;};
        o.size=n*mul;
    }
    static Instant parseTime(String s) {
        if(s.startsWith("@")) return Instant.ofEpochSecond(Long.parseLong(s.substring(1)));
        Instant dur = parseDuration(s); if(dur!=null) return dur;
        try { return LocalDate.parse(s).atStartOfDay(ZoneId.systemDefault()).toInstant(); } catch(DateTimeParseException ignored) {}
        try { return LocalDateTime.parse(s, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).atZone(ZoneId.systemDefault()).toInstant(); } catch(DateTimeParseException ignored) {}
        return Instant.EPOCH;
    }
    static Instant parseDuration(String s) {
        String x=s.toLowerCase(Locale.ROOT); int i=0; while(i<x.length()&&Character.isDigit(x.charAt(i))) i++;
        if(i==0) return null; long n=Long.parseLong(x.substring(0,i)); String u=x.substring(i);
        Duration d=switch(u){case "s","sec","secs","second","seconds"->Duration.ofSeconds(n); case "m","min","mins","minute","minutes"->Duration.ofMinutes(n); case "h","hr","hrs","hour","hours"->Duration.ofHours(n); case "d","day","days"->Duration.ofDays(n); case "w","week","weeks"->Duration.ofDays(n*7); default->null;};
        return d==null?null:Instant.now().minus(d);
    }
    static class UsageException extends Exception { int code; UsageException(String m,int c){super(m);code=c;} }
}
