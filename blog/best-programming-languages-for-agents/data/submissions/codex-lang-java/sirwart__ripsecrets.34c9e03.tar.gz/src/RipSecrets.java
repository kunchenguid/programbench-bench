import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class RipSecrets {
    private static final String VERSION = "ripsecrets 0.1.11";

    private static final class SecretPattern {
        final Pattern pattern;
        final int group;
        final boolean entropyCheck;

        SecretPattern(String regex, int group, boolean entropyCheck) {
            this.pattern = Pattern.compile(regex);
            this.group = group;
            this.entropyCheck = entropyCheck;
        }
    }

    private static final class IgnoreRules {
        final List<String> paths = new ArrayList<>();
        final Set<String> secrets = new HashSet<>();
    }

    public static void main(String[] args) {
        boolean onlyMatching = false;
        boolean strictIgnore = false;
        boolean install = false;
        List<String> sources = new ArrayList<>();
        List<String> additional = new ArrayList<>();

        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h":
                case "--help":
                    printHelp();
                    return;
                case "-V":
                case "--version":
                    System.out.println(VERSION);
                    return;
                case "--only-matching":
                    onlyMatching = true;
                    break;
                case "--strict-ignore":
                    strictIgnore = true;
                    break;
                case "--install-pre-commit":
                    install = true;
                    break;
                case "--additional-pattern":
                    if (i + 1 < args.length) {
                        additional.add(args[++i]);
                    }
                    break;
                default:
                    if (a.startsWith("--additional-pattern=")) {
                        additional.add(a.substring(a.indexOf('=') + 1));
                    } else {
                        sources.add(a);
                    }
            }
        }

        if (install) {
            installHook();
            return;
        }

        boolean userProvidedSources = !sources.isEmpty();
        if (sources.isEmpty()) {
            sources.add(".");
        }

        List<SecretPattern> patterns = builtins();
        for (String s : additional) {
            try {
                Pattern p = Pattern.compile(s);
                patterns.add(new SecretPattern(s, p.matcher("").groupCount() >= 1 ? 1 : 0, true));
            } catch (Exception ignored) {
            }
        }

        IgnoreRules ignore = loadIgnore(Paths.get(".secretsignore"));
        boolean found = false;
        for (String source : sources) {
            Path p = Paths.get(source);
            if (!Files.exists(p)) {
                System.out.println(source + ": No such file or directory (os error 2)");
                continue;
            }
            boolean explicit = userProvidedSources && !source.equals(".");
            try {
                if (Files.isDirectory(p)) {
                    final Path root = p;
                    final boolean[] any = new boolean[] {false};
                    final boolean bypass = explicit && !strictIgnore;
                    final boolean om = onlyMatching;
                    Files.walkFileTree(p, new SimpleFileVisitor<Path>() {
                        @Override
                        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                            if (!dir.equals(root) && ignored(dir, ignore, bypass)) {
                                return FileVisitResult.SKIP_SUBTREE;
                            }
                            return FileVisitResult.CONTINUE;
                        }

                        @Override
                        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                            if (!ignored(file, ignore, bypass)) {
                                any[0] |= scanFile(file, patterns, ignore.secrets, om);
                            }
                            return FileVisitResult.CONTINUE;
                        }
                    });
                    found |= any[0];
                } else if (!ignored(p, ignore, explicit && !strictIgnore)) {
                    found |= scanFile(p, patterns, ignore.secrets, onlyMatching);
                }
            } catch (IOException e) {
                System.out.println(source + ": " + e.getMessage());
            }
        }
        if (found) {
            System.exit(1);
        }
    }

    private static List<SecretPattern> builtins() {
        List<SecretPattern> ps = new ArrayList<>();
        ps.add(new SecretPattern("(?i)(aws_access_key_id|aws_access_key|access_key_id)[^A-Z0-9]{0,20}((?:AKIA|ASIA)[A-Z0-9]{16})", 2, false));
        ps.add(new SecretPattern("(?i)(aws_secret_access_key|aws_secret_key|secret_access_key)[^A-Za-z0-9+/]{0,20}([A-Za-z0-9/+=]{32,})", 2, true));
        ps.add(new SecretPattern("(?i)(api[_-]?key|token)[\\w\\s\"'`.-]{0,30}[:=][\\s\"'`]*([A-Za-z0-9_./+=-]{20,})", 2, true));
        ps.add(new SecretPattern("(-----BEGIN [A-Z ]*PRIVATE KEY-----)", 1, false));
        ps.add(new SecretPattern("\\b((?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,})\\b", 1, false));
        ps.add(new SecretPattern("\\b(github_pat_[A-Za-z0-9_]{22,})\\b", 1, false));
        ps.add(new SecretPattern("\\b((?:xox[baprs]|xapp)-[A-Za-z0-9-]{20,})\\b", 1, false));
        ps.add(new SecretPattern("\\b(sk_live_[A-Za-z0-9]{20,})\\b", 1, false));
        ps.add(new SecretPattern("\\b(eyJ[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,}\\.[A-Za-z0-9_-]{10,})\\b", 1, false));
        return ps;
    }

    private static boolean scanFile(Path file, List<SecretPattern> patterns, Set<String> ignoredSecrets, boolean onlyMatching) {
        boolean found = false;
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            int n = 0;
            while ((line = br.readLine()) != null) {
                n++;
                boolean lineMatched = false;
                Set<String> emitted = new HashSet<>();
                for (SecretPattern sp : patterns) {
                    Matcher m = sp.pattern.matcher(line);
                    while (m.find()) {
                        String match = safeGroup(m, sp.group);
                        if (match == null || match.isEmpty()) {
                            continue;
                        }
                        String cleaned = trimQuotes(match);
                        if (ignoredSecrets.contains(cleaned) || ignoredSecrets.contains(match)) {
                            continue;
                        }
                        if (sp.entropyCheck && !looksRandom(cleaned)) {
                            continue;
                        }
                        if (!emitted.add(cleaned)) {
                            continue;
                        }
                        System.out.println(display(file) + ":" + n + ":" + (onlyMatching ? cleaned : line));
                        found = true;
                        lineMatched = true;
                        break;
                    }
                    if (lineMatched && !onlyMatching) {
                        break;
                    }
                }
            }
        } catch (CharacterCodingException ignored) {
        } catch (IOException ignored) {
        }
        return found;
    }

    private static String safeGroup(Matcher m, int g) {
        try {
            return m.group(g);
        } catch (Exception e) {
            return m.group();
        }
    }

    private static String trimQuotes(String s) {
        String r = s;
        while (!r.isEmpty() && "\"'` ".indexOf(r.charAt(0)) >= 0) r = r.substring(1);
        while (!r.isEmpty() && "\"'`,; ".indexOf(r.charAt(r.length() - 1)) >= 0) r = r.substring(0, r.length() - 1);
        return r;
    }

    private static boolean looksRandom(String s) {
        if (s.length() < 16) return false;
        long classes = 0;
        if (s.matches(".*[a-z].*")) classes++;
        if (s.matches(".*[A-Z].*")) classes++;
        if (s.matches(".*[0-9].*")) classes++;
        if (s.matches(".*[^A-Za-z0-9].*")) classes++;
        if (classes < 2) return false;
        return entropy(s) >= 3.0;
    }

    private static double entropy(String s) {
        int[] counts = new int[256];
        for (char c : s.toCharArray()) {
            counts[c & 255]++;
        }
        double e = 0.0;
        for (int c : counts) {
            if (c == 0) continue;
            double p = (double) c / s.length();
            e -= p * (Math.log(p) / Math.log(2));
        }
        return e;
    }

    private static IgnoreRules loadIgnore(Path path) {
        IgnoreRules rules = new IgnoreRules();
        if (!Files.exists(path)) return rules;
        boolean secrets = false;
        try {
            for (String raw : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                String line = raw.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                if (line.equalsIgnoreCase("[secrets]")) {
                    secrets = true;
                    continue;
                }
                if (line.startsWith("[")) {
                    secrets = false;
                    continue;
                }
                if (secrets) rules.secrets.add(line);
                else rules.paths.add(line);
            }
        } catch (IOException ignored) {
        }
        return rules;
    }

    private static boolean ignored(Path p, IgnoreRules rules, boolean bypassExplicit) {
        if (bypassExplicit) return false;
        String rel = display(p);
        if (rel.startsWith("./")) rel = rel.substring(2);
        String name = p.getFileName() == null ? rel : p.getFileName().toString();
        for (String pat : rules.paths) {
            boolean dirPat = pat.endsWith("/");
            String q = dirPat ? pat.substring(0, pat.length() - 1) : pat;
            if (q.startsWith("./")) q = q.substring(2);
            if (rel.equals(q) || name.equals(q) || rel.startsWith(q + "/") || rel.contains("/" + q + "/")) {
                return true;
            }
            if (q.contains("*")) {
                String rx = q.replace(".", "\\.").replace("*", ".*");
                if (rel.matches(rx) || name.matches(rx)) return true;
            }
        }
        return false;
    }

    private static String display(Path p) {
        String s = p.toString();
        return s.replace('\\', '/');
    }

    private static void installHook() {
        try {
            Path hook = Paths.get(".git", "hooks", "pre-commit");
            Files.createDirectories(hook.getParent());
            Files.writeString(hook, "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n", StandardCharsets.UTF_8);
            hook.toFile().setExecutable(true, true);
        } catch (IOException ignored) {
        }
    }

    private static void printHelp() {
        System.out.println("ripsecrets searches files and directories recursively for secret API keys.");
        System.out.println("It's primarily designed to be used as a pre-commit to prevent committing");
        System.out.println("secrets into version control.");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [Source files]...");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [Source files]...");
        System.out.println("          Source files. Can be files or directories. Defaults to '.'");
        System.out.println();
        System.out.println("Options:");
        System.out.println("      --install-pre-commit");
        System.out.println("          Install `ripsecrets` as a pre-commit hook automatically in git directory provided");
        System.out.println();
        System.out.println("      --strict-ignore");
        System.out.println("          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit");
        System.out.println();
        System.out.println("      --only-matching");
        System.out.println("          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line");
        System.out.println();
        System.out.println("      --additional-pattern <ADDITIONAL_PATTERNS>");
        System.out.println("          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret");
        System.out.println();
        System.out.println("  -h, --help");
        System.out.println("          Print help (see a summary with '-h')");
        System.out.println();
        System.out.println("  -V, --version");
        System.out.println("          Print version");
    }
}
