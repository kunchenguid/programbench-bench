import java.io.*;
import java.net.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.regex.*;
import java.util.Base64;

public class Monolith {
    static final String VERSION = "monolith 2.11.0";
    static final String BANNER =
" _____    _____________   __________     ___________________    ___\n"+
"|     \\  /             \\ |          |   |                   |  |   |\n"+
"|      \\/       __      \\|    __    |   |    ___     ___    |__|   |\n"+
"|              |  |          |  |   |   |   |   |   |   |          |\n"+
"|   |\\    /|   |__|          |__|   |___|   |   |   |   |    __    |\n"+
"|   | \\__/ |          |\\                    |   |   |   |   |  |   |\n"+
"|___|      |__________| \\___________________|   |___|   |___|  |___|\n";

    static class Opt {
        boolean noAudio, blacklist, noCss, ignoreErrors, noFrames, noFonts, noImages;
        boolean isolate, noJs, insecure, mhtml, noMetadata, unwrapNoscript, quiet, noVideo;
        String baseUrl, cookieFile, encoding, output, timeout, userAgent, target;
        List<String> domains = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o == null) return;
            process(o);
        } catch (CliException e) {
            System.err.print(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(); return null;
                case "-V": case "--version": System.out.println(VERSION); return null;
                case "-a": case "--no-audio": o.noAudio = true; break;
                case "-B": case "--blacklist-domains": o.blacklist = true; break;
                case "-c": case "--no-css": o.noCss = true; break;
                case "-e": case "--ignore-errors": o.ignoreErrors = true; break;
                case "-f": case "--no-frames": o.noFrames = true; break;
                case "-F": case "--no-fonts": o.noFonts = true; break;
                case "-i": case "--no-images": o.noImages = true; break;
                case "-I": case "--isolate": o.isolate = true; break;
                case "-j": case "--no-js": o.noJs = true; break;
                case "-k": case "--insecure": o.insecure = true; break;
                case "-m": case "--mhtml": o.mhtml = true; break;
                case "-M": case "--no-metadata": o.noMetadata = true; break;
                case "-n": case "--unwrap-noscript": o.unwrapNoscript = true; break;
                case "-q": case "--quiet": o.quiet = true; break;
                case "-v": case "--no-video": o.noVideo = true; break;
                case "-b": case "--base-url": o.baseUrl = value(args, ++i, a); break;
                case "-C": case "--cookie-file": o.cookieFile = value(args, ++i, a); break;
                case "-d": case "--domain": o.domains.add(value(args, ++i, a)); break;
                case "-E": case "--encoding": o.encoding = value(args, ++i, a); break;
                case "-o": case "--output": o.output = value(args, ++i, a); break;
                case "-t": case "--timeout": o.timeout = value(args, ++i, a); break;
                case "-u": case "--user-agent": o.userAgent = value(args, ++i, a); break;
                default:
                    if (a.startsWith("-") && !a.equals("-")) throw new CliException("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.\n");
                    if (o.target != null) throw new CliException("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.\n");
                    o.target = a;
            }
        }
        if (o.target == null) throw new CliException("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.\n");
        return o;
    }

    static String value(String[] args, int idx, String opt) {
        if (idx >= args.length) throw new CliException("error: a value is required for '" + opt + "' but none was supplied\n");
        return args[idx];
    }

    static void process(Opt o) throws Exception {
        Context ctx = readTarget(o);
        String html = ctx.html;
        if (o.encoding != null) html = addCharset(html, o.encoding);
        html = transform(html, o, ctx);
        if (!o.noMetadata) html = addMetadata(html, ctx);
        if (o.mhtml) html = toMhtml(html);
        String out = resolveOutput(o.output, html);
        if (out == null || out.equals("-")) System.out.print(html);
        else Files.writeString(Paths.get(out), html, StandardCharsets.UTF_8);
    }

    static class Context { String html; URI base; boolean stdin; Path fileBase; }

    static Context readTarget(Opt o) throws Exception {
        Context c = new Context();
        c.stdin = "-".equals(o.target);
        if (c.stdin) {
            c.html = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
            c.base = o.baseUrl != null ? makeUri(o.baseUrl) : URI.create("http://example.com/");
        } else if (looksRemote(o.target)) {
            c.base = makeUri(o.target);
            c.html = fetch(c.base, o, null, false);
        } else {
            Path p = Paths.get(o.target).toAbsolutePath().normalize();
            c.fileBase = p.getParent();
            c.base = p.toUri();
            c.html = Files.readString(p, StandardCharsets.UTF_8);
            if (!o.quiet) System.err.println(c.base);
        }
        if (o.baseUrl != null) c.base = makeUri(o.baseUrl);
        return c;
    }

    static String transform(String html, Opt o, Context ctx) {
        if (o.unwrapNoscript) {
            html = Pattern.compile("(?is)<noscript\\b[^>]*>(.*?)</noscript>").matcher(html).replaceAll("<!--noscript-->$1<!--/noscript-->");
        }
        List<String> csp = new ArrayList<>();
        if (o.noImages) csp.add("img-src data:;");
        if (o.noCss) csp.add("style-src 'none';");
        if (o.noJs || o.mhtml) csp.add("script-src 'none';");
        if (o.noFonts) csp.add("font-src 'none';");
        if (o.noFrames) { csp.add("frame-src 'none';"); csp.add("child-src 'none';"); }
        if (o.isolate) csp.add("default-src 'unsafe-eval' 'unsafe-inline' data:;");
        if (!csp.isEmpty()) html = insertIntoHead(html, "<meta http-equiv=\"Content-Security-Policy\" content=\"" + String.join(" ", csp) + "\"></meta>");

        if (o.noCss) {
            html = attr(html, "link", "href", (tag, val) -> isStylesheet(tag) ? null : val);
            html = Pattern.compile("(?is)<style\\b([^>]*)>.*?</style>").matcher(html).replaceAll("<style$1></style>");
        } else {
            html = attr(html, "link", "href", (tag, val) -> isStylesheet(tag) ? embedTextUrl(val, "text/css", o, ctx, true) : val);
            html = rewriteStyleBlocks(html, o, ctx);
        }
        if (o.noFonts) html = Pattern.compile("(?is)@font-face\\s*\\{.*?\\}").matcher(html).replaceAll("");

        if (o.noJs || o.mhtml) html = Pattern.compile("(?is)<script\\b[^>]*>.*?</script>").matcher(html).replaceAll("<script></script>");
        else html = scriptSrc(html, o, ctx);

        html = media(html, "img", "src", o.noImages, blankPng(), "image/png", o, ctx);
        html = media(html, "audio", "src", o.noAudio, null, "", o, ctx);
        html = media(html, "video", "src", o.noVideo, null, "", o, ctx);
        html = media(html, "source", "src", o.noAudio || o.noVideo, null, "", o, ctx);
        html = media(html, "iframe", "src", o.noFrames, "", "", o, ctx);
        html = media(html, "frame", "src", o.noFrames, "", "", o, ctx);

        html = attr(html, "a", "href", (tag, val) -> resolveNonAsset(val, o, ctx));
        if (o.isolate && !Pattern.compile("(?is)<base\\b").matcher(html).find()) {
            html = insertIntoHead(html, "<base href=\"" + escape(ctx.base.toString()) + "\"></base>");
        }
        html = insertIntoHead(html, "<meta name=\"robots\" content=\"none\"></meta>");
        if (!html.endsWith("\n")) html += "\n";
        return html;
    }

    interface AttrFn { String apply(String tag, String val); }

    static String attr(String html, String tagName, String attrName, AttrFn fn) {
        Pattern p = Pattern.compile("(?is)<" + tagName + "\\b[^>]*>");
        Matcher m = p.matcher(html);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String tag = m.group();
            String nt = replaceAttr(tag, attrName, fn);
            m.appendReplacement(sb, Matcher.quoteReplacement(nt));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String replaceAttr(String tag, String attr, AttrFn fn) {
        Pattern p = Pattern.compile("(?is)\\s+\\b" + attr + "\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
        Matcher m = p.matcher(tag);
        if (!m.find()) return tag;
        String val = first(m.group(2), m.group(3), m.group(4));
        String nv = fn.apply(tag, val);
        if (nv == null) return m.replaceFirst("");
        return m.replaceFirst(" " + attr + "=\"" + Matcher.quoteReplacement(escape(nv)) + "\"");
    }

    static String media(String html, String tag, String attr, boolean remove, String repl, String mime, Opt o, Context ctx) {
        return attr(html, tag, attr, (t, v) -> {
            if (remove) return repl;
            if (o.isolate) return uriText(resolve(ctx.base, v));
            if (tag.equals("iframe") || tag.equals("frame")) {
                String content = fetchAsset(v, "text/html", o, ctx, false);
                if (content == null) content = Base64.getEncoder().encodeToString("<html><head></head><body></body></html>".getBytes(StandardCharsets.UTF_8));
                return "data:text/plain;base64," + content;
            }
            return embedBinaryUrl(v, mimeFor(v, mime), o, ctx);
        });
    }

    static String scriptSrc(String html, Opt o, Context ctx) {
        Pattern p = Pattern.compile("(?is)<script\\b([^>]*)\\bsrc\\s*=\\s*(\"([^\"]*)\"|'([^']*)'|([^\\s>]+))([^>]*)>\\s*</script>");
        Matcher m = p.matcher(html);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String val = first(m.group(3), m.group(4), m.group(5));
            String js = o.isolate ? null : fetchText(val, o, ctx, false);
            String repl = js == null ? "<script></script>" : "<script>" + js + "</script>";
            m.appendReplacement(sb, Matcher.quoteReplacement(repl));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String rewriteStyleBlocks(String html, Opt o, Context ctx) {
        Pattern p = Pattern.compile("(?is)<style\\b([^>]*)>(.*?)</style>");
        Matcher m = p.matcher(html);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String css = rewriteCssUrls(m.group(2), o, ctx);
            m.appendReplacement(sb, Matcher.quoteReplacement("<style" + m.group(1) + ">" + css + "</style>"));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String rewriteCssUrls(String css, Opt o, Context ctx) {
        Pattern p = Pattern.compile("(?is)url\\((['\"]?)(.*?)\\1\\)");
        Matcher m = p.matcher(css);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String u = m.group(2).trim();
            String r = o.isolate ? resolve(ctx.base, u).toString() : embedBinaryUrl(u, mimeFor(u, "text/plain"), o, ctx);
            m.appendReplacement(sb, Matcher.quoteReplacement("url(\"" + r + "\")"));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String embedTextUrl(String url, String mime, Opt o, Context ctx, boolean rewriteCss) {
        if (o.isolate) return uriText(resolve(ctx.base, url));
        String text = fetchText(url, o, ctx, false);
        if (text == null) return "data:text/plain;base64,";
        if (rewriteCss) text = rewriteCssUrls(text, o, ctx);
        return "data:" + mime + ";base64," + Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    static String embedBinaryUrl(String url, String mime, Opt o, Context ctx) {
        if (o.isolate) return uriText(resolve(ctx.base, url));
        byte[] b = fetchBytes(url, o, ctx, false);
        if (b == null) return "data:text/plain;base64,";
        return "data:" + mime + ";base64," + Base64.getEncoder().encodeToString(b);
    }

    static String fetchAsset(String url, String mime, Opt o, Context ctx, boolean text) {
        byte[] b = fetchBytes(url, o, ctx, text);
        return b == null ? null : Base64.getEncoder().encodeToString(b);
    }

    static String fetchText(String url, Opt o, Context ctx, boolean required) {
        byte[] b = fetchBytes(url, o, ctx, required);
        return b == null ? null : new String(b, StandardCharsets.UTF_8);
    }

    static byte[] fetchBytes(String url, Opt o, Context ctx, boolean required) {
        try {
            URI u = resolve(ctx.base, url);
            if (u.getScheme() == null || u.getScheme().equals("file")) {
                Path p = u.getScheme() == null ? ctx.fileBase.resolve(url) : Paths.get(u);
                byte[] data = Files.readAllBytes(p);
                if (!o.quiet) System.err.println(uriText(p.toUri()));
                return data;
            }
            if (looksRemote(u.toString())) {
                if (!o.quiet && !ctx.stdin) System.err.println(u + " (error sending request for url (" + u + "))");
                return null;
            }
        } catch (Exception e) {
            try { if (!o.quiet) System.err.println(uriText(resolve(ctx.base, url)) + " (" + (e instanceof NoSuchFileException ? "file not found" : e.getMessage()) + ")"); } catch (Exception ignored) {}
        }
        return null;
    }

    static String fetch(URI uri, Opt o, String mime, boolean text) throws IOException {
        if (uri.getScheme() != null && uri.getScheme().equals("file")) return Files.readString(Paths.get(uri), StandardCharsets.UTF_8);
        throw new IOException(uri + " (error sending request for url (" + uri + "))");
    }

    static String resolveNonAsset(String val, Opt o, Context ctx) {
        if (o.isolate || !ctx.stdin) return uriText(resolve(ctx.base, val));
        return "data:,";
    }

    static String uriText(URI uri) {
        if (uri != null && "file".equals(uri.getScheme())) return "file://" + uri.getPath();
        return uri == null ? "" : uri.toString();
    }

    static URI resolve(URI base, String val) {
        if (val == null || val.isEmpty() || val.startsWith("data:") || val.startsWith("#")) return URI.create(val == null ? "" : val);
        return base.resolve(val);
    }

    static URI makeUri(String s) {
        if (looksRemote(s) || s.startsWith("file:")) return URI.create(s);
        return Paths.get(s).toAbsolutePath().normalize().toUri();
    }

    static boolean looksRemote(String s) { return s.startsWith("http://") || s.startsWith("https://"); }
    static boolean isStylesheet(String tag) { return tag.toLowerCase(Locale.ROOT).contains("rel=\"stylesheet\"") || tag.toLowerCase(Locale.ROOT).contains("rel='stylesheet'") || tag.toLowerCase(Locale.ROOT).contains("rel=stylesheet"); }

    static String insertIntoHead(String html, String frag) {
        if (html.toLowerCase(Locale.ROOT).contains(frag.toLowerCase(Locale.ROOT))) return html;
        Matcher m = Pattern.compile("(?is)<head[^>]*>").matcher(html);
        if (m.find()) return html.substring(0, m.end()) + frag + html.substring(m.end());
        Matcher h = Pattern.compile("(?is)<html[^>]*>").matcher(html);
        if (h.find()) return html.substring(0, h.end()) + "<head>" + frag + "</head>" + html.substring(h.end());
        return frag + html;
    }

    static String addCharset(String html, String enc) {
        return insertIntoHead(html, "<meta charset=\"" + escape(enc) + "\"></meta>");
    }

    static String addMetadata(String html, Context ctx) {
        String meta = "<!-- Saved from " + escape(ctx.base.toString()) + " at " + OffsetDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ISO_OFFSET_DATE_TIME) + " -->";
        return meta + "\n" + html;
    }

    static String toMhtml(String html) {
        return "MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"----=_NextPart_000_0000\"\r\n\r\n"+
               "------=_NextPart_000_0000\r\nContent-Type: text/html; charset=\"utf-8\"\r\nContent-Location: http://example.com/\r\n\r\n"+
               html.replace("\n", "\r\n") + "------=_NextPart_000_0000--\r\n";
    }

    static String resolveOutput(String out, String html) {
        if (out == null) return null;
        String title = "index";
        Matcher m = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(html);
        if (m.find()) title = m.group(1).replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        String ts = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneOffset.UTC).format(Instant.now());
        return out.replace("%title%", title).replace("%timestamp%", ts);
    }

    static String mimeFor(String url, String def) {
        String u = url.toLowerCase(Locale.ROOT).split("[?#]", 2)[0];
        if (u.endsWith(".css")) return "text/css";
        if (u.endsWith(".js")) return "application/javascript";
        if (u.endsWith(".png")) return "image/png";
        if (u.endsWith(".jpg") || u.endsWith(".jpeg")) return "image/jpeg";
        if (u.endsWith(".gif")) return "image/gif";
        if (u.endsWith(".svg")) return "image/svg+xml";
        if (u.endsWith(".webp")) return "image/webp";
        if (u.endsWith(".woff")) return "font/woff";
        if (u.endsWith(".woff2")) return "font/woff2";
        if (u.endsWith(".mp3")) return "audio/mpeg";
        if (u.endsWith(".mp4")) return "video/mp4";
        if (u.endsWith(".html") || u.endsWith(".htm")) return "text/html";
        return def == null || def.isEmpty() ? "text/plain" : def;
    }

    static String blankPng() {
        return "data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82";
    }

    static String escape(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
    }
    static String first(String... s) { for (String x : s) if (x != null) return x; return ""; }

    static void printHelp() {
        System.out.print(BANNER + "\n" + VERSION + "\n\nCLI tool and library for saving web pages as a single HTML file\n\n"+
"Usage: executable [OPTIONS] <TARGET>\n\nArguments:\n  <TARGET>  URL or file path, use - for STDIN\n\nOptions:\n"+
"  -a, --no-audio                      Remove audio sources\n"+
"  -b, --base-url <http://localhost/>  Set custom base URL\n"+
"  -B, --blacklist-domains             Treat specified domains as blacklist\n"+
"  -c, --no-css                        Remove CSS\n"+
"  -C, --cookie-file <cookies.txt>     Specify cookie file\n"+
"  -d, --domain <example.com>          Specify domains to use for white/black-listing\n"+
"  -e, --ignore-errors                 Ignore network errors\n"+
"  -E, --encoding <UTF-8>              Enforce custom charset\n"+
"  -f, --no-frames                     Remove frames and iframes\n"+
"  -F, --no-fonts                      Remove fonts\n"+
"  -i, --no-images                     Remove images\n"+
"  -I, --isolate                       Cut off document from the Internet\n"+
"  -j, --no-js                         Remove JavaScript\n"+
"  -k, --insecure                      Allow invalid X.509 (TLS) certificates\n"+
"  -m, --mhtml                         Use MHTML as output format\n"+
"  -M, --no-metadata                   Exclude timestamp and source information\n"+
"  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents\n"+
"  -o, --output <result.html>          File to write to, use - for STDOUT\n"+
"  -q, --quiet                         Suppress verbosity\n"+
"  -t, --timeout <60>                  Adjust network request timeout\n"+
"  -u, --user-agent <Firefox>          Set custom User-Agent string\n"+
"  -v, --no-video                      Remove video sources\n"+
"  -h, --help                          Print help\n"+
"  -V, --version                       Print version\n");
    }

    static class CliException extends RuntimeException { CliException(String m) { super(m); } }
}
