import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static final String VERSION = "Cppcheck 2.19 dev";
    static final Set<String> SOURCE_EXT = Set.of(".cpp", ".cxx", ".cc", ".c++", ".c", ".ipp", ".ixx", ".tpp", ".txx", ".h", ".hpp");

    static class Options {
        boolean help, version, quiet, xml, errorList, checkConfig, preprocessOnly;
        boolean enableAll, enableStyle, enablePerformance, enablePortability, enableInformation, enableMissingInclude, enableUnusedFunction;
        int errorExitCode = 0;
        String template = null;
        String outputFile = null;
        List<String> inputs = new ArrayList<>();
        List<String> fileLists = new ArrayList<>();
        List<String> suppressions = new ArrayList<>();
    }

    static class Finding {
        String file, severity, id, message;
        int line, column;
        Finding(String file, int line, int column, String severity, String id, String message) {
            this.file = file; this.line = line; this.column = column;
            this.severity = severity; this.id = id; this.message = message;
        }
    }

    static class Var {
        String name, type;
        int line, arraySize = -1;
        boolean pointer, initialized, allocated, freed, used, isBool;
        boolean nullValue;
    }

    public static void main(String[] args) throws Exception {
        Options opt = parse(args);
        if (opt.help || args.length == 0) {
            printHelp();
            System.exit(0);
        }
        if (opt.version) {
            System.out.println(VERSION);
            System.exit(0);
        }
        if (opt.errorList) {
            printErrorList();
            System.exit(0);
        }

        List<Path> files = collectFiles(opt);
        if (files.isEmpty()) {
            System.err.println("cppcheck: error: could not find or open any of the paths given.");
            System.exit(1);
        }
        if (opt.preprocessOnly) {
            for (Path p : files) System.out.print(Files.readString(p, StandardCharsets.UTF_8));
            System.exit(0);
        }

        List<Finding> all = new ArrayList<>();
        int n = 0;
        for (Path p : files) {
            n++;
            if (!opt.quiet) {
                System.out.println("Checking " + p.toString() + "...");
                if (files.size() > 1) {
                    int pct = (int)Math.round(n * 100.0 / files.size());
                    System.out.println(n + "/" + files.size() + " files checked " + pct + "% done");
                }
            }
            all.addAll(analyze(p, opt));
        }
        all.removeIf(f -> isSuppressed(f, opt.suppressions));
        String rendered = render(all, opt);
        if (opt.outputFile != null) {
            Files.writeString(Paths.get(opt.outputFile), rendered, StandardCharsets.UTF_8);
        } else if (!rendered.isEmpty()) {
            System.err.print(rendered);
        }
        if (!all.isEmpty() && opt.errorExitCode != 0) System.exit(opt.errorExitCode);
        System.exit(0);
    }

    static Options parse(String[] args) throws IOException {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-h")) o.help = true;
            else if (a.equals("--version")) o.version = true;
            else if (a.equals("--xml") || a.equals("--output-format=xml") || a.equals("--output-format=xmlv2") || a.equals("--output-format=xmlv3")) o.xml = true;
            else if (a.equals("--errorlist")) o.errorList = true;
            else if (a.equals("--quiet") || a.equals("-q")) o.quiet = true;
            else if (a.equals("--check-config")) o.checkConfig = true;
            else if (a.equals("-E")) o.preprocessOnly = true;
            else if (a.startsWith("--error-exitcode=")) o.errorExitCode = parseInt(a.substring(17), 0);
            else if (a.equals("--error-exitcode") && i + 1 < args.length) o.errorExitCode = parseInt(args[++i], 0);
            else if (a.startsWith("--template=")) o.template = stripQuotes(a.substring(11));
            else if (a.equals("--template") && i + 1 < args.length) o.template = args[++i];
            else if (a.startsWith("--output-file=")) o.outputFile = a.substring(14);
            else if (a.equals("--output-file") && i + 1 < args.length) o.outputFile = args[++i];
            else if (a.startsWith("--file-list=")) o.fileLists.add(a.substring(12));
            else if (a.equals("--file-list") && i + 1 < args.length) o.fileLists.add(args[++i]);
            else if (a.startsWith("--suppress=")) o.suppressions.add(a.substring(11));
            else if (a.equals("--suppress") && i + 1 < args.length) o.suppressions.add(args[++i]);
            else if (a.startsWith("--suppressions-list=")) readSuppressions(o, a.substring(20));
            else if (a.equals("--suppressions-list") && i + 1 < args.length) readSuppressions(o, args[++i]);
            else if (a.startsWith("--enable=")) parseEnable(o, a.substring(9));
            else if (a.equals("--enable") && i + 1 < args.length) parseEnable(o, args[++i]);
            else if (takesValue(a)) { if (!a.contains("=") && i + 1 < args.length) i++; }
            else if (a.startsWith("-D") || a.startsWith("-U") || a.startsWith("-I")) { if (a.length() == 2 && i + 1 < args.length) i++; }
            else if (knownFlag(a)) {}
            else if (a.startsWith("-")) {
                System.err.println("cppcheck: error: unrecognized command line option: \"" + a + "\".");
                System.exit(1);
            } else o.inputs.add(a);
        }
        return o;
    }

    static void parseEnable(Options o, String s) {
        for (String part : s.split(",")) {
            switch (part.trim()) {
                case "all" -> { o.enableAll = o.enableStyle = o.enablePerformance = o.enablePortability = o.enableInformation = o.enableMissingInclude = o.enableUnusedFunction = true; }
                case "style" -> o.enableStyle = true;
                case "performance" -> o.enablePerformance = true;
                case "portability" -> o.enablePortability = true;
                case "information" -> o.enableInformation = true;
                case "missingInclude" -> o.enableMissingInclude = true;
                case "unusedFunction" -> o.enableUnusedFunction = true;
                case "warning" -> {}
            }
        }
    }

    static boolean takesValue(String a) {
        String k = a.contains("=") ? a.substring(0, a.indexOf('=')) : a;
        return Set.of("--addon","--addon-python","--cppcheck-build-dir","--checkers-report","--clang","--config-exclude",
                "--config-excludes-file","--disable","--exitcode-suppressions","--file-filter","--includes-file",
                "--include","-i","-j","-l","--language","-x","--library","--max-configs","--max-ctu-depth",
                "--output-format","--platform","--plist-output","--project","--project-configuration",
                "--relative-paths","-rp","--report-type","--rule","--rule-file","--showtime","--std",
                "--template-location","--suppress-xml").contains(k);
    }

    static boolean knownFlag(String a) {
        return Set.of("-f","--force","--fsigned-char","--funsigned-char","--inconclusive","--inline-suppr",
                "--dump","--check-library","--report-progress","--safety","--verbose","-v").contains(a);
    }

    static List<Path> collectFiles(Options o) throws IOException {
        List<String> items = new ArrayList<>(o.inputs);
        for (String fl : o.fileLists) {
            if (fl.equals("-")) {
                try (BufferedReader br = new BufferedReader(new java.io.InputStreamReader(System.in))) {
                    String line; while ((line = br.readLine()) != null) if (!line.isBlank()) items.add(line.trim());
                }
            } else {
                for (String line : Files.readAllLines(Paths.get(fl))) if (!line.isBlank()) items.add(line.trim());
            }
        }
        List<Path> out = new ArrayList<>();
        for (String item : items) {
            Path p = Paths.get(item);
            if (Files.isDirectory(p)) {
                try (var stream = Files.walk(p)) {
                    stream.filter(Files::isRegularFile).filter(Main::isSource).sorted().forEach(out::add);
                }
            } else if (Files.isRegularFile(p)) out.add(p);
        }
        out.sort(Comparator.comparing(Path::toString));
        return out;
    }

    static boolean isSource(Path p) {
        String s = p.getFileName().toString().toLowerCase(Locale.ROOT);
        for (String e : SOURCE_EXT) if (s.endsWith(e)) return true;
        return false;
    }

    static List<Finding> analyze(Path path, Options opt) throws IOException {
        List<String> raw = Files.readAllLines(path, StandardCharsets.UTF_8);
        List<String> lines = new ArrayList<>();
        boolean block = false;
        for (String l : raw) {
            String s = l;
            if (block) {
                int end = s.indexOf("*/");
                if (end >= 0) { s = s.substring(end + 2); block = false; } else { lines.add(""); continue; }
            }
            while (s.contains("/*")) {
                int st = s.indexOf("/*"), en = s.indexOf("*/", st + 2);
                if (en >= 0) s = s.substring(0, st) + s.substring(en + 2);
                else { s = s.substring(0, st); block = true; break; }
            }
            int sl = s.indexOf("//");
            if (sl >= 0) s = s.substring(0, sl);
            lines.add(s);
        }
        String file = path.toString();
        List<Finding> f = new ArrayList<>();
        Map<String, Var> vars = new HashMap<>();
        Set<String> functions = new HashSet<>();
        Set<String> called = new HashSet<>();
        Pattern decl = Pattern.compile("\\b((?:unsigned\\s+|signed\\s+|const\\s+|static\\s+|long\\s+|short\\s+)*[A-Za-z_][\\w:<>]*)\\s+(\\*+\\s*)?([A-Za-z_]\\w*)\\s*(?:\\[\\s*(-?\\d+)\\s*\\])?\\s*(=\\s*([^;]+))?;");
        Pattern func = Pattern.compile("\\b(?:int|void|char|double|float|bool|long|short|size_t|[A-Za-z_]\\w*)\\s+([A-Za-z_]\\w*)\\s*\\([^;]*\\)\\s*\\{?");
        for (int i = 0; i < lines.size(); i++) {
            String s = lines.get(i);
            Matcher fm = func.matcher(s);
            if (fm.find() && !s.trim().startsWith("if") && !s.trim().startsWith("for") && !s.trim().startsWith("while") && !s.contains("=")) functions.add(fm.group(1));
            Matcher dm = decl.matcher(s);
            while (dm.find()) {
                Var v = new Var();
                v.type = dm.group(1).trim(); v.name = dm.group(3); v.line = i + 1;
                v.pointer = dm.group(2) != null || v.type.contains("*"); v.isBool = v.type.endsWith("bool") || v.type.equals("bool");
                if (dm.group(4) != null) v.arraySize = parseInt(dm.group(4), -1);
                String init = dm.group(6);
                v.initialized = init != null || v.arraySize >= 0;
                if (dm.group(4) != null && v.arraySize < 0) add(f, file, i + 1, "error", "negativeArraySize", "Declaration of array '" + v.name + "' with negative size is undefined behaviour");
                if (init != null && init.contains("malloc")) v.allocated = true;
                if (init != null && v.pointer && init.trim().matches("(NULL|0)")) v.nullValue = true;
                vars.put(v.name, v);
            }
        }
        Pattern callPat = Pattern.compile("\\b([A-Za-z_]\\w*)\\s*\\(");
        Pattern idxPat = Pattern.compile("\\b([A-Za-z_]\\w*)\\s*\\[\\s*(-?\\d+)\\s*\\]");
        for (int i = 0; i < lines.size(); i++) {
            String s = lines.get(i);
            int line = i + 1;
            Matcher cm = callPat.matcher(s);
            while (cm.find()) called.add(cm.group(1));
            Matcher im = idxPat.matcher(s);
            while (im.find()) {
                Var v = vars.get(im.group(1));
                int idx = parseInt(im.group(2), 0);
                if (v != null && s.matches(".*\\b(?:char|int|short|long|float|double|bool|size_t)\\b.*\\b" + Pattern.quote(v.name) + "\\s*\\[.*")) continue;
                if (v != null && v.arraySize >= 0 && idx >= v.arraySize) {
                    add(f, file, line, "error", "arrayIndexOutOfBounds", "Array '" + v.name + "[" + v.arraySize + "]' accessed at index " + idx + ", which is out of bounds.");
                } else if (idx < 0) add(f, file, line, "error", "negativeIndex", "Negative array index");
                if (v != null) v.used = true;
            }
            for (Var v : vars.values()) {
                if (s.matches(".*\\b" + Pattern.quote(v.name) + "\\s*=.*")) {
                    v.initialized = true;
                    v.nullValue = v.pointer && s.matches(".*\\b" + Pattern.quote(v.name) + "\\s*=\\s*(NULL|0)\\s*;.*");
                }
                if (s.matches(".*\\b" + Pattern.quote(v.name) + "\\b.*") && line != v.line) v.used = true;
            }
            if (s.matches(".*(^|[^\\w])[/|%]\\s*0([^\\w]|$).*") || s.matches(".*\\b[A-Za-z_]\\w*\\s*/\\s*0\\b.*")) add(f, file, line, "error", "zerodiv", "Division by zero.");
            if (s.contains("NULL") || s.matches(".*=\\s*0\\s*;.*")) {
                Matcher p = Pattern.compile("\\b([A-Za-z_]\\w*)\\s*=\\s*(NULL|0)\\s*;").matcher(s);
                while (p.find()) { Var v = vars.get(p.group(1)); if (v != null && v.pointer) v.initialized = true; }
            }
            Matcher deref = Pattern.compile("\\*\\s*([A-Za-z_]\\w*)\\b|([A-Za-z_]\\w*)\\s*->").matcher(s);
            while (deref.find()) {
                String n = deref.group(1) != null ? deref.group(1) : deref.group(2);
                if (s.matches(".*\\b" + Pattern.quote(n) + "\\s*=\\s*(NULL|0)\\s*;.*")) continue;
                Var v = vars.get(n);
                if (v != null && v.pointer && (v.nullValue || definitelyNullBefore(lines, i, n))) add(f, file, line, "error", "nullPointer", "Null pointer dereference: " + n);
            }
            Matcher free = Pattern.compile("\\bfree\\s*\\(\\s*([A-Za-z_]\\w*)\\s*\\)").matcher(s);
            while (free.find()) {
                Var v = vars.get(free.group(1));
                if (v != null) {
                    if (!v.pointer && !v.allocated) add(f, file, line, "error", "autovarInvalidDeallocation", "Deallocation of an auto-variable results in undefined behaviour.");
                    if (v.freed) add(f, file, line, "error", "doubleFree", "Memory pointed to by '" + v.name + "' is freed twice.");
                    v.freed = true;
                }
            }
            Matcher retAddr = Pattern.compile("\\breturn\\s+&\\s*([A-Za-z_]\\w*)\\s*;").matcher(s);
            if (retAddr.find()) add(f, file, line, "error", "returnDanglingLifetime", "Returning object that will be invalid when returning.");
            if (s.contains("strcpy(") || s.contains("strcat(") || s.contains("gets(")) add(f, file, line, "warning", "unsafeClassCanLeak", "Unsafe function usage.");
            Matcher memset = Pattern.compile("\\bmemset\\s*\\([^,]+,[^,]+,\\s*0\\s*\\)").matcher(s);
            if (memset.find()) add(f, file, line, "warning", "memsetZeroBytes", "memset() called to fill 0 bytes.");
            Matcher assIf = Pattern.compile("\\b(if|while)\\s*\\([^=]*=[^=].*\\)").matcher(s);
            if ((opt.enableStyle || opt.enableAll) && assIf.find()) add(f, file, line, "style", "assignmentInCondition", "Assignment in condition.");
            Matcher boolInc = Pattern.compile("\\b([A-Za-z_]\\w*)\\s*\\+\\+").matcher(s);
            while ((opt.enableStyle || opt.enableAll) && boolInc.find()) {
                Var v = vars.get(boolInc.group(1));
                if (v != null && v.isBool) add(f, file, line, "style", "incrementboolean", "Incrementing a variable of type 'bool' with postfix operator++ is deprecated by the C++ Standard. You should assign it the value 'true' instead.");
            }
        }
        for (Var v : vars.values()) {
            if (v.allocated && !v.freed) add(f, file, v.line, "error", "memleak", "Memory leak: " + v.name);
            if ((opt.enableStyle || opt.enableAll) && !v.used && !v.name.equals("main")) add(f, file, v.line, "style", "unusedVariable", "Variable '" + v.name + "' is not used.");
        }
        if (opt.enableUnusedFunction || opt.enableAll) {
            for (String fn : functions) if (!fn.equals("main") && !called.contains(fn)) add(f, file, 1, "style", "unusedFunction", "The function '" + fn + "' is never used.");
        }
        if ((opt.enableMissingInclude || opt.enableAll) || opt.checkConfig) {
            for (int i = 0; i < lines.size(); i++) {
                Matcher inc = Pattern.compile("^\\s*#\\s*include\\s+\"([^\"]+)\"").matcher(lines.get(i));
                if (inc.find() && !Files.exists(path.getParent() == null ? Paths.get(inc.group(1)) : path.getParent().resolve(inc.group(1))))
                    add(f, file, i + 1, "information", "missingInclude", "Include file: \"" + inc.group(1) + "\" not found.");
            }
        }
        f.sort(Comparator.comparingInt((Finding x) -> x.line).thenComparing(x -> x.id));
        return f;
    }

    static boolean definitelyNullBefore(List<String> lines, int idx, String name) {
        for (int j = idx; j >= 0 && j >= idx - 20; j--) {
            String s = lines.get(j);
            if (s.matches(".*\\b" + Pattern.quote(name) + "\\s*=\\s*(NULL|0)\\s*;.*")) return true;
            if (j != idx && s.matches(".*\\b" + Pattern.quote(name) + "\\s*=\\s*[^;]+;.*")) return false;
        }
        return false;
    }

    static void add(List<Finding> f, String file, int line, String sev, String id, String msg) {
        f.add(new Finding(file, line, 0, sev, id, msg));
    }

    static String render(List<Finding> findings, Options opt) {
        StringBuilder sb = new StringBuilder();
        if (opt.xml) {
            sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<results version=\"2\">\n    <cppcheck version=\"2.19 dev\"/>\n    <errors>\n");
            for (Finding f : findings) sb.append("        <error id=\"").append(esc(f.id)).append("\" severity=\"").append(f.severity).append("\" msg=\"").append(esc(f.message)).append("\" verbose=\"").append(esc(f.message)).append("\"><location file=\"").append(esc(f.file)).append("\" line=\"").append(f.line).append("\"/></error>\n");
            sb.append("    </errors>\n</results>\n");
            return sb.toString();
        }
        for (Finding f : findings) {
            if (opt.template != null) {
                sb.append(applyTemplate(opt.template, f)).append('\n');
            } else {
                sb.append(f.file).append(':').append(f.line).append(":0: ").append(f.severity).append(": ").append(f.message).append(" [").append(f.id).append("]\n");
            }
        }
        return sb.toString();
    }

    static String applyTemplate(String t, Finding f) {
        return t.replace("\\n", "\n").replace("\\t", "\t").replace("{file}", f.file).replace("{line}", String.valueOf(f.line))
                .replace("{column}", String.valueOf(f.column)).replace("{severity}", f.severity).replace("{message}", f.message)
                .replace("{id}", f.id).replace("{cwe}", "").replace("{callstack}", "[" + f.file + ":" + f.line + "]");
    }

    static boolean isSuppressed(Finding f, List<String> specs) {
        for (String s : specs) {
            String[] p = s.split(":", -1);
            if (p.length > 0 && !(p[0].equals("*") || p[0].equals(f.id))) continue;
            if (p.length > 1 && !p[1].isEmpty() && !f.file.endsWith(p[1])) continue;
            if (p.length > 2 && !p[2].isEmpty() && parseInt(p[2], -99) != f.line) continue;
            return true;
        }
        return false;
    }

    static void readSuppressions(Options o, String file) throws IOException {
        for (String line : Files.readAllLines(Paths.get(file))) {
            String s = line.trim();
            if (!s.isEmpty() && !s.startsWith("#")) o.suppressions.add(s);
        }
    }

    static int parseInt(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return def; }
    }
    static String stripQuotes(String s) {
        if ((s.startsWith("'") && s.endsWith("'")) || (s.startsWith("\"") && s.endsWith("\""))) return s.substring(1, s.length() - 1);
        return s;
    }
    static String esc(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("'", "&apos;").replace("<", "&lt;").replace(">", "&gt;");
    }

    static void printHelp() {
        System.out.println("""
Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    --enable=<severity>  Enable additional checks. Values: warning, style, performance,
                         portability, information, unusedFunction, missingInclude, all
    --error-exitcode=<n> If errors are found, integer [n] is returned.
    --errorlist          Print a list of all the error messages in XML format.
    --file-list=<file>   Specify the files to check in a text file.
    -h, --help           Print this help.
    -I <dir>             Give path to search for include files.
    -q, --quiet          Do not show progress reports.
    --suppress=<spec>    Suppress warnings that match [error id]:[filename]:[line].
    --suppressions-list=<file>
                         Suppress warnings listed in the file.
    --template='<text>'  Format the error messages.
    --version            Print out version number.
    --xml                Write results in xml format to error stream (stderr).

Example usage:
  cppcheck .
  cppcheck --quiet ../myproject/
  cppcheck --enable=all test.cpp
""");
    }

    static void printErrorList() {
        System.out.println("""
<?xml version="1.0" encoding="UTF-8"?>
<results version="2">
    <cppcheck version="2.19 dev"/>
    <errors>
        <error id="arrayIndexOutOfBounds" severity="error" msg="Array 'arr[16]' accessed at index 16, which is out of bounds." verbose="Array 'arr[16]' accessed at index 16, which is out of bounds." cwe="788"/>
        <error id="negativeIndex" severity="error" msg="Negative array index" verbose="Negative array index" cwe="786"/>
        <error id="zerodiv" severity="error" msg="Division by zero." verbose="Division by zero."/>
        <error id="nullPointer" severity="error" msg="Null pointer dereference" verbose="Null pointer dereference"/>
        <error id="memleak" severity="error" msg="Memory leak" verbose="Memory leak"/>
        <error id="doubleFree" severity="error" msg="Memory pointed to by variable is freed twice." verbose="Memory pointed to by variable is freed twice."/>
        <error id="unusedVariable" severity="style" msg="Variable is not used." verbose="Variable is not used."/>
        <error id="missingInclude" severity="information" msg="Include file not found." verbose="Include file not found."/>
    </errors>
</results>
""");
    }
}
