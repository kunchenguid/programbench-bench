import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.FileTime;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

public class Main {
    static final String BANNER = "\n7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12\n" +
            " 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576\n";
    static final String HELP = BANNER + "\n" +
            "Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]\n\n" +
            "<Commands>\n" +
            "  a : Add files to archive\n" +
            "  b : Benchmark\n" +
            "  d : Delete files from archive\n" +
            "  e : Extract files from archive (without using directory names)\n" +
            "  h : Calculate hash values for files\n" +
            "  i : Show information about supported formats\n" +
            "  l : List contents of archive\n" +
            "  rn : Rename files in archive\n" +
            "  t : Test integrity of archive\n" +
            "  u : Update files to archive\n" +
            "  x : eXtract files with full paths\n\n" +
            "<Switches>\n" +
            "  -- : Stop switches and @listfile parsing\n" +
            "  -ai[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include archives\n" +
            "  -ax[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude archives\n" +
            "  -ao{a|s|t|u} : set Overwrite mode\n" +
            "  -an : disable archive_name field\n" +
            "  -bb[0-3] : set output log level\n" +
            "  -bd : disable progress indicator\n" +
            "  -bs{o|e|p}{0|1|2} : set output stream for output/error/progress line\n" +
            "  -bt : show execution time statistics\n" +
            "  -i[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include filenames\n" +
            "  -m{Parameters} : set compression Method\n" +
            "    -mmt[N] : set number of CPU threads\n" +
            "    -mx[N] : set compression level: -mx1 (fastest) ... -mx9 (ultra)\n" +
            "  -o{Directory} : set Output directory\n" +
            "  -p{Password} : set Password\n" +
            "  -r[-|0] : Recurse subdirectories for name search\n" +
            "  -sa{a|e|s} : set Archive name mode\n" +
            "  -scc{UTF-8|WIN|DOS} : set charset for console input/output\n" +
            "  -scs{UTF-8|UTF-16LE|UTF-16BE|WIN|DOS|{id}} : set charset for list files\n" +
            "  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands\n" +
            "  -sdel : delete files after compression\n" +
            "  -seml[.] : send archive by email\n" +
            "  -sfx[{name}] : Create SFX archive\n" +
            "  -si[{name}] : read data from stdin\n" +
            "  -slp : set Large Pages mode\n" +
            "  -snh : store hard links as links\n" +
            "  -snl : store symbolic links as links\n" +
            "  -sni : store NT security information\n" +
            "  -sns[-] : store NTFS alternate streams\n" +
            "  -so : write data to stdout\n" +
            "  -spd : disable wildcard matching for file names\n" +
            "  -spe : eliminate duplication of root folder for extract command\n" +
            "  -spf[2] : use fully qualified file paths\n" +
            "  -ssc[-] : set sensitive case mode\n" +
            "  -sse : stop archive creating, if it can't open some input file\n" +
            "  -ssp : do not change Last Access Time of source files while archiving\n" +
            "  -ssw : compress shared files\n" +
            "  -stl : set archive timestamp from the most recently modified file\n" +
            "  -stm{HexMask} : set CPU thread affinity mask (hexadecimal number)\n" +
            "  -stx{Type} : exclude archive type\n" +
            "  -t{Type} : Set type of archive\n" +
            "  -u[-][p#][q#][r#][x#][y#][z#][!newArchiveName] : Update options\n" +
            "  -v{Size}[b|k|m|g] : Create volumes\n" +
            "  -w[{path}] : assign Work directory. Empty path means a temporary directory\n" +
            "  -x[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude filenames\n" +
            "  -y : assume Yes on all queries\n";

    public static void main(String[] args) {
        try {
            int rc = run(args);
            if (rc != 0) System.exit(rc);
        } catch (Exception e) {
            System.out.println("\n\nSystem ERROR:");
            System.out.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(2);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("-h") || args[0].equals("--help") || args[0].equals("/?")) {
            System.out.print(HELP);
            return 0;
        }
        String cmd = args[0].toLowerCase(Locale.ROOT);
        if (cmd.startsWith("-")) {
            System.out.println("\n\nCommand Line Error:\nUnknown switch:\n" + cmd);
            return 7;
        }
        List<String> rest = expandListFiles(Arrays.asList(args).subList(1, args.length));
        Options opt = parse(rest);
        switch (cmd) {
            case "i": printInfo(); return 0;
            case "h": return hash(opt);
            case "a": case "u": return add(opt);
            case "l": return list(opt, false);
            case "t": return test(opt);
            case "x": return extract(opt, true);
            case "e": return extract(opt, false);
            case "b": return bench();
            default:
                System.out.println("\n\nCommand Line Error:\nUnsupported command:\n" + cmd);
                System.out.print(BANNER);
                return 7;
        }
    }

    static class Options {
        String type, outDir = ".";
        String hashAlg = "CRC32";
        boolean stdout, technical;
        List<String> pos = new ArrayList<>();
    }

    static Options parse(List<String> args) {
        Options o = new Options();
        boolean switches = true;
        for (String a : args) {
            if (switches && a.equals("--")) { switches = false; continue; }
            if (switches && a.startsWith("-") && a.length() > 1) {
                String l = a.toLowerCase(Locale.ROOT);
                if (l.startsWith("-t")) o.type = a.substring(2).toLowerCase(Locale.ROOT);
                else if (l.startsWith("-o")) o.outDir = a.substring(2).isEmpty() ? "." : a.substring(2);
                else if (l.startsWith("-scrc")) o.hashAlg = a.substring(5).toUpperCase(Locale.ROOT);
                else if (l.equals("-so")) o.stdout = true;
                else if (l.equals("-slt")) o.technical = true;
                continue;
            }
            o.pos.add(a);
        }
        return o;
    }

    static List<String> expandListFiles(List<String> args) throws IOException {
        List<String> out = new ArrayList<>();
        for (String a : args) {
            if (a.startsWith("@") && a.length() > 1) {
                out.addAll(Files.readAllLines(Path.of(a.substring(1)), StandardCharsets.UTF_8));
            } else out.add(a);
        }
        return out;
    }

    static void printInfo() {
        System.out.print(BANNER + "\n\nFormats:\n" +
                "   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C\n" +
                "   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08\n" +
                "   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r\n" +
                "   CK.....................  xz       xz txz (.tar) FD 7 z X Z 00\n" +
                "   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04\n" +
                "   CK.....O.....XC........  Hash     sha256 sha1 crc32 crc64\n\n" +
                "Codecs:\n" +
                "    ED         0 Copy\n" +
                "    ED     40108 Deflate\n\n" +
                "Hashers:\n" +
                "      4        1 CRC32\n" +
                "     20      201 SHA1\n" +
                "     32        A SHA256\n" +
                "      8        4 CRC64\n");
    }

    static int bench() {
        System.out.print(BANNER + "\n7-Zip Java cleanroom benchmark placeholder\nEverything is Ok\n");
        return 0;
    }

    static int hash(Options o) throws Exception {
        String alg = o.hashAlg;
        List<Path> files = collectInputs(o.pos);
        long total = files.stream().mapToLong(Main::sizeOf).sum();
        System.out.print(BANNER + "\nScanning\n" + files.size() + " file" + (files.size()==1?"":"s") + ", " + total + " bytes (1 KiB)\n\n");
        String label = alg.equals("SHA1") ? "SHA1" : alg.equals("SHA256") ? "SHA256" : "CRC32";
        int width = label.equals("SHA256") ? 64 : label.equals("SHA1") ? 40 : 8;
        System.out.printf("%-" + width + "s  %12s  %s%n", label, "Size", "Name");
        System.out.println("-".repeat(width) + " -------------  ------------");
        for (Path f : files) System.out.printf("%-" + width + "s  %12d  %s%n", digest(label, f), Files.size(f), norm(f.toString()));
        System.out.println("-".repeat(width) + " -------------  ------------");
        System.out.printf("%-" + width + "s  %12d  %n%n", combinedDigest(label, files), total);
        if (files.size() != 1) System.out.println("Files: " + files.size());
        System.out.println("Size: " + total + "\n");
        System.out.printf("%-6s for data:              %s%n%n", label, combinedDigest(label, files));
        System.out.println("Everything is Ok");
        return 0;
    }

    static List<Path> collectInputs(List<String> names) throws IOException {
        List<Path> out = new ArrayList<>();
        for (String n : names) {
            if (n.startsWith("-")) continue;
            Path p = Path.of(n);
            if (Files.isDirectory(p)) {
                try (var s = Files.walk(p)) {
                    s.filter(Files::isRegularFile).sorted().forEach(out::add);
                }
            } else if (Files.isRegularFile(p)) out.add(p);
        }
        return out;
    }

    static long sizeOf(Path p) { try { return Files.size(p); } catch (IOException e) { return 0; } }

    static String digest(String alg, Path f) throws Exception {
        byte[] data = Files.readAllBytes(f);
        if (alg.equals("CRC32")) {
            CRC32 c = new CRC32(); c.update(data); return String.format("%08X", c.getValue());
        }
        MessageDigest md = MessageDigest.getInstance(alg.equals("SHA1") ? "SHA-1" : "SHA-256");
        return hex(md.digest(data));
    }

    static String combinedDigest(String alg, List<Path> files) throws Exception {
        if (alg.equals("CRC32")) {
            CRC32 c = new CRC32();
            for (Path f : files) c.update(Files.readAllBytes(f));
            return String.format("%08X", c.getValue());
        }
        MessageDigest md = MessageDigest.getInstance(alg.equals("SHA1") ? "SHA-1" : "SHA-256");
        for (Path f : files) md.update(Files.readAllBytes(f));
        return hex(md.digest());
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x & 0xff));
        return sb.toString();
    }

    static int add(Options o) throws Exception {
        if (o.pos.isEmpty()) return commandError("Cannot find archive name");
        Path archive = Path.of(o.pos.get(0));
        List<String> names = o.pos.subList(1, o.pos.size());
        List<Entry> entries = new ArrayList<>();
        for (String n : names) addEntry(Path.of(n), null, entries);
        long bytes = entries.stream().filter(e -> !e.dir).mapToLong(e -> sizeOf(e.path)).sum();
        long dirs = entries.stream().filter(e -> e.dir).count();
        long files = entries.stream().filter(e -> !e.dir).count();
        System.out.print(BANNER + "\nScanning the drive:\n");
        System.out.printf("%s%s%s, %d bytes (1 KiB)%n%n", dirs>0?dirs+" folder"+(dirs==1?"":"s"):"", dirs>0&&files>0?", ":"", files+" file"+(files==1?"":"s"), bytes);
        System.out.println("Creating archive: " + archive + "\n");
        String type = typeOf(archive, o.type);
        if (type.equals("tar")) writeTar(archive, entries);
        else writeZip(archive, entries);
        System.out.printf("Add new data to archive: %s%s%s, %d bytes (1 KiB)%n%n%n", dirs>0?dirs+" folder"+(dirs==1?"":"s"):"", dirs>0&&files>0?", ":"", files+" file"+(files==1?"":"s"), bytes);
        System.out.println("Files read from disk: " + files);
        System.out.println("Archive size: " + Files.size(archive) + " bytes (1 KiB)");
        System.out.println("Everything is Ok");
        return 0;
    }

    static class Entry { Path path; String name; boolean dir; Entry(Path p, String n, boolean d){path=p;name=n;dir=d;} }

    static void addEntry(Path p, Path parent, List<Entry> out) throws IOException {
        if (!Files.exists(p)) return;
        String name = parent == null ? p.toString() : parent.relativize(p).toString();
        name = norm(name);
        if (Files.isDirectory(p)) {
            out.add(new Entry(p, name, true));
            try (var s = Files.list(p)) {
                List<Path> kids = s.sorted().toList();
                for (Path k : kids) addEntry(k, parent, out);
            }
        } else out.add(new Entry(p, name, false));
    }

    static void writeZip(Path archive, List<Entry> entries) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(archive))) {
            for (Entry e : entries) {
                ZipEntry ze = new ZipEntry(e.dir ? e.name + "/" : e.name);
                ze.setTime(Files.getLastModifiedTime(e.path).toMillis());
                z.putNextEntry(ze);
                if (!e.dir) Files.copy(e.path, z);
                z.closeEntry();
            }
        }
    }

    static void writeTar(Path archive, List<Entry> entries) throws IOException {
        try (OutputStream os = Files.newOutputStream(archive)) {
            for (Entry e : entries) {
                byte[] data = e.dir ? new byte[0] : Files.readAllBytes(e.path);
                byte[] h = tarHeader(e.name + (e.dir && !e.name.endsWith("/") ? "/" : ""), data.length, e.dir, Files.getLastModifiedTime(e.path).toMillis()/1000);
                os.write(h); if (!e.dir) os.write(data);
                int pad = (int)((512 - (data.length % 512)) % 512);
                os.write(new byte[pad]);
            }
            os.write(new byte[1024]);
        }
    }

    static byte[] tarHeader(String name, long size, boolean dir, long mtime) {
        byte[] h = new byte[512];
        put(h,0,100,name); putOct(h,100,8,0644); putOct(h,108,8,0); putOct(h,116,8,0);
        putOct(h,124,12,dir?0:size); putOct(h,136,12,mtime);
        Arrays.fill(h,148,156,(byte)' '); h[156]=(byte)(dir?'5':'0'); put(h,257,6,"ustar"); put(h,263,2,"00");
        long sum=0; for(byte b:h) sum += b & 0xff; putOct(h,148,8,sum);
        return h;
    }
    static void put(byte[] h,int off,int len,String s){ byte[] b=s.getBytes(StandardCharsets.UTF_8); System.arraycopy(b,0,h,off,Math.min(len,b.length));}
    static void putOct(byte[] h,int off,int len,long v){ byte[] b=String.format("%0"+(len-1)+"o",v).getBytes(StandardCharsets.US_ASCII); System.arraycopy(b,0,h,off,Math.min(len-1,b.length)); h[off+len-1]=0; }

    static int list(Options o, boolean quiet) throws Exception {
        if (o.pos.isEmpty()) return commandError("Cannot find archive name");
        Path a = Path.of(o.pos.get(0));
        if (!Files.exists(a)) return missing(a);
        String type = typeOf(a, o.type);
        List<ArchiveItem> items = type.equals("tar") ? readTar(a) : readZip(a);
        if (!quiet) {
            System.out.print(BANNER + "\nScanning the drive for archives:\n1 file, " + Files.size(a) + " bytes (1 KiB)\n\nListing archive: " + a + "\n\n--\n");
            System.out.println("Path = " + a);
            System.out.println("Type = " + type);
            System.out.println("Physical Size = " + Files.size(a));
            if (o.technical) {
                for (ArchiveItem it : items) {
                    System.out.println("\nPath = " + it.name + "\nSize = " + it.size + "\nPacked Size = " + it.packed + "\nModified = " + fmt(it.time) + "\nFolder = " + (it.dir ? "+" : "-"));
                }
            } else {
                System.out.println("\n   Date      Time    Attr         Size   Compressed  Name");
                System.out.println("------------------- ----- ------------ ------------  ------------------------");
                for (ArchiveItem it : items) System.out.printf("%s %s %12d %12d  %s%n", fmt(it.time), it.dir?"D....":".....", it.size, it.packed, it.name);
                System.out.println("------------------- ----- ------------ ------------  ------------------------");
                long files = items.stream().filter(i -> !i.dir).count(), dirs = items.stream().filter(i -> i.dir).count();
                long size = items.stream().filter(i -> !i.dir).mapToLong(i -> i.size).sum();
                long packed = items.stream().filter(i -> !i.dir).mapToLong(i -> i.packed).sum();
                System.out.printf("%s %17d %12d  %d files%s%n", fmt(new Date()), size, packed, files, dirs>0?", "+dirs+" folders":"");
            }
        }
        return 0;
    }

    static class ArchiveItem { String name; long size, packed; boolean dir; Date time; byte[] data; }

    static List<ArchiveItem> readZip(Path a) throws IOException {
        List<ArchiveItem> out = new ArrayList<>();
        try (ZipFile z = new ZipFile(a.toFile())) {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry ze = en.nextElement();
                ArchiveItem it = new ArchiveItem();
                it.name = ze.getName().replaceAll("/$", ""); it.dir = ze.isDirectory();
                it.size = Math.max(0, ze.getSize()); it.packed = Math.max(0, ze.getCompressedSize());
                FileTime ft = ze.getLastModifiedTime(); it.time = new Date(ft == null ? 0 : ft.toMillis());
                if (!it.dir) try (InputStream is = z.getInputStream(ze)) { it.data = is.readAllBytes(); }
                out.add(it);
            }
        }
        return out;
    }

    static List<ArchiveItem> readTar(Path a) throws IOException {
        List<ArchiveItem> out = new ArrayList<>();
        try (InputStream is = Files.newInputStream(a)) {
            while (true) {
                byte[] h = is.readNBytes(512);
                if (h.length < 512 || allZero(h)) break;
                String name = cstr(h,0,100); long size = parseOct(h,124,12); boolean dir = h[156]=='5' || name.endsWith("/");
                ArchiveItem it = new ArchiveItem(); it.name = name.replaceAll("/$", ""); it.size = dir?0:size; it.packed = dir?0:((size+511)/512)*512; it.dir=dir; it.time = new Date(parseOct(h,136,12)*1000);
                it.data = is.readNBytes((int)size);
                long pad = (512 - (size % 512)) % 512; if (pad>0) is.skipNBytes(pad);
                out.add(it);
            }
        }
        return out;
    }
    static boolean allZero(byte[] b){ for(byte x:b) if(x!=0) return false; return true; }
    static String cstr(byte[] b,int o,int l){ int e=o; while(e<o+l && b[e]!=0)e++; return new String(b,o,e-o,StandardCharsets.UTF_8); }
    static long parseOct(byte[] b,int o,int l){ String s=cstr(b,o,l).trim(); if(s.isEmpty())return 0; return Long.parseLong(s,8); }

    static int test(Options o) throws Exception {
        if (o.pos.isEmpty()) return commandError("Cannot find archive name");
        Path a = Path.of(o.pos.get(0)); if (!Files.exists(a)) return missing(a);
        List<ArchiveItem> items = typeOf(a,o.type).equals("tar") ? readTar(a) : readZip(a);
        long size = items.stream().filter(i -> !i.dir).mapToLong(i -> i.size).sum();
        System.out.print(BANNER + "\nScanning the drive for archives:\n1 file, " + Files.size(a) + " bytes (1 KiB)\n\nTesting archive: " + a + "\n--\nPath = " + a + "\nType = " + typeOf(a,o.type) + "\nPhysical Size = " + Files.size(a) + "\n\nEverything is Ok\n\n");
        System.out.println("Size:       " + size);
        System.out.println("Compressed: " + Files.size(a));
        return 0;
    }

    static int extract(Options o, boolean full) throws Exception {
        if (o.pos.isEmpty()) return commandError("Cannot find archive name");
        Path a = Path.of(o.pos.get(0)); if (!Files.exists(a)) return missing(a);
        if (o.stdout) {
            for (ArchiveItem it : itemsFor(a,o)) if (!it.dir && it.data != null) System.out.write(it.data);
            return 0;
        }
        List<ArchiveItem> items = itemsFor(a,o);
        Path base = Path.of(o.outDir); Files.createDirectories(base);
        for (ArchiveItem it : items) {
            String n = full ? it.name : Path.of(it.name).getFileName().toString();
            Path out = base.resolve(n).normalize();
            if (it.dir) Files.createDirectories(out);
            else { Files.createDirectories(out.getParent()==null?base:out.getParent()); Files.write(out, it.data); }
        }
        long size = items.stream().filter(i -> !i.dir).mapToLong(i -> i.size).sum();
        long files = items.stream().filter(i -> !i.dir).count();
        System.out.print(BANNER + "\nScanning the drive for archives:\n1 file, " + Files.size(a) + " bytes (1 KiB)\n\nExtracting archive: " + a + "\n--\nPath = " + a + "\nType = " + typeOf(a,o.type) + "\nPhysical Size = " + Files.size(a) + "\n\nEverything is Ok\n\n");
        System.out.println("Files: " + files);
        System.out.println("Size:       " + size);
        System.out.println("Compressed: " + Files.size(a));
        return 0;
    }

    static List<ArchiveItem> itemsFor(Path a, Options o) throws IOException {
        String t = typeOf(a,o.type);
        if (t.equals("tar")) return readTar(a);
        if (t.equals("gzip")) {
            ArchiveItem it = new ArchiveItem(); String n = a.getFileName().toString().replaceFirst("\\.gz$", "");
            it.name=n; it.dir=false; try(GZIPInputStream gis=new GZIPInputStream(Files.newInputStream(a))){ it.data=gis.readAllBytes(); }
            it.size=it.data.length; it.packed=Files.size(a); it.time=new Date(Files.getLastModifiedTime(a).toMillis()); return List.of(it);
        }
        return readZip(a);
    }

    static int missing(Path p) {
        System.out.print(BANNER + "\nScanning the drive for archives:\n\nERROR: errno=2 : No such file or directory\n" + p + "\n\n\n\nSystem ERROR:\nerrno=2 : No such file or directory\n");
        return 2;
    }
    static int commandError(String s) { System.out.println("\n\nCommand Line Error:\n" + s); return 7; }
    static String typeOf(Path a, String forced) {
        if (forced != null && !forced.isEmpty()) return forced.equals("gz") ? "gzip" : forced;
        String n = a.toString().toLowerCase(Locale.ROOT);
        if (n.endsWith(".tar")) return "tar";
        if (n.endsWith(".gz") || n.endsWith(".gzip") || n.endsWith(".tgz")) return "gzip";
        return "zip";
    }
    static String norm(String s){ return s.replace(File.separatorChar, '/'); }
    static String fmt(Date d){ return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(d); }
}
