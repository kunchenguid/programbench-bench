import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class FigletClone {
    static final String VERSION_TEXT =
            "FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,\n" +
            "Christiaan Keet and Claudio Matsuoka\n" +
            "Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012\n\n" +
            "FIGlet, along with the various FIGlet fonts and documentation, may be\n" +
            "freely copied and distributed.\n\n" +
            "If you use FIGlet, please send an e-mail message to <info@figlet.org>.\n\n" +
            "The latest version of FIGlet is available from the web site,\n" +
            "\thttp://www.figlet.org/\n\n" +
            "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n" +
            "              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n" +
            "              [ -C controlfile ] [ -I infocode ] [ message ]";
    static final String USAGE =
            "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n" +
            "              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n" +
            "              [ -C controlfile ] [ -I infocode ] [ message ]";

    enum Spacing { DEFAULT, SMUSH, FORCE_SMUSH, KERN, FULL, OVERLAP }
    enum Justify { AUTO, LEFT, CENTER, RIGHT }

    static class Opts {
        String fontDir = "/usr/local/share/figlet";
        String font = "standard";
        int width = 80;
        int info = -1;
        boolean rtl = false;
        boolean paragraph = false;
        boolean german = false;
        Spacing spacing = Spacing.DEFAULT;
        Justify justify = Justify.AUTO;
        Integer explicitLayout = null;
        List<String> msg = new ArrayList<>();
    }

    static class Font {
        char hardblank;
        int height;
        int oldLayout;
        int fullLayout;
        int printDirection;
        Map<Integer, String[]> glyphs = new HashMap<>();
        int layoutMode() {
            if (fullLayout != Integer.MIN_VALUE && fullLayout != 0) return fullLayout & 63;
            return oldLayout;
        }
    }

    public static void main(String[] args) {
        try {
            Opts o = parse(args);
            if (o.info >= 0) {
                printInfo(o);
                return;
            }
            Font font = loadFont(o.fontDir, o.font);
            if (font.printDirection == 1) o.rtl = true;
            String input = o.msg.isEmpty() ? readAllStdin() : String.join(" ", o.msg);
            if (o.paragraph) input = paragraphize(input);
            if (o.german) input = germanMap(input);
            List<String> out = renderText(input, font, o);
            for (String s : out) System.out.println(s);
        } catch (FigletException e) {
            System.err.println("executable: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            if (System.getenv("FIGLET_DEBUG") != null) e.printStackTrace();
            System.err.println("executable: " + e.getMessage());
            System.exit(1);
        }
    }

    static Opts parse(String[] args) throws FigletException {
        Opts o = new Opts();
        boolean endOpts = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (!endOpts && a.equals("--")) { endOpts = true; continue; }
            if (!endOpts && a.startsWith("-") && a.length() > 1) {
                for (int j = 1; j < a.length(); j++) {
                    char c = a.charAt(j);
                    switch (c) {
                        case 'f':
                            o.font = needArg(args, a, i, j);
                            if (j + 1 < a.length()) { o.font = a.substring(j + 1); j = a.length(); }
                            else i++;
                            j = a.length();
                            break;
                        case 'd':
                            o.fontDir = needArg(args, a, i, j);
                            if (j + 1 < a.length()) { o.fontDir = a.substring(j + 1); j = a.length(); }
                            else i++;
                            j = a.length();
                            break;
                        case 'w':
                            String w = needArg(args, a, i, j);
                            if (j + 1 < a.length()) { w = a.substring(j + 1); j = a.length(); }
                            else i++;
                            try { o.width = Integer.parseInt(w); } catch (NumberFormatException ex) { throw new FigletException("invalid width"); }
                            j = a.length();
                            break;
                        case 'm':
                            String m = needArg(args, a, i, j);
                            if (j + 1 < a.length()) { m = a.substring(j + 1); j = a.length(); }
                            else i++;
                            try { o.explicitLayout = Integer.parseInt(m); } catch (NumberFormatException ex) { throw new FigletException("invalid smushmode"); }
                            if (o.explicitLayout == 0) o.spacing = Spacing.KERN;
                            else if (o.explicitLayout == -1) o.spacing = Spacing.FULL;
                            else if (o.explicitLayout == -2) o.spacing = Spacing.DEFAULT;
                            else o.spacing = Spacing.SMUSH;
                            j = a.length();
                            break;
                        case 'I':
                            String inf = needArg(args, a, i, j);
                            if (j + 1 < a.length()) { inf = a.substring(j + 1); j = a.length(); }
                            else i++;
                            try { o.info = Integer.parseInt(inf); } catch (NumberFormatException ex) { o.info = -1; }
                            j = a.length();
                            break;
                        case 'C':
                            if (j + 1 >= a.length()) i++;
                            j = a.length();
                            break;
                        case 'c': o.justify = Justify.CENTER; break;
                        case 'l': o.justify = Justify.LEFT; break;
                        case 'r': o.justify = Justify.RIGHT; break;
                        case 'x': o.justify = Justify.AUTO; break;
                        case 'L': o.rtl = false; break;
                        case 'R': o.rtl = true; break;
                        case 'X': break;
                        case 'p': o.paragraph = true; break;
                        case 'n': o.paragraph = false; o.spacing = Spacing.KERN; break;
                        case 's': o.spacing = Spacing.DEFAULT; break;
                        case 'S': o.spacing = Spacing.FORCE_SMUSH; break;
                        case 'k': o.spacing = Spacing.KERN; break;
                        case 'W': o.spacing = Spacing.FULL; break;
                        case 'o': o.spacing = Spacing.OVERLAP; break;
                        case 'D': o.german = true; break;
                        case 'E': o.german = false; break;
                        case 't': o.width = 80; break;
                        case 'v': o.info = 0; break;
                        default:
                            System.err.println("executable: invalid option -- '" + c + "'");
                            System.err.println(USAGE);
                            System.exit(1);
                    }
                }
            } else {
                o.msg.add(a);
            }
        }
        return o;
    }

    static String needArg(String[] args, String a, int i, int j) throws FigletException {
        if (j + 1 < a.length()) return a.substring(j + 1);
        if (i + 1 < args.length) return args[i + 1];
        throw new FigletException("option requires an argument -- '" + a.charAt(j) + "'");
    }

    static void printInfo(Opts o) {
        switch (o.info) {
            case 0: System.out.println(VERSION_TEXT); break;
            case 1: System.out.println("20205"); break;
            case 2: System.out.println(o.fontDir); break;
            case 3: System.out.println(stripSuffix(Paths.get(o.font).getFileName().toString())); break;
            case 4: System.out.println(o.width); break;
            case 5: System.out.println("flf2 tlf2"); break;
            default: break;
        }
    }

    static Font loadFont(String dir, String name) throws IOException, FigletException {
        List<Path> tries = new ArrayList<>();
        Path n = Paths.get(name);
        if (n.isAbsolute() || name.contains("/") || name.contains(File.separator)) {
            tries.add(n);
            if (!name.endsWith(".flf") && !name.endsWith(".tlf")) {
                tries.add(Paths.get(name + ".flf"));
                tries.add(Paths.get(name + ".tlf"));
            }
        } else {
            tries.add(Paths.get(dir, name));
            tries.add(Paths.get(dir, name + ".flf"));
            tries.add(Paths.get(dir, name + ".tlf"));
            tries.add(Paths.get("fonts", name));
            tries.add(Paths.get("fonts", name + ".flf"));
            tries.add(Paths.get("fonts", name + ".tlf"));
            tries.add(Paths.get("assets", name + ".flf"));
            tries.add(Paths.get("assets", name + ".tlf"));
        }
        Path path = null;
        for (Path p : tries) if (Files.isRegularFile(p)) { path = p; break; }
        if (path == null) throw new FigletException(name + ": Unable to open font file");
        return parseFont(path);
    }

    static Font parseFont(Path path) throws IOException, FigletException {
        byte[] data = Files.readAllBytes(path);
        List<String> lines;
        try {
            lines = Arrays.asList(new String(data, StandardCharsets.UTF_8).split("\\R", -1));
        } catch (Exception ex) {
            lines = Arrays.asList(new String(data, StandardCharsets.ISO_8859_1).split("\\R", -1));
        }
        if (lines.isEmpty()) throw new FigletException(path + ": Bad font file");
        String[] parts = lines.get(0).split("\\s+");
        if (parts.length < 6 || !(parts[0].startsWith("flf2a") || parts[0].startsWith("tlf2a")))
            throw new FigletException(path + ": Bad font file");
        Font f = new Font();
        f.hardblank = parts[0].charAt(parts[0].length() - 1);
        f.height = Integer.parseInt(parts[1]);
        f.oldLayout = Integer.parseInt(parts[4]);
        int comments = Integer.parseInt(parts[5]);
        f.printDirection = parts.length > 6 ? parseInt(parts[6], 0) : 0;
        f.fullLayout = parts.length > 7 ? parseInt(parts[7], Integer.MIN_VALUE) : Integer.MIN_VALUE;
        int idx = 1 + comments;
        for (int code = 32; code <= 126 && idx + f.height <= lines.size(); code++) {
            f.glyphs.put(code, readGlyph(lines, idx, f.height));
            idx += f.height;
        }
        int[] extras = {196, 214, 220, 228, 246, 252, 223};
        for (int code : extras) {
            if (idx + f.height <= lines.size()) {
                f.glyphs.put(code, readGlyph(lines, idx, f.height));
                idx += f.height;
            }
        }
        while (idx < lines.size()) {
            String s = lines.get(idx).trim();
            if (s.isEmpty()) { idx++; continue; }
            String[] p = s.split("\\s+");
            Integer code = null;
            try {
                if (p[0].startsWith("0x") || p[0].startsWith("0X")) code = Integer.parseInt(p[0].substring(2), 16);
                else code = Integer.parseInt(p[0]);
            } catch (NumberFormatException ignored) {}
            idx++;
            if (code != null && idx + f.height <= lines.size()) {
                f.glyphs.put(code, readGlyph(lines, idx, f.height));
                idx += f.height;
            }
        }
        return f;
    }

    static int parseInt(String s, int d) {
        try { return Integer.parseInt(s); } catch (Exception e) { return d; }
    }

    static String[] readGlyph(List<String> lines, int idx, int h) {
        String[] g = new String[h];
        for (int r = 0; r < h; r++) {
            String s = lines.get(idx + r);
            if (!s.isEmpty()) {
                char end = s.charAt(s.length() - 1);
                while (!s.isEmpty() && s.charAt(s.length() - 1) == end) s = s.substring(0, s.length() - 1);
            }
            g[r] = s;
        }
        return g;
    }

    static List<String> renderText(String input, Font f, Opts o) {
        List<String> result = new ArrayList<>();
        String[] rows = blankRows(f.height);
        int[] cps = input.codePoints().toArray();
        for (int pos = 0; pos < cps.length; pos++) {
            int cp = cps[pos];
            if (cp == '\r') continue;
            if (cp == '\n') {
                flush(result, rows, f, o);
                rows = blankRows(f.height);
                continue;
            }
            String[] glyph = glyphFor(f, cp);
            if (o.rtl) glyph = copyGlyph(glyph);
            int prospective = widthAfterAdd(rows, glyph, f, o);
            if (o.width > 1 && maxWidth(rows) > 0 && prospective > o.width) {
                flush(result, rows, f, o);
                rows = blankRows(f.height);
                if (cp == ' ') continue;
            }
            rows = addGlyph(rows, glyph, f, o);
        }
        flush(result, rows, f, o);
        return result;
    }

    static String[] glyphFor(Font f, int cp) {
        String[] g = f.glyphs.get(cp);
        if (g == null) g = f.glyphs.get((int)'?');
        if (g == null) g = blankRows(f.height);
        return g;
    }

    static String[] blankRows(int h) {
        String[] r = new String[h];
        Arrays.fill(r, "");
        return r;
    }

    static int widthAfterAdd(String[] rows, String[] glyph, Font f, Opts o) {
        return maxWidth(addGlyph(copyGlyph(rows), glyph, f, o));
    }

    static String[] addGlyph(String[] rows, String[] glyph, Font f, Opts o) {
        if (maxWidth(rows) == 0) {
            String[] out = new String[f.height];
            for (int i = 0; i < f.height; i++) out[i] = glyph[i];
            return out;
        }
        if (o.rtl) {
            String[] swapped = new String[f.height];
            for (int i = 0; i < f.height; i++) swapped[i] = glyph[i];
            return merge(swapped, rows, fitting(glyph, rows, f, o), f, o);
        }
        return merge(rows, glyph, fitting(rows, glyph, f, o), f, o);
    }

    static String[] copyGlyph(String[] g) {
        return Arrays.copyOf(g, g.length);
    }

    static int fitting(String[] left, String[] right, Font f, Opts o) {
        if (o.spacing == Spacing.FULL || (o.spacing == Spacing.DEFAULT && f.oldLayout < 0)) return 0;
        boolean smush = isSmush(f, o);
        int mode = layout(f, o);
        int best = Integer.MAX_VALUE;
        for (int r = 0; r < f.height; r++) {
            String l = left[r], rr = right[r];
            int trail = trailingBlanks(l);
            int lead = leadingBlanks(rr);
            int lpos = l.length() - trail - 1;
            int rpos = lead;
            int amt = trail + lead;
            if (lpos >= 0 && rpos < rr.length()) {
                char lc = l.charAt(lpos), rc = rr.charAt(rpos);
                if (o.spacing == Spacing.OVERLAP) amt++;
                else if (smush && smushChar(lc, rc, f, mode) != 0) amt++;
            }
            best = Math.min(best, amt);
        }
        if (best == Integer.MAX_VALUE) return 0;
        int cap = Math.min(maxWidth(left), maxWidth(right));
        return Math.max(0, Math.min(best, cap));
    }

    static String[] merge(String[] left, String[] right, int ov, Font f, Opts o) {
        String[] out = new String[f.height];
        int mode = layout(f, o);
        for (int r = 0; r < f.height; r++) {
            String l = left[r], rr = right[r];
            int lw = l.length();
            ov = Math.max(0, Math.min(ov, Math.min(lw, rr.length())));
            StringBuilder sb = new StringBuilder();
            sb.append(l, 0, Math.min(l.length(), Math.max(0, lw - ov)));
            for (int i = 0; i < ov; i++) {
                char lc = charAt(l, lw - ov + i);
                char rc = charAt(rr, i);
                char c;
                if (lc == ' ') c = rc;
                else if (rc == ' ') c = lc;
                else if (o.spacing == Spacing.OVERLAP) c = rc;
                else {
                    char s = smushChar(lc, rc, f, mode);
                    c = s == 0 ? rc : s;
                }
                sb.append(c);
            }
            if (ov < rr.length()) sb.append(rr.substring(ov));
            out[r] = sb.toString();
        }
        return out;
    }

    static char charAt(String s, int idx) {
        if (idx < 0 || idx >= s.length()) return ' ';
        return s.charAt(idx);
    }

    static int leadingBlanks(String s) {
        int n = 0;
        while (n < s.length() && s.charAt(n) == ' ') n++;
        return n;
    }

    static int trailingBlanks(String s) {
        int n = 0;
        while (n < s.length() && s.charAt(s.length() - 1 - n) == ' ') n++;
        return n;
    }

    static boolean isSmush(Font f, Opts o) {
        if (o.spacing == Spacing.SMUSH || o.spacing == Spacing.FORCE_SMUSH) return true;
        if (o.spacing == Spacing.KERN || o.spacing == Spacing.FULL || o.spacing == Spacing.OVERLAP) return false;
        return f.oldLayout > 0 || (f.fullLayout & 128) != 0;
    }

    static int layout(Font f, Opts o) {
        if (o.explicitLayout != null && o.explicitLayout > 0) return o.explicitLayout;
        int m = f.layoutMode();
        if (m < 0) m = 0;
        return m;
    }

    static char smushChar(char a, char b, Font f, int mode) {
        if (a == ' ') return b;
        if (b == ' ') return a;
        if (a == f.hardblank && b == f.hardblank) return (mode & 32) != 0 ? f.hardblank : 0;
        if (a == f.hardblank || b == f.hardblank) return 0;
        if ((mode & 1) != 0 && a == b) return a;
        if ((mode & 2) != 0 && a == '_') return b;
        if ((mode & 2) != 0 && b == '_') return a;
        if ((mode & 4) != 0) {
            String h = "|/\\[]{}()<>";
            int ia = h.indexOf(a), ib = h.indexOf(b);
            if (ia >= 0 && ib >= 0) return ia > ib ? a : b;
        }
        if ((mode & 8) != 0) {
            if ((a == '[' && b == ']') || (a == ']' && b == '[') ||
                (a == '{' && b == '}') || (a == '}' && b == '{') ||
                (a == '(' && b == ')') || (a == ')' && b == '(')) return '|';
        }
        if ((mode & 16) != 0) {
            if (a == '/' && b == '\\') return '|';
            if (a == '\\' && b == '/') return 'Y';
            if (a == '>' && b == '<') return 'X';
        }
        if (mode == 0) return b;
        return 0;
    }

    static void flush(List<String> result, String[] rows, Font f, Opts o) {
        if (o.spacing != Spacing.FULL && !(o.spacing == Spacing.DEFAULT && f.oldLayout < 0)) {
            rows = trimCommonLeading(rows);
        }
        int w = maxWidth(rows);
        if (w == 0) return;
        Justify j = o.justify;
        if (j == Justify.AUTO) j = o.rtl ? Justify.RIGHT : Justify.LEFT;
        int pad = 0;
        if (o.width > w) {
            if (j == Justify.RIGHT) pad = o.width - w;
            else if (j == Justify.CENTER) pad = (o.width - w) / 2;
        }
        String p = repeat(' ', pad);
        for (String row : rows) result.add(p + row.replace(f.hardblank, ' '));
    }

    static String[] trimCommonLeading(String[] rows) {
        int common = Integer.MAX_VALUE;
        for (String row : rows) {
            if (row.isEmpty()) continue;
            common = Math.min(common, leadingBlanks(row));
        }
        if (common == Integer.MAX_VALUE || common <= 0) return rows;
        String[] out = new String[rows.length];
        for (int i = 0; i < rows.length; i++) {
            out[i] = rows[i].length() >= common ? rows[i].substring(common) : "";
        }
        return out;
    }

    static int maxWidth(String[] rows) {
        int m = 0;
        for (String s : rows) m = Math.max(m, s.length());
        return m;
    }

    static String repeat(char c, int n) {
        if (n <= 0) return "";
        char[] a = new char[n];
        Arrays.fill(a, c);
        return new String(a);
    }

    static String readAllStdin() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = System.in.read(buf)) >= 0) baos.write(buf, 0, n);
        return baos.toString(StandardCharsets.UTF_8);
    }

    static String paragraphize(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n') {
                char prev = i > 0 ? s.charAt(i - 1) : '\n';
                char next = i + 1 < s.length() ? s.charAt(i + 1) : '\n';
                out.append(prev != '\n' && next != ' ' && next != '\n' ? ' ' : '\n');
            } else out.append(c);
        }
        return out.toString();
    }

    static String germanMap(String s) {
        return s.replace('[', 'Ä').replace('\\', 'Ö').replace(']', 'Ü')
                .replace('{', 'ä').replace('|', 'ö').replace('}', 'ü')
                .replace('~', 'ß');
    }

    static String stripSuffix(String s) {
        if (s.endsWith(".flf") || s.endsWith(".tlf")) return s.substring(0, s.length() - 4);
        return s;
    }

    static class FigletException extends Exception {
        FigletException(String m) { super(m); }
    }
}
