package sgrep;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Stream;

public class Main {
  static final String VERSION = "ast-grep 0.42.1";

  public static void main(String[] args) {
    try {
      int code = new Main().run(args);
      System.exit(code);
    } catch (Exception e) {
      System.err.println("ERROR: " + e.getMessage());
      System.exit(1);
    }
  }

  int run(String[] argv) throws Exception {
    List<String> args = new ArrayList<>(Arrays.asList(argv));
    if (args.isEmpty()) return help();
    if (has(args, "-V") || has(args, "--version")) {
      System.out.println(VERSION);
      return 0;
    }
    if (has(args, "-h") || has(args, "--help")) {
      String cmd = firstCommand(args);
      if ("run".equals(cmd)) return runHelp();
      if ("scan".equals(cmd)) return scanHelp();
      if ("test".equals(cmd)) return testHelp();
      return help();
    }
    String cmd = "";
    if (!args.isEmpty() && !args.get(0).startsWith("-")) {
      String a = args.get(0);
      if (Set.of("run", "scan", "test", "new", "lsp", "completions", "help").contains(a)) {
        cmd = args.remove(0);
      }
    }
    if (cmd.isEmpty() || "run".equals(cmd)) return runSearch(args, null);
    if ("scan".equals(cmd)) return runScan(args);
    if ("test".equals(cmd)) {
      System.out.println("No tests found");
      return 0;
    }
    if ("new".equals(cmd)) {
      System.out.println("ast-grep project scaffolding is not available in this reimplementation.");
      return 0;
    }
    if ("completions".equals(cmd)) return 0;
    if ("help".equals(cmd)) return help();
    return help();
  }

  int runSearch(List<String> args, Rule forcedRule) throws Exception {
    Options opt = parseOptions(args, false);
    Rule rule = forcedRule != null ? forcedRule : new Rule("command-line", opt.pattern, opt.rewrite, "hint", "Match found");
    if (rule.pattern == null || rule.pattern.isEmpty()) {
      System.err.println("error: the following required arguments were not provided:");
      System.err.println("  --pattern <PATTERN>");
      return 2;
    }
    if (opt.debugQuery != null) {
      System.out.println(rule.pattern);
      return 0;
    }
    PatternEngine engine = new PatternEngine(rule.pattern);
    List<Match> matches = new ArrayList<>();
    if (opt.stdin) {
      String text = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
      collectMatches("<stdin>", text, engine, matches, opt);
    } else {
      for (Path p : collectFiles(opt.paths, opt.lang, opt.globs)) {
        String text = Files.readString(p);
        collectMatches(displayPath(p), text, engine, matches, opt);
        if (opt.maxResults > 0 && matches.size() >= opt.maxResults) break;
      }
    }
    if (opt.updateAll && rule.rewrite != null) {
      int changed = applyRewrites(opt, engine, rule.rewrite);
      System.out.println("Applied " + changed + " changes");
      return 0;
    }
    if (opt.filesWithMatches) {
      LinkedHashSet<String> files = new LinkedHashSet<>();
      for (Match m : matches) files.add(m.file);
      files.forEach(System.out::println);
      return files.isEmpty() ? 1 : 0;
    }
    if (opt.json != null) {
      printJson(matches, opt.json);
      return matches.isEmpty() ? 1 : 0;
    }
    printText(matches, opt);
    return matches.isEmpty() ? 1 : 0;
  }

  int runScan(List<String> args) throws Exception {
    Options opt = parseOptions(args, true);
    List<Rule> rules = new ArrayList<>();
    if (opt.ruleFile != null) rules.add(parseRule(Files.readString(Path.of(opt.ruleFile))));
    if (opt.inlineRules != null) {
      for (String part : opt.inlineRules.split("(?m)^---\\s*$")) rules.add(parseRule(part));
    }
    if (rules.isEmpty()) {
      Path cfg = Path.of(opt.config == null ? "sgconfig.yml" : opt.config);
      if (Files.exists(cfg)) {
        String c = Files.readString(cfg);
        Matcher m = Pattern.compile("(?m)^\\s*ruleDirs:\\s*\\n((?:\\s*-\\s*.+\\n?)+)").matcher(c);
        if (m.find()) {
          for (String line : m.group(1).split("\\R")) {
            String dir = line.replaceFirst("^\\s*-\\s*", "").trim();
            if (!dir.isEmpty()) try (Stream<Path> s = Files.walk(Path.of(dir))) {
              s.filter(Files::isRegularFile).filter(p -> p.toString().endsWith(".yml") || p.toString().endsWith(".yaml"))
                  .forEach(p -> { try { rules.add(parseRule(Files.readString(p))); } catch(Exception ignored) {} });
            }
          }
        }
      }
    }
    if (rules.isEmpty()) return 0;
    int total = 0;
    for (Rule r : rules) {
      if ("off".equalsIgnoreCase(r.severity)) continue;
      List<String> a = new ArrayList<>();
      if (r.lang != null && opt.lang == null) { a.add("-l"); a.add(r.lang); }
      if (opt.stdin) a.add("--stdin");
      if (opt.json != null) a.add("--json=" + opt.json);
      if (opt.filesWithMatches) a.add("--files-with-matches");
      for (String p : opt.paths) a.add(p);
      Options ro = parseOptions(a, false);
      if (opt.paths != null && !opt.paths.isEmpty()) ro.paths = opt.paths;
      ro.stdin = opt.stdin; ro.json = opt.json; ro.filesWithMatches = opt.filesWithMatches;
      PatternEngine engine = new PatternEngine(r.pattern);
      if (opt.updateAll && r.rewrite != null) {
        ro.updateAll = true;
        int changed = applyRewrites(ro, engine, r.rewrite);
        System.out.println("Applied " + changed + " changes");
        total += changed;
        continue;
      }
      List<Match> ms = new ArrayList<>();
      for (Path p : collectFiles(ro.paths, r.lang, ro.globs)) collectMatches(displayPath(p), Files.readString(p), engine, ms, ro);
      for (Match m : ms) {
        System.out.println(m.file + ":" + (m.line + 1) + ":" + (m.col + 1) + ": " + r.severity + "[" + r.id + "]: " + r.message);
        System.out.println(m.lineText);
      }
      total += ms.size();
    }
    return total == 0 ? 1 : 0;
  }

  Options parseOptions(List<String> args, boolean scanMode) {
    Options o = new Options();
    for (int i = 0; i < args.size(); i++) {
      String a = args.get(i);
      if ("-p".equals(a) || "--pattern".equals(a)) o.pattern = args.get(++i);
      else if (a.startsWith("--pattern=")) o.pattern = a.substring(10);
      else if (!scanMode && ("-r".equals(a) || "--rewrite".equals(a))) o.rewrite = args.get(++i);
      else if (!scanMode && a.startsWith("--rewrite=")) o.rewrite = a.substring(10);
      else if ("-l".equals(a) || "--lang".equals(a)) o.lang = args.get(++i);
      else if (a.startsWith("--lang=")) o.lang = a.substring(7);
      else if ("-c".equals(a) || "--config".equals(a)) o.config = args.get(++i);
      else if (a.startsWith("--config=")) o.config = a.substring(9);
      else if ("--stdin".equals(a)) o.stdin = true;
      else if ("-U".equals(a) || "--update-all".equals(a)) o.updateAll = true;
      else if ("--files-with-matches".equals(a)) o.filesWithMatches = true;
      else if (a.equals("--json")) o.json = "pretty";
      else if (a.startsWith("--json=")) o.json = a.substring(7).isEmpty() ? "pretty" : a.substring(7);
      else if (a.equals("--debug-query")) o.debugQuery = "pattern";
      else if (a.startsWith("--debug-query=")) o.debugQuery = a.substring(14);
      else if ("--color".equals(a) || "--heading".equals(a) || "--strictness".equals(a) || "--selector".equals(a) || "--inspect".equals(a) || "--no-ignore".equals(a) || "-j".equals(a) || "--threads".equals(a)) {
        if ("--heading".equals(a)) o.heading = args.get(i + 1);
        i++;
      } else if ("-A".equals(a) || "--after".equals(a)) o.after = Integer.parseInt(args.get(++i));
      else if ("-B".equals(a) || "--before".equals(a)) o.before = Integer.parseInt(args.get(++i));
      else if ("-C".equals(a) || "--context".equals(a)) { int n = Integer.parseInt(args.get(++i)); o.after = n; o.before = n; }
      else if ("--globs".equals(a)) o.globs.add(args.get(++i));
      else if (a.startsWith("--globs=")) o.globs.add(a.substring(8));
      else if ("--max-results".equals(a)) o.maxResults = Integer.parseInt(args.get(++i));
      else if (a.startsWith("--max-results=")) o.maxResults = Integer.parseInt(a.substring(14));
      else if (scanMode && ("--rule".equals(a) || "-r".equals(a))) o.ruleFile = args.get(++i);
      else if (a.startsWith("--rule=")) o.ruleFile = a.substring(7);
      else if ("--inline-rules".equals(a)) o.inlineRules = args.get(++i);
      else if (a.startsWith("--inline-rules=")) o.inlineRules = a.substring(15);
      else if ("--format".equals(a) || "--report-style".equals(a) || "--filter".equals(a)) i++;
      else if (!a.startsWith("-")) o.paths.add(a);
    }
    if (o.paths.isEmpty()) o.paths.add(".");
    return o;
  }

  void collectMatches(String file, String text, PatternEngine engine, List<Match> out, Options opt) {
    String[] lines = text.split("\\R", -1);
    int byteOffset = 0;
    for (int i = 0; i < lines.length; i++) {
      String line = lines[i];
      Matcher m = engine.regex.matcher(line);
      while (m.find()) {
        Match mm = new Match(file, i, m.start(), m.end(), line, m.group(), byteOffset + m.start(), byteOffset + m.end());
        for (String name : engine.names) {
          try { String v = m.group(name); if (v != null) mm.vars.put(name, v); } catch (Exception ignored) {}
        }
        out.add(mm);
        if (opt.maxResults > 0 && out.size() >= opt.maxResults) return;
      }
      byteOffset += line.getBytes(StandardCharsets.UTF_8).length + 1;
    }
  }

  int applyRewrites(Options opt, PatternEngine engine, String rewrite) throws IOException {
    int count = 0;
    if (opt.stdin) return 0;
    for (Path p : collectFiles(opt.paths, opt.lang, opt.globs)) {
      String old = Files.readString(p);
      String[] lines = old.split("\\R", -1);
      boolean changed = false;
      for (int i = 0; i < lines.length; i++) {
        Matcher m = engine.regex.matcher(lines[i]);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
          Map<String,String> vars = new HashMap<>();
          for (String n : engine.names) try { vars.put(n, m.group(n)); } catch(Exception ignored) {}
          m.appendReplacement(sb, Matcher.quoteReplacement(expand(rewrite, vars)));
          count++; changed = true;
        }
        m.appendTail(sb);
        lines[i] = sb.toString();
      }
      if (changed) Files.writeString(p, String.join(System.lineSeparator(), lines));
    }
    return count;
  }

  static String expand(String rewrite, Map<String,String> vars) {
    Matcher m = Pattern.compile("\\$([A-Z_][A-Z0-9_]*)").matcher(rewrite);
    StringBuffer sb = new StringBuffer();
    while (m.find()) m.appendReplacement(sb, Matcher.quoteReplacement(vars.getOrDefault(m.group(1), "")));
    m.appendTail(sb);
    return sb.toString();
  }

  List<Path> collectFiles(List<String> paths, String lang, List<String> globs) throws IOException {
    List<Path> files = new ArrayList<>();
    for (String s : paths) {
      Path p = Path.of(s);
      if (!Files.exists(p)) throw new NoSuchFileException(s);
      if (Files.isRegularFile(p)) files.add(p);
      else if (Files.isDirectory(p)) try (Stream<Path> st = Files.walk(p)) {
        st.filter(Files::isRegularFile).filter(x -> !hidden(x)).filter(x -> lang == null || languageOk(x, lang)).forEach(files::add);
      }
    }
    files.sort(Comparator.comparing(Path::toString));
    return files;
  }

  boolean languageOk(Path p, String lang) {
    String f = p.getFileName().toString().toLowerCase(Locale.ROOT);
    lang = lang.toLowerCase(Locale.ROOT);
    return switch (lang) {
      case "js", "javascript" -> f.endsWith(".js") || f.endsWith(".jsx") || f.endsWith(".mjs") || f.endsWith(".cjs");
      case "ts", "typescript" -> f.endsWith(".ts") || f.endsWith(".tsx");
      case "tsx" -> f.endsWith(".tsx");
      case "py", "python" -> f.endsWith(".py");
      case "java" -> f.endsWith(".java");
      case "go" -> f.endsWith(".go");
      case "rs", "rust" -> f.endsWith(".rs");
      case "c" -> f.endsWith(".c") || f.endsWith(".h");
      case "cpp", "c++" -> f.endsWith(".cc") || f.endsWith(".cpp") || f.endsWith(".cxx") || f.endsWith(".hpp") || f.endsWith(".h");
      default -> true;
    };
  }

  boolean hidden(Path p) {
    for (Path part : p) if (part.toString().startsWith(".") && !part.toString().equals(".")) return true;
    return false;
  }

  static String displayPath(Path p) { return p.toString(); }

  void printText(List<Match> matches, Options opt) {
    Map<String,List<Match>> byFile = new LinkedHashMap<>();
    for (Match m : matches) byFile.computeIfAbsent(m.file, k -> new ArrayList<>()).add(m);
    boolean heading = "always".equals(opt.heading);
    for (var e : byFile.entrySet()) {
      if (heading) System.out.println(e.getKey());
      Set<Integer> printed = new TreeSet<>();
      for (Match m : e.getValue()) {
        int start = Math.max(0, m.line - opt.before), end = m.line + opt.after;
        for (int l = start; l <= end; l++) printed.add(l);
      }
      String[] lines = null;
      try { lines = Files.readString(Path.of(e.getKey())).split("\\R", -1); } catch(Exception ignored) {}
      for (int l : printed) {
        String text = null;
        for (Match m : e.getValue()) if (m.line == l) text = m.lineText;
        if (text == null && lines != null && l < lines.length) text = lines[l];
        if (text == null) continue;
        if (heading) System.out.println((l + 1) + "│" + text);
        else System.out.println(e.getKey() + ":" + (l + 1) + ":" + text);
      }
      if (heading) System.out.println();
    }
  }

  void printJson(List<Match> matches, String style) {
    if ("stream".equals(style)) {
      for (Match m : matches) System.out.println(jsonObj(m));
    } else if ("compact".equals(style)) {
      System.out.println("[" + joinJson(matches) + "]");
    } else {
      System.out.println("[");
      for (int i = 0; i < matches.size(); i++) {
        System.out.print(pretty(jsonObj(matches.get(i))));
        if (i + 1 < matches.size()) System.out.println(",");
        else System.out.println();
      }
      System.out.println("]");
    }
  }

  String joinJson(List<Match> ms) {
    List<String> xs = new ArrayList<>();
    for (Match m : ms) xs.add(jsonObj(m));
    return String.join(",", xs);
  }

  String jsonObj(Match m) {
    StringBuilder meta = new StringBuilder("{\"single\":{");
    int i = 0;
    for (var e : m.vars.entrySet()) {
      if (i++ > 0) meta.append(',');
      meta.append(q(e.getKey())).append(":{\"text\":").append(q(e.getValue())).append("}");
    }
    meta.append("},\"multi\":{},\"transformed\":{}}");
    return "{\"text\":" + q(m.text) + ",\"range\":{\"byteOffset\":{\"start\":" + m.byteStart + ",\"end\":" + m.byteEnd + "},\"start\":{\"line\":" + m.line + ",\"column\":" + m.col + "},\"end\":{\"line\":" + m.line + ",\"column\":" + (m.endCol) + "}},\"file\":" + q(m.file) + ",\"lines\":" + q(m.lineText) + ",\"charCount\":{\"leading\":" + m.col + ",\"trailing\":0},\"language\":\"" + "Unknown" + "\",\"metaVariables\":" + meta + "}";
  }

  static String pretty(String s) { return s.replace("{", "{\n  ").replace(",", ",\n  ").replace("}", "\n}"); }
  static String q(String s) { return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t") + "\""; }

  Rule parseRule(String text) {
    Rule r = new Rule(val(text, "id", "rule"), val(text, "pattern", null), val(text, "fix", null), val(text, "severity", "hint"), val(text, "message", "Match found"));
    r.lang = val(text, "language", val(text, "lang", null));
    if (r.pattern == null) {
      Matcher m = Pattern.compile("(?s)rule:\\s*.*?pattern:\\s*['\"]?([^'\"\\n]+)").matcher(text);
      if (m.find()) r.pattern = m.group(1).trim();
    }
    return r;
  }

  static String val(String text, String key, String def) {
    Matcher m = Pattern.compile("(?m)^\\s*" + Pattern.quote(key) + "\\s*:\\s*(.+?)\\s*$").matcher(text);
    if (!m.find()) return def;
    String v = m.group(1).trim();
    if ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) v = v.substring(1, v.length()-1);
    return v;
  }

  boolean has(List<String> a, String x) { return a.contains(x); }
  String firstCommand(List<String> a) { for (String s : a) if (!s.startsWith("-")) return s; return ""; }

  int help() {
    System.out.println("Search and Rewrite code at large scale using AST pattern.");
    System.out.println("Usage: executable [OPTIONS] <COMMAND>");
    System.out.println("Commands:\n  run\n  scan\n  test\n  new\n  lsp\n  completions\n  help");
    System.out.println("Options:\n  -c, --config <CONFIG_FILE>\n  -h, --help\n  -V, --version");
    return 0;
  }
  int runHelp() { System.out.println("Run one time search or rewrite in command line. (default command)\n\nUsage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]..."); return 0; }
  int scanHelp() { System.out.println("Scan and rewrite code by configuration\n\nUsage: executable scan [OPTIONS] [PATHS]..."); return 0; }
  int testHelp() { System.out.println("Test ast-grep rules\n\nUsage: executable test [OPTIONS]"); return 0; }

  static class Options {
    String pattern, rewrite, lang, config, json, heading = "never", ruleFile, inlineRules, debugQuery;
    boolean stdin, updateAll, filesWithMatches;
    int before, after, maxResults;
    List<String> paths = new ArrayList<>(), globs = new ArrayList<>();
  }

  static class Rule {
    String id, pattern, rewrite, severity, message, lang;
    Rule(String id, String p, String rw, String sev, String msg) { this.id=id; pattern=p; rewrite=rw; severity=sev; message=msg; }
  }

  static class Match {
    String file, lineText, text; int line, col, endCol, byteStart, byteEnd; Map<String,String> vars = new LinkedHashMap<>();
    Match(String f, int l, int c, int e, String lt, String t, int bs, int be) { file=f; line=l; col=c; endCol=e; lineText=lt; text=t; byteStart=bs; byteEnd=be; }
  }

  static class PatternEngine {
    Pattern regex; List<String> names = new ArrayList<>();
    PatternEngine(String pattern) {
      StringBuilder r = new StringBuilder();
      for (int i = 0; i < pattern.length();) {
        char c = pattern.charAt(i);
        if (Character.isWhitespace(c)) { r.append("\\s+"); while (i < pattern.length() && Character.isWhitespace(pattern.charAt(i))) i++; continue; }
        if (c == '$' && i + 1 < pattern.length() && (Character.isUpperCase(pattern.charAt(i+1)) || pattern.charAt(i+1) == '_')) {
          int j = i + 2;
          while (j < pattern.length() && (Character.isUpperCase(pattern.charAt(j)) || Character.isDigit(pattern.charAt(j)) || pattern.charAt(j) == '_')) j++;
          String name = pattern.substring(i + 1, j);
          if (!names.contains(name)) {
            names.add(name);
            r.append("(?<").append(name).append(">.+?)");
          } else {
            r.append("\\k<").append(name).append(">");
          }
          i = j; continue;
        }
        if ("()[]{}.+*?^$|\\".indexOf(c) >= 0) r.append('\\');
        r.append(c);
        i++;
      }
      regex = Pattern.compile(r.toString());
    }
  }
}
