package masscanclone;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.regex.*;

public class Main {
    static class Range implements Comparable<Range> {
        long start, end;
        Range(long s,long e){start=s;end=e; if(start>end){long t=start;start=end;end=t;}}
        public int compareTo(Range o){int c=Long.compareUnsigned(start,o.start); return c!=0?c:Long.compareUnsigned(end,o.end);}        
    }
    static class Config {
        boolean help,nmap,version,echo,selftest,iflist,packetTrace,banners,open,append,offline;
        int verbosity=0, debug=0;
        String ports="";
        String rate="100";
        String shard="1/1";
        String adapterIp, adapterMac, routerMac, sourceIp, sourcePort, outputFormat, outputFilename, readscan, resume;
        String ttl, wait, connectionTimeout, spoofMac, iface;
        List<String> nocapture = new ArrayList<>(Arrays.asList("servername","servername"));
        List<Range> ranges = new ArrayList<>();
        List<Range> excludes = new ArrayList<>();
        List<String> ipv6Ranges = new ArrayList<>();
        List<String> errors = new ArrayList<>();
    }

    static final String SHORT_HELP = "usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]\n"+
"\n"+
"examples:\n"+
"    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000\n"+
"        scan some web ports on 10.x.x.x at 10kpps\n"+
"\n"+
"    masscan --nmap\n"+
"        list those options that are compatible with nmap\n"+
"\n"+
"    masscan -p80 10.0.0.0/8 --banners -oB <filename>\n"+
"        save results of scan in binary format to <filename>\n"+
"\n"+
"    masscan --open --banners --readscan <filename> -oX <savefile>\n"+
"        read binary scan results in <filename> and save them as xml in <savefile>\n";

    static final String LONG_HELP = "usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]\n"+
"MASSCAN is a fast port scanner. The primary input parameters are the\n"+
"IP addresses/ranges you want to scan, and the port numbers. An example\n"+
"is the following, which scans the 10.x.x.x network for web servers:\n"+
"\n"+
"    masscan 10.0.0.0/8 -p80\n"+
"\n"+
"The program auto-detects network interface/adapter settings. If this\n"+
"fails, you'll have to set these manually. The following is an\n"+
"example of all the parameters that are needed:\n"+
"\n"+
"    --adapter-ip 192.168.10.123\n"+
"    --adapter-mac 00-11-22-33-44-55\n"+
"    --router-mac 66-55-44-33-22-11\n"+
"\n"+
"Parameters can be set either via the command-line or config-file. The\n"+
"names are the same for both. Thus, the above adapter settings would\n"+
"appear as follows in a configuration file:\n"+
"\n"+
"    adapter-ip = 192.168.10.123\n"+
"    adapter-mac = 00-11-22-33-44-55\n"+
"    router-mac = 66-55-44-33-22-11\n"+
"\n"+
"All single-dash parameters have a spelled out double-dash equivalent,\n"+
"so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).\n"+
"To use the config file, type:\n"+
"\n"+
"    masscan -c <filename>\n"+
"\n"+
"To generate a config-file from the current settings, use the --echo\n"+
"option. This stops the program from actually running, and just echoes\n"+
"the current configuration instead. This is a useful way to generate\n"+
"your first config file, or see a list of parameters you didn't know\n"+
"about. I suggest you try it now:\n"+
"\n"+
"    masscan -p1234 --echo\n";

    static final String NMAP = "Masscan (https://github.com/robertdavidgraham/masscan)\n"+
"Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}\n"+
"TARGET SPECIFICATION:\n"+
"  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)\n"+
"  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254\n"+
"  -iL <inputfilename>: Input from list of hosts/networks\n"+
"  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks\n"+
"  --excludefile <exclude_file>: Exclude list from file\n"+
"  --randomize-hosts: Randomize order of hosts (default)\n"+
"HOST DISCOVERY:\n"+
"  -Pn: Treat all hosts as online (default)\n"+
"  -n: Never do DNS resolution (default)\n"+
"SCAN TECHNIQUES:\n"+
"  -sS: TCP SYN (always on, default)\n"+
"SERVICE/VERSION DETECTION:\n"+
"  --banners: get the banners of the listening service if available. The\n"+
"    default timeout for waiting to receive data is 30 seconds.\n"+
"PORT SPECIFICATION AND SCAN ORDER:\n"+
"  -p <port ranges>: Only scan specified ports\n"+
"    Ex: -p22; -p1-65535; -p 111,137,80,139,8080\n"+
"TIMING AND PERFORMANCE:\n"+
"  --max-rate <number>: Send packets no faster than <number> per second\n"+
"  --connection-timeout <number>: time in seconds a TCP connection will\n"+
"    timeout while waiting for banner data from a port.\n"+
"FIREWALL/IDS EVASION AND SPOOFING:\n"+
"  -S/--source-ip <IP_Address>: Spoof source address\n"+
"  -e <iface>: Use specified interface\n"+
"  -g/--source-port <portnum>: Use given port number\n"+
"  --ttl <val>: Set IP time-to-live field\n"+
"  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address\n"+
"OUTPUT:\n"+
"  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml\n"+
"  --output-file <file>: Write scan results to file. If --output-format is\n"+
"     not given default is xml\n"+
"  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,\n"+
"     respectively, to the given filename. Shortcut for\n"+
"     --output-format <format> --output-file <file>\n"+
"  -v: Increase verbosity level (use -vv or more for greater effect)\n"+
"  -d: Increase debugging level (use -dd or more for greater effect)\n"+
"  --open: Only show open (or possibly open) ports\n"+
"  --packet-trace: Show all packets sent and received\n"+
"  --iflist: Print host interfaces and routes (for debugging)\n"+
"  --append-output: Append to rather than clobber specified output files\n"+
"  --resume <filename>: Resume an aborted scan\n"+
"MISC:\n"+
"  --send-eth: Send using raw ethernet frames (default)\n"+
"  -V: Print version number\n"+
"  -h: Print this help summary page.\n"+
"EXAMPLES:\n"+
"  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80\n"+
"  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan\n"+
"  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable\n"+
"SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP\n";

    public static void main(String[] args) {
        Config c = new Config();
        parseArgs(c, new ArrayList<>(Arrays.asList(args)), false);
        if (c.version) { version(); return; }
        if (c.nmap) { System.out.print(NMAP); return; }
        if (c.selftest) { pcapFail(); System.out.println("regression test: success!"); return; }
        if (c.iflist) { pcapFail(); System.out.println("libpcap not loaded"); return; }
        if (c.help) { System.out.print(args.length>0 && "--help".equals(args[0]) ? LONG_HELP : SHORT_HELP); return; }
        if (!c.errors.isEmpty()) { for(String e:c.errors) System.out.println(e); pcapFail(); System.out.print(SHORT_HELP); return; }
        if (c.echo) { pcapFail(); echo(c); return; }
        pcapFail();
        if (c.readscan != null) { doReadscan(c); return; }
        if (c.ports.isEmpty()) {
            if (c.ranges.isEmpty() && c.ipv6Ranges.isEmpty()) System.out.print(SHORT_HELP);
            else { System.out.println("FAIL: no ports were specified"); System.out.println(" [hint] try something like \"-p80,8000-9000\""); System.out.println(" [hint] try something like \"--ports 0-65535\""); }
            return;
        }
        if (c.ranges.isEmpty() && c.ipv6Ranges.isEmpty()) {
            System.out.println("FAIL: target IP address list empty");
            System.out.println(" [hint] try something like \"--range 10.0.0.0/8\"");
            System.out.println(" [hint] try something like \"--range 192.168.0.100-192.168.0.200\"");
            return;
        }
        if (c.offline || "0".equals(c.wait)) {
            writeOutput(c);
        } else {
            System.out.println("FAIL: failed to initialize adapter");
        }
    }

    static void version(){
        System.out.println();
        System.out.println("Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )");
        System.out.println("Compiled on: Apr 17 2026 19:59:25");
        System.out.println("Compiler: gcc 11.4.0");
        System.out.println("OS: Linux");
        System.out.println("CPU: x86 (64 bits)");
        System.out.println("GIT version: unknown");
    }
    static void pcapFail(){ System.out.println("[-] FAIL: failed to load libpcap shared library"); System.out.println("    [hint]: you must install libpcap or WinPcap"); }

    static void parseArgs(Config c, List<String> args, boolean fromConfig) {
        for (int i=0;i<args.size();i++) {
            String a=args.get(i);
            if (a==null || a.isEmpty()) continue;
            String opt=a, val=null;
            int eq=a.indexOf('=');
            if (eq>=0) { opt=a.substring(0,eq); val=a.substring(eq+1); }
            if (!fromConfig && opt.startsWith("--") && opt.length()>2) opt=opt.substring(2);
            else if (!fromConfig && opt.startsWith("-") && opt.length()>1) {
                if ("-V".equals(opt)) { c.version=true; continue; }
                if (opt.matches("-[vd]+")) { for(int k=1;k<opt.length();k++){ if(opt.charAt(k)=='v')c.verbosity++; else c.debug++; } continue; }
                if (opt.startsWith("-p") && opt.length()>2) { c.ports=opt.substring(2); continue; }
                String s=opt.substring(1);
                if (s.startsWith("o") && s.length()>1) { String f=formatFor(s.charAt(1)); if (f!=null){ c.outputFormat=f; c.outputFilename=needVal(c,args,++i,s); continue; } }
                opt=s;
            }
            String lower=opt.toLowerCase(Locale.ROOT);
            switch(lower) {
                case "h": case "?": c.help=true; break;
                case "help": c.help=true; break;
                case "v": c.verbosity++; break;
                case "d": c.debug++; break;
                case "version": case "vversion": case "V": c.version=true; break;
                case "nmap": c.nmap=true; break;
                case "selftest": case "regress": c.selftest=true; break;
                case "iflist": c.iflist=true; break;
                case "echo": case "echo-all": c.echo=true; break;
                case "banners": c.banners=true; break;
                case "open": c.open=true; break;
                case "append-output": c.append=true; break;
                case "packet-trace": c.packetTrace=true; break;
                case "offline": c.offline=true; break;
                case "send-eth": System.out.println("nmap(send-eth): unnecessary, we always do --send-eth"); break;
                case "randomize-hosts": case "pn": case "n": case "ss": case "ping": break;
                case "p": case "ports": c.ports=val!=null?val:needVal(c,args,++i,lower); break;
                case "rate": case "max-rate": c.rate=val!=null?val:needVal(c,args,++i,lower); break;
                case "shard": c.shard=val!=null?val:needVal(c,args,++i,lower); break;
                case "adapter-ip": c.adapterIp=val!=null?val:needVal(c,args,++i,lower); break;
                case "adapter-mac": c.adapterMac=normMac(val!=null?val:needVal(c,args,++i,lower)); break;
                case "router-mac": case "router-mac-ipv4": case "router-mac-ipv6": c.routerMac=normMac(val!=null?val:needVal(c,args,++i,lower)); break;
                case "adapter-port": case "source-port": case "g": c.sourcePort=val!=null?val:needVal(c,args,++i,lower); break;
                case "source-ip": case "s": c.sourceIp=val!=null?val:needVal(c,args,++i,lower); break;
                case "e": case "adapter": case "interface": c.iface=val!=null?val:needVal(c,args,++i,lower); break;
                case "ttl": c.ttl=val!=null?val:needVal(c,args,++i,lower); break;
                case "wait": c.wait=val!=null?val:needVal(c,args,++i,lower); break;
                case "connection-timeout": c.connectionTimeout=val!=null?val:needVal(c,args,++i,lower); break;
                case "spoof-mac": c.spoofMac=val!=null?val:needVal(c,args,++i,lower); break;
                case "output-format": c.outputFormat=val!=null?val:needVal(c,args,++i,lower); break;
                case "output-file": case "output-filename": c.outputFilename=val!=null?val:needVal(c,args,++i,lower); break;
                case "readscan": c.readscan=val!=null?val:needVal(c,args,++i,lower); break;
                case "resume": c.resume=val!=null?val:needVal(c,args,++i,lower); break;
                case "range": addTarget(c, val!=null?val:needVal(c,args,++i,lower)); break;
                case "exclude": addExcludeList(c, val!=null?val:needVal(c,args,++i,lower)); break;
                case "excludefile": readTargetsFile(c, val!=null?val:needVal(c,args,++i,lower), true); break;
                case "il": case "iL": case "include-file": case "includefile": readTargetsFile(c, val!=null?val:needVal(c,args,++i,lower), false); break;
                case "c": case "conf": case "config": readConfig(c, val!=null?val:needVal(c,args,++i,lower)); break;
                default:
                    if (!fromConfig && (a.contains(".") || a.contains(":") || a.contains("/") || a.contains("-")) && !a.startsWith("-")) addTarget(c,a);
                    else if (!fromConfig) { System.out.println("FAIL: unknown command-line parameter \""+a+"\""); System.out.println(" [hint] did you want \"--"+a+"\"?"); }
                    break;
            }
        }
    }
    static String needVal(Config c,List<String> args,int idx,String name){ if(idx>=args.size()){ c.errors.add(name+": empty parameter"); return "";} return args.get(idx); }
    static String formatFor(char ch){ switch(ch){case 'X':return"xml";case 'G':return"grepable";case 'J':return"json";case 'D':return"ndjson";case 'B':return"binary";case 'L':return"list";case 'U':return"unicornscan";default:return null;} }
    static String normMac(String s){ return s==null?null:s.replace(':','-').toLowerCase(Locale.ROOT); }

    static void readConfig(Config c, String file){
        try { for(String line:Files.readAllLines(Paths.get(file))) {
            int hash=line.indexOf('#'); if(hash>=0) line=line.substring(0,hash); line=line.trim(); if(line.isEmpty()) continue;
            String key, val=""; int eq=line.indexOf('=');
            if(eq>=0){key=line.substring(0,eq).trim(); val=line.substring(eq+1).trim();}
            else {String[] p=line.split("\\s+",2); key=p[0]; if(p.length>1)val=p[1];}
            parseArgs(c, new ArrayList<>(Arrays.asList(key+"="+val)), true);
        }} catch(IOException e){ System.out.println("[-] "+file+": No such file or directory"); }
    }
    static void readTargetsFile(Config c,String file,boolean excl){
        try { for(String line:Files.readAllLines(Paths.get(file))) { int h=line.indexOf('#'); if(h>=0) line=line.substring(0,h); line=line.trim(); if(line.isEmpty()) continue; if(excl) addExcludeList(c,line); else addTarget(c,line); }}
        catch(IOException e){ System.out.println("[-] "+file+": No such file or directory"); }
    }
    static void addExcludeList(Config c,String s){ for(String part:s.split(",")){ part=part.trim(); if(part.isEmpty())continue; Range r=parseRange(part); if(r!=null)c.excludes.add(r); }}
    static void addTarget(Config c,String s){ if(s==null)return; for(String part:s.split(",")){ part=part.trim(); if(part.isEmpty())continue; if(part.contains(":")){ c.ipv6Ranges.add(part); continue;} Range r=parseRange(part); if(r!=null)c.ranges.add(r); else c.ipv6Ranges.add(part); }}

    static Range parseRange(String s){
        try {
            if (s.contains("/")) { String[] p=s.split("/",2); long ip=ipToLong(p[0]); int bits=Integer.parseInt(p[1]); long mask=bits==0?0:((-1L) << (32-bits)) & 0xffffffffL; long st=ip & mask; long size=bits==32?1:(1L << (32-bits)); return new Range(st, st+size-1); }
            int dash=s.indexOf('-'); if(dash>0){ return new Range(ipToLong(s.substring(0,dash)), ipToLong(s.substring(dash+1))); }
            return new Range(ipToLong(s), ipToLong(s));
        } catch(Exception e){ return null; }
    }
    static long ipToLong(String ip){ String[] p=ip.trim().split("\\."); if(p.length!=4) throw new IllegalArgumentException(); long v=0; for(String x:p){int n=Integer.parseInt(x); if(n<0||n>255)throw new IllegalArgumentException(); v=(v<<8)|n;} return v&0xffffffffL; }
    static String longToIp(long v){ return ((v>>>24)&255)+"."+((v>>>16)&255)+"."+((v>>>8)&255)+"."+(v&255); }
    static String rangeString(Range r){
        long len=r.end-r.start+1; if(r.start==r.end) return longToIp(r.start);
        if(len>0 && (len & (len-1))==0 && (r.start % len)==0) { int bits=32-Long.numberOfTrailingZeros(len); return longToIp(r.start)+"/"+bits; }
        return longToIp(r.start)+"-"+longToIp(r.end);
    }
    static List<Range> finalRanges(Config c){
        List<Range> rs=new ArrayList<>(c.ranges); Collections.sort(rs); List<Range> merged=new ArrayList<>();
        for(Range r:rs){ if(merged.isEmpty()||r.start>merged.get(merged.size()-1).end+1) merged.add(new Range(r.start,r.end)); else merged.get(merged.size()-1).end=Math.max(merged.get(merged.size()-1).end,r.end); }
        for(Range ex:c.excludes){ List<Range> next=new ArrayList<>(); for(Range r:merged){ if(ex.end<r.start||ex.start>r.end) next.add(r); else { if(ex.start>r.start) next.add(new Range(r.start,ex.start-1)); if(ex.end<r.end) next.add(new Range(ex.end+1,r.end)); }} merged=next; }
        return merged;
    }
    static void echo(Config c){
        System.out.printf(Locale.ROOT,"seed = %s%n", Long.toUnsignedString(new Random().nextLong()));
        System.out.printf("rate = %-10s%n", trimRate(c.rate));
        System.out.println("shard = "+c.shard);
        for(String n:c.nocapture) System.out.println("nocapture = "+n);
        System.out.println(); System.out.println();
        if(c.adapterIp!=null) System.out.println("adapter-ip = "+c.adapterIp);
        if(c.adapterMac!=null) System.out.println("adapter-mac = "+c.adapterMac);
        if(c.routerMac!=null){ System.out.println("router-mac-ipv4 = "+c.routerMac); System.out.println("router-mac-ipv6 = "+c.routerMac); }
        if(c.sourcePort!=null) System.out.println("adapter-port = "+c.sourcePort);
        if(c.sourceIp!=null) System.out.println("source-ip = "+c.sourceIp);
        if(c.outputFormat!=null) System.out.println("output-format = "+c.outputFormat);
        if(c.outputFilename!=null) System.out.println("output-filename = "+c.outputFilename);
        if(c.banners) System.out.println("banners = true");
        if(c.open) System.out.println("open = true");
        System.out.println("# TARGET SELECTION (IP, PORTS, EXCLUDES)");
        System.out.println("ports = "+sanitizePorts(c.ports));
        for(Range r:finalRanges(c)) System.out.println("range = "+rangeString(r));
        for(String s:c.ipv6Ranges) System.out.println("range = "+s);
    }
    static String trimRate(String r){ if(r==null||r.isEmpty())return"100"; if(r.endsWith(".00")) return r.substring(0,r.length()-3); return r; }
    static String sanitizePorts(String p){ if(p==null)return""; if(!p.matches("[0-9,\u002d]+")) return ""; return p; }
    static void doReadscan(Config c){ writeOutput(c); }
    static void writeOutput(Config c){
        if(c.outputFilename==null) return;
        String f=c.outputFormat==null?"xml":c.outputFormat.toLowerCase(Locale.ROOT);
        String content="";
        if(f.equals("xml")) content="<?xml version=\"1.0\"?>\n<nmaprun scanner=\"masscan\">\n</nmaprun>\n";
        else if(f.equals("json")) content="[\n]\n";
        else if(f.equals("ndjson")) content="";
        else if(f.equals("grepable")) content="# Masscan scan initiated\n# Masscan done\n";
        else if(f.equals("list")) content="#masscan\n";
        try { Files.write(Paths.get(c.outputFilename), content.getBytes(), c.append?StandardOpenOption.CREATE:StandardOpenOption.CREATE, c.append?StandardOpenOption.APPEND:StandardOpenOption.TRUNCATE_EXISTING); } catch(IOException e){ System.out.println("FAIL: could not open output file"); }
    }
}
