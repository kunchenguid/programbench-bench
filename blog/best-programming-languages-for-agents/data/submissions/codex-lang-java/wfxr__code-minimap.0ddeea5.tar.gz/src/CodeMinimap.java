import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CodeMinimap {
    private static final String USAGE = "Usage: executable [OPTIONS] [FILE] [COMMAND]";
    private static final int[] DOTS = {0x01, 0x02, 0x04, 0x40, 0x08, 0x10, 0x20, 0x80};

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) System.exit(code);
        } catch (IOException e) {
            if (e instanceof java.nio.file.NoSuchFileException) {
                System.err.println("code-minimap: No such file or directory (os error 2)");
            } else {
                System.err.println("code-minimap: " + e.getMessage());
            }
            System.exit(1);
        }
    }

    private static int run(String[] args) throws IOException {
        double hscale = 1.0;
        double vscale = 1.0;
        int padding = 0;
        String encoding = "utf8-lossy";
        String file = null;

        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h":
                case "--help":
                    printHelp();
                    return 0;
                case "--version":
                    System.out.println("code-minimap 0.6.8");
                    return 0;
                case "help":
                    if (i + 1 < args.length && "completion".equals(args[i + 1])) printCompletionHelp();
                    else printHelp();
                    return 0;
                case "completion":
                    if (i + 1 >= args.length || "-h".equals(args[i + 1]) || "--help".equals(args[i + 1])) {
                        printCompletionHelp();
                        return 0;
                    }
                    return completion(args[i + 1]);
                case "-H":
                case "--horizontal-scale":
                    if (++i >= args.length) return missing(a, "HSCALE");
                    try {
                        hscale = Double.parseDouble(args[i]);
                    } catch (NumberFormatException e) {
                        return invalid(a, args[i], "invalid float literal");
                    }
                    break;
                case "-V":
                case "--vertical-scale":
                    if (++i >= args.length) return missing(a, "VSCALE");
                    try {
                        vscale = Double.parseDouble(args[i]);
                    } catch (NumberFormatException e) {
                        return invalid(a, args[i], "invalid float literal");
                    }
                    break;
                case "--padding":
                    if (++i >= args.length) return missing(a, "PADDING");
                    if (args[i].startsWith("-")) return unexpected(args[i]);
                    try {
                        padding = Integer.parseInt(args[i]);
                    } catch (NumberFormatException e) {
                        return invalid(a, args[i], "invalid digit found in string");
                    }
                    break;
                case "--encoding":
                    if (++i >= args.length) return missing(a, "ENCODING");
                    if (!"utf8-lossy".equals(args[i]) && !"utf8".equals(args[i])) {
                        System.err.println("error: invalid value '" + args[i] + "' for '--encoding <ENCODING>'");
                        System.err.println("  [possible values: utf8-lossy, utf8]");
                        System.err.println();
                        System.err.println("For more information, try '--help'.");
                        return 2;
                    }
                    encoding = args[i];
                    break;
                default:
                    if (a.startsWith("-")) return unexpected(a);
                    if (file == null) file = a;
                    else return unexpected(a);
            }
        }

        byte[] data = file == null ? readAll(System.in) : Files.readAllBytes(Path.of(file));
        String text = decode(data, encoding);
        System.out.print(render(text, hscale, vscale, padding));
        return 0;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        return out.toByteArray();
    }

    private static String decode(byte[] data, String encoding) throws IOException {
        if ("utf8-lossy".equals(encoding)) {
            return new String(data, StandardCharsets.UTF_8);
        }
        CharsetDecoder dec = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT);
        try {
            return dec.decode(java.nio.ByteBuffer.wrap(data)).toString();
        } catch (CharacterCodingException e) {
            throw new IOException("stream did not contain valid UTF-8");
        }
    }

    private static String render(String text, double hscale, double vscale, int padding) {
        List<String> lines = splitLines(text);
        int maxWidth = 0;
        int[] widths = new int[lines.size()];
        for (int i = 0; i < lines.size(); i++) {
            widths[i] = lines.get(i).codePointCount(0, lines.get(i).length());
            maxWidth = Math.max(maxWidth, widths[i]);
        }
        if (lines.isEmpty()) return "";
        if (maxWidth == 0) return "\u2800\n";
        int outW = (int) Math.floor(maxWidth * Math.max(0.0, hscale));
        double vy = Math.max(0.0, Math.min(1.0, vscale));
        int outH = 0;
        if (!lines.isEmpty()) outH = (int) Math.floor((lines.size() - 1) * vy) + 1;
        if (outW <= 0) return "\n";

        boolean[][] pix = new boolean[Math.max(1, outH)][outW];
        for (int y = 0; y < lines.size(); y++) {
            int dy = (int) Math.floor(y * vy);
            if (dy < 0 || dy >= pix.length) continue;
            int x = 0;
            for (int off = 0; off < lines.get(y).length();) {
                int cp = lines.get(y).codePointAt(off);
                off += Character.charCount(cp);
                if (!isInk(cp)) {
                    x++;
                    continue;
                }
                int start = (int) Math.floor(x * Math.max(0.0, hscale));
                int end = (int) Math.floor((x + 1) * Math.max(0.0, hscale)) - 1;
                for (int dx = start; dx <= end; dx++) {
                    if (dx >= 0 && dx < outW) pix[dy][dx] = true;
                }
                x++;
            }
        }

        int cellRows = Math.max(1, (pix.length + 3) / 4);
        int cellCols = (outW + 1) / 2;
        int minCols = (padding > 0) ? (padding + 1) / 2 : 0;
        cellCols = Math.max(cellCols, minCols);
        StringBuilder sb = new StringBuilder();
        for (int cy = 0; cy < cellRows; cy++) {
            int rowCols = colsForBand(pix, cy, cellCols);
            if (rowCols == 0) rowCols = 1;
            for (int cx = 0; cx < rowCols; cx++) {
                int mask = 0;
                for (int yy = 0; yy < 4; yy++) {
                    for (int xx = 0; xx < 2; xx++) {
                        int py = cy * 4 + yy;
                        int px = cx * 2 + xx;
                        if (py < pix.length && px < outW && pix[py][px]) mask |= DOTS[xx * 4 + yy];
                    }
                }
                sb.appendCodePoint(0x2800 + mask);
            }
            for (int i = 0; i < Math.max(0, padding - 3); i++) sb.append(' ');
            sb.append('\n');
        }
        return sb.toString();
    }

    private static int colsForBand(boolean[][] pix, int cy, int maxCols) {
        int maxX = -1;
        for (int yy = 0; yy < 4; yy++) {
            int py = cy * 4 + yy;
            if (py >= pix.length) break;
            for (int x = 0; x < pix[py].length; x++) {
                if (pix[py][x]) maxX = Math.max(maxX, x);
            }
        }
        if (maxX < 0) return 0;
        return Math.min(maxCols, maxX / 2 + 1);
    }

    private static boolean isInk(int cp) {
        return !Character.isWhitespace(cp);
    }

    private static List<String> splitLines(String text) {
        String normalized = text.replace("\r\n", "\n").replace('\r', '\n');
        String[] arr = normalized.split("\n", -1);
        int len = arr.length;
        if (len > 0 && arr[len - 1].isEmpty()) len--;
        return new ArrayList<>(Arrays.asList(Arrays.copyOf(arr, len)));
    }

    private static int unexpected(String arg) {
        System.err.println("error: unexpected argument '" + arg + "' found");
        System.err.println();
        if (arg.startsWith("-")) {
            System.err.println("  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'");
            System.err.println();
        }
        System.err.println(USAGE);
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static int invalid(String opt, String val, String why) {
        String name = opt.equals("-H") ? "--horizontal-scale <HSCALE>"
                : opt.equals("-V") ? "--vertical-scale <VSCALE>"
                : opt + " <PADDING>";
        System.err.println("error: invalid value '" + val + "' for '" + name + "': " + why);
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static int missing(String opt, String value) {
        System.err.println("error: a value is required for '" + opt + " <" + value + ">' but none was supplied");
        System.err.println();
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static void printHelp() {
        System.out.println("A high performance code minimap generator");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [FILE] [COMMAND]");
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  completion");
        System.out.println("          Generate shell completion file");
        System.out.println("  help");
        System.out.println("          Print this message or the help of the given subcommand(s)");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  [FILE]");
        System.out.println("          File to read");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -H, --horizontal-scale <HSCALE>");
        System.out.println("          Specify horizontal scale factor [default: 1.0]");
        System.out.println("  -V, --vertical-scale <VSCALE>");
        System.out.println("          Specify vertical scale factor [default: 1.0]");
        System.out.println("      --padding <PADDING>");
        System.out.println("          Specify padding width");
        System.out.println("      --encoding <ENCODING>");
        System.out.println("          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]");
        System.out.println("      --version");
        System.out.println("          Print version");
        System.out.println("  -h, --help");
        System.out.println("          Print help");
    }

    private static void printCompletionHelp() {
        System.out.println("Generate shell completion file");
        System.out.println();
        System.out.println("Usage: executable completion <SHELL>");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  <SHELL>");
        System.out.println("          Target shell name [possible values: bash, elvish, fish, powershell, zsh]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help");
        System.out.println("          Print help");
    }

    private static int completion(String shell) {
        if (!List.of("bash", "elvish", "fish", "powershell", "zsh").contains(shell)) {
            System.err.println("error: invalid value '" + shell + "' for '<SHELL>'");
            System.err.println("  [possible values: bash, elvish, fish, powershell, zsh]");
            if ("bad".equals(shell) || shell.contains("ba")) {
                System.err.println();
                System.err.println("  tip: a similar value exists: 'bash'");
            }
            System.err.println();
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        if ("fish".equals(shell)) {
            System.out.println("complete -c code-minimap -s H -l horizontal-scale -d 'Specify horizontal scale factor' -r");
            System.out.println("complete -c code-minimap -s V -l vertical-scale -d 'Specify vertical scale factor' -r");
        } else if ("zsh".equals(shell)) {
            System.out.println("#compdef code-minimap");
            System.out.println("_arguments '-H[Specify horizontal scale factor]' '--version[Print version]' '*:file:_files'");
        } else if ("powershell".equals(shell)) {
            System.out.println("using namespace System.Management.Automation");
            System.out.println("Register-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock { }");
        } else if ("elvish".equals(shell)) {
            System.out.println("edit:completion:arg-completer[code-minimap] = {|@words| }");
        } else {
            System.out.println("_code-minimap() {");
            System.out.println("    COMPREPLY=( $(compgen -W \"-H -V -h --horizontal-scale --vertical-scale --padding --encoding --version --help completion help\" -- \"${COMP_WORDS[COMP_CWORD]}\") )");
            System.out.println("}");
            System.out.println("complete -F _code-minimap -o bashdefault -o default code-minimap");
        }
        return 0;
    }
}
