package parqeye;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.NumberFormat;
import java.util.Locale;

public final class Main {
    private static final String HELP = String.join("\n",
            "Command line tool to visualize parquet files",
            "",
            "Usage: executable <PATH>",
            "",
            "Arguments:",
            "  <PATH>  Path to the parquet file",
            "",
            "Options:",
            "  -h, --help     Print help",
            "  -V, --version  Print version");

    private Main() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && ("--help".equals(args[0]) || "-h".equals(args[0]))) {
            System.out.println(HELP);
            return;
        }
        if (args.length == 1 && ("--version".equals(args[0]) || "-V".equals(args[0]))) {
            System.out.println("parqeye 0.0.2");
            return;
        }
        if (args.length == 0) {
            System.err.println("error: the following required arguments were not provided:");
            System.err.println("  <PATH>");
            System.err.println();
            System.err.println("Usage: executable <PATH>");
            System.err.println();
            System.err.println("For more information, try '--help'.");
            System.exit(2);
        }
        if (args.length > 1 || args[0].startsWith("-")) {
            String bad = args.length == 0 ? "" : args[0];
            System.err.println("error: unexpected argument '" + bad + "' found");
            System.err.println();
            System.err.println("  tip: to pass '" + bad + "' as a value, use '-- " + bad + "'");
            System.err.println();
            System.err.println("Usage: executable <PATH>");
            System.err.println();
            System.err.println("For more information, try '--help'.");
            System.exit(2);
        }

        if (System.console() == null) {
            printRatatuiNoTtyPanic();
            System.exit(101);
        }

        renderSimpleUi(Path.of(args[0]));
    }

    private static void printRatatuiNoTtyPanic() {
        System.out.print("\033[?1049l");
        System.err.println();
        System.err.println("thread 'main' (159) panicked at /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ratatui-0.29.0/src/terminal/init.rs:52:16:");
        System.err.println("failed to initialize terminal: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }");
        System.err.println("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace");
    }

    private static void renderSimpleUi(Path path) throws IOException {
        FileInfo info = inspect(path);
        String title = " parqeye ";
        clear();
        System.out.println("+" + repeat("-", 76) + "+");
        System.out.printf("|%-76s|%n", title + path);
        System.out.println("+" + repeat("-", 76) + "+");
        line("File", path.toString());
        line("Size", NumberFormat.getIntegerInstance(Locale.US).format(info.size) + " bytes");
        line("Format", info.parquet ? "Parquet" : "Unknown");
        if (info.parquet) {
            line("Footer length", info.footerLength + " bytes");
            line("Magic", "PAR1");
        }
        System.out.println("+" + repeat("-", 76) + "+");
        System.out.println("| Tabs: Visualize | Schema | Metadata | Row Groups                         |");
        System.out.println("| Press q or Ctrl-C to quit.                                             |");
        System.out.println("+" + repeat("-", 76) + "+");
        InputStream in = System.in;
        while (true) {
            int ch = in.read();
            if (ch == -1 || ch == 'q' || ch == 'Q' || ch == 3) {
                break;
            }
        }
        clear();
    }

    private static FileInfo inspect(Path path) throws IOException {
        long size = Files.size(path);
        FileInfo info = new FileInfo();
        info.size = size;
        if (size >= 12) {
            byte[] tail = new byte[8];
            try (InputStream in = Files.newInputStream(path)) {
                long skipped = in.skip(size - 8);
                while (skipped < size - 8) {
                    long more = in.skip(size - 8 - skipped);
                    if (more <= 0) {
                        break;
                    }
                    skipped += more;
                }
                int read = in.read(tail);
                if (read == 8 && tail[4] == 'P' && tail[5] == 'A' && tail[6] == 'R' && tail[7] == '1') {
                    info.parquet = true;
                    info.footerLength = (tail[0] & 0xff) | ((tail[1] & 0xff) << 8) | ((tail[2] & 0xff) << 16) | ((tail[3] & 0xff) << 24);
                }
            }
        }
        return info;
    }

    private static void line(String key, String value) {
        System.out.printf("| %-18s %-55s|%n", key + ":", truncate(value, 55));
    }

    private static String truncate(String s, int width) {
        if (s.length() <= width) {
            return s;
        }
        return s.substring(0, Math.max(0, width - 3)) + "...";
    }

    private static String repeat(String s, int count) {
        return s.repeat(Math.max(0, count));
    }

    private static void clear() {
        System.out.print("\033[?1049h\033[2J\033[H");
        System.out.flush();
    }

    private static final class FileInfo {
        long size;
        boolean parquet;
        int footerLength;
    }
}
