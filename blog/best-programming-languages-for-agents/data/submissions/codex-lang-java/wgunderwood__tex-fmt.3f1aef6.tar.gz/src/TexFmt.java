import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class TexFmt {
    static class Opts {
        boolean check=false, print=false, fail=false, recursive=false, wrap=true, stdin=false;
        boolean noConfig=false, verbose=false, quiet=false, trace=false, useTabs=false, args=false, man=false;
        int wraplen=80, tabsize=2;
        String config=null, completion=null;
        List<String> files = new ArrayList<>();
        Set<String> lists = new LinkedHashSet<>(Arrays.asList("itemize","enumerate","description","inlineroman","inventory"));
        Set<String> verbatims = new LinkedHashSet<>(Arrays.asList("verbatim","Verbatim","lstlisting","minted","comment"));
        Set<String> noIndent = new LinkedHashSet<>(Collections.singletonList("document"));
        List<String> wrapChars = new ArrayList<>();
    }

    static final String VERSION = "tex-fmt 0.5.6";

    public static void main(String[] argv) {
        try {
            Opts cli = parse(argv);
            Opts o = new Opts();
            o.config = cli.config;
            o.noConfig = cli.noConfig;
            if (!o.noConfig) loadConfig(o);
            applyCli(o, argv);
            if (o.args) { printArgs(o); return; }
            if (o.man) { printMan(); return; }
            if (o.completion != null) { printCompletion(o.completion); return; }
            if (o.stdin) {
                if (!o.files.isEmpty()) die(1, "ERROR: tex-fmt : Do not provide file name(s) when using --stdin. ");
                String input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
                System.out.print(format(input, o));
                return;
            }
            List<Path> files = new ArrayList<>();
            if (o.recursive) {
                List<Path> roots = o.files.isEmpty() ? Collections.singletonList(Paths.get(".")) : toPaths(o.files);
                for (Path r: roots) collectFiles(r, files);
            } else {
                if (o.files.isEmpty()) die(1, "ERROR: tex-fmt : No files specified. Provide filenames, or pass --recursive or --stdin. ");
                files.addAll(toPaths(o.files));
            }
            boolean changed = false;
            for (Path p: files) {
                String name = p.toString();
                String input;
                try { input = Files.readString(p); }
                catch (IOException e) { die(1, "ERROR: tex-fmt " + name + ": Could not open file. "); return; }
                if (o.verbose && !o.quiet && !o.print && !o.check) System.err.println("INFO: tex-fmt " + name + ": Formatting started. ");
                String out = format(input, o);
                if (!out.equals(input)) {
                    changed = true;
                    if (o.check) {
                        if (!o.quiet) System.err.println("ERROR: tex-fmt " + name + ": Incorrect formatting. ");
                    } else if (o.print) {
                        System.out.print(out);
                    } else {
                        Files.writeString(p, out);
                    }
                } else if (o.print) {
                    System.out.print(out);
                }
                if (o.verbose && !o.quiet && !o.print && !o.check) System.err.println("INFO: tex-fmt " + name + ": Formatting complete. ");
            }
            if ((o.check || o.fail) && changed) System.exit(1);
        } catch (CliError e) {
            System.err.print(e.message);
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("ERROR: tex-fmt : " + e.getMessage() + " ");
            System.exit(1);
        }
    }

    static class CliError extends RuntimeException {
        final int code; final String message;
        CliError(int c, String m) { code=c; message=m; }
    }
    static void die(int code, String msg) { throw new CliError(code, msg + "\n"); }

    static Opts parse(String[] a) {
        Opts o = new Opts();
        applyCli(o, a);
        return o;
    }
    static void applyCli(Opts o, String[] a) {
        for (int i=0;i<a.length;i++) {
            String s=a[i];
            switch (s) {
                case "-c": case "--check": o.check=true; break;
                case "-p": case "--print": o.print=true; break;
                case "-f": case "--fail-on-change": o.fail=true; break;
                case "-r": case "--recursive": o.recursive=true; break;
                case "-n": case "--nowrap": o.wrap=false; break;
                case "-s": case "--stdin": o.stdin=true; break;
                case "--usetabs": o.useTabs=true; break;
                case "--noconfig": o.noConfig=true; break;
                case "-v": case "--verbose": o.verbose=true; break;
                case "-q": case "--quiet": o.quiet=true; break;
                case "--trace": o.trace=true; break;
                case "--args": o.args=true; o.fail=true; break;
                case "--man": o.man=true; break;
                case "-h": case "--help": printHelp(); System.exit(0); break;
                case "-V": case "--version": System.out.println(VERSION); System.exit(0); break;
                case "-l": case "--wraplen": o.wraplen=parseInt(next(a, ++i, s), s); break;
                case "-t": case "--tabsize": o.tabsize=parseInt(next(a, ++i, s), s); break;
                case "--config": o.config=next(a, ++i, s); break;
                case "--completion": o.completion=next(a, ++i, s); break;
                default:
                    if (s.startsWith("--wraplen=")) o.wraplen=parseInt(s.substring(10), "--wraplen");
                    else if (s.startsWith("--tabsize=")) o.tabsize=parseInt(s.substring(10), "--tabsize");
                    else if (s.startsWith("--config=")) o.config=s.substring(9);
                    else if (s.startsWith("--completion=")) o.completion=s.substring(13);
                    else if (s.startsWith("-")) die(2, "error: unexpected argument '" + s + "' found\n\nUsage: executable [OPTIONS] [files]...\n\nFor more information, try '--help'.");
                    else o.files.add(s);
            }
        }
    }
    static String next(String[] a, int i, String opt) { if (i>=a.length) die(2,"error: a value is required for '"+opt+"' but none was supplied\n"); return a[i];}
    static int parseInt(String s, String opt) { try { return Integer.parseInt(s); } catch(Exception e){ die(2,"error: invalid value '"+s+"' for '"+opt+" <N>': invalid digit found in string\n\nFor more information, try '--help'."); return 0; } }
    static List<Path> toPaths(List<String> xs) { List<Path> ps=new ArrayList<>(); for(String x:xs) ps.add(Paths.get(x)); return ps; }

    static void loadConfig(Opts o) {
        Path cfg = null;
        if (o.config != null) cfg = Paths.get(o.config);
        else if (Files.exists(Paths.get("tex-fmt.toml"))) cfg = Paths.get("tex-fmt.toml");
        else {
            Path p = Paths.get("").toAbsolutePath();
            while (p != null) {
                if (Files.isDirectory(p.resolve(".git")) && Files.exists(p.resolve("tex-fmt.toml"))) { cfg=p.resolve("tex-fmt.toml"); break; }
                p = p.getParent();
            }
            if (cfg == null) {
                String home = System.getProperty("user.home");
                if (home != null && Files.exists(Paths.get(home, ".config", "tex-fmt", "tex-fmt.toml")))
                    cfg = Paths.get(home, ".config", "tex-fmt", "tex-fmt.toml");
            }
        }
        if (cfg == null || !Files.exists(cfg)) return;
        o.config = cfg.toAbsolutePath().toString();
        try {
            for (String raw: Files.readAllLines(cfg)) {
                String line = raw.split("#",2)[0].trim();
                if (!line.contains("=")) continue;
                String[] kv = line.split("=",2);
                String k = kv[0].trim(), v = kv[1].trim();
                switch(k) {
                    case "check": o.check=bool(v); break;
                    case "print": o.print=bool(v); break;
                    case "fail-on-change": o.fail=bool(v); break;
                    case "wrap": o.wrap=bool(v); break;
                    case "wraplen": o.wraplen=Integer.parseInt(v.replaceAll("[^0-9-]","")); break;
                    case "tabsize": o.tabsize=Integer.parseInt(v.replaceAll("[^0-9-]","")); break;
                    case "tabchar": o.useTabs=v.contains("tab"); break;
                    case "stdin": o.stdin=bool(v); break;
                    case "lists": o.lists.addAll(arr(v)); break;
                    case "verbatims": o.verbatims.addAll(arr(v)); break;
                    case "no-indent-envs": o.noIndent.addAll(arr(v)); break;
                    case "wrap-chars": o.wrapChars.addAll(arr(v)); break;
                    case "verbosity": o.quiet=v.contains("error"); o.verbose=v.contains("info") || v.contains("trace"); o.trace=v.contains("trace"); break;
                }
            }
        } catch(Exception ignored) {}
    }
    static boolean bool(String v) { return v.trim().startsWith("true");}
    static List<String> arr(String v) {
        List<String> r = new ArrayList<>();
        Matcher m = Pattern.compile("\"([^\"]*)\"").matcher(v);
        while(m.find()) r.add(m.group(1));
        return r;
    }

    static String format(String input, Opts o) {
        String[] lines = input.split("\\R", -1);
        int n = lines.length;
        boolean finalEmpty = n>0 && lines[n-1].isEmpty();
        if (finalEmpty) n--;
        List<String> out = new ArrayList<>();
        int indent=0, itemCont=-1;
        boolean off=false, verb=false; String verbEnv=null;
        for (int idx=0; idx<n; idx++) {
            String raw = rstrip(lines[idx]);
            String t = raw.trim();
            if (off) {
                out.add(raw);
                if (t.contains("tex-fmt: on")) off=false;
                continue;
            }
            if (t.contains("tex-fmt: off")) { out.add(raw); off=true; continue; }
            if (t.contains("tex-fmt: skip")) { out.add(raw); continue; }
            if (verb) {
                if (isEndEnv(t, verbEnv)) {
                    out.add(ind(o, indent) + t);
                    verb=false; verbEnv=null;
                } else out.add(raw);
                continue;
            }
            if (t.isEmpty()) { out.add(""); continue; }

            String endEnv = endEnv(t);
            if (endEnv != null && !o.noIndent.contains(endEnv)) indent = Math.max(0, indent-1);
            else if (isCloser(t)) indent = Math.max(0, indent-1);

            int lineIndent = indent;
            boolean item = startsItem(t);
            int contIndent = item ? indent+1 : (itemCont >= 0 ? itemCont : indent);
            if (item) itemCont = indent + 1;
            if (endEnv != null || startsNewBlock(t)) itemCont = -1;

            String line = ind(o, lineIndent) + t;
            addWrapped(out, line, ind(o, contIndent), o);

            String beginEnv = beginEnv(t);
            if (beginEnv != null) {
                if (o.verbatims.contains(beginEnv)) { verb=true; verbEnv=beginEnv; }
                if (!o.noIndent.contains(beginEnv)) indent++;
            } else if (isOpener(t)) indent++;
        }
        StringBuilder sb = new StringBuilder();
        for (String s: out) sb.append(s).append('\n');
        if (!finalEmpty && sb.length()>0) sb.setLength(sb.length()-1);
        return sb.toString();
    }

    static String rstrip(String s) { return s.replaceFirst("\\s+$", ""); }
    static String ind(Opts o, int level) {
        if (level <= 0) return "";
        if (o.useTabs) return "\t".repeat(level * Math.max(1, o.tabsize));
        return " ".repeat(level * Math.max(0, o.tabsize));
    }
    static boolean startsItem(String t) { return t.startsWith("\\item") || t.startsWith("\\bibitem"); }
    static boolean startsNewBlock(String t) { return t.startsWith("\\begin") || t.startsWith("\\[") || t.startsWith("\\("); }
    static boolean isCloser(String t) { return t.equals("}") || t.startsWith("},") || t.startsWith("\\]") || t.startsWith("\\)") || t.startsWith("\\right"); }
    static boolean isOpener(String t) { return t.equals("{") || t.matches("^@\\w+\\s*\\{.*") || t.startsWith("\\[") || t.startsWith("\\(") || t.startsWith("\\left"); }
    static final Pattern BEGIN = Pattern.compile("^\\\\begin\\{([^}]+)\\}");
    static final Pattern END = Pattern.compile("^\\\\end\\{([^}]+)\\}");
    static String beginEnv(String t) { Matcher m=BEGIN.matcher(t); return m.find()?m.group(1):null; }
    static String endEnv(String t) { Matcher m=END.matcher(t); return m.find()?m.group(1):null; }
    static boolean isEndEnv(String t, String env) { return t.startsWith("\\end{"+env+"}"); }

    static void addWrapped(List<String> out, String line, String cont, Opts o) {
        if (!o.wrap || line.length() <= o.wraplen || line.trim().startsWith("\\") && !line.trim().startsWith("\\item")) {
            out.add(line); return;
        }
        String cur = line;
        while (cur.length() > o.wraplen) {
            int cut = -1;
            int limit = o.wraplen;
            if (o.wraplen >= 70) limit = o.wraplen - 10;
            int min = Math.min(cur.length()-1, Math.max(cont.length()+1, limit));
            for (int i=min; i>=0; i--) if (Character.isWhitespace(cur.charAt(i))) { cut=i; break; }
            if (cut <= cont.length()) break;
            out.add(rstrip(cur.substring(0, cut)));
            cur = cont + cur.substring(cut).trim();
        }
        out.add(cur);
    }

    static void collectFiles(Path root, List<Path> out) throws IOException {
        if (Files.isRegularFile(root)) { if (wanted(root)) out.add(root); return; }
        if (!Files.isDirectory(root)) return;
        try (Stream<Path> s = Files.walk(root)) {
            s.filter(Files::isRegularFile)
             .filter(TexFmt::wanted)
             .filter(p -> !p.toString().contains(File.separator+".git"+File.separator))
             .forEach(out::add);
        }
    }
    static boolean wanted(Path p) {
        String x=p.getFileName().toString().toLowerCase(Locale.ROOT);
        return x.endsWith(".tex") || x.endsWith(".bib") || x.endsWith(".cls") || x.endsWith(".sty");
    }

    static void printHelp() {
        System.out.print(VERSION+"\n\nLaTeX formatter written in Rust\n\nUsage: executable [OPTIONS] [files]...\n\nArguments:\n  [files]...  List of files to be formatted\n\nOptions:\n  -c, --check               Check formatting, do not modify files\n  -p, --print               Print to stdout, do not modify files\n  -f, --fail-on-change      Format files and return non-zero exit code if files are modified\n  -n, --nowrap              Do not wrap long lines\n  -l, --wraplen <N>         Line length for wrapping [default: 80]\n  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]\n      --usetabs             Use tabs instead of spaces for indentation\n  -s, --stdin               Process stdin as a single file, output to stdout\n      --config <PATH>       Path to config file\n      --noconfig            Do not read any config file\n  -v, --verbose             Show info messages\n  -q, --quiet               Hide warning messages\n      --trace               Show trace messages\n      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]\n      --man                 Generate a man page\n      --args                Print arguments passed to tex-fmt and exit\n  -r, --recursive           Recursively search for files to format\n  -h, --help                Print help\n  -V, --version             Print version\n");
    }
    static void printArgs(Opts o) {
        System.out.println("tex-fmt");
        System.out.printf("  check:                   %s%n", o.check);
        System.out.printf("  print:                   %s%n", o.print);
        System.out.printf("  fail-on-change:          %s%n", o.fail || o.print);
        System.out.printf("  wrap:                    %s%n", o.wrap);
        System.out.printf("  wraplen:                 %d%n", o.wraplen);
        System.out.printf("  wrapmin:                 %d%n", Math.max(0, o.wraplen-10));
        System.out.printf("  tabsize:                 %d%n", o.tabsize);
        System.out.printf("  tabchar:                 %s%n", o.useTabs?"tab":"space");
        System.out.printf("  stdin:                   %s%n", o.stdin);
        System.out.printf("  config:                  %s%n", o.config==null?"None":o.config);
        System.out.printf("  verbosity:               %s%n", o.trace?"trace":(o.verbose?"info":(o.quiet?"error":"warn")));
        printList("lists", o.lists); printList("verbatims", o.verbatims); printList("no-indent-envs", o.noIndent);
        System.out.println("  wrap-chars:               ");
        if (!o.files.isEmpty()) System.out.println("  files:                   "+String.join("\n                           ", o.files));
    }
    static void printList(String name, Collection<String> xs) {
        boolean first=true;
        for(String x: xs) {
            System.out.printf("  %-24s %s%n", first ? name + ":" : "", x);
            first=false;
        }
    }
    static void printCompletion(String shell) { System.out.println("# completion script for "+shell+"\n# generated by tex-fmt"); }
    static void printMan() { System.out.println(".TH tex-fmt 1  \"tex-fmt 0.5.6\"\n.SH NAME\ntex\\-fmt \\- LaTeX formatter written in Rust\n.SH SYNOPSIS\ntex-fmt [OPTIONS] [files]\n.SH DESCRIPTION\nLaTeX formatter written in Rust"); }
}
