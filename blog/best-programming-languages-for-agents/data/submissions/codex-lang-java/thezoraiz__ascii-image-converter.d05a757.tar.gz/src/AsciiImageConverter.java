import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

public class AsciiImageConverter {
    private static final String VERSION = "v1.13.1";
    private static final String DEFAULT_MAP = " .:-=+*#%@";
    private static final String COMPLEX_MAP = " .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$";

    static class Opt {
        boolean color, colorBg, braille, dither, grayscale, complex, full, negative, flipX, flipY, onlySave;
        int threshold = 128;
        Integer width, height;
        int[] dimensions;
        String map;
        String saveImg, saveTxt, saveGif, font;
        int[] saveBg = {0,0,0,100};
        int[] fontColor = {255,255,255};
        List<String> paths = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) System.exit(code);
        } catch (Throwable t) {
            System.out.println("Error: " + t.getMessage());
        }
    }

    private static int run(String[] args) throws Exception {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(); return 0;
                case "-v": case "--version": System.out.println(VERSION); return 0;
                case "--formats": printFormats(); return 0;
                case "-C": case "--color": o.color = true; break;
                case "--color-bg": o.colorBg = true; break;
                case "-b": case "--braille": o.braille = true; break;
                case "--dither": o.dither = true; break;
                case "-g": case "--grayscale": o.grayscale = true; break;
                case "-c": case "--complex": o.complex = true; break;
                case "-f": case "--full": o.full = true; break;
                case "-n": case "--negative": o.negative = true; break;
                case "-x": case "--flipX": o.flipX = true; break;
                case "-y": case "--flipY": o.flipY = true; break;
                case "--only-save": o.onlySave = true; break;
                case "-d": case "--dimensions":
                    String dv = need(args, ++i, a);
                    try {
                        String[] p = dv.split(",");
                        if (p.length != 2) {
                            System.out.println("Error: requires 2 dimensions, got " + p.length);
                            System.out.println();
                            return 0;
                        }
                        o.dimensions = new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
                    } catch (NumberFormatException e) {
                        System.out.println("Error: invalid argument \"" + dv + "\" for \"-d, --dimensions\" flag: strconv.Atoi: parsing \"" + dv + "\": invalid syntax");
                        printHelpUsage();
                        return 0;
                    }
                    break;
                case "-W": case "--width":
                    String wv = need(args, ++i, a);
                    try { o.width = Integer.parseInt(wv); }
                    catch (NumberFormatException e) {
                        System.out.println("Error: invalid argument \"" + wv + "\" for \"-W, --width\" flag: strconv.ParseInt: parsing \"" + wv + "\": invalid syntax");
                        printHelpUsage();
                        return 0;
                    }
                    break;
                case "-H": case "--height":
                    String hv = need(args, ++i, a);
                    try { o.height = Integer.parseInt(hv); }
                    catch (NumberFormatException e) {
                        System.out.println("Error: invalid argument \"" + hv + "\" for \"-H, --height\" flag: strconv.ParseInt: parsing \"" + hv + "\": invalid syntax");
                        printHelpUsage();
                        return 0;
                    }
                    break;
                case "-m": case "--map": o.map = need(args, ++i, a); break;
                case "--threshold":
                    o.threshold = Integer.parseInt(need(args, ++i, a));
                    if (o.threshold < 0 || o.threshold > 255) {
                        System.out.println("Error: threshold must be between 0 and 255");
                        System.out.println();
                        return 0;
                    }
                    break;
                case "-s": case "--save-img": o.saveImg = need(args, ++i, a); break;
                case "--save-txt": o.saveTxt = need(args, ++i, a); break;
                case "--save-gif": o.saveGif = need(args, ++i, a); break;
                case "--font": o.font = need(args, ++i, a); break;
                case "--font-color":
                    o.fontColor = parseInts(need(args, ++i, a), 3, "--font-color requires 3 values for RGB");
                    break;
                case "--save-bg":
                    o.saveBg = parseInts(need(args, ++i, a), 4, "--save-bg requires 4 values for RGBA");
                    break;
                default:
                    if (a.startsWith("-")) {
                        System.out.println("Error: unknown flag: " + a);
                        printHelpUsage();
                        System.out.println("unknown flag: " + a);
                        return 1;
                    }
                    o.paths.add(a);
            }
        }

        if (o.paths.isEmpty()) {
            System.out.println("Error: Need at least 1 input path/url or piped input");
            System.out.println("Use the -h flag for more info");
            System.out.println();
            return 0;
        }

        if (o.color || o.colorBg || o.grayscale || !Arrays.equals(o.fontColor, new int[]{255,255,255})) {
            System.out.println("Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available");
            System.out.println();
            return 0;
        }

        for (String path : o.paths) {
            process(path, o);
        }
        return 0;
    }

    private static String need(String[] args, int i, String flag) {
        if (i >= args.length) throw new RuntimeException("flag needs an argument: " + flag);
        return args[i];
    }

    private static int[] parseInts(String s, int count, String msg) {
        String[] p = s.split(",");
        if (p.length != count) {
            System.out.println("Error: " + msg + ", got " + p.length);
            System.out.println();
            System.exit(0);
        }
        int[] v = new int[count];
        for (int i = 0; i < count; i++) v[i] = Integer.parseInt(p[i].trim());
        return v;
    }

    private static void process(String path, Opt o) throws Exception {
        BufferedImage img;
        File f = new File(path);
        if (!f.exists()) {
            System.out.println("Error: unable to open file: open " + path + ": no such file or directory");
            System.out.println();
            return;
        }
        try {
            img = ImageIO.read(f);
        } catch (Exception e) {
            img = null;
        }
        if (img == null) {
            System.out.println("Error: " + path + " is not a valid image");
            System.out.println();
            return;
        }
        Dimension d = targetDimensions(img, o);
        String art = o.braille ? convertBraille(img, d.width, d.height, o) : convertAscii(img, d.width, d.height, o);

        if (o.saveTxt != null) {
            Path out = Paths.get(o.saveTxt, baseName(path) + "-ascii-art.txt");
            Files.createDirectories(out.getParent() == null ? Paths.get(".") : out.getParent());
            Files.writeString(out, art);
            System.out.println("Saved " + out.toString());
        }
        if (o.saveImg != null) {
            Path out = Paths.get(o.saveImg, baseName(path) + "-ascii-art.png");
            savePng(art, out, o);
            System.out.println("Saved " + out.toString());
        }
        if (!(o.onlySave && (o.saveTxt != null || o.saveImg != null || o.saveGif != null))) {
            System.out.print(art);
        }
    }

    private static Dimension targetDimensions(BufferedImage img, Opt o) {
        int iw = img.getWidth(), ih = img.getHeight();
        if (o.full) {
            int w = 80;
            return new Dimension(w, Math.max(1, (int)Math.round(w * ih / (double)iw * 0.5)));
        }
        if (o.dimensions != null) return new Dimension(Math.max(1, o.dimensions[0]), Math.max(1, o.dimensions[1]));
        if (o.width != null) return new Dimension(Math.max(1, o.width), Math.max(1, (int)Math.round(o.width * ih / (double)iw * 0.5)));
        if (o.height != null) return new Dimension(Math.max(1, (int)Math.round(o.height * iw / (double)ih * 2.0)), Math.max(1, o.height));
        int w = Math.min(80, iw);
        return new Dimension(w, Math.max(1, (int)Math.round(w * ih / (double)iw * 0.5)));
    }

    private static String convertAscii(BufferedImage img, int w, int h, Opt o) {
        BufferedImage scaled = scale(img, w, h);
        String map = o.map != null ? o.map : (o.complex ? COMPLEX_MAP : DEFAULT_MAP);
        StringBuilder sb = new StringBuilder();
        for (int yy = 0; yy < h; yy++) {
            int y = o.flipY ? h - 1 - yy : yy;
            for (int xx = 0; xx < w; xx++) {
                int x = o.flipX ? w - 1 - xx : xx;
                int g = gray(scaled.getRGB(x, y));
                if (o.negative) g = 255 - g;
                int idx = Math.min(map.length() - 1, Math.max(0, g * map.length() / 256));
                sb.append(map.charAt(idx));
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private static String convertBraille(BufferedImage img, int w, int h, Opt o) {
        BufferedImage scaled = scale(img, w * 2, h * 4);
        int[][] dots = {{0,0,1},{0,1,2},{0,2,3},{1,0,4},{1,1,5},{1,2,6},{0,3,7},{1,3,8}};
        StringBuilder sb = new StringBuilder();
        for (int cy = 0; cy < h; cy++) {
            for (int cx = 0; cx < w; cx++) {
                int mask = 0;
                for (int[] d : dots) {
                    int px = cx * 2 + d[0], py = cy * 4 + d[1];
                    int g = gray(scaled.getRGB(px, py));
                    if (o.negative) g = 255 - g;
                    boolean on = g >= o.threshold;
                    if (on) mask |= 1 << (d[2] - 1);
                }
                sb.append((char)(0x2800 + mask));
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private static BufferedImage scale(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return out;
    }

    private static int gray(int rgb) {
        int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
        return (int)Math.round(0.299 * r + 0.587 * g + 0.114 * b);
    }

    private static String baseName(String p) {
        String n = new File(p).getName();
        int dot = n.lastIndexOf('.');
        return dot > 0 ? n.substring(0, dot) : n;
    }

    private static void savePng(String art, Path out, Opt o) throws IOException {
        String[] lines = art.split("\n", -1);
        int rows = Math.max(1, lines.length - 1);
        int cols = 1;
        for (String l : lines) cols = Math.max(cols, l.length());
        int cw = 9, ch = 16;
        BufferedImage im = new BufferedImage(cols * cw + 8, rows * ch + 8, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = im.createGraphics();
        g.setColor(new Color(o.saveBg[0], o.saveBg[1], o.saveBg[2], o.saveBg[3]));
        g.fillRect(0, 0, im.getWidth(), im.getHeight());
        g.setColor(new Color(o.fontColor[0], o.fontColor[1], o.fontColor[2]));
        g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        FontMetrics fm = g.getFontMetrics();
        for (int i = 0; i < rows; i++) g.drawString(lines[i], 4, 4 + (i + 1) * fm.getAscent());
        g.dispose();
        Files.createDirectories(out.getParent() == null ? Paths.get(".") : out.getParent());
        ImageIO.write(im, "png", out.toFile());
    }

    private static void printFormats() {
        System.out.println("Supported input formats:");
        System.out.println();
        System.out.println("JPEG/JPG");
        System.out.println("PNG");
        System.out.println("WEBP");
        System.out.println("BMP");
        System.out.println("TIFF/TIF");
        System.out.println("GIF");
        System.out.println();
    }

    private static void printHelp() {
        System.out.print(HELP);
    }

    private static void printHelpUsage() {
        System.out.print(HELP.substring(HELP.indexOf("Usage:")));
    }

    private static final String HELP =
            "This tool converts images into ascii art and prints them on the terminal.\n" +
            "Further configuration can be managed with flags.\n\n" +
            "Usage:\n" +
            "  ascii-image-converter [image paths/urls or piped stdin] [flags]\n\n" +
            "Flags:\n" +
            "  -C, --color             Display ascii art with original colors\n" +
            "                          If 24-bit colors aren't supported, uses 8-bit\n" +
            "                          (Inverts with --negative flag)\n" +
            "                          (Overrides --grayscale and --font-color flags)\n" +
            "                          \n" +
            "      --color-bg          If some color flag is passed, use that color\n" +
            "                          on character background instead of foreground\n" +
            "                          (Inverts with --negative flag)\n" +
            "                          (Only applicable for terminal display)\n" +
            "                          \n" +
            "  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length\n" +
            "                          e.g. -d 60,30 (defaults to terminal height)\n" +
            "                          (Overrides --width and --height flags)\n" +
            "                          \n" +
            "  -W, --width int         Set width for ascii art in CHARACTER length\n" +
            "                          Height is kept to aspect ratio\n" +
            "                          e.g. -W 60\n" +
            "                          \n" +
            "  -H, --height int        Set height for ascii art in CHARACTER length\n" +
            "                          Width is kept to aspect ratio\n" +
            "                          e.g. -H 60\n" +
            "                          \n" +
            "  -m, --map string        Give custom ascii characters to map against\n" +
            "                          Ordered from darkest to lightest\n" +
            "                          e.g. -m \" .-+#@\" (Quotation marks excluded from map)\n" +
            "                          (Overrides --complex flag)\n" +
            "                          \n" +
            "  -b, --braille           Use braille characters instead of ascii\n" +
            "                          Terminal must support braille patterns properly\n" +
            "                          (Overrides --complex and --map flags)\n" +
            "                          \n" +
            "      --threshold int     Threshold for braille art\n" +
            "                          Value between 0-255 is accepted\n" +
            "                          e.g. --threshold 170\n" +
            "                          (Defaults to 128)\n" +
            "                          \n" +
            "      --dither            Apply dithering on image for braille\n" +
            "                          art conversion\n" +
            "                          (Only applicable with --braille flag)\n" +
            "                          (Negates --threshold flag)\n" +
            "                          \n" +
            "  -g, --grayscale         Display grayscale ascii art\n" +
            "                          (Inverts with --negative flag)\n" +
            "                          (Overrides --font-color flag)\n" +
            "                          \n" +
            "  -c, --complex           Display ascii characters in a larger range\n" +
            "                          May result in higher quality\n" +
            "                          \n" +
            "  -f, --full              Use largest dimensions for ascii art\n" +
            "                          that fill the terminal width\n" +
            "                          (Overrides --dimensions, --width and --height flags)\n" +
            "                          \n" +
            "  -n, --negative          Display ascii art in negative colors\n" +
            "                          \n" +
            "  -x, --flipX             Flip ascii art horizontally\n" +
            "                          \n" +
            "  -y, --flipY             Flip ascii art vertically\n" +
            "                          \n" +
            "  -s, --save-img string   Save ascii art as a .png file\n" +
            "                          Format: <image-name>-ascii-art.png\n" +
            "                          Image will be saved in passed path\n" +
            "                          (pass . for current directory)\n" +
            "                          \n" +
            "      --save-txt string   Save ascii art as a .txt file\n" +
            "                          Format: <image-name>-ascii-art.txt\n" +
            "                          File will be saved in passed path\n" +
            "                          (pass . for current directory)\n" +
            "                          \n" +
            "      --save-gif string   If input is a gif, save it as a .gif file\n" +
            "                          Format: <gif-name>-ascii-art.gif\n" +
            "                          Gif will be saved in passed path\n" +
            "                          (pass . for current directory)\n" +
            "                          \n" +
            "      --save-bg ints      Set background color for --save-img\n" +
            "                          and --save-gif flags\n" +
            "                          Pass an RGBA value\n" +
            "                          e.g. --save-bg 255,255,255,100\n" +
            "                          (Defaults to 0,0,0,100)\n" +
            "                          \n" +
            "      --font string       Set font for --save-img and --save-gif flags\n" +
            "                          Pass file path to font .ttf file\n" +
            "                          e.g. --font ./RobotoMono-Regular.ttf\n" +
            "                          (Defaults to Hack-Regular for ascii and\n" +
            "                           DejaVuSans-Oblique for braille)\n" +
            "                          \n" +
            "      --font-color ints   Set font color for terminal as well as\n" +
            "                          --save-img and --save-gif flags\n" +
            "                          Pass an RGB value\n" +
            "                          e.g. --font-color 0,0,0\n" +
            "                          (Defaults to 255,255,255)\n" +
            "                          \n" +
            "      --only-save         Don't print ascii art on terminal\n" +
            "                          if some saving flag is passed\n" +
            "                          \n" +
            "      --formats           Display supported input formats\n" +
            "                          \n" +
            "  -h, --help              Help for ascii-image-converter\n" +
            "                          \n" +
            "  -v, --version           Version for ascii-image-converter\n\n" +
            "Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>\n" +
            "Distributed under the Apache License Version 2.0 (Apache-2.0)\n" +
            "For further details, visit https://github.com/TheZoraiz/ascii-image-converter\n";
}
