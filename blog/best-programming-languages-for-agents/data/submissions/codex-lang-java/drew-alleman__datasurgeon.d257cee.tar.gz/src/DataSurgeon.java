import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;

public class DataSurgeon {
    static class Opts {
        String file = "";
        String directory = "";
        String output = "";
        String drop = "";
        String filter = "";
        String add = "";
        String update = "";
        String remove = "";
        boolean list, clean, ignore, line, thorough, display, suppress, hide, time, help, version;
        Set<String> selected = new HashSet<>();
    }

    static class Extractor {
        final String key, label, shortOpt, longOpt;
        final Pattern pattern;
        Extractor(String key, String label, String shortOpt, String longOpt, String regex) {
            this.key = key;
            this.label = label;
            this.shortOpt = shortOpt;
            this.longOpt = longOpt;
            this.pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        }
    }

    static final String PLUGIN = "Failed to open plugins.json file. PLUGIN_PATH: /home/agent/.DataSurgeon/plugins.json";
    static final List<Extractor> EXTRACTORS = List.of(
        new Extractor("c", "credit_card", "c", "credit-card", "\\b(?:\\d[ -]*?){13,19}\\b"),
        new Extractor("m", "mac_address", "m", "mac-addr", "\\b[0-9a-f]{2}(?::[0-9a-f]{2}){5}\\b"),
        new Extractor("F", "files", "F", "files", "(?:^|[/\\\\]|(?<![@A-Za-z0-9_.:/-]))([A-Za-z0-9_ -]+\\.(?:txt|pdf|docx?|xlsx?|pptx?|csv|json|xml|ya?ml|html?|php|asp|aspx|jsp|js|ts|css|py|rb|go|rs|java|cpp|hpp|sh|bash|ps1|exe|dll|dylib|zip|rar|tar|jpg|jpeg|png|gif|bmp|svg|log|conf|ini|sql))\\b"),
        new Extractor("H", "hashes", "H", "hash", "\\b(?:[a-f0-9]{32}|[a-f0-9]{40}|[a-f0-9]{56}|[a-f0-9]{64}|[a-f0-9]{96}|[a-f0-9]{128})\\b|\\$2[abyx]?\\$\\d{2}\\$[./A-Za-z0-9]{53}"),
        new Extractor("u", "url", "u", "url", "\\b(?:https?|ftp)://[^\\s\"'<>]+"),
        new Extractor("i", "ip_address", "i", "ip-addr", "\\b(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\b"),
        new Extractor("6", "ipv6_address", "6", "ipv6-addr", "\\b(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}\\b"),
        new Extractor("b", "bitcoin_wallet", "b", "bitcoin", "\\b(?:bc1[ac-hj-np-z02-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\\b"),
        new Extractor("e", "email", "e", "email", "\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b"),
        new Extractor("a", "aws", "a", "aws", "\\baws_(?:access_key_id|secret_access_key)\\s*[:=]\\s*([A-Z0-9/+=]{20,40})\\b"),
        new Extractor("g", "google", "g", "google", "\"?private_key_id\"?\\s*[:=]\\s*\"?([a-f0-9]{40})\"?"),
        new Extractor("d", "dns", "d", "dns", "\\b(?:A|AAAA|CNAME|MX|NS|TXT|SOA|PTR)\\s+((?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:com|net|org|edu|gov|mil|io|co|uk|de|jp|fr|au|us|ru|ch|it|nl|se|no|es|me|info|biz|dev|app))\\b"),
        new Extractor("s", "social_security", "s", "social", "\\b\\d{3}-\\d{2}-\\d{4}\\b"),
        new Extractor("p", "phone_number", "p", "phone", "\\b\\d{3}-\\d{3}-\\d{4}\\b")
    );

    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        Opts o;
        try {
            o = parse(args);
        } catch (IllegalArgumentException ex) {
            System.out.println(PLUGIN);
            System.err.println(ex.getMessage());
            System.exit(2);
            return;
        }
        System.out.println(PLUGIN);
        if (o.help) { printHelp(); return; }
        if (o.version) { System.out.println("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8"); return; }
        if (o.list) { System.out.println("No plugins found. Plugin File: /home/agent/.DataSurgeon/plugins.json"); return; }
        if (!o.add.isEmpty()) { System.out.println("[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base"); return; }
        if (!o.update.isEmpty() || !o.remove.isEmpty()) { System.out.println(PLUGIN); return; }

        List<String> output = new ArrayList<>();
        int code = 0;
        try {
            process(o, output);
        } catch (Exception ex) {
            if (!o.ignore) {
                System.out.println("[-] " + ex.getMessage());
                code = 1;
            }
        }
        if (o.time) output.add("[*] Time elapsed: " + formatElapsed(System.currentTimeMillis() - start));
        try {
            if (!o.output.isEmpty()) {
                try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(o.output), StandardCharsets.UTF_8)) {
                    for (String s : output) { bw.write(s); bw.newLine(); }
                }
            } else {
                for (String s : output) System.out.println(s);
            }
        } catch (IOException ex) {
            if (!o.ignore) {
                System.out.println("[-] " + ex.getMessage());
                code = 1;
            }
        }
        if (code != 0) System.exit(code);
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--help") || a.equals("-h")) o.help = true;
            else if (a.equals("--version") || a.equals("-V")) o.version = true;
            else if (a.equals("--list")) o.list = true;
            else if (a.equals("--file") || a.equals("-f")) o.file = need(args, ++i, a);
            else if (a.equals("--directory")) o.directory = need(args, ++i, a);
            else if (a.equals("--output") || a.equals("-o")) o.output = need(args, ++i, a);
            else if (a.equals("--drop")) o.drop = need(args, ++i, a);
            else if (a.equals("--filter")) o.filter = need(args, ++i, a);
            else if (a.equals("--add")) o.add = need(args, ++i, a);
            else if (a.equals("--update")) o.update = need(args, ++i, a);
            else if (a.equals("--remove")) o.remove = need(args, ++i, a);
            else if (a.startsWith("--")) setLong(o, a.substring(2));
            else if (a.startsWith("-") && a.length() > 1) {
                for (int j = 1; j < a.length(); j++) setShort(o, a.charAt(j));
            } else throw new IllegalArgumentException("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.");
        }
        return o;
    }

    static String need(String[] args, int idx, String opt) {
        if (idx >= args.length) throw new IllegalArgumentException("error: a value is required for '" + opt + "'");
        return args[idx];
    }

    static void setLong(Opts o, String s) {
        switch (s) {
            case "clean" -> o.clean = true;
            case "ignore" -> o.ignore = true;
            case "line" -> o.line = true;
            case "thorough" -> o.thorough = true;
            case "display" -> o.display = true;
            case "suppress" -> o.suppress = true;
            case "hide" -> o.hide = true;
            case "time" -> o.time = true;
            case "email" -> o.selected.add("e");
            case "phone" -> o.selected.add("p");
            case "hash" -> o.selected.add("H");
            case "ip-addr" -> o.selected.add("i");
            case "ipv6-addr" -> o.selected.add("6");
            case "mac-addr" -> o.selected.add("m");
            case "credit-card" -> o.selected.add("c");
            case "url" -> o.selected.add("u");
            case "files" -> o.selected.add("F");
            case "bitcoin" -> o.selected.add("b");
            case "aws" -> o.selected.add("a");
            case "google" -> o.selected.add("g");
            case "dns" -> o.selected.add("d");
            case "social" -> o.selected.add("s");
            default -> throw new IllegalArgumentException("error: unexpected argument '--" + s + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.");
        }
    }

    static void setShort(Opts o, char c) {
        switch (c) {
            case 'C' -> o.clean = true;
            case 'l' -> o.line = true;
            case 'T' -> o.thorough = true;
            case 'D' -> o.display = true;
            case 'S' -> o.suppress = true;
            case 'X' -> o.hide = true;
            case 't' -> o.time = true;
            case 'e','p','H','i','6','m','c','u','F','b','a','g','d','s' -> o.selected.add(String.valueOf(c));
            default -> throw new IllegalArgumentException("error: unexpected argument '-" + c + "' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.");
        }
    }

    static void process(Opts o, List<String> out) throws IOException {
        Pattern filter = compileOptional(o.filter);
        Pattern drop = compileOptional(o.drop);
        if (!o.directory.isEmpty()) {
            Path root = Paths.get(o.directory);
            if (!Files.exists(root)) throw new IOException("Directory not found: " + o.directory);
            try (Stream<Path> st = Files.walk(root)) {
                List<Path> paths = st.filter(Files::isRegularFile).sorted(Comparator.comparing(Path::toString)).toList();
                for (Path p : paths) readLines(o, p, p.toString().replace('\\', '/'), filter, drop, out);
            }
        } else if (!o.file.isEmpty()) {
            Path p = Paths.get(o.file);
            if (!Files.exists(p)) throw new IOException("File not found: " + o.file);
            readLines(o, p, o.file, filter, drop, out);
        } else {
            if (!o.suppress) System.out.println("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)");
            try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8))) {
                String line; int n = 1;
                while ((line = br.readLine()) != null) handleLine(o, line, "", n++, filter, drop, out);
            }
        }
    }

    static Pattern compileOptional(String s) {
        if (s == null || s.isEmpty()) return null;
        try { return Pattern.compile(s); } catch (PatternSyntaxException ex) { return null; }
    }

    static void readLines(Opts o, Path p, String name, Pattern filter, Pattern drop, List<String> out) throws IOException {
        try (BufferedReader br = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            String line; int n = 1;
            while ((line = br.readLine()) != null) handleLine(o, line, name, n++, filter, drop, out);
        }
    }

    static void handleLine(Opts o, String line, String file, int lineNo, Pattern filter, Pattern drop, List<String> out) {
        if (filter != null && !filter.matcher(line).find()) return;
        for (Extractor ex : EXTRACTORS) {
            if (!o.selected.isEmpty() && !o.selected.contains(ex.key)) continue;
            Matcher m = ex.pattern.matcher(line);
            boolean any = false;
            while (m.find()) {
                String match = m.groupCount() >= 1 && m.group(1) != null ? m.group(1) : m.group();
                if (drop != null && drop.matcher(match).find()) {
                    if (!o.thorough) break;
                    continue;
                }
                out.add(format(o, ex.label, o.clean ? match : line, file, lineNo));
                any = true;
                if (!o.thorough) break;
            }
            if (any && !o.thorough) {
                // The original stops after the first match for each extractor, not for the whole line.
            }
        }
    }

    static String format(Opts o, String label, String value, String file, int lineNo) {
        if (!o.display && !o.line) {
            return (o.hide ? "" : label + ": ") + value;
        }
        StringBuilder sb = new StringBuilder();
        if (!o.hide) sb.append(label).append(", ");
        if (o.display) sb.append("file: ").append(file).append(" ");
        sb.append(value);
        if (o.line) sb.append(", line: ").append(lineNo);
        return sb.toString();
    }

    static String formatElapsed(long ms) {
        long s = ms / 1000;
        long h = s / 3600; s %= 3600;
        long m = s / 60; s %= 60;
        return String.format("%02dh:%02dm:%02ds", h, m, s);
    }

    static void printHelp() {
        System.out.println("Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS]");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -f, --file <file>            File to extract information from [default: \"\"]");
        System.out.println("      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: \"\"]");
        System.out.println("      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: \"\"]");
        System.out.println("      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: \"\"]");
        System.out.println("      --list                   List all added plugins");
        System.out.println("  -C, --clean                  Only displays the matched result, rather than the entire line");
        System.out.println("      --directory <directory>  Process all files found in the specified directory [default: \"\"]");
        System.out.println("      --ignore                 Silences error messages");
        System.out.println("  -l, --line                   Displays the line number where the match occurred");
        System.out.println("  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line");
        System.out.println("  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)");
        System.out.println("  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file");
        System.out.println("      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop \"^.{1,10}$\" will hide all matches not under 10 characters) [default: \"\"]");
        System.out.println("      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: \"\"]");
        System.out.println("  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.");
        System.out.println("  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: \"\"]");
        System.out.println("  -t, --time                   Time how long the operation took");
        System.out.println("  -e, --email                  Extract email addresses");
        System.out.println("  -p, --phone                  Extracts phone numbers");
        System.out.println("  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)");
        System.out.println("  -i, --ip-addr                Extract IP addresses");
        System.out.println("  -6, --ipv6-addr              Extract IPv6 addresses");
        System.out.println("  -m, --mac-addr               Extract MAC addresses");
        System.out.println("  -c, --credit-card            Extract credit card numbers");
        System.out.println("  -u, --url                    Extract urls");
        System.out.println("  -F, --files                  Extract filenames");
        System.out.println("  -b, --bitcoin                Extract bitcoin wallets");
        System.out.println("  -a, --aws                    Extract AWS keys");
        System.out.println("  -g, --google                 Extract Google service account private key ids (used for google automations services)");
        System.out.println("  -d, --dns                    Extract Domain Name System records");
        System.out.println("  -s, --social                 Extract social security numbers");
        System.out.println("  -h, --help                   Print help");
        System.out.println("  -V, --version                Print version");
    }
}
