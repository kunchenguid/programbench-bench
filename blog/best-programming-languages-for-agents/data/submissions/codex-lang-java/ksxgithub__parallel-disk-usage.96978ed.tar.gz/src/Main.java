import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

public class Main {
    static final String VERSION = "0.21.1";
    static class Options {
        boolean jsonInput, jsonOutput, dedupe, topDown, alignRight, noSort, silent, omitDetails, omitSummary;
        String bytesFormat = "metric", quantity = "block-size", threads = "auto";
        int maxDepth = 10;
        Integer totalWidth = null, treeWidth = null, barWidth = null;
        double minRatio = 0.01;
        List<String> files = new ArrayList<>();
    }
    static class Node {
        String name, path, inoKey;
        long size, ownSize, links;
        boolean dir;
        List<Node> children = new ArrayList<>();
        Node parent;
        Node(String name) { this.name = name; }
    }
    static class LinkInfo {
        long ino, size, links;
        List<String> paths = new ArrayList<>();
    }

    public static void main(String[] args) throws Exception {
        Options o;
        try { o = parse(args); } catch (IllegalArgumentException e) {
            System.err.println("error: " + e.getMessage());
            System.err.println("\nFor more information, try '--help'.");
            System.exit(2); return;
        }
        if (o == null) return;
        Node root;
        Map<String, LinkInfo> linkMap = new LinkedHashMap<>();
        if (o.jsonInput) {
            String input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
            root = new JsonParser(input).parseRoot();
        } else {
            if (o.files.isEmpty()) o.files.add(".");
            List<Node> roots = new ArrayList<>();
            for (String f : o.files) {
                Node n = scan(Paths.get(f), f, o, linkMap);
                roots.add(n);
            }
            if (roots.size() == 1) root = roots.get(0);
            else {
                root = new Node("(total)");
                root.dir = true;
                for (Node n : roots) { n.parent = root; root.children.add(n); root.size += n.size; }
            }
            if (!o.noSort) sortTree(root);
            if (o.dedupe) applyDedupe(root, linkMap, o);
        }
        prune(root, 1, o.maxDepth, root.size, o.minRatio);
        if (o.jsonOutput) System.out.println(toJson(root, o, linkMap));
        else printChart(root, o);
    }

    static Options parse(String[] args) {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            String v = null;
            int eq = a.indexOf('=');
            if (eq > 0) { v = a.substring(eq + 1); a = a.substring(0, eq); }
            switch (a) {
                case "-h": printShortHelp(); return null;
                case "--help": printLongHelp(); return null;
                case "-V": case "--version": System.out.println("pdu " + VERSION); return null;
                case "--json-input": o.jsonInput = true; break;
                case "--json-output": o.jsonOutput = true; break;
                case "-H": case "--deduplicate-hardlinks": case "--detect-links": case "--dedupe-links": o.dedupe = true; break;
                case "--top-down": o.topDown = true; break;
                case "--align-right": o.alignRight = true; break;
                case "--no-sort": o.noSort = true; break;
                case "-s": case "--silent-errors": case "--no-errors": o.silent = true; break;
                case "-p": case "--progress": break;
                case "--omit-json-shared-details": o.omitDetails = true; break;
                case "--omit-json-shared-summary": o.omitSummary = true; break;
                case "-b": case "--bytes-format": o.bytesFormat = val(args, i, v, a); if (v == null) i++; check(o.bytesFormat, "plain","metric","binary"); break;
                case "-q": case "--quantity": o.quantity = val(args, i, v, a); if (v == null) i++; check(o.quantity, "apparent-size","block-size","block-count"); break;
                case "-d": case "--max-depth": case "--depth": {
                    String s = val(args, i, v, a); if (v == null) i++;
                    o.maxDepth = s.equals("inf") ? Integer.MAX_VALUE : Integer.parseInt(s);
                    if (o.maxDepth < 1) throw new IllegalArgumentException("invalid value '" + s + "' for '" + a + "'");
                    break;
                }
                case "-w": case "--total-width": o.totalWidth = Integer.parseInt(val(args, i, v, a)); if (v == null) i++; break;
                case "--column-width":
                    if (v != null) o.treeWidth = Integer.parseInt(v);
                    else {
                        if (i + 1 >= args.length) throw new IllegalArgumentException("a value is required for '" + a + "'");
                        o.treeWidth = Integer.parseInt(args[++i]);
                    }
                    if (i + 1 >= args.length) throw new IllegalArgumentException("a value is required for '" + a + "'");
                    o.barWidth = Integer.parseInt(args[++i]);
                    break;
                case "-m": case "--min-ratio": o.minRatio = Double.parseDouble(val(args, i, v, a)); if (v == null) i++; break;
                case "--threads": o.threads = val(args, i, v, a); if (v == null) i++; break;
                default:
                    if (a.startsWith("-")) throw new IllegalArgumentException("unexpected argument '" + a + "' found");
                    o.files.add(args[i]);
            }
        }
        return o;
    }
    static String val(String[] args, int current, String inline, String name) {
        if (inline != null) return inline;
        int idx = current + 1;
        if (idx >= args.length) throw new IllegalArgumentException("a value is required for '" + name + "'");
        return args[idx];
    }
    static void check(String s, String... vals) {
        for (String v : vals) if (v.equals(s)) return;
        throw new IllegalArgumentException("invalid value '" + s + "'");
    }

    static Node scan(Path p, String display, Options o, Map<String, LinkInfo> links) {
        Node n = new Node(display);
        n.path = display;
        try {
            Map<String,Object> at = Files.readAttributes(p, "unix:*", LinkOption.NOFOLLOW_LINKS);
            boolean isDir = Boolean.TRUE.equals(at.get("isDirectory"));
            n.dir = isDir;
            long apparent = num(at.get("size"));
            long blocks = statBlocks(p);
            n.links = num(at.get("nlink"));
            long ino = num(at.get("ino"));
            long dev = num(at.get("dev"));
            if (o.quantity.equals("apparent-size")) n.ownSize = apparent;
            else if (o.quantity.equals("block-count")) n.ownSize = blocks;
            else n.ownSize = blocks * 512L;
            n.size = n.ownSize;
            n.inoKey = dev + ":" + ino;
            if (o.dedupe && n.links > 1 && !isDir) {
                LinkInfo li = links.computeIfAbsent(n.inoKey, k -> { LinkInfo x = new LinkInfo(); x.ino = ino; x.size = n.ownSize; x.links = n.links; return x; });
                li.paths.add(display);
            }
            if (isDir) {
                try (DirectoryStream<Path> ds = Files.newDirectoryStream(p)) {
                    for (Path c : ds) {
                        Node child = scan(c, display.equals(".") ? c.getFileName().toString() : display + "/" + c.getFileName(), o, links);
                        child.name = c.getFileName().toString();
                        child.parent = n;
                        n.children.add(child);
                        n.size += child.size;
                    }
                }
            }
        } catch (Exception e) {
            n.size = 0; n.ownSize = 0;
            if (!o.silent) System.err.println("[error] symlink_metadata \"" + display + "\": " + errorText(e));
        }
        return n;
    }
    static long num(Object o) { return o instanceof Number ? ((Number)o).longValue() : 0L; }
    static long statBlocks(Path p) {
        try {
            Process pr = new ProcessBuilder("stat", "-c", "%b", p.toString()).redirectErrorStream(true).start();
            String out = new String(pr.getInputStream().readAllBytes(), StandardCharsets.UTF_8).trim();
            if (pr.waitFor() == 0 && !out.isEmpty()) return Long.parseLong(out.split("\\s+")[0]);
        } catch (Exception ignored) {}
        return 0L;
    }
    static String errorText(Exception e) {
        if (e instanceof NoSuchFileException) return e.getMessage() + ": No such file or directory (os error 2)";
        if (e instanceof AccessDeniedException) return e.getMessage() + ": Permission denied (os error 13)";
        return e.getMessage() == null ? e.toString() : e.getMessage();
    }

    static void sortTree(Node n) {
        n.children.sort((a,b) -> {
            int c = Long.compare(b.size, a.size);
            if (c != 0) return c;
            return b.name.compareTo(a.name);
        });
        for (Node c : n.children) sortTree(c);
    }

    static void applyDedupe(Node root, Map<String, LinkInfo> links, Options o) {
        for (LinkInfo li : links.values()) {
            if (li.paths.size() <= 1) continue;
            long subtract = li.size * (li.paths.size() - 1);
            root.size -= subtract;
        }
    }

    static void prune(Node n, int depth, int maxDepth, long total, double minRatio) {
        if (depth >= maxDepth) { n.children.clear(); return; }
        Iterator<Node> it = n.children.iterator();
        while (it.hasNext()) {
            Node c = it.next();
            if (total > 0 && c.size / (double) total < minRatio) { it.remove(); continue; }
            prune(c, depth + 1, maxDepth, total, minRatio);
        }
    }

    static String toJson(Node root, Options o, Map<String,LinkInfo> links) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"schema-version\":\"2024-11-02\",\"pdu\":\"").append(VERSION)
          .append("\",\"unit\":\"").append(o.quantity.equals("block-count") ? "blocks" : "bytes")
          .append("\",\"tree\":");
        nodeJson(sb, root);
        if (o.dedupe) {
            List<LinkInfo> shared = new ArrayList<>();
            for (LinkInfo li : links.values()) if (li.paths.size() > 1) shared.add(li);
            if (!shared.isEmpty()) {
                sb.append(",\"shared\":{");
                boolean comma = false;
                if (!o.omitDetails) {
                    sb.append("\"details\":[");
                    for (int i=0;i<shared.size();i++) {
                        LinkInfo li=shared.get(i); if(i>0) sb.append(',');
                        sb.append("{\"ino\":").append(li.ino).append(",\"size\":").append(li.size)
                          .append(",\"links\":").append(li.links).append(",\"paths\":[");
                        for(int j=0;j<li.paths.size();j++){ if(j>0) sb.append(','); str(sb, li.paths.get(j)); }
                        sb.append("]}");
                    }
                    sb.append("]"); comma = true;
                }
                if (!o.omitSummary) {
                    if (comma) sb.append(',');
                    long inodes=shared.size(), all=0, detected=0, size=0;
                    for(LinkInfo li:shared){ all += li.links; detected += li.paths.size(); size += li.size; }
                    sb.append("\"summary\":{\"inodes\":").append(inodes)
                      .append(",\"exclusive_inodes\":").append(inodes)
                      .append(",\"all_links\":").append(all)
                      .append(",\"detected_links\":").append(detected)
                      .append(",\"exclusive_links\":").append(detected)
                      .append(",\"shared_size\":").append(size)
                      .append(",\"exclusive_shared_size\":").append(size).append("}");
                }
                sb.append("}");
            }
        }
        sb.append("}");
        return sb.toString();
    }
    static void nodeJson(StringBuilder sb, Node n) {
        sb.append("{\"name\":"); str(sb, n.name); sb.append(",\"size\":").append(n.size).append(",\"children\":[");
        for (int i=0;i<n.children.size();i++) { if (i>0) sb.append(','); nodeJson(sb, n.children.get(i)); }
        sb.append("]}");
    }
    static void str(StringBuilder sb, String s) {
        sb.append('"');
        for(char ch: s.toCharArray()) {
            switch(ch){case '\\':sb.append("\\\\");break;case '"':sb.append("\\\"");break;case '\n':sb.append("\\n");break;case '\r':sb.append("\\r");break;case '\t':sb.append("\\t");break;default: if(ch<32) sb.append(String.format("\\u%04x",(int)ch)); else sb.append(ch);}
        }
        sb.append('"');
    }

    static void printChart(Node root, Options o) {
        List<Node> rows = new ArrayList<>();
        if (o.topDown) pre(root, rows); else post(root, rows);
        int sizeW = 0, treeW = 0;
        Map<Node,String> labels = new IdentityHashMap<>();
        for (Node n: rows) {
            sizeW = Math.max(sizeW, fmt(n.size, o.bytesFormat).length());
            String lab = treeLabel(n, o.topDown); labels.put(n, lab); treeW = Math.max(treeW, lab.length());
        }
        if (o.treeWidth != null) treeW = Math.min(treeW, o.treeWidth);
        int totalW = o.totalWidth == null ? 100 : o.totalWidth;
        int barW = o.barWidth != null ? o.barWidth : Math.max(1, totalW - sizeW - treeW - 8);
        for (Node n: rows) {
            String f = fmt(n.size, o.bytesFormat);
            String lab = labels.get(n);
            if (lab.length() > treeW) lab = lab.substring(0, treeW);
            int pct = root.size == 0 ? 0 : (int)Math.round(n.size * 100.0 / root.size);
            int fill = root.size == 0 ? 0 : (int)Math.round(n.size * barW / (double)root.size);
            if (fill > barW) fill = barW;
            String bar = "█".repeat(fill) + " ".repeat(Math.max(0, barW-fill));
            if (o.alignRight) bar = " ".repeat(Math.max(0, barW-fill)) + "█".repeat(fill);
            System.out.printf("%" + sizeW + "s %-" + treeW + "s │%s│%3d%%%n", f, lab, bar, pct);
        }
    }
    static void pre(Node n, List<Node> out) { out.add(n); for(Node c:n.children) pre(c,out); }
    static void post(Node n, List<Node> out) {
        List<Node> cs = new ArrayList<>(n.children); Collections.reverse(cs);
        for(Node c:cs) post(c,out); out.add(n);
    }
    static String treeLabel(Node n, boolean top) {
        List<Node> chain = new ArrayList<>();
        for(Node x=n; x.parent!=null; x=x.parent) chain.add(x);
        Collections.reverse(chain);
        StringBuilder sb = new StringBuilder();
        for(int i=0;i<chain.size()-1;i++) sb.append(isLast(chain.get(i)) ? "  " : "│ ");
        String mark = top ? (n.children.isEmpty() ? "──" : "─┬") : (n.children.isEmpty() ? "──" : "─┴");
        if (n.parent == null) sb.append(top ? "└" : "┌").append(mark).append(n.name);
        else sb.append(isLast(n) ? (top ? "└" : "┌") : "├").append(mark).append(n.name);
        return sb.toString();
    }
    static boolean isLast(Node n) { return n.parent != null && !n.parent.children.isEmpty() && n.parent.children.get(n.parent.children.size()-1)==n; }
    static String fmt(long v, String mode) {
        if (mode.equals("plain")) return Long.toString(v);
        int base = mode.equals("binary") ? 1024 : 1000;
        if (v < base) return Long.toString(v);
        String[] u = {"K","M","G","T","P","E"};
        double d = v; int i=-1; while(d>=base && i<u.length-1){d/=base;i++;}
        return String.format(Locale.ROOT, "%.1f%s", d, u[i]);
    }

    static class JsonParser {
        final String s; int i;
        JsonParser(String s){this.s=s;}
        Node parseRoot(){ Object o=parseValue(); Object t=((Map<?,?>)o).get("tree"); return toNode((Map<?,?>)t, null); }
        Node toNode(Map<?,?> m, Node p){ Node n=new Node((String)m.get("name")); n.parent=p; n.size=((Number)m.get("size")).longValue(); List<?> ch=(List<?>)m.get("children"); if(ch!=null) for(Object x:ch)n.children.add(toNode((Map<?,?>)x,n)); return n; }
        Object parseValue(){ ws(); char c=s.charAt(i); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='"')return string(); if(c=='t'){i+=4;return true;} if(c=='f'){i+=5;return false;} if(c=='n'){i+=4;return null;} return number(); }
        Map<String,Object> obj(){ i++; Map<String,Object> m=new LinkedHashMap<>(); ws(); if(s.charAt(i)=='}'){i++;return m;} while(true){String k=string(); ws(); i++; Object v=parseValue(); m.put(k,v); ws(); char c=s.charAt(i++); if(c=='}')return m; } }
        List<Object> arr(){ i++; List<Object> l=new ArrayList<>(); ws(); if(s.charAt(i)==']'){i++;return l;} while(true){l.add(parseValue()); ws(); char c=s.charAt(i++); if(c==']')return l; } }
        String string(){ i++; StringBuilder b=new StringBuilder(); while(true){char c=s.charAt(i++); if(c=='"')return b.toString(); if(c=='\\'){char e=s.charAt(i++); if(e=='n')b.append('\n'); else if(e=='r')b.append('\r'); else if(e=='t')b.append('\t'); else if(e=='u'){b.append((char)Integer.parseInt(s.substring(i,i+4),16)); i+=4;} else b.append(e);} else b.append(c);} }
        Number number(){ int st=i; while(i<s.length() && "-+.0123456789eE".indexOf(s.charAt(i))>=0)i++; String n=s.substring(st,i); return n.contains(".")||n.contains("e")||n.contains("E")?Double.parseDouble(n):Long.parseLong(n); }
        void ws(){ while(i<s.length() && Character.isWhitespace(s.charAt(i)))i++; }
    }

    static void printShortHelp() {
        System.out.println("Summarize disk usage of the set of files, recursively for directories.\n\nUsage: executable [OPTIONS] [FILES]...\n\nArguments:\n  [FILES]...  List of files and/or directories\n\nOptions:\n      --json-input\n          Read JSON data from stdin\n      --json-output\n          Print JSON data instead of an ASCII chart\n  -b, --bytes-format <BYTES_FORMAT>\n          How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]\n  -H, --deduplicate-hardlinks\n          Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]\n      --top-down\n          Print the tree top-down instead of bottom-up\n      --align-right\n          Set the root of the bars to the right\n  -q, --quantity <QUANTITY>\n          Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]\n  -d, --max-depth <MAX_DEPTH>\n          Maximum depth to display the data. Could be either \"inf\" or a positive integer [default: 10] [aliases: --depth]\n  -w, --total-width <TOTAL_WIDTH>\n          Width of the visualization [aliases: --width]\n      --column-width <TREE_WIDTH> <BAR_WIDTH>\n          Maximum widths of the tree column and width of the bar column\n  -m, --min-ratio <MIN_RATIO>\n          Minimal size proportion required to appear [default: 0.01]\n      --no-sort\n          Do not sort the branches in the tree\n  -s, --silent-errors\n          Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]\n  -p, --progress\n          Report progress being made at the expense of performance\n      --threads <THREADS>\n          Set the maximum number of threads to spawn. Could be either \"auto\", \"max\", or a positive integer [default: auto]\n      --omit-json-shared-details\n          Do not output `.shared.details` in the JSON output\n      --omit-json-shared-summary\n          Do not output `.shared.summary` in the JSON output\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version");
    }
    static void printLongHelp() { printShortHelp(); System.out.println("\nExamples:\n    Show disk usage chart of current working directory\n    $ pdu\n\n    Show disk usage chart of a single file or directory\n    $ pdu path/to/file/or/directory\n\n    Compare disk usages of multiple files and/or directories\n    $ pdu file.txt dir/\n\n    Show chart in apparent sizes instead of block sizes\n    $ pdu --quantity=apparent-size\n\n    Detect and subtract the sizes of hardlinks from their parent nodes\n    $ pdu --deduplicate-hardlinks\n\n    Show sizes in plain numbers instead of metric units\n    $ pdu --bytes-format=plain\n\n    Show sizes in base 2¹⁰ units (binary) instead of base 10³ units (metric)\n    $ pdu --bytes-format=binary\n\n    Show disk usage chart of all entries regardless of size\n    $ pdu --min-ratio=0\n\n    Only show disk usage chart of entries whose size is at least 5% of total\n    $ pdu --min-ratio=0.05\n\n    Show disk usage data as JSON instead of chart\n    $ pdu --min-ratio=0 --max-depth=inf --json-output | jq\n\n    Visualize existing JSON representation of disk usage data\n    $ pdu --json-input < disk-usage.json"); }
}
