package gittrim;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

public class Main {
    static final String LONG_HELP = """
Automatically trims your tracking branches whose upstream branches are merged or stray.
`git-trim` is a missing companion to the `git fetch --prune` and a proper, safer, faster alternative to your `<bash oneliner HERE>`.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
          
          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.

  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]

      --no-update
          Do not update remotes [config: trim.update]

      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

      --no-confirm
          Do not ask confirm [config: trim.confirm]

      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]

  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
          
          `merged` implies `merged-local,merged-remote`.
          
          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.

      --dry-run
          Do not delete branches, show what branches will be deleted

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
""";

    static final String SHORT_HELP = """
Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
""";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (GitException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        } catch (CliException e) {
            System.err.println(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        Options opt = parse(args);
        if (opt.version) {
            System.out.println("git-trim 0.4.4");
            return 0;
        }
        if (opt.helpLong) {
            System.out.print(LONG_HELP);
            return 0;
        }
        if (opt.helpShort) {
            System.out.print(SHORT_HELP);
            return 0;
        }
        ensureRepo();
        applyConfig(opt);
        if (opt.update) {
            updateRemotes();
        }
        Repo repo = loadRepo();
        List<Base> bases = resolveBases(opt, repo);
        if (bases.isEmpty()) {
            printNoBase();
            System.err.println("Error: No base branch is found!");
            return 1;
        }
        Plan plan = plan(opt, repo, bases);
        printPlan(plan, opt);
        if (plan.isEmpty()) {
            return 0;
        }
        if (opt.confirm && !opt.dryRun) {
            System.out.print("Delete these branches? [y/N] ");
            byte[] buf = new byte[16];
            int n = System.in.read(buf);
            String ans = n <= 0 ? "" : new String(buf, 0, n, StandardCharsets.UTF_8).trim();
            if (!ans.equalsIgnoreCase("y") && !ans.equalsIgnoreCase("yes")) {
                return 0;
            }
        }
        execute(plan, opt);
        return 0;
    }

    Options parse(String[] args) throws CliException {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h" -> o.helpShort = true;
                case "--help" -> o.helpLong = true;
                case "-V", "--version" -> o.version = true;
                case "--dry-run" -> o.dryRun = true;
                case "--no-update" -> o.update = false;
                case "--update" -> o.update = true;
                case "--no-confirm" -> o.confirm = false;
                case "--confirm" -> o.confirm = true;
                case "--no-detach" -> o.detach = false;
                case "--detach" -> o.detach = true;
                case "-b", "--bases" -> o.bases = need(args, ++i, a);
                case "-p", "--protected" -> o.protectedPatterns = split(need(args, ++i, a));
                case "--update-interval" -> {
                    String v = need(args, ++i, a);
                    try {
                        o.updateInterval = Long.parseLong(v);
                    } catch (NumberFormatException e) {
                        throw new CliException("error: invalid value '" + v + "' for '--update-interval <UPDATE_INTERVAL>': invalid digit found in string\n\nFor more information, try '--help'.");
                    }
                }
                case "-d", "--delete" -> {
                    o.deleteSpec = need(args, ++i, a);
                    o.deleteExplicit = true;
                }
                default -> {
                    if (a.startsWith("--bases=")) o.bases = a.substring(8);
                    else if (a.startsWith("--protected=")) o.protectedPatterns = split(a.substring(12));
                    else if (a.startsWith("--delete=")) {
                        o.deleteSpec = a.substring(9);
                        o.deleteExplicit = true;
                    }
                    else if (a.startsWith("--update-interval=")) {
                        String v = a.substring(18);
                        try { o.updateInterval = Long.parseLong(v); }
                        catch (NumberFormatException e) { throw new CliException("error: invalid value '" + v + "' for '--update-interval <UPDATE_INTERVAL>': invalid digit found in string\n\nFor more information, try '--help'."); }
                    } else {
                        throw new CliException("error: unexpected argument '" + a + "' found\n\nFor more information, try '--help'.");
                    }
                }
            }
        }
        if (o.deleteExplicit) parseDelete(o);
        return o;
    }

    static String need(String[] args, int i, String flag) throws CliException {
        if (i >= args.length) throw new CliException("error: a value is required for '" + flag + "' but none was supplied\n\nFor more information, try '--help'.");
        return args[i];
    }

    void parseDelete(Options o) throws CliException {
        String spec = o.deleteSpec;
        if (spec == null || spec.isBlank()) spec = "merged:origin";
        for (String item : split(spec)) {
            String[] p = item.split(":", -1);
            String kind = p[0];
            String remote = p.length > 1 ? p[1] : "";
            if (p.length > 2 || kind.isEmpty()) throw badDelete(item);
            switch (kind) {
                case "merged" -> {
                    if (remote.isEmpty()) throw badDelete(item);
                    o.deleteMergedLocal = true;
                    o.mergedRemote.add(remote);
                }
                case "merged-local" -> {
                    if (!remote.isEmpty()) throw badDelete(item);
                    o.deleteMergedLocal = true;
                }
                case "merged-remote" -> {
                    if (remote.isEmpty()) throw badDelete(item);
                    o.mergedRemote.add(remote);
                }
                case "stray" -> {
                    if (!remote.isEmpty()) throw badDelete(item);
                    o.deleteStray = true;
                }
                case "diverged" -> {
                    if (remote.isEmpty()) throw badDelete(item);
                    o.deleteMergedLocal = true;
                    o.divergedRemote.add(remote);
                }
                case "local" -> {
                    if (!remote.isEmpty()) throw badDelete(item);
                    o.deleteLocal = true;
                }
                case "remote" -> {
                    if (remote.isEmpty()) throw badDelete(item);
                    o.remote.add(remote);
                }
                default -> throw badDelete(item);
            }
        }
    }

    CliException badDelete(String item) {
        return new CliException("error: invalid value '" + item + "' for '--delete <DELETE>': Invalid delete range format `" + item + "`\n\nFor more information, try '--help'.");
    }

    void applyConfig(Options o) {
        if (o.bases == null) {
            String v = gitMaybe("config", "--get", "trim.bases");
            if (!v.isBlank()) o.bases = v.trim();
        }
        if (o.protectedPatterns.isEmpty()) {
            String v = gitMaybe("config", "--get", "trim.protected");
            if (!v.isBlank()) o.protectedPatterns = split(v.trim());
        }
        String confirm = gitMaybe("config", "--get", "trim.confirm");
        if (!confirm.isBlank()) o.confirm = bool(confirm, o.confirm);
        String update = gitMaybe("config", "--get", "trim.update");
        if (!update.isBlank()) o.update = bool(update, o.update);
        String detach = gitMaybe("config", "--get", "trim.detach");
        if (!detach.isBlank()) o.detach = bool(detach, o.detach);
        String del = gitMaybe("config", "--get", "trim.delete");
        if (!o.deleteExplicit) o.deleteSpec = del.isBlank() ? "merged:origin" : del.trim();
        try { parseDelete(o); } catch (CliException ignored) { }
    }

    static boolean bool(String s, boolean def) {
        String v = s.trim().toLowerCase(Locale.ROOT);
        if (v.equals("true") || v.equals("yes") || v.equals("on") || v.equals("1")) return true;
        if (v.equals("false") || v.equals("no") || v.equals("off") || v.equals("0")) return false;
        return def;
    }

    void ensureRepo() throws GitException {
        Cmd r = cmd(false, "git", "rev-parse", "--git-dir");
        if (r.code != 0) throw new GitException("could not find repository at '.'; class=Repository (6); code=NotFound (-3)");
    }

    void updateRemotes() {
        cmd(true, "git", "fetch", "--all", "--prune");
    }

    Repo loadRepo() {
        Repo r = new Repo();
        String locals = gitMaybe("for-each-ref", "--format=%(refname:short)%00%(objectname)%00%(upstream:short)", "refs/heads");
        for (String line : locals.split("\\R")) {
            if (line.isEmpty()) continue;
            String[] p = line.split("\0", -1);
            Branch b = new Branch();
            b.name = p[0]; b.sha = p.length > 1 ? p[1] : ""; b.upstream = p.length > 2 ? p[2] : "";
            b.remote = false;
            String remote = gitMaybe("config", "--get", "branch." + b.name + ".remote").trim();
            String merge = gitMaybe("config", "--get", "branch." + b.name + ".merge").trim();
            if (!remote.isEmpty() && !merge.isEmpty()) b.configuredUpstream = remote + "/" + merge.replace("refs/heads/", "");
            r.locals.add(b);
            r.localByName.put(b.name, b);
        }
        String remotes = gitMaybe("for-each-ref", "--format=%(refname:short)%00%(objectname)", "refs/remotes");
        for (String line : remotes.split("\\R")) {
            if (line.isEmpty()) continue;
            String[] p = line.split("\0", -1);
            if (p[0].endsWith("/HEAD")) continue;
            Branch b = new Branch();
            b.name = p[0]; b.sha = p.length > 1 ? p[1] : ""; b.remote = true;
            r.remotes.add(b);
            r.remoteByName.put(b.name, b);
        }
        r.head = gitMaybe("branch", "--show-current").trim();
        return r;
    }

    List<Base> resolveBases(Options o, Repo repo) {
        List<Base> bases = new ArrayList<>();
        if (o.bases != null && !o.bases.isBlank()) {
            for (String name : split(o.bases)) {
                Branch local = repo.localByName.get(name);
                if (local != null) {
                    String up = !local.upstream.isEmpty() ? local.upstream : local.configuredUpstream;
                    bases.add(new Base(name, up.isEmpty() ? name : up));
                }
            }
            return bases;
        }
        String heads = gitMaybe("for-each-ref", "--format=%(refname:short)", "refs/remotes");
        for (String h : heads.split("\\R")) {
            if (!h.endsWith("/HEAD")) continue;
            String full = gitMaybe("symbolic-ref", "refs/remotes/" + h).trim();
            if (full.startsWith("refs/remotes/")) {
                String up = full.substring("refs/remotes/".length());
                for (Branch b : repo.locals) {
                    String bu = !b.upstream.isEmpty() ? b.upstream : b.configuredUpstream;
                    if (up.equals(bu)) bases.add(new Base(b.name, up));
                }
            }
        }
        return bases;
    }

    Plan plan(Options o, Repo repo, List<Base> bases) {
        Plan p = new Plan();
        Set<String> baseLocals = new HashSet<>();
        Set<String> baseRemotes = new HashSet<>();
        for (Base b : bases) { baseLocals.add(b.local); baseRemotes.add(b.upstream); }
        Set<String> upstreams = new HashSet<>();
        for (Branch b : repo.locals) if (!b.upstream.isEmpty()) upstreams.add(b.upstream);
        for (Branch b : repo.locals) {
            if (baseLocals.contains(b.name)) { p.remainLocal.put(b.name, "[base]"); continue; }
            if (protectedBranch(o, b.name)) { p.remainLocal.put(b.name, "[protected]"); continue; }
            boolean tracking = !b.upstream.isEmpty() || !b.configuredUpstream.isEmpty();
            String upstream = !b.upstream.isEmpty() ? b.upstream : b.configuredUpstream;
            boolean upstreamExists = upstream != null && !upstream.isEmpty() && repo.remoteByName.containsKey(upstream);
            boolean merged = isMergedIntoAny(b.name, bases);
            if (tracking && !upstreamExists) {
                if (o.deleteStray) p.localDelete.add(new DeleteLocal(b.name, "stray", true));
                else p.remainLocal.put(b.name, "[stray, but: delete range `stray` was not given]");
            } else if (tracking && merged) {
                if (o.deleteMergedLocal) p.localDelete.add(new DeleteLocal(b.name, "merged", false));
                else p.remainLocal.put(b.name, "[merged, but: delete range `merged-local` was not given]");
            } else if (!tracking && merged) {
                if (o.deleteLocal) p.localDelete.add(new DeleteLocal(b.name, "local", false));
                else p.remainLocal.put(b.name, "*2");
            } else {
                p.remainLocal.put(b.name, tracking ? "" : "*2");
            }
        }
        for (Branch b : repo.remotes) {
            if (baseRemotes.contains(b.name)) { p.remainRemote.put(b.name, "[base]"); continue; }
            if (protectedBranch(o, remoteShort(b.name))) { p.remainRemote.put(b.name, "[protected]"); continue; }
            String remote = remoteName(b.name);
            boolean merged = isMergedIntoAny(b.name, bases);
            boolean isUpstream = upstreams.contains(b.name);
            if (merged && remoteAllowed(o.mergedRemote, remote)) {
                p.remoteDelete.add(b.name);
            } else if (merged && remoteAllowed(o.remote, remote) && !isUpstream) {
                p.remoteDelete.add(b.name);
            } else {
                if (merged && !remoteAllowed(o.mergedRemote, remote)) p.remainRemote.put(b.name, isUpstream ? "[merged, but: delete range `merged-remote:" + remote + "` was not given]" : "*1");
                else p.remainRemote.put(b.name, "");
            }
        }
        p.localDelete.sort(Comparator.comparing(a -> a.name));
        p.remoteDelete.sort(String::compareTo);
        return p;
    }

    boolean isMergedIntoAny(String ref, List<Base> bases) {
        for (Base b : bases) {
            String target = b.upstream == null || b.upstream.isEmpty() ? b.local : b.upstream;
            if (cmd(false, "git", "merge-base", "--is-ancestor", ref, target).code == 0) return true;
        }
        return false;
    }

    void printPlan(Plan p, Options o) {
        System.out.println("Branches that will remain:");
        System.out.println("  local branches:");
        p.remainLocal.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e -> System.out.println("    " + e.getKey() + (e.getValue().isEmpty() ? "" : " " + e.getValue())));
        System.out.println("  remote references:");
        p.remainRemote.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e -> System.out.println("    " + e.getKey() + (e.getValue().isEmpty() ? "" : " " + e.getValue())));
        boolean need1 = p.remainLocal.containsValue("*1") || p.remainRemote.containsValue("*1");
        boolean need2 = p.remainLocal.containsValue("*2") || p.remainRemote.containsValue("*2");
        if (need1 || need2) {
            System.out.println("  Some branches are skipped. Consider following to scan them:");
            if (need1) System.out.println("    *1: Add `--delete 'merged:*'` flag.");
            if (need2) System.out.println("    *2: Set an upstream to make it a tracking branch or add `--delete 'local'` flag.");
        }
        System.out.println();
        List<String> merged = new ArrayList<>();
        List<String> stray = new ArrayList<>();
        List<String> local = new ArrayList<>();
        for (DeleteLocal d : p.localDelete) {
            if (d.kind.equals("stray")) stray.add(d.name);
            else if (d.kind.equals("local")) local.add(d.name + " (non-tracking)");
            else merged.add(d.name);
        }
        if (!merged.isEmpty()) {
            System.out.println("Delete merged local branches:");
            for (String s : merged) System.out.println("  - " + s);
        }
        if (!stray.isEmpty()) {
            System.out.println("Delete stray local branches:");
            for (String s : stray) System.out.println("  - " + s);
        }
        if (!local.isEmpty()) {
            System.out.println("Delete merged local branches:");
            for (String s : local) System.out.println("  - " + s);
        }
        if (!p.remoteDelete.isEmpty()) {
            System.out.println("Delete merged remote refs:");
            for (String s : p.remoteDelete) System.out.println("  - " + remoteName(s) + ", refs/heads/" + remoteShort(s));
        }
    }

    void execute(Plan p, Options o) {
        Map<String, List<String>> byRemote = new HashMap<>();
        for (String r : p.remoteDelete) byRemote.computeIfAbsent(remoteName(r), k -> new ArrayList<>()).add(remoteShort(r));
        for (Map.Entry<String, List<String>> e : byRemote.entrySet()) {
            List<String> command = new ArrayList<>();
            command.add("git"); command.add("push");
            if (o.dryRun) command.add("--dry-run");
            command.add(e.getKey()); command.add("--delete");
            command.addAll(e.getValue());
            cmd(true, command.toArray(new String[0]));
        }
        for (DeleteLocal d : p.localDelete) {
            if (o.dryRun) {
                System.out.println("Delete branch " + d.name + " (dry run).");
            } else {
                if (o.detach && d.name.equals(gitMaybe("branch", "--show-current").trim())) {
                    cmd(true, "git", "checkout", "--detach");
                }
                cmd(true, "git", "branch", d.force ? "-D" : "-d", d.name);
            }
        }
    }

    static String remoteName(String remoteRef) {
        int i = remoteRef.indexOf('/');
        return i < 0 ? remoteRef : remoteRef.substring(0, i);
    }

    static String remoteShort(String remoteRef) {
        int i = remoteRef.indexOf('/');
        return i < 0 ? remoteRef : remoteRef.substring(i + 1);
    }

    static boolean remoteAllowed(Set<String> remotes, String r) {
        return remotes.contains(r) || remotes.contains("*");
    }

    static boolean protectedBranch(Options o, String name) {
        for (String pat : o.protectedPatterns) {
            StringBuilder re = new StringBuilder();
            for (char c : pat.toCharArray()) {
                if (c == '*') re.append(".*");
                else if ("\\.[]{}()+-^$?|".indexOf(c) >= 0) re.append('\\').append(c);
                else re.append(c);
            }
            if (Pattern.matches(re.toString(), name)) return true;
        }
        return false;
    }

    static List<String> split(String s) {
        List<String> out = new ArrayList<>();
        if (s == null) return out;
        for (String p : s.split(",")) {
            String t = p.trim();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    String gitMaybe(String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add("git");
        cmd.addAll(Arrays.asList(args));
        Cmd c = cmd(false, cmd.toArray(new String[0]));
        return c.out.trim();
    }

    static Cmd cmd(boolean inherit, String... argv) {
        try {
            ProcessBuilder pb = new ProcessBuilder(argv);
            if (inherit) {
                pb.inheritIO();
            } else {
                pb.redirectErrorStream(true);
            }
            Process p = pb.start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (!inherit) p.getInputStream().transferTo(out);
            int code = p.waitFor();
            return new Cmd(code, out.toString(StandardCharsets.UTF_8));
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            return new Cmd(127, e.getMessage());
        }
    }

    void printNoBase() {
        System.out.println("I can't detect base branch! Try following any resolution:");
        System.out.println(" * `git remote set-head origin --auto` will help `git-trim` to automatically");
        System.out.println("   detect the base branch.");
        System.out.println("   If you see `origin/HEAD set to <base branch>` in the output of the previous");
        System.out.println("   command, then `git branch --set-upstream origin/<base branch> <base branch>`");
        System.out.println("   to set an upstream branch for <base branch> if exists.");
        System.out.println("You also can set bases manually with any of following commands:");
        System.out.println(" * `git config trim.bases develop,master` for a repository.");
        System.out.println(" * `git config --global trim.bases develop,master` to set globally.");
        System.out.println(" * `git trim --bases develop,master` to set temporarily.");
    }

    static class Options {
        boolean helpShort, helpLong, version, dryRun;
        boolean update = true, confirm = true, detach = true;
        long updateInterval = 5;
        String bases, deleteSpec;
        boolean deleteExplicit;
        List<String> protectedPatterns = new ArrayList<>();
        boolean deleteMergedLocal, deleteStray, deleteLocal;
        Set<String> mergedRemote = new LinkedHashSet<>();
        Set<String> divergedRemote = new LinkedHashSet<>();
        Set<String> remote = new LinkedHashSet<>();
    }
    record Cmd(int code, String out) {}
    static class GitException extends Exception { GitException(String m) { super(m); } }
    static class CliException extends Exception { CliException(String m) { super(m); } }
    static class Branch { String name, sha, upstream = "", configuredUpstream = ""; boolean remote; }
    static class Repo {
        List<Branch> locals = new ArrayList<>(), remotes = new ArrayList<>();
        Map<String, Branch> localByName = new HashMap<>(), remoteByName = new HashMap<>();
        String head = "";
    }
    record Base(String local, String upstream) {}
    record DeleteLocal(String name, String kind, boolean force) {}
    static class Plan {
        Map<String, String> remainLocal = new HashMap<>(), remainRemote = new HashMap<>();
        List<DeleteLocal> localDelete = new ArrayList<>();
        List<String> remoteDelete = new ArrayList<>();
        boolean isEmpty() { return localDelete.isEmpty() && remoteDelete.isEmpty(); }
    }
}
