import org.w3c.dom.*;
import org.xml.sax.InputSource;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Xq {
    static class Opt {
        int indent = 2, depth = -1;
        boolean tab, html, json, node, inPlace, compact;
        String xpath, extract, query, attr, file;
    }

    static final String HELP = "Command-line XML and HTML beautifier and content extractor\n\n" +
            "Usage:\n  xq [flags]\n\nFlags:\n" +
            "  -a, --attr string      Extract an attribute value instead of node content for provided CSS query\n" +
            "  -c, --color            Force colorful output\n" +
            "      --compact          Compact JSON output (no indentation)\n" +
            "  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)\n" +
            "  -e, --extract string   Extract a single node from XML\n" +
            "  -h, --help             Print this help message\n" +
            "  -m, --html             Use HTML formatter\n" +
            "  -i, --in-place         Format file in place\n" +
            "      --indent int       Use the given number of spaces for indentation (default 2)\n" +
            "  -j, --json             Output the result as JSON\n" +
            "      --no-color         Disable colorful output\n" +
            "  -n, --node             Return the node content instead of text\n" +
            "  -q, --query string     Extract the node(s) using CSS selector\n" +
            "      --tab              Use tabs for indentation\n" +
            "  -v, --version          Print version information\n" +
            "  -x, --xpath string     Extract the node(s) from XML";

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            if (opt.attr != null && opt.query == null) {
                throw new XqError("query option (-q) is missed for attribute selection");
            }
            String input = readInput(opt);
            if (input == null || input.isEmpty()) {
                System.out.println(HELP);
                return;
            }
            Document doc = parseDoc(input, opt.html);
            String out;
            if (opt.json) {
                Object obj = new LinkedHashMap<String, Object>() {{
                    put(doc.getDocumentElement().getTagName(), toJsonValue(doc.getDocumentElement(), 0, opt.depth));
                }};
                out = renderJson(obj, opt.compact, 0) + "\n";
            } else if (opt.query != null) {
                out = cssOutput(doc, opt);
            } else if (opt.xpath != null || opt.extract != null) {
                out = xpathOutput(doc, opt);
            } else {
                out = formatElement(doc.getDocumentElement(), 0, opt) + "\n";
            }
            if (opt.inPlace && opt.file != null) Files.writeString(Paths.get(opt.file), out, StandardCharsets.UTF_8);
            else System.out.print(out);
        } catch (XqError e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) throws XqError {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": System.out.println(HELP); return null;
                case "-v": case "--version": System.out.println("xq version 1.4.0"); return null;
                case "-c": case "--color": case "--no-color": break;
                case "-m": case "--html": o.html = true; break;
                case "-j": case "--json": o.json = true; break;
                case "-n": case "--node": o.node = true; break;
                case "-i": case "--in-place": o.inPlace = true; break;
                case "--tab": o.tab = true; break;
                case "--compact": o.compact = true; break;
                case "--indent": o.indent = parseInt(need(args, ++i, a), a); break;
                case "-d": case "--depth": o.depth = parseInt(need(args, ++i, a), a); break;
                case "-x": case "--xpath": o.xpath = need(args, ++i, a); break;
                case "-e": case "--extract": o.extract = need(args, ++i, a); break;
                case "-q": case "--query": o.query = need(args, ++i, a); break;
                case "-a": case "--attr": o.attr = need(args, ++i, a); break;
                default:
                    if (a.startsWith("-")) throw new XqError("unknown flag: " + a);
                    if (o.file == null) o.file = a;
                    else throw new XqError("open " + a + ": no such file or directory");
            }
        }
        return o;
    }

    static String need(String[] args, int i, String f) throws XqError {
        if (i >= args.length) {
            if (f.length() == 2) throw new XqError("flag needs an argument: '" + f.charAt(1) + "' in " + f);
            throw new XqError("flag needs an argument: " + f);
        }
        return args[i];
    }

    static int parseInt(String s, String f) throws XqError {
        try { return Integer.parseInt(s); }
        catch (NumberFormatException e) {
            throw new XqError("invalid argument \"" + s + "\" for \"" + f + "\" flag: strconv.ParseInt: parsing \"" + s + "\": invalid syntax");
        }
    }

    static String readInput(Opt o) throws IOException, XqError {
        if (o.file != null) {
            try { return Files.readString(Paths.get(o.file)); }
            catch (NoSuchFileException e) { throw new XqError("open " + o.file + ": no such file or directory"); }
        }
        return new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
    }

    static Document parseDoc(String input, boolean html) throws Exception {
        String s = input.trim();
        if (html) s = closeHtmlVoids(s);
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(false);
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        try { f.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, ""); } catch (Exception ignored) {}
        DocumentBuilder b = f.newDocumentBuilder();
        b.setErrorHandler(null);
        return b.parse(new InputSource(new StringReader(s)));
    }

    static String closeHtmlVoids(String s) {
        String[] tags = {"br","hr","img","input","meta","link","area","base","col","embed","param","source","track","wbr"};
        for (String t : tags) s = s.replaceAll("(?i)<" + t + "([^>/]*?)>", "<" + t + "$1/>");
        return s;
    }

    static String xpathOutput(Document doc, Opt o) throws Exception {
        String expr = o.extract != null ? o.extract : o.xpath;
        XPath xp = XPathFactory.newInstance().newXPath();
        Object r = xp.evaluate(expr, doc, XPathConstants.NODESET);
        NodeList list = (NodeList) r;
        StringBuilder sb = new StringBuilder();
        int limit = o.extract != null ? Math.min(1, list.getLength()) : list.getLength();
        for (int i = 0; i < limit; i++) appendExtract(sb, list.item(i), o.node, o);
        if (list.getLength() == 0) {
            String val = xp.evaluate(expr, doc);
            if (!val.isEmpty()) sb.append(val).append('\n');
        }
        return sb.toString();
    }

    static String cssOutput(Document doc, Opt o) {
        List<Element> els = select(doc.getDocumentElement(), o.query);
        StringBuilder sb = new StringBuilder();
        for (Element e : els) {
            if (o.attr != null) sb.append(e.getAttribute(o.attr)).append('\n');
            else if (o.node) sb.append(formatElement(e, 0, o)).append('\n');
            else sb.append(normText(e.getTextContent())).append('\n');
        }
        return sb.toString();
    }

    static void appendExtract(StringBuilder sb, Node n, boolean node, Opt o) {
        if (n.getNodeType() == Node.ATTRIBUTE_NODE) sb.append(n.getNodeValue()).append('\n');
        else if (node && n instanceof Element) sb.append(formatElement((Element)n, 0, o)).append('\n');
        else sb.append(normText(n.getTextContent())).append('\n');
    }

    static List<Element> select(Element root, String q) {
        String[] parts = Arrays.stream(q.trim().split("\\s*>\\s*|\\s+")).filter(s -> !s.isEmpty()).toArray(String[]::new);
        List<Element> cur = new ArrayList<>();
        cur.add(root);
        boolean direct = q.contains(">");
        for (int pi = 0; pi < parts.length; pi++) {
            String p = parts[pi];
            List<Element> next = new ArrayList<>();
            for (Element base : cur) {
                if (pi == 0 && matches(base, p)) next.add(base);
                collect(base, p, next, direct && pi > 0);
            }
            cur = next;
        }
        return cur;
    }

    static void collect(Element e, String p, List<Element> out, boolean childrenOnly) {
        NodeList nl = e.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) if (nl.item(i) instanceof Element) {
            Element c = (Element) nl.item(i);
            if (matches(c, p)) out.add(c);
            if (!childrenOnly) collect(c, p, out, false);
        }
    }

    static boolean matches(Element e, String p) {
        if (p.startsWith(".")) return Arrays.asList(e.getAttribute("class").split("\\s+")).contains(p.substring(1));
        if (p.startsWith("#")) return e.getAttribute("id").equals(p.substring(1));
        int dot = p.indexOf('.');
        if (dot > 0) return e.getTagName().equalsIgnoreCase(p.substring(0, dot)) && matches(e, p.substring(dot));
        return p.equals("*") || e.getTagName().equalsIgnoreCase(p);
    }

    static String formatElement(Element e, int level, Opt o) {
        StringBuilder sb = new StringBuilder();
        String ind = indent(level, o);
        sb.append(ind).append('<').append(e.getTagName());
        NamedNodeMap attrs = e.getAttributes();
        for (int i = 0; i < attrs.getLength(); i++) {
            Node a = attrs.item(i);
            sb.append(' ').append(a.getNodeName()).append("=\"").append(escAttr(a.getNodeValue())).append('"');
        }
        List<Element> children = childElements(e);
        String text = ownText(e);
        if (children.isEmpty()) {
            if (text.isEmpty()) {
                if (o.html) sb.append("></").append(e.getTagName()).append('>');
                else sb.append("/>");
            } else sb.append('>').append(escText(text)).append("</").append(e.getTagName()).append('>');
            return sb.toString();
        }
        sb.append('>');
        if (!text.isEmpty()) sb.append(escText(text));
        for (Element c : children) sb.append('\n').append(formatElement(c, level + 1, o));
        sb.append('\n').append(ind).append("</").append(e.getTagName()).append('>');
        return sb.toString();
    }

    static String indent(int n, Opt o) {
        if (o.tab) return "\t".repeat(Math.max(0, n));
        return " ".repeat(Math.max(0, n * o.indent));
    }

    static List<Element> childElements(Element e) {
        List<Element> r = new ArrayList<>();
        NodeList nl = e.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) if (nl.item(i) instanceof Element) r.add((Element) nl.item(i));
        return r;
    }

    static String ownText(Element e) {
        StringBuilder sb = new StringBuilder();
        NodeList nl = e.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.TEXT_NODE || n.getNodeType() == Node.CDATA_SECTION_NODE) sb.append(n.getTextContent());
        }
        return normText(sb.toString());
    }

    static String normText(String s) { return s.replaceAll("\\s+", " ").trim(); }
    static String escText(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }
    static String escAttr(String s) { return escText(s).replace("\"", "&quot;"); }

    static Object toJsonValue(Element e, int depth, int maxDepth) {
        if (maxDepth >= 0 && depth >= maxDepth) return e.getTextContent();
        List<Element> kids = childElements(e);
        NamedNodeMap attrs = e.getAttributes();
        String text = ownText(e);
        if (kids.isEmpty() && attrs.getLength() == 0 && !text.isEmpty()) return text;
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        if (!text.isEmpty()) m.put("#text", text);
        List<String> an = new ArrayList<>();
        for (int i = 0; i < attrs.getLength(); i++) an.add(attrs.item(i).getNodeName());
        Collections.sort(an);
        for (String name : an) m.put("@" + name, e.getAttribute(name));
        TreeMap<String, List<Object>> grouped = new TreeMap<>();
        for (Element c : kids) grouped.computeIfAbsent(c.getTagName(), k -> new ArrayList<>()).add(toJsonValue(c, depth + 1, maxDepth));
        for (Map.Entry<String, List<Object>> en : grouped.entrySet()) {
            m.put(en.getKey(), en.getValue().size() == 1 ? en.getValue().get(0) : en.getValue());
        }
        return m;
    }

    static String renderJson(Object o, boolean compact, int level) {
        String sp = compact ? "" : " ".repeat(level * 2);
        String sp1 = compact ? "" : " ".repeat((level + 1) * 2);
        if (o instanceof Map) {
            Map<?,?> m = (Map<?,?>) o;
            if (m.isEmpty()) return compact ? "{}" : "{\n\n" + sp + "}";
            StringBuilder sb = new StringBuilder("{");
            if (!compact) sb.append('\n');
            int i = 0;
            for (Map.Entry<?,?> e : m.entrySet()) {
                if (i++ > 0) sb.append(compact ? "," : ",\n");
                sb.append(sp1).append('"').append(jsonEsc(e.getKey().toString())).append("\":");
                sb.append(compact ? " " : " ").append(renderJson(e.getValue(), compact, level + 1));
            }
            if (!compact) sb.append('\n').append(sp);
            return sb.append('}').toString();
        }
        if (o instanceof List) {
            List<?> l = (List<?>) o;
            StringBuilder sb = new StringBuilder("[");
            if (!compact) sb.append('\n');
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(compact ? "," : ",\n");
                sb.append(sp1).append(renderJson(l.get(i), compact, level + 1));
            }
            if (!compact) sb.append('\n').append(sp);
            return sb.append(']').toString();
        }
        return "\"" + jsonEsc(String.valueOf(o)) + "\"";
    }

    static String jsonEsc(String s) {
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            switch (c) {
                case '\\': b.append("\\\\"); break;
                case '"': b.append("\\\""); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default: if (c < 32) b.append(String.format("\\u%04x", (int)c)); else b.append(c);
            }
        }
        return b.toString();
    }

    static class XqError extends Exception { XqError(String m) { super(m); } }
}
