import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.regex.*;

public class MiniDuckDB {
    enum Mode { TABLE, CSV, LIST, COLUMN, LINE, JSON, JSONLINES, MARKDOWN, QUOTE, HTML, ASCII, BOX }

    static class Options {
        Mode mode = Mode.TABLE;
        boolean header = true, bail = false, echo = false, noStdin = false, readonly = false;
        String nullValue = "NULL", colSep = "|", rowSep = "\n", filename = ":memory:";
        List<String> commands = new ArrayList<>();
        List<String> initFiles = new ArrayList<>();
    }

    static class RowSet {
        List<String> cols = new ArrayList<>();
        List<String> types = new ArrayList<>();
        List<List<Object>> rows = new ArrayList<>();
    }

    private Options opt = new Options();
    private Connection conn;
    private File cwd = new File(System.getProperty("user.dir"));

    public static void main(String[] args) {
        try {
            new MiniDuckDB().run(args);
        } catch (ExitException e) {
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static class ExitException extends RuntimeException {
        final int code;
        ExitException(int code) { this.code = code; }
    }

    void run(String[] args) throws Exception {
        parseArgs(args);
        if (opt.filename.equals("-")) opt.filename = ":memory:";
        Class.forName("org.sqlite.JDBC");
        String url = opt.filename.equals(":memory:") ? "jdbc:sqlite::memory:" : "jdbc:sqlite:" + opt.filename;
        conn = DriverManager.getConnection(url);
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys=ON");
        }
        for (String f : opt.initFiles) runScript(Files.readString(resolve(f).toPath()));
        for (String c : opt.commands) executeInput(c);
        if (!opt.noStdin && opt.commands.isEmpty() && System.console() == null) {
            executeInput(new String(System.in.readAllBytes(), StandardCharsets.UTF_8));
        }
    }

    void parseArgs(String[] args) {
        List<String> positional = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "-help": case "--help": printHelp(); throw new ExitException(0);
                case "-version": case "--version": System.out.println("v0.0.1 (Unknown Version) 780a7396"); throw new ExitException(0);
                case "-csv": opt.mode = Mode.CSV; break;
                case "-list": opt.mode = Mode.LIST; break;
                case "-column": opt.mode = Mode.COLUMN; break;
                case "-line": opt.mode = Mode.LINE; break;
                case "-json": opt.mode = Mode.JSON; break;
                case "-jsonlines": opt.mode = Mode.JSONLINES; break;
                case "-markdown": opt.mode = Mode.MARKDOWN; break;
                case "-quote": opt.mode = Mode.QUOTE; break;
                case "-html": opt.mode = Mode.HTML; break;
                case "-ascii": opt.mode = Mode.ASCII; break;
                case "-box": case "-table": opt.mode = Mode.TABLE; break;
                case "-header": opt.header = true; break;
                case "-noheader": opt.header = false; break;
                case "-bail": opt.bail = true; break;
                case "-echo": opt.echo = true; break;
                case "-no-stdin": opt.noStdin = true; break;
                case "-readonly": opt.readonly = true; break;
                case "-safe": case "-unsigned": case "-unredacted": case "-batch": case "-interactive": case "-no-init": break;
                case "-separator": if (i + 1 < args.length) opt.colSep = decodeSep(args[++i]); break;
                case "-newline": if (i + 1 < args.length) opt.rowSep = decodeSep(args[++i]); break;
                case "-nullvalue": if (i + 1 < args.length) opt.nullValue = args[++i]; break;
                case "-cmd": if (i + 1 < args.length) opt.commands.add(args[++i]); break;
                case "-c": case "-s": if (i + 1 < args.length) { opt.commands.add(args[++i]); opt.noStdin = true; } break;
                case "-f": if (i + 1 < args.length) { opt.commands.add(readQuiet(args[++i])); opt.noStdin = true; } break;
                case "-init": if (i + 1 < args.length) opt.initFiles.add(args[++i]); break;
                case "-format": formatStdin(); throw new ExitException(0);
                case "-format-file": if (i + 1 < args.length) { System.out.print(formatSql(readQuiet(args[++i]))); throw new ExitException(0); } break;
                case "-storage-version": if (i + 1 < args.length) i++; break;
                default:
                    if (a.startsWith("-")) {
                        System.err.println("unknown option: " + a);
                        throw new ExitException(1);
                    }
                    positional.add(a);
            }
        }
        if (!positional.isEmpty()) opt.filename = positional.get(0);
        if (positional.size() > 1) { opt.commands.add(String.join(" ", positional.subList(1, positional.size()))); opt.noStdin = true; }
    }

    String readQuiet(String f) {
        try { return Files.readString(resolve(f).toPath()); }
        catch (IOException e) { throw new RuntimeException("Error: cannot open \"" + f + "\""); }
    }

    void formatStdin() {
        try { System.out.print(formatSql(new String(System.in.readAllBytes(), StandardCharsets.UTF_8))); }
        catch (IOException e) { throw new RuntimeException(e); }
    }

    String formatSql(String sql) {
        String s = sql.trim().replaceAll("\\s+", " ");
        String[] kws = {"select","from","where","group by","order by","limit","insert","update","delete","create table","values"};
        for (String k : kws) s = s.replaceAll("(?i)\\b" + Pattern.quote(k) + "\\b", k.toUpperCase());
        return s + (s.endsWith(";") ? "\n" : ";\n");
    }

    String decodeSep(String s) {
        return s.replace("\\n", "\n").replace("\\t", "\t").replace("\\r", "\r");
    }

    File resolve(String p) {
        File f = new File(p);
        return f.isAbsolute() ? f : new File(cwd, p);
    }

    void executeInput(String input) throws Exception {
        StringBuilder sql = new StringBuilder();
        for (String raw : input.split("\\R", -1)) {
            String line = raw;
            if (sql.length() == 0 && line.trim().startsWith(".")) {
                handleDot(line.trim());
                continue;
            }
            sql.append(line).append('\n');
            if (complete(sql.toString())) {
                for (String stmt : splitSqlStatements(sql.toString())) runSql(stmt);
                sql.setLength(0);
            }
        }
        if (sql.toString().trim().length() > 0) for (String stmt : splitSqlStatements(sql.toString())) runSql(stmt);
    }

    boolean complete(String s) {
        boolean in = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\'' && (i + 1 >= s.length() || s.charAt(i + 1) != '\'')) in = !in;
            else if (c == '\'' && i + 1 < s.length()) i++;
            else if (c == ';' && !in) return true;
        }
        return false;
    }

    List<String> splitSqlStatements(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        boolean in = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\'' && in && i + 1 < s.length() && s.charAt(i + 1) == '\'') { b.append(c).append(c); i++; continue; }
            if (c == '\'') in = !in;
            if (c == ';' && !in) {
                String stmt = b.toString().trim();
                if (!stmt.isEmpty()) out.add(stmt);
                b.setLength(0);
            } else b.append(c);
        }
        String stmt = b.toString().trim();
        if (!stmt.isEmpty()) out.add(stmt);
        return out;
    }

    void handleDot(String line) throws Exception {
        String[] p = splitWords(line);
        String cmd = p.length == 0 ? "" : p[0];
        switch (cmd) {
            case ".help": printDotHelp(); break;
            case ".quit": case ".exit": throw new ExitException(p.length > 1 ? parseInt(p[1], 0) : 0);
            case ".mode": if (p.length > 1) setMode(p[1]); break;
            case ".headers": case ".header": if (p.length > 1) opt.header = isOn(p[1]); break;
            case ".separator": if (p.length > 1) opt.colSep = decodeSep(p[1]); if (p.length > 2) opt.rowSep = decodeSep(p[2]); break;
            case ".nullvalue": if (p.length > 1) opt.nullValue = p[1]; break;
            case ".print": System.out.println(line.length() > 7 ? line.substring(7) : ""); break;
            case ".read": if (p.length > 1) executeInput(Files.readString(resolve(p[1]).toPath())); break;
            case ".cd": if (p.length > 1) cwd = resolve(p[1]).getCanonicalFile(); break;
            case ".tables": printTables(); break;
            case ".schema": printSchema(p.length > 1 ? p[1] : null); break;
            case ".databases": System.out.println("memory: " + opt.filename); break;
            case ".version": System.out.println("v0.0.1 (Unknown Version) 780a7396"); break;
            case ".about": System.out.println("DuckDB " + "v0.0.1 (Unknown Version) 780a7396"); break;
            case ".bail": if (p.length > 1) opt.bail = isOn(p[1]); break;
            case ".echo": if (p.length > 1) opt.echo = isOn(p[1]); break;
            case ".show": printShow(); break;
            default: System.err.println("Error: unknown command or invalid arguments:  \"" + line + "\". Enter \".help\" for help");
        }
    }

    String[] splitWords(String s) {
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("\"([^\"]*)\"|'([^']*)'|(\\S+)").matcher(s);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2) != null ? m.group(2) : m.group(3));
        return out.toArray(new String[0]);
    }

    boolean isOn(String s) { return s.equalsIgnoreCase("on") || s.equals("1") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("true"); }
    int parseInt(String s, int d) { try { return Integer.parseInt(s); } catch(Exception e) { return d; } }

    void setMode(String m) {
        switch (m.toLowerCase(Locale.ROOT)) {
            case "csv": opt.mode = Mode.CSV; opt.colSep = ","; break;
            case "list": opt.mode = Mode.LIST; break;
            case "column": opt.mode = Mode.COLUMN; break;
            case "line": opt.mode = Mode.LINE; break;
            case "json": opt.mode = Mode.JSON; break;
            case "jsonlines": opt.mode = Mode.JSONLINES; break;
            case "markdown": opt.mode = Mode.MARKDOWN; break;
            case "quote": opt.mode = Mode.QUOTE; break;
            case "html": opt.mode = Mode.HTML; break;
            case "ascii": opt.mode = Mode.ASCII; break;
            case "box": case "table": case "duckbox": opt.mode = Mode.TABLE; break;
        }
    }

    void runScript(String s) throws Exception { executeInput(s); }

    void runSql(String sql) throws Exception {
        sql = stripTrailingSemicolon(sql.trim());
        if (sql.isEmpty()) return;
        if (opt.echo) System.out.println(sql + ";");
        try {
            RowSet special = handleSpecialSelect(sql);
            if (special != null) { render(special); return; }
            try (Statement st = conn.createStatement()) {
                boolean has = st.execute(rewriteSql(sql));
                if (has) render(readResult(st.getResultSet()));
            }
        } catch (SQLException e) {
            System.err.println(errorMessage(e));
            if (opt.bail) throw new ExitException(1);
        }
    }

    String rewriteSql(String sql) {
        String s = sql.replaceAll("(?i)\\btrue\\b", "1").replaceAll("(?i)\\bfalse\\b", "0")
                  .replaceAll("(?i)\\bDOUBLE\\b", "REAL").replaceAll("(?i)\\bVARCHAR\\b", "TEXT")
                  .replaceAll("(?i)\\bHUGEINT\\b", "INTEGER").replaceAll("(?i)\\bUBIGINT\\b", "INTEGER")
                  .replaceAll("(?i)\\bBOOLEAN\\b", "INTEGER");
        s = rewriteRange(s);
        if (s.matches("(?is)^\\s*show\\s+tables\\s*$")) {
            return "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name";
        }
        Matcher d = Pattern.compile("(?is)^\\s*(describe|desc)\\s+([A-Za-z_][A-Za-z0-9_]*)\\s*$").matcher(s);
        if (d.find()) return "PRAGMA table_info(" + d.group(2) + ")";
        return s;
    }

    String rewriteRange(String sql) {
        Matcher m = Pattern.compile("(?i)range\\s*\\(\\s*(\\d+)\\s*\\)").matcher(sql);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            long end = Long.parseLong(m.group(1));
            String repl = "(WITH RECURSIVE duck_range(range) AS (SELECT 0 UNION ALL SELECT range + 1 FROM duck_range WHERE range + 1 < " + end + ") SELECT range FROM duck_range)";
            m.appendReplacement(sb, Matcher.quoteReplacement(repl));
        }
        m.appendTail(sb);
        String one = sb.toString();
        m = Pattern.compile("(?i)range\\s*\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\)").matcher(one);
        sb = new StringBuffer();
        while (m.find()) {
            long start = Long.parseLong(m.group(1)), end = Long.parseLong(m.group(2));
            String repl = "(WITH RECURSIVE duck_range(range) AS (SELECT " + start + " UNION ALL SELECT range + 1 FROM duck_range WHERE range + 1 < " + end + ") SELECT range FROM duck_range)";
            m.appendReplacement(sb, Matcher.quoteReplacement(repl));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    String stripTrailingSemicolon(String s) {
        while (s.endsWith(";")) s = s.substring(0, s.length() - 1).trim();
        return s;
    }

    String errorMessage(SQLException e) {
        String m = e.getMessage();
        if (m == null) m = e.toString();
        return "Error: " + m.replace("[SQLITE_ERROR] SQL error or missing database ", "").replace("(near ", "near ");
    }

    RowSet handleSpecialSelect(String sql) throws Exception {
        Matcher r = Pattern.compile("(?is)^select\\s+\\*\\s+from\\s+range\\s*\\(\\s*(\\d+)\\s*\\)$").matcher(sql);
        if (r.find()) {
            int n = Integer.parseInt(r.group(1));
            RowSet rs = new RowSet(); rs.cols.add("range"); rs.types.add("int64");
            for (int i = 0; i < n; i++) rs.rows.add(new ArrayList<>(List.of((long)i)));
            return rs;
        }
        r = Pattern.compile("(?is)^select\\s+\\*\\s+from\\s+range\\s*\\(\\s*(-?\\d+)\\s*,\\s*(-?\\d+)\\s*\\)$").matcher(sql);
        if (r.find()) {
            int start = Integer.parseInt(r.group(1)), end = Integer.parseInt(r.group(2));
            RowSet rs = new RowSet(); rs.cols.add("range"); rs.types.add("int64");
            for (int i = start; i < end; i++) rs.rows.add(new ArrayList<>(List.of((long)i)));
            return rs;
        }
        Matcher csv = Pattern.compile("(?is)^select\\s+\\*\\s+from\\s+'([^']+\\.csv)'$").matcher(sql);
        if (csv.find()) return readCsv(resolve(csv.group(1)).toPath());
        csv = Pattern.compile("(?is)^select\\s+\\*\\s+from\\s+read_csv_auto\\s*\\(\\s*'([^']+)'\\s*\\)$").matcher(sql);
        if (csv.find()) return readCsv(resolve(csv.group(1)).toPath());
        return null;
    }

    RowSet readCsv(Path path) throws IOException {
        List<String> lines = Files.readAllLines(path);
        RowSet rs = new RowSet();
        if (lines.isEmpty()) return rs;
        rs.cols.addAll(parseCsvLine(lines.get(0)));
        for (int i = 0; i < rs.cols.size(); i++) rs.types.add("varchar");
        for (int i = 1; i < lines.size(); i++) {
            List<String> vals = parseCsvLine(lines.get(i));
            rs.rows.add(new ArrayList<>(vals));
        }
        return rs;
    }

    List<String> parseCsvLine(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (q && i + 1 < line.length() && line.charAt(i + 1) == '"') { b.append('"'); i++; }
                else q = !q;
            } else if (c == ',' && !q) { out.add(b.toString()); b.setLength(0); }
            else b.append(c);
        }
        out.add(b.toString());
        return out;
    }

    RowSet readResult(ResultSet r) throws SQLException {
        RowSet rs = new RowSet();
        ResultSetMetaData md = r.getMetaData();
        int n = md.getColumnCount();
        for (int i = 1; i <= n; i++) {
            rs.cols.add(md.getColumnLabel(i));
            rs.types.add(typeName(md.getColumnType(i), md.getColumnTypeName(i)));
        }
        while (r.next()) {
            List<Object> row = new ArrayList<>();
            for (int i = 1; i <= n; i++) row.add(r.getObject(i));
            rs.rows.add(row);
        }
        refineTypes(rs);
        return rs;
    }

    String typeName(int t, String db) {
        switch (t) {
            case Types.INTEGER: case Types.SMALLINT: case Types.TINYINT: return "int32";
            case Types.BIGINT: return "int64";
            case Types.FLOAT: case Types.REAL: case Types.DOUBLE: case Types.NUMERIC: case Types.DECIMAL: return "double";
            case Types.BOOLEAN: case Types.BIT: return "boolean";
            case Types.DATE: return "date";
            case Types.TIMESTAMP: case Types.TIMESTAMP_WITH_TIMEZONE: return "timestamp";
            default: return "varchar";
        }
    }

    void refineTypes(RowSet rs) {
        for (int c = 0; c < rs.cols.size(); c++) {
            boolean seen = false, allInt = true, allNum = true;
            long min = Long.MAX_VALUE, max = Long.MIN_VALUE;
            for (List<Object> row : rs.rows) {
                Object v = row.size() > c ? row.get(c) : null;
                if (v == null) continue;
                seen = true;
                if (v instanceof Number) {
                    double d = ((Number)v).doubleValue();
                    if (Math.rint(d) != d) allInt = false;
                    long l = ((Number)v).longValue(); min = Math.min(min, l); max = Math.max(max, l);
                } else { allInt = false; allNum = false; }
            }
            if (!seen) {
                // Keep the JDBC-declared type when there are no values to infer from.
            } else if (allNum && allInt) rs.types.set(c, (min >= Integer.MIN_VALUE && max <= Integer.MAX_VALUE) ? "int32" : "int64");
            else if (allNum) rs.types.set(c, "double");
        }
    }

    void render(RowSet rs) {
        switch (opt.mode) {
            case CSV: renderSeparated(rs, ",", true, false); break;
            case LIST: renderSeparated(rs, opt.colSep, false, false); break;
            case QUOTE: renderSeparated(rs, opt.colSep, false, true); break;
            case COLUMN: renderColumn(rs); break;
            case LINE: renderLine(rs); break;
            case JSON: renderJson(rs, false); break;
            case JSONLINES: renderJson(rs, true); break;
            case MARKDOWN: renderMarkdown(rs); break;
            case HTML: renderHtml(rs); break;
            case ASCII: renderBox(rs, false); break;
            default: renderBox(rs, true);
        }
    }

    String val(Object v) { return v == null ? opt.nullValue : String.valueOf(v); }
    boolean numericType(String t) { return t.startsWith("int") || t.equals("double") || t.startsWith("decimal"); }

    void renderSeparated(RowSet rs, String sep, boolean csv, boolean quoteMode) {
        if (opt.header) {
            List<String> h = new ArrayList<>();
            for (String c : rs.cols) h.add(quoteMode ? "'" + c.replace("'", "''") + "'" : csv ? csv(c) : c);
            System.out.print(String.join(sep, h) + opt.rowSep);
        }
        for (List<Object> row : rs.rows) {
            List<String> vals = new ArrayList<>();
            for (int i = 0; i < rs.cols.size(); i++) {
                Object v = i < row.size() ? row.get(i) : null;
                if (quoteMode) vals.add(v == null ? opt.nullValue : (v instanceof Number ? String.valueOf(v) : "'" + String.valueOf(v).replace("'", "''") + "'"));
                else vals.add(csv ? csv(val(v)) : val(v));
            }
            System.out.print(String.join(sep, vals) + opt.rowSep);
        }
    }

    String csv(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r")) return "\"" + s.replace("\"", "\"\"") + "\"";
        return s;
    }

    void renderColumn(RowSet rs) {
        int n = rs.cols.size();
        int[] w = new int[n];
        for (int i = 0; i < n; i++) w[i] = rs.cols.get(i).length();
        for (List<Object> row : rs.rows) for (int i = 0; i < n; i++) w[i] = Math.max(w[i], val(i < row.size() ? row.get(i) : null).length());
        if (opt.header) {
            printPadded(rs.cols, w, false);
            List<String> d = new ArrayList<>(); for (int x : w) d.add("-".repeat(x)); printPadded(d, w, false);
        }
        for (List<Object> row : rs.rows) {
            List<String> v = new ArrayList<>(); for (int i = 0; i < n; i++) v.add(val(i < row.size() ? row.get(i) : null));
            printPadded(v, w, false);
        }
    }

    void printPadded(List<String> vals, int[] w, boolean right) {
        for (int i = 0; i < vals.size(); i++) {
            if (i > 0) System.out.print("  ");
            String s = vals.get(i);
            System.out.print(right ? leftPad(s, w[i]) : rightPad(s, w[i]));
        }
        System.out.println();
    }

    String rightPad(String s, int w) { return s + " ".repeat(Math.max(0, w - s.length())); }
    String leftPad(String s, int w) { return " ".repeat(Math.max(0, w - s.length())) + s; }

    void renderLine(RowSet rs) {
        int w = 0; for (String c : rs.cols) w = Math.max(w, c.length());
        for (List<Object> row : rs.rows) for (int i = 0; i < rs.cols.size(); i++) System.out.println(leftPad(rs.cols.get(i), w) + " = " + val(i < row.size() ? row.get(i) : null));
    }

    void renderJson(RowSet rs, boolean lines) {
        if (!lines) System.out.print("[");
        for (int r = 0; r < rs.rows.size(); r++) {
            if (!lines && r > 0) System.out.print(",");
            System.out.print(jsonObj(rs, rs.rows.get(r)));
            if (lines) System.out.println();
        }
        if (!lines) System.out.println("]");
    }

    String jsonObj(RowSet rs, List<Object> row) {
        StringBuilder b = new StringBuilder("{");
        for (int i = 0; i < rs.cols.size(); i++) {
            if (i > 0) b.append(',');
            b.append('"').append(esc(rs.cols.get(i))).append("\":");
            Object v = i < row.size() ? row.get(i) : null;
            if (v == null) b.append("null");
            else if (v instanceof Number) b.append(v);
            else b.append('"').append(esc(String.valueOf(v))).append('"');
        }
        return b.append('}').toString();
    }

    String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r"); }

    void renderMarkdown(RowSet rs) {
        System.out.println("| " + String.join(" | ", rs.cols) + " |");
        List<String> al = new ArrayList<>();
        for (int i = 0; i < rs.cols.size(); i++) al.add(numericType(rs.types.get(i)) ? "--:" : "---");
        System.out.println("|" + String.join("|", al) + "|");
        for (List<Object> row : rs.rows) {
            List<String> v = new ArrayList<>(); for (int i = 0; i < rs.cols.size(); i++) v.add(val(i < row.size() ? row.get(i) : null));
            System.out.println("| " + String.join(" | ", v) + " |");
        }
    }

    void renderHtml(RowSet rs) {
        System.out.println("<table>");
        if (opt.header) { System.out.println("<thead><tr>"); for (String c : rs.cols) System.out.println("<th>" + html(c) + "</th>"); System.out.println("</tr></thead>"); }
        System.out.println("<tbody>");
        for (List<Object> row : rs.rows) { System.out.println("<tr>"); for (int i = 0; i < rs.cols.size(); i++) System.out.println("<td>" + html(val(i < row.size() ? row.get(i) : null)) + "</td>"); System.out.println("</tr>"); }
        System.out.println("</tbody></table>");
    }
    String html(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }

    void renderBox(RowSet rs, boolean unicode) {
        int n = rs.cols.size();
        int[] w = new int[n];
        for (int i = 0; i < n; i++) w[i] = Math.max(rs.cols.get(i).length(), rs.types.get(i).length());
        for (List<Object> row : rs.rows) for (int i = 0; i < n; i++) w[i] = Math.max(w[i], val(i < row.size() ? row.get(i) : null).length());
        String[] ch = unicode ? new String[]{"┌","┬","┐","├","┼","┤","└","┴","┘","─","│"} : new String[]{"+","+","+","+","+","+","+","+","+","-","|"};
        border(w, ch[0], ch[1], ch[2], ch[9]);
        if (opt.header) {
            boxRow(rs.cols, rs.types, w, ch[10], true);
            boxRow(rs.types, rs.types, w, ch[10], false);
            border(w, ch[3], ch[4], ch[5], ch[9]);
        }
        for (List<Object> row : rs.rows) {
            List<String> v = new ArrayList<>(); for (int i = 0; i < n; i++) v.add(val(i < row.size() ? row.get(i) : null));
            boxRow(v, rs.types, w, ch[10], false);
        }
        border(w, ch[6], ch[7], ch[8], ch[9]);
    }

    void border(int[] w, String l, String m, String r, String h) {
        System.out.print(l);
        for (int i = 0; i < w.length; i++) { if (i > 0) System.out.print(m); System.out.print(h.repeat(w[i] + 2)); }
        System.out.println(r);
    }

    void boxRow(List<String> vals, List<String> types, int[] w, String vbar, boolean center) {
        System.out.print(vbar);
        for (int i = 0; i < vals.size(); i++) {
            String s = vals.get(i);
            boolean right = !center && numericType(types.get(i)) && !s.equals(opt.nullValue);
            if (center) {
                int pad = w[i] - s.length(), left = pad / 2, rightp = pad - left;
                System.out.print(" " + " ".repeat(left) + s + " ".repeat(rightp) + " " + vbar);
            } else {
                System.out.print(" " + (right ? leftPad(s, w[i]) : rightPad(s, w[i])) + " " + vbar);
            }
        }
        System.out.println();
    }

    void printTables() throws SQLException {
        RowSet rs = new RowSet(); rs.cols.add("name"); rs.types.add("varchar");
        try (ResultSet r = conn.getMetaData().getTables(null, null, "%", new String[]{"TABLE"})) {
            while (r.next()) rs.rows.add(new ArrayList<>(List.of(r.getString("TABLE_NAME"))));
        }
        opt.header = false; renderColumn(rs); opt.header = true;
    }

    void printSchema(String pat) throws SQLException {
        try (Statement st = conn.createStatement(); ResultSet r = st.executeQuery("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY name")) {
            while (r.next()) {
                String s = r.getString(1);
                if (pat == null || s.toLowerCase(Locale.ROOT).contains(pat.toLowerCase(Locale.ROOT))) System.out.println(s + ";");
            }
        }
    }

    void printShow() {
        System.out.println("        echo: " + (opt.echo ? "on" : "off"));
        System.out.println("     headers: " + (opt.header ? "on" : "off"));
        System.out.println("        mode: " + opt.mode.toString().toLowerCase(Locale.ROOT));
        System.out.println("   nullvalue: \"" + opt.nullValue + "\"");
        System.out.println("   separator: \"" + opt.colSep + "\"");
    }

    void printHelp() {
        System.out.println("Usage: ./executable [OPTIONS] FILENAME [SQL]\n");
        System.out.println("FILENAME is the name of a DuckDB database. A new database is created");
        System.out.println("if the file does not previously exist.\n");
        System.out.println("OPTIONS:");
        System.out.println("  -ascii                   set output mode to 'ascii'");
        System.out.println("  -bail                    stop after hitting an error");
        System.out.println("  -batch                   force batch I/O'");
        System.out.println("  -box                     set output mode to 'box'");
        System.out.println("  -column                  set output mode to 'column'");
        System.out.println("  -cmd COMMAND             run \"COMMAND\" before reading stdin");
        System.out.println("  -csv                     set output mode to 'csv'");
        System.out.println("  -c COMMAND               run \"COMMAND\" and exit");
        System.out.println("  -echo                    print commands before execution");
        System.out.println("  -f FILENAME              read/process named file and exit");
        System.out.println("  -format                  format SQL from stdin, writing result to stdout");
        System.out.println("  -format-file FILENAME    format SQL in file, writing result to stdout");
        System.out.println("  -header                  turn headers on");
        System.out.println("  -h                       show help message");
        System.out.println("  -help                    show help message");
        System.out.println("  -json                    set output mode to 'json'");
        System.out.println("  -jsonlines               set output mode to 'jsonlines'");
        System.out.println("  -line                    set output mode to 'line'");
        System.out.println("  -list                    set output mode to 'list'");
        System.out.println("  -markdown                set output mode to 'markdown'");
        System.out.println("  -noheader                turn headers off");
        System.out.println("  -nullvalue TEXT          set text string for NULL values. Default 'NULL'");
        System.out.println("  -quote                   set output mode to 'quote'");
        System.out.println("  -separator SEP           set output column separator. Default: '|'");
        System.out.println("  -table                   set output mode to 'table'");
        System.out.println("  -version                 show DuckDB version");
    }

    void printDotHelp() {
        System.out.println(".bail on|off                             Stop after hitting an error.  Default OFF");
        System.out.println(".cd DIRECTORY                            Change the working directory to DIRECTORY");
        System.out.println(".echo on|off                             Turn command echo on or off");
        System.out.println(".exit ?CODE?                             Exit this program with return-code CODE");
        System.out.println(".headers on|off                          Turn display of headers on or off");
        System.out.println(".help ?-all? ?PATTERN?                   Show help text for PATTERN");
        System.out.println(".mode MODE ?TABLE?                       Set output mode");
        System.out.println(".nullvalue STRING                        Use STRING in place of NULL values");
        System.out.println(".print STRING...                         Print literal STRING");
        System.out.println(".quit                                    Exit this program");
        System.out.println(".read FILE                               Read input from FILE");
        System.out.println(".schema ?PATTERN?                        Show the CREATE statements matching PATTERN");
        System.out.println(".separator COL ?ROW?                     Change the column and row separators");
        System.out.println(".show                                    Show the current values for various settings");
        System.out.println(".tables ?TABLE?                          List names of tables matching LIKE pattern TABLE");
        System.out.println(".version                                 Show the version");
    }
}
