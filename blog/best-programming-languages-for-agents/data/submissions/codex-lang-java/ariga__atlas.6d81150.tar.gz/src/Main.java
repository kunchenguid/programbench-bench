import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Stream;

public class Main {
    static final String COMMUNITY = "You're running the community build of Atlas, which may differ from the official version.\n" +
            "If this error persists, try installing the official version as a troubleshooting step:\n\n" +
            "  curl -sSf https://atlasgo.sh | sh\n\n" +
            "More installation options: https://atlasgo.io/docs#installation";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (Exception e) {
            err("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] a) throws Exception {
        List<String> args = new ArrayList<>(Arrays.asList(a));
        if (args.isEmpty() || has(args, "-h") || has(args, "--help")) {
            if (args.isEmpty() || isHelpOnly(args)) { rootHelp(); return 0; }
        }
        String cmd = args.remove(0);
        switch (cmd) {
            case "help": return help(args);
            case "version": version(); return 0;
            case "license": license(); return 0;
            case "schema": return schema(args);
            case "migrate": return migrate(args);
            case "completion": return completion(args);
            default:
                err("Error: unknown command \"" + cmd + "\" for \"atlas\"");
                return 1;
        }
    }

    int help(List<String> args) throws Exception {
        if (args.isEmpty()) { rootHelp(); return 0; }
        if (args.get(0).equals("schema")) return schema(new ArrayList<>(List.of("--help")));
        if (args.get(0).equals("migrate")) return migrate(new ArrayList<>(List.of("--help")));
        if (args.get(0).equals("completion")) return completion(new ArrayList<>(List.of("--help")));
        rootHelp(); return 0;
    }

    int schema(List<String> args) throws Exception {
        if (args.isEmpty() || has(args, "-h") || has(args, "--help")) { schemaHelp(); return 0; }
        String sub = args.remove(0);
        if (has(args, "-h") || has(args, "--help")) { schemaSubHelp(sub); return 0; }
        switch (sub) {
            case "fmt": return schemaFmt(args);
            case "inspect": return schemaInspect(args);
            case "apply":
                if (!hasFlagValue(args, "-u", "--url")) return required("url");
                return unsupportedDev();
            case "diff":
                if (!hasFlagValue(args, "-f", "--from")) return required("from");
                if (!hasFlagValue(args, null, "--to")) return required("to");
                return unsupportedDev();
            case "clean":
                if (!hasFlagValue(args, "-u", "--url")) return required("url");
                return unsupportedDev();
            default: err("Error: unknown command \"" + sub + "\" for \"atlas schema\""); return 1;
        }
    }

    int schemaInspect(List<String> args) {
        String url = flagValue(args, "-u", "--url");
        if (url == null) return required("url");
        if (url.startsWith("file://")) { err("Error: --dev-url cannot be empty"); return 1; }
        if (url.startsWith("sqlite://")) {
            System.err.print("Notice: This Atlas edition lacks support for features such as checkpoints,\n" +
                    "testing, down migrations, and more. Additionally, advanced database objects such as views, \n" +
                    "triggers, and stored procedures are not supported. To read more: https://atlasgo.io/community-edition\n\n" +
                    "To install the non-community version of Atlas, use the following command:\n\n" +
                    "\tcurl -sSf https://atlasgo.sh | sh\n\n" +
                    "Or, visit the website to see all installation options:\n\n" +
                    "\thttps://atlasgo.io/docs#installation\n\n");
            System.out.println("schema \"main\" {\n}");
            return 0;
        }
        return unsupportedDev();
    }

    int schemaFmt(List<String> args) throws IOException {
        stripGlobal(args);
        List<String> paths = new ArrayList<>();
        for (String s : args) if (!s.startsWith("-")) paths.add(s);
        if (paths.isEmpty()) paths.add(".");
        boolean ok = true;
        for (String p : paths) {
            Path path = Paths.get(p);
            if (!Files.exists(path)) {
                err("Error: stat " + p + ": no such file or directory\n" + COMMUNITY);
                ok = false;
                continue;
            }
            if (Files.isDirectory(path)) {
                try (Stream<Path> st = Files.walk(path)) {
                    for (Path f : (Iterable<Path>) st.filter(x -> x.toString().endsWith(".hcl")).sorted()::iterator) {
                        fmtFile(f);
                    }
                }
            } else {
                fmtFile(path);
            }
        }
        return ok ? 0 : 1;
    }

    void fmtFile(Path f) throws IOException {
        String old = Files.readString(f);
        String neu = formatHcl(old);
        if (!old.equals(neu)) {
            Files.writeString(f, neu);
            System.out.println(f.toString());
        }
    }

    String formatHcl(String s) {
        StringBuilder out = new StringBuilder();
        String[] lines = s.replace("\r\n", "\n").split("\n", -1);
        int n = lines.length;
        if (n > 0 && lines[n - 1].isEmpty()) n--;
        for (int idx = 0; idx < n; idx++) {
            String raw = lines[idx];
            if (raw.isEmpty()) { out.append("\n"); continue; }
            int lead = 0; while (lead < raw.length() && raw.charAt(lead) == ' ') lead++;
            String line = raw.trim();
            line = line.replaceAll("\\s+", " ");
            line = line.replaceAll("\\s*=\\s*", " = ");
            line = line.replaceAll("\\s+\\{", " {");
            line = line.replaceAll("\\[\\s+", "[");
            line = line.replaceAll("\\s+\\]", "]");
            int indent = (lead / 2) * 2;
            out.append(" ".repeat(Math.max(0, indent))).append(line).append("\n");
        }
        return out.toString();
    }

    int migrate(List<String> args) throws Exception {
        if (args.isEmpty() || has(args, "-h") || has(args, "--help")) { migrateHelp(); return 0; }
        String sub = args.remove(0);
        if (has(args, "-h") || has(args, "--help")) { migrateSubHelp(sub); return 0; }
        switch (sub) {
            case "new": return migrateNew(args);
            case "hash": return migrateHash(args);
            case "validate": return migrateValidate(args);
            case "status":
                if (!Files.exists(dirPath(flagValue(args, null, "--dir"), "migrations"))) {
                    err("Error: sql/migrate: stat " + dirPath(flagValue(args, null, "--dir"), "migrations") + ": no such file or directory");
                    return 1;
                }
                err("Error: required flag(s) \"url\" not set"); return 1;
            case "apply":
            case "diff":
            case "lint":
            case "import":
            case "set":
                return unsupportedDev();
            default: err("Error: unknown command \"" + sub + "\" for \"atlas migrate\""); return 1;
        }
    }

    int migrateNew(List<String> args) throws IOException {
        String name = "";
        for (int i = 0; i < args.size(); i++) {
            String s = args.get(i);
            if (s.equals("--dir") || s.equals("--dir-format") || s.equals("-c") || s.equals("--config") || s.equals("--env") || s.equals("--var")) {
                i++;
                continue;
            }
            if (!s.startsWith("-")) name = s;
        }
        Path dir = dirPath(flagValue(args, null, "--dir"), "migrations");
        Files.createDirectories(dir);
        String ts = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(ZoneOffset.UTC).format(Instant.now());
        String suffix = name.isEmpty() ? "" : "_" + sanitize(name);
        Files.writeString(dir.resolve(ts + suffix + ".sql"), "");
        return 0;
    }

    int migrateHash(List<String> args) throws Exception {
        Path dir = dirPath(flagValue(args, null, "--dir"), "migrations");
        if (!Files.exists(dir)) { err("Error: sql/migrate: stat " + dir + ": no such file or directory"); return 1; }
        Files.writeString(dir.resolve("atlas.sum"), sumFile(dir));
        return 0;
    }

    int migrateValidate(List<String> args) throws Exception {
        Path dir = dirPath(flagValue(args, null, "--dir"), "migrations");
        if (!Files.exists(dir)) { err("Error: sql/migrate: stat " + dir + ": no such file or directory"); return 1; }
        Path sum = dir.resolve("atlas.sum");
        if (!Files.exists(sum)) { err("Error: checksum file not found"); return 1; }
        String expected = Files.readString(sum);
        String got = sumFile(dir);
        if (!expected.equals(got)) { err("Error: checksum mismatch"); return 1; }
        return 0;
    }

    String sumFile(Path dir) throws Exception {
        List<Path> files = new ArrayList<>();
        try (Stream<Path> st = Files.list(dir)) {
            st.filter(Files::isRegularFile).filter(p -> !p.getFileName().toString().equals("atlas.sum")).sorted().forEach(files::add);
        }
        StringBuilder body = new StringBuilder();
        for (Path p : files) body.append(p.getFileName()).append(" h1:").append(hash(Files.readAllBytes(p))).append("\n");
        String root = hash(body.toString().getBytes(StandardCharsets.UTF_8));
        return "h1:" + root + "\n" + body;
    }

    static String hash(byte[] b) throws Exception {
        return Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest(b));
    }

    Path dirPath(String raw, String def) {
        String s = raw == null ? def : raw;
        if (s.startsWith("file://")) s = s.substring(7);
        if (s.isEmpty()) s = ".";
        return Paths.get(s);
    }

    int completion(List<String> args) {
        if (args.isEmpty() || has(args, "-h") || has(args, "--help")) { completionHelp(); return 0; }
        if (List.of("bash","zsh","fish","powershell").contains(args.get(0))) {
            System.out.println("# completion script for atlas " + args.get(0));
            return 0;
        }
        err("Error: unknown command \"" + args.get(0) + "\" for \"atlas completion\"");
        return 1;
    }

    int required(String name) { err("Error: required flag(s) \"" + name + "\" not set"); return 1; }
    int unsupportedDev() { err("Error: --dev-url cannot be empty"); return 1; }
    static void err(String s) { System.err.println(s); }
    static boolean has(List<String> a, String f) { return a.contains(f); }
    static boolean isHelpOnly(List<String> a) { return a.size() == 1 && (a.get(0).equals("-h") || a.get(0).equals("--help")); }
    static String sanitize(String s) { return s.trim().replaceAll("[^A-Za-z0-9_]+", "_"); }

    boolean hasFlagValue(List<String> a, String shortF, String longF) { return flagValue(a, shortF, longF) != null; }
    String flagValue(List<String> a, String shortF, String longF) {
        for (int i = 0; i < a.size(); i++) {
            String s = a.get(i);
            if (longF != null && s.startsWith(longF + "=")) return s.substring(longF.length()+1);
            if ((shortF != null && s.equals(shortF)) || (longF != null && s.equals(longF))) {
                if (i + 1 < a.size()) return a.get(i+1);
            }
        }
        return null;
    }
    void stripGlobal(List<String> a) {}

    void version() {
        System.out.println("atlas unofficial version - development");
        System.out.println("https://github.com/ariga/atlas/releases/latest");
        System.out.println("To download an official version, visit: https://atlasgo.io/getting-started#installation");
    }
    void license() {
        System.out.println("LICENSE");
        System.out.println("Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.");
    }
    void rootHelp() {
        System.out.println("Manage your database schema as code\n\nUsage:\n  atlas [command]\n\nAvailable Commands:\n  completion  Generate the autocompletion script for the specified shell\n  help        Help about any command\n  license     Display license information\n  migrate     Manage versioned migration files\n  schema      Work with atlas schemas.\n  version     Prints this Atlas CLI version information.\n\nFlags:\n  -h, --help   help for atlas\n\nUse \"atlas [command] --help\" for more information about a command.");
    }
    void schemaHelp() {
        System.out.println("The `atlas schema` command groups subcommands working with declarative Atlas schemas.\n\nUsage:\n  atlas schema [command]\n\nAvailable Commands:\n  apply       Apply an atlas schema to a target database.\n  clean       Removes all objects from the connected database.\n  diff        Calculate and print the diff between two schemas.\n  fmt         Formats Atlas HCL files\n  inspect     Inspect a database and print its schema in Atlas DDL syntax.\n\nFlags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n  -h, --help                 help for schema\n      --var <name>=<value>   input variables (default [])\n\nUse \"atlas schema [command] --help\" for more information about a command.");
    }
    void migrateHelp() {
        System.out.println("'atlas migrate' wraps several sub-commands for migration management.\n\nUsage:\n  atlas migrate [command]\n\nAvailable Commands:\n  apply       Applies pending migration files on the connected database.\n  diff        Compute the diff between the migration directory and a desired state and create a new migration file.\n  hash        Hash (re-)creates an integrity hash file for the migration directory.\n  import      Import a migration directory from another migration management tool to the Atlas format.\n  lint        Run analysis on the migration directory\n  new         Creates a new empty migration file in the migration directory.\n  set         Set the current version of the migration history table.\n  status      Get information about the current migration status.\n  validate    Validates the migration directories checksum and SQL statements.\n\nFlags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n  -h, --help                 help for migrate\n      --var <name>=<value>   input variables (default [])\n\nUse \"atlas migrate [command] --help\" for more information about a command.");
    }
    void completionHelp() {
        System.out.println("Generate the autocompletion script for atlas for the specified shell.\nSee each sub-command's help for details on how to use the generated script.\n\nUsage:\n  atlas completion [command]\n\nAvailable Commands:\n  bash        Generate the autocompletion script for bash\n  fish        Generate the autocompletion script for fish\n  powershell  Generate the autocompletion script for powershell\n  zsh         Generate the autocompletion script for zsh\n\nFlags:\n  -h, --help   help for completion\n\nUse \"atlas completion [command] --help\" for more information about a command.");
    }
    void schemaSubHelp(String sub) {
        if (sub.equals("fmt")) System.out.println("'atlas schema fmt' formats all \".hcl\" files under the given paths using\ncanonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.\nUnless stated otherwise, the fmt command will use the current directory.\n\nAfter running, the command will print the names of the files it has formatted. If all\nfiles in the directory are formatted, no input will be printed out.\n\nUsage:\n  atlas schema fmt [path ...] [flags]\n\nFlags:\n  -h, --help   help for fmt\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
        else if (sub.equals("inspect")) System.out.println("'atlas schema inspect' connects to the given database and inspects its schema.\nIt then prints to the screen the schema of that database in Atlas DDL syntax.\n\nUsage:\n  atlas schema inspect [flags]\n\nFlags:\n  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n  -s, --schema strings    set schema names\n      --exclude strings   list of glob patterns used to filter resources from applying\n      --format string     Go template to use to format the output\n  -h, --help              help for inspect");
        else System.out.println("Usage:\n  atlas schema " + sub + " [flags]\n\nFlags:\n  -h, --help   help for " + sub);
    }
    void migrateSubHelp(String sub) {
        if (sub.equals("new")) System.out.println("'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.\n\nUsage:\n  atlas migrate new [flags] [name]\n\nExamples:\n  atlas migrate new my-new-migration\n\nFlags:\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n      --edit                edit the created migration file(s)\n  -h, --help                help for new");
        else if (sub.equals("hash")) System.out.println("'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.\nThis command should be used whenever a manual change in the migration directory was made.\n\nUsage:\n  atlas migrate hash [flags]\n\nFlags:\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n  -h, --help                help for hash");
        else if (sub.equals("validate")) System.out.println("'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the\natlas.sum file. If there is a mismatch it will be reported.\n\nUsage:\n  atlas migrate validate [flags]\n\nFlags:\n      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n  -h, --help                help for validate");
        else System.out.println("Usage:\n  atlas migrate " + sub + " [flags]");
    }
}
