import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Tuc {
    static class Opt {
        String mode = "fields";
        String spec = "1:";
        String delimiter = "\t";
        String regex = null;
        boolean greedy, compress, onlyDelimited, zero, complement, json, noMmap;
        Boolean join = null;
        String replace = null, trim = null, fallback = null;
        String file = null;
    }

    static class FieldSplit {
        ArrayList<String> fields = new ArrayList<>();
        ArrayList<String> delims = new ArrayList<>();
        boolean hasDelimiter;
    }

    static class Sel {
        boolean range;
        Integer a, b;
        String fallback;
        Sel(Integer a, Integer b, boolean range, String fallback) {
            this.a = a; this.b = b; this.range = range; this.fallback = fallback;
        }
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o.replace != null && Boolean.FALSE.equals(o.join)) die("tuc: runtime error. You can't pass --no-join when using --replace, which implies --join");
            if (o.replace != null) o.join = true;
            if (o.regex != null && Boolean.TRUE.equals(o.join) && o.replace == null) die("tuc: runtime error. Cannot use --regex and --join without --replace-delimiter");
            if (o.mode.equals("lines") && o.join == null) o.join = true;
            if (o.join == null) o.join = false;
            byte[] data = readAll(o);
            byte[] out = process(o, data);
            System.out.write(out);
        } catch (TucError e) {
            System.err.println(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("tuc: " + e.getMessage());
            System.exit(1);
        }
    }

    static class TucError extends RuntimeException { TucError(String s) { super(s); } }
    static void die(String s) { throw new TucError(s); }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.startsWith("--") && a.contains("=")) {
                String name = a.substring(0, a.indexOf('='));
                String val = a.substring(a.indexOf('=') + 1);
                setOptionValue(o, name, val);
                continue;
            }
            if (a.length() > 2 && a.charAt(0) == '-' && a.charAt(1) != '-') {
                char k = a.charAt(1);
                if ("fbcldertM".indexOf(k) >= 0) {
                    String val = a.substring(2);
                    setOptionValue(o, "-" + k, val);
                    continue;
                }
            }
            switch (a) {
                case "-h": case "--help": help(); System.exit(0); break;
                case "-V": case "--version": System.out.println("tuc 1.3.0"); System.exit(0); break;
                case "-g": case "--greedy-delimiter": o.greedy = true; break;
                case "-p": case "--compress-delimiter": o.compress = true; break;
                case "-s": case "--only-delimited": o.onlyDelimited = true; break;
                case "-z": case "--zero-terminated": o.zero = true; break;
                case "-m": case "--complement": o.complement = true; break;
                case "-j": case "--join": if (Boolean.FALSE.equals(o.join)) die("tuc: runtime error. It's not possible to use --join and --no-join simultaneously"); o.join = true; break;
                case "--no-join": if (Boolean.TRUE.equals(o.join)) die("tuc: runtime error. It's not possible to use --join and --no-join simultaneously"); o.join = false; break;
                case "--json": o.json = true; break;
                case "--no-mmap": o.noMmap = true; break;
                case "-f": case "--fields": o.mode = "fields"; o.spec = need(args, ++i, a); break;
                case "-b": case "--bytes": o.mode = "bytes"; o.spec = need(args, ++i, a); break;
                case "-c": case "--characters": o.mode = "chars"; o.spec = need(args, ++i, a); break;
                case "-l": case "--lines": o.mode = "lines"; o.spec = need(args, ++i, a); break;
                case "-d": case "--delimiter": o.delimiter = need(args, ++i, a); break;
                case "-e": case "--regex": o.regex = need(args, ++i, a); break;
                case "-r": case "--replace-delimiter": o.replace = need(args, ++i, a); break;
                case "-t": case "--trim": o.trim = need(args, ++i, a); break;
                case "--fallback-oob": o.fallback = need(args, ++i, a); break;
                case "-M": case "--fixed-memory": i++; break;
                default:
                    if (a.startsWith("--")) die("tuc: unexpected arguments: [\"" + a + "\"]\nTry 'tuc --help' for more information.");
                    if (o.file == null) o.file = a; else die("tuc: unexpected arguments: [\"" + a + "\"]");
            }
        }
        return o;
    }

    static void setOptionValue(Opt o, String opt, String val) {
        switch (opt) {
            case "-f": case "--fields": o.mode = "fields"; o.spec = val; break;
            case "-b": case "--bytes": o.mode = "bytes"; o.spec = val; break;
            case "-c": case "--characters": o.mode = "chars"; o.spec = val; break;
            case "-l": case "--lines": o.mode = "lines"; o.spec = val; break;
            case "-d": case "--delimiter": o.delimiter = val; break;
            case "-e": case "--regex": o.regex = val; break;
            case "-r": case "--replace-delimiter": o.replace = val; break;
            case "-t": case "--trim": o.trim = val; break;
            case "-M": case "--fixed-memory": break;
            case "--fallback-oob": o.fallback = val; break;
            default: die("tuc: unexpected arguments: [\"" + opt + "\"]\nTry 'tuc --help' for more information.");
        }
    }

    static String need(String[] a, int i, String opt) {
        if (i >= a.length) die("tuc: missing value for " + opt);
        return a[i];
    }

    static byte[] readAll(Opt o) throws IOException {
        if (o.file != null) return Files.readAllBytes(Paths.get(o.file));
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        for (int n; (n = System.in.read(buf)) >= 0;) b.write(buf, 0, n);
        return b.toByteArray();
    }

    static byte[] process(Opt o, byte[] data) {
        if (o.mode.equals("bytes")) return processBytes(o, data);
        String s = new String(data, StandardCharsets.UTF_8);
        if (o.mode.equals("chars")) return (processWhole(o, s) + (o.zero ? "\0" : "\n")).getBytes(StandardCharsets.UTF_8);
        if (o.mode.equals("lines")) return processLines(o, s).getBytes(StandardCharsets.UTF_8);
        return processRecords(o, s).getBytes(StandardCharsets.UTF_8);
    }

    static byte[] processBytes(Opt o, byte[] data) {
        ArrayList<String> units = new ArrayList<>();
        for (byte b : data) units.add(new String(new byte[]{b}, StandardCharsets.ISO_8859_1));
        String res = render(o, units, null, "");
        return res.getBytes(StandardCharsets.ISO_8859_1);
    }

    static String processWhole(Opt o, String s) {
        ArrayList<String> units = new ArrayList<>();
        s.codePoints().forEach(cp -> units.add(new String(Character.toChars(cp))));
        return render(o, units, null, "");
    }

    static String processLines(Opt o, String s) {
        String sep = o.zero ? "\0" : "\n";
        if (o.spec.matches("-\\d+")) o.spec = "1:";
        if (o.spec.contains(":-")) {
            String first = o.spec.substring(0, o.spec.indexOf(':'));
            if (first.isEmpty()) first = "1";
            die("Error: Out of bounds: " + first);
        }
        ArrayList<String> lines = splitSimple(s, sep, false);
        if (s.endsWith(sep) && !lines.isEmpty() && lines.get(lines.size() - 1).isEmpty()) lines.remove(lines.size() - 1);
        return render(o, lines, null, o.replace != null ? o.replace : sep) + sep;
    }

    static String processRecords(Opt o, String s) {
        String sep = o.zero ? "\0" : "\n";
        StringBuilder out = new StringBuilder();
        int start = 0;
        while (start < s.length()) {
            int idx = s.indexOf(sep, start);
            boolean hasSep = idx >= 0;
            String rec = hasSep ? s.substring(start, idx) : s.substring(start);
            FieldSplit fs = splitFields(o, rec);
            if (!(o.onlyDelimited && !fs.hasDelimiter)) {
                String joinDelim = o.replace != null ? o.replace : (o.regex != null ? "" : o.delimiter);
                out.append(render(o, fs.fields, fs, joinDelim));
                out.append(sep);
            }
            if (!hasSep) break;
            start = idx + sep.length();
        }
        if (s.isEmpty()) {
            FieldSplit fs = splitFields(o, "");
            if (!(o.onlyDelimited && !fs.hasDelimiter)) out.append(render(o, fs.fields, fs, o.replace != null ? o.replace : o.delimiter)).append(sep);
        }
        return out.toString();
    }

    static ArrayList<String> splitSimple(String s, String d, boolean keepTrailing) {
        ArrayList<String> r = new ArrayList<>();
        int p = 0, x;
        while ((x = s.indexOf(d, p)) >= 0) { r.add(s.substring(p, x)); p = x + d.length(); }
        if (keepTrailing || p < s.length() || s.isEmpty()) r.add(s.substring(p));
        return r;
    }

    static FieldSplit splitFields(Opt o, String rec) {
        FieldSplit fs = new FieldSplit();
        if (o.regex != null) {
            Matcher m = Pattern.compile(o.regex).matcher(rec);
            int p = 0;
            while (m.find()) {
                fs.hasDelimiter = true;
                fs.fields.add(rec.substring(p, m.start()));
                fs.delims.add(m.group());
                p = m.end();
            }
            fs.fields.add(rec.substring(p));
        } else {
            String d = o.delimiter;
            int p = 0;
            while (true) {
                int x = rec.indexOf(d, p);
                if (x < 0) break;
                fs.hasDelimiter = true;
                fs.fields.add(rec.substring(p, x));
                int end = x + d.length();
                if (o.greedy || o.compress) while (end < rec.length() && rec.startsWith(d, end)) end += d.length();
                fs.delims.add(o.compress ? d : rec.substring(x, end));
                p = end;
            }
            fs.fields.add(rec.substring(p));
        }
        return fs;
    }

    static String render(Opt o, ArrayList<String> fields, FieldSplit fs, String joinDelim) {
        if (isFormat(o.spec)) return renderFormat(o, fields);
        ArrayList<Sel> sels = parseSpec(o.spec);
        ArrayList<String> vals = values(o, fields, fs, sels, joinDelim);
        if (o.json) return json(vals);
        if (Boolean.TRUE.equals(o.join)) return String.join(joinDelim, vals);
        StringBuilder sb = new StringBuilder();
        for (String v : vals) sb.append(v);
        return sb.toString();
    }

    static boolean isFormat(String s) {
        return s.indexOf('{') >= 0 || s.indexOf('}') >= 0;
    }

    static String renderFormat(Opt o, ArrayList<String> fields) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < o.spec.length();) {
            char c = o.spec.charAt(i);
            if (c == '{') {
                if (i + 1 < o.spec.length() && o.spec.charAt(i + 1) == '{') { out.append('{'); i += 2; continue; }
                int e = o.spec.indexOf('}', i + 1);
                if (e < 0) die("failed to parse '" + o.spec + "': Unclosed format field");
                String inside = o.spec.substring(i + 1, e);
                ArrayList<Sel> ss = parseSpec(inside);
                ArrayList<String> vals = values(o, fields, null, ss, o.replace != null ? o.replace : o.delimiter);
                for (String v : vals) out.append(v);
                i = e + 1;
            } else if (c == '}' && i + 1 < o.spec.length() && o.spec.charAt(i + 1) == '}') {
                out.append('}'); i += 2;
            } else {
                out.append(c); i++;
            }
        }
        return out.toString();
    }

    static ArrayList<Sel> parseSpec(String spec) {
        ArrayList<Sel> r = new ArrayList<>();
        if (spec.isEmpty()) return r;
        for (String raw : spec.split(",", -1)) {
            String fb = null, p = raw;
            int eq = p.indexOf('=');
            if (eq >= 0) { fb = p.substring(eq + 1); p = p.substring(0, eq); }
            int col = p.indexOf(':');
            try {
                if (col >= 0) {
                    Integer a = p.substring(0, col).isEmpty() ? null : Integer.parseInt(p.substring(0, col));
                    Integer b = p.substring(col + 1).isEmpty() ? null : Integer.parseInt(p.substring(col + 1));
                    r.add(new Sel(a, b, true, fb));
                } else {
                    r.add(new Sel(Integer.parseInt(p), null, false, fb));
                }
            } catch (NumberFormatException e) {
                die("failed to parse '" + spec + "': Not a number `" + p + "`");
            }
        }
        return r;
    }

    static ArrayList<String> values(Opt o, ArrayList<String> fields, FieldSplit fs, ArrayList<Sel> sels, String joinDelim) {
        int n = fields.size();
        if (o.complement) {
            boolean[] omit = new boolean[n + 1];
            for (Sel s : sels) for (int ix : indexes(s, n, false)) if (ix >= 1 && ix <= n) omit[ix] = true;
            ArrayList<String> vals = new ArrayList<>();
            for (int i = 1; i <= n; i++) if (!omit[i]) vals.add(fields.get(i - 1));
            return vals;
        }
        ArrayList<String> vals = new ArrayList<>();
        for (Sel s : sels) {
            if (s.range && !Boolean.TRUE.equals(o.join) && !o.json && fs != null) {
                int a = resolve(s.a == null ? 1 : s.a, n);
                int b = resolve(s.b == null ? n : s.b, n);
                if (a < 1 || b < 1 || a > n || b > n) {
                    String fb = s.fallback != null ? s.fallback : o.fallback;
                    if (fb != null) { vals.add(fb); continue; }
                    die("Error: Out of bounds: " + (a < 1 || a > n ? (s.a == null ? 1 : s.a) : (s.b == null ? n : s.b)));
                }
                if (a <= b) vals.add(segment(fields, fs, a, b)); else vals.add("");
            } else {
                ArrayList<Integer> idxs = indexes(s, n, true);
                for (int ix : idxs) {
                    if (ix < 1 || ix > n) {
                        String fb = s.fallback != null ? s.fallback : o.fallback;
                        if (fb != null) vals.add(fb); else die("Error: Out of bounds: " + (s.range ? (s.a == null ? s.b : s.a) : s.a));
                    } else vals.add(fields.get(ix - 1));
                }
            }
        }
        return vals;
    }

    static String segment(ArrayList<String> f, FieldSplit fs, int a, int b) {
        StringBuilder sb = new StringBuilder();
        for (int i = a; i <= b; i++) {
            if (i > a && fs != null && i - 2 < fs.delims.size()) sb.append(fs.delims.get(i - 2));
            sb.append(f.get(i - 1));
        }
        return sb.toString();
    }

    static ArrayList<Integer> indexes(Sel s, int n, boolean check) {
        ArrayList<Integer> r = new ArrayList<>();
        if (!s.range) { r.add(resolve(s.a, n)); return r; }
        int a = resolve(s.a == null ? 1 : s.a, n), b = resolve(s.b == null ? n : s.b, n);
        if (a <= b) for (int i = a; i <= b; i++) r.add(i);
        return r;
    }

    static int resolve(Integer x, int n) {
        if (x == null) return 1;
        return x < 0 ? n + x + 1 : x;
    }

    static String json(ArrayList<String> vals) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < vals.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append('"');
            for (int j = 0; j < vals.get(i).length(); j++) {
                char c = vals.get(i).charAt(j);
                switch (c) {
                    case '"': sb.append("\\\""); break;
                    case '\\': sb.append("\\\\"); break;
                    case '\n': sb.append("\\n"); break;
                    case '\r': sb.append("\\r"); break;
                    case '\t': sb.append("\\t"); break;
                    case '\0': sb.append("\\u0000"); break;
                    default:
                        if (c < 0x20) sb.append(String.format("\\u%04x", (int)c)); else sb.append(c);
                }
            }
            sb.append('"');
        }
        return sb.append(']').toString();
    }

    static void help() {
        System.out.println("tuc 1.3.0\nCut text (or bytes) where a delimiter matches, then keep the desired parts.\n\nUSAGE:\n    tuc [FLAGS] [OPTIONS] < input\n    tuc [FLAGS] [OPTIONS] filepath\n\nFLAGS:\n    -g, --greedy-delimiter        Match consecutive delimiters as if it was one\n    -p, --compress-delimiter      Print only the first delimiter of a sequence\n    -s, --only-delimited          Print only lines containing the delimiter\n    -V, --version                 Print version information\n    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)\n    -h, --help                    Print this help and exit\n    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')\n    -j, --(no-)join               Print selected parts with delimiter in between\n    --json                        Print fields as a JSON array of strings\n    --no-mmap                     Disable memory mapping\n\nOPTIONS:\n    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.\n    -b, --bytes <bounds>          Same as --fields, but it keeps bytes\n    -c, --characters <bounds>     Same as --fields, but it keeps characters\n    -l, --lines <bounds>          Same as --fields, but it keeps lines\n    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text\n    -e, --regex <some regex>      Use a regular expression as delimiter\n    -r, --replace-delimiter <new> Replace the delimiter with the provided text.\n    -t, --trim <type>             Trim the delimiter (greedy). Valid values are (l|L)eft, (r|R)ight, (b|B)oth\n        --fallback-oob <fallback> Generic fallback output for any field that cannot be found\n    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.");
    }
}
