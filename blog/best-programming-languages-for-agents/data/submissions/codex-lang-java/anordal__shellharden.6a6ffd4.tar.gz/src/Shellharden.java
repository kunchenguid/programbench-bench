import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Shellharden {
    private enum Mode { SYNTAX_SUGGEST, SUGGEST, SYNTAX, TRANSFORM, CHECK, REPLACE }

    private static final String HELP = """
Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like `cat`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
""";

    private static final String GREEN = "\033[0;42m";
    private static final String RED = "\033[0;41m";
    private static final String RESET = "\033[m";
    private static final String CMD = "\033[0;38;2;192;0;128m";
    private static final String VAR = "\033[0;38;2;63;127;207m";
    private static final String STR = "\033[0;38;2;255;0;0m";
    private static final String KW = "\033[0;1m";

    public static void main(String[] args) {
        int code;
        try {
            code = run(args);
        } catch (IOException e) {
            System.err.println(e.getMessage());
            code = 1;
        }
        System.exit(code);
    }

    private static int run(String[] args) throws IOException {
        Mode mode = Mode.SYNTAX_SUGGEST;
        List<String> files = new ArrayList<>();
        boolean endOptions = false;
        for (String arg : args) {
            if (!endOptions && arg.startsWith("-") && !arg.equals("")) {
                switch (arg) {
                    case "--suggest" -> mode = Mode.SUGGEST;
                    case "--syntax" -> mode = Mode.SYNTAX;
                    case "--syntax-suggest" -> mode = Mode.SYNTAX_SUGGEST;
                    case "--transform" -> mode = Mode.TRANSFORM;
                    case "--check" -> mode = Mode.CHECK;
                    case "--replace" -> mode = Mode.REPLACE;
                    case "--" -> endOptions = true;
                    case "-h", "--help" -> {
                        System.out.print(HELP);
                        return 0;
                    }
                    case "--version" -> {
                        System.out.println("4.3.1");
                        return 0;
                    }
                    default -> {
                        System.err.println(arg + ": No such option.");
                        return 3;
                    }
                }
            } else {
                files.add(arg);
            }
        }

        if (mode == Mode.REPLACE) {
            if (files.isEmpty()) {
                String text = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
                System.out.print(syntaxSuggest(text));
                return 0;
            }
            for (String f : files) {
                if (f.equals("")) {
                    String text = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
                    System.out.print(syntaxSuggest(text));
                    continue;
                }
                Path p = Path.of(f);
                String text = Files.readString(p);
                Files.writeString(p, transform(text), StandardCharsets.UTF_8);
            }
            return 0;
        }

        StringBuilder input = new StringBuilder();
        if (files.isEmpty()) {
            input.append(new String(System.in.readAllBytes(), StandardCharsets.UTF_8));
        } else {
            for (String f : files) {
                if (f.equals("")) {
                    input.append(new String(System.in.readAllBytes(), StandardCharsets.UTF_8));
                } else {
                    try {
                        input.append(Files.readString(Path.of(f)));
                    } catch (NoSuchFileException e) {
                        System.err.println(f + ": No such file or directory (os error 2)");
                        return 1;
                    } catch (IOException e) {
                        System.err.println(f + ": " + e.getMessage());
                        return 1;
                    }
                }
            }
        }

        String original = input.toString();
        String transformed = transform(original);
        if (mode == Mode.CHECK) {
            return original.equals(transformed) ? 0 : 2;
        }
        switch (mode) {
            case TRANSFORM -> System.out.print(transformed);
            case SUGGEST -> System.out.print(suggest(original));
            case SYNTAX -> System.out.print(syntax(original));
            case SYNTAX_SUGGEST -> System.out.print(syntaxSuggest(original));
            default -> {}
        }
        return 0;
    }

    private static String transform(String input) {
        StringBuilder out = new StringBuilder();
        int start = 0;
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == '\n') {
                out.append(transformLine(input.substring(start, i)));
                out.append('\n');
                start = i + 1;
            }
        }
        if (start < input.length()) out.append(transformLine(input.substring(start)));
        return out.toString();
    }

    private static String transformLine(String line) {
        StringBuilder out = new StringBuilder();
        String prevWord = "";
        boolean atWordStart = true;
        boolean inSingle = false, inDouble = false, inBracketTest = false;
        for (int i = 0; i < line.length(); ) {
            char c = line.charAt(i);
            if (inSingle) {
                out.append(c);
                if (c == '\'') inSingle = false;
                i++;
                continue;
            }
            if (inDouble) {
                out.append(c);
                if (c == '"' && !escaped(line, i)) inDouble = false;
                i++;
                continue;
            }
            if (c == '#') {
                out.append(line.substring(i));
                break;
            }
            if (c == '\'') {
                inSingle = true; out.append(c); i++; atWordStart = false; continue;
            }
            if (c == '"') {
                inDouble = true; out.append(c); i++; atWordStart = false; continue;
            }
            if (i + 1 < line.length() && line.startsWith("[[", i)) {
                inBracketTest = true; out.append("[["); i += 2; atWordStart = true; prevWord = "[["; continue;
            }
            if (i + 1 < line.length() && line.startsWith("]]", i)) {
                inBracketTest = false; out.append("]]"); i += 2; atWordStart = false; prevWord = "]]"; continue;
            }
            if (c == '$' && i + 1 < line.length() && line.charAt(i + 1) == '(') {
                int end = findMatching(line, i + 1, '(', ')');
                if (end > 0) {
                    out.append(inBracketTest ? line.substring(i, end + 1) : "\"" + line.substring(i, end + 1) + "\"");
                    i = end + 1;
                    atWordStart = false;
                    prevWord = "";
                    continue;
                }
            }
            if (Character.isWhitespace(c) || ";|&()<>".indexOf(c) >= 0) {
                out.append(c);
                atWordStart = true;
                if (";|&()<>".indexOf(c) >= 0) prevWord = "";
                i++;
                continue;
            }

            int j = i;
            while (j < line.length()) {
                char d = line.charAt(j);
                if (Character.isWhitespace(d) || ";|&()<>".indexOf(d) >= 0 || d == '\'' || d == '"' || d == '#') break;
                j++;
            }
            String word = line.substring(i, j);
            String newWord = word;
            if (inBracketTest) {
                newWord = word;
            } else if (isAssignmentWord(word)) {
                newWord = word;
            } else if (prevWord.equals("case")) {
                newWord = word;
            } else if (prevWord.equals("in") && word.startsWith("$") && simpleDollarName(word).length() > 0 && word.equals("$" + simpleDollarName(word))) {
                newWord = "\"${" + simpleDollarName(word) + "[@]}\"";
            } else {
                newWord = transformWord(word);
            }
            out.append(newWord);
            prevWord = bareWordForContext(word);
            atWordStart = false;
            i = j;
        }
        return out.toString();
    }

    private static boolean escaped(String s, int i) {
        int n = 0;
        for (int j = i - 1; j >= 0 && s.charAt(j) == '\\'; j--) n++;
        return (n % 2) == 1;
    }

    private static boolean isAssignmentWord(String w) {
        int eq = w.indexOf('=');
        if (eq <= 0) return false;
        for (int i = 0; i < eq; i++) {
            char c = w.charAt(i);
            if (i == 0) {
                if (!(c == '_' || Character.isLetter(c))) return false;
            } else if (!(c == '_' || Character.isLetterOrDigit(c))) return false;
        }
        return true;
    }

    private static String bareWordForContext(String w) {
        if (w.equals("for") || w.equals("in") || w.equals("case") || w.equals("do") || w.equals("then")) return w;
        return w.replaceAll("[^A-Za-z_]", "");
    }

    private static String simpleDollarName(String w) {
        if (!w.startsWith("$") || w.length() < 2) return "";
        int i = 1;
        char c = w.charAt(i);
        if (!(c == '_' || Character.isLetter(c))) return "";
        i++;
        while (i < w.length()) {
            c = w.charAt(i);
            if (!(c == '_' || Character.isLetterOrDigit(c))) break;
            i++;
        }
        return w.substring(1, i);
    }

    private static String transformWord(String w) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < w.length(); ) {
            char c = w.charAt(i);
            if (c == '$') {
                Expansion e = parseDollar(w, i);
                if (e != null) {
                    if (e.safeBare) out.append(e.text);
                    else out.append('"').append(e.text).append('"');
                    i = e.end;
                    continue;
                }
            }
            if (c == '`') {
                int end = w.indexOf('`', i + 1);
                if (end > i) {
                    out.append("\"$(").append(w, i + 1, end).append(")\"");
                    i = end + 1;
                    continue;
                }
            }
            out.append(c);
            i++;
        }
        return out.toString();
    }

    private static class Expansion {
        String text; int end; boolean safeBare;
        Expansion(String text, int end, boolean safeBare) { this.text = text; this.end = end; this.safeBare = safeBare; }
    }

    private static Expansion parseDollar(String w, int i) {
        if (i + 1 >= w.length()) return null;
        char n = w.charAt(i + 1);
        if (n == '(') {
            int end = findMatching(w, i + 1, '(', ')');
            if (end > 0) return new Expansion(w.substring(i, end + 1), end + 1, false);
            return null;
        }
        if (n == '{') {
            int end = findMatching(w, i + 1, '{', '}');
            if (end > 0) {
                String body = w.substring(i + 2, end);
                boolean safe = body.equals("#") || body.startsWith("#") && body.endsWith("[@]");
                String text = w.substring(i, end + 1);
                if (body.matches("[A-Za-z_][A-Za-z0-9_]*")) {
                    boolean needsBraces = end + 1 < w.length() && isIdentifierTail(w.charAt(end + 1));
                    text = needsBraces ? text : "$" + body;
                }
                return new Expansion(text, end + 1, safe);
            }
            return null;
        }
        if ("?!#$".indexOf(n) >= 0) return new Expansion("$" + n, i + 2, true);
        if (n == '*') return new Expansion("$@", i + 2, false);
        if (n == '@') return new Expansion("$@", i + 2, false);
        if (Character.isDigit(n)) {
            if (i + 2 < w.length() && Character.isDigit(w.charAt(i + 2))) {
                return new Expansion(w.substring(i), w.length(), false);
            }
            return new Expansion("$" + n, i + 2, false);
        }
        if (n == '_' || Character.isLetter(n)) {
            int j = i + 2;
            while (j < w.length()) {
                char c = w.charAt(j);
                if (!(c == '_' || Character.isLetterOrDigit(c))) break;
                j++;
            }
            return new Expansion(w.substring(i, j), j, false);
        }
        return null;
    }

    private static boolean isIdentifierTail(char c) {
        return c == '_' || Character.isLetterOrDigit(c);
    }

    private static int findMatching(String s, int openPos, char open, char close) {
        int depth = 0;
        for (int i = openPos; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == open) depth++;
            else if (c == close) {
                depth--;
                if (depth == 0) return i;
            }
        }
        return -1;
    }

    private static String suggest(String input) {
        String t = transform(input);
        if (input.equals(t)) return input;
        StringBuilder out = new StringBuilder();
        String[] a = input.split("(?<=\\n)", -1);
        String[] b = t.split("(?<=\\n)", -1);
        int n = Math.max(a.length, b.length);
        for (int i = 0; i < n; i++) {
            String x = i < a.length ? a[i] : "";
            String y = i < b.length ? b[i] : "";
            out.append(colorInsertions(x, y));
        }
        return out.toString();
    }

    private static String syntaxSuggest(String input) {
        return syntax(suggest(input));
    }

    private static String colorInsertions(String oldLine, String newLine) {
        if (oldLine.equals(newLine)) return newLine;
        StringBuilder out = new StringBuilder();
        int i = 0, j = 0;
        while (j < newLine.length()) {
            if (i < oldLine.length() && oldLine.charAt(i) == newLine.charAt(j)) {
                out.append(newLine.charAt(j)); i++; j++;
            } else {
                int k = j + 1;
                while (k <= newLine.length()) {
                    String rest = newLine.substring(k);
                    if (i <= oldLine.length() && oldLine.substring(i).startsWith(rest.isEmpty() ? "" : rest.substring(0, Math.min(rest.length(), 1)))) break;
                    if (k == newLine.length()) break;
                    k++;
                }
                out.append(GREEN).append(newLine, j, k).append(RESET);
                j = k;
            }
        }
        return out.toString();
    }

    private static String syntax(String input) {
        StringBuilder out = new StringBuilder();
        boolean atCmd = true;
        for (int i = 0; i < input.length(); ) {
            char c = input.charAt(i);
            if (c == '\n') { out.append(c); i++; atCmd = true; continue; }
            if (Character.isWhitespace(c)) { out.append(c); i++; continue; }
            if (c == ';' || c == '|' || c == '&') { out.append(c); i++; atCmd = true; continue; }
            if (c == '"' || c == '\'') {
                int j = i + 1;
                while (j < input.length() && input.charAt(j) != c) j++;
                if (j < input.length()) j++;
                out.append(STR).append(input, i, j).append(RESET);
                i = j; atCmd = false; continue;
            }
            if (c == '$') {
                Expansion e = parseDollar(input, i);
                if (e != null) {
                    out.append(VAR).append(e.text).append(RESET);
                    i = e.end; atCmd = false; continue;
                }
            }
            if (Character.isLetter(c) || c == '_' || c == '[') {
                int j = i + 1;
                while (j < input.length()) {
                    char d = input.charAt(j);
                    if (!(Character.isLetterOrDigit(d) || d == '_' || d == '[' || d == ']')) break;
                    j++;
                }
                String w = input.substring(i, j);
                if (w.equals("if") || w.equals("then") || w.equals("fi") || w.equals("for") || w.equals("do") || w.equals("done") || w.equals("case") || w.equals("in") || w.equals("esac")) {
                    out.append(KW).append(w).append(RESET);
                } else if (atCmd) {
                    out.append(CMD).append(w).append(RESET);
                } else {
                    out.append(w);
                }
                i = j; atCmd = false; continue;
            }
            out.append(c); i++; atCmd = false;
        }
        return out.toString();
    }
}
