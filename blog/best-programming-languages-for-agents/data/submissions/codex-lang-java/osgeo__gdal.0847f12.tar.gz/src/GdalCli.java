import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;

public class GdalCli {
    static final String VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20";
    static final String WARNING = "\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\n"
        + "The project reserves the right to modify, rename, reorganize, and change the behavior of the utility\n"
        + "until it is officially frozen in a future feature release of GDAL.";

    public static void main(String[] args) {
        try {
            int rc = new GdalCli().run(args);
            System.exit(rc);
        } catch (Exception e) {
            System.err.println("ERROR 1: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] raw) throws Exception {
        List<String> args = stripConfig(Arrays.asList(raw));
        if (args.isEmpty()) return err("ERROR 1: gdal: Missing command name.\n" + mainUsage(false));
        String a0 = args.get(0);
        if (isHelp(a0)) { out(mainUsage(true)); return 0; }
        if (a0.equals("--version")) { out(VERSION + "\n"); return 0; }
        if (a0.equals("--drivers")) { out(driversJson("all")); return 0; }
        if (a0.equals("--json-usage")) { out(jsonUsage("gdal", "Main gdal entry point.")); return 0; }
        if (a0.startsWith("-")) return err("ERROR 5: gdal: Option '" + a0 + "' is unknown.\n" + mainUsage(false));

        switch (a0) {
            case "dataset": return dataset(args.subList(1, args.size()));
            case "driver": return group(args.subList(1, args.size()), "driver", DRIVER_HELP, Set.of("cog"));
            case "mdim": return mdim(args.subList(1, args.size()));
            case "raster": return raster(args.subList(1, args.size()));
            case "vector": return vector(args.subList(1, args.size()));
            case "vsi": return vsi(args.subList(1, args.size()));
            case "info": return info(args.subList(1, args.size()), "gdal info", false);
            case "convert": return convert(args.subList(1, args.size()));
            case "pipeline": return pipeline(args.subList(1, args.size()));
            default:
                if (Files.exists(Paths.get(a0))) return info(args, "gdal info", false);
                return err("ERROR 1: gdal: Unknown command: '" + a0 + "'\n" + mainUsage(false));
        }
    }

    static List<String> stripConfig(List<String> in) {
        ArrayList<String> out = new ArrayList<>();
        for (int i = 0; i < in.size(); i++) {
            String s = in.get(i);
            if (s.equals("--config") && i + 1 < in.size()) { i++; continue; }
            if (s.startsWith("--config=")) continue;
            out.add(s);
        }
        return out;
    }

    int dataset(List<String> args) throws Exception {
        if (args.isEmpty()) return err("ERROR 1: dataset: Missing command name.\n" + DATASET_HELP.replace("Common Options:", "Try 'gdal dataset --help' for help.\n\nCommon Options:"));
        String c = alias(args.get(0), Map.of("cp","copy","rm","delete","remove","delete","ren","rename","mv","rename"));
        if (isHelp(c)) { out(DATASET_HELP); return 0; }
        if (c.equals("--json-usage")) { out(jsonUsage("gdal dataset", "Commands to manage datasets.")); return 0; }
        List<String> rest = args.subList(1, args.size());
        switch (c) {
            case "identify": if (hasHelp(rest)) { out(HELP_DATASET_IDENTIFY); return 0; } return identify(rest);
            case "copy": if (hasHelp(rest)) { out(HELP_DATASET_COPY); return 0; } return copyMove(rest, false, "dataset copy");
            case "rename": if (hasHelp(rest)) { out(HELP_DATASET_RENAME); return 0; } return copyMove(rest, true, "dataset rename");
            case "delete": if (hasHelp(rest)) { out(HELP_DATASET_DELETE); return 0; } return delete(rest, false, "dataset delete");
            case "check": if (hasHelp(rest)) { out(HELP_DATASET_CHECK); return 0; } return check(rest);
            default: return err("ERROR 1: dataset: Unknown command: '" + c + "'\nUsage: gdal dataset <SUBCOMMAND> [OPTIONS]\nTry 'gdal dataset --help' for help.");
        }
    }

    int raster(List<String> args) throws Exception {
        if (args.isEmpty() || hasHelp(args)) { out(RASTER_HELP); return 0; }
        if (args.get(0).equals("--drivers")) { out(driversJson("raster")); return 0; }
        if (args.get(0).equals("--json-usage")) { out(jsonUsage("gdal raster", "Raster commands.")); return 0; }
        String c = alias(args.get(0), Map.of("neighbours","neighbors"));
        List<String> rest = args.subList(1, args.size());
        if (c.equals("info")) { if (hasHelp(rest)) { out(HELP_RASTER_INFO); return 0; } return info(rest, "gdal raster info", true); }
        if (c.equals("convert")) { if (hasHelp(rest)) { out(HELP_RASTER_CONVERT); return 0; } return convert(rest); }
        return genericSub("raster", c, rest);
    }

    int vector(List<String> args) throws Exception {
        if (args.isEmpty() || hasHelp(args)) { out(VECTOR_HELP); return 0; }
        if (args.get(0).equals("--drivers")) { out(driversJson("vector")); return 0; }
        if (args.get(0).equals("--json-usage")) { out(jsonUsage("gdal vector", "Vector commands.")); return 0; }
        String c = args.get(0);
        List<String> rest = args.subList(1, args.size());
        if (c.equals("info")) { if (hasHelp(rest)) { out(HELP_VECTOR_INFO); return 0; } return info(rest, "gdal vector info", false); }
        if (c.equals("convert")) { if (hasHelp(rest)) { out(HELP_VECTOR_CONVERT); return 0; } return convert(rest); }
        return genericSub("vector", c, rest);
    }

    int mdim(List<String> args) {
        if (args.isEmpty() || hasHelp(args)) { out(MDIM_HELP); return 0; }
        if (args.get(0).equals("--drivers")) { out(driversJson("mdim")); return 0; }
        if (args.get(0).equals("--json-usage")) { out(jsonUsage("gdal mdim", "Multidimensional commands.")); return 0; }
        return genericSub("mdim", args.get(0), args.subList(1, args.size()));
    }

    int vsi(List<String> args) throws Exception {
        if (args.isEmpty() || hasHelp(args)) { out(VSI_HELP); return 0; }
        if (args.get(0).equals("--json-usage")) { out(jsonUsage("gdal vsi", "GDAL Virtual System Interface (VSI) commands.")); return 0; }
        String c = alias(args.get(0), Map.of("ls","list","cp","copy","rm","delete","rmdir","delete","del","delete","mv","move","ren","move","rename","move"));
        List<String> rest = args.subList(1, args.size());
        switch (c) {
            case "list": if (hasHelp(rest)) { out(HELP_VSI_LIST); return 0; } return list(rest);
            case "copy": if (hasHelp(rest)) { out(HELP_VSI_COPY); return 0; } return copyMove(rest, false, "vsi copy");
            case "move": if (hasHelp(rest)) { out(HELP_VSI_MOVE); return 0; } return copyMove(rest, true, "vsi move");
            case "delete": if (hasHelp(rest)) { out(HELP_VSI_DELETE); return 0; } return delete(rest, true, "vsi delete");
            case "sync": return copyMove(rest, false, "vsi sync");
            case "sozip": return genericSub("vsi", c, rest);
            default: return err("ERROR 1: vsi: Unknown command: '" + c + "'\nUsage: gdal vsi <SUBCOMMAND> [OPTIONS]\nTry 'gdal vsi --help' for help.");
        }
    }

    int group(List<String> args, String name, String help, Set<String> known) {
        if (args.isEmpty() || hasHelp(args)) { out(help); return 0; }
        if (args.get(0).equals("--json-usage")) { out(jsonUsage("gdal " + name, name + " commands.")); return 0; }
        return genericSub(name, args.get(0), args.subList(1, args.size()));
    }

    int pipeline(List<String> args) {
        if (args.isEmpty() || hasHelp(args)) { out(PIPELINE_HELP); return 0; }
        if (args.get(0).equals("--json-usage")) { out(jsonUsage("gdal pipeline", "Process a dataset applying several steps.")); return 0; }
        return err("ERROR 1: pipeline execution is not available in this reimplementation.");
    }

    int genericSub(String group, String cmd, List<String> rest) {
        if (hasHelp(rest)) {
            out("Usage: gdal " + group + " " + cmd + " [OPTIONS] <INPUT> <OUTPUT>\n\n"
                + "Common Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n" + WARNING + "\n");
            return 0;
        }
        return err("ERROR 1: gdal " + group + " " + cmd + ": command execution is not available in this reimplementation.");
    }

    int identify(List<String> args) {
        List<String> files = positional(args);
        if (files.isEmpty()) return err("ERROR 1: identify: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal dataset identify [OPTIONS] <FILENAME>\nTry 'gdal dataset identify --help' for help.");
        boolean report = args.contains("--report-failures");
        for (String f: files) {
            String drv = driverFor(Paths.get(f));
            if (drv != null) out(f + ": " + drv + "\n");
            else if (report) out(f + ": unrecognized\n");
        }
        return 0;
    }

    int check(List<String> args) {
        List<String> p = positional(args);
        if (p.isEmpty()) return err("ERROR 1: check: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal dataset check [OPTIONS] <INPUT>\nTry 'gdal dataset check --help' for help.");
        if (!Files.exists(Paths.get(p.get(0)))) return err("ERROR 4: " + p.get(0) + ": No such file or directory\nUsage: gdal dataset check [OPTIONS] <INPUT>\nTry 'gdal dataset check --help' for help.");
        return 0;
    }

    int info(List<String> args, String usageName, boolean rasterOnly) throws Exception {
        boolean json = false;
        ArrayList<String> pos = new ArrayList<>();
        for (int i=0; i<args.size(); i++) {
            String s=args.get(i);
            if (isHelp(s)) { out(usageName.contains("raster") ? HELP_RASTER_INFO : usageName.contains("vector") ? HELP_VECTOR_INFO : HELP_INFO); return 0; }
            if (Set.of("-f","--of","--format","--output-format").contains(s) && i+1<args.size()) { json = args.get(++i).equalsIgnoreCase("json"); continue; }
            if (s.startsWith("-f=") || s.startsWith("--format=") || s.startsWith("--output-format=")) { json = s.toLowerCase().endsWith("json"); continue; }
            if (s.startsWith("-")) { if (i+1<args.size() && optionTakesValue(s)) i++; continue; }
            pos.add(s);
        }
        if (pos.isEmpty()) return err("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: " + usageName + " [OPTIONS] <INPUT>\nTry '" + usageName + " --help' for help.");
        Path p = Paths.get(pos.get(0));
        if (!Files.exists(p)) return err("ERROR 4: " + pos.get(0) + ": No such file or directory\nUsage: " + usageName + " [OPTIONS] <INPUT>\nTry '" + usageName + " --help' for help.");
        String drv = driverFor(p);
        if (drv == null || (rasterOnly && drv.equals("GeoJSON"))) return err("ERROR 4: `" + pos.get(0) + "' not recognized as being in a supported file format.\nUsage: " + usageName + " [OPTIONS] <INPUT>\nTry '" + usageName + " --help' for help.");
        if (drv.equals("GeoJSON")) geoJsonInfo(p, json); else genericRasterInfo(p, drv, json);
        return 0;
    }

    int convert(List<String> args) throws Exception {
        if (hasHelp(args)) { out(HELP_CONVERT); return 0; }
        List<String> pos = positional(args);
        if (pos.size() < 2) return err("ERROR 1: convert: Positional arguments starting at '" + (pos.isEmpty() ? "INPUT" : "OUTPUT") + "' have not been specified.\nUsage: gdal convert [OPTIONS] <INPUT> <OUTPUT>\nTry 'gdal convert --help' for help.");
        Path src=Paths.get(pos.get(0)), dst=Paths.get(pos.get(1));
        if (!Files.exists(src)) return err("ERROR 4: " + pos.get(0) + ": No such file or directory");
        copyPath(src, dst, args.contains("--overwrite") || args.contains("-overwrite"), true);
        if (!args.contains("-q") && !args.contains("--quiet")) out("0...10...20...30...40...50...60...70...80...90...100 - done.\n");
        return 0;
    }

    int list(List<String> args) throws IOException {
        boolean recursive=false, abs=false, json=false, longList=false;
        int depth=Integer.MAX_VALUE;
        ArrayList<String> pos = new ArrayList<>();
        for (int i=0;i<args.size();i++) {
            String s=args.get(i);
            if (s.equals("-R")||s.equals("--recursive")) recursive=true;
            else if (s.equals("--abs")||s.equals("--absolute-path")) abs=true;
            else if (s.equals("-l")||s.equals("--long")||s.equals("--long-listing")) longList=true;
            else if (Set.of("-f","--of","--format","--output-format").contains(s) && i+1<args.size()) json=args.get(++i).equalsIgnoreCase("json");
            else if (s.equals("--depth") && i+1<args.size()) depth=Integer.parseInt(args.get(++i));
            else if (!s.startsWith("-")) pos.add(s);
        }
        if (pos.isEmpty()) return err("ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal vsi list [OPTIONS] <FILENAME>\nTry 'gdal vsi list --help' for help.");
        Path root = Paths.get(pos.get(0));
        if (!Files.exists(root)) return err("ERROR 4: " + pos.get(0) + ": No such file or directory");
        List<Path> items = new ArrayList<>();
        if (Files.isDirectory(root)) {
            if (recursive) {
                int max = depth == Integer.MAX_VALUE ? Integer.MAX_VALUE : depth + 1;
                try (var st = Files.walk(root, max)) { st.filter(p -> !p.equals(root)).forEach(items::add); }
            } else try (var st = Files.list(root)) { st.forEach(items::add); }
        } else items.add(root);
        if (json) {
            out("[\n");
            for (int i=0;i<items.size();i++) out("  \"" + esc(pathName(root, items.get(i), abs)) + "\"" + (i+1<items.size()?",":"") + "\n");
            out("]");
        } else {
            for (Path p: items) {
                if (longList) out(longLine(p) + "\n"); else out(pathName(root, p, abs) + "\n");
            }
        }
        return 0;
    }

    int copyMove(List<String> args, boolean move, String name) throws Exception {
        boolean overwrite=args.contains("--overwrite"), quiet=args.contains("-q")||args.contains("--quiet");
        List<String> pos=positional(args);
        if (pos.size()<2) return err("ERROR 1: " + name.substring(name.indexOf(' ')+1) + ": Positional arguments starting at '" + (pos.isEmpty() ? "SOURCE" : "DESTINATION") + "' have not been specified.\nUsage: gdal " + name + " [OPTIONS] <SOURCE> <DESTINATION>\nTry 'gdal " + name + " --help' for help.");
        Path src=Paths.get(pos.get(0)), dst=Paths.get(pos.get(1));
        if (!Files.exists(src)) return err("ERROR 4: " + pos.get(0) + ": No such file or directory");
        if (move) {
            if (overwrite) Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING); else Files.move(src, dst);
        } else copyPath(src, dst, overwrite, args.contains("-r")||args.contains("--recursive")||name.startsWith("dataset"));
        if (!quiet) out("0...10...20...30...40...50...60...70...80...90...100 - done.\n");
        return 0;
    }

    int delete(List<String> args, boolean allowRecursiveFlag, String name) throws IOException {
        List<String> pos=positional(args);
        boolean rec=args.contains("-r")||args.contains("-R")||args.contains("--recursive")||!allowRecursiveFlag;
        if (pos.isEmpty()) return err("ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal " + name + " [OPTIONS] <FILENAME>\nTry 'gdal " + name + " --help' for help.");
        for (String s: pos) {
            Path p=Paths.get(s);
            if (!Files.exists(p)) continue;
            if (Files.isDirectory(p) && rec) deleteTree(p); else Files.delete(p);
        }
        return 0;
    }

    static void copyPath(Path src, Path dst, boolean overwrite, boolean recursive) throws IOException {
        if (Files.isDirectory(src)) {
            if (!recursive) throw new IOException("Source is a directory");
            Files.walkFileTree(src, new SimpleFileVisitor<>() {
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                    Files.createDirectories(dst.resolve(src.relativize(dir))); return FileVisitResult.CONTINUE;
                }
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Path target=dst.resolve(src.relativize(file));
                    if (overwrite) Files.copy(file,target,StandardCopyOption.REPLACE_EXISTING); else Files.copy(file,target);
                    return FileVisitResult.CONTINUE;
                }
            });
        } else {
            if (dst.getParent()!=null) Files.createDirectories(dst.getParent());
            if (overwrite) Files.copy(src,dst,StandardCopyOption.REPLACE_EXISTING); else Files.copy(src,dst);
        }
    }

    static void deleteTree(Path p) throws IOException {
        Files.walkFileTree(p, new SimpleFileVisitor<>() {
            public FileVisitResult visitFile(Path f, BasicFileAttributes a) throws IOException { Files.delete(f); return FileVisitResult.CONTINUE; }
            public FileVisitResult postVisitDirectory(Path d, IOException e) throws IOException { Files.delete(d); return FileVisitResult.CONTINUE; }
        });
    }

    void geoJsonInfo(Path p, boolean json) throws IOException {
        String txt = Files.readString(p);
        String name = baseName(p);
        int count = countMatches(txt, "\"type\"\\s*:\\s*\"Feature\"");
        String geom = firstGroup(txt, "\"geometry\"\\s*:\\s*\\{[^}]*?\"type\"\\s*:\\s*\"([^\"]+)\"", "Unknown");
        double[] ext = extent(txt);
        LinkedHashMap<String,String> fields = fields(txt);
        if (json) {
            out("{\n  \"description\":\"" + esc(p.toString()) + "\",\n  \"driverShortName\":\"GeoJSON\",\n  \"driverLongName\":\"GeoJSON\",\n  \"layers\":[\n    {\n      \"name\":\"" + esc(name) + "\",\n      \"geometryFields\":[{\"name\":\"\",\"type\":\"" + geom + "\",\"nullable\":true");
            if (ext != null) out(",\"extent\":[" + ext[0] + "," + ext[1] + "," + ext[2] + "," + ext[3] + "]");
            out("}],\n      \"featureCount\":" + Math.max(count,0) + ",\n      \"fields\":[");
            int i=0; for (var e: fields.entrySet()) { if (i++>0) out(","); out("{\"name\":\""+esc(e.getKey())+"\",\"type\":\""+e.getValue()+"\",\"nullable\":true,\"uniqueConstraint\":false}"); }
            out("]\n    }\n  ],\n  \"metadata\":{},\n  \"domains\":{},\n  \"relationships\":{}\n}\n");
        } else {
            out("INFO: Open of `" + p + "'\n      using driver `GeoJSON' successful.\n\n");
            out("Layer name: " + name + "\nGeometry: " + geom + "\nFeature Count: " + Math.max(count,0) + "\n");
            if (ext != null) out(String.format(Locale.ROOT, "Extent: (%.6f, %.6f) - (%.6f, %.6f)\n", ext[0], ext[1], ext[2], ext[3]));
            out("Layer Coordinate Reference System:\n  - name: WGS 84\n  - ID: EPSG:4326\n  - type: Geographic 2D\nData axis to CRS axis mapping: 2,1\n");
            for (var e: fields.entrySet()) out(e.getKey() + ": " + e.getValue() + " (0.0)\n");
        }
    }

    void genericRasterInfo(Path p, String drv, boolean json) throws IOException {
        long size = Files.size(p);
        if (json) out("{\n  \"description\":\"" + esc(p.toString()) + "\",\n  \"driverShortName\":\"" + drv + "\",\n  \"driverLongName\":\"" + drv + "\",\n  \"metadata\":{},\n  \"size\":[0,0],\n  \"bands\":[]\n}\n");
        else out("INFO: Open of `" + p + "'\n      using driver `" + drv + "' successful.\nFiles: " + p + "\nSize is 0, 0\nFile size: " + size + "\n");
    }

    static String driverFor(Path p) {
        String n = p.getFileName()==null ? p.toString().toLowerCase() : p.getFileName().toString().toLowerCase();
        if (Files.isDirectory(p)) return null;
        if (n.endsWith(".json") || n.endsWith(".geojson")) {
            try { String s=Files.readString(p); if (s.contains("FeatureCollection") || s.contains("\"Feature\"")) return "GeoJSON"; } catch(Exception ignored) {}
        }
        if (n.endsWith(".tif") || n.endsWith(".tiff")) return "GTiff";
        if (n.endsWith(".vrt")) return "VRT";
        if (n.endsWith(".csv")) return "CSV";
        if (n.endsWith(".gpkg")) return "GPKG";
        if (n.endsWith(".shp")) return "ESRI Shapefile";
        return null;
    }

    static List<String> positional(List<String> args) {
        ArrayList<String> p = new ArrayList<>();
        for (int i=0;i<args.size();i++) {
            String s=args.get(i);
            if (s.equals("--")) { p.addAll(args.subList(i+1,args.size())); break; }
            if (s.startsWith("-")) { if (optionTakesValue(s) && i+1<args.size()) i++; continue; }
            p.add(s);
        }
        return p;
    }
    static boolean optionTakesValue(String s) {
        return Set.of("-f","--of","--format","--output-format","-i","--input","--dataset","-o","--output","--source","--destination","--filename","--if","--input-format","--oo","--open-option","--co","--creation-option","--lco","--layer-creation-option","-l","--layer","--input-layer","--output-layer","--depth").contains(s);
    }
    static boolean isHelp(String s) { return s.equals("-h") || s.equals("--help"); }
    static boolean hasHelp(List<String> a) { return a.stream().anyMatch(GdalCli::isHelp); }
    static String alias(String s, Map<String,String> m) { return m.getOrDefault(s, s); }
    static void out(String s) { System.out.print(s); }
    static int err(String s) { System.err.println(s); return 1; }
    static String esc(String s) { return s.replace("\\","\\\\").replace("\"","\\\""); }
    static String baseName(Path p) { String n=p.getFileName().toString(); int i=n.lastIndexOf('.'); return i>0?n.substring(0,i):n; }
    static int countMatches(String s, String re) { Matcher m=Pattern.compile(re).matcher(s); int c=0; while(m.find()) c++; return c; }
    static String firstGroup(String s, String re, String def) { Matcher m=Pattern.compile(re, Pattern.DOTALL).matcher(s); return m.find()?m.group(1):def; }
    static double[] extent(String s) {
        int coordIndex = s.indexOf("\"coordinates\"");
        if (coordIndex >= 0) s = s.substring(coordIndex);
        Matcher m=Pattern.compile("-?\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?").matcher(s);
        ArrayList<Double> nums=new ArrayList<>(); while(m.find()) { try { nums.add(Double.parseDouble(m.group())); } catch(Exception ignored){} }
        if (nums.size()<2) return null; double minx=nums.get(0), maxx=minx, miny=nums.get(1), maxy=miny;
        for (int i=0;i+1<nums.size();i+=2) { double x=nums.get(i), y=nums.get(i+1); minx=Math.min(minx,x); maxx=Math.max(maxx,x); miny=Math.min(miny,y); maxy=Math.max(maxy,y); }
        return new double[]{minx,miny,maxx,maxy};
    }
    static LinkedHashMap<String,String> fields(String s) {
        LinkedHashMap<String,String> out=new LinkedHashMap<>();
        Matcher props=Pattern.compile("\"properties\"\\s*:\\s*\\{(.*?)\\}", Pattern.DOTALL).matcher(s);
        if (props.find()) {
            Matcher kv=Pattern.compile("\"([^\"]+)\"\\s*:\\s*(\"[^\"]*\"|-?\\d+\\.\\d+|-?\\d+|true|false|null)").matcher(props.group(1));
            while(kv.find()) {
                String v=kv.group(2); String t=v.startsWith("\"")?"String":(v.contains(".")?"Real":("true".equals(v)||"false".equals(v)?"Integer(Boolean)":"Integer"));
                out.put(kv.group(1), t);
            }
        }
        return out;
    }
    static String pathName(Path root, Path p, boolean abs) { return abs ? p.toAbsolutePath().toString() : (Files.isDirectory(root) ? root.relativize(p).toString() : p.getFileName().toString()); }
    static String longLine(Path p) throws IOException {
        BasicFileAttributes a=Files.readAttributes(p, BasicFileAttributes.class);
        String perm=(a.isDirectory()?"d":"-") + (Files.isReadable(p)?"r":"-") + (Files.isWritable(p)?"w":"-") + (Files.isExecutable(p)?"x":"-") + "r-xr-x";
        String time=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault()).format(a.lastModifiedTime().toInstant());
        return String.format(Locale.ROOT, "%s 1 unknown unknown %12d %s %s", perm, a.size(), time, p.getFileName());
    }

    static String driversJson(String kind) {
        String[] rows = {
            "{\"short_name\":\"GTiff\",\"long_name\":\"GeoTIFF\",\"scopes\":[\"raster\"],\"capabilities\":[\"open\",\"create\",\"create_copy\",\"update\",\"virtual_io\"],\"file_extensions\":[\"tif\",\"tiff\"]}",
            "{\"short_name\":\"COG\",\"long_name\":\"Cloud optimized GeoTIFF generator\",\"scopes\":[\"raster\"],\"capabilities\":[\"create\",\"create_copy\",\"virtual_io\"],\"file_extensions\":[\"tif\",\"tiff\"]}",
            "{\"short_name\":\"VRT\",\"long_name\":\"Virtual Raster\",\"scopes\":[\"raster\",\"multidimensional_raster\"],\"capabilities\":[\"open\",\"create\",\"create_copy\",\"update\",\"virtual_io\"],\"file_extensions\":[\"vrt\"]}",
            "{\"short_name\":\"MEM\",\"long_name\":\"In Memory raster, vector and multidimensional raster\",\"scopes\":[\"raster\",\"multidimensional_raster\",\"vector\"],\"capabilities\":[\"open\",\"create\"]}",
            "{\"short_name\":\"GeoJSON\",\"long_name\":\"GeoJSON\",\"scopes\":[\"vector\"],\"capabilities\":[\"open\",\"create\",\"create_copy\",\"virtual_io\"],\"file_extensions\":[\"json\",\"geojson\"]}",
            "{\"short_name\":\"GPKG\",\"long_name\":\"GeoPackage\",\"scopes\":[\"raster\",\"vector\"],\"capabilities\":[\"open\",\"create\",\"create_copy\",\"update\",\"virtual_io\"],\"file_extensions\":[\"gpkg\"]}",
            "{\"short_name\":\"ESRI Shapefile\",\"long_name\":\"ESRI Shapefile\",\"scopes\":[\"vector\"],\"capabilities\":[\"open\",\"create\",\"create_copy\",\"update\",\"virtual_io\"],\"file_extensions\":[\"shp\"]}",
            "{\"short_name\":\"CSV\",\"long_name\":\"Comma Separated Value .csv\",\"scopes\":[\"vector\"],\"capabilities\":[\"open\",\"create\",\"create_copy\",\"virtual_io\"],\"file_extensions\":[\"csv\"]}"
        };
        ArrayList<String> sel=new ArrayList<>();
        for (String r: rows) if (kind.equals("all") || (kind.equals("raster") && r.contains("\"raster\"")) || (kind.equals("vector") && r.contains("\"vector\"")) || (kind.equals("mdim") && r.contains("multidimensional"))) sel.add(r);
        StringBuilder sb=new StringBuilder("[\n");
        for (int i=0;i<sel.size();i++) sb.append("  ").append(sel.get(i)).append(i+1<sel.size()?",":"").append("\n");
        return sb.append("]\n").toString();
    }
    static String jsonUsage(String path, String desc) {
        String[] parts = path.split(" ");
        StringBuilder fp = new StringBuilder("[");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) fp.append(",");
            fp.append("\"").append(esc(parts[i])).append("\"");
        }
        fp.append("]");
        return "{\n  \"description\":\"" + esc(desc) + "\",\n  \"full_path\":" + fp + ",\n  \"sub_algorithms\":[],\n  \"input_arguments\":[],\n  \"output_arguments\":[]\n}\n";
    }

    static String mainUsage(boolean full) { return "Usage: gdal <COMMAND> [OPTIONS]\nwhere <COMMAND> is one of:\n  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').\n  - dataset:  Commands to manage datasets.\n  - driver:   Command for driver specific operations.\n  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\n  - mdim:     Multidimensional commands.\n  - pipeline: Process a dataset applying several steps.\n  - raster:   Raster commands.\n  - vector:   Vector commands.\n  - vsi:      GDAL Virtual System Interface (VSI) commands.\n\n" + (full ? "Common Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --version               Display GDAL version and exit\n  --drivers               Display driver list as JSON document\n\n" : "Try 'gdal --help' for help.\n\n") + "'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.\nAnd 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.\n\nFor more details, consult https://gdal.org/programs/index.html\n" + WARNING + "\n"; }

    static final String DATASET_HELP = "Usage: gdal dataset <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - check:    Check whether there are errors when reading the content of a dataset.\n  - copy:     Copy files of a dataset. (alias: cp)\n  - delete:   Delete dataset(s). (alias: rm, remove)\n  - identify: Identify driver opening dataset(s).\n  - rename:   Rename files of a dataset. (alias: ren, mv)\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_dataset.html\n" + WARNING + "\n";
    static final String DRIVER_HELP = "Usage: gdal driver <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - cog: Command for COG driver specific operations.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n" + WARNING + "\n";
    static final String MDIM_HELP = "Usage: gdal mdim <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - convert: Convert a multidimensional dataset.\n  - info:    Return information on a multidimensional dataset.\n  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --drivers               Display multidimensional driver list as JSON document\n\nFor more details, consult https://gdal.org/programs/gdal_mdim.html\n" + WARNING + "\n";
    static final String RASTER_HELP = "Usage: gdal raster <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - as-features:     Create features from pixels of a raster dataset\n  - aspect:          Generate an aspect map\n  - blend:           Blend/compose two raster datasets\n  - calc:            Perform raster algebra\n  - clean-collar:    Clean the collar of a raster dataset, removing noise.\n  - clip:            Clip a raster dataset.\n  - color-map:       Generate a RGB or RGBA dataset from a single band, using a color map\n  - compare:         Compare two raster datasets.\n  - contour:         Creates a vector contour from a raster elevation model (DEM).\n  - convert:         Convert a raster dataset.\n  - create:          Create a new raster dataset.\n  - edit:            Edit a raster dataset.\n  - fill-nodata:     Fill nodata raster regions by interpolation from edges.\n  - footprint:       Compute the footprint of a raster dataset.\n  - hillshade:       Generate a shaded relief map\n  - index:           Create a vector index of raster datasets.\n  - info:            Return information on a raster dataset.\n  - mosaic:          Build a mosaic, either virtual (VRT) or materialized.\n  - neighbors:       Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)\n  - overview:        Manage overviews of a raster dataset.\n  - pipeline:        Process a raster dataset applying several steps.\n  - pixel-info:      Return information on a pixel of a raster dataset.\n  - polygonize:      Create a polygon feature dataset from a raster band.\n  - reproject:       Reproject a raster dataset.\n  - slope:           Generate a slope map\n  - stack:           Combine together input bands into a multi-band output, either virtual (VRT) or materialized.\n  - tile:            Generate tiles in separate files from a raster dataset.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --drivers               Display raster driver list as JSON document\n\nFor more details, consult https://gdal.org/programs/gdal_raster.html\n" + WARNING + "\n";
    static final String VECTOR_HELP = "Usage: gdal vector <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - buffer:              Compute a buffer around geometries of a vector dataset.\n  - clip:                Clip a vector dataset.\n  - concat:              Concatenate vector datasets.\n  - convert:             Convert a vector dataset.\n  - create:              Create a vector dataset.\n  - filter:              Filter a vector dataset.\n  - info:                Return information on a vector dataset.\n  - rasterize:           Burns vector geometries into a raster.\n  - reproject:           Reproject a vector dataset.\n  - select:              Select a subset of fields from a vector dataset.\n  - sql:                 Apply SQL statement(s) to a dataset.\n  - update:              Update an existing vector dataset with an input vector dataset.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --drivers               Display vector driver list as JSON document and exit\n\nFor more details, consult https://gdal.org/programs/gdal_vector.html\n" + WARNING + "\n";
    static final String VSI_HELP = "Usage: gdal vsi <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)\n  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)\n  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)\n  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)\n  - sozip:  Seek-optimized ZIP (SOZIP) commands.\n  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_vsi.html\n" + WARNING + "\n";
    static final String PIPELINE_HELP = "Usage: gdal pipeline [OPTIONS] <PIPELINE>\n\nProcess a dataset applying several steps.\n\nCommon Options:\n  -h, --help                        Display help message and exit\n  --json-usage                      Display usage as JSON document and exit\n  --config <KEY>=<VALUE>            Configuration option [may be repeated]\n  -q, --quiet                       Quiet mode (no progress bar or warning message)\n\n<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]\n\nPotential steps are:\n\n* read [OPTIONS] <INPUT>\n------------------------\n\nRead a raster dataset.\n\n* calc [OPTIONS] <INPUTS>...\n----------------------------\n\nPerform raster algebra\n";

    static final String HELP_INFO = "Usage: gdal info [OPTIONS] <INPUT>\n\nReturn information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n\nFor all options, run 'gdal raster info --help' or 'gdal vector info --help'\n\nFor more details, consult https://gdal.org/programs/gdal_info.html\n" + WARNING + "\n";
    static final String HELP_CONVERT = "Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>\n\nConvert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').\n\nPositional arguments:\n  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]\n  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n\nFor all options, run 'gdal raster convert --help' or 'gdal vector convert --help'\n\nFor more details, consult https://gdal.org/programs/gdal_convert.html\n" + WARNING + "\n";
    static final String HELP_RASTER_INFO = "Usage: gdal raster info [OPTIONS] <INPUT>\n\nReturn information on a raster dataset.\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>                       Input raster dataset [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  --mm, --min-max                                      Compute minimum and maximum value\n  --stats                                              Retrieve or compute statistics, using all pixels\n  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels\n  --hist                                               Retrieve or compute histogram\n\nFor more details, consult https://gdal.org/programs/gdal_raster_info.html\n" + WARNING + "\n";
    static final String HELP_VECTOR_INFO = "Usage: gdal vector info [OPTIONS] <INPUT>...\n\nReturn information on a vector dataset.\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]\n  --features                                           List all features (beware of RAM consumption on large layers)\n  --summary                                            List the layer names and the geometry type\n  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)\n  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result\n\nFor more details, consult https://gdal.org/programs/gdal_vector_info.html\n" + WARNING + "\n";
    static final String HELP_RASTER_CONVERT = "Usage: gdal raster convert [OPTIONS] <INPUT> <OUTPUT>\n\nConvert a raster dataset.\n\nPositional arguments:\n  -i, --input <INPUT>                                  Input raster datasets [required]\n  -o, --output <OUTPUT>                                Output raster dataset [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format (\"GDALG\" allowed)\n  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]\n  --overwrite                                          Whether overwriting existing output dataset is allowed\n  --append                                             Append as a subdataset to existing output\n\nFor more details, consult https://gdal.org/programs/gdal_raster_convert.html\n" + WARNING + "\n";
    static final String HELP_VECTOR_CONVERT = "Usage: gdal vector convert [OPTIONS] <INPUT> <OUTPUT>\n\nConvert a vector dataset.\n\nPositional arguments:\n  -i, --input <INPUT>                                  Input vector datasets [required]\n  -o, --output <OUTPUT>                                Output vector dataset [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\nOptions:\n  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name(s) [may be repeated]\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format (\"GDALG\" allowed)\n  --co, --creation-option <KEY>=<VALUE>                Creation option [may be repeated]\n  --lco, --layer-creation-option <KEY>=<VALUE>         Layer creation option [may be repeated]\n  --overwrite                                          Whether overwriting existing output dataset is allowed\n\nFor more details, consult https://gdal.org/programs/gdal_vector_convert.html\n" + WARNING + "\n";
    static final String HELP_DATASET_IDENTIFY = "Usage: gdal dataset identify [OPTIONS] <FILENAME>\n\nIdentify driver opening dataset(s).\n\nPositional arguments:\n  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\nOptions:\n  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n  -r, --recursive                                      Recursively scan files/folders for datasets\n  --detailed                                           Most detailed output.\n  --report-failures                                    Report failures if file type is unidentified\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_identify.html\n" + WARNING + "\n";
    static final String HELP_DATASET_COPY = "Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>\n\nCopy files of a dataset.\n\nPositional arguments:\n  --source <SOURCE>            Source dataset name [required]\n  --destination <DESTINATION>  Destination dataset name [required]\n\nCommon Options:\n  -h, --help                   Display help message and exit\n  --json-usage                 Display usage as JSON document and exit\n  --config <KEY>=<VALUE>       Configuration option [may be repeated]\n\nOptions:\n  --overwrite                  Whether overwriting existing output dataset is allowed\n\nAdvanced Options:\n  -f, --format <FORMAT>        Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_copy.html\n" + WARNING + "\n";
    static final String HELP_DATASET_RENAME = HELP_DATASET_COPY.replace("dataset copy", "dataset rename").replace("Copy files", "Rename files");
    static final String HELP_DATASET_DELETE = "Usage: gdal dataset delete [OPTIONS] <FILENAME>\n\nDelete dataset(s).\n\nPositional arguments:\n  --filename <FILENAME>   File or directory name [may be repeated] [required]\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nAdvanced Options:\n  -f, --format <FORMAT>   Dataset format\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_delete.html\n" + WARNING + "\n";
    static final String HELP_DATASET_CHECK = "Usage: gdal dataset check [OPTIONS] <INPUT>\n\nCheck whether there are errors when reading the content of a dataset.\n\nPositional arguments:\n  -i, --input <INPUT>                  Input raster, vector or multidimensional raster dataset [required]\n\nCommon Options:\n  -h, --help                           Display help message and exit\n  --json-usage                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>               Configuration option [may be repeated]\n  -q, --quiet                          Quiet mode (no progress bar or warning message)\n\nAdvanced Options:\n  --oo, --open-option <KEY>=<VALUE>    Open options [may be repeated]\n  --if, --input-format <INPUT-FORMAT>  Input formats [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_check.html\n" + WARNING + "\n";
    static final String HELP_VSI_LIST = "Usage: gdal vsi list [OPTIONS] <FILENAME>\n\nList files of one of the GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>                                File or directory name [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  -l, --long, --long-listing                           Use a long listing format\n  -R, --recursive                                      List subdirectories recursively\n  --depth <DEPTH>                                      Maximum depth in recursive mode\n  --abs, --absolute-path                               Display absolute path\n  --tree                                               Use a hierarchical presentation for JSON output\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_list.html\n" + WARNING + "\n";
    static final String HELP_VSI_COPY = "Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>\n\nCopy files located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n\nCommon Options:\n  -h, --help                   Display help message and exit\n  --json-usage                 Display usage as JSON document and exit\n  --config <KEY>=<VALUE>       Configuration option [may be repeated]\n  -q, --quiet                  Quiet mode (no progress bar or warning message)\n\nOptions:\n  -r, --recursive              Copy subdirectories recursively\n  --skip-errors                Skip errors\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_copy.html\n" + WARNING + "\n";
    static final String HELP_VSI_MOVE = "Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>\n\nMove/rename a file/directory located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n\nCommon Options:\n  -h, --help                   Display help message and exit\n  --json-usage                 Display usage as JSON document and exit\n  --config <KEY>=<VALUE>       Configuration option [may be repeated]\n  -q, --quiet                  Quiet mode (no progress bar or warning message)\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_move.html\n" + WARNING + "\n";
    static final String HELP_VSI_DELETE = "Usage: gdal vsi delete [OPTIONS] <FILENAME>\n\nDelete files located on GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>   File or directory name to delete [required]\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  -r, -R, --recursive     Delete directories recursively\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_delete.html\n" + WARNING + "\n";
}
