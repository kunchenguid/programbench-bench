import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

public class Crowbook {
    static final String VERSION = "0.17.0";
    static boolean quiet = false;

    static class Opts {
        boolean single, create, list, stats, verbose, autograph;
        String output, to, printTemplate, lang;
        List<String> createFiles = new ArrayList<>();
        List<String> set = new ArrayList<>();
        String book;
    }

    static class Book {
        Map<String,String> meta = new LinkedHashMap<>();
        List<Path> chapters = new ArrayList<>();
        Path base = Paths.get(".");
        Book() {
            meta.put("author", "");
            meta.put("title", "");
            meta.put("lang", "en");
        }
        String get(String k) { return meta.getOrDefault(k, ""); }
    }

    static class Chapter {
        Path path;
        String text;
        String title;
        Chapter(Path p, String t) {
            path = p; text = t; title = firstHeading(t);
        }
    }

    public static void main(String[] args) {
        try {
            Opts o = parse(args);
            if (o == null) System.exit(2);
            if (o.list) { printListOptions(); return; }
            if (o.printTemplate != null) { banner(); System.out.println("ERROR " + o.printTemplate + " is not a valid template name"); return; }
            if (o.create) { banner(); printCreate(o.createFiles); return; }
            if (o.book == null) { banner(); System.out.println("ERROR You must pass the name of a book configuration file.\nFor more information try --help."); return; }
            banner();
            Book b = o.single ? readSingle(Paths.get(o.book)) : readBook(Paths.get(o.book));
            applySet(b, o.set);
            List<Chapter> chapters = readChapters(b);
            if (o.stats) printStats(chapters);
            else render(b, chapters, o);
        } catch (UsageError e) {
            System.err.print(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            banner();
            System.out.println("ERROR " + e.getMessage());
        }
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": case "--help": printHelp(); System.exit(0);
                case "-V": case "--version": System.out.println("crowbook " + VERSION); System.exit(0);
                case "-s": case "--single": o.single = true; break;
                case "-n": case "--no-fancy": case "-f": case "--force-emoji": break;
                case "-v": case "--verbose": o.verbose = true; break;
                case "-a": case "--autograph": o.autograph = true; break;
                case "-q": case "--quiet": quiet = true; break;
                case "-l": case "--list-options": o.list = true; break;
                case "-S": case "--stats": o.stats = true; break;
                case "-o": case "--output": o.output = need(args, ++i, a); break;
                case "-t": case "--to":
                    o.to = need(args, ++i, a);
                    if (!Arrays.asList("epub","pdf","html","tex","odt","html.dir").contains(o.to))
                        throw new UsageError("error: invalid value '" + o.to + "' for '--to <to>'\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'.\n");
                    break;
                case "-L": case "--lang": o.lang = need(args, ++i, a); break;
                case "--print-template": o.printTemplate = need(args, ++i, a); break;
                case "--set":
                    while (i + 1 < args.length && !args[i+1].startsWith("-")) o.set.add(args[++i]);
                    break;
                case "-c": case "--create":
                    o.create = true;
                    while (i + 1 < args.length && !args[i+1].startsWith("-")) o.createFiles.add(args[++i]);
                    break;
                default:
                    if (a.startsWith("-")) throw new UsageError("error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.\n");
                    if (o.book == null) o.book = a; else throw new UsageError("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] [BOOK]\n\nFor more information, try '--help'.\n");
            }
        }
        return o;
    }
    static String need(String[] a, int i, String opt) { if (i >= a.length) throw new UsageError("error: a value is required for '" + opt + "' but none was supplied\n\nFor more information, try '--help'.\n"); return a[i]; }

    static void printHelp() {
        System.out.println("crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>");
        System.out.println("Render a Markdown book in EPUB, PDF or HTML.\n  ");
        System.out.println("USAGE:\n    executable [OPTIONS] [BOOK]\n");
        System.out.println("OPTIONS:");
        String[][] opts = {
            {"  -f, --force-emoji","Force emoji usage even if it might not work on your system"},
            {"  -s, --single","Use a single Markdown file instead of a book configuration file"},
            {"  -n, --no-fancy","Disably fancy UI"},
            {"  -v, --verbose","Print warnings in parsing/rendering"},
            {"  -a, --autograph","Prompts for an autograph for this book"},
            {"  -q, --quiet","Don't print info/error messages"},
            {"  -c, --create <files>...","Create a new book with existing Markdown files"},
            {"  -o, --output <output>","Specify output file"},
            {"  -t, --to <to>","Generate specific format"},
            {"      --set <set> <set>...","Set a list of book options"},
            {"  -l, --list-options","List all possible options"},
            {"  -L, --lang <lang>","Set the runtime language used by Crowbook"},
            {"      --print-template <print-template>","Prints the default content of a template"},
            {"  -S, --stats","Print some project statistics"},
            {"  -h, --help","Print help"},
            {"  -V, --version","Print version"}};
        for (String[] x: opts) System.out.println(x[0] + "\n          " + x[1]);
        System.out.println("\nARGS:\n  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single");
    }
    static void banner() { if (!quiet) System.out.println("CROWBOOK " + VERSION); }

    static void printCreate(List<String> files) {
        System.out.println("\"author: Your name\"\n\"title: Your title\"\n\"lang: en\"\n");
        System.out.println("\"## Output formats\"\n");
        System.out.println("\"# Uncomment and fill to generate files\"");
        System.out.println("\"# output.html: some_file.html\"");
        System.out.println("\"# output.epub: some_file.epub\"");
        System.out.println("\"# output.pdf: some_file.pdf\"\n");
        System.out.println("\"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name\"");
        System.out.println("\"# output: [pdf, epub, html]\"\n");
        System.out.println("\"# Uncomment and fill to set cover image (for EPUB)\"");
        System.out.println("\"# cover: some_cover.png\"\n");
        System.out.println("## List of chapters");
        for (String f: files) System.out.println("+ " + f);
    }

    static Book readSingle(Path p) throws IOException {
        Book b = new Book(); b.base = p.toAbsolutePath().getParent(); if (b.base == null) b.base = Paths.get(".");
        String text = Files.readString(p, StandardCharsets.UTF_8);
        if (text.startsWith("---\n")) {
            int end = text.indexOf("\n---", 4);
            if (end > 0) {
                for (String line: text.substring(4, end).split("\\R")) parseMetaLine(b, line);
                text = text.substring(text.indexOf('\n', end + 1) + 1);
                Path tmp = Files.createTempFile("crowbook-single", ".md");
                Files.writeString(tmp, text, StandardCharsets.UTF_8);
                b.chapters.add(tmp);
                return b;
            }
        }
        b.chapters.add(p);
        return b;
    }
    static Book readBook(Path p) throws IOException {
        Book b = new Book();
        b.base = p.toAbsolutePath().getParent(); if (b.base == null) b.base = Paths.get(".");
        int lineNo = 0;
        for (String raw: Files.readAllLines(p, StandardCharsets.UTF_8)) {
            lineNo++;
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            if (line.startsWith("+") || line.startsWith("-")) {
                String name = line.substring(1).trim();
                Path cp = b.base.resolve(name).normalize();
                if (!Files.exists(cp)) throw new IOException(p + ":" + lineNo + ": Could not find file '" + name + "' for book chapter");
                b.chapters.add(cp);
            } else parseMetaLine(b, line);
        }
        return b;
    }
    static void parseMetaLine(Book b, String line) {
        int idx = line.indexOf(':');
        if (idx > 0) b.meta.put(line.substring(0, idx).trim(), unquote(line.substring(idx+1).trim()));
    }
    static String unquote(String s) {
        if ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'"))) return s.substring(1, s.length()-1);
        return s;
    }
    static void applySet(Book b, List<String> set) {
        for (int i = 0; i + 1 < set.size(); i += 2) b.meta.put(set.get(i), set.get(i+1));
    }
    static List<Chapter> readChapters(Book b) throws IOException {
        List<Chapter> list = new ArrayList<>();
        for (Path p: b.chapters) list.add(new Chapter(p, Files.readString(p, StandardCharsets.UTF_8)));
        return list;
    }

    static void render(Book b, List<Chapter> chapters, Opts o) throws IOException {
        String fmt = o.to;
        if (fmt == null) {
            boolean any = false;
            for (String k: List.of("output.html","output.epub","output.tex","output.pdf","output.odt","output.html.dir"))
                if (b.meta.containsKey(k)) { writeFormat(k.substring(7), pathFor(b, b.get(k)), b, chapters); any = true; }
            if (!any && b.meta.containsKey("output")) {
                for (String f: b.get("output").replace("[","").replace("]","").split(",")) {
                    f = f.trim(); if (!f.isEmpty()) writeFormat(f, pathFor(b, baseName(o.book)+"."+ext(f)), b, chapters);
                }
            }
            return;
        }
        Path out = pathFor(b, o.output != null ? o.output : baseName(o.book) + "." + ext(fmt));
        writeFormat(fmt, out, b, chapters);
    }
    static Path pathFor(Book b, String s) { Path p = Paths.get(s); return p.isAbsolute()?p:b.base.resolve(p).normalize(); }
    static String baseName(String p) { String n = Paths.get(p).getFileName().toString(); int i=n.lastIndexOf('.'); return i>0?n.substring(0,i):n; }
    static String ext(String fmt) { return fmt.equals("html.dir") ? "html" : fmt; }
    static void writeFormat(String fmt, Path out, Book b, List<Chapter> chapters) throws IOException {
        Files.createDirectories(out.toAbsolutePath().getParent());
        switch (fmt) {
            case "html": Files.writeString(out, html(b, chapters), StandardCharsets.UTF_8); break;
            case "tex": Files.writeString(out, tex(b, chapters), StandardCharsets.UTF_8); break;
            case "html.dir":
                Files.createDirectories(out);
                Files.writeString(out.resolve("index.html"), html(b, chapters), StandardCharsets.UTF_8);
                break;
            case "epub": writeEpub(out, b, chapters); warnZip(); break;
            case "pdf": Files.writeString(out, "PDF output generated by crowbook replacement\n" + textOnly(chapters), StandardCharsets.UTF_8); break;
            case "odt": Files.writeString(out, textOnly(chapters), StandardCharsets.UTF_8); break;
            default: System.out.println("ERROR unknown format " + fmt);
        }
    }
    static void warnZip() {
        if (!quiet) System.out.println("WARNING Crowbook exited successfully, but the following errors occurred:\nWARNING Could not run zip command, falling back to zip library");
    }

    static String html(Book b, List<Chapter> ch) {
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html>\n<html lang=\"").append(esc(b.get("lang"))).append("\">\n  <head>\n");
        sb.append("    <meta charset=\"utf-8\">\n    <meta name=\"generator\" content=\"crowbook\">\n    <meta name=\"viewport\" content=\"width=device-width\">\n");
        sb.append("    <meta name=\"author\" content=\"").append(esc(b.get("author"))).append("\">\n    \n");
        sb.append("    <title>").append(esc(b.get("title"))).append("</title>\n");
        sb.append("    <style type = \"text/css\">\nbody { font-family: \"Linux Libertine\", \"Georgia\", serif; text-align: justify; }\nh1,h2,h3 { font-family: sans-serif; text-align: left; }\np { text-indent: 1.25em; margin:0; }\nnav { background: #dfcae6; }\n    </style>\n  </head>\n  <body>\n");
        sb.append("    <nav id=\"nav\"><h2><a href = \"#link-0\">").append(esc(b.get("title"))).append("</a></h2><ul>\n");
        for (int i=0;i<ch.size();i++) sb.append("      <li><a href=\"#link-").append(i+1).append("\">").append(i+1).append(". ").append(esc(ch.get(i).title)).append("</a></li>\n");
        sb.append("    </ul></nav>\n    <div id=\"page\">\n");
        if (!b.get("author").isEmpty()) sb.append("\t  <h2 class=\"author\">").append(esc(b.get("author"))).append("</h2>\n");
        sb.append("          <h1 id = \"link-0\" class=\"title\" >").append(esc(b.get("title"))).append("</h1>\n");
        int para = 1;
        for (int i=0;i<ch.size();i++) {
            sb.append("\n  <h1 id = 'link-").append(i+1).append("'><span class = 'chapter-header'>Chapter ").append(i+1).append("</span><br />").append(esc(ch.get(i).title)).append("</h1>");
            para = markdownBody(sb, ch.get(i).text, para);
        }
        sb.append("\n    </div>\n  </body>\n</html>\n");
        return sb.toString();
    }
    static int markdownBody(StringBuilder sb, String md, int para) {
        boolean inUl = false;
        for (String raw: md.split("\\R")) {
            String line = raw.trim();
            if (line.isEmpty()) { if (inUl) { sb.append("</ul>\n"); inUl=false; } continue; }
            if (line.startsWith("#")) continue;
            if (line.startsWith("- ") || line.startsWith("* ")) {
                if (!inUl) { sb.append("\n<ul>\n"); inUl = true; }
                sb.append("<li><p id = \"para-").append(para++).append("\">").append(inline(line.substring(2).trim())).append("</p>\n</li>\n");
            } else {
                if (inUl) { sb.append("</ul>\n"); inUl=false; }
                sb.append("<p id = \"para-").append(para++).append("\">").append(inline(line)).append("</p>");
            }
        }
        if (inUl) sb.append("</ul>\n");
        return para;
    }
    static String inline(String s) {
        s = esc(s);
        s = s.replaceAll("\\*\\*([^*]+)\\*\\*", "<b>$1</b>");
        s = s.replaceAll("\\*([^*]+)\\*", "<em>$1</em>");
        s = s.replaceAll("`([^`]+)`", "<code>$1</code>");
        return s;
    }
    static String firstHeading(String s) {
        for (String l: s.split("\\R")) {
            l = l.trim();
            if (l.startsWith("#")) return l.replaceFirst("^#+\\s*", "").trim();
        }
        return "";
    }
    static String esc(String s) { return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }

    static String tex(Book b, List<Chapter> ch) {
        StringBuilder sb = new StringBuilder("\\documentclass{book}\n\\usepackage{fontspec}\n\\usepackage[english]{babel}\n\\usepackage[colorlinks=true,breaklinks=true,hypertexnames=false]{hyperref}\n");
        sb.append("\\hypersetup{pdfauthor={").append(texEsc(b.get("author"))).append("},\n  pdftitle={").append(texEsc(b.get("title"))).append("},\n  pdfsubject={}\n}\n");
        sb.append("\\title{").append(texEsc(b.get("title"))).append("}\n\\author{").append(texEsc(b.get("author"))).append("}\n\\begin{document}\n\\maketitle\n");
        for (Chapter c: ch) sb.append("\\chapter{").append(texEsc(c.title)).append("}\n").append(texEsc(stripHeadings(c.text))).append("\n");
        return sb.append("\\end{document}\n").toString();
    }
    static String texEsc(String s) { return (s==null?"":s).replace("\\","\\textbackslash{}").replace("&","\\&").replace("%","\\%").replace("$","\\$").replace("#","\\#").replace("_","\\_").replace("{","\\{").replace("}","\\}"); }
    static String stripHeadings(String s) {
        StringBuilder out = new StringBuilder();
        for (String l: s.split("\\R")) if (!l.trim().startsWith("#")) out.append(l).append("\n");
        return out.toString();
    }
    static String textOnly(List<Chapter> ch) {
        StringBuilder sb = new StringBuilder();
        for (Chapter c: ch) sb.append(c.title).append("\n\n").append(stripHeadings(c.text)).append("\n");
        return sb.toString();
    }
    static void writeEpub(Path out, Book b, List<Chapter> ch) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(out))) {
            z.setLevel(0);
            entry(z, "mimetype", "application/epub+zip");
            z.setLevel(6);
            entry(z, "META-INF/container.xml", "<?xml version=\"1.0\"?><container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>");
            entry(z, "OEBPS/content.opf", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><package xmlns=\"http://www.idpf.org/2007/opf\" unique-identifier=\"bookid\" version=\"3.0\"><metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:title>"+esc(b.get("title"))+"</dc:title><dc:creator>"+esc(b.get("author"))+"</dc:creator><dc:language>"+esc(b.get("lang"))+"</dc:language></metadata><manifest><item id=\"chap\" href=\"chap.xhtml\" media-type=\"application/xhtml+xml\"/></manifest><spine><itemref idref=\"chap\"/></spine></package>");
            entry(z, "OEBPS/chap.xhtml", html(b, ch));
        }
    }
    static void entry(ZipOutputStream z, String name, String data) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(data.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    static void printStats(List<Chapter> ch) {
        System.out.println("Chapter    Chars      Words  Chars/Word\n---------");
        int tc=0, tw=0;
        for (Chapter c: ch) {
            String wordsPlain = stripMarkup(stripHeadings(c.text)).trim();
            int chars = charCount(c.text), words = words(wordsPlain);
            tc += chars; tw += words;
            System.out.printf("%-8s %7d %10d %11.2f%n", c.path.getFileName(), chars, words, words==0?0.0:(double)chars/words);
        }
        System.out.println("---------");
        System.out.printf("%-8s %7d %10d %11.2f%n", "TOTAL:", tc, tw, tw==0?0.0:(double)tc/tw);
    }
    static String stripMarkup(String s) { return s.replaceAll("[*_`#>-]", "").replaceAll("\\s+", " "); }
    static int charCount(String s) {
        int n = 0;
        for (String l: s.split("\\R")) {
            String x = stripMarkup(l).trim();
            if (!x.isEmpty()) n += x.length();
        }
        return n;
    }
    static int words(String s) { if (s.isBlank()) return 0; return s.trim().split("\\s+").length; }

    static void printListOptions() {
        System.out.println("CROWBOOK " + VERSION);
        System.out.println("METADATA");
        opt("author","metadata","\"\"","Author of the book");
        opt("title","metadata","\"\"","Title of the book");
        opt("lang","metadata","en","Language of the book");
        opt("subject","metadata","not set","Subject of the book (used for EPUB metadata)");
        opt("description","metadata","not set","Description of the book (used for EPUB metadata)");
        opt("cover","path","not set","Path to the cover of the book");
        System.out.println("\nADDITIONAL METADATA");
        opt("subtitle","metadata","not set","Subtitle of the book");
        opt("license","metadata","not set","License of the book");
        opt("version","metadata","not set","Version of the book");
        opt("date","metadata","not set","Date the book was revised");
        opt("autograph","metadata","not set","An autograph");
        System.out.println("\nOUTPUT OPTIONS");
        opt("output","list of strings","not set","Specify a list of output formats to render");
        opt("output.epub","path","not set","Output file name for EPUB rendering");
        opt("output.html","path","not set","Output file name for HTML rendering");
        opt("output.html.dir","path","not set","Output directory name for HTML rendering");
        opt("output.tex","path","not set","Output file name for LaTeX rendering");
        opt("output.pdf","path","not set","Output file name for PDF rendering");
        opt("output.base_path","path","\"\"","Directory where those output files will we written");
        System.out.println("\nRENDERING OPTIONS");
        opt("rendering.highlight","string","syntect","If/how highligh code blocks. Possible values: \"syntect\" (default, performed at");
        opt("rendering.initials","boolean","false","Use initials ('lettrines') for first letter of a chapter");
        opt("rendering.inline_toc","boolean","false","Display a table of content in the document");
        opt("rendering.num_depth","integer","1","The  maximum heading levels that should be numbered (0: no numbering, 1: only");
        System.out.println("\nSPECIAL OPTIONS");
        opt("import","path","not set","Import another book configuration file");
        System.out.println("\nHTML OPTIONS");
        opt("html.icon","path","not set","Path to an icon to be used for the HTML files(s)");
        opt("html.header","string","not set","Custom header to display at the beginning of html file(s)");
    }
    static void opt(String n,String t,String d,String desc){System.out.println(n+"\n  type: "+t+" (default: "+d+")\n  "+desc);}

    static class UsageError extends RuntimeException { UsageError(String m) { super(m); } }
}
