package sccclone;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Main {
    static class Lang {
        final String name;
        final String line;
        final String blockStart;
        final String blockEnd;
        final boolean markdown;
        Lang(String name, String line, String blockStart, String blockEnd) {
            this(name, line, blockStart, blockEnd, false);
        }
        Lang(String name, String line, String blockStart, String blockEnd, boolean markdown) {
            this.name = name;
            this.line = line;
            this.blockStart = blockStart;
            this.blockEnd = blockEnd;
            this.markdown = markdown;
        }
    }

    static class FileStat {
        String path;
        String fileName;
        Lang lang;
        long bytes;
        int lines, code, comments, blanks, complexity;
        int maxLine, totalLineLen;
    }

    static class Summary {
        String name;
        long bytes;
        int files, lines, code, comments, blanks, complexity;
        int maxLine, totalLineLen;
        List<FileStat> fileStats = new ArrayList<>();
    }

    static class Opt {
        boolean help, version, languages, byFile, noComplexity, noCocomo, noSize, wide, character, percent, ci;
        boolean includeSymlinks, noDuplicates, countIgnore;
        boolean noGitignore, noIgnore, noSccIgnore, binary;
        String format = "tabular";
        String output = null;
        String sort = "files";
        Set<String> includeExt = new HashSet<>();
        Set<String> excludeExt = new HashSet<>();
        Set<String> excludeDir = new HashSet<>(Arrays.asList(".git", ".hg", ".svn"));
        Set<String> excludeFile = new HashSet<>(Arrays.asList("package-lock.json", "Cargo.lock", "yarn.lock", "pubspec.lock", "Podfile.lock", "pnpm-lock.yaml"));
        Map<String,String> countAs = new HashMap<>();
        List<String> paths = new ArrayList<>();
    }

    static final Map<String, Lang> EXT = new HashMap<>();
    static final Map<String, Lang> NAME = new HashMap<>();
    static final Map<String, Lang> LANG_BY_NAME = new HashMap<>();
    static final List<String> LANGUAGE_LINES = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        initLangs();
        Opt opt = parse(args);
        if (opt.help) { printHelp(); return; }
        if (opt.version) { System.out.println("scc version 3.7.0"); return; }
        if (opt.languages) { printLanguages(); return; }
        if (opt.paths.isEmpty()) opt.paths.add(".");

        List<Path> files = collectFiles(opt);
        List<FileStat> stats = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (Path p : files) {
            Lang lang = languageFor(p, opt);
            if (lang == null) continue;
            if (!opt.includeExt.isEmpty() && !matchesExt(p, opt.includeExt)) continue;
            if (!opt.excludeExt.isEmpty() && matchesExt(p, opt.excludeExt)) continue;
            if (!opt.binary && isBinary(p)) continue;
            FileStat fs = countFile(p, lang);
            if (opt.noDuplicates) {
                String key = fs.bytes + ":" + fs.lines + ":" + fs.code + ":" + fs.comments + ":" + fs.blanks + ":" + safeRead(p).hashCode();
                if (!seen.add(key)) continue;
            }
            stats.add(fs);
        }

        Map<String, Summary> sums = new TreeMap<>();
        for (FileStat fs : stats) {
            Summary s = sums.computeIfAbsent(fs.lang.name, k -> { Summary x = new Summary(); x.name = k; return x; });
            s.files++;
            s.bytes += fs.bytes;
            s.lines += fs.lines;
            s.code += fs.code;
            s.comments += fs.comments;
            s.blanks += fs.blanks;
            s.complexity += fs.complexity;
            s.maxLine = Math.max(s.maxLine, fs.maxLine);
            s.totalLineLen += fs.totalLineLen;
            s.fileStats.add(fs);
        }
        List<Summary> list = new ArrayList<>(sums.values());
        sort(list, opt.sort);
        String out = format(list, stats, opt);
        if (opt.output != null) {
            try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(opt.output), StandardCharsets.UTF_8)) { bw.write(out); }
        } else {
            System.out.print(out);
        }
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) { for (int j=i+1;j<args.length;j++) o.paths.add(args[j]); break; }
            if (!a.startsWith("-") || a.equals("-")) { o.paths.add(a); continue; }
            switch (a) {
                case "-h": case "--help": o.help = true; break;
                case "--version": o.version = true; break;
                case "-l": case "--languages": o.languages = true; break;
                case "--by-file": o.byFile = true; break;
                case "-c": case "--no-complexity": o.noComplexity = true; break;
                case "--no-cocomo": o.noCocomo = true; break;
                case "--no-size": o.noSize = true; break;
                case "-w": case "--wide": o.wide = true; break;
                case "-m": case "--character": o.character = true; break;
                case "-p": case "--percent": o.percent = true; break;
                case "-u": case "--uloc": break;
                case "-a": case "--dryness": break;
                case "--ci": o.ci = true; break;
                case "--include-symlinks": o.includeSymlinks = true; break;
                case "-d": case "--no-duplicates": o.noDuplicates = true; break;
                case "--count-ignore": o.countIgnore = true; break;
                case "--no-gitignore": o.noGitignore = true; break;
                case "--no-ignore": o.noIgnore = true; break;
                case "--no-scc-ignore": o.noSccIgnore = true; break;
                case "--binary": o.binary = true; break;
                case "-f": case "--format": o.format = need(args, ++i, a); break;
                case "-o": case "--output": o.output = need(args, ++i, a); break;
                case "-s": case "--sort": o.sort = need(args, ++i, a); break;
                case "-i": case "--include-ext": addCsv(o.includeExt, need(args, ++i, a)); break;
                case "-x": case "--exclude-ext": addCsv(o.excludeExt, need(args, ++i, a)); break;
                case "-n": case "--exclude-file": addCsv(o.excludeFile, need(args, ++i, a)); break;
                case "--exclude-dir": o.excludeDir.clear(); addCsv(o.excludeDir, need(args, ++i, a)); break;
                case "--count-as": parseCountAs(o.countAs, need(args, ++i, a)); break;
                default:
                    if (a.startsWith("--format=")) o.format = a.substring(9);
                    else if (a.startsWith("--sort=")) o.sort = a.substring(7);
                    else if (a.startsWith("--include-ext=")) addCsv(o.includeExt, a.substring(14));
                    else if (a.startsWith("--exclude-ext=")) addCsv(o.excludeExt, a.substring(14));
                    else if (a.startsWith("--exclude-dir=")) { o.excludeDir.clear(); addCsv(o.excludeDir, a.substring(14)); }
                    else if (a.startsWith("--count-as=")) parseCountAs(o.countAs, a.substring(11));
                    else if (takesValue(a) && i + 1 < args.length) i++;
                    break;
            }
        }
        return o;
    }

    static boolean takesValue(String a) {
        return Arrays.asList("--avg-wage","--currency-symbol","--large-byte-count","--large-line-count",
                "--size-unit","--sql-project","--cocomo-project-type","--eaf","--overhead","--format-multi",
                "--locomo-config","--locomo-cycles","--locomo-input-price","--locomo-output-price",
                "--locomo-preset","--locomo-review","--locomo-tps","--min-gen-line-length",
                "--directory-walker-job-workers","--file-gc-count","--file-list-queue-size",
                "--file-process-job-workers","--file-summary-job-queue-size","--not-match").contains(a);
    }

    static String need(String[] args, int i, String flag) {
        if (i >= args.length) throw new IllegalArgumentException("flag needs an argument: " + flag);
        return args[i];
    }
    static void addCsv(Set<String> set, String csv) {
        for (String s : csv.split(",")) if (!s.trim().isEmpty()) set.add(normExt(s.trim()));
    }
    static void parseCountAs(Map<String,String> map, String spec) {
        for (String part : spec.split(",")) {
            int idx = part.indexOf(':');
            if (idx > 0) map.put(normExt(part.substring(0, idx).replace("\"", "")), part.substring(idx+1).replace("\"", ""));
        }
    }

    static List<Path> collectFiles(Opt opt) throws IOException {
        List<Path> files = new ArrayList<>();
        Set<FileVisitOption> visit = opt.includeSymlinks ? Set.of(FileVisitOption.FOLLOW_LINKS) : Collections.emptySet();
        for (String s : opt.paths) {
            Path p = Paths.get(s);
            if (!Files.exists(p)) continue;
            List<String> ignores = loadIgnores(p, opt);
            if (Files.isRegularFile(p)) { if (includeFile(p, opt)) files.add(p); continue; }
            Files.walkFileTree(p, visit, Integer.MAX_VALUE, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    String n = dir.getFileName() == null ? "" : dir.getFileName().toString();
                    if (!dir.equals(p) && opt.excludeDir.contains(n)) return FileVisitResult.SKIP_SUBTREE;
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (attrs.isRegularFile() && includeFile(file, opt) && !ignored(p, file, ignores)) files.add(file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        files.sort(Comparator.comparing(Path::toString));
        return files;
    }

    static boolean includeFile(Path p, Opt o) {
        String n = p.getFileName().toString();
        if (!o.countIgnore && (n.equals(".gitignore") || n.equals(".ignore") || n.equals(".sccignore"))) return false;
        return !o.excludeFile.contains(n);
    }

    static List<String> loadIgnores(Path root, Opt o) {
        if (Files.isRegularFile(root)) return Collections.emptyList();
        List<String> patterns = new ArrayList<>();
        addIgnoreFile(root.resolve(".gitignore"), patterns, !o.noGitignore);
        addIgnoreFile(root.resolve(".ignore"), patterns, !o.noIgnore);
        addIgnoreFile(root.resolve(".sccignore"), patterns, !o.noSccIgnore);
        return patterns;
    }
    static void addIgnoreFile(Path p, List<String> patterns, boolean enabled) {
        if (!enabled || !Files.isRegularFile(p)) return;
        try {
            for (String line : Files.readAllLines(p, StandardCharsets.UTF_8)) {
                String t = line.trim();
                if (!t.isEmpty() && !t.startsWith("#") && !t.startsWith("!")) patterns.add(t);
            }
        } catch (IOException ignored) {}
    }
    static boolean ignored(Path root, Path file, List<String> patterns) {
        if (patterns.isEmpty()) return false;
        String rel = root.relativize(file).toString().replace('\\', '/');
        String name = file.getFileName().toString();
        for (String p : patterns) {
            String pat = p.replace('\\', '/');
            if (pat.endsWith("/") && rel.startsWith(pat)) return true;
            if (pat.startsWith("/")) pat = pat.substring(1);
            if (glob(name, pat) || glob(rel, pat) || rel.startsWith(pat + "/")) return true;
        }
        return false;
    }
    static boolean glob(String text, String pat) {
        StringBuilder re = new StringBuilder();
        for (char ch : pat.toCharArray()) {
            if (ch == '*') re.append(".*");
            else if (ch == '?') re.append('.');
            else if ("\\.[]{}()+-^$|".indexOf(ch) >= 0) re.append('\\').append(ch);
            else re.append(ch);
        }
        return text.matches(re.toString());
    }
    static boolean isBinary(Path p) {
        try {
            byte[] b = Files.readAllBytes(p);
            int max = Math.min(b.length, 8192);
            for (int i = 0; i < max; i++) if (b[i] == 0) return true;
        } catch (IOException ignored) {}
        return false;
    }

    static Lang languageFor(Path p, Opt opt) {
        String n = p.getFileName().toString();
        String lname = n.toLowerCase(Locale.ROOT);
        String ext = extension(n);
        if (opt.countAs.containsKey(normExt(ext))) {
            String target = opt.countAs.get(normExt(ext));
            Lang byExt = EXT.get(normExt(target));
            if (byExt != null) return byExt;
            Lang byName = LANG_BY_NAME.get(target.toLowerCase(Locale.ROOT));
            if (byName != null) return byName;
            return new Lang(target, "//", "/*", "*/");
        }
        if (NAME.containsKey(lname)) return NAME.get(lname);
        if (EXT.containsKey(normExt(ext))) return EXT.get(normExt(ext));
        try {
            String first = Files.lines(p, StandardCharsets.UTF_8).findFirst().orElse("");
            if (first.startsWith("#!")) {
                if (first.contains("python")) return EXT.get("py");
                if (first.contains("bash")) return EXT.get("bash");
                if (first.contains("sh")) return EXT.get("sh");
                if (first.contains("ruby")) return EXT.get("rb");
                if (first.contains("perl")) return EXT.get("pl");
                if (first.contains("node")) return EXT.get("js");
            }
        } catch (Exception ignored) {}
        return null;
    }

    static boolean matchesExt(Path p, Set<String> set) {
        String n = p.getFileName().toString();
        return set.contains(normExt(extension(n))) || set.contains(n.toLowerCase(Locale.ROOT));
    }
    static String extension(String n) {
        int dot = n.lastIndexOf('.');
        if (dot <= 0 || dot == n.length()-1) return n.startsWith(".") ? n : "";
        return n.substring(dot+1);
    }
    static String normExt(String e) {
        e = e.toLowerCase(Locale.ROOT);
        return e.startsWith(".") ? e.substring(1) : e;
    }

    static FileStat countFile(Path p, Lang lang) {
        FileStat fs = new FileStat();
        fs.path = p.toString();
        fs.fileName = p.getFileName().toString();
        fs.lang = lang;
        try { fs.bytes = Files.size(p); } catch (IOException ignored) {}
        List<String> lines;
        try { lines = Files.readAllLines(p, StandardCharsets.UTF_8); }
        catch (Exception e) { return fs; }
        fs.lines = lines.size();
        boolean inBlock = false;
        String activeBlockEnd = lang.blockEnd;
        boolean inFence = false;
        for (String line : lines) {
            int len = line.length();
            fs.maxLine = Math.max(fs.maxLine, len);
            fs.totalLineLen += len;
            String t = line.trim();
            if (t.isEmpty()) { fs.blanks++; continue; }
            boolean comment = false, code = false;
            if (lang.markdown) {
                if (t.startsWith("```") || t.startsWith("~~~")) inFence = !inFence;
                code = true;
                fs.code++;
            } else if (inBlock) {
                fs.comments++;
                if (activeBlockEnd != null && t.contains(activeBlockEnd)) {
                    inBlock = false;
                    String after = t.substring(t.indexOf(activeBlockEnd) + activeBlockEnd.length()).trim();
                    if (!after.isEmpty()) { fs.comments--; fs.code++; code = true; }
                }
                if (!code) continue;
            } else {
                if (lang.name.equals("Python") && (t.startsWith("\"\"\"") || t.startsWith("'''"))) {
                    fs.comments++;
                    String marker = t.startsWith("\"\"\"") ? "\"\"\"" : "'''";
                    if (t.indexOf(marker, 3) < 0) { inBlock = true; activeBlockEnd = marker; }
                    continue;
                }
                if (lang.line != null && t.startsWith(lang.line)) comment = true;
                if (!comment && lang.blockStart != null && t.startsWith(lang.blockStart)) {
                    comment = true;
                    activeBlockEnd = lang.blockEnd;
                    if (!t.contains(lang.blockEnd) || t.indexOf(lang.blockEnd) < t.indexOf(lang.blockStart)) inBlock = true;
                    else {
                        String after = t.substring(t.indexOf(lang.blockEnd) + lang.blockEnd.length()).trim();
                        if (!after.isEmpty()) { comment = false; code = true; }
                    }
                }
                if (comment) fs.comments++; else { fs.code++; code = true; }
            }
            if (code) fs.complexity += complexity(line, lang.name);
        }
        return fs;
    }

    static int complexity(String line, String lang) {
        String s = line;
        int c = 0;
        String[] words = {" if "," for "," while "," case "," catch "," switch ","&&","||","?"," elif "," else if "," when "," match "};
        String padded = " " + s.replace('(', ' ').replace('{', ' ') + " ";
        for (String w : words) if (padded.contains(w)) c++;
        if (lang.equals("Python") && padded.contains(" except ")) c++;
        return c;
    }

    static String format(List<Summary> list, List<FileStat> files, Opt opt) {
        if (opt.format.equals("wide")) {
            opt.wide = true;
            return table(list, opt);
        }
        switch (opt.format) {
            case "json": return json(list, false);
            case "json2": return "{\"languageSummary\":" + json(list, false) + ",\"estimatedCost\":" + estimateCost(totalCode(list)) + ",\"estimatedScheduleMonths\":0,\"estimatedPeople\":0}";
            case "csv": return csv(list);
            case "csv-stream": return csvStream(files);
            case "cloc-yaml": return yaml(list);
            case "openmetrics": return metrics(list);
            case "sql": case "sql-insert": return sql(list);
            case "html": case "html-table": return html(list);
            default: return table(list, opt);
        }
    }

    static String table(List<Summary> list, Opt opt) {
        boolean ascii = opt.ci;
        String border = ascii ? "-------------------------------------------------------------------------------" : "───────────────────────────────────────────────────────────────────────────────";
        if (opt.wide) border = ascii ? "-------------------------------------------------------------------------------------------------------------" : "─────────────────────────────────────────────────────────────────────────────────────────────────────────────";
        StringBuilder sb = new StringBuilder();
        sb.append(border).append('\n');
        if (opt.noComplexity) sb.append(String.format("%-20s %12s %11s %10s %11s %10s%n", "Language","Files","Lines","Blanks","Comments","Code"));
        else if (opt.wide) sb.append(String.format("%-30s %10s %9s %8s %9s %8s %10s %16s%n", "Language","Files","Lines","Blanks","Comments","Code","Complexity","Complexity/Lines"));
        else sb.append(String.format("%-17s %8s %11s %9s %9s %10s %10s%n", "Language","Files","Lines","Blanks","Comments","Code","Complexity"));
        sb.append(border).append('\n');
        Summary total = total(list);
        for (Summary s : list) {
            appendSummary(sb, s, opt);
            if (opt.character) sb.append(String.format("%-17s %8s %11s%n", "MaxLine / MeanLine", fmt(s.maxLine), fmt(s.lines == 0 ? 0 : s.totalLineLen / s.lines))).append(ascii ? "-------------------------------------------------------------------------------\n" : "-------------------------------------------------------------------------------\n");
            if (opt.percent) {
                sb.append(String.format("%-17s %8s %11s %9s %9s %10s", "Percentage", pct(s.files,total.files), pct(s.lines,total.lines), pct(s.blanks,total.blanks), pct(s.comments,total.comments), pct(s.code,total.code)));
                if (!opt.noComplexity) sb.append(String.format(" %10s", pct(s.complexity,total.complexity)));
                sb.append('\n').append("-------------------------------------------------------------------------------\n");
            }
            if (opt.byFile) {
                sb.append(border).append('\n');
                s.fileStats.sort(Comparator.comparing(f -> f.path));
                for (FileStat f : s.fileStats) {
                    sb.append(String.format("%-27s %9s %9s %9s %10s", truncate(f.path, 27), fmt(f.lines), fmt(f.blanks), fmt(f.comments), fmt(f.code)));
                    if (!opt.noComplexity) sb.append(String.format(" %10s", fmt(f.complexity)));
                    sb.append('\n');
                }
                sb.append(border).append('\n');
            }
        }
        if (!opt.byFile) sb.append(border).append('\n');
        total.name = "Total";
        appendSummary(sb, total, opt);
        sb.append(border).append('\n');
        if (!opt.noCocomo) {
            sb.append("Estimated Cost to Develop (organic) $").append(fmt((long)estimateCost(total.code))).append('\n');
            sb.append("Estimated Schedule Effort (organic) 0.00 months\n");
            sb.append("Estimated People Required (organic) 0.00\n");
            sb.append(border).append('\n');
        }
        if (!opt.noSize) {
            sb.append("Processed ").append(fmt(total.bytes)).append(" bytes, ").append(String.format(Locale.US, "%.3f", total.bytes / 1000000.0)).append(" megabytes (SI)\n");
            sb.append(border).append('\n');
        }
        return sb.toString();
    }

    static void appendSummary(StringBuilder sb, Summary s, Opt opt) {
        if (opt.noComplexity) sb.append(String.format("%-20s %12s %11s %10s %11s %10s%n", truncate(s.name,20), fmt(s.files), fmt(s.lines), fmt(s.blanks), fmt(s.comments), fmt(s.code)));
        else if (opt.wide) sb.append(String.format("%-30s %10s %9s %8s %9s %8s %10s %16s%n", truncate(s.name,30), fmt(s.files), fmt(s.lines), fmt(s.blanks), fmt(s.comments), fmt(s.code), fmt(s.complexity), String.format(Locale.US, "%.2f", s.code == 0 ? 0.0 : 100.0*s.complexity/s.code)));
        else sb.append(String.format("%-17s %8s %11s %9s %9s %10s %10s%n", truncate(s.name,17), fmt(s.files), fmt(s.lines), fmt(s.blanks), fmt(s.comments), fmt(s.code), fmt(s.complexity)));
    }

    static Summary total(List<Summary> list) {
        Summary t = new Summary();
        for (Summary s : list) { t.files+=s.files; t.bytes+=s.bytes; t.lines+=s.lines; t.code+=s.code; t.comments+=s.comments; t.blanks+=s.blanks; t.complexity+=s.complexity; t.maxLine=Math.max(t.maxLine,s.maxLine); t.totalLineLen+=s.totalLineLen; }
        return t;
    }
    static int totalCode(List<Summary> l) { int x=0; for (Summary s:l) x+=s.code; return x; }
    static double estimateCost(int code) { return code * 21.45830066413562; }

    static String json(List<Summary> list, boolean files) {
        StringBuilder sb = new StringBuilder("[");
        for (int i=0;i<list.size();i++) {
            Summary s=list.get(i); if (i>0) sb.append(',');
            sb.append("{\"Name\":\"").append(esc(s.name)).append("\",\"Bytes\":").append(s.bytes).append(",\"CodeBytes\":0,\"Lines\":").append(s.lines)
              .append(",\"Code\":").append(s.code).append(",\"Comment\":").append(s.comments).append(",\"Blank\":").append(s.blanks)
              .append(",\"Complexity\":").append(s.complexity).append(",\"Count\":").append(s.files)
              .append(",\"WeightedComplexity\":0,\"Files\":[],\"LineLength\":null,\"ULOC\":0}");
        }
        return sb.append("]").toString();
    }
    static String csv(List<Summary> list) {
        StringBuilder sb=new StringBuilder("Language,Lines,Code,Comments,Blanks,Complexity,Bytes,Files,ULOC\n");
        for(Summary s:list) sb.append(q(s.name)).append(',').append(s.lines).append(',').append(s.code).append(',').append(s.comments).append(',').append(s.blanks).append(',').append(s.complexity).append(',').append(s.bytes).append(',').append(s.files).append(",0\n");
        return sb.toString();
    }
    static String csvStream(List<FileStat> files) {
        files.sort(Comparator.comparing((FileStat f)->f.lang.name).thenComparing(f->f.path));
        StringBuilder sb=new StringBuilder("Language,Provider,Filename,Lines,Code,Comments,Blanks,Complexity,Bytes,Uloc\n");
        for(FileStat f:files) sb.append(q(f.lang.name)).append(',').append(q(f.path)).append(',').append(q(f.fileName)).append(',').append(f.lines).append(',').append(f.code).append(',').append(f.comments).append(',').append(f.blanks).append(',').append(f.complexity).append(',').append(f.bytes).append(",0\n");
        return sb.toString();
    }
    static String yaml(List<Summary> list) {
        Summary t=total(list); StringBuilder sb=new StringBuilder("# https://github.com/boyter/scc/\nheader:\n  url: https://github.com/boyter/scc/\n  version: 3.7.0\n  elapsed_seconds: 0\n  n_files: "+t.files+"\n  n_lines: "+t.lines+"\n");
        for(Summary s:list) sb.append(s.name).append(":\n  name: ").append(s.name).append("\n  code: ").append(s.code).append("\n  comment: ").append(s.comments).append("\n  blank: ").append(s.blanks).append("\n  nFiles: ").append(s.files).append('\n');
        sb.append("SUM:\n  code: ").append(t.code).append("\n  comment: ").append(t.comments).append("\n  blank: ").append(t.blanks).append("\n  nFiles: ").append(t.files).append('\n');
        return sb.toString();
    }
    static String metrics(List<Summary> list) {
        StringBuilder sb=new StringBuilder();
        for(Summary s:list) {
            String l=s.name.replace("\\","\\\\").replace("\"","\\\"");
            sb.append("scc_files{language=\"").append(l).append("\"} ").append(s.files).append('\n');
            sb.append("scc_lines{language=\"").append(l).append("\"} ").append(s.lines).append('\n');
            sb.append("scc_code{language=\"").append(l).append("\"} ").append(s.code).append('\n');
            sb.append("scc_comments{language=\"").append(l).append("\"} ").append(s.comments).append('\n');
            sb.append("scc_blanks{language=\"").append(l).append("\"} ").append(s.blanks).append('\n');
        }
        return sb.toString();
    }
    static String sql(List<Summary> list) {
        StringBuilder sb=new StringBuilder("CREATE TABLE t (language TEXT, files INTEGER, lines INTEGER, blanks INTEGER, comments INTEGER, code INTEGER, complexity INTEGER);\n");
        for(Summary s:list) sb.append("INSERT INTO t VALUES ('").append(s.name.replace("'","''")).append("',").append(s.files).append(',').append(s.lines).append(',').append(s.blanks).append(',').append(s.comments).append(',').append(s.code).append(',').append(s.complexity).append(");\n");
        return sb.toString();
    }
    static String html(List<Summary> list) {
        StringBuilder sb=new StringBuilder("<table><thead><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr></thead><tbody>");
        for(Summary s:list) sb.append("<tr><td>").append(esc(s.name)).append("</td><td>").append(s.files).append("</td><td>").append(s.lines).append("</td><td>").append(s.blanks).append("</td><td>").append(s.comments).append("</td><td>").append(s.code).append("</td><td>").append(s.complexity).append("</td></tr>");
        return sb.append("</tbody></table>\n").toString();
    }

    static void sort(List<Summary> list, String sort) {
        Comparator<Summary> c;
        switch (sort) {
            case "name": c = Comparator.comparing(s -> s.name); break;
            case "lines": c = Comparator.<Summary>comparingInt(s -> s.lines).reversed().thenComparing(s -> s.name); break;
            case "blanks": c = Comparator.<Summary>comparingInt(s -> s.blanks).reversed().thenComparing(s -> s.name); break;
            case "code": c = Comparator.<Summary>comparingInt(s -> s.code).reversed().thenComparing(s -> s.name); break;
            case "comments": c = Comparator.<Summary>comparingInt(s -> s.comments).reversed().thenComparing(s -> s.name); break;
            case "complexity": c = Comparator.<Summary>comparingInt(s -> s.complexity).reversed().thenComparing(s -> s.name); break;
            default: c = Comparator.<Summary>comparingInt(s -> s.files).reversed().thenComparing(s -> s.name); break;
        }
        list.sort(c);
    }

    static String fmt(long n) { return NumberFormat.getIntegerInstance(Locale.US).format(n); }
    static String pct(long a, long b) { return String.format(Locale.US, "%.1f%%", b == 0 ? 0.0 : (100.0*a/b)); }
    static String truncate(String s, int n) { return s.length() <= n ? s : s.substring(0, Math.max(0,n-1)) + "…"; }
    static String esc(String s) { return s.replace("\\","\\\\").replace("\"","\\\"").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }
    static String q(String s) { return s.matches("[A-Za-z0-9_./:-]+") ? s : "\"" + s.replace("\"","\"\"") + "\""; }
    static String safeRead(Path p) { try { return Files.readString(p); } catch(Exception e) { return ""; } }

    static void printHelp() {
        System.out.print("Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.\nVersion 3.7.0\nBen Boyter <ben@boyter.org> + Contributors\n\nUsage:\n  scc [flags] [files or directories]\n\nFlags:\n      --by-file                            display output for every file\n  -m, --character                          calculate max and mean characters per line\n  -c, --no-complexity                      skip calculation of code complexity\n  -d, --no-duplicates                      remove duplicate files from stats and output\n  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default \"tabular\")\n  -h, --help                               help for scc\n  -l, --languages                          print supported languages and extensions\n      --no-cocomo                          remove COCOMO calculation output\n      --no-size                            remove size calculation output\n  -o, --output string                      output filename (default stdout)\n  -p, --percent                            include percentage values in output\n  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default \"files\")\n      --version                            version for scc\n  -w, --wide                               wider output with additional statistics (implies --complexity)\n");
    }

    static void addLang(String name, String line, String bs, String be, String... exts) {
        Lang l = new Lang(name, line, bs, be);
        LANG_BY_NAME.put(name.toLowerCase(Locale.ROOT), l);
        for (String e: exts) {
            if (e.contains(".") || e.equals(e.toLowerCase(Locale.ROOT)) && !e.matches("[a-z0-9]+")) NAME.put(e.toLowerCase(Locale.ROOT), l);
            else EXT.put(normExt(e), l);
        }
        LANGUAGE_LINES.add(name + " (" + String.join(",", exts) + ")");
    }
    static void initLangs() {
        if (!EXT.isEmpty()) return;
        addLang("ABAP","*","/*","*/","abap"); addLang("ActionScript","//","/*","*/","as");
        addLang("Ada","--",null,null,"ada","adb","ads","pad"); addLang("Assembly",";",null,null,"s","asm");
        addLang("BASH","#",null,null,"bash","bashrc",".bashrc",".bash_profile",".bash_login",".bash_logout");
        addLang("Batch","REM",null,null,"bat","btm","cmd"); addLang("C","//","/*","*/","c","ec","pgc");
        addLang("C Header","//","/*","*/","h"); addLang("C#","//","/*","*/","cs","csx");
        addLang("C++","//","/*","*/","cc","cpp","cxx","c++","ino"); addLang("C++ Header","//","/*","*/","hh","hpp","hxx","h++","inl","ipp","tpp");
        addLang("CMake","#",null,null,"cmake","cmakelists.txt"); addLang("CSS",null,"/*","*/","css");
        addLang("CSV",null,null,null,"csv"); addLang("Clojure",";",null,null,"clj","cljc","cljs");
        addLang("CoffeeScript","#",null,null,"coffee"); addLang("Crystal","#",null,null,"cr");
        addLang("D","//","/*","*/","d"); addLang("Dart","//","/*","*/","dart");
        addLang("Dockerfile","#",null,null,"dockerfile"); addLang("Elixir","#",null,null,"ex","exs");
        addLang("Elm","--","{-","-}","elm"); addLang("Erlang","%",null,null,"erl","hrl");
        addLang("F#","//","(*","*)","fs","fsi","fsx"); addLang("FORTRAN Legacy","!",null,null,"f","for","ftn","f77");
        addLang("Fortran Modern","!",null,null,"f03","f08","f90","f95"); addLang("Go","//","/*","*/","go");
        addLang("Gradle","//","/*","*/","gradle"); addLang("GraphQL","#",null,null,"graphql","gql");
        addLang("Groovy","//","/*","*/","groovy","gvy"); addLang("Haskell","--","{-","-}","hs","lhs");
        addLang("HTML",null,"<!--","-->","html","htm"); addLang("Java","//","/*","*/","java");
        addLang("JavaScript","//","/*","*/","js","mjs","cjs","jsx"); addLang("JSON",null,null,null,"json");
        addLang("JSX","//","/*","*/","jsx"); addLang("Julia","#","#=","=#","jl");
        addLang("Kotlin","//","/*","*/","kt","kts"); addLang("License",null,null,null,"license","licence","copying");
        addLang("Lua","--","--[[","]]","lua"); addLang("Makefile","#",null,null,"makefile","mk");
        addLang("Markdown",null,null,null,"md","markdown"); EXT.put("md", new Lang("Markdown", null, null, null, true)); EXT.put("markdown", EXT.get("md"));
        LANG_BY_NAME.put("markdown", EXT.get("md"));
        addLang("Objective C","//","/*","*/","m"); addLang("Objective C++","//","/*","*/","mm");
        addLang("PHP","//","/*","*/","php","php3","php4","php5","phtml"); addLang("Perl","#",null,null,"pl","pm","t");
        addLang("Plain Text",null,null,null,"txt","text"); addLang("PowerShell","#","<#","#>","ps1","psm1");
        addLang("Python","#",null,null,"py","pyw"); addLang("R","#",null,null,"r","R");
        addLang("Ruby","#",null,null,"rb","rake","gemspec"); addLang("Rust","//","/*","*/","rs");
        addLang("Scala","//","/*","*/","scala","sc"); addLang("Shell","#",null,null,"sh");
        addLang("SQL","--","/*","*/","sql"); addLang("Swift","//","/*","*/","swift");
        addLang("TOML","#",null,null,"toml"); addLang("TypeScript","//","/*","*/","ts","tsx");
        addLang("XML",null,"<!--","-->","xml","xsd","xsl","xslt","pom"); addLang("YAML","#",null,null,"yaml","yml");
        addLang("Zig","//",null,null,"zig");
        NAME.put("readme", EXT.get("md")); NAME.put("readme.md", EXT.get("md")); NAME.put("makefile", EXT.get("mk"));
        NAME.put("dockerfile", EXT.get("dockerfile")); NAME.put("license", EXT.get("license")); NAME.put("licence", EXT.get("license"));
        Collections.sort(LANGUAGE_LINES);
    }
    static void printLanguages() {
        for (String s : LANGUAGE_LINES) System.out.println(s);
    }
}
