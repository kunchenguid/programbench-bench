package curlieclone;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Main {
    private static final String USAGE = "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]";
    private static final Set<String> METHODS = new HashSet<>(Arrays.asList(
            "GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", "TRACE", "CONNECT"));
    private static final Set<String> VALUE_OPTIONS = new HashSet<>(Arrays.asList(
            "-A", "--user-agent", "-b", "--cookie", "-c", "--cookie-jar", "-d", "--data",
            "--data-ascii", "--data-binary", "--data-raw", "--data-urlencode", "-D", "--dump-header",
            "-e", "--referer", "-E", "--cert", "--cacert", "--capath", "--cert-type", "--ciphers",
            "-H", "--header", "-K", "--config", "-m", "--max-time", "--connect-timeout",
            "-o", "--output", "--output-dir", "-r", "--range", "-u", "--user", "-U", "--proxy-user",
            "-w", "--write-out", "-x", "--proxy", "-X", "--request", "--url", "--resolve",
            "--connect-to", "--retry", "--retry-delay", "--retry-max-time", "--max-redirs",
            "--limit-rate", "--local-port", "--interface", "--noproxy", "--proto", "--proto-redir",
            "--proto-default", "--unix-socket", "--abstract-unix-socket", "--libcurl", "--trace",
            "--trace-ascii", "-T", "--upload-file", "-Q", "--quote", "-z", "--time-cond",
            "--form-string", "--proxy-header", "--proxy-cacert", "--proxy-capath", "--proxy-cert",
            "--proxy-key", "--proxy-pass", "--key", "--key-type", "--pass", "--pubkey"));

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            printCurlHelp("all");
            return;
        }
        if (isHelp(args)) {
            printCurlHelp(args.length > 1 ? args[1] : "");
            return;
        }
        if (args.length == 1 && (args[0].equals("-V") || args[0].equals("--version"))) {
            runPassthrough(Arrays.asList("curl", "--version"));
            return;
        }

        Parsed parsed = parse(args);
        List<String> curl = buildCurl(parsed);

        if (parsed.printCurl) {
            if (parsed.url != null) {
                System.out.println(displayUrl(parsed.url, parsed.query));
            }
            System.out.println(shellLine(curl));
            return;
        }

        if (parsed.url != null) {
            System.err.println(displayUrl(parsed.url, parsed.query));
        }
        int code = runCurl(curl, parsed.pretty);
        System.exit(code);
    }

    private static boolean isHelp(String[] args) {
        return args[0].equals("-h") || args[0].equals("--help");
    }

    private static void printCurlHelp(String category) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add("curl");
        cmd.add("--help");
        if (category != null) cmd.add(category);
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        String text = new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        p.waitFor();
        String[] lines = text.split("\\R", -1);
        if (lines.length > 0) lines[0] = USAGE;
        System.out.print(String.join(System.lineSeparator(), lines));
    }

    private static Parsed parse(String[] args) {
        Parsed p = new Parsed();
        List<String> positional = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--curl")) {
                p.printCurl = true;
            } else if (a.equals("--pretty")) {
                p.pretty = true;
            } else if (a.equals("--form")) {
                p.formMode = true;
            } else if (a.startsWith("-") && !a.equals("-")) {
                p.prefix.add(a);
                if (takesValue(a) && i + 1 < args.length) {
                    p.prefix.add(args[++i]);
                }
            } else {
                positional.add(a);
            }
        }

        int idx = 0;
        if (idx < positional.size() && METHODS.contains(positional.get(idx).toUpperCase(Locale.ROOT))
                && idx + 1 < positional.size()) {
            p.method = positional.get(idx).toUpperCase(Locale.ROOT);
            idx++;
        }
        if (idx < positional.size()) {
            p.url = positional.get(idx++);
        }
        for (; idx < positional.size(); idx++) {
            parseItem(positional.get(idx), p);
        }
        return p;
    }

    private static boolean takesValue(String opt) {
        if (opt.contains("=")) return false;
        if (VALUE_OPTIONS.contains(opt)) return true;
        return opt.startsWith("--") && (opt.endsWith("-file") || opt.endsWith("-url")
                || opt.endsWith("-timeout") || opt.endsWith("-time") || opt.endsWith("-type"));
    }

    private static void parseItem(String item, Parsed p) {
        int pos;
        if ((pos = item.indexOf("==")) > 0) {
            p.query.add(new String[]{item.substring(0, pos), item.substring(pos + 2)});
        } else if ((pos = item.indexOf(":=")) > 0) {
            p.json.put(item.substring(0, pos), new RawJson(item.substring(pos + 2)));
        } else if ((pos = item.indexOf('=')) > 0) {
            if (p.formMode) {
                p.forms.add(item);
            } else {
                p.json.put(item.substring(0, pos), item.substring(pos + 1));
            }
        } else if ((pos = item.indexOf(':')) > 0) {
            p.headers.add(item);
        } else if (item.endsWith(";") && item.length() > 1) {
            p.headers.add(item);
        } else {
            p.extra.add(item);
        }
    }

    private static List<String> buildCurl(Parsed p) {
        List<String> c = new ArrayList<>();
        c.add("curl");
        c.addAll(p.prefix);
        if (p.pretty) c.add("-v");
        if (p.method != null) {
            c.add("-X");
            c.add(p.method);
        }
        for (String h : p.headers) {
            c.add("-H");
            c.add(h);
        }
        for (String f : p.forms) {
            c.add("-F");
            c.add(f);
        }
        if (!p.json.isEmpty()) {
            c.add("-d");
            c.add(toJson(p.json));
        }
        c.addAll(p.extra);
        if (p.url != null) c.add(commandUrl(p.url, p.query));
        c.add("-s");
        c.add("-S");
        if (p.json.isEmpty() && p.forms.isEmpty()) {
            c.add("-d@-");
        }
        if (!p.formMode) {
            c.add("-H");
            c.add("Content-Type: application/json");
        }
        c.add("-H");
        c.add("Accept: application/json, */*");
        return c;
    }

    private static String commandUrl(String url, List<String[]> query) {
        if (query.isEmpty()) return url;
        StringBuilder b = new StringBuilder(url);
        b.append(url.contains("?") ? "&" : "?");
        for (int i = 0; i < query.size(); i++) {
            if (i > 0) b.append('&');
            b.append(query.get(i)[0]).append('=').append(query.get(i)[1]);
        }
        return b.toString();
    }

    private static String displayUrl(String url, List<String[]> query) {
        return "http://" + commandUrl(url, query);
    }

    private static String toJson(TreeMap<String, Object> map) {
        StringBuilder b = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (!first) b.append(',');
            first = false;
            b.append(jsonString(e.getKey())).append(':');
            Object v = e.getValue();
            if (v instanceof RawJson) b.append(normalizeRaw(((RawJson) v).value));
            else b.append(jsonString(String.valueOf(v)));
        }
        return b.append('}').toString();
    }

    private static String normalizeRaw(String s) {
        String t = s.trim();
        if (t.equals("true") || t.equals("false") || t.equals("null")) return t;
        if (t.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?")) return t;
        if ((t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"))) return t;
        return "null";
    }

    private static String jsonString(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\b': b.append("\\b"); break;
                case '\f': b.append("\\f"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch));
                    else b.append(ch);
            }
        }
        return b.append('"').toString();
    }

    private static String shellLine(List<String> args) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < args.size(); i++) {
            if (i > 0) b.append(' ');
            String a = args.get(i);
            if (i == 0 || !a.matches(".*\\s.*")) b.append(a);
            else b.append('"').append(a.replace("\\", "\\\\").replace("\"", "\\\"")).append('"');
        }
        return b.toString();
    }

    private static int runCurl(List<String> cmd, boolean pretty) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        if (!pretty) {
            pb.inheritIO();
            return pb.start().waitFor();
        }
        Process p = pb.start();
        Thread err = new Thread(() -> copy(p.getErrorStream(), System.err));
        err.start();
        byte[] out = p.getInputStream().readAllBytes();
        int code = p.waitFor();
        err.join();
        String s = new String(out, StandardCharsets.UTF_8);
        System.out.print(prettyJson(s));
        return code;
    }

    private static void copy(InputStream in, PrintStream out) {
        try {
            in.transferTo(out);
        } catch (IOException ignored) {
        }
    }

    private static void runPassthrough(List<String> cmd) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.inheritIO();
        System.exit(pb.start().waitFor());
    }

    private static String prettyJson(String s) {
        String t = s.trim();
        if (!(t.startsWith("{") || t.startsWith("["))) return s;
        StringBuilder b = new StringBuilder();
        int indent = 0;
        boolean inStr = false, esc = false;
        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            if (inStr) {
                b.append(ch);
                if (esc) esc = false;
                else if (ch == '\\') esc = true;
                else if (ch == '"') inStr = false;
                continue;
            }
            switch (ch) {
                case '"': inStr = true; b.append(ch); break;
                case '{': case '[':
                    b.append(ch).append('\n'); indent++; spaces(b, indent); break;
                case '}': case ']':
                    b.append('\n'); indent--; spaces(b, indent); b.append(ch); break;
                case ',':
                    b.append(ch).append('\n'); spaces(b, indent); break;
                case ':':
                    b.append(": "); break;
                default:
                    if (!Character.isWhitespace(ch)) b.append(ch);
            }
        }
        if (!s.endsWith("\n")) b.append('\n');
        return b.toString();
    }

    private static void spaces(StringBuilder b, int n) {
        for (int i = 0; i < n; i++) b.append("  ");
    }

    private static class Parsed {
        boolean printCurl, pretty, formMode;
        String method, url;
        List<String> prefix = new ArrayList<>();
        List<String> headers = new ArrayList<>();
        List<String> forms = new ArrayList<>();
        List<String> extra = new ArrayList<>();
        List<String[]> query = new ArrayList<>();
        TreeMap<String, Object> json = new TreeMap<>();
    }

    private static class RawJson {
        final String value;
        RawJson(String value) { this.value = value; }
    }
}
