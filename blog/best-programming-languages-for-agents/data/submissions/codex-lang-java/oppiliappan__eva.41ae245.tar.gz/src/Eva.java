import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Eva {
    static class Options {
        int fix = 10;
        int base = 10;
        String angle = "degree";
        String input = null;
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.US);
        Options opt;
        try {
            opt = parseArgs(args);
        } catch (ArgError e) {
            System.err.print(e.getMessage());
            System.exit(2);
            return;
        }
        if (opt == null) return;

        if (opt.input != null) {
            runOne(opt, opt.input, 0.0);
            return;
        }

        System.out.println("No previous history.");
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line;
        double previous = 0.0;
        while ((line = br.readLine()) != null) {
            if (line.trim().equals("quit") || line.trim().equals("exit")) break;
            try {
                double v = new Parser(line, opt, previous).parse();
                previous = v;
                System.out.println(format(v, opt));
            } catch (EvaError e) {
                System.out.println(e.getMessage());
            }
        }
    }

    static void runOne(Options opt, String input, double previous) {
        try {
            double v = new Parser(input, opt, previous).parse();
            System.out.println(format(v, opt));
        } catch (EvaError e) {
            System.out.println(e.getMessage());
            System.exit(1);
        }
    }

    static Options parseArgs(String[] args) throws ArgError {
        Options opt = new Options();
        boolean positional = false;
        List<String> rest = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (positional) {
                rest.add(a);
            } else if (a.equals("--")) {
                positional = true;
            } else if (a.equals("-h") || a.equals("--help")) {
                printHelp();
                return null;
            } else if (a.equals("-V") || a.equals("--version")) {
                System.out.println("eva 0.3.1");
                return null;
            } else if (a.equals("-f") || a.equals("--fix")) {
                if (++i >= args.length) throw new ArgError("error: a value is required for '" + a + " <FIX>' but none was supplied\n\nFor more information, try '--help'.\n");
                opt.fix = parseRange(args[i], "fix", "FIX", 1, 64);
            } else if (a.equals("-b") || a.equals("--base")) {
                if (++i >= args.length) throw new ArgError("error: a value is required for '" + a + " <RADIX>' but none was supplied\n\nFor more information, try '--help'.\n");
                opt.base = parseRange(args[i], "base", "RADIX", 1, 36);
            } else if (a.equals("-a") || a.equals("--angle_unit")) {
                if (++i >= args.length) throw new ArgError("error: a value is required for '" + a + " <angle_unit>' but none was supplied\n\nFor more information, try '--help'.\n");
                opt.angle = args[i];
                if (!opt.angle.equals("degree") && !opt.angle.equals("radian") && !opt.angle.equals("gradian")) {
                    throw new ArgError("error: invalid value '" + opt.angle + "' for '--angle_unit <angle_unit>'\n  [possible values: degree, radian, gradian]\n\nFor more information, try '--help'.\n");
                }
            } else if (a.equals("-r") || a.equals("--radian")) {
                opt.angle = "radian";
            } else if (a.startsWith("-")) {
                throw new ArgError("error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.\n");
            } else {
                rest.add(a);
            }
        }
        if (!rest.isEmpty()) opt.input = String.join(" ", rest);
        return opt;
    }

    static int parseRange(String s, String flag, String meta, int lo, int hi) throws ArgError {
        int v;
        try { v = Integer.parseInt(s); } catch (NumberFormatException e) {
            throw new ArgError("error: invalid value '" + s + "' for '--" + flag + " <" + meta + ">'\n\nFor more information, try '--help'.\n");
        }
        if (v < lo || v > hi) throw new ArgError("error: invalid value '" + s + "' for '--" + flag + " <" + meta + ">': " + s + " is not in " + lo + "..=" + hi + "\n\nFor more information, try '--help'.\n");
        return v;
    }

    static void printHelp() {
        System.out.println("Calculator REPL similar to bc(1)\n");
        System.out.println("Usage: executable [OPTIONS] [INPUT]\n");
        System.out.println("Arguments:");
        System.out.println("  [INPUT]  Optional expression string to run eva in command mode\n");
        System.out.println("Options:");
        System.out.println("  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]");
        System.out.println("  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]");
        System.out.println("  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]");
        System.out.println("  -h, --help                     Print help");
        System.out.println("  -V, --version                  Print version");
    }

    static String format(double v, Options opt) {
        if (Double.isNaN(v)) throw new EvaError("Domain Error: Out of bounds!");
        if (Double.isInfinite(v)) throw new EvaError("Math Error: Divide by zero error!");
        if (opt.base == 10) {
            BigDecimal bd = BigDecimal.valueOf(v).setScale(opt.fix, RoundingMode.HALF_UP);
            String s = bd.toPlainString();
            boolean neg = s.startsWith("-");
            if (neg) s = s.substring(1);
            int dot = s.indexOf('.');
            String whole = dot >= 0 ? s.substring(0, dot) : s;
            String frac = dot >= 0 ? s.substring(dot) : "";
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < whole.length(); i++) {
                if (i > 0 && (whole.length() - i) % 3 == 0) out.append(',');
                out.append(whole.charAt(i));
            }
            return (neg ? "-" : "") + out + frac;
        }
        return formatBase(v, opt.base, opt.fix);
    }

    static String formatBase(double v, int base, int fix) {
        boolean neg = v < 0;
        v = Math.abs(v);
        long whole = (long)Math.floor(v);
        double frac = v - whole;
        String digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder w = new StringBuilder();
        if (whole == 0) w.append('0');
        while (whole > 0) {
            w.append(digits.charAt((int)(whole % base)));
            whole /= base;
        }
        w.reverse();
        StringBuilder f = new StringBuilder();
        int max = fix;
        for (int i = 0; i < max; i++) {
            frac *= base;
            int d = (int)Math.floor(frac + 1e-12);
            f.append(digits.charAt(Math.max(0, Math.min(d, base - 1))));
            frac -= d;
        }
        while (f.length() > 1 && f.charAt(f.length() - 1) == '0') f.setLength(f.length() - 1);
        String grouped = group4(w.toString());
        return (neg ? "-" : "") + grouped + "." + f;
    }

    static String group4(String s) {
        List<String> parts = new ArrayList<>();
        for (int end = s.length(); end > 0; end -= 3) {
            int start = Math.max(0, end - 3);
            parts.add(0, s.substring(start, end));
        }
        while (parts.size() < 4) parts.add(0, "");
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) out.append(',');
            String p = parts.get(i);
            int width = (i == 0) ? 1 : 3;
            for (int j = p.length(); j < width; j++) out.append(' ');
            out.append(p);
        }
        return out.toString();
    }

    static class ArgError extends Exception { ArgError(String m) { super(m); } }
    static class EvaError extends RuntimeException { EvaError(String m) { super(m); } }

    enum Type { NUM, NAME, OP, LP, RP, COMMA, END }
    static class Tok {
        Type t; String s; double n;
        Tok(Type t, String s) { this.t = t; this.s = s; }
        Tok(double n) { this.t = Type.NUM; this.n = n; this.s = ""; }
    }

    static class Lexer {
        String in; int p;
        Lexer(String in) { this.in = in; }
        Tok next() {
            while (p < in.length() && Character.isWhitespace(in.charAt(p))) p++;
            if (p >= in.length()) return new Tok(Type.END, "");
            char c = in.charAt(p);
            if (Character.isDigit(c) || c == '.') {
                int st = p++;
                while (p < in.length() && (Character.isDigit(in.charAt(p)) || in.charAt(p) == '.')) p++;
                return new Tok(Double.parseDouble(in.substring(st, p)));
            }
            if (Character.isLetter(c) || c == '_') {
                int st = p++;
                while (p < in.length() && (Character.isLetterOrDigit(in.charAt(p)) || in.charAt(p) == '_')) p++;
                return new Tok(Type.NAME, in.substring(st, p));
            }
            p++;
            if (c == '(') return new Tok(Type.LP, "(");
            if (c == ')') return new Tok(Type.RP, ")");
            if (c == ',') return new Tok(Type.COMMA, ",");
            if ("+-*/^".indexOf(c) >= 0) {
                if (c == '*' && p < in.length() && in.charAt(p) == '*') { p++; return new Tok(Type.OP, "**"); }
                return new Tok(Type.OP, String.valueOf(c));
            }
            return new Tok(Type.OP, String.valueOf(c));
        }
    }

    static class Parser {
        Lexer lex; Tok cur; Options opt; double previous;
        String source;
        Parser(String s, Options opt, double previous) {
            this.source = s;
            this.lex = new Lexer(joinSplitNumbers(s));
            this.opt = opt;
            this.previous = previous;
            this.cur = lex.next();
        }
        static String joinSplitNumbers(String s) {
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (Character.isWhitespace(c)) {
                    int j = i + 1;
                    while (j < s.length() && Character.isWhitespace(s.charAt(j))) j++;
                    if (b.length() > 0 && j < s.length()) {
                        char prev = b.charAt(b.length() - 1), next = s.charAt(j);
                        if ((Character.isDigit(prev) || prev == '.') && (Character.isDigit(next) || next == '.')) continue;
                    }
                }
                b.append(c);
            }
            return b.toString();
        }
        double parse() {
            if (source.matches(".*\\b(pi|e)\\s+(pi|e)\\b.*")) throw new EvaError("Parser Error: Too many operators, too few operands");
            double v = expr(0);
            if (cur.t == Type.COMMA || cur.t == Type.RP) throw new EvaError("Syntax Error: Mismatched parentheses!");
            if (cur.t != Type.END) {
                if (startsPrimary(cur)) v *= expr(0);
                else throw new EvaError("Parser Error: Too many operators, too few operands");
            }
            return checked(v);
        }
        void eat() { cur = lex.next(); }
        boolean startsPrimary(Tok t) { return t.t == Type.NUM || t.t == Type.NAME || t.t == Type.LP; }
        int prec(String op) {
            if (op.equals("+") || op.equals("-")) return 1;
            if (op.equals("*") || op.equals("/")) return 2;
            if (op.equals("^") || op.equals("**")) return 4;
            return -1;
        }
        double expr(int min) {
            double left = unary();
            while (true) {
                if (startsPrimary(cur)) {
                    if (cur.t == Type.NAME && !isConst(cur.s) && !cur.s.equals("_")) break;
                    double r = expr(3);
                    left = checked(left * r);
                    continue;
                }
                if (cur.t != Type.OP) break;
                String op = cur.s;
                int p = prec(op);
                if (p < min) break;
                eat();
                double right = expr(op.equals("^") || op.equals("**") ? p : p + 1);
                switch (op) {
                    case "+": left += right; break;
                    case "-": left -= right; break;
                    case "*": left *= right; break;
                    case "/":
                        if (right == 0.0) throw new EvaError("Math Error: Divide by zero error!");
                        left /= right; break;
                    case "^": case "**": left = Math.pow(left, right); break;
                }
                left = checked(left);
            }
            return left;
        }
        double unary() {
            if (cur.t == Type.OP && (cur.s.equals("+") || cur.s.equals("-"))) {
                String op = cur.s; eat();
                double v = unary();
                return op.equals("-") ? -v : v;
            }
            return primary();
        }
        double primary() {
            if (cur.t == Type.NUM) { double v = cur.n; eat(); return v; }
            if (cur.t == Type.LP) {
                eat();
                double v = expr(0);
                if (cur.t == Type.RP) eat();
                return v;
            }
            if (cur.t == Type.NAME) {
                String name = cur.s;
                eat();
                if (cur.t == Type.LP) return call(name);
                if (name.equals("pi")) return Math.PI;
                if (name.equals("e")) return Math.E;
                if (name.equals("_")) return previous;
                throw new EvaError("Syntax Error: Unknown function '" + name + "'");
            }
            throw new EvaError("Parser Error: Too many operators, too few operands");
        }
        double call(String name) {
            eat();
            List<Double> args = new ArrayList<>();
            if (cur.t != Type.RP && cur.t != Type.END) {
                args.add(expr(0));
                while (cur.t == Type.COMMA) {
                    eat();
                    args.add(expr(0));
                }
            }
            if (cur.t == Type.RP) eat();
            if (!known(name)) throw new EvaError("Syntax Error: Unknown function '" + name + "'");
            int need = (name.equals("log") || name.equals("nroot")) ? 2 : 1;
            if (args.size() < need) throw new EvaError("Parser Error: To few arguments for function, need " + need);
            if (args.size() > need) throw new EvaError("Parser Error: Too many operators, too few operands");
            return checked(apply(name, args));
        }
        boolean isConst(String s) { return s.equals("pi") || s.equals("e"); }
        boolean known(String s) {
            return List.of("sin","cos","tan","csc","sec","cot","sinh","cosh","tanh","asin","acos","atan","acsc","asec","acot","ln","log2","log10","sqrt","ceil","floor","abs","log","nroot").contains(s);
        }
        double angleIn(double x) {
            if (opt.angle.equals("radian")) return x;
            return Math.toRadians(x);
        }
        double apply(String n, List<Double> a) {
            double x = a.get(0);
            switch (n) {
                case "sin": return Math.sin(angleIn(x));
                case "cos": return Math.cos(angleIn(x));
                case "tan": return Math.tan(angleIn(x));
                case "csc": return 1.0 / Math.sin(angleIn(x));
                case "sec": return 1.0 / Math.cos(angleIn(x));
                case "cot": return 1.0 / Math.tan(angleIn(x));
                case "sinh": return Math.sinh(x);
                case "cosh": return Math.cosh(x);
                case "tanh": return Math.tanh(x);
                case "asin": return Math.asin(x);
                case "acos": return Math.acos(x);
                case "atan": return Math.atan(x);
                case "acsc": return Math.asin(1.0 / x);
                case "asec": return Math.acos(1.0 / x);
                case "acot": return Math.atan(1.0 / x);
                case "ln": return Math.log(x);
                case "log2": return Math.log(x) / Math.log(2);
                case "log10": return Math.log10(x);
                case "sqrt": return Math.sqrt(x);
                case "ceil": return Math.ceil(x);
                case "floor": return Math.floor(x);
                case "abs": return Math.abs(x);
                case "log": return Math.log(x) / Math.log(a.get(1));
                case "nroot": return Math.pow(x, 1.0 / a.get(1));
            }
            throw new EvaError("Syntax Error: Unknown function '" + n + "'");
        }
        double checked(double v) {
            if (Double.isNaN(v)) throw new EvaError("Domain Error: Out of bounds!");
            if (Double.isInfinite(v)) throw new EvaError("Math Error: Divide by zero error!");
            return v;
        }
    }
}
