import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Loop {
    static class Opts {
        boolean help, version, stdin, onlyLast, summary, errorDuration;
        boolean untilChanges, untilSame, untilFail, untilSuccess;
        long countBy = 1, offset = 0;
        Long num = null, durationNs = null;
        long everyNs = 1000;
        String forList, untilContains, untilMatch;
        Integer untilError;
        Instant untilTime;
        List<String> input = new ArrayList<>();
    }
    static class RunResult { String out; int code; RunResult(String o,int c){out=o;code=c;} }

    public static void main(String[] args) throws Exception {
        Opts o;
        try { o = parse(args); } catch (IllegalArgumentException e) { System.err.println(e.getMessage()); System.exit(1); return; }
        if (o.help) { printHelp(); return; }
        if (o.version) { System.out.println("loop 0.6.1"); return; }
        if (o.input.isEmpty()) { System.out.println("No command supplied, exiting."); return; }

        List<String> items = new ArrayList<>();
        if (o.stdin) {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
            String line; while ((line = br.readLine()) != null) items.add(line);
            if (o.num == null) o.num = (long) items.size();
        }
        if (o.forList != null) {
            if (!o.forList.isEmpty()) items.addAll(Arrays.asList(o.forList.split(",", -1)));
            if (o.num == null) o.num = (long) items.size();
        }
        String command = String.join(" ", o.input);
        long start = System.nanoTime();
        long runs = 0, ok = 0, fail = 0;
        String lastOut = "", previous = null;
        Pattern match = null;
        if (o.untilMatch != null) {
            try { match = Pattern.compile(o.untilMatch); } catch (PatternSyntaxException e) { match = Pattern.compile(Pattern.quote(o.untilMatch)); }
        }
        boolean durationExpired = false;
        while (true) {
            if (o.num != null && runs >= o.num) break;
            if (o.untilTime != null && Instant.now().compareTo(o.untilTime) >= 0) break;
            if (o.durationNs != null && runs > 0 && System.nanoTime() - start >= o.durationNs) { durationExpired = true; break; }
            if ((o.stdin || o.forList != null) && o.num == null && runs >= items.size()) break;

            long count = o.offset + runs * o.countBy;
            String item = "";
            if (!items.isEmpty()) item = items.get((int)Math.min(runs, items.size() - 1));
            RunResult rr = run(command, count, item);
            runs++;
            if (rr.code == 0) ok++; else fail++;
            lastOut = rr.out;
            if (!o.onlyLast) printRaw(rr.out);

            boolean stop = false;
            if (o.untilSuccess && rr.code == 0) stop = true;
            if (o.untilFail && rr.code != 0) stop = true;
            if (o.untilError != null && rr.code == o.untilError) stop = true;
            if (o.untilContains != null && rr.out.contains(o.untilContains)) stop = true;
            if (match != null && match.matcher(rr.out).find()) stop = true;
            if (o.untilChanges && previous != null && !previous.equals(rr.out)) stop = true;
            if (o.untilSame && previous != null && previous.equals(rr.out)) stop = true;
            previous = rr.out;
            if (stop) break;
            if (o.durationNs != null && System.nanoTime() - start >= o.durationNs) { durationExpired = true; break; }
            if (o.everyNs > 0) sleepNs(o.everyNs);
        }
        if (o.onlyLast) printRaw(lastOut);
        if (o.summary) {
            System.out.println("Total runs:\t" + runs);
            System.out.println("Successes:\t" + ok);
            System.out.println("Failures:\t" + fail);
        }
        if (durationExpired && o.errorDuration) System.exit(124);
    }

    static RunResult run(String cmd, long count, String item) throws Exception {
        ProcessBuilder pb = new ProcessBuilder("sh", "-c", cmd);
        Map<String,String> env = pb.environment();
        env.put("COUNT", Long.toString(count));
        env.put("ITEM", item == null ? "" : item);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (InputStream is = p.getInputStream()) { is.transferTo(baos); }
        int code = p.waitFor();
        return new RunResult(baos.toString(StandardCharsets.UTF_8), code);
    }

    static void printRaw(String s) throws IOException { System.out.print(s); System.out.flush(); }
    static void sleepNs(long ns) throws InterruptedException {
        if (ns <= 0) return;
        long ms = ns / 1_000_000L; int nanos = (int)(ns % 1_000_000L);
        Thread.sleep(ms, nanos);
    }

    static Opts parse(String[] args) {
        Opts o = new Opts();
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            if (a.equals("--")) { for (int j=i+1;j<args.length;j++) o.input.add(args[j]); break; }
            switch (a) {
                case "-h": case "--help": o.help=true; break;
                case "-V": case "--version": o.version=true; break;
                case "-i": case "--stdin": o.stdin=true; break;
                case "-l": case "--only-last": o.onlyLast=true; break;
                case "--summary": o.summary=true; break;
                case "-D": case "--error-duration": o.errorDuration=true; break;
                case "-C": case "--until-changes": o.untilChanges=true; break;
                case "-S": case "--until-same": o.untilSame=true; break;
                case "-f": case "--until-fail": o.untilFail=true; break;
                case "-s": case "--until-success": o.untilSuccess=true; break;
                case "-b": case "--count-by": o.countBy=Long.parseLong(next(args, ++i, a)); break;
                case "-o": case "--offset": o.offset=Long.parseLong(next(args, ++i, a)); break;
                case "-n": case "--num": o.num=Long.parseLong(next(args, ++i, a)); break;
                case "-e": case "--every": o.everyNs=parseDuration(next(args, ++i, a)); break;
                case "-d": case "--for-duration": o.durationNs=parseDuration(next(args, ++i, a)); break;
                case "--for": o.forList=next(args, ++i, a); break;
                case "-c": case "--until-contains": o.untilContains=next(args, ++i, a); break;
                case "-m": case "--until-match": o.untilMatch=next(args, ++i, a); break;
                case "-r": case "--until-error": o.untilError=Integer.parseInt(next(args, ++i, a)); break;
                case "-t": case "--until-time": o.untilTime=parseTime(next(args, ++i, a)); break;
                default:
                    if (a.startsWith("--for=")) o.forList=a.substring(6);
                    else if (a.startsWith("--")) throw new IllegalArgumentException("error: Found argument '"+a+"' which wasn't expected");
                    else { for (int j=i;j<args.length;j++) o.input.add(args[j]); i=args.length; }
            }
        }
        return o;
    }
    static String next(String[] args, int i, String opt) { if (i>=args.length) throw new IllegalArgumentException("error: The argument '"+opt+"' requires a value but none was supplied"); return args[i]; }

    static long parseDuration(String s) {
        long total = 0; int i = 0;
        while (i < s.length()) {
            int st = i; while (i<s.length() && Character.isDigit(s.charAt(i))) i++;
            if (st == i) throw new IllegalArgumentException("invalid duration: " + s);
            long n = Long.parseLong(s.substring(st,i));
            String unit;
            if (s.startsWith("ms", i)) { unit="ms"; i+=2; }
            else if (s.startsWith("us", i) || s.startsWith("µs", i)) { unit="us"; i+=2; }
            else if (i<s.length()) { unit=String.valueOf(s.charAt(i++)); }
            else unit="s";
            switch(unit) {
                case "h": total += n*3_600_000_000_000L; break;
                case "m": total += n*60_000_000_000L; break;
                case "s": total += n*1_000_000_000L; break;
                case "ms": total += n*1_000_000L; break;
                case "us": total += n*1_000L; break;
                default: throw new IllegalArgumentException("invalid duration: " + s);
            }
        }
        return total;
    }
    static Instant parseTime(String s) {
        try { return Instant.parse(s); } catch(Exception ignored) {}
        try { return LocalDateTime.parse(s, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).toInstant(ZoneOffset.UTC); } catch(Exception ignored) {}
        try { return LocalDate.parse(s).atStartOfDay().toInstant(ZoneOffset.UTC); } catch(Exception ignored) {}
        throw new IllegalArgumentException("invalid time: " + s);
    }

    static void printHelp() {
        System.out.println("loop 0.6.1");
        System.out.println("Rich Jones <miserlou@gmail.com>");
        System.out.println("UNIX's missing `loop` command\n");
        System.out.println("USAGE:");
        System.out.println("    executable [FLAGS] [OPTIONS] [input]...\n");
        System.out.println("FLAGS:");
        System.out.println("    -D, --error-duration    Exit with timeout error code on duration");
        System.out.println("    -h, --help              Prints help information");
        System.out.println("    -l, --only-last         Only print the output of the last execution of the command");
        System.out.println("    -i, --stdin             Read from standard input");
        System.out.println("        --summary           Provide a summary");
        System.out.println("    -C, --until-changes     Keep going until the output changes");
        System.out.println("    -f, --until-fail        Keep going until the command exit status is non-zero");
        System.out.println("    -S, --until-same        Keep going until the output changes");
        System.out.println("    -s, --until-success     Keep going until the command exit status is zero");
        System.out.println("    -V, --version           Prints version information\n");
        System.out.println("OPTIONS:");
        System.out.println("    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]");
        System.out.println("    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]");
        System.out.println("        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue");
        System.out.println("    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)");
        System.out.println("    -n, --num <num>                          Number of iterations to execute");
        System.out.println("    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]");
        System.out.println("    -c, --until-contains <until_contains>    Keep going until the output contains this string");
        System.out.println("    -r, --until-error <until_error>          Keep going until the command exit status is the value given");
        System.out.println("    -m, --until-match <until_match>          Keep going until the output matches this regular expression");
        System.out.println("    -t, --until-time <until_time>            Keep going until a future time, ex. \"2018-04-20 04:20:00\" (Times in UTC.)\n");
        System.out.println("ARGS:");
        System.out.println("    <input>...    The command to be looped");
    }
}
