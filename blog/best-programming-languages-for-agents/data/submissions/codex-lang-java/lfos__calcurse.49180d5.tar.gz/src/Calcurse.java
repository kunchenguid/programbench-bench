import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.*;

public class Calcurse {
    static final DateTimeFormatter FILE_DATE = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    static final DateTimeFormatter OUT_DATE = DateTimeFormatter.ofPattern("MM/dd/yy");
    static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    static Path dataDir, confDir, calFile;
    static int inputFmt = 1;
    static String outputFmt = "%D";
    static boolean quiet = false, dumpImported = false, exportUid = false;
    static String op = null, exportFormat = "ical";
    static String fromArg = null, toArg = null, daysArg = null, dayArg = null;
    static Integer todoPriority = null, limit = null;
    static String search = null;
    static String filterType = null, filterPattern = null, filterPriority = null, filterHash = null;
    static boolean filterCompleted = false, filterUncompleted = false, filterInvert = false;
    static String fmtApt = null, fmtEvent = null, fmtTodo = null, fmtRecurApt = null, fmtRecurEvent = null;

    static class Item {
        String raw, type, text = "", note = null, recur = null;
        LocalDate date, endDate, until;
        LocalTime start, end;
        int durationSec = 0, priority = 0;
        boolean completed = false, important = false;
    }

    public static void main(String[] args) {
        try {
            initDefaults();
            parseArgs(args);
            loadConf();
            if (op == null) op = "interactive";
            switch (op) {
                case "help": help(); return;
                case "version": version(); return;
                case "status": System.out.println("calcurse is not running"); return;
                case "gc": gc(); return;
                case "daemon": return;
                case "import": doImport(dayArg); return;
                case "export": doExport(loadItems()); return;
                case "grep": doGrep(loadItems(), false); return;
                case "purge": doPurge(loadItems()); return;
                case "next": doNext(loadItems()); return;
                case "query": doQuery(loadItems()); return;
                case "interactive": return;
                default: usageErr("invalid argument combination");
            }
        } catch (BadUsage e) {
            System.err.println(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static void initDefaults() {
        String home = System.getenv().getOrDefault("HOME", ".");
        Path old = Paths.get(home, ".calcurse");
        if (Files.isDirectory(old)) {
            dataDir = old; confDir = old;
        } else {
            dataDir = Paths.get(System.getenv().getOrDefault("XDG_DATA_HOME", Paths.get(home, ".local", "share").toString()), "calcurse");
            confDir = Paths.get(System.getenv().getOrDefault("XDG_CONFIG_HOME", Paths.get(home, ".config").toString()), "calcurse");
        }
        calFile = dataDir.resolve("apts");
    }

    static void parseArgs(String[] args) {
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("--help")) op = "help";
            else if (a.equals("-v") || a.equals("--version")) op = "version";
            else if (a.equals("--status")) op = "status";
            else if (a.equals("--daemon")) op = "daemon";
            else if (a.equals("-g") || a.equals("--gc")) op = "gc";
            else if (a.equals("-Q") || a.equals("--query")) op = "query";
            else if (a.equals("-G") || a.equals("--grep")) op = "grep";
            else if (a.equals("-P") || a.equals("--purge") || a.equals("-F") || a.equals("--filter")) op = "purge";
            else if (a.equals("-a") || a.equals("--appointment")) { op = "query"; filterType = "cal"; fromArg = "today"; daysArg = "1"; }
            else if (a.equals("-n") || a.equals("--next")) op = "next";
            else if (a.equals("-q") || a.equals("--quiet") || a.equals("--read-only")) quiet = true;
            else if (a.equals("--dump-imported")) dumpImported = true;
            else if (a.equals("--export-uid")) exportUid = true;
            else if (a.equals("-D") || a.equals("--datadir")) { dataDir = Paths.get(need(args, ++i, a)); calFile = dataDir.resolve("apts"); }
            else if (a.equals("-C") || a.equals("--confdir")) confDir = Paths.get(need(args, ++i, a));
            else if (a.equals("-c") || a.equals("--calendar")) calFile = Paths.get(need(args, ++i, a));
            else if (a.equals("-i") || a.equals("--import")) { op = "import"; dayArg = need(args, ++i, a); }
            else if (a.equals("-x") || a.equals("--export")) { op = "export"; }
            else if (a.startsWith("-x") && a.length() > 2) { op = "export"; exportFormat = a.substring(2); }
            else if (a.startsWith("--export=")) { op = "export"; exportFormat = a.substring(9); }
            else if (a.equals("-d") || a.equals("--day")) { op = "query"; filterType = "cal"; dayArg = need(args, ++i, a); handleDay(dayArg); }
            else if (a.startsWith("-d") && a.length() > 2) { op = "query"; filterType = "cal"; handleDay(a.substring(2)); }
            else if (a.equals("-r") || a.equals("--range")) { op = "query"; filterType = "cal"; daysArg = "1"; }
            else if (a.startsWith("-r") && a.length() > 2) { op = "query"; filterType = "cal"; daysArg = a.substring(2); }
            else if (a.startsWith("--range=")) { op = "query"; filterType = "cal"; daysArg = a.substring(8); }
            else if (a.equals("-s") || a.equals("--startday")) { op = "query"; filterType = "cal"; fromArg = "today"; }
            else if (a.startsWith("-s") && a.length() > 2) { op = "query"; filterType = "cal"; fromArg = a.substring(2); }
            else if (a.startsWith("--startday=")) { op = "query"; filterType = "cal"; fromArg = a.substring(11); }
            else if (a.equals("-t") || a.equals("--todo")) { op = "query"; filterType = "todo"; }
            else if (a.startsWith("-t") && a.length() > 2) { op = "query"; filterType = "todo"; todoPriority = parseInt(a.substring(2), 0); }
            else if (a.startsWith("--todo=")) { op = "query"; filterType = "todo"; todoPriority = parseInt(a.substring(7), 0); }
            else if (a.equals("--from")) fromArg = need(args, ++i, a);
            else if (a.equals("--to")) toArg = need(args, ++i, a);
            else if (a.equals("--days")) daysArg = need(args, ++i, a);
            else if (a.equals("-l") || a.equals("--limit")) limit = parseInt(need(args, ++i, a), 0);
            else if (a.equals("-S") || a.equals("--search")) { search = need(args, ++i, a); filterPattern = search; }
            else if (a.startsWith("--search=")) { search = a.substring(9); filterPattern = search; }
            else if (a.startsWith("-S") && a.length() > 2) { search = a.substring(2); filterPattern = search; }
            else if (a.equals("--input-datefmt")) inputFmt = parseInt(need(args, ++i, a), 1);
            else if (a.startsWith("--input-datefmt=")) inputFmt = parseInt(a.substring(16), 1);
            else if (a.equals("--output-datefmt")) outputFmt = need(args, ++i, a);
            else if (a.startsWith("--output-datefmt=")) outputFmt = a.substring(17);
            else if (a.equals("--filter-type")) filterType = need(args, ++i, a);
            else if (a.startsWith("--filter-type=")) filterType = a.substring(14);
            else if (a.equals("--filter-pattern")) filterPattern = need(args, ++i, a);
            else if (a.startsWith("--filter-pattern=")) filterPattern = a.substring(17);
            else if (a.equals("--filter-hash")) filterHash = need(args, ++i, a);
            else if (a.startsWith("--filter-hash=")) filterHash = a.substring(14);
            else if (a.equals("--filter-priority")) filterPriority = need(args, ++i, a);
            else if (a.startsWith("--filter-priority=")) filterPriority = a.substring(18);
            else if (a.equals("--filter-completed")) filterCompleted = true;
            else if (a.equals("--filter-uncompleted")) filterUncompleted = true;
            else if (a.equals("--filter-invert")) filterInvert = true;
            else if (a.startsWith("--filter-")) { if (i + 1 < args.length && !args[i+1].startsWith("--")) i++; }
            else if (a.equals("--format-apt")) fmtApt = need(args, ++i, a);
            else if (a.startsWith("--format-apt=")) fmtApt = a.substring(13);
            else if (a.equals("--format-recur-apt")) fmtRecurApt = need(args, ++i, a);
            else if (a.startsWith("--format-recur-apt=")) fmtRecurApt = a.substring(19);
            else if (a.equals("--format-event")) fmtEvent = need(args, ++i, a);
            else if (a.startsWith("--format-event=")) fmtEvent = a.substring(15);
            else if (a.equals("--format-recur-event")) fmtRecurEvent = need(args, ++i, a);
            else if (a.startsWith("--format-recur-event=")) fmtRecurEvent = a.substring(21);
            else if (a.equals("--format-todo")) fmtTodo = need(args, ++i, a);
            else if (a.startsWith("--format-todo=")) fmtTodo = a.substring(14);
            else if (a.startsWith("-")) throw new BadUsage("./executable: unrecognized option '" + a + "'\n" + shortUsage() + "Try `calcurse -h' for more information.");
            else usageErr("invalid argument combination");
        }
    }

    static void handleDay(String s) {
        if (s.matches("[+-]?\\d+")) daysArg = s;
        else { fromArg = s; daysArg = "1"; }
    }

    static String need(String[] a, int i, String opt) {
        if (i >= a.length) throw new BadUsage(opt + ": option requires an argument");
        return a[i];
    }

    static int parseInt(String s, int d) {
        try { return Integer.parseInt(s); } catch (Exception e) { return d; }
    }

    static void loadConf() {
        Path c = confDir.resolve("conf");
        if (!Files.isRegularFile(c)) return;
        try {
            for (String line : Files.readAllLines(c, StandardCharsets.UTF_8)) {
                int p = line.indexOf('=');
                if (p < 0) p = line.indexOf(' ');
                if (p < 0) continue;
                String k = line.substring(0, p).trim(), v = line.substring(p + 1).trim();
                if (k.equals("format.inputdate")) inputFmt = parseInt(v, inputFmt);
                if (k.equals("format.outputdate")) outputFmt = v;
            }
        } catch (IOException ignored) {}
    }

    static List<Item> loadItems() throws IOException {
        List<Item> out = new ArrayList<>();
        if (Files.isRegularFile(dataDir.resolve("todo"))) {
            List<Item> todos = new ArrayList<>();
            for (String l : Files.readAllLines(dataDir.resolve("todo"), StandardCharsets.UTF_8)) {
                if (!l.isBlank()) parseTodo(l).ifPresent(todos::add);
            }
            todos.sort(Comparator.comparing((Item it) -> it.completed));
            out.addAll(todos);
        }
        if (Files.isRegularFile(calFile)) {
            for (String l : Files.readAllLines(calFile, StandardCharsets.UTF_8)) {
                if (!l.isBlank()) parseCal(l).ifPresent(out::add);
            }
        }
        return out;
    }

    static Optional<Item> parseTodo(String l) {
        Matcher m = Pattern.compile("^\\[(-?)(\\d+)\\](?:>(\\S+))?\\s*(.*)$").matcher(l);
        if (!m.find()) return Optional.empty();
        Item it = new Item(); it.raw = l; it.type = "todo";
        it.completed = "-".equals(m.group(1)); it.priority = parseInt(m.group(2), 0);
        it.note = m.group(3); it.text = m.group(4);
        return Optional.of(it);
    }

    static Optional<Item> parseCal(String l) {
        Item it = new Item(); it.raw = l;
        Matcher apt = Pattern.compile("^(\\d\\d/\\d\\d/\\d{4}) @ (\\d\\d:\\d\\d) -> (\\d\\d/\\d\\d/\\d{4}) @ (\\d\\d:\\d\\d)(!)?(?:>([^ |]+))? ?\\|(.*)$").matcher(l);
        if (apt.find()) {
            it.type = "apt"; it.date = LocalDate.parse(apt.group(1), FILE_DATE); it.start = LocalTime.parse(apt.group(2), TIME);
            it.endDate = LocalDate.parse(apt.group(3), FILE_DATE); it.end = LocalTime.parse(apt.group(4), TIME);
            it.important = apt.group(5) != null; it.note = apt.group(6); it.text = apt.group(7);
            it.durationSec = (int)Duration.between(LocalDateTime.of(it.date, it.start), LocalDateTime.of(it.endDate, it.end)).getSeconds();
            return Optional.of(it);
        }
        Matcher ev = Pattern.compile("^(\\d\\d/\\d\\d/\\d{4}) \\[(\\d+)\\](?: \\{([^}]*)\\})?(?: >([^ ]+))?\\s*(.*)$").matcher(l);
        if (ev.find()) {
            it.type = ev.group(3) == null ? "event" : "recur-event";
            it.date = LocalDate.parse(ev.group(1), FILE_DATE); it.priority = parseInt(ev.group(2), 1);
            it.recur = ev.group(3); it.note = ev.group(4); it.text = ev.group(5);
            if (it.recur != null) {
                Matcher u = Pattern.compile("->\\s*(\\d\\d/\\d\\d/\\d{4})").matcher(it.recur);
                if (u.find()) it.until = LocalDate.parse(u.group(1), FILE_DATE);
            }
            return Optional.of(it);
        }
        return Optional.empty();
    }

    static boolean typeOk(Item it) {
        if (filterType == null) return true;
        Set<String> set = new HashSet<>();
        for (String t : filterType.split(",")) {
            t = t.trim();
            if (t.equals("cal")) { set.addAll(Arrays.asList("event","apt","recur-event","recur-apt")); }
            else if (t.equals("recur")) { set.add("recur-event"); set.add("recur-apt"); }
            else set.add(t);
        }
        return set.contains(it.type);
    }

    static boolean filterOk(Item it) {
        boolean ok = typeOk(it);
        if (ok && filterPattern != null) ok = Pattern.compile(filterPattern).matcher(it.text).find();
        if (ok && filterHash != null) {
            String h = sha1(it.raw);
            ok = filterHash.startsWith("!") ? !h.startsWith(filterHash.substring(1)) : h.startsWith(filterHash);
        }
        if (ok && it.type.equals("todo") && filterPriority != null) ok = it.priority == parseInt(filterPriority, -1);
        if (ok && filterCompleted) ok = it.type.equals("todo") && it.completed;
        if (ok && filterUncompleted) ok = it.type.equals("todo") && !it.completed;
        if (ok && it.type.equals("todo") && "todo".equals(filterType) && todoPriority == null && !filterCompleted) ok = !it.completed;
        if (ok && todoPriority != null && it.type.equals("todo")) ok = todoPriority == 0 ? it.completed : (!it.completed && it.priority == todoPriority);
        return filterInvert ? !ok : ok;
    }

    static void doQuery(List<Item> all) {
        LocalDate[] r = queryRange();
        boolean wantTodo = filterType == null || typeOk(dummy("todo"));
        boolean wantCal = filterType == null || typeOk(dummy("event")) || typeOk(dummy("apt")) || typeOk(dummy("recur-event"));
        int count = 0;
        if (wantTodo) {
            List<Item> todos = new ArrayList<>();
            for (Item it : all) if (it.type.equals("todo") && filterOk(it)) todos.add(it);
            todos.sort(Comparator.comparing((Item it) -> it.completed));
            if (!todos.isEmpty()) {
                System.out.println(todoPriority != null && todoPriority == 0 ? "completed tasks:" : "to do:");
                for (Item it : todos) {
                    if (limit != null && count >= limit) break;
                    System.out.print(format(it, fmtTodo, "%p. %m\\n", false, null, null));
                    count++;
                }
                if (wantCal) System.out.println();
            }
        }
        if (wantCal) {
            boolean printedDay = false;
            for (LocalDate d = r[0]; !d.isAfter(r[1]); d = d.plusDays(1)) {
                List<Item> day = occurrences(all, d);
                day.removeIf(it -> it.type.equals("todo") || !filterOk(it));
                day.sort(Comparator.comparing((Item x) -> x.start == null ? LocalTime.MIN : x.start));
                if (day.isEmpty()) continue;
                if (printedDay) System.out.println();
                System.out.println(formatDate(d) + ":");
                for (Item it : day) {
                    if (limit != null && count >= limit) break;
                    String def = it.type.contains("apt") ? " - %S -> %E\\n\\t%m\\n" : " * %m\\n";
                    String f = it.type.equals("recur-event") ? fmtRecurEvent : it.type.equals("recur-apt") ? fmtRecurApt : it.type.equals("apt") ? fmtApt : fmtEvent;
                    System.out.print(format(it, f, def, false, d, null));
                    count++;
                }
                printedDay = true;
            }
        }
    }

    static Item dummy(String type) { Item i = new Item(); i.type = type; return i; }

    static List<Item> occurrences(List<Item> all, LocalDate d) {
        List<Item> res = new ArrayList<>();
        for (Item it : all) {
            if (it.type.equals("event") && it.date.equals(d)) res.add(it);
            else if (it.type.equals("apt") && !d.isBefore(it.date) && !d.isAfter(it.endDate)) res.add(it);
            else if (it.type.equals("recur-event") && !d.isBefore(it.date) && (it.until == null || !d.isAfter(it.until))) {
                String r = it.recur == null ? "" : it.recur;
                long diff = ChronoUnit.DAYS.between(it.date, d);
                int n = 1;
                Matcher m = Pattern.compile("(\\d+)([DWMY])").matcher(r);
                boolean ok = false;
                if (m.find()) {
                    n = parseInt(m.group(1), 1);
                    switch (m.group(2)) {
                        case "D": ok = diff % n == 0; break;
                        case "W": ok = diff % (7L*n) == 0; break;
                        case "M": ok = it.date.getDayOfMonth() == d.getDayOfMonth() && ChronoUnit.MONTHS.between(it.date.withDayOfMonth(1), d.withDayOfMonth(1)) % n == 0; break;
                        case "Y": ok = it.date.getDayOfYear() == d.getDayOfYear() && (d.getYear() - it.date.getYear()) % n == 0; break;
                    }
                }
                if (ok) res.add(it);
            }
        }
        return res;
    }

    static LocalDate[] queryRange() {
        LocalDate start = fromArg == null ? LocalDate.now() : parseDate(fromArg);
        LocalDate end;
        if (toArg != null) end = parseDate(toArg);
        else if (daysArg != null) {
            int n = parseInt(daysArg, 1);
            if (n < 0) { end = start; start = start.plusDays(n + 1L); }
            else end = start.plusDays(Math.max(1, n) - 1L);
        } else end = start;
        if (end.isBefore(start)) { LocalDate t = start; start = end; end = t; }
        return new LocalDate[]{start, end};
    }

    static LocalDate parseDate(String s) {
        s = s.toLowerCase(Locale.ROOT);
        LocalDate now = LocalDate.now();
        if (s.equals("today") || s.equals("now")) return now;
        if (s.equals("tomorrow")) return now.plusDays(1);
        if (s.equals("yesterday")) return now.minusDays(1);
        String[] wd = {"mon","tue","wed","thu","fri","sat","sun"};
        for (int i=0;i<wd.length;i++) if (s.startsWith(wd[i])) {
            int cur = now.getDayOfWeek().getValue();
            int add = (i + 1 - cur + 7) % 7;
            return now.plusDays(add);
        }
        String date = s.split("\\s+")[0];
        List<DateTimeFormatter> fmts = new ArrayList<>();
        if (inputFmt == 4) fmts.add(DateTimeFormatter.ofPattern("yyyy-M-d"));
        else if (inputFmt == 3) fmts.add(DateTimeFormatter.ofPattern("yyyy/M/d"));
        else if (inputFmt == 2) fmts.add(DateTimeFormatter.ofPattern("d/M/yyyy"));
        else fmts.add(DateTimeFormatter.ofPattern("M/d/yyyy"));
        fmts.add(DateTimeFormatter.ofPattern("yyyy-M-d"));
        fmts.add(DateTimeFormatter.ofPattern("M/d/yyyy"));
        for (DateTimeFormatter f : fmts) try { return LocalDate.parse(date, f); } catch (Exception ignored) {}
        return LocalDate.now();
    }

    static String formatDate(LocalDate d) {
        if ("%D".equals(outputFmt)) return d.format(OUT_DATE);
        String f = outputFmt.replace("%Y", "yyyy").replace("%m", "MM").replace("%d", "dd").replace("%D", "MM/dd/yy");
        try { return d.format(DateTimeFormatter.ofPattern(f)); } catch (Exception e) { return d.format(OUT_DATE); }
    }

    static String format(Item it, String f, String def, boolean grep, LocalDate occ, String forcedRaw) {
        if (f == null) f = grep ? "%(raw)\\n" : def;
        f = unescape(f);
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<f.length();i++) {
            char c = f.charAt(i);
            if (c != '%') { sb.append(c); continue; }
            if (i + 1 >= f.length()) { sb.append('%'); continue; }
            if (f.charAt(i+1) == '(') {
                int e = f.indexOf(')', i+2);
                if (e > 0) { sb.append(ext(it, f.substring(i+2, e), forcedRaw)); i = e; continue; }
            }
            char sp = f.charAt(++i);
            switch (sp) {
                case 'm': sb.append(it.text); break;
                case 'p': sb.append(it.priority); break;
                case 'n': sb.append(it.note == null ? "(null)" : it.note); break;
                case 'N': sb.append(noteText(it)); break;
                case 'S': sb.append(startDisplay(it, occ)); break;
                case 'E': sb.append(endDisplay(it, occ)); break;
                case 's': sb.append(epoch(it.date, it.start)); break;
                case 'e': sb.append(epoch(it.endDate, it.end)); break;
                case 'd': sb.append(it.durationSec); break;
                case 'r': sb.append(remaining(it)); break;
                default: sb.append('%').append(sp);
            }
        }
        return sb.toString();
    }

    static String ext(Item it, String x, String forcedRaw) {
        if (x.equals("raw")) return forcedRaw == null ? it.raw : forcedRaw;
        if (x.equals("hash")) return sha1(forcedRaw == null ? it.raw : forcedRaw);
        if (x.startsWith("duration")) return String.valueOf(it.durationSec);
        if (x.startsWith("remaining")) return remaining(it);
        if (x.startsWith("start")) return String.valueOf(epoch(it.date, it.start));
        if (x.startsWith("end")) return String.valueOf(epoch(it.endDate, it.end));
        return "";
    }

    static String unescape(String s) { return s.replace("\\n", "\n").replace("\\t", "\t"); }
    static long epoch(LocalDate d, LocalTime t) { return d == null || t == null ? 0 : LocalDateTime.of(d,t).atZone(ZoneId.systemDefault()).toEpochSecond(); }
    static String remaining(Item it) {
        if (it.date == null || it.start == null) return "0:00";
        long min = Duration.between(LocalDateTime.now(), LocalDateTime.of(it.date,it.start)).toMinutes();
        if (min < 0) min = 0;
        return (min/60) + ":" + String.format("%02d", min%60);
    }
    static String startDisplay(Item it, LocalDate occ) {
        if (it.start == null) return "";
        if (occ != null && it.date.isBefore(occ)) return "..:..";
        return it.start.format(TIME);
    }
    static String endDisplay(Item it, LocalDate occ) {
        if (it.end == null) return "";
        if (occ != null && it.endDate.isAfter(occ)) return "..:..";
        return it.end.format(TIME);
    }
    static String noteText(Item it) {
        if (it.note == null) return "\tNo note file found\n";
        try { return Files.readString(dataDir.resolve("notes").resolve(it.note)); } catch (Exception e) { return "\tNo note file found\n"; }
    }

    static void doGrep(List<Item> all, boolean imported) {
        List<Item> list = new ArrayList<>(all);
        list.sort(Comparator.comparingInt(Calcurse::grepRank));
        for (Item it : list) {
            if (!filterOk(it)) continue;
            String f = it.type.equals("todo") ? fmtTodo : it.type.equals("apt") ? fmtApt : it.type.equals("recur-apt") ? fmtRecurApt : it.type.equals("recur-event") ? fmtRecurEvent : fmtEvent;
            System.out.print(format(it, f, "%(raw)", true, null, null));
        }
    }

    static int grepRank(Item it) {
        switch (it.type) {
            case "todo": return 0;
            case "recur-event": return 1;
            case "apt": return 2;
            case "recur-apt": return 3;
            case "event": return 4;
            default: return 9;
        }
    }

    static void doPurge(List<Item> all) throws IOException {
        List<String> todos = new ArrayList<>(), cals = new ArrayList<>();
        for (Item it : all) if (!filterOk(it)) { if (it.type.equals("todo")) todos.add(it.raw); else cals.add(it.raw); }
        Files.createDirectories(dataDir);
        Files.write(dataDir.resolve("todo"), todos, StandardCharsets.UTF_8);
        Files.write(calFile, cals, StandardCharsets.UTF_8);
    }

    static void doNext(List<Item> all) {
        LocalDateTime now = LocalDateTime.now(), until = now.plusHours(24);
        Item best = null; LocalDateTime bt = null;
        for (Item it : all) if (it.type.equals("apt")) {
            LocalDateTime st = LocalDateTime.of(it.date, it.start);
            if (!st.isBefore(now) && !st.isAfter(until) && (bt == null || st.isBefore(bt))) { best = it; bt = st; }
        }
        if (best != null) {
            long min = Duration.between(now, bt).toMinutes();
            System.out.printf("%02d:%02d %s%n", min/60, min%60, best.text);
        }
    }

    static void doExport(List<Item> all) {
        if (exportFormat.equals("pcal")) { pcal(all); return; }
        System.out.println("BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN");
        for (Item it : all) if (it.type.equals("event") || it.type.equals("recur-event")) {
            System.out.println("BEGIN:VEVENT");
            if (exportUid) System.out.println("UID:" + sha1(it.raw));
            System.out.println("DTSTART;VALUE=DATE:" + it.date.format(DateTimeFormatter.BASIC_ISO_DATE));
            if (it.until != null) System.out.println("RRULE:FREQ=DAILY;UNTIL=" + it.until.format(DateTimeFormatter.BASIC_ISO_DATE));
            System.out.println("SUMMARY:" + escIcal(it.text));
            System.out.println("END:VEVENT");
        }
        for (Item it : all) if (it.type.equals("apt")) {
            System.out.println("BEGIN:VEVENT");
            if (exportUid) System.out.println("UID:" + sha1(it.raw));
            System.out.println("DTSTART:" + dt(it.date,it.start));
            System.out.println("DURATION:" + dur(it.durationSec));
            System.out.println("SUMMARY:" + escIcal(it.text));
            System.out.println("END:VEVENT");
        }
        for (Item it : all) if (it.type.equals("todo")) {
            System.out.println("BEGIN:VTODO");
            if (exportUid) System.out.println("UID:" + sha1(it.raw));
            System.out.println("PRIORITY:" + it.priority);
            System.out.println("SUMMARY:" + escIcal(it.text));
            if (it.completed) System.out.println("STATUS:COMPLETED");
            System.out.println("END:VTODO");
        }
        System.out.println("END:VCALENDAR");
    }

    static void pcal(List<Item> all) {
        System.out.println("# calcurse pcal export\n\n# =======\n# options\n# =======\nopt -A -K -l -m -F Monday");
        System.out.println("# Display week number (i.e. 1-52) on every Monday\nall monday in all week %w\n");
        System.out.println("\n# =============\n# Recur. Events\n# =============\n# (pcal does not support from..until dates specification\n");
        System.out.println("# ======\n# Events\n# ======\n");
        for (Item it : all) if (it.type.contains("event")) System.out.printf("%s  %s%n", it.date.format(DateTimeFormatter.ofPattern("MM/dd")), it.text);
    }

    static String dt(LocalDate d, LocalTime t) { return d.format(DateTimeFormatter.BASIC_ISO_DATE) + "T" + t.format(DateTimeFormatter.ofPattern("HHmmss")); }
    static String dur(int sec) {
        int d = sec / 86400; sec %= 86400; int h = sec / 3600; sec %= 3600; int m = sec / 60; int s = sec % 60;
        return (d > 0 ? "P" + d + "DT" : "PT") + h + "H" + m + "M" + s + "S";
    }
    static String escIcal(String s) { return s.replace("\\", "\\\\").replace(",", "\\,").replace(";", "\\;").replace("\n", "\\n"); }

    static void doImport(String file) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8);
        Files.createDirectories(dataDir); Files.createDirectories(dataDir.resolve("notes"));
        List<String> apts = Files.isRegularFile(calFile) ? Files.readAllLines(calFile) : new ArrayList<>();
        List<String> todos = Files.isRegularFile(dataDir.resolve("todo")) ? Files.readAllLines(dataDir.resolve("todo")) : new ArrayList<>();
        int ev=0, td=0; List<Item> imported = new ArrayList<>();
        for (int i=0;i<lines.size();i++) {
            String l = lines.get(i);
            if (l.equals("BEGIN:VEVENT") || l.equals("BEGIN:VTODO")) {
                boolean todo = l.endsWith("VTODO");
                Map<String,String> p = new LinkedHashMap<>();
                for (++i;i<lines.size() && !lines.get(i).startsWith("END:");i++) {
                    String x = lines.get(i);
                    int c = x.indexOf(':'); if (c < 0) continue;
                    String k = x.substring(0,c); int semi = k.indexOf(';'); if (semi >= 0) k = k.substring(0, semi);
                    p.put(k, unIcal(x.substring(c+1)));
                }
                if (todo) {
                    int pr = parseInt(p.getOrDefault("PRIORITY","0"), 0);
                    String raw = "[" + pr + "] " + p.getOrDefault("SUMMARY", "");
                    todos.add(raw); parseTodo(raw).ifPresent(imported::add); td++;
                } else {
                    LocalDateTime st = parseIcalDt(p.get("DTSTART"));
                    if (st == null) continue;
                    String summary = p.getOrDefault("SUMMARY", "");
                    String raw;
                    if ((p.containsKey("DTEND") && !p.get("DTSTART").contains("T")) || !p.get("DTSTART").contains("T")) {
                        raw = st.toLocalDate().format(FILE_DATE) + " [1] " + summary;
                    } else {
                        int sec = p.containsKey("DURATION") ? parseDur(p.get("DURATION")) : (int)Duration.between(st, parseIcalDt(p.get("DTEND"))).getSeconds();
                        LocalDateTime en = st.plusSeconds(sec);
                        raw = st.toLocalDate().format(FILE_DATE) + " @ " + st.toLocalTime().format(TIME) + " -> " + en.toLocalDate().format(FILE_DATE) + " @ " + en.toLocalTime().format(TIME) + "|" + summary;
                    }
                    apts.add(raw); parseCal(raw).ifPresent(imported::add); ev++;
                }
            }
        }
        Files.write(calFile, apts, StandardCharsets.UTF_8);
        Files.write(dataDir.resolve("todo"), todos, StandardCharsets.UTF_8);
        if (dumpImported) for (Item it : imported) System.out.print(format(it, it.type.equals("todo") ? fmtTodo : it.type.equals("apt") ? fmtApt : fmtEvent, "%(raw)", true, null, null));
        if (!quiet) System.err.printf("Import process report: %03d lines read%n%d apps / %d events / %d todos / 0 skipped%n", lines.size(), 0, ev, td);
    }

    static String unIcal(String s) { return s.replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\"); }
    static LocalDateTime parseIcalDt(String s) {
        if (s == null) return null;
        try {
            if (s.contains("T")) return LocalDateTime.parse(s.replace("Z",""), DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss"));
            return LocalDate.parse(s, DateTimeFormatter.BASIC_ISO_DATE).atStartOfDay();
        } catch (Exception e) { return null; }
    }
    static int parseDur(String s) {
        Matcher m = Pattern.compile("P(?:(\\d+)D)?T?(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").matcher(s);
        if (!m.matches()) return 0;
        return parseInt(nz(m.group(1)),0)*86400 + parseInt(nz(m.group(2)),0)*3600 + parseInt(nz(m.group(3)),0)*60 + parseInt(nz(m.group(4)),0);
    }
    static String nz(String s) { return s == null ? "0" : s; }

    static void gc() throws IOException {
        Path notes = dataDir.resolve("notes");
        if (!Files.isDirectory(notes)) return;
        Set<String> refs = new HashSet<>();
        for (Item it : loadItems()) if (it.note != null) refs.add(it.note);
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(notes)) {
            for (Path p : ds) if (!refs.contains(p.getFileName().toString())) Files.deleteIfExists(p);
        }
    }

    static String sha1(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] b = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    static void help() { System.out.print(shortUsage() +
        "\nOperations in command line mode:\n" +
        "  -Q, --query   Print items in a given query range\n" +
        "  -G, --grep    Grep items from the data files\n" +
        "  -P, --purge   Read items and write them back\n" +
        "Query short forms:\n-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>\n\n" +
        "Note that filter, format and day-range options affect input or output:\n" +
        "  --filter-*              Filter items loaded by -Q, -G, -P and -x\n" +
        "  --format-*              Rewrite output from -Q, -G and --dump-imported\n" +
        "  --from <date>           Limit day range of -Q.\n  --to <date>             Limit day range of -Q.\n  --days <number>         Limit day range of -Q.\n\n" +
        "  --limit, -l <number>    Limit number of query results\n  --search, -S <regexp>   Match regular expression in queries\nConsult the man page for details.\n\n" +
        "Miscellaneous:\n  -c, --calendar <file>   The calendar data file to use\n  -C, --confdir <dir>     The configuration directory to use\n  --daemon                Run notification daemon in the background\n  -D, --datadir <dir>     The data directory to use\n  -g, --gc                Run the garbage collector\n  -h, --help              Show this help text\n  -i, --import <file>     Import iCal data from file\n  -q, --quiet             Suppress import/export result message\n  --read-only             Do not save configuration or data files\n  --status                Display status of running instances\n  -v, --version           Show version information\n  -x, --export[<format>]  Export to stdout in ical (default) or pcal format\n\n" +
        "For more information, type '?' from within calcurse, or read the manpage.\nSubmit feature requests and suggestions to <misc@calcurse.org>.\nSubmit bug reports to <bugs@calcurse.org>.\n"); }
    static String shortUsage() { return "Usage:\ncalcurse [-D <directory>] [-C <directory>] [-c <calendar file>]\ncalcurse -Q [--from <date>] [--to <date>] [--days <number>]\ncalcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]\ncalcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon\n"; }
    static void version() { System.out.print("calcurse 4.8.2 -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions.\n"); }
    static void usageErr(String s) { throw new BadUsage("args.c: 880: " + s); }
    static class BadUsage extends RuntimeException { BadUsage(String m) { super(m); } }
}
