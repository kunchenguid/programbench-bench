import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Hx {
    private static final String HELP = """
Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
""";

    private static class Options {
        int cols = 10;
        int len = 0;
        char format = 'x';
        int color = envNoColor() ? 0 : 0;
        Character array = null;
        Integer func = null;
        String places = "4";
        boolean prefix = true;
        String inputFile = null;
    }

    public static void main(String[] args) {
        try {
            Options opt = parse(args);
            if (opt == null) {
                return;
            }
            if (opt.func != null) {
                int places = parseInt(opt.places, "-p, --places <integer> expected. ");
                printFunc(opt.func, places);
                return;
            }
            byte[] data = readInput(opt);
            if (opt.array != null) {
                printArray(data, opt);
            } else {
                printDump(data, opt);
            }
        } catch (CliException e) {
            if (!e.message.isEmpty()) {
                System.err.print(e.message);
            }
            System.exit(e.status);
        } catch (IOException e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static boolean envNoColor() {
        String v = System.getenv("NO_COLOR");
        return v != null;
    }

    private static Options parse(String[] args) throws CliException {
        Options opt = new Options();
        List<String> positionals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h", "--help" -> {
                    System.out.print(HELP);
                    return null;
                }
                case "-V", "--version" -> {
                    System.out.println("hx 0.7.0");
                    return null;
                }
                case "-c", "--cols" -> opt.cols = parseInt(nextArg(args, ++i, a), "-c, --cols <integer> expected. ");
                case "-l", "--len" -> opt.len = parseInt(nextArg(args, ++i, a), "-l, --len <integer> expected. ");
                case "-u", "--func" -> opt.func = parseInt(nextArg(args, ++i, a), "-u, --func <integer> expected. ");
                case "-p", "--places" -> opt.places = nextArg(args, ++i, a);
                case "-f", "--format" -> {
                    String v = nextArg(args, ++i, a);
                    if (!(v.equals("o") || v.equals("x") || v.equals("X") || v.equals("b"))) {
                        throw clapInvalid("invalid value '" + v + "' for '--format <format>'\n  [possible values: o, x, X, b]\n");
                    }
                    opt.format = v.charAt(0);
                }
                case "-t", "--color" -> {
                    String v = nextArg(args, ++i, a);
                    if (!(v.equals("0") || v.equals("1"))) {
                        throw clapInvalid("invalid value '" + v + "' for '--color <color>'\n  [possible values: 0, 1]\n");
                    }
                    opt.color = Integer.parseInt(v);
                }
                case "-r", "--prefix" -> {
                    String v = nextArg(args, ++i, a);
                    if (!(v.equals("0") || v.equals("1"))) {
                        throw clapInvalid("invalid value '" + v + "' for '--prefix <prefix>'\n  [possible values: 0, 1]\n");
                    }
                    opt.prefix = v.equals("1");
                }
                case "-a", "--array" -> {
                    String v = nextArg(args, ++i, a);
                    if (v.length() != 1 || "rcgpkjsf".indexOf(v.charAt(0)) < 0) {
                        throw clapInvalid("invalid value '" + v + "' for '--array <array_format>'\n  [possible values: r, c, g, p, k, j, s, f]\n");
                    }
                    opt.array = v.charAt(0);
                }
                default -> {
                    if (a.startsWith("-")) {
                        throw unexpected(a);
                    }
                    positionals.add(a);
                }
            }
        }
        if (!positionals.isEmpty()) {
            opt.inputFile = positionals.get(0);
            if (positionals.size() > 1) {
                throw unexpected(positionals.get(1));
            }
        }
        return opt;
    }

    private static String nextArg(String[] args, int i, String flag) throws CliException {
        if (i >= args.length) {
            throw new CliException("error: a value is required for '" + flag + "' but none was supplied\n", 2);
        }
        return args[i];
    }

    private static int parseInt(String s, String prefix) throws CliException {
        try {
            if (s.startsWith("-")) {
                throw unexpected(s);
            }
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new CliException(prefix + "ParseIntError { kind: InvalidDigit }\nerror: invalid digit found in string\n", 1);
        }
    }

    private static CliException unexpected(String arg) {
        String msg = "error: unexpected argument '" + arg + "' found\n\n" +
                "  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'\n\n" +
                "Usage: executable [OPTIONS] [INPUTFILE]\n\n" +
                "For more information, try '--help'.\n";
        return new CliException(msg, 2);
    }

    private static CliException clapInvalid(String msg) {
        return new CliException("error: " + msg + "\nFor more information, try '--help'.\n", 2);
    }

    private static byte[] readInput(Options opt) throws IOException {
        byte[] data;
        if (opt.inputFile != null) {
            data = Files.readAllBytes(Path.of(opt.inputFile));
        } else {
            data = readAll(System.in);
        }
        if (opt.len > 0 && opt.len < data.length) {
            byte[] limited = new byte[opt.len];
            System.arraycopy(data, 0, limited, 0, opt.len);
            return limited;
        }
        return data;
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private static void printDump(byte[] data, Options opt) {
        int cols = Math.max(0, opt.cols);
        int offset = 0;
        if (cols == 0) {
            System.out.printf("0x%06x: %n", 0);
            System.out.printf("   bytes: %d%n", 0);
            return;
        }
        while (offset <= data.length) {
            int n = Math.min(cols, data.length - offset);
            System.out.print(String.format("0x%06x: ", offset));
            StringBuilder ascii = new StringBuilder();
            int cellWidth = octetWidth(opt) + 1;
            int used = 0;
            for (int i = 0; i < n; i++) {
                int b = data[offset + i] & 0xff;
                String oct = formatOctet(b, opt);
                System.out.print(color(oct, b, opt));
                System.out.print(" ");
                used += cellWidth;
                char ch = (b >= 32 && b <= 126) ? (char) b : '.';
                ascii.append(color(String.valueOf(ch), b, opt));
            }
            int total = n == 0 ? 50 : cols * cellWidth;
            for (int i = used; i < total; i++) {
                System.out.print(" ");
            }
            System.out.println(ascii);
            offset += cols;
            if (offset > data.length) {
                break;
            }
        }
        System.out.printf("   bytes: %d%n", data.length);
    }

    private static int octetWidth(Options opt) {
        return switch (opt.format) {
            case 'o' -> opt.prefix ? 6 : 4;
            case 'b' -> opt.prefix ? 10 : 8;
            default -> opt.prefix ? 4 : 2;
        };
    }

    private static String formatOctet(int b, Options opt) {
        return switch (opt.format) {
            case 'o' -> (opt.prefix ? "0o" : "") + String.format("%04o", b);
            case 'X' -> (opt.prefix ? "0x" : "") + String.format("%02X", b);
            case 'b' -> (opt.prefix ? "0b" : "") + String.format("%8s", Integer.toBinaryString(b)).replace(' ', '0');
            default -> (opt.prefix ? "0x" : "") + String.format("%02x", b);
        };
    }

    private static String color(String s, int b, Options opt) {
        if (opt.color != 1) {
            return s;
        }
        int code = b == 0 ? 22 : b;
        return "\033[38;5;" + code + "m" + s + "\033[0m";
    }

    private static void printArray(byte[] data, Options opt) {
        int cols = opt.cols <= 0 ? data.length : opt.cols;
        char a = opt.array;
        switch (a) {
            case 'r' -> System.out.printf("let ARRAY: [u8; %d] = [%n", data.length);
            case 'c' -> System.out.printf("unsigned char ARRAY[%d] = {%n", data.length);
            case 'g' -> System.out.printf("a := [%d]byte{%n", data.length);
            case 'p' -> System.out.println("a = [");
            case 'k' -> System.out.println("val a = byteArrayOf(");
            case 'j' -> System.out.println("byte[] a = new byte[]{");
            case 's' -> System.out.println("let a: [UInt8] = [");
            case 'f' -> System.out.println("let a = [|");
            default -> { }
        }
        for (int i = 0; i < data.length; i += cols) {
            int n = Math.min(cols, data.length - i);
            System.out.print("    ");
            for (int j = 0; j < n; j++) {
                int idx = i + j;
                String item = String.format("0x%02x", data[idx] & 0xff);
                if (a == 'g') {
                    System.out.print(item);
                    System.out.print(", ");
                } else if (a == 'f') {
                    item += "uy";
                    System.out.print(item);
                    if (idx != data.length - 1) {
                        System.out.print("; ");
                    }
                } else {
                    System.out.print(item);
                    if (idx != data.length - 1) {
                        System.out.print(", ");
                    }
                }
            }
            System.out.println();
        }
        switch (a) {
            case 'r' -> System.out.println("];");
            case 'c', 'j' -> System.out.println("};");
            case 'g' -> System.out.println("}");
            case 'p', 's' -> System.out.println("]");
            case 'k' -> System.out.println(")");
            case 'f' -> System.out.println("|]");
            default -> { }
        }
    }

    private static void printFunc(int len, int places) {
        if (len <= 0) {
            System.out.println();
            return;
        }
        String fmt = "%." + Math.max(0, places) + "f";
        for (int i = 0; i < len; i++) {
            double v = Math.sin((Math.PI / 2.0) * i / len);
            System.out.print(String.format(fmt, v));
            System.out.print(",");
        }
        System.out.println();
    }

    private static class CliException extends Exception {
        final String message;
        final int status;
        CliException(String message, int status) {
            this.message = message;
            this.status = status;
        }
    }
}
