import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.*;

public class Main {
  static class LuaError extends RuntimeException { LuaError(String m){super(m);} }
  interface Fn { Object call(List<Object> args); }
  static class Env {
    final Env parent; final Map<String,Object> vars=new LinkedHashMap<>();
    Env(Env p){parent=p;}
    Object get(String k){ if(vars.containsKey(k)) return vars.get(k); return parent==null?null:parent.get(k); }
    void set(String k,Object v){ Env e=find(k); (e==null?this:e).vars.put(k,v); }
    void local(String k,Object v){ vars.put(k,v); }
    Env find(String k){ if(vars.containsKey(k)) return this; return parent==null?null:parent.find(k); }
  }
  static class Table {
    final Map<Object,Object> map=new LinkedHashMap<>(); int next=1;
    void add(Object v){ map.put((double)next++, v); }
    Object get(Object k){ return map.get(normKey(k)); }
    void put(Object k,Object v){ map.put(normKey(k), v); }
    Object normKey(Object k){ if(k instanceof Integer) return ((Integer)k).doubleValue(); return k; }
    int len(){ int n=0; while(map.containsKey((double)(n+1))) n++; return n; }
  }
  static class Return extends RuntimeException { final List<Object> vals; Return(List<Object> v){vals=v;} }
  static class Break extends RuntimeException {}
  static class Tok {
    final String text; final int line;
    Tok(String t,int l){text=t;line=l;}
    public String toString(){return text;}
  }
  interface Stmt { void exec(Env e); }
  interface Expr { Object eval(Env e); }

  static String progName = "./executable";
  static boolean warnings = false;

  public static void main(String[] args) throws Exception {
    progName = "./executable";
    List<String> chunks = new ArrayList<>();
    List<String> scriptArgs = new ArrayList<>();
    boolean interactive=false, stop=false, stdinScript=false;
    int i=0;
    try {
      for(; i<args.length; i++){
        String a=args[i];
        if(stop){ break; }
        if(a.equals("--")){ stop=true; i++; break; }
        if(a.equals("-")){ stdinScript=true; i++; break; }
        if(!a.startsWith("-") || a.equals("")) break;
        switch(a){
          case "-v": System.out.println("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"); break;
          case "-E": break;
          case "-W": warnings=true; break;
          case "-i": interactive=true; break;
          case "-e":
            if(i+1>=args.length) die("'-e' needs argument"); chunks.add(args[++i]); break;
          case "-l":
            if(i+1>=args.length) die("'-l' needs argument"); chunks.add(requireChunk(args[++i])); break;
          default:
            if(a.startsWith("-e") && a.length()>2) chunks.add(a.substring(2));
            else if(a.startsWith("-l") && a.length()>2) chunks.add(requireChunk(a.substring(2)));
            else { System.err.println(progName+": unrecognized option '"+a+"'"); usage(); System.exit(1); }
        }
      }
      int scriptIndex = (stdinScript || i<args.length) ? i : -1;
      Env env=baseEnv();
      Table argt=new Table();
      if(scriptIndex>=0){
        argt.put((double)(-scriptIndex-1), progName);
        for(int j=0;j<args.length;j++) argt.put((double)(j-scriptIndex), args[j]);
      } else {
        argt.put(-1.0, progName);
        for(int j=0;j<args.length;j++) argt.put((double)(j-args.length), args[j]);
      }
      env.local("arg", argt);
      for(String c: chunks) run(c, env);
      if(stdinScript){
        run(new String(System.in.readAllBytes()), env);
      } else if(i<args.length) {
        String script=args[i++];
        progName=script;
        for(;i<args.length;i++) scriptArgs.add(args[i]);
        Path p=Paths.get(script);
        if(!Files.exists(p)){ System.err.println("./executable: cannot open "+script+": No such file or directory"); System.exit(1); }
        run(Files.readString(p), env);
      } else if(interactive) {
        repl(env);
      }
    } catch (LuaError e) { System.err.println(progName+": "+e.getMessage()); System.exit(1); }
  }
  static String requireChunk(String s){ int eq=s.indexOf('='); String g=eq>=0?s.substring(0,eq):s; String m=eq>=0?s.substring(eq+1):s; return g+" = require('"+m+"')"; }
  static void usage(){ System.err.println("usage: ./executable [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin"); }
  static void die(String m){ throw new LuaError(m); }
  static void repl(Env env)throws Exception{ BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); String l; while((l=br.readLine())!=null){ try{run(l,env);}catch(Exception e){System.err.println(e.getMessage());}} }
  static void run(String code, Env env){ Parser p=new Parser(lex(code)); List<Stmt> ss=p.block(Set.of()); for(Stmt s:ss) s.exec(env); }

  static Env baseEnv(){
    Env e=new Env(null); e.local("_VERSION","Lua 5.5");
    e.local("print",(Fn)as->{ for(int i=0;i<as.size();i++){ if(i>0)System.out.print("\t"); System.out.print(str(as.get(i))); } System.out.println(); return null;});
    Table io=new Table(); io.put("write",(Fn)as->{ for(Object a:as) System.out.print(str(a)); return null;});
    io.put("read",(Fn)as->{ try{ BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); return br.readLine(); }catch(IOException ex){ return null; }});
    e.local("io",io);
    e.local("type",(Fn)as->{ Object v=arg(as,0); return v==null?"nil":v instanceof Boolean?"boolean":v instanceof Double?"number":v instanceof String?"string":v instanceof Table?"table":v instanceof Fn?"function":"userdata";});
    e.local("tostring",(Fn)as->str(arg(as,0))); e.local("tonumber",(Fn)as->{try{return num(arg(as,0));}catch(Exception ex){return null;}});
    e.local("assert",(Fn)as->{ if(!truth(arg(as,0))) throw new LuaError(str(as.size()>1?as.get(1):"assertion failed!")); return arg(as,0);});
    e.local("error",(Fn)as->{ throw new LuaError(str(arg(as,0))); });
    e.local("pcall",(Fn)as->{ List<Object> r=new ArrayList<>(); try{ Object f=arg(as,0); Object v=call(f, as.subList(1,as.size())); r.add(true); if(v instanceof Multi) r.addAll(((Multi)v).vals); else r.add(v); }catch(Exception ex){r.add(false); r.add(ex.getMessage());} return new Multi(r);});
    e.local("require",(Fn)as->{ String n=str(arg(as,0)); Object lib=makeLib(n); if(lib==null) throw new LuaError("module '"+n+"' not found"); return lib;});
    e.local("pairs",(Fn)as->arg(as,0)); e.local("ipairs",(Fn)as->arg(as,0));
    Table math=new Table(); math.put("pi",Math.PI); math.put("huge",Double.POSITIVE_INFINITY);
    math.put("abs",(Fn)as->Math.abs(num(arg(as,0)))); math.put("floor",(Fn)as->Math.floor(num(arg(as,0)))); math.put("ceil",(Fn)as->Math.ceil(num(arg(as,0))));
    math.put("sqrt",(Fn)as->Math.sqrt(num(arg(as,0)))); math.put("sin",(Fn)as->Math.sin(num(arg(as,0)))); math.put("cos",(Fn)as->Math.cos(num(arg(as,0))));
    math.put("max",(Fn)as->{double m=-Double.MAX_VALUE; for(Object a:as)m=Math.max(m,num(a)); return m;}); math.put("min",(Fn)as->{double m=Double.MAX_VALUE; for(Object a:as)m=Math.min(m,num(a)); return m;});
    math.put("random",(Fn)as->Math.random());
    e.local("math",math);
    Table string=new Table(); string.put("len",(Fn)as->(double)str(arg(as,0)).length()); string.put("upper",(Fn)as->str(arg(as,0)).toUpperCase()); string.put("lower",(Fn)as->str(arg(as,0)).toLowerCase()); string.put("reverse",(Fn)as->new StringBuilder(str(arg(as,0))).reverse().toString()); string.put("rep",(Fn)as->str(arg(as,0)).repeat((int)num(arg(as,1))));
    string.put("sub",(Fn)as->{String s=str(arg(as,0)); int a=(int)num(arg(as,1)); int b=as.size()>2?(int)num(arg(as,2)):s.length(); if(a<0)a=s.length()+a+1; if(b<0)b=s.length()+b+1; a=Math.max(1,a); b=Math.min(s.length(),b); return a>b?"":s.substring(a-1,b);});
    string.put("find",(Fn)as->{String s=str(arg(as,0)), pat=str(arg(as,1)); int ix=s.indexOf(pat); if(ix<0)return null; return new Multi(List.of((double)ix+1,(double)(ix+pat.length())));}); e.local("string",string);
    Table table=new Table(); table.put("insert",(Fn)as->{((Table)arg(as,0)).add(arg(as,1)); return null;}); table.put("concat",(Fn)as->{Table t=(Table)arg(as,0); String sep=as.size()>1?str(as.get(1)):""; StringBuilder sb=new StringBuilder(); for(int i=1;i<=t.len();i++){ if(i>1)sb.append(sep); sb.append(str(t.get((double)i))); } return sb.toString();}); table.put("sort",(Fn)as->{Table t=(Table)arg(as,0); List<Object> vals=new ArrayList<>(); for(int i=1;i<=t.len();i++)vals.add(t.get((double)i)); vals.sort(Comparator.comparing(Main::str)); for(int i=0;i<vals.size();i++)t.put((double)(i+1),vals.get(i)); return null;}); e.local("table",table);
    Table os=new Table(); os.put("clock",(Fn)as->System.nanoTime()/1e9); os.put("exit",(Fn)as->{System.exit(as.isEmpty()?0:(int)num(as.get(0))); return null;}); e.local("os",os);
    return e;
  }
  static Object makeLib(String n){ return null; }
  static Object arg(List<Object>a,int i){ return i<a.size()?a.get(i):null; }
  static class Multi { final List<Object> vals; Multi(List<Object>v){vals=v;} }
  static boolean truth(Object o){ return !(o==null || Boolean.FALSE.equals(o)); }
  static double num(Object o){ if(o instanceof Double)return(Double)o; if(o instanceof Number)return((Number)o).doubleValue(); return Double.parseDouble(str(o)); }
  static int cmp(Object a,Object b){ if(a instanceof String || b instanceof String) return str(a).compareTo(str(b)); return Double.compare(num(a),num(b)); }
  static String str(Object o){ if(o==null)return"nil"; if(o instanceof Boolean)return(Boolean)o?"true":"false"; if(o instanceof Double){ double d=(Double)o; if(d==(long)d)return Long.toString((long)d); return Double.toString(d);} if(o instanceof Table)return"table: "+Integer.toHexString(System.identityHashCode(o)); if(o instanceof Fn)return"function: "+Integer.toHexString(System.identityHashCode(o)); return o.toString(); }
  static Object call(Object f,List<Object>a){ if(!(f instanceof Fn)) throw new LuaError("attempt to call a "+(f==null?"nil":f.getClass().getSimpleName())+" value"); return ((Fn)f).call(a); }

  static List<Tok> lex(String s){
    List<Tok> r=new ArrayList<>(); int i=0,line=1; Set<String> two=Set.of("==","~=","<=",">=","..","//");
    while(i<s.length()){ char c=s.charAt(i); if(c=='\n'){line++;i++;continue;} if(Character.isWhitespace(c)){i++;continue;}
      if(c=='-'&&i+1<s.length()&&s.charAt(i+1)=='-'){ i+=2; while(i<s.length()&&s.charAt(i)!='\n')i++; continue; }
      if(c=='"'||c=='\''){ char q=c; i++; StringBuilder b=new StringBuilder(); while(i<s.length()&&s.charAt(i)!=q){ c=s.charAt(i++); if(c=='\\'&&i<s.length()){ char e=s.charAt(i++); b.append(e=='n'?'\n':e=='t'?'\t':e=='r'?'\r':e); } else b.append(c);} i++; r.add(new Tok("\""+b+"\"",line)); continue; }
      if(Character.isDigit(c)){ int j=i; while(j<s.length()&&(Character.isDigit(s.charAt(j))||s.charAt(j)=='.'))j++; r.add(new Tok(s.substring(i,j),line)); i=j; continue; }
      if(Character.isLetter(c)||c=='_'){ int j=i; while(j<s.length()&&(Character.isLetterOrDigit(s.charAt(j))||s.charAt(j)=='_'))j++; r.add(new Tok(s.substring(i,j),line)); i=j; continue; }
      if(i+1<s.length()&&two.contains(s.substring(i,i+2))){ r.add(new Tok(s.substring(i,i+2),line)); i+=2; continue; }
      r.add(new Tok(Character.toString(c),line)); i++;
    }
    r.add(new Tok("<eof>",line)); return r;
  }

  static class Parser {
    final List<Tok> t; int p=0; Parser(List<Tok>t){this.t=t;}
    String peek(){return t.get(p).text;} boolean at(String s){return peek().equals(s);} boolean take(String s){if(at(s)){p++;return true;}return false;} Tok next(){return t.get(p++);}
    List<Stmt> block(Set<String>end){ List<Stmt> ss=new ArrayList<>(); while(!at("<eof>")&&!end.contains(peek())){ if(take(";"))continue; ss.add(stmt()); } return ss; }
    Stmt stmt(){
      if(take("local")){ if(take("function")){ String n=next().text; FnExpr f=functionExpr(); return e->e.local(n,f.eval(e)); } List<String> ns=names(); List<Expr> es=take("=")?explist():List.of(); return e->{ for(int i=0;i<ns.size();i++) e.local(ns.get(i), i<es.size()?es.get(i).eval(e):null); }; }
      if(take("function")){ String n=next().text; FnExpr f=functionExpr(); return e->e.set(n,f.eval(e)); }
      if(take("return")){ List<Expr> es=at("end")||at("<eof>")?List.of():explist(); return e->{ List<Object> v=new ArrayList<>(); for(Expr x:es)v.add(x.eval(e)); throw new Return(v);};}
      if(take("break")) return e->{ throw new Break(); };
      if(take("do")){ List<Stmt>b=block(Set.of("end")); need("end"); return e->exec(b,new Env(e));}
      if(take("repeat")){ List<Stmt>b=block(Set.of("until")); need("until"); Expr c=expr(); return e->{ do{ try{exec(b,e);}catch(Break br){break;} }while(!truth(c.eval(e)));};}
      if(take("if")) return ifTail();
      if(take("while")){ Expr c=expr(); need("do"); List<Stmt>b=block(Set.of("end")); need("end"); return e->{ while(truth(c.eval(e))){ try{exec(b,e);}catch(Break br){break;} } };}
      if(take("for")){ List<String> ns=new ArrayList<>(); ns.add(next().text); if(take("=")){ Expr a=expr(); need(","); Expr b=expr(); Expr step=take(",")?expr():ee->1.0; need("do"); List<Stmt> body=block(Set.of("end")); need("end"); return e->{ for(double x=num(a.eval(e)),to=num(b.eval(e)),st=num(step.eval(e)); st>=0?x<=to:x>=to; x+=st){ Env le=new Env(e); le.local(ns.get(0),x); try{exec(body,le);}catch(Break br){break;} } }; } while(take(",")) ns.add(next().text); need("in"); Expr src=expr(); need("do"); List<Stmt> body=block(Set.of("end")); need("end"); return e->{ Object o=src.eval(e); if(o instanceof Table){ Table tb=(Table)o; boolean arrayOnly=ns.size()==1; for(Map.Entry<Object,Object>en:tb.map.entrySet()){ Env le=new Env(e); le.local(ns.get(0), arrayOnly?en.getValue():en.getKey()); if(ns.size()>1)le.local(ns.get(1), en.getValue()); try{exec(body,le);}catch(Break br){break;} } } }; }
      Expr lhs=prefix(); List<Expr> lhss=new ArrayList<>(); lhss.add(lhs); while(take(",")) lhss.add(prefix()); if(take("=")){ List<Expr> vals=explist(); return e->{ for(int i=0;i<lhss.size();i++) assign(lhss.get(i),e,i<vals.size()?vals.get(i).eval(e):null); }; } return e->lhs.eval(e);
    }
    Stmt ifTail(){ Expr c=expr(); need("then"); List<Stmt> th=block(Set.of("elseif","else","end")); List<Stmt> el=List.of(); if(take("elseif")) el=List.of(ifTail()); else { if(take("else")) el=block(Set.of("end")); need("end"); } List<Stmt> ell=el; return e->{ if(truth(c.eval(e))) exec(th,e); else exec(ell,e);}; }
    void exec(List<Stmt>s,Env e){ for(Stmt x:s)x.exec(e); }
    void need(String s){ if(!take(s)) throw new LuaError("syntax error near '"+peek()+"'"); }
    List<String> names(){ List<String> n=new ArrayList<>(); n.add(next().text); while(take(","))n.add(next().text); return n; }
    List<Expr> explist(){ List<Expr> e=new ArrayList<>(); e.add(expr()); while(take(","))e.add(expr()); return e; }
    Expr expr(){ return bin(0); }
    int prec(String o){ return switch(o){case"or"->1;case"and"->2;case"==","~=","<",">","<=",">="->3;case".."->4;case"+","-"->5;case"*","/","//","%"->6;case"^"->8;default->-1;};}
    Expr bin(int min){ Expr l=unary(); while(true){ String o=peek(); int pr=prec(o); if(pr<min)break; next(); int nextMin=(o.equals("^")||o.equals(".."))?pr:pr+1; Expr r=bin(nextMin); l=op(o,l,r);} return l; }
    Expr unary(){ if(take("-")){Expr x=unary(); return e->-num(x.eval(e));} if(take("not")){Expr x=unary(); return e->!truth(x.eval(e));} if(take("#")){Expr x=unary(); return e->{Object v=x.eval(e); return v instanceof Table?(double)((Table)v).len():(double)str(v).length();};} return prefix(); }
    Expr prefix(){ Expr x=primary(); while(true){ if(take(".")){String k=next().text; x=new Index(x,ee->k);} else if(take("[")){Expr k=expr(); need("]"); x=new Index(x,k);} else if(take(":")){String m=next().text; need("("); List<Expr>a=at(")")?List.of():explist(); need(")"); Expr self=x; x=e->{List<Object>av=new ArrayList<>(); av.add(self.eval(e)); for(Expr q:a)av.add(q.eval(e)); Object v=call(new Index(self,ee->m).eval(e),av); return v instanceof Multi?(((Multi)v).vals.isEmpty()?null:((Multi)v).vals.get(0)):v;}; } else if(take("(")){List<Expr>a=at(")")?List.of():explist(); need(")"); Expr f=x; x=e->{List<Object>av=new ArrayList<>(); for(Expr q:a)av.add(q.eval(e)); Object v=call(f.eval(e),av); return v instanceof Multi?(((Multi)v).vals.isEmpty()?null:((Multi)v).vals.get(0)):v;}; } else break;} return x; }
    Expr primary(){ String s=next().text; if(s.equals("(")){Expr e=expr(); need(")"); return e;} if(s.equals("nil"))return e->null; if(s.equals("true"))return e->true; if(s.equals("false"))return e->false; if(s.startsWith("\""))return e->s.substring(1,s.length()-1); if(Character.isDigit(s.charAt(0)))return e->Double.parseDouble(s); if(s.equals("{")){ List<Object[]> items=new ArrayList<>(); if(!at("}")) do{ if(take("[")){Expr k=expr(); need("]"); need("="); Expr v=expr(); items.add(new Object[]{k,v}); } else if(p+1<t.size()&&t.get(p+1).text.equals("=")){String k=next().text; need("="); Expr v=expr(); items.add(new Object[]{(Expr)(e->k),v});} else {Expr v=expr(); items.add(new Object[]{null,v});} }while(take(",")||take(";")); need("}"); return e->{Table tb=new Table(); for(Object[]it:items){Object v=((Expr)it[1]).eval(e); if(it[0]==null)tb.add(v); else tb.put(((Expr)it[0]).eval(e),v);} return tb;}; } return new Var(s); }
    FnExpr functionExpr(){ need("("); List<String> ps=at(")")?List.of():names(); need(")"); List<Stmt>b=block(Set.of("end")); need("end"); return new FnExpr(ps,b); }
    Expr op(String o,Expr a,Expr b){ return e->{Object x=a.eval(e), y=b.eval(e); return switch(o){case"or"->truth(x)?x:y;case"and"->truth(x)?y:x;case"=="->Objects.equals(x,y);case"~="->!Objects.equals(x,y);case"<"->cmp(x,y)<0;case">"->cmp(x,y)>0;case"<="->cmp(x,y)<=0;case">="->cmp(x,y)>=0;case"+"->num(x)+num(y);case"-"->num(x)-num(y);case"*"->num(x)*num(y);case"/"->num(x)/num(y);case"//"->Math.floor(num(x)/num(y));case"%"->num(x)%num(y);case"^"->Math.pow(num(x),num(y));case".."->str(x)+str(y);default->null;};};}
    void assign(Expr lhs,Env e,Object v){ if(lhs instanceof Var)((Var)lhs).set(e,v); else if(lhs instanceof Index)((Index)lhs).set(e,v); else throw new LuaError("syntax error");}
  }
  static class Var implements Expr { final String n; Var(String n){this.n=n;} public Object eval(Env e){ return e.get(n);} void set(Env e,Object v){e.set(n,v);} }
  static class Index implements Expr { final Expr t,k; Index(Expr t,Expr k){this.t=t;this.k=k;} public Object eval(Env e){ Object tb=t.eval(e); Object key=k.eval(e); if(tb instanceof Table)return ((Table)tb).get(key); if(tb instanceof String){ Object st=e.get("string"); return st instanceof Table?((Table)st).get(key):null; } return null;} void set(Env e,Object v){ Object tb=t.eval(e); if(tb instanceof Table)((Table)tb).put(k.eval(e),v); else throw new LuaError("attempt to index a non-table value");} }
  static class FnExpr implements Expr { final List<String> ps; final List<Stmt>b; FnExpr(List<String>p,List<Stmt>b){ps=p;this.b=b;} public Object eval(Env env){ return (Fn)as->{ Env le=new Env(env); for(int i=0;i<ps.size();i++)le.local(ps.get(i), i<as.size()?as.get(i):null); try{ for(Stmt s:b)s.exec(le); }catch(Return r){ return r.vals.size()==1?r.vals.get(0):new Multi(r.vals);} return null;};} }
}
