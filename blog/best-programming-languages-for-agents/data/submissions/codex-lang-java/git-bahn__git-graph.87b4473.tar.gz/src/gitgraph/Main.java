package gitgraph;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Main {
    static final String VERSION = "git-graph 0.7.0";
    static final Set<String> MODELS = new LinkedHashSet<>(Arrays.asList("none", "simple", "git-flow"));

    static class Opt {
        String path = ".";
        String model = null;
        int max = -1;
        String color = "auto";
        boolean noColor, reverse, local, svg, debug, sparse;
        String style = "normal";
        String format = "oneline";
        List<String> wrap = new ArrayList<>();
        String command = null;
        boolean helpLong = false, helpShort = false, version = false;
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (CliExit e) {
            if (!e.getMessage().isEmpty()) System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            if (e instanceof IOException && String.valueOf(e.getMessage()).contains("Broken pipe")) System.exit(0);
            System.err.println("ERROR: " + e.getMessage());
            System.exit(1);
        }
    }

    static int run(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("help")) {
            if (args.length > 1 && args[1].equals("model")) printModelHelp();
            else printHelp(true);
            return 0;
        }
        Opt o = parse(args);
        if (o.version) {
            System.out.println(VERSION);
            return 0;
        }
        if (o.command != null && o.command.startsWith("model")) return modelCommand(o);
        if (o.helpShort || o.helpLong) {
            printHelp(o.helpLong);
            return 0;
        }
        if (!validStyle(o.style)) {
            System.err.println("Unknown characters/style '" + o.style + "'. Must be one of [normal|thin|round|bold|double|ascii]");
            return 1;
        }
        if (o.model != null && !modelExists(o.model)) {
            System.err.println("ERROR: No branching model named '" + o.model + "' found in " + homeModels());
            System.err.println("       Available models are: none, simple, git-flow");
            return 1;
        }
        Path repo = resolveRepo(o.path);
        if (repo == null) {
            Path p = Paths.get(o.path);
            System.err.println("ERROR: failed to resolve path '" + o.path + "': " + (Files.exists(p) ? "not a git repository" : "No such file or directory"));
            System.err.println("       Navigate into a repository before running git-graph, or use option --path");
            return 1;
        }
        if (o.svg) {
            printSvg(repo, o);
            return 0;
        }
        printLog(repo, o);
        return 0;
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": o.helpShort = true; break;
                case "--help": o.helpLong = true; break;
                case "-V": case "--version": o.version = true; break;
                case "-p": case "--path": o.path = need(args, ++i, a); break;
                case "--skip-repo-owner-validation": break;
                case "-m": case "--model": o.model = need(args, ++i, a); break;
                case "-n": case "--max-count":
                    String n = need(args, ++i, a);
                    try { o.max = Integer.parseInt(n); if (o.max <= 0) throw new NumberFormatException(); }
                    catch (NumberFormatException ex) { throw new CliExit("Option max-count must be a positive number, but got '" + n + "'", 1); }
                    break;
                case "--color": o.color = need(args, ++i, a); break;
                case "--no-color": o.noColor = true; break;
                case "-w": case "--wrap":
                    while (i + 1 < args.length && !args[i + 1].startsWith("-")) o.wrap.add(args[++i]);
                    break;
                case "-f": case "--format": o.format = need(args, ++i, a); break;
                case "-r": case "--reverse": o.reverse = true; break;
                case "-l": case "--local": o.local = true; break;
                case "--svg": o.svg = true; break;
                case "-d": case "--debug": o.debug = true; break;
                case "-S": case "--sparse": o.sparse = true; break;
                case "-s": case "--style": o.style = normalizeStyle(need(args, ++i, a)); break;
                case "model":
                    o.command = "model";
                    parseModelArgs(o, Arrays.copyOfRange(args, i + 1, args.length));
                    return o;
                default:
                    if (a.startsWith("--style=")) o.style = normalizeStyle(a.substring(8));
                    else if (a.startsWith("--model=")) o.model = a.substring(8);
                    else if (a.startsWith("--format=")) o.format = a.substring(9);
                    else if (a.startsWith("--path=")) o.path = a.substring(7);
                    else if (a.startsWith("--max-count=")) {
                        String n2 = a.substring(12);
                        try { o.max = Integer.parseInt(n2); if (o.max <= 0) throw new NumberFormatException(); }
                        catch (NumberFormatException ex) { throw new CliExit("Option max-count must be a positive number, but got '" + n2 + "'", 1); }
                    } else if (!a.startsWith("-")) {
                        System.err.println("error: unrecognized subcommand '" + a + "'\n");
                        System.err.println("Usage: executable [OPTIONS] [COMMAND]\n");
                        System.err.println("For more information, try '--help'.");
                        throw new CliExit("", 1);
                    } else {
                        System.err.println("error: unexpected argument '" + a + "' found");
                        throw new CliExit("", 1);
                    }
            }
        }
        return o;
    }

    static void parseModelArgs(Opt o, String[] rest) {
        for (int i = 0; i < rest.length; i++) {
            String a = rest[i];
            if (a.equals("-h") || a.equals("--help")) o.helpShort = true;
            else if (a.equals("-l") || a.equals("--list")) o.command = "model-list";
            else if (o.model == null) o.model = a;
        }
    }

    static String need(String[] args, int i, String opt) {
        if (i >= args.length) throw new CliExit("error: a value is required for '" + opt + "'", 1);
        return args[i];
    }

    static int modelCommand(Opt o) throws Exception {
        if (o.helpShort || o.helpLong) { printModelHelp(); return 0; }
        if ("model-list".equals(o.command)) {
            for (String m : MODELS) System.out.println(m);
            listCustomModels();
            return 0;
        }
        Path repo = resolveRepo(o.path);
        if (repo == null) {
            System.err.println("ERROR: failed to resolve path '" + o.path + "': No such file or directory");
            System.err.println("       Navigate into a repository before running git-graph, or use option --path");
            return 1;
        }
        if (o.model == null) {
            String val = git(repo, "config", "--get", "git-graph.model").trim();
            if (val.isEmpty()) System.out.print("No branching model set");
            else System.out.print(val);
            return 0;
        }
        if (!modelExists(o.model)) {
            System.err.println("ERROR: No branching model named '" + o.model + "' found in " + homeModels());
            System.err.println("       Available models are: none, simple, git-flow");
            return 1;
        }
        git(repo, "config", "git-graph.model", o.model);
        System.out.print("Branching model set to '" + o.model + "'");
        return 0;
    }

    static void printLog(Path repo, Opt o) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add("log");
        cmd.add("--graph");
        cmd.add("--decorate=short");
        cmd.add("--abbrev=7");
        cmd.add("--date=default");
        if (o.reverse) cmd.add("--reverse");
        if (o.max > 0) cmd.add("-n"); if (o.max > 0) cmd.add(String.valueOf(o.max));
        if (o.local) cmd.add("--branches");
        cmd.add("--pretty=format:" + pretty(o.format));
        String raw = git(repo, cmd.toArray(new String[0]));
        if (raw.isEmpty()) return;
        String[] lines = raw.split("\\R", -1);
        for (String line : lines) {
            if (line.isEmpty()) continue;
            String t = translateGraph(line, o.style);
            System.out.println(t);
        }
    }

    static String pretty(String f) {
        String k = f.toLowerCase(Locale.ROOT);
        if (k.equals("o") || k.equals("oneline")) return "%h%d %s";
        if (k.equals("s") || k.equals("short")) return "commit %H%d%nAuthor: %an <%ae>%n%n    %s%n";
        if (k.equals("m") || k.equals("medium")) return "commit %H%d%+P%nAuthor: %an <%ae>%nDate:   %ad%n%n    %B%n";
        if (k.equals("f") || k.equals("full")) return "commit %H%d%+P%nAuthor: %an <%ae>%nCommit: %cn <%ce>%nDate:   %ad%n%n    %B%n";
        return f;
    }

    static String translateGraph(String line, String style) {
        int idx = firstCommitChar(line);
        if (idx < 0) return " " + styleGraph(line, style) + "  ";
        String graph = line.substring(0, idx);
        String text = line.substring(idx);
        graph = compressGitMerge(graph);
        String sg = styleGraph(graph, style);
        if (sg.length() < 4) sg = String.format("%-4s", sg);
        return " " + sg + " " + text;
    }

    static int firstCommitChar(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != ' ' && c != '*' && c != '|' && c != '\\' && c != '/' && c != '_' && c != '-' && c != '.') return i;
        }
        return -1;
    }

    static String compressGitMerge(String g) {
        if (g.equals("*   ")) return "o<.";
        if (g.equals("* ")) return "*";
        if (g.endsWith("* ")) return g.substring(0, g.length() - 2) + "*";
        return g.trim().isEmpty() ? g : g;
    }

    static String styleGraph(String g, String style) {
        boolean ascii = style.equals("ascii");
        String s = g;
        if (!ascii) {
            s = s.replace("o<.", mergeLeft(style));
            s = s.replace('*', node(style));
            s = s.replace('|', vertical(style));
            s = s.replace('\\', downRight(style));
            s = s.replace('/', upRight(style));
            s = s.replace('-', horizontal(style));
            s = s.replace('.', corner(style));
        }
        return s;
    }

    static char node(String st) { return st.equals("round") ? '●' : st.equals("bold") ? '●' : st.equals("double") ? '●' : '●'; }
    static char vertical(String st) { return st.equals("bold") ? '┃' : st.equals("double") ? '║' : '│'; }
    static char horizontal(String st) { return st.equals("bold") ? '━' : st.equals("double") ? '═' : '─'; }
    static char downRight(String st) { return st.equals("bold") ? '┗' : st.equals("double") ? '╚' : '└'; }
    static char upRight(String st) { return st.equals("bold") ? '┏' : st.equals("double") ? '╔' : '┌'; }
    static char corner(String st) { return st.equals("bold") ? '┓' : st.equals("double") ? '╗' : '┐'; }
    static String mergeLeft(String st) {
        if (st.equals("ascii")) return "o<.";
        if (st.equals("bold")) return "○<┓";
        if (st.equals("double")) return "○<╗";
        return "○<┐";
    }

    static void printSvg(Path repo, Opt o) throws Exception {
        String hashes = git(repo, "log", "--pretty=format:%H");
        int count = hashes.isEmpty() ? 0 : hashes.split("\\R").length;
        if (o.max > 0) count = Math.min(count, o.max);
        int h = Math.max(15, count * 15 + 30);
        System.out.println("<svg height=\"" + h + "\" viewBox=\"0 0 45 " + h + "\" width=\"45\" xmlns=\"http://www.w3.org/2000/svg\">");
        if (count > 1) System.out.println("<line stroke=\"blue\" stroke-width=\"1\" x1=\"15\" x2=\"15\" y1=\"15\" y2=\"" + (15 * count) + "\"/>");
        for (int i = 0; i < count; i++) {
            int y = 15 + i * 15;
            System.out.println("<circle cx=\"15\" cy=\"" + y + "\" fill=\"blue\" r=\"4\" stroke=\"blue\" stroke-width=\"1\"/>");
        }
        System.out.println("</svg>");
    }

    static Path resolveRepo(String path) throws Exception {
        Path p = Paths.get(path).toAbsolutePath().normalize();
        if (!Files.exists(p)) return null;
        ProcessResult r = exec(p, Arrays.asList("git", "rev-parse", "--show-toplevel"), false);
        if (r.code != 0) return null;
        return Paths.get(r.out.trim());
    }

    static String git(Path cwd, String... args) throws Exception {
        List<String> cmd = new ArrayList<>();
        cmd.add("git");
        cmd.addAll(Arrays.asList(args));
        ProcessResult r = exec(cwd, cmd, true);
        if (r.code != 0) return "";
        return r.out;
    }

    static ProcessResult exec(Path cwd, List<String> cmd, boolean mergeErr) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(cwd.toFile());
        if (mergeErr) pb.redirectErrorStream(true);
        Process p = pb.start();
        byte[] out = p.getInputStream().readAllBytes();
        byte[] err = p.getErrorStream().readAllBytes();
        int code = p.waitFor();
        return new ProcessResult(code, new String(out, StandardCharsets.UTF_8), new String(err, StandardCharsets.UTF_8));
    }

    record ProcessResult(int code, String out, String err) {}

    static boolean validStyle(String s) {
        return Arrays.asList("normal","thin","round","bold","double","ascii").contains(s);
    }
    static String normalizeStyle(String s) {
        if (s.equals("n")) return "normal";
        if (s.equals("t")) return "thin";
        if (s.equals("r")) return "round";
        if (s.equals("b")) return "bold";
        if (s.equals("d")) return "double";
        if (s.equals("a")) return "ascii";
        return s;
    }
    static boolean modelExists(String m) {
        if (MODELS.contains(m)) return true;
        return Files.isRegularFile(Paths.get(homeModels(), m + ".toml"));
    }
    static String homeModels() {
        return System.getProperty("user.home") + "/.config/git-graph/models";
    }
    static void listCustomModels() throws IOException {
        Path dir = Paths.get(homeModels());
        if (!Files.isDirectory(dir)) return;
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.toml")) {
            for (Path p : ds) {
                String name = p.getFileName().toString().replaceFirst("\\.toml$", "");
                if (!MODELS.contains(name)) System.out.println(name);
            }
        }
    }

    static void printHelp(boolean longHelp) {
        System.out.println("Structured Git graphs for your branching model.");
        System.out.println("    https://github.com/mlange-42/git-graph\n");
        System.out.println("EXAMPES:");
        System.out.println("    git-graph                   -> Show graph");
        System.out.println("    git-graph --style round     -> Show graph in a different style");
        System.out.println("    git-graph --model <model>   -> Show graph using a certain <model>");
        System.out.println("    git-graph model --list      -> List available branching models");
        System.out.println("    git-graph model             -> Show repo's current branching models");
        System.out.println("    git-graph model <model>     -> Permanently set model <model> for this repo\n");
        System.out.println("Usage: executable [OPTIONS] [COMMAND]\n");
        System.out.println("Commands:");
        System.out.println("  model  Prints or permanently sets the branching model for a repository.");
        System.out.println("  help   Print this message or the help of the given subcommand(s)\n");
        System.out.println("Options:");
        System.out.println("  -p, --path <path>                 Open repository from this path or above. Default '.'");
        System.out.println("      --skip-repo-owner-validation  Skip owner validation for the repository.");
        System.out.println("  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].");
        System.out.println("                                    Default: git-flow.");
        System.out.println("  -n, --max-count <n>               Maximum number of commits");
        System.out.println("      --color <color>               Specify when colors should be used. One of [auto|always|never].");
        System.out.println("      --no-color                    Print without colors.");
        System.out.println("  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'");
        System.out.println("  -f, --format <format>             Commit format. One of [oneline|short|medium|full|\"<string>\"].");
        System.out.println("  -r, --reverse                     Reverse the order of commits.");
        System.out.println("  -l, --local                       Show only local branches, no remotes.");
        System.out.println("      --svg                         Render graph as SVG instead of text-based.");
        System.out.println("  -d, --debug                       Additional debug output and graphics.");
        System.out.println("  -S, --sparse                      Print a less compact graph: merge lines point to target lines");
        System.out.println("  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].");
        System.out.println("  -h, --help                        Print help (see more with '--help')");
        System.out.println("  -V, --version                     Print version");
    }

    static void printModelHelp() {
        System.out.println("Prints or permanently sets the branching model for a repository.\n");
        System.out.println("Usage: executable model [OPTIONS] [model]\n");
        System.out.println("Arguments:");
        System.out.println("  [model]  The branching model to be used. Available presets are [simple|git-flow|none].");
        System.out.println("           When not given, prints the currently set model.\n");
        System.out.println("Options:");
        System.out.println("  -l, --list  List all available branching models.");
        System.out.println("  -h, --help  Print help");
    }

    static class CliExit extends RuntimeException {
        final int code;
        CliExit(String msg, int c) { super(msg); code = c; }
    }
}
