import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static class Options {
        Set<Integer> accepted = parseCodes("200..300");
        int timeout = 10;
        int maxRedirects = 64;
        int maxBody = 10_000_000;
        boolean verbose = false;
        boolean ignoreFragments = false;
        boolean onePageOnly = false;
        boolean verboseJson = false;
        String format = "text";
        List<Pattern> include = new ArrayList<>();
        List<Pattern> exclude = new ArrayList<>();
        List<String[]> headers = new ArrayList<>();
        String url;
    }

    static class Fetch {
        int status;
        String error;
        String body = "";
        String contentType = "";
        URI finalUri;
    }

    static class LinkResult {
        String url;
        String error;
        Integer status;
        boolean ok() { return error == null; }
    }

    static class PageResult {
        String url;
        List<LinkResult> links = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Options opt = parseArgs(args);
            if (opt == null) return;
            int code = run(opt);
            System.exit(code);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static int run(Options opt) throws Exception {
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(opt.timeout))
                .followRedirects(HttpClient.Redirect.NEVER)
                .build();

        URI root = normalize(new URI(opt.url), null, false);
        Fetch rootFetch = fetch(client, root, opt);
        if (rootFetch.error != null || !opt.accepted.contains(rootFetch.status)) {
            System.err.println("failed to fetch root page: " + (rootFetch.error != null ? rootFetch.error : rootFetch.status));
            return 1;
        }

        Map<String, PageResult> pages = new LinkedHashMap<>();
        Map<String, Fetch> cache = new LinkedHashMap<>();
        cache.put(stripFragment(root).toString(), rootFetch);
        Queue<URI> queue = new ArrayDeque<>();
        Set<String> crawled = new LinkedHashSet<>();
        queue.add(stripFragment(root));

        while (!queue.isEmpty()) {
            URI pageUri = queue.remove();
            String pageKey = pageUri.toString();
            if (!crawled.add(pageKey)) continue;
            Fetch pageFetch = cache.get(pageKey);
            if (pageFetch == null) {
                pageFetch = fetch(client, pageUri, opt);
                cache.put(pageKey, pageFetch);
            }
            if (pageFetch.error != null || !isHtml(pageFetch)) continue;

            PageResult page = new PageResult();
            page.url = pageUri.toString();
            pages.put(page.url, page);
            List<URI> links = extractLinks(pageUri, pageFetch.body);
            for (URI link : links) {
                if (!included(link.toString(), opt)) continue;
                LinkResult lr = checkLink(client, link, opt, cache);
                page.links.add(lr);

                URI crawlUri = stripFragment(link);
                Fetch lf = cache.get(crawlUri.toString());
                if (!opt.onePageOnly && lf != null && lr.ok() && isSameSite(root, crawlUri) && isHtml(lf) && !crawled.contains(crawlUri.toString())) {
                    queue.add(crawlUri);
                }
            }
        }

        if (opt.format.equals("json")) printJson(pages, opt);
        else if (opt.format.equals("junit")) printJunit(pages);
        else printText(pages, opt);
        return hasFailures(pages) ? 1 : 0;
    }

    static LinkResult checkLink(HttpClient client, URI link, Options opt, Map<String, Fetch> cache) {
        LinkResult lr = new LinkResult();
        lr.url = link.toString();
        URI fetchUri = opt.ignoreFragments ? stripFragment(link) : stripFragment(link);
        Fetch f = cache.get(fetchUri.toString());
        if (f == null) {
            f = fetch(client, fetchUri, opt);
            cache.put(fetchUri.toString(), f);
        }
        if (f.error != null) {
            lr.error = f.error;
            return lr;
        }
        lr.status = f.status;
        if (!opt.accepted.contains(f.status)) {
            lr.error = String.valueOf(f.status);
            return lr;
        }
        String frag = link.getRawFragment();
        if (!opt.ignoreFragments && frag != null && !frag.isEmpty() && isHtml(f)) {
            String decoded = decodeFragment(frag);
            if (!hasAnchor(f.body, decoded)) {
                lr.error = "id #" + decoded + " not found";
            }
        }
        return lr;
    }

    static Fetch fetch(HttpClient client, URI uri, Options opt) {
        URI current = stripFragment(uri);
        for (int redirects = 0; ; redirects++) {
            if (redirects > opt.maxRedirects) {
                Fetch f = new Fetch();
                f.error = "too many redirections";
                return f;
            }
            try {
                HttpRequest.Builder b = HttpRequest.newBuilder(current)
                        .timeout(Duration.ofSeconds(opt.timeout))
                        .method("GET", HttpRequest.BodyPublishers.noBody())
                        .header("User-Agent", "muffet/2.11.1");
                for (String[] h : opt.headers) b.header(h[0], h[1]);
                HttpResponse<InputStream> resp = client.send(b.build(), HttpResponse.BodyHandlers.ofInputStream());
                int status = resp.statusCode();
                if (status >= 300 && status < 400 && resp.headers().firstValue("location").isPresent()) {
                    current = normalize(current.resolve(resp.headers().firstValue("location").get()), null, true);
                    continue;
                }
                Fetch f = new Fetch();
                f.status = status;
                f.finalUri = current;
                f.contentType = resp.headers().firstValue("content-type").orElse("");
                f.body = readLimited(resp.body(), opt.maxBody);
                return f;
            } catch (Exception e) {
                Fetch f = new Fetch();
                f.error = cleanError(e);
                return f;
            }
        }
    }

    static String readLimited(InputStream in, int limit) throws Exception {
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int total = 0;
            for (int n; (n = input.read(buf)) >= 0; ) {
                int take = Math.min(n, Math.max(0, limit - total));
                if (take > 0) out.write(buf, 0, take);
                total += n;
                if (total >= limit) break;
            }
            return out.toString("UTF-8");
        }
    }

    static String cleanError(Exception e) {
        Throwable t = e;
        while (t.getCause() != null) t = t.getCause();
        String s = t.getMessage();
        if (s == null || s.isEmpty()) s = t.toString();
        return s;
    }

    static boolean isHtml(Fetch f) {
        String ct = f.contentType == null ? "" : f.contentType.toLowerCase(Locale.ROOT);
        return ct.isEmpty() || ct.contains("text/html") || ct.contains("application/xhtml");
    }

    static final Pattern ATTR = Pattern.compile("(?is)\\b(?:href|src)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
    static final Pattern SRCSET = Pattern.compile("(?is)\\bsrcset\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^>]+))");

    static List<URI> extractLinks(URI base, String html) {
        List<URI> out = new ArrayList<>();
        Matcher m = ATTR.matcher(html);
        while (m.find()) addLink(out, base, first(m.group(1), m.group(2), m.group(3)));
        Matcher s = SRCSET.matcher(html);
        while (s.find()) {
            String value = first(s.group(1), s.group(2), s.group(3));
            for (String part : value.split(",")) {
                String u = part.trim().split("\\s+")[0];
                addLink(out, base, u);
            }
        }
        return out;
    }

    static void addLink(List<URI> out, URI base, String value) {
        if (value == null) return;
        value = htmlDecode(value.trim());
        if (value.isEmpty() || value.startsWith("#")) return;
        String low = value.toLowerCase(Locale.ROOT);
        if (low.startsWith("mailto:") || low.startsWith("tel:") || low.startsWith("javascript:") || low.startsWith("data:")) return;
        try {
            URI u = normalize(base.resolve(value), base, false);
            if (u.getScheme() != null && (u.getScheme().equals("http") || u.getScheme().equals("https"))) out.add(u);
        } catch (Exception ignored) {
        }
    }

    static URI normalize(URI u, URI base, boolean keepFragment) throws URISyntaxException {
        String scheme = u.getScheme() == null ? "http" : u.getScheme().toLowerCase(Locale.ROOT);
        String host = u.getHost() == null ? null : u.getHost().toLowerCase(Locale.ROOT);
        int port = u.getPort();
        String path = u.getRawPath();
        if (path == null || path.isEmpty()) path = "/";
        URI n = new URI(scheme, u.getRawUserInfo(), host, port, path, u.getRawQuery(), keepFragment ? u.getRawFragment() : u.getRawFragment()).normalize();
        return n;
    }

    static URI stripFragment(URI u) {
        try {
            return new URI(u.getScheme(), u.getRawUserInfo(), u.getHost(), u.getPort(), u.getRawPath() == null || u.getRawPath().isEmpty() ? "/" : u.getRawPath(), u.getRawQuery(), null).normalize();
        } catch (Exception e) {
            return u;
        }
    }

    static boolean isSameSite(URI a, URI b) {
        return eq(a.getScheme(), b.getScheme()) && eq(a.getHost(), b.getHost()) && effectivePort(a) == effectivePort(b);
    }

    static int effectivePort(URI u) {
        if (u.getPort() != -1) return u.getPort();
        return "https".equals(u.getScheme()) ? 443 : 80;
    }

    static boolean eq(String a, String b) {
        if (a == null) return b == null;
        return a.equalsIgnoreCase(b);
    }

    static boolean included(String url, Options opt) {
        for (Pattern p : opt.exclude) if (p.matcher(url).find()) return false;
        if (opt.include.isEmpty()) return true;
        for (Pattern p : opt.include) if (p.matcher(url).find()) return true;
        return false;
    }

    static boolean hasAnchor(String html, String id) {
        Pattern p = Pattern.compile("(?is)\\b(?:id|name)\\s*=\\s*(?:\"" + Pattern.quote(id) + "\"|'" + Pattern.quote(id) + "'|" + Pattern.quote(id) + "(?=[\\s>]))");
        return p.matcher(html).find();
    }

    static String decodeFragment(String s) {
        try { return java.net.URLDecoder.decode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    static String htmlDecode(String s) {
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'");
    }

    static void printText(Map<String, PageResult> pages, Options opt) {
        for (PageResult p : pages.values()) {
            List<LinkResult> shown = new ArrayList<>();
            for (LinkResult l : p.links) if (opt.verbose || !l.ok()) shown.add(l);
            if (!opt.verbose && shown.isEmpty()) continue;
            System.out.println(p.url);
            for (LinkResult l : shown) System.out.println("\t" + (l.ok() ? l.status : l.error) + "\t" + l.url);
        }
    }

    static void printJson(Map<String, PageResult> pages, Options opt) {
        StringBuilder sb = new StringBuilder("[");
        boolean firstPage = true;
        for (PageResult p : pages.values()) {
            List<LinkResult> links = new ArrayList<>();
            for (LinkResult l : p.links) if (opt.verboseJson || opt.verbose || !l.ok()) links.add(l);
            if (links.isEmpty()) continue;
            if (!firstPage) sb.append(",");
            firstPage = false;
            sb.append("{\"url\":\"").append(json(p.url)).append("\",\"links\":[");
            for (int i = 0; i < links.size(); i++) {
                LinkResult l = links.get(i);
                if (i > 0) sb.append(",");
                sb.append("{\"url\":\"").append(json(l.url)).append("\"");
                if (l.ok()) sb.append(",\"status\":").append(l.status);
                else sb.append(",\"error\":\"").append(json(l.error)).append("\"");
                sb.append("}");
            }
            sb.append("]}");
        }
        sb.append("]");
        System.out.println(sb);
    }

    static void printJunit(Map<String, PageResult> pages) {
        System.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        System.out.println("<testsuites>");
        for (PageResult p : pages.values()) {
            int failures = 0;
            for (LinkResult l : p.links) if (!l.ok()) failures++;
            if (p.links.isEmpty() && failures == 0) continue;
            System.out.println("  <testsuite name=\"" + xml(p.url) + "\" tests=\"" + p.links.size() + "\" failures=\"" + failures + "\" skipped=\"0\">");
            for (LinkResult l : p.links) {
                System.out.print("    <testcase name=\"" + xml(l.url) + "\" classname=\"" + xml(p.url) + "\">");
                if (l.ok()) {
                    System.out.println("</testcase>");
                } else {
                    System.out.println();
                    System.out.println("      <failure message=\"" + xml(l.error) + "\"></failure>");
                    System.out.println("    </testcase>");
                }
            }
            System.out.println("  </testsuite>");
        }
        System.out.println("</testsuites>");
    }

    static boolean hasFailures(Map<String, PageResult> pages) {
        for (PageResult p : pages.values()) for (LinkResult l : p.links) if (!l.ok()) return true;
        return false;
    }

    static String json(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t");
    }

    static String xml(String s) {
        return s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;").replace(">", "&gt;");
    }

    static String first(String... ss) {
        for (String s : ss) if (s != null) return s;
        return "";
    }

    static Options parseArgs(String[] args) {
        Options opt = new Options();
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("--help")) { printHelp(); return null; }
            if (a.equals("--version")) { System.out.println("2.11.1"); return null; }
            String name = a, value = null;
            int eq = a.indexOf('=');
            if (eq >= 0) { name = a.substring(0, eq); value = a.substring(eq + 1); }
            switch (name) {
                case "-v": case "--verbose": opt.verbose = true; break;
                case "-f": case "--ignore-fragments": opt.ignoreFragments = true; break;
                case "--one-page-only": opt.onePageOnly = true; break;
                case "--json": opt.format = "json"; break;
                case "--junit": opt.format = "junit"; break;
                case "--experimental-verbose-json": opt.format = "json"; opt.verboseJson = true; break;
                case "--follow-robots-txt": case "--follow-sitemap-xml": case "--skip-tls-verification": break;
                case "--format":
                    value = needValue(args, ++i, value, name);
                    if (!value.equals("text") && !value.equals("json") && !value.equals("junit"))
                        throw new IllegalArgumentException("Invalid value `" + value + "' for option `--format'. Allowed values are: text, json or junit");
                    opt.format = value; break;
                case "--accepted-status-codes": opt.accepted = parseCodes(needValue(args, ++i, value, name)); break;
                case "-t": case "--timeout": opt.timeout = parseInt(needValue(args, ++i, value, name), "-t, --timeout"); break;
                case "-r": case "--max-redirections": opt.maxRedirects = parseInt(needValue(args, ++i, value, name), "-r, --max-redirections"); break;
                case "--max-response-body-size": opt.maxBody = parseInt(needValue(args, ++i, value, name), name); break;
                case "-b": case "--buffer-size": case "-c": case "--max-connections": case "--max-connections-per-host": case "--max-retries": case "--rate-limit": case "--dns-resolver": case "--proxy":
                    needValue(args, ++i, value, name); break;
                case "-e": case "--exclude": opt.exclude.add(compileRegex(needValue(args, ++i, value, name))); break;
                case "-i": case "--include": opt.include.add(compileRegex(needValue(args, ++i, value, name))); break;
                case "--header":
                    String h = needValue(args, ++i, value, name);
                    int colon = h.indexOf(':');
                    if (colon > 0) opt.headers.add(new String[]{h.substring(0, colon).trim(), h.substring(colon + 1).trim()});
                    break;
                case "--color": needValue(args, ++i, value, name); break;
                default:
                    if (a.startsWith("-")) throw new IllegalArgumentException("unknown flag `" + a.replaceFirst("^-+", "") + "'");
                    pos.add(a);
            }
            if (eq >= 0 && takesValue(name)) i--;
        }
        if (pos.size() != 1) throw new IllegalArgumentException("invalid number of arguments");
        opt.url = pos.get(0);
        return opt;
    }

    static boolean takesValue(String n) {
        return true;
    }

    static String needValue(String[] args, int index, String current, String name) {
        if (current != null) return current;
        if (index >= args.length) throw new IllegalArgumentException("expected argument for flag `" + name + "'");
        return args[index];
    }

    static int parseInt(String s, String name) {
        try { return Integer.parseInt(s); }
        catch (Exception e) { throw new IllegalArgumentException("invalid argument for flag `" + name + "' (expected int): strconv.ParseInt: parsing \"" + s + "\": invalid syntax"); }
    }

    static Pattern compileRegex(String s) {
        try {
            return Pattern.compile(s);
        } catch (Exception e) {
            if ("[".equals(s)) throw new IllegalArgumentException("error parsing regexp: missing closing ]: `[`");
            throw new IllegalArgumentException("error parsing regexp: " + e.getMessage());
        }
    }

    static Set<Integer> parseCodes(String s) {
        Set<Integer> out = new TreeSet<>();
        for (String part : s.split(",")) {
            part = part.trim();
            if (part.isEmpty()) continue;
            int dots = part.indexOf("..");
            if (dots >= 0) {
                int a = Integer.parseInt(part.substring(0, dots));
                int b = Integer.parseInt(part.substring(dots + 2));
                for (int i = a; i <= b; i++) out.add(i);
            } else out.add(Integer.parseInt(part));
        }
        return out;
    }

    static void printHelp() {
        System.out.println("Usage:");
        System.out.println("  executable [options] <url>");
        System.out.println();
        System.out.println("Application Options:");
        System.out.println("      --accepted-status-codes=<codes>       Accepted HTTP response status codes");
        System.out.println("  -b, --buffer-size=<size>                  HTTP response buffer size in bytes");
        System.out.println("  -c, --max-connections=<count>             Maximum number of HTTP connections");
        System.out.println("      --max-connections-per-host=<count>    Maximum number of HTTP connections per host");
        System.out.println("      --max-response-body-size=<size>       Maximum response body size to read");
        System.out.println("  -e, --exclude=<pattern>...                Exclude URLs matched with given regular expressions");
        System.out.println("  -i, --include=<pattern>...                Include URLs matched with given regular expressions");
        System.out.println("      --follow-robots-txt                   Follow robots.txt when scraping pages");
        System.out.println("      --follow-sitemap-xml                  Scrape only pages listed in sitemap.xml (deprecated)");
        System.out.println("      --header=<header>...                  Custom headers");
        System.out.println("  -f, --ignore-fragments                    Ignore URL fragments");
        System.out.println("      --max-retries=<count>                 Maximum retry count for network errors");
        System.out.println("      --dns-resolver=<address>              Custom DNS resolver");
        System.out.println("      --format=[text|json|junit]            Output format (default: text)");
        System.out.println("      --json                                Output results in JSON (deprecated)");
        System.out.println("      --experimental-verbose-json           Include successful results in JSON (deprecated)");
        System.out.println("      --junit                               Output results as JUnit XML file (deprecated)");
        System.out.println("  -r, --max-redirections=<count>            Maximum number of redirections");
        System.out.println("      --rate-limit=<rate>                   Max requests per second");
        System.out.println("  -t, --timeout=<seconds>                   Timeout for HTTP requests in seconds");
        System.out.println("  -v, --verbose                             Show successful results too");
        System.out.println("      --proxy=<host>                        HTTP proxy host");
        System.out.println("      --skip-tls-verification               Skip TLS certificate verification");
        System.out.println("      --one-page-only                       Only check links found in the given URL");
        System.out.println("      --color=[auto|always|never]           Color output (default: auto)");
        System.out.println("  -h, --help                                Show this help");
        System.out.println("      --version                             Show version");
    }
}
