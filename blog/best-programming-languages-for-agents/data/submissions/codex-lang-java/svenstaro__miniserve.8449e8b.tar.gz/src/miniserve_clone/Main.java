package miniserve_clone;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class Main {
    static final String VERSION = "0.32.0";

    static class Config {
        Path root = Paths.get(".");
        int port = 8080;
        String bind = "0.0.0.0";
        String index = null;
        boolean spa, pretty, verbose, hidden, noSymlinks, dirsFirst, readme, disableIndexing;
        boolean upload, mkdir, rm, tar, targz, zip, hideFooter, hideTheme, wgetFooter, webdav;
        String uploadDir = null, rmDir = null, title = null, routePrefix = "";
        String sortMethod = "name", sortOrder = "desc", sizeDisplay = "human", externalUrl = "";
        String duplicate = "error";
        List<String> auth = new ArrayList<>();
        Map<String,String> customHeaders = new LinkedHashMap<>();
    }

    public static void main(String[] args) throws Exception {
        Config cfg;
        try {
            cfg = parse(args);
        } catch (CliExit e) {
            if (e.message != null) {
                if (e.code == 0) System.out.print(e.message);
                else System.err.print(e.message);
            }
            System.exit(e.code);
            return;
        }
        cfg.root = cfg.root.toAbsolutePath().normalize();
        if (!Files.exists(cfg.root)) {
            System.err.println("Error: Path does not exist: " + cfg.root);
            System.exit(1);
        }
        InetSocketAddress addr = new InetSocketAddress(cfg.bind, cfg.port);
        HttpServer server = HttpServer.create(addr, 0);
        server.createContext("/", new Handler(cfg));
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        int actualPort = server.getAddress().getPort();
        System.out.println("miniserve v" + VERSION);
        System.out.println("Bound to [::]:" + actualPort + ", 0.0.0.0:" + actualPort);
        System.out.println("Serving path " + cfg.root);
        System.out.println("Available at (non-exhaustive list):");
        System.out.println("    http://127.0.0.1:" + actualPort + prefix(cfg));
        System.out.println("    http://[::1]:" + actualPort + prefix(cfg));
    }

    static String prefix(Config c) { return c.routePrefix.isEmpty() ? "" : c.routePrefix; }

    static class CliExit extends Exception {
        int code; String message;
        CliExit(int code, String message) { this.code = code; this.message = message; }
    }

    static Config parse(String[] args) throws Exception {
        Config c = new Config();
        env(c);
        List<String> positionals = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--")) {
                while (++i < args.length) positionals.add(args[i]);
                break;
            } else if (a.equals("-h")) {
                throw new CliExit(0, shortHelp());
            } else if (a.equals("--help")) {
                throw new CliExit(0, longHelp());
            } else if (a.equals("-V") || a.equals("--version")) {
                throw new CliExit(0, "miniserve " + VERSION + "\n");
            } else if (a.equals("--print-manpage")) {
                throw new CliExit(0, manpage());
            } else if (a.equals("--print-completions")) {
                i++; throw new CliExit(0, "# shell completions for miniserve\n");
            } else if (a.equals("-v") || a.equals("--verbose")) c.verbose = true;
            else if (a.equals("--spa")) c.spa = true;
            else if (a.equals("--pretty-urls")) c.pretty = true;
            else if (a.equals("-P") || a.equals("--no-symlinks")) c.noSymlinks = true;
            else if (a.equals("-H") || a.equals("--hidden")) c.hidden = true;
            else if (a.equals("-q") || a.equals("--qrcode")) {}
            else if (a.equals("--directory-size")) {}
            else if (a.equals("-U") || a.equals("--mkdir")) c.mkdir = true;
            else if (a.equals("-r") || a.equals("--enable-tar")) c.tar = true;
            else if (a.equals("-g") || a.equals("--enable-tar-gz")) c.targz = true;
            else if (a.equals("-z") || a.equals("--enable-zip")) c.zip = true;
            else if (a.equals("-C") || a.equals("--compress-response")) {}
            else if (a.equals("-D") || a.equals("--dirs-first")) c.dirsFirst = true;
            else if (a.equals("-l") || a.equals("--show-symlink-info")) {}
            else if (a.equals("-F") || a.equals("--hide-version-footer")) c.hideFooter = true;
            else if (a.equals("--hide-theme-selector")) c.hideTheme = true;
            else if (a.equals("-W") || a.equals("--show-wget-footer")) c.wgetFooter = true;
            else if (a.equals("--readme")) c.readme = true;
            else if (a.equals("-I") || a.equals("--disable-indexing")) c.disableIndexing = true;
            else if (a.equals("--enable-webdav")) c.webdav = true;
            else if (a.equals("--random-route")) c.routePrefix = "/" + Integer.toHexString(new Random().nextInt(0x1000000));
            else if (a.equals("-u") || a.equals("--upload-files")) {
                c.upload = true;
                if (i + 1 < args.length && !args[i+1].startsWith("-")) c.uploadDir = args[++i];
            } else if (a.equals("-R") || a.equals("--rm-files")) {
                c.rm = true;
                if (i + 1 < args.length && !args[i+1].startsWith("-")) c.rmDir = args[++i];
            } else if (needsValue(a)) {
                if (i + 1 >= args.length) throw err("error: a value is required for '" + a + "'\n");
                set(c, a, args[++i]);
            } else if (a.startsWith("--")) {
                String key = a, val = null;
                int eq = a.indexOf('=');
                if (eq > 0) { key = a.substring(0, eq); val = a.substring(eq + 1); }
                if (val != null && needsValue(key)) set(c, key, val);
                else throw err("error: unexpected argument '" + a + "' found\n\nFor more information, try '--help'.\n");
            } else if (a.startsWith("-") && a.length() > 1) {
                for (int k = 1; k < a.length(); k++) {
                    char ch = a.charAt(k);
                    switch (ch) {
                        case 'v': c.verbose = true; break;
                        case 'P': c.noSymlinks = true; break;
                        case 'H': c.hidden = true; break;
                        case 'U': c.mkdir = true; break;
                        case 'r': c.tar = true; break;
                        case 'g': c.targz = true; break;
                        case 'z': c.zip = true; break;
                        case 'D': c.dirsFirst = true; break;
                        case 'F': c.hideFooter = true; break;
                        case 'W': c.wgetFooter = true; break;
                        case 'I': c.disableIndexing = true; break;
                        default: throw err("error: unexpected argument '-" + ch + "' found\n\nFor more information, try '--help'.\n");
                    }
                }
            } else positionals.add(a);
        }
        if (!positionals.isEmpty()) c.root = Paths.get(positionals.get(positionals.size() - 1));
        if (c.routePrefix.endsWith("/") && c.routePrefix.length() > 1) c.routePrefix = c.routePrefix.substring(0, c.routePrefix.length()-1);
        return c;
    }

    static CliExit err(String s) { return new CliExit(2, s); }

    static boolean needsValue(String a) {
        return Arrays.asList("--temp-directory","--index","-p","--port","-i","--interfaces","-a","--auth","--auth-file",
                "--route-prefix","-S","--default-sorting-method","-O","--default-sorting-order","-c","--color-scheme",
                "-d","--color-scheme-dark","--web-upload-files-concurrency","--chmod","-m","--media-type","-M",
                "--raw-media-type","-o","--on-duplicate-files","-t","--title","--header","--tls-cert","--tls-key",
                "--size-display","--file-external-url").contains(a);
    }

    static void set(Config c, String key, String v) throws Exception {
        switch (key) {
            case "-p": case "--port": try { c.port = Integer.parseInt(v); } catch (Exception e) { throw err("error: invalid value '" + v + "' for '--port <PORT>': invalid digit found in string\n\nFor more information, try '--help'.\n"); } break;
            case "-i": case "--interfaces": c.bind = v; break;
            case "--index": c.index = v; break;
            case "-a": case "--auth": c.auth.add(v); break;
            case "--auth-file": c.auth.addAll(Files.readAllLines(Paths.get(v))); break;
            case "--route-prefix": c.routePrefix = v.startsWith("/") ? v : "/" + v; break;
            case "-S": case "--default-sorting-method": if (!List.of("name","size","date").contains(v)) throw err("error: invalid value '" + v + "' for '--default-sorting-method <DEFAULT_SORTING_METHOD>'\n  [possible values: name, size, date]\n\nFor more information, try '--help'.\n"); c.sortMethod = v; break;
            case "-O": case "--default-sorting-order": if (!List.of("asc","desc").contains(v)) throw err("error: invalid value '" + v + "' for '--default-sorting-order <DEFAULT_SORTING_ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.\n"); c.sortOrder = v; break;
            case "-o": case "--on-duplicate-files": c.duplicate = v; break;
            case "-t": case "--title": c.title = v; break;
            case "--header": int p = v.indexOf(':'); if (p > 0) c.customHeaders.put(v.substring(0,p).trim(), v.substring(p+1).trim()); break;
            case "--size-display": c.sizeDisplay = v; break;
            case "--file-external-url": c.externalUrl = v; break;
            default: break;
        }
    }

    static void env(Config c) {
        Map<String,String> e = System.getenv();
        if (e.containsKey("MINISERVE_PATH")) c.root = Paths.get(e.get("MINISERVE_PATH"));
        if (e.containsKey("MINISERVE_PORT")) try { c.port = Integer.parseInt(e.get("MINISERVE_PORT")); } catch(Exception ignored) {}
        if (e.containsKey("MINISERVE_INDEX")) c.index = e.get("MINISERVE_INDEX");
        if (e.containsKey("MINISERVE_SPA")) c.spa = truth(e.get("MINISERVE_SPA"));
        if (e.containsKey("MINISERVE_PRETTY_URLS")) c.pretty = truth(e.get("MINISERVE_PRETTY_URLS"));
        if (e.containsKey("MINISERVE_VERBOSE")) c.verbose = truth(e.get("MINISERVE_VERBOSE"));
        if (e.containsKey("MINISERVE_AUTH")) c.auth.add(e.get("MINISERVE_AUTH"));
    }
    static boolean truth(String s) { return s != null && !s.equals("") && !s.equals("0") && !s.equalsIgnoreCase("false"); }

    static class Handler implements HttpHandler {
        final Config c;
        Handler(Config c) { this.c = c; }
        public void handle(HttpExchange ex) throws IOException {
            try {
                applyHeaders(ex);
                if (!checkPrefix(ex)) return;
                if (!checkAuth(ex)) return;
                String method = ex.getRequestMethod();
                String relUri = stripPrefix(ex.getRequestURI().getRawPath());
                if (relUri.startsWith("/__miniserve_internal/")) { internal(ex); return; }
                if (method.equals("PROPFIND")) { propfind(ex, relUri); return; }
                if (method.equals("POST") && c.upload && relUri.equals("/upload")) { upload(ex); return; }
                if ((method.equals("DELETE") || (method.equals("POST") && relUri.endsWith("?delete"))) && c.rm) { delete(ex, relUri); return; }
                if (method.equals("POST") && c.mkdir && relUri.equals("/mkdir")) { mkdir(ex); return; }
                if (!method.equals("GET") && !method.equals("HEAD")) { sendText(ex, 405, "Method Not Allowed\n", "text/plain"); return; }
                serve(ex, relUri, method.equals("HEAD"));
            } catch (Exception e) {
                sendText(ex, 500, "Internal Server Error\n" + e.getMessage() + "\n", "text/plain");
            } finally {
                if (c.verbose) System.out.println(ex.getRequestMethod() + " " + ex.getRequestURI() + " " + ex.getRemoteAddress());
            }
        }

        void applyHeaders(HttpExchange ex) {
            for (Map.Entry<String,String> h : c.customHeaders.entrySet()) ex.getResponseHeaders().add(h.getKey(), h.getValue());
        }

        boolean checkPrefix(HttpExchange ex) throws IOException {
            if (c.routePrefix.isEmpty()) return true;
            String p = ex.getRequestURI().getRawPath();
            if (p.equals(c.routePrefix)) { redirect(ex, c.routePrefix + "/"); return false; }
            if (!p.startsWith(c.routePrefix + "/")) { notFound(ex); return false; }
            return true;
        }
        String stripPrefix(String raw) {
            String p = raw;
            if (!c.routePrefix.isEmpty() && p.startsWith(c.routePrefix)) p = p.substring(c.routePrefix.length());
            return p.isEmpty() ? "/" : p;
        }

        boolean checkAuth(HttpExchange ex) throws IOException {
            if (c.auth.isEmpty()) return true;
            String a = ex.getRequestHeaders().getFirst("Authorization");
            if (a != null && a.startsWith("Basic ")) {
                String dec = new String(Base64.getDecoder().decode(a.substring(6)), StandardCharsets.UTF_8);
                for (String rule : c.auth) if (authMatches(rule.trim(), dec)) return true;
            }
            ex.getResponseHeaders().set("WWW-Authenticate", "Basic realm=\"miniserve\"");
            sendText(ex, 401, "Authentication required\n", "text/plain");
            return false;
        }

        boolean authMatches(String rule, String up) {
            String[] r = rule.split(":", 3);
            int idx = up.indexOf(':');
            if (idx < 0 || r.length < 2 || !up.substring(0, idx).equals(r[0])) return false;
            String pass = up.substring(idx + 1);
            if (r.length == 2) return pass.equals(r[1]);
            if (r.length == 3 && (r[1].equals("sha256") || r[1].equals("sha512"))) {
                try { return hex(MessageDigest.getInstance(r[1].equals("sha256") ? "SHA-256" : "SHA-512").digest(pass.getBytes(StandardCharsets.UTF_8))).equalsIgnoreCase(r[2]); } catch(Exception ignored) {}
            }
            return false;
        }

        void serve(HttpExchange ex, String rel, boolean head) throws IOException {
            Path target = resolve(rel);
            if (target == null || (c.noSymlinks && Files.isSymbolicLink(target))) { notFound(ex); return; }
            if (!Files.exists(target)) {
                if (c.pretty && !rel.endsWith(".html")) {
                    Path html = resolve(rel + ".html");
                    if (html != null && Files.isRegularFile(html)) { file(ex, html, head); return; }
                }
                if (c.spa && c.index != null) {
                    Path idx = c.root.resolve(c.index).normalize();
                    if (Files.isRegularFile(idx)) { file(ex, idx, head); return; }
                }
                notFound(ex); return;
            }
            if (Files.isDirectory(target)) {
                if (!rel.endsWith("/")) { redirect(ex, addPrefix(rel + "/")); return; }
                if (c.index != null && Files.isRegularFile(target.resolve(c.index))) { file(ex, target.resolve(c.index), head); return; }
                if (archiveRequested(ex, target, rel, head)) return;
                if (c.disableIndexing) { sendText(ex, 403, "Directory listing disabled\n", "text/plain"); return; }
                listing(ex, target, rel, head);
            } else file(ex, target, head);
        }

        Path resolve(String rel) {
            try {
                String decoded = URLDecoder.decode(rel, StandardCharsets.UTF_8);
                while (decoded.startsWith("/")) decoded = decoded.substring(1);
                Path p = c.root.resolve(decoded).normalize();
                return p.startsWith(c.root) ? p : null;
            } catch (Exception e) { return null; }
        }

        void file(HttpExchange ex, Path f, boolean head) throws IOException {
            long size = Files.size(f);
            Headers h = ex.getResponseHeaders();
            h.set("Content-Type", mime(f));
            h.set("Content-Disposition", "inline; filename=\"" + f.getFileName() + "\"");
            h.set("Accept-Ranges", "bytes");
            h.set("Last-Modified", DateTimeFormatter.RFC_1123_DATE_TIME.format(Files.getLastModifiedTime(f).toInstant().atZone(ZoneId.of("GMT"))));
            String range = ex.getRequestHeaders().getFirst("Range");
            if (range != null && range.startsWith("bytes=")) {
                long[] r = parseRange(range, size);
                if (r != null) {
                    h.set("Content-Range", "bytes " + r[0] + "-" + r[1] + "/" + size);
                    ex.sendResponseHeaders(206, head ? -1 : r[1]-r[0]+1);
                    if (!head) try (OutputStream os = ex.getResponseBody(); InputStream is = Files.newInputStream(f)) { is.skip(r[0]); copyN(is, os, r[1]-r[0]+1); }
                    return;
                }
            }
            ex.sendResponseHeaders(200, head ? -1 : size);
            if (!head) try (OutputStream os = ex.getResponseBody()) { Files.copy(f, os); }
        }

        long[] parseRange(String range, long size) {
            try {
                String s = range.substring(6).split(",",2)[0];
                String[] p = s.split("-",2);
                long start = p[0].isEmpty() ? Math.max(0, size - Long.parseLong(p[1])) : Long.parseLong(p[0]);
                long end = p.length < 2 || p[1].isEmpty() ? size - 1 : Long.parseLong(p[1]);
                if (start < 0 || end < start || start >= size) return null;
                return new long[]{start, Math.min(end, size - 1)};
            } catch(Exception e) { return null; }
        }

        void listing(HttpExchange ex, Path dir, String rel, boolean head) throws IOException {
            List<Path> entries = new ArrayList<>();
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
                for (Path p : ds) {
                    String n = p.getFileName().toString();
                    if (!c.hidden && n.startsWith(".")) continue;
                    if (c.noSymlinks && Files.isSymbolicLink(p)) continue;
                    entries.add(p);
                }
            }
            entries.sort(comparator(ex));
            String host = c.title != null ? c.title : Optional.ofNullable(ex.getRequestHeaders().getFirst("Host")).orElse("localhost");
            StringBuilder sb = new StringBuilder();
            sb.append("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>").append(esc(host)).append("</title>")
                    .append("<style>body{font-family:sans-serif;margin:2em}table{border-collapse:collapse;width:100%}td,th{padding:.35em;border-bottom:1px solid #ddd;text-align:left}.size{text-align:right}.footer{margin-top:2em;color:#777}</style></head><body>");
            sb.append("<h1 class=\"title\"><span><bdi>").append(esc(host)).append("</bdi></span>").append(esc(rel)).append("</h1>");
            if (c.upload) sb.append("<form method=\"post\" enctype=\"multipart/form-data\" action=\"").append(addPrefix("/upload?path=")).append(url(rel)).append("\"><input type=\"file\" name=\"path\" multiple><button>Upload</button></form>");
            if (c.mkdir) sb.append("<form method=\"post\" action=\"").append(addPrefix("/mkdir?path=")).append(url(rel)).append("\"><input name=\"name\"><button>Create directory</button></form>");
            sb.append("<table><thead><tr><th>Name</th><th class=\"size\">Size</th><th>Last modification</th></tr></thead><tbody>");
            if (!rel.equals("/")) sb.append("<tr class=\"entry-type-directory\"><td><a class=\"directory\" href=\"../\">../</a></td><td></td><td></td></tr>");
            for (Path p : entries) {
                boolean d = Files.isDirectory(p);
                String name = p.getFileName().toString() + (d ? "/" : "");
                String href = (c.externalUrl == null ? "" : c.externalUrl) + addPrefix(join(rel, name));
                sb.append("<tr class=\"entry-type-").append(d ? "directory" : "file").append("\"><td><a class=\"").append(d ? "directory" : "file").append("\" href=\"").append(urlPath(href)).append("\">").append(esc(name)).append("</a></td><td class=\"size\">").append(d ? "" : size(Files.size(p))).append("</td><td>").append(time(p)).append("</td></tr>");
            }
            sb.append("</tbody></table>");
            if (c.readme && Files.isRegularFile(dir.resolve("README.md"))) sb.append("<h2>README.md</h2><pre>").append(esc(Files.readString(dir.resolve("README.md")))).append("</pre>");
            if (c.wgetFooter) sb.append("<div class=\"wget\">wget -r ").append(esc("http://" + Optional.ofNullable(ex.getRequestHeaders().getFirst("Host")).orElse("localhost") + addPrefix(rel))).append("</div>");
            if (!c.hideFooter) sb.append("<div class=\"footer\"><a href=\"https://github.com/svenstaro/miniserve\">miniserve</a>/").append(VERSION).append("</div>");
            sb.append("</body></html>");
            sendBytes(ex, 200, sb.toString().getBytes(StandardCharsets.UTF_8), "text/html; charset=utf-8", head);
        }

        Comparator<Path> comparator(HttpExchange ex) {
            Map<String,String> q = query(ex.getRequestURI().getRawQuery());
            String sm = q.getOrDefault("sort", c.sortMethod);
            String order = q.getOrDefault("order", c.sortOrder);
            Comparator<Path> cmp;
            if (sm.equals("size")) cmp = Comparator.comparingLong(p -> { try { return Files.isDirectory(p) ? 0 : Files.size(p); } catch(IOException e) { return 0; }});
            else if (sm.equals("date")) cmp = Comparator.comparingLong(p -> { try { return Files.getLastModifiedTime(p).toMillis(); } catch(IOException e) { return 0; }});
            else cmp = Comparator.comparing(p -> p.getFileName().toString().toLowerCase(Locale.ROOT));
            if (c.dirsFirst) cmp = Comparator.comparing((Path p) -> !Files.isDirectory(p)).thenComparing(cmp);
            if (order.equals("desc")) cmp = cmp.reversed();
            return cmp;
        }

        boolean archiveRequested(HttpExchange ex, Path dir, String rel, boolean head) throws IOException {
            String q = Optional.ofNullable(ex.getRequestURI().getRawQuery()).orElse("");
            if (c.zip && q.contains("download=zip")) { zip(ex, dir, false); return true; }
            if ((c.tar || c.targz) && (q.contains("download=tar") || q.contains("download=tar.gz"))) { zip(ex, dir, q.contains("gz")); return true; }
            return false;
        }

        void zip(HttpExchange ex, Path dir, boolean gzip) throws IOException {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            OutputStream out = gzip ? new GZIPOutputStream(baos) : new ZipOutputStream(baos);
            if (out instanceof ZipOutputStream zos) {
                Files.walk(dir).filter(Files::isRegularFile).forEach(p -> {
                    try { zos.putNextEntry(new ZipEntry(dir.relativize(p).toString())); Files.copy(p, zos); zos.closeEntry(); } catch(IOException ignored) {}
                });
            }
            out.close();
            sendBytes(ex, 200, baos.toByteArray(), gzip ? "application/gzip" : "application/zip", false);
        }

        void upload(HttpExchange ex) throws IOException {
            Map<String,String> q = query(ex.getRequestURI().getRawQuery());
            Path base = resolve(q.getOrDefault("path", "/"));
            if (base == null || !Files.isDirectory(base)) { notFound(ex); return; }
            String ct = ex.getRequestHeaders().getFirst("Content-Type");
            byte[] body = ex.getRequestBody().readAllBytes();
            if (ct != null && ct.contains("multipart/form-data")) {
                String boundary = "--" + ct.substring(ct.indexOf("boundary=") + 9);
                String s = new String(body, StandardCharsets.ISO_8859_1);
                int fn = s.indexOf("filename=\"");
                if (fn >= 0) {
                    int fe = s.indexOf('"', fn + 10);
                    String name = Paths.get(s.substring(fn + 10, fe)).getFileName().toString();
                    int start = s.indexOf("\r\n\r\n", fe) + 4;
                    int end = s.indexOf("\r\n" + boundary, start);
                    if (end > start) Files.write(unique(base.resolve(name)), Arrays.copyOfRange(body, start, end));
                }
            }
            sendText(ex, 200, "OK\n", "text/plain");
        }
        Path unique(Path p) throws IOException {
            if (!Files.exists(p) || c.duplicate.equals("overwrite")) return p;
            if (c.duplicate.equals("error")) throw new FileAlreadyExistsException(p.toString());
            String n = p.getFileName().toString(), base = n, ext = "";
            int dot = n.lastIndexOf('.');
            if (dot > 0) { base = n.substring(0,dot); ext = n.substring(dot); }
            for (int i=1;;i++) { Path x = p.resolveSibling(base + "-" + i + ext); if (!Files.exists(x)) return x; }
        }

        void mkdir(HttpExchange ex) throws IOException {
            Map<String,String> q = query(ex.getRequestURI().getRawQuery());
            Path base = resolve(q.getOrDefault("path", "/"));
            String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            String name = query(body).getOrDefault("name", "new-directory");
            if (base != null) Files.createDirectories(base.resolve(name).normalize());
            redirect(ex, addPrefix(q.getOrDefault("path", "/")));
        }
        void delete(HttpExchange ex, String rel) throws IOException {
            Path p = resolve(rel);
            if (p == null || p.equals(c.root)) { notFound(ex); return; }
            if (Files.isDirectory(p)) Files.walk(p).sorted(Comparator.reverseOrder()).forEach(x -> { try { Files.deleteIfExists(x); } catch(IOException ignored) {} });
            else Files.deleteIfExists(p);
            sendText(ex, 200, "OK\n", "text/plain");
        }
        void propfind(HttpExchange ex, String rel) throws IOException {
            if (!c.webdav) { sendText(ex, 405, "Method Not Allowed\n", "text/plain"); return; }
            Path p = resolve(rel);
            if (p == null || !Files.exists(p)) { notFound(ex); return; }
            String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><D:multistatus xmlns:D=\"DAV:\"><D:response><D:href>" + esc(addPrefix(rel)) + "</D:href><D:propstat><D:prop><D:displayname>" + esc(p.getFileName()==null?"":p.getFileName().toString()) + "</D:displayname></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response></D:multistatus>";
            sendBytes(ex, 207, xml.getBytes(StandardCharsets.UTF_8), "application/xml; charset=utf-8", false);
        }
        void internal(HttpExchange ex) throws IOException {
            if (ex.getRequestURI().getPath().endsWith("favicon.svg")) sendText(ex, 200, "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\"><text y=\"48\" font-size=\"48\">m</text></svg>", "image/svg+xml");
            else if (ex.getRequestURI().getPath().endsWith("style.css")) sendText(ex, 200, "body{font-family:sans-serif}", "text/css");
            else sendText(ex, 200, "~", "text/plain");
        }
        void notFound(HttpExchange ex) throws IOException { sendText(ex, 404, "<!DOCTYPE html><html><head><title>404 Not Found</title></head><body><h1>404 Not Found</h1></body></html>", "text/html"); }
        void redirect(HttpExchange ex, String loc) throws IOException { ex.getResponseHeaders().set("Location", loc); ex.sendResponseHeaders(307, -1); ex.close(); }
        String addPrefix(String p) { return (c.routePrefix == null ? "" : c.routePrefix) + (p.startsWith("/") ? p : "/" + p); }
    }

    static void sendText(HttpExchange ex, int code, String s, String type) throws IOException { sendBytes(ex, code, s.getBytes(StandardCharsets.UTF_8), type, false); }
    static void sendBytes(HttpExchange ex, int code, byte[] b, String type, boolean head) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(code, head ? -1 : b.length);
        if (!head) try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }
    static void copyN(InputStream is, OutputStream os, long n) throws IOException { byte[] buf = new byte[8192]; while(n>0) { int r = is.read(buf,0,(int)Math.min(buf.length,n)); if(r<0) break; os.write(buf,0,r); n-=r; } }
    static String hex(byte[] b) { StringBuilder s = new StringBuilder(); for(byte x:b) s.append(String.format("%02x", x)); return s.toString(); }
    static String esc(String s) { return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
    static String url(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    static String urlPath(String s) { return s.replace(" ", "%20").replace("#", "%23"); }
    static String join(String rel, String name) { return (rel.endsWith("/") ? rel : rel + "/") + name; }
    static String time(Path p) { try { return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss XXX").format(Files.getLastModifiedTime(p).toInstant().atZone(ZoneId.systemDefault())); } catch(IOException e) { return ""; } }
    static String size(long n) {
        if (n < 1024) return n + " B";
        String[] u = {"KiB","MiB","GiB","TiB"}; double d = n; int i=-1; do { d/=1024; i++; } while(d>=1024 && i<u.length-1);
        return String.format(Locale.ROOT, d >= 10 ? "%.0f %s" : "%.1f %s", d, u[i]);
    }
    static Map<String,String> query(String q) {
        Map<String,String> m = new HashMap<>(); if (q == null) return m;
        for (String part : q.split("&")) { int p=part.indexOf('='); if(p>=0) m.put(dec(part.substring(0,p)), dec(part.substring(p+1))); else if(!part.isEmpty()) m.put(dec(part), ""); }
        return m;
    }
    static String dec(String s) { return URLDecoder.decode(s.replace("+","%2B"), StandardCharsets.UTF_8); }
    static String mime(Path p) throws IOException {
        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html; charset=utf-8";
        if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".log")) return "text/plain; charset=utf-8";
        if (n.endsWith(".css")) return "text/css; charset=utf-8";
        if (n.endsWith(".js")) return "application/javascript";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".gif")) return "image/gif";
        String t = Files.probeContentType(p);
        return t == null ? "application/octet-stream" : t;
    }

    static String shortHelp() { return "For when you really just want to serve some files over HTTP right now!\n\nUsage: executable [OPTIONS] [PATH]\n\nArguments:\n  [PATH]  Which path to serve [env: MINISERVE_PATH=]\n\nOptions:\n  -p, --port <PORT>  Port to use [default: 8080]\n  -h, --help         Print help (see more with '--help')\n  -V, --version      Print version\n"; }
    static String longHelp() { return "For when you really just want to serve some files over HTTP right now!\n\nUsage: executable [OPTIONS] [PATH]\n\nArguments:\n  [PATH]\n          Which path to serve\n          \n          [env: MINISERVE_PATH=]\n\nOptions:\n  -v, --verbose\n          Be verbose, includes emitting access logs\n  --index <INDEX>\n          The name of a directory index file to serve, like \"index.html\"\n  --spa\n          Activate SPA (Single Page Application) mode\n  --pretty-urls\n          Activate Pretty URLs mode\n  -p, --port <PORT>\n          Port to use\n          [default: 8080]\n  -i, --interfaces <INTERFACES>\n          Interface to listen on\n  -a, --auth <AUTH>\n          Set authentication\n  --auth-file <AUTH_FILE>\n          Read authentication values from a file\n  --route-prefix <ROUTE_PREFIX>\n          Use a specific route prefix\n  --random-route\n          Generate a random 6-hexdigit route\n  -P, --no-symlinks\n          Hide symlinks in listing and prevent them from being followed\n  -H, --hidden\n          Show hidden files\n  -S, --default-sorting-method <DEFAULT_SORTING_METHOD>\n          Default sorting method for file list [possible values: name, size, date]\n  -O, --default-sorting-order <DEFAULT_SORTING_ORDER>\n          Default sorting order for file list [possible values: asc, desc]\n  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]\n          Enable file uploading\n  -U, --mkdir\n          Enable creating directories\n  -R, --rm-files [<ALLOWED_RM_DIR>]\n          Enable file and directory deletion\n  -r, --enable-tar\n  -g, --enable-tar-gz\n  -z, --enable-zip\n  -D, --dirs-first\n  -t, --title <TITLE>\n  --header <HEADER>\n  --readme\n  -I, --disable-indexing\n  --enable-webdav\n  --size-display <SIZE_DISPLAY>\n  --file-external-url <FILE_EXTERNAL_URL>\n  -h, --help\n          Print help (see a summary with '-h')\n  -V, --version\n          Print version\n"; }
    static String manpage() { return ".TH miniserve 1 \"\" \"miniserve " + VERSION + "\"\n.SH NAME\nminiserve \\- For when you really just want to serve some files over HTTP right now!\n.SH SYNOPSIS\nminiserve [OPTIONS] [PATH]\n"; }
}
