package argcjava;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Argc {
    static class Cmd {
        String name="", fn=null, describe="", version=null;
        List<String> aliases=new ArrayList<>();
        List<Opt> opts=new ArrayList<>();
        List<Pos> pos=new ArrayList<>();
        List<Env> envs=new ArrayList<>();
        List<Cmd> subs=new ArrayList<>();
        Map<String,String> meta=new LinkedHashMap<>();
        Cmd parent;
        boolean defaultSub=false;
    }
    static class Opt {
        String id,longName,shortName,desc="", def=null, delim=null;
        boolean flag, required, multi, terminal, assigned, prefixed;
        int minArgs, maxArgs;
        List<String> notations=new ArrayList<>(), choices=null;
    }
    static class Pos {
        String id, desc="", notation, def=null, delim=null;
        boolean required, multi, terminal;
        List<String> choices=null;
    }
    static class Env {
        String name, def=null; boolean required; List<String> choices=null;
    }
    static class ParseResult {
        Cmd cmd; List<String> positionals=new ArrayList<>(); Map<String,Object> vals=new LinkedHashMap<>();
        List<String> callArgs=new ArrayList<>(); boolean help=false, version=false; String error=null;
    }

    public static void main(String[] args) throws Exception {
        if (args.length==0 || args[0].equals("--help")) { defaultRun(args); return; }
        switch(args[0]) {
            case "--argc-help": printArgcHelp(); return;
            case "--argc-version": System.out.println("argc 1.23.0"); return;
            case "--version": defaultRun(args); return;
            case "--argc-eval": argcEval(Arrays.copyOfRange(args,1,args.length)); return;
            case "--argc-export": argcExport(Arrays.copyOfRange(args,1,args.length)); return;
            case "--argc-compgen": argcCompgen(Arrays.copyOfRange(args,1,args.length)); return;
            case "--argc-run": argcRun(Arrays.copyOfRange(args,1,args.length)); return;
            case "--argc-script-path": System.out.println(findArgcFile()); return;
            case "--argc-shell-path": System.out.println("/usr/bin/env bash"); return;
            case "--argc-create": argcCreate(Arrays.copyOfRange(args,1,args.length)); return;
            case "--argc-build":
            case "--argc-mangen":
            case "--argc-completions":
            case "--argc-parallel":
                System.err.println("error: unsupported command `" + args[0] + "`");
                System.exit(1);
            default: defaultRun(args);
        }
    }

    static void defaultRun(String[] args) {
        System.err.println("Argcfile not found, try `argc --argc-help` for help.");
        System.exit(1);
    }

    static void printArgcHelp() {
        System.out.println("A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n");
        System.out.println("USAGE:");
        System.out.println("    argc --argc-eval <FILE> <ARGS~>            Use `eval \"$(argc --argc-eval \"$0\" \"$@\")\"`");
        System.out.println("    argc --argc-create <RECIPES~>              Create a boilerplate argcfile");
        System.out.println("    argc --argc-run <FILE> <ARGS~>             Run an argc-based script");
        System.out.println("    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency");
        System.out.println("    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages");
        System.out.println("    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts");
        System.out.println("    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates");
        System.out.println("    argc --argc-export <FILE>                  Export command line definitions as json");
        System.out.println("    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel");
        System.out.println("    argc --argc-script-path                    Print current argcfile path");
        System.out.println("    argc --argc-shell-path                     Print current shell path");
        System.out.println("    argc --argc-help                           Print help information");
        System.out.println("    argc --argc-version                        Print version information");
    }

    static void argcEval(String[] a) throws Exception {
        if (a.length<1) { System.err.println("error: missing FILE"); System.exit(1); }
        Path file=Paths.get(a[0]); Cmd root=parse(file); root.name=baseName(file);
        ParseResult pr=parseArgs(root, Arrays.copyOfRange(a,1,a.length));
        if (pr.help) { emitCat(helpText(root, pr.cmd), 0); return; }
        if (pr.version) { emitCat((pr.cmd.version!=null?pr.cmd.version:"")+"\n",0); return; }
        if (pr.error!=null) { emitCat(pr.error+"\n",1); return; }
        System.out.print(shellCode(root, pr, Arrays.copyOfRange(a,1,a.length)));
    }

    static void argcExport(String[] a) throws Exception {
        if (a.length<1) return;
        Cmd root=parse(Paths.get(a[0])); root.name=baseName(Paths.get(a[0]));
        System.out.println(toJson(root,0));
    }

    static void argcCompgen(String[] a) throws Exception {
        if (a.length<3) return;
        Cmd root=parse(Paths.get(a[1])); root.name=baseName(Paths.get(a[1]));
        List<String> toks=new ArrayList<>(Arrays.asList(Arrays.copyOfRange(a,3,a.length)));
        Cmd cmd=resolveCmdForComp(root,toks);
        String last=toks.isEmpty()?"":toks.get(toks.size()-1);
        if (last.startsWith("-") || last.startsWith("+")) {
            for (Opt o: allOpts(cmd)) {
                if (o.longName!=null) System.out.println(o.longName + " " + (o.desc.isEmpty()?"":"("+o.desc+")"));
                else if (o.shortName!=null) System.out.println(o.shortName + " " + (o.desc.isEmpty()?"":"("+o.desc+")"));
            }
        } else {
            for (Cmd c: cmd.subs) System.out.println(c.name + " " + (c.describe.isEmpty()?"":"("+c.describe+")"));
        }
    }

    static void argcRun(String[] a) throws Exception {
        if (a.length<1) return;
        Path exe=Paths.get(System.getProperty("user.dir"), "executable").toAbsolutePath();
        List<String> cmd=new ArrayList<>();
        cmd.add("bash"); cmd.add("-lc");
        StringBuilder sb=new StringBuilder();
        sb.append("argc(){ ").append(sh(exe.toString())).append(" \"$@\"; }; export -f argc; ");
        sb.append("source ").append(sh(a[0])).append(" ");
        for (int i=1;i<a.length;i++) sb.append(sh(a[i])).append(" ");
        Process p=new ProcessBuilder(cmd.get(0),cmd.get(1),sb.toString()).inheritIO().start();
        System.exit(p.waitFor());
    }

    static void argcCreate(String[] a) {
        for (String r:a) {
            String fn=r.replace('-','_');
            System.out.println("# @cmd\n" + fn + "() {\n    :\n}\n");
        }
    }

    static Cmd parse(Path file) throws IOException {
        List<String> lines=Files.readAllLines(file, StandardCharsets.UTF_8);
        Cmd root=new Cmd(); root.name=baseName(file);
        List<String> block=new ArrayList<>(); boolean rootDone=false;
        for (String line: lines) {
            String t=line.trim();
            if (t.startsWith("#")) {
                String c=t.substring(1);
                if (c.startsWith(" ")) c=c.substring(1);
                if (c.startsWith("@") || (!block.isEmpty() && !c.startsWith("@") && !c.startsWith("!"))) block.add(c);
                continue;
            }
            Matcher m=Pattern.compile("^([A-Za-z0-9_:+-]+)\\s*\\(\\)\\s*\\{.*").matcher(t);
            if (!m.matches()) m=Pattern.compile("^function\\s+([A-Za-z0-9_:+-]+)\\s*.*").matcher(t);
            if (m.matches()) {
                String fn=m.group(1);
                if (hasTag(block,"@cmd")) {
                    int ci=lastTag(block,"@cmd");
                    if (!rootDone && ci>0) {
                        applyBlock(root, new ArrayList<>(block.subList(0, ci)));
                    }
                    Cmd c=new Cmd(); c.fn=fn; c.name=cmdName(fn); c.parent=root;
                    applyBlock(c, block.subList(ci, block.size()));
                    addCommand(root,c);
                    rootDone=true;
                } else if (fn.equals("main")) {
                    if (!rootDone && !block.isEmpty()) {
                        applyBlock(root, block);
                        rootDone=true;
                    }
                    root.meta.put("__main", "1");
                }
                block.clear();
                continue;
            }
            if (t.startsWith("eval ") || t.startsWith("main()") || (!t.isEmpty() && !t.startsWith("#"))) {
                if (!rootDone && !block.isEmpty()) { applyBlock(root, block); rootDone=true; }
                if (!t.isEmpty() && !t.startsWith("#")) block.clear();
            }
        }
        if (!rootDone && !block.isEmpty()) applyBlock(root, block);
        addBuiltins(root);
        return root;
    }

    static boolean hasTag(List<String> b,String tag){ for(String s:b) if(s.startsWith(tag)) return true; return false; }
    static int lastTag(List<String> b,String tag){ int n=-1; for(int i=0;i<b.size();i++) if(b.get(i).startsWith(tag)) n=i; return n; }

    static void applyBlock(Cmd c, List<String> b) {
        String last=null;
        for (String raw:b) {
            String s=raw.trim();
            if (s.isEmpty()) continue;
            if (s.startsWith("@describe")) { c.describe=rest(s,"@describe"); last="describe"; }
            else if (s.startsWith("@cmd")) { String r=rest(s,"@cmd"); if(!r.isEmpty()) c.describe=r; last="cmd"; }
            else if (s.startsWith("@alias")) { c.aliases.addAll(Arrays.asList(rest(s,"@alias").trim().split("\\s+"))); last="alias"; }
            else if (s.startsWith("@meta")) { parseMeta(c, rest(s,"@meta")); last="meta"; }
            else if (s.startsWith("@flag")) { c.opts.add(parseOpt(rest(s,"@flag"), true)); last="flag"; }
            else if (s.startsWith("@option")) { c.opts.add(parseOpt(rest(s,"@option"), false)); last="option"; }
            else if (s.startsWith("@arg")) { c.pos.add(parsePos(rest(s,"@arg"))); last="arg"; }
            else if (s.startsWith("@env")) { c.envs.add(parseEnv(rest(s,"@env"))); last="env"; }
            else if (!s.startsWith("@")) {
                if (("describe".equals(last)||"cmd".equals(last)) && !s.isEmpty()) c.describe = c.describe.isEmpty()?s:c.describe+"\n"+s;
                else if ("option".equals(last) && !c.opts.isEmpty()) c.opts.get(c.opts.size()-1).desc += (c.opts.get(c.opts.size()-1).desc.isEmpty()?"":"\n")+s;
                else if ("arg".equals(last) && !c.pos.isEmpty()) c.pos.get(c.pos.size()-1).desc += (c.pos.get(c.pos.size()-1).desc.isEmpty()?"":"\n")+s;
            }
        }
    }

    static void parseMeta(Cmd c,String r){
        if (r.startsWith("version ")) c.version=r.substring(8).trim();
        else if (r.equals("default-subcommand")) c.defaultSub=true;
        else c.meta.put(r.split("\\s+")[0], r);
    }

    static Opt parseOpt(String r, boolean flag) {
        Opt o=new Opt(); o.flag=flag; o.minArgs=flag?0:1; o.maxArgs=flag?0:1;
        List<String> toks=splitWords(r); int i=0;
        for (;i<toks.size();i++) {
            String tok=toks.get(i);
            if (tok.startsWith("<")) break;
            if (!(tok.startsWith("-")||tok.startsWith("+"))) break;
            if (tok.contains(":")) { o.assigned=true; tok=tok.substring(0,tok.indexOf(':')) + tok.substring(tok.indexOf(':')+1); }
            String core=stripSpec(tok,o);
            if (core.endsWith("-*")) { o.prefixed=true; core=core.substring(0,core.length()-1); }
            if (core.startsWith("--") || core.matches("^[+-][A-Za-z][A-Za-z0-9_-]+$")) {
                if (core.startsWith("--") || o.longName==null) o.longName=core;
                else o.shortName=core;
            } else o.shortName=core;
        }
        for (;i<toks.size();i++) {
            String tok=toks.get(i);
            if (tok.startsWith("<") && tok.endsWith(">")) o.notations.add(tok.substring(1,tok.length()-1));
            else { o.desc=join(toks.subList(i,toks.size())); break; }
        }
        if (!flag && !o.notations.isEmpty()) {
            o.minArgs=0; o.maxArgs=0;
            for (String n:o.notations) {
                if (n.endsWith("*")) { o.maxArgs=999; }
                else if (n.endsWith("+")) { o.minArgs++; o.maxArgs=999; }
                else if (n.endsWith("?")) { o.maxArgs++; }
                else { o.minArgs++; o.maxArgs++; }
            }
        }
        String primary=o.longName!=null?o.longName:o.shortName;
        o.id=idFrom(primary);
        return o;
    }

    static String stripSpec(String tok, Opt o) {
        int bi=tok.indexOf('[');
        if (bi>=0) {
            String inside=tok.substring(bi+1, tok.lastIndexOf(']'));
            parseChoiceDefault(inside, o);
            tok=tok.substring(0,bi);
        }
        if (tok.endsWith(",")) { o.delim=","; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("~")) { o.terminal=true; o.multi=true; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("*")) { o.multi=true; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("+")) { o.required=true; o.multi=true; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("!")) { o.required=true; tok=tok.substring(0,tok.length()-1); }
        int eq=tok.indexOf('=');
        if (eq>=0) { o.def=tok.substring(eq+1); tok=tok.substring(0,eq); }
        return tok;
    }

    static Pos parsePos(String r) {
        Pos p=new Pos(); List<String> toks=splitWords(r);
        String tok=toks.isEmpty()?"arg":toks.get(0);
        int bi=tok.indexOf('[');
        if (bi>=0) {
            String inside=tok.substring(bi+1,tok.lastIndexOf(']'));
            parseChoiceDefault(inside,p); tok=tok.substring(0,bi);
        }
        if (tok.endsWith(",")) { p.delim=","; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("~")) { p.terminal=true; p.multi=true; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("*") || tok.endsWith("...")) { p.multi=true; tok=tok.replaceFirst("(\\*|\\.\\.\\.)$",""); }
        if (tok.endsWith("+")) { p.required=true; p.multi=true; tok=tok.substring(0,tok.length()-1); }
        if (tok.endsWith("!")) { p.required=true; tok=tok.substring(0,tok.length()-1); }
        int eq=tok.indexOf('=');
        if (eq>=0) { p.def=tok.substring(eq+1); tok=tok.substring(0,eq); }
        p.id=tok.toLowerCase().replace('-','_');
        p.notation=toks.size()>1 && toks.get(1).startsWith("<") ? toks.get(1).replaceAll("[<>]","") : p.id.toUpperCase();
        int start=toks.size()>1 && toks.get(1).startsWith("<") ? 2 : 1;
        if (start<toks.size()) p.desc=join(toks.subList(start,toks.size()));
        return p;
    }

    static Env parseEnv(String r) {
        Env e=new Env(); List<String> toks=splitWords(r); String tok=toks.isEmpty()?"":toks.get(0);
        int bi=tok.indexOf('[');
        if (bi>=0) {
            String inside=tok.substring(bi+1,tok.lastIndexOf(']'));
            if (inside.startsWith("=")) { String[] ps=inside.substring(1).split("\\|"); e.def=ps[0]; e.choices=Arrays.asList(ps); }
            else if (!inside.startsWith("`")) e.choices=Arrays.asList(inside.split("\\|"));
            tok=tok.substring(0,bi);
        }
        if (tok.endsWith("!")) { e.required=true; tok=tok.substring(0,tok.length()-1); }
        int eq=tok.indexOf('=');
        if (eq>=0) { e.def=tok.substring(eq+1); tok=tok.substring(0,eq); }
        e.name=tok;
        return e;
    }

    static void parseChoiceDefault(String inside, Object obj) {
        boolean skip=inside.startsWith("?"); if (skip) inside=inside.substring(1);
        if (inside.startsWith("=")) {
            String[] ps=inside.substring(1).split("\\|");
            if (obj instanceof Opt) { ((Opt)obj).def=ps[0]; ((Opt)obj).choices=Arrays.asList(ps); }
            else { ((Pos)obj).def=ps[0]; ((Pos)obj).choices=Arrays.asList(ps); }
        } else if (!inside.startsWith("`") && !skip) {
            List<String> ch=Arrays.asList(inside.split("\\|"));
            if (obj instanceof Opt) ((Opt)obj).choices=ch; else ((Pos)obj).choices=ch;
        }
    }

    static void addCommand(Cmd root, Cmd c) {
        if (c.fn.contains("::")) {
            String[] parts=c.fn.split("::"); Cmd cur=root;
            for (int i=0;i<parts.length;i++) {
                String nm=cmdName(parts[i]); Cmd next=findSub(cur,nm);
                if (next==null) { next=new Cmd(); next.name=nm; next.fn=i==parts.length-1?c.fn:null; next.parent=cur; cur.subs.add(next); }
                cur=next;
            }
            cur.fn=c.fn; cur.describe=c.describe; cur.aliases=c.aliases; cur.opts=c.opts; cur.pos=c.pos;
        } else root.subs.add(c);
    }

    static void addBuiltins(Cmd root) {
        addHelpVersion(root);
        for (Cmd c: allCommands(root)) addHelp(c);
    }
    static void addHelpVersion(Cmd c){ addHelp(c); Opt v=new Opt(); v.flag=true; v.id="version"; v.longName="--version"; v.shortName="-V"; c.opts.add(v); }
    static void addHelp(Cmd c){ Opt h=new Opt(); h.flag=true; h.id="help"; h.longName="--help"; h.shortName="-h"; h.desc=c.parent==null?"":"Print help"; c.opts.add(h); }
    static List<Cmd> allCommands(Cmd r){ List<Cmd> out=new ArrayList<>(); for(Cmd c:r.subs){ out.add(c); out.addAll(allCommands(c)); } return out; }

    static ParseResult parseArgs(Cmd root, String[] args) {
        ParseResult pr=new ParseResult(); Cmd cmd=root; int idx=0;
        while (idx<args.length && !args[idx].startsWith("-") && !args[idx].startsWith("+")) {
            Cmd n=findSubAlias(cmd,args[idx]);
            if (n==null) break; cmd=n; idx++;
        }
        if (cmd==root && !root.subs.isEmpty()) {
            Cmd d=null; for(Cmd c:root.subs) if(c.defaultSub) d=c;
            if (d!=null) cmd=d; else if (idx<args.length && !args[idx].startsWith("-")) {
                pr.cmd=cmd; pr.error="error: `"+root.name+"` requires a subcommand but '"+args[idx]+"' is not one of them\n  [subcommands: "+subList(root)+"]"; return pr;
            }
        }
        pr.cmd=cmd;
        initDefaults(pr,cmd);
        validateEnvs(root,cmd,pr);
        if (pr.error!=null) return pr;
        List<String> rest=new ArrayList<>();
        List<Opt> opts=allOpts(cmd);
        for (;idx<args.length;idx++) {
            String a=args[idx];
            if (a.equals("--")) { for(idx++;idx<args.length;idx++) rest.add(args[idx]); break; }
            if (a.equals("-h")||a.equals("--help")) { pr.help=true; return pr; }
            if ((a.equals("-V")||a.equals("--version")) && cmd==root) { pr.version=true; return pr; }
            if (a.startsWith("-")||a.startsWith("+")) {
                boolean matched=false;
                if (cmd.meta.containsKey("combine-shorts") && a.matches("^-[A-Za-z]{2,}$")) {
                    matched=true;
                    for (int k=1;k<a.length();k++) {
                        Opt o=findOpt(opts,"-"+a.charAt(k));
                        if (o==null || !o.flag) { pr.error="error: unexpected argument `"+a+"` found"; return pr; }
                        setOpt(pr,o,Collections.emptyList());
                    }
                    continue;
                }
                String name=a, val=null;
                int eq=a.indexOf('=');
                if (eq>0) { name=a.substring(0,eq); val=a.substring(eq+1); }
                Opt o=findOpt(opts,name);
                if (o==null) { pr.error="error: unexpected argument `"+a+"` found"; return pr; }
                matched=true;
                List<String> vals=new ArrayList<>();
                if (!o.flag) {
                    if (val!=null) vals.add(val);
                    while(vals.size()<o.minArgs && idx+1<args.length) vals.add(args[++idx]);
                    while(vals.size()<o.maxArgs && o.maxArgs>=999 && idx+1<args.length && !args[idx+1].startsWith("-")) vals.add(args[++idx]);
                    if (o.terminal) { while(idx+1<args.length) vals.add(args[++idx]); }
                    if (vals.size()<o.minArgs) { pr.error="error: a value is required for '"+name+" <"+o.id.toUpperCase()+">' but none was supplied"; return pr; }
                }
                setOpt(pr,o,vals);
            } else rest.add(a);
        }
        assignPositionals(pr,cmd,rest);
        if (pr.error!=null) return pr;
        List<String> missing=new ArrayList<>();
        for (Opt o: opts) if (o.required && !pr.vals.containsKey(o.id)) missing.add(optUsage(o));
        for (Pos p: cmd.pos) if (p.required && !pr.vals.containsKey(p.id)) missing.add(posUsage(p));
        if (!missing.isEmpty()) pr.error="error: the following required arguments were not provided:\n  "+String.join("\n  ", missing);
        return pr;
    }

    static void initDefaults(ParseResult pr, Cmd cmd) {
        for (Opt o: allOpts(cmd)) if(o.def!=null) pr.vals.put(o.id, o.def);
        for (Pos p: cmd.pos) if(p.def!=null) pr.vals.put(p.id, p.def);
    }

    static void validateEnvs(Cmd root, Cmd cmd, ParseResult pr) {
        for (Env e: allEnvs(root,cmd)) {
            String v=System.getenv(e.name);
            if ((v==null || v.isEmpty()) && e.def!=null) v=e.def;
            if ((v==null || v.isEmpty()) && e.required) { pr.error="error: the following required environment variables were not provided:\n  "+e.name; return; }
            if (v!=null && e.choices!=null && !e.choices.contains(v)) { pr.error="error: invalid value `"+v+"` for environment variable `"+e.name+"`\n  [possible values: "+String.join(", ",e.choices)+"]"; return; }
        }
    }

    static void assignPositionals(ParseResult pr, Cmd cmd, List<String> rest) {
        int i=0;
        for (int pi=0;pi<cmd.pos.size();pi++) {
            Pos p=cmd.pos.get(pi); List<String> vals=new ArrayList<>();
            if (p.multi || p.terminal) { while(i<rest.size()) vals.add(rest.get(i++)); }
            else if (i<rest.size()) vals.add(rest.get(i++));
            if (p.delim!=null) vals=splitDelim(vals,p.delim);
            if (!vals.isEmpty()) {
                if (p.choices!=null) for(String v:vals) if(!p.choices.contains(v)) { pr.error="error: invalid value `"+v+"` for `"+posUsage(p)+"`\n  [possible values: "+String.join(", ",p.choices)+"]"; return; }
                pr.vals.put(p.id, p.multi?vals:vals.get(0)); pr.positionals.addAll(vals); pr.callArgs.addAll(vals);
            } else if (p.def!=null) { pr.positionals.add(p.def); pr.callArgs.add(p.def); }
        }
        if (i<rest.size()) pr.error="error: unexpected argument `"+rest.get(i)+"` found";
    }

    static void setOpt(ParseResult pr, Opt o, List<String> vals) {
        if (o.flag) {
            Object cur=pr.vals.get(o.id); int n=cur instanceof String?Integer.parseInt((String)cur):0; pr.vals.put(o.id, String.valueOf(n+1));
        } else {
            List<String> v=o.delim!=null?splitDelim(vals,o.delim):vals;
            if (o.choices!=null) for(String x:v) if(!o.choices.contains(x)) { pr.error="error: invalid value `"+x+"` for `"+(o.longName!=null?o.longName:o.shortName)+" <"+o.id.toUpperCase()+">`\n  [possible values: "+String.join(", ",o.choices)+"]"; return; }
            if (o.multi || o.maxArgs!=1 || o.delim!=null) {
                List<String> arr=(List<String>)pr.vals.getOrDefault(o.id,new ArrayList<String>());
                arr.addAll(v); pr.vals.put(o.id,arr);
            } else if (!v.isEmpty()) pr.vals.put(o.id,v.get(0));
        }
    }

    static String shellCode(Cmd root, ParseResult pr, String[] orig) {
        StringBuilder sb=new StringBuilder(); List<String> assigns=new ArrayList<>();
        for (Map.Entry<String,Object> e:pr.vals.entrySet()) {
            String var="argc_"+e.getKey();
            if (e.getValue() instanceof List) {
                sb.append(var).append("=( "); for(String v:(List<String>)e.getValue()) sb.append(sh(v)).append(" "); sb.append(")\n");
            } else {
                String v=String.valueOf(e.getValue());
                sb.append(var).append("=").append(v.startsWith("`")&&v.endsWith("`")?v:sh(v)).append("\n");
            }
        }
        for (Env e: allEnvs(root, pr.cmd)) {
            String v=System.getenv(e.name);
            if ((v==null || v.isEmpty()) && e.def!=null) {
                sb.append("export ").append(e.name).append("=").append(e.def.startsWith("`")&&e.def.endsWith("`")?e.def:sh(e.def)).append("\n");
            }
        }
        List<String> aa=new ArrayList<>(); aa.add(root.name); aa.addAll(Arrays.asList(orig));
        sb.append("argc__args=( "); for(String v:aa) sb.append(sh(v)).append(" "); sb.append(")\n");
        if (pr.cmd.fn!=null) sb.append("argc__fn=").append(sh(pr.cmd.fn)).append("\n");
        sb.append("argc__positionals=( "); for(String v:pr.positionals) sb.append(sh(v)).append(" "); sb.append(")\n");
        if (pr.cmd.fn!=null) { sb.append(pr.cmd.fn).append(" "); for(String v:pr.callArgs) sb.append(sh(v)).append(" "); sb.append("\n"); }
        else if (hasMain(root)) sb.append("main ").append("\n");
        return sb.toString();
    }

    static boolean hasMain(Cmd root){ return root.meta.containsKey("__main"); }

    static String helpText(Cmd root, Cmd cmd) {
        StringBuilder sb=new StringBuilder();
        if (!cmd.describe.isEmpty()) sb.append(cmd.describe).append("\n\n");
        sb.append("USAGE: ").append(usage(root,cmd)).append("\n");
        if (!cmd.subs.isEmpty()) {
            sb.append("\nCOMMANDS:\n");
            int w=0; for(Cmd c:cmd.subs) w=Math.max(w,c.name.length());
            for(Cmd c:cmd.subs) {
                sb.append("  ").append(pad(c.name,w+2)).append(c.describe.replace("\n"," "));
                List<String> al=new ArrayList<>(c.aliases); String hy=c.name.replace('_','-'); if(!hy.equals(c.name) && !al.contains(hy)) al.add(0,hy);
                if(!al.isEmpty()) sb.append(" [aliases: ").append(String.join(", ",al)).append("]");
                sb.append("\n");
            }
        }
        if (!cmd.pos.isEmpty()) {
            sb.append("\nARGS:\n"); int w=0; for(Pos p:cmd.pos) w=Math.max(w,posUsage(p).length());
            for(Pos p:cmd.pos) sb.append("  ").append(pad(posUsage(p),w+2)).append(p.desc).append("\n");
        }
        List<Opt> os=cmd.opts;
        if (!os.isEmpty() && cmd.subs.isEmpty()) {
            sb.append("\nOPTIONS:\n"); int w=0; List<String> us=new ArrayList<>();
            for(Opt o:os){ String u=optUsage(o); us.add(u); w=Math.max(w,u.length()); }
            for(int i=0;i<os.size();i++) sb.append("  ").append(pad(us.get(i),w+2)).append(os.get(i).desc.isEmpty()?builtinDesc(os.get(i)):os.get(i).desc).append("\n");
        }
        return sb.toString();
    }

    static String usage(Cmd root, Cmd cmd) {
        List<String> names=new ArrayList<>(); Cmd c=cmd; while(c!=null && c.parent!=null){ names.add(c.name); c=c.parent; } Collections.reverse(names);
        StringBuilder u=new StringBuilder(root.name); for(String n:names) u.append(" ").append(n);
        if (!cmd.opts.isEmpty() && cmd.subs.isEmpty()) u.append(" [OPTIONS]");
        for(Pos p:cmd.pos) u.append(" ").append(posUsage(p));
        if(!cmd.subs.isEmpty()) u.append(" <COMMAND>");
        return u.toString();
    }

    static String optUsage(Opt o) {
        String n="";
        if (o.shortName!=null && o.longName!=null) n=o.shortName+", "+o.longName; else n=o.longName!=null?o.longName:o.shortName;
        if (!o.flag) n+=" <"+(o.notations.isEmpty()?o.id.toUpperCase():o.notations.get(0).replaceAll("[*+?]$",""))+">"+(o.multi?"...":"");
        return n;
    }
    static String posUsage(Pos p){ String n=p.notation; String s=p.required?"<"+n+">":"["+n+"]"; if(p.multi) s+=(p.required?"...":"..."); return s; }
    static String builtinDesc(Opt o){ if(o.id.equals("help")) return "Print help"; if(o.id.equals("version")) return "Print version"; return ""; }

    static void emitCat(String text,int code) {
        System.out.println("command cat >&2 <<-'EOF' ");
        System.out.print(text);
        System.out.println("EOF");
        System.out.println("exit "+code);
    }

    static Cmd resolveCmdForComp(Cmd root,List<String> toks){
        Cmd cmd=root; for(String t:toks){ if(t.startsWith("-")||t.equals(root.name)) continue; Cmd n=findSubAlias(cmd,t); if(n!=null) cmd=n; }
        return cmd;
    }
    static List<Env> allEnvs(Cmd root, Cmd cmd){ List<Env> l=new ArrayList<>(); l.addAll(root.envs); if(cmd!=root) l.addAll(cmd.envs); return l; }
    static List<Opt> allOpts(Cmd c){ List<Opt> l=new ArrayList<>(); if(c.parent!=null && c.parent.meta.containsKey("inherit-flag-options")) l.addAll(c.parent.opts); l.addAll(c.opts); return l; }
    static Opt findOpt(List<Opt> opts,String n){ for(Opt o:opts) if(n.equals(o.longName)||n.equals(o.shortName)) return o; return null; }
    static Cmd findSub(Cmd c,String n){ for(Cmd s:c.subs) if(s.name.equals(n)) return s; return null; }
    static Cmd findSubAlias(Cmd c,String n){ for(Cmd s:c.subs){ if(s.name.equals(n)||s.name.replace('_','-').equals(n)||s.aliases.contains(n)) return s; } return null; }
    static String subList(Cmd c){ List<String> l=new ArrayList<>(); for(Cmd s:c.subs){ l.add(s.name); l.addAll(s.aliases); } return String.join(", ",l); }
    static String idFrom(String s){ return s.replaceFirst("^[+-]+","").replace('-','_').toLowerCase(); }
    static String cmdName(String fn){ String x=fn.contains("::")?fn.substring(fn.lastIndexOf("::")+2):fn; return x; }
    static String baseName(Path p){ String n=p.getFileName().toString(); return n.replaceFirst("\\.[^.]*$",""); }
    static String rest(String s,String tag){ return s.length()>tag.length()?s.substring(tag.length()).trim():""; }
    static List<String> splitWords(String s){ return s.trim().isEmpty()?new ArrayList<>():new ArrayList<>(Arrays.asList(s.trim().split("\\s+"))); }
    static String join(List<String> l){ return String.join(" ",l).trim(); }
    static List<String> splitDelim(List<String> vals,String d){ List<String> out=new ArrayList<>(); for(String v:vals) if(v!=null&&!v.isEmpty()) out.addAll(Arrays.asList(v.split(Pattern.quote(d)))); return out; }
    static String pad(String s,int w){ StringBuilder b=new StringBuilder(s); while(b.length()<w)b.append(' '); return b.toString(); }
    static String sh(String s){ if(s==null) return "''"; if(s.matches("[A-Za-z0-9_./:+@%=-]+")) return s; return "'" + s.replace("'","'\\''") + "'"; }
    static String findArgcFile(){ return Paths.get("Argcfile.sh").toAbsolutePath().toString(); }

    static String toJson(Cmd c,int ind) {
        String sp=" ".repeat(ind), sp2=" ".repeat(ind+2); StringBuilder sb=new StringBuilder();
        sb.append(sp).append("{\n");
        field(sb,sp2,"name",c.name,true); field(sb,sp2,"describe",c.describe,true); field(sb,sp2,"version",c.version,true);
        sb.append(sp2).append("\"aliases\": ").append(jsonArr(c.aliases)).append(",\n");
        sb.append(sp2).append("\"flag_options\": ["); for(int i=0;i<c.opts.size();i++){ if(i>0)sb.append(","); sb.append("\n").append(optJson(c.opts.get(i),ind+4)); } if(!c.opts.isEmpty()) sb.append("\n").append(sp2); sb.append("],\n");
        sb.append(sp2).append("\"positionals\": ["); for(int i=0;i<c.pos.size();i++){ if(i>0)sb.append(","); sb.append("\n").append(posJson(c.pos.get(i),ind+4)); } if(!c.pos.isEmpty()) sb.append("\n").append(sp2); sb.append("],\n");
        sb.append(sp2).append("\"envs\": [");
        for(int i=0;i<c.envs.size();i++){ if(i>0)sb.append(", "); sb.append(q(c.envs.get(i).name)); }
        sb.append("],\n");
        sb.append(sp2).append("\"subcommands\": ["); for(int i=0;i<c.subs.size();i++){ if(i>0)sb.append(","); sb.append("\n").append(toJson(c.subs.get(i),ind+4)); } if(!c.subs.isEmpty()) sb.append("\n").append(sp2); sb.append("],\n");
        sb.append(sp2).append("\"command_fn\": ").append(c.fn==null?"null":q(c.fn)).append("\n");
        sb.append(sp).append("}"); return sb.toString();
    }
    static String optJson(Opt o,int ind){ String sp=" ".repeat(ind); return sp+"{\"id\": "+q(o.id)+", \"long_name\": "+(o.longName==null?"null":q(o.longName))+", \"short_name\": "+(o.shortName==null?"null":q(o.shortName))+", \"describe\": "+q(o.desc)+", \"flag\": "+o.flag+"}"; }
    static String posJson(Pos p,int ind){ String sp=" ".repeat(ind); return sp+"{\"id\": "+q(p.id)+", \"describe\": "+q(p.desc)+", \"notation\": "+q(p.notation)+", \"required\": "+p.required+", \"multiple\": "+p.multi+"}"; }
    static void field(StringBuilder sb,String sp,String k,String v,boolean comma){ sb.append(sp).append(q(k)).append(": ").append(v==null?"null":q(v)).append(comma?",":"").append("\n"); }
    static String jsonArr(List<String> a){ StringBuilder sb=new StringBuilder("["); for(int i=0;i<a.size();i++){ if(i>0)sb.append(", "); sb.append(q(a.get(i))); } return sb.append("]").toString(); }
    static String q(String s){ return "\""+(s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"))+"\""; }
}
