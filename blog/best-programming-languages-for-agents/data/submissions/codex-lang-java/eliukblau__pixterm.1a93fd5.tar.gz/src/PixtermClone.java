import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PixtermClone {
    private static final String VERSION = "1.3.2";
    private static final String LOWER = "\u2584";
    private static final String[] BLOCKS = {" ", "\u2591", "\u2592", "\u2593", "\u2588"};
    private static final char[] ASCII = " .:-=+*#%@&X".toCharArray();

    static class Options {
        int dither = 0;
        int scale = 0;
        int columns = 80;
        int rows = 24;
        int matte = 0x000000;
        boolean noBg = false;
        boolean go = false;
        String image;
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) System.exit(code);
        } catch (PixtermException e) {
            banner();
            System.out.println();
            System.out.println("[PIXTERM ERROR] " + timestamp() + " " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            banner();
            System.out.println();
            String msg = e.getMessage();
            if (msg == null || msg.isEmpty()) msg = e.getClass().getSimpleName();
            System.out.println("[PIXTERM ERROR] " + timestamp() + " " + msg);
            System.exit(1);
        }
    }

    private static int run(String[] args) throws Exception {
        if (args.length == 0) {
            help();
            return 2;
        }
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-help":
                case "--help":
                    help();
                    return 0;
                case "-version":
                    System.out.println(VERSION);
                    return 0;
                case "-credits":
                    credits();
                    return 0;
                case "-go":
                    opt.go = true;
                    break;
                case "-nobg":
                    opt.noBg = true;
                    break;
                case "-d":
                    if (++i >= args.length) return usageError();
                    opt.dither = parseInt(args[i], -1);
                    if (opt.dither < 0 || opt.dither > 2) return usageError();
                    break;
                case "-s":
                    if (++i >= args.length) return usageError();
                    opt.scale = parseInt(args[i], -1);
                    if (opt.scale < 0 || opt.scale > 2) return usageError();
                    break;
                case "-tc":
                    if (++i >= args.length) return usageError();
                    opt.columns = parseInt(args[i], -1);
                    if (opt.columns < 2) return usageError();
                    break;
                case "-tr":
                    if (++i >= args.length) return usageError();
                    opt.rows = parseInt(args[i], -1);
                    if (opt.rows < 2) return usageError();
                    break;
                case "-m":
                    if (++i >= args.length) return usageError();
                    opt.matte = parseColor(args[i]);
                    break;
                default:
                    if (a.startsWith("-")) return usageError();
                    if (opt.image != null) return usageError();
                    opt.image = a;
            }
        }
        if (opt.image == null) return usageError();

        BufferedImage input = readImage(opt.image, opt.matte);
        BufferedImage scaled = scale(input, opt.columns, opt.rows * 2, opt.scale, opt.matte);
        String rendered = render(scaled, opt);
        if (opt.go) {
            for (String line : rendered.split("\n", -1)) {
                if (line.isEmpty()) continue;
                System.out.println("fmt.Print(\"" + escapeGo(line + "\n") + "\")");
            }
        } else {
            System.out.print(rendered);
        }
        return 0;
    }

    private static int usageError() {
        help();
        return 2;
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static int parseColor(String s) throws PixtermException {
        String v = s.trim();
        if (v.startsWith("#")) v = v.substring(1);
        if (v.length() == 3) {
            v = "" + v.charAt(0) + v.charAt(0) + v.charAt(1) + v.charAt(1) + v.charAt(2) + v.charAt(2);
        }
        if (!v.matches("[0-9a-fA-F]{6}")) throw new PixtermException("matte color : " + s + " is not a hex-color");
        return Integer.parseInt(v, 16);
    }

    private static BufferedImage readImage(String path, int matte) throws IOException, PixtermException {
        BufferedImage img;
        if (path.startsWith("http://") || path.startsWith("https://")) {
            img = ImageIO.read(new URL(path));
            if (img == null) throw new PixtermException("image: unknown format");
        } else {
            File f = new File(path);
            if (!f.exists()) throw new PixtermException("open " + path + ": no such file or directory");
            img = ImageIO.read(f);
            if (img == null) throw new PixtermException("image: unknown format");
        }
        BufferedImage out = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < img.getHeight(); y++) {
            for (int x = 0; x < img.getWidth(); x++) {
                out.setRGB(x, y, composite(img.getRGB(x, y), matte));
            }
        }
        return out;
    }

    private static int composite(int argb, int matte) {
        int a = (argb >>> 24) & 0xff;
        int r = (argb >>> 16) & 0xff;
        int g = (argb >>> 8) & 0xff;
        int b = argb & 0xff;
        int mr = (matte >>> 16) & 0xff;
        int mg = (matte >>> 8) & 0xff;
        int mb = matte & 0xff;
        r = (r * a + mr * (255 - a) + 127) / 255;
        g = (g * a + mg * (255 - a) + 127) / 255;
        b = (b * a + mb * (255 - a) + 127) / 255;
        return 0xff000000 | (r << 16) | (g << 8) | b;
    }

    private static BufferedImage scale(BufferedImage src, int targetW, int targetH, int mode, int matte) {
        int w = targetW, h = targetH;
        BufferedImage canvas = new BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_ARGB);
        Graphics2D cg = canvas.createGraphics();
        cg.setColor(new java.awt.Color(matte));
        cg.fillRect(0, 0, targetW, targetH);
        cg.dispose();

        double sx = targetW / (double) src.getWidth();
        double sy = targetH / (double) src.getHeight();
        int dx = 0, dy = 0;
        if (mode == 1 || mode == 2) {
            double scale = mode == 1 ? Math.max(sx, sy) : Math.min(sx, sy);
            w = Math.max(1, (int) Math.round(src.getWidth() * scale));
            h = Math.max(1, (int) Math.round(src.getHeight() * scale));
            dx = (targetW - w) / 2;
            dy = (targetH - h) / 2;
        }
        Graphics2D g = canvas.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(src, dx, dy, w, h, null);
        g.dispose();
        return canvas;
    }

    private static String render(BufferedImage img, Options opt) {
        StringBuilder sb = new StringBuilder();
        for (int y = 0; y < img.getHeight(); y += 2) {
            for (int x = 0; x < img.getWidth(); x++) {
                int top = img.getRGB(x, y);
                int bot = img.getRGB(x, Math.min(y + 1, img.getHeight() - 1));
                if (opt.dither == 0) {
                    ansiBg(sb, top);
                    ansiFg(sb, bot);
                    sb.append(LOWER);
                } else {
                    int c = average(top, bot);
                    if (!opt.noBg) ansiBg(sb, opt.matte | 0xff000000);
                    ansiFg(sb, c);
                    sb.append(opt.dither == 1 ? ditherBlock(c, x, y) : ditherAscii(c, x, y));
                }
            }
            sb.append("\u001b[0m\n");
        }
        return sb.toString();
    }

    private static int average(int a, int b) {
        int r = ((((a >>> 16) & 255) + ((b >>> 16) & 255)) / 2);
        int g = ((((a >>> 8) & 255) + ((b >>> 8) & 255)) / 2);
        int bl = (((a & 255) + (b & 255)) / 2);
        return 0xff000000 | (r << 16) | (g << 8) | bl;
    }

    private static String ditherBlock(int rgb, int x, int y) {
        int lum = luminance(rgb);
        int level = Math.max(0, Math.min(4, (lum + threshold(x, y)) * 5 / 256));
        return BLOCKS[level];
    }

    private static char ditherAscii(int rgb, int x, int y) {
        int lum = luminance(rgb);
        int level = Math.max(0, Math.min(ASCII.length - 1, (lum + threshold(x, y)) * ASCII.length / 256));
        return ASCII[level];
    }

    private static int threshold(int x, int y) {
        int[][] bayer = {{0, 8, 2, 10}, {12, 4, 14, 6}, {3, 11, 1, 9}, {15, 7, 13, 5}};
        return bayer[y & 3][x & 3] - 8;
    }

    private static int luminance(int rgb) {
        return (int) ((((rgb >>> 16) & 255) * 0.299) + (((rgb >>> 8) & 255) * 0.587) + ((rgb & 255) * 0.114));
    }

    private static void ansiBg(StringBuilder sb, int rgb) {
        sb.append("\u001b[48;2;").append((rgb >>> 16) & 255).append(';').append((rgb >>> 8) & 255).append(';').append(rgb & 255).append('m');
    }

    private static void ansiFg(StringBuilder sb, int rgb) {
        sb.append("\u001b[38;2;").append((rgb >>> 16) & 255).append(';').append((rgb >>> 8) & 255).append(';').append(rgb & 255).append('m');
    }

    private static String escapeGo(String s) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\u001b') out.append("\\033");
            else if (c == '\n') out.append("\\n");
            else if (c == '\\') out.append("\\\\");
            else if (c == '"') out.append("\\\"");
            else out.append(c);
        }
        return out.toString();
    }

    private static void banner() {
        System.out.print(
                "   ___  _____  ____\n" +
                "  / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau\n" +
                " / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm\n" +
                "/_/  /___/_/|_|\\__/\\__/_/ /_/_/_/                " + VERSION + "\n");
    }

    private static void help() {
        banner();
        System.out.print("\n" +
                "USAGE:\n\n" +
                "  executable [options] image/url\n\n" +
                "  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.\n" +
                "  Supported URL protocols: HTTP, HTTPS.\n\n" +
                "OPTIONS:\n\n" +
                "  -credits\n" +
                "    \tshow some love to contributors <3\n" +
                "  -d mode\n" +
                "    \tdithering mode:\n" +
                "    \t   0 - no dithering (default)\n" +
                "    \t   1 - with blocks\n" +
                "    \t   2 - with chars\n" +
                "  -go\n" +
                "    \toutput Go code to 'fmt.Print()' the image\n" +
                "  -m color\n" +
                "    \tmatte color for transparency or background\n" +
                "    \t(optional, hex format, default: 000000)\n" +
                "  -nobg\n" +
                "    \tdisable background color\n" +
                "    \t(optional, only in dithering mode, ignores matte color)\n" +
                "  -s method\n" +
                "    \tscale method:\n" +
                "    \t   0 - resize (default)\n" +
                "    \t   1 - fill\n" +
                "    \t   2 - fit\n" +
                "  -tc columns\n" +
                "    \tterminal columns (optional, >=2; when piping, default: 80)\n" +
                "  -tr rows\n" +
                "    \tterminal rows (optional, >=2; when piping, default: 24)\n" +
                "  -version\n" +
                "    \tshow PIXterm version\n" +
                "  -help\n" +
                "\tprints this message :D LOL\n\n");
    }

    private static void credits() {
        banner();
        System.out.print("\n" +
                "CONTRIBUTORS:\n\n" +
                "  > @disq - https://github.com/disq\n" +
                "      + Original code for image transparency support.\n\n" +
                "  > @timob - https://github.com/timob\n" +
                "      + Fix for ANSIpixel type: use 8bit color component for output.\n\n" +
                "  > @HongjiangHuang - https://github.com/HongjiangHuang\n" +
                "      + Original code for image download support.\n\n" +
                "  > @brutestack - https://github.com/brutestack\n" +
                "      + Color support for Windows (Command Prompt & PowerShell).\n" +
                "      + Original code for disable background color in dithering mode.\n" +
                "      + Original code for output Go code to 'fmt.Print()' the image.\n\n" +
                "  > @diamondburned - https://github.com/diamondburned\n" +
                "      + NewFromImage() & NewScaledFromImage() for ANSImage API.\n\n" +
                "  > @MichaelMure - https://github.com/MichaelMure\n" +
                "      + More conventional 'go.mod' file at repository.\n\n" +
                "  > @Calinou - https://github.com/Calinou\n" +
                "      + Use HTTPS URLs everywhere.\n" +
                "      + Other awesome contributions.\n\n" +
                "  > @danirod - https://github.com/danirod\n" +
                "  > @Xpktro - https://github.com/Xpktro\n" +
                "      + Moral support.\n\n");
    }

    private static String timestamp() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
    }

    static class PixtermException extends Exception {
        PixtermException(String message) {
            super(message);
        }
    }
}
