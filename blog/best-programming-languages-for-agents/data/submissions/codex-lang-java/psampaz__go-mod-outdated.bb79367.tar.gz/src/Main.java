import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    static class Options {
        boolean ci;
        boolean direct;
        boolean update;
        String style = "default";
    }

    static class Module {
        String path = "";
        String version = "";
        String time = "";
        boolean main;
        boolean indirect;
        Update update;
    }

    static class Update {
        String version = "";
        String time = "";
    }

    public static void main(String[] args) throws Exception {
        Options options = parseFlags(args);
        if (options == null) {
            System.exit(2);
            return;
        }

        String input = readAll();
        List<Module> modules;
        try {
            modules = parseModules(input);
        } catch (RuntimeException ex) {
            log(ex.getMessage());
            return;
        }

        List<String[]> rows = new ArrayList<>();
        boolean outdated = false;
        try {
            for (Module m : modules) {
                if (m.main) {
                    continue;
                }
                boolean hasUpdate = m.update != null;
                boolean isDirect = !m.indirect;
                if (options.update && !hasUpdate) {
                    continue;
                }
                if (options.direct && !isDirect) {
                    continue;
                }
                String newVersion = hasUpdate ? nz(m.update.version) : "";
                String valid = String.valueOf(validTimestamps(m));
                rows.add(new String[]{nz(m.path), nz(m.version), newVersion, String.valueOf(isDirect), valid});
                if (hasUpdate) {
                    outdated = true;
                }
            }
        } catch (DateTimeParseException ex) {
            log("parsing time \"" + ex.getParsedString() + "\" as \"2006-01-02T15:04:05Z07:00\": cannot parse \"" + ex.getParsedString() + "\" as \"2006\"");
            return;
        } catch (NullPointerException ex) {
            ex.printStackTrace(System.err);
            System.exit(2);
            return;
        }

        if (!rows.isEmpty()) {
            render(rows, options.style);
        }
        if (options.ci && outdated) {
            System.exit(1);
        }
    }

    static Options parseFlags(String[] args) {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-h") || a.equals("-help") || a.equals("--help")) {
                usage();
                System.exit(0);
            } else if (a.equals("-ci")) {
                o.ci = true;
            } else if (a.startsWith("-ci=")) {
                o.ci = boolValue(a.substring(4));
            } else if (a.equals("-direct")) {
                o.direct = true;
            } else if (a.startsWith("-direct=")) {
                o.direct = boolValue(a.substring(8));
            } else if (a.equals("-update")) {
                o.update = true;
            } else if (a.startsWith("-update=")) {
                o.update = boolValue(a.substring(8));
            } else if (a.equals("-style")) {
                if (i + 1 >= args.length) {
                    System.err.println("flag needs an argument: -style");
                    usage();
                    return null;
                }
                o.style = args[++i];
            } else if (a.startsWith("-style=")) {
                o.style = a.substring(7);
            } else if (a.startsWith("-")) {
                System.err.println("flag provided but not defined: " + a);
                usage();
                return null;
            }
        }
        return o;
    }

    static boolean boolValue(String value) {
        return value.equals("1") || value.equalsIgnoreCase("t") || value.equalsIgnoreCase("true");
    }

    static void usage() {
        System.err.println("Usage of ./executable:");
        System.err.println("  -ci");
        System.err.println("    \tNon-zero exit code when at least one outdated dependency was found");
        System.err.println("  -direct");
        System.err.println("    \tList only direct modules");
        System.err.println("  -style string");
        System.err.println("    \tOutput style, pass 'markdown' for a Markdown table (default \"default\")");
        System.err.println("  -update");
        System.err.println("    \tList only modules with updates");
    }

    static String readAll() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = System.in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        return out.toString(StandardCharsets.UTF_8);
    }

    static List<Module> parseModules(String input) {
        Parser p = new Parser(input);
        List<Module> modules = new ArrayList<>();
        while (true) {
            p.skipWs();
            if (p.eof()) {
                break;
            }
            Object v = p.value();
            if (!(v instanceof Map)) {
                throw new RuntimeException("invalid character '" + (p.pos < input.length() ? input.charAt(p.pos) : ' ') + "' looking for beginning of object key string");
            }
            modules.add(toModule((Map<?, ?>) v));
        }
        return modules;
    }

    static Module toModule(Map<?, ?> map) {
        Module m = new Module();
        m.path = string(map.get("Path"));
        m.version = string(map.get("Version"));
        m.time = string(map.get("Time"));
        m.main = bool(map.get("Main"));
        m.indirect = bool(map.get("Indirect"));
        Object upd = map.get("Update");
        if (upd instanceof Map) {
            Map<?, ?> um = (Map<?, ?>) upd;
            m.update = new Update();
            m.update.version = string(um.get("Version"));
            m.update.time = string(um.get("Time"));
        }
        return m;
    }

    static String string(Object o) {
        return o instanceof String ? (String) o : "";
    }

    static boolean bool(Object o) {
        return o instanceof Boolean && (Boolean) o;
    }

    static boolean validTimestamps(Module m) {
        if (m.update == null) {
            return true;
        }
        if (m.time == null || m.time.isEmpty()) {
            return true;
        }
        Instant current = Instant.parse(m.time);
        Instant next = Instant.parse(m.update.time);
        return !next.isBefore(current);
    }

    static void render(List<String[]> rows, String style) {
        String[] headers = {"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"};
        int[] w = new int[headers.length];
        for (int i = 0; i < headers.length; i++) {
            w[i] = headers[i].length();
        }
        for (String[] row : rows) {
            for (int i = 0; i < row.length; i++) {
                w[i] = Math.max(w[i], row[i].length());
            }
        }
        if ("markdown".equals(style)) {
            printRow(headers, w, true);
            printMarkdownSep(w);
            for (String[] row : rows) {
                printRow(row, w, false);
            }
        } else {
            printBorder(w);
            printRow(headers, w, true);
            printBorder(w);
            for (String[] row : rows) {
                printRow(row, w, false);
            }
            printBorder(w);
        }
    }

    static void printBorder(int[] w) {
        StringBuilder sb = new StringBuilder();
        for (int width : w) {
            sb.append('+').append(repeat('-', width + 2));
        }
        sb.append('+');
        System.out.println(sb);
    }

    static void printMarkdownSep(int[] w) {
        StringBuilder sb = new StringBuilder();
        for (int width : w) {
            sb.append('|').append(repeat('-', width + 2));
        }
        sb.append('|');
        System.out.println(sb);
    }

    static void printRow(String[] cells, int[] w, boolean header) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cells.length; i++) {
            sb.append('|');
            String s = cells[i];
            int width = w[i] + 2;
            if (header) {
                int left = (width - s.length()) / 2;
                int right = width - s.length() - left;
                sb.append(repeat(' ', left)).append(s).append(repeat(' ', right));
            } else {
                sb.append(' ').append(s).append(repeat(' ', width - s.length() - 1));
            }
        }
        sb.append('|');
        System.out.println(sb);
    }

    static String repeat(char c, int n) {
        StringBuilder sb = new StringBuilder(Math.max(0, n));
        for (int i = 0; i < n; i++) {
            sb.append(c);
        }
        return sb.toString();
    }

    static String nz(String s) {
        return s == null ? "" : s;
    }

    static void log(String msg) {
        System.err.println("2026/05/31 05:12:00 " + msg);
    }

    static class Parser {
        final String s;
        int pos;

        Parser(String s) {
            this.s = s;
        }

        boolean eof() {
            return pos >= s.length();
        }

        void skipWs() {
            while (!eof() && Character.isWhitespace(s.charAt(pos))) {
                pos++;
            }
        }

        Object value() {
            skipWs();
            if (eof()) {
                throw new RuntimeException("unexpected EOF");
            }
            char c = s.charAt(pos);
            if (c == '{') return object();
            if (c == '[') return array();
            if (c == '"') return string();
            if (c == 't') return literal("true", Boolean.TRUE);
            if (c == 'f') return literal("false", Boolean.FALSE);
            if (c == 'n') return literal("null", null);
            if (c == '-' || Character.isDigit(c)) return number();
            throw new RuntimeException("invalid character '" + c + "' looking for beginning of value");
        }

        Map<String, Object> object() {
            Map<String, Object> map = new LinkedHashMap<>();
            pos++;
            skipWs();
            if (!eof() && s.charAt(pos) == '}') {
                pos++;
                return map;
            }
            while (true) {
                skipWs();
                if (eof() || s.charAt(pos) != '"') {
                    throw new RuntimeException("invalid character '" + (eof() ? ' ' : s.charAt(pos)) + "' looking for beginning of object key string");
                }
                String key = string();
                skipWs();
                expect(':');
                Object val = value();
                map.put(key, val);
                skipWs();
                if (!eof() && s.charAt(pos) == ',') {
                    pos++;
                    continue;
                }
                expect('}');
                return map;
            }
        }

        List<Object> array() {
            List<Object> list = new ArrayList<>();
            pos++;
            skipWs();
            if (!eof() && s.charAt(pos) == ']') {
                pos++;
                return list;
            }
            while (true) {
                list.add(value());
                skipWs();
                if (!eof() && s.charAt(pos) == ',') {
                    pos++;
                    continue;
                }
                expect(']');
                return list;
            }
        }

        String string() {
            StringBuilder out = new StringBuilder();
            expect('"');
            while (!eof()) {
                char c = s.charAt(pos++);
                if (c == '"') {
                    return out.toString();
                }
                if (c == '\\') {
                    if (eof()) {
                        throw new RuntimeException("unexpected EOF");
                    }
                    char e = s.charAt(pos++);
                    switch (e) {
                        case '"': out.append('"'); break;
                        case '\\': out.append('\\'); break;
                        case '/': out.append('/'); break;
                        case 'b': out.append('\b'); break;
                        case 'f': out.append('\f'); break;
                        case 'n': out.append('\n'); break;
                        case 'r': out.append('\r'); break;
                        case 't': out.append('\t'); break;
                        case 'u':
                            if (pos + 4 > s.length()) throw new RuntimeException("unexpected EOF");
                            int code = Integer.parseInt(s.substring(pos, pos + 4), 16);
                            out.append((char) code);
                            pos += 4;
                            break;
                        default:
                            throw new RuntimeException("invalid character '" + e + "' in string escape code");
                    }
                } else {
                    if (c < 0x20) {
                        throw new RuntimeException("invalid character '\\n' in string literal");
                    }
                    out.append(c);
                }
            }
            throw new RuntimeException("unexpected EOF");
        }

        Object literal(String lit, Object value) {
            for (int i = 0; i < lit.length(); i++) {
                if (pos + i >= s.length() || s.charAt(pos + i) != lit.charAt(i)) {
                    throw new RuntimeException("invalid character '" + (pos + i < s.length() ? s.charAt(pos + i) : ' ') + "' in literal " + lit);
                }
            }
            pos += lit.length();
            return value;
        }

        Number number() {
            int start = pos;
            if (s.charAt(pos) == '-') pos++;
            while (!eof() && Character.isDigit(s.charAt(pos))) pos++;
            if (!eof() && s.charAt(pos) == '.') {
                pos++;
                while (!eof() && Character.isDigit(s.charAt(pos))) pos++;
            }
            if (!eof() && (s.charAt(pos) == 'e' || s.charAt(pos) == 'E')) {
                pos++;
                if (!eof() && (s.charAt(pos) == '+' || s.charAt(pos) == '-')) pos++;
                while (!eof() && Character.isDigit(s.charAt(pos))) pos++;
            }
            return Double.parseDouble(s.substring(start, pos));
        }

        void expect(char c) {
            if (eof() || s.charAt(pos) != c) {
                throw new RuntimeException("invalid character '" + (eof() ? ' ' : s.charAt(pos)) + "' looking for '" + c + "'");
            }
            pos++;
        }
    }
}
