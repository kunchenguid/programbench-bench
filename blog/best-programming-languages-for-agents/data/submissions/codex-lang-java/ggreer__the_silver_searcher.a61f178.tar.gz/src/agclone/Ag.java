package agclone;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.*;
import java.util.zip.GZIPInputStream;

public class Ag {
    static class Opt {
        boolean ignoreCase=false, caseSensitive=false, smartCase=true, literal=false, word=false, invert=false;
        boolean filename=true, filenameSet=false, numbers=true, numbersSet=false, column=false;
        boolean count=false, filesWith=false, filesWithout=false, only=false, vimgrep=false, ackmate=false;
        boolean hidden=false, unrestricted=false, allTypes=false, allText=false, searchBinary=false, follow=false;
        boolean skipVcs=false, noRecurse=false, group=false, heading=false, breakBetween=false, stats=false, statsOnly=false;
        boolean print0=false, passthrough=false, printAll=false, silent=false, searchZip=false, debug=false;
        int before=0, after=0, depth=25, maxCount=10000, width=-1, workers=0;
        String fileRegex=null, filenamePattern=null, pager=null, pathToIgnore=null;
        Set<String> typeExts = null;
        List<String> ignores = new ArrayList<>();
        List<String> positional = new ArrayList<>();
    }
    static class FileResult {
        Path path; List<String> lines; int matchCount; boolean hasMatch; long bytes;
        FileResult(Path p){path=p; lines=new ArrayList<>();}
    }
    static final String HELP = """

Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
                          (This often differs from the number of matching lines)
     --[no]color          Print color codes in results (Enabled by default)
     --color-line-number  Color codes for line numbers (Default: 1;33)
     --color-match        Color codes for result match numbers (Default: 30;43)
     --color-path         Color codes for path names (Default: 1;32)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
                          (don't print the matching lines)
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --print-all-files    Print headings for all files searched, even those that
                          don't contain matches
     --[no]numbers        Print line numbers. Default is to omit line numbers
                          when searching streams
  -o --only-matching      Prints only the matching part of the lines
     --print-long-lines   Print matches on very long lines (Default: >2k characters)
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
                          (Same as --count when searching a single file)
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
                          (it reports every match on the line)
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files (doesn't include hidden files
                          or patterns from ignore files)
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
                          (literal file/directory names also allowed)
     --ignore-dir NAME    Alias for --ignore for compatibility with ack.
  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)
     --one-device         Don't follow links to other devices.
  -p --path-to-ignore STRING
                          Use .ignore file at STRING
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files (doesn't include hidden files)
  -u --unrestricted       Search all files (ignore .ignore, .gitignore, etc.;
                          searches binary and hidden files as well)
  -U --skip-vcs-ignores   Ignore VCS ignore files
                          (.gitignore, .hgignore; still obey .ignore)
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed (e.g., gzip) files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle
  - Searches for 'needle' in files with suffix .htm, .html, .shtml or .xhtml.

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag""";

    static final LinkedHashMap<String,String[]> TYPES = new LinkedHashMap<>();
    static {
        add("actionscript","as","mxml"); add("ada","ada","adb","ads"); add("asciidoc","adoc","ad","asc","asciidoc");
        add("apl","apl"); add("asm","asm","s"); add("asp","asp","asa","aspx","asax","ashx","ascx","asmx"); add("aspx","asp","asa","aspx","asax","ashx","ascx","asmx");
        add("batch","bat","cmd"); add("bazel","bazel"); add("bitbake","bb","bbappend","bbclass","inc"); add("cc","c","h","xs"); add("cfmx","cfc","cfm","cfml");
        add("clojure","clj","cljs","cljc","cljx","edn"); add("coffee","coffee","cjsx"); add("cpp","cpp","cc","C","cxx","m","hpp","hh","h","H","hxx","tpp");
        add("csharp","cs"); add("css","css"); add("elixir","ex","eex","exs"); add("erlang","erl","hrl"); add("go","go"); add("groovy","groovy","gtmpl","gpp","grunit","gradle");
        add("haskell","hs","hsig","lhs"); add("html","htm","html","shtml","xhtml"); add("java","java","properties"); add("js","es6","js","jsx","vue"); add("json","json");
        add("kotlin","kt"); add("log","log"); add("lua","lua"); add("make","Makefiles","mk","mak"); add("markdown","markdown","mdown","mdwn","mkdn","mkd","md"); add("md","markdown","mdown","mdwn","mkdn","mkd","md");
        add("objc","m","h"); add("perl","pl","pm","pm6","pod","t"); add("php","php","phpt","php3","php4","php5","phtml"); add("python","py"); add("ruby","rb","rhtml","rjs","rxml","erb","rake","spec");
        add("rust","rs"); add("scala","scala"); add("shell","sh","bash","csh","tcsh","ksh","zsh","fish"); add("sql","sql","ctl"); add("swift","swift"); add("ts","ts","tsx"); add("xml","xml","dtd","xsl","xslt","ent"); add("yaml","yaml","yml");
        loadTypeResource();
    }
    static void add(String k,String...v){TYPES.put(k,v);}
    static void loadTypeResource() {
        try (InputStream in = Ag.class.getResourceAsStream("/agclone/filetypes.txt")) {
            if(in==null) return;
            BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line, key=null;
            while((line=br.readLine())!=null) {
                String t=line.trim();
                if(t.startsWith("--")) key=t.substring(2);
                else if(key!=null && t.startsWith(".")) {
                    String[] parts=t.split("\\s+");
                    List<String> ex=new ArrayList<>();
                    for(String p:parts) if(p.startsWith(".")) ex.add(p.substring(1));
                    TYPES.put(key, ex.toArray(new String[0]));
                    key=null;
                }
            }
        } catch(IOException ignored) {}
    }

    public static void main(String[] args) throws Exception {
        long start = System.nanoTime();
        Opt o = new Opt();
        int rc;
        try { rc = run(args,o,start); } catch (Usage u) { if(!u.msg.isEmpty()) System.err.println(u.msg); System.out.println(HELP); rc=u.code; }
        System.exit(rc);
    }
    static class Usage extends RuntimeException { int code; String msg; Usage(String m,int c){msg=m;code=c;} }

    static int run(String[] args, Opt o, long start) throws Exception {
        parse(args,o);
        if (o.filenamePattern != null) {
            List<String> paths = o.positional.isEmpty() ? List.of(".") : o.positional;
            Pattern filePat = o.fileRegex==null?null:Pattern.compile(o.fileRegex);
            Pattern fp = Pattern.compile(o.filenamePattern);
            for(Path p: collectFiles(paths,o,filePat)) if(fp.matcher(pathString(p)).find()) printName(p,o);
            return 0;
        }
        if (o.positional.isEmpty()) throw new Usage("",1);
        String pattern = o.positional.get(0);
        List<String> paths = o.positional.subList(1,o.positional.size());
        if(paths.isEmpty() && System.getenv("AG_STDIN_DATA") != null) paths = List.of("-");
        if(o.filenameSet && !o.filename && !o.numbersSet) o.numbers=false;
        if (paths.isEmpty()) paths = List.of(".");
        boolean stdin = paths.size()==1 && paths.get(0).equals("-");
        if (stdin && !o.numbersSet) o.numbers=false;
        if (paths.size()==1 && Files.isRegularFile(Paths.get(paths.get(0))) && !o.filenameSet) o.filename=false;
        Pattern filePat = o.fileRegex==null?null:Pattern.compile(o.fileRegex);
        Pattern regex = compilePattern(pattern,o);
        List<Path> files = stdin ? List.of() : collectFiles(paths,o,filePat);
        int totalMatches=0, matchFiles=0; long bytes=0; int searched=0;
        List<FileResult> results = new ArrayList<>();
        if (stdin) {
            FileResult r = searchStream(Paths.get("-"), System.in, regex, o);
            printResult(r,o,true);
            return r.matchCount>0?0:1;
        }
        for(Path p: files) {
            FileResult r = searchFile(p, regex, o);
            if(r==null) continue;
            searched++; bytes += r.bytes; totalMatches += r.matchCount; if(r.hasMatch) matchFiles++;
            results.add(r);
            if(!o.statsOnly) printResult(r,o,files.size()==1);
        }
        if(o.stats || o.statsOnly) {
            System.out.printf("%d matches%n%d files contained matches%n%d files searched%n%d bytes searched%n%.6f seconds%n",
                    totalMatches, matchFiles, searched, bytes, (System.nanoTime()-start)/1_000_000_000.0);
        }
        return totalMatches>0?0:1;
    }

    static void parse(String[] args, Opt o) {
        boolean end=false;
        for(int i=0;i<args.length;i++) {
            String a=args[i];
            if(end || !a.startsWith("-") || a.equals("-")) { o.positional.add(a); continue; }
            if(a.matches("-[ABCmW][0-9]+")) {
                int val=Integer.parseInt(a.substring(2));
                switch(a.charAt(1)) { case 'A': o.after=val; break; case 'B': o.before=val; break; case 'C': o.before=o.after=val; break; case 'm': o.maxCount=val; break; case 'W': o.width=val; break; }
                continue;
            }
            if(a.equals("--")) { end=true; continue; }
            if(a.equals("--help")||a.equals("-h")) throw new Usage("",0);
            if(a.equals("--version")||a.equals("-V")) { System.out.println("ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib"); System.exit(0); }
            if(a.equals("--list-file-types")) { listTypes(); System.exit(0); }
            if(TYPES.containsKey(a.replaceFirst("^--",""))) { o.typeExts = new HashSet<>(Arrays.asList(TYPES.get(a.substring(2)))); continue; }
            switch(a) {
                case "-i": case "--ignore-case": o.ignoreCase=true; o.caseSensitive=false; o.smartCase=false; break;
                case "-s": case "--case-sensitive": o.caseSensitive=true; o.ignoreCase=false; o.smartCase=false; break;
                case "-S": case "--smart-case": o.smartCase=true; break;
                case "-Q": case "--literal": case "-F": case "--fixed-strings": o.literal=true; break;
                case "-w": case "--word-regexp": o.word=true; break; case "-v": case "--invert-match": o.invert=true; break;
                case "-c": case "--count": o.count=true; break; case "-l": case "--files-with-matches": o.filesWith=true; break; case "-L": case "--files-without-matches": o.filesWithout=true; break;
                case "-o": case "--only-matching": o.only=true; break; case "--vimgrep": o.vimgrep=true; break; case "--ackmate": o.ackmate=true; break;
                case "--column": o.column=true; break; case "--filename": o.filename=true; o.filenameSet=true; break; case "--nofilename": o.filename=false; o.filenameSet=true; break;
                case "-H": case "--heading": o.heading=true; o.group=true; break; case "--noheading": o.heading=false; break; case "--group": o.group=true; o.heading=true; o.breakBetween=true; break; case "--nogroup": o.group=false; o.heading=false; o.breakBetween=false; break;
                case "--numbers": o.numbers=true; o.numbersSet=true; break; case "--nonumbers": o.numbers=false; o.numbersSet=true; break;
                case "-a": case "--all-types": o.allTypes=true; break; case "-t": case "--all-text": o.allText=true; break; case "-u": case "--unrestricted": o.unrestricted=true; o.hidden=true; o.searchBinary=true; break;
                case "--hidden": o.hidden=true; break; case "--search-binary": o.searchBinary=true; break; case "-f": case "--follow": o.follow=true; break; case "-n": case "--norecurse": o.noRecurse=true; break; case "-U": case "--skip-vcs-ignores": o.skipVcs=true; break;
                case "--stats": o.stats=true; break; case "--stats-only": o.statsOnly=true; break; case "--silent": o.silent=true; break; case "-0": case "--null": case "--print0": o.print0=true; break; case "--passthrough": case "--passthru": o.passthrough=true; break;
                case "--print-all-files": o.printAll=true; break; case "-z": case "--search-zip": o.searchZip=true; break; case "-D": case "--debug": o.debug=true; break;
                case "-A": case "--after": if(i+1<args.length && isInt(args[i+1])) o.after=Integer.parseInt(args[++i]); else o.after=2; break;
                case "-B": case "--before": if(i+1<args.length && isInt(args[i+1])) o.before=Integer.parseInt(args[++i]); else o.before=2; break;
                case "-C": case "--context": if(i+1<args.length && isInt(args[i+1])) o.before=o.after=Integer.parseInt(args[++i]); else o.before=o.after=2; break;
                case "-m": case "--max-count": o.maxCount=nextIntReq(args,++i,a); break; case "--depth": o.depth=nextIntReq(args,++i,a); break; case "-W": case "--width": o.width=nextIntReq(args,++i,a); break; case "--workers": o.workers=nextIntReq(args,++i,a); break;
                case "-G": case "--file-search-regex": o.fileRegex=next(args,++i,a); break; case "-g": case "--filename-pattern": o.filenamePattern=next(args,++i,a); break;
                case "--ignore": case "--ignore-dir": o.ignores.add(next(args,++i,a)); break; case "-p": case "--path-to-ignore": o.pathToIgnore=next(args,++i,a); break;
                case "--color": case "--nocolor": case "--color-line-number": case "--color-match": case "--color-path": if(!a.startsWith("--no") && i+1<args.length && !args[i+1].startsWith("-")) i++; break;
                case "--mmap": case "--nommap": case "--multiline": case "--nomultiline": case "--affinity": case "--noaffinity": case "--one-device": case "-r": case "--recurse": case "--break": case "--nobreak": case "--parallel": break;
                case "--pager": o.pager=next(args,++i,a); break; case "--nopager": break;
                default:
                    if(a.startsWith("-") && !a.startsWith("--") && a.length()>2) {
                        String rest=a.substring(1);
                        for(char ch:rest.toCharArray()) {
                            switch(ch) {
                                case 'i': o.ignoreCase=true; o.caseSensitive=false; o.smartCase=false; break;
                                case 's': o.caseSensitive=true; o.ignoreCase=false; o.smartCase=false; break;
                                case 'S': o.smartCase=true; break; case 'Q': case 'F': o.literal=true; break; case 'w': o.word=true; break; case 'v': o.invert=true; break;
                                case 'c': o.count=true; break; case 'l': o.filesWith=true; break; case 'L': o.filesWithout=true; break; case 'o': o.only=true; break; case 'a': o.allTypes=true; break; case 't': o.allText=true; break;
                                case 'u': o.unrestricted=true; o.hidden=true; o.searchBinary=true; break; case 'U': o.skipVcs=true; break; case 'f': o.follow=true; break; case 'n': o.noRecurse=true; break; case '0': o.print0=true; break;
                                default: throw new Usage("./executable: unrecognized option '-"+ch+"'\n",1);
                            }
                        }
                    } else throw new Usage("./executable: unrecognized option '"+a+"'\n",1);
            }
        }
    }
    static String next(String[] a,int i,String opt){ if(i>=a.length) throw new Usage(opt+" requires an argument",1); return a[i]; }
    static int nextIntReq(String[] a,int i,String opt){ return Integer.parseInt(next(a,i,opt)); }
    static boolean isInt(String s){ try { Integer.parseInt(s); return true; } catch(Exception e) { return false; } }

    static Pattern compilePattern(String pat, Opt o) {
        String p = o.literal ? Pattern.quote(pat) : pat;
        if(o.word) p = "\\b(?:"+p+")\\b";
        boolean ci = o.ignoreCase || (o.smartCase && !o.caseSensitive && pat.equals(pat.toLowerCase(Locale.ROOT)));
        int flags = Pattern.MULTILINE | (ci ? Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE : 0);
        try { return Pattern.compile(p, flags); }
        catch(PatternSyntaxException e) {
            String desc=e.getDescription();
            if(desc != null && desc.toLowerCase(Locale.ROOT).contains("unclosed character class")) desc="missing terminating ] for character class";
            System.err.println("ERR: Bad regex! pcre_compile() failed at position "+Math.max(0,e.getIndex()+1)+": "+desc);
            System.err.println("If you meant to search for a literal string, run ag with -Q");
            System.exit(2); return null;
        }
    }

    static List<Path> collectFiles(List<String> roots, Opt o, Pattern filePat) throws IOException {
        List<Path> out = new ArrayList<>();
        for(String r: roots) {
            Path root=Paths.get(r);
            if(Files.isRegularFile(root)) { if(accept(root,o,filePat)) out.add(root); continue; }
            if(!Files.isDirectory(root)) { if(!o.silent) System.err.println("ERR: "+r+": No such file or directory"); continue; }
            final int baseCount=root.toAbsolutePath().normalize().getNameCount();
            Set<FileVisitOption> opts=o.follow?EnumSet.of(FileVisitOption.FOLLOW_LINKS):EnumSet.noneOf(FileVisitOption.class);
            Files.walkFileTree(root, opts, o.noRecurse?1:(o.depth<0?Integer.MAX_VALUE:o.depth+1), new SimpleFileVisitor<>() {
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if(!dir.equals(root) && skipPath(dir,o,true)) return FileVisitResult.SKIP_SUBTREE;
                    return FileVisitResult.CONTINUE;
                }
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) { if(accept(file,o,filePat)) out.add(file); return FileVisitResult.CONTINUE; }
                public FileVisitResult visitFileFailed(Path file, IOException exc) { return FileVisitResult.CONTINUE; }
            });
        }
        return out;
    }
    static boolean accept(Path p, Opt o, Pattern filePat) {
        if(skipPath(p,o,false)) return false;
        if(filePat!=null && !filePat.matcher(pathString(p)).find()) return false;
        if(o.typeExts!=null && !o.typeExts.contains(ext(p))) return false;
        String e=ext(p).toLowerCase(Locale.ROOT);
        if(!o.searchZip && (e.equals("gz")||e.equals("xz"))) return false;
        return true;
    }
    static boolean skipPath(Path p, Opt o, boolean dir) {
        if(o.unrestricted) return false;
        String name=p.getFileName()==null?"":p.getFileName().toString();
        if(!o.hidden && name.startsWith(".")) return true;
        if(dir && (name.equals(".git")||name.equals(".hg")||name.equals(".svn"))) return true;
        for(String ig:o.ignores) if(globMatch(ig,name)||globMatch(ig,pathString(p))) return true;
        if(o.allTypes || o.allText) return false;
        if(o.pathToIgnore!=null) for(String ig:readIgnoreFile(Paths.get(o.pathToIgnore))) if(globMatch(ig,name)||globMatch(ig,pathString(p))) return true;
        List<String> patterns = loadIgnorePatterns(p,o.skipVcs);
        for(String ig:patterns) if(globMatch(ig,name)||globMatch(ig,pathString(p))) return true;
        return false;
    }
    static List<String> loadIgnorePatterns(Path p, boolean skipVcs) {
        List<String> pats=new ArrayList<>(); Path dir=Files.isDirectory(p)?p:p.getParent();
        while(dir!=null) {
            for(String f: new String[]{".ignore",".gitignore",".hgignore"}) {
                if(skipVcs && (f.equals(".gitignore") || f.equals(".hgignore"))) continue;
                Path q=dir.resolve(f); if(Files.isRegularFile(q)) try { for(String s:Files.readAllLines(q)) { s=s.trim(); if(!s.isEmpty()&&!s.startsWith("#")) pats.add(s); } } catch(IOException ignored){}
            }
            dir=dir.getParent();
        }
        String home=System.getenv("HOME");
        if(home!=null) pats.addAll(readIgnoreFile(Paths.get(home).resolve(".agignore")));
        return pats;
    }
    static List<String> readIgnoreFile(Path q) {
        List<String> out=new ArrayList<>();
        if(Files.isRegularFile(q)) try { for(String s:Files.readAllLines(q)) { s=s.trim(); if(!s.isEmpty()&&!s.startsWith("#")) out.add(s); } } catch(IOException ignored){}
        return out;
    }
    static boolean globMatch(String pat,String text) {
        pat=pat.trim(); if(pat.endsWith("/")) pat=pat.substring(0,pat.length()-1);
        if(pat.startsWith("/")) pat=pat.substring(1);
        StringBuilder re=new StringBuilder();
        for(char c:pat.toCharArray()) {
            if(c=='*') re.append(".*"); else if(c=='?') re.append('.');
            else if(".[]{}()+-^$|\\".indexOf(c)>=0) re.append('\\').append(c); else re.append(c);
        }
        return Pattern.compile(re.toString()).matcher(text).matches() || text.endsWith("/"+pat);
    }

    static FileResult searchFile(Path p, Pattern regex, Opt o) {
        try {
            byte[] data=Files.readAllBytes(p); FileResult r=new FileResult(p); r.bytes=data.length;
            if(!o.searchBinary && isBinary(data)) return null;
            InputStream in = new ByteArrayInputStream(data);
            if(o.searchZip && ext(p).equalsIgnoreCase("gz")) in = new GZIPInputStream(new ByteArrayInputStream(data));
            return searchReader(r, new InputStreamReader(in, StandardCharsets.UTF_8), regex, o);
        } catch(Exception e){ if(!o.silent) System.err.println("ERR: "+pathString(p)+": "+e.getMessage()); return null; }
    }
    static FileResult searchStream(Path p, InputStream in, Pattern regex, Opt o) throws IOException {
        return searchReader(new FileResult(p), new InputStreamReader(in, StandardCharsets.UTF_8), regex, o);
    }
    static FileResult searchReader(FileResult r, Reader rdr, Pattern regex, Opt o) throws IOException {
        BufferedReader br=new BufferedReader(rdr); List<String> all=new ArrayList<>(); String line; while((line=br.readLine())!=null) all.add(line);
        boolean[] match=new boolean[all.size()]; List<List<int[]>> spans=new ArrayList<>();
        for(int i=0;i<all.size();i++) {
            Matcher m=regex.matcher(all.get(i)); List<int[]> sp=new ArrayList<>(); boolean found=false;
            while(m.find()) { found=true; sp.add(new int[]{m.start(),m.end()}); if(m.start()==m.end()) break; }
            if(o.invert) found=!found;
            match[i]=found; spans.add(sp); if(found) { r.hasMatch=true; r.matchCount += o.invert ? 1 : Math.max(1, sp.size()); }
            if(o.maxCount>0 && r.matchCount>=o.maxCount) break;
        }
        if(o.count||o.filesWith||o.filesWithout) return r;
        Set<Integer> printIdx=new TreeSet<>();
        for(int i=0;i<match.length;i++) if(match[i]) for(int j=Math.max(0,i-o.before);j<=Math.min(match.length-1,i+o.after);j++) printIdx.add(j);
        if(o.passthrough) for(int i=0;i<all.size();i++) printIdx.add(i);
        for(int i:printIdx) {
            boolean isMatch=match[i]; String sep=isMatch?":":"-"; String l=all.get(i);
            if(o.width>=0 && l.length()>o.width) l=l.substring(0,o.width);
            if(o.ackmate && isMatch && !o.invert) {
                List<int[]> ss=spans.get(i);
                StringBuilder meta=new StringBuilder();
                for(int k=0;k<ss.size();k++) {
                    if(k>0) meta.append(',');
                    meta.append(ss.get(k)[0]).append(' ').append(ss.get(k)[1]-ss.get(k)[0]);
                }
                r.lines.add((i+1)+";"+meta+":"+l);
            } else if(o.only && isMatch && !o.invert) {
                for(int[] sp:spans.get(i)) r.lines.add(formatLine(r.path,i+1,sp[0]+1,l.substring(sp[0],sp[1]),":",o));
            } else if(o.vimgrep && isMatch && !o.invert) {
                List<int[]> ss=spans.get(i); if(ss.isEmpty()) r.lines.add(formatLine(r.path,i+1,1,l,":",o)); else for(int[] sp:ss) r.lines.add(pathString(r.path)+":"+(i+1)+":"+(sp[0]+1)+":"+l);
            } else {
                int c = (isMatch && !spans.get(i).isEmpty()) ? spans.get(i).get(0)[0]+1 : 1;
                r.lines.add(formatLine(r.path,i+1,c,l,sep,o));
            }
        }
        return r;
    }
    static String formatLine(Path p,int line,int col,String text,String sep,Opt o) {
        StringBuilder sb=new StringBuilder();
        if(o.filename && !pathString(p).equals("-")) sb.append(pathString(p)).append(':');
        if(o.numbers) sb.append(line).append(sep);
        if(o.column) sb.append(col).append(sep);
        sb.append(text); return sb.toString();
    }
    static void printResult(FileResult r, Opt o, boolean single) {
        if(o.filesWith) { if(r.hasMatch) printName(r.path,o); return; }
        if(o.filesWithout) { if(!r.hasMatch) printName(r.path,o); return; }
        if(o.count) { if(!single && o.filename) System.out.print(pathString(r.path)+":"); System.out.println(r.matchCount); return; }
        if(o.ackmate) {
            if(!r.hasMatch) return;
            System.out.println(":"+pathString(r.path));
            for(String s:r.lines) System.out.println(s);
            System.out.println();
            return;
        }
        if(o.printAll && o.heading) System.out.println(pathString(r.path));
        if(!r.hasMatch && !o.passthrough) return;
        if(o.heading && r.hasMatch) {
            System.out.println(pathString(r.path));
            String prefix=pathString(r.path)+":";
            for(String s:r.lines) System.out.println(s.startsWith(prefix)?s.substring(prefix.length()):s);
            System.out.println();
        } else for(String s:r.lines) System.out.println(s);
    }
    static void printName(Path p,Opt o){ System.out.print(pathString(p)); System.out.print(o.print0?'\0':'\n'); }
    static boolean isBinary(byte[] d){ int n=Math.min(d.length,8192); for(int i=0;i<n;i++) if(d[i]==0) return true; return false; }
    static String pathString(Path p){ return p.toString().replace(File.separatorChar,'/'); }
    static String ext(Path p){ String n=p.getFileName()==null?"":p.getFileName().toString(); int i=n.lastIndexOf('.'); return i>=0?n.substring(i+1):n; }
    static void listTypes(){
        try (InputStream in = Ag.class.getResourceAsStream("/agclone/filetypes.txt")) {
            if(in!=null) { in.transferTo(System.out); return; }
        } catch(IOException ignored) {}
        System.out.println("The following file types are supported:"); for(var e:TYPES.entrySet()){ System.out.println("  --"+e.getKey()); StringBuilder sb=new StringBuilder("      "); for(String x:e.getValue()) sb.append('.').append(x).append("  "); System.out.println(sb.toString().trim()); System.out.println(); }
    }
}
