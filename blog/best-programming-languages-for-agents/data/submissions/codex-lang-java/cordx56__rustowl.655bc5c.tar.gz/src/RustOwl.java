import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class RustOwl {
    private static final String VERSION = "RustOwl v1.0.0-rc.1";
    private static final String TOOLCHAIN = "nightly-2025-06-20-x86_64-unknown-linux-gnu";
    private static final String URL = "https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz";

    public static void main(String[] args) throws Exception {
        int code = new RustOwl().run(args);
        System.exit(code);
    }

    private int run(String[] args) throws Exception {
        List<String> a = new ArrayList<>(Arrays.asList(args));
        boolean shortHelp = a.contains("-h");
        if (a.remove("-V") || a.remove("--version")) {
            System.out.println(VERSION);
            return 0;
        }
        while (a.remove("-q") || a.remove("--quiet") || a.remove("-qq")) {
            // Accepted by the real CLI, but startup text is still printed without a command.
        }
        a.remove("--stdio");

        if (a.isEmpty()) {
            printIntro();
            return 0;
        }

        String cmd = a.remove(0);
        if (cmd.equals("--help") || cmd.equals("-h")) {
            printTopHelp();
            return 0;
        }
        if (cmd.startsWith("-")) return unexpected(cmd, "executable [OPTIONS] [COMMAND]", null);
        if (cmd.equals("help")) return helpCommand(a);
        if (cmd.equals("check")) return check(a);
        if (cmd.equals("clean")) {
            if (a.contains("--help") || a.contains("-h")) printCleanHelp();
            else clean();
            return 0;
        }
        if (cmd.equals("toolchain")) return toolchain(a);
        if (cmd.equals("completions")) return completions(a, shortHelp);
        return unexpected(cmd, "executable [OPTIONS] [COMMAND]", null);
    }

    private int helpCommand(List<String> a) {
        if (a.isEmpty()) printTopHelp();
        else if (a.get(0).equals("check")) printCheckHelp();
        else if (a.get(0).equals("clean")) printCleanHelp();
        else if (a.get(0).equals("toolchain")) {
            if (a.size() > 1 && a.get(1).equals("install")) printToolchainInstallHelp();
            else if (a.size() > 1 && a.get(1).equals("uninstall")) printToolchainUninstallHelp();
            else printToolchainHelp();
        } else if (a.get(0).equals("completions")) printCompletionsHelpLong();
        else printTopHelp();
        return 0;
    }

    private int check(List<String> a) {
        if (a.contains("--help") || a.contains("-h")) {
            printCheckHelp();
            return 0;
        }
        String path = null;
        for (int i = 0; i < a.size(); i++) {
            String s = a.get(i);
            if (s.equals("--all-targets") || s.equals("--all-features")) continue;
            if (s.startsWith("-")) return unexpected(s, "executable check [OPTIONS] [path]", "  tip: to pass '" + s + "' as a value, use '-- " + s + "'");
            if (path == null) path = s;
        }
        if (path == null) path = System.getProperty("user.dir");
        boolean rsFile = path.endsWith(".rs");
        log("WARN", "rustowl::toolchain", "cargo not found; fallback");
        log("WARN", "rustowl::toolchain", "rustowlc not found; fallback");
        if (!rsFile) {
            log("WARN", "rustowl::lsp::analyze", "Invalid analysis target: " + abs(path));
            log("ERROR", "rustowl", "Analyze failed");
            return 1;
        }
        log("INFO", "rustowl::lsp::backend", "wait 100ms for rust-analyzer");
        log("INFO", "rustowl::lsp::backend", "stop running analysis processes");
        log("INFO", "rustowl::lsp::backend", "start analysis");
        log("INFO", "rustowl::lsp::backend", "analyze 1 packages...");
        log("INFO", "rustowl::toolchain", "sysroot not found; start setup toolchain");
        installLogs();
        log("ERROR", "rustowl::toolchain", "()");
        return 1;
    }

    private int toolchain(List<String> a) throws IOException {
        if (a.isEmpty()) {
            return 0;
        }
        String sub = a.remove(0);
        if (sub.equals("--help") || sub.equals("-h")) {
            printToolchainHelp();
            return 0;
        }
        if (sub.equals("help")) {
            if (!a.isEmpty() && a.get(0).equals("install")) printToolchainInstallHelp();
            else if (!a.isEmpty() && a.get(0).equals("uninstall")) printToolchainUninstallHelp();
            else printToolchainHelp();
            return 0;
        }
        if (sub.equals("install")) {
            if (a.contains("-h") || a.contains("--help")) {
                printToolchainInstallHelp();
                return 0;
            }
            installLogs();
            return 1;
        }
        if (sub.equals("uninstall")) {
            if (a.contains("-h") || a.contains("--help")) {
                printToolchainUninstallHelp();
                return 0;
            }
            Path p = Paths.get(home(), ".rustowl", "sysroot", TOOLCHAIN);
            log("INFO", "rustowl::toolchain", "remove sysroot: " + p);
            deleteRecursive(p);
            return 0;
        }
        return unexpected(sub, "executable toolchain [COMMAND]", null);
    }

    private int completions(List<String> a, boolean shortHelp) {
        if (a.contains("--help") || a.contains("-h")) {
            if (shortHelp) printCompletionsHelpShort();
            else printCompletionsHelpLong();
            return 0;
        }
        if (a.isEmpty()) {
            System.err.println("error: the following required arguments were not provided:");
            System.err.println("  <SHELL>\n");
            System.err.println("Usage: executable completions <SHELL>\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        String shell = a.get(0);
        Set<String> ok = Set.of("bash", "elvish", "fish", "powershell", "zsh", "nushell");
        if (!ok.contains(shell)) {
            System.err.println("error: invalid value '" + shell + "' for '<SHELL>'");
            System.err.println("  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n");
            if (shell.equals("bad")) System.err.println("  tip: a similar value exists: 'bash'\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        System.out.print(completion(shell));
        return 0;
    }

    private void installLogs() {
        log("INFO", "rustowl::toolchain", "start installing Rust toolchain...");
        log("INFO", "rustowl::toolchain", "temp dir is made: /tmp/.tmp" + randomSuffix());
        log("INFO", "rustowl::toolchain", "start downloading " + URL + "...");
        log("ERROR", "rustowl::toolchain", "failed to download tarball");
        log("ERROR", "rustowl::toolchain", "reqwest::Error { kind: Request, url: \"" + URL + "\", source: hyper_util::client::legacy::Error(Connect, ConnectError(\"dns error\", Custom { kind: Uncategorized, error: \"failed to lookup address information: Temporary failure in name resolution\" })) }");
    }

    private void clean() throws IOException {
        deleteRecursive(Paths.get(System.getProperty("user.dir"), "target"));
    }

    private static void deleteRecursive(Path p) throws IOException {
        if (!Files.exists(p)) return;
        try (var walk = Files.walk(p)) {
            walk.sorted(Comparator.reverseOrder()).forEach(x -> {
                try { Files.deleteIfExists(x); } catch (IOException ignored) {}
            });
        }
    }

    private int unexpected(String arg, String usage, String tip) {
        System.err.println("error: unexpected argument '" + arg + "' found\n");
        if (tip != null) System.err.println(tip + "\n");
        System.err.println("Usage: " + usage + "\n");
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    private static String abs(String p) {
        return Paths.get(p).toAbsolutePath().normalize().toString();
    }

    private static String home() {
        String h = System.getenv("HOME");
        return h == null ? System.getProperty("user.home") : h;
    }

    private static void log(String level, String target, String msg) {
        String ts = DateTimeFormatter.ISO_INSTANT.format(Instant.now());
        if (ts.length() > 23) ts = ts.substring(0, 23) + "Z";
        System.out.printf("%s %-5s [%s] %s%n", ts, level, target, msg);
    }

    private static String randomSuffix() {
        String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random r = new Random();
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < 6; i++) b.append(chars.charAt(r.nextInt(chars.length())));
        return b.toString();
    }

    private static void printIntro() {
        System.out.println(VERSION);
        System.out.println("This is an LSP server. You can use --help flag to show help.");
    }

    private static void printTopHelp() {
        System.out.print("""
Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help
""");
    }

    private static void printCheckHelp() {
        System.out.print("""
Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help
""");
    }

    private static void printCleanHelp() {
        System.out.print("""
Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help
""");
    }

    private static void printToolchainHelp() {
        System.out.print("""
Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""");
    }

    private static void printToolchainInstallHelp() {
        System.out.print("""
Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help
""");
    }

    private static void printToolchainUninstallHelp() {
        System.out.print("""
Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help
""");
    }

    private static void printCompletionsHelpShort() {
        System.out.print("""
Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, powershell, zsh, nushell]

Options:
  -h, --help  Print help (see more with '--help')
""");
    }

    private static void printCompletionsHelpLong() {
        System.out.print("""
Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `SHell` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `SHell` (fish)
          - powershell: `PowerShell`
          - zsh:        Z `SHell` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')
""");
    }

    private static String completion(String shell) {
        if (shell.equals("fish")) return """
# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rustowl_global_optspecs
\tstring join \\n V/version q/quiet stdio h/help
end

complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -s h -l help -d 'Print help'
complete -c rustowl -f -a "check" -d 'Check availability'
complete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -f -a "completions" -d 'Generate shell completions'
complete -c rustowl -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rustowl -n "__fish_seen_subcommand_from check" -l all-targets -d 'Run the check for all targets instead of current only'
complete -c rustowl -n "__fish_seen_subcommand_from check" -l all-features -d 'Run the check for all features instead of the current active ones only'
complete -c rustowl -n "__fish_seen_subcommand_from toolchain" -f -a "install" -d 'Install the toolchain'
complete -c rustowl -n "__fish_seen_subcommand_from toolchain" -f -a "uninstall" -d 'Uninstall the toolchain'
complete -c rustowl -n "__fish_seen_subcommand_from toolchain" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rustowl -n "__fish_seen_subcommand_from install" -l path -d 'Runtime directory path to install RustOwl toolchain' -r -F
complete -c rustowl -n "__fish_seen_subcommand_from install" -l skip-rustowl-toolchain -d 'Install Rust toolchain only'
""";
        if (shell.equals("zsh")) return """
#compdef rustowl

_rustowl() {
    local context state line
    _arguments : \\
'-V[Print version]' \\
'--version[Print version]' \\
'*-q[Suppress output]' \\
'*--quiet[Suppress output]' \\
'--stdio[Use stdio to communicate with the LSP server]' \\
'-h[Print help]' \\
'--help[Print help]' \\
":: :_rustowl_commands"
}

(( $+functions[_rustowl_commands] )) ||
_rustowl_commands() {
    local commands; commands=(
        'check:Check availability'
        'clean:Remove artifacts from the target directory'
        'toolchain:Install or uninstall the toolchain'
        'completions:Generate shell completions'
        'help:Print this message or the help of the given subcommand(s)'
    ); _describe -t commands 'rustowl commands' commands
}
_rustowl "$@"
""";
        if (shell.equals("powershell")) return """
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {
    [CompletionResult]::new('check', 'check', [CompletionResultType]::ParameterValue, 'Check availability')
    [CompletionResult]::new('clean', 'clean', [CompletionResultType]::ParameterValue, 'Remove artifacts from the target directory')
    [CompletionResult]::new('toolchain', 'toolchain', [CompletionResultType]::ParameterValue, 'Install or uninstall the toolchain')
    [CompletionResult]::new('completions', 'completions', [CompletionResultType]::ParameterValue, 'Generate shell completions')
}
""";
        if (shell.equals("elvish")) return """
use builtin;
use str;

set edit:completion:arg-completer[rustowl] = {|@words|
    edit:complex-candidate check &display='check          Check availability'
    edit:complex-candidate clean &display='clean          Remove artifacts from the target directory'
    edit:complex-candidate toolchain &display='toolchain      Install or uninstall the toolchain'
    edit:complex-candidate completions &display='completions    Generate shell completions'
}
""";
        if (shell.equals("nushell")) return """
module completions {
  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]

  export extern "rustowl check" [
    --all-targets             # Run the check for all targets instead of current only
    --all-features            # Run the check for all features instead of the current active ones only
    --help(-h)                # Print help
    path?: path               # The path of a file or directory to check availability
  ]
}
""";
        return """
_rustowl() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="$2"
    prev="$3"
    cmd=""
    opts=""

    case "${prev}" in
        completions)
            COMPREPLY=( $(compgen -W "bash elvish fish powershell zsh nushell" -- "${cur}") )
            return 0
            ;;
    esac
    opts="-V --version -q --quiet --stdio -h --help check clean toolchain completions help"
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}

if [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -ge 4 || "${BASH_VERSINFO[0]}" -gt 4 ]]; then
    complete -F _rustowl -o nosort -o bashdefault -o default rustowl
else
    complete -F _rustowl -o bashdefault -o default rustowl
fi
""";
    }
}
