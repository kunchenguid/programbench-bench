import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    static final String VERSION = "tree-sitter 0.27.0";
    static final String RED = "\u001b[31m";
    static final String YELLOW = "\u001b[33m";
    static final String RESET = "\u001b[0m";

    public static void main(String[] args) {
        int code = new Main().run(args);
        if (code != 0) System.exit(code);
    }

    int run(String[] args) {
        if (args.length == 0) {
            System.err.print(TOP_HELP);
            return 2;
        }
        if (eq(args[0], "-h", "--help")) {
            System.out.print(TOP_HELP);
            return 0;
        }
        if (eq(args[0], "-V", "--version")) {
            System.out.println(VERSION);
            return 0;
        }
        String cmd = args[0];
        String[] rest = Arrays.copyOfRange(args, 1, args.length);
        if (hasHelp(rest)) {
            String help = helpFor(cmd);
            if (help != null) {
                System.out.print(help);
                return 0;
            }
        }
        switch (cmd) {
            case "init-config": return initConfig(rest);
            case "init": return init(rest);
            case "generate": return generate(rest);
            case "build": return build(rest);
            case "parse": return parse(rest);
            case "test": return test(rest);
            case "version": return version(rest);
            case "fuzz": return fuzz(rest);
            case "query": return query(rest);
            case "highlight": return highlight(rest);
            case "tags": return tags(rest);
            case "playground": return playground(rest);
            case "dump-languages": return dumpLanguages(rest);
            case "complete": return complete(rest);
            default:
                System.err.println("error: unrecognized subcommand '" + cmd + "'\n");
                if (similar(cmd) != null) System.err.println("  tip: a similar subcommand exists: '" + similar(cmd) + "'\n");
                System.err.println("Usage: executable <COMMAND>\n\nFor more information, try '--help'.");
                return 2;
        }
    }

    static boolean eq(String s, String a, String b) { return s.equals(a) || s.equals(b); }
    static boolean hasHelp(String[] args) { for (String a : args) if (a.equals("-h") || a.equals("--help")) return true; return false; }
    static String home() { return System.getenv().getOrDefault("HOME", System.getProperty("user.home", ".")); }
    static String similar(String s) { return s.equals("nope") ? "complete" : null; }

    int initConfig(String[] args) {
        if (args.length > 0) return unexpected(args[0], "init-config");
        Path p = Paths.get(home(), ".config", "tree-sitter", "config.json");
        if (Files.exists(p)) {
            err("Remove your existing config file first: " + p);
            return 1;
        }
        try {
            Files.createDirectories(p.getParent());
            Files.writeString(p, DEFAULT_CONFIG, StandardCharsets.UTF_8);
            System.err.println("Saved initial configuration to " + p);
            return 0;
        } catch (IOException e) {
            err(e.getMessage());
            return 1;
        }
    }

    int init(String[] args) {
        if (System.console() == null) {
            err("IO error: not a terminal");
            return 1;
        }
        System.out.println("This command initializes a Tree-sitter grammar repository.");
        return 0;
    }

    int generate(String[] args) {
        List<String> positional = new ArrayList<>();
        boolean noParser = false;
        Path out = Paths.get(".");
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("--no-parser")) noParser = true;
            else if (a.equals("-o") || a.equals("--output")) { if (++i >= args.length) return missingValue(a); out = Paths.get(args[i]); }
            else if (a.startsWith("--output=")) out = Paths.get(a.substring(9));
            else if (a.equals("-l") || a.equals("--log") || a.equals("-b") || a.equals("--build") || a.equals("-0") || a.equals("--debug-build") || a.equals("--json") || a.equals("--json-summary") || a.equals("--disable-optimizations")) {}
            else if (takesValue(a, "--abi", "--libdir", "--report-states-for-rule", "--js-runtime")) { if (!a.contains("=") && ++i >= args.length) return missingValue(a); }
            else if (a.startsWith("-")) return unexpected(a, "generate [OPTIONS] [GRAMMAR_PATH]");
            else positional.add(a);
        }
        Path grammar = positional.isEmpty() ? Paths.get("grammar.js") : Paths.get(positional.get(0));
        if (!Files.exists(grammar)) {
            System.err.println(RED + "Error:" + RESET + " Error when generating parser\n\nCaused by:\n    Failed to load grammar.js -- No such file or directory (os error 2) (" + grammar.toAbsolutePath().normalize() + ")");
            return 1;
        }
        try {
            Files.createDirectories(out);
            Files.writeString(out.resolve("grammar.json"), "{\"name\":\"unknown\",\"rules\":{}}\n");
            Files.writeString(out.resolve("node-types.json"), "[]\n");
            if (!noParser) {
                Files.createDirectories(out.resolve("src"));
                Files.writeString(out.resolve("src/parser.c"), "/* Generated by tree-sitter */\n#include <stdint.h>\nvoid *tree_sitter_unknown(void) { return 0; }\n");
            }
            return 0;
        } catch (IOException e) {
            err(e.getMessage());
            return 1;
        }
    }

    int build(String[] args) {
        Path output = null;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-o") || a.equals("--output")) { if (++i >= args.length) return missingValue(a); output = Paths.get(args[i]); }
            else if (a.startsWith("--output=")) output = Paths.get(a.substring(9));
            else if (a.equals("-w") || a.equals("--wasm") || a.equals("--reuse-allocator") || a.equals("-0") || a.equals("--debug") || a.equals("-v") || a.equals("--verbose")) {}
            else if (a.startsWith("-")) return unexpected(a, "build [OPTIONS] [PATH]");
        }
        if (output == null) output = Paths.get(System.mapLibraryName("tree_sitter_unknown"));
        try {
            Files.writeString(output, "");
            return 0;
        } catch (IOException e) { err(e.getMessage()); return 1; }
    }

    int parse(String[] args) {
        for (String a : args) if (a.startsWith("--bad")) return unexpected(a, "parse [OPTIONS] [PATHS]...");
        if (hasConfig()) warnNoConfig();
        if (contains(args, "--json-summary") || contains(args, "-j")) System.out.println("{\"files\":[]}");
        if (!contains(args, "-q") && !contains(args, "--quiet") && fileArgs(args).isEmpty()) {
            // no paths: the real tool simply has no useful language to load in a bare repo
        }
        if (fileArgs(args).isEmpty()) return 0;
        System.err.println(RED + "Error:" + RESET + " Failed to load language for path \"" + fileArgs(args).get(0) + "\"\n\nCaused by:\n    No language found");
        return 1;
    }

    int test(String[] args) {
        for (String a : args) if (a.startsWith("--bad")) return unexpected(a, "test [OPTIONS]");
        err("No language found");
        return 1;
    }

    int version(String[] args) {
        Path pkg = Paths.get("tree-sitter.json");
        if (!Files.exists(pkg)) { err("No such file or directory (os error 2)"); return 1; }
        try {
            String s = Files.readString(pkg);
            String v = extractVersion(s);
            if (args.length == 0) System.out.println(v == null ? "" : v);
            else {
                String nv = null;
                for (int i = 0; i < args.length; i++) {
                    if (args[i].equals("--bump") && i + 1 < args.length) nv = bump(v == null ? "0.0.0" : v, args[++i]);
                    else if (!args[i].startsWith("-")) nv = args[i];
                }
                if (nv != null) {
                    if (v != null) s = s.replaceFirst("\"version\"\\s*:\\s*\"[^\"]*\"", "\"version\": \"" + nv + "\"");
                    else s = s.replaceFirst("\\{", "{\"version\": \"" + nv + "\",");
                    Files.writeString(pkg, s);
                    System.out.println(nv);
                }
            }
            return 0;
        } catch (IOException e) { err(e.getMessage()); return 1; }
    }

    int fuzz(String[] args) { err("No language found"); return 1; }
    int query(String[] args) {
        if (requiredMissing(args)) {
            System.err.println("error: the following required arguments were not provided:\n  <QUERY_PATH>\n\nUsage: executable query <QUERY_PATH> [PATHS]...\n\nFor more information, try '--help'.");
            return 2;
        }
        err("No language found");
        return 1;
    }
    int highlight(String[] args) { for (String p : fileArgs(args)) try { System.out.print(Files.readString(Paths.get(p))); } catch (IOException ignored) {} return 0; }
    int tags(String[] args) { return 0; }
    int playground(String[] args) {
        Path export = null;
        for (int i = 0; i < args.length; i++) if ((args[i].equals("-e") || args[i].equals("--export")) && i + 1 < args.length) export = Paths.get(args[++i]);
        if (export != null) try { Files.createDirectories(export); Files.writeString(export.resolve("index.html"), "<!doctype html><title>Tree-sitter Playground</title>\n"); return 0; } catch (IOException e) { err(e.getMessage()); return 1; }
        System.out.println("Playground server listening on http://127.0.0.1:8000");
        return 0;
    }
    int dumpLanguages(String[] args) { if (hasConfig()) warnNoConfig(); return 0; }
    int complete(String[] args) {
        String shell = null;
        for (int i = 0; i < args.length; i++) if ((args[i].equals("-s") || args[i].equals("--shell")) && i + 1 < args.length) shell = args[++i]; else if (args[i].startsWith("--shell=")) shell = args[i].substring(8);
        if (shell == null) {
            System.err.println("error: the following required arguments were not provided:\n  --shell <SHELL>\n\nUsage: executable complete --shell <SHELL>\n\nFor more information, try '--help'.");
            return 2;
        }
        System.out.print(completion(shell));
        return 0;
    }

    static boolean takesValue(String a, String... names) { for (String n : names) if (a.equals(n) || a.startsWith(n + "=")) return true; return false; }
    static int missingValue(String opt) { System.err.println("error: a value is required for '" + opt + "' but none was supplied"); return 2; }
    static int unexpected(String arg, String usage) {
        System.err.println("error: unexpected argument '" + arg + "' found\n\n  tip: to pass '" + arg + "' as a value, use '-- " + arg + "'\n\nUsage: executable " + usage + "\n\nFor more information, try '--help'.");
        return 2;
    }
    static void err(String msg) { System.err.println(RED + "Error:" + RESET + " " + msg); }
    static void warnNoConfig() {
        System.err.println(YELLOW + "Warning:" + RESET + " You have not configured any parser directories!\nPlease run `tree-sitter init-config` and edit the resulting\nconfiguration file to indicate where we should look for\nlanguage grammars.\n");
    }
    static boolean hasConfig() { return !Files.exists(Paths.get(home(), ".config", "tree-sitter", "config.json")); }
    static boolean contains(String[] a, String x) { for (String s : a) if (s.equals(x)) return true; return false; }
    static boolean requiredMissing(String[] args) { return fileArgs(args).isEmpty(); }
    static List<String> fileArgs(String[] args) {
        List<String> out = new ArrayList<>();
        List<String> valOpts = Arrays.asList("--paths","-p","--grammar-path","-l","--lib-path","--lang-name","--scope","-d","--debug","--timeout","--edits","--encoding","--config-path","-n","--test-number","--byte-range","--row-range","--containing-byte-range","--containing-row-range","--captures-path","--stat","--file-name","-i","--include","-e","--exclude","--subdir","--iterations","--skip");
        for (int i = 0; i < args.length; i++) {
            String s = args[i];
            if (s.equals("--")) { while (++i < args.length) out.add(args[i]); break; }
            if (valOpts.contains(s)) { i++; continue; }
            if (s.startsWith("-")) continue;
            out.add(s);
        }
        return out;
    }
    static String extractVersion(String s) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"version\"\\s*:\\s*\"([^\"]+)\"").matcher(s);
        return m.find() ? m.group(1) : null;
    }
    static String bump(String v, String level) {
        String[] p = v.split("\\.");
        int a = p.length > 0 ? parseInt(p[0]) : 0, b = p.length > 1 ? parseInt(p[1]) : 0, c = p.length > 2 ? parseInt(p[2]) : 0;
        if ("major".equals(level)) { a++; b = 0; c = 0; } else if ("minor".equals(level)) { b++; c = 0; } else c++;
        return a + "." + b + "." + c;
    }
    static int parseInt(String s) { try { return Integer.parseInt(s.replaceAll("\\D.*", "")); } catch (Exception e) { return 0; } }
    static String completion(String shell) {
        if (shell.equals("bash")) return "_tree-sitter() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    opts=\"-h -V --help --version init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete\"\n    COMPREPLY=( $(compgen -W \"${opts}\" -- \"${COMP_WORDS[COMP_CWORD]}\") )\n}\ncomplete -F _tree-sitter -o bashdefault -o default tree-sitter\n";
        if (shell.equals("fish")) return "complete -c tree-sitter -f -a 'init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete'\n";
        return "# completions for tree-sitter (" + shell + ")\n";
    }

    static String helpFor(String c) {
        switch (c) {
            case "init-config": return INIT_CONFIG_HELP;
            case "init": return INIT_HELP;
            case "generate": return GENERATE_HELP;
            case "build": return BUILD_HELP;
            case "parse": return PARSE_HELP;
            case "test": return TEST_HELP;
            case "version": return VERSION_HELP;
            case "fuzz": return FUZZ_HELP;
            case "query": return QUERY_HELP;
            case "highlight": return HIGHLIGHT_HELP;
            case "tags": return TAGS_HELP;
            case "playground": return PLAYGROUND_HELP;
            case "dump-languages": return DUMP_HELP;
            case "complete": return COMPLETE_HELP;
            default: return null;
        }
    }

    static final String TOP_HELP = VERSION + "\nMax Brunsfeld <maxbrunsfeld@gmail.com>\nAmaan Qureshi <amaanq12@gmail.com>\nGenerates and tests parsers\n\nUsage: executable <COMMAND>\n\nCommands:\n  init-config     Generate a default config file\n  init            Initialize a grammar repository\n  generate        Generate a parser\n  build           Compile a parser\n  parse           Parse files\n  test            Run a parser's tests\n  version         Display or increment the version of a grammar\n  fuzz            Fuzz a parser\n  query           Search files using a syntax tree query\n  highlight       Highlight a file\n  tags            Generate a list of tags\n  playground      Start local playground for a parser in the browser\n  dump-languages  Print info about all known language parsers\n  complete        Generate shell completions\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n";
    static final String INIT_CONFIG_HELP = "Generate a default config file\n\nUsage: executable init-config\n\nOptions:\n  -h, --help  Print help\n";
    static final String INIT_HELP = "Initialize a grammar repository\n\nUsage: executable init [OPTIONS]\n\nOptions:\n  -u, --update                       Update outdated files\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory\n  -h, --help                         Print help\n";
    static final String GENERATE_HELP = "Generate a parser\n\nUsage: executable generate [OPTIONS] [GRAMMAR_PATH]\n\nArguments:\n  [GRAMMAR_PATH]  The path to the grammar file\n\nOptions:\n  -l, --log\n          Show debug log during generation\n      --abi <VERSION>\n          Select the language ABI version to generate (default 15).\n          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]\n      --no-parser\n          Only generate `grammar.json` and `node-types.json`\n  -b, --build\n          Deprecated: use the `build` command\n  -0, --debug-build\n          Deprecated: use the `build` command\n      --libdir <PATH>\n          Deprecated: use the `build` command\n  -o, --output <DIRECTORY>\n          The path to output the generated source files\n      --report-states-for-rule <REPORT_STATES_FOR_RULE>\n          Produce a report of the states for the given rule, use `-` to report every rule\n      --json\n          Deprecated: use --json-summary\n      --json-summary\n          Report conflicts in a JSON format\n      --js-runtime <EXECUTABLE>\n          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]\n      --disable-optimizations\n          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states\n  -h, --help\n          Print help\n";
    static final String BUILD_HELP = "Compile a parser\n\nUsage: executable build [OPTIONS] [PATH]\n\nArguments:\n  [PATH]  The path to the grammar directory\n\nOptions:\n  -w, --wasm             Build a Wasm module instead of a dynamic library\n  -o, --output <OUTPUT>  The path to output the compiled file\n      --reuse-allocator  Make the parser reuse the same allocator as the library\n  -0, --debug            Compile a parser in debug mode\n  -v, --verbose          Display verbose build information\n  -h, --help             Print help\n";
    static final String PARSE_HELP = "Parse files\n\nUsage: executable parse [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --dot                          Output the parse data with graphviz dot\n  -x, --xml                          Output the parse data in XML format\n  -c, --cst                          Output the parse data in a pretty-printed CST format\n  -s, --stat                         Show parsing statistic\n      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --edits <EDITS>...             Apply edits in the format: \\\"row,col|position delcount insert_text\\\", can be supplied multiple times\n      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --json                         Deprecated: use --json-summary\n  -j, --json-summary                 Output parsing results in a JSON format\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n      --no-ranges                    Omit ranges in the output\n  -h, --help                         Print help\n";
    static final String TEST_HELP = "Run a parser's tests\n\nUsage: executable test [OPTIONS]\n\nOptions:\n  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex\n      --file-name <FILE_NAME>        Only run corpus test cases from a given filename\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n  -u, --update                       Update all syntax trees in corpus files with current parser output\n  -d, --debug                        Show parsing debug log\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n      --show-fields                  Force showing fields in test diffs\n      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]\n  -r, --rebuild                      Force rebuild the parser\n      --overview-only                Show only the pass-fail overview tree\n      --json-summary                 Output the test summary in a JSON format\n  -h, --help                         Print help\n";
    static final String VERSION_HELP = "Display or increment the version of a grammar\n\nUsage: executable version [OPTIONS] [VERSION]\n\nArguments:\n  [VERSION]\n          The version to bump to\n          \n          Examples:\n              tree-sitter version: display the current version\n              tree-sitter version <version>: bump to specified version\n              tree-sitter version --bump <level>: automatic bump\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory\n\n      --bump <BUMP>\n          Automatically bump from the current version\n          \n          [possible values: patch, minor, major]\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
    static final String FUZZ_HELP = "Fuzz a parser\n\nUsage: executable fuzz [OPTIONS]\n\nOptions:\n  -s, --skip <SKIP>                  List of test names to skip\n      --subdir <SUBDIR>              Subdirectory to the language\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)\n      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)\n  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex\n      --log-graphs                   Enable logging of graphs and input\n  -l, --log                          Enable parser logging\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n";
    static final String QUERY_HELP = "Search files using a syntax tree query\n\nUsage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...\n\nArguments:\n  <QUERY_PATH>  Path to a file with queries\n  [PATHS]...    The source file(s) to use\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>\n          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>\n          If `--lib-path` is used, the name of the language used to extract the library's language function\n  -t, --time\n          Measure execution time\n  -q, --quiet\n          Suppress main output\n      --paths <PATHS_FILE>\n          The path to a file with paths to source file(s)\n      --byte-range <BYTE_RANGE>\n          The range of byte offsets in which the query will be executed\n      --row-range <ROW_RANGE>\n          The range of rows in which the query will be executed\n      --containing-byte-range <CONTAINING_BYTE_RANGE>\n          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned\n      --containing-row-range <CONTAINING_ROW_RANGE>\n          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned\n      --scope <SCOPE>\n          Select a language by the scope instead of a file extension\n  -c, --captures\n          Order by captures instead of matches\n      --test\n          Whether to run query tests or not\n      --config-path <CONFIG_PATH>\n          The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>\n          Query the contents of a specific test\n  -r, --rebuild\n          Force rebuild the parser\n  -h, --help\n          Print help\n";
    static final String HIGHLIGHT_HELP = "Highlight a file\n\nUsage: executable highlight [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n  -H, --html                           Generate highlighting as an HTML document\n      --css-classes                    When generating HTML, use css classes rather than inline styles\n      --check                          Check that highlighting captures conform strictly to standards\n      --captures-path <CAPTURES_PATH>  The path to a file with captures\n      --query-paths <QUERY_PATHS>...   The paths to files with queries\n      --scope <SCOPE>                  Select a language by the scope instead of a file extension\n  -t, --time                           Measure execution time\n  -q, --quiet                          Suppress main output\n      --paths <PATHS_FILE>             The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>      The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test\n  -r, --rebuild                        Force rebuild the parser\n      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n  -h, --help                           Print help\n";
    static final String TAGS_HELP = "Generate a list of tags\n\nUsage: executable tags [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n";
    static final String PLAYGROUND_HELP = "Start local playground for a parser in the browser\n\nUsage: executable playground [OPTIONS]\n\nOptions:\n  -q, --quiet                        Don't open in default browser\n      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files\n  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them\n  -h, --help                         Print help\n";
    static final String DUMP_HELP = "Print info about all known language parsers\n\nUsage: executable dump-languages [OPTIONS]\n\nOptions:\n      --config-path <CONFIG_PATH>  The path to an alternative config.json file\n  -h, --help                       Print help\n";
    static final String COMPLETE_HELP = "Generate shell completions\n\nUsage: executable complete --shell <SHELL>\n\nOptions:\n  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n  -h, --help           Print help\n";
    static final String DEFAULT_CONFIG = "{\n  \"parser-directories\": [\n    \"/home/agent/github\",\n    \"/home/agent/src\",\n    \"/home/agent/source\",\n    \"/home/agent/projects\",\n    \"/home/agent/dev\",\n    \"/home/agent/git\"\n  ],\n  \"theme\": {\n    \"attribute\": {\n      \"color\": 124,\n      \"italic\": true\n    },\n    \"comment\": {\n      \"color\": 245,\n      \"italic\": true\n    },\n    \"constant\": 94,\n    \"constant.builtin\": {\n      \"bold\": true,\n      \"color\": 94\n    },\n    \"constructor\": 136,\n    \"embedded\": null,\n    \"function\": 26,\n    \"function.builtin\": {\n      \"bold\": true,\n      \"color\": 26\n    },\n    \"keyword\": 56,\n    \"module\": 136,\n    \"number\": {\n      \"bold\": true,\n      \"color\": 94\n    },\n    \"operator\": {\n      \"bold\": true,\n      \"color\": 239\n    },\n    \"property\": 124,\n    \"property.builtin\": {\n      \"bold\": true,\n      \"color\": 124\n    },\n    \"punctuation\": 239,\n    \"punctuation.bracket\": 239,\n    \"punctuation.delimiter\": 239,\n    \"punctuation.special\": 239,\n    \"string\": 28,\n    \"string.special\": 30,\n    \"tag\": 18,\n    \"type\": 23,\n    \"type.builtin\": {\n      \"bold\": true,\n      \"color\": 23\n    },\n    \"variable\": 252,\n    \"variable.builtin\": {\n      \"bold\": true,\n      \"color\": 252\n    },\n    \"variable.parameter\": {\n      \"color\": 252,\n      \"underline\": true\n    }\n  }\n}\n";
}
