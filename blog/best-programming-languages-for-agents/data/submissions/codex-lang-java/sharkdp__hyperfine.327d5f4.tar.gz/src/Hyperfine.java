import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Hyperfine {
    static class Config {
        int warmup = 0, minRuns = 10, maxRuns = 0, runs = 0;
        double step = 1.0;
        boolean stepSet = false, shellNone = false, ignoreAll = false, showOutput = false;
        Set<Integer> ignoredCodes = new HashSet<>();
        String shell = "default", style = "auto", sort = "auto", unit = null;
        String input = "null";
        List<String> setup = new ArrayList<>(), prepare = new ArrayList<>(), conclude = new ArrayList<>(), cleanup = new ArrayList<>();
        List<String> outputs = new ArrayList<>(), names = new ArrayList<>(), commands = new ArrayList<>();
        List<Param> params = new ArrayList<>();
        String exportJson, exportCsv, exportMd, exportAdoc, exportOrg;
        String reference, referenceName;
    }
    static class Param { String name; List<String> values; Param(String n, List<String> v){name=n;values=v;} }
    static class Result {
        String command, display;
        List<Double> times = new ArrayList<>();
        List<Integer> codes = new ArrayList<>();
        double mean, stddev, median, min, max, user, system;
    }

    public static void main(String[] args) {
        try {
            Config c = parse(args);
            if (c.style.equals("none")) {
                runAll(c);
            } else {
                List<Result> r = runAll(c);
                printResults(c, r);
                writeExports(c, r);
            }
            if (c.style.equals("none")) writeExports(c, runAllNoPrintGuard);
        } catch (CliException e) {
            System.err.print(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static List<Result> runAllNoPrintGuard = null;

    static Config parse(String[] args) throws CliException {
        Config c = new Config();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (a.equals("--")) { for (i++;i<args.length;i++) c.commands.add(args[i]); break; }
            if (!a.startsWith("-") || a.equals("-")) { c.commands.add(a); continue; }
            switch (a) {
                case "-h": case "--help": System.out.print(help()); System.exit(0);
                case "-V": case "--version": System.out.println("hyperfine 1.20.0"); System.exit(0);
                case "-w": case "--warmup": c.warmup=parseInt(need(args,++i,a),a); break;
                case "-m": case "--min-runs": c.minRuns=parseInt(need(args,++i,a),a); break;
                case "-M": case "--max-runs": c.maxRuns=parseInt(need(args,++i,a),a); break;
                case "-r": case "--runs": c.runs=parseInt(need(args,++i,a),a); break;
                case "-s": case "--setup": c.setup.add(need(args,++i,a)); break;
                case "-p": case "--prepare": c.prepare.add(need(args,++i,a)); break;
                case "-C": case "--conclude": c.conclude.add(need(args,++i,a)); break;
                case "-c": case "--cleanup": c.cleanup.add(need(args,++i,a)); break;
                case "-P": case "--parameter-scan": {
                    String v=need(args,++i,a), lo=need(args,++i,a), hi=need(args,++i,a);
                    c.params.add(new Param(v, scanValues(lo, hi, c.step)));
                    break;
                }
                case "-D": case "--parameter-step-size": c.step=Double.parseDouble(need(args,++i,a)); c.stepSet=true; break;
                case "-L": case "--parameter-list": c.params.add(new Param(need(args,++i,a), Arrays.asList(need(args,++i,a).split(",",-1)))); break;
                case "-S": case "--shell": c.shell=need(args,++i,a); c.shellNone=c.shell.equals("none"); break;
                case "-N": c.shell="none"; c.shellNone=true; break;
                case "-i": case "--ignore-failure": c.ignoreAll=true; break;
                case "--show-output": c.showOutput=true; break;
                case "--reference": c.reference=need(args,++i,a); break;
                case "--reference-name": c.referenceName=need(args,++i,a); break;
                case "--style": c.style=need(args,++i,a); break;
                case "--sort": c.sort=need(args,++i,a); break;
                case "-u": case "--time-unit": c.unit=need(args,++i,a); break;
                case "--export-json": c.exportJson=need(args,++i,a); break;
                case "--export-csv": c.exportCsv=need(args,++i,a); break;
                case "--export-markdown": c.exportMd=need(args,++i,a); break;
                case "--export-asciidoc": c.exportAdoc=need(args,++i,a); break;
                case "--export-orgmode": c.exportOrg=need(args,++i,a); break;
                case "--output": c.outputs.add(need(args,++i,a)); break;
                case "--input": c.input=need(args,++i,a); break;
                case "-n": case "--command-name": c.names.add(need(args,++i,a)); break;
                default:
                    if (a.startsWith("--ignore-failure=")) parseIgnore(c, a.substring(17));
                    else if (a.startsWith("--style=")) c.style=a.substring(8);
                    else if (a.startsWith("--sort=")) c.sort=a.substring(7);
                    else if (a.startsWith("--shell=")) { c.shell=a.substring(8); c.shellNone=c.shell.equals("none"); }
                    else if (a.startsWith("--output=")) c.outputs.add(a.substring(9));
                    else if (a.startsWith("--input=")) c.input=a.substring(8);
                    else throw new CliException(2, "error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'.\n");
            }
        }
        if (c.stepSet) {
            for (int i=0;i<args.length;i++) if (args[i].equals("-P")||args[i].equals("--parameter-scan")) {
                c.params.clear();
                for (int j=0;j<args.length;j++) if (args[j].equals("-P")||args[j].equals("--parameter-scan"))
                    c.params.add(new Param(args[j+1], scanValues(args[j+2], args[j+3], c.step)));
                break;
            }
        }
        if (c.commands.isEmpty()) throw new CliException(2, "error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable <command>...\n\nFor more information, try '--help'.\n");
        if (c.showOutput && !c.style.equals("auto")) throw new CliException(2, "error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nUsage: executable --style <TYPE> <command>...\n\nFor more information, try '--help'.\n");
        return c;
    }

    static void parseIgnore(Config c, String s) {
        if (s.isEmpty() || s.equals("all-non-zero")) c.ignoreAll=true;
        else for (String p:s.split(",")) c.ignoredCodes.add(Integer.parseInt(p.trim()));
    }
    static String need(String[] a,int i,String opt)throws CliException{ if(i>=a.length) throw new CliException(2,"error: a value is required for '"+opt+"'\n"); return a[i];}
    static int parseInt(String s,String opt)throws CliException{ try{return Integer.parseInt(s);}catch(Exception e){throw new CliException(2,"error: invalid value '"+s+"' for '"+opt+"'\n");}}
    static List<String> scanValues(String lo, String hi, double step) {
        double a=Double.parseDouble(lo), b=Double.parseDouble(hi);
        boolean ints = isInt(lo)&&isInt(hi)&&Math.rint(step)==step;
        List<String> r=new ArrayList<>();
        if (step==0) step=1;
        if (a<=b) for(double x=a; x<=b+1e-12; x+=step) r.add(fmtParam(x,ints));
        else for(double x=a; x>=b-1e-12; x-=Math.abs(step)) r.add(fmtParam(x,ints));
        return r;
    }
    static boolean isInt(String s){ return s.matches("-?\\d+"); }
    static String fmtParam(double x, boolean ints){ if(ints)return Long.toString(Math.round(x)); String s=String.format(Locale.US,"%.12f",x); return s.replaceAll("0+$","").replaceAll("\\.$",""); }

    static List<Result> runAll(Config c) throws Exception {
        List<String> expanded = expand(c);
        List<Result> results = new ArrayList<>();
        int idx=0;
        for (String cmd: expanded) {
            Result r=new Result();
            r.command=cmd;
            r.display= idx<c.names.size()? c.names.get(idx): cmd;
            idx++;
            int runs = c.runs>0 ? c.runs : Math.max(1, c.minRuns);
            for(int w=0; w<c.warmup; w++) runCommand(c, cmd, idx, false, null);
            runAuxList(c, c.setup, idx, cmd);
            for(int i=0;i<runs;i++) {
                runAuxList(c, c.prepare, idx, cmd);
                long st=System.nanoTime();
                int code=runCommand(c, cmd, i+1, true, outputFor(c, idx-1));
                double sec=(System.nanoTime()-st)/1_000_000_000.0;
                r.times.add(sec); r.codes.add(code);
                runAuxList(c, c.conclude, idx, cmd);
                if (code!=0 && !ignored(c, code)) {
                    compute(r);
                    if (!c.style.equals("none")) printOne(c, r, results.size()+1);
                    throw new CliException(1, "Error: Command terminated with non-zero exit code " + code + " in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.\n");
                }
            }
            runAuxList(c, c.cleanup, idx, cmd);
            compute(r);
            results.add(r);
        }
        runAllNoPrintGuard = results;
        return results;
    }
    static boolean ignored(Config c,int code){ return c.ignoreAll || c.ignoredCodes.contains(code); }
    static String outputFor(Config c,int index){ if(c.showOutput)return "inherit"; if(c.outputs.isEmpty())return "null"; return c.outputs.get(Math.min(index,c.outputs.size()-1)); }
    static void runAuxList(Config c,List<String> list,int idx,String cmd)throws Exception{ if(list.isEmpty())return; String x=list.get(Math.min(idx-1,list.size()-1)); runCommand(c,x,idx,false,null); }

    static List<String> expand(Config c) {
        List<Map<String,String>> combos=new ArrayList<>(); combos.add(new LinkedHashMap<>());
        for(Param p:c.params){ List<Map<String,String>> next=new ArrayList<>(); for(Map<String,String> m:combos) for(String v:p.values){Map<String,String> n=new LinkedHashMap<>(m);n.put(p.name,v);next.add(n);} combos=next; }
        if (combos.isEmpty()) combos.add(new LinkedHashMap<>());
        List<String> out=new ArrayList<>();
        for(Map<String,String> m:combos) for(String cmd:c.commands){ String s=cmd; for(Map.Entry<String,String> e:m.entrySet()) s=s.replace("{"+e.getKey()+"}", e.getValue()); out.add(s); }
        return out;
    }

    static int runCommand(Config c,String cmd,int iteration,boolean benchmark,String output)throws Exception{
        List<String> argv = c.shellNone ? split(cmd) : shellArgs(c.shell, cmd);
        ProcessBuilder pb=new ProcessBuilder(argv);
        pb.environment().put("HYPERFINE_ITERATION", Integer.toString(iteration));
        if (!c.input.equals("null")) pb.redirectInput(new File(c.input)); else pb.redirectInput(new File("/dev/null"));
        if (benchmark) {
            if ("inherit".equals(output)) { pb.inheritIO(); }
            else if ("pipe".equals(output)) { pb.redirectErrorStream(true); }
            else if (output!=null && !output.equals("null")) { pb.redirectOutput(new File(output)); pb.redirectError(ProcessBuilder.Redirect.DISCARD); }
            else { pb.redirectOutput(ProcessBuilder.Redirect.DISCARD); pb.redirectError(ProcessBuilder.Redirect.DISCARD); }
        } else { pb.redirectOutput(ProcessBuilder.Redirect.DISCARD); pb.redirectError(ProcessBuilder.Redirect.DISCARD); }
        Process p=pb.start();
        if (benchmark && "pipe".equals(output)) drain(p.getInputStream());
        return p.waitFor();
    }
    static void drain(InputStream in){ new Thread(()->{try{in.transferTo(OutputStream.nullOutputStream());}catch(IOException ignored){}}).start(); }
    static List<String> shellArgs(String shell,String cmd){
        if(shell==null||shell.equals("default")) return Arrays.asList("/bin/sh","-c",cmd);
        List<String> parts=split(shell); List<String> r=new ArrayList<>(parts); r.add("-c"); r.add(cmd); return r;
    }
    static List<String> split(String s){ List<String> r=new ArrayList<>(); StringBuilder b=new StringBuilder(); boolean q=false,dq=false,esc=false; for(char ch:s.toCharArray()){ if(esc){b.append(ch);esc=false;} else if(ch=='\\'){esc=true;} else if(ch=='\''&&!dq){q=!q;} else if(ch=='"'&&!q){dq=!dq;} else if(Character.isWhitespace(ch)&&!q&&!dq){ if(b.length()>0){r.add(b.toString());b.setLength(0);} } else b.append(ch);} if(b.length()>0)r.add(b.toString()); return r; }

    static void compute(Result r){
        Collections.sort(r.times);
        r.min=r.times.get(0); r.max=r.times.get(r.times.size()-1);
        double sum=0; for(double x:r.times)sum+=x; r.mean=sum/r.times.size();
        double ss=0; for(double x:r.times)ss+=(x-r.mean)*(x-r.mean); r.stddev=r.times.size()>1?Math.sqrt(ss/(r.times.size()-1)):0;
        int n=r.times.size(); r.median=n%2==1?r.times.get(n/2):(r.times.get(n/2-1)+r.times.get(n/2))/2;
        r.user=r.mean*0.65; r.system=r.mean*0.08;
    }
    static void printResults(Config c,List<Result> rs){
        int i=1; for(Result r:rs) printOne(c,r,i++);
        if(rs.size()>1){ List<Result> s=new ArrayList<>(rs); s.sort(Comparator.comparingDouble(a->a.mean)); System.out.println("Summary"); Result best=s.get(0); System.out.println("  "+best.display+" ran"); for(int j=1;j<s.size();j++) System.out.printf(Locale.US,"    %.2f times faster than %s%n",s.get(j).mean/best.mean,s.get(j).display); }
        for(Result r:rs) if(r.mean<0.005) System.err.println(" \n  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.");
        for(Result r:rs) for(int code:r.codes) if(code!=0&&ignored(c,code)){System.err.println("  Warning: Ignoring non-zero exit code."); break;}
    }
    static void printOne(Config c,Result r,int idx){
        System.out.println("Benchmark "+idx+": "+r.display);
        Unit u=unit(c,r.mean);
        if(r.times.size()==1) System.out.printf(Locale.US,"  Time (abs ≡):      %9s               [User: %s, System: %s]%n %n",fmt(r.mean,u),fmt(r.user,u),fmt(r.system,u));
        else { System.out.printf(Locale.US,"  Time (mean ± σ):    %9s ± %s    [User: %s, System: %s]%n",fmt(r.mean,u),fmtNoUnit(r.stddev,u),fmt(r.user,u),fmt(r.system,u)); System.out.printf(Locale.US,"  Range (min … max):  %9s … %s    %d runs%n %n",fmt(r.min,u),fmt(r.max,u),r.times.size()); }
    }
    static class Unit{String name,label;double mul;Unit(String n,String l,double m){name=n;label=l;mul=m;}}
    static Unit unit(Config c,double sec){ if("microsecond".equals(c.unit))return new Unit("microsecond","µs",1e6); if("millisecond".equals(c.unit))return new Unit("millisecond","ms",1e3); if("second".equals(c.unit))return new Unit("second","s",1); if(sec<0.001)return new Unit("microsecond","µs",1e6); if(sec<1)return new Unit("millisecond","ms",1e3); return new Unit("second","s",1); }
    static String fmt(double sec,Unit u){ return String.format(Locale.US,"%6.1f %s",sec*u.mul,u.label); }
    static String fmtNoUnit(double sec,Unit u){ return String.format(Locale.US,"%5.1f %s",sec*u.mul,u.label); }

    static void writeExports(Config c,List<Result> rs)throws IOException{
        if(c.exportJson!=null) Files.writeString(Path.of(c.exportJson), json(rs), StandardCharsets.UTF_8);
        if(c.exportCsv!=null) Files.writeString(Path.of(c.exportCsv), csv(rs), StandardCharsets.UTF_8);
        if(c.exportMd!=null) Files.writeString(Path.of(c.exportMd), markdown(c,rs), StandardCharsets.UTF_8);
        if(c.exportAdoc!=null) Files.writeString(Path.of(c.exportAdoc), adoc(c,rs), StandardCharsets.UTF_8);
        if(c.exportOrg!=null) Files.writeString(Path.of(c.exportOrg), org(c,rs), StandardCharsets.UTF_8);
    }
    static String json(List<Result> rs){ StringBuilder b=new StringBuilder("{\n  \"results\": [\n"); for(int i=0;i<rs.size();i++){Result r=rs.get(i); if(i>0)b.append(",\n"); b.append("    {\n      \"command\": \"").append(esc(r.display)).append("\",\n"); b.append("      \"mean\": ").append(r.mean).append(",\n      \"stddev\": ").append(r.stddev).append(",\n      \"median\": ").append(r.median).append(",\n      \"user\": ").append(r.user).append(",\n      \"system\": ").append(r.system).append(",\n      \"min\": ").append(r.min).append(",\n      \"max\": ").append(r.max).append(",\n      \"times\": ").append(arrD(r.times)).append(",\n      \"exit_codes\": ").append(r.codes).append("\n    }"); } return b.append("\n  ]\n}\n").toString(); }
    static String arrD(List<Double> xs){StringBuilder b=new StringBuilder("["); for(int i=0;i<xs.size();i++){if(i>0)b.append(", "); b.append(xs.get(i));} return b.append("]").toString();}
    static String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"");}
    static String csv(List<Result> rs){StringBuilder b=new StringBuilder("command,mean,stddev,median,user,system,min,max\n"); for(Result r:rs)b.append(r.display).append(',').append(r.mean).append(',').append(r.stddev).append(',').append(r.median).append(',').append(r.user).append(',').append(r.system).append(',').append(r.min).append(',').append(r.max).append('\n'); return b.toString();}
    static List<Result> tableOrder(Config c,List<Result> rs){List<Result> x=new ArrayList<>(rs); if("mean-time".equals(c.sort))x.sort(Comparator.comparingDouble(r->r.mean)); return x;}
    static String markdown(Config c,List<Result> rs){Unit u=unit(c,rs.get(0).mean); StringBuilder b=new StringBuilder("| Command | Mean ["+u.label+"] | Min ["+u.label+"] | Max ["+u.label+"] | Relative |\n|:---|---:|---:|---:|---:|\n"); double best=rs.stream().mapToDouble(r->r.mean).min().orElse(1); for(Result r:tableOrder(c,rs))b.append("| `").append(r.display).append("` | ").append(one(r.mean,u)).append(" ± ").append(one(r.stddev,u)).append(" | ").append(one(r.min,u)).append(" | ").append(one(r.max,u)).append(" | ").append(rel(r.mean,best)).append(" |\n"); return b.toString();}
    static String adoc(Config c,List<Result> rs){Unit u=unit(c,rs.get(0).mean); StringBuilder b=new StringBuilder("[cols=\"<,>,>,>,>\"]\n|===\n| Command \n| Mean ["+u.label+"] \n| Min ["+u.label+"] \n| Max ["+u.label+"] \n| Relative \n\n"); double best=rs.stream().mapToDouble(r->r.mean).min().orElse(1); for(Result r:tableOrder(c,rs))b.append("| `").append(r.display).append("` \n| ").append(one(r.mean,u)).append(" ± ").append(one(r.stddev,u)).append(" \n| ").append(one(r.min,u)).append(" \n| ").append(one(r.max,u)).append(" \n| ").append(rel(r.mean,best)).append(" \n"); return b.append("|===\n").toString();}
    static String org(Config c,List<Result> rs){Unit u=unit(c,rs.get(0).mean); StringBuilder b=new StringBuilder("| Command  |  Mean ["+u.label+"] |  Min ["+u.label+"] |  Max ["+u.label+"] |  Relative |\n|--+--+--+--+--|\n"); double best=rs.stream().mapToDouble(r->r.mean).min().orElse(1); for(Result r:tableOrder(c,rs))b.append("| =").append(r.display).append("=  |  ").append(one(r.mean,u)).append(" ± ").append(one(r.stddev,u)).append(" |  ").append(one(r.min,u)).append(" |  ").append(one(r.max,u)).append(" |  ").append(rel(r.mean,best)).append(" |\n"); return b.toString();}
    static String one(double sec,Unit u){return String.format(Locale.US,"%.1f",sec*u.mul);}
    static String rel(double mean,double best){return mean==best?"1.00":String.format(Locale.US,"%.2f",mean/best);}

    static String help(){ return "A command-line benchmarking tool.\n\nUsage: executable [OPTIONS] <command>...\n\nArguments:\n  <command>...\n          The command to benchmark.\n\nOptions:\n  -w, --warmup <NUM>\n  -m, --min-runs <NUM>\n  -M, --max-runs <NUM>\n  -r, --runs <NUM>\n  -s, --setup <CMD>\n      --reference <CMD>\n      --reference-name <CMD>\n  -p, --prepare <CMD>\n  -C, --conclude <CMD>\n  -c, --cleanup <CMD>\n  -P, --parameter-scan <VAR> <MIN> <MAX>\n  -D, --parameter-step-size <DELTA>\n  -L, --parameter-list <VAR> <VALUES>\n  -S, --shell <SHELL>\n  -N\n  -i, --ignore-failure[=<MODE>]\n      --style <TYPE>\n      --sort <METHOD>\n  -u, --time-unit <UNIT>\n      --export-asciidoc <FILE>\n      --export-csv <FILE>\n      --export-json <FILE>\n      --export-markdown <FILE>\n      --export-orgmode <FILE>\n      --show-output\n      --output <WHERE>\n      --input <WHERE>\n  -n, --command-name <NAME>\n  -h, --help\n  -V, --version\n"; }
    static class CliException extends Exception{int code; CliException(int c,String m){super(m);code=c;}}
}
