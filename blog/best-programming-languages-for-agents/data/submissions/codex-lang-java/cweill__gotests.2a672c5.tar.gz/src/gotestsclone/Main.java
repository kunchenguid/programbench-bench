package gotestsclone;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static class Options {
        boolean all, exported, named, noSubtests, parallel, inputs, write, version, useCmp;
        String only, excl;
        List<String> paths = new ArrayList<>();
    }

    static class Param {
        String name, type;
        boolean variadic;
        Param(String n, String t, boolean v) { name = n; type = t; variadic = v; }
    }

    static class Func {
        String name, recvName, recvType, recvBase;
        List<Param> params = new ArrayList<>();
        List<String> returns = new ArrayList<>();
        boolean method;
        String testName() {
            String fn = (!name.isEmpty() && Character.isLowerCase(name.charAt(0))) ? "_" + name : name;
            return method ? "Test" + recvBase + "_" + name : "Test" + fn;
        }
        String displayName() { return method ? recvBase + "." + name : name; }
    }

    public static void main(String[] args) throws Exception {
        Options o = parse(args);
        if (o.version) {
            System.out.println("gotests v0.0.0-20260303205902-f3b63d74369a");
            System.out.println("Go version: go1.24.5");
            System.out.println("Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f");
            System.out.println("Build time: 2026-03-03T20:59:02Z");
            return;
        }
        if (!o.all && !o.exported && o.only == null && o.excl == null) {
            System.out.println("Please specify either the -only, -excl, -exported, or -all flag");
            return;
        }
        if (o.paths.isEmpty()) {
            System.out.println("Please specify a path");
            return;
        }
        for (String p : expandPaths(o.paths)) {
            process(Path.of(p), o);
        }
    }

    static Options parse(String[] args) {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-all" -> o.all = true;
                case "-exported" -> o.exported = true;
                case "-named" -> o.named = true;
                case "-nosubtests" -> o.noSubtests = true;
                case "-parallel" -> o.parallel = true;
                case "-i" -> o.inputs = true;
                case "-w" -> o.write = true;
                case "-version" -> o.version = true;
                case "-use_go_cmp" -> o.useCmp = true;
                case "-only" -> o.only = i + 1 < args.length ? args[++i] : "";
                case "-excl" -> o.excl = i + 1 < args.length ? args[++i] : "";
                case "-template", "-template_dir", "-template_params", "-template_params_file",
                     "-ai-model", "-ai-endpoint", "-ai-min-cases", "-ai-max-cases" -> { if (i + 1 < args.length) i++; }
                case "-ai" -> {}
                case "--help", "-h" -> { help(); System.exit(0); }
                default -> o.paths.add(a);
            }
        }
        return o;
    }

    static void help() {
        System.out.println("Usage of ./executable:");
        System.out.println("  -all\n\tgenerate tests for all functions and methods");
        System.out.println("  -excl string\n\tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all");
        System.out.println("  -exported\n\tgenerate tests for exported functions and methods. Takes precedence over -only and -all");
        System.out.println("  -i\tprint test inputs in error messages");
        System.out.println("  -named\n\tswitch table tests from using slice to map (with test name for the key)");
        System.out.println("  -nosubtests\n\tdisable generating tests using the Go 1.7 subtests feature");
        System.out.println("  -only string\n\tregexp. generate tests for functions and methods that match only. Takes precedence over -all");
        System.out.println("  -parallel\n\tenable generating parallel subtests using the Go 1.7 feature");
        System.out.println("  -w\twrite output to (test) files instead of stdout");
    }

    static List<String> expandPaths(List<String> paths) throws IOException {
        List<String> out = new ArrayList<>();
        for (String p : paths) {
            if (p.endsWith("/...")) {
                Path root = Path.of(p.substring(0, p.length() - 4));
                try (var s = Files.walk(root)) {
                    s.filter(Files::isRegularFile).map(Path::toString)
                        .filter(x -> x.endsWith(".go") && !x.endsWith("_test.go")).forEach(out::add);
                }
            } else if (Files.isDirectory(Path.of(p))) {
                try (var s = Files.list(Path.of(p))) {
                    s.filter(Files::isRegularFile).map(Path::toString)
                        .filter(x -> x.endsWith(".go") && !x.endsWith("_test.go")).forEach(out::add);
                }
            } else {
                out.add(p);
            }
        }
        return out;
    }

    static void process(Path path, Options o) throws IOException {
        String src = Files.readString(path);
        String pkg = findPackage(src);
        List<String> imports = findImports(src);
        List<Func> funcs = parseFuncs(stripComments(src));
        List<Func> selected = new ArrayList<>();
        for (Func f : funcs) if (matches(f, o)) selected.add(f);
        for (Func f : selected) System.out.println("Generated " + f.testName());
        String code = generate(pkg, imports, selected, o);
        if (o.write) {
            Path out = path.resolveSibling(path.getFileName().toString().replaceAll("\\.go$", "_test.go"));
            Files.writeString(out, code);
        } else {
            System.out.print(code);
        }
    }

    static boolean matches(Func f, Options o) {
        String n = f.name;
        if (o.excl != null) return !Pattern.compile(o.excl).matcher(n).find();
        if (o.exported) return !n.isEmpty() && Character.isUpperCase(n.charAt(0));
        if (o.only != null) return Pattern.compile(o.only).matcher(n).find();
        return o.all;
    }

    static String findPackage(String src) {
        Matcher m = Pattern.compile("(?m)^\\s*package\\s+(\\w+)").matcher(src);
        return m.find() ? m.group(1) : "main";
    }

    static List<String> findImports(String src) {
        List<String> imps = new ArrayList<>();
        Matcher block = Pattern.compile("(?s)import\\s*\\((.*?)\\)").matcher(src);
        while (block.find()) {
            for (String line : block.group(1).split("\\R")) {
                String s = line.trim();
                if (s.contains("\"")) imps.add(s);
            }
        }
        Matcher single = Pattern.compile("(?m)^\\s*import\\s+((?:[\\w.]+\\s+)?\"[^\"]+\")\\s*$").matcher(src);
        while (single.find()) imps.add(single.group(1).trim());
        return imps;
    }

    static String stripComments(String s) {
        s = s.replaceAll("(?s)/\\*.*?\\*/", "");
        s = s.replaceAll("(?m)//.*$", "");
        return s;
    }

    static List<Func> parseFuncs(String src) {
        List<Func> fs = new ArrayList<>();
        Matcher m = Pattern.compile("\\bfunc\\b").matcher(src);
        while (m.find()) {
            int i = skipWs(src, m.end());
            Func f = new Func();
            if (i < src.length() && src.charAt(i) == '(') {
                int e = findMatch(src, i, '(', ')');
                parseReceiver(src.substring(i + 1, e), f);
                f.method = true;
                i = skipWs(src, e + 1);
            }
            int start = i;
            while (i < src.length() && (Character.isLetterOrDigit(src.charAt(i)) || src.charAt(i) == '_')) i++;
            if (i == start) continue;
            f.name = src.substring(start, i);
            i = skipWs(src, i);
            if (i >= src.length() || src.charAt(i) != '(') continue;
            int pe = findMatch(src, i, '(', ')');
            f.params = parseParams(src.substring(i + 1, pe));
            i = skipWs(src, pe + 1);
            int body = src.indexOf('{', i);
            if (body < 0) body = src.length();
            String ret = src.substring(i, body).trim();
            f.returns = parseReturns(ret);
            fs.add(f);
        }
        return fs;
    }

    static void parseReceiver(String s, Func f) {
        List<Param> ps = parseParams(s);
        if (!ps.isEmpty()) {
            Param p = ps.get(0);
            f.recvName = p.name.isEmpty() ? recvVar(p.type) : p.name;
            f.recvType = p.type;
            f.recvBase = baseType(p.type);
        }
    }

    static List<Param> parseParams(String s) {
        List<String> parts = splitTop(s, ',');
        List<Param> out = new ArrayList<>();
        List<String> pending = new ArrayList<>();
        for (String raw : parts) {
            String part = raw.trim();
            if (part.isEmpty()) continue;
            int sp = lastTopSpace(part);
            if (sp > 0) {
                String names = part.substring(0, sp).trim();
                String type = part.substring(sp + 1).trim();
                if (looksLikeNameList(names)) {
                    ArrayList<String> all = new ArrayList<>(pending);
                    pending.clear();
                    for (String n : names.split(",")) all.add(n.trim());
                    for (String n : all) addParam(out, n, type);
                } else {
                    addParam(out, "", part);
                }
            } else if (isIdent(part)) {
                pending.add(part);
            } else {
                addParam(out, "", part);
            }
        }
        return out;
    }

    static void addParam(List<Param> out, String name, String type) {
        boolean variadic = type.startsWith("...");
        if (variadic) type = "[]" + type.substring(3);
        if (name.isEmpty()) name = "arg" + out.size();
        out.add(new Param(name, type, variadic));
    }

    static boolean looksLikeNameList(String s) {
        for (String n : s.split(",")) if (!isIdent(n.trim())) return false;
        return true;
    }

    static boolean isIdent(String s) { return s.matches("[A-Za-z_][A-Za-z0-9_]*"); }

    static int lastTopSpace(String s) {
        int depth = 0, last = -1;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ("([{".indexOf(c) >= 0) depth++;
            else if (")]}".indexOf(c) >= 0) depth--;
            else if (Character.isWhitespace(c) && depth == 0) last = i;
        }
        return last;
    }

    static List<String> parseReturns(String s) {
        s = s.trim();
        if (s.isEmpty()) return new ArrayList<>();
        if (s.startsWith("(") && s.endsWith(")")) s = s.substring(1, s.length() - 1);
        List<String> out = new ArrayList<>();
        for (String p : splitTop(s, ',')) {
            String x = p.trim();
            if (x.isEmpty()) continue;
            int sp = lastTopSpace(x);
            if (sp > 0 && isIdent(x.substring(0, sp).trim())) x = x.substring(sp + 1).trim();
            out.add(x);
        }
        return out;
    }

    static List<String> splitTop(String s, char sep) {
        List<String> out = new ArrayList<>();
        int depth = 0, start = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ("([{".indexOf(c) >= 0) depth++;
            else if (")]}".indexOf(c) >= 0) depth--;
            else if (c == sep && depth == 0) {
                out.add(s.substring(start, i));
                start = i + 1;
            }
        }
        out.add(s.substring(start));
        return out;
    }

    static int skipWs(String s, int i) {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        return i;
    }

    static int findMatch(String s, int pos, char open, char close) {
        int d = 0;
        for (int i = pos; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == open) d++;
            else if (c == close && --d == 0) return i;
        }
        return s.length() - 1;
    }

    static String baseType(String t) {
        t = t.replace("*", "").trim();
        int b = t.indexOf('[');
        if (b >= 0) t = t.substring(0, b);
        int dot = t.lastIndexOf('.');
        if (dot >= 0) t = t.substring(dot + 1);
        return t;
    }

    static String recvVar(String t) {
        String b = baseType(t);
        return b.isEmpty() ? "r" : b.substring(0, 1).toLowerCase();
    }

    static String generate(String pkg, List<String> sourceImports, List<Func> funcs, Options o) {
        boolean needReflect = funcs.stream().anyMatch(f -> f.returns.stream().anyMatch(Main::deepType)) && !o.useCmp;
        boolean needCmp = funcs.stream().anyMatch(f -> f.returns.stream().anyMatch(Main::deepType)) && o.useCmp;
        Set<String> imports = new LinkedHashSet<>();
        if (needReflect) imports.add("\"reflect\"");
        imports.add("\"testing\"");
        Set<String> neededQuals = neededQualifiers(funcs);
        for (String imp : sourceImports) {
            String q = importQualifier(imp);
            if (neededQuals.contains(q) || imp.startsWith(". ") || imp.startsWith("_ ")) imports.add(imp);
        }
        List<String> stdImports = new ArrayList<>();
        List<String> extImports = new ArrayList<>();
        for (String imp : imports) {
            String path = imp.substring(imp.indexOf('"') + 1, imp.lastIndexOf('"'));
            if (path.contains(".")) extImports.add(imp); else stdImports.add(imp);
        }
        stdImports.sort(java.util.Comparator.comparing(Main::importPath));
        extImports.sort(java.util.Comparator.comparing(Main::importPath));
        StringBuilder sb = new StringBuilder();
        sb.append("package ").append(pkg).append("\n\n");
        if (imports.size() == 1 && !needCmp) {
            sb.append("import ").append(stdImports.isEmpty() ? extImports.get(0) : stdImports.get(0)).append("\n\n");
        } else {
            sb.append("import (\n");
            for (String imp : stdImports) sb.append("\t").append(imp).append("\n");
            for (String imp : extImports) sb.append("\t").append(imp).append("\n");
            if (needCmp) sb.append("\n\t\"github.com/google/go-cmp/cmp\"\n");
            sb.append(")\n\n");
        }
        for (int i = 0; i < funcs.size(); i++) {
            appendFunc(sb, funcs.get(i), o);
            if (i + 1 < funcs.size()) sb.append("\n");
        }
        return sb.toString();
    }

    static boolean deepType(String t) {
        t = t.trim();
        return t.startsWith("[]") || t.startsWith("map[") || t.startsWith("struct") || t.startsWith("*") || t.contains("[");
    }

    static String importPath(String imp) {
        return imp.substring(imp.indexOf('"') + 1, imp.lastIndexOf('"'));
    }

    static String importQualifier(String imp) {
        String before = imp.substring(0, imp.indexOf('"')).trim();
        if (!before.isEmpty()) return before;
        String path = importPath(imp);
        int slash = path.lastIndexOf('/');
        return slash >= 0 ? path.substring(slash + 1) : path;
    }

    static Set<String> neededQualifiers(List<Func> funcs) {
        Set<String> out = new LinkedHashSet<>();
        Pattern p = Pattern.compile("\\b([A-Za-z_][A-Za-z0-9_]*)\\.");
        for (Func f : funcs) {
            ArrayList<String> types = new ArrayList<>();
            if (f.recvType != null) types.add(f.recvType);
            for (Param a : f.params) types.add(a.type);
            types.addAll(f.returns);
            for (String t : types) {
                Matcher m = p.matcher(t);
                while (m.find()) out.add(m.group(1));
            }
        }
        return out;
    }

    static void appendFunc(StringBuilder sb, Func f, Options o) {
        sb.append("func ").append(f.testName()).append("(t *testing.T) {\n");
        if (o.parallel) sb.append("\tt.Parallel()\n");
        if (!f.params.isEmpty()) {
            sb.append("\ttype args struct {\n");
            int pad = f.params.stream().mapToInt(p -> p.name.length()).max().orElse(0);
            for (Param p : f.params) sb.append("\t\t").append(rpad(p.name, pad)).append(" ").append(p.type).append("\n");
            sb.append("\t}\n");
        }
        ArrayList<String[]> fields = new ArrayList<>();
        if (!o.named) fields.add(new String[]{"name", "string"});
        if (o.named) {
            sb.append("\ttests := map[string]struct {\n");
        } else {
            sb.append("\ttests := []struct {\n");
        }
        if (f.method) fields.add(new String[]{f.recvName, f.recvType});
        if (!f.params.isEmpty()) fields.add(new String[]{"args", "args"});
        List<String> rets = nonErrReturns(f);
        for (int i = 0; i < rets.size(); i++) {
            String wn = i == 0 ? "want" : "want" + i;
            fields.add(new String[]{wn, rets.get(i)});
        }
        if (hasErr(f)) fields.add(new String[]{"wantErr", "bool"});
        int fpad = fields.stream().mapToInt(a -> a[0].length()).max().orElse(0);
        for (String[] fld : fields) sb.append("\t\t").append(rpad(fld[0], fpad)).append(" ").append(fld[1]).append("\n");
        sb.append("\t}{\n\t\t// TODO: Add test cases.\n\t}\n");
        if (o.named) sb.append("\tfor name, tt := range tests {\n");
        else sb.append("\tfor _, tt := range tests {\n");
        String innerIndent = "\t\t";
        if (!o.noSubtests) {
            sb.append("\t\tt.Run(").append(o.named ? "name" : "tt.name").append(", func(t *testing.T) {\n");
            innerIndent = "\t\t\t";
            if (o.parallel) sb.append(innerIndent).append("t.Parallel()\n");
        }
        appendBody(sb, f, o, innerIndent);
        if (!o.noSubtests) sb.append("\t\t})\n");
        sb.append("\t}\n}\n");
    }

    static boolean hasErr(Func f) { return !f.returns.isEmpty() && f.returns.get(f.returns.size() - 1).equals("error"); }
    static List<String> nonErrReturns(Func f) {
        int n = hasErr(f) ? f.returns.size() - 1 : f.returns.size();
        return new ArrayList<>(f.returns.subList(0, n));
    }

    static void appendBody(StringBuilder sb, Func f, Options o, String in) {
        if (f.method) sb.append(in).append(f.recvName).append(" := &").append(f.recvBase).append("{}\n");
        String call = (f.method ? f.recvName + "." : "") + f.name + "(" + argsCall(f) + ")";
        List<String> vals = nonErrReturns(f);
        boolean err = hasErr(f);
        if (vals.isEmpty() && !err) {
            sb.append(in).append(call).append("\n");
            return;
        }
        if (vals.isEmpty()) {
            sb.append(in).append("if err := ").append(call).append("; (err != nil) != tt.wantErr {\n");
            sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(" error = %v, wantErr %v\"").append(fmtArgs(f, o, "err", "tt.wantErr")).append(")\n");
            sb.append(in).append("}\n");
            return;
        }
        if (vals.size() == 1 && !err) {
            String got = "got";
            String want = "tt.want";
            String ty = vals.get(0);
            if (!deepType(ty)) {
                sb.append(in).append("if got := ").append(call).append("; got != tt.want {\n");
                sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(" = %v, want %v\"").append(fmtArgs(f, o, got, want)).append(")\n");
                sb.append(in).append("}\n");
                return;
            } else if (o.useCmp) {
                sb.append(in).append("if got := ").append(call).append("; !cmp.Equal(tt.want, got) {\n");
                sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(" = %v, want %v\\ndiff=%s\"").append(fmtArgs(f, o, got, want, "cmp.Diff(tt.want, got)")).append(")\n");
                sb.append(in).append("}\n");
                return;
            } else {
                sb.append(in).append("if got := ").append(call).append("; !reflect.DeepEqual(got, tt.want) {\n");
                sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(" = %v, want %v\"").append(fmtArgs(f, o, got, want)).append(")\n");
                sb.append(in).append("}\n");
                return;
            }
        }
        String gotList = gotList(vals.size()) + (err ? ", err" : "");
        sb.append(in).append(gotList).append(" := ").append(call).append("\n");
        if (err) {
            sb.append(in).append("if (err != nil) != tt.wantErr {\n");
            sb.append(in).append("\tt.").append(o.noSubtests ? "Errorf" : "Fatalf").append("(\"").append(msgPrefix(f, o)).append(" error = %v, wantErr %v\"").append(fmtArgs(f, o, "err", "tt.wantErr")).append(")\n");
            if (o.noSubtests) sb.append(in).append("\tcontinue\n");
            sb.append(in).append("}\n");
            sb.append(in).append("if tt.wantErr {\n").append(in).append("\treturn\n").append(in).append("}\n");
        }
        for (int i = 0; i < vals.size(); i++) {
            String got = i == 0 ? "got" : "got" + i;
            String want = i == 0 ? "tt.want" : "tt.want" + i;
            String label = vals.size() == 1 ? "" : " " + got;
            if (deepType(vals.get(i))) {
                if (o.useCmp) {
                    sb.append(in).append("if !cmp.Equal(").append(want).append(", ").append(got).append(") {\n");
                    sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(label).append(" = %v, want %v\\ndiff=%s\"").append(fmtArgs(f, o, got, want, "cmp.Diff(" + want + ", " + got + ")")).append(")\n");
                } else {
                    sb.append(in).append("if !reflect.DeepEqual(").append(got).append(", ").append(want).append(") {\n");
                    sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(label).append(" = %v, want %v\"").append(fmtArgs(f, o, got, want)).append(")\n");
                }
            } else {
                sb.append(in).append("if ").append(got).append(" != ").append(want).append(" {\n");
                sb.append(in).append("\tt.Errorf(\"").append(msgPrefix(f, o)).append(label).append(" = %v, want %v\"").append(fmtArgs(f, o, got, want)).append(")\n");
            }
            sb.append(in).append("}\n");
        }
    }

    static String msgPrefix(Func f, Options o) {
        String base = f.displayName();
        if (o.noSubtests) base = "%q. " + base;
        if (o.inputs && !f.params.isEmpty()) return base + "(" + "%v, ".repeat(f.params.size()).replaceAll(", $", "") + ")";
        return base + "()";
    }

    static String fmtArgs(Func f, Options o, String... tail) {
        List<String> xs = new ArrayList<>();
        if (o.noSubtests) xs.add("tt.name");
        if (o.inputs && !f.params.isEmpty()) {
            for (Param p : f.params) xs.add("tt.args." + p.name);
        }
        xs.addAll(List.of(tail));
        return ", " + String.join(", ", xs);
    }

    static String rpad(String s, int width) {
        return s + " ".repeat(Math.max(0, width - s.length()));
    }

    static String gotList(int n) {
        List<String> gs = new ArrayList<>();
        for (int i = 0; i < n; i++) gs.add(i == 0 ? "got" : "got" + i);
        return String.join(", ", gs);
    }

    static String argsCall(Func f) {
        List<String> a = new ArrayList<>();
        for (Param p : f.params) a.add("tt.args." + p.name + (p.variadic ? "..." : ""));
        return String.join(", ", a);
    }
}
