import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Nomino {
    static class Config {
        Path dir = Paths.get(".");
        boolean noExt, mkdirs, quiet, test, overwrite;
        String generate, map, regex, sort;
        Integer maxDepth, depth;
        List<String> pos = new ArrayList<>();
    }

    static class Item {
        Path inPath, outPath;
        String in, out;
        Item(Path inPath, Path outPath, String in, String out) {
            this.inPath = inPath; this.outPath = outPath; this.in = in; this.out = out;
        }
    }

    public static void main(String[] args) {
        try {
            Config c = parse(args);
            List<Item> items = build(c);
            if (!c.overwrite) avoidCollisions(c.dir, items);
            if (!c.quiet) printTable(items);
            if (!c.test) rename(c, items);
            if (c.generate != null) writeMap(c, items);
            System.exit(0);
        } catch (UsageException e) {
            System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            String msg = e.getMessage();
            if (msg == null || msg.isBlank()) msg = e.toString();
            System.err.println("error: " + msg);
            System.exit(1);
        }
    }

    static Config parse(String[] args) {
        Config c = new Config();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h": smallHelp(); System.exit(0); break;
                case "--help": longHelp(); System.exit(0); break;
                case "-V": case "--version": System.out.println("nomino 1.6.4"); System.exit(0); break;
                case "-E": case "--no-extension": c.noExt = true; break;
                case "-k": case "--mkdir": c.mkdirs = true; break;
                case "-q": case "--quiet": c.quiet = true; break;
                case "-t": case "--test": case "--dry-run": c.test = true; break;
                case "-w": case "--overwrite": c.overwrite = true; break;
                case "-d": case "--dir": c.dir = Paths.get(req(args, ++i, a)); break;
                case "-g": case "--generate": c.generate = req(args, ++i, a); break;
                case "-m": case "--map": case "--from-file": c.map = req(args, ++i, a); break;
                case "-r": case "--regex": c.regex = req(args, ++i, a); break;
                case "-s": case "--sort": c.sort = req(args, ++i, a); break;
                case "--depth": c.depth = Integer.parseInt(req(args, ++i, a)); break;
                case "--max-depth": c.maxDepth = Integer.parseInt(req(args, ++i, a)); break;
                default:
                    if (a.startsWith("-")) throw new UsageException("error: unexpected argument '" + a + "' found\n\n  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nFor more information, try '--help'.", 2);
                    c.pos.add(a);
            }
        }
        if (c.sort != null && !c.sort.equals("asc") && !c.sort.equals("desc")) {
            throw new UsageException("error: invalid value '" + c.sort + "' for '--sort <ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'.", 2);
        }
        return c;
    }

    static String req(String[] args, int i, String opt) {
        if (i >= args.length) throw new UsageException("error: a value is required for '" + opt + "' but none was supplied", 2);
        return args[i];
    }

    static List<Item> build(Config c) throws IOException {
        if (!Files.isDirectory(c.dir)) throw new IOException("No such file or directory (os error 2)");
        if (c.map != null) return buildMap(c);
        String pattern;
        if (c.sort != null) {
            if (c.pos.isEmpty()) throw new UsageException("error: the following required arguments were not provided:\n  <OUTPUT>", 2);
            pattern = c.pos.get(c.pos.size() - 1);
            List<Path> entries = listEntries(c.dir);
            entries.sort(Nomino::naturalComparePath);
            if (c.sort.equals("desc")) Collections.reverse(entries);
            List<Item> out = new ArrayList<>();
            int idx = 1;
            for (Path p : entries) {
                String name = p.getFileName().toString();
                String baseOut = render(pattern, groupsForSort(name, idx++));
                String finalOut = c.noExt ? baseOut : appendExtension(baseOut, extension(name));
                out.add(new Item(p, c.dir.resolve(finalOut), name, finalOut));
            }
            return out;
        }
        if (c.regex != null || c.pos.size() >= 2) {
            String source = c.regex;
            if (source == null) source = c.pos.get(c.pos.size() - 2);
            pattern = c.pos.isEmpty() ? null : c.pos.get(c.pos.size() - 1);
            if (pattern == null) throw new UsageException("error: the following required arguments were not provided:\n  <OUTPUT>", 2);
            Pattern re = Pattern.compile(convertNamedGroups(source));
            List<Path> entries = listRegexEntries(c);
            entries.sort(Nomino::naturalComparePath);
            List<Item> out = new ArrayList<>();
            for (Path p : entries) {
                String rel = c.dir.relativize(p).toString();
                String normalized = rel.replace('\\', '/');
                String name = p.getFileName().toString();
                Matcher m = re.matcher(normalized);
                if (!m.find()) continue;
                GroupData gd = groupsForMatcher(m);
                String baseOut = render(pattern, gd);
                String finalOut = c.noExt ? baseOut : appendExtension(baseOut, extension(name));
                out.add(new Item(p, c.dir.resolve(finalOut), normalized, finalOut));
            }
            return out;
        }
        throw new UsageException("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.\nusage: run '/workspace/executable --help' for more information.", 1);
    }

    static List<Path> listEntries(Path dir) throws IOException {
        List<Path> entries = new ArrayList<>();
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p : ds) entries.add(p);
        }
        return entries;
    }

    static List<Path> listRegexEntries(Config c) throws IOException {
        int max = c.maxDepth != null ? c.maxDepth : (c.depth != null ? c.depth : 1);
        List<Path> out = new ArrayList<>();
        try (var s = Files.walk(c.dir, Math.max(1, max))) {
            s.filter(p -> !p.equals(c.dir)).forEach(out::add);
        }
        return out;
    }

    static List<Item> buildMap(Config c) throws IOException {
        Map<String,String> map = parseJsonObject(Files.readString(c.dir.resolve(c.map), StandardCharsets.UTF_8));
        List<Item> out = new ArrayList<>();
        for (var e : map.entrySet()) {
            out.add(new Item(c.dir.resolve(e.getKey()), c.dir.resolve(e.getValue()), e.getKey(), e.getValue()));
        }
        return out;
    }

    static class GroupData {
        Map<String,String> values = new HashMap<>();
        int auto = 1;
        String get(String key) { return values.getOrDefault(key, ""); }
    }

    static GroupData groupsForSort(String name, int idx) {
        GroupData gd = new GroupData();
        gd.values.put("0", name);
        gd.values.put("1", Integer.toString(idx));
        return gd;
    }

    static GroupData groupsForMatcher(Matcher m) {
        GroupData gd = new GroupData();
        for (int i = 0; i <= m.groupCount(); i++) {
            String v = "";
            try { v = m.group(i); } catch (Exception ignored) {}
            gd.values.put(Integer.toString(i), v == null ? "" : v);
        }
        Matcher nm = Pattern.compile("\\(\\?<([A-Za-z][A-Za-z0-9_]*)>").matcher(m.pattern().pattern());
        while (nm.find()) {
            String n = nm.group(1);
            try { String v = m.group(n); gd.values.put(n, v == null ? "" : v); } catch (Exception ignored) {}
        }
        return gd;
    }

    static String render(String pattern, GroupData gd) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < pattern.length();) {
            char ch = pattern.charAt(i);
            if (ch == '\\' && i + 1 < pattern.length() && (pattern.charAt(i+1) == '{' || pattern.charAt(i+1) == '}')) {
                sb.append(pattern.charAt(i+1)); i += 2; continue;
            }
            if (ch == '{') {
                int j = pattern.indexOf('}', i + 1);
                if (j >= 0) {
                    String inside = pattern.substring(i + 1, j);
                    String key = inside, pad = null;
                    int colon = inside.indexOf(':');
                    if (colon >= 0) { key = inside.substring(0, colon); pad = inside.substring(colon + 1); }
                    if (key.isEmpty()) key = Integer.toString(gd.auto++);
                    String val = gd.get(key);
                    if (pad != null && !pad.isEmpty() && val.matches("[0-9]+")) {
                        int width = Integer.parseInt(pad);
                        while (val.length() < width) val = "0" + val;
                    }
                    sb.append(val); i = j + 1; continue;
                }
            }
            sb.append(ch); i++;
        }
        return sb.toString();
    }

    static String extension(String name) {
        int dot = name.lastIndexOf('.');
        if (dot <= 0 || dot == name.length() - 1) return "";
        return name.substring(dot);
    }

    static String appendExtension(String out, String ext) {
        if (ext.isEmpty() || out.endsWith(ext)) return out;
        return out + ext;
    }

    static void avoidCollisions(Path dir, List<Item> items) {
        Set<Path> planned = new HashSet<>();
        for (Item it : items) {
            Path out = it.outPath;
            while (Files.exists(out) || planned.contains(out.toAbsolutePath().normalize())) {
                Path parent = out.getParent();
                String n = out.getFileName().toString();
                out = (parent == null ? Paths.get("_" + n) : parent.resolve("_" + n));
            }
            it.outPath = out;
            it.out = dir.relativize(out).toString().replace('\\', '/');
            planned.add(out.toAbsolutePath().normalize());
        }
    }

    static void rename(Config c, List<Item> items) throws IOException {
        List<Path> temps = new ArrayList<>();
        for (Item it : items) {
            Path parent = it.outPath.getParent();
            if (parent != null && !Files.exists(parent)) {
                if (c.mkdirs) Files.createDirectories(parent);
                else throw new IOException("No such file or directory (os error 2)");
            }
        }
        for (Item it : items) {
            if (!Files.exists(it.inPath)) {
                temps.add(null);
                continue;
            }
            Path tmp = Files.createTempFile(c.dir, ".nomino-", ".tmp");
            Files.move(it.inPath, tmp, StandardCopyOption.REPLACE_EXISTING);
            temps.add(tmp);
        }
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            Path tmp = temps.get(i);
            if (tmp == null) continue;
            if (it.outPath.getParent() != null && c.mkdirs) Files.createDirectories(it.outPath.getParent());
            if (c.overwrite) Files.move(tmp, it.outPath, StandardCopyOption.REPLACE_EXISTING);
            else Files.move(tmp, it.outPath);
        }
    }

    static void writeMap(Config c, List<Item> items) throws IOException {
        Path p = c.dir.resolve(c.generate);
        if (p.getParent() != null) Files.createDirectories(p.getParent());
        StringBuilder sb = new StringBuilder("{\n");
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            sb.append("  \"").append(jsonEscape(it.out)).append("\": \"").append(jsonEscape(it.in)).append("\"");
            if (i + 1 < items.size()) sb.append(",");
            sb.append("\n");
        }
        sb.append("}");
        Files.writeString(p, sb.toString(), StandardCharsets.UTF_8);
    }

    static Map<String,String> parseJsonObject(String s) {
        LinkedHashMap<String,String> m = new LinkedHashMap<>();
        Matcher mm = Pattern.compile("\"((?:\\\\.|[^\"])*)\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"").matcher(s);
        while (mm.find()) m.put(jsonUnescape(mm.group(1)), jsonUnescape(mm.group(2)));
        return m;
    }

    static String jsonEscape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
    static String jsonUnescape(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) b.append(s.charAt(++i)); else b.append(c);
        }
        return b.toString();
    }

    static String convertNamedGroups(String s) {
        return s.replaceAll("\\(\\?P<([A-Za-z][A-Za-z0-9_]*)>", "(?<$1>");
    }

    static int naturalComparePath(Path a, Path b) {
        return naturalCompare(a.getFileName().toString(), b.getFileName().toString());
    }

    static int naturalCompare(String a, String b) {
        int ia = 0, ib = 0;
        while (ia < a.length() && ib < b.length()) {
            char ca = a.charAt(ia), cb = b.charAt(ib);
            if (Character.isDigit(ca) && Character.isDigit(cb)) {
                int sa = ia; while (ia < a.length() && Character.isDigit(a.charAt(ia))) ia++;
                int sb = ib; while (ib < b.length() && Character.isDigit(b.charAt(ib))) ib++;
                String na = a.substring(sa, ia).replaceFirst("^0+(?!$)", "");
                String nb = b.substring(sb, ib).replaceFirst("^0+(?!$)", "");
                if (na.length() != nb.length()) return na.length() - nb.length();
                int cmp = na.compareTo(nb); if (cmp != 0) return cmp;
            } else {
                int cmp = Character.compare(Character.toLowerCase(ca), Character.toLowerCase(cb));
                if (cmp != 0) return cmp;
                ia++; ib++;
            }
        }
        return Integer.compare(a.length(), b.length());
    }

    static void printTable(List<Item> items) {
        int wi = "Input".length(), wo = "Output".length();
        for (Item it : items) { wi = Math.max(wi, it.in.length()); wo = Math.max(wo, it.out.length()); }
        String border = "+" + "-".repeat(wi + 2) + "+" + "-".repeat(wo + 2) + "+";
        System.out.println(border);
        System.out.printf("| %-" + wi + "s | %-" + wo + "s |%n", "Input", "Output");
        System.out.println(border);
        for (Item it : items) System.out.printf("| %-" + wi + "s | %-" + wo + "s |%n", it.in, it.out);
        System.out.println(border);
    }

    static void smallHelp() {
        System.out.println("Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nArguments:\n  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n  -d, --dir <PATH>         Sets the working directory\n      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options\n  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files\n  -h, --help               Print help (see more with '--help')\n  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing\n  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]\n      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode\n  -q, --quiet              Does not print the map table to stdout\n  -r, --regex <PATTERN>    Regex pattern to match by filenames\n  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]\n  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]\n  -V, --version            Print version\n  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename\n\nOUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.");
    }
    static void longHelp() {
        System.out.println("Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nArguments:\n  [[SOURCE] OUTPUT]...\n          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n  -d, --dir <PATH>\n          Sets the working directory\n\n      --depth <DEPTH>\n          Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n\n  -E, --no-extension\n          Does not preserve the extension of input files in 'sort' and 'regex' options\n\n  -g, --generate <PATH>\n          Stores a JSON map file in '<PATH>' after renaming files\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -k, --mkdir\n          Recursively creates all parent directories of '<OUTPUT>' if they are missing\n\n  -m, --map <PATH>\n          Sets the path of map file to be used for renaming files\n          \n          [aliases: --from-file]\n\n      --max-depth <DEPTH>\n          Optional value to set the maximum of subdirectory depth value in 'regex' mode\n\n  -q, --quiet\n          Does not print the map table to stdout\n\n  -r, --regex <PATTERN>\n          Regex pattern to match by filenames\n\n  -s, --sort <ORDER>\n          Sets the order of natural sorting (by name) to rename files using enumerator\n\n          Possible values:\n          - asc:  Sort in ascending order\n          - desc: Sort in descending order\n\n  -t, --test\n          Runs in test mode without renaming actual files\n          \n          [aliases: --dry-run]\n\n  -V, --version\n          Print version\n\n  -w, --overwrite\n          Overwrites output files, otherwise, a '_' is prepended to filename\n\nOUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.");
    }

    static class UsageException extends RuntimeException {
        int code;
        UsageException(String m, int code) { super(m); this.code = code; }
    }
}
