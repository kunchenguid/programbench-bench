import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class Main {
    static final String VERSION = "1.2";
    static final String HELP = """

USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
""";

    static class Opt {
        int width = 30, height = 30, seed;
        boolean seedSet, quiet, noReplay, timeout, override;
        String replayDir = ".";
        int nplayers = -1;
        boolean invalidNPlayers;
        List<String> commands = new ArrayList<>();
    }

    static class Bot {
        int id;
        String command, name = "";
        Process process;
        BufferedReader in;
        BufferedWriter out;
        PrintWriter log;
        boolean alive = true;
        int lastAlive = 0;
        int strength = 0;
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            if (opt.commands.isEmpty()) {
                System.out.println("Please provide the launch command string for at least one bot.");
                System.out.println("Use the --help flag for usage details.");
                System.exit(1);
            }
            if (opt.invalidNPlayers || opt.commands.size() < 1 || opt.commands.size() > 6) {
                for (String c : opt.commands) System.out.println(c);
                if (!opt.quiet) for (String c : opt.commands) System.out.println(c);
                System.out.println();
                System.out.println("A map can only accommodate between 1 and 6 players.");
                System.exit(1);
            }
            play(opt);
        } catch (ParseException e) {
            parseError(e.arg, e.value);
            System.exit(1);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static Opt parse(String[] args) throws ParseException {
        Opt o = new Opt();
        boolean rest = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (rest) { o.commands.add(a); continue; }
            switch (a) {
                case "-h": case "--help": System.out.print(HELP); return null;
                case "--version": System.out.println(); System.out.println("./executable  version: " + VERSION); return null;
                case "--": case "--ignore_rest": rest = true; break;
                case "-q": case "--quiet": o.quiet = true; break;
                case "-r": case "--noreplay": o.noReplay = true; break;
                case "-t": case "--timeout": o.timeout = true; break;
                case "-o": case "--override": o.override = true; break;
                case "-i": case "--replaydirectory":
                    if (++i >= args.length) throw new ParseException("-i (--replaydirectory)", "");
                    o.replayDir = args[i]; break;
                case "-s": case "--seed":
                    if (++i >= args.length) throw new ParseException("-s (--seed)", "");
                    o.seed = positive(args[i], "-s (--seed)"); o.seedSet = true; break;
                case "-n": case "--nplayers":
                    if (++i >= args.length) throw new ParseException("-n (--nplayers)", "");
                    o.nplayers = positive(args[i], "-n (--nplayers)");
                    if (o.nplayers < 1 || o.nplayers > 6) o.invalidNPlayers = true;
                    break;
                case "-d": case "--dimensions":
                    if (++i >= args.length) throw new ParseException("-d (--dimensions)", "");
                    int[] wh = dims(args[i], "-d (--dimensions)");
                    o.width = wh[0]; o.height = wh[1]; break;
                default:
                    o.commands.add(a);
            }
        }
        if (!o.seedSet) o.seed = (int)(System.currentTimeMillis() / 1000L);
        return o;
    }

    static int positive(String s, String arg) throws ParseException {
        try {
            int v = Integer.parseInt(s.trim());
            if (v <= 0) throw new NumberFormatException();
            return v;
        } catch (Exception e) { throw new ParseException(arg, s); }
    }

    static int[] dims(String s, String arg) throws ParseException {
        String[] p = s.trim().split("\\s+");
        if (p.length != 2) throw new ParseException(arg, s);
        return new int[]{positive(p[0], arg), positive(p[1], arg)};
    }

    static void parseError(String arg, String value) {
        System.out.println("PARSE ERROR: Argument: " + arg);
        System.out.println("             Couldn't read argument value from string '" + value + "'");
        System.out.println();
        System.out.println("Brief USAGE: ");
        System.out.println("   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a");
        System.out.println("                 string containing two space-seprated positive integers>]");
        System.out.println("                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]");
        System.out.println("                 [-h] <Array of strings> ...");
        System.out.println();
        System.out.println("For complete USAGE and HELP type: ");
        System.out.println("   ./executable --help");
        System.out.println();
    }

    static void play(Opt opt) throws Exception {
        int n = opt.commands.size();
        int turns = Math.max(1, (int)Math.round(10.0 * Math.sqrt(opt.width * opt.height)));
        Random rnd = new Random(Integer.toUnsignedLong(opt.seed));
        int[] production = new int[opt.width * opt.height];
        int[] owner = new int[production.length];
        int[] strength = new int[production.length];
        for (int y = 0; y < opt.height; y++) for (int x = 0; x < opt.width; x++) {
            int i = y * opt.width + x;
            production[i] = 1 + Math.abs((int)((x * 31L + y * 17L + opt.seed + rnd.nextInt(11)) % 10));
            strength[i] = 20 + Math.abs((int)((x * 73L + y * 41L + opt.seed + rnd.nextInt(251)) % 236));
        }
        placePlayers(n, opt.width, opt.height, owner, strength);
        String prodLine = join(production);
        String mapLine = encodeMap(owner, strength);

        List<Bot> bots = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            Bot b = new Bot(); b.id = i + 1; b.command = opt.commands.get(i); bots.add(b);
            System.out.println(b.command);
        }
        if (!opt.quiet) for (Bot b : bots) System.out.println(b.command);
        System.out.println(opt.width + " " + opt.height);

        for (Bot b : bots) startBot(b, opt);
        for (Bot b : bots) {
            send(b, String.valueOf(b.id));
            send(b, opt.width + " " + opt.height + " ");
            send(b, prodLine);
            send(b, mapLine);
            if (!opt.quiet) System.out.println("Init Message sent to player " + b.id + ".");
        }
        for (Bot b : bots) {
            String nm = readLine(b, opt.timeout ? 0 : 1000);
            if (nm == null) { b.alive = false; b.name = ""; log(b, "ERRORED!\nNo response received."); }
            else b.name = opt.override ? b.command : nm.trim();
            if (!opt.quiet) System.out.println("Init Message received from player " + b.id + ", " + b.name + ".");
        }

        for (int t = 1; t <= turns; t++) {
            if (!opt.quiet) System.out.println("Turn " + t);
            for (Bot b : bots) if (b.alive) {
                send(b, encodeMap(owner, strength));
                String moves = readLine(b, opt.timeout ? 0 : 1000);
                if (moves == null) {
                    b.alive = false;
                    if (!opt.quiet) System.out.println("Bot #" + b.id + " timeout or error (Unix) 0");
                    log(b, "ERRORED!\nNo response received.");
                } else {
                    b.lastAlive = t;
                    applyMoves(b.id, moves, opt.width, opt.height, owner, strength);
                }
            }
            for (int i = 0; i < strength.length; i++) {
                if (owner[i] > 0) strength[i] = Math.min(255, strength[i] + production[i]);
            }
        }
        for (Bot b : bots) b.strength = totalStrength(b.id, owner, strength);
        List<Bot> ranking = new ArrayList<>(bots);
        ranking.sort((a,b) -> {
            int c = Integer.compare(b.strength, a.strength);
            if (c != 0) return c;
            c = Integer.compare(b.lastAlive, a.lastAlive);
            if (c != 0) return c;
            return Integer.compare(b.id, a.id);
        });
        Map<Integer,Integer> rank = new HashMap<>();
        for (int i = 0; i < ranking.size(); i++) rank.put(ranking.get(i).id, i + 1);
        String replay = "";
        if (!opt.noReplay) replay = writeReplay(opt, bots, turns);
        if (opt.quiet) {
            for (Bot b : bots) System.out.println(b.id + " " + rank.get(b.id) + " " + turns);
            System.out.println(replay);
            String logs = "";
            for (Bot b : bots) if (b.log != null) logs += (logs.isEmpty() ? "" : " ") + b.id + "-" + opt.seed + ".log";
            System.out.println(logs + " ");
        } else {
            for (Bot b : bots) System.out.println("Player #" + b.id + ", " + b.name + ", came in rank #" + rank.get(b.id) + " and was last alive on frame #" + turns + "!");
        }
        for (Bot b : bots) closeBot(b);
    }

    static void startBot(Bot b, Opt opt) throws IOException {
        ProcessBuilder pb = new ProcessBuilder("sh", "-c", b.command);
        pb.directory(new File("."));
        pb.redirectErrorStream(true);
        b.process = pb.start();
        b.in = new BufferedReader(new InputStreamReader(b.process.getInputStream(), StandardCharsets.UTF_8));
        b.out = new BufferedWriter(new OutputStreamWriter(b.process.getOutputStream(), StandardCharsets.UTF_8));
    }

    static void send(Bot b, String s) throws IOException {
        if (!b.alive) return;
        try {
            b.out.write(s); b.out.newLine(); b.out.flush();
        } catch (IOException e) {
            b.alive = false;
        }
    }

    static String readLine(Bot b, long ms) {
        ExecutorService ex = Executors.newSingleThreadExecutor();
        Future<String> f = ex.submit(() -> b.in.readLine());
        try {
            return ms <= 0 ? f.get() : f.get(ms, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            f.cancel(true);
            return null;
        } finally { ex.shutdownNow(); }
    }

    static void closeBot(Bot b) {
        try { if (b.log != null) b.log.close(); } catch (Exception ignored) {}
        try { if (b.process != null) b.process.destroyForcibly(); } catch (Exception ignored) {}
    }

    static void log(Bot b, String msg) {
        try {
            if (b.log == null) b.log = new PrintWriter(new FileWriter(b.id + "-" + System.currentTimeMillis()/1000 + ".log", true));
            b.log.println(" --- Frame #" + Math.max(1, b.lastAlive + 1) + " ---");
            b.log.println();
            b.log.println(msg);
            b.log.flush();
        } catch (IOException ignored) {}
    }

    static void placePlayers(int n, int w, int h, int[] owner, int[] strength) {
        int[][] pos = {{w/4,h/2},{3*w/4,h/2},{w/2,h/4},{w/2,3*h/4},{w/4,h/4},{3*w/4,3*h/4}};
        for (int i = 0; i < n; i++) {
            int x = Math.floorMod(pos[i][0], w), y = Math.floorMod(pos[i][1], h);
            int idx = y*w+x; owner[idx] = i+1; strength[idx] = 100;
        }
    }

    static String encodeMap(int[] owner, int[] strength) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < owner.length) {
            int o = owner[i], c = 1; i++;
            while (i < owner.length && owner[i] == o) { c++; i++; }
            sb.append(c).append(' ').append(o).append(' ');
        }
        for (int s : strength) sb.append(s).append(' ');
        return sb.toString();
    }

    static String join(int[] a) {
        StringBuilder sb = new StringBuilder();
        for (int v : a) sb.append(v).append(' ');
        return sb.toString();
    }

    static void applyMoves(int id, String line, int w, int h, int[] owner, int[] strength) {
        String[] p = line.trim().isEmpty() ? new String[0] : line.trim().split("\\s+");
        for (int i = 0; i + 2 < p.length; i += 3) {
            try {
                int x = Integer.parseInt(p[i]), y = Integer.parseInt(p[i+1]), d = Integer.parseInt(p[i+2]);
                if (x < 0 || y < 0 || x >= w || y >= h || owner[y*w+x] != id) continue;
                int nx=x, ny=y;
                if (d == 1) ny = (y - 1 + h) % h; else if (d == 2) nx = (x + 1) % w;
                else if (d == 3) ny = (y + 1) % h; else if (d == 4) nx = (x - 1 + w) % w; else continue;
                int from = y*w+x, to = ny*w+nx;
                if (owner[to] == id) strength[to] = Math.min(255, strength[to] + strength[from]);
                else if (strength[from] > strength[to]) { owner[to] = id; strength[to] = strength[from] - strength[to]; }
                strength[from] = 0;
            } catch (NumberFormatException ignored) {}
        }
    }

    static int totalStrength(int id, int[] owner, int[] strength) {
        int s = 0; for (int i = 0; i < owner.length; i++) if (owner[i] == id) s += strength[i]; return s;
    }

    static String writeReplay(Opt opt, List<Bot> bots, int turns) {
        try {
            Path dir = Paths.get(opt.replayDir);
            Files.createDirectories(dir);
            String name = opt.seed + "-" + Math.abs(Objects.hash(opt.width, opt.height, bots.size())) + ".hlt";
            Path p = dir.resolve(name);
            StringBuilder sb = new StringBuilder();
            sb.append("{\"width\":").append(opt.width).append(",\"height\":").append(opt.height)
              .append(",\"num_players\":").append(bots.size()).append(",\"num_frames\":").append(turns).append("}\n");
            Files.writeString(p, sb.toString(), StandardCharsets.UTF_8);
            return opt.replayDir.equals(".") ? name : p.toString();
        } catch (IOException e) {
            return "";
        }
    }

    static class ParseException extends Exception {
        final String arg, value;
        ParseException(String arg, String value) { this.arg = arg; this.value = value; }
    }
}
