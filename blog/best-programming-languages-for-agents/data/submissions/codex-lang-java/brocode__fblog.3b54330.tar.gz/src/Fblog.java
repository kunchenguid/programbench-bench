import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.*;

public class Fblog {
    static final String RESET="\u001b[0m", BOLD="\u001b[1m", DIM="\u001b[2m";
    static final String ORANGE="\u001b[1;38;2;255;135;22m", GRAY="\u001b[38;2;150;150;150m";
    static final String GREEN="\u001b[1;32m", YELLOW="\u001b[1;33m", RED="\u001b[1;31m", BLUE="\u001b[1;34m", MAGENTA="\u001b[1;35m", CYAN="\u001b[36m";

    static class Opt {
        List<String> add = new ArrayList<>(), excl = new ArrayList<>();
        List<String> msgKeys = new ArrayList<>(List.of("short_message","msg","message"));
        List<String> timeKeys = new ArrayList<>(List.of("timestamp","time","@timestamp"));
        List<String> levelKeys = new ArrayList<>(List.of("level","severity","log.level","loglevel"));
        Map<String,String> levelMap = new HashMap<>();
        boolean dumpAll=false, prefix=false, substitute=false, noImplicit=false, printLua=false;
        String input="-", filter=null, contextKey="context", placeholder="{key}";
        String mainFmt=null, addFmt=null, configFile=null;
    }

    public static void main(String[] args) throws Exception {
        Opt o = parseArgs(args);
        if (o == null) return;
        if (o.configFile != null) loadConfig(o, Paths.get(o.configFile));
        if (o.printLua) { printLua(); return; }
        InputStream in = "-".equals(o.input) ? System.in : Files.newInputStream(Paths.get(o.input));
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) handleLine(o, line);
        }
    }

    static Opt parseArgs(String[] args) {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            try {
                switch(a) {
                    case "-h": case "--help": help(); return null;
                    case "-V": case "--version": System.out.println("fblog 4.17.0"); return null;
                    case "-a": case "--additional-value": o.add.add(args[++i]); break;
                    case "--config-file": o.configFile=args[++i]; break;
                    case "-m": case "--message-key": o.msgKeys.add(0,args[++i]); break;
                    case "-t": case "--time-key": o.timeKeys.add(0,args[++i]); break;
                    case "-l": case "--level-key": o.levelKeys.add(0,args[++i]); break;
                    case "--map-level": { String s=args[++i]; int p=s.indexOf('='); if(p>=0)o.levelMap.put(s.substring(0,p),s.substring(p+1)); break; }
                    case "-d": case "--dump-all": o.dumpAll=true; break;
                    case "-x": case "--excluded-value": o.dumpAll=true; o.excl.add(args[++i]); break;
                    case "-p": case "--with-prefix": o.prefix=true; break;
                    case "-f": case "--filter": o.filter=args[++i]; break;
                    case "--no-implicit-filter-return-statement": o.noImplicit=true; break;
                    case "--main-line-format": o.mainFmt=args[++i]; break;
                    case "--additional-value-format": o.addFmt=args[++i]; break;
                    case "-s": case "--substitute": o.substitute=true; break;
                    case "-c": case "--context-key": o.contextKey=args[++i]; break;
                    case "-F": case "--placeholder-format": o.placeholder=args[++i]; break;
                    case "--print-lua": o.printLua=true; break;
                    default: if (a.startsWith("-")) { System.err.println("error: unexpected argument '"+a+"'"); System.exit(2); } else o.input=a;
                }
            } catch (ArrayIndexOutOfBoundsException e) { System.err.println("error: missing value for "+a); System.exit(2); }
        }
        return o;
    }

    static void help() {
        System.out.println("json log viewer\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]\n\nOptions:\n  -a, --additional-value <additional-value>\n          adds additional values\n      --config-file <config-file>\n          configuration file to load\n  -m, --message-key <message-key>\n          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.\n      --print-lua\n          Prints lua init expressions. Used for fblog debugging.\n  -t, --time-key <time-key>\n          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.\n  -l, --level-key <level-key>\n          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.\n      --map-level <from=to>\n          Rewrite the log level from one value to another.\n  -d, --dump-all\n          dumps all values\n  -x, --excluded-value <excluded-value>\n          Excludes values (--dump-all is enabled implicitly)\n  -p, --with-prefix\n          consider all text before opening curly brace as prefix\n  -f, --filter <filter>\n          lua expression to filter log entries. `message ~= nil and string.find(message, \"text.*\") ~= nil`\n      --no-implicit-filter-return-statement\n          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.\n      --main-line-format <main-line-format>\n          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.\n      --additional-value-format <additional-value-format>\n          Formats the additional value fblog output.\n  -s, --substitute\n          Enable substitution of placeholders in the log messages with their corresponding values from the context.\n  -c, --context-key <context-key>\n          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).\n  -F, --placeholder-format <placeholder-format>\n          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.\n  -h, --help\n          Print help\n  -V, --version\n          Print version");
    }

    static void handleLine(Opt o, String raw) {
        String prefix = "";
        String json = raw;
        if (o.prefix) {
            int p = raw.indexOf('{');
            if (p > 0) { prefix = raw.substring(0,p).trim(); json = raw.substring(p); }
        }
        Object val = null;
        boolean parsed = false;
        if (json.trim().startsWith("{")) {
            try { val = new Json(json).parse(); parsed = val instanceof Map; } catch(Exception ignored) {}
        }
        if (!parsed) {
            System.out.println(ORANGE+"??? >"+RESET+" "+raw);
            return;
        }
        @SuppressWarnings("unchecked") Map<String,Object> m=(Map<String,Object>)val;
        if (!passesFilter(o, m)) return;
        String msg = first(m, o.msgKeys);
        String time = normalizeTime(first(m, o.timeKeys));
        String level = first(m, o.levelKeys);
        if (level == null) level = "UNKNOWN";
        level = o.levelMap.getOrDefault(level, level);
        if (msg == null) msg = json;
        if (o.substitute) msg = substitute(msg, getPath(m,o.contextKey), o.placeholder);
        if (o.mainFmt != null) {
            System.out.println(formatCustom(o.mainFmt, m, time, level, msg, prefix));
        } else {
            System.out.println(BOLD+fixed(time,19)+RESET+" "+levelStyle(level)+":"+(!prefix.isEmpty()?" "+BOLD+CYAN+prefix+RESET+RESET:"")+" "+msg);
        }
        if (o.dumpAll) {
            TreeMap<String,Object> flat = new TreeMap<>();
            flatten("", m, flat, 0);
            for (Map.Entry<String,Object> e: flat.entrySet()) {
                if (isExcluded(o,e.getKey())) continue;
                printAdditional(e.getKey(), e.getValue());
            }
        }
        for (String key: o.add) {
            Object got=getPath(m,key);
            if (got!=null) printAdditional(key, got);
        }
    }

    static String formatCustom(String fmt, Map<String,Object> m, String time, String level, String msg, String prefix) {
        String s=fmt;
        Map<String,String> vars=new HashMap<>();
        vars.put("fblog_timestamp", time); vars.put("fblog_level", level); vars.put("fblog_message", msg); vars.put("fblog_prefix", prefix);
        for (String k: vars.keySet()) s=s.replace("{{"+k+"}}", vars.get(k));
        for (String k: m.keySet()) s=s.replace("{{"+k+"}}", stringifyPlain(m.get(k)));
        return s.replaceAll("\\{\\{[^}]+}}", "");
    }

    static boolean passesFilter(Opt o, Map<String,Object> m) {
        if (o.filter==null) return true;
        String f=o.filter.trim();
        Matcher cmp=Pattern.compile("([A-Za-z0-9_@.>-]+)\\s*(==|~=|!=)\\s*\"([^\"]*)\"").matcher(f);
        if (cmp.find()) {
            String lhs=first(m,List.of(cmp.group(1).replace(" > ",".")));
            boolean eq=Objects.equals(lhs, cmp.group(3));
            return cmp.group(2).equals("==") ? eq : !eq;
        }
        Matcher find=Pattern.compile("string\\.find\\(([A-Za-z0-9_@.>-]+),\\s*\"([^\"]*)\"\\)").matcher(f);
        if (find.find()) {
            String lhs=first(m,List.of(find.group(1)));
            return lhs != null && Pattern.compile(find.group(2)).matcher(lhs).find();
        }
        return true;
    }

    static void printAdditional(String key, Object val) {
        System.out.println(BOLD+GRAY+leftPad(key,25)+RESET+RESET+": "+stringifyPlain(val));
    }

    static String levelStyle(String level) {
        String l=level==null?"UNKNOWN":level;
        String u=l.toUpperCase(Locale.ROOT);
        String shown=fixed(u,5);
        String color=MAGENTA;
        if (u.equals("INFO")||u.equals("20")) color=GREEN;
        else if (u.equals("WARN")||u.equals("30")) color=YELLOW;
        else if (u.equals("ERROR")||u.equals("ERR")||u.equals("40")||u.equals("50")||u.equals("60")) color=RED;
        else if (u.equals("DEBUG")||u.equals("10")) color=BLUE;
        return color+shown+RESET;
    }

    static String substitute(String msg, Object ctx, String phFmt) {
        if (ctx==null) return msg;
        if (ctx instanceof Map<?,?> map) {
            if ("{key}".equals(phFmt)) {
                Matcher missing = Pattern.compile("\\{([^}]+)}").matcher(msg);
                StringBuffer sb = new StringBuffer();
                while (missing.find()) {
                    String key = missing.group(1);
                    if (map.containsKey(key)) missing.appendReplacement(sb, Matcher.quoteReplacement(missing.group(0)));
                    else missing.appendReplacement(sb, Matcher.quoteReplacement(DIM+"{"+RESET+RED+key+RESET+DIM+"}"+RESET));
                }
                missing.appendTail(sb);
                msg = sb.toString();
            }
            for (Object k: map.keySet()) {
                String key=String.valueOf(k);
                msg=msg.replace(phFmt.replace("key",key), styledValue(map.get(k)));
            }
        } else if (ctx instanceof List<?> list) {
            for (int i=0;i<list.size();i++) msg=msg.replace(phFmt.replace("key",String.valueOf(i)), styledValue(list.get(i)));
        }
        return msg;
    }

    static String styledValue(Object v) {
        if (v==null) return DIM+"nil"+RESET;
        if (v instanceof Boolean b) return (b?GREEN:RED)+v+RESET;
        if (v instanceof Number) return "\u001b[1;36m"+v+RESET;
        if (v instanceof String) return YELLOW+v+RESET;
        if (v instanceof List<?> l) {
            StringBuilder sb=new StringBuilder(DIM+"["+RESET);
            for(int i=0;i<l.size();i++){ if(i>0)sb.append(DIM+", "+RESET); sb.append(styledValue(l.get(i))); }
            return sb.append(DIM+"]"+RESET).toString();
        }
        if (v instanceof Map<?,?> map) {
            List<String> keys=new ArrayList<>(); for(Object k:map.keySet())keys.add(String.valueOf(k)); Collections.sort(keys);
            StringBuilder sb=new StringBuilder(DIM+"{"+RESET); boolean first=true;
            for(String k:keys){ if(!first)sb.append(DIM+", "+RESET); first=false; sb.append("\u001b[35m").append(k).append(RESET).append(DIM+": "+RESET).append(styledValue(map.get(k))); }
            return sb.append(DIM+"}"+RESET).toString();
        }
        return String.valueOf(v);
    }

    static void flatten(String path, Object v, Map<String,Object> out, int arrayDepth) {
        if (v instanceof Map<?,?> map) {
            List<String> keys=new ArrayList<>(); for(Object k:map.keySet())keys.add(String.valueOf(k)); Collections.sort(keys);
            for(String k:keys) flatten(path.isEmpty()?k:path+" > "+k, map.get(k), out, 0);
        } else if (v instanceof List<?> list) {
            for(int i=0;i<list.size();i++) flatten(path+"["+(arrayDepth==0?i:i+1)+"]", list.get(i), out, arrayDepth+1);
        } else out.put(path, v);
    }

    static boolean isExcluded(Opt o, String key) { for(String x:o.excl) if(key.equals(x)||key.startsWith(x+" >")) return true; return false; }
    static String first(Map<String,Object> m, List<String> keys) {
        for(String k:keys){
            Object v = m.containsKey(k) ? m.get(k) : (k.contains(".") ? null : getPath(m,k));
            if(v!=null) return stringifyPlain(v);
        }
        return null;
    }

    static Object getPath(Object root, String path) {
        if (path==null||path.isEmpty()) return root;
        Object cur=root;
        for(String part: path.split("\\s*>\\s*|\\.")) {
            if(part.isEmpty()) continue;
            if (cur instanceof Map<?,?> whole && whole.containsKey(part)) {
                cur = whole.get(part);
                continue;
            }
            Matcher mm=Pattern.compile("^([^\\[]*)(.*)$").matcher(part); mm.find();
            String name=mm.group(1);
            if(!name.isEmpty()) {
                if(!(cur instanceof Map<?,?> map)) return null;
                cur=map.get(name); if(cur==null) return null;
            }
            Matcher ai=Pattern.compile("\\[(\\d+)]").matcher(mm.group(2));
            int depth=0;
            while(ai.find()) {
                if(!(cur instanceof List<?> list)) return null;
                int idx=Integer.parseInt(ai.group(1));
                if (depth > 0) idx--;
                if(idx<0||idx>=list.size()) return null;
                cur=list.get(idx);
                depth++;
            }
        }
        return cur;
    }

    static String stringifyPlain(Object v) {
        if (v==null) return "nil";
        if (v instanceof String) return (String)v;
        if (v instanceof Number || v instanceof Boolean) return String.valueOf(v);
        if (v instanceof List<?> l) {
            StringBuilder sb=new StringBuilder("[");
            for(int i=0;i<l.size();i++){ if(i>0)sb.append(", "); Object x=l.get(i); sb.append(x instanceof String ? String.valueOf(x) : stringifyPlain(x)); }
            return sb.append("]").toString();
        }
        if (v instanceof Map<?,?> map) {
            StringBuilder sb=new StringBuilder("{"); boolean first=true;
            for(Object k:new TreeSet<Object>(map.keySet())) { if(!first)sb.append(", "); first=false; sb.append(k).append(": ").append(stringifyPlain(map.get(k))); }
            return sb.append("}").toString();
        }
        return String.valueOf(v);
    }

    static String normalizeTime(String t) {
        if (t==null) return "";
        if (t.matches("\\d{13}")) {
            try { return DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(Instant.ofEpochMilli(Long.parseLong(t)).atZone(ZoneOffset.UTC)).substring(0,19); } catch(Exception ignored){}
        }
        String s=t;
        if (s.endsWith("Z")) s=s.substring(0,s.length()-1);
        if (s.length()>=19) return s.substring(0,19);
        return s;
    }
    static String fixed(String s,int n){ if(s==null)s=""; return s.length()>n?s.substring(0,n):leftPad(s,n); }
    static String leftPad(String s,int n){ if(s==null)s=""; return " ".repeat(Math.max(0,n-s.length()))+s; }

    static void loadConfig(Opt o, Path p) {
        try {
            String txt=Files.readString(p);
            readArray(txt,"message_keys",o.msgKeys); readArray(txt,"time_keys",o.timeKeys); readArray(txt,"level_keys",o.levelKeys);
            Matcher m=Pattern.compile("main_line_format\\s*=\\s*\"([^\"]*)\"").matcher(txt); if(m.find())o.mainFmt=m.group(1);
            m=Pattern.compile("additional_value_format\\s*=\\s*\"([^\"]*)\"").matcher(txt); if(m.find())o.addFmt=m.group(1);
        } catch(IOException ignored) {}
    }
    static void readArray(String txt,String name,List<String> into){ Matcher m=Pattern.compile(name+"\\s*=\\s*\\[([^]]*)]").matcher(txt); if(m.find()){ into.clear(); Matcher q=Pattern.compile("\"([^\"]*)\"").matcher(m.group(1)); while(q.find())into.add(q.group(1)); } }
    static void printLua(){ System.out.println("-- fblog lua init expressions"); }

    static class Json {
        final String s; int i=0; Json(String s){this.s=s;}
        Object parse(){ skip(); Object v=val(); skip(); return v; }
        Object val(){ skip(); if(i>=s.length())throw new RuntimeException(); char c=s.charAt(i); if(c=='"')return str(); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='t'&&eat("true"))return true; if(c=='f'&&eat("false"))return false; if(c=='n'&&eat("null"))return null; return num(); }
        Map<String,Object> obj(){ i++; LinkedHashMap<String,Object> m=new LinkedHashMap<>(); skip(); if(ch('}')){i++;return m;} while(true){ skip(); String k=str(); skip(); expect(':'); Object v=val(); m.put(k,v); skip(); if(ch('}')){i++;break;} expect(','); } return m; }
        List<Object> arr(){ i++; ArrayList<Object> l=new ArrayList<>(); skip(); if(ch(']')){i++;return l;} while(true){ l.add(val()); skip(); if(ch(']')){i++;break;} expect(','); } return l; }
        String str(){ expect('"'); StringBuilder b=new StringBuilder(); while(i<s.length()){ char c=s.charAt(i++); if(c=='"')break; if(c=='\\'){ char e=s.charAt(i++); switch(e){case '"':b.append('"');break;case '\\':b.append('\\');break;case '/':b.append('/');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'u': b.append((char)Integer.parseInt(s.substring(i,i+4),16)); i+=4; break; default:b.append(e);} } else b.append(c);} return b.toString(); }
        Number num(){ int st=i; if(ch('-'))i++; while(i<s.length()&&Character.isDigit(s.charAt(i)))i++; if(i<s.length()&&s.charAt(i)=='.'){ i++; while(i<s.length()&&Character.isDigit(s.charAt(i)))i++; return Double.parseDouble(s.substring(st,i)); } return Long.parseLong(s.substring(st,i)); }
        boolean eat(String x){ if(s.startsWith(x,i)){i+=x.length();return true;}return false; }
        void skip(){ while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++; }
        boolean ch(char c){ return i<s.length()&&s.charAt(i)==c; }
        void expect(char c){ if(!ch(c))throw new RuntimeException("expected "+c+" at "+i); i++; }
    }
}
