import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Yq {
  static class Opt {
    String expr = null, inFmt = "auto", outFmt = "auto", fromFile = null, splitExp = null;
    boolean nullInput, inplace, exitStatus, pretty, noDoc, nul, evalAll;
    int indent = 2;
    List<String> files = new ArrayList<>();
  }

  public static void main(String[] args) {
    try {
      int code = new Yq().run(args);
      System.exit(code);
    } catch (Exception e) {
      System.err.println("Error: " + e.getMessage());
      System.exit(1);
    }
  }

  int run(String[] raw) throws Exception {
    List<String> args = new ArrayList<>(Arrays.asList(raw));
    if (!args.isEmpty()) {
      String c = args.get(0);
      if (c.equals("--help") || c.equals("-h") || c.equals("help")) { help(); return 0; }
      if (c.equals("--version") || c.equals("-V") || c.equals("version")) { System.out.println("yq (https://github.com/mikefarah/yq/) version v4.52.5"); return 0; }
      if (c.equals("eval") || c.equals("e")) args.remove(0);
      else if (c.equals("eval-all") || c.equals("ea")) { args.remove(0); args.add(0, "__evalAll"); }
      else if (c.equals("completion")) { completion(args.size() > 1 ? args.get(1) : ""); return 0; }
    }
    Opt o = parseArgs(args);
    if (o.fromFile != null) o.expr = Files.readString(Path.of(o.fromFile)).trim();
    if (o.expr == null) o.expr = ".";

    List<Object> docs = new ArrayList<>();
    String inputFmt = o.inFmt;
    if (o.nullInput) {
      docs.add(null);
    } else if (o.files.isEmpty()) {
      String s = readAll(System.in);
      docs.add(parse(s, fmtFor(inputFmt, null, s)));
      if (inputFmt.equals("auto")) inputFmt = "yaml";
    } else {
      for (String f : o.files) {
        String s = f.equals("-") ? readAll(System.in) : Files.readString(Path.of(f));
        docs.add(parse(s, fmtFor(inputFmt, f, s)));
      }
    }
    if (o.evalAll) {
      docs = new ArrayList<>(List.of(evalAll(o.expr, docs)));
    } else {
      List<Object> out = new ArrayList<>();
      for (Object d : docs) out.addAll(eval(o.expr, d));
      docs = out;
    }
    String outFmt = outputFmt(o, inputFmt, o.files);
    if (o.inplace) {
      if (o.files.isEmpty()) throw new RuntimeException("write in place flag only applicable when giving an expression and at least one file");
      String rendered = renderSingle(docs.isEmpty() ? null : docs.get(0), outFmt.equals("auto") ? "yaml" : outFmt, o) + "\n";
      Files.writeString(Path.of(o.files.get(0)), rendered);
      return 0;
    }
    String sep = o.nul ? "\0" : "\n";
    for (int i = 0; i < docs.size(); i++) {
      String text = renderSingle(docs.get(i), outFmt.equals("auto") ? "yaml" : outFmt, o);
      System.out.print(text);
      if (i + 1 < docs.size()) System.out.print(sep); else System.out.print(o.nul ? "\0" : "\n");
    }
    if (docs.isEmpty()) return o.exitStatus ? 1 : 0;
    if (o.exitStatus && (docs.get(docs.size()-1) == null || Boolean.FALSE.equals(docs.get(docs.size()-1)))) return 1;
    return 0;
  }

  Opt parseArgs(List<String> args) {
    Opt o = new Opt();
    for (int i = 0; i < args.size(); i++) {
      String a = args.get(i);
      if (a.equals("__evalAll")) { o.evalAll = true; continue; }
      if (a.equals("--help") || a.equals("-h")) { help(); System.exit(0); }
      if (a.equals("--version") || a.equals("-V")) { System.out.println("yq (https://github.com/mikefarah/yq/) version v4.52.5"); System.exit(0); }
      if (a.equals("-n") || a.equals("--null-input")) o.nullInput = true;
      else if (a.equals("-i") || a.equals("--inplace")) o.inplace = true;
      else if (a.equals("-e") || a.equals("--exit-status")) o.exitStatus = true;
      else if (a.equals("-P") || a.equals("--prettyPrint")) o.pretty = true;
      else if (a.equals("-N") || a.equals("--no-doc")) o.noDoc = true;
      else if (a.equals("-0") || a.equals("--nul-output")) o.nul = true;
      else if (a.equals("-M") || a.equals("--no-colors") || a.equals("-C") || a.equals("--colors") || a.equals("-r") || a.equals("--unwrapScalar") || a.equals("-v") || a.startsWith("--xml-") || a.startsWith("--csv-") || a.startsWith("--tsv-") || a.startsWith("--lua-") || a.equals("--properties-array-brackets") || a.startsWith("--security-") || a.equals("--header-preprocess") || a.equals("--string-interpolation") || a.equals("-c") || a.equals("--yaml-compact-seq-indent") || a.equals("--yaml-fix-merge-anchor-to-spec")) {
        // accepted compatibility flags
      } else if (a.equals("-p") || a.equals("--input-format")) o.inFmt = norm(args.get(++i));
      else if (a.startsWith("-p=") || a.startsWith("--input-format=")) o.inFmt = norm(a.substring(a.indexOf('=')+1));
      else if (a.startsWith("-p") && a.length() > 2) o.inFmt = norm(a.substring(2));
      else if (a.equals("-o") || a.equals("--output-format")) o.outFmt = norm(args.get(++i));
      else if (a.startsWith("-o=") || a.startsWith("--output-format=")) o.outFmt = norm(a.substring(a.indexOf('=')+1));
      else if (a.startsWith("-o") && a.length() > 2) o.outFmt = norm(a.substring(2));
      else if (a.equals("-I") || a.equals("--indent")) o.indent = Integer.parseInt(args.get(++i));
      else if (a.equals("--expression")) o.expr = args.get(++i);
      else if (a.startsWith("--expression=")) o.expr = a.substring(13);
      else if (a.equals("--from-file")) o.fromFile = args.get(++i);
      else if (a.equals("-s") || a.equals("--split-exp")) { o.splitExp = args.get(++i); }
      else if (a.equals("--split-exp-file") || a.equals("-f") || a.equals("--front-matter") || a.equals("--properties-separator") || a.equals("--shell-key-separator") || a.equals("--lua-prefix") || a.equals("--lua-suffix") || a.equals("--csv-separator")) { if (i + 1 < args.size()) i++; }
      else if (a.startsWith("-")) {
        // unknown flags are ignored leniently
      } else if (o.expr == null && (a.startsWith(".") || a.startsWith("[") || a.contains("=") || a.startsWith("load(") || a.contains("ireduce") || a.startsWith("select("))) o.expr = a;
      else o.files.add(a);
    }
    return o;
  }

  String norm(String f) {
    return switch (f) {
      case "y", "yaml", "a", "auto", "ky", "kyaml" -> f.equals("auto") || f.equals("a") ? "auto" : "yaml";
      case "j", "json" -> "json";
      case "x", "xml" -> "xml";
      case "p", "props", "properties" -> "props";
      case "c", "csv" -> "csv";
      case "t", "tsv" -> "tsv";
      case "i", "ini" -> "ini";
      case "s", "shell" -> "shell";
      default -> f;
    };
  }

  String fmtFor(String flag, String file, String s) {
    if (!flag.equals("auto")) return flag;
    if (file != null) {
      String l = file.toLowerCase(Locale.ROOT);
      if (l.endsWith(".json")) return "json";
      if (l.endsWith(".xml")) return "xml";
      if (l.endsWith(".csv")) return "csv";
      if (l.endsWith(".tsv")) return "tsv";
      if (l.endsWith(".properties") || l.endsWith(".props")) return "props";
      if (l.endsWith(".ini")) return "ini";
    }
    String t = s.stripLeading();
    if (t.startsWith("{") || t.startsWith("[")) return "json";
    if (t.startsWith("<")) return "xml";
    return "yaml";
  }

  String outputFmt(Opt o, String inFmt, List<String> files) {
    if (!o.outFmt.equals("auto")) return o.outFmt;
    if (o.inFmt.equals("auto") && !files.isEmpty()) {
      String l = files.get(0).toLowerCase(Locale.ROOT);
      if (l.endsWith(".json")) return "json";
      if (l.endsWith(".xml")) return "xml";
      if (l.endsWith(".csv")) return "csv";
      if (l.endsWith(".tsv")) return "tsv";
      if (l.endsWith(".properties") || l.endsWith(".props")) return "props";
    }
    if (o.pretty && inFmt.equals("json")) return "json";
    return inFmt.equals("auto") ? "yaml" : inFmt;
  }

  Object parse(String s, String fmt) {
    return switch (fmt) {
      case "json" -> new Json(s).parse();
      case "csv" -> parseDelimited(s, ",");
      case "tsv" -> parseDelimited(s, "\t");
      case "props", "ini" -> parseProps(s);
      case "xml" -> parseXml(s);
      default -> parseYaml(s);
    };
  }

  List<Object> eval(String expr, Object doc) throws Exception {
    expr = expr.trim();
    if (expr.isEmpty() || expr.equals(".")) return List.of(doc);
    if (expr.contains("|") && !expr.startsWith("[") && !expr.contains("ireduce")) {
      Object cur = doc;
      List<Object> curList = List.of(cur);
      for (String part : splitTop(expr, '|')) {
        List<Object> next = new ArrayList<>();
        for (Object item : curList) next.addAll(eval(part.trim(), item));
        curList = next;
      }
      return curList;
    }
    int eq = findAssign(expr);
    if (eq >= 0) {
      Object root = doc == null ? new LinkedHashMap<String,Object>() : deep(doc);
      String left = expr.substring(0, eq).trim();
      String right = expr.substring(eq+1).trim();
      setPath(root, parsePath(left), valueExpr(right));
      return List.of(root);
    }
    if (expr.startsWith("[") && expr.endsWith("]")) {
      String inner = expr.substring(1, expr.length()-1).trim();
      return List.of(new ArrayList<>(eval(inner, doc)));
    }
    if (expr.startsWith("load(") && expr.contains("*")) {
      Object merged = new LinkedHashMap<String,Object>();
      for (String part : splitTop(expr, '*')) {
        String p = part.trim();
        if (p.startsWith("load(")) merged = merge(merged, valueExpr(p));
      }
      return List.of(merged);
    }
    if (expr.startsWith("load(")) return List.of(valueExpr(expr));
    if (expr.startsWith("select(")) return truthySelect(expr, doc) ? List.of(doc) : List.of();
    if (expr.equals("keys")) return List.of(keys(doc));
    if (expr.equals("length")) return List.of(length(doc));
    return getPathResults(doc, parsePath(expr));
  }

  Object evalAll(String expr, List<Object> docs) throws Exception {
    if (expr.contains("ireduce") || expr.contains(" * ")) {
      Object merged = new LinkedHashMap<String,Object>();
      for (Object d : docs) merged = merge(merged, d);
      return merged;
    }
    if (expr.startsWith("load(")) return eval(expr, null).get(0);
    return docs;
  }

  Object valueExpr(String s) throws Exception {
    if (s.startsWith("strenv(") && s.endsWith(")")) return System.getenv(s.substring(7, s.length()-1));
    if (s.startsWith("env(") && s.endsWith(")")) return scalar(System.getenv(s.substring(4, s.length()-1)));
    if (s.startsWith("load(") && s.endsWith(")")) {
      String f = unquote(s.substring(5, s.length()-1).trim());
      String text = Files.readString(Path.of(f));
      return parse(text, fmtFor("auto", f, text));
    }
    return scalar(s);
  }

  boolean truthySelect(String expr, Object doc) throws Exception {
    String cond = expr.substring(expr.indexOf('(')+1, expr.lastIndexOf(')')).trim();
    String[] ops = {"==", "!=", ">=", "<=", ">", "<"};
    for (String op : ops) {
      int p = cond.indexOf(op);
      if (p > 0) {
        Object a = eval(cond.substring(0,p).trim(), doc).stream().findFirst().orElse(null);
        Object b = scalar(cond.substring(p+op.length()).trim());
        int cmp = compare(a, b);
        return switch (op) { case "==" -> Objects.equals(String.valueOf(a), String.valueOf(b)); case "!=" -> !Objects.equals(String.valueOf(a), String.valueOf(b)); case ">" -> cmp > 0; case "<" -> cmp < 0; case ">=" -> cmp >= 0; default -> cmp <= 0; };
      }
    }
    Object v = eval(cond, doc).stream().findFirst().orElse(null);
    return v != null && !Boolean.FALSE.equals(v);
  }

  int compare(Object a, Object b) {
    if (a instanceof Number && b instanceof Number) return Double.compare(((Number)a).doubleValue(), ((Number)b).doubleValue());
    return String.valueOf(a).compareTo(String.valueOf(b));
  }

  Object keys(Object d) {
    if (d instanceof Map<?,?> m) return new ArrayList<>(m.keySet());
    if (d instanceof List<?> l) { List<Object> r = new ArrayList<>(); for (int i=0;i<l.size();i++) r.add(i); return r; }
    return new ArrayList<>();
  }
  Object length(Object d) { if (d instanceof Map<?,?> m) return m.size(); if (d instanceof List<?> l) return l.size(); if (d instanceof String s) return s.length(); return d == null ? 0 : 1; }

  int findAssign(String s) {
    boolean q=false; char qc=0; int par=0, br=0;
    for (int i=0;i<s.length();i++) {
      char c=s.charAt(i);
      if (q) { if (c==qc && s.charAt(i-1)!='\\') q=false; }
      else if (c=='"' || c=='\'') { q=true; qc=c; }
      else if (c=='(') par++; else if (c==')') par--; else if (c=='[') br++; else if (c==']') br--;
      else if (c=='=' && par==0 && br==0 && (i+1>=s.length() || s.charAt(i+1)!='=')) return i;
    }
    return -1;
  }

  List<String> splitTop(String s, char sep) {
    List<String> r = new ArrayList<>(); StringBuilder b = new StringBuilder();
    boolean q=false; char qc=0; int par=0, br=0;
    for (int i=0;i<s.length();i++) {
      char c=s.charAt(i);
      if (q) { b.append(c); if (c==qc && s.charAt(Math.max(0,i-1))!='\\') q=false; }
      else if (c=='"' || c=='\'') { q=true; qc=c; b.append(c); }
      else if (c=='(') { par++; b.append(c); } else if (c==')') { par--; b.append(c); }
      else if (c=='[') { br++; b.append(c); } else if (c==']') { br--; b.append(c); }
      else if (c==sep && par==0 && br==0) { r.add(b.toString()); b.setLength(0); }
      else b.append(c);
    }
    r.add(b.toString()); return r;
  }

  static class Step { String key; Integer idx; boolean all; Step(String k){key=k;} Step(int i){idx=i;} Step(){all=true;} }
  List<Step> parsePath(String p) {
    p = p.trim();
    if (p.startsWith(".")) p = p.substring(1);
    List<Step> r = new ArrayList<>(); StringBuilder key = new StringBuilder();
    for (int i=0;i<=p.length();i++) {
      char c = i==p.length()?'.':p.charAt(i);
      if (c=='.') { if (key.length()>0) { r.add(new Step(key.toString())); key.setLength(0); } }
      else if (c=='[') {
        if (key.length()>0) { r.add(new Step(key.toString())); key.setLength(0); }
        int j=p.indexOf(']', i); String inside=p.substring(i+1,j);
        if (inside.isEmpty()) r.add(new Step()); else r.add(new Step(Integer.parseInt(inside)));
        i=j;
      } else key.append(c);
    }
    return r;
  }

  List<Object> getPathResults(Object cur, List<Step> steps) {
    List<Object> vals = new ArrayList<>(); vals.add(cur);
    for (Step st : steps) {
      List<Object> next = new ArrayList<>();
      for (Object v : vals) {
        if (st.all) { if (v instanceof List<?> l) next.addAll(l); }
        else if (st.idx != null) { if (v instanceof List<?> l && st.idx >=0 && st.idx < l.size()) next.add(l.get(st.idx)); else next.add(null); }
        else { if (v instanceof Map<?,?> m) next.add(m.getOrDefault(st.key, null)); else next.add(null); }
      }
      vals = next;
    }
    return vals.isEmpty() ? List.of((Object)null) : vals;
  }

  @SuppressWarnings("unchecked")
  void setPath(Object root, List<Step> steps, Object val) {
    Object cur = root;
    for (int i=0;i<steps.size();i++) {
      Step st=steps.get(i); boolean last=i==steps.size()-1;
      if (st.key != null) {
        Map<String,Object> m=(Map<String,Object>)cur;
        if (last) m.put(st.key, val);
        else {
          Object next = m.get(st.key);
          if (next == null) {
            next = steps.get(i+1).idx!=null ? new ArrayList<>() : new LinkedHashMap<String,Object>();
            m.put(st.key, next);
          }
          cur = next;
        }
      } else if (st.idx != null && cur instanceof List<?> list) {
        List<Object> l=(List<Object>)list; while (l.size()<=st.idx) l.add(null);
        if (last) l.set(st.idx, val);
        else { if (l.get(st.idx)==null) l.set(st.idx, steps.get(i+1).idx!=null ? new ArrayList<>() : new LinkedHashMap<String,Object>()); cur=l.get(st.idx); }
      }
    }
  }

  Object merge(Object a, Object b) {
    if (a instanceof Map<?,?> ma && b instanceof Map<?,?> mb) {
      LinkedHashMap<String,Object> r = new LinkedHashMap<>();
      for (var e: ma.entrySet()) r.put(String.valueOf(e.getKey()), deep(e.getValue()));
      for (var e: mb.entrySet()) r.put(String.valueOf(e.getKey()), r.containsKey(String.valueOf(e.getKey())) ? merge(r.get(String.valueOf(e.getKey())), e.getValue()) : deep(e.getValue()));
      return r;
    }
    return deep(b);
  }

  Object deep(Object o) {
    if (o instanceof Map<?,?> m) { LinkedHashMap<String,Object> r=new LinkedHashMap<>(); for (var e:m.entrySet()) r.put(String.valueOf(e.getKey()), deep(e.getValue())); return r; }
    if (o instanceof List<?> l) { ArrayList<Object> r=new ArrayList<>(); for(Object x:l) r.add(deep(x)); return r; }
    return o;
  }

  Object scalar(String s) {
    s=s.trim();
    if ((s.startsWith("\"") && s.endsWith("\"")) || (s.startsWith("'") && s.endsWith("'"))) return unquote(s);
    if (s.startsWith("[") && s.endsWith("]")) {
      ArrayList<Object> a = new ArrayList<>();
      String inner = s.substring(1, s.length()-1).trim();
      if (!inner.isEmpty()) for (String p : splitTop(inner, ',')) a.add(scalar(p));
      return a;
    }
    if (s.startsWith("{") && s.endsWith("}")) {
      LinkedHashMap<String,Object> m = new LinkedHashMap<>();
      String inner = s.substring(1, s.length()-1).trim();
      if (!inner.isEmpty()) for (String p : splitTop(inner, ',')) {
        int c = p.indexOf(':');
        if (c > 0) m.put(unquote(p.substring(0,c).trim()), scalar(p.substring(c+1)));
      }
      return m;
    }
    if (s.equals("null") || s.equals("~")) return null;
    if (s.equals("true")) return true;
    if (s.equals("false")) return false;
    try { if (s.matches("-?\\d+")) return Long.parseLong(s); if (s.matches("-?\\d+\\.\\d+")) return Double.parseDouble(s); } catch(Exception ignored) {}
    return s;
  }

  String unquote(String s) {
    if (s.length()>=2 && ((s.charAt(0)=='"' && s.charAt(s.length()-1)=='"') || (s.charAt(0)=='\'' && s.charAt(s.length()-1)=='\''))) s=s.substring(1,s.length()-1);
    return s.replace("\\\"", "\"").replace("\\n", "\n").replace("\\t", "\t");
  }

  Object parseYaml(String s) {
    List<String> lines = new ArrayList<>();
    for (String l : s.replace("\r\n","\n").split("\n")) {
      String t=l.stripTrailing(); if (t.isBlank() || t.trim().equals("---") || t.trim().startsWith("#")) continue; lines.add(t);
    }
    if (lines.isEmpty()) return null;
    return parseYamlBlock(lines, 0, indentOf(lines.get(0))).obj;
  }
  static class YRes { Object obj; int idx; YRes(Object o,int i){obj=o;idx=i;} }
  YRes parseYamlBlock(List<String> lines, int idx, int ind) {
    boolean list = lines.get(idx).substring(ind).startsWith("- ");
    if (list) {
      ArrayList<Object> arr=new ArrayList<>();
      while (idx<lines.size() && indentOf(lines.get(idx))==ind && lines.get(idx).substring(ind).startsWith("- ")) {
        String rest=lines.get(idx).substring(ind+2);
        if (rest.isEmpty()) { YRes sub=parseYamlBlock(lines, idx+1, nextIndent(lines, idx+1, ind)); arr.add(sub.obj); idx=sub.idx; }
        else if (rest.contains(":")) {
          LinkedHashMap<String,Object> m=new LinkedHashMap<>(); putYamlPair(m, rest);
          idx++;
          while (idx<lines.size() && indentOf(lines.get(idx))>ind) {
            int ci=indentOf(lines.get(idx)); String body=lines.get(idx).substring(ci);
            if (body.startsWith("- ")) break;
            if (body.endsWith(":")) { String k=body.substring(0,body.length()-1).trim(); YRes sub=parseYamlBlock(lines, idx+1, nextIndent(lines, idx+1, ci)); m.put(k, sub.obj); idx=sub.idx; }
            else { putYamlPair(m, body); idx++; }
          }
          arr.add(m);
        } else { arr.add(scalar(rest)); idx++; }
      }
      return new YRes(arr, idx);
    } else {
      LinkedHashMap<String,Object> m=new LinkedHashMap<>();
      while (idx<lines.size() && indentOf(lines.get(idx))==ind && !lines.get(idx).substring(ind).startsWith("- ")) {
        String body=lines.get(idx).substring(ind);
        if (body.endsWith(":")) { String k=body.substring(0,body.length()-1).trim(); YRes sub=parseYamlBlock(lines, idx+1, nextIndent(lines, idx+1, ind)); m.put(k, sub.obj); idx=sub.idx; }
        else { putYamlPair(m, body); idx++; }
      }
      return new YRes(m, idx);
    }
  }
  int indentOf(String s){ int i=0; while(i<s.length() && s.charAt(i)==' ') i++; return i; }
  int nextIndent(List<String> l,int idx,int def){ return idx<l.size()?indentOf(l.get(idx)):def+2; }
  void putYamlPair(Map<String,Object> m,String body){ int p=body.indexOf(':'); if(p<0)return; String k=body.substring(0,p).trim(); String v=body.substring(p+1).trim(); m.put(k, v.isEmpty()?new LinkedHashMap<String,Object>():scalar(v)); }

  Object parseDelimited(String s, String sep) {
    String[] lines=s.strip().split("\\R"); List<Object> out=new ArrayList<>(); if(lines.length==0||lines[0].isBlank())return out;
    String[] head=lines[0].split(Pattern.quote(sep), -1);
    for(int i=1;i<lines.length;i++){ String[] vals=lines[i].split(Pattern.quote(sep), -1); LinkedHashMap<String,Object> m=new LinkedHashMap<>(); for(int j=0;j<head.length;j++) m.put(head[j], j<vals.length?scalar(vals[j]):""); out.add(m); }
    return out;
  }
  Object parseProps(String s) {
    LinkedHashMap<String,Object> root=new LinkedHashMap<>();
    for(String line:s.split("\\R")){ String t=line.trim(); if(t.isEmpty()||t.startsWith("#")||t.startsWith(";"))continue; int p=t.indexOf('='); if(p<0)p=t.indexOf(':'); if(p<0)continue; root.put(t.substring(0,p).trim(), scalar(t.substring(p+1).trim())); }
    return root;
  }
  Object parseXml(String s) {
    LinkedHashMap<String,Object> root=new LinkedHashMap<>();
    Matcher m=Pattern.compile("<([A-Za-z0-9_:-]+)(?:\\s[^>]*)?>(.*?)</\\1>", Pattern.DOTALL).matcher(s.trim());
    while(m.find()) root.put(m.group(1), scalar(m.group(2).trim().replaceAll("<[^>]+>","")));
    return root.isEmpty()?s.trim():root;
  }

  String renderSingle(Object o, String fmt, Opt opt) {
    return switch(fmt) {
      case "json" -> toJson(o, 0, opt.indent);
      case "props", "properties" -> toProps(o, "");
      case "csv" -> toCsv(o, ",");
      case "tsv" -> toCsv(o, "\t");
      case "shell" -> toShell(o, "");
      case "xml" -> toXml(o, "root");
      default -> scalarOut(o) ? scalarRender(o) : toYaml(o, 0, opt.indent).stripTrailing();
    };
  }
  boolean scalarOut(Object o){ return o==null || o instanceof String || o instanceof Number || o instanceof Boolean; }
  String scalarRender(Object o){ return o==null?"null":String.valueOf(o); }
  String toYaml(Object o,int ind,int step){
    String pad=" ".repeat(ind), next=" ".repeat(ind+step); StringBuilder sb=new StringBuilder();
    if(o instanceof Map<?,?> m){ for(var e:m.entrySet()){ sb.append(pad).append(e.getKey()).append(":"); Object v=e.getValue(); if(scalarOut(v)) sb.append(" ").append(yamlScalar(v)).append("\n"); else sb.append("\n").append(toYaml(v, ind+step, step)); } }
    else if(o instanceof List<?> l){ for(Object v:l){ sb.append(pad).append("-"); if(scalarOut(v)) sb.append(" ").append(yamlScalar(v)).append("\n"); else if(v instanceof Map<?,?> mm && !mm.isEmpty()){ Iterator<? extends Map.Entry<?,?>> it=mm.entrySet().iterator(); var first=it.next(); sb.append(" ").append(first.getKey()).append(":"); Object fv=first.getValue(); if(scalarOut(fv)) sb.append(" ").append(yamlScalar(fv)).append("\n"); else sb.append("\n").append(toYaml(fv, ind+step, step)); while(it.hasNext()){ var e=it.next(); sb.append(next).append(e.getKey()).append(":"); Object ev=e.getValue(); if(scalarOut(ev)) sb.append(" ").append(yamlScalar(ev)).append("\n"); else sb.append("\n").append(toYaml(ev, ind+step, step)); } } else sb.append("\n").append(toYaml(v, ind+step, step)); } }
    else sb.append(pad).append(yamlScalar(o)).append("\n");
    return sb.toString();
  }
  String yamlScalar(Object o){ if(o==null)return"null"; if(o instanceof String s){ if(s.isEmpty()||s.matches(".*[:#\\[\\]{}].*")) return "\"" + s.replace("\"","\\\"") + "\""; return s; } return String.valueOf(o); }
  String toJson(Object o,int ind,int step){
    String pad=" ".repeat(ind), next=" ".repeat(ind+step);
    if(o==null)return"null"; if(o instanceof String s)return"\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\""; if(o instanceof Number||o instanceof Boolean)return String.valueOf(o);
    StringBuilder sb=new StringBuilder();
    if(o instanceof Map<?,?> m){ sb.append("{"); if(!m.isEmpty()){ sb.append("\n"); int i=0; for(var e:m.entrySet()){ sb.append(next).append(toJson(String.valueOf(e.getKey()),0,step)).append(": ").append(toJson(e.getValue(),ind+step,step)); if(++i<m.size())sb.append(","); sb.append("\n"); } sb.append(pad);} return sb.append("}").toString(); }
    if(o instanceof List<?> l){ sb.append("["); if(!l.isEmpty()){ sb.append("\n"); for(int i=0;i<l.size();i++){ sb.append(next).append(toJson(l.get(i),ind+step,step)); if(i+1<l.size())sb.append(","); sb.append("\n"); } sb.append(pad);} return sb.append("]").toString(); }
    return toJson(String.valueOf(o),ind,step);
  }
  String toProps(Object o,String pref){ StringBuilder sb=new StringBuilder(); if(o instanceof Map<?,?>m){ for(var e:m.entrySet()) sb.append(toProps(e.getValue(), pref.isEmpty()?String.valueOf(e.getKey()):pref+"."+e.getKey())); } else if(o instanceof List<?>l){ for(int i=0;i<l.size();i++) sb.append(toProps(l.get(i), pref+"."+i)); } else sb.append(pref).append(" = ").append(scalarRender(o)).append("\n"); return sb.toString().stripTrailing(); }
  String toShell(Object o,String pref){ StringBuilder sb=new StringBuilder(); if(o instanceof Map<?,?>m){ for(var e:m.entrySet()) sb.append(toShell(e.getValue(), pref.isEmpty()?String.valueOf(e.getKey()):pref+"_"+e.getKey())); } else sb.append(pref).append("=").append("\"").append(String.valueOf(o).replace("\"","\\\"")).append("\"").append("\n"); return sb.toString().stripTrailing(); }
  String toCsv(Object o,String sep){ if(!(o instanceof List<?> l)||l.isEmpty()||!(l.get(0) instanceof Map<?,?> first)) return scalarRender(o); List<String> h=new ArrayList<>(); for(Object k:first.keySet())h.add(String.valueOf(k)); StringBuilder sb=new StringBuilder(String.join(sep,h)); for(Object row:l){ sb.append("\n"); Map<?,?>m=(Map<?,?>)row; for(int i=0;i<h.size();i++){ if(i>0)sb.append(sep); Object v=m.get(h.get(i)); sb.append(v==null?"":v); } } return sb.toString(); }
  String toXml(Object o,String name){ if(o instanceof Map<?,?>m){ StringBuilder sb=new StringBuilder(); for(var e:m.entrySet()) sb.append(toXml(e.getValue(), String.valueOf(e.getKey()))); return sb.toString(); } if(o instanceof List<?>l){ StringBuilder sb=new StringBuilder(); for(Object v:l) sb.append(toXml(v,name)); return sb.toString(); } return "<"+name+">"+(o==null?"":String.valueOf(o))+"</"+name+">"; }

  String readAll(InputStream in) throws IOException { return new String(in.readAllBytes(), StandardCharsets.UTF_8); }

  void help() {
    System.out.println("yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) ");
    System.out.println("See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.\n");
    System.out.println("Usage:\n  yq [flags]\n  yq [command]\n\nAvailable Commands:\n  completion  Generate the autocompletion script for the specified shell\n  eval        (default) Apply the expression to each document in each yaml file in sequence\n  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once\n  help        Help about any command\n");
    System.out.println("Flags:\n  -C, --colors                            force print with colors\n  -e, --exit-status                       set exit status if there are no matches or null or false is returned\n      --expression string                 forcibly set the expression argument.\n      --from-file string                  Load expression from specified file.\n  -h, --help                              help for yq\n  -I, --indent int                        sets indent level for output (default 2)\n  -i, --inplace                           update the file in place of first file given.\n  -p, --input-format string               parse format for input. (default \"auto\")\n  -M, --no-colors                         force print with no colors\n  -N, --no-doc                            Don't print document separators (---)\n  -0, --nul-output                        Use NUL char to separate values.\n  -n, --null-input                        Don't read input, simply evaluate the expression given.\n  -o, --output-format string              output format type. (default \"auto\")\n  -P, --prettyPrint                       pretty print\n  -r, --unwrapScalar                      unwrap scalar (default true)\n  -v, --verbose                           verbose mode\n  -V, --version                           Print version information and quit");
  }
  void completion(String shell){ System.out.println("# completion for " + shell); }

  static class Json {
    String s; int i; Json(String s){this.s=s.trim();}
    Object parse(){ skip(); return val(); }
    Object val(){ skip(); if(i>=s.length())return null; char c=s.charAt(i); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='"')return str(); if(s.startsWith("true",i)){i+=4;return true;} if(s.startsWith("false",i)){i+=5;return false;} if(s.startsWith("null",i)){i+=4;return null;} return num(); }
    Object obj(){ i++; LinkedHashMap<String,Object> m=new LinkedHashMap<>(); skip(); if(s.charAt(i)=='}'){i++;return m;} while(true){ String k=str(); skip(); i++; Object v=val(); m.put(k,v); skip(); if(s.charAt(i)=='}'){i++;break;} i++; skip(); } return m; }
    Object arr(){ i++; ArrayList<Object> a=new ArrayList<>(); skip(); if(s.charAt(i)==']'){i++;return a;} while(true){ a.add(val()); skip(); if(s.charAt(i)==']'){i++;break;} i++; } return a; }
    String str(){ i++; StringBuilder b=new StringBuilder(); while(i<s.length()){ char c=s.charAt(i++); if(c=='"')break; if(c=='\\'&&i<s.length()){ char e=s.charAt(i++); b.append(e=='n'?'\n':e=='t'?'\t':e); } else b.append(c);} return b.toString(); }
    Object num(){ int j=i; while(i<s.length()&&"-+.0123456789eE".indexOf(s.charAt(i))>=0)i++; String n=s.substring(j,i); if(n.contains(".")||n.contains("e")||n.contains("E")) return Double.parseDouble(n); return Long.parseLong(n); }
    void skip(){ while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++; }
  }
}
