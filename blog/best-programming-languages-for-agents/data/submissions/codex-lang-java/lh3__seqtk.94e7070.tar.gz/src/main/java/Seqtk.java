import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

public class Seqtk {
    static class Rec {
        String name, comment, seq, qual;
        boolean fastq;
        String header() { return comment == null || comment.isEmpty() ? name : name + " " + comment; }
        String id() { return name; }
    }

    static class ReaderSeq implements Closeable {
        BufferedReader br;
        String pending;
        ReaderSeq(String path) throws IOException { br = open(path); }
        public void close() throws IOException { br.close(); }
        Rec next() throws IOException {
            String h = pending;
            pending = null;
            while (h == null) {
                h = br.readLine();
                if (h == null) return null;
                if (!h.isEmpty() && (h.charAt(0) == '>' || h.charAt(0) == '@')) break;
                h = null;
            }
            char type = h.charAt(0);
            String head = h.substring(1);
            Rec r = new Rec();
            int sp = firstWs(head);
            r.name = sp < 0 ? head : head.substring(0, sp);
            r.comment = sp < 0 ? "" : head.substring(sp + 1).trim();
            StringBuilder seq = new StringBuilder();
            if (type == '>') {
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.isEmpty() && (line.charAt(0) == '>' || line.charAt(0) == '@')) {
                        pending = line;
                        break;
                    }
                    seq.append(line.trim());
                }
                r.seq = seq.toString();
                r.fastq = false;
                return r;
            } else {
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.isEmpty() && line.charAt(0) == '+') break;
                    seq.append(line.trim());
                }
                StringBuilder q = new StringBuilder();
                while (q.length() < seq.length() && (line = br.readLine()) != null) q.append(line.trim());
                r.seq = seq.toString();
                r.qual = q.length() > seq.length() ? q.substring(0, seq.length()) : q.toString();
                r.fastq = true;
                return r;
            }
        }
    }

    static BufferedReader open(String path) throws IOException {
        InputStream in = path.equals("-") ? System.in : Files.newInputStream(Paths.get(path));
        if (path.endsWith(".gz")) in = new GZIPInputStream(in);
        return new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    static int firstWs(String s) {
        for (int i = 0; i < s.length(); i++) if (Character.isWhitespace(s.charAt(i))) return i;
        return -1;
    }

    public static void main(String[] args) throws Exception {
        if (args.length == 0) { mainUsage(); return; }
        try {
            switch (args[0]) {
                case "seq": cmdSeq(Arrays.copyOfRange(args, 1, args.length)); break;
                case "size": cmdSize(args); break;
                case "comp": cmdComp(args); break;
                case "subseq": cmdSubseq(Arrays.copyOfRange(args, 1, args.length)); break;
                case "sample": cmdSample(Arrays.copyOfRange(args, 1, args.length)); break;
                case "trimfq": cmdTrimfq(Arrays.copyOfRange(args, 1, args.length)); break;
                case "mergepe": cmdMergepe(args); break;
                case "fqchk": cmdFqchk(Arrays.copyOfRange(args, 1, args.length)); break;
                case "split": cmdSplit(Arrays.copyOfRange(args, 1, args.length)); break;
                case "gap": cmdGap(Arrays.copyOfRange(args, 1, args.length)); break;
                case "hpc": cmdHpc(args); break;
                case "rename": cmdRename(args); break;
                case "randbase": cmdRandbase(args); break;
                case "listhet": cmdListhet(args); break;
                case "mutfa": cmdMutfa(args); break;
                case "famask": cmdFamask(args); break;
                case "cutN": cmdCutN(Arrays.copyOfRange(args, 1, args.length)); break;
                case "dropse": cmdDropse(args); break;
                case "mergefa": cmdMergefa(Arrays.copyOfRange(args, 1, args.length)); break;
                case "telo": cmdTelo(args); break;
                case "gc": cmdGc(Arrays.copyOfRange(args, 1, args.length)); break;
                case "hety": cmdHety(args); break;
                default:
                    System.err.println("[main] unrecognized command '" + args[0] + "'. Abort!");
            }
        } catch (Usage u) {
            System.err.print(u.getMessage());
        }
    }

    static class Usage extends RuntimeException { Usage(String s) { super(s); } }

    static void mainUsage() {
        System.out.println();
        System.out.println("Usage:   seqtk <command> <arguments>");
        System.out.println("Version: 1.5-r133");
        System.out.println();
        System.out.println("Command: seq       common transformation of FASTA/Q");
        System.out.println("         size      report the number sequences and bases");
        System.out.println("         comp      get the nucleotide composition of FASTA/Q");
        System.out.println("         sample    subsample sequences");
        System.out.println("         subseq    extract subsequences from FASTA/Q");
        System.out.println("         fqchk     fastq QC (base/quality summary)");
        System.out.println("         mergepe   interleave two PE FASTA/Q files");
        System.out.println("         split     split one file into multiple smaller files");
        System.out.println("         trimfq    trim FASTQ using the Phred algorithm");
        System.out.println();
        System.out.println("         hety      regional heterozygosity");
        System.out.println("         gc        identify high- or low-GC regions");
        System.out.println("         mutfa     point mutate FASTA at specified positions");
        System.out.println("         mergefa   merge two FASTA/Q files");
        System.out.println("         famask    apply a X-coded FASTA to a source FASTA");
        System.out.println("         dropse    drop unpaired from interleaved PE FASTA/Q");
        System.out.println("         rename    rename sequence names");
        System.out.println("         randbase  choose a random base from hets");
        System.out.println("         cutN      cut sequence at long N");
        System.out.println("         gap       get the gap locations");
        System.out.println("         listhet   extract the position of each het");
        System.out.println("         hpc       homopolyer-compressed sequence");
        System.out.println("         telo      identify telomere repeats in asm or long reads");
        System.out.println();
    }

    static void cmdSeq(String[] a) throws Exception {
        boolean toFa = false, toFq = false, rev = false, noComment = false;
        int lineLen = -1, qBase = 33, qThres = -1;
        Character maskChar = null;
        String maskBed = null;
        List<String> files = new ArrayList<>();
        for (int i = 0; i < a.length; i++) {
            String s = a[i];
            if (!s.startsWith("-") || s.equals("-")) { files.add(s); continue; }
            for (int j = 1; j < s.length(); j++) {
                char c = s.charAt(j);
                String val = j + 1 < s.length() ? s.substring(j + 1) : null;
                if (c == 'a' || c == 'A') toFa = true;
                else if (c == 'F') toFq = true;
                else if (c == 'r') rev = true;
                else if (c == 'C') noComment = true;
                else if (c == 'Q') { qBase = Integer.parseInt(val != null ? val : a[++i]); break; }
                else if (c == 'q') { qThres = Integer.parseInt(val != null ? val : a[++i]); break; }
                else if (c == 'n') { String v = val != null ? val : a[++i]; maskChar = v.isEmpty() ? 'N' : v.charAt(0); break; }
                else if (c == 'l') { lineLen = Integer.parseInt(val != null ? val : a[++i]); break; }
                else if (c == 'M') { maskBed = val != null ? val : a[++i]; break; }
            }
        }
        if (files.isEmpty()) return;
        Map<String,List<int[]>> masks = maskBed == null ? Collections.emptyMap() : readBed(maskBed);
        try (ReaderSeq rs = new ReaderSeq(files.get(0))) {
            Rec r;
            while ((r = rs.next()) != null) {
                if (rev) reverse(r);
                if (!masks.isEmpty()) applyMasks(r, masks.get(r.name), maskChar == null ? null : maskChar);
                if (qThres >= 0 && r.fastq) maskByQual(r, qBase, qThres, maskChar);
                writeRec(r, toFa || !r.fastq, toFq && r.fastq, lineLen, noComment, System.out);
            }
        }
    }

    static void maskByQual(Rec r, int base, int th, Character mask) {
        char[] s = r.seq.toCharArray();
        for (int i = 0; i < s.length && i < r.qual.length(); i++) {
            if (r.qual.charAt(i) - base < th) s[i] = mask == null ? Character.toLowerCase(s[i]) : mask;
        }
        r.seq = new String(s);
    }

    static void applyMasks(Rec r, List<int[]> regs, Character mask) {
        if (regs == null) return;
        char[] s = r.seq.toCharArray();
        for (int[] x : regs) {
            int b = Math.max(0, x[0]), e = Math.min(s.length, x[1]);
            for (int i = b; i < e; i++) s[i] = mask == null ? Character.toLowerCase(s[i]) : mask;
        }
        r.seq = new String(s);
    }

    static void writeRec(Rec r, boolean fasta, boolean fastq, int lineLen, boolean noComment, PrintStream out) {
        String head = noComment ? r.name : r.header();
        if (!fasta && r.fastq || fastq) {
            out.println("@" + head);
            printFold(r.seq, lineLen, out);
            out.println("+");
            printFold(r.qual == null ? repeat('I', r.seq.length()) : r.qual, lineLen, out);
        } else {
            out.println(">" + head);
            printFold(r.seq, lineLen, out);
        }
    }

    static void printFold(String s, int lineLen, PrintStream out) {
        if (lineLen < 0) { out.println(s); return; }
        if (lineLen == 0) { out.println(s); return; }
        for (int i = 0; i < s.length(); i += lineLen) out.println(s.substring(i, Math.min(s.length(), i + lineLen)));
    }

    static String repeat(char c, int n) { char[] a = new char[n]; Arrays.fill(a, c); return new String(a); }

    static void reverse(Rec r) {
        r.seq = revcomp(r.seq);
        if (r.qual != null) r.qual = new StringBuilder(r.qual).reverse().toString();
    }

    static String revcomp(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = s.length() - 1; i >= 0; i--) b.append(comp(s.charAt(i)));
        return b.toString();
    }

    static char comp(char c) {
        switch (c) {
            case 'A': return 'T'; case 'C': return 'G'; case 'G': return 'C'; case 'T': return 'A';
            case 'a': return 't'; case 'c': return 'g'; case 'g': return 'c'; case 't': return 'a';
            case 'U': return 'A'; case 'u': return 'a';
            case 'M': return 'K'; case 'R': return 'Y'; case 'W': return 'W'; case 'S': return 'S';
            case 'Y': return 'R'; case 'K': return 'M'; case 'V': return 'B'; case 'H': return 'D';
            case 'D': return 'H'; case 'B': return 'V';
            case 'm': return 'k'; case 'r': return 'y'; case 'w': return 'w'; case 's': return 's';
            case 'y': return 'r'; case 'k': return 'm'; case 'v': return 'b'; case 'h': return 'd';
            case 'd': return 'h'; case 'b': return 'v';
            default: return c;
        }
    }

    static void cmdSize(String[] args) throws Exception {
        if (args.length < 2) return;
        long n = 0, bases = 0;
        try (ReaderSeq rs = new ReaderSeq(args[1])) {
            Rec r; while ((r = rs.next()) != null) { n++; bases += r.seq.length(); }
        }
        System.out.println(n + "\t" + bases);
    }

    static void cmdComp(String[] args) throws Exception {
        if (args.length < 2) return;
        try (ReaderSeq rs = new ReaderSeq(args[1])) {
            Rec r;
            while ((r = rs.next()) != null) {
                int[] c = new int[11];
                for (char ch : r.seq.toCharArray()) {
                    switch (Character.toUpperCase(ch)) {
                        case 'A': c[0]++; break; case 'C': c[1]++; break; case 'G': c[2]++; break; case 'T': case 'U': c[3]++; break;
                        case '2': c[4]++; break; case '3': c[5]++; break; case 'N': c[6]++; break;
                        default: c[8]++; break;
                    }
                    if (Character.isLowerCase(ch)) c[7]++;
                }
                System.out.printf("%s\t%d", r.name, r.seq.length());
                for (int i = 0; i < 11; i++) System.out.print("\t" + c[i]);
                System.out.println();
            }
        }
    }

    static Map<String,List<int[]>> readBed(String p) throws IOException {
        Map<String,List<int[]>> m = new HashMap<>();
        try (BufferedReader br = open(p)) {
            String l;
            while ((l = br.readLine()) != null) {
                if (l.isEmpty() || l.charAt(0) == '#') continue;
                String[] t = l.trim().split("\\s+");
                if (t.length >= 3) m.computeIfAbsent(t[0], k -> new ArrayList<>()).add(new int[]{Integer.parseInt(t[1]), Integer.parseInt(t[2])});
            }
        }
        return m;
    }

    static void cmdSubseq(String[] a) throws Exception {
        boolean tab = false, strand = false; int lineLen = 0; List<String> f = new ArrayList<>();
        for (int i = 0; i < a.length; i++) {
            if (a[i].equals("-t")) tab = true; else if (a[i].equals("-s")) strand = true;
            else if (a[i].equals("-l")) lineLen = Integer.parseInt(a[++i]);
            else if (a[i].startsWith("-l")) lineLen = Integer.parseInt(a[i].substring(2));
            else f.add(a[i]);
        }
        if (f.size() < 2) throw new Usage("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\nOptions:\n  -t       TAB delimited output\n  -s       strand aware\n  -l INT   sequence line length [0]\nNote: Use 'samtools faidx' if only a few regions are intended.\n");
        List<String[]> regs = new ArrayList<>(); Set<String> names = new LinkedHashSet<>(); boolean bed = false;
        try (BufferedReader br = open(f.get(1))) {
            String l;
            while ((l = br.readLine()) != null) {
                if (l.isEmpty() || l.charAt(0) == '#') continue;
                String[] t = l.trim().split("\\s+");
                if (t.length >= 3 && isInt(t[1]) && isInt(t[2])) { bed = true; regs.add(t); } else names.add(t[0]);
            }
        }
        Map<String,Rec> map = new LinkedHashMap<>();
        try (ReaderSeq rs = new ReaderSeq(f.get(0))) { Rec r; while ((r = rs.next()) != null) map.put(r.name, r); }
        if (!bed) {
            for (String n : names) { Rec r = map.get(n); if (r != null) writeRec(r, !r.fastq, false, lineLen, false, System.out); }
        } else for (String[] t : regs) {
            Rec r = map.get(t[0]); if (r == null) continue;
            int b = Math.max(0, Integer.parseInt(t[1])), e = Math.min(r.seq.length(), Integer.parseInt(t[2]));
            if (b > e) continue;
            String s = r.seq.substring(b, e), q = r.qual == null ? null : r.qual.substring(b, e);
            boolean neg = strand && t.length >= 6 && t[5].equals("-");
            if (neg) { s = revcomp(s); if (q != null) q = new StringBuilder(q).reverse().toString(); }
            if (tab) System.out.println(t[0] + "\t" + b + "\t" + e + "\t" + s);
            else { Rec x = new Rec(); x.name = t[0] + ":" + (b + 1) + "-" + e; x.comment = ""; x.seq = s; x.qual = q; x.fastq = r.fastq; writeRec(x, !x.fastq, false, lineLen, false, System.out); }
        }
    }

    static boolean isInt(String s) { try { Integer.parseInt(s); return true; } catch (Exception e) { return false; } }

    static void cmdSample(String[] a) throws Exception {
        int seed = 11; boolean two = false; List<String> f = new ArrayList<>();
        for (int i = 0; i < a.length; i++) {
            if (a[i].equals("-2")) two = true;
            else if (a[i].equals("-s")) seed = Integer.parseInt(a[++i]);
            else if (a[i].startsWith("-s")) seed = Integer.parseInt(a[i].substring(2));
            else f.add(a[i]);
        }
        if (f.size() < 2) throw new Usage("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n\nOptions: -s INT       RNG seed [11]\n         -2           2-pass mode: twice as slow but with much reduced memory\n\n");
        double v = Double.parseDouble(f.get(1));
        List<Rec> recs = new ArrayList<>();
        try (ReaderSeq rs = new ReaderSeq(f.get(0))) { Rec r; while ((r = rs.next()) != null) recs.add(r); }
        Random rnd = new Random(seed);
        if (v < 1.0) {
            for (Rec rec : recs) if (rnd.nextDouble() < v) writeRec(rec, !rec.fastq, false, -1, false, System.out);
        } else {
            List<Rec> shuffled = new ArrayList<>(recs);
            Collections.shuffle(shuffled, rnd);
            int n = Math.min((int)v, shuffled.size());
            Set<Rec> pick = Collections.newSetFromMap(new IdentityHashMap<>());
            for (int i = 0; i < n; i++) pick.add(shuffled.get(i));
            for (Rec rec : recs) if (pick.contains(rec)) writeRec(rec, !rec.fastq, false, -1, false, System.out);
        }
    }

    static void cmdTrimfq(String[] a) throws Exception {
        int b = 0, e = 0, L = 0, min = 30; double q = .05; boolean forceQ = false; List<String> f = new ArrayList<>();
        for (int i = 0; i < a.length; i++) {
            String s = a[i];
            if (s.equals("-Q")) forceQ = true;
            else if (s.equals("-b")) b = Integer.parseInt(a[++i]); else if (s.startsWith("-b")) b = Integer.parseInt(s.substring(2));
            else if (s.equals("-e")) e = Integer.parseInt(a[++i]); else if (s.startsWith("-e")) e = Integer.parseInt(s.substring(2));
            else if (s.equals("-L")) L = Integer.parseInt(a[++i]); else if (s.startsWith("-L")) L = Integer.parseInt(s.substring(2));
            else if (s.equals("-l")) min = Integer.parseInt(a[++i]); else if (s.startsWith("-l")) min = Integer.parseInt(s.substring(2));
            else if (s.equals("-q")) q = Double.parseDouble(a[++i]); else if (s.startsWith("-q")) q = Double.parseDouble(s.substring(2));
            else f.add(s);
        }
        if (f.isEmpty()) throw new Usage("\nUsage:   seqtk trimfq [options] <in.fq>\n\nOptions: -q FLOAT    error rate threshold (disabled by -b/-e) [0.05]\n         -l INT      maximally trim down to INT bp (disabled by -b/-e) [30]\n         -b INT      trim INT bp from left (non-zero to disable -q/-l) [0]\n         -e INT      trim INT bp from right (non-zero to disable -q/-l) [0]\n         -L INT      retain at most INT bp from the 5'-end (non-zero to disable -q/-l) [0]\n         -Q          force FASTQ output\n\n");
        try (ReaderSeq rs = new ReaderSeq(f.get(0))) {
            Rec r; while ((r = rs.next()) != null) {
                int st = b, en = r.seq.length() - e;
                if (L > 0) en = Math.min(en, st + L);
                if (b == 0 && e == 0 && L == 0 && r.qual != null) {
                    int th = (int)Math.round(-10.0 * Math.log10(q));
                    while (st < en && r.qual.charAt(st) - 33 < th) st++;
                    while (en > st && r.qual.charAt(en - 1) - 33 < th) en--;
                    if (en - st < min) en = st;
                }
                st = Math.max(0, Math.min(st, r.seq.length())); en = Math.max(st, Math.min(en, r.seq.length()));
                r.seq = r.seq.substring(st, en); if (r.qual != null) r.qual = r.qual.substring(st, en);
                writeRec(r, !forceQ && !r.fastq, forceQ, -1, false, System.out);
            }
        }
    }

    static void cmdMergepe(String[] args) throws Exception {
        if (args.length < 3) throw new Usage("Usage: seqtk mergepe <in1.fq> <in2.fq>\n");
        try (ReaderSeq a = new ReaderSeq(args[1]); ReaderSeq b = new ReaderSeq(args[2])) {
            Rec x, y; while ((x = a.next()) != null & (y = b.next()) != null) { writeRec(x, !x.fastq, false, -1, false, System.out); writeRec(y, !y.fastq, false, -1, false, System.out); }
        }
    }

    static void cmdFqchk(String[] a) throws Exception {
        int q = 20; String file = null;
        for (int i = 0; i < a.length; i++) if (a[i].equals("-q")) q = Integer.parseInt(a[++i]); else if (a[i].startsWith("-q")) q = Integer.parseInt(a[i].substring(2)); else file = a[i];
        if (file == null) throw new Usage("Usage: seqtk fqchk [-q 20] <in.fq>\nNote: use -q0 to get the distribution of all quality values\n");
        long n = 0, bases = 0, low = 0;
        try (ReaderSeq rs = new ReaderSeq(file)) { Rec r; while ((r = rs.next()) != null) { n++; bases += r.seq.length(); for (char c : r.qual.toCharArray()) if (c - 33 < q) low++; } }
        System.out.println("ALL\t" + n + "\t" + bases + "\t" + low);
    }

    static void cmdSplit(String[] a) throws Exception {
        int n = 10, l = 0; List<String> f = new ArrayList<>();
        for (int i = 0; i < a.length; i++) {
            if (a[i].equals("-n")) n = Integer.parseInt(a[++i]); else if (a[i].startsWith("-n")) n = Integer.parseInt(a[i].substring(2));
            else if (a[i].equals("-l")) l = Integer.parseInt(a[++i]); else if (a[i].startsWith("-l")) l = Integer.parseInt(a[i].substring(2));
            else f.add(a[i]);
        }
        if (f.size() < 2) throw new Usage("Usage: seqtk split [options] <prefix> <in.fa>\nOptions:\n  -n INT    number of files [10]\n  -l INT    line length [0]\n");
        PrintStream[] ps = new PrintStream[n];
        for (int i = 0; i < n; i++) ps[i] = new PrintStream(new FileOutputStream(f.get(0) + "." + i + ".fa"));
        try (ReaderSeq rs = new ReaderSeq(f.get(1))) { Rec r; int i = 0; while ((r = rs.next()) != null) writeRec(r, true, false, l, false, ps[(i++) % n]); }
        for (PrintStream p : ps) p.close();
    }

    static void cmdGap(String[] a) throws Exception {
        int min = 50; String file = null;
        for (int i = 0; i < a.length; i++) if (a[i].equals("-l")) min = Integer.parseInt(a[++i]); else if (a[i].startsWith("-l")) min = Integer.parseInt(a[i].substring(2)); else file = a[i];
        if (file == null) throw new Usage("Usage: seqtk gap [-l 50] <in.fa>\n");
        try (ReaderSeq rs = new ReaderSeq(file)) { Rec r; while ((r = rs.next()) != null) printGaps(r, min); }
    }
    static void printGaps(Rec r, int min) {
        int i = 0; while (i < r.seq.length()) { while (i < r.seq.length() && Character.toUpperCase(r.seq.charAt(i)) != 'N') i++; int b = i; while (i < r.seq.length() && Character.toUpperCase(r.seq.charAt(i)) == 'N') i++; if (i - b >= min) System.out.println(r.name + "\t" + b + "\t" + i); }
    }

    static void cmdHpc(String[] args) throws Exception {
        if (args.length < 2) return;
        try (ReaderSeq rs = new ReaderSeq(args[1])) { Rec r; while ((r = rs.next()) != null) { r.seq = hpc(r.seq); if (r.qual != null && r.qual.length() > r.seq.length()) r.qual = r.qual.substring(0, r.seq.length()); writeRec(r, true, false, -1, true, System.out); } }
    }
    static String hpc(String s) { StringBuilder b = new StringBuilder(); char prev = 0; for (char c : s.toCharArray()) { if (b.length()==0 || Character.toUpperCase(c)!=Character.toUpperCase(prev)) b.append(c); prev = c; } return b.toString(); }

    static void cmdRename(String[] args) throws Exception {
        if (args.length < 2) return; int i = 1; try (ReaderSeq rs = new ReaderSeq(args[1])) { Rec r; while ((r = rs.next()) != null) { r.name = String.valueOf(i++); r.comment = ""; writeRec(r, !r.fastq, false, -1, false, System.out); } }
    }
    static void cmdRandbase(String[] args) throws Exception {
        if (args.length < 2) throw new Usage("Usage: seqtk randbase <in.fa>\n"); Random rnd = new Random(11);
        try (ReaderSeq rs = new ReaderSeq(args[1])) { Rec r; while ((r = rs.next()) != null) { char[] s = r.seq.toCharArray(); for (int i=0;i<s.length;i++) s[i]=randBase(s[i],rnd); r.seq=new String(s); writeRec(r,true,false,-1,false,System.out);} }
    }
    static char randBase(char c, Random r) { char u=Character.toUpperCase(c); String opts; switch(u){case 'R':opts="AG";break;case 'Y':opts="CT";break;case 'M':opts="AC";break;case 'K':opts="GT";break;case 'S':opts="CG";break;case 'W':opts="AT";break;default:return c;} char x=opts.charAt(r.nextInt(opts.length())); return Character.isLowerCase(c)?Character.toLowerCase(x):x; }
    static void cmdListhet(String[] args) throws Exception {
        if (args.length < 2) throw new Usage("Usage: seqtk listhet <in.fa>\n");
        try (ReaderSeq rs = new ReaderSeq(args[1])) { Rec r; while ((r=rs.next())!=null) for(int i=0;i<r.seq.length();i++) if("RYSWKMryswkm".indexOf(r.seq.charAt(i))>=0) System.out.println(r.name+"\t"+(i+1)+"\t"+r.seq.charAt(i)); }
    }

    static void cmdMutfa(String[] args) throws Exception {
        if (args.length < 3) throw new Usage("Usage: seqtk mutfa <in.fa> <in.snp>\n\nNote: <in.snp> contains at least four columns per line which are:\n      'chr  1-based-pos  any  base-changed-to'.\n");
        Map<String,Map<Integer,Character>> muts = new HashMap<>();
        try (BufferedReader br=open(args[2])) { String l; while((l=br.readLine())!=null){ if(l.isEmpty()||l.charAt(0)=='#')continue; String[]t=l.trim().split("\\s+"); if(t.length>=4)muts.computeIfAbsent(t[0],k->new HashMap<>()).put(Integer.parseInt(t[1])-1,t[3].charAt(0));}}
        try (ReaderSeq rs=new ReaderSeq(args[1])) { Rec r; while((r=rs.next())!=null){ char[]s=r.seq.toCharArray(); Map<Integer,Character> mm=muts.get(r.name); if(mm!=null) for(Map.Entry<Integer,Character>e:mm.entrySet()) if(e.getKey()>=0&&e.getKey()<s.length)s[e.getKey()]=e.getValue(); r.seq=new String(s); writeRec(r,true,false,-1,false,System.out);} }
    }
    static void cmdFamask(String[] args) throws Exception {
        if (args.length < 3) throw new Usage("Usage: seqtk famask <src.fa> <mask.fa>\n");
        Map<String,Rec> mask=new HashMap<>(); try(ReaderSeq rs=new ReaderSeq(args[2])){Rec r;while((r=rs.next())!=null)mask.put(r.name,r);}
        try(ReaderSeq rs=new ReaderSeq(args[1])){Rec r;while((r=rs.next())!=null){Rec m=mask.get(r.name); if(m!=null){char[]s=r.seq.toCharArray(); for(int i=0;i<s.length&&i<m.seq.length();i++) if(Character.toUpperCase(m.seq.charAt(i))=='X') s[i]='N'; r.seq=new String(s);} writeRec(r,true,false,-1,false,System.out);}}
    }

    static void cmdCutN(String[] a) throws Exception {
        int min=1000, pen=10; boolean gaps=false; String file=null;
        for(int i=0;i<a.length;i++){ if(a[i].equals("-g"))gaps=true; else if(a[i].equals("-n"))min=Integer.parseInt(a[++i]); else if(a[i].startsWith("-n"))min=Integer.parseInt(a[i].substring(2)); else if(a[i].equals("-p"))pen=Integer.parseInt(a[++i]); else if(a[i].startsWith("-p"))pen=Integer.parseInt(a[i].substring(2)); else file=a[i];}
        if(file==null) throw new Usage("\nUsage:   seqtk cutN [options] <in.fa>\n\nOptions: -n INT    min size of N tract [1000]\n         -p INT    penalty for a non-N [10]\n         -g        print gaps only, no sequence\n\n");
        try(ReaderSeq rs=new ReaderSeq(file)){Rec r; while((r=rs.next())!=null){ if(gaps) printGaps(r,min); else cutNPrint(r,min);}}
    }
    static void cutNPrint(Rec r,int min){ int last=0,part=1,i=0; while(i<r.seq.length()){ while(i<r.seq.length()&&Character.toUpperCase(r.seq.charAt(i))!='N')i++; int b=i; while(i<r.seq.length()&&Character.toUpperCase(r.seq.charAt(i))=='N')i++; if(i-b>=min){ if(b>last){Rec x=new Rec();x.name=r.name+"_"+part++;x.comment="";x.seq=r.seq.substring(last,b);writeRec(x,true,false,-1,false,System.out);} last=i;}} if(last<r.seq.length()){Rec x=new Rec();x.name=r.name+"_"+part;x.comment="";x.seq=r.seq.substring(last);writeRec(x,true,false,-1,false,System.out);}}

    static void cmdDropse(String[] args) throws Exception { if(args.length<2)return; try(ReaderSeq rs=new ReaderSeq(args[1])){Rec a,b; while((a=rs.next())!=null && (b=rs.next())!=null){writeRec(a,!a.fastq,false,-1,false,System.out);writeRec(b,!b.fastq,false,-1,false,System.out);}} }
    static void cmdMergefa(String[] a) throws Exception { List<String> f=new ArrayList<>(); for(String s:a) if(!s.startsWith("-")) f.add(s); if(f.size()<2) throw new Usage("\nUsage: seqtk mergefa [options] <in1.fa> <in2.fa>\n\nOptions: -q INT   quality threshold [0]\n         -i       take intersection\n         -m       convert to lowercase when one of the input base is N\n         -r       pick a random allele from het\n         -h       suppress hets in the input\n\n"); try(ReaderSeq r1=new ReaderSeq(f.get(0));ReaderSeq r2=new ReaderSeq(f.get(1))){Rec x,y; while((x=r1.next())!=null & (y=r2.next())!=null){x.seq=mergeSeq(x.seq,y.seq); writeRec(x,true,false,-1,false,System.out);}} }
    static String mergeSeq(String a,String b){StringBuilder s=new StringBuilder(); for(int i=0;i<a.length();i++){char x=a.charAt(i), y=i<b.length()?b.charAt(i):'N'; s.append(Character.toUpperCase(x)=='N'?y:x);} return s.toString();}
    static void cmdTelo(String[] args) throws Exception { if(args.length<2){System.out.println("0\t0");return;} try(ReaderSeq rs=new ReaderSeq(args[1])){Rec r; while((r=rs.next())!=null){String u=r.seq.toUpperCase(); findMotif(r.name,u,"TTAGGG"); findMotif(r.name,u,"CCCTAA");}} }
    static void findMotif(String name,String s,String m){ for(int i=0;i+m.length()*3<=s.length();i++){int j=i,c=0; while(j+m.length()<=s.length()&&s.substring(j,j+m.length()).equals(m)){c++;j+=m.length();} if(c>=3){System.out.println(name+"\t"+i+"\t"+j+"\t"+m+"\t"+c); i=j-1;}} }
    static void cmdGc(String[] a) throws Exception { String file=null; double min=.60; int len=20; boolean at=false; for(int i=0;i<a.length;i++){if(a[i].equals("-w"))at=true;else if(a[i].equals("-f"))min=Double.parseDouble(a[++i]);else if(a[i].startsWith("-f"))min=Double.parseDouble(a[i].substring(2));else if(a[i].equals("-l"))len=Integer.parseInt(a[++i]);else if(a[i].startsWith("-l"))len=Integer.parseInt(a[i].substring(2));else if(!a[i].startsWith("-"))file=a[i];} if(file==null) throw new Usage("Usage: seqtk gc [options] <in.fa>\nOptions:\n  -w         identify high-AT regions\n  -f FLOAT   min GC fraction (or AT fraction for -w) [0.60]\n  -l INT     min region length to output [20]\n  -x FLOAT   X-dropoff [10.0]\n"); try(ReaderSeq rs=new ReaderSeq(file)){Rec r; while((r=rs.next())!=null){int b=-1; for(int i=0;i<r.seq.length();i++){char c=Character.toUpperCase(r.seq.charAt(i)); boolean ok=at?(c=='A'||c=='T'):(c=='G'||c=='C'); if(ok&&b<0)b=i; if((!ok||i==r.seq.length()-1)&&b>=0){int e=ok&&i==r.seq.length()-1?i+1:i; if(e-b>=len)System.out.println(r.name+"\t"+b+"\t"+e); b=-1;}}}} }
    static void cmdHety(String[] args) throws Exception { if(args.length<2) throw new Usage("\nUsage:   seqtk hety [options] <in.fa>\n\nOptions: -w INT   window size [50000]\n         -t INT   # start positions in a window [5]\n         -m       treat lowercases as masked\n\n"); }
}
