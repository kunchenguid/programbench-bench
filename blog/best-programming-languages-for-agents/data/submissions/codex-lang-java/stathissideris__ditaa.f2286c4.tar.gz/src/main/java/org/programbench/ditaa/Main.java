package org.programbench.ditaa;

import javax.imageio.ImageIO;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    private static final String VERSION = "ditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            if (code != 0) System.exit(code);
        } catch (OptionException e) {
            System.err.println(e.getMessage());
            printHelp(System.err);
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    private int run(String[] args) throws Exception {
        Options opt = parse(args);
        if (opt.help || args.length == 0) {
            printHelp(System.out);
            return 0;
        }
        if (opt.input == null) throw new OptionException("Missing argument: INPFILE");

        Path input = Paths.get(opt.input);
        if (!Files.exists(input)) {
            banner(opt);
            System.out.println("Reading file: " + input);
            System.err.println("Error: File " + input + " does not exist");
            return 1;
        }

        if (opt.html) {
            Path out = Paths.get(opt.output != null ? opt.output : defaultOutput(input, ".html"));
            banner(opt);
            System.out.println("Converting HTML file (" + input + " -> " + out + ")... ");
            convertHtml(input, out, opt);
            return 0;
        }

        Path out = Paths.get(opt.output != null ? opt.output : defaultOutput(input, opt.svg ? ".svg" : ".png"));
        banner(opt);
        System.out.println("Reading file: " + input);
        String text = Files.readString(input, Charset.forName(opt.encoding));
        Diagram diagram = Diagram.from(text, opt.tabs);
        System.out.println("Rendering to file: " + out);
        Files.createDirectories(out.toAbsolutePath().getParent() == null ? Paths.get(".") : out.toAbsolutePath().getParent());
        if (opt.svg) {
            Files.writeString(out, SvgRenderer.render(diagram, opt), StandardCharsets.UTF_8);
        } else {
            ImageIO.write(RasterRenderer.render(diagram, opt), "png", out.toFile());
        }
        System.out.println("Done in 0sec");
        return 0;
    }

    private static void banner(Options opt) {
        System.out.println();
        System.out.println(VERSION);
        System.out.println();
        System.out.println("Running with options:");
        if (opt.html) System.out.println("html");
        if (opt.svg) System.out.println("svg");
        if (opt.overwrite) System.out.println("overwrite");
        if (opt.noAntialias) System.out.println("no-antialias");
        if (opt.roundCorners) System.out.println("round-corners");
        if (opt.noShadows) System.out.println("no-shadows");
        if (opt.transparent) System.out.println("transparent");
    }

    private static String defaultOutput(Path input, String ext) {
        String name = input.toString();
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        int dot = name.lastIndexOf('.');
        if (dot > slash) name = name.substring(0, dot);
        return name + ext;
    }

    private static Options parse(String[] args) {
        Options opt = new Options();
        List<String> pos = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "--help": opt.help = true; break;
                case "-h": case "--html": opt.html = true; break;
                case "--svg": opt.svg = true; break;
                case "-o": case "--overwrite": opt.overwrite = true; break;
                case "-A": case "--no-antialias": opt.noAntialias = true; break;
                case "-d": case "--debug": opt.debug = true; break;
                case "-E": case "--no-separation": opt.noSeparation = true; break;
                case "-r": case "--round-corners": opt.roundCorners = true; break;
                case "-S": case "--no-shadows": opt.noShadows = true; break;
                case "-T": case "--transparent": opt.transparent = true; break;
                case "-v": case "--verbose": opt.verbose = true; break;
                case "-W": case "--fixed-slope": opt.fixedSlope = true; break;
                case "-b": case "--background":
                    opt.background = need(args, ++i, a);
                    break;
                case "-e": case "--encoding":
                    opt.encoding = need(args, ++i, a);
                    break;
                case "-s": case "--scale":
                    opt.scale = Double.parseDouble(need(args, ++i, a));
                    break;
                case "-t": case "--tabs":
                    opt.tabs = Integer.parseInt(need(args, ++i, a));
                    break;
                case "--svg-font-url":
                    opt.svgFontUrl = need(args, ++i, a);
                    break;
                default:
                    if (a.startsWith("-")) throw new OptionException("Unrecognized option: " + a);
                    pos.add(a);
            }
        }
        if (pos.size() > 0) opt.input = pos.get(0);
        if (pos.size() > 1) opt.output = pos.get(1);
        if (pos.size() > 2) throw new OptionException("Unrecognized argument: " + pos.get(2));
        return opt;
    }

    private static String need(String[] args, int i, String opt) {
        if (i >= args.length) throw new OptionException("Missing argument for option: " + opt);
        return args[i];
    }

    private static void printHelp(java.io.PrintStream out) {
        out.println("usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]");
        out.println("       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]");
        out.println("       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]");
        out.println(" -A,--no-antialias              Turns anti-aliasing off.");
        out.println(" -b,--background <BACKGROUND>   The background colour of the image. The");
        out.println("                                format should be a six-digit hexadecimal");
        out.println("                                number (as in HTML, FF0000 for red). Pass");
        out.println("                                an eight-digit hex to define transparency.");
        out.println("                                This is overridden by --transparent.");
        out.println(" -d,--debug                     Renders the debug grid over the resulting");
        out.println("                                image.");
        out.println(" -E,--no-separation             Prevents the separation of common edges of");
        out.println("                                shapes.");
        out.println(" -e,--encoding <ENCODING>       The encoding of the input file.");
        out.println(" -h,--html                      In this case the input is an HTML file.");
        out.println("                                The contents of the <pre");
        out.println("                                class=\"textdiagram\"> tags are rendered as");
        out.println("                                diagrams and saved in the images directory");
        out.println("                                and a new HTML file is produced with the");
        out.println("                                appropriate <img> tags.");
        out.println("    --help                      Prints usage help.");
        out.println(" -o,--overwrite                 If the filename of the destination image");
        out.println("                                already exists, an alternative name is");
        out.println("                                chosen. If the overwrite option is");
        out.println("                                selected, the image file is instead");
        out.println("                                overwriten.");
        out.println(" -r,--round-corners             Causes all corners to be rendered as round");
        out.println("                                corners.");
        out.println(" -S,--no-shadows                Turns off the drop-shadow effect.");
        out.println(" -s,--scale <SCALE>             A natural number that determines the size");
        out.println("                                of the rendered image. The units are");
        out.println("                                fractions of the default size (2.5 renders");
        out.println("                                1.5 times bigger than the default).");
        out.println("    --svg                       Write an SVG image as destination file.");
        out.println("    --svg-font-url <FONT>       SVG font URL.");
        out.println(" -T,--transparent               Causes the diagram to be rendered on a");
        out.println("                                transparent background. Overrides");
        out.println("                                --background.");
        out.println(" -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces");
        out.println("                                but it is possible to change that using");
        out.println("                                this option. It is not advisable to use");
        out.println("                                tabs in your diagrams.");
        out.println(" -v,--verbose                   Makes ditaa more verbose.");
        out.println(" -W,--fixed-slope               Makes sides of parallelograms and");
        out.println("                                trapezoids fixed slope instead of fixed");
        out.println("                                width.");
    }

    private static void convertHtml(Path input, Path output, Options opt) throws IOException {
        String html = Files.readString(input, Charset.forName(opt.encoding));
        Path base = output.toAbsolutePath().getParent();
        if (base == null) base = Paths.get(".").toAbsolutePath();
        Path images = base.resolve("images");
        Files.createDirectories(images);
        Pattern p = Pattern.compile("(?is)<pre\\b([^>]*)>(.*?)</pre>");
        Matcher m = p.matcher(html);
        StringBuffer sb = new StringBuffer();
        List<String> generated = new ArrayList<>();
        int n = 1;
        while (m.find()) {
            String attrs = m.group(1);
            Matcher classm = Pattern.compile("(?is)\\bclass\\s*=\\s*([\"'])(.*?)\\1").matcher(attrs);
            if (!classm.find() || !List.of(classm.group(2).split("\\s+")).contains("textdiagram")) {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
                continue;
            }
            Matcher idm = Pattern.compile("(?is)\\bid\\s*=\\s*([\"'])(.*?)\\1").matcher(attrs);
            String id = idm.find() ? idm.group(2) : "ditaa_diagram_" + n++;
            String file = id + (opt.svg ? ".svg" : ".png");
            Path img = images.resolve(file);
            String diagramText = unescapeHtml(m.group(2));
            if (opt.overwrite || !Files.exists(img)) {
                Diagram d = Diagram.from(diagramText, opt.tabs);
                if (opt.svg) Files.writeString(img, SvgRenderer.render(d, opt), StandardCharsets.UTF_8);
                else ImageIO.write(RasterRenderer.render(d, opt), "png", img.toFile());
            }
            generated.add(img.toString());
            m.appendReplacement(sb, Matcher.quoteReplacement("<img src=\"images/" + file + "\" />"));
        }
        m.appendTail(sb);
        Files.writeString(output, sb.toString(), StandardCharsets.UTF_8);
        System.out.println("done");
        System.out.println("Generating diagrams... ");
        generated.stream().sorted().forEach(s -> System.out.println("\t" + s));
        System.out.println();
        System.out.println("...done");
    }

    private static String unescapeHtml(String s) {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", "\"");
    }

    static class Options {
        boolean help, html, svg, overwrite, noAntialias, debug, noSeparation, roundCorners;
        boolean noShadows, transparent, verbose, fixedSlope;
        String background = "FFFFFF";
        String encoding = StandardCharsets.UTF_8.name();
        String svgFontUrl;
        double scale = 1.0;
        int tabs = 8;
        String input, output;
    }

    static class OptionException extends RuntimeException {
        OptionException(String message) { super(message); }
    }

    static class Diagram {
        final List<String> lines;
        final int rows, cols;
        final List<Box> boxes;
        final Set<Long> consumed = new HashSet<>();

        Diagram(List<String> lines) {
            this.lines = lines;
            this.rows = lines.size();
            int c = 0;
            for (String line : lines) c = Math.max(c, line.length());
            this.cols = Math.max(1, c);
            this.boxes = findBoxes();
            for (Box b : boxes) markBox(b);
        }

        static Diagram from(String text, int tabs) {
            String[] raw = text.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
            List<String> out = new ArrayList<>();
            int end = raw.length;
            while (end > 0 && raw[end - 1].isEmpty()) end--;
            for (int i = 0; i < Math.max(1, end); i++) out.add(expandTabs(raw[i], tabs));
            return new Diagram(out);
        }

        char ch(int r, int c) {
            if (r < 0 || r >= lines.size()) return ' ';
            String s = lines.get(r);
            return c < s.length() ? s.charAt(c) : ' ';
        }

        boolean consumed(int r, int c) { return consumed.contains((((long) r) << 32) ^ c); }
        void mark(int r, int c) { consumed.add((((long) r) << 32) ^ c); }

        private List<Box> findBoxes() {
            List<Box> found = new ArrayList<>();
            boolean[][] used = new boolean[rows][cols];
            for (int r1 = 0; r1 < rows; r1++) {
                for (int c1 = 0; c1 < cols; c1++) {
                    if (ch(r1, c1) != '+' && ch(r1, c1) != '/' && ch(r1, c1) != '\\') continue;
                    for (int c2 = c1 + 2; c2 < cols; c2++) {
                        if (!isCorner(ch(r1, c2)) || !hline(r1, c1 + 1, c2 - 1)) continue;
                        for (int r2 = r1 + 2; r2 < rows; r2++) {
                            if (!isCorner(ch(r2, c1)) || !isCorner(ch(r2, c2))) continue;
                            if (!hline(r2, c1 + 1, c2 - 1)) continue;
                            if (!vline(c1, r1 + 1, r2 - 1) || !vline(c2, r1 + 1, r2 - 1)) continue;
                            boolean overlap = false;
                            for (int rr = r1; rr <= r2 && !overlap; rr++)
                                for (int cc = c1; cc <= c2; cc++)
                                    if (used[rr][cc] && (rr == r1 || rr == r2 || cc == c1 || cc == c2)) overlap = true;
                            if (!overlap) {
                                Box b = new Box(r1, c1, r2, c2);
                                b.inspect(this);
                                found.add(b);
                                for (int rr = r1; rr <= r2; rr++) {
                                    used[rr][c1] = true; used[rr][c2] = true;
                                }
                                for (int cc = c1; cc <= c2; cc++) {
                                    used[r1][cc] = true; used[r2][cc] = true;
                                }
                            }
                            break;
                        }
                    }
                }
            }
            found.sort(Comparator.comparingInt((Box b) -> (b.r2 - b.r1) * (b.c2 - b.c1)).reversed());
            return found;
        }

        private boolean isCorner(char c) { return c == '+' || c == '/' || c == '\\'; }
        private boolean hline(int r, int c1, int c2) {
            for (int c = c1; c <= c2; c++) if ("-=+".indexOf(ch(r, c)) < 0) return false;
            return true;
        }
        private boolean vline(int c, int r1, int r2) {
            for (int r = r1; r <= r2; r++) if ("|:+".indexOf(ch(r, c)) < 0) return false;
            return true;
        }

        private void markBox(Box b) {
            for (int c = b.c1; c <= b.c2; c++) { mark(b.r1, c); mark(b.r2, c); }
            for (int r = b.r1; r <= b.r2; r++) { mark(r, b.c1); mark(r, b.c2); }
            for (int r = b.r1 + 1; r < b.r2; r++) {
                String row = lines.get(r);
                for (String token : List.of("{d}", "{s}", "{o}", "{mo}", "{c}", "{tr}", "{io}", "cRED", "cGRE", "cBLU", "cPNK", "cYEL", "cBLK")) {
                    int idx = row.indexOf(token);
                    while (idx >= 0) {
                        if (idx > b.c1 && idx + token.length() - 1 < b.c2) {
                            for (int c = idx; c < idx + token.length(); c++) mark(r, c);
                        }
                        idx = row.indexOf(token, idx + 1);
                    }
                }
            }
        }
    }

    static class Box {
        final int r1, c1, r2, c2;
        String kind = "rect";
        Color fill = Color.WHITE;
        Box(int r1, int c1, int r2, int c2) { this.r1 = r1; this.c1 = c1; this.r2 = r2; this.c2 = c2; }
        void inspect(Diagram d) {
            StringBuilder inside = new StringBuilder();
            for (int r = r1 + 1; r < r2; r++) {
                for (int c = c1 + 1; c < c2; c++) inside.append(d.ch(r, c));
                inside.append('\n');
            }
            String s = inside.toString();
            if (s.contains("{d}")) kind = "document";
            else if (s.contains("{s}")) kind = "storage";
            else if (s.contains("{o}")) kind = "ellipse";
            else if (s.contains("{c}")) kind = "choice";
            else if (s.contains("{mo}")) kind = "manual";
            else if (s.contains("{tr}")) kind = "trapezoid";
            else if (s.contains("{io}")) kind = "io";
            Map<String, Color> colors = new HashMap<>();
            colors.put("cRED", new Color(0xff9999));
            colors.put("cGRE", new Color(0x99ff99));
            colors.put("cBLU", new Color(0x9999ff));
            colors.put("cPNK", new Color(0xffccff));
            colors.put("cYEL", new Color(0xffff99));
            colors.put("cBLK", new Color(0x555555));
            for (Map.Entry<String, Color> e : colors.entrySet()) if (s.contains(e.getKey())) fill = e.getValue();
        }
    }

    static class Geometry {
        static final int CELL_W = 10, CELL_H = 14, X0 = 25, Y0 = 35;
        static int width(Diagram d, Options opt) { return (int)Math.ceil((d.cols * CELL_W + 40) * opt.scale); }
        static int height(Diagram d, Options opt) { return (int)Math.ceil((d.rows * CELL_H + 56) * opt.scale); }
        static double x(int c, Options opt) { return (X0 + c * CELL_W) * opt.scale; }
        static double y(int r, Options opt) { return (Y0 + r * CELL_H) * opt.scale; }
        static double tx(int c, Options opt) { return (20 + c * CELL_W) * opt.scale; }
        static double ty(int r, Options opt) { return (40 + r * CELL_H) * opt.scale; }
    }

    static class RasterRenderer {
        static BufferedImage render(Diagram d, Options opt) {
            int type = opt.transparent ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB;
            BufferedImage im = new BufferedImage(Geometry.width(d, opt), Geometry.height(d, opt), type);
            Graphics2D g = im.createGraphics();
            if (!opt.noAntialias) {
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            }
            if (!opt.transparent) {
                g.setColor(parseColor(opt.background, Color.WHITE));
                g.fillRect(0, 0, im.getWidth(), im.getHeight());
            }
            g.scale(opt.scale, opt.scale);
            if (!opt.noShadows) {
                g.setColor(new Color(0, 0, 0, 55));
                for (Box b : d.boxes) drawBox(g, b, true, opt);
            }
            for (Box b : d.boxes) drawBox(g, b, false, opt);
            drawLooseLines(g, d);
            drawText(g, d);
            if (opt.debug) drawDebug(g, d);
            g.dispose();
            return im;
        }

        private static void drawBox(Graphics2D g, Box b, boolean shadow, Options opt) {
            double x1 = Geometry.X0 + b.c1 * Geometry.CELL_W, y1 = Geometry.Y0 + b.r1 * Geometry.CELL_H;
            double x2 = Geometry.X0 + b.c2 * Geometry.CELL_W, y2 = Geometry.Y0 + b.r2 * Geometry.CELL_H;
            if (shadow) { x1 += 5; x2 += 5; y1 += 5; y2 += 5; }
            Path2D p = shapePath(b, x1, y1, x2, y2, opt.roundCorners);
            if (shadow) {
                g.fill(p);
                return;
            }
            g.setColor(b.fill);
            if ("ellipse".equals(b.kind)) g.fill(new Ellipse2D.Double(x1, y1, x2 - x1, y2 - y1));
            else g.fill(p);
            g.setColor(Color.BLACK);
            g.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            if ("ellipse".equals(b.kind)) g.draw(new Ellipse2D.Double(x1, y1, x2 - x1, y2 - y1));
            else g.draw(p);
            if ("storage".equals(b.kind)) {
                g.drawArc((int)x1, (int)y1, (int)(x2 - x1), 12, 0, 360);
                g.drawArc((int)x1, (int)(y2 - 12), (int)(x2 - x1), 12, 0, -180);
            } else if ("document".equals(b.kind)) {
                g.drawArc((int)x1, (int)(y2 - 10), (int)((x2 - x1) / 2), 10, 0, -180);
                g.drawArc((int)(x1 + (x2 - x1) / 2), (int)(y2 - 10), (int)((x2 - x1) / 2), 10, 180, -180);
            }
        }

        private static Path2D shapePath(Box b, double x1, double y1, double x2, double y2, boolean round) {
            Path2D p = new Path2D.Double();
            double w = x2 - x1, h = y2 - y1, sl = Math.min(18, w / 4);
            switch (b.kind) {
                case "choice":
                    p.moveTo((x1 + x2) / 2, y1); p.lineTo(x2, (y1 + y2) / 2); p.lineTo((x1 + x2) / 2, y2); p.lineTo(x1, (y1 + y2) / 2); break;
                case "io":
                    p.moveTo(x1 + sl, y1); p.lineTo(x2, y1); p.lineTo(x2 - sl, y2); p.lineTo(x1, y2); break;
                case "manual":
                    p.moveTo(x1 + sl, y1); p.lineTo(x2, y1); p.lineTo(x2, y2); p.lineTo(x1, y2); break;
                case "trapezoid":
                    p.moveTo(x1 + sl, y1); p.lineTo(x2 - sl, y1); p.lineTo(x2, y2); p.lineTo(x1, y2); break;
                default:
                    if (round) {
                        double r = Math.min(8, Math.min(w, h) / 3);
                        p.moveTo(x1 + r, y1); p.lineTo(x2 - r, y1); p.quadTo(x2, y1, x2, y1 + r);
                        p.lineTo(x2, y2 - r); p.quadTo(x2, y2, x2 - r, y2); p.lineTo(x1 + r, y2);
                        p.quadTo(x1, y2, x1, y2 - r); p.lineTo(x1, y1 + r); p.quadTo(x1, y1, x1 + r, y1);
                    } else {
                        p.moveTo(x1, y1); p.lineTo(x2, y1); p.lineTo(x2, y2); p.lineTo(x1, y2);
                    }
            }
            p.closePath();
            return p;
        }

        private static void drawLooseLines(Graphics2D g, Diagram d) {
            g.setColor(Color.BLACK);
            g.setStroke(new BasicStroke(1.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            for (int r = 0; r < d.rows; r++) {
                for (int c = 0; c < d.cols; c++) {
                    if (d.consumed(r, c)) continue;
                    char ch = d.ch(r, c);
                    double x = Geometry.X0 + c * Geometry.CELL_W, y = Geometry.Y0 + r * Geometry.CELL_H;
                    if (ch == '-' || ch == '=') g.drawLine((int)(x - 5), (int)y, (int)(x + 5), (int)y);
                    else if (ch == '|' || ch == ':') g.drawLine((int)x, (int)(y - 7), (int)x, (int)(y + 7));
                    else if (ch == '/') g.drawLine((int)(x + 5), (int)(y - 7), (int)(x - 5), (int)(y + 7));
                    else if (ch == '\\') g.drawLine((int)(x - 5), (int)(y - 7), (int)(x + 5), (int)(y + 7));
                    else if (ch == '*') { g.fillOval((int)x - 3, (int)y - 3, 6, 6); }
                    else if ("<>^v".indexOf(ch) >= 0) drawArrow(g, ch, x, y);
                }
            }
        }

        private static void drawArrow(Graphics2D g, char ch, double x, double y) {
            Path2D p = new Path2D.Double();
            if (ch == '>') { p.moveTo(x + 5, y); p.lineTo(x - 4, y - 5); p.lineTo(x - 4, y + 5); }
            if (ch == '<') { p.moveTo(x - 5, y); p.lineTo(x + 4, y - 5); p.lineTo(x + 4, y + 5); }
            if (ch == '^') { p.moveTo(x, y - 6); p.lineTo(x - 5, y + 4); p.lineTo(x + 5, y + 4); }
            if (ch == 'v') { p.moveTo(x, y + 6); p.lineTo(x - 5, y - 4); p.lineTo(x + 5, y - 4); }
            p.closePath();
            g.fill(p);
        }

        private static void drawText(Graphics2D g, Diagram d) {
            g.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 15));
            FontMetrics fm = g.getFontMetrics();
            g.setColor(Color.BLACK);
            for (int r = 0; r < d.rows; r++) {
                StringBuilder run = new StringBuilder();
                int start = -1;
                for (int c = 0; c <= d.cols; c++) {
                    char ch = c < d.cols ? d.ch(r, c) : ' ';
                    boolean text = c < d.cols && !d.consumed(r, c) && isTextChar(ch, d, r, c);
                    if (text) {
                        if (start < 0) start = c;
                        run.append(ch == '\u00a0' ? ' ' : ch);
                    } else if (start >= 0) {
                        String s = run.toString().stripTrailing();
                        if (!s.isBlank()) {
                            if (s.startsWith("o ") && (start == 0 || d.ch(r, start - 1) == ' ')) {
                                g.fillOval(Geometry.X0 + start * Geometry.CELL_W - 1, Geometry.Y0 + r * Geometry.CELL_H - 4, 6, 6);
                                s = s.substring(2);
                                g.drawString(s, 20 + (start + 2) * Geometry.CELL_W, 40 + r * Geometry.CELL_H);
                            } else {
                                g.drawString(s, 20 + start * Geometry.CELL_W, 40 + r * Geometry.CELL_H);
                            }
                        }
                        run.setLength(0); start = -1;
                    }
                }
            }
        }

        private static boolean isTextChar(char ch, Diagram d, int r, int c) {
            if (ch == ' ') return false;
            if ("+-=|:/\\<>^v*".indexOf(ch) >= 0) return false;
            return true;
        }

        private static void drawDebug(Graphics2D g, Diagram d) {
            g.setColor(new Color(255, 0, 0, 70));
            for (int c = 0; c <= d.cols; c++) g.drawLine(Geometry.X0 + c * Geometry.CELL_W, 0, Geometry.X0 + c * Geometry.CELL_W, Geometry.height(d, new Options()));
            for (int r = 0; r <= d.rows; r++) g.drawLine(0, Geometry.Y0 + r * Geometry.CELL_H, Geometry.width(d, new Options()), Geometry.Y0 + r * Geometry.CELL_H);
        }
    }

    static class SvgRenderer {
        static String render(Diagram d, Options opt) {
            StringBuilder s = new StringBuilder();
            s.append("<?xml version='1.0' encoding='UTF-8' standalone='no'?>\n");
            s.append("<svg \n    xmlns='http://www.w3.org/2000/svg'\n");
            s.append("    width='").append(Geometry.width(d, opt)).append("'\n");
            s.append("    height='").append(Geometry.height(d, opt)).append("'\n");
            s.append("    shape-rendering='geometricPrecision'\n    version='1.0'>\n");
            if (opt.svgFontUrl != null) {
                s.append("  <defs><style>@font-face{font-family:Courier;src:url('").append(esc(opt.svgFontUrl)).append("')}</style></defs>\n");
            } else {
                s.append("  <defs>\n    <filter id='f2' x='0' y='0' width='200%' height='200%'>\n");
                s.append("      <feOffset result='offOut' in='SourceGraphic' dx='5' dy='5' />\n");
                s.append("      <feGaussianBlur result='blurOut' in='offOut' stdDeviation='3' />\n");
                s.append("      <feBlend in='SourceGraphic' in2='blurOut' mode='normal' />\n    </filter>\n  </defs>\n");
            }
            s.append("  <g stroke-width='1' stroke-linecap='square' stroke-linejoin='round'>\n");
            if (!opt.transparent) s.append("    <rect x='0' y='0' width='").append(Geometry.width(d, opt)).append("' height='").append(Geometry.height(d, opt)).append("' style='fill: ").append(color(parseColor(opt.background, Color.WHITE))).append("'/>\n");
            if (!opt.noShadows) for (Box b : d.boxes) appendBox(s, b, opt, true);
            for (Box b : d.boxes) appendBox(s, b, opt, false);
            appendLooseLines(s, d, opt);
            appendText(s, d, opt);
            s.append("  </g>\n</svg>\n");
            return s.toString();
        }

        private static void appendBox(StringBuilder s, Box b, Options opt, boolean shadow) {
            double x1 = Geometry.x(b.c1, opt), y1 = Geometry.y(b.r1, opt), x2 = Geometry.x(b.c2, opt), y2 = Geometry.y(b.r2, opt);
            if (shadow) {
                s.append("    <path stroke='gray' fill='gray' filter='url(#f2)' d='").append(svgPath(b, x1, y1, x2, y2, opt.roundCorners)).append("' />\n");
            } else {
                s.append("    <path stroke='#000000' stroke-width='").append(fmt(opt.scale)).append("' stroke-linecap='round' stroke-linejoin='round' fill='").append(color(b.fill)).append("' d='").append(svgPath(b, x1, y1, x2, y2, opt.roundCorners)).append("' />\n");
            }
        }

        private static String svgPath(Box b, double x1, double y1, double x2, double y2, boolean round) {
            if ("ellipse".equals(b.kind)) {
                double rx = (x2 - x1) / 2, ry = (y2 - y1) / 2, cx = x1 + rx, cy = y1 + ry;
                return "M" + fmt(cx - rx) + " " + fmt(cy) + " A" + fmt(rx) + " " + fmt(ry) + " 0 1 0 " + fmt(cx + rx) + " " + fmt(cy) + " A" + fmt(rx) + " " + fmt(ry) + " 0 1 0 " + fmt(cx - rx) + " " + fmt(cy) + " z";
            }
            double sl = Math.min(18, (x2 - x1) / 4);
            List<double[]> pts = new ArrayList<>();
            switch (b.kind) {
                case "choice": pts.add(new double[]{(x1+x2)/2,y1}); pts.add(new double[]{x2,(y1+y2)/2}); pts.add(new double[]{(x1+x2)/2,y2}); pts.add(new double[]{x1,(y1+y2)/2}); break;
                case "io": pts.add(new double[]{x1+sl,y1}); pts.add(new double[]{x2,y1}); pts.add(new double[]{x2-sl,y2}); pts.add(new double[]{x1,y2}); break;
                case "manual": pts.add(new double[]{x1+sl,y1}); pts.add(new double[]{x2,y1}); pts.add(new double[]{x2,y2}); pts.add(new double[]{x1,y2}); break;
                case "trapezoid": pts.add(new double[]{x1+sl,y1}); pts.add(new double[]{x2-sl,y1}); pts.add(new double[]{x2,y2}); pts.add(new double[]{x1,y2}); break;
                default: pts.add(new double[]{x1,y1}); pts.add(new double[]{x2,y1}); pts.add(new double[]{x2,y2}); pts.add(new double[]{x1,y2});
            }
            StringBuilder p = new StringBuilder("M").append(fmt(pts.get(0)[0])).append(" ").append(fmt(pts.get(0)[1]));
            for (int i = 1; i < pts.size(); i++) p.append(" L").append(fmt(pts.get(i)[0])).append(" ").append(fmt(pts.get(i)[1]));
            p.append(" z");
            return p.toString();
        }

        private static void appendLooseLines(StringBuilder s, Diagram d, Options opt) {
            for (int r = 0; r < d.rows; r++) for (int c = 0; c < d.cols; c++) {
                if (d.consumed(r, c)) continue;
                char ch = d.ch(r, c);
                double x = Geometry.x(c, opt), y = Geometry.y(r, opt);
                if (ch == '-' || ch == '=') line(s, x - 5 * opt.scale, y, x + 5 * opt.scale, y, ch == '=');
                else if (ch == '|' || ch == ':') line(s, x, y - 7 * opt.scale, x, y + 7 * opt.scale, ch == ':');
                else if (ch == '/') line(s, x + 5 * opt.scale, y - 7 * opt.scale, x - 5 * opt.scale, y + 7 * opt.scale, false);
                else if (ch == '\\') line(s, x - 5 * opt.scale, y - 7 * opt.scale, x + 5 * opt.scale, y + 7 * opt.scale, false);
                else if (ch == '*') s.append("    <circle cx='").append(fmt(x)).append("' cy='").append(fmt(y)).append("' r='3' fill='#000000'/>\n");
                else if ("<>^v".indexOf(ch) >= 0) s.append("    <text x='").append(fmt(x - 4)).append("' y='").append(fmt(y + 5)).append("' font-family='Courier' font-size='15' stroke='none' fill='#000000'>").append(ch).append("</text>\n");
            }
        }

        private static void line(StringBuilder s, double x1, double y1, double x2, double y2, boolean dash) {
            s.append("    <line x1='").append(fmt(x1)).append("' y1='").append(fmt(y1)).append("' x2='").append(fmt(x2)).append("' y2='").append(fmt(y2)).append("' stroke='#000000' stroke-width='1'");
            if (dash) s.append(" stroke-dasharray='4,4'");
            s.append("/>\n");
        }

        private static void appendText(StringBuilder s, Diagram d, Options opt) {
            for (int r = 0; r < d.rows; r++) {
                StringBuilder run = new StringBuilder();
                int start = -1;
                for (int c = 0; c <= d.cols; c++) {
                    char ch = c < d.cols ? d.ch(r, c) : ' ';
                    boolean text = c < d.cols && !d.consumed(r, c) && ch != ' ' && "+-=|:/\\<>^v*".indexOf(ch) < 0;
                    if (text) {
                        if (start < 0) start = c;
                        run.append(ch);
                    } else if (start >= 0) {
                        String txt = run.toString().stripTrailing();
                        if (!txt.isBlank()) {
                            s.append("    <text x='").append((int)Geometry.tx(start, opt)).append("' y='").append((int)Geometry.ty(r, opt)).append("' font-family='Courier' font-size='").append((int)(15 * opt.scale)).append("' stroke='none' fill='#000000' ><![CDATA[").append(txt.replace("]]>", "]]]]><![CDATA[>")).append("]]></text>\n");
                        }
                        run.setLength(0); start = -1;
                    }
                }
            }
        }

        private static String esc(String x) { return x.replace("&", "&amp;").replace("'", "&apos;").replace("<", "&lt;"); }
        private static String fmt(double d) { return String.format(Locale.ROOT, "%.1f", d); }
    }

    private static String expandTabs(String s, int tabs) {
        StringBuilder b = new StringBuilder();
        int col = 0;
        for (char ch : s.toCharArray()) {
            if (ch == '\t') {
                int n = tabs - (col % tabs);
                b.append(" ".repeat(Math.max(1, n)));
                col += n;
            } else {
                b.append(ch);
                col++;
            }
        }
        return b.toString();
    }

    private static Color parseColor(String value, Color fallback) {
        if (value == null) return fallback;
        String v = value.startsWith("#") ? value.substring(1) : value;
        try {
            long n = Long.parseLong(v, 16);
            if (v.length() == 8) return new Color((int)((n >> 16) & 255), (int)((n >> 8) & 255), (int)(n & 255), (int)((n >> 24) & 255));
            if (v.length() == 6) return new Color((int)((n >> 16) & 255), (int)((n >> 8) & 255), (int)(n & 255));
        } catch (NumberFormatException ignored) { }
        return fallback;
    }

    private static String color(Color c) {
        return String.format("#%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue());
    }
}
