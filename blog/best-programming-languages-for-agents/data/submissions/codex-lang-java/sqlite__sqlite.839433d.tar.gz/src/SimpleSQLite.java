import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class SimpleSQLite {
    static final String VERSION = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)";
    static final String JDBC = "jdbc:sqlite:";
    static final String HELP = """
Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive
""";

    enum Mode { LIST, CSV, COLUMN, TABLE, LINE, QUOTE, HTML, JSON, TABS, ASCII, MARKDOWN, BOX }
    Connection conn;
    Mode mode = Mode.LIST;
    boolean headers = false, bail = false, echo = false;
    String colSep = "|", rowSep = "\n", nullValue = "";
    PrintStream out = System.out;
    int errors = 0;

    public static void main(String[] args) {
        int rc = new SimpleSQLite().run(args);
        if (rc != 0) System.exit(rc);
    }

    int run(String[] args) {
        List<String> pre = new ArrayList<>(), sqlArgs = new ArrayList<>();
        String db = ":memory:";
        boolean dbSet = false, endOpts = false, readStdin = true;
        try {
            for (int i = 0; i < args.length; i++) {
                String a = args[i];
                if (!endOpts && a.equals("--")) { endOpts = true; continue; }
                if (!endOpts && a.startsWith("-")) {
                    switch (a) {
                        case "-help": case "--help": System.out.print(HELP); return 0;
                        case "-version": case "--version": System.out.println(VERSION); return 0;
                        case "-bail": bail = true; break;
                        case "-batch": case "-interactive": case "-noinit": case "-safe":
                        case "-unsafe-testing": case "-append": case "-deserialize":
                        case "-nofollow": case "-no-rowid-in-view": case "-memtrace":
                        case "-pcachetrace": case "-stats": case "-vfstrace": case "-zip": break;
                        case "-echo": echo = true; break;
                        case "-header": case "-headers": headers = true; break;
                        case "-noheader": case "-noheaders": headers = false; break;
                        case "-list": mode = Mode.LIST; break;
                        case "-csv": mode = Mode.CSV; colSep = ","; rowSep = "\r\n"; break;
                        case "-column": mode = Mode.COLUMN; break;
                        case "-table": mode = Mode.TABLE; break;
                        case "-box": mode = Mode.BOX; break;
                        case "-line": mode = Mode.LINE; break;
                        case "-quote": mode = Mode.QUOTE; break;
                        case "-html": mode = Mode.HTML; break;
                        case "-json": mode = Mode.JSON; break;
                        case "-tabs": mode = Mode.TABS; colSep = "\t"; break;
                        case "-ascii": mode = Mode.ASCII; colSep = "\u001f"; rowSep = "\u001e"; break;
                        case "-markdown": mode = Mode.MARKDOWN; break;
                        case "-cmd": pre.add(require(args, ++i, a)); break;
                        case "-init": pre.add(readFile(require(args, ++i, a))); break;
                        case "-separator": colSep = decode(require(args, ++i, a)); break;
                        case "-newline": rowSep = decode(require(args, ++i, a)); break;
                        case "-nullvalue": nullValue = require(args, ++i, a); break;
                        case "-mmap": case "-maxsize": case "-nonce": case "-vfs":
                        case "-screenwidth": case "-escape": i++; break;
                        case "-lookaside": case "-pagecache": i += 2; break;
                        case "-readonly":
                            pre.add("PRAGMA query_only=ON;");
                            break;
                        case "-ifexists":
                            break;
                        default:
                            System.err.println("./executable: Error: unknown option: " + a);
                            System.err.println("Use -help for a list of options.");
                            return 1;
                    }
                } else if (!dbSet) {
                    db = a; dbSet = true;
                } else {
                    sqlArgs.add(a); readStdin = false;
                }
            }
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection(JDBC + db);
            for (String s : pre) processScript(s, "command-line option");
            if (!sqlArgs.isEmpty()) {
                for (int i = 0; i < sqlArgs.size(); i++) processScript(sqlArgs.get(i), ordinal(i + 2) + " command line argument");
            } else if (readStdin) {
                processScript(new String(System.in.readAllBytes(), StandardCharsets.UTF_8), "stdin");
            }
        } catch (Exception e) {
            error("Error: " + e.getMessage());
        } finally {
            try { if (conn != null) conn.close(); } catch (Exception ignored) {}
        }
        return errors == 0 ? 0 : 1;
    }

    static String require(String[] args, int i, String opt) {
        if (i >= args.length) throw new IllegalArgumentException("option requires an argument: " + opt);
        return args[i];
    }

    static String readFile(String f) throws IOException {
        return Files.readString(Path.of(f));
    }

    void processScript(String script, String source) {
        StringBuilder sql = new StringBuilder();
        for (String raw : script.split("\\R", -1)) {
            String line = raw;
            if (echo && !line.isEmpty()) out.println(line);
            String trim = line.trim();
            if (sql.length() == 0 && trim.startsWith(".")) {
                if (!dot(trim)) { if (bail) return; }
                continue;
            }
            sql.append(line).append('\n');
            if (complete(sql.toString())) {
                for (String st : splitStatements(sql.toString())) execSql(st, source);
                sql.setLength(0);
                if (bail && errors > 0) return;
            }
        }
        if (sql.toString().trim().length() > 0) execSql(sql.toString(), source);
    }

    boolean dot(String line) {
        List<String> a = shellWords(line);
        if (a.isEmpty()) return true;
        String cmd = a.get(0);
        try {
            switch (cmd) {
                case ".quit": case ".exit":
                    System.exit(a.size() > 1 ? Integer.parseInt(a.get(1)) : 0);
                    return true;
                case ".help": printDotHelp(); return true;
                case ".headers": case ".header": if (a.size() > 1) headers = on(a.get(1)); else out.println(headers ? "on" : "off"); return true;
                case ".mode":
                    if (a.size() == 1) { out.println("current output mode: " + mode.name().toLowerCase()); return true; }
                    setMode(a.get(1)); return true;
                case ".separator": if (a.size() > 1) colSep = decode(a.get(1)); if (a.size() > 2) rowSep = decode(a.get(2)); return true;
                case ".nullvalue": nullValue = a.size() > 1 ? a.get(1) : ""; return true;
                case ".print": out.println(String.join(" ", a.subList(1, a.size()))); return true;
                case ".version": out.println("SQLite " + VERSION); return true;
                case ".read": processScript(readFile(a.get(1)), a.get(1)); return true;
                case ".once": case ".output":
                    if (a.size() == 1 || a.get(1).equals("stdout")) out = System.out;
                    else out = new PrintStream(new FileOutputStream(a.get(1)), true, StandardCharsets.UTF_8);
                    return true;
                case ".open":
                    if (conn != null) conn.close();
                    String db = a.size() > 1 ? a.get(a.size() - 1) : ":memory:";
                    conn = DriverManager.getConnection(JDBC + db);
                    return true;
                case ".tables": tables(a.size() > 1 ? a.get(1) : null); return true;
                case ".schema": schema(a.size() > 1 ? a.get(1) : null); return true;
                case ".indexes": indexes(a.size() > 1 ? a.get(1) : null); return true;
                case ".databases": queryDirect("PRAGMA database_list;"); return true;
                case ".dump": dump(); return true;
                case ".changes": case ".timer": case ".echo": case ".bail":
                    if (cmd.equals(".echo") && a.size() > 1) echo = on(a.get(1));
                    if (cmd.equals(".bail") && a.size() > 1) bail = on(a.get(1));
                    return true;
                default:
                    System.err.println("Error: unknown command or invalid arguments:  \"" + cmd + "\". Enter \".help\" for help");
                    errors++; return false;
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            errors++; return false;
        }
    }

    void setMode(String m) {
        switch (m.toLowerCase(Locale.ROOT)) {
            case "list": mode = Mode.LIST; break;
            case "csv": mode = Mode.CSV; colSep = ","; rowSep = "\r\n"; break;
            case "column": mode = Mode.COLUMN; break;
            case "table": mode = Mode.TABLE; break;
            case "line": mode = Mode.LINE; break;
            case "quote": mode = Mode.QUOTE; break;
            case "html": mode = Mode.HTML; break;
            case "json": mode = Mode.JSON; break;
            case "tabs": mode = Mode.TABS; colSep = "\t"; break;
            case "ascii": mode = Mode.ASCII; colSep = "\u001f"; rowSep = "\u001e"; break;
            case "markdown": mode = Mode.MARKDOWN; break;
            case "box": mode = Mode.BOX; break;
            default: throw new IllegalArgumentException("mode should be one of: ascii box column csv html insert json line list markdown quote table tabs tcl");
        }
    }

    void execSql(String sql, String source) {
        sql = sql.trim();
        if (sql.isEmpty()) return;
        try (Statement st = conn.createStatement()) {
            boolean has = st.execute(sql);
            while (true) {
                if (has) printResult(st.getResultSet());
                else {
                    int c = st.getUpdateCount();
                    if (c == -1) break;
                }
                has = st.getMoreResults();
            }
        } catch (SQLException e) {
            System.err.println("Parse error in " + source + ": " + sqlMessage(e));
            errors++;
        }
    }

    void queryDirect(String sql) throws SQLException {
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) { printResult(rs); }
    }

    void printResult(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int n = md.getColumnCount();
        List<String> names = new ArrayList<>();
        for (int i = 1; i <= n; i++) names.add(md.getColumnLabel(i));
        if (mode == Mode.QUOTE) {
            printQuoteResult(rs, names);
            return;
        }
        List<List<String>> rows = new ArrayList<>();
        while (rs.next()) {
            List<String> r = new ArrayList<>();
            for (int i = 1; i <= n; i++) r.add(value(rs, i));
            rows.add(r);
        }
        switch (mode) {
            case LINE -> printLine(names, rows);
            case COLUMN -> printColumn(names, rows, false);
            case TABLE -> printTable(names, rows, '+', '-', '|');
            case MARKDOWN -> printMarkdown(names, rows);
            case BOX -> printTable(names, rows, '+', '-', '|');
            case CSV -> printCsv(names, rows);
            case HTML -> printHtml(names, rows);
            case JSON -> printJson(names, rows);
            default -> printList(names, rows);
        }
    }

    String value(ResultSet rs, int i) throws SQLException {
        Object o = rs.getObject(i);
        if (o == null) return nullValue;
        if (o instanceof byte[] b) return "X'" + hex(b) + "'";
        return rs.getString(i);
    }

    void printList(List<String> names, List<List<String>> rows) {
        if (headers) out.print(String.join(colSep, names) + rowSep);
        for (List<String> r : rows) out.print(String.join(colSep, r) + rowSep);
    }

    void printCsv(List<String> names, List<List<String>> rows) {
        if (headers) out.print(csvLine(names));
        for (List<String> r : rows) out.print(csvLine(r));
    }

    String csvLine(List<String> r) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < r.size(); i++) {
            if (i > 0) b.append(',');
            String s = r.get(i);
            boolean q = s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r");
            if (q) b.append('"').append(s.replace("\"", "\"\"")).append('"'); else b.append(s);
        }
        return b.append("\r\n").toString();
    }

    void printQuoteResult(ResultSet rs, List<String> names) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int n = md.getColumnCount();
        if (headers) {
            for (int i = 0; i < names.size(); i++) {
                if (i > 0) out.print(",");
                out.print(lit(names.get(i)));
            }
            out.println();
        }
        while (rs.next()) {
            for (int i = 1; i <= n; i++) {
                if (i > 1) out.print(",");
                out.print(sqlLiteral(rs.getObject(i)));
            }
            out.println();
        }
    }

    void printQuote(List<List<String>> rows) {
        for (List<String> r : rows) {
            for (int i = 0; i < r.size(); i++) {
                if (i > 0) out.print(",");
                String s = r.get(i);
                if (s.equals(nullValue) && nullValue.isEmpty()) out.print("NULL");
                else out.print("'" + s.replace("'", "''") + "'");
            }
            out.println();
        }
    }

    void printLine(List<String> names, List<List<String>> rows) {
        int w = 0; for (String s : names) w = Math.max(w, s.length());
        for (int row = 0; row < rows.size(); row++) {
            List<String> r = rows.get(row);
            for (int i = 0; i < names.size(); i++) out.printf("%" + w + "s: %s%n", names.get(i), r.get(i));
            if (row + 1 < rows.size()) out.println();
        }
    }

    void printColumn(List<String> names, List<List<String>> rows, boolean boxed) {
        int n = names.size();
        int[] w = widths(names, rows);
        if (headers) {
            for (int i = 0; i < n; i++) out.print(pad(names.get(i), w[i]) + (i == n - 1 ? "" : "  "));
            out.println();
            for (int i = 0; i < n; i++) out.print("-".repeat(w[i]) + (i == n - 1 ? "" : "  "));
            out.println();
        }
        for (List<String> r : rows) {
            for (int i = 0; i < n; i++) out.print(columnCell(r.get(i), w[i], i == n - 1) + (i == n - 1 ? "" : "  "));
            out.println();
        }
    }

    void printTable(List<String> names, List<List<String>> rows, char corner, char h, char v) {
        int[] w = widths(names, rows);
        border(w, corner, h);
        out.print(v); for (int i = 0; i < names.size(); i++) out.print(" " + pad(names.get(i), w[i]) + " " + v); out.println();
        border(w, corner, h);
        for (List<String> r : rows) { out.print(v); for (int i = 0; i < r.size(); i++) out.print(" " + pad(r.get(i), w[i]) + " " + v); out.println(); }
        border(w, corner, h);
    }

    void printMarkdown(List<String> names, List<List<String>> rows) {
        int[] w = widths(names, rows);
        out.print("|"); for (int i = 0; i < names.size(); i++) out.print(" " + pad(names.get(i), w[i]) + " |"); out.println();
        out.print("|"); for (int x : w) out.print(" " + "-".repeat(x) + " |"); out.println();
        for (List<String> r : rows) { out.print("|"); for (int i = 0; i < r.size(); i++) out.print(" " + pad(r.get(i), w[i]) + " |"); out.println(); }
    }

    void printHtml(List<String> names, List<List<String>> rows) {
        if (headers) { out.print("<TR>"); for (String s : names) out.print("<TH>" + esc(s) + "</TH>"); out.println("</TR>"); }
        for (List<String> r : rows) { out.print("<TR>"); for (String s : r) out.print("<TD>" + esc(s) + "</TD>"); out.println("</TR>"); }
    }

    void printJson(List<String> names, List<List<String>> rows) {
        out.println("[");
        for (int r = 0; r < rows.size(); r++) {
            out.print("{");
            for (int i = 0; i < names.size(); i++) {
                if (i > 0) out.print(",");
                out.print("\"" + json(names.get(i)) + "\":\"" + json(rows.get(r).get(i)) + "\"");
            }
            out.print("}");
            out.println(r == rows.size() - 1 ? "" : ",");
        }
        out.println("]");
    }

    int[] widths(List<String> names, List<List<String>> rows) {
        int[] w = new int[names.size()];
        for (int i = 0; i < names.size(); i++) w[i] = Math.max(1, names.get(i).length());
        for (List<String> r : rows) for (int i = 0; i < r.size(); i++) w[i] = Math.max(w[i], r.get(i).length());
        return w;
    }

    void border(int[] w, char c, char h) { out.print(c); for (int x : w) out.print(String.valueOf(h).repeat(x + 2) + c); out.println(); }
    static String pad(String s, int w) { return s + " ".repeat(Math.max(0, w - s.length())); }
    static String columnCell(String s, int w, boolean last) {
        boolean num = s.matches("[-+]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:[eE][-+]?\\d+)?");
        if (num) return " ".repeat(Math.max(0, w - s.length())) + s;
        return last ? s : pad(s, w);
    }

    void tables(String pat) throws SQLException {
        String sql = "SELECT name FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%'" + (pat == null ? "" : " AND name LIKE " + lit(pat)) + " ORDER BY 1";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            List<String> names = new ArrayList<>(); while (rs.next()) names.add(rs.getString(1));
            out.println(String.join(" ", names));
        }
    }

    void indexes(String pat) throws SQLException {
        String sql = "SELECT name FROM sqlite_schema WHERE type='index'" + (pat == null ? "" : " AND tbl_name LIKE " + lit(pat)) + " ORDER BY 1";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) { while (rs.next()) out.println(rs.getString(1)); }
    }

    void schema(String pat) throws SQLException {
        String sql = "SELECT sql FROM sqlite_schema WHERE sql NOT NULL" + (pat == null ? "" : " AND name LIKE " + lit(pat)) + " ORDER BY tbl_name, type DESC, name";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) { while (rs.next()) out.println(rs.getString(1) + ";"); }
    }

    void dump() throws SQLException {
        out.println("PRAGMA foreign_keys=OFF;");
        out.println("BEGIN TRANSACTION;");
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT name, sql FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")) {
            while (rs.next()) {
                String table = rs.getString(1);
                out.println(rs.getString(2) + ";");
                dumpTable(table);
            }
        }
        out.println("COMMIT;");
    }

    void dumpTable(String table) throws SQLException {
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM " + quoteIdent(table))) {
            ResultSetMetaData md = rs.getMetaData();
            int n = md.getColumnCount();
            while (rs.next()) {
                out.print("INSERT INTO " + quoteIdent(table) + " VALUES(");
                for (int i = 1; i <= n; i++) { if (i > 1) out.print(","); out.print(sqlLiteral(rs.getObject(i))); }
                out.println(");");
            }
        }
    }

    static boolean complete(String s) {
        boolean sq = false, dq = false, line = false, block = false; char prev = 0; boolean semi = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i), nx = i + 1 < s.length() ? s.charAt(i + 1) : 0;
            if (line) { if (c == '\n') line = false; continue; }
            if (block) { if (c == '*' && nx == '/') { block = false; i++; } continue; }
            if (!sq && !dq && c == '-' && nx == '-') { line = true; i++; continue; }
            if (!sq && !dq && c == '/' && nx == '*') { block = true; i++; continue; }
            if (!dq && c == '\'' && prev != '\\') { if (sq && nx == '\'') i++; else sq = !sq; }
            else if (!sq && c == '"') dq = !dq;
            else if (!sq && !dq && c == ';') semi = true;
            else if (!Character.isWhitespace(c)) semi = false;
            prev = c;
        }
        return semi && !sq && !dq && !block;
    }

    static List<String> splitStatements(String s) {
        List<String> out = new ArrayList<>(); StringBuilder b = new StringBuilder();
        boolean sq = false, dq = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i), nx = i + 1 < s.length() ? s.charAt(i + 1) : 0;
            b.append(c);
            if (!dq && c == '\'') { if (sq && nx == '\'') b.append(s.charAt(++i)); else sq = !sq; }
            else if (!sq && c == '"') dq = !dq;
            else if (!sq && !dq && c == ';') { out.add(b.toString()); b.setLength(0); }
        }
        if (b.toString().trim().length() > 0) out.add(b.toString());
        return out;
    }

    static List<String> shellWords(String s) {
        List<String> r = new ArrayList<>(); StringBuilder b = new StringBuilder();
        boolean q = false; char qc = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (q) { if (c == qc) q = false; else b.append(c); }
            else if (c == '\'' || c == '"') { q = true; qc = c; }
            else if (Character.isWhitespace(c)) { if (b.length() > 0) { r.add(b.toString()); b.setLength(0); } }
            else b.append(c);
        }
        if (b.length() > 0) r.add(b.toString());
        return r;
    }

    static boolean on(String s) { return s.equalsIgnoreCase("on") || s.equals("1") || s.equalsIgnoreCase("yes") || s.equalsIgnoreCase("true"); }
    static String decode(String s) { return s.replace("\\n", "\n").replace("\\t", "\t").replace("\\r", "\r"); }
    static String lit(String s) { return "'" + s.replace("'", "''") + "'"; }
    static String quoteIdent(String s) { return "\"" + s.replace("\"", "\"\"") + "\""; }
    static String sqlLiteral(Object o) {
        if (o == null) return "NULL";
        if (o instanceof Number) return o.toString();
        if (o instanceof byte[] b) return "X'" + hex(b) + "'";
        return lit(o.toString());
    }
    static String hex(byte[] b) { StringBuilder x = new StringBuilder(); for (byte v : b) x.append(String.format("%02x", v)); return x.toString(); }
    static String esc(String s) { return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
    static String json(String s) { return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t"); }
    static String sqlMessage(SQLException e) {
        String m = e.getMessage();
        int p = m.lastIndexOf('(');
        if (m.startsWith("[SQLITE_") && p >= 0 && m.endsWith(")")) return m.substring(p + 1, m.length() - 1);
        return m;
    }
    static String ordinal(int n) {
        if (n % 100 >= 11 && n % 100 <= 13) return n + "th";
        return n + switch (n % 10) { case 1 -> "st"; case 2 -> "nd"; case 3 -> "rd"; default -> "th"; };
    }
    void error(String s) { System.err.println("./executable: " + s); errors++; }

    void printDotHelp() {
        out.print("""
.archive ...             Manage SQL archives
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.databases               List names and files of attached databases
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.exit ?CODE?             Exit this program with return-code CODE
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.mode ?MODE? ?OPTIONS?   Set output mode
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.print STRING...         Print literal STRING
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.separator COL ?ROW?     Change the column and row separators
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.timer on|off            Turn SQL timer on or off.
.version                 Show source, library and compiler versions
""");
    }
}
