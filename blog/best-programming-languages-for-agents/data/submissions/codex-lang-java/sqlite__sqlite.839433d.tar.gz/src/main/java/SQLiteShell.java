import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class SQLiteShell {
    enum Mode { LIST, CSV, TABS, COLUMN, TABLE, LINE, QUOTE, JSON, HTML, MARKDOWN, BOX, ASCII }

    private Mode mode = Mode.LIST;
    private boolean headers = false;
    private boolean bail = false;
    private boolean echo = false;
    private String colSep = "|";
    private String rowSep = "\n";
    private String nullValue = "";
    private Connection db;
    private String dbFile = ":memory:";
    private final PrintWriter out = new PrintWriter(System.out, true);
    private int exitCode = 0;

    public static void main(String[] args) {
        int code = new SQLiteShell().run(args);
        System.exit(code);
    }

    private int run(String[] args) {
        try {
            Class.forName("org.sqlite.JDBC");
            List<String> commands = new ArrayList<>();
            List<String> positional = parseArgs(args, commands);
            if (positional == null) return exitCode;

            if (!positional.isEmpty()) {
                dbFile = positional.remove(0);
            }
            openDb(dbFile, false);

            for (String c : commands) {
                processInput(c + "\n", "<cmd>");
                if (bail && exitCode != 0) return exitCode;
            }

            if (!positional.isEmpty()) {
                executeScript(String.join(" ", positional), 1);
            } else {
                StringBuilder sb = new StringBuilder();
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append('\n');
                processInput(sb.toString(), "stdin");
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return 1;
        }
        return exitCode;
    }

    private List<String> parseArgs(String[] args, List<String> commands) {
        List<String> rest = new ArrayList<>();
        boolean opts = true;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (opts && "--".equals(a)) {
                opts = false;
                continue;
            }
            if (opts && a.startsWith("-") && rest.isEmpty()) {
                switch (a) {
                    case "-help":
                    case "--help":
                        printHelp();
                        return null;
                    case "-version":
                    case "--version":
                        System.out.println("3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)");
                        return null;
                    case "-header":
                    case "--header":
                        break;
                    case "-noheader":
                    case "--noheader":
                        break;
                    case "-bail":
                    case "--bail":
                        bail = true;
                        break;
                    case "-echo":
                    case "--echo":
                        echo = true;
                        break;
                    case "-csv": mode = Mode.CSV; break;
                    case "-list": mode = Mode.LIST; break;
                    case "-tabs": mode = Mode.TABS; colSep = "\t"; break;
                    case "-column": mode = Mode.COLUMN; break;
                    case "-table": mode = Mode.TABLE; break;
                    case "-line": mode = Mode.LINE; break;
                    case "-quote": mode = Mode.QUOTE; break;
                    case "-json": mode = Mode.JSON; break;
                    case "-html": mode = Mode.HTML; break;
                    case "-markdown": mode = Mode.MARKDOWN; break;
                    case "-box": mode = Mode.BOX; break;
                    case "-ascii": mode = Mode.ASCII; colSep = "\u001f"; rowSep = "\u001e\n"; break;
                    case "-batch": case "--batch": case "-interactive": case "-noinit":
                    case "-safe": case "-unsafe-testing": case "-readonly": case "-ifexists":
                    case "-deserialize": case "-append": case "-nofollow":
                        break;
                    case "-cmd":
                    case "--cmd":
                        if (++i >= args.length) return missing(a);
                        commands.add(args[i]);
                        break;
                    case "-separator":
                    case "--separator":
                        if (++i >= args.length) return missing(a);
                        colSep = decodeSep(args[i]);
                        break;
                    case "-newline":
                    case "--newline":
                        if (++i >= args.length) return missing(a);
                        rowSep = decodeSep(args[i]);
                        break;
                    case "-nullvalue":
                    case "--nullvalue":
                        if (++i >= args.length) return missing(a);
                        nullValue = args[i];
                        break;
                    case "-init": case "--init": case "-vfs": case "-mmap": case "-maxsize":
                    case "-screenwidth": case "-nonce":
                        if (++i >= args.length) return missing(a);
                        break;
                    case "-lookaside": case "-pagecache":
                        if (i + 2 >= args.length) return missing(a);
                        i += 2;
                        break;
                    case "-A":
                        System.err.println("Error: unknown command or unsupported option: -A");
                        exitCode = 1;
                        return null;
                    default:
                        System.err.println("Error: unknown option: " + a);
                        System.err.println("Use -help for a list of options.");
                        exitCode = 1;
                        return null;
                }
            } else {
                rest.add(a);
                opts = false;
            }
        }
        return rest;
    }

    private List<String> missing(String opt) {
        System.err.println("Error: " + opt + " requires an argument");
        exitCode = 1;
        return null;
    }

    private void openDb(String file, boolean readonly) throws SQLException {
        if (db != null) db.close();
        String url;
        if (":memory:".equals(file)) {
            url = "jdbc:sqlite::memory:";
        } else {
            url = "jdbc:sqlite:" + file;
        }
        db = DriverManager.getConnection(url);
    }

    private void processInput(String text, String source) throws Exception {
        StringBuilder sql = new StringBuilder();
        int lineNo = 0;
        for (String line : text.split("\\R", -1)) {
            lineNo++;
            if (lineNo == text.split("\\R", -1).length && line.isEmpty()) break;
            if (sql.length() == 0 && line.startsWith(".")) {
                if (echo) out.println(line);
                dotCommand(line);
                if (bail && exitCode != 0) return;
                continue;
            }
            sql.append(line).append('\n');
            List<String> complete = takeCompleteStatements(sql);
            for (String stmt : complete) {
                if (echo) out.println(stmt.trim());
                executeStatement(stmt, lineNo);
                if (bail && exitCode != 0) return;
            }
        }
        if (sql.toString().trim().length() > 0) {
            executeStatement(sql.toString(), lineNo);
        }
    }

    private void executeScript(String script, int lineNo) {
        StringBuilder sb = new StringBuilder(script);
        for (String stmt : takeAllStatements(sb)) {
            executeStatement(stmt, lineNo);
            if (bail && exitCode != 0) return;
        }
        if (sb.toString().trim().length() > 0) executeStatement(sb.toString(), lineNo);
    }

    private void executeStatement(String sql, int lineNo) {
        sql = sql.trim();
        if (sql.isEmpty()) return;
        try (Statement st = db.createStatement()) {
            boolean has = st.execute(sql);
            while (true) {
                if (has) {
                    printResult(st.getResultSet());
                }
                if (!st.getMoreResults() && st.getUpdateCount() == -1) break;
                has = st.getUpdateCount() == -1;
            }
        } catch (SQLException e) {
            System.err.println("Parse error near line " + Math.max(1, lineNo) + ": " + e.getMessage());
            exitCode = 1;
        }
    }

    private List<String> takeCompleteStatements(StringBuilder sb) {
        List<String> res = new ArrayList<>();
        int start = 0;
        char quote = 0;
        boolean lineComment = false, blockComment = false;
        for (int i = 0; i < sb.length(); i++) {
            char c = sb.charAt(i);
            char n = i + 1 < sb.length() ? sb.charAt(i + 1) : 0;
            if (lineComment) {
                if (c == '\n') lineComment = false;
                continue;
            }
            if (blockComment) {
                if (c == '*' && n == '/') { blockComment = false; i++; }
                continue;
            }
            if (quote != 0) {
                if (c == quote) {
                    if (n == quote) i++;
                    else quote = 0;
                }
                continue;
            }
            if (c == '-' && n == '-') { lineComment = true; i++; continue; }
            if (c == '/' && n == '*') { blockComment = true; i++; continue; }
            if (c == '\'' || c == '"' || c == '`') { quote = c; continue; }
            if (c == ';') {
                res.add(sb.substring(start, i + 1));
                start = i + 1;
            }
        }
        if (start > 0) sb.delete(0, start);
        return res;
    }

    private List<String> takeAllStatements(StringBuilder sb) {
        return takeCompleteStatements(sb);
    }

    private void dotCommand(String line) throws Exception {
        List<String> p = splitWords(line.trim());
        String cmd = p.isEmpty() ? "" : p.get(0).toLowerCase(Locale.ROOT);
        if (cmd.startsWith(".quit") || cmd.startsWith(".exit")) {
            System.exit(p.size() > 1 ? Integer.parseInt(p.get(1)) : 0);
        } else if (cmd.equals(".help")) {
            printDotHelp();
        } else if (cmd.equals(".headers") || cmd.equals(".header")) {
            if (p.size() > 1) headers = isOn(p.get(1));
            else out.println(headers ? "on" : "off");
        } else if (cmd.equals(".mode")) {
            if (p.size() > 1) setMode(p.get(1));
            else out.println(mode.name().toLowerCase(Locale.ROOT));
        } else if (cmd.equals(".separator")) {
            if (p.size() > 1) colSep = decodeSep(p.get(1));
            if (p.size() > 2) rowSep = decodeSep(p.get(2));
        } else if (cmd.equals(".nullvalue")) {
            nullValue = p.size() > 1 ? p.get(1) : "";
        } else if (cmd.equals(".print")) {
            out.println(line.length() > 6 ? line.substring(7) : "");
        } else if (cmd.equals(".echo")) {
            if (p.size() > 1) echo = isOn(p.get(1));
        } else if (cmd.equals(".read")) {
            if (p.size() < 2) return;
            StringBuilder s = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new FileReader(p.get(1)))) {
                String l;
                while ((l = br.readLine()) != null) s.append(l).append('\n');
            }
            processInput(s.toString(), p.get(1));
        } else if (cmd.equals(".tables")) {
            String pattern = p.size() > 1 ? p.get(1) : null;
            printTables(pattern);
        } else if (cmd.equals(".schema") || cmd.equals(".fullschema")) {
            String pattern = p.size() > 1 ? p.get(1) : null;
            printSchema(pattern);
        } else if (cmd.equals(".indexes")) {
            String pattern = p.size() > 1 ? p.get(1) : null;
            printIndexes(pattern);
        } else if (cmd.equals(".dump")) {
            String pattern = p.size() > 1 ? p.get(1) : null;
            dumpDatabase(pattern);
        } else if (cmd.equals(".databases")) {
            executeStatement("PRAGMA database_list;", 1);
        } else if (cmd.equals(".version")) {
            out.println("SQLite 3.54.0 2026-04-14 20:02:49");
            out.println("zlib version 1.2.11");
            out.println("gcc-11.4.0");
        } else if (cmd.equals(".open")) {
            if (p.size() > 1) { dbFile = p.get(p.size() - 1); openDb(dbFile, false); }
        } else {
            System.err.println("Error: unknown command or invalid arguments:  \"" + line + "\". Enter \".help\" for help");
            exitCode = 1;
        }
    }

    private void setMode(String m) {
        switch (m.toLowerCase(Locale.ROOT)) {
            case "csv": mode = Mode.CSV; break;
            case "list": mode = Mode.LIST; colSep = "|"; break;
            case "tabs": mode = Mode.TABS; colSep = "\t"; break;
            case "column": mode = Mode.COLUMN; break;
            case "table": mode = Mode.TABLE; break;
            case "line": mode = Mode.LINE; break;
            case "quote": mode = Mode.QUOTE; break;
            case "json": mode = Mode.JSON; break;
            case "html": mode = Mode.HTML; break;
            case "markdown": mode = Mode.MARKDOWN; break;
            case "box": mode = Mode.BOX; break;
            case "ascii": mode = Mode.ASCII; colSep = "\u001f"; rowSep = "\u001e\n"; break;
        }
    }

    private void printResult(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int n = md.getColumnCount();
        List<String> names = new ArrayList<>();
        for (int i = 1; i <= n; i++) names.add(md.getColumnLabel(i));
        List<List<Object>> rows = new ArrayList<>();
        while (rs.next()) {
            List<Object> row = new ArrayList<>();
            for (int i = 1; i <= n; i++) row.add(rs.getObject(i));
            rows.add(row);
        }
        switch (mode) {
            case CSV: printSeparated(names, rows, ",", true, "\r\n"); break;
            case TABS: printSeparated(names, rows, "\t", false, "\n"); break;
            case ASCII: printSeparated(names, rows, "\u001f", false, "\u001e\n"); break;
            case COLUMN: printColumn(names, rows, false, false); break;
            case TABLE: printTable(names, rows, false); break;
            case MARKDOWN: printMarkdown(names, rows); break;
            case BOX: printTable(names, rows, true); break;
            case LINE: printLine(names, rows); break;
            case QUOTE: printQuote(names, rows); break;
            case JSON: printJson(names, rows); break;
            case HTML: printHtml(names, rows); break;
            case LIST:
            default: printSeparated(names, rows, colSep, false, rowSep); break;
        }
    }

    private String cell(Object o) {
        return o == null ? nullValue : String.valueOf(o);
    }

    private void printSeparated(List<String> names, List<List<Object>> rows, String sep, boolean csv, String eol) {
        if (headers) printRaw(joinLine(names, sep, csv) + eol);
        for (List<Object> row : rows) {
            List<String> vals = new ArrayList<>();
            for (Object o : row) vals.add(cell(o));
            printRaw(joinLine(vals, sep, csv) + eol);
        }
    }

    private String joinLine(List<String> vals, String sep, boolean csv) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vals.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(csv ? csv(vals.get(i)) : vals.get(i));
        }
        return sb.toString();
    }

    private String csv(String s) {
        if (s == null) s = "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n") || s.contains("\r")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    private void printLine(List<String> names, List<List<Object>> rows) {
        int w = names.stream().mapToInt(String::length).max().orElse(0);
        for (List<Object> row : rows) {
            for (int i = 0; i < names.size(); i++) {
                out.printf("%" + w + "s: %s%n", names.get(i), cell(row.get(i)));
            }
            if (rows.size() > 1) out.println();
        }
    }

    private void printQuote(List<String> names, List<List<Object>> rows) {
        if (headers) out.println(joinLine(names, ",", true));
        for (List<Object> row : rows) {
            List<String> vals = new ArrayList<>();
            for (Object o : row) vals.add(sqlQuote(o));
            out.println(String.join(",", vals));
        }
    }

    private String sqlQuote(Object o) {
        if (o == null) return "NULL";
        if (o instanceof Number) return String.valueOf(o);
        return "'" + String.valueOf(o).replace("'", "''") + "'";
    }

    private void printJson(List<String> names, List<List<Object>> rows) {
        StringBuilder sb = new StringBuilder("[");
        for (int r = 0; r < rows.size(); r++) {
            if (r > 0) sb.append(",");
            sb.append("{");
            for (int i = 0; i < names.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(jsonString(names.get(i))).append(":").append(jsonValue(rows.get(r).get(i)));
            }
            sb.append("}");
        }
        sb.append("]");
        out.println(sb);
    }

    private String jsonValue(Object o) {
        if (o == null) return "null";
        if (o instanceof Number || o instanceof Boolean) return String.valueOf(o);
        return jsonString(String.valueOf(o));
    }

    private String jsonString(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"': sb.append("\\\""); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 32) sb.append(String.format("\\u%04x", (int)c));
                    else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    private void printHtml(List<String> names, List<List<Object>> rows) {
        if (headers) {
            out.println("<TR>");
            for (String name : names) out.println("<TH>" + html(name));
            out.println("</TR>");
        }
        for (List<Object> row : rows) {
            out.println("<TR>");
            for (Object o : row) out.println("<TD>" + html(o == null ? "null" : String.valueOf(o)));
            out.println("</TR>");
        }
    }

    private String html(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private int[] widths(List<String> names, List<List<Object>> rows) {
        int[] w = new int[names.size()];
        for (int i = 0; i < names.size(); i++) w[i] = headers ? names.get(i).length() : 0;
        if (mode == Mode.TABLE || mode == Mode.MARKDOWN || mode == Mode.BOX) {
            for (int i = 0; i < names.size(); i++) w[i] = Math.max(w[i], names.get(i).length());
        }
        for (List<Object> row : rows) {
            for (int i = 0; i < row.size(); i++) w[i] = Math.max(w[i], cell(row.get(i)).length());
        }
        for (int i = 0; i < w.length; i++) w[i] = Math.max(w[i], 1);
        return w;
    }

    private void printColumn(List<String> names, List<List<Object>> rows, boolean unused, boolean unicode) {
        int[] w = widths(names, rows);
        if (headers) {
            out.println(rtrim(paddedRow(names, w, "  ", false)));
            List<String> dash = new ArrayList<>();
            for (int x : w) dash.add(repeat("-", x));
            out.println(rtrim(paddedRow(dash, w, "  ", false)));
        }
        for (List<Object> row : rows) {
            List<String> vals = new ArrayList<>();
            for (Object o : row) vals.add(cell(o));
            out.println(rtrim(paddedRow(vals, w, "  ", false)));
        }
    }

    private String paddedRow(List<String> vals, int[] w, String sep, boolean center) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vals.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(pad(vals.get(i), w[i], center));
        }
        return sb.toString();
    }

    private void printMarkdown(List<String> names, List<List<Object>> rows) {
        int[] w = widths(names, rows);
        out.println("| " + paddedRow(names, w, " | ", true) + " |");
        List<String> dash = new ArrayList<>();
        for (int x : w) dash.add(repeat("-", x));
        out.println("|" + joinDash(w, "|") + "|");
        for (List<Object> row : rows) {
            List<String> vals = new ArrayList<>();
            for (Object o : row) vals.add(cell(o));
            out.println("| " + paddedRow(vals, w, " | ", true) + " |");
        }
    }

    private void printTable(List<String> names, List<List<Object>> rows, boolean box) {
        int[] w = widths(names, rows);
        if (box) {
            out.println("╭" + joinRepeat(w, "─", "┬") + "╮");
            out.println("│ " + paddedRow(names, w, " │ ", true) + " │");
            out.println("╞" + joinRepeat(w, "═", "╪") + "╡");
            for (List<Object> row : rows) {
                List<String> vals = new ArrayList<>();
                for (Object o : row) vals.add(cell(o));
                out.println("│ " + paddedRow(vals, w, " │ ", true) + " │");
            }
            out.println("╰" + joinRepeat(w, "─", "┴") + "╯");
        } else {
            out.println("+" + joinDash(w, "+") + "+");
            out.println("| " + paddedRow(names, w, " | ", true) + " |");
            out.println("+" + joinDash(w, "+") + "+");
            for (List<Object> row : rows) {
                List<String> vals = new ArrayList<>();
                for (Object o : row) vals.add(cell(o));
                out.println("| " + paddedRow(vals, w, " | ", true) + " |");
            }
            out.println("+" + joinDash(w, "+") + "+");
        }
    }

    private String joinDash(int[] w, String sep) {
        return joinRepeat(w, "-", sep);
    }

    private String joinRepeat(int[] w, String ch, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < w.length; i++) {
            if (i > 0) sb.append(sep);
            sb.append(repeat(ch, w[i] + 2));
        }
        return sb.toString();
    }

    private String pad(String s, int w, boolean center) {
        if (s.length() >= w) return s;
        int diff = w - s.length();
        if (!center) return s + repeat(" ", diff);
        int left = diff / 2;
        int right = diff - left;
        return repeat(" ", left) + s + repeat(" ", right);
    }

    private String repeat(String s, int n) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < n; i++) b.append(s);
        return b.toString();
    }

    private String rtrim(String s) {
        int i = s.length();
        while (i > 0 && s.charAt(i - 1) == ' ') i--;
        return s.substring(0, i);
    }

    private void printTables(String pattern) throws SQLException {
        List<String> names = new ArrayList<>();
        String sql = "SELECT name FROM sqlite_schema WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%'";
        if (pattern != null) sql += " AND name LIKE '" + pattern.replace("'", "''") + "'";
        sql += " ORDER BY name";
        try (Statement st = db.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) names.add(rs.getString(1));
        }
        if (!names.isEmpty()) out.println(String.join(" ", names));
    }

    private void printSchema(String pattern) throws SQLException {
        String sql = "SELECT sql FROM sqlite_schema WHERE sql IS NOT NULL";
        if (pattern != null) sql += " AND name LIKE '" + pattern.replace("'", "''") + "'";
        sql += " ORDER BY tbl_name, type DESC, name";
        try (Statement st = db.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) out.println(rs.getString(1) + ";");
        }
    }

    private void printIndexes(String pattern) throws SQLException {
        String sql = "SELECT name FROM sqlite_schema WHERE type='index' AND name NOT LIKE 'sqlite_%'";
        if (pattern != null) sql += " AND tbl_name LIKE '" + pattern.replace("'", "''") + "'";
        sql += " ORDER BY name";
        List<String> names = new ArrayList<>();
        try (Statement st = db.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) names.add(rs.getString(1));
        }
        if (!names.isEmpty()) out.println(String.join(" ", names));
    }

    private void dumpDatabase(String pattern) throws SQLException {
        out.println("PRAGMA foreign_keys=OFF;");
        out.println("BEGIN TRANSACTION;");
        String sql = "SELECT name, type, sql FROM sqlite_schema WHERE sql IS NOT NULL AND type IN ('table','index','trigger','view')";
        if (pattern != null) sql += " AND name LIKE '" + pattern.replace("'", "''") + "'";
        sql += " ORDER BY type='table' DESC, name";
        List<String> tables = new ArrayList<>();
        try (Statement st = db.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                String name = rs.getString(1);
                String type = rs.getString(2);
                String ddl = rs.getString(3);
                out.println(ddl + ";");
                if ("table".equals(type) && !name.startsWith("sqlite_")) tables.add(name);
            }
        }
        for (String table : tables) {
            try (Statement st = db.createStatement(); ResultSet rs = st.executeQuery("SELECT * FROM \"" + table.replace("\"", "\"\"") + "\"")) {
                ResultSetMetaData md = rs.getMetaData();
                int n = md.getColumnCount();
                while (rs.next()) {
                    List<String> vals = new ArrayList<>();
                    for (int i = 1; i <= n; i++) vals.add(sqlQuote(rs.getObject(i)));
                    out.println("INSERT INTO " + sqlQuoteIdentifier(table) + " VALUES(" + String.join(",", vals) + ");");
                }
            }
        }
        out.println("COMMIT;");
    }

    private String sqlQuoteIdentifier(String s) {
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private boolean isOn(String s) {
        s = s.toLowerCase(Locale.ROOT);
        return s.equals("on") || s.equals("yes") || s.equals("true") || s.equals("1");
    }

    private List<String> splitWords(String s) {
        List<String> r = new ArrayList<>();
        StringBuilder b = new StringBuilder();
        char q = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (q != 0) {
                if (c == q) q = 0;
                else b.append(c);
            } else if (c == '\'' || c == '"') {
                q = c;
            } else if (Character.isWhitespace(c)) {
                if (b.length() > 0) { r.add(b.toString()); b.setLength(0); }
            } else {
                b.append(c);
            }
        }
        if (b.length() > 0) r.add(b.toString());
        return r;
    }

    private String decodeSep(String s) {
        return s.replace("\\n", "\n").replace("\\t", "\t").replace("\\r", "\r");
    }

    private void printRaw(String s) {
        System.out.print(s);
        System.out.flush();
    }

    private void printHelp() {
        System.out.print("Usage: ./executable [OPTIONS] [FILENAME [SQL...]]\n" +
                "FILENAME is the name of an SQLite database. A new database is created\n" +
                "if the file does not previously exist. Defaults to :memory:.\n" +
                "OPTIONS include:\n" +
                "   --                   treat no subsequent arguments as options\n" +
                "   -A ARGS...           run \".archive ARGS\" and exit\n" +
                "   -append              append the database to the end of the file\n" +
                "   -ascii               set output mode to 'ascii'\n" +
                "   -bail                stop after hitting an error\n" +
                "   -batch               force batch I/O\n" +
                "   -box                 set output mode to 'box'\n" +
                "   -cmd COMMAND         run \"COMMAND\" before reading stdin\n" +
                "   -column              set output mode to 'column'\n" +
                "   -csv                 set output mode to 'csv'\n" +
                "   -deserialize         open the database using sqlite3_deserialize()\n" +
                "   -echo                print inputs before execution\n" +
                "   -escape T            ctrl-char escape; T is one of: symbol, ascii, off\n" +
                "   -init FILENAME       read/process named file\n" +
                "   -[no]header          turn headers on or off\n" +
                "   -help                show this message\n" +
                "   -html                set output mode to HTML\n" +
                "   -ifexists            only open if database already exists\n" +
                "   -interactive         force interactive I/O\n" +
                "   -json                set output mode to 'json'\n" +
                "   -line                set output mode to 'line'\n" +
                "   -list                set output mode to 'list'\n" +
                "   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory\n" +
                "   -markdown            set output mode to 'markdown'\n" +
                "   -maxsize N           maximum size for a --deserialize database\n" +
                "   -memtrace            trace all memory allocations and deallocations\n" +
                "   -mmap N              default mmap size set to N\n" +
                "   -newline SEP         set output row separator. Default: '\\n'\n" +
                "   -nofollow            refuse to open symbolic links to database files\n" +
                "   -noinit              Do not read the ~/.sqliterc file at startup\n" +
                "   -nonce STRING        set the safe-mode escape nonce\n" +
                "   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()\n" +
                "   -nullvalue TEXT      set text string for NULL values. Default ''\n" +
                "   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory\n" +
                "   -pcachetrace         trace all page cache operations\n" +
                "   -quote               set output mode to 'quote'\n" +
                "   -readonly            open the database read-only\n" +
                "   -safe                enable safe-mode\n" +
                "   -screenwidth N       use N as the default screenwidth \n" +
                "   -separator SEP       set output column separator. Default: '|'\n" +
                "   -stats               print memory stats before each finalize\n" +
                "   -table               set output mode to 'table'\n" +
                "   -tabs                set output mode to 'tabs'\n" +
                "   -unsafe-testing      allow unsafe commands and modes for testing\n" +
                "   -version             show SQLite version\n" +
                "   -vfs NAME            use NAME as the default VFS\n" +
                "   -vfstrace            enable tracing of all VFS calls\n" +
                "   -zip                 open the file as a ZIP Archive\n");
    }

    private void printDotHelp() {
        String[] lines = {
                ".archive ...             Manage SQL archives",
                ".auth ON|OFF             Show authorizer callbacks",
                ".backup ?DB? FILE        Backup DB (default \"main\") to FILE",
                ".bail on|off             Stop after hitting an error.  Default OFF",
                ".cd DIRECTORY            Change the working directory to DIRECTORY",
                ".changes on|off          Show number of rows changed by SQL",
                ".databases               List names and files of attached databases",
                ".dump ?OBJECTS?          Render database content as SQL",
                ".echo on|off             Turn command echo on or off",
                ".exit ?CODE?             Exit this program with return-code CODE",
                ".headers on|off          Turn display of headers on or off",
                ".help ?-all? ?PATTERN?   Show help text for PATTERN",
                ".import FILE TABLE       Import data from FILE into TABLE",
                ".indexes ?PATTERN?       Show names of indexes matching PATTERN",
                ".load FILE ?ENTRY?       Load an extension library",
                ".mode ?MODE? ?OPTIONS?   Set output mode",
                ".nullvalue STRING        Use STRING in place of NULL values",
                ".once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE",
                ".open ?OPTIONS? ?FILE?   Close existing database and reopen FILE",
                ".output ?FILE?           Send output to FILE or stdout if FILE is omitted",
                ".print STRING...         Print literal STRING",
                ".quit                    Stop interpreting input stream, exit if primary.",
                ".read FILE               Read input from FILE or command output",
                ".schema ?PATTERN?        Show the CREATE statements matching PATTERN",
                ".separator COL ?ROW?     Change the column and row separators",
                ".shell CMD ARGS...       Run CMD ARGS... in a system shell",
                ".show                    Show the current values for various settings",
                ".tables ?TABLE?          List names of tables matching LIKE pattern TABLE",
                ".version                 Show source, library and compiler versions"
        };
        for (String l : lines) out.println(l);
    }
}
