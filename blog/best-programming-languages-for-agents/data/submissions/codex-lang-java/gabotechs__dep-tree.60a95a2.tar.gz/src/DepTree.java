import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class DepTree {
    static final String VERSION = "v0.23.4";
    static final Set<String> EXT = Set.of(".py", ".js", ".jsx", ".ts", ".tsx", ".go", ".rs");

    public static void main(String[] raw) {
        try {
            new DepTree().run(raw);
        } catch ( Cli e) {
            if (!e.msg.isEmpty()) System.err.println(e.msg);
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class Cli extends RuntimeException {
        final int code; final String msg;
        Cli(int code, String msg) { this.code = code; this.msg = msg; }
    }

    Path cwd = Paths.get("").toAbsolutePath().normalize();
    List<String> only = new ArrayList<>(), exclude = new ArrayList<>();
    boolean unwrapExports = false, pyExcludeConditional = false;
    String configPath = ".dep-tree.yml";

    void run(String[] raw) throws Exception {
        List<String> args = parseGlobals(new ArrayList<>(Arrays.asList(raw)));
        if (args.isEmpty() || args.get(0).equals("-h") || args.get(0).equals("--help")) { help(); return; }
        if (has(args, "-v", "--version")) { System.out.println("dep-tree version " + VERSION); return; }
        String cmd = args.remove(0);
        if (cmd.equals("help")) { helpFor(args.isEmpty() ? "" : args.get(0)); return; }
        switch (cmd) {
            case "entropy" -> entropy(args);
            case "tree" -> tree(args);
            case "explain" -> explain(args);
            case "check" -> check(args);
            case "config", "init" -> config();
            default -> {
                if (Files.exists(cwd.resolve(cmd))) entropy(prepend(cmd, args));
                else throw new Cli(1, "Error: " + cmd + " does not match with any existing file");
            }
        }
    }

    List<String> parseGlobals(List<String> a) throws IOException {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < a.size(); i++) {
            String s = a.get(i);
            if (s.equals("-c") || s.equals("--config")) configPath = need(a, ++i, s);
            else if (s.startsWith("--config=")) configPath = s.substring(9);
            else if (s.equals("--only")) only.add(need(a, ++i, s));
            else if (s.startsWith("--only=")) only.add(s.substring(7));
            else if (s.equals("--exclude")) exclude.add(need(a, ++i, s));
            else if (s.startsWith("--exclude=")) exclude.add(s.substring(10));
            else if (s.equals("--unwrap-exports")) unwrapExports = true;
            else if (s.equals("--python-exclude-conditional-imports")) pyExcludeConditional = true;
            else if (s.equals("--js-tsconfig-paths") || s.equals("--js-workspaces")) {}
            else out.add(s);
        }
        loadConfig();
        return out;
    }

    String need(List<String> a, int i, String f) {
        if (i >= a.size()) throw new Cli(1, "Error: flag needs an argument: " + f);
        return a.get(i);
    }

    List<String> prepend(String s, List<String> rest) { List<String> r = new ArrayList<>(); r.add(s); r.addAll(rest); return r; }
    boolean has(List<String> a, String... keys) { for (String k: keys) if (a.contains(k)) return true; return false; }

    void helpFor(String c) {
        switch (c) {
            case "entropy" -> System.out.print("""
(default) Renders a 3d force-directed graph in the browser

Usage:
  dep-tree entropy [flags]

Flags:
      --enable-gui           Enables a GUI for changing rendering settings
  -h, --help                 help for entropy
      --no-browser-open      Disable the automatic browser open while rendering entropy
      --render-path string   Sets the output path of the rendered html file
""");
            case "tree" -> System.out.print("""
Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format
""");
            case "check" -> System.out.print("""
Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check
""");
            case "explain" -> System.out.print("""
Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right
""");
            case "config", "init" -> System.out.print("""
Generates a sample config in case that there's not already one present

Usage:
  dep-tree config [flags]

Aliases:
  config, init
""");
            default -> help();
        }
        if (!c.isEmpty()) System.out.print(globalFlags());
    }

    void help() {
        System.out.print("""

      ____         _ __       _
     |  _ \\   ___ |  _ \\    _| |_  _ __  ___   ___
     | | | | / _ \\| |_) |  |_   _||  __|/ _ \\ / _ \\
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \\__| |_|        | \\__|_|   \\___| \\___|

Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
""");
        System.out.print(globalFlags().replaceFirst("\\nGlobal Flags:\\n", ""));
        System.out.println("\nUse \"dep-tree [command] --help\" for more information about a command.");
    }

    String globalFlags() {
        return """

Global Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
""";
    }

    void tree(List<String> args) throws IOException {
        if (has(args, "-h", "--help")) { helpFor("tree"); return; }
        boolean json = args.remove("--json");
        if (args.isEmpty()) throw new Cli(1, "Error: requires at least 1 arg(s), only received 0");
        Graph g = scan();
        if (json) {
            Map<String,Object> t = new LinkedHashMap<>();
            for (String e: expandArgs(args)) t.put(norm(e), buildTree(norm(e), g, new LinkedHashSet<>()));
            System.out.println("{\n  \"tree\": " + jsonObj(t, 2) + ",\n  \"circularDependencies\": " + jsonArr(cycles(g)) + ",\n  \"errors\": {}\n}");
        } else {
            for (String e: expandArgs(args)) printTree(norm(e), g, "", new LinkedHashSet<>());
        }
    }

    Object buildTree(String f, Graph g, LinkedHashSet<String> stack) {
        if (!stack.add(f)) return null;
        List<String> deps = g.edges.getOrDefault(f, List.of());
        if (deps.isEmpty()) { stack.remove(f); return null; }
        Map<String,Object> m = new LinkedHashMap<>();
        for (String d: deps) m.put(d, buildTree(d, g, stack));
        stack.remove(f);
        return m;
    }

    void printTree(String f, Graph g, String ind, Set<String> seen) {
        System.out.println(ind + f);
        if (!seen.add(f)) return;
        for (String d: g.edges.getOrDefault(f, List.of())) printTree(d, g, ind + "  ", seen);
    }

    void explain(List<String> args) throws IOException {
        if (has(args, "-h", "--help")) { helpFor("explain"); return; }
        boolean ol = args.remove("--overlap-left") || args.remove("-l");
        boolean or = args.remove("--overlap-right") || args.remove("-r");
        if (args.size() != 2) throw new Cli(1, "Error: accepts 2 arg(s), received " + args.size());
        Graph g = scan();
        Set<String> left = matchFiles(args.get(0)), right = matchFiles(args.get(1));
        Set<String> both = new HashSet<>(left); both.retainAll(right);
        if (ol) right.removeAll(both); if (or) left.removeAll(both);
        List<String> lines = new ArrayList<>();
        for (String l: left) for (String d: reachable(l, g)) if (right.contains(d)) lines.add(l + " -> " + d);
        Collections.sort(lines);
        for (String s: lines) System.out.println(s);
    }

    void check(List<String> args) throws IOException {
        if (!args.isEmpty() && has(args, "-h", "--help")) { helpFor("check"); return; }
        Config cfg = parseCheckConfig();
        Graph g = scan();
        Set<String> relevant = new LinkedHashSet<>();
        if (cfg.entrypoints.isEmpty()) relevant.addAll(g.edges.keySet());
        else for (String e: cfg.entrypoints) { relevant.add(norm(e)); relevant.addAll(reachable(norm(e), g)); }
        List<String> errors = new ArrayList<>();
        if (!cfg.allowCircular) for (List<String> cyc: cycles(g)) errors.add("Circular dependency: " + String.join(" -> ", cyc));
        for (String from: relevant) {
            for (String to: g.edges.getOrDefault(from, List.of())) {
                for (Rule r: cfg.deny) if (glob(r.from, from) && globAny(expandAliases(r.to, cfg), to))
                    errors.add(from + " -> " + to + " is forbidden" + reason(r));
                List<Rule> ars = new ArrayList<>();
                for (Rule r: cfg.allow) if (glob(r.from, from)) ars.add(r);
                if (!ars.isEmpty()) {
                    boolean ok = false; String why = "";
                    for (Rule r: ars) { if (globAny(expandAliases(r.to, cfg), to)) ok = true; if (!r.reason.isEmpty()) why = r.reason; }
                    if (!ok) errors.add(from + " -> " + to + " is not allowed" + (why.isEmpty() ? "" : ": " + why));
                }
            }
        }
        if (!errors.isEmpty()) {
            for (String e: errors) System.err.println(e);
            throw new Cli(1, "");
        }
    }

    String reason(Rule r) { return r.reason.isEmpty() ? "" : ": " + r.reason; }
    List<String> expandAliases(List<String> p, Config c) { List<String> r = new ArrayList<>(); for (String x: p) r.addAll(c.aliases.getOrDefault(x, List.of(x))); return r; }

    void entropy(List<String> args) throws IOException {
        if (has(args, "-h", "--help")) { helpFor("entropy"); return; }
        String out = "dep-tree.html";
        for (int i=0;i<args.size();i++) if (args.get(i).equals("--render-path")) out = need(args, ++i, "--render-path");
        Graph g = scan();
        Files.writeString(cwd.resolve(out), "<!doctype html><html><head><title>dep-tree</title></head><body><script>window.depTree=" + graphJson(g) + ";</script></body></html>");
    }

    void config() throws IOException {
        Path p = cwd.resolve(configPath);
        if (Files.exists(p)) throw new Cli(1, "Error: cannot generate config file, as one already exists in " + configPath);
        Files.writeString(p, SAMPLE_CONFIG, StandardCharsets.UTF_8);
    }

    static class Graph { Map<String,List<String>> edges = new TreeMap<>(); Set<String> files = new TreeSet<>(); }

    Graph scan() throws IOException {
        Graph g = new Graph();
        List<Path> files = new ArrayList<>();
        try (var s = Files.walk(cwd)) {
            s.filter(Files::isRegularFile).forEach(p -> { String n = norm(cwd.relativize(p).toString()); if (isSource(n) && include(n)) files.add(p); });
        }
        Map<String,Path> by = new HashMap<>();
        for (Path p: files) { String n = norm(cwd.relativize(p).toString()); by.put(n, p); g.files.add(n); g.edges.put(n, new ArrayList<>()); }
        for (Path p: files) {
            String from = norm(cwd.relativize(p).toString());
            LinkedHashSet<String> deps = new LinkedHashSet<>();
            for (String spec: importSpecs(p)) {
                String r = resolve(from, spec, by);
                if (r != null && include(r) && !r.equals(from)) deps.add(r);
            }
            g.edges.put(from, new ArrayList<>(deps));
        }
        return g;
    }

    List<String> importSpecs(Path p) throws IOException {
        String rel = norm(cwd.relativize(p).toString());
        String text = Files.readString(p);
        List<String> r = new ArrayList<>();
        if (rel.endsWith(".py")) {
            int prevIndent = 0; boolean conditional = false;
            for (String line: text.split("\\R")) {
                String t = line.strip();
                int ind = line.length() - line.stripLeading().length();
                if (ind <= prevIndent) conditional = false;
                if (t.startsWith("if ") || t.startsWith("try:")) conditional = true;
                Matcher m = Pattern.compile("^import\\s+([A-Za-z0-9_.,\\s]+)").matcher(t);
                if (m.find() && !(pyExcludeConditional && conditional)) for (String x: m.group(1).split(",")) r.add(x.trim().split("\\s+")[0]);
                m = Pattern.compile("^from\\s+([.A-Za-z0-9_]+)\\s+import\\s+(.+)").matcher(t);
                if (m.find() && !(pyExcludeConditional && conditional)) {
                    String mod = m.group(1);
                    r.add(mod);
                    for (String x: m.group(2).split(",")) {
                        String name = x.trim().split("\\s+")[0];
                        if (!name.equals("*") && name.matches("[A-Za-z_][A-Za-z0-9_]*")) r.add(mod + "." + name);
                    }
                }
                prevIndent = ind;
            }
        } else if (rel.matches(".*\\.(js|jsx|ts|tsx)$")) {
            Matcher m = Pattern.compile("(?:import|export)\\s+(?:[^;]*?\\s+from\\s+)?[\"']([^\"']+)[\"']|require\\(\\s*[\"']([^\"']+)[\"']\\s*\\)").matcher(text);
            while (m.find()) r.add(m.group(1) != null ? m.group(1) : m.group(2));
        } else if (rel.endsWith(".go")) {
            Matcher m = Pattern.compile("import\\s+(?:\\((?s:.*?)\\)|[\"'][^\"']+[\"'])").matcher(text);
            while (m.find()) { Matcher q = Pattern.compile("[\"']([^\"']+)[\"']").matcher(m.group()); while(q.find()) r.add(q.group(1)); }
        } else if (rel.endsWith(".rs")) {
            Matcher m = Pattern.compile("\\bmod\\s+([A-Za-z0-9_]+)|\\buse\\s+crate::([A-Za-z0-9_:]+)").matcher(text);
            while (m.find()) r.add(m.group(1) != null ? m.group(1) : m.group(2).replace("::", "/"));
        }
        return r;
    }

    String resolve(String from, String spec, Map<String,Path> by) {
        if (spec == null || spec.isEmpty()) return null;
        String dir = from.contains("/") ? from.substring(0, from.lastIndexOf('/')) : "";
        List<String> bases = new ArrayList<>();
        if (spec.startsWith(".")) {
            Path b = (dir.isEmpty()? Paths.get(""):Paths.get(dir)).resolve(spec).normalize();
            bases.add(norm(b.toString()));
        } else {
            bases.add(spec.replace('.', '/'));
            bases.add((dir.isEmpty() ? "" : dir + "/") + spec.replace('.', '/'));
        }
        for (String b: bases) {
            for (String ext: EXT) if (by.containsKey(b + ext)) return b + ext;
            for (String ext: EXT) if (by.containsKey(b + "/index" + ext)) return b + "/index" + ext;
            for (String ext: EXT) if (by.containsKey(b + "/mod" + ext)) return b + "/mod" + ext;
            if (by.containsKey(b)) return b;
        }
        return null;
    }

    Set<String> matchFiles(String pat) throws IOException {
        Set<String> r = new TreeSet<>();
        for (String f: scan().files) if (glob(pat, f)) r.add(f);
        return r;
    }

    List<String> expandArgs(List<String> args) throws IOException {
        List<String> out = new ArrayList<>();
        for (String a: args) {
            Set<String> m = (a.contains("*") || a.contains("?")) ? matchFiles(a) : Set.of(norm(a));
            out.addAll(m);
        }
        return out;
    }

    Set<String> reachable(String start, Graph g) {
        Set<String> out = new TreeSet<>(); Deque<String> q = new ArrayDeque<>(g.edges.getOrDefault(start, List.of()));
        while (!q.isEmpty()) { String x = q.removeFirst(); if (out.add(x)) q.addAll(g.edges.getOrDefault(x, List.of())); }
        return out;
    }

    List<List<String>> cycles(Graph g) {
        List<List<String>> out = new ArrayList<>();
        for (String f: g.files) cycDfs(f, g, new ArrayList<>(), new HashSet<>(), out);
        return out;
    }
    void cycDfs(String f, Graph g, List<String> st, Set<String> local, List<List<String>> out) {
        if (local.contains(f)) { int i = st.indexOf(f); if (i >= 0) { List<String> c = new ArrayList<>(st.subList(i, st.size())); c.add(f); if (out.stream().noneMatch(x -> new HashSet<>(x).equals(new HashSet<>(c)))) out.add(c); } return; }
        local.add(f); st.add(f);
        for (String d: g.edges.getOrDefault(f, List.of())) cycDfs(d, g, st, local, out);
        st.remove(st.size()-1); local.remove(f);
    }

    boolean include(String f) {
        if (!only.isEmpty() && !globAny(only, f)) return false;
        return !globAny(exclude, f);
    }
    boolean globAny(List<String> p, String f) { for (String x: p) if (glob(x, f)) return true; return false; }
    boolean glob(String pat, String f) {
        pat = stripQuotes(norm(pat));
        StringBuilder re = new StringBuilder("^");
        for (int i=0;i<pat.length();i++) {
            char c=pat.charAt(i);
            if (c=='*') {
                if (i+1<pat.length() && pat.charAt(i+1)=='*') { re.append(".*"); i++; if (i+1<pat.length() && pat.charAt(i+1)=='/') { re.append("(?:/)?"); i++; } }
                else re.append("[^/]*");
            } else if (c=='?') re.append("[^/]");
            else if (".[]{}()+-^$|\\".indexOf(c)>=0) re.append('\\').append(c);
            else re.append(c);
        }
        re.append("$");
        return Pattern.compile(re.toString()).matcher(f).matches();
    }

    String stripQuotes(String s) { return ((s.startsWith("'")&&s.endsWith("'"))||(s.startsWith("\"")&&s.endsWith("\""))) ? s.substring(1,s.length()-1) : s; }
    static String norm(String s) { return s.replace('\\','/').replaceFirst("^\\./", ""); }
    static boolean isSource(String f) { for (String e: EXT) if (f.endsWith(e)) return true; return false; }

    String jsonObj(Map<String,Object> m, int ind) {
        if (m.isEmpty()) return "{}";
        StringBuilder sb = new StringBuilder("{\n"); int i=0;
        for (var e: m.entrySet()) {
            sb.append(" ".repeat(ind+2)).append(q(e.getKey())).append(": ");
            Object v=e.getValue(); sb.append(v==null ? "null" : jsonObj((Map<String,Object>)v, ind+2));
            if (++i<m.size()) sb.append(",");
            sb.append("\n");
        }
        return sb.append(" ".repeat(ind)).append("}").toString();
    }
    String jsonArr(List<List<String>> a) { StringBuilder sb=new StringBuilder("["); for(int i=0;i<a.size();i++){ if(i>0)sb.append(", "); sb.append("["); for(int j=0;j<a.get(i).size();j++){ if(j>0)sb.append(", "); sb.append(q(a.get(i).get(j))); } sb.append("]"); } return sb.append("]").toString(); }
    String graphJson(Graph g) { Map<String,Object> m=new LinkedHashMap<>(); for(String f:g.files)m.put(f,new LinkedHashMap<>()); return jsonObj(m,0); }
    String q(String s) { return "\"" + s.replace("\\","\\\\").replace("\"","\\\"") + "\""; }

    void loadConfig() throws IOException {
        Path p = cwd.resolve(configPath);
        if (!Files.exists(p)) return;
        String topList = "";
        for (String line: Files.readAllLines(p)) {
            String t=line.strip();
            int ind = line.length() - line.stripLeading().length();
            if (ind == 0) {
                if (t.equals("only:")) topList = "only";
                else if (t.equals("exclude:")) topList = "exclude";
                else topList = "";
            } else if (!topList.isEmpty() && t.startsWith("-")) {
                (topList.equals("only") ? only : exclude).add(unquote(t.substring(1).trim()));
            }
            if (t.startsWith("unwrapExports:") && t.contains("true")) unwrapExports=true;
            if (t.startsWith("excludeConditionalImports:") && t.contains("true")) pyExcludeConditional=true;
        }
    }

    static class Config { List<String> entrypoints=new ArrayList<>(); boolean allowCircular=false; List<Rule> allow=new ArrayList<>(), deny=new ArrayList<>(); Map<String,List<String>> aliases=new HashMap<>(); }
    static class Rule { String from="", reason=""; List<String> to=new ArrayList<>(); }

    Config parseCheckConfig() throws IOException {
        Config c = new Config(); Path p = cwd.resolve(configPath); if (!Files.exists(p)) return c;
        List<String> lines = Files.readAllLines(p);
        String section="", sub="", currentKey=null; Rule current=null;
        for (String line: lines) {
            String t=line.strip(); if (t.isEmpty()||t.startsWith("#")) continue;
            int ind=line.length()-line.stripLeading().length();
            if (ind==0 && t.startsWith("check:")) { section="check"; continue; }
            if (!section.equals("check")) continue;
            if (ind==2 && t.startsWith("entrypoints:")) { sub="entry"; continue; }
            if (ind==2 && t.startsWith("allowCircularDependencies:")) { c.allowCircular=t.contains("true"); continue; }
            if (ind==2 && t.startsWith("allow:")) { sub="allow"; currentKey=null; continue; }
            if (ind==2 && t.startsWith("deny:")) { sub="deny"; currentKey=null; continue; }
            if (ind==2 && t.startsWith("aliases:")) { sub="aliases"; currentKey=null; continue; }
            if (sub.equals("entry") && t.startsWith("-")) c.entrypoints.add(unquote(t.substring(1).trim()));
            else if ((sub.equals("allow")||sub.equals("deny")) && ind==4 && t.endsWith(":")) { currentKey=unquote(t.substring(0,t.length()-1).trim()); current=null; }
            else if ((sub.equals("allow")||sub.equals("deny")) && currentKey!=null) {
                if (t.startsWith("-")) {
                    String val=t.substring(1).trim();
                    if (current != null && current.to.isEmpty() && !val.startsWith("to:")) current.to.add(unquote(val));
                    else { Rule r=new Rule(); r.from=currentKey; if (val.startsWith("to:")) r.to.add(unquote(val.substring(3).trim())); else r.to.add(unquote(val)); (sub.equals("allow")?c.allow:c.deny).add(r); current=r; }
                }
                else if (t.startsWith("to:")) { current=new Rule(); current.from=currentKey; String val=unquote(t.substring(3).trim()); if (!val.isEmpty()) current.to.add(val); (sub.equals("allow")?c.allow:c.deny).add(current); }
                else if (t.startsWith("reason:") && current!=null) current.reason=unquote(t.substring(7).trim());
            } else if (sub.equals("aliases") && ind==4 && t.endsWith(":")) { currentKey=unquote(t.substring(0,t.length()-1).trim()); c.aliases.putIfAbsent(currentKey,new ArrayList<>()); }
            else if (sub.equals("aliases") && currentKey!=null && t.startsWith("-")) c.aliases.get(currentKey).add(unquote(t.substring(1).trim()));
        }
        return c;
    }
    static String unquote(String s) { s=s.trim(); return ((s.startsWith("'")&&s.endsWith("'"))||(s.startsWith("\"")&&s.endsWith("\""))) ? s.substring(1,s.length()-1) : s; }

    static final String SAMPLE_CONFIG = """
# Files that should be completely ignored by dep-tree. It's fine to ignore
# some big files that everyone depends on and that don't add
# value to the visualization, like auto generated code.
exclude:
  - 'some-glob-pattern/**/*.ts'

# The only files that will be included by dep-tree. If a file does not
# match any of the provided patters, it is ignored.
only:
  - 'some-glob-pattern/**/*.ts'

unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
  # None available at the moment.
""";
}
