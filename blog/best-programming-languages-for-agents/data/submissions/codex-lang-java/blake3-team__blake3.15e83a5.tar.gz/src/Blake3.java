import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

final class Blake3 {
    private static final int OUT_LEN = 32;
    private static final int KEY_LEN = 32;
    private static final int BLOCK_LEN = 64;
    private static final int CHUNK_LEN = 1024;

    private static final int CHUNK_START = 1;
    private static final int CHUNK_END = 2;
    private static final int PARENT = 4;
    private static final int ROOT = 8;
    static final int KEYED_HASH = 16;
    private static final int DERIVE_KEY_CONTEXT = 32;
    static final int DERIVE_KEY_MATERIAL = 64;

    private static final int[] IV = {
            0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
            0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19
    };
    private static final byte[] IV_KEY = wordsToBytes(IV);
    private static final int[] MSG_PERMUTATION = {
            2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8
    };

    private Blake3() {
    }

    static byte[] hash(byte[] input, int outLen, long seek) {
        return hashWithKey(input, IV_KEY, 0, outLen, seek);
    }

    static byte[] keyedHash(byte[] input, byte[] key, int outLen, long seek) {
        if (key.length != KEY_LEN) {
            throw new IllegalArgumentException("key must be 32 bytes");
        }
        return hashWithKey(input, key, KEYED_HASH, outLen, seek);
    }

    static byte[] deriveKeyHash(byte[] input, String context, int outLen, long seek) {
        byte[] contextKey = hashWithKey(context.getBytes(StandardCharsets.UTF_8), IV_KEY,
                DERIVE_KEY_CONTEXT, OUT_LEN, 0);
        return hashWithKey(input, contextKey, DERIVE_KEY_MATERIAL, outLen, seek);
    }

    private static byte[] hashWithKey(byte[] input, byte[] keyBytes, int flags, int outLen, long seek) {
        int[] keyWords = bytesToWords(keyBytes, 0);
        int chunks = Math.max(1, (input.length + CHUNK_LEN - 1) / CHUNK_LEN);
        List<Output> level = new ArrayList<>(chunks);
        for (int i = 0; i < chunks; i++) {
            int start = i * CHUNK_LEN;
            int end = Math.min(input.length, start + CHUNK_LEN);
            level.add(chunkOutput(input, start, end - start, i, keyWords, flags));
        }
        while (level.size() > 1) {
            List<Output> next = new ArrayList<>((level.size() + 1) / 2);
            int i = 0;
            for (; i + 1 < level.size(); i += 2) {
                next.add(parentOutput(level.get(i).chainingValue(), level.get(i + 1).chainingValue(), keyWords, flags));
            }
            if (i < level.size()) {
                next.add(level.get(i));
            }
            level = next;
        }
        return level.get(0).rootBytes(outLen, seek);
    }

    private static Output chunkOutput(byte[] input, int offset, int len, long chunkCounter, int[] keyWords, int flags) {
        int[] cv = Arrays.copyOf(keyWords, 8);
        int pos = 0;
        if (len == 0) {
            return new Output(cv, new int[16], chunkCounter, 0, flags | CHUNK_START | CHUNK_END);
        }
        while (pos < len) {
            int blockLen = Math.min(BLOCK_LEN, len - pos);
            int blockFlags = flags;
            if (pos == 0) {
                blockFlags |= CHUNK_START;
            }
            if (pos + blockLen == len) {
                blockFlags |= CHUNK_END;
                return new Output(cv, blockWords(input, offset + pos, blockLen), chunkCounter, blockLen, blockFlags);
            }
            cv = first8(compress(cv, blockWords(input, offset + pos, blockLen), chunkCounter, blockLen, blockFlags));
            pos += blockLen;
        }
        throw new AssertionError();
    }

    private static Output parentOutput(int[] leftCv, int[] rightCv, int[] keyWords, int flags) {
        int[] block = new int[16];
        System.arraycopy(leftCv, 0, block, 0, 8);
        System.arraycopy(rightCv, 0, block, 8, 8);
        return new Output(Arrays.copyOf(keyWords, 8), block, 0, BLOCK_LEN, flags | PARENT);
    }

    private static int[] compress(int[] cv, int[] block, long counter, int blockLen, int flags) {
        int[] v = new int[16];
        System.arraycopy(cv, 0, v, 0, 8);
        System.arraycopy(IV, 0, v, 8, 4);
        v[12] = (int) counter;
        v[13] = (int) (counter >>> 32);
        v[14] = blockLen;
        v[15] = flags;

        int[] m = Arrays.copyOf(block, 16);
        for (int round = 0; round < 7; round++) {
            round(v, m);
            if (round != 6) {
                permute(m);
            }
        }
        int[] out = new int[16];
        for (int i = 0; i < 8; i++) {
            out[i] = v[i] ^ v[i + 8];
            out[i + 8] = v[i + 8] ^ cv[i];
        }
        return out;
    }

    private static void round(int[] v, int[] m) {
        g(v, 0, 4, 8, 12, m[0], m[1]);
        g(v, 1, 5, 9, 13, m[2], m[3]);
        g(v, 2, 6, 10, 14, m[4], m[5]);
        g(v, 3, 7, 11, 15, m[6], m[7]);
        g(v, 0, 5, 10, 15, m[8], m[9]);
        g(v, 1, 6, 11, 12, m[10], m[11]);
        g(v, 2, 7, 8, 13, m[12], m[13]);
        g(v, 3, 4, 9, 14, m[14], m[15]);
    }

    private static void g(int[] v, int a, int b, int c, int d, int mx, int my) {
        v[a] = v[a] + v[b] + mx;
        v[d] = Integer.rotateRight(v[d] ^ v[a], 16);
        v[c] = v[c] + v[d];
        v[b] = Integer.rotateRight(v[b] ^ v[c], 12);
        v[a] = v[a] + v[b] + my;
        v[d] = Integer.rotateRight(v[d] ^ v[a], 8);
        v[c] = v[c] + v[d];
        v[b] = Integer.rotateRight(v[b] ^ v[c], 7);
    }

    private static void permute(int[] m) {
        int[] old = Arrays.copyOf(m, 16);
        for (int i = 0; i < 16; i++) {
            m[i] = old[MSG_PERMUTATION[i]];
        }
    }

    private static int[] blockWords(byte[] input, int offset, int len) {
        int[] words = new int[16];
        for (int i = 0; i < len; i++) {
            words[i / 4] |= (input[offset + i] & 0xff) << (8 * (i % 4));
        }
        return words;
    }

    private static int[] bytesToWords(byte[] bytes, int offset) {
        int[] words = new int[8];
        for (int i = 0; i < 32; i++) {
            words[i / 4] |= (bytes[offset + i] & 0xff) << (8 * (i % 4));
        }
        return words;
    }

    private static byte[] wordsToBytes(int[] words) {
        byte[] out = new byte[words.length * 4];
        for (int i = 0; i < words.length; i++) {
            int w = words[i];
            out[i * 4] = (byte) w;
            out[i * 4 + 1] = (byte) (w >>> 8);
            out[i * 4 + 2] = (byte) (w >>> 16);
            out[i * 4 + 3] = (byte) (w >>> 24);
        }
        return out;
    }

    private static int[] first8(int[] words) {
        return Arrays.copyOf(words, 8);
    }

    private static final class Output {
        private final int[] inputCv;
        private final int[] blockWords;
        private final long counter;
        private final int blockLen;
        private final int flags;

        Output(int[] inputCv, int[] blockWords, long counter, int blockLen, int flags) {
            this.inputCv = inputCv;
            this.blockWords = blockWords;
            this.counter = counter;
            this.blockLen = blockLen;
            this.flags = flags;
        }

        int[] chainingValue() {
            return first8(compress(inputCv, blockWords, counter, blockLen, flags));
        }

        byte[] rootBytes(int outLen, long seek) {
            byte[] out = new byte[outLen];
            int written = 0;
            long blockCounter = seek / 64;
            int skip = (int) (seek % 64);
            while (written < outLen) {
                byte[] block = wordsToBytes(compress(inputCv, blockWords, blockCounter, blockLen, flags | ROOT));
                int take = Math.min(outLen - written, 64 - skip);
                System.arraycopy(block, skip, out, written, take);
                written += take;
                blockCounter++;
                skip = 0;
            }
            return out;
        }
    }
}
