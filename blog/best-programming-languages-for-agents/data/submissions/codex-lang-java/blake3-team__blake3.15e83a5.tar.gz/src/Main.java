import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class Main {
    private static final String HELP = """
Usage: executable [OPTIONS] [FILE]...

Arguments:
  [FILE]...
          Files to hash, or checkfiles to check
          
          When no file is given, or when - is given, read standard input.

Options:
      --keyed
          Use the keyed mode, reading the 32-byte key from stdin

      --derive-key <CONTEXT>
          Use the key derivation mode, with the given context string
          
          Cannot be used with --keyed.

  -l, --length <LEN>
          The number of output bytes, before hex encoding
          
          [default: 32]

      --seek <SEEK>
          The starting output byte offset, before hex encoding
          
          [default: 0]

      --num-threads <NUM>
          The maximum number of threads to use
          
          By default, this is the number of logical cores. If this flag is omitted, or if its value
          is 0, RAYON_NUM_THREADS is also respected.

      --no-mmap
          Disable memory mapping
          
          Currently this also disables multithreading.

      --no-names
          Omit filenames in the output

      --raw
          Write raw output bytes to stdout, rather than hex
          
          --no-names is implied. In this case, only a single input is allowed.

      --tag
          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]

  -c, --check
          Read BLAKE3 sums from the [FILE]s and check them

      --quiet
          Skip printing OK for each checked file
          
          Must be used with --check.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
""";

    private Main() {
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            if (code != 0) {
                System.exit(code);
            }
        } catch (CliException e) {
            System.err.println("error: " + e.getMessage());
            System.exit(2);
        } catch (IOException e) {
            System.err.println("executable: " + e.getMessage());
            System.exit(1);
        }
    }

    private static int run(String[] args) throws IOException, CliException {
        Options opt = parse(args);
        if (opt.help) {
            System.out.print(HELP);
            return 0;
        }
        if (opt.version) {
            System.out.println("b3sum 1.8.4");
            return 0;
        }
        if (opt.keyed && opt.deriveContext != null) {
            throw new CliException("the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'");
        }
        if (opt.quiet && !opt.check) {
            throw new CliException("the argument '--quiet' cannot be used without '--check'");
        }
        if (opt.raw && opt.files.size() > 1) {
            throw new CliException("the argument '--raw' cannot be used with multiple inputs");
        }
        if (opt.keyed && opt.files.isEmpty()) {
            throw new CliException("the following required arguments were not provided:\n  <FILE>...\n\nUsage: b3sum --keyed <FILE>...\n\nFor more information, try '--help'.");
        }
        if (opt.check) {
            return check(opt);
        }
        return hashInputs(opt);
    }

    private static int hashInputs(Options opt) throws IOException, CliException {
        List<String> files = opt.files.isEmpty() ? List.of("-") : opt.files;
        byte[] key = null;
        if (opt.keyed) {
            key = readN(System.in, 32);
            if (key.length != 32) {
                throw new CliException("expected 32 bytes of key from stdin");
            }
        }
        for (String file : files) {
            byte[] input;
            if (file.equals("-")) {
                input = readAll(System.in);
            } else {
                input = Files.readAllBytes(Path.of(file));
            }
            byte[] digest = digest(input, opt, key);
            if (opt.raw) {
                System.out.write(digest);
            } else if (opt.noNames) {
                System.out.println(hex(digest));
            } else if (opt.tag) {
                System.out.println("BLAKE3 (" + file + ") = " + hex(digest));
            } else {
                System.out.println(hex(digest) + "  " + file);
            }
        }
        return 0;
    }

    private static int check(Options opt) throws IOException, CliException {
        List<String> files = opt.files.isEmpty() ? List.of("-") : opt.files;
        int failures = 0;
        int malformed = 0;
        for (String checkFile : files) {
            String text = checkFile.equals("-")
                    ? new String(readAll(System.in), StandardCharsets.UTF_8)
                    : Files.readString(Path.of(checkFile), StandardCharsets.UTF_8);
            String[] lines = text.split("\\R", -1);
            for (String line : lines) {
                if (line.isEmpty()) {
                    continue;
                }
                Entry entry = parseCheckLine(line);
                if (entry == null) {
                    malformed++;
                    continue;
                }
                byte[] got;
                try {
                    got = digest(Files.readAllBytes(Path.of(entry.file)), opt, null);
                } catch (IOException e) {
                    System.out.println(entry.file + ": FAILED open or read");
                    failures++;
                    continue;
                }
                if (hex(got).equalsIgnoreCase(entry.hex)) {
                    if (!opt.quiet) {
                        System.out.println(entry.file + ": OK");
                    }
                } else {
                    System.out.println(entry.file + ": FAILED");
                    failures++;
                }
            }
        }
        if (malformed > 0) {
            System.err.println("executable: WARNING: " + malformed + " line" + (malformed == 1 ? "" : "s") + " is improperly formatted");
        }
        if (failures > 0 || malformed > 0) {
            System.err.println("executable: WARNING: " + failures + " computed checksum" + (failures == 1 ? "" : "s") + " did NOT match");
            return 1;
        }
        return 0;
    }

    private static Entry parseCheckLine(String line) {
        if (line.startsWith("BLAKE3 (")) {
            int close = line.indexOf(") = ");
            if (close > 8) {
                return new Entry(line.substring(close + 4), line.substring(8, close));
            }
            return null;
        }
        int i = 0;
        while (i < line.length() && isHex(line.charAt(i))) {
            i++;
        }
        if (i == 0 || i >= line.length()) {
            return null;
        }
        String sum = line.substring(0, i);
        String rest = line.substring(i);
        if (rest.startsWith("  ") || rest.startsWith(" *")) {
            return new Entry(sum, rest.substring(2));
        }
        return null;
    }

    private static boolean isHex(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }

    private static byte[] digest(byte[] input, Options opt, byte[] key) {
        if (opt.keyed) {
            return Blake3.keyedHash(input, key, opt.length, opt.seek);
        }
        if (opt.deriveContext != null) {
            return Blake3.deriveKeyHash(input, opt.deriveContext, opt.length, opt.seek);
        }
        return Blake3.hash(input, opt.length, opt.seek);
    }

    private static Options parse(String[] args) throws CliException {
        Options opt = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h", "--help" -> opt.help = true;
                case "-V", "--version" -> opt.version = true;
                case "--keyed" -> opt.keyed = true;
                case "--derive-key" -> opt.deriveContext = requireValue(args, ++i, "--derive-key");
                case "-l", "--length" -> opt.length = parseNonNegativeInt(requireValue(args, ++i, a), a);
                case "--seek" -> opt.seek = parseNonNegativeLong(requireValue(args, ++i, a), a);
                case "--num-threads" -> {
                    parseNonNegativeLong(requireValue(args, ++i, a), a);
                }
                case "--no-mmap" -> {
                }
                case "--no-names" -> opt.noNames = true;
                case "--raw" -> {
                    opt.raw = true;
                    opt.noNames = true;
                }
                case "--tag" -> opt.tag = true;
                case "-c", "--check" -> opt.check = true;
                case "--quiet" -> opt.quiet = true;
                default -> {
                    if (a.startsWith("--length=")) {
                        opt.length = parseNonNegativeInt(a.substring(9), "--length");
                    } else if (a.startsWith("--seek=")) {
                        opt.seek = parseNonNegativeLong(a.substring(7), "--seek");
                    } else if (a.startsWith("--derive-key=")) {
                        opt.deriveContext = a.substring(13);
                    } else if (a.startsWith("--num-threads=")) {
                        parseNonNegativeLong(a.substring(14), "--num-threads");
                    } else if (a.startsWith("-") && !a.equals("-")) {
                        throw new CliException("unexpected argument '" + a + "' found");
                    } else {
                        opt.files.add(a);
                    }
                }
            }
        }
        return opt;
    }

    private static String requireValue(String[] args, int index, String flag) throws CliException {
        if (index >= args.length) {
            throw new CliException("a value is required for '" + flag + "'");
        }
        return args[index];
    }

    private static int parseNonNegativeInt(String s, String flag) throws CliException {
        long v = parseNonNegativeLong(s, flag);
        if (v > Integer.MAX_VALUE) {
            throw new CliException("invalid value '" + s + "' for '" + flag + "'");
        }
        return (int) v;
    }

    private static long parseNonNegativeLong(String s, String flag) throws CliException {
        try {
            long v = Long.parseUnsignedLong(s);
            if (v < 0) {
                throw new NumberFormatException();
            }
            return v;
        } catch (NumberFormatException e) {
            throw new CliException("invalid value '" + s + "' for '" + flag + "'");
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private static byte[] readN(InputStream in, int n) throws IOException {
        byte[] buf = new byte[n];
        int off = 0;
        while (off < n) {
            int got = in.read(buf, off, n - off);
            if (got == -1) {
                break;
            }
            off += got;
        }
        if (off == n) {
            return buf;
        }
        byte[] shortBuf = new byte[off];
        System.arraycopy(buf, 0, shortBuf, 0, off);
        return shortBuf;
    }

    static String hex(byte[] bytes) {
        char[] out = new char[bytes.length * 2];
        char[] alphabet = "0123456789abcdef".toCharArray();
        for (int i = 0; i < bytes.length; i++) {
            out[i * 2] = alphabet[(bytes[i] >>> 4) & 0xf];
            out[i * 2 + 1] = alphabet[bytes[i] & 0xf];
        }
        return new String(out);
    }

    private static final class Options {
        boolean help;
        boolean version;
        boolean keyed;
        String deriveContext;
        int length = 32;
        long seek;
        boolean noNames;
        boolean raw;
        boolean tag;
        boolean check;
        boolean quiet;
        List<String> files = new ArrayList<>();
    }

    private record Entry(String hex, String file) {
    }

    private static final class CliException extends Exception {
        CliException(String message) {
            super(message);
        }
    }
}
