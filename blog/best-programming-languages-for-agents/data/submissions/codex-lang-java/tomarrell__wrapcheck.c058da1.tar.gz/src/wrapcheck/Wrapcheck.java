package wrapcheck;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.*;

public class Wrapcheck {
    static final String HELP = "wrapcheck: Checks that errors returned from external packages are wrapped\n\n"+
        "Usage: wrapcheck [-flag] [package]\n\n\nFlags:\n"+
        "  -V\tprint version and exit\n"+
        "  -all\n    \tno effect (deprecated)\n"+
        "  -c int\n    \tdisplay offending line with this many lines of context (default -1)\n"+
        "  -cpuprofile string\n    \twrite CPU profile to this file\n"+
        "  -debug string\n    \tdebug flags, any subset of \"fpstv\"\n"+
        "  -diff\n    \twith -fix, don't update the files, but print a unified diff\n"+
        "  -fix\n    \tapply all suggested fixes\n"+
        "  -flags\n    \tprint analyzer flags in JSON\n"+
        "  -json\n    \temit JSON output\n"+
        "  -memprofile string\n    \twrite memory profile to this file\n"+
        "  -source\n    \tno effect (deprecated)\n"+
        "  -tags string\n    \tno effect (deprecated)\n"+
        "  -test\n    \tindicates whether test files should be analyzed, too (default true)\n"+
        "  -trace string\n    \twrite trace log to this file\n"+
        "  -v\tno effect (deprecated)\n";
    static final String FLAGS_JSON = "[\n"+
        "\t{\n\t\t\"Name\": \"V\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"print version and exit\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"all\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"c\",\n\t\t\"Bool\": false,\n\t\t\"Usage\": \"display offending line with this many lines of context\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"diff\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"with -fix, don't update the files, but print a unified diff\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"flags\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"print analyzer flags in JSON\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"json\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"emit JSON output\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"source\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"tags\",\n\t\t\"Bool\": false,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"test\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"indicates whether test files should be analyzed, too\"\n\t},\n"+
        "\t{\n\t\t\"Name\": \"v\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t}\n]";
    static final List<String> DEFAULT_IGNORES = Arrays.asList(".Errorf(", "errors.New(", "errors.Unwrap(", "errors.Join(", ".Wrap(", ".Wrapf(", ".WithMessage(", ".WithMessagef(", ".WithStack(");
    static class Opts { boolean json=false, test=true, flags=false, version=false; int context=-1; List<String> pkgs=new ArrayList<>(); }
    static class Config { List<String> ignores=new ArrayList<>(DEFAULT_IGNORES); List<Pattern> ignoreRegex=new ArrayList<>(); List<String> pkgGlobs=new ArrayList<>(); boolean reportInternal=false; }
    static class Diag { String pkg,path,msg,lineText; int line,col; }

    public static void main(String[] args) {
        try { int code = run(args); if (code != 0) System.exit(code); }
        catch (Exception e) { System.err.println("wrapcheck: " + e.getMessage()); System.exit(1); }
    }
    static int run(String[] args) throws Exception {
        Opts o = parse(args);
        if (o.flags) { System.out.println(FLAGS_JSON); return 0; }
        if (o.version) { System.err.println("wrapcheck: open /workspace/executable: permission denied"); return 1; }
        if (o.pkgs.isEmpty()) { System.out.println(HELP); return 1; }
        Config cfg = readConfig(Paths.get("."));
        List<Diag> diags = new ArrayList<>();
        for (String p: o.pkgs) diags.addAll(analyzePattern(p, o, cfg));
        diags.sort(Comparator.comparing((Diag d)->d.path).thenComparingInt(d->d.line).thenComparingInt(d->d.col));
        if (o.json) printJson(diags); else printText(diags, o.context);
        return diags.isEmpty()?0:3;
    }
    static Opts parse(String[] args) {
        Opts o = new Opts();
        Set<String> bools = new HashSet<>(Arrays.asList("all","diff","fix","flags","json","source","test","v"));
        Set<String> vals = new HashSet<>(Arrays.asList("c","cpuprofile","debug","memprofile","tags","trace"));
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            if (!a.startsWith("-") || a.equals("-")) { o.pkgs.add(a); continue; }
            String name=a.replaceFirst("^-+", ""), val=null;
            int eq=name.indexOf('='); if (eq>=0) { val=name.substring(eq+1); name=name.substring(0,eq); }
            if (name.equals("h") || name.equals("help")) { System.out.println(HELP); System.exit(0); }
            if (name.equals("V")) {
                if (val==null) val="true"; if (!val.equals("full")) { System.err.println("wrapcheck: unsupported flag value: -V="+val+" (use -V=full)"); System.exit(1); } o.version=true; continue;
            }
            if (!bools.contains(name) && !vals.contains(name)) { System.err.println("flag provided but not defined: -"+name); System.out.println(HELP); System.exit(2); }
            if (bools.contains(name)) { if (val==null) val="true"; if (name.equals("flags")) o.flags=Boolean.parseBoolean(val); if (name.equals("json")) o.json=Boolean.parseBoolean(val); if (name.equals("test")) o.test=Boolean.parseBoolean(val); continue; }
            if (val==null) { if (++i>=args.length) { System.err.println("flag needs an argument: -"+name); System.exit(2); } val=args[i]; }
            if (name.equals("c")) try { o.context=Integer.parseInt(val); } catch(NumberFormatException e){ System.err.println("invalid value \""+val+"\" for flag -c: parse error"); System.exit(2); }
        }
        return o;
    }
    static Config readConfig(Path start) throws IOException {
        Config c = new Config(); Path cur=start.toAbsolutePath().normalize(); Path found=null;
        while (cur!=null) { Path f=cur.resolve(".wrapcheck.yaml"); if (Files.exists(f)) { found=f; break; } cur=cur.getParent(); }
        if (found==null) { String home=System.getProperty("user.home"); if (home!=null && Files.exists(Paths.get(home,".wrapcheck.yaml"))) found=Paths.get(home,".wrapcheck.yaml"); }
        if (found==null) return c;
        List<String> lines=Files.readAllLines(found); String section=""; boolean sawIgnore=false; List<String> ignore=new ArrayList<>(), extra=new ArrayList<>();
        for (String raw: lines) { String s=raw.split("#",2)[0].trim(); if (s.isEmpty()) continue; if (!s.startsWith("-") && s.endsWith(":")) { section=s.substring(0,s.length()-1); continue; }
            if (s.contains(":")) { String[] kv=s.split(":",2); section=kv[0].trim(); String v=unq(kv[1].trim()); if (section.equals("reportInternalErrors")) c.reportInternal=v.equalsIgnoreCase("true"); continue; }
            if (s.startsWith("-")) { String v=unq(s.substring(1).trim()); if (section.equals("ignoreSigs")) { sawIgnore=true; ignore.add(v); } else if (section.equals("extraIgnoreSigs")) extra.add(v); else if (section.equals("ignoreSigRegexps")) { try { c.ignoreRegex.add(Pattern.compile(v)); } catch(Exception ignored){} } else if (section.equals("ignorePackageGlobs")) c.pkgGlobs.add(v); }
        }
        if (sawIgnore) c.ignores=new ArrayList<>(ignore); c.ignores.addAll(extra); return c;
    }
    static String unq(String s){ if ((s.startsWith("\"")&&s.endsWith("\""))||(s.startsWith("'")&&s.endsWith("'"))) return s.substring(1,s.length()-1); return s; }
    static List<Diag> analyzePattern(String pat, Opts o, Config cfg) throws IOException {
        Path base = Paths.get(pat.replaceAll("/\\.\\.\\.$", "")).normalize(); boolean rec=pat.endsWith("/..."); if (pat.equals("./...")) { base=Paths.get("."); rec=true; }
        if (!Files.exists(base)) { System.err.println("wrapcheck: "+pat+": no such file or directory"); return Collections.emptyList(); }
        List<Path> dirs = new ArrayList<>();
        if (Files.isRegularFile(base)) dirs.add(base.getParent()==null?Paths.get("."):base.getParent());
        else if (rec) try(Stream<Path> st=Files.walk(base)) { st.filter(Files::isDirectory).filter(d->!d.toString().contains("/.git")).forEach(dirs::add); }
        else dirs.add(base);
        List<Diag> out=new ArrayList<>(); String module=findModule(Paths.get("."));
        for (Path d: dirs) out.addAll(analyzeDir(d, module, o, cfg)); return out;
    }
    static String findModule(Path p) throws IOException { Path cur=p.toAbsolutePath().normalize(); while(cur!=null){ Path gm=cur.resolve("go.mod"); if(Files.exists(gm)) for(String l:Files.readAllLines(gm)) if(l.trim().startsWith("module ")) return l.trim().substring(7).trim(); cur=cur.getParent(); } return ""; }
    static List<Diag> analyzeDir(Path dir, String module, Opts o, Config cfg) throws IOException {
        if (!Files.isDirectory(dir)) return Collections.emptyList(); List<Diag> out=new ArrayList<>();
        List<Path> files; try(Stream<Path> st=Files.list(dir)) { files=st.filter(p->p.toString().endsWith(".go") && (o.test || !p.getFileName().toString().endsWith("_test.go"))).sorted().collect(Collectors.toList()); }
        if (files.isEmpty()) return out; String rel=Paths.get(".").toAbsolutePath().normalize().relativize(dir.toAbsolutePath().normalize()).toString().replace(File.separatorChar,'/'); String pkg=module.isEmpty()?rel:module+(rel.equals("")?"":"/"+rel);
        for (Path f: files) out.addAll(analyzeFile(f, pkg, module, cfg)); return out;
    }
    static List<Diag> analyzeFile(Path f, String pkg, String module, Config cfg) throws IOException {
        List<String> lines=Files.readAllLines(f); Map<String,String> imports=new HashMap<>(); Set<String> extAliases=new HashSet<>(); Set<String> extVars=new HashSet<>(); Set<String> errVars=new HashSet<>(); List<Diag> out=new ArrayList<>();
        boolean inImport=false; Pattern imp=Pattern.compile("^(?:([A-Za-z_][\\w]*)\\s+)?\"([^\"]+)\"");
        for (String raw: lines) { String s=strip(raw).trim(); if (s.startsWith("import (")) { inImport=true; continue; } if (inImport && s.startsWith(")")) { inImport=false; continue; } if (s.startsWith("import ")) s=s.substring(7).trim(); if (inImport || s.startsWith("\"")) { Matcher m=imp.matcher(s); if(m.find()){ String path=m.group(2); String alias=m.group(1); if(alias==null||alias.equals("_")||alias.equals(".")) alias=path.substring(path.lastIndexOf('/')+1).replaceAll("[^A-Za-z0-9_]", ""); imports.put(alias,path); if(isExternal(path,module,pkg,cfg)) extAliases.add(alias); } } }
        Pattern typed=Pattern.compile("\\b([A-Za-z_]\\w*)\\s+(?:\\*|\\[\\])?([A-Za-z_]\\w*)\\."); Pattern assign=Pattern.compile("(?:^|[;{]\s*)([A-Za-z_]\\w*)\\s*:?=\\s*(.+)");
        for (int i=0;i<lines.size();i++) { String no=strip(lines.get(i)); String s=no.trim(); Matcher tv=typed.matcher(s); while(tv.find()) if(extAliases.contains(tv.group(2))) extVars.add(tv.group(1)); Matcher am=assign.matcher(s); while(am.find()) { String var=am.group(1), rhs=am.group(2); if (externalExpr(rhs, extAliases, extVars, cfg) && var.toLowerCase().contains("err")) errVars.add(var); }
            Matcher ret=Pattern.compile("\\breturn\\b\\s*([^;}]*)").matcher(no);
            while(ret.find()) { String expr=ret.group(1); if (shouldFlag(expr, extAliases, extVars, errVars, cfg)) out.add(diag(f, i+1, ret.start()+1, lines.get(i))); }
        }
        return out;
    }
    static boolean isExternal(String path,String module,String pkg,Config cfg){ for(String g:cfg.pkgGlobs) if(glob(g,path)) return false; return !path.equals(pkg); }
    static boolean glob(String g,String s){ String r="^"+Pattern.quote(g).replace("*","\\E.*\\Q")+"$"; return s.matches(r); }
    static String strip(String s){ StringBuilder b=new StringBuilder(); boolean q=false; for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(c=='"' && (i==0||s.charAt(i-1)!='\\')) q=!q; if(!q && c=='/' && i+1<s.length() && s.charAt(i+1)=='/') break; b.append(c);} return b.toString(); }
    static boolean ignored(String e, Config c){ for(String ig:c.ignores) if(e.contains(ig)) return true; for(Pattern p:c.ignoreRegex) if(p.matcher(e).find()) return true; return false; }
    static boolean externalExpr(String e, Set<String>a, Set<String>v, Config c){ if(ignored(e,c)) return false; for(String x:a) if(Pattern.compile("\\b"+Pattern.quote(x)+"\\.").matcher(e).find()) return true; for(String x:v) if(Pattern.compile("\\b"+Pattern.quote(x)+"\\.").matcher(e).find()) return true; return false; }
    static boolean shouldFlag(String e, Set<String>a, Set<String>v, Set<String>errs, Config c){ if(ignored(e,c)) return false; for(String part:e.split(",")){ String p=part.trim().replaceAll("[;}]+$",""); if(errs.contains(p)) return true; } return externalExpr(e,a,v,c); }
    static Diag diag(Path f,int line,int col,String text){ Diag d=new Diag(); d.path=Paths.get(".").toAbsolutePath().normalize().relativize(f.toAbsolutePath().normalize()).toString().replace(File.separatorChar,'/'); d.line=line; d.col=col; d.msg="error returned from external package is unwrapped"; d.lineText=text; return d; }
    static void printText(List<Diag>d,int ctx){ for(Diag x:d){ System.out.println(x.path+":"+x.line+":"+x.col+": "+x.msg); if(ctx>=0){ System.out.println(x.lineText); } } }
    static void printJson(List<Diag>d){ System.out.println("{"); Map<String,List<Diag>> by=new TreeMap<>(); for(Diag x:d) by.computeIfAbsent(x.path,k->new ArrayList<>()).add(x); int fi=0; for(String file:by.keySet()){ if(fi++>0) System.out.println(","); System.out.print("\t\""+esc(file)+"\": [\n"); List<Diag> ds=by.get(file); for(int i=0;i<ds.size();i++){ Diag x=ds.get(i); System.out.print("\t\t{\"posn\": \""+esc(file+":"+x.line+":"+x.col)+"\", \"message\": \""+esc(x.msg)+"\"}"); if(i+1<ds.size()) System.out.print(","); System.out.println(); } System.out.print("\t]"); } System.out.println("\n}"); }
    static String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }
}
