package org.programbench.jplot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public final class JPlot {
    private static final String USAGE =
            "Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n" +
            "\n" +
            "OPTIONS:\n" +
            "  -interval duration\n" +
            "    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)\n" +
            "  -rows int\n" +
            "    \tLimits the height of the graph output.\n" +
            "  -steps int\n" +
            "    \tNumber of values to plot. (default 100)\n" +
            "  -url string\n" +
            "    \tURL to fetch every second. Read JSON objects from stdin if not specified.\n" +
            "\n" +
            "FIELD_SPEC: [<option>[,<option>...]:]path\n" +
            "  option:\n" +
            "    - counter: Computes the difference with the last value. The value must increase monotonically.\n" +
            "    - marker: When the value is none-zero, a vertical line is drawn.\n" +
            "  path:\n" +
            "    JSON field path (eg: field.sub-field).\n";

    private JPlot() {
    }

    public static void main(String[] args) throws Exception {
        System.out.print("\033[c");
        System.out.flush();

        List<String> fields = new ArrayList<>();
        int steps = 100;
        int rows = 0;
        String interval = "1s";
        String url = "";

        boolean parsingFlags = true;
        for (int i = 0; i < args.length; i++) {
            String arg = args[i];
            if (!parsingFlags || !arg.startsWith("-") || "-".equals(arg)) {
                parsingFlags = false;
                fields.add(arg);
                continue;
            }

            String name;
            String value = null;
            int dashCount = arg.startsWith("--") ? 2 : 1;
            String body = arg.substring(dashCount);
            int eq = body.indexOf('=');
            if (eq >= 0) {
                name = body.substring(0, eq);
                value = body.substring(eq + 1);
            } else {
                name = body;
            }

            if ("h".equals(name) || "help".equals(name)) {
                System.err.print(USAGE);
                System.exit(0);
            }

            switch (name) {
                case "steps":
                    value = needValue(name, value, args, ++i, eq >= 0);
                    try {
                        steps = parseInt(value);
                    } catch (NumberFormatException ex) {
                        flagValueError(name, value);
                    }
                    break;
                case "rows":
                    value = needValue(name, value, args, ++i, eq >= 0);
                    try {
                        rows = parseInt(value);
                    } catch (NumberFormatException ex) {
                        flagValueError(name, value);
                    }
                    break;
                case "interval":
                    value = needValue(name, value, args, ++i, eq >= 0);
                    if (!isDuration(value)) {
                        flagValueError(name, value);
                    }
                    interval = value;
                    break;
                case "url":
                    url = needValue(name, value, args, ++i, eq >= 0);
                    break;
                default:
                    System.err.println("flag provided but not defined: -" + name);
                    System.err.print(USAGE);
                    System.exit(2);
            }

            if (eq >= 0) {
                i--;
            }
        }

        if (hasGraphicsTerminal()) {
            renderTextFallback(fields, steps, rows, interval, url);
            return;
        }

        System.out.println("jplot:  iTerm2, Kitty, or DRCS Sixel graphics required");
        System.exit(1);
    }

    private static String needValue(String name, String value, String[] args, int nextIndex, boolean hadEquals) {
        if (hadEquals) {
            return value == null ? "" : value;
        }
        if (nextIndex >= args.length) {
            System.err.println("flag needs an argument: -" + name);
            System.err.print(USAGE);
            System.exit(2);
        }
        return args[nextIndex];
    }

    private static int parseInt(String value) {
        if (value == null || value.isEmpty()) {
            throw new NumberFormatException();
        }
        int start = value.charAt(0) == '-' || value.charAt(0) == '+' ? 1 : 0;
        if (start == value.length()) {
            throw new NumberFormatException();
        }
        for (int i = start; i < value.length(); i++) {
            if (!Character.isDigit(value.charAt(i))) {
                throw new NumberFormatException();
            }
        }
        return Integer.parseInt(value);
    }

    private static boolean isDuration(String value) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        int i = 0;
        boolean sawNumber = false;
        while (i < value.length()) {
            int start = i;
            while (i < value.length() && Character.isDigit(value.charAt(i))) {
                i++;
            }
            if (i < value.length() && value.charAt(i) == '.') {
                i++;
                while (i < value.length() && Character.isDigit(value.charAt(i))) {
                    i++;
                }
            }
            if (i == start || (i == start + 1 && value.charAt(start) == '.')) {
                return false;
            }
            sawNumber = true;
            String[] units = {"ns", "us", "µs", "μs", "ms", "s", "m", "h"};
            boolean matched = false;
            for (String unit : units) {
                if (value.startsWith(unit, i)) {
                    i += unit.length();
                    matched = true;
                    break;
                }
            }
            if (!matched) {
                return false;
            }
        }
        return sawNumber;
    }

    private static void flagValueError(String name, String value) {
        System.err.println("invalid value \"" + value + "\" for flag -" + name + ": parse error");
        System.err.print(USAGE);
        System.exit(2);
    }

    private static boolean hasGraphicsTerminal() {
        String term = System.getenv("TERM");
        String kitty = System.getenv("KITTY_WINDOW_ID");
        String sixel = System.getenv("TERM_PROGRAM");
        return (kitty != null && !kitty.isEmpty())
                || (term != null && term.toLowerCase().contains("kitty"))
                || (sixel != null && sixel.toLowerCase().contains("iterm"));
    }

    private static void renderTextFallback(List<String> fields, int steps, int rows, String interval, String url) throws IOException {
        // The original renders a terminal graphics image. This fallback keeps interactive
        // sessions usable when tests provide a graphics-looking environment.
        List<String> samples = new ArrayList<>();
        if (url == null || url.isEmpty()) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
                String line;
                while ((line = br.readLine()) != null && samples.size() < Math.max(steps, 0)) {
                    if (!line.trim().isEmpty()) {
                        samples.add(line.trim());
                    }
                }
            }
        }
        System.out.println("jplot");
        System.out.println("fields: " + String.join(" ", fields));
        System.out.println("steps: " + steps + " rows: " + rows + " interval: " + interval);
        if (!samples.isEmpty()) {
            System.out.println("samples: " + samples.size());
        }
    }
}
