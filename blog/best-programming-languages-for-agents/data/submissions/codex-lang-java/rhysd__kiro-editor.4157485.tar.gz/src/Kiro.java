import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Kiro {
    private static final String VERSION = "0.4.3";
    private static final String HELP = "./executable: A tiny UTF-8 terminal text editor\n\n" +
            "Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.\n" +
            "Specify file paths to edit as a command argument or run without argument to\n" +
            "start to write a new text.\n" +
            "Help can show up with key mapping Ctrl-?.\n\n" +
            "Usage:\n" +
            "    ./executable [options] [FILES...]\n\n" +
            "Mappings:\n" +
            "    Ctrl-Q                        : Quit\n" +
            "    Ctrl-S                        : Save to file\n" +
            "    Ctrl-O                        : Open text buffer\n" +
            "    Ctrl-X                        : Next text buffer\n" +
            "    Alt-X                         : Previous text buffer\n" +
            "    Ctrl-P or UP                  : Move cursor up\n" +
            "    Ctrl-N or DOWN                : Move cursor down\n" +
            "    Ctrl-F or RIGHT               : Move cursor right\n" +
            "    Ctrl-B or LEFT                : Move cursor left\n" +
            "    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line\n" +
            "    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line\n" +
            "    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page\n" +
            "    Ctrl-] or Alt-V or PAGE UP    : Previous page\n" +
            "    Alt-F or Ctrl-RIGHT           : Move cursor to next word\n" +
            "    Alt-B or Ctrl-LEFT            : Move cursor to previous word\n" +
            "    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph\n" +
            "    Alt-P or Ctrl-UP              : Move cursor to previous paragraph\n" +
            "    Alt-<                         : Move cursor to top of file\n" +
            "    Alt->                         : Move cursor to bottom of file\n" +
            "    Ctrl-H or BACKSPACE           : Delete character\n" +
            "    Ctrl-D or DELETE              : Delete next character\n" +
            "    Ctrl-W                        : Delete a word\n" +
            "    Ctrl-J                        : Delete until head of line\n" +
            "    Ctrl-K                        : Delete until end of line\n" +
            "    Ctrl-U                        : Undo last change\n" +
            "    Ctrl-R                        : Redo last undo change\n" +
            "    Ctrl-G                        : Search text\n" +
            "    Ctrl-M                        : New line\n" +
            "    Ctrl-L                        : Refresh screen\n" +
            "    Ctrl-?                        : Show this help\n\n" +
            "Options:\n" +
            "    -v, --version       Print version\n" +
            "    -h, --help          Print this help\n";

    public static void main(String[] args) {
        try {
            new Kiro().run(args);
        } catch (CliError e) {
            System.err.println("Error: " + e.getMessage() + ". Please see --help for more details");
            System.exit(1);
        } catch (Throwable t) {
            String msg = t.getMessage();
            if (msg == null || msg.isEmpty()) msg = t.toString();
            System.err.println("Error: " + msg);
            System.exit(1);
        }
    }

    private void run(String[] args) throws Exception {
        List<String> files = parseArgs(args);
        if (System.console() == null && files.isEmpty()) {
            System.exit(1);
        }
        Editor editor = new Editor(files);
        editor.loop();
    }

    private List<String> parseArgs(String[] args) throws CliError {
        List<String> files = new ArrayList<>();
        for (String arg : args) {
            if (arg.equals("--help")) {
                System.out.print(HELP + "\n");
                System.exit(0);
            } else if (arg.equals("--version")) {
                System.out.println(VERSION);
                System.exit(0);
            } else if (arg.startsWith("--") && arg.length() > 2) {
                int eq = arg.indexOf('=');
                String opt = eq >= 0 ? arg.substring(2, eq) : arg.substring(2);
                if (opt.equals("help") || opt.equals("version")) {
                    throw new CliError("Option '" + opt + "' does not take an argument");
                }
                throw new CliError("Unrecognized option: '" + opt + "'");
            } else if (arg.startsWith("-") && arg.length() > 1) {
                for (int i = 1; i < arg.length(); i++) {
                    char c = arg.charAt(i);
                    if (c == 'h') {
                        System.out.print(HELP + "\n");
                        System.exit(0);
                    } else if (c == 'v') {
                        System.out.println(VERSION);
                        System.exit(0);
                    } else {
                        throw new CliError("Unrecognized option: '" + c + "'");
                    }
                }
            } else {
                files.add(arg);
            }
        }
        return files;
    }

    private static class CliError extends Exception {
        CliError(String msg) { super(msg); }
    }

    private static class Editor {
        private final List<String> lines = new ArrayList<>();
        private final Path file;
        private int cx, cy, rowoff, coloff;
        private int rows = 24, cols = 80;
        private boolean dirty;
        private String status = "HELP: Ctrl-S = save | Ctrl-Q = quit | Ctrl-? = help";
        private String originalStty = "";

        Editor(List<String> files) throws IOException {
            this.file = files.isEmpty() ? null : Paths.get(files.get(0));
            if (file != null && Files.exists(file)) {
                String text = Files.readString(file, StandardCharsets.UTF_8);
                lines.addAll(Arrays.asList(text.split("\\R", -1)));
                if (!text.isEmpty() && (text.endsWith("\n") || text.endsWith("\r"))) {
                    lines.remove(lines.size() - 1);
                }
            }
            if (lines.isEmpty()) lines.add("");
            sizeFromEnv();
        }

        void loop() throws IOException, InterruptedException {
            boolean raw = enableRawMode();
            try {
                refresh();
                while (true) {
                    int key = readKey();
                    if (key < 0) break;
                    if (handle(key)) break;
                    refresh();
                }
            } finally {
                if (raw) disableRawMode();
                System.out.print("\u001b[?25h\u001b[2J\u001b[H");
                System.out.flush();
            }
        }

        private boolean handle(int key) throws IOException {
            switch (key) {
                case 17: // Ctrl-Q
                    return true;
                case 19: // Ctrl-S
                    save();
                    return false;
                case 12: // Ctrl-L
                    return false;
                case 1: // Ctrl-A
                    cx = 0;
                    return false;
                case 5: // Ctrl-E
                    cx = line().length();
                    return false;
                case 13:
                case 10:
                    newline();
                    return false;
                case 8:
                case 127:
                    backspace();
                    return false;
                case 4:
                    deleteForward();
                    return false;
                case 11:
                    killToEnd();
                    return false;
                case 21:
                    status = "Already at oldest change";
                    return false;
                case 18:
                    status = "Already at newest change";
                    return false;
                case 7:
                    status = "Search is not available in this build";
                    return false;
                case 31:
                    status = "Kiro " + VERSION + " | Ctrl-Q quit | Ctrl-S save";
                    return false;
                case 1000:
                    moveLeft();
                    return false;
                case 1001:
                    moveRight();
                    return false;
                case 1002:
                    moveUp();
                    return false;
                case 1003:
                    moveDown();
                    return false;
                case 1004:
                    cy = 0; cx = 0;
                    return false;
                case 1005:
                    cy = lines.size() - 1; cx = line().length();
                    return false;
                default:
                    if (key >= 32 && key != 127) insertCodePoint(key);
                    return false;
            }
        }

        private void refresh() {
            scroll();
            StringBuilder b = new StringBuilder();
            b.append("\u001b[?25l\u001b[H");
            int screenRows = Math.max(1, rows - 2);
            for (int y = 0; y < screenRows; y++) {
                int filerow = y + rowoff;
                b.append("\u001b[K");
                if (filerow >= lines.size()) {
                    if (lines.size() == 1 && lines.get(0).isEmpty() && y == screenRows / 3) {
                        String welcome = "Kiro editor -- version " + VERSION;
                        int pad = Math.max(0, (cols - welcome.length()) / 2);
                        if (pad > 0) {
                            b.append('~');
                            pad--;
                        }
                        for (int i = 0; i < pad; i++) b.append(' ');
                        b.append(truncate(welcome, cols));
                    } else {
                        b.append('~');
                    }
                } else {
                    String s = lines.get(filerow);
                    if (coloff < s.length()) s = s.substring(coloff);
                    b.append(truncate(s, cols));
                }
                b.append("\r\n");
            }
            b.append("\u001b[7m");
            String name = file == null ? "[No Name]" : file.toString();
            String left = name + (dirty ? " (modified)" : "") + " - " + lines.size() + " lines";
            String right = (cy + 1) + "/" + lines.size();
            b.append(truncate(left, Math.max(0, cols - right.length())));
            while (visibleLen(left) < cols - right.length()) {
                b.append(' ');
                left += " ";
            }
            b.append(right);
            b.append("\u001b[m\r\n\u001b[K");
            b.append(truncate(status, cols));
            int cursorY = (cy - rowoff) + 1;
            int cursorX = (cx - coloff) + 1;
            b.append("\u001b[").append(Math.max(1, cursorY)).append(';').append(Math.max(1, cursorX)).append('H');
            b.append("\u001b[?25h");
            System.out.print(b);
            System.out.flush();
        }

        private int readKey() throws IOException {
            int c = System.in.read();
            if (c == 27) {
                System.in.mark(8);
                int a = System.in.read();
                if (a == '[') {
                    int b = System.in.read();
                    if (b >= '0' && b <= '9') {
                        int tilde = System.in.read();
                        if (tilde == '~') {
                            if (b == '1' || b == '7') return 1004;
                            if (b == '4' || b == '8') return 1005;
                            if (b == '5') { pageUp(); return 0; }
                            if (b == '6') { pageDown(); return 0; }
                        }
                    } else {
                        if (b == 'D') return 1000;
                        if (b == 'C') return 1001;
                        if (b == 'A') return 1002;
                        if (b == 'B') return 1003;
                        if (b == 'H') return 1004;
                        if (b == 'F') return 1005;
                    }
                } else if (a == '<') {
                    return 1004;
                } else if (a == '>') {
                    return 1005;
                } else if (a == 'v' || a == 'V') {
                    pageUp();
                    return 0;
                }
                return 0;
            }
            if (c < 0) return -1;
            if (c < 128) return c;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            out.write(c);
            int needed = (c & 0xE0) == 0xC0 ? 1 : ((c & 0xF0) == 0xE0 ? 2 : 3);
            for (int i = 0; i < needed; i++) {
                int n = System.in.read();
                if (n < 0) break;
                out.write(n);
            }
            String s = out.toString(StandardCharsets.UTF_8);
            return s.codePointAt(0);
        }

        private void insertCodePoint(int cp) {
            String s = line();
            String ch = new String(Character.toChars(cp));
            lines.set(cy, s.substring(0, cx) + ch + s.substring(cx));
            cx += ch.length();
            dirty = true;
        }

        private void newline() {
            String s = line();
            lines.set(cy, s.substring(0, cx));
            lines.add(cy + 1, s.substring(cx));
            cy++;
            cx = 0;
            dirty = true;
        }

        private void backspace() {
            if (cx == 0 && cy == 0) return;
            if (cx > 0) {
                String s = line();
                int prev = s.offsetByCodePoints(cx, -1);
                lines.set(cy, s.substring(0, prev) + s.substring(cx));
                cx = prev;
            } else {
                int oldLen = lines.get(cy - 1).length();
                lines.set(cy - 1, lines.get(cy - 1) + line());
                lines.remove(cy);
                cy--;
                cx = oldLen;
            }
            dirty = true;
        }

        private void deleteForward() {
            if (cx < line().length()) {
                String s = line();
                int next = s.offsetByCodePoints(cx, 1);
                lines.set(cy, s.substring(0, cx) + s.substring(next));
                dirty = true;
            } else if (cy + 1 < lines.size()) {
                lines.set(cy, line() + lines.get(cy + 1));
                lines.remove(cy + 1);
                dirty = true;
            }
        }

        private void killToEnd() {
            String s = line();
            if (cx < s.length()) {
                lines.set(cy, s.substring(0, cx));
                dirty = true;
            } else if (cy + 1 < lines.size()) {
                lines.set(cy, s + lines.get(cy + 1));
                lines.remove(cy + 1);
                dirty = true;
            }
        }

        private void save() throws IOException {
            if (file == null) {
                status = "No file name";
                return;
            }
            Files.writeString(file, String.join("\n", lines) + "\n", StandardCharsets.UTF_8);
            dirty = false;
            status = lines.size() + " lines written to " + file;
        }

        private void moveLeft() {
            if (cx > 0) cx = line().offsetByCodePoints(cx, -1);
            else if (cy > 0) {
                cy--;
                cx = line().length();
            }
        }

        private void moveRight() {
            if (cx < line().length()) cx = line().offsetByCodePoints(cx, 1);
            else if (cy + 1 < lines.size()) {
                cy++;
                cx = 0;
            }
        }

        private void moveUp() {
            if (cy > 0) cy--;
            clampCx();
        }

        private void moveDown() {
            if (cy + 1 < lines.size()) cy++;
            clampCx();
        }

        private void pageUp() {
            cy = Math.max(0, cy - Math.max(1, rows - 2));
            clampCx();
        }

        private void pageDown() {
            cy = Math.min(lines.size() - 1, cy + Math.max(1, rows - 2));
            clampCx();
        }

        private void clampCx() {
            if (cx > line().length()) cx = line().length();
        }

        private void scroll() {
            if (cy < rowoff) rowoff = cy;
            if (cy >= rowoff + rows - 2) rowoff = cy - rows + 3;
            if (cx < coloff) coloff = cx;
            if (cx >= coloff + cols) coloff = cx - cols + 1;
        }

        private String line() {
            return lines.get(cy);
        }

        private void sizeFromEnv() {
            try {
                String l = System.getenv("LINES");
                String c = System.getenv("COLUMNS");
                if (l != null) rows = Math.max(3, Integer.parseInt(l));
                if (c != null) cols = Math.max(10, Integer.parseInt(c));
            } catch (NumberFormatException ignored) {
            }
        }

        private boolean enableRawMode() {
            try {
                originalStty = shell("stty -g < /dev/tty").trim();
                shell("stty raw -echo -ixon < /dev/tty");
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        private void disableRawMode() {
            if (!originalStty.isEmpty()) {
                try {
                    shell("stty " + originalStty + " < /dev/tty");
                } catch (Exception ignored) {
                }
            }
        }

        private static String shell(String cmd) throws IOException, InterruptedException {
            Process p = new ProcessBuilder("bash", "-lc", cmd).redirectErrorStream(true).start();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            p.getInputStream().transferTo(out);
            int code = p.waitFor();
            if (code != 0) throw new IOException(out.toString(StandardCharsets.UTF_8));
            return out.toString(StandardCharsets.UTF_8);
        }

        private static String truncate(String s, int width) {
            if (width <= 0) return "";
            int count = s.codePointCount(0, s.length());
            if (count <= width) return s;
            int end = s.offsetByCodePoints(0, width);
            return s.substring(0, end);
        }

        private static int visibleLen(String s) {
            return s.codePointCount(0, s.length());
        }
    }
}
