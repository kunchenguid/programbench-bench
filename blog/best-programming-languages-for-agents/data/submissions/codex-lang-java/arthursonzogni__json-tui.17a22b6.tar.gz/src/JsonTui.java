import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class JsonTui {
    static final String RESET_FG = "\033[39m\033[49m";
    static final String BLUE = "\033[94m\033[49m";
    static final String GREEN = "\033[92m\033[49m";
    static final String CYAN = "\033[96m\033[49m";
    static final String YELLOW = "\033[93m\033[49m";
    static final String RED = "\033[91m\033[49m";
    static final String BOLD = "\033[1m";
    static final String UNBOLD = "\033[22m";
    static int lastLines = 0;
    static int lastWidth = 0;
    static boolean lastFullscreen = false;

    sealed interface J permits Obj, Arr, Str, Num, Bool, Nil {}
    static final class Obj implements J { final TreeMap<String,J> m = new TreeMap<>(); }
    static final class Arr implements J { final List<J> a = new ArrayList<>(); }
    static final class Str implements J { final String s; Str(String s){this.s=s;} }
    static final class Num implements J { final String s; Num(String s){this.s=s;} }
    static final class Bool implements J { final boolean b; Bool(boolean b){this.b=b;} }
    static final class Nil implements J {}

    public static void main(String[] args) throws Exception {
        boolean fullscreen = false;
        String file = null;
        boolean positional = false;
        for (String arg : args) {
            if (!positional && arg.equals("--")) { positional = true; continue; }
            if (!positional && (arg.equals("-h") || arg.equals("--help"))) { printHelp(); return; }
            if (!positional && (arg.equals("-v") || arg.equals("--version"))) { System.out.println("1.4.1"); return; }
            if (!positional && (arg.equals("-k") || arg.equals("--key") || arg.equals("--keybinding"))) { printKeys(); return; }
            if (!positional && (arg.equals("-f") || arg.equals("--fullscreen"))) { fullscreen = true; continue; }
            if (!positional && arg.startsWith("-")) { System.out.println("Invalid arguments"); System.exit(1); }
            if (file != null) { System.out.println("Invalid arguments"); System.exit(1); }
            file = arg;
        }

        String input;
        if (file == null) {
            System.out.print("Reading from stdin...\0");
            input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        } else {
            try {
                input = Files.readString(Path.of(file), StandardCharsets.UTF_8);
            } catch (IOException e) {
                System.out.println("Could not open file " + file);
                System.exit(1);
                return;
            }
        }

        J root;
        try {
            root = new Parser(input).parse();
        } catch (ParseException e) {
            System.out.println();
            System.out.println(e.getMessage());
            System.exit(1);
            return;
        }

        List<String> lines = new Renderer().render(root);
        draw(lines, fullscreen);
        Runtime.getRuntime().addShutdownHook(new Thread(JsonTui::cleanup));
        waitForever();
    }

    static void printHelp() {
        System.out.print("""
  json-tui {OPTIONS} [file]

    A JSON terminal UI

  OPTIONS:

      file                              A JSON file. Omit to read from stdin.
      -h, --help                        Display this help menu.
      -v, --version                     Print version.
      -k, --key, --keybinding           Display key binding.
      -f, --fullscreen                  Display the JSON in fullscreen, in an
                                        alternate buffer
      "--" can be used to terminate flag options and force all following
      arguments to be treated as positional options

    If no file is given, json-tui reads JSON from the standard input
    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues
""");
    }

    static void printKeys() {
        System.out.print("┌───────────┬────────────────┐\r\n");
        System.out.print("│\033[36m\033[49mkeys       \033[39m\033[49m│\033[36m\033[49maction          \033[39m\033[49m│\r\n");
        System.out.print("├───────────┼────────────────┤\r\n");
        System.out.print("│Navigate   │← ↑ ↓ →         │\r\n");
        System.out.print("│           │h j k l         │\r\n");
        System.out.print("│           │Mouse::WheelUp  │\r\n");
        System.out.print("│           │Mouse::WheelDown│\r\n");
        System.out.print("├───────────┼────────────────┤\r\n");
        System.out.print("│Toggle     │enter           │\r\n");
        System.out.print("│           │Mouse::Left     │\r\n");
        System.out.print("├───────────┼────────────────┤\r\n");
        System.out.print("│Deep       │                │\r\n");
        System.out.print("│ - Expand  │+               │\r\n");
        System.out.print("│ - Collapse│-               │\r\n");
        System.out.print("├───────────┼────────────────┤\r\n");
        System.out.print("│Exit       │Escape          │\r\n");
        System.out.print("│           │q               │\r\n");
        System.out.print("├───────────┼────────────────┤\r\n");
        System.out.print("│Navigate   │                │\r\n");
        System.out.print("│ - first   │page-up         │\r\n");
        System.out.print("│ - last    │page-down       │\r\n");
        System.out.print("│ - top     │gg              │\r\n");
        System.out.print("│ - bottom  │G               │\r\n");
        System.out.print("└───────────┴────────────────┘\0\n");
    }

    static void draw(List<String> lines, boolean fullscreen) {
        System.out.print("\0\033P$q q\033\\");
        if (fullscreen) System.out.print("\033[?1049h");
        System.out.print("\033[?7l\033[?1000h\033[?1003h\033[?1015h\033[?1006h\0");
        int width = fullscreen ? 80 : Math.max(1, lines.stream().mapToInt(JsonTui::plainLength).max().orElse(1));
        lastLines = lines.size();
        lastWidth = width;
        lastFullscreen = fullscreen;
        for (int i = 0; i < lines.size(); i++) {
            System.out.print("\r\033[2K");
            String line = lines.get(i);
            if (i == 0 && !line.isEmpty()) {
                System.out.print("\033[7m" + line.charAt(0) + "\033[27m" + line.substring(1));
            } else {
                System.out.print(line);
            }
            int pad = Math.max(0, width - plainLength(line));
            System.out.print(" ".repeat(pad));
            if (i + 1 < lines.size()) System.out.print("\r\n");
        }
        System.out.print("\033[" + lines.size() + "A\033[" + width + "D\033[?25l\0");
        System.out.flush();
    }

    static void cleanup() {
        if (lastLines <= 0) return;
        System.out.print("\033[" + lastLines + "B\033[" + lastWidth + "C");
        System.out.print("\033[?1006l\033[?1015l\033[?1003l\033[?1000l\033[?7h\033[?25h");
        if (lastFullscreen) System.out.print("\033[?1049l");
        System.out.print("\033[1 q\0\r\n");
        System.out.flush();
    }

    static int plainLength(String s) {
        int n = 0;
        boolean esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc) { if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) esc = false; continue; }
            if (c == 27) { esc = true; continue; }
            n++;
        }
        return n;
    }

    static void waitForever() throws InterruptedException {
        while (true) Thread.sleep(1_000_000);
    }

    static final class Renderer {
        List<String> out = new ArrayList<>();
        List<String> render(J j) { emit(j, 0, false, true); return out; }

        void emit(J j, int indent, boolean comma, boolean top) {
            if (j instanceof Obj o) emitObj(o, indent, comma);
            else if (j instanceof Arr a) emitArr(a, indent, comma, top);
            else out.add(" ".repeat(indent) + scalar(j) + (comma ? "," : ""));
        }

        void emitObj(Obj o, int indent, boolean comma) {
            String open = indent == 0 ? "{" : BOLD + "{" + UNBOLD;
            out.add(" ".repeat(indent) + open);
            int i = 0, sz = o.m.size();
            for (Map.Entry<String,J> e : o.m.entrySet()) {
                boolean c = ++i < sz;
                J v = e.getValue();
                String p = " ".repeat(indent + 2) + BLUE + quote(e.getKey()) + RESET_FG + ": ";
                if (v instanceof Obj oo) {
                    out.add(p + BOLD + "{" + UNBOLD);
                    int j = 0, os = oo.m.size();
                    for (Map.Entry<String,J> ne : oo.m.entrySet()) {
                        out.add(" ".repeat(indent + 4) + BLUE + quote(ne.getKey()) + RESET_FG + ": " + valueInline(ne.getValue()) + (++j < os ? "," : ""));
                    }
                    out.add(" ".repeat(indent + 2) + "}" + (c ? "," : ""));
                } else {
                    out.add(p + valueInline(v) + (c ? "," : ""));
                }
            }
            out.add(" ".repeat(indent) + "}" + (comma ? "," : ""));
        }

        void emitArr(Arr a, int indent, boolean comma, boolean top) {
            if (!top) { out.add(" ".repeat(indent) + BOLD + "[...]" + UNBOLD + (comma ? "," : "")); return; }
            out.add(" ".repeat(indent) + "[");
            for (int i = 0; i < a.a.size(); i++) out.add(" ".repeat(indent + 2) + valueInline(a.a.get(i)) + (i + 1 < a.a.size() ? "," : ""));
            out.add(" ".repeat(indent) + "]" + (comma ? "," : ""));
        }

        String valueInline(J v) {
            if (v instanceof Arr) return BOLD + "[...]" + UNBOLD;
            if (v instanceof Obj) return BOLD + "{...}" + UNBOLD;
            return scalar(v);
        }
        String scalar(J v) {
            if (v instanceof Str s) return GREEN + quote(s.s) + RESET_FG;
            if (v instanceof Num n) return CYAN + n.s + RESET_FG;
            if (v instanceof Bool b) return YELLOW + b.b + RESET_FG;
            return RED + "null" + RESET_FG;
        }
        String quote(String s) { return "\"" + escape(s) + "\""; }
        String escape(String s) {
            StringBuilder b = new StringBuilder();
            for (char c : s.toCharArray()) {
                switch (c) {
                    case '"' -> b.append("\\\"");
                    case '\\' -> b.append("\\\\");
                    case '\b' -> b.append("\\b");
                    case '\f' -> b.append("\\f");
                    case '\n' -> b.append("\\n");
                    case '\r' -> b.append("\\r");
                    case '\t' -> b.append("\\t");
                    default -> { if (c < 32) b.append(String.format("\\u%04x", (int)c)); else b.append(c); }
                }
            }
            return b.toString();
        }
    }

    static final class ParseException extends RuntimeException {
        ParseException(String m) { super(m); }
    }

    static final class Parser {
        final String s; int p = 0;
        Parser(String s){this.s=s;}
        J parse() { skip(); J v = value(); skip(); if (p != s.length()) err("unexpected character"); return v; }
        J value() {
            skip();
            if (p >= s.length()) err("unexpected end of input");
            char c = s.charAt(p);
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (c == '"') return new Str(str());
            if (c == '-' || Character.isDigit(c)) return num();
            if (match("true")) return new Bool(true);
            if (match("false")) return new Bool(false);
            if (match("null")) return new Nil();
            err("syntax error while parsing value");
            return null;
        }
        Obj obj() {
            Obj o = new Obj(); p++; skip();
            if (peek('}')) { p++; return o; }
            while (true) {
                skip(); if (!peek('"')) err("syntax error while parsing object key - invalid literal; expected string literal");
                String k = str(); skip(); if (!peek(':')) err("expected ':'"); p++;
                o.m.put(k, value()); skip();
                if (peek('}')) { p++; return o; }
                if (!peek(',')) err("expected ',' or '}'"); p++;
            }
        }
        Arr arr() {
            Arr a = new Arr(); p++; skip();
            if (peek(']')) { p++; return a; }
            while (true) {
                a.a.add(value()); skip();
                if (peek(']')) { p++; return a; }
                if (!peek(',')) err("expected ',' or ']'"); p++;
            }
        }
        String str() {
            StringBuilder b = new StringBuilder(); p++;
            while (p < s.length()) {
                char c = s.charAt(p++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    if (p >= s.length()) err("invalid string escape");
                    char e = s.charAt(p++);
                    switch (e) {
                        case '"','\\','/' -> b.append(e);
                        case 'b' -> b.append('\b');
                        case 'f' -> b.append('\f');
                        case 'n' -> b.append('\n');
                        case 'r' -> b.append('\r');
                        case 't' -> b.append('\t');
                        case 'u' -> {
                            if (p + 4 > s.length()) err("invalid unicode escape");
                            b.append((char)Integer.parseInt(s.substring(p, p + 4), 16)); p += 4;
                        }
                        default -> err("invalid string escape");
                    }
                } else b.append(c);
            }
            err("unterminated string");
            return "";
        }
        Num num() {
            int start = p;
            if (peek('-')) p++;
            if (peek('0')) p++; else { if (p >= s.length() || !Character.isDigit(s.charAt(p))) err("invalid number"); while (p < s.length() && Character.isDigit(s.charAt(p))) p++; }
            if (peek('.')) { p++; if (p >= s.length() || !Character.isDigit(s.charAt(p))) err("invalid number"); while (p < s.length() && Character.isDigit(s.charAt(p))) p++; }
            if (p < s.length() && (s.charAt(p) == 'e' || s.charAt(p) == 'E')) { p++; if (p < s.length() && (s.charAt(p) == '+' || s.charAt(p) == '-')) p++; if (p >= s.length() || !Character.isDigit(s.charAt(p))) err("invalid number"); while (p < s.length() && Character.isDigit(s.charAt(p))) p++; }
            return new Num(s.substring(start, p));
        }
        boolean match(String x) { if (s.startsWith(x, p)) { p += x.length(); return true; } return false; }
        boolean peek(char c) { return p < s.length() && s.charAt(p) == c; }
        void skip() { while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++; }
        void err(String m) { throw new ParseException("[json.exception.parse_error.101] parse error at line " + line() + ", column " + col() + ": " + m); }
        int line() { int l = 1; for (int i=0;i<p && i<s.length();i++) if (s.charAt(i)=='\n') l++; return l; }
        int col() { int c = 1; for (int i=p-1;i>=0 && i<s.length();i--) { if (s.charAt(i)=='\n') break; c++; } return c; }
    }
}
