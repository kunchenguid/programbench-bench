import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class Hwatch {
    private static final String VERSION = "hwatch 0.3.19";
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final String DIM = "\u001B[38;5;240m";
    private static final String RESET = "\u001B[0m";

    static class Options {
        boolean batch = false;
        boolean beep = false;
        boolean border = false;
        boolean scrollbar = false;
        boolean mouse = false;
        boolean color = false;
        boolean reverse = false;
        boolean compress = false;
        boolean noTitle = false;
        boolean enableSummaryChar = false;
        boolean lineNumber = false;
        boolean noHelpBanner = false;
        boolean noSummary = false;
        boolean exec = false;
        boolean diffOutputOnly = false;
        boolean precise = false;
        String afterCommand = null;
        String logfile = null;
        String shell = "sh -c";
        double interval = 2.0;
        long limit = 5000;
        int tabSize = 4;
        String differences = null;
        String output = "output";
        final List<String> keymaps = new ArrayList<>();
        final List<String> command = new ArrayList<>();
    }

    static class CommandResult {
        int status;
        String stdout;
        String stderr;
    }

    public static void main(String[] args) {
        try {
            List<String> merged = new ArrayList<>();
            String env = System.getenv("HWATCH");
            if (env != null && !env.trim().isEmpty()) {
                merged.addAll(splitShellLike(env));
            }
            merged.addAll(Arrays.asList(args));

            for (String a : merged) {
                if (a.equals("-h") || a.equals("--help")) {
                    printHelp();
                    return;
                }
                if (a.equals("-V") || a.equals("--version")) {
                    System.out.println(VERSION);
                    return;
                }
            }

            Options opt = parse(merged);
            if (opt.command.isEmpty()) {
                if (opt.logfile != null && Files.exists(Path.of(opt.logfile)) && Files.size(Path.of(opt.logfile)) > 0) {
                    replayLog(opt);
                    return;
                }
                usageError("command not specified and logfile is empty.");
                return;
            }
            runLoop(opt);
        } catch (UsageException e) {
            System.err.print(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    private static Options parse(List<String> args) throws UsageException {
        Options o = new Options();
        boolean endOpts = false;
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (endOpts) {
                o.command.add(a);
                continue;
            }
            if (a.equals("--")) {
                endOpts = true;
            } else if (a.equals("-b") || a.equals("--batch")) {
                o.batch = true;
            } else if (a.equals("-B") || a.equals("--beep")) {
                o.beep = true;
            } else if (a.equals("--border")) {
                o.border = true;
            } else if (a.equals("--with-scrollbar")) {
                o.scrollbar = true;
            } else if (a.equals("--mouse")) {
                o.mouse = true;
            } else if (a.equals("-c") || a.equals("--color")) {
                o.color = true;
            } else if (a.equals("-r") || a.equals("--reverse")) {
                o.reverse = true;
            } else if (a.equals("-C") || a.equals("--compress")) {
                o.compress = true;
            } else if (a.equals("-t") || a.equals("--no-title")) {
                o.noTitle = true;
            } else if (a.equals("--enable-summary-char")) {
                o.enableSummaryChar = true;
            } else if (a.equals("-N") || a.equals("--line-number")) {
                o.lineNumber = true;
            } else if (a.equals("--no-help-banner")) {
                o.noHelpBanner = true;
            } else if (a.equals("--no-summary")) {
                o.noSummary = true;
            } else if (a.equals("-x") || a.equals("--exec") || a.equals("-e")) {
                o.exec = true;
            } else if (a.equals("-O") || a.equals("--diff-output-only")) {
                o.diffOutputOnly = true;
            } else if (a.equals("--precise")) {
                o.precise = true;
            } else if (a.equals("-A") || a.equals("--aftercommand")) {
                o.afterCommand = need(args, ++i, a, "<after_command>");
            } else if (a.startsWith("--aftercommand=")) {
                o.afterCommand = a.substring(a.indexOf('=') + 1);
            } else if (a.equals("-l") || a.equals("--logfile")) {
                if (i + 1 < args.size() && !looksLikeOption(args.get(i + 1))) {
                    o.logfile = args.get(++i);
                } else {
                    o.logfile = "hwatch.log";
                }
            } else if (a.startsWith("--logfile=")) {
                o.logfile = a.substring(a.indexOf('=') + 1);
            } else if (a.equals("-s") || a.equals("--shell")) {
                o.shell = need(args, ++i, a, "<shell_command>");
            } else if (a.startsWith("--shell=")) {
                o.shell = a.substring(a.indexOf('=') + 1);
            } else if (a.equals("-n") || a.equals("--interval")) {
                String v = need(args, ++i, a, "<interval>");
                o.interval = parseDouble(v, "--interval <interval>");
            } else if (a.startsWith("--interval=")) {
                o.interval = parseDouble(a.substring(a.indexOf('=') + 1), "--interval <interval>");
            } else if (a.equals("-L") || a.equals("--limit")) {
                String v = need(args, ++i, a, "<limit>");
                try {
                    o.limit = Long.parseLong(v);
                } catch (NumberFormatException ex) {
                    throw invalid("invalid value '" + v + "' for '--limit <limit>': invalid digit found in string\n\nFor more information, try '--help'.\n");
                }
            } else if (a.startsWith("--limit=")) {
                try {
                    o.limit = Long.parseLong(a.substring(a.indexOf('=') + 1));
                } catch (NumberFormatException ex) {
                    throw invalid("invalid value '" + a.substring(a.indexOf('=') + 1) + "' for '--limit <limit>': invalid digit found in string\n\nFor more information, try '--help'.\n");
                }
            } else if (a.equals("--tab-size")) {
                String v = need(args, ++i, a, "<tab_size>");
                try {
                    o.tabSize = Integer.parseInt(v);
                } catch (NumberFormatException ex) {
                    throw invalid("invalid value '" + v + "' for '--tab-size <tab_size>': invalid digit found in string\n\nFor more information, try '--help'.\n");
                }
            } else if (a.startsWith("--tab-size=")) {
                try {
                    o.tabSize = Integer.parseInt(a.substring(a.indexOf('=') + 1));
                } catch (NumberFormatException ex) {
                    throw invalid("invalid value '" + a.substring(a.indexOf('=') + 1) + "' for '--tab-size <tab_size>': invalid digit found in string\n\nFor more information, try '--help'.\n");
                }
            } else if (a.equals("-d") || a.equals("--differences")) {
                if (i + 1 >= args.size() || looksLikeOption(args.get(i + 1))) {
                    o.differences = "watch";
                } else if (isDiffValue(args.get(i + 1))) {
                    o.differences = args.get(++i);
                } else {
                    throw badDiff(args.get(i + 1));
                }
            } else if (a.startsWith("--differences=")) {
                String v = a.substring(a.indexOf('=') + 1);
                if (!isDiffValue(v)) throw badDiff(v);
                o.differences = v;
            } else if (a.equals("-o") || a.equals("--output")) {
                String v = need(args, ++i, a, "[<output>]");
                if (!isOutputValue(v)) throw badOutput(v);
                o.output = v;
            } else if (a.startsWith("--output=")) {
                String v = a.substring(a.indexOf('=') + 1);
                if (!isOutputValue(v)) throw badOutput(v);
                o.output = v;
            } else if (a.equals("-K") || a.equals("--keymap")) {
                o.keymaps.add(need(args, ++i, a, "<keymap>"));
            } else if (a.startsWith("--keymap=")) {
                o.keymaps.add(a.substring(a.indexOf('=') + 1));
            } else if (a.startsWith("-") && !a.equals("-")) {
                String flag = a.contains("=") ? a.substring(0, a.indexOf('=')) : a;
                throw invalid("error: unexpected argument '" + flag + "' found\n\nUsage: executable [OPTIONS] [command]...\n\nFor more information, try '--help'.\n");
            } else {
                o.command.add(a);
            }
        }
        if (o.interval < 0.001) o.interval = 0.001;
        if (o.differences != null && !isDiffValue(o.differences)) throw badDiff(o.differences);
        return o;
    }

    private static void runLoop(Options o) throws Exception {
        boolean first = true;
        String previous = null;
        while (true) {
            CommandResult r = runCommand(o);
            String body = selectedOutput(o, r);
            body = applyTransforms(body, o);
            printDivider();
            System.out.print(body);
            if (!body.endsWith("\n")) System.out.println();
            System.out.println();
            System.out.flush();
            if (o.logfile != null && (first || previous == null || !previous.equals(body))) {
                appendLog(o, r);
            }
            if (o.beep && !first && previous != null && !previous.equals(body)) {
                System.out.print("\007");
                System.out.flush();
            }
            if (o.afterCommand != null && !first && previous != null && !previous.equals(body)) {
                runAfter(o.afterCommand, o, r);
            }
            first = false;
            previous = body;
            Thread.sleep(Math.max(1L, Math.round(o.interval * 1000.0)));
        }
    }

    private static CommandResult runCommand(Options o) throws IOException, InterruptedException {
        List<String> cmd = new ArrayList<>();
        if (o.exec) {
            cmd.addAll(o.command);
        } else if (o.shell.contains("{COMMAND}")) {
            List<String> shellParts = splitShellLike(o.shell.replace("{COMMAND}", commandString(o.command)));
            cmd.addAll(shellParts);
        } else {
            cmd.addAll(splitShellLike(o.shell));
            cmd.add(commandString(o.command));
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        Process p = pb.start();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        Thread tout = copyThread(p.getInputStream(), out);
        Thread terr = copyThread(p.getErrorStream(), err);
        int status = p.waitFor();
        tout.join();
        terr.join();
        CommandResult r = new CommandResult();
        r.status = status;
        r.stdout = out.toString(StandardCharsets.UTF_8);
        r.stderr = err.toString(StandardCharsets.UTF_8);
        return r;
    }

    private static Thread copyThread(InputStream in, ByteArrayOutputStream out) {
        Thread t = new Thread(() -> {
            try {
                in.transferTo(out);
            } catch (IOException ignored) {
            }
        });
        t.start();
        return t;
    }

    private static String selectedOutput(Options o, CommandResult r) {
        if ("stdout".equals(o.output)) return r.stdout;
        if ("stderr".equals(o.output)) return r.stderr;
        return r.stderr + r.stdout;
    }

    private static String applyTransforms(String s, Options o) {
        if (o.tabSize > 0) {
            s = s.replace("\t", " ".repeat(o.tabSize));
        }
        List<String> lines = new ArrayList<>(Arrays.asList(s.split("\\R", -1)));
        boolean trailingNewline = s.endsWith("\n") || s.endsWith("\r");
        if (!trailingNewline && !lines.isEmpty()) {
            // Keep the final partial line.
        } else if (!lines.isEmpty()) {
            lines.remove(lines.size() - 1);
        }
        if (o.reverse) {
            java.util.Collections.reverse(lines);
        }
        if (o.lineNumber) {
            for (int i = 0; i < lines.size(); i++) {
                lines.set(i, DIM + (i + 1) + RESET + DIM + " | " + RESET + lines.get(i));
            }
        }
        String joined = String.join("\n", lines);
        if (trailingNewline || !joined.isEmpty()) joined += "\n";
        return joined;
    }

    private static void printDivider() {
        String now = LocalDateTime.now().format(TS);
        System.out.println(DIM + "=====[" + now + "]=========================" + RESET);
    }

    private static void appendLog(Options o, CommandResult r) throws IOException {
        File f = new File(o.logfile);
        File parent = f.getParentFile();
        if (parent != null) parent.mkdirs();
        try (FileWriter fw = new FileWriter(f, true)) {
            fw.write("{\"timestamp\":\"" + json(LocalDateTime.now().format(TS)) + "\",");
            fw.write("\"command\":\"" + json(commandString(o.command)) + "\",");
            fw.write("\"status\":" + (r.status == 0 ? "true" : "false") + ",");
            fw.write("\"output\":\"" + json(r.stderr + r.stdout) + "\",");
            fw.write("\"stdout\":\"" + json(r.stdout) + "\",");
            fw.write("\"stderr\":\"" + json(r.stderr) + "\"}\n");
        }
    }

    private static void replayLog(Options o) throws IOException, InterruptedException, UsageException {
        List<String> lines = Files.readAllLines(Path.of(o.logfile), StandardCharsets.UTF_8);
        if (lines.isEmpty()) {
            usageError("command not specified and logfile is empty.");
            return;
        }
        for (String line : lines) {
            String out = extractJsonField(line, o.output.equals("output") ? "output" : o.output);
            printDivider();
            System.out.print(out);
            if (!out.endsWith("\n")) System.out.println();
            System.out.println();
            Thread.sleep(Math.max(1L, Math.round(o.interval * 1000.0)));
        }
    }

    private static void runAfter(String command, Options o, CommandResult r) {
        try {
            ProcessBuilder pb = new ProcessBuilder("sh", "-c", command);
            pb.environment().put("HWATCH_DATA", "{\"command\":\"" + json(commandString(o.command)) + "\",\"status\":" + (r.status == 0 ? "true" : "false") + "}");
            pb.inheritIO();
            pb.start().waitFor();
        } catch (Exception ignored) {
        }
    }

    private static String commandString(List<String> command) {
        return String.join(" ", command);
    }

    private static String need(List<String> args, int idx, String opt, String value) throws UsageException {
        if (idx >= args.size()) {
            throw invalid("error: a value is required for '" + opt + " " + value + "' but none was supplied\n\nFor more information, try '--help'.\n");
        }
        return args.get(idx);
    }

    private static boolean looksLikeOption(String s) {
        return s.startsWith("-") && !s.equals("-");
    }

    private static double parseDouble(String v, String name) throws UsageException {
        try {
            return Double.parseDouble(v.replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw invalid("error: invalid value '" + v + "' for '" + name + "': invalid float literal\n\nFor more information, try '--help'.\n");
        }
    }

    private static boolean isDiffValue(String v) {
        return v.equals("none") || v.equals("watch") || v.equals("line") || v.equals("word");
    }

    private static boolean isOutputValue(String v) {
        return v.equals("output") || v.equals("stdout") || v.equals("stderr");
    }

    private static UsageException badDiff(String v) {
        return invalid("error: invalid value '" + v + "' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]\n\nFor more information, try '--help'.\n");
    }

    private static UsageException badOutput(String v) {
        return invalid("error: invalid value '" + v + "' for '--output [<output>]'\n  [possible values: output, stdout, stderr]\n\nFor more information, try '--help'.\n");
    }

    private static UsageException invalid(String msg) {
        return new UsageException(msg);
    }

    private static void usageError(String msg) throws UsageException {
        throw invalid("error: " + msg + "\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try '--help'.\n");
    }

    private static List<String> splitShellLike(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean single = false, dbl = false, esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc) {
                cur.append(c);
                esc = false;
            } else if (c == '\\' && !single) {
                esc = true;
            } else if (c == '\'' && !dbl) {
                single = !single;
            } else if (c == '"' && !single) {
                dbl = !dbl;
            } else if (Character.isWhitespace(c) && !single && !dbl) {
                if (cur.length() > 0) {
                    out.add(cur.toString());
                    cur.setLength(0);
                }
            } else {
                cur.append(c);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private static String json(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> {
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
                }
            }
        }
        return b.toString();
    }

    private static String unjson(String s) {
        StringBuilder b = new StringBuilder();
        boolean esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (!esc) {
                if (c == '\\') esc = true;
                else b.append(c);
            } else {
                switch (c) {
                    case 'n' -> b.append('\n');
                    case 'r' -> b.append('\r');
                    case 't' -> b.append('\t');
                    case '"' -> b.append('"');
                    case '\\' -> b.append('\\');
                    default -> b.append(c);
                }
                esc = false;
            }
        }
        return b.toString();
    }

    private static String extractJsonField(String line, String key) {
        String needle = "\"" + key + "\":\"";
        int start = line.indexOf(needle);
        if (start < 0) return "";
        start += needle.length();
        StringBuilder raw = new StringBuilder();
        boolean esc = false;
        for (int i = start; i < line.length(); i++) {
            char c = line.charAt(i);
            if (!esc && c == '"') break;
            raw.append(c);
            esc = !esc && c == '\\';
            if (c != '\\') esc = false;
        }
        return unjson(raw.toString());
    }

    private static void printHelp() {
        System.out.println("""
A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
""");
    }

    static class UsageException extends Exception {
        UsageException(String msg) {
            super(msg);
        }
    }
}
