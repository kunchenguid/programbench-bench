import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class JqLite {
  static final Object MISSING = new Object();
  static final Object EMPTY = new Object();

  static class Cfg {
    boolean compact, rawOut, joinOut, nulOut, ascii, sortKeys, nullInput, rawInput, slurp, exitStatus;
    int indent = 2;
    String filter = null;
    List<String> files = new ArrayList<>();
    Map<String,Object> vars = new LinkedHashMap<>();
    List<Object> positional = new ArrayList<>();
  }

  public static void main(String[] args) {
    try {
      Cfg c = parseArgs(args);
      if (c.filter == null) die("jq: error: Top-level program not given (try \".\")", 3);
      Expr expr = new Parser(c.filter).parse();
      List<Object> inputs = readInputs(c);
      if (c.slurp && !c.nullInput) inputs = List.of(new ArrayList<>(inputs));
      boolean any = false; Object last = null;
      for (Object in : inputs) {
        for (Object out : expr.eval(in, rootVars(c))) {
          if (out == EMPTY || out == MISSING) continue;
          any = true; last = out; writeOut(out, c);
        }
      }
      if (c.exitStatus) System.exit(!any ? 4 : (last == null || Boolean.FALSE.equals(last) ? 1 : 0));
    } catch (JqException e) {
      System.err.println(e.getMessage());
      System.exit(e.code);
    } catch (Exception e) {
      System.err.println("jq: error: " + e.getMessage());
      System.exit(5);
    }
  }

  static Map<String,Object> rootVars(Cfg c) {
    Map<String,Object> m = new LinkedHashMap<>(c.vars);
    Map<String,Object> args = new LinkedHashMap<>();
    args.put("named", new LinkedHashMap<>(c.vars));
    args.put("positional", new ArrayList<>(c.positional));
    m.put("ARGS", args);
    return m;
  }

  static Cfg parseArgs(String[] args) throws IOException {
    Cfg c = new Cfg();
    for (int i=0;i<args.length;i++) {
      String a=args[i];
      if ("--".equals(a)) { for (i++;i<args.length;i++) c.files.add(args[i]); break; }
      if ("-V".equals(a) || "--version".equals(a)) { System.out.println("jq-build-2b77eb1"); System.exit(0); }
      if ("-h".equals(a) || "--help".equals(a)) { printHelp(); System.exit(0); }
      if ("--build-configuration".equals(a)) { System.out.println("--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local"); System.exit(0); }
      if ("-c".equals(a)||"--compact-output".equals(a)) c.compact=true;
      else if ("-r".equals(a)||"--raw-output".equals(a)) c.rawOut=true;
      else if ("-j".equals(a)||"--join-output".equals(a)) { c.rawOut=true; c.joinOut=true; }
      else if ("-a".equals(a)||"--ascii-output".equals(a)) c.ascii=true;
      else if ("-S".equals(a)||"--sort-keys".equals(a)) c.sortKeys=true;
      else if ("-n".equals(a)||"--null-input".equals(a)) c.nullInput=true;
      else if ("-R".equals(a)||"--raw-input".equals(a)) c.rawInput=true;
      else if ("-s".equals(a)||"--slurp".equals(a)) c.slurp=true;
      else if ("--tab".equals(a)) c.indent=-1;
      else if ("--indent".equals(a)) c.indent=Integer.parseInt(args[++i]);
      else if ("--raw-output0".equals(a)) { c.rawOut=true; c.joinOut=true; c.nulOut=true; }
      else if ("-e".equals(a)||"--exit-status".equals(a)) c.exitStatus=true;
      else if ("-M".equals(a)||"-C".equals(a)||"--monochrome-output".equals(a)||"--color-output".equals(a)||"--unbuffered".equals(a)||"--seq".equals(a)) {}
      else if ("-f".equals(a)||"--from-file".equals(a)) c.filter = Files.readString(Path.of(args[++i]));
      else if ("--arg".equals(a)) c.vars.put(args[++i], args[++i]);
      else if ("--argjson".equals(a)) c.vars.put(args[++i], new JsonParser(args[++i]).parseOne());
      else if ("--rawfile".equals(a)) c.vars.put(args[++i], Files.readString(Path.of(args[++i])));
      else if ("--slurpfile".equals(a)) c.vars.put(args[++i], new JsonParser(Files.readString(Path.of(args[++i]))).parseAll());
      else if ("--args".equals(a)) { if (c.filter==null) c.filter=args[++i]; for (i++;i<args.length;i++) c.positional.add(args[i]); break; }
      else if ("--jsonargs".equals(a)) { if (c.filter==null) c.filter=args[++i]; for (i++;i<args.length;i++) c.positional.add(new JsonParser(args[i]).parseOne()); break; }
      else if (a.startsWith("-") && c.filter==null && a.length()>2) {
        for (int k=1;k<a.length();k++) { char ch=a.charAt(k); if(ch=='c')c.compact=true; else if(ch=='r')c.rawOut=true; else if(ch=='n')c.nullInput=true; else if(ch=='R')c.rawInput=true; else if(ch=='s')c.slurp=true; else if(ch=='S')c.sortKeys=true; else if(ch=='a')c.ascii=true; else if(ch=='e')c.exitStatus=true; }
      } else if (c.filter == null) c.filter = a;
      else c.files.add(a);
    }
    return c;
  }

  static void printHelp() {
    System.out.println("jq - commandline JSON processor [version build-2b77eb1]\n\nUsage:\tjq [options] <jq filter> [file...]\n\tjq [options] --args <jq filter> [strings...]\n\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]\n\njq is a tool for processing JSON inputs, applying the given filter to\nits JSON text inputs and producing the filter's results as JSON on\nstandard output.\n\nCommand options:\n  -n, --null-input          use `null` as the single input value;\n  -R, --raw-input           read each line as string instead of JSON;\n  -s, --slurp               read all inputs into an array and use it as\n                            the single input value;\n  -c, --compact-output      compact instead of pretty-printed output;\n  -r, --raw-output          output strings without escapes and quotes;\n  -j, --join-output         implies -r and output without newline after\n                            each output;\n  -a, --ascii-output        output strings by only ASCII characters\n                            using escape sequences;\n  -S, --sort-keys           sort keys of each object on output;\n  -f, --from-file           load the filter from a file;\n  -h, --help                show the help;");
  }

  static List<Object> readInputs(Cfg c) throws IOException {
    if (c.nullInput) return Collections.singletonList(null);
    List<Object> r = new ArrayList<>();
    if (c.rawInput) {
      if (c.files.isEmpty()) readRaw(System.in, r); else for(String f:c.files) readRaw(new FileInputStream(f), r);
    } else {
      StringBuilder sb = new StringBuilder();
      if (c.files.isEmpty()) sb.append(new String(System.in.readAllBytes(), StandardCharsets.UTF_8));
      else for (String f:c.files) sb.append(Files.readString(Path.of(f))).append('\n');
      r.addAll(new JsonParser(sb.toString()).parseAll());
    }
    return r;
  }
  static void readRaw(InputStream is, List<Object> r) throws IOException { try(BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){ String line; while((line=br.readLine())!=null) r.add(line); } }
  static void writeOut(Object v, Cfg c) {
    if (c.rawOut && v instanceof String) System.out.print((String)v);
    else System.out.print(JsonPrinter.print(v, c.compact ? 0 : c.indent, c.ascii, c.sortKeys));
    if (c.nulOut) System.out.print('\0');
    else if (!c.joinOut) System.out.println();
  }
  static void die(String s, int code) { throw new JqException(s, code); }
  static class JqException extends RuntimeException { int code; JqException(String m,int c){super(m);code=c;} }

  interface Expr { List<Object> eval(Object in, Map<String,Object> vars); }
  static List<Object> one(Object x){ return x==EMPTY ? List.of() : Collections.singletonList(x); }
  static boolean truth(Object v){ return !(v == null || Boolean.FALSE.equals(v) || v == EMPTY || v == MISSING); }
  static Object missToNull(Object v){ return v==MISSING ? null : v; }

  static class Lit implements Expr { Object v; Lit(Object v){this.v=v;} public List<Object> eval(Object in,Map<String,Object> vars){return one(v);} }
  static class Id implements Expr { public List<Object> eval(Object in,Map<String,Object> vars){return one(in);} }
  static class Var implements Expr { String n; Var(String n){this.n=n;} public List<Object> eval(Object in,Map<String,Object> vars){return one(vars.getOrDefault(n, null));} }
  static class Pipe implements Expr { Expr a,b; Pipe(Expr a,Expr b){this.a=a;this.b=b;} public List<Object> eval(Object in,Map<String,Object> vars){List<Object> out=new ArrayList<>(); for(Object x:a.eval(in,vars)) out.addAll(b.eval(x,vars)); return out;} }
  static class Comma implements Expr { Expr a,b; Comma(Expr a,Expr b){this.a=a;this.b=b;} public List<Object> eval(Object in,Map<String,Object> vars){List<Object> out=new ArrayList<>(a.eval(in,vars)); out.addAll(b.eval(in,vars)); return out;} }
  static class Field implements Expr { Expr base; String key; boolean opt; Field(Expr b,String k,boolean o){base=b;key=k;opt=o;} public List<Object> eval(Object in,Map<String,Object> vars){List<Object> out=new ArrayList<>(); for(Object x:base.eval(in,vars)){ if(x instanceof Map) out.add(((Map<?,?>)x).getOrDefault(key, null)); else out.add(null);} return out;} }
  static class Index implements Expr { Expr base, idx; boolean iter; Index(Expr b,Expr i,boolean it){base=b;idx=i;iter=it;} public List<Object> eval(Object in,Map<String,Object> vars){List<Object> out=new ArrayList<>(); for(Object x:base.eval(in,vars)){ if(iter){ if(x instanceof List) out.addAll((List<?>)x); else if(x instanceof Map) out.addAll(((Map<?,?>)x).values()); } else { Object iv=idx.eval(in,vars).stream().findFirst().orElse(null); out.add(index(x,iv)); }} return out;} }
  static Object index(Object x,Object iv){ if(x instanceof List && iv instanceof Number){ List<?> l=(List<?>)x; int i=((Number)iv).intValue(); if(i<0)i=l.size()+i; return i>=0&&i<l.size()?l.get(i):null;} if(x instanceof Map && iv instanceof String) return ((Map<?,?>)x).getOrDefault(iv,null); if(x instanceof String && iv instanceof Number){String s=(String)x; int i=((Number)iv).intValue(); if(i<0)i=s.length()+i; return i>=0&&i<s.length()?String.valueOf(s.charAt(i)):null;} return null; }
  static class Arr implements Expr { Expr e; Arr(Expr e){this.e=e;} public List<Object> eval(Object in,Map<String,Object> vars){return one(new ArrayList<>(e.eval(in,vars)));} }
  static class Obj implements Expr { List<String> keys; List<Expr> vals; Obj(List<String> k,List<Expr> v){keys=k;vals=v;} public List<Object> eval(Object in,Map<String,Object> vars){Map<String,Object> m=new LinkedHashMap<>(); for(int i=0;i<keys.size();i++){List<Object> vs=vals.get(i).eval(in,vars); m.put(keys.get(i), vs.isEmpty()?null:missToNull(vs.get(vs.size()-1)));} return one(m);} }
  static class Bin implements Expr { String op; Expr a,b; Bin(String o,Expr a,Expr b){op=o;this.a=a;this.b=b;} public List<Object> eval(Object in,Map<String,Object> vars){List<Object> out=new ArrayList<>(); for(Object x:a.eval(in,vars)) for(Object y:b.eval(in,vars)) out.add(apply(op,missToNull(x),missToNull(y))); return out;} }
  static Object apply(String op,Object x,Object y){ switch(op){case "+": return plus(x,y); case "-": return num(x).subtract(num(y)); case "*": return times(x,y); case "/": return num(x).divide(num(y), java.math.MathContext.DECIMAL64); case "%": return num(x).remainder(num(y)); case "==": return Objects.equals(x,y); case "!=": return !Objects.equals(x,y); case ">": return cmp(x,y)>0; case "<": return cmp(x,y)<0; case ">=": return cmp(x,y)>=0; case "<=": return cmp(x,y)<=0; case "and": return truth(x)&&truth(y); case "or": return truth(x)||truth(y); case "//": return truth(x)?x:y;} return null; }
  static Object plus(Object x,Object y){ if(x==null)return y; if(y==null)return x; if(x instanceof Number && y instanceof Number)return num(x).add(num(y)); if(x instanceof String || y instanceof String)return String.valueOf(x)+String.valueOf(y); if(x instanceof List){ArrayList<Object> l=new ArrayList<>((List<?>)x); if(y instanceof List)l.addAll((List<?>)y); else l.add(y); return l;} if(x instanceof Map && y instanceof Map){Map<String,Object> m=new LinkedHashMap<>((Map<String,Object>)x); m.putAll((Map<String,Object>)y); return m;} return null; }
  static Object times(Object x,Object y){ if(x instanceof Number && y instanceof Number)return num(x).multiply(num(y)); if(x instanceof String && y instanceof Number)return ((String)x).repeat(Math.max(0,((Number)y).intValue())); return null; }
  static BigDecimal num(Object o){ if(o instanceof BigDecimal)return (BigDecimal)o; if(o instanceof Number)return new BigDecimal(o.toString()); return BigDecimal.ZERO; }
  static int cmp(Object x,Object y){ if(x instanceof Number && y instanceof Number)return num(x).compareTo(num(y)); return String.valueOf(x).compareTo(String.valueOf(y)); }
  static class Un implements Expr { String op; Expr e; Un(String o,Expr e){op=o;this.e=e;} public List<Object> eval(Object in,Map<String,Object> vars){List<Object> out=new ArrayList<>(); for(Object x:e.eval(in,vars)){ if("-".equals(op)) out.add(num(x).negate()); else if("not".equals(op)) out.add(!truth(x)); } return out;} }
  static class Call implements Expr { String n; List<Expr> args; Call(String n,List<Expr>a){this.n=n;args=a;} public List<Object> eval(Object in,Map<String,Object> vars){return builtin(n,args,in,vars);} }

  static List<Object> builtin(String n,List<Expr>a,Object in,Map<String,Object> vars){
    switch(n){
      case "empty": return List.of();
      case "type": return one(type(in));
      case "length": return one(length(in));
      case "keys": return one(keys(in));
      case "keys_unsorted": return one(keysUnsorted(in));
      case "add": return one(add(in));
      case "select": return truth(first(a.get(0),in,vars))?one(in):List.of();
      case "map": { List<Object> r=new ArrayList<>(); if(in instanceof List) for(Object x:(List<?>)in) r.addAll(a.get(0).eval(x,vars)); return one(r); }
      case "map_values": { if(in instanceof List){List<Object> r=new ArrayList<>(); for(Object x:(List<?>)in){List<Object> v=a.get(0).eval(x,vars); r.add(v.isEmpty()?null:v.get(0));} return one(r);} if(in instanceof Map){Map<String,Object> m=new LinkedHashMap<>(); for(var e:((Map<String,Object>)in).entrySet()){List<Object> v=a.get(0).eval(e.getValue(),vars); if(!v.isEmpty())m.put(e.getKey(),v.get(0));} return one(m);} return one(in); }
      case "has": { Object k=first(a.get(0),in,vars); return one((in instanceof Map && ((Map<?,?>)in).containsKey(k)) || (in instanceof List && k instanceof Number && ((Number)k).intValue()>=0 && ((Number)k).intValue()<((List<?>)in).size())); }
      case "contains": return one(contains(in, first(a.get(0),in,vars)));
      case "tostring": return one(in instanceof String ? in : JsonPrinter.print(in,0,false,false));
      case "tonumber": try{return one(new BigDecimal(String.valueOf(in)));}catch(Exception e){return one(null);}
      case "tojson": return one(JsonPrinter.print(in,0,false,false));
      case "fromjson": return one(new JsonParser(String.valueOf(in)).parseOne());
      case "not": return one(!truth(in));
      case "first": { if(a.isEmpty()){ if(in instanceof List&&!((List<?>)in).isEmpty())return one(((List<?>)in).get(0)); return one(null);} List<Object> v=a.get(0).eval(in,vars); return v.isEmpty()?List.of():one(v.get(0));}
      case "last": { if(in instanceof List&&!((List<?>)in).isEmpty())return one(((List<?>)in).get(((List<?>)in).size()-1)); return one(null);}
      case "reverse": { if(in instanceof List){List<Object> l=new ArrayList<>((List<?>)in); Collections.reverse(l); return one(l);} return one(in);}
      case "sort": { if(in instanceof List){List<Object> l=new ArrayList<>((List<?>)in); l.sort(JqLite::cmp); return one(l);} return one(in);}
      case "flatten": return one(flatten(in));
      case "range": { int s=0,e=0; if(a.size()==1)e=((Number)first(a.get(0),in,vars)).intValue(); else {s=((Number)first(a.get(0),in,vars)).intValue(); e=((Number)first(a.get(1),in,vars)).intValue();} List<Object> r=new ArrayList<>(); for(int i=s;i<e;i++)r.add(new BigDecimal(i)); return r; }
    }
    return one(null);
  }
  static Object first(Expr e,Object in,Map<String,Object> vars){ List<Object> v=e.eval(in,vars); return v.isEmpty()?EMPTY:v.get(0); }
  static String type(Object v){ if(v==null)return"null"; if(v instanceof Boolean)return"boolean"; if(v instanceof Number)return"number"; if(v instanceof String)return"string"; if(v instanceof List)return"array"; if(v instanceof Map)return"object"; return"null"; }
  static Object length(Object v){ if(v==null)return BigDecimal.ZERO; if(v instanceof String)return new BigDecimal(((String)v).length()); if(v instanceof List)return new BigDecimal(((List<?>)v).size()); if(v instanceof Map)return new BigDecimal(((Map<?,?>)v).size()); if(v instanceof Number)return num(v).abs(); return BigDecimal.ZERO; }
  static Object keys(Object v){ List<Object> r=keysUnsorted(v); r.sort(JqLite::cmp); return r; }
  static List<Object> keysUnsorted(Object v){ List<Object> r=new ArrayList<>(); if(v instanceof Map)r.addAll(((Map<?,?>)v).keySet()); else if(v instanceof List)for(int i=0;i<((List<?>)v).size();i++)r.add(new BigDecimal(i)); return r; }
  static Object add(Object v){ if(!(v instanceof List))return null; Object acc=null; boolean first=true; for(Object x:(List<?>)v){ if(first){acc=x;first=false;} else acc=plus(acc,x);} return first?null:acc; }
  static boolean contains(Object a,Object b){ if(a instanceof String && b instanceof String)return ((String)a).contains((String)b); if(a instanceof List)return ((List<?>)a).contains(b); if(a instanceof Map && b instanceof Map){Map<?,?> am=(Map<?,?>)a; for(var e:((Map<?,?>)b).entrySet()) if(!Objects.equals(am.get(e.getKey()),e.getValue())) return false; return true;} return Objects.equals(a,b); }
  static Object flatten(Object v){ if(!(v instanceof List))return v; List<Object> r=new ArrayList<>(); for(Object x:(List<?>)v){ Object f=flatten(x); if(f instanceof List)r.addAll((List<?>)f); else r.add(f);} return r; }

  static class Parser {
    String s; int p; Parser(String s){this.s=s;}
    Expr parse(){ Expr e=parseComma(); skip(); if(p<s.length()) throw new JqException("jq: error: syntax error, unexpected " + peek(),3); return e; }
    Expr parseComma(){ Expr e=parsePipe(); skip(); while(eat(",")){ e=new Comma(e,parsePipe()); skip(); } return e; }
    Expr parsePipe(){ Expr e=parseAlt(); skip(); while(eat("|")){ e=new Pipe(e,parseAlt()); skip(); } return e; }
    Expr parseAlt(){ Expr e=parseBool(); skip(); while(eat("//")) e=new Bin("//",e,parseBool()); return e; }
    Expr parseBool(){ Expr e=parseCmp(); while(true){skip(); if(word("and"))e=new Bin("and",e,parseCmp()); else if(word("or"))e=new Bin("or",e,parseCmp()); else return e;} }
    Expr parseCmp(){ Expr e=parseAdd(); while(true){skip(); String o=null; for(String x:new String[]{"==","!=",">=","<=",">","<"}) if(eat(x)){o=x;break;} if(o==null)return e; e=new Bin(o,e,parseAdd());} }
    Expr parseAdd(){ Expr e=parseMul(); while(true){skip(); if(eat("+"))e=new Bin("+",e,parseMul()); else if(eat("-"))e=new Bin("-",e,parseMul()); else return e;} }
    Expr parseMul(){ Expr e=parseUnary(); while(true){skip(); if(eat("*"))e=new Bin("*",e,parseUnary()); else if(!s.startsWith("//",p)&&eat("/"))e=new Bin("/",e,parseUnary()); else if(eat("%"))e=new Bin("%",e,parseUnary()); else return e;} }
    Expr parseUnary(){ skip(); if(eat("-"))return new Un("-",parseUnary()); if(word("not"))return new Un("not",parseUnary()); return parsePost(); }
    Expr parsePost(){ Expr e=parsePrim(); while(true){ skip(); if(eat(".")){ String k=name(); e=new Field(e,k,false); eat("?"); } else if(eat("[]")) { e=new Index(e,null,true); eat("?"); } else if(eat("[")){ skip(); if(eat("]")) e=new Index(e,null,true); else { Expr idx=parseComma(); need("]"); e=new Index(e,idx,false);} eat("?"); } else break; } return e; }
    Expr parsePrim(){ skip(); char c=peek(); if(c=='.'){p++; skip(); if(p<s.length()&&(Character.isLetter(s.charAt(p))||s.charAt(p)=='_')) return new Field(new Id(),name(),false); return new Id();} if(c=='$'){p++; return new Var(name());} if(c=='('){p++; Expr e=parseComma(); need(")"); return e;} if(c=='['){p++; skip(); if(eat("]"))return new Lit(new ArrayList<>()); Expr e=parseComma(); need("]"); return new Arr(e);} if(c=='{')return parseObj(); if(c=='"')return new Lit(str()); if(c=='-'||Character.isDigit(c))return new Lit(number()); String n=name(); if(n.isEmpty()) throw new JqException("jq: error: syntax error",3); if("null".equals(n))return new Lit(null); if("true".equals(n))return new Lit(true); if("false".equals(n))return new Lit(false); skip(); List<Expr> args=new ArrayList<>(); if(eat("(")){ skip(); if(!eat(")")){ do{args.add(parseComma()); skip();}while(eat(";")||eat(",")); need(")"); }} return new Call(n,args); }
    Expr parseObj(){ need("{"); List<String> ks=new ArrayList<>(); List<Expr> vs=new ArrayList<>(); skip(); if(eat("}"))return new Obj(ks,vs); do{ skip(); String k; Expr v; if(peek()=='"') k=str(); else k=name(); skip(); if(eat(":")) v=parsePipe(); else v=new Field(new Id(),k,false); ks.add(k); vs.add(v); skip(); }while(eat(",")); need("}"); return new Obj(ks,vs); }
    String name(){ skip(); int st=p; if(p<s.length()&&(Character.isLetter(s.charAt(p))||s.charAt(p)=='_')){p++; while(p<s.length()&&(Character.isLetterOrDigit(s.charAt(p))||s.charAt(p)=='_'))p++;} return s.substring(st,p); }
    BigDecimal number(){ int st=p; if(s.charAt(p)=='-')p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++; if(p<s.length()&&s.charAt(p)=='.'){p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} if(p<s.length()&&(s.charAt(p)=='e'||s.charAt(p)=='E')){p++; if(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-'))p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} return new BigDecimal(s.substring(st,p)); }
    String str(){ need("\""); StringBuilder b=new StringBuilder(); while(p<s.length()){ char c=s.charAt(p++); if(c=='"')break; if(c=='\\'){ char e=s.charAt(p++); switch(e){case '"':b.append('"');break;case '\\':b.append('\\');break;case '/':b.append('/');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'u':b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;break;default:b.append(e);} } else b.append(c);} return b.toString(); }
    void skip(){ while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++; }
    char peek(){ skip(); return p<s.length()?s.charAt(p):'\0'; }
    boolean eat(String x){ skip(); if(s.startsWith(x,p)){p+=x.length();return true;} return false; }
    boolean word(String w){ skip(); if(s.startsWith(w,p)&&(p+w.length()==s.length()||!Character.isLetterOrDigit(s.charAt(p+w.length())))){p+=w.length();return true;} return false; }
    void need(String x){ if(!eat(x)) throw new JqException("jq: error: syntax error, expected "+x,3); }
  }

  static class JsonParser {
    String s; int p; JsonParser(String s){this.s=s;}
    Object parseOne(){ Object v=parseVal(); skip(); return v; }
    List<Object> parseAll(){ List<Object> r=new ArrayList<>(); skip(); while(p<s.length()){ r.add(parseVal()); skip(); } return r; }
    Object parseVal(){ skip(); char c=s.charAt(p); if(c=='{')return obj(); if(c=='[')return arr(); if(c=='"')return str(); if(c=='t'){p+=4;return true;} if(c=='f'){p+=5;return false;} if(c=='n'){p+=4;return null;} return num(); }
    Map<String,Object> obj(){ p++; Map<String,Object> m=new LinkedHashMap<>(); skip(); if(s.charAt(p)=='}'){p++;return m;} do{ String k=str(); skip(); p++; Object v=parseVal(); m.put(k,v); skip(); }while(s.charAt(p++)==','); return m; }
    List<Object> arr(){ p++; List<Object> a=new ArrayList<>(); skip(); if(s.charAt(p)==']'){p++;return a;} do{ a.add(parseVal()); skip(); }while(s.charAt(p++)==','); return a; }
    BigDecimal num(){ int st=p; if(s.charAt(p)=='-')p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++; if(p<s.length()&&s.charAt(p)=='.'){p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} if(p<s.length()&&(s.charAt(p)=='e'||s.charAt(p)=='E')){p++; if(s.charAt(p)=='+'||s.charAt(p)=='-')p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} return new BigDecimal(s.substring(st,p)); }
    String str(){ p++; StringBuilder b=new StringBuilder(); while(p<s.length()){ char c=s.charAt(p++); if(c=='"')break; if(c=='\\'){ char e=s.charAt(p++); switch(e){case '"':b.append('"');break;case '\\':b.append('\\');break;case '/':b.append('/');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'u':b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;break;default:b.append(e);} } else b.append(c);} return b.toString(); }
    void skip(){ while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++; }
  }

  static class JsonPrinter {
    static String print(Object v,int indent,boolean ascii,boolean sort){ StringBuilder b=new StringBuilder(); val(b,v,indent,0,ascii,sort); return b.toString(); }
    static void val(StringBuilder b,Object v,int ind,int lvl,boolean ascii,boolean sort){ if(v==null)b.append("null"); else if(v instanceof Boolean)b.append(v); else if(v instanceof Number)b.append(num(v).stripTrailingZeros().toPlainString().replace("-0","0")); else if(v instanceof String)str(b,(String)v,ascii); else if(v instanceof List){List<?> l=(List<?>)v; b.append('['); for(int i=0;i<l.size();i++){ if(i>0)b.append(','); nl(b,ind,lvl+1); val(b,l.get(i),ind,lvl+1,ascii,sort);} nlEnd(b,ind,lvl,!l.isEmpty()); b.append(']');} else if(v instanceof Map){Map<String,Object> m=(Map<String,Object>)v; List<String> ks=new ArrayList<>(m.keySet()); if(sort)Collections.sort(ks); b.append('{'); boolean first=true; for(String k:ks){ if(!first)b.append(','); first=false; nl(b,ind,lvl+1); str(b,k,ascii); b.append(ind==0?":":": "); val(b,m.get(k),ind,lvl+1,ascii,sort);} nlEnd(b,ind,lvl,!ks.isEmpty()); b.append('}');} }
    static void nl(StringBuilder b,int ind,int lvl){ if(ind==0)return; b.append('\n'); if(ind<0)b.append("\t".repeat(lvl)); else b.append(" ".repeat(ind*lvl)); }
    static void nlEnd(StringBuilder b,int ind,int lvl,boolean any){ if(ind!=0&&any){ b.append('\n'); if(ind<0)b.append("\t".repeat(lvl)); else b.append(" ".repeat(ind*lvl)); } }
    static void str(StringBuilder b,String s,boolean ascii){ b.append('"'); for(int i=0;i<s.length();i++){ char c=s.charAt(i); switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\b':b.append("\\b");break;case '\f':b.append("\\f");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default: if((c<32)||(ascii&&c>127))b.append(String.format("\\u%04x",(int)c)); else b.append(c);} } b.append('"'); }
  }
}
