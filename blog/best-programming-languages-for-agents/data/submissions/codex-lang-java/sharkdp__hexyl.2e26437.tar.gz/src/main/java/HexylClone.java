import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HexylClone {
    static class Opt {
        Long length = null;
        long skip = 0;
        long blockSize = 512;
        boolean noSqueeze = false;
        String border = "unicode";
        boolean chars = true;
        boolean position = true;
        String charTable = "default";
        int panels = 2;
        boolean include = false;
        int groupSize = 1;
        boolean little = false;
        String base = "hexadecimal";
        String file = null;
    }

    public static void main(String[] args) {
        try {
            Opt opt = parse(args);
            if (opt == null) return;
            byte[] data = readInput(opt.file);
            long fileLen = data.length;
            long start = opt.skip >= 0 ? opt.skip : Math.max(0, fileLen + opt.skip);
            if (start > fileLen) start = fileLen;
            long end = fileLen;
            if (opt.length != null) end = Math.min(fileLen, start + Math.max(0, opt.length));
            byte[] slice = Arrays.copyOfRange(data, (int) start, (int) end);
            if (opt.include) {
                printInclude(opt, slice);
            } else {
                printHex(opt, slice, start);
            }
        } catch (CliError e) {
            System.err.print(e.getMessage());
            System.exit(e.code);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class CliError extends Exception {
        int code;
        CliError(String msg) { this(msg, 2); }
        CliError(String msg, int code) { super(msg); this.code = code; }
    }

    static Opt parse(String[] args) throws CliError {
        Opt o = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            String val = null;
            int eq = a.indexOf('=');
            if (eq > 0 && a.startsWith("--")) {
                val = a.substring(eq + 1);
                a = a.substring(0, eq);
            }
            switch (a) {
                case "-h": printShortHelp(); return null;
                case "--help": printLongHelp(); return null;
                case "-V": case "--version": System.out.println("hexyl 0.16.0"); return null;
                case "-n": case "--length": case "--bytes": case "-c": case "-l":
                    o.length = parseCount(value(args, ++i, val, a), o.blockSize, true, a);
                    break;
                case "-s": case "--skip":
                    o.skip = parseCount(value(args, ++i, val, a), o.blockSize, false, a);
                    break;
                case "--block-size":
                    o.blockSize = parseCount(value(args, ++i, val, a), o.blockSize, true, a);
                    break;
                case "-v": case "--no-squeezing": o.noSqueeze = true; break;
                case "--color": value(args, ++i, val, a); break;
                case "--border": o.border = value(args, ++i, val, a); break;
                case "-p": case "--plain":
                    o.chars = false; o.position = false; o.border = "none";
                    break;
                case "--no-characters": o.chars = false; break;
                case "-C": case "--characters": o.chars = true; break;
                case "--character-table": o.charTable = value(args, ++i, val, a); break;
                case "--color-scheme": value(args, ++i, val, a); break;
                case "-P": case "--no-position": o.position = false; break;
                case "-o": case "--display-offset":
                    long off = parseCount(value(args, ++i, val, a), o.blockSize, true, a);
                    o.skip += 0; // parsed for compatibility; display offset is handled below
                    displayOffset = off;
                    break;
                case "--panels":
                    String p = value(args, ++i, val, a);
                    o.panels = p.equals("auto") ? 2 : Math.max(1, Integer.parseInt(p));
                    break;
                case "--terminal-width":
                    int w = Integer.parseInt(value(args, ++i, val, a));
                    o.panels = w >= 132 ? 3 : (w >= 76 ? 2 : 1);
                    break;
                case "-g": case "--group-size": case "--groupsize":
                    o.groupSize = Integer.parseInt(value(args, ++i, val, a));
                    if (!(o.groupSize == 1 || o.groupSize == 2 || o.groupSize == 4 || o.groupSize == 8))
                        throw usage("invalid value '" + o.groupSize + "' for '" + a + "'");
                    break;
                case "--endianness":
                    String en = value(args, ++i, val, a);
                    o.little = en.equals("little");
                    break;
                case "-e":
                    o.little = true;
                    break;
                case "-b": case "--base":
                    o.base = value(args, ++i, val, a);
                    break;
                case "--print-color-table":
                    printColorTable();
                    return null;
                case "-i": case "--include": o.include = true; break;
                case "--completion":
                    value(args, ++i, val, a);
                    return null;
                default:
                    if (a.startsWith("-")) throw unexpected(a);
                    if (o.file != null) throw unexpected(a);
                    o.file = a;
            }
            if (val != null) i--;
        }
        return o;
    }

    static long displayOffset = 0;

    static String value(String[] args, int index, String inline, String opt) throws CliError {
        if (inline != null) return inline;
        if (index >= args.length) throw usage("a value is required for '" + opt + " <N>' but none was supplied");
        return args[index];
    }

    static CliError unexpected(String a) {
        return new CliError("error: unexpected argument '" + a + "' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n");
    }

    static CliError usage(String s) {
        return new CliError("error: " + s + "\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n");
    }

    static long parseCount(String s, long block, boolean positiveOnly, String ctx) throws CliError {
        boolean neg = s.startsWith("-");
        if (neg) s = s.substring(1);
        long mult = 1;
        String lower = s.toLowerCase();
        String num = s;
        String[][] units = {
                {"kib", "1024"}, {"mib", "1048576"}, {"gib", "1073741824"},
                {"kb", "1000"}, {"mb", "1000000"}, {"gb", "1000000000"},
                {"k", "1000"}, {"m", "1000000"}, {"g", "1000000000"},
                {"block", Long.toString(block)}
        };
        for (String[] u : units) {
            if (lower.endsWith(u[0])) {
                mult = Long.parseLong(u[1]);
                num = s.substring(0, s.length() - u[0].length());
                break;
            }
        }
        long n;
        try {
            if (num.startsWith("0x") || num.startsWith("0X")) n = Long.parseLong(num.substring(2), 16);
            else n = Long.parseLong(num);
        } catch (NumberFormatException e) {
            throw new CliError("Error: failed to parse `" + ctx + "` arg \"" + (neg ? "-" : "") + s + "\" as byte count\n");
        }
        long r = n * mult;
        if (neg) {
            if (positiveOnly) throw new CliError("Error: failed to parse `" + ctx + "` arg \"-" + s + "\" as byte count\n\nCaused by:\n    negative offset specified, but only positive offsets (counts) are accepted in this context\n");
            r = -r;
        }
        return r;
    }

    static byte[] readInput(String file) throws IOException {
        if (file == null) return readAll(System.in);
        return Files.readAllBytes(Path.of(file));
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) >= 0) b.write(buf, 0, n);
        return b.toByteArray();
    }

    static void printHex(Opt o, byte[] data, long start) {
        int rowBytes = o.panels * 8;
        Border b = Border.of(o.border);
        List<Row> rows = new ArrayList<>();
        for (int off = 0; off < data.length; off += rowBytes) {
            int len = Math.min(rowBytes, data.length - off);
            rows.add(new Row(start + displayOffset + off, Arrays.copyOfRange(data, off, off + len), false));
        }
        if (!o.noSqueeze) rows = squeeze(rows, rowBytes, data.length, start + displayOffset);
        if (!b.none) System.out.println(borderLine(o, b, true));
        for (Row r : rows) System.out.println(formatRow(o, b, r));
        if (!b.none) System.out.println(borderLine(o, b, false));
    }

    static class Row {
        long offset; byte[] bytes; boolean star;
        Row(long o, byte[] b, boolean s) { offset = o; bytes = b; star = s; }
    }

    static List<Row> squeeze(List<Row> rows, int rowBytes, int total, long base) {
        List<Row> out = new ArrayList<>();
        byte[] prev = null;
        boolean squeezing = false;
        for (Row r : rows) {
            boolean same = prev != null && r.bytes.length == rowBytes && Arrays.equals(prev, r.bytes);
            if (same) {
                if (!squeezing) out.add(new Row(0, new byte[0], true));
                squeezing = true;
            } else {
                out.add(r);
                squeezing = false;
            }
            if (r.bytes.length == rowBytes) prev = r.bytes;
            else prev = null;
        }
        if (squeezing) out.add(new Row(base + total, new byte[0], false));
        return out;
    }

    static String formatRow(Opt o, Border b, Row r) {
        StringBuilder s = new StringBuilder();
        String sep = b.none ? " " : b.v;
        s.append(sep);
        if (o.position) {
            if (r.star) s.append("*       ");
            else s.append(String.format("%08x", r.offset));
            s.append(sep);
        }
        for (int p = 0; p < o.panels; p++) {
            if (p > 0) s.append(b.none ? "  " : b.mid);
            s.append(hexPanel(o, r.bytes, p * 8));
        }
        if (o.chars) {
            s.append(sep);
            for (int p = 0; p < o.panels; p++) {
                if (p > 0) s.append(b.none ? " " : b.mid);
                s.append(charPanel(o, r.bytes, p * 8));
            }
        }
        if (!b.none) s.append(sep);
        return s.toString();
    }

    static String hexPanel(Opt o, byte[] row, int base) {
        int width = hexWidth(o);
        if (row.length <= base) return " ".repeat(width);
        List<String> toks = new ArrayList<>();
        for (int i = 0; i < 8; i += o.groupSize) {
            if (base + i >= row.length) break;
            int n = Math.min(o.groupSize, row.length - base - i);
            toks.add(token(o, row, base + i, n));
        }
        String content = " " + String.join(" ", toks);
        if (content.length() < width) content += " ".repeat(width - content.length());
        return content;
    }

    static int hexWidth(Opt o) {
        int digit = switch (o.base) {
            case "binary" -> 8;
            case "octal", "decimal" -> 3;
            default -> 2;
        };
        int groups = (8 + o.groupSize - 1) / o.groupSize;
        int token = digit * o.groupSize;
        return 1 + groups * token + Math.max(0, groups - 1) + 1;
    }

    static String token(Opt o, byte[] row, int off, int n) {
        int[] order = new int[n];
        for (int i = 0; i < n; i++) order[i] = o.little ? n - 1 - i : i;
        StringBuilder s = new StringBuilder();
        for (int idx : order) {
            int v = row[off + idx] & 0xff;
            s.append(switch (o.base) {
                case "binary" -> String.format("%8s", Integer.toBinaryString(v)).replace(' ', '0');
                case "octal" -> String.format("%03o", v);
                case "decimal" -> String.format("%03d", v);
                default -> String.format("%02x", v);
            });
        }
        return s.toString();
    }

    static String charPanel(Opt o, byte[] row, int base) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (base + i < row.length) s.append(mapChar(o.charTable, row[base + i] & 0xff));
            else s.append(' ');
        }
        return s.toString();
    }

    static String mapChar(String table, int v) {
        if ("ascii".equals(table) || "codepage-1047".equals(table)) {
            return v >= 0x21 && v <= 0x7e ? Character.toString((char) v) : (v == 0x20 ? " " : ".");
        }
        if ("braille".equals(table)) {
            if (v == 0) return "⋄";
            if (v == 9) return "→";
            if (v == 10) return "↵";
            if (v == 13) return "←";
            if (v >= 0x20 && v <= 0x7e) return Character.toString((char) v);
            return Character.toString((char) (0x2800 + v));
        }
        if ("codepage-437".equals(table)) {
            String[] cp = {"⋄","☺","☻","♥","♦","♣","♠","•","◘","○","◙","♂","♀","♪","♫","☼","►","◄","↕","‼","¶","§","▬","↨","↑","↓","→","←","∟","↔","▲","▼"};
            if (v < cp.length) return cp[v];
            if (v >= 0x20 && v <= 0x7e) return Character.toString((char)v);
            if (v == 0x7f) return "⌂";
            if (v == 0x80) return "Ç";
            if (v == 0xff) return "ﬀ";
            return ".";
        }
        if (v == 0) return "⋄";
        if (v == 0x20) return " ";
        if (v == 9 || v == 10 || v == 12 || v == 13) return "_";
        if (v >= 0x21 && v <= 0x7e) return Character.toString((char) v);
        if (v < 0x80) return "•";
        return "×";
    }

    static String borderLine(Opt o, Border b, boolean top) {
        StringBuilder s = new StringBuilder();
        s.append(top ? b.tl : b.bl);
        List<Integer> widths = new ArrayList<>();
        if (o.position) widths.add(8);
        for (int i = 0; i < o.panels; i++) widths.add(hexWidth(o));
        if (o.chars) for (int i = 0; i < o.panels; i++) widths.add(8);
        for (int i = 0; i < widths.size(); i++) {
            s.append(b.h.repeat(widths.get(i)));
            if (i == widths.size() - 1) s.append(top ? b.tr : b.br);
            else s.append(top ? b.tm : b.bm);
        }
        return s.toString();
    }

    static class Border {
        String v,h,tl,tr,bl,br,tm,bm,mid; boolean none;
        static Border of(String style) {
            Border b = new Border();
            if ("ascii".equals(style)) {
                b.v="|"; b.h="-"; b.tl=b.tr=b.bl=b.br=b.tm=b.bm="+"; b.mid="|";
            } else if ("none".equals(style)) {
                b.none=true; b.v=" "; b.h=" "; b.mid=" ";
            } else {
                b.v="│"; b.h="─"; b.tl="┌"; b.tr="┐"; b.bl="└"; b.br="┘"; b.tm="┬"; b.bm="┴"; b.mid="┊";
            }
            return b;
        }
    }

    static void printInclude(Opt o, byte[] data) {
        String name = o.file == null ? "stdin" : Path.of(o.file).getFileName().toString();
        name = name.replaceAll("[^A-Za-z0-9]", "_");
        System.out.println("unsigned char " + name + "[] = {");
        for (int i = 0; i < data.length; i += 12) {
            StringBuilder s = new StringBuilder("  ");
            int n = Math.min(12, data.length - i);
            for (int j = 0; j < n; j++) {
                if (j > 0) s.append(", ");
                s.append(String.format("0x%02x", data[i + j] & 0xff));
            }
            if (i + n < data.length) s.append(",");
            System.out.println(s);
        }
        System.out.println("};");
        System.out.println("unsigned int " + name + "_len = " + data.length + ";");
    }

    static void printColorTable() {
        System.out.println("Color table output is not available in this reimplementation.");
    }

    static void printShortHelp() {
        System.out.println("A command-line hex viewer\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]  The file to display. If no FILE argument is given, read from STDIN\n\nOptions:\n  -n, --length <N>                Only read N bytes from the input\n  -s, --skip <N>                  Skip the first N bytes of the input\n  -v, --no-squeezing              Displays all input data\n      --color <WHEN>              When to use colors [default: always]\n      --border <STYLE>            Whether to draw a border [default: unicode]\n  -p, --plain                     Display plain output\n  -h, --help                      Print help (see more with '--help')\n  -V, --version                   Print version");
    }

    static void printLongHelp() {
        System.out.println("A command-line hex viewer\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]\n          The file to display. If no FILE argument is given, read from STDIN\n\nOptions:\n  -n, --length <N>\n          Only read N bytes from the input. The N argument can also include a unit with a\n          decimal prefix (kB, MB, ..) or binary prefix (kiB, MiB, ..), or can be specified\n          using a hex number. The short option '-l' can be used as an alias.\n          Examples: --length=64, --length=4KiB, --length=0xff\n          \n          [aliases: bytes]\n          [short aliases: c]\n\n  -s, --skip <N>\n          Skip the first N bytes of the input. The N argument can also include a unit (see\n          `--length` for details).\n          A negative value is valid and will seek from the end of the file.\n\n      --block-size <SIZE>\n          Sets the size of the `block` unit to SIZE.\n          Examples: --block-size=1024, --block-size=4kB\n          \n          [default: 512]\n\n  -v, --no-squeezing\n          Displays all input data. Otherwise any number of groups of output lines which\n          would be identical to the preceding group of lines, are replaced with a line\n          comprised of a single asterisk\n\n      --color <WHEN>\n          When to use colors\n          \n          [default: always]\n\n          Possible values:\n          - always: Always use colorized output\n          - auto:   Only displays colors if the output goes to an interactive terminal\n          - never:  Do not use colorized output\n          - force:  Override the NO_COLOR environment variable\n\n      --border <STYLE>\n          Whether to draw a border\n          \n          [default: unicode]\n\n          Possible values:\n          - unicode: Draw a border with Unicode characters\n          - ascii:   Draw a border with ASCII characters\n          - none:    Do not draw a border at all\n\n  -p, --plain\n          Display output with --no-characters, --no-position, --border=none, and\n          --color=never\n\n      --no-characters\n          Do not show the character panel on the right\n\n  -C, --characters\n          Show the character panel on the right. This is the default, unless\n          --no-characters has been specified\n\n      --character-table <FORMAT>\n          Defines how bytes are mapped to characters\n          \n          [default: default]\n\n          Possible values:\n          - default\n          - ascii\n          - codepage-1047\n          - codepage-437\n          - braille\n\n  -P, --no-position\n          Whether to display the position panel on the left\n\n  -o, --display-offset <N>\n          Add N bytes to the displayed file position.\n          \n          [default: 0]\n\n      --panels <N>\n          Sets the number of hex data panels to be displayed.\n\n  -g, --group-size <N>\n          Number of bytes/octets that should be grouped together.\n          \n          [default: 1]\n\n      --endianness <FORMAT>\n          Whether to print out groups in little-endian or big-endian format.\n          \n          [default: big]\n\n  -b, --base <B>\n          Sets the base used for the bytes.\n          \n          [default: hexadecimal]\n\n      --terminal-width <N>\n          Sets the number of terminal columns to be displayed.\n\n      --print-color-table\n          Print a table showing how different types of bytes are colored\n\n  -i, --include\n          Output in C include file style\n\n      --completion <SHELL>\n          Show shell completion for a certain shell\n          \n          [possible values: bash, elvish, fish, powershell, zsh]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
    }
}
