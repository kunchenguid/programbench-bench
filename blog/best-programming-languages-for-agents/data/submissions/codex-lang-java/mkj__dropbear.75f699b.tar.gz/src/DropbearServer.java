import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class DropbearServer {
    private static final String VERSION = "2025.89";
    private static final String[] DEFAULT_KEYS = {
            "/etc/dropbear/dropbear_rsa_host_key",
            "/etc/dropbear/dropbear_ecdsa_host_key",
            "/etc/dropbear/dropbear_ed25519_host_key"
    };
    private static final DateTimeFormatter TIME_FMT =
            DateTimeFormatter.ofPattern("MMM HH:mm:ss", Locale.US);
    private static final AtomicBoolean RUNNING_SERVER = new AtomicBoolean(false);

    private static final class ListenSpec {
        final String host;
        final int port;

        ListenSpec(String host, int port) {
            this.host = host;
            this.port = port;
        }
    }

    private static final class Options {
        String prog = "./executable";
        boolean foreground;
        boolean generateKeys;
        boolean inetd;
        boolean sawVersion;
        final List<String> hostKeys = new ArrayList<>();
        final List<ListenSpec> listens = new ArrayList<>();
        String pidFile = "/var/run/dropbear.pid";
    }

    public static void main(String[] rawArgs) throws Exception {
        Options opts = new Options();
        int start = 0;
        if (rawArgs.length > 0 && rawArgs[0].startsWith("__prog=")) {
            opts.prog = rawArgs[0].substring("__prog=".length());
            start = 1;
        }

        try {
            parse(opts, rawArgs, start);
        } catch (Help h) {
            printHelp(opts.prog);
            System.exit(h.status);
        } catch (Die d) {
            log("Early exit: " + d.getMessage());
            System.exit(1);
        }

        if (opts.sawVersion) {
            System.err.println("Dropbear v" + VERSION);
            return;
        }

        if (!opts.generateKeys && !hasAnyHostKey(opts)) {
            for (String key : keysToLoad(opts)) {
                log("Failed loading " + key);
            }
            log("Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
            System.exit(1);
        }

        if (opts.listens.isEmpty()) {
            opts.listens.add(new ListenSpec(null, 22));
        }

        if (opts.inetd) {
            serveOne(System.in, System.out);
            return;
        }

        if (opts.foreground) {
            log("Not backgrounding");
            RUNNING_SERVER.set(true);
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                if (RUNNING_SERVER.get()) {
                    log("Early exit: Terminated by signal");
                }
            }));
            runServers(opts);
        } else {
            log("Running in background");
            background(opts);
        }
    }

    private static void parse(Options opts, String[] args, int start) {
        for (int i = start; i < args.length; i++) {
            String arg = args[i];
            if (!arg.startsWith("-") || arg.equals("-")) {
                throw new Die("Invalid argument: " + arg);
            }
            if (arg.equals("--")) {
                if (i + 1 < args.length) {
                    throw new Die("Invalid argument: " + args[i + 1]);
                }
                return;
            }
            for (int pos = 1; pos < arg.length(); pos++) {
                char c = arg.charAt(pos);
                switch (c) {
                    case 'h':
                        throw new Help(0);
                    case 'V':
                        opts.sawVersion = true;
                        return;
                    case 'F':
                        opts.foreground = true;
                        break;
                    case 'R':
                        opts.generateKeys = true;
                        break;
                    case 'i':
                        opts.inetd = true;
                        break;
                    case 'e':
                    case 'm':
                    case 'w':
                    case 's':
                    case 'g':
                    case 'B':
                    case 't':
                    case 'j':
                    case 'k':
                    case 'a':
                    case 'z':
                        break;
                    case 'b':
                    case 'r':
                    case 'D':
                    case 'G':
                    case 'T':
                    case 'c':
                    case 'p':
                    case 'P':
                    case 'l':
                    case 'W':
                    case 'K':
                    case 'I': {
                        String val;
                        if (pos + 1 < arg.length()) {
                            val = arg.substring(pos + 1);
                            pos = arg.length();
                        } else {
                            if (i + 1 >= args.length) {
                                throw new Die("Missing argument");
                            }
                            val = args[++i];
                        }
                        consumeArg(opts, c, val);
                        break;
                    }
                    default:
                        if (arg.equals("--help")) {
                            System.err.println("Invalid option --");
                        } else {
                            System.err.println("Invalid option -" + c);
                        }
                        throw new Help(1);
                }
            }
        }
    }

    private static void consumeArg(Options opts, char c, String val) {
        switch (c) {
            case 'r':
                opts.hostKeys.add(val);
                break;
            case 'T':
                parseNonNegative(val, "maxauthtries");
                if ("0".equals(val)) {
                    // Dropbear accepts zero here in option parsing.
                }
                break;
            case 'K':
                parseNonNegative(val, "keepalive");
                break;
            case 'I':
                parseNonNegative(val, "idle_timeout");
                break;
            case 'W':
                parseWindow(val);
                break;
            case 'p':
                opts.listens.add(parseListen(val));
                break;
            case 'P':
                opts.pidFile = val;
                break;
            default:
                break;
        }
    }

    private static void parseNonNegative(String val, String name) {
        try {
            if (Integer.parseInt(val) < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            throw new Die("Bad " + name + " '" + val + "'");
        }
    }

    private static void parseWindow(String val) {
        try {
            int parsed = Integer.parseInt(val);
            if (parsed < 0) {
                log("Bad recv window '" + val + "', using 24576");
            } else if (parsed > 10 * 1024 * 1024) {
                log("Bad recv window '" + val + "', using 10485760");
            }
        } catch (NumberFormatException e) {
            log("Bad recv window '" + val + "', using 24576");
        }
    }

    private static ListenSpec parseListen(String value) {
        String host = null;
        String portText = value;
        int colon = value.lastIndexOf(':');
        if (colon >= 0) {
            host = value.substring(0, colon);
            if (host.isEmpty()) {
                host = null;
            }
            portText = value.substring(colon + 1);
        }
        int port;
        try {
            port = Integer.parseInt(portText);
        } catch (NumberFormatException e) {
            port = 22;
        }
        return new ListenSpec(host, port);
    }

    private static boolean hasAnyHostKey(Options opts) {
        for (String key : keysToLoad(opts)) {
            if (Files.isReadable(Path.of(key))) {
                return true;
            }
        }
        return false;
    }

    private static List<String> keysToLoad(Options opts) {
        if (!opts.hostKeys.isEmpty()) {
            return opts.hostKeys;
        }
        return List.of(DEFAULT_KEYS);
    }

    private static void runServers(Options opts) throws IOException {
        List<ServerSocket> sockets = new ArrayList<>();
        for (ListenSpec spec : opts.listens) {
            ServerSocket server;
            if (spec.host == null) {
                server = new ServerSocket(spec.port);
            } else {
                server = new ServerSocket(spec.port, 50, InetAddress.getByName(spec.host));
            }
            sockets.add(server);
            Thread t = new Thread(() -> acceptLoop(server), "dropbear-listener");
            t.setDaemon(false);
            t.start();
        }
        try {
            Thread.sleep(Long.MAX_VALUE);
        } catch (InterruptedException ignored) {
            for (ServerSocket s : sockets) {
                try {
                    s.close();
                } catch (IOException ignored2) {
                }
            }
        }
    }

    private static void background(Options opts) throws IOException {
        String cp = System.getProperty("java.class.path");
        List<String> cmd = new ArrayList<>();
        cmd.add(System.getProperty("java.home") + "/bin/java");
        cmd.add("-cp");
        cmd.add(cp);
        cmd.add(DropbearServer.class.getName());
        cmd.add("__prog=" + opts.prog);
        cmd.add("-R");
        cmd.add("-F");
        for (ListenSpec spec : opts.listens) {
            cmd.add("-p");
            cmd.add((spec.host == null ? "" : spec.host + ":") + spec.port);
        }
        new ProcessBuilder(cmd).redirectOutput(ProcessBuilder.Redirect.DISCARD)
                .redirectError(ProcessBuilder.Redirect.DISCARD).start();
    }

    private static void acceptLoop(ServerSocket server) {
        while (true) {
            try (Socket socket = server.accept()) {
                serveSocket(socket);
            } catch (IOException ignored) {
                return;
            }
        }
    }

    private static void serveSocket(Socket socket) throws IOException {
        String remote = socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
        log("Child connection from " + remote);
        OutputStream out = socket.getOutputStream();
        out.write(("SSH-2.0-dropbear_" + VERSION + "\r\n").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        socket.setSoTimeout(1000);
        try {
            new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.US_ASCII)).readLine();
        } catch (IOException ignored) {
        }
        log("Exit before auth from <" + remote + ">: Exited normally");
    }

    private static void serveOne(java.io.InputStream in, java.io.PrintStream out) throws IOException {
        out.print("SSH-2.0-dropbear_" + VERSION + "\r\n");
        out.flush();
    }

    private static void printHelp(String prog) {
        System.err.print("Dropbear server v" + VERSION + " https://matt.ucc.asn.au/dropbear/dropbear.html\n" +
                "Usage: " + prog + " [options]\n" +
                "-b bannerfile\tDisplay the contents of bannerfile before user login\n" +
                "\t\t(default: none)\n" +
                "-r keyfile      Specify hostkeys (repeatable)\n" +
                "\t\tdefaults: \n" +
                "\t\t- rsa /etc/dropbear/dropbear_rsa_host_key\n" +
                "\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key\n" +
                "\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key\n" +
                "-D\t\tDirectory containing authorized_keys file\n" +
                "-R\t\tCreate hostkeys as required\n" +
                "-F\t\tDon't fork into background\n" +
                "-e\t\tPass on server process environment to child process\n" +
                "(Syslog support not compiled in, using stderr)\n" +
                "-m\t\tDon't display the motd on login\n" +
                "-w\t\tDisallow root logins\n" +
                "-G\t\tRestrict logins to members of specified group\n" +
                "-s\t\tDisable password logins\n" +
                "-g\t\tDisable password logins for root\n" +
                "-B\t\tAllow blank password logins\n" +
                "-t\t\tEnable two-factor authentication (both password and public key required)\n" +
                "-T\t\tMaximum authentication tries (default 10)\n" +
                "-j\t\tDisable local port forwarding\n" +
                "-k\t\tDisable remote port forwarding\n" +
                "-a\t\tAllow connections to forwarded ports from any host\n" +
                "-c command\tForce executed command\n" +
                "-p [address:]port\n" +
                "\t\tListen on specified tcp port (and optionally address),\n" +
                "\t\tup to 10 can be specified\n" +
                "\t\t(default port is 22 if none specified)\n" +
                "-P PidFile\tCreate pid file PidFile\n" +
                "\t\t(default /var/run/dropbear.pid)\n" +
                "-l <interface>\n" +
                "\t\tinterface to bind on\n" +
                "-i\t\tStart for inetd\n" +
                "-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)\n" +
                "-K <keepalive>  (0 is never, default 0, in seconds)\n" +
                "-I <idle_timeout>  (0 is never, default 0, in seconds)\n" +
                "-z    disable QoS\n" +
                "-V    Version\n");
    }

    private static void log(String msg) {
        long pid = ProcessHandle.current().pid();
        LocalDateTime now = LocalDateTime.now();
        String monTime = now.format(TIME_FMT);
        String day = String.format(Locale.US, "%2d", now.getDayOfMonth());
        String month = monTime.substring(0, 3);
        String time = monTime.substring(4);
        System.err.println("[" + pid + "] " + month + " " + day + " " + time + " " + msg);
    }

    private static final class Help extends RuntimeException {
        final int status;
        Help(int status) {
            this.status = status;
        }
    }

    private static final class Die extends RuntimeException {
        Die(String message) {
            super(message);
        }
    }
}
