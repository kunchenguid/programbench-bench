import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.security.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.Base64;
import java.util.regex.*;
import java.util.stream.*;

public class FSelect {
    static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    static boolean noErrors = false;

    public static void main(String[] args) {
        try {
            List<String> a = new ArrayList<>(Arrays.asList(args));
            if (a.isEmpty()) { interactive(); return; }
            for (Iterator<String> it = a.iterator(); it.hasNext();) {
                String s = it.next();
                if (s.equals("--help") || s.equals("-h") || s.equals("/?") || s.equals("/h")) { help(); return; }
                if (s.equals("--nocolor") || s.equals("--no-color") || s.equals("--us-dates")) { it.remove(); continue; }
                if (s.equals("--no-errors")) { noErrors = true; it.remove(); continue; }
                if (s.equals("--config") || s.equals("-c") || s.equals("/config")) { it.remove(); if (it.hasNext()) { it.next(); it.remove(); } continue; }
                if (s.equals("--interactive") || s.equals("-i") || s.equals("/i")) { interactive(); return; }
            }
            if (a.isEmpty()) { interactive(); return; }
            run(String.join(" ", a), Paths.get("").toAbsolutePath().normalize());
        } catch (ParseError e) {
            if (!noErrors) System.err.println(e.getMessage());
            System.exit(2);
        } catch (Exception e) {
            if (!noErrors) System.err.println(e.getMessage());
            System.exit(1);
        }
    }

    static void help() {
        System.out.println("fselect 0.10.0");
        System.out.println("Find files with SQL-like queries.");
        System.out.println("https://github.com/jhspetersson/fselect");
        System.out.println();
        System.out.println("Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]");
        System.out.println();
        System.out.println("Column Options:");
        System.out.println("    name, filename, ext, path, abspath, dir, absdir, size, fsize");
        System.out.println("    uid, gid, user, group, created, accessed, modified, atime, mtime, ctime");
        System.out.println("    is_dir, is_file, is_symlink, mode, is_hidden, is_empty, line_count");
        System.out.println("    is_archive, is_audio, is_book, is_doc, is_font, is_image, is_source, is_video");
        System.out.println("    mime, sha1, sha256, sha512");
        System.out.println();
        System.out.println("Format: tabs, lines, list, csv, json, html");
    }

    static void interactive() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        Path cwd = Paths.get("").toAbsolutePath().normalize();
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.equalsIgnoreCase("exit") || line.equalsIgnoreCase("quit")) break;
            if (line.equalsIgnoreCase("help")) { help(); continue; }
            if (line.equalsIgnoreCase("pwd")) { System.out.println(cwd); continue; }
            if (line.toLowerCase(Locale.ROOT).startsWith("cd ")) { cwd = cwd.resolve(line.substring(3).trim()).normalize(); continue; }
            if (line.toLowerCase(Locale.ROOT).startsWith("errors")) { noErrors = !line.toLowerCase(Locale.ROOT).contains("off"); continue; }
            if (!line.isEmpty()) run(line, cwd);
        }
    }

    static void run(String query, Path cwd) throws Exception {
        Query q = Parser.parse(query);
        List<Row> rows = new ArrayList<>();
        for (RootSpec r : q.roots) rows.addAll(scan(r, cwd));
        if (q.where != null) rows = rows.stream().filter(row -> truth(q.where.eval(row))).collect(Collectors.toList());
        List<ResultRow> out;
        if (!q.groupBy.isEmpty()) out = grouped(q, rows);
        else if (q.hasAggregate()) out = Collections.singletonList(aggregate(q.columns, rows, null));
        else {
            if (!q.orderBy.isEmpty()) sortRows(rows, q.orderBy);
            out = rows.stream().map(row -> project(q.columns, row, null)).collect(Collectors.toList());
        }
        if ((!q.groupBy.isEmpty() || q.hasAggregate()) && !q.orderBy.isEmpty()) sort(out, q.orderBy);
        int from = Math.min(q.offset, out.size());
        int to = q.limit >= 0 ? Math.min(from + q.limit, out.size()) : out.size();
        output(out.subList(from, to), q.format);
    }

    static List<Row> scan(RootSpec spec, Path cwd) {
        List<Row> rows = new ArrayList<>();
        Path root = cwd.resolve(spec.path).normalize();
        try { root = root.toRealPath(spec.followLinks ? new LinkOption[]{} : new LinkOption[]{LinkOption.NOFOLLOW_LINKS}); }
        catch (Exception e) { if (!noErrors) System.err.println(spec.path + ": could not canonicalize path: " + e.getMessage()); return rows; }
        ArrayDeque<Item> dq = new ArrayDeque<>();
        dq.add(new Item(root, 0));
        while (!dq.isEmpty()) {
            Item it = spec.dfs ? dq.removeLast() : dq.removeFirst();
            if (it.depth > 0 && it.depth >= spec.mindepth) rows.add(new Row(root, it.path));
            if (it.depth >= spec.maxdepth) continue;
            if (!Files.isDirectory(it.path, LinkOption.NOFOLLOW_LINKS)) continue;
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(it.path)) {
                List<Path> children = new ArrayList<>();
                for (Path p : ds) children.add(p);
                if (spec.dfs) Collections.reverse(children);
                for (Path p : children) dq.add(new Item(p, it.depth + 1));
            } catch (Exception e) { if (!noErrors) System.err.println(it.path + ": " + e.getMessage()); }
        }
        return rows;
    }

    static class Item { Path path; int depth; Item(Path p, int d){path=p;depth=d;} }

    static ResultRow project(List<Expr> cols, Row row, List<Row> group) {
        ResultRow rr = new ResultRow();
        for (Expr e : cols) rr.add(label(e), str(e.eval(row, group)));
        return rr;
    }
    static ResultRow aggregate(List<Expr> cols, List<Row> rows, Row keyRow) {
        ResultRow rr = new ResultRow();
        Row sample = keyRow != null ? keyRow : (rows.isEmpty() ? null : rows.get(0));
        for (Expr e : cols) rr.add(label(e), str(e.eval(sample, rows)));
        return rr;
    }
    static List<ResultRow> grouped(Query q, List<Row> rows) {
        LinkedHashMap<String, List<Row>> groups = new LinkedHashMap<>();
        for (Row r : rows) {
            String k = q.groupBy.stream().map(e -> str(e.eval(r, null))).collect(Collectors.joining("\u0001"));
            groups.computeIfAbsent(k, x -> new ArrayList<>()).add(r);
        }
        List<ResultRow> out = new ArrayList<>();
        for (List<Row> g : groups.values()) out.add(aggregate(q.columns, g, g.get(0)));
        return out;
    }

    static void sort(List<ResultRow> rows, List<Order> orders) {
        rows.sort((a,b) -> {
            for (Order o : orders) {
                int idx = o.index >= 0 ? o.index : a.indexOfLabel(canonLabel(o.name));
                String av = idx >= 0 && idx < a.values.size() ? a.values.get(idx) : "";
                String bv = idx >= 0 && idx < b.values.size() ? b.values.get(idx) : "";
                int c = compareValues(av, bv);
                if (c != 0) return o.desc ? -c : c;
            }
            return 0;
        });
    }
    static void sortRows(List<Row> rows, List<Order> orders) {
        rows.sort((a,b) -> {
            for (Order o : orders) {
                if (o.index >= 0) continue;
                String av = str(o.expr.eval(a, null)), bv = str(o.expr.eval(b, null));
                int c = compareValues(av, bv);
                if (c != 0) return o.desc ? -c : c;
            }
            return 0;
        });
    }
    static int compareValues(String a, String b) {
        Double da = numOrNull(a), db = numOrNull(b);
        if (da != null && db != null) return Double.compare(da, db);
        return a.compareTo(b);
    }

    static void output(List<ResultRow> rows, String fmt) {
        switch (fmt) {
            case "lines":
                for (ResultRow r: rows) for (String v: r.values) System.out.println(v);
                break;
            case "list":
                for (ResultRow r: rows) for (String v: r.values) System.out.print(v + "\0");
                break;
            case "csv":
                for (ResultRow r: rows) System.out.println(r.values.stream().map(FSelect::csv).collect(Collectors.joining(",")));
                break;
            case "json":
                System.out.print("[");
                for (int i=0;i<rows.size();i++) {
                    if (i>0) System.out.print(",");
                    ResultRow r=rows.get(i); System.out.print("{");
                    for (int j=0;j<r.values.size();j++) {
                        if (j>0) System.out.print(",");
                        System.out.print("\""+json(r.labels.get(j))+"\":\""+json(r.values.get(j))+"\"");
                    }
                    System.out.print("}");
                }
                System.out.print("]");
                break;
            case "html":
                System.out.println("<html><body><table>");
                for (ResultRow r: rows) System.out.println("<tr>" + r.values.stream().map(v -> "<td>"+html(v)+"</td>").collect(Collectors.joining()) + "</tr>");
                System.out.println("</table></body></html>");
                break;
            default:
                for (ResultRow r: rows) System.out.println(String.join("\t", r.values));
        }
    }
    static String csv(String s){ return s.matches(".*[\",\n\r].*") ? "\"" + s.replace("\"","\"\"") + "\"" : s; }
    static String json(String s){ return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t"); }
    static String html(String s){ return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;"); }

    static class Row {
        Path root, path;
        BasicFileAttributes basic; PosixFileAttributes posix; Integer mode;
        Row(Path root, Path path){this.root=root;this.path=path;}
        BasicFileAttributes basic() {
            if (basic == null) try { basic = Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); } catch(Exception e){ throw new RuntimeException(e); }
            return basic;
        }
        PosixFileAttributes posix() {
            if (posix == null) try { posix = Files.readAttributes(path, PosixFileAttributes.class, LinkOption.NOFOLLOW_LINKS); } catch(Exception e){ return null; }
            return posix;
        }
        int mode() {
            if (mode != null) return mode;
            try { mode = (Integer)Files.getAttribute(path, "unix:mode", LinkOption.NOFOLLOW_LINKS); } catch(Exception e){ mode = 0; }
            return mode;
        }
        String field(String raw) {
            String f = raw.toLowerCase(Locale.ROOT);
            String name = path.getFileName().toString();
            String ext = extension(name);
            try {
                switch (f) {
                    case "*": return "";
                    case "name": return name;
                    case "filename": case "fname": return ext.isEmpty()?name:name.substring(0, name.length()-ext.length()-1);
                    case "ext": case "extension": return ext;
                    case "path": return root.relativize(path).toString();
                    case "abspath": return path.toAbsolutePath().normalize().toString();
                    case "dir": case "directory": case "dirname": { Path rel=root.relativize(path).getParent(); return rel==null?"":rel.toString(); }
                    case "absdir": { Path p=path.getParent(); return p==null?"":p.toAbsolutePath().normalize().toString(); }
                    case "size": return Long.toString(basic().isDirectory()?4096:basic().size());
                    case "fsize": case "hsize": return formatSize(basic().isDirectory()?4096:basic().size());
                    case "created": return time(basic().creationTime());
                    case "accessed": return time(basic().lastAccessTime());
                    case "modified": return time(basic().lastModifiedTime());
                    case "atime": return Long.toString(basic().lastAccessTime().toMillis()/1000);
                    case "mtime": return Long.toString(basic().lastModifiedTime().toMillis()/1000);
                    case "ctime": return Long.toString(((Number)Files.getAttribute(path,"unix:ctime", LinkOption.NOFOLLOW_LINKS)).longValue());
                    case "uid": return attr("unix:uid");
                    case "gid": return attr("unix:gid");
                    case "user": return posix()!=null?posix().owner().getName():"";
                    case "group": return posix()!=null?posix().group().getName():"";
                    case "is_dir": return bool(Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS));
                    case "is_file": return bool(Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS));
                    case "is_symlink": return bool(Files.isSymbolicLink(path));
                    case "is_hidden": return bool(name.startsWith("."));
                    case "is_empty": return bool(isEmpty());
                    case "is_pipe": case "is_fifo": return bool((mode() & 0170000) == 0010000);
                    case "is_char": case "is_character": return bool((mode() & 0170000) == 0020000);
                    case "is_block": return bool((mode() & 0170000) == 0060000);
                    case "is_socket": return bool((mode() & 0170000) == 0140000);
                    case "mode": return modeString();
                    case "user_read": return bit(0400); case "user_write": return bit(0200); case "user_exec": return bit(0100);
                    case "user_all": case "user_rwx": return bool((mode() & 0700)==0700);
                    case "group_read": return bit(0040); case "group_write": return bit(0020); case "group_exec": return bit(0010);
                    case "group_all": case "group_rwx": return bool((mode() & 0070)==0070);
                    case "other_read": return bit(0004); case "other_write": return bit(0002); case "other_exec": return bit(0001);
                    case "other_all": case "other_rwx": return bool((mode() & 0007)==0007);
                    case "suid": case "is_suid": return bit(04000);
                    case "sgid": case "is_sgid": return bit(02000);
                    case "sticky": case "is_sticky": return bit(01000);
                    case "device": return attr("unix:dev"); case "rdev": return attr("unix:rdev");
                    case "inode": return attr("unix:ino"); case "hardlinks": return attr("unix:nlink");
                    case "blocks": { long s=basic().isDirectory()?4096:basic().size(); return Long.toString((s+255)/256); }
                    case "line_count": return Long.toString(lineCount());
                    case "is_binary": return bool(isBinary()); case "is_text": return bool(!isBinary());
                    case "mime": return mime(ext);
                    case "is_archive": return in(ext,"7z,bz2,bzip2,gz,gzip,lz,rar,tar,xz,zip");
                    case "is_audio": return in(ext,"aac,aiff,amr,flac,gsm,m4a,m4b,m4p,mp3,ogg,wav,wma");
                    case "is_book": return in(ext,"azw3,chm,djv,djvu,epub,fb2,mobi,pdf");
                    case "is_doc": return in(ext,"accdb,doc,docm,docx,dot,dotm,dotx,mdb,odp,ods,odt,pdf,potm,potx,ppt,pptm,pptx,rtf,xlm,xls,xlsm,xlsx,xlt,xltm,xltx,xps");
                    case "is_font": return in(ext,"eot,fon,otc,otf,ttc,ttf,woff,woff2");
                    case "is_image": return in(ext,"bmp,exr,gif,heic,jpeg,jpg,jxl,png,psb,psd,svg,tga,tiff,webp");
                    case "is_source": return in(ext,"asm,awk,bas,c,cc,ceylon,clj,coffee,cpp,cs,d,dart,elm,erl,go,gradle,groovy,h,hh,hpp,java,jl,js,jsp,jsx,kt,kts,lua,nim,pas,php,pl,pm,py,rb,rs,scala,sol,swift,tcl,ts,tsx,vala,vb,zig");
                    case "is_video": return in(ext,"3gp,avi,flv,m4p,m4v,mkv,mov,mp4,mpeg,mpg,webm,wmv");
                    case "sha1": return digest("SHA-1"); case "sha256": case "sha2_256": return digest("SHA-256"); case "sha512": case "sha2_512": return digest("SHA-512");
                    default: return "";
                }
            } catch (Exception e) { return ""; }
        }
        String attr(String a) throws Exception { return String.valueOf(Files.getAttribute(path,a,LinkOption.NOFOLLOW_LINKS)); }
        String bit(int b){ return bool((mode() & b) != 0); }
        boolean isEmpty() throws IOException { if (Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)) try(Stream<Path>s=Files.list(path)){return !s.findAny().isPresent();} return basic().size()==0; }
        long lineCount() { try(Stream<String>s=Files.lines(path)){return s.count();} catch(Exception e){return 0;} }
        boolean isBinary(){ try(InputStream in=Files.newInputStream(path)){ byte[] b=in.readNBytes(1024); for(byte x:b) if(x==0) return true; return false;}catch(Exception e){return false;} }
        String digest(String alg){ if(!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) return ""; try(InputStream in=Files.newInputStream(path)){ MessageDigest md=MessageDigest.getInstance(alg); byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) md.update(b,0,n); StringBuilder sb=new StringBuilder(); for(byte x:md.digest()) sb.append(String.format("%02x",x)); return sb.toString();}catch(Exception e){return "";} }
        String modeString() {
            int m=mode(); char t=Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS)?'d':Files.isSymbolicLink(path)?'l':((m&0170000)==0010000?'p':((m&0170000)==0140000?'s':'-'));
            char[] c=(t+"rwxrwxrwx").toCharArray();
            int[] bits={0400,0200,0100,040,020,010,04,02,01};
            for(int i=0;i<bits.length;i++) if((m&bits[i])==0) c[i+1]='-';
            if((m&04000)!=0)c[3]=(c[3]=='x')?'s':'S'; if((m&02000)!=0)c[6]=(c[6]=='x')?'s':'S'; if((m&01000)!=0)c[9]=(c[9]=='x')?'t':'T';
            return new String(c);
        }
    }

    interface Expr { Object eval(Row r, List<Row> group); String source(); default boolean agg(){return false;} }
    static class Field implements Expr { String n; Field(String n){this.n=n;} public Object eval(Row r,List<Row>g){return r==null?"":r.field(n);} public String source(){return n;} }
    static class Lit implements Expr { String v; Lit(String v){this.v=v;} public Object eval(Row r,List<Row>g){return v;} public String source(){return v;} }
    static class Num implements Expr { String v; Num(String v){this.v=v;} public Object eval(Row r,List<Row>g){return v;} public String source(){return v;} }
    static class Func implements Expr {
        String n; List<Expr> args; Func(String n,List<Expr>a){this.n=n.toLowerCase(Locale.ROOT);this.args=a;}
        public boolean agg(){ return Set.of("count","min","max","avg","sum","stddev","stddev_pop","std","stddev_samp","var_pop","variance","var_samp").contains(n); }
        public Object eval(Row r,List<Row>g) {
            if (agg()) return aggregateFunc(g==null?Collections.emptyList():g);
            List<String> vs=args.stream().map(e->str(e.eval(r,g))).collect(Collectors.toList());
            try {
                switch(n) {
                    case "lower": case "lowercase": case "lcase": return vs.get(0).toLowerCase(Locale.ROOT);
                    case "upper": case "uppercase": case "ucase": return vs.get(0).toUpperCase(Locale.ROOT);
                    case "length": case "len": return Integer.toString(vs.get(0).length());
                    case "initcap": return Arrays.stream(vs.get(0).split(" ")).map(s->s.isEmpty()?s:s.substring(0,1).toUpperCase()+s.substring(1).toLowerCase()).collect(Collectors.joining(" "));
                    case "concat": return String.join("", vs);
                    case "concat_ws": return vs.size()<2?"":String.join(vs.get(0), vs.subList(1,vs.size()));
                    case "trim": return vs.get(0).trim(); case "ltrim": return vs.get(0).replaceFirst("^\\s+",""); case "rtrim": return vs.get(0).replaceFirst("\\s+$","");
                    case "replace": return vs.get(0).replace(vs.get(1), vs.size()>2?vs.get(2):"");
                    case "substr": case "substring": { String s=vs.get(0); int p=(int)parseNumber(vs.get(1)); if(p<0)p=s.length()+p+1; p=Math.max(1,p); int len=vs.size()>2?(int)parseNumber(vs.get(2)):s.length(); return s.substring(Math.min(p-1,s.length()), Math.min(p-1+len,s.length())); }
                    case "to_base64": case "base64": return Base64.getEncoder().encodeToString(vs.get(0).getBytes(StandardCharsets.UTF_8));
                    case "from_base64": return new String(Base64.getDecoder().decode(vs.get(0)), StandardCharsets.UTF_8);
                    case "year": return datePart(vs.get(0), "y"); case "month": return datePart(vs.get(0), "m"); case "day": return datePart(vs.get(0), "d");
                    case "current_date": case "cur_date": case "curdate": return LocalDate.now().toString();
                    case "current_time": case "cur_time": case "curtime": return LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
                    case "current_timestamp": case "now": return LocalDateTime.now().format(DTF);
                    case "format_size": case "format_filesize": return formatSize((long)parseNumber(vs.get(0)));
                    case "abs": return numstr(Math.abs(parseNumber(vs.get(0))));
                    case "floor": return Long.toString((long)Math.floor(parseNumber(vs.get(0))));
                    case "ceil": case "ceiling": return Long.toString((long)Math.ceil(parseNumber(vs.get(0))));
                    case "round": return Long.toString(Math.round(parseNumber(vs.get(0))));
                    case "sqrt": return numstr(Math.sqrt(parseNumber(vs.get(0))));
                    case "pow": case "power": return numstr(Math.pow(parseNumber(vs.get(0)), parseNumber(vs.get(1))));
                    case "contains": return bool(r!=null && Files.isRegularFile(r.path) && Files.readString(r.path).contains(vs.get(0)));
                    case "coalesce": return vs.stream().filter(s->!s.isEmpty()).findFirst().orElse("");
                }
            } catch(Exception e) { return ""; }
            return "";
        }
        Object aggregateFunc(List<Row> rows) {
            if (n.equals("count")) return Integer.toString(rows.size());
            List<Double> vals = rows.stream().map(row -> args.isEmpty()?0:parseNumber(str(args.get(0).eval(row,null)))).collect(Collectors.toList());
            if (vals.isEmpty()) return "";
            switch(n) {
                case "min": return numstr(vals.stream().min(Double::compare).get());
                case "max": return numstr(vals.stream().max(Double::compare).get());
                case "sum": return numstr(vals.stream().mapToDouble(Double::doubleValue).sum());
                case "avg": return numstr(vals.stream().mapToDouble(Double::doubleValue).average().orElse(0));
                default: {
                    double avg=vals.stream().mapToDouble(Double::doubleValue).average().orElse(0), ss=0; for(double v:vals)ss+=(v-avg)*(v-avg);
                    boolean samp=n.endsWith("samp"); double var= rows.size()>(samp?1:0) ? ss/(rows.size()-(samp?1:0)) : 0;
                    return n.startsWith("var")||n.equals("variance")?numstr(var):numstr(Math.sqrt(var));
                }
            }
        }
        public String source(){return n+"("+args.stream().map(Expr::source).collect(Collectors.joining(","))+")";}
    }
    static class Binary implements Expr { Expr a,b; String op; Binary(Expr a,String op,Expr b){this.a=a;this.op=op;this.b=b;} public Object eval(Row r,List<Row>g){ double x=parseNumber(str(a.eval(r,g))), y=parseNumber(str(b.eval(r,g))); switch(op){case "+":return numstr(x+y);case "-":return numstr(x-y);case "*":return numstr(x*y);case "/":return y==0?"":numstr(x/y);default:return numstr(x%y);} } public String source(){return a.source()+op+b.source();} }

    interface Cond { Object eval(Row r); }
    static class ExprCond implements Cond { Expr e; ExprCond(Expr e){this.e=e;} public Object eval(Row r){ return truth(e.eval(r,null)); } }
    static class NotCond implements Cond { Cond c; NotCond(Cond c){this.c=c;} public Object eval(Row r){return !truth(c.eval(r));} }
    static class LogicCond implements Cond { Cond a,b; String op; LogicCond(Cond a,String op,Cond b){this.a=a;this.op=op;this.b=b;} public Object eval(Row r){ return op.equals("and") ? truth(a.eval(r))&&truth(b.eval(r)) : truth(a.eval(r))||truth(b.eval(r)); } }
    static class CmpCond implements Cond {
        Expr a,b,c; String op; List<Expr> list;
        CmpCond(Expr a,String op,Expr b){this.a=a;this.op=op;this.b=b;}
        public Object eval(Row r) {
            String av=str(a.eval(r,null)), bv=value(b, r);
            switch(op) {
                case "=": case "==": case "eq": return eq(av,bv,false);
                case "===": case "eeq": return av.equals(bv);
                case "!=": case "<>": case "ne": return !eq(av,bv,false);
                case "!==": case "ene": return !av.equals(bv);
                case ">": case "gt": return compareValues(av,bv)>0; case ">=": case "gte": case "ge": return compareValues(av,bv)>=0;
                case "<": case "lt": return compareValues(av,bv)<0; case "<=": case "lte": case "le": return compareValues(av,bv)<=0;
                case "=~": case "~=": case "regexp": case "rx": return Pattern.compile(bv).matcher(av).find();
                case "!=~": case "!~=": case "notrx": return !Pattern.compile(bv).matcher(av).find();
                case "like": return like(av,bv); case "notlike": return !like(av,bv);
                case "between": return compareValues(av,bv)>=0 && compareValues(av,value(c, r))<=0;
                case "in": return list.stream().anyMatch(e -> eq(av, value(e, r), true));
                case "notin": return list.stream().noneMatch(e -> eq(av, value(e, r), true));
            }
            return false;
        }
        String value(Expr e, Row r) { if (e == null) return ""; if (e instanceof Field && !knownField(((Field)e).n)) return ((Field)e).n; return str(e.eval(r,null)); }
    }

    static class Query {
        List<Expr> columns = new ArrayList<>(), groupBy = new ArrayList<>(); List<RootSpec> roots = new ArrayList<>(); List<Order> orderBy = new ArrayList<>();
        Cond where; int limit=-1, offset=0; String format="tabs";
        boolean hasAggregate(){ return columns.stream().anyMatch(Expr::agg); }
    }
    static class RootSpec { String path="."; int mindepth=1, maxdepth=Integer.MAX_VALUE; boolean followLinks=false, dfs=false; }
    static class Order { String name; Expr expr; int index=-1; boolean desc=false; }
    static class ResultRow { List<String> labels=new ArrayList<>(), values=new ArrayList<>(); void add(String l,String v){labels.add(l);values.add(v);} int indexOfLabel(String l){ for(int i=0;i<labels.size();i++) if(canonLabel(labels.get(i)).equals(l)) return i; return -1; } }

    static class Parser {
        List<Tok> t; int p=0;
        Parser(String s){t=lex(s);}
        static Query parse(String s){ return new Parser(s).query(); }
        Query query() {
            if (peek("select")) p++;
            Query q=new Query();
            int from=findClause("from",0), where=findClause("where",0), group=findGroup(), order=findOrder(), limit=findClause("limit",0), offset=findClause("offset",0), into=findClause("into",0);
            int end=t.size(); for(int x: new int[]{from,where,group,order,limit,offset,into}) if(x>=0) end=Math.min(end,x);
            q.columns=parseExprList(0,end);
            if(q.columns.isEmpty()) q.columns.add(new Field("path"));
            if(from>=0){ int fe=nextClause(from+1); q.roots=parseRoots(from+1,fe); } else q.roots.add(new RootSpec());
            if(where>=0) q.where=sub(where+1,nextClause(where+1)).condition();
            if(group>=0) q.groupBy=parseExprList(group+2,nextClause(group+2));
            if(order>=0) q.orderBy=parseOrders(order+2,nextClause(order+2));
            if(limit>=0) q.limit=(int)parseNumber(tok(limit+1));
            if(offset>=0) q.offset=(int)parseNumber(tok(offset+1));
            if(into>=0) q.format=tok(into+1).toLowerCase(Locale.ROOT);
            return q;
        }
        Parser sub(int s,int e){ Parser x=new Parser(""); x.t=new ArrayList<>(t.subList(s,e)); return x; }
        int nextClause(int s){ int n=t.size(); for(int x:new int[]{findClause("where",s),findGroup(s),findOrder(s),findClause("limit",s),findClause("offset",s),findClause("into",s)}) if(x>=0)n=Math.min(n,x); return n; }
        int findClause(String k,int s){ for(int i=s;i<t.size();i++) if(t.get(i).depth==0&&t.get(i).text.equalsIgnoreCase(k)) return i; return -1; }
        int findGroup(){return findGroup(0);} int findGroup(int s){ for(int i=s;i+1<t.size();i++) if(t.get(i).depth==0&&peekAt(i,"group")&&peekAt(i+1,"by")) return i; return -1; }
        int findOrder(){return findOrder(0);} int findOrder(int s){ for(int i=s;i+1<t.size();i++) if(t.get(i).depth==0&&peekAt(i,"order")&&peekAt(i+1,"by")) return i; return -1; }
        List<Expr> parseExprList(int s,int e){ List<Expr> res=new ArrayList<>(); int last=s; for(int i=s;i<=e;i++) if(i==e || (t.get(i).text.equals(",")&&t.get(i).depth==0)){ if(last<i) res.add(sub(last,i).expr()); last=i+1; } return res; }
        List<RootSpec> parseRoots(int s,int e){ List<RootSpec> list=new ArrayList<>(); int last=s; for(int i=s;i<=e;i++) if(i==e || (t.get(i).text.equals(",")&&t.get(i).depth==0)){ if(last<i) list.add(root(last,i)); last=i+1; } if(list.isEmpty())list.add(new RootSpec()); return list; }
        RootSpec root(int s,int e){ RootSpec r=new RootSpec(); if(s<e) r.path=strip(tok(s)); for(int i=s+1;i<e;i++){ String x=tok(i).toLowerCase(Locale.ROOT); if((x.equals("maxdepth")||x.equals("depth"))&&i+1<e)r.maxdepth=(int)parseNumber(tok(++i)); else if(x.equals("mindepth")&&i+1<e)r.mindepth=(int)parseNumber(tok(++i)); else if(x.equals("symlinks")||x.equals("sym"))r.followLinks=true; else if(x.equals("dfs"))r.dfs=true; else if(x.equals("as")&&i+1<e)i++; } return r; }
        List<Order> parseOrders(int s,int e){ List<Order> os=new ArrayList<>(); int last=s; for(int i=s;i<=e;i++) if(i==e || (t.get(i).text.equals(",")&&t.get(i).depth==0)){ if(last<i){ Order o=new Order(); int end=i; if(end>last && (tok(end-1).equalsIgnoreCase("desc")||tok(end-1).equalsIgnoreCase("asc"))){o.desc=tok(end-1).equalsIgnoreCase("desc"); end--;} String nm=join(last,end); if(nm.matches("\\d+"))o.index=Integer.parseInt(nm)-1; else { o.name=nm; o.expr=sub(last,end).expr(); } os.add(o);} last=i+1;} return os; }
        Cond condition(){ return or(); }
        Cond or(){ Cond c=and(); while(peek("or")){p++; c=new LogicCond(c,"or",and());} return c; }
        Cond and(){ Cond c=not(); while(peek("and")){p++; c=new LogicCond(c,"and",not());} return c; }
        Cond not(){ if(peek("not")){p++; return new NotCond(not());} return cmp(); }
        Cond cmp(){
            if(accept("(")){ Cond c=condition(); accept(")"); return c; }
            Expr a=expr();
            if(p>=t.size()) return new ExprCond(a);
            String op=tok(p).toLowerCase(Locale.ROOT);
            if(op.equals("not") && p+1<t.size() && tok(p+1).equalsIgnoreCase("in")){p+=2; CmpCond c=new CmpCond(a,"notin",null); c.list=parseList(); return c;}
            Set<String> ops=Set.of("=","==","eq","===","eeq","!=","<>","ne","!==","ene",">","gt",">=","gte","ge","<","lt","<=","lte","le","=~","~=","regexp","rx","!=~","!~=","notrx","like","notlike","between","in");
            if(!ops.contains(op)) return new ExprCond(a);
            p++;
            if(op.equals("between")){ CmpCond c=new CmpCond(a,op,expr()); if(peek("and"))p++; c.c=expr(); return c; }
            if(op.equals("in")){ CmpCond c=new CmpCond(a,op,null); c.list=parseList(); return c; }
            return new CmpCond(a,op,expr());
        }
        List<Expr> parseList(){ List<Expr> l=new ArrayList<>(); if(accept("(")){ int start=p, d=0; for(;p<t.size();p++){ String x=tok(p); if(x.equals("("))d++; if(x.equals(")")){ if(d==0)break; d--; } if(x.equals(",")&&d==0){ l.add(sub(start,p).expr()); start=p+1; } } if(start<p)l.add(sub(start,p).expr()); accept(")"); } else l.add(expr()); return l; }
        Expr expr(){ return add(); }
        Expr add(){ Expr e=mul(); while(peek("+")||peek("-")||peek("plus")||peek("minus")){String o=tok(p++); e=new Binary(e,o.equals("plus")?"+":o.equals("minus")?"-":o,mul());} return e; }
        Expr mul(){ Expr e=primary(); while(peek("*")||peek("/")||peek("%")||peek("mul")||peek("div")||peek("mod")){String o=tok(p++); e=new Binary(e,o.equals("mul")?"*":o.equals("div")?"/":o.equals("mod")?"%":o,primary());} return e; }
        Expr primary(){
            if(accept("(")){ Expr e=expr(); accept(")"); return e; }
            if(p>=t.size()) return new Lit("");
            String x=tok(p++);
            if((x.startsWith("'")&&x.endsWith("'"))||(x.startsWith("\"")&&x.endsWith("\""))||(x.startsWith("`")&&x.endsWith("`"))) return new Lit(strip(x));
            if(p<t.size() && tok(p).equals("(")){ p++; List<Expr> args=new ArrayList<>(); int st=p,d=0; for(;p<t.size();p++){ if(tok(p).equals("("))d++; else if(tok(p).equals(")")){ if(d==0)break; d--; } else if(tok(p).equals(",")&&d==0){ if(st<p)args.add(sub(st,p).expr()); st=p+1; } } if(st<p)args.add(sub(st,p).expr()); accept(")"); return new Func(x,args); }
            if(x.matches("-?\\d+(\\.\\d+)?[a-zA-Z]*")) return new Num(x);
            return new Field(x);
        }
        boolean accept(String s){ if(peek(s)){p++;return true;} return false; } boolean peek(String s){ return p<t.size()&&tok(p).equalsIgnoreCase(s); } boolean peekAt(int i,String s){return tok(i).equalsIgnoreCase(s);}
        String tok(int i){return t.get(i).text;} String join(int s,int e){ StringBuilder sb=new StringBuilder(); for(int i=s;i<e;i++){ if(i>s)sb.append(' '); sb.append(tok(i)); } return sb.toString(); }
    }

    static class Tok { String text; int depth; Tok(String t,int d){text=t;depth=d;} }
    static List<Tok> lex(String s) {
        List<Tok> r=new ArrayList<>(); int d=0;
        for(int i=0;i<s.length();) {
            char c=s.charAt(i); if(Character.isWhitespace(c)){i++;continue;}
            if(c=='\''||c=='"'||c=='`'){ char q=c; StringBuilder sb=new StringBuilder().append(q); i++; while(i<s.length()&&s.charAt(i)!=q){ if(s.charAt(i)=='\\'&&i+1<s.length()) i++; sb.append(s.charAt(i++)); } if(i<s.length()) {sb.append(q); i++;} r.add(new Tok(sb.toString(),d)); continue; }
            if(c=='*' && (i+1==s.length() || Character.isWhitespace(s.charAt(i+1)) || ",)}".indexOf(s.charAt(i+1))>=0)){ r.add(new Tok("*",d)); i++; continue; }
            if("(),{}+-/%".indexOf(c)>=0){ String x=(c=='{'?"(":c=='}'?")":Character.toString(c)); if(x.equals(")")) d=Math.max(0,d-1); r.add(new Tok(x,d)); if(x.equals("(")) d++; i++; continue; }
            String two=i+1<s.length()?s.substring(i,i+2):"", three=i+2<s.length()?s.substring(i,i+3):"";
            if(Set.of("===","!==","!=~","!~=").contains(three)){r.add(new Tok(three,d));i+=3;continue;}
            if(Set.of("==","!=","<>",">=","<=","=~","~=").contains(two)){r.add(new Tok(two,d));i+=2;continue;}
            if(c=='='||c=='<'||c=='>'){r.add(new Tok(Character.toString(c),d));i++;continue;}
            int j=i; while(j<s.length()&&!Character.isWhitespace(s.charAt(j))&&"(),{}+-/%=<>".indexOf(s.charAt(j))<0)j++;
            r.add(new Tok(s.substring(i,j),d)); i=j;
        }
        return r;
    }

    static String label(Expr e){ return pretty(e.source()); }
    static String pretty(String s) {
        if ((s.startsWith("'")&&s.endsWith("'"))||(s.startsWith("\"")&&s.endsWith("\""))) return strip(s);
        String l=s.toLowerCase(Locale.ROOT);
        Map<String,String> m=Map.of("name","Name","filename","Filename","fname","Filename","ext","Extension","extension","Extension","path","Path","abspath","AbsPath","dir","Directory","directory","Directory","size","Size");
        if(m.containsKey(l)) return m.get(l);
        Matcher mt=Pattern.compile("([A-Za-z_][A-Za-z_0-9]*)\\((.*)\\)").matcher(s);
        if(mt.matches()) return capFunc(mt.group(1))+"("+pretty(mt.group(2))+")";
        return s;
    }
    static String capFunc(String f){ return Arrays.stream(f.split("_")).map(x->x.isEmpty()?x:x.substring(0,1).toUpperCase()+x.substring(1).toLowerCase()).collect(Collectors.joining("_")); }
    static String canonLabel(String s){ return s.toLowerCase(Locale.ROOT).replace("extension","ext").replace("directory","dir"); }
    static String strip(String s){ if(s.length()>=2){char a=s.charAt(0),b=s.charAt(s.length()-1); if((a=='\''&&b=='\'')||(a=='"'&&b=='"')||(a=='`'&&b=='`')) return s.substring(1,s.length()-1);} return s; }
    static String str(Object o){ return o==null?"":String.valueOf(o); }
    static String bool(boolean b){ return b?"true":"false"; }
    static boolean truth(Object o){ String s=str(o); return s.equalsIgnoreCase("true")||s.equals("1")||(!s.isEmpty()&&!s.equals("0")&&!s.equalsIgnoreCase("false")); }
    static String extension(String n){ int i=n.lastIndexOf('.'); return i>0?n.substring(i+1).toLowerCase(Locale.ROOT):""; }
    static String time(FileTime ft){ return LocalDateTime.ofInstant(ft.toInstant(), ZoneId.systemDefault()).format(DTF); }
    static Double numOrNull(String s){ try{return parseNumber(s);}catch(Exception e){return null;} }
    static double parseNumber(String s){ s=strip(s.trim()).toLowerCase(Locale.ROOT); Matcher m=Pattern.compile("(-?\\d+(?:\\.\\d+)?)([a-z]+)?").matcher(s); if(!m.matches()) return Double.parseDouble(s); double v=Double.parseDouble(m.group(1)); String u=m.group(2); if(u==null)return v; switch(u){case"k":case"kib":return v*1024;case"kb":return v*1000;case"m":case"mib":return v*1024*1024;case"mb":return v*1000*1000;case"g":case"gib":return v*1024*1024*1024;case"gb":return v*1_000_000_000d;default:return v;} }
    static String numstr(double d){ return Math.rint(d)==d?Long.toString((long)d):Double.toString(d); }
    static boolean eq(String a,String b,boolean exact){ if(exact) return a.equals(b); if(b.contains("*")||b.contains("?")) return Pattern.compile(globRegex(b)).matcher(a).matches(); return a.equals(b); }
    static boolean like(String a,String p){ StringBuilder sb=new StringBuilder("^"); for(char c:p.toCharArray()){ if(c=='%')sb.append(".*"); else if(c=='_')sb.append('.'); else sb.append(Pattern.quote(Character.toString(c))); } return Pattern.compile(sb+"$").matcher(a).matches(); }
    static String globRegex(String g){ StringBuilder sb=new StringBuilder("^"); for(char c:g.toCharArray()){ if(c=='*')sb.append(".*"); else if(c=='?')sb.append('.'); else sb.append(Pattern.quote(Character.toString(c))); } return sb.append("$").toString(); }
    static String formatSize(long s){ if(s<1024)return s+" B"; String[] u={"KiB","MiB","GiB","TiB"}; double v=s; int i=-1; do{v/=1024;i++;}while(v>=1024&&i<u.length-1); return String.format(Locale.ROOT, v>=10?"%.1f %s":"%.2f %s", v,u[i]); }
    static String in(String ext,String csv){ return bool(Arrays.asList(csv.split(",")).contains(ext)); }
    static String mime(String ext){ Map<String,String> m=new HashMap<>(); m.put("txt","text/plain");m.put("md","text/markdown");m.put("html","text/html");m.put("json","application/json");m.put("pdf","application/pdf");m.put("png","image/png");m.put("jpg","image/jpeg");m.put("jpeg","image/jpeg");m.put("gif","image/gif");m.put("svg","image/svg+xml"); return m.getOrDefault(ext, ext.isEmpty()?"":"application/octet-stream"); }
    static String datePart(String s,String p){ try{ LocalDateTime d=LocalDateTime.parse(s, DTF); return p.equals("y")?""+d.getYear():p.equals("m")?""+d.getMonthValue():""+d.getDayOfMonth(); }catch(Exception e){return "";} }
    static boolean knownField(String f) {
        String k=f.toLowerCase(Locale.ROOT);
        return Set.of("*","name","filename","fname","ext","extension","path","abspath","dir","directory","dirname","absdir","size","fsize","hsize",
                "created","accessed","modified","atime","mtime","ctime","uid","gid","user","group","is_dir","is_file","is_symlink","is_hidden","is_empty",
                "is_pipe","is_fifo","is_char","is_character","is_block","is_socket","mode","user_read","user_write","user_exec","user_all","user_rwx",
                "group_read","group_write","group_exec","group_all","group_rwx","other_read","other_write","other_exec","other_all","other_rwx",
                "suid","is_suid","sgid","is_sgid","sticky","is_sticky","device","rdev","inode","hardlinks","blocks","line_count","is_binary","is_text",
                "mime","is_archive","is_audio","is_book","is_doc","is_font","is_image","is_source","is_video","sha1","sha256","sha2_256","sha512","sha2_512").contains(k);
    }
    static class ParseError extends RuntimeException { ParseError(String s){super(s);} }
}
