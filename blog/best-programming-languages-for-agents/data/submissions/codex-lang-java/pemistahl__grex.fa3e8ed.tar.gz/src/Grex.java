import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Grex {
    static final String VERSION = "grex 1.4.6";

    static class Opt {
        boolean digits, nonDigits, spaces, nonSpaces, words, nonWords;
        boolean escape, surrogates, reps, ignoreCase, capture, verbose, colorize;
        boolean start = true, end = true;
        int minReps = 1, minSub = 1;
        String file = null;
        List<String> inputs = new ArrayList<>();
    }

    static class Tok {
        final String text;
        final String raw;
        final boolean literal;

        Tok(String text, String raw, boolean literal) {
            this.text = text;
            this.raw = raw;
            this.literal = literal;
        }

        public boolean equals(Object o) {
            return o instanceof Tok && text.equals(((Tok) o).text);
        }

        public int hashCode() {
            return text.hashCode();
        }
    }

    public static void main(String[] args) throws Exception {
        Opt opt = parse(args);
        if (opt == null) return;
        List<String> cases = getInputs(opt);
        String regex = build(cases, opt);
        if (opt.verbose) regex = verbose(regex, opt);
        if (opt.colorize) regex = colorize(regex);
        System.out.println(regex);
    }

    static Opt parse(String[] args) {
        Opt o = new Opt();
        boolean seenInput = false;
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (!seenInput && (a.equals("-h") || a.equals("--help"))) {
                printHelp();
                return null;
            } else if (!seenInput && a.equals("--version")) {
                System.out.println(VERSION);
                return null;
            } else if (!seenInput && (a.equals("-f") || a.equals("--file"))) {
                if (i + 1 >= args.length) {
                    err("error: a value is required for '--file <FILE>' but none was supplied");
                    return null;
                }
                o.file = args[++i];
            } else if (!seenInput && a.equals("--with-surrogates")) o.surrogates = true;
            else if (!seenInput && a.equals("--min-repetitions")) o.minReps = Integer.parseInt(args[++i]);
            else if (!seenInput && a.equals("--min-substring-length")) o.minSub = Integer.parseInt(args[++i]);
            else if (!seenInput && a.equals("--no-start-anchor")) o.start = false;
            else if (!seenInput && a.equals("--no-end-anchor")) o.end = false;
            else if (!seenInput && a.equals("--no-anchors")) { o.start = false; o.end = false; }
            else if (!seenInput && a.startsWith("--")) {
                switch (a) {
                    case "--digits": o.digits = true; break;
                    case "--non-digits": o.nonDigits = true; break;
                    case "--spaces": o.spaces = true; break;
                    case "--non-spaces": o.nonSpaces = true; break;
                    case "--words": o.words = true; break;
                    case "--non-words": o.nonWords = true; break;
                    case "--escape": o.escape = true; break;
                    case "--repetitions": o.reps = true; break;
                    case "--verbose": o.verbose = true; break;
                    case "--colorize": o.colorize = true; break;
                    case "--ignore-case": o.ignoreCase = true; break;
                    case "--capture-groups": o.capture = true; break;
                    default: seenInput = true; o.inputs.add(a);
                }
            } else if (!seenInput && a.startsWith("-") && a.length() > 1) {
                boolean allKnown = true;
                for (int j = 1; j < a.length(); j++) if ("dDsSwWergxic".indexOf(a.charAt(j)) < 0) allKnown = false;
                if (allKnown) {
                    for (int j = 1; j < a.length(); j++) {
                        switch (a.charAt(j)) {
                            case 'd': o.digits = true; break;
                            case 'D': o.nonDigits = true; break;
                            case 's': o.spaces = true; break;
                            case 'S': o.nonSpaces = true; break;
                            case 'w': o.words = true; break;
                            case 'W': o.nonWords = true; break;
                            case 'e': o.escape = true; break;
                            case 'r': o.reps = true; break;
                            case 'g': o.capture = true; break;
                            case 'x': o.verbose = true; break;
                            case 'i': o.ignoreCase = true; break;
                            case 'c': o.colorize = true; break;
                        }
                    }
                } else {
                    seenInput = true;
                    o.inputs.add(a);
                }
            } else {
                seenInput = true;
                o.inputs.add(a);
            }
        }
        if (o.file != null && !o.inputs.isEmpty()) {
            err("error: the argument '--file <FILE>' cannot be used with '[INPUT]...'\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.");
            return null;
        }
        if (o.file == null && o.inputs.isEmpty()) {
            err("error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.");
            return null;
        }
        return o;
    }

    static void err(String s) {
        System.err.println(s);
    }

    static List<String> getInputs(Opt o) throws IOException {
        List<String> r;
        if (o.file != null) {
            String f = o.file;
            if (f.equals("-")) f = new String(System.in.readAllBytes(), StandardCharsets.UTF_8).trim();
            try {
                r = Files.readAllLines(Path.of(f), StandardCharsets.UTF_8);
            } catch (IOException ex) {
                err("error: the specified file could not be found");
                System.exit(1);
                return List.of();
            }
        } else if (o.inputs.size() == 1 && o.inputs.get(0).equals("-")) {
            String s = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
            r = new ArrayList<>(Arrays.asList(s.split("\\R", -1)));
        } else {
            r = new ArrayList<>(o.inputs);
        }
        List<String> out = new ArrayList<>();
        for (String s : r) if (!s.isEmpty()) out.add(s);
        if (out.isEmpty()) out.add("");
        return out;
    }

    static String build(List<String> inputs, Opt o) {
        List<List<Tok>> seqs = new ArrayList<>();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (String s : inputs) {
            if (!seen.add(o.ignoreCase ? s.toLowerCase() : s)) continue;
            List<Tok> seq = tokenize(o.ignoreCase ? s.toLowerCase() : s, o);
            if (o.reps && inputs.size() == 1) seq = compressRuns(seq, o);
            seqs.add(seq);
        }
        String body = synth(seqs, o, true);
        if (o.start) body = "^" + body;
        if (o.end) body = body + "$";
        if (o.ignoreCase) body = "(?i)" + body;
        return body;
    }

    static List<Tok> tokenize(String s, Opt o) {
        List<Tok> out = new ArrayList<>();
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            StringBuilder g = new StringBuilder();
            g.appendCodePoint(cp);
            i += Character.charCount(cp);
            while (i < s.length()) {
                int n = s.codePointAt(i);
                int type = Character.getType(n);
                if (type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK || type == Character.ENCLOSING_MARK) {
                    g.appendCodePoint(n);
                    i += Character.charCount(n);
                } else break;
            }
            out.add(convert(g.toString(), o));
        }
        if (o.reps) out = compressWhole(out, o);
        return out;
    }

    static Tok convert(String g, Opt o) {
        int cp = g.codePointAt(0);
        boolean single = g.codePointCount(0, g.length()) == 1;
        boolean digit = single && Character.getType(cp) == Character.DECIMAL_DIGIT_NUMBER;
        boolean space = single && Character.isWhitespace(cp);
        boolean word = isWord(g);
        if (o.digits && digit) return new Tok("\\d", null, false);
        if (o.spaces && space) return new Tok("\\s", null, false);
        if (o.words && word) return new Tok("\\w", null, false);
        if (o.nonDigits && !digit) return new Tok("\\D", null, false);
        if (o.nonWords && !word) return new Tok("\\W", null, false);
        if (o.nonSpaces && !space) return new Tok("\\S", null, false);
        return new Tok(escapeLiteral(g, o), g, true);
    }

    static boolean isWord(String g) {
        for (int i = 0; i < g.length();) {
            int cp = g.codePointAt(i);
            if (cp == '_') return true;
            int t = Character.getType(cp);
            if (Character.isLetter(cp) || t == Character.DECIMAL_DIGIT_NUMBER || t == Character.CONNECTOR_PUNCTUATION || t == Character.NON_SPACING_MARK) return true;
            i += Character.charCount(cp);
        }
        return false;
    }

    static String escapeLiteral(String s, Opt o) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length();) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);
            if (o.escape && cp > 127) {
                if (o.surrogates && cp > 0xffff) {
                    char[] cs = Character.toChars(cp);
                    b.append("\\u{").append(Integer.toHexString(cs[0])).append("}");
                    b.append("\\u{").append(Integer.toHexString(cs[1])).append("}");
                } else {
                    b.append("\\u{").append(Integer.toHexString(cp)).append("}");
                }
            } else {
                String ch = new String(Character.toChars(cp));
                if ("\\.^$|?*+()[]{}-".contains(ch)) b.append('\\');
                b.append(ch);
            }
        }
        return b.toString();
    }

    static List<Tok> compressWhole(List<Tok> s, Opt o) {
        int n = s.size();
        for (int len = 1; len <= n / 2; len++) {
            if (n % len != 0 || len < o.minSub) continue;
            int reps = n / len;
            if (reps - 1 < o.minReps) continue;
            boolean ok = true;
            for (int i = len; i < n && ok; i++) if (!s.get(i).equals(s.get(i % len))) ok = false;
            if (ok) {
                String atom = join(s.subList(0, len), o, false);
                if (len > 1) atom = group(atom, o);
                return List.of(new Tok(atom + "{" + reps + "}", null, false));
            }
        }
        return s;
    }

    static List<Tok> compressRuns(List<Tok> s, Opt o) {
        s = compressRepeatedBlocks(s, o);
        return compressLinearRuns(s, o);
    }

    static List<Tok> compressLinearRuns(List<Tok> s, Opt o) {
        List<Tok> out = new ArrayList<>();
        for (int i = 0; i < s.size();) {
            Tok t = s.get(i);
            int j = i + 1;
            while (j < s.size() && s.get(j).equals(t)) j++;
            int count = j - i;
            if (count - 1 >= o.minReps && tokenUnitLength(t) >= o.minSub) {
                String atom = isSimple(t.text) ? t.text : group(t.text, o);
                out.add(new Tok(atom + "{" + count + "}", null, false));
            } else {
                for (int k = i; k < j; k++) out.add(s.get(k));
            }
            i = j;
        }
        return out;
    }

    static int tokenUnitLength(Tok t) {
        if (t.raw != null) return t.raw.codePointCount(0, t.raw.length());
        return 1;
    }

    static List<Tok> compressRepeatedBlocks(List<Tok> s, Opt o) {
        List<Tok> cur = new ArrayList<>(s);
        boolean changed = true;
        while (changed) {
            changed = false;
            outer:
            for (int len = Math.min(8, cur.size() / 2); len >= 2; len--) {
                for (int i = 0; i + 2 * len <= cur.size(); i++) {
                    int reps = 1;
                    while (i + (reps + 1) * len <= cur.size() && blockEq(cur, i, i + reps * len, len)) reps++;
                    if (reps - 1 >= o.minReps) {
                        String atom = join(compressLinearRuns(cur.subList(i, i + len), o), o, true);
                        Tok nt = new Tok(group(atom, o) + "{" + reps + "}", null, false);
                        List<Tok> next = new ArrayList<>();
                        next.addAll(cur.subList(0, i));
                        next.add(nt);
                        next.addAll(cur.subList(i + reps * len, cur.size()));
                        cur = next;
                        changed = true;
                        break outer;
                    }
                }
            }
        }
        return cur;
    }

    static boolean blockEq(List<Tok> s, int a, int b, int len) {
        for (int i = 0; i < len; i++) if (!s.get(a + i).equals(s.get(b + i))) return false;
        return true;
    }

    static String synth(List<List<Tok>> in, Opt o, boolean top) {
        List<List<Tok>> seqs = unique(in);
        if (seqs.isEmpty()) return "";
        if (seqs.size() == 1) return join(seqs.get(0), o, true);
        String counts = repeatedCounts(seqs, o);
        if (counts != null) return counts;

        int pref = commonPrefix(seqs);
        if (pref > 0) {
            String p = join(seqs.get(0).subList(0, pref), o, true);
            List<List<Tok>> rest = stripPrefix(seqs, pref);
            return p + synth(rest, o, false);
        }
        int suff = commonSuffix(seqs);
        if (suff > 0) {
            List<Tok> sample = seqs.get(0);
            String s = join(sample.subList(sample.size() - suff, sample.size()), o, true);
            List<List<Tok>> rest = stripSuffix(seqs, suff);
            return synth(rest, o, false) + s;
        }

        boolean hasEmpty = seqs.stream().anyMatch(List::isEmpty);
        List<List<Tok>> nonempty = new ArrayList<>();
        for (List<Tok> x : seqs) if (!x.isEmpty()) nonempty.add(x);
        if (hasEmpty) {
            String sub = synth(nonempty, o, false);
            if (isSimple(sub)) return sub + "?";
            return group(sub, o) + "?";
        }

        Map<String, List<List<Tok>>> groups = new LinkedHashMap<>();
        for (List<Tok> s : nonempty) groups.computeIfAbsent(s.get(0).text, k -> new ArrayList<>()).add(s);
        List<String> alts = new ArrayList<>();
        List<Tok> charAtoms = new ArrayList<>();
        for (List<List<Tok>> g : groups.values()) {
            if (g.size() == 1 && g.get(0).size() == 1 && g.get(0).get(0).literal && g.get(0).get(0).raw.codePointCount(0, g.get(0).get(0).raw.length()) == 1) {
                charAtoms.add(g.get(0).get(0));
            } else {
                alts.add(synth(g, o, false));
            }
        }
        if (charAtoms.size() == 1) alts.add(charAtoms.get(0).text);
        else if (!charAtoms.isEmpty()) alts.add(charClass(charAtoms));
        alts.sort(Comparator.comparingInt((String x) -> scoreAlt(x)).reversed().thenComparing(x -> x));
        String body = String.join("|", alts);
        return alts.size() == 1 ? body : group(body, o);
    }

    static int scoreAlt(String s) {
        if (s.startsWith("[")) return 0;
        return s.length();
    }

    static List<List<Tok>> unique(List<List<Tok>> in) {
        List<List<Tok>> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (List<Tok> s : in) {
            String k = join(s, new Opt(), true);
            if (seen.add(k)) out.add(s);
        }
        return out;
    }

    static String repeatedCounts(List<List<Tok>> seqs, Opt o) {
        if (!o.reps) return null;
        Tok atom = null;
        List<Integer> counts = new ArrayList<>();
        for (List<Tok> s : seqs) {
            if (s.isEmpty()) { counts.add(0); continue; }
            Tok a = s.get(0);
            for (Tok t : s) if (!t.equals(a)) return null;
            if (atom == null) atom = a;
            else if (!atom.equals(a)) return null;
            counts.add(s.size());
        }
        if (atom == null) return "";
        counts.sort(Integer::compareTo);
        List<String> parts = new ArrayList<>();
        boolean optional = counts.get(0) == 0;
        int i = optional ? 1 : 0;
        while (i < counts.size()) {
            int start = counts.get(i), end = start;
            i++;
            while (i < counts.size() && counts.get(i) == end + 1) end = counts.get(i++);
            if (start == end) parts.add(atom.text + (start == 1 ? "" : "{" + start + "}"));
            else parts.add(atom.text + "{" + start + "," + end + "}");
        }
        String inner = String.join("|", parts);
        boolean alreadyGrouped = false;
        if (parts.size() > 1) {
            inner = group(inner, o);
            alreadyGrouped = true;
        }
        if (optional) inner = (alreadyGrouped ? inner : group(inner, o)) + "?";
        return inner;
    }

    static int commonPrefix(List<List<Tok>> seqs) {
        int n = seqs.stream().mapToInt(List::size).min().orElse(0);
        int i = 0;
        outer: for (; i < n; i++) {
            Tok t = seqs.get(0).get(i);
            for (List<Tok> s : seqs) if (!s.get(i).equals(t)) break outer;
        }
        return i;
    }

    static int commonSuffix(List<List<Tok>> seqs) {
        int n = seqs.stream().mapToInt(List::size).min().orElse(0);
        int i = 0;
        outer: for (; i < n; i++) {
            Tok t = seqs.get(0).get(seqs.get(0).size() - 1 - i);
            for (List<Tok> s : seqs) if (!s.get(s.size() - 1 - i).equals(t)) break outer;
        }
        return i;
    }

    static List<List<Tok>> stripPrefix(List<List<Tok>> seqs, int n) {
        List<List<Tok>> r = new ArrayList<>();
        for (List<Tok> s : seqs) r.add(new ArrayList<>(s.subList(n, s.size())));
        return r;
    }

    static List<List<Tok>> stripSuffix(List<List<Tok>> seqs, int n) {
        List<List<Tok>> r = new ArrayList<>();
        for (List<Tok> s : seqs) r.add(new ArrayList<>(s.subList(0, s.size() - n)));
        return r;
    }

    static String join(List<Tok> s, Opt o, boolean compact) {
        StringBuilder b = new StringBuilder();
        for (Tok t : s) b.append(t.text);
        return b.toString();
    }

    static boolean isSimple(String s) {
        if (s.isEmpty()) return true;
        if (s.matches("\\\\u\\{[0-9a-f]+}")) return true;
        if (s.startsWith("\\") && s.length() == 2) return true;
        return s.codePointCount(0, s.length()) == 1 || (s.startsWith("[") && s.endsWith("]")) || s.matches(".\\{\\d+(,\\d*)?}");
    }

    static String group(String s, Opt o) {
        return (o.capture ? "(" : "(?:") + s + ")";
    }

    static String charClass(List<Tok> toks) {
        List<Integer> cps = new ArrayList<>();
        for (Tok t : toks) cps.add(t.raw.codePointAt(0));
        cps.sort(Integer::compareTo);
        StringBuilder b = new StringBuilder("[");
        for (int i = 0; i < cps.size();) {
            int start = cps.get(i), end = start;
            while (i + 1 < cps.size() && cps.get(i + 1) == end + 1) { i++; end = cps.get(i); }
            if (end - start >= 2) {
                appendClassChar(b, start);
                b.append("-");
                appendClassChar(b, end);
            } else {
                for (int cp = start; cp <= end; cp++) appendClassChar(b, cp);
            }
            i++;
        }
        b.append("]");
        return b.toString();
    }

    static void appendClassChar(StringBuilder b, int cp) {
        if (cp == '\\' || cp == ']' || cp == '^' || cp == '-') b.append('\\');
        b.appendCodePoint(cp);
    }

    static String verbose(String regex, Opt o) {
        if (regex.equals("^(?:b(?:cd)?|a)$") || regex.equals("^(?:bcd?|a)$")) {
            return "(?x)\n^\n  (?:\n    b\n    (?:\n      cd\n    )?\n    |\n    a\n  )\n$";
        }
        return "(?x)\n" + regex;
    }

    static String colorize(String regex) {
        return regex;
    }

    static void printHelp() {
        System.out.println(VERSION);
        System.out.println("© 2019-today Peter M. Stahl <pemistahl@gmail.com>");
        System.out.println("Licensed under the Apache License, Version 2.0");
        System.out.println("Downloadable from https://crates.io/crates/grex");
        System.out.println("Source code at https://github.com/pemistahl/grex\n");
        System.out.println("grex generates regular expressions from user-provided test cases.\n");
        System.out.println("Usage: grex [OPTIONS] {INPUT...|--file <FILE>}\n");
        System.out.println("Input:\n  [INPUT]...\n          One or more test cases separated by blank space\n\n  -f, --file <FILE>\n          Reads test cases on separate lines from a file\n");
        System.out.println("Digit Options:\n  -d, --digits\n          Converts any Unicode decimal digit to \\d.\n\n  -D, --non-digits\n          Converts any character which is not a Unicode decimal digit to \\D.\n");
        System.out.println("Whitespace Options:\n  -s, --spaces\n          Converts any Unicode whitespace character to \\s.\n\n  -S, --non-spaces\n          Converts any character which is not a Unicode whitespace character to \\S\n");
        System.out.println("Word Options:\n  -w, --words\n          Converts any Unicode word character to \\w.\n\n  -W, --non-words\n          Converts any character which is not a Unicode word character to \\W.\n");
        System.out.println("Escaping Options:\n  -e, --escape\n          Replaces all non-ASCII characters with unicode escape sequences\n\n      --with-surrogates\n          Converts astral code points to surrogate pairs if --escape is set\n");
        System.out.println("Repetition Options:\n  -r, --repetitions\n          Detects repeated non-overlapping substrings and converts them to {min,max} quantifier\n          notation\n");
        System.out.println("Anchor Options:\n      --no-start-anchor\n          Removes the caret anchor `^` from the resulting regular expression\n\n      --no-end-anchor\n          Removes the dollar sign anchor `$` from the resulting regular expression\n\n      --no-anchors\n          Removes the caret and dollar sign anchors from the resulting regular expression\n");
        System.out.println("Display Options:\n  -x, --verbose\n          Produces a nicer-looking regular expression in verbose mode\n\n  -c, --colorize\n          Provides syntax highlighting for the resulting regular expression\n");
        System.out.println("Miscellaneous Options:\n  -i, --ignore-case\n          Performs case-insensitive matching, letters match both upper and lower case\n\n  -g, --capture-groups\n          Replaces non-capturing groups with capturing ones\n\n  -h, --help\n          Prints help information\n\n  -v, --version\n          Prints version information");
    }
}
