import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

public class Duc {
    static final String VERSION = "1.5.0-rc1";
    static class Node implements Serializable {
        String name, path; boolean dir; long apparent, actual; int count; ArrayList<Node> children = new ArrayList<>();
    }
    static class Db implements Serializable {
        long time; ArrayList<Node> roots = new ArrayList<>(); int files, dirs; int buckets = 48; long[] hist = new long[48]; ArrayList<Node> top = new ArrayList<>();
    }
    static class Opt { String db; boolean bytes, apparent, recursive, classify, directory, dirsOnly, nameSort, graph, ascii, fullPath, countMode, excludeFiles, dryRun, checkHard, hideNames, base10; String output="duc.png", format="png"; int levels=4, topn=0; long minSize=0; ArrayList<String> args=new ArrayList<>(), excludes=new ArrayList<>(); }
    static HashSet<Object> hardSeen = new HashSet<>();

    public static void main(String[] argv) {
        try { int rc = run(argv); if (rc != 0) System.exit(rc); }
        catch (Throwable t) { System.err.println(t.getMessage()==null?t.toString():t.getMessage()); System.exit(1); }
    }
    static int run(String[] argv) throws Exception {
        ArrayList<String> a = new ArrayList<>(Arrays.asList(argv));
        if (a.isEmpty() || a.contains("--help") || a.contains("-h")) {
            if (!a.isEmpty() && !a.get(0).startsWith("-") && !a.get(0).equals("help")) printSubHelp(a.get(0)); else printHelp(); return 0;
        }
        if (a.contains("--version")) { System.out.println("duc version: " + VERSION); System.out.println("options: cairo x11 ui sqlite3"); return 0; }
        String cmd = a.remove(0);
        if (cmd.equals("help")) { if (!a.isEmpty() && (a.get(0).equals("--all")||a.get(0).equals("-a"))) printAllHelp(); else if (!a.isEmpty()) printSubHelp(a.get(0)); else printHelp(); return 0; }
        Opt o = parse(a);
        switch(cmd) {
            case "index": return cmdIndex(o);
            case "info": return cmdInfo(o);
            case "ls": return cmdLs(o);
            case "json": return cmdJson(o);
            case "xml": return cmdXml(o);
            case "histogram": return cmdHistogram(o);
            case "topn": return cmdTopn(o);
            case "graph": return cmdGraph(o);
            case "cgi": return cmdCgi(o);
            case "ui": return cmdLs(o);
            case "gui": return cmdGraph(o);
            default: printHelp(); return 0;
        }
    }
    static Opt parse(ArrayList<String> a) {
        Opt o = new Opt(); o.db = System.getenv().getOrDefault("DUC_DATABASE", System.getProperty("user.home") + "/.duc.db");
        for (int i=0;i<a.size();i++) { String s=a.get(i); String val=null; int eq=s.indexOf('='); if (eq>0) { val=s.substring(eq+1); s=s.substring(0,eq); }
            switch(s) {
                case "-d": case "--database": o.db = val!=null?val:a.get(++i); break;
                case "-b": case "--bytes": o.bytes=true; break; case "-a": case "--apparent": o.apparent=true; break;
                case "-R": case "--recursive": o.recursive=true; break; case "-F": case "--classify": o.classify=true; break;
                case "-D": case "--directory": o.directory=true; break; case "--dirs-only": o.dirsOnly=true; break;
                case "-n": case "--name-sort": o.nameSort=true; break; case "-g": case "--graph": o.graph=true; break;
                case "--ascii": o.ascii=true; break; case "--full-path": o.fullPath=true; break; case "--count": o.countMode=true; break;
                case "-x": case "--exclude-files": case "--one-file-system": if (s.equals("-x")||s.equals("--exclude-files")) o.excludeFiles=true; break;
                case "--dry-run": o.dryRun=true; break; case "-H": case "--check-hard-links": o.checkHard=true; break; case "--hide-file-names": o.hideNames=true; break;
                case "-l": case "--levels": o.levels=Integer.parseInt(val!=null?val:a.get(++i)); break;
                case "-s": case "--min_size": case "--size": o.minSize=Long.parseLong(val!=null?val:a.get(++i).replaceAll("[^0-9]","")); break;
                case "-e": case "--exclude": o.excludes.add(val!=null?val:a.get(++i)); break;
                case "-T": case "--topn": o.topn=Integer.parseInt(val!=null?val:a.get(++i)); break;
                case "-t": case "--base10": o.base10=true; break;
                case "-p": case "--progress": case "-f": case "--format": o.format = val!=null?val:((i+1<a.size()&&!a.get(i+1).startsWith("-"))?a.get(++i):"png"); break;
                case "--force": case "--uncompressed": case "-c": case "--color": case "--no-color": case "--gradient": case "--dark": case "--list": case "--tooltip": break;
                case "-o": case "--output": o.output = val!=null?val:a.get(++i); break;
                case "-B": case "--buckets": case "-M": case "--topn-min": case "-U": case "--uid": case "-u": case "--username": case "--fs-exclude": case "--fs-include": case "--dpi": case "--fuzz": case "--palette": case "--ring-gap": case "--css-url": case "--header": case "--footer": if (val==null && i+1<a.size()) i++; break;
                default: if (!s.startsWith("-")) o.args.add(a.get(i)); break;
            }
        }
        return o;
    }
    static int cmdIndex(Opt o) throws Exception {
        if (o.args.isEmpty()) { System.err.println("Missing path"); return 1; }
        Db db = new Db(); db.time = System.currentTimeMillis(); hardSeen.clear();
        for (String p: o.args) { Node n = scan(Paths.get(p).toAbsolutePath().normalize(), o, true, db); if (n!=null) db.roots.add(n); }
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(o.db))) { out.writeObject(db); }
        return 0;
    }
    static Node scan(Path p, Opt o, boolean root, Db db) throws IOException {
        String nm = p.getFileName()==null?p.toString():p.getFileName().toString();
        for (String ex:o.excludes) if (match(ex,nm) || match(ex,p.toString())) return null;
        BasicFileAttributes at; try { at = Files.readAttributes(p, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); } catch(IOException e){ return null; }
        Node n = new Node(); n.path=p.toString(); n.name=root?p.toString():nm; n.dir=at.isDirectory(); n.apparent=n.dir?0:at.size(); n.actual=(n.dir && root)?0:actualSize(p, at); n.count = n.dir?(root?0:1):0;
        if (!n.dir && o.checkHard) { Object fk = at.fileKey(); if (fk!=null && hardSeen.contains(fk)) { n.apparent=0; n.actual=0; } else if (fk!=null) hardSeen.add(fk); }
        if (n.dir) { db.dirs++; try (DirectoryStream<Path> ds = Files.newDirectoryStream(p)) { for (Path c: ds) { Node ch=scan(c,o,false,db); if(ch!=null){ n.children.add(ch); n.apparent+=ch.apparent; n.actual+=ch.actual; n.count+= ch.dir?ch.count:1; } } } catch(IOException ignored){} sort(n.children,false); }
        else { db.files++; db.top.add(n); int b = bucket(n.apparent,false); if (b>=0 && b<db.hist.length) db.hist[b]++; if (o.hideNames) n.name="file"; }
        return n;
    }
    static boolean match(String pat,String text){ String r=Pattern.quote(pat).replace("*","\\E.*\\Q").replace("?","\\E.\\Q"); return text.matches(r); }
    static long actualSize(Path p, BasicFileAttributes at){ try { Object blocks=Files.getAttribute(p,"unix:blocks",LinkOption.NOFOLLOW_LINKS); if(blocks instanceof Number) return ((Number)blocks).longValue()*512; } catch(Exception ignored){} long s=at.size(); return s==0?0:((s+4095)/4096)*4096; }
    static int bucket(long s, boolean base10){ if(s<=0) return 0; double b=base10?10.0:2.0; return (int)Math.floor(Math.log(s)/Math.log(b)); }
    static Db readDb(String path) throws Exception { File f=new File(path); if(!f.exists()){ System.err.println("Error opening: "+path+" - Database not found"); throw new FileNotFoundException("Database not found"); } try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(f))){ return (Db)in.readObject(); } catch(Exception e){ System.err.println("Error opening: "+path+" - Database not recognized"); throw e; } }
    static Node find(Db db, String p){ if(p==null||p.isEmpty()) p=Paths.get("").toAbsolutePath().normalize().toString(); String q=Paths.get(p).toAbsolutePath().normalize().toString(); for(Node r:db.roots){ Node f=findIn(r,q); if(f!=null)return f; } return null; }
    static Node findIn(Node n,String q){ if(n.path.equals(q)) return n; for(Node c:n.children){ Node f=findIn(c,q); if(f!=null)return f; } return null; }
    static long val(Node n, Opt o){ return o.countMode?n.count:(o.apparent?n.apparent:n.actual); }
    static String size(long v, Opt o){ if(o.countMode||o.bytes) return Long.toString(v); String[] u={"B","K","M","G","T","P"}; double d=v; int i=0; while(d>=1024&&i<u.length-1){d/=1024;i++;} if(i==0) return Long.toString(v); return String.format(Locale.US,"%.1f%s",d,u[i]); }
    static void sort(List<Node> l, boolean name){ l.sort((a,b)-> name?a.name.compareTo(b.name):Long.compare(b.actual,a.actual)!=0?Long.compare(b.actual,a.actual):a.name.compareTo(b.name)); }
    static int cmdInfo(Opt o) throws Exception { Db db=readDb(o.db); System.out.println("Date       Time       Files    Dirs    Size Path"); DateTimeFormatter df=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"); for(Node r:db.roots) System.out.printf("%s %7d %7d %6s %s%n", df.format(LocalDateTime.ofInstant(Instant.ofEpochMilli(db.time), ZoneId.systemDefault())), db.files, db.dirs, size(o.apparent?r.apparent:r.actual,o), r.path); return 0; }
    static int cmdLs(Opt o) throws Exception { Db db=readDb(o.db); if(o.args.isEmpty()) o.args.add(Paths.get("").toAbsolutePath().toString()); for(String p:o.args){ Node n=find(db,p); if(n==null){ System.err.println("Path not found: "+p); return 1;} if(o.directory) printEntry(n,o,n.path); else if(o.recursive) printRec(n,o,0,"",true); else { ArrayList<Node> list=new ArrayList<>(n.children); sort(list,o.nameSort); for(Node c:list) if(!o.dirsOnly||c.dir) printEntry(c,o,c.name); } } return 0; }
    static void printEntry(Node n,Opt o,String name){ if(o.classify&&n.dir) name+="/"; if(o.bytes||o.countMode) System.out.printf("%12d %s", val(n,o), name); else System.out.printf("%6s %s", size(val(n,o),o), name); if(o.graph){ int bars=64; System.out.print(" ["+"+".repeat(Math.max(0,Math.min(bars,(int)(bars*0.66))))+" ".repeat(22)+"]"); } System.out.println(); }
    static void printRec(Node n, Opt o, int depth, String pref, boolean root){ if(depth>=o.levels) return; ArrayList<Node> list=new ArrayList<>(n.children); sort(list,o.nameSort); for(int i=0;i<list.size();i++){ Node c=list.get(i); if(o.dirsOnly&&!c.dir) continue; String branch=o.ascii?(i==list.size()-1?"`- ":"|- "):(i==list.size()-1?"╰─ ":"├─ "); String name=o.fullPath?c.path:pref+branch+c.name+(o.classify&&c.dir?"/":" "); if(o.bytes||o.countMode) System.out.printf("%12d %s%n", val(c,o), name); else System.out.printf("%6s %s%n", size(val(c,o),o), name); if(c.dir) printRec(c,o,depth+1,pref+(i==list.size()-1?"   ":(o.ascii?" | ":" │ ")),false); } }
    static int cmdJson(Opt o)throws Exception{ Db db=readDb(o.db); Node n=find(db,o.args.isEmpty()?null:o.args.get(0)); if(n==null)return 1; printJson(n,o,0,true); return 0; }
    static void printJson(Node n,Opt o,int ind,boolean root){ String sp="  ".repeat(ind); System.out.println(sp+"{"); System.out.println(sp+"  \"name\": \""+esc(root?n.path:n.name)+"\","); if(n.dir) System.out.println(sp+"  \"count\": "+n.count+","); System.out.println(sp+"  \"size_apparent\": "+n.apparent+","); System.out.println(sp+"  \"size_actual\": "+n.actual+(n.dir?",":"")); if(n.dir){ System.out.println(sp+"  \"children\": ["); ArrayList<Node> cs=new ArrayList<>(); for(Node c:n.children) if(!(o.excludeFiles&&!c.dir)&&c.actual>=o.minSize) cs.add(c); for(int i=0;i<cs.size();i++){ printJson(cs.get(i),o,ind+2,false); if(i<cs.size()-1) System.out.println(","); } System.out.println(sp+"  ]"); } System.out.println(sp+"}"); }
    static int cmdXml(Opt o)throws Exception{ Db db=readDb(o.db); Node n=find(db,o.args.isEmpty()?null:o.args.get(0)); if(n==null)return 1; System.out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); System.out.printf("<duc root=\"%s\" size_apparent=\"%d\" size_actual=\"%d\" count=\"%d\">%n", esc(n.path),n.apparent,n.actual,n.count); for(Node c:n.children) xmlEnt(c,o,1); System.out.println("</duc>"); return 0; }
    static void xmlEnt(Node n,Opt o,int ind){ if(o.excludeFiles&&!n.dir) return; if(n.actual<o.minSize) return; String sp=" ".repeat(ind); if(n.dir){ System.out.printf("%s<ent type=\"dir\" name=\"%s\" size_apparent=\"%d\" size_actual=\"%d\" count=\"%d\">%n",sp,esc(n.name),n.apparent,n.actual,n.count); for(Node c:n.children) xmlEnt(c,o,ind+1); System.out.println(sp+"</ent>"); } else System.out.printf("%s<ent name=\"%s\" size_apparent=\"%d\" size_actual=\"%d\" />%n",sp,esc(n.name),n.apparent,n.actual); }
    static int cmdHistogram(Opt o)throws Exception{ Db db=readDb(o.db); String path=db.roots.isEmpty()?"":db.roots.get(0).path; System.out.println("Path: "+path); System.out.println("Bkt       Size      Count"); for(int i=0;i<db.hist.length;i++){ long sz=(long)Math.pow(o.base10?10:2,i); System.out.printf("%3d %10s %10d%n",i,o.bytes?Long.toString(sz):size(sz,new Opt()),db.hist[i]); } return 0; }
    static int cmdTopn(Opt o)throws Exception{ Db db=readDb(o.db); System.out.println("        Size Filename"); ArrayList<Node> ts=new ArrayList<>(db.top); ts.sort((a,b)->Long.compare(b.actual,a.actual)); for(Node n:ts) System.out.printf("%12s %s%n", size(o.apparent?n.apparent:n.actual,o), n.path); return 0; }
    static int cmdGraph(Opt o)throws Exception{ String svg="<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"800\" height=\"800\"><circle cx=\"400\" cy=\"400\" r=\"300\" fill=\"#ddd\" stroke=\"#333\"/><text x=\"400\" y=\"405\" text-anchor=\"middle\">duc</text></svg>\n"; if(o.format.equals("svg")||o.output.endsWith(".svg")){ if(o.output.equals("-")) System.out.print(svg); else Files.writeString(Paths.get(o.output),svg); } else { byte[] png=Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lz3vNwAAAABJRU5ErkJggg=="); if(o.output.equals("-")) System.out.write(png); else Files.write(Paths.get(o.output),png); } return 0; }
    static int cmdCgi(Opt o)throws Exception{ System.out.println("Content-Type: text/html\n\n<html><body><h1>Duc</h1></body></html>"); return 0; }
    static String esc(String s){ return s.replace("&","&amp;").replace("\"","&quot;").replace("<","&lt;").replace(">","&gt;"); }
    static void printHelp(){ System.out.print("usage: duc <cmd> [options] [args]\n\nAvailable subcommands:\n\n  help      : Show help\n  histogram : Dump histogram of file sizes found.\n  index     : Scan the filesystem and generate the Duc index\n  info      : Dump database info\n  ls        : List sizes of directory\n  topn      : Dump N largest files in DB.\n  xml       : Dump XML output\n  json      : Dump JSON output\n  graph     : Generate a sunburst graph for a given path\n  cgi       : CGI interface wrapper\n  gui       : Interactive X11 graphical interface\n  ui        : Interactive ncurses user interface\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n\nUse 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all\noptions and detailed description of the subcommand.\n\nUse 'duc help --all' for a complete list of all options for all subcommands.\n"); }
    static void printAllHelp(){ printHelp(); }
    static void printSubHelp(String c){ System.out.println("usage: duc "+c+" [options] [PATH]..."); System.out.println(); System.out.println((c.equals("ls")?"List sizes of directory.":c.substring(0,1).toUpperCase()+c.substring(1)+" command.")+"\n"); System.out.println("Options for the command '"+c+"':"); System.out.println("  -a,  --apparent            show apparent instead of actual file size"); System.out.println("  -b,  --bytes               show file size in exact number of bytes"); System.out.println("  -d,  --database=VAL        select database file to use [~/.duc.db]"); System.out.println("  -h,  --help                show help"); }
}
