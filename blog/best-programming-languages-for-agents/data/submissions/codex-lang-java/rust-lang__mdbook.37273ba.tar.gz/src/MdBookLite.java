import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MdBookLite {
    static final String VERSION = "mdbook v0.5.0-alpha.1";
    static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) {
        try {
            int code = new MdBookLite().run(args);
            System.exit(code);
        } catch (BookError e) {
            log("ERROR", "mdbook_core::utils", "Error: " + e.getMessage());
            if (e.getCause() != null) log("ERROR", "mdbook_core::utils", "\tCaused By: " + e.getCause().getMessage());
            System.exit(101);
        } catch (Exception e) {
            log("ERROR", "mdbook_core::utils", "Error: " + e.getMessage());
            System.exit(101);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.print(topHelp());
            return 2;
        }
        if (isHelp(args[0])) {
            System.out.print(topHelp());
            return 0;
        }
        if (isVersion(args[0])) {
            System.out.println(VERSION);
            return 0;
        }
        String cmd = args[0];
        String[] rest = Arrays.copyOfRange(args, 1, args.length);
        if (cmd.startsWith("-")) {
            System.err.println("error: unexpected argument '" + cmd + "' found\n");
            System.err.println("Usage: executable [COMMAND]\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        return switch (cmd) {
            case "init" -> init(rest);
            case "build" -> build(rest, false);
            case "clean" -> clean(rest);
            case "test" -> test(rest);
            case "completions" -> completions(rest);
            case "watch" -> watch(rest);
            case "serve" -> serve(rest);
            case "help" -> help(rest);
            default -> {
                System.err.println("error: unrecognized subcommand '" + cmd + "'\n");
                System.err.println("Usage: executable [COMMAND]\n");
                System.err.println("For more information, try '--help'.");
                yield 2;
            }
        };
    }

    int help(String[] args) {
        if (args.length == 0) {
            System.out.print(topHelp());
            return 0;
        }
        String sub = args[0];
        if (List.of("init","build","test","clean","completions","watch","serve").contains(sub)) {
            System.out.print(helpFor(sub));
            return 0;
        }
        System.err.println("error: unrecognized subcommand '" + sub + "'\n");
        System.err.println("Usage: executable [COMMAND]\n");
        System.err.println("For more information, try '--help'.");
        return 2;
    }

    int init(String[] args) throws IOException {
        InitOpts o = new InitOpts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (isHelp(a)) { System.out.print(helpFor("init")); return 0; }
            if (isVersion(a)) { System.out.println(VERSION); return 0; }
            if (a.equals("--theme")) o.theme = true;
            else if (a.equals("--force")) o.force = true;
            else if (a.startsWith("--title=")) o.title = a.substring(8);
            else if (a.equals("--title")) o.title = needValue(args, ++i, "--title");
            else if (a.startsWith("--ignore=")) o.ignore = a.substring(9);
            else if (a.equals("--ignore")) o.ignore = needValue(args, ++i, "--ignore");
            else if (a.startsWith("-")) return unexpected(a, "init");
            else if (o.dir == null) o.dir = a;
            else return unexpected(a, "init");
        }
        if (o.dir == null) o.dir = ".";
        if (o.ignore != null && !o.ignore.equals("none") && !o.ignore.equals("git")) {
            System.err.println("error: invalid value '" + o.ignore + "' for '--ignore <ignore>'");
            System.err.println("  [possible values: none, git]\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        if (o.ignore == null && !o.force) {
            System.out.println("\nDo you want a .gitignore to be created? (y/n)");
            String ans = br.readLine();
            o.ignore = ans != null && ans.trim().toLowerCase(Locale.ROOT).startsWith("y") ? "git" : "none";
        } else if (o.ignore == null) {
            o.ignore = "none";
        }
        if (o.title == null && !o.force) {
            System.out.println("What title would you like to give the book? ");
            String t = br.readLine();
            o.title = (t == null || t.isBlank()) ? "My First Book" : t.trim();
        } else if (o.title == null) {
            o.title = "My First Book";
        }
        Path root = Paths.get(o.dir).normalize();
        Path src = root.resolve("src");
        Files.createDirectories(src);
        log("INFO", "mdbook_driver::init", "Creating a new book with stub content");
        Path summary = src.resolve("SUMMARY.md");
        if (!Files.exists(summary)) {
            Files.writeString(summary, "# Summary\n\n- [Chapter 1](./chapter_1.md)\n", StandardCharsets.UTF_8);
        }
        List<Chapter> chapters = Summary.parse(summary);
        if (chapters.isEmpty()) chapters.add(new Chapter("Chapter 1", "chapter_1.md", 0));
        for (Chapter c : chapters) {
            if (c.path == null || c.path.isBlank()) continue;
            Path md = src.resolve(c.path).normalize();
            if (!md.startsWith(src.normalize())) continue;
            if (!Files.exists(md)) {
                Files.createDirectories(md.getParent());
                Files.writeString(md, "# " + c.title + "\n", StandardCharsets.UTF_8);
            }
        }
        Path bookToml = root.resolve("book.toml");
        if (!Files.exists(bookToml)) {
            Files.writeString(bookToml, "[book]\nauthors = []\nlanguage = \"en\"\nsrc = \"src\"\ntitle = \"" + tomlEscape(o.title) + "\"\n", StandardCharsets.UTF_8);
        }
        if (o.ignore.equals("git")) Files.writeString(root.resolve(".gitignore"), "book\n", StandardCharsets.UTF_8);
        if (o.theme) {
            Files.createDirectories(src.resolve("theme"));
            Files.writeString(src.resolve("theme/index.hbs"), "<!-- mdBook theme placeholder -->\n", StandardCharsets.UTF_8);
        }
        System.out.println("\nAll done, no errors...");
        return 0;
    }

    int build(String[] args, boolean fromWatch) throws Exception {
        Integer early = earlyHelpVersion(args, "build");
        if (early != null) return early;
        BuildOpts o = parseBuildOpts(args, "build");
        if (o == null) return 2;
        Config cfg = Config.load(Paths.get(o.dir));
        Path src = cfg.root.resolve(cfg.src);
        Path summary = src.resolve("SUMMARY.md");
        if (!Files.exists(summary)) throw new BookError("Couldn't open SUMMARY.md in \"" + src + "\" directory", new IOException("No such file or directory (os error 2)"));
        log("INFO", "mdbook_driver::mdbook", "Book building has started");
        List<Chapter> chapters = Summary.parse(summary);
        for (Chapter c : chapters) {
            if (c.path == null || c.path.isBlank()) continue;
            Path md = src.resolve(c.path).normalize();
            if (!md.startsWith(src.normalize())) continue;
            if (!Files.exists(md)) {
                Files.createDirectories(md.getParent());
                Files.writeString(md, "# " + c.title + "\n", StandardCharsets.UTF_8);
            }
        }
        Path dest = o.dest == null ? cfg.root.resolve(cfg.buildDir) : cfg.root.resolve(o.dest);
        if (dest.isAbsolute()) dest = o.dest == null ? cfg.root.resolve(cfg.buildDir) : Paths.get(o.dest);
        deleteDir(dest);
        Files.createDirectories(dest);
        copyNonMarkdown(src, dest);
        writeAssets(dest);
        RenderContext rc = new RenderContext(cfg, chapters);
        for (int i = 0; i < chapters.size(); i++) {
            Chapter c = chapters.get(i);
            if (c.path == null || c.path.isBlank()) continue;
            Path md = src.resolve(c.path).normalize();
            String markdown = Files.exists(md) ? Files.readString(md, StandardCharsets.UTF_8) : "# " + c.title + "\n";
            Path out = dest.resolve(htmlPath(c.path));
            Files.createDirectories(out.getParent());
            Files.writeString(out, Renderer.page(rc, c, markdown, i), StandardCharsets.UTF_8);
        }
        Files.writeString(dest.resolve("toc.html"), Renderer.toc(rc), StandardCharsets.UTF_8);
        Files.writeString(dest.resolve("print.html"), Renderer.print(rc, src), StandardCharsets.UTF_8);
        Files.writeString(dest.resolve("404.html"), Renderer.simple("404", cfg.title, "<h1>404</h1><p>Not Found</p>"), StandardCharsets.UTF_8);
        log("INFO", "mdbook_driver::mdbook", "Running the html backend");
        log("INFO", "mdbook_html::html_handlebars::hbs_renderer", "HTML book written to `" + dest.toAbsolutePath().normalize() + "`");
        if (o.open) log("WARN", "mdbook_driver::mdbook", "--open is not supported by this implementation");
        return 0;
    }

    int clean(String[] args) throws Exception {
        Integer early = earlyHelpVersion(args, "clean");
        if (early != null) return early;
        BuildOpts o = parseBuildOpts(args, "clean");
        if (o == null) return 2;
        Config cfg = Config.load(Paths.get(o.dir));
        Path dest = o.dest == null ? cfg.root.resolve(cfg.buildDir) : cfg.root.resolve(o.dest);
        if (dest.isAbsolute()) dest = o.dest == null ? cfg.root.resolve(cfg.buildDir) : Paths.get(o.dest);
        long[] stats = dirStats(dest);
        deleteDir(dest);
        System.out.printf("Removed %d files, %s total%n", stats[0], human(stats[1]));
        return 0;
    }

    int test(String[] args) throws Exception {
        Integer early = earlyHelpVersion(args, "test");
        if (early != null) return early;
        BuildOpts o = parseTestOpts(args);
        if (o == null) return 2;
        Config cfg = Config.load(Paths.get(o.dir));
        Path src = cfg.root.resolve(cfg.src);
        Path summary = src.resolve("SUMMARY.md");
        if (!Files.exists(summary)) throw new BookError("Couldn't open SUMMARY.md in \"" + src + "\" directory", new IOException("No such file or directory (os error 2)"));
        List<Chapter> chapters = Summary.parse(summary);
        for (Chapter c : chapters) {
            if (o.chapter != null && !c.title.equals(o.chapter)) continue;
            log("INFO", "mdbook_driver::mdbook", "Testing chapter '" + c.title + "': \"" + c.path + "\"");
        }
        return 0;
    }

    int watch(String[] args) throws Exception {
        Integer early = earlyHelpVersion(args, "watch");
        if (early != null) return early;
        BuildOpts o = parseBuildOpts(args, "watch");
        if (o == null) return 2;
        List<String> buildArgs = new ArrayList<>();
        if (o.dest != null) { buildArgs.add("--dest-dir"); buildArgs.add(o.dest); }
        if (o.open) buildArgs.add("--open");
        buildArgs.add(o.dir);
        int code = build(buildArgs.toArray(new String[0]), true);
        if (code == 0) log("INFO", "mdbook_driver::watch", "Watching for changes...");
        return code;
    }

    int serve(String[] args) throws Exception {
        Integer early = earlyHelpVersion(args, "serve");
        if (early != null) return early;
        BuildOpts o = parseServeOpts(args);
        if (o == null) return 2;
        List<String> buildArgs = new ArrayList<>();
        if (o.dest != null) { buildArgs.add("--dest-dir"); buildArgs.add(o.dest); }
        buildArgs.add(o.dir);
        int code = build(buildArgs.toArray(new String[0]), false);
        if (code == 0) {
            log("INFO", "mdbook_driver::serve", "Serving on: http://" + o.hostname + ":" + o.port);
            Thread.sleep(Long.MAX_VALUE);
        }
        return code;
    }

    int completions(String[] args) {
        if (args.length == 0) {
            System.err.println("error: the following required arguments were not provided:\n  <SHELL>\n");
            System.err.println("Usage: executable completions <SHELL>\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        if (isHelp(args[0])) { System.out.print(helpFor("completions")); return 0; }
        if (isVersion(args[0])) { System.out.println(VERSION); return 0; }
        String sh = args[0];
        if (!List.of("bash","elvish","fish","powershell","zsh").contains(sh)) {
            System.err.println("error: invalid value '" + sh + "' for '<SHELL>'");
            System.err.println("  [possible values: bash, elvish, fish, powershell, zsh]\n");
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        System.out.print(Completions.forShell(sh));
        return 0;
    }

    Integer earlyHelpVersion(String[] args, String cmd) {
        for (String a : args) {
            if (isHelp(a)) { System.out.print(helpFor(cmd)); return 0; }
            if (isVersion(a)) { System.out.println(VERSION); return 0; }
        }
        return null;
    }

    BuildOpts parseBuildOpts(String[] args, String cmd) {
        BuildOpts o = new BuildOpts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (isHelp(a)) { System.out.print(helpFor(cmd)); return null; }
            if (isVersion(a)) { System.out.println(VERSION); return null; }
            if (a.equals("-d") || a.equals("--dest-dir")) o.dest = needValue(args, ++i, a);
            else if (a.startsWith("--dest-dir=")) o.dest = a.substring(11);
            else if (a.equals("-o") || a.equals("--open")) o.open = true;
            else if (a.equals("--watcher")) { o.watcher = needValue(args, ++i, a); if (!validWatcher(o.watcher)) return invalidWatcher(o.watcher); }
            else if (a.startsWith("--watcher=")) { o.watcher = a.substring(10); if (!validWatcher(o.watcher)) return invalidWatcher(o.watcher); }
            else if (a.startsWith("-")) { unexpected(a, cmd); return null; }
            else if (o.dir.equals(".")) o.dir = a;
            else { unexpected(a, cmd); return null; }
        }
        return o;
    }

    BuildOpts parseServeOpts(String[] args) {
        BuildOpts o = new BuildOpts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (isHelp(a)) { System.out.print(helpFor("serve")); return null; }
            if (isVersion(a)) { System.out.println(VERSION); return null; }
            if (a.equals("-d") || a.equals("--dest-dir")) o.dest = needValue(args, ++i, a);
            else if (a.startsWith("--dest-dir=")) o.dest = a.substring(11);
            else if (a.equals("-n") || a.equals("--hostname")) o.hostname = needValue(args, ++i, a);
            else if (a.startsWith("--hostname=")) o.hostname = a.substring(11);
            else if (a.equals("-p") || a.equals("--port")) o.port = needValue(args, ++i, a);
            else if (a.startsWith("--port=")) o.port = a.substring(7);
            else if (a.equals("-o") || a.equals("--open")) o.open = true;
            else if (a.equals("--watcher")) { o.watcher = needValue(args, ++i, a); if (!validWatcher(o.watcher)) return invalidWatcher(o.watcher); }
            else if (a.startsWith("--watcher=")) { o.watcher = a.substring(10); if (!validWatcher(o.watcher)) return invalidWatcher(o.watcher); }
            else if (a.startsWith("-")) { unexpected(a, "serve"); return null; }
            else if (o.dir.equals(".")) o.dir = a;
            else { unexpected(a, "serve"); return null; }
        }
        return o;
    }

    BuildOpts parseTestOpts(String[] args) {
        BuildOpts o = new BuildOpts();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (isHelp(a)) { System.out.print(helpFor("test")); return null; }
            if (isVersion(a)) { System.out.println(VERSION); return null; }
            if (a.equals("-d") || a.equals("--dest-dir")) o.dest = needValue(args, ++i, a);
            else if (a.startsWith("--dest-dir=")) o.dest = a.substring(11);
            else if (a.equals("-c") || a.equals("--chapter")) o.chapter = needValue(args, ++i, a);
            else if (a.startsWith("--chapter=")) o.chapter = a.substring(10);
            else if (a.equals("-L") || a.equals("--library-path")) o.libraryPath = needValue(args, ++i, a);
            else if (a.startsWith("--library-path=")) o.libraryPath = a.substring(15);
            else if (a.startsWith("-")) { unexpected(a, "test"); return null; }
            else if (o.dir.equals(".")) o.dir = a;
            else { unexpected(a, "test"); return null; }
        }
        return o;
    }

    static boolean validWatcher(String w) { return w.equals("poll") || w.equals("native"); }
    BuildOpts invalidWatcher(String w) {
        System.err.println("error: invalid value '" + w + "' for '--watcher <watcher>'");
        System.err.println("  [possible values: poll, native]\n");
        System.err.println("For more information, try '--help'.");
        return null;
    }
    int unexpected(String a, String cmd) {
        System.err.println("error: unexpected argument '" + a + "' found\n");
        if (a.startsWith("-")) System.err.println("  tip: to pass '" + a + "' as a value, use '-- " + a + "'\n");
        System.err.println("Usage: executable " + cmd + (cmd.equals("completions") ? " <SHELL>" : " [OPTIONS] [dir]") + "\n");
        System.err.println("For more information, try '--help'.");
        return 2;
    }
    static String needValue(String[] args, int i, String opt) {
        if (i >= args.length) throw new IllegalArgumentException("a value is required for '" + opt + "'");
        return args[i];
    }
    static boolean isHelp(String s) { return s.equals("-h") || s.equals("--help"); }
    static boolean isVersion(String s) { return s.equals("-V") || s.equals("--version"); }
    static void log(String level, String target, String msg) {
        System.err.println(LocalDateTime.now().format(TS) + " [" + level + "] (" + target + "): " + msg);
    }
    static String tomlEscape(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
    static String htmlPath(String md) {
        String p = md.replace('\\', '/');
        if (p.equals("README.md")) return "index.html";
        if (p.endsWith("/README.md")) return p.substring(0, p.length() - "README.md".length()) + "index.html";
        if (p.endsWith(".md")) return p.substring(0, p.length() - 3) + ".html";
        return p + ".html";
    }
    static void deleteDir(Path p) throws IOException {
        if (!Files.exists(p)) return;
        Files.walkFileTree(p, new SimpleFileVisitor<>() {
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException { Files.deleteIfExists(file); return FileVisitResult.CONTINUE; }
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException { Files.deleteIfExists(dir); return FileVisitResult.CONTINUE; }
        });
    }
    static long[] dirStats(Path p) throws IOException {
        long[] r = new long[2];
        if (!Files.exists(p)) return r;
        Files.walkFileTree(p, new SimpleFileVisitor<>() {
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException { r[0]++; r[1] += attrs.size(); return FileVisitResult.CONTINUE; }
        });
        return r;
    }
    static String human(long n) {
        if (n < 1024) return n + "B";
        if (n < 1024 * 1024) return String.format(Locale.ROOT, "%.2fKiB", n / 1024.0);
        return String.format(Locale.ROOT, "%.2fMiB", n / 1024.0 / 1024.0);
    }
    static void copyNonMarkdown(Path src, Path dest) throws IOException {
        if (!Files.exists(src)) return;
        Files.walkFileTree(src, new SimpleFileVisitor<>() {
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (!file.getFileName().toString().endsWith(".md")) {
                    Path rel = src.relativize(file);
                    Path out = dest.resolve(rel);
                    Files.createDirectories(out.getParent());
                    Files.copy(file, out, StandardCopyOption.REPLACE_EXISTING);
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }
    static void writeAssets(Path dest) throws IOException {
        Files.writeString(dest.resolve(".nojekyll"), "", StandardCharsets.UTF_8);
        Files.createDirectories(dest.resolve("css"));
        Files.createDirectories(dest.resolve("fonts"));
        Files.writeString(dest.resolve("css/general.css"), "body{font-family:Arial,sans-serif;margin:0;color:#222} main{max-width:900px;margin:2rem auto;padding:0 1rem;line-height:1.6} pre{background:#f6f8fa;padding:1rem;overflow:auto} code{background:#f6f8fa;padding:.1rem .25rem} nav{background:#f5f5f5;padding:.7rem 1rem} nav a{margin-right:1rem}\n", StandardCharsets.UTF_8);
        Files.writeString(dest.resolve("css/chrome.css"), "", StandardCharsets.UTF_8);
        Files.writeString(dest.resolve("css/print.css"), "", StandardCharsets.UTF_8);
        Files.writeString(dest.resolve("css/variables.css"), "", StandardCharsets.UTF_8);
        for (String f : List.of("book.js","toc.js","searchindex.js","searcher.js","clipboard.min.js","elasticlunr.min.js","mark.min.js","highlight.js")) Files.writeString(dest.resolve(f), "", StandardCharsets.UTF_8);
        for (String f : List.of("highlight.css","tomorrow-night.css","ayu-highlight.css","favicon.svg","favicon.png")) Files.writeString(dest.resolve(f), "", StandardCharsets.UTF_8);
        Files.writeString(dest.resolve("fonts/fonts.css"), "", StandardCharsets.UTF_8);
    }

    static String topHelp() {
        return """
Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try `mdbook <command> --help`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook
""";
    }
    static String helpFor(String c) {
        return switch (c) {
            case "init" -> """
Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version
""";
            case "build" -> buildHelp("build", "Builds a book from its markdown files");
            case "clean" -> buildHelp("clean", "Deletes a built book");
            case "test" -> """
Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version
""";
            case "completions" -> """
Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version
""";
            case "watch" -> """
Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""";
            case "serve" -> """
Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version
""";
            default -> topHelp();
        };
    }
    static String buildHelp(String cmd, String desc) {
        return desc + "\n\nUsage: executable " + cmd + " [OPTIONS] [dir]\n\nArguments:\n  [dir]  Root directory for the book\n         (Defaults to the current directory when omitted)\n\nOptions:\n  -d, --dest-dir <dest-dir>  Output directory for the book\n                             Relative paths are interpreted relative to the book's root directory.\n                             If omitted, mdBook uses build.build-dir from book.toml or defaults to\n                             `./book`.\n" + (cmd.equals("build") ? "  -o, --open                 Opens the compiled book in a web browser\n" : "") + "  -h, --help                 Print help\n  -V, --version              Print version\n";
    }
}

class BookError extends Exception {
    BookError(String msg, Throwable cause) { super(msg, cause); }
}

class InitOpts { String dir; String title; String ignore; boolean force; boolean theme; }
class BuildOpts { String dir = "."; String dest; String watcher = "poll"; boolean open; String hostname = "localhost"; String port = "3000"; String chapter; String libraryPath; }

class Config {
    Path root; String title = "My First Book"; String language = "en"; String src = "src"; String buildDir = "book"; String description = "";
    static Config load(Path root) throws IOException {
        Config c = new Config();
        c.root = root.toAbsolutePath().normalize();
        Path toml = c.root.resolve("book.toml");
        if (!Files.exists(toml)) return c;
        String section = "";
        for (String raw : Files.readAllLines(toml, StandardCharsets.UTF_8)) {
            String line = raw.replaceFirst("#.*$", "").trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) { section = line.substring(1, line.length()-1); continue; }
            int eq = line.indexOf('=');
            if (eq < 0) continue;
            String key = line.substring(0, eq).trim();
            String val = unquote(line.substring(eq + 1).trim());
            if (section.equals("book")) {
                if (key.equals("title")) c.title = val;
                else if (key.equals("language")) c.language = val;
                else if (key.equals("src")) c.src = val;
                else if (key.equals("description")) c.description = val;
            } else if (section.equals("build") && key.equals("build-dir")) c.buildDir = val;
        }
        return c;
    }
    static String unquote(String v) {
        if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) return v.substring(1, v.length()-1).replace("\\\"", "\"").replace("\\\\", "\\");
        return v;
    }
}

class Chapter {
    String title; String path; int level;
    Chapter(String title, String path, int level) { this.title = title; this.path = path; this.level = level; }
}

class Summary {
    static final Pattern LINK = Pattern.compile("^(\\s*)(?:[-*+]\\s*)?\\[([^]]+)]\\(([^)]*)\\)");
    static List<Chapter> parse(Path summary) throws IOException {
        List<Chapter> out = new ArrayList<>();
        for (String line : Files.readAllLines(summary, StandardCharsets.UTF_8)) {
            Matcher m = LINK.matcher(line);
            if (m.find()) {
                String indent = m.group(1).replace("\t", "    ");
                String path = m.group(3).trim();
                if (path.startsWith("./")) path = path.substring(2);
                out.add(new Chapter(m.group(2).trim(), path, indent.length() / 4));
            }
        }
        return out;
    }
}

class RenderContext {
    Config cfg; List<Chapter> chapters;
    RenderContext(Config cfg, List<Chapter> chapters) { this.cfg = cfg; this.chapters = chapters; }
}

class Renderer {
    static String page(RenderContext rc, Chapter ch, String md, int idx) {
        String root = rootPrefix(ch.path);
        String title = escape(ch.title) + " - " + escape(rc.cfg.title);
        String prev = idx > 0 ? linkNav(root, rc.chapters.get(idx - 1), "Previous") : "";
        String next = idx + 1 < rc.chapters.size() ? linkNav(root, rc.chapters.get(idx + 1), "Next") : "";
        return "<!DOCTYPE HTML>\n<html lang=\"" + escape(rc.cfg.language) + "\" class=\"light sidebar-visible\" dir=\"ltr\">\n<head>\n<meta charset=\"UTF-8\">\n<title>" + title + "</title>\n<meta name=\"description\" content=\"" + escape(rc.cfg.description) + "\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<link rel=\"stylesheet\" href=\"" + root + "css/general.css\">\n<script>window.path_to_searchindex_js='" + root + "searchindex.js';</script>\n</head>\n<body>\n<nav><a href=\"" + root + "index.html\">" + escape(rc.cfg.title) + "</a><a href=\"" + root + "toc.html\">Contents</a><a href=\"" + root + "print.html\">Print</a></nav>\n<main>\n" + markdown(md, root) + "\n<div class=\"nav-chapters\">" + prev + next + "</div>\n</main>\n</body>\n</html>\n";
    }
    static String simple(String pageTitle, String bookTitle, String body) {
        return "<!DOCTYPE HTML>\n<html><head><meta charset=\"UTF-8\"><title>" + escape(pageTitle) + " - " + escape(bookTitle) + "</title><link rel=\"stylesheet\" href=\"css/general.css\"></head><body><main>" + body + "</main></body></html>\n";
    }
    static String toc(RenderContext rc) {
        StringBuilder b = new StringBuilder("<!DOCTYPE HTML>\n<html><head><meta charset=\"UTF-8\"><title>Table of Contents - " + escape(rc.cfg.title) + "</title><link rel=\"stylesheet\" href=\"css/general.css\"></head><body><main><h1>Table of Contents</h1><ol>\n");
        for (Chapter c : rc.chapters) if (c.path != null && !c.path.isBlank()) b.append("<li style=\"margin-left:").append(c.level * 1.5).append("em\"><a href=\"").append(escape(MdBookLite.htmlPath(c.path))).append("\">").append(escape(c.title)).append("</a></li>\n");
        return b.append("</ol></main></body></html>\n").toString();
    }
    static String print(RenderContext rc, Path src) throws IOException {
        StringBuilder body = new StringBuilder();
        for (Chapter c : rc.chapters) if (c.path != null && !c.path.isBlank()) {
            Path md = src.resolve(c.path).normalize();
            body.append(markdown(Files.exists(md) ? Files.readString(md, StandardCharsets.UTF_8) : "# " + c.title + "\n", ""));
            body.append("\n<hr>\n");
        }
        return simple("Print", rc.cfg.title, body.toString());
    }
    static String linkNav(String root, Chapter c, String text) {
        if (c.path == null || c.path.isBlank()) return "";
        return "<a class=\"nav-" + text.toLowerCase(Locale.ROOT) + "\" href=\"" + root + escape(MdBookLite.htmlPath(c.path)) + "\">" + text + ": " + escape(c.title) + "</a> ";
    }
    static String rootPrefix(String mdPath) {
        String hp = MdBookLite.htmlPath(mdPath);
        int slash = hp.lastIndexOf('/');
        if (slash < 0) return "";
        int depth = hp.substring(0, slash).split("/").length;
        return "../".repeat(depth);
    }
    static String markdown(String md, String root) {
        StringBuilder out = new StringBuilder();
        StringBuilder para = new StringBuilder();
        boolean code = false;
        String codeLang = "";
        List<String> lines = Arrays.asList(md.replace("\r\n", "\n").split("\n", -1));
        for (String line : lines) {
            if (line.startsWith("```")) {
                flushPara(out, para);
                if (!code) { code = true; codeLang = line.substring(3).trim().split("\\s+")[0]; out.append("<pre><code class=\"language-").append(escape(codeLang)).append("\">"); }
                else { code = false; out.append("</code></pre>\n"); }
                continue;
            }
            if (code) { out.append(escape(line)).append("\n"); continue; }
            if (line.isBlank()) { flushPara(out, para); continue; }
            Matcher h = Pattern.compile("^(#{1,6})\\s+(.*)$").matcher(line);
            if (h.find()) {
                flushPara(out, para);
                int n = h.group(1).length();
                String text = inline(h.group(2), root);
                String id = slug(stripTags(text));
                out.append("<h").append(n).append(" id=\"").append(id).append("\"><a class=\"header\" href=\"#").append(id).append("\">").append(text).append("</a></h").append(n).append(">\n");
            } else if (line.matches("^\\s*[-*+]\\s+.*")) {
                flushPara(out, para);
                out.append("<ul><li>").append(inline(line.replaceFirst("^\\s*[-*+]\\s+", ""), root)).append("</li></ul>\n");
            } else {
                if (!para.isEmpty()) para.append(' ');
                para.append(line.trim());
            }
        }
        flushPara(out, para);
        if (code) out.append("</code></pre>\n");
        return out.toString();
    }
    static void flushPara(StringBuilder out, StringBuilder para) {
        if (!para.isEmpty()) {
            out.append("<p>").append(inline(para.toString(), "")).append("</p>\n");
            para.setLength(0);
        }
    }
    static String inline(String s, String root) {
        String e = escape(s);
        e = e.replaceAll("`([^`]+)`", "<code>$1</code>");
        e = e.replaceAll("\\*\\*([^*]+)\\*\\*", "<strong>$1</strong>");
        Pattern p = Pattern.compile("\\[([^]]+)]\\(([^)]+)\\)");
        Matcher m = p.matcher(e);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String href = m.group(2);
            if (href.endsWith(".md")) href = MdBookLite.htmlPath(href.startsWith("./") ? href.substring(2) : href);
            m.appendReplacement(sb, "<a href=\"" + Matcher.quoteReplacement(href) + "\">" + m.group(1) + "</a>");
        }
        m.appendTail(sb);
        return sb.toString();
    }
    static String escape(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
    static String stripTags(String s) { return s.replaceAll("<[^>]*>", ""); }
    static String slug(String s) {
        String x = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_ -]", "").trim().replaceAll("\\s+", "-");
        return x.isEmpty() ? "section" : x;
    }
}

class Completions {
    static String forShell(String shell) {
        return switch (shell) {
            case "bash" -> "_mdbook() {\n    COMPREPLY=()\n    local cur=\"${COMP_WORDS[COMP_CWORD]}\"\n    local opts=\"init build test clean completions watch serve help --help --version\"\n    COMPREPLY=( $(compgen -W \"$opts\" -- \"$cur\") )\n}\ncomplete -F _mdbook mdbook\n";
            case "fish" -> "complete -c mdbook -f -a 'init build test clean completions watch serve help'\ncomplete -c mdbook -s h -l help -d 'Print help'\ncomplete -c mdbook -s V -l version -d 'Print version'\n";
            case "zsh" -> "#compdef mdbook\n_arguments '1: :((init build test clean completions watch serve help))' '(-h --help)'{-h,--help}'[Print help]' '(-V --version)'{-V,--version}'[Print version]'\n";
            case "elvish" -> "set edit:completion:arg-completer[mdbook] = {|@words| put init build test clean completions watch serve help }\n";
            case "powershell" -> "Register-ArgumentCompleter -Native -CommandName 'mdbook' -ScriptBlock { param($wordToComplete) 'init','build','test','clean','completions','watch','serve','help' | Where-Object { $_ -like \"$wordToComplete*\" } }\n";
            default -> "";
        };
    }
}
