import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

@SuppressWarnings({"unchecked", "rawtypes"})
public class Gron {
    static final String HELP = "Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable\n\n"+
"Usage:\n  gron [OPTIONS] [FILE|URL|-]\n\n"+
"Options:\n  -u, --ungron     Reverse the operation (turn assignments back into JSON)\n  -v, --values     Print just the values of provided assignments\n  -c, --colorize   Colorize output (default on tty)\n  -m, --monochrome Monochrome (don't colorize output)\n  -s, --stream     Treat each line of input as a separate JSON object\n  -k, --insecure   Disable certificate validation\n  -x, --proxy      Set proxy configuration\n      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.\n  -j, --json       Represent gron data as JSON stream\n      --no-sort    Don't sort output (faster)\n      --version    Print version information\n\n"+
"Exit Codes:\n  0\tOK\n  1\tFailed to open file\n  2\tFailed to read input\n  3\tFailed to form statements\n  4\tFailed to fetch URL\n  5\tFailed to parse statements\n  6\tFailed to encode JSON\n\n"+
"Examples:\n  gron /tmp/apiresponse.json\n  gron http://jsonplaceholder.typicode.com/users/1 \n  curl -s http://jsonplaceholder.typicode.com/users/1 | gron\n  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron";

    static class Num { String s; Num(String s){this.s=s;} public String toString(){return s;} }

    public static void main(String[] args) {
        boolean ungron=false, values=false, stream=false, json=false, sort=true;
        String inputArg=null;
        for (int i=0;i<args.length;i++) {
            String a=args[i];
            switch(a){
                case "-u": case "--ungron": ungron=true; break;
                case "-v": case "--values": values=true; break;
                case "-s": case "--stream": stream=true; break;
                case "-j": case "--json": json=true; break;
                case "--no-sort": sort=false; break;
                case "-c": case "--colorize": case "-m": case "--monochrome": case "-k": case "--insecure": break;
                case "--version": System.out.println("gron version dev"); return;
                case "--help": case "-h": System.err.println(HELP); return;
                case "-x": case "--proxy": case "--noproxy": if (i+1<args.length) i++; break;
                default:
                    if (a.startsWith("-")) { System.err.println("flag provided but not defined: "+a.substring(1)); System.err.println(HELP); System.exit(2); }
                    else inputArg=a;
            }
        }
        String in;
        try { in = readInput(inputArg); }
        catch (NoSuchFileException e) { System.err.println("open "+inputArg+": no such file or directory"); System.exit(1); return; }
        catch (IOException e) { System.err.println("failed to read input: "+e.getMessage()); System.exit(2); return; }
        try {
            if (ungron) {
                Object root = json ? parseJsonStatements(in) : parseAssignments(in, values);
                System.out.println(writePretty(root,0));
            } else if (values) {
                printValues(in, json);
            } else {
                Object root;
                if (stream) {
                    List<Object> arr=new ArrayList<>();
                    for(String line: in.split("\\R")) if(!line.trim().isEmpty()) arr.add(new Parser(line).parseAll());
                    root=arr;
                } else root=new Parser(in).parseAll();
                List<Stmt> out=new ArrayList<>(); flatten(root,new ArrayList<>(),out);
                if (sort) out.sort(Comparator.comparing(s -> pathToText(s.path)));
                for(Stmt s: out) System.out.println(json ? streamStmt(s) : pathToText(s.path)+" = "+writeCompact(s.val)+";");
            }
        } catch (ParseException e) { System.err.println((ungron?"failed to parse statements: ":"failed to form statements: ")+e.getMessage()); System.exit(ungron?5:3); }
          catch (Exception e) { System.err.println(e.getMessage()==null?e.toString():e.getMessage()); System.exit(6); }
    }

    static String readInput(String arg) throws IOException {
        if (arg==null || arg.equals("-")) return new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        if (arg.startsWith("http://") || arg.startsWith("https://")) {
            try (InputStream is = new URL(arg).openStream()) { return new String(is.readAllBytes(), StandardCharsets.UTF_8); }
            catch (IOException e) { System.err.println("failed to fetch URL: "+e.getMessage()); System.exit(4); return ""; }
        }
        return Files.readString(Path.of(arg), StandardCharsets.UTF_8);
    }

    static class Stmt { List<Object> path; Object val; Stmt(List<Object> p,Object v){path=p;val=v;} }
    static void flatten(Object v, List<Object> path, List<Stmt> out) {
        out.add(new Stmt(new ArrayList<>(path), v instanceof Map ? new LinkedHashMap<>() : v instanceof List ? new ArrayList<>() : v));
        if (v instanceof Map) for (Object e0: ((Map<?,?>)v).entrySet()) { Map.Entry<?,?> e=(Map.Entry<?,?>)e0; path.add(e.getKey().toString()); flatten(e.getValue(),path,out); path.remove(path.size()-1); }
        else if (v instanceof List) { List<?> l=(List<?>)v; for(int i=0;i<l.size();i++){ path.add(i); flatten(l.get(i),path,out); path.remove(path.size()-1);} }
    }
    static boolean ident(String s){ return s.matches("[A-Za-z_$][A-Za-z0-9_$]*"); }
    static String pathToText(List<Object> path){ StringBuilder b=new StringBuilder("json"); for(Object p:path){ if(p instanceof Integer) b.append('[').append(p).append(']'); else {String s=p.toString(); if(ident(s)) b.append('.').append(s); else b.append('[').append(quote(s)).append(']');}} return b.toString(); }
    static String streamStmt(Stmt s){ List<Object> pair=new ArrayList<>(); pair.add(s.path); pair.add(s.val); return writeCompact(pair); }

    static Object parseJsonStatements(String in){ Object root=null; boolean any=false; for(String line: in.split("\\R")){ if(line.trim().isEmpty()) continue; any=true; Object o=new Parser(line).parseAll(); if(!(o instanceof List) || ((List<?>)o).size()!=2) throw new ParseException("invalid JSON statement"); List<?> pair=(List<?>)o; List<Object> path=new ArrayList<>(); if(pair.get(0) instanceof List) for(Object p:(List<?>)pair.get(0)) { if(p instanceof Num) path.add(Integer.parseInt(((Num)p).s)); else path.add(p.toString()); } root=assign(root,path,pair.get(1)); } return any?root:new LinkedHashMap<>(); }

    static Object parseAssignments(String in, boolean ignoreValuesFlag){ Object root=null; boolean any=false; for(String raw: in.split("\\R")){ String line=raw.trim(); if(line.isEmpty()) continue; any=true; if(!line.endsWith(";")) throw new ParseException("ungron failed for `"+line+"`: statement has no value"); line=line.substring(0,line.length()-1).trim(); int eq=findEq(line); if(eq<0) throw new ParseException("ungron failed for `"+line+"`: statement has no value"); String left=line.substring(0,eq).trim(), right=line.substring(eq+1).trim(); if(right.isEmpty()) throw new ParseException("ungron failed for `"+line+";`: invalid value ``"); if(!left.startsWith("json")) continue; List<Object> path=parsePath(left.substring(4)); Object val=new Parser(right).parseAll(); root=assign(root,path,val); } return any?root:new LinkedHashMap<>(); }
    static int findEq(String s){ boolean str=false, esc=false; for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(str){ if(esc) esc=false; else if(c=='\\') esc=true; else if(c=='\"') str=false; } else { if(c=='\"') str=true; else if(c=='=') return i; }} return -1; }
    static List<Object> parsePath(String s){ List<Object> p=new ArrayList<>(); int i=0; while(i<s.length()){ char c=s.charAt(i); if(c=='.'){ int j=++i; while(j<s.length() && (Character.isLetterOrDigit(s.charAt(j))||s.charAt(j)=='_'||s.charAt(j)=='$')) j++; p.add(s.substring(i,j)); i=j; } else if(c=='['){ int j=i+1; if(j<s.length()&&s.charAt(j)=='\"'){ int start=j; boolean esc=false; j++; while(j<s.length()){ char ch=s.charAt(j); if(esc) esc=false; else if(ch=='\\') esc=true; else if(ch=='\"'){j++;break;} j++; } String q=s.substring(start,j); p.add(new Parser(q).parseAll().toString()); if(j>=s.length()||s.charAt(j)!=']') throw new ParseException("invalid path"); i=j+1; } else { int st=j; while(j<s.length()&&Character.isDigit(s.charAt(j))) j++; p.add(Integer.parseInt(s.substring(st,j))); if(j>=s.length()||s.charAt(j)!=']') throw new ParseException("invalid path"); i=j+1; }} else if(Character.isWhitespace(c)) i++; else throw new ParseException("invalid path"); } return p; }

    static Object assign(Object root, List<Object> path, Object val){ if(path.isEmpty()) return cloneContainer(val); if(root==null) root = path.get(0) instanceof Integer ? new ArrayList<>() : new LinkedHashMap<String,Object>(); Object cur=root; for(int i=0;i<path.size();i++){ Object seg=path.get(i); boolean last=i==path.size()-1; Object next = !last && path.get(i+1) instanceof Integer ? new ArrayList<>() : new LinkedHashMap<String,Object>(); if(seg instanceof Integer){ List<Object> l=(List<Object>)cur; int idx=(Integer)seg; while(l.size()<=idx) l.add(null); if(last) l.set(idx, cloneContainer(val)); else { if(l.get(idx)==null) l.set(idx,next); cur=l.get(idx); } } else { Map<String,Object> m=(Map<String,Object>)cur; String k=seg.toString(); if(last) m.put(k, cloneContainer(val)); else { if(!m.containsKey(k) || m.get(k)==null) m.put(k,next); cur=m.get(k); } } } return root; }
    static Object cloneContainer(Object v){ if(v instanceof Map) return new LinkedHashMap<String,Object>(); if(v instanceof List) return new ArrayList<Object>(); return v; }

    static void printValues(String in, boolean jsonMode){ if(jsonMode){ for(String line: in.split("\\R")){ if(line.trim().isEmpty()) continue; Object o=new Parser(line).parseAll(); Object v=((List<?>)o).get(1); if(!(v instanceof Map) && !(v instanceof List)) System.out.println(valueText(v)); }} else { for(String raw: in.split("\\R")){ String line=raw.trim(); if(line.isEmpty()||!line.endsWith(";")) continue; int eq=findEq(line); if(eq<0) continue; Object v=new Parser(line.substring(eq+1,line.length()-1).trim()).parseAll(); if(!(v instanceof Map) && !(v instanceof List)) System.out.println(valueText(v)); }} }
    static String valueText(Object v){ if(v==null) return "null"; if(v instanceof String) return (String)v; if(v instanceof Num) return ((Num)v).s; return String.valueOf(v); }

    static String writeCompact(Object v){ if(v==null) return "null"; if(v instanceof String) return quote((String)v); if(v instanceof Num) return ((Num)v).s; if(v instanceof Boolean) return v.toString(); if(v instanceof Map){ StringBuilder b=new StringBuilder("{"); boolean first=true; for(Object e0: ((Map<?,?>)v).entrySet()){ Map.Entry<?,?> e=(Map.Entry<?,?>)e0; if(!first)b.append(','); first=false; b.append(quote(e.getKey().toString())).append(':').append(writeCompact(e.getValue())); } return b.append('}').toString(); } if(v instanceof List){ StringBuilder b=new StringBuilder("["); boolean first=true; for(Object x:(List<?>)v){ if(!first)b.append(','); first=false; b.append(writeCompact(x)); } return b.append(']').toString(); } return String.valueOf(v); }
    static String writePretty(Object v,int ind){ if(v instanceof Map){ Map<String,Object> m=(Map<String,Object>)v; if(m.isEmpty()) return "{}"; List<String> keys=new ArrayList<>(m.keySet()); Collections.sort(keys); StringBuilder b=new StringBuilder("{\n"); for(int i=0;i<keys.size();i++){ String k=keys.get(i); spaces(b,ind+2); b.append(quote(k)).append(": ").append(writePretty(m.get(k),ind+2)); if(i<keys.size()-1)b.append(','); b.append('\n'); } spaces(b,ind); return b.append('}').toString(); } if(v instanceof List){ List<?> l=(List<?>)v; if(l.isEmpty()) return "[]"; StringBuilder b=new StringBuilder("[\n"); for(int i=0;i<l.size();i++){ spaces(b,ind+2); b.append(writePretty(l.get(i),ind+2)); if(i<l.size()-1)b.append(','); b.append('\n'); } spaces(b,ind); return b.append(']').toString(); } return writeCompact(v); }
    static void spaces(StringBuilder b,int n){ for(int i=0;i<n;i++) b.append(' '); }
    static String quote(String s){ StringBuilder b=new StringBuilder("\""); for(int i=0;i<s.length();i++){ char c=s.charAt(i); switch(c){ case '\"': b.append("\\\""); break; case '\\': b.append("\\\\"); break; case '\b': b.append("\\b"); break; case '\f': b.append("\\f"); break; case '\n': b.append("\\n"); break; case '\r': b.append("\\r"); break; case '\t': b.append("\\t"); break; default: if(c<0x20) b.append(String.format("\\u%04x",(int)c)); else b.append(c); }} return b.append('"').toString(); }

    static class ParseException extends RuntimeException { ParseException(String m){super(m);} }
    static class Parser { String s; int i=0; Parser(String s){this.s=s;} Object parseAll(){ Object v=parseValue(); ws(); if(i!=s.length()) throw new ParseException("invalid character '"+s.charAt(i)+"' after top-level value"); return v; } void ws(){ while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++; } Object parseValue(){ ws(); if(i>=s.length()) throw new ParseException("unexpected end of JSON input"); char c=s.charAt(i); if(c=='\"') return parseString(); if(c=='{') return parseObj(); if(c=='[') return parseArr(); if(c=='t'&&eat("true")) return Boolean.TRUE; if(c=='f'&&eat("false")) return Boolean.FALSE; if(c=='n'&&eat("null")) return null; if(c=='-'||Character.isDigit(c)) return parseNum(); throw new ParseException("invalid character '"+c+"' looking for beginning of value"); } boolean eat(String x){ if(s.startsWith(x,i)){i+=x.length();return true;} return false; } String parseString(){ StringBuilder b=new StringBuilder(); i++; while(i<s.length()){ char c=s.charAt(i++); if(c=='\"') return b.toString(); if(c=='\\'){ if(i>=s.length()) throw new ParseException("invalid string"); char e=s.charAt(i++); switch(e){ case '\"':b.append('"');break; case '\\':b.append('\\');break; case '/':b.append('/');break; case 'b':b.append('\b');break; case 'f':b.append('\f');break; case 'n':b.append('\n');break; case 'r':b.append('\r');break; case 't':b.append('\t');break; case 'u': if(i+4>s.length()) throw new ParseException("invalid unicode escape"); b.append((char)Integer.parseInt(s.substring(i,i+4),16)); i+=4; break; default: throw new ParseException("invalid escape"); }} else b.append(c); } throw new ParseException("unexpected end of JSON input"); } Object parseObj(){ LinkedHashMap<String,Object> m=new LinkedHashMap<>(); i++; ws(); if(i<s.length()&&s.charAt(i)=='}'){i++;return m;} while(true){ ws(); if(i>=s.length()||s.charAt(i)!='\"') throw new ParseException("invalid character '"+(i<s.length()?s.charAt(i):' ')+"' looking for beginning of object key string"); String k=parseString(); ws(); if(i>=s.length()||s.charAt(i)!=':') throw new ParseException("expected colon"); i++; m.put(k,parseValue()); ws(); if(i<s.length()&&s.charAt(i)==','){i++;continue;} if(i<s.length()&&s.charAt(i)=='}'){i++;return m;} throw new ParseException("expected comma or object end"); }} Object parseArr(){ ArrayList<Object> l=new ArrayList<>(); i++; ws(); if(i<s.length()&&s.charAt(i)==']'){i++;return l;} while(true){ l.add(parseValue()); ws(); if(i<s.length()&&s.charAt(i)==','){i++;continue;} if(i<s.length()&&s.charAt(i)==']'){i++;return l;} throw new ParseException("expected comma or array end"); }} Num parseNum(){ int st=i; if(s.charAt(i)=='-')i++; while(i<s.length()&&Character.isDigit(s.charAt(i)))i++; if(i<s.length()&&s.charAt(i)=='.'){i++; while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;} if(i<s.length()&&(s.charAt(i)=='e'||s.charAt(i)=='E')){i++; if(i<s.length()&&(s.charAt(i)=='+'||s.charAt(i)=='-'))i++; while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;} return new Num(s.substring(st,i)); }}
}
