import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

public class Direnv {
    static final String VERSION = "2.37.1";

    public static void main(String[] args) throws Exception {
        Direnv d = new Direnv();
        int code = d.run(args);
        System.exit(code);
    }

    int run(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("help") || args[0].equals("--help") || args[0].equals("-h")) {
            printHelp();
            return 0;
        }
        String cmd = args[0];
        switch (cmd) {
            case "version": return version(Arrays.copyOfRange(args, 1, args.length));
            case "hook": return hook(args);
            case "status": return status(args);
            case "allow": case "permit": case "grant": return allow(args, true);
            case "block": case "deny": case "disallow": case "revoke": return allow(args, false);
            case "export": return exportCmd(args);
            case "exec": return exec(args);
            case "stdlib": printStdlib(); return 0;
            case "reload": System.out.println("direnv: reloading"); return 0;
            case "prune": return 0;
            case "edit": return edit(args);
            case "fetchurl": return fetchurl(args);
            case "log": return log(args);
            default:
                err("command \"" + String.join(" ", args) + "\" not found");
                return 1;
        }
    }

    static void printHelp() {
        System.out.println("direnv v" + VERSION);
        System.out.println("Usage: direnv COMMAND [...ARGS]\n");
        System.out.println("Available commands");
        System.out.println("------------------");
        System.out.println("allow [PATH_TO_RC]:\n  aliases: permit, grant\n  Grants direnv permission to load the given .envrc or .env file.");
        System.out.println("block [PATH_TO_RC]:\n  aliases: deny, disallow, revoke\n  Revokes the authorization of a given .envrc or .env file.");
        System.out.println("edit [PATH_TO_RC]:\n  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow\n  the file to be loaded afterwards.");
        System.out.println("exec DIR COMMAND [...ARGS]:\n  Executes a command after loading the first .envrc or .env found in DIR");
        System.out.println("export SHELL:\n  Loads an .envrc or .env and prints the diff in terms of exports.\n  Supported SHELL values are: [tcsh, zsh, systemd, elvish, fish, json, murex, vim, pwsh, bash, gha, gzenv]");
        System.out.println("fetchurl <url> [<integrity-hash>]:\n  Fetches a given URL into direnv's CAS");
        System.out.println("help [SHOW_PRIVATE]:\n  Shows this help");
        System.out.println("hook SHELL:\n  Used to setup the shell hook");
        System.out.println("prune:\n  Removes old allowed and required files");
        System.out.println("reload:\n  Triggers an env reload");
        System.out.println("status [--json]:\n  Prints some debug status information");
        System.out.println("stdlib:\n  Displays the stdlib available in the .envrc execution context");
        System.out.println("version [VERSION_AT_LEAST]:\n  prints the version or checks that direnv is older than VERSION_AT_LEAST.");
        System.out.println("log [--status | --error] <message>:\n  Logs a given message");
    }

    int version(String[] args) {
        if (args.length == 0) {
            System.out.println(VERSION);
            return 0;
        }
        if (compareVersions(VERSION, args[0]) < 0) {
            err("current version v" + VERSION + " is older than the desired version v" + args[0]);
            return 1;
        }
        return 0;
    }

    static int compareVersions(String a, String b) {
        String[] as = a.split("\\."), bs = b.split("\\.");
        for (int i = 0; i < Math.max(as.length, bs.length); i++) {
            int ai = i < as.length ? parseLeadingInt(as[i]) : 0;
            int bi = i < bs.length ? parseLeadingInt(bs[i]) : 0;
            if (ai != bi) return Integer.compare(ai, bi);
        }
        return 0;
    }

    static int parseLeadingInt(String s) {
        int n = 0, i = 0;
        while (i < s.length() && Character.isDigit(s.charAt(i))) n = n * 10 + s.charAt(i++) - '0';
        return n;
    }

    int hook(String[] args) {
        if (args.length < 2) { err("missing shell argument"); return 1; }
        String self = selfPath();
        switch (args[1]) {
            case "bash":
                System.out.print("\n_direnv_hook() {\n  local previous_exit_status=$?;\n  vars=\"$(\"" + self + "\" export bash)\";\n  trap -- '' SIGINT;\n  eval \"$vars\";\n  trap - SIGINT;\n  return $previous_exit_status;\n};\nif [[ \";${PROMPT_COMMAND[*]:-};\" != *\";_direnv_hook;\"* ]]; then\n  if [[ \"$(declare -p PROMPT_COMMAND 2>&1)\" == \"declare -a\"* ]]; then\n    PROMPT_COMMAND=(_direnv_hook \"${PROMPT_COMMAND[@]}\")\n  else\n    PROMPT_COMMAND=\"_direnv_hook${PROMPT_COMMAND:+;$PROMPT_COMMAND}\"\n  fi\nfi\n");
                return 0;
            case "zsh":
                System.out.print("\n_direnv_hook() {\n  vars=\"$(\"" + self + "\" export zsh)\"\n  trap -- '' SIGINT\n  eval \"$vars\"\n  trap - SIGINT\n}\ntypeset -ag precmd_functions\nif (( ! ${precmd_functions[(I)_direnv_hook]} )); then\n  precmd_functions=(_direnv_hook $precmd_functions)\nfi\ntypeset -ag chpwd_functions\nif (( ! ${chpwd_functions[(I)_direnv_hook]} )); then\n  chpwd_functions=(_direnv_hook $chpwd_functions)\nfi\n");
                return 0;
            case "fish":
                System.out.print("\n    function __direnv_export_eval --on-event fish_prompt;\n        \"" + self + "\" export fish | source;\n\n        if test \"$direnv_fish_mode\" != \"disable_arrow\";\n            function __direnv_cd_hook --on-variable PWD;\n                if test \"$direnv_fish_mode\" = \"eval_after_arrow\";\n                    set -g __direnv_export_again 0;\n                else;\n                    \"" + self + "\" export fish | source;\n                end;\n            end;\n        end;\n    end;\n\n    function __direnv_export_eval_2 --on-event fish_preexec;\n        if set -q __direnv_export_again;\n            set -e __direnv_export_again;\n            \"" + self + "\" export fish | source;\n            echo;\n        end;\n\n        functions --erase __direnv_cd_hook;\n    end;\n");
                return 0;
            case "tcsh": System.out.print("alias precmd 'eval `" + self + " export tcsh`'"); return 0;
            case "elvish": System.out.print("## hook for direnv\nset @edit:before-readline = $@edit:before-readline {\n\ttry {\n\t\tvar m = [(\"" + self + "\" export elvish | from-json)]\n\t\tif (> (count $m) 0) {\n\t\t\tset m = (all $m)\n\t\t\tkeys $m | each { |k|\n\t\t\t\tif $m[$k] {\n\t\t\t\t\tset-env $k $m[$k]\n\t\t\t\t} else {\n\t\t\t\t\tunset-env $k\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\t} catch e {\n\t\techo $e\n\t}\n}\n"); return 0;
            case "pwsh": System.out.print("using namespace System;\nusing namespace System.Management.Automation;\n\n$hook = [EventHandler[LocationChangedEventArgs]] {\n  param([object] $source, [LocationChangedEventArgs] $eventArgs)\n  end {\n    $export = (" + self + " export pwsh) -join [Environment]::NewLine;\n    if ($export) { Invoke-Expression -Command $export; }\n  }\n};\n$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = $hook;\n"); return 0;
            case "murex": System.out.print("event: onPrompt direnv_hook=before {\n\t\"" + self + "\" export murex -> set exports\n\tif { $exports != \"\" } {\n\t\t$exports -> :json: formap key value {\n\t\t\tif { is-null value } then { !export \"$key\" } else { $value -> export \"$key\" }\n\t\t}\n\t}\n}"); return 0;
            case "json": case "systemd": err("this feature is not supported"); return 1;
            case "vim": err("this feature is not supported. Install the direnv.vim plugin instead"); return 1;
            case "gha": err("Hook not implemented for GitHub Actions shell"); return 1;
            case "gzenv": err("the gzenv shell doesn't support hooking"); return 1;
            default: err("unknown target shell '" + args[1] + "'"); return 1;
        }
    }

    int status(String[] args) throws IOException {
        Rc rc = findRc(Paths.get(System.getProperty("user.dir")));
        String config = configDir().toString();
        if (args.length > 1 && args[1].equals("--json")) {
            System.out.println("{");
            System.out.println("  \"config\": {");
            System.out.println("    \"ConfigDir\": " + json(config) + ",");
            System.out.println("    \"SelfPath\": " + json(selfPath()));
            System.out.println("  },");
            System.out.println("  \"state\": {");
            System.out.println("    \"foundRC\": " + (rc == null ? "null" : json(rc.path.toString())) + ",");
            System.out.println("    \"loadedRC\": null");
            System.out.println("  }");
            System.out.println("}");
        } else {
            System.out.println("direnv exec path " + selfPath());
            System.out.println("DIRENV_CONFIG " + config);
            System.out.println("bash_path /usr/bin/bash");
            System.out.println("disable_stdin false");
            System.out.println("warn_timeout 5s");
            System.out.println("whitelist.prefix []");
            System.out.println("whitelist.exact map[]");
            System.out.println("No .envrc or .env loaded");
            if (rc == null) System.out.println("No .envrc or .env found");
            else {
                System.out.println("Found RC path " + rc.path);
                System.out.println("Found watch: \"" + rc.path.getFileName() + "\" - " + Instant.ofEpochMilli(Files.getLastModifiedTime(rc.path).toMillis()).toString());
                System.out.println("Found RC allowed " + (isAllowed(rc.path) ? "0" : "-1"));
                System.out.println("Found RC allowPath " + allowPath(rc.path));
            }
        }
        return 0;
    }

    int allow(String[] args, boolean yes) throws IOException {
        Path p = resolveRcArg(args.length > 1 ? args[1] : null);
        if (p == null || !Files.exists(p)) {
            err(".envrc file not found");
            return 1;
        }
        Path target = yes ? allowPath(p) : denyPath(p);
        Files.createDirectories(target.getParent());
        Files.writeString(target, p.toString(), StandardCharsets.UTF_8);
        if (!yes) Files.deleteIfExists(allowPath(p));
        return 0;
    }

    int edit(String[] args) throws Exception {
        Path p = resolveRcArg(args.length > 1 ? args[1] : null);
        if (p == null) p = Paths.get(".envrc").toAbsolutePath().normalize();
        String ed = getenv("EDITOR", "vi");
        Process proc = new ProcessBuilder(ed, p.toString()).inheritIO().start();
        int rc = proc.waitFor();
        if (rc == 0 && Files.exists(p)) allow(new String[]{"allow", p.toString()}, true);
        return rc;
    }

    int fetchurl(String[] args) {
        err("unsupported in this cleanroom reimplementation");
        return 1;
    }

    int log(String[] args) {
        boolean error = args.length > 1 && args[1].equals("--error");
        int start = (args.length > 1 && args[1].startsWith("--")) ? 2 : 1;
        String msg = start < args.length ? String.join(" ", Arrays.copyOfRange(args, start, args.length)) : "";
        if (error) System.err.println(msg); else System.err.println("direnv: " + msg);
        return 0;
    }

    int exportCmd(String[] args) throws Exception {
        if (args.length < 2) { err("missing shell argument"); return 1; }
        String shell = args[1];
        if (!Set.of("bash","zsh","fish","tcsh","json","gha","systemd","elvish","murex","pwsh","vim","gzenv").contains(shell)) {
            err("unknown target shell '" + shell + "'");
            return 1;
        }
        Rc rc = findRc(Paths.get(System.getProperty("user.dir")));
        if (rc == null) {
            render(shell, Collections.emptyMap(), Collections.emptySet());
            return 0;
        }
        Map<String,String> values = new TreeMap<>();
        values.put("DIRENV_DIR", "-" + rc.dir);
        values.put("DIRENV_FILE", rc.path.toString());
        values.put("DIRENV_DIFF", token(rc.path + ":diff"));
        values.put("DIRENV_WATCHES", token(rc.path + ":watches"));
        if (!isAllowed(rc.path)) {
            render(shell, values, Collections.emptySet());
            err(rc.path + " is blocked. Run `direnv allow` to approve its content");
            return 1;
        }
        EvalResult eval = evaluate(rc);
        if (eval.exit != 0) return eval.exit;
        values.putAll(eval.changed);
        System.err.print("\u001b[0mdirenv: loading " + rc.path + "\n");
        if (!eval.changed.isEmpty()) System.err.print("\u001b[0mdirenv: export " + summarize(eval.changed.keySet()) + "\n");
        render(shell, values, Collections.emptySet());
        return 0;
    }

    int exec(String[] args) throws Exception {
        if (args.length < 3) { err("not enough arguments"); return 1; }
        Path dir = Paths.get(args[1]).toAbsolutePath().normalize();
        Rc rc = findRc(dir);
        Map<String,String> env = new HashMap<>(System.getenv());
        if (rc != null) {
            if (!isAllowed(rc.path)) { err(rc.path + " is blocked. Run `direnv allow` to approve its content"); return 1; }
            EvalResult er = evaluate(rc);
            if (er.exit != 0) return er.exit;
            env.putAll(er.changed);
            env.put("DIRENV_DIR", "-" + rc.dir);
            env.put("DIRENV_FILE", rc.path.toString());
        }
        ProcessBuilder pb = new ProcessBuilder(Arrays.copyOfRange(args, 2, args.length));
        pb.directory(dir.toFile());
        pb.environment().clear();
        pb.environment().putAll(env);
        pb.inheritIO();
        return pb.start().waitFor();
    }

    EvalResult evaluate(Rc rc) throws Exception {
        if (rc.path.getFileName().toString().equals(".env")) return evalDotenv(rc.path);
        String script = stdlibScript() + "\nsource " + shQuote(rc.path.toString()) + "\nenv -0\n";
        ProcessBuilder pb = new ProcessBuilder("/usr/bin/bash", "-c", script);
        pb.directory(rc.dir.toFile());
        Map<String,String> before = new HashMap<>(System.getenv());
        pb.environment().put("DIRENV_IN_ENVRC", "1");
        Process p = pb.start();
        byte[] out = p.getInputStream().readAllBytes();
        byte[] err = p.getErrorStream().readAllBytes();
        int code = p.waitFor();
        if (err.length > 0) System.err.write(err);
        Map<String,String> after = parseNulEnv(out);
        Map<String,String> changed = new TreeMap<>();
        for (Map.Entry<String,String> e : after.entrySet()) {
            String k = e.getKey();
            if (k.equals("DIRENV_IN_ENVRC") || k.equals("_") || k.equals("PWD") || k.equals("SHLVL")) continue;
            if (!Objects.equals(before.get(k), e.getValue())) changed.put(k, e.getValue());
        }
        return new EvalResult(code, changed);
    }

    EvalResult evalDotenv(Path p) throws IOException {
        Map<String,String> changed = new TreeMap<>();
        for (String line : Files.readAllLines(p)) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            if (line.startsWith("export ")) line = line.substring(7).trim();
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            String k = line.substring(0, eq).trim();
            String v = line.substring(eq + 1).trim();
            if ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))) v = v.substring(1, v.length() - 1);
            changed.put(k, v);
        }
        return new EvalResult(0, changed);
    }

    static Map<String,String> parseNulEnv(byte[] bytes) {
        Map<String,String> m = new HashMap<>();
        int start = 0;
        for (int i = 0; i <= bytes.length; i++) {
            if (i == bytes.length || bytes[i] == 0) {
                if (i > start) {
                    String s = new String(bytes, start, i - start, StandardCharsets.UTF_8);
                    int eq = s.indexOf('=');
                    if (eq > 0) m.put(s.substring(0, eq), s.substring(eq + 1));
                }
                start = i + 1;
            }
        }
        return m;
    }

    void render(String shell, Map<String,String> values, Set<String> unsets) {
        switch (shell) {
            case "bash": case "zsh":
                for (String k : unsets) System.out.print("unset " + k + ";");
                values.forEach((k,v) -> System.out.print("export " + k + "=" + bashDollar(v) + ";"));
                break;
            case "fish":
                values.forEach((k,v) -> System.out.print("set -x -g '" + k + "' '" + sq(v) + "';"));
                break;
            case "tcsh":
                values.forEach((k,v) -> System.out.print("setenv " + k + " " + v.replace(" ", "\\ ") + " ;"));
                break;
            case "json": case "elvish": case "murex":
                System.out.println("{");
                int i = 0;
                for (Map.Entry<String,String> e : values.entrySet()) {
                    System.out.print("  " + json(e.getKey()) + ": " + json(e.getValue()));
                    System.out.println(++i < values.size() ? "," : "");
                }
                System.out.println("}");
                break;
            case "systemd":
                values.forEach((k,v) -> System.out.println(k + "=" + v));
                break;
            case "gha":
                values.forEach((k,v) -> {
                    String d = "ghadelimiter_" + sha(k + v).substring(0, 32);
                    System.out.println(k + "<<" + d + "\n" + v + "\n" + d);
                });
                break;
            case "pwsh":
                values.forEach((k,v) -> System.out.println("$env:" + k + " = " + json(v)));
                break;
            default:
                break;
        }
    }

    Rc findRc(Path dir) throws IOException {
        dir = dir.toAbsolutePath().normalize();
        for (Path p = dir; p != null; p = p.getParent()) {
            Path envrc = p.resolve(".envrc");
            if (Files.isRegularFile(envrc)) return new Rc(p, envrc.toAbsolutePath().normalize());
            Path env = p.resolve(".env");
            if (Files.isRegularFile(env)) return new Rc(p, env.toAbsolutePath().normalize());
        }
        return null;
    }

    Path resolveRcArg(String arg) throws IOException {
        if (arg == null || arg.isEmpty() || arg.equals(".")) {
            Rc rc = findRc(Paths.get(System.getProperty("user.dir")));
            return rc == null ? null : rc.path;
        }
        Path p = Paths.get(arg).toAbsolutePath().normalize();
        if (Files.isDirectory(p)) {
            Path e = p.resolve(".envrc");
            if (Files.exists(e)) return e;
            e = p.resolve(".env");
            if (Files.exists(e)) return e;
            return p.resolve(".envrc");
        }
        return p;
    }

    boolean isAllowed(Path p) {
        return Files.exists(allowPath(p)) && !Files.exists(denyPath(p));
    }

    Path allowPath(Path p) { return dataDir().resolve("allow").resolve(hashRc(p)); }
    Path denyPath(Path p) { return dataDir().resolve("deny").resolve(hashRc(p)); }
    String hashRc(Path p) {
        try { return sha(p.toString() + "\n" + Files.readString(p)); }
        catch (IOException e) { return sha(p.toString()); }
    }

    Path configDir() {
        String x = System.getenv("DIRENV_CONFIG");
        if (x != null && !x.isEmpty()) return Paths.get(x);
        return Paths.get(getenv("XDG_CONFIG_HOME", getenv("HOME", "." ) + "/.config"), "direnv");
    }

    Path dataDir() {
        return Paths.get(getenv("XDG_DATA_HOME", getenv("HOME", ".") + "/.local/share"), "direnv");
    }

    static String getenv(String k, String def) {
        String v = System.getenv(k);
        return v == null || v.isEmpty() ? def : v;
    }

    String selfPath() {
        String cp = System.getProperty("sun.java.command", "");
        return Paths.get("executable").toAbsolutePath().normalize().toString();
    }

    static void err(String s) {
        System.err.println("\u001b[31mdirenv: error " + s + "\u001b[0m");
    }

    static String sha(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    static String token(String s) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(sha(s).getBytes(StandardCharsets.UTF_8));
    }

    static String summarize(Set<String> keys) {
        StringBuilder sb = new StringBuilder();
        for (String k : keys) {
            if (k.startsWith("DIRENV_")) continue;
            if (sb.length() > 0) sb.append(" ");
            sb.append("+").append(k);
        }
        return sb.toString();
    }

    static String bashDollar(String v) {
        return "$'" + v.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n") + "'";
    }

    static String sq(String v) { return v.replace("\\", "\\\\").replace("'", "\\'"); }
    static String shQuote(String v) { return "'" + v.replace("'", "'\\''") + "'"; }

    static String json(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '"': sb.append("\\\""); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 32) sb.append(String.format("\\u%04x", (int)c)); else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    static void printStdlib() {
        System.out.print("#!/usr/bin/env bash\n#\n# These are the commands available in an .envrc context\n#\n");
        System.out.print(stdlibScript());
    }

    static String stdlibScript() {
        return "direnv=\"direnv\"\n" +
            "export DIRENV_IN_ENVRC=1\n" +
            "log_status(){ echo \"direnv: $*\" >&2; }\n" +
            "log_error(){ echo \"direnv: error $*\" >&2; }\n" +
            "has(){ type \"$1\" >/dev/null 2>&1; }\n" +
            "expand_path(){ local p=\"$1\"; local r=\"${2:-$PWD}\"; [[ \"$p\" = /* ]] && realpath -m \"$p\" || realpath -m \"$r/$p\"; }\n" +
            "user_rel_path(){ case \"$1\" in \"$HOME\"/*) echo \"~/${1#$HOME/}\";; \"$HOME\") echo '~';; *) echo \"$1\";; esac; }\n" +
            "find_up(){ local n=\"${1:-.envrc}\" d=\"$PWD\"; while true; do [[ -e \"$d/$n\" ]] && { echo \"$d/$n\"; return 0; }; [[ \"$d\" = / ]] && return 1; d=\"$(dirname \"$d\")\"; done; }\n" +
            "dotenv(){ set -a; source \"${1:-.env}\"; set +a; }\n" +
            "dotenv_if_exists(){ [[ -f \"${1:-.env}\" ]] && dotenv \"${1:-.env}\" || true; }\n" +
            "source_env(){ local p=\"$1\"; [[ -d \"$p\" ]] && p=\"$p/.envrc\"; source \"$p\"; }\n" +
            "source_env_if_exists(){ [[ -f \"$1\" ]] && source \"$1\" || true; }\n" +
            "source_up(){ local f; f=$(find_up \"${1:-.envrc}\") || return 1; source \"$f\"; }\n" +
            "source_up_if_exists(){ source_up \"${1:-.envrc}\" || true; }\n" +
            "path_add(){ local var=\"$1\" p; p=$(expand_path \"$2\"); eval \"export $var=\\\"$p${!var:+:${!var}}\\\"\"; }\n" +
            "PATH_add(){ path_add PATH \"$1\"; }\n" +
            "MANPATH_add(){ path_add MANPATH \"$1\"; }\n" +
            "PATH_rm(){ local IFS=: out=() x pat keep; for x in $PATH; do keep=1; for pat in \"$@\"; do [[ \"$x\" == $pat ]] && keep=0; done; [[ $keep = 1 ]] && out+=(\"$x\"); done; PATH=\"$(IFS=:; echo \"${out[*]}\")\"; export PATH; }\n" +
            "load_prefix(){ PATH_add \"$1/bin\"; path_add CPATH \"$1/include\"; path_add LD_LIBRARY_PATH \"$1/lib\"; path_add LIBRARY_PATH \"$1/lib\"; path_add PKG_CONFIG_PATH \"$1/lib/pkgconfig\"; MANPATH_add \"$1/share/man\"; }\n" +
            "layout_python(){ :; }\nlayout_node(){ :; }\nuse(){ :; }\nwatch_file(){ :; }\nunwatch_file(){ :; }\n";
    }

    static class Rc {
        final Path dir, path;
        Rc(Path dir, Path path) { this.dir = dir; this.path = path; }
    }
    static class EvalResult {
        final int exit; final Map<String,String> changed;
        EvalResult(int exit, Map<String,String> changed) { this.exit = exit; this.changed = changed; }
    }
}
