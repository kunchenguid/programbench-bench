import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class Tailspin {
    static final String RESET = "\u001b[0m";
    static final Set<String> GROUPS = new LinkedHashSet<>(Arrays.asList(
            "numbers", "urls", "pointers", "dates", "paths", "quotes", "key-value-pairs", "uuids", "ip-addresses", "processes", "json"));

    static class Options {
        boolean follow, print, disableBuiltin;
        String configPath, exec, pager, file;
        Set<String> enabled = null;
        Set<String> disabled = new HashSet<>();
        List<Custom> custom = new ArrayList<>();
    }
    static class Custom { String color; List<String> words; Custom(String c, List<String> w){color=c;words=w;} }
    static class Span { int s,e; String code; Span(int s,int e,String c){this.s=s;this.e=e;this.code=c;} }

    public static void main(String[] args) {
        try {
            Options opt = parse(args);
            if (opt == null) return;
            if (opt.configPath != null && !Files.exists(Paths.get(opt.configPath))) {
                System.err.println("Error:   \u00d7 could not find the TOML file");
                System.exit(1);
            }
            if (opt.enabled != null && !opt.disabled.isEmpty()) {
                System.err.println("Error:   \u00d7 cannot both enable and disable highlighters");
                System.exit(1);
            }
            run(opt);
        } catch (CliError e) {
            System.err.print(e.getMessage());
            System.exit(e.status);
        } catch (IOException e) {
            System.err.println("Error:   \u26a0 " + yellow(e.getMessage()));
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error:   \u00d7 " + e.getMessage());
            System.exit(1);
        }
    }

    static void run(Options opt) throws Exception {
        if (opt.exec != null) {
            Process p = new ProcessBuilder("bash", "-lc", opt.exec).redirectErrorStream(true).start();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                stream(br, opt);
            }
            p.waitFor();
            return;
        }
        if (opt.file != null) {
            Path p = Paths.get(opt.file);
            if (!Files.exists(p)) throw new IOException(opt.file + ": No such file or directory");
            if (opt.follow) {
                long pos = 0;
                while (true) {
                    byte[] bytes = Files.readAllBytes(p);
                    if (bytes.length > pos) {
                        String s = new String(bytes, (int)pos, bytes.length - (int)pos, StandardCharsets.UTF_8);
                        System.out.print(highlightText(s, opt));
                        System.out.flush();
                        pos = bytes.length;
                    }
                    Thread.sleep(500);
                }
            } else {
                try (BufferedReader br = Files.newBufferedReader(p, StandardCharsets.UTF_8)) { stream(br, opt); }
            }
            return;
        }
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8))) { stream(br, opt); }
    }

    static void stream(BufferedReader br, Options opt) throws IOException {
        String line;
        while ((line = br.readLine()) != null) {
            System.out.print(highlightLine(line, opt));
            System.out.print(System.lineSeparator());
        }
    }

    static Options parse(String[] args) throws CliError {
        Options o = new Options();
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            if (a.equals("-h")) { printShortHelp(); return null; }
            if (a.equals("--help")) { printLongHelp(); return null; }
            if (a.equals("-V") || a.equals("--version")) { System.out.println("tspin 5.6.0"); return null; }
            if (a.equals("-f") || a.equals("--follow")) { o.follow=true; continue; }
            if (a.equals("-p") || a.equals("--print")) { o.print=true; continue; }
            if (a.equals("--disable-builtin-keywords")) { o.disableBuiltin=true; continue; }
            if (a.equals("--config-path")) { o.configPath = need(args, ++i, a); continue; }
            if (a.startsWith("--config-path=")) { o.configPath = a.substring(14); continue; }
            if (a.equals("-e") || a.equals("--exec")) { o.exec = need(args, ++i, a); continue; }
            if (a.startsWith("--exec=")) { o.exec = a.substring(7); continue; }
            if (a.equals("--pager")) { o.pager = need(args, ++i, a); continue; }
            if (a.startsWith("--pager=")) { o.pager = a.substring(8); continue; }
            if (a.equals("--highlight")) { addHighlight(o, need(args, ++i, a)); continue; }
            if (a.startsWith("--highlight=")) { addHighlight(o, a.substring(12)); continue; }
            if (a.equals("--enable")) { o.enabled = parseGroups(need(args, ++i, a), a); continue; }
            if (a.startsWith("--enable=")) { o.enabled = parseGroups(a.substring(9), "--enable"); continue; }
            if (a.equals("--disable")) { o.disabled.addAll(parseGroups(need(args, ++i, a), a)); continue; }
            if (a.startsWith("--disable=")) { o.disabled.addAll(parseGroups(a.substring(10), "--disable")); continue; }
            if (a.equals("--")) { if (i+1<args.length) o.file=args[++i]; break; }
            if (a.startsWith("-")) throw new CliError(2, "error: unexpected argument '"+a+"' found\n\n  tip: to pass '"+a+"' as a value, use '-- "+a+"'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n");
            if (o.file == null) o.file = a; else throw new CliError(2, "error: unexpected argument '"+a+"' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n");
        }
        return o;
    }
    static String need(String[] args, int i, String flag) throws CliError { if (i>=args.length) throw new CliError(2, "error: a value is required for '"+flag+" <VALUE>'\n\nFor more information, try '--help'.\n"); return args[i]; }
    static Set<String> parseGroups(String v, String flag) throws CliError {
        Set<String> out = new LinkedHashSet<>();
        for (String part : v.split(",")) {
            if (!GROUPS.contains(part)) throw new CliError(2, "error: invalid value '"+part+"' for '"+flag+" <"+(flag.contains("enable")?"ENABLED_HIGHLIGHTERS":"DISABLED_HIGHLIGHTERS")+">'\n  [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n\nFor more information, try '--help'.\n");
            out.add(part);
        }
        return out;
    }
    static void addHighlight(Options o, String v) throws CliError {
        int k = v.indexOf(':');
        String c = k < 0 ? v : v.substring(0,k);
        if (!Arrays.asList("red","green","yellow","blue","magenta","cyan").contains(c)) throw new CliError(2, "error: invalid value '"+v+"' for '--highlight <COLOR_WORD>': invalid variant: "+c+"\n\nFor more information, try '--help'.\n");
        List<String> words = new ArrayList<>();
        if (k >= 0) for (String w : v.substring(k+1).split(",")) if (!w.isEmpty()) words.add(w);
        o.custom.add(new Custom(c, words));
    }

    static boolean active(Options o, String g) { return o.enabled != null ? o.enabled.contains(g) : !o.disabled.contains(g); }
    static String highlightText(String text, Options opt) { StringBuilder sb = new StringBuilder(); for (String l : text.split("(?<=\n)", -1)) { if (l.endsWith("\n")) sb.append(highlightLine(l.substring(0,l.length()-1), opt)).append('\n'); else sb.append(highlightLine(l,opt)); } return sb.toString(); }
    static String highlightLine(String line, Options opt) {
        List<Span> spans = new ArrayList<>();
        for (Custom c : opt.custom) for (String w : c.words) addLiteral(spans, line, w, ansi(c.color));
        if (!opt.disableBuiltin) {
            addRegex(spans,line,"\\b(ERROR|ERR|FAIL|FAILED|FAILURE|SEVERE)\\b","31");
            addRegex(spans,line,"\\b(WARN|WARNING)\\b","33");
            addRegex(spans,line,"\\b(INFO|NOTICE)\\b","37");
            addRegex(spans,line,"\\b(DEBUG|SUCCESS|OK)\\b","32");
            addRegex(spans,line,"\\b(TRACE)\\b","2");
            addRegex(spans,line,"\\b(true|false|null)\\b","3;31");
            addRegex(spans,line,"\\b(GET)\\b","42;30");
            addRegex(spans,line,"\\b(POST)\\b","43;30");
            addRegex(spans,line,"\\b(PUT|PATCH)\\b","45;30");
            addRegex(spans,line,"\\b(DELETE)\\b","41;30");
        }
        if (active(opt,"urls")) addRegex(spans,line,"\\bhttps?://[^\\s\"'<>]+","2;34");
        if (active(opt,"uuids")) addRegex(spans,line,"\\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\\b","3;34");
        if (active(opt,"ip-addresses")) addRegex(spans,line,"\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b","3;34");
        if (active(opt,"dates")) {
            addRegex(spans,line,"\\b\\d{4}-\\d{2}-\\d{2}(?:[ T]\\d{2}:\\d{2}:\\d{2}(?:[,.]\\d+)?)?\\b","35");
            addRegex(spans,line,"\\b\\d{2}:\\d{2}:\\d{2}(?:[,.]\\d+)?\\b","34");
        }
        if (active(opt,"paths")) addRegex(spans,line,"(?<![A-Za-z0-9])(?:/[A-Za-z0-9._@%+,-]+)+/?|[A-Za-z]:\\\\(?:[^\\s:]+\\\\?)+","34");
        if (active(opt,"quotes")) addRegex(spans,line,"\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'","32");
        if (active(opt,"key-value-pairs")) addRegex(spans,line,"\\b[A-Za-z_][A-Za-z0-9_.-]*=([^\\s,]+)","36");
        if (active(opt,"processes")) addRegex(spans,line,"\\[[^\\]]+\\]","36");
        if (active(opt,"json")) addRegex(spans,line,"[{}\\[\\]:,]","2");
        if (active(opt,"pointers")) addRegex(spans,line,"0x[0-9a-fA-F]+","35");
        if (active(opt,"numbers")) addRegex(spans,line,"(?<![A-Za-z])[-+]?\\b\\d+(?:\\.\\d+)?\\b","36");
        return render(line, spans);
    }
    static void addLiteral(List<Span> spans, String line, String w, String code) { int p=0; while(!w.isEmpty() && (p=line.indexOf(w,p))>=0){ addSpan(spans,new Span(p,p+w.length(),code)); p+=w.length(); } }
    static void addRegex(List<Span> spans, String line, String re, String code) { Matcher m=Pattern.compile(re).matcher(line); while(m.find()) addSpan(spans,new Span(m.start(),m.end(),code)); }
    static void addSpan(List<Span> spans, Span n) { if(n.s>=n.e) return; for(Span s:spans) if(n.s<s.e && n.e>s.s) return; spans.add(n); }
    static String render(String line, List<Span> spans) { spans.sort(Comparator.comparingInt(a->a.s)); StringBuilder sb=new StringBuilder(); int p=0; for(Span s:spans){ if(s.s<p) continue; sb.append(line, p, s.s).append("\u001b[").append(s.code).append('m').append(line, s.s, s.e).append(RESET); p=s.e; } sb.append(line.substring(p)); return sb.toString(); }
    static String ansi(String c) { switch(c){case "red":return "31";case "green":return "32";case "yellow":return "33";case "blue":return "34";case "magenta":return "35";case "cyan":return "36";} return "37"; }
    static String yellow(String s){ return "\u001b[33m"+s+RESET; }

    static void printShortHelp(){ System.out.print("A log file highlighter\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]  Filepath\n\nOptions:\n  -f, --follow\n          Follow the contents of a file\n  -p, --print\n          Print the output to stdout\n      --config-path <CONFIG_PATH>\n          Provide a custom path to a configuration file\n  -e, --exec <EXEC>\n          Run command and view the output in a pager\n      --highlight <COLOR_WORD>\n          Highlights in the form color:word1,word2\n      --enable <ENABLED_HIGHLIGHTERS>\n          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,\n          quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n      --disable <DISABLED_HIGHLIGHTERS>\n          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,\n          quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n      --disable-builtin-keywords\n          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities\n          and common REST verbs)\n      --pager <PAGER>\n          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`) [env:\n          TAILSPIN_PAGER=]\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n"); }
    static void printLongHelp(){ System.out.print("A log file highlighter\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]\n          Filepath\n\nOptions:\n  -f, --follow\n          Follow the contents of a file\n\n  -p, --print\n          Print the output to stdout\n\n      --config-path <CONFIG_PATH>\n          Provide a custom path to a configuration file\n\n  -e, --exec <EXEC>\n          Run command and view the output in a pager\n\n      --highlight <COLOR_WORD>\n          Highlights in the form color:word1,word2\n          \n          [possible values: red, green, yellow, blue, magenta, cyan]\n\n      --enable <ENABLED_HIGHLIGHTERS>\n          Enable specific highlighters\n          \n          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,\n          ip-addresses, processes, json]\n\n      --disable <DISABLED_HIGHLIGHTERS>\n          Disable specific highlighters\n          \n          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,\n          ip-addresses, processes, json]\n\n      --disable-builtin-keywords\n          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities\n          and common REST verbs)\n\n      --pager <PAGER>\n          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`)\n          \n          [env: TAILSPIN_PAGER=]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n"); }
    static class CliError extends Exception { int status; CliError(int s, String m){super(m);status=s;} }
}
