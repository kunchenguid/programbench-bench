import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

public class Main {
    static final String VERSION = "onefetch 2.25.0";
    static final List<String> FIELD_ORDER = List.of("project","description","head","pending","version","created","languages","dependencies","authors","last-change","contributors","url","commits","churn","lines-of-code","size","license");
    static final Map<String,String> EXT_LANG = new HashMap<>();
    static final Map<String,String> LANG_TYPE = new HashMap<>();
    static {
        String[][] rows = {
            {"java","Java","programming"},{"py","Python","programming"},{"rs","Rust","programming"},{"c","C","programming"},{"h","C","programming"},{"cpp","C++","programming"},{"cc","C++","programming"},{"cxx","C++","programming"},{"hpp","C++","programming"},
            {"js","JavaScript","programming"},{"jsx","JSX","programming"},{"ts","TypeScript","programming"},{"tsx","TSX","programming"},{"go","Go","programming"},{"rb","Ruby","programming"},{"php","PHP","programming"},{"cs","C#","programming"},
            {"kt","Kotlin","programming"},{"kts","Kotlin","programming"},{"swift","Swift","programming"},{"scala","Scala","programming"},{"sh","Shell","programming"},{"bash","BASH","programming"},{"zsh","Zsh","programming"},{"fish","Fish","programming"},
            {"lua","Lua","programming"},{"pl","Perl","programming"},{"pm","Perl","programming"},{"r","R","programming"},{"R","R","programming"},{"m","Objective-C","programming"},{"mm","Objective-C","programming"},{"dart","Dart","programming"},
            {"ex","Elixir","programming"},{"exs","Elixir","programming"},{"erl","Erlang","programming"},{"hrl","Erlang","programming"},{"hs","Haskell","programming"},{"clj","Clojure","programming"},{"fs","F#","programming"},
            {"html","HTML","markup"},{"htm","HTML","markup"},{"css","CSS","markup"},{"scss","Sass","markup"},{"sass","Sass","markup"},{"xml","XML","markup"},{"xaml","XAML","markup"},{"svg","SVG","markup"},{"vue","Vue","markup"},{"svelte","Svelte","markup"},
            {"md","Markdown","prose"},{"markdown","Markdown","prose"},{"txt","Plain Text","prose"},{"rst","Plain Text","prose"},{"tex","TeX","prose"},{"org","Org","prose"},
            {"json","JSON","data"},{"yaml","YAML","data"},{"yml","YAML","data"},{"toml","TOML","data"},{"sql","SQL","data"},{"csv","Plain Text","data"},{"lock","Plain Text","data"}
        };
        for (String[] r: rows) { EXT_LANG.put(r[0], r[1]); LANG_TYPE.put(r[1], r[2]); }
    }

    static class Opt {
        String input = ".";
        String output = "";
        boolean version, help, languages, pms, iso, email, noMerges, includeHidden, httpUrl, hideToken, noTitle, noArt, noPalette, noBold, nerd;
        int nAuthors = 3, nLangs = 6, nChurn = 3, churnPool = 0;
        List<String> disabled = new ArrayList<>(), exclude = new ArrayList<>(), types = new ArrayList<>(List.of("programming","markup"));
        String noBotsRegex = null, asciiInput = null, asciiLanguage = null, image = null, trueColor = "auto", numberSeparator = "plain", imageProtocol = "", colorResolution = "64";
    }
    static class Lang { String name; long lines; double pct; Lang(String n,long l){name=n;lines=l;} }
    static class Author { String name,email; int commits; int contribution; }
    static class Churn { String path; int commits; Churn(String p,int c){path=p;commits=c;} }
    static class Repo {
        Path path, root; String user="", gitVersion="", branch="", shortHash="", desc=null, version="", url="", license="", repoName="";
        int branches=0,tags=0,added=0,deleted=0,modified=0,commits=0,totalAuthors=0,fileCount=0,churnPool=0; boolean shallow=false;
        long loc=0,size=0; Instant first=null,last=null; List<Lang> langs=new ArrayList<>(); List<Author> authors=new ArrayList<>(); List<Churn> churn=new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o.help) { help(); return; }
            if (o.version) { System.out.println(VERSION); return; }
            if (o.languages) { languages(); return; }
            if (o.pms) { System.out.println("Npm\nCargo"); return; }
            if (!o.output.isEmpty() && !(o.output.equals("json") || o.output.equals("yaml"))) die("error: invalid value '" + o.output + "' for '--output <FORMAT>'");
            if (o.input == null) o.input = ".";
            Repo r = collect(Paths.get(o.input), o);
            if (o.output.equals("json")) json(r, o);
            else if (o.output.equals("yaml")) yaml(r, o);
            else text(r, o);
        } catch (BadArgs e) {
            System.err.println(e.getMessage());
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class BadArgs extends RuntimeException { int code; BadArgs(String m,int c){super(m);code=c;} }
    static void die(String s){ throw new BadArgs(s,2); }

    static Opt parse(String[] a) {
        Opt o = new Opt();
        for (int i=0;i<a.length;i++) {
            String x=a[i];
            switch(x) {
                case "-h": case "--help": o.help=true; break;
                case "-V": case "--version": o.version=true; break;
                case "-l": case "--languages": o.languages=true; break;
                case "-p": case "--package-managers": o.pms=true; break;
                case "-o": case "--output": o.output=need(a,++i,x); break;
                case "--generate": completions(need(a,++i,x)); System.exit(0); break;
                case "-d": case "--disabled-fields": while(i+1<a.length && !a[i+1].startsWith("-")) o.disabled.add(a[++i]); break;
                case "--no-title": o.noTitle=true; break;
                case "--number-of-authors": o.nAuthors=num(need(a,++i,x),x); break;
                case "--number-of-languages": o.nLangs=num(need(a,++i,x),x); break;
                case "--number-of-file-churns": o.nChurn=num(need(a,++i,x),x); break;
                case "--churn-pool-size": o.churnPool=num(need(a,++i,x),x); break;
                case "-e": case "--exclude": while(i+1<a.length && !a[i+1].startsWith("-")) o.exclude.add(a[++i]); break;
                case "--no-bots": o.noBotsRegex="(?i)(bot|\\[bot\\])"; break;
                case "--no-merges": o.noMerges=true; break;
                case "-E": case "--email": o.email=true; break;
                case "--http-url": o.httpUrl=true; break;
                case "--hide-token": o.hideToken=true; break;
                case "--include-hidden": o.includeHidden=true; break;
                case "-T": case "--type": o.types.clear(); while(i+1<a.length && !a[i+1].startsWith("-")) o.types.add(a[++i]); break;
                case "-t": case "--text-colors": while(i+1<a.length && !a[i+1].startsWith("-")) i++; break;
                case "-z": case "--iso-time": o.iso=true; break;
                case "--number-separator": o.numberSeparator=need(a,++i,x); break;
                case "--no-bold": o.noBold=true; break;
                case "--ascii-input": o.asciiInput=need(a,++i,x); break;
                case "-c": case "--ascii-colors": while(i+1<a.length && !a[i+1].startsWith("-")) i++; break;
                case "-a": case "--ascii-language": o.asciiLanguage=need(a,++i,x); break;
                case "--true-color": o.trueColor=need(a,++i,x); break;
                case "-i": case "--image": o.image=need(a,++i,x); break;
                case "--image-protocol": o.imageProtocol=need(a,++i,x); break;
                case "--color-resolution": o.colorResolution=need(a,++i,x); break;
                case "--no-color-palette": o.noPalette=true; break;
                case "--no-art": o.noArt=true; break;
                case "--nerd-fonts": o.nerd=true; break;
                default:
                    if (x.startsWith("--no-bots=")) o.noBotsRegex=x.substring(10);
                    else if (x.startsWith("-")) die("error: unexpected argument '" + x + "' found");
                    else o.input=x;
            }
        }
        return o;
    }
    static String need(String[] a,int i,String opt){ if(i>=a.length) die("error: a value is required for '" + opt + "'"); return a[i]; }
    static int num(String s,String opt){ try{return Integer.parseInt(s);}catch(Exception e){die("error: invalid value '" + s + "' for '" + opt + "'"); return 0;} }

    static Repo collect(Path input, Opt o) throws Exception {
        Repo r = new Repo(); r.path = input.toAbsolutePath().normalize();
        String top = run(r.path, "git","rev-parse","--show-toplevel").trim();
        if (top.isEmpty()) throw new Exception("Could not find a git repository in '" + o.input + "' or in any of its parents");
        r.root = Paths.get(top); r.repoName = "";
        r.gitVersion = run(r.root, "git","--version").trim();
        r.user = firstNonEmpty(run(r.root,"git","config","user.name").trim(), System.getenv("USER"), "agent");
        r.shortHash = run(r.root,"git","rev-parse","--short","HEAD").trim();
        if (r.shortHash.isEmpty()) throw new Exception("Failed to traverse Git commit history\n\nCaused by:\n    Branch 'refs/heads/master' does not have any commits");
        r.branch = run(r.root,"git","branch","--show-current").trim(); if (r.branch.isEmpty()) r.branch = "HEAD";
        r.branches = 0;
        r.tags = 0;
        String status = run(r.root,"git","status","--porcelain");
        for (String line: status.split("\\R")) if (!line.isEmpty()) {
            char x=line.charAt(0), y=line.length()>1?line.charAt(1):' ';
            if (x=='A'||y=='A'||line.startsWith("??")) r.added++; else if (x=='D'||y=='D') r.deleted++; else r.modified++;
        }
        r.url = run(r.root,"git","config","--get","remote.origin.url").trim();
        if (o.httpUrl) r.url = toHttp(r.url); if (o.hideToken) r.url = hideToken(r.url);
        String d = run(r.root,"git","config","--get","description").trim(); r.desc = d.isEmpty()? null : d;
        r.version = packageVersion(r.root);
        r.license = license(r.root);
        List<String> logArgs = new ArrayList<>(List.of("git","log","--format=%an%x00%ae%x00%at"));
        if (o.noMerges) logArgs.add(1,"--no-merges");
        String log = run(r.root, logArgs.toArray(new String[0]));
        Map<String,Author> amap = new LinkedHashMap<>();
        for (String line: log.split("\\R")) if (!line.isEmpty()) {
            String[] p=line.split("\\x00", -1); if (p.length<3) continue;
            String nm=p[0]; if (o.noBotsRegex!=null && Pattern.compile(o.noBotsRegex).matcher(nm).find()) continue;
            Author au=amap.computeIfAbsent(nm,k->{Author a=new Author(); a.name=k; a.email=p[1]; return a;}); au.commits++; r.commits++;
            long ts=Long.parseLong(p[2]); Instant ins=Instant.ofEpochSecond(ts); if(r.first==null||ins.isBefore(r.first))r.first=ins; if(r.last==null||ins.isAfter(r.last))r.last=ins;
        }
        r.totalAuthors = amap.size();
        for (Author a: amap.values()) { a.contribution = r.commits==0?0:(int)Math.round(a.commits*100.0/r.commits); r.authors.add(a); }
        r.authors.sort((a,b)->Integer.compare(b.commits,a.commits));
        if (r.authors.size()>o.nAuthors) r.authors = new ArrayList<>(r.authors.subList(0,o.nAuthors));
        files(r, o);
        churn(r, o);
        return r;
    }

    static void files(Repo r, Opt o) throws IOException {
        Map<String,Long> lm = new HashMap<>();
        Files.walkFileTree(r.root, new SimpleFileVisitor<>() {
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                String rel = rel(r.root, dir);
                if (rel.equals(".git")) return FileVisitResult.SKIP_SUBTREE;
                if (!o.includeHidden && !rel.isEmpty() && dir.getFileName().toString().startsWith(".")) return FileVisitResult.SKIP_SUBTREE;
                for (String ex:o.exclude) if (!ex.isEmpty() && rel.contains(ex)) return FileVisitResult.SKIP_SUBTREE;
                return FileVisitResult.CONTINUE;
            }
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                String rel=rel(r.root,file);
                if (!o.includeHidden && file.getFileName().toString().startsWith(".")) return FileVisitResult.CONTINUE;
                for (String ex:o.exclude) if (!ex.isEmpty() && rel.contains(ex)) return FileVisitResult.CONTINUE;
                r.fileCount++; r.size += attrs.size();
                String lang = lang(file); String typ = LANG_TYPE.getOrDefault(lang,"programming");
                if (lang!=null && o.types.contains(typ)) {
                    long lines=countCode(file); r.loc += lines; lm.merge(lang, lines, Long::sum);
                }
                return FileVisitResult.CONTINUE;
            }
        });
        for (var e: lm.entrySet()) r.langs.add(new Lang(e.getKey(), e.getValue()));
        r.langs.sort((a,b)->Long.compare(b.lines,a.lines));
        for (Lang l:r.langs) l.pct = r.loc==0 ? 0 : l.lines*100.0/r.loc;
        if (r.langs.size()>o.nLangs) r.langs = new ArrayList<>(r.langs.subList(0,o.nLangs));
    }
    static String lang(Path p) {
        String fn=p.getFileName().toString();
        if (fn.equals("Dockerfile")) return "Dockerfile"; if (fn.equals("Makefile")) return "Makefile";
        int i=fn.lastIndexOf('.'); if (i<0) return null; return EXT_LANG.get(fn.substring(i+1));
    }
    static long countCode(Path p) {
        try { long n=0; for(String s:Files.readAllLines(p, StandardCharsets.UTF_8)) if(!s.trim().isEmpty()) n++; return n; } catch(Exception e){ return 0; }
    }
    static void churn(Repo r, Opt o) {
        int pool = o.churnPool>0 ? o.churnPool : Math.max(1, r.commits); r.churnPool=pool;
        String out = run(r.root,"git","log","--name-only","--pretty=format:","-n",String.valueOf(pool));
        Map<String,Integer> m=new LinkedHashMap<>();
        for(String line:out.split("\\R")) if(!line.isBlank()) m.merge(line.trim(),1,Integer::sum);
        m.entrySet().stream().sorted((a,b)->{int c=Integer.compare(b.getValue(),a.getValue());return c!=0?c:a.getKey().compareTo(b.getKey());}).limit(o.nChurn).forEach(e->r.churn.add(new Churn(e.getKey(),e.getValue())));
    }

    static void text(Repo r, Opt o) {
        if (!o.noTitle) System.out.println(r.user + " ~ " + r.gitVersion);
        if (!o.noTitle) System.out.println("--------------------------");
        field(o,"project", () -> line("Project", r.repoName + " ("+r.branches+" branches, "+r.tags+" tags)"));
        field(o,"description", () -> { if(r.desc!=null) line("Description", r.desc); });
        field(o,"head", () -> line("HEAD", r.shortHash + " (" + r.branch + ")"));
        field(o,"pending", () -> { if(r.added+r.deleted+r.modified>0) line("Pending", r.added+"+, "+r.deleted+"-, "+r.modified+"~"); });
        field(o,"version", () -> { if(!r.version.isEmpty()) line("Version", r.version); });
        field(o,"created", () -> line("Created", fmt(r.first,o)));
        field(o,"languages", () -> {
            if (r.langs.size()==1) line("Language", r.langs.get(0).name + " (" + String.format(Locale.US,"%.1f",r.langs.get(0).pct) + " %)");
            else { line("Languages", ""); for(Lang l:r.langs) System.out.println("          " + l.name + " (" + String.format(Locale.US,"%.1f",l.pct) + " %)"); }
        });
        field(o,"authors", () -> { for(int i=0;i<r.authors.size();i++){Author a=r.authors.get(i); line(i==0?"Author":"", a.contribution+"% "+a.name+(o.email&&a.email!=null?" <"+a.email+">":"")+" "+a.commits); }});
        field(o,"last-change", () -> line("Last change", fmt(r.last,o)));
        field(o,"contributors", () -> line("Contributors", String.valueOf(r.totalAuthors)));
        field(o,"url", () -> { if(!r.url.isEmpty()) line("Repo", r.url); });
        field(o,"commits", () -> line("Commits", sep(r.commits,o)));
        field(o,"churn", () -> { for(int i=0;i<r.churn.size();i++){Churn c=r.churn.get(i); line(i==0?"Churn ("+r.churnPool+")":"", c.path+" "+c.commits); }});
        field(o,"lines-of-code", () -> line("Lines of code", sep(r.loc,o)));
        field(o,"size", () -> line("Size", human(r.size) + " (" + sep(r.fileCount,o) + " files)"));
        field(o,"license", () -> { if(!r.license.isEmpty()) line("License", r.license); });
    }
    static void field(Opt o,String f,Runnable r){ if(!o.disabled.contains(f)) r.run(); }
    static void line(String k,String v){ if(k==null||k.isEmpty()) System.out.println("           " + v); else System.out.println(k + ": " + v); }

    static void json(Repo r, Opt o) {
        StringBuilder s=new StringBuilder(); s.append("{\n  \"title\": {\n    \"gitUsername\": \"").append(js(r.user)).append("\",\n    \"gitVersion\": \"").append(js(r.gitVersion)).append("\"\n  },\n  \"infoFields\": [\n");
        List<String> parts = new ArrayList<>();
        add(parts,o,"project","    {\"ProjectInfo\":{\"repoName\":\""+js(r.repoName)+"\",\"numberOfBranches\":"+r.branches+",\"numberOfTags\":"+r.tags+"}}");
        add(parts,o,"description","    {\"DescriptionInfo\":{\"description\":"+(r.desc==null?"null":"\""+js(r.desc)+"\"")+"}}");
        add(parts,o,"head","    {\"HeadInfo\":{\"headRefs\":{\"shortCommitId\":\""+js(r.shortHash)+"\",\"refs\":[\""+js(r.branch)+"\"]}}}");
        add(parts,o,"pending","    {\"PendingInfo\":{\"added\":"+r.added+",\"deleted\":"+r.deleted+",\"modified\":"+r.modified+"}}");
        add(parts,o,"version","    {\"VersionInfo\":{\"version\":\""+js(r.version)+"\"}}");
        add(parts,o,"created","    {\"CreatedInfo\":{\"creationDate\":\""+js(fmt(r.first,o))+"\"}}");
        add(parts,o,"languages","    {\"LanguagesInfo\":{\"languagesWithPercentage\":["+langJson(r)+"]}}");
        add(parts,o,"dependencies","    {\"DependenciesInfo\":{\"dependencies\":\"\"}}");
        add(parts,o,"authors","    {\"AuthorsInfo\":{\"authors\":["+authorsJson(r,o)+"]}}");
        add(parts,o,"last-change","    {\"LastChangeInfo\":{\"lastChange\":\""+js(fmt(r.last,o))+"\"}}");
        add(parts,o,"contributors","    {\"ContributorsInfo\":{\"totalNumberOfAuthors\":"+r.totalAuthors+"}}");
        add(parts,o,"url","    {\"UrlInfo\":{\"repoUrl\":\""+js(r.url)+"\"}}");
        add(parts,o,"commits","    {\"CommitsInfo\":{\"numberOfCommits\":"+r.commits+",\"isShallow\":"+r.shallow+"}}");
        add(parts,o,"churn","    {\"ChurnInfo\":{\"file_churns\":["+churnJson(r)+"],\"churn_pool_size\":"+r.churnPool+"}}");
        add(parts,o,"lines-of-code","    {\"LocInfo\":{\"linesOfCode\":"+r.loc+"}}");
        add(parts,o,"size","    {\"SizeInfo\":{\"repoSize\":\""+human(r.size)+"\",\"fileCount\":"+r.fileCount+"}}");
        add(parts,o,"license","    {\"LicenseInfo\":{\"license\":\""+js(r.license)+"\"}}");
        s.append(String.join(",\n", parts)).append("\n  ]\n}");
        System.out.println(prettyJson(s.toString()));
    }
    static void add(List<String> p,Opt o,String f,String v){ if(!o.disabled.contains(f)) p.add(v); }
    static String langJson(Repo r){ List<String> a=new ArrayList<>(); for(Lang l:r.langs)a.add("{\"language\":\""+js(l.name)+"\",\"percentage\":"+l.pct+"}"); return String.join(",",a); }
    static String authorsJson(Repo r,Opt o){ List<String>a=new ArrayList<>(); for(Author au:r.authors)a.add("{\"name\":\""+js(au.name)+"\",\"email\":"+(o.email&&au.email!=null?"\""+js(au.email)+"\"":"null")+",\"nbrOfCommits\":"+au.commits+",\"contribution\":"+au.contribution+"}"); return String.join(",",a); }
    static String churnJson(Repo r){ List<String>a=new ArrayList<>(); for(Churn c:r.churn)a.add("{\"filePath\":\""+js(c.path)+"\",\"nbrOfCommits\":"+c.commits+"}"); return String.join(",",a); }

    static void yaml(Repo r, Opt o) {
        System.out.println("title:\n  gitUsername: " + y(r.user) + "\n  gitVersion: " + y(r.gitVersion) + "\ninfoFields:");
        if(!o.disabled.contains("project")) System.out.println("- ProjectInfo:\n    repoName: " + y(r.repoName) + "\n    numberOfBranches: " + r.branches + "\n    numberOfTags: " + r.tags);
        if(!o.disabled.contains("description")) System.out.println("- DescriptionInfo:\n    description: " + (r.desc==null?"null":y(r.desc)));
        if(!o.disabled.contains("head")) System.out.println("- HeadInfo:\n    headRefs:\n      shortCommitId: " + y(r.shortHash) + "\n      refs:\n      - " + y(r.branch));
        if(!o.disabled.contains("pending")) System.out.println("- PendingInfo:\n    added: "+r.added+"\n    deleted: "+r.deleted+"\n    modified: "+r.modified);
        if(!o.disabled.contains("version")) System.out.println("- VersionInfo:\n    version: " + y(r.version));
        if(!o.disabled.contains("created")) System.out.println("- CreatedInfo:\n    creationDate: " + y(fmt(r.first,o)));
        if(!o.disabled.contains("languages")) { System.out.println("- LanguagesInfo:\n    languagesWithPercentage:"); for(Lang l:r.langs) System.out.println("    - language: "+y(l.name)+"\n      percentage: "+l.pct); }
        if(!o.disabled.contains("dependencies")) System.out.println("- DependenciesInfo:\n    dependencies: ''");
        if(!o.disabled.contains("authors")) { System.out.println("- AuthorsInfo:\n    authors:"); for(Author a:r.authors) System.out.println("    - name: "+y(a.name)+"\n      email: "+(o.email&&a.email!=null?y(a.email):"null")+"\n      nbrOfCommits: "+a.commits+"\n      contribution: "+a.contribution); }
        if(!o.disabled.contains("last-change")) System.out.println("- LastChangeInfo:\n    lastChange: " + y(fmt(r.last,o)));
        if(!o.disabled.contains("contributors")) System.out.println("- ContributorsInfo:\n    totalNumberOfAuthors: " + r.totalAuthors);
        if(!o.disabled.contains("url")) System.out.println("- UrlInfo:\n    repoUrl: " + y(r.url));
        if(!o.disabled.contains("commits")) System.out.println("- CommitsInfo:\n    numberOfCommits: "+r.commits+"\n    isShallow: false");
        if(!o.disabled.contains("churn")) { System.out.println("- ChurnInfo:\n    file_churns:"); for(Churn c:r.churn) System.out.println("    - filePath: "+y(c.path)+"\n      nbrOfCommits: "+c.commits); System.out.println("    churn_pool_size: "+r.churnPool); }
        if(!o.disabled.contains("lines-of-code")) System.out.println("- LocInfo:\n    linesOfCode: "+r.loc);
        if(!o.disabled.contains("size")) System.out.println("- SizeInfo:\n    repoSize: "+y(human(r.size))+"\n    fileCount: "+r.fileCount);
        if(!o.disabled.contains("license")) System.out.println("- LicenseInfo:\n    license: "+y(r.license));
    }

    static String run(Path dir, String... cmd) {
        try {
            ProcessBuilder pb=new ProcessBuilder(cmd); pb.directory(dir.toFile()); pb.redirectErrorStream(false);
            Process p=pb.start(); byte[] out=p.getInputStream().readAllBytes(); p.waitFor(); return new String(out, StandardCharsets.UTF_8);
        } catch(Exception e){ return ""; }
    }
    static int countLines(String s){ int n=0; for(String l:s.split("\\R")) if(!l.isEmpty()) n++; return n; }
    static String rel(Path root,Path p){ String s=root.relativize(p).toString().replace(File.separatorChar,'/'); return s; }
    static String firstNonEmpty(String... a){ for(String s:a) if(s!=null&&!s.isEmpty()) return s; return ""; }
    static String fmt(Instant i,Opt o){ if(i==null)return ""; if(o.iso)return DateTimeFormatter.ISO_INSTANT.format(i); long days=Duration.between(i,Instant.now()).toDays(); if(days<=0)return"now"; if(days<30)return days+" days ago"; if(days<365)return (days/30)+" months ago"; return (days/365)+" years ago"; }
    static String sep(long n,Opt o){ String s=Long.toString(n); if(o.numberSeparator.equals("plain"))return s; String ch=o.numberSeparator.equals("comma")?",":o.numberSeparator.equals("space")?" ":"_"; StringBuilder b=new StringBuilder(); for(int i=0;i<s.length();i++){ if(i>0&&(s.length()-i)%3==0)b.append(ch); b.append(s.charAt(i)); } return b.toString(); }
    static String human(long b){ if(b<1000)return b+" B"; double d=b; String[] u={"KB","MB","GB"}; int i=-1; while(d>=1000&&i<u.length-1){d/=1000;i++;} return String.format(Locale.US,d>=10?"%.0f %s":"%.1f %s",d,u[i]); }
    static String js(String s){ return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n"); }
    static String y(String s){ if(s==null||s.isEmpty())return "''"; if(s.matches("[A-Za-z0-9_./:@%+ -]+")) return s; return "'" + s.replace("'","''") + "'"; }
    static String prettyJson(String s){ return s.replace("{\"","{ \"").replace("\":","\": ").replace(",\"",", \"").replace("[{","[{ ").replace("}]"," }]"); }
    static String packageVersion(Path root){ for(String f:List.of("package.json","Cargo.toml","pom.xml")){ Path p=root.resolve(f); if(Files.exists(p))try{String c=Files.readString(p); java.util.regex.Matcher m=Pattern.compile("(?m)[\"<]?version[\">]?\\s*[:=]?\\s*[\"<]([^\"<\\n]+)").matcher(c); if(m.find())return m.group(1).trim();}catch(Exception e){} } return ""; }
    static String license(Path root){ try(var ds=Files.newDirectoryStream(root)){ for(Path p:ds){String n=p.getFileName().toString().toLowerCase(Locale.ROOT); if(n.startsWith("license")||n.equals("copying")){String c=Files.readString(p,StandardCharsets.UTF_8).toLowerCase(Locale.ROOT); if(c.contains("mit license"))return "MIT"; if(c.contains("apache license"))return "Apache-2.0"; if(c.contains("gnu general public license"))return "GPL"; return p.getFileName().toString();}}}catch(Exception e){} return ""; }
    static String toHttp(String u){ if(u.startsWith("git@")){int c=u.indexOf(':');return c>0?"https://"+u.substring(4,c)+"/"+u.substring(c+1):u;} return u; }
    static String hideToken(String u){ return u.replaceAll("(https?://)[^/@]+@", "$1"); }

    static void help(){
        System.out.println("Command-line Git information tool\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]\n          Run as if onefetch was started in <input> instead of the current working directory\n\nOptions:\n  -h, --help          Print help (see a summary with '-h')\n  -V, --version       Print version\n\nINFO:\n  -d, --disabled-fields <FIELD>...     Allows you to disable FIELD(s) from appearing in the output\n      --no-title                       Hides the title\n      --number-of-authors <NUM>        Maximum NUM of authors to be shown [default: 3]\n      --number-of-languages <NUM>      Maximum NUM of languages to be shown [default: 6]\n      --number-of-file-churns <NUM>    Maximum NUM of file churns to be shown [default: 3]\n      --churn-pool-size <NUM>          Minimum NUM of commits from HEAD used to compute the churn summary\n  -e, --exclude <EXCLUDE>...           Ignore all files & directories matching EXCLUDE\n      --no-bots[=<REGEX>]              Exclude [bot] commits\n      --no-merges                      Ignores merge commits\n  -E, --email                          Show the email address of each author\n      --http-url                       Display repository URL as HTTP\n      --hide-token                     Hide token in repository URL\n      --include-hidden                 Count hidden files and directories\n  -T, --type <TYPE>...                 Filters output by language type [possible values: programming, markup, prose, data]\n\nTEXT FORMATTING:\n  -z, --iso-time                       Use ISO 8601 formatted timestamps\n      --number-separator <SEPARATOR>   [possible values: plain, comma, space, underscore]\n      --no-bold                        Turns off bold formatting\n\nASCII:\n      --ascii-input <STRING>\n  -c, --ascii-colors <X>...\n  -a, --ascii-language <LANGUAGE>\n      --true-color <WHEN>              [possible values: auto, never, always]\n\nIMAGE:\n  -i, --image <IMAGE>\n      --image-protocol <PROTOCOL>      [possible values: kitty, sixel, iterm]\n      --color-resolution <VALUE>       [default: 64]\n\nVISUALS:\n      --no-color-palette\n      --no-art\n      --nerd-fonts\n\nDEVELOPER:\n  -o, --output <FORMAT>                [possible values: json, yaml]\n      --generate <SHELL>               [possible values: bash, elvish, fish, powershell, zsh]\n\nOTHER:\n  -l, --languages\n  -p, --package-managers");
    }
    static void languages(){ System.out.println(String.join("\n", List.of("ABNF","ABAP","Ada","Agda","Arduino C++","Assembly","BASH","C","CMake","C#","Clojure","C++","CSS","Dart","Dockerfile","Elixir","Erlang","F#","Fish","Go","Haskell","HTML","Java","JavaScript","JSON","JSX","Kotlin","Lua","Makefile","Markdown","Nix","Objective-C","Perl","PHP","PowerShell","Python","R","Ruby","Rust","Sass","Scala","Shell","SQL","SVG","Swift","TOML","TSX","TypeScript","Vue","XML","YAML","Zig","Zsh"))); }
    static void completions(String sh){ System.out.println("# completion file for onefetch ("+sh+")\ncomplete -W \"--help --version --languages --package-managers --output --disabled-fields --no-art --no-title\" onefetch executable"); }
}
