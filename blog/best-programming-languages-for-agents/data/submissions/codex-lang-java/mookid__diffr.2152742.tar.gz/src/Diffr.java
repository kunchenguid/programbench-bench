import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Diffr {
    private static final String RESET = "\u001b[0m";
    private static final String HELP_SHORT = """
diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
""";

    private static final String HELP_LONG = """
diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
""";

    private static final Pattern HUNK = Pattern.compile("^@@ -(\\d+)(?:,\\d+)? \\+(\\d+)(?:,\\d+)? @@.*");

    static class Face {
        boolean bold, italic, intense, underline;
        Integer fg, bg;
        int[] fgRgb, bgRgb;
        Integer fg256, bg256;
        String ansi() {
            StringBuilder s = new StringBuilder();
            if (bold) s.append("\u001b[1m");
            if (italic) s.append("\u001b[3m");
            if (underline) s.append("\u001b[4m");
            if (fgRgb != null) s.append("\u001b[38;2;").append(fgRgb[0]).append(';').append(fgRgb[1]).append(';').append(fgRgb[2]).append('m');
            else if (fg256 != null) s.append("\u001b[38;5;").append(fg256).append('m');
            else if (fg != null) s.append("\u001b[").append(fg).append('m');
            if (bgRgb != null) s.append("\u001b[48;2;").append(bgRgb[0]).append(';').append(bgRgb[1]).append(';').append(bgRgb[2]).append('m');
            else if (bg256 != null) s.append("\u001b[48;5;").append(bg256).append('m');
            else if (bg != null) s.append("\u001b[").append(bg).append('m');
            return s.toString();
        }
    }

    enum LineNums { NONE, COMPACT, ALIGNED }

    private final Face added = new Face();
    private final Face removed = new Face();
    private final Face refineAdded = new Face();
    private final Face refineRemoved = new Face();
    private LineNums lineNums = LineNums.NONE;
    private int oldNo = 0, newNo = 0;

    public static void main(String[] args) throws Exception {
        new Diffr().run(args);
    }

    Diffr() {
        added.fg = 32;
        removed.fg = 31;
        refineAdded.bold = true; refineAdded.fgRgb = new int[]{255,255,255}; refineAdded.bg = 42;
        refineRemoved.bold = true; refineRemoved.fgRgb = new int[]{255,255,255}; refineRemoved.bg = 41;
    }

    private void run(String[] args) throws Exception {
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-V") || a.equals("--version")) {
                System.out.println("diffr 0.1.5");
                return;
            } else if (a.equals("-h")) {
                System.out.print(HELP_SHORT);
                return;
            } else if (a.equals("--help")) {
                System.out.print(HELP_LONG);
                return;
            } else if (a.equals("--line-numbers")) {
                lineNums = LineNums.COMPACT;
                if (i + 1 < args.length && (args[i + 1].equals("compact") || args[i + 1].equals("aligned"))) {
                    lineNums = args[++i].equals("aligned") ? LineNums.ALIGNED : LineNums.COMPACT;
                }
            } else if (a.equals("--colors")) {
                if (i + 1 >= args.length) {
                    bad("missing color spec");
                    return;
                }
                if (!parseColor(args[++i])) return;
            } else {
                bad("bad argument: '" + a + "'");
                return;
            }
        }
        process();
    }

    private void bad(String msg) {
        System.err.println(msg);
        System.err.print(HELP_SHORT);
    }

    private boolean parseColor(String spec) {
        String[] parts = spec.split(":");
        if (parts.length == 0) return true;
        Face f;
        switch (parts[0]) {
            case "added" -> f = added;
            case "removed" -> f = removed;
            case "refine-added" -> f = refineAdded;
            case "refine-removed" -> f = refineRemoved;
            default -> {
                System.err.println("unexpected face name: got '" + parts[0] + "', expected added|refine-added|removed|refine-removed");
                return false;
            }
        }
        for (int i = 1; i < parts.length; i++) {
            String p = parts[i];
            if (p.equals("none")) {
                f.bold = f.italic = f.intense = f.underline = false;
                f.fg = f.bg = f.fg256 = f.bg256 = null; f.fgRgb = f.bgRgb = null;
            } else if (p.equals("bold")) f.bold = true;
            else if (p.equals("nobold")) f.bold = false;
            else if (p.equals("italic")) f.italic = true;
            else if (p.equals("noitalic")) f.italic = false;
            else if (p.equals("underline")) f.underline = true;
            else if (p.equals("nounderline")) f.underline = false;
            else if (p.equals("intense")) f.intense = true;
            else if (p.equals("nointense")) f.intense = false;
            else if ((p.equals("foreground") || p.equals("background")) && i + 1 < parts.length) {
                Color c = color(parts[++i], p.equals("background"));
                if (p.equals("foreground")) { f.fg = c.code; f.fgRgb = c.rgb; f.fg256 = c.color256; }
                else { f.bg = c.code; f.bgRgb = c.rgb; f.bg256 = c.color256; }
            }
        }
        return true;
    }

    record Color(Integer code, int[] rgb, Integer color256) {}
    private Color color(String s, boolean bg) {
        if (s.equals("none")) return new Color(null, null, null);
        String[] rgb = s.split(",");
        if (rgb.length == 3) {
            try { return new Color(null, new int[]{Integer.parseInt(rgb[0]), Integer.parseInt(rgb[1]), Integer.parseInt(rgb[2])}, null); }
            catch (NumberFormatException ignored) {}
        }
        int base = bg ? 40 : 30;
        int v = switch (s) {
            case "black" -> 0; case "red" -> 1; case "green" -> 2; case "yellow" -> 3;
            case "blue" -> 4; case "magenta" -> 5; case "cyan" -> 6; case "white" -> 7;
            default -> -1;
        };
        if (v >= 0) return new Color(base + v, null, null);
        try {
            int n = Integer.parseInt(s);
            return new Color(null, null, n);
        } catch (NumberFormatException e) {
            return new Color(null, null, null);
        }
    }

    private void process() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        List<String> pending = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            Matcher m = HUNK.matcher(line);
            if (m.matches()) {
                flush(pending);
                oldNo = Integer.parseInt(m.group(1));
                newNo = Integer.parseInt(m.group(2));
                plain(line);
            } else if (line.startsWith("-") && !line.startsWith("---")) {
                pending.add(line);
            } else if (line.startsWith("+") && !line.startsWith("+++")) {
                pending.add(line);
            } else {
                flush(pending);
                if (line.startsWith(" ")) {
                    prefixBoth();
                    if (lineNums == LineNums.COMPACT) System.out.println(line + RESET);
                    else System.out.println(RESET + line + RESET);
                    oldNo++; newNo++;
                } else {
                    plain(line);
                }
            }
        }
        flush(pending);
    }

    private void plain(String line) {
        System.out.println(RESET + line + RESET);
    }

    private void flush(List<String> block) {
        if (block.isEmpty()) return;
        List<String> minus = new ArrayList<>(), plus = new ArrayList<>();
        for (String s : block) {
            if (s.startsWith("-")) minus.add(s.substring(1));
            else plus.add(s.substring(1));
        }
        List<List<Part>> minusParts = new ArrayList<>();
        List<List<Part>> plusParts = new ArrayList<>();
        int n = Math.max(minus.size(), plus.size());
        for (int i = 0; i < n; i++) {
            String a = i < minus.size() ? minus.get(i) : null;
            String b = i < plus.size() ? plus.get(i) : null;
            if (a != null && b != null) {
                DiffPair dp = diff(a, b);
                minusParts.add(dp.aParts);
                plusParts.add(dp.bParts);
            } else if (a != null) {
                minusParts.add(List.of(new Part(a, true)));
            } else {
                plusParts.add(List.of(new Part(b, true)));
            }
        }
        for (List<Part> p : minusParts) { emitChanged('-', p, removed, refineRemoved); oldNo++; }
        for (List<Part> p : plusParts) { emitChanged('+', p, added, refineAdded); newNo++; }
        block.clear();
    }

    record Part(String text, boolean changed) {}
    record DiffPair(List<Part> aParts, List<Part> bParts) {}

    private DiffPair diff(String a, String b) {
        List<String> ta = tokens(a), tb = tokens(b);
        int[][] dp = new int[ta.size()+1][tb.size()+1];
        for (int i = ta.size()-1; i >= 0; i--) {
            for (int j = tb.size()-1; j >= 0; j--) {
                dp[i][j] = ta.get(i).equals(tb.get(j)) ? dp[i+1][j+1]+1 : Math.max(dp[i+1][j], dp[i][j+1]);
            }
        }
        boolean[] ca = new boolean[ta.size()], cb = new boolean[tb.size()];
        int i = 0, j = 0;
        while (i < ta.size() && j < tb.size()) {
            if (ta.get(i).equals(tb.get(j))) { i++; j++; }
            else if (dp[i+1][j] >= dp[i][j+1]) ca[i++] = true;
            else cb[j++] = true;
        }
        while (i < ta.size()) ca[i++] = true;
        while (j < tb.size()) cb[j++] = true;
        return new DiffPair(parts(ta, ca), parts(tb, cb));
    }

    private List<String> tokens(String s) {
        ArrayList<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int mode = -1;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int m = Character.isLetterOrDigit(c) || c == '_' ? 1 : (Character.isWhitespace(c) ? 0 : 2);
            if (mode != -1 && m != mode) { out.add(cur.toString()); cur.setLength(0); }
            mode = m; cur.append(c);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private List<Part> parts(List<String> toks, boolean[] changed) {
        ArrayList<Part> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        Boolean mode = null;
        for (int i = 0; i < toks.size(); i++) {
            if (mode != null && mode != changed[i]) {
                out.add(new Part(cur.toString(), mode)); cur.setLength(0);
            }
            mode = changed[i]; cur.append(toks.get(i));
        }
        if (cur.length() > 0) out.add(new Part(cur.toString(), mode != null && mode));
        return out;
    }

    private void emitChanged(char sign, List<Part> parts, Face base, Face refine) {
        prefixOne(sign);
        String b = base.ansi(), r = refine.ansi();
        System.out.print(RESET + b + sign + RESET);
        for (Part p : parts) {
            System.out.print(RESET + (p.changed ? r : b) + p.text + RESET);
        }
        System.out.println(RESET + b + RESET);
    }

    private void prefixBoth() {
        if (lineNums == LineNums.NONE) return;
        if (lineNums == LineNums.ALIGNED) System.out.print(oldNo + " " + newNo + "\t");
        else if (oldNo == newNo) System.out.print(String.format("%3d", oldNo) + RESET);
        else System.out.print(oldNo + " " + newNo + RESET);
    }

    private void prefixOne(char sign) {
        if (lineNums == LineNums.NONE) return;
        Face f = sign == '-' ? removed : added;
        String s;
        if (sign == '-') s = oldNo + "  ";
        else s = "  " + newNo;
        if (lineNums == LineNums.ALIGNED) s = sign == '-' ? String.format("%-5d", oldNo) : String.format("%5d", newNo);
        System.out.print(RESET + f.ansi() + s + RESET + (lineNums == LineNums.ALIGNED ? "\t" : ""));
    }
}
