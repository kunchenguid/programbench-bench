package hashcards;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Main {
    static final String VERSION = "hashcards 0.3.0";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            if (code != 0) System.exit(code);
        } catch (HashcardsError e) {
            System.err.print(e.getMessage());
            if (!e.getMessage().endsWith("\n")) System.err.println();
            System.exit(e.code);
        } catch (Exception e) {
            System.err.println("hashcards: error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0 || eq(args[0], "-h", "--help")) {
            printMainHelp();
            return 0;
        }
        if (eq(args[0], "-V", "--version")) {
            System.out.println(VERSION);
            return 0;
        }
        switch (args[0]) {
            case "drill": return drill(args);
            case "check": return check(args);
            case "stats": return stats(args);
            case "export": return export(args);
            case "orphans": return orphans(args);
            case "help": return help(args);
            default:
                throw new HashcardsError(2, "error: unrecognized subcommand '" + args[0] + "'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n");
        }
    }

    int help(String[] args) {
        if (args.length == 1) {
            printMainHelp();
            return 0;
        }
        String[] shifted = new String[args.length - 1];
        System.arraycopy(args, 1, shifted, 0, shifted.length);
        switch (shifted[0]) {
            case "drill": printDrillHelp(); return 0;
            case "check": printCheckHelp(); return 0;
            case "stats": printStatsHelp(); return 0;
            case "export": printExportHelp(); return 0;
            case "orphans": printOrphansHelp(); return 0;
            default:
                throw new HashcardsError(2, "error: unrecognized subcommand '" + shifted[0] + "'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.\n");
        }
    }

    int drill(String[] args) throws Exception {
        for (String a : args) if (eq(a, "-h", "--help")) { printDrillHelp(); return 0; }
        String dir = lastPositional(args, 1);
        Collection c = load(Paths.get(dir == null ? "." : dir).toAbsolutePath().normalize(), true);
        validateMedia(c);
        System.out.println("Starting server at http://127.0.0.1:8000");
        return 0;
    }

    int check(String[] args) throws Exception {
        for (String a : args) if (eq(a, "-h", "--help")) { printCheckHelp(); return 0; }
        String dir = lastPositional(args, 1);
        Collection c = load(Paths.get(dir == null ? "." : dir).toAbsolutePath().normalize(), true);
        validateMedia(c);
        touchDb(c.root);
        System.out.println("ok");
        return 0;
    }

    int stats(String[] args) throws Exception {
        for (String a : args) if (eq(a, "-h", "--help")) { printStatsHelp(); return 0; }
        String format = "html";
        List<String> pos = new ArrayList<>();
        for (int i = 1; i < args.length; i++) {
            if (args[i].equals("--format") && i + 1 < args.length) format = args[++i];
            else if (args[i].startsWith("--format=")) format = args[i].substring(9);
            else if (!args[i].startsWith("-")) pos.add(args[i]);
        }
        if (!format.equals("html") && !format.equals("json")) {
            throw new HashcardsError(2, "error: invalid value '" + format + "' for '--format <FORMAT>'\n");
        }
        Path root = Paths.get(pos.isEmpty() ? "." : pos.get(pos.size() - 1)).toAbsolutePath().normalize();
        Collection c = load(root, true);
        validateMedia(c);
        touchDb(root);
        if (format.equals("html")) {
            System.out.println("HTML output is not implemented yet.");
        } else {
            System.out.println("{");
            System.out.println("  \"cardsInDeckCount\": " + c.cards.size() + ",");
            System.out.println("  \"cardsInDbCount\": 0,");
            System.out.println("  \"texMacroCount\": 0,");
            System.out.println("  \"cardsReviewedTodayCount\": 0");
            System.out.println("}");
        }
        return 0;
    }

    int export(String[] args) throws Exception {
        for (String a : args) if (eq(a, "-h", "--help")) { printExportHelp(); return 0; }
        String out = null;
        List<String> pos = new ArrayList<>();
        for (int i = 1; i < args.length; i++) {
            if (args[i].equals("--output") && i + 1 < args.length) out = args[++i];
            else if (args[i].startsWith("--output=")) out = args[i].substring(9);
            else if (!args[i].startsWith("-")) pos.add(args[i]);
        }
        Path root = Paths.get(pos.isEmpty() ? "." : pos.get(pos.size() - 1)).toAbsolutePath().normalize();
        Collection c = load(root, true);
        validateMedia(c);
        touchDb(root);
        String json = renderExport(c);
        if (out == null) System.out.print(json);
        else Files.writeString(Paths.get(out), json, StandardCharsets.UTF_8);
        return 0;
    }

    int orphans(String[] args) throws Exception {
        if (args.length == 1 || eq(args[1], "-h", "--help")) { printOrphansHelp(); return 0; }
        if (args[1].equals("help")) { printOrphansHelp(); return 0; }
        if (args[1].equals("list")) {
            for (String a : args) if (eq(a, "-h", "--help")) { printOrphansListHelp(); return 0; }
            return 0;
        }
        if (args[1].equals("delete")) {
            for (String a : args) if (eq(a, "-h", "--help")) { printOrphansDeleteHelp(); return 0; }
            return 0;
        }
        throw new HashcardsError(2, "error: unrecognized subcommand '" + args[1] + "'\n\nUsage: executable orphans <COMMAND>\n\nFor more information, try '--help'.\n");
    }

    Collection load(Path root, boolean dedupe) throws IOException {
        Collection c = new Collection();
        c.root = root;
        if (!Files.exists(root)) return c;
        List<Path> files = new ArrayList<>();
        try (var stream = Files.walk(root)) {
            stream.filter(p -> Files.isRegularFile(p) && p.getFileName().toString().endsWith(".md"))
                    .forEach(files::add);
        }
        files.sort(Comparator.comparing(Path::toString));
        Map<String, Card> cards = new LinkedHashMap<>();
        for (Path file : files) {
            List<Card> parsed = parseFile(root, file.toAbsolutePath().normalize());
            for (Card card : parsed) cards.put(card.hash, card);
        }
        c.cards.addAll(cards.values());
        return c;
    }

    List<Card> parseFile(Path root, Path file) throws IOException {
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        List<Card> out = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.startsWith("Q:")) {
                int start = i;
                StringBuilder q = new StringBuilder(afterColon(line));
                i++;
                while (i < lines.size() && !lines.get(i).startsWith("A:")) appendLine(q, lines.get(i++));
                if (i >= lines.size()) break;
                StringBuilder a = new StringBuilder(afterColon(lines.get(i)));
                i++;
                while (i < lines.size() && !isCardStart(lines.get(i))) appendLine(a, lines.get(i++));
                int end = i < lines.size() ? i : Math.max(start, lines.size() - 1);
                i--;
                Card card = Card.basic(file, deckName(file), start, end, trimBlank(q.toString()), trimBlank(a.toString()));
                out.add(card);
            } else if (line.startsWith("C:")) {
                int start = i;
                StringBuilder text = new StringBuilder(afterColon(line));
                i++;
                while (i < lines.size() && !isCardStart(lines.get(i))) appendLine(text, lines.get(i++));
                int end = i < lines.size() ? i : Math.max(start, lines.size() - 1);
                i--;
                out.addAll(clozes(file, deckName(file), start, end, trimBlank(text.toString())));
            }
        }
        return out;
    }

    static String afterColon(String line) {
        String s = line.length() > 2 ? line.substring(2) : "";
        if (s.startsWith(" ")) s = s.substring(1);
        return s;
    }

    static void appendLine(StringBuilder b, String s) {
        if (b.length() > 0) b.append('\n');
        b.append(s);
    }

    static boolean isCardStart(String s) {
        return s.startsWith("Q:") || s.startsWith("C:");
    }

    static List<Card> clozes(Path file, String deck, int startLine, int endLine, String raw) {
        List<Card> cards = new ArrayList<>();
        StringBuilder visible = new StringBuilder();
        List<int[]> spans = new ArrayList<>();
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            if (ch == '[') {
                int close = raw.indexOf(']', i + 1);
                if (close >= 0) {
                    int start = visible.length();
                    visible.append(raw, i + 1, close);
                    int end = visible.length() - 1;
                    spans.add(new int[]{start, end});
                    i = close;
                } else {
                    visible.append(ch);
                }
            } else if (ch != ']') {
                visible.append(ch);
            }
        }
        String text = visible.toString();
        String family = sha256("cloze-family\0" + text);
        for (int[] span : spans) cards.add(Card.cloze(file, deck, startLine, endLine, text, span[0], span[1], family));
        return cards;
    }

    static String trimBlank(String s) {
        String[] parts = s.split("\n", -1);
        int a = 0, b = parts.length;
        while (a < b && parts[a].isEmpty()) a++;
        while (b > a && parts[b - 1].isEmpty()) b--;
        StringBuilder r = new StringBuilder();
        for (int i = a; i < b; i++) {
            if (i > a) r.append('\n');
            r.append(parts[i]);
        }
        return r.toString();
    }

    void validateMedia(Collection c) {
        List<MediaRef> missing = new ArrayList<>();
        for (Card card : c.cards) {
            for (String body : card.bodies()) {
                int at = 0;
                while ((at = body.indexOf("](", at)) >= 0) {
                    int start = at + 2;
                    int end = body.indexOf(')', start);
                    if (end < 0) break;
                    String ref = body.substring(start, end);
                    at = end + 1;
                    if (ref.startsWith("http://") || ref.startsWith("https://") || ref.startsWith("#") || ref.isEmpty()) continue;
                    Path p = ref.startsWith("@/") ? c.root.resolve(ref.substring(2)) : card.file.getParent().resolve(ref);
                    if (!Files.exists(p.normalize())) missing.add(new MediaRef(ref, card.file, card.lineStart));
                }
            }
        }
        if (!missing.isEmpty()) {
            missing.sort(Comparator.comparing((MediaRef m) -> m.ref).thenComparing(m -> m.file.toString()));
            StringBuilder b = new StringBuilder("hashcards: error: Missing media files referenced in cards:\n");
            for (MediaRef m : missing) b.append("  - ").append(m.ref).append(" (referenced in ").append(m.file).append(":").append(m.line).append(")\n");
            throw new HashcardsError(1, b.toString());
        }
    }

    static String renderExport(Collection c) {
        StringBuilder b = new StringBuilder();
        b.append("{\n  \"cards\": [");
        for (int i = 0; i < c.cards.size(); i++) {
            Card card = c.cards.get(i);
            if (i > 0) b.append(",");
            b.append("\n    {\n");
            b.append("      \"hash\": \"").append(card.hash).append("\",\n");
            b.append("      \"familyHash\": ").append(card.familyHash == null ? "null" : "\"" + card.familyHash + "\"").append(",\n");
            b.append("      \"deckName\": \"").append(esc(card.deckName)).append("\",\n");
            b.append("      \"location\": {\n");
            b.append("        \"filePath\": \"").append(esc(card.file.toString())).append("\",\n");
            b.append("        \"lineStart\": ").append(card.lineStart).append(",\n");
            b.append("        \"lineEnd\": ").append(card.lineEnd).append("\n");
            b.append("      },\n");
            b.append("      \"content\": {\n");
            if (card.type.equals("basic")) {
                b.append("        \"basic\": {\n");
                b.append("          \"question\": \"").append(esc(card.question)).append("\",\n");
                b.append("          \"answer\": \"").append(esc(card.answer)).append("\"\n");
                b.append("        }\n");
            } else {
                b.append("        \"cloze\": {\n");
                b.append("          \"text\": \"").append(esc(card.text)).append("\",\n");
                b.append("          \"start\": ").append(card.start).append(",\n");
                b.append("          \"end\": ").append(card.end).append("\n");
                b.append("        }\n");
            }
            b.append("      },\n");
            b.append("      \"performance\": null\n");
            b.append("    }");
        }
        if (!c.cards.isEmpty()) b.append("\n  ");
        b.append("],\n  \"sessions\": []\n}\n");
        return b.toString();
    }

    static void touchDb(Path root) {
        try {
            if (Files.isDirectory(root)) {
                Path db = root.resolve("hashcards.db");
                if (!Files.exists(db)) Files.write(db, new byte[0]);
            }
        } catch (IOException ignored) {
        }
    }

    static String deckName(Path p) {
        String n = p.getFileName().toString();
        return n.endsWith(".md") ? n.substring(0, n.length() - 3) : n;
    }

    static boolean eq(String s, String... xs) {
        for (String x : xs) if (s.equals(x)) return true;
        return false;
    }

    static String lastPositional(String[] args, int start) {
        String r = null;
        for (int i = start; i < args.length; i++) {
            if (args[i].startsWith("--")) {
                if (!args[i].contains("=") && i + 1 < args.length && !args[i + 1].startsWith("-")) i++;
            } else if (!args[i].startsWith("-")) r = args[i];
        }
        return r;
    }

    static String esc(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '\\': b.append("\\\\"); break;
                case '"': b.append("\\\""); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (ch < 0x20) b.append(String.format("\\u%04x", (int) ch));
                    else b.append(ch);
            }
        }
        return b.toString();
    }

    static String sha256(String s) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] h = d.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte x : h) b.append(String.format("%02x", x & 0xff));
            return b.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    static void printMainHelp() {
        System.out.println("A plain text-based spaced repetition system.\n\nUsage: executable <COMMAND>\n\nCommands:\n  drill    Drill cards through a web interface\n  check    Check the integrity of a collection\n  stats    Print collection statistics\n  orphans  Commands relating to orphan cards\n  export   Export a collection\n  help     Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version");
    }
    static void printCheckHelp() {
        System.out.println("Check the integrity of a collection\n\nUsage: executable check [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help");
    }
    static void printStatsHelp() {
        System.out.println("Print collection statistics\n\nUsage: executable stats [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --format <FORMAT>\n          Which output format to use\n\n          Possible values:\n          - html: HTML output\n          - json: JSON output\n          \n          [default: html]\n\n  -h, --help\n          Print help (see a summary with '-h')");
    }
    static void printExportHelp() {
        System.out.println("Export a collection\n\nUsage: executable export [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout\n  -h, --help             Print help");
    }
    static void printOrphansHelp() {
        System.out.println("Commands relating to orphan cards\n\nUsage: executable orphans <COMMAND>\n\nCommands:\n  list    List the hashes of all orphan cards in the collection\n  delete  Remove all orphan cards from the database\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help");
    }
    static void printOrphansListHelp() {
        System.out.println("List the hashes of all orphan cards in the collection\n\nUsage: executable orphans list [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help");
    }
    static void printOrphansDeleteHelp() {
        System.out.println("Remove all orphan cards from the database\n\nUsage: executable orphans delete [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help");
    }
    static void printDrillHelp() {
        System.out.println("Drill cards through a web interface\n\nUsage: executable drill [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --card-limit <CARD_LIMIT>\n          Maximum number of cards to drill in a session. By default, all cards due today are drilled\n\n      --new-card-limit <NEW_CARD_LIMIT>\n          Maximum number of new cards to drill in a session\n\n      --host <HOST>\n          The host address to bind to. Default is 127.0.0.1\n          \n          [default: 127.0.0.1]\n\n      --port <PORT>\n          The port to use for the web server. Default is 8000\n          \n          [default: 8000]\n\n      --from-deck <FROM_DECK>\n          Only drill cards from this deck\n\n      --open-browser <OPEN_BROWSER>\n          Whether to open the browser automatically. Default is true\n          \n          [possible values: true, false]\n\n      --answer-controls <ANSWER_CONTROLS>\n          Which answer controls to show:\n\n          Possible values:\n          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)\n          - binary: Show only two rating buttons (Forgot/Good)\n          \n          [default: full]\n\n      --bury-siblings <BURY_SIBLINGS>\n          Whether or not to bury siblings. Default is true\n          \n          [possible values: true, false]\n\n  -h, --help\n          Print help (see a summary with '-h')");
    }

    static class HashcardsError extends RuntimeException {
        final int code;
        HashcardsError(int code, String message) { super(message); this.code = code; }
    }
    static class Collection {
        Path root;
        List<Card> cards = new ArrayList<>();
    }
    static class MediaRef {
        String ref; Path file; int line;
        MediaRef(String ref, Path file, int line) { this.ref = ref; this.file = file; this.line = line; }
    }
    static class Card {
        String hash, familyHash, deckName, type, question, answer, text;
        int start, end, lineStart, lineEnd;
        Path file;
        static Card basic(Path file, String deck, int lineStart, int lineEnd, String q, String a) {
            Card c = new Card();
            c.file = file; c.deckName = deck; c.lineStart = lineStart; c.lineEnd = lineEnd; c.type = "basic"; c.question = q; c.answer = a;
            c.hash = sha256("basic\0" + q + "\0" + a);
            return c;
        }
        static Card cloze(Path file, String deck, int lineStart, int lineEnd, String text, int start, int end, String family) {
            Card c = new Card();
            c.file = file; c.deckName = deck; c.lineStart = lineStart; c.lineEnd = lineEnd; c.type = "cloze"; c.text = text; c.start = start; c.end = end; c.familyHash = family;
            c.hash = sha256("cloze\0" + text + "\0" + start + "\0" + end);
            return c;
        }
        List<String> bodies() {
            List<String> b = new ArrayList<>();
            if (question != null) b.add(question);
            if (answer != null) b.add(answer);
            if (text != null) b.add(text);
            return b;
        }
    }
}
