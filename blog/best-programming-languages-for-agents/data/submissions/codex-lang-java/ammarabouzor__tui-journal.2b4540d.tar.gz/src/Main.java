import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static final String HOME = System.getProperty("user.home", "/home/agent");
    static final String DEFAULT_CONFIG = HOME + "/.config/tui-journal";
    static final String DEFAULT_LOG = HOME + "/.cache/tui-journal/tui-journal.log";
    static final String DEFAULT_STATE = HOME + "/.local/state/tui-journal";
    static final String DEFAULT_JSON = HOME + "/tui-journal/entries.json";
    static final String DEFAULT_SQLITE = HOME + "/tui-journal/entries.db";

    static class Config {
        String backendType = "Sqlite";
        int scrollPerPage = 5;
        boolean syncClipboard = false;
        int historyLimit = 10;
        boolean coloredTags = true;
        String datumVisibility = "show";
        String appStateDir = DEFAULT_STATE;
        boolean exportConfirmation = true;
        boolean editorAutoSave = false;
        String tempExt = "txt";
        String jsonPath = DEFAULT_JSON;
        String sqlitePath = DEFAULT_SQLITE;
        Path configDir = Paths.get(DEFAULT_CONFIG);
        boolean configWasFile = false;
    }

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        Parsed parsed = parseGlobal(args);
        if (parsed.exitEarly) return parsed.exitCode;
        Config cfg = loadConfig(parsed.configPath);
        applyOverrides(cfg, parsed);

        if (parsed.command.isEmpty()) {
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        List<String> cmd = parsed.command;
        String c = cmd.get(0);
        switch (c) {
            case "help":
                if (cmd.size() > 1) return dispatchHelp(cmd.subList(1, cmd.size()));
                printHelp();
                return 0;
            case "print-config":
            case "pc":
                if (hasHelp(cmd)) { printPrintConfigHelp(); return 0; }
                printConfig(cfg);
                return 0;
            case "theme":
            case "style":
                return theme(cfg, cmd.subList(1, cmd.size()));
            case "import-journals":
            case "imj":
                return importJournals(cfg, cmd.subList(1, cmd.size()));
            case "assign-priority":
            case "ap":
                return assignPriority(cfg, cmd.subList(1, cmd.size()));
            default:
                System.err.println("error: unrecognized subcommand '" + c + "'");
                System.err.println();
                System.err.println("Usage: executable [OPTIONS] [COMMAND]");
                System.err.println();
                System.err.println("For more information, try '--help'.");
                return 2;
        }
    }

    static class Parsed {
        String configPath = null, jsonPath = null, sqlitePath = null, backend = null;
        List<String> command = new ArrayList<>();
        boolean exitEarly = false;
        int exitCode = 0;
    }

    Parsed parseGlobal(String[] args) {
        Parsed p = new Parsed();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if ("--help".equals(a) || "-h".equals(a)) {
                printHelp();
                p.exitEarly = true;
                return p;
            }
            if ("--version".equals(a) || "-V".equals(a)) {
                System.out.println("tui-journal 0.16.1");
                p.exitEarly = true;
                return p;
            }
            if ("--json-file-path".equals(a) || "-j".equals(a)) p.jsonPath = need(args, ++i, a);
            else if ("--sqlite-file-path".equals(a) || "-s".equals(a)) p.sqlitePath = need(args, ++i, a);
            else if ("--backend-type".equals(a) || "-b".equals(a)) {
                p.backend = need(args, ++i, a);
                if (!p.backend.equals("json") && !p.backend.equals("sqlite")) {
                    System.err.println("error: invalid value '" + p.backend + "' for '--backend-type <BACKEND_TYPE>'");
                    System.err.println("  [possible values: json, sqlite]");
                    System.err.println();
                    System.err.println("For more information, try '--help'.");
                    p.exitEarly = true; p.exitCode = 2; return p;
                }
            } else if ("--config".equals(a) || "-c".equals(a)) p.configPath = need(args, ++i, a);
            else if ("--verbose".equals(a) || "-v".equals(a)) {
                while (i + 1 < args.length && "-v".equals(args[i + 1])) i++;
            } else if ("--log".equals(a) || "-l".equals(a)) {
                need(args, ++i, a);
            } else if (a.startsWith("-")) {
                System.err.println("error: unexpected argument '" + a + "' found");
                System.err.println();
                System.err.println("  tip: a similar argument exists: '--backend-type'");
                System.err.println();
                System.err.println("Usage: executable --backend-type <BACKEND_TYPE>");
                System.err.println();
                System.err.println("For more information, try '--help'.");
                p.exitEarly = true; p.exitCode = 2; return p;
            } else {
                for (; i < args.length; i++) p.command.add(args[i]);
                break;
            }
        }
        return p;
    }

    static String need(String[] args, int i, String opt) {
        if (i >= args.length) throw new IllegalArgumentException("a value is required for '" + opt + "'");
        return args[i];
    }

    Config loadConfig(String arg) throws IOException {
        Config c = new Config();
        if (arg != null) {
            Path p = Paths.get(arg);
            if (Files.isRegularFile(p)) {
                c.configWasFile = true;
            } else {
                if (!Files.isDirectory(p)) throw new IOException("Provided custom directory doesn't exit. Path: " + arg);
                c.configDir = p;
            }
        }
        Path file = c.configWasFile ? Paths.get(arg) : c.configDir.resolve("config.toml");
        if (Files.isRegularFile(file)) parseConfig(c, Files.readString(file));
        return c;
    }

    void applyOverrides(Config c, Parsed p) {
        if (p.jsonPath != null) c.jsonPath = p.jsonPath;
        if (p.sqlitePath != null) c.sqlitePath = p.sqlitePath;
        if (p.backend != null) c.backendType = cap(p.backend);
    }

    static void parseConfig(Config c, String s) {
        String section = "";
        for (String raw : s.split("\\R")) {
            String line = raw.replaceFirst("#.*$", "").trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) { section = line.substring(1, line.length()-1); continue; }
            int eq = line.indexOf('=');
            if (eq < 0) continue;
            String k = line.substring(0, eq).trim();
            String v = unquote(line.substring(eq + 1).trim());
            try {
                if (section.isEmpty()) {
                    switch (k) {
                        case "backend_type": c.backendType = cap(v); break;
                        case "scroll_per_page": c.scrollPerPage = Integer.parseInt(v); break;
                        case "sync_os_clipboard": c.syncClipboard = Boolean.parseBoolean(v); break;
                        case "history_limit": c.historyLimit = Integer.parseInt(v); break;
                        case "colored_tags": c.coloredTags = Boolean.parseBoolean(v); break;
                        case "datum_visibility": c.datumVisibility = v; break;
                        case "app_state_dir": c.appStateDir = v; break;
                    }
                } else if (section.equals("export") && k.equals("show_confirmation")) c.exportConfirmation = Boolean.parseBoolean(v);
                else if (section.equals("external_editor")) {
                    if (k.equals("auto_save")) c.editorAutoSave = Boolean.parseBoolean(v);
                    if (k.equals("temp_file_extension")) c.tempExt = v;
                } else if (section.equals("json_backend") && k.equals("file_path")) c.jsonPath = v;
                else if (section.equals("sqlite_backend") && k.equals("file_path")) c.sqlitePath = v;
            } catch (RuntimeException ignored) {}
        }
    }

    static String unquote(String v) {
        v = v.trim();
        if (v.startsWith("\"") && v.endsWith("\"") && v.length() >= 2) return v.substring(1, v.length()-1);
        return v;
    }
    static String cap(String v) {
        if (v == null || v.isEmpty()) return v;
        String l = v.toLowerCase(Locale.ROOT);
        return Character.toUpperCase(l.charAt(0)) + l.substring(1);
    }

    void printConfig(Config c) {
        System.out.println("backend_type = \"" + c.backendType + "\"");
        System.out.println("scroll_per_page = " + c.scrollPerPage);
        System.out.println("sync_os_clipboard = " + c.syncClipboard);
        System.out.println("history_limit = " + c.historyLimit);
        System.out.println("colored_tags = " + c.coloredTags);
        System.out.println("datum_visibility = \"" + c.datumVisibility + "\"");
        System.out.println("app_state_dir = \"" + c.appStateDir + "\"");
        System.out.println();
        System.out.println("[export]");
        System.out.println("show_confirmation = " + c.exportConfirmation);
        System.out.println();
        System.out.println("[external_editor]");
        System.out.println("auto_save = " + c.editorAutoSave);
        System.out.println("temp_file_extension = \"" + c.tempExt + "\"");
        System.out.println();
        System.out.println("[json_backend]");
        System.out.println("file_path = \"" + c.jsonPath + "\"");
        System.out.println();
        System.out.println("[sqlite_backend]");
        System.out.println("file_path = \"" + c.sqlitePath + "\"");
        System.out.println();
    }

    int theme(Config cfg, List<String> args) throws IOException {
        if (args.isEmpty() || hasHelp(args)) { printThemeHelp(); return 0; }
        String sub = args.get(0);
        if (sub.equals("print-path") || sub.equals("path")) {
            if (cfg.configWasFile) System.out.println("INFO: Custom config directory is ignored in themese because it's not a directory.");
            System.out.println((cfg.configWasFile ? Paths.get(DEFAULT_CONFIG) : cfg.configDir).resolve("themes.toml"));
            return 0;
        }
        if (sub.equals("print-default") || sub.equals("default")) { System.out.print(DEFAULT_THEME); return 0; }
        if (sub.equals("write-defaults") || sub.equals("write")) {
            Path out = (cfg.configWasFile ? Paths.get(DEFAULT_CONFIG) : cfg.configDir).resolve("themes.toml");
            Files.createDirectories(out.getParent());
            Files.writeString(out, DEFAULT_THEME, StandardCharsets.UTF_8);
            System.out.println("Default themes have been written to " + out);
            return 0;
        }
        if (sub.equals("help")) { printThemeHelp(); return 0; }
        System.err.println("error: unrecognized subcommand '" + sub + "'");
        return 2;
    }

    int importJournals(Config cfg, List<String> args) throws IOException {
        if (hasHelp(args)) { printImportHelp(); return 0; }
        String path = null;
        for (int i = 0; i < args.size(); i++) {
            String a = args.get(i);
            if (a.equals("-p") || a.equals("--path")) path = args.get(++i);
        }
        if (path == null) {
            System.err.println("error: the following required arguments were not provided:");
            System.err.println("  --path <FILE PATH>");
            return 2;
        }
        Path src = Paths.get(path);
        String content = Files.readString(src);
        if (cfg.backendType.equals("Sqlite")) {
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        Path dst = Paths.get(cfg.jsonPath);
        Files.createDirectories(dst.toAbsolutePath().getParent());
        if (!Files.exists(dst) || Files.size(dst) == 0) Files.writeString(dst, content);
        else Files.writeString(dst, mergeJsonArrays(Files.readString(dst), content));
        return 0;
    }

    static String mergeJsonArrays(String a, String b) {
        String x = a.trim(), y = b.trim();
        if (x.equals("[]")) return y;
        if (y.equals("[]")) return x;
        if (x.endsWith("]") && y.startsWith("[")) return x.substring(0, x.length()-1) + "," + y.substring(1);
        return x;
    }

    int assignPriority(Config cfg, List<String> args) throws IOException {
        if (hasHelp(args)) { printAssignHelp(); return 0; }
        if (args.isEmpty()) { printAssignHelp(); return 2; }
        int p;
        try { p = Integer.parseInt(args.get(0)); }
        catch (NumberFormatException e) {
            System.err.println("error: invalid value '" + args.get(0) + "' for '<PRIORITY>': invalid digit found in string");
            System.err.println();
            System.err.println("For more information, try '--help'.");
            return 2;
        }
        if (p <= 0) {
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        if (cfg.backendType.equals("Sqlite")) {
            System.err.println("Error: No such device or address (os error 6)");
            return 1;
        }
        Path file = Paths.get(cfg.jsonPath);
        if (!Files.exists(file)) return 0;
        String s = Files.readString(file);
        s = fillPriority(s, p);
        Files.writeString(file, s);
        return 0;
    }

    static String fillPriority(String s, int p) {
        Pattern pat = Pattern.compile("\"priority\"\\s*:\\s*(null|\"\"|0)");
        Matcher m = pat.matcher(s);
        return m.replaceAll("\"priority\": " + p);
    }

    int dispatchHelp(List<String> args) {
        if (args.isEmpty()) { printHelp(); return 0; }
        switch (args.get(0)) {
            case "print-config": case "pc": printPrintConfigHelp(); return 0;
            case "import-journals": case "imj": printImportHelp(); return 0;
            case "assign-priority": case "ap": printAssignHelp(); return 0;
            case "theme": case "style": printThemeHelp(); return 0;
            default: printHelp(); return 0;
        }
    }

    static boolean hasHelp(List<String> xs) { return xs.contains("--help") || xs.contains("-h"); }

    static void printHelp() {
        System.out.println("Tui app allows writing and managing journals/notes from within the terminal With different local back-ends");
        System.out.println();
        System.out.println("Usage: executable [OPTIONS] [COMMAND]");
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  print-config     Print the current settings including the paths for the back-end files [aliases: pc]");
        System.out.println("  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]");
        System.out.println("  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]");
        System.out.println("  theme            Provides commands regarding changing themes and styles of the app [aliases: style]");
        System.out.println("  help             Print this message or the help of the given subcommand(s)");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it");
        System.out.println("  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it");
        System.out.println("  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]");
        System.out.println("  -c, --config <DIR PATH>             Specifies the path for the configuration directory.");
        System.out.println("                                      Configuration files is considered as root for themes file too.");
        System.out.println("                                      It still accepts the path for configuration file for backward compatibility.");
        System.out.println("                                      (default path: " + DEFAULT_CONFIG + ")");
        System.out.println("  -v, --verbose...                    Increases logging verbosity each use for up to 3 times");
        System.out.println("  -l, --log <FILE PATH>               Specifies a file to use for logging");
        System.out.println("                                      (default file: " + DEFAULT_LOG + ")");
        System.out.println("  -h, --help                          Print help");
        System.out.println("  -V, --version                       Print version");
    }

    static void printPrintConfigHelp() {
        System.out.println("Print the current settings including the paths for the back-end files");
        System.out.println();
        System.out.println("Usage: executable print-config");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }
    static void printImportHelp() {
        System.out.println("Import journals from the given transfer JSON file to the current back-end file");
        System.out.println();
        System.out.println("Usage: executable import-journals --path <FILE PATH>");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -p, --path <FILE PATH>  Path of the JSON file to import from");
        System.out.println("  -h, --help              Print help");
    }
    static void printAssignHelp() {
        System.out.println("Assign priority for all the entries with empty priority field");
        System.out.println();
        System.out.println("Usage: executable assign-priority <PRIORITY>");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  <PRIORITY>  Priority value (Positive number)");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }
    static void printThemeHelp() {
        System.out.println("Provides commands regarding changing themes and styles of the app");
        System.out.println();
        System.out.println("Usage: executable theme <COMMAND>");
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  print-path      Prints the path to the user themes file [aliases: path]");
        System.out.println("  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]");
        System.out.println("  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]");
        System.out.println("  help            Print this message or the help of the given subcommand(s)");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  -h, --help  Print help");
    }

    static final String DEFAULT_THEME = """
[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"

""";
}
