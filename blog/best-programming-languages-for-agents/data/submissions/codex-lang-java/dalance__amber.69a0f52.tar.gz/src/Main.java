import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Main {
    private static final String VERSION = "ambr 0.6.0";
    private static final Set<String> VCS = new HashSet<>(Arrays.asList(".git", ".hg", ".svn", ".bzr"));

    private static class Opt {
        boolean keyFromFile, repFromFile, verbose, regex, column, row, binary, statistics, skipped;
        boolean preserveTime, interactive = true, recursive = true, symlink = true;
        boolean color = true, file = true, skipVcs = true, skipGitignore = true;
        boolean fixedOrder = true, parentIgnore = true;
        int binCheckBytes = 256;
        List<String> positional = new ArrayList<>();
    }

    private static class Stats {
        long searchedFiles, skippedFiles, matchedFiles, matches, replacements;
    }

    public static void main(String[] args) {
        try {
            int code = run(args);
            System.exit(code);
        } catch (CliException e) {
            System.err.print(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static int run(String[] args) throws Exception {
        Opt opt = parse(args);
        if (opt.positional.size() < 2) {
            if (opt.positional.isEmpty()) {
                throw new CliException("error: The following required arguments were not provided:\n" +
                        "    <KEYWORD>\n    <REPLACEMENT>\n\n" +
                        usageShort() + "\n\nFor more information try --help\n");
            }
            throw new CliException("error: The following required arguments were not provided:\n" +
                    "    <REPLACEMENT>\n\n" + usageShort() + "\n\nFor more information try --help\n");
        }

        String keyword = opt.positional.get(0);
        String replacement = opt.positional.get(1);
        if (opt.keyFromFile) keyword = Files.readString(Paths.get(keyword), StandardCharsets.UTF_8);
        if (opt.repFromFile) replacement = Files.readString(Paths.get(replacement), StandardCharsets.UTF_8);

        List<Path> roots = new ArrayList<>();
        if (opt.positional.size() > 2) {
            for (int i = 2; i < opt.positional.size(); i++) roots.add(Paths.get(opt.positional.get(i)));
        } else {
            roots.add(Paths.get("."));
        }

        Pattern pattern = null;
        if (opt.regex) {
            try {
                pattern = Pattern.compile(keyword);
            } catch (PatternSyntaxException e) {
                System.err.println("error: " + e.getMessage());
                return 1;
            }
        }

        Stats stats = new Stats();
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        boolean replaceAll = !opt.interactive;
        List<Path> files = collectFiles(roots, opt, stats);
        if (opt.fixedOrder) files.sort(Comparator.comparing(Path::toString));

        for (Path file : files) {
            processFile(file, opt, keyword, replacement, pattern, input, stats, replaceAll);
            if (replaceAll || !opt.interactive) {
                replaceAll = true;
            }
        }

        if (opt.statistics) {
            System.out.println("Searched files: " + stats.searchedFiles);
            System.out.println("Matched files: " + stats.matchedFiles);
            System.out.println("Matches: " + stats.matches);
            System.out.println("Replacements: " + stats.replacements);
            System.out.println("Skipped files: " + stats.skippedFiles);
        }
        return stats.matches > 0 ? 0 : 1;
    }

    private static Opt parse(String[] args) throws CliException {
        Opt opt = new Opt();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-h":
                case "--help":
                    System.out.print(help());
                    System.exit(0);
                    break;
                case "-V":
                case "--version":
                    System.out.println(VERSION);
                    System.exit(0);
                    break;
                case "--key-from-file": opt.keyFromFile = true; break;
                case "--rep-from-file": opt.repFromFile = true; break;
                case "--verbose": opt.verbose = true; break;
                case "-r":
                case "--regex": opt.regex = true; break;
                case "--column": opt.column = true; break;
                case "--row": opt.row = true; break;
                case "--binary": opt.binary = true; break;
                case "--statistics": opt.statistics = true; break;
                case "--skipped": opt.skipped = true; break;
                case "--preserve-time": opt.preserveTime = true; break;
                case "--no-interactive": opt.interactive = false; break;
                case "--no-recursive": opt.recursive = false; break;
                case "--no-symlink": opt.symlink = false; break;
                case "--no-color": opt.color = false; break;
                case "--no-file": opt.file = false; break;
                case "--no-skip-vcs": opt.skipVcs = false; break;
                case "--no-skip-gitignore": opt.skipGitignore = false; break;
                case "--no-fixed-order": opt.fixedOrder = false; break;
                case "--no-parent-ignore": opt.parentIgnore = false; break;
                case "--tbm":
                case "--sse":
                    break;
                case "--max-threads":
                case "--size-per-thread":
                case "--bin-check-bytes":
                case "--mmap-bytes":
                    if (i + 1 >= args.length) throw new CliException("error: The argument '" + a + "' requires a value but none was supplied\n");
                    if ("--bin-check-bytes".equals(a)) {
                        try { opt.binCheckBytes = Integer.parseInt(args[++i]); } catch (NumberFormatException e) { opt.binCheckBytes = 256; }
                    } else {
                        i++;
                    }
                    break;
                default:
                    if (a.startsWith("--")) throw new CliException("error: Found argument '" + a + "' which wasn't expected\n\n" + usageShort() + "\n\nFor more information try --help\n");
                    opt.positional.add(a);
            }
        }
        return opt;
    }

    private static List<Path> collectFiles(List<Path> roots, Opt opt, Stats stats) throws IOException {
        List<Path> files = new ArrayList<>();
        for (Path root : roots) {
            if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) {
                if (opt.skipped || opt.verbose) System.err.println("Skipped: " + root);
                stats.skippedFiles++;
                continue;
            }
            if (Files.isRegularFile(root, LinkOption.NOFOLLOW_LINKS)) {
                if (!isIgnored(root, root.getParent(), opt)) files.add(root);
                continue;
            }
            if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) continue;
            int maxDepth = opt.recursive ? Integer.MAX_VALUE : 1;
            Set<java.nio.file.FileVisitOption> visitOpts = opt.symlink
                    ? java.util.EnumSet.of(java.nio.file.FileVisitOption.FOLLOW_LINKS)
                    : java.util.EnumSet.noneOf(java.nio.file.FileVisitOption.class);
            Files.walkFileTree(root, visitOpts, maxDepth, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(root) && opt.skipVcs && VCS.contains(dir.getFileName().toString())) {
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                    if (!dir.equals(root) && isIgnored(dir, root, opt)) {
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (attrs.isRegularFile() && !isIgnored(file, root, opt)) files.add(file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        return files;
    }

    private static boolean isIgnored(Path path, Path root, Opt opt) {
        if (!opt.skipGitignore) return false;
        String name = path.getFileName() == null ? path.toString() : path.getFileName().toString();
        Path base = root == null ? Paths.get(".") : root;
        Path absBase = base.toAbsolutePath().normalize();
        Path absPath = path.toAbsolutePath().normalize();
        List<String> patterns = new ArrayList<>();
        try {
            Path cur = absBase;
            if (Files.isRegularFile(cur)) cur = cur.getParent();
            while (cur != null) {
                Path gi = cur.resolve(".gitignore");
                if (Files.isRegularFile(gi)) patterns.addAll(Files.readAllLines(gi, StandardCharsets.UTF_8));
                if (!opt.parentIgnore || cur.equals(absBase.getRoot())) break;
                if (cur.equals(absBase)) {
                    cur = cur.getParent();
                } else if (!absBase.startsWith(cur)) {
                    break;
                } else {
                    cur = cur.getParent();
                }
            }
        } catch (IOException ignored) {
        }
        String rel = absBase.relativize(absPath).toString().replace('\\', '/');
        for (String raw : patterns) {
            String p = raw.trim();
            if (p.isEmpty() || p.startsWith("#") || p.startsWith("!")) continue;
            boolean dirOnly = p.endsWith("/");
            if (dirOnly) p = p.substring(0, p.length() - 1);
            if (p.startsWith("/")) p = p.substring(1);
            if (matchesIgnore(p, rel, name)) return true;
        }
        return false;
    }

    private static boolean matchesIgnore(String pattern, String rel, String name) {
        if (pattern.indexOf('/') < 0) {
            if (glob(pattern).matcher(name).matches()) return true;
            for (String part : rel.split("/")) if (glob(pattern).matcher(part).matches()) return true;
            return false;
        }
        return glob(pattern).matcher(rel).matches();
    }

    private static Pattern glob(String pattern) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < pattern.length(); i++) {
            char c = pattern.charAt(i);
            if (c == '*') b.append(".*");
            else if (c == '?') b.append('.');
            else b.append(Pattern.quote(String.valueOf(c)));
        }
        return Pattern.compile(b.toString());
    }

    private static void processFile(Path file, Opt opt, String keyword, String replacement, Pattern pattern,
                                    BufferedReader input, Stats stats, boolean replaceAllInitial) throws IOException {
        if (!opt.binary && isBinary(file, opt.binCheckBytes)) {
            stats.skippedFiles++;
            if (opt.skipped) System.err.println("Skipped: " + file);
            return;
        }
        stats.searchedFiles++;
        byte[] originalBytes = Files.readAllBytes(file);
        String text = new String(originalBytes, StandardCharsets.UTF_8);
        String[] lines = text.split("\\R", -1);
        boolean hadTrailingNewline = text.endsWith("\n") || text.endsWith("\r");
        boolean changed = false;
        boolean matchedFile = false;
        boolean replaceAll = replaceAllInitial;
        StringBuilder out = new StringBuilder();

        int offset = 0;
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (i == lines.length - 1 && line.isEmpty() && hadTrailingNewline) break;
            MatchResult mr = replaceLine(line, opt, keyword, replacement, pattern, file, i + 1, input, replaceAll);
            if (mr.matches > 0) {
                matchedFile = true;
                stats.matches += mr.matches;
                stats.replacements += mr.replacements;
                changed |= mr.replacements > 0;
                if (mr.all) replaceAll = true;
            }
            if (i > 0) out.append('\n');
            out.append(mr.line);
            offset += line.length() + 1;
        }
        if (hadTrailingNewline) out.append('\n');
        if (matchedFile) stats.matchedFiles++;
        if (changed) {
            long mtime = 0L;
            if (opt.preserveTime) mtime = Files.getLastModifiedTime(file).toMillis();
            Files.writeString(file, out.toString(), StandardCharsets.UTF_8);
            if (opt.preserveTime) Files.setLastModifiedTime(file, java.nio.file.attribute.FileTime.fromMillis(mtime));
        }
    }

    private static class MatchResult {
        String line;
        long matches, replacements;
        boolean all;
        MatchResult(String line) { this.line = line; }
    }

    private static MatchResult replaceLine(String line, Opt opt, String keyword, String replacement, Pattern pattern,
                                           Path file, int row, BufferedReader input, boolean replaceAll) throws IOException {
        MatchResult res = new MatchResult(line);
        Matcher matcher = opt.regex ? pattern.matcher(line) : Pattern.compile(Pattern.quote(keyword)).matcher(line);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            res.matches++;
            int col = matcher.start() + 1;
            printMatch(opt, file, row, col, line, matcher.start(), matcher.end());
            boolean doReplace = replaceAll;
            if (opt.interactive && !replaceAll) {
                System.out.print("Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ): ");
                System.out.flush();
                String ans = input.readLine();
                if (ans == null) ans = "";
                String norm = ans.trim().toLowerCase();
                if (norm.equals("q") || norm.equals("quit")) {
                    matcher.appendTail(sb);
                    res.line = sb.toString();
                    return res;
                } else if (norm.equals("a") || norm.equals("all")) {
                    res.all = true;
                    replaceAll = true;
                    doReplace = true;
                } else if (norm.equals("y") || norm.equals("yes")) {
                    doReplace = true;
                }
            }
            if (doReplace) {
                res.replacements++;
                String rep = opt.regex ? normalizeReplacement(replacement) : Matcher.quoteReplacement(replacement);
                matcher.appendReplacement(sb, rep);
            }
        }
        matcher.appendTail(sb);
        res.line = sb.toString();
        return res;
    }

    private static String normalizeReplacement(String replacement) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < replacement.length(); i++) {
            char c = replacement.charAt(i);
            if (c != '$' || i + 1 >= replacement.length()) {
                out.append(c);
                continue;
            }
            char n = replacement.charAt(i + 1);
            if (n == '{') {
                int end = replacement.indexOf('}', i + 2);
                if (end > i) {
                    String name = replacement.substring(i + 2, end);
                    if (name.matches("[0-9]+")) out.append('$').append(name);
                    else out.append("${").append(name).append('}');
                    i = end;
                    continue;
                }
            } else if (Character.isLetter(n)) {
                int j = i + 2;
                while (j < replacement.length()) {
                    char x = replacement.charAt(j);
                    if (!Character.isLetterOrDigit(x) && x != '_') break;
                    j++;
                }
                out.append("${").append(replacement, i + 1, j).append('}');
                i = j - 1;
                continue;
            }
            out.append(c);
        }
        return out.toString();
    }

    private static void printMatch(Opt opt, Path file, int row, int col, String line, int start, int end) {
        StringBuilder prefix = new StringBuilder();
        if (opt.file) prefix.append(file).append(':');
        if (opt.row) prefix.append(row).append(':');
        if (opt.column) prefix.append(col).append(':');
        if (opt.color) {
            System.out.println(prefix + line.substring(0, start) + "\u001b[31m" + line.substring(start, end) + "\u001b[0m" + line.substring(end));
        } else {
            System.out.println(prefix + line);
        }
    }

    private static boolean isBinary(Path file, int n) {
        try {
            byte[] bytes = Files.readAllBytes(file);
            int limit = Math.min(Math.max(n, 0), bytes.length);
            for (int i = 0; i < limit; i++) if (bytes[i] == 0) return true;
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    private static String usageShort() {
        return "USAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>";
    }

    private static String help() {
        return VERSION + "\n\n" +
                "USAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\n" +
                "FLAGS:\n" +
                "        --key-from-file        Use file contents of KEYWORD as keyword for search\n" +
                "        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement\n" +
                "        --verbose              Verbose message\n" +
                "    -r, --regex                Enable regular expression search\n" +
                "        --column               Enable column output\n" +
                "        --row                  Enable row output\n" +
                "        --binary               Enable binary file search\n" +
                "        --statistics           Enable statistics output\n" +
                "        --skipped              Enable skipped file output\n" +
                "        --preserve-time        Enable timestamp preserve\n" +
                "        --no-interactive       Disable interactive replace\n" +
                "        --no-recursive         Disable recursive directory search\n" +
                "        --no-symlink           Disable symbolic link follow\n" +
                "        --no-color             Disable colored output\n" +
                "        --no-file              Disable filename output\n" +
                "        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip\n" +
                "        --no-skip-gitignore    Disable .gitignore skip\n" +
                "        --no-fixed-order       Disable output order guarantee\n" +
                "        --no-parent-ignore     Disable .*ignore file search at parent directories\n" +
                "        --tbm                  [Experimental] Enable TBM matcher\n" +
                "        --sse                  [Experimental] Enable SSE 4.2\n" +
                "    -h, --help                 Prints help information\n" +
                "    -V, --version              Prints version information\n\n" +
                "OPTIONS:\n" +
                "        --max-threads <NUM>          Number of max threads [default: 4]\n" +
                "        --size-per-thread <BYTES>    File size per one thread [default: 1048576]\n" +
                "        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]\n" +
                "        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]\n\n" +
                "ARGS:\n" +
                "    <KEYWORD>        Keyword for search\n" +
                "    <REPLACEMENT>    Keyword for replace\n" +
                "    <PATHS>...       Search paths\n";
    }

    private static class CliException extends Exception {
        CliException(String message) { super(message); }
    }
}
