package rnrclone;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Main {
    static final String VERSION = "rnr 0.5.1";

    public static void main(String[] args) {
        try {
            int code = new Main().run(args);
            System.exit(code);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    int run(String[] args) throws Exception {
        if (args.length == 0 || eq(args[0], "-h", "--help")) {
            printTopHelp();
            return 0;
        }
        if (eq(args[0], "-V", "--version")) {
            System.out.println(VERSION);
            return 0;
        }
        switch (args[0]) {
            case "help":
                if (args.length > 1) return run(new String[]{args[1], "--help"});
                printTopHelp();
                return 0;
            case "regex":
                return regex(Arrays.copyOfRange(args, 1, args.length));
            case "to-ascii":
                return toAscii(Arrays.copyOfRange(args, 1, args.length));
            case "from-file":
                return fromFile(Arrays.copyOfRange(args, 1, args.length));
            default:
                System.err.println("error: unrecognized subcommand '" + args[0] + "'\n");
                System.err.println("Usage: executable <COMMAND>\n");
                System.err.println("For more information, try '--help'.");
                return 2;
        }
    }

    int regex(String[] args) throws Exception {
        if (hasHelp(args)) { printRegexHelp(); return 0; }
        Options opt = parseCommon(args, 3);
        if (opt.rest.size() < 3) { printRegexHelp(); return 2; }
        String expr = opt.rest.get(0), repl = opt.rest.get(1);
        Pattern pat;
        try {
            pat = Pattern.compile(expr);
        } catch (PatternSyntaxException e) {
            System.err.println("Error: Bad expression provided\n");
            System.err.println("regex parse error:");
            System.err.println("    " + expr);
            System.err.println("    ^");
            System.err.println("error: " + friendlyPatternError(e));
            return 1;
        }
        List<Operation> ops = new ArrayList<>();
        for (int i = 2; i < opt.rest.size(); i++) {
            Path p = Paths.get(opt.rest.get(i));
            collect(p, opt, path -> {
                String name = path.getFileName().toString();
                Matcher m = pat.matcher(name);
                String nn = replaceLimited(m, repl, opt.replaceLimit, opt.transform);
                if (!name.equals(nn)) ops.add(new Operation(path.toString(), path.resolveSibling(nn).toString()));
            });
        }
        return execute(ops, opt);
    }

    int toAscii(String[] args) throws Exception {
        if (hasHelp(args)) { printAsciiHelp(); return 0; }
        Options opt = parseCommon(args, 1);
        if (opt.rest.isEmpty()) { printAsciiHelp(); return 2; }
        List<Operation> ops = new ArrayList<>();
        for (String s : opt.rest) {
            collect(Paths.get(s), opt, path -> {
                String name = path.getFileName().toString();
                String nn = ascii(name);
                if (!name.equals(nn)) ops.add(new Operation(path.toString(), path.resolveSibling(nn).toString()));
            });
        }
        return execute(ops, opt);
    }

    int fromFile(String[] args) throws Exception {
        if (hasHelp(args)) { printFromFileHelp(); return 0; }
        Options opt = parseCommon(args, 1);
        if (opt.rest.isEmpty()) { printFromFileHelp(); return 2; }
        List<Operation> ops = readDump(Paths.get(opt.rest.get(0)));
        if (opt.undo) {
            List<Operation> rev = new ArrayList<>();
            for (int i = ops.size() - 1; i >= 0; i--) {
                Operation o = ops.get(i);
                rev.add(new Operation(o.target, o.source));
            }
            ops = rev;
        }
        return execute(ops, opt);
    }

    interface PathConsumer { void accept(Path p) throws IOException; }

    void collect(Path root, Options opt, PathConsumer consumer) throws IOException {
        if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return;
        if (!opt.recursive) {
            if (Files.isRegularFile(root, LinkOption.NOFOLLOW_LINKS)) consumer.accept(root);
            return;
        }
        int max = opt.maxDepth == null ? Integer.MAX_VALUE : opt.maxDepth;
        traverse(root, root, 0, max, opt, consumer);
    }

    void traverse(Path root, Path dir, int depth, int max, Options opt, PathConsumer consumer) throws IOException {
        if (depth >= max) return;
        List<Path> dirs = new ArrayList<>(), files = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path child : stream) {
                if (isHidden(root, child, opt)) continue;
                if (Files.isDirectory(child, LinkOption.NOFOLLOW_LINKS)) dirs.add(child);
                else if (Files.isRegularFile(child, LinkOption.NOFOLLOW_LINKS)) files.add(child);
            }
        }
        files.sort(Comparator.comparing(p -> p.getFileName().toString()));
        for (Path d : dirs) {
            traverse(root, d, depth + 1, max, opt, consumer);
            if (opt.includeDirs) consumer.accept(d);
        }
        for (Path f : files) consumer.accept(f);
    }

    boolean isHidden(Path root, Path p, Options opt) {
        if (opt.hidden) return false;
        Path rel = root.equals(p) ? p : root.relativize(p);
        for (Path part : rel) if (part.toString().startsWith(".")) return true;
        return p.getFileName() != null && p.getFileName().toString().startsWith(".");
    }

    int execute(List<Operation> ops, Options opt) throws IOException {
        if (!opt.silent && !opt.force) System.out.println("This is a DRY-RUN");
        Set<String> targets = new HashSet<>();
        for (Operation o : ops) {
            if (!targets.add(o.target) || (Files.exists(Paths.get(o.target)) && !Paths.get(o.source).equals(Paths.get(o.target)))) {
                System.err.println("Error: Conflict with existing path " + o.source + " -> " + o.target);
                return 1;
            }
        }
        for (Operation o : ops) {
            if (!opt.silent && opt.backup && opt.force) System.out.println("Info:  Backup created - " + o.source + " -> " + o.source + ".bk");
            if (!opt.silent) System.out.println(o.source + " -> " + o.target);
            if (opt.force) {
                Path src = Paths.get(o.source), dst = Paths.get(o.target);
                if (opt.backup) Files.copy(src, Paths.get(o.source + ".bk"), StandardCopyOption.REPLACE_EXISTING);
                Files.move(src, dst);
            }
        }
        if ((opt.force && !opt.noDump) || (opt.dump && !opt.noDump)) writeDump(ops, opt.dumpPrefix);
        return 0;
    }

    static String replaceLimited(Matcher m, String repl, int limit, String transform) {
        StringBuffer sb = new StringBuffer();
        int n = 0;
        while (m.find() && (limit == 0 || n < limit)) {
            String r = expand(m, repl);
            r = transform(r, transform);
            m.appendReplacement(sb, Matcher.quoteReplacement(r));
            n++;
        }
        m.appendTail(sb);
        return sb.toString();
    }

    static String expand(Matcher m, String repl) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < repl.length(); i++) {
            char c = repl.charAt(i);
            if (c == '$' && i + 1 < repl.length() && Character.isDigit(repl.charAt(i + 1))) {
                int j = i + 1, num = 0;
                while (j < repl.length() && Character.isDigit(repl.charAt(j))) num = num * 10 + repl.charAt(j++) - '0';
                try { String g = m.group(num); if (g != null) out.append(g); } catch (Exception ignored) {}
                i = j - 1;
            } else {
                out.append(c);
            }
        }
        return out.toString();
    }

    static String transform(String s, String t) {
        if ("upper".equals(t)) return s.toUpperCase(Locale.ROOT);
        if ("lower".equals(t)) return s.toLowerCase(Locale.ROOT);
        if ("ascii".equals(t)) return ascii(s);
        return s;
    }

    static String ascii(String s) {
        String x = s.replace("ß", "ss").replace("ø", "o").replace("Ø", "O").replace("ð", "d").replace("Ð", "D")
                .replace("þ", "th").replace("Þ", "Th").replace("æ", "ae").replace("Æ", "AE")
                .replace("œ", "oe").replace("Œ", "OE").replace("ñ", "n").replace("Ñ", "N");
        String norm = Normalizer.normalize(x, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < norm.length(); i++) {
            char c = norm.charAt(i);
            if (c < 128) out.append(c);
        }
        return out.toString();
    }

    Options parseCommon(String[] args, int minRest) {
        Options o = new Options();
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            switch (a) {
                case "-n": case "--dry-run": o.force = false; break;
                case "-f": case "--force": o.force = true; break;
                case "-b": case "--backup": o.backup = true; break;
                case "-s": case "--silent": o.silent = true; break;
                case "--dump": o.dump = true; break;
                case "--no-dump": o.noDump = true; break;
                case "--dump-prefix": o.dumpPrefix = args[++i]; break;
                case "--color": i++; break;
                case "-l": case "--replace-limit": o.replaceLimit = Integer.parseInt(args[++i]); break;
                case "-t": case "--replace-transform": o.transform = args[++i]; break;
                case "-D": case "--include-dirs": o.includeDirs = true; break;
                case "-r": case "--recursive": o.recursive = true; break;
                case "-d": case "--max-depth": o.maxDepth = Integer.parseInt(args[++i]); break;
                case "-x": case "--hidden": o.hidden = true; break;
                case "-u": case "--undo": o.undo = true; break;
                default: o.rest.add(a);
            }
        }
        return o;
    }

    void writeDump(List<Operation> ops, String prefix) throws IOException {
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HHmmss"));
        String date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        Path p = Paths.get(prefix + stamp + ".json");
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"date\": \"").append(date).append("\",\n  \"operations\": [\n");
        for (int i = 0; i < ops.size(); i++) {
            Operation o = ops.get(i);
            sb.append("    {\n      \"source\": \"").append(json(o.source)).append("\",\n      \"target\": \"").append(json(o.target)).append("\"\n    }");
            if (i + 1 < ops.size()) sb.append(",");
            sb.append("\n");
        }
        sb.append("  ]\n}");
        Files.writeString(p, sb.toString(), StandardCharsets.UTF_8);
    }

    List<Operation> readDump(Path p) throws IOException {
        String s = Files.readString(p, StandardCharsets.UTF_8);
        Pattern pat = Pattern.compile("\\{\\s*\"source\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"\\s*,\\s*\"target\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"", Pattern.DOTALL);
        Matcher m = pat.matcher(s);
        List<Operation> ops = new ArrayList<>();
        while (m.find()) ops.add(new Operation(unjson(m.group(1)), unjson(m.group(2))));
        return ops;
    }

    static String json(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }
    static String unjson(String s) { return s.replace("\\\"", "\"").replace("\\\\", "\\"); }
    static boolean hasHelp(String[] a) { for (String s : a) if (eq(s, "-h", "--help")) return true; return false; }
    static boolean eq(String s, String... vals) { for (String v : vals) if (v.equals(s)) return true; return false; }
    static String friendlyPatternError(PatternSyntaxException e) {
        String m = e.getDescription();
        if (m.toLowerCase(Locale.ROOT).contains("unclosed character class")) return "unclosed character class";
        return m;
    }

    static class Operation { String source, target; Operation(String s, String t) { source = s; target = t; } }
    static class Options {
        boolean force, backup, silent, dump, noDump, includeDirs, recursive, hidden, undo;
        String dumpPrefix = "rnr-", transform = null;
        Integer maxDepth = null;
        int replaceLimit = 1;
        List<String> rest = new ArrayList<>();
    }

    void printTopHelp() {
        System.out.println("RnR is a command-line tool to rename multiple files and directories that\nsupports regular expressions\n\n\nUsage: executable <COMMAND>\n\nCommands:\n  regex      Rename files and directories using a regular expression\n  from-file  Read operations from a dump file\n  to-ascii   Replace file name UTF-8 chars with ASCII chars representation\n  help       Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version");
    }
    void printRegexHelp() {
        System.out.println("Rename files and directories using a regular expression\n\nUsage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...\n\nArguments:\n  <EXPRESSION>   Expression to match (can be a regex)\n  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)\n  <PATH(S)>...   Target paths\n\nOptions:\n  -n, --dry-run\n          Only show what would be done (default mode)\n  -f, --force\n          Make actual changes to files\n  -b, --backup\n          Generate file backups before renaming\n  -s, --silent\n          Do not print any information\n      --color <COLOR>\n          Set color output mode [default: auto] [possible values: always, never, auto]\n      --dump\n          Force dumping operations into a file even in dry-run mode\n      --dump-prefix <DUMP_PREFIX>\n          Set the dump file prefix [default: rnr-]\n      --no-dump\n          Do not dump operations into a file\n  -l, --replace-limit <LIMIT>\n          Limit of replacements, all matches if set to 0\n  -t, --replace-transform <REPLACE_TRANSFORM>\n          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]\n  -D, --include-dirs\n          Rename matching directories\n  -r, --recursive\n          Recursive mode\n  -d, --max-depth <LEVEL>\n          Set max depth in recursive mode\n  -x, --hidden\n          Include hidden files and directories\n  -h, --help\n          Print help");
    }
    void printFromFileHelp() {
        System.out.println("Read operations from a dump file\n\nUsage: executable from-file [OPTIONS] <DUMPFILE>\n\nArguments:\n  <DUMPFILE>  \n\nOptions:\n  -n, --dry-run                    Only show what would be done (default mode)\n  -f, --force                      Make actual changes to files\n  -b, --backup                     Generate file backups before renaming\n  -s, --silent                     Do not print any information\n      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]\n      --dump                       Force dumping operations into a file even in dry-run mode\n      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]\n      --no-dump                    Do not dump operations into a file\n  -u, --undo                       Undo the operations from the dump file\n  -h, --help                       Print help");
    }
    void printAsciiHelp() {
        System.out.println("Replace file name UTF-8 chars with ASCII chars representation\n\nUsage: executable to-ascii [OPTIONS] <PATH(S)>...\n\nArguments:\n  <PATH(S)>...  Target paths\n\nOptions:\n  -n, --dry-run                    Only show what would be done (default mode)\n  -f, --force                      Make actual changes to files\n  -b, --backup                     Generate file backups before renaming\n  -s, --silent                     Do not print any information\n      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]\n      --dump                       Force dumping operations into a file even in dry-run mode\n      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]\n      --no-dump                    Do not dump operations into a file\n  -D, --include-dirs               Rename matching directories\n  -r, --recursive                  Recursive mode\n  -d, --max-depth <LEVEL>          Set max depth in recursive mode\n  -x, --hidden                     Include hidden files and directories\n  -h, --help                       Print help");
    }
}
