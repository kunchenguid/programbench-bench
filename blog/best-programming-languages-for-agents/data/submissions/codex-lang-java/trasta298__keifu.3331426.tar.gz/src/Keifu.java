import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class Keifu {
    private static final String HELP = """
A TUI tool to visualize Git commit graphs with branch genealogy

Usage: executable

Options:
  -h, --help     Print help
  -V, --version  Print version
""";

    private record CmdResult(int code, String out, String err) {}
    private record Commit(String hash, String shortHash, String date, String isoDate, String author, String email, String refs, String subject, String body) {}
    private record FileStat(String status, String path, int adds, int dels) {}

    public static void main(String[] args) throws Exception {
        if (!parseArgs(args)) {
            return;
        }

        if (!isGitRepository()) {
            System.err.println("Error: Git repository not found. Please run inside a Git repository.");
            System.err.println();
            System.err.println("Caused by:");
            System.err.println("    could not find repository at '.'; class=Repository (6); code=NotFound (-3)");
            System.exit(1);
        }

        if (System.console() == null) {
            System.err.println("Error: No such device or address (os error 6)");
            System.exit(1);
        }

        List<Commit> commits = loadCommits();
        if (commits.isEmpty()) {
            System.err.println("Error: No commits found.");
            System.exit(1);
        }

        enterRawMode();
        try {
            render(commits, 0, false);
            runEventLoop(commits);
        } finally {
            leaveRawMode();
            System.out.print("\u001b[?1049l\u001b[?25h");
            System.out.flush();
        }
    }

    private static boolean parseArgs(String[] args) {
        if (args.length == 0) {
            return true;
        }
        if (args.length == 1 && (args[0].equals("-h") || args[0].equals("--help"))) {
            System.out.print(HELP);
            return false;
        }
        if (args.length == 1 && (args[0].equals("-V") || args[0].equals("--version"))) {
            System.out.println("keifu 0.2.3");
            return false;
        }
        String first = args[0];
        if (first.startsWith("-")) {
            System.err.println("error: unexpected argument '" + first + "' found");
        } else {
            System.err.println("error: unexpected argument '" + first + "' found");
        }
        System.err.println();
        System.err.println("Usage: executable");
        System.err.println();
        System.err.println("For more information, try '--help'.");
        System.exit(2);
        return false;
    }

    private static boolean isGitRepository() throws IOException, InterruptedException {
        CmdResult r = run("git", "rev-parse", "--git-dir");
        return r.code == 0;
    }

    private static List<Commit> loadCommits() throws IOException, InterruptedException {
        CmdResult r = run("git", "log", "--all", "--date=format:%Y-%m-%d", "--pretty=format:%H%x1f%h%x1f%ad%x1f%ai%x1f%an%x1f%ae%x1f%D%x1f%s%x1f%b%x1e", "-500");
        List<Commit> commits = new ArrayList<>();
        for (String rec : r.out.split("\u001e")) {
            while (rec.startsWith("\n") || rec.startsWith("\r")) {
                rec = rec.substring(1);
            }
            if (rec.isEmpty()) continue;
            String[] p = rec.split("\u001f", -1);
            if (p.length < 9) continue;
            commits.add(new Commit(p[0], p[1], p[2], normalizeDate(p[3]), p[4], p[5], cleanRefs(p[6]), p[7], p[8].strip()));
        }
        return commits;
    }

    private static String normalizeDate(String gitDate) {
        if (gitDate == null || gitDate.length() < 19) return "";
        return gitDate.substring(0, 19);
    }

    private static String cleanRefs(String refs) {
        if (refs == null || refs.isBlank()) return "";
        List<String> labels = new ArrayList<>();
        for (String raw : refs.split(",")) {
            String s = raw.trim();
            if (s.equals("HEAD")) continue;
            if (s.startsWith("HEAD -> ")) s = s.substring(8);
            if (s.startsWith("tag: ")) s = s.substring(5);
            if (s.startsWith("origin/HEAD -> ")) continue;
            labels.add(s);
        }
        return String.join(", ", labels);
    }

    private static void runEventLoop(List<Commit> commits) throws IOException, InterruptedException {
        int selected = 0;
        boolean help = false;
        InputStream in = System.in;
        while (true) {
            int c = in.read();
            if (c < 0 || c == 'q' || c == 27) return;
            if (c == 'j' || c == 'B') selected = Math.min(selected + 1, commits.size() - 1);
            if (c == 'k' || c == 'A') selected = Math.max(selected - 1, 0);
            if (c == 'g') selected = 0;
            if (c == 'G') selected = commits.size() - 1;
            if (c == '?') help = !help;
            if (c == 'R') commits = loadCommits();
            if (c == 'f') run("git", "fetch", "origin");
            render(commits, selected, help);
        }
    }

    private static void render(List<Commit> commits, int selected, boolean help) throws IOException, InterruptedException {
        int[] size = terminalSize();
        int rows = Math.max(12, size[0]);
        int cols = Math.max(60, size[1]);
        int listHeight = Math.max(5, rows - 8);
        Commit current = commits.get(Math.max(0, Math.min(selected, commits.size() - 1)));
        List<FileStat> stats = loadStats(current.hash);

        StringBuilder s = new StringBuilder();
        s.append("\u001b[?1049h\u001b[?25l\u001b[1;1H\u001b[0m");
        s.append(borderTop("Commits", cols));
        int offset = Math.max(0, selected - listHeight + 2);
        for (int i = 0; i < listHeight; i++) {
            int idx = offset + i;
            if (idx < commits.size()) {
                Commit c = commits.get(idx);
                boolean sel = idx == selected;
                String refs = c.refs.isEmpty() ? "" : "[" + c.refs + "] ";
                String line = " " + (sel ? "◉" : "○") + "  " + refs + c.subject;
                String suffix = " " + c.date + "  " + abbreviate(c.author, 8) + "  " + c.shortHash + " ";
                s.append(row(line, suffix, cols, sel));
            } else {
                s.append(emptyRow(cols));
            }
        }
        s.append(borderBottom(cols));

        if (help) {
            s.append(borderTop("Help", cols));
            s.append(row(" j/k move  g/G top/bottom  R refresh  f fetch", "", cols, false));
            s.append(row(" Enter checkout  b create branch  d delete branch  / search", "", cols, false));
            s.append(row(" ? help  q quit", "", cols, false));
            s.append(borderBottom(cols));
        } else {
            int rightStart = Math.max(34, cols / 2);
            s.append(borderTopSplit("Commit Detail", "Changed Files", cols, rightStart));
            s.append(splitRow("Commit: " + current.hash, statSummary(stats), cols, rightStart));
            s.append(splitRow("Author: " + current.author + " <" + current.email + ">", "", cols, rightStart));
            s.append(splitRow("Date:   " + current.isoDate, "", cols, rightStart));
            String message = current.body.isBlank() ? current.subject : current.subject + " " + current.body.replace('\n', ' ');
            s.append(splitRow(message, "", cols, rightStart));
            int maxFiles = Math.max(1, rows - listHeight - 7);
            for (int i = 0; i < maxFiles; i++) {
                String right = i < stats.size() ? formatStat(stats.get(i)) : "";
                s.append(splitRow("", right, cols, rightStart));
            }
            s.append(borderBottomSplit(cols, rightStart));
        }
        s.append(statusLine(cols));
        System.out.print(s);
        System.out.flush();
    }

    private static List<FileStat> loadStats(String hash) throws IOException, InterruptedException {
        CmdResult r = run("git", "show", "--format=", "--numstat", hash);
        List<FileStat> stats = new ArrayList<>();
        for (String line : r.out.split("\\R")) {
            if (line.isBlank()) continue;
            String[] parts = line.split("\\t");
            if (parts.length >= 3) {
                int adds = parseNum(parts[0]);
                int dels = parseNum(parts[1]);
                String status = dels == 0 && adds > 0 ? "A" : adds == 0 && dels > 0 ? "D" : "M";
                stats.add(new FileStat(status, parts[2], adds, dels));
            }
        }
        return stats;
    }

    private static int parseNum(String s) {
        try { return Integer.parseInt(s); } catch (Exception e) { return 0; }
    }

    private static String statSummary(List<FileStat> stats) {
        int adds = 0, dels = 0;
        for (FileStat f : stats) { adds += f.adds; dels += f.dels; }
        return stats.size() + " files changed  +" + adds + " -" + dels;
    }

    private static String formatStat(FileStat f) {
        return " " + f.status + " " + f.path + " +" + f.adds + " -" + f.dels;
    }

    private static String borderTop(String title, int cols) {
        return "┌ " + title + " " + repeat("─", Math.max(0, cols - title.length() - 4)) + "┐\n";
    }

    private static String borderBottom(int cols) {
        return "└" + repeat("─", Math.max(0, cols - 2)) + "┘\n";
    }

    private static String borderTopSplit(String left, String right, int cols, int split) {
        int leftW = split - 1;
        int rightW = cols - split;
        return "┌ " + left + " " + repeat("─", Math.max(0, leftW - left.length() - 3)) + "┐"
                + "┌ " + right + " " + repeat("─", Math.max(0, rightW - right.length() - 3)) + "┐\n";
    }

    private static String borderBottomSplit(int cols, int split) {
        return "└" + repeat("─", Math.max(0, split - 2)) + "┘└" + repeat("─", Math.max(0, cols - split - 1)) + "┘\n";
    }

    private static String row(String left, String suffix, int cols, boolean selected) {
        int inner = cols - 2;
        String content;
        if (suffix.isEmpty()) {
            content = fit(left, inner);
        } else {
            int leftW = Math.max(0, inner - suffix.length());
            content = fit(left, leftW) + fit(suffix, suffix.length());
        }
        return "│" + (selected ? "\u001b[1;48;5;8m" : "") + content + (selected ? "\u001b[0m" : "") + "│\n";
    }

    private static String splitRow(String left, String right, int cols, int split) {
        int leftW = split - 2;
        int rightW = cols - split - 1;
        return "│" + fit(left, leftW) + "││" + fit(right, rightW) + "│\n";
    }

    private static String emptyRow(int cols) {
        return "│" + repeat(" ", Math.max(0, cols - 2)) + "│\n";
    }

    private static String statusLine(int cols) throws IOException, InterruptedException {
        String repo = new File(".").getCanonicalFile().getName();
        CmdResult branch = run("git", "branch", "--show-current");
        String b = branch.out.strip().isEmpty() ? "detached" : branch.out.strip();
        String line = " " + repo + "  " + b + "  j/k move  Enter checkout  b branch  f fetch  ? help  q quit";
        return fit(line, cols) + "\u001b[0m";
    }

    private static String fit(String text, int width) {
        String clean = text == null ? "" : text.replace('\n', ' ');
        if (width <= 0) return "";
        if (clean.codePointCount(0, clean.length()) > width) {
            int end = clean.offsetByCodePoints(0, Math.max(0, width - 1));
            return clean.substring(0, end) + "…";
        }
        return clean + repeat(" ", width - clean.codePointCount(0, clean.length()));
    }

    private static String abbreviate(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n);
    }

    private static String repeat(String s, int n) {
        return s.repeat(Math.max(0, n));
    }

    private static int[] terminalSize() {
        try {
            CmdResult r = run("sh", "-c", "stty size < /dev/tty");
            String[] p = r.out.trim().split("\\s+");
            if (p.length == 2) return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
        } catch (Exception ignored) {
        }
        return new int[]{24, 100};
    }

    private static void enterRawMode() {
        try { run("sh", "-c", "stty raw -echo < /dev/tty"); } catch (Exception ignored) {}
    }

    private static void leaveRawMode() {
        try { run("sh", "-c", "stty sane < /dev/tty"); } catch (Exception ignored) {}
    }

    private static CmdResult run(String... cmd) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(cmd);
        Process p = pb.start();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        Thread t1 = new Thread(() -> copy(p.getInputStream(), out));
        Thread t2 = new Thread(() -> copy(p.getErrorStream(), err));
        t1.start();
        t2.start();
        int code = p.waitFor();
        t1.join();
        t2.join();
        return new CmdResult(code, out.toString(StandardCharsets.UTF_8), err.toString(StandardCharsets.UTF_8));
    }

    private static void copy(InputStream in, ByteArrayOutputStream out) {
        try (in) {
            in.transferTo(out);
        } catch (IOException ignored) {
        }
    }
}
