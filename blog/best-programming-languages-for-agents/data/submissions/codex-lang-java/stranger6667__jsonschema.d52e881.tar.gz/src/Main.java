import java.io.*;
import java.math.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.regex.*;

public class Main {
  static String schemaPath, output = "text", draft = null;
  static boolean assertFormat = false;
  static final List<String> instances = new ArrayList<>();
  static Object rootSchema;
  static String schemaUri;

  public static void main(String[] args) {
    try {
      parseArgs(args);
      if (schemaPath == null) {
        System.err.println("error: the following required arguments were not provided:\n  <SCHEMA>\n\nUsage: executable <SCHEMA>\n\nFor more information, try '--help'.");
        System.exit(2);
      }
      Path sp = Paths.get(schemaPath);
      rootSchema = new Parser(Files.readString(sp)).parse();
      schemaUri = sp.toAbsolutePath().normalize().toUri().toString() + "#";
      if (instances.isEmpty()) {
        System.out.println("Schema is valid");
        return;
      }
      boolean allValid = true;
      for (String ip : instances) {
        Object inst = new Parser(Files.readString(Paths.get(ip))).parse();
        List<Err> errors = new ArrayList<>();
        boolean valid = validate(rootSchema, inst, "", "", errors, new HashSet<>());
        allValid &= valid;
        printResult(ip, valid, errors);
      }
      if (!allValid) System.exit(1);
    } catch (Cli e) {
      System.err.println(e.getMessage());
      System.exit(e.code);
    } catch (Exception e) {
      String m = e.getMessage();
      System.err.println("Error: " + (m == null ? e.toString() : m));
      System.exit(1);
    }
  }

  static void parseArgs(String[] a) {
    for (int i=0;i<a.length;i++) {
      String s=a[i];
      switch(s) {
        case "-h": case "--help": help(); System.exit(0); break;
        case "-v": case "--version": System.out.println("Version: 0.41.0"); System.exit(0); break;
        case "-i": case "--instance": instances.add(need(a, ++i, s)); break;
        case "-d": case "--draft":
          draft = need(a, ++i, s);
          if (!List.of("4","6","7","2019","2020").contains(draft))
            throw new Cli("error: invalid value '"+draft+"' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.",2);
          break;
        case "--assert-format": assertFormat=true; break;
        case "--no-assert-format": assertFormat=false; break;
        case "--output":
          output=need(a,++i,s);
          if (!List.of("text","flag","list","hierarchical").contains(output))
            throw new Cli("error: invalid value '"+output+"' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.",2);
          break;
        case "--errors-only": break;
        case "--connect-timeout": case "--timeout": case "--cacert": need(a, ++i, s); break;
        case "-k": case "--insecure": break;
        default:
          if (s.startsWith("-")) throw new Cli("error: unexpected argument '"+s+"' found\n\nFor more information, try '--help'.",2);
          if (schemaPath == null) schemaPath = s;
          else throw new Cli("error: unexpected argument '"+s+"' found\n\nFor more information, try '--help'.",2);
      }
    }
  }
  static String need(String[] a,int i,String opt){ if(i>=a.length) throw new Cli("error: a value is required for '"+opt+"' but none was supplied",2); return a[i];}
  static void help() {
    System.out.println("Usage: executable [OPTIONS] [SCHEMA]\n\nArguments:\n  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)\n\nOptions:\n  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)\n  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]\n      --assert-format              Turn ON format validation\n      --no-assert-format           Turn OFF format validation\n      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]\n  -v, --version                    Show program's version number and exit\n      --errors-only                Only show validation errors\n      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)\n      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)\n  -k, --insecure                   Skip TLS certificate verification (dangerous!)\n      --cacert <FILE>              Path to a custom CA certificate file (PEM format)\n  -h, --help                       Print help");
  }

  static void printResult(String ip, boolean valid, List<Err> errors) {
    if (output.equals("flag")) {
      System.out.println("{\"instance\":"+q(ip)+",\"output\":\"flag\",\"payload\":{\"valid\":"+valid+"},\"schema\":"+q(schemaPath)+"}");
    } else if (output.equals("list") || output.equals("hierarchical")) {
      Map<String,Object> payload = new LinkedHashMap<>();
      payload.put("valid", valid);
      if (!valid) {
        List<Object> det = new ArrayList<>();
        for (Err e: errors) {
          Map<String,Object> m = new LinkedHashMap<>();
          m.put("valid", false); m.put("evaluationPath", e.schema); m.put("instanceLocation", e.inst);
          m.put("schemaLocation", schemaUri + e.schema);
          Map<String,Object> em = new LinkedHashMap<>(); em.put(e.keyword, e.msg); m.put("errors", em);
          det.add(m);
        }
        payload.put("details", det);
      }
      Map<String,Object> out = new LinkedHashMap<>();
      out.put("instance", ip); out.put("output", output); out.put("payload", payload); out.put("schema", schemaPath);
      System.out.println(toJson(out));
    } else {
      if (valid) System.out.println(ip + " - VALID");
      else {
        System.out.println(ip + " - INVALID. Errors:");
        for (int i=0;i<errors.size();i++) System.out.println((i+1)+". "+errors.get(i).msg);
      }
    }
  }

  static boolean validate(Object schema, Object inst, String sp, String ip, List<Err> errs, Set<String> seen) {
    schema = deref(schema, sp, seen);
    if (schema instanceof Boolean) {
      if ((Boolean)schema) return true;
      errs.add(new Err(sp, ip, "false", "false schema"));
      return false;
    }
    if (!(schema instanceof Map)) return true;
    Map<String,Object> s = obj(schema);
    int start = errs.size();

    if (s.containsKey("if")) {
      List<Err> tmp = new ArrayList<>();
      boolean ok = validate(s.get("if"), inst, sp+"/if", ip, tmp, new HashSet<>(seen));
      if (ok && s.containsKey("then")) validate(s.get("then"), inst, sp+"/then", ip, errs, new HashSet<>(seen));
      if (!ok && s.containsKey("else")) validate(s.get("else"), inst, sp+"/else", ip, errs, new HashSet<>(seen));
    }
    if (s.containsKey("allOf")) forEachSchema(s.get("allOf"), (sub,idx)->validate(sub,inst,sp+"/allOf/"+idx,ip,errs,new HashSet<>(seen)));
    if (s.containsKey("anyOf")) {
      boolean ok=false; for (Object sub: arr(s.get("anyOf"))) { List<Err> t=new ArrayList<>(); if(validate(sub,inst,sp+"/anyOf",ip,t,new HashSet<>(seen))) {ok=true; break;} }
      if(!ok) errs.add(new Err(sp+"/anyOf",ip,"anyOf","must be valid against at least one schema"));
    }
    if (s.containsKey("oneOf")) {
      int count=0; for (Object sub: arr(s.get("oneOf"))) { List<Err> t=new ArrayList<>(); if(validate(sub,inst,sp+"/oneOf",ip,t,new HashSet<>(seen))) count++; }
      if(count!=1) errs.add(new Err(sp+"/oneOf",ip,"oneOf","must be valid against exactly one schema, but "+count+" matched"));
    }
    if (s.containsKey("not")) {
      List<Err> t=new ArrayList<>(); if(validate(s.get("not"),inst,sp+"/not",ip,t,new HashSet<>(seen))) errs.add(new Err(sp+"/not",ip,"not","must not be valid"));
    }

    if (s.containsKey("type")) checkType(s.get("type"), inst, sp+"/type", ip, errs);
    if (s.containsKey("enum") && !containsJson(arr(s.get("enum")), inst)) errs.add(new Err(sp+"/enum",ip,"enum","value is not one of the allowed values"));
    if (s.containsKey("const") && !jsonEq(s.get("const"), inst)) errs.add(new Err(sp+"/const",ip,"const","value must be "+toJson(s.get("const"))));

    if (inst instanceof String) stringChecks(s, (String)inst, sp, ip, errs);
    if (inst instanceof Number) numberChecks(s, (Number)inst, sp, ip, errs);
    if (inst instanceof List) arrayChecks(s, list(inst), sp, ip, errs, seen);
    if (inst instanceof Map) objectChecks(s, obj(inst), sp, ip, errs, seen);
    if (assertFormat && s.containsKey("format") && inst instanceof String) formatCheck(String.valueOf(s.get("format")), (String)inst, sp+"/format", ip, errs);
    return errs.size()==start;
  }

  interface SchemaConsumer { void accept(Object sub, int idx); }
  static void forEachSchema(Object o, SchemaConsumer c){ List<Object>a=arr(o); for(int i=0;i<a.size();i++) c.accept(a.get(i),i); }

  static Object deref(Object schema, String sp, Set<String> seen) {
    while (schema instanceof Map && obj(schema).get("$ref") instanceof String) {
      String ref = (String)obj(schema).get("$ref");
      if (!ref.startsWith("#")) break;
      if (!seen.add(ref)) break;
      schema = resolvePointer(rootSchema, ref.substring(1));
    }
    return schema;
  }
  static Object resolvePointer(Object root, String ptr) {
    if (ptr.isEmpty()) return root;
    if (ptr.startsWith("/")) ptr=ptr.substring(1);
    Object cur=root;
    for(String raw: ptr.split("/",-1)) {
      String p=raw.replace("~1","/").replace("~0","~");
      if(cur instanceof Map) cur=obj(cur).get(p);
      else if(cur instanceof List) cur=list(cur).get(Integer.parseInt(p));
      else return null;
    }
    return cur;
  }

  static void checkType(Object type, Object inst, String sp, String ip, List<Err> errs) {
    List<String> types = new ArrayList<>();
    if (type instanceof List) for(Object x:list(type)) types.add(String.valueOf(x)); else types.add(String.valueOf(type));
    for(String t: types) if (isType(t,inst)) return;
    String want = types.size()==1 ? types.get(0) : types.toString();
    errs.add(new Err(sp,ip,"type",typeName(inst)+" is not of type \""+want+"\""));
  }
  static boolean isType(String t,Object v){
    return switch(t){case "null"->v==null;case"boolean"->v instanceof Boolean;case"object"->v instanceof Map;case"array"->v instanceof List;case"number"->v instanceof Number;case"integer"->v instanceof BigDecimal && ((BigDecimal)v).stripTrailingZeros().scale()<=0;case"string"->v instanceof String;default->true;};
  }
  static String typeName(Object v){ if(v==null)return"null"; if(v instanceof Map)return"object"; if(v instanceof List)return"array"; if(v instanceof String)return"string"; if(v instanceof Boolean)return"boolean"; if(v instanceof Number)return"number"; return"value"; }

  static void stringChecks(Map<String,Object>s,String v,String sp,String ip,List<Err>errs){
    int len=v.codePointCount(0,v.length());
    if(num(s.get("minLength"))!=null && len<num(s.get("minLength")).intValue()) errs.add(new Err(sp+"/minLength",ip,"minLength","length must be at least "+num(s.get("minLength")).intValue()));
    if(num(s.get("maxLength"))!=null && len>num(s.get("maxLength")).intValue()) errs.add(new Err(sp+"/maxLength",ip,"maxLength","length must be at most "+num(s.get("maxLength")).intValue()));
    if(s.get("pattern") instanceof String) try{ if(!Pattern.compile((String)s.get("pattern")).matcher(v).find()) errs.add(new Err(sp+"/pattern",ip,"pattern","string does not match pattern "+q((String)s.get("pattern")))); }catch(Exception ignored){}
  }
  static void numberChecks(Map<String,Object>s,Number n,String sp,String ip,List<Err>errs){
    BigDecimal v=(BigDecimal)n;
    if(num(s.get("minimum"))!=null && v.compareTo(num(s.get("minimum")))<0) errs.add(new Err(sp+"/minimum",ip,"minimum","must be greater than or equal to "+plain(num(s.get("minimum")))));
    if(num(s.get("maximum"))!=null && v.compareTo(num(s.get("maximum")))>0) errs.add(new Err(sp+"/maximum",ip,"maximum","must be less than or equal to "+plain(num(s.get("maximum")))));
    Object em=s.get("exclusiveMinimum"); if(em instanceof Number && v.compareTo(num(em))<=0) errs.add(new Err(sp+"/exclusiveMinimum",ip,"exclusiveMinimum","must be greater than "+plain(num(em)))); else if(Boolean.TRUE.equals(em)&&num(s.get("minimum"))!=null&&v.compareTo(num(s.get("minimum")))<=0) errs.add(new Err(sp+"/exclusiveMinimum",ip,"exclusiveMinimum","must be greater than "+plain(num(s.get("minimum")))));
    Object ex=s.get("exclusiveMaximum"); if(ex instanceof Number && v.compareTo(num(ex))>=0) errs.add(new Err(sp+"/exclusiveMaximum",ip,"exclusiveMaximum","must be less than "+plain(num(ex)))); else if(Boolean.TRUE.equals(ex)&&num(s.get("maximum"))!=null&&v.compareTo(num(s.get("maximum")))>=0) errs.add(new Err(sp+"/exclusiveMaximum",ip,"exclusiveMaximum","must be less than "+plain(num(s.get("maximum")))));
    if(num(s.get("multipleOf"))!=null) try{ if(v.remainder(num(s.get("multipleOf"))).compareTo(BigDecimal.ZERO)!=0) errs.add(new Err(sp+"/multipleOf",ip,"multipleOf","must be a multiple of "+plain(num(s.get("multipleOf"))))); }catch(Exception ignored){}
  }
  static void arrayChecks(Map<String,Object>s,List<Object>a,String sp,String ip,List<Err>errs,Set<String>seen){
    if(num(s.get("minItems"))!=null && a.size()<num(s.get("minItems")).intValue()) errs.add(new Err(sp+"/minItems",ip,"minItems","array length must be at least "+num(s.get("minItems")).intValue()));
    if(num(s.get("maxItems"))!=null && a.size()>num(s.get("maxItems")).intValue()) errs.add(new Err(sp+"/maxItems",ip,"maxItems","array length must be at most "+num(s.get("maxItems")).intValue()));
    if(Boolean.TRUE.equals(s.get("uniqueItems"))) for(int i=0;i<a.size();i++) for(int j=i+1;j<a.size();j++) if(jsonEq(a.get(i),a.get(j))) {errs.add(new Err(sp+"/uniqueItems",ip,"uniqueItems","array items are not unique")); i=a.size(); break;}
    Object items=s.get("items");
    int prefixCount = s.get("prefixItems") instanceof List ? list(s.get("prefixItems")).size() : 0;
    if(items instanceof Map || items instanceof Boolean) for(int i=prefixCount;i<a.size();i++) validate(items,a.get(i),sp+"/items",ip+"/"+i,errs,new HashSet<>(seen));
    else if(items instanceof List) { List<Object> its=list(items); for(int i=0;i<Math.min(a.size(),its.size());i++) validate(its.get(i),a.get(i),sp+"/items/"+i,ip+"/"+i,errs,new HashSet<>(seen)); if(Boolean.FALSE.equals(s.get("additionalItems"))&&a.size()>its.size()) errs.add(new Err(sp+"/additionalItems",ip,"additionalItems","additional array items are not allowed")); }
    if(s.get("prefixItems") instanceof List) { List<Object> ps=list(s.get("prefixItems")); for(int i=0;i<Math.min(a.size(),ps.size());i++) validate(ps.get(i),a.get(i),sp+"/prefixItems/"+i,ip+"/"+i,errs,new HashSet<>(seen)); }
    if(s.containsKey("contains")) { int c=0; for(int i=0;i<a.size();i++){List<Err>t=new ArrayList<>(); if(validate(s.get("contains"),a.get(i),sp+"/contains",ip+"/"+i,t,new HashSet<>(seen))) c++;} int min=s.containsKey("minContains")?num(s.get("minContains")).intValue():1; if(c<min) errs.add(new Err(sp+"/contains",ip,"contains","does not contain enough matching items")); if(s.containsKey("maxContains")&&c>num(s.get("maxContains")).intValue()) errs.add(new Err(sp+"/contains",ip,"contains","contains too many matching items")); }
  }
  static void objectChecks(Map<String,Object>s,Map<String,Object>o,String sp,String ip,List<Err>errs,Set<String>seen){
    if(num(s.get("minProperties"))!=null && o.size()<num(s.get("minProperties")).intValue()) errs.add(new Err(sp+"/minProperties",ip,"minProperties","object has too few properties"));
    if(num(s.get("maxProperties"))!=null && o.size()>num(s.get("maxProperties")).intValue()) errs.add(new Err(sp+"/maxProperties",ip,"maxProperties","object has too many properties"));
    if(s.get("required") instanceof List) for(Object r:list(s.get("required"))) if(!o.containsKey(String.valueOf(r))) errs.add(new Err(sp+"/required",ip,"required",q(String.valueOf(r))+" is a required property"));
    Set<String> matched=new HashSet<>();
    if(s.get("properties") instanceof Map) for(var e: obj(s.get("properties")).entrySet()) if(o.containsKey(e.getKey())) {matched.add(e.getKey()); validate(e.getValue(),o.get(e.getKey()),sp+"/properties/"+esc(e.getKey()),ip+"/"+esc(e.getKey()),errs,new HashSet<>(seen));}
    if(s.get("patternProperties") instanceof Map) for(var pe: obj(s.get("patternProperties")).entrySet()) try{Pattern p=Pattern.compile(pe.getKey()); for(var e:o.entrySet()) if(p.matcher(e.getKey()).find()){matched.add(e.getKey()); validate(pe.getValue(),e.getValue(),sp+"/patternProperties/"+esc(pe.getKey()),ip+"/"+esc(e.getKey()),errs,new HashSet<>(seen));}}catch(Exception ignored){}
    if(s.containsKey("additionalProperties")) {
      Object ap=s.get("additionalProperties");
      for(var e:o.entrySet()) if(!matched.contains(e.getKey())) {
        if(Boolean.FALSE.equals(ap)) errs.add(new Err(sp+"/additionalProperties",ip,"additionalProperties","additional property "+q(e.getKey())+" is not allowed"));
        else if(ap instanceof Map || ap instanceof Boolean) validate(ap,e.getValue(),sp+"/additionalProperties",ip+"/"+esc(e.getKey()),errs,new HashSet<>(seen));
      }
    }
    if(s.get("dependentRequired") instanceof Map) for(var e:obj(s.get("dependentRequired")).entrySet()) if(o.containsKey(e.getKey())) for(Object r:arr(e.getValue())) if(!o.containsKey(String.valueOf(r))) errs.add(new Err(sp+"/dependentRequired",ip,"dependentRequired",q(String.valueOf(r))+" is a dependency of "+q(e.getKey())));
    if(s.get("dependencies") instanceof Map) for(var e:obj(s.get("dependencies")).entrySet()) if(o.containsKey(e.getKey())) {Object d=e.getValue(); if(d instanceof List) for(Object r:list(d)) if(!o.containsKey(String.valueOf(r))) errs.add(new Err(sp+"/dependencies",ip,"dependencies",q(String.valueOf(r))+" is a dependency of "+q(e.getKey()))); else validate(d,o,sp+"/dependencies/"+esc(e.getKey()),ip,errs,new HashSet<>(seen));}
    if(s.get("dependentSchemas") instanceof Map) for(var e:obj(s.get("dependentSchemas")).entrySet()) if(o.containsKey(e.getKey())) validate(e.getValue(),o,sp+"/dependentSchemas/"+esc(e.getKey()),ip,errs,new HashSet<>(seen));
    if(s.containsKey("propertyNames")) for(String k:o.keySet()) validate(s.get("propertyNames"),k,sp+"/propertyNames",ip,errs,new HashSet<>(seen));
    if(!s.containsKey("additionalProperties") && s.containsKey("unevaluatedProperties")) {
      Object up = s.get("unevaluatedProperties");
      Set<String> known = new HashSet<>();
      if(s.get("properties") instanceof Map) known.addAll(obj(s.get("properties")).keySet());
      for(var e:o.entrySet()) if(!known.contains(e.getKey())) {
        if(Boolean.FALSE.equals(up)) errs.add(new Err(sp+"/unevaluatedProperties",ip,"unevaluatedProperties","unevaluated property "+q(e.getKey())+" is not allowed"));
        else validate(up,e.getValue(),sp+"/unevaluatedProperties",ip+"/"+esc(e.getKey()),errs,new HashSet<>(seen));
      }
    }
  }
  static void formatCheck(String f,String v,String sp,String ip,List<Err>errs){
    boolean ok=true;
    try { switch(f){case"email": ok=Pattern.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$",v); break; case"uri": new URI(v); ok=v.contains(":"); break; case"date-time": OffsetDateTime.parse(v); break; case"ipv4": ok=Pattern.matches("^(25[0-5]|2[0-4]\\d|[01]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[01]?\\d?\\d)){3}$",v); break; case"regex": Pattern.compile(v); break; default: ok=true;} } catch(Exception e){ok=false;}
    if(!ok) errs.add(new Err(sp,ip,"format",q(v)+" is not a valid "+f));
  }

  static BigDecimal num(Object o){ return o instanceof BigDecimal ? (BigDecimal)o : null; }
  static String plain(BigDecimal b){ return b.stripTrailingZeros().toPlainString(); }
  static String esc(String p){ return p.replace("~","~0").replace("/","~1"); }
  @SuppressWarnings("unchecked") static Map<String,Object> obj(Object o){return (Map<String,Object>)o;}
  @SuppressWarnings("unchecked") static List<Object> list(Object o){return (List<Object>)o;}
  static List<Object> arr(Object o){return o instanceof List?list(o):List.of();}
  static boolean containsJson(List<Object>a,Object v){ for(Object x:a) if(jsonEq(x,v)) return true; return false; }
  static boolean jsonEq(Object a,Object b){ if(a instanceof BigDecimal && b instanceof BigDecimal) return ((BigDecimal)a).compareTo((BigDecimal)b)==0; if(a instanceof List && b instanceof List){List<Object>x=list(a),y=list(b); if(x.size()!=y.size())return false; for(int i=0;i<x.size();i++) if(!jsonEq(x.get(i),y.get(i)))return false; return true;} if(a instanceof Map && b instanceof Map){Map<String,Object>x=obj(a),y=obj(b); if(!x.keySet().equals(y.keySet()))return false; for(String k:x.keySet()) if(!jsonEq(x.get(k),y.get(k)))return false; return true;} return Objects.equals(a,b);}

  static String toJson(Object o){ if(o==null)return"null"; if(o instanceof String)return q((String)o); if(o instanceof Boolean)return o.toString(); if(o instanceof BigDecimal)return plain((BigDecimal)o); if(o instanceof Map){StringBuilder sb=new StringBuilder("{"); boolean first=true; for(var e:obj(o).entrySet()){if(!first)sb.append(','); first=false; sb.append(q(e.getKey())).append(':').append(toJson(e.getValue()));} return sb.append('}').toString();} if(o instanceof List){StringBuilder sb=new StringBuilder("["); boolean first=true; for(Object x:list(o)){if(!first)sb.append(','); first=false; sb.append(toJson(x));} return sb.append(']').toString();} return q(String.valueOf(o));}
  static String q(String s){StringBuilder b=new StringBuilder("\""); for(int i=0;i<s.length();i++){char c=s.charAt(i); switch(c){case'\\'->b.append("\\\\");case'"'->b.append("\\\"");case'\b'->b.append("\\b");case'\f'->b.append("\\f");case'\n'->b.append("\\n");case'\r'->b.append("\\r");case'\t'->b.append("\\t");default->{if(c<32)b.append(String.format("\\u%04x",(int)c)); else b.append(c);}}} return b.append('"').toString();}

  static class Err { String schema, inst, keyword, msg; Err(String s,String i,String k,String m){schema=s;inst=i;keyword=k;msg=m;} }
  static class Cli extends RuntimeException { int code; Cli(String m,int c){super(m);code=c;} }

  static class Parser {
    final String s; int p=0; Parser(String s){this.s=s;}
    Object parse(){ Object v=val(); ws(); if(p!=s.length()) throw err("trailing characters"); return v; }
    Object val(){ ws(); if(p>=s.length()) throw err("EOF while parsing a value"); char c=s.charAt(p); if(c=='{')return object(); if(c=='[')return array(); if(c=='"')return string(); if(c=='t'&&eat("true"))return true; if(c=='f'&&eat("false"))return false; if(c=='n'&&eat("null"))return null; return number(); }
    Map<String,Object> object(){ p++; Map<String,Object> m=new LinkedHashMap<>(); ws(); if(ch('}'))return m; while(true){ ws(); if(p>=s.length()||s.charAt(p)!='"') throw err("expected string key"); String k=string(); ws(); if(!ch(':')) throw err("expected ':'"); m.put(k,val()); ws(); if(ch('}'))break; if(!ch(','))throw err("expected ',' or '}'"); } return m; }
    List<Object> array(){ p++; List<Object>a=new ArrayList<>(); ws(); if(ch(']'))return a; while(true){ a.add(val()); ws(); if(ch(']'))break; if(!ch(','))throw err("expected ',' or ']'"); } return a; }
    String string(){ p++; StringBuilder b=new StringBuilder(); while(p<s.length()){ char c=s.charAt(p++); if(c=='"')return b.toString(); if(c=='\\'){ if(p>=s.length())throw err("EOF in string escape"); char e=s.charAt(p++); switch(e){case'"':b.append('"');break;case'\\':b.append('\\');break;case'/':b.append('/');break;case'b':b.append('\b');break;case'f':b.append('\f');break;case'n':b.append('\n');break;case'r':b.append('\r');break;case't':b.append('\t');break;case'u': if(p+4>s.length())throw err("bad unicode escape"); b.append((char)Integer.parseInt(s.substring(p,p+4),16)); p+=4; break;default:throw err("bad escape");}} else b.append(c);} throw err("EOF while parsing a string");}
    BigDecimal number(){ int st=p; if(p<s.length()&&s.charAt(p)=='-')p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++; if(p<s.length()&&s.charAt(p)=='.'){p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} if(p<s.length()&&(s.charAt(p)=='e'||s.charAt(p)=='E')){p++; if(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-'))p++; while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;} try{return new BigDecimal(s.substring(st,p));}catch(Exception e){throw err("invalid number");}}
    void ws(){ while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++; }
    boolean ch(char c){ if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false; }
    boolean eat(String x){ if(s.startsWith(x,p)){p+=x.length();return true;}return false; }
    RuntimeException err(String m){ int line=1,col=1; for(int i=0;i<p&&i<s.length();i++){ if(s.charAt(i)=='\n'){line++;col=1;} else col++; } return new RuntimeException(m+" at line "+line+" column "+col); }
  }
}
