import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class Oha {
    static final String VERSION = "oha 1.12.1";
    static final String HELP = """
Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with `-w` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. `-w` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version
""";

    static class Opt {
        long n = 200;
        int c = 50, p = 1, redirect = 10;
        String method = "GET", url, outputFormat = "text", output, timeUnit;
        String bodyString, bodyPath, bodyLinesPath, contentType, accept, basicAuth, host, proxy;
        Duration duration, timeout, connectTimeout = Duration.ofSeconds(5), burstDelay;
        double qps = 0;
        int burstRate = 1, dumpUrls = -1, maxRepeat = 4;
        boolean noTui, debug, urlsFromFile, randRegexUrl, disableKeepalive, disableCompression, http2, waitOngoing, insecure;
        List<String> headers = new ArrayList<>();
        List<String> forms = new ArrayList<>();
    }
    static class Res {
        boolean ok; int status; long bytes; long startNs, dnsNs, dialNs, delayNs, durationNs; String err;
    }

    public static void main(String[] args) throws Exception {
        Opt opt;
        try { opt = parse(args); }
        catch (Cli e) { System.err.print(e.getMessage()); System.exit(e.code); return; }
        if (opt == null) return;
        if (opt.dumpUrls >= 0) { for (int i=0;i<opt.dumpUrls;i++) System.out.println(genUrl(opt.url, opt)); return; }
        if (opt.debug) { debug(opt); return; }
        List<Res> results = run(opt);
        String out = switch (opt.outputFormat) {
            case "json" -> json(results);
            case "csv" -> csv(results);
            case "quiet" -> "";
            default -> text(results, opt.timeUnit);
        };
        if (opt.output != null) Files.writeString(Path.of(opt.output), out, StandardCharsets.UTF_8);
        else System.out.print(out);
    }

    static class Cli extends Exception { int code; Cli(String m,int c){super(m);code=c;} }
    static Opt parse(String[] a) throws Cli {
        Opt o = new Opt(); List<String> pos = new ArrayList<>();
        for (int i=0;i<a.length;i++) {
            String s=a[i];
            if (s.equals("-h")||s.equals("--help")) { System.out.print(HELP); return null; }
            if (s.equals("-V")||s.equals("--version")) { System.out.println(VERSION); return null; }
            switch(s) {
                case "-n" -> o.n = parseCount(need(a,++i,s), "-n <N_REQUESTS>");
                case "-c" -> o.c = (int)parseCount(need(a,++i,s), "-c <N_CONNECTIONS>");
                case "-p" -> o.p = (int)parseCount(need(a,++i,s), "-p <N_HTTP2_PARALLEL>");
                case "-z" -> o.duration = parseDuration(need(a,++i,s), "-z <DURATION>");
                case "-w","--wait-ongoing-requests-after-deadline" -> o.waitOngoing = true;
                case "-q" -> o.qps = Double.parseDouble(need(a,++i,s));
                case "--burst-delay" -> o.burstDelay = parseDuration(need(a,++i,s), "--burst-delay <BURST_DURATION>");
                case "--burst-rate" -> o.burstRate = (int)parseCount(need(a,++i,s), "--burst-rate <BURST_REQUESTS>");
                case "--rand-regex-url" -> o.randRegexUrl = true;
                case "--urls-from-file" -> o.urlsFromFile = true;
                case "--max-repeat" -> o.maxRepeat = (int)parseCount(need(a,++i,s), "--max-repeat <MAX_REPEAT>");
                case "--dump-urls" -> o.dumpUrls = (int)parseCount(need(a,++i,s), "--dump-urls <DUMP_URLS>");
                case "--latency-correction","--no-color","--no-pre-lookup","--ipv4","--ipv6","--stats-success-breakdown" -> {}
                case "--no-tui" -> o.noTui = true;
                case "--fps" -> { ++i; need(a,i,s); }
                case "-m","--method" -> o.method = need(a,++i,s).toUpperCase(Locale.ROOT);
                case "-H" -> { String h=need(a,++i,s); if(!h.contains(":")) throw invalid(h,"-H <HEADERS>","Parse header"); o.headers.add(h); }
                case "--proxy-header" -> { ++i; need(a,i,s); }
                case "-t" -> o.timeout = parseDuration(need(a,++i,s), "-t <TIMEOUT>");
                case "--connect-timeout" -> o.connectTimeout = parseDuration(need(a,++i,s), "--connect-timeout <CONNECT_TIMEOUT>");
                case "-A" -> o.accept = need(a,++i,s);
                case "-d" -> { if(o.bodyPath!=null) conflict("-d <BODY_STRING>","-D <BODY_PATH>"); o.bodyString = need(a,++i,s); }
                case "-D" -> { if(o.bodyString!=null) conflict("-d <BODY_STRING>","-D <BODY_PATH>"); o.bodyPath = need(a,++i,s); }
                case "-Z" -> o.bodyLinesPath = need(a,++i,s);
                case "-F","--form" -> o.forms.add(need(a,++i,s));
                case "-T" -> o.contentType = need(a,++i,s);
                case "-a" -> o.basicAuth = need(a,++i,s);
                case "--aws-session","--aws-sigv4","--proxy-http-version","--cacert","--cert","--key","--connect-to","--unix-socket","--db-url" -> { ++i; need(a,i,s); }
                case "-x" -> o.proxy = need(a,++i,s);
                case "--proxy-http2","--http2" -> o.http2 = true;
                case "--http-version" -> { String v=need(a,++i,s); o.http2 = v.equals("2"); }
                case "--host" -> o.host = need(a,++i,s);
                case "--disable-compression" -> o.disableCompression = true;
                case "-r","--redirect" -> o.redirect = (int)parseCount(need(a,++i,s), "-r <REDIRECT>");
                case "--disable-keepalive" -> o.disableKeepalive = true;
                case "--insecure" -> o.insecure = true;
                case "--debug" -> o.debug = true;
                case "-o","--output" -> o.output = need(a,++i,s);
                case "--output-format" -> { o.outputFormat = need(a,++i,s); if(!List.of("text","json","csv","quiet").contains(o.outputFormat)) throw new Cli("error: invalid value '"+o.outputFormat+"' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]\n\nFor more information, try '--help'.\n",2); }
                case "-u","--time-unit" -> { o.timeUnit = need(a,++i,s); if(!List.of("ns","us","ms","s","m","h").contains(o.timeUnit)) throw new Cli("error: invalid value '"+o.timeUnit+"' for '--time-unit <TIME_UNIT>'\n  [possible values: ns, us, ms, s, m, h]\n\nFor more information, try '--help'.\n",2); }
                default -> { if (s.startsWith("-")) throw new Cli("error: unexpected argument '"+s+"' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.\n",2); else pos.add(s); }
            }
        }
        if (pos.isEmpty()) { System.out.print(HELP); return null; }
        if (pos.size()>1) throw new Cli("error: unexpected argument '"+pos.get(1)+"' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.\n",2);
        o.url = pos.get(0); return o;
    }
    static String need(String[] a,int i,String opt) throws Cli { if(i>=a.length) throw new Cli("error: a value is required for '"+opt+" <value>' but none was supplied\n\nFor more information, try '--help'.\n",2); return a[i]; }
    static void conflict(String a,String b) throws Cli { throw new Cli("error: the argument '"+a+"' cannot be used with '"+b+"'\n\nUsage: executable "+a.substring(0,2)+" "+a+" <URL>\n\nFor more information, try '--help'.\n",2); }
    static Cli invalid(String val,String arg,String why){ return new Cli("error: invalid value '"+val+"' for '"+arg+"': "+why+"\n\nFor more information, try '--help'.\n",2); }
    static long parseCount(String s,String arg) throws Cli {
        try { long mul=1; String x=s.toLowerCase(Locale.ROOT); if(x.endsWith("k")){mul=1000;x=x.substring(0,x.length()-1);} else if(x.endsWith("m")){mul=1000000;x=x.substring(0,x.length()-1);} return Long.parseLong(x)*mul; }
        catch(Exception e){ throw invalid(s,arg,"invalid digit found in string"); }
    }
    static Duration parseDuration(String s,String arg) throws Cli {
        try {
            int i=0; while(i<s.length() && (Character.isDigit(s.charAt(i))||s.charAt(i)=='.')) i++;
            if(i==0) throw new Exception(); double n=Double.parseDouble(s.substring(0,i)); String u=s.substring(i);
            double seconds = switch(u) { case "ns" -> n/1e9; case "us","µs" -> n/1e6; case "ms" -> n/1000; case "","s","sec","secs","second","seconds" -> n; case "m","min","mins","minute","minutes" -> n*60; case "h","hr","hour","hours" -> n*3600; case "d","day","days" -> n*86400; default -> throw new Exception("unit"); };
            return Duration.ofNanos((long)(seconds*1_000_000_000L));
        } catch(Exception e) { String unit=s.replaceFirst("^[0-9.]+",""); throw invalid(s,arg,"unknown time unit \""+unit+"\", supported units: ns, us/µs, ms, sec, min, hours, days, weeks, months, years (and few variations)"); }
    }

    static List<Res> run(Opt o) throws Exception {
        List<String> urls = urls(o);
        if (o.n == 0 && o.duration == null) o.n = 1; // close to original's surprising eager single request
        int workers = Math.max(1, o.c * o.p);
        ExecutorService ex = Executors.newFixedThreadPool(workers);
        Queue<Res> out = new ConcurrentLinkedQueue<>();
        AtomicLong issued = new AtomicLong();
        long begin = System.nanoTime();
        long deadline = o.duration == null ? Long.MAX_VALUE : begin + o.duration.toNanos();
        List<Future<?>> fs = new ArrayList<>();
        for (int w=0; w<workers; w++) fs.add(ex.submit(() -> {
            Random rnd = new Random();
            while (true) {
                long id = issued.getAndIncrement();
                if (o.duration == null && id >= o.n) break;
                if (System.nanoTime() >= deadline) break;
                if (o.qps > 0) sleepUntil(begin + (long)(id * 1_000_000_000.0 / o.qps));
                else if (o.burstDelay != null && o.burstRate > 0 && id > 0 && id % o.burstRate == 0) sleepNanos(o.burstDelay.toNanos());
                String u = o.randRegexUrl ? genUrl(o.url,o) : urls.get(rnd.nextInt(urls.size()));
                out.add(request(o, u, begin));
            }
        }));
        for (Future<?> f: fs) try { f.get(); } catch (ExecutionException ignored) {}
        ex.shutdownNow();
        return new ArrayList<>(out);
    }
    static List<String> urls(Opt o) throws IOException {
        if (!o.urlsFromFile) return List.of(o.url);
        List<String> l = Files.readAllLines(Path.of(o.url), StandardCharsets.UTF_8); l.removeIf(String::isBlank);
        return l.isEmpty()?List.of(o.url):l;
    }
    static String genUrl(String pat, Opt o) {
        Random r = new Random(); StringBuilder sb = new StringBuilder();
        for (int i=0;i<pat.length();i++) {
            if (i+4<pat.length() && pat.charAt(i)=='[' && pat.charAt(i+2)=='-' && pat.charAt(i+4)==']') {
                char a=pat.charAt(i+1), b=pat.charAt(i+3); sb.append((char)(a+r.nextInt(Math.max(1,b-a+1)))); i+=4;
            } else sb.append(pat.charAt(i));
        }
        return sb.toString();
    }
    static Res request(Opt o, String url, long zero) {
        Res r = new Res(); r.startNs = System.nanoTime()-zero; long st = System.nanoTime();
        try {
            HttpClient.Builder cb = HttpClient.newBuilder().connectTimeout(o.connectTimeout).followRedirects(o.redirect==0?HttpClient.Redirect.NEVER:HttpClient.Redirect.NORMAL);
            if (o.http2) cb.version(HttpClient.Version.HTTP_2); else cb.version(HttpClient.Version.HTTP_1_1);
            if (o.proxy != null) { URI pu=URI.create(o.proxy); cb.proxy(ProxySelector.of(new InetSocketAddress(pu.getHost(), pu.getPort()))); }
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(url));
            if (o.timeout != null) b.timeout(o.timeout);
            byte[] body = body(o);
            HttpRequest.BodyPublisher pub = body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(body);
            b.method(o.method, pub);
            addDefaultHeaders(o, b, URI.create(url));
            for (String h:o.headers) { int k=h.indexOf(':'); b.header(h.substring(0,k).trim(), h.substring(k+1).trim()); }
            HttpResponse<byte[]> resp = cb.build().send(b.build(), HttpResponse.BodyHandlers.ofByteArray());
            r.status = resp.statusCode(); r.bytes = resp.body()==null?0:resp.body().length; r.ok = r.status >= 200 && r.status < 300; r.durationNs = System.nanoTime()-st; r.delayNs = r.durationNs;
        } catch (Exception e) { r.err = fmtErr(e); r.durationNs = System.nanoTime()-st; }
        return r;
    }
    static byte[] body(Opt o) throws IOException {
        if (o.bodyString != null) return o.bodyString.getBytes(StandardCharsets.UTF_8);
        if (o.bodyPath != null) return Files.readAllBytes(Path.of(o.bodyPath));
        if (!o.forms.isEmpty()) {
            StringBuilder s=new StringBuilder(); for(String f:o.forms){ if(s.length()>0)s.append('&'); s.append(URLEncoder.encode(f, StandardCharsets.UTF_8)); }
            return s.toString().getBytes(StandardCharsets.UTF_8);
        }
        return null;
    }
    static void addDefaultHeaders(Opt o, HttpRequest.Builder b, URI u) {
        b.header("User-Agent","oha/1.12.1");
        b.header("Accept", o.accept==null?"*/*":o.accept);
        if (!o.disableCompression) b.header("Accept-Encoding","gzip, compress, deflate, br");
        if (o.disableKeepalive) b.header("Connection","close");
        if (o.contentType != null) b.header("Content-Type",o.contentType);
        if (o.basicAuth != null) b.header("Authorization","Basic "+Base64.getEncoder().encodeToString(o.basicAuth.getBytes(StandardCharsets.UTF_8)));
    }
    static String fmtErr(Exception e) {
        Throwable t=e; while(t.getCause()!=null) t=t.getCause(); String m=t.getMessage(); if(m==null) m=t.toString();
        if (m.contains("Connection refused")) return "Connection refused (os error 111)";
        if (m.contains("Network is unreachable")) return "Network is unreachable (os error 101)";
        if (m.contains("timed out") || m.contains("timeout")) return "operation timed out";
        return m;
    }
    static void sleepUntil(long ns){ long d=ns-System.nanoTime(); if(d>0)sleepNanos(d); }
    static void sleepNanos(long ns){ try { TimeUnit.NANOSECONDS.sleep(ns); } catch(InterruptedException ignored){} }

    static void debug(Opt o) throws Exception {
        URI u = URI.create(o.url);
        String path = (u.getRawPath()==null||u.getRawPath().isEmpty()?"/":u.getRawPath()) + (u.getRawQuery()==null?"":"?"+u.getRawQuery());
        System.out.println("Request {");
        System.out.println("    method: "+o.method+",");
        System.out.println("    uri: "+path+",");
        System.out.println("    version: HTTP/1.1,");
        System.out.println("    headers: {");
        System.out.println("        \"accept\": \""+(o.accept==null?"*/*":o.accept)+"\",");
        if(!o.disableCompression) System.out.println("        \"accept-encoding\": \"gzip, compress, deflate, br\",");
        System.out.println("        \"user-agent\": \"oha/1.12.1\",");
        System.out.println("        \"host\": \""+(o.host==null?hostPort(u):o.host)+"\",");
        for(String h:o.headers){int k=h.indexOf(':');System.out.println("        \""+h.substring(0,k).trim().toLowerCase(Locale.ROOT)+"\": \""+h.substring(k+1).trim()+"\",");}
        System.out.println("    },");
        System.out.println("    body: Full {");
        byte[] body = body(o);
        System.out.println("        data: "+(body==null?"None":"Some("+body.length+" bytes)")+",");
        System.out.println("    },");
        System.out.println("}");
        Res r=request(o,o.url,System.nanoTime());
        if(r.err!=null){ System.err.println("Error: "+r.err); System.exit(1); }
        System.out.println("Response: HTTP "+r.status);
    }
    static String hostPort(URI u){ int p=u.getPort(); if(p<0) return u.getHost(); return u.getHost()+":"+p; }

    static String text(List<Res> rs, String unit) {
        Stats s = stats(rs); String u = unit==null?autoUnit(s.avgNs()):unit; StringBuilder b=new StringBuilder();
        b.append("Summary:\n");
        b.append(String.format(Locale.US,"  Success rate:\t%.2f%%\n", s.successRate));
        b.append("  Total:\t").append(fmt(s.totalNs,u)).append(" ").append(u).append("\n");
        b.append("  Slowest:\t").append(s.okCount==0?"-inf":fmt(s.max,u)).append(" ").append(u).append("\n");
        b.append("  Fastest:\t").append(s.okCount==0?"inf":fmt(s.min,u)).append(" ").append(u).append("\n");
        b.append("  Average:\t").append(s.okCount==0?"NaN":fmt(s.avgNs(),u)).append(" ").append(u).append("\n");
        b.append(String.format(Locale.US,"  Requests/sec:\t%.4f\n\n", s.rps));
        b.append("  Total data:\t").append(bytes(s.bytes)).append("\n");
        b.append("  Size/request:\t").append(s.okCount==0?"NaN":bytes((long)(s.bytes/(double)s.okCount))).append("\n");
        b.append("  Size/sec:\t").append(bytes((long)(s.bytes/Math.max(s.totalNs/1e9,1e-9)))).append("\n\n");
        b.append("Response time histogram:\n");
        for(int i=0;i<11;i++) b.append(String.format(Locale.US,"  %8s %s [%d] |\n", s.okCount==0?"NaN":fmt(s.percentile((i+1)/11.0),u), u, 0));
        b.append("\nResponse time distribution:\n");
        double[] ps={.10,.25,.50,.75,.90,.95,.99,.999,.9999}; String[] pn={"10.00","25.00","50.00","75.00","90.00","95.00","99.00","99.90","99.99"};
        for(int i=0;i<ps.length;i++) b.append("  ").append(pn[i]).append("% in ").append(s.okCount==0?"NaN":fmt(s.percentile(ps[i]),u)).append(" ").append(u).append("\n");
        b.append("\n\nDetails (average, fastest, slowest):\n");
        b.append("  DNS+dialup:\t").append(s.okCount==0?"NaN "+u+", inf "+u+", -inf "+u:"0.0000 ns, 0.0000 ns, 0.0000 ns").append("\n");
        b.append("  DNS-lookup:\t").append(s.okCount==0?"NaN "+u+", inf "+u+", -inf "+u:"0.0000 ns, 0.0000 ns, 0.0000 ns").append("\n\n");
        b.append("Status code distribution:\n"); s.status.forEach((k,v)->b.append("  [").append(v).append("] ").append(k).append("\n"));
        b.append("\nError distribution:\n"); s.errors.forEach((k,v)->b.append("  [").append(v).append("] ").append(k).append("\n"));
        return b.toString();
    }
    static String csv(List<Res> rs){ StringBuilder b=new StringBuilder("request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status\n"); for(Res r:rs) if(r.err==null) b.append(sec(r.startNs)).append(',').append(sec(r.dnsNs)).append(',').append(sec(r.dialNs)).append(',').append(sec(r.delayNs)).append(',').append(sec(r.durationNs)).append(',').append(r.bytes).append(',').append(r.status).append('\n'); return b.toString(); }
    static String json(List<Res> rs) {
        Stats s=stats(rs); StringBuilder b=new StringBuilder(); b.append("{\n  \"summary\": {\n");
        b.append("    \"successRate\": ").append(s.successRate/100.0).append(",\n");
        b.append("    \"total\": ").append(sec(s.totalNs)).append(",\n");
        b.append("    \"slowest\": ").append(numOrNull(s.okCount,s.max/1e9)).append(",\n");
        b.append("    \"fastest\": ").append(numOrNull(s.okCount,s.min/1e9)).append(",\n");
        b.append("    \"average\": ").append(numOrNull(s.okCount,s.avgNs()/1e9)).append(",\n");
        b.append("    \"requestsPerSec\": ").append(s.rps).append(",\n");
        b.append("    \"totalData\": ").append(s.bytes).append(",\n");
        b.append("    \"sizePerRequest\": ").append(numOrNull(s.okCount,s.bytes/(double)Math.max(1,s.okCount))).append(",\n");
        b.append("    \"sizePerSec\": ").append(s.bytes/Math.max(s.totalNs/1e9,1e-9)).append("\n  },\n");
        b.append("  \"responseTimeHistogram\": {\n    \"").append(s.okCount==0?"NaN":String.valueOf(sec(s.avgNs()))).append("\": ").append(s.okCount).append("\n  },\n");
        b.append("  \"latencyPercentiles\": {\n"); String[] keys={"p10","p25","p50","p75","p90","p95","p99","p99.9","p99.99"}; double[] ps={.1,.25,.5,.75,.9,.95,.99,.999,.9999};
        for(int i=0;i<keys.length;i++) b.append("    \"").append(keys[i]).append("\": ").append(numOrNull(s.okCount,s.percentile(ps[i])/1e9)).append(i==keys.length-1?"\n":",\n");
        b.append("  },\n  \"rps\": {\n    \"mean\": null,\n    \"stddev\": null,\n    \"max\": null,\n    \"min\": null,\n    \"percentiles\": {\n      \"p10\": null,\n      \"p25\": null,\n      \"p50\": null,\n      \"p75\": null,\n      \"p90\": null,\n      \"p95\": null,\n      \"p99\": null,\n      \"p99.9\": null,\n      \"p99.99\": null\n    }\n  },\n");
        b.append("  \"details\": {\n    \"DNSDialup\": {\n      \"average\": null,\n      \"fastest\": null,\n      \"slowest\": null\n    },\n    \"DNSLookup\": {\n      \"average\": null,\n      \"fastest\": null,\n      \"slowest\": null\n    }\n  },\n");
        b.append("  \"statusCodeDistribution\": {"); appendMapJson(b,s.status); b.append("\n  },\n  \"errorDistribution\": {"); appendMapJson(b,s.errors); b.append("\n  }\n}"); return b.toString();
    }
    static void appendMapJson(StringBuilder b, Map<?,Integer> m){ if(!m.isEmpty()) b.append('\n'); int i=0,n=m.size(); for(var e:m.entrySet()) b.append("    \"").append(esc(String.valueOf(e.getKey()))).append("\": ").append(e.getValue()).append(++i<n?",\n":""); }
    static String numOrNull(long n,double v){ return n==0?"null":String.valueOf(v); }
    static double sec(double ns){ return ns/1e9; }
    static String esc(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }
    static String autoUnit(double ns){ if(Double.isNaN(ns))return "ns"; if(ns<1000)return"ns"; if(ns<1_000_000)return"us"; if(ns<1_000_000_000)return"ms"; return"s"; }
    static String fmt(double ns,String u){ double v=switch(u){case"ns"->ns;case"us"->ns/1e3;case"ms"->ns/1e6;case"s"->ns/1e9;case"m"->ns/60e9;case"h"->ns/3600e9;default->ns;}; return String.format(Locale.US,"%.4f",v); }
    static String bytes(long b){ if(b<1024)return b+" B"; if(b<1024*1024)return String.format(Locale.US,"%.2f KiB",b/1024.0); return String.format(Locale.US,"%.2f MiB",b/1024.0/1024.0); }
    static class Stats {
        long totalNs, min=Long.MAX_VALUE, max=Long.MIN_VALUE, sum, bytes, okCount; double successRate,rps; List<Long> times=new ArrayList<>(); Map<Integer,Integer> status=new TreeMap<>(); Map<String,Integer> errors=new TreeMap<>();
        double avgNs(){ return okCount==0?Double.NaN:sum/(double)okCount; }
        double percentile(double p){ if(times.isEmpty())return Double.NaN; Collections.sort(times); int idx=(int)Math.ceil(p*times.size())-1; return times.get(Math.max(0,Math.min(idx,times.size()-1))); }
    }
    static Stats stats(List<Res> rs){ Stats s=new Stats(); long end=0; for(Res r:rs) end=Math.max(end,r.startNs+r.durationNs); s.totalNs=Math.max(1,end); for(Res r:rs){ if(r.err!=null) s.errors.merge(r.err,1,Integer::sum); else {s.status.merge(r.status,1,Integer::sum); if(r.ok){s.okCount++; s.bytes+=r.bytes; s.sum+=r.durationNs; s.min=Math.min(s.min,r.durationNs); s.max=Math.max(s.max,r.durationNs); s.times.add(r.durationNs);}} } s.successRate=rs.isEmpty()?0:(100.0*s.okCount/rs.size()); s.rps=rs.size()/Math.max(s.totalNs/1e9,1e-9); return s; }
}
