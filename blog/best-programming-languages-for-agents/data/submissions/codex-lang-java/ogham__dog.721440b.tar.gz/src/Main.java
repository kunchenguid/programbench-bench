import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;

public class Main {
    static final String HELP = "dog \u25cf command-line DNS client\n\n" +
            "Usage:\n  dog [OPTIONS] [--] <arguments>\n\n" +
            "Examples:\n" +
            "  dog example.net                          Query a domain using default settings\n" +
            "  dog example.net MX                       ...looking up MX records instead\n" +
            "  dog example.net MX @1.1.1.1              ...using a specific nameserver instead\n" +
            "  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP\n" +
            "  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments\n\n" +
            "Query options:\n" +
            "  <arguments>              Human-readable host names, nameservers, types, or classes\n" +
            "  -q, --query=HOST         Host name or domain name to query\n" +
            "  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)\n" +
            "  -n, --nameserver=ADDR    Address of the nameserver to send packets to\n" +
            "  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)\n\n" +
            "Sending options:\n" +
            "  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)\n" +
            "  --txid=NUMBER            Set the transaction ID to a specific value\n" +
            "  -Z=TWEAKS                Set uncommon protocol-level tweaks\n\n" +
            "Protocol options:\n" +
            "  -U, --udp                Use the DNS protocol over UDP\n" +
            "  -T, --tcp                Use the DNS protocol over TCP\n" +
            "  -S, --tls                Use the DNS-over-TLS protocol\n" +
            "  -H, --https              Use the DNS-over-HTTPS protocol\n\n" +
            "Output options:\n" +
            "  -1, --short              Short mode: display nothing but the first result\n" +
            "  -J, --json               Display the output as JSON\n" +
            "  --color, --colour=WHEN   When to colourise the output (always, automatic, never)\n" +
            "  --seconds                Do not format durations, display them as seconds\n" +
            "  --time                   Print how long the response took to arrive\n\n" +
            "Meta options:\n" +
            "  -?, --help               Print list of command-line options\n" +
            "  -v, --version            Print version information";
    static final Map<String,Integer> TYPES = new HashMap<>();
    static final Map<Integer,String> TYPE_NAMES = new HashMap<>();
    static final Map<String,Integer> CLASSES = Map.of("IN",1,"CH",3,"HS",4);
    static {
        Object[][] t={{"A",1},{"NS",2},{"CNAME",5},{"SOA",6},{"PTR",12},{"HINFO",13},{"MX",15},{"TXT",16},{"AAAA",28},{"LOC",29},{"SRV",33},{"NAPTR",35},{"CAA",257},{"SSHFP",44},{"TLSA",52},{"OPT",41},{"AFSDB",18},{"ANY",255},{"IXFR",251},{"AXFR",252}};
        for (Object[] e:t){TYPES.put((String)e[0],(Integer)e[1]);TYPE_NAMES.put((Integer)e[1],(String)e[0]);}
    }
    static class Opt {
        List<String> queries=new ArrayList<>(), servers=new ArrayList<>();
        List<Integer> types=new ArrayList<>(), classes=new ArrayList<>();
        boolean tcp=false, tls=false, https=false, udp=false, json=false, sh=false, seconds=false, time=false;
        String edns="hide"; Integer txid=null; int flags=0; int bufsize=4096; boolean showEdns=false;
    }
    static class Msg { List<Question> qs=new ArrayList<>(); List<RR> an=new ArrayList<>(), ns=new ArrayList<>(), ar=new ArrayList<>(); int rcode; boolean tc; }
    static class Question { String name; int type, cls; Question(String n,int t,int c){name=n;type=t;cls=c;} }
    static class RR { String name; int type, cls; long ttl; byte[] data; String text; Map<String,Object> json; }

    public static void main(String[] args) {
        try {
            int rc = run(args);
            System.exit(rc);
        } catch (Bad b) {
            System.err.println("dog: Invalid options: " + b.getMessage());
            System.exit(3);
        }
    }
    static int run(String[] args) throws Bad {
        Opt o=parse(args);
        if (o==null) return 0;
        if (o.queries.isEmpty()) { System.out.println(HELP); return 3; }
        if (o.types.isEmpty()) o.types.add(1);
        if (o.classes.isEmpty()) o.classes.add(1);
        if (o.servers.isEmpty()) o.servers.addAll(systemResolvers());
        if (o.servers.isEmpty()) { System.err.println("Error [system]: No nameservers found"); return 4; }
        List<Msg> ok = new ArrayList<>(); List<String> errs = new ArrayList<>(); long started=System.nanoTime();
        outer: for (String q:o.queries) for (int typ:o.types) for (int cls:o.classes) for (String srv:o.servers) {
            try { ok.add(query(o, q, typ, cls, srv)); }
            catch (Exception e) { errs.add(cleanError(e)); if (o.sh) break outer; }
        }
        if (o.json) {
            StringBuilder sb=new StringBuilder("{\"responses\":[");
            for(int i=0;i<ok.size();i++){ if(i>0)sb.append(','); jsonMsg(sb, ok.get(i)); }
            sb.append("]}"); System.out.println(sb);
            if(!errs.isEmpty()) System.err.println("{\"error\":true,\"error_phase\":\"network\",\"error_message\":\""+esc(errs.get(0))+"\"}");
        } else if (o.sh) {
            String first=null; for(Msg m:ok){ for(RR r:m.an){ first=shortText(r); if(first!=null)break; } if(first!=null)break; }
            if(first!=null) System.out.println(first);
            else { if(!errs.isEmpty()) System.err.println("Error [network]: "+errs.get(0)); System.err.println("No results"); return 2; }
        } else {
            for (Msg m: ok) for (RR r: allRecords(m,o.showEdns)) printRR(r,o);
            for (String e: errs) System.err.println("Error [network]: "+e);
            if(o.time) System.out.println("Ran in "+Math.max(0,Math.round((System.nanoTime()-started)/1_000_000.0))+"ms");
        }
        return errs.isEmpty() ? 0 : 1;
    }
    static List<RR> allRecords(Msg m, boolean showEdns){ List<RR> l=new ArrayList<>(); l.addAll(m.an); l.addAll(m.ns); for(RR r:m.ar) if(showEdns||r.type!=41) l.add(r); return l; }
    static Opt parse(String[] args) throws Bad {
        Opt o=new Opt(); boolean plain=true;
        for(int i=0;i<args.length;i++){
            String a=args[i]; if(plain && a.equals("--")){plain=false;continue;}
            if(plain && (a.equals("--help")||a.equals("-?"))){System.out.println(HELP);return null;}
            if(plain && (a.equals("--version")||a.equals("-v"))){System.out.println("dog \u25cf command-line DNS client\nv0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)\nmhttps://dns.lookup.dog/");return null;}
            if(plain && a.startsWith("-")){
                String val=null,opt=a; int eq=a.indexOf('='); if(eq>=0){opt=a.substring(0,eq);val=a.substring(eq+1);}
                switch(opt){
                    case "-q": case "--query": o.queries.add(value(args,++i,val,opt)); break;
                    case "-t": case "--type": o.types.add(type(value(args,++i,val,opt))); break;
                    case "-n": case "--nameserver": o.servers.add(value(args,++i,val,opt)); break;
                    case "--class": o.classes.add(qclass(value(args,++i,val,opt))); break;
                    case "--edns": o.edns=value(args,++i,val,opt); if(!List.of("disable","hide","show").contains(o.edns)) throw new Bad("Invalid EDNS setting \""+o.edns+"\""); o.showEdns=o.edns.equals("show"); break;
                    case "--txid": String tx=value(args,++i,val,opt); try{o.txid=Integer.parseInt(tx); if(o.txid<0||o.txid>65535)throw new Exception();}catch(Exception e){throw new Bad("Invalid transaction ID \""+tx+"\"");} break;
                    case "-Z": String z=value(args,++i,val,opt); tweak(o,z); break;
                    case "-U": case "--udp": o.udp=true; break; case "-T": case "--tcp": o.tcp=true; break; case "-S": case "--tls": o.tls=true; break; case "-H": case "--https": o.https=true; break;
                    case "-1": case "--short": o.sh=true; break; case "-J": case "--json": o.json=true; break; case "--seconds": o.seconds=true; break; case "--time": o.time=true; break;
                    case "--color": case "--colour": value(args,++i,val,opt); break;
                    default: throw new Bad("Unrecognized option: '"+a.replaceFirst("^-+","")+"'");
                }
            } else classify(o,a);
        }
        return o;
    }
    static String value(String[] args,int idx,String val,String opt)throws Bad{ if(val!=null)return val; if(idx>=args.length)throw new Bad("Option "+opt+" needs a value"); return args[idx]; }
    static void classify(Opt o,String a)throws Bad{ if(a.startsWith("@")) o.servers.add(a.substring(1)); else if(TYPES.containsKey(a.toUpperCase(Locale.ROOT))) o.types.add(TYPES.get(a.toUpperCase(Locale.ROOT))); else if(CLASSES.containsKey(a.toUpperCase(Locale.ROOT))) o.classes.add(CLASSES.get(a.toUpperCase(Locale.ROOT))); else o.queries.add(a); }
    static int type(String s)throws Bad{ s=s.toUpperCase(Locale.ROOT); if(s.startsWith("TYPE")) try{return Integer.parseInt(s.substring(4));}catch(Exception ignored){} Integer v=TYPES.get(s); if(v==null)throw new Bad("Invalid query type \""+s+"\""); return v; }
    static int qclass(String s)throws Bad{ Integer v=CLASSES.get(s.toUpperCase(Locale.ROOT)); if(v==null)throw new Bad("Invalid query class \""+s+"\""); return v; }
    static void tweak(Opt o,String z)throws Bad{ if(z.equals("aa"))o.flags|=0x0400; else if(z.equals("ad"))o.flags|=0x0020; else if(z.equals("cd"))o.flags|=0x0010; else if(z.startsWith("bufsize="))try{o.bufsize=Integer.parseInt(z.substring(8));}catch(Exception e){throw new Bad("Invalid protocol tweak \""+z+"\"");} else throw new Bad("Invalid protocol tweak \""+z+"\""); }

    static Msg query(Opt o,String q,int typ,int cls,String server) throws Exception {
        HostPort hp=parseServer(server, o.https?443:(o.tls?853:53));
        byte[] pkt=packet(o,q,typ,cls);
        byte[] resp;
        if(o.tcp||o.tls||o.https) resp=tcp(hp,pkt); else { resp=udp(hp,pkt); if(resp.length>3 && (resp[2]&2)!=0 && !o.udp) resp=tcp(hp,pkt); }
        return parseMsg(resp);
    }
    static class HostPort{String h;int p;HostPort(String h,int p){this.h=h;this.p=p;}}
    static HostPort parseServer(String s,int def){ if(s.startsWith("http://")||s.startsWith("https://")){ try{URL u=new URL(s); return new HostPort(u.getHost(), u.getPort()>0?u.getPort():443);}catch(Exception e){return new HostPort(s,def);} } int p=s.lastIndexOf(':'); if(p>0 && s.indexOf(':')==p) try{return new HostPort(s.substring(0,p),Integer.parseInt(s.substring(p+1)));}catch(Exception ignored){} return new HostPort(s,def); }
    static byte[] udp(HostPort hp,byte[] pkt)throws Exception{ DatagramSocket ds=new DatagramSocket(); ds.setSoTimeout(3000); DatagramPacket p=new DatagramPacket(pkt,pkt.length,InetAddress.getByName(hp.h),hp.p); ds.send(p); byte[] b=new byte[65535]; DatagramPacket r=new DatagramPacket(b,b.length); ds.receive(r); ds.close(); return Arrays.copyOf(b,r.getLength()); }
    static byte[] tcp(HostPort hp,byte[] pkt)throws Exception{ Socket s=new Socket(); s.connect(new InetSocketAddress(hp.h,hp.p),3000); s.setSoTimeout(3000); OutputStream out=s.getOutputStream(); out.write(pkt.length>>8); out.write(pkt.length); out.write(pkt); InputStream in=s.getInputStream(); int a=in.read(),b=in.read(); if(a<0||b<0)throw new EOFException(); int len=(a<<8)|b; byte[] r=in.readNBytes(len); s.close(); return r; }
    static byte[] packet(Opt o,String q,int typ,int cls)throws IOException{ ByteArrayOutputStream b=new ByteArrayOutputStream(); int id=o.txid!=null?o.txid:new SecureRandom().nextInt(65536); w16(b,id); w16(b,0x0100|o.flags); w16(b,1); w16(b,0); w16(b,0); w16(b,o.edns.equals("disable")?0:1); name(b,q); w16(b,typ); w16(b,cls); if(!o.edns.equals("disable")){ b.write(0); w16(b,41); w16(b,o.bufsize); b.write(new byte[]{0,0,0,0}); w16(b,0);} return b.toByteArray(); }
    static void w16(OutputStream o,int v)throws IOException{o.write((v>>8)&255);o.write(v&255);} static void w32(OutputStream o,long v)throws IOException{w16(o,(int)(v>>16));w16(o,(int)v);}
    static void name(OutputStream o,String n)throws IOException{ if(n.endsWith("."))n=n.substring(0,n.length()-1); if(n.isEmpty()){o.write(0);return;} for(String p:n.split("\\\\.")){ byte[] bs=p.getBytes(StandardCharsets.UTF_8); o.write(bs.length); o.write(bs);} o.write(0); }
    static Msg parseMsg(byte[] b)throws IOException{ Msg m=new Msg(); m.tc=(b[2]&2)!=0; m.rcode=b[3]&15; int qd=u16(b,4), an=u16(b,6), ns=u16(b,8), ar=u16(b,10), off=12; for(int i=0;i<qd;i++){ Name n=readName(b,off); off=n.off; int t=u16(b,off), c=u16(b,off+2); off+=4; m.qs.add(new Question(n.name,t,c)); } off=readRRs(b,off,an,m.an); off=readRRs(b,off,ns,m.ns); readRRs(b,off,ar,m.ar); return m; }
    static int readRRs(byte[] b,int off,int count,List<RR> out)throws IOException{ for(int i=0;i<count;i++){ Name n=readName(b,off); off=n.off; RR r=new RR(); r.name=n.name; r.type=u16(b,off); r.cls=u16(b,off+2); r.ttl=u32(b,off+4); int l=u16(b,off+8); off+=10; r.data=Arrays.copyOfRange(b,off,Math.min(b.length,off+l)); r.text=rrText(b,off,l,r); r.json=rrJson(r); off+=l; out.add(r);} return off; }
    static class Name{String name;int off;Name(String n,int o){name=n;off=o;}}
    static Name readName(byte[] b,int off)throws IOException{ StringBuilder s=new StringBuilder(); int p=off,end=-1,guard=0; while(true){ if(++guard>128)throw new IOException("bad name"); int l=b[p]&255; if((l&0xc0)==0xc0){ if(end<0)end=p+2; p=((l&63)<<8)|(b[p+1]&255); continue;} p++; if(l==0)break; if(s.length()>0)s.append('.'); s.append(new String(b,p,l,StandardCharsets.UTF_8)); p+=l;} s.append('.'); return new Name(s.toString(),end<0?p:end); }
    static int u16(byte[]b,int o){return ((b[o]&255)<<8)|(b[o+1]&255);} static long u32(byte[]b,int o){return ((long)u16(b,o)<<16)|u16(b,o+2);}
    static String rrText(byte[] msg,int off,int len,RR r){ try{ byte[] d=r.data; switch(r.type){
        case 1: return InetAddress.getByAddress(d).getHostAddress();
        case 28: return InetAddress.getByAddress(d).getHostAddress();
        case 2: case 5: case 12: return quote(readName(msg,off).name);
        case 15: return u16(d,0)+" "+quote(readName(msg,off+2).name);
        case 16: { List<String> xs=new ArrayList<>(); for(int p=0;p<d.length;){ int l=d[p++]&255; xs.add(quote(new String(d,p,Math.min(l,d.length-p),StandardCharsets.UTF_8))); p+=l;} return String.join(", ",xs); }
        case 6: { Name a=readName(msg,off); Name b=readName(msg,a.off); int p=b.off; return quote(a.name)+" "+quote(b.name)+" "+u32(msg,p)+" "+dur(u32(msg,p+4),false)+" "+dur(u32(msg,p+8),false)+" "+dur(u32(msg,p+12),false)+" "+dur(u32(msg,p+16),false); }
        case 33: return u16(d,0)+" "+u16(d,2)+" "+u16(d,4)+" "+quote(readName(msg,off+6).name);
        case 13: { int p=0,l=d[p++]&255; String cpu=new String(d,p,l,StandardCharsets.UTF_8); p+=l; int l2=d[p++]&255; return quote(cpu)+" "+quote(new String(d,p,l2,StandardCharsets.UTF_8)); }
        case 44: return (d[0]&255)+" "+(d[1]&255)+" "+hex(Arrays.copyOfRange(d,2,d.length));
        case 52: return (d[0]&255)+" "+(d[1]&255)+" "+(d[2]&255)+" "+hex(Arrays.copyOfRange(d,3,d.length));
        case 257: return (d[0]&255)+" "+quote(new String(d,1,d.length-1,StandardCharsets.UTF_8));
        default: List<String> nums=new ArrayList<>(); for(byte x:d)nums.add(Integer.toString(x&255)); return String.join(" ",nums);
    }}catch(Exception e){ List<String> nums=new ArrayList<>(); for(byte x:r.data)nums.add(Integer.toString(x&255)); return String.join(" ",nums);} }
    static Map<String,Object> rrJson(RR r){ Map<String,Object> m=new LinkedHashMap<>(); if(r.type==1||r.type==28)m.put("address",r.text); else m.put("contents",r.text); return m; }
    static void printRR(RR r,Opt o){ System.out.printf("%s %s %s   %s%n", padType(r.type), r.name, dur(r.ttl,o.seconds), r.text); }
    static String padType(int t){ String n=TYPE_NAMES.getOrDefault(t,"TYPE"+t); return n.length()==1?" "+n:n; }
    static String shortText(RR r){ if(r.type==1||r.type==28)return r.text; if(r.text!=null)return r.text.replace("\"",""); return null; }
    static String dur(long s,boolean seconds){ if(seconds)return Long.toString(s); long h=s/3600,m=(s%3600)/60,sec=s%60; if(h>0)return String.format("%dh%02dm%02ds",h,m,sec); if(m>0)return String.format("%dm%02ds",m,sec); return sec+"s"; }
    static String quote(String s){return "\""+s+"\"";} static String hex(byte[]b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format("%02x",x&255));return s.toString();}
    static void jsonMsg(StringBuilder sb,Msg m){ sb.append("{\"queries\":["); for(int i=0;i<m.qs.size();i++){Question q=m.qs.get(i); if(i>0)sb.append(','); sb.append("{\"name\":\"").append(esc(q.name)).append("\",\"class\":\"").append(clsName(q.cls)).append("\",\"type\":\"").append(TYPE_NAMES.getOrDefault(q.type,"TYPE"+q.type)).append("\"}");} sb.append("],\"answers\":"); jsonRRs(sb,m.an); sb.append(",\"authorities\":"); jsonRRs(sb,m.ns); sb.append(",\"additionals\":"); jsonRRs(sb,m.ar); sb.append('}'); }
    static void jsonRRs(StringBuilder sb,List<RR> rs){ sb.append('['); for(int i=0;i<rs.size();i++){ RR r=rs.get(i); if(i>0)sb.append(','); sb.append("{\"name\":\"").append(esc(r.name)).append("\",\"class\":\"").append(clsName(r.cls)).append("\",\"ttl\":").append(r.ttl).append(",\"type\":\"").append(TYPE_NAMES.getOrDefault(r.type,"TYPE"+r.type)).append("\",\"data\":{"); int j=0; for(var e:r.json.entrySet()){ if(j++>0)sb.append(','); sb.append("\"").append(e.getKey()).append("\":\"").append(esc(String.valueOf(e.getValue()))).append("\""); } sb.append("}}"); } sb.append(']'); }
    static String clsName(int c){return c==1?"IN":c==3?"CH":c==4?"HS":"CLASS"+c;} static String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"");}
    static List<String> systemResolvers(){ List<String> out=new ArrayList<>(); try(BufferedReader r=new BufferedReader(new FileReader("/etc/resolv.conf"))){ String l; while((l=r.readLine())!=null){ l=l.trim(); if(l.startsWith("nameserver")){ String[] p=l.split("\\s+"); if(p.length>1)out.add(p[1]); } } } catch(Exception ignored){} return out; }
    static String cleanError(Exception e){ String m=e.getMessage(); if(m==null)m=e.toString(); if(m.contains("Network is unreachable"))return "Network is unreachable (os error 101)"; if(m.contains("Connection refused"))return "Connection refused (os error 111)"; return m; }
    static class Bad extends Exception{ Bad(String m){super(m);} }
}
