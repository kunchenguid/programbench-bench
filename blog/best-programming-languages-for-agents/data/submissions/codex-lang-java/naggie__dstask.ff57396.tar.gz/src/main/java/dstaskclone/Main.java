package dstaskclone;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class Main {
    static final String ZERO_TIME = "0001-01-01T00:00:00Z";
    static final DateTimeFormatter INSTANT_FMT = DateTimeFormatter.ISO_INSTANT;
    static Path repo;
    static boolean ignoreContext;

    static class Task {
        String uuid = UUID.randomUUID().toString();
        String status = "pending";
        int id;
        String summary = "";
        String notes = "";
        List<String> tags = new ArrayList<>();
        String project = "";
        String priority = "P2";
        String created = now();
        String resolved = ZERO_TIME;
        String due = ZERO_TIME;
        Path path;
    }

    static class Spec {
        List<String> words = new ArrayList<>();
        List<String> addTags = new ArrayList<>();
        List<String> removeTags = new ArrayList<>();
        String project;
        boolean clearProject;
        String priority;
        String due;
        String note = "";
    }

    public static void main(String[] args) {
        try {
            repo = repoPath();
            List<String> argv = new ArrayList<>(List.of(args));
            if (argv.remove("--")) ignoreContext = true;
            ensureRepo();
            if (argv.isEmpty()) {
                printTasks(filter(loadTasks(), List.of(), false, "open"), 3);
                return;
            }
            dispatch(argv);
        } catch (UserError e) {
            err(e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            err(e.getMessage() == null ? e.toString() : e.getMessage());
            System.exit(1);
        }
    }

    static void dispatch(List<String> argv) throws Exception {
        List<Integer> ids = new ArrayList<>();
        String cmd = null;
        List<String> rest = new ArrayList<>();
        for (String a : argv) {
            if (cmd == null && isInt(a)) ids.add(Integer.parseInt(a));
            else if (cmd == null) cmd = a;
            else rest.add(a);
        }
        if (cmd == null) cmd = "next";
        if (!COMMANDS.contains(cmd) && ids.isEmpty()) {
            rest = new ArrayList<>(argv);
            cmd = "next";
        } else if (!COMMANDS.contains(cmd) && !ids.isEmpty()) {
            throw new UserError("unknown command: " + cmd);
        }
        if (Set.of("start","stop","done","remove","modify","note").contains(cmd)) {
            while (!rest.isEmpty() && isInt(rest.get(0))) {
                ids.add(Integer.parseInt(rest.remove(0)));
            }
        }
        switch (cmd) {
            case "help" -> help(rest);
            case "version" -> System.out.print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown\n");
            case "add" -> add(rest, false, false);
            case "template" -> add(rest, true, false);
            case "log" -> add(rest, false, true);
            case "next" -> printTasks(filter(loadTasks(), rest, false, "open"), 3);
            case "show-open" -> printTasks(filter(loadTasks(), rest, false, "open"), 0);
            case "show-resolved" -> printTasks(filter(loadTasks(), rest, false, "resolved"), 0);
            case "show-active" -> printTasks(filter(loadTasks(), rest, false, "active"), 0);
            case "show-paused" -> printTasks(filter(loadTasks(), rest, false, "paused"), 0);
            case "show-templates" -> printTasks(filter(loadTasks(), rest, false, "template"), 0);
            case "show-unorganised" -> printTasks(showUnorganised(), 0);
            case "show-tags" -> showTags();
            case "show-projects" -> showProjects();
            case "start" -> change(ids, "active", "Started");
            case "stop" -> change(ids, "paused", "Stopped");
            case "done" -> change(ids, "resolved", "Resolved");
            case "remove" -> remove(ids);
            case "modify" -> modify(ids, rest);
            case "note" -> note(ids, rest);
            case "context" -> context(rest);
            case "git" -> runGit(rest, true);
            case "sync" -> { runGit(List.of("pull", "--no-edit"), true); runGit(List.of("push"), true); }
            case "bash-completion", "fish-completion", "zsh-completion", "powershell-completion" -> {}
            case "edit", "open", "undo" -> {}
            default -> throw new UserError("unknown command: " + cmd);
        }
    }

    static final Set<String> COMMANDS = Set.of("next","add","template","log","start","note","stop","done","context",
            "modify","edit","undo","sync","open","git","remove","show-projects","show-tags","show-active",
            "show-paused","show-open","show-resolved","show-templates","show-unorganised","bash-completion",
            "fish-completion","zsh-completion","powershell-completion","help","version");

    static void add(List<String> args, boolean template, boolean resolved) throws Exception {
        Spec s = parseSpec(args, true);
        applyContextToSpec(s);
        Task t = new Task();
        t.status = template ? "template" : (resolved ? "resolved" : "pending");
        t.summary = String.join(" ", s.words).trim();
        t.notes = s.note;
        t.tags.addAll(unique(s.addTags));
        t.project = s.project == null ? "" : s.project;
        if (s.priority != null) t.priority = s.priority;
        if (s.due != null) t.due = s.due;
        if (resolved) t.resolved = now();
        saveTask(t);
        List<Task> all = loadTasks();
        assignIds(all);
        Task saved = findByUuid(all, t.uuid);
        int id = saved == null ? maxId(all) : saved.id;
        String action = template ? "Added template " : "Added ";
        System.out.println("\n" + action + id + ": " + t.summary);
        commit(action + id + ": " + t.summary);
    }

    static void change(List<Integer> ids, String status, String verb) throws Exception {
        if (ids.isEmpty()) throw new UserError("no task specified");
        List<Task> tasks = loadTasks();
        assignIds(tasks);
        for (int id : ids) {
            Task t = byOpenId(tasks, id);
            if (t == null) throw new UserError("no open task with ID " + id + " exists");
            t.status = status;
            if (status.equals("resolved")) t.resolved = now();
            saveTask(t);
            deleteOldPath(t);
            System.out.println(verb + " " + id + ": " + t.summary);
            commit(verb + " " + id + ": " + t.summary);
        }
    }

    static void remove(List<Integer> ids) throws Exception {
        if (ids.isEmpty()) throw new UserError("no task specified");
        List<Task> tasks = loadTasks();
        assignIds(tasks);
        for (int id : ids) {
            Task t = byOpenId(tasks, id);
            if (t == null) throw new UserError("no open task with ID " + id + " exists");
            Files.deleteIfExists(t.path);
            System.out.println("Removed " + id + ": " + t.summary);
            commit("Removed " + id + ": " + t.summary);
        }
    }

    static void modify(List<Integer> ids, List<String> args) throws Exception {
        Spec s = parseSpec(args, false);
        List<Task> tasks = loadTasks();
        assignIds(tasks);
        List<Task> targets = new ArrayList<>();
        if (ids.isEmpty()) targets.addAll(filter(tasks, List.of(), true, "open"));
        else for (int id : ids) {
            Task t = byOpenId(tasks, id);
            if (t == null) throw new UserError("no open task with ID " + id + " exists");
            targets.add(t);
        }
        for (Task t : targets) {
            for (String tag : s.addTags) if (!t.tags.contains(tag)) t.tags.add(tag);
            t.tags.removeAll(s.removeTags);
            if (s.project != null) t.project = s.project;
            if (s.clearProject) t.project = "";
            if (s.priority != null) t.priority = s.priority;
            if (s.due != null) t.due = s.due;
            saveTask(t);
            System.out.println("Modified " + t.id + ": " + t.summary);
            commit("Modified " + t.id + ": " + t.summary);
        }
    }

    static void note(List<Integer> ids, List<String> text) throws Exception {
        if (ids.isEmpty()) throw new UserError("no task specified");
        List<Task> tasks = loadTasks();
        assignIds(tasks);
        Task t = byOpenId(tasks, ids.get(0));
        if (t == null) throw new UserError("no open task with ID " + ids.get(0) + " exists");
        if (!text.isEmpty()) {
            String add = String.join(" ", text);
            t.notes = t.notes.isEmpty() ? add : t.notes + "\n" + add;
            saveTask(t);
            System.out.println("Modified " + t.id + ": " + t.summary);
            commit("Modified " + t.id + ": " + t.summary);
        } else {
            System.out.println(t.notes);
        }
    }

    static void context(List<String> args) throws IOException {
        Path p = repo.resolve("context");
        if (args.isEmpty()) {
            if (Files.exists(p)) System.out.println(Files.readString(p).trim());
            return;
        }
        for (String a : args) if (!(a.startsWith("+") || a.startsWith("-") || a.startsWith("project:") || a.equals("none"))) {
            throw new UserError("context cannot contain text");
        }
        String val = args.get(0).equals("none") ? "" : String.join(" ", args);
        if (val.isEmpty()) Files.deleteIfExists(p); else Files.writeString(p, val + "\n");
        if (!val.isEmpty()) System.out.println(val);
    }

    static Spec parseSpec(List<String> args, boolean allowText) {
        Spec s = new Spec();
        boolean note = false;
        for (String a : args) {
            if (note) { if (!s.note.isEmpty()) s.note += " "; s.note += a; continue; }
            if (a.equals("/")) { note = true; continue; }
            if (a.matches("P[0-3]")) s.priority = a;
            else if (a.startsWith("+") && a.length() > 1) s.addTags.add(a.substring(1));
            else if (a.startsWith("-project:")) { s.clearProject = true; }
            else if (a.startsWith("-") && a.length() > 1) s.removeTags.add(a.substring(1));
            else if (a.startsWith("project:")) s.project = a.substring(8);
            else if (a.startsWith("due:")) s.due = parseDue(a.substring(4));
            else if (a.startsWith("template:")) {}
            else if (allowText) s.words.add(a);
        }
        return s;
    }

    static void applyContextToSpec(Spec s) throws IOException {
        String ctx = contextString();
        if (ignoreContext || ctx.isBlank()) return;
        Spec c = parseSpec(List.of(ctx.split("\\s+")), false);
        for (String tag : c.addTags) if (!s.addTags.contains(tag)) s.addTags.add(tag);
        if (s.project == null && c.project != null) s.project = c.project;
    }

    static List<Task> filter(List<Task> tasks, List<String> args, boolean contextOnly, String mode) throws IOException {
        Spec f = parseSpec(args, true);
        if (!ignoreContext) {
            Spec c = parseSpec(contextString().isBlank() ? List.of() : List.of(contextString().split("\\s+")), false);
            f.addTags.addAll(c.addTags);
            f.removeTags.addAll(c.removeTags);
            if (f.project == null) f.project = c.project;
        }
        String text = String.join(" ", f.words).toLowerCase(Locale.ROOT);
        List<Task> out = new ArrayList<>();
        for (Task t : tasks) {
            boolean open = Set.of("pending","active","paused").contains(t.status);
            if (mode.equals("open") && !open) continue;
            if (mode.equals("resolved") && !t.status.equals("resolved")) continue;
            if (mode.equals("active") && !t.status.equals("active")) continue;
            if (mode.equals("paused") && !t.status.equals("paused")) continue;
            if (mode.equals("template") && !t.status.equals("template")) continue;
            if (f.project != null && !f.project.equals(t.project)) continue;
            if (!t.tags.containsAll(f.addTags)) continue;
            boolean anti = false;
            for (String tag : f.removeTags) if (t.tags.contains(tag)) anti = true;
            if (anti) continue;
            if (!text.isBlank() && !(t.summary.toLowerCase(Locale.ROOT).contains(text) || t.notes.toLowerCase(Locale.ROOT).contains(text))) continue;
            out.add(t);
        }
        out.sort(taskComparator());
        assignIds(tasks);
        return out;
    }

    static List<Task> showUnorganised() throws Exception {
        List<Task> out = new ArrayList<>();
        for (Task t : loadTasks()) if (Set.of("pending","active","paused").contains(t.status) && t.tags.isEmpty() && t.project.isEmpty()) out.add(t);
        out.sort(taskComparator());
        assignIds(out);
        return out;
    }

    static void showTags() throws Exception {
        Set<String> tags = new HashSet<>();
        for (Task t : loadTasks()) if (!t.status.equals("resolved")) tags.addAll(t.tags);
        tags.stream().sorted().forEach(System.out::println);
    }

    static void showProjects() throws Exception {
        Map<String, List<Task>> map = new LinkedHashMap<>();
        for (Task t : loadTasks()) if (!t.project.isEmpty()) map.computeIfAbsent(t.project, k -> new ArrayList<>()).add(t);
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (String name : map.keySet().stream().sorted().toList()) {
            List<Task> ts = map.get(name);
            Task top = ts.stream().min(taskComparator()).orElse(ts.get(0));
            long resolved = ts.stream().filter(t -> t.status.equals("resolved")).count();
            boolean active = ts.stream().anyMatch(t -> t.status.equals("active"));
            if (!first) sb.append(",");
            first = false;
            sb.append("\n  {\n");
            field(sb, "name", name, true, 4); comma(sb);
            field(sb, "taskCount", ts.size(), false, 4); comma(sb);
            field(sb, "resolvedCount", resolved, false, 4); comma(sb);
            field(sb, "active", active, false, 4); comma(sb);
            field(sb, "created", top.created, true, 4); comma(sb);
            field(sb, "resolved", top.resolved, true, 4); comma(sb);
            field(sb, "priority", top.priority, true, 4);
            sb.append("\n  }");
        }
        if (!first) sb.append("\n");
        sb.append("]");
        System.out.print(sb);
    }

    static List<Task> loadTasks() throws IOException {
        List<Task> tasks = new ArrayList<>();
        for (String dir : List.of("pending","active","paused","resolved","template")) {
            Path d = repo.resolve(dir);
            if (!Files.isDirectory(d)) continue;
            try (var stream = Files.list(d)) {
                for (Path p : stream.filter(x -> x.toString().endsWith(".yml")).toList()) {
                    Task t = readTask(p);
                    t.status = dir;
                    t.path = p;
                    tasks.add(t);
                }
            }
        }
        tasks.sort(taskComparator());
        assignIds(tasks);
        return tasks;
    }

    static Task readTask(Path p) throws IOException {
        Task t = new Task();
        t.uuid = p.getFileName().toString().replaceFirst("\\.yml$", "");
        t.path = p;
        List<String> lines = Files.readAllLines(p);
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.startsWith("summary: ")) t.summary = unesc(line.substring(9));
            else if (line.startsWith("notes: ")) t.notes = unesc(line.substring(7));
            else if (line.equals("tags:")) {
                t.tags.clear();
                while (i + 1 < lines.size() && lines.get(i + 1).startsWith("- ")) t.tags.add(unesc(lines.get(++i).substring(2)));
            } else if (line.startsWith("project: ")) t.project = unesc(line.substring(9));
            else if (line.startsWith("priority: ")) t.priority = line.substring(10).trim();
            else if (line.startsWith("created: ")) t.created = line.substring(9).trim();
            else if (line.startsWith("resolved: ")) t.resolved = line.substring(10).trim();
            else if (line.startsWith("due: ")) t.due = line.substring(5).trim();
        }
        return t;
    }

    static void saveTask(Task t) throws IOException {
        Path dir = repo.resolve(t.status);
        Files.createDirectories(dir);
        Path target = dir.resolve(t.uuid + ".yml");
        StringBuilder sb = new StringBuilder();
        sb.append("summary: ").append(esc(t.summary)).append("\n");
        sb.append("notes: ").append(esc(t.notes)).append("\n");
        sb.append("tags:\n");
        for (String tag : t.tags.stream().distinct().sorted().toList()) sb.append("- ").append(esc(tag)).append("\n");
        sb.append("project: ").append(esc(t.project)).append("\n");
        sb.append("priority: ").append(t.priority).append("\n");
        sb.append("delegatedto: \"\"\nsubtasks: []\ndependencies: []\n");
        sb.append("created: ").append(t.created).append("\n");
        sb.append("resolved: ").append(t.resolved).append("\n");
        sb.append("due: ").append(t.due).append("\n");
        Files.writeString(target, sb.toString());
        if (t.path != null && !t.path.equals(target)) Files.deleteIfExists(t.path);
        t.path = target;
    }

    static void deleteOldPath(Task t) throws IOException {
        for (String dir : List.of("pending","active","paused","resolved","template")) {
            Path p = repo.resolve(dir).resolve(t.uuid + ".yml");
            if (!p.equals(t.path) && Files.exists(p)) Files.deleteIfExists(p);
        }
    }

    static void printTasks(List<Task> tasks, int limit) {
        List<Task> list = limit > 0 && tasks.size() > limit ? tasks.subList(0, limit) : tasks;
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        for (Task t : list) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\n  {\n");
            field(sb, "uuid", t.uuid, true, 4); comma(sb);
            field(sb, "status", t.status.equals("template") ? "pending" : t.status, true, 4); comma(sb);
            field(sb, "id", t.status.equals("resolved") ? 0 : t.id, false, 4); comma(sb);
            field(sb, "summary", t.summary, true, 4); comma(sb);
            field(sb, "notes", t.notes, true, 4); comma(sb);
            sb.append("    \"tags\": [");
            for (int i = 0; i < t.tags.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append("\n      \"").append(json(t.tags.get(i))).append("\"");
            }
            if (!t.tags.isEmpty()) sb.append("\n    ");
            sb.append("]"); comma(sb);
            field(sb, "project", t.project, true, 4); comma(sb);
            field(sb, "priority", t.priority, true, 4); comma(sb);
            field(sb, "created", t.created, true, 4); comma(sb);
            field(sb, "resolved", t.resolved, true, 4); comma(sb);
            field(sb, "due", t.due, true, 4);
            sb.append("\n  }");
        }
        if (!first) sb.append("\n");
        sb.append("]");
        System.out.print(sb);
    }

    static Comparator<Task> taskComparator() {
        Map<String,Integer> p = Map.of("P0",0,"P1",1,"P2",2,"P3",3);
        return Comparator.<Task>comparingInt(t -> p.getOrDefault(t.priority, 2))
                .thenComparing(t -> t.created)
                .thenComparing(t -> t.uuid);
    }

    static void assignIds(List<Task> tasks) {
        List<Task> open = tasks.stream().filter(t -> Set.of("pending","active","paused","template").contains(t.status)).sorted(Comparator.comparing(t -> t.created)).toList();
        int i = 1;
        for (Task t : open) t.id = i++;
    }

    static Task byOpenId(List<Task> tasks, int id) {
        return tasks.stream().filter(t -> Set.of("pending","active","paused","template").contains(t.status) && t.id == id).findFirst().orElse(null);
    }

    static void ensureRepo() throws IOException, InterruptedException {
        Files.createDirectories(repo);
        if (!Files.isDirectory(repo.resolve(".git"))) {
            ProcessBuilder pb = new ProcessBuilder("git", "-C", repo.toString(), "init");
            pb.inheritIO();
            pb.start().waitFor();
            System.out.println("\nAdd a remote repository with:\n\n\tdstask git remote add origin <repo>\n");
        }
        for (String d : List.of("pending","active","paused","resolved","template")) Files.createDirectories(repo.resolve(d));
    }

    static void commit(String msg) throws IOException, InterruptedException {
        runGit(List.of("add", "."), false);
        runGit(List.of("commit", "-m", msg), false);
    }

    static void runGit(List<String> args, boolean exitOnFailure) throws IOException, InterruptedException {
        List<String> cmd = new ArrayList<>();
        cmd.add("git"); cmd.add("-C"); cmd.add(repo.toString()); cmd.addAll(args);
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line; while ((line = br.readLine()) != null) System.out.println(line);
        }
        int code = p.waitFor();
        if (exitOnFailure && code != 0) System.exit(code);
    }

    static Path repoPath() {
        String e = System.getenv("DSTASK_GIT_REPO");
        if (e != null && !e.isBlank()) return Path.of(e);
        return Path.of(System.getProperty("user.home"), ".dstask");
    }

    static String contextString() throws IOException {
        String e = System.getenv("DSTASK_CONTEXT");
        if (e != null) return e.trim();
        Path p = repo.resolve("context");
        return Files.exists(p) ? Files.readString(p).trim() : "";
    }

    static String parseDue(String s) {
        return LocalDate.parse(s).atStartOfDay().toInstant(ZoneOffset.UTC).toString();
    }

    static String now() { return INSTANT_FMT.format(Instant.now()); }
    static boolean isInt(String s) { try { Integer.parseInt(s); return true; } catch (Exception e) { return false; } }
    static List<String> unique(List<String> in) { return new ArrayList<>(new java.util.TreeSet<>(in)); }
    static int maxId(List<Task> tasks) { return tasks.stream().mapToInt(t -> t.id).max().orElse(0); }
    static Task findByUuid(List<Task> tasks, String uuid) { return tasks.stream().filter(t -> t.uuid.equals(uuid)).findFirst().orElse(null); }
    static void err(String s) { System.err.println("\u001B[31m" + s + "\u001B[0m"); }
    static void field(StringBuilder sb, String k, Object v, boolean quote, int ind) {
        sb.append(" ".repeat(ind)).append("\"").append(k).append("\": ");
        if (quote) sb.append("\"").append(json(String.valueOf(v))).append("\""); else sb.append(v);
    }
    static void comma(StringBuilder sb) { sb.append(",\n"); }
    static String json(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n"); }
    static String esc(String s) { return s == null ? "" : s.replace("\n", "\\n"); }
    static String unesc(String s) {
        s = s.trim();
        if (s.equals("\"\"")) return "";
        return s.replace("\\n", "\n");
    }

    static void help(List<String> rest) {
        if (!rest.isEmpty() && rest.get(0).equals("add")) {
            System.out.print("Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n");
            return;
        }
        System.out.print("""
Usage: dstask [id...] <cmd> [task summary/filter]

Where [task summary] is text with tags/project/priority specified. Tags are
specified with + (or - for filtering) eg: +work. The project is specified with
a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
(low), P2 (default) to P1 (high) and P0 (critical).

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
show-projects     : List projects with completion status
show-tags         : List tags in use
show-active       : Show tasks that have been started
show-paused       : Show tasks that have been started then stopped
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
show-templates    : Show task templates
help              : Get help on any command or show this message
version           : Show dstask version information
""");
    }

    static class UserError extends RuntimeException {
        UserError(String m) { super(m); }
    }
}
