import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Jp2a {
    static final String VERSION = "jp2a 1.0.8";
    static final String PALETTE = "   ...',;:clodxkO0KXNWM";

    static class Opt {
        int width = -1, height = -1;
        boolean border, invert, colors, html, htmlRaw, fill, grayscale;
        boolean flipX, flipY, verbose, clear, htmlBold = true;
        int htmlFont = 8;
        String title = "jp2a converted image";
        String output = null;
        String chars = PALETTE;
        double rw = 0.2989, gw = 0.5866, bw = 0.1145;
        List<String> files = new ArrayList<>();
    }

    static class Pixel {
        int r, g, b, y;
        char ch;
    }

    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.ROOT);
        Opt o = new Opt();
        int parse = parse(args, o);
        if (parse != 0) return;
        if (o.files.isEmpty()) {
            System.out.println("No files specified.\n");
            help();
            return;
        }
        if (o.width <= 0 && o.height <= 0) {
            System.err.println("Environment variable TERM not set.");
            return;
        }
        PrintStream out = System.out;
        if (o.output != null && !o.output.equals("-")) out = new PrintStream(new FileOutputStream(o.output), true, "ISO-8859-1");
        if (o.html && !o.htmlRaw) printHtmlHeader(out, o);
        boolean first = true;
        for (String f : o.files) {
            BufferedImage img = readImage(f);
            if (img == null) continue;
            if (o.verbose) {
                System.err.println("Source width: " + img.getWidth());
                System.err.println("Source height: " + img.getHeight());
                System.err.println("Source color components: " + img.getColorModel().getNumColorComponents());
            }
            int[] wh = outputSize(o, img.getWidth(), img.getHeight());
            if (wh[0] <= 0 || wh[1] <= 0) {
                System.err.println("Invalid width or height specified");
                continue;
            }
            if (o.verbose) {
                System.err.println("Output width: " + wh[0]);
                System.err.println("Output height: " + wh[1]);
                System.err.println("Output palette (" + o.chars.length() + " chars): '" + o.chars + "'");
            }
            if (o.clear && first) out.print("\033[H\033[J");
            Pixel[][] px = render(img, wh[0], wh[1], o);
            emit(px, out, o);
            first = false;
        }
        if (o.html && !o.htmlRaw) printHtmlFooter(out);
        if (out != System.out) out.close();
    }

    static int parse(String[] args, Opt o) {
        for (int i = 0; i < args.length; i++) {
            String a = args[i];
            if (a.equals("-")) { o.files.add(a); continue; }
            if (!a.startsWith("-")) { o.files.add(a); continue; }
            if (a.equals("-h") || a.equals("--help")) { help(); return 1; }
            if (a.equals("-V") || a.equals("--version")) { version(); return 1; }
            if (a.equals("-b") || a.equals("--border")) o.border = true;
            else if (a.equals("-i") || a.equals("--invert")) o.invert = true;
            else if (a.equals("-x") || a.equals("--flipx")) o.flipX = true;
            else if (a.equals("-y") || a.equals("--flipy")) o.flipY = true;
            else if (a.equals("-v") || a.equals("--verbose")) o.verbose = true;
            else if (a.equals("-d") || a.equals("--debug")) {}
            else if (a.equals("--colors") || a.equals("--color")) o.colors = true;
            else if (a.equals("--html")) o.html = true;
            else if (a.equals("--html-raw")) { o.html = true; o.htmlRaw = true; }
            else if (a.equals("--html-no-bold")) o.htmlBold = false;
            else if (a.equals("--fill") || a.equals("--html-fill")) o.fill = true;
            else if (a.equals("--grayscale")) o.grayscale = true;
            else if (a.equals("--clear")) o.clear = true;
            else if (a.equals("--background=dark")) o.invert = false;
            else if (a.equals("--background=light")) o.invert = true;
            else if (a.equals("-f") || a.equals("--term-fit") || a.equals("-z") || a.equals("--term-zoom")
                    || a.equals("--term-width") || a.equals("--term-height") || a.equals("--zoom")) {
                int cols = intEnv("COLUMNS", -1), rows = intEnv("LINES", -1);
                if (cols <= 0 || rows <= 0) {
                    System.err.println("Environment variable TERM not set.");
                    return 1;
                }
                o.width = cols; o.height = rows;
            }
            else if (a.startsWith("--width=")) o.width = parseInt(a.substring(8), -1);
            else if (a.startsWith("--height=")) o.height = parseInt(a.substring(9), -1);
            else if (a.startsWith("--size=")) {
                String s = a.substring(7);
                int x = Math.max(s.indexOf('x'), s.indexOf('X'));
                if (x < 0) return unknown(a);
                o.width = parseInt(s.substring(0, x), -1);
                o.height = parseInt(s.substring(x + 1), -1);
                if (o.width <= 0 || o.height <= 0) { System.err.println("Invalid width or height specified"); return 1; }
            }
            else if (a.startsWith("--chars=")) {
                o.chars = a.substring(8);
                if (o.chars.length() < 2) { System.err.println("Character palette must contain at least two characters"); return 1; }
            }
            else if (a.startsWith("--output=")) o.output = a.substring(9);
            else if (a.startsWith("--html-fontsize=")) o.htmlFont = parseInt(a.substring(16), 8);
            else if (a.startsWith("--html-title=")) o.title = a.substring(13);
            else if (a.startsWith("--red=")) o.rw = parseDouble(a.substring(6), o.rw);
            else if (a.startsWith("--green=")) o.gw = parseDouble(a.substring(8), o.gw);
            else if (a.startsWith("--blue=")) o.bw = parseDouble(a.substring(7), o.bw);
            else return unknown(a);
        }
        return 0;
    }

    static int unknown(String a) {
        System.out.println("Unknown option " + a + "\n");
        help();
        return 1;
    }

    static BufferedImage readImage(String name) {
        try {
            InputStream in;
            if (name.equals("-")) in = System.in;
            else if (name.startsWith("file:")) in = Files.newInputStream(Path.of(URI.create(name)));
            else if (name.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
                System.err.println("Couldn't download " + name);
                return null;
            } else in = new FileInputStream(name);
            try (InputStream bin = new BufferedInputStream(in)) {
                BufferedImage img = ImageIO.read(bin);
                if (img == null) System.err.println("Not a JPEG file");
                return img;
            }
        } catch (FileNotFoundException e) {
            System.err.println("Can't open " + name);
        } catch (Exception e) {
            System.err.println(e.getMessage() == null ? ("Can't open " + name) : e.getMessage());
        }
        return null;
    }

    static int[] outputSize(Opt o, int sw, int sh) {
        if (o.width > 0 && o.height > 0) return new int[]{o.width, o.height};
        if (o.width > 0) return new int[]{o.width, Math.max(1, (int)Math.floor(o.width * (double)sh / sw / 2.0))};
        if (o.height > 0) return new int[]{Math.max(1, (int)Math.floor(o.height * (double)sw / sh * 2.0)), o.height};
        return new int[]{80, Math.max(1, (int)Math.floor(80.0 * sh / sw / 2.0))};
    }

    static Pixel[][] render(BufferedImage img, int ow, int oh, Opt o) {
        Pixel[][] out = new Pixel[oh][ow];
        int sw = img.getWidth(), sh = img.getHeight();
        for (int y = 0; y < oh; y++) {
            int y0 = (int)Math.floor(y * (double)sh / oh);
            int y1 = Math.max(y0 + 1, (int)Math.floor((y + 1) * (double)sh / oh));
            y1 = Math.min(sh, y1);
            for (int x = 0; x < ow; x++) {
                int x0 = (int)Math.floor(x * (double)sw / ow);
                int x1 = Math.max(x0 + 1, (int)Math.floor((x + 1) * (double)sw / ow));
                x1 = Math.min(sw, x1);
                long rs = 0, gs = 0, bs = 0, n = 0;
                for (int yy = y0; yy < y1; yy++) {
                    int sy = o.flipY ? sh - 1 - yy : yy;
                    for (int xx = x0; xx < x1; xx++) {
                        int sx = o.flipX ? sw - 1 - xx : xx;
                        int rgb = img.getRGB(sx, sy);
                        rs += (rgb >> 16) & 255;
                        gs += (rgb >> 8) & 255;
                        bs += rgb & 255;
                        n++;
                    }
                }
                Pixel p = new Pixel();
                p.r = (int)Math.round(rs / (double)n);
                p.g = (int)Math.round(gs / (double)n);
                p.b = (int)Math.round(bs / (double)n);
                int lum = clamp((int)Math.floor(p.r * o.rw + p.g * o.gw + p.b * o.bw + 0.5));
                p.y = lum;
                int val = o.invert ? 255 - lum : lum;
                int idx = (int)Math.round(val * (o.chars.length() - 1) / 255.0);
                if (idx < 0) idx = 0;
                if (idx >= o.chars.length()) idx = o.chars.length() - 1;
                p.ch = o.chars.charAt(idx);
                out[y][x] = p;
            }
        }
        return out;
    }

    static void emit(Pixel[][] px, PrintStream out, Opt o) {
        int h = px.length, w = px[0].length;
        if (o.html) {
            for (int y = 0; y < h; y++) {
                if (o.border) {
                    // jp2a's HTML border is rarely used; keep it textual and predictable.
                    if (y == 0) out.print(htmlEsc("+" + "-".repeat(w) + "+\n"));
                }
                for (int x = 0; x < w; x++) emitHtmlPixel(px[y][x], out, o);
                if (o.colors) out.print("<br/>"); else out.print("\n");
            }
            return;
        }
        if (o.border) {
            out.print("+"); for (int i = 0; i < w; i++) out.print("-"); out.println("+");
        }
        for (int y = 0; y < h; y++) {
            if (o.border) out.print("|");
            for (int x = 0; x < w; x++) emitTextPixel(px[y][x], out, o);
            if (o.border) out.print("|");
            out.println();
        }
        if (o.border) {
            out.print("+"); for (int i = 0; i < w; i++) out.print("-"); out.println("+");
        }
    }

    static void emitTextPixel(Pixel p, PrintStream out, Opt o) {
        if (!o.colors) { out.print(p.ch); return; }
        if (o.grayscale) {
            int c = ansiGray(p.y);
            out.print("\033[" + c + "m" + p.ch + "\033[0m");
        } else {
            int code = ansiColor(p.r, p.g, p.b);
            if (code == 37) out.print(p.ch); else out.print("\033[" + code + "m" + p.ch + "\033[0m");
        }
    }

    static int ansiColor(int r, int g, int b) {
        int max = Math.max(r, Math.max(g, b));
        if (max < 40) return 30;
        if (r > 180 && g > 180 && b > 180) return 37;
        if (r >= g && r >= b) return (g > 100 ? 33 : (b > 100 ? 35 : 31));
        if (g >= r && g >= b) return (r > 100 ? 33 : (b > 100 ? 36 : 32));
        return (r > 100 ? 35 : (g > 100 ? 36 : 34));
    }

    static int ansiGray(int y) {
        if (y < 64) return 30;
        if (y < 128) return 90;
        if (y < 192) return 37;
        return 97;
    }

    static void emitHtmlPixel(Pixel p, PrintStream out, Opt o) {
        if (!o.colors) { out.print(htmlEscChar(p.ch)); return; }
        int r = p.r, g = p.g, b = p.b;
        if (o.grayscale) r = g = b = p.y;
        if (o.fill) {
            out.printf("<span style='color:#%02x%02x%02x; background-color:#%02x%02x%02x;'>%s</span>",
                    r / 2, g / 2, b / 2, r, g, b, htmlEscChar(p.ch));
        } else {
            out.printf("<span style='color:#%02x%02x%02x;'>%s</span>", r, g, b, htmlEscChar(p.ch));
        }
    }

    static void printHtmlHeader(PrintStream out, Opt o) {
        out.println("<?xml version='1.0' encoding='ISO-8859-1'?>");
        out.println("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>");
        out.println("<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>");
        out.println("<head>");
        out.println("<title>" + htmlEsc(o.title) + "</title>");
        out.println("<style type='text/css'>");
        out.println("body {");
        out.println("background-color: " + (o.invert ? "white" : "black") + ";");
        out.println("}");
        out.println(".ascii {");
        out.println("   font-family: Courier;");
        if (!o.colors) out.println("   color: " + (o.invert ? "black" : "white") + ";");
        out.println("   font-size:" + o.htmlFont + "pt;");
        if (o.htmlBold) out.println("   font-weight: bold;");
        out.println("}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='ascii'><pre>");
    }

    static void printHtmlFooter(PrintStream out) {
        out.println("</pre>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }

    static void version() {
        System.out.println(VERSION);
        System.out.println("Copyright 2006-2016 Christian Stigen Larsen");
        System.out.println("Distributed under the GNU General Public License (GPL) v2.");
    }

    static void help() {
        version();
        System.out.println();
        System.out.println("Usage: jp2a [ options ] [ file(s) | URL(s) ]");
        System.out.println();
        System.out.println("Convert files or URLs from JPEG format to ASCII.");
        System.out.println();
        System.out.println("OPTIONS");
        System.out.println("  -                 Read images from standard input.");
        System.out.println("      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145");
        System.out.println("  -b, --border      Print a border around the output image.");
        System.out.println("      --chars=...   Select character palette used to paint the image.");
        System.out.println("                    Leftmost character corresponds to black pixel, right-");
        System.out.println("                    most to white.  Minimum two characters must be specified.");
        System.out.println("      --clear       Clears screen before drawing each output image.");
        System.out.println("      --colors      Use ANSI colors in output.");
        System.out.println("  -d, --debug       Print additional debug information.");
        System.out.println("      --fill        When used with --color and/or --html, color each character's");
        System.out.println("                    background color.");
        System.out.println("  -x, --flipx       Flip image in X direction");
        System.out.println("  -y, --flipy       Flip image in Y direction");
        System.out.println("  -f, --term-fit    Use the largest image dimension that fits in your terminal");
        System.out.println("                    display with correct aspect ratio.");
        System.out.println("      --term-height Use terminal display height.");
        System.out.println("      --term-width  Use terminal display width.");
        System.out.println("  -z, --term-zoom   Use terminal display dimension for output.");
        System.out.println("      --grayscale   Convert image to grayscale when using --html or --colors");
        System.out.println("      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866");
        System.out.println("      --height=N    Set output height, calculate width from aspect ratio.");
        System.out.println("  -h, --help        Print program help.");
        System.out.println("      --html        Produce strict XHTML 1.0 output.");
        System.out.println("      --html-fill   Same as --fill (will be phased out)");
        System.out.println("      --html-fontsize=N   Set fontsize to N pt, default is 4.");
        System.out.println("      --html-no-bold      Do not use bold characters with HTML output");
        System.out.println("      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.");
        System.out.println("      --html-title=...  Set HTML output title");
        System.out.println("  -i, --invert      Invert output image.  Use if your display has a dark");
        System.out.println("                    background.");
        System.out.println("      --background=dark   These are just mnemonics whether to use --invert");
        System.out.println("      --background=light  or not.  If your console has light characters on");
        System.out.println("                    a dark background, use --background=dark.");
        System.out.println("      --output=...  Write output to file.");
        System.out.println("      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.");
        System.out.println("      --size=WxH    Set output width and height.");
        System.out.println("  -v, --verbose     Verbose output.");
        System.out.println("  -V, --version     Print program version.");
        System.out.println("      --width=N     Set output width, calculate height from ratio.");
        System.out.println();
        System.out.println("  The default mode is `jp2a --term-fit --background=dark'.");
        System.out.println("  See the man-page for jp2a for more detailed help text.");
        System.out.println();
        System.out.println("Project homepage on https://github.com/cslarsen/jp2a");
        System.out.println("Report bugs to <csl@csl.name>");
    }

    static int intEnv(String k, int d) { return parseInt(System.getenv(k), d); }
    static int parseInt(String s, int d) { try { return Integer.parseInt(s); } catch (Exception e) { return d; } }
    static double parseDouble(String s, double d) { try { return Double.parseDouble(s); } catch (Exception e) { return d; } }
    static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
    static String htmlEscChar(char c) { return htmlEsc(String.valueOf(c)); }
    static String htmlEsc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
