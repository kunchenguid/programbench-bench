package richgo;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class RichGo {
    static final String RESET = "\033[0m";
    static class Style {
        boolean hide, bold, faint, italic, underline;
        String fg;
        Style copy(){ Style s=new Style(); s.hide=hide; s.bold=bold; s.faint=faint; s.italic=italic; s.underline=underline; s.fg=fg; return s; }
        String on(){
            StringBuilder b=new StringBuilder();
            if (fg!=null) b.append("\033[").append(color(fg)).append('m');
            if (bold) b.append("\033[1m");
            if (faint) b.append("\033[2m");
            if (italic) b.append("\033[3m");
            if (underline) b.append("\033[4m");
            return b.toString();
        }
    }
    static class Config {
        String labelType="long";
        boolean leaveTestPrefix=false;
        int coverThreshold=50;
        List<Pattern> removals=new ArrayList<>();
        Map<String,Style> styles=new HashMap<>();
        Config(){
            style("build", "yellow", true, false);
            style("start", "lightBlack", false, false);
            style("pass", "green", false, false);
            style("fail", "red", true, false);
            style("skip", "lightBlack", false, false);
            style("file", "cyan", false, false);
            style("line", "magenta", false, false);
            style("passPackage", "green", false, true);
            style("failPackage", "red", true, true);
            style("covered", "green", false, false);
            style("uncovered", "yellow", true, false);
        }
        void style(String k,String fg,boolean bold,boolean hide){ Style s=new Style(); s.fg=fg; s.bold=bold; s.hide=hide; styles.put(k,s); }
        Style s(String k){ return styles.get(k); }
    }
    static int color(String c){
        switch(c.toLowerCase(Locale.ROOT)){
            case "black": return 30; case "red": return 31; case "green": return 32; case "yellow": return 33;
            case "blue": return 34; case "magenta": return 35; case "cyan": return 36; case "white": return 37;
            case "lightblack": case "brightblack": case "gray": case "grey": return 90;
            case "lightred": return 91; case "lightgreen": return 92; case "lightyellow": return 93;
            case "lightblue": return 94; case "lightmagenta": return 95; case "lightcyan": return 96; case "lightwhite": return 97;
            default: return 39;
        }
    }
    public static void main(String[] args) throws Exception {
        if (args.length>0 && args[0].equals("testfilter")) { filter(loadConfig(), colorEnabled()); return; }
        runGo(args);
    }
    static boolean colorEnabled(){
        String f=System.getenv("RICHGO_FORCE_COLOR");
        if (f!=null && !f.isEmpty() && !f.equals("0")) return true;
        return System.console()!=null;
    }
    static void runGo(String[] args) throws Exception {
        List<String> cmd=new ArrayList<>(); cmd.add("go"); cmd.addAll(Arrays.asList(args));
        ProcessBuilder pb=new ProcessBuilder(cmd);
        pb.redirectError(ProcessBuilder.Redirect.INHERIT);
        try {
            Process p=pb.start();
            Thread in=new Thread(() -> { try { System.in.transferTo(p.getOutputStream()); p.getOutputStream().close(); } catch(IOException ignored){} });
            in.start();
            boolean filt=args.length>0 && args[0].equals("test") && colorEnabled();
            if (filt) filterStream(p.getInputStream(), System.out, loadConfig(), true); else p.getInputStream().transferTo(System.out);
            in.join();
            System.exit(p.waitFor());
        } catch(IOException e) {
            System.err.println("panic: exec: \"go\": executable file not found in $PATH");
            System.err.println();
            System.err.println("goroutine 1 [running]:");
            System.err.println("main.main()");
            System.exit(2);
        }
    }
    static Config loadConfig(){
        Config c=new Config();
        List<Path> paths=new ArrayList<>();
        Path cwd=Paths.get("").toAbsolutePath(); addStylePaths(paths,cwd);
        String local=System.getenv("RICHGO_LOCAL");
        if (local==null || local.isEmpty() || local.equals("0")) {
            envPath("GOPATH").ifPresent(p->addStylePaths(paths,p)); envPath("GOROOT").ifPresent(p->addStylePaths(paths,p)); envPath("HOME").ifPresent(p->addStylePaths(paths,p));
        }
        for(Path p: paths) if(Files.isRegularFile(p)) { parseConfig(c,p); break; }
        return c;
    }
    static Optional<Path> envPath(String e){ String v=System.getenv(e); return v==null||v.isEmpty()?Optional.empty():Optional.of(Paths.get(v)); }
    static void addStylePaths(List<Path> ps,Path base){ ps.add(base.resolve(".richstyle")); ps.add(base.resolve(".richstyle.yaml")); ps.add(base.resolve(".richstyle.yml")); }
    static void parseConfig(Config c, Path p){
        try { List<String> lines=Files.readAllLines(p); String section=null; boolean inRem=false;
            for(String raw: lines){ String no=raw.replaceFirst("\\s+#.*$",""); if(no.trim().isEmpty()) continue; int ind=raw.length()-raw.stripLeading().length(); String t=no.trim();
                if(ind==0){ inRem=false; section=null; if(t.startsWith("labelType:")) c.labelType=val(t); else if(t.startsWith("leaveTestPrefix:")) c.leaveTestPrefix=bool(val(t)); else if(t.startsWith("coverThreshold:")) c.coverThreshold=parseInt(val(t),50); else if(t.startsWith("removals:")) inRem=true; else if(t.endsWith("Style:")){ section=t.substring(0,t.length()-6); c.styles.putIfAbsent(section,new Style()); } }
                else if(inRem && t.startsWith("-")){ try{c.removals.add(Pattern.compile(t.substring(1).trim()));}catch(Exception ignored){} }
                else if(section!=null){ Style s=c.styles.get(section); if(t.startsWith("hide:"))s.hide=bool(val(t)); else if(t.startsWith("bold:"))s.bold=bool(val(t)); else if(t.startsWith("faint:"))s.faint=bool(val(t)); else if(t.startsWith("italic:"))s.italic=bool(val(t)); else if(t.startsWith("underline:"))s.underline=bool(val(t)); else if(t.startsWith("foreground:"))s.fg=unq(val(t)); }
            }
        } catch(IOException ignored){}
    }
    static String val(String s){ return s.substring(s.indexOf(':')+1).trim(); }
    static boolean bool(String s){ return unq(s).equalsIgnoreCase("true"); }
    static String unq(String s){ s=s.trim(); if((s.startsWith("\"")&&s.endsWith("\""))||(s.startsWith("'")&&s.endsWith("'"))) return s.substring(1,s.length()-1); return s; }
    static int parseInt(String s,int d){ try{return Integer.parseInt(s.trim());}catch(Exception e){return d;} }
    static void filter(Config c, boolean color) throws IOException { filterStream(System.in, System.out, c, color); }
    static void filterStream(InputStream in, PrintStream out, Config c, boolean color) throws IOException{
        BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)); String line;
        while((line=br.readLine())!=null){
            String current=line;
            if(c.removals.stream().anyMatch(p->p.matcher(current).find())) continue;
            if(color) {
                String formatted = format(current,c);
                if(formatted != null) out.println(formatted);
            } else {
                out.println(current);
            }
        }
        if(!color) out.println();
    }
    static String format(String line, Config c){
        Matcher m;
        if(line.startsWith("=== RUN   ")) return styled(c,"start", label(c,"START",">")+testName(line.substring(10),c), false);
        m=Pattern.compile("^--- (PASS|FAIL|SKIP): (.*)$").matcher(line); if(m.matches()){ String kind=m.group(1).toLowerCase(Locale.ROOT); return styled(c,kind,label(c,m.group(1), kind.equals("pass")?"o":kind.equals("fail")?"x":"-")+testName(m.group(2),c),false); }
        if(line.equals("PASS")) return c.s("passPackage").hide?null:styled(c,"passPackage","PASS",false);
        if(line.equals("FAIL")) return c.s("failPackage").hide?null:styled(c,"failPackage","FAIL",false);
        if(line.startsWith("# ")) return styled(c,"build",label(c,"BUILD","!!")+line.substring(2),false);
        m=Pattern.compile("^coverage: ([0-9.]+)%.*$").matcher(line); if(m.matches()) return cover(c,m.group(1));
        m=Pattern.compile("^ok\\s+([^\\t]+)\\t[^\\t]+(?:\\t(coverage: .*))?$").matcher(line); if(m.matches()) return styled(c,"pass",label(c,"PASS","o")+m.group(1)+" "+(m.group(2)==null?"":m.group(2)),false);
        m=Pattern.compile("^FAIL(.*)$").matcher(line); if(m.matches()) return styled(c,"fail",label(c,"FAIL","x")+m.group(1),false);
        m=Pattern.compile("^\\?\\s+([^\\t]+)\\t(.*)$").matcher(line); if(m.matches()) return styled(c,"skip",label(c,"SKIP","-")+m.group(1)+"\t"+m.group(2),false);
        return styled(c,"start",labelBlank(c)+colorFileLine(line,c,"start"), true);
    }
    static String cover(Config c,String pct){ double d=Double.parseDouble(pct); int n=(int)Math.round(d/10.0); if(n<0)n=0; if(n>10)n=10; String bar="["+"#".repeat(n)+"_".repeat(10-n)+"]"; return styled(c,d>=c.coverThreshold?"covered":"uncovered",label(c,"COVER","%")+pct+"% "+bar,false); }
    static String testName(String name, Config c){ if(!c.leaveTestPrefix && name.startsWith("Test")) name=name.substring(4); int slash=0; for(char ch:name.toCharArray()) if(ch=='/') slash++; return "  ".repeat(slash)+name; }
    static String label(Config c,String longL,String shortL){ if(c.labelType.equals("none")) return ""; if(c.labelType.equals("short")) return shortL+"  "; return String.format("%-5s| ", longL); }
    static String labelBlank(Config c){ if(c.labelType.equals("none")) return ""; if(c.labelType.equals("short")) return "   "; return "     | "; }
    static String styled(Config c,String st,String body,boolean already){ Style s=c.s(st); String content=already?body:colorFileLine(body,c,st); return s.on()+content+RESET; }
    static String colorFileLine(String text, Config c, String base){
        Matcher m=Pattern.compile("([^\\s:]+\\.[A-Za-z0-9_]+):(\\d+)").matcher(text); StringBuffer sb=new StringBuffer();
        while(m.find()){ String r=c.s("file").on()+m.group(1)+RESET+c.s("line").on()+":"+m.group(2)+RESET+c.s(base).on(); m.appendReplacement(sb, Matcher.quoteReplacement(r)); }
        m.appendTail(sb); return sb.toString();
    }
}
