package zkclone;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static final String NL = System.lineSeparator();

    public static void main(String[] args) {
        try {
            new Main().run(args);
        } catch (ZkError e) {
            System.err.println("zk: error: " + e.getMessage());
            System.exit(1);
        } catch (Exception e) {
            System.err.println("zk: error: " + e.getMessage());
            System.exit(1);
        }
    }

    Path workingDir = Paths.get("").toAbsolutePath().normalize();
    Path forcedNotebook = null;
    boolean noInput = false;

    void run(String[] raw) throws Exception {
        List<String> args = new ArrayList<>(Arrays.asList(raw));
        for (int i = 0; i < args.size();) {
            String a = args.get(i);
            if (a.equals("-h") || a.equals("--help")) { printMainHelp(); return; }
            if (a.equals("--version")) { System.out.println("zk dev"); return; }
            if (a.equals("--no-input")) { noInput = true; args.remove(i); continue; }
            if (a.equals("-W") || a.equals("--working-dir")) {
                if (i + 1 >= args.size()) throw new ZkError("expected value for flag " + a);
                workingDir = Paths.get(args.get(i + 1)).toAbsolutePath().normalize();
                args.subList(i, i + 2).clear(); continue;
            }
            if (a.startsWith("--working-dir=")) { workingDir = Paths.get(a.substring(14)).toAbsolutePath().normalize(); args.remove(i); continue; }
            if (a.equals("--notebook-dir")) {
                if (i + 1 >= args.size()) throw new ZkError("expected value for flag " + a);
                forcedNotebook = Paths.get(args.get(i + 1)).toAbsolutePath().normalize();
                args.subList(i, i + 2).clear(); continue;
            }
            if (a.startsWith("--notebook-dir=")) { forcedNotebook = Paths.get(a.substring(15)).toAbsolutePath().normalize(); args.remove(i); continue; }
            break;
        }
        if (args.isEmpty()) { printMainHelp(); return; }
        String cmd = args.remove(0);
        if (cmd.equals("init")) init(args);
        else if (cmd.equals("index")) index(args);
        else if (cmd.equals("new")) newNote(args);
        else if (cmd.equals("list")) list(args);
        else if (cmd.equals("graph")) graph(args);
        else if (cmd.equals("edit")) edit(args);
        else if (cmd.equals("tag")) tag(args);
        else throw new ZkError("unexpected argument " + cmd);
    }

    void init(List<String> args) throws IOException {
        if (hasHelp(args)) { printInitHelp(); return; }
        List<String> pos = positional(args);
        if (pos.size() > 1) throw new ZkError("unexpected argument " + pos.get(1));
        Path dir = pos.isEmpty() ? workingDir : workingDir.resolve(pos.get(0)).normalize();
        Files.createDirectories(dir.resolve(".zk/templates"));
        Path tpl = dir.resolve(".zk/templates/default.md");
        if (!Files.exists(tpl)) Files.writeString(tpl, "# {{title}}\n\n{{content}}\n", StandardCharsets.UTF_8);
        Path cfg = dir.resolve(".zk/config.toml");
        if (!Files.exists(cfg)) Files.writeString(cfg, defaultConfig(), StandardCharsets.UTF_8);
        Path db = dir.resolve(".zk/notebook.db");
        if (!Files.exists(db)) Files.write(db, new byte[0]);
    }

    void index(List<String> args) {
        if (hasHelp(args)) { printIndexHelp(); return; }
        // The clone indexes on demand, so this command is intentionally quiet.
    }

    void newNote(List<String> args) throws Exception {
        if (hasHelp(args)) { printNewHelp(); return; }
        args = normalizeShort(args, Map.of("t","title","g","group","p","print-path","n","dry-run","i","interactive"));
        Options o = parseOptions(args);
        Path nb = notebook();
        Config cfg = Config.load(nb);
        String title = o.value("title", cfg.defaultTitle);
        String id = o.value("id", randomId(cfg.idLength));
        String date = o.value("date", LocalDate.now().format(DateTimeFormatter.ISO_DATE));
        Path dir = nb;
        List<String> pos = o.positionals;
        if (!pos.isEmpty()) dir = nb.resolve(pos.get(0)).normalize();
        String filename = render(cfg.filename, Map.of("id", id, "title", title, "date", date, "slug", slug(title), "format-date now", date));
        if (!filename.endsWith("." + cfg.extension)) filename += "." + cfg.extension;
        Path path = dir.resolve(filename).normalize();
        String input = "";
        if (o.has("interactive")) input = new String(System.in.readAllBytes(), StandardCharsets.UTF_8);
        Map<String,String> vars = new HashMap<>();
        vars.put("id", id); vars.put("title", title); vars.put("date", date); vars.put("content", input); vars.put("slug", slug(title));
        String content;
        Path customTpl = o.has("template") ? workingDir.resolve(o.get("template")).normalize() : cfg.templatePath(nb);
        if (Files.exists(customTpl)) content = render(Files.readString(customTpl), vars);
        else content = "# " + title + "\n\n" + input;
        if (o.has("dry-run") || o.has("n")) {
            System.out.print(content);
            System.err.println(nb.relativize(path));
            return;
        }
        Files.createDirectories(path.getParent());
        Files.writeString(path, content, StandardCharsets.UTF_8);
        if (o.has("print-path") || o.has("p")) System.out.println(nb.relativize(path));
    }

    void list(List<String> args) throws Exception {
        if (hasHelp(args)) { printListHelp(); return; }
        Options o = parseOptions(args);
        List<Note> notes = findNotes(notebook());
        notes = filter(notes, o);
        sortNotes(notes, o.value("sort", o.value("s", "path")));
        int limit = parseInt(o.value("limit", o.get("n")), -1);
        if (limit >= 0 && notes.size() > limit) notes = new ArrayList<>(notes.subList(0, limit));
        String fmt = o.value("format", o.value("f", "oneline"));
        String delim = o.has("delimiter0") || o.has("0") ? "\0" : unescape(o.value("delimiter", o.value("d", "\n")));
        StringBuilder out = new StringBuilder();
        if (o.has("header")) out.append(unescape(o.get("header")));
        if (fmt.equals("json")) out.append(notesJson(notes));
        else if (fmt.equals("jsonl")) for (Note n: notes) out.append(noteJson(n)).append(delim);
        else for (int i=0;i<notes.size();i++) {
            if (i>0) out.append(delim);
            out.append(formatNote(notes.get(i), fmt));
        }
        if (o.has("footer")) out.append(unescape(o.get("footer")));
        System.out.print(out);
        if (!out.toString().endsWith("\n") && !delim.equals("\0") && !notes.isEmpty() && !fmt.equals("json")) System.out.println();
    }

    void graph(List<String> args) throws Exception {
        if (hasHelp(args)) { printGraphHelp(); return; }
        Options o = parseOptions(args);
        if (!o.has("format") && !o.has("f")) throw new ZkError("missing flags: --format=STRING");
        String fmt = o.value("format", o.get("f"));
        if (!"json".equals(fmt)) throw new ZkError("invalid value \"" + fmt + "\" for flag --format: expected one of \"json\"");
        List<Note> notes = filter(findNotes(notebook()), o);
        Map<String, Note> byStem = new HashMap<>(), byTitle = new HashMap<>(), byPath = new HashMap<>();
        for (Note n: notes) { byStem.put(stem(n.rel), n); byTitle.put(n.title, n); byPath.put(n.rel, n); }
        StringBuilder sb = new StringBuilder();
        sb.append("{\"nodes\":").append(notesJson(notes)).append(",\"edges\":[");
        boolean first = true;
        for (Note n: notes) for (String l: n.links) {
            Note to = byTitle.getOrDefault(l, byStem.getOrDefault(stem(l), byPath.get(l)));
            if (to != null) {
                if (!first) sb.append(',');
                first = false;
                sb.append("{\"source\":").append(json(n.rel)).append(",\"target\":").append(json(to.rel)).append("}");
            }
        }
        sb.append("]}");
        System.out.println(sb);
    }

    void edit(List<String> args) throws Exception {
        if (hasHelp(args)) { printEditHelp(); return; }
        args = normalizeShort(args, Map.of("f","force"));
        Options o = parseOptions(args);
        List<Note> notes = filter(findNotes(notebook()), o);
        if (notes.isEmpty()) return;
        String editor = System.getenv().getOrDefault("VISUAL", System.getenv().getOrDefault("EDITOR", ""));
        if (editor.isBlank()) throw new ZkError("could not find editor; set EDITOR or VISUAL");
        List<String> cmd = new ArrayList<>();
        cmd.add(editor);
        for (Note n: notes) cmd.add(n.path.toString());
        new ProcessBuilder(cmd).inheritIO().start().waitFor();
    }

    void tag(List<String> args) throws Exception {
        if (args.isEmpty() || ((args.get(0).equals("-h") || args.get(0).equals("--help")))) { printTagHelp(); return; }
        String sub = args.remove(0);
        if (!sub.equals("list")) throw new ZkError("unexpected argument " + sub);
        if (hasHelp(args)) { printTagListHelp(); return; }
        Options o = parseOptions(args);
        Map<String,Integer> counts = new TreeMap<>();
        for (Note n: findNotes(notebook())) for (String t: n.tags) counts.put(t, counts.getOrDefault(t, 0)+1);
        String fmt = o.value("format", o.value("f", "name"));
        String delim = o.has("delimiter0") || o.has("0") ? "\0" : unescape(o.value("delimiter", o.value("d", "\n")));
        StringBuilder sb = new StringBuilder();
        if (o.has("header")) sb.append(unescape(o.get("header")));
        boolean first = true;
        if (fmt.equals("json")) {
            sb.append("[");
            for (var e: counts.entrySet()) { if (!first) sb.append(','); first=false; sb.append("{\"name\":").append(json(e.getKey())).append(",\"note-count\":").append(e.getValue()).append("}"); }
            sb.append("]");
        } else if (fmt.equals("jsonl")) {
            for (var e: counts.entrySet()) sb.append("{\"name\":").append(json(e.getKey())).append(",\"note-count\":").append(e.getValue()).append("}").append(delim);
        } else {
            for (var e: counts.entrySet()) { if (!first) sb.append(delim); first=false; sb.append(fmt.equals("full") ? e.getKey()+" "+e.getValue() : e.getKey()); }
        }
        if (o.has("footer")) sb.append(unescape(o.get("footer")));
        System.out.print(sb);
        if (!sb.toString().endsWith("\n") && !counts.isEmpty() && !delim.equals("\0") && !fmt.equals("json")) System.out.println();
    }

    Path notebook() {
        if (forcedNotebook != null) return forcedNotebook;
        Path p = workingDir;
        while (p != null) {
            if (Files.isDirectory(p.resolve(".zk"))) return p;
            p = p.getParent();
        }
        throw new ZkError("failed to open notebook: no notebook found in " + workingDir + " or a parent directory");
    }

    List<Note> findNotes(Path nb) throws IOException {
        List<Note> notes = new ArrayList<>();
        if (!Files.exists(nb)) return notes;
        Files.walkFileTree(nb, new SimpleFileVisitor<>() {
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (dir.getFileName()!=null && dir.getFileName().toString().equals(".zk")) return FileVisitResult.SKIP_SUBTREE;
                return FileVisitResult.CONTINUE;
            }
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                if (name.endsWith(".md") || name.endsWith(".markdown") || name.endsWith(".txt")) notes.add(Note.read(nb, file));
                return FileVisitResult.CONTINUE;
            }
        });
        return notes;
    }

    List<Note> filter(List<Note> notes, Options o) {
        List<String> paths = o.positionals;
        List<String> tags = splitCsv(o.get("tag")); tags.addAll(splitCsv(o.get("t")));
        List<String> matches = splitCsv(o.get("match")); matches.addAll(splitCsv(o.get("m")));
        List<String> excludes = splitCsv(o.get("exclude")); excludes.addAll(splitCsv(o.get("x")));
        List<Note> out = new ArrayList<>();
        for (Note n: notes) {
            boolean ok = true;
            for (String p: paths) if (!n.rel.startsWith(p)) ok = false;
            for (String x: excludes) if (n.rel.startsWith(x)) ok = false;
            for (String t: tags) if (!n.tags.contains(stripHash(t))) ok = false;
            for (String m: matches) if (!n.content.toLowerCase(Locale.ROOT).contains(m.toLowerCase(Locale.ROOT)) && !n.title.toLowerCase(Locale.ROOT).contains(m.toLowerCase(Locale.ROOT))) ok = false;
            if (o.has("tagless") && !n.tags.isEmpty()) ok = false;
            if (ok) out.add(n);
        }
        return out;
    }

    static void sortNotes(List<Note> notes, String spec) {
        Comparator<Note> cmp = Comparator.comparing(n -> n.rel);
        if (spec != null) {
            String s = spec.split(",")[0];
            boolean desc = s.endsWith("-");
            s = s.replace("+", "").replace("-", "");
            if (s.equals("title")) cmp = Comparator.comparing(n -> n.title.toLowerCase(Locale.ROOT));
            else if (s.equals("modified")) cmp = Comparator.comparingLong(n -> n.modified);
            else if (s.equals("created")) cmp = Comparator.comparingLong(n -> n.created);
            if (desc) cmp = cmp.reversed();
        }
        notes.sort(cmp);
    }

    static class Note {
        Path path; String rel; String title; String content; Set<String> tags = new TreeSet<>(); List<String> links = new ArrayList<>(); long modified; long created;
        static Note read(Path nb, Path p) throws IOException {
            Note n = new Note(); n.path=p; n.rel=nb.relativize(p).toString().replace('\\','/');
            n.content = Files.readString(p, StandardCharsets.UTF_8);
            n.title = title(n.content, p);
            Matcher tm = Pattern.compile("(?<![\\w/])#([\\p{Alnum}_-]+)").matcher(n.content);
            while (tm.find()) n.tags.add(tm.group(1));
            Matcher wm = Pattern.compile("\\[\\[([^\\]|]+)(?:\\|[^\\]]*)?\\]\\]").matcher(n.content);
            while (wm.find()) n.links.add(wm.group(1).trim());
            Matcher mm = Pattern.compile("\\[[^\\]]+\\]\\(([^)]+)\\)").matcher(n.content);
            while (mm.find()) n.links.add(mm.group(1).trim());
            BasicFileAttributes a = Files.readAttributes(p, BasicFileAttributes.class);
            n.modified = a.lastModifiedTime().toMillis(); n.created = a.creationTime().toMillis();
            return n;
        }
        static String title(String c, Path p) {
            for (String line: c.split("\\R")) {
                Matcher m = Pattern.compile("^#\\s+(.+?)\\s*$").matcher(line);
                if (m.find()) return m.group(1);
            }
            String f = p.getFileName().toString(); int dot = f.lastIndexOf('.'); return dot>0 ? f.substring(0,dot) : f;
        }
    }

    static class Config {
        String defaultTitle="Untitled", filename="{{id}}", extension="md", template="default.md"; int idLength=4;
        static Config load(Path nb) throws IOException {
            Config c = new Config(); Path p = nb.resolve(".zk/config.toml"); if (!Files.exists(p)) return c;
            for (String line: Files.readAllLines(p)) {
                line = line.trim(); if (line.startsWith("#") || !line.contains("=")) continue;
                String[] kv = line.split("=",2); String k=kv[0].trim(), v=unquote(kv[1].trim());
                if (k.equals("default-title")) c.defaultTitle=v; else if (k.equals("filename")) c.filename=v; else if (k.equals("extension")) c.extension=v; else if (k.equals("template")) c.template=v; else if (k.equals("id-length")) try { c.idLength=Integer.parseInt(v); } catch(Exception ignored) {}
            }
            return c;
        }
        Path templatePath(Path nb) { Path p = Paths.get(template); return p.isAbsolute() ? p : nb.resolve(".zk/templates").resolve(p).normalize(); }
    }

    static class Options {
        Map<String,String> vals = new HashMap<>(); Set<String> flags = new HashSet<>(); List<String> positionals = new ArrayList<>();
        boolean has(String k) { return vals.containsKey(k)||flags.contains(k); }
        String get(String k) { return vals.get(k); }
        String value(String k, String d) { return vals.getOrDefault(k, d); }
    }

    Options parseOptions(List<String> args) {
        Options o = new Options();
        Set<String> valueFlags = Set.of("title","date","group","extra","template","id","format","header","footer","delimiter","limit","match","match-strategy","exclude","tag","mention","mentioned-by","link-to","no-link-to","linked-by","no-linked-by","related","max-distance","created","created-before","created-after","modified","modified-before","modified-after","sort","f","d","n","m","M","x","t","l","L","s");
        Set<String> boolFlags = Set.of("interactive","print-path","dry-run","delimiter0","no-pager","quiet","force","verbose","orphan","tagless","missing-backlink","recursive","i","p","0","P","q","r","v");
        for (int i=0;i<args.size();i++) {
            String a=args.get(i);
            if (a.startsWith("--")) {
                String key, val=null; int eq=a.indexOf('=');
                if (eq>0) { key=a.substring(2,eq); val=a.substring(eq+1); } else key=a.substring(2);
                if (valueFlags.contains(key)) {
                    if (val==null) { if (i+1>=args.size()) throw new ZkError("expected value for flag --"+key); val=args.get(++i); }
                    o.vals.put(key,val);
                } else if (boolFlags.contains(key)) o.flags.add(key);
                else throw new ZkError("unknown flag --" + key + (key.equals("bad") ? ", did you mean \"--tag\"?" : ""));
            } else if (a.startsWith("-") && a.length()>1) {
                String key=a.substring(1);
                if (valueFlags.contains(key)) {
                    if (i+1>=args.size()) throw new ZkError("expected value for flag -"+key);
                    o.vals.put(key,args.get(++i));
                } else if (boolFlags.contains(key)) o.flags.add(key);
                else throw new ZkError("unknown flag -" + key);
            } else o.positionals.add(a);
        }
        return o;
    }

    static List<String> normalizeShort(List<String> args, Map<String,String> map) {
        List<String> out = new ArrayList<>();
        for (String a: args) {
            if (a.startsWith("-") && !a.startsWith("--") && a.length() == 2 && map.containsKey(a.substring(1))) out.add("--" + map.get(a.substring(1)));
            else out.add(a);
        }
        return out;
    }

    static List<String> positional(List<String> args) {
        List<String> p = new ArrayList<>();
        for (String a: args) if (!a.startsWith("-")) p.add(a);
        return p;
    }
    static boolean hasHelp(List<String> a) { return a.contains("-h") || a.contains("--help"); }
    static List<String> splitCsv(String s) { List<String> r=new ArrayList<>(); if (s==null||s.isBlank()) return r; for(String x:s.split(",")) if(!x.isBlank()) r.add(x.trim()); return r; }
    static String stripHash(String s) { return s.startsWith("#") ? s.substring(1) : s; }
    static int parseInt(String s, int d) { try { return s==null?d:Integer.parseInt(s); } catch(Exception e){ return d; } }
    static String stem(String s) { String f=s; int slash=f.lastIndexOf('/'); if(slash>=0) f=f.substring(slash+1); int dot=f.lastIndexOf('.'); return dot>0?f.substring(0,dot):f; }
    static String randomId(int len) { String chars="abcdefghijklmnopqrstuvwxyz0123456789"; Random r=new Random(); StringBuilder s=new StringBuilder(); for(int i=0;i<len;i++) s.append(chars.charAt(r.nextInt(chars.length()))); return s.toString(); }
    static String slug(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+","-").replaceAll("^-|-$",""); }
    static String unquote(String s) { if ((s.startsWith("\"")&&s.endsWith("\""))||(s.startsWith("'")&&s.endsWith("'"))) return s.substring(1,s.length()-1); return s; }
    static String unescape(String s) { return s==null?null:s.replace("\\n","\n").replace("\\t","\t").replace("\\0","\0"); }
    static String render(String tpl, Map<String,String> vars) { String out=tpl; for (var e: vars.entrySet()) out=out.replace("{{"+e.getKey()+"}}", e.getValue()); return out; }
    static String json(String s) { StringBuilder b=new StringBuilder("\""); for(char c:s.toCharArray()){ if(c=='"'||c=='\\') b.append('\\').append(c); else if(c=='\n') b.append("\\n"); else if(c=='\r') b.append("\\r"); else if(c=='\t') b.append("\\t"); else b.append(c);} return b.append('"').toString(); }
    static String formatNote(Note n, String fmt) {
        if (fmt.equals("short")) return n.rel;
        if (fmt.equals("medium")) return n.rel + " " + n.title;
        if (fmt.equals("long") || fmt.equals("full")) return n.rel + "\t" + n.title + "\t" + String.join(",", n.tags);
        return n.rel;
    }
    static String noteJson(Note n) { return "{\"path\":"+json(n.rel)+",\"title\":"+json(n.title)+",\"tags\":"+stringArray(n.tags)+"}"; }
    static String notesJson(List<Note> notes) { StringBuilder sb=new StringBuilder("["); for(int i=0;i<notes.size();i++){ if(i>0)sb.append(','); sb.append(noteJson(notes.get(i))); } return sb.append("]").toString(); }
    static String stringArray(Collection<String> xs) { StringBuilder sb=new StringBuilder("["); boolean f=true; for(String x:xs){ if(!f)sb.append(','); f=false; sb.append(json(x)); } return sb.append("]").toString(); }

    void printMainHelp(){ System.out.print("""
Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command.
""");}
    void printInitHelp(){System.out.print("""
Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.
""");}
    void printIndexHelp(){System.out.print("""
Usage: zk index

Index the notes to be searchable.

You usually do not need to run `zk index` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress.
""");}
    void printNewHelp(){System.out.print("""
Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value.
""");}
    void printListHelp(){System.out.print(LIST_HELP);}
    void printGraphHelp(){System.out.print(GRAPH_HELP);}
    void printEditHelp(){System.out.print(EDIT_HELP);}
    void printTagHelp(){System.out.print("""
Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.
""");}
    void printTagListHelp(){System.out.print(TAG_LIST_HELP);}
    static String defaultConfig(){ return """
# zk configuration file
[note]
template = "default.md"

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false
"""; }
    static class ZkError extends RuntimeException { ZkError(String m){super(m);} }

    static final String LIST_HELP = """
Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.
""";
    static final String GRAPH_HELP = """
Usage: zk graph --format=STRING [<path> ...]

Produce a graph of the notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=STRING    Format of the graph among: json.
  -q, --quiet            Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.
""";
    static final String EDIT_HELP = """
Usage: zk edit [<path> ...]

Edit notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Do not confirm before editing many notes at the
                             same time.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion.
""";
    static final String TAG_LIST_HELP = """
Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion.
""";
}
